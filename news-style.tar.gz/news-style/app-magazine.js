(function(){
    //Volt.BASE_PATH = 'http://10.240.135.67:8080/'; // In case server environment
    Volt.BASE_PATH = 'file://'; // In case TV environment
    Volt.require = function(path) {
        return require(Volt.browser ? path : Volt.BASE_PATH + path);
    };
})();

/*
 * Include modules
 */
var Require = Volt.require;
// This two files should be required first, other files depend on this file
// Only need to require Once
Require('lib/volt-debug.js');       // For Debug
Require('lib/volt-common.js');      // Common Functions

Require('lib/volt-nav.js');         // Focus and Key Input Management
Require('app/magazine-router.js');

var Backbone = Require('lib/volt-backbone.js'),
    PanelCommon = Volt.require('lib/panel-common.js'),
    ModelController = Require('app/controller/model-controller.js'),

    mainTemplate = PanelCommon.requireTemplate('main');

// KPI
Volt.KPIMapper = Volt.require('app/common/kpi-mapper.js');

//multilingual
Volt.i18n = Volt.require('lib/volt-multilingual.js');

////////////////////////
// Update Template Parser with Custom Widget Support
PanelCommon.mapWidgets(['CategoryTabs', 'OptionMenu', 'ResizeableGrid', 'Button_Generic', 'MessagePopup','AutoScrollTextWidget']);

////////////////////////
/**
 * Entry point for Volt application
 */
var initialize = function() {
    scene.color = {r: 0x0f, g: 0x18, b: 0x26};
    //Volt.KPIMapper.init();
    Volt.i18n.init({
        lng : 'en',
        resGetPath: 'lang/<<lng>>.json',
        getAsync: false,
        interpolationPrefix: '<<',
        interpolationSuffix: '>>'
    }, function(t){
        // Volt.log(t('TV_SID_MIX_RECORD_A_B_C', {'A' : '9', 'B' : '11', 'C' : '3'}));
        // Volt.i18n.setLng('en', function(t){
        //     Volt.log(Volt.i18n.t('TV_SID_MIX_RECORD_A_B_C', {'A' : '9', 'B' : '11', 'C' : '3'}), 4);
        // });
    });
/*
    var bg = new Widget({
		        x: 0, 
			    y: 0, 
			    width: 1920, 
			    height: 1080,
                color: Volt.hexToRgb('#0f1826'),
                parent : scene 
            });
*/
    // Set minCount of history, to prevent pop out all histroy
    Backbone.history.start({minCount: 1});

    Backbone.history.navigate('home', {
        trigger: true,
        focusPosition: mainTemplate.FOCUS_POSITION_CONTENT,
        focusIndex: 0
    });

    ModelController.ready();
};


/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keyCode, keyType) {
    Volt.log('keyCode: ' + keyCode + ', keyType: ' + keyType);

    // if Volt.Nav didn't process the event, the app will process it.
    if (Volt.Nav.onKeyEvent(keyCode, keyType) === false
        && keyCode == Volt.KEY_RETURN
        && keyType == Volt.EVENT_KEY_PRESS) {

        if (Backbone.history.getCount() > 1) {
            Volt.log("Return");
            Backbone.history.back();
            return;
        } else {
            Volt.log("Exit Common Module Panel");
			Volt.exit();
		}
    }
};

Volt.addEventListener(Volt.ON_SHOW, function(data){
    Volt.log("receive event ON_SHOW:"+JSON.stringify(data));
    PanelCommon.GlobalMediator.trigger("EVENT_VOLT_ON_SHOW");
    /*if(data == undefined || data == null){
        print('data is null or undefined');
        return;
    }
    
	if(data["Sub_Menu"] == "detail"){
		IsDeepLink = true;
		DeepLinkWidgetID = data["widget_id"];
	}*/

});

Volt.addEventListener(Volt.ON_PAUSE, function(){
    Volt.log("receive event ON_PAUSE");
    PanelCommon.GlobalMediator.trigger("EVENT_VOLT_ON_PAUSE");
});

Volt.addEventListener(Volt.ON_RESUME, function(){
    Volt.log("receive event ON_RESUME");
    PanelCommon.GlobalMediator.trigger("EVENT_VOLT_ON_RESUME");
});

Volt.addEventListener(Volt.ON_HIDE, function(){
    Volt.log("receive event ON_HIDE");
    PanelCommon.GlobalMediator.trigger("EVENT_VOLT_ON_HIDE");
});
Volt.addEventListener(Volt.ON_UNLOAD, function(){
    Volt.log("receive event ON_UNLOAD");
    PanelCommon.GlobalMediator.trigger("EVENT_VOLT_ON_UNLOAD");
});
