var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

    //////
    RouterController = Require('app/controller/router-controller.js');

var Router = Backbone.Router.extend({
    // Define routes here
    routes: {
        //'main': 'main', // route to MainView
        "home": "home",
		// route to SubView
        "Spotlight":"spotlight",
        "Brand Zone":"brandzone",
        'What`s New':"whatsNew",
        "Most Popular":"mostPopular",
        "Top Grossing":"topGrossing",
        "Genre":"genre",
        "My Page":"myPage",
        
        'main/:id': 'category', // route to MainView with Category ID
        'detail/:id': 'detail', // route to DetailView with Product ID
        'main/popup/:type': 'popup', // route to Popup in MainView
        'uielement': 'uielement'
    },

    // Enter MainView
   /* main: function (options) {
        RouterController.root('main-view', options);
    },*/

    // Enter HomeView
    home: function(options) {
        print("RouterController.show('main-spotlight-view')");
        RouterController.root('main-view',options).sub('main-spotlight-view'); 
    },
	// Enter SubView
    spotlight:function(options){
        print("RouterController.show('main-spotlight-view')");
        RouterController.root('main-view',options).sub('main-spotlight-view'); 
    },
    
    brandzone:function(options){
        print("RouterController.show('main-brandzone-view')");
        RouterController.root('main-view',options).sub('main-brandzone-view');
    },
    
    whatsNew:function(options){
        print("RouterController.show('main-whatsnew-view')");
        RouterController.root('main-view',options).sub('main-whatsnew-view');
    },
    
    mostPopular:function(options){
        print("RouterController.show('main-popular-view')");
        RouterController.root('main-view',options).sub('main-popular-view');
    },
    
    topGrossing:function(options){
        print("RouterController.show('main-grossing-view')");
        RouterController.root('main-view',options).sub('main-grossing-view');
    },
    
    genre:function(options){
        print("RouterController.show('main-genre-view')");
        RouterController.root('main-view',options).sub('main-genre-view');
    },
    
    myPage:function(options){
        print("RouterController.show('main-mypage-view')");
        RouterController.root('main-view',options).sub('main-mypage-view');
    },

	
    // Enter uielement
    uielement: function (options) {
        RouterController.root('uielement-view', options);
    },

    // Navigate to different categories
    category: function (id, options) {
        options.categoryId = id;
        RouterController.root('main-view', options);
        var event;
        switch (id) {
        case 'C0010':
            event = 'MOVESLIGHT';
            break;
        case 'C0020':
            event = 'MOVEPOPULAR';
            break;
        case 'C0020':
            event = 'MOVEWHATSNEW';
            break;
        case 'C0010':
            event = 'MOVETOP';
            break;
        case 'C0020':
            event = 'MOVEGENREALL';
            break;
        case 'C0020':
            event = 'MOVEMYP';
            break;
        default:
            break;
        }
        if (event) {
            Volt.KPIMapper.enterPage(event);
        }
    },

    // Navigate to detail view
    detail: function (id, options) {
        options.productId = id;
        RouterController.detail('tvshow-detail-view', options);
    },

    // Navigate to popups
    popup: function (type) {
        RouterController.popup('popup-' + type + '-view');
    }
});

exports = new Router();

