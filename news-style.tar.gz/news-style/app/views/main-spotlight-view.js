var BaseContentView = Volt.require('app/views/main-base-content-view.js');

MainSpotlightView = BaseContentView.extend({
    // Add whatever you like here
    spotlightId: 'C0010',
    
    getCategoryId:function(){ 
        return this.spotlightId;
    }
});

exports = MainSpotlightView;