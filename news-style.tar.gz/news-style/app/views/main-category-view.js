/**
 * @author Wang Xiaojun(xiaojun.wang@samsung.com)
 * @fileoverview An example of Header View in Games Main View.
 * @date 2014/07/21
 *
 * @version 1.4
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */

// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

    // Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),

    // Include models
    // Main Model
    mainModel = Require('app/models/main-model.js'),

    // Require Common templates of Main View
    MainTemplate = PanelCommon.requireTemplate('main'),

    // Common Constant of GUI
    CommonTemplate = PanelCommon.requireTemplate('common');

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
var MainCategoryView = PanelCommon.BaseView.extend({
    template: MainTemplate.category,
    collection: mainModel.get('category_collection'),

    mediator: null, // Trigger and listento Events
    categoryTabs: null,

    initialize: function (options) {
        // While initializing, this.widget has already been set 

        // Get mediator from MainView
        this.mediator = options.mediator;

        // Listen to category collection in main model to render Category
        this.listenTo(this.collection, 'reset sort', this.render);
        this.listenTo(this.collection, 'change', this.onChange);

        // On Events
        // The third parameter should be added as the caller of the callback
        this.mediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.expand, this);
        this.mediator.on('EVENT_MAIN_CATEGORY_BLUR', this.shrink, this);
    },

    render: function () {
        Volt.log();

        // Create if not created
        if (!this.categoryTabs) {
            this.initCategoryTabs();

            // Delegate events
            this.setWidget(this.widget);
        }
        // Update it
        this.updateCategoryTabs();

        return this;
    },

    events: {
        'NAV_FOCUS': 'onFocus',
//        'NAV_BLUR': 'onBlur'
    },

    onFocus: function (widget) {
        if (widget) {
            this.mediator.trigger('EVENT_MAIN_CATEGORY_FOCUS');

        } else if (widget === undefined) { // Default focus setting by CategoryView's own
            Volt.Nav.focus(this.categoryTabs);
        }
    },

//    onBlur: function (widget) {
//        this.mediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
//    },

    ////////////////////////////////////////////////////////////////////////////
    // Custom Function Begins Here
    ////////////////////////////////////////////////////////////////////////////

    expand: function () {
        Volt.log();
        this.widget.animate('y', CommonTemplate.CATEGORY_Y_EXPAND, CommonTemplate.CATEGORY_ANIM_DURATION);
        this.categoryTabs.animate('height', CommonTemplate.CATEGORY_HEIGHT_EXPAND, CommonTemplate.CATEGORY_ANIM_DURATION);
        
    },

    shrink: function () {
        Volt.log();
        this.widget.animate('y', CommonTemplate.CATEGORY_Y_NORMAL, CommonTemplate.CATEGORY_ANIM_DURATION);
        this.categoryTabs.animate('height', CommonTemplate.CATEGORY_HEIGHT_NORMAL, CommonTemplate.CATEGORY_ANIM_DURATION);
    },

    // This function is used to initialize Category Tabs.
    initCategoryTabs: function () {
        var categoryTabs = PanelCommon.loadTemplate(this.template, null, this.widget);

        //        categoryTabs.setAnimDuration(CommonTemplate.CONTENT_ANIM_DURATION);
        //        // Set Callbacks
        //        categoryTabs.onSelect = function (index) {
        //            var name = mainModel.get('category_collection').at(index).get('name');
        //		    print('main-category-view.js:name : '+ name);
        //            mainModel.selectCategory(index);
        //            Backbone.history.navigate(name,{trigger: true, replace: true});
        //        };

        ////////////////////////////////////////////////////////////////////////////
        // <?#2 Port to Halo Category Tabs ?>
        var tabListener = new CategoryTabListener;
        tabListener.onTabChanged = function (ctab, index) {
            var name = mainModel.get('category_collection').at(index).get('name');
            print('main-category-view.js: name : ' + name);
            mainModel.selectCategory(index);
            Backbone.history.navigate(name, {
                trigger: true,
                replace: true
            });
        };
        categoryTabs.addTabChangedListener(tabListener);

        this.categoryTabs = categoryTabs;
    },

    // This function is used to update content of Category Tabs.
    updateCategoryTabs: function () {
        ////////////////////////////////////////////////////////////////////////////
        // <?#3 Port to Halo Category Tabs ?>
        Volt.log();
        var names,
            i,
            n = this.categoryTabs.numberOfTab();

        for (i = n - 1; i >= 0; i--) {
            this.categoryTabs.removeTab(i);
        }
        
        names = this.collection.pluck('name');
        
        n = names.length;
        for (i = 0; i < n; i++) {
            this.categoryTabs.addTab(names[i]);
        }

        //        this.categoryTabs.setCategories(this.collection.pluck('name'));
        //        this.categoryTabs.setSelectIndex(0);
    },

    // When some category changed
    onChange: function (model) {
        /*
        var index = this.collection.indexOf(model);
        if (index != undefined) {
            var category = model.get('name');
            this.categoryTabs.removeCategory(index);
            this.categoryTabs.addCategory(category, index);
        }
*/
    },
});

exports = MainCategoryView;