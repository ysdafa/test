// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

// Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    loadTemplate = PanelCommon.loadTemplate,
	_ = Volt.require("modules/underscore.js")._,
    GamesMainTemplate = Require('app/templates/1080/games-main-template.js'),

    Nav = Volt.Nav;

var SingleLinelistView = PanelCommon.BaseView.extend({
	singlelineParam : null,
	parent: null,

	initialize : function(singlelineParam,parent) {

		this.singlelineParam = singlelineParam;
		this.parent = parent;
	},

/*
	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur'
	},
*/
	render : function() {
	
		this.initList = _.bind(__initList, this);
		
		var singleLinelist = this.initList(this.singlelineParam, this.parent);
		print("~~~~~~~~~~~~~~singleLinelist-list-view.    singleLinelist is  " + singleLinelist);
		this.setWidget(singleLinelist);

		return this;
	},

});




var getRenderer = function(singleList,parentWidth, parentHeight, data) {

	print("~~~~~~~~~~~~~~render root parent w  h " + parentWidth + "  :" + parentHeight);
	var renderer = new Renderer(parentWidth, parentHeight);
	
	renderer.root = new Widget({
		x : 0,
		y : 0,
		width : parentWidth,
		height : parentHeight,
		parent : scene,

	});

	renderer.root.show();

	singleList.initRenderer(renderer,data,parentWidth, parentHeight);

	
	renderer.onDraw = function(rendererInstance,drawTypeString, data, parentWidth, parentHeight) {
		if (!data) {
			return;
		}

		if ("LoadData" == drawTypeString) {
			
			//response the callback onDrawLoadData to draw on listitem
			singleList.onDrawLoadData(rendererInstance,data, parentWidth, parentHeight);
			print("~~~~~~~~~~~~~~renderer.onDraw     LoadData       " );

		}
		else if("UpdateData" == drawTypeString)
        {
			//response the callback onDrawUpdateData to update on listitem
			singleList.onDrawUpdateData(rendererInstance.root,data,parentWidth,parentHeight);
			print("~~~~~~~~~~~~~~renderer.onDraw     UpdateData       " );
        }
		else if("FromItemFocusChangeAniStart" == drawTypeString)
        {
            //The from item of focus change motion start
			singleList.onDrawFromFocusChangeStart(rendererInstance.root,data,parentWidth,parentHeight);
			//print("~~~~~~~~~~~~~~renderer.onDraw     FromItemFocusChangeAniStart       " );
        }
        else if("ToItemFocusChangeAniEnd" == drawTypeString)
        {
            //The to item of focus change motion end
			singleList.onDrawToFocusChangeEnd(rendererInstance.root,data,parentWidth,parentHeight);
			//print("~~~~~~~~~~~~~~renderer.onDraw     ToItemFocusChangeAniEnd       " );
        }
	};

	renderer.onResize = function(rendererInstance,data, destWidth, destHeight, flagWithAni, duration) {
		if ("withAni" == flagWithAni) {
		} else if ("noAni" == flagWithAni) {
		}

	};

	renderer.onUpdate = function(width, height) {

	};

	renderer.onRelease = function() {
		print("~~~~~~~~~~~~~~render onRelease " + renderer.root.getChildCount());

		renderer.root.destroy();
		delete renderer;
	};

	return renderer;
};


var itemClicked = function(singleLineList, itemIndex) {

		var index = itemIndex;	

        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   index    ' + index);
		
		//response the callback onItemMouseClick to mouse click on listitem
	    singleLineList.onItemMouseClick(index);

};



var __initList = function(param, parent) {
    var handleEvent = false;    //add by lihao.zha@20140909, fix messagebox omit key release to grid list
	//create gridlist refer to param
	var singleList = loadTemplate(param, null, parent, false);

	/********************set render and listener of gridlistcontrol begin**************************/
	//api from native element
	var rendererProvider = new RendererProvider;
					

	rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data) {
		return getRenderer(singleList,parentWidth, parentHeight, data);
	};

	singleList.setRendererProvider(rendererProvider);
	/********************set render and listener of gridlistcontrol end**************************/

	var singleLineListener = new SingleLineListControlListener;

	singleLineListener.onItemClicked = itemClicked;

	singleList.addListListener(singleLineListener);

	

	/*******************set call back api from common-module begin******************/
	//callback to draw list item
	singleList.onDrawLoadData = function(render,data, parentWidth, parentHeight){};
	//callback to response "enter" key press
	singleList.onItemPress = function(index){};
	//callback to response update list item
	singleList.onDrawUpdateData = function(widget,data, parentWidth, parentHeight){};
	//callback to response focus change start( from item)
	singleList.onDrawFromFocusChangeStart = function(widget,data, parentWidth, parentHeight){};
	//callback to response focus change start( to item)
	singleList.onDrawToFocusChangeEnd = function(widget,data, parentWidth, parentHeight){};
	//callback to response mouse click
	singleList.onItemMouseClick = function(index){};
	singleList.initRenderer= function(renderer,data,parentWidth, parentHeight){};


	/*******************set call back api from common-module  end ******************/

	
	/*******************set onkeyevent process begin******************/
	this.onKeyEvent = function (keycode, keytype) {
		var ret = false;
		
		if (keytype == Volt.EVENT_KEY_RELEASE) {
            
			return ret;
		}		
		
    	switch(keycode) {
			case Volt.KEY_JOYSTICK_UP:
				ret =  singleList.moveFocus("Up");
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				ret =  singleList.moveFocus("Down");
				break;	
			case Volt.KEY_JOYSTICK_LEFT:
				ret =  singleList.moveFocus("Left");
				break;	
			case Volt.KEY_JOYSTICK_RIGHT:
				ret =  singleList.moveFocus("Right");
				break;	
			case Volt.KEY_JOYSTICK_OK:{
				
				//response the callback onItemPress to key press on listitem
				var index = singleList.focusItemIndex;
	        	print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   singleList.focusItemIndex    ' + singleList.focusItemIndex);
				if ( index == undefined){
					index = 0;
				}
			    singleList.onItemPress(index);
			    ret = true;
			}
			break;

			default:
			// to do
			break;
		}
		return ret;
	}

	singleList.onKeyEvent =  this.onKeyEvent.bind(this);
	/*******************set onkeyevent process end******************/

	singleList.setScrollBar = function(x,y,scrollwidth){

		var scroll = new Scroll({
		    parent: scene,
		    width: scrollwidth*0.004630,
		    height: scrollwidth,
		    direction: "vertical"
		});


		//var param = GamesMainTemplate.scrollbar;
		//param.width = width;
		//param.height =  width*0.004630;

		
		//var scroll = loadTemplate(param, null, null);
		
		print(' ***********loadTemplate********singleList.setScrollBar********  ');
		scroll.setPosition(x, y);
		scroll.setBackgroundColor(220, 220, 220, 51);
		scroll.setTrackShadowColor(0, 0, 0, 51);
		scroll.setTrackShadowHeight(scrollwidth*0.000926);

		scroll.setPointingNormalThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pn.png"));
		scroll.setPointingNormalThumbSize(scrollwidth*0.018750, scrollwidth*0.004630);

		scroll.setPointingOverThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_po.png"));
		scroll.setPointingOverThumbSize(scrollwidth*0.020833, scrollwidth*0.019444);

		scroll.setPointingFocusThumbImage(Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pf.png"));
		scroll.setPointingFocusThumbSize(scrollwidth*0.025521, scrollwidth*0.026852);

		scroll.setMinValue(0);
		scroll.setMaxValue(100);
		scroll.setValue(0);

		scroll.setRolloverTrackHeight(scrollwidth*0.019444);
		scroll.show();



		singleList.attachScrollBar(scroll);

	}

	singleList.show();

	print("~~~~~~~~~~~~~~~~~~~~~~~~ init singlelinelist ");
	return singleList;
};




exports = SingleLinelistView;



