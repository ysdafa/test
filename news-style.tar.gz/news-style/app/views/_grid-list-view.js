// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

// Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    loadTemplate = PanelCommon.loadTemplate,
	_ = Volt.require("modules/underscore.js")._,
    GamesMainTemplate = Require('app/templates/1080/games-main-template.js'),

    Nav = Volt.Nav;

var GridlistView = PanelCommon.BaseView.extend({
	gridParam : null,
	parent: null,

	initialize : function(gridParam,parent) {

		this.gridParam = gridParam;
		this.parent = parent;
	},

/*
	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur'
	},
*/
	render : function() {
	
		this.initGrid = _.bind(__initGrid, this);
		
		var gridlist = this.initGrid(this.gridParam, this.parent);
		print("~~~~~~~~~~~~~~grid-list-view.js~~~~~~~~~~grilist is  " + gridlist);
		this.setWidget(gridlist);

		return this;
	},

/*
	onFocus : function(widget) {
		print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  focus  widget   ",widget);
		widget.enableFocus();
		widget.setFocus();
		widget.showFocus("true");
	},
	onBlur : function(widget) {
		print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  blur  widget      ",widget);
		widget.hideFocus("true");
	}
*/
});


var itemLoaded = function(gridList, groupIndex, itemIndex) {
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  itemloaded     ",itemIndex);
};

var itemUnloaded = function(gridList, groupIndex, itemIndex) {
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  itemUnloaded    ",itemIndex);
};

var asyncItemLoad = function(gridList, groupIndex, itemIndex) {
	//print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  async");
};

var focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {

	//print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  focusChange");
};

var focusChangeStart = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
	//print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  focuschangestart");
};

var moveOut = function(gridList, directionString, fromGroupIndex, fromItemIndex) {
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  directionString  "+directionString);
	if ("Up" == directionString) {
	} else if ("Down" == directionString) {
	} else if ("Left" == directionString) {
	} else if ("Right" == directionString) {
	}
};

var itemIndexChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
	print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gridlist  directionString  "+directionString);
};

var itemClicked = function(gridList, groupIndex, itemIndex) {

		var focusItem = gridList.getFocusItemIndex();
		var index = focusItem .itemIndex;	
		var groupindex = focusItem.groupIndex;

        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   index    ' + index);
		
		//response the callback onItemMouseClick to mouse click on listitem
	    gridList.onItemMouseClick(groupindex,index);

};

var enterKeyLongPressed = function(gridList, groupIndex, itemIndex) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   enterKeyLongPressed    ');
		var renderer = gridList.renderer(groupIndex, itemIndex);
		print('  Renderer.root   is    ',renderer.root);
		print('  Renderer.root.getChildCount()   is    ',renderer.root.getChildCount() );
		gridList.onLongPressed(groupIndex, itemIndex,renderer.root);
		gridList.longpress = true;
};



var getRenderer = function(gridlist,parentWidth, parentHeight, data) {

	print("~~~~~~~~~~~~~~render root parent w  h " + parentWidth + "  :" + parentHeight);
	var renderer = new Renderer(parentWidth, parentHeight);

	///*
	renderer.root = new Widget({
		x : 0,
		y : 0,
		width : parentWidth,
		height : parentHeight,
		parent : scene,

	});

	renderer.root.show();

	gridlist.initRenderer(renderer,data,parentWidth, parentHeight);
	
	renderer.onDraw = function(rendererInstance,drawTypeString, data, parentWidth, parentHeight) {
		if (!data) {
			return;
		}

		if ("LoadData" == drawTypeString) {
			
			//response the callback onDrawLoadData to draw on listitem
			gridlist.onDrawLoadData(rendererInstance,data, parentWidth, parentHeight);
			
		}
		else if("UpdateData" == drawTypeString)
        {
			//response the callback onDrawUpdateData to update on listitem
			gridlist.onDrawUpdateData(rendererInstance.root,data,parentWidth,parentHeight);
			print("~~~~~~~~~~~~~~renderer.onDraw     UpdateData       " );
        }
		else if("FromItemFocusChangeAniStart" == drawTypeString)
        {
            //The from item of focus change motion start
			gridlist.onDrawFromFocusChangeStart(rendererInstance.root,data,parentWidth,parentHeight);
			//print("~~~~~~~~~~~~~~renderer.onDraw     FromItemFocusChangeAniStart       " );
        }
        else if("ToItemFocusChangeAniEnd" == drawTypeString)
        {
            //The to item of focus change motion end
			gridlist.onDrawToFocusChangeEnd(rendererInstance.root,data,parentWidth,parentHeight);
			//print("~~~~~~~~~~~~~~renderer.onDraw     ToItemFocusChangeAniEnd       " );
        }
	};

	renderer.onResize = function(rendererInstance,data, destWidth, destHeight, flagWithAni, duration) {
		if ("withAni" == flagWithAni) {
		} else if ("noAni" == flagWithAni) {
		}

	};

	renderer.onUpdate = function(width, height) {

	};

	 renderer.onRelease = function () {
		print("~~~~~~~~~~~~~~renderer.onRelease     onRelease    renderer.thumbnail    ",renderer.thumbnail );
		
        
        renderer.thumbnail.destroy();
		renderer.root.destroy();
        delete renderer;

		print("~~~~~~~~~~~~~~renderer.onRelease     ToItemFocusChangeAniEnd       " );
    };


	return renderer;
};






var __initGrid = function(param, parent) {
    var handleEvent = false;    //add by lihao.zha@20140909, fix messagebox omit key release to grid list
	//create gridlist refer to param
	var gridlist = loadTemplate(param, null, parent, false);

	/********************set render and listener of gridlistcontrol begin**************************/
	//api from native element
	var rendererProvider = new RendererProvider;
	var gridListener = new GridListControlListener;

	gridListener.onItemLoaded = itemLoaded;
	gridListener.onItemUnloaded = itemUnloaded;
	gridListener.onAsyncItemLoad = asyncItemLoad;
	gridListener.onFocusChanged = focusChanged;
	gridListener.onFocusChangeStart = focusChangeStart;
	gridListener.onMoveOut = moveOut;
	gridListener.onItemIndexChanged = itemIndexChanged;
	gridListener.onItemClicked = itemClicked;
	gridListener.onEnterKeyLongPressed = enterKeyLongPressed;
					

	rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data) {
		return getRenderer(gridlist,parentWidth, parentHeight, data);
	};

	gridlist.setRendererProvider(rendererProvider);
	gridlist.addListListener(gridListener);
	/********************set render and listener of gridlistcontrol end**************************/

	

	/*******************set call back api from common-module begin******************/
	//callback to draw list item
	gridlist.onDrawLoadData = function(rendererInstance,data, parentWidth, parentHeight){};
	//callback to response "enter" key press
	gridlist.onItemPress = function(groupIndex,index){};
	//callback to response mouse click
	gridlist.onItemMouseClick = function(groupIndex,index){};
	//callback to response update list item
	gridlist.onDrawUpdateData = function(widget,data, parentWidth, parentHeight){};
	//callback to response update list item
	gridlist.onLongPressed = function(groupIndex, itemIndex,widget){};
	//callback to response focus change start( from item)
	gridlist.onDrawFromFocusChangeStart = function(widget,data, parentWidth, parentHeight){};
	//callback to response focus change start( to item)
	gridlist.onDrawToFocusChangeEnd = function(widget,data, parentWidth, parentHeight){};
	//initiailize renderer
	gridlist.initRenderer = function(renderer,data, parentWidth, parentHeight){};
	/*******************set call back api from common-module  end ******************/

	
	/*******************set onkeyevent process begin******************/
	this.onKeyEvent = function (keycode, keytype) {
		var ret = false;
        //add by lihao.zha@20140909, fix messagebox omit key release to grid list
        if(keytype == Volt.EVENT_KEY_PRESS){
            handleEvent = true;
        }
		if (keytype == Volt.EVENT_KEY_RELEASE) {
            if(handleEvent === false){
                Volt.log("omitted key release event, do not process");
                return;
            }
            handleEvent = false;
			if ( Volt.KEY_JOYSTICK_OK == keycode && gridlist.longpress == false){
				var focusItem = gridlist.getFocusItemIndex();
				var index = focusItem .itemIndex;	
				var groupindex = focusItem.groupIndex;
			
	        	print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   KEY_JOYSTICK_OK    index    ' + index);
				
				//response the callback onItemPress to key press on listitem
			    gridlist.onItemPress(groupindex,index);
			    ret = true;
			}
        	print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   gridlist.longpress   ' + gridlist.longpress);
			gridlist.longpress = false;
			return ret;
		}		
		
    	switch(keycode) {
			case Volt.KEY_JOYSTICK_UP:
				ret =  gridlist.moveFocus("Up");
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				ret =  gridlist.moveFocus("Down");
				break;	
			case Volt.KEY_JOYSTICK_LEFT:
				ret =  gridlist.moveFocus("Left");
				break;	
			case Volt.KEY_JOYSTICK_RIGHT:
				ret =  gridlist.moveFocus("Right");
				break;	

			default:
			// to do
			break;
		}
		return ret;
	}

	gridlist.onKeyEvent =  this.onKeyEvent.bind(this);
	/*******************set onkeyevent process end******************/


	gridlist.setScrollBar = function(template){

		//use template way to new and set attributes
		var scroll = loadTemplate(template, null, null);
		scroll.show();

		gridlist.attachScrollBar(scroll);

	}

	//flag to judge long press
	gridlist.longpress = false;

	gridlist.show();

	print("~~~~~~~~~~~~~~~~~~~~~~~~ init grid ");
	return gridlist;
};




exports = GridlistView;



