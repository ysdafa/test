var BaseContentView = Volt.require('app/views/main-base-content-view.js');

MainGrossingView = BaseContentView.extend({
    // Add whatever you like here
    grossingId: 'C0020',
    
    getCategoryId:function(){ 
        return this.grossingId;
    }
});

exports = MainGrossingView;
