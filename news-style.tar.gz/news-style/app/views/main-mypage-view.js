var BaseContentView = Volt.require('app/views/main-base-content-view.js');

MainMyPageView = BaseContentView.extend({
    // Add whatever you like here
    myPageId: 'C0020',
    
    getCategoryId:function(){ 
        return this.myPageId;
    }
});

exports = MainMyPageView;
