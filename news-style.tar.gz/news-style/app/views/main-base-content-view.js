/**
 * @author Wang Xiaojun(xiaojun.wang@samsung.com)
 * @fileoverview An example of Header View in Games Main View.
 * @date 2014/07/03
 *
 * @version 1.4
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */
// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

    // Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    loadTemplate = PanelCommon.loadTemplate,
    MainTemplate = PanelCommon.requireTemplate('main'),
    Nav = Volt.Nav,
    //    Gridlist = Require('app/views/grid-list-view.js'),

    // Include models
    // Main Model
    mainModel = Require('app/models/main-model.js'),

    // Require Specific template for Games Main View
    GamesMainTemplate = Require('app/templates/1080/games-main-template.js');

////////////////////////////////////////////////////////////////////////////////
// Global Content View Switch Animation, Define the grid switching animation
//var animContentSwitch = new Animation(PanelCommon.CONTENT_ANIM_DURATION);
//animContentSwitch.addKey(1, 'x', 0);
//animContentSwitch.addKey(1, 'opacity', 255);

////////////////////////////////////////////////////////////////////////////////
var MainBaseContentView = PanelCommon.BaseView.extend({
    //template: GamesMainTemplate.content,
    //mediator: null,     // Trigger and listento Events
    parent: null, // MainView

    categoryId: null, // Every Base Content View Should has a Category Id
    grid: null, // GridListControl

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    //initialize: function (options) {},
    render: function (parent) {
        Volt.log();

        this.parent = parent;

        // Widget of this View is content container. Don't change widget to grid
        this.widget = parent.widget.getChild('main-content-container');

        this.categoryId = this.getCategoryId();

        if (!mainModel.isContentCollectionReady()) {
            Volt.log();
            this.listenTo(mainModel.get('content_collection'), 'reset', this.renderContent);
            return this;
        } else {
            this.renderContent();
        }
        return this;
    },

    renderContent: function () {
        Volt.log();

        // After first time render. stop rendering
        this.stopListening(mainModel.get('content_collection'), 'reset');

        // Create a new gridlistcontrol Everytime
        this.grid = __initGrid(this.categoryId, this.widget);

        // bind mediator to grid
        this.grid.mediator = this.parent.mediator;
        // Set as top Widget
        this.widget.addChild(this.grid);

        // Delegate events
        this.setWidget(this.widget);

        // Update Grid Data
        __updateGrid(this.grid);

		//setfocusimage should be called after data load
		this.grid.setFocusImage(Volt.getRemoteUrl("images/1080/common/focus_grid.png"), 0, 0);

        
//        this.widget.show();
    },
    remove: function () {
        Volt.log();
        if (this.grid) {
            this.widget.removeChild(this.grid);
            this.grid.destroy();
            this.grid = null;
        }
    },

    onFocus: function (widget) {
        Volt.log();
        if (widget) {
		    widget.showFocus("false");
        }

        ////////////////////////////////////////////////////////////////////////////
        // <?#4 Port to Halo Category Tabs ?>
        this.parent.mediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
    },

    onBlur: function (widget) {
        Volt.log();
        if (widget) {
            widget.hideFocus("true");
        }
    },

    show: function () {
        Volt.log();
        if (this.grid) {
            this.grid.show();
            this.grid.custom.focusable = true;
            //Volt.Nav.reload();

            Volt.Nav.addItem(this.grid);

            var options = this.parent.options;

            if (options) {
                //focus on content view
                Volt.log('parentWidget.options.focusPosition is ' + options.focusPosition);

                if (MainTemplate.FOCUS_POSITION_CONTENT == options.focusPosition) {
                    Volt.Nav.focus(this.grid);
                    this.parent.options = null;
                }
            }
        }
    },

    hide: function () {
        Volt.log('Hide!');
        if (this.grid) {
            this.grid.hide();
            this.grid.custom.focusable = false;

            // Use remove Item instead of reload()
            //Volt.Nav.reload();
            Volt.Nav.removeItem(this.grid);
        }
    },

    getWidget: function () {
        return this.grid;
    }
});


function __initGrid(categoryId, parent) {
    print('@@@@@@@@[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] @@@@@@@@@@@@');

    var template = GamesMainTemplate.contentGenrealGrid;
    if (categoryId == 'C0010') {
        template = GamesMainTemplate.contentSpotlightGrid;
    }
    //template.focusable = true;
    //    print('   Gridlist  is    ', Gridlist);

    //	var gridView = new Gridlist(template,parent).render();
    //	var grid;
    //
    //	
    //	grid = gridView.widget;

    var grid = loadTemplate(template, null, parent);


    //****************************set list's layout begin********************************//

    grid.addGroup(1);
    grid.addStyle(1);
    grid.addDataGroup(1);


    if (categoryId == 'C0010') {

        for (var i = 0; i < 11; i++) {
            if (0 == i % 4) {
                grid.addColumn({
                    groupIndex: 0,
                    styleIndex: 0,
                    columnWidth: 648
                });
            } else {
                grid.addColumn({
                    groupIndex: 0,
                    styleIndex: 0,
                    columnWidth: 324
                });
            }
        }

        for (i = 0; i < 2; i++) {
            grid.addRowToAllColumn({
                groupIndex: 0,
                styleIndex: 0,
                rowHeight: 324 + 84
            });
        }


        grid.mergeCells({
            groupIndex: 0,
            styleIndex: 0,
            startRow: 0,
            startCol: 0,
            endRow: 1,
            endCol: 0
        });
        grid.mergeCells({
            groupIndex: 0,
            styleIndex: 0,
            startRow: 0,
            startCol: 4,
            endRow: 1,
            endCol: 4
        });
        grid.mergeCells({
            groupIndex: 0,
            styleIndex: 0,
            startRow: 0,
            startCol: 8,
            endRow: 1,
            endCol: 8
        });


        grid.attachGroupTitle(0, loadTemplate(GamesMainTemplate.spotlightTitlebar, null, grid));

		//create scrollbar attach to list
        var scroll = loadTemplate(GamesMainTemplate.scrollbar1, null, null);
        scroll.show();
        grid.attachScrollBar(scroll);

    } else {

        for (var i = 0; i < 5; i++) {
            if (0 == i) {
                grid.addColumn({
                    groupIndex: 0,
                    styleIndex: 0,
                    columnWidth: 648
                });
            } else {
                grid.addColumn({
                    groupIndex: 0,
                    styleIndex: 0,
                    columnWidth: 324
                });
            }
        }

        for (i = 0; i < 2; i++) {
            grid.addRowToAllColumn({
                groupIndex: 0,
                styleIndex: 0,
                rowHeight: 324 + 108
            });
        }

        grid.mergeCells({
            groupIndex: 0,
            styleIndex: 0,
            startRow: 0,
            startCol: 0,
            endRow: 1,
            endCol: 0
        });

		
		//create scrollbar attach to list
        var scroll = loadTemplate(GamesMainTemplate.scrollbar2, null, null);
        scroll.show();
        grid.attachScrollBar(scroll);
		

    }

    grid.enlargeFocusItem(20, 20);
    grid.editFlag = true; //drag and drop mode
    grid.shadowEffectFlag = false;
	grid.show();

    //****************************set list's layout end********************************//


    grid.initRenderer = function (renderer, data, parentWidth, parentHeight) {

        print(' initRenderer    renderer  is    ', renderer);

        if (parentHeight == 432) { // General Small Item
            loadTemplate(GamesMainTemplate.generalSmallItem, null, renderer.root);
            renderer.thumbnail = renderer.root.getChild(0);

        } else if (parentHeight == 864) { // General Large Item
            loadTemplate(GamesMainTemplate.generalLargeItem, null, renderer.root);
            renderer.thumbnail = renderer.root.getChild(0);
        } else if (parentHeight == 408) { // Spotlight Small Item
            loadTemplate(GamesMainTemplate.spotlightSmallItem, null, renderer.root);
            renderer.thumbnail = renderer.root.getChild(0);

        } else if (parentHeight == 816) { // Spotlight Large Item
            loadTemplate(GamesMainTemplate.spotlightLargeItem, null, renderer.root);
            renderer.thumbnail = renderer.root.getChild(0);
        }

    };



    //****************************set callback of Gridlist begin********************************//
    grid.onDrawLoadData = function (render, data, parentWidth, parentHeight) {

        //print('  data  is    ',data);
        var mustache = {
            imgUrl: data.imgUrl,
            title: data.title,
        };

        render.thumbnail.setInformationText("text1", data.title);
        render.thumbnail.setContentImage(data.imgUrl);

    }

    grid.onItemPress = function (groupindex, index) {
        Volt.log('index: ' + index);

        if (index >= 0) {
            var collection = mainModel.get('content_collection');
            var model = collection.models[index % collection.length];

            Backbone.history.navigate('detail/' + model.get('sourceid'), {
                trigger: true,
                focusPosition: 0,
                focusIndex: 0
            });



        } else {
            Volt.log('Error: Invalid Index!');
        }
    }

    grid.onItemMouseClick = function (groupindex, index) {
        Volt.log('index: ' + index);

        if (index >= 0) {
            var collection = mainModel.get('content_collection');
            var model = collection.models[index % collection.length];

            Backbone.history.navigate('detail/' + model.get('sourceid'), {
                trigger: true,
                focusPosition: 0,
                focusIndex: 0
            });
        } else {
            Volt.log('Erro: Invalid Index!');
        }


        /*****************update special item   test example***********************
		var data = this.getData(groupindex, index);
		data.title = '************';
		this.updateItem(groupindex, index);



		/*********************update all item  test example************************/
        /*
	    var contentCollection = mainModel.get('content_collection');
		for (i = 0; i < contentCollection.length; i++){
			var data = this.getData(groupindex, i);		
			data.title =  '************';
		}
		this.updateAllItems(groupindex);
		*/


        /*
		/***************add data  test example******************
	    var contentCollection = mainModel.get('content_collection');
		var columnCount = this.columnCount(0,0);
		this.addColumn({groupIndex: 0, styleIndex: 0, columnWidth: 648});
		this.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex: columnCount, rowHeight: 816});

		var data = new Data();
		
	    var model = contentCollection.at((0 + grid.rnd)%contentCollection.length);
		
		data.imgUrl = model.get('imgUrl');
		data.title =  model.get('title');
		
		//this.list.push(data);
		
		this.addData({groupIndex:0, data:data});

		this.loadData();
*/

    }

    grid.onDrawUpdateData = function (widget, data, parentWidth, parentHeight) {
        print("  onDrawUpdateData update process!!!!!  widget    ", widget);
    }

    grid.onLongPressed = function (groupIndex, itemIndex, widget) {
        print('  onLongPressed groupIndex    ' + groupIndex + '  itemIndex   ' + itemIndex);
        var rect = {
            x: widget.getAbsolutePosition().x,
            y: widget.getAbsolutePosition().y,
            width: widget.width,
            height: widget.height,
        }
        this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', 'LONG_PRESS_MENU', rect);
    }


    //****************************set callback of Gridlist end********************************//


    return grid;
}



function __updateGrid(grid) {
    var contentCollection = mainModel.get('content_collection');

    grid.rnd = Math.floor(Math.random() * contentCollection.length);

    //load data	
    for (i = 0; i < contentCollection.length; i++) {
        var data = new Data();

        var model = contentCollection.at((i + grid.rnd) % contentCollection.length);

        data.imgUrl = model.get('imgUrl');
        data.title = model.get('title');

        grid.addData({
            groupIndex: 0,
            data: data
        });
    }

    grid.loadData();
}




exports = MainBaseContentView;









/*
        //Don't let the graphics thread run any animations
        Volt.pauseGraphics();

        if (widget) {
            var view = this;
            widget.animate(this.anim, function() {
                //var contentView = this.Mediator.contentView;
                var container = view.container;
                if (container.getChildCount() > 1) {
                    container.removeChild(0);
                }

                view.setWidget(widget);
                Nav.reload();

                if(view.focusFlag)//first set content view focus
                {
                    Nav.focus(widget);
                    view.focusFlag = false;
                }

                Nav.unblock();
            });
        }
*/

/*
    hide: function() {
        var oldWidget = this.widget;
        if (oldWidget && !PanelCommon.isBaseWidget(oldWidget)) {
            oldWidget.animate('opacity', 0, PanelCommon.CONTENT_ANIM_DURATION, function() {
                oldWidget.releaseList();
            });
        }
    },
*/

/*
    setFocusFlag: function(focusFlag) {
         this.focusFlag = focusFlag;
    },
*/

/*
    var contentCollection = mainModel.get('content_collection');
		for (i = 0; i < contentCollection.length; i++){
			
			var data = grid.getData(groupindex, i);
			//data.imgUrl = model.get('imgUrl');
			data.title =  '*********************';		
		}

		grid.loadData();
		grid.updateAllItems(groupindex);

*/