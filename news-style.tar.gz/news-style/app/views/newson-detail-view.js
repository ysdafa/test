// Include libraries
var Require = Volt.require,
    Q = Require('modules/q.js'),

    Backbone = Require('lib/volt-backbone.js'),

    // Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    Nav = Volt.Nav,
    loadTemplate = PanelCommon.loadTemplate,
    // Include models
    newsCollection = Require('app/models/home-news-collection.js'),

    // Require Common templates of Main View
    NewsOnDetailCommonTemplate = PanelCommon.requireTemplate('newson-detail'),
    //Singlelist = Require('app/views/singleline-list-view.js'),


    // Include example templates(should implement by apps panel member)
    DetailThumbTemplate = Require("app/templates/1080/newson-detail-thumb-template.js"),
    DetailTextTemplate = Require("app/templates/1080/newson-detail-text-template.js");



/** NewsDetailView -BackboneView
 * @class
 * @name NewsDetailView
 * @augments Backbone.View
 */
var NewsDetailView = PanelCommon.BaseView.extend({
    //template of newson detail view
    template: NewsOnDetailCommonTemplate.container,
    relatedview: null,
    titleview: null,
    contentview: null,


    /** Initialize NewsDetailView.
     * @function initialize
     * @memberof NewsDetailView
     */
    initialize: function () {},


    /** Render NewsDetailView
     * @function Render
     * @param {Object}  viewInfo                  - information of view,include productid,focusposition,focusindex
     * @param {String}  animationType          - tpe string of animation
     * @memberof NewsDetailView
     * @method
     */
    render: function (options) {
        Volt.log('productId is ' + options.productId);
        Volt.log('focusPosition is ' + options.focusPosition);
        Volt.log('focusIndex is ' + options.focusIndex);
        
        this.model = newsCollection.get(options.productId);

        this.setWidget(loadTemplate(this.template, null, null, false)); //load newson detail view(include titile-area,content-area and related area)

        // Listen to model,when data change,update list
        this.listenTo(newsCollection, 'reset change', this.updateRelated);

        this.renderTitle(); //render newson title area
    },

    /** show NewsDetailView
     * @function show
     * @param {Object}  viewInfo                  - information of view,include productid,focusposition,focusindex
     * @param {String}  animationType          - tpe string of animation
     * @memberof NewsDetailView
     * @method
     * @return {Object} Return the deferred.promise used for checking if animation is done
     */
    show: function (options, animationType) {
        Volt.log('productId is ' + options.productId);
//        Volt.log('focusPosition is ' + options.focusPosition);
//        Volt.log('focusIndex is ' + options.focusIndex);

        this.model = newsCollection.get(options.productId);

        this.updateTitle(); //update newson title area
        this.renderContent(); //render newson content area(inlcude thumbnail,fullarticall,)

        //render related area(create list and render list)
        this.renderRelated();
        this.updateRelated();

        //call Volt.Nav.setRoot, for reset the root when coming back to this view.
        Volt.Nav.setRoot(this.widget);

        // Update ID
        var cache = Backbone.history.getCache();
        (options.focusIndex == undefined && cache) ? options.focusIndex = cache.focusIndex : options.focusIndex = 0;

        Volt.log('focusIndex is ' + options.focusIndex);

        if (this.relatedview.widget) {
            this.relatedview.widget.focusItemIndex = options.focusIndex;
            this.relatedview.widget.setFocus();
        }


        //deferred.resolve();
        return PanelCommon.doViewSwitchAni(this.widget, animationType);
    },
    /** update of NewsDetailView
     * @function update
     * @memberof NewsDetailView
     * @method
     */
    update: function (options, animationHideType, animationShowType) {
        print('newson-detail-view.js : update');
        var self = this;
        this.hide(options, animationHideType)
            .then(function () {
                print('newson-detail-view.js : show');
                self.show(options, animationShowType);
            });
    },
    /** render title of NewsDetailView
     * @function renderTitle
     * @memberof NewsDetailView
     * @method
     */
    renderTitle: function () {
        Volt.log();
        var container = this.widget.getDescendant('detail-title-area');
        this.titleview = new TitleView(this.model).render(container);
        container.addChild(this.titleview.widget);
    },

    /** update title of NewsDetailView
     * @function updateTitle
     * @memberof NewsDetailView
     * @method
     */
    updateTitle: function () {
        this.titleview.widget.getChild('title-headline').text = this.model.get('headline');

        this.titleview.show();
    },

    /** render content area of NewsDetailView
     * @function renderContent
     * @memberof NewsDetailView
     * @method
     */
    renderContent: function () {
        Volt.log();
        var container = this.widget.getDescendant('detail-content-area');
        this.contentview = new ContentView(this.model).render(container);
        container.addChild(this.contentview.widget);
    },

    /** render related list  area of NewsDetailView
     * @function renderRelated
     * @memberof NewsDetailView
     * @method
     */
    renderRelated: function () {
        var container = this.widget.getDescendant('detail-relate-area');
        Volt.log();
        this.relatedview = new RelatedItemView().render(container);
        container.addChild(this.relatedview.widget, 0);

    },



    /** update related list  area of NewsDetailView,just load list item data
     * @function updateRelated
     * @memberof NewsDetailView
     * @method
     */
    updateRelated: function () {
        Volt.log();
        this.relatedview.update();
    },

    /** hide NewsDetailView
     * @function hide
     * @param {Number} animationType Animation type
     * @memberof NewsDetailView
     * @method
     * @return {Object} Return the deferred.promise used for checking if hide is done
     */
    hide: function (options, animationType) {
        Volt.log();
        var deferred = Q.defer();
        var contentview = this.contentview;
        var titleview = this.titleview;
        var relatedView = this.relatedview;

        //deferred.resolve();
        var retDef = PanelCommon.doViewSwitchAni(this.widget, animationType);
        retDef.then(function () {
            //add further action when switch view ani finished here
            contentview.hide();
            titleview.hide();
            relatedView.destroy();
            deferred.resolve();
        });
        return deferred.promise;
    },

    /** destroy NewsDetailView
     * @function destroy
     * @param {Widget}  widget          - the root widget of this view
     * @memberof NewsDetailView
     * @method
     */
    //not use now
    /*
	destroy : function(widget){
		if(!widget) return;
		var nChildLength = widget.getChildCount();
		if(nChildLength > 0)
		{
			for(var i = 0; i < nChildLength; i++)
			{
				this.destroy(widget.getChild(i));
			}
		}
		widget.destroy();
		widget = null;
	},
*/
    onKeyEvent: function (keyCode, keyType) {
        Volt.log('onKeyEvent invoked in View: keyCode: ' + keyCode);
        return false;
    },
});


/** TitleView -BackboneView
 * @class
 * @name TitleView
 * @augments Backbone.View
 */
var TitleView = PanelCommon.BaseView.extend({
        template: NewsOnDetailCommonTemplate.TitleArea,

        /** Initialize TitleView.
         * @function initialize
         * @param {Model}  model          - model data of this detail news
         * @memberof TitleView
         */
        initialize: function (model) {
            this.model = model;
        },

        /** render TitleView.
         * @function render
         * @param {Widget}  parent          - the parent widget of this view
         * @memberof TitleView
         */
        render: function (parent) {
            Volt.log();

            //create UI and set data from server
            this.setWidget(loadTemplate(this.template, {
                headline: this.model.get('headline')
            }, null, parent));

            return this;

        },

        /** show TitleView.
         * @function show
         * @memberof TitleView
         */
        show: function () {
            this.widget.show();
        },

        /** hide TitleView.
         * @function hide
         * @memberof TitleView
         * @return {Object} Return the deferred.promise used for checking if hide is done
         */
        hide: function () {
            Volt.log();
            var deferred = Q.defer();

            this.widget.hide();
            //this.destroy(this.widget);
            deferred.resolve();

            return deferred.promise;
        },


        /** destroy TitleView
         * @function destroy
         * @param {Widget}  widget          - the root widget of this view
         * @memberof TitleView
         * @method
         */
        //not use now
        destroy: function (widget) {
            if (!widget) return;

            var headline_wgt = widget.getChild('title-headline');
            headline_wgt.id = '';
            headline_wgt.destroy();
            headline_wgt = null;

            widget.destroy();
            widget = null;

        }
    }

);


/** ContentView -BackboneView
 * @class
 * @name ContentView
 * @augments Backbone.View
 */
var ContentView = PanelCommon.BaseView.extend({
    template: DetailTextTemplate.container,

    /** Initialize ContentView.
     * @function initialize
     * @param {Model}  model          - model data of this detail news
     * @memberof ContentView
     */
    initialize: function (model) {
        this.model = model;
    },

    /** render ContentView. there are two types of content tempate
     *1)content template with thumbnail  (DetailThumbTemplate = Require("app/templates/1080/newson-detail-thumb-template.js"))
     *2)text-only content template  (var DetailTextTemplate = Require("app/templates/1080/newson-detail-text-template.js"))
     * @function render
     * @param {Widget}  parent          - the parent widget of this view
     * @memberof ContentView
     */
    render: function (parent) {
        //judge which template(text-only or thumb+text) use
        if (this.model.get('type') == 'text' || this.model.get('thumbnail') == null) {
            this.template = DetailTextTemplate.container;
        } else {
            this.template = DetailThumbTemplate.container;
        }

        //create UI and set data
        this.setWidget(loadTemplate(this.template, {
            thumbnail: this.model.get('thumbnail'),
            contents: this.model.get('contents').replace(/<(?:.|\n)*?>/gm, ''),
            fullarticle: this.model.get('contents').replace(/<(?:.|\n)*?>/gm, ''),
            timestamp: this.model.get('source') + ' | ' + this.model.get('published') + ' | ' + this.model.get('published')
        }, null, parent));
        return this;

    },

    /** hide ContentView.
     * @function hide
     * @memberof ContentView
     * @return {Object} Return the deferred.promise used for checking if hide is done
     */
    hide: function () {
        Volt.log();
        var deferred = Q.defer();

        //this.widget.hide();
        this.destroy(this.widget);

        deferred.resolve();
        return deferred.promise;
    },

    /** destroy ContentView
     * @function destroy
     * @param {Widget}  widget          - the root widget of this view
     * @memberof ContentView
     * @method
     */
    destroy: function (widget) {
        if (!widget) return;

        var info_wgt = widget.getChild('detail-info-area');
        var nChildLength = info_wgt.getChildCount();
        /*
		if(nChildLength > 0)
		{
			for(var i = 0; i < nChildLength; i++)
			{
				var wgt = info_wgt.getChild(i);
				wgt.destroy();
				wgt = null;
			}
		}
		*/
        info_wgt.destroyChildren();
        info_wgt.id = '';
        info_wgt.destroy();
        info_wgt = null;

        var fullarticale_wgt = widget.getChild('detail-fullarticle-area');
        nChildLength = fullarticale_wgt.getChildCount();
        /*
		if(nChildLength > 0)
		{
			for(var i = 0; i < nChildLength; i++)
			{
				var wgt = fullarticale_wgt.getChild(i);
				wgt.destroy();
				wgt = null;
			}
		}
		*/
        fullarticale_wgt.destroyChildren();
        fullarticale_wgt.id = '';
        fullarticale_wgt.destroy();
        fullarticale_wgt = null;


        widget.destroy();
        widget = null;
    }
});


/** RelatedItemView -BackboneView
 * @class
 * @name RelatedItemView
 * @augments Backbone.View
 */
var RelatedItemView = PanelCommon.BaseView.extend({

    /** Initialize RelatedItemView.
     * @function initialize
     * @memberof RelatedItemView
     */
//    initialize: function () {},

    /** render RelatedItemView.
     * @function render
     * @param {Widget}  parent          - the root widget of this view
     * @memberof RelatedItemView
     */
    render: function (parent) {
//        Volt.log();

        //use resizeablelist to render related list
        this.singlelist = __initSingleLine(parent, newsCollection.models);
        //this.grid.hide();
        this.setWidget(this.singlelist);
        //print("setItems");

        this.singlelist.setScrollBar(250,0,1080);
        Volt.Nav.reload();
        return this;
    },

    /** update RelatedItemView. 
     * @function update
     * @memberof RelatedItemView
     */
    update: function () {
        Volt.log();

        var contentCollection = newsCollection.models;

        this.singlelist.rnd = Math.floor(Math.random() * contentCollection.length);

        //load data		
        for (i = 0; i < contentCollection.length; i++) {
            var data = new Data();

            var model = contentCollection[(i + this.singlelist.rnd) % contentCollection.length];

            data.imgUrl = model.get('thumbnail');
            data.title = model.get('headline');
            //data.title =  "***************************************************************";

            this.singlelist.addData(data);
        }

        this.singlelist.loadData();

    },

    events: {
        //'NAV_SELECT':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    onSelect: function (widget) {},

    /** focus RelatedItemView.
     * @function onFocus
     * @param {Widget}  parent          - the target widget need to be focused
     * @memberof RelatedItemView
     */
    onFocus: function (widget) {
        widget.enableFocus();
//        widget.setFocus();
        widget.showFocus("true");
    },

    /** blur RelatedItemView.
     * @function onBlur
     * @param {Widget}  parent          - the target widget need to be killed focus
     * @memberof RelatedItemView
     */
    onBlur: function (widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] onBlur  widget    ', widget);

        if (widget) {
            widget.hideFocus("true");
        }
    },

    destroy: function () {
        Volt.Nav.focus(null);

        this.singlelist.destroy();
        delete this.singlelist;
        this.singlelist = null;

    },

});


/** init related news list and set callback function
 * @function __initSingleLine
 * @param {Widget}  parent          - the parent widget which list should created on
 */
function __initSingleLine(parent, model) {
    Volt.log();
    /*
	var template = {
        type: 'SingleLineListControl',
		parent:null, 
		width: 277+1, 
		height: 1080,  
        custom: {focusable: true,},
        scrollType: "Vertical"
	};
*/
    //print('   Singlelist  is    ', Singlelist);
//    var template = NewsOnDetailCommonTemplate.SingleList;
//    template.parent = parent;
//
//    var singlelineView = new Singlelist(template, parent).render();
//    var singleline;
//
//
//    singleline = singlelineView.widget;

    var singleline = loadTemplate(NewsOnDetailCommonTemplate.SingleList, null, parent);


    /****************************set list's layout begin********************************/

    var contentCollection = newsCollection.models;

    singleline.addItem({
        itemNum: contentCollection.length,
        itemSpace: 155 + 51
    });

    singleline.enlargeFocusedItem(20, 20);
    singleline.show();


    /****************************set list's layout end********************************/


    /****************************set callback of Singlelist begin********************************/
    singleline.initRenderer = function (renderer, data, parentWidth, parentHeight) {

        print(' initRenderer    renderer  is    ', renderer);

        loadTemplate(NewsOnDetailCommonTemplate.RelatedItem, null, renderer.root);
        renderer.thumbnail = renderer.root.getChild(0);
    };


    singleline.onDrawLoadData = function (render, data, parentWidth, parentHeight) {

        print('  data  is    ', data);
        var mustache = {
            imgUrl: data.imgUrl,
            title: data.title,
        };

        render.thumbnail.setInformationText("text1", data.title);
        render.thumbnail.setContentImage(data.imgUrl);

    }

    singleline.onItemPress = function (index) {
        Volt.log('index: ' + index);
        if (index >= 0) {
            //switch view when press item of the related list

            // Store anything you want in the cache
            Backbone.history.setCache({
                focusIndex: index
            });
            Backbone.history.navigate('detail/' + newsCollection.at(index).get('id'), {
                trigger: true
            });
        } else {
            Volt.log('index is invalid');
        }

    }

    singleline.onItemMouseClick = function (index) {
        Volt.log('index: ' + index);
        if (index >= 0) {
            //switch view when press item of the related list

            // Store anything you want in the cache
            Backbone.history.setCache({
                focusIndex: index
            });
            Backbone.history.navigate('detail/' + newsCollection.at(index).get('id'), {
                trigger: true
            });
        } else {
            Volt.log('index is invalid');
        }
    }

    singleline.onDrawUpdateData = function (widget, data, parentWidth, parentHeight) {
        print("  ondrawupdateData update process!!!!!  widget    ", widget);

    }

    singleline.onDrawFromFocusChangeStart = function (widget, data, parentWidth, parentHeight) {

    }

    singleline.onDrawToFocusChangeEnd = function (widget, data, parentWidth, parentHeight) {

    }

    //****************************set callback of Singlelist end********************************/
    return singleline;
};



exports = NewsDetailView;

