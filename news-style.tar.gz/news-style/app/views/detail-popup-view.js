// Modules
var Require = Volt.require,
    _ = Require('modules/underscore.js')._;
    Backbone = Require('lib/volt-backbone.js'),

// Require Common Modules
    PanelCommon = Require('lib/panel-common.js');

////////////////////////////////////////////////////////////////////////////////
var DetailPopupView = PanelCommon.BaseView.extend({
    mediator: null,     // Handle Events

    popup: null,        // Store popup widget

    options: null,    // store the options of render()

    initialize: function(options) {
        // NOTICE: this.widget has already been set as options.widget automatically

        // Get mediator from MainView
        this.mediator = options.mediator;

        // On Events
        this.mediator.on('EVENT_DETAIL_POPUP_SHOW', this.render, this);
        this.mediator.on('EVENT_DETAIL_POPUP_HIDE', this.remove, this);
    },

/**
 * Called if you want to show something
 */
    render: function(options,num) {

        this.options = {
            type: options,
            setRoot: false
        };

        switch (options) {
            case 'RATING-POPUP': {
                RatingPopView = PanelCommon.requireView('rating');
                var Rating = new RatingPopView(this.widget, options);
				Rating.setRatingNum(num);
		        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'num is    ' + num);
                Rating.setReturnCB(_.bind(this.onReturnCB, this));
                Rating.show();
                Volt.Nav.beginModal(Rating.getWidget());
                break;
            }
            default:
                break;
        }

        return this;
    },
/**
 * Remove what you created in render()
 */
    remove: function(options) {  
        Volt.Nav.endModal();
        this.popup = null;
        return this;
    },

    ////////////////////////////////////
    // Custom Function Begins Here
    ////////////////////////////////////
    onReturnCB: function(num) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'num is    ' + num);

		this.mediator.trigger('EVENT_RATING_NUM_UPDATE',num);  //update rating star at detail view'button
        this.mediator.trigger('EVENT_DETAIL_POPUP_HIDE', this.options);  //trigger to process focus
    }

});


exports = DetailPopupView;


