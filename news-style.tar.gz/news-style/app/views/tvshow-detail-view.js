
// Include libraries
var Require = Volt.require,
    Q = Require('modules/q.js'),

    Backbone = Require('lib/volt-backbone.js'),
    _ = Require('modules/underscore.js')._,
// Require Common Modules    
    PanelCommon = Require('lib/panel-common.js'),
    Nav = Volt.Nav,

// Include models
    tvCollection = Require('app/models/home-news-collection.js'),

// Require Common templates of Main View
    TVShowDetailCommonTemplate = PanelCommon.requireTemplate('tvshow-detail'),

// Include example templates(should implement by apps panel member)
	DetailTemplate = Require("app/templates/1080/example-tvshow-detail-template.js"),

	//DimView = PanelCommon.requireView('dim'),
    dimView = PanelCommon.requireView('dim'),
    
    PopupView = Require('app/views/detail-popup-view.js'),
//include ratingpop
	Rating = PanelCommon.requireView("rating"),
    Gridlist = Require('app/views/grid-list-view.js'),

// Create an Mediator to commumicate between Views
	DetailMediator = new PanelCommon.Mediator;



/** DetailView -BackboneView
* @class 
* @name DetailView
* @augments Backbone.View
*/ 
var DetailView = PanelCommon.BaseView.extend({
    template : TVShowDetailCommonTemplate.container,
	mainView:null,
	buttonView:null,
	thumbView:null,
	contentView:null,
	listView:null,
	listtitleView:null,
//	dimView: null,

	/** Initialize DetailView. 
	* @function initialize
	* @memberof DetailView
	*/         
	initialize: function() {
        this.mainView = this;
    },

	/** Render DetailView
	* @function Render
	* @param {Object}  viewInfo                  - information of view,include productid,focusposition,focusindex
	* @param {String}  animationType          - tpe string of animation
	* @memberof DetailView     
	* @method      
	*/
    render : function(options,animationType){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   render');

		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'productId is ' + options.productId);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' +'focusPosition is ' + options.focusPosition);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' +'focusIndex is ' + options.focusIndex);


		//print('');
		
        this.model = tvCollection.get(options.productId);

        this.setWidget(PanelCommon.loadTemplate(this.template,null,null,false));   //load newson detail view(include titile-area,content-area and related area)
        
        this.renderThumb();    //render newson title area
        this.renderContent();	//render newson content area(inlcude thumbnail,fullarticall,)
        this.renderPopup();
		
        this.renderButton();	//render tvshow content area(inlcude thumbnail,fullarticall,)

        // Listen to model,when data change,update list 
        this.listenTo(tvCollection, 'reset change', this.updateList);

        DetailMediator.on('EVENT_DETAIL_POPUP_SHOW', this.pause, this);
        DetailMediator.on('EVENT_DETAIL_POPUP_HIDE', this.resume, this);


	},

	/** show DetailView
	* @function show
	* @param {Object}  viewInfo                  - information of view,include productid,focusposition,focusindex
	* @param {String}  animationType          - tpe string of animation
	* @memberof DetailView     
	* @method      
	* @return {Object} Return the deferred.promise used for checking if animation is done 	
	*/
    show : function(options,animationType){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']  show');

		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'productId is ' + options.productId);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'focusPosition is ' + options.focusPosition);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'focusIndex is ' + options.focusIndex);
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'focusType is ' + options.focusType);

		
        this.model = tvCollection.get(options.productId);

        this.renderList();	//render related area
		this.updateList();
		
		this.updateContent();
		this.updateThumb();
     
		
        //call Volt.Nav.setRoot, for reset the root when coming back to this view.
        Volt.Nav.setRoot(this.widget);

	
		var cache = Backbone.history.getCache();
		(options.focusIndex === undefined && cache) ? options.focusIndex = cache.focusIndex : options.focusIndex = 0;

		if( options.focusType == undefined && cache ){
			options.focusType = cache.focusType;
		}
		
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + '####$$$' + options.focusIndex + options.focusType);


		if( options.focusType == 'list_type'){
	        if (this.listView.widget) {

				Volt.Nav.focus(this.listView.widget);
	            this.listView.widget.setFocusItemIndex(0,options.focusIndex);
		        this.listView.widget.setFocus();
			}
		}
		else{
	        Volt.Nav.focus(Volt.Nav.getItem(0));
		}

		
		
        return PanelCommon.doViewSwitchAni(this.widget,animationType);
    },
    /** update of DetailView
	* @function update
	* @memberof DetailView
	* @method
	*/
    update : function(options, animationHideType,animationShowType){
         print('newson-detail-view.js : update');
		 var self = this;
		 this.hide(options, animationHideType)
            .then(function(){
                print('newson-detail-view.js : show');
                self.show(options,animationShowType);
            });
    },
	/** render thumb of DetailView
	* @function renderThumb
	* @memberof DetailView     
	* @method      
	*/
    renderThumb : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] renderThumb');
        var container = this.widget.getDescendant('detail-thumb-area');
		this.thumbView = new ThumbView(this.model).render(container);
        container.addChild(this.thumbView.widget);
    },

	/** update thumb of DetailView
	* @function updateThumb
	* @memberof DetailView     
	* @method      
	*/
	updateThumb: function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] updateThumb');
		
		this.thumbView.widget.getChild(0).src = this.model.get('thumbnail');
		
		this.thumbView.show();
	},

	/** render content of DetailView
	* @function renderContent
	* @memberof DetailView     
	* @method      
	*/
    renderContent : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']    renderContent');
        var container = this.widget.getDescendant('detail-content-area');
		this.contentView = new ContentView(this.model).render(container);
        container.addChild(this.contentView.widget);
    },

	/** update content of DetailView
	* @function updateContent
	* @memberof DetailView     
	* @method      
	*/
	updateContent:function(){
		this.contentView.widget.getChild('headline-content').text = this.model.get('headline');
		this.contentView.widget.getChild('release-content').text = this.model.get('published');
		this.contentView.widget.getChild('description-content').text = 'description: ' + this.model.get('contents').replace(/<(?:.|\n)*?>/gm, '');
		this.contentView.show();
	},


	/** render popup of DetailView
	* @function renderPopup
	* @memberof DetailView     
	* @method      
	*/
    renderPopup: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']    renderPopup');

        // Check if contentView exists, if so, just render(), otherwise, create a new one
        // Another coding style compared to other render function
        if (!this.popupView) {
            this.popupView = new PopupView({
                widget: this.widget.getChild('detail-popup-container'),
                mediator: DetailMediator
            });
        }
        this.popupView.render();
    },

	/** render Dim of DetailView
	* @function renderDim
	* @memberof DetailView     
	* @method      
	*/
/*
    renderDim: function() {
        (this.dimView || (this.dimView = new DimView({
            'widget': this.widget.getChild('detail-dim-container')
        }))).render();
    },
*/
	/** render button of DetailView
	* @function renderButton
	* @memberof DetailView     
	* @method      
	*/
    renderButton : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getDescendant('detail-button-area');
		//print("container   is ",container);
        this.buttonView = new ButtonView(this.model).render(container);
		container.addChild(this.buttonView.widget);
    },


	/** render list of DetailView
	* @function renderList
	* @memberof DetailView     
	* @method      
	*/
    renderList : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']    renderList');
        var container = this.widget.getDescendant('detail-list-area');

		this.listView = new ListView().render(container);
        container.addChild(this.listView.widget);

		this.listtitleView = new ListTitleView().render(container);
        container.addChild(this.listtitleView.widget);
    },

	/** update list of DetailView
	* @function updateList
	* @memberof DetailView     
	* @method      
	*/
	updateList: function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']    updateList');
		this.listView.update();
	},

	/** hide DetailView
	* @function hide
	* @param {Number} animationType Animation type
	* @memberof DetailView     
	* @method      
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/
    hide : function(options, animationType){
        var deferred = Q.defer();

		var thumbView = this.thumbView;
		var listView = this.listView;

		//delete these UI,create refer to data
		var retDef = PanelCommon.doViewSwitchAni(this.widget,animationType);
		retDef.then(function()
		{
			thumbView.hide();
			listView.destroy();
			deferred.resolve();
		});
        return deferred.promise;
    },


	/**
	 * Invoked when some popup view popup over this View
	 * @function
	 * @memberof DetailView
	 */
    pause: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        //this.dimView.show();
        dimView.show({
            parent: this.widget.getChild('detail-dim-container')
        });
    },

	/**
	 * Invoked when come back from popup
	 * @function
	 * @memberof DetailView
	 */
    resume: function(options) {
        // To test Backbone.history.back(options) and View.onKeyEvent
        // options.greetings has been set in Popup-xxx-view.js's onKeyEvent function
        if (options.greetings) {
            print('[--------------------------------------------------------------------] ');
            print('[If you see this, means that history.back() with parameter and View with onKeyEvent() are successfully called]');
            print('[ ' + options.greetings + ' ]');
        }


        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
//        this.dimView.hide();
        dimView.hide();

        // by default, setRoot() should be called, unless options.setRoot is explicitly set as false
        if (!options || options.setRoot !== false) {
            Nav.setRoot(this.widget);
        }
    },

});


/** ThumbView -BackboneView
 * @class 
* @name DetailView
* @augments Backbone.View
*/ 
var ThumbView = PanelCommon.BaseView.extend({
    template : TVShowDetailCommonTemplate.ThumbArea,

	/** Initialize ThumbView. 
	* @function initialize      
	* @param {Model}  model          - model data of this detail news
	* @memberof ThumbView
	*/         
    initialize : function(model){
    this.model = model;
	},

	/** render ThumbView. 
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ThumbView
	*/         
    render : function(parent){
        this.setWidget(PanelCommon.loadTemplate(this.template, {
            thumbnail : this.model.get('thumbnail')
        },parent));

        return this;

    },

	/** show ThumbView. 
	* @function show      
	* @memberof ThumbView
	*/         
	show: function(){
		this.widget.show();

	},

	/** hide ThumbView. 
	* @function hide      
	* @memberof ThumbView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
		
		//this.destroy(this.widget);
		
        deferred.resolve();
		
        return deferred.promise;
    },

	/** destroy ThumbView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof ThumbView     
	* @method      
	*/
	//not use now
	destroy : function(widget){
		if(!widget) return;

		//delete imagewidget
		var image = widget.getChild(0);
		image.destroy();
		image = null;
		
		//delete widget;
		widget.destroy();
		widget = null;
		
	},
});


/** ContentView -BackboneView
* @class 
* @name ContentView
* @augments Backbone.View
*/ 
var ContentView = PanelCommon.BaseView.extend({
    template : DetailTemplate.content,

	/** Initialize ContentView. 
	* @function initialize      
	* @param {Model}  model          - model data of this detail news
	* @memberof ContentView
	*/         
    initialize : function(model){
    this.model = model;
    },

	/** render ContentView. there are two types of content tempate
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ContentView
	*/         
    render : function(parent){	

 		this.setWidget(PanelCommon.loadTemplate(this.template),null,parent);
	
		
        return this;

    },

	/** show ContentView. 
	* @function show      
	* @memberof ContentView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
	show: function(){
		this.widget.show();

	},

	/** hide ContentView. 
	* @function hide      
	* @memberof ContentView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
		
		//this.destroy(this.widget);
		
        deferred.resolve();
        return deferred.promise;
    },

		//not use now
		destroy : function(widget){
		if(!widget) return;
		
		//delete headline
		var headineText = widget.getChild('headline-content');
		headineText.destroy();
		headineText.id = '';
		headineText = null;

		//delete genre
		var genreText = widget.getChild('genre-content');
		genreText.destroy();
		genreText.id = '';
		genreText = null;
		
		//delete release
		var releaseText = widget.getChild('release-content');
		releaseText.destroy();
		releaseText.id = '';
		releaseText = null;

		//delete director
		var directorText = widget.getChild('director-content');
		directorText.destroy();
		directorText.id = '';
		directorText = null;

		//delete description
		var descriptionText = widget.getChild('description-content');
		descriptionText.destroy();
		descriptionText.id = '';
		descriptionText = null;


		//delete rating
		var ratingWidget = widget.getChild('rating-content');
		var nChildLength = ratingWidget.getChildCount();
		if(nChildLength > 0){
			for(var i = nChildLength-1; i >= 0; i++){
				ratingWidget.getChild(i).destroy();
			}
		}
		
		ratingWidget.destroy();
		ratingWidget.id = '';
		ratingWidget = null;


		//delete widget;
		widget.destroy();
		widget = null;
		
	},

});




/** ButtonView -BackboneView
 * @class 
* @name ButtonView
* @augments Backbone.View
*/ 
var ButtonView = PanelCommon.BaseView.extend({
    template : DetailTemplate.button,
	RatingStarsList : [],
	RatingNum: 0,
	/** Initialize ButtonView. 
	* @function initialize      
	* @memberof ButtonView
	*/         
    initialize : function(model){
    	this.model = model;
    },

	/** render ButtonView. 
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ButtonView
	*/         
    render : function(parent){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
	
        this.setWidget(PanelCommon.loadTemplate(this.template),null,parent);

		this.RatingNum = 4;
		this.updateRating(this.RatingNum);

        __initButton(this.widget.getChild(0));
        __initButton(this.widget.getChild(1));
        __initButton(this.widget.getChild(2));
        
        var btn = this.widget.getChild(2).getUIElement();
		btn.setMouseClickCallback(_.bind(
			function(){
				var rate_num = this.RatingNum.toString();

				DetailMediator.trigger('EVENT_DETAIL_POPUP_SHOW', 'RATING-POPUP',rate_num);
				DetailMediator.on('EVENT_RATING_NUM_UPDATE',this.updateRating,this);		//trigger event, parent view will do some response
	  		},this)
		);
		btn.enableMouseClick(true);
        return this;

    },

	/** update rating num on the rating-button. 
	* @function render      
	* @param {String}  num          - num string of rating value
	* @memberof ButtonView
	*/         
	updateRating: function(num){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + num);
		this.RatingNum = num;
		var rating_wdg = this.widget.getChild('rating-widget');

		for( var i = 0;i < num ;i++){
			this.widget.getChild('rating-widget').getChild(i).src = Volt.getRemoteUrl('images/1080/04_mt_icon_star_h.png');
		}
		
		for(var j = parseInt(num);j < 5 ;j++){
			this.widget.getChild('rating-widget').getChild(j).src = Volt.getRemoteUrl('images/1080/04_mt_icon_star_n.png');
		}
		
		DetailMediator.off('EVENT_RATING_NUM_UPDATE',this.updateRating,this);		//remove trigger
	},


		

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

	/** focus ButtonView. 
	* @function onFocus      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ButtonView
	*/         
    onFocus: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] focusid is  ' + widget.id);
		//print("this.watchBtn is",this.watchBtn);

		if ( widget.id == 'watch-btn' ){
			widget.onFocus();
		}
		else if ( widget.id == 'record-btn' ){
			widget.onFocus();
		}
		else if (widget.id == 'rating-btn'){
			widget.onFocus();
		}
    },

	/** unfocus ButtonView. 
	* @function onBlur      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ButtonView
	*/         
    onBlur: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] focusid is  ' + widget.id);
		if ( widget.id == 'watch-btn' ){
			widget.onBlur();

		}
		else if ( widget.id == 'record-btn' ){
			widget.onBlur();
		}
		else if (widget.id == 'rating-btn'){
			widget.onBlur();
		}


    },

   
	/** hide ButtonView. 
	* @function hide      
	* @memberof ButtonView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
        //this.widget.destroy(this.widget);
        deferred.resolve();
        return deferred.promise;
    },

	/** destroy ButtonView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof ButtonView     
	* @method      
	*/
	//not use now
	destroy : function(widget){
		if(!widget) return;

		this.RatingStarsList.length = 0;

		var watch_btn = widget.getChild('watch-btn');
		watch_btn.id = '';
		watch_btn.destroy();
		watch_btn = null;

		var record_btn = widget.getChild('record-btn');
		record_btn.id = '';
		record_btn.destroy();
		record_btn = null;

		var rating_btn = widget.getChild('rating-btn');
		rating_btn.id = '';
		rating_btn.destroy();
		rating_btn = null;


		var rating_wgt = widget.getChild('rating-widget');
		rating_wgt.destroyChildren(); 
		rating_wgt.id = '';
		rating_wgt.destroy();
		rating_wgt = null;

		

		//delete widget;
		widget.destroy();
		widget = null;
		
	},
});

/*
 * create button
 * 
 * @function
 * @param {object}  param    			- button parameters for creating
 * @return {object} 					- return created button object	
 * @since 0.1
 *
 */
function __initButton(widget) {
    var btn = widget.getUIElement();

    btn.setText(btn.buttonState.STATE_UNFOCUSED, widget.custom.text);
    btn.setText(btn.buttonState.STATE_FOCUSED, widget.custom.text);
    btn.setText(btn.buttonState.STATE_PRESSED, widget.custom.text);
         
    btn.show();
    
}




/** ListTitleView -BackboneView
 * @class 
* @name DetailView
* @augments Backbone.View
*/ 
var ListTitleView = PanelCommon.BaseView.extend({
    template : DetailTemplate.listtitle,

	/** Initialize ListTitleView. 
	* @function initialize      
	* @memberof ListTitleView
	*/         
    initialize : function(){
    },

	/** render ListTitleView. 
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ListTitleView
	*/         
    render : function(parent){	
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        this.setWidget(PanelCommon.loadTemplate(this.template),null,parent);
		
        return this;

    },

	/** hide ListTitleView. 
	* @function hide      
	* @memberof ListTitleView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
		this.destroy(this.widget);
        deferred.resolve();
        return deferred.promise;
    },

	/** destroy ListTitleView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof ListTitleView     
	* @method      
	*/
	//not use now
	/*
	destroy : function(widget){
		if(!widget) return;
		
		var nChildLength = widget.getChildCount();
		if(nChildLength > 0)
		{
			for(var i = 0; i < nChildLength; i++)
			{
				this.destroy(widget.getChild(i));
			}
		} 
		//delete widget;
		widget.destroy();
		widget = null;
		
	},
	*/
});




/** RelatedItemView -BackboneView
* @class 
* @name RelatedItemView
* @augments Backbone.View
*/ 
var ListView = PanelCommon.BaseView.extend({

	/** Initialize RelatedItemView. 
	* @function initialize      
	* @memberof RelatedItemView
	*/         
    initialize : function(model){
    },

	/** render RelatedItemView. 
	* @function render      
	* @param {Widget}  parent          - the root widget of this view
	* @memberof RelatedItemView
	*/         
    render : function(parent){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');

		this.grid = _initGrid(parent,tvCollection.models);
		this.setWidget(this.grid);

        //Volt.Nav.reload();
        return this;
    },

	/** update RelatedItemView. 
	* @function update      
	* @memberof RelatedItemView
	*/         
	update:function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');

	    var contentCollection = tvCollection.models;
		
	    this.grid.rnd = Math.floor(Math.random() * contentCollection.length);
		
		//load data		
		for (i = 0; i < contentCollection.length; i++){
			var data = new Data();
			
		    var model = contentCollection[(i + this.grid.rnd)%contentCollection.length];
			
			data.imgUrl = model.get('thumbnail');
			data.title =  model.get('headline');
			
			this.grid.addData({groupIndex:0, data:data});
		}

		this.grid.loadData();

		
        //this.grid.setItems(this.grid.items, true);
    },

    events: {
        //'NAV_SELECT':'onSelect',
        'NAV_FOCUS':'onFocus',
        'NAV_BLUR':'onBlur'
    },

    onSelect: function(widget) {
    },

	/** focus RelatedItemView. 
	* @function onFocus      
	* @param {Widget}  parent          - the target widget need to be focused
	* @memberof RelatedItemView
	*/         
    onFocus: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
		
		widget.enableFocus();
		widget.setFocus();
		widget.showFocus("true");


		print(' tvshow list onfocus   widget.onKeyEvent   ', widget.onKeyEvent);
    },

	/** blur RelatedItemView. 
	* @function onBlur      
	* @param {Widget}  parent          - the target widget need to be killed focus
	* @memberof RelatedItemView
	*/         
    onBlur: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] onBlur  widget    ',widget);

		if ( widget ){
			widget.hideFocus("true");
		}
    },

	destroy: function(){
        Volt.Nav.focus(null);
		
		this.grid.destroy();
		delete this.grid;
		this.grid = null;

    	},
});



function _initGrid(parent,model) {



    print('@@@@@@@@[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] @@@@@@@@@@@@' );

	var template = DetailTemplate.RelatedGrid;
	template.y = 80;
	print('   Gridlist  is    ',Gridlist);
	var gridView = new Gridlist(template,parent).render();
	var grid;

	
	grid = gridView.widget;



	/****************************set list's layout begin********************************/

	grid.addGroup(1);
	grid.addStyle(1);
	grid.addDataGroup(1);


	for (var i = 0; i < model.length; i++){
		grid.addColumn({groupIndex: 0, styleIndex: 0, columnWidth: 324});
	}

	grid.addRowToAllColumn({groupIndex: 0, styleIndex: 0, rowHeight: 240});
	

	grid.enlargeFocusItem(20, 20);
	grid.editFlag = true;				//drag and drop mode
	grid.show();


	/****************************set list's layout end********************************/


	/****************************set callback of Gridlist begin********************************/


	grid.onDrawLoadData = function(widget,data, parentWidth, parentHeight){

		print('  data  is    ',data);
	    var mustache = {
	        imgUrl: data.imgUrl,
	        title: data.title,
	    };

        PanelCommon.loadTemplate(DetailTemplate.listitem, mustache, widget);

		var imgWgt = widget.getChild(0);
		var textscrollwgt = widget.getChild(1);
		var textScroll ;

		var textFontObj = {
			normal: "16px",
			focus: "16px",
			selected: "16px",
			dim: "16px"
		};

		print(' data.imgUrl  is       ',data.imgUrl);
		
		if (  data.imgUrl != '' ){

			if ( textscrollwgt ){
				textScroll = textscrollwgt.getChild(0);
				 textScroll.getUIElement().setTextContent({text:data.title,textfont:textFontObj,/*textcolor:textColorObj,*/scrollgap:20});		
				//textscrollwgt.hide();

			}
			
			PanelCommon.onColorPickLoad(widget,data.title,textFontObj);
		}
	}

	grid.onItemPress = function(groupindex,index){
	    Volt.log('index: ' + index);
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   index    ' + index);
	    if (index >= 0) {
			Backbone.history.setCache({focusIndex: index,focusType:'list_type'});
			Backbone.history.navigate('detail/' + tvCollection.at(index).get('id'), {trigger: true});
	    }else {
	        //print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'index is invalid');
	        Volt.log('Erro: Invalid Index!');
	    }
	}

	grid.onItemMouseClick = function(groupindex,index){
	    Volt.log('index: ' + index);
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   index    ' + index);
	    if (index >= 0) {
			Backbone.history.setCache({focusIndex: index,focusType:'list_type'});
			Backbone.history.navigate('detail/' + tvCollection.at(index).get('id'), {trigger: true});
	    }else {
	        Volt.log('Erro: Invalid Index!');
	    }
	}

	grid.onDrawUpdateData = function(widget,data, parentWidth, parentHeight){
		print("  ondrawupdateData update process!!!!!  widget    ",widget);

	}
	
	//****************************set callback of Gridlist end********************************/
	
	

    return grid;
}


exports = DetailView;

