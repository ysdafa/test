/**
 * @author Common Group
 * @fileoverview An example of Games Main View.
 * @date 2014/07/21
 *
 * @version 1.4
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */

// Include libraries
var Require = Volt.require,
    Q = Require('modules/q.js'),

    // Require Common Modules
    Backbone = Require('lib/volt-backbone.js'),
    PanelCommon = Require('lib/panel-common.js'),
    Nav = Volt.Nav,

    // Include models
    // We only need One single Model for Main View
    mainModel = Require('app/models/main-model.js'),

    // Require Common templates/view of Main View
    MainTemplate = PanelCommon.requireTemplate('main'),

    // Common Constant Definitions of GUI
    CommonTemplate = PanelCommon.requireTemplate('common'),

    ////////////////////////////////////////////////////////////////////////////////
    // Sub Views of Main View
    // Main View is composed of 4 SubViews
    HeaderView = Require('app/views/main-header-view.js'),
    CategoryView = Require('app/views/main-category-view.js'),
    PopupView = Require('app/views/main-popup-view.js'),

    // Get singleton DimView
    DimView = PanelCommon.requireView('dim'),
    

    BaseContentView = Require('app/views/main-base-content-view.js'),

    // Sub Category Views. We only provide 2 as example
    SpotlightView = Require('app/views/main-spotlight-view.js'),
    BrandzoneView = Require('app/views/main-brandzone-view.js'),

    ////////////////////////////////////////////////////////////////////////////////
    // Create an Mediator to commumicate between MainView and its sub Views
    Mediator = new PanelCommon.Mediator(),
    
    GlobalMediator = PanelCommon.GlobalMediator;

////////////////////////////////////////////////////////////////////////////////
/**
 * MainView is view of KeyScreen_SectionMain in "TV_2015_SmartHub_KeyScreen_Common_v0.9_20140516.pdf".
 * <p>MainView should extend from BaseView. It will be created and used by router-controller.js.
 * <p>Developer doesn't need to operate this View manually.
 * <p>Some properties and public functions may be invoked by app framework. Check the properties for details
 * <p style='color:red; font-weight:bold'>[TIPS] for developing with Common Module</p>
 * <p>1) Format of Events: EVENT_[VIEW NAME]_[WIDGET NAME]_[EVENT].
 * <p>&nbsp;&nbsp;e.g. EVENT_MAIN_SEARCH_SELECT
 * <p>2) Focus should be set after Nav.setRoot() or Nav.reload() called. Otherwise errors may occur.
 * <p>
 * <p>3) Pass {widget: xxx} to BaseView's constructor can set this widget as widget of the View directly.
 * <p>&nbsp;&nbsp;But you still need to call setWidget() to delegate 'events' if you have defined the 'events' property.
 * <p>4) Backbone supports following properties of View automatically:
 * <p> ['model', 'collection', 'el', 'id', 'attributes', 'className', 'tagName', 'events', 'widget', 'widgetOptions']
 * <p>4) Backbone.View.setWidget has 2 jobs: set this.widget = widget and delegate events.
 *
 * @class MainView
 *
 * @property {Widget}   widget      - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {Function} initialize  - Constructor function. Do initialization inside.
 * @property {Function} render      - Core function to render element in the View.
 * @property {Function} remove      - Remove the display elements created by render. remove any Backbone.Events listeners.
 * @property {Function} show        - Show this view. Invoked when come back from other View
 * @property {Function} hide        - Hide this view. Invoked when leave from this View
 * @property {Function} pause       - Invoked when some popup view popup over this View
 * @property {Function} resume      - Invoked when come back from popup
 * @property {Function} onKeyEvent  - Let the View have the chance to handle key events in this View.
 *
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 * @requires {@link Nav}
 * @requires {@link MainModel}
 * @since 1.0
 *
 *
 */
var MainView = PanelCommon.BaseView.extend({
    template: MainTemplate.container, // Template of Main View is a view of containers

    // Sub Views
    headerView: null,
    categoryView: null,
    popupView: null,

    // store options for show()
    options: null,

    ////////////////////////////////////////////////////////////////////////////
    // Public Functions of View for Common Module
    ////////////////////////////////////////////////////////////////////////////
    /**
     * Render the static display elements.
     * <p>The convention is for **render** to always return `this`.
     * @function
     * @memberof MainView
     * @return {View} return `this` MainView
     */
    render: function () {

        // Parse and load the template
        this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));

        this.mediator = Mediator;
        // Render everything except ContentView
        this.renderHeader();
        this.renderCategory();

        //create dim window here
//        this.dimWin = PanelCommon.loadTemplate(CommonTemplate.dimWindow, null, null, false); //new DimWindow();
//        print('			this.dimWin   	', this.dimWin);
//        this.dimWin.hide();
        this.renderPopup();

        Mediator.on('EVENT_MAIN_POPUP_SHOW', this.pause, this);
        Mediator.on('EVENT_MAIN_POPUP_HIDE', this.resume, this);
        GlobalMediator.on("EVENT_VOLT_ON_PAUSE", this.pause, this);
        return this;
    },

    /**
     * Show this view. Invoked when come from other View
     * @function
     * @memberof MainView
     * @param {Object}  options         - All options from router path or navigate/back parameters.
     * @param {String}  animationType   - Type of Animation
     */
    show: function (options, animType) {
        // We came from outside
        PanelCommon.animateWidget(this.widget, animType);
        // call Nav.setRoot, for reset the root when coming back to this view.
        Nav.setRoot(this.widget);

        // This focus setting will only be called when options.focusPosition is set.
        if (options.focusPosition !== undefined) {
            var pos = options.focusPosition;

            if (pos === MainTemplate.FOCUS_POSITION_HEADER) {
                // Focus setting should be handled by sub views
                this.headerView.onFocus(options.focusIndex);

            } else if (pos === MainTemplate.FOCUS_POSITION_CATEGORY) {
                this.categoryView.onFocus();

            } else if (pos == MainTemplate.FOCUS_POSITION_CONTENT) {
                this.options = {
                    focusPosition: MainTemplate.FOCUS_POSITION_CONTENT
                };
            }
        }

        return;
    },

    /**
     * Opposite operation of show, hide what you have shown.
     * @function
     * @memberof MainView
     */
    hide: function (options, animationType) {

        //set customized hideView ani, by default just use animationType
        return PanelCommon.animateWidget(this.widget, animationType);
    },

    /**
     * Invoked when some popup view popup over this View
     * @function
     * @memberof MainView
     */
    pause: function (type, rect) {
        Volt.log();

        //        if (rect) {
        //            print("    this.dimWin.addTransparentArea    rect.width    ", rect.width);
        //            this.dimWin.addTransparentArea({
        //                x: rect.x,
        //                y: rect.y,
        //                width: rect.width,
        //                height: rect.height
        //            });
        //        }
        //        this.dimWin.parent = this.widget.getChild('main-dim-container');
        //        this.dimWin.show();

        DimView.show({
            parent: this.widget.getChild('main-dim-container'),
            rect: rect
        });

        GlobalMediator.off("EVENT_VOLT_ON_PAUSE", this.pause, this);
        GlobalMediator.on("EVENT_VOLT_ON_RESUME", this.resume, this);
    },

    onKeyEvent: function (keyCode, keyType) {
        if (keyCode == Volt.KEY_1 && keyType == Volt.EVENT_KEY_PRESS) {
            this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', 'RICHTEXT');
            return true;
        } else if (keyCode == Volt.KEY_2 && keyType == Volt.EVENT_KEY_PRESS) {
            var appName = "org.tizen.search-all",
                args = {
                    "--root": "/usr/apps/org.tizen.search-all/"
                },
                aulApp = new Aul();

            aulApp.launchApp(appName, args);
            return true;
        }
        return false;
    },
    /**
     * Invoked when come back from popup
     * @function
     * @memberof MainView
     */
    resume: function (options) {
        // To test Backbone.history.back(options) and View.onKeyEvent
        // options.greetings has been set in Popup-xxx-view.js's onKeyEvent function
        if (options && options.greetings) {
            print('[If you see this, means that history.back() with parameter and View with onKeyEvent() are successfully called]');
            print('[ ' + options.greetings + ' ]');
        }

        Volt.log();

//        this.dimWin.hide();
//        this.dimWin.clearTransparentArea();
        DimView.hide();

        // by default, setRoot() should be called, unless options.setRoot is explicitly set as false
        if (!options || options.setRoot !== false) {
            Nav.setRoot(this.widget);
        }

        GlobalMediator.off("EVENT_VOLT_ON_RESUME", this.resume, this);
        GlobalMediator.on("EVENT_VOLT_ON_PAUSE", this.pause, this);
    },

    ////////////////////////////////////////////////////////////////////////////
    // Custom Functions of this View
    ////////////////////////////////////////////////////////////////////////////

    renderHeader: function () {
        Volt.log();
        (this.headerView || (this.headerView = new HeaderView({
            widget: this.widget.getChild('main-header-container'), // This will be automatically set by Backbone
            mediator: Mediator
        }))).render();
    },

    renderCategory: function () {
        Volt.log();
        // Check if categoryView exists, if so, just render(), otherwise, create a new one
        (this.categoryView || (this.categoryView = new CategoryView({
            widget: this.widget.getChild('main-category-container'),
            mediator: Mediator
        }))).render();
    },

    renderPopup: function () {
        Volt.log();

        // Check if contentView exists, if so, just render(), otherwise, create a new one
        // Another coding style compared to other render function
        if (!this.popupView) {
            this.popupView = new PopupView({
                widget: this.widget.getChild('main-popup-container'),
                mediator: Mediator
            });
        }
        this.popupView.render();
    }
});

exports = MainView;