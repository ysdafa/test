var BaseContentView = Volt.require('app/views/main-base-content-view.js');

MainPopularView = BaseContentView.extend({
    // Add whatever you like here
    popularId: 'C0020',
    
    getCategoryId:function(){ 
        return this.popularId;
    }
});

exports = MainPopularView;
