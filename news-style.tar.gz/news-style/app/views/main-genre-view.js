var BaseContentView = Volt.require('app/views/main-base-content-view.js');

MainGenreView = BaseContentView.extend({
    // Add whatever you like here
    genreId: 'C0020',
    
    getCategoryId:function(){ 
        return this.genreId;
    }
});

exports = MainGenreView;
