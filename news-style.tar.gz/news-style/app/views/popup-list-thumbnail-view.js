/** 
 * @author Zha Lihao(lihao.zha@samsung.com)
 * @fileoverview: this is a sample about list thumbnail popup
 *				this popup use volt-nav to manager focus navigation
 * @date 2014/06/20
 *
 * @version 1.4
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Include libraries
// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),
    _ = Require('modules/underscore.js')._,
    VoltJSON = Require('modules/VoltJSON.js'),

    // Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    Q = Require('modules/q.js'),
    Voltapi = Volt.require("modules/voltapi.js"),

    BaseView = PanelCommon.BaseView,

    // Include models
    listThumbCollection = Volt.require("app/models/list-thumbnail-collection.js"),

    // Include example templates(should implement by apps panel member)
    modalDialogListThumbTemplate = PanelCommon.requireTemplate("modal-dialog-list-thumbnail"),
    listThumbTemplate = Volt.require("app/templates/1080/list-thumbnail-template.js"),

    // Create an Mediator to commumicate between Views
    ListThumbMediator = new PanelCommon.Mediator;

////////////////////////////////////////////////////////////////////////////////
/**
 * ListThumbView is sample view of ModalDialog_List_Thumbnail in "TV_2015_SmartHub_KeyScreen_Common_IA_v0.91_20140530.pdf".
 * <p>ListThumbView should extend from BaseView. It will be created and used by router-controller.js.
 *
 * @class ListThumbView
 * @memberof Views
 *
 * @property {Widget}   widget            - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {template} template         - template of basic widgets
 * @property {Function} initialize          - Constructor function. Do initialization inside.
 * @property {Function} render          - Core function to render element in the View.
 * @property {Function} show             - Show this view. Invoked when enter this View
 * @property {Function} renderTitle     - Render title view
 * @property {Function} renderContent - Render content view
 * @property {Function} renderButton   - Render button view
 * @property {Function} hide             - Hide this view. Invoked when leave from this View
 * @property {Function} onKeyEvent   - Let the View have the chance to handle key events in this View.
 *
 *
 */
var ListThumbView = BaseView.extend({
    template: modalDialogListThumbTemplate.container,

    /**
     * Constructor function. Do initialization inside
     * @function
     * @memberof ListThumbView
     * @return None
     */
    initialize: function () {},

    /**
     * Render the static display elements. Only render base container
     * @function
     * @memberof ListThumbView
     * @return None
     */
    render: function () {
        this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
        return this;
    },

    /**
     * Render title,content and button.
     * @function
     * @param {Object} options        -some view info transferred via switch view
     * @param {String} animationType  -animation type
     * @memberof ListThumbView
     * @return None
     */
    show: function (options, animationType) {

        this.renderTitle();

        if (listThumbCollection.length > 0) {
            this.renderContent();
        }
        this.renderButton();

        Volt.Nav.setRoot(this.widget);
        Volt.Nav.focus(Volt.Nav.getItem(0));

        PanelCommon.doViewSwitchAni(this.widget, animationType);
    },

    /**
     * Render title
     * @function
     * @memberof ListThumbView
     * @return None
     */
    renderTitle: function () {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getChild('list-thumbnail-title-container');
        container.addChild(new TitleView().render().widget);
    },

    /**
     * Render content
     * @function
     * @memberof ListThumbView
     * @return None
     */
    renderContent: function () {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getChild('list-thumbnail-content-container');
        container.addChild(new ContentView().render(container).widget);
    },

    /**
     * Render button
     * @function
     * @memberof ListThumbView
     * @return None
     */
    renderButton: function () {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getChild('list-thumbnail-button-container');
        container.addChild(new ButtonView().render(container).widget);
    },

    /**
     * Hide popup view and send message to destroy all widgets in popup
     * @function
     * @param {Object} options        -some view info transferred via switch view
     * @param {String} animationType  -animation type
     * @memberof ListThumbView
     * @return None
     */
    hide: function (options, animationType) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var deferred = Q.defer();

        var retDef = PanelCommon.doViewSwitchAni(this.widget, animationType);
        retDef.then(function () {
            ListThumbMediator.trigger("EVENT_LIST_THUMBNAIL_VIEW_DESTROY");
            //remove this line to fix crash defect, can not access to gridlist after content view destroyed
            //ListThumbMediator.contentView.gridlist.setFocusIndex(0);		
            deferred.resolve();
        });

        return deferred.promise;
    },

    /**
     * View handle key event, if return false, let nav to handle this key event.
     * @function
     * @param {enum} keyCode        -key code
     * @param {enum} keyType  	-key type
     * @memberof ListThumbView
     * @return None
     */
    onKeyEvent: function (keyCode, keyType) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [' + Volt.__line__ + '] ');

        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {
            Backbone.history.back({
                greetings: 'Last word from popup'
            });
            return true;
        }
        return false;
    }
});
/**
 * TitleView is used to create tilte and description
 * @class TitleView
 * @since 1.0
 * @property {Widget}   widget            - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {template} template         - template of basic widgets
 * @property {Function} initialize          - Constructor function. Do initialization inside.
 * @property {Function} render             - Core function to render element in the View.
 * @property {Function} destroy           - Destroy this view. Invoked when get EVENT_LIST_THUMBNAIL_VIEW_DESTROY
 *
 * @example
 * // Create a new ButtonView
 * var titleView = new TitleView();
 * titleView.render();
 */
var TitleView = BaseView.extend({
    template: listThumbTemplate.title,

    /**
     * Constructor function. Listen to EVENT_LIST_THUMBNAIL_VIEW_DESTROY
     * @function
     * @memberof TitleView
     * @return None
     */
    initialize: function () {
        ListThumbMediator.on("EVENT_LIST_THUMBNAIL_VIEW_DESTROY", this.destroy, this);
    },

    /**
     * Render the static display elements.
     * @function
     * @memberof TitleView
     * @return None
     */
    render: function () {
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    },

    /**
     * destroy all the widget of this view, and stop listening EVENT_LIST_THUMBNAIL_VIEW_DESTROY
     * @function
     * @memberof TitleView
     * @return None
     */
    destroy: function () {
        ListThumbMediator.off("EVENT_LIST_THUMBNAIL_VIEW_DESTROY", this.destroy, this);
        this.widget.destroy();
    },
});

/**
 * ContentView is used to create gridlist
 * @class ContentView
 * @since 1.0
 * @property {Widget}   widget            - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {template} template         - template of basic widgets
 * @property {Function} initialize          - Constructor function. Do initialization inside.
 * @property {Function} render             - Core function to render element in the View.
 * @property {object} events                - events binding to the widget of this view
 * @property {Function} onFocus           - Invoked when Volt-nav set focus to widget in this view
 * @property {Function} onBlur             - Invoked when focused widget lose focus
 * @property {Function} destroy           - Destroy this view. Invoked when get EVENT_LIST_THUMBNAIL_VIEW_DESTROY
 *
 * @example
 *
 * // Create a new ButtonView
 * var contentView = new ContentView();
 * contentView.render(parent);
 */
var ContentView = BaseView.extend({
    template: listThumbTemplate.gridList,

    /**
     * Constructor function. Listen to EVENT_LIST_THUMBNAIL_VIEW_DESTROY
     * @function
     * @memberof TitleView
     * @return None
     */
    initialize: function () {
        ListThumbMediator.on("EVENT_LIST_THUMBNAIL_VIEW_DESTROY", this.destroy, this);
    },

    /**
     * Render the static display elements. init gridlist.
     * @function
     * @param {widget}  Parent    			- parent of gridlist
     * @memberof ContentView
     * @return None
     */
    render: function (Parent) {
        //only create list for one time, next time only update grid data
        if (!this.widget.created) {

            var gridlist = PanelCommon.loadTemplate(this.template, null, Parent);
            gridlist.parent = Parent;


            this.setWidget(gridlist);

            __initGrid(this.widget);

            this.widget.created = true;
        }

        __updateGrid(this.widget);
		//setfocusimage should be called after data load
		this.widget.setFocusImage(Volt.getRemoteUrl("images/1080/common/focus_grid.png"), 0, 0);
		

        return this;

    },

    /**
     * events object that will binding to all the widget in this view when call setWidget
     * @object
     * @memberof ContentView
     */
    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * Invoked when widget in this view get focus
     * @function
     * @param {Widget}  widget    			- widget that get focus
     * @memberof ContentView
     * @return None
     */
    onFocus: function (widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');


        widget.enableFocus();
        widget.setFocus();
        widget.showFocus("false");
    },

    /**
     * Invoked when widget in this view lose focus
     * @function
     * @param {Widget}  widget    			- widget that lose focus
     * @memberof ContentView
     * @return None
     */
    onBlur: function (widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        if (widget) {
            widget.hideFocus("true");
        }
    },

    /**
     * destroy all the widget of this view, and stop listening EVENT_LIST_THUMBNAIL_VIEW_DESTROY
     * @function
     * @memberof ContentView
     * @return None
     */
    destroy: function () {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        ListThumbMediator.off("EVENT_LIST_THUMBNAIL_VIEW_DESTROY", this.destroy, this);
        this.widget.destroy();
        delete this.widget;
        this.widget = null;
    },
});

/**
 * ButtonView is used to create button and set functions
 * @class ButtonView
 * @since 1.0
 * @property {Widget}   widget            - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {template} template         - template of basic widgets
 * @property {Function} initialize          - Constructor function. Do initialization inside.
 * @property {Function} render             - Core function to render element in the View.
 * @property {object} events                - events binding to the widget of this view
 * @property {Function} onFocus           - Invoked when Volt-nav set focus to widget in this view
 * @property {Function} onBlur             - Invoked when focused widget lose focus
 * @property {Function} destroy           - Destroy this view. Invoked when get EVENT_LIST_THUMBNAIL_VIEW_DESTROY
 * @example
 *
 * // Create a new ButtonView
 * var buttonView = new ButtonView();
 * buttonView.render();
 */
var ButtonView = BaseView.extend({
    template: listThumbTemplate.button,

    /**
     * Constructor function. Listen to EVENT_LIST_THUMBNAIL_VIEW_DESTROY
     * @function
     * @memberof ButtonView
     * @return None
     */
    initialize: function () {
        ListThumbMediator.on("EVENT_LIST_THUMBNAIL_VIEW_DESTROY", this.destroy, this);
    },

    /**
     * Render the static display elements. init button cancel and button done
     * @function
     * @param {widget}  parent    			- parent of gridlist
     * @memberof ButtonView
     * @return None
     */
    render: function (parent) {
        this.setWidget(PanelCommon.loadTemplate(this.template, null, parent));


        var buttonListener = new ButtonListener;
        buttonListener.onButtonClicked = function (button, type) {
            print('    onButtonClicked     type  ', type);
            Backbone.history.back();
        };
        this.btnListener = buttonListener;

        var btn;
        print(' this.widget.getChildCount()  ', this.widget.getChildCount());
        // set button attributes which createed by native UI
        btn = this.widget.getChild('cancel');

        //set button click
        btn.addListener(this.btnListener);



        // set button attributes which createed by native UI
        btn = this.widget.getChild('done');
        btn.addListener(this.btnListener);


        return this;
    },

    /**
     * events object that will binding to all the widget in this view when call setWidget
     * @object
     * @memberof ButtonView
     */
    events: {
        //'NAV_SELECT':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * Invoked when select widget in this view
     * @function
     * @param {Widget}  widget    			- widget that selected
     * @memberof ButtonView
     * @return None
     */
    onSelect: function (widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        //widget.border = PanelCommon.BTN_BORDER_SELECTED;
    },

    /**
     * Invoked when widget in this view get focus
     * @function
     * @param {Widget}  widget    			- widget that get focus
     * @memberof ButtonView
     * @return None
     */
    onFocus: function (widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   widget      ', widget);

        widget.setFocus();
    },

    /**
     * Invoked when widget in this view lose focus
     * @function
     * @param {Widget}  widget    			- widget that lose focus
     * @memberof ButtonView
     * @return None
     */
    onBlur: function (widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');

        widget.killFocus();
    },

    /**
     * destroy all the widget of this view, and stop listening EVENT_LIST_THUMBNAIL_VIEW_DESTROY
     * @function
     * @memberof ButtonView
     * @return None
     */
    destroy: function () {
        ListThumbMediator.off("EVENT_LIST_THUMBNAIL_VIEW_DESTROY", this.destroy, this);

        this.widget.getChild('cancel').removeListener(this.btnListener);
        this.widget.getChild('done').removeListener(this.btnListener);
        this.widget.getChild('cancel').destroy();
        this.widget.getChild('done').destroy();

        this.widget.destroy();
    },

});

/**
 * init a grid and set propeties
 *
 * @function
 * @param {Object}  grid    			- gridlist widget
 * @return None
 * @since 1.0
 *
 */
function __initGrid(grid) {

    //****************************set list's layout begin********************************//

    grid.addGroup(1);
    grid.addStyle(1);
    grid.addDataGroup(1);

    /*
	for (var i = 0; i < listThumbCollection.length; i++){
		grid.addColumn({groupIndex: 0, styleIndex: 0, columnWidth: 300});
	}

	grid.addRowToAllColumn({groupIndex: 0, styleIndex: 0, rowHeight: 330});
*/
    print('   listThumbCollection.length  is       ' + listThumbCollection.length);
    grid.addRegularGrid({
        groupIndex: 0,
        styleIndex: 0,
        columnNumber: listThumbCollection.length,
        rowNumber: 1,
        columnWidth: 300,
        rowHeight: 330
    });

    grid.enlargeFocusItem(20, 20);
    grid.editFlag = true; //drag and drop mode
    grid.shadowEffectFlag = false;
    grid.show();

    //****************************set list's layout end********************************//





    //****************************set list's callback begin********************************//


    grid.initRenderer = function (renderer, data, parentWidth, parentHeight) {

        print(' initRenderer    renderer  is    ', renderer);
        PanelCommon.loadTemplate(listThumbTemplate.item, null, renderer.root);
        renderer.thumbnail = renderer.root.getChild(0);


    };


    grid.onDrawLoadData = function (render, data, parentWidth, parentHeight) {
        print('  data  is    ', data);
        print('  render  is    ', render.thumbnail);
        //print("-----------" + data.text + "-------------------------");
        render.thumbnail.setInformationText("text1", data.title);
        render.thumbnail.setInformationText("text2", data.subtitle);
        render.thumbnail.setContentImage(data.imgUrl);
        //PanelCommon.loadTemplate(listThumbTemplate.item, mustache, widget);
    }

    grid.onDrawFromFocusChangeStart = function (widget, data, parentWidth, parentHeight) {


    }

    grid.onDrawToFocusChangeEnd = function (widget, data, parentWidth, parentHeight) {

    }

    //****************************set list's callback end********************************//

}

/**
 * update a grid, reload data and items
 *
 * @function
 * @param {Object}  grid    			- gridlist widget
 * @return None
 * @since 1.0
 *
 */
function __updateGrid(grid) {

    var contentCollection = listThumbCollection;
    print('   contentCollection.length    is    ', contentCollection.length);

    grid.rnd = Math.floor(Math.random() * contentCollection.length);

    //load data	
    for (i = 0; i < contentCollection.length; i++) {
        var data = new Data();

        var model = contentCollection.models[i];

        data.imgUrl = model.get('imgUrl');
        data.title = model.get('title');
        data.subtitle = model.get('subTitle');

        grid.addData({
            groupIndex: 0,
            data: data
        });
    }

    grid.loadData();

}


/**
 * create button
 *
 * @function
 * @param {widget}  widget    			- button widget
 * @param {string}  text    			- text of button
 * @param {widget}  parent    			- parent widget of button object
 * @return None
 * @since 1.0
 *
 */
function __initButton(widget) {
    var btn = widget.getUIElement();
    btn.setText(btn.buttonState.STATE_UNFOCUSED, widget.custom.text);
    btn.setText(btn.buttonState.STATE_FOCUSED, widget.custom.text);
    btn.setText(btn.buttonState.STATE_PRESSED, widget.custom.text);
    btn.enableMouseClick(true);
    //btn.setParent(parent);
    btn.show();
}

/**
 * sample code for logging
 *
 * @function
 * @return None
 * @since 1.0
 *
 */
function __logging() {
    var ret = Voltapi.Logging.init();
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.init() return " + ret);

    ret = Voltapi.Logging.flushLog();
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.flushLog() return " + ret);

    ret = Voltapi.Logging.addEventFullLog("eventname", "log");
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.addEventFullLog() return " + ret);

    ret = Voltapi.Logging.setEventHeader("modelName", "userId", "DUID", "country", "privacyLog");
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.setEventHeader() return " + ret);

    ret = Voltapi.Logging.addEventConfInfo("", "", "", "", "");
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.addEventConfInfo() return " + ret);

    ret = Voltapi.Logging.setServiceConfInfo("", "", "", "", "", "");
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.setServiceConfInfo() return " + ret);

    ret = Voltapi.Logging.addEventLog("eventName", "time", "category", "value", "desc");
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.addEventLog() return " + ret);

    ret = Voltapi.Logging.isAgreedWith("eventName");
    print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.isAgreedWith() return " + ret);

    //ret = Voltapi.Logging.getGUID();
    //print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.getGUID() return " + ret);

    //ret = Voltapi.Logging.getUID();
    //print('[' + Volt.__file__ + ':' + Volt.__func__ + ':' + Volt.__line__ + ']' + "Voltapi.Logging.getUID() return " + ret);

}
exports = ListThumbView;