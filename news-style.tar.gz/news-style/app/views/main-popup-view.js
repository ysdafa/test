/**
 * @author Zha Lihao(lihao.zha@samsung.com)
 * @fileoverview An example of Games Main View.
 * @date 2014/06/28
 *
 * @version 1.1
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */

// Modules
var Require = Volt.require,
    _ = Require('modules/underscore.js')._,
    Backbone = Require('lib/volt-backbone.js'),

    // Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),

    // We only need One single Model for Main View
    mainModel = Require('app/models/main-model.js'),

    // Require Specific template for Games Main View
    GamesMainTemplate = Require('app/templates/1080/games-main-template.js'),
    
    GlobalMediator = PanelCommon.GlobalMediator;


////////////////////////////////////////////////////////////////////////////////
var MainPopupView = PanelCommon.BaseView.extend({
    mediator: null, // Handle Events

    popup: null, // Store popup widget

    options: null, // store the options of render()

    optionMenuIndex: 1, //save option menu selected index
    optionMenuSubIndex: 0, //save option menu first selected index

    initialize: function (options) {
        // NOTICE: this.widget has already been set as options.widget automatically

        // Get mediator from MainView
        this.mediator = options.mediator;
        //this.container = container;

        // On Events
        this.mediator.on('EVENT_MAIN_POPUP_SHOW', this.render, this);
        this.mediator.on('EVENT_MAIN_POPUP_HIDE', this.remove, this);
        PanelCommon.GlobalMediator.on("EVENT_CONNECT_NETWORK", this.showConnectNetworkPopup, this);
        PanelCommon.GlobalMediator.on("EVENT_DISCONNECT_NETWORK", this.showDisconnectNetworkPopup, this);
        
        GlobalMediator.on('EVENT_VOLT_ON_DEACTIVATE', this.remove, this);
        GlobalMediator.on('EVENT_VOLT_ON_PAUSE', this.remove, this);
        //PanelCommon.GlobalMediator.on("EVENT_NETWORK_ERROR_MESSAGE",this.showNetworkErrorPopup(),this);
    },

    /**
     * Called if you want to show something
     */
    render: function (options, rect) {
        this.options = {
            type: options,
            setRoot: false
        };

        switch (options) {
        case 'OPTION_MENU':
            {
                //var parent = this.container;
                var popup;

                // Load template
                popup = PanelCommon.loadTemplate(GamesMainTemplate.optionMenu, null, this.widget, false);

                popup._bNormalRemove = false,
                
                // Custom Widget specific initialization
                popup.setShowSubListArrow(0, false);
                popup.setShowSubListArrow(3, false);
                popup.setShowSubListArrow(4, false);
                popup.setShowCheckArrow(true);
                popup.setSelectIndex(this.optionMenuIndex);
                popup.setSubSelectIndex(0, this.optionMenuSubIndex);
                popup.setShowSubCheckArrow(3, true);
                popup.setShowSubCheckArrow(4, true);
                //                popup.setTimeout(_.bind(this.onTimeoutCB, this), 10 * 1000);
                popup.setTimeout(this.onTimeoutCB.bind(this), 10 * 1000);

                // _.bind will set context of the function
                //                popup.setCallback(_.bind(this.onOptionMenuCB, this));
                popup.setCallback(this.onOptionMenuCB.bind(this));

                var focusListener = new FocusListener;
                var mediator = this.mediator;
                focusListener.onFocusOut = function (actor) {
                    //if (!actor._bNormalRemove) {
                    Volt.setTimeout(mediator.trigger('EVENT_MAIN_POPUP_HIDE'), 1);
                    //}
                };
                popup.addFocusListener(focusListener);

                // Set Focus
                popup.enableFocus(true);
                popup.setFocus();
                popup.show();
				
                this.popup = popup;
            }
            break;
        case 'RICHTEXT':
            {
                var popup = PanelCommon.loadTemplate(GamesMainTemplate.richText, null, this.widget, false);
                popup.enableMultiline(true);
                popup.enableEditable(true);
                popup.enableSelectable(true);
                popup.setFontSize(100);
                popup.setTextColor(0, 0, 255, 255);
                popup.setCursorColor(255, 0, 0, 255);
                popup.setBackgroundColor(255, 255, 255, 255);
                popup.setCursorBlinkInterval(1000);
                popup.setText("This is a richtext sample, use mouse click this area to start input text, press return to destroy");
                popup.setPosition(GamesMainTemplate.richText.x, GamesMainTemplate.richText.y);
                popup.FocusInIMFContext();
                popup.SetIMEData("inputtype=1&osktype=1&layouttype=1&functiontype=1");
                popup.ShowIMFContext();

                popup.onKeyEvent = function (keyCode, keyType) {
                    if (keyType == Volt.EVENT_KEY_RELEASE) {
                        return false;
                    }
                    if (keyCode == Volt.KEY_RETURN) {
                        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
                        return true;
                    }
                }.bind(this);

                popup.show();
                Volt.Nav.beginModal(popup);
                this.popup = popup;
                break;
            }
        case 'LONG_PRESS_MENU':
            {
                //var parent = this.container;
                var popup;

                // Load template
                popup = PanelCommon.loadTemplate(GamesMainTemplate.longPressMenu, null, this.widget, false);

                // Custom Widget specific initialization
                popup.setShowListArrow(false);
                popup.setSelectIndex(0);
                popup.setTimeout(_.bind(this.onTimeoutCB, this), 10 * 1000);
                // _.bind will set context of the function
                popup.setCallback(_.bind(this.onLongPressMenuCB, this));

                if (rect.x + rect.width + popup.width >= GamesMainTemplate.SCREEN_WIDTH) {
                    popup.x = rect.x - popup.width;
                } else {
                    popup.x = rect.x + rect.width;
                }
                popup.y = rect.y + rect.height / 2 - popup.height / 2;

                popup.enableFocus(true);
                popup.setFocus();
                popup.show();


                this.popup = popup;
                break;
            }

        case 'POPUP_TYPE_INPUT_TEXT':
            {
                InputTextPopup = PanelCommon.requireView('input-text');
                var popup = new InputTextPopup(this.widget);

                var func = _.bind(this.onBtnClickCB, this);
                popup.setBtn1ClickCB(func);
                popup.setBtn2ClickCB(func);
                popup.setReturnCB(_.bind(this.onReturnCB, this));
                popup.show();

                widget = popup.getWidget();

                //Volt.Nav.setRoot(this.widget);

                Volt.Nav.beginModal(widget);
                break;
            }
            /////////////////////////////////////////////////////////////////////////
            // Updated by ZhaLihao@20140723, UIElement support message popup, do not need to 
            // use common module's msgbox, also check main-header-view.js
        case 'MSG_POPUP_TYPE_NETWORK_ERROR':
            {
                print("  create  MSG_POPUP_TYPE_NETWORK_ERROR  message box here    ");

                var msgtemplate = GamesMainTemplate.networkPopup;
                msgtemplate.parent = this.widget;

                var messageBox = PanelCommon.loadTemplate(msgtemplate);
                messageBox.parent = this.widget;
                messageBox.contentText  = Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK');
                messageBox.enablePointerFocus();

                var messageBoxListener = new MessageBoxListener;

				//response key "enter" and mouse "click"
                messageBoxListener.OnButtonEvent = function (messagebox, nButtonIndex, eventType) {
                    //print('    messageBoxListener.OnButtonEvent  begin');
                    if ("button_clicked" == eventType && "button_1" == nButtonIndex) {
                        Volt.setTimeout(_.bind(this.onReturnCB, this), 1);
                    } else if ("button_clicked" == eventType && "button_2" == nButtonIndex) {
                        Volt.setTimeout(_.bind(this.onReturnCB, this), 1);
                    }
                }.bind(this);

				//response key "return" and mouse "click"
			    var keyboardListener = new KeyboardListener;
			    keyboardListener.onKeyReleased = function (actor, keyCode) {
			        if (keyCode == Volt.KEY_RETURN) {
	                    Volt.setTimeout(_.bind(this.onReturnCB, this), 1);
			        }
			    }.bind(this);
				
			    messageBox.addKeyboardListener(keyboardListener);


                this.messageBoxListener = messageBoxListener;
				this.keyboardListener = keyboardListener;

                messageBox.addListener(this.messageBoxListener);

                messageBox.defaultFocusIndex = 1;

	            this.popup = messageBox;

	            break;
            }

        default:
            break;
        }

        return this;
    },
    /**
     * Remove what you created in render()
     */
    remove: function (options) {
        //print('********************remove messagebox*************this.messageBoxListener******************', this.messageBoxListener);
        if (this.popup) {
            if (this.popup.removeListener) {
                this.popup.removeListener(this.messageBoxListener);
                this.popup.removeKeyboardListener(this.keyboardListener);

				if ( this.messageBoxListener ){
					this.messageBoxListener.destroy();
				}

				if ( this.keyboardListener ){
					this.keyboardListener.destroy();
				}

                //HALOUtil.asyncRelease(this.popup);
                this.popup.destroy();
                //print('********************remove messagebox*************this.popup******************', this.popup);
            } else {
                this.popup.destroy();

                this.popup = null;
            }

        }

        return this;
    },

    showConnectNetworkPopup: function () {
        if (this.popup) {
            this.remove();
            this.render("MSG_POPUP_TYPE_CONNECT_NETWORK");
        } else {
            this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', "MSG_POPUP_TYPE_CONNECT_NETWORK");
        }
    },

    showDisconnectNetworkPopup: function () {
        if (this.popup) {
            this.remove();
            this.render("MSG_POPUP_TYPE_DISCONNECT_NETWORK");
        } else {
            this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', "MSG_POPUP_TYPE_DISCONNECT_NETWORK");
        }
    },
    ////////////////////////////////////
    // Custom Function Begins Here
    ////////////////////////////////////

    ////////////////////////////////////
    // Callback for Option Menu
    onOptionMenuCB: function (index, subIndex, bDim) {
        Volt.log('index is ' + index + ', subIndex is ' + subIndex);
        if (bDim) {
            return;
        }
        var optionMenuIndices = GamesMainTemplate.optionMenuIndices;
        if (index == optionMenuIndices.language) {
            /*this.optionMenuSubIndex = subIndex;
            if(subIndex == 0){
                Volt.onLanguageChanged(0);
            }
            else if(subIndex == 1){
                Volt.onLanguageChanged(99);
            }*/
        }
        if (subIndex == -1) {
            if (index != -1) {
                this.optionMenuIndex = index;
            }

            this.bNormalRemove = true;
            this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);

            if (index === optionMenuIndices.sortByName) {
                /*
                mainModel.fetch({
                    category: {
                        sort: 'name'
                    }
                });
                */
            } else if (index === optionMenuIndices.sortById) {
                /*
                mainModel.fetch({
                    category: {
                        sort: 'id'
                    }
                });
                */
            } else if (index === optionMenuIndices.signIn) {
                mainModel.updateAccountName('David Kim\'s Page');
            }
        }
    },
    onLongPressMenuCB: function (index, subIndex, bDim) {
        Volt.log('index is ' + index + ', subIndex is ' + subIndex);
        if (bDim) {
            return;
        }
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    onTimeoutCB: function () {
        Volt.log('option-menu timeout');
        this.bNormalRemove = true;
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    onBtn1ClickCB: function (type) {
        Volt.log('click popup button1 , type is ' + type);
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    onBtn2ClickCB: function (type) {
        Volt.log('click popup button2 , type is ' + type);
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    onReturnCB: function (type) {
        Volt.log('click return in popup , type is ' + type);
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    }
});

exports = MainPopupView;









/*
    show: function(type) {
        print('[main-popup-view.js] show: type is: ' + type);
        this.Mediator.trigger('EVENT_MAIN_POPUP_SHOW');

        var parent = this.container;
        var popup = null, widget;
        switch(type) {
            case "POPUP_TYPE_INPUT_TEXT":
                popup = new InputTextPopup(parent);
                popup.setBtn1ClickCB(this.onBtn1ClickCB);
                popup.setBtn2ClickCB(this.onBtn2ClickCB);
                popup.setReturnCB(this.onReturnCB);
                popup.show();
                widget = popup.getWidget();
                break;
            case PanelCommon.COMMON_POPUP_TYPE_UNEXPECTED_PROBLEM_ERROR1:
            case PanelCommon.COMMON_POPUP_TYPE_UNEXPECTED_PROBLEM_ERROR2:
            case PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR1:
            case PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR2:
            case PanelCommon.COMMON_POPUP_TYPE_SERVER_ERROR1:
            case PanelCommon.COMMON_POPUP_TYPE_SERVER_ERROR2:
            case PanelCommon.COMMON_POPUP_TYPE_LOGIN_ERROR:
            case PanelCommon.COMMON_POPUP_TYPE_UPDATE_ERROR:
                //create common msgbox
                //first parameter is the parent widget of the popup
                //second parameter is the event handler
                //third parameter is the msgbox type
                popup = new MessageboxView(parent, type);
                //set mesbox callback
                popup.setReturnCB(this.onReturnCB);
                popup.show();
                widget = popup.getWidget();
                break;
            case "OPTION_MENU":
                popup = PanelCommon.loadTemplate(GamesMainTemplate.optionMenu, null, parent, false);
                popup.create(parent);
                popup.setCallback(this.onOptionMenuCB);
                popup.setSubSelectIndex(3, 1);
                popup.show();
                widget = popup;
                break;
            default:
                print("[main-popup-view.js] error type");
        }
        if (popup) {
            //
            this.setWidget(widget);
            Volt.Nav.beginModal(widget);
            //Volt.Nav.setRoot(widget);

            this.popup = popup;
        }
        else {
            this.Mediator.trigger('EVENT_MAIN_POPUP_HIDE');
        }
    },

    hide: function() {
        Volt.Nav.endModal();
        //this.popup
    },

        onBtn1ClickCB: function(type) {
        print('[main-view.js] click popup button 1, type is ',type);
        _Global.Mediator.trigger('EVENT_MAIN_POPUP_HIDE');
    },

    onBtn2ClickCB: function(type) {
        print('[main-view.js] click popup button 2, type is ',type);
        _Global.Mediator.trigger('EVENT_MAIN_POPUP_HIDE');
    },
*/


/*            case PanelCommon.COMMON_POPUP_TYPE_UNEXPECTED_PROBLEM_ERROR1:
        case PanelCommon.COMMON_POPUP_TYPE_UNEXPECTED_PROBLEM_ERROR2:
        case PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR1:
        case PanelCommon.COMMON_POPUP_TYPE_NETWORK_ERROR2:
        case PanelCommon.COMMON_POPUP_TYPE_SERVER_ERROR1:
        case PanelCommon.COMMON_POPUP_TYPE_SERVER_ERROR2:
        case PanelCommon.COMMON_POPUP_TYPE_LOGIN_ERROR:
        case PanelCommon.COMMON_POPUP_TYPE_UPDATE_ERROR: {

            MessageboxView = PanelCommon.requireView('messagebox');
            //var parent = this.container;
            var messagebox = new MessageboxView(this.widget, options);
            messagebox.setReturnCB(_.bind(this.onReturnCB, this));
            messagebox.show();
            //this.setWidget(messagebox.getWidget());
            //Volt.Nav.beginModal(this.widget);
            Volt.Nav.beginModal(messagebox.getWidget());
            break;
        }*/

