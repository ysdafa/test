/**
 * @author Wang Xiaojun(xiaojun.wang@samsung.com)
 * @fileoverview An example of Header View in Games Main View.
 * @date 2014/07/21
 *
 * @version 1.4
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */

// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),
    // Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),

    // Require Specific template for Games Main View
    GamesMainTemplate = Require('app/templates/1080/games-main-template.js');

// Common Constant of GUI
CommonTemplate = PanelCommon.requireTemplate('common');

//KPI
KPI = Volt.require('app/common/kpi-options.js');
KPIOptions = KPI.Home;

////////////////////////////////////////////////////////////////////////////////
var MainHeaderView = PanelCommon.BaseView.extend({
    template: GamesMainTemplate.header,
    mediator: null,
    buttonListener: null,

    initialize: function (options) {
        this.mediator = options.mediator;

        // On Events
        // The third parameter should be added as the caller of the callback
        this.mediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink, this);
        this.mediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand, this);

        this.KPIAdd = new KPIOptions.Sub.OptionAdd();

        //
        this.buttonListener = new ButtonListener;
        this.buttonListener.onButtonClicked = function (button, type) {
            if (button.id == 'main-header-icon-close') {
                //Volt.exit();
                Backbone.history.navigate('main/popup/list-thumbnail', {
                    trigger: true
                });

            } else if (button.id == 'main-header-icon-schedule') {
                this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', 'MSG_POPUP_TYPE_NETWORK_ERROR');
            } else if (button.id == 'main-header-icon-setting') {
                this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', 'OPTION_MENU');
            }

        }.bind(this);
    },

    render: function () {
        Volt.log();
        PanelCommon.loadTemplate(this.template, null, this.widget);

        // delegate events. should be called at the end of render
        this.setWidget(this.widget);

        this.widget.getDescendant('main-header-icon-close').addListener(this.buttonListener);
        this.widget.getDescendant('main-header-icon-setting').addListener(this.buttonListener);
        this.widget.getDescendant('main-header-icon-schedule').addListener(this.buttonListener);
        return this;
    },

    events: {
        'NAV_FOCUS': 'onFocus',
//        'NAV_BLUR': 'onBlur'
    },

    onFocus: function (widget) {
        //Volt.log(Volt.Nav.getWidgetHierarchy(widget));

        if (widget) {
        ////////////////////////////////////////////////////////////////////////////
        // <?#5 Port to Halo Category Tabs ?>
            this.mediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
        }
    },

//    onBlur: function (widget) {
//        Volt.log(Volt.Nav.getWidgetHierarchy(widget));
//        //        widget.opacity  = CommonTemplate.TOPMENU_OPACITY_NORMAL;
//    },

    ////////////////////////////////////////////////////////////////////////////
    // Custom Function Begins Here
    ////////////////////////////////////////////////////////////////////////////

    //show popup view example when click schedule button
    onSelectSchedule: function () {
        Volt.log('Show list thumbnail popup view as an example');

        // Navigate a Popup View
        Backbone.history.navigate('main/popup/list-thumbnail', {
            trigger: true
        });
    },

    //show input text popup example when click search button
    onSelectSearch: function () {
        Volt.log('try to start search-all app');
        //print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        //this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', 'POPUP_TYPE_INPUT_TEXT');
        //this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', PanelCommon.COMMON_POPUP_TYPE_UPDATE_ERROR);
        /////////////////////////////////////////////////////////////////////////
        // Updated by ZhaLihao@20140723, UIElement support message popup, do not need to 
        // use common module's msgbox, also check main-popup-view.js

        this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', 'MSG_POPUP_TYPE_NETWORK_ERROR');

        // Add by lihao.zha@20140829, example of launch search-all
        //var appName = "org.tizen.search-all",
        //args = {"--root": "/usr/apps/org.tizen.search-all/"},
        //aulApp = new Aul();

        //aulApp.launchApp(appName, args);

    },

    //show msgbox example when click plus button
    onSelectPlus: function () {
        Volt.log();
        this.KPIAdd.send();
        this.mediator.trigger('EVENT_MAIN_POPUP_SHOW', 'OPTION_MENU');
    },

    expand: function () {
        Volt.log();
        this.widget.animate('y', CommonTemplate.HEADER_Y_NORMAL, CommonTemplate.CATEGORY_ANIM_DURATION);
    },

    shrink: function () {
        Volt.log();
        this.widget.animate('y', CommonTemplate.HEADER_Y_SHRINK, CommonTemplate.CATEGORY_ANIM_DURATION);
    }
});

exports = MainHeaderView;