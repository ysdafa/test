
// Include libraries
var Require = Volt.require,
    Q = Require('modules/q.js'),

    Backbone = Require('lib/volt-backbone.js'),

// Require Common Modules    
    PanelCommon = Require('lib/panel-common.js'),
    Nav = Volt.Nav,

// Include models
    appCollection = Require('app/models/home-news-collection.js'),

// Require Common templates of Main View
    AppDetailCommonTemplate = PanelCommon.requireTemplate('vertical-detail'),

// Include example templates(should implement by apps panel member)
	DetailTemplate = Require("app/templates/1080/example-app-detail-template.js"),

// Create an Mediator to commumicate between Views
	DetailMediator = new PanelCommon.Mediator;



/** DetailView -BackboneView
* @class 
* @name DetailView
* @augments Backbone.View
*/ 
var DetailView = PanelCommon.BaseView.extend({
    //template of newson detail view
    template : AppDetailCommonTemplate.container,
    thumbView: null,
    contentView: null,
    menuView: null,
    listView:null,
    
	/** Initialize DetailView. 
	* @function initialize
	* @memberof DetailView
	*/         
    initialize : function(){
    },

	/** Render DetailView
	* @function Render
	* @param {Object}  viewInfo                  - information of view,include productid,focusposition,focusindex
	* @param {String}  animationType          - tpe string of animation
	* @memberof DetailView     
	* @method      
	*/
    render : function(options,animationType){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');

		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'productId is ' + options.productId);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' +'focusPosition is ' + options.focusPosition);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' +'focusIndex is ' + options.focusIndex);
		
        this.model = appCollection.get(options.productId);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'this model is',this.model);

        this.setWidget(PanelCommon.loadTemplate(this.template,null,null,false));   //load newson detail view(include titile-area,content-area and related area)
        
		this.renderTitle();    //render app title area
		this.renderThumb();    //render app thumb area
        this.renderContent();	//render app content area

        this.renderList();	//render related area
        // Listen to model,when data change,update list 
        this.listenTo(appCollection, 'reset change', this.updateList);
		
        this.renderButton();	//render app button area
        
        //this.renderMenu();	//render menu popup
		

    },

	/** show DetailView
	* @function show
	* @param {Object}  viewInfo                  - information of view,include productid,focusposition,focusindex
	* @param {String}  animationType          - tpe string of animation
	* @memberof DetailView     
	* @method      
	* @return {Object} Return the deferred.promise used for checking if animation is done 	
	*/
    show : function(options,animationType){
        //var deferred = Q.defer();
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
		
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'productId is ' + options.productId);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' +'focusPosition is ' + options.focusPosition);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' +'focusIndex is ' + options.focusIndex);
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'DetailView focusType is ' + options.focusType);

		
        this.model = appCollection.get(options.productId);

		
		this.updateThumb(); //update thumbnail
		this.updateContent(); //update content
		
		
        //call Volt.Nav.setRoot, for reset the root when coming back to this view.
        Volt.Nav.setRoot(this.widget);

		var cache = Backbone.history.getCache();
		(options.focusIndex === undefined && cache) ? options.focusIndex = cache.focusIndex : options.focusIndex = 0;

		if( options.focusType == undefined && cache ){
			options.focusType = cache.focusType;
		}
		
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'focusType is ' + options.focusType);


		if( options.focusType == 'list_type'){
	        if (this.listView.widget) {
				Volt.Nav.focus(this.listView.widget);
	            this.listView.widget.setFocusIndex(options.focusIndex);
		        this.listView.widget.setFocus();
			}
		}
		else{
	        Volt.Nav.focus(Volt.Nav.getItem(0));
		}
        
        //deferred.resolve();
        return PanelCommon.doViewSwitchAni(this.widget,animationType);	
    },
    /** update of DetailView
	* @function update
	* @memberof DetailView
	* @method
	*/
    update : function(options, animationHideType,animationShowType){
         print('newson-detail-view.js : update');
		 var self = this;
		 this.hide(options, animationHideType)
            .then(function(){
                print('newson-detail-view.js : show');
                self.show(options,animationShowType);
            });
    },
	/** render title of DetailView
	* @function renderTitle
	* @memberof DetailView     
	* @method      
	*/
    renderTitle : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getDescendant('detail-title-area');
        container.addChild(new TitleView(this.model).render(container).widget);
    },

	/** render thumb of DetailView
	* @function renderThumb
	* @memberof DetailView     
	* @method      
	*/
    renderThumb : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getDescendant('detail-thumb-area');
		this.thumbView = new ThumbView(this.model).render(container);
        container.addChild(this.thumbView.widget);
    },

	/** update title of DetailView
	* @function updateThumb
	* @memberof DetailView     
	* @method      
	*/
	updateThumb: function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
		
		this.thumbView.widget.getChild(0).src = this.model.get('thumbnail');
		
		this.thumbView.show();

	},

	/** render content of DetailView
	* @function renderContent
	* @memberof DetailView     
	* @method      
	*/
    renderContent : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getDescendant('detail-content-area');
		this.contentView = new ContentView(this.model).render(container);
        container.addChild(this.contentView.widget);
    },

	/** update content of DetailView
	* @function updateContent
	* @memberof DetailView     
	* @method      
	*/
	updateContent:function(){
		this.contentView.widget.getChild('content-headline').text = this.model.get('headline');
		this.contentView.show();
	},

	/** render list of DetailView
	* @function renderList
	* @memberof DetailView     
	* @method      
	*/
    renderList : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getDescendant('detail-list-area');
		this.listView = new ListView(this.model).render(container);
        container.addChild(this.listView.widget);
    },

	/** update list of DetailView
	* @function updateList
	* @memberof DetailView     
	* @method      
	*/
	updateList: function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
			this.listView.update();
	},

	/** render button of DetailView
	* @function renderButton
	* @memberof DetailView     
	* @method      
	*/
    renderButton : function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getDescendant('detail-button-area');
       
		container.addChild(new ButtonView().render(container).widget);



    },

	/** render menu option of DetailView
	* @function renderMenu
	* @memberof DetailView     
	* @method      
	*/
	renderMenu: function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var container = this.widget.getDescendant('detail-popup-area');
		
        this.menuView = new MenuView().render(container);
		container.addChild(this.menuView.widget);

        DetailMediator.on("EVENT_SHOW_MENU_POPUP",this.dim,this);
        DetailMediator.on("EVENT_HIDE_MENU_POPUP",this.undim,this);
	},

	/** hide DetailView
	* @function hide
	* @param {Number} animationType Animation type
	* @memberof DetailView     
	* @method      
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/
    hide : function(options,animationType){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        var deferred = Q.defer();
		var thumbView = this.thumbView;
		var contentView = this.contentView;
        var retDef = PanelCommon.doViewSwitchAni(this.widget,animationType);
		retDef.then(function()
		{
			contentView.hide();
			thumbView.hide();
			deferred.resolve();
		});
		return deferred.promise;
    },

	/** destroy DetailView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof DetailView     
	* @method      
	*/
	//not use now
	destroy : function(widget){
		if(!widget) return;
		var nChildLength = widget.getChildCount();
		if(nChildLength > 0){
			for(var i = nChildLength-1; i >= 0; i++){
				this.destroy(widget.getChild(i));
			}
		}
		widget.destroy();
		widget = null;
	},

	/** set dim widget to invisible when popup shows
	* @function dim
	* @memberof DetailView     
	* @method      
	*/
    dim: function(){
    	var container = this.widget.getChild('detail-popup-area');
		container.color.a = 100;
		container.addEventListener("onMouseOver",this.blockMouse);
    },

	/** set undim widget to invisible when popup shows
	* @function undim
	* @memberof DetailView     
	* @method      
	*/
    undim: function(){
    	var container = this.widget.getChild('detail-popup-area');
		container.color.a = 0;
		container.removeEventListener("onMouseOver",this.blockMouse);
    },
    
	blockMouse: function(){},
});


/** TitleView -BackboneView
 * @class 
* @name DetailView
* @augments Backbone.View
*/ 
var TitleView = PanelCommon.BaseView.extend({
    template : AppDetailCommonTemplate.TitleArea,

	/** Initialize TitleView. 
	* @function initialize      
	* @param {Model}  model          - model data of this detail news
	* @memberof TitleView
	*/         
    initialize : function(model){
    this.model = model;
	},

	/** render TitleView. 
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof TitleView
	*/         
    render : function(parent){
	
        this.setWidget(PanelCommon.loadTemplate(this.template,null,parent));

        return this;

    },

	/** hide TitleView. 
	* @function hide      
	* @memberof TitleView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
		//this.destroy(this.widget);
        deferred.resolve();
        return deferred.promise;
    },

	/** destroy TitleView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof TitleView     
	* @method      
	*/
	//not use now
	destroy : function(widget){
		if(!widget) return;
		
		var nChildLength = widget.getChildCount();
		if(nChildLength > 0){
			for(var i = nChildLength-1; i >= 0; i++){
				this.destroy(widget.getChild(i));
			}
		} 
		//delete widget;
		widget.destroy();
		widget = null;
		
	},
});



/** ThumbView -BackboneView
 * @class 
* @name DetailView
* @augments Backbone.View
*/ 
var ThumbView = PanelCommon.BaseView.extend({
    template : DetailTemplate.ThumbArea,

	/** Initialize ThumbView. 
	* @function initialize      
	* @param {Model}  model          - model data of this detail news
	* @memberof ThumbView
	*/         
    initialize : function(model){
    this.model = model;
	},

	/** render ThumbView. 
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ThumbView
	*/         
    render : function(parent){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
	
        this.setWidget(PanelCommon.loadTemplate(this.template, {
            thumbnail : this.model.get('thumbnail')
        },parent));

        return this;

    },

	/** show ThumbView. 
	* @function show      
	* @memberof ThumbView
	*/         
	show: function(){
        this.widget.show();
	},

	/** hide ThumbView. 
	* @function hide      
	* @memberof ThumbView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
		//this.destroy(this.widget);
        deferred.resolve();
        return deferred.promise;
    },

	/** destroy ThumbView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof ThumbView     
	* @method      
	*/
	//not use now
	destroy : function(widget){
		if(!widget) return;
		
		//delete imagewidget
		var image = widget.getChild(0);
		image.destroy();
		image = null;
		
		//delete widget;
		widget.destroy();
		widget = null;
		
	},
});




/** ButtonView -BackboneView
 * @class 
* @name ButtonView
* @augments Backbone.View
*/ 
var ButtonView = PanelCommon.BaseView.extend({
    template : DetailTemplate.button,

	/** Initialize ButtonView. 
	* @function initialize      
	* @memberof ButtonView
	*/         
    initialize : function(){
    },

	/** render ButtonView. 
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ButtonView
	*/         
    render : function(parent){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
	
        this.setWidget(PanelCommon.loadTemplate(this.template),null,parent);

        __initButton(this.widget.getChild(0));
        __initButton(this.widget.getChild(1));


        return this;

    },

    events: {
        'NAV_SELECT #detail-btn': 'onSelectDetail',
        'NAV_SELECT #delete-btn': 'onSelectDelete',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

	/** focus ButtonView. 
	* @function onFocus      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ButtonView
	*/         
    onFocus: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'ButtonView.focus ' + widget.id);
		//print("this.watchBtn is",this.watchBtn);

		if ( widget.id == 'detail-btn' ){
			widget.onFocus();
		}
		else if ( widget.id == 'delete-btn' ){
			widget.onFocus();
		}
    },

	/** unfocus ButtonView. 
	* @function onBlur      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ButtonView
	*/         
    onBlur: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'ButtonView.focus ' + widget.id);
		if ( widget.id == 'detail-btn' ){
			widget.onBlur();
		}
		else if ( widget.id == 'delete-btn' ){
			widget.onBlur();
		}


    },


    onSelectDetail: function() {  print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '); },
    onSelectDelete: function() {  print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '); },

	/** hide ButtonView. 
	* @function hide      
	* @memberof ButtonView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
        this.widget.destroy(this.widget);
        deferred.resolve();
        return deferred.promise;
    },

	/** destroy ButtonView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof ButtonView     
	* @method      
	*/
	//not use now
	destroy : function(widget){
		if(!widget) return;
		
		var detail_btn = widget.getChild('detail-btn');
		detail_btn.id = '';
		detail_btn.destroy();
		detail_btn = null;

		var delete_btn = widget.getChild('delete-btn');
		delete_btn.id = '';
		delete_btn.destroy();
		delete_btn = null;


		//delete widget;
		widget.destroy();
		widget = null;
		
	},
});


/* * create button
 * 
 * @function
 * @param {object}  param    			- button parameters for creating
 * @return {object} 					- return created button object	
 * @since 0.1
 *
 */
function __initButton(widget) {
    var btn = widget.getUIElement();

    btn.setText(btn.buttonState.STATE_UNFOCUSED, widget.custom.text);
    btn.setText(btn.buttonState.STATE_FOCUSED, widget.custom.text);
    btn.setText(btn.buttonState.STATE_PRESSED, widget.custom.text);
         
    btn.show();
    
}




/** MenuView -BackboneView
 * @class 
* @name MenuView
* @augments Backbone.View
*/ 
var MenuView = PanelCommon.BaseView.extend({
    template : DetailTemplate.menu,
	PopupMenuSample : null,

	/** Initialize MenuView. 
	* @function initialize      
	* @memberof MenuView
	*/         
    initialize : function(){
    },

	/** render MenuView. 
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof MenuView
	*/         
    render : function(parent){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
	
        this.setWidget(PanelCommon.loadTemplate(this.template),null,parent);
	

		var listData = ["By Price", "By Popularity", "By Recency"];
		
		this.menu = this.widget.getUIElement();
		
		this.menu.setMenuListSpace(DetailTemplate.menu_list.x, DetailTemplate.menu_list.y, DetailTemplate.menu_list.w, DetailTemplate.menu_list.h, this.widget,DetailTemplate.menu_list.num);	
		DetailTemplate.menu_list_content.listArray = listData;
		this.menu.setMenuListContent(DetailTemplate.menu_list_content);
		
		var color1={r:192, g:128, b:128, a:255};
		var color2={r:64, g:128, b:128, a:255};
		var color3={r:128, g:192, b:128, a:255};
		var color4={r:128, g:64, b:128, a:255};
		
		this.menu.setUnFocusValue(color1,color2,"20px");
		this.menu.setFocusValue(color3,color4,"25px");
		
		this.menu.setSelectedBtnImage(this.menu.selectedButton.buttonState.STATE_UNFOCUSED, Volt.getRemoteUrl('images/1080/common/button/wizard_btn_nor.png'));
		this.menu.setSelectedBtnImage(this.menu.selectedButton.buttonState.STATE_FOCUSED, Volt.getRemoteUrl('images/1080/common/button/wizard_btn_sel.png'));
		this.menu.setSelectedBtnImage(this.menu.selectedButton.buttonState.STATE_PRESSED, Volt.getRemoteUrl('images/1080/common/button/wizard_btn_sel.png'));

		this.menu.setSelectedBtnCallback(function(){ DetailMediator.trigger('EVENT_SHOW_MENU_POPUP');});
		this.menu.setSelectedListCallback(function(){ DetailMediator.trigger('EVENT_HIDE_MENU_POPUP');});

		
		//set keyevent handle function for popup
		this.widget.onKeyEvent = this._onkeyEvent.bind(this);
		
        return this;

    },

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

	/** focus MenuView. 
	* @function onFocus      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof MenuView
	*/         
    onFocus: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'focus ' + widget.id);
		
		widget.onFocus();
    },
    
	/** kill focus MenuView. 
	* @function onFocus      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof MenuView
	*/         
    onBlur: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'focus ' + widget.id);
		widget.onBlur();

    },
    
	/** process key  MenuView. 
	* @function onFocus      
	* @param {String}  keycode          	- code string of key value
	* @param {String}  type          		- type  string of key value
	* @memberof MenuView
	*/         
    _onkeyEvent: function(keycode, type) {
		//filter Volt.EVENT_KEY_RELEASE add by yansu 20140711
		if (type == Volt.EVENT_KEY_RELEASE) 
			return true;
		
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'this.PopupMenuis',this.menu );
 		var ret = this.menu.keyHandler(keycode, type);
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'this.PopupMenu.isMenuShowFlag is    ',this.menu.isMenuShowFlag );
		
		if(this.menu.isMenuShowFlag == true  ){
			if (keycode == Volt.KEY_JOYSTICK_LEFT || keycode == Volt.KEY_JOYSTICK_RIGHT ){
					ret = true;
			}
		}
		
		if (this.menu.isMenuShowFlag == false && keycode == Volt.KEY_RETURN){
			DetailMediator.trigger('EVENT_HIDE_MENU_POPUP');
		}
		
		print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + '_onkeyEvent ret is ' + ret);


		return ret;
    },

	/** hide MenuView. 
	* @function hide      
	* @memberof MenuView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
        //this.widget.destroy(this.widget);
        deferred.resolve();
        return deferred.promise;
    },


	/** destroy MenuView
	* @function destroy
	* @param {Widget}  widget          - the root widget of this view
	* @memberof MenuView     
	* @method      
	*/
	//not use now
	destroy : function(widget){
		if(!widget) return;
		

		//delete widget;
		widget.destroy();
		widget = null;
		
	},
});





/** ContentView -BackboneView
* @class 
* @name ContentView
* @augments Backbone.View
*/ 
var ContentView = PanelCommon.BaseView.extend({
    template : DetailTemplate.content,
		
	/** Initialize ContentView. 
	* @function initialize      
	* @param {Model}  model          - model data of this detail news
	* @memberof ContentView
	*/         
    initialize : function(model){
    this.model = model;
    },

	/** render ContentView. there are two types of content tempate
	* @function render      
	* @param {Widget}  parent          - the parent widget of this view
	* @memberof ContentView
	*/         
    render : function(parent){	
        this.setWidget(PanelCommon.loadTemplate(this.template, {
            headline : this.model.get('headline')
        },parent));
		
        return this;

    },

	/** show ContentView. 
	* @function show      
	* @memberof ContentView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
	show: function(){
        this.widget.show();
	},

	/** hide ContentView. 
	* @function hide      
	* @memberof ContentView
	* @return {Object} Return the deferred.promise used for checking if hide is done 	
	*/         
    hide : function(){
        var deferred = Q.defer();
        this.widget.hide();
		//this.destroy(this.widget);
        deferred.resolve();
        return deferred.promise;
    },

		//not use now
		destroy : function(widget){
		if(!widget) return;

		var headline_widget = widget.getChild('content-headline');
		headline_widget.destroy();
		headline_widget.id = '';
		headline_widget = null;

		var price_widget = widget.getChild('content-price');
		price_widget.destroy();
		price_widget.id = '';
		price_widget = null;

		var name_widget = widget.getChild('content-name');
		name_widget.destroy();
		name_widget.id = '';
		name_widget = null;
		
		//delete widget;
		widget.destroy();
		widget = null;
		
	},

});




/** RelatedItemView -BackboneView
* @class 
* @name RelatedItemView
* @augments Backbone.View
*/ 
var ListView = PanelCommon.BaseView.extend({
	/** Initialize RelatedItemView. 
	* @function initialize      
	* @memberof RelatedItemView
	*/         
    initialize : function(){
    },

	/** render RelatedItemView. 
	* @function render      
	* @param {Widget}  parent          - the root widget of this view
	* @memberof RelatedItemView
	*/         
    render : function(parent){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');

		//use resizeablelist to render related list
		this.grid = __initGrid(parent);
		this.setWidget(this.grid);
		//print("setItems");
        this.grid.setItems(this.grid.items, true);

        Volt.Nav.reload();
        return this;
    },

	
	/** update RelatedItemView. 
	* @function update      
	* @memberof RelatedItemView
	*/         
	update:function(){
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        this.grid.setItems(this.grid.items, true);
    },

    events: {
        //'NAV_SELECT':'onSelect',
        'NAV_FOCUS':'onFocus',
        'NAV_BLUR':'onBlur'
    },

    onSelect: function(widget) {
    },

	/** focus RelatedItemView. 
	* @function onFocus      
	* @param {Widget}  parent          - the target widget need to be focused
	* @memberof RelatedItemView
	*/         
    onFocus: function(widget) {
		widget.setFocus();
    },

	/** blur RelatedItemView. 
	* @function onBlur      
	* @param {Widget}  parent          - the target widget need to be killed focus
	* @memberof RelatedItemView
	*/         
    onBlur: function(widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        widget.killFocus();
    }
});


/** init related news list and set callback function
* @function __initGrid      
* @param {Widget}  parent          - the parent widget which list should created on
*/         
function __initGrid(parent) {
	print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');

	var grid = PanelCommon.loadTemplate(DetailTemplate.list,null,parent);

	// Item size array for grid
	var arrItems = [];
    for (i = 0; i < DetailTemplate.LIST_ITEM_NUM; ++i) {
	        arrItems.push({
	            width:1,
	            height:1,
	            id:DetailTemplate.LIST_ITEM_ID
	        });
        }
    grid.items = arrItems;
    
	/** callback function of related list,create UI element on each list item
	* @function ifItemLoaded      
	* @param {String}  index             - the index num of each list item
	* @param {Widget}  parent          - the parent widget which UI element should created on
	*/         
    grid.ifItemLoaded = function(index, width, height, id) {
        var widget = this.getReuseableWidget(id);
        if(widget === undefined) {
            widget = new Widget(
            {
                x:0,
                y:0,
                width:width,
                height:height,
            })
            this.normalizeWidget(widget, id);
            __CreateAppItem(index, widget, appCollection.models[index]);
        }
        else{
            __updateAppItem(widget, appCollection.models[index]);
        }
        
        return widget;
    };

	/** callback function of related list,call it when press list item
	* @function ifItemPress      
	* @param {String}  index             - the index num of each list item
	* @param {Widget}  parent          - the parent widget which UI element should created on
	* @return {Widget} Return the list widget 	
	*/         
	grid.ifItemPress  = function(index, widget) {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + index);
		if (index >= 0){
			Backbone.history.setCache({focusIndex: index,focusType:'list_type'});
			Backbone.history.navigate('detail/' + appCollection.at(index).get('id'), {trigger: true});

		}
		else{
			print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' +  'index is invalid');
		}
	};
    
    // Attributes
    grid.itemScale = {x:DetailTemplate.LIST_ITEM_SCALE, y:DetailTemplate.LIST_ITEM_SCALE};
    grid.focusMode = grid.FOCUS_MODE_3D;
    grid.nAniTimeMove = DetailTemplate.LIST_ANI_TIME;    
    grid.color = {r:0xf2, g:0xf2, b:0xf2};
    grid.alwaysScaleFromCenter = true;
    return grid;
}



/** create each list item
* @function __CreateAppItem      
* @param {String}  index             - the index num of each list item
* @param {Widget}  parent          - the parent widget which UI element should created on
* @param {Model}  model            - news data
*/         
function __CreateAppItem(index, widget, model) {

    var mustache = {
        imgUrl: model.get('thumbnail'),
        title: model.get('headline'),
    };
    
    PanelCommon.loadTemplate(DetailTemplate.listitem, mustache, widget);

	var randomColor = '#'+'0123456789abcdef'.split('').map(function(v,i,a){
            return i>5 ? null : a[Math.floor(Math.random()*16)] }).join('');
        widget.color = Volt.hexToRgb(randomColor);

}


/** update each list item
* @function __updateAppItem      
* @param {Widget}  parent          - the parent widget which UI element should created on
* @param {Model}  model            - news data
*/         
function __updateAppItem(widget, model) {
    if(widget){
        widget.getChildById(DetailTemplate.LIST_ITEM_THUMBNAIL).src = model.get('thumbnail');
        widget.getChildById(DetailTemplate.LIST_ITEM_TITLE).getChild(0).text = model.get('headline');
    }
}

exports = DetailView;
