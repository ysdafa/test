var BaseContentView = Volt.require('app/views/main-base-content-view.js');

MainWhatsNewView = BaseContentView.extend({
    // Add whatever you like here
    whatsNewId: 'C0020',
    
    getCategoryId:function(){ 
        return this.whatsNewId;
    }
});

exports = MainWhatsNewView;
