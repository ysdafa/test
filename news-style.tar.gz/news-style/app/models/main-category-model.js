/**
 * @author Wang Xiaojun (xiaojun.wang@samsung.com)
 * @fileoverview Backbone Model
 * @date 2014/08/08
 * 
 * @version 0.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require("modules/backbone.js");
var LocalCache = Volt.require('app/controller/local-cache.js');

/**
 * Model of single category 
 */
var CategoryModel = Backbone.Model.extend({
    defaults: {
        no: null,
        name: null,     // Category Name
        id: null,       // Category Id
        order: null
    }
});

/**
 * Collection of Categories 
 */
var CategoryCollection = Backbone.Collection.extend({
    model: CategoryModel
});

/**
 * Model of Category List. Exports 
 */
var MainCategoryModel = Backbone.Model.extend({
    defaults: {
        stat: null,
        category_list_cnt: 0,
        category_list: new CategoryCollection(),
    },

/*    
    initialize: function() {
    },
*/
    fetch: function(options) {
        var that = this;
/*        
        LocalCache.getCategories().then(function(data) {
            that.set('stat', data.stat);
            that.set('category_list_cnt', data.category_list_cnt);
            that.get('category_list').reset(data.category_list);
        }, function (data) {
            Volt.log('Error: LocalCache.getCategories(), err: ' + data.err);
        });
*/
	// set dummy data of 'game main categories' to avoid case with error response from server
	var category_list = [ {"no":"1","name":"Spotlight","id":"C0010"},{"no":"2","name":"Brand Zone","id":"C0020"},{"no":"3","name":"Most Popular","id":"C0030"},{"no":"4","name":"What`s New","id":"C0040"},{"no":"5","name":"Top Grossing","id":"C0050"},{"no":"6","name":"Genre","id":"C0060"},{"no":"7","name":"My Page","id":"C0070"}];
	this.get('category_list').reset( category_list );

    },
    
    ////////////////////////////////////
});

exports = new MainCategoryModel();



/*
var data1 = '{"stat" : "ok","category_list_cnt":"7",';
var data2 = '"category_list":[{"no":"1","name":"Spotlight","id":"C0010","order":"1"},{"no":"2","name":"Brand Zone","id":"C0020","order":"2"},';
var data3 = '{"no":"3","name":"Most Popular","id":"C0030","order":"3"},{"no":"4","name":"What\'s New","id":"C0040","order":"4"},';
var data4 = '{"no":"5","name":"Top Grossing","id":"C0050","order":"5"},{"no":"6","name":"Genre","id":"C0060","order":"6"},';
var data5 = '{"no":"7","name":"My Page","id":"C0070","order":"7"}]}';
var _data = data1 + data2 + data3 + data4 + data5;
*/

/*
        if (options.sort) {
            var category_list = this.get('category_list');
            if (options.sort == 'name') {
                category_list.comparator = 'name';
                category_list.sort();
            }
            else if (options.sort == 'id') {
                category_list.comparator = 'id';
                category_list.sort();
            }
            return;
        }

        var data = JSON.parse(_data);
*/