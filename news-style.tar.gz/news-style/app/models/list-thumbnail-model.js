var Backbone = Volt.require("modules/backbone.js");

/** @lends GamesModel.prototype */
var ListThumbnailModel = Backbone.Model.extend({
    defaults: {
        imgUrl: null,       // URL of Thumbnail Image
        rcolor: null,       // Representative Color
        title: null,        // Title of Game
        sourceid: null,
    },
});
exports = ListThumbnailModel;