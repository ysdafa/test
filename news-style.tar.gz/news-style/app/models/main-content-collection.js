
var Backbone = Volt.require("lib/volt-backbone.js");

//
var GameItemModel = Volt.require('app/models/game-item-model.js');

var MainContentCollection = Backbone.Collection.extend({
    model: GameItemModel,

    fetch: function(options) {
        if (!options || !options.categoryId) {
            return;
        }
        var id = options.categoryId;
        
        switch (id) {
        case 'C0010':
            this.reset(__gamesItemList);
            break;
        case 'C0011':
            this.reset(__gamesItemList);
            break;
        default:
            this.reset(__gamesItemList);
            break;
        }
    },
    
});

exports = new MainContentCollection();



var __gamesItemList = [
{
    imgUrl:"images/1080/games/1.jpg",
    rcolor:{r:82, g:72, b:36},
    title:'No Man Land',
    sourceid : 415728,
},
{
    imgUrl:"images/1080/games/2.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
    sourceid : 415677,

},
{
    imgUrl:"images/1080/games/3.jpg",
    rcolor:{r:51, g:97, b:255},
    title:'Tom & Jerry',
    sourceid : 415672,
},
{
    imgUrl:"images/1080/games/4.jpg",
    rcolor:{r:108, g:233, b:133},
    title:'Reloaded',
    sourceid : 415664,
},
{
    imgUrl:"images/1080/games/5.jpg",
    rcolor:{r:0, g:152, b:135},
    title:'Lord of the Rings',
    sourceid : 415660,

},
{
    imgUrl:"images/1080/games/6.jpg",
    rcolor:{r:171, g:171, b:169},
    title: 'Death Race',
    sourceid : 415646,
},
{
    imgUrl:"images/1080/games/7.jpg",
    rcolor:{r:0, g:0, b:0},
    title:'The Oxford Murders',
    sourceid : 415640,
},
{
    imgUrl:"images/1080/games/8.jpg",
    rcolor:{r:138, g:129, b:194},
    title:'Titanic',
    sourceid : 415635,
},
{
    imgUrl:"images/1080/games/9.jpg",
    rcolor:{r:6, g:25, b:31},
    title:'Pirates of the Caribbean',
    sourceid : 415612,
},
{
    imgUrl:"images/1080/games/10.jpg",
    rcolor:{r:9, g:40, b:68},
    title:'Ra One',
    sourceid : 415610,
},
{
    imgUrl:"images/1080/games/1.jpg",
    rcolor:{r:82, g:72, b:36},
    title:'No Man Land',
    sourceid : 415600,
},
{
    imgUrl:"images/1080/games/2.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
    sourceid : 415604,
},
{
    imgUrl:"images/1080/games/3.jpg",
    rcolor:{r:51, g:97, b:255},
    title:'Tom & Jerry',
    sourceid : 415575,
},
{
    imgUrl:"images/1080/games/4.jpg",
    rcolor:{r:108, g:233, b:133},
    title:'Reloaded',
    sourceid : 415503,
},
{
    imgUrl:"images/1080/games/5.jpg",
    rcolor:{r:0, g:152, b:135},
    title:'Lord of the Rings',
    sourceid : 415362,
},
{
    imgUrl:"images/1080/games/6.jpg",
    rcolor:{r:171, g:171, b:169},
    title: 'Death Race',
    sourceid : 415545,

},
{
    imgUrl:"images/1080/games/7.jpg",
    rcolor:{r:0, g:0, b:0},
    title:'The Oxford Murders',
    sourceid : 415543,
},
{
    imgUrl:"images/1080/games/8.jpg",
    rcolor:{r:138, g:129, b:194},
    title:'Titanic',
    sourceid : 415502,
},
{
    imgUrl:"images/1080/games/9.jpg",
    rcolor:{r:6, g:25, b:31},
    title:'Pirates of the Caribbean',
    sourceid : 415485,
},
{
    imgUrl:"images/1080/games/10.jpg",
    rcolor:{r:9, g:40, b:68},
    title:'Ra One',
    sourceid : 415467,
},
];