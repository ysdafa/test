var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require("modules/underscore.js")._;

var NewsModel = Backbone.Model.extend(
    /** @lends NewsModel.prototype */
    {
        parse: function (rawitem) {
            try {
                var sNewsType, sThumbnail, oRelatedMap = {};

                if (rawitem.video && rawitem.video.length > 0) {
                    sNewsType = 'video';
                    sThumbnail = rawitem.video[0].thumbnail;
                } else if (rawitem.images && rawitem.images.length > 0 && rawitem.images[0].url != null) {
                    sNewsType = 'photo';
                    sThumbnail = rawitem.images[0].url;
//					print("rawitem.images[0].url is ",rawitem.images[0].url);
                } else {
                    sNewsType = 'text';
                    sThumbnail = Volt.getRemoteUrl('images/1080/common/ch_default_image_ll_02.jpg');
					//sThumbnail = 'www.baidu.com';
                }

                var teamIDs = [];
                var leagueIDs = [];
                _.each(rawitem.categories, function (category) {
                    if (category.type == 'team') {
                        oRelatedMap[category.teamId] = true;
                        teamIDs.push(category.teamId);
                    } else if (category.type == 'league') {
                        leagueIDs.push(category.leagueId);
                    }
                });

                // General Data
                var item = {
                    'id': rawitem.id,
                    'headline': rawitem.title || rawitem.headline,
                    'thumbnail': sThumbnail,
                    'images': rawitem.images,
                    'contents': rawitem.story,
                    'published': rawitem.published,
                    'related': oRelatedMap,
                    'type': sNewsType,
                    'category': {
                        'team': teamIDs,
                        'league': leagueIDs
                    },
					'source': rawitem.source,
					'modifytime': rawitem.lastModified,
					
                };

                // Video Specific Data
                if (item.type == 'video') {
                    item.video_id = rawitem.video[0].id;
                    item.videoCredit = rawitem.video[0].credit || null;

                    if (rawitem.video[0].links && rawitem.video[0].links.web && rawitem.video[0].links.web.href) {
                        if (rawitem.video[0].links.web.href.indexOf('.mp4') > -1) {
                            item.video_url = rawitem.video[0].links.web.href;
                        }
                    }
                }

                return item;

            } catch (e) {
                console.error('[newsCollection.js] parse error : ' + e);
                return false;
            }

        }
    });
exports = NewsModel;