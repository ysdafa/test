/**
 * @author Wang Xiaojun (xiaojun.wang@samsung.com)
 * @fileoverview Backbone Model For Main View and its sub Views
 * @date 2014/07/21
 *
 * @version 1.4
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),
    //
    categoryModel = Require('app/models/main-category-model.js'),
    contentCollection = Require('app/models/main-content-collection.js'),
    
////////////////////////////////////////////////////////////////////////////////
// [NEW 1.6] Exmaple to use Local Storage
    localStorage = Require("lib/volt-local-storage.js");


// At the beginning, category is changed to update first content

var MainModel = Backbone.Model.extend({
    lastCategory: -1, // index of last selected category
    defaults: {
        category_collection: categoryModel.get('category_list'),
        content_collection: contentCollection,
        category: -1, // index of current selected category
        
        accountName: null
    },

    initialize: function () {
        this.listenTo(this.get('category_collection'), 'reset', this.onCategoryReset);
        this.on('change:accountName', this.onAccountNameChange);
    },

    fetch: function (options) {
        categoryModel.fetch(options); // fetch categories
/*
        var accountName = localStorage.getItem('category_list');
        if (accountName) {
            this.set('accountName', accountName);
        }
*/
    },

    ////////////////////////////////////
    // Controller
    resetCategory: function () {
        this.lastCategory = -1;
        this.set('category', -1);
    },

    isCategoryChanged: function (index) {
        return this.get('category') != this.lastCategory;
    },
    
    onCategoryReset: function (collection) {
        this.selectCategory(0);
        this.stopListening(this.category_collection);
        
        var accountName = this.get('accountName');
        accountName ? this.onAccountNameChange() : undefined;
    },
    
    onAccountNameChange: function () {
        Volt.log();
        var model = this.get('category_collection').findWhere({id: 'C0070'});
        model ? model.set('name', this.get('accountName')) : undefined;
    },
    
    ////////////////////////////////////
    // Public
    selectCategory: function (index) {
        Volt.log('index: ' + index);

        if (index < 0) { // Reset Model
            this.resetCategory();
            return;
        }
        var category = this.get('category');

        if (index == category) {
            return;
        }
        //this.set('lastCategory', this.category);
        this.lastCategory = category;
        this.set('category', index); // Change <category> will invoke Navigation in main-view.js

        contentCollection.fetch({categoryId: this.getCategoryId(index)});
    },
        
    isContentCollectionReady: function () {
        if (!this.isCategoryChanged() || contentCollection.length <= 0) {
            return false;
        }
        return true;
    },

    /**
     * Get current Category Id from Category Collection
     * If index is provided, return category ID of index
     */
    getCategoryId: function (index) {

        if (index == undefined) {
            index = this.get('category');
        }

        var categoryCollection = this.get('category_collection');
        var model = categoryCollection.at(index);

        if (model) {
            return model.get('id');
        }
    },
    
    sortCategory: function (options) {
        /*
        this.resetCategory();
        categoryModel.fetch(options.category);
        */
    },

    updateAccountName: function (accountName) {
        this.set('accountName', accountName);
//        localStorage.setItem('accountName', accountName);
    }
});


exports = new MainModel();
