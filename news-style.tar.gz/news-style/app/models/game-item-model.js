/**
 * This is Model of a single Game Item
 */

var Backbone = Volt.require('lib/volt-backbone.js');

/** @lends GamesModel.prototype */
var GameItemModel = Backbone.Model.extend({
    defaults: {
        imgUrl: null,       // URL of Thumbnail Image
        rcolor: null,       // Representative Color
        title: null,        // Title of Game
        sourceid: null,
    },
});
exports = GameItemModel;