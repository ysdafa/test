
var Backbone = Volt.require("modules/backbone.js");


var ListThumbnailModel = Volt.require('app/models/game-item-model.js');

var Voltapi = Volt.require("modules/voltapi.js");

var ListThumbnailCollection = Backbone.Collection.extend({
    model: ListThumbnailModel,
    
    mode: {
        MODE_TEST: 20,
        NEWSON_DATA: 1,
    },
        
    fetch: function(mode) {
        if (mode == this.mode.MODE_TEST) {
            this.reset(_List);
        }
        else if(mode == this.mode.NEWSON_DATA){
            //test url to fetch newson data
            var url = "https://api.digitalhomeservices.yahoo.com/V0_3/GetYTodayMoreNews?yt_state=1;1406214721&page=2&appid=com.samsung.panels.tv.ytoday&contextid=samsung.main.2014&man=SEC&model=14_X14_BT&deviceid=SHCJYGR247DHC&swversion=T-MST14DEUC-0721.0&region=BR&language=pt&res=1920x1080&ts=1398135176&format=json&sig=db75ec884c761be41c6fc3e8aa43111e";
            Voltapi.rest.init();
            Voltapi.rest.sendAsync("GET", url,
                function(data, status, response)
                {
                    var parseData = JSON.parse(data);
                    var listData = [];
                    for(var i = 0; i < parseData.tiles.length; i++)
                    {
                        listData[i] = {};
                        listData[i].imgUrl = parseData.tiles[i].img_url;
                        listData[i].title = parseData.tiles[i].title;
                        listData[i].subTitle = __calTime(parseData.tiles[i].timestamp);
                        listData[i].rcolor = _List[i].rcolor;
                        
                        this.reset(listData);
                    }
                }.bind(this),
                function(response, status, exception)
                {
                    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+' error response:'+response);
                    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+' error exception:'+exception);
                    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+' error status:'+status);
                },
                function(response, status)
                {
                    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+' complete response:'+response);
                    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+' complete status:'+status);
                }
           );
        }
    },
});

exports = new ListThumbnailCollection;

function __calTime(totalSec)
{
    var year = 1970;
    var month = 1;
    var day = 1;
    var hour = 0;
    var min = 0;
    var sec = 0;
    
    var monthDay = [31,28,31,30,31,30,31,31,30,31,30,31];
    
    while(totalSec > 86400 * 365 + (__isLeap(year) ? 86400 : 0)){
        year++;
        totalSec = totalSec - (86400 * 365) - (__isLeap(year) ? 86400 : 0);
    }
    while(totalSec > 86400){
        day++;
        totalSec -= 86400;
    }
    while(day > monthDay[month]){
        if(__isLeap(year) && month == 2 && day == 29){
            break;
        }
        day -= monthDay[month];
        month++;
    }
    hour = Math.floor(totalSec / 3600);
    min = Math.floor((totalSec % 3600) / 60);
    sec = Math.floor(totalSec % 60);

    return ("" + year + "/" + month + "/" + day + "  " + hour + ":" + min + ":" + sec);
}

function __isLeap(year)
{
    return ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) 
}

var _List = [
{
    imgUrl:"images/1080/games/1.jpg",
    rcolor:{r:82, g:72, b:36},
    title:'No Man Land',
    subTitle:'No Man Land',
    sourceid : 415728,
},
{
    imgUrl:"images/1080/games/2.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
    subTitle:'Iron Man',
    sourceid : 415677,

},
{
    imgUrl:"images/1080/games/3.jpg",
    rcolor:{r:51, g:97, b:255},
    title:'Tom & Jerry',
    subTitle:'Tom & Jerry',
    sourceid : 415672,
},
{
    imgUrl:"images/1080/games/4.jpg",
    rcolor:{r:108, g:233, b:133},
    title:'Reloaded',
    subTitle:'Reloaded',
    sourceid : 415664,
},
{
    imgUrl:"images/1080/games/5.jpg",
    rcolor:{r:0, g:152, b:135},
    title:'Lord of the Rings',
    subTitle:'Lord of the Rings',
    sourceid : 415660,

},
{
    imgUrl:"images/1080/games/6.jpg",
    rcolor:{r:171, g:171, b:169},
    title: 'Death Race',
    subTitle: 'Death Race',
    sourceid : 415646,
},
{
    imgUrl:"images/1080/games/7.jpg",
    rcolor:{r:0, g:0, b:0},
    title:'The Oxford Murders',
    subTitle:'The Oxford Murders',
    sourceid : 415640,
},
{
    imgUrl:"images/1080/games/8.jpg",
    rcolor:{r:138, g:129, b:194},
    title:'Titanic',
    subTitle:'Titanic',
    sourceid : 415635,
},
{
    imgUrl:"images/1080/games/9.jpg",
    rcolor:{r:6, g:25, b:31},
    title:'Pirates of the Caribbean',
    subTitle:'Pirates of the Caribbean',
    sourceid : 415612,
},
{
    imgUrl:"images/1080/games/10.jpg",
    rcolor:{r:9, g:40, b:68},
    title:'Ra One',
    subTitle:'Ra One',
    sourceid : 415610,
},
{
    imgUrl:"images/1080/games/1.jpg",
    rcolor:{r:82, g:72, b:36},
    title:'No Man Land',
    subTitle:'No Man Land',
    sourceid : 415600,
},
{
    imgUrl:"images/1080/games/2.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
    subTitle:'Iron Man',
    sourceid : 415604,
},
{
    imgUrl:"images/1080/games/3.jpg",
    rcolor:{r:51, g:97, b:255},
    title:'Tom & Jerry',
    subTitle:'Tom & Jerry',
    sourceid : 415575,
},
{
    imgUrl:"images/1080/games/4.jpg",
    rcolor:{r:108, g:233, b:133},
    title:'Reloaded',
    subTitle:'Reloaded',
    sourceid : 415503,
},
{
    imgUrl:"images/1080/games/5.jpg",
    rcolor:{r:0, g:152, b:135},
    title:'Lord of the Rings',
    subTitle:'Lord of the Rings',
    sourceid : 415362,
},
{
    imgUrl:"images/1080/games/6.jpg",
    rcolor:{r:171, g:171, b:169},
    title: 'Death Race',
    subTitle: 'Death Race',
    sourceid : 415545,

},
{
    imgUrl:"images/1080/games/7.jpg",
    rcolor:{r:0, g:0, b:0},
    title:'The Oxford Murders',
    subTitle:'The Oxford Murders',
    sourceid : 415543,
},
{
    imgUrl:"images/1080/games/8.jpg",
    rcolor:{r:138, g:129, b:194},
    title:'Titanic',
    subTitle:'Titanic',
    sourceid : 415502,
},
{
    imgUrl:"images/1080/games/9.jpg",
    rcolor:{r:6, g:25, b:31},
    title:'Pirates of the Caribbean',
    subTitle:'Pirates of the Caribbean',
    sourceid : 415485,
},
{
    imgUrl:"images/1080/games/10.jpg",
    rcolor:{r:9, g:40, b:68},
    title:'Ra One',
    subTitle:'Ra One',
    sourceid : 415467,
},
];

 //test for clips
/*var date  = new Date();
var LocalDate = '';
if(date.getUTCMonth()<9)
{
    LocalDate = '0'+(date.getUTCMonth()+1);
}
else
{
    LocalDate = ''+(date.getUTCMonth()+1);
}
LocalDate = LocalDate+date.getUTCDate()+date.getUTCFullYear()+'T'+date.getUTCHours()+':'+date.getUTCMinutes()+':'+date.getUTCSeconds()+'+08:00';

Voltapi.rest.setContentType('json');
Voltapi.rest.setHeader('ContentLength','100');
Voltapi.rest.setHeader('Country','US');
Voltapi.rest.setHeader('Language','EN');
Voltapi.rest.setHeader('Date',LocalDate.toString());
Voltapi.rest.setSmartTVHeader(true);

Voltapi.rest.sendAsync("GET", "clips/content/v1/categories/1?size=6",
function(data, status, response)
{
    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+'data:'+data);
    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+'status:'+status);
},
function(response, status, exception)
{
    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+'exception:'+exception);
    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+'status:'+status);
},
function(response, status)
{
    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+'exception:'+ response);
    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] '+'status:'+status);
});*/