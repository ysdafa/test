var RatingTemplate = {
    container : {
		//parent:scene,
        type: 'widget',
		custom : {
			'focusable' : true,
			'onKeyEvent' : null
		},
        x: 0 , y: (1080-514)/2, width: 1920, height : 418,
    	color : Volt.hexToRgb('#0a5d88'),
    	opacity: 255 * 0.85,
        children: [
			{
                type : 'image',
                x : (1920 - (46*5 + (57 - 46)*4))/2, y : 418 - 30 - 66 -(41 + 46), width : 46, height : 46,
            },{
                type : 'image',
                x : (1920 - (46*5 + (57 - 46)*4))/2 + 57, y : 418 - 30 - 66 -(41 + 46), width : 46, height : 46,
            },{
                type : 'image',
                x : (1920 - (46*5 + (57 - 46)*4))/2+ 57*2, y : 418 - 30 - 66 -(41 + 46), width : 46, height : 46
            },{
                type : 'image',
                x : (1920 - (46*5 + (57 - 46)*4))/2+ 57*3, y : 418 - 30 - 66 -(41 + 46), width : 46, height : 46
            },{
                type : 'image',
                x : (1920 - (46*5 + (57 - 46)*4))/2+ 57*4, y : 418 - 30 - 66 -(41 + 46), width : 46, height : 46
            },	{
		        type : 'text',
				id: 'title-text',
		        x : (1920 - 1122)/2, y: 0, width : 1122, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        text : 'Rating',
		        font : '46px',
	    	},{
				type: 'widget',
				id: 'splite-line',
		    	x: 0, y: 96, width: 1920, height : 1,
		    	color : Volt.hexToRgb('#ffffff'),
		    	opacity: 255 * 0.3,
			},{
		        type : 'text',
				id: 'body-text',
		        x : (1920 - 1122)/2, y: 96  + 12, width : 1122, height : 40,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        text : 'RatingPopupRatingRatingPopupRatingRatingPopupRatingRatingPopupRating',
		        font : '34px',
				ellipsize : true,                
	    	},{
            	id: 'ok-btn',
                type : 'Button_Generic',
	            color : Volt.hexToRgb('#ffffff',0),
                //custom: { 'focusable': true },
                x:(1920- (270*2 + (282-270)))/2, y:418 - 30 - 66, width:270, height:66
            },{
                type : 'Button_Generic',
				id: 'cancel-btn',
				parent:'{{tempBG}}',
	            color : Volt.hexToRgb('#ffffff',0),
                //custom: { 'focusable': true },
                x:(1920- (270*2 + (282-270)))/2 + 282 , y:418 - 30 - 66, width:270, height:66
            },{
                type : 'Button_Generic',
				id : 'left-btn',
				parent:'{{tempBG}}',
	            color : Volt.hexToRgb('#ffffff',0),
                //custom: { 'focusable': true },
                x: (1920 - (46*5 + (57 - 46)*4))/2 - 60 - 23 , y:418 - 30 - 66 -(32 + 62), width:60, height:62
            },{
                type : 'Button_Generic',
				id : 'right-btn',
				parent:'{{tempBG}}',
	            color : Volt.hexToRgb('#ffffff',0),
                //custom: { 'focusable': true },
                x:(1920 - (46*5 + (57 - 46)*4))/2+ 57*4 + 46 + 23, y:418 - 30 - 66 -(32 + 62), width:60, height:62
            },

		]			
    },

}

exports = RatingTemplate;

