var TVShowDetailTemplate = {
    LIST_ITEM_SCALE: 1.1,
    LIST_ITEM_WIDTH_SIZE: 1.15,
    LIST_ITEM_HEIGHT_SIZE: 1.15,
    LIST_ITEM_NUM: 20,
    LIST_ANI_TIME: 300,

    LIST_ITEM_ID:'cellID',
    LIST_ITEM_THUMBNAIL:'thumbnail',
    LIST_ITEM_TITLE:'title',

    content: {
        type : 'widget',
                x : 0, y : 0, width : 1050, height : 278+34*3 - 60,
                color : Volt.hexToRgb('#ffffff',0),
    	children: [
            {
                type : 'text',
				id: 'headline-content',
                x : 0, y: 0, width : 1050, height : 70*2,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#9ed7ff'),
                ellipsize : true,
                text : '{{ headline }}',
                font : '64px',
                singleLineMode: false,
            },
            {
                type : 'text',
				id: 'genre-content',
                x : 0, y: 0+70*2, width : 1050, height : 35,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                ellipsize : true,
                text : 'Genre: genre name',
                font : '30px',
                singleLineMode: true,
            },
            {
                type : 'text',
				id: 'release-content',
                x : 0, y: 0+70*2 + 35 , width : 1050, height : 35,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                ellipsize : true,
                text : 'Release: {{ timestamp }}',
                font : '30px',
                singleLineMode: true,
            },
            {
                type : 'text',
				id: 'director-content',
                x : 0, y: 0+70*2 + 35 + 35, width : 1050, height : 35,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                ellipsize : true,
                text : 'Director: director name | Writer: writer name',
                font : '30px',
                singleLineMode: true,
            },
            {
                type : 'text',
				id: 'description-content',
                x : 0, y: 0+70*2 + 35 + 35 + 35, width : 1050, height : 40*3,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                ellipsize : true,
                text : 'Description: {{description}}',
                font : '30px',
                singleLineMode: false,
            },
            {
                type : 'widget',
				id: 'rating-content',
                x : 0 + 34*5*3 + 35*3, y: 0+70*2 + 35 + 35, width : 34*5, height : 34,
                color : Volt.hexToRgb('#ffffff',0),
                children: [
		            {
		                type : 'image',
		                x: 0, y:  0, width : 34, height : 34,
		                src : Volt.getRemoteUrl('images/1080/04_mt_icon_star_h.png'),
		            },
		            {
		                type : 'image',
		                x: 0+34, y:  0, width : 34, height : 34,
		                src : Volt.getRemoteUrl('images/1080/04_mt_icon_star_h.png'),
		            },
		            {
		                type : 'image',
		                x: 0+34*2, y:  0, width : 34, height : 34,
		                src : Volt.getRemoteUrl('images/1080/04_mt_icon_star_h.png'),
		            },
		            {
		                type : 'image',
		                x: 0+34*3, y:  0, width : 34, height : 34,
		                src : Volt.getRemoteUrl('images/1080/04_mt_icon_star_h.png'),
		            },
		            {
		                type : 'image',
		                x: 0+34*4, y:  0, width : 34, height : 34,
		                src : Volt.getRemoteUrl('images/1080/04_mt_icon_star_h.png'),
		            },

				]
			},
        ]
    },


	button: {
            type : 'widget',
            x : 0 , y: 0, width : 1050, height : 90*2,
            color : Volt.hexToRgb('#ffffff',0),
            children: [
	            {
	            	id: 'watch-btn',
	                type : 'Button_Generic',
		            color : Volt.hexToRgb('#ffffff',0),
	                custom : {'focusable' : true, 'text' : Volt.i18n.t('TV_SID_WATCH')},
	                x: 0, y:  0, width : 200, height : 50,
	            },
	            {
	                type : 'Button_Generic',
					id: 'record-btn',
		            color : Volt.hexToRgb('#ffffff',0),
	                custom : {'focusable' : true, 'text' : Volt.i18n.t('TV_SID_RECORD')},
	                x: 0+250, y:  0, width : 200, height : 50,
	            },
	            {
	                type : 'Button_Generic',
					id : 'rating-btn',
		            color : Volt.hexToRgb('#ffffff',0),
	                custom : {'focusable' : true},
	                x: 0+250+250, y:  0, width : 400, height : 50,
	            },
            	{
		            type : 'widget',
					id: 'rating-widget',
		            x : 0+250+250 , y: 0, width : 400, height : 50,
		            color : Volt.hexToRgb('#ffffff',0),
			        //border : {width : 1, color : {r:255,g:255,b:255,a:204}},
			        children: [
						{
			                type : 'image',
			                x : (400 - 34*5)/2, y : (50-34)/2, width : 34, height : 34
			            },
			            {
			                type : 'image',
			                x: (400 - 34*5)/2+ 34, y:  (50-34)/2, width : 34, height : 34
			            },
			            {
			                type : 'image',
			                x:  (400 - 34*5)/2+ 34*2, y:  (50-34)/2, width : 34, height : 34
			            },
			            {
			                type : 'image',
			                x:  (400 - 34*5)/2+ 34*3, y:  (50-34)/2, width : 34, height : 34
			            },
			            {
			                type : 'image',
			                x:  (400 - 34*5)/2+ 34*4, y:  (50-34)/2, width : 34, height : 34
			            },					
	            	]
            	},
        	 	    
			]
		},



	listtitle:{
        type : 'widget',
                x : 0, y : 0, width : 1920, height : 1080,
                color : Volt.hexToRgb('#ffffff',0),
    	children: [
            {
                type : 'text',
                x : 0, y: 0, width : 1920, height : 40,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#9ed7ff'),
                ellipsize : true,
                text : 'Related List',
                font : '30px',
                singleLineMode: false,
            },
		]
	},

	RelatedGrid:{
        type: 'GridListControl',
		parent:null, 
		width: 1920, 
		height: 240,  
		titleSpace: 0, 
		groupSpace: 0, 
		cellSpace: 0, 
		focusRangeStartOffset: 0, 
		focusRangeEndOffset: 0, 
        custom: {focusable: true,},
	},


    listitem: [
        {
            type: 'image',
            x: 0, y: 0, width: 324, height: 200,
            src: '{{ imgUrl }}',
            custom: {ID:'thumbnail'}
        },
        {
            type: 'widget',
            x: 0, y: 200, width: 324, height: 40,
            color: {r:255, g:255, b:255, a:200},
            custom: {ID:'title'},
            children: [
                {
		            type: 'AutoScrollTextWidget',
                    x: 5, y: 0, width: 324- 5*2, height: 40,
                    font: 'Calibri 16px',
		            color: {r:255, g:125, b:255,a:0},
                    opacity: 255,
                    ellipsize: true,
                    text: '{{ title }}'
                },
            ],
        },
    ],


};

exports = TVShowDetailTemplate;


