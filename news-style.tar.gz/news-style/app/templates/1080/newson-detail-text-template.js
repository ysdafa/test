var DetailTextTemplate = {
    container : {
        type: 'widget',
        x: 0, y: 0, width: 1920-60*2 - 277, height : 1080-(144+63),
        color : Volt.hexToRgb('#ffffff',0),
        children : [
            {
                type : 'widget',
                x : 0, y : 0, width : 1920-60*2 - 277, height : 86 + 36*6 + 20 + 43,
                id : 'detail-info-area',
                color : Volt.hexToRgb('#ffffff', 0),
                children : [
                    {
                        type : 'image',
                        x : 0, y : 20, width : 150, height:43,
                        src : Volt.getRemoteUrl('images/1080/soccer_h_sub_logo_espn.png')
                    },
                    {
                        type : 'text',
                        x : 0 + 150 + 18, y : 22, width : (1920-60*2 - 277) - (150 + 18), height:38,
                        text : '{{timestamp}}',
                        ellipsize : true,
						horizontalAlignment : 'left',                
						verticalAlignment : 'center',                
                        textColor : Volt.hexToRgb('#ffffff', 25),
                        font : '32px'
                    },
                    {
                        type : 'text',
                        x : 0, y : 86, width : (1920-60*2 - 277), height:36*6,
                        text : '{{contents}}',
                        ellipsize : true,
                        textColor : Volt.hexToRgb('#ffffff', 60),
                        font : '28px'
                    },
                    {
                        type : 'image',
                        x : 0, y : 86 + 36*6 + 20, width : 150, height:43,
                        src : Volt.getRemoteUrl('images/1080/soccer_h_sub_logo_espn.png')
                    },
                ]
            },
            {
                type : 'widget',
                x : 0, y : 376+36 , width : 1920-60*2 - 277, height : 1+24+36+8+36*8,
                id : 'detail-fullarticle-area',
                color : Volt.hexToRgb('#ffffff', 0),
                children : [
                    {
                        type : 'widget',
                        x : 0, y: 0, width : 1920-60*2 - 277, height : 1,
				        color : Volt.hexToRgb('#ffffff',15),
                    },
                    {
                        type : 'text',
                        x : 0, y: 25, width : 1920-60*2 - 277, height : 36,
                        horizontalAlignment : 'left',
                        verticalAlignment : 'center',
                        textColor : Volt.hexToRgb('#ffffff', 25),
                        ellipsize : true,
                        text : 'Full Article',
                        font : '28px'
                    },
                    {
                        type : 'text',
                        x : 0 , y : 25 + 36 + 8, width : 1920-60*2 - 277, height:36*8,
                        text : '{{fullarticle}}',
                        textColor : Volt.hexToRgb('#ffffff', 25),
                        font : '36px'
                    },
                    {
                        type : 'text',
                        x : 0 , y : 25 + 36 + 8 + 36*8 + 36, width : 690, height:32,
                        text : '(c)Coypright Year Owner\'s Name',
                        textColor : Volt.hexToRgb('#ffffff', 10),
                        font : '26px'
                    }

                ]
            }
        ]
    },
}

exports = DetailTextTemplate;
