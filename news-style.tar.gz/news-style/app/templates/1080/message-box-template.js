var MessageBoxTemplate = {
	
	msgbox_template_example1:
	{
		type: 'widget',
	    x: 660, y: 340, width: 600, height : 400,
	    color : Volt.hexToRgb('#000000',255),
	    border : {width : 5, color : {r:0,g:0,b:255,a:255}},
	    
		children: [
	    	{
		        type : 'text',
				id : 'message',
		        x : 0, y: 100, width : 600, height : 100,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#FFFFFF', 255),
		        text : 'This is a msgbox example',
		        font : '30',
	    	},
			{
				type : 'widget',
				id : 'btn1',
				custom:{'btntext': Volt.i18n.t('COM_SID_OK')},
				x : 225, y : 250, width : 150, height : 80,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },
			
	msgbox_template_example2:
	{
		type: 'widget',
	    x: 660, y: 340, width: 600, height : 400,
	    color : Volt.hexToRgb('#000000',255),
	    border : {width : 5, color : {r:0,g:0,b:255,a:255}},
	    
		children: [
	    	{
		        type : 'text',
				id : 'message',
		        x : 0, y: 100, width : 600, height : 100,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#FFFFFF', 255),
		        color : Volt.hexToRgb('#000000',255),
		        text : 'This is a msgbox example',
		        font : '30',
	    	},
			{
				type : 'widget',
				id : 'btn1',
				custom:{'btntext': Volt.i18n.t('TV_SID_DONE')},
				x : 100, y : 250, width : 150, height : 80,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'btn2',
				custom:{'btntext': Volt.i18n.t('COM_SID_CANCEL')},
				x : 350, y : 250, width : 150, height : 80,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },

	msgbox_template_example3:
	{
		type: 'widget',
	    x: 660, y: 340, width: 600, height : 400,
	    color : Volt.hexToRgb('#000000',255),
	    border : {width : 5, color : {r:0,g:0,b:255,a:255}},
	    
		children: [
	    	{
		        type : 'text',
				id : 'message',
		        x : 0, y: 100, width : 600, height : 100,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#FFFFFF', 255),
		        text : 'This is a msgbox example',
		        font : '30',
	    	},
			{
				type : 'widget',
				id : 'btn1',
				custom:{'btntext': Volt.i18n.t('COM_SID_OK')},
				x : 37, y : 250, width : 150, height : 80,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'btn2',
				custom:{'btntext': Volt.i18n.t('TV_SID_DONE')},
				x : 224, y : 250, width : 150, height : 80,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'btn3',
				custom:{'btntext': Volt.i18n.t('COM_SID_CANCEL')},
				x : 410, y : 250, width : 150, height : 80,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },
};

exports = MessageBoxTemplate;


