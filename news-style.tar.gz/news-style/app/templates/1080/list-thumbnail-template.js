var ListThumbnailTemplate = {

    LIST_ITEM_SCALE: 1.1,
    LIST_ITEM_WIDTH_SIZE: 1,
    LIST_ITEM_HEIGHT_SIZE: 1,
    LIST_ITEM_NUM: 20,
    LIST_ANI_TIME: 300,

    LIST_ITEM_ID:'cellID',
    LIST_ITEM_THUMBNAIL:'thumbnail',
    LIST_ITEM_TITLE:'title',
    LIST_ITEM_SUBTITLE:'subTitle',
    
	title:{
    	type : 'widget',
		x : 0, y : 0, width : 1880, height : 200,
		color : Volt.hexToRgb('#ffffff',0),
    	children : [
		    {
		        type : 'text',
		        x : 0, y: 0, width : 1880, height : 100,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#00FF00', 255),
		        text : 'Screen Title',
		        font : '66px'
			},
			{
		        type : 'text',
		        x : 0, y: 100, width : 1880, height : 100,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#0000FF', 255),
		        text : 'Additional Instructions',
		        font : '44'
	    	}
		]
    },

	gridList:{
        type: 'cmGridList',
		parent:null, 
		width: 1880, 
		height: 330,  
		titleSpace: 0, 
		groupSpace: 0, 
		cellSpace: 0, 
		focusRangeStartOffset: 0, 
		focusRangeEndOffset: 0, 
        custom: {focusable: true,},
	},

		/*
    item: [
        {
            type: 'image',
            x: 0, y: 0, width: 300, height: 240,
            src: '{{ imgUrl }}',
            custom:{ID:'thumbnail'}
        },
        {
            type: 'widget',
            x: 0, y: 240, width: 300, height: 330-240,
            color: {r:255, g:255, b:255, a:200},
            custom: {ID:'title'},
            children: [
		        {
		            type: 'AutoScrollTextWidget',
		            x: 5, y: 0, width: 290, height: 40,
		            font: '30px',
		            color: {r:255, g:125, b:255,a:0},
		            opacity: 255,
		            ellipsize: true,
		            text: '{{ title }}',
		            custom:{ID:'title'}
		        },
		        {
		            type: 'text',
		            x: 10, y: 293-250, width: 290, height: 30,
		            font: '20px',
		            textColor: {r:0, g:255, b:0},
		            opacity: 255,
		            ellipsize: true,
		            singleLineMode: true,
		            text: '{{ subTitle }}',
		            custom:{ID:'subTitle'}
		        }
            ],
        },
		
    ],
*/

    item: [
        {
            type: 'Thumbnail',
			visibleStyles: (0x01 | 0x20),
			image:{src: '{{ imgUrl }}',
				width: 300,
				height: 240},
			information:{
				x: 0,
				y: 240,
				width: 300,
				height: 330-240,
				text1:{
					x:5,
					y:0,
					width:290,
					height: 40,
					font: '30px',
					text: '{{ title }}',
					singleLineMode: true},
				text2:{
					x:10,
					y:293-250,
					width:290,
					height: 30,
					font: '20px',
					text: '{{ subTitle }}',
					singleLineMode: true},
				},	
			},

    ],



	button: {
        type : 'widget',
        x : 0, y : 0, width : 1880, height : 150,
        color : Volt.hexToRgb('#ffffff',0),
        children: [
            {
                type : 'winsetButton',
                id : 'cancel',
                custom : {'focusable' : true},
                x : 480, y : 50, width : 300, height : 80,
            	style: 1,
				buttonType: 1,
				text: Volt.i18n.t('COM_SID_CANCEL'),
				textWidth: 300,
            },
			{
                type : 'winsetButton',
                id : 'done',
                custom : {'focusable' : true},
                x : 1120, y : 50, width : 300, height : 80,
            	style: 1,
				buttonType: 1,
				text: Volt.i18n.t('TV_SID_DONE'),
				textWidth: 300,
            }		
        ]
    },


					/*

    button: {
        type : 'widget',
        x : 0, y : 0, width : 1880, height : 150,
        color : Volt.hexToRgb('#ffffff',0),
        children: [
            {
                type : 'Button_Generic',
                id : 'cancel',
                custom : {'focusable' : true, 'text' : Volt.i18n.t('COM_SID_CANCEL')},
                x : 480, y : 50, width : 300, height : 80
                //color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'Button_Generic',
                id : 'done',
                custom : {'focusable' : true, 'text' : Volt.i18n.t('TV_SID_DONE')},
                x : 1120, y : 50, width : 300, height : 80
                //color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    }
    */
/*
	button:
	{
    	type : 'widget',
		x : 0, y : 0, width : 1880, height : 150,
		color : Volt.hexToRgb('#ffffff',0),
			
		children: [
			{
				type : 'widget',
				id : 'cancel',
				custom : {'focusable' : true,},
				x : 480, y : 50, width : 300, height : 100,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'done',
				custom : {'focusable' : true,},
				x : 1120, y : 50, width : 300, height : 100,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    }
*/
};

exports = ListThumbnailTemplate;


