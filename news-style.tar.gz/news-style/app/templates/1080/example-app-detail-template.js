var AppDetailTemplate = {
    LIST_ITEM_SCALE: 1.1,
    LIST_ITEM_WIDTH_SIZE: 1.15,
    LIST_ITEM_HEIGHT_SIZE: 1.15,
    LIST_ITEM_NUM: 20,
    LIST_ANI_TIME: 300,

    LIST_ITEM_ID: 'cellID',
    LIST_ITEM_THUMBNAIL: 'thumbnail',
    LIST_ITEM_TITLE: 'title',

    content: {
        type : 'widget',
                x : 0, y : 0, width : 560, height : 1080 - (60 + 420 + 20 + 90 + 20 ) - 60,
                color : Volt.hexToRgb('#ffffff',0),
    	children: [
            {
                type : 'text',
				id : 'content-headline',
                x : 0, y: 0, width : 560, height : 70,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#9ed7ff'),
                ellipsize : true,
                text : '{{ headline }}',
                font : '64px',
            },
            {
                type : 'text',
				id : 'content-price',
                x : 0, y: 0+70*2, width : 560, height : 35,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                ellipsize : true,
                text : 'Price | Size:xx MB | Updated:yyyy-mm-dd',
                font : '30px',
                singleLineMode: true,
            },
            {
                type : 'text',
				id : 'content-name',
                x : 0, y: 0+70*2 + 35 , width : 560, height : 35,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                ellipsize : true,
                text : 'Developer Name | Ratings | Version #',
                font : '30px',
                singleLineMode: true,
            },
        ]
    },

	button: {
            type : 'widget',
            x : 0 , y: 0, width : 1050, height : 90*2,
            color : Volt.hexToRgb('#ffffff',0),
            children: [
	            {
	            	id: 'detail-btn',
	                type : 'Button_Generic',
		            color : Volt.hexToRgb('#ffffff',0),
			        
	                custom : {'focusable' : true, 'text' : Volt.i18n.t('TV_SID_VIEW_DETAIL')},
	                x: 0, y:  0, width : 200, height : 50,
	            },{
	                type : 'Button_Generic',
					id: 'delete-btn',
		            color : Volt.hexToRgb('#ffffff',0),
	                custom : {'focusable' : true, 'text' : Volt.i18n.t('TV_SID_DELTET')},
	                x: 0+250, y:  0, width : 200, height : 50,
	            },
			]
		},


		
    ThumbArea:{
        type : 'widget',
        x : 0, y : 0, width : 560, height : 420,
        color : Volt.hexToRgb('#0F2540'),
    	children: [
            {
                type : 'image',
                x: 0, y:  0, width : 560, height : 420,
                src : '{{ thumbnail }}',
            },
        ]
	},


	menu: {
            type : 'Popup_Menu',
            x : 1920 - 250, y : 10, width : 200  , height : 80  ,
            id : 'detail-menu-area',
            custom: { 'focusable': true },
            color : Volt.hexToRgb('#ffffff',0),
        },

	menu_list:
		{
			x:0,y:80,w:200,h:50,
			num:3
     },

	menu_list_content:
		{
			selectedIdx:1,
			selectedSrc:Volt.getRemoteUrl('images/1080/common/button/apps_check.png'),
			selectedSrcpositionx:10,
			selectedSrcpositiony:10,
			selectedSrcwidth:30,
			selectedSrcheight:30,
			textimggap:0
     	},



 // Template for Content View
    // Content View is a Resizeable Grid 
    listitem: [
        {
            type: 'image',
            x: 0, y: 0, width: (1080-70)/8, height: (1080-70)/8,
            src: '{{ imgUrl }}',
            custom: {ID:'thumbnail'}
        },
        {
            type: 'widget',
            x: 0 + (1080-70)/8 , y: 0, width: 1920 - 120 - 600 - (1080-70)/8 , height: (1080-70)/8,
            color: {r:255, g:255, b:255, a:0},
            custom: {ID:'title'},
            children: [
                {
                    type: 'text',
                    x: 0, y: 0, width: 1920 - 120 - 600 - (1080-70)/8, height: 60,
                    font: '50px',
	                horizontalAlignment : 'left',
	                verticalAlignment : 'center',
                    textColor: {r:0, g:0, b:0},
                    opacity: 255,
                    ellipsize: true,
                    text: '{{ title }}',
                },{
                    type: 'text',
                    x: 0, y: 0 + 60, width: 324, height: 40,
                    font: '30px',
                    textColor: {r:0, g:0, b:0},
                    opacity: 255,
                    ellipsize: true,
                    singleLineMode: true,
                    text: 'Genre'
                },
            ],
        },
    ],


};

exports = AppDetailTemplate;


