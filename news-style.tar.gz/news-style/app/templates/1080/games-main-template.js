/** 
 * @author Common Module Team
 * @fileoverview Template for Games Main View
 * @date 2014/11/03
 *
 * @version 1.86
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

/**
 * @module GamesMainTemplate
 * @property {Object}  header           - View Template of Header View in Main View.
 * @property {Object}  gamesItemSmall   - Template for Small Item(1X1) in Grid of Main View.
 * @property {Object}  gamesItemLarge   - Template for Large Item(2X2) in Grid of Main View.
 * 
 * @example
 * Volt.require('lib/panel-common.js');
 * var BaseView = Volt.BaseView;
 * var GamesMainTemplate = Volt.require('template-path/games-main-template.js');
 * var HeaderView = BaseView.extend({
 *     // Set header template as template of Header View
 *     template: GamesMainTemplate.header,
 *     render: function() {
 *         // Load header Template
 *         this.setWidget(PanelCommon.loadTemplate(this.template));
 *         return this;
 *     }
 * });
 * 
 * // Example to use gamesItemSmall/gamesItemLarge
 * var ExampleView = BaseView.extend({
 *     render: function() {
 *         // Load gamesItemSmall template and set it as child of ExampleView's widget.
 *         PanelCommon.loadTemplate(GamesMainTemplate.gamesItemSmall, data, this.widget);
 *     }
 * })
 * 
 * @note
 * 1) No two widgets are allowed to have the same ID
   2) Mustache only supports string replacement
 */

var GamesMainTemplate = {

    SCREEN_WIDTH: 1920,
    SCREEN_HEIGHT: 1080,
    //custom ID for list elements
    ID_LIST_THUMBNAIL: 'thumbnail',
    ID_LIST_TEXT: 'title',

    // Template for Header View
    header: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 1920,
        height: 144,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                type: 'text',
                x: 36,
                y: 0,
                width: 726,
                height: 144,
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff'),
                opacity: 102,
                text: Volt.i18n.t('COM_TV_SID_GAMES'),
                custom: {
                    multilingual: {
                        SID: 'COM_TV_SID_GAMES'
                    }
                },
                font: '50px'
            }, {
                type: 'widget',
                x: 1920 - 300 - 1,
                y: 0,
                width: 1,
                height: 144,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 13
            }, {
                type: 'widget',
                x: 1920 - 200 - 1,
                y: 0,
                width: 1,
                height: 144,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 13
            }, {
                type: 'widget',
                x: 1920 - 100 - 1,
                y: 0,
                width: 1,
                height: 144,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 13
            }, {
                type: 'cmHeaderButton',
                id: 'main-header-icon-schedule',
                custom: {
                    'focusable': true
                },
                x: 1920 - 101 - 200,
                y: 0,
                width: 101,
                height: 144,
                
                iconImageSrcNormal: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_search_nor.png'),
                iconImageSrcFocused: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_search_sel.png'),
                iconWidth: 36,
                iconHeight: 36
                
            }, {
                type: 'cmHeaderButton',
                id: 'main-header-icon-setting',
                custom: {
                    'focusable': true
                },
                x: 1920 - 101 - 100,
                y: 0,
                width: 101,
                height: 144,
                
                iconImageSrcNormal: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png'),
                iconImageSrcFocused: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
                iconWidth: 36,
                iconHeight: 36
            }, {
                type: 'cmHeaderButton',
                id: 'main-header-icon-close',
                custom: {
                    'focusable': true
                },
                x: 1920 - 101,
                y: 0,
                width: 101,
                height: 144,
                
                iconImageSrcNormal: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_nor.png'),
                iconImageSrcFocused: Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_close_sel.png'),
                iconWidth: 36,
                iconHeight: 36
            }
        ]
    },

    contentSpotlightGrid: {
        type: 'cmGridList',
        parent: null,
        width: 1944,
        height: 408 * 2 + 50,
        titleSpace: 50,
        groupSpace: 30,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        custom: {
            focusable: true,
        },
    },


    contentGenrealGrid: {
        type: 'cmGridList',
        parent: null,
        width: 1944, //1920, 
        height: 648 + 216,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        custom: {
            focusable: true,
        },
    },

    spotlightSmallItem: [
        {
            type: 'Thumbnail',
            visibleStyles: (0x01 | 0x20),
            image: {
                src: '{{ imgUrl }}',
                width: 324,
                height: 324
            },
            information: {
                x: 0,
                y: 324,
                width: 324,
                height: 84,
                text1: {
                    x: 20,
                    y: 15,
                    width: 284,
                    height: 30,
                    font: 'Calibri 26px',
                    text: '{{ title }}',
                    singleLineMode: true
                },
            },
        },
    ],




    // Template for Large Game Item
    spotlightLargeItem: [
        {
            type: 'Thumbnail',
            visibleStyles: (0x01 | 0x20),
            image: {
                src: '{{ imgUrl }}',
                width: 648,
                height: 648
            },
            information: {
                x: 0,
                y: 648,
                width: 648,
                height: 168,
                text1: {
                    x: 20,
                    y: 15,
                    width: 608,
                    height: 30,
                    font: 'Calibri 26px',
                    text: '{{ title }}',
                    singleLineMode: true
                },
            },
        },
    ],


    spotlightTitlebar: {
        type: 'widget',
        x: 0,
        //y:-48,
        width: 324 * 5 * 3,
        color: {
            r: 0xdf,
            g: 0xdf,
            b: 0xdf
        },
        height: 48,
        children: [
            {
                type: 'text',
                x: 12,
                y: 0,
                width: 648,
                height: 48,
                verticalAlignment: 'center',
                textColor: {
                    r: 0,
                    g: 0,
                    b: 0
                },
                font: '22px',
                text: Volt.i18n.t('TV_SID_PROMOTION_TITLE'),
            },
            {
                type: 'text',
                x: 1620 + 12,
                y: 0,
                width: 648,
                height: 48,
                verticalAlignment: 'center',
                textColor: {
                    r: 0,
                    g: 0,
                    b: 0
                },
                font: '22px',
                text: Volt.i18n.t('TV_SID_LASTEST_PLAYED'),
            },
            {
                type: 'text',
                x: 1620 * 2 + 12,
                y: 0,
                width: 648,
                height: 48,
                verticalAlignment: 'center',
                textColor: {
                    r: 0,
                    g: 0,
                    b: 0
                },
                font: '22px',
                text: Volt.i18n.t('TV_SID_FRIENDS_PICK'),
            },
        ],
    },

    generalSmallItem: [
        {
            type: 'Thumbnail',
            visibleStyles: (0x01 | 0x20),
            image: {
                src: '{{ imgUrl }}',
                width: 324,
                height: 324
            },
            information: {
                x: 0,
                y: 324,
                width: 324,
                height: 108,
                text1: {
                    x: 20,
                    y: 15,
                    width: 284,
                    height: 30,
                    font: 'Calibri 26px',
                    text: '{{ title }}',
                    singleLineMode: true
                },
            },
        },
    ],
    // Template for Large Game Item
    generalLargeItem: [
        {
            type: 'Thumbnail',
            visibleStyles: (0x01 | 0x20),
            image: {
                src: '{{ imgUrl }}',
                width: 648,
                height: 648
            },
            information: {
                x: 0,
                y: 648,
                width: 648,
                height: 216,
                text1: {
                    x: 20,
                    y: 15,
                    width: 608,
                    height: 30,
                    font: 'Calibri 26px',
                    text: '{{ title }}',
                    singleLineMode: true
                },
            },
        },
    ],

    //template of option menu
    optionMenu: {
        //type: 'OptionMenu',
        type: 'cmOptionMenu',
        x: 1380,
        y: 100,
        width: 520,
        renderNum: 4,
        text: [Volt.i18n.t('TV_SID_LANGUAGE'), Volt.i18n.t('TV_SID_SORT_BY_NAME'), Volt.i18n.t('TV_SID_SORY_BY_ID'), Volt.i18n.t('TV_SID_VIEW_DETAIL'), Volt.i18n.t('UID_FAVORITES'), Volt.i18n.t('TV_RECOMMENDATION_TYPE'), Volt.i18n.t('TV_SID_BLOCK_ADULT_CONTENT'), Volt.i18n.t('TV_SID_TUTORIAL')],
        subText: [
            {
                index: 0,
                text: [Volt.i18n.t('TV_SID_ENGLISH'), Volt.i18n.t('TV_SID_WAVE_ENGLISH')],
                width: 300,
                loop: true
            },
            {
                index: 3,
                text: [Volt.i18n.t('TV_SID_POPULAR'), Volt.i18n.t('TV_SID_PREFERENCE')],
                width: 300,
                loop: false
            },
            {
                index: 4,
                text: [Volt.i18n.t('COM_SID_OFF'), Volt.i18n.t('COM_SID_ON')],
                width: 300,
                loop: false
            },
		  ],
      custom:{
	        longpress: false,
	    },

    },

    longPressMenu: {
        //type: 'OptionMenu',
        type: 'cmOptionMenu',
        x: 0,
        y: 0,
        width: 300,
        text: [Volt.i18n.t('COM_SID_OK'), Volt.i18n.t('COM_SID_CLOSE')],
        custom: {
            multilingual: {
                translate: null
            },
	        longpress:true,
        },
    },

    optionMenuIndices: {
        language: 0,
        sortByName: 1,
        sortById: 2,
        signIn: 5
    },

    msgPopup: {
        type: 'MessagePopup',
        x: 0,
        y: 400,
        height: 270,
        color: Volt.hexToRgb('#0f1826', 85),
    },
    
	//winset message box
   networkPopup:{
        type: 'winsetMessageBox',
        style: 3,
		buttonStyle: 1,
		nResoultionStyle: 1,
		bgStyle: 1
	},

    MSG_POPUP_MESSAGE_HEIGHT: 100,


    scrollbar1: {
        type: 'Scroll',
        parent: scene,
        width: 1920,
        height: 1920 * 0.004630,
        trackShadowHeight: 1920 * 0.000926,
        direction: "horizontal",
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        }, // need it! WidgetBridge::constructFromScript calls:  cWidget->setColor( hasColor ? color : getDefaultColor() );
        backgroundColor: {
            r: 200,
            g: 200,
            b: 200,
            a: 51
        },
        trackShadowColor: {
            r: 0,
            g: 0,
            b: 0,
            a: 51
        },
        x: 0,
        y: (408 * 2) + 50 - 1920 * 0.019444,
        minValue: 0,
        currentValue: 0,
        maxValue: 100,
        pointingNormalThumbImageWidth: 1920 * 0.018750,
        pointingNormalThumbImageHeight: 1920 * 0.004630,
        pointingNormalThumbImage: Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pn.png"),
        pointingOverThumbImageWidth: 1920 * 0.020833,
        pointingOverThumbImageHeight: 1920 * 0.019444,
        pointingOverThumbImage: Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_po.png"),
        pointingFocusThumbImageWidth: 1920 * 0.025521,
        pointingFocusThumbImageHeight: 1920 * 0.026852,
        pointingFocusThumbImage: Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pf.png"),
        rolloverTopTrackHeight: 1920 * 0.019444
    },

    //scrollbar
    scrollbar2: {
        type: 'Scroll',
        parent: scene,
        width: 1920,
        height: 1920 * 0.004630,
        trackShadowHeight: 1920 * 0.000926,
        direction: "horizontal",
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        }, // need it! WidgetBridge::constructFromScript calls:  cWidget->setColor( hasColor ? color : getDefaultColor() );
        backgroundColor: {
            r: 200,
            g: 200,
            b: 200,
            a: 51
        },
        trackShadowColor: {
            r: 0,
            g: 0,
            b: 0,
            a: 51
        },
        x: 0,
        y: (648 + 216) - 1920 * 0.019444,
        minValue: 0,
        currentValue: 0,
        maxValue: 100,
        pointingNormalThumbImageWidth: 1920 * 0.018750,
        pointingNormalThumbImageHeight: 1920 * 0.004630,
        pointingNormalThumbImage: Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pn.png"),
        pointingOverThumbImageWidth: 1920 * 0.020833,
        pointingOverThumbImageHeight: 1920 * 0.019444,
        pointingOverThumbImage: Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_po.png"),
        pointingFocusThumbImageWidth: 1920 * 0.025521,
        pointingFocusThumbImageHeight: 1920 * 0.026852,
        pointingFocusThumbImage: Volt.getRemoteUrl("images/1080/scroll/keyscreen_scroll_pf.png"),
        rolloverTopTrackHeight: 1920 * 0.019444
    },

    richText: {
        type: 'RichText',
        x: 660,
        y: 340,
        width: 600,
        height: 400
    }

};

exports = GamesMainTemplate;

////////////////////////////////////////////////////////////////////////////////
// DO NOT CROSS
// DEPRECATED CODE STARTS FROM HERE
////////////////////////////////////////////////////////////////////////////////
    /*  
    spotlightLargeItem: [
        {
            type: 'image',
            x: 0, y: 0, width: 648, height: 648,
            src: '{{ imgUrl }}',
            custom: {ID:"thumbnail"}
        },
        {
            type: 'widget',
            x: 0, y: 648, width: 648, height: 168,
            color: {r:0, g:0, b:0, a:0},
            custom: {ID:"title"},
            children: [
                {
		            type: 'AutoScrollTextWidget',
                    x: 20, y: 15, width: 608, height: 30,
                    font: 'Calibri 26px',
		            color: {r:255, g:125, b:255,a:0},
                    opacity: 153,
                    ellipsize: true,
                    text: '{{ title }}'
                }
            ],
        },
    ],
*/
    
    
    /*
    generalSmallItem: [
        {
            type: 'image',
            x: 0, y: 0, width: 324, height: 324,
            src: '{{ imgUrl }}',
            custom: {ID:'thumbnail'}
        },
        {
            type: 'widget',
            x: 0, y: 324, width: 324, height: 108,
            color: {r:0, g:0, b:0, a:0},
            custom: {ID:'title'},
            children: [
                {
                    type: 'AutoScrollTextWidget',
                    x: 20, y: 15, width: 284, height: 30,
                    font: 'Calibri 26px',
		            color: {r:255, g:125, b:255,a:0},
                    opacity: 153,
                    ellipsize: true,
                    text: '{{ title }}'
                },
            ],
        },
    ],
    // Template for Large Game Item
    generalLargeItem: [
        {
            type: 'image',
            x: 0, y: 0, width: 648, height: 648,
            src: '{{ imgUrl }}',
            custom: {ID:'thumbnail'}
        },
        {
            type: 'widget',
            x: 0, y: 648, width: 648, height: 216,
            color: {r:0, g:0, b:0, a:0},
            custom: {ID:'title'},
            children: [
                {
                    type: 'AutoScrollTextWidget',
                    x: 20, y: 15, width: 608, height: 30,
                    font: 'Calibri 26px',
		            color: {r:255, g:125, b:255,a:0},
                    opacity: 153,
                    ellipsize: true,
                    text: '{{ title }}'
                }
            ],
        },
    ],
*/
    
    /*		
    contentGeneral: {
        type: 'ResizeableGrid',
        x: 0, y: 0, width: 1920,
        color: {r:0xf2, g:0xf2, b:0xf2},
        rows: 2,
        itemWidth: 324,
        itemHeight: 432,
        parent: scene,
        custom: {focusable: true,},
    },
   */


    // Template for Small Game Item
    /*
    spotlightSmallItem: [
        {
            type: 'image',
            x: 0, y: 0, width: 324, height: 324,
            src: '{{ imgUrl }}',
            custom: {ID:"thumbnail"}
        },
        {
            type: 'widget',
            x: 0, y: 324, width: 324, height: 84,
            color: {r:0, g:0, b:0, a:0},
            custom: {ID:"title"},
            children: [
                {
                    type: 'AutoScrollTextWidget',
                    x: 20, y: 15, width: 284, height: 30,
                    font: 'Calibri 26px',
		            color: {r:255, g:125, b:255,a:0},
                    opacity: 153,
                    ellipsize: true,
                    text: '{{ title }}'
                },
            ],
        },
    ],
    */
    
        /*    
    // Template for Content View
    // Content View is a Resizeable Grid 
    contentSpotlight: {
        type: 'ResizeableGrid',
        x: 0, y: 48, width: 1920,
        color: {r:0xf2, g:0xf2, b:0xf2},
        rows: 2,
        itemWidth: 324,
        itemHeight: 408,
        parent: scene,
        custom: {focusable: true,},
    },

*/