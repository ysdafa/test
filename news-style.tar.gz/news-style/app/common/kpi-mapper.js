var KPI = Volt.require('lib/volt-kpi.js');
var DeviceModel = Volt.require("app/models/device-model.js");

function KPIMapper() {

    //mapper event name and category,
    //left value is a custom name to enhance readability
    //e is event name
    //c is category name
    var CATEGORY_MAPPER = {
        //example name of common module, no real effect
        'COMMON_MOVE_SPOTLIGHT': {e:'HOME_SL',c:'PG101'},
        'COMMON_MOVE_BRANDZONE': {e:'HOME_BZ',c:'PG102'},
        'COMMON_MOVE_MOSTPOPULAR': {e:'HOME_MP',c:'PG103'},
        'COMMON_MOVE_WHATSNEW': {e:'HOME_WN',c:'PG104'},
        'COMMON_MOVE_TOPGROSSING': {e:'HOME_TG',c:'PG105'},
        'COMMON_MOVE_GENREALL': {e:'HOME_GA',c:'PG106'},
        'COMMON_MOVE_MYPAGE': {e:'HOME_MP',c:'PG107'},
        'COMMON_SELECT_ADD': {e:'SELECTADD',c:'EV009'},

        //kpi name from soccer panel
        'H01_HOME': {e:'H01_HOME',c:'PG001'},
        'N02_NEWS': {e:'N02_NEWS',c:'PG002'},
        'M02_MATCHUP': {e:'M02_MATCHUP',c:'PG003'},
        'MD03_MATCHDETAIL': {e:'MD03_MATCHDETAIL',c:'PG004'},
        'MDP04_DETAILPOPUP': {e:'MDP04_DETAILPOPUP',c:'PG005'},
        'LP04_LINEUPPOPUP': {e:'LP04_LINEUPPOPUP',c:'PG006'},
        'R01_RANKING': {e:'R01_RANKING',c:'PG007'},
        'SL02_LEAGUE': {e:'SL02_LEAGUE',c:'PG008'},
        'ST03_TEAM': {e:'ST03_TEAM',c:'PG009'},

        'MENUBTN': {e:'MENUBTN',c:'EV001'},
        'SELECTCONTENT': {e:'SELECTCONTENT',c:'EV002'},
        'CHANGETEAM': {e:'CHANGETEAM',c:'EV003'},
        'PREVTEAM': {e:'PREVTEAM',c:'EV004'},
        'NEXTTEAM': {e:'NEXTTEAM',c:'EV005'},
        'ADDTEAM': {e:'ADDTEAM',c:'EV006'},
        'SELECTMATCH': {e:'SELECTMATCH',c:'EV007'},
        'SELECTRANKING': {e:'SELECTRANKING',c:'EV008'},
        'SELECTADD': {e:'SELECTADD',c:'EV009'},
        'SELECTMOVE': {e:'SELECTMOVE',c:'EV010'},
        'SELECTREMOVE': {e:'SELECTREMOVE',c:'EV011'},
        'TEAMMOVEDONE': {e:'TEAMMOVEDONE',c:'EV012'},
        'MOVEDONE': {e:'MOVEDONE',c:'EV013'},
        'REMOVEDONE': {e:'REMOVEDONE',c:'EV014'},
        'SELECTREPLACE': {e:'SELECTREPLACE',c:'EV015'},
        'TEAMREPLACE': {e:'TEAMREPLACE',c:'EV016'},
        'REMOVEALL': {e:'REMOVEALL',c:'EV017'},
        'OTHERNEWS': {e:'OTHERNEWS',c:'EV018'},
        'MATCHITEM': {e:'MATCHITEM',c:'EV019'},
        'RELATEDNEWS': {e:'RELATEDNEWS',c:'EV020'},
        'DETAILPOPUP': {e:'DETAILPOPUP',c:'EV021'},
        'LINEUPPOPUP': {e:'LINEUPPOPUP',c:'EV022'},
        'SELECTLEAGUE': {e:'SELECTLEAGUE',c:'EV023'},
        'SELECTTEAM': {e:'SELECTTEAM',c:'EV024'}
    };

    this.init = function () {
        KPI.init({
            serviceName: '15_game',
            modelId: DeviceModel.get('modelId'),
            uid: ' ',
            duid: DeviceModel.get('duid'),
            countryCode: DeviceModel.get('countryCode'),
            version: DeviceModel.get('firmware'),
            configFallbackPath: 'app/common/LogPolicyConfig.xml',
            debug: true
        });
    };

    this.addEventLog = function (customName, pOptions) {
        Volt.err('[kpi-mapper.js]addEventLog - ' + customName);
        var options = pOptions || {};
        options['c'] = CATEGORY_MAPPER[customName].c;
        KPI.add(CATEGORY_MAPPER[customName].e, options);
    };

    var lastPage = null;
    
    //startPage, endPage
    this.enterPage = function (customName, pOptions) {
        var options = pOptions || {};
        var pageName = CATEGORY_MAPPER[customName].e;
        var category = CATEGORY_MAPPER[customName].c;
        options['c'] = category;

        if (lastPage != null) {
            if (lastPage.customName != customName) {
                this.leavePage(lastPage.customName, lastPage.options);
            } else {
                Volt.err('[kpi-mapper.js] This page is already entered!' + CATEGORY_MAPPER[lastPage.customName].e);
                return;
            }
        }

        if (lastPage != null) {
            options['d'] = {};
            options['d']['pp'] = CATEGORY_MAPPER[lastPage.customName].e;
            Volt.err('[kpi-mapper.js] Last Page : ' + options.d.pp);
        }

        KPI.startPage(pageName, options);
        lastPage = {
            customName: customName,
            options: options
        };
    };

    this.leavePage = function (customName, pOptions) {
        var pageName,
            cartegory,
            options;

        if (customName && CATEGORY_MAPPER[customName]) { //target Page
            pageName = CATEGORY_MAPPER[customName].e;
            options = pOptions || {};
            options['c'] = CATEGORY_MAPPER[customName].c;
        } else { //Last Page
            if (lastPage) {
                pageName = CATEGORY_MAPPER[lastPage.customName].e;
                options = pOptions || {};
                options['c'] = CATEGORY_MAPPER[customName].c;
            }
        }

        if (pageName) {
            KPI.endPage(pageName, options);
            lastPage = null;
        } else {
            Volt.err('[kpi-mapper.js] There is no page event to be leave');
        }
    };

    this.changeUID = function () {
        KPI.changeUID(KPI.getUID());
    };

    this.getEvent = function (customName) {
        return CATEGORY_MAPPER[customName].e;
    };
    
    this.getCategory = function (customName) {
        return CATEGORY_MAPPER[customName].c;
    };

}

exports = new KPIMapper();