
var _ = Volt.require("modules/underscore.js")._;
//var favoriteCurrentModel = Volt.require('app/models/favorite-current-model.js');
var DeviceModel = Volt.require("app/models/device-model.js");
//var favoriteCollection = Volt.require('app/models/favorite-collection.js');

var KPI = function(view){
	this.view = view;
	this.options = {};
	this.send = function(desc){
		try{
			this.setOptions();
			_.extend(this.options.d, desc);
			Volt.KPIMapper.addEventLog(this.kpiName, this.options);
		}catch(e){
			Volt.err('[kpi-options.js] send Error - ' + e);
		}
	};
};

var _moveCount = {l:0, r:0, u:0, d:0};

var SP_MAPPER = {
	'SELECTCONTENT' : {
		width : 360,
		height : 270,
		offset : {
			x : 216,
			y : 0
		},
		grid : [10, 3]
	},
	'OTHERNEWS' : {
		width : 257,
		height : 262,
		offset : {
			x : 1663,
			y : 0
		},
		grid : [1, 4]
	},
	'MATCHITEM' : {
		width : 486,
		height : 816,
		offset : {
			x : 0,
			y : 216 + 48
		},
		grid : [4, 1]
	},
	'RELATEDNEWS' : {
		width : 220,
		height : 230,
		offset : {
			x : 0,
			y : 1080-300-70
		},
		grid : [9, 1]
	},
	'SELECTLEAGUE' : {
		width: 384,
		height: 432,
		offset : {
			x : 0,
			y : 216
		},
		grid : [5, 2]
	},
	'SELECTTEAM' : {
		width: 459, height: 189,
		offset : {
			x : 0,
			y : 216
		},
		grid : [4, 4]
	},

	'TEAMMOVEDONE' : {
		grid : [6, 1]
	}
};

function getCurrentLanguage(){
	//TODO : get current contents language
	return DeviceModel.get('serviceLanguage');
}

/*function getCurrentTeam(){
	//TODO : get Curernt Team name
	return favoriteCurrentModel.get('name');
}*/

function getRemoteType(){
	return '4direction';
}

function extend(protoProps, staticProps) {
    var parent = this;
    var child;

    // The constructor function for the new subclass is either defined by you
    // (the "constructor" property in your `extend` definition), or defaulted
    // by us to simply call the parent's constructor.
    if (protoProps && _.has(protoProps, 'constructor')) {
      child = protoProps.constructor;
    } else {
      child = function(){ return parent.apply(this, arguments); };
    }

    // Add static properties to the constructor function, if supplied.
    _.extend(child, parent, staticProps);

    // Set the prototype chain to inherit from `parent`, without calling
    // `parent`'s constructor function.
    var Surrogate = function(){ this.constructor = child; };
    Surrogate.prototype = parent.prototype;
    child.prototype = new Surrogate();

    // Add prototype properties (instance properties) to the subclass,
    // if supplied.
    if (protoProps){
		_.extend(child.prototype, protoProps);
    }

    // Set a convenience property in case the parent's prototype is needed
    // later.
    child.__super__ = parent.prototype;

    return child;
}

function getSP(eventName, wz){
	var OFFSET = 20;
	var resultIndex = 0;
	var prop = SP_MAPPER[eventName];

	var targetPosition = wz.getAbsolutePosition();

	var centerX = (targetPosition.x - prop.offset.x) + (prop.width)/2,
		centerY = (targetPosition.y - prop.offset.y) + (prop.height)/2;

	//vertical

	var vertical = prop.grid[0];
	var verticalIndex = 0;

	var i, j;
	for(i = 0; i<vertical; ++i){
		var leftOffset = i*prop.width + OFFSET;
		var rightOffset = (i+1)*prop.width - OFFSET;
		if(centerX > leftOffset && centerX < rightOffset){
			verticalIndex = i;
		}
	}

	//horizontal
	var horizontal = prop.grid[1];
	var horizontalIndex = 0;
	for(j = 0; j<horizontal; ++j){
		var upOffset = j*prop.height + OFFSET;
		var downOffset = (j+1)*prop.height - OFFSET;
		if(centerY > upOffset && centerY < downOffset){
			horizontalIndex = j;
		}
	}
	return 'A' + ((horizontalIndex * vertical)+(verticalIndex+1));
}

/*function getTeamsIDs(){
	var teamsIDs = [];
	_.each(favoriteCollection.models, function(model){
		teamsIDs.push(model.get('id'));
	});

	return teamsIDs.join('|');
}*/

KPI.extend = extend;

var KeyLogger = {
	init : function(){
		_moveCount = {l:0, r:0, u:0, d:0};
	},
	log : function(oldIndex, newIndex, eventName){
		var grid = SP_MAPPER[eventName].grid;
		var index = newIndex - oldIndex;
        var indexAbs = Math.abs(index);

        if(oldIndex < 0){
			// focus grid first time.
			_moveCount = {l:0, r:0, u:0, d:0};
        }else if(oldIndex == newIndex){
			Volt.log('focus item again ==> no action');
		}else{
			if(indexAbs == 1){
				if(grid[1] == 1){
					if(index < 0){
						++_moveCount.l;
					}else{
						++_moveCount.r;
					}
				}else{
					if(index < 0){
						++_moveCount.u;
					}else{
						++_moveCount.d;
					}
				}
			}else{
				if(index < 0){
						++_moveCount.l;
					}else{
						++_moveCount.r;
					}
			}
		}
	},
	get : function(eventName){
		var selectOption = '';
		switch(eventName){
			case 'OTHERNEWS':
				selectOption = 'u'+_moveCount.u +'d'+_moveCount.d;
				//up,down
				break;
			case 'MATCHITEM':
			case 'RELATEDNEWS':
			case 'TEAMMOVEDONE':
				selectOption = 'l'+_moveCount.l +'r'+_moveCount.r;
				//left,right
				break;

			case 'SELECTCONTENT':
			case 'SELECTLEAGUE':
			case 'SELECTTEAM':
				//up,down,left,right
				selectOption = 'l'+ _moveCount.l +'r'+ _moveCount.r +'u'+_moveCount.u +'d'+ _moveCount.d;
				break;
		}
		return selectOption;
	}
};

// ============================ HomeView ============================//

var MenuBtn = KPI.extend({
    kpiName : 'MENUBTN',
    setOptions : function(){
        this.options = {
            d : {
                rt : getRemoteType()
            }
        };
    }
});


var ContentItem = KPI.extend({
	kpiName : 'SELECTCONTENT',
	setOptions : function(){
		var collection = this.view.model.collection;
		var index = collection.indexOf(this.view.model);
		this.options = {
			d : {
				ct : getCurrentTeam(),
				pn : index+'_'+collection.length,
				contentType : this.view.model.get('type') == 'CONTENT_VOD' ? 'video' : 'news',
				rt : getRemoteType()
			}
		};
	}
});

var RankingItem = KPI.extend({
	kpiName : 'SELECTRANKING',
	setOptions : function(){
		this.options = {
			d : {
				ct : getCurrentTeam(),
				rt : getRemoteType()
			}
		};
	}
});

var MatchupItem = KPI.extend({
	kpiName : 'SELECTMATCH',
	setOptions : function(){
		this.options = {
			d : {
				ct : getCurrentTeam(),
				rt : getRemoteType()
			}
		};
	}
});

var CategoryPrev = KPI.extend({
	kpiName : 'PREVTEAM',
	setOptions : function(){
		this.options = {
			d : {
				rt : getRemoteType()
			}
		};
	}
});
var CategoryNext = KPI.extend({
	kpiName : 'NEXTTEAM',
	setOptions : function(){
		this.options = {
			d : {
				rt : getRemoteType()
			}
		};
	}
});
var CategoryAdd = KPI.extend({
	kpiName : 'ADDTEAM',
	setOptions : function(){
		this.options = {
			d : {
				rt : getRemoteType()
			}
		};
	}
});

var CategoryTeamChange = KPI.extend({
	kpiName : 'CHANGETEAM',
	setOptions : function(){
		this.options = {
			d : {
				rt : getRemoteType(),
				ct : this.view.model.get('id')
			}
		};
	}
});

var OptionAdd = KPI.extend({
    //modify for common module test
	//kpiName : 'SELECTADD',
	kpiName : 'COMMON_SELECT_ADD',       
	setOptions : function(){
		this.options = {
			d : {
				rt : getRemoteType()
			}
		};
	}
});
var OptionMove = KPI.extend({
    kpiName : 'SELECTMOVE',
    setOptions : function(){
        this.options = {
            d : {
                rt : getRemoteType()
            }
        };
    }
});
var OptionRemove = KPI.extend({
    kpiName : 'SELECTREMOVE',
    setOptions : function(){
        this.options = {
            d : {
                rt : getRemoteType()
            }
        };
    }
});

var TeamMove = KPI.extend({
	kpiName : 'TEAMMOVEDONE',
	setOptions : function(){
		this.options = {
			d : {
				rt : getRemoteType(),
				tid : this.view.model.get('id'),
				mc : KeyLogger.get('TEAMMOVEDONE'),
				pn : this.view.positionIndex + '_' + favoriteCollection.length
			}
		};
	}
});

var MoveDone = KPI.extend({
	kpiName : 'MOVEDONE',
	setOptions : function(){
		this.options = {
			d : {
				rt : getRemoteType(),
				tid : getTeamsIDs(),
				tc : favoriteCollection.length
			}
		};
	}
});


var RemoveDone = KPI.extend({
	kpiName : 'REMOVEDONE',
	setOptions : function(){
		this.options = {
			d : {
				cp : 'H01_HOME',
				cl : getCurrentLanguage(),
				rt : getRemoteType()
			}
		};
	}
});

var SelectReplace = KPI.extend({
    kpiName : 'SELECTREPLACE',
    setOptions : function(){
        this.options = {
            d : {
                rt : getRemoteType()
            }
        };
    }
});

var TeamReplace = KPI.extend({
    kpiName : 'TEAMREPLACE',
    setOptions : function(){
        this.options = {
            d : {
                rt : getRemoteType(),
                rtid : this.view.model.get('id'),
                pn :this.view.attributes.index + '_' + favoriteCollection.length
            }
        };
    }
});

var RemoveAll = KPI.extend({
    kpiName : 'REMOVEALL',
    setOptions : function(){
        this.options = {
            d : {
                rt : getRemoteType()
            }
        };
    }
});
// ============================ MatchupListView ============================//
var MatchItem = KPI.extend({
	kpiName : 'MATCHITEM',
	setOptions : function(){
		var collection = this.view.model.collection;
		var index = collection.indexOf(this.view.model);
		this.options = {
			d : {
				ct : getCurrentTeam(),
				rt : getRemoteType(),
				pn : index+'_'+collection.length
			}
		};
	}
});

// ============================ MatchupDetailView ============================//
var DetailPopup = KPI.extend({
	kpiName : 'DETAILPOPUP',
	setOptions : function(){
		this.options = {
			d : {
				ct : getCurrentTeam(),
				rt : getRemoteType()
			}
		};
	}
});

var LineupPopup = KPI.extend({
	kpiName : 'LINEUPPOPUP',
	setOptions : function(){
		this.options = {
			d : {
				ct : getCurrentTeam(),
				rt : getRemoteType()
			}
		};
	}
});

var RelateNews = KPI.extend({
	kpiName : 'RELATEDNEWS',
	setOptions : function(){
		var collection = this.view.model.collection;
		var index = collection.indexOf(this.view.model);
		this.options = {
			d : {
				cp : 'MD03_MATCHDETAIL',
				ct : getCurrentTeam(),
				rt : getRemoteType(),
				pn : index+'_'+collection.length,
				type : this.view.model.get('type') == 'CONTENT_VOD' ? 'video' : 'news'
			}
		};
	}
});

// ============================ NewsDetailView ============================//
var OtherNews = KPI.extend({
	kpiName : 'OTHERNEWS',
	setOptions : function(){
		var collection = this.view.model.collection;
		var index = collection.indexOf(this.view.model);
		this.options = {
			d : {
				cp : 'N02_NEWS',
				ct : getCurrentTeam(),
				rt : getRemoteType(),
				pn : index+'_'+collection.length,
				type : this.view.model.get('type') == 'CONTENT_VOD' ? 'video' : 'news'
			}
		};
	}
});

// ============================ SelectLeagueView ============================//
var LeagueItem = KPI.extend({
	kpiName : 'SELECTLEAGUE',
	setOptions : function(){
		var collection = this.view.model.collection;
		var index = collection.indexOf(this.view.model);
		this.options = {
			d : {
				rt : getRemoteType(),
				pn : index+'_'+collection.length,
				lid : this.view.model.get('id')
			}
		};
	}
});

// ============================ SelectTeamView ============================//
var TeamItem = KPI.extend({
	kpiName : 'SELECTTEAM',
	setOptions : function(){
		var teamModel = this.view.model; //json data
		this.options = {
			d : {
				ct : getCurrentTeam(),
				rt : getRemoteType(),
				pn : this.view.index+'_'+this.view.leagueModel.get('teams').length,
				stid : teamModel.id, // SelectTeamID
				ntid : getTeamsIDs(), // NewTeamsID
				ntc : favoriteCollection.length, // NewTeamsCount,
				rid : '' // ReplaceTeamID ,
			}
		};
	}
});

exports = {
	KeyLogger : KeyLogger,
	Home : {
        MenuBtn : MenuBtn,
		Content : ContentItem,
		Ranking : RankingItem,
		Matchup : MatchupItem,
		Category : {
			prev : CategoryPrev,
			next : CategoryNext,
			add : CategoryAdd,
			team : CategoryTeamChange,
            SelectReplace : SelectReplace
		},
		Sub : {
            OptionAdd : OptionAdd,
            OptionMove : OptionMove,
            OptionRemove : OptionRemove,
			teamMove : TeamMove,
			moveDone : MoveDone,
			removeDone : RemoveDone,
            TeamReplace : TeamReplace,
            RemoveAll : RemoveAll
		}
	},
	Matchup : {
		Item : MatchItem
	},
	MatchupDetail : {
		DetailPopup : DetailPopup,
		LineupPopup : LineupPopup,
		RelateNews : RelateNews
	},
	NewsDetail : {
		OtherNews : OtherNews
	},
	League : {
		LeagueItem : LeagueItem
	},
	Team : {
		TeamItem : TeamItem
	}
};
