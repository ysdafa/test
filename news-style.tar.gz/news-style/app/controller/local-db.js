var Q = Volt.require('modules/q.js');
var _ = Volt.require("modules/underscore.js")._;

var nCurYear = 2013,
    nCurMonth = 12;

var APP_KEY = '48494e91-2662-11e3-9048-782bcb9aa972-95e58a5b-302b-4d7c-9494-f7e1eada42da',
    SECRET_KEY = '54b97a14-4998-49fa-ae8d-168065939074-f49be4e4-8a22-4d39-8f66-7f6d13a59d6a',
    ESPN_KEY = '6x6765ghb46c8tbh7b9vanyp';

var DUID,
    ModelID,
    CountryCode;

var sSessionToken = false,
    bReady = false;

var sBaseURL = 'http://soccerstg.internetat.tv/openapi',
    sOperURL = 'https://soccer.internetat.tv/openapi',
    sDevURL = 'http://soccerstg.internetat.tv/openapi';

var sCurLeague,
    sCurTeamID,
    sPreLeague,
    sPreTeamID,
    sDefaultLeague,
    sCPAPIDomain,
    sServiceLang,
    aSpecialEvents = [];

var sImageDomain = '';

// Internal Database
var NewsDB = DBController();

function getDefaultLeague() {
    return sDefaultLeague;
}

function initDeviceInfo(){
    DUID = '';
    ModelID = '';
    CountryCode = 'BR';
    sBaseURL = sDevURL;
}

function isReady() {
    return bReady;
}

function ready() {
    print('[local-db.js] ready');
    var deferred =  Q.defer();

    initDeviceInfo();

    Q.all([
        getServerTime(),
        requestToken()
    ]).then(function(){
        requestDefaultInfo()
            .then(onReadySuccess)
            .fail(onReadyFail);
        }).fail(onReadyFail);

    function onReadySuccess() {
        bReady = true;
        deferred.resolve(true);
    }

    function onReadyFail() {
        bReady = false;
        deferred.reject(false);
    }

    return deferred.promise;
}

function requestToken() {
        return requestSeedKey();
}

function getServerTime() {
    var deferred =  Q.defer();
    if ((new Date()).getFullYear() > '2013') {
        print('[local-db.js] Time adjustment is not required.');
        var nCurTime = new Date();
        nCurYear = nCurTime.getFullYear();
        nCurMonth = nCurTime.getMonth() + 1;
        return deferred.resolve();
    }
    print('[local-db.js] Time adjustment is required.');
    new ResourceRequest({
        uri: 'http://api.espn.com/v1/sports/soccer/ARG.1/news/?lang=es&limit=1&apikey=' + ESPN_KEY,
        method: 'GET',
        async: true,
        success : function(response){
            var result = response;
            if (result.timestamp) {
                window.timeOffset = new Date(result.timestamp).getTime() - new Date().getTime();
            }
            var nCurTime = window.getTime();
            nCurYear = nCurTime.getFullYear();
            nCurMonth = nCurTime.getMonth() + 1;
            deferred.resolve();
        },
        error : function(xhr, textStatus, errorThrown){
            print('[local-db.js] Get time failed');
            deferred.resolve();
        }
    }).process();
    return deferred.promise;
}

function requestSeedKey() {
    print('[local-db.js] requestSeedKey');
    return get({
        url: sBaseURL+'/auth/seedkey',
        header: {
            'AppKey': APP_KEY,
            'DUID': DUID,
            'ModelID': ModelID,
            'CountryCode': CountryCode
        }

    })
    .then(function(result){
        print('[local-db.js] requestSeedKey Success');
        sSessionToken = pass(result.session.id, result.session.seedkey);
    })
    .fail(function(){});
}

function requestDefaultInfo() {
    print('[local-db.js] requestDefaultInfo');
    return getContents({ resource: '/service/configuration/defaultinfo' })
        .then(function(result){
            sCurLeague = sDefaultLeague = result.leaguevalue;
            sCPAPIDomain = result.CPAPIdomain;
            sImageDomain = result.imagedomain;
            sServiceLang = result.servicelang;
            sCurTeamID = false;
            aSpecialEvents = result.specialevents || [];
        })
        .fail(function(){
            throw new Error('requestDefaultInfo failed');
        });
}

function setResource() {
    var deferred =  Q.defer();
    sPreLeague = sCurLeague;
    sPreTeamID = sCurTeamID;
    sCurLeague = sDefaultLeague;
    sCurTeamID = false;
    NewsController.init();
    deferred.resolve();
    return deferred.promise;
}

var NewsController = new (function() {
    var oCurLeague, oCurTeam, nRequestKey;
    var nLimit = 50, nTotalMonth = 3;
    var deferred;

    this.init = function() {
        print('[local-db.js] NewsController.setTeam');
        if (!NewsDB.get(sCurLeague)) {
            NewsDB.set(sCurLeague, {
                data: [],
                status: getBucket(nTotalMonth),
                offsetMonth: 0,
                completed: false,
                team: DBController()
            });
        };
        if (!NewsDB.get(sCurLeague).team.get(sCurTeamID)) {
            NewsDB.get(sCurLeague).team.set(sCurTeamID, {
                data: [],
                status: getBucket(nTotalMonth),
                offsetMonth: 0,
                completed: false,
            });
        }
        oCurLeague = NewsDB.get(sCurLeague);
        oCurTeam = NewsDB.get(sCurLeague).team.get(sCurTeamID);
    }

    this.getLeagueNews = function(options){
        print('[local-db.js] NewsController.getLeagueNews');
        options.resource = oCurLeague;
        getNews(options, false);

        deferred = Q.defer();
        return deferred.promise;
    }
    this.getTeamNews = function(options){
        print('[local-db.js] NewsController.getTeamNews');
        options.resource = oCurTeam;
        getNews(options, true);

        deferred =  Q.defer();
        return deferred.promise;
    }

    function getQuery(dataCtrl, bTeam) {
        var curData = dataCtrl.status[dataCtrl.offsetMonth];
        var sQuery = 'lang='+sServiceLang;
        sQuery+='&offset='+curData.offset;
        sQuery+='&dates='+curData.year+curData.month;
        sQuery+='&limit='+nLimit;
        if (bTeam) {
            sQuery+='&teams='+sCurTeamID;
        }
        return sQuery;
    }

    function getNews(options, bTeam) {
        if (options.resource.completed) {
            setTimeout(function(){
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            },0);
            return;
        }
        nRequestKey = options.key = new Date().getTime();
        if (options.resource.data.length - 1 < options.start || options.resource.data.length - 1 < options.end) {
            // No stored data
            options.query = getQuery(options.resource, bTeam);
            getContents({
                resource: '/service/'+getCountrySpecificURI()+sCurLeague+'/news/',
                query: options.query
            }).then(function(result){
                if (options.key != nRequestKey) {
                    print('[local-db.js] getNews(Success) ignored - ' + this.resource);
                    return;
                }
                parse(result, options, bTeam);
            }).fail(function(sMsg){
                if (options.key != nRequestKey) {
                    print('[local-db.js] getNews(Fail) ignored - ' + this.resource);
                    return;
                }
                deferred.reject(sMsg);
            });
        } else {
            setTimeout(function(){
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            },0);
        }
        return true;
    }

    function parse(response, options, bTeam) {
        var result = response.result;
        for (var idx=0; idx< result.headlines.length; idx++) {
            options.resource.data.push(result.headlines[idx]);
        }
        if (result.resultsCount > result.resultsOffset + result.headlines.length) {
            options.resource.status[options.resource.offsetMonth].offset = result.resultsOffset + options.resource.data.length;
        } else {
            if (nTotalMonth - 1 > options.resource.offsetMonth) {
                options.resource.offsetMonth = options.resource.offsetMonth + 1;
            } else {
                options.resource.completed = true;
            }
        }
        getNews(options, bTeam);
    }

    function getBucket(nNum) {
        var arrMonth = [], tmpDate;
        for (var idx=0;idx<nNum;idx++) {
            tmpDate = getOffsetDate(-idx);
            arrMonth.push({ 'year': tmpDate.year, 'month': tmpDate.month, 'total': 0, 'offset': 0 });
        }
        return arrMonth;
    }
})();

function DBController() {
    var data;

    // Constructor
    reset();

    function reset() {
        data = {};
    }

    function get(key) {
        if (data[key]) {
            return data[key];
        } else {
            return false;
        }
    }

    function set(key, value) {
        data[key] = value;
    }

    function print() {
        console.dir(data);
    }

    return {
        'reset': reset,
        'get': get,
        'set': set,
        'print': print
    }
}

function getCurLeague() {
    return sCurLeague;
}

function getOffsetDate(nOffsetMonth) {
    var nYear = nCurYear, nMonth = nCurMonth;
    var nMonth = nMonth + nOffsetMonth;
    if (nMonth > 12) {
        nYear = nYear + 1;
        nMonth = 1;
    } else if (nMonth < 1) {
        nYear = nYear - 1;
        nMonth = 12 + nMonth;
    }
    return {
        year: nYear,
        month: nMonth < 10 ? '0' + nMonth : nMonth
    }
}

function getContents(options) {
    var sToken = sSessionToken;
    if(options.local){
        options.url = options.resource;
    }else{
        options.url = sBaseURL + options.resource + (options.query ? '?' + options.query : '');
    }
    options.header = {
        'Token': sToken,
        'DUID': DUID,
        'ModelID': ModelID,
        'CountryCode': CountryCode
    }
    return get(options);
}

function get(options) {
    print('[local-db.js] get - ' + options.url);
    var deferred =  Q.defer();

    var resourceRequest = new ResourceRequest(options.url);
    resourceRequest.method = 'POST';
    resourceRequest.async = true;

    for (var key in options.header) {
        resourceRequest.addHeader(key, options.header[key]);
    }
    resourceRequest.success = function(json, textStatus, xhr) {
        json = JSON.parse(json);
        deferred.resolve(json);
    };
    resourceRequest.error = function(xhr, textStatus, errorThrown) {
        var sErrCode = textStatus;
        deferred.reject(sErrCode);
    };
    resourceRequest.process();
    return deferred.promise;
}

// It is needed to add an addtional URI 'BR/'
// to get data from Brazil related contents
// Ex: service/BR/~~~
function getCountrySpecificURI() {
    return CountryCode=='BR'?'BR/':'';
}

exports = {
    ready: ready,
    isReady: isReady,
    getDefaultLeague: getDefaultLeague,
    getCurLeague: getCurLeague,
    setResource: setResource,

    getLeagueNews: NewsController.getLeagueNews
};


function pass(sID, sSeedKey) {
    return makeSHA1(sSeedKey, SECRET_KEY, sID, DUID);
}

function makeSHA1(seedkey, secretKey, sid, duid) {
    var in_buf;
    var sha1_buf;
    var token_buf;
    in_buf = seedkey.concat("+").concat(secretKey);
    //sha1?�수 ?�출부
    sha1_buf = sha1Hash(in_buf);

    token_buf = sid.concat("+").concat(sha1_buf);

    return token_buf;
}


// $Id: sha1.js,v 1.1 2008/11/25 07:07:58 networks1 Exp $

function sha1Hash(msg)
{
    // constants [¡×4.2.1]
    var K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];


    // PREPROCESSING

    msg += String.fromCharCode(0x80); // add trailing '1' bit to string [¡×5.1.1]

    // convert string msg into 512-bit/16-integer blocks arrays of ints [¡×5.2.1]
    var l = Math.ceil(msg.length/4) + 2;  // long enough to contain msg plus 2-word length
    var N = Math.ceil(l/16);              // in N 16-int blocks
    var M = new Array(N);
    for (var i=0; i<N; i++) {
        M[i] = new Array(16);
        for (var j=0; j<16; j++) {  // encode 4 chars per integer, big-endian encoding
            M[i][j] = (msg.charCodeAt(i*64+j*4)<<24) | (msg.charCodeAt(i*64+j*4+1)<<16) |
                (msg.charCodeAt(i*64+j*4+2)<<8) | (msg.charCodeAt(i*64+j*4+3));
        }
    }
    // add length (in bits) into final pair of 32-bit integers (big-endian) [5.1.1]
    // note: most significant word would be ((len-1)*8 >>> 32, but since JS converts
    // bitwise-op args to 32 bits, we need to simulate this by arithmetic operators
    M[N-1][14] = ((msg.length-1)*8) / Math.pow(2, 32); M[N-1][14] = Math.floor(M[N-1][14])
    M[N-1][15] = ((msg.length-1)*8) & 0xffffffff;

    // set initial hash value [¡×5.3.1]
    var H0 = 0x67452301;
    var H1 = 0xefcdab89;
    var H2 = 0x98badcfe;
    var H3 = 0x10325476;
    var H4 = 0xc3d2e1f0;

    // HASH COMPUTATION [¡×6.1.2]

    var W = new Array(80); var a, b, c, d, e;
    for (var i=0; i<N; i++) {

        // 1 - prepare message schedule 'W'
        for (var t=0;  t<16; t++) W[t] = M[i][t];
        for (var t=16; t<80; t++) W[t] = ROTL(W[t-3] ^ W[t-8] ^ W[t-14] ^ W[t-16], 1);

        // 2 - initialise five working variables a, b, c, d, e with previous hash value
        a = H0; b = H1; c = H2; d = H3; e = H4;

        // 3 - main loop
        for (var t=0; t<80; t++) {
            var s = Math.floor(t/20); // seq for blocks of 'f' functions and 'K' constants
            var T = (ROTL(a,5) + f(s,b,c,d) + e + K[s] + W[t]) & 0xffffffff;
            e = d;
            d = c;
            c = ROTL(b, 30);
            b = a;
            a = T;
        }

        // 4 - compute the new intermediate hash value
        H0 = (H0+a) & 0xffffffff;  // note 'addition modulo 2^32'
        H1 = (H1+b) & 0xffffffff;
        H2 = (H2+c) & 0xffffffff;
        H3 = (H3+d) & 0xffffffff;
        H4 = (H4+e) & 0xffffffff;
    }

    return H0.toHexStr() + H1.toHexStr() + H2.toHexStr() + H3.toHexStr() + H4.toHexStr();
}

//
// function 'f' [¡×4.1.1]
//
function f(s, x, y, z)
{
    switch (s) {
        case 0: return (x & y) ^ (~x & z);           // Ch()
        case 1: return x ^ y ^ z;                    // Parity()
        case 2: return (x & y) ^ (x & z) ^ (y & z);  // Maj()
        case 3: return x ^ y ^ z;                    // Parity()
    }
}

//
// rotate left (circular left shift) value x by n positions [¡×3.2.5]
//
function ROTL(x, n)
{
    return (x<<n) | (x>>>(32-n));
}

//
// extend Number class with a tailored hex-string method
//   (note toString(16) is implementation-dependant, and
//   in IE returns signed numbers when used on full words)
//
Number.prototype.toHexStr = function()
{
    var s="", v;
    for (var i=7; i>=0; i--) { v = (this>>>(i*4)) & 0xf; s += v.toString(16); }
    return s;
}


