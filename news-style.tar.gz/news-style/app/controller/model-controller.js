/**
 * @file Manage Models and Collections
 */

var Require = Volt.require,
    Q = Require('modules/q.js'),
    
    localCache = Require('app/controller/local-cache.js'),
    
    homeNewsCollection = Require('app/models/home-news-collection.js'),
    listThumbnailCollection = Require('app/models/list-thumbnail-collection.js'),
    
    mainModel = Require('app/models/main-model.js'),

    // Flags
    bAPIReady = false,
    tmAPIReady = false;


/**
 * Fetch.
 */
function initialize() {
    Volt.log('[DAO] initialize');

    // Fetch data for Main View
    mainModel.fetch();
    
    homeNewsCollection.dummy();
    listThumbnailCollection.fetch(listThumbnailCollection.mode.MODE_TEST);
}


function onAPIReady(result) {
    if (result) {
        Volt.log('API is ready - ' + result);
        bAPIReady = true;
        initialize();
        
    } else { // Failed to ready
        Volt.log('[DAO] API is failed');
        if (tmAPIReady) {
            Volt.clearTimeout(tmAPIReady);
        }
        tmAPIReady = Volt.setTimeout(function () {
            Volt.log('[DAO] try API ready');
            ready();
        }, 10 * 1000);
    }
}

/**
 * Is Model Ready
 */
function isReady() {
    return bAPIReady;
}

/**
 * Get ready
 */
function ready() {
    if (bAPIReady) {
        Volt.log('DAO had been ready.');
        return;
    }

    localCache.ready()
        .then(onAPIReady);
}

////////////////////////////////////////////////////////////////////////////////
exports = {
    ready: ready,
    isReady: isReady
};

