/**
 * @file Manage Data and Interact with Server
 */

var Reuire = Volt.require,

    _ = Volt.require('modules/underscore.js')._,
    Q = Volt.require('modules/q.js'),

    DeviceModel = Volt.require('app/models/device-model.js'),
    //config = Volt.require('config.js'),

    sBaseURL = 'https://osbstg.samsungcloudsolution.com', //config.server.operation,
    sOperURL = 'https://osbstg.samsungcloudsolution.com', //config.server.operation,
    sDevURL = 'https://osbstg.samsungcloudsolution.com', //config.server.development,
    
    //
    bReady = false,
    
    requestHeader;


function initDeviceInfo() {
    Volt.log();

    DeviceModel.init();

    requestHeader = {
        'Content-Type': 'application/json;charset=utf-8',
        'Cache-Control': '*',
        'Accept': '*/*',
        // Comment for Browser
        'Accept-Encoding': 'gzip,deflate',
        
        'DUID': DeviceModel.get('duid'),
        'Country': DeviceModel.get('countryCode'),
        'Language': DeviceModel.get('languageCode'),
        'ModelID': DeviceModel.get('modelId'),
        
        'AToken': DeviceModel.get('aToken'),
        'Bluetooth': DeviceModel.get('bluetooth'),
        'Resolution': DeviceModel.get('resolutionY'),
        'SmartTVClient': DeviceModel.get('smartTvClient'),
        
        'TUID': DeviceModel.get('tuid'),
        
        // Common Header
        'AToken-CountryCode': DeviceModel.get('aTokenCountryCode'),
        'AToken-DUID': DeviceModel.get('aTokenDuid'),
        'AToken-TimeStamp': DeviceModel.get('aTokenTimeStamp'),
        'AToken-ModelId': DeviceModel.get('aTokenModelId'),
        'AToken-ModelName': DeviceModel.get('aTokenModelName'),
        'AToken-Language': DeviceModel.get('aTokenLanugage'),
        'AToken-DeviceType': DeviceModel.get('aTokenDeviceType'),
        
        'GUID': DeviceModel.get('guid'),
        'UID': DeviceModel.get('uid'),
    };

    if (DeviceModel.get('serverType') == 'SERVERTYPE_DEVELOPMENT') {
        sBaseURL = sDevURL;
    } else {
        sBaseURL = sOperURL;
    }
}


function isReady() {
    return bReady;
}

function ready() {
    Volt.log();
    var deferred = Q.defer();

    initDeviceInfo();

    deferred.resolve(true);
    return deferred.promise;
}


function get(options) {
    Volt.log('url: ' + options.uri);
    
    var deferred = Q.defer(),
        resourceRequest = new ResourceRequest(options.uri),
        key;
    
    resourceRequest.method = 'GET';
    //resourceRequest.async = false;
    
    for (key in options.header) {
        if (typeof options.header[key] !== 'function') {
            resourceRequest.addHeader(key, options.header[key]);
        }
    }

    resourceRequest.success = function (responseText, textStatus, xhr) {
        Volt.log('[local-cache.js] get - success : ' + options.uri);

        var json = JSON.parse(responseText);
        //if (json.stat != 'ok') {
        //    deferred.reject(xhr, json.err);
        //    return;
        //}
        deferred.resolve(json);
    };

    resourceRequest.error = function (responseObject, statusString, exceptionString) { //response object, status string, exception string.
        Volt.log('[local-cache.js] get - error : ' + options.uri + ', statusString : ' + statusString + ', Cause : ' + exceptionString);
        Volt.log(JSON.stringify(responseObject));
        
        deferred.reject(exceptionString);
    };
    
    resourceRequest.process();
    
    return deferred.promise;
}

function getContents(options) {
    Volt.log('[local-cache.js] getContents - ' + options.uri + ' , query : ' + options.query);

    options.uri = sBaseURL + options.resource + (options.query ? '?' + options.query : '');
    
    options.header = requestHeader;

    return get(options);
}

////////////////////////////////////////
function getCategories() {
    var deferred = Q.defer();
    
    getContents({
        resource: '/game/recommend/v2/main/categories',
        
    }).then(function (response) {
        var rsp = response.rsp;
        if (rsp.stat != 'ok') {
            deferred.reject(rsp);
            return;
        }
            
        deferred.resolve(rsp);
        
    }).fail(function (response) {
        deferred.reject(response);
    });
    return deferred.promise;
}

exports = {
    ready: ready,
    isReady: isReady,
    
    getCategories: getCategories
};


/*
    requestDefaultInfo()
        .then(onReadySuccess)
        .fail(onReadyFail);

    function onReadySuccess() {
        bReady = true;
        deferred.resolve(true);
    }

    function onReadyFail() {
        bReady = false;
        deferred.reject(false);
    }

    return deferred.promise;
*/

/*
function requestDefaultInfo() {
    Volt.log();
    
    return getContents({
            resource: '/conf/v2/defaultinfo',
            query: 'countrycode=BR'
        })
        .then(function (result) {
            sDefaultLeague = result.leaguevalue;
            sCPAPIDomain = result.CPAPIdomain;
            sImageDomain = result.imagedomain;
            sServiceLang = result.servicelang;
            aSpecialEvents = result.specialevents || [];
            SoccerCommon.setTime(result.currentUtcTimestamp);
            DeviceModel.set('serviceLanguage', sServiceLang);
        })
        .fail(function (e) {
            Volt.err('error : ' + e)
            throw new Error('requestDefaultInfo failed');
        });
}

function getServiceLeague() {
    var deferred = Q.defer();
    if (arrServiceLeague.length > 0) {
        deferred.resolve(arrServiceLeague);
    } else {
        getContents({
            resource: '/conf/v2/leagues',
            query: 'countrycode=BR'
        })
            .then(function (result) {
                var leagueList = result.leaguelist;
                for (var idx = 0; idx < leagueList.length; idx++) {
                    arrServiceLeague.push(leagueList[idx].leaguevalue);
                }
                deferred.resolve(arrServiceLeague);
            })
            .fail(function () {
                deferred.reject();
            });
    }
    return deferred.promise;
}

var NewsController = new(function () {
    var nLimit = 50;
    var deferred;

    this.getLeagueNews = function (param) {
        var options = _.clone(param);
        Volt.log('[local-cache.js] NewsController.getLeagueNews');
        readyDB(options, false);
        getNews(options, false);

        deferred = Q.defer();
        return deferred.promise;
    }

    this.getTeamNews = function (param) {
        var options = _.clone(param);
        Volt.log('[local-cache.js] NewsController.getTeamNews');
        readyDB(options, true);
        getNews(options, true);

        deferred = Q.defer();
        return deferred.promise;
    }

    function readyDB(options, bTeam) {
        if (!NewsDB.get(options.league)) {
            NewsDB.set(options.league, {
                data: [],
                offset: 0,
                completed: false,
                team: DBController()
            });
        };
        if (!NewsDB.get(options.league).team.get(options.team)) {
            NewsDB.get(options.league).team.set(options.team, {
                data: [],
                offset: 0,
                completed: false
            });
        }
        options.resource = bTeam ? NewsDB.get(options.league).team.get(options.team) : NewsDB.get(options.league);
    }

    function getQuery(options, bTeam) {
        var sQuery = 'countrycode=AR';
        sQuery += '&contentlang=es';
        if (bTeam) {
            sQuery += '&teamid=' + options.team;
        }
        sQuery += '&limit=' + nLimit;
        sQuery += '&offset=' + options.resource.offset;
        return sQuery;
    }

    function getNews(options, bTeam) {
        Volt.log('[local-cache.js] NewsController.getNews');
        if (options.resource.completed) {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
            return;
        }
        if (options.resource.data.length - 1 < options.start || options.resource.data.length - 1 < options.end) {
            // No stored data
            options.query = getQuery(options, bTeam);
            getContents({
                resource: '/service/v2/leagues/' + options.league + '/news',
                query: options.query
            }).then(function (result) {
                parse(result, options, bTeam);
            }).fail(function (sMsg) {
                deferred.reject(sMsg);
            });
        } else {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
        }
        return true;
    }

    function parse(response, options, bTeam) {
        var result = response;
        for (var idx = 0; idx < result.news.length; idx++) {
            options.resource.data.push(result.news[idx]);
        }
        if (options.resource.offset > 0 || result.news.length < nLimit) {
            options.resource.completed = true;
        } else {
            options.resource.offset = options.resource.offset + nLimit;
        }

        getNews(options, bTeam);
    }
})();

var VideoController = new(function () {
    var nLimit = 50;
    var deferred;

    this.getLeagueVideo = function (param) {
        var options = _.clone(param);
        Volt.log('[local-cache.js] VideoController.getLeagueVideo');
        options.url = '/service/v2/video/leagues/' + options.league + '/clips';
        readyDB(options, false);
        getVideo(options, false);

        deferred = Q.defer();
        return deferred.promise;
    }

    this.getTeamVideo = function (param) {
        var options = _.clone(param);
        Volt.log('[local-cache.js] VideoController.getTeamVideo');
        options.url = '/service/v2/video/teams/' + options.team + '/clips';
        readyDB(options, true);
        getVideo(options, true);

        deferred = Q.defer();
        return deferred.promise;
    }

    function readyDB(options, bTeam) {
        Volt.log('[local-cache.js] VideoController.setTeam');
        if (!VideoDB.get(options.league)) {
            VideoDB.set(options.league, {
                data: [],
                offset: 0,
                completed: false,
                team: DBController()
            });
        };
        if (!VideoDB.get(options.league).team.get(options.team)) {
            VideoDB.get(options.league).team.set(options.team, {
                data: [],
                offset: 0,
                completed: false
            });
        }
        options.resource = bTeam ? VideoDB.get(options.league).team.get(options.team) : VideoDB.get(options.league);
    }

    function getQuery(options) {
        var sQuery = 'countrycode=AR';
        sQuery += '&contentlang=es';
        sQuery += '&limit=' + nLimit;
        sQuery += '&offset=' + options.resource.offset;
        return sQuery;
    }

    function getVideo(options) {
        if (options.resource.completed) {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
            return;
        }
        if (options.resource.data.length - 1 < options.start || options.resource.data.length - 1 < options.end) {
            // No stored data
            options.query = getQuery(options);
            getContents({
                resource: options.url,
                query: options.query
            }).then(function (result) {
                parse(result, options);
            }).fail(function (reason) {
                Volt.log('getVOD ' + reason);
                deferred.reject(reason);
            });
        } else {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
        }
        return true;
    }

    function parse(response, options) {
        var result = response;
        if (!result.videos) {
            result.videos = [];
        }
        for (var idx = 0; idx < result.videos.length; idx++) {
            options.resource.data.push(result.videos[idx]);
        }
        if (options.resource.offset > 0 || result.videos.length < nLimit) {
            options.resource.completed = true;
        } else {
            options.resource.offset = options.resource.offset + nLimit;
        }
        getVideo(options);
    }
})();

var ChannelController = new(function () {
    var oCurLeague;
    var nLimit = 50;
    var deferred;

    this.init = function () {
        Volt.log('[local-cache.js] ChannelController.setTeam');
    };

    this.get = function (param) {
        var options = _.clone(param);
        Volt.log('[local-cache.js] ChannelController.get');

        if (!ChannelDB.get(options.cid)) {
            ChannelDB.set(options.cid, {
                data: [],
                offset: 0,
                completed: false
            });
        };

        oCurLeague = ChannelDB.get(options.cid);

        options.url = '/service/v2/video/channels/' + options.cid + '/clips';
        options.resource = oCurLeague;

        getChannel(options, false);

        deferred = Q.defer();
        return deferred.promise;
    };

    function getQuery(dataCtrl) {
        var sQuery = 'countrycode=AR';
        sQuery += '&contentlang=es';
        sQuery += '&limit=' + nLimit;
        sQuery += '&offset=' + dataCtrl.offset;
        return sQuery;
    };

    function getChannel(options) {
        if (options.resource.completed) {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
            return;
        }
        if (options.resource.data.length - 1 < options.start || options.resource.data.length - 1 < options.end) {
            // No stored data
            options.query = getQuery(options.resource);
            getContents({
                resource: options.url,
                query: options.query
            }).then(function (result) {
                parse(result, options);
            }).fail(function (reason) {
                deferred.reject(reason);
            });
        } else {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
        }
        return true;
    }

    function parse(response, options) {
        var result = response;
        if (!result.videos) {
            result.videos = [];
        }
        for (var idx = 0; idx < result.videos.length; idx++) {
            options.resource.data.push(result.videos[idx]);
        }
        if (options.resource.offset > 0 || result.videos.length < nLimit) {
            options.resource.completed = true;
        } else {
            options.resource.offset = options.resource.offset + nLimit;
        }
        get(options);
    }
})();

var EventsController = new(function () {
    var nLimit = 50;
    var deferred;

    this.get = function (param) {
        var options = _.clone(param);
        Volt.log('[local-cache.js] EventsController.get');
        readyDB(options);
        options.url = '/service/v2/leagues/' + options.league + '/events';

        if (options.mode == 'REQUEST_UPDATE' || options.mode == 'REQUEST_MORE') {
            options.resource.completed = false;
            options.resource.data = [];
        }

        getEvents(options, false);

        deferred = Q.defer();
        return deferred.promise;
    };

    function readyDB(options) {
        if (!EventsDB.get(options.league)) {
            EventsDB.set(options.league, {
                data: [],
                offset: 0,
                completed: false
            });
        };
        options.resource = EventsDB.get(options.league);
    }

    function getQuery(options) {
        var sQuery = 'countrycode=AR';
        sQuery += '&contentlang=es';
        sQuery += '&limit=' + nLimit;
        sQuery += '&offset=' + options.resource.offset;
        return sQuery;
    };

    function getEvents(options) {
        if (options.resource.completed) {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
            return;
        }
        if (options.resource.data.length - 1 < options.start || options.resource.data.length - 1 < options.end) {
            // No stored data
            options.query = getQuery(options);
            getContents({
                resource: options.url,
                query: options.query
            }).then(function (result) {
                parse(result, options);
            }).fail(function (reason) {
                deferred.reject(reason);
            });
        } else {
            Volt.setTimeout(function () {
                deferred.resolve(options.resource.data.slice(options.start, options.end + 1));
            }, 0);
        }
        return true;
    }

    function parse(response, options) {
        var result = response;
        if (!result.events) {
            result.events = [];
        }
        for (var idx = 0; idx < result.events.length; idx++) {
            result.events[idx].leagues = result.leagues;
            options.resource.data.push(result.events[idx]);
        }
        if (options.resource.offset > 0 || result.events.length < nLimit) {
            options.resource.completed = true;
        } else {
            options.resource.offset = options.resource.offset + nLimit;
        }
        getEvents(options);
    }
})();

function DBController() {
    var data;

    // Constructor
    reset();

    function reset() {
        data = {};
    }

    function get(key) {
        if (data[key]) {
            return data[key];
        } else {
            return false;
        }
    }

    function set(key, value) {
        data[key] = value;
    }

    return {
        'reset': reset,
        'get': get,
        'set': set,
        'print': print
    }
}

function getEventDetail(options) {
    var deferred = Q.defer();
    if (EventDB.get(options.eid) && options.mode == 'REQUEST_FETCH') {
        Volt.setTimeout(function () {
            deferred.resolve(EventDB.get(options.eid));
        }, 0);
        return deferred.promise;
    };
    var sQuery = 'countrycode=BR&contentlang=es';
    getContents({
        resource: '/service/v2/leagues/' + options.league + '/events/' + options.eid,
        query: sQuery
    }).then(function (response) {
        EventDB.set(options.eid, response);
        deferred.resolve(EventDB.get(options.eid));
    }).fail(function (response) {
        if (options.error) {
            deferred.reject(response);
        }
    });
    return deferred.promise;
}

function getStanding(options) {
    var deferred = Q.defer();

    if (StandingDB.get(options.league) && options.mode == 'REQUEST_FETCH') {
        Volt.setTimeout(function () {
            deferred.resolve(StandingDB.get(options.league));
        }, 0);
        return deferred.promise;
    };

    var sQuery = 'countrycode=BR&contentlang=es';
    getContents({
        resource: '/service/v2/leagues/' + options.league + '/standings',
        query: sQuery
    }).then(function (response) {
        StandingDB.set(options.league, response);
        deferred.resolve(StandingDB.get(options.league));
    }).fail(function (response) {
        deferred.reject(response);
    });
    return deferred.promise;
}

function getLeaders(options) {
    var deferred = Q.defer();
    if (LeadersDB.get(options.league) && options.mode == 'REQUEST_FETCH') {
        Volt.setTimeout(function () {
            deferred.resolve(LeadersDB.get(options.league));
        }, 0);
        return deferred.promise;
    };
    var sQuery = 'countrycode=BR&contentlang=es';
    getContents({
        resource: '/service/v2/leagues/' + options.league + '/leaders',
        query: sQuery
    })
        .then(function (response) {
            LeadersDB.set(options.league, response);
            deferred.resolve(LeadersDB.get(options.league));
        })
        .fail(function (response) {
            deferred.reject(response);
        });
    return deferred.promise;
}

function getTeams(options) {
    var deferred = Q.defer();
    if (TeamsDB.get(options.league)) {
        Volt.setTimeout(function () {
            deferred.resolve(TeamsDB.get(options.league));
        }, 0);
        return deferred.promise;
    };
    var sQuery = 'countrycode=BR&contentlang=es';

    getContents({
        resource: '/service/v2/leagues/' + options.league + '/teams',
        query: sQuery
    }).then(function (response) {
        TeamsDB.set(options.league, response);
        deferred.resolve(TeamsDB.get(options.league));
    }).fail(function (response) {
        deferred.reject(response);
    });
    return deferred.promise;
}

*/

    /*
    getDefaultLeague: getDefaultLeague,
    getServiceLeague: getServiceLeague,

    getLeagueNews: NewsController.getLeagueNews,
    getTeamNews: NewsController.getTeamNews,
    getLeagueVOD: VideoController.getLeagueVideo,
    getTeamVOD: VideoController.getTeamVideo,

    getEvents: EventsController.get,
    getChannel: ChannelController.get,

    getEventDetail: getEventDetail,
    getStanding: getStanding,
    getLeaders: getLeaders,
    getTeams: getTeams
    */

    /*
    sDefaultLeague,
    sCPAPIDomain,
    sServiceLang,
    aSpecialEvents = [],

    sImageDomain = '',

    // Internal Database
    NewsDB = DBController(),
    VideoDB = DBController(),
    EventDB = DBController(),
    EventsDB = DBController(),
    StandingDB = DBController(),
    LeadersDB = DBController(),
    ChannelDB = DBController(),
    TeamsDB = DBController(),
    
    
    function getDefaultLeague() {
    return sDefaultLeague;
}
    */
    /*
    var sToken = sSessionToken;
    
    
    if (options.local) {
        options.url = options.resource;
    } else {
        options.url = sBaseURL + options.resource + (options.query ? '?' + options.query : '');
    }
    */