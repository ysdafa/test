var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

    //////
    RouterController = Require('app/controller/router-controller.js');

var Router = Backbone.Router.extend({
    // Define routes here
    routes: {
        //'main': 'main', // route to MainView
        "home": "home",
		// route to SubView
        "Spotlight":"spotlight",
        "Brand Zone":"brandzone",
        'What`s New':"whatsNew",
        "Most Popular":"mostPopular",
        "Top Grossing":"topGrossing",
        "Genre":"genre",
        "My Page":"myPage",
        
        'main/:id': 'category', // route to MainView with Category ID
        'detail/:id': 'detail', // route to DetailView with Product ID
        'main/popup/:type': 'popup', // route to Popup in MainView
        'uielement': 'uielement'
    },

    // Enter MainView
   /* main: function (options) {
        RouterController.root('main-view', options);
    },*/

    // Enter HomeView
    home: function(options) {
        print("RouterController.show('main-spotlight-view')");
        RouterController.root('main-view',options).sub('main-spotlight-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_SPOTLIGHT');
    },
	// Enter SubView
    spotlight:function(options){
        print("RouterController.show('main-spotlight-view')");
        RouterController.root('main-view',options).sub('main-spotlight-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_SPOTLIGHT');
    },
    
    brandzone:function(options){
        print("RouterController.show('main-brandzone-view')");
        RouterController.root('main-view',options).sub('main-brandzone-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_BRANDZONE');
    },
    
    whatsNew:function(options){
        print("RouterController.show('main-whatsnew-view')");
        RouterController.root('main-view',options).sub('main-whatsnew-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_WHATSNEW');
    },
    
    mostPopular:function(options){
        print("RouterController.show('main-popular-view')");
        RouterController.root('main-view',options).sub('main-popular-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_MOSTPOPULAR');
    },
    
    topGrossing:function(options){
        print("RouterController.show('main-grossing-view')");
        RouterController.root('main-view',options).sub('main-grossing-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_TOPGROSSING');
    },
    
    genre:function(options){
        print("RouterController.show('main-genre-view')");
        RouterController.root('main-view',options).sub('main-genre-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_GENREALL');
    },
    
    myPage:function(options){
        print("RouterController.show('main-mypage-view')");
        RouterController.root('main-view',options).sub('main-mypage-view');
        Volt.KPIMapper.enterPage('COMMON_MOVE_MYPAGE');
    },

	
    // Enter uielement
    uielement: function (options) {
        RouterController.root('uielement-view', options);
    },

    // Navigate to different categories
    category: function (id, options) {
        options.categoryId = id;
        RouterController.root('main-view', options);
        var event;
        switch (id) {
        case 'C0010':
            event = 'MOVESLIGHT';
            break;
        case 'C0020':
            event = 'MOVEPOPULAR';
            break;
        case 'C0020':
            event = 'MOVEWHATSNEW';
            break;
        case 'C0010':
            event = 'MOVETOP';
            break;
        case 'C0020':
            event = 'MOVEGENREALL';
            break;
        case 'C0020':
            event = 'MOVEMYP';
            break;
        default:
            break;
        }
        if (event) {
            Volt.KPIMapper.enterPage(event);
        }
    },

    // Navigate to detail view
    detail: function (id, options) {
        options.productId = id;
        RouterController.detail('newson-detail-view', options);
    },

    // Navigate to popups
    popup: function (type,options) {
        options.type = type;
        RouterController.popup('popup-' + type + '-view',options);
    }
});

exports = new Router();