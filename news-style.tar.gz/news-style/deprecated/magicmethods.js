if (!Volt.browser) {

// sets globals __line__, __file__, __ext__, __dir__
// copied and tweaked from: http://goo.gl/wwjGVV and http://goo.gl/umq4s1
// todo: __function__ and __method__? (Not sure if __class__ is viable/useful in Javascript)

// begin setting magic properties into global (required for other functions)

// add by yansu for log filename, line and functionname on 2014.07.12
Object.defineProperty(Volt, '__stack__', {
  get: function(){
    var orig = Error.prepareStackTrace;
    Error.prepareStackTrace = function(_, stack){ return stack; };
    var err = new Error;
    Error.captureStackTrace(err, arguments.callee);
    var stack = err.stack;
    Error.prepareStackTrace = orig;
    return stack;
  }
});

/**
 * returns line number when placing this in your code: __line__
 */
Object.defineProperty(Volt, '__line__', {
  get: function(){
    return Volt.__stack__[1].getLineNumber();
  }
});

/**
 * returns line number when placing this in your code: __line__
 */
Object.defineProperty(Volt, '__function__', {
  get: function(){
    return Volt.__stack__[1].getFunction();
  }
});

/**
 * returns line number when placing this in your code: __line__
 */
Object.defineProperty(Volt, '__func__', {
  get: function(){
    return Volt.__stack__[1].getFunctionName();
  }
});

/**
 * return filename (without directory path or file extension) when placing this in your code: __file__
 */
Object.defineProperty(Volt, '__file__', {
  get: function(){
    return Volt.__stack__[1].getFileName().split('/').slice(-1)[0];
  }
});

/**
 * return file extension (without preceding period) when placing this in your code: __ext__
 */
Object.defineProperty(Volt, '__ext__', {
  get: function(){
    return Volt.__stack__[1].getFileName().split('.').slice(-1)[0];
  }
});

/**
 * return path to filename (with trailing slash) when placing this in your code: __dir__
 */
Object.defineProperty(Volt, '__dir__', {
  get: function(){
    filename = Volt.__stack__[1].getFileName().split('/').slice(-1)[0];
    return Volt.__stack__[1].getFileName().split(filename).slice(0)[0];
  }
});


// end setting magic properties into global

}
