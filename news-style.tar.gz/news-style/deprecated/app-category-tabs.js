(function () {
    //Volt.BASE_PATH = 'http://10.240.135.67:8080/'; // In case server environment
    Volt.BASE_PATH = 'file://'; // In case TV environment
    Volt.require = function(path) {
        return require(Volt.browser ? path : Volt.BASE_PATH + path);
    };
})();

/*
 * Include modules
 */
var Require = Volt.require,
    _ = Require('modules/underscore.js')._;


Require('lib/volt-common.js');
Require('lib/volt-nav.js');

var PanelCommon = Require('lib/panel-common.js');

////////////////////////
// Update Template Parser custom widget into

PanelCommon.mapWidgets(['CategoryTabs']);

// tempalte for sample
var template = [
    {
        type: 'text',
        x: 0, y: 10, width: 1920, height: 50,
        text: 'Category-Tabs Demo',
        font: '32px',
        textColor: {r: 0, g: 0, b: 0},
        horizontalAlignment: 'center', verticalAlignment: 'center'
    }, {
        type: 'text',
        x: 0, y: 60, width: 1920, height: 80,
        font: '24px',
        text: '1,2,3 to add categories before/at/after selected category;\n5,6,7 to remove categories before/at/after selected category;\n7,8,9 to select categories at begin/middle/end;',
        textColor: {r: 0, g: 0, b: 0},
        horizontalAlignment: 'center', verticalAlignment: 'center'
    }, {
        id: 'ct',
        type: 'CategoryTabs',
        x: 0, y: 490, width: 1920, height: 72,
        color: {r:242, g:242, b:242},
        separatorWidth: 2,
        separatorHeight: 2,
        separatorColor: {r:0x46, g:0x46, b:0x46},
        expandHeight: 108,
        
        categories: [
            'My Page',
            'Super Long Category Test',
            'Spotlight',
            "Brand Zone",
        ],
        
        lockDuration: 500,
        
        arrowWidth: 18,
        arrowHeight: 34,
        leftArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_left_n.png'),
        rightArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_right_n.png'),
        
    }, {
        id: 'ct2',
        type: 'CategoryTabs',
        x: 0, y: 600, width: 1920, height: 72,
        color: {r:242, g:242, b:242},
        separatorWidth: 2,
        separatorHeight: 2,
        separatorColor: {r:0x46, g:0x46, b:0x46},
        expandHeight: 108,
        
        categories: [
            'My Page',
            'Super Long Category Test',
            'Spotlight',
            "Brand Zone",            
            "Most Popular",
            "What`s New",
            "Top Grossing",
            "Arcade/Action",
            "Sports/Racing",
            
            "Party/Music",
            "Puzzle/Brain/Board",
            "Party/Music",
            "Party/Music",
        ],
        
        lockDuration: 500,
        
        arrowWidth: 18,
        arrowHeight: 34,
        leftArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_left_n.png'),
        rightArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_right_n.png'),
        
    }, {
        id: 'log',
        type: 'text',
        x: 0, y: 690, width: 1920, height: 50,
        font: '24px',
        color: {a: 0},
        textColor: {r: 0, g: 0, b: 0},
        horizontalAlignment: 'center', verticalAlignment: 'center'
    }
];

// CategoryTabs
var ct;
var log;

var data = 'Category Category Category Category Category Category';
var len = data.length;

function getRandCategory() {
    return data.slice(0, Math.floor(Math.random() * len));
}
    
var expanded = false;
function onSelect(index, oldIndex) {
    if (index >= 0) {
        log.text = '[Selected Category]: [' + index + 'th]: ' + ct.getCategory(index);
    } else {
        log.text = '[Selected Category]: [None]';
    }
}
////////////////////////
/**
 * Entry point for Volt application
 */
var initialize = function() {
    scene.color = Volt.hexToRgb('#FFFFFF');
    
    // Create CategoryTabs
    widgets = PanelCommon.loadTemplate(template, null, scene);
    
    ct = widgets[2];
    log = widgets[3];
    
    // Set onSelect callback of CategoryTabs
    // Method 1:
    //ct.onSelect = _.bind(onSelect, ct);
    ct.onSelect = onSelect;
    // Method 2:
    //ct.setOnSelect(onSelect);
    
    ct.addEventListener('onMouseOver', function () {
        ct.animate('height', 108, 200);
    });

    ct.addEventListener('onMouseOut', function () {
        ct.animate('height', 72, 200);
    });

    // print debug info
    ct.setDebug(true);
    
    // begin modal
    Volt.Nav.beginModal(ct);
};


/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */

var gKeyCount = 0;

var onKeyEvent = function(keyCode, keyType) {
    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [' + Volt.__line__ + '] ' + keyCode + ' ' + keyType);

    // if Volt.Nav didn't process the event, the app will process it.
    Volt.Nav.onKeyEvent(keyCode, keyType);
    
    // 1,2,3 to add categoreis, 7,8,9 to remove categories
    if (keyType == Volt.EVENT_KEY_PRESS) {
        if (keyCode == 49) { // 1
            gKeyCount++;
            ct.addCategory(getRandCategory() + gKeyCount, ct.getSelectIndex() - 1);
        } else if (keyCode == 50) {
            gKeyCount++;
            ct.addCategory(getRandCategory() + gKeyCount, ct.getSelectIndex());
        } else if (keyCode == 51) {
            gKeyCount++;
            ct.addCategory(getRandCategory() + gKeyCount, ct.getSelectIndex() + 1);
        } else if (keyCode == 52) { // 4
            ct.removeCategory(ct.getSelectIndex() - 1);
        } else if (keyCode == 53) {
            ct.removeCategory(ct.getSelectIndex());
        } else if (keyCode == 54) {
            ct.removeCategory(ct.getSelectIndex() + 1);
        } else if (keyCode == 55) { // 7
            ct.setSelectIndex(0);
        } else if (keyCode == 56) {
            ct.setSelectIndex(Math.floor(ct.getCategoryCount()/2));
        } else if (keyCode == 57) {
            ct.setSelectIndex(ct.getCategoryCount() - 1);
        }
    }
};
