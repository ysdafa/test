/**
 * @author Common Group
 * @fileoverview An example of UielementView. 
 * @date 2014/07/31
 *
 * @version 1.4
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */

// Include libraries
var Require = Volt.require,
    Q = Require('modules/q.js'),
    Backbone = Require('lib/volt-backbone.js'),

// Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    Nav = Volt.Nav,

// Include models
    // We only need One single Model for Main View
    UiElementTemplate = PanelCommon.requireTemplate('uielement'),
// Common Constant of GUI
    CommonTemplate = PanelCommon.requireTemplate('common');

////////////////////////////////////////////////////////////////////////////////
// Sub Views of UielementView
    RadioButtonView = Require('lib/uielement-views/radio-button-view.js'),
    AnimatedImageDrawingView = Require('lib/uielement-views/animated-image-drawing-view.js'),
    ContextualMenuView = Require('lib/uielement-views/contextual-menu-view.js'),
    EntryClassView = Require('lib/uielement-views/entry-class-view.js'),
    ButtonGenericView = Require('lib/uielement-views/button-generic-view.js'),
    CheckBoxView = Require('lib/uielement-views/check-box-view.js'),
    PopupMenuView = Require('lib/uielement-views/popup-menu-view.js'),
    ListThumbnailsView = Require('lib/uielement-views/list-thumbnails-view.js'),
    ProgressBarView = Require('lib/uielement-views/progress-bar-view.js'),
    
    DimView = PanelCommon.requireView('dim'),

////////////////////////////////////////////////////////////////////////////////
// Create an Mediator to commumicate between MainView and its sub Views
    Mediator = new PanelCommon.Mediator();

////////////////////////////////////////////////////////////////////////////////
/**
 * <p>UielementView should extend from BaseView. It will be created and used by router-controller.js.
 * <p>Developer doesn't need to operate this View manually.
 * <p>Some properties and public functions may be invoked by app framework. Check the properties for details
 * <p style='color:red; font-weight:bold'>[TIPS] for developing with Common Module</p>
 * <p>1) Format of Events: EVENT_[VIEW NAME]_[WIDGET NAME]_[EVENT].
 * <p>&nbsp;&nbsp;e.g. EVENT_MAIN_SEARCH_SELECT
 * <p>2) Focus should be set after Nav.setRoot() or Nav.reload() called. Otherwise errors may occur.
 * <p>
 * <p>3) Pass {widget: xxx} to BaseView's constructor can set this widget as widget of the View directly.
 * <p>&nbsp;&nbsp;But you still need to call setWidget() to delegate 'events' if you have defined the 'events' property.
 * <p>4) Backbone supports following properties of View automatically:
 * <p> ['model', 'collection', 'el', 'id', 'attributes', 'className', 'tagName', 'events', 'widget', 'widgetOptions']
 * @class MainView
 *
 * @property {Widget}   widget      - Basic Widget of this View. All content of this View should be drawn on this widget.
 * @property {Function} initialize  - Constructor function. Do initialization inside.
 * @property {Function} render      - Core function to render element in the View.
 * @property {Function} remove      - Remove the display elements created by render. remove any Backbone.Events listeners.
 * @property {Function} show        - Show this view. Invoked when come back from other View
 * @property {Function} hide        - Hide this view. Invoked when leave from this View
 * @property {Function} pause       - Invoked when some popup view popup over this View
 * @property {Function} resume      - Invoked when come back from popup
 * @property {Function} onKeyEvent  - Let the View have the chance to handle key events in this View.
 *
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 * @requires {@link Nav}
 * @requires {@link MainModel}
 * @since 1.0
 *
 *
 */
var UielementView = PanelCommon.BaseView.extend({
    template: UiElementTemplate.container,       // Template of Main View is a view of containers

	// Sub Views
    dimView: null,
    radioButtonView:null,
    animatedImageDrawingView:null,
    entryClassView:null,
    contextualMenuView:null,
    buttonGenericView:null,
    checkBoxView:null,
    popupMenuView:null,
    listThumbnailsView:null,
    progressBarView:null,
    // store options for show()
    options: null,

    ////////////////////////////////////////////////////////////////////////////
    // Public Functions of View for Common Module
    ////////////////////////////////////////////////////////////////////////////
/**
 * Render the static display elements.
 * <p>The convention is for **render** to always return `this`.
 * @function
 * @memberof MainView
 * @return {View} return `this` MainView
 */
    render: function() {
        print('[uielement-view.js.js] uielementView.js.render');  
		this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
		this.renderUiElementView();

        return this;
    },

/**
 * Show this view. Invoked when come from other View
 * @function
 * @memberof UielementView
 * @param {Object}  options         - All options from router path or navigate/back parameters.
 * @param {String}  animationType   - Type of Animation
 */
    show: function(options, animationType) {
                             // We came from outside
        PanelCommon.doViewSwitchAni(this.widget, animationType);
        // call Nav.setRoot, for reset the root when coming back to this view.
        Nav.setRoot(this.widget);
		return;
    },

/**
 * Opposite operation of show, hide what you have shown.
 * @function
 * @memberof UielementView
 */
    hide: function(options, animationType) {
        if (options.routeCategory) {
            animationType = undefined;
        }

        //set customized hideView ani, by default just use animationType
		return PanelCommon.doViewSwitchAni(this.widget, animationType);
    },

/**
 * Invoked when some popup view popup over this View
 * @function
 * @memberof UielementView
 */
    pause: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        this.dimView.show();
    },

/**
 * Invoked when come back from popup
 * @function
 * @memberof UielementView
 */
    resume: function(options) {
        // To test Backbone.history.back(options) and View.onKeyEvent
        // options.greetings has been set in Popup-xxx-view.js's onKeyEvent function
        if (options.greetings) {
            print('[--------------------------------------------------------------------] ');
            print('[If you see this, means that history.back() with parameter and View with onKeyEvent() are successfully called]');
            print('[ ' + options.greetings + ' ]');
        }


        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        this.dimView.hide();

        // by default, setRoot() should be called, unless options.setRoot is explicitly set as false
        if (!options || options.setRoot !== false) {
            Nav.setRoot(this.widget);
        }
    },

    ////////////////////////////////////////////////////////////////////////////
    // uielement view test
    ////////////////////////////////////////////////////////////////////////////
    renderUiElementView: function() {
	    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
		this.renderRadioButton();
		this.renderAnimatedImageDrawing();
		this.renderEntryClass();
		this.renderContextualMenu();
		this.renderButtonGeneric();
		this.renderCheckBox();
		this.renderPopupMenu();
		this.renderListThumbnails();
		this.renderprogressBar();
    },
    renderRadioButton: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.radioButtonView || (this.radioButtonView = new RadioButtonView({
            widget: this.widget.getChild('radio-button-container'),
            mediator: Mediator
        }))).render();  
    },
    renderAnimatedImageDrawing: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.animatedImageDrawingView || (this.animatedImageDrawingView = new AnimatedImageDrawingView({
            widget: this.widget.getChild('animated-image-container'),
            mediator: Mediator
        }))).render();  
    },
    renderEntryClass: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.entryClassView || (this.entryClassView = new EntryClassView({
            widget: this.widget.getChild('entry-class-container'),
            mediator: Mediator
        }))).render();  
    },
    renderContextualMenu: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.contextualMenuView || (this.contextualMenuView = new ContextualMenuView({
            widget: this.widget.getChild('contextual-menu-container'),
            mediator: Mediator
        }))).render();  
    },
    renderButtonGeneric: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.buttonGenericView || (this.buttonGenericView = new ButtonGenericView({
            widget: this.widget.getChild('button-generic-container'),
            mediator: Mediator
        }))).render();  
    },
    renderCheckBox: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.checkBoxView || (this.checkBoxView = new CheckBoxView({
            widget: this.widget.getChild('check-box-container'),
            mediator: Mediator
        }))).render();  
    },
    renderPopupMenu: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.popupMenuView || (this.popupMenuView = new PopupMenuView({
            widget: this.widget.getChild('popup-menu-container'),
            mediator: Mediator
        }))).render();  
    },
    renderListThumbnails: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.listThumbnailsView || (this.listThumbnailsView = new ListThumbnailsView({
            widget: this.widget.getChild('list-thumbnails-container'),
            mediator: Mediator
        }))).render();  
    },
    renderprogressBar: function() {
        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ');
        (this.progressBarView || (this.progressBarView = new ProgressBarView({
            widget: this.widget.getChild('progress-bar-container'),
            mediator: Mediator
        }))).render();  
    },


	
});
exports = UielementView;
