// Include libraries
var Require = Volt.require,

// Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    CommonTemplate = PanelCommon.requireTemplate('common'),
    GlobalMediator = PanelCommon.GlobalMediator;

/**
 *
 * @example
 * var dimView = PanelCommon.requireView('dim');
 * // Show
 * // set a parent to show.
 * dimView.show({parent: this.widget.getChild('main-dim-container')});
 */
var DimView = PanelCommon.BaseView.extend({
    rect: null,
    //    initialize: function () {
    //    },

    render: function () {
        this.widget = PanelCommon.loadTemplate(CommonTemplate.dim, null, scene);
        
//        GlobalMediator.on('EVENT_DIM', this.show, this);
//        GlobalMediator.on('EVENT_UNDIM', this.hide, this);
    },

    show: function (options) {
        Volt.log();

        options = options || {};
        if (options.parent) {
            this.widget.parent = options.parent;
        } else {
            scene.addChild(this.widget);
        }

        if (options.rect) {
            this.rect = rect;
            this.widget.addTransparentArea(options.rect);
        }

        //this.widget.addEventListener('onMouseOver', this._blockMouse);
        this.widget.show();
    },

    hide: function () {
        Volt.log();

        //this.widget.removeEventListener('onMouseOver', this._blockMouse);
        this.widget.hide();
        this.widget.parent = scene;
        
        if (this.rect) {
            this.widget.clearTransparentArea(this.rect);
            this.rect = null;
        }
        
    },

    remove: function() {
//        GlobalMediator.off('EVENT_DIM', this.show, this);
//        GlobalMediator.off('EVENT_UNDIM', this.hide, this);
    }

});

exports = new DimView().render();


////////////////////////////////////////////////////////////////////////////////
// DO NOT CROSS
// DEPRECATED CODE STARTS FROM HERE
////////////////////////////////////////////////////////////////////////////////
/*
render: function () {
        //this.widget = PanelCommon.loadTemplate(CommonTemplate.dim, null, scene, false);
        
        
        return this;
    },

    remove: function () {},

    show: function (options) {
        Volt.log();

        if (options.parent) {
            this.widget.parent = options.parent;
        }

        if (options.rect) {
            //top
            this.widget.getChild(0).height = options.rect.y;

            //bottom
            this.widget.getChild(1).y = options.rect.y + options.rect.height;
            this.widget.getChild(1).height = CommonTemplate.SCREEN_HEIGHT - options.rect.y - options.rect.height;

            //left
            this.widget.getChild(2).y = options.rect.y;
            this.widget.getChild(2).width = options.rect.x;
            this.widget.getChild(2).height = options.rect.height;

            //right
            this.widget.getChild(3).x = options.rect.x + options.rect.width;
            this.widget.getChild(3).y = options.rect.y;
            this.widget.getChild(3).width = CommonTemplate.SCREEN_WIDTH - options.rect.x - options.rect.width;
            this.widget.getChild(3).height = options.rect.height;
        } else {
            //top
            this.widget.getChild(0).height = CommonTemplate.SCREEN_HEIGHT;

            //bottom
            this.widget.getChild(1).y = 0;
            this.widget.getChild(1).height = 0;

            //left
            this.widget.getChild(2).y = 0;
            this.widget.getChild(2).width = 0;
            this.widget.getChild(2).height = 0;

            //right
            this.widget.getChild(3).x = 0;
            this.widget.getChild(3).y = 0;
            this.widget.getChild(3).width = 0;
            this.widget.getChild(3).height = 0;
        }

        //this.widget.addEventListener('onMouseOver', this._blockMouse);
        this.widget.show();
    },

    hide: function () {
        Volt.log();

        //this.widget.removeEventListener('onMouseOver', this._blockMouse);
        this.widget.hide();
        this.widget.parent = scene;
    },
*/