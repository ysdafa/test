(function(){
    //Volt.BASE_PATH = 'http://10.240.135.67:8080/'; // In case server environment
    Volt.BASE_PATH = 'file://'; // In case TV environment
    Volt.require = function(path) {
        return require(Volt.browser ? path : Volt.BASE_PATH + path);
    };
})();

/*
 * Include modules
 */
var Require = Volt.require;
Require('lib/volt-debug.js');
Require('lib/volt-common.js');
Require('lib/volt-nav.js');
Require('app/router.js');


var Backbone = Require('lib/volt-backbone.js'),
    PanelCommon = Volt.require('lib/panel-common.js'),
    ModelController = Require('app/controller/model-controller.js');

    MainTemplate = PanelCommon.requireTemplate('main');

////////////////////////
// Update Template Parser custom widget into

PanelCommon.mapWidgets(['CategoryList', 'OptionMenu', 'ResizeableGrid', 'Button_Generic','MessagePopup','RadioButton','ProgressBar','Contextual_Menu','AnimatedImageDrawing','EntryClass','CheckBox','Popup_Menu','ListThumbnails','ProgressBar']);
////////////////////////
/**
 * Entry point for Volt application
 */
var initialize = function() {
    scene.color = {r: 0, g:0, b:0};

//------------------------------------------------------------------------------
// [NEW-1.4]: Add an option 'minCount' for Backbone.history.
    // Set minCount of history, to prevent pop out all histroy
    Backbone.history.start({minCount: 1});

    Backbone.history.navigate('uielement', {//uielement
        trigger: true,
        focusPosition: MainTemplate.FOCUS_POSITION_CONTENT,
        focusIndex: 0
    });

    ModelController.ready();
};


/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keyCode, keyType) {
//------------------------------------------------------------------------------
// [NEW-1.3]: Print file name, function name and line number
    //samples to demo how to use Volt.__file__, Volt.__func__ and Volt.__line__ in log
	print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [' + Volt.__line__ + '] ' + keyCode + ' ' + keyType);
    if(keyType == Volt.EVENT_KEY_RELEASE)
    {
        return;
	}
    // if Volt.Nav didn't process the event, the app will process it.
    if (Volt.Nav.onKeyEvent(keyCode, keyType) === false) {
        if (keyCode == Volt.KEY_RETURN
            && keyType == Volt.EVENT_KEY_PRESS) {
//            && Backbone.history.getCount() > 1) {
            Backbone.history.back();
        }
    }
};
