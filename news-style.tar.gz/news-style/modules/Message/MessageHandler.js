
var Message = require("Message.js");


var MessageHandler = {

	m_MessageListeners:{},
	

	m_callMessageListeners:function(Message){
		if (!this.m_MessageListeners[Message.type]) {
			return;
		}
		
		// For the key event
		if (typeof(Message.type) == "number") {
			var tempListener = this.m_MessageListeners[Message.type];
			
			if (tempListener) {
				tempListener[0].m_listener(Message.subtype); // key type
			}
			return;
		}
	
		var tempListeners = this.m_MessageListeners[Message.type];
		for(var index = 0 ; index < tempListeners.length; index ++) {
			if (tempListeners[index].m_object == null) {
				tempListeners[index].m_listener(Message);
			} else {
				tempListeners[index].m_listener.call(tempListeners[index].m_object, Message);
			}
			
		}
	},

	addMessageListener:function(MessageType, listener, object){
		if (!listener || arguments.length < 2) {
			return;
		}
		
		if (!this.m_MessageListeners[MessageType]) {	
			this.m_MessageListeners[MessageType] = [];
		}

	    var tempObj = null;
	    if (arguments.length == 3) {
	    	tempObj = {
				m_listener:listener,
				m_object:object
			}
	    } else {
	    	tempObj = {
				m_listener:listener,
				m_object:null
			}
	    }
		
		this.m_MessageListeners[MessageType].push(tempObj);
	},
	

	removeMessageListener:function(MessageType, listener){
		if (!listener) {
			return;
		}

		var tempListeners = this.m_MessageListeners[MessageType];
		if (!tempListeners) {
			return;
		}

		var index = tempListeners.indexOf(listener);
		if (index >= 0) {
			if (tempListeners.length == 1) {
				delete this.m_MessageListeners[MessageType];
			} else {
				tempListeners.splice(index, 1);
			}
		}
	},
	
	sendMessage:function(messageType, messageSubtype, sender, receiver, data){
		
		if (typeof (messageType) == "object") {
			
			Volt.postMessage(JSON.stringify(messageType));	
			return;
		}
		
		if (arguments.length < 4) {
			return;
		}
		
		var newMessage = new Message();
		newMessage.messageType = messageType;
		newMessage.messageSubtype = messageSubtype;
		
		newMessage.sender = "this";
		newMessage.receiver = receiver;
		
		if (arguments.length >= 5) {
			for(var index in data) {
				newMessage.makeValue(index, data[index]);
			}
		} 
		
		Volt.postMessage(newMessage.toString());
	},


	handleMessage:function(Message){
		
		this.m_callMessageListeners(Message);
	}
}


Volt.addEventListener(Volt.ON_MESSAGE, function(Message){

	var messageData = JSON.parse(Message.data);
	
	MessageHandler.handleMessage(messageData);
})

exports = MessageHandler;


/*
// Just used in the APP side

var MessageHandler = require("MessageHandler.js");


// Add the Message type string
MessageHandler.addMessageListener("HIDE", function(messageData){
	
})

// remove the Message type string
MessageHandler.removeMessageListener("HIDE", function(messageData){
	
})
 // Send message
MessageHandler.sendMessage("MessageType", "SubType", "sender", "receiver", data);
*/