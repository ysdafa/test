
var Message = function(){
	
	var constructor=this.m_create;
	if(constructor){
		constructor.apply(this, arguments);
	}
	
}

Message.prototype = {
	m_id:"Message",
	
	m_messageData:null,
	
	m_create:function(){
		if (this.m_messageData == null) {
			this.m_messageData = new Object();
		} 
	},
	
	set messageType(messageType){
		this.m_messageData["type"] = messageType;
	},
	
	set messageSubType(messageSubType){
		this.m_messageData["subtype"] = messageSubType;
	},
	
	set receiver(receiverName){
		this.m_messageData["receiver"] = receiverName;
	},
	
	set sender(senderName){
		this.m_messageData["sender"] = senderName;
	},
	
	get Message(){
		if (this.m_messageData != null) {
			return this.m_messageData;
		}
	},
	
	makeValue:function(propertyName, value){
		if (!this.m_messageData["data"]) {
			this.m_messageData["data"] = new Object();
		}
		this.m_messageData["data"][propertyName] = value;
	},
	
	toString:function(){
		if (this.m_messageData == null) {
			return "";
		} else {
			return JSON.stringify(this.m_messageData);
		}
	},
	
	destroy:function(){
		delete this.m_messageData;
	}
}

exports = Message;





