/**
 * Title: voltapi.js
 * Version: 0.925
 * Date: 2014-11-12
 */
exports.volt_api_version = "0.925";
exports.volt_api_version_date = "2014-11-12";


var self = this;

var isArray = function (Obj) {
    return Object.prototype.toString.call(Obj) == '[object Array]';
}

ResourceRequest.prototype.setHeader = function (key, value) {
    this.removeHeader(key);
    this.addHeader(key, value);
}

exports.rest = {
    resource_request: null,
    m_bOpened: false,
    uri: '',
    smartTVServer: false,
    interval: 10000,
    retry: 3,
    smartTVClientHeader: '',
    cur_status: 0,
    REST_STATUS: {
        READY: 0,
        SENDING: 1,
        UNKNOWN: 999
    },
    HEADER_STATUS: {
        PARAMETER_ERROR: 0,
        SUCCESS: 1,
        FAIL_A_TOKEN: 2,
        FAIL_USER_TOKEN: 3,
        FAIL_DUID: 4,
        FAIL_SW_VERSION: 5,
        FAIL_INFOLINK_VERSION: 6,
        FAIL_GPM_URL: 7,
        UNKNOWN: 999
    },
    /*restError:{
			httpStatus:0,
			errorCode:0,
			message:'',
			description:''
		},*/

    init: function () {
        print("[rest]init");
        this.resource_request = new ResourceRequest();

        this.resource_request.setHeader('Content-Type', 'application/json; charset=utf-8');
        this.resource_request.setHeader('Accept', 'application/json');

        this.cur_status = this.REST_STATUS.READY;

        if (false === exports.WAS.isOpened()) exports.WAS.init();
        if (false === exports.device.isOpened()) exports.device.init();

        this.m_bOpened = true;
        return this.m_bOpened;
    },
    isOpened: function () {
        print("[rest]isOpened");
        return this.m_bOpened;
    },
    getCurrentStatus: function () {
        print("[rest]getCurrentStatus");
        return this.cur_status;
    },
    setParam: function (key, value) {
        print("[rest]setParam[" + key + "][" + value + "]");
        if ('string' === typeof (key) && 'string' === typeof (value)) {
            value = encodeURIComponent(value);
            this.uri += key + '=' + value + '&';
            return true;
        }
        return false;
    },
    clearParam: function () {
        print("[rest]clearParam");
        this.uri = '';
        return true;
    },
    setBody: function (value) {
        print("[rest]setBody[" + value + "]");
        if ('string' === typeof (value)) {
            this.resource_request.data = value;
            this.resource_request.setHeader('Content-Length', value.length.toString());
            return true;
        }
        return false;
    },
    clearBody: function () {
        print("[rest]clearBody");
        this.resource_request.data = '';
        this.resource_request.setHeader('Content-Length', '0');
        return true;
    },
    sendAsync: function (method, resourcePath, successCallback, errorCallback, completeCallback) {
        print("[rest]sendAsync[" + method + "][" + resourcePath + "]");
        this.cur_status = this.REST_STATUS.SENDING;

        this.resource_request.async = true;
        this.resource_request.method = method;

        var request_uri = '';
        if (this.smartTVServer) {
            try {
                request_uri = this.getRequestUri(resourcePath);
                print("[rest]request_uri:" + request_uri);
            } catch (e) {
                return e;
            }
        } else {
            request_uri = resourcePath;
        }

        if (this.uri !== '') {
            this.uri = this.uri.slice(0, -1);
            request_uri += '?' + this.uri;
        }
        this.resource_request.uri = request_uri;

        var retry_num = this.retry;
        this.resource_request.success = function (data, status, response) {
            print("[rest]success callback interval_id:" + interval_id);
            print("[rest]success callback retry_num:" + retry_num);
            retry_num = 0;
            Volt.clearInterval(interval_id);
            successCallback(data, status, response);
        };

        this.resource_request.error = function (response, status, exception) {
            print("[rest]error callback retry_num:" + retry_num);
            if (retry_num <= 0) {
                errorCallback(response, status, exception);
            }
        };

        this.resource_request.complete = function (response, status) {
            print("[rest]complete callback retry_num:" + retry_num);
            if (retry_num <= 0) {
                exports.rest.cur_status = exports.rest.REST_STATUS.READY;
                completeCallback(response, status);
            }
        };

        this.resource_request.process();

        var interval_id = Volt.setInterval(function () {
            if (retry_num > 0) {
                print("[rest]retry_num:" + retry_num);
                exports.rest.resource_request.process();
                retry_num--;
            } else {
                print("[rest]interval_id:" + interval_id);
                Volt.clearInterval(interval_id);
            }
        }, this.interval);

        return this.HEADER_STATUS.SUCCESS;
    },
    sendSync: function (method, resourcePath) {
        print("[rest]sendSync[" + method + "][" + resourcePath + "]");
        this.resource_request.async = false;
        this.resource_request.method = method;

        var request_uri = '';
        if (this.smartTVServer) {
            try {
                request_uri = this.getRequestUri(resourcePath);
                print("[rest]request_uri:" + request_uri);
            } catch (e) {
                return e;
            }
        } else {
            request_uri = resourcePath;
        }

        if (this.uri !== '') {
            this.uri = this.uri.slice(0, -1);
            request_uri += '?' + this.uri;
        }
        this.resource_request.uri = request_uri;

        this.resource_request.error = function (response, status, exception) {
            print("[rest]error callback status:" + status);
            print("[rest]error callback exception:" + exception);
            exports.rest.sleep(exports.rest.interval);
        };

        for (var n = 0; n < this.retry; n++) {
            var result = this.resource_request.process();
            if (result === null) {
                print("[rest]result:" + result);
                continue;
            }
            var error = parseInt(result['status']);
            if (error >= 400 || error >= 500) {
                print("[rest]error:" + error);
            } else {
                print("[rest]no error:" + error);
                break;
            }
        }

        return result;
    },
    setHeader: function (key, value) {
        print("[rest]setHeader[" + key + "][" + value + "]");
        if ('string' === typeof (key) && 'string' === typeof (value)) {
            if ('SmartTVClient' === key) {
                value = this.smartTVClientHeader + '+' + value;
            }
            this.resource_request.setHeader(key, value);
            return true;
        }
        return false;
    },
    setContentType: function (type) {
        print("[rest]setContentType[" + type + "]");
        if (type === 'xml') {
            this.resource_request.setHeader('Content-Type', 'application/xml; charset=utf-8');
            this.resource_request.setHeader('Accept', 'application/xml');
            return true;
        } else if (type === 'json') {
            this.resource_request.setHeader('Content-Type', 'application/json; charset=utf-8');
            this.resource_request.setHeader('Accept', 'application/json');
            return true;
        }
        return false;
    },
    setResponseType: function (type) {
        print("[rest]setResponseType[" + type + "]");
        if ('arraybuffer' === type || 'string' === type) {
            this.resource_request.response_type = type;
        } else {
            return false;
        }
        return true;
    },
    //setSmartTVHeader:function(isUse, errorCallback)
    setSmartTVHeader: function (isUse) {
        print("[rest]setSmartTVHeader[" + isUse + "]");
        if ('boolean' !== typeof (isUse)) {
            return this.HEADER_STATUS.PARAMETER_ERROR;
        }

        this.smartTVServer = isUse;
        if (true === isUse) {
            var aToken = Vconf.getString('db/comss/atoken');
            print("[rest]getAToken:" + aToken + ", type is " + typeof (aToken));
            Vconf.setOnChangeHandler('db/comss/atoken', function (key, val) {
                print("[rest]getAToken, key:" + key + ", val:" + val);
            });
            if ('' === aToken) {
                return this.HEADER_STATUS.FAIL_A_TOKEN;
            }

            var userToken = '';
            if (1 === exports.WAS.getSSOLoginState()) {
                userToken = exports.WAS.getSSOToken();
                print("[rest]getSSOToken:" + userToken);
                if ('' === userToken) {
                    return this.HEADER_STATUS.FAIL_USER_TOKEN;
                }
            }

            var DUID = Vconf.getString('db/comss/duid');
            print("[rest]getDuid:" + DUID + ", type is " + typeof (DUID));
            Vconf.setOnChangeHandler('db/comss/duid', function (key, val) {
                print("[rest]getDuid, key:" + key + ", val:" + val);
            });
            if ('' === DUID) {
                return this.HEADER_STATUS.FAIL_DUID;
            }

            //param1:DEVICE_MAIN_TV[0],DEVICE_SBB[1], param2:VERSION_SWVERSION[1]
            var swVersion = exports.device.getSWVersion(0, 1);
            print("[rest]getSWVersion:" + swVersion + ", type is " + typeof (swVersion));
            if ('' === swVersion) {
                return this.HEADER_STATUS.FAIL_SW_VERSION;
            }

            var infolinkVersion = exports.WAS.getInfolinkVer();
            print("[rest]getInfolinkVer:" + infolinkVersion + ", type is " + typeof (infolinkVersion));
            if ('' === infolinkVersion) {
                return this.HEADER_STATUS.FAIL_INFOLINK_VERSION;
            }

            var voltVersion = Volt.getVersion();
            for (var key in voltVersion) {
                print("[rest]Volt.getVersion[" + key + "]" + voltVersion[key] + ", type is " + typeof (voltVersion[key]));
            }

            this.smartTVClientHeader =
                'OTN-FW/' + swVersion +
                '+T-INFOLINK/' + infolinkVersion +
                '+VOLT-ENGINE/' + voltVersion['string'];

            this.resource_request.setHeader('Cache-Control', 'no-cache');
            this.resource_request.setHeader('Accept-Encoding', 'gzip, deflate');
            this.resource_request.setHeader('AToken', aToken);
            this.resource_request.setHeader('UserToken', userToken);
            this.resource_request.setHeader('DUID', DUID);
            this.resource_request.setHeader('SmartTVClient', this.smartTVClientHeader);
        } else {
            this.resource_request.removeHeader('Cache-Control');
            this.resource_request.removeHeader('Accept-Encoding');
            this.resource_request.removeHeader('Host');
            this.resource_request.removeHeader('LocalTime');
            this.resource_request.removeHeader('AToken');
            this.resource_request.removeHeader('UserToken');
            this.resource_request.removeHeader('DUID');
            this.resource_request.removeHeader('SmartTVClient');
        }
        return this.HEADER_STATUS.SUCCESS;
    },
    setTimeout: function (interval, retry) {
        print("[rest]setTimeout[" + interval + "][" + retry + "]");
        if ('number' === typeof (interval) && 'number' === typeof (retry)) {
            this.interval = interval;
            this.retry = retry;
            return true;
        }
        return false;
    },
    setCache: function (isUse) {
        print("[rest]setCache[" + isUse + "]");
        this.resource_request.noCache = isUse;
        return true;
    },
    cancel: function (isUse) {
        print("[rest]cancel[" + isUse + "]");
        return this.resource_request.cancel();
    },
    getRequestUri: function (resourcePath) {
        var key;
        var tmp = resourcePath.split('/');
        if (resourcePath[0] === '/') {
            key = tmp[1];
        } else {
            key = tmp[0];
        }
        print("[rest]vconf gpmurl key:" + key);
        var domain = Vconf.getString('db/comss/gpmurl/' + key);
        print("[rest]request domain:" + domain);
        if (domain === undefined || domain === '') {
            throw this.HEADER_STATUS.FAIL_GPM_URL;
        }

        var begine_str = '://';
        var begin = domain.indexOf(begine_str);
        var end = domain.lastIndexOf(':');
        var host = "";
        print("[rest]begin[" + begin + "]end[" + end + "]");
        if (-1 === begin || -1 === end) {
            host = domain;
        } else if (begin === end) {
            host = domain.substring(begin + begine_str.length, domain.length);
        } else {
            host = domain.substring(begin + begine_str.length, end);
        }
        print("[rest]host:" + host);
        this.resource_request.setHeader('Host', host);

        var localtime = this.getLocalTime();
        print("[rest]localtime:" + localtime);
        this.resource_request.setHeader('LocalTime', localtime);

        requset_uri = domain + '/' + resourcePath;

        return requset_uri;
    },
    getLocalTime: function () {
        var curDateTime = new Date();
        var localDateTime = curDateTime.getFullYear() + '-';
        if ((curDateTime.getMonth() + 1) < 10) {
            localDateTime += '0';
        }
        localDateTime += (curDateTime.getMonth() + 1) + '-';

        if (curDateTime.getDate() < 10) {
            localDateTime += '0';
        }
        localDateTime += curDateTime.getDate() + 'T';

        if (curDateTime.getHours() < 10) {
            localDateTime += '0';
        }
        localDateTime += curDateTime.getHours() + ':';

        if (curDateTime.getMinutes() < 10) {
            localDateTime += '0';
        }
        localDateTime += curDateTime.getMinutes() + ':';

        if (curDateTime.getSeconds() < 10) {
            localDateTime += '0';
        }
        localDateTime += curDateTime.getSeconds() + '+';


        var gmtOffsetHour = Math.floor(-(curDateTime.getTimezoneOffset() / 60));
        if (curDateTime.getTimezoneOffset() > 0) {
            gmtOffsetHour = Math.ceil(-(curDateTime.getTimezoneOffset() / 60));
        }
        var gmtOffsetMin = (-(curDateTime.getTimezoneOffset() % 60));
        gmtOffsetMin = Math.abs(gmtOffsetMin);

        if (gmtOffsetHour < 10) {
            localDateTime += '0';
        }
        localDateTime += gmtOffsetHour + ':';

        if (gmtOffsetMin < 10) {
            localDateTime += '0' + gmtOffsetMin;
        }
        localDateTime += gmtOffsetMin;

        return localDateTime;
    },
    sleep: function (ms) {
        var curTime = new Date();
        var exitTime = curTime.getTime() + (ms);
        while (true) {
            curTime = new Date();
            if (curTime.getTime() > exitTime) return;
        }
    }
};

var sefFactory = new SefFactory();

Volt.addEventListener(Volt.ON_UNLOAD, function () {
    sefFactory.allReleaseSEF();
    print("--------------------------------------->>[VOLT ON_UNLOAD] SEF ALL Release!!!!!!!!!!!!!!!!");
});


function SefFactory() {
    sefMap = {};
    /**
     * @ignore
     */
    this.init = function (name) {
        if (sefMap[name] == null) {
            sefMap[name] = new Sef();
            return sefMap[name].open(name, "1.00", name);
        }
        print("AlreadyInitializedException : " + name);
        // throw "AlreadyInitializedException : " + name;
    };
    this.initAsync = function (name, onOpenCallback) {
        if (sefMap[name] == null) {
            sefMap[name] = new Sef();
            return sefMap[name].openAsync(name, "1.00", name, function () {
                onOpenCallback();
            });

            print("AlreadyInitializedException : " + name);
        }
    };
    this.getSEF = function (name) {
        if (sefMap[name] == null) {
            throw "NoInitializationException : " + name;
        }
        return sefMap[name];
    };
    this.releaseSEF = function (name) {
        if (sefMap[name] != null) {
            sefMap[name].close();
            delete sefMap[name];
        }
    };
    this.allReleaseSEF = function () {
        for (var p in aPlayerInstance) {
            if (p != null) {
                aPlayerInstance[p].close();
                delete aPlayerInstance[p];
            }
        }
        for (var idx in sefMap) {
            if (idx != null) {
                sefMap[idx].close();
                delete sefMap[idx];

            }
        }
    };

}




var CSFLocalAPI = {};
//var CSFeventList = {};
var CSFcbList = {};
var CSFState = {

    SEF_CSF_EVENT_REQUEST_LIST_SUCCESS: 0,
    SEF_CSF_EVENT_REQUEST_LIST_FAIL: 1,
    SEF_CSF_EVENT_REQUEST_DETAIL_SUCCESS: 2,
    SEF_CSF_EVENT_REQUEST_DETAIL_FAIL: 3,
    SEF_CSF_EVENT_ACT_SUCCESS: 4,
    SEF_CSF_EVENT_ACT_FAIL: 5,
    SEF_CSF_EVENT_DISCONNECT_SUCCESS: 6,
    SEF_CSF_EVENT_DISCONNECT_FAIL: 7,
    SEF_CSF_EVENT_REQUEST_LIST_EMPTY: 8,
    SEF_CSF_EVENT_REQUEST_DETAIL_EMPTY: 9,
    SEF_CSF_EVENT_ACT_PROGRESS_UPDATE: 10,

    //share
    SEF_CSF_EVENT_SHARE_DONE: 11,
    SEF_CSF_EVENT_SHARE_COMPLETE: 12,
    SEF_CSF_EVENT_SHARE_FAIL: 13,
    SEF_CSF_EVENT_SHARE_SOURCE_DEVICE_DISCONNECT: 14,
    SEF_CSF_EVENT_SHARE_DEST_DEVICE_DISCONNECT: 15,
    SEF_CSF_EVENT_SHARE_PVR_IS_RECORDING: 16,
    SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED: 17,
    SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED: 18,
    SEF_CSF_EVENT_SHARE_FILE_UPDATE: 19,

    //RA
    SEF_CSF_EVENT_RA_DEVICE_CONNECTED: 20,
    SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED: 21,

    //DLNA
    SEF_CSF_EVENT_DLNA_DEVICE_CONNECTED: 22,
    SEF_CSF_EVENT_DLNA_DEVICE_DISCONNECTED: 23,
    SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED: 24,
    SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED_ALL: 25,
    SEF_CSF_EVENT_PARTIAL_LIST_UPDATE: 26,

    CSF_EVENT_THUMBNAIL_FINISHED: 100,
    CSF_EVENT_THUMBNAIL_FAIL: 101,
    CSF_EVENT_THUMBNAIL_UNKNOW: 102

};

/**
 * @author sunjung.yoo@samsung.com
 * @fn _onCSFCallBackEvent
 * @description CSF Event Callback
 * @param
 * @returns
 */

function _onCSFCallBackEvent(eventType, param1, param2) {
    print("EVENT:[" + eventType + "].param1[" + param1 + "].param2[" + param2 + "] ");
    if (typeof CSFcbList[String(eventType)] == 'undefined') {
        return;
    }
    var callbackFunc = null;

    if (isArray(CSFcbList[String(eventType)])) {
        var callbacks = CSFcbList[String(eventType)];
        for (var i = 0; i < callbacks.length; i++) {
            callbackFunc = callbacks[i];
            callbackFunc(param1, param2);
        }
    } else {
        CSFcbList[String(eventType)](param1, param2);
    }
};

/**
 * @namespace CSF
 */
exports.CSF = {
    m_bOpened: false,
    m_bOpenedthumbnail: false,

    FOLDER_VIEW_FILE_TYPE_IMAGE: 0,
    FOLDER_VIEW_FILE_TYPE_VIDEO: 1,
    FOLDER_VIEW_FILE_TYPE_SOUND: 2,
    FOLDER_VIEW_FILE_TYPE_MUSIC: 3,
    FOLDER_VIEW_FILE_TYPE_FOLDER: 4,
    FOLDER_VIEW_FILE_TYPE_RECORDTV: 5,
    FOLDER_VIEW_FILE_TYPE_M3U: 6,
    FOLDER_VIEW_FILE_TYPE_AUDIO: 7,
    FOLDER_VIEW_FILE_TYPE_GROUP: 8,
    FOLDER_VIEW_FILE_TYPE_UHD: 9,
    FOLDER_VIEW_FILE_TYPE_SCSA: 10,

    init: function () {
        print(" --->> init();");
        // this.m_SEFCSF = new Sef();
        // this.m_bOpened = this.m_SEFCSF.open("Local", "1.003", "Local");
        // this.m_SEFCSFthumbnail = new Sef();
        // this.m_bOpenedthumbnail = this.m_SEFCSFthumbnail.open("CsfThumbnail",
        // "1.003", "CsfThumbnail");
        this.csfLocalApiListInit();
        this.m_bOpened = sefFactory.init("Local");
        this.m_bOpenedthumbnail = sefFactory.init("CsfThumbnail");

        print(" --->> Open();", this.m_bOpened);
        print(" --->> thumbnailOpened();", this.m_bOpenedthumbnail);
        sefFactory.getSEF("Local").onEventCallback = _onCSFCallBackEvent;
        sefFactory.getSEF("CsfThumbnail").onEventCallback = _onCSFCallBackEvent;

        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        //var $this = this;
        this.csfLocalApiListInit();
        this.m_bOpened = sefFactory.initAsync("Local", function () {
            print(" --->> OpenAsync();");
        });
        this.m_bOpenedthumbnail = sefFactory.initAsync("CsfThumbnail", OpenCallback);
        //print(" --->> OpenAsync();", this.m_bOpened);
        print(" --->> thumbnailOpened();", this.m_bOpenedthumbnail);
        sefFactory.getSEF("Local").onEventCallback = _onCSFCallBackEvent;
        sefFactory.getSEF("CsfThumbnail").onEventCallback = _onCSFCallBackEvent;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    isOpenedthumbnail: function () {
        return this.m_bOpenedthumbnail;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("Local");
        sefFactory.releaseSEF("CsfThumbnail");
    },
    csfLocalApiListInit: function () {
        CSFLocalAPI["csfCancelRequestList"] = "csf_cancel_request_list";
        CSFLocalAPI["csfSetNavigation"] = "csf_set_navigation";
        CSFLocalAPI["csfMoveToIndex"] = "csf_move_to_index";
        CSFLocalAPI["csfGetItemCount"] = "csf_get_item_count";
        CSFLocalAPI["csfGetItemValueTime"] = "csf_get_item_value_time";
        CSFLocalAPI["csfGetItemValueLint"] = "csf_get_item_value_lint";
        CSFLocalAPI["csfGetItemValueChar"] = "csf_get_item_value_char";
        CSFLocalAPI["csfGetItemValueInt"] = "csf_get_item_value_int";
        CSFLocalAPI["csfGetItemValueBool"] = "csf_get_item_value_bool";
        CSFLocalAPI["csfGetItemValueDouble"] = "csf_get_item_value_double";
        CSFLocalAPI["csfSetItemValueTime"] = "csf_set_item_value_time";
        CSFLocalAPI["csfSetItemValueInt"] = "csf_set_item_value_int";
        CSFLocalAPI["csfSetItemValueChar"] = "csf_set_item_value_char";
        CSFLocalAPI["csfGetPlayerIndex"] = "csf_get_player_index";
        CSFLocalAPI["csfGetBrowseIndex"] = "csf_get_browse_index";
        CSFLocalAPI["csfGetItemCountOfGroup"] = "csf_get_item_count_of_group";
        CSFLocalAPI["csfAddFile"] = "csf_add_file";
        CSFLocalAPI["csfDeleteFile"] = "csf_delete_file";
        CSFLocalAPI["csfSelectAll"] = "csf_select_all";
        CSFLocalAPI["csfDeselectAll"] = "csf_deselect_all";
        CSFLocalAPI["csfDisconnect"] = "csf_disconnect";
        CSFLocalAPI["csfGetSelectedState"] = "csf_get_selected_state";
        CSFLocalAPI["csfGetSelectionCount"] = "csf_get_selection_count";
        CSFLocalAPI["csfToggleSelect"] = "csf_toggle_select";
        CSFLocalAPI["csfSetPageStyle"] = "csf_set_page_style";
        CSFLocalAPI["csfPreparePlayData"] = "csf_prepare_play_data";
        CSFLocalAPI["csfPlayListAddPlaylist"] = "csf_playlist_add_playlist";
        CSFLocalAPI["csfPlaylistAddItem"] = "csf_playlist_add_item";
        CSFLocalAPI["csfPlaylistRename"] = "csf_playlist_rename";
        CSFLocalAPI["csfPlaylistDelete"] = "csf_playlist_delete";
        CSFLocalAPI["csfPlaylistDeleteItem"] = "csf_playlist_delete_item";
        CSFLocalAPI["csfGetVideoCodec"] = "csf_get_video_codec";
        CSFLocalAPI["csfGetAudioCodec"] = "csf_get_audio_codec";
        CSFLocalAPI["csfRequestList"] = "csf_request_list";
        CSFLocalAPI["csfRequestPlayList"] = "csf_request_play_list";
        CSFLocalAPI["csfRequestDetail"] = "csf_request_detail";
        CSFLocalAPI["csfSetLike"] = "csf_set_like";
        CSFLocalAPI["csfUploadComment"] = "csf_upload_comment";
        CSFLocalAPI["csfCreateAlbum"] = "csf_create_album";
        CSFLocalAPI["csfSend"] = "csf_send";
        CSFLocalAPI["csfStopSend"] = "csf_stop_send";
        CSFLocalAPI["csfCancelDetail"] = "csf_cancel_detail";
        CSFLocalAPI["csfGetGroupCount"] = "csf_get_group_count";
        CSFLocalAPI["csfGetDetailItemValueChar"] = "csf_get_detail_item_value_char";
        CSFLocalAPI["csfGetDetailItemValueInt"] = "csf_get_detail_item_value_int";
        CSFLocalAPI["csfGetDetailItemValueBool"] = "csf_get_detail_item_value_bool";
        CSFLocalAPI["csfGetItem"] = "csf_get_item";
        CSFLocalAPI["csfRaGetDeviceList"] = "csf_ra_get_device_list";
        CSFLocalAPI["csfGetDlnaList"] = "csf_get_dlna_list";
        CSFLocalAPI["csfSelectGroup"] = "csf_select_group";
        CSFLocalAPI["csfSetExpandMode"] = "csf_set_expand_mode";
        CSFLocalAPI["csfPlaylistGetPlaylistCount"] = "csf_playlist_get_playlist_count";
        CSFLocalAPI["csfPlaylistGetPlaylist"] = "csf_playlist_get_playlist";
        CSFLocalAPI["csfPlaylistGetItemCount"] = "csf_playlist_get_item_count";
        CSFLocalAPI["csfPlaylistGetItem"] = "csf_playlist_get_item";
        CSFLocalAPI["csfGetNavigation"] = "csf_get_navigation";
        CSFLocalAPI["csfGetPageIndex"] = "csf_get_page_index";
        CSFLocalAPI["csfGetItemList"] = "csf_get_item_list";
        CSFLocalAPI["csfSetItemValue"] = "csf_set_item_value";
        CSFLocalAPI["csfDeselectGroup"] = "csf_deselect_group";
        CSFLocalAPI["csfGetRatingInfo"] = "csf_get_rating_info";

    },
    // plug-in name : Local]
    csfLocalFunction: function (functionName, isReturnJson, option) {
        if (!this.m_bOpened) return false;
        if (typeof functionName != "string" || functionName == "undefined") {
            print("--->> Player Open TYPE_MISMATCH_ERR");
            return false;
        }
        if (isReturnJson == "undefined") {
            print("--->> isReturnJson undefined");
            isReturnJson = false;
        }
        if (option.param_input == "undefined") {
            if (isReturnJson)
                return JSON.parse(sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName]));
            else
                return sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName]);
        } else {
            if (isReturnJson)
                return JSON.parse(sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName], JSON.stringify(optionparam_input)));
            else
                return sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName], JSON.stringify(option.param_input));
        }
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfCancelRequestList
     * @description Cancel the data request.
     * @param Json
     *            String
     * @returns Boolean
     */
    csfCancelRequestList: function (param_input) {
        print(" --->> csfCancelRequestList();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_cancel_request_list", JSON.stringify(param_input));;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSetNavigation
     * @description In player side, when in player view mode or going on
     *              selected play, after request list, should called this
     *              interface.
     * @param Json
     *            String
     * @returns Boolean
     */
    csfSetNavigation: function (param_input) {
        print(" --->> csfSetNavigation();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_set_navigation", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfMoveToIndex
     * @description Move focus to the assigned item
     * @param Json
     *            String
     * @returns Boolean
     */
    csfMoveToIndex: function (param_input) {
        print(" --->> csfMoveToIndex();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_move_to_index", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetItemCount
     * @description Get items’ count when date request finished
     * @param Json
     *            String
     * @returns Json Object
     */
    csfGetItemCount: function (param_input) {
        print(" --->> csfGetItemCount();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_item_count", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetItemCountOfGroup
     * @description Get the items’ cout of one group
     * @param Json
     *            String
     * @returns Json Object
     */
    csfGetItemCountOfGroup: function (param_input) {
        print(" --->> csfGetItemCountOfGroup();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_item_count_of_group", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSelectAll
     * @description Select all one type of media files in browser.
     * @param Json
     *            String
     * @returns Boolean
     */
    csfSelectAll: function (param_input) {
        print(" --->> csfSelectAll();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_select_all", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfDeselectAll
     * @description Deselected all items which were selected just now
     * @param Json
     *            String
     * @returns Boolean
     */
    csfDeselectAll: function (param_input) {
        print(" --->> csfDeselectAll();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_deselect_all", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfDisconnect
     * @description When the data requested was not used from now on, should
     *              call this interface to release related recources
     * @param Json
     *            String
     * @returns Boolean
     */
    csfDisconnect: function (param_input) {
        print(" --->> csfDisconnect();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_disconnect", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetSelectedState
     * @description Decide if the item was selected
     * @param Json
     *            String
     * @returns Json Object
     */
    csfGetSelectedState: function (param_input) {
        print(" --->> csfGetSelectedState();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_selected_state", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetSelectionCount
     * @description Get the count how many items were selected
     * @param Json
     *            String
     * @returns Json Obejct
     */
    csfGetSelectionCount: function (param_input) {
        print(" --->> csfGetSelectionCount();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_selection_count", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfToggleSelect
     * @description Call this interface to select one item or unselect one item
     * @param Json
     *            String
     * @returns Boolean
     */
    csfToggleSelect: function (param_input) {
        print(" --->> csfToggleSelect();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_toggle_select", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSetPageStyle
     * @description This interface should be called first when request over, and
     *              receive the message from csf
     * @param Json
     *            String
     * @returns Boolean
     */
    csfSetPageStyle: function (param_input) {
        print(" --->> csfSetPageStyle();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_set_page_style", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPreparePlayData
     * @description When you want to launch a player, you should call this
     *              interface first
     * @param Json
     *            String
     * @returns Json Obejct
     */
    csfPreparePlayData: function (param_input) {
        print(" --->> csfPreparePlayData();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_prepare_play_data", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlayListAddPlaylist
     * @description Create a new playlist file.
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlayListAddPlaylist: function (param_input) {
        print(" --->> csfPlayListAddPlaylist();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_add_playlist", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistAddItem
     * @description Add one item to the exiting playlist file.
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistAddItem: function (param_input) {
        print(" --->> csfPlaylistAddItem();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_add_item", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistRename
     * @description Modify the name of playlist file.
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistRename: function (param_input) {
        print(" --->> csfPlaylistRename();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_rename", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistDelete
     * @description Delete a playlist file from usb disk
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistDelete: function (param_input) {
        print(" --->> csfPlaylistDelete();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_delete", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistDeleteItem
     * @description Delete one item from the existing playlist file.
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistDeleteItem: function (param_input) {
        print(" --->> csfPlaylistDeleteItem();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_delete_item", JSON.stringify(param_input));
    },

    /**
     * @author sumin_.park@samsung.com
     * @fn csfRequestList
     * @description To set like/unlike to a specific item on web
     * @param Json
     *            String
     * @returns Json Obejct
     */
    csfRequestList: function (param_input) {
        //CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_LIST_SUCCESS] = successCallback;
        //CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_LIST_FAIL] = errorCallback;
        //CSFeventList[CSFState.CSF_EVENT_REQUEST_LIST_EMPTY] = errorCallback;
        print(" --->> csfRequestList();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_request_list", JSON.stringify(param_input)));;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfRequestDetail
     * @description Request a specific item from web .
     * @param Json
     *            String
     * @returns Json Obejct
     */
    csfRequestDetail: function (param_input) {

        print(" --->> csfRequestDetail();", param_input);
        //CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_DETAIL_SUCCESS] = successCallback;
        //CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_DETAIL_FAIL] = errorCallback;
        //CSFeventList[CSFState.CSF_EVENT_REQUEST_LIST_EMPTY] = errorCallback;
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_request_detail", JSON.stringify(param_input)));;

    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSetLike
     * @description To set like/unlike to a specific item on web
     * @param Json
     *            String
     * @returns Json Obejct
     */
    csfSetLike: function (param_input) {
        print(" --->> csfSetLike();", param_input);
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;		
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_set_like", JSON.stringify(param_input)));;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfUploadComment
     * @description To add comment to a specific item on web
     * @param Json
     *            String
     * @returns Json Obejct
     */
    csfUploadComment: function (param_input) {
        print(" --->> csfUploadComment();", param_input);
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;	
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_upload_comment", JSON.stringify(param_input)));;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfCreateAlbum
     * @description To create an album in facebook account
     * @param Json
     *            String
     * @returns Boolean
     */
    csfCreateAlbum: function (param_input) {
        print(" --->> csfCreateAlbum();", param_input);
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;	
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_create_album", JSON.stringify(param_input));;

    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSend
     * @description To send file between usb & web<ra, webstorage, sns>,
     *              lock/unlock pvr file, delete pvr file
     * @param Json
     *            String
     * @returns Boolean
     */
    csfSend: function (param_input) {
        print(" --->> csfSend();", param_input);
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
        //CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;	
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_send", JSON.stringify(param_input));;

    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfStopSend
     * @description To stop send operation
     * @param Json
     *            String
     * @returns Json Object
     */
    csfStopSend: function (param_input) {
        print(" --->> csfStopSend();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_stop_send", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfCancelDetail
     * @description To cancel request detail operation
     * @param Json
     *            String
     * @returns Json Object
     */
    csfCancelDetail: function (param_input) {
        print(" --->> csfCancelDetail();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_cancel_detail", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetGroupCount
     * @description To get group count
     * @param Json
     *            String
     * @returns Json Object
     */
    csfGetGroupCount: function (param_input) {
        print(" --->> csfGetGroupCount();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_group_count", JSON.stringify(param_input)));
    },

    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetItem
     * @description Get item info which was focused
     * @param Json
     *            String
     * @returns Json Object
     */
    csfGetItem: function (param_input) {

        print(" --->> csfGetItem();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_item", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfRaGetDeviceList
     * @description get RA device list.
     * @param Json
     *            String
     * @returns Json Object
     */
    csfRaGetDeviceList: function () {

        print(" --->> csfRaGetDeviceList();");
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_ra_get_device_list"));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetDlnaList
     * @description Get dlan item list
     * @param Json
     *            String
     * @returns Json Object
     */
    csfGetDlnaList: function () {
        print(" --->> csfGetDlnaList();");
        //CSFeventList[CSFState.SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED] = successCallback;
        //try {

        //} catch (e) {
        //	return 'Failed to handle the Execute call.';
        //}
        return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_dlna_list"));;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSelectGroup
     * @description Select all items of one group
     * @param Json
     *            String
     * @returns Boolean
     */
    csfSelectGroup: function (param_input) {

        print(" --->> csfSelectGroup();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_select_group", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSetExpandMode
     * @description Decide expand or pack up a group
     * @param Json
     *            String
     * @returns Boolean
     */
    csfSetExpandMode: function (param_input) {

        print(" --->> csfSetExpandMode();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_set_expand_mode", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistGetPlaylistCount
     * @description Get playlist count of a usb device
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistGetPlaylistCount: function (param_input) {

        print(" --->> csfPlaylistGetPlaylistCount();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_get_playlist_count", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistGetPlaylist
     * @description Get properties of a playlist file in a usb device
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistGetPlaylist: function (param_input) {

        print(" --->> csfPlaylistGetPlaylist();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_get_playlist", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistGetItemCount
     * @description Get count of songs in a playlist file
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistGetItemCount: function (param_input) {

        print(" --->> csfPlaylistGetItemCount();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_get_item_count", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfPlaylistGetItem
     * @description Get properties of a song in a playlist file
     * @param Json
     *            String
     * @returns Boolean
     */
    csfPlaylistGetItem: function (param_input) {

        print(" --->> csfPlaylistGetItem();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_playlist_get_item", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetNavigation
     * @description App can call this interface to know the state of navigation
     * @param Json
     *            String
     * @returns Boolean
     */
    csfGetNavigation: function (param_input) {

        print(" --->> csfGetNavigation();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_get_navigation", JSON.stringify(param_input));
    },
    //2014/07/18일 추가
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetPageIndex
     * @description Get start index in player or focues index in browser
     * @param Json String
     * @returns
     */
    csfGetPageIndex: function (param_input) {

        print(" --->> csfGetPageIndex();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_get_page_index", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetItemList
     * @description Get all items’ properties
     * @param Json String
     * @returns
     */
    csfGetItemList: function (param_input) {

        print(" --->> csfGetItemList();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_get_item_list", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfSetItemValue
     * @description Set item value in db
     * @param Json String
     * @returns
     */
    csfSetItemValue: function (param_input) {

        print(" --->> csfSetItemValue();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_set_item_value", JSON.stringify(param_input));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn csfDeselectGroup
     * @description Deselect all items of a group
     * @param Json String
     * @returns
     */
    csfDeselectGroup: function (param_input) {

        print(" --->> csfDeselectGroup();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_deselect_group", JSON.stringify(param_input));
    },

    /**
     * @author sumin_.park@samsung.com
     * @fn csfGetItemValue
     * @description Get item value in db
     * @param Json String
     * @returns
     */
    csfGetItemValue: function (param_input) {
        print(" --->> csfGetItemValue();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_get_item_value", JSON.stringify(param_input));
    },

    /**
     * @author jieun24.lee@samsung.com
     * @fn csfGetRatingInfo
     * @description Get rating information about UHD file
     * @param Json String
     * @returns
     */
    csfGetRatingInfo: function (param_input) {
        print(" --->> csfGetRatingInfo();", param_input);
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return sefFactory.getSEF("Local").execute("csf_get_rating_info", JSON.stringify(param_input));
    },

    // thumbnail
    /**
     * @author sumin_.park@samsung.com
     * @fn thumbnailRequestAsync
     * @description
     * @param Json
     *            String
     * @returns Json Obejct
     */
    thumbnailRequestAsync: function (param_input) {
        //CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FINISHED] = successCallback;
        //CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FAIL] = errorCallback;		
        print(" --->> thumbnailRequestAsync();");
        //		try {
        //			
        //			result = JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_async", JSON.stringify(param_input)));
        //		} catch (e) {
        //			return 'Failed to handle the Execute call.';
        //		}
        return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_async", JSON.stringify(param_input)));;

    },
    /**
     * @author sumin_.park@samsung.com
     * @fn thumbnailRequestHttpBufferAsync
     * @description
     * @param Json
     *            String
     * @returns Json Obejct
     */
    thumbnailRequestHttpBufferAsync: function (param_input) {
        print(" --->> thumbnailRequestHttpBufferAsync();");
        //CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FINISHED] = successCallback;
        //CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FAIL] = errorCallback;		
        //		try {
        //			
        //			result = JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_http_buffer_async", JSON.stringify(param_input)));
        //		} catch (e) {
        //			return 'Failed to handle the Execute call.';
        //		}
        return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_http_buffer_async", JSON.stringify(param_input)));

    },
    /**
     * @author sumin_.park@samsung.com
     * @fn thumbnailRequestCancelAll
     * @description
     * @param Json
     *            String
     * @returns Json Obejct
     */
    thumbnailRequestCancelAll: function (param_input) {
        print(" --->> thumbnailRequestCancelAll();");
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_cancel_all", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn thumbnailStopPtpDecodeSync
     * @description
     * @param Json
     *            String
     * @returns Json Obejct
     */
    thumbnailStopPtpDecodeSync: function (param_input) {
        print(" --->> thumbnailStopPtpDecodeSync();");
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_stop_ptp_decode_sync", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn thumbnailStopRaDecodeSync
     * @description
     * @param Json
     *            String
     * @returns Json Obejct
     */
    thumbnailStopRaDecodeSync: function (param_input) {
        print(" --->> thumbnailStopRaDecodeSync();");
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_stop_ra_decode_sync", JSON.stringify(param_input)));
    },
    /**
     * @author sunjung.yoo@samsung.com
     * @fn addEventListener
     * @description
     * @param
     * @returns
     */
    addEventListener: function (eventType, cb) {
        print("---------------------------------------->> addEventListener");
        if (typeof CSFcbList[String(eventType)] == 'undefined') {
            CSFcbList[String(eventType)] = cb;
            return;
        }
        if (typeof CSFcbList[String(eventType)] == 'function' && !isArray(CSFcbList[String(eventType)])) {
            var tempCB = CSFcbList[String(eventType)];
            CSFcbList[String(eventType)] = [];
            CSFcbList[String(eventType)].push(tempCB);
            CSFcbList[String(eventType)].push(cb);
            return;
        }
        if (isArray(CSFcbList[String(eventType)])) {
            CSFcbList[String(eventType)].push(cb);
        }
    }
};

/**
 * @namespace audio
 */
exports.audio = {
    /** ** sound */
    SOUND_MUTE_ON: "1",
    /** ** sound */
    SOUND_MUTE_OFF: "0",
    /** ** sound */
    SOUND_USER_MUTE_ON: 1,
    /** ** sound */
    SOUND_USER_MUTE_OFF: 0,
    /** ** sound */
    SOUND_DOWN: "1",
    /** ** sound */
    SOUND_UP: "0",

    /** ** outmode */
    PL_AUDIO_AUDIO_OUT_MODE_PCM: 0,
    /** ** outmode */
    PL_AUDIO_AUDIO_OUT_MODE_DOLBY: 1,
    /** ** outmode */
    PL_AUDIO_AUDIO_OUT_MODE_DTS: 2,
    /** ** outmode */
    PL_AUDIO_OUTPUT_DEVICE_MAIN_SPEAKER: 0,
    /** ** outmode */
    PL_AUDIO_OUTPUT_DEVICE_EARPHONE: 1,
    /** ** outmode */
    PL_AUDIO_OUTPUT_DEVICE_SUBWOOFER: 2,
    /** ** outmode */
    PL_AUDIO_OUTPUT_DEVICE_EXTERNAL: 3,
    /** ** outmode */
    PL_AUDIO_OUTPUT_DEVICE_RECEIVER: 4,

    m_SEFAudio: null,
    m_bOpened: false,

    /**
     * @fn Boolean init()
     * @description Audio EMP 초기화 함수
     * @returns {Boolean}
     */
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("Audio");
        print(" --->> Audio isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    /**
     * @fn Boolean initAsync()
     * @description Audio EMP 초기화 함수
     * @returns {Boolean}
     */
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Audio", OpenCallback);
        print(" --->> Audio isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    /**
     * @fn Boolean isOpened()
     * @description Audio EMP가 초기
     * @returns {Boolean}
     */
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("Audio");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 외부 출력모드를 체크한다.
     * @param enum
     * @return String
     */
    checkExternalOutMode: function () {
        print(" --->> checkExternalOutMode();");
        return sefFactory.getSEF("Audio").execute("CheckExternalOutMode");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 외부 출력모드를 반환한다.
     * @return String
     */
    getExternalOutMode: function () {
        print(" --->> GetExternalOutMode();");
        return sefFactory.getSEF("Audio").execute("GetExternalOutMode");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 현재 음소거 상태를 얻는다.
     * @return enum
     */
    getMute: function () {
        print(" --->> GetMute();");
        return sefFactory.getSEF("Audio").execute("GetMute");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 현재 아웃 디바이스를 얻는다.
     * @return enum
     */
    getOutputDevice: function () {
        print(" --->> GetOutputDevice();");
        return sefFactory.getSEF("Audio").execute("GetOutputDevice");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 현재 음소거 상태를 얻는다.
     * @return enum
     */
    getUserMute: function () {
        print(" --->> GetUserMute();");
        return sefFactory.getSEF("Audio").execute("GetUserMute");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 현재 볼륨을 얻는다.
     * @return number
     */
    getVolume: function () {
        print(" --->> GetVolume();");
        return sefFactory.getSEF("Audio").execute("GetVolume");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 현재 볼륨에 상대적인 값을 조절한다.
     * @param String
     * @return enum
     */
    setRelativeVolume: function (volume) {
        print(" --->> SetRelativeVolume();");
        return sefFactory.getSEF("Audio").execute("SetRelativeVolume", String(volume));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 음소거 상태를 설정한다.
     * @param enum
     * @return boolean
     */
    setUserMute: function (mute) {
        print(" --->> SetUserMute();");
        return sefFactory.getSEF("Audio").execute("SetUserMute", String(mute));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 볼륨을 설정한다.
     * @param String
     * @return enum
     */
    setVolume: function (volume) {
        print(" --->> SetVolume();");
        sefFactory.getSEF("Audio").execute("SetVolume", String(volume));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 볼륨 1을 증가 시킨다.
     */
    volumeUp: function () {
        print(" --->> volumeUp();");
        sefFactory.getSEF("Audio").execute("SetVolumeWithKey", this.SOUND_UP);
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 볼륨 1을 감소 시킨다.
     */
    volumeDown: function () {
        print(" --->> volumeDown();");
        sefFactory.getSEF("Audio").execute("SetVolumeWithKey", this.SOUND_DOWN);
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 버전을 리턴한다.
     * @return String
     */
    getVersion: function () {
        print(" --->> getVersion();");
        return sefFactory.getSEF("Audio").execute("GetVersion");
    }
};

/**
 * @namespace WAS
 */
exports.AUI = {
    /** ** sound_type */
    AUDIO_SOUND_TYPE_UP: 1,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_DOWN: 2,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_LEFT: 3,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_RIGHT: 4,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_PAGE_LEFT: 5,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_PAGE_RIGHT: 6,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_BACK: 7,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_SELECT: 8,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_CANCEL: 9,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_WARNING: 10,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_KEYPAD: 11,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_KEYPAD_ENTER: 12,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_KEYPAD_DEL: 13,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_SMARTCONTROL_MOVE: 14,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_SMARTCONTROL_SELECT: 15,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_MOVE: 16,
    /** ** sound_type */
    AUDIO_SOUND_TYPE_PREPARING: 17,

    m_SEFAudio: null,
    m_bOpened: false,

    /**
     * @fn Boolean init()
     * @description AUI EMP 초기화 함수
     * @returns {Boolean}
     */
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("AUI");
        print(" --->> Audio isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    /**
     * @fn Boolean initAsync()
     * @description AUI EMP 초기화 함수
     * @returns {Boolean}
     */
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("AUI", OpenCallback);
        print(" --->> Audio isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    /**
     * @fn Boolean isOpened()
     * @description AUI EMP가 open여부 확인
     * @returns {Boolean}
     */
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("Audio");
    },
    /**
     * @author yj14.lee@samsung.com
     * @description 설정된 비프음을 play한다.
     * @param enum
     */
    playAudio: function (soundType) {
        print(" --->> playSound();");
        sefFactory.getSEF("AUI").execute("PlayAudio", String(soundType));
    }
}

/**
 * @namespace WAS
 */
exports.WAS = {

    WAS_EVENT_DOWNLOADING: 100,
    WAS_EVENT_DOWNLOAD_COMPLETED: 101,
    WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST: 102,
    WAS_EVENT_DOWNLOAD_FAIL_NOSPACE: 103,
    WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR: 104,
    WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR: 105,
    WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR: 106,
    WAS_EVENT_DOWNLOAD_FAIL_OTHERS: 107,
    //install		
    WAS_EVENT_INSTALLING: 200,
    WAS_EVENT_INSTALL_CANCLE_COMPLETED: 201,
    WAS_EVENT_INSTALL_CANCLE_FAILED: 202,
    WAS_EVENT_INSTALL_COMPLETED: 203,
    WAS_EVENT_INSTALL_FAIL_EXIST: 204,
    WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR: 205,
    WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR: 206,
    WAS_EVENT_INSTALL_FAIL_OTHERS: 207,
    WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE: 208,
    //uninstall		
    WAS_EVENT_UNINSTALLING: 300,
    WAS_EVENT_UNINSTALL_COMPLETED: 301,
    WAS_EVENT_UNINSTALL_FAIL_NOT_EXIST: 302,
    WAS_EVENT_UNINSTALL_FAIL_PKGMGR_ERROR: 303,
    WAS_EVENT_UNINSTALL_FAIL_NOT_REMOVABLE: 304,
    WAS_EVENT_UNINSTALL_FAIL_OTHERS: 305,
    //apps sync		
    WAS_EVENT_APPS_SYNC_COMPLETED: 400,
    WAS_EVENT_APPS_SYNC_FAIL_NETWORK_ERROR: 401,
    WAS_EVNET_APPS_SYNC_FAIL_OTHERS: 402,
    //emp monitor		
    WAS_EVENT_EMP_MONITOR_INSTALL: 500,
    WAS_EVENT_EMP_MONITOR_UNINSTALL: 501,
    WAS_EVENT_EMP_MONITOR_UPDATE: 502,
    // launcher		
    WAS_EVENT_LAUNCHER_LAUNCH_START: 600,
    WAS_EVENT_LAUNCHER_LAUNCH: 601,
    WAS_EVENT_LAUNCHER_SHOW: 602,
    WAS_EVENT_LAUNCHER_TERMINATE: 603,
    WAS_EVENT_LAUNCHER_FAIL_NOT_EXIST: 604,
    WAS_EVENT_LAUNCHER_FAIL_TIMEOUT: 605,
    WAS_EVENT_LAUNCHER_FAIL_EMP: 606,
    WAS_EVENT_LAUNCHER_FAIL_SMARTHUB: 607,
    WAS_EVENT_LAUNCHER_FAIL_CAPH_APP: 608,
    WAS_EVENT_LAUNCHER_FAIL_NETWORK: 609,
    WAS_EVENT_LAUNCHER_FAIL_OTHERS: 610,
    WAS_EVENT_LAUNCHER_FAIL_MLS: 611,

    WAS_DEFAULT: 1000,

    WAS_APPS_SYNC: 2000, //TODO deprecated.
    WAS_APPS_LIST: 2000,
    WAS_REQUEST_APP_LIST: 2001,


    WAS_SSO_REQUEST_ACCESS_TOKEN: 3000,
    WAS_SSO_STATE_CHANGE: 3001,
    WAS_SSO_SHOW_POPUP: 3002,

    WAS_AD_START: 4000,
    WAS_AD_PLAY: 4001,

    ////////////////////////////////////////////////////// Delete
    WAS_RETURN_FALSE: -1,
    WAS_CALLBACK_ERROR: -2,
    WAS_INVALID_ARG: -3,
    WAS_DISCONNECT: -4,
    //////////////////////////////////////////////////////
    WAS_TRUE: 0,
    WAS_FALSE: -1,
    WAS_FALSE_DBUS_CREATE_ERROR: -2,
    WAS_RESULT_IPC_DISCONNECTED: -1,

    WAS_APPS_PANEL: 0,
    WAS_ONTV: 1,
    WAS_MT: 2,


    APPS_TYPE_WIDGET: 1,
    APPS_TYPE_TIZEN_WEB_APP: 2,
    APPS_TYPE_TIZEN_NATIVE_APP: 4,
    APPS_TYPE_TIZEN_NETFLIX_APP: 8,
    APPS_TYPE_TIZEN_GPLAYER_APP: 16,
    APPS_TYPE_TIZEN_RACH_APP: 32,
    APPS_TYPE_TIZEN_SDK_APP: 64,
    APPS_TYPE_ALL: 65535,
    APPS_INFO_PREMIUM_GAME_FALSE: 1,
    APPS_INFO_PREMIUM_GAME_TRUE: 2,
    APPS_INFO_PREMIUM_GAME_ALL: 65535,
    APPS_INFO_FEATURED_MYAPP: 1,
    APPS_INFO_FEATURED_RECOMMONDED: 2,
    APPS_INFO_FEATURED_ALL: 65535,


    VIEWMODE_MOSTLYPLAYED: 0,
    VIEWMODE_CUSTOM: 1,

    SSO_LOGIN_POPUP_E: 0,
    SSO_LINK_POPUP_E: 1,
    SSO_CREATEACCOUNT_POPUP_E: 2,
    SSO_LOGOUT_POPUP_E: 3,
    SSO_SETTING_POPUP_E: 4,
    SSO_REMOVE_POPUP_E: 5,
    SSO_SERVICE_PART_POPUP_E: 6,
    SSO_CREATEACCOUNT_FACEBOOK_POPUP_E: 7,
    SSO_ITEM_POPUP_E: 8,
    SSO_PRIVACY_POPUP_E: 9,


    WAS_LIST_TYPE_APP_UPDATE_LIST: 0,

    WAS_APPS_SYNC_STATE_INIT: 10,
    WAS_APPS_SYNC_STATE_START: 11,
    WAS_APPS_SYNC_STATE_UNINSTALL_COMPLETED: 12,
    WAS_APPS_SYNC_INSTALL_COMPLETED: 13,
    WAS_APPS_SYNC_COMPLETED: 14,


    m_bOpened: false,
    /**
     * @fn Boolean init()
     * @description WAS EMP 초기화 함수
     * @returns {Boolean}
     */
    init: function (reopenCallback) {
        print(" ------------------------->> init();");
        this.m_bOpened = sefFactory.init("WAS");
        sefFactory.getSEF("WAS").onEventCallback = WASCallback;
        empReopenCallback = reopenCallback;
        print(" ------------------------->> WAS isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    /**
     * @fn Boolean initAsync()
     * @description WAS EMP 초기화 함수
     * @returns {Boolean}
     */
    initAsync: function (OpenCallback, reopenCallback) {
        print(" ------------------------->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("WAS", OpenCallback);
        sefFactory.getSEF("WAS").onEventCallback = WASCallback;
        empReopenCallback = reopenCallback;
        print(" ------------------------->> WAS isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" ------------------------->> destroy();");
        sefFactory.releaseSEF("WAS");
        this.m_bOpened = false;
    },


    /**
     * @author yj14.lee@samsung.com
     * @description App Info를 얻어온다.
     * @param app_id -
     *            String
     * @returns Json Object
     */
    getAppInfo: function (app_id) {
        print(" ------------------------->> GetAppInfo();", String(app_id));
        return retryWASFunction(function () {
            return JSON.parse(sefFactory.getSEF("WAS").execute("GetAppInfo", String(app_id)))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 앱을 설치한다.
     * @param app_id -
     *            String
     * @returns boolean
     */
    installApp: function (app_id, packet_path, install_path) {
        print(" ------------------------->> installApp();", String(app_id));
        var path = String(install_path).replace("$USB_DIR", "/opt/storage/usb/");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("InstallApp", String(app_id), String(packet_path), path)
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App 설치를 취소한다.
     * @param app_id -
     *            String
     * @returns boolean
     */
    cancelInstallApp: function (app_id) {
        print(" ------------------------->> CancelInstallApp();", app_id);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("CancelInstallApp", String(app_id))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App을 삭제한다.
     * @param app_id -
     *            String
     * @returns boolean
     */
    unInstallApp: function (app_id) {
        print(" ------------------------->> UnInstallApp();", app_id);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("UnInstallApp", String(app_id))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App을 업데이트한다.
     * @param app_id -
     *            String
     * @returns boolean
     */
    updateApp: function (app_id) {
        print(" ------------------------->> UpdateApp();", app_id);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("UpdateApp", String(app_id))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description APP을 실행한다.
     * @param app_id -
     *            String
     * @param payload -
     *            String
     * @returns boolean
     */
    launchApp: function (app_id, payload) {
        print(" ------------------------->> LaunchApp();", app_id, payload);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("LaunchApp", String(app_id), String(payload))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App을 종료한다.
     * @param app_id -
     *            String
     * @returns boolean
     */
    terminateApp: function (app_id) {
        print(" ------------------------->> TerminateApp();", app_id);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("TerminateApp", String(app_id))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App Sync 상태를 체크한다.
     * @returns boolean
     */
    checkListSyncStatus: function () {
        print(" ------------------------->> CheckListSyncStatus();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("CheckListSyncStatus")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App을 종료한다.
     * @param type -
     *            enum
     * @param state -
     *            enum
     * @param category -
     *            enum
     * @returns number
     */
    getAppCount: function (app_type, state, category) {
        print(" ------------------------->> GetAppCount();", app_type, state, category);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetAppCount", String(app_type), String(state), String(category))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App List를 얻어온다.
     * @param type -
     *            enum,
     * @param state -
     *            enum,
     * @param category -
     *            enum,
     * @param viewMode -
     *            enum,
     * @param index -
     *            number,
     * @param count -
     *            number
     * @returns number
     */
    getAppList: function (appType, state, category, viewMode, index, count) {
        print(" ------------------------->> GetAppList();", String(appType), String(state), String(category), String(viewMode), String(index), String(count));
        return retryWASFunction(function () {
            return JSON.parse(sefFactory.getSEF("WAS").execute("GetAppList", String(appType), String(state), String(category), String(viewMode), String(index), String(count)))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App Sync 상태를 설정한다.
     * @param enum
     * @returns number
     */
    setListSyncStatus: function (status) {
        print(" ------------------------->> SetListSyncStatus();", String(status));
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("SetListSyncStatus", String(status))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App을 보여준다.
     * @param app_id -
     *            String
     * @returns boolean
     */
    showApp: function (app_id) {
        print(" ------------------------->> ShowApp();", app_id);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("ShowApp", String(app_id))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App Info의 was_app_info_item_e 정보를 얻어온다.
     * @param app_id -
     *            String,
     * @param app_item -
     *            enum
     * @returns number
     */
    getAppInfoIntParameter: function (app_id, app_item) {
        print(" ------------------------->> GetAppInfoIntParameter();", app_id, app_item);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetAppInfoIntParameter", String(app_id), String(app_item))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description App Info의 was_app_info_item_e 정보를 설정한다.
     * @param app_id -
     *            String
     * @param app_item -
     *            enum
     * @param value -
     *            number
     * @returns boolean
     */
    setAppInfoIntParameter: function (app_id, app_item, value) {
        print(" ------------------------->> SetAppInfoIntParameter();", app_id, app_item, value);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("SetAppInfoIntParameter", String(app_id), String(app_item), String(value))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 전달한 was_app_type_s의 App 개수를 얻어온다.
     * @param app_type -
     *            enum
     * @param state -
     *            enum
     * @param category -
     *            number
     * @returns boolean
     */
    requestAppCount: function (app_type, state, category) {
        print(" ------------------------->> RequestAppCount();", app_type, state, category);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("RequestAppCount", String(app_type), String(state), String(category))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Debug Info를 얻어온다.
     * @returns Json Object
     */
    getDebugInfo: function () {
        print(" ------------------------->> GetDebugInfo();");
        return retryWASFunction(function () {
            return JSON.parse(sefFactory.getSEF("WAS").execute("GetDebugInfo"))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description app_id, packet_path, type을 가지고 App을 설치한다.
     * @param app_id -
     *            String
     * @param app_type -
     *            enum
     * @returns boolean
     */
    installAppWithType: function (app_id, app_type) {
        print(" ------------------------->> InstallAppWithType();", String(app_id), String(app_type));
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("InstallAppWithType", String(app_id), String(app_type))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description My Apps에 있는 app_id의 위치를 이동한다.
     * @param app_id -
     *            String
     * @param distance -
     *            String
     * @returns boolean
     */
    moveApp: function (app_id, distance) {
        print(" ------------------------->> MoveApp();", app_id, distance);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("MoveApp", String(app_id), String(distance))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 자동 업데이트 성정 여부를 얻는다.
     * @returns 0 = AUTO_UPDATED, 1 = NOT_AUTO_UPDATED
     */
    checkAutoUpdateState: function () {
        print(" ------------------------->> checkAutoUpdateState();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("CheckAutoUpdateState")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 앱을 hide한다.
     * @param app_id -
     *            String
     * @returns boolean
     */
    hideApp: function (app_id) {
        print(" ------------------------->> HideApp();", app_id);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("HideApp", String(app_id))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 앱의 실행 상태를 얻는다.
     * @param app_id -
     *            String
     * @returns 0 = STOPPED, 1 = RUNNING
     */
    getAppStatus: function (app_id) {
        print(" ------------------------->> getAppStatus();", app_id);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetAppStatus", String(app_id))
        });
    },


    /**
     * @author yj14.lee@samsung.com
     * @description DUID를 얻어온다.
     * @returns String
     */
    getDuid: function () {
        print(" ------------------------->> getDuid();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetDuid")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Token을 얻어온다.
     * @returns String
     */
    getToken: function () {
        print(" ------------------------->> getToken();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetToken")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Infolink Version을 얻어온다.
     * @returns String
     */
    getInfolinkVer: function () {
        print(" ------------------------->> getInfolinkVer();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetInfolinkVer")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Country Code를 얻어온다.
     * @returns String
     */
    getCountryCode: function () {
        print(" ------------------------->> getCountryCode();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetCountryCode")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description AToken을 얻어온다.
     * @returns Json Object
     */
    getAToken: function () {
        print(" ------------------------->> getAToken();");
        return retryWASFunction(function () {
            return JSON.parse(sefFactory.getSEF("WAS").execute("GetAtoken"))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Model Code를 얻어온다.
     * @returns String
     */
    getModelCode: function () {
        print(" ------------------------->> getModelCode();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetModelCode")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description
     * @returns String
     */
    registerAtokenChangedCallback: function () {
        print(" ------------------------->> registerAtokenChangedCallback();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("RegisterAtokenChangedCallback")
        });
    },


    /**
     * @author yj14.lee@samsung.com
     * @description SSO AccessToken을 요청한다.
     * @param app_id -
     *            String
     * @param secret_key -
     *            String
     * @returns boolean
     */
    requestSSOAccessToken: function (app_id, secret_key) {
        print(" ------------------------->> RequestSSOAccessToken();", app_id, secret_key);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("RequestSSOAccessToken", String(app_id), String(secret_key))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description SSO 상태 변화를 전달받을수 있도록 cb을 등록한다.
     * @returns boolean
     */
    subscribeSSOStateChange: function () {
        print(" ------------------------->> SubscribeSSOStateChange();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("SubscribeSSOStateChange")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description SSO login state를 얻어온다.
     * @returns 0 = NOT_LOGIN_SSO = 0, 1 = LOGIN_SSO
     */
    getSSOLoginState: function () {
        print(" ------------------------->> GetSSOLoginState();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOLoginState")
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description SSO login info를 얻어온다.
     * @returns Json Object
     */
    getSSOLoginInfo: function () {
        print(" ------------------------->> GetSSOLoginInfo();");
        return retryWASFunction(function () {
            return JSON.parse(sefFactory.getSEF("WAS").execute("GetSSOLoginInfo"))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description SSO 팝업을 보여주고 cb를 통해 caller에게 팝업 상태를 nodify 한다.
     * @param type -
     *            enum
     * @param payload -
     *            String
     * @returns boolean
     */
    startSSOPopup: function (type, payload) {
        print(" ------------------------->> StartSSOPopup();", type, payload);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("StartSSOPopup", String(type), String(payload))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description SSO에 app account가 link 되어 있는지 체크한다.
     * @param cp_name -
     *            String
     * @returns boolean
     */
    isLinkedApp: function (cp_name) {
        print(" ------------------------->> IsLinkedApp();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("IsLinkedApp", String(cp_name))
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description SSO GUID를 얻어온다.
     * @returns String
     */
    getGuid: function () {
        print(" ------------------------->> GetGuid();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetGuid")
        });
    },


    /**
     * @author yj14.lee@samsung.com
     * @description AD 서버에 광고 이미지를 요청하여 cb를 통해 광고 이미지를 전달 받는다.
     * @param enum
     * @returns boolean
     */
    startAD: function (paneltype) {
        print(" ------------------------->> StartAD();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("StartAD", paneltype)
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description AD 서버에 광고 이미지 요청을 stop한다.
     * @param enum
     * @returns boolean
     */
    stopAD: function (paneltype) {
        print(" ------------------------->> StopAD();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("StopAD", paneltype)
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 광고 재생을 위한 AdHub를 Call한다.
     * @returns boolean
     */
    playAD: function (paneltype, filename) {
        print(" ------------------------->> PlayAD();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("PlayAD", paneltype, filename)
        });
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 광고가 노출 횟수를 기록하기위해 AD 서버에 notify한다.
     * @param filename -
     *            enum
     * @returns boolean
     */
    notifyADServer: function (paneltype, filename) {
        print(" ------------------------->> NotifyADServer();", filename);
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("NotifyADServer", paneltype, filename)
        });
    },


    /**
     * @author yj14.lee@samsung.com
     * @description This is a Sync interface. This function is provided for
     *              all modules to get the information of Memory usage.
     * @returns string
     */
    getMemory: function () {
        print(" ------------------------->> GetMemory();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetMemory")
        });
    },
    /**
     * @author yj14.lee@samsung.com
     * @description
     * @param void
     * @returns string
     */
    coMSSGetInfo: function () {
        print(" ------------------------->> CoMSSGetInfo();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("CoMSSGetInfo")
        });
    },

    appsSync: function () {
        print(" ------------------------->> appsSync();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("AppsSync")
        });
    },
    getSSOAppAccountInfoList: function () {
        print(" ------------------------->> GetSSOAppAccountInfoList();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOAppAccountInfoList")
        });
    },
    getSSOLoginInfoString: function () {
        print(" ------------------------->> GetSSOLoginInfoString();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOLoginInfoString")
        });
    },
    getSSOToken: function () {
        print(" ------------------------->> GetSSOToken();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOToken")
        });
    },
    getSSOAccountInfo: function (cp_name) {
        print(" ------------------------->> GetSSOAccountInfo();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOAccountInfo", cp_name)
        });
    },
    getSSOAccountInfoWithoutLogin: function (cp_name) {
        print(" ------------------------->> GetSSOAccountInfoWithoutLogin();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOAccountInfoWithoutLogin", cp_name)
        });
    },
    stopSSOPopup: function () {
        print(" ------------------------->> StopSSOPopup();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("StopSSOPopup")
        });
    },
    readSSOAccountInfo: function () {
        print(" ------------------------->> ReadSSOAccountInfo();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("ReadSSOAccountInfo")
        });
    },
    getSSOCPInfo: function (cp_name) {
        print(" ------------------------->> GetSSOCPInfo();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOCPInfo", cp_name)
        });
    },
    getSSOUnboundAppList: function () {
        print(" ------------------------->> GetSSOUnboundAppList();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOUnboundAppList")
        });
    },
    setAppRating: function (app_id, ratng) {
        print(" ------------------------->> SetAppRating();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("SetAppRating", String(app_id), String(ratng))
        });
    },
    getAppRating: function (app_id) {
        print(" ------------------------->> GetAppRating();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetAppRating", String(app_id))
        });
    },
    getHistoryAppList: function (count) {
        print(" ------------------------->> GetHistoryAppList();");
        return retryWASFunction(function () {
            return JSON.parse(sefFactory.getSEF("WAS").execute("GetHistoryAppList", String(count)))
        });
    },
    removeAppHistory: function (app_id) {
        print(" ------------------------->> RemoveAppHistory();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("RemoveAppHistory", String(app_id))
        });
    },
    removeAllAppHistory: function () {
        print(" ------------------------->> RemoveAllAppHistory();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("RemoveAllAppHistory")
        });
    },
    getAppMultiList: function (appType, state, category, viewMode, index, count) {
        print(" ------------------------->> GetAppMultiList();", String(appType), String(state), String(category), String(viewMode), String(index), String(count));
        return retryWASFunction(function () {
            return JSON.parse(sefFactory.getSEF("WAS").execute("GetAppMultiList", String(appType), String(state), String(category), String(viewMode), String(index), String(count)))
        });
    },
    requestAppList: function (list_type) {
        print(" ------------------------->> RequestAppList();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("RequestAppList", String(list_type))
        });
    },
    setAppLock: function (appid, p) {
        print(" ------------------------->> SetAppLock();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("SetAppLock", String(appid), String(p))
        });
    },
    getSSOTermStatus: function (term_id) {
        print(" ------------------------->> GetSSOTermStatus();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetSSOTermStatus", term_id)
        });
    },
    showSSOPopup: function (payload) {
        print("------------------------->> ShowSSOPopup();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("ShowSSOPopup", String(payload))
        });
    },

    getAppsSyncState: function () {
        print(" ------------------------->> GetAppsSyncState();");
        return retryWASFunction(function () {
            return sefFactory.getSEF("WAS").execute("GetAppsSyncState")
        });
    },

    addEventListener: function (eventType, cb) {
        print("---------------------------------------->> addEventListener");
        WAScbList[String(eventType)] = cb;
    },

    setAllEventListener: function (cb) {
        WASAllcb = cb;
    }
};

var WAScbList = {};
var WASAllcb;
var D_BUS_ERROR = "-4";
var empReopenCallback;

function WASException(message) {
    this.message = message;
    this.name = "WASException";
}

WASException.prototype.toString = function () {
    var name = this.name || 'unknown';
    var message = this.message || 'no description';
    return '[' + name + '] ' + message;
};

function WASCallback(eventType, param1, param2) {
    print("EVENT:[" + eventType + "].param1[" + param1 + "].param2[" + param2 + "] ");
    if (typeof WAScbList[String(eventType)] == "function")
        WAScbList[String(eventType)](eventType, param1, param2);
    if (typeof WASAllcb == "function")
        WASAllcb(eventType, param1, param2);
}

function retryWASFunction(retryFunction) {
    var result = retryFunction();
    if (result == D_BUS_ERROR) {
        print(" ------------------------->> [[ D_BUS_ERROR ]]");
        retryWASinit();
        result = retryFunction();
        if (result == D_BUS_ERROR) {
            Volt.setTimeout(function () {
                retryWASinit();
            }, 10 * 1000);
        }
    }
    return result;
}

function retryWASinit() {
    exports.WAS.destroy();
    var opened = exports.WAS.init();
    if (typeof empReopenCallback == "function")
        empReopenCallback(opened);
}

exports.onTV = {
    m_bOpened: false,
    m_bOpenedServiceID: false,

    /**
     * @author yj14.lee@samsung.com
     * @fn Boolean init()
     * @description Slive EMP 초기화 함수
     * @returns {Boolean}
     */
    init: function () {
        print(" ------------------------->> init();");
        this.m_bOpened = sefFactory.init("Slive");
        this.m_bOpenedServiceID = sefFactory.init("GetChannel_ServiceId");
        print(" ------------------------->> onTV isOpened  ", this.m_bOpened);
        print(" ------------------------->> onTV_ServiceID isOpened  ", this.m_bOpenedServiceID);
        return this.m_bOpened;
    },
    /**
     * @author sunjung.yoo@samsung.com
     * @fn Boolean initAsync()
     * @description Slive EMP 초기화 함수
     * @returns {Boolean}
     */
    initAsync: function (OpenCallback) {
        print(" ------------------------->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Slive", function () {
            print(" ------------------------->> onTV isOpened  ");
        });
        this.m_bOpenedServiceID = sefFactory.initAsync("GetChannel_ServiceId", OpenCallback);
        print(" ------------------------->> onTV_ServiceID isOpened  ", this.m_bOpenedServiceID);
        return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" ------------------------->> destroy();");
        sefFactory.releaseSEF("Slive");
    },
    /**
     * @author yj14.lee@samsung.com
     * @description OnTV 서비스에 대한 Rating protection rule을 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getCertRule: function (input_param) {
        print(" ------------------------->> GetCertRule();");
        var result = sefFactory.getSEF("Slive").execute("GetCertRule", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },
    /**
     * @author yj14.lee@samsung.com
     * @description 설정된 국가와 언어를 가지고 온다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getRemoteContentEnv: function (input_param) {
        print(" ------------------------->> GetRemoteContentEnv();");
        var result = sefFactory.getSEF("Slive").execute("GetRemoteContentEnv", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },
    /**
     * @author yj14.lee@samsung.com
     * @description 국가와 언어를 설정한다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    setRemoteContentEnv: function (input_param) {
        print(" ------------------------->> SetRemoteContentEnv();");
        var result = sefFactory.getSEF("Slive").execute("SetRemoteContentEnv", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },
    /**
     * @author yj14.lee@samsung.com
     * @description 저장된 MSO 설정을 가지고 온다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getRemoteContentConfig: function (input_param) {
        print(" ------------------------->> GetRemoteContentConfig();");
        var result = sefFactory.getSEF("Slive").execute("GetRemoteContentConfig", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },
    /**
     * @author yj14.lee@samsung.com
     * @description MSO를 설정 한다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    setRemoteContentConfig: function (input_param) {
        print(" ------------------------->> SetRemoteContentConfig();");
        var result = sefFactory.getSEF("Slive").execute("SetRemoteContentConfig", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Activity ID를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getRemoteContentActivityByTVSourceAndTVMode: function (input_param) {
        print(" ------------------------->> GetRemoteContentActivityByTVSourceAndTVMode();");
        var result = sefFactory.getSEF("Slive").execute("GetRemoteContentActivityByTVSourceAndTVMode", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 추천 정보를 얻는 방법을 설정한다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    setRecommendTypeOption: function (in_recommend_type) {
        print(" ------------------------->> SetRecommendTypeOption();");
        var result = sefFactory.getSEF("Slive").execute("SetRecommendTypeOption", JSON.stringify(in_recommend_type));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 개인화 데이터를 받아 온다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    activateSmartPersonal: function (input_param) {
        print(" ------------------------->> ActivateSmartPersonal();");
        var result = sefFactory.getSEF("Slive").execute("ActivateSmartPersonal", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description VOD Provider List를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getVODProviders: function (activityID) {
        print(" ------------------------->> GetVODProviders();");
        var result = sefFactory.getSEF("Slive").execute("GetVODProviders", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 장르 리스트를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getGenreList: function (activityID) {
        print(" ------------------------->> GetGenreList();");
        var result = sefFactory.getSEF("Slive").execute("GetGenreList", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description RecGroup을 가져온다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getRecGroupMap: function (activityID) {
        print(" ------------------------->> GetRecGroupMap();");
        var result = sefFactory.getSEF("Slive").execute("GetRecGroupMap", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Rep Genre List를 가져온다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getRepGenreList: function (activityID) {
        print(" ------------------------->> GetRepGenreList();");
        var result = sefFactory.getSEF("Slive").execute("GetRepGenreList", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description OnNow데이터를 받아온다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getRecommendationOnNow: function (input_param) {
        print(" ------------------------->> GetRecommendationOnNow();");
        var result = sefFactory.getSEF("Slive").execute("GetRecommendationOnNow", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Upcomming데이터를 받아온다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getRecommendationUpcomming: function (input_param) {
        print(" ------------------------->> GetRecommendationUpcomming();");
        var result = sefFactory.getSEF("Slive").execute("GetRecommendationUpcomming", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 48시간 이후 EPG 데이터를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    activateProgramGuide: function (activityID) {
        print(" ------------------------->> ActivateProgramGuide();");
        var result = sefFactory.getSEF("Slive").execute("ActivateProgramGuide", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 48시간 이후 EPG를 Program map에 Load한다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    loadAdditionalProgramMapFromServer: function (input_param) {
        print(" ------------------------->> LoadAdditionalProgramMapFromServer();");
        var result = sefFactory.getSEF("Slive").execute("LoadAdditionalProgramMapFromServer", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description EPG를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getProgramMap: function (input_param) {
        print(" ------------------------->> GetProgramMap();");
        var result = sefFactory.getSEF("Slive").execute("GetProgramMap", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 12시간 분량만 남기고 메모리에서 제거 한다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    deactivateProgramGuide: function (activityID) {
        print(" ------------------------->> DeactivateProgramGuide();");
        var result = sefFactory.getSEF("Slive").execute("DeactivateProgramGuide", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description ChannelList를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getFullChannelList: function (activityID) {
        print(" ------------------------->> GetFullChannelList();");
        var result = sefFactory.getSEF("Slive").execute("GetFullChannelList", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description ChannelList중 Tune이 가능한 Channel List를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getTunableChannelList: function (activityID) {
        print(" ------------------------->> GetTunableChannelList();");
        var result = sefFactory.getSEF("Slive").execute("GetTunableChannelList", JSON.stringify(activityID));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description TCChannel객체에 대한 FCRemoteChannel 객체를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getFCRemoteChannelByTCServiceID: function (input_param) {
        print(" ------------------------->> GetFCRemoteChannelByTCChannel();");
        var result = sefFactory.getSEF("Slive").execute("GetFCRemoteChannelByTCServiceId", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },
    /**
     * @author yj14.lee@samsung.com
     * @description FCRemoteChannel 객체에 대한 TCChannel 객체를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getTCServiceIdByFCRemoteChannel: function (input_param) {
        print(" ------------------------->> GetTCServiceIdByFCRemoteChannel();");
        var result = sefFactory.getSEF("Slive").execute("GetTCServiceIdByFCRemoteChannel", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Program source id에 대한 TCChannel객체를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getTCServiceIdByProgramSourceID: function (input_param) {
        print(" ------------------------->> GetTCServiceIdByProgramSourceID();");
        var result = sefFactory.getSEF("Slive").execute("GetTCServiceIdByProgramSourceID", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Program source id에 대한 FCRemoteChannel객체를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getFCRemoteChannelByProgramSourceID: function (input_param) {
        print(" ------------------------->> GetFCRemoteChannelByProgramSourceID();");
        var result = sefFactory.getSEF("Slive").execute("GetFCRemoteChannelByProgramSourceID", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Program source id에 대한 FCRemoteProgram객체를 얻는다.
     * @param Json
     *            Object
     * @returns Json Object
     */
    getFCRemoteProgramByProgramSourceID: function (input_param) {
        print(" ------------------------->> GetFCRemoteProgramByProgramSourceID();");
        var result = sefFactory.getSEF("Slive").execute("GetFCRemoteProgramByProgramSourceID", JSON.stringify(input_param));
        return JSON.parse(result);
        return result;
    },

    getTvMode: function () {
        print(" ------------------------->> GetTvMode();");
        return sefFactory.getSEF("Slive").execute("GetTvMode");
        return;
    },
    setTvMode: function (nTvMode) {
        print(" ------------------------->> SetTvMode();");
        return sefFactory.getSEF("Slive").execute("SetTvMode", nTvMode);
        return;
    },
    getSource: function () {
        print(" ------------------------->> GetSource();");
        return sefFactory.getSEF("Slive").execute("GetSource");
        return;
    },
    setSource: function (nSource, nSeek) {
        print(" ------------------------->> SetSource();");
        return sefFactory.getSEF("Slive").execute("SetSource", nSource, nSeek);
        return;
    },
    getCurrentChannel_Major: function () {
        print(" ------------------------->> GetCurrentChannel_Major();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Major");
        return;
    },
    getCurrentChannel_Minor: function () {
        print(" ------------------------->> GetCurrentChannel_Minor();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Minor");
        return;
    },
    getCurrentChannel_Name: function () {
        print(" ------------------------->> GetCurrentChannel_Name();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Name");
        return;
    },
    getCurrentChannel_OriginNetID: function () {
        print(" ------------------------->> GetCurrentChannel_OriginNetID();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_OriginNetID");
        return;
    },
    getCurrentChannel_ProgramNumber: function () {
        print(" ------------------------->> GetCurrentChannel_ProgramNumber();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_ProgramNumber");
        return;
    },
    getCurrentChannel_PTC: function () {
        print(" ------------------------->> GetCurrentChannel_PTC();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_PTC");
        return;
    },
    getCurrentChannel_ServiceName: function () {
        print(" ------------------------->> GetCurrentChannel_ServiceName();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_ServiceName");
        return;
    },
    getCurrentChannel_TransportStreamID: function () {
        print(" ------------------------->> GetCurrentChannel_TransportStreamID();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_TransportStreamID");
        return;
    },
    getCurrentChannel_Type: function () {
        print(" ------------------------->> GetCurrentChannel_Type();");
        return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Type");
        return;
    },
    getChannel_Major: function () {
        print(" ------------------------->> GetChannel_Major();");
        return sefFactory.getSEF("Slive").execute("GetChannel_Major");
        return;
    },
    getChannel_Minor: function () {
        print(" ------------------------->> GetChannel_Minor();");
        return sefFactory.getSEF("Slive").execute("GetChannel_Minor");
        return;
    },
    getChannel_Name: function () {
        print(" ------------------------->> GetChannel_Name();");
        return sefFactory.getSEF("Slive").execute("GetChannel_Name");
        return;
    },
    getChannel_OriginNetID: function () {
        print(" ------------------------->> GetChannel_OriginNetID();");
        return sefFactory.getSEF("Slive").execute("GetChannel_OriginNetID");
        return;
    },
    getChannel_ProgramNumber: function () {
        print(" ------------------------->> GetChannel_ProgramNumber();");
        return sefFactory.getSEF("Slive").execute("GetChannel_ProgramNumber");
        return;
    },
    getChannel_PTC: function () {
        print(" ------------------------->> GetChannel_PTC();");
        return sefFactory.getSEF("Slive").execute("GetChannel_PTC");
        return;
    },
    getChannel_ServiceName: function () {
        print(" ------------------------->> GetChannel_ServiceName();");
        return sefFactory.getSEF("Slive").execute("GetChannel_ServiceName");
        return;
    },
    getChannel_TransportStreamID: function () {
        print(" ------------------------->> GetChannel_TransportStreamID();");
        return sefFactory.getSEF("Slive").execute("GetChannel_TransportStreamID");
        return;
    },
    getChannel_Type: function () {
        print(" ------------------------->> GetChannel_Type();");
        return sefFactory.getSEF("Slive").execute("GetChannel_Type");
        return;
    },
    setChannel: function (nMajor, nMinor) {
        print(" ------------------------->> SetChannel();");
        return sefFactory.getSEF("Slive").execute("SetChannel", nMajor, nMinor);
        return;
    },
    setChannelNumberInfo: function (major, minor) {
        print(" ------------------------->> SetChannelNumberInfo();");
        return sefFactory.getSEF("Slive").execute("SetChannelNumberInfo", major, minor);
        return;
    },
    getChannelNumberInfo: function () {
        print(" ------------------------->> GetChannelNumberInfo();");
        return sefFactory.getSEF("Slive").execute("GetChannelNumberInfo");
        return;
    },
    getProgram: function (param) {
        print(" ------------------------->> GetProgram();");
        var result = sefFactory.getSEF("Slive").execute("GetProgram", JSON.stringify(param));
        return JSON.parse(result);
        return result;
    },
    getProgramList: function (param) {
        print(" ------------------------->> GetProgramList();");
        var result = sefFactory.getSEF("Slive").execute("GetProgramList", JSON.stringify(param));
        return JSON.parse(result);
        return result;
    },
    getPresentProgram: function (param) {
        print(" ------------------------->> GetPresentProgram();");
        var result = sefFactory.getSEF("Slive").execute("GetPresentProgram", JSON.stringify(param));
        return JSON.parse(result);
        return result;
    },
    getChannelServiceId: function (nMajor, nMinor, nChannelType) {
        print(" ------------------------->> getChannelServiceId();");
        var result = sefFactory.getSEF("GetChannel_ServiceId").execute("getChannelServiceId", nMajor, nMinor, nChannelType);
        return result;
    },
    flagMBRMode: function () {
        print(" ------------------------->> FlagMBRMode();");
        return sefFactory.getSEF("Slive").execute("FlagMBRMode");
        return;
    }
};

/**
 * @namespace network
 */
exports.network = {
    /** ** network_type */
    NETWORK_TYPE_WIRELESS: 0,
    /** ** network_type */
    NETWORK_TYPE_WIRED: 1,
    m_SEFNetwork: null,
    m_bOpened: false,
    /**
     * @author yj14.lee@samsung.com
     * @fn Boolean init()
     * @description Slive EMP 초기화 함수
     * @returns {Boolean}
     */
    init: function () {
        print(" ------------------------->> init();");
        this.m_bOpened = sefFactory.init("Network");
        this.m_SEFNetwork = sefFactory.getSEF("Network");
        print(" ------------------------->> network isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    /**
     * @author sunjung.yoo@samsung.com
     * @fn Boolean initAsync()
     * @description Slive EMP 초기화 함수
     * @returns {Boolean}
     */
    initAsync: function (OpenCallback) {
        print(" ------------------------->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Network", OpenCallback);
        this.m_SEFNetwork = sefFactory.getSEF("Network");
        print(" ------------------------->> network isOpened  ", this.m_bOpened);
        return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" ------------------------->> destroy();");
        sefFactory.releaseSEF("Network");
    },

    /**
     * @author yj14.lee@samsung.com
     * @description available한 네트워크를 얻는다.
     * @param successCallback -
     *            function, errorCalback - function
     */
    getAvailableNetworks: function (successCallback, errorCallback) {
        print(" ------------------------->> getAvailableNetworks();");
        var networkListLength = [this.NETWORK_TYPE_WIRELESS, this.NETWORK_TYPE_WIRED];
        var networkList = [];
        for (var i = 0; i < networkListLength.length; i++) {
            networkList[i] = new _Network(i, this);
        }
        if (!networkList[0].isActive() && !networkList[1].isActive()) {
            if (typeof errorCallback == 'function') {
                errorCallback(networkList);
            }
        } else {
            successCallback(networkList);
        }
    },

    /**
     * @author yj14.lee@samsung.com
     * @description DNS를 얻는다.
     * @param enum
     * @return String
     */
    getDNS: function (interfaceType) {
        print(" ------------------------->> getDNS(", interfaceType, ")");
        return sefFactory.getSEF("Network").execute("GetDNS", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description DNS Mode를 얻는다.
     * @param enum
     * @return String
     */
    getDNSMode: function (interfaceType) {
        print(" ------------------------->> getDNSMode();");
        return sefFactory.getSEF("Network").execute("GetDNSMode", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 게이트웨이를 얻는다.
     * @param enum
     * @return String
     */
    getGateway: function (interfaceType) {
        print(" ------------------------->> getGateway();");
        return sefFactory.getSEF("Network").execute("GetGateway", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 서브넷마스크를 얻는다.
     * @param enum
     * @return String
     */
    getNetMask: function (interfaceType) {
        print(" ------------------------->> getNetMask();");
        return sefFactory.getSEF("Network").execute("GetNetMask", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description IP를 얻는다.
     * @param enum
     * @return String
     */
    getIP: function (interfaceType) {
        print(" ------------------------->> getIP();");
        return sefFactory.getSEF("Network").execute("GetIP", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description IP Mode를 얻는다.
     * @param enum
     * @return String
     */
    getIPMode: function (interfaceType) {
        print(" ------------------------->> getIPMode();");
        return sefFactory.getSEF("Network").execute("GetIPMode", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description MAC을 얻는다.
     * @param enum
     * @return String
     */
    getMAC: function (interfaceType) {
        print(" ------------------------->> getMAC();");
        return sefFactory.getSEF("Network").execute("GetMAC", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description DNS를 체크한다.
     * @param enum
     * @return String
     */
    checkDNS: function (interfaceType) {
        print(" ------------------------->> checkDNS();", interfaceType);
        var result = 0;
        try {
            result = sefFactory.getSEF("Network").execute("CheckDNS", String(interfaceType));
        } catch (e) {
            print(" ------------------------->> checkDNS() emp error ", interfaceType);
        }
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 게이트웨이를 체크한다.
     * @param enum
     * @return String
     */
    checkGateway: function (interfaceType) {
        print(" ------------------------->> checkGateway();", interfaceType);
        var result = 0;
        try {
            result = sefFactory.getSEF("Network").execute("CheckGateway", String(interfaceType));
        } catch (e) {
            print(" ------------------------->> checkDNS() emp error ", interfaceType);
        }
        return result;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description HTTP를 체크한다.
     * @param enum
     * @return String
     */
    checkHTTP: function (interfaceType) {
        print(" ------------------------->> checkHTTP();", interfaceType);
        return sefFactory.getSEF("Network").execute("CheckHTTP", String(interfaceType));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 물리적 연결을 체크한다.
     * @param enum
     * @return String
     */
    checkPhysicalConnection: function (interfaceType) {
        print(" ------------------------->> checkPhysicalConnection();", interfaceType);
        return sefFactory.getSEF("Network").execute("CheckPhysicalConnection", String(interfaceType));
    }
};

function NetworkCallbackInfo() {
    this.NetworkConnectionStatusChnageCallback = null;
    this._networkID = null;
}
var networkCallbackInfos = [new NetworkCallbackInfo(), new NetworkCallbackInfo()];

var NETWORK_TYPE_WIRELESS = 0;
var NETWORK_TYPE_WIRED = 1;
var NETWORK_DISCONNECTED = 0;
var NETWORK_CONNECTED = 1;

function _onNetworkPluginEvent(event, data1, data2) {

    print("callback data ------------------------->> ", event, data1, data2);
    var status = null;
    switch (event) {
    case 0:
        if (data1 == NETWORK_DISCONNECTED) {
            status = new ConnectonStatus(ConnectonStatus.DISCONNECT, 'disconnected');
            networkCallbackInfos[NETWORK_TYPE_WIRED].NetworkConnectionStatusChnageCallback.ondisconnect(status);
        } else if (data1 == NETWORK_CONNECTED) {
            status = new ConnectonStatus(ConnectonStatus.CONNECT, 'connected');
            networkCallbackInfos[NETWORK_TYPE_WIRED].NetworkConnectionStatusChnageCallback.onconnect(status);
        }
        break;
    case 1:
        if (data1 == NETWORK_DISCONNECTED) {
            status = new ConnectonStatus(ConnectonStatus.DISCONNECT, 'disconnected');
            networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.ondisconnect(status);
        } else if (data1 == NETWORK_CONNECTED) {
            status = new ConnectonStatus(ConnectonStatus.CONNECT, 'connected');
            networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.onconnect(status);
        }
        break;
    case 2:
        if (data1 == NETWORK_DISCONNECTED) {
            status = new ConnectonStatus(ConnectonStatus.DISCONNECT, 'disconnected');
            networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.ondisconnect(status);
        } else if (data1 == NETWORK_CONNECTED) {
            status = new ConnectonStatus(ConnectonStatus.CONNECT, 'connected');
            networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.onconnect(status);
        }
        break;

    default:
        break;
    }
}

function ConnectonStatus(code, message) {
    this.code = function () {
        return code;
    };
    this.message = function () {
        return message;
    };
}

ConnectonStatus.prototype.toString = function () {
    return '(' + this.code + ') ' + this.message;
};

ConnectonStatus.DISCONNECT = 0;
ConnectonStatus.CONNECT = 1;

function _Network(pInterfaceType, network) {
    // 0 - wireless, 1 - wired
    this.interfaceType = pInterfaceType;
    this.dns = function () {
        return network.getDNS(this.interfaceType);
    };
    // this.secondaryDns = function () {
    // return network.getSecondaryDNS(this.interfaceType);
    // };
    this.dnsMode = function () {
        var nDnsMode = network.getDNSMode(this.interfaceType);
        var sDnsMode = this.toString(nDnsMode);
        return sDnsMode;
    };
    this.gateway = function () {
        return network.getGateway(this.interfaceType);
    };
    this.subnetMask = function () {
        return network.getNetMask(this.interfaceType);
    };
    this.ip = function () {
        return network.getIP(this.interfaceType);
    };
    this.ipMode = function () {
        var nIpMode = network.getIPMode(this.interfaceType);
        var sIpMode = this.toString(nIpMode);
        return sIpMode;
    };
    this.mac = function () {
        return network.getMAC(this.interfaceType);
    };

    this.isActive = function () {
        var checkTarget = {
            "checkDNS": network.checkDNS(String(this.interfaceType)),
            "checkGateway": network.checkGateway(String(this.interfaceType)),
            "checkHttp": network.checkHTTP(String(this.interfaceType)),
            "checkPhysicalConnection": network.checkPhysicalConnection(String(this.interfaceType))
        };

        if (checkTarget["checkDNS"] == 1 && checkTarget["checkGateway"] == 1 && checkTarget["checkHttp"] == 1 && checkTarget["checkPhysicalConnection"] == 1) {
            return true;
        } else {
            var errorMessage = " >>>>>>>>>>>>>>>>>>>>>>>>> " + (this.interfaceType ? "WIRED : " : "WIRELESS : ") + " Not available List [";
            var index = 0;
            for (key in checkTarget) {
                index++;
                if (checkTarget[key] != 1) {
                    errorMessage += key;
                    if (index > 1 && index < 4) errorMessage += ", ";
                }
            }
            errorMessage += "]";
            print(errorMessage);
            return false;
        }
    };

    this.setWatchListener = function (successCallback, errorCallback) {
        print(" ------------------------->> setWatchListener();");

        networkPlugin = network.m_SEFNetwork;
        networkPlugin.onEventCallback = _onNetworkPluginEvent;


        networkCallbackInfos[this.interfaceType].NetworkConnectionStatusChnageCallback = successCallback;
        networkCallbackInfos[this.interfaceType]._networkID = this.interfaceType;

    };

    this.unsetWatchListener = function () {

        networkCallbackInfos[this.interfaceType].NetworkConnectionStatusChnageCallback = null;
        networkCallbackInfos[this.interfaceType]._networkID = null;
    };

    this.toString = function (num) {
        // 0 if Auto, 1 if Manual, -1 if error
        var str = null;
        if (num === 0) {
            str = 'Auto';
        } else if (num == 1) {
            str = 'Manual';
        } else {
            str = 'NotSupported';
        }
        return str;
    };
};

exports.ASF = {
    ASF_EMP_DEVICE_ADDED: 3,
    ASF_EMP_DEVICE_REMOVED: 4,
    m_SEFASF: null,
    m_bOpened: false,
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("ASF");
        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("ASF", OpenCallback);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("ASF");
        this.m_bOpened = false;
    },
    setOnEvent: function (OnEvent) {
        this.m_SEFASF.OnEvent = OnEvent;
    },
    // connectServiceconnector
    connectServiceconnector: function () {
        print(" ------------------------->> connectServiceconnector();");
        return sefFactory.getSEF("ASF").execute("asf_serviceconnector_connect");
    },
    // disconnectServiceconnector
    disconnectServiceconnector: function () {
        print(" ------------------------->> disconnectServiceconnector();");
        return sefFactory.getSEF("ASF").execute("asf_serviceconnector_disconnect");
    },
    // setDevicefinderEventCallback
    setDevicefinderEventCallback: function (deviceType) {
        print(" ------------------------->> setDevicefinderEventCallback()");
        return sefFactory.getSEF("ASF").execute("asf_devicefinder_set_event_callback", deviceType);
    },
    // refreshDeviceFinder
    refreshDeviceFinder: function () {
        print(" ------------------------->> refreshDeviceFinder()");
        return sefFactory.getSEF("ASF").execute("asf_devicefinder_refresh");
    },
    // getDevicefinderDeviceList
    getDevicefinderDeviceList: function (deviceType) {
        print(" ------------------------->> getDevicefinderDeviceList()");
        return sefFactory.getSEF("ASF").execute("asf_devicefinder_get_device_list", deviceType);
    }
};

/**
 * @namespace remider
 */
exports.reminder = {
    REMINDER_REPEAT_ONCE: 0,
    REMINDER_REPEAT_EVERYDAY: 1,
    REMINDER_REPEAT_MON_FRI: 2,
    REMINDER_REPEAT_SAT_SUN: 3,
    REMINDER_REPEAT_MANUAL: 4,
    REMINDER_REPEAT_MAX: 5,

    RESERVE_WATCH: 0,
    RESERVE_RECORD: 1,
    RESERVE_EVENT_RECORD: 2,
    RESERVE_ACT: 3,
    RESERVE_FAIL: 4,
    RESERVE_NOTHING: 5,
    RESERVE_INSTANT_ACT: 6,
    RESERVE_RECORD_READY: 7,
    RESERVE_SERIES_BOOKING: 8,
    RESERVE_JAPAN_SERIES_RECORD: 9,
    RESERVE_PROGRAM_CRID: 10,
    RESERVE_RECORDLIST_GROUP: 11,
    RESERVE_COMPELETE: 12,

    RESERVE_EPG: 0,
    RESERVE_MANUA: 1,

    m_SEFReminder: null,
    m_bOpened: false,
    init: function () {
        print(" ------------------------->> init();");
        this.m_bOpened = sefFactory.init("Reminder");
        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" ------------------------->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Reminder", OpenCallback);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" ------------------------->> destroy();");
        sefFactory.releaseSEF("Reminder");
        this.m_bOpened = false;
    },

    /**
     * @author yj14.lee@samsung.com
     * @description Reminder Item의 Data를 설정한다.
     * @param channelType,
     *            major, minor, ptc, programNumber
     * @return Json Object
     */
    setRemindInfo: function (input_param) {
        print(" ------------------------->> reminder_info_set();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_info_set", JSON.stringify(input_param)));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 중복 리스트 리턴하면 팝업으로 띄운다.
     * @param Json
     *            Object
     * @return Json Object
     */
    getOverlappingRemindItems: function (input_param) {
        print(" ------------------------->> “reminder_get_overlapping_remind_item();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_overlapping_remind_items", JSON.stringify(input_param)));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 예약목록의 MaxCount를 얻는다.
     * @return Number
     */
    getMaxItemCnt: function () {
        print(" ------------------------->> GetMaxItemCnt();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_max_item_cnt"));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 현재 예약되어 있는 리스트를 얻는다.
     * @return Number
     */
    getReminderListSize: function () {
        print(" ------------------------->> GetReminderListSize();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_reminder_list_size"));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 아이템을 삭제한다.
     * @param String
     * @return boolean
     */
    addRemindItem: function (input_param) {
        print(" ------------------------->> AddRemindItem();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_add_remind_item", JSON.stringify(input_param)));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 아이템을 삭제한다.
     * @param String
     * @return boolean
     */
    deleteRemindItemByUid: function (input_param) {
        print(" ------------------------->> DeleteRemindItemByUid();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_delete_remind_item_by_uid", JSON.stringify(input_param)));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 아이템을 삭제한다.
     * @param String
     * @return Json Object
     */
    getRemindInfoByUid: function (input_param) {
        print(" ------------------------->> getRemindInfoByUid();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_remind_item_by_uid", JSON.stringify(input_param)));
    },

    /**
     * @author yj14.lee@samsung.com
     * @description 아이템을 삭제한다.
     * @param String
     * @return Json Object
     */
    getRemindItemByType: function (input_param) {
        print(" ------------------------->> GetRemindItemByType();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_remind_item_by_type", '{"str_reserveType":"' + input_param + '"}'));
    },
};

/**
 * @namespace PVR
 */
exports.PVR = {
    m_PVR: null,
    m_bOpened: false,
    /**
     * @author sumin_.park@samsung.com
     * @fn init
     * @description The first step to use PVR-related functions.
     * @param
     * @returns bool
     */
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("PVR");
        print(" --->> Opened();", this.m_bOpened);
        return this.m_bOpened;
    },
    /**
     * @author sunjung.yoo@samsung.com
     * @fn initAsync
     * @description The first step to use PVR-related functions.
     * @param
     * @returns bool
     */
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("PVR", OpenCallback);
        print(" --->> Opened();", this.m_bOpened);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("PVR");
        this.m_bOpened = false;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn recordStart
     * @description serviceId,uri,recordType and channelType are needed to start
     *              record.After record started,you will get handle to operate
     *              this record. And you will receive event PVR_RECORD_STATR
     *              which is the truly result.
     * @param Json
     * @returns Json
     */
    recordStart: function (param_input) {
        print(" --->> recordStart();");
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("PVR").execute("RecordStart", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn recordStop
     * @description You can use "handle" to stop record,"duration" is used to
     *              create thumbnail. And you will receive event PVR_RECORD_STOP
     *              which is the truly result.
     * @param Json
     * @returns Json
     */
    recordStop: function (param_input) {
        print(" --->> recordStop();");
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("PVR").execute("RecordStop", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn isRecordingAvailable
     * @description str_result will return true or false.
     * @param
     * @returns bool
     */
    isRecordingAvailable: function () {
        print(" --->> isRecordingAvailable();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("PVR").execute("IsRecordingAvailable"));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn isRecordingDeviceAttached
     * @description str_result will return true or false.
     * @param
     * @returns bool
     */
    isRecordingDeviceAttached: function () {
        print(" --->> isRecordingDeviceAttached();");
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("PVR").execute("IsRecordingDeviceAttached"));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn sendThumbnailRequest
     * @description uri is the path of file which need to get thumbnail.
     * @param Json
     * @returns Json
     */
    sendThumbnailRequest: function (param_input) {
        print(" --->> sendThumbnailRequest();");
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("PVR").execute("SendThumbnailRequest", JSON.stringify(param_input)));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn launchDeviceManager
     * @description calledApp is the name of the user app name like "org.tizen.XXX"
     * @param Json
     * @returns Json
     */
    launchDeviceManager: function (param_input) {
        print(" --->> launchDeviceManager();");
        try {
            IsJson(param_input);
        } catch (e) {
            return 'Failed to handle the Execute call.';
        }
        if (this.m_bOpened == false) return 'Failed to handle the Execute call.';
        return JSON.parse(sefFactory.getSEF("PVR").execute("LaunchDeviceManager", JSON.stringify(param_input)));
    }
};

var ContentsMgrState = {
    E_CM_EVENT_DEFAULT: 0,
    E_CM_EVENT_USB_CONNECTED: "USB_CONNECTED",
    E_CM_EVENT_USB_DISCONNECTED: "USB_DISCONNECTED",
    E_CM_EVENT_QUERY_COMPLETED: 3,
    E_CM_EVENT_FETCH_COMPLETED: 4,
    E_CM_EVENT_CONTENTS_REGISTER_COMPLETED: 5,
    E_CM_EVENT_CONTENTS_UNREGISTER_COMPLETED: 6,

    E_CM_EVENT_SYNC_COMPLETED: 7,
    E_CM_EVENT_SYNC_FAILED: 8,

    E_CM_EVENT_DB_UPDATED: 9,
    usbconnect: null,
    usbdisconnect: null
};

function _onContentMgrPluginEvent(category, event, data1, data2) {
    print(" --->> _onContentMgrPluginEvent", category, event, data1, data2);
    try {
        data1 = JSON.parse(data1);
    } catch (e) {}
    switch (event) {
    case ContentsMgrState.E_CM_EVENT_USB_CONNECTED:
        if (typeof ContentsMgrState.usbconnect == "function") {
            ContentsMgrState.usbconnect(data1, data2);
        }
        break;

    case ContentsMgrState.E_CM_EVENT_USB_DISCONNECTED:
        if (typeof ContentsMgrState.usbdisconnect == "function") {
            ContentsMgrState.usbdisconnect(data1, data2);
        }
        break;
    }
};
/**
 * @author sunjung.yoo@samsung.com
 * @fn retryContentsMgrOpen
 * @description ContentsMgr EMP open resutl check
 * @param
 * @returns
 */

function retryContentsMgrOpen(openResult) {
    var result = openResult;
    if (result == false) {
        print(" ------------------------->> [[ ContentsMgrOpen fail!! ]]");
        openResult = retryContentsMgrinit();
    } else {
        print("------------------------->> [[ ContentsMgrOpen success!! ]]");
    }
    print(" --->>ContentsMgr Opened();", openResult);
    return openResult;
}

function retryContentsMgrinit() {
    print("------------------->> [[retryContentsMgrinit]]");
    var result = exports.ContentsMgr.init();
    retryContentsMgrOpen(result);
}

/**
 * @namespace ContentsMgr
 */
exports.ContentsMgr = {

    m_ContentsMgr: null,
    m_bOpened: false,

    /**
     * @author sumin_.park@samsung.com
     * @fn init
     * @description
     * @param
     * @returns
     */
    init: function (_usbconnect, _usbdisconnect) {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("ContentsMgr");
        var retryResult = retryContentsMgrOpen(this.m_bOpened);
        //print(" --->> Opened();", this.m_bOpened);
        ContentsMgrState.usbconnect = _usbconnect;
        ContentsMgrState.usbdisconnect = _usbdisconnect;
        sefFactory.getSEF("ContentsMgr").onEventCallback = _onContentMgrPluginEvent;
        return retryResult;
    },
    /**
     * @author sunjung.yoo@samsung.com
     * @fn initAsync
     * @description
     * @param
     * @returns
     */
    initAsync: function (OpenCallback, _usbconnect, _usbdisconnect) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("ContentsMgr", OpenCallback);
        //retryContentsMgrOpen(this.m_bOpened);
        print(" --->> Opened();", this.m_bOpened);
        ContentsMgrState.usbconnect = _usbconnect;
        ContentsMgrState.usbdisconnect = _usbdisconnect;
        sefFactory.getSEF("ContentsMgr").onEventCallback = _onContentMgrPluginEvent;
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("ContentsMgr");
        this.m_bOpened = false;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn connect
     * @description
     * @param
     * @returns
     */
    connect: function () {
        print(" --->> connect();");
        return sefFactory.getSEF("ContentsMgr").execute("Connect");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn disconnect
     * @description
     * @param
     * @returns
     */
    disconnect: function () {
        print(" --->> disconnect();");
        return sefFactory.getSEF("ContentsMgr").execute("Disconnect");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getStorages
     * @description
     * @param
     * @returns
     */
    getStorages: function () {
        print(" --->> getStorages();");
        return JSON.parse(sefFactory.getSEF("ContentsMgr").execute("GetStorages"));
    },

};

/**
 * @namespace AppCommon
 */
exports.AppCommon = {
    m_AppCommon: null,
    m_bOpened: false,
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("AppCommon");
        print(" --->> Opened();", this.m_bOpened);
        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("AppCommon", OpenCallback);
        print(" --->> Opened();", this.m_bOpened);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("AppCommon");
        this.m_bOpened = false;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn registerKey
     * @description
     * @param
     * @returns
     */
    registerKey: function (key) {
        if (this.m_AppCommon) {
            print(" --->> TVMW Not Init;");
            // return;
        }
        print(" --->> registerKey();", String(key));
        return sefFactory.getSEF("AppCommon").execute("RegisterKey", String(key));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn unRegisterKey
     * @description
     * @param
     * @returns
     */
    unRegisterKey: function (key) {
        if (this.m_AppCommon) {
            print(" --->> TVMW Not Init;");
            // return;
        }
        print(" --->> unRegisterKey();", String(key));
        return sefFactory.getSEF("AppCommon").execute("UnregisterKey", String(key));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn registerAllKey
     * @description
     * @param
     * @returns
     */
    registerAllKey: function () {
        if (this.m_AppCommon) {
            print(" --->> TVMW Not Init;");
            // return;
        }
        print(" --->>registerAllKey();)");
        return sefFactory.getSEF("AppCommon").execute("RegisterAllKey");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn unregisterAllKey
     * @description
     * @param
     * @returns
     */
    unregisterAllKey: function () {
        if (this.m_AppCommon) {
            print(" --->> TVMW Not Init;");
            // return;
        }
        print(" --->>unregisterAllKeyy();)");
        return sefFactory.getSEF("AppCommon").execute("UnregisterAllKey");
    }
};
/**
 * @namespace TVMW
 */
exports.TVMW = {
    m_AppCommon: null,
    m_bOpened: false,
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("TVMW");
        print(" --->> Opened();", this.m_bOpened);
        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("TVMW", OpenCallback);
        print(" --->> Opened();", this.m_bOpened);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("TVMW");
        this.m_bOpened = false;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getProfile
     * @description
     * @param
     * @returns
     */
    getProfile: function () {
        print(" --->> getProfile();");
        return sefFactory.getSEF("TVMW").execute("GetProfile");
    }
};
/**
 * @namespace device
 */
exports.device = {
    PL_TVMW_PRFID_TICKER_ID: 0,
    PL_TVMW_PRFID_CHILDLOCK_PIN: 1,
    PL_TVMW_PRFID_HUB_TVID: 2,
    PL_TVMW_PRFID_TICKER_AUTOBOOT: 3,
    PL_TVMW_PRFID_TICKER_DURATION: 4,
    PL_TVMW_PRFID_WIDGET_DPTIME: 5,
    PL_TVMW_PRFID_CONTRACT: 6,
    PL_TVMW_PRFID_TICKER_SAFE: 7,
    PL_TVMW_PRFID_RESET: 8,
    PL_TVMW_PRFID_PASSWD_RESET: 9,
    PL_TVMW_PRFID_GEOIP_STATUS: 10,
    PL_TVMW_PRFID_COUNTRY_CODE: 11,
    PL_TVMW_PRFID_WLAN_DEFAULT_NETWORK: 12,
    PL_TVMW_PRFID_AUTO_PROTECTION_TIME: 13,
    PL_TVMW_PRFID_CHANNEL_BOUND_EXECUTE: 14,
    PL_TVMW_PRFID_PASSWORD: 15,
    PL_TVMW_PRFID_SOURCE_BOUND_WIDGET_ID: 16,
    PL_TVMW_PRFID_SOURCE_BOUND_SOURCE_ID: 17,
    PL_TVMW_PRFID_AUTOBOOT: 18,
    PL_TVMW_PRFID_ACRAD_MENU: 19,
    PL_TVMW_PRFID_MEDIA_PLAY_BLOCK: 20,
    PL_TVMW_PRFID_SOURCE_ISP_APP_ID: 21,
    m_SEFDevice: null,
    m_bOpened: false,

    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("Device");
        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Device", OpenCallback);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("Device");
        this.m_bOpened = false;
    },
    getModel: function (param_model) { // 존재함
        print(" --->> getModel();");
        return sefFactory.getSEF("Device").execute("GetModel", String(param_model));
    },

    getSWVersion: function (param_device_type, param_product_version_type) { // 존재함
        print(" --->> getSWVersion();", param_device_type, param_product_version_type);
        return sefFactory.getSEF("Device").execute("GetVersionString", String(param_device_type), String(param_product_version_type));
    }
};

/**
 * @namespace TUNE
 */
exports.TUNE = {
    m_bOpened: false,
    m_bOpenedTV: false,
    m_bOpenedMBR: false,
    m_bOpenedScreen: false,

    PL_TV_EVENT_NO_SIGNAL: "101",
    PL_TV_EVENT_TUNE_CHANNEL: "102",
    PL_TV_EVENT_TUNE_SUCCESS: "103",
    PL_TV_EVENT_BACKGROUND_SIGNAL_OK: "104",
    PL_TV_EVENT_SEARCH_CHANNEL: "105",
    PL_TV_EVENT_CHANNEL_FOUND: "106",

    PL_TV_EVENT_SEARCH_CHANNEL_DONE: "108",
    PL_TV_EVENT_SEARCH_CHANNEL_MAP_FULL: "109",
    PL_TV_EVENT_NOT_SUPPORTED: "110",
    PL_TV_EVENT_MTS_CHANGED: "111",
    PL_TV_EVENT_CHANNEL_MAP_CHANGED: "112",
    PL_TV_EVENT_CHANNEL_CHANGED: "113",
    PL_TV_EVENT_SOURCE_CHANGED: "114",
    PL_TV_EVENT_CHANGE_TV_MODE: "115",
    PL_TV_EVENT_SETCHANNEL_TUNED: "116",
    PL_TV_EVENT_RESOLUTION_CHANGED: "117",
    PL_TV_EVENT_RESOLUTION_DETECTED: "118",

    PL_TV_EVENT_EXTSOURCE_SCART: "121",
    PL_TV_EVENT_UPDATE_DYNAMICSI: "122",
    PL_TV_EVENT_SEARCH_GET_NETWORK_DONE: "123",
    PL_TV_EVENT_HD_NOT_SUPPORT: "124",
    PL_TV_EVENT_SHOW_START: "125",

    PL_TV_EVENT_SOURCE_CONNECTED: "126",

    PL_TV_EVENT_EPG_COMPLETED: "201",
    PL_TV_EVENT_EPG_CHANGED: "202",
    PL_TV_EVENT_CAPTION_DESCRIPTOR: "203",
    PL_TV_EVENT_PROGRAM_CHANGED: "204",
    PL_TV_EVENT_STREAM_CLOCK_CHANGED: "205",

    PL_TV_EVENT_SW_UPGRADE: "206",
    PL_TV_EVENT_PMT_ARRIVED: "207",
    PL_TV_EVENT_DSIDII_ARRIVED: "208",
    PL_TV_EVENT_DDB_ARRIVED: "209",
    PL_TV_EVENT_TSD_ARRIVED: "210",
    PL_TV_EVENT_CHANGE_POWER_STATE: "211",
    PL_TV_EVENT_RECV_CURRENT_EVENT: "212",
    PL_TV_EVENT_STT_CHANGED: "213",
    PL_TV_EVENT_CAPTION_MODE_CHANGED: "214",
    PL_TV_EVENT_PROGRAM_CHANGED_MULTIPLEX: "215",
    PL_TV_EVENT_DVBSI_STARTED: "216",
    PL_TV_EVENT_PRESENT_EIT_CHANGED: "21",

    PL_TV_EVENT_MMI_START: "301",
    PL_TV_EVENT_MMI_END: "302",
    PL_TV_EVENT_INBAND_EAS: "303",
    PL_TV_EVENT_OOB_EAS: "304",
    PL_TV_EVENT_CABLECARD_ENABLE: "305",
    PL_TV_EVENT_CABLECARD_DISABLE: "306",
    PL_TV_EVENT_CABLECARD_CHLIST_UPDATE: "307",
    PL_TV_EVENT_CABLECARD_CHLIST_COMPLETE: "308",
    PL_TV_EVENT_CABLECARD_CP_TECHNICAL_P_START: "309",
    PL_TV_EVENT_CABLECARD_CP_TECHNICAL_H_START: "310",
    PL_TV_EVENT_CABLECARD_CP_TIMEERROR_START: "311",
    PL_TV_EVENT_CABLECARD_HOMING_START: "312",
    PL_TV_EVENT_CABLECARD_HOMING_TUNE: "313",
    PL_TV_EVENT_CABLECARD_HOMING_FINISH: "314",
    PL_TV_EVENT_CABLECARD_HOMING_TIMEOUT: "315",
    PL_TV_EVENT_CABLECARD_CARD_ERROR: "316",
    PL_TV_EVENT_CABLECARD_CA_REPLY: "317",
    PL_TV_EVENT_CABLECARD_CA_UPDATE: "318",
    PL_TV_EVENT_CABLECARD_AI_MMI_READY: "319",
    PL_TV_EVENT_CABLECARD_AI_SERVER_REPLY: "320",

    PL_TV_EVENT_EXTSOURCE_CHECKCABLE: "401",
    PL_TV_EVENT_EXTSOURCE_NOTSUPPORT: "402",
    PL_TV_EVENT_EXTSOURCE_NOSIGNAL: "403",
    PL_TV_EVENT_EXTSOURCE_SIGNAL_OK: "404",

    PL_TV_EVENT_DIGITAL_CAPTION_DATA: "501",
    PL_TV_EVENT_ANALOG_CAPTION_DATA: "502",
    PL_TV_EVENT_GEMSTAR_CAPTION_DATA: "503",
    PL_TV_EVENT_EXIST_CC: "504",

    PL_TV_EVENT_ANALOG_TTX_DATA: "504",
    PL_TV_EVENT_DTV_TTX_DATA: "505",
    PL_TV_EVENT_DTV_SBT_DATA: "506",
    PL_TV_EVENT_DTV_ISDBCAPTION_DATA: "507",
    PL_TV_EVENT_DTV_SUPERIMPOSE_DATA: "508",
    PL_TV_EVENT_PES_CHANGED: "509",
    PL_TV_EVENT_DELIVERY_SYSTEM_CHANGED: "510",
    PL_TV_EVENT_SEARCH_OPTION_CHANGE: "511",
    PL_TV_EVENT_MTS_PREFER_LAN_CHANGED: "512",
    PL_TV_EVENT_NETWORK_CHANGE_INFO_DESC: "513",
    PL_TV_EVENT_TIME_CHILD_LOCK: "514",

    PL_TV_EVENT_SOURCE_CONTROL_CHANGE: "601",
    PL_TV_EVENT_SOURCE_ERROR: "602",
    PL_TV_EVENT_EXTERNALOUT_RECORD_CONTROL_CHANGE: "603",
    PL_TV_EVENT_EXTERNALOUT_ERROR: "604",
    PL_TV_EVENT_MEDIA_COPYPROTECTION_INFO: "605",

    PL_TV_EVENT_SET_MEDIA: "606",
    PL_TV_EVENT_SET_MEDIA_ONTIME: "60",

    PL_TV_EVENT_MEDIA_CHANNEL_FOUND: "608",
    PL_TV_EVENT_CHANNEL_SCRAMBLED: "609",
    PL_TV_EVENT_SERVICE_NOT_AVAILABLE: "610",
    PL_TV_EVENT_DATA_SERVICE: "611",
    PL_TV_EVENT_CAPTION_CHANGED: "6",

    PL_TV_EVENT_MAX: "6",

    PL_WINDOW_SHOW_STATE_OFF: "0",
    PL_WINDOW_SHOW_STATE_NO_SIGNAL: "1",
    PL_WINDOW_SHOW_STATE_VCHIP: "2",
    PL_WINDOW_SHOW_STATE_START: "3",
    PL_WINDOW_SHOW_STATE_STOP: "4",
    PL_WINDOW_SHOW_STATE_MAX: "5",

    PL_WINDOW_SHOW_TYPE_OFF: "0",
    PL_WINDOW_SHOW_TYPE_ON: "1",
    PL_WINDOW_SHOW_TYPE_STOP: "2",
    PL_WINDOW_SHOW_TYPE_START: "3",
    PL_WINDOW_SHOW_TYPE_NO_SIGNAL: "4",
    PL_WINDOW_SHOW_TYPE_VCHIP_ON: "5",
    PL_WINDOW_SHOW_TYPE_VCHIP_OFF: "6",

    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("Window");
        this.m_bOpenedTV = sefFactory.init("TV");
        this.m_bOpenedMBR = sefFactory.init("MBR");
        this.m_bOpenedScreen = sefFactory.init("Screen");

        print(" --->>Window Opened();", this.m_bOpened);
        print(" --->>TV Opened();", this.m_bOpenedTV);
        print(" --->>MBR Opened();", this.m_bOpenedMBR);
        print(" --->>Screen Opened();", this.m_bOpenedScreen);
        sefFactory.getSEF("Window").onEventCallback = TVCallback;
        sefFactory.getSEF("TV").onEventCallback = TVCallback;
        sefFactory.getSEF("MBR").onEventCallback = TVCallback;
        sefFactory.getSEF("Screen").onEventCallback = TVCallback;

        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Window", function () {
            print(" --->>Window Opened();");
        });
        this.m_bOpenedTV = sefFactory.initAsync("TV", function () {
            print(" --->>TV Opened();");
        });
        this.m_bOpenedMBR = sefFactory.initAsync("MBR", OpenCallback);
        this.m_bOpenedScreen = sefFactory.initAsync("Screen", function () {
            print(" --->>Screen Opened();");
        });
        //print(" --->>Window Opened();", this.m_bOpened);
        //print(" --->>TV Opened();", this.m_bOpenedTV);
        print(" --->>MBR Opened();", this.m_bOpenedMBR);
        sefFactory.getSEF("Window").onEventCallback = TVCallback;
        sefFactory.getSEF("TV").onEventCallback = TVCallback;
        sefFactory.getSEF("MBR").onEventCallback = TVCallback;
        sefFactory.getSEF("Screen").onEventCallback = TVCallback;

        return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    isOpenedTV: function () {
        return this.m_bOpenedTV;
    },
    isOpenedMBR: function () {
        return this.m_bOpenedMBR;
    },
    isOpenedScreen: function () {
        return this.m_bOpenedScreen;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("Window");
        sefFactory.releaseSEF("TV");
        sefFactory.releaseSEF("MBR");
        sefFactory.releaseSEF("Screen");
        this.m_bOpened = false;
        this.m_bOpenedTV = false;
        this.m_bOpenedMBR = false;
        this.m_bOpenedScreen = false;
    },
    /**
     * @author jieun24.lee@samsung.com
     * @fn  setPictureOff
     * @description 화면 끄기 기능
     * @param "0"
     * @returns String
     */
    setPictureOff: function () {
        if (!sefFactory.getSEF("Screen")) {
            print(" --->> Screen Not Init;");
            // return;
        }
        print(" --->> setPictureOff();");
        return sefFactory.getSEF("Screen").execute("SetPictureOff", "0");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelNumberInfo
     * @description mbr_get_send_channel_number_info()통해서 nMajor, nMinor 로 채널값을
     *              얻어온다.
     * @param string
     * @returns Json
     */
    getChannelNumberInfo: function (size) {
        if (!sefFactory.getSEF("MBR")) {
            print(" --->> MBR Not Init;");
            // return;
        }
        print(" --->> getChannelNumberInfo();");
        return sefFactory.getSEF("MBR").execute("GetChannelNumberInfo", size);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn setChannelNumberInfo
     * @description mbr_send_channel_number()통해서 nMajor, nMinor 으로 채널 번호를
     *              Set해준다.
     * @param int,
     *            int
     * @returns Json
     */
    setChannelNumberInfo: function (major, minor) {
        if (!sefFactory.getSEF("MBR")) {
            print(" --->> MBR Not Init;");
            // return;
        }
        print(" --->> setChannelNumberInfo();");
        return sefFactory.getSEF("MBR").execute("SetChannelNumberInfo", String(major), String(minor));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn flagMBRMode
     * @description mbr_mode()를 통해서 현재 mode가 MBR모드인지 확인한다.
     * @param
     * @returns Json
     */
    flagMBRMode: function () {
        if (!sefFactory.getSEF("MBR")) {
            print(" --->> MBR Not Init;");
            // return;
        }
        print(" --->> flagMBRMode();");
        return sefFactory.getSEF("MBR").execute("FlagMBRMode");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getTvMode
     * @description 현재 설정된 Tv Mode값을 리턴한다.
     * @param
     * @returns Json
     */
    getTvMode: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getTvMode();");
        return sefFactory.getSEF("Window").execute("GetTvMode");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn setTvMode
     * @description Tv Mode를 설정한다.
     * @param string
     * @returns bool
     */
    setTvMode: function (tvMode) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> setTvMode();", tvMode);
        return sefFactory.getSEF("Window").execute("SetTvMode", tvMode);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getSource
     * @description 현재 설정된 소스 정보를 가져온다.
     * @param string
     * @returns string
     */
    getSource: function (windowSeek) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getSource();", windowSeek);
        return sefFactory.getSEF("Window").execute("GetSource", windowSeek);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn setSource
     * @description 소스를 설정한다.
     * @param string
     * @returns bool
     */
    setSource: function (windowSeek) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> setSource();", windowSeek);
        return sefFactory.getSEF("Window").execute("SetSource", windowSeek);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelMajor
     * @description 현재 Channel의 Major 번호를 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelMajor: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelMajor();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_Major");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelMinor
     * @description 현재 Channel의 Minor 번호를 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelMinor: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelMinor();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_Minor");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelName
     * @description 현재 Channel의 Name을 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelName: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelName();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_Name");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelOriginNetID
     * @description 현재 Channel의 Original Net ID를 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelOriginNetID: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelOriginNetID();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_OriginNetID");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelProgramNumber
     * @description 현재 Channel의 Program number 를 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelProgramNumber: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelProgramNumber();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_ProgramNumber");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelPTC
     * @description 현재 Channel의 PTC 를 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelPTC: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelPTC();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_PTC");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelServiceName
     * @description 현재 Channel의 service name 을 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelServiceName: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelServiceName();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_ServiceName");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelTransportStreamID
     * @description 현재 Channel의 Transport Stream ID 를 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelTransportStreamID: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelTransportStreamID();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_TransportStreamID");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getCurrentChannelType
     * @description 현재 Channel의 Type을 가져온다.
     * @param
     * @returns string
     */
    getCurrentChannelType: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelType();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannel_Type");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn setChannel
     * @description Channel을 설정한다.
     * @param string
     * @returns bool
     */
    setChannel: function (majorChannel, minorChannel) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> setChannel();");
        return sefFactory.getSEF("Window").execute("SetChannel", String(majorChannel), String(minorChannel));
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn findChannel
     * @description 해당 타입에 맞는 채널을 찾는다.
     * @param string
     * @returns string
     */
    findChannel: function (channelType) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> findChannel();");
        return sefFactory.getSEF("Window").execute("FindChannel", channelType);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelMajor
     * @description 해당 채널의 Major를 얻는다.
     * @param number
     * @returns object
     */
    getChannelMajor: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelMajor();");
        return sefFactory.getSEF("Window").execute("GetChannel_Major", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelMinor
     * @description 해당 채널의 Minor를 얻는다.
     * @param number
     * @returns object
     */
    getChannelMinor: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelMinor();");
        return sefFactory.getSEF("Window").execute("GetChannel_Minor", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelName
     * @description 해당 채널의 name을 얻는다.
     * @param number
     * @returns string
     */
    getChannelName: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelName();");
        return sefFactory.getSEF("Window").execute("GetChannel_Name", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelOriginNetID
     * @description 해당 채널의 OriginNetID를 얻는다.
     * @param number
     * @returns string
     */
    getChannelOriginNetID: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelOriginNetID();");
        return sefFactory.getSEF("Window").execute("GetChannel_OriginNetID", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelProgramNumber
     * @description 해당 채널의 ProgramNumber를 얻는다.
     * @param number
     * @returns string
     */
    getChannelProgramNumber: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelProgramNumber();");
        return sefFactory.getSEF("Window").execute("GetChannel_ProgramNumber", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelPTC
     * @description 해당 채널의 PTC를 얻는다.
     * @param number
     * @returns string
     */
    getChannelPTC: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelPTC();");
        return sefFactory.getSEF("Window").execute("GetChannel_PTC", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelServiceName
     * @description 해당 채널의 service name을 얻는다.
     * @param number
     * @returns string
     */
    getChannelServiceName: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelServiceName();");
        return sefFactory.getSEF("Window").execute("GetChannel_ServiceName", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelSize
     * @description 채널의 개수를 얻는다.
     * @param string
     * @returns string
     */
    getChannelSize: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelSize();", channelIndex);
        return sefFactory.getSEF("Window").execute("GetChannel_Size", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelTransportStreamID
     * @description 채널의 TransportStreamID를 얻는다.
     * @param number
     * @returns string
     */
    getChannelTransportStreamID: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelTransportStreamID();");
        return sefFactory.getSEF("Window").execute("GetChannel_TransportStreamID", channelIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getChannelType
     * @description 해당 채널의 type을 얻는다.
     * @param number
     * @returns string
     */
    getChannelType: function (channelIndex) {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getChannelType();");
        return sefFactory.getSEF("Window").execute("GetChannel_Type", channelIndex);
    },


    setWindow: function (window) {
        print(" --->> SetWindow();");
        return sefFactory.getSEF("Window").execute("SetWindow", window);
    },
    getStateShow: function () {
        print(" --->> getStateShow();");
        return sefFactory.getSEF("Window").execute("GetState_Show");
    },

    setChannelPTC: function (PTC) {
        print(" --->> setChannelPTC();");
        return sefFactory.getSEF("Window").execute("SetChannel_PTC", PTC);
    },
    show: function (showType) {
        print(" --->> Show();");
        return sefFactory.getSEF("Window").execute("Show", showType);
    },
    setPreviousSource: function () {
        print(" --->> Show();");
        return sefFactory.getSEF("Window").execute("SetPreviousSource");
    },

    /**
     * @author sumin_.park@samsung.com
     * @fn getPresentProgramDuration
     * @description 현재 프로그램의 duration을 얻는다.
     * @param string
     * @returns string
     */
    getPresentProgramDuration: function () {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getPresentProgramDuration();");
        return sefFactory.getSEF("TV").execute("GetPresentProgram_Duration");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getPresentProgramEndTime
     * @description 현재 프로그램의 end time을 얻는다.
     * @param string
     * @returns string
     */
    getPresentProgramEndTime: function () {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getPresentProgramEndTime();");
        return sefFactory.getSEF("TV").execute("GetPresentProgram_EndTime");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getPresentProgramStartTime
     * @description 현재 프로그램의 start time을 얻는다.
     * @param string
     * @returns string
     */
    getPresentProgramStartTime: function () {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getPresentProgramStartTime();");
        return sefFactory.getSEF("TV").execute("GetPresentProgram_StartTime");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getPresentProgramTitle
     * @description 현재 프로그램의 title을 얻는다.
     * @param string
     * @returns string
     */
    getPresentProgramTitle: function () {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getPresentProgramTitle();");
        return sefFactory.getSEF("TV").execute("GetPresentProgram_Title");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getProgramDuration
     * @description 해당 프로그램의 duration을 얻는다.
     * @param number
     * @returns string
     */
    getProgramDuration: function (programIndex) {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getProgramDuration();", programIndex);
        return sefFactory.getSEF("TV").execute("GetProgram_Duration", programIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getProgramEndTime
     * @description 해당 프로그램의 end time을 얻는다.
     * @param number
     * @returns string
     */
    getProgramEndTime: function (programIndex) {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getProgramEndTime();", programIndex);
        return sefFactory.getSEF("TV").execute("GetProgram_EndTime", programIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getProgramStartTime
     * @description 해당 프로그램의 start time을 얻는다.
     * @param number
     * @returns string
     */
    getProgramStartTime: function (programIndex) {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getProgramStartTime();", programIndex);
        return sefFactory.getSEF("TV").execute("GetProgram_StartTime", programIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getProgramTitle
     * @description 해당 프로그램의 title을 얻는다.
     * @param number
     * @returns string
     */
    getProgramTitle: function (programIndex) {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getProgramTitle();", programIndex);
        return sefFactory.getSEF("TV").execute("GetProgram_Title", programIndex);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getProgramList
     * @description start time, duration으로 프로그램 리스트를 얻는다.
     * @param string,
     *            string
     * @returns string
     */
    getProgramList: function (startTime, duration) {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getProgramList();", startTime, duration);
        return sefFactory.getSEF("TV").execute("GetProgramList", startTime, duration);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getProgramListSize
     * @description 프로그램 리스트 크기를 얻는다.
     * @param string
     * @returns string
     */
    getProgramListSize: function () {
        if (!sefFactory.getSEF("TV")) {
            print(" --->> TV Not Init;");
            // return;
        }
        print(" --->> getProgramListSize();");
        return sefFactory.getSEF("TV").execute("GetProgramList_Size");
    },

    getPresentProgramTitle: function () {
        print(" --->> getPresentProgramTitle();");
        return sefFactory.getSEF("TV").execute("GetPresentProgram_Title");
    },
    /**
     * @author jieun24.lee@samsung.com
     * @fn getCurrentChannelInfo
     * @description Gets current channel information(as JSON)
     * @param N/A
     * @returns Json
     */
    getCurrentChannelInfo: function () {
        if (!sefFactory.getSEF("Window")) {
            print(" --->> Window Not Init;");
            // return;
        }
        print(" --->> getCurrentChannelInfo();");
        return sefFactory.getSEF("Window").execute("GetCurrentChannelInfo");
    },
    setEvent: function (event, cb) {
        print(" --->> SetEvent();");
        TVcbList[String(event)] = cb;
        return sefFactory.getSEF("TV").execute("SetEvent", String(event));
    },
    unsetEvent: function (event) {
        print(" --->> unsetEvent();");
        delete TVcbList[String(event)];
        return sefFactory.getSEF("TV").execute("UnsetEvent", String(event));
    },
    addEventListener: function (eventType, cb) {
        print("---------------------------------------->> addEventListener");
        TVcbList[String(eventType)] = cb;
    }
};

var TVcbList = {};

function TVCallback(eventType, param1, param2) {
    print("-----------------------> EVENT:[] " + eventType + param1);
    if (typeof TVcbList[String(param1)] == "function")
        TVcbList[String(param1)](eventType, param1, param2);
}

/**
 * @author sunjung.yoo@samsung.com
 * @fn retryLoggingOpen
 * @description Logging EMP open resutl check
 * @param
 * @returns
 */

function retryLoggingOpen(openResult) {
    //var result = openResult;
    if (openResult == false) {
        print(" ------------------------->> [[ LoggingOpen fail!! ]]");
        openResult = retryLogginginit();
    } else {
        print("------------------------->> [[ LoggingOpen success!! ]]");
    }
    print(" --->>Logging Opened();", openResult);
    return openResult;
}

function retryLogginginit() {
    print("------------------->> [[retryLogginginit]]");
    var result = exports.Logging.init();
    retryLoggingOpen(result);
}

/**
 * @namespace Logging
 */
exports.Logging = {
    m_bOpened: false,

    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("Logging");
        var retryResult = retryLoggingOpen(this.m_bOpened);
        //print(" --->>Logging Opened();", this.m_bOpened);
        return retryResult;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Logging", OpenCallback);
        print(" --->>Logging Opened();", this.m_bOpened);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("Logging");
        this.m_bOpened = false;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn flushLog
     * @description This functions prepares the message and sends it to server
     *              specified in SetServiceConfInfo call.
     * @param
     * @returns bool
     */
    flushLog: function () {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> flushLog();");
        return sefFactory.getSEF("Logging").execute("FlushLog");
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn addEventFullLog
     * @description This function Adds a full constructed message string to the
     *              queue. Applications can use it for their own format for logs
     * @param string,
     *            string
     * @returns bool
     */
    addEventFullLog: function (eventName, log) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> addEventFullLog();");
        return sefFactory.getSEF("Logging").execute("AddEventFullLog", eventName, log);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn setEventHeader
     * @description This function sets the event header that will be sent in the
     *              message
     * @param string,
     *            string, string, string, string
     * @returns bool
     */
    setEventHeader: function (modelName, userId, DUID, country) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> setEventHeader();");
        return sefFactory.getSEF("Logging").execute("SetEventHeader", modelName, userId, DUID, country);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn addEventConfInfo
     * @description This function adds a new type of Event
     * @param string,
     *            string, string, string, string
     * @returns bool
     */
    addEventConfInfo: function (eventName, queueMax, expiration, threshold, logLevel) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> addEventConfInfo();");
        return sefFactory.getSEF("Logging").execute("AddEventConfInfo", eventName, queueMax, expiration, threshold, logLevel);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn setServiceConfInfo
     * @description This function sets service configuration and check its state
     * @param string,
     *            string, string, string, string, string
     * @returns bool
     */
    setServiceConfInfo: function (serviceName, queueMax, expiration, threshold, logLevel, serverURL) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> setServiceConfInfo();");
        return sefFactory.getSEF("Logging").execute("SetServiceConfInfo", serviceName, queueMax, expiration, threshold, logLevel, serverURL);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn addEventLog
     * @description This function adds a log message.
     * @param string,
     *            string, string, string, string
     * @returns bool
     */
    addEventLog: function (eventName, time, category, value, desc) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> addEventLog();");
        return sefFactory.getSEF("Logging").execute("AddEventLog", eventName, time, category, value, desc);

    },
    /**
     * @author sumin_.park@samsung.com
     * @fn isAgreedWith
     * @description User can call this API with the Aggrement Name (string Type)
     *              for which he wants to get the information.
     * @param string
     * @returns bool
     */
    isAgreedWith: function (aggrementName) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> isAgreedWith();");
        return sefFactory.getSEF("Logging").execute("IsAgreedWith", aggrementName);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getGUID
     * @description This will return Globally Unique ID
     * @param
     * @returns string
     */
    getGUID: function (p1, p2, p3, p4, p5, p6, p7, p8) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            // return;
        }
        print(" --->> getGUID();");
        return sefFactory.getSEF("Logging").execute("GetGUID", p1, p2, p3, p4, p5, p6, p7, p8);
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getUID
     * @description This will return User ID.
     * @param
     * @returns string
     */
    getUID: function (p1, p2, p3, p4, p5, p6, p7, p8) {
        if (!sefFactory.getSEF("Logging")) {
            print(" --->> Logging Not Init;");
            return;
        }
        print(" --->> getUID();");
        return sefFactory.getSEF("Logging").execute("GetUID", p1, p2, p3, p4, p5, p6, p7, p8);
    }
};

function IsJson(str) {
    try {
        if (typeof str === "object") {

            return true;
        } else {

            throw print(" ------------------------->> parameter is not Json;", typeof str);
        }


    } catch (e) {
        throw print(" ------------------------->> error;", e);

    }
}
exports.vconf = {
    MEMORY_VOLT_STRING: "memory/volt/string",
    MEMORY_VOLT_INT: "memory/volt/int",
    MEMORY_VOLT_DOUBLE: "memory/volt/double",
    MEMORY_VOLT_BOOL: "memory/volt/bool",
    MEMORY_VOLT_ROOT_PATH: "memory/volt",

    MEMORY_VOLT_NOTIFY: "memory/volt/notify",
    DB_MENE_NETWORK_DEVICENAME_TV_NAME: "db/menu/network/devicename/tv_name",
    DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST: "db/menu/system/accessibility/highcontrast",
    DB_MENU_SYSTEM_ACCESSIBILITY_FOCUSZOOM: "db/menu/system/accessibility/focuszoom",
    DB_MENU_SYSTEM_MENU_LANGUAGE: "db/menu/system/menu_language",
    MEMORY_HOMEPANEL_COACHMARK_SHOW_FLAG: "memory/homepanel/coachmark_show_flag",
    MEMORY_WINDOW_SYSTEM_INPUT_CURSOR_VISIBLE: "memory/window_system/input/cursor_visible",
    DB_MENU_SYSTEM_GENERAL_MENU_TRANSPARENCY: "db/menu/system/general/menu_transparency",


    getValue: function (key) {
        return Vconf.getValue(key);
    },
    getValues: function () {
        return Vconf.getValues(this.MEMORY_VOLT_ROOT_PATH);
    },
    setValue: function (key, value) {
        return Vconf.setValue(key, value);
    },
    unsetValue: function (key, bool) {
        if (bool == null) {
            return Vconf.unsetValue(key);
        } else {
            return Vconf.unsetValue(key, bool);
        }
    },
    setOnChangeHandler: function (key, callbackfunction) {
        return Vconf.setOnChangeHandler(key, callbackfunction);

    },
    unsetOnChangeHandler: function (key, callbackfunction) {
        return Vconf.unsetOnChangeHandler(key, callbackfunction);
    }
}


// Player
nId = 0;
aPlayerInstance = [];

PlayerState = {
    // Player Plugin Event Enum 
    CONNECTION_FAILED: 1,
    AUTHENTICATION_FAILED: 2,
    STREAM_NOT_FOUND: 3,
    NETWORK_DISCONNECTED: 4,
    NETWORK_SLOW: 5,
    RENDER_ERROR: 6,
    RENDERING_START: 7, //Movie and Music only
    RENDERING_COMPLETE: 8,
    STREAM_INFO_READY: 9,
    DECODING_COMPLETE: 10, //Picture only
    BUFFERING_START: 11,
    BUFFERING_COMPLETE: 12,
    BUFFERING_PROGRESS: 13,
    CURRENT_DISPLAY_TIME: 14,
    CURRENT_PLAYBACK_TIME: 14,
    AD_START: 15,
    AD_END: 16,
    RESOLUTION_CHANGED: 17,
    BITRATE_CHANGED: 18,
    SUBTITLE: 19,
    CUSTOM: 20,
    SEEK_COMPLETED: 30,

    // RENDER_ERROR Detail
    UNKNOWN_ERROR: 0,
    UNSUPPORTED_CONTAINER: 1,
    UNSUPPORTED_VIDEO_CODEC: 2,
    UNSUPPORTED_AUDIO_CODEC: 3,
    UNSUPPORTED_VIDEO_RESOLUTION: 4,
    UNSUPPORTED_VIDEO_FRAMERATE: 5,
    CURRUPTED_STREAM: 6,

    //custom error 20121101
    CUSTOM_ERROR: 100,

    //custom error 20121207
    RTSP_STATE: 95,
    // Player State Enum
    PLAY_STATE_IDLE: 0,
    PLAY_STATE_INITIALIZED: 1,
    PLAY_STATE_STOPPED: 2,
    PLAY_STATE_PREPARED: 3,
    PLAY_STATE_STARTED: 4,
    PLAY_STATE_PAUSED: 5,
    //Sound Type
    SOUND_TYPE_SYSTEM: 1,
    SOUND_TYPE_NOTIFICATION: 2,
    SOUND_TYPE_ALARM: 3,
    SOUND_TYPE_RINGTONE: 4,
    SOUND_TYPE_MEDIA: 5,
    SOUND_TYPE_CALL: 6,
    SOUND_TYPE_VOIP: 7,
    SOUND_TYPE_FIXED: 8,
    SOUND_TYPE_FIXED_AF: 9,
    SOUND_TYPE_FIXED_SHUTTER1: 10,
    SOUND_TYPE_FIXED_SHUTTER2: 11,
    SOUND_TYPE_FIXED_CAMCORDING: 12,

    //Audio Latency
    AUDIO_LATENCY_MODE_LOW: 1,
    AUDIO_LATENCY_MODE_MID: 2,
    AUDIO_LATENCY_MODE_HIGH: 3
};

/**
 * @namespace player
 */
exports.player = {
    /**
     *
     * @author sumin_.park@samsung.com
     * @description Get Player instance
     * @returns Object
     */
    getPlayer: function () {
        var iPlayer = new _Player(nId);
        aPlayerInstance[nId] = iPlayer;
        nId++;
        return iPlayer;
    },

    _getAllInstance: function () {
        return aPlayerInstance;
    },

    _destroyAll: function () {
        var aInstance = player._getAllInstance();
        print('--->> [Player] _destroyAll() with ' + aInstance.length + ' instances.');
        for (var i = 0; i < _getAllInstance.length; i++) {
            aInstance[i].destroy();
        }

    }

};

function PlayTime(ms) {
    this.millisecond = ms;

    var hour = parseInt(ms / (3600 * 1000), 10);
    ms -= hour * (3600 * 1000);
    var min = parseInt(ms / (60 * 1000), 10);
    ms -= min * (60 * 1000);
    var sec = parseInt(ms / (1000), 10);
    this.timeString = (hour > 9 ? hour : '0' + hour) + ':' + (min > 9 ? min : '0' + min) + ':' + (sec > 9 ? sec : '0' + sec);
}

PlayTime.prototype.toString = function () {
    return this.timeString;
};

function _isType(value, types) {
    var sValueType = '';
    if (value === null) {
        sValueType = 'null';
    } else {
        sValueType = typeof value;
    }
    return types.indexOf(sValueType) != -1;
}

function _checkNumberType(num) {
    var nNum = Number(num);

    if (!isFinite(nNum)) {
        nNum = 0;
        return nNum;
    } else {
        return nNum;
    }
}

function _Player(id) {
    var sName = "Player" + id;
    var self = this;
    var ID = id;
    var bOpened = false;
    var bInitialize = false;
    var loopCount = 3;
    var bAutoRatio = true;
    var videoWidget = null;

    var oInitOption = {}; // AVPlayInitialOption -> init()에서 저장
    var oPlayOption = {}; // AVPlayOption -> open()에서 저장

    //	var cbOnSubtitle = null;

    ePlayerPlugin = null;

    this.status = PlayerState.PLAY_STATE_IDLE;
    this.Event2String = {}; // serial log 에 보여주기 위한 string
    this.Event2String[PlayerState.CONNECTION_FAILED] = "CONNECTION_FAILED";
    this.Event2String[PlayerState.AUTHENTICATION_FAILED] = "AUTHENTICATION_FAILED";
    this.Event2String[PlayerState.STREAM_NOT_FOUND] = "STREAM_NOT_FOUND";
    this.Event2String[PlayerState.NETWORK_DISCONNECTED] = "NETWORK_DISCONNECTED";
    this.Event2String[PlayerState.NETWORK_SLOW] = "NETWORK_SLOW";
    this.Event2String[PlayerState.RENDER_ERROR] = "RENDER_ERROR";
    this.Event2String[PlayerState.RENDERING_START] = "RENDERING_START";
    this.Event2String[PlayerState.RENDERING_COMPLETE] = "RENDERING_COMPLETE";
    this.Event2String[PlayerState.STREAM_INFO_READY] = "STREAM_INFO_READY";
    this.Event2String[PlayerState.DECODING_COMPLETE] = "DECODING_COMPLETE";
    this.Event2String[PlayerState.BUFFERING_START] = "BUFFERING_START";
    this.Event2String[PlayerState.BUFFERING_COMPLETE] = "BUFFERING_COMPLETE";
    this.Event2String[PlayerState.BUFFERING_PROGRESS] = "BUFFERING_PROGRESS";
    this.Event2String[PlayerState.CURRENT_PLAYBACK_TIME] = "CURRENT_PLAYBACK_TIME";
    this.Event2String[PlayerState.AD_START] = "AD_START";
    this.Event2String[PlayerState.AD_END] = "AD_END";
    this.Event2String[PlayerState.RESOLUTION_CHANGED] = "RESOLUTION_CHANGED";
    this.Event2String[PlayerState.BITRATE_CHANGED] = "BITRATE_CHANGED";
    this.Event2String[PlayerState.SUBTITLE] = "SUBTITLE";
    this.Event2String[PlayerState.CUSTOM] = "CUSTOM";

    this.State2String = {};
    this.State2String[PlayerState.PLAY_STATE_IDLE] = "PLAY_STATE_IDLE";
    this.State2String[PlayerState.PLAY_STATE_INITIALIZED] = "PLAY_STATE_INITIALIZED";
    this.State2String[PlayerState.PLAY_STATE_STOPPED] = "PLAY_STATE_STOPPED";
    this.State2String[PlayerState.PLAY_STATE_PREPARED] = "PLAY_STATE_PREPARED";
    this.State2String[PlayerState.PLAY_STATE_STARTED] = "PLAY_STATE_STARTED";
    this.State2String[PlayerState.PLAY_STATE_PAUSED] = "PLAY_STATE_PAUSED";

    this.getID = function () {
        return ID;
    }, this.getName = function () {
        return sName;
    }, this.destroy = function () {
        print("--->> [Player" + id + "] stop(" + ")");
        this.close();
    },
    this.close = function () {
        if (bOpened) {
            bInitialize = false;
            ePlayerPlugin.close();
        }
    }

    this.getSEFObj = function () {
        return ePlayerPlugin;
    }
    this.getVideoWidget = function () {
        return videoWidget;
    }
    this.createVideoWidget = function (args) {
        if (videoWidget == null) {
            videoWidget = new VideoWidget(args);
            videoWidget.videoPlayerSef = ePlayerPlugin;
        }
        return videoWidget;
    }


    /**
     * @memberof exports.player
     * @author sumin_.park@samsung.com
     * @fn init
     * @description Player init
     * @param Json Object
     * @returns
     */
    this.init = function (option) {
        /*
	     option = {
		     containerID: id,	// [init()]
		     zIndex: 0,	// [init()]
		     bufferingCallback: {
			     onbufferingstart : onBufferingStart,
			     onbufferingprogress : onBufferingProgress,
			     onbufferingcomplete : onBufferingComplete
		     },
		     playCallback: {
			     oncurrentplaytime : onCurrentPlayTime,
			     onresolutionchanged : onResolutionChange,
			     onstreamcompleted : onStreamComplete,
			     onseekcompleted : onSeekComplete,
			     onerror : onRederingError
		     },
		     displayRect: {	// SRect instance [init()]
			     top: 100,
			     left : 100,
			     width : 200,
			     height : 200
		     },
		     autoRatio: true,	// [STREAM_INFO_READY]
		     frontPanelLock: false // Front panel 표시 여부. MP3 재생시 표시하지 않도록 하기 위함
	     }
	     */

        // Parameter Type Checking
        if (_isType(option, 'object')) {
            if (_isType(option.bufferingCallback, 'object')) {
                if (!_isType(option.bufferingCallback.onbufferingstart, 'undefined|function') ||
                    !_isType(option.bufferingCallback.onbufferingprogress, 'undefined|function') ||
                    !_isType(option.bufferingCallback.onbufferingcomplete, 'undefined|function')
                ) {
                    print("--->> Player init bufferingCallback InvalidValuesError");
                }
            }

            if (_isType(option.playCallback, 'object')) {
                if (!_isType(option.playCallback.oncurrentplaytime, 'undefined|function') ||
                    !_isType(option.playCallback.onresolutionchanged, 'undefined|function') ||
                    !_isType(option.playCallback.onstreamcompleted, 'undefined|function') ||
                    !_isType(option.playCallback.onseekcompleted, 'undefined|function') ||
                    !_isType(option.playCallback.onerror, 'undefined|function')
                ) {
                    print("--->> Player init playCallback InvalidValuesError");
                }
            }
        } else {
            if (!_isType(option, 'undefined|null')) {
                print("--->> Player init InvalidValuesError");
            }
        }
        // Parameter Type Checking End
        oInitOption = option || {};
        try {
            print("--->> [Player" + id + "] init( option : " + String(option) + ")");

            if (ePlayerPlugin) { // 이전 Player Object를 제거
                print("--->> [Player" + id + "] Destroy ePlayerPlugin( option : " + String(option) + ")");
                this.close(); // Play() 상태에서 DOM을 건들면 죽는다.				
                ePlayerPlugin = null;
            }
            ePlayerPlugin = new Sef();

            if (ePlayerPlugin) {

                ret = ePlayerPlugin.open("Player", "1.120", "Player" + id);
                print("--->> [Player" + id + "] open()", ret);
            }

            bOpened = true;
            if (oInitOption.displayRect) {
                this.setDisplayArea(oInitOption.displayRect.top, oInitOption.displayRect.left, oInitOption.displayRect.width, oInitOption.displayRect.height, 1080);
            } else {
                print('[Player' + id + '] !WARNNING! > You did Not set displayRect.');
            }


            if (oInitOption.autoRatio !== undefined) {
                bAutoRatio = oInitOption.autoRatio;
            }
            if (this.status == PlayerState.PLAY_STATE_IDLE) {
                this.status = PlayerState.PLAY_STATE_INITIALIZED;
            }
            //this.setDisplayArea(0, 0, 1920, 1080, 1080);
            var evtListener = new _onPlayerPluginEvent(id, this);
            ePlayerPlugin.onEventCallback = function () {
                evtListener.onEvent.apply(evtListener, arguments);
            };

        } catch (e) {
            print("--->> [Player" + id + "] Error init( " + e + ")");
        }
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn open
     * @description Player open
     * @param Json Object
     * @returns
     */
    this.open = function (url, option) {
        /*
         * option = {
             totalBufferSize: 10240000, // [play()]
             pendingBufferSize: 10240000,   // [play()]
             initialBufferSize: 10240000,   // [play()]
             adaptive: {
                 type: ,
                 bitrates: ,
                 upTimer: ,
                 startBitrate: ,
                 startTime: ,
                 admode: ,
             },
             drm: {
                 type: ,
                 company: ,
                 deviceID: ,
                 deviceType: ,
                 streamID: ,
                 drmURL: ,
                 ackURL: ,
                 heartbeatPeriod: ,
                 portal: ,
                 userData: ,
                 cookie: 
             },
             macrovision: {
                 type: webapis.avplay.APS_ALL_OFF, // macrovision을 설정하기 위해 macrovisionType, ict, vbi 모든 값이 있어야 함. [STREAM_INFO_READY]
                 ict: webapis.avplay.ICT_ON, // [STREAM_INFO_READY]
                 dot: ,
                 vbi: webapis.avplay.CGMS_COPY_FREE, // CGMS type 이 와야하는 것인지? [STREAM_INFO_READY]
             },
             subtitle: {
                 path: ,
                 streamID: ,
                 sync: ,
                 callback: 
             }
             
             // 임시
             mode3D: webapis.displaycontrol.MODE_3D_EFFECT_SIDE_BY_SIDE, [play()] // [120406] IDL에 항목 없음
             authHeader: // 'basic' or 'none' (Default: 'basic')
         * }
         */
        var iurl = String(url);

        if (!_isType(iurl, 'string') ||
            !_isType(option, 'undefined|object|null')
        ) {
            print("--->> Player Open TYPE_MISMATCH_ERR");
        }

        if (_isType(option, 'object')) {
            if (!_isType(option.totalBufferSize, 'undefined|number') ||
                !_isType(option.pendingBufferSize, 'undefined|number') ||
                !_isType(option.initialBufferSize, 'undefined|number') ||
                !_isType(option.adaptive, 'undefined|object') ||
                !_isType(option.drm, 'undefined|object') ||
                !_isType(option.macrovision, 'undefined|object') ||
                !_isType(option.subtitle, 'undefined|object') ||
                !_isType(option.mode3D, 'undefined|number') ||
                !_isType(option.authHeader, 'undefined|string')
            ) {
                print("--->> Player Open TYPE_MISMATCH_ERR");
            }

            if (_isType(option.adaptive, 'object')) {
                if (!_isType(option.adaptive.type, 'string') ||
                    !_isType(option.adaptive.bitrates, 'undefined|string') ||
                    !_isType(option.adaptive.upTimer, 'undefined|string') ||
                    !_isType(option.adaptive.startBitrate, 'undefined|string') ||
                    !_isType(option.adaptive.startTime, 'undefined|string') ||
                    !_isType(option.adaptive.admode, 'undefined|string')
                ) {
                    print("--->> Player Open TYPE_MISMATCH_ERR");
                }
            }

            if (_isType(option.drm, 'object')) {
                if (!_isType(option.drm.type, 'string') ||
                    !_isType(option.drm.company, 'undefined|string') ||
                    !_isType(option.drm.deviceID, 'undefined|string') ||
                    !_isType(option.drm.deviceType, 'undefined|string') ||
                    !_isType(option.drm.streamID, 'undefined|string') ||
                    !_isType(option.drm.drmURL, 'undefined|string') ||
                    !_isType(option.drm.ackURL, 'undefined|string') ||
                    !_isType(option.drm.heartbeatPeriod, 'undefined|string') ||
                    !_isType(option.drm.portal, 'undefined|string') ||
                    !_isType(option.drm.userData, 'undefined|string') ||
                    !_isType(option.drm.cookie, 'undefined|string')
                ) {
                    print("--->> Player Open TYPE_MISMATCH_ERR");
                }
            }

            if (_isType(option.macrovision, 'object')) {
                if (!_isType(option.macrovision.type, 'undefined|number') ||
                    !_isType(option.macrovision.ict, 'undefined|number') ||
                    !_isType(option.macrovision.dot, 'undefined|number') ||
                    !_isType(option.macrovision.vbi, 'undefined|number')
                ) {
                    print("--->> Player Open TYPE_MISMATCH_ERR");
                }
            }

            if (_isType(option.subtitle, 'object')) {
                if (!_isType(option.subtitle.path, 'string') ||
                    !_isType(option.subtitle.streamID, 'number') ||
                    !_isType(option.subtitle.sync, 'undefined|number') ||
                    !_isType(option.subtitle.callback, 'function')
                ) {
                    print("--->> Player Open TYPE_MISMATCH_ERR");
                }
            }
        }

        if (!bOpened) {
            print('[AVPlay' + id + '] Do init() first..');
            return false;
        };
        if (this.status == PlayerState.PLAY_STATE_STOPPED ||
            this.status == PlayerState.PLAY_STATE_INITIALIZED) {

            print("--->> [Player" + id + "] open(" + url + ")");
            print("--->> [Player" + id + "] ePlayerPlugin(" + ePlayerPlugin + ")");
            var result = ePlayerPlugin.execute("InitPlayer", iurl);
            this.status = PlayerState.PLAY_STATE_PREPARED;

            if (result) {
                print("--->> Open complete");
                return result;
            }
        } else {
            print("--->> Player Open INVALID_STATE_ERR", this.State2String[this.status]);
            return 'Failed to handle the Execute call.';
        }
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn play
     * @description Player play
     * @param number
     * @returns
     */
    this.play = function (sec) {
        var isec = _checkNumberType(sec);
        print("--->> [Player" + id + "] play(" + isec + ")");
        if (isec < 0) {
            print("--->> Player play InvalidValuesError");
            this.status = PlayerState.PLAY_STATE_STOPPED;
            return;
        }

        if (!bOpened) {
            print('-->[Player' + id + '] Do init() first..');
            return false;
        };
        if (this.status != PlayerState.PLAY_STATE_PREPARED) {
            print('-->[Player' + id + '] !THROW ERROR! INVALID_STATE_ERR');
            return;
        }

        if (oPlayOption.totalBufferSize) { // oInitOption -> totalBufferSize 처리
            this.setTotalBufferSize(oPlayOption.totalBufferSize);
        }
        if (oPlayOption.pendingBufferSize) {
            this.setPendingBufferSize(oPlayOption.pendingBufferSize);
        }
        if (oPlayOption.initialBufferSize) {
            this.setInitialBufferSize(oPlayOption.initialBufferSize);
        }


        var retValue = ePlayerPlugin.execute("StartPlayback", String(isec));

        if (retValue == -1) {
            print("--->> Player play UnknownError");
            this.status = PlayerState.PLAY_STATE_STOPPED;
            return;
        }


        this.status = PlayerState.PLAY_STATE_STARTED;
        return retValue;

    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn stop
     * @description Player stop
     * @param
     * @returns
     */
    this.stop = function () {
        if (bOpened) {

            print("--->> [Player" + id + "] stop()");
            if (self.macrovision) { // widget has to clear to level 0 before widget calls 'Stop', if widget set macrovision level.
                self.setMacrovision(self.APS_ALL_OFF); // 0: APS_ALL_OFF, 
            }
            this.status = PlayerState.PLAY_STATE_STOPPED;
            return ePlayerPlugin.execute("Stop"); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn pause
     * @description Player pause
     * @param
     * @returns
     */
    this.pause = function () {
        if (bOpened) {
            print("--->> [Player" + id + "] Pause()");
            this.status = PlayerState.PLAY_STATE_PAUSED;
            return ePlayerPlugin.execute("Pause"); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn resume
     * @description Player resume
     * @param
     * @returns
     */
    this.resume = function () {
        if (bOpened) {
            print("--->> [Player" + id + "] Resume()");
            this.status = PlayerState.PLAY_STATE_STARTED;
            return ePlayerPlugin.execute("Resume"); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn seek
     * @description Player seek
     * @param sec
     * @returns
     */
    this.seek = function (sec) {
        if (bOpened) {
            print("--->> [Player" + id + "] Seek()");
            return ePlayerPlugin.execute("Seek", sec); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn jumpForward
     * @description Player jumpForward
     * @param offset
     * @returns
     */
    this.jumpForward = function (sec) {
        var isec = _checkNumberType(sec);
        if (isec < 0) {
            print("--->> Player play InvalidValuesError");
            return;
        }
        if (bOpened) {
            print("--->> [Player" + id + "] JumpForward()");
            return ePlayerPlugin.execute("JumpForward", String(isec)); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn jumpBackward
     * @description Player jumpBackward
     * @param offset
     * @returns
     */
    this.jumpBackward = function (sec) {
        var isec = _checkNumberType(sec);
        if (isec < 0) {
            print("--->> Player play InvalidValuesError");
            return;
        }
        if (bOpened) {
            print("--->> [Player" + id + "] JumpBackward()");
            return ePlayerPlugin.execute("JumpBackward", String(isec)); // 1: success,
            // -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn setPlaybackSpeed
     * @description Player setPlaybackSpeed
     * @param speed
     * @returns
     */
    this.setPlaybackSpeed = function (speed) {
        var ispeed = _checkNumberType(speed);
        if (bOpened) {
            print("--->> [Player" + id + "] SetPlaybackSpeed()");
            this.status = PlayerState.PLAY_STATE_STARTED;
            return ePlayerPlugin.execute("SetPlaybackSpeed", String(speed)); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn getDuration
     * @description Player getDuration
     * @param duration
     * @returns
     */
    this.getDuration = function () {
        if (bOpened) {
            print("--->> [Player" + id + "] GetDuration()");
            var result = ePlayerPlugin.execute("GetDuration");
            print("-------------------------------------- typeof >>>>>", typeof result);
            return ePlayerPlugin.execute("GetDuration"); // 1: success,
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn setVolume
     * @description Player setVolume
     * @param level
     * @returns
     */
    this.setVolume = function (level) {
        if (bOpened) {
            print("--->> [Player" + id + "] SetVolume()");
            return ePlayerPlugin.execute("SetVolume", level); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn getState
     * @description Player getState
     * @param
     * @returns
     */
    this.getState = function () {
        if (ePlayerPlugin) {
            try {
                print("--->> [Player" + id + "] GetState()");
                return ePlayerPlugin.execute("GetState"); // 1: success, -1:
            } catch (e) {
                print("--->> [Player" + id + "] GetState Error()", e);
            }

        }
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn setSoundType
     * @description Player setSoundType
     * @param
     * @returns
     */
    this.setSoundType = function (soundType) {
        if (bOpened) {
            print("--->> [Player" + id + "] SetSoundType()");
            return ePlayerPlugin.execute("SetSoundType", soundType); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn setAudioLatencyMode
     * @description Player setAudioLatencyMode
     * @param audioLatencyMode
     * @returns
     */
    this.setAudioLatencyMode = function (audioLatencyMode) {
        if (bOpened) {
            print("--->> [Player" + id + "] SetAudioLatencyMode()");
            return ePlayerPlugin.execute("SetAudioLatencyMode", audioLatencyMode); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn getPlayingTime
     * @description Player getPlayingTime
     * @param
     * @returns
     */
    this.getPlayingTime = function () {
        if (bOpened) {
            print("--->> [Player" + id + "] GetPlayingTime()");
            return ePlayerPlugin.execute("GetPlayingTime"); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },

    /** 
     * @author jieun24@samsung.com
     * @description 미디어 플레이어의 쿠키속성등을 설정한다.
     * @params Type(Number), StrParam(String), NumParam(Number)
     * @returns true/false(Boolean)
     */
    this.setPlayerProperty = function (type, strParam, numParam) {
        if (bOpened) {
            print("--->> [Player" + id + "] SetPlayerProperty()");
            return ePlayerPlugin.execute("SetPlayerProperty", String(type), String(strParam), String(numParam));
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn setLooping
     * @description Player setLooping
     * @param isLooping
     * @returns
     */
    this.setLooping = function (isLooping) {
        if (bOpened) {
            print("--->> [Player" + id + "] SetLooping()");
            return ePlayerPlugin.execute("SetLooping", isLooping); // 1: success, -1:
        }
        return 'Failed to handle the Execute call.';
    },
    /**
     * @author sumin_.park@samsung.com
     * @memberof exports.player
     * @fn setDisplayArea
     * @description Player setDisplayArea
     * @param x, y, width, height
     * @returns
     */
    //int x, int y, int width, int height, int baseRes, bool bAutoResume
    this.setDisplayArea = function (x, y, width, height, baseRes) {
        if (bOpened) {
            var set = ePlayerPlugin.execute("SetDisplayArea", String(x), String(y), String(width), String(height), String(baseRes || 1080));
            print("--->> [Player" + id + "] setDisplayArea(" + set + ")");
            return set;
        }
        return 'Failed to handle the Execute call.';

    },
    this.getVideoResolution = function () {
        var retValue = null;
        if (ePlayerPlugin) {
            retValue = ePlayerPlugin.execute("GetVideoResolution"); // x: success, -1: fail
        } else {
            //retValue = ePlayerPlugin.GetVideoWidth() + '|' + ePlayerPlugin.GetVideoHeight();	// EMP Player 형태로 맞춤
        }
        print('--->>[Player' + id + '] getVideoResolution() returns ' + retValue);
        return retValue;
    },
    this.onEvent = function (type, param, param2) {
        print("mycallback-----------------------------------------------------------------------------------------------------------!!")
        print('[Player' + id + '] onEvent(' + type + ',' + param + ',' + param2 + ') -> ' + this.Event2String[type]);
        switch (type) {
        case PlayerState.STREAM_INFO_READY:
            var resolution = this.getVideoResolution();
            if (typeof resolution == 'string') {
                resolution = resolution.split('|'); // '1280|720'

                // oPlayOption.displayArea 가 있으면 설정, autoRatio flag 무시
                if (oInitOption.displayRect) { // oPlayOption -> displayArea 처리
                    this.setDisplayArea(oInitOption.displayRect.top, oInitOption.displayRect.left, oInitOption.displayRect.width, oInitOption.displayRect.height, 1080);
                } else if (bAutoRatio) { // fullscreen
                    this.setDisplayArea(0, 0, scene.width, scene.height);
                }
            } else {}
            break;
        case PlayerState.BUFFERING_START:
            if (this.status == PlayerState.PLAY_STATE_STOPPED) {
                print('[player' + id + '] This BUFFERING_START event occured after stop() call. skip.');
                return;
            }
            if (oInitOption.bufferingCallback) { // oInitOption -> onbufferingstart 처리
                if (typeof oInitOption.bufferingCallback.onbufferingstart == 'function') {
                    oInitOption.bufferingCallback.onbufferingstart(param);
                }
            }

            break;
        case PlayerState.BUFFERING_PROGRESS:
            if (this.status == PlayerState.PLAY_STATE_STOPPED) {
                print('[player' + id + '] This BUFFERING_PROGRESS event occured after stop() call. skip.');
                return;
            }
            if (oInitOption.bufferingCallback) { // oInitOption -> onbufferingstart 처리
                if (typeof oInitOption.bufferingCallback.onbufferingprogress == 'function') {
                    oInitOption.bufferingCallback.onbufferingprogress(param);
                }
            }
            break;
        case PlayerState.BUFFERING_COMPLETE:
            if (oInitOption.bufferingCallback) { // oInitOption -> onbufferingcomplete 처리
                if (typeof oInitOption.bufferingCallback.onbufferingcomplete == 'function') {
                    oInitOption.bufferingCallback.onbufferingcomplete(param);
                }
            }
            break;
        case PlayerState.RENDERING_START:
            if (this.status == PlayerState.PLAY_STATE_STOPPED) {
                print('[player' + id + '] This RENDERING_START event occured after stop() call. skip.');
                return;
            }
            break;
        case PlayerState.CURRENT_PLAYBACK_TIME:
            if (this.status == PlayerState.PLAY_STATE_STOPPED) {
                print('[player' + id + '] This CURRENT_PLAYBACK_TIME event is not occured on "PLAY_STATE_STARTED". skip..');
                return;
            }
            if (oInitOption.playCallback) { // oInitOption -> oncurrentplaytime 처리
                if (typeof oInitOption.playCallback.oncurrentplaytime == 'function') {
                    oInitOption.playCallback.oncurrentplaytime(param);
                }
            }
            break;
        case PlayerState.RENDERING_COMPLETE:
            //Volt.setTimeout(function(){ 
            this.stop();
            if (oInitOption.playCallback) { // oInitOption -> onstreamcompleted 처리
                if (typeof oInitOption.playCallback.onstreamcompleted == 'function') {
                    oInitOption.playCallback.onstreamcompleted(param);
                }
            }
            //}, 0);
            break;
        case PlayerState.CONNECTION_FAILED:
        case PlayerState.STREAM_NOT_FOUND:
            this.stop();
            if (typeof oInitOption.playCallback.onerror == 'function') {
                oInitOption.playCallback.onerror("NOT_FOUND_ERR");
            }
            break;
        case PlayerState.AUTHENTICATION_FAILED:
            this.stop();
            if (typeof oInitOption.playCallback.onerror == 'function') {
                oInitOption.playCallback.onerror("SECURITY_ERR");
            }
            break;
        case PlayerState.NETWORK_DISCONNECTED:
            this.stop();
            if (typeof oInitOption.playCallback.onerror == 'function') {
                oInitOption.playCallback.onerror("NETWORK_ERR");
            }
            break;
        case PlayerState.NETWORK_SLOW:
            this.stop();
            if (typeof oInitOption.playCallback.onerror == 'function') {
                oInitOption.playCallback.onerror("NetworkSlowError");
            }
            break;
        case PlayerState.RENDER_ERROR:
            this.stop();
            if (oInitOption.playCallback) {
                if (typeof oInitOption.playCallback.onerror == 'function') {
                    switch (Number(data)) {
                    case PlayerState.UNKNOWN_ERROR:
                        oInitOption.playCallback.onerror("UnknownError");
                        break;
                    case PlayerState.UNSUPPORTED_CONTAINER:
                        oInitOption.playCallback.onerror("PlayerUnsupportedContainerError");
                        break;
                    case PlayerState.UNSUPPORTED_VIDEO_CODEC:
                        oInitOption.playCallback.onerror("PlayerUnsupportedVideoFormatError");
                        break;
                    case PlayerState.UNSUPPORTED_AUDIO_CODEC:
                        oInitOption.playCallback.onerror("PlayerUnsupportedAudioFormatError");
                        break;
                    case PlayerState.UNSUPPORTED_VIDEO_RESOLUTION:
                        oInitOption.playCallback.onerror("PlayerUnsupportedVideoResolutionError");
                        break;
                    case PlayerState.UNSUPPORTED_VIDEO_FRAMERATE:
                        oInitOption.playCallback.onerror("PlayerUnsupportedVideoFramerateError");
                        break;
                    case PlayerState.CURRUPTED_STREAM:
                        oInitOption.playCallback.onerror("PlayerCurruptedStreamError");
                        break;
                    default:
                        print('[Player' + id + '] !ERROR! No detail category..');
                        oInitOption.playCallback.onerror("UnknownError");
                        break;
                    }
                }
            }
            break;
        case PlayerState.CUSTOM_ERROR:
            this.stop();
            if (typeof oInitOption.playCallback.onerror == 'function') {
                oInitOption.playCallback.onerror({
                    "CustomError": param
                });
            }
            break;
        case PlayerState.RTSP_STATE:
            if (typeof oInitOption.playCallback.onerror == 'function') {
                oInitOption.playCallback.onerror({
                    "RTSPState": param
                });
            }
            break;
        case PlayerState.AD_START:
        case PlayerState.AD_END:
            break;
        case PlayerState.RESOLUTION_CHANGED:
            if (oInitOption.playCallback) { // oInitOption -> onresolutionchanged 처리
                if (typeof oInitOption.playCallback.onresolutionchanged == 'function') {
                    var resolution = this.getVideoResolution().split('|'); // '1280|720'
                    oInitOption.playCallback.onresolutionchanged(resolution[0], resolution[1]);
                }
            }
            break;
        case PlayerState.BITRATE_CHANGED:
        case PlayerState.CUSTOM:
            break;
        case PlayerState.SUBTITLE:
            break;
        case PlayerState.SEEK_COMPLETED:
            if (oInitOption.playCallback) { // oInitOption -> onstreamcompleted 처리
                if (typeof oInitOption.playCallback.onseekcompleted == 'function') {
                    oInitOption.playCallback.onseekcompleted(param);
                }
            }
            break;
        default:
            break;
        }
    }

    this.setTotalBufferSize = function (bytes) {
        var retValue = null;
        if (ePlayerPlugin) {
            retValue = ePlayerPlugin.execute("SetTotalBufferSize", bytes); // 1: success, -1: fail
            print('[AVPlay' + id + '] setTotalBufferSize(' + bytes + ') returns ' + (retValue == 1));
        }
        return retValue == 1;
    }
    this.setInitialBufferSize = function (bytes) {
        var retValue = null;
        if (ePlayerPlugin) {
            retValue = ePlayerPlugin.execute("SetInitialBufferSize", bytes); // 1: success, -1: fail
        } else {
            retValue = ePlayerPlugin.execute("SetInitialBuffer", bytes); // 1: success, -1: fail
        }
        print('[AVPlay' + id + '] setInitialBufferSize(' + bytes + ') returns ' + (retValue == 1));
        return retValue == 1;
    }
    this.setPendingBufferSize = function (bytes) {
        var retValue = null;
        if (ePlayerPlugin) {
            retValue = ePlayerPlugin.execute("SetPendingBufferSize", bytes); // 1: success, -1: fail
        } else {
            retValue = ePlayerPlugin.execute("SetPendingBuffer", bytes); // 1: success, -1: fail
        }
        print('[AVPlay' + id + '] setPendingBufferSize(' + bytes + ') returns ' + (retValue == 1));
        return retValue == 1;
    }
}

function _onPlayerPluginEvent(id, player) {
    var sName = 'Player' + id; // Instance name
    this.iPlayer = player;
    this.setMasterObject = function (player) {
        this.iPlayer = player;
    }
    this.onEvent = function (type, param, param2) {
        print('--->> [Player' + id + '] _onPlayerPluginEvent(' + type + ',' + param + ',' + param2 + ') -> ' + this.iPlayer.Event2String[type]);
        this.iPlayer.onEvent(type, param, param2);
    }
}


/**
 * @namespace Time
 */
exports.Time = {
    m_bOpened: false,
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("Time");
        print(" --->> Opened();", this.m_bOpened);
        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("Time", OpenCallback);
        print(" --->> Opened();", this.m_bOpened);
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("Time");
        this.m_bOpened = false;
    },
    /**
     * @author sumin_.park@samsung.com
     * @fn getEpochTime
     * @description
     * @param
     * @returns
     */
    getEpochTime: function () {
        print(" --->> getEpochTime();");
        return sefFactory.getSEF("Time").execute("GetEpochTime");
    }
};



/**
 * @namespace DMRAudioPlayer
 */
exports.DMRAudioPlayer = {

    STATE_STOPPED: "0",
    STATE_TRANSITIONING: "1",
    STATE_PLAYING: "2",
    STATE_PAUSED: "3",

    STOPPED_REASON_END_OF_PLAYING: "0",
    STOPPED_REASON_USER_INTERRUPT: "1",
    STOPPED_REASON_ERROR: "2",
    STOPPED_REASON_EXTERNAL_REQUEST: "3",
    STOPPED_REASON_UNKNOWN: "4",

    DMR_AUDIO_PLAYER_EMP_ATTACH_SUCCESS: "1",
    DMR_AUDIO_PLAYER_EMP_ATTACH_FAIL: "2",
    DMR_AUDIO_PLAYER_EMP_PAUSE: "3",
    DMR_AUDIO_PLAYER_EMP_PLAY: "4",
    DMR_AUDIO_PLAYER_EMP_STOP: "5",
    DMR_AUDIO_PLAYER_EMP_SEEK_TIME: "6",
    DMR_AUDIO_PLAYER_EMP_GET_ITEM_DURATION: "7",
    DMR_AUDIO_PLAYER_EMP_GET_ITEM_PLAYING_POSITION: "8",
    DMR_AUDIO_PLAYER_EMP_GET_PLAYING_STATE: "9",


    m_bOpened: false,
    init: function () {
        print(" --->> init();");
        this.m_bOpened = sefFactory.init("DmrAudio");
        print(" --->> Opened();", this.m_bOpened);
        sefFactory.getSEF("DmrAudio").onEventCallback = DmrAudioCallback;
        return this.m_bOpened;
    },
    initAsync: function (OpenCallback) {
        print(" --->> initAsync();");
        this.m_bOpened = sefFactory.initAsync("DmrAudio", OpenCallback);
        print(" --->> Opened();", this.m_bOpened);
        sefFactory.getSEF("DmrAudio").onEventCallback = DmrAudioCallback;
        //return this.m_bOpened;
    },
    isOpened: function () {
        return this.m_bOpened;
    },
    destroy: function () {
        print(" --->> destroy();");
        sefFactory.releaseSEF("DmrAudio");
        this.m_bOpened = false;
    },
    /**
     * @author yj14.lee@samsung.com
     * @fn attachAudioPlayer
     * @description Provide information of DLNA/UPnP devices in the network.
     * @param void
     * @returns bool
     */
    attachAudioPlayer: function (playerInstanceId) {
        print(" --->> attachAudioPlayer();");
        try {
            return sefFactory.getSEF("DmrAudio").execute("dmr_attach_audio_player", playerInstanceId);
        } catch (e) {
            return "failed emp execute";
        }
    },
    /**
     * @author yj14.lee@samsung.com
     * @fn detachAudioPlayer
     * @description Unbinding audio player from DMR.
     * @param void
     * @returns bool
     */
    detachAudioPlayer: function () {
        print(" --->> detachAudioPlayer();");
        return sefFactory.getSEF("DmrAudio").execute("dmr_detach_audio_player");
    },
    /**
     * @author yj14.lee@samsung.com
     * @fn setEventCallback
     * @description Set a callback with DMR service which will notify when DMR received new request from network.
     * @param void
     * @returns bool
     */
    setEventCallback: function () {
        print(" --->> set_event_callback();");
        return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_set_event_callback");
    },
    /**
     * @author yj14.lee@samsung.com
     * @fn notifyItemDuration
     * @description Notify DMR about duration of current audio item when this information became available.
     * @param milliseconds - number
     * @returns bool
     */
    notifyItemDuration: function (milliseconds) {
        print(" --->> notify_item_duration();");
        return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_item_duration", String(milliseconds));
    },
    /**
     * @author yj14.lee@samsung.com
     * @fn notifyItemPlayingPosition
     * @description Notify DMR about playing position of current audio item.
     * @param milliseconds - number
     * @returns bool
     */
    notifyItemPlayingPosition: function (milliseconds) {
        print(" --->> notify_item_playing_position();");
        return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_item_playing_position", String(milliseconds));
    },
    /**
     * @author yj14.lee@samsung.com
     * @fn notifyPlayingState
     * @description Inform DMR service about player’s state.
     * @param state - enum
     * @returns bool
     */
    notifyPlayingState: function (state) {
        print(" --->> notify_playing_state();");
        return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_playing_state", String(state));
    },
    /**
     * @author yj14.lee@samsung.com
     * @fn notifyStoppedReason
     * @description Inform DMR service about players stopped reason.
     *				Player should use this API if stopped no by DMR’s request e.g. user termination, errors, end of playing activation of other apps.
     *
     * @param reason - enum , details - string
     * @returns bool
     */
    notifyStoppedReason: function (reason, details) {
        print(" --->> notify_stopped_reason();");
        return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_stopped_reason", String(reason), details);
    },

    addEventListener: function (eventType, cb) {
        print("---------------------------------------->> addEventListener");
        DmrAudiocbList[String(eventType)] = cb;
    }
};

var DmrAudiocbList = {};

function DmrAudioCallback(eventType, param1, param2) {
    print("-----------------------> EVENT:[] " + eventType + param1);
    if (typeof DmrAudiocbList[String(eventType)] == "function")
        DmrAudiocbList[String(eventType)](eventType, param1, param2);
}

/**
 * @namespace convertFHD
 */
exports.convertFHD = {

    /**
     * @author sunjung.yoo@samsung.com
     * @fn convertFHD
     * @description Convert resolution 1080p to 720p
     * @param
     * @returns
     */

    convertFHD: function (template) {
        if (true) {
            return;
        }

        var scaleFactor = 720.0 / 1080;
        var convert1080to720 = function (data) {

            if (data.__is_converted__) {
                return;
            }

            function convertInner(child) {
                if (child == null) {
                    return;
                }

                if (typeof child !== "object") {
                    return;
                }

                if (typeof child.length !== "undefined" && child.length > 0) {
                    for (var i = 0; i < child.length; i++) {
                        var data = child[i];
                        if (typeof data === "object") {
                            convertInner(data);
                        }
                    }
                    return;
                }

                for (var prof in child) {
                    var obj = child[prof];
                    if (prof == "x" || prof == "y" || prof == "width" || prof == "height") {
                        child[prof] = parseFloat(child[prof]) * scaleFactor;
                        Log.d("Converted! " + child[prof]);
                    } else if (prof == "font") {
                        var temp = "" + child[prof];
                        var startIndex;
                        var number = "";

                        for (var i = 0; i < temp.length; i++) {
                            if (temp[i] != ' ' && temp[i] >= 0 && temp[i] <= 9) {
                                if (startIndex == undefined) {
                                    startIndex = i;
                                }
                                number = number + temp[i] + "";
                            }
                        }
                        temp = temp.substring(0, startIndex) + (number * scaleFactor) + temp.substring(temp.length - number.length, temp.length);

                        child[prof] = temp;
                        Log.d("Converted! test::" + child[prof]);
                    } else {
                        if (typeof obj === "object") {
                            // object
                            convertInner(obj);
                        }
                    }
                }
            }

            convertInner(data);
            data.__is_converted__ = true;
        }

        convert1080to720(template);
    }
};