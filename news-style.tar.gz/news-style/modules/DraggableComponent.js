//Module global fields
var selectedWidget; //The Widget currently being dragged.
var savedWidgetData = {}; //contains base widget data that has to be temporarily overwritten

//Constructor
function DraggableComponent(options){
    var widget;
    if (options.widget) {
        widget = options.widget;
    } else {
        widget = new Widget(options);
    }

	widget.onDrag = options.onDrag || null;
	widget.onDragStart = options.onDragStart || null;
	widget.onDrop = options.onDrop || null;
	widget.dragAnchor = options.dragAnchor || {x: 0, y:0};

	widget.addEventListener("onMouseDown", onMouseDown);

	return widget;
}

//Events:

function onMouseDown(widget, event){
	Volt.log('################### onMouseDown')
	Volt.err(widget)
	selectedWidget = widget;
}

function onGlobalMouseUp(widget, event){
	if(selectedWidget && selectedWidget.isDragging){
		if(selectedWidget.onDrop)
			selectedWidget.onDrop(selectedWidget, event);

		selectedWidget.isDragging = false;
		restoreWidgetData(selectedWidget);
		selectedWidget = null;
	}

	//TODO: Check for valid drop, or send widget back to starting point
}

function onGlobalMouseMove(widget, event) {
	if(selectedWidget && selectedWidget) {
		//Drag Start
		if(!selectedWidget.isDragging) 
		{
			selectedWidget.isDragging = true;
			saveWidgetData(selectedWidget);
			if(selectedWidget.onDragStart)
				selectedWidget.onDragStart(selectedWidget, event);
		}

		//Dragging
		var onDragReturn;
		if(selectedWidget.onDrag)
			onDragReturn = selectedWidget.onDrag(selectedWidget, event);

		if(onDragReturn !== false)
		{
			//var localCoords = getWidgetLocalCoordinates(event.coordinates, selectedWidget);
			selectedWidget.x = event.coordinates.x;
	      	selectedWidget.y = event.coordinates.y;
     	}

	}
}

scene.addEventListener("OnMouseUp", onGlobalMouseUp);
scene.addEventListener("OnMouseMove", onGlobalMouseMove);

/*function getWidgetLocalCoordinates(point, widget) {
	if(widget == scene) return point;

	while(widget.parent != scene && widget.parent != null) 
	{
		var parent = widget.parent;
		point.x += parent.x;
		point.y += parent.y;
		point.x += parent.width * widget.origin.x;
		point.y += parent.height * widget.origin.y;
		widget = widget.parent;
	}
	point.x += widget.parent.width * widget.origin.x;
	point.y += widget.parent.height * widget.origin.y;

	return point;
}*/

//Module internal functions
function saveWidgetData(widget) {
	savedWidgetData.anchor = widget.anchor;
	savedWidgetData.origin = widget.origin;

	widget.anchor = widget.dragAnchor;
	//widget.animate("anchor", widget.dragAnchor, 1000); //TODO: This only works once strangly...
	widget.origin = 0;
}

function restoreWidgetData(widget) {
	widget.anchor = savedWidgetData.anchor;
	widget.origin = savedWidgetData.origin;
}


//End
exports = DraggableComponent;
