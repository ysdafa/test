var qwerty = [
	[ "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=" ],
	[ "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "\\" ],
	[ "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'"],
	[ "z", "x", "c", "v", "b", "n", "m", ",", ".", "/"],
	[ "[shift]", "[sp]", "[del]", "[clear]", "[enter]" ]
];

var QWERTY = [
	[ "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "+" ],
	[ "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "{", "}", "|" ],
	[ "A", "S", "D", "F", "G", "H", "J", "K", "L", ":", "\""],
	[ "Z", "X", "C", "V", "B", "N", "M", "<", ">", "?"],
	[ "[shift]", "[sp]", "[del]", "[clear]", "[enter]" ]
];

var selectedColor = { r:255, g:255, b:255, a:255 };
var unselectedColor = { r:128, g:128, b:128, a:255 };

var KeyboardComponent = function(options){
	var keyboardWidget = new ListWidget({
		x: 0,
		y: 0,
		width: scene.width,
		height: scene.height,
		orientation: "vertical",
		spacing: 10,
		color: {r: 25, g: 25, b: 25, a: 250},
		parent: scene
	}),
	keyboardRows = qwerty;

	options = options || {};

	keyboardWidget.y = -1 * scene.height; /* off-screen */
	keyboardWidget.keyRowWidgets = [];

  var topPadding = new Widget({
    width: scene.width / 1.5,
    height: 48,
    color: { r:0, g:0, b:0, a:0 }
  });
  var textBg = new Widget({
    width: scene.width / 1.5,
    height: 48,
    color: { r:255, g:255, b:255 }
  });
  var textField = new TextWidget({
    width: textBg.width,
    height: textBg.height,
    color: { r:0, g:0, b:0 },
    font: "Helvetica 35px",
  });
  var midPadding = new Widget({
    width: scene.width / 1.5,
    height: 48,
    color: { r:0, g:0, b:0, a:0 }
  });
  textBg.addChild(textField);
  keyboardWidget.addChild(topPadding);
  keyboardWidget.addChild(textBg);
  keyboardWidget.addChild(midPadding);

	for (var i = 0; i < keyboardRows.length; i++){
		keyboardWidget.keyRowWidgets.push({
			rowWidget: new ListWidget({
				width: 500,
				height: 50,
				color: {r: 0, g: 0, b: 0, a: 0},
				spacing: 8
			}),
			keyWidgets: []
		});
		for (var j = 0; j < keyboardRows[i].length; j++){
			var widthModifyer = keyboardRows[i][j].length * 10;
			keyboardWidget.keyRowWidgets[i].keyWidgets.push(new TextWidget({
				text: keyboardRows[i][j],
				font: "Helvetica 35px",
				width: 29 + widthModifyer,
				color: unselectedColor
			}));
			keyboardWidget.keyRowWidgets[i].rowWidget.addChild(keyboardWidget.keyRowWidgets[i].keyWidgets[j]);
		}
		keyboardWidget.addChild(keyboardWidget.keyRowWidgets[i].rowWidget);
	}

	keyboardWidget.selectedIndex = {
		x:0,
		y:0
	};

	keyboardWidget.highlightSelected = highlightSelected;
	keyboardWidget.unhighlightSelected = unhighlightSelected;
	keyboardWidget.isComponent = true;
	keyboardWidget.handleKey = handleKey;
	keyboardWidget.showKeyboard = showKeyboard;
	keyboardWidget.hideKeyboard = hideKeyboard;
	keyboardWidget.onEnterCallback = options.onEnterCallback;
	keyboardWidget.onEnterCallbackArg = options.onEnterCallbackArg;
	keyboardWidget.visible = false;
	keyboardWidget.textField = textField;

	keyboardWidget.highlightSelected();

	return keyboardWidget;
};

var highlightSelected = function(){
	this.keyRowWidgets[this.selectedIndex.y].keyWidgets[this.selectedIndex.x].animate("scale.x", 1.3, 250);
	this.keyRowWidgets[this.selectedIndex.y].keyWidgets[this.selectedIndex.x].animate("scale.y", 1.3, 250);
	this.keyRowWidgets[this.selectedIndex.y].keyWidgets[this.selectedIndex.x].color = selectedColor;
};

var unhighlightSelected = function(){
	this.keyRowWidgets[this.selectedIndex.y].keyWidgets[this.selectedIndex.x].animate("scale.x", 1, 250);
	this.keyRowWidgets[this.selectedIndex.y].keyWidgets[this.selectedIndex.x].animate("scale.y", 1, 250);
	this.keyRowWidgets[this.selectedIndex.y].keyWidgets[this.selectedIndex.x].color = unselectedColor;
};

var showKeyboard = function(textWidget){
	this.visible = true;
	this.textWidget = textWidget;
  this.textField.text = this.textWidget.text;
  this.animate("y", 0, 250, "bounce-out");
};

var hideKeyboard = function(){
  this.animate("y", -1 * scene.height, 250, "bounce-in");
	this.visible = false;
	this.textWidget = null;
};

var keyHandler = {
	left: function(){	
		this.unhighlightSelected();
		if (this.selectedIndex.x > 0){
			this.selectedIndex.x--;
			this.highlightSelected();
		}else{
			this.selectedIndex.x = this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1;
			this.highlightSelected();
		}
	},
	right: function(){
		this.unhighlightSelected();
		if (this.selectedIndex.x < this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1){
			this.selectedIndex.x++;
			this.highlightSelected();
		}else{
			this.selectedIndex.x = 0;
			this.highlightSelected();
		}
	},
	up: function(){
		this.unhighlightSelected();
		if (this.selectedIndex.y > 0){
			this.selectedIndex.y--;
			if (this.selectedIndex.x > this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1){
				this.selectedIndex.x = this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1;
			}
			this.highlightSelected();
		}else{
			this.selectedIndex.y = this.keyRowWidgets.length - 1;
			if (this.selectedIndex.x > this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1){
				this.selectedIndex.x = this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1;
			}
			this.highlightSelected();
		}
	},
	down: function(){
		this.unhighlightSelected();
		if (this.selectedIndex.y < this.keyRowWidgets.length - 1){
			this.selectedIndex.y++;
			if (this.selectedIndex.x > this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1){
				this.selectedIndex.x = this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1;
			}
			this.highlightSelected();
		}
		else{
			this.selectedIndex.y = 0;
			if (this.selectedIndex.x > this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1){
				this.selectedIndex.x = this.keyRowWidgets[this.selectedIndex.y].keyWidgets.length - 1;
			}
			this.highlightSelected();
		}
	},
	select: function(){
		var selectedKey = this.keyRowWidgets[this.selectedIndex.y].keyWidgets[this.selectedIndex.x].text;
		print(selectedKey);
		switch(selectedKey)
		{
		case "[shift]": 
			toggleShift.call(this);
			break;
		case "[sp]": 
			this.textWidget.text += " "; 
			this.textField.text = this.textWidget.text;
			break;
		case "[del]": 
			this.textWidget.text = this.textWidget.text.slice(0, -1); 
			this.textField.text = this.textWidget.text;
			break;
		case "[clear]": 
			this.textWidget.text = "";  
			this.textField.text = this.textWidget.text;
			break;
		case "[enter]":
      if (this.onEnterCallback) this.onEnterCallback(this.onEnterCallbackArg);
			this.hideKeyboard();
			break;
		default:
			this.textWidget.text += selectedKey;
			this.textField.text = this.textWidget.text;
		}
	},
	focus: function(){
	}
};

var toggleShift = function()
{
  var keyboard = null;
  for (var row = 0; row < this.keyRowWidgets.length; row++)
  {
    var rowWidget = this.keyRowWidgets[row].rowWidget;
    for (var col = 0; col < rowWidget.getChildCount(); col++)
    {
      if (row === 0 && col === 0)
      {
        var top_left_char = rowWidget.getChild(col).text;
        if (top_left_char === "1")
        {
          keyboard = QWERTY;
        }
        else if (top_left_char === "!")
        {
          keyboard = qwerty;
        }
        else
        {
          /* Not a qwerty keyboard; do nothing */
          return;
        }
      }

      rowWidget.getChild(col).text = keyboard[row][col];
    }
  }
};

var handleKey = function(key){
	return keyHandler[key].call(this, key);
};

exports = KeyboardComponent;
