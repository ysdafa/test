/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of PinPopup
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
const ControlBase = Volt.require("modules/UIElement/ControlBase.js");
const Button_Generic = Volt.require("modules/UIElement/Button_Generic.js");
const InputBox = Volt.require("modules/UIElement/InputBox.js");


var setTimeout=function(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
};

var clearTimeout=function (id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
};

/**
 * Class PinPopup.
class
 * @constructor
 * @extends UIElement/ControlBase UIElement/Button_Generic UIElement/InputBox
 */
PinPopup = function() {
	//variable
	var sceWidth = scene.width;
	var sceHeight = scene.height;
	this.PopupBGWidget = null;
	this.focusIndex = 0;
	this.pinCount=0;
	this.buttonCount = 0;
	this.buttonList = [];
	this.pinBoxList=[];
	this.pinTextList=[];
	this.bgWidth=sceWidth;
	this.bgColor={r:10,g:93,b:136,a:255};//0a5d88
	this.bgOpacity=0.85*255;
	this.pinMessage="";
	this.pinTitle="";
	this.pinText="";
	this.messageWidth=sceWidth*0.584375;
	this.messageFont="Samsung SVD_Light 34px";
	this.messageHeight=sceHeight*0.044444;
	//this.messageLineSpace=14;
	this.messageOpacity=0.9*255;
	this.messageTextColor={r:255,g:255,b:255,a:255*0.9};//ffffffff
	this.messageBgColor={r:69,g:187,b:163,a:255};//45bba3
	this.messagePositionX=sceWidth/2*(1-0.584375);
	this.messagePositionY=sceHeight*(0.088889+0.010185);
	this.messageVerticalAlignment="center";
	this.messageHorizontalAlignment="center";
	this.messageInstance=null;
	this.pinTitleInstance=null;
	this.focus=false;
	this.isCreate=false;
	this.pinTitleFont="Samsung SVD_Light 46px";
	this.pinTitleTextColor={r:255,g:255,b:255,a:255};//ffffffff
	this.pinTitleHeight=0.088889*sceHeight;
	this.pinTitlePositionY=0;
	this.pinTitleVerticalAlignment="center";
	this.pinTitleHorizontalAlignment="center";
	this.pinTextFont="Samsung SVD_Light 34px";
	this.pinTextTextColor={r:255,g:255,b:255,a:255*0.85};//ffffffff
	this.pinTextVerticalAlignment="center";
	this.pinTextHorizontalAlignment="center";
	this.buttonPositionXList=[825,684,543,402];
	this.pinBoxPositionX=(1-0.181771)*sceWidth*0.5;
	this.pinTextHeight=0.044444*sceHeight;
	this.pinBoxWidth=0.181771*sceWidth;
	this.pinBoxHeight=0.053704*sceHeight;
	this.pinBoxPositionY=(0.053704*sceHeight-6)*0.5;
	this.pinBoxText="";
	this.pinBoxTextFont="Samsung SVD_Light 30px";
	this.pinBoxTextVerticalAlignment="center";
	this.pinBoxTextHorizontalAlignment="center";
	this.pinBoxStyle=InputBox.Style.PIN;
	this.pinBoxBgSrc={};
	this.pinImgSrc={};
	this.pinBoxTextTextColor={};
	this.pinImgWidth={};
	this.pinImgHeight={};
	this.buttonCallbackList=[];
	this.mouseOverCallBack=null;
	this.mouseOutCallBack=null;
	this.buttonWidth = 270;
	this.buttonHeight = 66;
	this.returnKeyCallback=null;
	this.timer=null;
	this.timeOutCallBack=null;
	this.timeOutTime=10000;
	this.inputDoneCallback=null;
	this.buttonPositionY=(0.491667-0.027778-0.061111)*sceHeight;
	this.BbgHeight=0.491667*sceHeight;
	this.BPinTitlePositionX=(1-0.407292)*sceWidth*0.5;
	this.BPinTextPositionX=(1-0.407292)*sceWidth*0.5;
	this.BPinTextPositionYList=[(0.088889+0.02963)*sceHeight,(0.088889+0.044444+0.02963+0.017593+0.053704+0.018519)*sceHeight];
	this.BPinBoxPositionYList=[(0.088889+0.044444+0.02963+0.017593)*sceHeight,(0.088889+0.044444*2+0.02963+0.017593+0.053704+0.018519+0.016667)*sceHeight];
	this.BPinTextWidth=0.407292*sceWidth;
	this.BPinTitleWidth=0.407292*sceWidth;
	
	this.MbgHeight=sceHeight*0.5;
	this.MPinTitlePositionX=(1-0.584375)*sceWidth*0.5;
	this.MPinTextPositionYList=[sceHeight*(0.088889+0.010185+2*0.044444),sceHeight*(0.088889+0.010185+3*0.044444+0.014815+0.053704+0.025926)];
	this.MPinBoxPositionYList=[sceHeight*(0.088889+0.010185+3*0.044444+0.014815),sceHeight*(0.088889+0.010185+4*0.044444+0.014815*2+0.053704+0.025926)];
	this.MPinTextPositionX=(1-0.584375)*sceWidth*0.5;
	this.MPinTitleWidth=0.584375*sceWidth;
	this.MPinTextWidth=0.584375*sceWidth;
	
	this.bgHeight=this.MbgHeight;
	this.pinTitlePositionX=this.MPinTitlePositionX;
	this.pinTextPositionX=this.MPinTextPositionX;
	this.pinTextPositionYList=this.MPinTextPositionYList;
	this.pinBoxPositionYList=this.MPinBoxPositionYList;
	this.pinTextWidth=this.MPinTextWidth;
	this.pinTitleWidth=this.MPinTitleWidth;
	this.inputMaxLength = 4;
	this.pinDotGap = scene.width * 0.016666;
	this.pinImg_x = (this.pinBoxWidth-36-this.pinDotGap *3)*0.5;
	this.pinImg_y = 0;
	this.pinBoxTextX = scene.width*0.008333;
	this.pinBoxTextY = 0;
	this.pinBoxTextWidth = this.pinBoxWidth - scene.width*0.008333*2;
	this.pinBoxTextHeight =this.pinBoxHeight;
	this.openOverout=false;
	this.openClick=false;
	this.openUpdown=false;
	
	/**
	* This function will create a PinPopup<p>
	* This function will create a PinPopup,You can use this function when you want to create an PinPopup Object.
	* @param {Object} param of the new PinPopup you want to create.
	* @return {Object} return the new PinPopup object you want to create.
	* @example //This example create a new PinPopup.
	* const script_AID = "UIElement/PinPopup";
	* const PinPopup = require(script_AID);
	* PopupIns = new PinPopup(); 
	* PopupIns.create({x:0, y:200, width:1800, height:600, opacity:255, bgSrc:"button/btn_dim.png", parent:scene});
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("width")){
			this.bgWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.bgHeight=obj.height;
		}
		if(obj.hasOwnProperty("color")){
			this.bgColor=obj.color;
		}
		
		if(obj.hasOwnProperty("opacity")){
			this.bgOpacity=obj.opacity;
		}
		this.PopupBGWidget = new ImageWidget({
			width : this.bgWidth,
			//height : this.bgHeight,
			height : this.bgHeight,
			color : {r:10,g:93,b:136,a:0},
			parent : obj.parent
		});
		if(obj.hasOwnProperty("bgsrc")){
			if ("string"== typeof(obj.bgsrc)){
				this.PopupBGWidget.src=obj.bgsrc;
			}
		}
		else{
			this.PopupBGWidget.color=this.bgColor;
		}
		this.PopupBGWidget.opacity=this.bgOpacity;
		this.PopupBGWidget.hide();
		this.initx=this.rootWidget.getAbsolutePosition().x;
		this.inity=this.rootWidget.getAbsolutePosition().y;
		this.isCreate=true;
	};
	
	this.t_destroy = function() {
		this.focusIndex = 0;
		if(this.timer!=null){
			clearTimeout(this.timer);
			this.timer=null;
		}
		delete this.t_buttonClickCallbackBind;
		delete this.m_buttonMouseOverCallBackBind;			
		delete this.m_buttonMouseOutCallBackBind;
		delete this.t_pinPopupMouseOverBind;
		delete this.t_pinPopupMouseOutBind;
		var num=this.pinTextList.length;
		if(num!=0){
			for(var i=num-1;i>=0;i--){
				this.pinTextList[i].destroy();
				this.pinBoxList[i].destroy();
			}
			this.pinTextList.splice(0, this.pinTextList.length);
			this.pinBoxList.splice(0, this.pinBoxList.length);
			this.pinTextList = null;
			this.pinBoxList = null;
		}
		var num1=this.buttonList.length;
		if(num1!=0){
			for(var i=num1-1;i>=0;i--){
				this.buttonList[i].destroy();
			}
			this.buttonList.splice(0, this.buttonList.length);
			this.buttonList = null;
		}
		this.buttonCallbackList.splice(0, this.buttonCallbackList.length);
		this.buttonCallbackList = null;
		if(this.pinTitleInstance != null){
			this.pinTitleInstance.destroy();
			this.pinTitleInstance = null;
			this.lineInstance.destroy();
			this.lineInstance = null;
		}
		if(this.messageInstance != null){
			this.messageInstance.destroy();
			this.messageInstance = null;
		}
		if(this.PopupBGWidget != null){
			this.PopupBGWidget.destroy();
			this.PopupBGWidget = null;
		}
	};
	
	this.t_show = function() {
		this.PopupBGWidget.show();
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	this.t_hide = function() {
		this.PopupBGWidget.hide();
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		if(this.isCreated == false) {
			return false;
		}
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}
		var	count=this.pinCount+this.buttonCount;
		var bRet = false;
		switch(keycode) {
			case Volt.KEY_JOYSTICK_RIGHT:
				if(this.focusIndex < this.buttonCount-1) {
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex++;
					this.buttonList[this.focusIndex].getFocus();
					bRet = true;
				}
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				if(this.focusIndex > 0&&this.focusIndex < this.buttonCount) {
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex--;
					this.buttonList[this.focusIndex].getFocus();
					bRet = true;
				}
				break;
			case Volt.KEY_JOYSTICK_OK:
				if(this.focusIndex >= 0&&this.focusIndex < this.buttonCount) {
					this.buttonList[this.focusIndex].keyHandler(keycode,keytype);
					bRet = true;
				}
								
				break;
			case Volt.KEY_RETURN:
				if(this.returnKeyCallback!=null){
					this.returnKeyCallback();
				}
				bRet = true;			
			break;
			case Volt.KEY_JOYSTICK_UP:
				if((this.focusIndex >= 0) && (this.focusIndex < this.buttonCount)) {
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex=count-1;
					this.pinBoxList[this.focusIndex-this.buttonCount].getFocus();
					bRet = true;
				}
				else if((this.focusIndex > this.buttonCount) && (this.focusIndex < count)) {
					this.pinBoxList[this.focusIndex-this.buttonCount].loseFocus();
					this.focusIndex--;
					this.pinBoxList[this.focusIndex-this.buttonCount].getFocus();
					bRet = true;
				}
				else{
				
				}
			break;
			case Volt.KEY_JOYSTICK_DOWN:
				if((this.focusIndex >= this.buttonCount) && (this.focusIndex < count-1)) {
					this.pinBoxList[this.focusIndex - this.buttonCount].loseFocus();
					this.focusIndex++;
					this.pinBoxList[this.focusIndex - this.buttonCount].getFocus();
					bRet = true;
				}
				else if(this.focusIndex == count-1){
					if(this.buttonCount!=0){
						this.pinBoxList[this.focusIndex - this.buttonCount].loseFocus();
						this.focusIndex=0;
						this.buttonList[this.focusIndex].getFocus();
						bRet = true;
					}
				}
				else{
				}
			break;
			case Volt.KEY_0:
			case Volt.KEY_1:
			case Volt.KEY_2:
			case Volt.KEY_3:
			case Volt.KEY_4:
			case Volt.KEY_5:
			case Volt.KEY_6:
			case Volt.KEY_7:
			case Volt.KEY_8:
			case Volt.KEY_9:
				if(this.focusIndex >= this.buttonCount&& this.focusIndex < count) {
					bRet = this.pinBoxList[this.focusIndex-this.buttonCount].keyHandler(keycode,keytype);
				}
			break;	
			default:
				break;
		}
		if(bRet == true){
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
		return bRet;
	};
	
	 /**
	* This function will set return key callback function of PinPopup created<p>
	* This function will set return key callback function of PinPopup created,You can use this function when you want to set return key callback.
	* @param {Function} callback function called when press return key.
	* @return {Void}
	* @example //This example set return key callback.
	* var okcallback=function(){
		  textwidget.text="ok";
	  };
	* PopupIns.setReturnKeyCallBack(okcallback);
	* @since The version 1.0 this function is added.
	*/
	this.setReturnKeyCallBack=function(callback){
		if(true == this.isCreate){
			this.returnKeyCallback=callback;
		}
	};
	
	/**
	* This function will set time out property of PinPopup created<p>
	* This function will set time out property of PinPopup created,You can use this function when you want to use time out.
	* @param {Object} param of time out you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set time out property.
	* var outcallback=function(){
		PopupIns.hide();
	  };
	* PopupIns.startTimeOut({callback:outcallback});
	* @since The version 1.0 this function is added.
	*/
	this.startTimeOut=function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("time")){
			this.timeOutTime=obj.time;
		}
		if(obj.hasOwnProperty("callback")){
			this.timeOutCallBack=obj.callback;
		}
		if(this.timeOutCallBack!=null){
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	 /**
	* This function will set title property of PinPopup created<p>
	* This function will set title property of PinPopup created,You can use this function when you want to set title.
	* @param {Object} param of title property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set title property.
	* PopupIns.setTitle({x:700, 
						 y:10,
						 width:300, 
						 height:100, 
						 textColor:color1, 
						 font:"45px", 
						 verticalAlignment:"top", 
						 horizontalAlignment:"center", 
						 bgColor:color2,
						 titleOpacity:25, 
						 title:"Popup Message"});
	* @since The version 1.0 this function is added.
	*/
	this.setTitle=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.pinTitlePositionX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.pinTitlePositionY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.pinTitleWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.pinTitleHeight=obj.height;
		}
		if(obj.hasOwnProperty("textcolor")){
			this.pinTitleTextColor=obj.textcolor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.pinTitleFont=obj.font;
			}	
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			this.pinTitleVerticalAlignment=obj.VerticalAlignment;
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			this.pinTitleHorizontalAlignment=obj.HorizontalAlignment;
		}
		if(obj.hasOwnProperty("title")){
			if ("string" == typeof(obj.title)){
				this.pinTitle=obj.title;
			}
		}
		if(this.pinTitleInstance==null){		
			this.pinTitleInstance = new TextWidget({
				parent : this.PopupBGWidget
			});
			this.lineInstance = new Widget({
				height : 1,
				parent : this.PopupBGWidget
			});
		}
		this.pinTitleInstance.x=this.pinTitlePositionX;
		this.pinTitleInstance.y=this.pinTitlePositionY;
		this.pinTitleInstance.width=this.pinTitleWidth;
		this.pinTitleInstance.height=this.pinTitleHeight;
		this.pinTitleInstance.font=this.pinTitleFont;
		this.pinTitleInstance.horizontalAlignment=this.pinTitleHorizontalAlignment;
		this.pinTitleInstance.verticalAlignment=this.pinTitleVerticalAlignment;
		this.pinTitleInstance.text=this.pinTitle;
		this.pinTitleInstance.textColor=this.pinTitleTextColor;
		this.lineInstance.x=this.pinTitlePositionX;
		this.lineInstance.y=this.pinTitlePositionY+this.pinTitleHeight;
		this.lineInstance.width=this.pinTitleWidth;
		this.lineInstance.color=this.pinTitleTextColor;
		if(obj.hasOwnProperty("titleopacity")){
			this.pinTitleInstance.opacity=obj.titleopacity;
		}
		if(obj.hasOwnProperty("bgColor")){
			this.pinTitleInstance.color=obj.bgColor;
		}
		this.lineInstance.opacity=0.2*255;
		return true;
	};
	
	 /**
	* This function will set message property of PinPopup created<p>
	* This function will set message property of PinPopup created,You can use this function when you want to set message.
	* @param {Object} param of message property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set message property.
	* PopupIns.setMessage({x:100, 
						   y:100,
						   width:1000,
						   height:200, 
						   textColor:color1, 
						   font:"20px", 
						   verticalAlignment:"top", 
						   horizontalAlignment:"center", 
						   bgColor:color2, 
						   opacity:22, 
						   message:tmpStr});
	* @since The version 1.0 this function is added.
	*/
	this.setMessage=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.messagePositionX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.messagePositionY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.messageWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.messageHeight=obj.height;
		}
		if(obj.hasOwnProperty("textcolor")){
			this.messageTextColor=obj.textcolor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.messageFont=obj.font;
			}
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			this.messageVerticalAlignment=obj.VerticalAlignment;
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			this.messageHorizontalAlignment=obj.HorizontalAlignment;
		}
		if(obj.hasOwnProperty("bgcolor")){
			this.messageBgColor=obj.bgcolor;
		}
		if(obj.hasOwnProperty("opacity")){
			this.messageOpacity=obj.opacity;
		}
		if(obj.hasOwnProperty("message")){
			if ("string"== typeof(obj.message)){
				this.pinMessage=obj.message;
			}
		}
		if(this.messageInstance==null){
			this.messageInstance = new TextWidget({
				parent : this.PopupBGWidget
			});
		}
		this.messageInstance.x=this.messagePositionX;
		this.messageInstance.y=this.messagePositionY;
		this.messageInstance.width=this.messageWidth;
		this.messageInstance.height=this.messageHeight;
		this.messageInstance.font=this.messageFont;
		this.messageInstance.horizontalAlignment=this.messageHorizontalAlignment;
		this.messageInstance.verticalAlignment=this.messageVerticalAlignment;
		this.messageInstance.text=this.pinMessage;
		this.messageInstance.textColor=this.messageTextColor;
		this.messageInstance.opacity=this.messageOpacity;	
		return true;
	};
	
	 /**
	* This function will set button property of PinPopup created<p>
	* This function will set button property of PinPopup created,You can use this function when you want to set button.
	* @param {Object} param of button property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set button property.
	* var okcallback=function(){
		textwidget.text="ok";
	 };
	* var cancelcallback=function(){
		textwidget.text="cancel";
	  };
	* var buttonProperty =[{x:100, 
						y:300, 
						width:100,
						height:100,
						buttonborder:{normal:{width:1, color:{r:255, g:25, b:25, a:52}},
									  focus:{width:5, color:{r:15, g:255, b:25, a:52}},
									  selected:{width:10, color:{r:55, g:255, b:255, a:52}}},
						buttontextfont:{normal:"20px",focus:"30px", selected:"35px"},
						buttontextcolor:{normal:color1,focus:color2, selected:color3}, 
						buttontextVerticalAlignment:"center", 
						buttontextHorizontalAlignment:"center", 
						buttontext:{normal:"ok",focus:"ok111", selected:"ok222"}, 
						buttonimage:{normal:"button/btn_dim.png",focus:"button/btn_focused.png", selected:"button/wizard_btn_sel.png"}, 
						callbackfunction:okcallback},
					   {x:1000, 
						y:300 , 
						width:200, 
						height:100,
						buttonborder:{normal:{width:1, color:{r:255, g:25, b:25, a:52}},
									  focus:{width:5, color:{r:15, g:255, b:25, a:52}},
									  selected:{width:10, color:{r:55, g:255, b:255, a:52}}},
						buttontextfont:{normal:"20px",focus:"30px", selected:"35px"},
						buttontextcolor:{normal:color1,focus:color2, selected:color3}, 
						buttontextVerticalAlignment:"center", 
						buttontextHorizontalAlignment:"center", 
						buttontext:{normal:"cancel",focus:"cancel111", selected:"cancel222"}, 
						buttonimage:{normal:"button/btn_dim.png",focus:"button/btn_focused.png", selected:"button/wizard_btn_sel.png"},
						callbackfunction:cancelcallback}];	 
	* PopupIns.setButton(buttonProperty);
	* @since The version 1.0 this function is added.
	*/
	this.setButton = function(buttonPropertyobj) {
		if(false == this.isCreate){
			return false;
		}
		if(buttonPropertyobj == null||typeof(buttonPropertyobj) == "undefined"){
			return false;
		}
		var buttonCount=buttonPropertyobj.length;
		if(buttonCount > 0) {
			var firstset=true;
			this.buttonCount = buttonCount;
			this.buttonPositionX = this.buttonPositionXList[buttonCount-1];
			var buttonpositionx = 0;
			//var buttonpositiony = 0;
			var num=this.buttonList.length;
			if(num!=0){
				for(var i=num-1;i>=0;i--){
					this.buttonList[i].destroy();
				}
				this.buttonList.splice(0, this.buttonList.length);
			}
			for(var index = 0; index < buttonCount; index++) {
				var tempButton = new Button_Generic();
				this.buttonList.push(tempButton);
				if(buttonPropertyobj[index].hasOwnProperty("x")){
					buttonpositionx=buttonPropertyobj[index].x;
				}
				else {
					buttonpositionx=this.buttonPositionX+282*index;
				}
				if(buttonPropertyobj[index].hasOwnProperty("y")){
					this.buttonPositionY=buttonPropertyobj[index].y;
				}
				if(buttonPropertyobj[index].hasOwnProperty("width")){
					this.buttonWidth=buttonPropertyobj[index].width;
				}
				if(buttonPropertyobj[index].hasOwnProperty("height")){
					this.buttonHeight=buttonPropertyobj[index].height;
				}
				
				this.buttonList[index].create({
					x : buttonpositionx,
					y : this.buttonPositionY,
					width : this.buttonWidth,
					height : this.buttonHeight,
					parent:this.PopupBGWidget
				});
				if(buttonPropertyobj[index].hasOwnProperty("buttonborder")){
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("normal")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonborder.normal);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("focus")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonborder.focus);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("selected")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonborder.selected);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("dim")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonborder.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextcolor")){
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("normal")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontextcolor.normal);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("focus")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontextcolor.focus);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("selected")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontextcolor.selected);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("dim")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontextcolor.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextfont")){
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.normal)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontextfont.normal);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.focus)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontextfont.focus);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.selected)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontextfont.selected);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.dim)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontextfont.dim);
						}
					}
				}
				
				if(buttonPropertyobj[index].hasOwnProperty("buttontextVerticalAlignment")){
					this.buttonList[index].setTextVerticalAlignment(buttonPropertyobj[index].buttontextVerticalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextHorizontalAlignment")){
					this.buttonList[index].setTextHorizontalAlignment(buttonPropertyobj[index].buttontextHorizontalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontext")){
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.normal)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontext.normal);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.focus)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontext.focus);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.selected)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontext.selected);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.dim)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontext.dim);
						}
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonimage")){
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("normal")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonimage.normal);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("focus")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonimage.focus);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("selected")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonimage.selected);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("dim")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonimage.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("callbackfunction")){
					if(firstset == true){
						this.buttonCallbackList.splice(0, this.buttonCallbackList.length);
						firstset=false;
					}
					this.buttonCallbackList[index]=buttonPropertyobj[index].callbackfunction;
					this.buttonList[index].setMouseClickCallback(this.t_buttonClickCallbackBind);
				}
				this.buttonList[index].index=index;
				this.buttonList[index].setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind,
																outCallback:this.m_buttonMouseOutCallBackBind});
				this.buttonList[index].show();			
			}
			if(this.focus==true){
				if(this.focusIndex<buttonCount)
				{
					this.buttonList[this.focusIndex].getFocus();
				}
				
			}
			if(this.pinCount==2){
				var gap=this.bgHeight-this.MbgHeight;
				if(gap==0){
					this.bgHeight=this.BbgHeight;
					this.PopupBGWidget.height=this.bgHeight;
				}
				if(this.pinTitleInstance==null){
					this.pinTitlePositionX=this.BPinTitlePositionX;
					this.pinTitleWidth=this.BPinTitleWidth;
				}
				else{
					gap=this.pinTitleInstance.x-this.MPinTitlePositionX;
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinTitlePositionX=this.BPinTitlePositionX;
						this.pinTitleInstance.x=this.pinTitlePositionX;
					}
					gap=this.pinTitleInstance.width-this.MPinTitleWidth;
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinTitleWidth=this.BPinTitleWidth;
						this.pinTitleInstance.width=this.pinTitleWidth;
					}
				}
				for(var i = 0; i < 2; i++) {
					gap=this.pinTextList[i].x - this.MPinTextPositionX;
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinTextPositionX=this.BPinTextPositionX;
						this.pinTextList[i].x=this.pinTextPositionX;
					}
					gap=this.pinTextList[i].y - this.MPinTextPositionYList[i];
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinTextPositionYList[i]=this.BPinTextPositionYList[i];
						this.pinTextList[i].y=this.pinTextPositionYList[i];
					}
					gap=this.pinBoxList[i].y-this.MPinBoxPositionYList[i];
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinBoxPositionYList=this.BPinBoxPositionYList;
						this.pinBoxList[i].y=this.pinBoxPositionYList[i];
					}
					gap=this.pinTextList[i].width-this.MPinTextWidth;
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinTextWidth=this.BPinTextWidth;
						this.pinTextList[i].width=this.pinTextWidth;
					}
				}
				
				
			}
			else if(this.pinCount == 0){
				var gap=this.bgHeight-this.MbgHeight;
				if(gap==0){
					this.bgHeight=this.BbgHeight;
					this.PopupBGWidget.height=this.bgHeight;
				}
				if(this.pinTitleInstance==null){
					this.pinTitlePositionX=this.BPinTitlePositionX;
					this.pinTitleWidth=this.BPinTitleWidth;
				}
				else{
					gap=this.pinTitleInstance.x-this.MPinTitlePositionX;
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinTitlePositionX=this.BPinTitlePositionX;
						this.pinTitleInstance.x=this.pinTitlePositionX;
					}
					gap=this.pinTitleInstance.width-this.MPinTitleWidth;
					if((gap<=0.001)&&(gap>=-0.001)){
						this.pinTitleWidth=this.BPinTitleWidth;
						this.pinTitleInstance.width=this.pinTitleWidth;
					}
				}
				this.pinTextPositionX=this.BPinTextPositionX;
				this.pinTextPositionYList=this.BPinTextPositionYList;
				this.pinBoxPositionuYList=this.BPinBoxPositionYList;
				this.pinTextWidth=this.BPinTextWidth;
			}
			else{
			}
			return true;
		}
		return false;
	};
	
	 /**
	* This function will set input box property of PinPopup created<p>
	* This function will set input box property of PinPopup created,You can use this function when you want to set input box.
	* @param {Object} param of input box property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set input box property.
	* var inputcallback =function(){
		textwidget.text="pin input done";
	  };	
	* var inputcallback1 =function(){
		textwidget.text="text input done";
	 };	
	* var pinobj=[{text:{x:200, 
					   y:100, 
					   width:100,
					   height:50, 
					   textColor:{r:255},
					   font:"20px",
					   verticalAlignment: "left",
					   horizontalAlignment:"top",
					   text:"pintext1"
					   },
				 box:{x:200, 
					  y:150, 
					  width:100,
					  height:50,
					  style: InputBox.Style.PIN,
					  inputMaxLength:3,
					  PINDotGap:10,
					  PINImgX:10,
					  PINImgY:10,
					  PINImgHeight:{normal:10, focus:15},
					  PINImgWidth:{normal:10, focus:15},
					  bgSrc:{normal:"inputBox/input_box_style_c_f.png", focus:"inputBox/input_box_style_c_f.png"},
					  PINImgsrc:{normal:"inputBox/obe_pin_f.png", focus:"inputBox/obe_pin_n.png"},
					  inputDoneCallback:inputcallback
					}
				},
				{text:{x:200, 
					   y:210, 
					   width:100,
					   height:50, 
					   textColor:{r:255},
					   font:"20px",
					   verticalAlignment: "right",
					   horizontalAlignment:"top",
					   text:"pintext2"
					   },
				 box:{x:200, 
					  y:270, 
					  width:100,
					  height:50,
					  bgSrc:{normal:"inputBox/input_box_style_c_f.png", focus:"inputBox/input_box_style_c_f.png"},
					  text:"abcd",
					  textX:10,
					  textY:10,
					  textWidth:50,
					  textHeight:30,
					  inputMaxLength:5,
					  textColor:{normal:{r:255}, focus:{g:255}, selected:{b:255}, dim:{r:122}},
					  font:"20px",
					  verticalAlignment:"left",
					  horizontalAlignment:"top",
					  style:InputBox.Style.TEXT,
					  inputDoneCallback:inputcallback1
					}
				}];					 
	* PopupIns.setPin(pinobj);
	* @since The version 1.0 this function is added.
	*/
	this.setPin=function(pinobj) {
		if(false == this.isCreate){
			return false;
		}
		if(pinobj == null||typeof(pinobj) == "undefined"){
			return false;
		}
		var pinCount=pinobj.length;
		if(pinCount > 0) {
			this.pinCount = pinCount;
			var num=this.pinTextList.length;
			if(num!=0){
				for(var i=num-1;i>=0;i--){
					this.pinTextList[i].destroy();
					this.pinBoxList[i].destroy();
				}
				this.pinTextList.splice(0, this.pinTextList.length);
				this.pinBoxList.splice(0, this.pinBoxList.length);
			}
			for(var index = 0; index < pinCount; index++) {
				var tempPinText =new TextWidget({
					parent : this.PopupBGWidget
				});
				this.pinTextList.push(tempPinText);
				if(pinobj[index].hasOwnProperty("text")){
					if(pinobj[index].text.hasOwnProperty("text")){
						if ("string"== typeof(pinobj[index].text.text)){
							this.pinText=pinobj[index].text.text;
						}
					}
					if(pinobj[index].text.hasOwnProperty("x")){
						this.pinTextPositionX=pinobj[index].text.x;
					}
					if(pinobj[index].text.hasOwnProperty("y")){
						this.pinTextPositionYList[index]=pinobj[index].text.y;
					}
					if(pinobj[index].text.hasOwnProperty("width")){
						this.pinTextWidth=pinobj[index].text.width;
					}
					if(pinobj[index].text.hasOwnProperty("height")){
						this.pinTextHeight=pinobj[index].text.height;
					}
					if(pinobj[index].text.hasOwnProperty("textcolor")){
						this.pinTextTextColor=pinobj[index].text.textcolor;
					}
					if(pinobj[index].text.hasOwnProperty("font")){
						if ("string"== typeof(pinobj[index].text.font)){
							this.pinTextFont=pinobj[index].text.font;
						}
					}
					if(pinobj[index].text.hasOwnProperty("VerticalAlignment")){
						this.pinTextVerticalAlignment=pinobj[index].text.VerticalAlignment;
					}
					if(pinobj[index].text.hasOwnProperty("HorizontalAlignment")){
						this.pinTextHorizontalAlignment=pinobj[index].text.HorizontalAlignment;
					}
					/*if(pinobj[index].text.hasOwnProperty("bgcolor")){
						this.pinTextBgColor=pinobj[index].text.bgcolor;
					}
					if(pinobj[index].hasOwnProperty("opacity")){
						this.pinTextOpacity=pinobj[index].text.opacity;
					}*/
					this.pinTextList[index].x=this.pinTextPositionX;
					this.pinTextList[index].y=this.MPinTextPositionYList[index];//this.pinTextPositionYList[index];
					this.pinTextList[index].width=this.pinTextWidth;
					this.pinTextList[index].height=this.pinTextHeight;
					this.pinTextList[index].font=this.pinTextFont;
					this.pinTextList[index].horizontalAlignment=this.pinTextHorizontalAlignment;
					this.pinTextList[index].verticalAlignment=this.pinTextVerticalAlignment;
					this.pinTextList[index].text=this.pinText;
					/*this.pinTextList[index].textColor=this.pinTextBgColor;
					this.pinTextList[index].opacity=this.pinTextOpacity;*/	
				}
				if(pinobj[index].hasOwnProperty("box")){
					if(pinobj[index].box.hasOwnProperty("text")){
						if ("string"== typeof(pinobj[index].box.text)){
							this.pinBoxText=pinobj[index].box.text;
						}
					}
					if(pinobj[index].box.hasOwnProperty("x")){
						this.pinBoxPositionX=pinobj[index].box.x;
					}
					if(pinobj[index].box.hasOwnProperty("y")){
						this.pinBoxPositionYList[index]=pinobj[index].box.y;
					}
					if(pinobj[index].box.hasOwnProperty("width")){
						this.pinBoxWidth=pinobj[index].box.width;
					}
					if(pinobj[index].box.hasOwnProperty("height")){
						this.pinBoxHeight=pinobj[index].box.height;
					}
					if(pinobj[index].box.hasOwnProperty("textcolor")){
						//var text = JSON.stringify(pinobj[index].box.textcolor);   // deep copy
						this.pinBoxTextTextColor = pinobj[index].box.textcolor
					}
					if(pinobj[index].box.hasOwnProperty("font")){
						if ("string"== typeof(pinobj[index].box.font)){
							this.pinBoxTextFont=pinobj[index].box.font;
						}
					}
					if(pinobj[index].box.hasOwnProperty("VerticalAlignment")){
						this.pinBoxTextVerticalAlignment=pinobj[index].box.VerticalAlignment;
					}
					if(pinobj[index].box.hasOwnProperty("HorizontalAlignment")){
						this.pinBoxTextHorizontalAlignment=pinobj[index].box.HorizontalAlignment;
					}
					/*if(pinobj[index].box.hasOwnProperty("bgcolor")){
						this.pinTextBgColor=pinobj[index].box.bgcolor;
					}
					if(pinobj[index].box.hasOwnProperty("opacity")){
						this.pinTextOpacity=pinobj[index].box.opacity;
					}*/
					if(pinobj[index].box.hasOwnProperty("bgsrc")){
						this.pinBoxBgSrc=pinobj[index].box.bgsrc;
					}
					if(pinobj[index].box.hasOwnProperty("pinimgsrc")){
						this.pinImgSrc = pinobj[index].box.pinimgsrc
					}
					if(pinobj[index].box.hasOwnProperty("style")){
						this.pinBoxStyle=pinobj[index].box.style;
		
					}
					
					if (pinobj[index].box.hasOwnProperty("inputMaxLength")){
						if(pinobj[index].box.inputMaxLength>0){
							this.inputMaxLength = pinobj[index].box.inputMaxLength;
						}
					}
					
					if (pinobj[index].box.hasOwnProperty("pindotgap")) {
						this.pinDotGap = pinobj[index].box.pindotgap;
					}
					
					/*if (pinobj[index].box.hasOwnProperty("pinimgy")){
						this.pinImg_y = pinobj[index].box.pinimgy;			
					}*/
							
					if (pinobj[index].box.hasOwnProperty("pinimgx")){
						this.pinImg_x = pinobj[index].box.pinimgx			
					}
					if (pinobj[index].box.hasOwnProperty("pinimgwidth")){	
						this.pinImgWidth = pinobj[index].box.pinimgwidth;						
					}
							
					if (pinobj[index].box.hasOwnProperty("pinimgheight")){
						this.pinImgHeight = pinobj[index].box.pinimgheight;		
					}
					if (pinobj[index].box.hasOwnProperty("textx")){
						this.pinBoxTextX= pinobj[index].box.textx;			
					}
					if (pinobj[index].box.hasOwnProperty("texty")){
						this.pinBoxTextY = pinobj[index].box.texty;			
					}
					if (pinobj[index].box.hasOwnProperty("textwidth")){
						this.pinBoxTextWidth = pinobj[index].box.textwidth;			
					}
					if (pinobj[index].box.hasOwnProperty("textheight")){
						this.pinBoxTextHeight = pinobj[index].box.textheight		
					}
					if (pinobj[index].box.hasOwnProperty("inputDoneCallback")){
						this.inputDoneCallback = pinobj[index].box.inputDoneCallback;
					}
					var tempPin = new InputBox();
					this.pinBoxList.push(tempPin);
					
					this.pinBoxList[index].create({x:this.pinBoxPositionX,
												   y:this.pinBoxPositionYList[index],
												   width:this.pinBoxWidth,
												   height:this.pinBoxHeight,
												   parent:this.PopupBGWidget,
											       bgSrc:this.pinBoxBgSrc,
												   text:this.pinBoxText,
											       textColor:this.pinBoxTextTextColor,
												   font:this.pinBoxTextFont,
											       horizontalAlignment:this.pinBoxTextHorizontalAlignment,
												   verticalAlignment:this.pinBoxTextVerticalAlignment,
												   textX:this.pinBoxTextX,
												   textY:this.pinBoxTextY,
												   textWidth:this.pinBoxTextWidth,
												   textHeight:this.pinBoxTextHeight,
												   inputMaxLength:this.inputMaxLength,
												   PINDotGap:this.pinDotGap,
												   PINImgX:this.pinImg_x,
												   PINImgWidth:this.pinImgWidth,
												   PINImgHeight:this.pinImgHeight,
												   PINImgSrc:this.pinImgSrc,
												   Style:this.pinBoxStyle,
												   inputDoneCallback:this.inputDoneCallback
												});
				}
			}
		}
		return true;
	};
	
	this.t_buttonClickCallback=function(widget){
		var index=widget.index;
		if(typeof(this.buttonCallbackList[index]) != "undefined"||this.buttonCallbackList[index]!=null){
			this.buttonCallbackList[index]();
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	this.t_buttonClickCallbackBind=this.t_buttonClickCallback.bind(this);
	
	this.setPinText=function(index,textobj) {
		if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
			this.pinBoxList[index].setTextAttr(textobj);
		}
	};
	
	 /**
	* This function will get input string of input box selected in PinPopup created<p>
	* This function will get input string of input box selected in PinPopup created,You can use this function when you want to get input string of one input box.
	* @param {Number} the index of input box selected.
	* @return {String} return input string of input box selected.
	* @example //This example get input string of input box selected.
	* var txt=PopupIns.getInputPinString(1);
	* textwidget.text=txt;
	* @since The version 1.0 this function is added.
	*/
	this.getInputPinString = function(index){
		if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
			return (this.pinBoxList[index].getInputString());
		}
	}
	
	 /**
	* This function will clear one input box selected in PinPopup created<p>
	* This function will clear one input box selected in PinPopup created,You can use this function when you want to clear one input box selected.
	* @param {Number} the index of input box selected.
	* @return {Void}.
	* @example //This example clear one input box selected.
	* PopupIns.clearOutAllInputBox(0);
	* @since The version 1.0 this function is added.
	*/
	this.clearOutInputBox = function(index){
		if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
			this.pinBoxList[index].clearOutInputBox();
		}
	};
	
	/**
	* This function will set input done callback function of PinPopup created<p>
	* This function will set input done callback function of PinPopup created,You can use this function when you want to set input done callback.
	* @param1 {Number} the index of input box selected .
	* @param2 {Function} callback function called when input box selected input done.
	* @return {Void}
	* @example //This set input done callback.
	* var donecallback1=function(){
		  PopupIns.setMessage({message:"ffffffffff"});
	  };
	* PopupIns.setInputDoneCallback(1,donecallback1);
	* @since The version 1.0 this function is added.
	*/
	this.setInputDoneCallback = function(index,callback){
		if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
			this.pinBoxList[index].setInputDoneCallback(callback);
		}
	};
	
	this.m_buttonMouseOverCallBack = function(widget){
		var index=widget.index;
		if(this.focus == true && this.focusIndex!=index){
			if(this.focusIndex>=0 && this.focusIndex < this.buttonCount){
				this.buttonList[this.focusIndex].loseFocus();
			}
			else if((this.focusIndex>=this.buttonCount) && this.focusIndex< (this.buttonCount+this.pinCount)){
				this.pinBoxList[this.focusIndex-this.buttonCount].loseFocus();
			}
			else{
			
			}
			this.focusIndex=index;
			if(this.focusIndex>=0 && this.focusIndex < this.buttonCount){
				this.buttonList[this.focusIndex].getFocus();
			}
			else if((this.focusIndex>=this.buttonCount) && this.focusIndex< (this.buttonCount+this.pinCount)){
				this.pinBoxList[this.focusIndex-this.buttonCount].getFocus();
			}
			else{
			
			}
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
	};
	this.m_buttonMouseOverCallBackBind=this.m_buttonMouseOverCallBack.bind(this);
	
	this.m_buttonMouseOutCallBack = function(widget){

	};
	this.m_buttonMouseOutCallBackBind=this.m_buttonMouseOutCallBack.bind(this);
	
	this.t_pinPopupMouseOver = function(targetWidget, eventData) {
		//this.getFocus();
		if(null!=this.mouseOverCallBack){
			this.mouseOverCallBack(this);
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_pinPopupMouseOverBind=this.t_pinPopupMouseOver.bind(this);

	this.t_pinPopupMouseOut = function(targetWidget, eventData) {
		var x=eventData.coordinates.x;
		var y=eventData.coordinates.y;
		var abx=x-this.initx;
		var aby=y-this.inity;
		if(abx<=this.bgWidth&&abx>=0&&aby<=this.bgHeight&&aby>=0){
			return false;
		}
		else{
			//this.loseFocus();
			if(null!=this.mouseOutCallBack){
				this.mouseOutCallBack(this);
			}
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_pinPopupMouseOutBind=this.t_pinPopupMouseOut.bind(this);
	
	this.t_setMouseOverOutCallback = function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("overCallback")){
			this.mouseOverCallBack=obj.overCallback;
		}
		if(obj.hasOwnProperty("outCallback")){
			this.mouseOutCallBack=obj.outCallback;
		}
	}
	
	this.t_MouseOverOut = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openOverout==false){
					this.PopupBGWidget.addEventListener("OnMouseOver",this.t_pinPopupMouseOverBind);										
					this.PopupBGWidget.addEventListener("OnMouseOut",this.t_pinPopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].index=index;
							this.buttonList[index].enableMouseOverOut(true);
						}			
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].index=index+this.buttonCount;
							this.pinBoxList[index].enableMouseOverOut(true);
							this.pinBoxList[index].setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind,outCallback:this.m_buttonMouseOutCallBack});
						}			
					}	
					this.openOverout=true;
				}
			}
			else{
				if(this.openOverout==true){
					this.PopupBGWidget.removeEventListener("OnMouseOver",this.t_pinPopupMouseOverBind);										
					this.PopupBGWidget.removeEventListener("OnMouseOut",this.t_pinPopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseOverOut(false);
						}			
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseOverOut(false);
						}			
					}
					this.openOverout=false;					
				}
			}
		}
	};
	
	this.t_setMouseUpDownCallback = function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		for(var index = 0; index < this.buttonCount; index++){
			if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
				this.buttonList[index].setMouseUpDownCallback(obj);
			}					
				
		}
	};
	
	this.t_MouseUpDown = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openUpdown==false){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(true);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseUpDown(true);
						}		
					}
					this.openUpdown=true;
				}	
			}
			else{
				if(this.openUpdown==true){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(false);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseUpDown(false);
						}		
					}
					this.openUpdown=false;
				}	
			}
		}
	};
	
	this.t_MouseClick= function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openClick==false){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseClick(true);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseClick(true);
						}		
					}
					this.openClick=true;
				}	
			}
			else{
				if(this.openClick==true){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseClick(false);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseClick(false);
						}		
					}
					this.openClick=false;
				}	
			}
		}
	};
	
	this.t_getFocus = function() {
		if(true == this.focus){
			return false;
		}
		else{
			
			if(this.focusIndex >= 0&&this.focusIndex < this.buttonCount){
				this.buttonList[this.focusIndex].getFocus();	
			}
			if(this.focusIndex >= this.buttonCount&&this.focusIndex < this.buttonCount+this.pinCount){
				this.pinBoxList[this.focusIndex-this.buttonCount].getFocus();	
			}
			this.focus=true;
			return true;
		}
	    	
	};
	
	this.t_loseFocus = function() {
		if(false == this.focus){
			return false;
		}
		else{
			
			if(this.focusIndex >= 0&&this.focusIndex < this.buttonCount){
				this.buttonList[this.focusIndex].loseFocus();
			}
			if(this.focusIndex >= this.buttonCount&&this.focusIndex < this.buttonCount+this.pinCount){
					this.pinBoxList[this.focusIndex-this.buttonCount].loseFocus();	
			}
			this.focus=false;
			return true;
		}
	};
	
	/**
	* This function will set the focus position in PinPopup created,it will work after getFocus.<p>
	* This function will set the focus position in PinPopup created,You can use this function when you want to set the focus position.
	* @param {Number} the index of object you want to focus,in this PinPopup,the input box index is input box index add button count.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set focus position.
	* PopupIns.setFocusIndex(0);
	* @since The version 1.0 this function is added.
	*/
	this.setFocusIndex = function(focusIdx) {	
		if(focusIdx >= 0 && focusIdx < this.buttonCount+this.pinCount) {
			this.focusIndex = focusIdx;
			return true;
		}
		return false;
	};
}

PinPopup.prototype = new ControlBase();
exports = PinPopup;
