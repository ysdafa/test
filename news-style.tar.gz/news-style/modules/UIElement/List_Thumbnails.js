/** 
 * @author  
 * @fileoverview Definition of List_Thumbnails
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
 
ControlBase = Volt.require("modules/UIElement/ControlBase.js");
var verifyLongPressModule = Volt.require('modules/UIElement/verifyLongPress.js');

List_Thumbnails = function(){
	this.m_ItemWidth = -1;
	this.m_ItemHeight = -1;
	this.m_ItemXGap = 0;
	this.m_ItemYGap = 0;
	
	this.m_RowNum = 0;
	this.m_DisplayAreaColumnNum = 0;
	
	this.m_CashColumNum = 2;		
	this.m_RenderCloumNum = -1;	// this.m_DisplayAreaColumnNum +this.m_CashColumNum*2;	
	
	this.m_DataSourceArray = null;
	this.m_ItemRenderArray = null;
	
	this.m_DisplayBGWidget = null;
	this.m_ScrollWidget = null;
			
	this.m_nVeticalOffSet = 0;
	this.m_nHorizontalOffSet = 0;
	this.m_nRealTotalNum = 0;	
	this.m_nTotalNumWithBlankNum =0;
	
	//after move need update those five parameter
	this.m_ScrollWidgetXPosition = 0;	
	this.m_curDataStartIndex = 0;
	this.m_curDataStartColumn = 0;
	this.m_firstRenderItemX = 0;
	this.m_curFocusItemIndex = -1;
	
	this.m_bIsAnimationIng = false;	
	this.m_bEditModule = false;
	this.m_bSupportDragAndDrop = false;
	this.m_bSupportDragAndDropAgent = false;
	this.m_bSupportCycle = false;
	this.m_bSupportEnlargeItem = false;
	this.m_nLongPressIntervalTime = 1000;
	
	//callback function
	this.m_ItemLoadCB = null;
	this.m_ItemUnloadCB = null;
	this.m_ItemUpdateCB = null;
	this.m_ItemClickCB = null;
	this.m_FocusOutOfRangeCB = null;
	this.m_FocusInCB = null;
	this.m_FocusOutCB = null;
	this.m_ItemLongPressCB = null;
	
	this.m_CursorInstance = null;
	this.m_fristShowCursor = true;
	
	this.m_leftArrowWidget = null;
	this.m_rightArrowWidget = null;
	
	//for drag and drop
	this.m_nMovingRenderIndex =-1;
	this.m_nMouseCurOverRenderIndex =-1;
	this.m_MovingItemWidget =null;
	this.m_bDoMovingFlag = false;

	//dim
	this.m_bDimFlag = false;
	this.m_DimWidget = null;
	
	//reverse
	this.m_bReverseFlag = false;

	//align side
	this.alignState = {
        STATE_NORMAL:0,
        STATE_ALIGN_LEFT:1,
		STATE_ALIGN_RIGHT:2,
        STATE_MAX:3//do NOT define enum after this!
    };
	this.m_bAlignSide = false;
	this.m_currentAlignState = this.alignState.STATE_NORMAL;
	this.m_nReverseAlignOffSet = 0;
	
	//for test
	this.m_testIndex =0;	
	
	//for time out handler
	this.m_fristShowCursorTimeOutHandler = null;
	this.m_ClickCallTimeOutHandler = null;
	
	//for animation handler
	this.m_scaleAniZoomInHandler = null;
	this.m_scaleAniZoomOutHandler = null;
	this.m_moveLeftAniHandler = null;
	this.m_moveRightAniHandler = null;
	this.m_moveCenterToRightAniHandler = null;
	this.moveLeftToCenterAniHandler = null;
	this.m_moveCenterToLeftAniHandler = null;
	this.m_moveRightToCenterAniHandler = null;
	this.m_moveLeftOnePageAniHandler = null;
	this.m_moveRightOnePageAniHandler = null;
	this.m_ReverseMoveLeftOnePageAniHandler = null;
	this.m_ReverseMoveRightOnePageAniHandler = null;
	this.m_MoveItemAniHandler = null;
	this.m_MoveItemSecondAniHandler = null;
	this.m_ReverseMoveItemAniHandler = null;
	this.m_ReverseMoveItemSecondAniHandler = null;		
	
	/**
	* This function creates a List Thumbnail object. 
	* @param {Object} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/			
	this.t_create = function(param) {
		this.m_InitMembers(param);		
		this.m_InitRenderItems(param);		
		
		//create long press
		this.m_verifyLongPress = new verifyLongPressModule(this.m_nLongPressIntervalTime);		
	}
	
	this.t_destroy = function(){
		//destroy render item
		this.m_unloadRenderItem();
	
		//clear array
		for(var nColumIndex =0; nColumIndex < this.m_RenderCloumNum; nColumIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
				this.m_ItemRenderArray[nColumIndex][nRowIndex].destroy();
			}
		
			this.m_ItemRenderArray[nColumIndex].length =0;
		}
		this.m_ItemRenderArray.length =0;		
		this.m_ItemRenderArray = null;
		
		//destroy member widget
		if(this.m_ScrollWidget != null){
			this.m_ScrollWidget.destroy();
			this.m_ScrollWidget = null;
		}
		
		if(this.m_leftArrowWidget != null){
			this.m_leftArrowWidget.destroy();
			this.m_leftArrowWidget = null;
		}
		
		if(this.m_rightArrowWidget != null){
			this.m_rightArrowWidget.destroy();
			this.m_rightArrowWidget = null;
		}
		
		if(this.m_DisplayBGWidget != null){
			this.m_DisplayBGWidget.destroy();
			this.m_DisplayBGWidget = null;
		}
						
		//clear timeout
		if(this.m_fristShowCursorTimeOutHandler != null){
			 Volt.clearTimeout(this.m_fristShowCursorTimeOutHandler);
			 this.m_fristShowCursorTimeOutHandler = null;
		}

		if(this.m_ClickCallTimeOutHandler != null){
			Volt.clearTimeout(this.m_ClickCallTimeOutHandler);
			this.m_ClickCallTimeOutHandler = null;
		}	
				
		//clear bind function
		delete this.m_leftArrowWidgetMouseClickBind;
		delete this.m_rightArrowWidgetMouseClickBind;
		delete this.m_ListMoveLeftCBBind;
		delete this.m_ListMoveRightCBBind;
		delete this.m_MoveCenterToRightCBBind;
		delete this.m_MoveLeftToCenterCBBind;
		delete this.m_moveCenterToLeftBind;
		delete this.m_moveRightToCenterCBBind;
		delete this.MoveLeftOnePageCBBind;
		delete this.m_MoveRightOnePageCBBind;
		delete this.m_ReverseMoveRightOnePageCBBind;
		delete this.m_ReverseMoveLeftOnePageCBBind;
		delete this.m_ListItemMouseClickBind;
		delete this.m_ListItemMouseOverBind;
		delete this.m_ListItemMouseDownBind;
		delete this.m_DisplayBGWidgetMouseUpBind;
		delete this.m_DisplayBGWidgetMouseMoveBind;

		//clear ainimation	
	}
	
	this.t_getFocus = function(){
		
		this.m_showFocus();
	
		//set focus			
		var curFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum; 
		this.m_HighlightItem(curFocusRenderIndex);
			
		//call focus in function
		var nCurDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);	
		this.m_FocusInCBCall(nCurDataIndex,curFocusRenderIndex);
		
	}
	
	this.t_loseFocus = function(){	
		this.m_hideCursor();	
	
		var curFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum; 
		this.m_UnHighlightItem(curFocusRenderIndex);	

		//call focus in function
		var nCurDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);	
		this.m_FocusOutCBCall(nCurDataIndex,curFocusRenderIndex);		
	}
	
	this.t_show = function() {
		this.updateCurPage();
	};

	this.t_hide = function() {
	};	
		
	this.t_keyHandler = function(keycode, keytype){	
		if(this.m_bDimFlag == true){
			return true;
		}
		
		if(this.m_bDoMovingFlag == true){
			return true;
		}	
	
		if(keycode == Volt.KEY_JOYSTICK_OK){
			var returnValue = this.m_verifyLongPress.keyAction({type:keytype});	
			if(returnValue == -1){
				return false;
			}
		}
	
		if (keytype == Volt.EVENT_KEY_PRESS && keycode ==Volt.KEY_JOYSTICK_OK ){
			return true;
		}
		
		if (keytype == Volt.EVENT_KEY_RELEASE && keycode !=Volt.KEY_JOYSTICK_OK ){
			return true;
		}	
		
		if(this.m_bIsAnimationIng == true){
			return true;
		}		
				
		var bDoingCycleAni = false;
		var bRet = false;
		switch (keycode)
		{
			case Volt.KEY_JOYSTICK_LEFT:
			{
				var bOnePageAndAtLastColumn = false;
				if(this.m_bReverseFlag == true){
					//for only one page and data Less than a page case
					bOnePageAndAtLastColumn = this.m_CheckIfOnlyOnePageAndAtLastColumn();
				}
						
				if( this.m_getCurColumn() > 0 && (bOnePageAndAtLastColumn == false))
				{						
					var oldFocusIndex = this.m_curFocusItemIndex;
					if(this.m_bReverseFlag == true){
						//check if need focus on last item	
						if(this.m_CheckIfNeedFocusOnLastItem(true) == false){
							this.m_curFocusItemIndex  = this.m_curFocusItemIndex - this.m_RowNum;
						}						
					}
					else
					{
						this.m_curFocusItemIndex  = this.m_curFocusItemIndex - this.m_RowNum;
					}
					
					this.m_ChangeFocus(oldFocusIndex, this.m_curFocusItemIndex);									
					this.m_moveFocusCursor();
				}
				else
				{
					//move the m_ScrollWidget case
					if(this.m_CheckIfNeedMoveRight() == true)
					{
						this.m_MoveRight(false); 
					}
					else
					{	
						if(this.m_bSupportCycle == true && this.m_PageNum() > 1)
						{
							this.m_bIsAnimationIng = true;
							bDoingCycleAni = true;
							this.m_CycleCallLeft();
						}
					}					
				}	
				bRet = true;
			}
			break;			
			case Volt.KEY_JOYSTICK_RIGHT:
			{
				var bOnePageAndAtLastColumn = false;
				if(this.m_bReverseFlag == false){
					//for only one page and data Less than a page case
					bOnePageAndAtLastColumn = this.m_CheckIfOnlyOnePageAndAtLastColumn();
				}
								
				if(this.m_getCurColumn() < (this.m_DisplayAreaColumnNum -1)&& (bOnePageAndAtLastColumn == false))
				{									
					var oldFocusIndex = this.m_curFocusItemIndex;							
					if(this.m_bReverseFlag == false){
						//check if need focus on last item
						if(this.m_CheckIfNeedFocusOnLastItem(true) == false){
							this.m_curFocusItemIndex  = this.m_curFocusItemIndex + this.m_RowNum;
						}					
					}
					else
					{
						this.m_curFocusItemIndex  = this.m_curFocusItemIndex + this.m_RowNum;
					}
										
					this.m_ChangeFocus(oldFocusIndex, this.m_curFocusItemIndex);
					this.m_moveFocusCursor();	
				}
				else
				{
					//move the m_ScrollWidget case
					//when at the last colum, check if need move
					if(this.m_CheckIfNeedMoveLeft() == true)
					{
						this.m_bIsAnimationIng = true;					
						this.m_MoveLeft(false);
					}
					else
					{					
						if(this.m_bSupportCycle == true && this.m_PageNum() > 1)
						{
							this.m_bIsAnimationIng = true;
							bDoingCycleAni = true;
							this.m_CycleCallRight();
						}	
					}							
				}			
				bRet = true;
			}
			break;			
			case Volt.KEY_JOYSTICK_UP:
			{
				if(this.m_getCurRow() > 0)
				{
					var oldFocusIndex = this.m_curFocusItemIndex;
					this.m_curFocusItemIndex  = this.m_curFocusItemIndex -1;
					this.m_ChangeFocus(oldFocusIndex, this.m_curFocusItemIndex);
					this.m_moveFocusCursor();					
				}
				else
				{
					//call out of range callback
					this.m_FocusOutOfRangeCBCall(Volt.KEY_JOYSTICK_UP);
				}			
				bRet = true;
			}
			break;
			case Volt.KEY_JOYSTICK_DOWN:
			{
				if(this.m_getCurRow() < (this.m_RowNum -1))
				{
					var oldFocusIndex = this.m_curFocusItemIndex;					
					//check if  need change focus on preview column's last item					
					if(this.m_CheckIfNeedFocusOnPreColumnLastOne() == false)
					{
						this.m_curFocusItemIndex  = this.m_curFocusItemIndex +1;
					}							
					this.m_ChangeFocus(oldFocusIndex, this.m_curFocusItemIndex);						
					this.m_moveFocusCursor();
				}
				else
				{
					//call out of range callback
					this.m_FocusOutOfRangeCBCall(Volt.KEY_JOYSTICK_DOWN);					
				}				
				bRet = true;				
			}
			break;			
			case Volt.KEY_JOYSTICK_OK:
			{
				if(returnValue)
				{
					this.m_verifyLongPress.clearLongPressTicker();	
					this.m_LongPressCall();
				}
				else
				{
					this.m_ClickCall();
				}				
				bRet = true;			
			}
			break;
			
			case Volt.KEY_0:
			//case Volt.KEY_FF:
			{
				if((this.m_curDataStartIndex + this.m_RowNum * this.m_DisplayAreaColumnNum) < this.m_nRealTotalNum){
					this.m_bIsAnimationIng = true;	
					this.nextPage();
				}				
			}
			break;
			
			case Volt.KEY_1:
			//case Volt.KEY_REWIND:
			{
				if(this.m_curDataStartIndex > 0){
					this.m_bIsAnimationIng = true;
					this.prePage();
				}
			}
			break;			
			
			case Volt.KEY_2:
			{
				//this.setFocusOnItem(this.m_testIndex);
				//this.m_testIndex = this.m_testIndex +1;
			}
			break;
			default:
			break;
		}
		
		if(bDoingCycleAni == false){
			//show arrow by case		
			this.m_showArrow();		
		}
		
		return bRet;
	}
		
	this.m_CheckIfLastPage = function(){
		//do not care about the one page case
		if(this.m_PageNum() == 1){
			return false;
		}
	
		if((this.m_curDataStartIndex + this.m_RowNum * this.m_DisplayAreaColumnNum) < this.m_nRealTotalNum){
			return false;
		}
		else{
			return true;
		}
	}
	this.m_GetAlignRightMoveLeftOffset = function(){
		var valueOne = this.m_nHorizontalOffSet +  (this.m_DisplayAreaColumnNum + 1) * (this.m_ItemWidth + this.m_ItemXGap)
		var nRet = valueOne - this.width;
		return nRet;
	}
	
	this.m_GetAlignRightLastPageOffSet = function(){
		var nRet = (this.m_ItemWidth + this.m_ItemXGap) - this.m_GetAlignRightMoveLeftOffset();
		return nRet;
	}
	
	this.m_CheckIfNeedMoveLeft = function(){
		if(this.m_bReverseFlag == false){
			if((this.m_curDataStartIndex + this.m_RowNum * this.m_DisplayAreaColumnNum) < this.m_nRealTotalNum)	
			return true;	
		}
		else{
			if(this.m_curDataStartIndex > 0)	
			return true;	
		}
		return false;	
	}
	
	this.m_CheckIfNeedMoveRight = function(){
		if(this.m_bReverseFlag == false){
			if(this.m_curDataStartIndex > 0)	
			return true;	
		}
		else{
			if((this.m_curDataStartIndex + this.m_RowNum * this.m_DisplayAreaColumnNum) < this.m_nRealTotalNum)	
			return true;		
		}
		return false;
	}
			
	/**
	* This function sets one item get focus. 
	* @param {Number} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/
	//interface for user	
	this.setFocusOnItem = function(nDataIndex){
		//check data if invalid
		if(nDataIndex < 0 && nDataIndex >= this.m_nRealTotalNum){
			return false;
		}
	
		var nStartDataIndex = this.m_curDataStartIndex;
		var nLastDataIndex = this.m_curDataStartIndex + this.m_DisplayAreaColumnNum *this.m_RowNum;
		//check if nDataIndex in current page , move focus
		if( this.m_MoveFocusOnCurPage(nDataIndex) == true)
			return true;
				
		//if nDataIndex in next page 
		if(nDataIndex >= nLastDataIndex){
			var curFirstItemCloumnNum = this.m_GetCurColumByDataIndex(this.m_curDataStartIndex);
			var newFcousDataIndexCloumnNum = this.m_GetCurColumByDataIndex(nDataIndex);
			
			var nMoveNum = newFcousDataIndexCloumnNum - curFirstItemCloumnNum - this.m_DisplayAreaColumnNum +1;
			var bMoveRight = (this.m_bReverseFlag == false)?false:true;
			this.m_MoveScrollWidgetByColumnNum(nMoveNum, bMoveRight);
			
			//move focus to the data item
			this.m_MoveFocusOnCurPage(nDataIndex);	
			return true;	
		}
			
		//if nDataIndex in pre page
		if(nDataIndex < nStartDataIndex)
		{
			var curFirstItemCloumnNum = this.m_GetCurColumByDataIndex(this.m_curDataStartIndex);
			var newFcousDataIndexCloumnNum = this.m_GetCurColumByDataIndex(nDataIndex);	
			var nMoveNum = curFirstItemCloumnNum - newFcousDataIndexCloumnNum;
			
			var bMoveRight = (this.m_bReverseFlag == false)?true:false;
			this.m_MoveScrollWidgetByColumnNum(nMoveNum, bMoveRight);
			
			//move focus to the data item
			this.m_MoveFocusOnCurPage(nDataIndex);	
			return true;			
		}	
			return false;
	}		
		
	/**
	* This function sets cursor image resource. 
	* @param {Object} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/
	this.setFcousImage = function(focusImages){	
			//cursor
			cursorClass	= require("CursorComponent");
			this.m_CursorInstance = new cursorClass(focusImages);			
			
			this.m_CursorInstance.x = this.m_nHorizontalOffSet + this.m_getCurColumn()*(this.m_ItemWidth + this.m_ItemXGap);	
			this.m_CursorInstance.y = this.m_nVeticalOffSet + this.m_getCurRow()*(this.m_ItemHeight + this.m_ItemYGap);
			this.m_CursorInstance.parent =  this.m_DisplayBGWidget;
			this.m_CursorInstance.hide();
	}
	
	this.setArrowAttributes = function(leftArrowAttr,rightArrowAttr){	
	if(this.m_leftArrowWidget == null){
		this.m_leftArrowWidget = new ImageWidget({
						x:leftArrowAttr.x,
						y:leftArrowAttr.y,
						width:leftArrowAttr.width,
						height:leftArrowAttr.height,
						src:leftArrowAttr.src,
						parent:this.m_DisplayBGWidget		
			});	
	}
	this.m_leftArrowWidget.addEventListener("OnMouseClick", this.m_leftArrowWidgetMouseClickBind);	
	this.m_leftArrowWidget.hide();
	
	if(this.m_rightArrowWidget == null){
		this.m_rightArrowWidget = new ImageWidget({
						x:rightArrowAttr.x,
						y:rightArrowAttr.y,
						width:rightArrowAttr.width,
						height:rightArrowAttr.height,
						src:rightArrowAttr.src,
						parent:this.m_DisplayBGWidget		
			});	
	}	
	
	this.m_rightArrowWidget.addEventListener("OnMouseClick", this.m_rightArrowWidgetMouseClickBind);	
	this.m_rightArrowWidget.hide();
	
	//show arrow by case
	this.m_showArrow();
}

	this.changeToEditMode = function(){
		if(this.m_bEditModule == true){
			return;}
	
		this.m_bSupportDragAndDrop = false;
		this.m_UnSetAllRenderDrawingWithDepth();	
		
		this.m_bEditModule = true;
		
		//update current page
		this.updateCurPage();		
	}
	
	this.changeToCommonMode = function(){
		if(this.m_bEditModule == false){
			return;}	
		
		this.m_bSupportDragAndDrop = this.m_bSupportDragAndDropAgent;
		
		this.m_SetAllRenderDrawingWithDepth();
		
		this.m_bEditModule = false;		
		
		//update current page
		this.updateCurPage();		
	}
	
	/**
	* This function resets item data. 
	* @param {Array} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/
	this.resetDataSource = function(newDataSource){	
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);
	
		//hide all render item
		this.m_unloadRenderItem();	
				
		this.setDataSource(newDataSource);
		if(this.m_nRealTotalNum != 0){		
			//update first start data index			
			this.m_curDataStartIndex = 0;
			
			//update cur page
			this.updateCurPage();
		
			this.m_curFocusItemIndex =0;
			//highlight Item		
			var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;		
			this.m_HighlightItem(newFocusRenderIndex);
			var nNewDataIndex = this.m_curDataStartIndex + this.m_curFocusItemIndex;
			this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
			
			this.m_moveFocusCursor();
		}
		else{
			this.loseFocus();
			this.m_bEditModule = false;		
			this.m_SetAllRenderDrawingWithDepth();			
		}
	}
	
	this.addItemUpdate = function(){
		//update the total number
		this.m_nRealTotalNum = this.m_DataSourceArray.length;		
			
		//reset total number with blank item	
		var addNum = this.m_GetBlankNum(); 		
		this.m_nTotalNumWithBlankNum = this.m_nRealTotalNum  + addNum;	
		
		//update cur page
		this.updateCurPage();
	}
	
	this.deleteItemUpdate = function(){
		if(this.m_bEditModule == false){
			return false;
		}
				
		//hide all render item
		this.m_unloadRenderItem();
		
		//update the total number
		this.m_nRealTotalNum = this.m_DataSourceArray.length;		
			
		//reset total number with blank item	
		var addNum = this.m_GetBlankNum(); 		
		this.m_nTotalNumWithBlankNum = this.m_nRealTotalNum  + addNum;
	
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);	
	
		//reset focus item
		if(this.m_nRealTotalNum != 0){		
			//update first start data index			
			this.m_curDataStartIndex = 0;			
			//update cur page
			this.updateCurPage();
			//update focus index	
			this.m_curFocusItemIndex = (this.m_bReverseFlag == false)? 0:(this.m_DisplayAreaColumnNum -1)*this.m_RowNum;
			//highlight Item		
			var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;		
			this.m_HighlightItem(newFocusRenderIndex);
			var nNewDataIndex = this.m_curDataStartIndex + this.m_curFocusItemIndex;
			this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
			
			this.m_moveFocusCursor();
		}
		else{
			this.loseFocus();
			this.m_bSupportDragAndDrop = this.m_bSupportDragAndDropAgent;
			this.m_bEditModule = false;			
			this.m_SetAllRenderDrawingWithDepth();
		}		
	}
		
	this.focusItemDataIndex  = function(){
		return this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
	}
	
	this.setDataSource = function(objArray){
		this.m_DataSourceArray = objArray;	
		this.m_nRealTotalNum = this.m_DataSourceArray.length;
		 
		var addNum = this.m_GetBlankNum(); 
		
		//reset total num
		this.m_nTotalNumWithBlankNum = this.m_nRealTotalNum  + addNum;
	}
			
	this.updateCurPage = function(){	
		//include two side columns of cash
		var nCurStartDataIndex = this.m_curDataStartIndex - this.m_RowNum;			
		var nLastDataIndex = this.m_curDataStartIndex + (this.m_DisplayAreaColumnNum + 1)*this.m_RowNum;
					
		for(;nCurStartDataIndex < nLastDataIndex; nCurStartDataIndex++)
		{
			this.m_updataDataToItemRender(nCurStartDataIndex);
		}
	}	
	
	/**
	* This function updates one item. 
	* @param {Number} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/
	this.updateItem = function(nDataIndex){
		if((nDataIndex >= 0)&&  nDataIndex < this.m_nRealTotalNum)
		{
			this.m_updataDataToItemRender(nDataIndex);			
		}
	}
		
	this.dimList = function(){
		this.m_bDimFlag = true;		
		this.loseFocus();
	
		if(this.m_DimWidget != null)
		{
			this.m_DimWidget.depth = 0.2;
			this.m_DimWidget.drawWithDepth = true;
			this.m_DimWidget.show();
		}
	}
		
	this.unDimList = function(){
		this.m_bDimFlag = false;
		this.getFocus();		
		
		if(this.m_DimWidget != null)
		{
			this.m_DimWidget.depth = 0;
			this.m_DimWidget.drawWithDepth = true;
			this.m_DimWidget.hide();
		}				
	}
		
	this.m_SetAllRenderDrawingWithDepth = function(){
		for(var nCloumnIndex = 0;  nCloumnIndex < this.m_RenderCloumNum;  nCloumnIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){				
				var tmpRender = this.m_ItemRenderArray[nCloumnIndex][nRowIndex];
					tmpRender.drawWithDepth = true;
			}
		}
	}

	this.m_UnSetAllRenderDrawingWithDepth = function(){
		for(var nCloumnIndex = 0;  nCloumnIndex < this.m_RenderCloumNum;  nCloumnIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){				
				var tmpRender = this.m_ItemRenderArray[nCloumnIndex][nRowIndex];
					tmpRender.drawWithDepth = false;
			}
		}
	}
		
	//for initial
	this.m_InitMembers = function(param){	
		this.m_ItemWidth = param.nItemWidth;
		this.m_ItemHeight = param.nItemHeight;
		this.m_RowNum = param.nRowNum;
		this.m_DisplayAreaColumnNum = param.nColumnNum;		
		
		if (param.hasOwnProperty("nXItemGap")) {
			this.m_ItemXGap = param.nXItemGap;
		}
		
		if (param.hasOwnProperty("nYItemGap")) {
			this.m_ItemYGap = param.nYItemGap;
		}	
		
		if (param.hasOwnProperty("nVeticalOffSet")) {
			this.m_nVeticalOffSet = param.nVeticalOffSet;
		}

		if (param.hasOwnProperty("nHorizontalOffSet")) {
			this.m_nHorizontalOffSet = param.nHorizontalOffSet;	
		}
		
		if(param.hasOwnProperty("bSupportDragAndDrop")){
			this.m_bSupportDragAndDrop = param.bSupportDragAndDrop;
			this.m_bSupportDragAndDropAgent = param.bSupportDragAndDrop;
		}
		
		if(param.hasOwnProperty("nLongPressIntervalTime")){
			this.m_nLongPressIntervalTime = param.nLongPressIntervalTime;
		}

		if(param.hasOwnProperty("bSupportCycle")){
			this.m_bSupportCycle = param.bSupportCycle;
		}
		
		if(param.hasOwnProperty("bReverseFlag")){
			this.m_bReverseFlag = param.bReverseFlag;
		}		
		
		if(param.hasOwnProperty("bAlignSide")){
			this.m_bAlignSide = param.bAlignSide;
		}
		
		if(param.hasOwnProperty("bSupportEnlargeItem")){
			this.m_bSupportEnlargeItem = param.bSupportEnlargeItem;
		}
		
		this.m_RenderCloumNum = this.m_DisplayAreaColumnNum +this.m_CashColumNum*2;
				
		if(this.m_bReverseFlag == false){
			this.m_curDataStartColumn = this.m_CashColumNum;
			this.m_curFocusItemIndex = 0;
		}
		else{
			this.m_curDataStartColumn = this.m_CashColumNum + this.m_DisplayAreaColumnNum -1;
			this.m_curFocusItemIndex = (this.m_DisplayAreaColumnNum -1)*this.m_RowNum;
		}
				
		this.m_bIsAnimationIng = false;	
		this.m_bEditModule = false;
	}
	
	this.m_InitRenderItems = function(param){			
		//create the Display Widget
		this.m_DisplayBGWidget = new Widget({
			x: 0,
			y: 0,
			width: param.width,
			height: param.height,			
			color: {r: 255, g: 255, b: 0, a: 0},
			parent: param.parent,
		});	
		this.m_DisplayBGWidget.cropOverflow = true;
		this.m_DisplayBGWidget.addEventListener("OnMouseMove", this.m_DisplayBGWidgetMouseMoveBind);
		this.m_DisplayBGWidget.addEventListener("OnMouseUp", this.m_DisplayBGWidgetMouseUpBind);		
		
		//create dim widget
		this.m_DimWidget = new Widget({
			x: 0,
			y: 0,
			width: param.width,
			height: param.height,			
			color: {r: 0, g: 0, b: 0, a:255},
			opacity:255/2,	
			parent: param.parent,
		});			
		this.m_DimWidget.hide();
		
		// create scroll widget
		this.m_ScrollWidget = new Widget({
			x: 0,
			y: 0,
			width: param.width,
			height: param.height,			
			color: {r: 0, g: 0, b: 0, a: 0},
			parent: this.m_DisplayBGWidget,
		});
		
		if(this.m_bReverseFlag == true && this.m_bAlignSide == true){
			this.m_ScrollWidget.x = this.m_GetAlignRightLastPageOffSet();
			this.m_ScrollWidgetXPosition = this.m_ScrollWidget.x;
			this.m_nReverseAlignOffSet = this.m_ScrollWidget.x;
		}
		
		//create render and create position object			
		this.m_firstRenderItemX = this.m_nHorizontalOffSet - (this.m_ItemWidth + this.m_ItemXGap)* this.m_CashColumNum;
		var nYOffSet = this.m_nVeticalOffSet; 
		var nXOffSet = this.m_firstRenderItemX;
						
		this.m_ItemRenderArray =new Array();			
		for(var nColumIndex =0; nColumIndex < this.m_RenderCloumNum; nColumIndex++)	
		{		
			this.m_ItemRenderArray[nColumIndex] = new Array();
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++)
			{			
				var nX = nXOffSet + nColumIndex*(this.m_ItemWidth + this.m_ItemXGap);
				var nY = nYOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);			
				var tmpRender = this.m_CreateOneRenderItem(nX, nY);				
				this.m_ItemRenderArray[nColumIndex][nRowIndex] = tmpRender;
			}
		}
	}
		
	this.m_GetBlankNum= function(){	
		var addNum =0;

		//check if only one page
		if(this.m_nRealTotalNum  < this.m_RowNum * this.m_DisplayAreaColumnNum){			
			addNum = this.m_RowNum * this.m_DisplayAreaColumnNum - this.m_nRealTotalNum;
		}
		else{
			//check last column is full
			var nlastDataIndex = this.m_nRealTotalNum - 1 ;
			var nlastDataRowNum = this.m_GetRowNumByDataIndex(nlastDataIndex);			
			if(nlastDataRowNum < (this.m_RowNum -1)){
				addNum = (this.m_RowNum - 1) - nlastDataRowNum;	
			}
		}
		return addNum;
	}	

	//for set Item call back
	this.setItemLoadCB = function(itemLoadCB){
		this.m_ItemLoadCB = itemLoadCB;	
	}
	
	this.setItemUnloadCB = function(itemUnloadCB){
		this.m_ItemUnloadCB = itemUnloadCB;	
	}	
	
	this.setItemUpdateCB = function(itemUpdateCB){
		this.m_ItemUpdateCB = itemUpdateCB;	
	}
	
	this.setItemClickCB = function(itemClickCB){
		this.m_ItemClickCB = itemClickCB;
	}			
		
	this.setFocusOutOfRangeCB = function(focusOutOfRangeCB){
		this.m_FocusOutOfRangeCB = focusOutOfRangeCB;			
	}	
	
	this.setFocusInCB = function(focusInCB){
		this.m_FocusInCB = focusInCB;	
	}
	
	this.setFocusOutCB = function(focusOutCB){
		this.m_FocusOutCB = focusOutCB;
	}	
	
	this.setItemLongPressCB = function(itemLongPressCB){
		this.m_ItemLongPressCB = itemLongPressCB;
	}
	
	// for internal call back
	this.m_GetAbsoluteXOfItem = function(){
		var nCloumnNum = this.m_GetCurColumByDataIndex(this.m_curFocusItemIndex);
		var nX = this.x + this.m_nHorizontalOffSet + (this.m_ItemWidth +this.m_ItemXGap)*nCloumnNum; 
		return nX;
	}

	this.m_GetAbsoluteYOfItem = function(){
		var nRowNum = this.m_GetRowNumByDataIndex(this.m_curFocusItemIndex);
		var nY = this.y + this.m_nVeticalOffSet + (this.m_ItemHeight + this.m_ItemYGap)*nRowNum;
		return nY;
	}
	
	this.m_LongPressCall = function(){
		if(this.m_ItemLongPressCB != null)
		{
			var nCurDataIndex = this.focusItemDataIndex();
			var nAbsoluteX = this.m_GetAbsoluteXOfItem();
			var nAbsoluteY = this.m_GetAbsoluteYOfItem();
			nAbsoluteX =this.m_ResetCursorXPositon(nAbsoluteX);
			
			if(0 <= nCurDataIndex && nCurDataIndex < this.m_nRealTotalNum)
			{
				this.m_ItemLongPressCB(nCurDataIndex,nAbsoluteX,nAbsoluteY);
			}			
		}	
	}	
		
	this.m_ClickCall = function(){
		if(this.m_ItemClickCB != null)
		{				
			var nCurDataIndex = this.focusItemDataIndex();
			//print("m_ClickCall=====================nCurDataIndex" + nCurDataIndex);
			if(0 <= nCurDataIndex && nCurDataIndex < this.m_nRealTotalNum)
			{	
				//clear timeout			
				if(this.m_ClickCallTimeOutHandler != null){
					Volt.clearTimeout(this.m_ClickCallTimeOutHandler);
					this.m_ClickCallTimeOutHandler = null;
				}				
				
				//set timeout
				this.m_ClickCallTimeOutHandler = Volt.setTimeout(function(firstObj){
					var curFocusRenderIndex = firstObj.m_FocusItemRenderIndex();
					//print("m_ClickCall=====================curFocusRenderIndex" + curFocusRenderIndex);										
					var nRowNum = curFocusRenderIndex%firstObj.m_RowNum;
					var nColumnNum = parseInt(curFocusRenderIndex/firstObj.m_RowNum);
					//print("m_ClickCall=====================nColumnNum" + nColumnNum);					
					//print("m_ClickCall==========/===========nRowNum" + nRowNum);					
					firstObj.m_ItemClickCB(nCurDataIndex, firstObj.m_ItemRenderArray[nColumnNum][nRowNum],firstObj.m_bEditModule);
					}
				,50, this);
			}				
		}		
	}		
		
	this.m_ItemLoadCall = function(nDataIndex, rootObject){
		rootObject.bItemLoad = true;	
		if(this.m_ItemLoadCB != null)
		{
			this.m_ItemLoadCB(nDataIndex, rootObject, this.m_bEditModule);
		}		
	}		
	
	this.m_ItemUnLoadCall = function(nDataIndex, rootObject){	
		if(rootObject.bItemLoad == false){
			return false;}
		//logTest("m_ItemUnLoadCall======" + nDataIndex,true);
		//reset	state of the item
		rootObject.bItemLoad = false;
		rootObject.nBindDataIndex = -1;
		rootObject.bMoveFlag = false;
		rootObject.depth =0;
		rootObject.drawWithDepth = true;		
		rootObject.removeEventListener("OnMouseClick", this.m_ListItemMouseClickBind);
		rootObject.removeEventListener("OnMouseOver", this.m_ListItemMouseOverBind);
		rootObject.removeEventListener("OnMouseDown", this.m_ListItemMouseDownBind);						
		
		//check if need call unload item call back	
		if(nDataIndex < 0 || nDataIndex >= this.m_nRealTotalNum){
			return false;}
					
		if(this.m_ItemUnloadCB != null){
			this.m_ItemUnloadCB(nDataIndex, rootObject);
		}	
	}
		
	this.m_ItemUpdateCBCall = function(nDataIndex, rootObject){
		if(nDataIndex < 0 || nDataIndex >= this.m_nRealTotalNum){
			return false;
		}
			
		if(this.m_ItemUpdateCB != null)	{
			this.m_ItemUpdateCB(nDataIndex, rootObject, this.m_bEditModule);
		}	
	}	
	
	this.m_FocusOutOfRangeCBCall = function(keycode){
		if(this.m_FocusOutOfRangeCB  != null){
			this.m_FocusOutOfRangeCB(keycode);
		}
	}
	
	this.m_FocusInCBCall = function(nDataIndex, nRenderIndex){
		if(nDataIndex < 0 || nDataIndex >= this.m_nRealTotalNum){
			return false;
		}
	
		var tmpRender = this.m_getRenderByRenderIndex(nRenderIndex);
	
		if(this.m_FocusInCB != null){
			this.m_FocusInCB(nDataIndex,tmpRender);
		}
	}
		
	this.m_FocusOutCBCall = function(nDataIndex,nRenderIndex){
		if(nDataIndex < 0 || nDataIndex >= this.m_nRealTotalNum){
			return false;
		}
		
		var tmpRender = this.m_getRenderByRenderIndex(nRenderIndex);
		
		if(this.m_FocusOutCB != null){
			this.m_FocusOutCB(nDataIndex,tmpRender);
		}
	}
			
	//for get Column and row number		
	this.m_GetCurColumByDataIndex = function(nDataIndex){
		return parseInt(nDataIndex/this.m_RowNum);
	}

	this.m_GetRowNumByDataIndex = function(nDataIndex){
		return (nDataIndex%this.m_RowNum);
	}			
	
	this.m_getCurColumn = function(){		
		return parseInt(this.m_curFocusItemIndex/this.m_RowNum);
	}	

	this.m_getCurRow = function(){
			return (this.m_curFocusItemIndex%this.m_RowNum);
	}
		
	// for Arrow operation
	this.m_leftArrowWidgetMouseClick = function(){
		if(this.m_bIsAnimationIng == true){
			return true;
		}	
		
		this.m_bIsAnimationIng = true;
		(this.m_bReverseFlag == false)?this.prePage() : this.nextPage();
		
		//show arrow by case
		this.m_showArrow();			
	}	
	this.m_leftArrowWidgetMouseClickBind = this.m_leftArrowWidgetMouseClick.bind(this);
	
	this.m_rightArrowWidgetMouseClick = function(){
		if(this.m_bIsAnimationIng == true){
			return true;
		}	
		
		this.m_bIsAnimationIng = true;
		(this.m_bReverseFlag == false)?this.nextPage() : this.prePage();
		
		//show arrow by case
		this.m_showArrow();	
	}	
	this.m_rightArrowWidgetMouseClickBind = this.m_rightArrowWidgetMouseClick.bind(this);	
				
	this.m_hideArrow = function(){
		if(this.m_rightArrowWidget == null || this.m_leftArrowWidget == null){
			return ;
		}
		
		this.m_rightArrowWidget.hide();
		this.m_leftArrowWidget.hide();		
	}
	
	this.m_showArrow =function(){
		if(this.m_rightArrowWidget == null || this.m_leftArrowWidget == null){
			return ;
		}

		//check if page num is one
		if(this.m_PageNum() == 1){
			this.m_rightArrowWidget.hide();
			this.m_leftArrowWidget.hide();
			return;
		}
		
		//check if on the first page
		if(this.m_curDataStartIndex > 0){
			(this.m_bReverseFlag == false)?this.m_leftArrowWidget.show():this.m_rightArrowWidget.show();
		}
		else
		{
			(this.m_bReverseFlag == false)?this.m_leftArrowWidget.hide():this.m_rightArrowWidget.hide();
		}
				
		//check if on the last page
		if((this.m_curDataStartIndex + this.m_RowNum * this.m_DisplayAreaColumnNum) < this.m_nRealTotalNum){
			(this.m_bReverseFlag == false)?this.m_rightArrowWidget.show():this.m_leftArrowWidget.show();
		}
		else
		{
			(this.m_bReverseFlag == false)?this.m_rightArrowWidget.hide():this.m_leftArrowWidget.hide();
		}
}
		
	// for focus operation
	this.m_showFocus = function(){
		if(this.m_CursorInstance == null)
		{
			return;			
		}			
		
		if(this.m_fristShowCursor == true)
		{
			this.m_fristShowCursorTimeOutHandler = Volt.setTimeout(function(firstObj){
				firstObj.m_moveFocusCursor();
				firstObj.m_CursorInstance.show();
			}, 100, this);
			
			this.m_fristShowCursor = false;				
		}
		else
		{
			this.m_CursorInstance.show();
		}
	}
	
	this.m_hideCursor = function(){
		if(this.m_CursorInstance){
			this.m_CursorInstance.hide();
			}
	}	
	
	this.m_moveFocusCursor = function(){
		if(this.m_CursorInstance == null){
			return;}
		var nTmpx =	this.m_nHorizontalOffSet + this.m_getCurColumn()*(this.m_ItemWidth + this.m_ItemXGap);	
		var nTmpy = this.m_nVeticalOffSet + this.m_getCurRow()*(this.m_ItemHeight + this.m_ItemYGap);
		nTmpx = this.m_ResetCursorXPositon(nTmpx);
		this.m_CursorInstance.move(nTmpx,nTmpy,this.m_ItemWidth,this.m_ItemHeight);
	}

	this.m_ResetCursorXPositon = function(nTmpx){
		var	nNewTmpx = nTmpx;
		if(this.m_bAlignSide == true){
			if(this.m_bReverseFlag == true){
				if(this.m_currentAlignState == this.alignState.STATE_ALIGN_LEFT){
					nNewTmpx = nTmpx - this.m_GetAlignRightLastPageOffSet();
				}
				nNewTmpx = nNewTmpx + this.m_nReverseAlignOffSet;				
			}
			else{
				if(this.m_currentAlignState == this.alignState.STATE_ALIGN_RIGHT){
					nNewTmpx = nTmpx + this.m_GetAlignRightLastPageOffSet();
				}			
			}
		}		
		return nNewTmpx;
	}
	
	this.m_ChangeFocus = function(oldFocusIndex, newFocusIndex){
		if(oldFocusIndex == newFocusIndex){
			return;
		}
	
		var oldFocusRenderIndex = oldFocusIndex + this.m_CashColumNum * this.m_RowNum;
		var newFocusRenderIndex = newFocusIndex + this.m_CashColumNum * this.m_RowNum;
			
		this.m_UnHighlightItem(oldFocusRenderIndex);
		this.m_HighlightItem(newFocusRenderIndex);
			
		//call focus change callback
		var	nOldDataIndex = this.m_GetDataIndexByFocusIndex(oldFocusIndex);			
		var	nNewDataIndex = this.m_GetDataIndexByFocusIndex(newFocusIndex);
			
		//call focus out function
		this.m_FocusOutCBCall(nOldDataIndex, oldFocusRenderIndex);
		
		//call focus in function
		this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
	};			
	
	this.m_GetDataIndexByFocusIndex = function(nFocusIndex){
		var nDataIndex;
		if(this.m_bReverseFlag == false)
		{
			nDataIndex = this.m_curDataStartIndex + nFocusIndex;
		}
		else
		{
			var nColumNum = (this.m_DisplayAreaColumnNum -1) - this.m_GetCurColumByDataIndex(nFocusIndex);
			var nRowNum = this.m_GetRowNumByDataIndex(nFocusIndex);				
				nDataIndex = this.m_curDataStartIndex + nColumNum*this.m_RowNum + nRowNum;		
		}

		return nDataIndex;
	}
		
	this.m_UnHighlightItem = function(nRenderIndex){
		if(this.m_bSupportEnlargeItem == false){
			return;
		}
	
		var tmpOldCloumIndex = this.m_GetCurColumByDataIndex(nRenderIndex);			
		var tmpOldRowIndex = this.m_GetRowNumByDataIndex(nRenderIndex);							
		var rootObject = this.m_ItemRenderArray[tmpOldCloumIndex][tmpOldRowIndex];		
		rootObject.pivot = {x:0.5,y:0.5};
		
		var scaleAni = new Animation(100);
		scaleAni.addProperty("scale.x", 1.0);
		scaleAni.addProperty("scale.y", 1.0);
		scaleAni.addProperty("depth", 0);
		rootObject.animate(scaleAni, function(){});		
	}	
			
	this.m_HighlightItem = function(nRenderIndex){
		if(this.m_bSupportEnlargeItem == false){
			return;
		}
	
		var tmpNewCloumIndex = this.m_GetCurColumByDataIndex(nRenderIndex);
		var tmpNewRowIndex = this.m_GetRowNumByDataIndex(nRenderIndex);			
		var rootObject = this.m_ItemRenderArray[tmpNewCloumIndex][tmpNewRowIndex];
		if(this.m_bAlignSide == true)
		{
			this.m_ChangePivotOfRootWidget(nRenderIndex,rootObject);
		}

		var scaleAni = new Animation(100);
		scaleAni.addProperty("scale.x", 1.12);
		scaleAni.addProperty("scale.y", 1.12);
		scaleAni.addProperty("depth", 0.1);		
		rootObject.animate(scaleAni, function(){});		
	}	
	
	this.m_ChangePivotOfRootWidget = function(nRenderIndex,rootObject){
		var nCloumnNum = this.m_GetCurColumByDataIndex(nRenderIndex);
		var nRowNum = this.m_GetRowNumByDataIndex(nRenderIndex);
		if(nRowNum == 0){
			if(nCloumnNum == this.m_CashColumNum){
				rootObject.pivot = {x:0,y:0};
			}
			else if(nCloumnNum == (this.m_CashColumNum + this.m_DisplayAreaColumnNum -1)){
				rootObject.pivot = {x:1,y:0};
			}
			else{
				rootObject.pivot = {x:0.5,y:0};
			}		
		}
		else if(nRowNum == (this.m_RowNum - 1)){
			if(nCloumnNum == this.m_CashColumNum){
				rootObject.pivot = {x:0,y:1};
			}
			else if(nCloumnNum == (this.m_CashColumNum + this.m_DisplayAreaColumnNum -1)){
				rootObject.pivot = {x:0.5,y:1};
			}
			else{
				rootObject.pivot = {x:1,y:1};
			}
		}
		else{
			if(nCloumnNum == this.m_CashColumNum){
				rootObject.pivot = {x:0,y:0.5};
			}
			else if(nCloumnNum == (this.m_CashColumNum + this.m_DisplayAreaColumnNum -1)){
				rootObject.pivot = {x:0.5,y:0.5};
			}
			else{
				rootObject.pivot = {x:1,y:0.5};
			}		
		}
	}
	
	// for render operation	
	this.m_FocusItemRenderIndex = function(){
		return this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;	
	}
			
	this.m_getRenderByRenderIndex = function(nRenderIndex){
		//check nRenderIndex
		if(nRenderIndex < 0 || nRenderIndex >= this.m_RenderCloumNum*this.m_RowNum){
			return;	
		}
					
		//get column and row number by render index
		var tmpNewColumnIndex = this.m_GetCurColumByDataIndex(nRenderIndex);
		var tmpNewRowIndex = this.m_GetRowNumByDataIndex(nRenderIndex);	
		
		return this.m_ItemRenderArray[tmpNewColumnIndex][tmpNewRowIndex];	
	}
		
	// for create and update render
	this.m_updataDataToItemRender = function(nDataIndex){	
		//if(nDataIndex >= 0 && nDataIndex < this.m_nRealTotalNum)
		if(nDataIndex >= 0 && nDataIndex < this.m_nTotalNumWithBlankNum)		
		{				
			var nRelativeDataIndex =  nDataIndex - this.m_curDataStartIndex;				
			//one more column data cash
			//var RelativeDataLeftLimit = 0- this.m_RowNum* this.m_CashColumNum;				
			//var RelativeDataRightLimit = this.m_RowNum *(this.m_DisplayAreaColumnNum +this.m_CashColumNum);
		
			//when flick over need cash more column data
			var RelativeDataLeftLimit = 0- this.m_RowNum*(this.m_ItemRenderArray.length - this.m_DisplayAreaColumnNum - this.m_CashColumNum);				
			var RelativeDataRightLimit = this.m_RowNum *(this.m_ItemRenderArray.length -this.m_CashColumNum);
			
			if((nRelativeDataIndex>= 0) && (nRelativeDataIndex < RelativeDataRightLimit))
			{
				var nTmpRow = this.m_GetRowNumByDataIndex(nRelativeDataIndex);				
				var nTmpColum = this.m_GetCurColumByDataIndex(nRelativeDataIndex);
				var realRenderCloumIndex;
				if(this.m_bReverseFlag == false){
					realRenderCloumIndex = nTmpColum + this.m_CashColumNum;	
				}
				else{
					var tmpCalCloumnNum = this.m_ItemRenderArray.length -this.m_CashColumNum;
					realRenderCloumIndex =tmpCalCloumnNum - nTmpColum -1;		
				}
												
				if(this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow] != "undefined")
				{
					//check if the useless data
					if(nDataIndex >= this.m_nRealTotalNum){
						this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].color = {r:0, g:0, b:255, a:100};
						return;
					}

					//reset color of tmpRender
					this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].color = {r:0, g:0, b:0, a:0};					
				
					//call itemLoad CB
					if(this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].bItemLoad == false)
					{
						this.m_ItemLoadCall(nDataIndex, this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow]);									
						this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].bItemLoad = true;
						
						//bind data index to render
						this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].nBindDataIndex = nDataIndex;								
						
						//add mouse call back
						this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].addEventListener("OnMouseClick", this.m_ListItemMouseClickBind);
						this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].addEventListener("OnMouseOver", this.m_ListItemMouseOverBind);	
						this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].addEventListener("OnMouseDown", this.m_ListItemMouseDownBind);
						
						if(this.m_bEditModule == false){
							//update depth
							this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].depth = 0;
							this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].drawWithDepth = true;
						}
					}
					else
					{
						//bind data index to render
						this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow].nBindDataIndex = nDataIndex;		
						
						// call update callback
						this.m_ItemUpdateCBCall(nDataIndex, this.m_ItemRenderArray[realRenderCloumIndex][nTmpRow]);
					}
				}			
			}
			else if((nRelativeDataIndex >= RelativeDataLeftLimit) && (nRelativeDataIndex <0)) 
			{			
				var tmpRelativeDataIndex = (0 - nRelativeDataIndex) -1;					
				var nTmpRowB = this.m_GetRowNumByDataIndex(tmpRelativeDataIndex);				
				var nTmpColumB = this.m_GetCurColumByDataIndex(tmpRelativeDataIndex) +1;	
					
				var reallRenderRowIndexB = (this.m_RowNum -1) - nTmpRowB;
				var realRenderCloumIndexB;															
				//var realRenderCloumIndexB = this.m_CashColumNum - nTmpColumB;	
				
				if(this.m_bReverseFlag == false){
					realRenderCloumIndexB = this.m_curDataStartColumn - nTmpColumB;
				}
				else{
					realRenderCloumIndexB = this.m_curDataStartColumn + nTmpColumB;
				}
								
				if(this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB] != "undefined")
				{
					//call itemLoad CB
					if(this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].bItemLoad == false)
					{				
						this.m_ItemLoadCall(nDataIndex, this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB]);									
						this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].bItemLoad = true;						
						//bind data index to render
						this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].nBindDataIndex = nDataIndex;												
						//add mouse call back
						this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].addEventListener("OnMouseClick", this.m_ListItemMouseClickBind);
						this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].addEventListener("OnMouseOver", this.m_ListItemMouseOverBind);
						this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].addEventListener("OnMouseDown", this.m_ListItemMouseDownBind);																		
						
						if(this.m_bEditModule == false){
							//update depth
							this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].depth = 0;
							this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].drawWithDepth = true;
						}
					}					
					else
					{
						//bind data index to render
						this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB].nBindDataIndex = nDataIndex;						
						// call update callback
						this.m_ItemUpdateCBCall(nDataIndex, this.m_ItemRenderArray[realRenderCloumIndexB][reallRenderRowIndexB]);											
					}													
				}			
			}				
		}
	}		
		
	this.m_UpdateDataToRender = function(nFromIndex, nEndIndex){		
		for(var nDataIndex = nFromIndex; nDataIndex < nEndIndex; nDataIndex++){
			this.m_updataDataToItemRender(nDataIndex);
		}				
	}		
					
	this.m_CreateOneRenderItem = function(nX, nY){	
		var tmpRender = new Widget({
					x: nX,
					y: nY,
					width:this.m_ItemWidth,
					height:this.m_ItemHeight,
					parent:this.m_ScrollWidget,
					color: {r: 0, g: 255, b: 0, a: 0},				
				});		
	
		tmpRender.bItemLoad = false;
		return tmpRender;
	}
			
	//for common move 
	this.m_MoveLeft = function(bDragFlag){
		if(this.m_ScrollWidget == null){
			return;
		}		
			
		//firstly, update data to the right cash column 
		var nDataStartIndex;
		if(this.m_bReverseFlag == false)
		{
			nDataStartIndex = this.m_curDataStartIndex + (this.m_DisplayAreaColumnNum +1) * this.m_RowNum;	
		}
		else
		{
			nDataStartIndex = this.m_curDataStartIndex - this.m_CashColumNum * this.m_RowNum;
		}	
		for(var tmpIndex =0; tmpIndex < this.m_RowNum; tmpIndex++)
		{
			//print("m_MoveLeft nDataStartIndex =========== " + (nDataStartIndex + tmpIndex));
			this.m_updataDataToItemRender(nDataStartIndex + tmpIndex);		
		}
		
		if(bDragFlag != true)
		{
			//UnHighligh old focus item
			var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
			this.m_UnHighlightItem(oldFocusRenderIndex);
			var nOldDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
			//call focus out function
			this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);		
		}
		
		//add new one column render at last
		this.m_ItemRenderArray.push(new Array());
		var nlastColumnIndex = this.m_ItemRenderArray.length -1;		
		var nXOffSet = this.m_firstRenderItemX;
		var nYOffSet = this.m_nVeticalOffSet;
		for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++)
		{			
			var nX = nXOffSet + nlastColumnIndex*(this.m_ItemWidth + this.m_ItemXGap);
			var nY = nYOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);			
			var tmpRender = this.m_CreateOneRenderItem(nX, nY);
			this.m_ItemRenderArray[nlastColumnIndex][nRowIndex] = tmpRender;
		}			
			
		var unLoadDataStartIndex = this.m_curDataStartIndex - this.m_CashColumNum * this.m_RowNum;
		//remove the first column render
		for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++)
		{
			//call item unload
			var unloadRenderItem = this.m_ItemRenderArray[0][nRowIndex];
			this.m_ItemUnLoadCall(unLoadDataStartIndex + nRowIndex ,unloadRenderItem);
		
			// destroy the item render	
			unloadRenderItem.destroy();
		}
		this.m_ItemRenderArray.shift();
				
		//update first start data index
		if(this.m_bReverseFlag == false){
			this.m_curDataStartIndex = this.m_curDataStartIndex + this.m_RowNum;
		}
		else{
			this.m_curDataStartIndex = this.m_curDataStartIndex - this.m_RowNum;		
		}
							
		if(bDragFlag != true){		
			if(this.m_bReverseFlag == false){
				//check if need focus on last item,when the last column's data is not full
				this.m_CheckIfNeedFocusOnLastItem(false);			
			}
		
			//Highlight new focus item
			var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
			this.m_HighlightItem(newFocusRenderIndex)
			var nNewDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
			//call focus in function
			this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);		
		}		

		//change first render Item's X 
		this.m_firstRenderItemX	= this.m_firstRenderItemX + (this.m_ItemWidth + this.m_ItemXGap);

		//do move animation
		this.m_SetDestOfScrollWidgetMoveLeft();
		var moveLeft = new Animation(100);
		moveLeft.addProperty("x", this.m_ScrollWidgetXPosition);						

		this.m_ScrollWidget.animate(moveLeft, this.m_ListMoveLeftCBBind);						
	}
	
	this.m_SetDestOfScrollWidgetMoveLeft = function(){
		if(this.m_bAlignSide == true){
			if(this.m_bReverseFlag == true){
				if(this.m_currentAlignState == this.alignState.STATE_ALIGN_LEFT){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition - this.m_GetAlignRightMoveLeftOffset();
					this.m_currentAlignState = this.alignState.STATE_NORMAL;
				}
				else if(this.m_currentAlignState == this.alignState.STATE_NORMAL){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition-(this.m_ItemWidth + this.m_ItemXGap);
				}				
			}
			else{
				if(this.m_currentAlignState == this.alignState.STATE_NORMAL){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition - this.m_GetAlignRightMoveLeftOffset();			
					this.m_currentAlignState = this.alignState.STATE_ALIGN_RIGHT;
				}
				else if(this.m_currentAlignState == this.alignState.STATE_ALIGN_RIGHT){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition-(this.m_ItemWidth + this.m_ItemXGap);				
				}			
			}
		}
		else{
			//common case
			this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition-(this.m_ItemWidth + this.m_ItemXGap);		
		}
	}
	
	this.m_ListMoveLeftCB = function(){		
		//move focus Cursor
		this.m_moveFocusCursor();		
		
		this.m_bIsAnimationIng = false;
	}
	this.m_ListMoveLeftCBBind = this.m_ListMoveLeftCB.bind(this);

	this.m_MoveRight = function(bDragFlag){	
		if(this.m_ScrollWidget == null){
			return;
		}	
	
		//firstly, update data to the left cash column
		var nDataStartIndex;
		if(this.m_bReverseFlag == false)
		{
			nDataStartIndex = this.m_curDataStartIndex - this.m_CashColumNum * this.m_RowNum;		
		}
		else
		{
			nDataStartIndex = this.m_curDataStartIndex + (this.m_DisplayAreaColumnNum +1) * this.m_RowNum;
		}
	
		for(var tmpIndex =0; tmpIndex < this.m_RowNum; tmpIndex++)
		{
			this.m_updataDataToItemRender(nDataStartIndex + tmpIndex);
		}
		
		if(bDragFlag != true)
		{
			//UnHighligh old focus item
			var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
			this.m_UnHighlightItem(oldFocusRenderIndex);
			var nOldDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
			//call focus out function
			this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);		
		}	
				
		//add new  first column 
		this.m_ItemRenderArray.unshift(new Array());
		var nXOffSet = this.m_firstRenderItemX;
		var nYOffSet = this.m_nVeticalOffSet;
		for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++)
		{
			var nX = nXOffSet - (this.m_ItemWidth + this.m_ItemXGap);
			var nY = nYOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);			
			var tmpRender = this.m_CreateOneRenderItem(nX, nY);
			this.m_ItemRenderArray[0][nRowIndex] = tmpRender;
		}				
					
		//remove old last column
		var nlastColumnIndex = this.m_ItemRenderArray.length -1;			
		var unLoadDataStartIndex = this.m_curDataStartIndex + (this.m_CashColumNum + this.m_DisplayAreaColumnNum ) * this.m_RowNum;				
		for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++)
		{
			//call unload callback
			var unloadRenderItem = this.m_ItemRenderArray[nlastColumnIndex][nRowIndex];
			this.m_ItemUnLoadCall(unLoadDataStartIndex + nRowIndex ,unloadRenderItem);			
			
			// destroy the item render			
			unloadRenderItem.destroy();
		}
		this.m_ItemRenderArray.pop();		
										
		//update first start data index
		if(this.m_bReverseFlag == false)
		{
			this.m_curDataStartIndex = this.m_curDataStartIndex - this.m_RowNum;		
		}
		else
		{
			this.m_curDataStartIndex = this.m_curDataStartIndex + this.m_RowNum;
		}
								
		if(bDragFlag != true)
		{
			if(this.m_bReverseFlag == true){
				//check if need focus on last item,when the last column's data is not full
				this.m_CheckIfNeedFocusOnLastItem(false);			
			}				
			//Highlight new focus item
			var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;		
			this.m_HighlightItem(newFocusRenderIndex);			
			var nNewDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
			//call focus in function
			this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
		}

		//change first render Item's X
		this.m_firstRenderItemX =  this.m_firstRenderItemX - (this.m_ItemWidth + this.m_ItemXGap);		

		
		//do move animation
		this.m_SetDestOfScrollWidgetMoveRight();
		var moveRight = new Animation(100);
		moveRight.addProperty("x", this.m_ScrollWidgetXPosition);			
		
		this.m_ScrollWidget.animate(moveRight, this.m_ListMoveRightCBBind);			
		}					
	
	this.m_SetDestOfScrollWidgetMoveRight = function(){
		if(this.m_bAlignSide == true){
			if(this.m_bReverseFlag == true){
				if(this.m_currentAlignState == this.alignState.STATE_NORMAL){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + this.m_GetAlignRightMoveLeftOffset();				
					this.m_currentAlignState = this.alignState.STATE_ALIGN_LEFT;
				}
				else if(this.m_currentAlignState == this.alignState.STATE_ALIGN_LEFT){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + (this.m_ItemWidth + this.m_ItemXGap);				
				}		
			}
			else{
				if(this.m_currentAlignState == this.alignState.STATE_ALIGN_RIGHT){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + this.m_GetAlignRightMoveLeftOffset();			
					this.m_currentAlignState = this.alignState.STATE_NORMAL;
				}
				else if(this.m_currentAlignState == this.alignState.STATE_NORMAL){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + (this.m_ItemWidth + this.m_ItemXGap);				
				}				
			}
		

		}
		else{
			//common case
			this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + (this.m_ItemWidth + this.m_ItemXGap);		
		}
	}
	
	this.m_ListMoveRightCB = function(){		
		//move focus Cursor
		this.m_moveFocusCursor();				
		this.m_bIsAnimationIng = false;		
	}
	this.m_ListMoveRightCBBind = this.m_ListMoveRightCB.bind(this);				
		
	this.m_CheckIfOnlyOnePageAndAtLastColumn =function(){
		var bOnePageAndAtLastColumn = false;
		if(this.m_PageNum() == 1)
		{
			var nLastDataIndex = this.m_nRealTotalNum -1;
			var nLastDataCloumn = this.m_GetCurColumByDataIndex(nLastDataIndex); 
			
			if(this.m_bReverseFlag == true){
				nLastDataCloumn = (this.m_DisplayAreaColumnNum - 1) - nLastDataCloumn;
			}
			
			bOnePageAndAtLastColumn = (nLastDataCloumn == this.m_getCurColumn())? true:false;
		}	
		return bOnePageAndAtLastColumn;
	}
	
	this.m_CheckIfNeedFocusOnLastItem = function(bNeedCheckColumnNum){	
		//check if the last column's data is not full
		var nLastDataIndex = this.m_nRealTotalNum -1;		  
		var nTmpLastDataStartIndex = this.m_curDataStartIndex + this.m_DisplayAreaColumnNum * this.m_RowNum -1;		
		if( nLastDataIndex >= nTmpLastDataStartIndex){
			return false;
		}
		
		//check the one page case
		if(this.m_PageNum() == 1){
			if(this.m_GetRowNumByDataIndex(nLastDataIndex) == (this.m_RowNum -1)){
				return false;
			}	
		}
		
		var nLastDataRelativeIndex = nLastDataIndex - this.m_curDataStartIndex;
		var nCloumNumOfLastDataRelativeIndex = this.m_GetCurColumByDataIndex(nLastDataRelativeIndex);
		var nRowNumOfLastDataRelativeIndex = this.m_GetRowNumByDataIndex(nLastDataRelativeIndex);
		var bAtLastSecondColumn = true;
		if(bNeedCheckColumnNum == true)
		{
			//check if at the last second display column				
			var nLastSecondColumnIndex = nCloumNumOfLastDataRelativeIndex -1;
			if(this.m_bReverseFlag == true){			
				nLastSecondColumnIndex = (this.m_DisplayAreaColumnNum -1) - nLastSecondColumnIndex;
			}				
			bAtLastSecondColumn =  (this.m_getCurColumn() == nLastSecondColumnIndex) ?true :false;		
		}
				
		if(bAtLastSecondColumn && nTmpLastDataStartIndex > nLastDataIndex)
		{
			//focus on last item
			if(this.m_bReverseFlag == false){
				this.m_curFocusItemIndex = nLastDataIndex - this.m_curDataStartIndex;
			}
			else
			{
				var nReverseCloumNumOfLastDataRelativeIndex = (this.m_DisplayAreaColumnNum -1) - nCloumNumOfLastDataRelativeIndex;
				this.m_curFocusItemIndex = nReverseCloumNumOfLastDataRelativeIndex*this.m_RowNum + nRowNumOfLastDataRelativeIndex;
			}
			return true;
		}		  
		return false;
	}	
		
	this.m_CheckIfNeedFocusOnPreColumnLastOne = function(){
		//check if only one column data and focus on the last item
		if(this.m_nRealTotalNum <= this.m_RowNum){
			var nRowNum = this.m_GetRowNumByDataIndex(this.m_nRealTotalNum -1)
			if(nRowNum == this.m_getCurRow()){
				return true;
			}
		}
	
		var nLastDataIndex = this.m_nRealTotalNum -1;
		var nCurFocusDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
		//check if focus on last item
		if(nCurFocusDataIndex == nLastDataIndex){					
			//change focus on preview column's last item
			if(this.m_bReverseFlag == false){
				this.m_curFocusItemIndex = (this.m_getCurColumn() * this.m_RowNum) -1;	
			}
			else
			{
				this.m_curFocusItemIndex =  (this.m_getCurColumn() + 2)* this.m_RowNum -1;
			}
			
			return true;
		}
		return false;
	}
	
	//for cycle move
	this.m_CycleCallRight = function(){
		if(this.m_ScrollWidget == null){
			return;
		}			
			
		//hide arrows	
		this.m_hideArrow();
			
		//hide cursor first
		this.m_hideCursor();				
			
		/*
		//for test
		//hide all render item
		this.m_unloadRenderItem();		
		return;
		*/
								
		//prepare for animation
		var moveCenterToRight = new Animation(500);
		var nMoveRightDistance = (this.m_CashColumNum + this.m_DisplayAreaColumnNum + 1) * (this.m_ItemWidth + this.m_ItemXGap);		
		moveCenterToRight.addProperty("x", this.m_ScrollWidgetXPosition + nMoveRightDistance);		
		
		this.m_ScrollWidget.animate(moveCenterToRight, this.m_MoveCenterToRightCBBind);							
	}
	
	this.m_MoveCenterToRightCB = function(){		
		
		//hide scroll widget
		this.m_ScrollWidget.hide();
	
		//hide all render item
		this.m_unloadRenderItem();		
		
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);
		var nOldDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
		this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);	
		
		//update first start data index
		var nLastColumRemainderData = this.m_nRealTotalNum % this.m_RowNum;			
		if(this.m_bReverseFlag == false){
			this.m_curDataStartIndex = 0;
		}
		else{
			if(nLastColumRemainderData != 0){
				this.m_curDataStartIndex = this.m_nRealTotalNum - nLastColumRemainderData - (this.m_DisplayAreaColumnNum -1)*this.m_RowNum;	
			}
			else{
				this.m_curDataStartIndex = this.m_nRealTotalNum - this.m_DisplayAreaColumnNum * this.m_RowNum;
			}
		}
		
		//update data page
		this.updateCurPage();		
		
		//set new focusIndex
		if(this.m_bReverseFlag == false){
			var oldFocusItemRow = this.m_getCurRow();
			this.m_curFocusItemIndex = oldFocusItemRow;
		}
		else{
			if(this.m_nRealTotalNum % this.m_RowNum == 0){
				var oldFocusItemRow = this.m_getCurRow();
				this.m_curFocusItemIndex = oldFocusItemRow;			
			}
			else{
				this.m_curFocusItemIndex = (nLastColumRemainderData -1);
			}
		}

			
		//reset scroll widget x position
		this.m_ScrollWidget.x = 0 - (this.m_CashColumNum + this.m_DisplayAreaColumnNum) * (this.m_ItemWidth + this.m_ItemXGap);				
		this.m_ScrollWidgetXPosition = 0;
		
		//update all render item x
		this.m_firstRenderItemX = this.m_nHorizontalOffSet - (this.m_ItemWidth + this.m_ItemXGap)* this.m_CashColumNum;
		for(var nCloumnIndex = 0;  nCloumnIndex < this.m_RenderCloumNum;  nCloumnIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){				
				var tmpRender = this.m_ItemRenderArray[nCloumnIndex][nRowIndex];
				tmpRender.x = this.m_firstRenderItemX + nCloumnIndex*(this.m_ItemWidth + this.m_ItemXGap);;				
			}	
		}			
		
		this.m_ScrollWidget.show();

		//move from left to centre animation
		this.m_SetDestOfScrollWidgetMoveLeftToCentre();
		var moveLeftToCenter = new Animation(400);
		moveLeftToCenter.addProperty("x", this.m_ScrollWidgetXPosition);			
		this.m_ScrollWidget.animate(moveLeftToCenter,this.m_MoveLeftToCenterCBBind);
	}	
	this.m_MoveCenterToRightCBBind = this.m_MoveCenterToRightCB.bind(this);		
	
	this.m_SetDestOfScrollWidgetMoveLeftToCentre = function(){
		if(this.m_bAlignSide == true){
			if(this.m_bReverseFlag == true){
				if(this.m_currentAlignState == this.alignState.STATE_NORMAL){
					this.m_ScrollWidgetXPosition = 0;
					this.m_currentAlignState = this.alignState.STATE_ALIGN_LEFT;
				}
			}
			else{
				if(this.m_currentAlignState == this.alignState.STATE_ALIGN_RIGHT){
					this.m_ScrollWidgetXPosition = 0;
					this.m_currentAlignState = this.alignState.STATE_NORMAL;
				}			
			}
		}
		else{
			//common case
			this.m_ScrollWidgetXPosition = 0;		
		}
	}	
	
	this.m_MoveLeftToCenterCB = function(){	
		//highlight Item
		var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;		
		this.m_HighlightItem(newFocusRenderIndex);
		var nNewDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);		
		this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
		
		//show cursor
		this.m_moveFocusCursor();
		this.m_showFocus();
		
		//show arrow by case		
		this.m_showArrow();	
		
		this.m_bIsAnimationIng = false;	
	}
	this.m_MoveLeftToCenterCBBind = this.m_MoveLeftToCenterCB.bind(this);	
	
	this.m_CycleCallLeft = function(){	
		if(this.m_ScrollWidget == null){
			return;
		}		
			
		//hide arrows	
		this.m_hideArrow();	
			
		//hide cursor first
		this.m_hideCursor();
			
		//prepare for animation			
		var m_moveCenterToLeft = new Animation(400);
		var nMoveLeftDistance = (this.m_CashColumNum + this.m_DisplayAreaColumnNum + 1) * (this.m_ItemWidth + this.m_ItemXGap);
		m_moveCenterToLeft.addProperty("x", this.m_ScrollWidgetXPosition - nMoveLeftDistance);						
		this.m_ScrollWidget.animate(m_moveCenterToLeft,this.m_moveCenterToLeftBind);		
		}									
	
	this.m_moveCenterToLeft = function(){
		//hide scroll widget
		this.m_ScrollWidget.hide();
	
		//hide all render item
		this.m_unloadRenderItem();
		
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);
		var nOldDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
		this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);
		
		//update first start data index			
		var nLastColumRemainderData = this.m_nRealTotalNum % this.m_RowNum;
		if(this.m_bReverseFlag == false){
			if(nLastColumRemainderData != 0){
				this.m_curDataStartIndex = this.m_nRealTotalNum - nLastColumRemainderData - (this.m_DisplayAreaColumnNum -1)*this.m_RowNum;	
			}
			else{
				this.m_curDataStartIndex = this.m_nRealTotalNum - this.m_DisplayAreaColumnNum * this.m_RowNum;
			}					
		}
		else{
			this.m_curDataStartIndex = 0;
		}

		//update data page
		this.updateCurPage();		
		
		//set new focusIndex
		if(this.m_bReverseFlag == false){
			if(this.m_nRealTotalNum % this.m_RowNum == 0){
				var oldFocusItemRow = this.m_getCurRow();
				this.m_curFocusItemIndex = oldFocusItemRow + (this.m_DisplayAreaColumnNum -1)*this.m_RowNum;			
			}
			else
			{
				this.m_curFocusItemIndex = (nLastColumRemainderData -1) + (this.m_DisplayAreaColumnNum -1)*this.m_RowNum;
			}
		}
		else
		{
			this.m_curFocusItemIndex = this.m_getCurRow() + (this.m_DisplayAreaColumnNum -1)*this.m_RowNum;
		}
		
		//reset scroll widget x position
		this.m_ScrollWidget.x = (this.m_CashColumNum + this.m_DisplayAreaColumnNum) * (this.m_ItemWidth + this.m_ItemXGap);				
		this.m_ScrollWidgetXPosition = 0;		
		
		//update all render item x
		this.m_firstRenderItemX = this.m_nHorizontalOffSet - (this.m_ItemWidth + this.m_ItemXGap)* this.m_CashColumNum;
		for(var nCloumnIndex = 0;  nCloumnIndex < this.m_RenderCloumNum;  nCloumnIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){				
				var tmpRender = this.m_ItemRenderArray[nCloumnIndex][nRowIndex];
				tmpRender.x = this.m_firstRenderItemX + nCloumnIndex*(this.m_ItemWidth + this.m_ItemXGap);;				
			}	
		}		
		
		this.m_ScrollWidget.show();
		//move right to centre animate
		this.m_SetDestOfScrollWidgetMoveRightToCenter();
		var moveRightToCenter = new Animation(400);
		moveRightToCenter.addProperty("x", this.m_ScrollWidgetXPosition);		
		this.m_ScrollWidget.animate(moveRightToCenter,this.m_moveRightToCenterCBBind);
	}
	this.m_moveCenterToLeftBind = this.m_moveCenterToLeft.bind(this);	
		
	this.m_moveRightToCenterCB = function(){
		//highlight Item		
		var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;		
		this.m_HighlightItem(newFocusRenderIndex);
		var nNewDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
		this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
		
		//show cursor
		this.m_moveFocusCursor();
		this.m_showFocus();
		
		//show arrow by case		
		this.m_showArrow();		
		this.m_bIsAnimationIng = false;				
	}
	this.m_moveRightToCenterCBBind = this.m_moveRightToCenterCB.bind(this);
	
	this.m_SetDestOfScrollWidgetMoveRightToCenter = function(){
		if(this.m_bAlignSide == true){
			if(this.m_bReverseFlag == true){
				if(this.m_currentAlignState == this.alignState.STATE_ALIGN_LEFT){
					this.m_ScrollWidgetXPosition = this.m_GetAlignRightLastPageOffSet();
					this.m_currentAlignState = this.alignState.STATE_NORMAL;
				}			
			}
			else{
				if(this.m_currentAlignState == this.alignState.STATE_NORMAL){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + this.m_GetAlignRightLastPageOffSet();			
					this.m_currentAlignState = this.alignState.STATE_ALIGN_RIGHT;
				}						
			}
		}
		else{
			//common case
			this.m_ScrollWidgetXPosition = 0;		
		}
	}
	
	this.m_unloadRenderItem = function(){
		var nTmpDataStartIndex;
		if(this.m_bReverseFlag == false){
			nTmpDataStartIndex = this.m_curDataStartIndex - this.m_CashColumNum * this.m_RowNum;
		}
		else{
			nTmpDataStartIndex = this.m_curDataStartIndex + (this.m_CashColumNum + this.m_DisplayAreaColumnNum)* this.m_RowNum -1;
		}
		
		for(var nCloumnIndex = 0;  nCloumnIndex < this.m_RenderCloumNum;  nCloumnIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){				
				var tmpRender = this.m_ItemRenderArray[nCloumnIndex][nRowIndex];
				this.m_ItemUnLoadCall(nTmpDataStartIndex,tmpRender);
				tmpRender.bItemLoad = false;
				if(this.m_bReverseFlag == false){
					nTmpDataStartIndex = nTmpDataStartIndex +1;
				}
				else{
					nTmpDataStartIndex = nTmpDataStartIndex -1;
				}
				//reset color of tmpRender
				tmpRender.color = {r:0, g:0, b:0, a:0};
			}				
		}

		if(this.m_bEditModule == true){
			this.m_UnSetAllRenderDrawingWithDepth();
		}		
	}
	
	/**
	* This function get the lists flick over to next page. 
	* @param Void
	* @return Void
	* @example 
	* @since The version 1.0 this function is added.
	*/
	//for flick over
	this.nextPage = function(){	
		if(this.m_ScrollWidget == null){
			return;}		
	
		if(this.m_bReverseFlag == true){
			this.m_ReverseNextPage();
			return;
		}
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);		
		var nOldDataIndex =  this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);				
		this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);	
		//calculate the cash column number					
		this.tmpNextPageCashCloumnNum = this.m_DisplayAreaColumnNum;
		
		//check if need reset tmpNextPageCashCloumnNum
		var nextPageEndDataIndex = this.m_curDataStartIndex + this.m_RowNum*this.m_DisplayAreaColumnNum*2 -1;
		var realLastDataIndex = this.m_nRealTotalNum -1;		
		var nLastPageEndDataRelativeIndex = realLastDataIndex - this.m_curDataStartIndex - this.m_RowNum*this.m_DisplayAreaColumnNum;
		if(realLastDataIndex < nextPageEndDataIndex){			
			this.tmpNextPageCashCloumnNum = parseInt(nLastPageEndDataRelativeIndex/this.m_RowNum) + 1;			
		}
								
		//create  cash column render obj
		var nStartCloumn = this.m_ItemRenderArray.length;
		var nEndCloumn = nStartCloumn + this.tmpNextPageCashCloumnNum;		
		var nYOffSet = this.m_nVeticalOffSet; 
		var nXOffSet = this.m_firstRenderItemX;		
		for(var nAddColumIndex =nStartCloumn; nAddColumIndex < nEndCloumn; nAddColumIndex++)	
		{	
			this.m_ItemRenderArray.push(new Array());
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
				var nX = nXOffSet + nAddColumIndex*(this.m_ItemWidth + this.m_ItemXGap);
				var nY = nYOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);			
				var tmpRender = this.m_CreateOneRenderItem(nX, nY);			
				this.m_ItemRenderArray[nAddColumIndex][nRowIndex] = tmpRender;				
			}
		}	
				
		//update data to new render obj
		var nFromIndex = this.m_curDataStartIndex + this.m_RowNum*this.m_DisplayAreaColumnNum;
		var nEndIndex = nFromIndex + this.m_RowNum*(this.m_DisplayAreaColumnNum +1);	
		this.m_UpdateDataToRender(nFromIndex,nEndIndex);	
		
		//set new focusIndex
		if(realLastDataIndex < nextPageEndDataIndex){
			var nCurFocusColumn = this.m_getCurColumn();
			if((this.m_nRealTotalNum % this.m_RowNum != 0) && (nCurFocusColumn == this.m_DisplayAreaColumnNum -1)){		
				var nLastDataRowNum	= realLastDataIndex%this.m_RowNum					
				this.m_curFocusItemIndex = (this.m_DisplayAreaColumnNum -1)*this.m_RowNum + nLastDataRowNum;			
			}		
		}
		
		//update first render Item's x
		this.m_firstRenderItemX	= this.m_firstRenderItemX + (this.m_ItemWidth + this.m_ItemXGap)*this.tmpNextPageCashCloumnNum;
		this.m_curDataStartIndex = this.m_curDataStartIndex + this.m_RowNum*this.tmpNextPageCashCloumnNum;
		
		//do move animation ,move m_ScrollWidget 	
		this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition-(this.m_ItemWidth + this.m_ItemXGap)*this.tmpNextPageCashCloumnNum;		
		this.m_SetDestOfScrollWidgetNextPage();
		var moveLeftOnePage = new Animation(400);
		moveLeftOnePage.addProperty("x", this.m_ScrollWidgetXPosition);		
		this.m_ScrollWidget.animate(moveLeftOnePage,this.MoveLeftOnePageCBBind);				
	}
	
	this.MoveLeftOnePageCB = function(){	
		//remove the first old one page render
		var nDelStartCloumn = 0;
		var nDelEndCloumn = nDelStartCloumn + this.tmpNextPageCashCloumnNum;									
		var unLoadDataStartIndex = this.m_curDataStartIndex - (this.tmpNextPageCashCloumnNum + this.m_CashColumNum)*this.m_RowNum;
				
		for(var nDestroyColumIndex =nDelStartCloumn; nDestroyColumIndex < nDelEndCloumn; nDestroyColumIndex++){
		for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
			//call item unload
			var unloadRenderItem = this.m_ItemRenderArray[nDestroyColumIndex][nRowIndex];
			this.m_ItemUnLoadCall(unLoadDataStartIndex ,unloadRenderItem);		
			unLoadDataStartIndex = unLoadDataStartIndex + 1;
			// destroy the item render	
			unloadRenderItem.destroy();}}	
				
		for(var nDelColumIndex =nDelStartCloumn; nDelColumIndex < nDelEndCloumn; nDelColumIndex++){
			this.m_ItemRenderArray.shift();
		}
			
		//Highlight new focus item
		var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;			
		this.m_HighlightItem(newFocusRenderIndex);					
		var nNewDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);	
		
		//call focus in function
		this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
		
		this.m_moveFocusCursor();			
		this.m_bIsAnimationIng = false;				
	}
	this.MoveLeftOnePageCBBind = this.MoveLeftOnePageCB.bind(this);
	
	this.m_SetDestOfScrollWidgetNextPage = function(){
		if(this.m_bAlignSide == true){			
			if((this.m_currentAlignState == this.alignState.STATE_NORMAL) && (this.m_CheckIfLastPage() == true)){
				this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + this.m_GetAlignRightLastPageOffSet();			
				this.m_currentAlignState = this.alignState.STATE_ALIGN_RIGHT;
			}	
		}
	}
	
	this.prePage = function(){
		if(this.m_ScrollWidget == null){
			return;}		
	
		if(this.m_bReverseFlag == true){
			this.m_ReversePrePage();
			return;
		}
	
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);		
		var nOldDataIndex = this.m_curDataStartIndex + this.m_curFocusItemIndex;
		this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);
		
		//calculate the cash column number					
		this.tmpPrePageCashCloumnNum = this.m_DisplayAreaColumnNum;
		
		//check if need reset tmpPrePageCashCloumnNum
		var nPrePagefirstDataIndex = this.m_curDataStartIndex - this.m_DisplayAreaColumnNum * this.m_RowNum;
		if(nPrePagefirstDataIndex < 0){		
			this.tmpPrePageCashCloumnNum =  parseInt(this.m_curDataStartIndex/this.m_RowNum);
		}
	
		//create cashed column render obj
		var nStartCloumn = 0;
		var nEndCloumn = this.tmpPrePageCashCloumnNum;				
		var nYOffSet = this.m_nVeticalOffSet; 
		var nXOffSet = this.m_firstRenderItemX;		
		for(var nAddColumIndex= nStartCloumn; nAddColumIndex < nEndCloumn; nAddColumIndex++){
			this.m_ItemRenderArray.unshift(new Array());
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
				var nX = nXOffSet - (nAddColumIndex +1)*(this.m_ItemWidth + this.m_ItemXGap);
				var nY = nYOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);			
				var tmpRender = this.m_CreateOneRenderItem(nX, nY);			
				this.m_ItemRenderArray[0][nRowIndex] = tmpRender;				
			}		
		}		
		this.m_curDataStartColumn = this.m_curDataStartColumn + this.tmpPrePageCashCloumnNum;
		
		//update data to new render obj
		var nFromIndex = this.m_curDataStartIndex - this.m_RowNum*(this.m_DisplayAreaColumnNum+1);
		var nEndIndex = nFromIndex + this.m_RowNum*(this.m_DisplayAreaColumnNum +1);
		this.m_UpdateDataToRender(nFromIndex,nEndIndex);	
		
		//update first render Item's x
		this.m_firstRenderItemX	= this.m_firstRenderItemX - (this.m_ItemWidth + this.m_ItemXGap)*this.tmpPrePageCashCloumnNum;
		this.m_curDataStartIndex = this.m_curDataStartIndex - this.m_RowNum*this.tmpPrePageCashCloumnNum;
		
		//do move animation ,move m_ScrollWidget 
		this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition+(this.m_ItemWidth + this.m_ItemXGap)*this.tmpPrePageCashCloumnNum;				
		this.m_SetDestOfScrollWidgetPrePage();
		var moveRightOnePage = new Animation(400);
		moveRightOnePage.addProperty("x", this.m_ScrollWidgetXPosition);
		this.m_ScrollWidget.animate(moveRightOnePage,this.m_MoveRightOnePageCBBind);
	}		
	
	this.m_MoveRightOnePageCB = function(){	
		var nDelEndCloumn = this.m_ItemRenderArray.length;					
		var nDelStartCloumn = nDelEndCloumn - this.tmpPrePageCashCloumnNum;
		//print("nDelEndCloumn================" + nDelEndCloumn);
		//print("nDelStartCloumn================" + nDelStartCloumn);
	
		var unLoadDataStartIndex = this.m_curDataStartIndex + (this.m_DisplayAreaColumnNum + this.m_CashColumNum)*this.m_RowNum;
		for(var nDestroyColumIndex =nDelStartCloumn; nDestroyColumIndex < nDelEndCloumn; nDestroyColumIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
			//call item unload
			var unloadRenderItem = this.m_ItemRenderArray[nDestroyColumIndex][nRowIndex];
			this.m_ItemUnLoadCall(unLoadDataStartIndex ,unloadRenderItem);	
			unLoadDataStartIndex = unLoadDataStartIndex + 1;
			// destroy the item render	
			unloadRenderItem.destroy();}}			

		for(var nDelColumIndex =nDelStartCloumn; nDelColumIndex < nDelEndCloumn; nDelColumIndex++){
			this.m_ItemRenderArray.pop();}
		this.m_curDataStartColumn = this.m_curDataStartColumn - this.tmpPrePageCashCloumnNum;			
			
		//Highlight new focus item
		var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;			
		this.m_HighlightItem(newFocusRenderIndex);					
		var nNewDataIndex = this.m_curDataStartIndex + this.m_curFocusItemIndex;
		this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
		
		this.m_moveFocusCursor();
		this.m_bIsAnimationIng = false;				
		
	}		
	this.m_MoveRightOnePageCBBind = this.m_MoveRightOnePageCB.bind(this);
	
	this.m_SetDestOfScrollWidgetPrePage = function(){
		if(this.m_bAlignSide == true){
			if(this.m_currentAlignState == this.alignState.STATE_ALIGN_RIGHT){
				this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition - this.m_GetAlignRightLastPageOffSet();
				this.m_currentAlignState = this.alignState.STATE_NORMAL;			
			}
		}
	}
	
	this.m_ReverseNextPage = function(){
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);		
		var nOldDataIndex =  this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);				
		this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);
		
		//calculate the cash column number
		this.tmpNextPageCashCloumnNum = this.m_DisplayAreaColumnNum;
		var nextPageEndDataIndex = this.m_curDataStartIndex + this.m_RowNum*this.m_DisplayAreaColumnNum*2 -1;
		var realLastDataIndex = this.m_nRealTotalNum -1;		
		var nLastPageEndDataRelativeIndex = realLastDataIndex - this.m_curDataStartIndex - this.m_RowNum*this.m_DisplayAreaColumnNum;
		if(realLastDataIndex < nextPageEndDataIndex){			
			this.tmpNextPageCashCloumnNum = parseInt(nLastPageEndDataRelativeIndex/this.m_RowNum) + 1;			
		}			
		//create cash column render obj
		var nStartCloumn = 0;
		var nEndCloumn = this.tmpNextPageCashCloumnNum;				
		var nYOffSet = this.m_nVeticalOffSet; 
		var nXOffSet = this.m_firstRenderItemX;		
		for(var nAddColumIndex= nStartCloumn; nAddColumIndex < nEndCloumn; nAddColumIndex++){
			this.m_ItemRenderArray.unshift(new Array());
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
				var nX = nXOffSet - (nAddColumIndex +1)*(this.m_ItemWidth + this.m_ItemXGap);
				var nY = nYOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);			
				var tmpRender = this.m_CreateOneRenderItem(nX, nY);			
				this.m_ItemRenderArray[0][nRowIndex] = tmpRender;				
			}		
		}		
		this.m_curDataStartColumn = this.m_curDataStartColumn + this.tmpNextPageCashCloumnNum;		
		
		//update data to new render obj
		var nFromIndex = this.m_curDataStartIndex + this.m_RowNum*this.m_DisplayAreaColumnNum;
		var nEndIndex = nFromIndex + this.m_RowNum*(this.m_DisplayAreaColumnNum +1);	
		this.m_UpdateDataToRender(nFromIndex,nEndIndex);
			
		//set new focusIndex, when the last column is not full and focus at the last column
		if(realLastDataIndex < nextPageEndDataIndex){
			var nCurFocusColumn = this.m_getCurColumn();
			if((this.m_nRealTotalNum % this.m_RowNum != 0) && (nCurFocusColumn == 0)){		
				var nLastDataRowNum	= realLastDataIndex%this.m_RowNum					
				this.m_curFocusItemIndex = nLastDataRowNum;
			}
		}
		
		//update first render Item's x
		this.m_firstRenderItemX	= this.m_firstRenderItemX - (this.m_ItemWidth + this.m_ItemXGap)*this.tmpNextPageCashCloumnNum;
		this.m_curDataStartIndex = this.m_curDataStartIndex + this.m_RowNum*this.tmpNextPageCashCloumnNum;	
				
		//do move animation ,move m_ScrollWidget right
		this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition+(this.m_ItemWidth + this.m_ItemXGap)*this.tmpNextPageCashCloumnNum;				
		this.m_ReverseSetDestOfScrollWidgetNextPage();
		var moveRightOnePage = new Animation(400);
		moveRightOnePage.addProperty("x", this.m_ScrollWidgetXPosition);
		this.m_ScrollWidget.animate(moveRightOnePage,this.m_ReverseMoveRightOnePageCBBind);		
	}
	
	this.m_ReverseMoveRightOnePageCB = function(){
		//remove the first old one page render
		var nDelEndCloumn = this.m_ItemRenderArray.length;					
		var nDelStartCloumn = nDelEndCloumn - this.tmpNextPageCashCloumnNum;		
		var unLoadDataStartIndex = this.m_curDataStartIndex - this.m_CashColumNum * this.m_RowNum;		
		for(var nDestroyColumIndex =nDelStartCloumn; nDestroyColumIndex < nDelEndCloumn; nDestroyColumIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
			//call item unload
			var unloadRenderItem = this.m_ItemRenderArray[nDestroyColumIndex][nRowIndex];
			this.m_ItemUnLoadCall(unLoadDataStartIndex ,unloadRenderItem);		
			unLoadDataStartIndex = unLoadDataStartIndex - 1;
			// destroy the item render	
			unloadRenderItem.destroy();}}			

		for(var nDelColumIndex =nDelStartCloumn; nDelColumIndex < nDelEndCloumn; nDelColumIndex++){
			this.m_ItemRenderArray.pop();}
		this.m_curDataStartColumn = this.m_curDataStartColumn - this.tmpNextPageCashCloumnNum;		
				
		//Highlight new focus item
		var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;			
		this.m_HighlightItem(newFocusRenderIndex);					
		var nNewDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);			
		
		//call focus in function
		this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
				
		this.m_moveFocusCursor();			
		this.m_bIsAnimationIng = false;
	}	
	this.m_ReverseMoveRightOnePageCBBind = this.m_ReverseMoveRightOnePageCB.bind(this);

	this.m_ReverseSetDestOfScrollWidgetNextPage = function(){
		if(this.m_bAlignSide == true){	
			if((this.m_currentAlignState == this.alignState.STATE_NORMAL) && (this.m_CheckIfLastPage() == true)){
					this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition - this.m_GetAlignRightLastPageOffSet();	
					this.m_currentAlignState = this.alignState.STATE_ALIGN_LEFT;
			}	
		}
	}	
	
	this.m_ReversePrePage = function(){
		//UnHighligh old focus item
		var oldFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;
		this.m_UnHighlightItem(oldFocusRenderIndex);		
		var nOldDataIndex =  this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);
		this.m_FocusOutCBCall(nOldDataIndex,oldFocusRenderIndex);
	
		//calculate the cash column number					
		this.tmpPrePageCashCloumnNum = this.m_DisplayAreaColumnNum;
		
		//check if need reset tmpPrePageCashCloumnNum
		var nPrePagefirstDataIndex = this.m_curDataStartIndex - this.m_DisplayAreaColumnNum * this.m_RowNum;
		if(nPrePagefirstDataIndex < 0){		
			this.tmpPrePageCashCloumnNum =  parseInt(this.m_curDataStartIndex/this.m_RowNum);
		}
		
		//create  cash column render obj
		var nStartCloumn = this.m_ItemRenderArray.length;
		var nEndCloumn = nStartCloumn + this.tmpPrePageCashCloumnNum;		
		var nYOffSet = this.m_nVeticalOffSet; 
		var nXOffSet = this.m_firstRenderItemX;		
		for(var nAddColumIndex =nStartCloumn; nAddColumIndex < nEndCloumn; nAddColumIndex++){	
			this.m_ItemRenderArray.push(new Array());
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
				var nX = nXOffSet + nAddColumIndex*(this.m_ItemWidth + this.m_ItemXGap);
				var nY = nYOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);			
				var tmpRender = this.m_CreateOneRenderItem(nX, nY);			
				this.m_ItemRenderArray[nAddColumIndex][nRowIndex] = tmpRender;				
			}
		}
		//update data to new render obj
		var nFromIndex = this.m_curDataStartIndex - this.m_RowNum*(this.m_DisplayAreaColumnNum+1);
		var nEndIndex = nFromIndex + this.m_RowNum*(this.m_DisplayAreaColumnNum +1);
		this.m_UpdateDataToRender(nFromIndex,nEndIndex);		
	
		//update first render Item's x
		this.m_firstRenderItemX	= this.m_firstRenderItemX + (this.m_ItemWidth + this.m_ItemXGap)*this.tmpPrePageCashCloumnNum;
		this.m_curDataStartIndex = this.m_curDataStartIndex - this.m_RowNum*this.tmpPrePageCashCloumnNum;	

		//do move animation ,move m_ScrollWidget 	
		this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition-(this.m_ItemWidth + this.m_ItemXGap)*this.tmpPrePageCashCloumnNum;		
		this.m_ReverseSetDestOfScrollWidgetPrePage();
		var moveLeftOnePage = new Animation(400);
		moveLeftOnePage.addProperty("x", this.m_ScrollWidgetXPosition);		
		this.m_ScrollWidget.animate(moveLeftOnePage,this.m_ReverseMoveLeftOnePageCBBind);		
	}
	
	this.m_ReverseMoveLeftOnePageCB = function(){
		//remove the first old one page render
		var nDelStartCloumn = 0;
		var nDelEndCloumn = nDelStartCloumn + this.tmpPrePageCashCloumnNum;									
		var unLoadDataStartIndex = this.m_curDataStartIndex - (this.m_DisplayAreaColumnNum + this.m_CashColumNum)*this.m_RowNum;		

		for(var nDestroyColumIndex = nDelEndCloumn - 1; nDestroyColumIndex >= nDelStartCloumn; nDestroyColumIndex--){
		for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
			//call item unload
			var unloadRenderItem = this.m_ItemRenderArray[nDestroyColumIndex][nRowIndex];
			this.m_ItemUnLoadCall(unLoadDataStartIndex ,unloadRenderItem);		
			unLoadDataStartIndex = unLoadDataStartIndex + 1;
			// destroy the item render	
			unloadRenderItem.destroy();}}		

		for(var nDelColumIndex =nDelStartCloumn; nDelColumIndex < nDelEndCloumn; nDelColumIndex++){
			this.m_ItemRenderArray.shift();
		}

		//Highlight new focus item
		var newFocusRenderIndex = this.m_curFocusItemIndex + this.m_CashColumNum * this.m_RowNum;			
		this.m_HighlightItem(newFocusRenderIndex);					
		var nNewDataIndex = this.m_GetDataIndexByFocusIndex(this.m_curFocusItemIndex);	
		
		//call focus in function
		this.m_FocusInCBCall(nNewDataIndex,newFocusRenderIndex);
		
		this.m_moveFocusCursor();			
		this.m_bIsAnimationIng = false;
	}	
	this.m_ReverseMoveLeftOnePageCBBind = this.m_ReverseMoveLeftOnePageCB.bind(this);
	
	this.m_ReverseSetDestOfScrollWidgetPrePage = function(){
		if(this.m_bAlignSide == true){
			if(this.m_currentAlignState == this.alignState.STATE_ALIGN_LEFT){
				this.m_ScrollWidgetXPosition = this.m_ScrollWidgetXPosition + this.m_GetAlignRightLastPageOffSet();	
				this.m_currentAlignState = this.alignState.STATE_NORMAL;
			}
		}
	}
	
	this.m_PageNum = function(){		
		var npagNum = parseInt(this.m_nRealTotalNum / (this.m_RowNum * this.m_DisplayAreaColumnNum));			
		if(this.m_nRealTotalNum % (this.m_RowNum * this.m_DisplayAreaColumnNum) != 0)
		{
			npagNum = npagNum + 1;
		}			
		return npagNum;
	}			
	
	//for scroll operation
	this.m_MoveFocusOnCurPage = function(nDataIndex){	
		var nStartDataIndex = this.m_curDataStartIndex;
		var nLastDataIndex = this.m_curDataStartIndex + this.m_DisplayAreaColumnNum *this.m_RowNum;	
			//check if nDataIndex in current page , move focus
		if(nDataIndex >= nStartDataIndex &&  nDataIndex < nLastDataIndex){
			//change focus item index 
			var oldFocusItemIndex = this.m_curFocusItemIndex;
			var newFocusItemIndex = this.m_GetFocusIndexByRelativeDataIndex(nDataIndex - this.m_curDataStartIndex);
			if(oldFocusItemIndex != newFocusItemIndex)
			{
				//change focus
				this.m_ChangeFocus(oldFocusItemIndex,newFocusItemIndex);
				
				this.m_curFocusItemIndex = newFocusItemIndex;
				//move focus 
				this.m_moveFocusCursor();
			}
			return true;
		}
			
		return false;	
	}
	
	this.m_GetFocusIndexByRelativeDataIndex = function(nRelativeDataIndex){
		var nFocusIndex = nRelativeDataIndex;
		if(this.m_bReverseFlag == true){
			var nColumnNum = this.m_GetCurColumByDataIndex(nRelativeDataIndex);
				nColumnNum = (this.m_DisplayAreaColumnNum -1) - nColumnNum;
			var nRowNum = this.m_GetRowNumByDataIndex(nRelativeDataIndex);
			
			nFocusIndex = nColumnNum*this.m_RowNum + nRowNum;
		}
		return nFocusIndex;
	}
	
	this.m_MoveScrollWidgetByColumnNum = function(nColumn, bMoveRight){
		for(var tmp =0; tmp<nColumn;  tmp++)
		{
			if(bMoveRight == true)
			{
				this.m_MoveRight(false);			
			}
			else
			{
				this.m_MoveLeft(false);
			}
			
		}	
	}
	
	//mouse call back		
	this.m_ListItemMouseClick = function(targetWidget, eventData){	
		if(this.m_bDimFlag == true){
			return false;
		}
		//print("Click item========"+ targetWidget.nBindDataIndex);		
		this.m_ClickCall();
		//return false;
	}
	this.m_ListItemMouseClickBind=this.m_ListItemMouseClick.bind(this)
	
	this.m_ListItemMouseOver = function(targetWidget, eventData){
		if(this.m_bDimFlag == true){
			return false;
		}
	
		var nRelativeX = targetWidget.x - this.m_firstRenderItemX;
		var nRelativeY = targetWidget.y - this.m_nVeticalOffSet;		
		var curRenderIndex = this.m_GetCurAtItemRenderIndex(nRelativeX, nRelativeY);
		
		if(this.m_MovingItemWidget !=null && this.m_MovingItemWidget.bMoveFlag == true)
		{
			if(this.m_MovingItemWidget === targetWidget){
	//			print("Error_m_ListItemMouseOver===00=="+ targetWidget.nBindDataIndex);	
				return false;				
			}
		//	print("Over_m_nMouseCurOverRenderIndex====="+ this.m_nMouseCurOverRenderIndex);
			this.m_nMouseCurOverRenderIndex = curRenderIndex;	
			this.m_CheckAndExChangeRender();	
		}
				
		var DisplayAreaRenderStartIndex = this.m_CashColumNum * this.m_RowNum;
		var DisplayAreaRenderEndIndex = (this.m_CashColumNum + this.m_DisplayAreaColumnNum) * this.m_RowNum;
		
		if(curRenderIndex < DisplayAreaRenderStartIndex)
		{
			//logTest("m_MoveRight=====3333",true);
			this.m_bIsAnimationIng = true;	
			this.m_MoveRight(this.m_bDoMovingFlag);
			
			//update move render index after move
			if(this.m_bDoMovingFlag == true){
				this.m_nMovingRenderIndex = this.m_nMovingRenderIndex + this.m_RowNum;
				this.m_curFocusItemIndex = 	this.m_nMovingRenderIndex - this.m_CashColumNum * this.m_RowNum;			
			}
			return false;
		}
		
		if(curRenderIndex >= DisplayAreaRenderEndIndex)
		{
			this.m_bIsAnimationIng = true;	
			this.m_MoveLeft(this.m_bDoMovingFlag);
			
			//update move render index after move
			if(this.m_bDoMovingFlag == true){
				this.m_nMovingRenderIndex = this.m_nMovingRenderIndex - this.m_RowNum;
				this.m_curFocusItemIndex = 	this.m_nMovingRenderIndex - this.m_CashColumNum * this.m_RowNum;			
			}
			return false;
		}
		
		if( curRenderIndex >= DisplayAreaRenderStartIndex || curRenderIndex < DisplayAreaRenderEndIndex )
		{
			//move focus on current page
			var newFocusIndex = curRenderIndex - this.m_CashColumNum * this.m_RowNum;
			if(this.m_curFocusItemIndex != newFocusIndex){
				this.m_ChangeFocus(this.m_curFocusItemIndex, newFocusIndex);
				this.m_curFocusItemIndex = newFocusIndex;			
				this.m_moveFocusCursor();	
			}			
		}
		return false;
	}
	this.m_ListItemMouseOverBind=this.m_ListItemMouseOver.bind(this)	

	this.m_ListItemMouseDown = function(targetWidget, eventData){
		if(this.m_bDimFlag == true){
			return false;
		}
	
		if(this.m_bDoMovingFlag == true){
			return false;
		}
		
	//	print("Down item====00===="+ targetWidget.nBindDataIndex);		
		if(this.m_bSupportDragAndDrop == true && targetWidget.bItemLoad == true){
			this.m_bDoMovingFlag = true;
		//	print("Down item====11===="+ targetWidget.nBindDataIndex);
			targetWidget.bMoveFlag = true;
			targetWidget.depth = 0.5;
			targetWidget.drawWithDepth = true;
			this.m_MovingItemWidget = targetWidget;	
			
			/*	
			this.m_MovingItemWidget.anchor = {x:0.5,y:0.5}			
			var nX = eventData.coordinates.x - this.x;
			var nY = eventData.coordinates.y - this.y;				
			this.m_MovingItemWidget.x = nX + (this.m_firstRenderItemX + this.m_CashColumNum*(this.m_ItemWidth + this.m_ItemXGap)) ;
			this.m_MovingItemWidget.y = nY;			
			*/
			
			//get cur down renderindex by relative positon
			var nRelativeX = targetWidget.x - this.m_firstRenderItemX;
			var nRelativeY = targetWidget.y - this.m_nVeticalOffSet;		
			var curRenderIndex = this.m_GetCurAtItemRenderIndex(nRelativeX, nRelativeY);			
			
			this.m_nMovingRenderIndex = curRenderIndex;
		//	print("Down item====77====this.m_nMovingRenderIndex "+ this.m_nMovingRenderIndex);		
			this.m_hideCursor();
		}
		//logTest("77 m_ListMouseDown item====="+ targetWidget.nBindDataIndex ,true);
		return false;
	}
	this.m_ListItemMouseDownBind = this.m_ListItemMouseDown.bind(this);
	
	//for drag and drop	
	this.m_ResetAllRenderMoveFlag = function(){
		for(var nColumIndex =0; nColumIndex < this.m_RenderCloumNum; nColumIndex++){
			for(var nRowIndex =0; nRowIndex < this.m_RowNum; nRowIndex++){
				this.m_ItemRenderArray[nColumIndex][nRowIndex].bMoveFlag = false;
				this.m_ItemRenderArray[nColumIndex][nRowIndex].depth =0;
				this.m_ItemRenderArray[nColumIndex][nRowIndex].drawWithDepth = true;
			}
		}
	}	
		
	this.m_DisplayBGWidgetMouseUp = function(targetWidget, eventData){
		if(this.m_bDimFlag == true){
			return false;
		}	
		
		if(this.m_bDoMovingFlag == false){
			return false;
		}		
		
		if(this.m_MovingItemWidget == null){
			return false;
		}
//		print("Up m_Display ===moving render index==" + this.m_nMovingRenderIndex);
		this.m_bDoMovingFlag = false;
		this.m_ResetAllRenderMoveFlag();
				
		//this.m_MovingItemWidget.anchor = {x:0,y:0};			
		//set the move item position
		this.m_MovingItemWidget.x = this.m_GetXPositionByRenderIndex(this.m_nMovingRenderIndex);
		this.m_MovingItemWidget.y = this.m_GetYPositionByRenderIndex(this.m_nMovingRenderIndex);
		
		this.m_MovingItemWidget = null;		
		this.m_nMovingRenderIndex = -1;
		this.m_nMouseCurOverRenderIndex = -1;
		this.m_showFocus();
		this.m_moveFocusCursor();	
		return false;
	}
	this.m_DisplayBGWidgetMouseUpBind = this.m_DisplayBGWidgetMouseUp.bind(this);	
	
	this.m_DisplayBGWidgetMouseMove = function(targetWidget, eventData){
		if(this.m_bDimFlag == true){
			return false;
		}	
	
		if(this.m_MovingItemWidget !=null && this.m_MovingItemWidget.bMoveFlag == true)
		{
			var nX = eventData.coordinates.x - this.x;
			var nY = eventData.coordinates.y - this.y;	
			
			this.m_MovingItemWidget.x = nX + (this.m_firstRenderItemX + this.m_CashColumNum*(this.m_ItemWidth + this.m_ItemXGap)) ;
			this.m_MovingItemWidget.y = nY;
			
			this.m_CursorInstance.move(nX,nY,this.m_ItemWidth,this.m_ItemHeight);
		}
		
		return false;		
	}
	this.m_DisplayBGWidgetMouseMoveBind = this.m_DisplayBGWidgetMouseMove.bind(this);	
	
	this.m_GetCurAtItemRenderIndex = function(nX,nY){
		var nCloumnNum = parseInt(nX/(this.m_ItemWidth + this.m_ItemXGap));
		var nRowNum = parseInt(nY/(this.m_ItemHeight + this.m_ItemYGap));		
		var nRelativeRenderIndex = nCloumnNum * this.m_RowNum + nRowNum;
		
		return nRelativeRenderIndex;		
	}
	
	this.m_CheckAndExChangeRender = function(){	
		if(this.m_nMovingRenderIndex != this.m_nMouseCurOverRenderIndex)
		{
			var nStartIndex = this.m_GetDataIndexByRenderIndex(this.m_nMovingRenderIndex);
			var nEndIndex = this.m_GetDataIndexByRenderIndex(this.m_nMouseCurOverRenderIndex);		
		
			if(this.m_bReverseFlag == false){
				this.m_ExchangeRenderByRenderIndex(this.m_nMovingRenderIndex, this.m_nMouseCurOverRenderIndex);
			}
			else{
				this.m_ReverseExchangeRenderByDataIndex(nStartIndex,nEndIndex);
			}
			
			//exchange data source array
			this.m_ExchangeDataByDataIndex(nStartIndex,nEndIndex);
			
			//update move index
			this.m_nMovingRenderIndex = this.m_nMouseCurOverRenderIndex;			
		//	print("exchange m_nMovingRenderIndex===" + this.m_nMovingRenderIndex);			
			//update focus index
			this.m_curFocusItemIndex = 	this.m_nMovingRenderIndex - this.m_CashColumNum * this.m_RowNum;					
		}			
	}
		
	this.m_ReverseGetRenderByDataIndex = function(nDataIndex){
		var realRenderCloumIndex;
		var reallRenderRowIndex;
		var nRelativeDataIndex =  nDataIndex - this.m_curDataStartIndex;
		var RelativeDataLeftLimit = 0- this.m_RowNum*(this.m_ItemRenderArray.length - this.m_DisplayAreaColumnNum - this.m_CashColumNum);				
		var RelativeDataRightLimit = this.m_RowNum *(this.m_ItemRenderArray.length -this.m_CashColumNum);		
		if((nRelativeDataIndex>= 0) && (nRelativeDataIndex < RelativeDataRightLimit)){	
			var nTmpColum = this.m_GetCurColumByDataIndex(nRelativeDataIndex);	
			var tmpCalCloumnNum = this.m_ItemRenderArray.length -this.m_CashColumNum;
				realRenderCloumIndex =tmpCalCloumnNum - nTmpColum -1;		
				reallRenderRowIndex = this.m_GetRowNumByDataIndex(nRelativeDataIndex);	
		}
		else if((nRelativeDataIndex >= RelativeDataLeftLimit) && (nRelativeDataIndex <0)){
			var tmpRelativeDataIndex = (0 - nRelativeDataIndex) -1;							
			var nTmpColumB = this.m_GetCurColumByDataIndex(tmpRelativeDataIndex) +1;
				realRenderCloumIndex = this.m_curDataStartColumn + nTmpColumB;		
			var nTmpRowB = this.m_GetRowNumByDataIndex(tmpRelativeDataIndex);
				reallRenderRowIndex = (this.m_RowNum -1) - nTmpRowB;		
		}		
		return this.m_ItemRenderArray[realRenderCloumIndex][reallRenderRowIndex];;
	}
	
	this.m_ReverseGetColumnByDataIndex = function(nDataIndex){
		var realRenderCloumIndex;
		var nRelativeDataIndex =  nDataIndex - this.m_curDataStartIndex;
		var RelativeDataLeftLimit = 0- this.m_RowNum*(this.m_ItemRenderArray.length - this.m_DisplayAreaColumnNum - this.m_CashColumNum);				
		var RelativeDataRightLimit = this.m_RowNum *(this.m_ItemRenderArray.length -this.m_CashColumNum);			
	
		if((nRelativeDataIndex>= 0) && (nRelativeDataIndex < RelativeDataRightLimit)){
			var nTmpColum = this.m_GetCurColumByDataIndex(nRelativeDataIndex);	
			var tmpCalCloumnNum = this.m_ItemRenderArray.length -this.m_CashColumNum;
				realRenderCloumIndex =tmpCalCloumnNum - nTmpColum -1;
		}
		else if((nRelativeDataIndex >= RelativeDataLeftLimit) && (nRelativeDataIndex <0)){
			var tmpRelativeDataIndex = (0 - nRelativeDataIndex) -1;							
			var nTmpColumB = this.m_GetCurColumByDataIndex(tmpRelativeDataIndex) +1;
				realRenderCloumIndex = this.m_curDataStartColumn + nTmpColumB;	
		}
		return realRenderCloumIndex;
	}
	
	this.m_ReverseGetRowByDataIndex = function(nDataIndex){
		var reallRenderRowIndex;
		var nRelativeDataIndex =  nDataIndex - this.m_curDataStartIndex;
		var RelativeDataLeftLimit = 0- this.m_RowNum*(this.m_ItemRenderArray.length - this.m_DisplayAreaColumnNum - this.m_CashColumNum);				
		var RelativeDataRightLimit = this.m_RowNum *(this.m_ItemRenderArray.length -this.m_CashColumNum);			
		
		if((nRelativeDataIndex>= 0) && (nRelativeDataIndex < RelativeDataRightLimit)){
			reallRenderRowIndex = this.m_GetRowNumByDataIndex(nRelativeDataIndex);	
		}
		else if((nRelativeDataIndex >= RelativeDataLeftLimit) && (nRelativeDataIndex <0)){
			var tmpRelativeDataIndex = (0 - nRelativeDataIndex) -1;	
			var nTmpRowB = this.m_GetRowNumByDataIndex(tmpRelativeDataIndex);
			reallRenderRowIndex = (this.m_RowNum -1) - nTmpRowB;	
		}
		
		return reallRenderRowIndex;
	}
	
	this.m_GetDataIndexByRenderIndex = function(nRenderIndex){
		var nDataIndex;	
		if(this.m_bReverseFlag == false)
		{
			nDataIndex = this.m_curDataStartIndex + nRenderIndex - this.m_CashColumNum * this.m_RowNum;
		}	
		else{
			var nCloumnIndex = this.m_GetCurColumByDataIndex(nRenderIndex);
			var	nRelativeCloumnIndex = (this.m_RenderCloumNum - 1) - nCloumnIndex - this.m_CashColumNum;		
			var nRowIndex = this.m_GetRowNumByDataIndex(nRenderIndex);
				
			if(nRelativeCloumnIndex >=0){
				nDataIndex = this.m_curDataStartIndex + nRelativeCloumnIndex * this.m_RowNum + nRowIndex;
			}		
			else{
				nDataIndex = (nRelativeCloumnIndex +1)* this.m_RowNum - (nRowIndex +1);
				nDataIndex = this.m_curDataStartIndex + nDataIndex;
			}			
		}		
		return nDataIndex;
	} 
	
	this.m_ReverseGetXPositionByDataIndex = function(nDataIndex){
		var nColumIndex = this.m_ReverseGetColumnByDataIndex(nDataIndex);
		var nRenderX = this.m_firstRenderItemX + nColumIndex*(this.m_ItemWidth + this.m_ItemXGap);
		return nRenderX;
	}
	
	this.m_ReverseGetYPositionByDataIndex = function(nDataIndex){
		var nRowIndex = this.m_ReverseGetRowByDataIndex(nDataIndex);
		var nRenderY = this.m_nVeticalOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);
		return nRenderY;
	}	
	
	this.m_ReverseExchangeRenderByDataIndex = function(nStartIndex, nEndIndex){
		if(nStartIndex == nEndIndex){
			return;
		}
		
		if(nStartIndex > nEndIndex){
			//change position
			for(var tmpIndex = nEndIndex; tmpIndex < nStartIndex; tmpIndex++){	
				var moveRender = this.m_ReverseGetRenderByDataIndex(tmpIndex);
				var newMoveX = this.m_ReverseGetXPositionByDataIndex(tmpIndex +1);
				var newMoveY = this.m_ReverseGetYPositionByDataIndex(tmpIndex +1);			
				var moveAni = new Animation(100);
					moveAni.addProperty("x", newMoveX);	
					moveAni.addProperty("y", newMoveY);				
					moveRender.animate(moveAni);			
			}
						
			//change the array 
			var startRender  = this.m_ReverseGetRenderByDataIndex(nStartIndex);
			for(var tmpIndex = nStartIndex; tmpIndex > nEndIndex; tmpIndex--){
				var nCurCloumn = this.m_ReverseGetColumnByDataIndex(tmpIndex);
				var nCurRow = this.m_ReverseGetRowByDataIndex(tmpIndex);
				this.m_ItemRenderArray[nCurCloumn][nCurRow] = this.m_ReverseGetRenderByDataIndex(tmpIndex-1);
			}
			
			var nEndCloumn = this.m_ReverseGetColumnByDataIndex(nEndIndex);
			var nEndRow = this.m_ReverseGetRowByDataIndex(nEndIndex);
			this.m_ItemRenderArray[nEndCloumn][nEndRow] = startRender;
		}
		else{
			//change position
			for(var tmpIndex = nEndIndex; tmpIndex > nStartIndex; tmpIndex--){	
				var moveRender = this.m_ReverseGetRenderByDataIndex(tmpIndex);
				var newMoveX = this.m_ReverseGetXPositionByDataIndex(tmpIndex -1);
				var newMoveY = this.m_ReverseGetYPositionByDataIndex(tmpIndex -1);
				//var nextRender = this.m_ReverseGetRenderByDataIndex(tmpIndex -1);				
				var moveAni = new Animation(100);
					moveAni.addProperty("x", newMoveX);	
					moveAni.addProperty("y", newMoveY);				
					moveRender.animate(moveAni);			
			}			
			
			//change the array 
			var startRender  = this.m_ReverseGetRenderByDataIndex(nStartIndex);
			for(var tmpIndex = nStartIndex; tmpIndex < nEndIndex; tmpIndex++){
				var nCurCloumn = this.m_ReverseGetColumnByDataIndex(tmpIndex);
				var nCurRow = this.m_ReverseGetRowByDataIndex(tmpIndex);			
				this.m_ItemRenderArray[nCurCloumn][nCurRow] = this.m_ReverseGetRenderByDataIndex(tmpIndex+1);
			}
			var nEndCloumn = this.m_ReverseGetColumnByDataIndex(nEndIndex);
			var nEndRow = this.m_ReverseGetRowByDataIndex(nEndIndex);	
			this.m_ItemRenderArray[nEndCloumn][nEndRow] = startRender;	
		}
	}
	
	this.m_ExchangeDataByDataIndex = function(nStartIndex, nEndIndex){
		if(nStartIndex == nEndIndex){
			return;
		}	
	
		if(nStartIndex > nEndIndex)
		{
			var nStartData = this.m_DataSourceArray[nStartIndex];
			for(var tmpIndex = nStartIndex; tmpIndex > nEndIndex; tmpIndex--){
				this.m_DataSourceArray[tmpIndex] = this.m_DataSourceArray[tmpIndex-1];
			}
			this.m_DataSourceArray[nEndIndex] = nStartData;	
		}
		else
		{
			var nStartData = this.m_DataSourceArray[nStartIndex];
			
			for(var tmpIndex = nStartIndex; tmpIndex < nEndIndex; tmpIndex++){
				this.m_DataSourceArray[tmpIndex] = this.m_DataSourceArray[tmpIndex+1];
			}
			this.m_DataSourceArray[nEndIndex] = nStartData;				
		}
	}
	
	this.m_ExchangeRenderByRenderIndex = function(nStartRenderIndex,nEndRenderIndex){
		if(nStartRenderIndex == nEndRenderIndex){
			return;
		}
		
		if(nStartRenderIndex > nEndRenderIndex)
		{
			//change position 
			for(var tmpIndex = nEndRenderIndex; tmpIndex < nStartRenderIndex; tmpIndex++)
			{
				var moveRender = this.m_getRenderByRenderIndex(tmpIndex);
				var newMoveX = this.m_GetXPositionByRenderIndex(tmpIndex +1);
				var newMoveY = this.m_GetYPositionByRenderIndex(tmpIndex +1);
				
				var moveAni = new Animation(100);
				moveAni.addProperty("x", newMoveX);	
				moveAni.addProperty("y", newMoveY);				
				moveRender.animate(moveAni);			
			}
			
			//change the array 
			var startRender = this.m_getRenderByRenderIndex(nStartRenderIndex);
			for(var tmpIndex = nStartRenderIndex; tmpIndex > nEndRenderIndex; tmpIndex--)
			{
				var curRenderRow  = this.m_GetRowNumByDataIndex(tmpIndex);			
				var curRenderColum = this.m_GetCurColumByDataIndex(tmpIndex);
				var preRender = this.m_getRenderByRenderIndex(tmpIndex -1);
				this.m_ItemRenderArray[curRenderColum][curRenderRow] = 	preRender;
			}
			var  nEndRenderRow = this.m_GetRowNumByDataIndex(nEndRenderIndex);	
			var  nEndRenderColum= this.m_GetCurColumByDataIndex(nEndRenderIndex);
			this.m_ItemRenderArray[nEndRenderColum][nEndRenderRow] = startRender;			
		}
		else
		{
			//change position 
			for(var tmpIndex = nEndRenderIndex; tmpIndex > nStartRenderIndex; tmpIndex--)
			{		
				//usefully code
				var moveRender = this.m_getRenderByRenderIndex(tmpIndex);
				var newMoveX = this.m_GetXPositionByRenderIndex(tmpIndex -1);
				var newMoveY = this.m_GetYPositionByRenderIndex(tmpIndex -1);
				
				var moveAni = new Animation(100);
				moveAni.addProperty("x", newMoveX);	
				moveAni.addProperty("y", newMoveY);				
				moveRender.animate(moveAni);
			}
					
			//change the array 	
			var startRender = this.m_getRenderByRenderIndex(nStartRenderIndex);	
			for(var tmpIndex = nStartRenderIndex; tmpIndex < nEndRenderIndex; tmpIndex++)
			{
				var curRenderRow  = this.m_GetRowNumByDataIndex(tmpIndex);			
				var curRenderColum = this.m_GetCurColumByDataIndex(tmpIndex);
				
				var nextRender = this.m_getRenderByRenderIndex(tmpIndex +1);
				this.m_ItemRenderArray[curRenderColum][curRenderRow] = 	nextRender;			
			}
			
			var  nEndRenderRow = this.m_GetRowNumByDataIndex(nEndRenderIndex);	
			var  nEndRenderColum= this.m_GetCurColumByDataIndex(nEndRenderIndex);
			this.m_ItemRenderArray[nEndRenderColum][nEndRenderRow] = startRender;		
		}
	}		
	
	this.m_GetXPositionByRenderIndex = function(nRenderIndex){
		var nColumIndex = this.m_GetCurColumByDataIndex(nRenderIndex);
		var nRenderX = this.m_firstRenderItemX + nColumIndex*(this.m_ItemWidth + this.m_ItemXGap);
		return nRenderX;
	}
	
	this.m_GetYPositionByRenderIndex = function(nRenderIndex){
		var nRowIndex = this.m_GetRowNumByDataIndex(nRenderIndex);
		var nRenderY = this.m_nVeticalOffSet + nRowIndex*(this.m_ItemHeight + this.m_ItemYGap);
		return nRenderY;
	}	
}

List_Thumbnails.prototype = new ControlBase();
exports = List_Thumbnails;
