 /** 
 * @author  
 * @fileoverview Definition of ControlBase
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

ControlBase = function() {
	this.m_RootWidgetObject = null;
	this.m_isFocused = false;
	this.m_isCreated = false;
	this.m_isDimed = false;
	this.m_isSelected = false;
	
	//property x
	this.__defineGetter__("x", function() {return this.m_RootWidgetObject.x;});
	this.__defineSetter__("x", function(val) {this.m_RootWidgetObject.x = val;});
	
	//property y
	this.__defineGetter__("y", function() {return this.m_RootWidgetObject.y;});
	this.__defineSetter__("y", function(val) {this.m_RootWidgetObject.y = val;});
	
	//property opacity
	this.__defineGetter__("opacity", function() {return this.m_RootWidgetObject.opacity;});
	this.__defineSetter__("opacity", function(val) {this.m_RootWidgetObject.opacity = val;});
	
	//property width
	this.__defineGetter__("width", function() {return this.m_RootWidgetObject.width;});
	this.__defineSetter__("width", function(val) {this.m_RootWidgetObject.width = val;});
	
	//property height
	this.__defineGetter__("height", function() {return this.m_RootWidgetObject.height;});
	this.__defineSetter__("height", function(val) {this.m_RootWidgetObject.height = val;});
	
	//property depth
	this.__defineGetter__("depth", function() {return this.m_RootWidgetObject.depth;});
	this.__defineSetter__("depth", function(val) {this.m_RootWidgetObject.depth = val;});
	
	//property anchor
	this.__defineGetter__("anchor", function() {return this.m_RootWidgetObject.anchor;});
	this.__defineSetter__("anchor", function(val) {this.m_RootWidgetObject.anchor = val;});
	
	//property origin
	this.__defineGetter__("origin", function() {return this.m_RootWidgetObject.origin;});
	this.__defineSetter__("origin", function(val) {this.m_RootWidgetObject.origin = val;});
	
	//property parent
	this.__defineGetter__("parent", function() {return this.m_RootWidgetObject.parent;});
	this.__defineSetter__("parent", function(val) {this.m_RootWidgetObject.parent = val;});
	
	//property parent
	this.__defineGetter__("color", function() {return this.m_RootWidgetObject.color;});
	this.__defineSetter__("color", function(val) {this.m_RootWidgetObject.color = val;});
	
	//property cropOverflow
	this.__defineGetter__("cropOverflow", function() {return this.m_RootWidgetObject.cropOverflow;});
	this.__defineSetter__("cropOverflow", function(val) {this.m_RootWidgetObject.cropOverflow = val;});
	
	//property isFocused read only
	this.__defineGetter__("isFocused", function() {return this.m_isFocused;});
	this.__defineSetter__("isFocused", function(val) {});
	
	//property isCreated read only
	this.__defineGetter__("isCreated", function() {return this.m_isCreated;});
	this.__defineSetter__("isCreated", function(val) {});
	
	//property isDimed read only
	this.__defineGetter__("isDimed", function() {return this.m_isDimed;});
	this.__defineSetter__("isDimed", function(val) {});
	
	//property isSelected read only
	this.__defineGetter__("isSelected", function() {return this.m_isSelected;});
	this.__defineSetter__("isSelected", function(val) {});
	
	
	//property rootWidget read only
	this.__defineGetter__("rootWidget", function() {return this.m_RootWidgetObject;});
	this.__defineSetter__("rootWidget", function(val) {});
	
	this.getFocus = function() {
		if (this.m_isCreated) {
			this.t_getFocus();
			this.m_isFocused = true;
		}
	};
	
	this.loseFocus = function() {
		if (this.m_isCreated) {
			this.m_isFocused = false;
			this.t_loseFocus();
		}
	};
	
	this.getDim = function(){
		if (this.m_isCreated) {
			this.t_getDim();
			this.m_isDimed = true;
		}
	};
	
	this.loseDim = function(){
		if ((this.m_isCreated) && (this.m_isDimed)) {
			this.t_loseDim();
			this.m_isDimed = false;
		}
	};
	
	this.selected = function(){
		if (this.m_isCreated) {
			this.t_selected();
			this.m_isSelected = true;
		}		
	};
	
	this.unSelected = function(){
		if (this.m_isCreated) {
			this.m_isSelected= false;
			this.t_unSelected();
		}	
	};
	
	this.t_getDim = function() {	
	};
	
	this.t_loseDim = function() {	
	};
	
	this.t_selected = function() {	
	};
	
	this.t_unSelected = function(){
	};
	
	this.create = function(obj) {
		if (this.m_isCreated) {
			return;
		}
		var x = 0;
		var y = 0;
		var height = 1;
		var width = 1;
		var parent = null;
		var color = {r: 0, g: 0, b: 0, a: 0};
		var cropOverflow = false;
		
		if (obj.hasOwnProperty("x")) {
			x = obj.x;
			delete obj.x;
		}
		if (obj.hasOwnProperty("y")) {
			y = obj.y;
			delete obj.y;
		}
		if (obj.hasOwnProperty("height")) {
			height = obj.height;
		}
		if (obj.hasOwnProperty("width")) {
			width = obj.width;
		}
		if (obj.hasOwnProperty("cropOverflow")) {
			cropOverflow = obj.cropOverflow;
			delete obj.cropOverflow;
		}
		if (obj.hasOwnProperty("color")) {
			color = obj.color;
		}
		if (obj.hasOwnProperty("parent")) {
			parent = obj.parent;
		}
		this.m_RootWidgetObject = new Widget({
			x: x,
			y: y,
			height: height,
			width: width,
			parent: parent,
			color: color,
			opacity: 255,
		});
		this.m_RootWidgetObject.cropOverflow = cropOverflow;
		
		
		obj.parent = this.m_RootWidgetObject;
		this.t_create(obj);
		this.m_isCreated = true;
		this.m_isFocused = false;
	};
	
	//obj:{overCallback:XXX, outCallback:XXX}
	this.setMouseOverOutCallback = function(obj){
		if (this.m_isCreated) {
			this.t_setMouseOverOutCallback(obj);
		}
	};
	
	//obj:{upCallback:XXX, downCallback:XXX}
	this.setMouseUpDownCallback = function(obj){
		if (this.m_isCreated) {
			this.t_setMouseUpDownCallback(obj);
		}
	};
	
	this.setMouseClickCallback = function(callback){
		if (this.m_isCreated) {
			this.t_setMouseClickCallback(callback);
		}
	};
	
	this.enableMouseOverOut = function(isOnFlag){				
		if (this.m_isCreated) {
			this.t_MouseOverOut(isOnFlag);	
		}
	};
	
	this.enableMouseUpDown = function(isOnFlag){
		if (this.m_isCreated) {
			this.t_MouseUpDown(isOnFlag);	
		}
	};
	
	this.enableMouseClick = function(isOnFlag){			
		if (this.m_isCreated) {
			this.t_MouseClick(isOnFlag);
		}
	};
				
	this.t_setMouseOverOutCallback = function(obj){
	};
	
	this.t_setMouseUpDownCallback = function(obj){
	};
	
	this.t_setMouseClickCallback = function(callback){
	};
	
	this.t_MouseOverOut =function(isOnFlag) {
	};
	
	this.t_MouseUpDown = function(isOnFlag) {
	};
	
	this.t_MouseClick = function(isOnFlag) {
	};	
	
	this.show = function() {
		if (this.m_isCreated) {
			this.t_show();
			this.m_RootWidgetObject.show();
		}
	};
			
	this.hide = function() {
		if (this.m_isCreated) {
			this.m_RootWidgetObject.hide();
			this.t_hide();
		}
	};
	
	this.onWidthChanged = function(newWidth){
		if (this.m_isCreated) {
			this.m_RootWidgetObject.width = newWidth;
			this.t_onWidthChanged(newWidth);
		}
	};

	this.t_show = function(){};	
	this.t_hide = function(){};
	this.t_onWidthChanged = function(newWidth){};	
			
	this.showWithAni = function(callback){
			if (this.m_isCreated) {
			this.t_showWithAni(callback);
		}
	};
	
	this.hideWithAni = function(callback){
			if (this.m_isCreated) {
			this.t_hideWithAni(callback);
		}
	};
	
	this.animate = function() {
		var command = "this.m_RootWidgetObject.animate(arguments[0]";
		for (var index=1; index<arguments.length; index++) {
			command+=", arguments["+index.toString()+"]";
		}
		command += ");";
		eval(command);
	};
	
	this.destroy = function() {
		if (this.m_isCreated) {
			this.t_destroy();
			this.m_RootWidgetObject.destroy();
		}
		this.m_isCreated = false;
		this.m_isFocused = false;
	};
	
	this.keyHandler = function(keycode, keytype) {	
		if (this.m_isCreated && this.m_isFocused && 
			(this.m_isDimed == false)) {
			return this.t_keyHandler(keycode, keytype);  //return false means the UI Element do not handle the key
		}
		return false;
	};
}

exports = ControlBase;