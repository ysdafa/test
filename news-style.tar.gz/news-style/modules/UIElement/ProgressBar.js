ControlBase = Volt.require("modules/UIElement/ControlBase.js");

ProgressBar = function() {
	this.m_ProcessWidget = null,
	this.m_Percentage = 0;
	this.m_FocusPointWidget = null;
	this.m_FocusPointImgSrc = null;
	this.m_StepLength = 0;
	this.m_Style = 0;
	this.leftKeyCallback = null;
	this.rightKeyCallback = null;
	this.bgColor={r:255,g:255,b:255,a:25.5};
	this.foreColor = {r:255,g:255,b:255,a:255};
	Object.defineProperties(this, 
		{
			backColor: {
				configurable: true,
				get: function() { return this.color; },
				set: function(val) { this.color = val; },
			},
			foreColor: {
				configurable: true,
				get: function() { return this.m_ProcessWidget.color; },
				set: function(val) { this.m_ProcessWidget.color = val; },
			},
			percentage: {
				configurable: true,
				get: function() { return this.m_Percentage; },
				set: function(val) {this.m_Percentage = val > 1 ? 1 : ( val < 0 ? 0: val);
									this.m_ProcessWidget.animate("width", this.width*this.m_Percentage, Math.abs(this.m_ProcessWidget.width - this.width*this.m_Percentage)*5);},
			},
			focusPointImgSrc: {
				configurable: true,
				get: function() { return this.m_FocusPointImgSrc; },
				set: function(val) {this.m_FocusPointImgSrc = val;},
			},
			stepLength: {
				configurable: true,
				get: function() {return this.m_StepLength; },
				set: function(val) {this.m_StepLength = val; },
			},
			style: {
				configurable: true,
				get: function() {return this.m_Style; },
				set: function(val) {this.m_Style = val; },
			}
		}
	);
	
	this.t_create = function(obj) {
		this.m_ProcessWidget = new Widget({
			x: 0,
			y: 0,
			height: obj.height,
			width: 0,
			parent: obj.parent,
		});
		if (obj.foreColor) {
			this.foreColor = obj.foreColor;
		} 
		this.color=this.bgColor;
		
		this.m_Percentage = typeof(obj.percentage)=="undefined" ? 0: obj.percentage;
		this.m_ProcessWidget.width = obj.width*this.m_Percentage;
		
		this.m_FocusPointWidget = new ImageWidget({
			x: 0,
			y: 0,
			width:50,
			height:50,
			parent: this.m_ProcessWidget,
		});
		this.m_FocusPointWidget.anchor = {x: 0.5, y: 0.5};
		this.m_FocusPointWidget.origin = {x: 1, y: 0.5};
		this.m_FocusPointWidget.fillMode = "fit";
		if (typeof(obj.focusPointImgSrc) != "undefined") {
			this.m_FocusPointImgSrc = obj.focusPointImgSrc;
			this.m_FocusPointWidget.src = this.m_FocusPointImgSrc.unfocused;
		} else {
			this.m_FocusPointImgSrc = null;
		}
		this.m_StepLength = 0.1;
		this.m_Style = obj.style ? obj.style : ProgressBar.Style.READONLY;
	};
	
	this.t_getFocus = function() {
		if (this.m_FocusPointImgSrc) {
			this.m_FocusPointWidget.src = this.m_FocusPointImgSrc.focused;
		}
	};
	
	this.t_loseFocus = function() {
		if (this.m_FocusPointImgSrc) {
			this.m_FocusPointWidget.src = this.m_FocusPointImgSrc.unfocused;
		}
	};
		
	this.t_destroy = function() {
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		if (ProgressBar.Style.READONLY == this.m_Style) {
			return false;
		}
		
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}
				
		switch (keycode) {
			case Volt.KEY_JOYSTICK_LEFT:
				if (this.leftKeyCallback != null){
					this.leftKeyCallback();
				}
				break;
				
			case Volt.KEY_JOYSTICK_RIGHT:				
				if (this.rightKeyCallback != null){
					this.rightKeyCallback();
				}
				break;
				
			default:
				break;
		}
		return false;
	};
	
	this.t_onWidthChanged = function(newWidth){
		this.m_ProcessWidget.width = newWidth * this.m_Percentage;		
	};
	
	this.setLeftKeyPressCallback = function(callback){
		this.leftKeyCallback = callback;
	};
	
	this.setRightKeyPressCallback = function(callback){
		this.rightKeyCallback = callback;	
	};
	
	this.resetProgressbar = function(){
		this.m_Percentage = 0;
		this.m_ProcessWidget.width = 0;
	}
	
};

ProgressBar.Style = {
	READONLY:0,
	EDITABLE:1,
};
ProgressBar.prototype = new ControlBase();

exports = ProgressBar;