/** 
 * @author  
 * @fileoverview Definition of SimpleLineListForPopup
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

assert = function(condition, message) {
	if (!condition) {
		print(message);
		throw new Error(message);
    }
};

SimpleLineListForPopup = function() {
	this.m_TopMargin = 0;
	this.m_BottomMargin = 0;
	this.m_ItemHeight = 0;
	this.m_ItemWidth = 0;
	this.m_TotalDataNumber = 0;
	this.m_RenderType = null;
	
	this.m_CurrDataIndex = 0;
	this.m_RenderHeadDataIndex = 0; // data index of render head
	
	this.m_CurrRenderIndex = 0;
	this.m_RenderHead = 0;
	this.m_RenderTail = 0;
	this.m_RenderItemNumber = 0;
	this.m_RenderArray = null;
	
	this.m_BufferNumer = 2;
	
	this.m_ItemLoadCB = null;
	this.m_ItemUnloadCB = null;
	this.m_FocusIndexChangedCB = null;
	this.m_ReachBottomCB = null;
	this.m_LeftKeyPressCB = null;
	this.m_RightKeyPressCB = null;
	this.m_DataChangeCB = null;
	
	this.m_DisplayBG = null;
	this.m_ScrollWidget = null;
	
	this.m_ScrollWidgetYPosition = 0;
	
	this.m_FocusItemIndex = 0;
	this.m_DisplayAreaItemsNumber = 0;
	
	this.m_UpArrowBG = null;
	this.m_DownArrowBG = null;
	this.m_UpArrowWidget = null;
	this.m_DownArrowWidget = null;
	
	this.m_UpArrowSrc = null;
	this.m_DownArrowSrc = null;
	
	this.m_InitMembers = function(param) {
		this.m_ItemHeight = param.itemHeight? param.itemHeight: 72;
		this.m_ItemWidth = param.itemWidth? param.itemWidth: 782;
		this.m_TopMargin = typeof(param.topMargin)=="undefined"? 0: param.topMargin;
		this.m_BottomMargin = typeof(param.bottomMargin)=="undefined"? 0: param.bottomMargin;
		if (!param.width) {
			this.width = this.m_ItemWidth; // change the width of ControlBase
		}
		if (!param.height) {
			this.height = (this.m_TopMargin+this.m_BottomMargin+this.m_ItemHeight*6); // change the height of ControlBase
		}
		
		assert((param.totalDataNumber && param.totalDataNumber != 0), "[SimpleLineListForPopup.js m_InitMembers ERROR] Please specify totalDataNumber while creating");
		this.m_TotalDataNumber = param.totalDataNumber;
		
		assert(param.renderType, "[SimpleLineListForPopup.js m_InitMembers ERROR] Please specify renderType while creating");
		this.m_RenderType = param.renderType;
		
		this.m_RenderArray = [];
		this.m_ItemLoadCB = null;
		this.m_ItemUnloadCB = null;
		this.m_FocusIndexChangedCB = null;
		this.m_ReachBottomCB = null;
		this.m_LeftKeyPressCB = null;
		this.m_RightKeyPressCB = null;
		
		this.m_FocusItemIndex = 0;
		//Calculate numbers of render items (which is also length of m_RenderArray)
		this.m_DisplayAreaItemsNumber = Math.floor((this.height-this.m_TopMargin-this.m_BottomMargin)/this.m_ItemHeight);
		this.m_RenderItemNumber = this.m_DisplayAreaItemsNumber+this.m_BufferNumer*2;
		this.m_RenderHead = 0;
		this.m_RenderTail = this.m_RenderItemNumber-1;
		this.m_CurrRenderIndex = this.m_BufferNumer;
		
		this.m_CurrDataIndex = 0;
		this.m_ScrollWidgetYPosition = 0;
		this.m_RenderHeadDataIndex = -this.m_BufferNumer;
		
		this.m_UpArrowBG = null;
		this.m_DownArrowBG = null;
		this.m_UpArrowWidget = null;
		this.m_DownArrowWidget = null;
		
		this.m_UpArrowSrc = param.upArrowSrc;
		this.m_DownArrowSrc = param.downArrowSrc;
	};
	
	this.m_InitRenderItems = function(param) {
		this.m_DisplayBG = new Widget({
			x: 0,
			y: this.m_TopMargin,
			height: this.height-this.m_TopMargin-this.m_BottomMargin,
			width: this.m_ItemWidth,
			color: {r: 0, g: 0, b: 0, a: 0},
			parent: param.parent,
		});
		this.m_DisplayBG.cropOverflow = true;
		this.m_DisplayBG.origin.x = 0.5;
		this.m_DisplayBG.anchor.x = 0.5;
		
		this.m_ScrollWidget = new Widget({
			x: 0,
			y: this.m_ScrollWidgetYPosition,
			color: {r: 0, g: 0, b: 0, a: 0},
			parent: this.m_DisplayBG,
		});
		
		var offsetPos = 0;
		for (var index = -this.m_BufferNumer; index < this.m_RenderItemNumber-this.m_BufferNumer; index++) {
			var randerItem = new param.renderType();
			if (index < 0) {
				randerItem.create({
					x : 0,
					y : -this.m_ItemHeight,
					width : this.m_ItemWidth,
					height : this.m_ItemHeight,
					parent : this.m_ScrollWidget,
				});
			} else {
				randerItem.create({
					x : 0,
					y : offsetPos,
					width : this.m_ItemWidth,
					height :this.m_ItemHeight,
					parent : this.m_ScrollWidget,
				});
				offsetPos += this.m_ItemHeight;
			}
			this.m_RenderArray.push(randerItem);
		}
		
		this.m_UpArrowBG = new Widget({
			x: 0,
			y: 0,
			height: this.m_TopMargin,
			width: this.width,
			parent: param.parent,
			color: {r: 0, g: 0, b: 0, a: 0},
		});
		this.m_UpArrowBG.anchor.x = 0.5;
		this.m_UpArrowBG.origin.x = 0.5;
		this.m_UpArrowBG.anchor.y = 0.0;
		this.m_UpArrowBG.origin.y = 0.0;
		
		this.m_DownArrowBG = new Widget({
			x: 0,
			y: 0,
			height: this.m_BottomMargin,
			width: this.width,
			parent: param.parent,
			color: {r: 0, g: 0, b: 0, a: 0},
		});
		this.m_DownArrowBG.anchor.x = 0.5;
		this.m_DownArrowBG.origin.x = 0.5;
		this.m_DownArrowBG.anchor.y = 1.0;
		this.m_DownArrowBG.origin.y = 1.0;
		
		this.m_UpArrowWidget = new ImageWidget({
			x: 0,
			y: 0,
			src: param.upArrowSrc?param.upArrowSrc.unHighlight:"",
			parent: this.m_UpArrowBG,
		});
		
		if (this.m_UpArrowWidget != null){
			this.m_UpArrowWidget.hide();
		}
		
		this.m_DownArrowWidget = new ImageWidget({
			x: 0,
			y: 0,
			src: param.downArrowSrc?param.downArrowSrc.unHighlight:"",
			parent: this.m_DownArrowBG,
		});
		
		if (this.m_TotalDataNumber <= this.m_DisplayAreaItemsNumber){
			if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.hide();
			}
		}
	};

	this.t_create = function(param) {
		this.m_InitMembers(param);
		this.m_InitRenderItems(param);
	};
	
	this.t_getFocus = function() {
		this.m_RenderArray[this.m_CurrRenderIndex].getFocus();
		
		if (this.m_UpArrowSrc){
			this.m_UpArrowWidget.src = this.m_UpArrowSrc?this.m_UpArrowSrc.highlight:"";
			this.m_UpArrowWidget.src = this.m_UpArrowSrc?this.m_UpArrowSrc.highlight:"";
		}

		if (this.m_DownArrowSrc){
			this.m_DownArrowWidget.src = this.m_DownArrowSrc?this.m_DownArrowSrc.highlight:"";
			this.m_DownArrowWidget.src = this.m_DownArrowSrc?this.m_DownArrowSrc.highlight:"";
		}
	};
	
	this.t_loseFocus = function() {
		this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
		this.m_UpArrowWidget.src = this.m_UpArrowSrc?this.m_UpArrowSrc.unHighlight:"";
		this.m_DownArrowWidget.src = this.m_DownArrowSrc?this.m_DownArrowSrc.unHighlight:"";
	};
		
	this.t_destroy = function() {
		for(var i=0; i<this.m_RenderItemNumber; ++i) {
			this.m_RenderArray[i].destroy();
		}
		
		if (this.m_ScrollWidget != null){
			this.m_ScrollWidget.destroy();
			this.m_ScrollWidget = null;
		}
		
		if (this.m_UpArrowWidget != null){
			this.m_UpArrowWidget.destroy();
			this.m_UpArrowWidget = null;
		}
		
		if (this.m_UpArrowBG != null){
			this.m_UpArrowBG.destroy();
			this.m_UpArrowBG = null;
		}
		
		if (this.m_DownArrowWidget != null){
			this.m_DownArrowWidget.destroy();
			this.m_DownArrowWidget = null;
		}
		
		if (this.m_DownArrowBG != null){
			this.m_DownArrowBG.destroy();
			this.m_DownArrowBG = null;
		}
		
		if (this.m_DisplayBG != null){
			this.m_DisplayBG.destroy();
			this.m_DisplayBG = null;
		}
		
		this.m_RenderArray.splice(0, this.m_RenderArray.length);
		this.m_RenderArray = null;
	};
	
	this.t_keyHandler = function(keycode, keytype){
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return true;
		}
		
		if (this.m_RenderArray[this.m_CurrRenderIndex].keyHandler(keycode, keytype)) {
			if (this.m_RenderArray[this.m_CurrRenderIndex].IsDataChanged()) {
				this.m_DataChangedCBCall(this.m_RenderArray[this.m_CurrRenderIndex].GetDataIndex(), this.m_RenderArray[this.m_CurrRenderIndex].GetDataItem());
				this.m_RenderArray[this.m_CurrRenderIndex].ResetDataChangeFlag();
			}
			return true;
		}
		
		switch (keycode) {
			case Volt.KEY_JOYSTICK_UP:
				return this.m_keyUpHandler();
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				return this.m_keyDownHandler();
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				this.m_LeftKeyPressCBCall();
				return true;
				break;
			case Volt.KEY_JOYSTICK_RIGHT:
				this.m_RightKeyPressCBCall();
				return true;
				break;
		}
		return false;
	};
	
	this.m_changeFocus = function(oldIndex, newIndx) {
		this.m_RenderArray[oldIndex].loseFocus();
		this.m_RenderArray[newIndx].getFocus();
	};
	
	this.m_keyUpHandler = function() {
		if (this.m_CurrDataIndex == 0) {
			return true;
		}
		
		//call focuschangedCB while data index changed
		var oldDataIndex = this.m_CurrDataIndex;
		var newDataIndex = --this.m_CurrDataIndex;
		this.m_FocusChangedCBCall(oldDataIndex, newDataIndex);
		
		//change focus from old render to new render
		var oldIndex = this.m_CurrRenderIndex;
		var newIndex = this.m_renderIndexMinus(this.m_CurrRenderIndex, 1);
		this.m_changeFocus(oldIndex, newIndex);
		this.m_CurrRenderIndex = newIndex;
		
		//when index item over the display area, scroll the ScrollWidget
		if (this.m_FocusItemIndex == 0) {
			//move the head render after tail render, and change the tail and head render index
			this.m_RenderArray[this.m_RenderTail].y = this.m_RenderArray[this.m_RenderHead].y - this.m_ItemHeight;
			this.m_RenderHead = this.m_RenderTail;
			this.m_RenderTail = this.m_renderIndexMinus(this.m_RenderTail, 1);
			
			//scroll the ScrollWidget
			this.m_ScrollWidgetYPosition += this.m_ItemHeight;
			this.m_ScrollWidget.animate("y", this.m_ScrollWidgetYPosition, 100, "sine");
			this.m_ItemUnloadCBCall(this.m_RenderHeadDataIndex+this.m_RenderItemNumber-1);
			--this.m_RenderHeadDataIndex;
			this.m_ItemLoadCBCall(this.m_RenderHeadDataIndex);
			
			if (this.m_CurrDataIndex == 0){
				if (this.m_UpArrowWidget != null){
					this.m_UpArrowWidget.hide();
				}
			}
			
			if (this.m_CurrDataIndex < this.m_TotalDataNumber-this.m_DisplayAreaItemsNumber){
				if (this.m_DownArrowWidget != null){
					this.m_DownArrowWidget.show();
				}	
			}
			
		} else {
			--this.m_FocusItemIndex;
		}
	};
	
	this.m_keyDownHandler = function() {
		if (this.m_CurrDataIndex == this.m_TotalDataNumber-1) {
			this.m_ReachBottomCBCall();
			return true;
		}
		
		//call focuschangedCB while data index changed
		var oldDataIndex = this.m_CurrDataIndex;
		var newDataIndex = ++this.m_CurrDataIndex;
		this.m_FocusChangedCBCall(oldDataIndex, newDataIndex);
		
		//change focus from old render to new render
		var oldIndex = this.m_CurrRenderIndex;
		var newIndex = this.m_renderIndexPlus(this.m_CurrRenderIndex, 1);
		this.m_changeFocus(oldIndex, newIndex);
		this.m_CurrRenderIndex = newIndex;
		
		//when index item over the display area, scroll the ScrollWidget
		if (this.m_FocusItemIndex == this.m_DisplayAreaItemsNumber - 1) {
			//move the head render after tail render, and change the tail and head render index
			this.m_RenderArray[this.m_RenderHead].y = this.m_RenderArray[this.m_RenderTail].y + this.m_ItemHeight;
			this.m_RenderTail = this.m_RenderHead;
			this.m_RenderHead = this.m_renderIndexPlus(this.m_RenderHead, 1);
			
			//scroll the ScrollWidget
			this.m_ScrollWidgetYPosition -= this.m_ItemHeight;
			this.m_ScrollWidget.animate("y", this.m_ScrollWidgetYPosition, 100, "sine");
			this.m_ItemUnloadCBCall(this.m_RenderHeadDataIndex);
			++this.m_RenderHeadDataIndex;
			this.m_ItemLoadCBCall(this.m_RenderHeadDataIndex+this.m_RenderItemNumber-1);
			
			if (this.m_CurrDataIndex >= this.m_DisplayAreaItemsNumber){
				this.m_UpArrowWidget.show();
			}
			
			if (this.m_CurrDataIndex == this.m_TotalDataNumber-1){
				this.m_DownArrowWidget.hide();
			}
		} else {
			++this.m_FocusItemIndex;
		}
	};
	
	this.setItemLoadCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_ItemLoadCB = callback;
	};
	
	this.setItemUnloadCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_ItemUnloadCB = callback;
	};
	
	this.setFocusIndexChangedCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_FocusIndexChangedCB = callback;
	};
	
	this.setReachBottomCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_ReachBottomCB = callback;
	};
	
	this.setLeftKeyPressCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_LeftKeyPressCB = callback;
	};
	
	this.setRightKeyPressCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_RightKeyPressCB = callback;
	};
	
	this.setDataChangedCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_DataChangeCB = callback;
	};
	
	this.itemUpdate = function(index, dataItem) {
		if (index < 0 || index >= this.m_TotalDataNumber) {
			return;
		}
		
		if (index >= this.m_RenderHeadDataIndex && index < this.m_RenderHeadDataIndex+this.m_RenderItemNumber) {
			var steps = index - this.m_RenderHeadDataIndex;
			var renderIndex = this.m_renderIndexPlus(this.m_RenderHead, steps);
			this.m_RenderArray[renderIndex].itemUpdate(index, dataItem);
		}
	};
	
	this.m_renderIndexPlus = function(startIndex, increment) {
		if (typeof(startIndex)!="undefined" && increment!=undefined) {
			var actualIncrement = increment%this.m_RenderItemNumber;
			for (var index=0; index<actualIncrement; index++) {
				startIndex = startIndex==this.m_RenderItemNumber-1 ? 0: 1+startIndex;
			}
			return startIndex;
		}
		return 0;
	};
	
	this.m_renderIndexMinus = function(startIndex, decrement) {
		if (typeof(startIndex)!="undefined" && decrement!=undefined) {
			var actualDecrement = decrement%this.m_RenderItemNumber;
			for (var index=0; index<actualDecrement; index++) {
				startIndex = startIndex==0 ? this.m_RenderItemNumber-1: startIndex-1;
			}
			return startIndex;
		}
		return 0;
	};
	
	this.m_ItemLoadCBCall = function(index) {
		if (this.m_ItemLoadCB && index>=0 && index<this.m_TotalDataNumber) {
			this.m_ItemLoadCB(index);
		}
	};
	
	this.m_ItemUnloadCBCall = function(index) {
		if (this.m_ItemUnloadCB && index>=0 && index<this.m_TotalDataNumber) {
			this.m_ItemUnloadCB(index);
		}
	};
	
	this.m_FocusChangedCBCall = function(oldIndex, newIndex) {
		if (this.m_FocusIndexChangedCB) {
			this.m_FocusIndexChangedCB(oldIndex, newIndex);
		}
	};
	
	this.m_ReachBottomCBCall = function() {
		if (this.m_ReachBottomCB) {
			this.m_ReachBottomCB();
		}
	};
	
	this.m_LeftKeyPressCBCall = function() {
		if (this.m_LeftKeyPressCB) {
			this.m_LeftKeyPressCB();
		}
	};
	
	this.m_RightKeyPressCBCall = function() {
		if (this.m_RightKeyPressCB) {
			this.m_RightKeyPressCB();
		}
	};
	
	this.m_DataChangedCBCall = function(index, dataItem) {
		if (this.m_DataChangeCB) {
			this.m_DataChangeCB(index, dataItem);
		}
	};
	
	this.update = function() {
		for (var i = this.m_RenderHeadDataIndex; i < this.m_RenderHeadDataIndex+this.m_RenderItemNumber; i++) {
			this.m_ItemUnloadCBCall(i);
			this.m_ItemLoadCBCall(i);
		}
	};
};
SimpleLineListForPopup.prototype = new ControlBase();

exports = SimpleLineListForPopup;