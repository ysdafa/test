/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of Popup_Menu
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");
const Button =  Volt.require("modules/UIElement/Button_Generic.js");
var KeyCode = {
	up : Volt.KEY_JOYSTICK_UP,
	down : Volt.KEY_JOYSTICK_DOWN,
	left : Volt.KEY_JOYSTICK_LEFT,
	right : Volt.KEY_JOYSTICK_RIGHT,
	enter : Volt.KEY_JOYSTICK_OK,
	returnKey : Volt.KEY_RETURN,
}

/**
 * Class Popup_Menu.
class
 * @constructor
 * @extends UIElement/ControlBase UIElement/Button_Generic
 */
 
Popup_Menu = function(){	
	//variable
	this.MenuState={
		normal:0,
		focus:1,
		selected:2,
		dim:3
	};
	this.isMenuShowFlag = false;
	this.hilightIdx = 0;
	this.listNumber = 0;
	this.seletedBtnStatus = -1;
	this.menuListArray = [];
	this.menuListBGArray = [];
	this.menuListData = [];
	this.selectListArray=[];
	this.selectedButton = null;
	this.allListBGWidget=null;
	this.focusIndex=0;
	this.check="";
	this.textPositionX=0;
	this.textPositionY=0;
	this.textWidth=0;
	this.textHeight=0;
	this.itemX=0;
	this.itemY=0;
	this.itemWidth=0;
	this.itemHeight=0;
	this.textFont="SVD Light 20px";
	this.focusTextFont="SVD Light 24px";
	this.selectedTextFont="SVD Light 24px";
	this.dimTextFont="SVD Light 20px";
	this.textColor={r:255,g:255,b:255,a:255*0.6};
	this.focusTextColor={r:255,g:255,b:255,a:255};
	this.selectedTextColor={r:255,g:227,b:56,a:255};
	this.dimTextColor={r:255,g:255,b:255,a:25.5};
	this.borderColor={r:255,g:255,b:255,a:25.5};
	this.focusBorderColor={r:255,g:255,b:255,a:255*0.8};
	this.dimBorderColor={r:255,g:227,b:56,a:255};
	this.selectedBorderColor={r:255,g:227,b:56,a:255*0.8};
	this.borderWidth=1;
	this.focusBorderWidth=2;
	this.dimBorderWidth=1;
	this.selectedBorderWidth=2;
	this.textHorizontalAlignment="center";
	this.textVerticalAlignment="center";
	this.itemBgColor={r:166, g:166, b:166, a:255};
	this.focusItemBgColor=this.itemBgColor;
	this.selectedItemBgColor=this.itemBgColor;
	this.dimItemBgColor=this.itemBgColor;
	this.isCreated =false;
	this.selectedSrcPositionX=0;
	this.selectedSrcPositionY=0;
	this.selectedSrcWidth=0;
	this.selectedSrcHeight=0;
	this.t_clickBtn=null;
	this.btnCallback=null;
	this.listCallback=null;
	this.mouseOverCallBack=null;
	this.mouseOutCallBack=null;
	this.listHeight=0;
	this.bgWidth=270;
	this.bgHeight=66;
	this.listWidth=0;
	this.listNumber=0;
	this.listHeight=0;
	this.listY=0;
	this.listX=0;
	this.listGap=0;
	this.openOverout=false;
	this.openClick=false;
	this.openUpdown=false;
	this.listBgColor={r:0, g:0, b:0, a:0};
	
	/**
	* This function will create a Popup_Menu<p>
	* This function will create a Popup_Menu,You can use this function when you want to create an Popup_Menu Object.
	* @param {Object} param of the new Popup_Menu you want to create.
	* @return {Object} return the new Popup_Menu object you want to create.
	* @example //This example create a new Popup_Menu.
	* const script_AID = "UIElement/Popup_Menu";
	* const Popup_Menu = require(script_AID);
	* PopupMenuSample = new PopupMenu();
	* PopupMenuSample.create({x:500, y:300, width:200, height:60, parent:tempBG});
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
		if(obj.hasOwnProperty("width")){
			this.bgWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.bgHeight=obj.height;
		}
		this.listParent=obj.parent;
		this.selectedButton = new Button();
		this.selectedButton.create({width:this.bgWidth, height:this.bgHeight,parent:obj.parent});
		this.selectedButton.setTextFont("Helvetica 15px");	
		this.selectedButton.hide();
		this.isCreated = true;
	};

	this.t_getFocus = function() {
		if(this.isCreated == true){
			if(this.isMenuShowFlag == true){
				return false;
			}
			else{
				this.selectedButton.getFocus();
				this.seletedBtnStatus = this.selectedButton.buttonState.STATE_FOCUSED;
				return true;
			}
		}
		
		return false;
	};
	
	this.flagoverout=false;
	this.flagclick=false;
	this.flagupdown=false;
	this.menuDim =false;
	this.t_getDim = function() {
		if(this.menuDim == false){
			this.menuDim=true;
			this.flagoverout=this.openOverout;
			this.flagclick=this.openClick;
			this.flagupdown=this.openUpDown;
			if(this.openOverout==true){
				this.enableMouseOverOut(false);
			}
			if(this.openUpDown==true){
				this.enableMouseUpDown(false);
			}
			if(this.openClick==true){
				this.enableMouseClick(false);
			}
			if(this.isMenuShowFlag == true){
				for(var i = 0; i < this.listNumber; i++){
					this.setDim(i);
				}
			}
			this.selectedButton.getDim();
		}
	};
	
	this.t_loseDim = function() {
		if(this.menuDim == true){
			this.menuDim = false;
			this.enableMouseOverOut(this.flagoverout);
			this.enableMouseClick(this.flagclick);
			this.enableMouseUpDown(this.flagupdown);
			this.flagoverout=false;
			this.flagclick=false;
			this.flagupdown=false;
			if(this.isMenuShowFlag == true){
				for(var i = 0; i < this.listNumber; i++){
					if(i!=this.focusIndex&&i!=this.hilightIdx){
						this.setUnDim(i);
					}
				}
				this.setFocusedListIndex(this.focusIndex);
				this.setSelected(this.hilightIdx);
			}
			this.selectedButton.loseDim();
		}
	
	};
	this.menuSelected = false;
	
	this.t_selected = function() {
		if(this.menuSelected == false){
			if(this.isMenuShowFlag == false){
				this.t_clickBtn();
				this.menuSelected = true;
				this.seletedBtnStatus = this.selectedButton.buttonState.STATE_PRESSED;
			}
		}
		
	};
	this.t_unSelected = function(){
		if(this.menuSelected == true){
			if(this.isMenuShowFlag == false){
				this.menuSelected = false;
				this.unSelectedButton.unSelected();
				this.seletedBtnStatus = this.selectedButton.buttonState.STATE_UNFOCUSED;
			}
		}
	};
	
	this.t_loseFocus = function() {
		if(this.isCreated == true){
			if(this.isMenuShowFlag == true){
				this.allListBGWidget.hide();
				this.isMenuShowFlag = false;
				this.setUnFocusedListIndex(this.focusIndex);
			}
			else{
				this.selectedButton.loseFocus();
				this.seletedBtnStatus = this.selectedButton.buttonState.STATE_UNFOCUSED;
			}
			return true;
		}
			
		return false;
	};
	
	
	this.t_destroy = function() {
		delete this.m_buttonMouseOverCallBackBind;			
		delete this.m_buttonMouseOutCallBackBind;
		delete this.t_menuListMouseOverBind;
		delete this.t_menuListMouseOutBind;
		delete this.t_menuListMouseClickBind;
		delete this.t_clickBtnBind;
		delete this.t_listBgMouseOverBind;
		delete this.t_listBgMouseOutBind;
		var num=this.menuListBGArray.length;
		if(num!=0){
			for(var i=num-1;i>=0;i--){
				this.menuListArray[i].destroy();
				this.selectListArray[i].destroy();
				this.menuListBGArray[i].destroy();
			}
			this.menuListArray.splice(0, this.menuListArray.length);
			this.selectListArray.splice(0, this.selectListArray.length);
			this.menuListBGArray.splice(0, this.menuListBGArray.length);
			this.menuListArray = null;
			this.selectListArray = null;
			this.menuListBGArray = null;
		}
		this.menuListData.splice(0, this.menuListData.length);
		this.menuListData = null;
		if(this.allListBGWidget != null){
			this.allListBGWidget.destroy();
			this.allListBGWidget = null;
		}
		if(this.selectedButton != null){
			this.selectedButton.destroy();
			this.selectedButton = null;	
		}
					
	};
	
	this.t_show = function() {
	};

	this.t_hide = function() {
		if(this.isMenuShowFlag == true){
			this.allListBGWidget.hide();
			this.isMenuShowFlag = false;
			this.setUnFocusedListIndex(this.focusIndex);
		}				
	};
	
	this.t_keyHandler = function(keycode, keytype){
		if (this.isCreated == false) {
			return false;
		}
		var bRet=false;
		switch(keycode) {
			case KeyCode.up:
				// to do
				if (this.isMenuShowFlag == true){
					if(this.focusIndex > 0) {
						if(this.focusIndex != this.hilightIdx){
							this.setUnFocusedListIndex(this.focusIndex);
						}
						else{
							this.setSelected(this.focusIndex);
						}
						this.focusIndex--;
						this.setFocusedListIndex(this.focusIndex);
						bRet=true;
					}	
					else if(this.focusIndex == 0) {
						if(this.focusIndex != this.hilightIdx){
							this.setUnFocusedListIndex(this.focusIndex);
						}
						else{
							this.setSelected(this.focusIndex);
						}
						this.focusIndex=this.listNumber-1;
						this.setFocusedListIndex(this.focusIndex);
						bRet=true;
					}
					else{
					}
				}
				break;
			case KeyCode.down:
				if (this.isMenuShowFlag == true){
					if(this.focusIndex < this.listNumber-1) {
						if(this.focusIndex != this.hilightIdx){
							this.setUnFocusedListIndex(this.focusIndex);
						}
						else{
							this.setSelected(this.focusIndex);
						}
						this.focusIndex++;
						this.setFocusedListIndex(this.focusIndex);
						bRet=true;
					}
					else if(this.focusIndex == this.listNumber-1){
						if(this.focusIndex != this.hilightIdx){
							this.setUnFocusedListIndex(this.focusIndex);
						}
						else{
							this.setSelected(this.focusIndex);
						}
						this.focusIndex=0;
						this.setFocusedListIndex(this.focusIndex);
						bRet=true;
					}
					else{
					}
				}
				// to do
				break;
			case KeyCode.enter:							
					if(this.isMenuShowFlag == false) {
						this.t_clickBtn();	
						bRet=true;
					}
					else{
						this.t_clickitem();
						bRet=true;
					}
					
				break;
			case KeyCode.returnKey:
					if(this.isMenuShowFlag == true) {
						this.selectedButton.getFocus();
						this.seletedBtnStatus = this.selectedButton.buttonState.STATE_FOCUSED;
						this.allListBGWidget.hide();
						this.isMenuShowFlag = false;	
						this.setUnFocusedListIndex(this.focusIndex);
						bRet=true;
					}
					else{
					
					}
				
				break;
			default:
				// to do
				break;
		}
		
		return bRet;
	};
	
	/**
	* This function will set menu list space. <p>
	* This function will set menu list space,You can use this function when you want to set menu list space.
	* @param {Object} param of the menu list space you want to create.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set menu list space.
	* PopupMenuSample.setMenuListSpace({x:500, 
									  y:78,
									  width:200, 
									  height:250,  
									  parent:tempBG, 
									  bgcolor:colorbg});
	* @since The version 1.0 this function is added.
	*/
	this.setMenuListSpace = function(obj){
		if(this.isCreated == false){
			return false;
		}
		if(obj==null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.listX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.listY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.listWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.listHeight=obj.height;
		}
		if(obj.hasOwnProperty("parent")){
			this.listParent=obj.parent;
		}
		else{
			this.listParent=this.selectedButton;
		}	
		if(obj.hasOwnProperty("bgcolor")){
			this.listBgColor=obj.bgcolor;
		}
		if(this.allListBGWidget==null){
			this.allListBGWidget = new Widget({
			});
		}
		this.allListBGWidget.x = this.listX;
		this.allListBGWidget.y = this.listY;
		this.allListBGWidget.width = this.listWidth;
		this.allListBGWidget.height = this.listHeight;
		this.allListBGWidget.color = this.listBgColor;
		this.allListBGWidget.parent = this.listParent;
		this.initx=this.allListBGWidget.getAbsolutePosition().x;
		this.inity=this.allListBGWidget.getAbsolutePosition().y;
		return true;
	};
	
	/**
	* This function will set menu list content property. <p>
	* This function will set menu list content property,You can use this function when you want to set menu list content.
	* @param {Object} param of menu list content property you want to create.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set menu list space.
	* listData = ["Apples", "Oranges", "Pipeapples", "Straberries"];
	* PopupMenuSample.setMenuListContent({
										x:10, 
										y:10,
										width:180, 
										height:50,
									    check:{x:5,y:5,width:40,height:40,imagesrc:{normal:"CheckBox/popup_check_icon_n.png",
																			        focus:"CheckBox/popup_check_icon_f.png",
																					selected:"CheckBox/popup_check_icon_s.png",
																					dim:"CheckBox/popup_check_icon_d.png"}},
										listdata:listData,
										selectedIdx:1,
										text:{x:50,y:5,width:120,height:40,textVerticalAlignment:"top",textHorizontalAlignment:"left",
											font:{normal:"30px",focus:"36px",selected:"36px",dim:"30px"},
											textcolor:{normal:{r:255},focus:{g:255},selected:{b:255},dim:{r:122}},
											},
										itembgcolor:{normal:{b:255},focus:{r:255},selected:{g:255},dim:{b:122}},
										border:{normal:{width:1,color:{r:255}},
												focus:{width:2,color:{g:255}},
												selected:{width:3,color:{b:255}},
												dim:{width:4,color:{r:122}}},
										itemgap:10
										});
	* @since The version 1.0 this function is added.
	*/
	this.setMenuListContent = function(obj){
		if(this.allListBGWidget==null){
			return false;
		}
		if(obj==null||typeof(obj) == "undefined"){
			return false;
		}
		var ischeck=false;
		if(obj.hasOwnProperty("x")){
			this.itemX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.itemY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.itemWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.itemHeight=obj.height;
		}
		if(obj.hasOwnProperty("check")){
			if(obj.check.hasOwnProperty("x")){
				this.selectedSrcPositionX=obj.check.x;
			}
			if(obj.check.hasOwnProperty("y")){
				this.selectedSrcPositionY=obj.check.y;
			}
			if(obj.check.hasOwnProperty("width")){
				this.selectedSrcWidth=obj.check.width;
			}
			if(obj.check.hasOwnProperty("height")){
				this.selectedSrcHeight=obj.check.height;
			}
			if(obj.check.hasOwnProperty("imagesrc")){
				if(obj.check.imagesrc.hasOwnProperty("normal")){
					this.check=obj.check.imagesrc.normal;
				}
				if(obj.check.imagesrc.hasOwnProperty("focus")){
					this.focusCheck=obj.check.imagesrc.focus;
				}
				else{
					this.focusCheck=this.check;
				}
				if(obj.check.imagesrc.hasOwnProperty("selected")){
					this.selectedCheck=obj.check.imagesrc.selected;
				}
				else{
					this.selectedCheck=this.check;
				}
				if(obj.check.imagesrc.hasOwnProperty("dim")){
					this.dimCheck=obj.check.imagesrc.dim;
				}
				else{
					this.dimCheck=this.check;
				}
			}
			ischeck=true;
		}
		var istext=false;
		
		if(obj.hasOwnProperty("text")){
			if(obj.text.hasOwnProperty("x")){
				this.textPositionX=obj.text.x;
			}
			if(obj.text.hasOwnProperty("y")){
				this.textPositionY=obj.text.y;
			}
			if(obj.text.hasOwnProperty("width")){
				this.textWidth=obj.text.width;
			}
			if(obj.text.hasOwnProperty("height")){
				this.textHeight=obj.text.height;
			}
			if(obj.text.hasOwnProperty("font")){
				if(obj.text.font.hasOwnProperty("normal")){
					this.textFont=obj.text.font.normal;
				}
				if(obj.text.font.hasOwnProperty("focus")){
					this.focusTextFont=obj.text.font.focus;
				}
				else{
					this.focusTextFont=this.textFont;
				}
				if(obj.text.font.hasOwnProperty("selected")){
					this.selectedTextFont=obj.text.font.selected;
				}
				else{
					this.selectedTextFont=this.textFont;
				}
				if(obj.text.font.hasOwnProperty("dim")){
					this.dimTextFont=obj.text.font.dim;
				}
				else{
					this.dimTextFont=this.textFont;
				}
			}
			if(obj.text.hasOwnProperty("textcolor")){
				if(obj.text.textcolor.hasOwnProperty("normal")){
					this.textColor=obj.text.textcolor.normal;
				}
				if(obj.text.textcolor.hasOwnProperty("focus")){
					this.focusTextColor=obj.text.textcolor.focus;
				}
				if(obj.text.textcolor.hasOwnProperty("selected")){
					this.selectedTextColor=obj.text.textcolor.selected;
				}
				if(obj.text.textcolor.hasOwnProperty("dim")){
					this.dimTextColor=obj.text.textcolor.dim;
				}
			}
			if(obj.text.hasOwnProperty("textVerticalAlignment")){
				this.textVerticalAlignment=obj.text.textVerticalAlignment;
			}
			if(obj.text.hasOwnProperty("textHorizontalAlignment")){
				this.textHorizontalAlignment=obj.text.textHorizontalAlignment;
			}
		}
		
		if(obj.hasOwnProperty("border")){
			if(obj.border.hasOwnProperty("normal")){
				if(obj.border.normal.hasOwnProperty("width")){
					this.borderWidth=obj.border.normal.width;
				}
				if(obj.border.normal.hasOwnProperty("color")){
					this.borderColor=obj.border.normal.color;
				}
			}
			if(obj.border.hasOwnProperty("focus")){
				if(obj.border.focus.hasOwnProperty("width")){
					this.focusBorderWidth=obj.border.focus.width;
				}
				if(obj.border.focus.hasOwnProperty("color")){
					this.focusBorderColor=obj.border.focus.color;
				}
			}
			if(obj.border.hasOwnProperty("selected")){
				if(obj.border.selected.hasOwnProperty("width")){
					this.selectedBorderWidth=obj.border.selected.width;
				}
				if(obj.border.selected.hasOwnProperty("color")){
					this.selectedBorderColor=obj.border.selected.color;
				}
			}
			if(obj.border.hasOwnProperty("dim")){
				if(obj.border.dim.hasOwnProperty("width")){
					this.dimBorderWidth=obj.border.dim.width;
				}
				if(obj.border.dim.hasOwnProperty("color")){
					this.dimBorderColor=obj.border.dim.color;
				}
			}
		}
		
		if(obj.hasOwnProperty("itembgcolor")){
			if(obj.itembgcolor.hasOwnProperty("normal")){
				this.itemBgColor=obj.itembgcolor.normal;
			}
			if(obj.itembgcolor.hasOwnProperty("focus")){
				this.focusItemBgColor=obj.itembgcolor.focus;
			}
			if(obj.itembgcolor.hasOwnProperty("selected")){
				this.selectedItemBgColor=obj.itembgcolor.selected;
			}
			if(obj.itembgcolor.hasOwnProperty("dim")){
				this.dimItemBgColor=obj.itembgcolor.dim;
			}
		}
		
		if(obj.hasOwnProperty("listdata")){
			var num2=obj.listdata.length;
			for(var i=0;i<num2;i++){
				if("string" != typeof(obj.listdata[i])){
					break;
				}
			}
			if(i == num2){
				this.menuListData.splice(0, this.menuListData.length);
				this.menuListData = obj.listdata;
			}				
		}
		if(obj.hasOwnProperty("itemgap")){
			this.itemGap=obj.itemgap;
		}
		if(obj.hasOwnProperty("selectedIdx")){
			if("number" == typeof(obj.selectedIdx)){
				this.hilightIdx = obj.selectedIdx;
			}
		}
		this.listNumber=this.menuListData.length;
		var num=this.menuListBGArray.length;
		if(num!=this.listNumber){
			for(var i=num-1;i>=0;i--){
				this.menuListArray[i].destroy();
				this.selectListArray[i].destroy();
				this.menuListBGArray[i].destroy();
			}
			this.menuListArray.splice(0, this.menuListArray.length);
			this.selectListArray.splice(0, this.selectListArray.length);
			this.menuListBGArray.splice(0, this.menuListBGArray.length);
		}
		if(this.isCreated == true&&this.listNumber>0&&this.allListBGWidget!=null){
			var num1=this.menuListArray.length;
			if(num1==0){
				for(var i = 0; i < this.listNumber; i++){
					this.menuListBGArray[i] = new Widget({
							x : this.itemX,
							y : this.itemY+(this.itemHeight+this.itemGap)*i,
							width :this.itemWidth,
							height :this.itemHeight,
							color : this.itemBgColor,
							parent : this.allListBGWidget
					});
					this.menuListBGArray[i].index=i;
					this.menuListBGArray[i].border.width=this.borderWidth;
					this.menuListBGArray[i].border.color=this.borderColor;
				
					this.selectListArray[i] = new ImageWidget({
							x : this.selectedSrcPositionX,
							y : this.selectedSrcPositionY,
							width : this.selectedSrcWidth,
							height :this.selectedSrcHeight,
							src :	"",
							parent : this.menuListBGArray[i]
					});
					
					this.menuListArray[i] = new TextWidget({
							x : this.textPositionX,
							y : this.textPositionY,
							width : this.textWidth,
							height : this.textHeight,
							font : this.textFont,
							horizontalAlignment : this.textHorizontalAlignment,
							verticalAlignment : this.textVerticalAlignment,
							text : this.menuListData[i],
							textColor : this.textColor,
							parent : this.menuListBGArray[i]
					});
				}
			}
			else{
				for(var i = 0; i < this.listNumber; i++){
					this.menuListBGArray[i].x=this.itemX;
					this.menuListBGArray[i].y = this.itemY+(this.itemHeight+this.itemGap)*i;
					this.menuListBGArray[i].width = this.itemWidth;
					this.menuListBGArray[i].height = this.itemHeight;
					this.menuListBGArray[i].color = this.itemBgColor;
					this.menuListBGArray[i].index = i;
					this.selectListArray[i].x = this.selectedSrcPositionX;
					this.selectListArray[i].y = this.selectedSrcPositionY;
					this.selectListArray[i].width = this.selectedSrcWidth;
					this.selectListArray[i].height = this.selectedSrcHeight;
					this.selectListArray[i].src = this.check;
					this.menuListArray[i].x = this.textPositionX;
					this.menuListArray[i].y = this.textPositionY;
					this.menuListArray[i].width = this.textWidth;
					this.menuListArray[i].height = this.textHeight;
					this.menuListArray[i].font = this.textFont;
					this.menuListArray[i].text = this.menuListData[i];
					this.menuListArray[i].textColor=this.textColor;
					this.menuListBGArray[i].border.width=this.borderWidth;
					this.menuListBGArray[i].border.color=this.borderColor;
				}
			}
			
			if(this.isMenuShowFlag == false){
				this.allListBGWidget.hide();
			}
			this.selectedButton.setText(this.selectedButton.buttonState.STATE_UNFOCUSED, this.menuListData[this.hilightIdx]);
			this.selectedButton.setText(this.selectedButton.buttonState.STATE_FOCUSED, this.menuListData[this.hilightIdx]);
			this.selectedButton.setText(this.selectedButton.buttonState.STATE_PRESSED, this.menuListData[this.hilightIdx]);
			this.selectedButton.setText(this.selectedButton.buttonState.STATE_DISABLED, this.menuListData[this.hilightIdx]);
			this.setSelected(this.hilightIdx);
			this.seletedBtnStatus = this.selectedButton.buttonState.STATE_UNFOCUSED;
			this.selectedButton.show();
			this.selectedButton.setMouseClickCallback(this.t_clickBtnBind);			
			return true;
		}						
		return false;
	};
	
	this.m_buttonMouseOverCallBack=function(widget){
		if(this.isMenuShowFlag == true) {
			this.setUnFocusedListIndex(this.focusIndex);
		}
		else{
			if(this.mouseOverCallBack!=null)
			{
				this.mouseOverCallBack(this);
			}
		}
	};
	this.m_buttonMouseOverCallBackBind=this.m_buttonMouseOverCallBack.bind(this);
	
	this.m_buttonMouseOutCallBack=function(widget){
		if(this.seletedBtnStatus == this.selectedButton.buttonState.STATE_PRESSED){
			this.selectedButton.selected();
		}
		if(this.mouseOutCallBack!=null)
		{
			this.mouseOutCallBack(this);
		}
	};
	this.m_buttonMouseOutCallBackBind = this.m_buttonMouseOutCallBack.bind(this); 

	this.t_menuListMouseOver = function(targetWidget, eventData) {
		if(this.focusIndex != this.hilightIdx){
			this.setUnFocusedListIndex(this.focusIndex);
		}
		else{
			this.setSelected(this.focusIndex);
		}
		this.focusIndex=targetWidget.index;
		this.setFocusedListIndex(this.focusIndex);
		return false;
	};
	this.t_menuListMouseOverBind = this.t_menuListMouseOver.bind(this);                 	

	this.t_menuListMouseOut = function(targetWidget, eventData) {
		var index=targetWidget.index;
		if(index != this.hilightIdx){
			this.setUnFocusedListIndex(index);
		}
		else{
			this.setSelected(index);
		}
		return false;
	};
	this.t_menuListMouseOutBind = this.t_menuListMouseOut.bind(this);   	
	
	this.t_menuListMouseClick = function(targetWidget, eventData) {
		this.focusIndex=targetWidget.index;
		this.t_clickitem();
		return false;
	};	
	this.t_menuListMouseClickBind = this.t_menuListMouseClick.bind(this); 	
	
	this.t_clickBtn= function(){
		if(this.isMenuShowFlag == false){
			this.focusIndex=0;
			this.allListBGWidget.show();
			this.isMenuShowFlag = true;
			//this.selectedButton.loseFocus();
			this.selectedButton.selected();
			this.seletedBtnStatus = this.selectedButton.buttonState.STATE_PRESSED;
			this.setFocusedListIndex(this.focusIndex);
			if(this.btnCallback!=null)
			{
				this.btnCallback();
			}
		}
		else{
		}		
	};
	this.t_clickBtnBind = this.t_clickBtn.bind(this); 		
	
	this.t_listBgMouseOver = function(targetWidget, eventData) {
		return false;
	};
	this.t_listBgMouseOverBind=this.t_listBgMouseOver.bind(this);

	this.t_listBgMouseOut = function(targetWidget, eventData) {
		return false;
	};
	
	this.t_listBgMouseOutBind=this.t_listBgMouseOut.bind(this);
	
	this.t_setMouseOverOutCallback = function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("overCallback")){
			this.mouseOverCallBack=obj.overCallback;
		}
		if(obj.hasOwnProperty("outCallback")){
			this.mouseOutCallBack=obj.outCallback;
		}
	};
	
	this.t_MouseOverOut = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openOverout==false){
					this.selectedButton.enableMouseOverOut(true);
					this.selectedButton.setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind,outCallback:this.m_buttonMouseOutCallBackBind});
					if(this.allListBGWidget!=null){
						this.allListBGWidget.addEventListener("OnMouseOver", this.t_listBgMouseOverBind); 
						this.allListBGWidget.addEventListener("OnMouseOut", this.t_listBgMouseOutBind); 
					}
					for(var i = 0; i < this.listNumber; i++){
						if(this.menuListBGArray[i] != null||typeof(this.menuListBGArray[i]) != "undefined"){
							this.menuListBGArray[i].addEventListener("OnMouseOver", this.t_menuListMouseOverBind); 				              
							this.menuListBGArray[i].addEventListener("OnMouseOut", this.t_menuListMouseOutBind); 							
						}				
						              
					}
					this.openOverout=true;
				}
			}
			else{
				if(this.openOverout==true){
					this.selectedButton.enableMouseOverOut(false);
					if(this.allListBGWidget!=null){
						this.allListBGWidget.removeEventListener("OnMouseOver", this.t_listBgMouseOverBind); 
						this.allListBGWidget.removeEventListener("OnMouseOut", this.t_listBgMouseOutBind); 
					}
					for(var i = 0; i < this.listNumber; i++){
						if(this.menuListBGArray[i] != null||typeof(this.menuListBGArray[i]) != "undefined"){
							this.menuListBGArray[i].removeEventListener("OnMouseOver", this.t_menuListMouseOverBind); 				              
							this.menuListBGArray[i].removeEventListener("OnMouseOut", this.t_menuListMouseOutBind);
						}				
						                 
					}
					this.openOverout=false;
				}
			}
		}
	};
	
	this.t_MouseUpDown = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openUpdown==false){
					this.selectedButton.enableMouseUpDown(true);						
					this.openUpdown=true;
				}
			}				
			else{
				if(this.openUpdown==true){
					this.selectedButton.enableMouseUpDown(false);
					this.openUpdown=false;						
				}	
			}
		}
	};
	
	this.t_MouseClick= function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openClick==false){
					this.selectedButton.enableMouseClick(true);
					for(var i = 0; i < this.listNumber; i++){
						if(this.menuListBGArray[i] != null||typeof(this.menuListBGArray[i]) != "undefined"){
							this.menuListBGArray[i].addEventListener("OnMouseClick", this.t_menuListMouseClickBind);
						}				                 
					
					}	
					this.openClick=true;					
						
				}
			}	
		}
		else{
			if(this.openClick==true){
				this.selectedButton.enableMouseClick(false);
				for(var i = 0; i < this.listNumber; i++){
					if(this.menuListBGArray[i] != null||typeof(this.menuListBGArray[i]) != "undefined"){
						this.menuListBGArray[i].removeEventListener("OnMouseClick", this.t_menuListMouseClickBind);
					}				                 
				}
				this.openClick=false;
			}	
		}
	};
	
	this.t_clickitem= function(){
		if(this.isMenuShowFlag == true){
			this.setUnFocusedListIndex(this.focusIndex);
			if(this.listCallback!=null){
				this.listCallback(this.focusIndex);
			}
			if(this.hilightIdx!=this.focusIndex){
				this.setUnSelected(this.hilightIdx);
				this.hilightIdx=this.focusIndex;
				this.setSelected(this.hilightIdx);
				this.selectedButton.setText(this.selectedButton.buttonState.STATE_UNFOCUSED, this.menuListData[this.hilightIdx]);
				this.selectedButton.setText(this.selectedButton.buttonState.STATE_FOCUSED, this.menuListData[this.hilightIdx]);
				this.selectedButton.setText(this.selectedButton.buttonState.STATE_PRESSED, this.menuListData[this.hilightIdx]);
				this.selectedButton.setText(this.selectedButton.buttonState.STATE_DISABLED, this.menuListData[this.hilightIdx]);
				this.selectedButton.getFocus();
			}
			else{
				this.setSelected(this.hilightIdx);
				this.selectedButton.getFocus();
			}
			this.seletedBtnStatus = this.selectedButton.buttonState.STATE_FOCUSED;
			this.allListBGWidget.hide();
			this.isMenuShowFlag = false;
			
		}
		else{
		
		}
	};
	
	
	
	this.setUnFocusedListIndex = function(index){
		if(this.isCreated == true){
			if (index >= 0){
				if(index<this.listNumber){
					this.selectListArray[index].src=this.check;
					this.menuListBGArray[index].color = this.itemBgColor;
					this.menuListArray[index].font = this.textFont;
					this.menuListArray[index].textColor=this.textColor;
					this.menuListBGArray[index].border.width=this.borderWidth;
					this.menuListBGArray[index].border.color=this.borderColor;
					return true;
				}
			}
		}	
		return false;
	};
	
	this.setUnSelected = function(index){
		if(this.isCreated == true){
			if (index >= 0){
				if(index<this.listNumber){
					this.selectListArray[index].src=this.check;
					this.menuListBGArray[index].color = this.itemBgColor;
					this.menuListArray[index].font = this.textFont;
					this.menuListArray[index].textColor=this.textColor;
					this.menuListBGArray[index].border.width=this.borderWidth;
					this.menuListBGArray[index].border.color=this.borderColor;
					return true;
				}
			}
		}	
		return false;
	};
	
	this.setSelected = function(index){
		if(this.isCreated == true){
			if (index >= 0){
				if(index<this.listNumber){
					this.selectListArray[index].src=this.selectedCheck;
					this.menuListBGArray[index].color = this.selectedItemBgColor;
					this.menuListArray[index].font = this.selectedTextFont;
					this.menuListArray[index].textColor=this.selectedTextColor;
					this.menuListBGArray[index].border.width=this.selectedBorderWidth;
					this.menuListBGArray[index].border.color=this.selectedBorderColor;
					return true;
				}
			}
		}	
		return false;
	};

	this.setFocusedListIndex = function(index){
		if(this.isCreated == true){
			if (index >= 0){
				if(index<this.listNumber){
					this.menuListBGArray[index].color=this.focusItemBgColor;
					this.menuListArray[index].textColor=this.focusTextColor;
					this.menuListArray[index].font=this.focusTextFont;
					this.selectListArray[index].src=this.focusCheck;
					this.menuListBGArray[index].border.width=this.focusBorderWidth;
					this.menuListBGArray[index].border.color=this.focusBorderColor;
					return true;
				}
			}
		}	
		return false;
	};
	
	this.setUnDim = function(index){
		if(this.isCreated == true){
			if (index >= 0){
				if(index<this.listNumber){
					this.selectListArray[index].src=this.check;
					this.menuListBGArray[index].color = this.itemBgColor;
					this.menuListArray[index].font = this.textFont;
					this.menuListArray[index].textColor=this.textColor;
					this.menuListBGArray[index].border.width=this.borderWidth;
					this.menuListBGArray[index].border.color=this.borderColor;
					return true;
				}
			}
		}	
		return false;
	};
	
	this.setDim  = function(index){
		if(this.isCreated == true){
			if (index >= 0){
				if(index<this.listNumber){
					this.selectListArray[index].src=this.dimCheck;
					this.menuListBGArray[index].color = this.dimItemBgColor;
					this.menuListArray[index].font = this.dimTextFont;
					this.menuListArray[index].textColor=this.dimTextColor;
					this.menuListBGArray[index].border.width=this.dimBorderWidth;
					this.menuListBGArray[index].border.color=this.dimBorderColor;
					return true;
				}
			}
		}	
		return false;
	};
	
	/**
	* This function will set the image property of button<p>
	* This function will set the image property of button,You can use this function when you want to set the image property of buttonn.
	* @param1 {btnState}.
	* @param2 {String}.
	* @return {Void}.
	* @example //This example set title property.
	* PopupMenuSample.setSelectedBtnImage(PopupMenuSample.selectedButton.buttonState.STATE_UNFOCUSED, "button/popup_btn_n.png");
	* @since The version 1.0 this function is added.
	*/
	this.setSelectedBtnImage = function(btnState, imgSrc) {
		if ("string"== typeof(imgSrc)){
			this.selectedButton.setImage(btnState, imgSrc);
		}
	};
	
	 /**
	* This function will set callback function called when click button<p>
	* This function will set callback function called when click button,You can use this function when you want to set callback function called when click button.
	* @param {Function}callback function called when click button.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set title property.
	* PopupMenuSample.setSelectedBtnCallback(btncal);
	* @since The version 1.0 this function is added.
	*/
	this.setSelectedBtnCallback = function(btncallback) {
		if(this.isCreated == true) {
			this.btnCallback=btncallback;
			return true;
		}
		return false;
	};
	
	  /**
	* This function will set callback function called when click list item<p>
	* This function will set callback function called when click list item,You can use this function when you want to set callback function called when click list item.
	* @param {Function}callback function called when click list item.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example callback function called when click list item.
	* PopupMenuSample.setSelectedListCallback(listcal);
	* @since The version 1.0 this function is added.
	*/
	this.setSelectedListCallback = function(listcallback) {
		if(this.isCreated == true) {
			this.listCallback=listcallback;
			return true;
		}
		return false;
	};
}

Popup_Menu.prototype = new ControlBase();
exports = Popup_Menu;