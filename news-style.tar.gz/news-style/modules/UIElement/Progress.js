 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of Progress
 * @date    2014/08/08
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

/**
 * Class Progress.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
Progress = function() {
    //inner data
    this.processedBar = null;
    this.sliderDial = null;
    this.balloon = null;
    this.balloonTail = null;
    this.leftKeyCallback = null;
    this.rightKeyCallback = null;
    this.mouseCallback = null;
    //for mouse drag
    this.isMouseDown = false;
    this.MouseDownPosX = 0;
    this.DragStartDialPosX = 0;
    this.sliderDialSrc = "";
    this.stepNumber = 100;
    this.currentStep = 0;
    this.readOnly = false;
    this.sliderDialFocusSrc = "";
    this.sliderDialWidth = scene.width*0.036458/2;
    this.sliderDialHeight = scene.width*0.036458/2;
    this.processedColor = {r:255,g:255,b:255,a:255};
    this.unprocessColor = {r:255,g:255,b:255,a:26};
    //balloon, optional
    this.balloonTailSrc = "";
    this.balloonWidth = scene.width*0.036458;
    this.balloonHeight = this.balloonWidth/16*9;
    this.balloonGapSize = scene.width*0.013889;
    this.textFont = "Helvetica 30px";
    this.textColor = {r:64,g:64,b:64,a:204};
    this.textBGColor = {r:255,g:255,b:255,a:255};
    
    this.m_setProperty = function(obj) {
        if (obj.hasOwnProperty("sliderDialSrc") 
            && "string" == typeof obj.sliderDialSrc && 0 != obj.sliderDialSrc.length) {
            this.sliderDialSrc = obj.sliderDialSrc;
        }
        if (obj.hasOwnProperty("stepNumber") 
            && "number" == typeof obj.stepNumber && obj.stepNumber >= 1) {
            this.stepNumber = Math.floor(obj.stepNumber);
        }
        if (obj.hasOwnProperty("currentStep") 
            && "number" == typeof obj.currentStep 
            && obj.currentStep <= this.stepNumber && obj.currentStep >= 0) {
            this.currentStep = obj.currentStep;
        }
        if (obj.hasOwnProperty("readOnly") 
            && "boolean" == typeof obj.readOnly) {
            this.readOnly = obj.readOnly;
        }
        if (obj.hasOwnProperty("width") 
            && "number" == typeof obj.width) {
            this.width = obj.width;
        }
        else{
            this.width = scene.width*0.193750;
        }
        if (obj.hasOwnProperty("height") 
            && "number" == typeof obj.height) {
            this.height = obj.height;
        }
        else{
            this.height = scene.height*0.001852;
        }
        if (obj.hasOwnProperty("sliderDialFocusSrc") 
            && "string" == typeof obj.sliderDialFocusSrc && 0 != obj.sliderDialFocusSrc.length) {
            this.sliderDialFocusSrc = obj.sliderDialFocusSrc;
        }
        else {
            this.sliderDialFocusSrc = obj.sliderDialSrc;
        }
        if (obj.hasOwnProperty("sliderDialWidth") 
            && "number" == typeof obj.sliderDialWidth) {
            this.sliderDialWidth = obj.sliderDialWidth;
        }
        if (obj.hasOwnProperty("sliderDialHeight") 
            && "number" == typeof obj.sliderDialHeight) {
            this.sliderDialHeight = obj.sliderDialHeight;
        }
        if (obj.hasOwnProperty("processedColor") 
            && "object" == typeof obj.processedColor) {
            this.processedColor = obj.processedColor;
        }
        if (obj.hasOwnProperty("unprocessColor") 
            && "object" == typeof obj.unprocessColor) {
            this.unprocessColor = obj.unprocessColor;
        }
        //balloon related.
        if (obj.hasOwnProperty("balloonTailSrc") 
            && "string" == typeof obj.balloonTailSrc && 0 != obj.balloonTailSrc.length) {
            this.balloonTailSrc = obj.balloonTailSrc;
        }
        if (obj.hasOwnProperty("balloonWidth") 
            && "number" == typeof obj.balloonWidth) {
            this.balloonWidth = obj.balloonWidth;
        }
        if (obj.hasOwnProperty("balloonHeight") 
            && "number" == typeof obj.balloonHeight) {
            this.balloonHeight = obj.balloonHeight;
        }
        if (obj.hasOwnProperty("balloonGapSize") 
            && "number" == typeof obj.balloonGapSize) {
            this.balloonGapSize = obj.balloonGapSize;
        }
        if (obj.hasOwnProperty("textFont") 
            && "string" == typeof obj.textFont && 0 != obj.textFont.length) {
            this.textFont = obj.textFont;
        }
        if (obj.hasOwnProperty("textColor") 
            && "object" == typeof obj.textColor) {
            this.textColor = obj.textColor;
        }
        if (obj.hasOwnProperty("textBGColor") 
            && "object" == typeof obj.textBGColor) {
            this.textBGColor = obj.textBGColor;
        }
        
        return true;
    };
	
	/**
	* This function creates a progerss object. 
	* @param {Object} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/	
	this.t_create = function(obj) {
        var ret = this.m_setProperty(obj);
        if(!ret){
            return null;
        }
        //reset background property.
        this.rootWidget.color = this.unprocessColor;
        //create elements
        this.processedBar = new Widget({
            x: 0,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.width*(this.currentStep/this.stepNumber),
            height: this.height,
            color: this.processedColor,
            parent: obj.parent,
        });
        this.sliderDial = new ImageWidget({
            x: this.processedBar.x+this.processedBar.width,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0.5,y:0.5},
            width: this.sliderDialWidth,
            height: this.sliderDialHeight,
            src: this.sliderDialSrc,
            parent: obj.parent,
        });
        if(0 < this.balloonTailSrc.length){
            this.balloon = new TextWidget({
                x: this.processedBar.x+this.processedBar.width,
                y: this.processedBar.height/2-this.sliderDialHeight/2-this.balloonGapSize-this.balloonHeight,
                origin: {x:0,y:0},
                anchor: {x:0.5,y:0},
                width: this.balloonWidth,
                height: this.balloonHeight,
                text: (Math.floor(this.currentStep)).toString(),
                font: this.textFont,
                textColor: this.textColor,
                color: this.textBGColor,
                horizontalAlignment: "center",
                verticalAlignment: "center",
                parent: obj.parent,
            });
            this.balloonTail = new ImageWidget({
                x: this.processedBar.x+this.processedBar.width,
                y: this.processedBar.height/2-this.sliderDialHeight/2-this.balloonGapSize,
                origin: {x:0,y:0},
                anchor: {x:0.5,y:0},
                src: this.balloonTailSrc,
                parent: obj.parent,
            });
        }
        
        return this;
	};

	this.t_getFocus = function() {
        this.sliderDial.src = this.sliderDialFocusSrc;
	};
	this.t_loseFocus = function() {
        this.sliderDial.src = this.sliderDialSrc;
	};
	this.t_hide = function() {
		this.t_loseFocus();
	};		
	this.t_destroy = function() {
        if(null != this.processedBar) {
            this.processedBar.destroy();
            this.processedBar = null;
        }
        if(null != this.sliderDial) {
            this.sliderDial.destroy();
            this.sliderDial = null;
        }
        if(null != this.balloon) {
            this.balloon.destroy();
            this.balloon = null;
        }
        if(null != this.balloonTail) {
            this.balloonTail.destroy();
            this.balloonTail = null;
        }
        
        delete this.m_ClickHandlerBinder;
        delete this.m_DownHandlerBinder;
        delete this.m_MoveHandlerBinder;
        delete this.m_UpHandlerBinder;
	};
    
	this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        if (keytype == Volt.EVENT_KEY_RELEASE || !this.isFocused || this.readOnly) 
        {
            return ret;
        }	
        switch(keycode) 
        {
            case Volt.KEY_JOYSTICK_RIGHT:
                if(this.currentStep < this.stepNumber)
                {
                    this.goForward1Step();
                    ret = true;
                }
                break;			
            case Volt.KEY_JOYSTICK_LEFT:	
                if(this.currentStep > 0)
                {
                    this.goBackward1Step();
                    ret = true;
                }
                break;
            default:
                break;
        } 					
        return ret;
	};
    
    this.m_update = function()
	{
        if(this.isCreated) {
            this.processedBar.width = this.width*(this.currentStep/this.stepNumber);
            this.sliderDial.x = this.processedBar.x+this.processedBar.width;
            if(null != this.balloon){
                this.balloon.x = this.processedBar.x+this.processedBar.width;
                this.balloon.text = (Math.floor(this.currentStep)).toString();
                this.balloonTail.x = this.processedBar.x+this.processedBar.width;
            }
        }
	};
	
	/**
	* This function resets progerss's width. 
	* @param {Number} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/	
    this.resetBarWidth = function(width)
	{
        if(this.isCreated && "number" == typeof width) {
            this.width = width;
            this.m_update();
        }
	};
	
	/**
	* This function resets progerss's step number. 
	* @param {Number} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/	
    this.resetStepNumber = function(stepNumber)
	{
        if(this.isCreated && "number" == typeof stepNumber && stepNumber >= 1) {
            this.stepNumber = Math.floor(stepNumber);
            if(this.currentStep > this.stepNumber){
                this.currentStep = this.stepNumber;
            }
            this.m_update();
        }
	};
    this.setProgress = function(progress)
	{
        if(this.isCreated && "number" == typeof progress) {
            this.currentStep = progress;
            if(this.currentStep < 0) {
                this.currentStep = 0;
            }
            if(this.currentStep > this.stepNumber) {
                this.currentStep = this.stepNumber;
            }
            this.m_update();
        }
	};
    this.goForward1Step = function()
	{
        if(this.isCreated) {
            this.setProgress(this.currentStep+1);
        }
        if(null != this.rightKeyCallback){
            this.rightKeyCallback(this.currentStep);
        }
	};
    this.goBackward1Step = function()
	{
        if(this.isCreated) {
            this.setProgress(this.currentStep-1);
        }
        if(null != this.leftKeyCallback){
            this.leftKeyCallback(this.currentStep);
        }
	};
    //mouse event handle    
	this.t_setMouseOverOutCallback =function(obj) {
	};
	this.t_setMouseUpDownCallback =function(obj) {
	};
	this.t_setMouseClickCallback =function(callback) {
        if(this.isCreated && null != callback
            && "function" == typeof callback) {
            this.mouseCallback = callback;
        }
	};
    
    this.t_MouseOverOut =function(isOnFlag) {
    };	
    this.t_MouseUpDown = function(isOnFlag) {
    };
    this.m_ClickHandler = function(targetWidget, eventData) {
        if(!this.readOnly && this.isFocused && !this.isDimed) {
            var progress = (eventData.coordinates.x-(this.processedBar.getAbsolutePosition()).x)/this.width*this.stepNumber;
            this.setProgress(progress);
            if(null != this.mouseCallback){
                this.mouseCallback(this.currentStep);
            }
        }
        return false;
    };
    this.m_ClickHandlerBinder = this.m_ClickHandler.bind(this);
    this.m_DownHandler = function(targetWidget, eventData) {
        if(!this.readOnly && this.isFocused && !this.isDimed) {
            this.MouseDownPosX = eventData.coordinates.x;
            this.DragStartDialPosX = this.sliderDial.x;
            this.isMouseDown = true;
        }
        return false;
    };
    this.m_DownHandlerBinder = this.m_DownHandler.bind(this);
    this.m_MoveHandler = function(targetWidget, eventData) {
        if(!this.readOnly && this.isMouseDown && this.isFocused && !this.isDimed) {
            this.sliderDial.x = this.DragStartDialPosX + (eventData.coordinates.x-this.MouseDownPosX);
            this.processedBar.width = this.sliderDial.x - this.processedBar.x;
            var progress = this.processedBar.width/this.width*this.stepNumber;
            this.setProgress(progress);
        }
        return false;
    };
    this.m_MoveHandlerBinder = this.m_MoveHandler.bind(this);
    this.m_UpHandler = function(targetWidget, eventData) {
        if(!this.readOnly && this.isFocused && !this.isDimed) {
            this.isMouseDown = false;
            var progress = (this.processedBar.width+(eventData.coordinates.x-this.MouseDownPosX))/this.width*this.stepNumber;
            this.setProgress(progress);
            if(null != this.mouseCallback){
                this.mouseCallback(this.currentStep);
            }
        }
        return false;
    };
    this.m_UpHandlerBinder = this.m_UpHandler.bind(this);
    this.t_MouseClick = function(isOnFlag) {
        if(isOnFlag){
            this.rootWidget.addEventListener("OnMouseClick", this.m_ClickHandlerBinder);
            this.sliderDial.addEventListener("OnMouseDown", this.m_DownHandlerBinder);
            this.sliderDial.addEventListener("OnMouseMove", this.m_MoveHandlerBinder);
            this.sliderDial.addEventListener("OnMouseUp", this.m_UpHandlerBinder);
        }
        else {
            this.rootWidget.removeEventListener("OnMouseClick", this.m_ClickHandlerBinder);
            this.sliderDial.removeEventListener("OnMouseDown", this.m_DownHandlerBinder);
            this.sliderDial.removeEventListener("OnMouseMove", this.m_MoveHandlerBinder);
            this.sliderDial.removeEventListener("OnMouseUp", this.m_UpHandlerBinder);
        }
    };
    
	this.setLeftKeyCallback = function(callback)
	{
        if(this.isCreated && null != callback
            && "function" == typeof callback) {
            this.leftKeyCallback = callback;
        }
	};
	this.setRightKeyCallback = function(callback)
	{
        if(this.isCreated && null != callback
            && "function" == typeof callback) {
            this.rightKeyCallback = callback;
        }
	};
}
Progress.prototype = new ControlBase();
exports = Progress;
