 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of SubPopup_Text
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

/**
 * Class SubPopup_Text.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
SubPopup_Text = function() {
    //inner data
    this.arrowUpLeft = null;
    this.arrowDownRight = null;
    this.textCenter = null;
    this.textLeft = null;
    this.textRight = null;
    this.callback = null;
    //mandatary
    this.textList = [];
    this.leftText = "";
    this.rightText = "";
    this.arrowUpLeftNormalSrc = "";
    this.arrowDownRightNormalSrc = "";
    //optional
    this.arrowUpLeftHighlightSrc = "";
    this.arrowDownRightHighlightSrc = "";
    this.hintTextWidth = scene.width*0.057292;
    this.hintTextHeight = scene.height*0.040741;
    this.centerTextWidth = scene.width*0.083333;
    this.centerTextHeight = scene.height*0.059259;
    this.arrowIconWidth = scene.width*(44/1920);
    this.arrowIconHeight = scene.height*(44/1080);
    this.leftRightMargin = scene.width*0.015625;
    this.topBottomMargin = scene.height*0.027778;
    this.iconTextGapSize = scene.width*0.010417;
    this.centerGapSize = scene.width*0.003125;
    this.currentIndex = 0;
    this.textFont = "Helvetica 30px";
    this.textColor = {r:255,g:255,b:255,a:204};
    this.textBGColor = {r:255,g:255,b:255,a:13};
    this.backgroundColor = {r:0,g:100,b:200,a:200};
    
    this.m_setProperty = function(obj) {
        //mandatary
        if (obj.hasOwnProperty("textList") && "object" == typeof obj.textList
            && 0 < obj.textList.length && "string" == typeof obj.textList[0]) {
            this.textList = obj.textList;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("leftText") 
            && "string" == typeof obj.leftText && 0 != obj.leftText.length) {
            this.leftText = obj.leftText;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("rightText") 
            && "string" == typeof obj.rightText && 0 != obj.rightText.length) {
            this.rightText = obj.rightText;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("arrowUpLeftNormalSrc") 
            && "string" == typeof obj.arrowUpLeftNormalSrc && 0 != obj.arrowUpLeftNormalSrc.length) {
            this.arrowUpLeftNormalSrc = obj.arrowUpLeftNormalSrc;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("arrowDownRightNormalSrc") 
            && "string" == typeof obj.arrowDownRightNormalSrc && 0 != obj.arrowDownRightNormalSrc.length) {
            this.arrowDownRightNormalSrc = obj.arrowDownRightNormalSrc;
        }
        else {
            return false;
        }
        //optional
        if (obj.hasOwnProperty("arrowUpLeftHighlightSrc") 
            && "string" == typeof obj.arrowUpLeftHighlightSrc && 0 != obj.arrowUpLeftHighlightSrc.length) {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftHighlightSrc;
        }
        else {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftNormalSrc;
        }
        if (obj.hasOwnProperty("arrowDownRightHighlightSrc") 
            && "string" == typeof obj.arrowDownRightHighlightSrc && 0 != obj.arrowDownRightHighlightSrc.length) {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightHighlightSrc;
        }
        else {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightNormalSrc;
        }
        if (obj.hasOwnProperty("hintTextWidth") 
            && "number" == typeof obj.hintTextWidth) {
            this.hintTextWidth = obj.hintTextWidth;
        }
        if (obj.hasOwnProperty("hintTextHeight") 
            && "number" == typeof obj.hintTextHeight) {
            this.hintTextHeight = obj.hintTextHeight;
        }
        if (obj.hasOwnProperty("centerTextWidth") 
            && "number" == typeof obj.centerTextWidth) {
            this.centerTextWidth = obj.centerTextWidth;
        }
        if (obj.hasOwnProperty("centerTextHeight") 
            && "number" == typeof obj.centerTextHeight) {
            this.centerTextHeight = obj.centerTextHeight;
        }
        if (obj.hasOwnProperty("arrowIconWidth") 
            && "number" == typeof obj.arrowIconWidth) {
            this.arrowIconWidth = obj.arrowIconWidth;
        }
        if (obj.hasOwnProperty("arrowIconHeight") 
            && "number" == typeof obj.arrowIconHeight) {
            this.arrowIconHeight = obj.arrowIconHeight;
        }
        if (obj.hasOwnProperty("leftRightMargin") 
            && "number" == typeof obj.leftRightMargin) {
            this.leftRightMargin = obj.leftRightMargin;
        }
        if (obj.hasOwnProperty("topBottomMargin") 
            && "number" == typeof obj.topBottomMargin) {
            this.topBottomMargin = obj.topBottomMargin;
        }
        if (obj.hasOwnProperty("iconTextGapSize") 
            && "number" == typeof obj.iconTextGapSize) {
            this.iconTextGapSize = obj.iconTextGapSize;
        }
        if (obj.hasOwnProperty("centerGapSize") 
            && "number" == typeof obj.centerGapSize) {
            this.centerGapSize = obj.centerGapSize;
        }
        if (obj.hasOwnProperty("currentIndex") 
            && "number" == typeof obj.currentIndex) {
            this.currentIndex = obj.currentIndex;
        }
        if (obj.hasOwnProperty("textFont") 
            && "string" == typeof obj.textFont && 0 != obj.textFont.length) {
            this.textFont = obj.textFont;
        }
        if (obj.hasOwnProperty("textColor") 
            && "object" == typeof obj.textColor) {
            this.textColor = obj.textColor;
        }
        if (obj.hasOwnProperty("textBGColor") 
            && "object" == typeof obj.textBGColor) {
            this.textBGColor = obj.textBGColor;
        }
        if (obj.hasOwnProperty("backgroundColor") 
            && "object" == typeof obj.backgroundColor) {
            this.backgroundColor = obj.backgroundColor;
        }
        
        return true;
    };
	
	/**
	* This function will create a SubPopup_Text<p>
	* This function will create a SubPopup_Text,You can use this function when you want to create a SubPopup_Text Object.
	* @param {Object} param of the new SubPopup_Text you want to create.
	* @return {Object} return the new SubPopup_Text object you want to create.
	* @example //This example create a new SubPopup_Text.
	* const script_AID = "UIElement/SubPopup_Text";
	* const SubPopup_Text = require(script_AID);
	* var text = new SubPopup_Text();
    * text.create({
        x: 200,
        y: 400,
        //width: scene.width*0.302083,//this will be recaculate!
        //height: scene.height*0.096296,//this will be recaculate!
        //mandatary
        parent: tempBG,
        textList:freqArray,
        leftText: "Up",
        rightText: "Down",
        arrowUpLeftNormalSrc: "popup/Arrow/popup_btn_arrow_left_n.png",
        arrowDownRightNormalSrc: "popup/Arrow/popup_btn_arrow_right_n.png",
        //optional
        arrowUpLeftHighlightSrc: "popup/Arrow/popup_btn_arrow_left_f.png",
        arrowDownRightHighlightSrc: "popup/Arrow/popup_btn_arrow_right_f.png",
        hintTextWidth: 100,
        hintTextHeight: 44,
        centerTextWidth: 120,
        centerTextHeight: 50,
        arrowIconWidth: 44,
        arrowIconHeight: 44,
        leftRightMargin: 20,
        topBottomMargin: 10,
        iconTextGapSize: 15,
        centerGapSize: 5,
        currentIndex: 121,
        textFont: "Helvetica 32px",
        textColor: {r:200,g:0,b:200,a:200},
        textBGColor: {r:0,g:255,b:0,a:200},
        backgroundColor: {r:0,g:128,b:255,a:255},
       });
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
        var ret = this.m_setProperty(obj);
        if(!ret){
            return null;
        }
        //reset background property.
        this.rootWidget.color = this.backgroundColor;
        this.width = (this.leftRightMargin+this.arrowIconWidth+this.iconTextGapSize+this.hintTextWidth+this.centerGapSize)*2+this.centerTextWidth;
        this.height = this.topBottomMargin*2+this.centerTextHeight;
        //create elements
        this.arrowUpLeft = new ImageWidget({
            x: this.leftRightMargin,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.arrowIconWidth,
            height: this.arrowIconHeight,
            src: this.arrowUpLeftNormalSrc,
            parent: obj.parent,
        });
        this.textLeft = new TextWidget({
            x: this.arrowUpLeft.x+this.arrowIconWidth+this.iconTextGapSize,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.hintTextWidth,
            height: this.hintTextHeight,
            text: this.leftText,
            font: this.textFont,
            textColor: this.textColor,
            color: {r:255,g:255,b:255,a:0},
            horizontalAlignment: "left",
            verticalAlignment: "center",
            parent: obj.parent,
        });
        this.textCenter = new TextWidget({
            x: this.textLeft.x+this.hintTextWidth+this.centerGapSize,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.centerTextWidth,
            height: this.centerTextHeight,
            text: this.textList[this.currentIndex],
            font: this.textFont,
            textColor: this.textColor,
            color: {r:255,g:255,b:255,a:13},
            horizontalAlignment: "center",
            verticalAlignment: "center",
            parent: obj.parent,
        });
        this.textRight = new TextWidget({
            x: this.textCenter.x+this.centerTextWidth+this.centerGapSize,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.hintTextWidth,
            height: this.hintTextHeight,
            text: this.rightText,
            font: this.textFont,
            textColor: this.textColor,
            color: {r:255,g:255,b:255,a:0},
            horizontalAlignment: "right",
            verticalAlignment: "center",
            parent: obj.parent,
        });
        this.arrowDownRight = new ImageWidget({
            x: this.textRight.x+this.hintTextWidth+this.iconTextGapSize,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.arrowIconWidth,
            height: this.arrowIconHeight,
            src: this.arrowDownRightNormalSrc,
            parent: obj.parent,
        });
        
        return this;
	};

	this.t_getFocus = function() {
	};
	this.t_loseFocus = function() {
        if(null != this.callback){
            this.callback(this.currentIndex);
        }
	};
	this.t_hide = function() {
		this.t_loseFocus();
	};		
	this.t_destroy = function() {
        if(null != this.arrowUpLeft) {
            this.arrowUpLeft.destroy();
            this.arrowUpLeft = null;
        }
        if(null != this.textLeft) {
            this.textLeft.destroy();
            this.textLeft = null;
        }
        if(null != this.textCenter) {
            this.textCenter.destroy();
            this.textCenter = null;
        }
        if(null != this.textRight) {
            this.textRight.destroy();
            this.textRight = null;
        }
        if(null != this.arrowDownRight) {
            this.arrowDownRight.destroy();
            this.arrowDownRight = null;
        }
    
       this.textList.length = 0;
       this.textList = null;
       
       delete this.arrowUpLeftMouseClickBind;
       delete this.arrowDownRightMouseClickBind;
	};

    this.arrowUpLeftMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed && this.currentIndex < this.textList.length - 1){
            this.arrowDownRight.src = this.arrowDownRightNormalSrc;
            this.arrowUpLeft.src = this.arrowUpLeftHighlightSrc;
            this.currentIndex = this.currentIndex + 1;
            this.textCenter.text = this.textList[this.currentIndex];
            if(null != this.callback){
                this.callback(this.currentIndex,this.textCenter.text);
            }
        }
        return false;
    };	
    this.arrowUpLeftMouseClickBind = this.arrowUpLeftMouseClick.bind(this);
    this.arrowDownRightMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed && this.currentIndex > 0){
            this.arrowUpLeft.src = this.arrowUpLeftNormalSrc;
            this.arrowDownRight.src = this.arrowDownRightHighlightSrc;
            this.currentIndex = this.currentIndex - 1;
            this.textCenter.text = this.textList[this.currentIndex];
            if(null != this.callback){
                this.callback(this.currentIndex,this.textCenter.text);
            }
        }
        return false;
    };	
    this.arrowDownRightMouseClickBind = this.arrowDownRightMouseClick.bind(this);   
    this.t_MouseClick = function(isOnFlag){
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag) {
                this.arrowUpLeft.addEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                this.arrowDownRight.addEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
            }
            else {
                this.arrowUpLeft.removeEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                this.arrowDownRight.removeEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
            }
        }
    };
    
	this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        if (keytype == Volt.EVENT_KEY_RELEASE || !this.isFocused) 
        {
            return ret;
        }	
        switch(keycode) 
        {
            case Volt.KEY_JOYSTICK_RIGHT:
                if(this.currentIndex > 0)
                {
                    this.arrowUpLeft.src = this.arrowUpLeftNormalSrc;
                    this.arrowDownRight.src = this.arrowDownRightHighlightSrc;
                    this.currentIndex = this.currentIndex - 1;
                    this.textCenter.text = this.textList[this.currentIndex];
                    if(null != this.callback){
                        this.callback(this.currentIndex,this.textCenter.text);
                    }
                    ret = true;
                }
                break;			
            case Volt.KEY_JOYSTICK_LEFT:	
                if(this.currentIndex < this.textList.length - 1)
                {
                    this.arrowDownRight.src = this.arrowDownRightNormalSrc;
                    this.arrowUpLeft.src = this.arrowUpLeftHighlightSrc;
                    this.currentIndex = this.currentIndex + 1;
                    this.textCenter.text = this.textList[this.currentIndex];
                    if(null != this.callback){
                        this.callback(this.currentIndex,this.textCenter.text);
                    }
                    ret = true;
                }
                break;
            default:
                break;
        } 					
        return ret;
	};
    
	this.t_setMouseClickCallback = function(callback)
	{
        if(this.isCreated && null != callback
            && "function" == typeof callback) {
            this.callback = callback;
        }
	};
}
SubPopup_Text.prototype = new ControlBase();
exports = SubPopup_Text;
