 /** 
 * @author  
 * @fileoverview Definition of NetWorkPopup
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

const commonMessagePopup  = Volt.require("modules/UIElement/MessagePopup.js");

NetWorkPopup = function(){	
	this.m_rellySettingBtnCallBack = null;
	this.m_callBackTimeOutHandler = null;
	this.m_buttonPropertyobj = null;

	this.netWorkSetButton = function(goSettingBtnAttr, cancelBtnAttr){
		//keep the really call back of setting btn
		if (goSettingBtnAttr.hasOwnProperty("callbackfunction")) {
			this.m_rellySettingBtnCallBack = goSettingBtnAttr.callbackfunction;
		}
		
		//reset call back of goSettingBtnAttr
		goSettingBtnAttr.callbackfunction = this.goNetSettingPopUpBind;
		
		//call base "setButton" function
		this.m_buttonPropertyobj = new Array();
		this.m_buttonPropertyobj.push(goSettingBtnAttr);
		this.m_buttonPropertyobj.push(cancelBtnAttr);		
		this.setButton(this.m_buttonPropertyobj);	
		
	}
	
	this.goNetSettingPopUp = function(){		
		var aulApp = new Aul();
		var ret = aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
				
		if(this.m_rellySettingBtnCallBack != null){
			this.m_callBackTimeOutHandler = Volt.setTimeout(function(sefThis){
				sefThis.m_rellySettingBtnCallBack();			
			},50,this);
		}
	}	
	this.goNetSettingPopUpBind = this.goNetSettingPopUp.bind(this);
	
	this.destroyBroker = function(){
		//destroy parent
		this.destroy();
			
		//clear time out	
		if(this.m_callBackTimeOutHandler != null){
			 Volt.clearTimeout(this.m_callBackTimeOutHandler);
			 this.m_callBackTimeOutHandler = null;
		}
	
		//clear array
		if(this.m_buttonPropertyobj != null){
			this.m_buttonPropertyobj.length =0;
			this.m_buttonPropertyobj = null;
		}
			
		//clear bind function	
		delete	this.goNetSettingPopUpBind;
	}	
}

NetWorkPopup.prototype = new commonMessagePopup();
exports = NetWorkPopup;