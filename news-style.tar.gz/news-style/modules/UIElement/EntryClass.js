var script_AID = "modules/UIElement/ControlBase.js";
ControlBase = Volt.require(script_AID);

//comomm function	
function setTimeout(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
}
	
EntryClass = function() {

	//init parameter
	this.strEncryText = "";
	this.strClearText = "";
	
	this.bgWidget = null;
	this.CursorInstance = null;
	this.entryTextWidget = null;
	this.boolFocusFlag = false;
	this.boolClearTextFlag = true;

	this.t_create = function(obj) {
	
		var entryWidgetSef = this;			
		
		//bgWidget
		if (obj.hasOwnProperty("bgUrl")) {
			this.bgWidget = new ImageWidget(obj.bgUrl);
		}
		
		if (this.bgWidget != null){
			this.bgWidget.x = 0;
			this.bgWidget.y = 0;
			this.bgWidget.height = obj.height;
			this.bgWidget.width = obj.width;
			this.bgWidget.color = {g:100};
			this.bgWidget.parent = obj.parent;
			this.bgWidget.addEventListener("onmousedown", function(targetWidget, eventData){
											entryWidgetSef.t_getFocus();
										});
		}
		
		
								
		//cursor
		cursorClass	= Volt.require("modules/CursorComponent.js");
		this.CursorInstance = new cursorClass(obj.focusImages);
		
		
		this.CursorInstance.x = 0;
		this.CursorInstance.y = 0;
		this.CursorInstance.parent = obj.parent;
		this.CursorInstance.hide();
								
		//entryTextWidget
		this.entryTextWidget = new TextWidget();
		this.entryTextWidget.x = 0;
		this.entryTextWidget.y = 0;
		this.entryTextWidget.height = obj.height;
		this.entryTextWidget.width = obj.width;
		this.entryTextWidget.parent = obj.parent;
		this.entryTextWidget.horizontalAlignment = "left";
		this.entryTextWidget.verticalAlignment  = "center";			
		this.entryTextWidget.font = "Helvetica 32px";
		this.entryTextWidget.textColor = {r:255, g:255, b:255};	
	};

	this.t_getFocus = function() {
		if(null == this.CursorInstance){
			return false;
		}			

		if(true == this.boolFocusFlag){
			return false;
		}
		
		var self = this;	
		setTimeout(function(){ 
			self.CursorInstance.move(self.bgWidget.x, self.bgWidget.y, self.bgWidget.width, self.bgWidget.height);
			print('EntryClass.js:t_getFocus');
			self.CursorInstance.show();
		}, 100);
		
		this.boolFocusFlag=true;
	};

	this.t_loseFocus = function() {
		print('EntryClass.js:t_loseFocus1');
		if(null == this.CursorInstance){
			return false;
		}
		print('EntryClass.js:t_loseFocus2');
		this.CursorInstance.hide();
		
		this.boolFocusFlag=false;
	};

	this.t_show = function() {
		this.t_getFocus();
	};

	this.t_hide = function() {
		this.t_loseFocus();
	};
	
	this.t_destroy = function() {
	};

	this.t_keyHandler = function(KeyCode, keytype){
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}	
		return false;
	}; 
	
	this.enable = function(){
		this.boolFocusFlag = true;
		this.CursorInstance.show();
	};

	this.disable = function(){
		this.boolFocusFlag = false;
		this.CursorInstance.hide();
	};

	this.showEncryptText = function(){
		if(false == this.boolFocusFlag){
			return false;
		}
		
		if( null == this.entryTextWidget){
			return false;
		}
		
		this.entryTextWidget.text = this.strEncryText;
		this.boolClearTextFlag = false;

		return true;
	};

	this.showClearText = function(){
		if(false == this.boolFocusFlag){
			return false;
		}
		if( null == this.entryTextWidget){	
			return false;
		}
		
		this.entryTextWidget.text = this.strClearText;
		this.boolClearTextFlag = true;
		
		return true;
	};		
			
	this.setPlaintext = function(){
		if(false == this.boolFocusFlag){
			return false;
		}				
			
		if( null == this.entryTextWidget){			
			return false;
		}

		this.strEncryText = "";
		this.strClearText = "";
		
		this.entryTextWidget.text = this.strClearText;

		return true;
	};

	this.getText = function(){
		return this.strClearText;
	};
    
	this.getCharacterNum = function(){
		return this.strClearText.length;
	};

	this.setEntryTextString = function(strText){				
		if(false == this.boolFocusFlag){								
			return false;
		}						
			
		var typeName = typeof strText;
		if (("string" == typeName)) {
			this.m_SetText(strText);
			return true;
		}
		return false;		
	};

	this.addNewStringAtEnd = function(strNew){
		if(false == this.boolFocusFlag){
			return false;
		}			

		if( null == this.entryTextWidget){
			//print("==========addNewStringAtEnd  return false=========!");				
			return false;
		}	
			
		var typeName = typeof strNew;
		if (("string" == typeName)) {				
					
			this.strClearText += strNew;						
			for(var index=0; index < strNew.length; index++){
				this.strEncryText += "*";
			}		
			
			if (this.boolClearTextFlag){
				this.entryTextWidget.text = this.strClearText;
			}
			else{
				this.entryTextWidget.text = this.strEncryText;
			}

			return true;
		}
		return false;		
	};

	this.m_SetText = function(strNew){
		if( null == this.entryTextWidget){
			return false;
		}
					
		this.strClearText = strNew;
		this.strEncryText = "";
		for(var index = 0;index < strNew.length; index++){
			this.strEncryText += "*";
		}				
		if (this.boolClearTextFlag){
			this.entryTextWidget.text = this.strClearText;
		}
		else{
			this.entryTextWidget.text = this.strEncryText;
		}
				
		return true;			
	};		
}

EntryClass.prototype = new ControlBase();
exports = EntryClass;
