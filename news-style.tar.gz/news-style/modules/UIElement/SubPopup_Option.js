 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of SubPopup_Option
 * @date    2014/08/06
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

/**
 * Class SubPopup_Option.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
SubPopup_Option = function() {
    this.optionValue = {
        LEFT: 0,
        RIGHT: 1,
        OPTION_MAX: 2
    };
    //inner data
    this.arrowUpLeft = null;
    this.arrowDownRight = null;
    this.textLeft = null;
    this.textRight = null;
    this.callback = null;
    //mandatary
    this.leftText = "";
    this.rightText = "";
    this.arrowUpLeftNormalSrc = "";
    this.arrowDownRightNormalSrc = "";
    //optional
    this.arrowUpLeftHighlightSrc = "";
    this.arrowDownRightHighlightSrc = "";
    this.textWidth = scene.width*0.064583;
    this.textHeight = scene.height*0.040741;
    this.arrowIconWidth = scene.width*(44/1920);
    this.arrowIconHeight = scene.height*(44/1080);
    this.leftRightMargin = scene.width*0.015625;
    this.topBottomMargin = scene.height*0.027778;
    this.iconTextGapSize = scene.width*0.010417;
    this.middleGapSize = scene.width*0.006250;
    this.currentOption = this.optionValue.LEFT;
    this.textFont = "Helvetica 30px";
    this.textColor = {r:255,g:255,b:255,a:204};
    this.textHighlightColor = {r:255,g:255,b:255,a:255};
    this.backgroundColor = {r:0,g:100,b:200,a:200};
    
    this.m_setProperty = function(obj) {
        //mandatary
        if (obj.hasOwnProperty("leftText") 
            && "string" == typeof obj.leftText && 0 != obj.leftText.length) {
            this.leftText = obj.leftText;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("rightText") 
            && "string" == typeof obj.rightText && 0 != obj.rightText.length) {
            this.rightText = obj.rightText;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("arrowUpLeftNormalSrc") 
            && "string" == typeof obj.arrowUpLeftNormalSrc && 0 != obj.arrowUpLeftNormalSrc.length) {
            this.arrowUpLeftNormalSrc = obj.arrowUpLeftNormalSrc;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("arrowDownRightNormalSrc") 
            && "string" == typeof obj.arrowDownRightNormalSrc && 0 != obj.arrowDownRightNormalSrc.length) {
            this.arrowDownRightNormalSrc = obj.arrowDownRightNormalSrc;
        }
        else {
            return false;
        }
        //optional
        if (obj.hasOwnProperty("arrowUpLeftHighlightSrc") 
            && "string" == typeof obj.arrowUpLeftHighlightSrc && 0 != obj.arrowUpLeftHighlightSrc.length) {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftHighlightSrc;
        }
        else {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftNormalSrc;
        }
        if (obj.hasOwnProperty("arrowDownRightHighlightSrc") 
            && "string" == typeof obj.arrowDownRightHighlightSrc && 0 != obj.arrowDownRightHighlightSrc.length) {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightHighlightSrc;
        }
        else {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightNormalSrc;
        }
        if (obj.hasOwnProperty("textWidth") 
            && "number" == typeof obj.textWidth) {
            this.textWidth = obj.textWidth;
        }
        if (obj.hasOwnProperty("textHeight") 
            && "number" == typeof obj.textHeight) {
            this.textHeight = obj.textHeight;
        }
        if (obj.hasOwnProperty("arrowIconWidth") 
            && "number" == typeof obj.arrowIconWidth) {
            this.arrowIconWidth = obj.arrowIconWidth;
        }
        if (obj.hasOwnProperty("arrowIconHeight") 
            && "number" == typeof obj.arrowIconHeight) {
            this.arrowIconHeight = obj.arrowIconHeight;
        }
        if (obj.hasOwnProperty("leftRightMargin") 
            && "number" == typeof obj.leftRightMargin) {
            this.leftRightMargin = obj.leftRightMargin;
        }
        if (obj.hasOwnProperty("topBottomMargin") 
            && "number" == typeof obj.topBottomMargin) {
            this.topBottomMargin = obj.topBottomMargin;
        }
        if (obj.hasOwnProperty("iconTextGapSize") 
            && "number" == typeof obj.iconTextGapSize) {
            this.iconTextGapSize = obj.iconTextGapSize;
        }
        if (obj.hasOwnProperty("middleGapSize") 
            && "number" == typeof obj.middleGapSize) {
            this.middleGapSize = obj.middleGapSize;
        }
        if (obj.hasOwnProperty("currentOption") 
            && "number" == typeof obj.currentOption) {
            this.currentOption = obj.currentOption;
        }
        if (obj.hasOwnProperty("textFont") 
            && "string" == typeof obj.textFont && 0 != obj.textFont.length) {
            this.textFont = obj.textFont;
        }
        if (obj.hasOwnProperty("textColor") 
            && "object" == typeof obj.textColor) {
            this.textColor = obj.textColor;
        }
        if (obj.hasOwnProperty("textHighlightColor") 
            && "object" == typeof obj.textHighlightColor) {
            this.textHighlightColor = obj.textHighlightColor;
        }
        if (obj.hasOwnProperty("backgroundColor") 
            && "object" == typeof obj.backgroundColor) {
            this.backgroundColor = obj.backgroundColor;
        }
        
        return true;
    };
	this.t_create = function(obj) {
        var ret = this.m_setProperty(obj);
        if(!ret){
            return null;
        }
        //reset background property.
        this.rootWidget.color = this.backgroundColor;
        this.width = (this.leftRightMargin+this.arrowIconWidth+this.iconTextGapSize+this.textWidth)*2+this.middleGapSize;
        this.height = this.topBottomMargin*2+this.textHeight;
        //create elements
        this.arrowUpLeft = new ImageWidget({
            x: this.leftRightMargin,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.arrowIconWidth,
            height: this.arrowIconHeight,
            src: this.arrowUpLeftNormalSrc,
            parent: obj.parent,
        });
        this.textLeft = new TextWidget({
            x: this.arrowUpLeft.x+this.arrowIconWidth+this.iconTextGapSize,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.textWidth,
            height: this.textHeight,
            text: this.leftText,
            font: this.textFont,
            textColor: this.textColor,
            color: {r:255,g:255,b:255,a:0},
            horizontalAlignment: "left",
            verticalAlignment: "center",
            parent: obj.parent,
        });
        this.textRight = new TextWidget({
            x: this.textLeft.x+this.textWidth+this.middleGapSize,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.textWidth,
            height: this.textHeight,
            text: this.rightText,
            font: this.textFont,
            textColor: this.textColor,
            color: {r:255,g:255,b:255,a:0},
            horizontalAlignment: "right",
            verticalAlignment: "center",
            parent: obj.parent,
        });
        this.arrowDownRight = new ImageWidget({
            x: this.textRight.x+this.textWidth+this.iconTextGapSize,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.arrowIconWidth,
            height: this.arrowIconHeight,
            src: this.arrowDownRightNormalSrc,
            parent: obj.parent,
        });
        if(this.optionValue.LEFT == this.currentOption){
            this.textLeft.textColor = this.textHighlightColor;
        }
        else{
            this.textRight.textColor = this.textHighlightColor;
        }
        
        return this;
	};

	this.t_getFocus = function() {
	};
	this.t_loseFocus = function() {
        if(null != this.callback){
            this.callback(this.currentOption);
        }
	};
	this.t_hide = function() {
		this.t_loseFocus();
	};		
	this.t_destroy = function() {
        if(null != this.arrowUpLeft) {
            this.arrowUpLeft.destroy();
            this.arrowUpLeft = null;
        }
        if(null != this.textLeft) {
            this.textLeft.destroy();
            this.textLeft = null;
        }
        if(null != this.textRight) {
            this.textRight.destroy();
            this.textRight = null;
        }
        if(null != this.arrowDownRight) {
            this.arrowDownRight.destroy();
            this.arrowDownRight = null;
        }
        
        delete this.arrowUpLeftMouseClickBind;
        delete this.arrowDownRightMouseClickBind;
	};

    this.arrowUpLeftMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed && this.optionValue.RIGHT == this.currentOption){
            this.arrowDownRight.src = this.arrowDownRightNormalSrc;
            this.arrowUpLeft.src = this.arrowUpLeftHighlightSrc;
            this.textRight.textColor = this.textColor;
            this.textLeft.textColor = this.textHighlightColor;
            this.currentOption = this.optionValue.LEFT;
            if(null != this.callback){
                this.callback(this.currentOption,this.textLeft.text);
            }
        }
        return false;
    };	
    this.arrowUpLeftMouseClickBind = this.arrowUpLeftMouseClick.bind(this);
    this.arrowDownRightMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed && this.optionValue.LEFT == this.currentOption){
            this.arrowUpLeft.src = this.arrowUpLeftNormalSrc;
            this.arrowDownRight.src = this.arrowDownRightHighlightSrc;
            this.textLeft.textColor = this.textColor;
            this.textRight.textColor = this.textHighlightColor;
            this.currentOption = this.optionValue.RIGHT;
            if(null != this.callback){
                this.callback(this.currentOption,this.textRight.text);
            }
        }
        return false;
    };	
    this.arrowDownRightMouseClickBind = this.arrowDownRightMouseClick.bind(this);   
    this.t_MouseClick = function(isOnFlag){
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag) {
                this.arrowUpLeft.addEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                this.arrowDownRight.addEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
            }
            else {
                this.arrowUpLeft.removeEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                this.arrowDownRight.removeEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
            }
        }
    };
    
	this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        if (keytype == Volt.EVENT_KEY_RELEASE || !this.isFocused) 
        {
            return ret;
        }	
        switch(keycode) 
        {
            case Volt.KEY_JOYSTICK_RIGHT:
                if(this.optionValue.LEFT == this.currentOption)
                {
                    this.arrowUpLeft.src = this.arrowUpLeftNormalSrc;
                    this.arrowDownRight.src = this.arrowDownRightHighlightSrc;
                    this.textLeft.textColor = this.textColor;
                    this.textRight.textColor = this.textHighlightColor;
                    this.currentOption = this.optionValue.RIGHT;
                    if(null != this.callback){
                        this.callback(this.currentOption,this.textRight.text);
                    }
                    ret = true;
                }
                break;			
            case Volt.KEY_JOYSTICK_LEFT:	
                if(this.optionValue.RIGHT == this.currentOption)
                {
                    this.arrowDownRight.src = this.arrowDownRightNormalSrc;
                    this.arrowUpLeft.src = this.arrowUpLeftHighlightSrc;
                    this.textRight.textColor = this.textColor;
                    this.textLeft.textColor = this.textHighlightColor;
                    this.currentOption = this.optionValue.LEFT;
                    if(null != this.callback){
                        this.callback(this.currentOption,this.textLeft.text);
                    }
                    ret = true;
                }
                break;
            default:
                break;
        } 					
        return ret;
	};
    
	this.t_setMouseClickCallback = function(callback)
	{
        if(this.isCreated && null != callback
            && "function" == typeof callback) {
            this.callback = callback;
        }
	};
}
SubPopup_Option.prototype = new ControlBase();
exports = SubPopup_Option;
