 /** 
 * @author  
 * @fileoverview Definition of InputBox
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");             

InputBox = function() {
	this.m_Status = null;
	this.stateBGSrc = [];
    this.stateTextColor = [];
	this.statePINImgSrc = [];
	this.PINImg = [];
	this.Style = InputBox.Style.TEXT;
	this.inputText = "";
	this.inputPIN = "";
	this.region = null;
	this.mouseOverCallback = null;
    this.mouseOutCallback = null;
	this.mouseClickCallback = null;
	this.inputMaxLength = 0;
	this.PINImg_width = null;
	this.PINImg_height = null;
	this.inputDoneCallback = null;
	
	/**
	* This function creates an InputBox object. 
	* @param {Object} param for this function.
	* @return void
	* @example //This example create an InputBox object.
	*var InputBoxPinSample = new InputBox();
	*InputBoxPinSample.create({
	*	x:100,
	*	y:100,
	*	width:scene.width * 0.181771,
	*	height:scene.height * 0.053704,
	*	parent:BG,
	*	bgSrc:{normal:"inputBox/input_box_n.png", focus:"inputBox/input_box_style_c_f.png"},
	*	PINImgSrc:{normal:"inputBox/obe_pin_n.png", focus:"inputBox/obe_pin_f.png"},
	*	Style:InputBox.Style.PIN,
	*	InputDoneCallback:pinDoneCallback
	*});
	* @since The version 1.0 this function is added.
	*/	
	this.t_create = function(obj) {
		this.region = obj.parent;
		if (obj.Style == InputBox.Style.PIN){
			//default pin code input box dimension
			var ImgBGWidth =  scene.width * 0.181771;
			var ImgBGHeight = scene.height * 0.053704;
			var normalImage = new Image({uri:Volt.getRemoteUrl('images/1080/uielement/inputBox/input_box_n.png')});
			var focusImage = new Image({uri:Volt.getRemoteUrl('images/1080/uielement/inputBox/input_box_style_c_f.png')});
			var ImgBGSrc = {normal:normalImage, focus:focusImage};
			this.stateBGSrc[InputBox.inputBoxStatus.STATE_NORMAL] = ImgBGSrc.normal;
			this.stateBGSrc[InputBox.inputBoxStatus.STATE_FOCUSED] = ImgBGSrc.focus;
			
			if (obj.hasOwnProperty("bgSrc") && 
			(obj.bgSrc.hasOwnProperty("normal"))){
				ImgBGSrc.normal = obj.bgSrc.normal;
				this.stateBGSrc[InputBox.inputBoxStatus.STATE_NORMAL] = obj.bgSrc.normal;
			}
			
			if (obj.hasOwnProperty("bgSrc") && 
			(obj.bgSrc.hasOwnProperty("focus"))){
				ImgBGSrc.focus = obj.bgSrc.focus;
				this.stateBGSrc[InputBox.inputBoxStatus.STATE_FOCUSED] = obj.bgSrc.focus;
			}
			
			this.ImgBG = new NinePatchWidget({
                       x: 0,
                       y: 0,
                       width: obj.width,
                       height: obj.height,
                       parent: obj.parent,
                       cornerDimensions: {x:5, y:5},
					   src:ImgBGSrc.normal
				   });
			
			if (obj.hasOwnProperty("width")){
				this.ImgBG.width = obj.width;
			}
			else{
				this.ImgBG.width = ImgBGWidth;
			}
			
			if (obj.hasOwnProperty("height")){
				this.ImgBG.height = obj.height;
			}
			else{
				this.ImgBG.height = ImgBGHeight;
			}
			
			var PINDotGap = 0;
			if (obj.hasOwnProperty("PINDotGap")) {
				PINDotGap = obj.PINDotGap;
			}
			else {
				//default pin code image gap
				PINDotGap = scene.width * 0.016666;
			} 
			
			var PINImg_x = 0;
			//var PINImg_y = 0;
			//default pin code image resource
			var normalPIN = new Image({uri:Volt.getRemoteUrl('images/1080/uielement/inputBox/obe_pin_n.png')});
			var focusPIN = new Image({uri:Volt.getRemoteUrl('images/1080/uielement/inputBox/obe_pin_f.png')});
			var PINImg_Src = {normal:normalPIN, focus:focusPIN};
			
			//default pin image dimension
			this.PINImg_width = {normal:6, focus:9};
			this.PINImg_height = {normal:6, focus:9};
			this.statePINImgSrc[InputBox.inputBoxStatus.STATE_NORMAL] = PINImg_Src.normal;
			this.statePINImgSrc[InputBox.inputBoxStatus.STATE_FOCUSED] = PINImg_Src.focus;
			
			
			if ((obj.hasOwnProperty("PINImgWidth")) &&
			(obj.PINImgWidth.hasOwnProperty("normal"))){
				this.PINImg_width.normal = obj.PINImgWidth.normal;
			}

			if ((obj.hasOwnProperty("PINImgWidth"))&&
			   (obj.PINImgWidth.hasOwnProperty("focus"))){
				this.PINImg_width.focus = obj.PINImgWidth.focus;
			}
			
			if ((obj.hasOwnProperty("PINImgHeight"))&&
			  (obj.PINImgHeight.hasOwnProperty("normal"))){
				this.PINImg_height.normal = obj.PINImgHeight.normal;
			}

			if ((obj.hasOwnProperty("PINImgHeight"))&&
			(obj.PINImgHeight.hasOwnProperty("focus"))){
				this.PINImg_height.focus = obj.PINImgHeight.focus;
			}
			
			if ((obj.hasOwnProperty("PINImgSrc"))&&
			(obj.PINImgSrc.hasOwnProperty("normal"))){
				PINImg_Src.normal = obj.PINImgSrc.normal;
				this.statePINImgSrc[InputBox.inputBoxStatus.STATE_NORMAL] = obj.PINImgSrc.normal;
			}

			if ((obj.hasOwnProperty("PINImgSrc"))&&
			(obj.PINImgSrc.hasOwnProperty("focus"))){
				PINImg_Src.focus = obj.PINImgSrc.focus;
				this.statePINImgSrc[InputBox.inputBoxStatus.STATE_FOCUSED] = obj.PINImgSrc.focus;
			}	

			if (obj.hasOwnProperty("inputMaxLength")){
				this.inputMaxLength = obj.inputMaxLength;
			}
			else{
				//default enter pin code number
				this.inputMaxLength = 4;
			}
			
			if (obj.hasOwnProperty("inputDoneCallback") && 
				(typeof obj.inputDoneCallback == "function")){
					this.inputDoneCallback = obj.inputDoneCallback;
			}			
					
			for (var i=0; i<this.inputMaxLength; i++){
				if (obj.hasOwnProperty("PINImgX")){
					PINImg_x = obj.PINImgX + (9+PINDotGap)*i;			
				}
				else{
					PINImg_x = (this.ImgBG.width -36-PINDotGap *3)/2 + (9+PINDotGap)*i;
				}
				
				this.PINImg[i] = new ImageWidget({
					x : PINImg_x,
					y : 0,
					width : this.PINImg_width.normal,
					height : this.PINImg_height.normal,
					parent : obj.parent,
					src : PINImg_Src.normal,			
				});
				
				this.PINImg[i].anchor.y = 0.5;
			    this.PINImg[i].origin.y = 0.5;
				this.PINImg[i].hide();
			}
			
			//set input box style
			this.Style = obj.Style;			
		}
		else{
		    var textX = 0;
			var textY = 0;
			
			if (obj.hasOwnProperty("textX")){
				textX = obj.textX;			
			}
			else{
				//default text x coordinate
				textX = scene.width*0.008333;
			}
			
			if (obj.hasOwnProperty("textY")){
				textY = obj.textY;			
			}
			
			//default alignment
			var textVerticalAlignment = "center";
			var textHorizontalAlignment = "center";
			
			if (obj.hasOwnProperty("horizontalAlignment")){
				textHorizontalAlignment = obj.horizontalAlignment;			
			}
			
			if (obj.hasOwnProperty("verticalAlignment")){
				textVerticalAlignment = obj.verticalAlignment;			
			}
			
			//default text width
			var textWidth = obj.width - textX*2;
			
			if (obj.hasOwnProperty("textWidth")){
				textWidth = obj.textWidth;			
			}
			
			var normalImage = new Image({uri:Volt.getRemoteUrl('images/1080/uielement/inputBox/input_box_n.png')});
			var focusImage = new Image({uri:Volt.getRemoteUrl('images/1080/uielement/inputBox/input_box_style_c_f.png')});
			var ImgBGSrc = {normal:normalImage, focus:focusImage};
			this.stateBGSrc[InputBox.inputBoxStatus.STATE_NORMAL] = ImgBGSrc.normal;
			this.stateBGSrc[InputBox.inputBoxStatus.STATE_FOCUSED] = ImgBGSrc.focus;
			
			if (obj.hasOwnProperty("bgSrc") && 
			(obj.bgSrc.hasOwnProperty("normal"))){
				ImgBGSrc.normal = obj.bgSrc.normal;
				this.stateBGSrc[InputBox.inputBoxStatus.STATE_NORMAL] = obj.bgSrc.normal;
			}
			
			if (obj.hasOwnProperty("bgSrc") && 
			(obj.bgSrc.hasOwnProperty("focus"))){
				ImgBGSrc.focus = obj.bgSrc.focus;
				this.stateBGSrc[InputBox.inputBoxStatus.STATE_FOCUSED] = obj.bgSrc.focus;
			}
			
			this.ImgBG = new NinePatchWidget({
                       x: 0,
                       y: 0,
                       width: obj.width,
                       height: obj.height,
                       parent: obj.parent,
                       cornerDimensions: {x:5, y:5},
					   src:ImgBGSrc.normal
			});
			
			this.clearTextWidget = new TextWidget({
				x : textX,
				y : textY,
				width : textWidth,
				height :obj.height,
				parent : obj.parent,
				//text : obj.text,
				verticalAlignment : textVerticalAlignment,
				horizontalAlignment : textHorizontalAlignment,
				ellipsize : true,
			});
			
			// set text font
			if (obj.hasOwnProperty("font")){
				this.clearTextWidget.font = obj.font;			
			}
			else{
				this.clearTextWidget.font = "Samsung SVD_Light 30px";
			}
			
			if (obj.hasOwnProperty("text")){
				this.inputText	= obj.text;
				this.clearTextWidget.text = obj.text;
			}
			//text color default value			
			this.stateTextColor[InputBox.inputBoxStatus.STATE_NORMAL] = {r:40, g:40, b:40, a:204};
			this.stateTextColor[InputBox.inputBoxStatus.STATE_FOCUSED] = {r:22, g:138, b:255, a:255};
			this.stateTextColor[InputBox.inputBoxStatus.STATE_SELECTED] = {r:40, g:40, b:40, a:204};
			this.stateTextColor[InputBox.inputBoxStatus.STATE_DIM] = {r:40, g:40, b:40, a:25.5};
			this.stateTextColor[InputBox.inputBoxStatus.STATE_DEFAULT] = {r:40, g:40, b:40, a:153};
			
			if ((obj.hasOwnProperty("textColor"))&&
			(obj.textColor.hasOwnProperty("normal"))){
				this.stateTextColor[InputBox.inputBoxStatus.STATE_NORMAL] = obj.textColor.normal;
			}
			
			if ((obj.hasOwnProperty("textColor"))&&
			(obj.textColor.hasOwnProperty("focus"))){
				this.stateTextColor[InputBox.inputBoxStatus.STATE_FOCUS] = obj.textColor.focus;
			}
			
			if ((obj.hasOwnProperty("textColor"))&&
			(obj.textColor.hasOwnProperty("selected"))){
				this.stateTextColor[InputBox.inputBoxStatus.STATE_SELECTED] = obj.textColor.selected;
			}
			
			if ((obj.hasOwnProperty("textColor"))&&
			(obj.textColor.hasOwnProperty("dim"))){
				this.stateTextColor[InputBox.inputBoxStatus.DIM] = obj.textColor.dim;
			}
			
			if ((obj.hasOwnProperty("textColor"))&&
			(obj.textColor.hasOwnProperty("defaultValue"))){
				this.stateTextColor[InputBox.inputBoxStatus.STATE_DEFAULT] = obj.textColor.defaultValue;
			}
			
			this.clearTextWidget.textColor = this.stateTextColor[InputBox.inputBoxStatus.STATE_NORMAL];
			
			if (obj.hasOwnProperty("inputMaxLength")){
				this.inputMaxLength = obj.inputMaxLength;
			}
			else{
				//default enter pin code number
				this.inputMaxLength = 4;
			}
			
			if (obj.hasOwnProperty("inputDoneCallback") && 
				(typeof obj.inputDoneCallback == "function")){
					this.inputDoneCallback = obj.inputDoneCallback;
			}	
		}		
	};
	
	 this.t_getFocus = function() {
        this.m_Status = InputBox.inputBoxStatus.STATE_FOCUSED;		
		this.updateState();    
    };

    this.t_loseFocus = function() {
        this.m_Status = InputBox.inputBoxStatus.STATE_NORMAL;        
		this.updateState();		
    };

    this.t_destroy = function() {
		if (this.Style == InputBox.Style.PIN){
			for (var i=0; i<this.inputMaxLength; i++){
				this.PINImg[i].destroy();			
			}
			
			if (this.ImgBG != null){
				this.ImgBG.destroy();
				this.ImgBG = null;
			}
		}
		else {
			if (this.clearTextWidget != null){
				this.clearTextWidget.destroy();
				this.clearTextWidget = null;
			}
			
			if (this.ImgBG != null){
				this.ImgBG.destroy();
				this.ImgBG = null;
			}
		}
		
		this.stateBGSrc.splice(0, this.stateBGSrc.length);
		this.stateBGSrc = null;
		this.stateTextColor.splice(0, this.stateTextColor.length);
		this.stateTextColor = null;
		this.statePINImgSrc.splice(0, this.statePINImgSrc.length);
		this.statePINImgSrc = null;
		this.PINImg.splice(0, this.PINImg.length);
		this.PINImg = null;
		
		delete this.inputBoxMouseClickBind;
		delete this.inputBoxMouseOverBind;
		delete this.inputBoxMouseOutBind;
	};
    
    this.t_show = function() {
    };

    this.t_hide = function() {        
    };
	
	this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        var tmp = this;
        	     
	   if ((this.inputPIN.length >= this.inputMaxLength) || 
			 (this.inputText.length >= this.inputMaxLength)){
			return ret;		
		}
		
		if(InputBox.inputBoxStatus.STATE_FOCUSED == this.m_Status){
            switch(keycode) {
				case Volt.KEY_0:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "0";
					}
					else{
						this.inputText += "0";
					}
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){							
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_1:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "1";
					}
					else{
						this.inputText += "1";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
				
				case Volt.KEY_2:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "2";
					}
					else{
						this.inputText += "2";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_3:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "3";
					}
					else{
						this.inputText += "3";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_4:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "4";
					}
					else{
						this.inputText += "4";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_5:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "5";
					}
					else{
						this.inputText += "5";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_6:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "6";
					}
					else{
						this.inputText += "6";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_7:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "7";
					}
					else{
						this.inputText += "7";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_8:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "8";
					}
					else{
						this.inputText += "8";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
					
				case Volt.KEY_9:
					if (this.Style == InputBox.Style.PIN){
						this.inputPIN += "9";
					}
					else{
						this.inputText += "9";
					}		
					this.m_addNumberAtEnd();
					
					if ((this.inputPIN.length == this.inputMaxLength) || 
					(this.inputText.length == this.inputMaxLength)){
						//do callback
						if (this.inputDoneCallback != null){
							this.inputDoneCallback(this);
						}
					}
					ret = true;
					break;
						
				default:
					// to do
					break;
			} 		
        }
		       
        return ret;
    };
	
	/**
	* This function clears input text or pin. 
	* @param void
	* @return void
	* @example //This example clears input text or pin.
	*InputBoxPinSample.clearOutInputBox();
	* @since The version 1.0 this function is added.
	*/	
	this.clearOutInputBox = function(){
		if ((this.isCreated == true) && (this.Style == InputBox.Style.PIN)){		
			for(var i=0; i<this.inputPIN.length; i++){
				this.PINImg[i].hide();
				this.inputPIN = "";
			}
		}
		else{
			this.inputText = "";
			this.clearTextWidget.text = this.inputText;
		}
	};
    
	this.m_addNumberAtEnd = function(){
		if (this.isCreated == true){			
		    if (this.Style == InputBox.Style.PIN){		
				this.PINImg[this.inputPIN.length -1].show();
			}
			else{			
				this.clearTextWidget.text = this.inputText;
			}		
		}
	};
	
	/**
	* This function adds text string at the end of input text. 
	* @param {String} param for this function.
	* @return void
	* @example //This example adds text string at the end of input text.
	*InputBoxPinSample.addNewStringAtEnd("abcd");
	* @since The version 1.0 this function is added.
	*/
	this.addNewStringAtEnd = function(strNew){
		if (this.isCreated == true){
		    if (this.Style == InputBox.Style.TEXT){		
				if (("string" == typeof strNew) && (this.inputText.length < this.inputMaxLength)) {				
					if (this.inputText.length + strNew.length <= this.inputMaxLength){
						this.inputText += strNew;
						this.clearTextWidget.text = this.inputText;
					}
					else{
						var truncatedLen = this.inputMaxLength - this.inputText.length;
						this.inputText += strNew.substr(0,truncatedLen);
						this.clearTextWidget.text = this.inputText;
					}
				}
			}	
		}
	};
		
	/**
	* This function gets the input text or pin of input box. 
	* @param Void
	* @return {String}
	* @example //This example gets the input text or pin of input box.
	* tempString = InputBoxPinSample.getInputString();
	* @since The version 1.0 this function is added.
	*/
	this.getInputString = function(){
		if (this.isCreated == true){
		    if (this.Style == InputBox.Style.PIN){		
				return 	this.inputPIN;
			}
			else {
				return this.inputText;
			}
		}
		
		return null;		
	};
	
	this.t_setMouseOverOutCallback = function(obj){
	
		if (obj.hasOwnProperty("overCallback") && typeof obj.overCallback == "function"){
			this.mouseOverCallback = obj.overCallback;
		}
		
		if (obj.hasOwnProperty("outCallback") && typeof obj.overCallback == "function"){
			this.mouseOutCallback = obj.outCallback
		}
	};
	
	this.t_setMouseClickCallback = function(callback){
		if (typeof callback == "function"){
			this.mouseClickCallback = callback;
		}
	};
 
    this.inputBoxMouseOver = function(targetWidget, eventData) {
        if(InputBox.inputBoxStatus.STATE_DIM == this.m_Status){
            return false;
        }
       
        if(null != this.mouseOverCallback){
            this.mouseOverCallback(this);
        }
		
		return false;
    };
    this.inputBoxMouseOverBind = this.inputBoxMouseOver.bind(this);
	
    this.inputBoxMouseOut = function(targetWidget, eventData) {
        if(InputBox.inputBoxStatus.STATE_DIM == this.m_Status){
            return false;
        }
        
        if(null != this.mouseOutCallback){
            this.mouseOutCallback(this);
        }
		return false;
    };
    this.inputBoxMouseOutBind = this.inputBoxMouseOut.bind(this);
	
	this.inputBoxMouseClick = function(targetWidget, eventData){
		if(InputBox.inputBoxStatus.STATE_DIM == this.m_Status){
            return false;
        }
        
        if(null != this.mouseClickCallback){
            this.mouseClickCallback(this);
        }
		return false;
	};
	this.inputBoxMouseClickBind = this.inputBoxMouseClick.bind(this);
	
	this.t_MouseOverOut = function(isOnFlag) {
		if (isOnFlag){
			this.region.addEventListener('OnMouseOver', this.inputBoxMouseOverBind);
			this.region.addEventListener('OnMouseOut', this.inputBoxMouseOutBind);
		}
		else{
			this.region.removeEventListener('OnMouseOver', this.inputBoxMouseOverBind);
			this.region.removeEventListener('OnMouseOut', this.inputBoxMouseOutBind)
		}
	};
	
	this.t_MouseClick = function(isOnFlag) {
		if (isOnFlag){
			this.region.addEventListener('OnMouseClick', this.inputBoxMouseClickBind);
		}
		else{
			this.region.removeEventListener('OnMouseClick', this.inputBoxMouseClickBind);
		}
	};
	
	this.setInputBoxStatus = function(status){
		this.m_Status = status;
		this.update();	
	};
	
	this.setTextStatusColor = function(status, color) {
		if ((this.isCreated == true)
            && (typeof status == "number") && (0 <= status) && (InputBox.inputBoxStatus.STATE_MAX > status)
			&& (typeof color == "object")) {			
			this.stateTextColor[status] = color;
            return true;
        }	
        return false;
	};
	
	this.setTextAttr = function(obj){
		if ((this.isCreated == true) && (this.Style == InputBox.Style.TEXT)){
			
			if (obj.hasOwnProperty("text")){
				this.clearTextWidget.text = obj.text;	
				this.inputText = obj.text;			
			}
			
			if (obj.hasOwnProperty("horizontalAlignment")){
				this.clearTextWidget.horizontalAlignment = obj.horizontalAlignment;
			}
			return true;
		}
		return false;
	};
	
	this.updateState =  function(){		
		if (this.isCreated == true && (0 <= this.m_Status) && (InputBox.inputBoxStatus.STATE_MAX > this.m_Status)) {		
			if (null != this.stateBGSrc[this.m_Status]) {
					//this.ImgBG.src = this.stateBGSrc[InputBox.inputBoxStatus.STATE_NORMAL];
					Volt.setTimeout(function(firstParam){
						firstParam.ImgBG.src = firstParam.stateBGSrc[firstParam.m_Status];
					}, 100, this);
					
			} else {
				if (null != this.stateBGSrc[InputBox.inputBoxStatus.STATE_NORMAL]) {
					//this.ImgBG.src = "";
					Volt.setTimeout(function(firstParam){
						firstParam.ImgBG.src = firstParam.stateBGSrc[firstParam.m_Status];
					}, 100, this);
					this.ImgBG.src = this.stateBGSrc[InputBox.inputBoxStatus.STATE_NORMAL];
				}
			}  
			
			if(this.Style == InputBox.Style.TEXT){
				if (null != this.stateTextColor[this.m_Status]) {
					this.clearTextWidget.textColor = this.stateTextColor[this.m_Status];
				} else {
					if (null != this.stateTextColor[InputBox.inputBoxStatus.STATE_NORMAL]) {
						this.clearTextWidget.textColor = this.stateTextColor[InputBox.inputBoxStatus.STATE_NORMAL];
					}
				}			
			}
			else{
				if (null != this.statePINImgSrc[this.m_Status]) {
					for (var i=0; i<this.inputMaxLength; i++){
	
						Volt.setTimeout(function(firstParam, index){
							firstParam.PINImg[index].src = firstParam.statePINImgSrc[firstParam.m_Status];
						}, 100, this, i);
						
						if (this.m_Status == InputBox.inputBoxStatus.STATE_FOCUS){
							this.PINImg[i].width = this.PINImg_width.focus;
							this.PINImg[i].height = this.PINImg_height.focus;
						}
						else{
							this.PINImg[i].width = this.PINImg_width.normal;
							this.PINImg[i].height = this.PINImg_height.normal;
						}
					}
				} else {
					if (null != this.statePINImgSrc[InputBox.inputBoxStatus.STATE_NORMAL]) {
						for (var i=0; i<this.inputMaxLength; i++){
							Volt.setTimeout(function(firstParam){
								firstParam.PINImg[i].src = firstParam.statePINImgSrc[InputBox.inputBoxStatus.STATE_NORMAL];
							}, 100, this);
							
							this.PINImg[i].width = this.PINImg_width.normal;
							this.PINImg[i].height = this.PINImg_height.normal;
						}
					}
				}	
			}	 
		}	
	};
	
	/**
	* This function sets input text or pin input finish callback. 
	* @param {Function} param for this function
	* @return Void
	* @example //This example sets input text or pin input finish callback.
	*textDoneCallback = function(object){
	*var tempwidget = new Widget({
	*		x:700,
	*		y:100,
	*		width:100,
	*		height:100,
	*		parent:scene,
	*		color:{r:255, g:255, b:255}
	*});
	*}
	* InputBoxPinSample.setInputDoneCallback(textDoneCallback);
	* @since The version 1.0 this function is added.
	*/
	this.setInputDoneCallback = function(callback){
		if (typeof callback == "function"){
			this.inputDoneCallback = callback;
		}
	};
}

InputBox.inputBoxStatus = {
	STATE_NORMAL:0,
	STATE_FOCUSED:1,
	STATE_SELECTED:2,
	STATE_DIM:3,
	STATE_DEFAULT:4,
	STATE_MAX:5 //DO NOT define enum after this!
};
InputBox.Style = {
	TEXT:0,
	PIN:1	
};

InputBox.prototype = new ControlBase();
exports = InputBox;
