 /** 
 * @author  
 * @fileoverview Definition of ExpandableItemRenderBase
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

ExpandableItemRenderBase = function() {
	this.onExpand = function() {
		this.t_onExpand();
	};
	
	this.onContract = function() {
		this.t_onContract();
	};
}

ExpandableItemRenderBase.prototype = new ControlBase();

exports = ExpandableItemRenderBase;