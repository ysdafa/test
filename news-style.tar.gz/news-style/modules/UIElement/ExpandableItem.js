 /** 
 * @author  
 * @fileoverview Definition of ExpandableItem
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

ExpandableItem = function() {
	this.m_Title = null;
	this.m_SubItemArray = null;
	this.m_SubItemDataArray = null;
	this.m_SubBG = null;
	this.m_TitleBG = null;
	this.m_SubItemWidth = 0;
	this.m_SubItemHeight = 0;
	this.m_IsExpanded = false;
	this.m_FocusIndex = -1;
	this.m_ItemsLoadCB = null;
	this.m_SubItemNumber = 0;
	this.m_Index = 0;
	
	this.__defineGetter__("heightDiffer", function() {return this.m_SubBG.height;});
	this.__defineGetter__("isExpanded", function() {return this.m_IsExpanded;});
	
	this.setItemsLoadCB = function(callback) {
		this.m_ItemsLoadCB = callback;
	};
	
	this.m_ItemsLoadCBCall = function() {
		if (this.m_ItemsLoadCB) {;
			this.m_ItemsLoadCB(this.m_Index);
		}
	};
	
	this.update = function() {
		
	};
	
	this.isFocusHead = function() {
		return this.m_FocusIndex == -1;
	};
	
	this.isFocusTail = function() {
		return this.m_FocusIndex == this.m_SubItemNumber-1;
	};
	
	/*
		obj should contain:
		width
		height
		subItemWidth
		subItemHeight
	*/
	this.t_create = function(obj) {
		this.m_Title = null;
		this.m_FocusIndex = -1;
		this.cropOverflow = true;
		this.m_IsExpanded = false;
		this.m_SubItemArray  = new Array();
		this.m_SubItemWidth = obj.subItemWidth;
		this.m_SubItemHeight = obj.subItemHeight;
		this.m_ItemLoadCB = null;
		
		this.m_SubBG = new Widget({
			color: {r: 0, g: 0, b: 0, a: 0},
			width: obj.subItemWidth,
			x: this.width - obj.subItemWidth,
			parent: obj.parent,
		});
		
		this.m_TitleBG = new Widget({
			color: {r: 0, g: 0, b: 0, a: 0},
			parent: obj.parent,
			height: this.height,
			width: this.width,
		});
		this.hide();
	};
	
	this.titleUpdate = function(data) {
		if (!data) {
			return;
		}
		this.m_Title = new data.type;
		this.m_Index = data.itemIndex;
		this.m_FocusIndex = -1;
		this.m_SubItemNumber = data.subItemNumber?data.subItemNumber:0;
		data.data.width = this.width;
		data.data.height = this.height;
		data.data.parent = this.m_TitleBG;
		this.m_Title.create(data.data);
		this.m_SubBG.height = data.subItemNumber*this.m_SubItemHeight;
		this.m_SubBG.y = this.m_TitleBG.height - this.m_SubBG.height;
	};
	
	this.listUpdate = function(data) {
		if (!data) {
			return;
		}
		var offset = 0;
		this.m_FocusIndex = -1;
		for (var i=0; i<this.m_SubItemNumber; i++) {
			var subItem = new data[i].type();
			data[i].data.width = this.m_SubItemWidth;
			data[i].data.height = this.m_SubItemHeight;
			data[i].data.y = offset;
			data[i].data.parent = this.m_SubBG;
			subItem.create(data[i].data);
			this.m_SubItemArray.push(subItem);
			offset += this.m_SubItemHeight;
		}
	};
	
	this.listDestroy = function() {
		for (var i=0; i<this.m_SubItemNumber; i++) {
			if (this.m_SubItemArray[i]) {
				this.m_SubItemArray[i].destroy();
			}
		}
		this.m_SubItemArray.length = 0;
		this.m_SubItemArray = [];
	};
	
	this.m_expand = function() {
		this.m_SubBG.show();
		this.m_ItemsLoadCBCall();
		this.height = this.m_SubBG.height + this.m_TitleBG.height;
		this.m_IsExpanded = true;
		this.m_SubBG.animate("y", this.m_TitleBG.height, 200);
		this.m_Title.onExpand();
	};
	
	this.m_contract = function() {
		var _self = this;
		this.m_IsExpanded = false;
		this.m_SubBG.animate("y", this.m_TitleBG.height - this.m_SubBG.height, 200, function() {
			_self.height = _self.m_TitleBG.height;
			_self.listDestroy();
			_self.m_SubBG.hide();
		});
		this.m_Title.onContract();
		this.m_FocusIndex = -1;
	};
	
	this.t_getFocus = function() {
		this.m_FocusIndex = -1;
		this.m_Title.getFocus();
	};
	
	this.t_loseFocus = function() {
		if (!this.m_IsExpanded) {
			this.m_Title.loseFocus();
		} else {
			if (this.m_FocusIndex != -1) {
				this.m_SubItemArray[this.m_FocusIndex].loseFocus();
			} else {
				this.m_Title.loseFocus();
			}
			this.m_contract();
		}
		this.m_FocusIndex = -1;
	};
		
	this.t_destroy = function() {
		this.m_SubItemArray.length = 0;
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		if (keytype == Volt.EVENT_KEY_RELEASE) 
		{
			return false;
		}	
	
		if (this.m_SubItemNumber <= 0 && (keycode == Volt.KEY_JOYSTICK_UP || keycode == Volt.KEY_JOYSTICK_DOWN)) {
			return false;
		}
		if (!this.m_IsExpanded) {
			if (keycode == Volt.KEY_JOYSTICK_UP || keycode == Volt.KEY_JOYSTICK_DOWN) {
				//this.loseFocus();
				return false;
			} else if (keycode == Volt.KEY_JOYSTICK_OK) {
				this.m_expand();
				return false;
			}
		} else {
			if (keycode == Volt.KEY_RETURN) {
				if (this.m_FocusIndex != -1) {
					this.m_Title.getFocus();
					this.m_SubItemArray[this.m_FocusIndex].loseFocus();
				}
				this.m_contract();
				return false;
			} else if (keycode == Volt.KEY_JOYSTICK_UP) {
				if (this.m_FocusIndex == -1) {
					//this.loseFocus();
					return false;
				} else if (this.m_FocusIndex == 0){
					this.m_SubItemArray[0].loseFocus();
					this.m_Title.getFocus();
				} else {
					this.m_SubItemArray[this.m_FocusIndex].loseFocus();
					this.m_SubItemArray[this.m_FocusIndex-1].getFocus();
				}
				this.m_FocusIndex--;
				return true;
			} else if (keycode == Volt.KEY_JOYSTICK_DOWN){
				if (this.m_FocusIndex == this.m_SubItemArray.length-1) {
					//this.loseFocus();
					return false;
				} else if (this.m_FocusIndex == -1) {
					this.m_Title.loseFocus();
					this.m_SubItemArray[this.m_FocusIndex+1].getFocus();
				} else {
					this.m_SubItemArray[this.m_FocusIndex].loseFocus();
					this.m_SubItemArray[this.m_FocusIndex+1].getFocus();
				}
				this.m_FocusIndex++;
				return true;
			} else {
				if (this.m_FocusIndex == -1) {
					return this.m_Title.keyHandler(keycode, keytype);
				} else {
					return this.m_SubItemArray[this.m_FocusIndex].keyHandler(keycode, keytype);
				}
			}
		}
	};
}
ExpandableItem.prototype = new ControlBase();
exports = ExpandableItem;