 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of SpinnerList
 * @date    2014/08/06
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");  
/**
 * Class SpinnerList.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
SpinnerList = function() {
    //inner data
    this.arrowUpLeftList = [];
    this.arrowDownRightList = [];
    this.textWidgetList = [];
    this.splitIconList = [];
    this.contentChangeCallback = null;
    this.unfocusCallback = null;
    this.itemNum = 1;
    //mandatary
    this.stringArrayList = [];
    this.arrowUpLeftNormalSrc = "";
    this.arrowDownRightNormalSrc = "";
    //optional
    this.arrowUpLeftHighlightSrc = "";
    this.arrowDownRightHighlightSrc = "";
    this.textWidth = scene.width*0.055208;
    this.textHeight = scene.height*0.048148;
    this.arrowIconWidth = scene.width*(44/1920);
    this.arrowIconHeight = scene.height*(40/1080);
    this.leftRightMargin = scene.width*0.015625;
    this.topBottomMargin = scene.height*0.010185;
    this.splitIconSrc = "";
    this.itemGapSize = scene.width*0.008333;
    this.contentIndexList = [];//which value each spinner displays.
    this.currentItemIndex = 0;//which spinner is currently focused.
    this.textFont = "Helvetica 24px";
    this.textBorder = {width:3, color:{r:0,g:128,b:255,a:255}};
    this.textColor = {r:0,g:0,b:0,a:255};
    this.textHighlightColor = {r:0,g:128,b:255,a:255};
    this.textBGColor = {r:255,g:255,b:255,a:255};
    this.backgroundColor = {r:0,g:128,b:255,a:100};
    this.horizontalAlignment = "center";
    
    this.m_setProperty = function(obj) {
        //mandatary
        if (obj.hasOwnProperty("stringArrayList")
            && "object" == typeof obj.stringArrayList && 0 < obj.stringArrayList.length) {
            for(var i=0;i<obj.stringArrayList.length;i++){
                if("object" != typeof obj.stringArrayList[i] 
                    || obj.stringArrayList[i].length == 0
                    || "string" != typeof obj.stringArrayList[i][0])
                    return false;
            }
            this.stringArrayList = obj.stringArrayList;
            this.itemNum = this.stringArrayList.length;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("arrowUpLeftNormalSrc") 
            && "string" == typeof obj.arrowUpLeftNormalSrc && 0 != obj.arrowUpLeftNormalSrc.length) {
            this.arrowUpLeftNormalSrc = obj.arrowUpLeftNormalSrc;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("arrowDownRightNormalSrc") 
            && "string" == typeof obj.arrowDownRightNormalSrc && 0 != obj.arrowDownRightNormalSrc.length) {
            this.arrowDownRightNormalSrc = obj.arrowDownRightNormalSrc;
        }
        else {
            return false;
        }
        //optional
        if (obj.hasOwnProperty("arrowUpLeftHighlightSrc") 
            && "string" == typeof obj.arrowUpLeftHighlightSrc && 0 != obj.arrowUpLeftHighlightSrc.length) {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftHighlightSrc;
        }
        else {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftNormalSrc;
        }
        if (obj.hasOwnProperty("arrowDownRightHighlightSrc") 
            && "string" == typeof obj.arrowDownRightHighlightSrc && 0 != obj.arrowDownRightHighlightSrc.length) {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightHighlightSrc;
        }
        else {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightNormalSrc;
        }
        if (obj.hasOwnProperty("textWidth") 
            && "number" == typeof obj.textWidth) {
            this.textWidth = obj.textWidth;
        }
        if (obj.hasOwnProperty("textHeight") 
            && "number" == typeof obj.textHeight) {
            this.textHeight = obj.textHeight;
        }
        if (obj.hasOwnProperty("arrowIconWidth") 
            && "number" == typeof obj.arrowIconWidth) {
            this.arrowIconWidth = obj.arrowIconWidth;
        }
        if (obj.hasOwnProperty("arrowIconHeight") 
            && "number" == typeof obj.arrowIconHeight) {
            this.arrowIconHeight = obj.arrowIconHeight;
        }
        if (obj.hasOwnProperty("leftRightMargin") 
            && "number" == typeof obj.leftRightMargin) {
            this.leftRightMargin = obj.leftRightMargin;
        }
        if (obj.hasOwnProperty("topBottomMargin") 
            && "number" == typeof obj.topBottomMargin) {
            this.topBottomMargin = obj.topBottomMargin;
        }
        if (obj.hasOwnProperty("splitIconSrc") 
            && "string" == typeof obj.splitIconSrc && 0 != obj.splitIconSrc.length) {
            this.splitIconSrc = obj.splitIconSrc;
        }
        if (obj.hasOwnProperty("itemGapSize") 
            && "number" == typeof obj.itemGapSize) {
            this.itemGapSize = obj.itemGapSize;
        }
        if (obj.hasOwnProperty("contentIndexList")
            && "object" == typeof obj.contentIndexList && this.stringArrayList.length == obj.contentIndexList.length 
            && "number" == typeof obj.contentIndexList[0]) {
            for(var i=0;i<this.stringArrayList.length;i++){
                if(obj.contentIndexList[i]<0 || obj.contentIndexList[i]>=obj.stringArrayList[i].length)
                    return false;
            }
            this.contentIndexList = obj.contentIndexList;
        }
        else{
            for(var i=0;i<this.stringArrayList.length;i++){
                this.contentIndexList[i] = 0;
            }
        }
        if (obj.hasOwnProperty("currentItemIndex") 
            && "number" == typeof obj.currentItemIndex 
            && obj.currentItemIndex < this.stringArrayList.length
            && obj.currentItemIndex > 0) {
            this.currentItemIndex = obj.currentItemIndex;
        }
        if (obj.hasOwnProperty("textFont") 
            && "string" == typeof obj.textFont && 0 != obj.textFont.length) {
            this.textFont = obj.textFont;
        }
        if (obj.hasOwnProperty("textBorder") 
            && "object" == typeof obj.textBorder) {
            this.textBorder = obj.textBorder;
        }
        if (obj.hasOwnProperty("textColor") 
            && "object" == typeof obj.textColor) {
            this.textColor = obj.textColor;
        }
        if (obj.hasOwnProperty("textHighlightColor") 
            && "object" == typeof obj.textHighlightColor) {
            this.textHighlightColor = obj.textHighlightColor;
        }
        if (obj.hasOwnProperty("textBGColor") 
            && "object" == typeof obj.textBGColor) {
            this.textBGColor = obj.textBGColor;
        }
        if (obj.hasOwnProperty("backgroundColor") 
            && "object" == typeof obj.backgroundColor) {
            this.backgroundColor = obj.backgroundColor;
        }
        if (obj.hasOwnProperty("textHorizontalAlignment")&& "string" == typeof obj.textHorizontalAlignment
            &&("center"==obj.textHorizontalAlignment || "right"==obj.textHorizontalAlignment || "left"==obj.textHorizontalAlignment)) {
            this.textHorizontalAlignment = obj.textHorizontalAlignment;
        }
        
        return true;
    };
	this.t_create = function(obj) {
        var ret = this.m_setProperty(obj);
        if(!ret){
            return null;
        }
        //reset background property.
        this.rootWidget.color = this.backgroundColor;
        this.width = this.leftRightMargin*2+this.textWidth*this.itemNum+this.itemGapSize*(this.itemNum-1);
        this.height = this.topBottomMargin*2+this.arrowIconHeight*2+this.textHeight;
        
        var curItemPosX = this.leftRightMargin;
        for(var i=0;i<this.itemNum;i++) {
            if(i>0 && 0 != this.splitIconSrc.length)
            {
                this.splitIconList[i-1] = new ImageWidget({
                    x: curItemPosX,
                    y: 0,
                    origin: {x:0,y:0.5},
                    anchor: {x:0,y:0.5},
                    width: this.itemGapSize,
                    height: this.textHeight,
                    src: this.splitIconSrc,
                    parent: obj.parent,
                });
            }
            this.arrowUpLeftList[i] = new ImageWidget({
                x: curItemPosX+this.itemGapSize+(this.textWidth-this.arrowIconWidth)/2,
                y: this.topBottomMargin,
                width: this.arrowIconWidth,
                height: this.arrowIconHeight,
                src: this.arrowUpLeftNormalSrc,
                parent: obj.parent,
            });
            this.textWidgetList[i] = new TextWidget({
                x: curItemPosX+this.itemGapSize,
                y: 0,
                origin: {x:0,y:0.5},
                anchor: {x:0,y:0.5},
                width: this.textWidth,
                height: this.textHeight,
                text: this.stringArrayList[i][this.contentIndexList[i]],
                font: this.textFont,
                border: {width:0, color:{r:0,g:128,b:128,a:255}},
                textColor: this.textColor,
                color: this.textBGColor,
                horizontalAlignment: this.horizontalAlignment,
                verticalAlignment: "center",
                parent: obj.parent,
            });
            this.arrowDownRightList[i] = new ImageWidget({
                x: curItemPosX+this.itemGapSize+(this.textWidth-this.arrowIconWidth)/2,
                y: this.height-this.topBottomMargin-this.arrowIconHeight,
                width: this.arrowIconWidth,
                height: this.arrowIconHeight,
                src: this.arrowDownRightNormalSrc,
                parent: obj.parent,
            });
            if(0 == i){
                //recalcutate the first spinner position
                this.arrowUpLeftList[i].x = curItemPosX+(this.textWidth-this.arrowIconWidth)/2;
                this.textWidgetList[i].x = curItemPosX;
                this.arrowDownRightList[i].x = curItemPosX+(this.textWidth-this.arrowIconWidth)/2;
                curItemPosX = curItemPosX + this.textWidth;
            }
            else{
                curItemPosX = curItemPosX + this.itemGapSize + this.textWidth;
            }
        }//all spinners created
        this.textWidgetList[this.currentItemIndex].border = this.textBorder;
        this.textWidgetList[this.currentItemIndex].textColor = this.textHighlightColor;
        
        return this;
	};

	this.t_getFocus = function() {
	};
	this.t_loseFocus = function() {
        if(null != this.unfocusCallback){
            this.unfocusCallback(this.contentIndexList);
        }
	};
	this.t_hide = function() {
		this.t_loseFocus();
	};		
	this.t_destroy = function() {
        for(var i=0;i<this.itemNum;i++) {
            this.arrowUpLeftList[i].destroy();
            this.arrowDownRightList[i].destroy();
        }
        for(var i=0;i<this.splitIconList.length;i++) {
            this.splitIconList[i].destroy();
        }
        this.arrowUpLeftList.length = 0;
        this.arrowDownRightList.length = 0;
        this.textWidgetList.length = 0;
        this.splitIconList.length = 0;
        this.stringArrayList.length = 0;
        this.contentIndexList.length = 0;
        this.arrowUpLeftList = null;
        this.arrowDownRightList = null;
        this.textWidgetList = null;
        this.splitIconList = null;
        this.stringArrayList = null;
        this.contentIndexList = null;
        
        delete this.arrowUpLeftMouseClickBind;
        delete this.arrowDownRightMouseClickBind;
	};

    this.m_clearHighlight = function() {
        this.textWidgetList[this.currentItemIndex].border = {width:0, color:{r:0,g:128,b:128,a:255}};
        this.textWidgetList[this.currentItemIndex].textColor = this.textColor;
        this.arrowUpLeftList[this.currentItemIndex].src = this.arrowUpLeftNormalSrc;
        this.arrowDownRightList[this.currentItemIndex].src = this.arrowDownRightNormalSrc;
    };
    this.arrowUpLeftMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            this.m_clearHighlight();
            this.currentItemIndex = targetWidget.SN;
            this.contentIndexList[this.currentItemIndex] = (this.contentIndexList[this.currentItemIndex] + 1) % this.stringArrayList[this.currentItemIndex].length;
            this.textWidgetList[this.currentItemIndex].text = this.stringArrayList[this.currentItemIndex][this.contentIndexList[this.currentItemIndex]];
            //mouse mode
            this.arrowUpLeftList[this.currentItemIndex].src = this.arrowUpLeftHighlightSrc;
            if(null != this.contentChangeCallback){
                this.contentChangeCallback(this.currentItemIndex,this.contentIndexList[this.currentItemIndex],this.textWidgetList[this.currentItemIndex].text);
            }
        }
        return false;
    };	
    this.arrowUpLeftMouseClickBind = this.arrowUpLeftMouseClick.bind(this);
    this.arrowDownRightMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            this.m_clearHighlight();
            this.currentItemIndex = targetWidget.SN;
            this.contentIndexList[this.currentItemIndex] = (this.contentIndexList[this.currentItemIndex] + this.stringArrayList[this.currentItemIndex].length - 1) % this.stringArrayList[this.currentItemIndex].length;
            this.textWidgetList[this.currentItemIndex].text = this.stringArrayList[this.currentItemIndex][this.contentIndexList[this.currentItemIndex]];
            //mouse mode
            this.arrowDownRightList[this.currentItemIndex].src = this.arrowDownRightHighlightSrc;
            if(null != this.contentChangeCallback){
                this.contentChangeCallback(this.currentItemIndex,this.contentIndexList[this.currentItemIndex],this.textWidgetList[this.currentItemIndex].text);
            }
        }
        return false;
    };	
    this.arrowDownRightMouseClickBind = this.arrowDownRightMouseClick.bind(this);   
    this.t_MouseClick = function(isOnFlag){
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag) {
                for(var i=0;i<this.itemNum;i++) {
                    this.arrowUpLeftList[i].SN = i;
                    this.arrowUpLeftList[i].addEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                    this.arrowDownRightList[i].SN = i;
                    this.arrowDownRightList[i].addEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
                }
            }
            else {
                for(var i=0;i<this.itemNum;i++) {
                    this.arrowUpLeftList[i].removeEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                    this.arrowDownRightList[i].removeEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
                }
            }
        }
    };
    
	this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        if (keytype == Volt.EVENT_KEY_RELEASE || !this.isFocused) 
        {
            return ret;
        }	
        switch(keycode) 
        {
            case Volt.KEY_JOYSTICK_RIGHT:
                if(this.currentItemIndex < this.itemNum - 1)
                {
                    this.m_clearHighlight();
                    this.currentItemIndex = this.currentItemIndex + 1;
                    this.textWidgetList[this.currentItemIndex].textColor = this.textHighlightColor;
                    this.textWidgetList[this.currentItemIndex].border = this.textBorder;
                    ret = true;
                }
                break;			
            case Volt.KEY_JOYSTICK_LEFT:	
                if(this.currentItemIndex > 0)
                {
                    this.m_clearHighlight();
                    this.currentItemIndex = this.currentItemIndex - 1;
                    this.textWidgetList[this.currentItemIndex].textColor = this.textHighlightColor;
                    this.textWidgetList[this.currentItemIndex].border = this.textBorder;
                    ret = true;
                }
                break;
            case Volt.KEY_JOYSTICK_DOWN:	
                this.contentIndexList[this.currentItemIndex] = (this.contentIndexList[this.currentItemIndex] + this.stringArrayList[this.currentItemIndex].length - 1) % this.stringArrayList[this.currentItemIndex].length;
                this.textWidgetList[this.currentItemIndex].text = this.stringArrayList[this.currentItemIndex][this.contentIndexList[this.currentItemIndex]];
                if(null != this.contentChangeCallback){
                    this.contentChangeCallback(this.currentItemIndex,this.contentIndexList[this.currentItemIndex],this.textWidgetList[this.currentItemIndex].text);
                }
                ret = true;
                break;
            case Volt.KEY_JOYSTICK_UP:
                this.contentIndexList[this.currentItemIndex] = (this.contentIndexList[this.currentItemIndex] + 1) % this.stringArrayList[this.currentItemIndex].length;
                this.textWidgetList[this.currentItemIndex].text = this.stringArrayList[this.currentItemIndex][this.contentIndexList[this.currentItemIndex]];
                if(null != this.contentChangeCallback){
                    this.contentChangeCallback(this.currentItemIndex,this.contentIndexList[this.currentItemIndex],this.textWidgetList[this.currentItemIndex].text);
                }
                ret = true;
                break;
            default:
                break;
        } 					
        return ret;
	};
	//contentChangeCallback parameter:spinner index, content index, content value
	this.setContentChangeCallback = function(contentChangeCallback)
	{
        if(this.isCreated && null != contentChangeCallback
            && "function" == typeof contentChangeCallback) {
            this.contentChangeCallback = contentChangeCallback;
        }
	};
	//unfocusCallback parameter: array of spinner selected value index
	this.setUnfocusCallback = function(unfocusCallback)
	{
        if(this.isCreated && null != unfocusCallback
            && "function" == typeof unfocusCallback) {
            this.unfocusCallback = unfocusCallback;
        }
	};
}
SpinnerList.prototype = new ControlBase();
exports = SpinnerList;
