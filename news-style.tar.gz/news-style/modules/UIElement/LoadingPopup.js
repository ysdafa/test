/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of LoadingPopup
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
const ControlBase = Volt.require("modules/UIElement/ControlBase.js");
const Loading = Volt.require("modules/UIElement/AnimatedImageDrawing.js");
var setTimeout=function(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
};

var clearTimeout=function (id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
};

/**
 * Class LoadingPopup.
class
 * @constructor
 * @extends UIElement/ControlBase   UIElement/AnimatedImageDrawing
 */
 
LoadingPopup = function() {
	//variable
	var sceWidth = scene.width;
	var sceHeight = scene.height;
	
	this.PopupBGWidget = null;
	this.bgHeight=sceHeight;
	this.bgWidth=sceWidth;
	this.bgColor={r:0,g:0,b:0,a:0.5*255};//0a5d88
	this.bgOpacity=0.5*255;
	this.loadingWidth = 301;
	this.loadingHeight = 58;
	this.loadingPositionX =(sceWidth-301)*0.5;
	this.loadingPositionY = 0.45*sceHeight;
	this.loadingIns=null;
	this.loadingTextPositionX=(sceWidth-301)*0.5;
	this.loadingTextPositionY=(0.45+0.009259)*sceHeight+58;
	this.loadingTextWidth=0.156771*sceWidth;
	this.loadingTextHeight=0.055556*sceHeight;
	this.loadingText="Loading...";
	this.loadingImgList=[];
	this.loadingTextFont="SVD Light 40px";
	this.loadingTextVerticalAlignment="center";
	this.loadingTextHorizontalAlignment="center";
	this.loadingTextTextColor={r:255,g:255,b:255,a:255};
	this.loadingTextBgColor={r:69,g:187,b:163,a:255};//45bba3
	this.loadingTextOpacity=0.9*255;//
	this.isCreate=false;
	this.returnKeyCallback=null;
	this.timer=null;
	this.timeOutCallBack=null;
	this.timeOutTime=10000;
	
	 /**
	* This function will create a LoadingPopup<p>
	* This function will create a LoadingPopup,You can use this function when you want to create an LoadingPopup Object.
	* @param {Object} param of the new LoadingPopup you want to create.
	* @return {Object} return the new LoadingPopup object you want to create.
	* @example //This example create a new LoadingPopup.
	* const script_AID = "UIElement/LoadingPopup";
	* const LoadingPopup = require(script_AID);
	* PopupIns = new LoadingPopup(); 
	* PopupIns.create({parent:scene});
	* @since The version 1.0 this function is added.
	*/
		
	this.t_create = function(obj) {
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("width")){
			this.bgWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.bgHeight=obj.height;
		}
		if(obj.hasOwnProperty("color")){
			this.bgColor=obj.color;
		}
		if(obj.hasOwnProperty("opacity")){
			this.bgOpacity=obj.opacity;
		}
	
		this.PopupBGWidget = new ImageWidget({
			width : this.bgWidth,
			height : this.bgHeight,
			color : {r:10,g:93,b:136,a:0},
			parent : obj.parent
		});
		if(obj.hasOwnProperty("bgsrc")){
			if ("string"== typeof(obj.bgsrc)){
				this.PopupBGWidget.src=obj.bgsrc;
			}
		}
		else{
			this.PopupBGWidget.color=this.bgColor;
		}
		this.PopupBGWidget.opacity=this.bgOpacity;
		this.PopupBGWidget.hide();
		this.textInstance = new TextWidget({
			x : this.loadingTextPositionX,
			y : this.loadingTextPositionY,
			width : this.loadingTextWidth,
			height : this.loadingTextHeight,
			font : this.loadingTextFont,
			horizontalAlignment : this.loadingTextHorizontalAlignment,
			verticalAlignment : this.loadingTextVerticalAlignment,
			text : this.loadingText,
			//color:this.loadingTextBgColor,
			textColor : this.loadingTextTextColor,
			parent : this.PopupBGWidget
		});
		this.isCreate=true;
	};
	this.t_destroy = function() {
		this.loadingImgList.splice(0, this.loadingImgList.length);
		this.loadingImgList = null;
		if(this.loadingIns!=null)
		{
			this.loadingIns.destroy();
			this.loadingIns = null;
		}
		if(this.textInstance!= null){
			this.textInstance.destroy();
			this.textInstance = null;
		}
		if(this.PopupBGWidget != null){
			this.PopupBGWidget.destroy();
			this.PopupBGWidget = null;
		}
	};
	this.t_getFocus = function() {

	};
	this.t_loseFocus = function() {

	};
	this.t_show = function() {
		this.PopupBGWidget.show();
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	this.t_hide = function() {
		this.PopupBGWidget.hide();
	};
	this.t_keyHandler = function(keycode, keytype) {
			return false;
	};
	
	 /**
	* This function will set loading image property in LoadingPopup created<p>
	* This function will set loading image property in LoadingPopup created,You can use this function when you want to set loading image.
	* @param {Object} param of the loading image you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set loading image property.
	* PopupIns.setLoadingImg({imagelist:ImageUrl2});
	* @since The version 1.0 this function is added.
	*/
	
	this.setLoadingImg=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.loadingPositionX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.loadingPositionY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.loadingWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.loadingHeight=obj.height;
		}
		if(obj.hasOwnProperty("imagelist")){
			var num = obj.imagelist.length;
			for(var i=0; i<num; i++){
				if ("string" != typeof(obj.imagelist[i])){
					break;
				}
			}
			if(i != num){
				num=0;
			}
			else{
				this.loadingImgList.splice(0, this.loadingImgList.length);
				this.loadingImgList = obj.imagelist;
			}
		}
		else{
			var num = 0;
		}
		if(this.loadingIns != null){
			this.loadingIns.destroy();
			this.loadingIns = null;
		}
		this.loadingIns = new Loading();
		this.loadingIns.create({x:this.loadingPositionX, y:this.loadingPositionY, width:this.loadingWidth, height:this.loadingHeight, parent:this.PopupBGWidget});
		for(var i = 0; i < this.loadingImgList.length; i++) {
			this.loadingIns.setFrames(this.loadingImgList[i], i);
		}
		this.loadingIns.play(0, 100);
		return true;
	};
	
	 /**
	* This function will set loading text property in LoadingPopup created<p>
	* This function will set loading text property in LoadingPopup created,You can use this function when you want to set loading text.
	* @param {Object} param of the loading text you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set loading text property.
	* PopupIns.setLoadingText({loadingtext:"loading now"});
	* @since The version 1.0 this function is added.
	*/
	
	this.setLoadingText=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.loadingTextPositionX=obj.x;
			this.textInstance.x=this.loadingTextPositionX;
		}
		if(obj.hasOwnProperty("y")){
			this.loadingTextPositionY=obj.y;
			this.textInstance.y=this.loadingTextPositionY;
		}
		if(obj.hasOwnProperty("width")){
			this.loadingTextWidth=obj.width;
			this.textInstance.width=this.loadingTextWidth;
		}
		if(obj.hasOwnProperty("height")){
			this.loadingTextHeight=obj.height;
			this.textInstance.height=this.loadingTextHeight;
		}
		if(obj.hasOwnProperty("textcolor")){
			this.loadingTextTextColor=obj.textcolor;
			this.textInstance.textColor=this.loadingTextTextColor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.loadingTextFont=obj.font;
			}
			this.textInstance.font=this.loadingTextFont;
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			if ("string" == typeof(obj.VerticalAlignment)){
				this.loadingTextVerticalAlignment=obj.VerticalAlignment;
				this.textInstance.VerticalAlignment=this.loadingTextVerticalAlignment;
			}
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			if ("string" == typeof(obj.HorizontalAlignment)){
				this.loadingTextHorizontalAlignment=obj.HorizontalAlignment;
				this.textInstance.HorizontalAlignment=this.loadingTextHorizontalAlignment;
			}
		}
		if(obj.hasOwnProperty("bgcolor")){
			this.loadingTextBgColor=obj.bgcolor;
			this.textInstance.color=this.loadingTextBgColor;
		}
		if(obj.hasOwnProperty("opacity")){
			this.loadingTextOpacity=obj.opacity;
			this.textInstance.opacity=this.loadingTextOpacity;
		}
		if(obj.hasOwnProperty("loadingtext")){
			if ("string" == typeof(obj.loadingtext)){
				this.loadingText=obj.loadingtext;
				this.textInstance.text=this.loadingText;
			}
		}
		return true;
	};
	this.t_keyHandler = function(keycode, keytype) {
		if(this.isCreated == false) {
			return false;
		}
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}					
		var bRet = false;
		switch(keycode) {
			case Volt.KEY_RETURN:
			case Volt.KEY_EXIT:
				bRet = false;
				/*if(this.returnKeyCallback!=null){
					this.returnKeyCallback();
				}
				bRet = true;	*/		
			break;
			default:
				bRet = true;
				break;
		}
		if(bRet == true){
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
		return bRet;
	};
}
LoadingPopup.prototype = new ControlBase();
exports = LoadingPopup;
