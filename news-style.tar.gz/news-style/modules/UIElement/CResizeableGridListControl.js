/**
  This software is the confidential and proprietary information of Samsung Electronics, Inc. ("Confidential Information").
  You shall not disclose such Confidential Information and shall use it only 
  in accordance with the terms of the license agreement you entered into with Samsung.
 
  * @file: CResizeableGridListControl.js
  * @version: 1.01
  * @author: yu.weng
  * @brief: To show unregular item on list
  * @date: 2014/5/31
 
  * @Function List:
              assert
              cancelAllAnimation
              CMapObject
              CMapObject.prototype
              CResizeableGridListControl
              CResizeableGridListItemObject
              CResizeableGridListItemObject.prototype
              defaultValue
              rgcAddSubView
              rgcBuildLayout
              rgcConfigMouseEvent
              rgcDestroyUnloadItems
              rgcGetFocusIndex
              rgcGetItemByIndex
              rgcGetItemInMap
              rgcGetVisibleItems
              rgcHandleKey
              rgcInit
              rgcKillFocus
              rgcMakeFocusRectByItem
              rgcMoveFocusToItem
              rgcOnItemMouseMove
              rgcOnItemMouseOut
              rgcOnKeyDown
              rgcOnKeyLeft
              rgcOnKeyRight
              rgcOnKeyUp
              rgcOnPressItem
              rgcReleaseAllItems
              rgcSetFocus
              rgcSetItems
              rgcUpdateFocusItem
              rgcUpdateView
              TestPrint

  * @Last Modified:
  * @History:
  * @1.Date: 2014/7/18
  * @Author: yu.weng
  * @Modification: Created file
*/

//cursor.js



var Dynamic_Cursor = function(x, y, width, height, Parent, imgs){
	this.id = "Dynamic_Cursor";
	this.bCreateInstance = false;
	this.InstanceRoot = null;
	this.isHidden = true;
	this.preStatus = {
    	Width:0,
    	Height:0
    };
    this.adjustment = -16;
	this.ninePatchInstance = {
		left:null,
		right:null,
		top:null,
		bottom:null,
		topLeft:null,
		topRight:null,
		bottomLeft:null,
		bottomRight:null
	};

	this.destroy = function(){
	if (this.InstanceRoot !== undefined)
	{
		this.InstanceRoot.destroy();
		this.InstanceRoot = undefined;
	}
		}
	
	this.setParent = function(Parent){
		this.InstanceRoot.parent = Parent;
	}
	
	this.initPrestatus = function(x, y, width, height){
		this.move(x, y, width, height);
	}
	this.move = function(x, y, width, height, duration){
		var self = this;
		var duration = duration || 0;

		this.animateDimensions(width, height, duration);
		this.InstanceRoot.animate("x", x, duration);
		this.InstanceRoot.animate("y", y, duration);

	}
	
	this.moveX = function(x, width, height, duration ){
		var self = this;
		var duration = duration || 100;
		
		this.animateDimensions(width, height, duration);
		this.InstanceRoot.animate("x", x, duration);
	}
	
	this.moveY = function(y, width, height, duration ){
		var self = this;
		var duration = duration || 100;
		
		this.animateDimensions(width, height, duration);
		this.InstanceRoot.animate("y", y, duration, self.callback);
	}
	
	this.xPosition = function(xStep){
		this.InstanceRoot.x = xStep;
	}
	
	this.yPosition = function(yStep){
		this.InstanceRoot.y = yStep;
	}
	
	this.getX = function(){
		return this.InstanceRoot.x;
	}
	
	this.getY = function(){
		return this.InstanceRoot.y;
	}
	
	this.callback = function(){
		//print("The move action is Finished !!!@@@!!!");
	}
	
	this.hide = function(){
		this.InstanceRoot.animate("opacity", 0, 100);
	}
	
	this.show = function(){
		this.InstanceRoot.animate("opacity", 255, 100);
	}
	
	this.animateDimensions = function(width, height, d){	
		if (this.preStatus.width == width && this.preStatus.height == height) {
			return;
		}

		var cornerWidth = this.ninePatchInstance.topLeft.width + this.adjustment;
		var cornerHeight = this.ninePatchInstance.topLeft.height + this.adjustment;

	    if (d > 0)
	    {
			this.ninePatchInstance.topLeft.animate("x", -cornerWidth , d); 
			this.ninePatchInstance.topLeft.animate("y", -cornerHeight , d);
		
			this.ninePatchInstance.topRight.animate("x", width + this.adjustment, d);
			this.ninePatchInstance.topRight.animate("y", -cornerHeight , d);
		
			this.ninePatchInstance.bottomRight.animate("x", width + this.adjustment, d); 
			this.ninePatchInstance.bottomRight.animate("y", height + this.adjustment, d);
		
			this.ninePatchInstance.bottomLeft.animate("x", -cornerWidth , d); 
			this.ninePatchInstance.bottomLeft.animate("y", height + this.adjustment, d);
		
			this.ninePatchInstance.left.animate("x",-this.ninePatchInstance.left.width - this.adjustment , d);
			this.ninePatchInstance.left.animate("y", - this.adjustment, d);
		
			this.ninePatchInstance.right.animate("x", width + this.adjustment, d);
			this.ninePatchInstance.right.animate("y", - this.adjustment, d);
		
			this.ninePatchInstance.top.animate("y", -this.ninePatchInstance.top.height - this.adjustment, d);
			this.ninePatchInstance.top.animate("x", -this.adjustment, d);
		
			this.ninePatchInstance.bottom.animate("y", height + this.adjustment, d);
			this.ninePatchInstance.bottom.animate("x", -this.adjustment, d);
		
			//Scale the sides
			this.ninePatchInstance.left.animate("height", height + this.adjustment*2 , d);
			this.ninePatchInstance.right.animate("height", height + this.adjustment*2, d);
			this.ninePatchInstance.top.animate("width", width + this.adjustment*2, d);
			this.ninePatchInstance.bottom.animate("width", width + this.adjustment*2, d);
	    }
		else
		{
			this.ninePatchInstance.topLeft.x = -cornerWidth; 
			this.ninePatchInstance.topLeft.y = -cornerHeight;
		
			this.ninePatchInstance.topRight.x = width + this.adjustment;
			this.ninePatchInstance.topRight.y = -cornerHeight;
		
			this.ninePatchInstance.bottomRight.x = width + this.adjustment;
			this.ninePatchInstance.bottomRight.y = height + this.adjustment;
		
			this.ninePatchInstance.bottomLeft.x = -cornerWidth;
			this.ninePatchInstance.bottomLeft.y = height + this.adjustment;
		
			this.ninePatchInstance.left.x = -this.ninePatchInstance.left.width - this.adjustment;
			this.ninePatchInstance.left.y = - this.adjustment;
		
			this.ninePatchInstance.right.x = width + this.adjustment;
			this.ninePatchInstance.right.y = - this.adjustment;
		
			this.ninePatchInstance.top.y = -this.ninePatchInstance.top.height - this.adjustment;
			this.ninePatchInstance.top.x = -this.adjustment;
		
			this.ninePatchInstance.bottom.y = height + this.adjustment;
			this.ninePatchInstance.bottom.x = -this.adjustment;
		
			//Scale the sides
			this.ninePatchInstance.left.height = height + this.adjustment*2;
			this.ninePatchInstance.right.height = height + this.adjustment*2;
			this.ninePatchInstance.top.width = width + this.adjustment*2;
			this.ninePatchInstance.bottom.width = width + this.adjustment*2;
		}
		
		this.preStatus = {Width: width, Height: height};
	}
	
	this.init = function(x, y, width, height, Parent, imgs){
		if (Parent == null) {
			return;
		}
		
		var self = this;
		var tempCursor = new Widget(0,0);
		tempCursor.color.a = 0;
		
		this.ninePatchInstance = {
			left:null,
			right:null,
			top:null,
			bottom:null,
			topLeft:null,
			topRight:null,
			bottomLeft:null,
			bottomRight:null
		};
		this.preStatus = {width: 0, height: 0};
		
		tempCursor.opacity = 0;
		
		this.InstanceRoot = tempCursor;
		//this.InstanceRoot.depth =;
		
		var tempInstance = null;
		for(var index in imgs) {
			tempInstance = new ImageWidget({src: imgs[index], async:false});
			this.ninePatchInstance[index] = tempInstance;
			tempCursor.addChild(tempInstance);
			tempInstance = null;
		}	
		
		this.bCreateInstance = true;
		
		self.initPrestatus(x, y, width, height);
		self.InstanceRoot.parent = Parent;
		//return this; retirn parent height instance initialize the instance index ninepatch options temp
		//this.InstanceRoot.show();
	}

	this.init(x, y, width, height, Parent, imgs);

	
}


//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

function getChildById(id)
{
	for (var i = 0; i < this.getChildCount(); ++i)
	{
		var wChild = this.getChild(i)
		{
			if (wChild.ID === id || (wChild.custom && wChild.custom.ID === id) )
			{
				return wChild;
			}
		}
	}
	return undefined;
}

Widget.prototype.doAnimation = function(widget, element, value, time)
{
	if (time > 0)
	{
		//TestPrint("Change value...0");
		widget.animate(element, value, time);
	}
	else
	{
		//TestPrint("Change value...1");

		if (widget.changeAttr)
		{
		    widget.changeAttr(element, value);
			return;
		}
		var arrElems = element.split(".");
		var elemTarget = widget;
		for (var i = 0; i < arrElems.length - 1; ++i)
		{
			elemTarget = elemTarget[arrElems[i]];
		}

		if (arrElems.length > 0)
		{
			elemTarget[arrElems[arrElems.length - 1]] = value;
			//TestPrint("Change value...2");
		}
	}
}



function assert(condition, strErrorInfo)
{
	strErrorInfo = strErrorInfo || "";
	if (!(condition))
	{
		throw new Error(strErrorInfo);
	}
}

function defaultValue(value, defaultValue)
{
	if (value === undefined)
	{
		return defaultValue;
	}
	else
	{
		return value;
	}
}

////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Can not globally expand clone function for all Object, it's dangerous.
var _clone = function(obj) {
    var objClone;
    if (obj.constructor == Object){
        objClone = new obj.constructor(); 
    }else{
        objClone = new obj.constructor(obj.valueOf()); 
    }
    for(var key in obj){
        if ( objClone[key] != obj[key] ){ 
            if ( typeof(obj[key]) == 'object' ){ 
                objClone[key] = obj[key].clone();
            }else{
                objClone[key] = obj[key];
            }
        }
    }
    objClone.toString = obj.toString;
    objClone.valueOf = obj.valueOf;
    return objClone; 
};

/*
Object.prototype.clone = function(){
    var objClone;
    if (this.constructor == Object){
        objClone = new this.constructor(); 
    }else{
        objClone = new this.constructor(this.valueOf()); 
    }
    for(var key in this){
        if ( objClone[key] != this[key] ){ 
            if ( typeof(this[key]) == 'object' ){ 
                objClone[key] = this[key].clone();
            }else{
                objClone[key] = this[key];
            }
        }
    }
    objClone.toString = this.toString;
    objClone.valueOf = this.valueOf;
    return objClone; 
}
*/
// End Update
////////////////////////////////////////////////////////////////////////////////
var COMMON_DATA = {};
COMMON_DATA.EMPTY_CELL = -1;
COMMON_DATA.MAIN_LIST_ID = "CResizeableGridListControl";

////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Comment the Test Part
/*
var wTestPrint = new TextWidget(
	{
		x:50,
		y:50,
		width:1500,
		height:980,
		font:"System Default 20px",
		textColor:{r:0, g:0, b:0},
		parent:scene
	}
);

wTestPrint.show();
var nTextLine = 0;
*/
function TestPrint(str)
{
/*
	++nTextLine;
	if (nTextLine > 40)
	{
		nTextLine = 0;
		wTestPrint.text = "";
	}
	wTestPrint.text = wTestPrint.text + str + "\n";
*/
}

function CMapObject()
{
	this.map = [];
	this.width = 0;
	this.height = 0;
}

CMapObject.prototype.createMap = function(width, height)
{
	this.width = width;
	this.height = height;
	for (var i = 0; i < height; ++i)
	{
		var arrRow = new Array;
		for (var j = 0; j < width; ++j)
		{
			arrRow.push(COMMON_DATA.EMPTY_CELL);
		}
		this.map.push(arrRow);
	}
}

CMapObject.prototype.releaseMap = function()
{
	this.map = [];
}

CMapObject.prototype.getValue = function(param)
{
	var nX = param["x"];
	var nY = param["y"];
	assert(nX !== undefined && nY !== undefined);
	
	if (nX < 0 || nX >= this.width || nY < 0 || nY >= this.height)
	{
		return undefined;
	}
	else
	{
	    return this.map[nY][nX];	
	}
}

CMapObject.prototype.toString = function()
{
    var strDesc = "";
    for (var i = 0; i < this.height; ++i)
    {
    	for (var j = 0; j < this.width; ++j)
    	{
    		var nValue = this.map[i][j];
    		if (nValue >= 0)
    		{
    			strDesc += "  ";
    		}
    		strDesc += nValue;
    		strDesc += " ";
    	}
    	strDesc += "\n";
    }
    return strDesc;
}

CMapObject.prototype.setValue = function(param)
{
	var nX = param["x"];
	var nY = param["y"];
	var nValue = param["value"];
	var nWidth = param["width"];
	var nHeight = param["height"];
	assert(nX !== undefined && nX >= 0 && nX < this.width, nX + " " + this.width);
	assert(nY !== undefined && nY >= 0 && nY < this.height, nY + " " + this.height);
	assert(nValue !== undefined && nWidth !== undefined && nHeight !== undefined);
	
	if (nY + nHeight > this.height)
	{
		if (0 == nY)
		{
			nHeight = this.height;
		}
		else
		{
			return false;
		}
	}
	for (var nCol = nX; nCol < nX + nWidth; ++nCol)
	{
		for (var nRow = nY; nRow < nY + nHeight; ++nRow)
		{
			if (this.map[nRow][nCol] != COMMON_DATA.EMPTY_CELL)
			{
				return false;
			}
		}
	}

	for (var nCol = nX; nCol < nX + nWidth; ++nCol)
	{
		for (var nRow = nY; nRow < nY + nHeight; ++nRow)
		{
			this.map[nRow][nCol] = nValue;
		}
	}
	return true;

}


function CResizeableGridListItemObject()
{
	this.widget = undefined;
	//this.shadow = undefined;
	this.nItemIndex = 0;
	this.logPosition = {x:0, y:0};
	this.logSize = {width:0, height:0};
	//this.arrAnis = [];
	
}

CResizeableGridListItemObject.prototype.releaseItem = function()
{
	if (this.widget !== undefined)
	{
		this.widget.parent.removeChild(this.widget);
		this.widget.destroy();
	    this.widget = undefined;
	}
}

	

CResizeableGridListItemObject.prototype.createItem = function(param) 
{
	this.widget = new Widget(param);
	this.widget.index = param["index"];
	this.widget.show();
}

/*
var listCtl = new CResizeableGridListControl(
   {x:600,
	y:100,
	rows:6,
	width:1200,
	itemWidth:90,
	itemHeight:110,
	parent:scene});
var arrItems = [];
arrItems.push({width:3, height:2});
arrItems.push({width:1, height:1});
listCtl.itemScale = {x:1.15, y:1.15};
listCtl.focusMode = listCtl.FOCUS_MODE_3D;
listCtl.setItems(arrItems, true);
listCtl.nAniTimeMove = 300; 
listCtl.show();
listCtl.setFocus();
	*/
function CResizeableGridListControl(param)
{
	var gridlist = new Widget();
	//gridlist.prototype = {};

	//constant
	//normal focus mode
    gridlist.FOCUS_MODE_NORMAL = 0;

	//3d focus mode like 15 UX
	gridlist.FOCUS_MODE_3D = 1;

    //move out direction
	gridlist.MOVE_OUT_DIR_UP = 2;
	gridlist.MOVE_OUT_DIR_LEFT = 3;
	gridlist.MOVE_OUT_DIR_DOWN = 4;
	gridlist.MOVE_OUT_DIR_RIGHT = 5;
	
	//public
	//(arrItems, bAnimate), arrItems's elem is {width:?, height:?}
	gridlist.setItems = rgcSetItems;

	//get resue cell
	gridlist.getReuseableWidget = rgcGetReuseableWidget;

	//normlize widget
	gridlist.normalizeWidget = rgcNormalizeWidget;

	//pass the key event to this function to handle event function(keyCode, type)
	gridlist.handleKey = rgcHandleKey;

	//list move animation duration
	gridlist.nAniTimeMove = 300;

	//list item scale animation duration
	gridlist.nAniTimeScale = 200;

	//list page move animation duration
	gridlist.nAniTimePageMove = 600;

	//print the log on the screen
	gridlist.logPrint = TestPrint;

    //get the focus item's index
	gridlist.getFocusIndex = rgcGetFocusIndex;

	//set the focus to specified item (index)
	gridlist.setFocusIndex = rgcSetFocusIndex;

	//set focus to the list
	gridlist.setFocus = rgcSetFocus;

	//kill the gridlist's focus
	gridlist.killFocus = rgcKillFocus;

	//set the item scale ratio
	gridlist.itemScale = {x:1, y:1};

	//set the list's focus mode
	gridlist.focusMode = gridlist.FOCUS_MODE_NORMAL;

	//add subview to the list control, can scroll with list (view, index)
	gridlist.addSubView = rgcAddSubView;

	//release resource
	gridlist.releaseList = rgcReleaseList;

	//get scroll content offset, return a object, {x:100, y:0} for example
	gridlist.getContentViewOffset = function(){return {x:this.m_oriPoint.x, y:this.m_oriPoint.y};}

	//get content view's size
	gridlist.getContentViewSize = rgcGetContentViewSize;

	//check if can move left
	gridlist.flagCanMoveLeft = function(){return this.m_oriPoint.x > 0;}

	//check if can move right
	gridlist.flagCanMoveRight = function(){return this.m_oriPoint.x + this.width < this.getContentViewSize().width;}

    //check if can move left
	gridlist.flagCanMoveUp = function(){return this.m_oriPoint.y > 0;}

	//check if can move right
	gridlist.flagCanMoveDown = function(){return this.m_oriPoint.y + this.height < this.getContentViewSize().height;}

    //update all visibleable items (param)
    gridlist.updateAllItems = rgcUpdateAllItems;

	//check if the list have focus
	gridlist.flagFocus = function(){return this.m_bFocus;}

	//update specified item (param)
	gridlist.updateItem = rgcUpdateItem;

	//get the widget of each item, getWidget(index)
	gridlist.getWidget = rgcGetWidget;

	//set focust image
	gridlist.setFocusImage = function(imgs){this.m_arrFocusImgs = imgs;}

	//page up
	gridlist.pageUp = rgcPageUp;

	//page down
	gridlist.pageDown = rgcPageDown;

	//page left
	gridlist.pageLeft = rgcPageLeft;

	//page right
	gridlist.pageRight = rgcPageRight;

	//set focus margin
	gridlist.focusMargin = {x:0,y:0,w:0,h:0};

	//get item count
	gridlist.getItemCount = rgcGetItemCount;

	//push items to end (arrItems)
	gridlist.pushItems = rgcPushItems;

	//remove items from the end (nItemCount)
	gridlist.popItems = rgcPopItems;

	//resize items
	gridlist.relayoutItems = rgcRelayoutItems;

	//check if is block by animation
	gridlist.isAnimating = function(){return this.m_timerAni !== undefined;}

	//enable list
	gridlist.enable = rgcEnable;

	//check if is enable state
	gridlist.flagEnable = function(){return this.m_bEnable;}

	//set item size
	gridlist.setBasicItemSize = rgcSetBasicItemSize;

	//relayout
	gridlist.relayout = rgcRelayout;

	gridlist.onKeyEvent = onKeyEvent;
    
    gridlist.onFocus = rgcSetFocus;
    gridlist.onBlur = rgcKillFocus;

	gridlist.dim = rgcDim;
	gridlist.undim = rgcUndim;
	gridlist.alwaysScaleFromCenter = false;
	
	
	//callback
	//when item is on the screen, list will notice the receiver to render UI on the item
	//must use widget.addChild to add sub widget to the widget
	//in this callback function, "this" means the listctl
	gridlist.ifItemLoaded = function(index, width, height, id){}

	//if one item is pressed by removecontroller or mouse, will call this callback
	gridlist.ifItemPress = function(index, widget, id){}

	//if one item is long pressed by removecontroller or mouse, will call this callback
	gridlist.ifItemLongPress = function(index, widget, id){}

	//if focus is changed from one item to one item, will call this function
	gridlist.ifFocusChange = function(oldIndex, newIndex){}

	//if focus is moved out of the list, will call this function
	gridlist.ifMoveOut = function(dir){}

	//if view scroll, will call this function
	gridlist.ifScroll = function(){}

	//call when use updateAllItems
	gridlist.ifItemUpdate = function(index, widget, id, param){}

	//call when listctl get the focus
	gridlist.ifGetFocus = function(){}

	//call when listctl lose the focus
	gridlist.ifLoseFocus = function(){}

	//call before scroll view, and let user decide if need scroll
	gridlist.canScroll = function(contentViewOffsetFrom, contentViewOffsetTo){return true;}

	//call before move focus, let user decide if can move
	gridlist.canMove = function(index){return true;}

	//call when relayout items
	gridlist.ifItemRelayout = function(index, widget, toSize, aniTime, param){}
	
	//private
	gridlist._initList = rgcInit;
	gridlist._releaseAllItems = rgcReleaseAllItems;
	gridlist._buildLayout = rgcBuildLayout;
	gridlist._getItemInMap = rgcGetItemInMap;
	gridlist._getItemByIndex = rgcGetItemByIndex;
	gridlist._moveFocusToItem = rgcMoveFocusToItem;
	gridlist._updateFocusItem = rgcUpdateFocusItem;
	gridlist._makeFocusRectByItem = rgcMakeFocusRectByItem;
	gridlist._updateView = rgcUpdateView;
	gridlist._getVisibleItems = rgcGetVisibleItems;
	gridlist._onKeyLeft = rgcOnKeyLeft;
	gridlist._onKeyRight = rgcOnKeyRight;
	gridlist._onKeyUp = rgcOnKeyUp;
	gridlist._onKeyDown = rgcOnKeyDown;
	gridlist._onPressItem = rgcOnPressItem;
	gridlist._configMouseEvent = rgcConfigMouseEvent;
	gridlist._onItemMouseMove = rgcOnItemMouseMove;
	gridlist._onItemMouseOut = rgcOnItemMouseOut;
	gridlist._calcFocusItemPos = rgcCalcFocusItemPos;
	gridlist._needOptimseFocusItem = rgcNeedOptimseFocusItem;
	gridlist._realItemScale = rgcRealItemScale;
	gridlist._getAvailableCellByPoint = rgcGetAvailableCellByPoint;
	gridlist._destroyUnloadItems = rgcDestroyUnloadItems;
	
	gridlist._initList(param);
	
	return gridlist;
}

function rgcDim()
{
	try 
	{
		//Volt.pauseGraphics();
		this.enable(false);

		if (this.m_itemFocus !== undefined)
		{
			this.m_wList.removeChild(this.m_itemFocus.widget);
		}
		this.wDim = new Widget({
			x:this.m_oriPoint.x,
			y:this.m_oriPoint.y,
			width:this.width,
			height:this.height,
			color:{a:120, r:0, g:0, b:0}}
		);


		this.m_wList.addChild(this.wDim);
		
		if (this.m_itemFocus !== undefined)
		{
			this.m_wList.addChild(this.m_itemFocus.widget);
		}
		
		this.killFocus();
		//Volt.resumeGraphics();
	}
	catch (e)
	{
		//Volt.resumeGraphics();
		throw e;
	}
	
}

function rgcUndim()
{
	if (this.wDim !== undefined)
	{
		this.m_wList.removeChild(this.wDim);
		this.wDim.destroy();
		this.wDim = undefined;
	}

	
	this.enable(true);
	
	if (!this.flagFocus())
	{
		this.setFocus();
	}
}

function onKeyEvent(keyCode, type) 
{
    if (keyCode == Volt.KEY_JOYSTICK_OK) {
        this.handleKey(keyCode, type);
        return;
    }
    else {
        return this.handleKey(keyCode, type);
    }
};

function rgcGetReuseableWidget(id)
{
	for (var i = 0; i < this.m_arrReuseableWidget.length; ++i)
	{
		var widget = this.m_arrReuseableWidget[i];
		if (widget.reuseableId === id)
		{
			this.m_arrReuseableWidget.splice(i, 1);
			return widget;
		}
	}
	return undefined;
}

function rgcSetBasicItemSize(width, height)
{
	this.m_itemSize.width = width;
	this.m_itemSize.height = height;
}

function rgcEnable(bEnable)
{
	this.m_bEnable = bEnable;
}

function haveItemInArray(item, array)
{
	for (var i = 0; i < array.length; ++i)
	{
		if (array[i] === item)
		{
			return true;
		}
	}
	return false;
}

function finishTimeoutAni(parent, param)
{
	parent.m_timerAni = undefined;
	parent.setFocus();

    for (var i = 0; i < parent.m_arrItems.length; ++i)
	{
		var item = parent.m_arrItems[i];
		if (item.bLeaveFlag === true)
		{
			delete item.bLeaveFlag;
			if (item.widget !== undefined)
			{
				item.widget.x = parent.m_itemSize.width * item.logPosition.x;
				item.widget.y = parent.m_itemSize.height * item.logPosition.y;
				item.widget.width = parent.m_itemSize.width * item.logSize.width;
				item.widget.height = parent.m_itemSize.height * item.logSize.height;
				parent.ifItemRelayout(item.nItemIndex, item.widget, {width:item.widget.width, height:item.widget.height}, 0, param);
				item.widget.show();
			}
		}
	}

	parent.ifScroll();
}

function dumpArray(arr)
{
	var str = "";
	for (var i = 0; i < arr.length; ++i)
	{
		var item = arr[i];
		str += item.nItemIndex +',';
	}
	return str;
}

function rgcRelayout(row, itemWidth, itemHeight)
{
	this.m_nDisplayRow = row;
	this.m_itemSize = {width:itemWidth, height:itemHeight};
}

function rgcRelayoutItems(arrItems, nRow, nItemWidth, nItemHeight, param)
{
	assert("can't use this function now");
	assert(arrItems.length == this.m_arrItems.length);

    //var nTime1 = (new Date).getTime();
	if (this.m_timerAni !== undefined)
	{
		return;
	}

	if (!this.m_bEnable)
	{
		return;
	}

	var arrInViewOld = this._getVisibleItems(this.m_oriPoint.y, this.m_oriPoint.x, this.m_oriPoint.y + this.height,
		this.m_oriPoint.x + this.width);

	this.killFocus(false);
	//var arrOldItemInfo = [];
	var nAniTime = 800;
	for (var i = 0; i < this.m_arrItems.length; ++i)
	{
		var item = this.m_arrItems[i];
		var itemNew = arrItems[i];
		//var itemInfo = {};
		//itemInfo.x = item.logPosition.x * this.m_itemSize.width;
		//itemInfo.y = item.logPosition.y * this.m_itemSize.height;
		//itemInfo.width = item.logSize.width * this.m_itemSize.width;
		//itemInfo.height = item.logSize.height * this.m_itemSize.height;
		//arrOldItemInfo.push(itemInfo);
		
		item.logSize.width = itemNew.width;
		item.logSize.height = itemNew.height;
		if (itemNew.scale !== undefined)
		{
			item.scale = itemNew.scale;
		}
		else
		{
			delete item.scale;
		}

		if (itemNew.id !== undefined)
		{
			item.strId = itemNew.id;
		}
	}

    var oldContentSize = this.getContentViewSize();

////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Can not globally extend clone function for all Object, it's dangerous.
    //var oldOriPoint = this.m_oriPoint.clone();
    var oldOriPoint = _clone(this.m_oriPoint);
// End
////////////////////////////////////////////////////////////////////////////////

	var itemKey = this.m_itemFocus;
	if (itemKey === undefined)
	{
		itemKey = this._getAvailableCellByPoint(this.m_oriPoint);
	}
    this.m_nDisplayRows = nRow;
	this.m_mapObj.releaseMap();
	this._buildLayout();
	this.m_itemSize.width = nItemWidth;
	this.m_itemSize.height = nItemHeight;

	
	var newContentSize = this.getContentViewSize();

	
	this.m_oriPoint.x = Math.ceil(this.m_oriPoint.x * newContentSize.width / oldContentSize.width);
	//TestPrint("1." + this.m_oriPoint.x);

	var nEndPos = (itemKey.logPosition.x + itemKey.logSize.width) * this.m_itemSize.width;
	var nBeginPos = itemKey.logPosition.x * this.m_itemSize.width;
    if (nEndPos > this.m_oriPoint.x + this.width)
    {
		this.m_oriPoint.x = Math.floor(nEndPos - this.width + (this.width - itemKey.logSize.width * this.m_itemSize.width) / 2);
		//TestPrint("2." + this.m_oriPoint.x);
    }

	if (nBeginPos < this.m_oriPoint.x)
	{
		this.m_oriPoint.x = Math.floor(nEndPos - this.width + (this.width - itemKey.logSize.width * this.m_itemSize.width) / 2);
		//TestPrint("3." + this.m_oriPoint.x);
	}

	//assert(false, this.m_oriPoint.x + "," + newContentSize.width + "," + this.width);

	this.m_oriPoint.x = Math.min(this.m_oriPoint.x, newContentSize.width - this.width);
	this.m_oriPoint.x = Math.max(0, this.m_oriPoint.x);
	//TestPrint("4." + this.m_oriPoint.x + "," + itemKey.logPosition.x * this.m_itemSize.width);
	var arrInViewNew = this._getVisibleItems(this.m_oriPoint.y, this.m_oriPoint.x, this.m_oriPoint.y + this.height,
		this.m_oriPoint.x + this.width);

	var arrWillLeaveView = [];
	var arrWillEnterView = [];
	var arrWillMaintain = [];

	for (var i = 0; i < arrInViewNew.length; ++i)
	{
		var item = arrInViewNew[i];
		item.bInViewFlag = true;
		if (haveItemInArray(item, arrInViewOld))
		{
			arrWillMaintain.push(item);
		}
		else
		{
			arrWillEnterView.push(item);
		}
	}

	for (var i = 0; i < arrInViewOld.length; ++i)
	{
		var item = arrInViewOld[i];
		item.bInViewFlag = true;
		if (!haveItemInArray(item, arrInViewNew))
		{
			arrWillLeaveView.push(item);
		}
	}

	for (var i = 0; i < this.m_arrItems.length; ++i)
	{
		var item = this.m_arrItems[i];
		if (item.bInViewFlag === true)
		{
			delete item.bInViewFlag;
		}
		else
		{
			//item.releaseItem();
			if (item.widget !== undefined)
			{
				item.bLeaveFlag = true;
				item.widget.hide();
			}
		}
	}

	//var strWillMaintain = "strWillMaintain:" + dumpArray(arrWillMaintain);//20 21 22 23 24 25
	//var strWillEnter = "strWillEnter:" + dumpArray(arrWillEnterView);//
	//var strWillLeave = "strWillLeave:" + dumpArray(arrWillLeaveView);//14~19 26 ~31
	//var strInViewOld = "strInViewOld:" + dumpArray(arrInViewOld);
	//var strInViewNew = "strInViewNew:" + dumpArray(arrInViewNew);

	//assert(false, strWillMaintain + strWillEnter + strWillLeave + strInViewOld + strInViewNew);
	

	for (var i = 0; i < arrWillMaintain.length; ++i)
	{
		var item = arrWillMaintain[i];
		var nToWidth = item.logSize.width * this.m_itemSize.width;
		var nToHeight = item.logSize.height * this.m_itemSize.height;
		this.ifItemRelayout(item.nItemIndex, item.widget, {width:nToWidth, height:nToHeight}, nAniTime, param);
		item.widget.animate("x", item.logPosition.x * this.m_itemSize.width, nAniTime);
		item.widget.animate("y", item.logPosition.y * this.m_itemSize.height, nAniTime);
		item.widget.animate("width", nToWidth, nAniTime);
		item.widget.animate("height", nToHeight, nAniTime);
	}

	
	//TestPrint("Relayout time2:" + ((new Date).getTime() - nTime1));
	var nNewCreateItems = 0;
	for (var i = 0; i < arrWillEnterView.length; ++i)
	{
		var item = arrWillEnterView[i];
		var nToWidth = item.logSize.width * this.m_itemSize.width;
		var nToHeight = item.logSize.height * this.m_itemSize.height;
		
		var nToX = item.logPosition.x * this.m_itemSize.width;
		var nToY = item.logPosition.y * this.m_itemSize.height;
		var nFromX = 0;
		if (nToX < this.m_oriPoint.x)
		{
			nFromX = oldOriPoint.x - this.width * 0.1 - Math.sqrt(this.m_oriPoint.x - nToX) - Math.random() * (this.width / 5);
		}
		else
		{
			nFromX = oldOriPoint.x + this.width * 1.1 + Math.sqrt(nToX - this.m_oriPoint.x) + Math.random() * (this.width / 5);
		}
		var nFromY = this.m_oriPoint.y + this.height / 2 - nToHeight / 2 + Math.random() * (this.height / 3);

		//var oldItemInfo = arrOldItemInfo[item.nItemIndex];
		if (item.widget === undefined)
		{
			++nNewCreateItems;
			item.createItem(
			{
				width:nToWidth,
				height:nToHeight,
				color:{a:0},
				parent:this.m_wList,
				x:nFromX,
				y:nFromY,
				index:item.nItemIndex
			});

			this._configMouseEvent(item);
			this.ifItemLoaded(item.nItemIndex, item.widget, item.strId);
		}
		else
		{
			this.ifItemRelayout(item.nItemIndex, item.widget, {width:nToWidth, height:nToHeight}, 0, param);
			item.widget.x = nFromX;
			item.widget.y = nFromY;
			item.widget.width = nToWidth;
			item.widget.height = nToHeight;
		}
		
		
		item.widget.animate("x", nToX, nAniTime);
		item.widget.animate("y", nToY, nAniTime);
		//item.widget.animate("width", item.logSize.width * this.m_itemSize.width, nAniTime);
		//item.widget.animate("height", item.logSize.height * this.m_itemSize.height, nAniTime);
	}

  // TestPrint("Relayout time3:" + ((new Date).getTime() - nTime1) + "Create items:" + nNewCreateItems);
	//TestPrint("Relayout time2:" + ((new Date).getTime() - nTime1));
	for (var i = 0; i < arrWillLeaveView.length; ++i)
	{
		var item = arrWillLeaveView[i];
		item.bLeaveFlag = true;
		var nToX = 0;
		var nPosition = item.logPosition.x * this.m_itemSize.width;
		if (nPosition < this.m_oriPoint.x)
		{
			nToX = this.m_oriPoint.x - item.widget.width - Math.sqrt(this.m_oriPoint.x - nPosition) - Math.random() * (this.width / 5);
		}
		else
		{
			nToX = this.m_oriPoint.x + this.width * 1.1 + Math.sqrt(nPosition - this.m_oriPoint.x) + Math.random() * (this.width / 5);
		}
		var nToY = this.m_oriPoint.y + this.height / 2 - item.widget.height / 2 + Math.random() * (this.height / 3);
	    
		item.widget.animate("x", nToX, nAniTime);
		item.widget.animate("y", nToY, nAniTime);
	}

	if (this.m_wList.aniHandle !== undefined)
	{
		this.m_wList.aniHandle.cancel();
		delete this.m_wList.aniHandle;
	}

    var ani = new Animation(nAniTime);
	ani.addProperty("x", -this.m_oriPoint.x + this.m_visibleAreaExtend.l);
	ani.addProperty("y", -this.m_oriPoint.y + this.m_visibleAreaExtend.t);
	this.m_wList.aniHandle = this.m_wList.animate(ani);

	//this.m_wFocusBg.animate("x", -this.m_oriPoint.x, nAniTime);
	//this.m_wFocusBg.animate("y", -this.m_oriPoint.y, nAniTime);
		   
	this.m_timerAni = Volt.setTimeout(finishTimeoutAni, nAniTime * 1.1, this, param);

	//TestPrint("Relayout time3:" + ((new Date).getTime() - nTime1));
}

function rgcPushItems(arrItems)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}

	if (!this.m_bEnable)
	{
		return;
	}
	if (this.getItemCount() == 0)
	{
		this.setItems(arrItems, false);
		return;
	}
	assert(arrItems !== undefined);
	assert(arrItems.length > 0);
	
	//this.m_nCols = 0;
	//this.m_oriPoint.x = 0;
	//this.m_oriPoint.y = 0;
	//this.m_itemFocus = undefined;
	this.m_nRealWidth = 0;
	this.m_nRealHeight = 0;
	this.m_mapObj.releaseMap();
	
	for (var i = 0; i < arrItems.length; ++i)
	{
		var tmpItem = arrItems[i];
		var objItem = new CResizeableGridListItemObject();
		objItem.nItemIndex = this.m_arrItems.length;
		objItem.logSize.width = tmpItem.width;
		objItem.logSize.height = tmpItem.height;
		if (tmpItem.scale !== undefined)
		{
			objItem.scale = tmpItem.scale;
		}

		if (tmpItem.id !== undefined)
		{
			objItem.strId = tmpItem.id;
		}
		this.m_nCols += objItem.logSize.width;
		this.m_arrItems.push(objItem);
	}
	this.m_arrItems.sort(function(a, b){return a.nItemIndex > b.nItemIndex ? 1 : -1;});
	this._buildLayout();

	//this.m_itemFocus = this.m_arrItems[0];

	this.m_bInitSetItem = true;
	this._updateView(this.m_oriPoint, undefined, 0);
}

function rgcPopItems(nItemCount)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}

	if (!this.m_bEnable)
	{
		return;
	}
	if (nItemCount <= 0)
	{
		return;
	}

	if (this.getItemCount() == 0)
	{
		return;
	}

	if (nItemCount >= this.getItemCount())
	{
		this._releaseAllItems();
		this.m_mapObj.releaseMap();
		if (this.m_objFocus !== undefined)
		{
			this.m_objFocus.parent.removeChild(this.m_objFocus);
			this.m_objFocus.destroy();
			this.m_objFocus = undefined;
		}

		//if (this.m_objShadow !== undefined)
		//{
		//	this.m_objShadow.destroy();
		//	this.m_objShadow = undefined;
		//}
		this.m_itemFocus = undefined;
		return;
	}
	
	this.m_nRealWidth = 0;
	this.m_nRealHeight = 0;
	this.m_mapObj.releaseMap();
	
	for (var i = 0; i < nItemCount; ++i)
	{
		var item = this.m_arrItems.pop();

		if (item === this.m_itemFocus)
		{
			this.m_itemFocus = this.m_arrItems[this.m_arrItems.length - 1];
		}
		item.releaseItem();
		item = undefined;
	}
	
	this._buildLayout();

	//this.m_itemFocus = this.m_arrItems[0];

    var sizeContentView = this.getContentViewSize();
	this.m_oriPoint.x = Math.max(0, Math.min(this.m_oriPoint.x, sizeContentView.width - this.width));
	this.m_oriPoint.y = Math.max(0, Math.min(this.m_oriPoint.y, sizeContentView.height - this.height));
	this._updateView(this.m_oriPoint, this.m_itemFocus, 0);
}

function rgcGetItemCount()
{
	return this.m_arrItems.length;
}

function rgcPageUp()
{
	if (this.m_timerAni !== undefined)
	{
		return false;
	}

	if (!this.m_bEnable)
	{
		return;
	}

////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Can not globally expand clone function for all Object, it's dangerous.
    //var oriPoint = this.m_oriPoint.clone();
    var oriPoint = _clone(this.m_oriPoint);
// End Update 
////////////////////////////////////////////////////////////////////////////////

	oriPoint.y = Math.max(oriPoint.y - this.height, 0);

	var item = this._getAvailableCellByPoint(oriPoint);
	if (item !== undefined)
	{
		this._moveFocusToItem(item, oriPoint, this.nAniTimePageMove);
		return true;
	}
	else
	{
		return false;
	}
}

function rgcPageDown()
{
	if (this.m_timerAni !== undefined)
	{
		return false;
	}

	if (!this.m_bEnable)
	{
		return;
	}
////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Can not globally expand clone function for all Object, it's dangerous.
    //var oriPoint = this.m_oriPoint.clone();
    var oriPoint = _clone(this.m_oriPoint);
// End Update
////////////////////////////////////////////////////////////////////////////////

	var sizeContent = this.getContentViewSize();
	oriPoint.y = Math.min(oriPoint.y + this.height, sizeContent.height - this.height);

	var item = this._getAvailableCellByPoint(oriPoint);
	if (item !== undefined)
	{
		this._moveFocusToItem(item, oriPoint, this.nAniTimePageMove);
		return true;
	}
	else
	{
		return false;
	}
}

function rgcPageLeft(nMoveValue)
{
	if (this.m_timerAni !== undefined)
	{
		return false;
	}

	if (!this.m_bEnable)
	{
		return;
	}
////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Can not globally expand clone function for all Object, it's dangerous.
    //var oriPoint = this.m_oriPoint.clone();
    var oriPoint = _clone(this.m_oriPoint);
// End Update
////////////////////////////////////////////////////////////////////////////////


	var item = undefined;

	if (nMoveValue !== undefined)
	{
		oriPoint.x = Math.max(oriPoint.x - nMoveValue, 0);

		var pt = this.m_itemFocus.logPosition;
		var nUpCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1);
		var nDownCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1) + 1;
		var nStartCol = pt.x - 1;
		item = this._getItemInMap(nStartCol, nUpCursor);

		if (item === undefined)
		{
			for (var nCol = nStartCol; nCol >= 0; --nCol)
			{
				while (nUpCursor >= 0 || nDownCursor < this.m_mapObj.height)
				{
					item = this._getItemInMap(nCol, nUpCursor);
					if (item !== undefined)
					{
						break;
					}
					item = this._getItemInMap(nCol, nDownCursor);
					if (item !== undefined)
					{
						break;
					}
					
					--nUpCursor;
					++nDownCursor;
				}
				if (item !== undefined)
				{
					break;
				}
			}
		}

	    if (item === undefined)
		{
			item = this.m_itemFocus;
	    }
	}
	else
	{
		oriPoint.x = Math.max(oriPoint.x - this.width, 0);
		item = this._getAvailableCellByPoint(oriPoint);
	}
	if (item !== undefined)
	{
		this._moveFocusToItem(item, oriPoint, this.nAniTimePageMove);
		return true;
	}
	else
	{
		return false;
	}
}

function rgcPageRight(nMoveValue)
{
	if (this.m_timerAni !== undefined)
	{
		return false;
	}

	if (!this.m_bEnable)
	{
		return;
	}
////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Can not globally expand clone function for all Object, it's dangerous.
    //var oriPoint = this.m_oriPoint.clone();
    var oriPoint = _clone(this.m_oriPoint);
// End Update    
////////////////////////////////////////////////////////////////////////////////


	var item = undefined;
	var sizeContent = this.getContentViewSize();

	if (nMoveValue !== undefined)
	{
		oriPoint.x = Math.min(oriPoint.x + nMoveValue, sizeContent.width - this.width);

		var pt = this.m_itemFocus.logPosition;
		var nUpCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1);
		var nDownCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1) + 1;
		var nStartCol = pt.x + this.m_itemFocus.logSize.width;
		item = this._getItemInMap(nStartCol, nUpCursor);

		if (item === undefined)
		{
			for (var nCol = nStartCol; nCol < this.m_mapObj.width; ++nCol)
			{
				while (nUpCursor >= 0 || nDownCursor < this.m_mapObj.height)
				{
					item = this._getItemInMap(nCol, nUpCursor);
					if (item !== undefined)
					{
						break;
					}
					item = this._getItemInMap(nCol, nDownCursor);
					if (item !== undefined)
					{
						break;
					}
					
					--nUpCursor;
					++nDownCursor;
				}
				if (item !== undefined)
				{
					break;
				}
			}
		}

		if (item === undefined)
		{
			item = this.m_itemFocus;
		}
	}
	else
	{
		oriPoint.x = Math.min(oriPoint.x + this.width, sizeContent.width - this.width);
		item = this._getAvailableCellByPoint(oriPoint);
	}
	if (item !== undefined)
	{
		this._moveFocusToItem(item, oriPoint, this.nAniTimePageMove);
		return true;
	}
	else
	{
		return false;
	}
}

function rgcGetAvailableCellByPoint(oriPoint)
{
	var nColStart = Math.ceil(oriPoint.x / this.m_itemSize.width);
	var nRowStart = Math.ceil(oriPoint.y / this.m_itemSize.height);
	var nColEnd = Math.floor((oriPoint.x + this.width) / this.m_itemSize.width);
	var nRowEnd = Math.floor((oriPoint.y + this.height) / this.m_itemSize.height);

	for (var nRowIndex = nRowStart; nRowIndex < nRowEnd; ++nRowIndex)
	{
		for (var nColIndex = nColStart; nColIndex < nColEnd; ++nColIndex)
		{
			var item = this._getItemInMap(nColIndex, nRowIndex);
			if (item !== undefined)
			{
				if (item.logPosition.x == nColIndex
				&& item.logPosition.y == nRowIndex)
				{
					
					return item;
				}
			}
		}
	}
	return undefined;
}

function rgcGetWidget(index)
{
	if (index >= 0 && index < this.m_arrItems.length)
	{
		return this.m_arrItems[index].widget;
	}
	else
	{
		return undefined;
	}
}

function rgcUpdateItem(index, param)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}

	if (!this.m_bEnable)
	{
		return;
	}
	var item = this._getItemByIndex(index);
	if (item !== undefined && item.widget !== undefined)
	{
		this.ifItemUpdate(item.nItemIndex, item.widget, item.strId, param);
	}
}

function rgcUpdateAllItems(param)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}

	if (!this.m_bEnable)
	{
		return;
	}
	for (var i = 0; i < this.m_arrItems.length; ++i)
	{
		var item = this.m_arrItems[i];
		if (item.widget !== undefined)
		{
			this.ifItemUpdate(item.nItemIndex, item.widget, item.strId, param);
		}
	}
}

function rgcRealItemScale(item)
{
	if (item.scale !== undefined)
	{
		return item.scale;
	}
	else
	{
		return this.itemScale;
	}
}

function rgcSetFocusIndex(index)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}
	if (!this.m_bEnable)
	{
		return;
	}
	assert(index !== undefined);
	var item = this._getItemByIndex(index);
	if (item !== undefined)
	{
		this._moveFocusToItem(item);
	}
}

function rgcGetContentViewSize()
{
	var size = {};
	size.width = this.m_nRealCols * this.m_itemSize.width;
	size.height = this.m_nRealRows * this.m_itemSize.height;
	return size;
}

function rgcCalcFocusItemPos(item, oriPoint)
{
	oriPoint = defaultValue(oriPoint, this.m_oriPoint);
	var xOri = item.logPosition.x * this.m_itemSize.width;
	var yOri = item.logPosition.y * this.m_itemSize.height;
    var nWidth = item.logSize.width * this.m_itemSize.width;
	var nHeight = item.logSize.height * this.m_itemSize.height;
	var nWidthScale = nWidth * this._realItemScale(item).x;
	var nHeightScale = nHeight * this._realItemScale(item).y;
 
	var nWidthExtend = (nWidthScale - nWidth) / 2;
	var nHeightExtend = (nHeightScale - nHeight) / 2;

	var nLeft = xOri - nWidthExtend;
	var nTop = yOri - nHeightExtend;
	var nLeftPre = nLeft;
	var nTopPre = nTop;
    item.widget.pivot = {x:0.5, y:0.5};

	if (!this.alwaysScaleFromCenter)
	{
		if (nLeft < oriPoint.x)
		{
			nLeft = oriPoint.x;
			item.widget.pivot.x = 0;
		}
		else if (nLeft + nWidthScale >oriPoint.x + this.width)
		{
			nLeft = oriPoint.x + this.width - nWidthScale; 
			item.widget.pivot.x = 1;
		}
		else
		{
			//do nothing
		}

		if (nTop + nHeightScale > oriPoint.y + this.height)
		{
			nTop = oriPoint.y + this.height - nHeightScale;
			item.widget.pivot.y = 1;
		}
		else if (nTop < oriPoint.y)
		{
			nTop = oriPoint.y;
			item.widget.pivot.y = 0;
		}
		else
		{
			//do nothing
		}
	}

	var xOriAfter = xOri + (nLeft - nLeftPre) / this._realItemScale(item).x;
	var yOriAfter = yOri + (nTop - nTopPre) / this._realItemScale(item).y;
	
	return {x:xOri, y:yOri, xCorrect:xOriAfter, yCorrect:yOriAfter};
}

function rgcReleaseList()
{
	if (this.m_timerAni !== undefined)
	{
		Volt.clearTimeout(this.m_timerAni);
		this.m_timerAni = undefined;
	}

	if (this.m_timerPress !== undefined)
	{
		Volt.clearTimeout(this.m_timerPress);
		this.m_timerPress = undefined;
	}
	this._releaseAllItems();
	this.m_mapObj.releaseMap();
	if (this.m_objFocus !== undefined)
	{
		this.m_objFocus.parent.removeChild(this.m_objFocus);
		this.m_objFocus.destroy();
		this.m_objFocus = undefined;
	}
    this.destroy();
}

function rgcAddSubView(view, index)
{
	//view.y += this.height / 4;
	this.m_wList.addChild(view, index);
}

function rgcGetItemByIndex(index)
{
	//for (var i = 0; i < this.m_arrItems.length; ++i)
	//{
	//	var item = this.m_arrItems[i];
	//	if (item.nItemIndex == index)
	//	{
	//		return item;
	//	}
	//}
	//return undefined;

	if (index < 0 || index >= this.m_arrItems.length)
	{
		return undefined;
	}
	else
	{
		return this.m_arrItems[index];
	}
}

function rgcGetFocusIndex()
{
	if (this.m_itemFocus === undefined)
	{
		return -1;
	}
	else
	{
		return this.m_itemFocus.nItemIndex;
	}
}

function rgcSetFocus()
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}

	if (!this.m_bFocus)
	{
		this.m_bFocus = true;
		this.ifGetFocus();
	}

	if (this.m_objFocus !== undefined)
	{
		this.m_objFocus.show();
	}

    var nFocusIndex = this.getFocusIndex();
	
	if (nFocusIndex < 0)
	{
		nFocusIndex = 0;
	}


	this.setFocusIndex(nFocusIndex);

	//if (this.m_objShadow !== undefined)
	//{
	//	this.m_objShadow.color.a = 50;
	//}

}

function rgcKillFocus(bAnimate)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}

	bAnimate = defaultValue(bAnimate, true);
	this.m_bFocus = false;
	if (this.m_objFocus !== undefined)
	{
		this.m_objFocus.hide();
	}

	if (this.m_itemFocus !== undefined && this.m_itemFocus.widget !== undefined)
	{
		//this.m_itemFocus.widget.depth = 0;

		if (bAnimate)
		{
			this.m_itemFocus.widget.animate("scale", {x:1,y:1}, this.nAniTimeScale);
		}
		else
		{
			this.m_itemFocus.widget.scale = {x:1,y:1};
		}
		this.m_itemFocus.widget.shadow = null;
	}

	//if (this.m_objShadow !== undefined)
	//{
	//	if (this.m_objShadow.aniHandle !== undefined)
 //       {
	//		this.m_objShadow.aniHandle.cancel();
	//		delete this.m_objShadow.aniHandle;
 //       }
	//	this.m_objShadow.color.a = 0;
	//}

	
	if (this.focusMode === this.FOCUS_MODE_3D && this.m_itemFocus !== undefined)
	{
		var xOri = this.m_itemFocus.logPosition.x * this.m_itemSize.width;
		var yOri = this.m_itemFocus.logPosition.y * this.m_itemSize.height;

		if (bAnimate)
		{
			this.m_itemFocus.widget.animate("x", xOri, this.nAniTimeScale);
			this.m_itemFocus.widget.animate("y", yOri, this.nAniTimeScale);
			this.m_itemFocus.widget.animate("rotation.x", 0, this.nAniTimeScale);
			this.m_itemFocus.widget.animate("rotation.y", 0, this.nAniTimeScale);
		}
		else
		{
			this.m_itemFocus.widget.x = xOri;
			this.m_itemFocus.widget.y = yOri;
			this.m_itemFocus.widget.rotation.x = 0;
			this.m_itemFocus.widget.rotation.y = 0;
		}
	}

	this.ifLoseFocus();
}

function timerPress(parent)
{
	parent.m_timerPress = undefined;
	parent.ifItemLongPress(parent.m_itemFocus.nItemIndex, parent.m_itemFocus.widget, parent.m_itemFocus.strId);
}

function rgcHandleKey(keyCode, type)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}
	
	if (!this.m_bEnable)
	{
		return;
	}
	if (this.m_itemFocus === undefined || !this.m_bFocus)
	{
		return false;
	}

	if (type == Volt.EVENT_KEY_PRESS && keyCode == Volt.KEY_JOYSTICK_OK)
	{
		if (this.m_timerPress !== undefined)
		{
			Volt.clearTimeout(this.m_timerPress);
			this.m_timerPress = undefined;
		}
		
		this.m_timerPress = Volt.setTimeout(timerPress, 2000, this);
		return true;
	}

	
	if (type == Volt.EVENT_KEY_RELEASE && keyCode == Volt.KEY_JOYSTICK_OK)
	{
		if (this.m_timerPress !== undefined)
		{
			Volt.clearTimeout(this.m_timerPress);
			this.m_timerPress = undefined;
			return this._onPressItem();
		}
		return false;
	}

	var nCurTime = (new Date).getTime();
	var nInterval = nCurTime - this.m_nPreTickCount;

	if (nInterval > 80)
	{
		this.m_nPreTickCount = nCurTime;
	}
	else
	{
		return;
	}
	
	//assert(false, key);
	if (type == Volt.EVENT_KEY_PRESS)
	{
		if (keyCode == Volt.KEY_JOYSTICK_LEFT)
		{
			return this._onKeyLeft();
		}
		else if (keyCode == Volt.KEY_JOYSTICK_RIGHT)
		{
			return this._onKeyRight();
		} 
		else if (keyCode == Volt.KEY_JOYSTICK_UP)
		{
			return this._onKeyUp();
		} 
		else if (keyCode == Volt.KEY_JOYSTICK_DOWN)
		{
			return this._onKeyDown();
		}  
		else
		{
			return false;
		}
	}
	
	return true;
}
function rgcOnKeyDown()
{
	var pt = this.m_itemFocus.logPosition;
	var nLeftCursor = pt.x + Math.floor(this.m_itemFocus.logSize.width / 2.1);
	var nRightCursor = pt.x + Math.floor(this.m_itemFocus.logSize.width / 2.1) + 1;
	var item = undefined;
	for (var nRow = pt.y + this.m_itemFocus.logSize.height; nRow < this.m_mapObj.height; ++nRow)
	{
		while (nLeftCursor >= 0 || nRightCursor < this.m_mapObj.width)
		{
			item = this._getItemInMap(nLeftCursor, nRow);
			if (item !== undefined)
			{
				break;
			}
			item = this._getItemInMap(nRightCursor, nRow);
			if (item !== undefined)
			{
				break;
			}
			
			--nLeftCursor;
			++nRightCursor;
		}
		if (item !== undefined)
		{
			break;
		}
	}
	
	if (item !== undefined)
	{
		this._moveFocusToItem(item);
		return true;
	}
	else
	{
		this.ifMoveOut(this.MOVE_OUT_DIR_DOWN);
		return this.MOVE_OUT_DIR_DOWN;
	}
}

function rgcOnKeyUp()
{
	var pt = this.m_itemFocus.logPosition;
	var nLeftCursor = pt.x + Math.floor(this.m_itemFocus.logSize.width / 2.1);
	var nRightCursor = pt.x + Math.floor(this.m_itemFocus.logSize.width / 2.1) + 1;
	var item = undefined;
	for (var nRow = pt.y - 1; nRow >= 0; --nRow)
	{
		while (nLeftCursor >= 0 || nRightCursor < this.m_mapObj.width)
		{
			item = this._getItemInMap(nLeftCursor, nRow);
			if (item !== undefined)
			{
				break;
			}
			item = this._getItemInMap(nRightCursor, nRow);
			if (item !== undefined)
			{
				break;
			}
			
			--nLeftCursor;
			++nRightCursor;
		}
		if (item !== undefined)
		{
			break;
		}
	}
	
	if (item !== undefined)
	{
		this._moveFocusToItem(item);
		return true;
	}
	else
	{
		this.ifMoveOut(this.MOVE_OUT_DIR_UP);
		return this.MOVE_OUT_DIR_UP;
	}
}

function rgcOnKeyLeft()
{
	var pt = this.m_itemFocus.logPosition;
	var nUpCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1);
	var nDownCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1) + 1;
	var nStartCol = pt.x - 1;
	var item = this._getItemInMap(nStartCol, nUpCursor);

	if (item === undefined)
	{
		for (var nCol = nStartCol; nCol >= 0; --nCol)
		{
			while (nUpCursor >= 0 || nDownCursor < this.m_mapObj.height)
			{
				item = this._getItemInMap(nCol, nUpCursor);
				if (item !== undefined)
				{
					break;
				}
				item = this._getItemInMap(nCol, nDownCursor);
				if (item !== undefined)
				{
					break;
				}
				
				--nUpCursor;
				++nDownCursor;
			}
			if (item !== undefined)
			{
				break;
			}
		}
	}
	
	if (item !== undefined)
	{
		this._moveFocusToItem(item);
		return true;
	}
	else
	{
		this.ifMoveOut(this.MOVE_OUT_DIR_LEFT);
		return this.MOVE_OUT_DIR_LEFT;
	}
	return true;
}

function rgcOnPressItem()
{
	if (this.m_itemFocus === undefined)
	{
		this.ifItemPress(-1);
	}
	else
	{
		this.ifItemPress(this.m_itemFocus.nItemIndex, this.m_itemFocus.widget, this.m_itemFocus.strId);
	}
}

function rgcOnKeyRight()
{
	var pt = this.m_itemFocus.logPosition;
	var nUpCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1);
	var nDownCursor = pt.y + Math.floor(this.m_itemFocus.logSize.height / 2.1) + 1;
	var nStartCol = pt.x + this.m_itemFocus.logSize.width;
	var item = this._getItemInMap(nStartCol, nUpCursor);

	if (item === undefined)
	{
		for (var nCol = nStartCol; nCol < this.m_mapObj.width; ++nCol)
		{
			while (nUpCursor >= 0 || nDownCursor < this.m_mapObj.height)
			{
				item = this._getItemInMap(nCol, nUpCursor);
				if (item !== undefined)
				{
					break;
				}
				item = this._getItemInMap(nCol, nDownCursor);
				if (item !== undefined)
				{
					break;
				}
				
				--nUpCursor;
				++nDownCursor;
			}
			if (item !== undefined)
			{
				break;
			}
		}
	}
	
	if (item !== undefined)
	{
		this._moveFocusToItem(item);
		return true;
	}
	else
	{
		this.ifMoveOut(this.MOVE_OUT_DIR_RIGHT);
		return this.MOVE_OUT_DIR_RIGHT;
	}
}

function rgcGetVisibleItems(nTop, nLeft, nBottom, nRight)
{
	//TestPrint(nTop + "," + nLeft + "," + nBottom + "," + nRight);
    var vecItems = [];
	for (var i = 0; i < this.m_arrItems.length; ++i)
	{
		var item = this.m_arrItems[i];
		var nBeginPosX = item.logPosition.x * this.m_itemSize.width;
		var nEndPosX = (item.logPosition.x + item.logSize.width) * this.m_itemSize.width;
		var nBeginPosY = item.logPosition.y * this.m_itemSize.height;
		var nEndPosY = (item.logPosition.y + item.logSize.height) * this.m_itemSize.height;
		if (((nBeginPosX >= nLeft && nBeginPosX <= nRight)
			|| (nEndPosX >= nLeft && nEndPosX <= nRight))
			&& ((nBeginPosY >= nTop && nBeginPosY <= nBottom)
			|| (nEndPosY >= nTop && nEndPosY <= nBottom)))
		{
			//TestPrint("Info:" + item.nItemIndex + "  " + nBeginPosX + "," + nEndPosX + "," + nBeginPosY + "," + nEndPosY);
			vecItems.push(item);
		}
	}

 //   var strLog = "Get visible:";
	//for (var i = 0; i < vecItems.length; ++i)
	//{
	//	strLog += vecItems[i].nItemIndex +",";
	//}
	//TestPrint(strLog);
	return vecItems;
}

function cancelAllAnimation(arr)
{
	for (var i = 0; i < arr.length; ++i)
	{
		var item = arr[i];
		if (item.widget !== undefined && item.arrAnis.length > 0)
		{
			for (var nAniIndex = 0; nAniIndex < item.arrAnis.length; ++nAniIndex)
			{
				var hAni = item.arrAnis[nAniIndex];
				hAni.jump(1);
			}
			item.arrAnis = [];
		}
	}
}

var nMoveCount = 0;
function rgcOnItemMouseMove(index, x, y)
{
	var item = this._getItemByIndex(index);

	if (item !== this.m_itemFocus)
	{
		this._moveFocusToItem(item, undefined, 0);
	}
	if (this.focusMode == this.FOCUS_MODE_3D)
	{
		if (nMoveCount == 3)
		{
			nMoveCount = 0;
		}
		else
		{
			++nMoveCount;
		}
		var pos = item.widget.getAbsolutePosition();
		var xCorrect = x - pos.x + item.widget.width * (this._realItemScale(item).x - 1) / 2;
		var yCorrect = y - pos.y + item.widget.height * (this._realItemScale(item).y - 1) / 2;
		var xOffset = item.widget.width * this._realItemScale(item).x / 2 - xCorrect;
		var yOffset = item.widget.height * this._realItemScale(item).y / 2 - yCorrect;

		//var aniMove = new Animation(this.nAniTimeScale);
        var oriItem = this._calcFocusItemPos(item);
		//var xOri = item.logPosition.x * this.m_itemSize.width;
		//var yOri = item.logPosition.y * this.m_itemSize.height;

		var flagX = 1;
		var flagY = 1;
		if (xOffset < 0)
		{
			flagX = -1;
		}

		if (yOffset < 0)
		{
			flagY = -1;
		}

        var factorX = Math.sqrt(Math.abs(xOffset) * 1.2) * flagX;
		var factorY = Math.sqrt(Math.abs(yOffset) * 1.2) * flagY;
		item.widget.x = oriItem.x - factorX;
		item.widget.y = oriItem.y - factorY;
		//if (this.m_objShadow !== undefined)
		//{
		//	this.m_objShadow.x = oriItem.xCorrect + 15 - factorX - item.logSize.width * this.m_itemSize.width * (this._realItemScale(item).x - 1) / 2;
		//	this.m_objShadow.y = oriItem.yCorrect + 15 - factorY - item.logSize.height * this.m_itemSize.height * (this._realItemScale(item).y - 1) / 2;
		//	this.m_objShadow.rotation.x = factorY / 4;
		//	this.m_objShadow.rotation.y = -factorX / 4;
		//}


		//item.widget.x = oriItem.x - xOffset / 8;
		//item.widget.y = oriItem.y - yOffset / 8;

		//TestPrint(Math.log(xOffset) + "," + xOffset);
		item.widget.rotation.x = factorY / 4;
		item.widget.rotation.y = -factorX / 4;
	}
	
}

function rgcOnItemMouseOut(index)
{
	if (this.focusMode == this.FOCUS_MODE_3D)
	{
		var item = this._getItemByIndex(index);
		var oriPoint = this._calcFocusItemPos(item);

		item.widget.animate("x", oriPoint.x, this.nAniTimeScale);
		item.widget.animate("y", oriPoint.y, this.nAniTimeScale);
		item.widget.animate("rotation.x", 0, this.nAniTimeScale);
		item.widget.animate("rotation.y", 0, this.nAniTimeScale);

		//if (this.m_objShadow !== undefined)
		//{
		//	var nShadowX = oriPoint.xCorrect + 15 - item.logSize.width * this.m_itemSize.width * (this._realItemScale(item).x - 1) / 2;
		//	var nShadowY = oriPoint.yCorrect + 15 - item.logSize.height * this.m_itemSize.height * (this._realItemScale(item).y - 1) / 2;

  //          if (this.m_objShadow.aniHandle !== undefined)
  //          {
		//		this.m_objShadow.aniHandle.cancel();
		//		delete this.m_objShadow.aniHandle;
  //          }
		//	var ani = new Animation(this.nAniTimeScale);
		//	ani.addProperty("x", nShadowX);
		//	ani.addProperty("y", nShadowY);
		//	ani.addProperty("rotation.x", 0);
		//	ani.addProperty("rotation.y", 0);
		//	this.m_objShadow.aniHandle = this.m_objShadow.animate(ani);
		//}
	}
}

function getMainParent(widget)
{
	if (widget.parent.ID == "focusBg")
	{
		//TestPrint("focusBg");
		return widget.parent.parent;
	}
	else if (widget.parent.ID == "listBg")
	{
		//TestPrint("listBg");
		return widget.parent.parent.parent;
	}
	else
	{
		assert(false);
	}
}

function rgcConfigMouseEvent(widget)
{
	widget.addEventListener("OnMouseClick", function(targetWidget, eventData)
	{
		var parent = getMainParent(targetWidget);
		if (parent !== undefined)
		{
			if (parent.m_timerAni !== undefined)
			{
				return;
			}
			if (!parent.m_bEnable)
			{
				return;
			}
			parent.ifItemPress(targetWidget.index, targetWidget, parent._getItemByIndex(targetWidget.index).strId);
		}
	});

	widget.addEventListener("OnMouseOver", function(targetWidget, eventData)
	{
		var parent = getMainParent(targetWidget);
		if (parent !== undefined)
		{
			if (parent.m_timerAni !== undefined)
			{
				return;
			}
			if (!parent.m_bEnable)
			{
				return;
			}
			parent._moveFocusToItem(parent._getItemByIndex(targetWidget.index), undefined, 0);
		}
	});

	widget.addEventListener("OnMouseOut", function(targetWidget, eventData)
	{
		var parent = getMainParent(targetWidget);
		if (parent !== undefined)
		{
			if (parent.m_timerAni !== undefined)
			{
				return;
			}
			if (!parent.m_bEnable)
			{
				return;
			}
			parent._onItemMouseOut(targetWidget.index);
		}
	});

	widget.addEventListener("OnMouseMove", function(targetWidget, eventData)
	{
		var parent = getMainParent(targetWidget);
		if (parent !== undefined)
		{
			if (parent.m_timerAni !== undefined)
			{
				return;
			}
			if (!parent.m_bEnable)
			{
				return;
			}
			parent._onItemMouseMove(targetWidget.index, eventData.coordinates.x, eventData.coordinates.y);
		}
	});

}

function rgcDestroyUnloadItems(bStrict)
{
	//var strLog = "destroy items:";

    bStrict = defaultValue(bStrict, false);

    var nLimitLeft = 0;
	var nLimitRight = 0;
	var nLimitTop = 0;
	var nLimitBot = 0;
	if (bStrict)
	{
		nLimitLeft = this.m_oriPoint.x;
		nLimitRight = this.m_oriPoint.x + this.width;
		nLimitTop = this.m_oriPoint.y;
		nLimitBot = this.m_oriPoint.y + this.height;
	}
	else
	{
		nLimitLeft = this.m_oriPoint.x - this.width / 2;
		nLimitRight = this.m_oriPoint.x + 1.5 * this.width;
		nLimitTop = this.m_oriPoint.y - this.height / 2;
		nLimitBot = this.m_oriPoint.y + this.height * 1.5;
	}
	//var nLimitTop = this.m_oriPoint.y;
	//var nLimitBottom = this.m_oriPoint.y + this.height;

	for (var i = 0; i < this.m_arrItems.length; ++i)
	{
		var item = this.m_arrItems[i];
		var itemPosX = item.logPosition.x * this.m_itemSize.width;
		var itemPosY = item.logPosition.y * this.m_itemSize.height;
		//var itemPosY = item.logPosition.y * this.m_itemSize.height;
		var itemEndX = (item.logPosition.x + item.logSize.width) * this.m_itemSize.width;
		var itemEndY = (item.logPosition.y + item.logSize.height) * this.m_itemSize.height;
		//var itemWidth = item.logSize.width * this.m_itemSize.width;
		//var itemEndY = (item.logPosition.x + item.logSize.width) * this.m_itemSize.height;
		if (item.widget !== undefined
			&& (itemPosX > nLimitRight
			|| itemEndX < nLimitLeft - this.m_itemSize.width * item.logSize.width
			|| itemPosY > nLimitBot
			|| itemEndY < nLimitTop - this.m_itemSize.height * item.logSize.height))
		{
			//item.releaseItem();
			//strLog += item.nItemIndex + ",";

			
			this.m_wList.removeChild(item.widget);
			this.m_arrReuseableWidget.push(item.widget);
			item.widget = undefined;
		}
	}
	//TestPrint(strLog);
}

function rgcNormalizeWidget(widget, reuseID)
{
	widget.getChildById = getChildById;
	widget.reuseableId = reuseID;
	this._configMouseEvent(widget);
}

function rgcUpdateView(oriPoint, objFocus, nAniTime)
{
	if (this.m_arrItems.length == 0)
	{
		return;
	}

    if (this.m_nAniTimeMove == 0)
    {
		bAnimate = false;
    }
    nAniTime = defaultValue(nAniTime, this.nAniTimeMove);	
    oriPoint = defaultValue(oriPoint, this.m_oriPoint);
    //objFocus = objFocus || this.m_objFocus;
	//this._destroyUnloadItems();

	//cancelAllAnimation(this.m_arrItems);
	var vecInvolved = [];

	var nMinPosX = Math.min(this.m_oriPoint.x, oriPoint.x);
	var nMaxPosX = Math.max(this.m_oriPoint.x, oriPoint.x);
	var nMinPosY = Math.min(this.m_oriPoint.y, oriPoint.y);
	var nMaxPosY = Math.max(this.m_oriPoint.y, oriPoint.y);

	if (this.m_bInitSetItem === true)
	{
		vecInvolved = this._getVisibleItems(nMinPosY, nMinPosX, nMaxPosY + this.height * 1.5, nMaxPosX + this.width * 1.5);
		
	}
	else
	{
		vecInvolved = this._getVisibleItems(nMinPosY, nMinPosX, nMaxPosY + this.height - 1, nMaxPosX + this.width - 1);
	}


	if (this.m_wList.x !== (-this.m_oriPoint.x + this.m_visibleAreaExtend.l))
    {
		//TestPrint("this.m_wList.x !== oriPoint.x");
		//nAniTime = 0;
		if (this.m_wList.aniHandle !== undefined)
		{
			this.m_wList.aniHandle.cancel();
		}
		this.m_wList.x = -this.m_oriPoint.x + this.m_visibleAreaExtend.l;
		
    }

	if (this.m_wList.y !== (-this.m_oriPoint.y + this.m_visibleAreaExtend.t))
    {
		//TestPrint("this.m_wList.x !== oriPoint.x");
		//nAniTime = 0;
		if (this.m_wList.aniHandle !== undefined)
		{
			this.m_wList.aniHandle.cancel();
		}
		this.m_wList.y = -this.m_oriPoint.y + this.m_visibleAreaExtend.t;
		
    }

	for (var i = 0; i < vecInvolved.length; ++i)
	{
		var item = vecInvolved[i]; 
		item.bInvolved = true;

		if (item.widget === undefined)
		{
			item.widget = this.ifItemLoaded(item.nItemIndex,
				item.logSize.width * this.m_itemSize.width,
				item.logSize.height * this.m_itemSize.height, item.strId);

            
			assert(item.widget !== undefined, "ifItemLoaded must return a widget!");
			
			item.widget.x = item.logPosition.x * this.m_itemSize.width;
			item.widget.y = item.logPosition.y * this.m_itemSize.height;

			item.widget.index = item.nItemIndex;
			this.m_wList.addChild(item.widget);

            
			
		}	
	}
	
	if (nAniTime <= 0)
	{
		

		this.m_wList.x = -oriPoint.x + this.m_visibleAreaExtend.l;
		this.m_wList.y = -oriPoint.y + this.m_visibleAreaExtend.t;

		//if (this._needOptimseFocusItem())
		//{
		//	this.m_wFocusBg.x = -oriPoint.x;
		//	this.m_wFocusBg.y = -oriPoint.y;
		//}

        if (objFocus !== undefined)
        {
        	this._updateFocusItem(objFocus, oriPoint, false);
        }
	}
    else
    { 
		if (objFocus !== undefined)
        {
        	this._updateFocusItem(objFocus, oriPoint, true, undefined);
        }

        if (this.m_wList.aniHandle !== undefined)
        {
			delete this.m_wList.aniHandle;
        }
		var ani = new Animation(nAniTime);
		ani.addProperty("x", -oriPoint.x + this.m_visibleAreaExtend.l);
		ani.addProperty("y", -oriPoint.y + this.m_visibleAreaExtend.t);
		this.m_wList.aniHandle = this.m_wList.animate(ani);

		//if (this._needOptimseFocusItem())
		//{
		//	this.m_wFocusBg.animate("x", -oriPoint.x, nAniTime);
		//	this.m_wFocusBg.animate("y", -oriPoint.y, nAniTime);
		//}

    }

	
	this.m_oriPoint = oriPoint;
	this.ifScroll();

	if (true === this.m_bInitSetItem)
	{
		this._destroyUnloadItems(true);
		delete this.m_bInitSetItem;
	}
	else
	{
		for (var i = 0; i < this.m_arrItems.length; ++i)
		{
			var item = this.m_arrItems[i];
			if (item.bInvolved === true)
			{
				delete item.bInvolved;
			}
			else
			{
				if (item.widget !== undefined)
				{
					this.m_wList.removeChild(item.widget);
					this.m_arrReuseableWidget.push(item.widget);
					item.widget = undefined;
				}
			}
		}
		
	}
}

function rgcNeedOptimseFocusItem()
{
	return this.focusMode == this.FOCUS_MODE_3D;
}

function rgcUpdateFocusItem(objItem, oriPoint, bAnimate, aniTime)
{
	bAnimate = defaultValue(bAnimate, true);
	var nAniTime = 0;
	if (!bAnimate)
	{
		nAniTime = 0;
	}
	else
	{
		nAniTime = defaultValue(aniTime, this.nAniTimeMove);
	}

	if (this.m_itemFocus !== undefined && this.m_itemFocus.widget !== undefined)
	{
		//this.m_itemFocus.widget.depth = 0;

		//if (this._needOptimseFocusItem())
		//{
		//	this.m_wFocusBg.removeChild(this.m_itemFocus.widget);
		//	this.m_wList.addChild(this.m_itemFocus.widget);
		//}

        this.m_itemFocus.widget.shadow = null;

        var xOri = this.m_itemFocus.logPosition.x * this.m_itemSize.width;
		var yOri = this.m_itemFocus.logPosition.y * this.m_itemSize.height;
		if (bAnimate)
		{
			this.m_itemFocus.widget.animate("scale", {x:1,y:1}, this.nAniTimeScale);


			this.m_itemFocus.widget.animate("x", xOri, this.nAniTimeScale);
			this.m_itemFocus.widget.animate("y", yOri, this.nAniTimeScale);
		}
		else
		{
			this.m_itemFocus.widget.x = xOri;
			this.m_itemFocus.widget.y = yOri;
			this.m_itemFocus.widget.scale = {x:1,y:1};
		}
		

		
		if (this.focusMode == this.FOCUS_MODE_3D)
		{
			
			this.m_itemFocus.widget.shadow = null;

			if (bAnimate)
			{
				this.m_itemFocus.widget.animate("rotation.x", 0, this.nAniTimeScale);
				this.m_itemFocus.widget.animate("rotation.y", 0, this.nAniTimeScale);
			}
			else
			{
				this.m_itemFocus.widget.rotation.x = 0;
				this.m_itemFocus.widget.rotation.y = 0;
			}
		}
		
	}

	if (objItem !== undefined && objItem.widget !== undefined)
	{
		//objItem.widget.depth = 0.08;

		//if (this._needOptimseFocusItem())
		//{
		//	this.m_wList.removeChild(objItem.widget);
		//	this.m_wFocusBg.addChild(objItem.widget);
		//}
		//else
		{
			
			

			//if (this.m_objShadow !== undefined)
			//{
			//	this.m_wList.removeChild(this.m_objShadow);
			//	this.m_wList.addChild(this.m_objShadow);
			//}

			this.m_wList.removeChild(objItem.widget);
			this.m_wList.addChild(objItem.widget);
			
		}

		if (this.focusMode == this.FOCUS_MODE_3D)
		{
			objItem.widget.color.a = 255;

			var xOffset = 0;
			var yOffset = 0;

			if (objItem.widget.x + objItem.widget.width / 2 - this.m_oriPoint.x > this.width / 2)
			{
				xOffset = -15;
			}
			else
			{
				xOffset = 15;
			}

			if (objItem.widget.y + objItem.widget.height / 2 - this.m_oriPoint.y > this.height / 2)
			{
				yOffset = -15;
			}
			else
			{
				yOffset = 15;
			}
			objItem.widget.shadow = { 
			   xOffset: xOffset, 
			   yOffset: yOffset, 
			   blur: 5, 
			   spread:0, 
			   color: {r:0, g:0, b:0, a:150} 
			};
		}

		oriPoint = defaultValue(oriPoint, this.m_oriPoint);
		var oriItem = this._calcFocusItemPos(objItem, oriPoint);
		//TestPrint("result:" + oriItem.x + "," + oriItem.y + "," + objItem.widget.x + "," + objItem.widget.y);
		//objItem.widget.x = oriItem.x;
		//objItem.widget.y = oriItem.y;
       
		//aniGroup.addAnim(objItem.widget, "x", oriItem.x, this.nAniTimeScale);
		//aniGroup.addAnim(objItem.widget, "y", oriItem.y, this.nAniTimeScale);

		if (bAnimate)
		{
			objItem.widget.animate("scale", this._realItemScale(objItem), this.nAniTimeScale);
		}
		else
		{
			objItem.widget.scale = this._realItemScale(objItem);
		}
		//objItem.widget, "scale.y", this._realItemScale(objItem).y, this.nAniTimeScale);

		//if (objItem !== undefined && this.m_objShadow !== undefined)
		//{
		//	if (this.m_objShadow.aniHandle !== undefined)
  //          {
		//		this.m_objShadow.aniHandle.cancel();
		//		delete this.m_objShadow.aniHandle;
  //          }
		//	
		//	this.m_objShadow.x = oriItem.xCorrect + 15 - objItem.logSize.width * this.m_itemSize.width * (this._realItemScale(objItem).x - 1) / 2;
		//	this.m_objShadow.y = oriItem.yCorrect + 15 - objItem.logSize.height * this.m_itemSize.height * (this._realItemScale(objItem).y - 1) / 2;
		//	this.m_objShadow.width = objItem.widget.width;
		//	this.m_objShadow.height = objItem.widget.height;
		//	this.m_objShadow.color.a = 0;
		//	this.m_objShadow.rotation.x = 0;
		//	this.m_objShadow.rotation.y = 0;
		//	this.m_objShadow.color.a = 50;
		//	this.m_objShadow.width = objItem.widget.width * this._realItemScale(objItem).x;
		//	this.m_objShadow.height = objItem.widget.height * this._realItemScale(objItem).y;

		//	//var ani = new Animation(this.nAniTimeScale);
		//	//ani.addProperty("color.a", 50);
		//	//ani.addProperty("width", objItem.widget.width * this._realItemScale(objItem).x);
		//	//ani.addProperty("height", objItem.widget.height * this._realItemScale(objItem).y);

		//	//this.m_objShadow.aniHandle = aniGroup.addAnim(this.m_objShadow, ani);
		//}
		if (this.focusMode == this.FOCUS_MODE_NORMAL)
		{
			var rc = {};
			rc.x = oriItem.xCorrect - oriPoint.x + 5 + this.focusMargin.x
				- objItem.logSize.width * this.m_itemSize.width * (this._realItemScale(objItem).x - 1) / 2;
			rc.y = oriItem.yCorrect - oriPoint.y + 5 + this.focusMargin.y
				- objItem.logSize.height * this.m_itemSize.height * (this._realItemScale(objItem).y - 1) / 2;
			rc.w = objItem.logSize.width * this.m_itemSize.width * this._realItemScale(objItem).x - 10 + this.focusMargin.w;
			rc.h = objItem.logSize.height * this.m_itemSize.height * this._realItemScale(objItem).y - 10 + this.focusMargin.h;
			if (this.m_objFocus === undefined)
			{
				assert(this.m_arrFocusImgs !== undefined, "must set focus image");
				this.m_objFocus = new Dynamic_Cursor(rc.x, rc.y, rc.w, rc.h, this, this.m_arrFocusImgs);
				this.m_objFocus.show();
				//this.m_objFocus.InstanceRoot.depth = 0.15;
			}
			else
			{
				this.m_objFocus.move(rc.x, rc.y, rc.w, rc.h, nAniTime);
			}
		}
	}
	
}

function rgcMakeFocusRectByItem(objItem, oriPoint)
{
	var rc = {};
	rc.x = (objItem.logPosition.x) * this.m_itemSize.width + 5 - oriPoint.x
		- objItem.logSize.width * this.m_itemSize.width * (this.itemScale.x - 1) / 2;
	rc.y = (objItem.logPosition.y) * this.m_itemSize.height - oriPoint.y + 5
		- objItem.logSize.height * this.m_itemSize.height * (this.itemScale.y - 1) / 2;
	rc.w = objItem.logSize.width * this.m_itemSize.width * this.itemScale.x - 10;
	rc.h = objItem.logSize.height * this.m_itemSize.height * this.itemScale.y - 10;

	return rc;
}

function rgcSetItems(arrItems, bAnimate)
{
	if (this.m_timerAni !== undefined)
	{
		return;
	}
	assert(arrItems !== undefined);
	assert(arrItems.length > 0);
	bAnimate = defaultValue(bAnimate, true);

	
	this._releaseAllItems();
	this.m_nCols = 0;
	this.m_oriPoint.x = 0;
	this.m_oriPoint.y = 0;
	this.m_itemFocus = undefined;
	this.m_nRealWidth = 0;
	this.m_nRealHeight = 0;
	this.m_mapObj.releaseMap();
	//if (this.m_objShadow !== undefined)
	//{
	//	this.m_objShadow.destroy();
	//	this.m_objShadow = undefined;
	//}
	if (this.focusMode == this.FOCUS_MODE_3D)
	{
		this.m_wListBase.cropOverflow = false;
		//this.m_objShadow = new Widget(
		//{
		//	x:0,
		//	y:0,
		//	width:0,
		//	height:0,
		//	color:{r:0,g:0,b:0,a:50},
		//	parent:this.m_wList
		//});
		//this.m_objShadow.show();
	}
	else
	{
		this.m_wListBase.cropOverflow = true;
	}
	
	for (var i = 0; i < arrItems.length; ++i)
	{
		var tmpItem = arrItems[i];
		var objItem = new CResizeableGridListItemObject();
		objItem.nItemIndex = i;
		objItem.logSize.width = tmpItem.width;
		objItem.logSize.height = tmpItem.height;
		if (tmpItem.scale !== undefined)
		{
			objItem.scale = tmpItem.scale;
		}

		if (tmpItem.id !== undefined)
		{
			objItem.strId = tmpItem.id;
		}
		this.m_nCols += objItem.logSize.width;
		this.m_arrItems.push(objItem);
	}
	this.m_arrItems.sort(function(a, b){return a.nItemIndex > b.nItemIndex ? 1 : -1;});
	this._buildLayout();

	//this.m_itemFocus = this.m_arrItems[0];
	this.m_bInitSetItem = true;
	this._updateView(this.m_oriPoint, undefined, 0);

	//this._moveFocusToItem(this.m_arrItems[0]);
}

function rgcBuildLayout()
{
	if (this.m_arrItems.length == 0)
	{
		this.m_mapObj.releaseMap();
		return;
	}
	
	this.m_mapObj.createMap(this.m_nCols, this.m_nDisplayRows);

	var nCol = 0;
	for (var i = 0; i < this.m_arrItems.length; ++i)
	{
		var item = this.m_arrItems[i];
		var nStartCol = 0;
		for (nStartCol = Math.max(0, nCol - Math.ceil(this.width / this.m_itemSize.width)); nStartCol < this.m_mapObj.width; ++nStartCol)
		{
			var bSet = false;
			for (var nRow = 0; nRow < this.m_mapObj.height; ++nRow)
			{
				var param = {
					x:nStartCol,
					y:nRow,
					width:item.logSize.width,
					height:item.logSize.height,
					value:item.nItemIndex
				};
				if (this.m_mapObj.setValue(param))
				{
					if (nStartCol > nCol)
					{
						nCol = nStartCol;
					}
					item.logPosition.x = param.x;
					item.logPosition.y = param.y;
					bSet = true;
					break;
				}
			}
			if (bSet)
			{
				break;
			}
		}
		
	}

    for (this.m_nRealRows = this.m_mapObj.height - 1; this.m_nRealRows >= 0; --this.m_nRealRows)
	{
		var nColIndex = 0;
		for (; nColIndex < this.m_mapObj.width; ++nColIndex)
		{
			if (this.m_mapObj.getValue({x:nColIndex, y:this.m_nRealRows}) != COMMON_DATA.EMPTY_CELL)
			{
				break;
			}
		}
		if (nColIndex < this.m_mapObj.width)
		{
			break;
		}
	}
	
	++this.m_nRealRows;
	
	for (this.m_nRealCols = this.m_mapObj.width - 1; this.m_nRealCols >= 0; --this.m_nRealCols)
	{
		var nRowIndex = 0;
		for (; nRowIndex < this.m_mapObj.height; ++nRowIndex)
		{
			if (this.m_mapObj.getValue({x:this.m_nRealCols, y:nRowIndex}) != COMMON_DATA.EMPTY_CELL)
			{
				break;
			}
		}
		if (nRowIndex < this.m_mapObj.height)
		{
			break;
		}
	}
	++this.m_nRealCols;
	//this.m_objFocus.show();
}

function rgcGetItemInMap(nX, nY)
{
	if (nX < 0 || nX >= this.m_mapObj.width || nY >= this.m_mapObj.height || nY < 0)
	{
		return undefined;
	}
	var nValue = this.m_mapObj.getValue({x:nX, y:nY});

	//for (var i = 0; i < this.m_arrItems.length; ++i)
	//{
	//	if (nValue == this.m_arrItems[i].nItemIndex)
	//	{
	//		return this.m_arrItems[i];
	//	}
	//}

	if (nValue < 0)
	{
		return undefined;
	}
	else
	{
		return this.m_arrItems[nValue];
	}
}

function rgcInit(param)
{ 
	var rows = param["rows"];
	var itemWidth = param["itemWidth"];
	var itemHeight = param["itemHeight"];
	var parent = param["parent"];
	var listWidth = param["width"];
	
	assert(listWidth !== undefined);

    this.x = defaultValue(param["x"], 0);
	this.y = defaultValue(param["y"], 0);
	this.m_visibleAreaExtend = defaultValue(param["visibleAreaExtend"], {l:0, t:0, b:0, r:0});
	this.m_mapObj = new CMapObject();
	this.m_nRealRows = 0;
	this.m_nRealCols = 0;
	this.m_bFocus = false;
	this.color.a = 0;
	this.m_bEnable = true;
	this.m_timerAni = undefined;
	this.m_timerPress = undefined;
	this.m_oriPoint = {x:0, y:0};
	this.m_arrItems = [];
	this.m_arrReuseableWidget = [];
	this.m_itemFocus = undefined;
	this.m_objFocus = undefined;
	this.m_nPreTickCount = 0;
	
	//this.m_objShadow = undefined;

	
	this.m_itemSize = {width:itemWidth, height:itemHeight};
	this.m_nCols = 0;

	if (parent !== undefined)
	{
		this.parent = parent;
	}

	if (itemHeight === undefined)
	{
		assert(param["height"] !== undefined);
		this.height = param["height"];
	}
	else
	{
		this.height = defaultValue(param["height"], rows * itemHeight);
	}
	
	this.width = listWidth;
	//this.m_nDisplayCols = Math.ceil(this.width / itemWidth);
	this.m_nDisplayRows = rows;
	this.m_wListBase = new Widget(
	{
		x:-this.m_visibleAreaExtend.l,
		y:-this.m_visibleAreaExtend.t,
		width:this.width + this.m_visibleAreaExtend.l + this.m_visibleAreaExtend.r,
		height:this.height + this.m_visibleAreaExtend.t + this.m_visibleAreaExtend.b,
		parent:this,
		color:{a:0},
		cropOverflow:false
	}
	);

	//this.m_wFocusBg = new Widget(
	//{
	//	x:0,
	//	y:0,
	//	width:this.width,
	//	height:this.height,
	//	parent:this,
	//	color:{a:0},
	//}
	//);

	//this.m_wFocusBg.ID = "focusBg";
	this.m_wList = new Widget(
		{
			x:this.m_visibleAreaExtend.l,
			y:this.m_visibleAreaExtend.t,
			width:this.width,
			height:this.height,
			parent:this.m_wListBase,
			color:{a:0},
			drawWithDepth:false
		}
	);

	this.m_wList.ID = "listBg";
	this.drawWithDepth = false;
}

function rgcReleaseAllItems()
{
	for (var i = 0; i < this.m_arrItems.length; ++i)
	{
		this.m_arrItems[i].releaseItem();
	}
	this.m_arrItems = [];
	for (var i = 0; i < this.m_arrReuseableWidget.length; ++i)
	{
		this.m_arrReuseableWidget[i].destroy();
	}
	this.m_arrReuseableWidget = [];
}

function rgcMoveFocusToItem(objItem, oriPointSpecified, nAniTime)
{
	assert(objItem !== undefined);

	if (!this.canMove(objItem.nItemIndex))
	{
		return;
	}

	try
	{
		//Volt.pauseGraphics();
		var bNeedScroll = false;
////////////////////////////////////////////////////////////////////////////////
// Updated by WangXJ@20140703
// Update Reason: Can not globally extend clone function for all Object, it's dangerous.
    //var newOriPoint = this.m_oriPoint.clone();
    var newOriPoint = _clone(this.m_oriPoint);
// End Update
////////////////////////////////////////////////////////////////////////////////

		if (oriPointSpecified === undefined)
		{
			if (objItem.logPosition.x * this.m_itemSize.width < this.m_oriPoint.x)
			{
				newOriPoint.x = objItem.logPosition.x * this.m_itemSize.width;
				bNeedScroll = true;
			}
			
			if ((objItem.logPosition.x + objItem.logSize.width) * this.m_itemSize.width
				> this.m_oriPoint.x + this.width)
			{
				newOriPoint.x = (objItem.logPosition.x + objItem.logSize.width) * this.m_itemSize.width - this.width;
				bNeedScroll = true;
			}
			else
			{
				//do nothing
			}

			if (objItem.logPosition.y * this.m_itemSize.height < this.m_oriPoint.y)
			{
				newOriPoint.y = objItem.logPosition.y * this.m_itemSize.height;
				bNeedScroll = true;
			}
			if ((objItem.logPosition.y + objItem.logSize.height) * this.m_itemSize.height
				> this.m_oriPoint.y + this.height)
			{
				newOriPoint.y = (objItem.logPosition.y + objItem.logSize.height) * this.m_itemSize.height - this.height;
				bNeedScroll = true;
			}
		}
		else
		{
			bNeedScroll = true;
			newOriPoint = oriPointSpecified;
		}

		

		if (!bNeedScroll)
		{
			this._updateFocusItem(objItem, this.m_oriPoint, true, nAniTime);
		}
		else
		{
			var bCanScroll = true;

			if (oriPointSpecified === undefined)
			{
				bCanScroll = this.canScroll(this.m_oriPoint, newOriPoint);
			}

			if (bCanScroll)
			{
				this._updateView(newOriPoint, objItem, nAniTime);
			}
			else
			{
				//Volt.resumeGraphics();
				return;
			}
		}

	    var nOldIndex = -1;
		
	    if (this.m_itemFocus !== undefined)
		{
			nOldIndex = this.m_itemFocus.nItemIndex;
	    }
		
	    this.m_itemFocus = objItem;

		this.ifFocusChange(nOldIndex, objItem.nItemIndex);

		if (!this.m_bFocus)
		{
			this.m_bFocus = true;
			this.ifGetFocus();

			if (this.m_objFocus !== undefined)
			{
				this.m_objFocus.show();
			}
		}

		//Volt.resumeGraphics();
	}
	catch (e)
	{
		//Volt.resumeGraphics();
		throw e;
	}
}


exports = CResizeableGridListControl;
