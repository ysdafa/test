/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of AutoScrollTextWidget
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var setTimeout=function(cb, interval, param) {
		return Volt.setTimeout(cb, interval, param);
	};
	
	var clearTimeout=function (id){
		if (id !== undefined)  {
			Volt.clearTimeout(id);
		}
	};
	const ControlBase = Volt.require("modules/UIElement/ControlBase.js");
/**
 * Class AutoScrollTextWidget.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
	AutoScrollTextWidget = function() { 
		this.ScrollDirection={
			SCROLL_RIGHT_TO_LEFT:0,
			SCROLL_LEFT_TO_RIGHT:1
		};
		this.ScrollState={
			normal:0,
			focus:1,
			selected:2,
			dim:3
		};
		this.state=0;
		this.text="";
		this.autoFocus=false;
		this.autoDim=false;
		this.autoSelected=false;
		this.isCreate=false;
		this.isAnimateable=false;
		this.flagAnimating = false;
		this.continuousScrollGap=40;
		this.startDelayTime=1000;
		this.endDelayTime=1000;
		this.textScrollInterval=8000;
		this.FirstTextInstance=null;
		this.SecondTextInstance=null;
		//this.textgap=40;
		this.scrollRate=0;
		this.textFont="30px";
		this.focusTextFont="36px";
		this.selectedTextFont="36px";
		this.dimTextFont="30px";
		this.isStartScroll=false;
		this.textColor={r:255,g:255,b:255,a:255*0.6};
		this.focusTextColor={r:255,g:255,b:255,a:255};
		this.selectedTextColor={r:255,g:227,b:56,a:255};
		this.dimTextColor={r:255,g:255,b:255,a:25.5};
		this.borderColor={r:255,g:255,b:255,a:25.5};
		this.focusBorderColor={r:255,g:255,b:255,a:255*0.8};
		this.dimBorderColor={r:255,g:227,b:56,a:255};
		this.selectedBorderColor={r:255,g:227,b:56,a:255*0.8};
		this.borderWidth=1;
		this.focusBorderWidth=2;
		this.dimBorderWidth=1;
		this.selectedBorderWidth=2;
		this.bgWidth=0;
		this.bgHeight=0;
		this.bgColor= {r: 0, g: 0, b: 0, a: 0};
		this.textVerticalAlignment="center";
		this.textHorizontalAlignment="left";
		this.timer=null;
		this.timer2=null;
		this.firsthandler=null;
		this.secondhandler=null;
		this.mouseOutCallBack=null;
		this.mouseOverCallBack=null;
		this.openOverout=false;
		this.openClick=false;
		this.mouseClickCallBack=null;
		this.isCalculate=false;
		this.direction = this.ScrollDirection.SCROLL_RIGHT_TO_LEFT;
		this.flagoverout=false;
		this.flagclick=false;
		
		 /**
		* This function will create an AutoScrollTextWidget<p>
		* This function will create an AutoScrollTextWidget,You can use this function when you want to create an AutoScrollTextWidget Object.
		* @param {Object} param of the new AutoScrollTextWidget you want to create.
		* @return {Object} return the new AutoScrollTextWidget object you want to create.
		* @example //This example create a new AutoScrollTextWidget.
		* const script_AID = "UIElement/AutoScrollTextWidget";
		* const AutoScrollTextWidget = require(script_AID);
		* TextAnimatingSample = new AutoScrollTextWidget(); 
		* var bcolor={r : 112,g : 112,b : 112,a : 255};
		* var bgolor={r : 112,g : 132,b : 92,a : 255};
		* TextAnimatingSample.create({x:300, y:300, width:300, height:50,parent:tempBG, focusbgcolor:bgolor, color:bcolor});
		* @since The version 1.0 this function is added.
		*/
		this.t_create = function(obj) {
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(obj.hasOwnProperty("width")){
				if("number" == typeof(obj.width)){
					this.bgWidth=obj.width;
				}
			}
			
			if(obj.hasOwnProperty("height")){
				if("number" == typeof(obj.height)){
					this.bgHeight=obj.height;
				}
			}
			
			if(obj.hasOwnProperty("color")){
				this.bgColor=obj.color;
			}
			
			if(obj.hasOwnProperty("focusbgcolor")){
				this.focusBgColor=obj.focusbgcolor;
			}
			else{
				this.focusBgColor=this.bgColor;
			}
			if(obj.hasOwnProperty("selectedbgcolor")){
				this.selectedBgColor=obj.selectedbgcolor;
			}
			else{
				this.selectedBgColor=this.bgColor;
			}
			if(obj.hasOwnProperty("dimbgcolor")){
				this.dimBgColor=obj.dimbgcolor;
			}
			else{
				this.dimBgColor=this.bgColor;
			}
			this.hasborder=false;
			if(obj.hasOwnProperty("border")){
				if(obj.border.hasOwnProperty("normal")){
					if(obj.border.normal.hasOwnProperty("width")){
						if("number" == typeof(obj.border.normal.width)){
							this.borderWidth=obj.border.normal.width;
							this.rootWidget.border.width=this.borderWidth;
						}
					}
					if(obj.border.normal.hasOwnProperty("color")){
						this.borderColor=obj.border.normal.color;
						this.rootWidget.border.color=this.borderColor;
					}
				}
				if(obj.border.hasOwnProperty("focus")){
					if(obj.border.focus.hasOwnProperty("width")){
						if("number" == typeof(obj.border.focus.width)){
							this.focusBorderWidth=obj.border.focus.width;
						}
					}
					if(obj.border.focus.hasOwnProperty("color")){
						this.focusBorderColor=obj.border.focus.color;
					}
				}
				if(obj.border.hasOwnProperty("selected")){
					if(obj.border.selected.hasOwnProperty("width")){
						if("number" == typeof(obj.border.selected.width)){
							this.selectedBorderWidth=obj.border.selected.width;
						}
					}
					if(obj.border.selected.hasOwnProperty("color")){
						this.selectedBorderColor=obj.border.selected.color;
					}
				}
				if(obj.border.hasOwnProperty("dim")){
					if(obj.border.dim.hasOwnProperty("width")){
						if("number" == typeof(obj.border.dim.width)){
							this.dimBorderWidth=obj.border.dim.width;
						}
					}
					if(obj.border.dim.hasOwnProperty("color")){
						this.dimBorderColor=obj.border.dim.color;
					}
				}
				this.hasborder=true;
			}
			this.tDrawingBGWidget = new Widget({
					x : 0,
					y : 0,
					width : this.bgWidth,
					height : this.bgHeight,
					color :  this.bgColor,
					cropOverflow : true,
					parent : obj.parent
			});
			this.isCreate = true;			
	    };
		
		this.t_MouseOverOut = function(isOnFlag){
			if(this.isCreate == true)
			{
				if(isOnFlag==true){
					if(this.openOverout==true){
						return;
					}
					else{
						this.tDrawingBGWidget.addEventListener("OnMouseOver", this.t_BGWidgetMouseOverBind); 
						this.tDrawingBGWidget.addEventListener("OnMouseOut", this.t_BGWidgetMouseOutBind);
						this.openOverout=true;
					}
				}
				else{
					if(this.openOverout==true){
						this.tDrawingBGWidget.removeEventListener("OnMouseOver", this.t_BGWidgetMouseOverBind); 
						this.tDrawingBGWidget.removeEventListener("OnMouseOut", this.t_BGWidgetMouseOutBind);
						this.openOverout=false;
					}
				}
			}
		};
		
		this.t_setMouseOverOutCallback = function(obj){
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(obj.hasOwnProperty("overCallback")){
				this.mouseOverCallBack=obj.overCallback;
			}
			if(obj.hasOwnProperty("outCallback")){
				this.mouseOutCallBack=obj.outCallback;
			}
		};
		
		this.t_MouseClick = function(isOnFlag){
			if(this.isCreate == true)
			{
				if(isOnFlag==true){
					if(this.openClick==true){
						return;
					}
					else{
						this.tDrawingBGWidget.addEventListener("OnMouseClick", this.t_BGWidgetMouseClickBind); 
						this.openClick=true;
					}
				}
				else{
					if(this.openClick==true){
						this.tDrawingBGWidget.removeEventListener("OnMouseClick", this.t_BGWidgetMouseClickBind); 
						this.openClick=false;
					}
				}
			}
		};
		
		this.t_setMouseClickCallback = function(callback){
			if(typeof(callback)!="undefined" || callback!=null){
				this.mouseClickCallBack=callback;
			}
		};
		
		this.t_BGWidgetMouseClick = function(targetWidget, eventData) {
			this.selected();
			if(null!=this.mouseClickCallBack){
				this.mouseClickCallBack(this);
			}
			return false;
		};
		this.t_BGWidgetMouseClickBind = this.t_BGWidgetMouseClick.bind(this);   
		
		this.t_BGWidgetMouseOver = function(targetWidget, eventData) {
			//this.getFocus();
			if(null!=this.mouseOverCallBack){
				this.mouseOverCallBack(this);
			}
			return false;
		};
		this.t_BGWidgetMouseOverBind = this.t_BGWidgetMouseOver.bind(this);                 		
		
		this.t_BGWidgetMouseOut = function(targetWidget, eventData) {
			//this.loseFocus();
			if(null!=this.mouseOutCallBack){
				this.mouseOutCallBack(this);
			}
			return false;
		};	
		this.t_BGWidgetMouseOutBind = this.t_BGWidgetMouseOut.bind(this);                 		
				
	    this.t_destroy = function() {
			if(this.timer!=null){
				clearTimeout(this.timer);
				this.timer=null;
			}
			
			if(this.timer2!=null){
				clearTimeout(this.timer2);
				this.timer2=null;
			}
			
			if(this.firsthandler!=null){
				this.firsthandler.cancel();
				this.firsthandler = null;
			}
			if(this.secondhandler!=null){
				this.secondhandler.cancel();
				this.secondhandler = null;
			}
			delete this.t_BGWidgetMouseClickBind;
			delete this.t_BGWidgetMouseOverBind;
			delete this.t_BGWidgetMouseOutBind;
			if(this.FirstTextInstance!=null){
				this.FirstTextInstance.destroy();
				this.FirstTextInstance = null;
			}
			if(this.SecondTextInstance!=null){
				this.SecondTextInstance.destroy();
				this.SecondTextInstance = null;
			}
			if(this.tDrawingBGWidget!=null){
				this.tDrawingBGWidget.destroy();
				this.tDrawingBGWidget = null;
			}
        };
	
	    this.t_getFocus = function() {
			if(true == this.autoFocus){
				return true;
			}
			else{
				this.active();
				if(true == this.isAnimateable){
					this.flagAnimating = true;
				}
				if(this.autoSelected == true){
					this.autoSelected = false;
				}
				if(this.hasborder){
					this.rootWidget.border.width=this.focusBorderWidth;
					this.rootWidget.border.color=this.focusBorderColor;
				}
				this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
				this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
				this.autoFocus=true;
				this.state=this.ScrollState.focus;
				return true;
			}
	    	
	    };
	
	    this.t_loseFocus = function() {
			if(false == this.autoFocus){
				return true;
			}
			else{
				this.deactive();
				if(true == this.isAnimateable){
					this.flagAnimating = false;					
				}
				this.FirstTextInstance.textColor = this.textColor;
				this.FirstTextInstance.font = this.textFont;
				this.tDrawingBGWidget.color = this.bgColor;
				if(this.hasborder){
					this.rootWidget.border.width=this.borderWidth;
					this.rootWidget.border.color=this.borderColor;
				}
				this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
				this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
				this.autoFocus=false;
				this.state=this.ScrollState.normal;
				return true;
			}
	    };
		
		this.t_getDim = function() {
			if(this.autoDim == false){
				this.autoDim=true;
				
				this.FirstTextInstance.textColor = this.dimTextColor;
				this.FirstTextInstance.font = this.dimTextFont;
				this.tDrawingBGWidget.color = this.dimBgColor;
				if(this.hasborder){
					this.rootWidget.border.width=this.dimBorderWidth;
					this.rootWidget.border.color=this.dimBorderColor;
				}
				this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
				this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
				switch(this.state) {
					case this.ScrollState.focus:
						this.deactive();
						if(true == this.isAnimateable){
							this.flagAnimating = false;					
						}
						this.autoFocus = false;
					break;
					case this.ScrollState.selected:
						this.autoSelected = false;
					break;
					default:
					break;
				}
				this.flagoverout=this.openOverout;
				this.flagclick=this.openClick;
				if(this.openOverout==true){
					this.enableMouseOverOut(false);
				}
				if(this.openClick==true){
					this.enableMouseClick(false);
				}
			}
		
		};
		
		this.t_loseDim = function() {
			if(this.autoDim == true){
				this.autoDim = false;
				this.enableMouseOverOut(this.flagoverout);
				this.enableMouseClick(this.flagclick);
				this.flagoverout=false;
				this.flagclick=false;
				switch(this.state) {
					case this.ScrollState.normal:
						this.autoFocus=true;
						this.loseFocus();
					break;
					case this.ScrollState.focus:
						this.getFocus();
					break;
					case this.ScrollState.selected:
						this.selected();
					break;
					default:
					break;
				}
				
			}
		
		};
		
		this.t_selected = function() {
			if(this.autoSelected == false){
				this.FirstTextInstance.textColor = this.selectedTextColor;
				this.FirstTextInstance.font = this.selectedTextFont;
				this.tDrawingBGWidget.color = this.selectedBgColor;
				if(this.hasborder){
					this.rootWidget.border.width=this.selectedBorderWidth;
					this.rootWidget.border.color=this.selectedBorderColor;
				}
				this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
				this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
				if(this.autoFocus==true){
					this.deactive();
					if(true == this.isAnimateable){
						this.flagAnimating = false;					
					}
					this.autoFocus = false;
				}
				this.autoSelected = true;
				this.state=this.ScrollState.selected;
			}
		};
		
		this.t_unSelected = function(){
			if(this.autoSelected == true){
				this.autoSelected = false;
				if(this.autoFocus==true){
					this.deactive();
					if(true == this.isAnimateable){
						this.flagAnimating = false;					
					}
					this.autoFocus = false;
				}
				this.FirstTextInstance.textColor = this.textColor;
				this.FirstTextInstance.font = this.textFont;
				this.tDrawingBGWidget.color = this.bgColor;
				if(this.hasborder){
					this.rootWidget.border.width=this.borderWidth;
					this.rootWidget.border.color=this.borderColor;
				}
				this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
				this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
				this.state=this.ScrollState.normal;
			}
		};
		
		this.flagScrollAnimating = function(){
			return this.flagAnimating;
		};

		this.setScrollDirection = function(scrolldirection){
			if(false == this.isCreate){
				return false;
			}
			if(scrolldirection == this.ScrollDirection.SCROLL_RIGHT_TO_LEFT||scrolldirection == this.ScrollDirection.SCROLL_LEFT_TO_RIGHT){
				this.direction = scrolldirection;
				if(scrolldirection == this.ScrollDirection.SCROLL_LEFT_TO_RIGHT)
				{
					this.FirstTextInstance.width = this.textWidgetLength;
					this.FirstTextInstance.x = this.bgWidth - this.textWidgetLength;
					this.FirstTextInstance.ellipsize = false;
				}
				return true;
			}
			return false;
		};		
	
		 /**
		* This function will set the text content property of the AutoScrollTextWidget created.<p>
		* This function will set the text content property of the AutoScrollTextWidget created,You can use this function when you want to set the text content property.
		* @param {Object} param of the text content property you want to set.
		* @return {Boolean} return true if set succeed,else return false.
		* @example //This example set  the text content property.
		* var tcolor={r : 112,g : 152,b : 212,a : 255};	
		* var ftcolor={r : 112,g : 212,b : 212,a : 255};
		* TextAnimatingSample1.setTextContent({text:"This is",
										textfont:{normal:"32px",focus:"45px"},
										textcolor:{normal:tcolor,focus:ftcolor},
										textVerticalAlignment:"center",
										textHorizontalAlignment:"center",
										scrollgap:10});
		* @since The version 1.0 this function is added.
		*/
		
		this.setTextContent = function(obj){
			if(false == this.isCreate)
			{
				return false;
			}
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(this.isAnimateable == true){
				this.isAnimateable = false;
			}
			if(this.flagAnimating ==true){
				if(this.timer!=null){
					clearTimeout(this.timer);
					this.timer=null;
				}
				if(this.timer2!=null){
					clearTimeout(this.timer2);
					this.timer2=null;
				}
				if(this.firsthandler!=null){
					this.firsthandler.cancel();
					this.firsthandler = null;
				}
				if(this.secondhandler!=null){
					this.secondhandler.cancel();
					this.secondhandler = null;
				}
			}
			if(obj.hasOwnProperty("text")){
				if ("string" == typeof(obj.text)){
					this.text=obj.text;
					this.iscalculate=true;
				}
			}
			if(obj.hasOwnProperty("textfont")){
				if(obj.textfont.hasOwnProperty("normal")){
					if ("string"== typeof(obj.textfont.normal)){
						this.textFont=obj.textfont.normal;
						this.iscalculate=true;
					}
				}
				if(obj.textfont.hasOwnProperty("focus")){
					if ("string"== typeof(obj.textfont.focus)){
						this.focusTextFont=obj.textfont.focus;
						this.iscalculate=true;
					}
					else{
						this.focusTextFont=this.textFont;
					}
				}
				else{
					this.focusTextFont=this.textFont;
				}
				if(obj.textfont.hasOwnProperty("selected")){
					if ("string"== typeof(obj.textfont.selected)){
						this.selectedTextFont=obj.textfont.selected;
					}
					else{
						this.selectedTextFont=this.textFont;
					}
				}
				else{
					this.selectedTextFont=this.textFont;
				}
				if(obj.textfont.hasOwnProperty("dim")){
					if ("string"== typeof(obj.textfont.dim)){
						this.dimTextFont=obj.textfont.dim;
					}
					else{
						this.dimTextFont=this.textFont;
					}
				}
				else{
					this.dimTextFont=this.textFont;
				}
			}
			if(obj.hasOwnProperty("scrollgap")){
				this.continuousScrollGap=obj.scrollgap;
			}
			if(obj.hasOwnProperty("textcolor")){
				if(obj.textcolor.hasOwnProperty("normal")){
					this.textColor=obj.textcolor.normal;
				}
				if(obj.textcolor.hasOwnProperty("focus")){
					this.focusTextColor=obj.textcolor.focus;
				}
				if(obj.textcolor.hasOwnProperty("selected")){
					this.selectedTextColor=obj.textcolor.selected;
				}
				if(obj.textcolor.hasOwnProperty("dim")){
					this.dimTextColor=obj.textcolor.dim;
				}
			}
			if(obj.hasOwnProperty("textVerticalAlignment")){
				this.textVerticalAlignment=obj.textVerticalAlignment;
			}
			if(obj.hasOwnProperty("textHorizontalAlignment")){
				this.textHorizontalAlignment=obj.textHorizontalAlignment;
			}
			var tempFirstTextInstance = new TextWidget({
				x:0,
				y:0,
				font:this.focusTextFont,
				text:this.text,
			});
			var tmpTextSize = [];
			tmpTextSize[0] = (tempFirstTextInstance.getAbsoluteSize()).x;
            tmpTextSize[1] = (tempFirstTextInstance.getAbsoluteSize()).y;
			if(tmpTextSize[0] > this.bgWidth)
				this.isAnimateable = true;
			if(!this.FirstTextInstance){
				this.FirstTextInstance=tempFirstTextInstance;
				this.FirstTextInstance.parent=this.tDrawingBGWidget;
			}
			else{
				tempFirstTextInstance.destroy();
				tempFirstTextInstance=null;
			}
			//init text instance
			var tmptextWidgetLength = tmpTextSize[0]+this.continuousScrollGap;
			var tmptextWidgetHeight = tmpTextSize[1];
			if(tmpTextSize[0] < this.bgWidth)
				tmptextWidgetLength = this.bgWidth;
			if(tmpTextSize[1] < this.bgHeight)
				tmptextWidgetHeight = this.bgHeight;
				
			this.textWidgetLength = tmptextWidgetLength;
			this.textWidgetHeight = tmptextWidgetHeight;
			if(this.isAnimateable){
				this.FirstTextInstance.height = this.textWidgetHeight;
				this.FirstTextInstance.x=0;
				this.FirstTextInstance.text = this.text;
				//test the abbs
				if(this.autoFocus == true){
					this.FirstTextInstance.width = this.textWidgetLength;
					this.FirstTextInstance.textColor = this.focusTextColor;
					this.FirstTextInstance.font=this.focusTextFont;
				}
				else if(this.atuoDim == true){
					this.FirstTextInstance.width = this.bgWidth;
					this.FirstTextInstance.ellipsize = true;
					this.FirstTextInstance.font=this.dimTextFont;
					this.FirstTextInstance.textColor = this.dimTextColor;
				}
				else if(this.autoSelected == true){
					this.FirstTextInstance.width = this.bgWidth;
					this.FirstTextInstance.ellipsize = true;
					this.FirstTextInstance.font=this.selectedTextFont;
					this.FirstTextInstance.textColor = this.selectedTextColor;
				}
				else{
					this.FirstTextInstance.width = this.bgWidth;
					this.FirstTextInstance.ellipsize = true;
					this.FirstTextInstance.font=this.textFont;
					this.FirstTextInstance.textColor = this.textColor;
				}
				this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
				this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
				if(!this.SecondTextInstance){
					var tempSecondTextInstance = new TextWidget({
						x:(this.textWidgetLength+this.continuousScrollGap),
						y:0,
						width:this.textWidgetLength,
						height:this.textWidgetHeight,
						parent:this.tDrawingBGWidget
					});
					tempSecondTextInstance.text = this.text;
					if(this.autoFocus == true){
						tempSecondTextInstance.textColor = this.focusTextColor;
						tempSecondTextInstance.font=this.focusTextFont;
					}
					else{
						tempSecondTextInstance.textColor = this.textColor;
						tempSecondTextInstance.font=this.textFont;
					}
					tempSecondTextInstance.horizontalAlignment = this.textHorizontalAlignment;
					tempSecondTextInstance.verticalAlignment = this.textVerticalAlignment;
					this.SecondTextInstance = tempSecondTextInstance;
				 }
				 else{
					this.SecondTextInstance.x = (this.textWidgetLength+this.continuousScrollGap);
					this.SecondTextInstance.y = 0;
					this.SecondTextInstance.height = this.textWidgetHeight;
					this.SecondTextInstance.width = this.textWidgetLength;
					if(this.autoFocus == true){
						this.SecondTextInstance.textColor = this.focusTextColor;
						this.SecondTextInstance.font=this.focusTextFont;
					}
					else{
						this.SecondTextInstance.textColor = this.textColor;
						this.SecondTextInstance.font=this.textFont;
					}
					this.SecondTextInstance.text = this.text;
					this.SecondTextInstance.horizontalAlignment = this.textHorizontalAlignment;
					this.SecondTextInstance.verticalAlignment = this.textVerticalAlignment;
				}
				
				if(true == this.autoFocus){
					if(this.flagAnimating == false){
						this.flagAnimating = true;
						this.isStartScroll=true;
					}
					 var self=this;
					 if(this.timer==null){
						this.timer=setTimeout(function(){
							self.m_DoScroll();
						},this.startDelayTime);
					}

				}
			}
			else{
				if(this.SecondTextInstance!=null){
					this.SecondTextInstance.destroy();
					this.SecondTextInstance=null;
				}
				this.FirstTextInstance.x = 0;
				this.FirstTextInstance.y = 0;
				this.FirstTextInstance.height = this.textWidgetHeight;
				this.FirstTextInstance.width = this.textWidgetLength;
				this.FirstTextInstance.text = this.text;
				this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
				this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
				if(this.autoFocus == false){
					this.FirstTextInstance.textColor = this.textColor;
					this.FirstTextInstance.font=this.textFont;
				}
				else{
					this.FirstTextInstance.textColor = this.focusTextColor;
					this.FirstTextInstance.font=this.focusTextFont;
					if(this.flagAnimating == true){
						this.flagAnimating = false;
						this.isStartScroll=false;
					}
				}
			}
			return true;
		};
		
		
		 /**
		* This function will set the scroll time property of the AutoScrollTextWidget created.It will not work if you set Scroll Rate.<p>
		* This function will set the scroll time property of the AutoScrollTextWidget created,You can use this function when you want to set set the scroll time property.
		* @param {Object} param of the scroll time you want to set.
		* @return {Boolean} return true if set succeed,else return false.
		* @example //This example set  the scroll time property.
		* TextAnimatingSample1.setScrollTime({gaptime:0,startdelaytime:0,textscrollinterval:7000});
		* @since The version 1.0 this function is added.
		*/
		
		this.setScrollTime=function(obj){
			if(false == this.isCreate){
				return false;
			}
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(obj.hasOwnProperty("gaptime")){
				if(obj.gaptime>=0){
					this.endDelayTime=obj.gaptime;
				}
			}
			if(obj.hasOwnProperty("startdelaytime")){
				if(obj.startdelaytime>=0){
					this.startDelayTime=obj.startdelaytime;
				}
			}
			if(obj.hasOwnProperty("textscrollinterval")){
				if(obj.textscrollinterval >= 0){
					this.textScrollInterval=obj.textscrollinterval;
				}
			}
			return true;
	
		};
		
		 /**
		* This function will set the width of the AutoScrollTextWidget created.<p>
		* This function will set width of the AutoScrollTextWidget created,You can use this function when you want to set width.
		* @param {Number} width you want to set.
		* @return {Boolean} return true if set succeed,else return false.
		* @example //This example set  the width property.
		* TextAnimatingSample1.setWidth(1000);
		* @since The version 1.0 this function is added.
		*/
		
		this.setWidth=function(width){
			if("number" != typeof(width))
			{
				return false;
			}
			if(width>0){
				if(width != this.bgWidth){
					this.bgWidth=width;
					this.tDrawingBGWidget.width=this.bgWidth;
					this.setTextContent({});
					return true;
				}
			}
		};
		
		/**
		* This function will set scroll rate of the AutoScrollTextWidget created.<p>
		* This function will set  scroll rate of the AutoScrollTextWidget created,You can use this function when you want to set scroll rate.
		* @param {Number}scroll rate you want to set.
		* @return {Boolean} return true if set succeed,else return false.
		* @example //This example set scroll rate property.
		* TextAnimatingSample1.setScrollRate(100);
		* @since The version 1.0 this function is added.
		*/
		
		this.setScrollRate=function(scrollrate){
			if(false == this.isCreate){
				return false;
			}
			if("number"!=typeof(scrollrate))
			{
				return false;
			}
			if(scrollrate>0){
				this.scrollRate=scrollrate;
				this.iscalculate=true;
			}
			else{
				this.scrollRate=0;
			}
			return true;
			
		};
		
		this.active=function(){
			var self = this;
			if(this.isActived == true){
				return true;
			}
			else{
				if(!this.isAnimateable){
					this.FirstTextInstance.textColor = this.focusTextColor;
					this.FirstTextInstance.font = this.focusTextFont;
					this.tDrawingBGWidget.color =  this.focusBgColor;
					
				}
				else{
					this.isActived = true;
					this.isStartScroll = true;
					this.FirstTextInstance.textColor = this.focusTextColor;
					this.FirstTextInstance.font = this.focusTextFont;
					this.SecondTextInstance.textColor = this.focusTextColor;
					this.SecondTextInstance.font = this.focusTextFont;
					this.tDrawingBGWidget.color = this.focusBgColor;
					
					if(this.direction == this.ScrollDirection.SCROLL_RIGHT_TO_LEFT){
						this.FirstTextInstance.width = this.textWidgetLength;
						this.FirstTextInstance.ellipsize = false;
					}
					else if(this.direction == this.ScrollDirection.SCROLL_LEFT_TO_RIGHT){
						this.FirstTextInstance.width = this.textWidgetLength;
						this.FirstTextInstance.x = this.bgWidth - this.textWidgetLength;
						this.FirstTextInstance.ellipsize = false;
						this.SecondTextInstance.x =-2*this.textWidgetLength-this.continuousScrollGap+this.bgWidth;
					}
					if(this.timer==null){
						this.timer=setTimeout(function(){
							self.m_DoScroll();
						},this.startDelayTime);
					}
				}
				return true;
			}
		};
		
		this.m_DoScroll=function(){
			if(this.scrollRate!=0){
				if(this.iscalculate == true){
					this.textScrollInterval=this.textWidgetLength/this.scrollRate*1000;
					this.iscalculate = false;
				}
			}
			if(this.isStartScroll){
				if(this.direction == this.ScrollDirection.SCROLL_RIGHT_TO_LEFT){
					this.m_R_L_Scroll();
				}
				else if(this.direction == this.ScrollDirection.SCROLL_LEFT_TO_RIGHT){
					this.m_L_R_Scroll();
				}
				else{
				}
			}
		};
		
		this.m_R_L_Scroll=function(){
			var self = this;
			this.firsthandler=this.FirstTextInstance.animate("x",(-1*(self.textWidgetLength+self.continuousScrollGap)),self.textScrollInterval);
			this.secondhandler=this.SecondTextInstance.animate("x",0,self.textScrollInterval,function(){
				if(self.isStartScroll){
					var tmpTextInstance = self.FirstTextInstance;
					self.FirstTextInstance = self.SecondTextInstance;
					self.SecondTextInstance = tmpTextInstance;
					self.FirstTextInstance.x=0;
					self.SecondTextInstance.x = self.textWidgetLength+self.continuousScrollGap;
					var selftwice = self;
					self.timer2=setTimeout(function(){
						selftwice.m_DoScroll();
					},self.endDelayTime);
					
				}
			});
		};
		
		this.m_L_R_Scroll=function(){
			var self = this;
			this.firsthandler=this.FirstTextInstance.animate("x",(self.width+self.continuousScrollGap),self.textScrollInterval);
			this.secondhandler=this.SecondTextInstance.animate("x",(self.width - self.textWidgetLength),self.textScrollInterval,function(){
				if(self.isStartScroll){
					var tmpTextInstance = self.FirstTextInstance;
					self.FirstTextInstance = self.SecondTextInstance;
					self.SecondTextInstance = tmpTextInstance;
					self.FirstTextInstance.x=self.width - self.textWidgetLength;
					self.SecondTextInstance.x =-2*self.textWidgetLength-self.continuousScrollGap+self.width;
					var selftwice = self;
					self.timer2=setTimeout(function(){
						selftwice.m_DoScroll();
					},self.endDelayTime);
				}
			});
		};
		
		this.deactive=function(){
			this.isActived = false;
			if(this.timer!=null){
				clearTimeout(this.timer);
				this.timer=null;
			}
			
			if(this.timer2!=null){
				clearTimeout(this.timer2);
				this.timer2=null;
			}
			
			if(this.firsthandler!=null){
				this.firsthandler.cancel();
				this.firsthandler = null;
			}
			if(this.secondhandler!=null){
				this.secondhandler.cancel();
				this.secondhandler = null;
			}
			if(this.isAnimateable){
				if(this.direction == this.ScrollDirection.SCROLL_RIGHT_TO_LEFT){
					if(this.FirstTextInstance==this.SecondTextInstance){
						return false;
					}
					this.FirstTextInstance.x = 0;
					this.FirstTextInstance.text=this.text;
					this.FirstTextInstance.width = this.bgWidth;
					this.FirstTextInstance.ellipsize = true;
					this.SecondTextInstance.x =(this.textWidgetLength+this.continuousScrollGap);
					this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
					this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
					this.SecondTextInstance.horizontalAlignment = this.textHorizontalAlignment;
					this.SecondTextInstance.verticalAlignment = this.textVerticalAlignment;
				}
				else if(this.direction == this.ScrollDirection.SCROLL_LEFT_TO_RIGHT){
					if(this.FirstTextInstance==this.SecondTextInstance)	{
						return false;
					}
					this.FirstTextInstance.text=this.text;
					this.FirstTextInstance.width = this.textWidgetLength;
					this.FirstTextInstance.x = this.bgWidth - this.textWidgetLength;
					this.FirstTextInstance.ellipsize = false;
					this.SecondTextInstance.x =-2*this.textWidgetLength-this.continuousScrollGap+this.bgWidth;
					this.FirstTextInstance.horizontalAlignment = this.textHorizontalAlignment;
					this.FirstTextInstance.verticalAlignment = this.textVerticalAlignment;
					this.SecondTextInstance.horizontalAlignment = this.textHorizontalAlignment;
					this.SecondTextInstance.verticalAlignment = this.textVerticalAlignment;
				}
				this.isStartScroll = false;
			}
			
		};
		
	    this.t_keyHandler = function(keycode, keytype){	
			return false;	
	    };
	};
		
	AutoScrollTextWidget.prototype = new ControlBase();

	exports = AutoScrollTextWidget;    
