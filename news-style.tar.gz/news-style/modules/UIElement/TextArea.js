 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of TextArea
 * @date    2014/08/12
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

/**
 * Class TextArea.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
TextArea = function() {
    //inner data
    this.totalHeight = 0;
    this.textBG = null;
    this.textWdgt = null;
    this.expandBtn = null;
    this.arrowUp = null;
    this.arrowDown = null;
    this.callback = null;
    this.expanded = false;
    //parameter
    this.text = "";
    this.font = "Samsung SVD_Light 30px";
    this.textColor = {r:255,g:255,b:255,a:255*0.6};
    this.textBGColor = {r:0,g:0,b:0,a:0};
    this.lineNumber = 3;
    //this.linespacing = 0;
    this.lineHeight = 50;
    this.expandIconSrc = "";
    this.expandIconWidth = 30;
    this.expandIconHeight = 30;
    this.expandIconGap = scene.width*0.015625;
    this.arrowUpSrc = "";
    this.arrowDownSrc = "";
    this.arrowWidth = 38;
    this.arrowHeight = 32;
    this.scrollLineNum = 1;
    
    this.m_setProperty = function(obj) {
        if (obj.hasOwnProperty("text") 
            && "string" == typeof obj.text && 0 < obj.text.length) {
            this.text = obj.text;
        }
        if (obj.hasOwnProperty("font") 
            && "string" == typeof obj.font && 0 < obj.font.length) {
            this.font = obj.font;
        }
        if (obj.hasOwnProperty("textColor") 
            && "object" == typeof obj.textColor) {
            this.textColor = obj.textColor;
        }
        if (obj.hasOwnProperty("textBGColor") 
            && "object" == typeof obj.textBGColor) {
            this.textBGColor = obj.textBGColor;
        }
        if (obj.hasOwnProperty("lineNumber") 
            && "number" == typeof obj.lineNumber && 1 <= obj.lineNumber) {
            this.lineNumber = Math.floor(obj.lineNumber);
        }
        /*
        if (obj.hasOwnProperty("linespacing") 
            && "number" == typeof obj.linespacing && 0 < obj.linespacing) {
            this.linespacing = obj.linespacing;
        }
        */
        if (obj.hasOwnProperty("lineHeight") 
            && "number" == typeof obj.lineHeight && 0 < obj.lineHeight) {
            this.lineHeight = obj.lineHeight;
        }
        if (obj.hasOwnProperty("expandIconSrc") 
            && "string" == typeof obj.expandIconSrc && 0 < obj.expandIconSrc.length) {
            this.expandIconSrc = obj.expandIconSrc;
        }
        if (obj.hasOwnProperty("expandIconWidth") 
            && "number" == typeof obj.expandIconWidth && 0 < obj.expandIconWidth) {
            this.expandIconWidth = obj.expandIconWidth;
        }
        if (obj.hasOwnProperty("expandIconHeight") 
            && "number" == typeof obj.expandIconHeight && 0 < obj.expandIconHeight) {
            this.expandIconHeight = obj.expandIconHeight;
        }
        if (obj.hasOwnProperty("expandIconGap") 
            && "number" == typeof obj.expandIconGap && 0 < obj.expandIconGap) {
            this.expandIconGap = obj.expandIconGap;
        }
        if (obj.hasOwnProperty("arrowUpSrc") 
            && "string" == typeof obj.arrowUpSrc && 0 < obj.arrowUpSrc.length) {
            this.arrowUpSrc = obj.arrowUpSrc;
        }
        if (obj.hasOwnProperty("arrowDownSrc") 
            && "string" == typeof obj.arrowDownSrc && 0 < obj.arrowDownSrc.length) {
            this.arrowDownSrc = obj.arrowDownSrc;
        }
        if (obj.hasOwnProperty("arrowWidth") 
            && "number" == typeof obj.arrowWidth && 0 < obj.arrowWidth) {
            this.arrowWidth = obj.arrowWidth;
        }
        if (obj.hasOwnProperty("arrowHeight") 
            && "number" == typeof obj.arrowHeight && 0 < obj.arrowHeight) {
            this.arrowHeight = obj.arrowHeight;
        }
        if (obj.hasOwnProperty("arrowHeight") 
            && "number" == typeof obj.arrowHeight && 0 < obj.arrowHeight) {
            this.arrowHeight = obj.arrowHeight;
        }
        if (obj.hasOwnProperty("scrollLineNum") 
            && "number" == typeof obj.scrollLineNum
            && 1 <= obj.scrollLineNum && obj.scrollLineNum <= this.lineNumber) {
            this.scrollLineNum = Math.floor(obj.scrollLineNum);
        }
        
        return true;
    };
	
	/**
	* This function will create a TextArea<p>
	* This function will create a TextArea,You can use this function when you want to create a TextArea Object.
	* @param {Object} param of the new TextArea you want to create.
	* @return {Object} return the new TextArea object you want to create.
	* @example //This example create a new TextArea.
	* const script_AID = "UIElement/TextArea";
	* const TextArea = require(script_AID);
	* var textArea = new TextArea();
    * textArea.create({
        x : 100,
        y : 100,
        width : 500,
        height : 500,
        parent: tempBG,
        text: textContent,
        font: "Samsung SVD_Light 36px",
        textColor: {r:255,g:255,b:255,a:255},
        textBGColor: {r:0,g:0,b:100,a:100},
        lineNumber: 5,
        //linespacing: 20,
        lineHeight: 50,
        expandIconSrc: "SingleLineGridSample/ico/comn_icon_add.png",
        expandIconWidth: 30,
        expandIconHeight: 30,
        expandIconGap: 20,
        arrowUpSrc: "spinner/arrow_up.png",
        arrowDownSrc: "spinner/arrow_dn.png",
        arrowWidth: 38,
        arrowHeight: 32,
        scrollLineNum: 5,
		});
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
        this.m_setProperty(obj);
        /*
        this.debugText = new TextWidget({
                       x: this.x/2,
                       y: this.y/2,
                       width: 500,
                       height: 50,
                       text: 'debug',
                       color:{r:0,g:0,b:0,a:0},
                       textColor: {r:255, g:255, b:255, a:255},
                       parent: scene,
        });
        */
        //create elements
        this.textBG = new Widget({
            x: 0,
            y: 0,
            origin: {x:0,y:0},
            anchor: {x:0,y:0},
            width: this.width-this.expandIconWidth-this.expandIconGap,
            height: this.height,
            color: {r:0,g:0,b:0,a:0},
            cropOverflow: true,
            parent: obj.parent,
        });
        this.textWdgt = new TextWidget({
            x: 0,
            y: 0,
            origin: {x:0,y:0},
            anchor: {x:0,y:0},
            width: this.textBG.width,
            text: this.text,
            font: this.font,
            textColor: this.textColor,
            color: this.textBGColor,
            horizontalAlignment: "left",
            verticalAlignment: "center",
            //lineSpacing:this.linespacing,
            ellipsize: true,
            parent: this.textBG,
        });
        this.textWdgt.lineSpacing = this.lineHeight - this.textWdgt.getLineHeight();
        //this.lineHeight = this.textWdgt.getLineHeight();
        //this.totalHeight = this.textWdgt.getAbsoluteSize().y;
        this.totalHeight = this.textWdgt.height;
        //this.debugText.text=this.totalHeight.toString();
        this.textWdgt.setHeightInLines(this.lineNumber);
        this.expandBtn = new Button();
        this.expandBtn.create({
            x:this.width-this.expandIconWidth,
            y:(this.textWdgt.height-this.lineHeight+this.textWdgt.lineSpacing)+(this.lineHeight-this.textWdgt.lineSpacing-this.expandIconHeight)/2,
            width:this.expandIconWidth,
            height:this.expandIconHeight,
            parent:obj.parent,
            IconSrc: {normal:this.expandIconSrc,
                    focus:this.expandIconSrc,
                    selected:this.expandIconSrc,
                    dim:this.expandIconSrc},
        });
        if(this.totalHeight <= this.textWdgt.height){
            this.expandBtn.hide();
        }
        //arrow icon display outside the background height.
        this.cropOverflow = false;
        this.arrowUp = new ImageWidget({
            x: this.textWdgt.x+(this.textWdgt.width-this.arrowWidth)/2,
            y: this.textWdgt.y-this.arrowHeight,
            origin: {x:0,y:0},
            anchor: {x:0,y:0},
            width: this.arrowWidth,
            height: this.arrowHeight,
            src: this.arrowUpSrc,
            parent: obj.parent,
        });
        this.arrowUp.hide();
        this.arrowDown = new ImageWidget({
            x: this.textWdgt.x+(this.textWdgt.width-this.arrowWidth)/2,
            y: this.textWdgt.y+this.height,
            origin: {x:0,y:0},
            anchor: {x:0,y:0},
            width: this.arrowWidth,
            height: this.arrowHeight,
            src: this.arrowDownSrc,
            parent: obj.parent,
        });
        this.arrowDown.hide();
        return this;
	};
	
    /**
	* This function will set text of TextArea<p>
	* This function will set text of TextArea,You can use this function when you want to set text.
	* @param {String} text of the new TextArea you want to create.
	* @return {Void}.
	* @example //This example set text.
	* controlArray[controlIndex].setText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ");
	* @since The version 1.0 this function is added.
	*/
    this.setText = function(text){
        if ("string" == typeof text && 0 < text.length) {
            this.textWdgt.text = text;
        }
        //recaculate total height.
        var tmpText = new TextWidget({
            x: 0,
            y: 0,
            origin: {x:0,y:0},
            anchor: {x:0,y:0},
            width: this.textBG.width,
            text: text,
            font: this.font,
            textColor: this.textColor,
            color: this.textBGColor,
            horizontalAlignment: "left",
            verticalAlignment: "center",
            //lineSpacing: this.linespacing,
            ellipsize: true,
            parent: this.textBG,
        });
        tmpText.lineSpacing = this.lineHeight - this.textWdgt.getLineHeight();
        this.totalHeight = tmpText.height;
        tmpText.destroy();
        delete tmpText;
        this.reset();
    };
    this.reset = function(){
        this.textWdgt.y = 0;
        this.textWdgt.setHeightInLines(this.lineNumber);
        if(this.totalHeight > this.textWdgt.height){
            this.expandBtn.show();
            if(this.isFocused)
                this.expandBtn.getFocus();
        }
        else {
            this.expandBtn.hide();
        }
        this.arrowUp.hide();
        this.arrowDown.hide();
        this.expanded = false;
    };

	this.t_getFocus = function() {
        this.expandBtn.getFocus();
	};
	this.t_loseFocus = function() {
        this.expandBtn.loseFocus();
	};
	this.t_show = function() {
        if(this.totalHeight > this.textWdgt.height){
            this.expandBtn.show();
        }
        else {
            this.expandBtn.hide();
        }
	};
	this.t_hide = function() {
		this.t_loseFocus();
       this.expandBtn.hide();
	};		
	this.t_destroy = function() {
        if(null != this.expandBtn) {
            this.expandBtn.destroy();
            this.expandBtn = null;
        }
        if(null != this.textWdgt) {
            this.textWdgt.destroy();
            this.textWdgt = null;
        }
        if(null != this.arrowUp) {
            this.arrowUp.destroy();
            this.arrowUp = null;
        }
        if(null != this.arrowDown) {
            this.arrowDown.destroy();
            this.arrowDown = null;
        }
        if(null != this.textBG) {
            this.textBG.destroy();
            this.textBG = null;
        }
        
       delete this.expandBtnMouseClickBind;
       delete this.arrowUpMouseClickBind;
       delete this.arrowDownMouseClickBind;
	};
	this.t_getDim = function() {
       this.expandBtn.getDim();
	};	
	this.t_loseDim = function() {
       this.expandBtn.loseDim();
	};
    this.t_selected = function() {
       this.expandBtn.selected();
    };
    this.t_unSelected = function() {
       this.expandBtn.unSelected();
    };

	this.t_setMouseClickCallback = function(callback)
	{
        if(this.isCreated && null != callback
            && "function" == typeof callback) {
            this.callback = callback;
        }
	};
	
    this.expandBtnMouseClick = function(targetWidget) {
        if(this.isFocused && !this.isDimed && !this.expanded){
            this.textWdgt.height = this.totalHeight;
            this.expandBtn.hide();
            if(this.totalHeight>this.textBG.height){
                //this.arrowUp.show();
                this.arrowDown.show();
            }
            this.expanded = true;
            if(null != this.callback){
                this.callback();
            }
        }
        return false;
    };	
    this.expandBtnMouseClickBind = this.expandBtnMouseClick.bind(this);
    this.arrowUpMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            if(this.textWdgt.y <= 0){
                this.textWdgt.y = this.textWdgt.y + this.scrollLineNum*this.lineHeight;
                if(this.totalHeight>this.textBG.height){
                    this.arrowDown.show();
                }
                if(this.textWdgt.y > 0){
                    this.textWdgt.y = 0;
                    this.arrowUp.hide();
                }
            }
        }
        return false;
    };	
    this.arrowUpMouseClickBind = this.arrowUpMouseClick.bind(this);
    this.arrowDownMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            if(this.textWdgt.y+this.textWdgt.height >= this.textBG.height){
                this.textWdgt.y = this.textWdgt.y - this.scrollLineNum*this.lineHeight;
                if(this.totalHeight>this.textBG.height){
                    this.arrowUp.show();
                }
                if(this.textWdgt.y+this.textWdgt.height < this.textBG.height){
                    this.textWdgt.y = this.textBG.height - this.textWdgt.height;
                    this.arrowDown.hide();
                }
            }
        }
        return false;
    };	
    this.arrowDownMouseClickBind = this.arrowDownMouseClick.bind(this);
    this.t_MouseClick = function(isOnFlag){
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag) {
                this.expandBtn.setMouseClickCallback(this.expandBtnMouseClickBind);
                this.expandBtn.enableMouseClick(true);
                this.arrowUp.addEventListener("OnMouseClick", this.arrowUpMouseClickBind);
                this.arrowDown.addEventListener("OnMouseClick", this.arrowDownMouseClickBind);
            }
            else {
                this.expandBtn.enableMouseClick(false);
                this.arrowUp.removeEventListener("OnMouseClick", this.arrowUpMouseClickBind);
                this.arrowDown.removeEventListener("OnMouseClick", this.arrowDownMouseClickBind);
            }
        }
    };
    
	this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        if (keytype == Volt.EVENT_KEY_RELEASE || !this.isFocused) 
        {
            return ret;
        }	
        switch(keycode) 
        {
            case Volt.KEY_JOYSTICK_UP:
                    this.arrowUpMouseClick();
                    ret = true;
                break;
            case Volt.KEY_JOYSTICK_DOWN:	
                    this.arrowDownMouseClick();
                    ret = true;
                break;
            case Volt.KEY_JOYSTICK_OK:	
                    this.expandBtnMouseClick();
                    ret = true;
                break;
            case Volt.KEY_RETURN:	
                    if(this.expanded){
                        this.reset();
                    }
                    ret = true;
                break;
            default:
                break;
        } 					
        return ret;
	};    
}
TextArea.prototype = new ControlBase();
exports = TextArea;