/** 
 * @author 
 * @fileoverview Definition of verifyLongPress
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var VerifylongPressModule = function(){
	
	var constructor=this.m_create;
	if(constructor){
		constructor.apply(this, arguments);
	}
}

VerifylongPressModule.prototype = {
	
	m_intervalTime:0,
	m_timerInc:null,
	
	m_callbackFunc:null,
	m_bLongPressChecking:false,
	
	m_dealKeyHandler:function(){
		
		if (this.m_callbackFunc != null) {
			this.m_callbackFunc();
		}
		this.m_timerInc = null;
	},
	
	m_create:function(){
		if (typeof arguments[0] == 'object') {
			// ARGUMENTS JSON
			var paramOption = arguments[0];
			this.m_intervalTime = paramOption['timer'];
			this.m_callbackFunc = paramOption['callBack'].bind(paramOption['callBack_Context']);
			
			return true;
			
		} else {
			// ARGUMENTS ......
			if (arguments.length == 1) {
				if (typeof arguments[0] != 'number') {
					return false;
				} else {
					this.m_intervalTime = arguments[0];
				}
			}
			
			if (arguments.length == 2) {
				if (typeof arguments[0] != 'number') {
					return false;
				} else {
					this.m_intervalTime = arguments[0];
				}
				
				if (typeof arguments[1] != 'function') {
					return false;
				} else {
					this.m_callbackFunc = arguments[1].bind(null);
				}
			}
			
			if (arguments.length == 3) {
				if (typeof arguments[0] != 'number') {
					return false;
				} else {
					this.m_intervalTime = arguments[0];
				}
				
				if (typeof arguments[1] != 'function' || typeof arguments[2] != 'object') {
					return false;
				} else {
					this.m_callbackFunc = arguments[1].bind(arguments[2]);
				}
			}
			return true;
		}
	},
	
	set IntervalTime(intervalTime){
		this.m_intervalTime = intervalTime;
	},
	
	setCallbackFunc:function(callbackFunc, context){
		if (typeof callbackFunc == 'function'){
			this.m_callbackFunc = callbackFunc.bind(context);
		}		
	},

	clearLongPressTicker:function(){
		if (this.m_timerInc != null) {
			Volt.clearTimeout(this.m_timerInc);
		}
		this.m_timerInc = null;
		this.m_bLongPressChecking = false;
	},
	
	keyAction:function(keyEvent){
	
		if (keyEvent.type == Volt.EVENT_KEY_PRESS) {			
			this.m_bLongPressChecking = true;
			if (this.m_intervalTime != 0) {
				
				var keyHandlerBind = this.m_dealKeyHandler.bind(this);
				this.m_timerInc = Volt.setTimeout(keyHandlerBind, this.m_intervalTime);
			}
			 return false;
		} else {
			if(this.m_bLongPressChecking == true){
				if (this.m_timerInc != null) {
					Volt.clearTimeout(this.m_timerInc);
					this.m_timerInc = null;
					return false;
				} else {
					if (this.m_intervalTime == 0) {
						return false;
					} else {
						return true;
					}
				}	
				this.m_bLongPressChecking = false;
			}
			else
			{
				return -1;
			}
		}
		
	}
}

exports = VerifylongPressModule;

