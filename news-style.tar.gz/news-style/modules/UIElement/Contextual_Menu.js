 /** 
 * @author  
 * @fileoverview Definition of Contextual_Menu
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");
CursorComponent	= Volt.require("modules/CursorComponent.js");

/*logArea = new TextWidget({
	x: 0,
	y: 200,
	width: 1920,
	height: 1080,
	textColor: {r: 255, g: 255, b: 255, a: 255},
	text: "logArea",
	parent: scene,
});

function logTest(text, append) {
	if (append) {
		logArea.text += "\n"+text.toString();
	} else {
		logArea.text = text.toString();
	}
}*/

log = function(message) {
	print(message);
}

assert = function(condition, message) {
	if (!condition) {
		print(message);
		throw new Error(message);
    }
};

Contextual_Menu = function() {
	this.m_TopMargin = 0;			// default :0
	this.m_BottomMargin = 0;		// default :0
	this.m_ItemHeight = 0;			// default :72
	this.m_ItemWidth = 0;			// default :782
	this.m_ItemSpace = 0;			// default :0
	this.m_TotalDataNumber = 0;		// need
	this.m_RenderType = null;		// need
	this.m_FirstItemOffset = 0;		// default :0
	this.m_EnlargeHeight = 0;		// default :this.m_ItemHeight
	this.m_EnlargeWidth = 0;		// default :this.m_ItemWidth
	this.m_Looping = false;			// default :false
	this.m_Style = Contextual_Menu.Style.VERTICAL;	//default :vertical
	
	this.m_CurrDataIndex = 0;
	this.m_RenderHeadDataIndex = 0; // data index of render head
	
	this.m_FocusItemIndex = 0; // an cursor used to pointer to the index of current page
	this.m_DisplayAreaItemsNumber = 0; // items number of display area
	this.m_CurrRenderIndex = 0;
	this.m_RenderItemNumber = 0; // total number of render items
	this.m_RenderArray = null; // array used to store render items
	
	this.m_BufferNumer = 2;
	
	this.m_ItemLoadCB = null; //called while item load data		param: index (data index which needs to load)
	this.m_ItemUnloadCB = null; // called while item unload data	param: index (data index which needs to unLoad)
	this.m_FocusIndexChangedCB = null; // called while focued change to new index		param: oldIndex(data index before changing), newIndex(data index after changing)
	this.m_DataChangeCB = null; // called when data changed		param: index(index of dataItem),  newData(data after changing)
	this.m_ReachBoundaryCB = null; // called when press left/right key or reach top or buttom item param: keycode
	
	this.m_DisplayBG = null;
	this.m_ScrollWidget = null;
	
	this.m_ScrollWidgetPosition = 0;
	
	//up and down arrow
	this.m_UpArrowWidget = null;
	this.m_DownArrowWidget = null;
	this.m_UpArrowInfo = null;
	this.m_DownArrowInfo = null;
	
	this.m_Cursor = null;
	this.m_CursorOffsetX = 0;
	this.m_CursorOffsetY = 0;
	this.m_CursorHeight = 0;
	this.m_CursorWidth = 0;
	
	this.m_IsVertical = true;
	this.m_IsMouseOutOverOn = false;
	this.m_IsMouseClickOn = false;
	this.m_DimItemIndex = [];
	//this.m_unDimItemIndex = [];
	
	Object.defineProperties(this, {
		currentIndex: {
			configurable: false,
			get: function() {
				return this.m_CurrDataIndex;
			},
			set: function(index) {
				this.m_SetFocusDataIndex(index);
			}
		},
	});
	
	/**************************
	Virtual Functions, Inherited from father 
	***************************/
	/**
	* This function creates a Contextual_Menu object. 
	* @param {Object} param for this function.
	* @return void
	* @example //This example create a Contextual_Menu object.
	*var test = new Contextual_Menu();
	*test.create({x: 500,
	*			 y: 100,
	*			 width: 782,
	*			 height: 500,
	*			 parent: scene,
	*			 color: {r: 0, g: 255, b: 255},
	*			 itemWidth: 782,
	*			 itemHeight: 80,
	*			 itemSpace: 20,
	*			 firstItemOffset: 50,
	*			 topMargin: 40,
	*			 bottomMargin: 40,
	*			 totalDataNumber: 20,
	*			 renderType: Renders.BothListCheckRender,
	*			 upArrow: {highlightSrc: "sample/Arrow/popup_sublist_arrow_up_f.png", unHighlightSrc: "sample/Arrow/popup_sublist_arrow_up_n.png", 
	*				dimSrc:"sample/Arrow/popup_sublist_arrow_up_d.png", x: 300, y: 0},
	*			 downArrow: {highlightSrc: "sample/Arrow/popup_sublist_arrow_down_n.png", unHighlightSrc: "sample/Arrow/popup_sublist_arrow_down_f.png", 
	*				dimSrc:"sample/Arrow/popup_sublist_arrow_down_d.png", x: 300, y: 460},
	*			 looping: true,
	*			 style: Contextual_Menu.Style.VERTICAL,
	*});
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(param) {
		this.m_InitMembers(param);
		this.m_InitRenderItems(param);
	};
	
	this.t_getFocus = function() {
		if (this.m_CurrRenderIndex+this.m_RenderHeadDataIndex > this.m_TotalDataNumber-1) {
			return;
		}
		
		if (this.m_UpArrowInfo) {
			this.m_UpArrowWidget.src = this.m_UpArrowInfo?this.m_UpArrowInfo.highlightSrc:"";
			this.m_UpArrowWidget.src = this.m_UpArrowInfo?this.m_UpArrowInfo.highlightSrc:"";
		}
			
		if (this.m_DownArrowInfo) {
			this.m_DownArrowWidget.src = this.m_DownArrowInfo?this.m_DownArrowInfo.highlightSrc:"";
			this.m_DownArrowWidget.src = this.m_DownArrowInfo?this.m_DownArrowInfo.highlightSrc:"";
		}
		
		this.m_RenderArray[this.m_CurrRenderIndex].getFocus();
		
		var _this = this;
		if (this.m_Cursor) {
			Volt.setTimeout(function() {_this.m_moveCursor(_this.m_DisplayBG.x, _this.m_DisplayBG.y, 100);}, 100);
			Volt.setTimeout(function() {_this.m_Cursor.show();}, 200);
		}
		this.m_EnlargeFocusItem();
	};
	
	this.t_loseFocus = function() {
		if (this.m_CurrRenderIndex+this.m_RenderHeadDataIndex > this.m_TotalDataNumber-1) {
			return;
		}
		this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
		if (this.m_UpArrowInfo) {
			this.m_UpArrowWidget.src = this.m_UpArrowInfo?this.m_UpArrowInfo.unHighlightSrc:"";
		}
		if (this.m_DownArrowInfo) {
			this.m_DownArrowWidget.src = this.m_DownArrowInfo?this.m_DownArrowInfo.unHighlightSrc:"";
		}
		if (this.m_Cursor) {
			this.m_Cursor.hide();
		}
		this.m_DiminishFocusItem();
	};
	
	this.t_show = function() {
	};
	
	this.t_hide = function() {
	};
	
	this.t_destroy = function() {	
		for(var i=0; i<this.m_RenderItemNumber; ++i) {
			this.m_RenderArray[i].destroy();
		}
		
		if (this.m_ScrollWidget != null){
			this.m_ScrollWidget.destroy();
			this.m_ScrollWidget = null;
		}
		
		
		if (this.m_UpArrowWidget != null){
			this.m_UpArrowWidget.destroy();
			this.m_UpArrowWidget = null;
		}
		
		if (this.m_DownArrowWidget != null){
			this.m_DownArrowWidget.destroy();
			this.m_DownArrowWidget = null;
		}
		
		if (this.m_DisplayBG != null){
			this.m_DisplayBG.destroy();
			this.m_DisplayBG = null;
		}
		
		this.m_DimItemIndex.splice(0, this.m_DimItemIndex.length);
		this.m_DimItemIndex = null;
		this.m_RenderArray.splice(0, this.m_RenderArray.length);
		this.m_RenderArray = null;
	};
	
	this.t_getDim = function(){
		for(var i=0; i<this.m_RenderItemNumber; ++i) {
			this.m_RenderArray[i].getDim();
		}
		
		if (this.m_UpArrowInfo) {
			this.m_UpArrowWidget.src = this.m_UpArrowInfo?this.m_UpArrowInfo.dimSrc:"";
		}
		
		if (this.m_DownArrowInfo) {
			this.m_DownArrowWidget.src = this.m_DownArrowInfo?this.m_DownArrowInfo.dimSrc:"";
		}
		
		if (this.m_Cursor) {
			this.m_Cursor.hide();
		}
	};
	
	this.t_loseDim = function(){
		for(var i=0; i<this.m_RenderItemNumber; ++i) {
			this.m_RenderArray[i].loseDim();
		}
		
		if (this.m_UpArrowInfo) {
			if (this.isFocused){
				this.m_UpArrowWidget.src = this.m_UpArrowInfo?this.m_UpArrowInfo.highlightSrc:"";
			}
			else{
				this.m_UpArrowWidget.src = this.m_UpArrowInfo?this.m_UpArrowInfo.unHighlightSrc:"";
			}
		}
		
		if (this.m_DownArrowInfo) {
			if (this.isFocused){
				this.m_DownArrowWidget.src = this.m_DownArrowInfo?this.m_DownArrowInfo.highlightSrc:"";
			}
			else{
				this.m_DownArrowWidget.src = this.m_DownArrowInfo?this.m_DownArrowInfo.unHighlightSrc:"";
			}	
		}
		
		if (this.m_Cursor) {
			if (this.isFocused) {
				this.m_Cursor.show();
			}
		}
	};
	
	/**
	* This function deals with Contextual_Menu object's key input event. 
	* @param {Object} param for this function.
	* @return void
	* @example //This example deals with Contextual_Menu object's key input event.
	*test.keyHandler(keycode, keytype);
	* @since The version 1.0 this function is added.
	*/	
	this.t_keyHandler = function(keycode, keytype){
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return true;
		}
		
		if (this.m_RenderArray[this.m_CurrRenderIndex].keyHandler(keycode, keytype)) {
			if (this.m_RenderArray[this.m_CurrRenderIndex].IsDataChanged()) {
				this.m_DataChangedCBCall(this.m_RenderArray[this.m_CurrRenderIndex].GetDataIndex(), this.m_RenderArray[this.m_CurrRenderIndex].GetDataItem());
				this.m_RenderArray[this.m_CurrRenderIndex].ResetDataChangeFlag();
			}
			return true;
		}
		if (this.m_IsVertical) {
			switch (keycode) {
				case Volt.KEY_JOYSTICK_UP:
					return this.m_keyUpHandler();
					break;
				case Volt.KEY_JOYSTICK_DOWN:
					return this.m_keyDownHandler();
					break;
				case Volt.KEY_JOYSTICK_LEFT:
					this.m_ReachBoundaryCBCall(keycode);
					return true;
					break;
				case Volt.KEY_JOYSTICK_RIGHT:
					this.m_ReachBoundaryCBCall(keycode);
					return true;
					break;
			}
		} else {
			switch (keycode) {
				case Volt.KEY_JOYSTICK_LEFT:
					return this.m_keyUpHandler();
					break;
				case Volt.KEY_JOYSTICK_RIGHT:
					return this.m_keyDownHandler();
					break;
				case Volt.KEY_JOYSTICK_UP:
					this.m_ReachBoundaryCBCall(keycode);
					return true;
					break;
				case Volt.KEY_JOYSTICK_DOWN:
					this.m_ReachBoundaryCBCall(keycode);
					return true;
					break;
			}
		}
		return false;
	};
	
	this.t_MouseOverOut = function(isOnFlag){
		if (isOnFlag){
			for(var i=0; i<this.m_RenderItemNumber; ++i) {
				this.m_RenderArray[i].enableMouseOverOut(true);
			}
			
			this.m_IsMouseOutOverOn = true;

		}
		else{
			for(var i=0; i<this.m_RenderItemNumber; ++i) {
				this.m_RenderArray[i].enableMouseOverOut(false);
			}
		}
	}
	
	this.t_MouseClick = function(isOnFlag){
		if (isOnFlag){
			var _this = this;
			
			if (this.m_UpArrowInfo) {
				this.m_UpArrowWidget.addEventListener("OnMouseClick", function() {
					_this.pageUp();
				});
			}

			if (this.m_DownArrowInfo){
				this.m_DownArrowWidget.addEventListener("OnMouseClick", function() {
					_this.pageDown();
				});		
			}
			
			for(var i=0; i<this.m_RenderItemNumber; ++i) {
				this.m_RenderArray[i].enableMouseClick(true);
			}
			
			this.m_IsMouseClickOn = true;
		}
		else{
			if (this.m_UpArrowInfo) {
				this.m_UpArrowWidget.removeEventListener("OnMouseClick", function() {
					_this.pageUp();
				});
			}

			if (this.m_DownArrowInfo){
				this.m_DownArrowWidget.removeEventListener("OnMouseClick", function() {
					_this.pageDown();
				});		
			}
			
			for(var i=0; i<this.m_RenderItemNumber; ++i) {
				this.m_RenderArray[i].enableMouseClick(false);
			}
			
			this.m_IsMouseClickOn = false;
		}
	};
	
	/**************************
	Private Functions 
	***************************/
	this.m_InitMembers = function(param) {
		this.m_ItemHeight = param.itemHeight? param.itemHeight: 72;
		this.m_ItemWidth = param.itemWidth? param.itemWidth: 782;
		this.m_ItemSpace = param.itemSpace? param.itemSpace: 0;
		this.m_TopMargin = typeof(param.topMargin)=="undefined"? 0: param.topMargin;
		this.m_BottomMargin = typeof(param.bottomMargin)=="undefined"? 0: param.bottomMargin;
		this.m_FirstItemOffset = typeof(param.firstItemOffset)=="undefined"? 0: param.firstItemOffset;
		this.m_EnlargeHeight = param.enlargeHeight? param.enlargeHeight: this.m_ItemHeight;
		this.m_EnlargeWidth = param.enlargeWidth? param.enlargeWidth: this.m_ItemWidth;
		this.m_Looping = typeof(param.looping)!="undefined" ? param.looping: false;
		this.m_Style = typeof(param.style)!="undefined" ? param.style: Contextual_Menu.Style.VERTICAL;
		this.m_IsVertical = this.m_Style == Contextual_Menu.Style.VERTICAL;
		
		if (this.m_IsVertical) {
			if (!param.width) {
				this.width = this.m_ItemWidth; // change the width of ControlBase
			} else {
				assert((param.width>=this.m_ItemWidth), "[Contextual_Menu.js m_InitMembers ERROR] Width value is too small!");
				this.width = param.width;
			}
			if (!param.height) {
				this.height = (this.m_TopMargin+this.m_BottomMargin+this.m_ItemHeight*6+this.m_ItemSpace*5); // change the height of ControlBase
			} else { 
				assert(param.height >= (this.m_TopMargin+this.m_BottomMargin+this.m_EnlargeHeight), "[Contextual_Menu.js m_InitMembers ERROR] Height value is too small!");
				this.height = param.height;
			}
		} else {
			if (!param.width) {
				this.width = (this.m_TopMargin+this.m_BottomMargin+this.m_ItemWidth*6+this.m_ItemSpace*5); // change the width of ControlBase
			} else {
				assert((param.width>=(this.m_TopMargin+this.m_BottomMargin+this.m_EnlargeWidth)), "[Contextual_Menu.js m_InitMembers ERROR] Width value is too small!");
				this.width = param.width;
			}
			if (!param.height) {
				this.height = this.m_ItemHeight; // change the height of ControlBase
			} else {
				assert(param.height >= this.m_ItemHeight, "[Contextual_Menu.js m_InitMembers ERROR] Height value is too small!");
				this.height = param.height;
			}
		}
		
		assert((param.totalDataNumber && param.totalDataNumber != 0), "[Contextual_Menu.js m_InitMembers ERROR] Please specify totalDataNumber while creating");
		this.m_TotalDataNumber = param.totalDataNumber;
		
		assert(param.renderType, "[Contextual_Menu.js m_InitMembers ERROR] Please specify renderType while creating");
		this.m_RenderType = param.renderType;
		
		this.m_RenderArray = [];
		
		this.m_ItemLoadCB = null;
		this.m_ItemUnloadCB = null;
		this.m_FocusIndexChangedCB = null;
		this.m_DataChangeCB = null;
		this.m_ReachBoundaryCB = null;
		
		this.m_FocusItemIndex = 0;
		//Calculate numbers of render items (which is also length of m_RenderArray)
		this.m_DisplayAreaItemsNumber = this.m_IsVertical? 
		(Math.floor((this.height-this.m_TopMargin-this.m_BottomMargin-this.m_EnlargeHeight-this.m_FirstItemOffset)/(this.m_ItemHeight+this.m_ItemSpace))+1): 
		(Math.floor((this.width-this.m_TopMargin-this.m_BottomMargin-this.m_EnlargeWidth-this.m_FirstItemOffset)/(this.m_ItemWidth+this.m_ItemSpace))+1);
		this.m_RenderItemNumber = this.m_DisplayAreaItemsNumber+this.m_BufferNumer*2;
		this.m_CurrRenderIndex = this.m_BufferNumer;
		
		this.m_CurrDataIndex = 0;
		this.m_ScrollWidgetPosition = 0;
		this.m_RenderHeadDataIndex = -this.m_BufferNumer;
		
		this.m_UpArrowWidget = null;
		this.m_DownArrowWidget = null;
		this.m_UpArrowInfo = param.upArrow;
		this.m_DownArrowInfo = param.downArrow;
		
		this.m_CursorOffsetX = param.cursorOffsetX? param.cursorOffsetX: 0;
		this.m_CursorOffsetY = param.cursorOffsetY? param.cursorOffsetY: 0;
		this.m_CursorHeight = param.cursorHeight? param.cursorHeight: this.m_ItemHeight;
		this.m_CursorWidth = param.cursorWidth? param.cursorWidth: this.m_ItemWidth;
	};
	
	this.m_InitRenderItems = function(param) {
		this.m_DisplayBG = new Widget({
			x: this.m_IsVertical? 0: this.m_TopMargin,
			y: this.m_IsVertical? this.m_TopMargin: 0,
			height: this.m_IsVertical? (this.height-this.m_TopMargin-this.m_BottomMargin): this.m_ItemHeight,
			width: this.m_IsVertical? this.m_ItemWidth: (this.width-this.m_TopMargin-this.m_BottomMargin),
			color: {r: 0, g: 0, b: 0, a: 0},
			parent: param.parent,
		});
		this.m_DisplayBG.cropOverflow = true;
		this.m_DisplayBG.origin = this.m_IsVertical? {x: 0.5, y: 0}: {x: 0, y: 0.5};
		this.m_DisplayBG.anchor = this.m_IsVertical? {x: 0.5, y: 0}: {x: 0, y: 0.5};
		
		this.m_ScrollWidget = new Widget({
			x: this.m_IsVertical? 0: this.m_ScrollWidgetPosition,
			y: this.m_IsVertical? this.m_ScrollWidgetPosition: 0,
			color: {r: 0, g: 0, b: 0, a: 0},
			parent: this.m_DisplayBG,
		});
		
		var offsetPos = this.m_IsVertical? this.m_FirstItemOffset-(this.m_ItemHeight+this.m_ItemSpace)*this.m_BufferNumer
										 : this.m_FirstItemOffset-(this.m_ItemWidth+this.m_ItemSpace)*this.m_BufferNumer;
		for (var index = -this.m_BufferNumer; index < this.m_RenderItemNumber-this.m_BufferNumer; index++) {
			var randerItem = this.m_CreateItem(this.m_IsVertical? 0: offsetPos, this.m_IsVertical? offsetPos: 0);
			offsetPos += this.m_IsVertical? (this.m_ItemHeight+this.m_ItemSpace): (this.m_ItemWidth+this.m_ItemSpace);
			if (index < 0) {
				randerItem.hide();
			} else {
				randerItem.show();
			}
			this.m_RenderArray.push(randerItem);
		}
		
		if (param.cursorImageSrc) {
			this.m_Cursor = new CursorComponent(param.cursorImageSrc);
			this.m_Cursor.parent = param.parent;
			this.m_Cursor.hide();
		}
		
		if (typeof(this.m_UpArrowInfo)!="undefined") {			
			this.m_UpArrowWidget = new ImageWidget({
				x: this.m_UpArrowInfo.x,
				y: this.m_UpArrowInfo.y,
				src: this.m_UpArrowInfo.unHighlightSrc,
				parent: param.parent,
			});
		}
		if (this.m_UpArrowWidget != null){
			this.m_UpArrowWidget.hide();
		}
		

		if (typeof(this.m_DownArrowInfo)!="undefined") {		
			this.m_DownArrowWidget = new ImageWidget({
				x: this.m_DownArrowInfo.x,
				y: this.m_DownArrowInfo.y,
				src: this.m_DownArrowInfo.unHighlightSrc,
				parent: param.parent,
			})
		}
		
		if (this.m_TotalDataNumber <= this.m_DisplayAreaItemsNumber){
			if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.hide();
			}
		}
	};
	
	this.m_CreateItem = function(x, y) {
		var randerItem = new this.m_RenderType();
		randerItem.create({
			x: x,
			y: y,
			width : this.m_ItemWidth,
			height :this.m_ItemHeight,
			parent : this.m_ScrollWidget,
			enlargeHeight: this.m_EnlargeHeight,
			enlargeWidth: this.m_EnlargeWidth,
		});
		randerItem.id = 1000;
		
		/****************item mouse***********************/
		var _this = this;
		randerItem.setMouseOverOutCallback({overCallback:function() {
				var oldIndex = _this.m_CurrRenderIndex;
				var newIndex = randerItem.GetDataIndex() - _this.m_RenderHeadDataIndex;
				var offset = newIndex - oldIndex;
				if (offset > 0) {
					for (var i = 0; i<offset; i++) {
						_this.m_keyDownHandler();
					}
				} else {
					for (var i = 0; i<-offset; i++) {
						_this.m_keyUpHandler();
					}
				}
			}});
		
		randerItem.setMouseClickCallback(function() {
			_this.t_keyHandler(Volt.KEY_JOYSTICK_OK);
		});
		
		if (this.m_IsMouseOutOverOn){
			randerItem.enableMouseOverOut(true);
		}
		
		if (this.m_IsMouseClickOn){
			randerItem.enableMouseClick(true);
		}
		
		return randerItem;
	};
	
	this.m_EnlargeFocusItem = function() {
		var offset = this.m_IsVertical? (this.m_EnlargeHeight - this.m_ItemHeight): (this.m_EnlargeWidth - this.m_ItemWidth);
		for (var i = this.m_CurrRenderIndex+1; i<this.m_RenderItemNumber; ++i) {
			this.m_IsVertical? this.m_RenderArray[i].y += offset: this.m_RenderArray[i].x += offset;
		}
		this.m_ResetPosition();
	};
	
	this.m_DiminishFocusItem = function() {
		var offset = this.m_IsVertical? (this.m_EnlargeHeight - this.m_ItemHeight): (this.m_EnlargeWidth - this.m_ItemWidth);
		for (var i = this.m_CurrRenderIndex+1; i<this.m_RenderItemNumber; ++i) {
			this.m_IsVertical? this.m_RenderArray[i].y -= offset: this.m_RenderArray[i].x -= offset;
		}
		this.m_ResetPosition();
	};
	
	this.m_ResetPosition = function() {
		for (var i = 0; i<this.m_RenderItemNumber; ++i) {
			this.m_RenderArray[i].optY = this.m_RenderArray[i].y;
			this.m_RenderArray[i].optX = this.m_RenderArray[i].x;
		}
	};
	
	this.m_changeFocus = function(oldIndex, newIndex) {
		this.m_RenderArray[oldIndex].loseFocus();
		this.m_RenderArray[newIndex].getFocus();
		if (oldIndex > newIndex) { // up key
			for (var i = newIndex+1; i<=oldIndex; ++i) {
				if (this.m_IsVertical) {
					if (typeof (this.m_RenderArray[i].optY) == "undefined") {
						this.m_RenderArray[i].optY = this.m_RenderArray[i].y;
					}
					this.m_RenderArray[i].optY = this.m_RenderArray[i].optY + (this.m_EnlargeHeight - this.m_ItemHeight);
					this.m_RenderArray[i].animate("y", this.m_RenderArray[i].optY, 100);
				} else {
					if (typeof (this.m_RenderArray[i].optX) == "undefined") {
						this.m_RenderArray[i].optX = this.m_RenderArray[i].x;
					}
					this.m_RenderArray[i].optX = this.m_RenderArray[i].optX + (this.m_EnlargeWidth - this.m_ItemWidth);
					this.m_RenderArray[i].animate("x", this.m_RenderArray[i].optX, 100);
				}
			}
		} else {
			for (var i = oldIndex+1; i<= newIndex; ++i) {
				if (this.m_IsVertical) {
					if (typeof (this.m_RenderArray[i].optY) == "undefined") {
						this.m_RenderArray[i].optY = this.m_RenderArray[i].y;
					}
					this.m_RenderArray[i].optY = this.m_RenderArray[i].optY - (this.m_EnlargeHeight - this.m_ItemHeight);
					this.m_RenderArray[i].animate("y", this.m_RenderArray[i].optY, 100);
				} else {
					if (typeof (this.m_RenderArray[i].optX) == "undefined") {
						this.m_RenderArray[i].optX = this.m_RenderArray[i].x;
					}
					this.m_RenderArray[i].optX = this.m_RenderArray[i].optX - (this.m_EnlargeWidth - this.m_ItemWidth);
					this.m_RenderArray[i].animate("x", this.m_RenderArray[i].optX, 100);
				}
			}
		}
	};
	
	this.m_moveCursor = function(x, y, duration, callback) {
		if (this.m_Cursor) {
			this.m_Cursor.move( this.m_IsVertical? (this.m_CursorOffsetX+x): (this.m_FirstItemOffset+this.m_CursorOffsetX+x), 
								this.m_IsVertical? (this.m_FirstItemOffset+this.m_CursorOffsetY+y): (this.m_CursorOffsetY+y), 
								this.m_CursorWidth, 
								this.m_CursorHeight, 
								duration, 
								callback);
		}
	};
	
	this.m_TopLooping = function() {
		if (!this.m_Looping) 
				return;
				
		if ((this.m_TotalDataNumber >= 2) && (this.m_TotalDataNumber == this.m_DisplayAreaItemsNumber)) {
			this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
			this.m_CurrRenderIndex = this.m_RenderItemNumber - this.m_BufferNumer-1;
			this.m_RenderArray[this.m_CurrRenderIndex].getFocus();
			this.m_UpdateDisplayStatus();
			this.m_EnlargeFocusItem();
			this.m_FocusItemIndex = this.m_DisplayAreaItemsNumber - 1;
			this.m_CurrDataIndex = this.m_TotalDataNumber-1;
			this.m_moveCursor(this.m_IsVertical? this.m_DisplayBG.x: this.m_DisplayBG.x+(this.m_ItemWidth+this.m_ItemSpace)*this.m_FocusItemIndex, 
						  this.m_IsVertical? this.m_DisplayBG.y+(this.m_ItemHeight+this.m_ItemSpace)*this.m_FocusItemIndex: this.m_DisplayBG.y, 
						  100);
			return;			  
		}
		else if ((this.m_TotalDataNumber < this.m_DisplayAreaItemsNumber) ||
		(this.m_TotalDataNumber == 1)){
			return;		
		}
				
		this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
		this.m_DiminishFocusItem();
		
		this.m_ScrollWidgetPosition += this.m_IsVertical? (this.m_ItemHeight+this.m_ItemSpace)*this.m_DisplayAreaItemsNumber: 
														  (this.m_ItemWidth+this.m_ItemSpace)*this.m_DisplayAreaItemsNumber;
		var _this = this;
		this.m_ScrollWidget.animate(this.m_IsVertical? "y": "x", this.m_ScrollWidgetPosition, 100, "sine", function() {
			
			_this.m_RenderHeadDataIndex = _this.m_TotalDataNumber-_this.m_DisplayAreaItemsNumber-_this.m_BufferNumer;
			_this.update();
			for (var i = 0; i<_this.m_RenderItemNumber; i++) {
				_this.m_IsVertical? (_this.m_RenderArray[i].y = _this.m_FirstItemOffset+(_this.m_RenderHeadDataIndex+i)*(_this.m_ItemHeight+_this.m_ItemSpace))
				                  :(_this.m_RenderArray[i].x = _this.m_FirstItemOffset+(_this.m_RenderHeadDataIndex+i)*(_this.m_ItemWidth+_this.m_ItemSpace));
			}
			_this.m_ScrollWidgetPosition = _this.m_IsVertical? (_this.m_DisplayAreaItemsNumber-_this.m_TotalDataNumber)*(_this.m_ItemHeight+_this.m_ItemSpace)
															 :(_this.m_DisplayAreaItemsNumber-_this.m_TotalDataNumber)*(_this.m_ItemWidth+_this.m_ItemSpace);
			_this.m_IsVertical? (_this.m_ScrollWidget.y = _this.m_ScrollWidgetPosition-_this.m_TotalDataNumber*(_this.m_ItemHeight+_this.m_ItemSpace))
							  :(_this.m_ScrollWidget.x = _this.m_ScrollWidgetPosition-_this.m_TotalDataNumber*(_this.m_ItemWidth+_this.m_ItemSpace));
			_this.m_ScrollWidget.animate(_this.m_IsVertical? "y": "x", _this.m_ScrollWidgetPosition, 100, "sine");
			_this.m_CurrRenderIndex = _this.m_RenderItemNumber-_this.m_BufferNumer-1;
			
			_this.m_resetDimFlag();
			_this.m_RenderArray[_this.m_CurrRenderIndex].getFocus();
			_this.m_CurrDataIndex = _this.m_TotalDataNumber-1;
			_this.m_UpdateDisplayStatus();
			_this.m_EnlargeFocusItem();
		});
		this.m_FocusItemIndex = this.m_DisplayAreaItemsNumber - 1;
		this.m_moveCursor(this.m_IsVertical? this.m_DisplayBG.x: this.m_DisplayBG.x+(this.m_ItemWidth+this.m_ItemSpace)*this.m_FocusItemIndex, 
						  this.m_IsVertical? this.m_DisplayBG.y+(this.m_ItemHeight+this.m_ItemSpace)*this.m_FocusItemIndex: this.m_DisplayBG.y, 
						  100);
		
		if (this.m_TotalDataNumber > this.m_DisplayAreaItemsNumber){
			if (this.m_UpArrowWidget != null){
				this.m_UpArrowWidget.show();
			}
			
			if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.hide();
			}		
		}
	};
	
	this.m_BottomLooping = function() {
		if (!this.m_Looping) 
			return;
			
		if ((this.m_TotalDataNumber >= 2) && (this.m_TotalDataNumber == this.m_DisplayAreaItemsNumber)) {
			this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
			this.m_CurrRenderIndex = this.m_BufferNumer;
			this.m_RenderArray[this.m_CurrRenderIndex].getFocus();
			this.m_CurrDataIndex = 0;
			this.m_UpdateDisplayStatus();
			this.m_EnlargeFocusItem();
			this.m_FocusItemIndex = 0;
			this.m_moveCursor(this.m_IsVertical? this.m_DisplayBG.x: this.m_DisplayBG.x+(this.m_ItemWidth+this.m_ItemSpace)*this.m_FocusItemIndex, 
						  this.m_IsVertical? this.m_DisplayBG.y+(this.m_ItemHeight+this.m_ItemSpace)*this.m_FocusItemIndex: this.m_DisplayBG.y, 
						  100);
			return;			  
		}
		else if ((this.m_TotalDataNumber < this.m_DisplayAreaItemsNumber) ||
		(this.m_TotalDataNumber == 1)){
			return;		
		}
			
		this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
		this.m_DiminishFocusItem();
		
		this.m_ScrollWidgetPosition -= this.m_IsVertical? ((this.m_ItemHeight+this.m_ItemSpace)*this.m_DisplayAreaItemsNumber)
														: ((this.m_ItemWidth+this.m_ItemSpace)*this.m_DisplayAreaItemsNumber);
		var _this = this;
		this.m_ScrollWidget.animate(this.m_IsVertical? "y": "x", this.m_ScrollWidgetPosition, 100, "sine", function() {
			_this.m_RenderHeadDataIndex = -_this.m_BufferNumer;
			_this.update();
			for (var i = 0; i<_this.m_RenderItemNumber; i++) {
				_this.m_IsVertical? (_this.m_RenderArray[i].y = _this.m_FirstItemOffset+(_this.m_RenderHeadDataIndex+i)*(_this.m_ItemHeight+_this.m_ItemSpace))
								 : (_this.m_RenderArray[i].x = _this.m_FirstItemOffset+(_this.m_RenderHeadDataIndex+i)*(_this.m_ItemWidth+_this.m_ItemSpace));
			}
			_this.m_ScrollWidgetPosition = 0;
			_this.m_IsVertical? (_this.m_ScrollWidget.y = _this.m_ScrollWidgetPosition+_this.m_TotalDataNumber*(_this.m_ItemHeight+_this.m_ItemSpace))
							 : (_this.m_ScrollWidget.x = _this.m_ScrollWidgetPosition+_this.m_TotalDataNumber*(_this.m_ItemWidth+_this.m_ItemSpace));
			_this.m_ScrollWidget.animate(_this.m_IsVertical? "y": "x", _this.m_ScrollWidgetPosition, 100, "sine");
			_this.m_CurrRenderIndex = _this.m_BufferNumer;
			_this.m_resetDimFlag();
			_this.m_RenderArray[_this.m_CurrRenderIndex].getFocus();
			_this.m_CurrDataIndex = 0;
			_this.m_UpdateDisplayStatus();
			_this.m_EnlargeFocusItem();
		});
		this.m_FocusItemIndex = 0;
		this.m_moveCursor(this.m_IsVertical? this.m_DisplayBG.x: this.m_DisplayBG.x+(this.m_ItemWidth+this.m_ItemSpace)*this.m_FocusItemIndex, 
						  this.m_IsVertical? this.m_DisplayBG.y+(this.m_ItemHeight+this.m_ItemSpace)*this.m_FocusItemIndex: this.m_DisplayBG.y, 
						  100);
		
		if (this.m_TotalDataNumber > this.m_DisplayAreaItemsNumber){
			if (this.m_UpArrowWidget != null){
				this.m_UpArrowWidget.hide();
			}
			
			if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.show();
			}	
		}
	};
	
	this.m_keyUpHandler = function() {
		if (this.isDimed || this.m_TotalDataNumber == 0){
			return;
		}
		
		if (this.m_CurrDataIndex == 0) {
			this.m_ReachBoundaryCBCall(this.m_IsVertical? Volt.KEY_JOYSTICK_UP: Volt.KEY_JOYSTICK_LEFT);
			this.m_TopLooping();
			return true;
		}
		
		//call focuschangedCB while data index changed
		var oldDataIndex = this.m_CurrDataIndex;
		var newDataIndex = --this.m_CurrDataIndex;
		this.m_FocusChangedCBCall(oldDataIndex, newDataIndex);
		
		//change focus from old render to new render
		var oldIndex = this.m_CurrRenderIndex;
		var newIndex = --this.m_CurrRenderIndex;
		this.m_changeFocus(oldIndex, newIndex);
		
		//when index item over the display area, scroll the ScrollWidget
		if (this.m_FocusItemIndex == 0) {
			//destroy tail item and create an new item before head
			this.m_RenderArray[this.m_RenderItemNumber-1].destroy();
			this.m_RenderArray.pop();
			var headItem = this.m_CreateItem(this.m_IsVertical? 0: this.m_RenderArray[0].x-this.m_ItemWidth-this.m_ItemSpace
							, this.m_IsVertical? this.m_RenderArray[0].y-this.m_ItemHeight-this.m_ItemSpace: 0);
			this.m_RenderArray.unshift(headItem);
			++this.m_CurrRenderIndex;
			if (this.m_RenderHeadDataIndex < 1) { // hide item above the first item while cursor reached the top
				headItem.hide();
			}
			
			//scroll the ScrollWidget
			this.m_ScrollWidgetPosition += this.m_IsVertical? this.m_ItemHeight+this.m_ItemSpace: this.m_ItemWidth+this.m_ItemSpace;
			this.m_ScrollWidget.animate(this.m_IsVertical? "y": "x", this.m_ScrollWidgetPosition, 150);
			this.m_ItemUnloadCBCall(this.m_RenderHeadDataIndex+this.m_RenderItemNumber-1);
			--this.m_RenderHeadDataIndex;
			this.m_ItemLoadCBCall(this.m_RenderHeadDataIndex);
			
			if (this.m_CurrDataIndex == 0){
				if (this.m_UpArrowWidget != null){
					this.m_UpArrowWidget.hide();
				}
			}
			
			if (this.m_CurrDataIndex < this.m_TotalDataNumber-this.m_DisplayAreaItemsNumber){
				if (this.m_DownArrowWidget != null){
					this.m_DownArrowWidget.show();
				}	
			}
		} else {
			--this.m_FocusItemIndex;
			this.m_moveCursor(this.m_IsVertical? this.m_DisplayBG.x: this.m_DisplayBG.x+(this.m_ItemWidth+this.m_ItemSpace)*this.m_FocusItemIndex, 
						      this.m_IsVertical? this.m_DisplayBG.y+(this.m_ItemHeight+this.m_ItemSpace)*this.m_FocusItemIndex: this.m_DisplayBG.y, 
							  100);
		}
	};
	
	this.m_keyDownHandler = function() {
		if (this.isDimed || this.m_TotalDataNumber == 0){
			return;
		}
		
		if (this.m_CurrDataIndex == this.m_TotalDataNumber-1) {
			this.m_ReachBoundaryCBCall(this.m_IsVertical? Volt.KEY_JOYSTICK_DOWN: Volt.KEY_JOYSTICK_RIGHT);
			this.m_BottomLooping();
			return true;
		}
		
		//call focuschangedCB while data index changed
		var oldDataIndex = this.m_CurrDataIndex;
		var newDataIndex = ++this.m_CurrDataIndex;
		this.m_FocusChangedCBCall(oldDataIndex, newDataIndex);
		
		//change focus from old render to new render
		var oldIndex = this.m_CurrRenderIndex;
		var newIndex = ++this.m_CurrRenderIndex;
		this.m_changeFocus(oldIndex, newIndex);
		
		//when index item over the display area, scroll the ScrollWidget
		if (this.m_FocusItemIndex == this.m_DisplayAreaItemsNumber - 1) {
			//destroy head item and create a new tail item
			this.m_RenderArray[0].destroy();
			var tailItem = this.m_CreateItem(this.m_IsVertical? 0: (this.m_RenderArray[this.m_RenderItemNumber-1].x+this.m_ItemWidth+this.m_ItemSpace), 
											 this.m_IsVertical? (this.m_RenderArray[this.m_RenderItemNumber-1].y+this.m_ItemHeight+this.m_ItemSpace): 0);
			this.m_RenderArray.push(tailItem);
			this.m_RenderArray.shift();
			--this.m_CurrRenderIndex;
			if (this.m_RenderHeadDataIndex+this.m_RenderItemNumber > this.m_TotalDataNumber-1) {// hide item under the last item while cursor reached the bottom
				tailItem.hide();
			}
			
			//scroll the ScrollWidget
			this.m_ScrollWidgetPosition -= this.m_IsVertical? this.m_ItemHeight+this.m_ItemSpace: this.m_ItemWidth+this.m_ItemSpace;
			this.m_ScrollWidget.animate(this.m_IsVertical? "y": "x", this.m_ScrollWidgetPosition, 150);
			this.m_ItemUnloadCBCall(this.m_RenderHeadDataIndex);
			++this.m_RenderHeadDataIndex;
			this.m_ItemLoadCBCall(this.m_RenderHeadDataIndex+this.m_RenderItemNumber-1);
			
			if (this.m_CurrDataIndex >= this.m_DisplayAreaItemsNumber){
				if(this.m_UpArrowWidget){
					this.m_UpArrowWidget.show();	
				}
				
			}
			if (this.m_CurrDataIndex == this.m_TotalDataNumber-1){
				if(this.m_DownArrowWidget){
					this.m_DownArrowWidget.hide();		
				}
				
			}
			
		} else {
			++this.m_FocusItemIndex;
			this.m_moveCursor(this.m_IsVertical? this.m_DisplayBG.x: this.m_DisplayBG.x+(this.m_ItemWidth+this.m_ItemSpace)*this.m_FocusItemIndex, 
						      this.m_IsVertical? this.m_DisplayBG.y+(this.m_ItemHeight+this.m_ItemSpace)*this.m_FocusItemIndex: this.m_DisplayBG.y, 
							  100);
		}
	};
	
	this.m_ItemLoadCBCall = function(index) {
		if (this.m_ItemLoadCB && index>=0 && index<this.m_TotalDataNumber) {
			this.m_ItemLoadCB(index);
		}
	};
	
	this.m_ItemUnloadCBCall = function(index) {
		if (this.m_ItemUnloadCB && index>=0 && index<this.m_TotalDataNumber) {
			this.m_ItemUnloadCB(index);
		}
	};
	
	this.m_FocusChangedCBCall = function(oldIndex, newIndex) {
		if (this.m_FocusIndexChangedCB) {
			this.m_FocusIndexChangedCB(oldIndex, newIndex);
		}
	};
	
	this.m_DataChangedCBCall = function(index, dataItem) {
		if (this.m_DataChangeCB) {
			this.m_DataChangeCB(index, dataItem);
		}
	};
	
	this.m_ReachBoundaryCBCall = function(keycode) {
		if (this.m_ReachBoundaryCB) {
			this.m_ReachBoundaryCB(keycode);
		}
	};
	
	this.m_SetFocusDataIndex = function(index) {
		if (index < 0 || index > this.m_TotalDataNumber-1 || index == this.m_CurrDataIndex) {
			return;
		}
		this.m_DiminishFocusItem();
		var oldIndex = this.m_CurrRenderIndex;
		var newIndex = 0;
		if (index >= this.m_RenderHeadDataIndex+this.m_BufferNumer 
		&& index <= this.m_RenderHeadDataIndex+this.m_RenderItemNumber-this.m_BufferNumer-1) { // index is in current page
			log("[Contextual_Menu.js m_SetFocusDataIndex INFO] Index is in current page.");
			var offset = index-this.m_CurrDataIndex;
			newIndex = this.m_CurrRenderIndex+offset;
			this.m_FocusItemIndex += offset;
		} else if (index < this.m_RenderHeadDataIndex+this.m_BufferNumer) { // index is before current page
			log("[Contextual_Menu.js m_SetFocusDataIndex INFO] Index is before current page.");
			this.m_RenderHeadDataIndex = index-this.m_BufferNumer;
			this.m_FocusItemIndex = 0;
			newIndex = this.m_BufferNumer;
		} else if (index > this.m_RenderHeadDataIndex+this.m_RenderItemNumber-this.m_BufferNumer-1) { // index is after current page
			log("[Contextual_Menu.js m_SetFocusDataIndex INFO] Index is after current page.");
			this.m_RenderHeadDataIndex = index+this.m_BufferNumer-this.m_RenderItemNumber+1;
			this.m_FocusItemIndex = this.m_DisplayAreaItemsNumber - 1;
			newIndex = this.m_RenderItemNumber-this.m_BufferNumer-1;
		} else {
			log("[Contextual_Menu.js m_SetFocusDataIndex ERROR] Should not access this branch!");
			return;
		}
		this.m_CurrRenderIndex = newIndex;
		this.update();
		this.m_UpdateDisplayStatus();
		this.m_EnlargeFocusItem();
		this.m_RenderArray[oldIndex].loseFocus();
		this.m_RenderArray[newIndex].getFocus();
		this.m_moveCursor(this.m_IsVertical? this.m_DisplayBG.x: this.m_DisplayBG.x+(this.m_ItemWidth+this.m_ItemSpace)*this.m_FocusItemIndex, 
						  this.m_IsVertical? this.m_DisplayBG.y+(this.m_ItemHeight+this.m_ItemSpace)*this.m_FocusItemIndex: this.m_DisplayBG.y, 
						  100);
		
		this.m_FocusChangedCBCall(this.m_CurrDataIndex, index);
		this.m_CurrDataIndex = index;
	};
	
	this.m_UpdateDisplayStatus = function() {
		for (var i=0; i<this.m_RenderItemNumber; ++i) {
			var tempIndex = this.m_RenderHeadDataIndex+i;
			if (tempIndex < 0 || tempIndex > this.m_TotalDataNumber-1) {
				this.m_RenderArray[i].hide();
			} else {
				this.m_RenderArray[i].show();
			}
		}
	};
	
	/**************************
	Common Functions
	***************************/
	
	this.setItemLoadCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_ItemLoadCB = callback;
	};
	
	this.setItemUnloadCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_ItemUnloadCB = callback;
	};
	
	this.setFocusIndexChangedCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_FocusIndexChangedCB = callback;
	};
	
	this.setDataChangedCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_DataChangeCB = callback;
	};
	
	this.setReachBoundaryCB = function(callback) {
		if (typeof(callback) == "function")
			this.m_ReachBoundaryCB = callback;
	};
	
	this.itemUpdate = function(index, dataItem) {
		if (index < 0 || index >= this.m_TotalDataNumber) {
			return;
		}
		this.m_RenderArray[index - this.m_RenderHeadDataIndex].itemUpdate(index, dataItem);
		
		for(var i=0; i< this.m_DimItemIndex.length; i++){
			if (index == this.m_DimItemIndex[i]){
				if (this.m_RenderArray[index - this.m_RenderHeadDataIndex].isDimed ==false){					
					this.m_RenderArray[index - this.m_RenderHeadDataIndex].getDim();
				}
			}	
		}	
	};
	
	/**
	* This function deals with Contextual_Menu list data updating after initialization. 
	* @param void
	* @return void
	* @example //This example deals with Contextual_Menu list data updating after initialization.
	*test.update();
	* @since The version 1.0 this function is added.
	*/
	this.update = function() {
		for(var i=0; i<this.m_RenderItemNumber; ++i) {
			var index = this.m_RenderArray[i].GetDataIndex();
			this.m_ItemUnloadCBCall(index);
		}
		for (var i = this.m_RenderHeadDataIndex; i<this.m_RenderHeadDataIndex+this.m_RenderItemNumber; ++i) {
			if (i >= 0 && i < this.m_TotalDataNumber) {
				this.m_ItemLoadCBCall(i);
			} else {
				this.m_RenderArray[i-this.m_RenderHeadDataIndex].hide();
			}
		}
	};
	
	/**
	* This function deals with Contextual_Menu list page up showing. 
	* @param void
	* @return void
	* @example //This example deals with Contextual_Menu list page up showing.
	*test.pageUp();
	* @since The version 1.0 this function is added.
	*/	
	this.pageUp = function() {
		if (this.isDimed){
			return false;
		}
		
		var offset = 0;
		if (this.m_RenderHeadDataIndex+this.m_BufferNumer >= this.m_DisplayAreaItemsNumber) {
			offset = this.m_DisplayAreaItemsNumber;
		} else if (this.m_RenderHeadDataIndex+this.m_BufferNumer > 0){
			offset = this.m_RenderHeadDataIndex+this.m_BufferNumer;
		} else {
			return false;
		}
		this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
		this.m_DiminishFocusItem();
		
		for (var i = 0; i < offset; ++i) {  //add reserved items
			var headItem = this.m_CreateItem(this.m_IsVertical? 0: (this.m_RenderArray[0].x-(this.m_ItemWidth+this.m_ItemSpace)),
											 this.m_IsVertical? this.m_RenderArray[0].y-(this.m_ItemHeight+this.m_ItemSpace): 0);
			this.m_RenderArray.unshift(headItem);
			--this.m_RenderHeadDataIndex;
			this.m_ItemLoadCBCall(this.m_RenderHeadDataIndex);
		}
		
		this.m_CurrDataIndex -= offset;
		this.m_ScrollWidgetPosition += this.m_IsVertical? (this.m_ItemHeight+this.m_ItemSpace)*offset: (this.m_ItemWidth+this.m_ItemSpace)*offset;
		
		var _this = this;
		this.m_ScrollWidget.animate(this.m_IsVertical? "y": "x", this.m_ScrollWidgetPosition, 100, "sine", function(){	
			for (var i = 0; i < offset; ++i) {
				_this.m_ItemUnloadCBCall(_this.m_RenderArray[_this.m_RenderItemNumber].GetDataIndex());
				_this.m_RenderArray[_this.m_RenderItemNumber].destroy();
				_this.m_RenderArray.splice(_this.m_RenderItemNumber, 1);
				_this.m_UpdateDisplayStatus();
			}
			_this.m_RenderArray[_this.m_CurrRenderIndex].getFocus();
			_this.m_EnlargeFocusItem();
		});
		
		if (this.m_RenderHeadDataIndex > 0){
			if (this.m_UpArrowWidget != null){
				this.m_UpArrowWidget.show();
			}
		}
		else{
			if (this.m_UpArrowWidget != null){
				this.m_UpArrowWidget.hide();
			}
		}
		
		if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.show();
		}
		
		return false;
	};
	
	/**
	* This function deals with Contextual_Menu list page down showing. 
	* @param void
	* @return void
	* @example //This example deals with Contextual_Menu list page down showing.
	*test.pageDown();
	* @since The version 1.0 this function is added.
	*/	
	this.pageDown = function() {
		if (this.isDimed){
			return false;
		}
		
		var offset = 0;
		if (this.m_TotalDataNumber-(this.m_RenderItemNumber+this.m_RenderHeadDataIndex)+this.m_BufferNumer >= this.m_DisplayAreaItemsNumber) {
			offset = this.m_DisplayAreaItemsNumber;
		} else if (this.m_TotalDataNumber-(this.m_RenderItemNumber+this.m_RenderHeadDataIndex)+this.m_BufferNumer > 0){
			offset = this.m_TotalDataNumber-(this.m_RenderItemNumber+this.m_RenderHeadDataIndex)+this.m_BufferNumer;
		} else {
			return false;
		}
		this.m_RenderArray[this.m_CurrRenderIndex].loseFocus();
		this.m_DiminishFocusItem();
		
		for (var i = 0; i < offset; ++i) {  //add reserved items
			var tailItem = this.m_CreateItem(this.m_IsVertical? 0: (this.m_RenderArray[this.m_RenderArray.length-1].x+(this.m_ItemWidth+this.m_ItemSpace)),
											 this.m_IsVertical? (this.m_RenderArray[this.m_RenderArray.length-1].y+(this.m_ItemHeight+this.m_ItemSpace)): 0);
			this.m_RenderArray.push(tailItem);
			this.m_ItemLoadCBCall(this.m_RenderHeadDataIndex+this.m_RenderItemNumber+i);
		}
		this.m_RenderHeadDataIndex+= offset;
		this.m_CurrDataIndex += offset;
		this.m_ScrollWidgetPosition -= this.m_IsVertical? (this.m_ItemHeight+this.m_ItemSpace)*offset: (this.m_ItemWidth+this.m_ItemSpace)*offset;
		
		var _this = this;
		this.m_ScrollWidget.animate(this.m_IsVertical? "y": "x", this.m_ScrollWidgetPosition, 100, "sine", function(){	
			for (var i = 0; i < offset; i++) {
				_this.m_ItemUnloadCBCall(_this.m_RenderArray[0].GetDataIndex());
				_this.m_RenderArray[0].destroy();
				_this.m_RenderArray.shift();
				_this.m_UpdateDisplayStatus();
			}
			_this.m_RenderArray[_this.m_CurrRenderIndex].getFocus();
			_this.m_EnlargeFocusItem();
		});
		
		if (this.m_UpArrowWidget != null){
			this.m_UpArrowWidget.show();
		}
		
		if (this.m_RenderHeadDataIndex + this.m_BufferNumer >= this.m_TotalDataNumber - this.m_DisplayAreaItemsNumber){
			if (this.m_DownArrowWidget != null){
					this.m_DownArrowWidget.hide();
			}
		}
		else{
			if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.show();
			}
		}
		
		return false;
	};
		
	/**
	* This function changes Contextual_Menu list number. 
	* @param {Number} param for this function.
	* @return void
	* @example //This example changes Contextual_Menu list number.
	*test.changeItemNumber(4);
	* @since The version 1.0 this function is added.
	*/	
	this.changeItemNumber = function(newItemNumber) {
		this.t_loseFocus();
		for(var i=0; i<this.m_RenderItemNumber; ++i) {
			var index = this.m_RenderArray[i].GetDataIndex();
			this.m_ItemUnloadCBCall(index);
			var x = this.m_RenderArray[i].x;
			var y = this.m_RenderArray[i].y;
			this.m_RenderArray[i].destroy();
			this.m_RenderArray[i] = this.m_CreateItem(x, y);
		}
		this.m_RenderHeadDataIndex = -this.m_BufferNumer;
		this.m_TotalDataNumber = newItemNumber;
		for (var i = this.m_RenderHeadDataIndex; i<this.m_RenderHeadDataIndex+this.m_RenderItemNumber; ++i) {
			if (i >= 0 && i < this.m_TotalDataNumber) {
				this.m_ItemLoadCBCall(i);
			} else {
				this.m_RenderArray[i-this.m_RenderHeadDataIndex].hide();
			}
		}
		this.m_CurrDataIndex = 0;
		this.m_CurrRenderIndex = this.m_BufferNumer;
		this.m_FocusItemIndex = 0;
		if (this.isFocused) {
			this.t_getFocus();
		}
		
		if (this.m_TotalDataNumber <= this.m_DisplayAreaItemsNumber){
			if (this.m_UpArrowWidget != null){
				this.m_UpArrowWidget.hide();
			}
			
			if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.hide();
			}
		}
		else{
			if (this.m_UpArrowWidget != null){
				this.m_UpArrowWidget.hide();
			}
			
			if (this.m_DownArrowWidget != null){
				this.m_DownArrowWidget.show();
			}
		}
	};
		
	/**
	* This function sets Contextual_Menu one item get dim. 
	* @param {Number} param for this function.
	* @return void
	* @example //This example sets Contextual_Menu one item get dim.
	*test.setOneItemGetDim(1);
	* @since The version 1.0 this function is added.
	*/	
	this.setOneItemGetDim = function(index){
		if ((index < 0) || (index > this.m_TotalDataNumber-1)){
			return;		
		}
		
		this.m_DimItemIndex.push(index);
		
		if ((index >= this.m_RenderHeadDataIndex) &&
			(index <= this.m_RenderHeadDataIndex+this.m_RenderItemNumber -1)){
			var offset = index - this.m_RenderHeadDataIndex;
			var dimRenderIndex = offset;
			
			if (this.m_RenderArray[dimRenderIndex].isDimed == false){
				this.m_RenderArray[dimRenderIndex].getDim();
			}			
		}
	};
	
	/**
	* This function sets Contextual_Menu one item lose dim. 
	* @param {Number} param for this function.
	* @return void
	* @example //This example sets Contextual_Menu one item lose dim.
	*test.setOneItemLoseDim(1);
	* @since The version 1.0 this function is added.
	*/	
	this.setOneItemLoseDim = function(index){
		if ((index < 0) || (index > this.m_TotalDataNumber-1)){
			return;		
		}
		
		for (var i=0; i<this.m_DimItemIndex.length; i++){
			if (index == this.m_DimItemIndex[i]){
				this.m_DimItemIndex.splice(i, 1);
			}
		}
		
		if ((index >= this.m_RenderHeadDataIndex) &&
			(index < this.m_RenderHeadDataIndex+this.m_RenderItemNumber -1)){
			var offset = index - this.m_RenderHeadDataIndex;
			var dimRenderIndex = offset;
			
			if (this.m_RenderArray[dimRenderIndex].isDimed){
				this.m_RenderArray[dimRenderIndex].loseDim();
			}	
		}
	};
	
	this.m_resetDimFlag = function(){
		for(var i=0; i<this.m_RenderItemNumber; ++i) {
			 this.m_RenderArray[i].loseDim();
		}
		
		for (var i=0; i<this.m_DimItemIndex.length; i++){
			var index = this.m_DimItemIndex[i];
			
			if ((index >= this.m_RenderHeadDataIndex) &&
			(index < this.m_RenderHeadDataIndex+this.m_RenderItemNumber -1)){
				var offset = index - this.m_RenderHeadDataIndex;
				var dimRenderIndex = offset;
				
				if (this.m_RenderArray[dimRenderIndex].isDimed == false){
					this.m_RenderArray[dimRenderIndex].getDim();
				}			
			}
		}
	};
};
Contextual_Menu.prototype = new ControlBase();

Contextual_Menu.Style = {
	VERTICAL:0,
	HORIZONTAL:1,
};

exports = Contextual_Menu;