/** 
 * @author  
 * @fileoverview Definition of List_Thumbnail_Featured_Group
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

ControlBase = Volt.require("modules/UIElement/ControlBase.js");

var List_Thumbnails_Featrued_Group = function(){
	
	this.m_TopMargin = 0;
	this.m_BottomMargin = 0;
	this.m_LeftMargin = 0;
	this.m_RightMargin = 0;
	this.m_RightEdge = 0;
	this.m_ItemSpace = 0;
	
	this.m_GroupCounts = 0;
	this.m_FocusGroupIndex = 0;
	this.m_DisplayRightEdge = 1920;
	
	m_SectionInstances:null,
	this.m_SubSectionTextType = {
		x:0,
		y:0,
		width:200,
		height:50,
		font:"32px",
		textColor:{r:255, g:255, b:255},
		verticalAlignment:'center',
		horizontalAlignment:'center'
	};
	
	this.m_SubSectionBodyArea = null;
	
	/**
	* This function creates a List Thumbnail Featured Group object. 
	* @param {Object} param for this function.
	* @return void
	* @example 
	* @since The version 1.0 this function is added.
	*/	
	this.t_create = function(params) {
		
		this.m_InitMembers(params);
		this.m_InitWidgets(params);
	};
	
	this.m_InitMembers = function(params){
		this.m_TopMargin = params['topMargin']? params['topMargin']: 0;
		this.m_BottomMargin = params['bottomMargin']? params['bottomMargin']: 0;
		this.m_LeftMargin = params['leftMargin']? params['leftMargin']: 0;
		this.m_RightMargin = params['rightMargin']? params['rightMargin']: 0;
		this.m_ItemSpace = params['itemSpace']? params['itemSpace']: 0;
		this.m_RightEdge = this.m_LeftMargin;
		
		if (params['subSectionTextType']) {
			this.m_SubSectionTextType = params['subSectionTextType'];
		}
		
		if (params['subSectionBodyArea']) {
			this.m_SubSectionBodyArea = params['subSectionBodyArea'];
		}
	};
	
	this.m_InitWidgets = function(params){
		
		this.m_DisplayBG = new Widget({
			x: params['x']? params['x']: 0,
			y: params['y']? params['y']: 0,
			height: params['height']? params['height']: 1080,
			width: params['width']? params['width']: 1920,
			parent: params['parent']? params['parent']: scene,
			color: {r: 0, g: 60, b: 50, a: 0}
		});
		this.m_DisplayRightEdge = this.m_DisplayBG.x + this.m_DisplayBG.width;
		
		this.m_DisplayBG.cropOverflow = true;
	};
	
	this.m_LeftEdgeWgt = null;
	this.m_RightEdgeWgt = null;
	//this.m_IntervalID = null;
	this.m_InitEdgeMouseListeners = function(){
		
		if (this.m_LeftEdgeWgt == null) {
			this.m_LeftEdgeWgt = new Widget({
				x:0,
				y:this.m_TopMargin,
				width:10,
				height:this.m_DisplayBG.height - this.m_TopMargin,
				color:{a:0},
				parent:this.m_DisplayBG
			});
			
			var self = this; // do not need to use the bind feature
			this.m_LeftEdgeWgt.addEventListener('OnMouseOver', function(){
				
				self.m_LeftKeyHandler();
				return false;
			})
			
			this.m_LeftEdgeWgt.addEventListener('OnMouseOut', function(){
				return false;
			})
		}
		
		if (this.m_RightEdgeWgt == null) {
			this.m_RightEdgeWgt = new Widget({
				x:this.m_DisplayBG.width - 10,
				y:this.m_TopMargin,
				width:10,
				height:this.m_DisplayBG.height - this.m_TopMargin,
				color:{a:0},
				parent:this.m_DisplayBG
			});
			
			this.m_RightEdgeWgt.addEventListener('OnMouseOver', function(){
				self.m_RightKeyHandler();
				return false;
			})
			
			this.m_RightEdgeWgt.addEventListener('OnMouseOut', function(){
				return false;
			})
		}
	};
	
	this.m_RemoveEdgeMouseListeners = function(){
		
		if (this.m_LeftEdgeWgt != null) {
			this.m_LeftEdgeWgt.destroy();
		}
		
		if (this.m_RightEdgeWgt != null) {
			this.m_RightEdgeWgt.destroy();
		}
		
		this.m_LeftEdgeWgt = null;
		this.m_RightEdgeWgt = null;
	};
	
	this.m_MouseOver_For_Sections = function(target, eventData){
		this.loseFocus();
		
		var self = this;
		Volt.setTimeout(function(){
			var sectionItem = self.m_SectionInstances[target.m_index];
			var tempX = sectionItem['sectionDisplayBG_X'];
			if (tempX < self.m_LeftMargin) {
				var tempOffsetX = self.m_LeftMargin - tempX;
				self.m_updateSectionPosition(tempOffsetX);
			}
			
			var sectionItem = self.m_SectionInstances[target.m_index];
			var tempXLength = sectionItem['sectionDisplayBG_Width'] + sectionItem['sectionDisplayBG_X'];
			if (tempXLength > self.m_DisplayRightEdge) {
				var tempOffsetX = -(tempXLength - self.m_DisplayRightEdge + self.m_ItemSpace + 100); // 100 need to check 
				self.m_updateSectionPosition(tempOffsetX);
			}
		}, 100); // response time for user
		
		this.m_FocusGroupIndex = target.m_index;
		this.getFocus();
		
		return false;
	};
	this.m_MouseOver_For_SectionCallBack = this.m_MouseOver_For_Sections.bind(this);
	
	this.m_SetSectionMouseEvent = function(eventType, targetInc, callback){
		if (targetInc.m_setMouseEventFlag == false) {
			targetInc.addEventListener(eventType, callback);
			targetInc.m_setMouseEventFlag = true;
		}
	};
	
	this.m_SetSectionMouseListenerFlag = false;
	this.m_InitSectionIncMouseListeners = function(){
		if (this.m_SetSectionMouseListenerFlag == true) {
			return;
		}
		
		var tempSectionBGItem = null;
		for(var index = 0; index < this.m_SectionInstances.length; index ++) {
			tempSectionBGItem = this.m_SectionInstances[index]['sectionDisplayBG'];
			this.m_SetSectionMouseEvent('OnMouseOver', tempSectionBGItem, this.m_MouseOver_For_SectionCallBack);
		}
		
		this.m_SetSectionMouseListenerFlag = true;
	};
	
	this.addSectionItem = function(params){
		
		if (!params['sectionName']) {
			throw new Error('Please enter the name of the section!');
			return null;
		}
		
		if (this.m_SectionInstances == null) {
			this.m_SectionInstances = new Array();
		}
		
		var sectionDisplayBG = new Widget({
			x:this.m_RightEdge,
			y:this.m_TopMargin,
			height: params['height']? params['height']: 0,
			width: params['width']? params['width']: 0,
			color: params['color']? params['color']: {a:0},
			parent: this.m_DisplayBG
		})
		
		sectionDisplayBG.m_index = this.m_GroupCounts;
		sectionDisplayBG.m_setMouseEventFlag = false;
		
		var sectionNameWgt = new TextWidget(this.m_SubSectionTextType);
		sectionNameWgt.text = params['sectionName'];
		sectionNameWgt.parent = sectionDisplayBG;
		
		var sectionBodyWgt = null;
		if (this.m_SubSectionBodyArea) {
			sectionBodyWgt = new Widget(this.m_SubSectionBodyArea);
		} else {
			sectionBodyWgt = new Widget({
				x:0,
				y:sectionNameWgt.height,
				width:sectionDisplayBG.width,
				height:sectionDisplayBG.height - sectionNameWgt.height
			});
		}
		
		sectionBodyWgt.color = {g:60, b:80};
		sectionBodyWgt.parent = sectionDisplayBG;
		
		this.m_GroupCounts ++;
		
		var sectionItem = new Object();
		sectionItem['sectionDisplayBG'] = sectionDisplayBG;
		sectionItem['sectionName'] = sectionNameWgt;
		sectionItem['sectionBody'] = sectionBodyWgt;
		sectionItem['sectionDisplayBG_Width'] = sectionDisplayBG.width;
		sectionItem['sectionDisplayBG_X'] = sectionDisplayBG.x;
		this.m_SectionInstances.push(sectionItem);
		
		this.m_RightEdge += this.m_SectionInstances[this.m_GroupCounts - 1]['sectionDisplayBG_Width'] + this.m_ItemSpace;
		
		var returnValue = {
			m_sectionItem:sectionItem,
			set Child(targerWgt){
				targerWgt.parent = this.m_sectionItem['sectionBody'];
			},
			set BodyContent(bodyContent) {
				this.m_sectionItem['sectionBodyContent'] = bodyContent;
			},
			get width(){
				return this.m_sectionItem['sectionBody'].width;
			}
		};
			
		return returnValue;
	};
	
	this.m_updateSectionPosition = function(xStep){
		
		var tempSectionItem = null;
		for(var index = 0; index < this.m_SectionInstances.length; index ++) {
			
			tempSectionItem = this.m_SectionInstances[index];
			tempSectionItem['sectionDisplayBG_X'] += xStep;
			tempSectionItem['sectionDisplayBG'].animate("x", tempSectionItem['sectionDisplayBG_X'], 200);
		}
	};
	
	this.m_DealWidthSectionBodyKeyHandler = function(keycode, keytype){
		
		if (this.m_SectionInstances[this.m_FocusGroupIndex]['sectionBodyContent']) {
			
			return this.m_SectionInstances[this.m_FocusGroupIndex]['sectionBodyContent'].keyHandler(keycode, keytype);
		} 
		
		return false;
	}
	
	this.t_destroy = function(){
		while(this.m_SectionInstances.length > 0) {
			var sectionInc = this.m_SectionInstances.pop();
			sectionInc['sectionBodyContent'].destroy();
			sectionInc['sectionBody'].destroy();
			sectionInc['sectionDisplayBG'].destroy();
			
			for(var i in sectionInc) {
				delete sectionInc[i];
			}
		}
		
		this.m_RemoveEdgeMouseListeners();
		this.m_DisplayBG.destroy();
		
		delete this.m_MouseOver_For_SectionCallBack;
	}
	
	this.t_getFocus = function() {

		this.m_SectionInstances[this.m_FocusGroupIndex]['sectionDisplayBG'].border = {width: 2, color:{r:10, g:233, b:233}};
		
		this.m_InitEdgeMouseListeners();
		this.m_InitSectionIncMouseListeners();
		
		if (this.m_SectionInstances[this.m_FocusGroupIndex]['sectionBodyContent']) {
			this.m_SectionInstances[this.m_FocusGroupIndex]['sectionBodyContent'].getFocus();
		}
	};
	
	this.t_loseFocus = function() {
		
		this.m_SectionInstances[this.m_FocusGroupIndex]['sectionDisplayBG'].border = {width: 0, color:{r:10, g:233, b:233}};
		if (this.m_SectionInstances[this.m_FocusGroupIndex]['sectionBodyContent']) {
			this.m_SectionInstances[this.m_FocusGroupIndex]['sectionBodyContent'].loseFocus();
		}
	};
	
	this.m_UpKeyHandler = function(){
		print(" The UP edge------------->>>>>");
		return false;
	};
	
	this.m_DownKeyHandler = function(){
		print(" The DOWN edge------------->>>>>");
		return false;
	};
	
	this.m_LeftKeyHandler = function(){
		
		if (this.m_FocusGroupIndex == 0) {
			print(" The LEFT edge------------->>>>>");
			return false;
		}
		
		this.loseFocus();
		this.m_FocusGroupIndex--;
		this.getFocus();
		
		var sectionItem = this.m_SectionInstances[this.m_FocusGroupIndex];
		var tempX = sectionItem['sectionDisplayBG_X'];
		if (tempX < this.m_LeftMargin) {
			var tempOffsetX = this.m_LeftMargin - tempX;
			this.m_updateSectionPosition(tempOffsetX);
		}
		return true;
	};
	
	this.m_RightKeyHandler = function(){
		
		if (this.m_FocusGroupIndex == this.m_GroupCounts - 1) {
			print(" The RIGHT edge------------->>>>>");
			return false;
		}
		
		this.loseFocus();
		this.m_FocusGroupIndex++;
		this.getFocus();
		
		var sectionItem = this.m_SectionInstances[this.m_FocusGroupIndex];
		var tempXLength = sectionItem['sectionDisplayBG_Width'] + sectionItem['sectionDisplayBG_X'];
		if (tempXLength > this.m_DisplayRightEdge) {
			var tempOffsetX = -(tempXLength - this.m_DisplayRightEdge + this.m_ItemSpace + 100); // 100 need to check 
			this.m_updateSectionPosition(tempOffsetX);
		}
		return true;
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		
		if (this.m_DealWidthSectionBodyKeyHandler(keycode, keytype)){
			return true;
		}
		
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return true;
		}
		
		switch (keycode) {
			case Volt.KEY_JOYSTICK_UP:
				return this.m_UpKeyHandler();
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				return this.m_DownKeyHandler();
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				return this.m_LeftKeyHandler();
				break;
			case Volt.KEY_JOYSTICK_RIGHT:
				return this.m_RightKeyHandler();
				break;
			default:
				return true;
		}
	};
	
}

List_Thumbnails_Featrued_Group.prototype = new ControlBase();

exports = List_Thumbnails_Featrued_Group;
