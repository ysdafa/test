 /** 
 * @author  
 * @fileoverview Definition of Contextual_MenuRenderBase
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

Contextual_MenuRenderBase = function(){
	this.m_DataIndex = -1;
	this.m_DataItem = null;
	this.m_IsDataChanged = false;

	this.t_getFocus = function() {
	};
	
	this.t_loseFocus = function() {
	};
	
	this.t_getDim = function() {	
	};
	
	this.t_loseDim = function() {	
	};
	
	this.t_selected = function() {	
	};
	
	this.t_keyHandler = function() {
	};
	
	this.t_destroy = function() {
	};
	
	this.t_setMouseOverOutCallback = function(obj){	
	};
	
	this.t_setMouseUpDownCallback = function(obj){
	};

	this.t_setMouseClickCallback = function(callback){
	};
	
	this.t_MouseOverOut = function(isOnFlag){
	};
	
	this.t_MouseClick = function(isOnFlag){
	};
	
	this.GetDataIndex = function() {
		return this.m_DataIndex;
	};
	
	this.GetDataItem = function() {
		return this.m_DataItem;
	};
	
	this.ResetDataChangeFlag = function() {
		this.m_IsDataChanged = false;
	};
	
	this.DataChanged = function() {
		this.m_IsDataChanged = true;
	};
	
	this.IsDataChanged = function() {
		return this.m_IsDataChanged;
	};
	
	this.itemUpdate = function(index, itemData){
		this.m_DataIndex = index;
		var text = JSON.stringify(itemData);   // deep copy
		this.m_DataItem = JSON.parse(text);
		this.t_itemUpdate(itemData);
	};
}

Contextual_MenuRenderBase.prototype = new ControlBase();

exports = Contextual_MenuRenderBase;