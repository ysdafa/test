 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of SubPopup_Progress
 * @date    2014/08/08
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");
Progress = Volt.require("modules/UIElement/Progress");

/**
 * Class SubPopup_Progress.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
SubPopup_Progress = function() {
    //inner data
    this.arrowUpLeft = null;
    this.arrowDownRight = null;
    this.progress = null;
    //mandatary
    this.arrowUpLeftNormalSrc = "";
    this.arrowDownRightNormalSrc = "";
    this.sliderDialSrc = "";
    //optional
    this.arrowUpLeftHighlightSrc = "";
    this.arrowDownRightHighlightSrc = "";
    this.sliderDialFocusSrc = "";
    this.balloonTailSrc = "";
    this.arrowIconWidth = scene.width*(44/1920);
    this.arrowIconHeight = scene.height*(44/1080);
    this.progressWidth = scene.width*0.193750;
    this.progressHeight = scene.height*0.001852;
    this.stepNumber = 100;
    this.leftRightMargin = scene.width*0.015625;
    this.topBottomMargin = scene.height*0.027778;
    this.centerGapSize = scene.width*0.015625;
    this.backgroundColor = {r:0,g:100,b:200,a:200};
    
    this.m_setProperty = function(obj) {
        //mandatary
        if (obj.hasOwnProperty("arrowUpLeftNormalSrc") 
            && "string" == typeof obj.arrowUpLeftNormalSrc && 0 != obj.arrowUpLeftNormalSrc.length) {
            this.arrowUpLeftNormalSrc = obj.arrowUpLeftNormalSrc;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("arrowDownRightNormalSrc") 
            && "string" == typeof obj.arrowDownRightNormalSrc && 0 != obj.arrowDownRightNormalSrc.length) {
            this.arrowDownRightNormalSrc = obj.arrowDownRightNormalSrc;
        }
        else {
            return false;
        }
        if (obj.hasOwnProperty("sliderDialSrc") 
            && "string" == typeof obj.sliderDialSrc && 0 != obj.sliderDialSrc.length) {
            this.sliderDialSrc = obj.sliderDialSrc;
        }
        else {
            return false;
        }
        //optional
        if (obj.hasOwnProperty("arrowUpLeftHighlightSrc") 
            && "string" == typeof obj.arrowUpLeftHighlightSrc && 0 != obj.arrowUpLeftHighlightSrc.length) {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftHighlightSrc;
        }
        else {
            this.arrowUpLeftHighlightSrc = obj.arrowUpLeftNormalSrc;
        }
        if (obj.hasOwnProperty("arrowDownRightHighlightSrc") 
            && "string" == typeof obj.arrowDownRightHighlightSrc && 0 != obj.arrowDownRightHighlightSrc.length) {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightHighlightSrc;
        }
        else {
            this.arrowDownRightHighlightSrc = obj.arrowDownRightNormalSrc;
        }
        if (obj.hasOwnProperty("sliderDialFocusSrc") 
            && "string" == typeof obj.sliderDialFocusSrc && 0 != obj.sliderDialFocusSrc.length) {
            this.sliderDialFocusSrc = obj.sliderDialFocusSrc;
        }
        else {
            this.sliderDialFocusSrc = obj.sliderDialSrc;
        }
        if (obj.hasOwnProperty("balloonTailSrc") 
            && "string" == typeof obj.balloonTailSrc && 0 != obj.balloonTailSrc.length) {
            this.balloonTailSrc = obj.balloonTailSrc;
        }
        if (obj.hasOwnProperty("arrowIconWidth") 
            && "number" == typeof obj.arrowIconWidth) {
            this.arrowIconWidth = obj.arrowIconWidth;
        }
        if (obj.hasOwnProperty("arrowIconHeight") 
            && "number" == typeof obj.arrowIconHeight) {
            this.arrowIconHeight = obj.arrowIconHeight;
        }
        if (obj.hasOwnProperty("progressWidth") 
            && "number" == typeof obj.progressWidth) {
            this.progressWidth = obj.progressWidth;
        }
        if (obj.hasOwnProperty("progressHeight") 
            && "number" == typeof obj.progressHeight) {
            this.progressHeight = obj.progressHeight;
        }
        if (obj.hasOwnProperty("stepNumber") 
            && "number" == typeof obj.stepNumber && obj.stepNumber >= 1) {
            this.stepNumber = Math.floor(obj.stepNumber);
        }
        if (obj.hasOwnProperty("leftRightMargin") 
            && "number" == typeof obj.leftRightMargin) {
            this.leftRightMargin = obj.leftRightMargin;
        }
        if (obj.hasOwnProperty("topBottomMargin") 
            && "number" == typeof obj.topBottomMargin) {
            this.topBottomMargin = obj.topBottomMargin;
        }
        if (obj.hasOwnProperty("centerGapSize") 
            && "number" == typeof obj.centerGapSize) {
            this.centerGapSize = obj.centerGapSize;
        }
        if (obj.hasOwnProperty("backgroundColor") 
            && "object" == typeof obj.backgroundColor) {
            this.backgroundColor = obj.backgroundColor;
        }
        
        return true;
    };
	
	/**
	* This function will create a SubPopup_Progress<p>
	* This function will create a SubPopup_Progress,You can use this function when you want to create a SubPopup_Progress Object.
	* @param {Object} param of the new SubPopup_Progress you want to create.
	* @return {Object} return the new SubPopup_Progress object you want to create.
	* @example //This example create a new SubPopup_Progress.
	* const script_AID = "UIElement/SubPopup_Progress";
	* const SubPopup_Progress = require(script_AID);
	* var progress = new SubPopup_Progress();
    * progress.create({
        x: 200,
        y: 750,
        //width: scene.width*0.302083,//this will be recaculate!
        //height: scene.height*0.096296,//this will be recaculate!
        //mandatary
        parent: tempBG,
        arrowUpLeftNormalSrc: "popup/Arrow/popup_btn_arrow_left_n.png",
        arrowDownRightNormalSrc: "popup/Arrow/popup_btn_arrow_right_n.png",
        sliderDialSrc: "popup/progress/popup_progress_dial_1_n.png",
        //optional
        arrowUpLeftHighlightSrc: "popup/Arrow/popup_btn_arrow_left_f.png",
        arrowDownRightHighlightSrc: "popup/Arrow/popup_btn_arrow_right_f.png",
        sliderDialFocusSrc: "popup/progress/popup_progress_dial_1_f.png",
        balloonTailSrc : "popup/Balloon/popup_balloon_tail_d.png",
        arrowIconWidth: 44,
        arrowIconHeight: 44,
        progressWidth: 1000,
        progressHeight: 10,
        stepNumber: 10,
        leftRightMargin: 20,
        topBottomMargin: 10,
        centerGapSize: 5,
        backgroundColor: {r:0,g:128,b:255,a:255},
      });
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
        var ret = this.m_setProperty(obj);
        if(!ret){
            return null;
        }
        //reset background property.
        this.rootWidget.color = this.backgroundColor;
        this.width = (this.leftRightMargin+this.arrowIconWidth+this.centerGapSize)*2+this.progressWidth;
        this.height = this.topBottomMargin*2+this.arrowIconHeight;
        //create elements
        this.arrowUpLeft = new ImageWidget({
            x: this.leftRightMargin,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.arrowIconWidth,
            height: this.arrowIconHeight,
            src: this.arrowUpLeftNormalSrc,
            parent: obj.parent,
        });
        this.progress = new Progress();
        this.progress.create({
            x : this.leftRightMargin+this.arrowIconWidth+this.centerGapSize,
            y : (this.height-this.progressHeight)/2,
            width : this.progressWidth,
            height : this.progressHeight,
            stepNumber : this.stepNumber,
            sliderDialSrc : this.sliderDialSrc,
            sliderDialFocusSrc : this.sliderDialFocusSrc,
            balloonTailSrc : this.balloonTailSrc,
            parent: obj.parent,
        });
        this.arrowDownRight = new ImageWidget({
            x: this.leftRightMargin+this.arrowIconWidth+this.centerGapSize*2+this.progressWidth,
            y: 0,
            origin: {x:0,y:0.5},
            anchor: {x:0,y:0.5},
            width: this.arrowIconWidth,
            height: this.arrowIconHeight,
            src: this.arrowDownRightNormalSrc,
            parent: obj.parent,
        });
        
        return this;
	};

	this.t_getFocus = function() {
        this.progress.getFocus();
	};
	this.t_loseFocus = function() {
        this.progress.loseFocus();
	};
	this.t_hide = function() {
		this.t_loseFocus();
	};		
	this.t_destroy = function() {
        if(null != this.progress) {
            this.progress.destroy();
            this.progress = null;
        }
        if(null != this.arrowUpLeft) {
            this.arrowUpLeft.destroy();
            this.arrowUpLeft = null;
        }
        if(null != this.arrowDownRight) {
            this.arrowDownRight.destroy();
            this.arrowDownRight = null;
        }
        
        delete this.arrowUpLeftMouseClickBind;
        delete this.arrowDownRightMouseClickBind;
	};
	this.t_getDim = function() {
        this.progress.getDim();	
	};	
	this.t_loseDim = function() {	
        this.progress.loseDim();
	};
    this.t_selected = function() {
       this.progress.selected();
    };
    this.t_unSelected = function() {
       this.progress.unSelected();
    };

	this.t_setMouseClickCallback = function(callback)
	{
        if(this.isCreated && null != callback
            && "function" == typeof callback) {
            this.progress.setLeftKeyCallback(callback);
            this.progress.setRightKeyCallback(callback);
            this.progress.setMouseClickCallback(callback);
        }
	};
    this.arrowUpLeftMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            this.arrowDownRight.src = this.arrowDownRightNormalSrc;
            this.arrowUpLeft.src = this.arrowUpLeftHighlightSrc;
            this.progress.goBackward1Step();
        }
        return false;
    };	
    this.arrowUpLeftMouseClickBind = this.arrowUpLeftMouseClick.bind(this);
    this.arrowDownRightMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            this.arrowUpLeft.src = this.arrowUpLeftNormalSrc;
            this.arrowDownRight.src = this.arrowDownRightHighlightSrc;
            this.progress.goForward1Step();
        }
        return false;
    };	
    this.arrowDownRightMouseClickBind = this.arrowDownRightMouseClick.bind(this);   
    this.t_MouseClick = function(isOnFlag){
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag) {
                this.progress.enableMouseClick(true);
                this.arrowUpLeft.addEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                this.arrowDownRight.addEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
            }
            else {
                this.progress.enableMouseClick(false);
                this.arrowUpLeft.removeEventListener("OnMouseClick", this.arrowUpLeftMouseClickBind);
                this.arrowDownRight.removeEventListener("OnMouseClick", this.arrowDownRightMouseClickBind);
            }
        }
    };
    
	this.t_keyHandler = function(keycode, keytype){
        var ret = false;
        if (keytype == Volt.EVENT_KEY_RELEASE || !this.isFocused) 
        {
            return ret;
        }	
        switch(keycode) 
        {
            case Volt.KEY_JOYSTICK_RIGHT:
                    this.arrowUpLeft.src = this.arrowUpLeftNormalSrc;
                    this.arrowDownRight.src = this.arrowDownRightHighlightSrc;
                    ret = this.progress.keyHandler(keycode,keytype);
                break;			
            case Volt.KEY_JOYSTICK_LEFT:	
                    this.arrowDownRight.src = this.arrowDownRightNormalSrc;
                    this.arrowUpLeft.src = this.arrowUpLeftHighlightSrc;
                    ret = this.progress.keyHandler(keycode,keytype);
                break;
            default:
                break;
        } 					
        return ret;
	};    
}
SubPopup_Progress.prototype = new ControlBase();
exports = SubPopup_Progress;
