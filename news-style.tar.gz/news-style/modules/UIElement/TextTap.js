/** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of TextTap
 * @date    2014/08/02
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
 ControlBase = Volt.require("modules/UIElement/ControlBase.js");


/**
 * Class TextTap.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
TextTap = function() {
    //inner data
    this.itemNum = 0;
    this.itemList = [];
    this.itemTextList = [];
    this.splitList = [];
    this.focusIndex = 0;
    //mandatory!
    this.textList = [];//length must be greater than 0
    //optional
    this.splitIconSrc = null;
    this.splitIcon = null;
    this.iconWidth = 10;
    this.iconHeight = 10;
    this.gapSize = 0;
    this.textFont = "Helvetica 24px";
    this.selectIndex = 0;
    this.selectWhenFocus = false;//need to click or press enter by default
    //setXXX api properties
    this.stateItemBGColor = [];
    this.stateTextColor = [];
    this.callback = null;
    
    this.debugText = null;
    
    this.enumState = 
    {
        NORMAL:0,
        SELECTED:1,
        FOCUSED:2,
        ALL:3
    };
	
	/**
	* This function will create a TextTap<p>
	* This function will create a TextTap,You can use this function when you want to create a TextTap Object.
	* @param {Object} param of the new TextTap you want to create.
	* @return {Object} return the new TextTap object you want to create.
	* @example //This example create a new TextTap.
	* const script_AID = "UIElement/TextTap";
	* const TextTap = require(script_AID);
	* sampleTextTap = new TextTap();
    * sampleTextTap.create({
        x:100,
        y:100,
        height:100,
        //mandatory!length must be greater than 0
        textList:["Apple","a lot of Banana","Grape","a loooooooooooooooot of Orange","Watermelon"],
        parent:tempBG,
        //optional
        splitIconSrc : iconSrc,
        iconWidth : 5,
        iconHeight : 5,
        gapSize : 10,
        textFont : "Helvetica 32px",
        selectIndex : 1,
        selectWhenFocus : false,
      });
	* @since The version 1.0 this function is added.
	*/
    this.t_create = function(obj) { 
        /*
        this.debugText = new TextWidget({
            x:0,
            y:50,
            width:1000,
            height:30,
            text:"debug",
            textColor:{r:255, g:255, b:255, a:150},
            parent:scene,
        });
        */
        if (obj.hasOwnProperty("textList") && "object" == typeof obj.textList
            && 0 < obj.textList.length && "string" == typeof obj.textList[0]) {
            this.textList = obj.textList;
            this.itemNum = obj.textList.length;
        }
        else {
            return null;//this is mandatory!
        }
        if (obj.hasOwnProperty("splitIconSrc") 
            && "string" == typeof obj.splitIconSrc && 0 != obj.splitIconSrc.length) {
            this.splitIconSrc = obj.splitIconSrc;
        }
        if (obj.hasOwnProperty("iconWidth") 
            && "number" == typeof obj.iconWidth) {
            this.iconWidth = obj.iconWidth;
        }
        if (obj.hasOwnProperty("iconHeight") 
            && "number" == typeof obj.iconHeight) {
            this.iconHeight = obj.iconHeight;
        }
        if (obj.hasOwnProperty("gapSize") 
            && "number" == typeof obj.gapSize) {
            this.gapSize = obj.gapSize;
        }
        if (obj.hasOwnProperty("textFont") 
            && "string" == typeof obj.textFont && 0 != obj.textFont.length) {
            this.textFont = obj.textFont;
        }
        if (obj.hasOwnProperty("selectIndex") && "number" == typeof obj.selectIndex
            && obj.selectIndex >= 0 && obj.selectIndex < this.itemNum) {
            this.selectIndex = obj.selectIndex;
            this.focusIndex = obj.selectIndex;
        }
        if (obj.hasOwnProperty("selectWhenFocus") 
            && "boolean" == typeof obj.selectWhenFocus) {
            this.selectWhenFocus = obj.selectWhenFocus;
        }

        for(var index = 0; index < this.enumState.ALL ; index++) {
            this.stateItemBGColor[index] = {r:255, g:255, b:255, a:100};
        }
        this.stateTextColor[this.enumState.NORMAL] = {r:0, g:0, b:0, a:255};
        this.stateTextColor[this.enumState.SELECTED] = {r:0, g:0, b:255, a:255};
        this.stateTextColor[this.enumState.FOCUSED] = {r:255, g:0, b:0, a:255};

          
        var currentx = 0;//the beginning position of item.
        for(var index = 0; index < this.itemNum; index++)
        {
            //this widget will contain the two gaps around TextWidget
            this.itemList[index] = new Widget({
                width: 200,
                height: 50,
                color: this.stateItemBGColor[this.enumState.NORMAL],
                //border: {width:1, color:{r:255, g:255, b:255, a:255}},
                origin: {x:0,y:0.5},
                anchor: {x:0,y:0.5},
                parent: obj.parent,
            });
            //split icon is optional
            if(null != this.splitIconSrc && index > 0 )
            {
                splitIcon = new ImageWidget({
                    width: this.iconWidth,
                    height: this.iconHeight,
                    src: this.splitIconSrc,
                    origin: {x:0,y:0.5},
                    anchor: {x:0,y:0.5},
                    parent: obj.parent,
                });
                this.splitList.push(splitIcon);
            }
            //text list is mandatory!
            this.itemTextList[index] = new TextWidget({
                x: 0,
                y: 0,
                text: this.textList[index],
                textColor: this.stateTextColor[this.enumState.NORMAL],
                //color:{r:100, g:200, b:100, a:255},//for debug
                font: this.textFont,
                origin: {x:0,y:0.5},
                anchor: {x:0,y:0.5},
                horizontalAlignment: "center",
                verticalAlignment: "center",
                parent: this.itemList[index],
            });

            //recaculate the size and position.
            this.itemTextList[index].x = this.gapSize;
            this.itemTextList[index].width = (this.itemTextList[index].getAbsoluteSize()).x;
            this.itemTextList[index].height = (this.itemTextList[index].getAbsoluteSize()).y;
            this.itemList[index].width = this.itemTextList[index].width + this.gapSize*2;
            this.itemList[index].height = this.itemTextList[index].height;  
            if(0 == index)
            {
                this.itemList[index].x = currentx;
                currentx = this.itemList[index].width;
            }
            else
            {
                if(null != splitIcon){
                    splitIcon.x = currentx;
                    this.itemList[index].x = currentx + splitIcon.width;
                    currentx = currentx + splitIcon.width + this.itemList[index].width;
                }
                else{
                    this.itemList[index].x = currentx;
                    currentx = currentx + this.itemList[index].width;
                }
            }
            this.rootWidget.width = currentx;
            if(this.rootWidget.height < this.itemList[index].height)
                this.rootWidget.height = this.itemList[index].height;
            //this.debugText.text = this.debugText.text + index.toString() + ":" + (this.itemTextList[index].getAbsoluteSize()).x.toString() + ";";
        }

        return this;
    };

    this.t_getFocus = function() {
    };
    this.t_loseFocus = function() {
    };
    this.t_destroy = function() {
        for(var index = 0; index < this.splitList.length; index++)
        {
            this.splitList[index].destroy();
        }
        for(var index = 0; index < this.itemNum; index++)
        {
            this.itemTextList[index].destroy();
            this.itemList[index].destroy();
        }
        this.itemList.length = 0;
        this.itemTextList.length = 0;
        this.splitList.length = 0;
        this.textList.length = 0;
        this.stateItemBGColor.length = 0;
        this.stateTextColor.length = 0;
        this.itemList = null;
        this.itemTextList = null;
        this.splitList = null;
        this.textList = null;
        this.stateItemBGColor = null;
        this.stateTextColor = null;
        
        delete this.itemMouseOverBind;
        delete this.itemMouseOutBind;
        delete this.itemMouseClickBind;
    };
    this.t_show = function() {
    };
    this.t_hide = function() {
    };
    
    this.itemMouseOver =function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            this.focusIndex = targetWidget.SN;
            if(this.selectWhenFocus){
                this.selectIndex = this.focusIndex;
                //notify user here!
                if(null != this.callback){
                    this.callback(this.selectIndex);
                }
            }
            //this.debugText.text = "item width: " + this.itemList[this.focusIndex].width.toString();
            //this.debugText.text += ",text width: " + this.itemTextList[this.focusIndex].width.toString();
            //this.debugText.text += ",text x: " + this.itemTextList[this.focusIndex].x.toString();
            this.m_updateState();
        }
        return false;
    };
    this.itemMouseOverBind = this.itemMouseOver.bind(this);
    
    this.itemMouseOut = function(targetWidget, eventData) {
        return false;
    };
    this.itemMouseOutBind = this.itemMouseOut.bind(this);
        
    this.itemMouseClick = function(targetWidget, eventData) {
        if(this.isFocused && !this.isDimed){
            this.selectIndex = targetWidget.SN;
            //notify user here!
            if(null != this.callback){
                this.callback(this.selectIndex);
            }
            //this.debugText.text = "select index: " + this.selectIndex.toString();
            this.m_updateState();
        }
        return false;
    };	
    this.itemMouseClickBind = this.itemMouseClick.bind(this);
   
    this.t_MouseOverOut = function(isOnFlag) {
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag){
                for(var i = 0; i < this.itemNum; i++) {
                    this.itemList[i].SN = i;
                    this.itemList[i].addEventListener("OnMouseOver", this.itemMouseOverBind);
                    this.itemList[i].addEventListener("OnMouseOut", this.itemMouseOutBind);
                }
            }
            else{
                for(var i = 0; i < this.itemNum; i++) {
                    this.itemList[i].removeEventListener("OnMouseOver", this.itemMouseOverBind);
                    this.itemList[i].removeEventListener("OnMouseOut", this.itemMouseOutBind);
                }
            }
        }
    };
    this.t_MouseClick = function(isOnFlag) {
        if(this.isCreated == true && "boolean" == typeof isOnFlag){
            if(isOnFlag){
                for(var i = 0; i < this.itemNum; i++) {
                    this.itemList[i].SN = i;
                    if(!this.selectWhenFocus){
                        this.itemList[i].addEventListener("OnMouseClick", this.itemMouseClickBind);
                    }
                }
            }
            else{
                for(var i = 0; i < this.itemNum; i++) {
                    if(!this.selectWhenFocus){
                        this.itemList[i].removeEventListener("OnMouseClick", this.itemMouseClickBind);
                    }
                }
            }
        }
    };
    
    this.t_keyHandler = function(keycode, keytype){
		if (keytype == Volt.EVENT_KEY_RELEASE || !this.isFocused) 
		{
			return false;
		}
				
        var ret = false;
        switch(keycode) {
            case Volt.KEY_JOYSTICK_RIGHT:
                if(this.focusIndex < this.itemNum - 1) {
                    this.focusIndex++;
                    if(this.selectWhenFocus){
                        this.selectIndex = this.focusIndex;
                        //notify user here!
                        if(null != this.callback){
                            this.callback(this.selectIndex);
                        }
                    }
                    this.m_updateState();
                    ret = true;
                }
                break;
            case Volt.KEY_JOYSTICK_LEFT:
                if(this.focusIndex > 0) {
                    this.focusIndex--;
                    if(this.selectWhenFocus){
                        this.selectIndex = this.focusIndex;
                        //notify user here!
                        if(null != this.callback){
                            this.callback(this.selectIndex);
                        }
                    }
                    this.m_updateState();
                    ret = true;
                }
                break;
            case Volt.KEY_JOYSTICK_OK:
                if(!this.selectWhenFocus){
                    this.selectIndex = this.focusIndex;
                    //notify user here!
                    if(null != this.callback){
                        this.callback(this.selectIndex);
                    }
                    this.m_updateState();
                    ret = true;
                }
                else{
                    //already handled in left right key.
                }
                break;
        
            default:
                return ret;
                break;
        }
        return ret;
    };
    
    /**
	* This function will set bgcolor of TextTap<p>
	* This function will set bgcolor of TextTap,You can use this function when you want to set bgcolor.
	* @param {Color Object} param of the bgcolor you want to create.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set bgcolor.
	* sampleTextTap.setBGColor({r:50, g:50, b:50, a:128});
	* @since The version 1.0 this function is added.
	*/            
    this.setBGColor = function(color)
    {
        if(this.isCreated == true && "object" == typeof color){
            this.rootWidget.color = color;
            return true;
        }
        return false;
    };
    
	/**
	* This function will set item bgcolor of TextTap<p>
	* This function will set item bgcolor of TextTap,You can use this function when you want to set item bgcolor.
	* @param1 {state}.
	* @param2 {Color Object} param of the item bgcolor you want to create.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set item bgcolor.
	* sampleTextTap.setItemBGColor(sampleTextTap.enumState.NORMAL,{r:100, g:100, b:100, a:255});
	* @since The version 1.0 this function is added.
	*/    
    this.setItemBGColor = function(state, color)
    {
        if (this.isCreated == true && "number"==typeof state && "object"==typeof color
            &&(0 <= state) && (this.enumState.ALL > state)) {
            this.stateItemBGColor[state] = color;
            this.m_updateState();
            return true;
        }
        return false;        
    };
    
	   
	/**
	* This function will set text color of TextTap<p>
	* This function will set text color of TextTap,You can use this function when you want to set text color.
	* @param1 {state}.
	* @param2 {Color Object} param of the text color you want to create.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set text color.
	* sampleTextTap.setTextColor(sampleTextTap.enumState.NORMAL,{r:0, g:0, b:0, a:255});
	* @since The version 1.0 this function is added.
	*/ 
    this.setTextColor = function(state, color)
    {
        if (this.isCreated == true && "number"==typeof state && "object"==typeof color
            &&(0 <= state) && (this.enumState.ALL > state)) {
            this.stateTextColor[state] = color;
            this.m_updateState();
            return true;
        }	
        return false;
    };
    
    this.setCallback = function(callback){
		 if(this.isCreated == true && this.isCreated == true 
            && "function" == typeof callback){
            this.callback = callback;
        }
    };
    
    this.m_updateState = function()
    {
        for(var index = 0; index < this.itemNum; index++)
        {
            if(this.stateItemBGColor[this.enumState.NORMAL] != null)
                this.itemList[index].color = this.stateItemBGColor[this.enumState.NORMAL];
            if(this.stateTextColor[this.enumState.NORMAL])
                this.itemTextList[index].textColor = this.stateTextColor[this.enumState.NORMAL];
        }
        if(this.stateItemBGColor[this.enumState.SELECTED] != null)
            this.itemList[this.selectIndex].color = this.stateItemBGColor[this.enumState.SELECTED];
        if(this.stateTextColor[this.enumState.SELECTED] != null)
            this.itemTextList[this.selectIndex].textColor = this.stateTextColor[this.enumState.SELECTED];
            
        if(this.stateItemBGColor[this.enumState.FOCUSED] != null)
            this.itemList[this.focusIndex].color = this.stateItemBGColor[this.enumState.FOCUSED];
        if(this.stateTextColor[this.enumState.FOCUSED] != null)
            this.itemTextList[this.focusIndex].textColor = this.stateTextColor[this.enumState.FOCUSED];
    };
        		   
}
TextTap.prototype = new ControlBase();
exports = TextTap;
