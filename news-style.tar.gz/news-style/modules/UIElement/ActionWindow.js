 /** 
 * @author  
 * @fileoverview Definition of ActionWindow
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
const ControlBase = Volt.require("modules/UIElement/ControlBase.js");
const Button = Volt.require("modules/UIElement/Button_Generic.js");
const SimpleLineListForPopup = Volt.require("modules/UIElement/SimpleLineListForPopup.js");

var KeyCode = {
	up : Volt.KEY_JOYSTICK_UP,
	down : Volt.KEY_JOYSTICK_DOWN,
	left : Volt.KEY_JOYSTICK_LEFT,
	right : Volt.KEY_JOYSTICK_RIGHT,
	enter : Volt.KEY_JOYSTICK_OK,
}

var KeyType = {
	press : Volt.EVENT_KEY_PRESS,
	release : Volt.EVENT_KEY_RELEASE
}

ActionWindow = function(){
	this.m_BGWidget = null;
	this.m_TitleWidget = null;
	this.m_SplitWidget = null;
	this.m_ContentWidget = null;
	this.m_BothListWidget = null;
	this.m_ScrollTypeFlag = false;
	this.m_WithContentFlag = false;
	this.isFocusOnBtn = false;
	this.focusBtnIndex = -1;
		 
	  /**
		* This function creates an ActionWindow object. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example create an instance.
		*sampleActionWindow = new ActionWindow();
		*sampleActionWindow.create({x:0, 
        *                  y:212, 
        *                  width:1920, 
        *                  height:656,
        *                  color:{r: 10, g: 93, b: 136, a: 217},
        *                  parent:scene,
        *                  scrollTypeFlag:true,
        *                  withContentFlag:false
        *                });
		* @since The version 1.0 this function is added.
	*/
	 this.t_create = function(obj) {	
		var width = 1920;
		var height = 656;		
		var parent = null;
		var color = {r: 10, g: 93, b: 136, a: 217};
		
		if (obj.hasOwnProperty("height")) {
			height = obj.height;
		}
		if (obj.hasOwnProperty("width")) {
			width = obj.width;
		}		
		if (obj.hasOwnProperty("color")) {
			color = obj.color;
		}
		if (obj.hasOwnProperty("parent")) {
			parent = obj.parent;
		}
		if (obj.hasOwnProperty("scrollTypeFlag")){
			this.m_ScrollTypeFlag = obj.scrollTypeFlag;
		}
		if (obj.hasOwnProperty("withContentFlag")){
			this.m_WithContentFlag = obj.withContentFlag;
		}
		
		this.m_BGWidget = new Widget({
			x : 0,
			y : 0,
			width : width,
			height : height,
			parent : parent,
			color : color,
			cropOverflow : true		
		});
		
		this.m_TitleWidget = new TextWidget({
			horizontalAlignment:"center",
	    	verticalAlignment:"center",
			parent : this.m_BGWidget,
		});
		
		this.m_SplitWidget = new Widget({
			parent : this.m_BGWidget,
		});
		
		if(this.m_WithContentFlag){
			this.m_ContentWidget = new TextWidget({
				parent : this.m_BGWidget,
			});
		}			
	 };
	 
	 /**
		* This function sets the properties of action window title. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example sets the properties of action window title.
		*sampleActionWindow.setTitleAtrr({ x:399, 
        *                          y:5, 
        *                          width:1122, 
        *                          height:90,
        *                          text:"Action Window Scroll Type",
        *                          textColor:{r:255, g:255, b:255},
        *                          textFont:"Samsung SVD_Medium 46px"});                       
		* @since The version 1.0 this function is added.
	*/
	 this.setTitleAtrr = function(obj){
		var x_temp = 399;
		var y_temp = 5;
		var width_temp = 1122;
		var height_temp = 90;
		var textFont_temp = "Samsung SVD_Medium 46px";
		var textColor_temp = {r:255, g:255, b:255};
		var text_temp = null;
		
		if (obj.hasOwnProperty("x")){
			x_temp = obj.x;
		}
		if (obj.hasOwnProperty("y")){
			y_temp = obj.y;
		}
		if (obj.hasOwnProperty("width")){
			width_temp = obj.width;
		}
		if (obj.hasOwnProperty("height")){
			height_temp = obj.height;
		}
		if  (obj.hasOwnProperty("textFont")){
			textFont_temp = obj.textFont;		
		}
		if  (obj.hasOwnProperty("textColor")){
			textColor_temp = obj.textColor;		
		}
		if  (obj.hasOwnProperty("text")){
			text_temp = obj.text;		
		}
		
		this.m_TitleWidget.x = x_temp;
		this.m_TitleWidget.y = y_temp;
		this.m_TitleWidget.width = width_temp;
		this.m_TitleWidget.height = height_temp;
		this.m_TitleWidget.text = text_temp;
		this.m_TitleWidget.textColor = textColor_temp;
		this.m_TitleWidget.font = textFont_temp;		
	 };
	 
	 /**
		* This function sets the properties of action window split line. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example sets the properties of action window split line.
		*sampleActionWindow.setSplitLineAtrr({x:399, 
        *                             y:95, 
        *                             width:1122, 
        *                             height:1,
        *                             color:{r:255, g:255, b:255, a:51}
        *                           });            
		* @since The version 1.0 this function is added.
	*/
	 this.setSplitLineAtrr = function(obj){
		var x_temp = 399;
		var y_temp = 95;
		var width_temp = 1122;
		var height_temp = 1;
		var color_temp = {r:255, g:255, b:255, a:51};
		
		if (obj.hasOwnProperty("x")){
			x_temp = obj.x;
		}
		if (obj.hasOwnProperty("y")){
			y_temp = obj.y;
		}
		if (obj.hasOwnProperty("width")){
			width_temp = obj.width;
		}
		if (obj.hasOwnProperty("height")){
			height_temp = obj.height;
		}
		if (obj.hasOwnProperty("color")){
			color_temp = obj.color;		
		}
		
		this.m_SplitWidget.x = x_temp;
		this.m_SplitWidget.y = y_temp;
		this.m_SplitWidget.width = width_temp;
		this.m_SplitWidget.height = height_temp;
		this.m_SplitWidget.color = color_temp;
	}; 
	 
	 this.setContentAtrr = function(obj){
	 	if (this.m_WithContentFlag){
			var x_temp = 399;
			var y_temp = 105;
			var width_temp = 1122;
			var height_temp = 48;
			var textFont_temp = "Samsung SVD_Light 34px";
			var textColor_temp = {r:255, g:255, b:255, a:229.5};
			var text_temp = null;
			
			if (obj.hasOwnProperty("x")){
				x_temp = obj.x;
			}
			if (obj.hasOwnProperty("y")){
				y_temp = obj.y;
			}
			if (obj.hasOwnProperty("width")){
				width_temp = obj.width;
			}
			if (obj.hasOwnProperty("height")){
				height_temp = obj.height;
			}
			if  (obj.hasOwnProperty("textFont")){
				textFont_temp = obj.textFont;		
			}
			if  (obj.hasOwnProperty("textColor")){
				textColor_temp = obj.textColor;		
			}
			if  (obj.hasOwnProperty("text")){
				text_temp = obj.text;		
			}
			
			this.m_ContentWidget.x = x_temp;
			this.m_ContentWidget.y = y_temp;
			this.m_ContentWidget.width = width_temp;
			this.m_ContentWidget.height = height_temp;
			this.m_ContentWidget.text = text_temp;
			this.m_ContentWidget.textColor = textColor_temp;
			this.m_ContentWidget.font = textFont_temp;
		}			 
	 };
	 
	 /**
		* This function sets the properties of the both list or single line list. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example sets the properties of menu list.
		*sampleActionWindow.setBothListAtrr({x:399,
        *                            y:97,
        *                            itemWidth:782,
        *                            itemHeight:72,
        *                            listNum:20,
        *                            upArrowSrc: {highlight: "actionWindowImg/popup_arrow_up_f.png", unHighlight: "actionWindowImg/popup_arrow_up_n.png"},
        *                            downArrowSrc: {highlight: "actionWindowImg/popup_arrow_down_f.png", unHighlight: "actionWindowImg/popup_arrow_down_n.png"},
        *                            topMargin:44                                                                     bottomMargin:44,
        *                            listRenderType:BothListCheckRender
        *                        });                                 
		* @since The version 1.0 this function is added.
	*/
	 this.setBothListAtrr = function(obj){
		var x_temp = 568;
		var y_temp = 97;
		var itemWidth_temp = 782;
		var itemHeight_temp = 72;
		var listNum_temp = 6;
		var topMargin_temp = 0;
		var bottomMargin_temp = 0;
		
		if(this.m_ScrollTypeFlag == true){
			topMargin_temp = 44;
			bottomMargin_temp = 44;
		}
		
		if (obj.hasOwnProperty("x")){
			x_temp = obj.x;
		}
		if (obj.hasOwnProperty("y")){
			y_temp = obj.y;
		}
		if (obj.hasOwnProperty("itemWidth")){
			itemWidth_temp = obj.itemWidth;
		}
		if  (obj.hasOwnProperty("itemHeight")){
			itemHeight_temp = obj.itemHeight;		
		}
		if  (obj.hasOwnProperty("listNum")){
			listNum_temp = obj.listNum;		
		}
		if  (obj.hasOwnProperty("topMargin")){
			topMargin_temp = obj.topMargin;		
		}
		if  (obj.hasOwnProperty("bottomMargin")){
			bottomMargin_temp = obj.bottomMargin;		
		}
			
		this.m_BothListWidget = new SimpleLineListForPopup();
			if (this.m_ScrollTypeFlag == true){
				this.m_BothListWidget.create({
				x: x_temp,
				y: y_temp,
				renderType: obj.listRenderType,
				upArrowSrc: obj.upArrowSrc,
				downArrowSrc: obj.downArrowSrc,
				itemWidth: itemWidth_temp,
				itemHeight: itemHeight_temp,
				totalDataNumber: listNum_temp,
				topMargin: topMargin_temp,
				bottomMargin: topMargin_temp,
				parent: this.m_BGWidget,
			});
		}
		else{
			this.m_BothListWidget.create({
				x: x_temp,
				y: y_temp,
				renderType: obj.listRenderType,
				itemWidth: itemWidth_temp,
				itemHeight: itemHeight_temp,
				totalDataNumber: listNum_temp,
				topMargin: topMargin_temp,
				bottomMargin: topMargin_temp,
				parent: this.m_BGWidget,
			});				
		}		

		var _this = this;
		this.m_BothListWidget.setReachBottomCB(function() {
			if (_this.m_ScrollTypeFlag == false){
				_this.OKButton.getFocus();
				_this.isFocusOnBtn = true;
				_this.focusBtnIndex = 0;
				_this.m_BothListWidget.loseFocus();
			}	
		});	
	 };
	 	 
	 this.bothListUpdate = function(){
		this.m_BothListWidget.update();
	 };
	 
	 this.setBothListItemLoadCB = function(callback){	 
		this.m_BothListWidget.setItemLoadCB(callback);
	 };
	 
	 this.setBothListItemFocusChangedCB = function(callback){
		this.m_BothListWidget.setFocusIndexChangedCB(callback);
	 };
	 
	 this.setBothListCheckStatusChangedCB = function(callback){
		this.m_BothListWidget.setDataChangedCB(callback);
	 };
	 
	 this.itemUpdate = function(index, listText){
		this.m_BothListWidget.itemUpdate(index, listText);	 
	 };
	 
	 /**
		* This function sets the properties of action window ok button. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example sets the properties of action window ok button.
		*sampleActionWindow.setOKButtonAtrr({x:1253,
        *                            y:302,
        *                            width:270,
        *                            height:66,                                                 
        *                            textFont:"Samsung SVD_Light 32px"
        *                        });         
		* @since The version 1.0 this function is added.
	*/	 
	 this.setOKButtonAtrr = function(obj){
		var x_temp = 0;
		var y_temp = this.m_BGWidget.height - 96;
		var width_temp = 270;
		var height_temp = 66;
		var textFont_temp = "Samsung SVD_Light 32px";
		
		if (this.m_ScrollTypeFlag == true){
			x_temp = 1253;
			y_temp = 302;
		}
		else{
			x_temp = 684;
			y_temp = this.m_BGWidget.height - 96;
		}
		
		if (obj.hasOwnProperty("x")){
			x_temp = obj.x;
		}
		if (obj.hasOwnProperty("y")){
			y_temp = obj.y;
		}
		if (obj.hasOwnProperty("width")){
			width_temp = obj.width;
		}
		if (obj.hasOwnProperty("height")){
			height_temp = obj.height;
		}
		if  (obj.hasOwnProperty("textFont")){
			textFont_temp = obj.textFont;		
		}
			
		this.OKButton = new Button();
		this.OKButton.create({x:x_temp, y:y_temp, width:width_temp, height:height_temp, parent:this.m_BGWidget});
		this.OKButton.setTextFont(textFont_temp);
	 };
	 
	 this.setOKButtonStatusSrc = function(obj){
		if ((obj.hasOwnProperty("text")) && (obj.hasOwnProperty("status"))){
			this.OKButton.setText(obj.status, obj.text);
		}
		if ((obj.hasOwnProperty("textColor")) && (obj.hasOwnProperty("status"))){
			this.OKButton.setTextColor(obj.status, obj.textColor);
		}
		if ((obj.hasOwnProperty("imageSrc")) && (obj.hasOwnProperty("status"))){
			this.OKButton.setImage(obj.status, obj.imageSrc);
		}	 
	 };
	 
	 this.setCancelButtonAttr = function(obj){
		var x_temp = 0;
		var y_temp = this.m_BGWidget.height - 96;
		var width_temp = 270;
		var height_temp = 66;
		var textFont_temp = "Samsung SVD_Light 32px";
			
		if (this.m_ScrollTypeFlag == true){
			x_temp = 1253;
			y_temp = 384;
		}
		else{
			x_temp = 966;
			y_temp = this.m_BGWidget.height - 96;
		}
		
		if (obj.hasOwnProperty("x")){
			x_temp = obj.x;
		}
		if (obj.hasOwnProperty("y")){
			y_temp = obj.y;
		}
		if (obj.hasOwnProperty("width")){
			width_temp = obj.width;
		}
		if (obj.hasOwnProperty("height")){
			height_temp = obj.height;
		}
		if  (obj.hasOwnProperty("textFont")){
			textFont_temp = obj.textFont;		
		}
		
		this.cancelButton = new Button();
		this.cancelButton.create({x:x_temp, y:y_temp, width:width_temp, height:height_temp, parent:this.m_BGWidget});
		this.cancelButton.setTextFont(textFont_temp); 
	 };
	 
	 this.setCancelButtonStatusSrc = function(obj){
		if ((obj.hasOwnProperty("text")) && (obj.hasOwnProperty("status"))){
			this.cancelButton.setText(obj.status, obj.text);
		}
		if ((obj.hasOwnProperty("textColor")) && (obj.hasOwnProperty("status"))){
			this.cancelButton.setTextColor(obj.status, obj.textColor);
		}
		if ((obj.hasOwnProperty("imageSrc")) && (obj.hasOwnProperty("status"))){
			this.cancelButton.setImage(obj.status, obj.imageSrc);
		}	
	 };
	 
	 this.setOKButtonOnClickCallback = function(callback){
			this.OKButton.setMouseClickCallback(callback);
	 };
	 
	 this.setCancelButtonOnClickCallback = function(callback){
			this.cancelButton.setMouseClickCallback(callback);
	 };
	
	this.t_destroy = function() {	
		if (this.m_SplitWidget != null){
			this.m_SplitWidget.destroy();
			this.m_SplitWidget = null;
		}
		
		if (this.m_TitleWidget != null){
			this.m_TitleWidget.destroy();
			this.m_TitleWidget = null;
		}
	
		if(this.m_ContentWidget != null){
			this.m_ContentWidget.destroy();
			this.m_ContentWidget = null;
		}
		if (this.m_BothListWidget != null){
			this.m_BothListWidget.destroy();
			this.m_BothListWidget = null;
		}
		
		if (this.OKButton != null){
			this.OKButton.destroy();
		}
		
		if (this.cancelButton != null){
			this.cancelButton.destroy();
			this.cancelButton = null; 
		}
		
		if(this.m_BGWidget != null){
			this.m_BGWidget.destroy();
			this.m_BGWidget	= null;	
		}
	};
	
	this.t_getFocus = function() {
		this.m_BothListWidget.getFocus();
	};

	this.t_loseFocus = function() {
		this.m_BothListWidget.loseFocus();
		this.OKButton.loseFocus();
		this.cancelButton.loseFocus();
	};
	
	this.t_keyHandler = function(keycode, keytype){
	
		switch(keycode) {
			case KeyCode.up:
				// to do
				if (this.m_ScrollTypeFlag){
					if(this.isFocusOnBtn == false){
						this.m_BothListWidget.keyHandler(keycode, keytype);
					}
					else{
						if (this.focusBtnIndex == 1){
							this.cancelButton.loseFocus();
							this.OKButton.getFocus();
							this.focusBtnIndex = 0;
						}
					}				
				}
				else{
					if (this.isFocusOnBtn == false){
						this.m_BothListWidget.keyHandler(keycode, keytype);
					}
					else{
						this.cancelButton.loseFocus();
						this.OKButton.loseFocus();
						this.isFocusOnBtn  = false;
						this.focusBtnIndex = -1;
						this.m_BothListWidget.getFocus();
					}				
				}
				break;
				
			case KeyCode.down:
				// to do
				if (this.m_ScrollTypeFlag){
					if(this.isFocusOnBtn == false){
						this.m_BothListWidget.keyHandler(keycode, keytype);
					}
					else{
						if (this.focusBtnIndex == 0){
							this.OKButton.loseFocus();
							this.cancelButton.getFocus();
							this.focusBtnIndex = 1;
						}
					}
				}
				else{
				  if(this.isFocusOnBtn == false){
						this.m_BothListWidget.keyHandler(keycode, keytype);
				  }				
				}
				break;
				
			case KeyCode.right:
				// to do
				if (this.m_ScrollTypeFlag){
					if(this.isFocusOnBtn == false){
						this.OKButton.getFocus();
						this.isFocusOnBtn = true;
						this.focusBtnIndex = 0;
						this.m_BothListWidget.loseFocus();
					}				
				}
				else{
					if(this.isFocusOnBtn == true){
						if (this.focusBtnIndex == 0){
							this.OKButton.loseFocus();
							this.cancelButton.getFocus();
							this.focusBtnIndex = 1;
						}
					}								
				}
				break;
				
			case KeyCode.left:
				// to do
				if (this.m_ScrollTypeFlag){
					if(this.isFocusOnBtn == true){
						this.OKButton.loseFocus();
						this.cancelButton.loseFocus();
						this.isFocusOnBtn = false;
						this.focusBtnIndex = -1;
						this.m_BothListWidget.getFocus();
					}
				}
				else{
					if (this.focusBtnIndex == 1){
						this.cancelButton.loseFocus();
						this.OKButton.getFocus();
						this.focusBtnIndex = 0;
					}			
				}
				break;
				
			case KeyCode.enter:
				//to do			
				if (this.isFocusOnBtn == true){
					if (this.focusBtnIndex == 0){
						this.OKButton.keyHandler(keycode, keytype);
					}
					else{
						this.cancelButton.keyHandler(keycode, keytype);
					}				
				}
				else{
					this.m_BothListWidget.keyHandler(keycode, keytype);				
				}				
				break;
	
			default:
				// to do
				break;
		}
	
	}; 
}

ActionWindow.prototype = new ControlBase();
exports = ActionWindow;