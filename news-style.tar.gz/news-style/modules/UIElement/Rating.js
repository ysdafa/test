/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of Rating
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	const ControlBase = Volt.require("modules/UIElement/ControlBase.js");
	var KeyCode = {
		left : Volt.KEY_JOYSTICK_LEFT,
		right : Volt.KEY_JOYSTICK_RIGHT,
	}
	function setTimeout(cb, interval, param) {
		return Volt.setTimeout(cb, interval, param);
	}
	
/**
 * Class Rating.
class
 * @constructor
 * @extends UIElement/ControlBase 
 */
 
	Rating = function() {  
		this.ratingArray=[];
		this.starNum=0;
		this.starWidth=0;
		this.starHeight=0;
		this.starSrc="";
		this.selectStarSrc="";
		this.starGap=0;
		this.fontArrowX=0;
		this.fontArrowY=0;
		this.fontArrowWidth=0;
		this.fontArrowHeight=0;
		this.fontArrowSrc="";
		this.backArrowSrc="";
		this.backArrowX=0;
		this.backArrowY=0;
		this.backArrowWidth=0;
		this.backArrowHeight=0;
		this.starPositionY=0;
		this.starPositionX=0;
		this.selectedIndex=-1;
		this.bgWidth=0;
		this.bgHeight=0;
		this.bgColor={r: 0, g: 0, b: 0, a: 0};
		this.ratingFocus=false;
		this.isCreate=false;
		this.backArrow=null;
		this.fontArrow=null;
		this.mouseOverCallBack=null;
		this.mouseOutCallBack=null;
		this.mouseClickCallBack=null;
		this.ratingArea=null;
		this.openOverout=false;
		this.openClick=false;
		
		 /**
		* This function will create an Rating<p>
		* This function will create an Rating,You can use this function when you want to create an Rating Object.
		* @param {Object} param of the new Rating you want to create.
		* @return {Object} return the new Rating object you want to create.
		* @example //This example create a new Rating.
		* const script_AID = "UIElement/Rating";
		* const Rating = require(script_AID);
		* RatingSample = new Rating();
		* var color1={r : 112,g : 112,b : 112,a : 0};
		* RatingSample.create({x:500, y:300, width:300, height:80, color:color1,cursorImages:"",parent:tempBG});
		* @since The version 1.0 this function is added.
		*/
		this.t_create = function(obj) {
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(obj.hasOwnProperty("color")){
				this.bgColor=obj.color;
			}
			if(obj.hasOwnProperty("width")){
				this.bgWidth=obj.width;
			}
			if(obj.hasOwnProperty("height")){
				this.bgHeight=obj.height;
			}
			if(obj.hasOwnProperty("cursorImages")&&obj.cursorImages != null){//cursor image
				this.focusImages=obj.cursorImages;
				cursorClass	= Volt.require("modules/UIElement/CursorComponent.js");
				this.CursorInstance = new cursorClass(this.focusImages);
				this.CursorInstance.x = 0;
				this.CursorInstance.y = 0;
				this.CursorInstance.parent = this.rootWidget;
				this.CursorInstance.hide();
			}
			this.ratingX=this.bgHeight;
			this.ratingY=0;
			this.ratingWidth=this.bgWidth-this.bgHeight*2;
			this.ratingHeight=this.bgHeight;
			this.initx=this.rootWidget.getAbsolutePosition().x;
			this.inity=this.rootWidget.getAbsolutePosition().y;
			this.isCreate=true;
			return true;
	    };
		
		this.t_setMouseOverOutCallback = function(obj){
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(obj.hasOwnProperty("overCallback")){
				this.mouseOverCallBack=obj.overCallback;
			}
			if(obj.hasOwnProperty("outCallback")){
				this.mouseOutCallBack=obj.outCallback;
			}
		}
		
		this.t_MouseOverOut = function(isOnFlag){
			if(this.isCreated == true){
				if(isOnFlag==true){
					if(this.openOverout==false){
						this.rootWidget.addEventListener("OnMouseOver", this.t_ratingMouseOverBind);
						this.rootWidget.addEventListener("OnMouseOut", this.t_ratingMouseOutBind);
						this.openOverout=true;
					}
				}
				else{
					if(this.openOverout==true){
						this.rootWidget.removeEventListener("OnMouseOver", this.t_ratingMouseOverBind);
						this.rootWidget.removeEventListener("OnMouseOut", this.t_ratingMouseOutBind);
						this.openOverout=false;
					}
				}
			}
		};
		
		this.t_MouseClick= function(isOnFlag){
			if(this.isCreated == true){
				if(isOnFlag==true){
					if(this.openClick==false){
						for(var i=0;i<this.starNum;i++){
							if(this.ratingArray[i]!=null||typeof(this.ratingArray[i])!="undefined"){
								this.ratingArray[i].addEventListener("OnMouseClick", this.t_ratingMouseClickBind);
							}					
							
						}
						this.openClick=true;
					}	
				}
				else{
					if(this.openClick==true){
						for(var i=0;i<this.starNum;i++){
							if(this.ratingArray[i]!=null||typeof(this.ratingArray[i])!="undefined"){
								this.ratingArray[i].removeEventListener("OnMouseClick", this.t_ratingMouseClickBind);
							}					
							
						}
						this.openClick=false;
					}	
				}
			}
		};
		
		this.t_setMouseClickCallback = function(callback){
			if(callback!=null||typeof(callback)!="undefined"){
				this.mouseClickCallBack=callback;
			}
		};
	    
	    this.t_destroy = function() {
			delete this.t_ratingMouseOutBind;
			delete this.t_ratingMouseOverBind;
			delete this.t_ratingMouseClickBind;
			var num=this.ratingArray.length;
			if(num != 0){
				for(var i=num-1;i>=0;i--){
					this.ratingArray[i].destroy();
				}
				this.ratingArray.splice(0, this.ratingArray.length);
				this.ratingArray = null;
			}
			if(this.ratingArea != null){
				this.ratingArea.destroy();
				this.ratingArea = null;
			}
			if(this.fontArrow != null){
				this.fontArrow.destroy();
				this.fontArrow = null;
			}
			if(this.backArrow != null){
				this.backArrow.destroy();
				this.backArrow = null;
			}
			if(this.CursorInstance != null){
				this.CursorInstance.destroy();
				this.CursorInstance = null;
			}	       	
        };
	
	    this.t_getFocus = function() {
			if(true == this.ratingFocus){
				return false;
			}
			else{
				this.ratingFocus=true;
				if(this.fontArrow != null){
					this.fontArrow.src=this.focusFontArrowSrc;
				}
				if(this.backArrow != null){
					this.backArrow.src=this.focusBackArrowSrc;
				}
				if(this.CursorInstance!=null){
					var self = this;
					setTimeout(function(){ 
						self.CursorInstance.move(self.ratingX,self.ratingY+5,self.ratingWidth,self.ratingHeight-10);			
						self.CursorInstance.show();
					}, 100)
				}
				return true;
			}
	    	
	    };
	
	    this.t_loseFocus = function() {
			if(false == this.ratingFocus){
				return false;
			}
			else{
				if(this.CursorInstance!=null){
					this.CursorInstance.hide();
				}
				if(this.fontArrow != null){
					this.fontArrow.src=this.fontArrowSrc;
				}
				if(this.backArrow != null){
					this.backArrow.src=this.backArrowSrc;
				}
				this.ratingFocus=false;
				return true;
			}
			
	    };
		
		this.getStarNum= function() {
			return (this.selectedIndex+1);
	    };
		
		 /**
		* This function will set rating content property of Rating created.<p>
		* This function will set rating content property of Rating created,You can use this function when you want to set rating content property.
		* @param {Object} param of rating content property you want to set.
		* @return {Boolean} return true if set succeed,else return false.
		* @example //This example set rating content property.
		* RatingSample.setRatingContent({ratingx:50,
								   ratingy:0,
								   ratingwidth:200,
								   ratingheight:80,
								   starwidth:40,
								   starheight:80,
								   starimage:{normal:"Rating/popup_rating_off.png", selected:"Rating/popup_rating_on.png"},
								   starnum:4,
								   stargap:5,
								   stary:5,
								   starx:5});
		* @since The version 1.0 this function is added.
		*/
		this.setRatingContent = function(obj){		
			if(false == this.isCreate){
				return false;
			}
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(obj.hasOwnProperty("ratingx")){
				this.ratingX=obj.ratingx;
			}
			if(obj.hasOwnProperty("ratingy")){
				this.ratingY=obj.ratingy;
			}
			if(obj.hasOwnProperty("ratingwidth")){
				this.ratingWidth=obj.ratingwidth;
			}
			if(obj.hasOwnProperty("ratingheight")){
				this.ratingHeight=obj.ratingheight;
			}
			if(this.ratingArea == null){
				this.ratingArea= new Widget({
						/*x : ratingx,
						y : ratingy,
						width : ratingwidth,
						height : ratingheight,*/
						color : this.bgColor,
						parent : this.rootWidget
				});
			}
			this.ratingArea.x=this.ratingX;
			this.ratingArea.y=this.ratingY;
			this.ratingArea.width=this.ratingWidth;
			this.ratingArea.height=this.ratingHeight;
			if(obj.hasOwnProperty("starwidth")){
				this.starWidth=obj.starwidth;
			}
			if(obj.hasOwnProperty("starheight")){
				this.starHeight=obj.starheight;
			}
			if(obj.hasOwnProperty("starimage")){
				if(obj.starimage.hasOwnProperty("normal")){
					if ("string"== typeof(obj.starimage.normal)){
						this.starSrc=obj.starimage.normal;
					}
				}
				if(obj.starimage.hasOwnProperty("selected")){
					if ("string"== typeof(obj.starimage.selected)){
						this.selectStarSrc=obj.starimage.selected;
					}
				}
				else{
					this.selectStarSrc=this.starSrc;
				}
			}
			if(obj.hasOwnProperty("starnum")){
				if(obj.starnum>0){
					this.starNum=obj.starnum;
				}
			}
			if(obj.hasOwnProperty("stargap")){
				this.starGap=obj.stargap;
			}
			if(obj.hasOwnProperty("stary")){
				this.starPositionY=obj.stary;
			}
			if(obj.hasOwnProperty("starx")){
				this.starPositionX=obj.starx;
			}
			
			var num=this.ratingArray.length;
			if(num!=this.starNum){
				for(var i=num-1;i>=0;i--){
					this.ratingArray[i].destroy();
				}
				this.ratingArray.splice(0, this.ratingArray.length);
				for(var i=0;i<this.starNum;i++){
					 temp = new ImageWidget({
						x :(this.starWidth+this.starGap)*i+this.starPositionX,
						y : this.starPositionY,
						width : this.starWidth,
						height : this.starHeight,
						src : this.starSrc,
						parent : this.ratingArea
					});
					temp.index=i;
					this.ratingArray.push(temp);
				}
			}
			else{
				for(var i=0;i<this.starNum;i++){
					this.ratingArray[i].x = (this.starWidth+this.starGap)*i+this.starPositionX;
					this.ratingArray[i].y = this.starPositionY;
					this.ratingArray[i].width = this.starWidth;
					this.ratingArray[i].height = this.starHeight;
					this.ratingArray[i].src = this.starSrc;
				}
			}
			return true;
		};
		
		this.t_ratingMouseOver = function(targetWidget, eventData) {
			if(false == this.ratingFocus){
				//this.debugText.text = 'mouse over, get focus';
				//this.getFocus();
			}
			if(null != this.mouseOverCallBack){
				
				this.mouseOverCallBack(this);
			}
			return false;
		};
		this.t_ratingMouseOverBind=this.t_ratingMouseOver.bind(this);

		this.t_ratingMouseOut = function(targetWidget, eventData) {
				var x=eventData.coordinates.x;
				var y=eventData.coordinates.y;
				var abx=x-this.initx;
				var aby=y-this.inity;
				if(abx<=this.bgWidth&&abx>=0&&aby<=this.bgHeight&&aby>=0){
					return false;
				}
				else{
				//	this.loseFocus();
				}
				if(null!=this.mouseOutCallBack){
					this.mouseOutCallBack(this);
				}
				return false;
		};
		this.t_ratingMouseOutBind=this.t_ratingMouseOut.bind(this);
		
		this.t_ratingMouseClick = function(targetWidget, eventData) {
			var index=targetWidget.index;
			if(index==this.selectedIndex){
				this.ratingArray[this.selectedIndex].src=this.starSrc;
				this.selectedIndex=this.selectedIndex-1;
			}
			else if(index<this.selectedIndex){
				for(var j=index;j<=this.selectedIndex;j++)
				{
					this.ratingArray[j].src=this.starSrc;
				}
				this.selectedIndex=index-1;
			}
			else{
				for(var j=this.selectedIndex+1;j<=index;j++){
					this.ratingArray[j].src=this.selectStarSrc;
				}
				this.selectedIndex=index;
			}
			this.m_showarrow();
			if(null!=this.mouseClickCallBack){
				this.mouseClickCallBack(this);
			}
			return false;
		};
		this.t_ratingMouseClickBind=this.t_ratingMouseClick.bind(this);
		
		 /**
		* This function will set font arrow property of Rating created.<p>
		* This function will set font arrow property of Rating created,You can use this function when you want to set font arrow property.
		* @param {Object} param of font arrow property you want to set.
		* @return {Boolean} return true if set succeed,else return false.
		* @example //This example set font arrow property.
		* RatingSample.setFontArrow({x:0,y:0,width:50,height:80,
							   imagesrc:{normal:"Rating/popup_rating_arrow_l_n.png", focus:"Rating/popup_rating_arrow_l_f.png", dim:"Rating/popup_rating_arrow_l_d.png"}});
		* @since The version 1.0 this function is added.
		*/
		this.setFontArrow=function(obj){
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(false == this.isCreate){
				return false;
			}
			if(obj.hasOwnProperty("x")){
				this.fontArrowX=obj.x;
			}
			if(obj.hasOwnProperty("y")){
				this.fontArrowY=obj.y;
			}
			if(obj.hasOwnProperty("width")){
				this.fontArrowWidth=obj.width;
			}
			if(obj.hasOwnProperty("height")){
				this.fontArrowHeight=obj.height;
			}
			
			if(obj.hasOwnProperty("imagesrc")){
				if(obj.imagesrc.hasOwnProperty("normal")){
					if ("string"== typeof(obj.imagesrc.normal)){
						this.fontArrowSrc=obj.imagesrc.normal;
					}
				}
				if(obj.imagesrc.hasOwnProperty("focus")){
					if ("string"== typeof(obj.imagesrc.focus)){
						this.focusFontArrowSrc=obj.imagesrc.focus;
					}
				}
				else{
					this.focusFontArrowSrc=this.fontArrowSrc;
				}
				if(obj.imagesrc.hasOwnProperty("dim")){
					if ("string"== typeof(obj.imagesrc.dim)){
						this.dimFontArrowSrc=obj.imagesrc.dim;
					}
				}
				else{
					this.dimFontArrowSrc=this.fontArrowSrc;
				}
			}
			if(this.fontArrow == null){
				this.fontArrow = new ImageWidget({
					parent : this.rootWidget
				});
			}
			this.fontArrow.x=this.fontArrowX;
			this.fontArrow.y=this.fontArrowY;
			this.fontArrow.width=this.fontArrowWidth;
			this.fontArrow.height=this.fontArrowHeight;
			if(this.ratingFocus==false){
				this.fontArrow.src=this.fontArrowSrc;
			}
			else{
				this.fontArrow.src=this.focusFontArrowSrc;
			}
			this.fontArrow.opacity=0;
			return true;
		};
		
		/**
		* This function will set back arrow property of Rating created.<p>
		* This function will set back arrow property of Rating created,You can use this function when you want to set back arrow property.
		* @param {Object} param of back arrow property you want to set.
		* @return {Boolean} return true if set succeed,else return false.
		* @example //This example set back arrow property.
		* RatingSample.setBackArrow({x:250,y:0,width:50,height:80,
							   imagesrc:{normal:"Rating/popup_rating_arrow_r_n.png", focus:"Rating/popup_rating_arrow_r_f.png", dim:"Rating/popup_rating_arrow_r_d.png"}});
		* @since The version 1.0 this function is added.
		*/
		this.setBackArrow=function(obj){
			if(false == this.isCreate){
				return false;
			}
			if(obj == null||typeof(obj) == "undefined"){
				return false;
			}
			if(obj.hasOwnProperty("x")){
				this.backArrowX=obj.x;
			}
			if(obj.hasOwnProperty("y")){
				this.backArrowY=obj.y;
			}
			if(obj.hasOwnProperty("width")){
				this.backArrowWidth=obj.width;
			}
			if(obj.hasOwnProperty("height")){
				this.backArrowHeight=obj.height;
			}
			if(obj.hasOwnProperty("imagesrc")){
				if(obj.imagesrc.hasOwnProperty("normal")){
					if ("string"== typeof(obj.imagesrc.normal)){
						this.backArrowSrc=obj.imagesrc.normal;
					}
				}
				if(obj.imagesrc.hasOwnProperty("focus")){
					if ("string"== typeof(obj.imagesrc.focus)){
						this.focusBackArrowSrc=obj.imagesrc.focus;
					}
				}
				else{
					this.focusBackArrowSrc=this.backArrowSrc;
				}
				if(obj.imagesrc.hasOwnProperty("dim")){
					if ("string"== typeof(obj.imagesrc.dim)){
						this.dimBackArrowSrc=obj.imagesrc.dim;
					}
				}
				else{
					this.dimBackArrowSrc=this.backArrowSrc;
				}
			}
			if(this.backArrow==null){
				this.backArrow = new ImageWidget({
					parent : this.rootWidget
				});
			}
			this.backArrow.x=this.backArrowX;
			this.backArrow.y=this.backArrowY;
			this.backArrow.width=this.backArrowWidth;
			this.backArrow.height=this.backArrowHeight;
			if(this.ratingFocus==false){
				this.backArrow.src=this.backArrowSrc;
			}
			else{
				this.backArrow.src=this.focusBackArrowSrc;
			}
			return true;
		};
		
		this.moveLeft=function(){
			if(false == this.isCreate){
				return false;
			}
			if(this.selectedIndex==-1){
				return false;
			}
			this.ratingArray[this.selectedIndex].src=this.starSrc;
			this.selectedIndex--;
			this.m_showarrow();
			return true;
		};
		
		this.moveRight=function(){
			if(false == this.isCreate){
				return false;
			}
			if(this.selectedIndex==this.starNum-1){
				return false;
			}
			this.selectedIndex++;
			this.ratingArray[this.selectedIndex].src=this.selectStarSrc;
			this.m_showarrow();	
			return true;
		};
		
		this.m_showarrow=function(){
			if(-1==this.selectedIndex){
				this.fontArrow.opacity=0;
				this.backArrow.opacity=255;
			}
			else if(this.starNum-1==this.selectedIndex){
				
				this.backArrow.opacity=0;
				this.fontArrow.opacity=255;
			}
			else {
				this.fontArrow.opacity=255;
				this.backArrow.opacity=255;
			}
			
		};
		
	    this.t_keyHandler = function(keycode, keytype){
			if(this.ratingFocus==false||this.isCreate==false){
				return false;
			}
			var bRet=false;
			switch(keycode) {
				case KeyCode.left:
					this.moveLeft();
					bRet=true;
					break;
				case KeyCode.right:	
					this.moveRight();
					bRet=true;
					break;
				default:
					// to do
					break;
			}
				return bRet;
	    };
	};
		
	Rating.prototype = new ControlBase();

	exports = Rating;