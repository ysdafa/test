/** 
 * @author  
 * @fileoverview Definition of ExpandableList
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = Volt.require("modules/UIElement/ControlBase.js");

ExpandableList = function() {
	this.m_DataSourceArray = null;  //reserved
	this.m_ItemRanderArray = null;
	this.m_CurDataIndex = 0;
	this.m_CurRanderIndex = 0;
	this.m_ShowIndex = 0;
	this.m_ActualRander = 0;
	this.m_BufferHeadIndex = 0;
	this.m_BufferTailIndex = 0;
	this.m_TotalRanderItem = 0;
	this.m_BufferNumber = 3;
	this.m_ParentWidget = null;
	this.m_DestPosition = 0;
	this.m_ItemHeight = 0;
	this.m_ItemLoadCB = null;
	this.m_ItemUnloadCB = null;
	this.m_ItemNumber = 0;
	this.m_DisplayAreaHead = 0;
	this.m_SubItemListLoadCB = null;
	
	/*
		obj should contains:
		itemWidth
		itemHeight
		subItemWidth
		subItemHeight
		randerType
	*/
	this.t_create = function(obj) {
		this.cropOverflow = true;
		this.m_ParentWidget = new Widget({
			x: 0,
			y: 0,
			parent: obj.parent,
			color: {a: 0},
		});
		
		this.m_ItemNumber = obj.itemNumber ? obj.itemNumber : 0;
		this.m_ItemRanderArray = [];
		this.m_ItemHeight = obj.itemHeight;
		this.m_ActualRander = Math.floor(this.height/obj.itemHeight);
		this.m_TotalRanderItem = Math.floor(this.height/obj.itemHeight)+this.m_BufferNumber*2;
		this.m_ShowIndex = 0;
		this.m_BufferHeadIndex = 0;
		this.m_BufferTailIndex = this.m_TotalRanderItem-1;
		this.m_CurRanderIndex = this.m_BufferNumber;
		this.m_CurDataIndex = 0;
		this.m_DisplayAreaHead = -this.m_BufferNumber;
		
		this.m_DestPosition = 0;
		var offset = -this.m_BufferNumber*obj.itemHeight;
		for (var index = 0; index < this.m_TotalRanderItem; index++) {
			var randerItem = new obj.randerType();
			randerItem.create({
				x: 0,
				y: offset,
				width: obj.itemWidth,
				height: obj.itemHeight,
				subItemWidth: obj.subItemWidth, 
				subItemHeight: obj.subItemHeight,
				parent: this.m_ParentWidget,
			});
			randerItem.initY = offset;
			this.m_ItemRanderArray.push(randerItem);
			offset+=obj.itemHeight;
		}
	};
	
	this.t_getFocus = function() {
		this.m_ItemRanderArray[this.m_CurRanderIndex].getFocus();
	};
	
	this.t_loseFocus = function() {
		this.m_ItemRanderArray[this.m_CurRanderIndex].loseFocus();
	};
	
	this.t_destroy = function() {
	};
	
	this.m_upKeyHandler = function() {
		if (this.m_CurDataIndex == 0) {
			this.m_ItemRanderArray[this.m_CurRanderIndex].getFocus();
			return;
		}
		this.m_ItemRanderArray[this.m_CurRanderIndex].loseFocus();
		this.m_CurDataIndex--;
		this.m_CurRanderIndex = this.m_CurRanderIndex==0 ? this.m_ItemRanderArray.length-1: this.m_CurRanderIndex-1;
		this.m_ItemRanderArray[this.m_CurRanderIndex].getFocus();
		if (this.m_ShowIndex == 0) {
			this.m_ItemRanderArray[this.m_BufferTailIndex].y = this.m_ItemRanderArray[this.m_BufferHeadIndex].y - this.m_ItemHeight;
			this.m_BufferHeadIndex = this.m_BufferTailIndex;
			this.m_ItemRanderArray[this.m_BufferTailIndex].initY = this.m_ItemRanderArray[this.m_BufferTailIndex].y;
			this.m_BufferTailIndex = this.m_BufferTailIndex==0 ? this.m_ItemRanderArray.length-1: this.m_BufferTailIndex-1;
			this.m_ParentWidget.animate("y", -this.m_ItemHeight*this.m_CurDataIndex, 100, "sine");
			this.m_ItemUnloadCBCall(this.m_DisplayAreaHead+this.m_ItemRanderArray.length-1);
			this.m_ItemLoadCBCall(--this.m_DisplayAreaHead);
		} else {
			this.m_ShowIndex--;
		}
	};
	
	this.m_downKeyHandler = function() {
		if (this.m_CurDataIndex == this.m_ItemNumber-1) {
			this.m_ItemRanderArray[this.m_CurRanderIndex].getFocus();
			return;
		}
		this.m_ItemRanderArray[this.m_CurRanderIndex].loseFocus();
		this.m_CurDataIndex++;
		this.m_CurRanderIndex = this.m_CurRanderIndex==this.m_ItemRanderArray.length-1 ? 0: 1+this.m_CurRanderIndex;
		this.m_ItemRanderArray[this.m_CurRanderIndex].getFocus();
		if (this.m_ShowIndex == this.m_ActualRander-1) {
			this.m_ItemRanderArray[this.m_BufferHeadIndex].y = this.m_ItemRanderArray[this.m_BufferTailIndex].y + this.m_ItemHeight;
			this.m_BufferTailIndex = this.m_BufferHeadIndex;
			this.m_ItemRanderArray[this.m_BufferTailIndex].initY = this.m_ItemRanderArray[this.m_BufferTailIndex].y;
			this.m_BufferHeadIndex = this.m_BufferHeadIndex==this.m_ItemRanderArray.length-1 ? 0: 1+this.m_BufferHeadIndex;
			this.m_ParentWidget.animate("y", this.height-this.m_ItemHeight*(this.m_CurDataIndex+1), 100, "sine");
			this.m_ItemUnloadCBCall(this.m_DisplayAreaHead);
			++this.m_DisplayAreaHead;
			this.m_ItemLoadCBCall(this.m_DisplayAreaHead+this.m_ItemRanderArray.length-1);
		} else {
			this.m_ShowIndex++;
		}
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		if (keytype == Volt.EVENT_KEY_RELEASE) 
		{
			return false;
		}		
		
		var preExpand = this.m_ItemRanderArray[this.m_CurRanderIndex].isExpanded;
		if (keycode == Volt.KEY_JOYSTICK_UP && this.m_CurDataIndex == 0 && this.m_ItemRanderArray[this.m_CurRanderIndex].isFocusHead()) {
			return false;
		}
		
		if (keycode == Volt.KEY_JOYSTICK_DOWN && this.m_CurDataIndex == (this.m_ItemNumber-1) && this.m_ItemRanderArray[this.m_CurRanderIndex].isFocusTail()) {
			return false;
		}
		
		if (this.m_ItemRanderArray[this.m_CurRanderIndex].keyHandler(keycode, keytype)) {
			return true;
		}
		var afterExpand = this.m_ItemRanderArray[this.m_CurRanderIndex].isExpanded;
		if (preExpand != afterExpand) {
			if (this.m_ItemRanderArray[this.m_CurRanderIndex].isExpanded) {
				var index = this.m_CurRanderIndex==this.m_ItemRanderArray.length-1 ? 0: 1+this.m_CurRanderIndex;
				if (this.m_ItemRanderArray[this.m_CurRanderIndex].initY+this.m_ItemRanderArray[this.m_CurRanderIndex].height <= this.height-this.m_ParentWidget.y && this.m_CurDataIndex != this.m_ItemNumber-1) {
					for (; index != this.m_BufferHeadIndex;) {
						this.m_ItemRanderArray[index].animate("y", this.m_ItemRanderArray[index].y+this.m_ItemRanderArray[this.m_CurRanderIndex].heightDiffer, 200); //TODO duration should be changed
						index = index==this.m_ItemRanderArray.length-1 ? 0: 1+index;
					}
				} else {
					index = this.m_CurRanderIndex;
					for (; index != this.m_BufferTailIndex;) {
						this.m_ItemRanderArray[index].animate("y", this.m_ItemRanderArray[index].y-this.m_ItemRanderArray[this.m_CurRanderIndex].heightDiffer, 200); //TODO duration should be changed
						index = index==0 ? this.m_ItemRanderArray.length-1: index-1;
					}
				}
			} else {
				var index = this.m_BufferHeadIndex;
				this.m_ItemRanderArray[index].animate("y", this.m_ItemRanderArray[index].initY, 200);
				index = index==this.m_ItemRanderArray.length-1 ? 0: 1+index;
				for (; index != this.m_BufferHeadIndex; ) {
					this.m_ItemRanderArray[index].animate("y", this.m_ItemRanderArray[index].initY, 200);
					index = index==this.m_ItemRanderArray.length-1 ? 0: 1+index;
				}
			}
		} else {
			var index = this.m_BufferHeadIndex;
			this.m_ItemRanderArray[index].animate("y", this.m_ItemRanderArray[index].initY, 200);
			index = index==this.m_ItemRanderArray.length-1 ? 0: 1+index;
			for (; index != this.m_BufferHeadIndex; ) {
				this.m_ItemRanderArray[index].animate("y", this.m_ItemRanderArray[index].initY, 200);
				index = index==this.m_ItemRanderArray.length-1 ? 0: 1+index;
			}
		}
		switch (keycode) {
			case Volt.KEY_JOYSTICK_UP:
				this.m_upKeyHandler();
				return true;
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				this.m_downKeyHandler();
				return true;
				break;
		}
		return false;
	};

	this.setItemLoadCB = function(callback) {
		this.m_ItemLoadCB = callback;
	};
	
	this.setItemUnloadCB = function(callback) {
		this.m_ItemUnloadCB = callback;
	};
	
	this.setSubItemListLoadCB = function(callback) {
		this.m_SubItemListLoadCB = callback;
	};
	
	this.m_ItemLoadCBCall = function(index) {
		if (this.m_ItemLoadCB && index>=0 && index<this.m_ItemNumber) {
			this.m_ItemLoadCB(index);
		}
	};
	
	this.m_ItemUnloadCBCall = function(index) {
		if (this.m_ItemUnloadCB && index>=0 && index<this.m_ItemNumber) {
			this.m_ItemUnloadCB(index);
		}
	};

	this.m_renderIndexPlus = function(startIndex, increment) {
		if (startIndex!=undefined && increment!=undefined) {
			var actualIncrement = increment%this.m_ItemRanderArray.length;
			for (var index=0; index<actualIncrement; index++) {
				startIndex = startIndex==this.m_ItemRanderArray.length-1 ? 0: 1+startIndex;
			}
			return startIndex;
		}
		return 0;
	};
	
	this.m_renderIndexMinus = function(startIndex, decrement) {
		if (startIndex!=undefined && decrement!=undefined) {
			var actualDecrement = decrement%this.m_ItemRanderArray.length;
			for (var index=0; index<actualDecrement; index++) {
				startIndex = startIndex==0 ? this.m_ItemRanderArray.length-1: startIndex-1;
			}
			return startIndex;
		}
		return 0;
	};
	
	this.itemUpdate = function(index, dataItem) {
		if (index >= this.m_DisplayAreaHead && index < this.m_DisplayAreaHead+this.m_TotalRanderItem) {
			dataItem.itemIndex = index;
			var steps = index - this.m_DisplayAreaHead;
			var renderIndex = this.m_renderIndexPlus(this.m_BufferHeadIndex, steps);
			this.m_ItemRanderArray[renderIndex].titleUpdate(dataItem);
			this.m_ItemRanderArray[renderIndex].setItemsLoadCB(this.m_SubItemListLoadCB);
		}
	};
	
	this.subListUpdate = function(index, dataItem) {
		if (index >= this.m_DisplayAreaHead && index < this.m_DisplayAreaHead+this.m_TotalRanderItem) {
			var steps = index - this.m_DisplayAreaHead;
			var renderIndex = this.m_renderIndexPlus(this.m_BufferHeadIndex, steps);
			this.m_ItemRanderArray[renderIndex].listUpdate(dataItem);
		}
	};
	
	this.update = function() {
		for (var i = this.m_DisplayAreaHead; i<this.m_DisplayAreaHead+this.m_TotalRanderItem; i++) {
			this.m_ItemUnloadCBCall(i);
			this.m_ItemLoadCBCall(i);
		}
	};
	
}
ExpandableList.prototype = new ControlBase();

exports = ExpandableList;