/*
Cursor Module

Usage:

//Require in the cursor component
var CursorComponent = require("CursorComponent");

//Instantiate a new CursorComponent
//You can pass in an options argument with a color and border width property or 
//a ninePatch property with images for all 9 sides
var cursor = new CursorComponent();

//or

var cursor = new CursorComponent({
	color: {r:0, g:120, b:160, a:255},
	width: 15
});

//or 

var cursor = new CursorComponent({
	ninePatch: {
		left: "9patch_img/list_high_mid_left.png",
		right: "9patch_img/list_high_mid_right.png",
		top: "9patch_img/list_high_upper_center.png",
		bottom: "9patch_img/list_high_lower_center.png",
		topLeft: "9patch_img/list_high_upper_left.png",
		topRight: "9patch_img/list_high_upper_right.png",
		bottomRight: "9patch_img/list_high_lower_right.png",
		bottomLeft: "9patch_img/list_high_lower_left.png"
	}
});


//Call move to move the cursor to the desired position and dimentions
// .move(x, y, width, height, duration) duration defaults to 100
cursor.move(100, 200, 500, 500, 100);

//Show and hide the cursor
cursor.show() || cursor.hide()

*/

var defaults = {
			color: {
				r: 0,
				g: 120,
				b: 160,
				a: 255
			},
			width: 15
		},
		adjustment = -16; //Needed after screwing with original images 

var CursorComponent = function(options){
	var cursorWidget = new Widget(-200, -200);

	options = options || {};

	cursorWidget.color = {r:0, g:0, b:0, a:0};
	cursorWidget.parent = scene;
	cursorWidget.ninePatch = {};
	cursorWidget.isHidden = false;
	cursorWidget.prevWidth = 0;
	cursorWidget.prevHeight = 0;

	if (options.ninePatch) {
		cursorWidget.type = "ninePatch";

		cursorWidget.ninePatch.left = new ImageWidget({
			src: options.ninePatch.left,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.right = new ImageWidget({
			src: options.ninePatch.right,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.top = new ImageWidget({
			src: options.ninePatch.top,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.bottom = new ImageWidget({
			src: options.ninePatch.bottom,
			parent: cursorWidget
		});

		cursorWidget.ninePatch.topLeft = new ImageWidget({
			src: options.ninePatch.topLeft,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.topRight = new ImageWidget({
			src: options.ninePatch.topRight,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.bottomRight = new ImageWidget({
			src: options.ninePatch.bottomRight,
			parent: cursorWidget
		});
		cursorWidget.ninePatch.bottomLeft = new ImageWidget({
			src: options.ninePatch.bottomLeft,
			parent: cursorWidget
		});

	} else {
		cursorWidget.type = "default";
		cursorWidget.border = {
			width: options.width || defaults.width,
			color: options.color || defaults.color
		};
	}

	//Set up methods on cursor widget
	cursorWidget.move = _move;
	return cursorWidget;

};

var _move = function(x, y, width, height, duration, callback, animGroupIn) {
	duration = duration || 100;
	var handle;
	this.animate("height", height, duration);
	this.animate("width", width, duration);
	this.animate("x", x, duration);
	handle = this.animate("y", y, duration, callback);
	
	return handle;
};


var move = function(x, y, width, height, duration, callback, animGroupIn) {
	var animGroup = animGroupIn || new AnimationGroup();
	duration = duration || 100;
	var handle;
	if (this.type === "ninePatch") {
		animateDimensions.call(this, width, height, duration, animGroup);
		animGroup.addAnim(this, "x", x, duration);
		handle = animGroup.addAnim(this, "y", y, duration, callback);
	} else {
		animGroup.addAnim(this,"height", height, duration);
		animGroup.addAnim(this,"width", width, duration);
		animGroup.addAnim(this,"x", x, duration);
		handle = animGroup.addAnim(this,"y", y, duration, callback);
	}
	if(!animGroupIn)
		animGroup.startAnimation();
	return handle;
};


//Setup image positions and scales

function animateDimensions(width, height, d, animGroup) {
	//Setup image positions
	if (width == this.prevWidth && height == this.prevHeight) {
		return;
	}

	var cornerWidth = this.ninePatch.topLeft.width + adjustment;
	var cornerHeight = this.ninePatch.topLeft.height + adjustment;

	animGroup.addAnim(this.ninePatch.topLeft, "x", -cornerWidth, d);
	animGroup.addAnim(this.ninePatch.topLeft, "y", -cornerHeight, d);

	animGroup.addAnim(this.ninePatch.topRight, "x", width + adjustment, d);
	animGroup.addAnim(this.ninePatch.topRight, "y", -cornerHeight, d);

	animGroup.addAnim(this.ninePatch.bottomRight, "x", width + adjustment, d);
	animGroup.addAnim(this.ninePatch.bottomRight, "y", height + adjustment, d);

	animGroup.addAnim(this.ninePatch.bottomLeft, "x", -cornerWidth, d);
	animGroup.addAnim(this.ninePatch.bottomLeft, "y", height + adjustment, d);

	animGroup.addAnim(this.ninePatch.left, "x", -this.ninePatch.left.width - adjustment, d);
	animGroup.addAnim(this.ninePatch.left, "y", -adjustment, d);

	animGroup.addAnim(this.ninePatch.right, "x", width + adjustment, d);
	animGroup.addAnim(this.ninePatch.right, "y", -adjustment, d);

	animGroup.addAnim(this.ninePatch.top, "x", -adjustment, d);
	animGroup.addAnim(this.ninePatch.top, "y", -this.ninePatch.top.height - adjustment, d);

	animGroup.addAnim(this.ninePatch.bottom, "x", -adjustment, d);
	animGroup.addAnim(this.ninePatch.bottom, "y", height + adjustment, d);

	//Scale the sides
	animGroup.addAnim(this.ninePatch.left, "height", height + adjustment * 2, d);

	animGroup.addAnim(this.ninePatch.right, "height", height + adjustment * 2, d);

	animGroup.addAnim(this.ninePatch.top, "width", width + adjustment * 2, d);

	animGroup.addAnim(this.ninePatch.bottom, "width", width + adjustment * 2, d);

	this.prevWidth = width;
	this.prevHeight = height;
}


exports = CursorComponent;
