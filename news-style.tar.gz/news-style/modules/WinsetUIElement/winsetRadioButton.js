winsetRadioButton = function(obj){	

	// local var
	var style = RadioButtonStyle.Radiobutton_Style_A,
		resoultion = ResoultionStyle.Resoultion_1080,
		radioButton,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		x = 0,
		y = 0,
		width = 150,
		height = 150,
		parent = scene,
		id = null,
		// image path
		bgNormal,
		bgFoucs,
		bgSelect,
		bgDim,
		normalCheckImagePath,
		foucsCheckImagePath,
		selectCheckImagePath,
		dimCheckImagePath,
		// image opcity
		bgNormalOpcity,
		bgFoucsOpcity,
		bgSelectOpcity,
		bgDimOpcity,
		normalCheckImageOpcity,
		foucsCheckImageOpcity,
		selectCheckImageOpcity,
		dimCheckImageOpcity;
				
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (RadioButtonStyle.Radiobutton_Style_A <= objParameter.style)
				&& (RadioButtonStyle.Radiobutton_Style_C >= objParameter.style)){
				
				style = objParameter.style;		
			}
			
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}				
					
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
				
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
		}	
	}
			
	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			path = path + "1080p/radio/";
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/radio/";
		}
		//set default value
		switch(style)
		{
			case RadioButtonStyle.Radiobutton_Style_A:
				{
					// image path
					bgNormal = path + "checkbox_box_w.png";
					bgFoucs = path + "checkbox_box_w.png";
					bgSelect = path + "checkbox_box_y.png";
					bgDim = path + "checkbox_box_w.png";
					
					normalCheckImagePath = path + "checkbox_radio_w.png";
					foucsCheckImagePath = path + "checkbox_radio_w.png";
					selectCheckImagePath = path + "checkbox_radio_y.png";
					dimCheckImagePath = path + "ccheckbox_radio_w.png";
					
					
					// image opcity
					bgNormalOpcity = 51;
					bgFoucsOpcity = 102;
					bgSelectOpcity = 102;
					bgDimOpcity = 26;
					normalCheckImageOpcity = 255;
					foucsCheckImageOpcity = 255;
					selectCheckImageOpcity = 255;
					dimCheckImageOpcity = 26;				
				}
				break;
			
			case RadioButtonStyle.Radiobutton_Style_B_Focus1:
				{
					// image path
					bgNormal = path + "checkbox_box_w.png";
					bgFoucs = path + "checkbox_box_w.png";
					bgSelect = path + "checkbox_box_y.png";
					bgDim = path + "checkbox_box_w.png";
					
					normalCheckImagePath = path + "checkbox_radio_w.png";
					foucsCheckImagePath = path + "checkbox_radio_w.png";
					selectCheckImagePath = path + "checkbox_radio_y.png";
					dimCheckImagePath = path + "ccheckbox_radio_w.png";
										
					// image opcity
					bgNormalOpcity = 102;
					bgFoucsOpcity = 102;
					bgSelectOpcity = 255;
					bgDimOpcity = 26;
					normalCheckImageOpcity = 255;
					foucsCheckImageOpcity = 255;
					selectCheckImageOpcity = 255;
					dimCheckImageOpcity = 26;				
				}
				break;
				
			case RadioButtonStyle.Radiobutton_Style_B_Focus2:
				{
					// image path
					bgNormal = path + "checkbox_box_w.png";
					bgFoucs = path + "checkbox_box_w.png";
					bgSelect = path + "checkbox_box_y.png";
					bgDim = path + "checkbox_box_w.png";
					
					normalCheckImagePath = path + "checkbox_radio_w.png";
					foucsCheckImagePath = path + "checkbox_radio_w.png";
					selectCheckImagePath = path + "checkbox_radio_y.png";
					dimCheckImagePath = path + "ccheckbox_radio_w.png";
					
					// image opcity
					bgNormalOpcity = 255;
					bgFoucsOpcity = 255;
					bgSelectOpcity = 255;
					bgDimOpcity = 255;
					normalCheckImageOpcity = 255;
					foucsCheckImageOpcity = 255;
					selectCheckImageOpcity = 255;
					dimCheckImageOpcity = 255;				
				}	
				break;
				
			case RadioButtonStyle.Radiobutton_Style_C:
				{
					// image path
					bgNormal = path + "checkbox_box_w.png";
					bgFoucs = path + "checkbox_box_w.png";
					bgSelect = path + "checkbox_box_y.png";
					bgDim = path + "checkbox_box_w.png";
					
					normalCheckImagePath = path + "checkbox_radio_w.png";
					foucsCheckImagePath = path + "checkbox_radio_w.png";
					selectCheckImagePath = path + "checkbox_radio_y.png";
					dimCheckImagePath = path + "ccheckbox_radio_w.png";
					
					// image opcity
					bgNormalOpcity = 255;
					bgFoucsOpcity = 255;
					bgSelectOpcity = 255;
					bgDimOpcity = 255;
					normalCheckImageOpcity = 255;
					foucsCheckImageOpcity = 255;
					selectCheckImageOpcity = 255;
					dimCheckImageOpcity = 255;				
				}	
				break;
			default:
				break;
		}
	}
		
	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	// resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + normalCheckImagePath);
	//create selectButton instance 
	radioButton = new SelectButton({
		x: x,
		y: y,
		parent: parent,
		width: width,
		height: height,
		color: { r:0, g:0, b:0, a:0}
	});
	
	if(null != id){
		radioButton.id = id;
	}
	// radioButton.x = x;
	// radioButton.y = y;
	// radioButton.color = { r:0, g:0, b:0, a:0};
		
	// set background image
	radioButton.setBoxBackGroudImage({ state: "normal", imageSrc: bgNormal });
	radioButton.setBoxBackGroudImage({ state: "focused", imageSrc: bgFoucs });
	radioButton.setBoxBackGroudImage({ state: "selected", imageSrc: bgSelect });
	radioButton.setBoxBackGroudImage({ state: "disabled", imageSrc: bgDim });
	
	// set check image
	radioButton.setCheckImage({ state: "normal", imageSrc: normalCheckImagePath });
    radioButton.setCheckImage({ state: "focused", imageSrc: foucsCheckImagePath });
    radioButton.setCheckImage({ state: "selected", imageSrc: selectCheckImagePath });
    radioButton.setCheckImage({ state: "disabled", imageSrc: dimCheckImagePath });
   
   	// set background image's opacity
    radioButton.setBoxBackGroudImageOpacity({ state: "normal",opacity: bgNormalOpcity });
    radioButton.setBoxBackGroudImageOpacity({ state: "focused",opacity: bgFoucsOpcity });
    radioButton.setBoxBackGroudImageOpacity({ state: "selected",opacity: bgSelectOpcity });
    radioButton.setBoxBackGroudImageOpacity({ state: "disabled",opacity: bgDimOpcity });
    
	// set check image's opacity	
    radioButton.setCheckImageOpacity({ state: "normal", opacity: normalCheckImageOpcity });
    radioButton.setCheckImageOpacity({ state: "focused", opacity: foucsCheckImageOpcity });
    radioButton.setCheckImageOpacity({ state: "selected",opacity: selectCheckImageOpcity });
    radioButton.setCheckImageOpacity({ state: "disabled",opacity: dimCheckImageOpcity });
    
    return radioButton;
}

var RadioButtonStyle = {
	Radiobutton_Style_A: 1,
	Radiobutton_Style_B_Focus1: 2,
	Radiobutton_Style_B_Focus2: 3,
	Radiobutton_Style_C: 4
};
		
var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};
				

winsetRadioButton.RadioButtonStyle =  RadioButtonStyle;
winsetRadioButton.ResoultionStyle = ResoultionStyle;

exports = winsetRadioButton;
