winsetMessageBox = function(obj){		
	// local var
	var style = MessageBoxStyle.MessageBox_Title_Button_1Line,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		messagebox = null,
		x = 0,
		y = 0,
		id = null,
		parent = scene,
		screenWidth = 1920,
		screenHeight = 1080,
		width = 1920,
		height = 1080,
		bTitle,
		bButton,
		bgcolor,
		// background
		bgStyle = BackgroundStyle.Background_Style_B_1,
		// title
		titleText = "title",
        titleTextFont,
        titleTextColor,
        titleHeightRate,
        titleRect = {},
        // title line 
        titleLineRect = {},
        // content text
        contentNumber,
        contentLine,
        contextLineNumber = 2,
        contentText = "Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message",
        contentTextFont,
        contentTextColor,
        contentRect = {},
        contentText2 = "Message Popup Message Popup Message Popup",
        contentText2Font,
        contentText2Color,
        contentRect2 = {},
        // button attr
        buttonStyle,
        buttonType,
        button1Rect = {},
        button2Rect = {},
        button_1_Text,
        button_2_Text,
        buttonBgNormal,
		buttonBgFoucs,
		buttonBgSelect,
		buttonBgDim,
		buttonBgNormalColor,
		buttonBgFoucsColor,
		buttonBgSelectColor,
		buttonBgDimColor,
		normalFont,
		focusFont,
		selectFont,
		dimFont,
		normalTextColor,
		focusTextColor,
		selectTextColor,
		dimTextColor,
		// loading
		bLoading = false,
		loadingWidth,
		loadingHeight,
		loadingImageName = [],
		loadingImageNumber = 63,
		loadingImagePath,
		loadingX = 0,
		loadingY = 0,
		bAutoFlag = true;	
        
				
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (MessageBoxStyle.MessageBox_Title_Button_1Line <= objParameter.style)
				&& (MessageBoxStyle.MessageBox_3Line_Loading >= objParameter.style)){
				
				style = objParameter.style;		
			}
		
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}			
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("bgStyle")
				&& (typeof objParameter.bgStyle == "number")
				&& (BackgroundStyle.Background_Style_B_1 <= objParameter.bgStyle)
				&& (BackgroundStyle.Background_Style_B_3 >= objParameter.bgStyle)){
				bgStyle = objParameter.bgStyle;	
			}
			
			if(objParameter.hasOwnProperty("buttonStyle")
				&& (typeof objParameter.buttonStyle == "number")){
				buttonStyle = objParameter.buttonStyle;	
			}
			
			if(objParameter.hasOwnProperty("contextLineNumber")
				&& (typeof objParameter.contextLineNumber == "number")){
				contextLineNumber = objParameter.contextLineNumber;
				print("contextLineNumber is    --------- " + contextLineNumber);
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
			
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
			
			if(objParameter.hasOwnProperty("titleText")
				&& (typeof objParameter.titleText == "string")){
				titleText = objParameter.titleText;	
			}
			
			if(objParameter.hasOwnProperty("contentText")
				&& (typeof objParameter.contentText == "string")){
				contentText = objParameter.contentText;	
			}
			
			if(objParameter.hasOwnProperty("contentText2")
				&& (typeof objParameter.contentText2 == "string")){
				contentText2 = objParameter.contentText2;	
			}
		}
	}
			
	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			loadingWidth = 301;
			loadingHeight = 58;
			loadingImagePath = path + "1080p/Loading/";
			path = path + "1080p/btn/";
			screenWidth = 1920;
			screenHeight = 1080;
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			loadingWidth = 201;
			loadingHeight = 39;
			loadingImagePath = path + "720p/Loading/";
			path = path + "720p/btn/";
			screenWidth = 1280;
			screenHeight = 720;
		}
		
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_720){
			x = 0;
		}
		
		if(resoultion == ResoultionStyle.Resoultion_1080_21_9){
			x = 300;
		}
		
		if(resoultion == ResoultionStyle.Resoultion_720_21_9){
			x = 200;
		}
		//set default value
		switch(style)
		{
			case MessageBoxStyle.MessageBox_Title_Button_1Line:
				{
					bTitle = true;
					// bAutoFlag = false;
					y = (1 - 0.351852) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						titleTextFont = "Sans 44px";
						contentTextFont = "Sans 34px";
						width = 1920;
						height = 1080 * 0.351852;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						titleTextFont = "Sans 30px";
						contentTextFont = "Sans 22px";
						width = 1280;
						height = 720 * 0.351852;
					}
					// title
			       	titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
			       	titleRect.x = (1 - 0.584375)/2 * screenWidth;
			       	titleRect.y = 0;
			       	titleRect.width = 0.584375 * screenWidth;
			       	titleRect.height = 0.089815 * screenHeight;
			        
			        // title line
			        titleLineRect.x = (1 - 0.584375)/2 * screenWidth;
			        titleLineRect.y = 0.089815 * screenHeight + 0;
			        titleLineRect.width = 0.584375 * screenWidth;
			        titleLineRect.height = 1;
			        // content text
			        contentNumber = 1;
			        contextLineNumber = 1;
			        contentLine = "single_line_content_type";
			    
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.089815 + 0.063889 + 0.044444 + 0.064815) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.089815 + 0.063889 + 0.044444 + 0.064815) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
			
			case MessageBoxStyle.MessageBox_Title_Button_2_8Line:
				{
					bTitle = true;
					// bAutoFlag = false;
					y = (1 - 0.089815 - 0.025926 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					 // title line
			        titleLineRect.x = (1 - 0.584375)/2 * screenWidth;
			        titleLineRect.y = 0.089815 * screenHeight + 0;
			        titleLineRect.width = 0.584375 * screenWidth;
			        titleLineRect.height = 1;
			        
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						titleTextFont = "Sans 44px";
						contentTextFont = "Sans 34px";
						width = 1920;
						height = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						titleTextFont = "Sans 30px";
						contentTextFont = "Sans 22px";
						width = 1280;
						height = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					}
					
			       	titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
			       	titleRect.x = (1 - 0.584375)/2 * screenWidth;
			       	titleRect.y = 0;
			       	titleRect.width = 0.584375 * screenWidth;
			       	titleRect.height = 0.089815 * screenHeight;
			       
			        // content text
			        contentNumber = 1;
			        contentLine = "multi_line_content_type";
			   
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.025926) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * contextLineNumber * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_1Line:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.287037) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						titleTextFont = "Sans 44px";
						contentTextFont = "Sans 34px";
						width = 1920;
						height = 0.287037 * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						titleTextFont = "Sans 30px";
						contentTextFont = "Sans 22px";
						width = 1280;
						height = 0.287037 * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contextLineNumber = 1;
			        contentLine = "single_line_content_type";
			        // contentText = "Message Popup";
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.088889 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.088889 +  0.044444  + 0.064815) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.088889 +  0.044444  + 0.064815) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;	
			
			case MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.044444 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						width = 1920;
						height = (0.044444 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						width = 1280;
						height = (0.044444 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contentLine = "multi_line_content_type";
	
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.044444 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_Message_Text_Align:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.044444 - 0.044444 * contextLineNumber - 0.029630 - 0.044444 - 0.042593 - 0.061111 - 0.027778) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px";
						width = 1920;
						height = (0.044444 + 0.044444 * contextLineNumber + 0.029630 + 0.044444 + 0.042593 + 0.061111 + 0.027778) * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
						width = 1280;
						height = (0.044444 + 0.044444 * contextLineNumber + 0.029630 + 0.044444 + 0.042593 + 0.061111 + 0.027778) * screenHeight;
					}
					
			        // content text
			        contentNumber = 2;
			        contentLine = "multi_line_with_single_line_content_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			        contentText2Color ={ r: 69, g: 187, b: 163, a: 230 };
			        
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.044444 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			      	
			      	contentRect2.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect2.y = (0.044444 + 0.044444 * contextLineNumber + 0.029630) * screenHeight;
			      	contentRect2.width = 0.584375 * screenWidth;
			      	contentRect2.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.029630 + 0.044444 + 0.042593) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.029630 + 0.044444 + 0.042593) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_NoButton:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.046296 - 0.044444 * contextLineNumber - 0.042593) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px"
						width = 1920;
						height = (0.046296 + 0.044444 * contextLineNumber + 0.042593) * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
						width = 1280;
						height = (0.046296 + 0.044444 * contextLineNumber + 0.042593) * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contentLine = "multi_line_content_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.046296 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
				}
				break;
			
			case MessageBoxStyle.MessageBox_1Line:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.131481) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px";
						width = 1920;
						height = 0.131481 * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
						width = 1280;
						height = 0.131481 * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contextLineNumber = 1;
			        contentLine = "single_line_content_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.043519 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
				}
				break;
				
			case MessageBoxStyle.MessageBox_1Line_Loading:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.220370) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px";
						width = 1920;
						height = 0.220370 * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
						width = 1280;
						height = 0.220370 * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contextLineNumber = 1;
			        contentLine = "single_line_content_with_loading_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.046296 + 0.033333) * screenHeight + loadingHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
					
					// loading
					bLoading = true;
					loadingX =  (screenWidth - loadingWidth)/2;
					loadingY = 0.046296 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_2Line_Loading:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.266667) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px";
						width = 1920;
						height = 0.266667 * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
						width = 1280;
						height = 0.266667 * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contextLineNumber = 2;
			        contentLine = "multi_line_content_with_loading_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.048148 + 0.031481) * screenHeight + loadingHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * 2;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
					
					// loading
					bLoading = true;
					loadingX =  (screenWidth - loadingWidth)/2;
					loadingY = 0.048148 * screenHeight;
				}
				break;	
				
			case MessageBoxStyle.MessageBox_3Line_Loading:
				{
					bTitle = false;
					// bAutoFlag = false;
					y = (1 - 0.309259) * screenHeight/2;
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						contentTextFont = "Sans 34px";
						contentText2Font = "Sans 34px";
						width = 1920;
						height = 0.309259 * screenHeight;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
						contentTextFont = "Sans 22px";
						contentText2Font = "Sans 22px";
						width = 1280;
						height = 0.309259 * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contextLineNumber = 3;
			        contentLine = "multi_line_content_with_loading_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.048148 + 0.031481) * screenHeight + loadingHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * 3;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
					
					// loading
					bLoading = true;
					loadingX =  (screenWidth - loadingWidth)/2;
					loadingY = 0.048148 * screenHeight;
				}
				break;	
				
			default:
				break;
		}
		
		// button attr
		if(true == bButton){
			if(buttonStyle = ButtonStyle.Button_Style_A){
				button_1_Text = "OK";
				button_2_Text = "Cancel";
				  
			    // background
			    buttonBgNormal = path + "btn_style_a_n.png";
				buttonBgFoucs = path + "btn_style_a_f.png";
				buttonBgSelect = path + "btn_style_a_s.png";
				buttonBgDim = path + "btn_style_a_d.png";
				
				buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
				buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
				buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				
				if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
					// text fontsize
					normalFont = "Sans 32px";
					focusFont = "Sans 36px";
					selectFont = "Sans 36px";
					dimFont = "Sans 32px";
				} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
					// text fontsize
					normalFont = "Sans 21px";
					focusFont = "Sans 24px";
					selectFont = "Sans 24px";
					dimFont = "Sans 24px";
				}
				
				// text color
				normalTextColor = { r: 64, g: 64, b: 64, a: 0 };
				focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
				selectTextColor = { r: 241, g: 171, b: 21, a: 255 };
				dimTextColor = { r: 64, g: 64, b: 64, a: 0 };	   
			}
	        
			 if(buttonStyle = ButtonStyle.Button_Style_B_Focus1){
				button_1_Text = "OK";
				button_2_Text = "Cancel";
				
			    // background
			    buttonBgNormal = path + "btn_style_a_n.png";
				buttonBgFoucs = path + "btn_style_a_f.png";
				buttonBgSelect = path + "btn_style_a_s.png";
				buttonBgDim = path + "btn_style_a_d.png";
				
				buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
				buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
				buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				
				if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
					// text fontsize
					normalFont = "Sans 32px";
					focusFont = "Sans 36px";
					selectFont = "Sans 36px";
					dimFont = "Sans 32px";
				} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
					// text fontsize
					normalFont = "Sans 21px";
					focusFont = "Sans 24px";
					selectFont = "Sans 24px";
					dimFont = "Sans 24px";
				}
				
				// text color
				normalTextColor = { r: 64, g: 64, b: 64, a: 0 };
				focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
				selectTextColor = { r: 241, g: 171, b: 21, a: 255 };
				dimTextColor = { r: 64, g: 64, b: 64, a: 0 };	   
			}
			
			 if(buttonStyle = ButtonStyle.Button_Style_B_Focus2){
				button_1_Text = "OK";
				button_2_Text = "Cancel";
				
			    // background
			    buttonBgNormal = path + "btn_style_b_n.png";
				buttonBgFoucs = path + "btn_style_b_f.png";
				buttonBgSelect = path + "btn_style_b_s.png";
				buttonBgDim = path + "btn_style_b_d.png";
				
				buttonBgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
				buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242 };
				buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				
				if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
					// text fontsize
					normalFont = "Sans 32px";
					focusFont = "Sans 36px";
					selectFont = "Sans 36px";
					dimFont = "Sans 32px";
				} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
					// text fontsize
					normalFont = "Sans 21px";
					focusFont = "Sans 24px";
					selectFont = "Sans 24px";
					dimFont = "Sans 24px";
				}
				
				// text color	
				normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
				focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
				selectTextColor = { r: 233, g: 179, b: 33, a: 255 };
				dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	   
			} 
		}
		
		// loading attr
		if(true == bLoading){
			loadingImageNumber = 63;
			loadingImagePath = loadingImagePath + "white/20x20/";
			for (var i = 1; i <= 63; ++i){
			    if (i < 10){
			        loadingImageName[i-1] = "loading_bright_20_0" + i + ".png";
			    }
			    else{
			        loadingImageName[i-1] = "loading_bright_20_" + i + ".png";
			    }	
			}
		}
	
		// background
		if(BackgroundStyle.Background_Style_B_1 == bgStyle){
			bgcolor = {r: 39, g: 124, b: 175, a: 200};
		}
		
		if(BackgroundStyle.Background_Style_B_2 == bgStyle){
			bgcolor = {r: 15, g: 24, b: 38, a: 217};
		}
		
		if(BackgroundStyle.Background_Style_B_3 == bgStyle){
			bgcolor = {r: 237, g: 237, b: 237, a: 217};
		}
	}
	
	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	// resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + buttonBgNormal);
	if(true == bAutoFlag){
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			width = 1920;
			height = 1080;
		} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			width = 1280;
			height = 720;
		}		
	}
	//create Messagebox instance 
	messagebox = new MessageBox({
		 x: x,
		 y: y,
		 parent: parent,
		 bTitle: bTitle,
		 bAutoFlag: bAutoFlag,
		 width: width,
         height: height,
         color: bgcolor,
         contentType: contentLine,
         buttonType: buttonType
	});
	
	// messagebox.color = bgcolor;
	
	if(null != id){
		messagebox.id = id;
	}
	
	// title
	if(true == bTitle){
		messagebox.setTitleText(titleText);
		if(false == bAutoFlag){
			messagebox.setTitleRect(titleRect.x, titleRect.y, titleRect.width, titleRect.height);
		}
		messagebox.setTitleTextColor(titleTextColor.r, titleTextColor.g, titleTextColor.b, titleTextColor.a);
		messagebox.setTitleTextFont(titleTextFont);
		messagebox.setTitleTextAlignment("horizontal_align_center", "vertical_align_middle");
		// title line
		messagebox.setTitleLineRect(titleLineRect.x, titleLineRect.y, titleLineRect.width, titleLineRect.height);
		messagebox.setTitleLineColor(255, 255, 255, 76);
	}
	
	
	// content text
	if(1 == contentNumber){
		messagebox.setContentTextFont(contentTextFont);
		messagebox.setContentText(contentText);
		if(false == bAutoFlag){
			messagebox.setContentRect(contentRect.x, contentRect.y, contentRect.width, contentRect.height);
		}
		
		messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
		if(1 == contextLineNumber){
			messagebox.setContentTextAlignment("horizontal_align_center", "vertical_align_top");
		}else{
			messagebox.setContentTextAlignment("horizontal_align_left", "vertical_align_top");
		}
		
		
	}
	if(2 == contentNumber){
		messagebox.setContentTextFont(contentTextFont);
		messagebox.setContentText(contentText);
		if(false == bAutoFlag){
			messagebox.setContentRect(contentRect.x, contentRect.y, contentRect.width, contentRect.height);
		}
		
		messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
		if(1 == contextLineNumber){
			messagebox.setContentTextAlignment("horizontal_align_center", "vertical_align_top");
		}else{
			messagebox.setContentTextAlignment("horizontal_align_left", "vertical_align_top");
		}
		
		messagebox.setContentText2Font(contentText2Font);
		messagebox.setContentText2(contentText2);
		if(false == bAutoFlag){
			messagebox.setContent2Rect(contentRect2.x, contentRect2.y, contentRect2.width, contentRect2.height);
		}
		messagebox.setContentText2Color(contentText2Color.r, contentText2Color.g, contentText2Color.b, contentText2Color.a);
		messagebox.setContentText2Alignment("horizontal_align_center", "vertical_align_top");
		
	}
	
	
	if(true == bButton){
		messagebox.setButtonImage("button_all", "normal", buttonBgNormal);
		messagebox.setButtonImage("button_all", "focused", buttonBgFoucs);
		messagebox.setButtonImage("button_all", "selected", buttonBgSelect);
		messagebox.setButtonImage("button_all", "disabled", buttonBgDim);
		
		messagebox.setButtonTextColor("button_all", "normal", normalTextColor.r, normalTextColor.g, normalTextColor.b, normalTextColor.a);
		messagebox.setButtonTextColor("button_all", "focused", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
		messagebox.setButtonTextColor("button_all", "selected", selectTextColor.r, selectTextColor.g, selectTextColor.b, selectTextColor.a);
		messagebox.setButtonTextColor("button_all", "disabled", dimTextColor.r, dimTextColor.g, dimTextColor.b, dimTextColor.a);
		
		messagebox.setButtonTextFontSize("button_all", "normal", normalFont);
		messagebox.setButtonTextFontSize("button_all", "focused", focusFont);
		messagebox.setButtonTextFontSize("button_all", "selected", selectFont);
		messagebox.setButtonTextFontSize("button_all", "disabled", dimFont);
		
		messagebox.setButtonText("button_1", "all", button_1_Text);
		messagebox.setButtonText("button_2", "all", button_2_Text);
		
		if(false == bAutoFlag){
			messagebox.setButtonRect("button_1", button1Rect.x, button1Rect.y, button1Rect.width, button1Rect.height);
			messagebox.setButtonRect("button_2", button2Rect.x, button2Rect.y, button2Rect.width, button2Rect.height);	
		}		
	}    
	
	// loading
	if(true == bLoading){
		messagebox.setLoadingAttr({
			x: loadingX,
			y: loadingY,
			// width: loadingWidth,
			// height: loadingHeight, 
			imageWidth: loadingWidth,
			imageHeight: loadingHeight, 
			imageNum: loadingImageNumber, 
			imageFps: 15, 
			imagePath: loadingImagePath, 
			imageName: loadingImageName
		});	
	}
	
	return messagebox;	
}

var MessageBoxStyle = {
		MessageBox_Title_Button_1Line:1,
		MessageBox_Title_Button_2_8Line:2,
		MessageBox_NoTitle_Button_1Line:3,
		MessageBox_NoTitle_Button_2_8Line:4,
		MessageBox_NoTitle_Button_Message_Text_Align:5,
		MessageBox_NoTitle_NoButton:6,
		MessageBox_1Line:7,
		MessageBox_1Line_Loading:8,
		MessageBox_2Line_Loading:9,
		MessageBox_3Line_Loading:10
	};
	
var BackgroundStyle = {
		Background_Style_B_1:1,
		Background_Style_B_2:2,
		Background_Style_B_3:3
	};
	
var ButtonStyle = {
		Button_Style_A: 1,
		Button_Style_B_Focus1: 2,
		Button_Style_B_Focus2: 3
	};
	
var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};	

winsetMessageBox.MessageBoxStyle = MessageBoxStyle;
winsetMessageBox.BackgroundStyle = BackgroundStyle;
winsetMessageBox.ButtonStyle = ButtonStyle;
winsetMessageBox.ResoultionStyle = ResoultionStyle;

exports = winsetMessageBox;
