winsetScroll = function(obj) {
	// local var
	var scroll,
		height = -1,
		width = -1,
		parent = scene,
		id = null,
		x = 0,
		y = 0,
		minValue = 0,
		maxValue = 100,
		value = 50,
		style = ScrollStyle.Scroll_Style_C,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		pointingNormalThumbImageWidth = 5,
		pointingNormalThumbImageHeight = 40,
		pointingOverThumbImageWidth = 21,
		pointingOverThumbImageHeight = 40,
		pointingFocusThumbImageWidth = 29,
		pointingFocusThumbImageHeight = 49,
		pointingNormalThumbImage,
		pointingOverThumbImage,
		pointingFocusThumbImage,
		bgFocusImage,
		bgNormalImage;
		
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (ScrollStyle.Scroll_Style_A <= objParameter.style)
				&& (ScrollStyle.Scroll_Style_C >= objParameter.style)){
				
				style = objParameter.style;		
			}

			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}			
		
		
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
			
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
			
			if(objParameter.hasOwnProperty("minValue")
				&& (typeof objParameter.minValue == "number")){
				minValue = objParameter.minValue;	
			}
			
			if(objParameter.hasOwnProperty("maxValue")
				&& (typeof objParameter.maxValue == "number")){
				maxValue = objParameter.maxValue;	
			}
			
			if(objParameter.hasOwnProperty("value")
				&& (typeof objParameter.y == "number")){
				value = objParameter.value;
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			path = path + "1080p/scroll/";
			if(0 > height){
				height = 1080;
			}
			if(0 > width){
				width = 5;
			}
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/scroll/";
			if(0 > height){
				height = 720;
			}
			if(0 > width){
				width = 4;
			}
		}

		//set default value
		switch(style)
		{
			case ScrollStyle.Scroll_Style_A:
			case ScrollStyle.Scroll_Style_B:
			case ScrollStyle.Scroll_Style_C:
				{
					// image path
					pointingNormalThumbImage = path + "chvol_scroll_nor.png";
					pointingOverThumbImage = path + "chvol_scroll_over.png";
					pointingFocusThumbImage = path + "chvol_scroll_focus.png";
					
					bgFocusImage = path + "keyscreen_scroll_pn.png";
					bgNormalImage = path + "keyscreen_scroll_po.png";
					
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						pointingNormalThumbImageWidth = 5;
						pointingNormalThumbImageHeight = 40;
						pointingOverThumbImageWidth = 21;
						pointingOverThumbImageHeight = 40;
						pointingFocusThumbImageWidth = 29;
						pointingFocusThumbImageHeight = 49;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						height = 720;
						width = 4;
						pointingNormalThumbImageWidth = 4;
						pointingNormalThumbImageHeight = 26;
						pointingOverThumbImageWidth = 14;
						pointingOverThumbImageHeight = 26;
						pointingFocusThumbImageWidth = 19;
						pointingFocusThumbImageHeight = 32;					
					}
				}
				break;
			
			default:
				break;
		}
	}

	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	//resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + pointingNormalThumbImage);
	scroll = new Scroll({
		x: x,
		y: y,
		// id: id,
		minValue: minValue,
		maxValue: maxValue,
		value: value,
		parent: parent,
		width: width,
		height: height,
		trackShadowHeight: 0,
		direction: "vertical",
		active: true,
		backgroundColor: { r: 255, g: 0, b: 0, a: 5 },
		trackShadowColor: { r: 255, g: 0, b: 0, a: 51 },
		pointingNormalThumbImageWidth: pointingNormalThumbImageWidth,
		pointingNormalThumbImageHeight: pointingNormalThumbImageHeight,
		pointingNormalThumbImage: pointingNormalThumbImage,
		pointingOverThumbImageWidth: pointingOverThumbImageWidth,
		pointingOverThumbImageHeight: pointingOverThumbImageHeight,
		pointingOverThumbImage: pointingOverThumbImage,
		pointingFocusThumbImageWidth: pointingFocusThumbImageWidth,
		pointingFocusThumbImageHeight: pointingFocusThumbImageHeight,
		pointingFocusThumbImage: pointingFocusThumbImage,
		rolloverTopTrackHeight: pointingOverThumbImageWidth,
		// backgroud
		pointingNormalBackgroundImage: bgFocusImage,
		pointingOverBackgroundImage: bgNormalImage
	});
	
	if(null != id){
		scroll.id = id;
	}
	
	return scroll;
};

var ScrollStyle = {
	Scroll_Style_A:1,
	Scroll_Style_B:2,
	Scroll_Style_C:3
};

var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};

winsetScroll.ScrollStyle = ScrollStyle;
winsetScroll.ResoultionStyle = ResoultionStyle;
exports = winsetScroll;

