winsetLoading = function(obj) {
	// local var
	var loading,
		height = 58,
		width = 301,
		imageWidth = 301,
		imageHeight = 58,
		textWidth = 0,
		textHeight = 0,
		x = 1500,
		y = 0,
		parent = scene,
		id = null,
		gap = 0,
		style = LoadingStyle.Loading_Bright_20,
		resoultion = ResoultionStyle.Resoultion_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		imageName = [],
		//text
		textFont,
		textColor;
		
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number")
				&& (LoadingStyle.Loading_Bright_20 <= objParameter.style)
				&& (LoadingStyle.Loading_Dark_14 >= objParameter.style)){
				
				style = objParameter.style;		
			}
			
			if (objParameter.hasOwnProperty("nResoultionStyle") 
				&& (typeof objParameter.nResoultionStyle == "number")
				&& (ResoultionStyle.Resoultion_720 <= objParameter.nResoultionStyle)
				&& (ResoultionStyle.Resoultion_Style_MAX > objParameter.nResoultionStyle)){
					resoultion = objParameter.nResoultionStyle;
			}		
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number")){
				x = objParameter.x;	
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number")){
				y = objParameter.y;	
			}
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number")){
				width = objParameter.width;	
			}
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number")){
				height = objParameter.height;	
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
				
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
			// height = 58;
			// width = 301;
			path = path + "1080p/Loading/";
		} else if (resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){
			path = path + "720p/Loading/";
			// height = 39;
			// width = 201;
		}

		//set default value
		switch(style)
		{
			case LoadingStyle.Loading_Bright_20:
				{
					// image path
					path = path + "white/20x20/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_bright_20_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_bright_20_" + i + ".png";
					    }	
					}

					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;		
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
			
			case LoadingStyle.Loading_Bright_17:
				{
					// image path
					path = path + "white/17x17/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_bright_17_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_bright_17_" + i + ".png";
					    }	
					}

					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;			
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			case LoadingStyle.Loading_Bright_14:
				{
					// image path
					path = path + "white/14x14/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_bright_14_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_bright_14_" + i + ".png";
					    }	
					}

					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 34;
						gap = -1920 * 0.005556;
						imageWidth = 206;
						imageHeight = 40;
						textWidth = 0.107292 * 1920;
						textHeight = 0.046296 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 22;	
						gap = -720 * 0.005556;
						imageWidth = 137;
						imageHeight = 27;
						textWidth = 0.107292 * 1280;
						textHeight = 0.046296 * 720;			
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;	
				
			case LoadingStyle.Loading_Dark_20:
				{
					// image path
					path = path + "Black/20x20/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_dark_20_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_dark_20_" + i + ".png";
					    }	
					}
	
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1920 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;	
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;				
					}
					
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
				
			case LoadingStyle.Loading_Dark_17:
				{
					// image path
					path = path + "Black/17x17/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_dark_17_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_dark_17_" + i + ".png";
					    }	
					}
	
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 40;
						gap = -1920 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.156771 * 1920;
						textHeight = 0.055556 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 26;	
						gap = -720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.156771 * 1280;
						textHeight = 0.055556 * 720;				
					}
					
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
				
				case LoadingStyle.Loading_Dark_14:
				{
					// image path
					path = path + "Black/14x14/";
					
					for (var i = 1; i <= 63; ++i)
					{
					    if (i < 10) 
					    {
					        imageName[i-1] = "loading_dark_14_0" + i + ".png";
					    }
					    else
					    {
					        imageName[i-1] = "loading_dark_14_" + i + ".png";
					    }	
					}
	
					if(resoultion == ResoultionStyle.Resoultion_1080 || resoultion == ResoultionStyle.Resoultion_1080_21_9){
						textFont = 34;
						gap = -1920 * 0.005556;
						imageWidth = 206;
						imageHeight = 40;
						textWidth = 0.107292 * 1920;
						textHeight = 0.046296 * 1080;
					} else if(resoultion == ResoultionStyle.Resoultion_720 || resoultion == ResoultionStyle.Resoultion_720_21_9){						
						textFont = 22;	
						gap = -720 * 0.005556;
						imageWidth = 137;
						imageHeight = 27;
						textWidth = 0.107292 * 1280;
						textHeight = 0.046296 * 720;			
					}
					
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
				
			default:
				break;
		}
	}

	var getResoultion = function(){
		return ResoultionStyle.Resoultion_1080;
	}
	
	// resoultion = getResoultion();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	print("path is ------------ " + path);
	loading = new Loading({
		imageNum: 63,
        x: x,
        y: y,
        parent: parent,
        imageWidth: imageWidth,
		imageHeight: imageHeight,
		textWidth: textWidth,
		textHeight: textHeight,
        gap: gap,
        imageFPS: 15,
        fontSize: textFont,
        text: "Loading...",
        imagePath: path,
        imageName: imageName,
        textColor: textColor
	});
	
	if(null != id){
		loading.id = id;	
	}
	
	return loading;
};

var LoadingStyle = {
	Loading_Bright_20:1,
	Loading_Bright_17:2,
	Loading_Bright_14:3,
	Loading_Dark_20:4,
	Loading_Dark_17:5,
	Loading_Dark_14:6
};

var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4
};

winsetLoading.LoadingStyle = LoadingStyle;
winsetLoading.ResoultionStyle = ResoultionStyle;
exports = winsetLoading;

