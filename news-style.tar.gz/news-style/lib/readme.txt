Descriptions about this directory

custom-widgets/		-- custom widgets inside

views/			-- common views inside

panel-common.js		-- Common Utilities for Panel Development

volt-backbone.js	-- Improved Backbone for Volt Panels

volt-common.js		-- Common Functions. E.g. Volt.getRemoteUrl(), Volt.hexToRgb(), Volt.rgbToHex

volt-debug.js		-- log and debug support. E.g. Volt.log()

volt-kpi.js		-- KPI support

volt-local-storage.js	-- Local Storage support

volt-multilingual.js	-- Multi-Language support

volt-nav.js		-- Volt Navigator to Handle Key Focus

volt-wrapper.js		-- A Wrapper for Browser to Run Volt app