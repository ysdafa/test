/**
 * 本文件用于测试 winset UI Element 和 Volt-Nav
 */

(function () {
    Volt.require = function (path) {
        return require('file://' + path);
    };
})();

////////////////////////////////////////////////////////////////////////////////
// Require Modules
var Require = Volt.require;
Require('lib/volt-debug.js'); // For Print and Debug
Require('lib/volt-common.js'); // Common Functions
Require('lib/volt-nav.js'); // Focus and Key Input Management
//var Backbone = Require('lib/volt-backbone.js');
var PanelCommon = Require('lib/panel-common.js');

var mainTemplate = PanelCommon.requireTemplate('main');

var Nav = Volt.Nav;

////////////////////////////////////////////////////////////////////////////////
// App Entry
var initialize = function () {
    scene.color = {
        r: 0x0f,
        g: 0x18,
        b: 0x26
    };

    var view = new MainView();
    view.render();
};

////////////////////////////////////////////////////////////////////////////////
// 定义一个template包含大部分winset UI Element

var SCREEN_WIDTH = scene.width;
var SCREEN_HEIGHT = scene.height;

var template = {
    type: 'widget',
    x: 0,
    y: 0,
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
    color: {
        a: 0
    },
    children: [
        {
            id: 'btnTest',
            type: 'Button',
            custom: {
                focusable: true
            },
            x: 1920 - 101,
            y: 0,
            width: 101,
            height: 144,
        },
        {
            id: 'ct1',
            custom: {
                focusable: true
            },
            type: 'CategoryTab',
            x: 0,
            y: 144,
            width: SCREEN_WIDTH,
            height: 72,

            color: {
                r: 242,
                g: 242,
                b: 242,
                a: 255
            },
            margin: {
                top: 0,
                bottom: 0,
                left: SCREEN_WIDTH * 0.005208,
                right: SCREEN_WIDTH * 0.005208
            },

            spliterSize: {
                w: 2,
                h: 2
            },
            enableLooping: true,
            tabFont: "Sans 28px",
            arrowSize: {
                w: SCREEN_WIDTH * 0.035938,
                h: 34
            },
            leftArrowImage: "./images/1080/arrow/comn_sub_arrow_left_n.png",
            rightArrowImage: "./images/1080/arrow/comn_sub_arrow_right_n.png",
            highlightbarColor: {
                r: 30,
                g: 158,
                b: 230,
                a: 255
            },
            spliterColor: {
                r: 70,
                g: 70,
                b: 70,
                a: 255
            },
            enableHighlightbar: true,
            highlightbarHeight: 5,
            textMargin: SCREEN_WIDTH * 0.020833,
            textLimit: 25,
            enableAlignTabsCenter: true,
        },
        {
            id: 'ct2',
            custom: {
                focusable: true
            },
            type: 'CategoryTab',
            x: 0,
            y: 288,
            width: SCREEN_WIDTH,
            height: 72,

            color: {
                r: 242,
                g: 242,
                b: 242,
                a: 255
            },
            margin: {
                top: 0,
                bottom: 0,
                left: SCREEN_WIDTH * 0.005208,
                right: SCREEN_WIDTH * 0.005208
            },

            spliterSize: {
                w: 2,
                h: 2
            },
            enableLooping: true,
            tabFont: "Sans 28px",
            arrowSize: {
                w: SCREEN_WIDTH * 0.035938,
                h: 34
            },
            leftArrowImage: "./images/1080/arrow/comn_sub_arrow_left_n.png",
            rightArrowImage: "./images/1080/arrow/comn_sub_arrow_right_n.png",
            highlightbarColor: {
                r: 30,
                g: 158,
                b: 230,
                a: 255
            },
            spliterColor: {
                r: 70,
                g: 70,
                b: 70,
                a: 255
            },
            enableHighlightbar: true,
            highlightbarHeight: 5,
            textMargin: SCREEN_WIDTH * 0.020833,
            textLimit: 50,
            enableAlignTabsCenter: false,
        }
    ]
};
////////////////////////////////////////////////////////////////////////////////
// 如何自己封装一个Button
var CustomButton = PanelCommon.BaseActor.extend({
    //type: Button,
    //onKeyEvent: 
});
////////////////////////////////////////////////////////////////////////////////
// 定义一个View

var MainView = PanelCommon.BaseView.extend({
    ct: null,

    events: {
        'NAV_FOCUS #ct1': 'onFocus',
        'NAV_FOCUS #btnTest': 'onBlur'
    },

    render: function () {
        var ct, bnt;

        var parent = PanelCommon.loadTemplate(template, null, scene);

        // Button
        this.btn = btn = parent.getChild('btnTest');
        btn.setBackgroundColor({
            state: "normal",
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 0,
            },
        });

        btn.setBackgroundColor({
            state: "focused",
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 242
            }
        });
        btn.setIconImage({
            state: 'normal',
            src: './images/1080/icon/comn_icon_tm_setting_nor.png'
        });
        btn.setIconImage({
            state: 'focused',
            src: './images/1080/icon/comn_icon_tm_setting_sel.png'
        });
        btn.setIconImage({
            state: 'roll-over',
            src: './images/1080/icon/comn_icon_tm_setting_sel.png'
        });

        btn.setIconAttr({
            x: (btn.width - 36) / 2,
            y: (btn.height - 36) / 2,
            width: 36,
            height: 36
        });

        // CT 1
        this.ct = ct = parent.getChild('ct1');
        ct.addTab("Tab 1");
        ct.addTab("Tab 2");
        ct.addTab("Tab 3333303333333330MoreThan20");
        ct.addTab("Tab 4");
        ct.addTab("Tab 5");
        ct.addTab("Tab 6");
        ct.addTab("Tab 1");
        ct.addTab("Tab 2");
        ct.addTab("Tab 3333303333333330MoreThan20");
        ct.addTab("Tab 4");
        ct.addTab("Tab 5");
        ct.addTab("Tab 6");


        // ct 2
        ct = parent.getChild('ct2');
        ct.addTab("Tab 1");
        ct.addTab("Tab 2");
        ct.addTab("Tab 3333303333333330MoreThan20");
        ct.addTab("Tab 4");
        ct.addTab("Tab 5");
        ct.addTab("Tab 6");

        this.setWidget(parent);
        Nav.setRoot(this.widget);
        Nav.focus(Nav.getItem(1));
    },


    onFocus: function (widget) {
        Volt.log(Nav.getWidgetHierarchy(widget));
        widget.animate('y', 108, 200);
        widget.animate('height', 108, 200, "cubic-out");
    },

    onBlur: function (widget) {
        Volt.log(Nav.getWidgetHierarchy(widget));
        widget.parent.getChild('ct1').animate('y', 144, 200);
        widget.parent.getChild('ct1').animate('height', 72, 200, 'cubic-out');
    },
});