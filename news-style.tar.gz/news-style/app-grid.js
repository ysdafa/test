(function(){
    //Volt.BASE_PATH = 'http://10.240.135.67:8080/'; // In case server environment
    Volt.BASE_PATH = 'file://'; // In case TV environment
    Volt.require = function(path) {
        return require(Volt.browser ? path : Volt.BASE_PATH + path);
    };
})();

/**
 * Include modules
 */
var Require = Volt.require;

Require('lib/volt-debug.js');
Require('lib/volt-common.js');
Require('lib/volt-nav.js');
Require('app/grid-router.js');


var Backbone = Require('lib/volt-backbone.js'),
    PanelCommon = Volt.require('lib/panel-common.js'),
    ModelController = Require('app/controller/model-controller.js'),


    MainTemplate = PanelCommon.requireTemplate('main');

////////////////////////
// Update Template Parser custom widget into
// KPI
Volt.KPIMapper = Volt.require('app/common/kpi-mapper.js');

//multilingual
Volt.i18n = Volt.require('lib/volt-multilingual.js');

PanelCommon.mapWidgets(['CategoryTabs', 'OptionMenu', 'ResizeableGrid', 'Button_Generic','Popup_Menu','MessagePopup','AutoScrollTextWidget']);
////////////////////////
/**
 * Entry point for Volt application
 */
var initialize = function() {
    scene.color = {r: 0, g:0, b:0};
    Volt.KPIMapper.init();
    Volt.i18n.init({
        lng : 'en',
        resGetPath: 'lang/<<lng>>.json',
        getAsync: false,
        interpolationPrefix: '<<',
        interpolationSuffix: '>>'
    }, function(t){
        // Volt.log(t('TV_SID_MIX_RECORD_A_B_C', {'A' : '9', 'B' : '11', 'C' : '3'}));
        // Volt.i18n.setLng('en', function(t){
        //     Volt.log(Volt.i18n.t('TV_SID_MIX_RECORD_A_B_C', {'A' : '9', 'B' : '11', 'C' : '3'}), 4);
        // });
    });
    // Set minCount of history, to prevent pop out all histroy
    Backbone.history.start({minCount: 1});

    Backbone.history.navigate('home', {
        trigger: true,
        focusPosition: MainTemplate.FOCUS_POSITION_CONTENT,
        focusIndex: 0
    });

    ModelController.ready();
};


/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keyCode, keyType) {
	print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [' + Volt.__line__ + '] ' + keyCode + ' ' + keyType);

    // if Volt.Nav didn't process the event, the app will process it.
    if (Volt.Nav.onKeyEvent(keyCode, keyType) === false
        && keyCode == Volt.KEY_RETURN
        && keyType == Volt.EVENT_KEY_PRESS) {

        if (Backbone.history.getCount() > 1) {
            Volt.log("Return");
            Backbone.history.back();
            return;
        } else {
            Volt.log("Exit Common Module Panel");
			Volt.exit();
		}
    }


};

