scene.color = {
    r: 0x0f,
    g: 0x18,
    b: 0x26
};

(function () {
    //Volt.BASE_PATH = 'http://10.240.135.67:8080/'; // In case server environment
    Volt.pakages = {
        instances: {},
        modules: {}
    };
    Volt.BASE_PATH = 'file://'; // In case TV environment
    if (Volt.browser) {
        Volt.require = function (path) {
            if (Volt.pakages.instances[path]) {
                return Volt.pakages.instances[path];
            } else if (Volt.pakages.modules[path]) {
                Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
                return Volt.pakages.instances[path];
            } else {
                return require(path);
            }
        };
    } else {
        Volt.require = function (path) {
            if (Volt.pakages.instances[path]) {
                return Volt.pakages.instances[path];
            } else if (Volt.pakages.modules[path]) {
                Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
                return Volt.pakages.instances[path];
            } else {
                return require(Volt.BASE_PATH + path);
            }
        };
    }
    Volt.requireWinset = function (winset) {
        return Volt.require('modules/WinsetUIElement/' + winset + '.js');
    }
})();

////////////////////////////////////////////////////////////////////////////////
var _, DeviceModel, Backbone, PanelCommon, voltapi, ModelController, GlobalMediator, DimView;

/**
 * @namespace app
 */

/**
 * Load modules for whole Panel and this app.js
 * @function
 * @memberof app
 */
function loadModules() {
    var Require = Volt.require;

    //----------------------------------
    // Step 1: Load Pre-compiled modules

    ////////////////////////////////////
    // DESC: Require this distribution file when release. Comment this during development.
    // Load pre-compiled modules
    //Require('distribution.min.js');

    //--------------------------------------
    // Step 2: Load Modules attached to Volt

    // These two files should be required first, other files depend on these files
    // Only need to be Required ONCE
    Require('lib/volt-debug.js'); // For Print and Debug
    Require('lib/volt-common.js'); // Common Functions

    _ = Require('modules/underscore.js')._;
    
    // Focus and Key Input Management
    Require('lib/volt-nav.js');

    //multilingual
    Volt.i18n = Require('lib/volt-multilingual.js');

    // KPI
    Volt.KPIMapper = Require('app/common/kpi-mapper.js');

    // Device Model
    //Volt.DeviceInfoModel = Require('app/models/device-info-model.js');
    DeviceModel = Require('app/models/device-model.js');

    // Router Map
    Require('app/router.js');

    //--------------------------------
    // Step 3: Load Modules for app.js
    Backbone = Require('lib/volt-backbone.js');
    PanelCommon = Require('lib/panel-common.js');
    voltapi = Require('modules/voltapi.js'); // Volt APIs

    ModelController = Require('app/controller/model-controller.js');

    //
    GlobalMediator = PanelCommon.GlobalMediator;

    // Global DimView
    DimView = PanelCommon.requireView('dim');
}

/**
 * Set up environment for app
 * @function
 * @memberof app
 */
function setupEnv() {
    DeviceModel.init();

    //Volt.KPIMapper.init();
    Volt.i18n.init({
        lng: DeviceModel.get('languageCode'),
        resGetPath: 'lang/<<lng>>.json',
        getAsync: false,
        interpolationPrefix: '<<',
        interpolationSuffix: '>>'
    }, function (t) {});

    //
    addVoltEventListeners();
}

/**
 * Start the app
 * @function
 * @memberof app
 */
function startApp() {

    checkUSB();
    checkNetwork();

    // Set minCount of history, to prevent popping out all histroy
    Backbone.history.start({
        minCount: 1
    });

    // Template of MainView. This is a Common Template
    var mainTemplate = PanelCommon.requireTemplate('main');

    Backbone.history.navigate('home', {
        trigger: true,
        //focusPosition: mainTemplate.FOCUS_POSITION_CATEGORY,
        //focusIndex: 0
    });

    ModelController.ready();
}

////////////////////////
/**
 * Entry point for Volt application
 * @function
 * @memberof app
 */
var initialize = function () {
    scene.color = {
        r: 0x0f,
        g: 0x18,
        b: 0x26
    };

    loadModules();
    setupEnv();
    startApp();

    ////////////////////////////////////////////////////////////////////////////
    // CHANGES: onKeyEvent should be attached to Volt.Nav
    Volt.Nav.onKeyEvent = function (keyCode, keyType) {
        Volt.log('keyCode: ' + keyCode + ', keyType: ' + keyType);

        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {

            if (Backbone.history.getCount() > 1) {
                Volt.log("Return");
                Backbone.history.back();
                return;
            } else {
                Volt.log("Exit Common Module Panel");
                Volt.exit();
            }
        }

        if (keyCode == Volt.KEY_1 && keyType == Volt.EVENT_KEY_PRESS) {
            gc();    //manually garbage collect
            VDUtil.heapSnapshot();//dump heap snapshot
        }

        if (keyCode == Volt.KEY_2 && keyType == Volt.EVENT_KEY_PRESS) {
            gc();    //manually garbage collect
            VDUtil.heapSnapshot();//dump heap snapshot
        }
        if (keyCode == Volt.KEY_3 && keyType == Volt.EVENT_KEY_PRESS) {
			Volt.log("make heap snapshot");
            gc();    //manually garbage collect
            VDUtil.heapSnapshot();//dump heap snapshot
        }		
		
    };
};

////////////////////////////////////////////////////////////////////////////////

function addVoltEventListeners() {
    Volt.addEventListener(Volt.ON_SHOW, function (data) {
        Volt.log("receive event ON_SHOW:" + JSON.stringify(data));
        GlobalMediator.trigger("EVENT_VOLT_ON_SHOW");
        /*if(data == undefined || data == null){
            print('data is null or undefined');
            return;
        }

        if(data["Sub_Menu"] == "detail"){
            IsDeepLink = true;
            DeepLinkWidgetID = data["widget_id"];
        }*/

    });

    Volt.addEventListener(Volt.ON_PAUSE, function () {
        Volt.log("receive event ON_PAUSE");
        GlobalMediator.trigger("EVENT_VOLT_ON_PAUSE");
        DimView.hide();
    });

    Volt.addEventListener(Volt.ON_RESUME, function () {
        Volt.log("receive event ON_RESUME");
        DimView.show();
        GlobalMediator.trigger("EVENT_VOLT_ON_RESUME");
    });

    Volt.addEventListener(Volt.ON_HIDE, function () {
        Volt.log("receive event ON_HIDE");
        if (voltapi.network.isOpened()) {
            voltapi.network.destroy();
        }
        GlobalMediator.trigger("EVENT_VOLT_ON_HIDE");
    });

    Volt.addEventListener(Volt.ON_UNLOAD, function () {
        Volt.log("receive event ON_UNLOAD");
        GlobalMediator.trigger("EVENT_VOLT_ON_UNLOAD");
    });

    Volt.addEventListener(Volt.ON_RESET, function () {
        Volt.log("receive event ON_RESET");
        GlobalMediator.trigger("EVENT_VOLT_ON_RESET");
    });

    Volt.addEventListener(Volt.ON_ACTIVATE, function () {
        Volt.log("receive event ON_ACTIVATE");
        GlobalMediator.trigger("EVENT_VOLT_ON_ACTIVATE");
        DimView.hide();
    });

    Volt.addEventListener(Volt.ON_DEACTIVATE, function () {
        Volt.log("receive event ON_DEACTIVATE");
        DimView.show();
        GlobalMediator.trigger("EVENT_VOLT_ON_DEACTIVATE");
    });
}


var checkNetwork = function () {
    Volt.log(" checkNetwork()");

    var stateNetwork = true;
    voltapi.network.init();

    voltapi.network.getAvailableNetworks(function (networkList) {
        networkList[0].setWatchListener({
            onconnect: function (type) {
                Volt.log(" wireless network onconnect");
                GlobalMediator.trigger("EVENT_CONNECT_NETWORK");
            },
            ondisconnect: function (type) {
                Volt.log(" wireless network ondisconnect");
                GlobalMediator.trigger("EVENT_DISCONNECT_NETWORK");
            }
        }, function () {
            Volt.log(" wireless network error");
            GlobalMediator.trigger("EVENT_NETWORK_ERROR");
            stateNetwork = false;
        });

        networkList[1].setWatchListener({
            onconnect: function (type) {
                Volt.log(" wired network onconnect");
                GlobalMediator.trigger("EVENT_CONNECT_NETWORK");
            },
            ondisconnect: function (type) {
                Volt.log(" wired network ondisconnect");
                GlobalMediator.trigger("EVENT_DISCONNECT_NETWORK");
            }
        }, function () {
            Volt.log(" wired network error");
            GlobalMediator.trigger("EVENT_NETWORK_ERROR");
            stateNetwork = false;
        });
    }, function (errorMessage) {
        Volt.log(" network error errorMessage : " + errorMessage);
        GlobalMediator.trigger("EVENT_NETWORK_ERROR_MESSAGE");
        stateNetwork = false;
    });

    return stateNetwork;
};

var checkUSB = function () {
    Volt.log("checkUSB()");

    var ret = voltapi.ContentsMgr.init(function () {
        Volt.log("connect usb");
        GlobalMediator.trigger("EVENT_CONNECT_USB");
    }, function () {
        Volt.log("disconnect usb");
        GlobalMediator.trigger("EVENT_DISCONNECT_USB");
    });
    Volt.log("ret is " + ret);
};


Volt.onLanguageChanged = function (lang) {
    //    var candidates = Volt.getWidgetByCustomProperty(scene, 'multilingual');

    Volt.log('Volt.onLanguageChanged : ' + lang);

    var candidates = Volt.multilingualWidget;

    Volt.i18n.setLng(lang, function (t) {
        DeviceModel.set('languageCode', lang);

        _.each(candidates, function (widget) {
            try {
                var multilingual = widget.custom['multilingual'];
                if (multilingual.translate) {
                    multilingual.translate(widget);
                } else {
                    if (multilingual.SID) {
                        widget.text = t(multilingual.SID);
                    }
                }

            } catch (e) {
                Volt.err('Volt.onLanguageChanged : ' + e);
            }
        });
    });
};
////////////////////////////////////////////////////////////////////////////////
// DO NOT CROSS
// DEPRECATED CODE STARTS FROM HERE
////////////////////////////////////////////////////////////////////////////////

/*
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */

//var onKeyEvent = function (keyCode, keyType) {
//    Volt.log('keyCode: ' + keyCode + ', keyType: ' + keyType);
//
//    // if Volt.Nav didn't process the event, the app will process it.
//    if (Volt.Nav.onKeyEvent(keyCode, keyType) === false && keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {
//
//        if (Backbone.history.getCount() > 1) {
//            Volt.log("Return");
//            Backbone.history.back();
//            return;
//        } else {
//            Volt.log("Exit Common Module Panel");
//            Volt.exit();
//        }
//    }
//};