/** 
 * @author Gu Wenxuan (wenxuan.gu@samsung.com)
 * @fileoverview Template for news-style detail View
 * @date 2014/07/10
 * 
 * @version 0.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

/**
 * @module TVShowDetailTemplate
 * @property {Object}  container          	- View Template about magazine-style detail view,include: thumb-area,content-area,relatedlist-area,button-area and popup-area
 * @property {Object}  ThumbArea   		- Template for thumb-area.
 * 
 * @example
 * var PanelCommon = Require('lib/panel-common.js');
 * var TVShowDetailCommonTemplate = PanelCommon.requireTemplate('tvshow-detail');
 * var DetailView = PanelCommon.BaseView.extend({
 *     // Set detail template as template of magazine-style detail View
 *     template: TVShowDetailCommonTemplate.container,
 *     render: function() {
 *         // Load detail Template
 *         this.setWidget(PanelCommon.loadTemplate(this.template,null,null,false));   //load newson detail view(include titile-area,content-area and related area)
 *     }
 * });
 * 
 * // Example to use ThumbArea
 * var ThumbView = PanelCommon.BaseView.extend({
 *     template : TVShowDetailCommonTemplate.ThumbArea,
 *     render: function() {
 *        	 // Load thumb-area template and set it as child of ThumbArea's widget.
 *                this.setWidget(PanelCommon.loadTemplate(this.template, {
 *          thumbnail : this.model.get('thumbnail')
 *        },parent));
 *
 *     }
 * })
 * 
 * @note
 * 1) No two widgets are allowed to have the same ID
   2) Mustache only supports string replacement
 */
var TVShowDetailTemplate = {
    container : {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height : 1080,
        color : Volt.hexToRgb('#0f1826'),
        children : [
            {
                type : 'widget',
                id : 'detail-thumb-area',
                x : 60, y : 60, width : 560, height : 420,
                color : Volt.hexToRgb('#ffffff'),
            },{
                type : 'widget',
                id : 'detail-content-area',
                x : 662, y : 60, width : 1050, height : 278+34*3 - 60,
                color : Volt.hexToRgb('#ffffff',0),
            },{
                type : 'widget',
                x : 662, y : 60 + (278+34*3 - 60) + 50, width : 1050, height : 90*2,
                id : 'detail-button-area',
                color : Volt.hexToRgb('#ffffff',0),
            },{
                type : 'widget',
                x : 60, y : 700, width : 1920 -60 , height : 1080 - 700,
                id : 'detail-list-area',
                color : Volt.hexToRgb('#ffffff',0),
                //custom: { 'focusable': true },
            },{
                id: 'detail-dim-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                opacity: 0,
                color: {r:0, g:0, b:0, a:255}
            },{
                id: 'detail-popup-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                color: Volt.hexToRgb('#000000',0),
            }
        ]

    },
    ThumbArea:{
        type : 'widget',
        x : 0, y : 0, width : 560, height : 420,
        color : Volt.hexToRgb('#0F2540'),
    	children: [
            {
                type : 'image',
                x: 0, y:  0, width : 560, height : 420,
                src : '{{ thumbnail }}',
            },
        ]
	},
 		
}

exports = TVShowDetailTemplate;







