/** 
 * @author Gu Wenxuan (wenxuan.gu@samsung.com)
 * @fileoverview Template for news-style detail View
 * @date 2014/07/10
 * 
 * @version 0.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

/**
 * @module NewsOnDetailTemplate
 * @property {Object}  container          	- View Template about news-style detail view,include: title-area,content-area,relatedlist-area
 * @property {Object}  TitleArea   		- Template for title-area.
 * @property {Object}  list   				- Template for relatedlist-area.
 * @property {Object}  RelatedItem   		- Template for each related list item.
 * 
 * @example
 * var PanelCommon = Require('lib/panel-common.js');
 * var  NewsOnDetailCommonTemplate = PanelCommon.requireTemplate('newson-detail');
 * var NewsDetailView = PanelCommon.BaseView.extend({
 *     // Set detail template as template of news-style detail View
 *     template: NewsOnDetailCommonTemplate.container,
 *     render: function() {
 *         // Load detail Template
 *         this.setWidget(PanelCommon.loadTemplate(this.template,null,null,false));   //load newson detail view(include titile-area,content-area and related area)
 *     }
 * });
 * 
 * // Example to use TitleArea
 * var TitleView = PanelCommon.BaseView.extend({
 *     template : NewsOnDetailCommonTemplate.TitleArea,
 *     render: function() {
 *        	 // Load titlearea template and set it as child of TitleArea's widget.
 *                 this.setWidget(PanelCommon.loadTemplate(this.template, {
 *          	 headline : this.model.get('headline'),
 *        	 timestamp : this.model.get('source')+' | '+ this.model.get('published')+' | '+ this.model.get('published')
 *  		 },null,parent));
 *
 *     }
 * })
 * 
 * // Example to use list
 * var RelatedItemView = PanelCommon.BaseView.extend({
 *     render: function() {
 *        	 PanelCommon.loadTemplate(NewsOnDetailCommonTemplate.list,null,parent);
 *     }
 * })
 *
 * // Example to use list
 *function __CreateGamesItem(index, widget, model) {
 *
 * var mustache = {
 *     imgUrl: model.get('thumbnail'),
 *     title: model.get('headline'),
 * };
 *    
 *   PanelCommon.loadTemplate(NewsOnDetailCommonTemplate.RelatedItem, mustache, widget);
 *
 *}

 * @note
 * 1) No two widgets are allowed to have the same ID
   2) Mustache only supports string replacement
 */


var NewsOnDetailTemplate = {
    LIST_ITEM_SCALE: 1.1,
    LIST_ITEM_WIDTH_SIZE: 1.15,
    LIST_ITEM_HEIGHT_SIZE: 1.15,
    LIST_ITEM_NUM: 20,
    LIST_ANI_TIME: 300,

    LIST_ITEM_ID:'cellID',
    LIST_ITEM_THUMBNAIL:'thumbnail',
    LIST_ITEM_TITLE:'title',

    container : {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height : 1080,
        //color : Volt.hexToRgb('#000000',20),
        color : Volt.hexToRgb('#0f1826'),
        children : [
            {
                type : 'widget',
                id : 'detail-title-area',
                x : 0, y : 0, width : 1920 , height : 144,
                color : Volt.hexToRgb('#f2f2f2',8),
            },
            {
                type : 'widget',
                x : 60, y : 144+63, width : 1920-60*2 - 277, height : 1080-(144+63),
                id : 'detail-content-area',
                color : Volt.hexToRgb('#f2f2f2',0),
            },
            {
                type : 'widget',
                x : 1920 - 324, y : 0, width : 277 , height : 1080,
                id : 'detail-relate-area',
                color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    },
    
    TitleArea:{        
    type : 'widget',        
		x : 60, y : 0, width : 1920-60*2 - 277, height : 144,        
		color : Volt.hexToRgb('#f2f2f2',0),    	
		children: [            
			{ 
					type : 'text',				
					id:'title-headline',                
					x : 0, y: 0, width : 1920-60*2 - 277, height : 144,                
					horizontalAlignment : 'left',                
					verticalAlignment : 'center',                
					textColor : Volt.hexToRgb('#ffffff', 90),                
					ellipsize : true,                
					text : '{{ headline }}',                
					font : '70px',                
					singleLineMode: false,            
				},

					/*{               
					type : 'image',				
					id:'title-logo',                
					x: 0, y:  0+74*2 + 5, width : 150, height : 52,                
					src : Volt.getRemoteUrl('images/1080/soccer_h_sub_logo_espn.png')            
				},{                
					type : 'text',				
					id:'title-time',                
					x : 0+150, y: 0+74*2, width : 1920 - 450 -150, height : 52,               
					horizontalAlignment : 'left',                
					verticalAlignment : 'center',                
					textColor : Volt.hexToRgb('#ffffff', 90),                
					ellipsize : true,                
					text : '{{ timestamp }}',               
					font : '44px'            
			} */       
		]	
	},


		list: {
        type: 'ResizeableGrid',
        x: 0, y: 0, width: 277 ,height: 1080,//(155 +51)*5,
        //color: {r:0xf2, g:0xf2, b:0xf2},
        rows: 20,
        itemWidth:  277,
        itemHeight: 155 +51 ,
        parent: scene,
        custom: {focusable: true,},
    },				

//	SingleList : {
//        type: 'SingleLineListControl',
//		parent:null, 
//		width: 324, 
//		height: 1080,  
//        custom: {focusable: true,},
//        scrollType: "Vertical"
//	},
    SingleList: {
        type: 'cmSinglelineList',
		width: 324,
		height: 1080,
        custom: {focusable: true},
        scrollType: "Vertical"
	},

/*		
    RelatedItem: [
        {
            type: 'image',
            x: 0, y: 0, width: 277, height: 155,
            src: '{{ imgUrl }}',
            custom: {ID:'thumbnail'}
        },
        {
            type: 'widget',
            x: 0, y: 155, width: 277, height: 51,
            color: {r:255, g:255, b:255, a:200},
            custom: {ID:'title'},
            children: [
                {
		            type: 'AutoScrollTextWidget',
                    font: 'Calibri 16px',
                    x: 20, y: 20, width: 277- 20*2, height: 30,
		            color: {r:255, g:125, b:255,a:0},
                    opacity: 60,
                    ellipsize: true,
                    text: '{{ title }}'
                },
            ],
        },
    ],
*/

    RelatedItem: [
        {
            type: 'Thumbnail',
			visibleStyles: (0x01 | 0x20),
			image:{src: '{{ imgUrl }}',
				width: 324,
				height: 196},
			information:{
				x: 0,
				y: 155,
				width: 324,
				height: 51,
				text1:{
					x:20,
					y:20,
					width:324- 20*2,
					height: 30,
					font: 'SamsungSVD_Light_Latin 16px',
					text: '***********************************************************************',
					ellipsize: true,},
				},
        },
    ],


		
}

exports = NewsOnDetailTemplate;


