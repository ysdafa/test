/** 
 * @author Gu Wenxuan (wenxuan.gu@samsung.com)
 * @fileoverview Template for news-style detail View
 * @date 2014/07/10
 * 
 * @version 0.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

/**
 * @module VerticalDetailTemplate
 * @property {Object}  container          	- View Template about vertical-style detail view,include: thumb-area,content-area,relatedlist-area,button-area and popup-area,title-area
 * @property {Object}  TitleArea   		- Template for title-area.
 * 
 * @example
 * var PanelCommon = Require('lib/panel-common.js');
 * var AppDetailCommonTemplate = PanelCommon.requireTemplate('vertical-detail');
 * var DetailView = PanelCommon.BaseView.extend({
 *     // Set detail template as template of vertical-style detail View
 *     template: AppDetailCommonTemplate.container,
 *     render: function() {
 *         // Load detail Template
 *         this.setWidget(PanelCommon.loadTemplate(this.template,null,null,false));   //load newson detail view(include titile-area,content-area and related area)
 *     }
 * });
 * 
 * // Example to use TitleArea
 * var TitleView = PanelCommon.BaseView.extend({
 *     template : TVShowDetailCommonTemplate.TitleArea,
 *     render: function() {
 *        	 // Load title-area template and set it as child of TitleArea's widget.
 *                this.setWidget(PanelCommon.loadTemplate(this.template,null,parent));
 *
 *     }
 * })
 * 
 * @note
 * 1) No two widgets are allowed to have the same ID
   2) Mustache only supports string replacement
 */

var VerticalDetailTemplate = {
    container : {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height : 1080,
        color : Volt.hexToRgb('#0f1826'),
        children : [
            {
                type : 'widget',
                id : 'detail-thumb-area',
                x : 1920 - 560 - 60, y : 80, width : 560, height : 420,
                color : Volt.hexToRgb('#ffffff',0),
            },{
                type : 'widget',
                x : 1920 - 560 - 60, y : 60 + 420 + 20 +20, width : 560, height : 90,
                id : 'detail-button-area',
                color : Volt.hexToRgb('#ffffff',0),
            },{
                type : 'widget',
                id : 'detail-content-area',
                x : 1920 - 560 - 60, y : 60 + 420 + 20 + 90 + 20 , width : 560, height : 1080 - (60 + 420 + 20 + 90 + 20 ) - 60,
                color : Volt.hexToRgb('#ffffff',0),
            },{
                type : 'widget',
                x : 60, y : 80, width : 1920 - 120 - 600  , height : 1080 - 80 ,
                id : 'detail-list-area',
                color : Volt.hexToRgb('#ffffff',0),
            },{
                type : 'widget',
                x : 60, y : 0, width : 1920 - 120 - 600  , height : 70 ,
                id : 'detail-title-area',
                color : Volt.hexToRgb('#ffffff',0),
            },{
                type : 'widget',
                x : 0, y : 0, width : 1920   , height : 1080 ,
                id : 'detail-popup-area',
                color : Volt.hexToRgb('#000000',0),
            }			
        ]

    },


	TitleArea:{
		type : 'widget',
		x : 0, y : 0, width : 1920 - 120 - 600, height : 70,
		color : Volt.hexToRgb('#0F2540',0),
		children: [
			{
			    type : 'text',
			    x: 0, y:  0, width : 1920 - 120 - 600, height : 70,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#9ed7ff'),
                ellipsize : true,
                text : 'Apps Server Category 1',
                font : '64px',
			},
		]
	},		
 		
}

exports = VerticalDetailTemplate;







