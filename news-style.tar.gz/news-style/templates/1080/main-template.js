var SCREEN_WIDTH = scene.width,
    SCREEN_HEIGHT = scene.height;

var MainTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height: 1080,
        color:{r:0, g:0, b:0},
        //color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'main-header-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#0f1826')
                //color: {r:0, g:0, b:0, a:0}
            }, {
                id: 'main-category-container',
                type: 'widget',
                x: 0, y: 144, width: 1920, height: 72,
                //color: Volt.hexToRgb('#f2f2f2')
                color: {r:0, g:0, b:0, a:0}
            }, {
                id: 'main-content-container',
                type: 'widget',
                x: 0, y: 216, width: 1920, height: 864,
                //color: Volt.hexToRgb('#ffffff'),
                color: {r:0, g:0, b:0, a:0}
            }, {
                id: 'main-dim-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                //opacity: 0,
                color: {r:0, g:0, b:0, a:0}
            }, {
                id: 'main-popup-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                color: {r:0, g:0, b:0, a:0}
            }, {
                id: 'main-popup2-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                color: {r:0, g:0, b:0, a:0}
            }
        ]
    },

    ////////////////////////////////////////////////////////////////////////////
    // <?#1 Port to Halo Category Tabs ?>
    category: {
        type: 'CategoryTab',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH,
        height: 72,

        color: {
            r: 242,
            g: 242,
            b: 242,
            a: 255
        },
        margin: {
            top: 0,
            bottom: 0,
            left: SCREEN_WIDTH * 0.005208,
            right: SCREEN_WIDTH * 0.005208
        },

        spliterSize: {
            w: 2,
            h: 2
        },
        enableLooping: true,
        tabFont: "Sans 28px",
        arrowSize: {
            w: SCREEN_WIDTH * 0.035938,
            h: 34
        },
        leftArrowImage: "images/1080/arrow/comn_sub_arrow_left_n.png",
        rightArrowImage: "images/1080/arrow/comn_sub_arrow_right_n.png",
        highlightbarColor: {
            r: 30,
            g: 158,
            b: 230,
            a: 255
        },
        spliterColor: {
            r: 70,
            g: 70,
            b: 70,
            a: 255
        },
        enableHighlightbar: true,
        highlightbarHeight: 5,
        textMargin: SCREEN_WIDTH * 0.020833,
        textLimit: 400,
        enableAlignTabsCenter: true,
        
        custom: {
            focusable: true
        },
    },
    
    // focusPosition of MainView
    FOCUS_POSITION_HEADER:     0,
    FOCUS_POSITION_CATEGORY:   1,
    FOCUS_POSITION_CONTENT:    2
};

exports = MainTemplate;

////////////////////////////////////////////////////////////////////////////////
// DO NOT CROSS
// DEPRECATED CODE STARTS FROM HERE
////////////////////////////////////////////////////////////////////////////////

//    category: {
//        type: 'cmCategoryTab',
//        x: 0, y: 0, width: 1920, height: 72,
//        color: {r: 242, g: 242, b: 242},
//        
//        expandHeight: 108,
//        lockDuration: 200,
//        
//        separatorWidth: 2,
//        separatorHeight: 2,
//        separatorColor: {r: 0x46, g: 0x46, b: 0x46},
//        arrowWidth: 18,
//        arrowHeight: 34,
//        leftArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_left_n.png'),
//        rightArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_right_n.png'),
//        
//        custom: {focusable: true}
//    },