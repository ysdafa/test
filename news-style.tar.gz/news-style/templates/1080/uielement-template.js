var UiElementTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height: 1080,
        color:{r:0, g:0, b:0},
        children: [
            {
                id: 'radio-button-container',
                type: 'widget',
                x: 70, y: 50, width: 250, height: 50,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'animated-image-container',
                type: 'widget',
                x: 350, y: 50, width: 80, height: 80,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'entry-class-container',
                type: 'widget',
                x: 460, y: 50, width: 400, height: 200,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'contextual-menu-container',
                type: 'widget',
                x: 1350, y: 370, width: 500, height: 450,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'button-generic-container',
                type: 'widget',
                x: 950, y: 50, width: 270, height: 200,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'check-box-container',
                type: 'widget',
                x: 1300, y: 50, width: 200, height: 120,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'popup-menu-container',
                type: 'widget',
                x: 1600, y: 100, width: 200, height: 60,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'list-thumbnails-container',
                type: 'widget',
                x: 0, y: 350, width: 1300, height: 230*3 + 20,
                color: Volt.hexToRgb('#0f1826')
            },{
                id: 'progress-bar-container',
                type: 'widget',
                x: 1400, y: 250, width: 300, height: 10,
                color: Volt.hexToRgb('#0f1826')
            }				
        ]
    },
    radioButton:{
        type: 'RadioButton',
	    isHorizontal:false,
	    x : 0,
		y : 0,
	    width: 250,
        height: 50,
        itemNumber: 5,
        itemSpace: 5,
        textList : ["Apple","Banana","Grape","Orange","Watermelon"],
        iconSelectedSrc : Volt.getRemoteUrl('images/1080/uielement/Radio/selected5.png'),
        iconUnselectedSrc : Volt.getRemoteUrl('images/1080/uielement/Radio/selected6.png'),
        itemHeight : 50,
        itemFocusBorder : {width:5, color:{r:255, g:0, b:0, a:100}},
        iconWidth : 50,
        iconHeight : 50,
        textFont : "Helvetica 30px",
        textWidth : 200,//set default for no text case.
        textHeight : 50,
        //Optional property
        isHorizontal : false,
        itemInnerGap : 0,
        textColor : {r:0,g:0,b:255,a:255},
        itemBGColor : {r:50,g:50,b:50,a:100},
        focusImages:'{{options}}',
        custom: {focusable: true}
    },
    animatedImageDrawing:{
        type: 'AnimatedImageDrawing',
	    x : 0,
		y : 0,
	    width: 80,
        height: 80,
        parent:'{{tempBG}}',
        //custom: {focusable: true}
    },
    entryClass:{
        type: 'EntryClass',
	    x : 0,
		y : 0,
	    width: 400,
        height: 200,
        bgUrl:'',
        parent:'{{tempBG}}',
        focusImages:'{{options}}',
        custom: {focusable: true}
    },
    contextualMenu:{
	    type: 'Contextual_Menu',
	    x : 0,
		y : 0,
		itemHeight: 80,
		itemWidth: 500,
		width: 500,
		height: 450,
		
		firstItemOffset: 50,
		itemSpace: 20,
		totalDataNumber: 20,
		topMargin: 40,
		bottomMargin: 40,
		looping: true,
		style: 0,
		color: {r: 0, g: 255, b: 255},
		upArrow: {highlightSrc:Volt.getRemoteUrl('images/1080/uielement/Arrow/popup_sublist_arrow_up_f.png'), unHighlightSrc:Volt.getRemoteUrl('images/1080/uielement/Arrow/popup_sublist_arrow_up_n.png'), 
				dimSrc:Volt.getRemoteUrl('images/1080/uielement/Arrow/popup_sublist_arrow_up_d.png'), x: 80, y: -50},
	    downArrow: {highlightSrc: Volt.getRemoteUrl('images/1080/uielement/Arrow/popup_sublist_arrow_down_f.png'), unHighlightSrc: Volt.getRemoteUrl('images/1080/uielement/Arrow/popup_sublist_arrow_down_n.png'), 
				dimSrc:Volt.getRemoteUrl('images/1080/uielement/Arrow/popup_sublist_arrow_down_d.png'), x: 80, y: 440},	
		parent:null,
        renderType:null,
		custom: {focusable: true}
    },

    ButtonGenericA:{
        type: 'Button_Generic',
	    x : 0,
		y : 0,
		width: 270,
		height: 66,
        parent:'{{tempBG}}',
        horizontalAlignment: 'right',
        verticalAlignment: 'bottom',
        cornerDimensions: {x:4, y:4},
        sideGap: 10,
        ImgSrc: {normal:Volt.getRemoteUrl('images/1080/uielement/button/popup_btn_d.png'),
                focus:Volt.getRemoteUrl('images/1080/uielement/button/popup_btn_f.png'),
                selected:Volt.getRemoteUrl('images/1080/uielement/button/popup_btn_s.png'),
                dim:Volt.getRemoteUrl('images/1080/uielement/button/popup_btn_n.png')},
        text: {normal:"Normal",focus:"Focus",selected:"Selected",dim:"Dim"},
        textFont: {normal:"Helvetica 32px",focus:"Helvetica 38px",selected:"Helvetica 32px",dim:"Helvetica 32px"},
        textColor: {normal:{r:255, g:255, b:255, a:255},
                  focus:{r:61, g:127, b:201, a:255},
                  selected:{r:249, g:173, b:10, a:255},
                  dim:{r:255, g:255, b:255, a:26}},
        textBorder: {normal:{width:5, color:{r:0, g:255, b:0, a:52}},
                   focus:{width:10, color:{r:255, g:0, b:0, a:255}},
                   selected:{width:3, color:{r:251, g:186, b:45, a:204}},
                   dim:{width:1, color:{r:0, g:0, b:255, a:26}}},
        custom: {focusable: true}
    },
   
    ButtonGenericB:{
	    type: 'Button_Generic',
	    x : 0,
		y : 100,
		width: 80,
		height: 80,
	    parent:'{{tempBG}}',
        IconSrc: {normal:Volt.getRemoteUrl('images/1080/uielement/button/icon_d.png')},
        focus:Volt.getRemoteUrl('images/1080/uielement/button/icon_f.png'),
        selected:Volt.getRemoteUrl('images/1080/uielement/button/icon_s.png'),
        dim:"",
	    custom: {focusable: true}
    },
    CheckBoxA:{
	    type: 'CheckBox',
	    x : 0,
		y : 0,
		width: 200,
		height: 50,
	    parent:'{{tempBG}}',
	    focusImages:'{{options}}',
	    color:{r:166, g:166, b:166, a:166},
	    IconBG:{x:10, y:0, width:50, height:50},
	    IconBGSrc:{normal:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_n.png'), focus:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_f.png'),dim:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_d.png"'), selected:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_s.png')},
		IconSrc:{normal:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_n.png'), focus:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_f.png'), dim:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_d.png'), selected:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_s.png')},
		TextAttr:{x:65, y:0, width:135, height:50, text:'Apple', font:"Helvetica 20px", 
		horizontalAlignment:"left", verticalAlignment:"center"},
		TextColor:{normal:{r: 150, g: 150, b: 150, a:204}, focus:{r:255, g:255, b:255, a:255},dim:{r: 255, g: 255, b: 255, a:25.5}, selected:{r: 255, g: 248, b: 38, a:255}},
		index:0,
	    custom: {focusable: true}
    },							
    CheckBoxB:{
	    type: 'CheckBox',
	    x : 0,
		y : 70,
		width: 200,
		height: 50,
	    parent:'{{tempBG}}',
	    focusImages:'{{options}}',
	    color:{r:166, g:166, b:166, a:166},
	    IconBG:{x:10, y:0, width:50, height:50},
	    IconBGSrc:{normal:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_n.png'), focus:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_f.png'),dim:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_d.png"'), selected:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_box_s.png')},
		IconSrc:{normal:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_n.png'), focus:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_f.png'), dim:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_d.png'), selected:Volt.getRemoteUrl('images/1080/uielement/CheckBox/popup_check_icon_s.png')},
		TextAttr:{x:65, y:0, width:135, height:50, text:'Banana', font:"Helvetica 20px", 
		horizontalAlignment:"left", verticalAlignment:"center"},
		TextColor:{normal:{r: 150, g: 150, b: 150, a:204}, focus:{r:255, g:255, b:255, a:255},dim:{r: 255, g: 255, b: 255, a:25.5}, selected:{r: 255, g: 248, b: 38, a:255}},
		index:1,
	    custom: {focusable: true}
    },
    PopupMenu:{
        type: 'Popup_Menu',    
	    x : 0,
		y : 0,
		width: 200,
		height: 60,
	    parent:'{{tempBG}}',
	    custom: {focusable: true}
    },
    ListThumbnails:{
        type: 'ListThumbnails',
	    x:0,
		y:0, 
		width:1300,
		height:230*3 + 20,					
		nHorizontalOffSet:40,
		nVeticalOffSet:20,
		nItemWidth:220,  
		nItemHeight:220,  
		nXItemGap:10,  
		nYItemGap:10,
		nRowNum:3,					
		nColumnNum:5,
		bSupportDragAndDrop:true,
		bSupportCycle:true,
		nLongPressIntervalTime:1000,
		bReverseFlag:false,
	    parent:'{{tempBG}}',
	    custom: {focusable: true}
    },
    ProgressBar:{
        type: 'ProgressBar',
	    x:0,
		y:0, 
		width:300,
		height:10,					
		color: {r: 255},
		foreColor: {b: 255},
		focusPointImgSrc: {focused: Volt.getRemoteUrl('images/1080/uielement/progress/gauge_bar.PNG'), unfocused: Volt.getRemoteUrl('images/1080/uielement/progress/gauge_bg.PNG')},
		style: 1,						
		parent:'{{tempBG}}',
	    custom: {focusable: true}
    },
};

exports = UiElementTemplate;
