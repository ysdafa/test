/*
 * IORequest.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "IORequest.h"

#include <iomanip>
#include <cstring>
#include <openssl/sha.h>

#include <boost/config.hpp>

using namespace volt::util;

namespace Resource
{

/******************************************************************************
 * IOResponse
 *****************************************************************************/

std::string IOResponse::LOGGER_NAME = "volt.resource.response";

IOResponse::IOResponse():
  logger_(LOGGER_NAME), is_from_cache_(false),
  uri_(), status_(400), reason_string_(), source_(SOURCE_INVALID),
  type_(), data_(), cache_key_()
{
  LOG_DEBUG(logger_, "Born");
}

IOResponse::IOResponse(const IORequest &aRequest):
  logger_(LOGGER_NAME), is_from_cache_(false),
  uri_(aRequest.uri()), status_(400), reason_string_(),
  source_(SOURCE_INVALID), type_(), data_(),
  cache_key_(aRequest.cache_key())
{
  LOG_DEBUG(logger_, "Born: " << uri_);
}

IOResponse::~IOResponse()
{
  LOG_DEBUG(logger_, "Dead: " << uri_);
}

void IOResponse::AppendData(const void *aBuffer, const size_t aSize)
{
  if (aBuffer)
  {
    data_.append(reinterpret_cast<const char *>(aBuffer), aSize);
  }
  else
  {
    data_.clear();
  }
}

void IOResponse::SetHeader(const std::string& key, const std::string& value)
{
  headers_[key] = value;
}

bool IOResponse::IsCacheable() const
{
  return false;
}

bool IOResponse::IsFromCache() const
{
  return is_from_cache_;
}

bool IOResponse::IsExpired() const
{
  return true;
}

const std::string& IOResponse::SourceToString(const Source &aSource)
{
  switch(aSource)
  {
  case SOURCE_FILE:
  {
    static std::string str = "file";
    return str;
  }
  case SOURCE_DIRECTORY:
  {
    static std::string str = "directory";
    return str;
  }
  case SOURCE_NETWORK:
  {
    static std::string str = "network";
    return str;
  }
  default:
  {
    static std::string str = "unknown";
    return str;
  }
  }
}


/******************************************************************************
 * IORequest
 *****************************************************************************/

std::string IORequest::LOGGER_NAME = "volt.resource.request";

IORequest::IORequest(const std::string &aUri):
  logger_(LOGGER_NAME), id_(0), uri_(aUri), src_(),
  async_(true), recursive_(false), on_complete_callback_(), method_(METHOD_GET),
  data_(), response_type_(RESPONSE_INVALID), response_(),
  cached_response_(), cache_key_(), no_cache_(false)
{
  LOG_DEBUG(logger_, "Born: " << uri_);
}

IORequest::~IORequest()
{
  LOG_DEBUG(logger_, "Dead(" << id_ << "): " << uri_);
}

void IORequest::SetHeaders(const ResourceRequest::HeaderList &aHeaders)
{
}

void IORequest::Finalize()
{
}

void IORequest::FinalizeResponse()
{
}

void IORequest::InitResponse()
{
  response_.reset(new IOResponse(*this));
}

bool IORequest::ValidateCachedResponseBeforeRequest()
{
  return false;
}

bool IORequest::ValidateCachedResponseAfterRequest()
{
  return false;
}

void IORequest::ResetCacheKey()
{
  unsigned char key[SHA256_DIGEST_LENGTH];
  SHA256_CTX context;
  SHA256_Init(&context);
  SHA256_Update(&context, uri().c_str(), uri().size());
  SHA256_Final(key, &context);

  std::stringstream sstream;
#ifdef BOOST_NO_CXX11_RANGE_BASED_FOR

  for (int index = 0; index < SHA256_DIGEST_LENGTH; ++index)
  {
    sstream << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(key[index]);
  }

#else

for (unsigned char byte: key)
  {
    sstream << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
  }

#endif

  cache_key_ = sstream.str();

  LOG_DEBUG(logger_, "Cache key: " << cache_key_);
}

void IORequest::Callback()
{
  on_complete_callback()(shared_from_this());
}

bool IORequest::IsValid() const
{
  return true;
}

bool IORequest::ShouldCacheResponse() const
{
  return false;
}

IORequest::Method IORequest::StringToMethod(const std::string &aMethodStr)
{
  if (strcasecmp(aMethodStr.c_str(), "GET") == 0)
  {
    return METHOD_GET;
  }

  if (strcasecmp(aMethodStr.c_str(), "PUT") == 0)
  {
    return METHOD_PUT;
  }

  if (strcasecmp(aMethodStr.c_str(), "POST") == 0)
  {
    return METHOD_POST;
  }

  if (strcasecmp(aMethodStr.c_str(), "DELETE") == 0)
  {
    return METHOD_DELETE;
  }

  return METHOD_INVALID;
}

const std::string& IORequest::ResponseTypeToString(const ResponseType &aType)
{
  switch(aType)
  {
  case RESPONSE_STRING:
  {
    static std::string str = "string";
    return str;
  }
  case RESPONSE_ARRAY_BUFFER:
  {
    static std::string str = "arraybuffer";
    return str;
  }
  case RESPONSE_DIRECTORY:
  {
    static std::string str = "directory";
    return str;
  }
  default:
  {
    static std::string str = "unknown";
    return str;
  }
  }
}

} /* namespace Resource */
