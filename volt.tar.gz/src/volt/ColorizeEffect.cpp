/*
 * ColorizeEffect.cpp
 *
 *  Created on: Aug 6, 2013
 *      Author: Jim DiNunzio
 */

#include "VoltActor.h"
#include "ColorizeEffect.h"

const char* ColorizeEffect::TINT_TRANSITION_NAME = "colorize-tint";

#define EFFECT_NAME_DEF "colorize-effect"

const char* ColorizeEffect::EFFECT_NAME = EFFECT_NAME_DEF;

#define GET_EFFECT (CLUTTER_COLORIZE_EFFECT(getEffect()))
#define CLUTTER_COLORIZE_EFFECT_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), CLUTTER_TYPE_COLORIZE_EFFECT, ClutterColorizeEffectClass))


ColorizeEffect::ColorizeEffect(const Color& tint)
{
  setEffect(clutter_colorize_effect_new(tint.toClutterColor()));
}


ColorizeEffect::~ColorizeEffect()
{
}


void
ColorizeEffect::setTint(const Color& tint)
{
  // if no animation necessary, just set value, otherwise create implicit transition.
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (getEffect()));

  if (clutter_actor_get_easing_duration(actor) == 0)
  {
    clutter_colorize_effect_set_tint(CLUTTER_COLORIZE_EFFECT(getEffect()),
                                     tint.toClutterColor());
    return;
  }

  const char *prop = "@effects." EFFECT_NAME_DEF ".tint";

  GParamSpec* spec = g_object_class_find_property(
                       G_OBJECT_CLASS(CLUTTER_COLORIZE_EFFECT_GET_CLASS(getEffect())),
                       "tint");

  ClutterColor fromTint;

  ClutterColor toTint = {tint.r, tint.g, tint.b, tint.a};

  clutter_colorize_effect_get_tint(CLUTTER_COLORIZE_EFFECT(getEffect()), &fromTint);

  volt_actor_create_transition (VOLT_ACTOR(actor),
                                prop,
                                TINT_TRANSITION_NAME,
                                spec,
                                &fromTint,
                                &toTint);
}


Color
ColorizeEffect::getTint() const
{
  ClutterColor tint;
  clutter_colorize_effect_get_tint(CLUTTER_COLORIZE_EFFECT(getEffect()), &tint);
  return Color(tint);
}


