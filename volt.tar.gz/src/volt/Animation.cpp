
#include "Animation.h"
#include "Widget.h"
#include "WidgetUtilities.h"
#include "Exception.h"
#include "logger.h"

using namespace volt::graphics;

Animation::Animation(float dur, int rep) :  duration(dur), repeat(rep), isAnimatingRoundedCorners(false)
{
}

Animation::~Animation()
{
}

void Animation::setDuration(float value)
{
  duration = value;
}

void Animation::setRepeat(float value)
{
  repeat = value;
}

void Animation::cancelAnimation(Widget* widget, const std::vector<AnimatableProperty>& propertiesToCancel)
{
  LOG_WARN(volt::util::Logger("volt"), "DEPRECATED: cancelAnimation is deprecated (Volt 1.8). Use AnimationHandle.cancel instead.");

  if (propertiesToCancel.size() > 0)
  {
    for (auto it = propertiesToCancel.begin(); it != propertiesToCancel.end(); ++it)
    {
      const char* clutterPropName = AnimationSpec::voltAnimatableToClutter(*it);
      clutter_actor_remove_transition(widget->getAnimationActor(), clutterPropName);
    }
  }
  else //if called with no properties, remove all transitions
  {
    clutter_actor_remove_all_transitions(widget->getAnimationActor());
  }
}

AnimationHandle* Animation::apply(Widget* widget, AnimationCallback callback)
{
  //Check if widget has animation for any of our properties already, and if it does cancel it.
  for (auto it = props.begin(); it != props.end(); ++it)
  {
    widget->removeAnimation(*it);
  }

  float correctedDuration = (duration == 0) ? 1 : duration;
  AnimationHandle* handle = new AnimationHandle(widget, correctedDuration, repeat, props);

  //Add callbacks
  for(auto it = onCompleteCallbacks.begin(); it != onCompleteCallbacks.end(); ++it)
  {
    handle->addCompletionCallback(*it);
  }

  handle->addCompletionCallback(callback);

  //Add key callbacks
  for(auto it = keyCallbacks.begin(); it != keyCallbacks.end(); ++it)
  {
    handle->addKeyCallback(it->first, it->second);
  }

  //Setup the transitions for each property
  for(auto outer = animations.begin(); outer != animations.end(); outer++)
  {
    AnimationSpec& spec = outer->second;
    ClutterTransition* transition = spec.getTransition(widget, isAnimatingRoundedCorners); //creates and transfers ownership
    handle->addTransition(transition, spec.property, spec.getClutterPropertyName());
  }

  return handle;
}


void Animation::addKey(AnimatableProperty property, float value, bool isByte, TweenMode tweenMode, double key, bool isRelative,
                       BezierCurve customCurve)
{
  WidgetPropertyType type = isByte ? WByte : Scaler;
  addKeyFinal(property,  GValueConversion::getGValue( type , value ), type, tweenMode, key, isRelative, customCurve);
}

void Animation::addKey(AnimatableProperty property, Vector2 value, TweenMode tweenMode, double key , bool isRelative, BezierCurve customCurve)
{
  addKeyFinal(property,  GValueConversion::getGValue(value), Vector2D, tweenMode, key, isRelative, customCurve);
}

void Animation::addKey(AnimatableProperty property, Vector3 value, TweenMode tweenMode, double key, bool isRelative, BezierCurve customCurve)
{
  addKeyFinal(property,  GValueConversion::getGValue(value), Vector3D, tweenMode, key, isRelative, customCurve);
}

void Animation::addKey(AnimatableProperty property, Color value, TweenMode tweenMode, double key, bool isRelative, BezierCurve customCurve )
{
  addKeyFinal(property,  GValueConversion::getGValue(value), ColorValue, tweenMode, key, isRelative, customCurve);
}


void Animation::addKeyFinal(AnimatableProperty property, GValue value, WidgetPropertyType type, TweenMode tweenMode, double key, bool isRelative,
                            BezierCurve curve)
{
  props.insert(property);

  if (animations.count(property) == 0)
  {
    animations[property] = AnimationSpec(property, type);

    if (property == RoundedCornersRadius || property == RoundedCornersArcStep || property == RoundedCorners)
    {
      isAnimatingRoundedCorners = true; //if we are rounding the corners, we need to know to apply color animations correctly due to hack in rounded corners
      //implementation
    }

    if (tweenMode == CUBIC_BEZIER) //bezier curves can only be used if there are no keys
    {
      animations[property].customTweeningCurve = curve;
    }

    //if this is the first key and its value is 1, then useKeys can stay false. Otherwise keyframes are needed
    if (key != 1)
    {
      animations[property].useKeys = true;
    }
  }
  else
  {
    animations[property].useKeys = true;
  }

  animations[property].addKey(key, tweenMode, value, isRelative);
}


void Animation::addCompletionCallback(AnimationCallback callback)
{
  onCompleteCallbacks.push_back(callback);
}

void Animation::addKeyCallback(double key, AnimationCallback callback)
{
  keyCallbacks.push_back(std::make_pair(key, callback));
}

