#include "VoltProcessRuntime.h"

#include <sys/time.h>

#include "AppConfig.h"

VoltProcessRuntime::VoltProcessRuntime():
  event_handlers_()
{
}

VoltProcessRuntime::~VoltProcessRuntime()
{
}

void VoltProcessRuntime::GetScreenDimensions(int &aWidth, int &aHeight,
    int &aWindowWidth, int &aWindowHeight,
    float &aScaleX, float &aScaleY)
{
  aWidth = AppConfig::Instance().GetValue<int>("scene-width");
  aHeight = AppConfig::Instance().GetValue<int>("scene-height");
  int screenWidth = AppConfig::Instance().GetValue<int>("screen-width");
  int screenHeight = AppConfig::Instance().GetValue<int>("screen-height");

  /* Guard against 0 or negatives */
  aWidth = aWidth < 1 ? 1 : aWidth;
  aHeight = aHeight < 1 ? 1 : aHeight;

  screenWidth = screenWidth < 1 ? aWidth : screenWidth;
  screenHeight = screenHeight < 1 ? aHeight : screenHeight;

  /* Calculate the scale factor and new aWidth/aHeight given the screen size. */
  aScaleX = (float) screenWidth / (float) aWidth;
  aScaleY = (float) screenHeight / (float) aHeight;
  aWindowWidth = screenWidth;
  aWindowHeight = screenHeight;
}

void VoltProcessRuntime::ChangeScreenResolution(const int aWidth, const int aHeight)
{
#if defined(BUILD_FOR_TV) && defined(BUILD_EMP)
  char wbuf[32];
  char hbuf[32];
  snprintf(wbuf, sizeof(wbuf), "%d", aWidth);
  snprintf(hbuf, sizeof(hbuf), "%d", aHeight);

  SimpleSefClient client;
  client.Open("Screen", "1.0", "Screen");
  std::string result = client.Execute("SetScreenResolution", "1", wbuf, hbuf, "");
#endif
}

void VoltProcessRuntime::GetTimeOfDay(struct timeval &aResult)
{
  gettimeofday(&aResult, 0);
  aResult.tv_sec += GetTimeOffset(); /* add offset */
}

time_t VoltProcessRuntime::GetTimeOffset()
{
#if defined(BUILD_FOR_TV) && defined(BUILD_EMP)
  static time_t offset = 0;

  if (offset == 0)
  {
    /* Get the time offset! */
    /* TODO: Error handling!! */
    SimpleSefClient client;
    bool result = client.Open("NRDP", "1.000", "NRDP");

    if (result)
    {
      std::string drm_time = client.Execute("getDrmTime", "", "", "", "");
      drm_time.erase(0, 1); /* First char is a type classifier. */
      char *end_ptr = NULL;
      offset = (time_t) strtoll(drm_time.c_str(), &end_ptr, 10);
      client.Close();
    }
  }

  return offset;
#else
  return 0;
#endif
}

void VoltProcessRuntime::RegisterEventHandlers(const VoltEngine::EventHandlers &Handlers)
{
  event_handlers_ = Handlers;
}

bool VoltProcessRuntime::Initialize(int aArgc, char **aArgv,
                                    const VoltEngine::ExternalData &aData)
{
  RegisterEventHandlers(aData.eventHandlers);

  return true;
}
