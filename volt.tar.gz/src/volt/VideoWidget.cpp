/*
* VideoWidget.cpp
*
*  Created on: June 10, 2014
*      Author: jim.dinunzio
*/

#include "VideoWidget.h"
#include "SefClient.h"
#include "VoltFullProcessRuntime.h"
#include "SceneRoot.h"

namespace volt
{
namespace graphics
{
volt::util::Logger VideoWidget::LOGGER = volt::util::Logger("volt.videoWidget");

void VideoWidget::on_allocation_changed (ClutterActor           *actor,
    const ClutterActorBox  *allocation,
    ClutterAllocationFlags  flags,
    gpointer                user_data)
{
  VideoWidget* vw = static_cast<VideoWidget*>(user_data);

  if (vw)
  {
    vw->needUpdateSefPlayer = true;
  }
}

void VideoWidget::on_transform_changed (GObject* object,
                                        GParamSpec* paramSpec,
                                        gpointer user_data)
{
  VideoWidget* vw = static_cast<VideoWidget*>(user_data);

  if (vw)
  {
    vw->needUpdateSefPlayer = true;
  }
}

VideoWidget::VideoWidget(float xIn, float yIn, float widthIn, float heightIn, Widget* aParent,
                         SefClient* playerSefIn) : Widget(xIn, yIn, widthIn, heightIn, aParent),
  repaint_func_id(0), needUpdateSefPlayer(true), playerSef(playerSefIn)
{
  g_signal_connect (actor, "allocation-changed",
                    G_CALLBACK (on_allocation_changed),
                    this);

  g_signal_connect (actor, "notify::scale-x",
                    G_CALLBACK (on_transform_changed),
                    this);

  g_signal_connect (actor, "notify::scale-y",
                    G_CALLBACK (on_transform_changed),
                    this);

  g_signal_connect (actor, "notify::pivot-point",
                    G_CALLBACK (on_transform_changed),
                    this);

  // these two cover VoltActor origin and anchor
  g_signal_connect (actor, "notify::translation-x",
                    G_CALLBACK (on_transform_changed),
                    this);

  g_signal_connect (actor, "notify::translation-y",
                    G_CALLBACK (on_transform_changed),
                    this);

  repaint_func_id = clutter_threads_add_repaint_func_full(
                      static_cast<ClutterRepaintFlags>(CLUTTER_REPAINT_FLAGS_QUEUE_REDRAW_ON_ADD |
                          CLUTTER_REPAINT_FLAGS_POST_PAINT),
                      reinterpret_cast<GSourceFunc>(UpdateSefPlayer),
                      this, NULL);
}

VideoWidget::~VideoWidget()
{
  if (repaint_func_id)
  {
    clutter_threads_remove_repaint_func(repaint_func_id);
    repaint_func_id = 0;
  }
}

gboolean VideoWidget::UpdateSefPlayer(VideoWidget* vw)
{
  if (vw && vw->needUpdateSefPlayer)
  {
    vw->needUpdateSefPlayer = false;
    gfloat width, height, x, y;
    clutter_actor_get_transformed_size (vw->actor, &width, &height);
    clutter_actor_get_transformed_position(vw->actor, &x, &y);

    vw->SetDisplayArea(x, y, width, height);
  }

  return TRUE;
}

void VideoWidget::setPlayerSef(SefClient* playerSefIn)
{
  playerSef = playerSefIn;
}


SefClient* VideoWidget::getPlayerSef() const
{
  return playerSef;
}

void VideoWidget::onExecutedCB(std::string result)
{
  LOG_DEBUG(LOGGER, "onExecutedCB completed with result: " << result);
}

void VideoWidget::SetDisplayArea(float x, float y, float width, float height)
{
  // SetDisplayArea() takes coordinates in 960x540 space.
  if (playerSef != nullptr)
  {
    VoltFullProcessRuntime *runtime =
      static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
    SceneRoot* root = runtime->GetSceneRoot();
    float widthScale = 960 / root->getWidth();
    float heightScale = 540 / root->getHeight();

    std::vector<std::string> args;
    const int MAX_SIZE = 32;
    char numStr[MAX_SIZE];
    snprintf(numStr, MAX_SIZE, "%d", static_cast<int>((x + 0.5) * widthScale));
    args.push_back(numStr);
    snprintf(numStr, MAX_SIZE, "%d", static_cast<int>((y + 0.5) * heightScale));
    args.push_back(numStr);
    snprintf(numStr, MAX_SIZE, "%d", static_cast<int>((width + 0.5) * widthScale));
    args.push_back(numStr);
    snprintf(numStr, MAX_SIZE, "%d", static_cast<int>((height + 0.5) * heightScale));
    args.push_back(numStr);

    playerSef->ExecuteAsync("SetDisplayArea", args, onExecutedCB);
  }
}

const std::string& VideoWidget::getWidgetTypeString() const
{
  static const std::string type("VideoWidget");
  return type;
}

};
};
