#include <logger.h>
#include "EmpVolt.h"
#include "EmpEngineVolt.h"
#include "Version.h"

namespace sef
{

EmpVolt::EmpVolt()
{
  m_strName = EMP_VOLT_NAME;
  m_strOption = EMP_OPTION_NOT_SINGLETON;
  m_strVersion = VOLT_VERSION;
}

EmpVolt::~EmpVolt()
{
}

CEmpEngineBase* EmpVolt::CreateEmpEngine()
{
  return new EmpEngineVolt();
}

bool EmpVolt::CheckVersion(const std::string aVersion)
{
//  printf("[Volt|Engine] Check version string: %s\n", aVersion.c_str());
  return true;
}

} /* namespace sef */
