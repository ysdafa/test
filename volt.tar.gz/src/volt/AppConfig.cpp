#include "AppConfig.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <fontconfig/fontconfig.h>

#include "logger.h"
#include "ResourceLoader.h"
#include "DirIORequest.h"
#include "FileIORequest.h"

using namespace boost::program_options;

static volt::util::Logger LOGGER("volt.config");

AppConfig& AppConfig::Instance()
{
  static AppConfig singleton;
  return singleton;
}

AppConfig::AppConfig():
  help_desc_(), cmd_option_desc_(), file_option_desc_(),
  cmd_options_(), conf_options_(), json_options_(), xml_options_(),
  volt_root_path_("invalid path"), volt_config_path_("invalid path"),
  volt_data_path_("invalid path"), app_root_path_("invalid path"),
  app_data_path_("invalid path"), relative_app_js_("invalid path"),
  prog_name_(), orig_argv_()
{
  options_description help_options("");
  help_options.add_options()
  ("help,h", "Print help messages");

  /* Paths related configs. */
  options_description path_options("");
  path_options.add_options()
  ("root",
   value<std::string>()->default_value("."),
   "Root path where the built-in resources are searched.")
  ("app-root",
   value<std::vector<std::string>>()->default_value(std::vector<std::string>( {""}), ""),
   "Root path for the running app.")
  ("data-path",
   value<std::string>()->default_value(""),
   "Path where the Volt data is read/written.");

  /* Generic options */
  options_description generic_options("");
  generic_options.add_options()
  ("log-level",
   value<std::string>()->default_value(""),
   "Log level (overrides the level set by the config file)")
  ("scene-width",
   value<int>()->default_value(1920),
   "Root scene width")
  ("scene-height",
   value<int>()->default_value(1080),
   "Root scene height")
  ("screen-width",
   value<int>()->default_value(-1),
   "Width of screen. Scene will be scaled to fit screen.")
  ("screen-height",
   value<int>()->default_value(-1),
   "Height of screen. Scene will be scaled to fit screen.")
  ("use-perspective",
   value<bool>()->default_value(true),
   "If true(default): Distant widgets, or rotated parts of widgets, will appear smaller.")
  ("app-name",
   value<std::string>()->default_value(""),
   "Name of the application to run")
  ("app-icon",
   value<std::string>()->default_value(""),
   "Path to the application icon image file")
  ("app-id",
   value<std::string>()->default_value(""),
   "Tizen Application id")
  ("default-app-js",
   value<std::string>()->default_value("app.js"),
   "Default name of the main application JS")
  ("target-fps",
   value<int>()->default_value(0),
   "Target FPS")
  ("show-splash",
   value<std::string>()->default_value("false"),
   "Show splash screen")
  ("enable-device-profile",
   value<std::string>()->default_value("false"),
   "Enable device specific profile/config")
  ("device-type",
   value<std::string>()->default_value(""),
   "Set the device type (disable device type detection)")
  ("device-code",
   value<std::string>()->default_value(""),
   "Set the device code (disable device code detection)")
  ("default-font",
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
   value<std::string>()->default_value("Smr00"),
#else
   value<std::string>()->default_value("TizenSans"),
#endif
   "Set the font to use for texts")
  ("text-direction",
   value<std::string>()->default_value(""),
   "Set the direction of text. Valid values are \"rtl\" and \"ltr\"")
  ("enable-gc",
   value<std::string>()->default_value("false"),
   "Allow garbage collector to be manually invoked")
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
  ("show-fps",
   value<std::string>()->default_value("false"),
   "Show animation FPS")
#endif
  ("msaa-samples",
   value<int>()->default_value(0),
   "MSAA samples per pixel")
  ("sync-img-load", "Use synchronous image loading by default")
  ("run-test", "Run unit tests")
  ("font-aa",
   value<int>()->default_value(-1),
   "Font Anti-aliasing");

  /* Multi Process options */
  options_description multi_proc_options("Multi Process Options");
  multi_proc_options.add_options()
  ("worker",
   value<std::vector<std::string>>()->default_value(std::vector<std::string>( {""}), ""),
   "Run as a worker process and attach to the given shared mem.")
  ("worker-id",
   value<std::vector<std::string>>()->default_value(std::vector<std::string>( {""}), ""),
   "ID of this worker process (required if --worker is set).")
  ("worker-scene",
   value<std::vector<uintptr_t>>()->default_value(std::vector<uintptr_t>( {0}), "0"),
   "ID of this worker scene (required if --worker is set).")
  ("parent-id",
   value<std::vector<std::string>>()->default_value(std::vector<std::string>( {""}), ""),
   "ID of the parent process (required if --worker is set).")
  /* These 2 are mostly used for debugging */
  ("gfx",
   value<std::string>()->default_value(""),
   "Run as a GFX process and attach to the given shared mem.")
  ("headless",
   "Run in headless mode (no GFX process)");

  options_description ipc_options("Multi Process IPC Options");
  ipc_options.add_options()
  ("shm-size",
   value<unsigned int>()->default_value(1000000),
   "Total size of the shared memory to allocate.")
  ("shm-queue-size",
   value<unsigned int>()->default_value(2000),
   "Size of the message queue used for IPC.");

  /* Debugging options */
  options_description debug_options("Debugger Options");
  debug_options.add_options()
  ("debugger.enable",
   value<std::string>()->default_value("false"),
   "Enable debugging agent")
  ("debugger.port",
   value<unsigned int>()->default_value(9222),
   "Port to bind to");

  /* Profiling options */
  options_description prof_options("Profiling Options");
  prof_options.add_options()
  ("profiler.enable",
   value<std::string>()->default_value("false"),
   "Enable profiler")
  ("profiler.out",
   value<std::string>()->default_value("volt.prof"),
   "Enable profiler")
  ("profiler.timer-events",
   value<std::string>()->default_value("false"),
   "Enable timer events profiler");

  /* V8 options */
  options_description v8_options("V8 Options");
  v8_options.add_options()
  ("v8.gc.threshold",
   value<unsigned int>()->default_value(240000000),
   "Threshold in bytes to notify V8 of low memory to trigger garbage collection")
  ("v8.gc.threshold-poll-interval",
   value<unsigned int>()->default_value(5),
   "Interval (in sec) to check for V8 heap memory usage")
  ("v8.gc.debug",
   value<std::string>()->default_value("false"),
   "Enable v8's gc related debug messages");

  /* Backend options */
  options_description backend_options("Backend Options");
  backend_options.add_options()
  ("nw.verbose", "Make network request backend verbose")
  ("clutter.stage_clear",
   value<std::string>()->default_value("true"),
   "Toggle clearing of the main stage")
  ("clutter.debug",
   value<std::string>()->default_value(""),
   "Debug options for Clutter (same as CLUTTER_DEBUG)")
  ("clutter.paint",
   value<std::string>()->default_value(""),
   "Debug options for Clutter painting logic (same as CLUTTER_PAINT)")
  ("cogl.debug",
   value<std::string>()->default_value(""),
   "Debug options for COGL (same as COGL_DEBUG)");

  /* For command line args */
  options_description pos_options("Positional Options");
  pos_options.add_options()
  ("app-js",
   value<std::vector<std::string>>(),
   "The application JS to run");

  pos_options.add_options()
  ("firstscreen",
   value<std::string>()->default_value(""),
   "is firstscreen");

  /* command line options include everything */
  cmd_option_desc_.add(help_options)
  .add(path_options)
  .add(generic_options)
  .add(multi_proc_options)
  .add(ipc_options)
  .add(debug_options)
  .add(prof_options)
  .add(v8_options)
  .add(backend_options)
  .add(pos_options);

  /* config file options (can't set the paths and multi-proc options) */
  file_option_desc_.add(generic_options)
  .add(ipc_options)
  .add(debug_options)
  .add(prof_options)
  .add(v8_options)
  .add(backend_options);

  /* For displaying help/usage (ie without the hidden options) */
  help_desc_.add(help_options)
  .add(path_options)
  .add(generic_options)
  .add(multi_proc_options)
  .add(ipc_options)
  .add(debug_options)
  .add(prof_options)
  .add(v8_options)
  .add(backend_options);
}

AppConfig::~AppConfig()
{
}

const std::string& AppConfig::GetProgramName() const
{
  return prog_name_;
}

void AppConfig::SetProgramName(const char *aName)
{
  prog_name_ = aName;
}

void AppConfig::PrintUsage() const
{
  help_desc_.print(std::cout);
}

bool AppConfig::ParseCommandLineArgs(const int aArgc, char *aArgv[])
{
  /* Add the positional arg. */
  positional_options_description pos_options;
  pos_options.add("app-js", -1);

  cmd_options_.clear();

  SaveArgv(aArgc, aArgv);

  /* Parse options with support for unregistered args. */
  store(command_line_parser(aArgc, aArgv).options(cmd_option_desc_)
        .positional(pos_options)
        .allow_unregistered()
        .run(),
        cmd_options_);

  notify(cmd_options_);

  /* Paths can be set only on the command line.
   * Let's update Volt paths now. */
  UpdateVoltPaths();

  /* Configure logger as soon as we have enough info to initialize. */
  std::string log_config = GetVoltConfigPath() + "/log4cplus.conf";
  volt::util::Logger::Configure(log_config.c_str());

  std::string log_level = GetValue<std::string>("log-level");

  if (log_level.empty() == false)
  {
    volt::util::Logger::LogLevel level =
      volt::util::Logger::StringToLevel(log_level.c_str());
    volt::util::Logger::SetLogLevel(level);
  }

  LOG_DEBUG(LOGGER, "Volt root path: " << volt_root_path_);
  LOG_DEBUG(LOGGER, "Volt config path: " << volt_config_path_);
  LOG_DEBUG(LOGGER, "Volt data path: " << volt_data_path_);
  LOG_DEBUG(LOGGER, "Volt app root path: " << app_root_path_);
  LOG_DEBUG(LOGGER, "Volt app data path: " << app_data_path_);
  LOG_DEBUG(LOGGER, "Relative app.js: " << relative_app_js_);

  return true;
}

bool AppConfig::ParseVoltConf(const std::string aPath)
{
  conf_options_.clear();

  try
  {
    LOG_INFO(LOGGER, "Parsing config file: " <<  aPath);
    store(parse_config_file<char>(aPath.c_str(), file_option_desc_, true),
          conf_options_);
  }
  catch (boost::program_options::reading_file &e)
  {
    /* Error reading config (or config file does not exist). */
    LOG_WARN(LOGGER, "Failed to parse config file: " <<  aPath);
    return false;
  }

  notify(conf_options_);

  return true;
}

bool AppConfig::ParseConfigXml(const std::string aPath)
{
  LOG_DEBUG(LOGGER, "Parsing " << aPath);

  std::string xml_data;

  if (ResourceLoader::Instance().LoadString(aPath, xml_data) == false)
  {
    LOG_WARN(LOGGER, "Failed to read " << aPath);
    return false;
  }

  try
  {
    xmlpp::DomParser parser;
    parser.parse_memory(xml_data);

    const xmlpp::Document *doc = parser.get_document();

    if (doc == NULL)
    {
      LOG_WARN(LOGGER, "Failed to find xml document in " << aPath);
      return false;
    }

    const xmlpp::Node *root = doc->get_root_node();

    if (root == NULL)
    {
      LOG_WARN(LOGGER, "Failed to find the root node in " << aPath);
      return false;
    }

    /* Let's just take the first <volt> element. */
    xmlpp::NodeSet volt_nodes = root->find("/widget/volt[1]");

    if (volt_nodes.size() > 0)
    {
      const xmlpp::Node *volt_node = volt_nodes[0];
      LOG_INFO(LOGGER, "Found volt config in " << aPath);

      /* Convert XML options to command line equivalents */
      std::vector<std::string> cmd_args;
      Xml2CommandLineArgs(volt_node->get_children(), cmd_args);

      xml_options_.clear();

      store(command_line_parser(cmd_args).options(file_option_desc_)
            .allow_unregistered()
            .run(),
            xml_options_);

      notify(xml_options_);
    }
    else
    {
      LOG_INFO(LOGGER, "No volt config found in " << aPath);
    }

    return true;
  }
  catch (const std::exception &e)
  {
    LOG_WARN(LOGGER, "Failed to parse " << aPath << ": " << e.what());
    return false;
  }
}

bool AppConfig::ParseConfigJson(const std::string aPath)
{
  LOG_DEBUG(LOGGER, "Parsing " << aPath);

  std::string json_data;

  if (ResourceLoader::Instance().LoadString(aPath, json_data) == false)
  {
    LOG_WARN(LOGGER, "Failed to read " << aPath);
    return false;
  }

  Json::Value root;
  Json::Reader reader;

  if (reader.parse(json_data, root) == false)
  {
    LOG_WARN(LOGGER, "Failed to parse " << aPath);
    return false;
  }

  if (root.isObject() == false)
  {
    LOG_DEBUG(LOGGER, "The root is not an object: " << aPath);
    return false;
  }

  /* Convert JSON options to command line equivalents */
  std::vector<std::string> cmd_args;
  Json2CommandLineArgs(root, cmd_args);

  for (auto iter = cmd_args.begin(); iter != cmd_args.end(); ++iter)
  {
    LOG_DEBUG(LOGGER, *iter);
  }

  json_options_.clear();

  store(command_line_parser(cmd_args).options(file_option_desc_)
        .allow_unregistered()
        .run(),
        json_options_);

  notify(json_options_);

  return true;
}

void AppConfig::Clear()
{
  cmd_options_.clear();
  conf_options_.clear();
  json_options_.clear();
  xml_options_.clear();
}

bool AppConfig::IsSet(const std::string aKey) const
{
  return cmd_options_.count(aKey) || conf_options_.count(aKey) ||
         json_options_.count(aKey) || xml_options_.count(aKey);
}

const std::string& AppConfig::GetVoltRootPath() const
{
  return volt_root_path_;
}

const std::string& AppConfig::GetVoltConfigPath() const
{
  return volt_config_path_;
}

const std::string& AppConfig::GetVoltDataPath() const
{
  return volt_data_path_;
}

const std::string& AppConfig::GetAppRootPath() const
{
	return app_root_path_;
}

const std::string& AppConfig::GetAppDataPath() const
{
  return app_data_path_;
}

const std::string& AppConfig::GetRelativeAppJsPath() const
{
	return relative_app_js_;
}

void AppConfig::UpdateAppRootPath(const std::string aRoot)
{
  char real_path_buf[PATH_MAX];
  char *real_path = realpath(aRoot.c_str(), real_path_buf);

  if (real_path)
  {
    app_root_path_ = real_path;
    LOG_DEBUG(LOGGER, "App root path: " << app_root_path_);

    app_data_path_ = volt_data_path_ + "/app";
    Resource::DirIORequest::Create(app_data_path_);
    LOG_DEBUG(LOGGER, "App data path: " << app_data_path_);

    /* Set local font directory so that the Volt apps can use custom fonts */

    /* Clear font of the previous app. */
    FcConfigAppFontClear(NULL);

    std::string font_dir_str = app_root_path_ + "/fonts";
    const FcChar8 *font_dir =
      reinterpret_cast<const FcChar8 *>(font_dir_str.c_str());

    if (FcConfigAppFontAddDir(NULL, font_dir) == FcFalse)
    {
      LOG_WARN(LOGGER, "Failed to add font dir: " << font_dir);
    }

#if 0
    /* List available fonts for debugging... */
    {
      PangoFontMap *fontmap = pango_cairo_font_map_get_default();
      PangoFontFamily **families = NULL;
      int num_families = 0;
      pango_font_map_list_families(fontmap, &families, &num_families);

      LOG_DEBUG(LOGGER, "# available font family: " << num_families);

      for (int index = 0; index < num_families; ++index)
      {
        PangoFontFamily *family = families[index];
        const char *family_name = pango_font_family_get_name(family);
        LOG_DEBUG(LOGGER, "  " << index << ": " << family_name);
      }

      g_free (families);
    }
#endif
  }
  else
  {
    LOG_ERROR(LOGGER, "Failed to get the real app root path: " << aRoot);
  }
}

const std::vector<char *>& AppConfig::OriginalArgs()
{
  return orig_argv_;
}

void AppConfig::PrintValues() const
{
  auto options = cmd_option_desc_.options();
  const variables_map *source = NULL;
  std::string source_str;
  bool found = false;

  for (auto iter = options.begin(); iter != options.end(); ++iter)
  {
    variable_value value = GetVariableValue((*iter)->long_name(),
                                            &found, &source);
    source_str = source == &cmd_options_? " (src cmd)" :
                 (source == &conf_options_ ? " (src text)" :
                  (source == &json_options_ ? " (src json)" :
                   (source == &xml_options_ ? " (src xml)" : "")));

    try
    {
      LOG_INFO(LOGGER, (*iter)->long_name() << source_str <<
               (IsSet((*iter)->long_name()) ? " (set)" : " (not set)") <<
               (value.defaulted() ? " (default)" : "") <<
               (value.empty() ? " (empty)" : "") <<
               " = " << value.as<std::string>());
    }
    catch (boost::bad_any_cast)
    {
      try
      {
        LOG_INFO(LOGGER, (*iter)->long_name() << source_str <<
                 (IsSet((*iter)->long_name()) ? " (set)" : " (not set)") <<
                 (value.defaulted() ? " (default)" : "") <<
                 (value.empty() ? " (empty)" : "") <<
                 " = " << value.as<int>());
      }
      catch (boost::bad_any_cast)
      {
        try
        {
          LOG_INFO(LOGGER, (*iter)->long_name() << source_str <<
                   (IsSet((*iter)->long_name()) ? " (set)" : " (not set)") <<
                   (value.defaulted() ? " (default)" : "") <<
                   (value.empty() ? " (empty)" : "") <<
                   " = " << value.as<unsigned int>());
        }
        catch (boost::bad_any_cast)
        {
          LOG_INFO(LOGGER, (*iter)->long_name() << source_str <<
                   (IsSet((*iter)->long_name()) ? " (set)" : " (not set)") <<
                   (value.defaulted() ? " (default)" : "") <<
                   (value.empty() ? " (empty)" : ""));
        }
      }
    }
  }
}

variable_value AppConfig::GetVariableValue(const std::string aKey,
    bool *aFound,
    const variables_map **aSource) const
{
  /*
   * Look for options from different sources in the following order.
   *   1. Command line arguments.
   *   2. XML configuration file.
   *   3. Text configuration file (ie volt.conf).
   *   4. Default value (if any).
   *   5. Not found.
   */

  if (aFound)
  {
    *aFound = true;
  }

  if (aSource)
  {
    *aSource = NULL;
  }

  if (cmd_options_.count(aKey) && cmd_options_[aKey].defaulted() == false)
  {
    /* set via a command line arg */
    if (aSource)
    {
      *aSource = &cmd_options_;
    }

    return cmd_options_[aKey];
  }
  else if (json_options_.count(aKey) && json_options_[aKey].defaulted() == false)
  {
    /* set in the config.xml file */
    if (aSource)
    {
      *aSource = &json_options_;
    }

    return json_options_[aKey];
  }
  else if (xml_options_.count(aKey) && xml_options_[aKey].defaulted() == false)
  {
    /* set in the config.xml file */
    if (aSource)
    {
      *aSource = &xml_options_;
    }

    return xml_options_[aKey];
  }
  else if (conf_options_.count(aKey) && conf_options_[aKey].defaulted() == false)
  {
    /* set in the volt.conf file */
    if (aSource)
    {
      *aSource = &conf_options_;
    }

    return conf_options_[aKey];
  }
  else if (cmd_options_.count(aKey))
  {
    /* Get the default value.  Must use cmd_options_ because
     * xml_options_/conf_options_ do not have all the supported options. */
    if (aSource)
    {
      *aSource = &cmd_options_;
    }

    return cmd_options_[aKey];
  }
  else
  {
    /* Not found */
    LOG_DEBUG(LOGGER, "Could not find " << aKey << " in config");

    if (aFound)
    {
      *aFound = false;
    }

    return variable_value();
  }
}

void AppConfig::Xml2CommandLineArgs(const xmlpp::Node::NodeList aNodes,
                                    std::vector<std::string> &aResult,
                                    const std::string aKey)
{
  /* Recursively construct command line arguments from XML tags. */

  for(auto iter = aNodes.begin(); iter != aNodes.end(); ++iter)
  {
    const xmlpp::TextNode *text = dynamic_cast<const xmlpp::TextNode *>(*iter);

    /* Skip indentation */
    if(text && text->is_white_space())
    {
      continue;
    }

    if (text)
    {
      /* aKey is the command line arg name (without the -- prefix).
       * The option value is the current text node content. */
      aResult.push_back(std::string("--") + aKey);
      aResult.push_back(text->get_content());
    }

    /* Recurse with children nodes.
     * Update aKey with the current node name. */
    Xml2CommandLineArgs((*iter)->get_children(), aResult,
                        aKey.empty() ? (*iter)->get_name() :
                        aKey + "." + (*iter)->get_name());
  }
}

void AppConfig::Json2CommandLineArgs(const Json::Value aRoot,
                                     std::vector<std::string> &aResult,
                                     const std::string aKey)
{
  /* Recursively construct command line arguments from XML tags. */

  /* assume no number with more than 31 digits are in the config. */
  static const int num_digits = 31;
  char num_buf[num_digits + 1];
  Json::Value value;
  const Json::Value::Members members = aRoot.getMemberNames();

  for (auto iter = members.begin(); iter != members.end(); ++iter)
  {
    value = aRoot[*iter];

    std::string key =
      std::string("--") + (aKey.empty() ? *iter : aKey + "." + *iter);

    if (value.isString())
    {
      LOG_DEBUG(LOGGER, "Add option: " << key << "=" << value.asString());
      aResult.push_back(key);
      aResult.push_back(value.asString());
    }
    else if (value.isBool())
    {
      std::string the_value = value.asBool() ? "true" : "false";
      LOG_DEBUG(LOGGER, "Add option: " << key << "=" << the_value);
      aResult.push_back(key);
      aResult.push_back(the_value);
    }
    else if (value.isNumeric())
    {
      int written = 0;

      if (value.isDouble())
      {
        written =
          snprintf(num_buf, num_digits + 1, "%f", value.asDouble());
      }
      else
      {
        written =
          snprintf(num_buf, num_digits + 1, "%d", value.asInt());
      }

      if (written >= (num_digits + 1))
      {
        LOG_WARN(LOGGER, "Value for " << key << " is too large: " <<
                 value.asDouble());
      }
      else
      {
        LOG_DEBUG(LOGGER, "Add option: " << key << "=" << num_buf);
        aResult.push_back(key);
        aResult.push_back(num_buf);
      }
    }
    else if (value.isObject())
    {
      /* Recurse with this object.
       * Update aKey with the current key. */
      Json2CommandLineArgs(value, aResult,
                           aKey.empty() ? *iter : aKey + "." + *iter);
    }
    else
    {
      LOG_WARN(LOGGER, "Config " << *iter << " is not supported");
    }
  }
}

void AppConfig::UpdateVoltPaths()
{
  /**
   * Set the Volt root directory where files are searched.
   * This is the root path for resources used by the framework (eg modules).
   * All requests are made relative to the root path.
   * Care should be taken if using this API from multiple threads as this is
   * not thread-safe yet.
   * @param[in] aRoot Root path.
   */

  std::string root = GetValue<std::string>("root");
  char real_path_buf[PATH_MAX];
  char *real_path = realpath(root.c_str(), real_path_buf);

  if (real_path)
  {
    volt_root_path_ = real_path;

    /* Paths relative to the root. */
    volt_config_path_ = volt_root_path_ + "/config";
    volt_data_path_ = volt_root_path_ + "/data";

    std::string data_path = AppConfig::Instance().GetValue<std::string>("data-path");

    if (data_path.empty() == false)
    {
      LOG_DEBUG(LOGGER, "Overwriting Volt data path: " << data_path);
      volt_data_path_ = data_path;
    }

    Resource::DirIORequest::Create(volt_data_path_);

    real_path = realpath(volt_data_path_.c_str(), real_path_buf);

    if (real_path)
    {
      volt_data_path_ = real_path;
    }

    if (IsSet("app-js"))
    {
      std::vector<std::string> js_list =
        GetValue<std::vector<std::string>>("app-js");
      relative_app_js_ = js_list[0];
	 
	  /* Check if the path is a directory. */
      struct stat stat_buf;

      if (stat(relative_app_js_.c_str(), &stat_buf) == 0)
      {
        if (S_ISDIR(stat_buf.st_mode))
        {
          relative_app_js_ +=
            std::string("/") + GetValue<std::string>("default-app-js");
        }
      }

      std::string app_root = GetValue<std::string>("app-root");

      if (app_root.empty())
      {
        app_root = ".";

        size_t slash = relative_app_js_.find_last_of("/");

        if (slash != std::string::npos)
        {
          app_root = relative_app_js_.substr(0, slash);

          /* make it relative to the app root path */
          relative_app_js_ = relative_app_js_.substr(slash + 1);
        }
      }

      UpdateAppRootPath(app_root);
    }
  }
  else
  {
    LOG_ERROR(LOGGER, "Failed to get the real Volt root path: " << root);
  }
}

void AppConfig::SaveArgv(const int aArgc, char *aArgv[])
{
  /* Clear existing options. */
  for (auto iter = orig_argv_.begin(); iter != orig_argv_.end(); ++iter)
  {
    /* Use free since strdup allocates with malloc. */
    if (*iter)
    {
      free(*iter);
    }

    *iter = NULL;
  }

  orig_argv_.clear();

  for (int index = 0; index < aArgc; ++index)
  {
    orig_argv_.push_back(strdup(aArgv[index]));
    LOG_DEBUG(LOGGER, "Arg[" << index << "]: " << orig_argv_.back());
  }

  orig_argv_.push_back(static_cast<char *>(NULL));

  if (orig_argv_[0] == NULL || orig_argv_[0][0] == '\0')
  {
    orig_argv_[0] = strdup(GetProgramName().c_str());
    LOG_DEBUG(LOGGER, "Overwrite Arg[0]: " << orig_argv_[0]);
  }
}

