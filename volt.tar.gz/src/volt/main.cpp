#include "VoltFullProcessRuntime.h"
#include "Volt.h"

#include "logger.h"
#include <power_tv.h>
#include <dd-power.h>

static volt::util::Logger LOGGER("volt.main");

#define TEST_EXTERNAL_GMAINLOOP

#ifdef TEST_EXTERNAL_GMAINLOOP
#include <glib.h>
#endif

#include "volt/Volt.h"

#include <sys/types.h>
#include <unistd.h>
#include <thread>
#include <vector>
#include <string>

#include <aul.h>
#include <appcore-efl.h>
#include <Elementary.h>
#include <dlog.h>
#include "clutter_helper.h"
#include <streamline/streamline_annotate.h>

#include <boost/algorithm/string/predicate.hpp>
#include <boost/lexical_cast.hpp>
#include <time.h>

#include <avoc_3d.h>

#ifdef HAS_VCONF
#include "vconf.h"
#endif
#include "system_info.h"

//#define TEST_RESET_APP
//#define TEST_SCENE_ROOT

#ifdef TEST_SCENE_ROOT
#include "SceneRoot.h"
#endif

#ifdef LOG_TAG
#undef LOG_TAG
#endif

#define LOG_TAG "VOLT_CONTAINER"

/* Utility macros to log timestamp */
#define LOG_TAG_TS LOG_TAG "_TS"
#define LOG_TS(msg) do \
{ \
struct timeval tv; \
	gettimeofday(&tv, NULL); \
	__dlog_print(LOG_ID_MAIN, DLOG_DEBUG, LOG_TAG_TS, "[%lu.%06lu|%s] %s\n", tv.tv_sec, tv.tv_usec, __func__, (msg) ? (msg) : ""); \
} while (0)

ANNOTATE_DEFINE;

int globalargc;
char **globalargv;

bundle *b_dup_deeplink;

funcP HaloInitialize = NULL;
funcP HaloFinalize = NULL;
funcP2 SetupVDDisplayFn = NULL;
funcP2 XRaiseWindowFn = NULL;

#define JSON_LENGTH 2048
#define SCREEN_CAPTURE_LENGTH 1024

static VoltFullProcessRuntime* GetVoltFullProcessRuntime() 
{
	VoltFullProcessRuntime *runtime =
		static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

	return runtime;
}

using namespace volt::util;

namespace
{
	VoltEngine *engine_ = NULL;

	std::string prog_name_;
	std::vector<char *> args_;
	bool launched_via_aul_ = false;
	bool firstReset = true;

	int OnCreate(void *data)
	{
		LOG_TS("");
		LOGD("Doing nothing here\n");
		avoc_set_3d_mode_async(0, AVOC_3D_EFFECT_OFF, AVOC_NO_SAVE); 

		return 0;
	}

	std::string GetAppName()
	{
		std::string appName = AppConfig::Instance().GetValue<std::string>("app-name");
		if (appName.empty())
		{
			std::string appjs = AppConfig::Instance().GetValue<std::string>("app-js");

			if (boost::starts_with(appjs, "/opt/down/panels/apps/"))
			{
				return std::string("Apps");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/clips/"))
			{
				return std::string("Clips");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/games/"))
			{
				return std::string("Games");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/mycontents/"))
			{
				return std::string("My Contents");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/newson/"))
			{
				return std::string("NewsOn");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/soccer/"))
			{
				return std::string("Soccer");
			}
		}
		
		return appName;
	}

	std::string GetAppId()
	{
		std::string appId = AppConfig::Instance().GetValue<std::string>("app-id");
		if (appId.empty())
		{
			std::string appjs = AppConfig::Instance().GetValue<std::string>("app-js");

			if (boost::starts_with(appjs, "/opt/down/panels/apps/"))
				
				
				
			{
				return std::string("org.volt.apps");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/clips/"))
			{
				return std::string("org.volt.clips");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/games/"))
			{
				return std::string("org.volt.games");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/mycontents/"))
			{
				return std::string("org.volt.mycontents");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/newson/"))
			{
				return std::string("org.volt.newson");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/soccer/"))
			{
				return std::string("org.volt.soccer");
			}
		}
		
		return appId;
	}

	std::string GetAppIcon()
	{
		std::string appIcon = AppConfig::Instance().GetValue<std::string>("app-icon");
		if (appIcon.empty())
		{
			return std::string("");
		}

		return appIcon;
	}

	int Capture()
	{
		LOGD("Capture Screenshot");
		char *val = vconf_get_str("db/volt/return_last_play_index");
		int captureHeight = 540;

		if (val != NULL)
		{
			int h = atoi(val);
			if (h > 0 && h <= 1080)
			{
				captureHeight = h;
			}
		}

		printf("captureHeight: %d\n", captureHeight);
		
		std::string appId = GetAppId();
		std::string appName = GetAppName();
		std::string appIcon = GetAppIcon();

		if (appId == "org.volt.games" || appId == "org.volt.apps")
		{
			// DF141021-03816
			return 0; // ��������Ʈ �϶��� �ϴ� ����������...
		}
		
		int value = 1080;
		int systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT, &value);
		printf("systemResult-----------------> %d\n", systemResult);
		if(systemResult != SYSTEM_INFO_ERROR_NONE)
		{
			LOG_FATAL(LOGGER, "Failed to get value for Resolution[" << SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT << "]" );
		}
		/*
		else if(value == 720)
		{
			// 720�� ��ũ�� ĸ�� �ϴ� ����
			return 0;
		}*/

	//	printf("SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT : %d\, %dn" , SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT, systemResult);
	//	printf("SYSTEM_INFO_KEY_OSD_RESOLUTION_WEIGHT : %d\n" , SYSTEM_INFO_KEY_OSD_RESOLUTION_WEIGHT);



		time_t curTime;
		time(&curTime);

		printf("Capture Screenshot-----------------------------------------------\n");


		int caller_pid;
		char caller_appid[255] = {0,};
		//resolution
		caller_pid = atoi(bundle_get_val(b_dup_deeplink,AUL_K_CALLER_PID));
		aul_app_get_appid_bypid(caller_pid, caller_appid, sizeof(caller_appid));
		//caller_app_id 
		printf("----------------------------> caller_appid : %s \n", caller_appid);
		//


		char json[JSON_LENGTH] = {0,};
		snprintf(json, JSON_LENGTH, "'app_title': '%s', 'cur_time': %ld, 'caller_app_id': '%s'", const_cast<char*>(appName.c_str()), curTime, caller_appid);

		
		volt::util::ScreenCapture(const_cast<char*>(appId.c_str()), json);
		printf("-------------> appid : %s\n", appId.c_str());
		printf("-------------> app_info: %s\n", json);

		printf("memory/volt/history_event: %s\n", vconf_get_str("memory/volt/history_event"));

		/*
		char screenPath[SCREEN_CAPTURE_LENGTH] = {0,};
		snprintf(screenPath, SCREEN_CAPTURE_LENGTH, "/opt/down/common/capture_img/%s.png", appId.c_str());
		volt::util::ScreenCapture(GetMainStage(), screenPath, captureHeight);

		char json[JSON_LENGTH] = {0,};
		snprintf(json, JSON_LENGTH, "{'type': 'volt_app', 'app_id': '%s', 'app_title': '%s', 'app_icon_path': '%s', 'cur_time': %ld, 'capture_path': '%s'}", 
			appId.c_str(), appName.c_str(), appIcon.c_str(), curTime, screenPath);

		printf("json: %s\n", json);
		vconf_set_str("memory/volt/history_event", json);

		printf("memory/volt/history_event: %s\n", vconf_get_str("memory/volt/history_event"));
		
		*/
		return 0;
	}

	int OnTerminate(void *data)
	{

		Capture();
		LOGD("Received terminate.. \n");
		engine_->Quit();
		engine_->Cleanup();
		LOGD("Terminate Complete\n");
		return 0;
	}

	

	int OnPause(void *data)
	{
		LOGD("Hiding Volt UI...\n");
		
		VoltFullProcessRuntime *runtime =
			static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
		runtime->script_engine_->sendInteruptEvent(volt::util::ON_PAUSE);
		
		if (AppConfig::Instance().GetValue<std::string>("firstscreen") == "true")
		{
			unlink("/tmp/firstscreen_visible.txt");
			return 0;
		}

		Capture();

		return 0;
	}

	int OnResume(void *data)
	{
		LOGD("Showing Volt UI...\n");
		
		avoc_set_3d_mode_async(0, AVOC_3D_EFFECT_OFF, AVOC_NO_SAVE); 
		
		if (AppConfig::Instance().GetValue<std::string>("firstscreen") == "true")
		{
			FILE* fp = fopen("/tmp/firstscreen_visible.txt", "w");
			fprintf(fp, "on");
			fclose(fp);
		}

		volt::util::VDRaiseXWindow(GetMainStage());

		VoltFullProcessRuntime *runtime =
			static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
		runtime->script_engine_->sendInteruptEvent(volt::util::ON_RESUME);
		
		return 0;
	}

	void BundleIterator(const char *aKey, const char *aVal, void *aData)
	{
		LOGD("bundle[%s] = %s\n", aKey, aVal);
		printf("bundle[%s] = %s\n", aKey, aVal);

		if (strncmp(aKey, "__AUL_", 6) == 0)
		{
			/* Assume launched by AUL if the bundle contains AUL keys. */
			launched_via_aul_ = true;
		}
		else if (strncmp(aKey, "--", 2) == 0)
		{
			/* Only using the keys with "--" prefix.
			* This is a work around for the bug in aul_test where it adds extra data
			* to the bundle.  For example, if volt-container is launched like this:
			*   aul_test launch volt-container key1 val1 key2 val2
			* aul_test will put the following key-val pair into the bundle:
			*   key1=>val1, val1=>key2, key2=>val2
			*/
			args_.push_back(strdup(aKey));
			args_.push_back(strdup(aVal));
		}
	}

	void bundleIteratorReset(const char *aKey, const char *aVal, void *aData)
	{
		if (strncmp(aKey, "__", 2) == 0)
		{
			//do Nothing it's AUL key
		}
		else
		{
			VoltEngine::ExternalData* external = (VoltEngine::ExternalData*) aData;
			external->eventArgs.InsertString(aKey, aVal);
		}
	}

	int OnReset(bundle *b, void *data)
	{
		LOG_TS("");
		LOGD("Initializing VoltEngine...\n");
    
    avoc_set_3d_mode_async(0, AVOC_3D_EFFECT_OFF, AVOC_NO_SAVE); 
    
		const char* reset = bundle_get_val(b_dup_deeplink, "reset");
		printf("reset: %s\n", reset);
		if (reset != NULL && strlen(reset))
		{
			printf("starting reset\n");
			printf("end reset\n");
			printf("process exit\n");
			elm_exit();
			return 0;
		}

		if (AppConfig::Instance().GetValue<std::string>("firstscreen") == "true")
		{
			FILE* fp = fopen("/tmp/firstscreen_visible.txt", "w");
			fprintf(fp, "on");
			fclose(fp);
		}

		/* Clear args_ (populated with command line args) and re-populate with the
		* options given via the bundle. */
		args_.clear();
		/* First arg is always the prog name. */
		args_.push_back(strdup(prog_name_.c_str()));

		/* Populate with bundle data. */
		bundle_iterate(b, BundleIterator, NULL);


		VoltEngine::ExternalData external;
		bundle_iterate(b, bundleIteratorReset, (void*) &external);

		if (firstReset)
		{
			firstReset = false;
			
			bundle_iterate(b_dup_deeplink, bundleIteratorReset, (void*) &external);
			LOG_TS("Before Initialize");
			if (engine_->Initialize(args_.size(), args_.data(), external) == false)
			{
				LOGE("Failed to initialize/run VoltEngine...\n");
			}
			LOG_TS("After Initialize");
		}
		else
		{
			volt::util::VDRaiseXWindow(GetMainStage());
			engine_->ResetApp(external.eventArgs);
		}

		return 0;
	}

} /* namespace */

static int onSuspend(int option, void *data)
{
	LOG_FATAL(LOGGER, "[Volt] Engine On_Suspend Call! [%d] \n" << option);

	if(option & POWER_OFF_TO_SUSPEND)
	{
		GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_SUSPEND);
	}
	else if(option == POWER_OFF_REASON_FACTORY_RESET)
	{
		GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_FACTORY_RESET);
	}
	else if(option == POWER_OFF_REASON_SERVICE_RESET)
	{
		GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_SERVICE_RESET);
	}

	return 0;	
}

static void onWakeup(int option, void *data)
{
	LOG_FATAL(LOGGER, "[Volt] Engine On_Wake_Up Call!\n");
	GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_WAKEUP);
	int result = -1;
	result = power_subscribe_poweroff(onSuspend, (void *)GetVoltFullProcessRuntime());
	LOG_FATAL(LOGGER, "[Volt] Engine On_Suspend Callback Register!\n");
	if(result < 0)
	{
	  LOG_FATAL(LOGGER, "Failed to Unsubscribe Poweroff\n");
	}	
}

extern "C" void register_halo_init_func(funcP p1, funcP p2, funcP2 p3, funcP2 p4)
{
	HaloInitialize = p1;
	HaloFinalize = p2;
	SetupVDDisplayFn = p3;
	XRaiseWindowFn = p4;
}

extern "C" int startvolt(int aArgc, char **aArgv, int gargc, char *gargv[], bundle *deep_link)
{
	LOG_TS("");
	globalargc = gargc;
	globalargv = gargv;

	b_dup_deeplink=bundle_dup(deep_link); // duplicate deeplink 
	int result = -1;
	result = power_subscribe_poweroff(onSuspend, (void *)GetVoltFullProcessRuntime());
	if(result < 0)
	{
	  LOG_FATAL(LOGGER, "Failed to Unsubscribe Poweroff\n");
	}
	
	result = power_subscribe_wakeup(onWakeup, (void *)GetVoltFullProcessRuntime());
	if(result < 0)
	{
	  LOG_FATAL(LOGGER, "Failed to Unsubscribe Wakeup\n");
	}
	engine_ = VoltEngine::New();

	LOGD("Initializing VoltEngine %s...\n", VOLT_VERSION);

	prog_name_ = aArgv[0];
	args_.push_back(strdup(prog_name_.c_str()));

	/* Get data from the bundle.
	* args_ will be populated in BundleIterator */
	bundle *b = bundle_import_from_argv(aArgc, aArgv);
	bundle_iterate(b, BundleIterator, NULL);
	bundle_free(b);

	for (int i=0;i<aArgc;i++) {
		args_.push_back(aArgv[i]);
	}

	if (launched_via_aul_ == false)
	{
		/* Use the original args if not launched via AUL... */
		args_.assign(aArgv, aArgv + aArgc);
	}

	for (unsigned int index = 0; index < args_.size(); ++index)
	{
		printf("args_[%d] = %s\n", index, args_[index]);
	}

	LOG_TS("Before ParseOptions...");
	if (engine_->ParseOptions(args_.size(), args_.data()))
	{
		LOG_TS("After ParseOptions...");
		if (engine_->IsAppProcess())
		{
			/* This is the main app process; register appcore event handlers */

			struct appcore_ops ops;
			ops.create = OnCreate;
			ops.terminate = OnTerminate;
			ops.pause = OnPause;
			ops.resume = OnResume;
			ops.reset = OnReset;

			LOG_TS("");
			LOGD("Starting appcore_efl_main\n");
			appcore_efl_main("volt-container", &aArgc, &aArgv, &ops);
		}
		else
		{
			if (engine_->Initialize(args_.size(), args_.data()))
			{
				/* Child Volt processes do not need to handle appcore events... */
				if (engine_->Run() == false)
				{
					LOGE("Failed to run VoltEngine...\n");
				}
			}
			else
			{
				LOGE("Failed to initialize/run VoltEngine...\n");
			}
		}
	}

	LOGD("Cleaning up VoltEngine...\n");
 	bundle_free(b_dup_deeplink);
	engine_->Cleanup();

	delete engine_;

	return 0;
}

void* GetMainStage()
{
	VoltFullProcessRuntime *runtime =
		static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

	return runtime->GetMainStage();
}

void RegisterPluginBridge(Bridge::ScriptBridge* bridge)
{
	VoltFullProcessRuntime *runtime =
		static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
	runtime->RegisterPluginBridge(bridge);
}
