/*
 * FileIORequest.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "FileIORequest.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#include "DrmManager.h"

using namespace volt::util;

#include "AppConfig.h"

namespace Resource
{

/******************************************************************************
 * FileIORequest
 *****************************************************************************/

const std::string FileIORequest::LOGGER_NAME = "volt.resource.file";
FileIORequest::AllowedPathCheckFunc *FileIORequest::AllowedPathChecker = NULL;
std::string FileIORequest::license_path_ = "invalid path";

unsigned char FileIORequest::VoltPath(const std::string &aUri,
                                      std::string &aVoltPath)
{
  unsigned char permission = PERM_NO_ACCESS; /* no perm to read nor write. */

  if (aUri.length() == 0)
  {
    return permission;
  }

  static const std::string file_scheme("file://");
  static const std::string dir_scheme("dir://");
  static const std::string volt_root_prefix("$VOLT_ROOT/");
  static const std::string app_root_prefix("$APP_ROOT/");
  static const std::string app_data_prefix("$APP_DATA/");
  static const std::string sys_root_prefix("$SYS_ROOT/");
  static const std::string usb_root_prefix("$USB_ROOT/");

  const char *uri = aUri.c_str();

  if (file_scheme.compare(0, file_scheme.length(), uri,
                          file_scheme.length()) == 0)
  {
    /* Remove file scheme */
    uri += file_scheme.length();
  }
  else if (dir_scheme.compare(0, dir_scheme.length(), uri,
                              dir_scheme.length()) == 0)
  {
    /* Remove directory scheme */
    uri += dir_scheme.length();
  }

  /* Determine which root path to use. */
  if (volt_root_prefix.compare(0, volt_root_prefix.length(), uri,
                               volt_root_prefix.length()) == 0)
  {
    aVoltPath = AppConfig::Instance().GetVoltRootPath() + "/" + (uri + volt_root_prefix.length());

    /* Read-only */
    permission |= PERM_R;
  }
  else if (app_root_prefix.compare(0, app_root_prefix.length(), uri,
                                   app_root_prefix.length()) == 0)
  {
    aVoltPath = AppConfig::Instance().GetAppRootPath() + "/" + (uri + app_root_prefix.length());

    /* Read/write */
    permission |= PERM_R | PERM_W;
  }
  else if (app_data_prefix.compare(0, app_data_prefix.length(), uri,
                                   app_data_prefix.length()) == 0)
  {
    aVoltPath = AppConfig::Instance().GetAppDataPath() + "/" + (uri + app_data_prefix.length());

    /* Read/write */
    permission |= PERM_R | PERM_W;
  }
  else if (sys_root_prefix.compare(0, sys_root_prefix.length(), uri,
                                   sys_root_prefix.length()) == 0)
  {
    aVoltPath = std::string("/") + (uri + sys_root_prefix.length());

    /* Read-only */
    permission |= PERM_R;
  }
  else if (usb_root_prefix.compare(0, usb_root_prefix.length(), uri,
                                   usb_root_prefix.length()) == 0)
  {
	  char rootPath[1024];
	  bool found = false;

	  for (int i=0;i<24;i++)
	  {
		  snprintf(rootPath, 1023, "/opt/storage/usb/sd%c1/", ('a' + i));
		  if (access(rootPath, F_OK) == 0)
		  {
			  found = true;
			  break;
		  }
	  }

	  printf("rootPath: %s\n", rootPath);

	  if (found)
	  {
		aVoltPath = std::string(rootPath) + (uri + usb_root_prefix.length());
	  }
	  else
	  {
		aVoltPath = std::string("/opt/storage/usb/sda1/") + (uri + usb_root_prefix.length());
	  }

    permission |= PERM_R | PERM_W;
  }
  else
  {
    if (*uri == '/')
    {
      /* Default to sys root */
      aVoltPath = uri;

      /* Read-only */
      permission |= PERM_R;
    }
    else
    {
      /* Default to app root */
      aVoltPath = AppConfig::Instance().GetAppRootPath() + "/" + uri;

      /* Read-only */
      permission |= PERM_R | PERM_W;
    }
  }

  return permission;
}

std::string FileIORequest::AbsoluteFilePath(const std::string &aPath)
{
  std::string absolutePath = "";
  std::string path = aPath;

  /* Get absolute path */
  char real_path_buf[PATH_MAX];
  char *real_path = realpath(path.c_str(), real_path_buf);

  if (real_path == NULL && errno == ENOENT)
  {
    size_t last_slash = path.find_last_of('/');

    if (last_slash != std::string::npos)
    {
      std::string file_name = path.substr(last_slash);
      path = path.substr(0, last_slash);

      real_path = realpath(path.c_str(), real_path_buf);

      if (real_path)
      {
        absolutePath = real_path + file_name;
      }
    }
  }
  else if(real_path)
  {
    absolutePath = real_path;
  }

  return absolutePath;
}

unsigned char FileIORequest::NormalizePath(const std::string &aUri,
    std::string &aNormalized)
{
  unsigned char permission = PERM_NO_ACCESS; /* no perm to read nor write. */

  if (aUri.length() == 0)
  {
    return permission;
  }

  static Logger logger(LOGGER_NAME);
  bool is_accessible = false;
  std::string tmp_path;
  std::string real_path;

  permission = FileIORequest::VoltPath(aUri, tmp_path);

  if(permission != PERM_NO_ACCESS and tmp_path.length())
  {
    real_path = AbsoluteFilePath(tmp_path);
  }

  if (real_path.length())
  {
    if (strncmp(AppConfig::Instance().GetAppRootPath().c_str(), real_path.c_str(), AppConfig::Instance().GetAppRootPath().length()) == 0 ||
        strncmp(AppConfig::Instance().GetAppDataPath().c_str(), real_path.c_str(), AppConfig::Instance().GetAppDataPath().length()) == 0 ||
        strncmp(AppConfig::Instance().GetVoltRootPath().c_str(), real_path.c_str(), AppConfig::Instance().GetVoltRootPath().length()) == 0)
    {
      /* Accessible if within the allowed root paths. */
      is_accessible = true;
    }
    else if (AllowedPathChecker && AllowedPathChecker(real_path.c_str()))
    {
      /* Accessible only if allowed. */
      is_accessible = true;
    }
  }
  else
  {
    LOG_ERROR(logger, "Failed to get the real path for " << aUri);
  }

  if (is_accessible)
  {
    aNormalized = real_path;
  }
  else
  {
    LOG_ERROR(logger, "No permission to read/write from/to " << aUri);
    permission = PERM_NO_ACCESS;
  }

  LOG_DEBUG(logger, "URI: " << aUri);
  LOG_DEBUG(logger, "Path: " << tmp_path);
  LOG_DEBUG(logger, "Real Path: " << real_path);
  LOG_DEBUG(logger, "Accessible: " << (is_accessible ? "yes" : "no"));
  LOG_DEBUG(logger, "Permission: " << (permission & PERM_R ? "r" : "_") <<
            (permission & PERM_W ? "w" : "_"));

  return permission;
}

void FileIORequest::SetLicensePath(const std::string &aPath)
{
  license_path_ = aPath;
}

const std::string& FileIORequest::GetLicensePath()
{
  return license_path_;
}

FileIORequest::FileIORequest(const std::string &aUri):
  IORequest(aUri), logger_(LOGGER_NAME),
  fd_(-1), event_(NULL), is_valid_path_(false),
  path_(), permission_(PERM_NO_ACCESS)
{
  LOG_DEBUG(logger_, "Born: " << uri());

  if (uri().compare(0, 7, "file://") != 0)
  {
    set_uri(std::string("file://") + uri());
  }
}

FileIORequest::~FileIORequest()
{
  LOG_DEBUG(logger_, "Dead(" << id() << "): " << uri());

  if (event_)
  {
    event_free(event_);
  }
}

bool FileIORequest::RegisterEvent(struct event_base *aEventBase)
{
  LOG_DEBUG(logger_, "Registering new event");

  fd_ = open(path().c_str(), O_RDONLY);

  if (fd_ < 0)
  {
    LOG_WARN(logger_, "Failed to open: " << uri());
    return false;
  }

  event_ = event_new(aEventBase, fd_, EV_READ | EV_PERSIST,
                     FileIORequest::EventCallback, this);

  if (event_ == NULL)
  {
    LOG_WARN(logger_, "Failed to create event: " << uri());
    return false;
  }

  /* It seems epoll doesn't support regular files.  Maybe we don't need async
   * file io...
   * http://stackoverflow.com/questions/5456967/problem-handling-file-i-o-with-libevent2
   */
  event_add(event_, NULL);

  return true;
}

void FileIORequest::InitResponse()
{
  IORequest::InitResponse();
  response()->set_source(IOResponse::SOURCE_FILE);
}

bool FileIORequest::Execute()
{
  response()->set_status(400);
  response()->set_reason_string("Bad request");

  if ((permission_ = NormalizePath(uri(), path_)) != PERM_NO_ACCESS)
  {
    is_valid_path_ = true;
  }

  switch (method())
  {
  case METHOD_GET:
    return ReadFile();
  case METHOD_PUT: /* fallthru */
  case METHOD_POST:
    return ExecuteWrite();
  case METHOD_DELETE:
    return ExecuteDelete();
  default:
    return false;
  }
}

bool FileIORequest::IsValid() const
{
  return true;
}

bool FileIORequest::ReadFile()
{
  LOG_DEBUG(logger_, "Reading file: " << uri());

  response()->set_status(403);
  response()->set_reason_string("Forbidden");

  if (is_valid_path_ == false)
  {
    LOG_DEBUG(logger_, "Invalid path: " << path());
    return false;
  }

  response()->set_status(404);
  response()->set_reason_string("File not found");

  FILE *file = fopen(path().c_str(), "rb");

  if (file == NULL)
  {
    LOG_DEBUG(logger_, "Check encrypted version of " << path());
    return ReadEncryptedFile();
  }

  char chunk[8192];
  size_t num_read = 0;

  while (true)
  {
    num_read = fread(chunk, 1, sizeof(chunk) / sizeof(chunk[0]), file);
    LOG_DEBUG(logger_, "Read " << num_read << " bytes");

    if (num_read > 0)
    {
      response()->AppendData(chunk, num_read);
    }

    if (feof(file))
    {
      LOG_DEBUG(logger_,
                "Finished loading " << response()->data().size() << " bytes: " << uri());
      response()->set_status(200);
      response()->set_reason_string("OK");
      break;
    }

    if (ferror(file))
    {
      LOG_ERROR(logger_, "Error loading: " << uri());
      response()->set_reason_string("Read error");
      break;
    }
  }

  fclose(file);
  return response()->status() == 200;
}

bool FileIORequest::ReadEncryptedFile()
{
  /* Assuming only 1 Volt app for this process. */
  static bool try_decrypt = true;

  response()->set_status(404);
  response()->set_reason_string("File not found");

  if (try_decrypt == false)
  {
    return false;
  }

  if (DrmManager::Instance().LoadLicense(GetLicensePath()) == false)
  {
    LOG_WARN(logger_, "Failed to load license: " << GetLicensePath());
    try_decrypt = false;
    return false;
  }

  std::string enc_path = path() + ".spm";

  unsigned char *decrypted_data = NULL;
  int decrypted_len = 0;

  LOG_DEBUG(logger_, "Decrypting file: " << enc_path);

  if (DrmManager::Instance().DecryptFile(enc_path.c_str(),
                                         decrypted_data, decrypted_len) == false)
  {
    LOG_WARN(logger_, "Failed to decrypt file: " << enc_path);
    response()->set_reason_string("Decryption error");
    return false;
  }

  LOG_DEBUG(logger_, "Decrypted " << decrypted_len << " bytes");

  if (decrypted_data)
  {
    response()->AppendData(decrypted_data, decrypted_len);
    delete [] decrypted_data;
  }

  response()->set_status(200);
  response()->set_reason_string("OK");

  return true;
}

bool FileIORequest::ExecuteWrite()
{
  LOG_DEBUG(logger_, "Writing file: " << uri());

  /* TODO:
   *   - Check if the path is under $APP_ROOT.
   *   - If not, set status to 403 and return false.
   */

  // if we are in recursive mode,
  // attempt to create all of the parent directory and then re-evaluate permission
  if(not is_valid_path_ and recursive())
  {
    std::string voltPath = "";
    unsigned char newPermission = FileIORequest::VoltPath(uri(), voltPath);

    if(voltPath.length() and (newPermission & PERM_W))
    {
      std::string createPath = DirIORequest::GetParentPath(voltPath);

      // create the missing directories
      if(createPath.length() and DirIORequest::Create(createPath, true))
      {
        // lets try normalize path again..
        if ((permission_ = NormalizePath(uri(), path_)) != PERM_NO_ACCESS)
        {
          is_valid_path_ = true;
        }
      }
    }
  }

  response()->set_status(403);
  response()->set_reason_string("Forbidden");

  if ((permission_ & PERM_W) == 0)
  {
    LOG_WARN(logger_, "Not permitted to write to " << path());
    return false;
  }

  std::string reason;
  bool result = Write(path(), data().c_str(), data().size(), reason);

  if(result)
  {
    response()->set_status(200);
  }

  response()->set_reason_string(reason);

  return result;
}

bool FileIORequest::Write(const std::string &path, const char* data,
                          size_t length, std::string &reason)
{
  volt::util::Logger logger("volt.resource.file");

  bool result = false;
  FILE *file = fopen(path.c_str(), "wb");

  if (file == NULL)
  {
    LOG_ERROR(logger, "null file pointer for " << path);
    return false;
  }

  size_t to_write = length;
  int total_written = 0;
  int num_written = 0;

  while (to_write > 0)
  {
    num_written = fwrite(data + total_written, 1, to_write, file);

    if (num_written > 0)
    {
      to_write -= num_written;
      total_written += num_written;
    }

    LOG_DEBUG(logger, "Wrote " << total_written << " of " << length <<
              " (" << to_write << " left)");

    if (feof(file))
    {
      LOG_DEBUG(logger,
                "Finished writing " << length << " bytes: " << path);
      reason = "OK";
      result = true;
      break;
    }

    if (ferror(file))
    {
      LOG_ERROR(logger, "Error writing: " << path);
      reason = "Write error";
      break;
    }
  }

  if (to_write == 0)
  {
    reason = "OK";
    result = true;
  }

  fclose(file);
  return result;
}

bool FileIORequest::ExecuteDelete()
{
  LOG_DEBUG(logger_, "Deleting file: " << path());

  response()->set_status(403);
  response()->set_reason_string("Forbidden");

  if (is_valid_path_ == false)
  {
    LOG_DEBUG(logger_, "Invalid path: " << path());
    return false;
  }

  bool result = false;

  if ((permission_ & PERM_W) == 0)
  {
    LOG_WARN(logger_, "Not permitted to delete " << path());
    return false;
  }

  result = Delete(path());

  if(not result)
  {
    response()->set_status(404);
    response()->set_reason_string("File not found");
  }
  else
  {
    response()->set_status(200);
    response()->set_reason_string("OK");
  }

  return result;
}

bool FileIORequest::Delete(const std::string &path)
{
  volt::util::Logger logger("volt.resource.file");

  int status = 0;

  if ((status = unlink(path.c_str())) == -1)
  {
    LOG_WARN(logger, "Failed to delete file: " << path);

    if (access(path.c_str(), F_OK) != 0)
    {
      LOG_DEBUG(logger, "File not found: " << path);
    }

    return false;
  }

  return true;
}

void FileIORequest::EventCallback(int aFd, short aEvent, void *aSelf)
{
  FileIORequest *self = (FileIORequest *) aSelf;

  LOG_DEBUG(self->logger_, "Got event " << aEvent);

  if ((aEvent & EV_READ) == 0)
  {
    LOG_DEBUG(self->logger_, "Only interested in READ event");
    return;
  }

  char buf[8192];
  int num_read = read(aFd, buf, sizeof(buf) / sizeof(buf[0]));

  if (num_read == 0)
  {
    LOG_DEBUG(self->logger_, "EOF");

    close(self->fd_);

    /* EOF */
    event_free(self->event_);
    self->event_ = NULL;

    self->Callback();
  }
  else if (num_read > 0)
  {
    LOG_DEBUG(self->logger_, "Read " << num_read << " bytes");
    self->response()->AppendData(buf, num_read);
  }
  else
  {
    LOG_ERROR(self->logger_, "Failed to read from file");
  }
}

} /* namespace Resource */
