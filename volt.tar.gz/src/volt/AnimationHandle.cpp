#include "AnimationHandle.h"

using namespace volt::graphics;

AnimationHandle::AnimationHandle(Widget* widget, float duration, float repeat, std::set<AnimatableProperty> properties)
  : props(properties), host(widget), paused(false), isLive(true), isReferenced(true), isInCallbacks(false), duration(duration), repeat(repeat)
{
  //Add the anim handle to its host widget's animations list
  host->addAnimationHandle(this);

  //Host should notify this anim handle if it is destroyed

  ClutterTimeline* guideline = clutter_timeline_new(duration);
  clutter_timeline_set_repeat_count(guideline, repeat);

  //add a signal to delete the guideline when completed (and invoke callbacks)
  g_signal_connect ( guideline, "stopped", G_CALLBACK(onGuidelineFinished), this );
  //add a signal for key callbacks
  g_signal_connect( guideline, "marker-reached", G_CALLBACK(onMarkerReached), this);

  clutter_timeline_start(guideline);

  transitions.push_back(guideline);
}

void AnimationHandle::selfDestructIfAble()
{
  if (!isReferenced && !isLive && !isInCallbacks) //If there is no danger of either the timeline or external code trying to use this handle
  {
    delete this;
  }
}

void AnimationHandle::release()
{
  //If isLive is false, the animation has already completed or been cancelled, and we are free to delete the object.
  //If not, than set it to false. This will cause this function to be called again when the animation completes.
  isReferenced = false;
  selfDestructIfAble();
}

bool AnimationHandle::hasProperty(AnimatableProperty prop) const
{
  return props.count(prop) > 0;
}

bool AnimationHandle::isActive() const
{
  return isLive && transitions.size() > 0;
}

void AnimationHandle::addTransition(ClutterTransition* transition, AnimatableProperty property, const char* name)
{
  clutter_transition_set_remove_on_complete(transition, true);
  float dur = duration == 0 ? 1 : duration;
  clutter_timeline_set_duration(CLUTTER_TIMELINE(transition), dur);
  clutter_timeline_set_repeat_count(CLUTTER_TIMELINE(transition), repeat);

  if (clutter_actor_get_transition(host->getAnimationActor(property), name))
  {
    clutter_actor_remove_transition(host->getAnimationActor(property), name);
  }

  clutter_actor_add_transition(host->getAnimationActor(property), name, transition);

  transitions.push_back(CLUTTER_TIMELINE(transition));
}

double AnimationHandle::getProgress() const
{
  if (!isActive())
  {
    return 0;
  }

  ClutterTimeline* guideline = transitions[0];

  return clutter_timeline_get_progress(guideline);
}

int AnimationHandle::getCurrentRepeat() const
{
  if (!isActive())
  {
    return 0;
  }

  ClutterTimeline* guideline = transitions[0];

  return clutter_timeline_get_current_repeat(guideline);
}


void AnimationHandle::cancel()
{
  forEachTransition(cancelTransition);
  isLive = false;
}

void AnimationHandle::pause()
{
  if (!paused)
  {
    forEachTransition(clutter_timeline_pause);
    paused = true;
  }
}

void AnimationHandle::resume()
{
  if(paused)
  {
    forEachTransition(clutter_timeline_start);
    paused = false;
  }
}

void AnimationHandle::jump(double progress)
{
  guint timestamp = (guint)(progress * duration);
  forEachTransition(clutter_timeline_advance, timestamp);
}

void AnimationHandle::skip(double progress)
{
  guint timestamp = (guint)(progress * duration);
  forEachTransition(clutter_timeline_skip, timestamp);
}

void AnimationHandle::forEachTransition( void (*transformation)(ClutterTimeline*) )
{
  if (isLive)
  {
    for (auto it = transitions.begin(); it != transitions.end(); ++it)
    {
      if (CLUTTER_IS_TIMELINE(*it)) //If the timeline has been destroyed already, say by cancelAnim or by just finishing, do nothing.
      {
        transformation(*it);
      }
    }
  }
}

void AnimationHandle::forEachTransition( void (*transformation)(ClutterTimeline*, guint), double param )
{
  if (isLive)
  {
    for (auto it = transitions.begin(); it != transitions.end(); ++it)
    {
      if (CLUTTER_IS_TIMELINE(*it)) //If the timeline has been destroyed already, say by cancelAnim or by just finishing, do nothing.
      {
        transformation(*it, param);
      }
    }
  }
}

void AnimationHandle::cancelTransition(ClutterTimeline* timeline)
{
  clutter_timeline_stop(timeline);
  g_object_unref(timeline);
}


void AnimationHandle::addCompletionCallback(AnimationCallback callback)
{
  if (!isActive())
  {
    return;
  }

  if (callback != nullptr)
  {
    completionCallbacks.push_back(callback);
  }
}

void AnimationHandle::addKeyCallback(double checkpoint, AnimationCallback callback)
{
  if (!isActive())
  {
    return;
  }

  ClutterTimeline *guideline = transitions[0];

  static int uniqueMarkerName = 0;
  //generate unique ids by just incrementing this counter after every use. We don't really care what
  //names we give to markers, since we never need to query or remove them. They just need to be unique.
  std::string markerName = std::to_string(uniqueMarkerName++);

  keyCallbacks[markerName] = callback;

  clutter_timeline_add_marker(guideline, markerName.c_str(), checkpoint);
}

void AnimationHandle::onMarkerReached(ClutterTimeline* timeline, gchar* markerName, gint msecs, gpointer handle)
{
  AnimationHandle* animHandle = static_cast<AnimationHandle*>(handle);

  if(animHandle->keyCallbacks.count(markerName) != 0)
  {
    AnimationCallback callback = animHandle->keyCallbacks[markerName];

    if(callback) //invoke callback
    {
      callback();
    }
  }
}

void AnimationHandle::onGuidelineFinished(ClutterTimeline* guideline, gboolean isFinished, gpointer handle)
{
  AnimationHandle* animHandle = static_cast<AnimationHandle*>(handle);

  if (isFinished)
  {
    //Clean up all transitions by calling cancel. We know cancel has not already been called because isFinished is true.
    animHandle->cancel();
    animHandle->host->removeAnimationHandle(animHandle);

    //invoke completion callbacks
    animHandle->isInCallbacks = true; //guard against callback code releasing the handle
    for (auto it = animHandle->completionCallbacks.begin();
         it != animHandle->completionCallbacks.end(); ++it)
    {
      AnimationCallback callback = *it;

      if (callback)
      {
        callback();
      }
    }
    animHandle->isInCallbacks = false;
  }
  else
  {
    animHandle->host->removeAnimationHandle(animHandle);
  }

  //At this point either the animation has completed or been cancelled. All callbacks have been invoked if they should be.
  animHandle->selfDestructIfAble();
}

