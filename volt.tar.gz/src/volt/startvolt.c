#include <sharedvc.h>
#include <dbg.h>
#include <vconf.h>

//const char *lic_key="db/menu/smart_hub/homedatacontrol/defaultdisclaimeragree";

int main(int argc, char **argv)
{
	syscall(380, "-------------------------main() start-------------------------"); 
	printf("\n-------------------------main() start-------------------------");
	
/*	int lic_val=0;
	LOGE("In main function");
	if(vconf_get_int(lic_key, &lic_val))
	{
        LOGE("vconf_get_int FAIL\n");
	}
	if(lic_val == 0)
	{
		LOGE("License terms not accepted.");
	}
	if (lic_val == 1)
	{*/
		bundle *b = bundle_create();
		bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
		bundle_add(b,"--app-js", "/usr/apps/org.volt.firstscreen/bin/first_screen/app.js");
		bundle_add(b,"--data-path", "/opt/down/panels/firstscreen_temp/");
		bundle_add(b,"--firstscreen", "true");
		startVoltContainerFirstScreen(argc, argv, b);
		bundle_free(b);
//	}
//	LOGE("wainting");
	return 0;
}
