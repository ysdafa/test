/*
 * DepthEffect.cpp
 *
 *  Created on: July 3, 2013
 *      Author: jim dinunzio
 */

#include "DepthEffect.h"

G_DEFINE_TYPE (CDepthEffect, depth_effect, CLUTTER_TYPE_EFFECT);

static void
depth_effect_paint (ClutterEffect *effect, ClutterEffectPaintFlags flags)
{
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (effect));

  bool depthTest = cogl_get_depth_test_enabled();

  if(!depthTest)
  {
    cogl_set_depth_test_enabled(true);
  }

  clutter_actor_continue_paint(actor);

  if (!depthTest)
  {
    cogl_set_depth_test_enabled(depthTest);
  }
}

/* GObject implementation */
static void
depth_effect_dispose (GObject *gobject)
{
  G_OBJECT_CLASS (depth_effect_parent_class)->dispose (gobject);
}


/* GObject class and instance init */
static void
depth_effect_class_init (CDepthEffectClass *klass)
{
  ClutterEffectClass *effect_class = CLUTTER_EFFECT_CLASS (klass);
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  effect_class->paint = depth_effect_paint;
  gobject_class->dispose = depth_effect_dispose;
}


static void
depth_effect_init (CDepthEffect *self)
{
}

/* public API */

/**
 * depth_effect_new:
 *
 * Creates a new #CDepthEffect
 */
ClutterEffect *
depth_effect_new ()
{
  return (ClutterEffect*)g_object_new (TYPE_DEPTH_EFFECT, NULL);
}

#ifndef STAND_ALONE
/* DepthEffect Implementation */

DepthEffect::DepthEffect()
{
  setEffect(depth_effect_new());
}

DepthEffect::~DepthEffect()
{
}

#endif // STAND_ALONE
