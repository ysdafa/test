#include "logger.h"
#include "EmpEngineVolt.h"

#include <string.h>
#include <boost/lexical_cast.hpp>

#include "EmpVolt.h"
#include "event_manager.h"

#include "SefClient.h"
#include "FileIORequest.h"

using namespace volt::util;

namespace sef
{

std::string EmpEngineVolt::LOGGER_NAME = "volt.emp.engine";

std::string EmpEngineVolt::volt_app_data_base_path_ = "/mtd_down/widgets/normal/";

EmpEngineVolt::EmpEngineVolt():
  CEmpEngineBase(), logger_(LOGGER_NAME), log_level_(),
  volt_app_id_(), volt_app_path_(), volt_app_data_path_(), volt_app_name_(),
  volt_app_icon_path_(), volt_app_width_(), volt_app_height_(),
  volt_options_(), thread_(), engine_(VoltEngine::New())
{
  LOG_DEBUG(logger_, "Born");

  static const char *ROOT_OPT = "--root";
  static const char *ROOT_PATH = "/mtd_down/emps/emp" EMP_VOLT_NAME;

  char *dummy = new char[1];
  dummy[0] = '\0';

  char *root_opt = new char[strlen(ROOT_OPT) + 1];
  memmove(root_opt, ROOT_OPT, strlen(ROOT_OPT) + 1);

  char *root = new char[strlen(ROOT_PATH) + 1];
  memmove(root, ROOT_PATH, strlen(ROOT_PATH) + 1);

  volt_options_ = { dummy, root_opt, root };
}

EmpEngineVolt::~EmpEngineVolt()
{
  if (thread_.joinable())
  {
    LOG_DEBUG(logger_, "Joining threads");
    thread_.join(); /* blocks */
    LOG_DEBUG(logger_, "Joined threads");
  }

for (char *option: volt_options_)
  {
    delete [] option;
    option = nullptr;
  }

  volt_options_.clear();

  if (engine_)
  {
    delete engine_;
  }

  engine_ = NULL;

  LOG_DEBUG(logger_, "Dead");
}

void EmpEngineVolt::operator()()
{
  /* Volt thread! */
  pthread_setname_np(pthread_self(), "Volt:Main");

  LOG_DEBUG(logger_, "Starting Volt main");

  MountWidgetImage();

  auto options = volt_options_;

  if (volt_app_name_.empty() == false)
  {
    options.push_back(const_cast<char *>("--app-name"));
    options.push_back(const_cast<char *>(volt_app_name_.c_str()));
  }

  if (volt_app_icon_path_.empty() == false)
  {
    options.push_back(const_cast<char *>("--app-icon"));
    options.push_back(const_cast<char *>(volt_app_icon_path_.c_str()));
  }

  if (volt_app_width_.empty() == false)
  {
    options.push_back(const_cast<char *>("--scene-width"));
    options.push_back(const_cast<char *>(volt_app_width_.c_str()));
  }

  if (volt_app_height_.empty() == false)
  {
    options.push_back(const_cast<char *>("--scene-height"));
    options.push_back(const_cast<char *>(volt_app_height_.c_str()));
  }

  if (volt_app_data_path_.empty() == false)
  {
    options.push_back(const_cast<char *>("--data-path"));
    options.push_back(const_cast<char *>(volt_app_data_path_.c_str()));
  }

  if (log_level_.empty() == false)
  {
    options.push_back(const_cast<char *>("--log-level"));
    options.push_back(const_cast<char *>(log_level_.c_str()));
  }

  options.push_back(const_cast<char *>(volt_app_path_.c_str()));

  if (engine_->ParseOptions(options.size(), options.data()))
  {
    if (engine_->Initialize(options.size(), options.data()))
    {
      if (engine_->Run() == false)
      {
        LOG_WARN(logger_, "Failed to run VoltEngine");
      }
    }
    else
    {
      LOG_WARN(logger_, "Failed to initialize VoltEngine");
    }
  }
  else
  {
    LOG_WARN(logger_, "Failed to parse optins for VoltEngine");
  }

  engine_->Cleanup();

  LOG_DEBUG(logger_, "Volt main completed");

  /* This is for CAppLauncher */
  SendExitEvent();
}

bool EmpEngineVolt::Execute(std::string &aReturn,
                            const std::string &aCmd,
                            const std::string &aParam1,
                            const std::string &aParam2,
                            const std::string &aParam3,
                            const std::string &aParam4)
{
  LOG_DEBUG(logger_,
            "Execute: " << aCmd <<
            " " << aParam1 <<
            " " << aParam2 <<
            " " << aParam3 <<
            " " << aParam4);

  int retval = 0;

  if (aCmd == "HandleRemoteControlEvent" ||
      /* Below are deprecated methods. */
      aCmd == "HandleEvent" || aCmd == "onKeyEvent")
  {
    int type = boost::lexical_cast<int>(aParam1);
    int keycode = boost::lexical_cast<int>(aParam2);

#ifdef EVENT_WEBKIT
    keycode = WebkitToVoltKeyMap::Instance().GetVoltKey(keycode);
    LOG_DEBUG(logger_,
              "Converted webkit key: " << aParam2 << " => " << keycode);

    if (type == 1)
    {
      type = volt::util::EVENT_KEY_PRESS;
    }
    else if (type == 2)
    {
      type = volt::util::EVENT_KEY_RELEASE;
    }

#endif

    EventManager::Instance().HandleEvent(type, keycode);
  }
  else if (aCmd == "HandleRidgeFlick")
  {
    int direction = boost::lexical_cast<int>(aParam1);
    int percentage = boost::lexical_cast<int>(aParam2);

    MOUSE_FLICK flick = EventManager::Instance().VoltFlickEvent(direction);

    if (flick != MOUSE_FLICK_INVALID)
    {
      EventManager::Instance().HandleFlickEvent(flick);
    }
    else
    {
      LOG_WARN(logger_, "Unsupported flick direction: " << direction);
      retval = -1;
    }
  }
  else if (aCmd == "Load")
  {
    /* Load the specified Volt app. */
    volt_app_id_ = aParam1;
    volt_app_path_ = aParam2;
    volt_app_name_ = aParam3;
    volt_app_icon_path_ = aParam4;
    LOG_DEBUG(logger_,"Loading Volt app: " <<
              (volt_app_name_.empty() ? "???" : volt_app_name_) << "@" <<
              volt_app_path_);

    if (volt_app_id_.empty() == false)
    {
      volt_app_data_path_ = volt_app_data_base_path_ + volt_app_id_ + "_data";
    }

    /* Just start the thread here for now...
     * Path to the app is hardcoded in Volt (ie <cwd>/app.js)... */
    thread_= std::thread(std::ref(*this));
  }
  else if (aCmd == "Hide")
  {
    EventManager::Instance().HandleHide();
  }
  else if (aCmd == "Show")
  {
    EventManager::Instance().HandleShow();
  }
  else if (aCmd == "Quit")
  {
    LOG_DEBUG(logger_, "Quitting Volt app");

    if (thread_.joinable())
    {
      if (engine_)
      {
        engine_->Quit();
      }
    }
    else
    {
      LOG_DEBUG(logger_, "Volt thread not running; just send the exit event");
      SendExitEvent();
    }
  }
  else if (aCmd == "Unload")
  {
    /* Unload, do necessary cleanup */
    LOG_DEBUG(logger_, "Unloading Volt app");

    if (thread_.joinable())
    {
      LOG_DEBUG(logger_, "Thread is running, joining...");
      thread_.join();
    }
  }
  else if (aCmd == "Initialize")
  {
    if (aParam1.empty() == false)
    {
      /* Log level */
      log_level_ = aParam1;
    }
  }
  else if (aCmd == "Kill")
  {
    LOG_DEBUG(logger_, "Killing Volt app");

    if (thread_.joinable())
    {
      if (engine_)
      {
        engine_->Quit();
      }
    }
    else
    {
      LOG_DEBUG(logger_, "Volt thread not running; just send the exit event");
      SendExitEvent();
    }
  }
  else if (aCmd == "SetLogLevel")
  {
    if (aParam1.empty() == false)
    {
      /* Log level */
      log_level_ = aParam1;
      LOG_DEBUG(logger_, "Setting log level to " << log_level_);

      /* Is this thread-safe?? */
      Logger::SetLogLevel(Logger::StringToLevel(log_level_.c_str()));
    }
  }
  else
  {
    LOG_WARN(logger_, "Invalid command: " << aCmd);
    retval = -1;
  }

  SetReturnValueInteger(aReturn, retval);
  return true;
}

bool EmpEngineVolt::ExecuteWithParamList(std::string &aReturn,
    const std::string &aCmd,
    const ParamList &aParams)
{
  LOG_DEBUG(logger_,
            "Execute: " << aCmd <<
            " " << aParams.param1 <<
            " " << aParams.param2 <<
            " " << aParams.param3 <<
            " " << aParams.param4 <<
            " " << aParams.param5 <<
            " " << aParams.param6 <<
            " " << aParams.param7 <<
            " " << aParams.param8 <<
            " " << aParams.param9 <<
            " " << aParams.param10);

  int retval = 0;

  /* 11 == strlen("HandleMouse") */
  if (aCmd.compare(0, 11, "HandleMouse") == 0)
  {
    do
    {
      enum EVENT_TYPE type;

      if (aCmd.compare(11, std::string::npos, "ButtonPressed") == 0)
      {
        type = EVENT_MOUSE_PRESS;
      }
      else if (aCmd.compare(11, std::string::npos, "ButtonReleased") == 0)
      {
        type = EVENT_MOUSE_RELEASE;
      }
      else if (aCmd.compare(11, std::string::npos, "Moved") == 0)
      {
        type = EVENT_MOUSE_MOVE;
      }
      else
      {
        LOG_WARN(logger_, "Invalid command: " << aCmd);
        retval = -1;
        break;
      }

      int button = boost::lexical_cast<int>(aParams.param1);
      int x = boost::lexical_cast<int>(aParams.param2);
      int y = boost::lexical_cast<int>(aParams.param3);
#if 0
      /* Not used (they seem to be always 0,0) */
      int delta_x = boost::lexical_cast<int>(aParams.param4);
      int delta_y = boost::lexical_cast<int>(aParams.param5);
#endif

      EventManager::Instance().HandleMouseEvent(type,
          static_cast<MOUSE_BUTTON>(button),
          x, y);
    }
    while(0);
  }
  else if (aCmd == "Load")
  {
    /* Load the specified Volt app. */
    volt_app_id_ = aParams.param1;
    volt_app_path_ = aParams.param2;
    volt_app_name_ = aParams.param3;
    volt_app_icon_path_ = aParams.param4;
    volt_app_width_ = aParams.param5;
    volt_app_height_ = aParams.param6;
    LOG_DEBUG(logger_,"Loading Volt app: " <<
              (volt_app_name_.empty() ? "???" : volt_app_name_) << "@" <<
              volt_app_path_ << " (" << volt_app_width_ << "x" <<
              volt_app_height_ << ")");

    if (volt_app_id_.empty() == false)
    {
      volt_app_data_path_ = volt_app_data_base_path_ + volt_app_id_ + "_data";
    }

    /* Just start the thread here for now...
     * Path to the app is hardcoded in Volt (ie <cwd>/app.js)... */
    thread_= std::thread(std::ref(*this));
  }
  else
  {
    LOG_WARN(logger_, "Invalid command: " << aCmd);
    retval = -1;
  }

  SetReturnValueInteger(aReturn, retval);

  return true;
}

void EmpEngineVolt::SendExitEvent()
{
  if (engine_->ShouldReturnToPrevAppOnExit())
  {
    SendEvent(1, "volt", "return");
  }
  else
  {
    SendEvent(1, "volt", "exit");
  }
}

bool EmpEngineVolt::MountWidgetImage()
{
  /* TODO: Should probably use regex match/capture. */

  static const std::string normal_path = "/mtd_down/widgets/normal/";
  static const std::string image_suffix = "_img";

#if 0
  /* Check if this is a squashfs img. */
#if 0

  /* Temp commenting these out to test mounting from non-normal paths. */
  if (volt_app_path_.compare(0, normal_widget_path.length(), normal_widget_path) != 0 ||
#if 0
      volt_app_path_.compare(volt_app_path_.length() - image_suffix.length(),
                             std::string::npos, image_suffix) != 0 ||
#else
      /* Could be _img or _Img? */
      strcasecmp(volt_app_path_.c_str() + (volt_app_path_.length() - image_suffix.length()),
                 image_suffix.c_str()) != 0 ||
#endif
      volt_app_path_.find('/', normal_widget_path.length()) != std::string::npos)
  {
    /* No need to mount. */
    LOG_DEBUG(logger_, volt_app_path_ << " is not an img path");
    return true;
  }

  std::string widget_id =
    volt_app_path_.substr(normal_widget_path.length(),
                          volt_app_path_.length() - normal_widget_path.length() - image_suffix.length());
#else

  if (strcasecmp(volt_app_path_.c_str() + (volt_app_path_.length() - image_suffix.length()),
                 image_suffix.c_str()) != 0)
  {
    /* No need to mount. */
    LOG_DEBUG(logger_, volt_app_path_ << " is not an img path.");
    return true;
  }

  size_t last_slash = volt_app_path_.rfind('/');

  if (last_slash == std::string::npos)
  {
    LOG_DEBUG(logger_, volt_app_path_ << " is not an img path.");
    return true;
  }

  std::string widget_id =
    volt_app_path_.substr(last_slash + 1,
                          volt_app_path_.length() - last_slash - image_suffix.length() - 1);
#endif
  std::string image_path = volt_app_path_ + "/" + widget_id + ".img";
  /* It seems we can only mount inside the normal path (couldn't mount in the
   * user directory...) */
  std::string mount_path = normal_path + widget_id;

  LOG_DEBUG(logger_, "Widget ID: " << widget_id);
#else
  std::string image_path = volt_app_path_ + "/" + volt_app_id_ + ".img";
  /* It seems we can only mount inside the normal path (couldn't mount in the
   * user directory...) */
  std::string mount_path = normal_path + volt_app_id_;

  LOG_DEBUG(logger_, "Widget ID: " << volt_app_id_);
#endif
  LOG_DEBUG(logger_, "Image path: " << image_path);
  LOG_DEBUG(logger_, "Mount path: " << mount_path);

  if (access(image_path.c_str(), F_OK) == 0)
  {
    std::vector<std::string> args;
    args.push_back(image_path);
    args.push_back(mount_path);
    args.push_back("0");
    args.push_back("Broker");

    /* TODO: Check for errors! */
    SefClient sef;
    sef.Open("Broker", "1.000", "Broker");
    sef.Execute("Mount", args);
    sef.Close();

    /* Need this for decryption. */
    Resource::FileIORequest::SetLicensePath(volt_app_path_ + "/widget.license");

    /* Update the app path to the mounted dir. */
    volt_app_path_ = mount_path;
  }
  else
  {
    LOG_DEBUG(logger_, "Failed to find the img file: " << image_path);
  }

  return true;
}

} /* namespace sef */
