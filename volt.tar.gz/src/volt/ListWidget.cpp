/*
 * ListWidget.cpp
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#include "ListWidget.h"

ListWidget::ListWidget(float x, float y, float width, float height, Widget* parent, Vector2 aSpacing,
                       LayoutOrientation aOrientation)
  : LayoutWidget(x, y, width, height, parent, aOrientation), spacing(aSpacing)
{

  if(width == 0 && height == 0) //Clutter_Flow_Layout has issues with having no dimensions
  {
    setWidth(1);
  }

  layout = clutter_box_layout_new();
  clutter_actor_set_layout_manager (actor, layout);

  setOrientation(aOrientation);
  setSpacing(aSpacing);

}

void ListWidget::setSpacing(Vector2 spacing)
{
  this->spacing = spacing;
  clutter_box_layout_set_spacing(CLUTTER_BOX_LAYOUT (layout), spacing.x);
}

void ListWidget::setOrientation(LayoutOrientation orientation)
{
  if (orientation == LayoutOrientation::Vertical)
  {
    clutter_box_layout_set_orientation (CLUTTER_BOX_LAYOUT (layout), CLUTTER_ORIENTATION_VERTICAL);
  }
  else if(orientation == LayoutOrientation::Horizontal)
  {
    clutter_box_layout_set_orientation (CLUTTER_BOX_LAYOUT (layout), CLUTTER_ORIENTATION_HORIZONTAL);
  }

  this->orientation = orientation;
}

