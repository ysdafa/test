#include <stdlib.h>
#include <clutter-1.0/clutter/clutter.h>
#include <app.h>
#include <appcore-efl.h>
#include <Elementary.h>
#include <Ecore.h>
#include <Ecore_X.h>
#include <Ecore_Evas.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

#include <stdio.h>
#include <dbg.h>
#include<pthread.h>
#include <glib.h>
#include <aul.h>
#include<dlfcn.h>
#include <sharedvc.h>

#include<tv_context.h>
#include<utilX.h>
#include <vconf.h>

#include <halo/HaloBridge.h>

#define LOG_TAG "VC"
#define MAX_NUMBER_OF_AURGUMENTS 20

typedef void(*funcP)();
typedef void(*funcP2)(void*);

static void on_any_notify(void *data, int ev_type, void *event)
{
	XEvent *ev = (XEvent *)event;
	XAnyEvent *anyev = (XAnyEvent *)ev;
	clutter_x11_handle_event(anyev);
}

static void bundle_iterator(const char *aKey, const char *aVal, void *aData);

void parse_bundle(bundle *b)
{
	bundle_iterate(b, bundle_iterator, NULL);
}

static void bundle_iterator(const char *aKey, const char *aVal, void *aData)
{
	LOGE("From Lib: bundle[%s] = %s\n", aKey, aVal);
}


int aArgc;
char *aArgv[MAX_NUMBER_OF_AURGUMENTS];
int launched_via_aul = 0;

int globalargc;
char **globalargv;

__attribute__ ((visibility("default")))
void BundleIterator(const char *aKey, const char *aVal, void *aData)
{
	LOGE("bundle[%s] = %s\n", aKey, aVal);
	if (strncmp(aKey, "--", 2) == 0)
	{
		/* Only using the keys with "--" prefix.
		* This is a work around for the bug in aul_test where it adds extra data
		* to the bundle.  For example, if volt-container is launched like this:
		*   aul_test launch volt-container key1 val1 key2 val2
		* aul_test will put the following key-val pair into the bundle:
		*   key1=>val1, val1=>key2, key2=>val2
		*/
		aArgv[aArgc++] = strdup(aKey);
		aArgv[aArgc++] = strdup(aVal);
	}
}

extern void SetupVDDisplay(void* stage)
{
	LOGE("SetupVDDisplay");
	printf("SetupVDDisplay\n");

	clutter_stage_aux_hint_add((ClutterStage*) stage, "wm.policy.win.zone.desk.layout.mode" , "fullscreen");
}

extern void XRaiseWindowFn(void* stage)
{
	LOGE("XRaiseWindowFn");
	printf("XRaiseWindowFn\n");
}

int change_appinfo_vconf(void *user_data)
{
	LOGD("\nKeycombi recognized!!!!!!!!!\n");

	const char *app_info_key_name="db/volt/app_info";
	int valRuntime=0;

	vconf_set_int(app_info_key_name,true);
	vconf_get_int(app_info_key_name, &valRuntime);
	LOGD("db/volt/app_info = %d", valRuntime);


	return 0; //continue
}

void checkTVContextSeq(void)
{
	char *sequence[5];
	sequence[0] = KEY_MUTE;
	sequence[1] = KEY_MUTE;
	sequence[2] = KEY_VOLUMEUP;
	sequence[3] = KEY_CHANNELUP;
	sequence[4] = KEY_MUTE;
	tvcontext_init();
	tvcontext_listen_sequence_key(sequence, 5, change_appinfo_vconf, NULL);
}

int startVoltContainerFirstScreen(int argc, char **argv, bundle *b)
{
	///
	LOGI("-------------------------elm_init_start------------------");

	globalargc=argc;
	globalargv=argv;
	aArgc = 1;
	aArgv[0]=strdup(argv[0]);

	clutter_x11_set_use_argb_visual(TRUE);

	void *handle;
	int (*runvolt)(int argc, char**argv, int gargc, char**gargv, bundle *b);
	void (*registerHalo)(funcP, funcP, funcP2, funcP2);
	char *error;
	int ret=0;
	int i;

	for (i=0;i<argc;i++)
	{
		LOGE("argv[%d] = %s",i,argv[i]);
		if(strncmp(argv[i], "__AUL_", 6) == 0)
		{
			launched_via_aul = 1;
		}
	}
	bundle *deep_link = bundle_import_from_argv(argc, argv);

	if(launched_via_aul == 1)
	{
		LOGE("Inside aul");
		bundle_iterate(b, BundleIterator, NULL);

		handle=dlopen("/usr/lib/libvoltEngine.so",RTLD_LAZY);
		if(handle)
		{
			runvolt=dlsym(handle,"startvolt");
			registerHalo = dlsym(handle, "register_halo_init_func");
			registerHalo(&RunHalo, &ExitHalo, &SetupVDDisplay, &XRaiseWindowFn);
			
			ret = (*runvolt)(aArgc, aArgv, globalargc, globalargv, deep_link);
			dlclose(handle);
		}
	}
	else
	{
		/* Multi process to create gfx & worker processes */

		handle=dlopen("/usr/lib/libvoltEngine.so",RTLD_LAZY);
		LOGE("Running else");

		if(handle)
		{
			runvolt=dlsym(handle,"startvolt");
			registerHalo = dlsym(handle, "register_halo_init_func");
			registerHalo(&RunHalo, &ExitHalo, &SetupVDDisplay, &XRaiseWindowFn);
			
			ret = (*runvolt)(aArgc, aArgv, globalargc, globalargv, deep_link);
			dlclose(handle);
		}
	}

	LOGE("exiting main");
	return ret;
}


int startVoltContainer(int argc, char **argv, bundle *b)
{
	///
	LOGI("-------------------------elm_init_start------------------");

	// setenv("DISPLAY", ":0", 1);

	globalargc=argc;
	globalargv=argv;
	aArgc = 1;
	aArgv[0]=strdup(argv[0]);

	void *handle;
	int (*runvolt)(int argc, char**argv, int gargc, char**gargv, bundle *b);
	void (*registerHalo)(funcP, funcP, funcP2, funcP2);
	char *error;
	int ret=0;
	int i;

	for (i=0;i<argc;i++)
	{
		LOGE("argv[%d] = %s",i,argv[i]);
		if(strncmp(argv[i], "__AUL_", 6) == 0)
		{
			launched_via_aul = 1;
		}
	}

	bundle *deep_link = bundle_import_from_argv(argc, argv);

	if(launched_via_aul == 1)
	{
		LOGE("Inside aul");
		bundle_iterate(b, BundleIterator, NULL);

		handle=dlopen("/usr/lib/libvoltEngine.so",RTLD_LAZY);

		if(handle)
		{
			runvolt=dlsym(handle,"startvolt");
			registerHalo = dlsym(handle, "register_halo_init_func");
			registerHalo(&RunHalo, &ExitHalo, &SetupVDDisplay, &XRaiseWindowFn);
			
			ret = (*runvolt)(aArgc, aArgv, globalargc, globalargv, deep_link);
			dlclose(handle);
		}
	}
	else
	{
		/* Multi process to create gfx & worker processes */

		handle=dlopen("/usr/lib/libvoltEngine.so",RTLD_LAZY);
		LOGE("Running else");

		if(handle)
		{
			runvolt=dlsym(handle,"startvolt");
			registerHalo = dlsym(handle, "register_halo_init_func");
			registerHalo(&RunHalo, &ExitHalo, &SetupVDDisplay, &XRaiseWindowFn);
			
			ret = (*runvolt)(aArgc, aArgv, globalargc, globalargv, deep_link);
			dlclose(handle);
		}
	}
	LOGE("exiting main");
	return ret;
}

