#include "RuntimeProfile.h"

#include "FileIORequest.h"
#include "logger.h"

#include "AppConfig.h"

namespace po = boost::program_options;

namespace volt
{

static volt::util::Logger LOGGER("volt.profile");

RuntimeProfile::RuntimeProfile():
  profile_options_("Profile Options"), profile_(),
  target_fps_(60), max_cache_size_(50)
{
  profile_options_.add_options()
  ("min-fps",
   po::value<int>()->default_value(60),
   "Min FPS")
  ("max-fps",
   po::value<int>()->default_value(60),
   "Max FPS")
  ("target-fps",
   po::value<int>()->default_value(target_fps_),
   "Target FPS")
  ("max-cache-size",
   po::value<int>()->default_value(max_cache_size_),
   "Max storage allowed for cached data (in MB)")
  ;
}

RuntimeProfile::~RuntimeProfile()
{
}

void RuntimeProfile::SetDeviceProfile(const Environment::DeviceType aDeviceType,
                                      const std::string &aDeviceCode)
{
  const std::string &type = Environment::DeviceTypeToString(aDeviceType);

  LOG_DEBUG(LOGGER, "Setting base profile for device " << type);

  /* Check more specific profile first. */
  std::string prof_path =
    AppConfig::Instance().GetVoltConfigPath() + "/profile/" + type + "." + aDeviceCode + ".profile";
  LOG_DEBUG(LOGGER, "Checking profile: " << prof_path);

  try
  {
    po::store(po::parse_config_file<char>(prof_path.c_str(), profile_options_, true),
              profile_);
  }
  catch (boost::program_options::reading_file &e)
  {
    /* Error reading config (or config file does not exist). */

    /* Check more generic profile. */
    prof_path = AppConfig::Instance().GetVoltConfigPath() + "/profile/" + type + ".profile";
    LOG_DEBUG(LOGGER, "Checking profile: " << prof_path);

    try
    {
      po::store(po::parse_config_file<char>(prof_path.c_str(), profile_options_, true),
                profile_);
    }
    catch (boost::program_options::reading_file &e)
    {
      /* Error reading config (or config file does not exist). */

      /* Check the default profile */
      prof_path = AppConfig::Instance().GetVoltConfigPath() + "/profile/default.profile";
      LOG_DEBUG(LOGGER, "Checking profile: " << prof_path);

      try
      {
        po::store(po::parse_config_file<char>(prof_path.c_str(), profile_options_, true),
                  profile_);
      }
      catch (boost::program_options::reading_file &e)
      {
        /* Error reading config (or config file does not exist). */
        LOG_WARN(LOGGER, "Using default profile");

        po::store(po::command_line_parser(0, NULL).options(profile_options_)
                  .allow_unregistered()
                  .run(),
                  profile_);
      }
    }
  }

  po::notify(profile_);

  target_fps_ = profile_["target-fps"].as<int>();
  LOG_INFO(LOGGER, "target-fps: " << target_fps_);

  max_cache_size_ = profile_["max-cache-size"].as<int>();
  LOG_INFO(LOGGER, "max-cache-size: " << max_cache_size_);
}

} /* end namespace volt */
