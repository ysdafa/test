/*
 * VoltImage.cpp
 *
 *  Created on: July 29, 2013
 *      Author: jim dinunzio
 */

#define CLUTTER_ENABLE_EXPERIMENTAL_API
#define COGL_ENABLE_EXPERIMENTAL_API

#include "VoltImage.h"
#include "VoltActor.h"
#include <cogl/cogl.h>
#include <clutter/clutter.h>
#include <glib/gi18n.h>

/**
 * SECTION:volt-image
 * @Title: VoltImage
 * @Short_Description: Image data content
 *
 * #VoltImage is a #ClutterContent implementation that displays
 * image data.
 *
 */

struct _VoltImagePrivate
{
  CoglTexture *texture;
  GdkPixbufAnimation* pixbufAnim;

  bool useSubtexture;
  float subtexture_x1;
  float subtexture_y1;
  float subtexture_x2;
  float subtexture_y2;
};

static void volt_image_iface_init (ClutterContentIface *iface);

G_DEFINE_TYPE_WITH_CODE (VoltImage, volt_image, G_TYPE_OBJECT,
                         G_IMPLEMENT_INTERFACE(CLUTTER_TYPE_CONTENT,
                             volt_image_iface_init))


/* macro for accessing the object's private structure */
#define VOLT_IMAGE_TYPE_GET_PRIVATE(obj) \
  (G_TYPE_INSTANCE_GET_PRIVATE ((obj), VOLT_TYPE_IMAGE, VoltImagePrivate))

GQuark
volt_image_error_quark (void)
{
  return g_quark_from_static_string ("volt-image-error-quark");
}

static void
volt_image_dispose(GObject* gobject)
{
  VoltImagePrivate* priv = VOLT_IMAGE (gobject)->priv;

  if (priv->pixbufAnim != NULL)
  {
    g_clear_object(&priv->pixbufAnim);
  }

  if (priv->texture != NULL)
  {
    cogl_object_unref (priv->texture);
    priv->texture = NULL;
  }

  /* call the parent class' dispose() method */
  G_OBJECT_CLASS (volt_image_parent_class)->dispose (gobject);
}

static void
volt_image_finalize (GObject *gobject)
{
  /* call the parent class' finalize() method */
  G_OBJECT_CLASS (volt_image_parent_class)->finalize (gobject);
}

static void
volt_image_class_init (VoltImageClass *klass)
{
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  gobject_class->dispose = volt_image_dispose;
  gobject_class->finalize = volt_image_finalize;
  g_type_class_add_private (klass, sizeof (VoltImagePrivate));
}

static void
volt_image_init (VoltImage *self)
{
  VoltImagePrivate *priv;

  priv = self->priv = VOLT_IMAGE_TYPE_GET_PRIVATE (self);
  priv->pixbufAnim = NULL;
  priv->texture = NULL;

  priv->useSubtexture = false;
  priv->subtexture_x1 = 0;
  priv->subtexture_y1 = 0;
  priv->subtexture_x2 = 0;
  priv->subtexture_y2 = 0;
}


// This is a copy of clutter_image_paint_content from clutter-image.c v1-14.2
static void
volt_image_paint_content_common (ClutterContent   *content,
                                 ClutterActor     *actor,
                                 ClutterPaintNode *root)
{
  VoltImagePrivate *priv = VOLT_IMAGE (content)->priv;
  ClutterScalingFilter min_f, mag_f;
  ClutterContentRepeat repeat;
  ClutterPaintNode *node = NULL;
  ClutterActorBox box;
  ClutterColor color;
  guint8 paint_opacity;

  if (priv->texture == NULL)
  {
    return;
  }

  clutter_actor_get_content_box (actor, &box);
  paint_opacity = clutter_actor_get_paint_opacity (actor);
  clutter_actor_get_content_scaling_filters (actor, &min_f, &mag_f);
  repeat = clutter_actor_get_content_repeat (actor);

  color.red = 255;
  color.green = 255;
  color.blue = 255;
  color.alpha = paint_opacity;

  node = clutter_texture_node_new (priv->texture, &color, min_f, mag_f);
  clutter_paint_node_set_name (node, "Image");

  if (repeat == CLUTTER_REPEAT_NONE)
  {
    if (priv->useSubtexture)
    {
      clutter_paint_node_add_texture_rectangle (node, &box,
          priv->subtexture_x1, priv->subtexture_y1,
          priv->subtexture_x2, priv->subtexture_y2);
    }
    else
    {
      clutter_paint_node_add_rectangle(node, &box);
    }
  }
  else
  {
    float t_w = 1.f, t_h = 1.f;

    if ((repeat & CLUTTER_REPEAT_X_AXIS) != FALSE)
    {
      t_w = (box.x2 - box.x1) / cogl_texture_get_width (priv->texture);
    }

    if ((repeat & CLUTTER_REPEAT_Y_AXIS) != FALSE)
    {
      t_h = (box.y2 - box.y1) / cogl_texture_get_height (priv->texture);
    }

    clutter_paint_node_add_texture_rectangle (node, &box,
        0.f, 0.f,
        t_w, t_h);
  }

  clutter_paint_node_add_child (root, node);
  clutter_paint_node_unref (node);
}

/**
 * volt_image_paint_content:
 *
 * Paints the texture of the #VoltImage
 *
 */
static void
volt_image_paint_content (ClutterContent   *content,
                          ClutterActor     *actor,
                          ClutterPaintNode *root)
{
  VoltActor* voltActor = VOLT_ACTOR(actor);
  gboolean hasRoundedCorners = voltActor && volt_actor_get_rounded_corners(voltActor);
  gfloat width, height;
  ClutterActorBox allocation = { 0, };
  ClutterPaintNode *node = NULL;

  // if the actor is a VoltActor and the rounded rect property is true, then
  // add rounded rect clipping node to render graph and the gradient as its child
  if (hasRoundedCorners)
  {
    node = clutter_clip_node_new();
    clutter_paint_node_set_name(node, "Clip");

    clutter_actor_get_allocation_box (actor, &allocation);
    clutter_actor_box_get_size (&allocation, &width, &height);

    CoglPath* path = NULL;
    cogl_path_new();

    if(volt_actor_has_custom_corner(voltActor))
    {
      volt_actor_custom_rounded_rect(voltActor, 0, 0, width, height, 0, false);
    }
    // use standard rounded corners
    else
    {
      cogl_path_round_rectangle (0, 0, width, height,
                                 volt_actor_get_rc_radius(voltActor, VOLT_ACTOR_PROP_RC_RADIUS),
                                 volt_actor_get_rc_arc_step(voltActor, VOLT_ACTOR_PROP_RC_ARC_STEP));
    }

    path = cogl_get_path();
    clutter_paint_node_add_path(node, path);
    clutter_paint_node_add_child (root, node);
    root = node;
  }

  volt_image_paint_content_common(content, actor, root);

  if (node)
  {
    clutter_paint_node_unref (node);
  }
}

static gboolean
volt_image_get_preferred_size (ClutterContent *content,
                               gfloat         *width,
                               gfloat         *height)
{
  VoltImagePrivate *priv = VOLT_IMAGE (content)->priv;

  if (priv->texture == NULL)
  {
    return FALSE;
  }

  if (width != NULL)
  {
    *width = cogl_texture_get_width (priv->texture);
  }

  if (height != NULL)
  {
    *height = cogl_texture_get_height (priv->texture);
  }

  return TRUE;
}

static void
volt_image_iface_init (ClutterContentIface *iface)
{
  iface->get_preferred_size = volt_image_get_preferred_size;
  iface->paint_content = volt_image_paint_content;
}


/**
 * volt_image_new:
 *
 * Creates a new #VoltImage instance.
 *
 * Return value: (transfer full): the newly created #VoltImage instance.
 *   Use g_object_unref() when done.
 *
 */
ClutterContent*
volt_image_new (void)
{
  return CLUTTER_CONTENT(g_object_new (VOLT_TYPE_IMAGE, NULL));
}

/**
 * Returns the GdkPixbufAnimation instance which is used for animated images.
 *
 * @author jim
 *
 * @param self The VoltImage pointer
 *
 * @return GdkPixbufAnimation* the GdkPixbufAnimation valid only if image is animated.
 */
GdkPixbufAnimation*
volt_image_get_pixbuf_anim(VoltImage *self)
{
  g_return_val_if_fail (VOLT_IS_IMAGE(self), NULL);
  VoltImagePrivate *priv = VOLT_IMAGE_TYPE_GET_PRIVATE(self);
  return priv->pixbufAnim;
}

/**
 * Sets the GdkPixbufAnimation pointer which is used for animated images.
 *
 * @author jim
 *
 * @param self The VoltImage pointer
 * @param pixbufAnim The pointer to the GdkPixbufAnimation for the animated image
 */
void
volt_image_set_pixbuf_anim(VoltImage *self, GdkPixbufAnimation* pixbufAnim)
{
  g_return_if_fail (VOLT_IS_IMAGE(self));
  VoltImagePrivate *priv = VOLT_IMAGE_TYPE_GET_PRIVATE(self);

  if (priv->pixbufAnim != pixbufAnim)
  {
    if (priv->pixbufAnim)
    {
      g_object_unref(priv->pixbufAnim);
    }

    priv->pixbufAnim = pixbufAnim;

    if (priv->pixbufAnim)
    {
      g_object_ref(priv->pixbufAnim);
    }
  }
}


/**
 * volt_image_set_data:
 * @image: a #VoltImage
 * @data: (array): the image data, as an array of bytes
 * @pixel_format: the Cogl pixel format of the image data
 * @width: the width of the image data
 * @height: the height of the image data
 * @row_stride: the length of each row inside @data
 * @error: return location for a #GError, or %NULL
 *
 * Sets the image data to be displayed by @image.
 *
 * If the image data was successfully loaded, the @image will be invalidated.
 *
 * In case of error, the @error value will be set, and this function will
 * return %FALSE.
 *
 * The image data is copied in texture memory.
 *
 * Return value: %TRUE if the image data was successfully loaded,
 *   and %FALSE otherwise.
 *
 * Since: 1.10
 */
gboolean
volt_image_set_data (VoltImage     *image,
                     const guint8     *data,
                     CoglTextureFlags  flags,
                     CoglPixelFormat   pixel_format,
                     guint             width,
                     guint             height,
                     guint             row_stride,
                     GError          **error)
{
  g_return_val_if_fail (VOLT_IS_IMAGE (image), FALSE);
  g_return_val_if_fail (data != NULL, FALSE);

  VoltImagePrivate *priv;

  priv = image->priv;

  if (priv->texture != NULL)
  {
    cogl_object_unref (priv->texture);
  }

  priv->texture = cogl_texture_new_from_data (width, height,
                  flags,
                  pixel_format,
                  COGL_PIXEL_FORMAT_ANY,
                  row_stride,
                  data);

  if (priv->texture == NULL)
  {
    g_set_error_literal (error, VOLT_IMAGE_ERROR,
                         VOLT_IMAGE_ERROR_INVALID_DATA,
                         _("Unable to load image data"));
    return FALSE;
  }

  clutter_content_invalidate (CLUTTER_CONTENT (image));

  return TRUE;
}

/**
 * volt_image_set_bytes:
 * @image: a #VoltImage
 * @data: the image data, as a #GBytes
 * @pixel_format: the Cogl pixel format of the image data
 * @width: the width of the image data
 * @height: the height of the image data
 * @row_stride: the length of each row inside @data
 * @error: return location for a #GError, or %NULL
 *
 * Sets the image data stored inside a #GBytes to be displayed by @image.
 *
 * If the image data was successfully loaded, the @image will be invalidated.
 *
 * In case of error, the @error value will be set, and this function will
 * return %FALSE.
 *
 * The image data contained inside the #GBytes is copied in texture memory,
 * and no additional reference is acquired on the @data.
 *
 * Return value: %TRUE if the image data was successfully loaded,
 *   and %FALSE otherwise.
 *
 * Since: 1.12
 */
gboolean
volt_image_set_bytes (VoltImage     *image,
                      GBytes           *data,
                      CoglTextureFlags  flags,
                      CoglPixelFormat   pixel_format,
                      guint             width,
                      guint             height,
                      guint             row_stride,
                      GError          **error)
{
  VoltImagePrivate *priv;

  g_return_val_if_fail (VOLT_IS_IMAGE (image), FALSE);
  g_return_val_if_fail (data != NULL, FALSE);

  priv = image->priv;

  if (priv->texture != NULL)
  {
    cogl_object_unref (priv->texture);
  }

  priv->texture = cogl_texture_new_from_data (width, height,
                  flags,
                  pixel_format,
                  COGL_PIXEL_FORMAT_ANY,
                  row_stride,
                  static_cast<const uint8_t*>(g_bytes_get_data (
                        data, NULL)));

  if (priv->texture == NULL)
  {
    g_set_error_literal (error, VOLT_IMAGE_ERROR,
                         VOLT_IMAGE_ERROR_INVALID_DATA,
                         _("Unable to load image data"));
    return FALSE;
  }

  clutter_content_invalidate (CLUTTER_CONTENT (image));

  return TRUE;
}

/**
 * volt_image_set_area:
 * @image: a #VoltImage
 * @data: (array): the image data, as an array of bytes
 * @pixel_format: the Cogl pixel format of the image data
 * @rect: a rectangle indicating the area that should be set
 * @row_stride: the length of each row inside @data
 * @error: return location for a #GError, or %NULL
 *
 * Sets the image data to be display by @image, using @rect to indicate
 * the position and size of the image data to be set.
 *
 * If the @image does not have any image data set when this function is
 * called, a new texture will be created with the size of the width and
 * height of the rectangle, i.e. calling this function on a newly created
 * #VoltImage will be the equivalent of calling volt_image_set_data().
 *
 * If the image data was successfully loaded, the @image will be invalidated.
 *
 * In case of error, the @error value will be set, and this function will
 * return %FALSE.
 *
 * The image data is copied in texture memory.
 *
 * Return value: %TRUE if the image data was successfully loaded,
 *   and %FALSE otherwise.
 *
 * Since: 1.10
 */
gboolean
volt_image_set_area (VoltImage                 *image,
                     const guint8                 *data,
                     CoglTextureFlags              flags,
                     CoglPixelFormat               pixel_format,
                     const cairo_rectangle_int_t  *area,
                     guint                         row_stride,
                     GError                      **error)
{
  VoltImagePrivate *priv;

  g_return_val_if_fail (VOLT_IS_IMAGE (image), FALSE);
  g_return_val_if_fail (data != NULL, FALSE);
  g_return_val_if_fail (area != NULL, FALSE);

  priv = image->priv;

  if (priv->texture == NULL)
  {
    priv->texture = cogl_texture_new_from_data (area->width,
                    area->height,
                    flags,
                    pixel_format,
                    COGL_PIXEL_FORMAT_ANY,
                    row_stride,
                    data);
  }
  else
  {
    gboolean res;

    res = cogl_texture_set_region (priv->texture,
                                   0, 0,
                                   area->x, area->y,
                                   area->width, area->height,
                                   area->width, area->height,
                                   pixel_format,
                                   row_stride,
                                   data);

    if (!res)
    {
      cogl_object_unref (priv->texture);
      priv->texture = NULL;
    }
  }

  if (priv->texture == NULL)
  {
    g_set_error_literal (error, VOLT_IMAGE_ERROR,
                         VOLT_IMAGE_ERROR_INVALID_DATA,
                         _("Unable to load image data"));
    return FALSE;
  }

  clutter_content_invalidate (CLUTTER_CONTENT (image));

  return TRUE;
}

/**
 * Sets a CoglTexture directly to be used by this image and
 * acquires a ref.
 *
 * @author Reza
 *
 * @param self The VoltImage pointer
 *
 * @param texture The CoglTexture to set
 *
 * @return The texture used by this image
 */
void
volt_image_set_texture(VoltImage *self, CoglTexture* texture)
{
  VoltImagePrivate *priv;

  g_return_if_fail (VOLT_IS_IMAGE (self));
  g_return_if_fail (cogl_is_texture (texture));

  priv = self->priv;

  if (priv->texture != NULL)
  {
    cogl_object_unref (priv->texture);
  }

  priv->texture = texture;
  cogl_object_ref(texture);
  clutter_content_invalidate (CLUTTER_CONTENT (self));
}


/**
 * Returns the CoglTexture instance used for this image.
 *
 * @author jim
 *
 * @param self The VoltImage pointer
 *
 * @return The texture used by this image
 */
CoglTexture *
volt_image_get_texture(VoltImage *self)
{
  g_return_val_if_fail (VOLT_IS_IMAGE (self), FALSE);

  VoltImagePrivate *priv = VOLT_IMAGE_TYPE_GET_PRIVATE(self);
  return priv->texture;
}


/**
 * Returns the CoglTexture instance used for this image.
 *
 * @author Reza
 *
 * @return Sets this VoltImage to use only a portion of the
 */
void
volt_image_set_subtexture_rectangle  (VoltImage                 *self,
                                      float                      x1,
                                      float                      y1,
                                      float                      x2,
                                      float                      y2 )
{
  g_return_if_fail (VOLT_IS_IMAGE (self));

  VoltImagePrivate *priv = self->priv;

  float texWidth = cogl_texture_get_width (priv->texture);
  float texHeight = cogl_texture_get_height (priv->texture);
  priv->useSubtexture = true;
  priv->subtexture_x1 = x1 / texWidth;
  priv->subtexture_y1 = y1 / texHeight;
  priv->subtexture_x2 =  x2 / texWidth;
  priv->subtexture_y2 =  y2 / texHeight;

  clutter_content_invalidate (CLUTTER_CONTENT (self));
}


