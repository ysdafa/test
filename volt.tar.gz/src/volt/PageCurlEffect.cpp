/*
 * PageCurlEffect.cpp
 *
 *  Created on: Jul 1, 2013
 *      Author: reza
 */

#include "PageCurlEffect.h"
#include "VoltActor.h"

const char* PageCurlEffect::PERIOD_TRANSITION_NAME = "pageCurl-period";
const char* PageCurlEffect::RADIUS_TRANSITION_NAME = "pageCurl-radius";
const char* PageCurlEffect::ANGLE_TRANSITION_NAME = "pageCurl-angle";

#define EFFECT_NAME_DEF "page-curl-effect"

const char* PageCurlEffect::EFFECT_NAME = EFFECT_NAME_DEF;

#define GET_EFFECT (CLUTTER_PAGE_TURN_EFFECT(getEffect()))
#define CLUTTER_PAGE_TURN_EFFECT_GET_CLASS(o)   (G_TYPE_INSTANCE_GET_CLASS ((o), CLUTTER_TYPE_PAGE_TURN_EFFECT, ClutterPageTurnEffectClass))

PageCurlEffect::PageCurlEffect(double period = 0, double angle = 20, float radius = 30)
{
  setEffect(clutter_page_turn_effect_new(period, angle, radius));
}

PageCurlEffect::~PageCurlEffect()
{
}

void PageCurlEffect::setAngle(double angle)
{
  // if no animation necessary, just set value, otherwise create implicit transition.
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (getEffect()));

  if (clutter_actor_get_easing_duration(actor) == 0)
  {
    clutter_page_turn_effect_set_angle(GET_EFFECT, angle);
    return;
  }

  const char *prop = "@effects." EFFECT_NAME_DEF ".angle";

  GParamSpec* spec = g_object_class_find_property(
                       G_OBJECT_CLASS(CLUTTER_PAGE_TURN_EFFECT_GET_CLASS(getEffect())),
                       "angle");

  volt_actor_create_transition (VOLT_ACTOR(actor),
                                prop,
                                ANGLE_TRANSITION_NAME,
                                spec,
                                getAngle(),
                                angle);
}


double PageCurlEffect::getAngle() const
{
  return clutter_page_turn_effect_get_angle(GET_EFFECT);
}


void PageCurlEffect::setRadius(float radius)
{
  // if no animation necessary, just set value, otherwise create implicit transition.
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (getEffect()));

  if (clutter_actor_get_easing_duration(actor) == 0)
  {
    clutter_page_turn_effect_set_radius(GET_EFFECT, radius);
    return;
  }

  const char *prop = "@effects." EFFECT_NAME_DEF ".radius";

  GParamSpec* spec = g_object_class_find_property(
                       G_OBJECT_CLASS(CLUTTER_PAGE_TURN_EFFECT_GET_CLASS(getEffect())),
                       "radius");

  volt_actor_create_transition (VOLT_ACTOR(actor),
                                prop,
                                RADIUS_TRANSITION_NAME,
                                spec,
                                getRadius(),
                                radius);

}


float PageCurlEffect::getRadius() const
{
  return clutter_page_turn_effect_get_radius(GET_EFFECT);
}

void PageCurlEffect::setPeriod(double period)
{
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (getEffect()));

  // if no animation necessary, just set value, otherwise create implicit transition.
  if (clutter_actor_get_easing_duration(actor) == 0)
  {
    clutter_page_turn_effect_set_period(GET_EFFECT, period);
    return;
  }

  /* the property we wish to animate; the "@effects" section
   * tells Clutter to check inside the effects associated
   * with the actor; the "page-curl" section is the name of the
   * effect; and the "period" is the name of the property
   * on the effect.
   */
  const char *prop = "@effects." EFFECT_NAME_DEF ".period";

  GParamSpec* spec = g_object_class_find_property(
                       G_OBJECT_CLASS(CLUTTER_PAGE_TURN_EFFECT_GET_CLASS(getEffect())),
                       "period");

  volt_actor_create_transition (VOLT_ACTOR(actor),
                                prop,
                                PERIOD_TRANSITION_NAME,
                                spec,
                                getPeriod(),
                                period);
}


double PageCurlEffect::getPeriod() const
{
  return clutter_page_turn_effect_get_period(GET_EFFECT);
}

