/*
 * DesaturateEffect.cpp
 *
 *  Created on: Aug 6, 2013
 *      Author: Jim DiNunzio
 */

#include "VoltActor.h"
#include "DesaturateEffect.h"

const char* DesaturateEffect::FACTOR_TRANSITION_NAME = "desaturate-factor";

#define EFFECT_NAME_DEF "desaturate-effect"

const char* DesaturateEffect::EFFECT_NAME = EFFECT_NAME_DEF;

#define GET_EFFECT (CLUTTER_DESATURATE_EFFECT(getEffect()))
#define CLUTTER_DESATURATE_EFFECT_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), CLUTTER_TYPE_DESATURATE_EFFECT, ClutterDesaturateEffectClass))


DesaturateEffect::DesaturateEffect()
{
  setEffect(clutter_desaturate_effect_new(0.0));
}


DesaturateEffect::~DesaturateEffect()
{
}

void DesaturateEffect::setFactor(double factor)
{
  // if no animation necessary, just set value, otherwise create implicit transition.
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (getEffect()));

  if (clutter_actor_get_easing_duration(actor) == 0)
  {
    clutter_desaturate_effect_set_factor(GET_EFFECT, factor);
    return;
  }

  const char *prop = "@effects." EFFECT_NAME_DEF ".factor";

  GParamSpec* spec = g_object_class_find_property(
                       G_OBJECT_CLASS(CLUTTER_DESATURATE_EFFECT_GET_CLASS(getEffect())),
                       "factor");

  volt_actor_create_transition (VOLT_ACTOR(actor),
                                prop,
                                FACTOR_TRANSITION_NAME,
                                spec,
                                getFactor(),
                                factor);
}


double DesaturateEffect::getFactor() const
{
  return clutter_desaturate_effect_get_factor(GET_EFFECT);
}

