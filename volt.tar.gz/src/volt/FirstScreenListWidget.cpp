#include <math.h>
#include <map>
#include <string>
#include "FirstScreenListWidget.h"
#include "VoltActor.h"
#include "event_manager.h"
#include "clutter_helper.h"
#include <time.h>
#include <thread>

using namespace std;
using namespace volt::util;
using namespace volt::graphics;

static volt::util::Logger logger;

ClutterActor *contentsList = NULL;
std::map<ClutterActor*, FirstScreenContents*> itemMap;
std::map<std::string, FirstScreenContents*> contentsTagMap;
std::map<ClutterActor*, FirstScreenCategory*> categoryActorMap;
std::map<std::string, FirstScreenCategory*> categoryTagMap;

ClutterActor *live1 = NULL;
ClutterActor *live2 = NULL;
ClutterTimeline *timeline = NULL;

#define EMPTY -10
#define FEATURED_OPEN -11
#define HISTORY_OPEN -12
#define IN_CONTENTS -13
#define FIRST_GAP -14
#define SECOND_GAP -15
#define LEFT_END -16

gfloat Rounding( gfloat x, int digit ) 
{
    return (floor((x) * pow(float(10), digit) + 0.5f ) / pow(float(10), digit) );
}

ClutterActor *mouseArea = NULL;
ClutterActor *bar = NULL;
ClutterActor *check = NULL;
ClutterActor *extend = NULL;
ClutterActor *liveTemp1 = NULL;
ClutterActor *liveTemp2 = NULL;
ClutterActor *appLive[3] = {NULL, NULL, NULL};
ClutterActor *gameLive[3] = {NULL, NULL, NULL};

//ClutterTimeline *timeline = clutter_timeline_new(16);

gfloat SCENE_WIDTH = 1920;
gfloat SCENE_HEIGHT = 1080;

//gfloat ROOT_WIDTH = 1920;
//gfloat ROOT_HEIGHT = 1080;


gfloat   HD_PROPORTION = SCENE_HEIGHT / 1080;
gboolean   REVERSE_OSD = false;

//gfloat WIDGET_HEIGHT = 251;
gfloat WIDGET_HEIGHT = SCENE_WIDTH * 0.130729;
gfloat BOTTOM_HEIGHT = Rounding(SCENE_HEIGHT * 0.046296, 1);
gfloat CONTENTS_IMAGE_HEIGHT = Rounding(SCENE_HEIGHT * 0.160185, 1);
gfloat CATEGORY_GAP =  Rounding(SCENE_WIDTH * 0.015625, 1);
gfloat SCROLL_AREA = 200;

gfloat NORMAL_CATEGORY_WIDTH = Rounding(SCENE_WIDTH * 0.139583, 1);
gfloat FOCUS_CATEGORY_WIDTH = NORMAL_CATEGORY_WIDTH * 1.5;

gfloat NORMAL_CATEGORY_TITLE_WIDTH = NORMAL_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;
gfloat FOCUS_CATEGORY_TITLE_WIDTH = FOCUS_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;

gfloat CATEGORY_TITLE_X = SCENE_WIDTH * 0.015625;
gfloat CATEGORY_TITLE_Y = SCENE_HEIGHT * 0.020370;
gfloat EXTEND_CATEGORY_TITLE_Y = -50;

gfloat CATEGORY_COLOR_HEIGHT = SCENE_HEIGHT * 0.130556;
gfloat CATEGORY_LIVE_HEIGHT = WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT;

gfloat NORMAL_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.090104, 1);
gfloat FOCUS_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.131250, 1);

gfloat NORMAL_CONTENTS_TITLE_WIDTH = NORMAL_CONTENTS_WIDTH - 2 * SCENE_WIDTH * 0.003535;
gfloat FOCUS_CONTENTS_TITLE_WIDTH = FOCUS_CONTENTS_WIDTH;

gfloat CONTENTS_TITLE_X = SCENE_WIDTH * 0.003535;
gfloat CONTENTS_TITLE_Y = SCENE_HEIGHT * 0.016667;

gfloat PROGRESS_HEIGHT = 2;

gfloat ICON_GAP = SCENE_WIDTH * 0.002083;
gfloat ICON_BOTTOM_GAP = SCENE_HEIGHT * 0.004630;
gfloat OPACITY_100 = 255;
gfloat OPACITY_70 = 179;
gfloat OPACITY_15 = 38;
gfloat OPACITY_10 = 25;
gfloat OPACITY_8 = 20;

ClutterColor CATEGOTY_COLOR = {0xC2, 0xC4, 0xC5, 0xFF};
ClutterColor whiteColor = {255, 255, 255, 255};
ClutterColor blackColor = {0, 0, 0, 255};

gfloat cur_x = CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2, 
	   cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;
gfloat goal_x = NORMAL_CATEGORY_WIDTH + 2*CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2,
	   goal_y;
gfloat goal_position = CATEGORY_GAP;
gfloat ratio_point;
gfloat ratio_position;
gfloat velocity = 0;

gfloat verticalDiff = 0.0f;
gfloat liveDiff = 0.0;
gfloat extendDiff = 0.0;
gfloat contentLiveDiff = 0.0;

gfloat scaleFactor[2] = {0, 0};
gfloat curListWidth[2]= {0, 0};
gfloat curCategoryWidth[2] = {0, 0};

gfloat contentLiveScaleX = 0.5;
gfloat contentLiveScaleY = 0.5;

int currentIndex = 0;
int livetick = 0;
int tick = 0;
int contentLiveTick = 0.0;
int extendList = 0;
int currentCategory = 0;
int currentContents = 0;
int extendIndex = 0;
int reduceIndex = 0;
int foveaState = IN_CONTENTS;
bool isOpen[2] = {false, false};

bool KEY_RIGHT = false;
bool KEY_LEFT = false;
bool SCROLL_RIGHT = false;
bool SCROLL_LEFT = false;
bool EVENT_FLAG = true;
bool EXTEND_FLAG = false;
bool REDUCE_FLAG = false;
bool KEY_SELECT = false;
bool ON_TRANSITION = false;
bool STOP_FLAG = false;
bool FOCUS_OPTIONS = false;
bool WHITE_BACKGROUND[2] = {true, false};
bool CONTENT_LIVE_FLAG = false;

int tempcount = 0;
gfloat t_delta_x = 0;
gfloat t_delta_y = 0;
gfloat t_delta_width = 0;
gfloat t_delta_height = 0;
gfloat t_delta_scala_width = 0;
gfloat t_delta_scala_height = 0;
gfloat p_x_title_start = 0;
gfloat p_y_title_start = 0;
gfloat p_y_bar_start = 0;
gfloat p_x_bar_start = 0;

gfloat p_x_start = 0;
gfloat p_y_start = 0;
int count_transition =  0;
int COUNT_TRANSITION_FRAME = 30;
gfloat Diff_transition = 0.0;

gfloat INIT_SPEED = 0;
gfloat INIT_MINSPEED = 5.0;
gfloat INIT_MAXSPEED = 120.0;

gfloat SCALE_SPEED = 0;
gfloat SCALE_MINSPEED = 5.0;
gfloat SCALE_MAXSPEED = 120.0;

gfloat LIMIT_SPEED = 0;
gfloat LIMIT_MINSPEED = 5.0;
gfloat LIMIT_MAXSPEED = 120.0;

gfloat V_t = 0;
gfloat t_t = 0;
gfloat t_scrollout = 0;
gfloat DELAY_TIME = 0.15;
gfloat AUTOSCROLL_TIME = 5.0;

gfloat STOP_LIMITSPEED = 120;
gfloat STOPSCROLL_TIME = 2.0;

bool isOutScroll = false;
time_t mouseMoved = 0;

gfloat extendCurve[4] = {0.3373, 0.0, 0.0, 1.0};
gfloat live[4] = {0.3373, 0.0, 0.0, 1.0};
gfloat hFovea[4] = {0.8, 0.2, 0.2, 0.8};
gfloat vFovea[4] = {0.8, 0.2, 0.2, 0.8};
gfloat contentLive[4] = {0.3373, 0.0, 0.0, 1.0};
gfloat aniTime[5] = {0.5, 2, 6, 60, 120};

long pressTime = 0;
long releaseTime = 0;
bool isPressHold = false;
bool isLongPress = false;
std::thread pressThread;

enum {EXTEND, LIVE_EXCUTE, LIVE_TERM, CONTENT_LIVE_EXCUTE, CONTENT_LIVE_TERM};

FirstScreenListWidget::FirstScreenListWidget(Widget* aParent)
{
	if (aParent->getHeight() != 1080 || aParent->getWidth() != 1920)
	{
		// Need to redefine the values  of global params[shuhao.yan]
		redefineGlobalParams(aParent->getHeight());
	}
	// To define the SCENE WIDTH AGAIN  For 21:9 Feature[shuhao.yan]
	SCENE_WIDTH  = aParent->getWidth();

	// Add a level between scene and Bar widget, To implement the reverse OSD [shuhao.yan]
	SCENEROOT = new  Widget(0, 0, SCENE_WIDTH, SCENE_HEIGHT, aParent);
	SCENEROOT->setPivot(Vector2(0.5, 0.5));

	actor = volt_actor_new();
	init(CATEGORY_GAP, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT, SCENEROOT);
	//volt_actor_set_width(VOLT_ACTOR(actor), SCENE_WIDTH - 2 * CATEGORY_GAP); // [shuhao.yan]
	volt_actor_set_height(VOLT_ACTOR(actor), WIDGET_HEIGHT);
	clutter_actor_set_translation(actor, 0, 0 , 0);

	//clutter_actor_set_reactive(actor, TRUE);
	
	bar = actor;

	ClutterColor color = { 0, 0, 0, 0 };
	
	mouseArea = clutter_rectangle_new_with_color(&color);

    clutter_actor_set_size(mouseArea, SCENE_WIDTH, SCENE_HEIGHT);	
    clutter_actor_set_position(mouseArea, 0, 0);
	clutter_actor_set_reactive (mouseArea, TRUE);
    clutter_actor_add_child(SCENEROOT->getActor(), mouseArea);
}


/*
Need to redefine the global parameters 
To separate FHD ,HD and 21:9 resolution also
[shuhao.yan]
*/
void FirstScreenListWidget::redefineGlobalParams(float scene_height)
{
	SCENE_HEIGHT = scene_height;

	int switchHeight = (int)SCENE_HEIGHT;
	// for 21:9 feature [shuhao.yan] Must use const number
	switch(switchHeight)
	{
		case 720:
			SCENE_WIDTH  = 1280;
			break;
		case 1080:
			SCENE_WIDTH  = 1920;
			break;
		case 2160:
			SCENE_WIDTH  = 3840;
			break;
		default:
			SCENE_WIDTH  = 1920;
	}

	HD_PROPORTION = SCENE_HEIGHT / 1080;

    WIDGET_HEIGHT = SCENE_WIDTH * 0.130729;
    BOTTOM_HEIGHT = Rounding(SCENE_HEIGHT * 0.046296, 1);
    CONTENTS_IMAGE_HEIGHT = Rounding(SCENE_HEIGHT * 0.160185, 1);
    CATEGORY_GAP =  Rounding(SCENE_WIDTH * 0.015625, 1);
    SCROLL_AREA = 200 * HD_PROPORTION;

    NORMAL_CATEGORY_WIDTH = Rounding(SCENE_WIDTH * 0.139583, 1);
    FOCUS_CATEGORY_WIDTH = NORMAL_CATEGORY_WIDTH * 1.5;

    NORMAL_CATEGORY_TITLE_WIDTH = NORMAL_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;
    FOCUS_CATEGORY_TITLE_WIDTH = FOCUS_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;

    CATEGORY_TITLE_X = SCENE_WIDTH * 0.015625;
    CATEGORY_TITLE_Y = SCENE_HEIGHT * 0.020370;
    EXTEND_CATEGORY_TITLE_Y = -50 * HD_PROPORTION;

    CATEGORY_COLOR_HEIGHT = SCENE_HEIGHT * 0.130556;
    CATEGORY_LIVE_HEIGHT = WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT;

    NORMAL_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.090104, 1);
    FOCUS_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.131250, 1);

    NORMAL_CONTENTS_TITLE_WIDTH = NORMAL_CONTENTS_WIDTH - 2 * SCENE_WIDTH * 0.003535;
    FOCUS_CONTENTS_TITLE_WIDTH = FOCUS_CONTENTS_WIDTH;

    CONTENTS_TITLE_X = SCENE_WIDTH * 0.003535;
    CONTENTS_TITLE_Y = SCENE_HEIGHT * 0.016667;

    PROGRESS_HEIGHT = 2;

    ICON_GAP = SCENE_WIDTH * 0.002083;
    ICON_BOTTOM_GAP = SCENE_HEIGHT * 0.004630;
    cur_x = CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2, 
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;
    goal_x = NORMAL_CATEGORY_WIDTH + 2*CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2,
	goal_y;
    goal_position = CATEGORY_GAP;

}

static gfloat x_for_t(gfloat t, gfloat x_1, gfloat x_2)
{
  gfloat omt = 1.0 - t;

  return 3.0 * omt * omt * t * x_1
       + 3.0 * omt * t * t * x_2
       + t * t * t;
}

static gfloat y_for_t(gfloat t, gfloat y_1, gfloat y_2)
{
  gfloat omt = 1.0 - t;

  return 3.0 * omt * omt * t * y_1
       + 3.0 * omt * t * t * y_2
       + t * t * t;
}

static gfloat t_for_x(gfloat x, gfloat x_1, gfloat x_2) 
{
  gfloat min_t = 0, max_t = 1;
  gfloat guess_t, guess_x;
  int i;

  for(i = 0; i < 30; ++i) 
  {
      guess_t = (min_t + max_t) / 2.0;
      guess_x = x_for_t (guess_t, x_1, x_2);

      if (x < guess_x)
        max_t = guess_t;
      else
        min_t = guess_t;
    }

  return (min_t + max_t) / 2.0;
}

static gfloat bezier(gfloat t, gfloat d, gfloat x_1, gfloat y_1, gfloat x_2, gfloat y_2) 
{
  gfloat p = t / d;

  if (p == 0.0)
    return 0.0;

  if (p == 1.0)
    return 1.0;

  return y_for_t (t_for_x (p, x_1, x_2), y_1, y_2);
}

void FirstScreenListWidget::setExtendBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time)
{
	extendCurve[0]=x1;	extendCurve[1]=y1;	extendCurve[2]=x2;	extendCurve[3]=y2;	aniTime[EXTEND]=time/1000.0f;
	
	tick = 0;
}

void FirstScreenListWidget::setLiveImageBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2)
{
	live[0]=x1;	live[1]=y1;	live[2]=x2;	live[3]=y2;	aniTime[LIVE_EXCUTE]=time1/1000.0f;	aniTime[LIVE_TERM]=time2/1000.0f;
	
	livetick = 0;
}

void FirstScreenListWidget::setHorizontalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2)
{
	hFovea[0]=x1;	hFovea[1]=y1;	hFovea[2]=x2;	hFovea[3]=y2;
}

void FirstScreenListWidget::setVerticalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2)
{
	vFovea[0]=x1;	vFovea[1]=y1;	vFovea[2]=x2;	vFovea[3]=y2;	
}

void FirstScreenListWidget::setContentLiveBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2)
{
	contentLive[0]=x1;	contentLive[1]=y1;	contentLive[2]=x2;	contentLive[3]=y2;	aniTime[CONTENT_LIVE_EXCUTE]=time1*0.06f;	aniTime[CONTENT_LIVE_TERM]=time2*0.06f;

	contentLiveTick = 0;
}

int FirstScreenListWidget::returnCategory()
{
	return currentCategory;
}

int FirstScreenListWidget::returnContents()
{
	return currentContents;
}

void FirstScreenListWidget::setFocusById(std::string id)
{
	// do nothing
}

static void createCategory(FirstScreenCategory* Item, ClutterActor* parent)
{
	ClutterColor zeroColor = {0, 0, 0, 0};
	ClutterColor fullColor = {255, 255, 255, 255};
	ClutterColor categoryColor = CATEGOTY_COLOR;

	ClutterActor *current = NULL;
	
	//categoryWrapper
	current = Item->categoryWrapper;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_set_clip_to_allocation(current, TRUE);

	//categoryTitle
	current = Item->categoryTitle;
	
	//clutter_text_set_line_alignment (CLUTTER_TEXT(current), PANGO_ALIGN_LEFT);
	//clutter_text_set_line_wrap(CLUTTER_TEXT(current), true);
	//clutter_actor_set_width(current, NORMAL_CATEGORY_TITLE_WIDTH);
	clutter_actor_set_position(current, (NORMAL_CATEGORY_WIDTH - clutter_actor_get_width(current))/2, EXTEND_CATEGORY_TITLE_Y);
	clutter_actor_set_opacity(current, OPACITY_70);

	// [shuhao.yan]
	if (REVERSE_OSD) // To rotate the latest careated category title
	{
		clutter_actor_set_rotation_angle(current, CLUTTER_Y_AXIS, 180);
	}
	//color
	current = Item->color;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH, CATEGORY_COLOR_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_background_color(current, &fullColor);
	clutter_actor_set_opacity(current, OPACITY_15);

	//liveParent1
	current = Item->liveParent1;
	
	clutter_actor_set_size(current, FOCUS_CATEGORY_WIDTH, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, 0, CATEGORY_COLOR_HEIGHT);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, OPACITY_70);
	clutter_actor_set_pivot_point(current, 0.0, 0.0);
	// [shuhao.yan]
	if (REVERSE_OSD) // To rotate the latest careated category Live One
	{
		clutter_actor_set_rotation_angle(current, CLUTTER_Y_AXIS, 180);
	}

	current = Item->post1;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH/2, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_add_child(Item->liveParent1, current);

	current = Item->post2;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH/2, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, NORMAL_CATEGORY_WIDTH/2, 0);
	clutter_actor_add_child(Item->liveParent1, current);

	current = Item->post3;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH/2, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, NORMAL_CATEGORY_WIDTH, 0);
	clutter_actor_add_child(Item->liveParent1, current);

	//liveParent2
	current = Item->liveParent2;
	
	clutter_actor_set_size(current, FOCUS_CATEGORY_WIDTH, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, FOCUS_CATEGORY_WIDTH, CATEGORY_COLOR_HEIGHT);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, OPACITY_70);
	clutter_actor_set_pivot_point(current, 0.0, 0.0);
	
	// [shuhao.yan]
	if (REVERSE_OSD) // To rotate the latest careated category Live TWO
	{
		clutter_actor_set_rotation_angle(current, CLUTTER_Y_AXIS, 180);
	}
	

	current = Item->post4;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH/2, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_add_child(Item->liveParent2, current);

	current = Item->post5;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH/2, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, NORMAL_CATEGORY_WIDTH/2, 0);
	clutter_actor_add_child(Item->liveParent2, current);

	current = Item->post6;
	
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH/2, CATEGORY_LIVE_HEIGHT);
	clutter_actor_set_position(current, NORMAL_CATEGORY_WIDTH, 0);
	clutter_actor_add_child(Item->liveParent2, current);
	
	//border
	/*current = Item->border;
	
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH - 4, WIDGET_HEIGHT - 4);
	clutter_actor_set_position(current, 2, 2);
	//volt_actor_set_border_color(VOLT_ACTOR(current), borderColor);
	volt_actor_set_border_width(VOLT_ACTOR(current), 2);
	clutter_actor_set_opacity(current, 0);*/
	
	clutter_actor_add_child(Item->categoryWrapper, Item->color);
	clutter_actor_add_child(Item->categoryWrapper, Item->liveParent1);
	clutter_actor_add_child(Item->categoryWrapper, Item->liveParent2);
	clutter_actor_add_child(Item->categoryWrapper, Item->border);

	//border
	ClutterActor *border = NULL;
	
	border = clutter_rectangle_new_with_color (&zeroColor);
	clutter_actor_set_size(border, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(border, 0, 0);
	clutter_rectangle_set_border_width(CLUTTER_RECTANGLE(border), 2);
	clutter_rectangle_set_border_color(CLUTTER_RECTANGLE(border), &fullColor);
	clutter_actor_set_opacity(border, 0);
	
	clutter_actor_replace_child(Item->categoryWrapper, clutter_actor_get_child_at_index(Item->categoryWrapper, 3), border);

	clutter_actor_add_child(parent, Item->categoryWrapper);

	clutter_actor_add_child(parent, Item->categoryTitle);
}

void FirstScreenListWidget::createChild(FirstScreenCategory* Item)
{
	if(clutter_actor_get_n_children(bar) == 0)
	{
		isOpen[0] = true;;
		isOpen[1] = false;
	}
	else
	{
		ClutterActor *temp = clutter_actor_get_child_at_index(bar, 0);

		clutter_actor_set_position(temp, NORMAL_CATEGORY_WIDTH + CATEGORY_GAP, 0);

		isOpen[0] = false;
		isOpen[1] = true;
		
		reduceIndex = 0;
		extendIndex = 1;
		
		cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH/2;
	}

	ClutterActor *child = clutter_actor_new();

	ClutterColor zeroColor = {0, 0, 0, 0};

	clutter_actor_set_size(child, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT);
    clutter_actor_set_position(child, 0, 0);
	clutter_actor_set_background_color(child, &zeroColor);
	clutter_actor_set_opacity(child, 255);

	createCategory(Item, child); 

	ClutterActor *current = Item->listWrapper;

	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
    clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 0);
	clutter_actor_set_pivot_point(current, 0.0, 0.0);

	clutter_actor_add_child(child, current);

	clutter_actor_set_name(child, const_cast<gchar*>(Item->id.c_str()));
	
	clutter_actor_insert_child_at_index(bar, child, 0);
	
	liveTemp1 = clutter_actor_get_child_at_index(bar, 0);
	liveTemp1 = clutter_actor_get_child_at_index(liveTemp1, 0);
	liveTemp1 = clutter_actor_get_child_at_index(liveTemp1, 1);

	liveTemp2 = clutter_actor_get_child_at_index(bar, 0);
	liveTemp2 = clutter_actor_get_child_at_index(liveTemp2, 0);
	liveTemp2 = clutter_actor_get_child_at_index(liveTemp2, 2);

	// insert map
	categoryActorMap.insert(pair<ClutterActor*, FirstScreenCategory*>(Item->categoryWrapper, Item));

	if (!Item->id.empty())
	{
		categoryTagMap.insert(pair<std::string, FirstScreenCategory*>(Item->id, Item));
	}
}

static void toNormalContents(int category, int contents, gfloat init_x)
{
	ClutterActor *temp = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	//barChild
	temp = clutter_actor_get_child_at_index(bar, category);

	//contentsWrapper
	temp = clutter_actor_get_child_at_index(temp, 2);
	temp = clutter_actor_get_child_at_index(temp, contents);

	clutter_actor_set_x(temp, init_x + NORMAL_CONTENTS_WIDTH*contents);
	clutter_actor_set_width(temp, NORMAL_CONTENTS_WIDTH);

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp, 0);

	clutter_actor_set_width(temp2, NORMAL_CONTENTS_WIDTH);
	clutter_actor_set_opacity(temp2, OPACITY_70);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_size(temp3, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_scale(temp3, 1, 1);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
	clutter_actor_set_y(temp3, CONTENTS_IMAGE_HEIGHT);
	
	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	clutter_actor_set_x(temp3, NORMAL_CONTENTS_WIDTH - ICON_GAP - clutter_actor_get_width(temp3));

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 4);

	clutter_actor_set_opacity(temp3, 0);

	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, 1, 1);
		clutter_actor_set_opacity(temp3, 0);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100);
	}
	
	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp, 1);

	clutter_actor_set_y(temp2, CONTENTS_IMAGE_HEIGHT);

	//title1
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_width(temp3, NORMAL_CONTENTS_TITLE_WIDTH);
	clutter_actor_set_x(temp3, CONTENTS_TITLE_X);
	clutter_actor_set_opacity(temp3, OPACITY_70);

	//title2
	temp3 = clutter_actor_get_child_at_index(temp2, 1);
	
	//clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
	clutter_actor_set_x(temp3, (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2);
	clutter_actor_set_opacity(temp3, 0);
	
	//border
	temp3 = clutter_actor_get_child_at_index(temp, 2);

	clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
	clutter_actor_set_opacity(temp3, 0);
	
	//progressN
	
	temp2 = clutter_actor_get_child_at_index(temp, 3);
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	gfloat progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_y(temp2, CONTENTS_IMAGE_HEIGHT - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, 0);
	
		clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_x(temp3, NORMAL_CONTENTS_WIDTH * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}

	// options
	int itemCounts = clutter_actor_get_n_children(temp);
	if (itemCounts > 4)
	{
		ClutterColor normalColor = {10, 10, 10, 255};
		temp2 = clutter_actor_get_child_at_index(temp, 4);
		clutter_actor_set_width(temp2, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_background_color(temp2, &normalColor);
		clutter_actor_set_opacity(temp2, 0);
	}
}

void FirstScreenListWidget::createContents(FirstScreenContents* Item) 
{
	ClutterActor *current = NULL;
	
	int index = Item->index;
	
	ClutterColor zeroColor = {0, 0, 0, 0};
	ClutterColor fullColor = {255, 255, 255, 255};
	ClutterColor overRayColor = {0, 0, 0, 255};
	ClutterColor progressColor = {255, 255, 255, OPACITY_10};
	
	gfloat iconParentWidth1 = 0.0f;
	gfloat iconParentWidth2 = 0.0f;
	gfloat iconParentHeight = 0.0f;

	//contentsWrapper
	current = Item->contentsWrapper;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	//clutter_actor_set_position(current, NORMAL_CONTENTS_WIDTH*index, 0);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 255);
	
	// [shuhao.yan]
	if (REVERSE_OSD) // To rotate the latest careated content
	{
		clutter_actor_set_rotation_angle(current, CLUTTER_Y_AXIS, 180);
	}

	//dominant
	current = Item->dominant;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_background_color(current, Item->dominantColor.toClutterColor());
	clutter_actor_set_opacity(current, OPACITY_70);
	clutter_actor_set_clip_to_allocation(current, TRUE);

	//titleParent
	current = Item->titleParent;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT - CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 255);
	
	//border
	/*current = Item->border;
	
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	//volt_actor_set_border_color(VOLT_ACTOR(current), borderColor);
	volt_actor_set_border_width(VOLT_ACTOR(current), 2);
	clutter_actor_set_opacity(current, 0);*/
	
	//progressP
	current = Item->progressP;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, PROGRESS_HEIGHT);
	clutter_actor_set_position(current, 0, CONTENTS_IMAGE_HEIGHT - PROGRESS_HEIGHT);
	clutter_actor_set_background_color(current, &progressColor);
	clutter_actor_set_opacity(current, 0);
	clutter_actor_set_clip_to_allocation(current, TRUE);

	//progressC
	ClutterActor *progressC = clutter_actor_new();
	
	clutter_actor_set_size(progressC, NORMAL_CONTENTS_WIDTH, PROGRESS_HEIGHT);
	clutter_actor_set_position(progressC, -NORMAL_CONTENTS_WIDTH, 0);
	clutter_actor_set_background_color(progressC, &fullColor);
	clutter_actor_set_opacity(progressC, OPACITY_100);
	clutter_actor_add_child(current, progressC);
	
	//progressN
	ClutterActor *progressN = clutter_actor_new();
	
	clutter_actor_set_x(progressN, 0);
	clutter_actor_set_opacity(progressN, 0);
	clutter_actor_add_child(current, progressN);

	//main
	current = Item->mainWrapper;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_pivot_point(current, 0.0, 0.0);
	clutter_actor_add_child(Item->dominant, current);

	//subMain
	current = Item->subMain;
	
	clutter_actor_set_width(current, 10.0f);
	clutter_actor_add_child(Item->dominant, current);

	//overRay
	current = Item->overRay;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT - CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_background_color(current, &overRayColor);
	clutter_actor_set_opacity(current, OPACITY_8);
	clutter_actor_add_child(Item->dominant, current);

	//iconParent1
	current = Item->iconParent1;
	
	clutter_actor_get_size(current, &iconParentWidth1, &iconParentHeight);
	clutter_actor_set_position(current, NORMAL_CONTENTS_WIDTH - ICON_GAP - iconParentWidth1, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_add_child(Item->dominant, current);

	//iconParent2
	current = Item->iconParent2;
	
	clutter_actor_get_size(current, &iconParentWidth2, &iconParentHeight);
	clutter_actor_set_position(current, FOCUS_CONTENTS_WIDTH - ICON_GAP - iconParentWidth1- iconParentWidth2, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 0);
	clutter_actor_add_child(Item->dominant, current);

	//normalTitle
	current = Item->normalTitle;
	
	//clutter_text_set_line_alignment (CLUTTER_TEXT(current),  PANGO_ALIGN_CENTER);
	//clutter_text_set_line_wrap(CLUTTER_TEXT(current), true);
	//clutter_actor_set_width(current, NORMAL_CONTENTS_TITLE_WIDTH);
	clutter_actor_set_position(current, CONTENTS_TITLE_X, CONTENTS_TITLE_Y);
	clutter_actor_set_opacity(current, OPACITY_70);
	clutter_actor_add_child(Item->titleParent, current);

	//focusTitle
	current = Item->focusTitle;
	
	//clutter_text_set_line_alignment (CLUTTER_TEXT(current),  PANGO_ALIGN_CENTER);
	//clutter_text_set_line_wrap(CLUTTER_TEXT(current), true);
	//clutter_actor_set_width(current, NORMAL_CONTENTS_WIDTH);
	clutter_actor_set_position(current, (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(current))/2, 0);
	clutter_actor_set_opacity(current, 0);
	clutter_actor_add_child(Item->titleParent, current);

	if (Item->haveOptions)
	{
		current = Item->options;
		clutter_actor_set_position(current, 0, -50);
		clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, 40);
		clutter_actor_set_opacity(current, 0);
	}
	
	//main
	current = Item->main;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_set_pivot_point(current, 1.0, 1.0);
	clutter_actor_insert_child_at_index(Item->mainWrapper, current, 2);
	
	clutter_actor_add_child(Item->contentsWrapper, Item->dominant);
	clutter_actor_add_child(Item->contentsWrapper, Item->titleParent);
	clutter_actor_add_child(Item->contentsWrapper, Item->border);
	clutter_actor_add_child(Item->contentsWrapper, Item->progressP);

	if (Item->haveOptions)
	{
		clutter_actor_add_child(Item->contentsWrapper, Item->options);
	}
	
	//border	
	ClutterActor *border = NULL;
	
	border = clutter_rectangle_new_with_color (&zeroColor);
	clutter_actor_set_size(border, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(border, 0, 0);
	clutter_rectangle_set_border_width(CLUTTER_RECTANGLE(border), 2);
	clutter_rectangle_set_border_color(CLUTTER_RECTANGLE(border), &fullColor);
	clutter_actor_set_opacity(border, 0);
	
	clutter_actor_replace_child(Item->contentsWrapper, clutter_actor_get_child_at_index(Item->contentsWrapper, 2), border);
	
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *tempContents = NULL;

	gfloat prev_x = 0.0f;
	gfloat prev_width = NORMAL_CONTENTS_WIDTH;
	gint count = 0;
	gint currentCategory = 0;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		printf("There is no category!!!\n");

		return;
	}
	else if(clutter_actor_get_n_children(bar) == 1)
	{
		currentChild = clutter_actor_get_child_at_index(bar, 0);
		
		childName = clutter_actor_get_name(currentChild);

		currentCategory = 0;

		if(Item->categoryType.compare(childName) != 0)
		{
			printf("There is no such category!!! Check id!!!\n");

			return;
		}

		currentList = clutter_actor_get_child_at_index(currentChild, 2);

		count = clutter_actor_get_n_children(currentList);

		tempContents = clutter_actor_get_child_at_index(currentList, index - 1);

		if(tempContents != NULL)
		{
			prev_x = clutter_actor_get_x(tempContents);
			prev_width = clutter_actor_get_width(tempContents);
		}

		if(index == 0 && count != 0)
		{
			prev_x = 0.0f;
			prev_width = 0.0f;

			toNormalContents(currentCategory, 0, 0);
		}

		for(int i = index; i < count; i++)
		{
			tempContents = clutter_actor_get_child_at_index(currentList, i);

			clutter_actor_set_x(tempContents, prev_x + prev_width + NORMAL_CONTENTS_WIDTH + NORMAL_CONTENTS_WIDTH*(i - index));	
		}
		
		clutter_actor_set_position(Item->contentsWrapper, prev_x + prev_width, 0);

		clutter_actor_insert_child_at_index(currentList, Item->contentsWrapper, index);

		clutter_actor_set_width(currentList, NORMAL_CONTENTS_WIDTH*(count + 1) + FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH);
	}
	else
	{
		currentChild = clutter_actor_get_child_at_index(bar, 0);

		childName = clutter_actor_get_name(currentChild);

		currentCategory = 0;

		if(Item->categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);

			childName = clutter_actor_get_name(currentChild);

			currentCategory = 1;

			if(Item->categoryType.compare(childName) != 0)
			{
				printf("There is no such category!!! Check id!!!\n");

				return;
			}			
		}

		currentList = clutter_actor_get_child_at_index(currentChild, 2);

		count = clutter_actor_get_n_children(currentList);

		tempContents = clutter_actor_get_child_at_index(currentList, index - 1);

		if(tempContents != NULL)
		{
			prev_x = clutter_actor_get_x(tempContents);
			prev_width = clutter_actor_get_width(tempContents);
		}

		if(index == 0 && count != 0)
		{
			prev_x = 0.0f;
			prev_width = 0.0f;

			toNormalContents(currentCategory, 0, 0);
		}

		for(int i = index; i < count; i++)
		{
			tempContents = clutter_actor_get_child_at_index(currentList, i);

			clutter_actor_set_x(tempContents, prev_x + prev_width + NORMAL_CONTENTS_WIDTH + NORMAL_CONTENTS_WIDTH*(i - index));	
		}
		
		clutter_actor_set_position(Item->contentsWrapper, prev_x + prev_width, 0);

		clutter_actor_insert_child_at_index(currentList, Item->contentsWrapper, index);

		clutter_actor_set_width(currentList, NORMAL_CONTENTS_WIDTH*(count + 1) + FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH);
	}

	itemMap.insert(pair<ClutterActor*, FirstScreenContents*>(Item->contentsWrapper, Item));

	if (!Item->id.empty())
	{
		contentsTagMap.insert(pair<std::string, FirstScreenContents*>(Item->id, Item));
	}
}

void FirstScreenListWidget::fallFirstScreen()
{
	STOP_FLAG = true;
	
	EVENT_FLAG = false;
	
	clutter_actor_animate(bar, CLUTTER_EASE_IN_OUT_QUINT, 700, "y", SCENE_HEIGHT + 100, NULL);
	
	clutter_timeline_stop(timeline); 
}

void FirstScreenListWidget::changeIcon(std::string categoryType, int contentsIndex, int number, ClutterActor *newIconParent)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDominant = NULL;
	ClutterActor *iconParent = NULL;
	
	ClutterColor zeroColor = {0, 0, 0, 0};
	
	gfloat iconParentWidth = 0.0f;
	gfloat iconParentHeight = 0.0f;
	
	std::string childName;
	
	if(clutter_actor_get_n_children(bar) == 0)
	{
		printf("There is no category!!!\n");
		
		return;
	}
	else if(clutter_actor_get_n_children(bar) == 1)
	{
		currentChild = clutter_actor_get_child_at_index(bar, 0);
		
		childName = clutter_actor_get_name(currentChild);
		
		if(categoryType.compare(childName) != 0)
		{
			printf("There is no such category!!! Check id!!!\n");
			
			return;
		}
		
		currentList = clutter_actor_get_child_at_index(currentChild, 2);
		
		currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
		
		currentDominant = clutter_actor_get_child_at_index(currentDominant, 0);
		
		if(number == 1)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, 3);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, NORMAL_CONTENTS_WIDTH - ICON_GAP - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 255);
		}
		else if(number == 2)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, 4);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, FOCUS_CONTENTS_WIDTH - ICON_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(newIconParent)) - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 0);
		}
		else
		{
			printf("There is no such iconParent!!! Check number!!!");
		}
	}
	else
	{
		currentChild = clutter_actor_get_child_at_index(bar, 0);
		
		childName = clutter_actor_get_name(currentChild);
		
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);
			
			childName = clutter_actor_get_name(currentChild);
			
			if(categoryType.compare(childName) != 0)
			{
				printf("There is no such category!!! Check id!!!\n");
				
				return;
			}			
		}
		
		currentList = clutter_actor_get_child_at_index(currentChild, 2);
		
		currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
		
		currentDominant = clutter_actor_get_child_at_index(currentDominant, 0);
		
		if(number == 1)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, 3);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, NORMAL_CONTENTS_WIDTH - ICON_GAP - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 255);
		}
		else if(number == 2)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, 4);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, FOCUS_CONTENTS_WIDTH - ICON_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(newIconParent)) - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 0);
		}
		else
		{
			printf("There is no such iconParent!!! Check number!!!");
		}
	}
}

void FirstScreenListWidget::removeCategoryById(std::string id)
{
	FirstScreenCategory* category = NULL;

	map<std::string, FirstScreenCategory*>::iterator tagIt = categoryTagMap.find(id);
	if (tagIt == categoryTagMap.end())
	{
		return;
	}

	category = tagIt->second;
	categoryTagMap.erase(tagIt);

	ClutterActor *removeCategory = category->categoryWrapper;

	// remove from map
	map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(removeCategory);
	if (it != categoryActorMap.end())
	{
		categoryActorMap.erase(it);
	}

	clutter_actor_destroy_all_children(removeCategory);

	clutter_actor_remove_child(bar, removeCategory); 
	
	isOpen[0] = true;
	isOpen[1] = false;
}

void FirstScreenListWidget::removeContents(int categoryIndex, int contentsIndex)
{
	ClutterActor *removeParent = clutter_actor_get_child_at_index(bar, categoryIndex);
	ClutterActor *removeChild = NULL;
	ClutterActor *temp = NULL;

	removeParent = clutter_actor_get_child_at_index(removeParent, 2);
	removeChild = clutter_actor_get_child_at_index(removeParent, contentsIndex);
	
	// remove from map
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(removeChild);
	if (it != itemMap.end())
	{
		FirstScreenContents* ctr = it->second;
		itemMap.erase(it);

		if (ctr != NULL && !ctr->id.empty())
		{
			map<std::string, FirstScreenContents*>::iterator tagIt = contentsTagMap.find(ctr->id);
			if (tagIt != contentsTagMap.end())
			{
				contentsTagMap.erase(tagIt);
			}
		}
	}

	clutter_actor_remove_child(removeParent, removeChild); 

	temp = clutter_actor_get_child_at_index(temp, categoryIndex);
	temp = clutter_actor_get_child_at_index(temp, 2);

	clutter_actor_set_width(temp, clutter_actor_get_width(temp) - NORMAL_CONTENTS_WIDTH);
}

void FirstScreenListWidget::removeContentsById(std::string id)
{
	ClutterActor *removeParent = NULL;
	ClutterActor *removeChild = NULL;
	ClutterActor *temp = NULL;
	
	map<std::string, FirstScreenContents*>::iterator it = contentsTagMap.find(id);
	if (it == contentsTagMap.end())
	{
		return;
	}

	FirstScreenContents* ctr = it->second;

	removeChild = ctr->contentsWrapper;
	removeParent = clutter_actor_get_parent(removeChild);

	contentsTagMap.erase(it);
	
	// remove from map
	map<ClutterActor*, FirstScreenContents*>::iterator actIt = itemMap.find(removeChild);
	if (actIt != itemMap.end())
	{
		itemMap.erase(actIt);
	}

	clutter_actor_remove_child(removeParent, removeChild); 

	/*
	temp = clutter_actor_get_child_at_index(temp, categoryIndex);
	temp = clutter_actor_get_child_at_index(temp, 2);

	clutter_actor_set_width(temp, clutter_actor_get_width(temp) - NORMAL_CONTENTS_WIDTH);
	*/
}

static void toNomralCategory(int index, gfloat init_x)
{
	ClutterActor *temp = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	//barChild
	temp = clutter_actor_get_child_at_index(bar, index);

	clutter_actor_set_width(temp, NORMAL_CATEGORY_WIDTH);
	clutter_actor_set_x(temp, init_x);

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp, 1);

	//clutter_actor_set_width(temp2, NORMAL_CATEGORY_TITLE_WIDTH);
	clutter_actor_set_opacity(temp2, OPACITY_70);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp, 0);

	clutter_actor_set_width(temp2, NORMAL_CATEGORY_WIDTH);

	//color
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	clutter_actor_set_width(temp3, NORMAL_CATEGORY_WIDTH);
	clutter_actor_set_opacity(temp3, OPACITY_15);

	//liveParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	clutter_actor_set_opacity(temp3, OPACITY_70);

	//liveParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_opacity(temp3, OPACITY_70);
	
	//border
	temp3 = clutter_actor_get_child_at_index(temp2, 3);
	clutter_actor_set_width(temp3, NORMAL_CATEGORY_WIDTH);
	clutter_actor_set_opacity(temp3, 0);
}

static void toFocusContents(int categoryIndex, int contentsIndex, gfloat init_x)
{
	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, categoryIndex);

	//clutter_actor_set_x(temp, init_x);

	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, 2);
	temp1 = clutter_actor_get_child_at_index(temp1, contentsIndex);

	clutter_actor_set_width(temp1, FOCUS_CONTENTS_WIDTH);
	clutter_actor_set_x(temp1, init_x + NORMAL_CONTENTS_WIDTH*contentsIndex);

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, FOCUS_CONTENTS_WIDTH);
	clutter_actor_set_opacity(temp2, OPACITY_100);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_size(temp3, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_scale(temp3, FOCUS_CONTENTS_WIDTH / NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT / CONTENTS_IMAGE_HEIGHT);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
	clutter_actor_set_y(temp3, WIDGET_HEIGHT);
	
	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH - ICON_GAP - clutter_actor_get_width(temp3));

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 4);

	clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH - ICON_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(temp3)) - clutter_actor_get_width(temp3));
	clutter_actor_set_opacity(temp3, 255);

	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, FOCUS_CONTENTS_WIDTH / NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT / CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_opacity(temp3, OPACITY_100);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), 0);
	}
	
	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	clutter_actor_set_y(temp2, WIDGET_HEIGHT);

	//title1
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_width(temp3, FOCUS_CONTENTS_TITLE_WIDTH);
	clutter_actor_set_x(temp3, (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2);
	clutter_actor_set_opacity(temp3, 0);

	//title2
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	//clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
	clutter_actor_set_x(temp3, (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2);
	clutter_actor_set_opacity(temp3, OPACITY_100);
	
	//border
	temp3 = clutter_actor_get_child_at_index(temp1, 2);
	
	clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
	clutter_actor_set_opacity(temp3, 255);
	
	//progressN
	temp2 = clutter_actor_get_child_at_index(temp1, 3);
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	gfloat progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, FOCUS_CONTENTS_WIDTH);
		clutter_actor_set_y(temp2, WIDGET_HEIGHT - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, 0);
	
		clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
		clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}
}

static void foveaFeaturedOpen(gfloat diff)
{
	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transCategoryTitleWidth;
	gfloat transCategoryTitleX;
	gfloat transCategoryTitleOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;

	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalCategoryTitleWidth;
	gfloat transVerticalCategoryTitleX;
	gfloat transVerticalCategoryTitleOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	int rightLimit = 0;
	int itemCount = 0;
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;

	////////////////////////////////category fovea//////////////////////////////////
	
	transVerticalWidth = NORMAL_CATEGORY_WIDTH - (NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	//transVerticalCategoryTitleWidth = NORMAL_CATEGORY_TITLE_WIDTH - (NORMAL_CATEGORY_TITLE_WIDTH - FOCUS_CATEGORY_TITLE_WIDTH)*verticalDiff;
	transVerticalCategoryTitleOpacity = OPACITY_15 - (OPACITY_15 - OPACITY_70)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CATEGORY_WIDTH - 4) - ((NORMAL_CATEGORY_WIDTH - 4) - (FOCUS_CATEGORY_WIDTH - 4))*verticalDiff;

	transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CATEGORY_WIDTH)*diff;
	transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
	//transCategoryTitleWidth = transVerticalCategoryTitleWidth - (transVerticalCategoryTitleWidth - NORMAL_CATEGORY_TITLE_WIDTH)*diff;
	transCategoryTitleOpacity = transVerticalCategoryTitleOpacity - (transVerticalCategoryTitleOpacity - OPACITY_15)*diff;
	transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CATEGORY_WIDTH - 4))*diff;
	
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, 0);

	clutter_actor_set_x(temp1, 0);
	clutter_actor_set_width(temp1, transWidth);

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	gfloat normalX = (NORMAL_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2;
	gfloat focusX = (FOCUS_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2;
	
	transVerticalCategoryTitleX = normalX - (normalX - focusX)*verticalDiff;
	transCategoryTitleX = transVerticalCategoryTitleX - (transVerticalCategoryTitleX - normalX)*diff;
	
	clutter_actor_set_x(temp2, transCategoryTitleX);
	//clutter_actor_set_width(temp2, transCategoryTitleWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);

	//color
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_opacity(temp3, transCategoryTitleOpacity);

	//liveParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	clutter_actor_set_opacity(temp3, transOpacity);

	//liveParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_opacity(temp3, transOpacity);
	
	//border
	temp3 = clutter_actor_get_child_at_index(temp2, 3);
	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*verticalDiff);

	////////////////////////////////contents fovea//////////////////////////////////
		
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, 1);
		
	clutter_actor_set_x(temp1, transWidth + CATEGORY_GAP);

	transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
	transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

	transWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - transVerticalWidth)*diff;
	transHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - transVerticalHeight)*diff;
	transOpacity = OPACITY_70 - (OPACITY_70 - transVerticalOpacity)*diff;
	transContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - transVerticalContentsTitleWidth)*diff;
	transBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - transVerticalBorderWidth)*diff;
	transNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - transVerticalNormalTitlePos)*diff;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = OPACITY_70;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = OPACITY_70*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = OPACITY_70 - (OPACITY_70 - OPACITY_70*(1 - 2*diff))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*2*(diff - 0.5)*transVerticalDiff;
		}
	}

	itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(temp1, 2));

	clutter_actor_set_width(temp1, transWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	
	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + clutter_actor_get_width(temp1);
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
	
	clutter_actor_set_x(temp2, title_x);
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, 2);
	temp1 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp1, transWidth);
	clutter_actor_set_x(temp1, 0);

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_size(temp3, transWidth, transHeight);
	clutter_actor_set_scale(temp3, transScaleX, transScaleY);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_y(temp3, transHeight);

	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	transIconPosition = transWidth - ICON_GAP - clutter_actor_get_width(temp3);

	clutter_actor_set_x(temp3, transIconPosition);

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 4);

	if(diff == 1.0f)
	{
		clutter_actor_set_x(temp3, transIconPosition - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
	}
	else
	{
		clutter_actor_set_opacity(temp3, 0);
	}

	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);
		clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
	}
	
	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	clutter_actor_set_y(temp2, transHeight);

	//title1 (normal)
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_width(temp3, transContentsTitleWidth);
	clutter_actor_set_x(temp3, transNormalTitlePos);
	clutter_actor_set_opacity(temp3, transNormalTitleOpt);

	//title2 (focus)
	temp3 = clutter_actor_get_child_at_index(temp2, 1);
	
	contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
	
	transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
	transFocusTitlePos = contentsTitle_x - (contentsTitle_x - transVerticalFocusTitlePos)*diff;

	//clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_x(temp3, transFocusTitlePos);
	clutter_actor_set_opacity(temp3, transFocusTitleOpt);
	
	//border
	temp2 = clutter_actor_get_child_at_index(temp1, 2);
	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, OPACITY_100*diff*verticalDiff);
	
	//progressN
	temp2 = clutter_actor_get_child_at_index(temp1, 3);
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	gfloat progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, 0);
	
		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}

	// options
	int itemCounts = clutter_actor_get_n_children(temp1);
	if (itemCounts > 4)
	{
		temp2 = clutter_actor_get_child_at_index(temp1, 4);
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_opacity(temp2, transFocusTitleOpt);
	}

	////////////////////////////////right contents//////////////////////////////////

	temp1 = clutter_actor_get_child_at_index(bar, 1);
	temp2 = clutter_actor_get_child_at_index(temp1, 2);

	for(int i = 0; i < itemCount; i++)
	{
		temp3 = clutter_actor_get_child_at_index(temp2, i);

		if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
		{
			rightLimit = i;
		
			break;
		}

		if(i == itemCount - 1)
		{
			rightLimit = itemCount - 1;
		}
	}

	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	for(int i = 1; i <= rightLimit + 1; i++)
	{
		if(i > itemCount - 1) 
		{
			return;
		}

		toNormalContents(1, i, clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) - NORMAL_CONTENTS_WIDTH);
	}
}

static void foveaHistoryOpen(gfloat diff)
{
	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transCategoryTitleWidth;
	gfloat transCategoryTitleX;
	gfloat transCategoryTitleOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;

	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalCategoryTitleWidth;
	gfloat transVerticalCategoryTitleX;
	gfloat transVerticalCategoryTitleOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	int leftLimit = 0;
	int itemCount = 0;
	
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;
	
	////////////////////////////////contents fovea//////////////////////////////////

	transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
	transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

	transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CONTENTS_WIDTH)*diff;
	transHeight = transVerticalHeight - (transVerticalHeight - CONTENTS_IMAGE_HEIGHT)*diff;
	transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
	transContentsTitleWidth = transVerticalContentsTitleWidth - (transVerticalContentsTitleWidth - NORMAL_CONTENTS_TITLE_WIDTH)*diff;
	transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CONTENTS_WIDTH - 4))*diff;
	transNormalTitlePos = transVerticalNormalTitlePos - (transVerticalNormalTitlePos - CONTENTS_TITLE_X)*diff;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = OPACITY_70*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = OPACITY_70;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*(1 - 2*diff)*transVerticalDiff;
		}
		else
		{
			transNormalTitleOpt = OPACITY_70 - (OPACITY_70 - OPACITY_70*2*(diff - 0.5))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, 0);

	itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(temp1, 2));

	clutter_actor_set_x(temp1, 0);
	clutter_actor_set_width(temp1, transWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));
	
	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	
	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + clutter_actor_get_width(temp1);
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
	
	clutter_actor_set_x(temp2, title_x);
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, 2);
	temp1 = clutter_actor_get_child_at_index(temp1, itemCount - 1);

	clutter_actor_set_width(temp1, transWidth);
	clutter_actor_set_x(temp1, NORMAL_CONTENTS_WIDTH*(itemCount - 1));

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_size(temp3, transWidth, transHeight);
	clutter_actor_set_scale(temp3, transScaleX, transScaleY);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_y(temp3, transHeight);
	
	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	transIconPosition = transWidth - ICON_GAP - clutter_actor_get_width(temp3);

	clutter_actor_set_x(temp3, transIconPosition);

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 4);

	if(diff == 0.0f)
	{
		clutter_actor_set_x(temp3, transIconPosition - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
	}
	else
	{
		clutter_actor_set_opacity(temp3, 0);
	}
	
	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);
		clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*verticalDiff);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*diff)*verticalDiff);
	}

	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	clutter_actor_set_y(temp2, transHeight);

	//title1 (normal)
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_width(temp3, transContentsTitleWidth);
	clutter_actor_set_x(temp3, transNormalTitlePos);
	clutter_actor_set_opacity(temp3, transNormalTitleOpt);

	//title2 (focus)
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
	
	transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
	transFocusTitlePos = transVerticalFocusTitlePos - (transVerticalFocusTitlePos - contentsTitle_x)*diff;
	
	//clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_x(temp3, transFocusTitlePos);
	clutter_actor_set_opacity(temp3, transFocusTitleOpt);
	
	//border
	temp2 = clutter_actor_get_child_at_index(temp1, 2);
	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, OPACITY_100*(1 - diff)*verticalDiff);
	
	//progressN
	temp2 = clutter_actor_get_child_at_index(temp1, 3);
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	gfloat progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, 0);
	
		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}

	// options
	int itemCounts = clutter_actor_get_n_children(temp1);
	if (itemCounts > 4)
	{
		temp2 = clutter_actor_get_child_at_index(temp1, 4);
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_opacity(temp2, transFocusTitleOpt);
	}

	////////////////////////////////left contents//////////////////////////////////

	for(int i = itemCount - 2; i >= 0; i--)
	{
		if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) - NORMAL_CONTENTS_WIDTH*(itemCount - 1 - i) <= 0 )
		{
			leftLimit = i;

			break;
		}

		if(i == 0)
		{
			leftLimit = 0;
		}
	}

	for(int i = leftLimit; i < itemCount - 1; i++)
	{
		toNormalContents(0, i, 0);
	}

	////////////////////////////////category fovea//////////////////////////////////
	
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, 1);

	clutter_actor_set_x(temp1, clutter_actor_get_width(clutter_actor_get_child_at_index(bar, 0)) + CATEGORY_GAP);

	transVerticalWidth = NORMAL_CATEGORY_WIDTH - (NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	//transVerticalCategoryTitleWidth = NORMAL_CATEGORY_TITLE_WIDTH - (NORMAL_CATEGORY_TITLE_WIDTH - FOCUS_CATEGORY_TITLE_WIDTH)*verticalDiff;
	transVerticalCategoryTitleOpacity = OPACITY_15 - (OPACITY_15 - OPACITY_70)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CATEGORY_WIDTH - 4) - ((NORMAL_CATEGORY_WIDTH - 4) - (FOCUS_CATEGORY_WIDTH - 4))*verticalDiff;

	transWidth = NORMAL_CATEGORY_WIDTH - (NORMAL_CATEGORY_WIDTH - transVerticalWidth)*diff;
	transOpacity = OPACITY_70 - (OPACITY_70 - transVerticalOpacity)*diff;
	//transCategoryTitleWidth = NORMAL_CATEGORY_TITLE_WIDTH - (NORMAL_CATEGORY_TITLE_WIDTH - transVerticalCategoryTitleWidth)*diff;
	transCategoryTitleOpacity = OPACITY_15 - (OPACITY_15 - transVerticalCategoryTitleOpacity)*diff;
	transBorderWidth = (NORMAL_CATEGORY_WIDTH - 4) - ((NORMAL_CATEGORY_WIDTH - 4) - transVerticalBorderWidth)*diff;

	clutter_actor_set_width(temp1, transWidth);

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	
	gfloat normalX = (NORMAL_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2;
	gfloat focusX = (FOCUS_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2;

	transVerticalCategoryTitleX = normalX - (normalX - focusX)*verticalDiff;
	transCategoryTitleX = normalX - (normalX - transVerticalCategoryTitleX)*diff;
	
	clutter_actor_set_x(temp2, transCategoryTitleX);
	//clutter_actor_set_width(temp2, transCategoryTitleWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);

	//color
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_opacity(temp3, transCategoryTitleOpacity);

	//liveParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	clutter_actor_set_opacity(temp3, transOpacity);

	//liveParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_opacity(temp3, transOpacity);
	
	//border
	temp3 = clutter_actor_get_child_at_index(temp2, 3);
	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
}

static void foveaContents(gfloat diff, int index)
{
	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;
	
	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;
	
	gfloat x, y;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	ClutterActor *tempChild = NULL;
	ClutterActor *tempList = NULL;

	int leftLimit = 0;
	int rightLimit = 0;
	int itemCount = 0;
	int tempIndex = 0;
	
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;

	////////////////////////////////left contents fovea//////////////////////////////////

	//barChild
		
	if(currentCategory == 1)	//���ʿ� ī�װ����� �ִ� ���
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, 1);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, 2);
		tempIndex = 1;
	
		itemCount = clutter_actor_get_n_children(temp2);

		clutter_actor_set_x(temp1, NORMAL_CATEGORY_WIDTH + CATEGORY_GAP);

		toNomralCategory(0, 0);
	}
	else	//�����ʿ� ī�װ����� �ְų� ī�װ����� �ϳ��� ���
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, 0);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, 2);
		tempIndex = 0;
	
		itemCount = clutter_actor_get_n_children(temp2);

		clutter_actor_set_x(temp1, 0);

		if(clutter_actor_get_n_children(bar) == 2)
		{
			toNomralCategory(1, clutter_actor_get_width(temp1) + CATEGORY_GAP);
		}
	}

	////////////////////////////////left contents//////////////////////////////////
	
	temp3 = clutter_actor_get_child_at_index(temp2, index - 1);

	for(int i = index - 2; i >= 0; i--)
	{
		if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) - NORMAL_CONTENTS_WIDTH*(index - 1 - i) <= 0 )
		{
			leftLimit = i;

			break;
		}

		if(i == 0)
		{
			leftLimit = 0;
		}
	}

	for(int i = leftLimit; i <= index - 2; i++)
	{
		toNormalContents(tempIndex, i, 0);
	}

	transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
	transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

	transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CONTENTS_WIDTH)*diff;
	transHeight = transVerticalHeight - (transVerticalHeight - CONTENTS_IMAGE_HEIGHT)*diff;
	transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
	transContentsTitleWidth = transVerticalContentsTitleWidth - (transVerticalContentsTitleWidth - NORMAL_CONTENTS_TITLE_WIDTH)*diff;
	transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CONTENTS_WIDTH - 4))*diff;
	transNormalTitlePos = transVerticalNormalTitlePos - (transVerticalNormalTitlePos - CONTENTS_TITLE_X)*diff;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = OPACITY_70*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = OPACITY_70;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*(1 - 2*diff)*transVerticalDiff;
		}
		else
		{
			transNormalTitleOpt = OPACITY_70 - (OPACITY_70 - OPACITY_70*2*(diff - 0.5))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	
	clutter_actor_set_width(temp1, transVerticalWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	
	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + clutter_actor_get_width(temp1);
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
	
	clutter_actor_set_x(temp2, title_x);
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, 2);
	temp1 = clutter_actor_get_child_at_index(temp1, index - 1);

	clutter_actor_set_width(temp1, transWidth);
	clutter_actor_set_x(temp1, NORMAL_CONTENTS_WIDTH*(index - 1));

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_size(temp3, transWidth, transHeight);
	clutter_actor_set_scale(temp3, transScaleX, transScaleY);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_y(temp3, transHeight);
	
	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	transIconPosition = transWidth - ICON_GAP - clutter_actor_get_width(temp3);

	clutter_actor_set_x(temp3, transIconPosition);

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 4);

	if(diff == 0.0f)
	{
		clutter_actor_set_x(temp3, transIconPosition - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
	}
	else
	{
		clutter_actor_set_opacity(temp3, 0);
	}

	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);
		clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*verticalDiff);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*diff)*verticalDiff);
	}
	
	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	clutter_actor_set_y(temp2, transHeight);

	//title1 (normal)
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_width(temp3, transContentsTitleWidth);
	clutter_actor_set_x(temp3, transNormalTitlePos);
	clutter_actor_set_opacity(temp3, transNormalTitleOpt);

	//title2 (focus)
	temp3 = clutter_actor_get_child_at_index(temp2, 1);
	
	contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
	
	transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
	transFocusTitlePos = transVerticalFocusTitlePos - (transVerticalFocusTitlePos - contentsTitle_x)*diff;

	//clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_x(temp3, transFocusTitlePos);
	clutter_actor_set_opacity(temp3, transFocusTitleOpt);
	
	//border
	temp2 = clutter_actor_get_child_at_index(temp1, 2);
	
	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, OPACITY_100*(1 - diff)*verticalDiff);
	
	//progressN
	temp2 = clutter_actor_get_child_at_index(temp1, 3);
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	gfloat progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, 0);
	
		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}

	// options
	int itemCounts = clutter_actor_get_n_children(temp1);
	if (itemCounts > 4)
	{
		temp2 = clutter_actor_get_child_at_index(temp1, 4);
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_opacity(temp2, transFocusTitleOpt);
	}
	
	
	////////////////////////////////right contents fovea//////////////////////////////////

	clutter_actor_get_position(temp1, &x, &y);

	//contentsWrapper
	temp1 = clutter_actor_get_next_sibling(temp1); 

	clutter_actor_set_x(temp1, x + transWidth);

	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;

	transWidth = (transVerticalWidth + NORMAL_CONTENTS_WIDTH) - transWidth;
	transHeight = (transVerticalHeight + CONTENTS_IMAGE_HEIGHT) - transHeight;
	transOpacity = (transVerticalOpacity + OPACITY_70) - transOpacity;       
	transContentsTitleWidth = (transVerticalContentsTitleWidth + NORMAL_CONTENTS_TITLE_WIDTH) - transContentsTitleWidth;
	transBorderWidth = (transVerticalBorderWidth + (NORMAL_CONTENTS_WIDTH - 4)) - transBorderWidth;
	transNormalTitlePos = (transVerticalNormalTitlePos + CONTENTS_TITLE_X) - transNormalTitlePos;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = OPACITY_70;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = OPACITY_70*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = OPACITY_70 - (OPACITY_70 - OPACITY_70*(1 - 2*diff))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*2*(diff - 0.5)*transVerticalDiff;
		}
	}

	clutter_actor_set_width(temp1, transWidth);

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_size(temp3, transWidth, transHeight);
	clutter_actor_set_scale(temp3, transScaleX, transScaleY);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_y(temp3, transHeight);
	
	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	transIconPosition = transWidth - ICON_GAP - clutter_actor_get_width(temp3);

	clutter_actor_set_x(temp3, transIconPosition);

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 4);

	if(diff == 1.0f)
	{
		clutter_actor_set_x(temp3, transIconPosition - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
	}
	else
	{
		clutter_actor_set_opacity(temp3, 0);
	}

	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);
		clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
	}
	
	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	clutter_actor_set_y(temp2, transHeight);

	//title1 (normal)
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_width(temp3, transContentsTitleWidth);
	clutter_actor_set_x(temp3, transNormalTitlePos);
	clutter_actor_set_opacity(temp3, transNormalTitleOpt);

	//title2 (focus)
	temp3 = clutter_actor_get_child_at_index(temp2, 1);
	
	contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
	
	transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
	transFocusTitlePos = contentsTitle_x - (contentsTitle_x - transVerticalFocusTitlePos)*diff;

	//clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_x(temp3, transFocusTitlePos);
	clutter_actor_set_opacity(temp3, transFocusTitleOpt);
	
	//border
	temp2 = clutter_actor_get_child_at_index(temp1, 2);
	
	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, OPACITY_100*diff*verticalDiff);
	
	//progressN
	temp2 = clutter_actor_get_child_at_index(temp1, 3);
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, 0);
	
		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}

	// options
	itemCounts = clutter_actor_get_n_children(temp1);
	if (itemCounts > 4)
	{
		temp2 = clutter_actor_get_child_at_index(temp1, 4);
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_opacity(temp2, transFocusTitleOpt);
	}
	

	////////////////////////////////right contents//////////////////////////////////
	
	for(int i = index; i < itemCount; i++)
	{
		temp3 = clutter_actor_get_child_at_index(tempList, i);

		if(clutter_actor_get_x(bar) + clutter_actor_get_x(tempChild) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
		{
			rightLimit = i;
		
			break;
		}

		if(i == itemCount - 1)
		{
			rightLimit = itemCount - 1;
		}
	}

	if(index == itemCount - 1) 
	{
		return;
	}

	for(int i = index + 1; i <= rightLimit + 1; i++)
	{
		if(i > itemCount - 1) 
		{
			return;
		}

		toNormalContents(tempIndex, i, transVerticalWidth - NORMAL_CONTENTS_WIDTH);
	}
}

void FirstScreenListWidget::addSubMain(std::string categoryType, int contentsIndex, ClutterActor* subMain)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDominant = NULL;
	ClutterActor *currentSubMain = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		printf("There is no category!!!\n");

		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, 0);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			printf("There is no such category!!! Check id!!!\n");

			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, 2);

	currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
	currentDominant = clutter_actor_get_child_at_index(currentDominant, 0);
	
	currentSubMain = clutter_actor_get_child_at_index(currentDominant, 1);

	clutter_actor_set_size(subMain, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(subMain, 0, 0);
	clutter_actor_set_opacity(subMain, 0);
	clutter_actor_set_pivot_point(subMain, 0.0, 0.0);

	clutter_actor_replace_child(currentDominant, currentSubMain, subMain);
}

void FirstScreenListWidget::changeContentLive(std::string categoryType, std::string contentsType, int contentsIndex, int num, ClutterActor* contentLive)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDominant = NULL;
	ClutterActor *currentMain = NULL;

	std::string childName;
	std::string contentName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, 0);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, 2);

	currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
	currentDominant = clutter_actor_get_child_at_index(currentDominant, 0);

	currentMain = clutter_actor_get_child_at_index(currentDominant, 0);

	clutter_actor_set_size(contentLive, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(contentLive, NORMAL_CONTENTS_WIDTH, 0);
	clutter_actor_set_opacity(contentLive, 255);

	contentName = "apps";

	if(contentsType.compare(contentName) == 0)
	{
		if(num == 1)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, 0);
			appLive[1] = contentLive;
		}
		else if(num == 2)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, 1);
			appLive[2] = contentLive;
		}

		appLive[0] = clutter_actor_get_child_at_index(currentMain, 2);
	}
	
	contentName = "games";

	if(contentsType.compare(contentName) == 0)
	{
		if(num == 1)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, 0);
			gameLive[1] = contentLive;
		}
		else if(num == 2)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, 1);
			gameLive[2] = contentLive;
		}

		gameLive[0] = clutter_actor_get_child_at_index(currentMain, 2);
	}
}

void FirstScreenListWidget::setProgress(std::string categoryType, int contentsIndex, gfloat progress)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentProgressN = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		printf("There is no category!!!\n");

		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, 0);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			printf("There is no such category!!! Check id!!!\n");

			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, 2);

	currentProgressN = clutter_actor_get_child_at_index(currentList, contentsIndex);
	currentProgressN = clutter_actor_get_child_at_index(currentProgressN, 3);
	currentProgressN = clutter_actor_get_child_at_index(currentProgressN, 1);

	clutter_actor_set_x(currentProgressN, progress);
}

int FirstScreenListWidget::getCategoryIndexByID(std::string categoryType)
{
	ClutterActor *currentChild = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		printf("There is no category!!!\n");

		return EMPTY;
	}

	currentChild = clutter_actor_get_child_at_index(bar, 0);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			printf("There is no such category!!! Check id!!!\n");

			return EMPTY;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				printf("There is no such category!!! Check id!!!\n");
				
				return EMPTY;
			}		
			else
			{
				return 1;
			}
		}
		else
		{
			return 0;
		}
	}
}

static void cal_mouse_over()
{
	int categoryCount = clutter_actor_get_n_children(bar);
	int over_x = cur_x - clutter_actor_get_x(bar);
	int over_y = cur_y - (SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2);	
	int over_category = 0;
	int over_contents = 0;
	gfloat inputPosition = 0;

	ClutterActor *barTemp = NULL;

	for(int i = 0; i < categoryCount; i++)
	{
		barTemp = clutter_actor_get_child_at_index(bar, i);

		if(over_x <= clutter_actor_get_x(barTemp) + clutter_actor_get_width(barTemp))
		{
			over_category = i;

			break;
		}

		if(i == categoryCount - 1)
		{
			foveaState = EMPTY;

			currentCategory = EMPTY;
			currentContents = EMPTY;

			return;
		}
	}

	if(over_y < 0)
	{
		verticalDiff = 0.0f;
	}
	else if(over_y <= CATEGORY_COLOR_HEIGHT/2)
	{	
		inputPosition = over_y / (CATEGORY_COLOR_HEIGHT/2);

		verticalDiff = bezier(inputPosition, 1.0f, vFovea[0], vFovea[1], vFovea[2], vFovea[3]);
	}
	else if(over_y <= WIDGET_HEIGHT + CATEGORY_COLOR_HEIGHT/2)
	{
		verticalDiff = 1.0f;
	}
	else
	{
		over_y -= (WIDGET_HEIGHT+ CATEGORY_COLOR_HEIGHT/2);

		inputPosition = 1 - (over_y / BOTTOM_HEIGHT);

		verticalDiff = bezier(inputPosition, 1.0f, vFovea[0], vFovea[1], vFovea[2], vFovea[3]);
	}

	if(isOpen[over_category])	//���� ī�װ����� �����ִ� ���
	{
		barTemp = clutter_actor_get_child_at_index(bar, over_category);	//���� ������ ���ϵ�

		ClutterActor *listWrapper = clutter_actor_get_child_at_index(barTemp, 2);
		
		int itemCount = clutter_actor_get_n_children(listWrapper);	//���� ������ �������� ���ϵ� ��

		if(over_x < clutter_actor_get_x(barTemp) + FOCUS_CONTENTS_WIDTH/2)	//���� �� �κ�
		{
			foveaState = EMPTY;

			if(over_x >= clutter_actor_get_x(barTemp))	//�����Ͱ� ������ ���ο� �ִ� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = FEATURED_OPEN;
				}
				else
				{
					foveaState = LEFT_END;
				}
				
				currentCategory = over_category;
				currentContents = 0;
			}
			else	//�����Ͱ� ������ ���ο� ���� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = FIRST_GAP;
				}

				currentCategory = EMPTY;
				currentContents = EMPTY;
			}
		}
		else if(over_x >= clutter_actor_get_x(barTemp) + FOCUS_CONTENTS_WIDTH/2 + NORMAL_CONTENTS_WIDTH*(itemCount-1))	//������ �� �κ�
		{
			foveaState = EMPTY;

			currentCategory = over_category;
			currentContents = itemCount - 1;

			if(over_category == 0 && categoryCount == 2)	//�����ʿ� ī�װ��� ����
			{
				foveaState = HISTORY_OPEN;
			}
		}
		else	//������ ����
		{
			ClutterActor *sibling = NULL;

			foveaState = IN_CONTENTS;

			currentIndex = (int)((over_x - clutter_actor_get_x(barTemp) - FOCUS_CONTENTS_WIDTH/2)/NORMAL_CONTENTS_WIDTH) + 1; 

			currentCategory = over_category;

			for(int i = 0; i <= currentIndex; i++)
			{
				sibling = clutter_actor_get_child_at_index(listWrapper, i - 1);

				if(over_x - clutter_actor_get_x(barTemp) > NORMAL_CONTENTS_WIDTH*(i - 1) + clutter_actor_get_width(sibling))
				{
					currentContents = i;
				}
			}
		}
	}
	else	//���� ī�װ����� �����ִ� ���
	{
		if(over_x <= clutter_actor_get_x(barTemp) + FOCUS_CATEGORY_WIDTH/2)	//������ ���
		{
			foveaState = EMPTY;

			if(over_x >= clutter_actor_get_x(barTemp))	//�����Ͱ� ī�װ��� ���ο� �ִ� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = HISTORY_OPEN;
				}
				else
				{
					foveaState = LEFT_END;
				}
				
				currentCategory = over_category;
				currentContents = EMPTY;
			}
			else	//�����Ͱ� ī�װ��� ���ο� ���� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = SECOND_GAP;
				}

				currentCategory = EMPTY;
				currentContents = EMPTY;
			}
		}
		else	//�������� ���
		{
			foveaState = EMPTY;

			currentCategory = over_category;
			currentContents = EMPTY;

			if(over_category == 0)	//�����ʿ� ī�װ��� ����
			{
				foveaState = FEATURED_OPEN;
			}
		}
	}
}

static void move_rect() 
{      
	ClutterActor *barTemp = NULL;
	gfloat center = 0;
	gfloat inputPosition;
	gfloat diff;
	gfloat move_x = cur_x - clutter_actor_get_x(bar);

	cal_mouse_over();

	if(foveaState == IN_CONTENTS)
	{
		barTemp = clutter_actor_get_child_at_index(bar, currentCategory);

		center = clutter_actor_get_x(barTemp) + FOCUS_CONTENTS_WIDTH/2 + NORMAL_CONTENTS_WIDTH*(currentIndex-1);
		
		inputPosition = abs(move_x - center) / NORMAL_CONTENTS_WIDTH;

		diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

		foveaContents(diff, currentIndex);
	}
	else if(foveaState == EMPTY)
	{
		return;
	}
	else if(foveaState == FEATURED_OPEN)
	{
		barTemp = clutter_actor_get_child_at_index(bar, 0);

		center = FOCUS_CATEGORY_WIDTH/2;

		gfloat range = NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH/2 + FOCUS_CONTENTS_WIDTH/2 + CATEGORY_GAP; 
	
		inputPosition = abs(move_x - center) / range;

		diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);
		
		foveaFeaturedOpen(diff);
		
		/*barTemp = clutter_actor_get_child_at_index(bar, 0);

		center = FOCUS_CATEGORY_WIDTH/2;

		gfloat range = NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH/2 + FOCUS_CONTENTS_WIDTH/2; 
	
		if(move_x >= clutter_actor_get_width(barTemp) + CATEGORY_GAP)
		{
			inputPosition = abs(move_x - CATEGORY_GAP - center) / range;
		}
		else
		{
			inputPosition = abs(move_x - center) / range;
		}

		diff = bezier(inputPosition, 1.0f, 0.8f, 0.0f, 0.2f, 1.0f);

		foveaFeaturedOpen(diff);*/	
	}
	else if(foveaState == HISTORY_OPEN)
	{
		barTemp = clutter_actor_get_child_at_index(bar, 0);

		ClutterActor *listWrapper = clutter_actor_get_child_at_index(barTemp, 2);

		int itemCount = clutter_actor_get_n_children(listWrapper);

		center = FOCUS_CONTENTS_WIDTH/2 + NORMAL_CONTENTS_WIDTH*(itemCount-1);

		gfloat range = NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH/2 + FOCUS_CATEGORY_WIDTH/2; 

		barTemp = clutter_actor_get_child_at_index(bar, 1);
	
		if(move_x >= clutter_actor_get_x(barTemp))
		{
			inputPosition = abs(move_x - CATEGORY_GAP - center) / range;
		}
		else
		{
			inputPosition = abs(move_x - center) / range;
		}

		diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

		foveaHistoryOpen(diff);
	}
	else if(foveaState == FIRST_GAP)
	{
		barTemp = clutter_actor_get_child_at_index(bar, 0);

		center = FOCUS_CATEGORY_WIDTH/2;

		gfloat range = NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH/2 + FOCUS_CONTENTS_WIDTH/2 + CATEGORY_GAP; 
	
		inputPosition = abs(move_x - center) / range;

		diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);
		
		foveaFeaturedOpen(diff);
		
		//return;
	}
	else if(foveaState == LEFT_END)
	{
		if(isOpen[currentCategory])
		{
			diff = bezier(0.0f, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

			foveaContents(diff, 1);
			
			//printf("Left end Contents");
		}
		else
		{
			diff = bezier(0.0f, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

			foveaFeaturedOpen(diff);
			
			//printf("Left end Category");
		}
	}
	else
	{
		return;
	}
}

void FirstScreenListWidget::setFocus(int contentsIndex)
{
	if(KEY_SELECT) {
		return;
	}

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;

	EVENT_FLAG = false;

	gfloat posLeft = 0.0f;
	gfloat posRight = 0.0f;

	posLeft = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex;
	posRight = posLeft + FOCUS_CONTENTS_WIDTH;

	if(posLeft <= 0)
	{
		goal_position = -(NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex) + CATEGORY_GAP;
		clutter_actor_set_x(bar, goal_position);
	}
	
	if(posRight >= SCENE_WIDTH)
	{
		goal_position = -(NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex) + CATEGORY_GAP;
		clutter_actor_set_x(bar, goal_position);
	}
	
	cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex + FOCUS_CONTENTS_WIDTH/2;

	move_rect();

	EVENT_FLAG = true;

}

static bool setenterOptions()
{
	if (!FOCUS_OPTIONS)
	{
		return false;
	}

	bool haveOptions = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * options = NULL;
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		haveOptions = ctr->haveOptions; 
	}
	else
	{
		return false;
	}
	
	if (haveOptions)
	{	
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->enterOptionsCallback.invoke(arr);
		
		ClutterColor unfocusColor = {10, 10, 10, 255};
		options = clutter_actor_get_child_at_index(contentWrapper, 4);
		clutter_actor_set_background_color(options, &unfocusColor);
	}
	else
	{
		return false;
	}

	STOP_FLAG = true;
	FOCUS_OPTIONS = false;

	return true;
}

static bool setfocusOptions()
{
	if (FOCUS_OPTIONS)
	{
		return false;
	}

	bool haveOptions = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * options = NULL;
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		haveOptions = ctr->haveOptions; 
	}

	if (STOP_FLAG)
	{
		STOP_FLAG = false;
	}
	
	if (haveOptions)
	{	
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->focusOptionsCallback.invoke(arr);
	
		ClutterColor focusColor = {0, 200, 150, 255};
		options = clutter_actor_get_child_at_index(contentWrapper, 4);
		clutter_actor_set_background_color(options, &focusColor);
		
		FOCUS_OPTIONS = true;

		return true;
	}
	else
	{	
		return false;
	}
}

static void setunfocusOptions()
{
	if (!FOCUS_OPTIONS)
	{
		return;
	}

	bool haveOptions = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * options = NULL;
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		haveOptions = ctr->haveOptions; 
	}
	
	if (haveOptions)
	{	
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->unfocusOptionsCallback.invoke(arr);
		
		ClutterColor unfocusColor = {10, 10, 10, 255};
		options = clutter_actor_get_child_at_index(contentWrapper, 4);
		clutter_actor_set_background_color(options, &unfocusColor);
	}
	
	
	FOCUS_OPTIONS = false;	
}

bool FirstScreenListWidget::focusOptions()
{
	return setfocusOptions();
}

void FirstScreenListWidget::unfocusOptions()
{
	setunfocusOptions();
}

bool FirstScreenListWidget::enterOptions()
{
	return setenterOptions();
}


static void extendCategory(int index)
{
	extendIndex = index;

	int itemCount = 0;

	ClutterActor *temp = clutter_actor_get_child_at_index(bar, extendIndex);

	curCategoryWidth[extendIndex] = clutter_actor_get_width(temp);

	ClutterActor* categoryWrapper = clutter_actor_get_child_at_index(temp, 0);;
	// extend
	map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(categoryWrapper);
	FirstScreenCategory* ctr = NULL;

	if (it != categoryActorMap.end())
	{
		ctr = it->second;
	}
	else
	{
		printf("Can not find category wrapper idx: %d\n", extendIndex);
	}

	temp = clutter_actor_get_child_at_index(temp, 2);

	itemCount = clutter_actor_get_n_children(temp);

	toFocusContents(extendIndex, 0, 0);

	for(int i = 1; i< itemCount; i++)
	{
		toNormalContents(extendIndex, i, FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH);
	}

	curListWidth[extendIndex] = clutter_actor_get_width(temp);

	scaleFactor[extendIndex] = curCategoryWidth[extendIndex] / curListWidth[extendIndex];

	clutter_actor_set_scale(temp, scaleFactor[extendIndex], 1);

	//cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 200;

	EXTEND_FLAG = true;

	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);

		ctr->onExtendCallback.invoke(arr);
	}
}

static void extendEffect()
{
	gfloat transWidth;
	gfloat transOpacity;
	gfloat transScale;
	gfloat transPosition;
	gfloat transTitlePosition;
	gfloat transBorderWidth;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;

	///////////////////////////////////////////////category//////////////////////////////////////////////////////

	transWidth = curCategoryWidth[extendIndex] - (curCategoryWidth[extendIndex] - curListWidth[extendIndex])*extendDiff;
	transOpacity = OPACITY_100*(1 - extendDiff);
	transScale = 1 - (1 - curListWidth[extendIndex]/curCategoryWidth[extendIndex])*extendDiff;
	transPosition = CATEGORY_TITLE_Y - (CATEGORY_TITLE_Y - EXTEND_CATEGORY_TITLE_Y)*extendDiff;
	transBorderWidth = (curCategoryWidth[extendIndex] - 4) - ((curCategoryWidth[extendIndex] - 4) - (curListWidth[extendIndex] - 4))*extendDiff;

	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, extendIndex);

	clutter_actor_set_width(temp1, transWidth);

	if(extendIndex == 0 && clutter_actor_get_next_sibling(temp1) != NULL)
	{
		clutter_actor_set_x(clutter_actor_get_next_sibling(temp1), transWidth + CATEGORY_GAP);
	}

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + curListWidth[extendIndex];
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);

	transTitlePosition = (FOCUS_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2 - ((FOCUS_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2 - title_x)*extendDiff;
	
	clutter_actor_set_x(temp2, transTitlePosition);	
	//clutter_actor_set_y(temp2, transPosition);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//color
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	clutter_actor_set_width(temp3, transWidth);

	//liveParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	clutter_actor_set_scale(temp3, transScale, 1);

	//liveParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_scale(temp3, transScale, 1);
	clutter_actor_set_x(temp3, FOCUS_CATEGORY_WIDTH*transScale);
	
	//border
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	clutter_actor_set_width(temp3, transBorderWidth);
	clutter_actor_set_opacity(temp3, transOpacity);

	///////////////////////////////////////////////contents//////////////////////////////////////////////////////

	transScale = scaleFactor[extendIndex] - (scaleFactor[extendIndex] - 1)*extendDiff;
	transOpacity = OPACITY_100*extendDiff;

	//listWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, 2);

	clutter_actor_set_scale(temp2, transScale, 1);
	clutter_actor_set_opacity(temp2, transOpacity);
}

static void reduceCategory(int index)
{
	reduceIndex = index;

	ClutterActor *temp = clutter_actor_get_child_at_index(bar, reduceIndex);
	
	curListWidth[reduceIndex] = clutter_actor_get_width(temp);

	scaleFactor[reduceIndex] = NORMAL_CATEGORY_WIDTH / curListWidth[reduceIndex];
	
	if(clutter_actor_get_n_children(bar) == 2)
	{
		if(reduceIndex == 0)
		{
			liveTemp1 = clutter_actor_get_child_at_index(bar, 0);
			liveTemp1 = clutter_actor_get_child_at_index(liveTemp1, 0);
			liveTemp1 = clutter_actor_get_child_at_index(liveTemp1, 1);

			liveTemp2 = clutter_actor_get_child_at_index(bar, 0);
			liveTemp2 = clutter_actor_get_child_at_index(liveTemp2, 0);
			liveTemp2 = clutter_actor_get_child_at_index(liveTemp2, 2);
		}
		else
		{
			liveTemp1 = clutter_actor_get_child_at_index(bar, 1);
			liveTemp1 = clutter_actor_get_child_at_index(liveTemp1, 0);
			liveTemp1 = clutter_actor_get_child_at_index(liveTemp1, 1);

			liveTemp2 = clutter_actor_get_child_at_index(bar, 1);
			liveTemp2 = clutter_actor_get_child_at_index(liveTemp2, 0);
			liveTemp2 = clutter_actor_get_child_at_index(liveTemp2, 2);
		}
	}
	
	temp = clutter_actor_get_child_at_index(temp, 2);

	int itemCount = clutter_actor_get_n_children(temp);

	temp = clutter_actor_get_child_at_index(temp, 0);

	for(int i = 1; i< itemCount; i++)
	{
		toNormalContents(reduceIndex, i, clutter_actor_get_width(temp) - NORMAL_CONTENTS_WIDTH);
	}

	REDUCE_FLAG = true;
}

static void reduceEffect()
{
	gfloat transWidth;
	gfloat transOpacity;
	gfloat transScale;
	gfloat transPosition;
	gfloat transTitlePosition;
	gfloat transBorderWidth;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;

	///////////////////////////////////////////////category//////////////////////////////////////////////////////

	transWidth = curListWidth[reduceIndex] - (curListWidth[reduceIndex] - NORMAL_CATEGORY_WIDTH)*extendDiff;
	transOpacity = OPACITY_100*extendDiff;
	transScale = curListWidth[reduceIndex]/NORMAL_CATEGORY_WIDTH - (curListWidth[reduceIndex]/NORMAL_CATEGORY_WIDTH - 1)*extendDiff;
	transPosition = EXTEND_CATEGORY_TITLE_Y - (EXTEND_CATEGORY_TITLE_Y - CATEGORY_TITLE_Y)*extendDiff;
	transBorderWidth = (curListWidth[reduceIndex] - 4) - ((curListWidth[reduceIndex] - 4) - (NORMAL_CATEGORY_WIDTH - 4))*extendDiff;

	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);

	clutter_actor_set_width(temp1, transWidth);

	if(reduceIndex == 0 && clutter_actor_get_next_sibling(temp1) != NULL)
	{
		clutter_actor_set_x(clutter_actor_get_next_sibling(temp1), transWidth + CATEGORY_GAP);
	}

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + curListWidth[reduceIndex];
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
	
	transTitlePosition = title_x - (title_x - (NORMAL_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2)*extendDiff;
	
	clutter_actor_set_x(temp2, transTitlePosition);
	//clutter_actor_set_y(temp2, transPosition);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, transOpacity);

	//color
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	clutter_actor_set_width(temp3, transWidth);

	//liveParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	clutter_actor_set_scale(temp3, transScale, 1);

	//liveParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_scale(temp3, transScale, 1);
	clutter_actor_set_x(temp3, FOCUS_CATEGORY_WIDTH*transScale);
	
	//border
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	clutter_actor_set_width(temp3, transBorderWidth);

	///////////////////////////////////////////////contents//////////////////////////////////////////////////////

	transScale = 1 - (1 - scaleFactor[reduceIndex])*extendDiff;
	transOpacity = OPACITY_100*(1 - extendDiff);

	//listWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, 2);

	clutter_actor_set_scale(temp2, transScale, 1);
	clutter_actor_set_opacity(temp2, transOpacity);
}

void FirstScreenListWidget::removeCategory(int categoryIndex)
{
	EVENT_FLAG = false;

	ClutterActor *removeCategory = clutter_actor_get_child_at_index(bar, categoryIndex);

	// remove from map
	map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(removeCategory);
	if (it != categoryActorMap.end())
	{
		std::string id = it->second->id;
		categoryActorMap.erase(it);

		if (!id.empty())
		{
			map<std::string, FirstScreenCategory*>::iterator tagIt = categoryTagMap.find(id);
			if (tagIt != categoryTagMap.end())
			{
				categoryTagMap.erase(tagIt);
			}
		}
	}

	clutter_actor_destroy_all_children(removeCategory);

	clutter_actor_remove_child(bar, removeCategory); 
	
	extendCategory(0);	
	
	isOpen[0] = true;
	isOpen[1] = false;

}


static void extendAnimation()
{
	EVENT_FLAG = false;

	ClutterActor *child1 = clutter_actor_get_child_at_index(bar, 0);
	ClutterActor *child2 = clutter_actor_get_child_at_index(bar, 1);

	clutter_actor_set_x(child2, 0);
	clutter_actor_set_x(child1, clutter_actor_get_width(child2) + CATEGORY_GAP);

	clutter_actor_set_child_at_index(bar, child2, 0);
	clutter_actor_set_child_at_index(bar, child1, 1);

	extendCategory(1);
	reduceCategory(0);

	isOpen[0] = false;
	isOpen[1] = true;

	cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
	//cur_x = goal_x = clutter_actor_get_x(bar);
}

static void call_startTransitionCallback(ClutterActor * contentWrapper) 
{
	FirstScreenContents* ctr = NULL;
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
	}

	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->startTransitionCallback.invoke(arr);
	}
}

static void call_stopTransitionCallback(ClutterActor * contentWrapper) 
{
	FirstScreenContents* ctr = NULL;
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
	}

	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->stopTransitionCallback.invoke(arr);
	}
}

static void on_transition() 
{
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, 2);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);
	ClutterActor * border			= clutter_actor_get_child_at_index(contentWrapper, 2);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, 1);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, 1);
	
	Diff_transition = bezier(count_transition,COUNT_TRANSITION_FRAME, 0.3373f, 0.0f, 0.0f, 1.0f);

	gfloat Delta_width	= FOCUS_CONTENTS_WIDTH + (t_delta_width * Diff_transition);
	gfloat Delta_height = WIDGET_HEIGHT + (t_delta_height * Diff_transition);

	gfloat Scala_width =  FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH * (1 - (1 - t_delta_scala_width) * Diff_transition);
	gfloat Scala_height = WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT * (1 - (1 - t_delta_scala_height) * Diff_transition);

	clutter_actor_set_x(bar, p_x_start - (t_delta_x * Diff_transition));
	clutter_actor_set_y(contentWrapper, p_y_start - (t_delta_y * Diff_transition));

	int count  = clutter_actor_get_n_children(listWrapper);

	gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
	int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;

	for(int i = currentContents + 1; i < Maxcount; i++) 
	{
		ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
		clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (Delta_width - contentWrapper_width));
	}

	clutter_actor_set_size(contentWrapper, Delta_width, Delta_height);
	clutter_actor_set_size(dominant, Delta_width, Delta_height);
	clutter_actor_set_scale(image, Scala_width, Scala_height);

	
	if(clutter_actor_get_width(subMain) != 10) {
		clutter_actor_set_scale(subMain, Scala_width, Scala_height);
	}

	clutter_actor_set_opacity(titleParent, 0);
	clutter_actor_set_opacity(overray, 0);
	clutter_actor_set_opacity(border, 0);
	clutter_actor_set_opacity(categoryTitle, 0);


	if(!ON_TRANSITION) 
	{				
		count_transition++;

		if(count_transition > COUNT_TRANSITION_FRAME) 
		{
			KEY_SELECT = false;
			ON_TRANSITION = true;

			call_startTransitionCallback(contentWrapper);
		}
	}
	else 
	{
		count_transition--;

		if(count_transition < 0) 
		{
			clutter_actor_set_opacity(titleParent, 255);
			clutter_actor_set_opacity(overray, OPACITY_8);
			clutter_actor_set_opacity(border, 255);
			clutter_actor_set_opacity(categoryTitle, 255);

			KEY_SELECT = false;
			ON_TRANSITION = false;


			call_stopTransitionCallback(contentWrapper);

		}
	}
}

static void on_transition2() 
{
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, 2);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);
	ClutterActor * border			= clutter_actor_get_child_at_index(contentWrapper, 2);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, 1);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, 1);
	
	Diff_transition = bezier(count_transition,COUNT_TRANSITION_FRAME, 0.3373f, 0.0f, 0.0f, 1.0f);

	gfloat Delta_width	= FOCUS_CONTENTS_WIDTH + (t_delta_width * Diff_transition);
	gfloat Delta_height = WIDGET_HEIGHT + (t_delta_height * Diff_transition);

	gfloat Scala_width =  FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH * (1 - (1 - t_delta_scala_width) * Diff_transition);
	gfloat Scala_height = WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT * (1 - (1 - t_delta_scala_height) * Diff_transition);

	clutter_actor_set_y(bar, p_y_bar_start + (t_delta_y * Diff_transition));
	clutter_actor_set_position(contentWrapper, p_x_start - (t_delta_width * Diff_transition) / 2 , p_y_start - (t_delta_height * Diff_transition) - (t_delta_y * Diff_transition) );
	clutter_actor_set_position(titleParent, p_x_title_start + (t_delta_width * Diff_transition) / 2, p_y_title_start + (t_delta_height * Diff_transition));	

	clutter_actor_set_size(contentWrapper, Delta_width, Delta_height);
	clutter_actor_set_size(dominant, Delta_width, Delta_height);

	clutter_actor_set_scale(image, Scala_width, Scala_height);
	
	if(clutter_actor_get_width(subMain) != 10) {
		clutter_actor_set_scale(subMain, Scala_width, Scala_height);
	}

	clutter_actor_set_opacity(titleParent, 0);
	clutter_actor_set_opacity(overray, 0);
	clutter_actor_set_opacity(border, 0);
	clutter_actor_set_opacity(categoryTitle, 0);


	if(!ON_TRANSITION) 
	{				
		count_transition++;

		if(count_transition > COUNT_TRANSITION_FRAME) 
		{
			KEY_SELECT = false;
			ON_TRANSITION = true;

			call_startTransitionCallback(contentWrapper);
		}
	}
	else 
	{
		count_transition--;

		if(count_transition < 0) 
		{
			clutter_actor_set_opacity(titleParent, 255);
			clutter_actor_set_opacity(overray, OPACITY_8);
			clutter_actor_set_opacity(border, 255);
			clutter_actor_set_opacity(categoryTitle, 255);

			KEY_SELECT = false;
			ON_TRANSITION = false;


			call_stopTransitionCallback(contentWrapper);

		}
	}
}

static void on_transition3() 
{
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, 2);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);
	ClutterActor * border			= clutter_actor_get_child_at_index(contentWrapper, 2);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, 1);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, 1);
	
	Diff_transition = bezier(count_transition,COUNT_TRANSITION_FRAME, 0.3373f, 0.0f, 0.0f, 1.0f);



	gfloat Delta_width	= FOCUS_CONTENTS_WIDTH + (t_delta_width * Diff_transition);
	gfloat Delta_height = WIDGET_HEIGHT + (t_delta_height * Diff_transition);

	gfloat Scala_width =  FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH * (1 - (1 - t_delta_scala_width) * Diff_transition);
	gfloat Scala_height = WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT * (1 - (1 - t_delta_scala_height) * Diff_transition);
	
	clutter_actor_set_x(bar, p_x_bar_start - (t_delta_width * Diff_transition) / 2 );
	clutter_actor_set_y(contentWrapper, p_y_start - (t_delta_height * Diff_transition));
	clutter_actor_set_position(titleParent, p_x_title_start + (t_delta_width * Diff_transition) / 2, p_y_title_start + (t_delta_height * Diff_transition));	

	//other item
	int count  = clutter_actor_get_n_children(listWrapper);

	gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
	int startindex = (currentContents - 10 < 0) ? 0 : currentContents - 10;
	int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;

	for(int i = startindex; i < Maxcount; i++) 
	{
		if(i ==  currentContents) {
			continue;
		}

		ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
		clutter_actor_set_opacity(temp, 255 * (1 - Diff_transition));

		if(currentContents < i) {
			clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (Delta_width - contentWrapper_width));
		}
	}
	
	if(extendIndex == 1) {
		ClutterActor * otherCategoryItem = clutter_actor_get_child_at_index(bar, 0);
		clutter_actor_set_opacity(otherCategoryItem, 255 * (1 - Diff_transition));
	}
	clutter_actor_set_opacity(categoryTitle, 255 * (1 - Diff_transition));
	clutter_actor_set_opacity(titleParent, 255 * (1 - Diff_transition));

	clutter_actor_set_size(contentWrapper, Delta_width, Delta_height);
	clutter_actor_set_size(dominant, Delta_width, Delta_height);
	clutter_actor_set_scale(image, Scala_width, Scala_height);
	
	if(clutter_actor_get_width(subMain) != 10) {
		clutter_actor_set_scale(subMain, Scala_width, Scala_height);
	}

	clutter_actor_set_opacity(overray, 0);
	clutter_actor_set_opacity(border, 0);

	if (clutter_actor_get_n_children(contentWrapper) > 4)
	{
		ClutterActor * temp2 = clutter_actor_get_child_at_index(contentWrapper, 4);
		clutter_actor_set_opacity(temp2, (1 - Diff_transition) * 255);
	}
	

	if(!ON_TRANSITION) 
	{				
		count_transition++;

		if(count_transition > COUNT_TRANSITION_FRAME) 
		{
			KEY_SELECT = false;
			ON_TRANSITION = true;

			call_startTransitionCallback(contentWrapper);
		}
	}
	else 
	{
		count_transition--;

		if(count_transition < 0) 
		{
			clutter_actor_set_opacity(overray, OPACITY_8);
			clutter_actor_set_opacity(border, 255);
			
			KEY_SELECT = false;
			ON_TRANSITION = false;
			
			ClutterActor * liveImg1			= clutter_actor_get_child_at_index(image, 0);
			ClutterActor * liveImg2			= clutter_actor_get_child_at_index(image, 1);
			ClutterActor * liveIcon			= clutter_actor_get_child_at_index(image, 2);

			if(liveImg1 != NULL && liveImg2 != NULL ) {
				CONTENT_LIVE_FLAG = true;
				contentLiveTick =  0;
			}
			
			call_stopTransitionCallback(contentWrapper);
		}
	}
}

static void set_startapp_animation() 
{
	bool skipTransition = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		skipTransition = ctr->skipTransition; 
	}
	
	if (ctr != NULL && skipTransition && !ON_TRANSITION)
	{	
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);

		ctr->onClickCallback.invoke(arr);

		return;
	}

	KEY_RIGHT = false;
	KEY_LEFT = false;
	
	if(!ON_TRANSITION) 
	{
		count_transition = 0;

		//clutter_actor_set_size(image, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		clutter_actor_set_scale(image, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
		
		int ohtreCagtegoryIndex = (currentCategory == 0) ? 1 : 0;
		ClutterActor * otherCategory	= clutter_actor_get_child_at_index(bar, ohtreCagtegoryIndex);
		ClutterActor * otherCateWrapper	= clutter_actor_get_child_at_index(otherCategory, 0);


		t_delta_x		= clutter_actor_get_x(bar)  + clutter_actor_get_x(contentWrapper);
		if(extendIndex != 0 ) {
			t_delta_x += clutter_actor_get_width(otherCateWrapper) + CATEGORY_GAP;
		}
		t_delta_y		= clutter_actor_get_y(bar);
		t_delta_width	= (SCENE_WIDTH - FOCUS_CONTENTS_WIDTH);
		t_delta_height	= (SCENE_HEIGHT - WIDGET_HEIGHT);

		t_delta_scala_width = SCENE_WIDTH / FOCUS_CONTENTS_WIDTH;
		t_delta_scala_height = SCENE_HEIGHT / WIDGET_HEIGHT;


		p_x_start = clutter_actor_get_x(bar);
		p_y_start = clutter_actor_get_y(contentWrapper);

		if (ctr != NULL)
		{
			ScriptArray arr;
			arr.set(0, ctr->jsInstance);

			ctr->onClickCallback.invoke(arr);
		}
		
		KEY_SELECT = true;
	}
	else
	{
		KEY_RIGHT = false;
		KEY_LEFT = false;
	
		count_transition = COUNT_TRANSITION_FRAME;

		KEY_SELECT = true;
	}
}

static void set_startapp_animation2() 
{
	bool skipTransition = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		skipTransition = ctr->skipTransition; 
	}
	
	if (ctr != NULL && skipTransition && !ON_TRANSITION)
	{	
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);

		ctr->onClickCallback.invoke(arr);

		return;
	}

	KEY_RIGHT = false;
	KEY_LEFT = false;
	
	if(!ON_TRANSITION) 
	{
		count_transition = 0;

		//clutter_actor_set_size(image, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		//clutter_actor_set_scale(image, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
		
		if(extendIndex == 0) {
			cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2 + (currentContents) * NORMAL_CONTENTS_WIDTH;
		}
		else {
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2 + (currentContents) * NORMAL_CONTENTS_WIDTH;
		}

		move_rect();
		
		//int ohtreCagtegoryIndex = (currentCategory == 0) ? 1 : 0;
		//ClutterActor * otherCategory	= clutter_actor_get_child_at_index(bar, ohtreCagtegoryIndex);
		//ClutterActor * otherCateWrapper	= clutter_actor_get_child_at_index(otherCategory, 0);

		t_delta_y		= 500;
		t_delta_width	= FOCUS_CONTENTS_WIDTH * 0.2;
		t_delta_height	= WIDGET_HEIGHT * 0.2;

		t_delta_scala_width = FOCUS_CONTENTS_WIDTH * (1.2) / FOCUS_CONTENTS_WIDTH;
		t_delta_scala_height = WIDGET_HEIGHT * (1.2) / WIDGET_HEIGHT;

		p_x_start = clutter_actor_get_x(contentWrapper);
		p_y_start = clutter_actor_get_y(contentWrapper);
		p_x_title_start = clutter_actor_get_x(titleParent);
		p_y_title_start = clutter_actor_get_y(titleParent);
		p_y_bar_start = clutter_actor_get_y(bar);

		KEY_SELECT = true;

		if (ctr != NULL)
		{
			ScriptArray arr;
			arr.set(0, ctr->jsInstance);

			ctr->onClickCallback.invoke(arr);
		}
		

	}
	else
	{
		KEY_RIGHT = false;
		KEY_LEFT = false;
	
		count_transition = COUNT_TRANSITION_FRAME;

		KEY_SELECT = true;
	}
}

static void set_startapp_animation3() 
{
	bool skipTransition = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);

	ClutterActor * liveImg1			= clutter_actor_get_child_at_index(image, 0);
	ClutterActor * liveImg2			= clutter_actor_get_child_at_index(image, 1);
	ClutterActor * liveIcon			= clutter_actor_get_child_at_index(image, 2);
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		skipTransition = ctr->skipTransition; 
	}
	
	if (ctr != NULL && skipTransition && !ON_TRANSITION)
	{	
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);

		ctr->onClickCallback.invoke(arr);

		return;
	}

	KEY_RIGHT = false;
	KEY_LEFT = false;
	
	if(!ON_TRANSITION) 
	{
		count_transition = 0;

		if(extendIndex == 0) {
			cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2 + (currentContents) * NORMAL_CONTENTS_WIDTH;
		}
		else {
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2 + (currentContents) * NORMAL_CONTENTS_WIDTH;
		}

		move_rect();

		if(liveImg1 != NULL && liveImg2 != NULL ) {
			CONTENT_LIVE_FLAG = false;
			clutter_actor_set_scale(liveIcon, 1, 1);
			clutter_actor_set_x(liveImg1, NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(liveImg2, NORMAL_CONTENTS_WIDTH);
			contentLiveTick =  0;
		}
		
		int ohtreCagtegoryIndex = (currentCategory == 0) ? 1 : 0;
		ClutterActor * otherCategory	= clutter_actor_get_child_at_index(bar, ohtreCagtegoryIndex);
		ClutterActor * otherCateWrapper	= clutter_actor_get_child_at_index(otherCategory, 0);

		t_delta_width	= FOCUS_CONTENTS_WIDTH * 0.3;
		t_delta_height	= WIDGET_HEIGHT * 0.3;

		t_delta_scala_width = FOCUS_CONTENTS_WIDTH * (1.3) / FOCUS_CONTENTS_WIDTH;
		t_delta_scala_height = WIDGET_HEIGHT * (1.3) / WIDGET_HEIGHT;

		p_x_bar_start = clutter_actor_get_x(bar);
		p_x_start = clutter_actor_get_x(contentWrapper);
		p_y_start = clutter_actor_get_y(contentWrapper);
		p_x_title_start = clutter_actor_get_x(titleParent);
		p_y_title_start = clutter_actor_get_y(titleParent);

		KEY_SELECT = true;

		if (ctr != NULL)
		{
			ScriptArray arr;
			arr.set(0, ctr->jsInstance);

			ctr->onClickCallback.invoke(arr);
		}
	}
	else
	{
		KEY_RIGHT = false;
		KEY_LEFT = false;
	
		count_transition = COUNT_TRANSITION_FRAME;

		KEY_SELECT = true;
	}
}

static int get_extend_itemCount() {
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	int t_count = clutter_actor_get_n_children(listWrapper);
	return t_count;
}

void FirstScreenListWidget::off_transition_noanimaition() {

	KEY_SELECT = false;
	ON_TRANSITION = false;
	count_transition = -1;
		
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, 2);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);
	ClutterActor * border			= clutter_actor_get_child_at_index(contentWrapper, 2);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, 1);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, 1);
	
	ClutterActor * liveImg1			= clutter_actor_get_child_at_index(image, 0);
	ClutterActor * liveImg2			= clutter_actor_get_child_at_index(image, 1);
	ClutterActor * liveIcon			= clutter_actor_get_child_at_index(image, 2);

	clutter_actor_set_x(bar, p_x_bar_start);
	clutter_actor_set_position(contentWrapper, p_x_start, p_y_start);
	clutter_actor_set_position(titleParent, p_x_title_start, p_y_title_start);	
	
	int count  = clutter_actor_get_n_children(listWrapper);

	gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
	int startindex = (currentContents - 10 < 0) ? 0 : currentContents - 10;
	int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;

	for(int i = startindex; i < Maxcount; i++) 
	{
		if(i ==  currentContents) {
			continue;
		}

		ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
		clutter_actor_set_opacity(temp, 255 );

		if(currentContents < i) {
			clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (FOCUS_CONTENTS_WIDTH - contentWrapper_width));
		}
	}

	clutter_actor_set_size(contentWrapper, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_size(dominant, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_scale(image, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_scale(subMain, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
	
	if(extendIndex == 1) {
		ClutterActor * otherCategoryItem = clutter_actor_get_child_at_index(bar, 0);
		clutter_actor_set_opacity(otherCategoryItem, 255);
	}

	clutter_actor_set_opacity(titleParent, 255);
	clutter_actor_set_opacity(overray, OPACITY_8);
	clutter_actor_set_opacity(categoryTitle, 255);

	if(liveImg1 != NULL && liveImg2 != NULL ) {
		CONTENT_LIVE_FLAG = true;
		contentLiveTick =  0;
	}
}
/*back up
void FirstScreenListWidget::off_transition_noanimaition() {
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, 1);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);
	ClutterActor * border			= clutter_actor_get_child_at_index(contentWrapper, 2);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, 1);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, 4);
	
	clutter_actor_set_x(bar, p_x_start);
	clutter_actor_set_y(contentWrapper, p_y_start);

	int count  = clutter_actor_get_n_children(listWrapper);

	gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
	int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;

	for(int i = currentContents + 1; i < Maxcount; i++) 
	{
		ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
		clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (FOCUS_CONTENTS_WIDTH - contentWrapper_width));
	}
	
	clutter_actor_set_size(contentWrapper, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_size(dominant, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_scale(image, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_scale(subMain, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
	
	count_transition = -1;
	clutter_actor_set_opacity(titleParent, 255);
	clutter_actor_set_opacity(overray, OPACITY_8);
	clutter_actor_set_opacity(categoryTitle, 255);
	KEY_SELECT = false;
	ON_TRANSITION = false;
}
*/

void FirstScreenListWidget::stop_transition() {
	ON_TRANSITION = true;
	KEY_SELECT = true;
	set_startapp_animation3();
}

void FirstScreenListWidget::animateOnEnter()
{
	if(KEY_SELECT || REDUCE_FLAG || EXTEND_FLAG || STOP_FLAG || foveaState == FIRST_GAP)	
	{
		return;
	}

	if(!isOpen[currentCategory]) 
	{
		extendAnimation();
	}
	else 
	{
		set_startapp_animation3();
	}
}

static void moveToEnd(bool fromContents)
{
	STOP_FLAG = true;

	if (fromContents)
	{
		// 1: normal contents	
		goal_position = SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP);
	}
	else
	{
		goal_position = SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP);
	}
	
	if (goal_position >= CATEGORY_GAP)
	{
		goal_position = CATEGORY_GAP;
	}
	clutter_actor_set_x(bar, goal_position);

	if (fromContents)
	{
		// 1: normal contents	
		cur_x = goal_x	= goal_position + (NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH / 2 - 1);
	}
	else
	{
		cur_x = goal_x	= goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH / 2 - 1);
	}
	
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;
	move_rect();
	STOP_FLAG = false;
}

static void moveToBegin()
{
	STOP_FLAG = true;
	
	clutter_actor_set_x(bar, CATEGORY_GAP);
	goal_position = CATEGORY_GAP;

	if (extendIndex == 0)
	{
		cur_x = goal_x = CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2;
	}
	else
	{
		cur_x = goal_x = CATEGORY_GAP + FOCUS_CATEGORY_WIDTH / 2 + 1;
		//int t_count = get_extend_itemCount();
		//toNormalContents(extendIndex, t_count - 1, 0);
		//foveaFeaturedOpen(1.0);
	}

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;

	move_rect();
	STOP_FLAG = false;
}

void FirstScreenListWidget::moveRight()
{
	if(ON_TRANSITION || STOP_FLAG || KEY_SELECT)
	{
		return;
	}

	int t_count = get_extend_itemCount();
	

	if(extendIndex == 0) {
		if(goal_x <= goal_position + NORMAL_CONTENTS_WIDTH * (t_count -1) + FOCUS_CONTENTS_WIDTH
					&& goal_x >= goal_position + NORMAL_CONTENTS_WIDTH * (t_count -1) )
		{
			if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				moveToBegin();
			}
			return ;
		}	
	}
	else {
		if(goal_x <= goal_position + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count -1) + FOCUS_CONTENTS_WIDTH
					&& goal_x >= goal_position + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count -1) )
		{
			if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				moveToBegin();
			}
			return ;
		}	
	}
	
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;

	if(KEY_LEFT) {
		KEY_LEFT = false;
		goal_position = clutter_actor_get_x(bar);
		if(currentContents < 0) {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2;
			}
		}
		else {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
		}
	}
	KEY_RIGHT = true;

	t_delta_x = NORMAL_CONTENTS_WIDTH;
	goal_x += t_delta_x;

	if(extendIndex == 1 && goal_position <= goal_x && (goal_position + FOCUS_CATEGORY_WIDTH >=  goal_x))
	{
		//t_delta_x = NORMAL_CONTENTS_WIDTH + (FOCUS_CATEGORY_WIDTH - FOCUS_CONTENTS_WIDTH ) / 2 + CATEGORY_GAP;
		goal_x = goal_position + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2;
	}
	
	if(extendIndex == 1) {
		if(goal_x >= goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 ) )
		{
			goal_x = goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 - 1);		
		}			
	}
	else {
		
		if(goal_x >= goal_position + (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2)) 
		{
			goal_x = goal_position + (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 - 1);
		}
	}
			
	if(goal_x + FOCUS_CONTENTS_WIDTH / 2 >= SCENE_WIDTH) 
	{
		goal_position -= t_delta_x;
		goal_x -= t_delta_x;

		if(extendIndex == 0) {
			if(goal_position < SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP)) {
				goal_position = SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP);
				goal_x = goal_position + (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 - 1);
			}
		}
		else {
			if(goal_position < SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP)) {
				goal_position = SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP);
				goal_x = goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 - 1) ;
			}
		}

		if(cur_x > goal_x) {
			cur_x = goal_x;
		}
	}

	ratio_point = (goal_x - cur_x) / (15 * 1);
	ratio_position = (goal_position - clutter_actor_get_x(bar)) / (10 * 1);
}

void FirstScreenListWidget::moveLeft()
{
	if(ON_TRANSITION || STOP_FLAG || KEY_SELECT)
	{
		return;
	}

	if(extendIndex == 0 )
	{
		if(goal_position <= goal_x && (goal_position + FOCUS_CONTENTS_WIDTH >=  goal_x))// || currentCategory == 1) 
		{
			if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				moveToEnd(true);
			}
			return;
		}
	}
	else if(goal_position <= goal_x && (goal_position + FOCUS_CATEGORY_WIDTH >=  goal_x))// || currentCategory == 1) 
	{
		if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				moveToEnd(false);
		}
		return;
	}

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;


	if(KEY_RIGHT) {
		KEY_RIGHT = false;
		goal_position = clutter_actor_get_x(bar);
		if(currentContents < 0) {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2;
			}
			
		}
		else {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
		}
	}
	KEY_LEFT = true;
				
	t_delta_x = NORMAL_CONTENTS_WIDTH;
	goal_x -= t_delta_x;
		
	if(extendIndex == 1 && goal_position <= goal_x && (goal_position + FOCUS_CATEGORY_WIDTH >=  goal_x)) 
	{
		t_delta_x = NORMAL_CONTENTS_WIDTH + (FOCUS_CATEGORY_WIDTH - FOCUS_CONTENTS_WIDTH ) / 2 + CATEGORY_GAP + CATEGORY_GAP;
		goal_x = goal_position + FOCUS_CATEGORY_WIDTH / 2; 
	}
	
	if(goal_x <= goal_position) 
	{
		goal_x += t_delta_x;
		goal_x += CATEGORY_GAP;

		return;
	}			
	
	if(goal_x - FOCUS_CONTENTS_WIDTH / 2 <= 0) 
	{
		goal_position += t_delta_x;
		goal_x += t_delta_x;

		if(goal_position >= 0 ) {
			goal_position = CATEGORY_GAP;
			if(extendIndex == 0) {
				goal_x = CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2;
			}
			else {
				goal_x = CATEGORY_GAP + FOCUS_CATEGORY_WIDTH / 2;
			}
			
			if(cur_x < goal_x) {
				cur_x = goal_x;
			}
		}

	} 

	ratio_point = (goal_x - cur_x) / (15 * 1);
	ratio_position = (goal_position - clutter_actor_get_x(bar)) / (10 * 1);
}

static void scrollLeft()
{
	if(clutter_actor_get_x(bar) >= 0) 
	{
		SCROLL_LEFT = false;
	}
	else 
	{
		velocity += 0.7;

		if(velocity > 60) 
		{
			velocity = 60;
		}

		clutter_actor_set_x(bar, clutter_actor_get_x(bar) + velocity);
	}
}

static void scrollRight() 
{
	int t_count = get_extend_itemCount();
	if(clutter_actor_get_x(bar) <= SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH) )
	{
		SCROLL_RIGHT = false;
	}
	else 
	{
		velocity += 0.7;

		if(velocity > 60)
		{
			velocity = 60;
		}

		clutter_actor_set_x(bar, clutter_actor_get_x(bar) - velocity);
	}
}

static void scrollLeft_Rollover() 
{
	gfloat temp = min((t_t - DELAY_TIME)/AUTOSCROLL_TIME, (gfloat)1);

	V_t = min(INIT_SPEED + temp * temp  * SCALE_SPEED, LIMIT_SPEED);
	t_t += 0.16;

	if(clutter_actor_get_x(bar) >= CATEGORY_GAP) 
	{
		SCROLL_LEFT = false;
	}
	else 
	{	
		if(clutter_actor_get_x(bar) + V_t > CATEGORY_GAP) {
			clutter_actor_set_x(bar, CATEGORY_GAP);
		}
		else {
			clutter_actor_set_x(bar, clutter_actor_get_x(bar) + V_t);
		}
	}

	goal_position = clutter_actor_get_x(bar);
}

static void scrollRight_Rollover() 
{

	gfloat temp = min((t_t - DELAY_TIME)/AUTOSCROLL_TIME, (gfloat)1);

	V_t = min(INIT_SPEED + temp * temp * SCALE_SPEED, LIMIT_SPEED);
	t_t += 0.16;

	int t_count = get_extend_itemCount();

	if(extendIndex == 0 ) {
		if(clutter_actor_get_x(bar) <= SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP))
		{
			SCROLL_RIGHT = false;
		}
		else 
		{
			if(clutter_actor_get_x(bar) - V_t < SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP)) {
				clutter_actor_set_x(bar, SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP));
			}
			else {
				clutter_actor_set_x(bar, clutter_actor_get_x(bar) - V_t);
			}
		}
	}
	else {
		if(clutter_actor_get_x(bar) <= SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP))
		{
			SCROLL_RIGHT = false;
		}
		else 
		{
			if(clutter_actor_get_x(bar) - V_t < SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP)) {
				clutter_actor_set_x(bar, SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + CATEGORY_GAP));
			}
			else {
				clutter_actor_set_x(bar, clutter_actor_get_x(bar) - V_t);
			}
		}
	}

	

	goal_position = clutter_actor_get_x(bar);
}

static long getCurrentTime(){
	time_t curTime;
	time(&curTime);
	return curTime;
}



static gboolean FireOnCallbacks(gpointer aData)
{

	FirstScreenContents* ctr = NULL;
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);

	clutter_actor_get_child_at_index(listWrapper, currentContents);
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
	}

	//FirstScreenContents* ctr = reinterpret_cast<FirstScreenContents *>(aData);
	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->longPressCallback.invoke(arr);
	}
	return FALSE;
};

void longPressCheckThread() 
{
	while(true){
		releaseTime = getCurrentTime();
		
		if(getCurrentTime() - pressTime >= 1 && isPressHold == true){
			isLongPress = true;
			clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW, FireOnCallbacks, NULL, NULL);
			break;
		}else if(isPressHold == false){
			break;
		}
	}
}


static void on_stage_button_press_event(ClutterStage *stage, ClutterEvent *event, gpointer data) 
{
	pressTime = getCurrentTime();
	isPressHold = true;
	isLongPress = false;
	pressThread = std::thread(longPressCheckThread);
	pressThread.detach();
}


static void on_stage_button_release_event(ClutterStage *stage, ClutterEvent *event, gpointer data) 
{

	//LYJ
	isPressHold = false;
	if(isLongPress == false){
		if(STOP_FLAG)
		{
			return;
		}

		gfloat y;

		clutter_event_get_coords(event, NULL, &y);

		if(KEY_SELECT || REDUCE_FLAG || EXTEND_FLAG || foveaState == FIRST_GAP)	
		{
			return;
		}

		if(y < SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT)	
		{

			if (y < SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2)
			{
				VoltFullProcessRuntime *runtime =
				static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

				runtime->GetMainStage();
				
				STOP_FLAG = true;
				
				EVENT_FLAG = false;

				clutter_actor_animate(bar, CLUTTER_EASE_IN_OUT_QUINT, 700, "y", SCENE_HEIGHT + 100 * HD_PROPORTION, NULL);
				
				VDLowerXWindow(runtime->GetMainStage());
			}
			else
			{
				if (isOpen[currentCategory])
				{
					// call the options [shuhao.yan]	

					setenterOptions();
				}
			}
			
		}
		else
		{
			if(!isOpen[currentCategory]) 
			{
				extendAnimation();
			}
			else 
			{
				set_startapp_animation3();
			}
		}	
	}
	isLongPress = false;
}

void FirstScreenListWidget::riseFirstScreen()
{
	clutter_actor_set_y(bar, SCENE_HEIGHT + 100);
	clutter_actor_animate(bar, CLUTTER_EASE_IN_OUT_QUINT, 1000, "y", SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT, this);	
	clutter_timeline_start(timeline); 
	EVENT_FLAG = true;
	STOP_FLAG = false;
}

void FirstScreenListWidget::setBarOpacityZero()
{
	clutter_actor_set_opacity(bar, 0);
}

void FirstScreenListWidget::setBarOpacityMax()
{
	clutter_actor_set_opacity(bar, 255);
}

static void on_stage_motion_event(ClutterStage *stage, ClutterEvent *event, gpointer data)
{
	if(ON_TRANSITION || KEY_SELECT || STOP_FLAG) 
	{
		return;
	}

	if(FOCUS_OPTIONS)
	{
		setunfocusOptions();
	}

	time(&mouseMoved);
	
	gfloat x = 0;
    gfloat y = 0;

	clutter_event_get_coords(event, &x, &y);

	x = REVERSE_OSD ? SCENE_WIDTH - x : x; // [shuhao.yan]

	KEY_LEFT = false;
	KEY_RIGHT = false;
	
	/*if(x < SCROLL_AREA && y > ROOT_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2 - 200)	//SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2
	{
		SCROLL_LEFT = true;
		SCROLL_RIGHT = false;
		
		cur_x = SCROLL_AREA;
		
		return;
	}
	else if(SCENE_WIDTH - SCROLL_AREA < x && y > ROOT_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2 - 200)	//SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2
	{
		SCROLL_LEFT = false;
		SCROLL_RIGHT = true;
		
		cur_x = SCENE_WIDTH - SCROLL_AREA;
		
		return;
	}
	else 
	{
		velocity = 0;
		
		SCROLL_LEFT = false;
		SCROLL_RIGHT = false;
	}*/
	
	if(x < SCROLL_AREA && y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT)	
	{
		t_scrollout = 0;
		isOutScroll = false;
		SCROLL_LEFT = true;
		SCROLL_RIGHT = false;
		
		if(INIT_SPEED == 0) 
		{
			INIT_SPEED = ((INIT_MAXSPEED - INIT_MINSPEED )/SCROLL_AREA) * (SCROLL_AREA - x) + INIT_MINSPEED;
		}

		SCALE_SPEED = ((SCALE_MAXSPEED - SCALE_MINSPEED)/SCROLL_AREA) * (SCROLL_AREA - x) + SCALE_MINSPEED;
		LIMIT_SPEED = ((LIMIT_MAXSPEED - LIMIT_MINSPEED)/SCROLL_AREA) * (SCROLL_AREA - x) + LIMIT_MINSPEED;

		cur_x = SCROLL_AREA;
		
		return;
	}
	else if(SCENE_WIDTH - SCROLL_AREA < x && y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT)	
	{
		t_scrollout = 0;
		isOutScroll = false;
		SCROLL_LEFT = false;
		SCROLL_RIGHT = true;

		if(INIT_SPEED == 0) 
		{
			INIT_SPEED = ((INIT_MAXSPEED - INIT_MINSPEED )/SCROLL_AREA) * (x - (SCENE_WIDTH - SCROLL_AREA)) + INIT_MINSPEED;
		}
		
		SCALE_SPEED = ((SCALE_MAXSPEED - SCALE_MINSPEED)/SCROLL_AREA) * (x - (SCENE_WIDTH - SCROLL_AREA)) + SCALE_MINSPEED;
		LIMIT_SPEED = ((LIMIT_MAXSPEED - LIMIT_MINSPEED)/SCROLL_AREA) * (x - (SCENE_WIDTH - SCROLL_AREA)) + LIMIT_MINSPEED;

		cur_x = SCENE_WIDTH - SCROLL_AREA;
		
		return;
	}
	else 
	{
		if(SCROLL_LEFT == true || SCROLL_RIGHT == true) {
			velocity = 0;
			INIT_SPEED = 0;
			SCALE_SPEED = 0;
			LIMIT_SPEED = 0;
			t_t = 0;
			t_scrollout = 0;
			if(y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT) {
				V_t = 0;
				SCROLL_LEFT = false;
				SCROLL_RIGHT = false;
			}
			else {
				V_t = min(V_t, STOP_LIMITSPEED);
		
				isOutScroll = true;
			}
		}
	}

	if (y < SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT && y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - 50)
	{
		setfocusOptions();
	}
	else
	{
		setunfocusOptions();
	}
	
	
	cur_x = x;
	cur_y = y;
	
	if(clutter_actor_get_n_children(bar) == 1)
	{
		goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2 + (currentIndex - 1) * NORMAL_CONTENTS_WIDTH;
	}
	else
	{
		goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2 + (currentIndex - 1) * NORMAL_CONTENTS_WIDTH;
	}
	
	goal_position = clutter_actor_get_x(bar);
}

float FirstScreenListWidget::getPositionX(std::string categoryType, int contentsIndex)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentContents = NULL;

	float position = 0.0f;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		printf("There is no category!!!\n");

		return -10.0f;
	}

	currentChild = clutter_actor_get_child_at_index(bar, 0);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			printf("There is no such category!!! Check id!!!\n");

			return -10.0f;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				printf("There is no such category!!! Check id!!!\n");

				return -10.0f;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, 2);

	currentContents = clutter_actor_get_child_at_index(currentList, contentsIndex);

	position = clutter_actor_get_x(bar) + clutter_actor_get_x(currentChild) + clutter_actor_get_x(currentContents);

	return position;
}

float FirstScreenListWidget::getPositionY(std::string categoryType, int contentsIndex)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentContents = NULL;

	float position = 0.0f;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		printf("There is no category!!!\n");

		return -10.0f;
	}

	currentChild = clutter_actor_get_child_at_index(bar, 0);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			printf("There is no such category!!! Check id!!!\n");

			return -10.0f;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, 1);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				printf("There is no such category!!! Check id!!!\n");

				return -10.0f;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, 2);

	currentContents = clutter_actor_get_child_at_index(currentList, contentsIndex);

	position = clutter_actor_get_y(bar) + clutter_actor_get_y(currentContents);

	return position;
}

static void categoryLiveImage()
{
	if(livetick <= 60.0f * (aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
	{
		liveDiff = bezier(livetick - (60.0f * aniTime[LIVE_TERM]), 60.0f * aniTime[LIVE_EXCUTE], live[0], live[1], live[2], live[3]);

		clutter_actor_set_x(liveTemp1, -FOCUS_CATEGORY_WIDTH*liveDiff);
		clutter_actor_set_x(liveTemp2, FOCUS_CATEGORY_WIDTH*(1 - liveDiff));

		if(livetick == 60.0f * (aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
		{
			clutter_actor_set_x(liveTemp1, FOCUS_CATEGORY_WIDTH);
		}
	}
	else if(livetick >= 60.0f * (2*aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
	{
		liveDiff = bezier(livetick - 60.0f * (2*aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]), 60.0f * aniTime[LIVE_EXCUTE], live[0], live[1], live[2], live[3]);

		clutter_actor_set_x(liveTemp2, -FOCUS_CATEGORY_WIDTH*liveDiff);
		clutter_actor_set_x(liveTemp1, FOCUS_CATEGORY_WIDTH*(1 - liveDiff));

		if(livetick == 60.0f * 2 * (aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
		{
			livetick = 0;
		}
	}
}

static void contentLiveImage()
{
	if(contentLiveTick < aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE])
	{
		if(contentLiveTick == 0)
		{
			clutter_actor_set_scale(appLive[0], 1, 1);
			clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);

			clutter_actor_set_scale(gameLive[0], 1, 1);
			clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - aniTime[CONTENT_LIVE_TERM], aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_scale(appLive[0], 1 - (1 - contentLiveScaleX)*contentLiveDiff, 1 - (1 - contentLiveScaleY)*contentLiveDiff);
		clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));
	}
	else if(contentLiveTick < 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	{
		if(contentLiveTick == aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE])
		{
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - (2*aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_x(appLive[1], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);
		clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));	
	}
	else if(contentLiveTick < 3*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	{
		if(contentLiveTick == 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - (3*aniTime[CONTENT_LIVE_TERM] + 2*aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_scale(appLive[0], contentLiveScaleX - (contentLiveScaleX - 1)*contentLiveDiff, contentLiveScaleY - (contentLiveScaleY - 1)*contentLiveDiff);
		clutter_actor_set_x(appLive[2], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);

		clutter_actor_set_scale(gameLive[0], 1 - (1 - contentLiveScaleX)*contentLiveDiff, 1 - (1 - contentLiveScaleY)*contentLiveDiff);
		clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));
	}
	else if(contentLiveTick < 4*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	{
		if(contentLiveTick == 3*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - (4*aniTime[CONTENT_LIVE_TERM] + 3*aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_x(gameLive[1], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);
		clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));
	}
	else if(contentLiveTick <= 5*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	{
		if(contentLiveTick == 4*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - (5*aniTime[CONTENT_LIVE_TERM] + 4*aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_scale(gameLive[0], contentLiveScaleX - (contentLiveScaleX - 1)*contentLiveDiff, contentLiveScaleY - (contentLiveScaleY - 1)*contentLiveDiff);
		clutter_actor_set_x(gameLive[2], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);

		clutter_actor_set_scale(appLive[0], 1 - (1 - contentLiveScaleX)*contentLiveDiff, 1 - (1 - contentLiveScaleY)*contentLiveDiff);
		clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));

		if(contentLiveTick == 5*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);

			contentLiveTick = aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE];
		}
	}
}

bool totalFrameNum = 0;

static void on_timeline_new_frame(ClutterTimeline *timeline, gint frame_num, gpointer data)
{
	if(STOP_FLAG)
	{
		return;
	}

	if(EVENT_FLAG)
	{
		if(clutter_actor_get_n_children(bar) == 2)
		{
			categoryLiveImage();
			
			livetick++;
		}

		if(CONTENT_LIVE_FLAG && appLive[2] != NULL && gameLive[2] != NULL)
		{
			contentLiveImage();
			
			contentLiveTick++;
		}

		if(KEY_RIGHT && !ON_TRANSITION) 
		{
			
			if(clutter_actor_get_x(bar) + ratio_position <= goal_position) {
				clutter_actor_set_x(bar, goal_position);
			}
			else {
				clutter_actor_set_x(bar, clutter_actor_get_x(bar) + ratio_position);
			}
			

			if(cur_x + ratio_point >= goal_x)
			{
				cur_x = goal_x;
			}
			else {
				cur_x += ratio_point;
			}
			
			int t_count = get_extend_itemCount();
			
			if(extendIndex == 1 && cur_x == clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count - 1) + FOCUS_CONTENTS_WIDTH / 2 - 1) {
				KEY_RIGHT = false;
			}
			else if(extendIndex == 0 && cur_x == clutter_actor_get_x(bar) + NORMAL_CONTENTS_WIDTH * (t_count - 1) + FOCUS_CONTENTS_WIDTH / 2 - 1)
			{
				KEY_RIGHT = false;
			}
			//printf("KEY_RIGHT: %f %f\n", cur_x, clutter_actor_get_x(bar));
		}

		if(KEY_LEFT && !ON_TRANSITION) 
		{	
			if(clutter_actor_get_x(bar) + ratio_position >= goal_position) 
			{
				clutter_actor_set_x(bar, goal_position);
			}
			else {
				clutter_actor_set_x(bar, clutter_actor_get_x(bar) + ratio_position);
			}
			
		
			if(cur_x + ratio_point <= goal_x) 
			{
				cur_x = goal_x;
			}
			else {
				cur_x += ratio_point;
			}

			if(extendIndex == 1 && clutter_actor_get_x(bar) == CATEGORY_GAP && cur_x == (clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH / 2)) {
				KEY_LEFT = false;
			}
			else if(extendIndex == 0 && clutter_actor_get_x(bar) == CATEGORY_GAP && cur_x == (clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2)) {
				KEY_LEFT = false;
			}
			//printf("KEY_LEFT: cur_x %f %f\n", cur_x, clutter_actor_get_x(bar));
		}

		if(SCROLL_LEFT)  
		{
			//scrollLeft();

			if(isOutScroll) 
			{
				if(clutter_actor_get_x(bar) >= 0 || V_t < 0)
				{
					SCROLL_LEFT = false;
					SCROLL_RIGHT = false;
					V_t = 0;
					t_t = 0;
					t_scrollout = 0;
					isOutScroll = false;
				}
				else 
				{
					clutter_actor_set_x(bar, clutter_actor_get_x(bar) + V_t);
					t_scrollout += 0.16;
					gfloat temp = (t_scrollout / STOPSCROLL_TIME);
					V_t = V_t + (-V_t * temp * temp);	
				}
			}
			else 
			{
				scrollLeft_Rollover();
			}
		}

		if(SCROLL_RIGHT)  
		{
			//scrollRight();
			int t_count = get_extend_itemCount();
			if(isOutScroll)
			{

				if( V_t < 0 || clutter_actor_get_x(bar) <= SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH) )
				{
					SCROLL_RIGHT = false;
					SCROLL_LEFT = false;
					V_t = 0;
					t_t = 0;
					t_scrollout = 0;
					isOutScroll = false;
				}
				else 
				{
					clutter_actor_set_x(bar, clutter_actor_get_x(bar) - V_t);
					t_scrollout += 0.16;
					gfloat temp = (t_scrollout / STOPSCROLL_TIME);
					V_t = V_t + (- V_t * temp * temp);
				}
			}
			else 
			{
				scrollRight_Rollover();
			}
		}

		if(KEY_SELECT) 
		{
			on_transition3();

			return;
		}
		
		if(!ON_TRANSITION && !KEY_SELECT) 
		{
			move_rect();
		}
	}
	else
	{
		tick++;

		extendDiff = bezier(tick, 60.0f * aniTime[EXTEND], extendCurve[0], extendCurve[1], extendCurve[2], extendCurve[3]);
	
		if(EXTEND_FLAG)
		{
			extendEffect();
		}
		
		if(REDUCE_FLAG)
		{
			reduceEffect();
		}
		
		if(tick >= 60.0f * aniTime[EXTEND])
		{
			tick = 0;
			livetick = 0;
			contentLiveTick = 0;
			EVENT_FLAG = true;
			EXTEND_FLAG = false;
			REDUCE_FLAG = false;
			
			std::string tempName;
			
			tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, 0));
			
			if(tempName.compare("featured") == 0)
			{
				CONTENT_LIVE_FLAG = false;
			}
			else
			{
				CONTENT_LIVE_FLAG = true;
			}
			
			if(clutter_actor_get_n_children(bar) == 1)
			{
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
			}
			else if(clutter_actor_get_n_children(bar) == 2)
			{
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
			}
		}
	}
}

int FirstScreenListWidget::addItem(FirstScreenListItem* item)
{
	return 0;
}

int FirstScreenListWidget::size()
{
	//return itemList.size();
	return 0;
}

int FirstScreenListWidget::clear()
{
	//itemList.clear();
	return 0;
}

int FirstScreenListWidget::getSelectedItemPos()
{
	return 10;
}

void FirstScreenListWidget::startAnimation()
{
	/*LOG_DEBUG(logger, "FirstScreenListWidget::startAnimation()");

	contentsList = actor;

	g_signal_connect(actor, "button-press-event", G_CALLBACK(on_stage_button_event), this);
	g_signal_connect(actor, "motion-event", G_CALLBACK(on_stage_motion_event), this);

	printf("g_signal_connect - button-press-event\n");
	printf("g_signal_connect - motion-event\n");

	timeline = clutter_timeline_new(16);
	g_signal_connect(timeline, "new-frame", G_CALLBACK(on_timeline_new_frame), NULL);

	clutter_timeline_set_loop(timeline, TRUE); 
	clutter_timeline_start(timeline);*/
	LOG_DEBUG(logger, "FirstScreenListWidget::startAnimation()");

	g_signal_connect(mouseArea, "button-press-event", G_CALLBACK(on_stage_button_press_event), this);
	g_signal_connect(mouseArea, "button-release-event", G_CALLBACK(on_stage_button_release_event), this);
	g_signal_connect(mouseArea, "motion-event", G_CALLBACK(on_stage_motion_event), this);

	printf("g_signal_connect - button-press-event\n");
	printf("g_signal_connect - motion-event\n");

	timeline = clutter_timeline_new(16);
	g_signal_connect(timeline, "new-frame", G_CALLBACK(on_timeline_new_frame), this);
	
	if(clutter_actor_get_n_children(bar) == 1)
	{
		extendDiff = 1.0f;
		
		extendCategory(0);	
		extendEffect();

		cur_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
		goal_x = cur_x;
		
		EXTEND_FLAG = false;
		
		CONTENT_LIVE_FLAG = true;
	}
	else if(clutter_actor_get_n_children(bar) == 2)
	{
		extendDiff = 1.0;

		ClutterActor *child1 = clutter_actor_get_child_at_index(bar, 0);
		ClutterActor *child2 = clutter_actor_get_child_at_index(bar, 1);

		clutter_actor_set_x(child2, 0);
		clutter_actor_set_x(child1, clutter_actor_get_width(child2) + CATEGORY_GAP);

		clutter_actor_set_child_at_index(bar, child2, 0);
		clutter_actor_set_child_at_index(bar, child1, 1);

		extendCategory(1);
		extendEffect();
		reduceCategory(0);
		reduceEffect();

		isOpen[0] = false;
		isOpen[1] = true;

		cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
		
		REDUCE_FLAG = false;
		EXTEND_FLAG = false;
		
		CONTENT_LIVE_FLAG = false;
		
		/*extendDiff = 1.0;

		extendCategory(1);	
		extendEffect();

		cur_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
		goal_x = cur_x;

		EXTEND_FLAG = false;*/
	}
	
	EVENT_FLAG = true;

	clutter_timeline_set_loop(timeline, TRUE); 
	clutter_timeline_start(timeline);
}

void FirstScreenListWidget::stopAnimation()
{
}

void FirstScreenListWidget::updateDominantColor(ClutterActor* dominant, Color dominantColor)
{
	printf("FirstScreenListWidget::updateDominantColor\n");
	clutter_actor_set_background_color(dominant, dominantColor.toClutterColor());
}

void FirstScreenListWidget::sendKeyEvent(int keyType, int keyCode)
{
	/*LOG_DEBUG(logger, "FirstScreenListWidget::sendKeyEvent " << keyType << " " << keyCode);

	if(keyType == EVENT_KEY_PRESS)
	{
		switch(keyCode)
		{
		case KEY_JOYSTICK_RIGHT :
			if (currentIndex >= itemCount - 1)
			{
				return;
			}

			is_key_right = true;
			is_key_left = false;
				
			goal_x += NORMAL_WIDTH;
		
			if(goal_x >= clutter_actor_get_x(contentsList) + NORMAL_WIDTH*itemCount) 
			{
				goal_x -= NORMAL_WIDTH;
			
				return;
			}			
			
			if(goal_x > ROOT_WIDTH) 
			{
				goal_position -= NORMAL_WIDTH;
				goal_x -= NORMAL_WIDTH;
			} 

			break;

		case KEY_JOYSTICK_LEFT :
			if (currentIndex <= 1)
			{
				return;
			}

			is_key_right = false;
			is_key_left = true;
				
			goal_x -= NORMAL_WIDTH;
		
			if(goal_x <= clutter_actor_get_x(contentsList)) 
			{
				goal_x += NORMAL_WIDTH;
			
				return;
			}			
			
			if(goal_x < 0) 
			{
				goal_position += NORMAL_WIDTH;
				goal_x += NORMAL_WIDTH;
			} 

			break;

		default :
			break;
		}
	}

	//printf("%f\t%f\n", cur_x, goal_x);
	ratio_point = (goal_x - cur_x) / (30 * 1);
	ratio_position = (goal_position - clutter_actor_get_x(contentsList)) / (10 * 1);*/
}

void FirstScreenListWidget::setOnItemSelectedListener(ScriptFunction callback)
{
	this->onItemSelectedListener = callback;
}

void FirstScreenListWidget::setOnItemLongPressedListener(ScriptFunction callback)
{
	this->onItemLongPressedListener = callback;
}

void FirstScreenListWidget::setOnItemChangedListener(ScriptFunction callback)
{
	this->onItemChangedListener = callback;
}

FirstScreenCategory* FirstScreenListWidget::findCategory(std::string id)
{
	map<std::string, FirstScreenCategory*>::iterator it = categoryTagMap.find(id);
	if (it != categoryTagMap.end())
	{
		return it->second;
	}

	return NULL;
}

FirstScreenContents* FirstScreenListWidget::findContents(std::string id)
{
	map<std::string, FirstScreenContents*>::iterator it = contentsTagMap.find(id);
	if (it != contentsTagMap.end())
	{
		return it->second;
	}

	return NULL;
}

int FirstScreenListWidget::getLastMouseMovedTime()
{
	return (int)mouseMoved;
}

void FirstScreenListWidget:: setFirstState() 
{
	clutter_actor_set_x(bar, CATEGORY_GAP);
	goal_position = CATEGORY_GAP;
	
	clutter_actor_set_y(bar, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
	clutter_timeline_start(timeline); 
	EVENT_FLAG = true;
	STOP_FLAG = false;



	/*
	if(extendIndex != 0) {

		ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
		ClutterActor * categoryWrapper = clutter_actor_get_child_at_index(categoryItem, 0);;
	
		// extend
		map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(categoryWrapper);
		FirstScreenCategory* ctr = NULL;

		if (it != categoryActorMap.end())
		{
			ctr = it->second;
			if(ctr->id == "featured") { 

				extendAnimation();
			}
		}
	}
	*/
}

void FirstScreenListWidget:: returnAnimation() 
{
	extendAnimation();
}

/*
rotateWgt_Y_axis[shuhao.yan]
rotate the actor by the Y axis(based on the value of REVERSE_OSD)
*/
void FirstScreenListWidget::rotateWgt_Y_axis(ClutterActor* actor)
{
	if (REVERSE_OSD)
	{
		clutter_actor_set_rotation_angle(actor, CLUTTER_Y_AXIS, 180);
	}
	else
	{
		clutter_actor_set_rotation_angle(actor, CLUTTER_Y_AXIS, 0);
	}
}

/*
reverseOSD[shuhao.yan]
reverse the FirstScreenList Widget
Param: bool reverseFlag
true to reverse List
false to recover the original layout
*/
void FirstScreenListWidget::reverseOSD(bool reverseFlag)
{

	// set the reverse OSD Flag and rotate the root Scene[shuhao.yan]
	if (false == reverseFlag)
	{
		if (!REVERSE_OSD)
		{
			return;
		}
		SCENEROOT->setRotation(Vector3(0, 0, 0));
		REVERSE_OSD = false;
	}
	else
	{
		if (REVERSE_OSD)
		{
			return;
		}
		SCENEROOT->setRotation(Vector3(0, 180, 0));
		REVERSE_OSD = true;
	}

	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;

	ClutterActor *categoryTitle = NULL;
	ClutterActor *liveParent1 = NULL;
	ClutterActor *liveParent2 = NULL;
	
	std::string childName;
	int contentsCounts = 0;

	// 2> rotate the category items
	int categoriesCounts = clutter_actor_get_n_children(bar);
	
	int i, j;
	for( i = 0; i < categoriesCounts; i++ )
	{
		currentChild = clutter_actor_get_child_at_index(bar, i);

		childName = clutter_actor_get_name(currentChild);
		LOG_FATAL(logger, "[shuhao.yan]FirstScreen The Category NAME::" << childName);

		categoryTitle = clutter_actor_get_child_at_index(currentChild, 1);
		liveParent1   = clutter_actor_get_child_at_index(currentChild, 4);
		liveParent2	  = clutter_actor_get_child_at_index(currentChild, 5);
		rotateWgt_Y_axis(categoryTitle);
		rotateWgt_Y_axis(liveParent1);
		rotateWgt_Y_axis(liveParent2);

		currentList = clutter_actor_get_child_at_index(currentChild, 2);
		contentsCounts = clutter_actor_get_n_children(currentList);

		// 3> rotate each contents in the categories
		for( j = 0; j < contentsCounts; j++ )
		{
			currentChild = clutter_actor_get_child_at_index(currentList, j);
			rotateWgt_Y_axis(currentChild);
		}
		
		LOG_FATAL(logger, "[shuhao.yan]The counts of the Contents is ::" << contentsCounts);
	}

}



