/*
 * ImageWidget.cpp
 *
 *  Created on: May 23, 2013
 *      Author: reza, jim.dinunzio
 */

#include "ImageWidget.h"
#include "Image.h"
#include "ResourceLoader.h"
#include "VoltActor.h"
#include <vector>

using namespace volt::graphics;

int ImageWidget::nextLoadImageReceiverID = 0;
std::unordered_map<int, ImageWidget*> ImageWidget::loadImageReceivers;
std::string ImageWidget::LOGGER_NAME = "volt.imageWidget";

ImageWidget::ImageWidget(float x, float y, Widget* aParent, ImageWidgetReadyCallback ready)
  : scaleImageDimensions(false),
    onReady(ready),
    isReady(false),
    fillMode(Stretch),
    loadImageReceiverID(-1),
    asyncLoad(true),
    logger_(LOGGER_NAME)
{
  LOG_DEBUG(logger_, "Born (" << this << ")");
  actor = volt_actor_new();
  init(x,y, aParent);
  setColor(Color(0,0,0,0));
}

ImageWidget::ImageWidget(float x, float y, float width, float height, Widget* aParent, ImageWidgetReadyCallback ready)
  : Widget(x, y, width, height, aParent),
    scaleImageDimensions(width >= 0 || height >= 0),
    onReady(ready),
    isReady(false),
    fillMode(Stretch),
    loadImageReceiverID(-1),
    asyncLoad(true),
    logger_(LOGGER_NAME)

{
  LOG_DEBUG(logger_, "Born (" << this << ")");
  setColor(Color(0,0,0,0));
}

ImageWidget::~ImageWidget()
{
  LOG_DEBUG(logger_, "Dead (" << this << ")");
  CancelLoadImage();

  if (imageSource)
  {
    imageSource->RemoveActor(actor);
  }
}

void ImageWidget::setSource(const std::string& imageUri)
{
	CancelLoadImage();
	
  if (imageSource.get())
  {
    imageSource->RemoveActor(actor);
    imageSource.reset();
  }

  imageSourceUri = imageUri;

  if(imageUri == "")
  {
    clutter_actor_set_content(actor, NULL);
  }
  else
  {
    BeginLoadImage(imageUri);
  }
}

void ImageWidget::setSource(const uint8_t *buffer, unsigned int length)
{
  volt::util::Logger logger(ResourceLoader::LOGGER_NAME);

  if(not buffer or not length)
  {
    LOG_ERROR(logger, "null buffer or length, failed to set buffer as image source");
    return;
  }

  if (imageSource.get())
  {
    imageSource->RemoveActor(actor);
    imageSource.reset();
  }

  // load raw image buffer here..
  ResourceLoader::Instance().LoadImage(this, buffer, length);
}

void ImageWidget::setSource(Image *aImage)
{
  if (aImage)
  {
    imageSourceUri = aImage->uri();

    if (imageSource.get())
    {
      imageSource->RemoveActor(actor);
    }

    imageSource = aImage->getSharedPtr();
    imageSource->AddActor(actor);

    if (imageSource->image())
    {
      onImageLoaded(imageSource->image(), true);
    }
    else if (imageSource->async())
    {
      /* assuming it's still loading... */
      imageSource->RegisterOnLoadCallback(this,
                                          std::bind(&ImageWidget::OnImageLoadedCallback,
                                              this, std::placeholders::_1));
    }
  }
}

Image* ImageWidget::getSourceImage() const
{
  return imageSource.get();
}

void ImageWidget::setFillMode(FillMode mode)
{
  if (isReady)
  {
    clutter_actor_set_content_gravity(actor, ClutterContentGravity(mode));
  }

  fillMode = mode;
}

bool ImageWidget::getColorPicking(int percentage, Color* color)
{
  if (NULL == color)
  {
    LOG_FATAL(logger_, "Color address cannot be NULL!");
    return false;
  }
  color->r = color->g = color->b = 0;

  ClutterContent* image = clutter_actor_get_content(actor);
  if (VOLT_IS_IMAGE(image) == FALSE)
  {
    return false;
  }

  GdkPixbufAnimation* pixbufAnim = volt_image_get_pixbuf_anim(VOLT_IMAGE(image));
  if (NULL == pixbufAnim)
  {
    LOG_FATAL(logger_, "Get pixbuf anim failed!");
    return false;
  }

  GdkPixbuf *pixbuf = gdk_pixbuf_animation_get_static_image(pixbufAnim);
  if (NULL == pixbuf)
  {
    LOG_FATAL(logger_, "Get pixbuf from pixbuf_anim failed!");
    return false;
  }

  gboolean retVal = false;
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  GdkPickColor pick_color = { 0, };
  pick_color.perc = percentage;
  retVal = gdk_pixbuf_get_colorpick(pixbuf, &pick_color);
  LOG_DEBUG(logger_, "Get color_picking, r:" << pick_color.R << "g:" << pick_color.G << "b:" << pick_color.B);
  color->r = pick_color.R;
  color->g = pick_color.G;
  color->b = pick_color.B;
#else
  retVal = true;
  color->r = 0;
  color->g = 0;
  color->b = 0;
#endif
  return retVal;
}

std::string ImageWidget::getSource() const
{
  return imageSourceUri;
}

void ImageWidget::setAsyncLoading(const bool async)
{
  asyncLoad = async;
}

bool ImageWidget::getAsyncLoading() const
{
  return asyncLoad;
}

float ImageWidget::getWidth() const
{
  return clutter_actor_get_width(actor);
}

void ImageWidget::setWidth(float width)
{
  if (width < 0)
  {
    return;
  }

  scaleImageDimensions = true;
  Widget::setWidth(width);
}

float ImageWidget::getHeight() const
{
  return clutter_actor_get_height(actor);
}

void ImageWidget::setHeight(float height)
{
  if (height < 0)
  {
    return;
  }

  scaleImageDimensions = true;
  Widget::setHeight(height);
}

void ImageWidget::BeginLoadImage(std::string imageUri)
{
  //register for callback
  loadImageReceivers[nextLoadImageReceiverID] = this;

  //Start load image
  ImageLoadedCallback callback = std::bind(ImageWidget::onImageLoadedRouter, nextLoadImageReceiverID, std::placeholders::_1, std::placeholders::_2);
  bool success = ResourceLoader::Instance().LoadImage(callback, imageUri, asyncLoad, COGL_TEXTURE_NO_ATLAS);

  if (!success) //if it fails here invoke the failure logic. If it succeeds, it may still fail later so wait for the async callback
  {
    callback(nullptr, false);
  }

  loadImageReceiverID = nextLoadImageReceiverID;
  nextLoadImageReceiverID++;
}

void ImageWidget::onImageLoadedRouter(int receiverID, VoltImage* image, bool success)
{
  if (loadImageReceivers.count(receiverID))
  {
    //Load the image
    ImageWidget* receiver = loadImageReceivers[receiverID];
    receiver->onImageLoaded(image, success);

    //Unregister for callbacks
    receiver->CancelLoadImage();
  }
}


void ImageWidget::onImageLoaded(VoltImage* image, bool success)
{
  if (success)
  {
    attachVoltImage(image);
  }

  isReady = success;

  if (onReady != nullptr)
  {
    onReady(success);
  }
}

void ImageWidget::attachVoltImage(VoltImage* image)
{
  volt::util::Logger logger(ResourceLoader::LOGGER_NAME);

  GdkPixbufAnimation *pixbufAnim = volt_image_get_pixbuf_anim(VOLT_IMAGE(image));
  gboolean isStatic = gdk_pixbuf_animation_is_static_image(pixbufAnim);

  if (!scaleImageDimensions)
  {
    bool size_ok = true;
    gfloat width, height;

    if (!isStatic && pixbufAnim) // Image is animated
    {
      width = gdk_pixbuf_animation_get_width(pixbufAnim);
      height = gdk_pixbuf_animation_get_height(pixbufAnim);

      // if this is an animated gif but we don't have an Image instance,
      // then display first frame for compatibility.
      if (!imageSource)
      {
        GError *error = NULL;
        GdkPixbuf *aPixbuf = gdk_pixbuf_animation_get_static_image(pixbufAnim);

        volt_image_set_data(image,
                            gdk_pixbuf_get_pixels(aPixbuf),
                            COGL_TEXTURE_NO_ATLAS,
                            gdk_pixbuf_get_has_alpha(aPixbuf)
                            ? COGL_PIXEL_FORMAT_RGBA_8888
                            : COGL_PIXEL_FORMAT_RGB_888,
                            gdk_pixbuf_get_width(aPixbuf),
                            gdk_pixbuf_get_height(aPixbuf),
                            gdk_pixbuf_get_rowstride(aPixbuf),
                            &error);
      }
    }
    else
    {
      size_ok = clutter_content_get_preferred_size(CLUTTER_CONTENT(image),
                &width, &height);
    }

    if (size_ok)
    {
      setWidth(width);
      setHeight(height);

      LOG_DEBUG(logger, "Scaled to the image size: " << width << "x" << height);
    }
  }

  clutter_actor_set_content(actor, CLUTTER_CONTENT(image));
  clutter_actor_set_content_gravity(actor, ClutterContentGravity(fillMode));
  volt_actor_shadow_update(VOLT_ACTOR(actor));
  LOG_DEBUG(logger, "Set image: " << imageSourceUri);
}

void ImageWidget::CancelLoadImage()
{
  if (loadImageReceiverID != -1)
  {
    loadImageReceivers.erase(loadImageReceiverID);
    loadImageReceiverID = -1;
  }

  if (imageSource)
  {
    imageSource->UnregisterOnLoadCallback(this);
  }
}

void ImageWidget::OnImageLoadedCallback(Image *aImage)
{
  if (aImage == nullptr)
  {
    return;
  }

  volt::util::Logger logger(ResourceLoader::LOGGER_NAME);
  bool success = true;

  if (aImage->image())
  {
    LOG_DEBUG(logger, "Image content ready: " << aImage->uri());
  }
  else
  {
    LOG_WARN(logger, "Failed to load image content: " << aImage->uri());
    success = false;
  }

  onImageLoaded(aImage->image(), success);
}
