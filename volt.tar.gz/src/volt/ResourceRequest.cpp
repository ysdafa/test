/*
 * ResourceRequest.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "ResourceRequest.h"

#include "Exception.h"

#include "string_util.h"

using namespace volt::util;

std::string ResourceRequest::LOGGER_NAME = "volt.resource.request";

ResourceRequest::ResourceRequest(const std::string &aUrl):
  logger_(LOGGER_NAME), headers_(),
  id_(0), requestHandle_(0), uri_(aUrl), async_(true), recursive_(false),
  success_callback_(), error_callback_(),
  complete_callback_(), async_callback_(), method_("GET"),
  data_(), src_(), status_(0), response_type_("string"), no_cache_(false)
{
  LOG_DEBUG(logger_, "Born: " << uri_);
}

ResourceRequest::~ResourceRequest()
{
  LOG_DEBUG(logger_, "Dead(" << id_ << "): " << uri_);
}

bool ResourceRequest::AddHeader(const std::string &aName,
                                const std::string &aValue)
{
  std::string name = aName;
  volt::util::Trim(name);

  if(name.length() == 0 ||
     name.find(':') != std::string::npos)
  {
    LOG_DEBUG(logger_, "Invalid header field name: " << name);
    return false;
  }

  LOG_DEBUG(logger_, "Add header: " << name << ": " << aValue);
  headers_.push_back(HeaderInfo(name, aValue));
  return true;
}

bool ResourceRequest::RemoveHeader(const std::string &aName,
                                   const bool &aRemoveAll)
{
  std::string name = aName;
  volt::util::Trim(name);

  if(name.length() == 0 ||
     name.find(':') != std::string::npos)
  {
    LOG_DEBUG(logger_, "Invalid header field name: " << name);
    return false;
  }

  bool retval = false;
  auto iter = headers_.begin();

  while (iter != headers_.end())
  {
    if(iter->name == name)
    {
      LOG_DEBUG(logger_, "Remove header: " << iter->name << ": " << iter->value);
      iter = headers_.erase(iter);
      retval = true;

      if (aRemoveAll == false)
      {
        break;
      }
    }
    else
    {
      ++iter;
    }
  }

  return retval;
}

void ResourceRequest::ClearHeaders()
{
  headers_.clear();
}

void ResourceRequest::SetHeaderBlock(const std::string &aHeaders)
{
  if(aHeaders.length() == 0)
  {
    return;
  }

  const char *start = aHeaders.c_str();

  const char *end = start + aHeaders.length();

  const char *current = start;

  const char *colon = strchr(current, ':');

  while(colon)
  {
    std::string header_name(current, colon - current);

    const char *quote1 = strstr(current, "'");

    if(quote1 == NULL || quote1 + 1 >= end)
    {
      return;
    }

    const char *quote2 = strstr(quote1 + 1, "'");

    if(quote2 == NULL)
    {
      return;
    }

    std::string header_value(quote1 + 1, quote2);

    AddHeader(header_name, header_value);

    current = quote2 + 1;

    // find start of next field
    while(current < end)
    {
      if(*current == ',' || *current == ' ' || *current == '\n')
      {
        current++;
      }
      else
      {
        break;
      }
    }

    if(current >= end)
    {
      break;
    }

    colon = strchr(current, ':');
  }
}

const ResourceRequest::HeaderList& ResourceRequest::GetHeaders() const
{
  return headers_;
}
