#include "StaticUI.h"

#include <string.h>

#include "ImageWidget.h"
#include "TextWidget.h"
#include "SceneRoot.h"

#include "VoltMessageCenter.h"
#include "VoltRuntimeMessages.h"

#include "VoltProcessManager.h"
#include "VoltFullProcessRuntime.h"

using namespace volt::graphics;

namespace volt
{

util::Logger StaticUI::LOGGER("volt.staticui");

StaticUI& StaticUI::Instance()
{
  static StaticUI instance;
  return instance;
}

StaticUI::StaticUI():
  scene_root_(), splash_screen_(nullptr),
  exception_popup_visible_(false), engine_(nullptr)
{
}

StaticUI::~StaticUI()
{
  Detach();
}

void StaticUI::Attach(Bridge::ScriptEngine *aEngine)
{
  engine_ = aEngine;
}

void StaticUI::Detach()
{
  engine_ = nullptr;
  splash_screen_ = nullptr;
}

void StaticUI::ShowSplashScreen(const std::string &aAppJs,
                                const VoltEventArgsMap &aData,
                                const std::string &aAppName,
                                const std::string &aAppIcon)
{
  if (engine_ == nullptr)
  {
    return;
  }

  if (!scene_root_)
  {
    if (VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS)
    {
      VoltFullProcessRuntime *runtime =
        static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

      if (runtime->GetMainStage())
      {
        scene_root_.reset(new SceneRoot((ClutterActor*) runtime->GetMainStage()));
      }
      else
      {
        LOG_FATAL(LOGGER, "Failed create splash screen");
        return;
      }
    }
    else
    {
      LOG_DEBUG(LOGGER, "Not showing splash screen on a worker process");
      return;
    }
  }

  if (splash_screen_ == nullptr)
  {
    splash_screen_ =
      new Widget(0, 0, scene_root_->getWidth(), scene_root_->getHeight());
    splash_screen_->setColor(Color(5, 20, 10, 255));

    // The Element coordinates
    unsigned int iconX;
    unsigned int iconY;
    unsigned int iconW;
    unsigned int iconH;

    unsigned int appTitleX;
    unsigned int appTitleY;
    unsigned int appTitleW;
    unsigned int appTitleH;

    unsigned int loadingTitleX;
    unsigned int loadingTitleY;
    unsigned int loadingTitleW;
    unsigned int loadingTitleH;

    unsigned int infoTitleX;
    unsigned int infoTitleY;
    unsigned int infoTitleW;
    unsigned int infoTitleH;

    // The title font size
    std::string appTitlefont;
    std::string loadingTitlefont;
    std::string infoTitlefont;

    if (scene_root_->getHeight() == 720)
    {
      // resolution  720P
      iconX = 597;
      iconY = 277;
      iconW = 85;
      iconH = 70;

      appTitleX = 100;
      appTitleY = 370;
      appTitleW = 1080;
      appTitleH = 34;

      loadingTitleX = 500;
      loadingTitleY = 450;
      loadingTitleW = 280;
      loadingTitleH = 26;

      infoTitleX = 100;
      infoTitleY = 644;
      infoTitleW = 1080;
      infoTitleH = 26;

      appTitlefont = "33px";
      loadingTitlefont = "24px";
      infoTitlefont = "24px";

    }
    else
    {
      // resolution  1080P
      iconX = 872;
      iconY = 432;
      iconW = 106;
      iconH = 87;

      appTitleX = 150;
      appTitleY = 555;
      appTitleW = 1620;
      appTitleH = 52;

      loadingTitleX = 750;
      loadingTitleY = 676;
      loadingTitleW = 420;
      loadingTitleH = 40;

      infoTitleX = 150;
      infoTitleY = 966;
      infoTitleW = 1620;
      infoTitleH = 40;

      appTitlefont = "50px";
      loadingTitlefont = "36px";
      infoTitlefont = "36px";
    }

    // Set Title Color
    Color appTitlefont_color(255, 255, 255, 255);
    Color loadingTitlefont_color(230, 230, 230, 255);
    Color infoTitlefont_color(178, 178, 178, 255);

    // Create App Icon thumbnail

    ImageWidget *appIconWgt = new ImageWidget(iconX, iconY, splash_screen_);

    appIconWgt->setAsyncLoading(false);
    appIconWgt->setSource(aAppIcon);
    appIconWgt->setWidth(iconW);
    appIconWgt->setHeight(iconH);
    splash_screen_->addChild(appIconWgt);

    /*
    // Create Loading Icon
    std::string lodingIconPath = "file://$VOLT_ROOT/data/loading/loading_01.png";

    ImageWidget *loadingIconWgt = new ImageWidget(loadingIconX, loadingIconY, splash_screen_);

    loadingIconWgt->setAsyncLoading(false);
    loadingIconWgt->setSource(lodingIconPath);
    loadingIconWgt->setWidth(loadingIconW);
    loadingIconWgt->setHeight(loadingIconH);
    splash_screen_->addChild(loadingIconWgt);
    */

    // Create App Title
    TextWidget *appTitle_text_widget =
      new TextWidget(appTitleX, appTitleY, aAppName, appTitlefont, NULL, appTitlefont_color);
    appTitle_text_widget->setWidth(appTitleW);
    appTitle_text_widget->setHeight(appTitleH);
    appTitle_text_widget->setHorizontalAlignment(Center);
    appTitle_text_widget->setVerticalAlignment(Middle);

    splash_screen_->addChild(appTitle_text_widget);

    // Create Loading Title
    TextWidget *loadingTitle_text_widget =
      new TextWidget(loadingTitleX, loadingTitleY, "Loading......", loadingTitlefont, NULL, loadingTitlefont_color);
    loadingTitle_text_widget->setWidth(loadingTitleW);
    loadingTitle_text_widget->setHeight(loadingTitleH);
    loadingTitle_text_widget->setHorizontalAlignment(Center);
    loadingTitle_text_widget->setVerticalAlignment(Middle);

    splash_screen_->addChild(loadingTitle_text_widget);

    // Create Info Title
    std::string info_text = "Pin:Press and hold the button on the apps panel, You can edit an app directly!";
    TextWidget *infoTitle_text_widget =
      new TextWidget(infoTitleX, infoTitleY, info_text, infoTitlefont, NULL, infoTitlefont_color);
    infoTitle_text_widget->setWidth(infoTitleW);
    infoTitle_text_widget->setHeight(infoTitleH);
    infoTitle_text_widget->setHorizontalAlignment(Center);
    infoTitle_text_widget->setVerticalAlignment(Middle);

    splash_screen_->addChild(infoTitle_text_widget);
  }

  if (scene_root_->getChildByName("splash_screen") != splash_screen_)
  {
    scene_root_->addChild(splash_screen_);
  }

  InterthreadData *data = new InterthreadData(aAppJs, aData);
  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE, LoadAppJS, data, NULL);
}

void StaticUI::HideSplashScreen()
{
  if (splash_screen_)
  {
    splash_screen_->hide();
    scene_root_->removeChild(splash_screen_);
  }
}

void StaticUI::ShowExceptionPopup(const char *aMsg,
                                  const VoltJsException *aException)
{
  /* Format text */
  char msg[1024];

  if (aException)
  {
    if (aException->stack_trace().length() > 0)
    {
      snprintf(msg, sizeof(msg) / sizeof(msg[0]),
               "%s\n"
               "%s%s"
               "%s",
               aMsg ? aMsg : "Encountered fatal error",
               aException->msg() ? aException->msg() : "",
               aException->msg() ? "\n" : "",
               aException->stack_trace().c_str());
    }
    else
    {
      snprintf(msg, sizeof(msg) / sizeof(msg[0]),
               "%s\n"
               "%s%s"
               "%s",
               aMsg ? aMsg : "Encountered fatal error",
               aException->msg() ? aException->msg() : "",
               aException->msg() ? "\n" : "",
               aException->js_msg().c_str());
    }
  }
  else
  {
    snprintf(msg, sizeof(msg) / sizeof(msg[0]),
             "%s\n", aMsg ? aMsg : "Encountered fatal error");
  }

  LOG_FATAL(LOGGER, "Exception: " << msg);

  if (!scene_root_)
  {
    VoltFullProcessRuntime *runtime =
      static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

    if (VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS)
    {
      if (runtime->GetMainStage())
      {
        scene_root_.reset(new SceneRoot((ClutterActor*) runtime->GetMainStage()));
      }
      else
      {
        LOG_FATAL(LOGGER, "Failed create exception screen");
        return;
      }
    }
    else
    {
      LOG_DEBUG(LOGGER, "Not showing exception screen on a worker process");
      std::string parent_id = VoltMessageCenter::Instance().ParentProcessID();
      VoltMessageCenter::Instance().PostMsgToWorker(parent_id,
          VoltRuntimeMsg::OnException(),
          msg, strlen(msg) + 1);
      runtime->Quit();
      return;
    }
  }

  Widget *rect_widget =
    new Widget(0, 0, scene_root_->getWidth(), scene_root_->getHeight(),
               scene_root_.get());
  rect_widget->setColor(Color(0, 0, 0, 220));

  std::string msg_font = "32px";
  TextWidget::canonicalizeFont(msg_font);

  TextWidget *text_widget =
    new TextWidget(0, 0, msg, msg_font, rect_widget, Color(232, 95, 21, 255));
  text_widget->setWidth(scene_root_->getWidth());
  text_widget->setHeight(scene_root_->getHeight());
  text_widget->setHorizontalAlignment(Center);
  text_widget->setVerticalAlignment(Middle);

  std::string dissmiss_font = "24px";
  TextWidget::canonicalizeFont(dissmiss_font);

  TextWidget *dismiss_text_widget =
    new TextWidget(0, 0, "Press EXIT/RETURN to dismiss this message and exit",
                   dissmiss_font, rect_widget, Color(232, 95, 21, 255));
  dismiss_text_widget->setWidth(scene_root_->getWidth());
  dismiss_text_widget->setHeight(scene_root_->getHeight());
  dismiss_text_widget->setHorizontalAlignment(Center);
  dismiss_text_widget->setOrigin(Vector2(0, 0.9));

  exception_popup_visible_ = true;
}

bool StaticUI::ExceptionPopupVisible() const
{
  return exception_popup_visible_;
}

gboolean StaticUI::LoadAppJS(gpointer aData)
{
  InterthreadData *data = reinterpret_cast<InterthreadData *>(aData);

  if (Instance().engine_)
  {
    try
    {
      if (Instance().engine_->loadScript(data->first, data->second))
      {
        Instance().HideSplashScreen();
      }
    }
    catch (VoltJsInitException &e)
    {
      LOG_FATAL(LOGGER, "Exiting due to JS initialization error: " << e.what());
      /* clutter main loop not started yet */
      Instance().ShowExceptionPopup("Encountered fatal error on initialization", &e);
    }
  }

  delete data;

  return FALSE;
}

} /* namespace volt */
