/*
 * VoltText.cpp
 *
 *  Created on: June 25, 2014
 *      Author: jim dinunzio
 */


#include "VoltText.h"
#include "CustomEffect.h"
#include <cogl-pango/cogl-pango.h>
#include <math.h>

#define CLUTTER_PARAM_READWRITE static_cast<GParamFlags>(G_PARAM_READABLE | G_PARAM_WRITABLE | G_PARAM_STATIC_STRINGS)

extern "C" {
  void clutter_text_dirty_cache (ClutterText *text);
}

/**
 * VoltText:
 *
 * The #VoltText struct contains only private data.
 *
 * Since: 1.0
 */
struct _VoltText
{
  /*< private >*/
  ClutterText parent_instance;

  gint line_spacing;
  gboolean has_shadow;
  gfloat shadow_x_offset;
  gfloat shadow_y_offset;
  ClutterColor shadow_color;
  gboolean clip_set;
};

/**
 * VoltTextClass:
 * @text_changed: class handler for the #VoltText::text-changed signal
 * @activate: class handler for the #VoltText::activate signal
 * @cursor_event: class handler for the #VoltText::cursor_event signal
 *
 * The #VoltTextClass struct contains only private data.
 *
 * Since: 1.0
 */
struct _VoltTextClass
{
  /*< private >*/
  ClutterTextClass parent_class;
};

G_DEFINE_TYPE(VoltText, volt_text, CLUTTER_TYPE_TEXT);

enum
{
  PROP_0,

  PROP_LINE_SPACING,
  PROP_SHADOW_X_OFFSET,
  PROP_SHADOW_Y_OFFSET,
  PROP_SHADOW_COLOR,

  PROP_LAST
};

static GParamSpec *obj_props[PROP_LAST];

static void
volt_text_set_property (GObject      *gobject,
                        guint         prop_id,
                        const GValue *value,
                        GParamSpec   *pspec)
{
  VoltText *self = VOLT_TEXT (gobject);

  switch (prop_id)
  {
  case PROP_LINE_SPACING:
    volt_text_set_line_spacing (self, g_value_get_int (value));
    break;

  case PROP_SHADOW_X_OFFSET:
    volt_text_set_shadow_x_offset(self, g_value_get_float (value));
    break;

  case PROP_SHADOW_Y_OFFSET:
    volt_text_set_shadow_y_offset(self, g_value_get_float (value));
    break;

  case PROP_SHADOW_COLOR:
    volt_text_set_shadow_color(self, clutter_value_get_color(value));
    break;

  default:
    G_OBJECT_WARN_INVALID_PROPERTY_ID (gobject, prop_id, pspec);
  }
}

static void
volt_text_get_property (GObject    *gobject,
                        guint       prop_id,
                        GValue     *value,
                        GParamSpec *pspec)
{
  VoltText *self = VOLT_TEXT (gobject);

  switch (prop_id)
  {
  case PROP_LINE_SPACING:
    g_value_set_int(value, volt_text_get_line_spacing (self));
    break;

  case PROP_SHADOW_X_OFFSET:
    g_value_set_float(value, volt_text_get_shadow_x_offset(self));
    break;

  case PROP_SHADOW_Y_OFFSET:
    g_value_set_float(value, volt_text_get_shadow_y_offset(self));
    break;

  case PROP_SHADOW_COLOR:
    ClutterColor color;
    volt_text_get_shadow_color(self, &color);
    clutter_value_set_color(value, &color);
    break;

  default:
    G_OBJECT_WARN_INVALID_PROPERTY_ID (gobject, prop_id, pspec);
  }
}

static void
volt_text_enlarge_allocation(VoltText *self, ClutterVertex *origin, gfloat *width, gfloat *height)
{
  *width += fabs(self->shadow_x_offset);
  *height += fabs(self->shadow_y_offset);

  if (self->shadow_x_offset < 0)
  {
    origin->x += self->shadow_x_offset;
  }

  if (self->shadow_y_offset < 0)
  {
    origin->y += self->shadow_y_offset;
  }
}

static gboolean
volt_text_get_paint_volume(ClutterActor       *self,
                           ClutterPaintVolume *volume)
{
  VoltText *voltText = VOLT_TEXT(self);
  gfloat width, height;
  ClutterVertex origin;

  gboolean result =
    CLUTTER_ACTOR_CLASS(volt_text_parent_class)->get_paint_volume(self, volume);

  // we need to add in the shadow area to the paint volume
  if (voltText->has_shadow)
  {
    clutter_paint_volume_get_origin(volume, &origin);
    width = clutter_paint_volume_get_width(volume);
    height = clutter_paint_volume_get_height(volume);

    volt_text_enlarge_allocation(voltText, &origin, &width, &height);
    clutter_paint_volume_set_width(volume, width);
    clutter_paint_volume_set_height(volume, height);
    clutter_paint_volume_set_origin(volume, &origin);
  }

  return result;
}

void volt_text_class_init (VoltTextClass *klass)
{
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);
  GParamSpec *pspec;

  gobject_class->set_property = volt_text_set_property;
  gobject_class->get_property = volt_text_get_property;

  ClutterActorClass *actor_class = CLUTTER_ACTOR_CLASS(klass);
  actor_class->get_paint_volume = volt_text_get_paint_volume;

  /**
  * VoltText:line-spacing:
  *
  * The amount of spacing between lines of text, in pixels, negative ok.
  */
  pspec = g_param_spec_int ("line-spacing",
                            "Line Spacing",
                            "The amount of spacing between lines of text, in pixels, negative ok.",
                            G_MININT, G_MAXINT, 0,
                            CLUTTER_PARAM_READWRITE);
  obj_props[PROP_LINE_SPACING] = pspec;

  pspec = g_param_spec_float ("shadow-x-offset",
                              "Shadow X Offset",
                              "The horizontal offset of the shadow, negative ok.",
                              -G_MAXFLOAT, G_MAXFLOAT, 0,
                              CLUTTER_PARAM_READWRITE);
  obj_props[PROP_SHADOW_X_OFFSET] = pspec;

  pspec = g_param_spec_float ("shadow-y-offset",
                              "Shadow Y Offset",
                              "The vertical offset of the shadow, negative ok.",
                              -G_MAXFLOAT, G_MAXFLOAT, 0,
                              CLUTTER_PARAM_READWRITE);
  obj_props[PROP_SHADOW_Y_OFFSET] = pspec;

  pspec = clutter_param_spec_color("text-shadow-color",
                                   "Text Shadow Color",
                                   "The color of the text shadow.",
                                   CLUTTER_COLOR_Transparent,
                                   CLUTTER_PARAM_READWRITE);
  obj_props[PROP_SHADOW_COLOR] = pspec;

  g_object_class_install_properties (gobject_class, PROP_LAST, obj_props);
}


static void
volt_text_create_layout_cb (ClutterText   *self,
                            PangoLayout   *layout)
{
  g_return_if_fail (VOLT_IS_TEXT (self));

  VoltText* voltText = VOLT_TEXT(self);

  if (layout)
  {
    pango_layout_set_spacing(layout, voltText->line_spacing * PANGO_SCALE);
  }
}


const char* TEXT_SHADOW_EFFECT = "TEXT_SHADOW_EFFECT";
gboolean volt_text_pre_paint_cb(CCustomEffect* effect);
void volt_text_post_paint_cb(CCustomEffect* effect);

static void
volt_text_init (VoltText *self)
{
  self->line_spacing = 0;
  self->has_shadow = FALSE;
  self->shadow_color = *CLUTTER_COLOR_Black;
  self->shadow_x_offset = 0;
  self->shadow_y_offset = 0;
  self->clip_set = FALSE;

  clutter_text_set_create_layout_cb (CLUTTER_TEXT(self), volt_text_create_layout_cb);
  ClutterEffect* effect = custom_effect_new();
  custom_effect_set_pre_paint_cb(CUSTOM_EFFECT(effect), volt_text_pre_paint_cb);
  custom_effect_set_post_paint_cb(CUSTOM_EFFECT(effect), volt_text_post_paint_cb);
  clutter_actor_add_effect_with_name(CLUTTER_ACTOR(self), TEXT_SHADOW_EFFECT, effect);
}

static void
volt_text_pre_paint_real_cb (VoltText *actor)
{
  PangoLayout *layout;
  guint8 real_opacity;
  CoglColor color;
  ClutterText *text = CLUTTER_TEXT (actor);
  ClutterColor text_color = { 0, };
  ClutterActorBox alloc = { 0, }, allocOrig = { 0, };
  gboolean clip_set = FALSE;

  /* Get the PangoLayout that the Text actor is going to paint */
  layout = clutter_text_get_layout (text);

  clutter_actor_get_allocation_box (CLUTTER_ACTOR(actor), &alloc);
  allocOrig = alloc; // save original allocation of actor
  PangoRectangle logical_rect = { 0, };
  pango_layout_get_pixel_extents (layout, NULL, &logical_rect);
  gboolean allocSmallerThanLayout =
    logical_rect.width > (alloc.x2 - alloc.x1) ||
    logical_rect.height > (alloc.y2 - alloc.y1);

  if (actor->has_shadow)
  {
    // Add clip for shadow if allocation is smaller than layout extents
    if (allocSmallerThanLayout)
    {
      clutter_actor_box_set_origin(&alloc,
                                   alloc.x1 + actor->shadow_x_offset,
                                   alloc.y1 + actor->shadow_y_offset);
      cogl_clip_push_rectangle (alloc.x1, alloc.y1,
                                alloc.x2, alloc.y2);
      clip_set = TRUE;
    }

    /* Get the color of the text, to extract the alpha component */
    clutter_text_get_color (text, &text_color);

    /* Composite the opacity so that the shadow is correctly blended */
    real_opacity = clutter_actor_get_paint_opacity (CLUTTER_ACTOR(actor))
                   * text_color.alpha
                   / 255;

    /* get color and premultiply it */
    ClutterColor shadow_color;
    volt_text_get_shadow_color(actor, &shadow_color);
    cogl_color_init_from_4ub (&color, shadow_color.red, shadow_color.green, shadow_color.blue,
                              shadow_color.alpha * real_opacity / 255);
    cogl_color_premultiply (&color);

    /* Finally, render the Text layout at a given offset using the color */
    cogl_pango_render_layout (layout, volt_text_get_shadow_x_offset(actor),
                              volt_text_get_shadow_y_offset(actor), &color, 0);

    if (clip_set)
    {
      cogl_clip_pop ();
    }
  }

  // if allocation is smaller than layout and line spacing > 0 and ellipsizing then
  // add clipping region to fix a bug in pango that draws outside the allocation.
  if (allocSmallerThanLayout &&
      clutter_text_get_ellipsize(CLUTTER_TEXT(actor)) &&
      volt_text_get_line_spacing(actor) > 0.0f)
  {
    cogl_clip_push_rectangle(allocOrig.x1, allocOrig.y1,
                             allocOrig.x2, allocOrig.y2);
    actor->clip_set = TRUE;
  }
}

static void
volt_text_post_paint_real_cb(VoltText *actor)
{
  if (actor->clip_set)
  {
    cogl_clip_pop();
    actor->clip_set = FALSE;
  }
}

/**
 * volt_text_set_line_spacing:
 * @self: a #VoltText
 * @line_spacing: the amount of spacing between lines of text, in pixels, negative ok
 *
 * Sets the amount of spacing between lines of text.
 *
 */

void
volt_text_set_line_spacing (VoltText *self,
                            gint line_spacing)
{
  g_return_if_fail (VOLT_IS_TEXT (self));

  if (self->line_spacing != line_spacing)
  {
    self->line_spacing = line_spacing;

    clutter_text_dirty_cache (CLUTTER_TEXT(self));
    clutter_actor_queue_relayout (CLUTTER_ACTOR (self));

    g_object_notify_by_pspec (G_OBJECT (self), obj_props[PROP_LINE_SPACING]);
  }
}

/**
 * volt_text_get_line_spacing:
 * @self: a #VoltText
 *
 * Retrieves the amount of spacing between lines of text of a #VoltText actor,
 *
 * Return value: The amount of spacing between lines of text, in pixels. May be negative.
 *
 */
gint
volt_text_get_line_spacing (VoltText *self)
{
  g_return_val_if_fail (VOLT_IS_TEXT (self), 0);

  return self->line_spacing;
}

gboolean volt_text_get_has_shadow (VoltText *self)
{
  g_return_val_if_fail (VOLT_IS_TEXT (self), FALSE);

  return self->has_shadow;
}

gfloat volt_text_get_shadow_x_offset(VoltText *self)
{
  g_return_val_if_fail (VOLT_IS_TEXT (self), 0);

  return self->shadow_x_offset;
}

gfloat volt_text_get_shadow_y_offset(VoltText *self)
{
  g_return_val_if_fail (VOLT_IS_TEXT (self), 0);

  return self->shadow_y_offset;
}

void volt_text_get_shadow_color(VoltText *self, ClutterColor* color)
{
  g_return_if_fail (VOLT_IS_TEXT (self));

  *color = self->shadow_color;
}

gboolean volt_text_pre_paint_cb(CCustomEffect* effect)
{
  VoltText* actor = VOLT_TEXT(clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (effect)));

  volt_text_pre_paint_real_cb(actor);
  return TRUE;
}

void volt_text_post_paint_cb(CCustomEffect* effect)
{
  VoltText* actor = VOLT_TEXT(clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (effect)));
  volt_text_post_paint_real_cb(actor);
}

void volt_text_set_has_shadow(VoltText *self, gboolean has_shadow)
{
  g_return_if_fail (VOLT_IS_TEXT (self));

  if (has_shadow != self->has_shadow)
  {
    self->has_shadow = has_shadow;

    clutter_text_dirty_cache (CLUTTER_TEXT(self));
    clutter_actor_queue_relayout (CLUTTER_ACTOR (self));
  }
}

void volt_text_set_shadow_x_offset(VoltText *self, gfloat x_offset)
{
  g_return_if_fail (VOLT_IS_TEXT (self));

  if (x_offset != self->shadow_x_offset)
  {
    self->shadow_x_offset = x_offset;
    clutter_text_dirty_cache (CLUTTER_TEXT(self));
    clutter_actor_queue_relayout (CLUTTER_ACTOR (self));
    g_object_notify_by_pspec (G_OBJECT (self), obj_props[PROP_SHADOW_X_OFFSET]);
  }
}

void volt_text_set_shadow_y_offset(VoltText *self, gfloat y_offset)
{
  g_return_if_fail (VOLT_IS_TEXT (self));

  if (y_offset != self->shadow_y_offset)
  {
    self->shadow_y_offset = y_offset;
    clutter_text_dirty_cache (CLUTTER_TEXT(self));
    clutter_actor_queue_relayout (CLUTTER_ACTOR (self));
    g_object_notify_by_pspec (G_OBJECT (self), obj_props[PROP_SHADOW_Y_OFFSET]);
  }
}

void volt_text_set_shadow_color(VoltText *self, const ClutterColor* color)
{
  g_return_if_fail (VOLT_IS_TEXT (self));

  if (!clutter_color_equal(color, &self->shadow_color))
  {
    self->shadow_color = *color;
    clutter_actor_queue_redraw (CLUTTER_ACTOR (self));
    g_object_notify_by_pspec (G_OBJECT (self), obj_props[PROP_SHADOW_COLOR]);
  }
}

/**
 * volt_get_is_right_to_left:
 * @string: a #const gchar*
 *
 * Return value: TRUE if the given string is written right to left.
 *
 */
gboolean volt_get_is_right_to_left(const gchar* string)
{
  PangoDirection dir = pango_find_base_dir (string, -1);
  
  switch (dir)
  {
  case PANGO_DIRECTION_RTL:
  case PANGO_DIRECTION_TTB_RTL:
  case PANGO_DIRECTION_WEAK_RTL:
    return TRUE;
    break;
  default:
    return FALSE;
    break;
  }
}

/**
 * volt_text_get_is_right_to_left:
 * @self: a #VoltText
 *
 * Return value: TRUE if the given VoltText's text is right to left.
 * 
 */
gboolean volt_text_get_is_right_to_left(VoltText *self)
{
  return volt_get_is_right_to_left(clutter_text_get_text(CLUTTER_TEXT(self)));
}

/**
 * volt_text_new:
 *
 * Creates a new #VoltText actor. This actor can be used to
 * display and edit text.
 *
 * Return value: the newly created #VoltText actor
 *
 */
ClutterActor *
volt_text_new (void)
{
  return CLUTTER_ACTOR(g_object_new (VOLT_TYPE_TEXT, NULL));
}

/**
 * volt_text_new:
 *
 * @font_name: a string with a font description
 * @text: the contents of the actor
 * @color: the color to be used to render @text
 *
 * Creates a new #VoltText actor, using @font_name as the font
 * description; @text will be used to set the contents of the actor;
 * and @color will be used as the color to render @text.
 *
 * This function is equivalent to calling volt_text_new(),
 * clutter_text_set_font_name(), clutter_text_set_text() and
 * clutter_text_set_color().
 *
 * Return value: the newly created #VoltText actor
 *
 */
ClutterActor *
volt_text_new_full (const gchar        *font_name,
                    const gchar        *text,
                    const ClutterColor *color)
{
  return CLUTTER_ACTOR(g_object_new (VOLT_TYPE_TEXT,
                                     "font-name", font_name,
                                     "text", text,
                                     "color", color,
                                     NULL));
}

