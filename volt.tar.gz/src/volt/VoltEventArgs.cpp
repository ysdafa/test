#include "VoltEventArgs.h"

#include "AnyContainer.h"

/******************************************************************************
 * ByteArray
 *****************************************************************************/

namespace
{
/**
 * This is a helper class to contain info of byte array values.
 */
class ByteArray
{
  public:
    size_t size;
    uint8_t *bytes;

  public:
    ByteArray(): size(0), bytes(NULL) {}

    ByteArray(const size_t aSize, const uint8_t *aBytes):
      size(aSize), bytes(NULL)
    {
      if (size > 0)
      {
        bytes = new uint8_t[size];
        memmove(bytes, aBytes, size);
      }
    }

    ~ByteArray()
    {
      if (bytes)
      {
        delete [] bytes;
      }

      bytes = NULL;
    }

  private:
    ByteArray(const ByteArray &aSrc);
    ByteArray& operator=(const ByteArray &aRhs);
};
}

/******************************************************************************
 * VoltEventArgsMap
 *****************************************************************************/

VoltEventArgsMap::VoltEventArgsMap(): map_(new AnyMap())
{
}

VoltEventArgsMap::VoltEventArgsMap(const VoltEventArgsMap &aSrc): map_(new AnyMap())
{
  *this = aSrc;
}

VoltEventArgsMap::~VoltEventArgsMap()
{
}

VoltEventArgsMap& VoltEventArgsMap::operator=(const VoltEventArgsMap &aRhs)
{
  if (this != &aRhs)
  {
    *map_ = *(aRhs.map_);
  }

  return *this;
}

bool VoltEventArgsMap::InsertString(const std::string &aKey, const std::string &aVal)
{
  return map_->Insert(aKey, aVal);
}

bool VoltEventArgsMap::GetString(const std::string &aKey, std::string &aVal) const
{
  return map_->Get<std::string>(aKey, aVal);
}

bool VoltEventArgsMap::InsertByteArray(const std::string &aKey,
                                       const uint8_t *aVal, const size_t aSize)
{
  std::shared_ptr<ByteArray> val(new ByteArray(aSize, aVal));
  return map_->Insert(aKey, val);
}

bool VoltEventArgsMap::GetByteArray(const std::string &aKey,
                                    const uint8_t * &aVal, size_t &aSize) const
{
  std::shared_ptr<ByteArray> val;
  bool result = map_->Get<std::shared_ptr<ByteArray>>(aKey, val);

  if (result)
  {
    aSize = val->size;
    aVal = val->bytes;
  }

  return result;
}

bool VoltEventArgsMap::InsertMap(const std::string &aKey, const VoltEventArgsMap &aVal)
{
  return map_->Insert(aKey, aVal);
}

bool VoltEventArgsMap::GetMap(const std::string &aKey, VoltEventArgsMap &aVal) const
{
  return map_->Get<VoltEventArgsMap>(aKey, aVal);
}

bool VoltEventArgsMap::InsertList(const std::string &aKey, const VoltEventArgsList &aVal)
{
  return map_->Insert(aKey, aVal);
}

bool VoltEventArgsMap::GetList(const std::string &aKey, VoltEventArgsList &aVal) const
{
  return map_->Get<VoltEventArgsList>(aKey, aVal);
}

bool VoltEventArgsMap::Has(const std::string &aKey) const
{
  return map_->Has(aKey);
}

size_t VoltEventArgsMap::Size() const
{
  return map_->Size();
}

bool VoltEventArgsMap::Empty() const
{
  return map_->Empty();
}

std::vector<std::string>& VoltEventArgsMap::GetKeys(std::vector<std::string> &aKeys) const
{
  return map_->GetKeys(aKeys);
}


/******************************************************************************
 * VoltEventArgsList
 *****************************************************************************/

VoltEventArgsList::VoltEventArgsList(): list_(new AnyList())
{
}

VoltEventArgsList::VoltEventArgsList(const VoltEventArgsList &aSrc): list_(new AnyList())
{
  *this = aSrc;
}

VoltEventArgsList::~VoltEventArgsList()
{
}

VoltEventArgsList& VoltEventArgsList::operator=(const VoltEventArgsList &aRhs)
{
  if (this != &aRhs)
  {
    *list_ = *(aRhs.list_);
  }

  return *this;
}

bool VoltEventArgsList::AddString(const std::string &aVal)
{
  return list_->Add(aVal);
}

bool VoltEventArgsList::GetString(const size_t aIndex, std::string &aVal) const
{
  return list_->Get<std::string>(aIndex, aVal);
}

bool VoltEventArgsList::AddByteArray(const uint8_t *aVal, const size_t aSize)
{
  std::shared_ptr<ByteArray> val(new ByteArray(aSize, aVal));
  return list_->Add(val);
}

bool VoltEventArgsList::GetByteArray(const size_t aIndex,
                                     const uint8_t * &aVal, size_t &aSize) const
{
  std::shared_ptr<ByteArray> val;
  bool result = list_->Get<std::shared_ptr<ByteArray>>(aIndex, val);

  if (result)
  {
    aSize = val->size;
    aVal = val->bytes;
  }

  return result;
}

bool VoltEventArgsList::AddMap(const VoltEventArgsMap &aVal)
{
  return list_->Add(aVal);
}

bool VoltEventArgsList::GetMap(const size_t aIndex, VoltEventArgsMap &aVal) const
{
  return list_->Get<VoltEventArgsMap>(aIndex, aVal);
}

bool VoltEventArgsList::AddList(const VoltEventArgsList &aVal)
{
  return list_->Add(aVal);
}

bool VoltEventArgsList::GetList(const size_t aIndex, VoltEventArgsList &aVal) const
{
  return list_->Get<VoltEventArgsList>(aIndex, aVal);
}

size_t VoltEventArgsList::Size() const
{
  return list_->Size();
}

bool VoltEventArgsList::Empty() const
{
  return list_->Empty();
}
