#include "CacheManager.h"

#include <fstream>
#include <iostream>
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/serialization/shared_ptr.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/iostreams/concepts.hpp>
#include <boost/iostreams/categories.hpp>
#include <sys/stat.h>
#include <dirent.h>

#include "NetworkIORequest.h"

#include "AppConfig.h"

namespace Resource
{

static std::string s_mru_store = "mruStore";
static std::string s_cache_path = "./data/cache";

volt::util::Logger CacheManager::LOGGER("volt.resource.cache.manager");

CacheManager& CacheManager::Instance()
{
  static CacheManager singleton;
  return singleton;
}

CacheManager::CacheManager()
{
  LOG_DEBUG(LOGGER, "Born");

  s_cache_path = AppConfig::Instance().GetVoltDataPath() + "/cache";

  /* Create cache directory. */
  for (auto iter = s_cache_path.begin();
       iter != s_cache_path.end(); ++iter)
  {
    /* don't care about the root (/) dir. */
    if (iter == s_cache_path.begin())
    {
      continue;
    }

    if (*iter == '/')
    {
      *iter = '\0';

      if(access(s_cache_path.c_str(), F_OK) != 0)
      {
        /* Log s_cache_path.c_str() instead of just s_cache_path since it
         * seems like using s_cache_path makes it intelligently skip over null
         * character in mid-string. */
        LOG_DEBUG(LOGGER, "Creating dir: " << s_cache_path.c_str());
        mkdir(s_cache_path.c_str(), 0777);
      }

      *iter = '/';
    }
  }

  if(access(s_cache_path.c_str(), F_OK) != 0)
  {
    LOG_DEBUG(LOGGER, "Creating dir: " << s_cache_path.c_str());
    mkdir(s_cache_path.c_str(), 0777);
  }

  if (mru_cache.load_from_file(GetCachePath(s_mru_store).c_str()) == false)
  {
    LOG_WARN(LOGGER, "Failed to load MRU cache: " << GetCachePath(s_mru_store));
  }
}

CacheManager::~CacheManager()
{
  LOG_DEBUG(LOGGER, "Dead");
}

void CacheManager::SaveCatalog() const
{
  std::string catalog_path = GetCachePath(s_mru_store);
  LOG_DEBUG(LOGGER, "Saving cache catalog to " << catalog_path);

  try
  {
    mru_cache.save_to_file(catalog_path.c_str());
  }
  catch (boost::archive::archive_exception &e)
  {
    LOG_FATAL(LOGGER, "Failed to save catalog to " << catalog_path << ": " << e.what());
  }
}

void CacheManager::SetMaxSize(std::size_t max_size)
{
  mru_cache.set_max_size(max_size * 1024 * 1024);
}

std::string CacheManager::GetCachePath(const std::string &aKey) const
{
  std::string path = s_cache_path + "/" + aKey;
  LOG_DEBUG(LOGGER, "Cache path: " << path);
  return path;
}

void CacheManager::Flush()
{
  LOG_DEBUG(LOGGER, "Flushing the cache");
  mru_cache.clear();

  DIR *theFolder;

  theFolder = opendir(s_cache_path.c_str());

  if (theFolder != NULL)
  {
    int len = offsetof(struct dirent, d_name) + pathconf(s_cache_path.c_str(), _PC_NAME_MAX) + 1;
    struct dirent* entryp = static_cast<struct dirent*>(malloc(len));
    struct dirent* next_file = NULL;

    readdir_r(theFolder, entryp, &next_file);

    while (next_file != NULL)
    {
      if (next_file->d_type == DT_REG)
      {
        LOG_DEBUG(LOGGER, "Removing cache file: " << GetCachePath(std::string(next_file->d_name)));
        int result = remove(GetCachePath(std::string(next_file->d_name)).c_str());

        if (result != 0)
        {
          LOG_DEBUG(LOGGER, "Error unlinking cache file: ");
        }
      }

      readdir_r(theFolder, entryp, &next_file);
    }

    free(entryp);
    closedir(theFolder);
  }
}


void CacheManager::CachedResponseAccessed(const IOResponse::SharedPtr aResponse)
{
  mru_cache.accessed(aResponse->uri());
}


bool CacheManager::GetCachedResponse(IORequest::SharedPtr aRequest)
{
  LOG_DEBUG(LOGGER, "Check for cache: " << aRequest->uri());

  /* Generate cache key for this request. */
  aRequest->ResetCacheKey();

  CachedItem item = mru_cache.findByHash(aRequest->uri());
  std::string cache_path = GetCachePath(aRequest->cache_key());

  if (access(cache_path.c_str(), R_OK) == 0)
  {
    if (!item.isValid()) // catalog is out of sync with cache.  For now just flush the cache.
    {
      Flush();
      return false;
    }

    /* Cache hit! */
    try
    {
      IOResponse::SharedPtr response;
      std::ifstream in_file(cache_path);
      boost::archive::text_iarchive in_archive(in_file);
      in_archive >> response;

      if (response)
      {
        LOG_DEBUG(LOGGER, "Loaded cached response: " << response->uri());

        aRequest->set_response(response);
        return true;
      }
    }
    catch (std::exception &e)
    {
      LOG_WARN(LOGGER, "Failed to load cached data for " << aRequest->uri()
               << " from " << cache_path << ": " << e.what());
    }
  }
  else
  {
    LOG_DEBUG(LOGGER, "Cache not found: " << aRequest->uri());
  }

  return false;
}


bool CacheManager::TryCache(const IOResponse::SharedPtr aResponse)
{
  LOG_DEBUG(LOGGER, "Try caching " << aResponse->uri());

  if (mru_cache.get_max_size() <= 0)
  {
    LOG_DEBUG(LOGGER, "Caching is disabled");
  }
  else if (aResponse->IsCacheable())
  {
    if (aResponse->IsExpired())
    {
      LOG_DEBUG(LOGGER, "Can't cache expired response: " << aResponse->uri());
    }
    else
    {
      LOG_DEBUG(LOGGER, "Try caching reponse for: " << aResponse->uri());

      // TBD figure out a better way to compute size of serialized data
      // Did not have enough time, tried for few hours trying to create
      // a sink and streambuf that counts bytes going by.
      std::stringstream out_buf;
      boost::archive::text_oarchive out_archive(out_buf);
      out_archive << aResponse;
      size_t newItemLen = out_buf.tellp();

      LOG_DEBUG(LOGGER, "Length of new cachable item = " << newItemLen);

      // if this file is larger than the cache's max size, then don't cache it.
      if (newItemLen > mru_cache.get_max_size())
      {
        LOG_DEBUG(LOGGER, "Item size larger than cache, will not cache it.");
        return false;
      }

      size_t cacheSize = mru_cache.get_current_size();

      LOG_DEBUG(LOGGER, "cache_size:" << newItemLen <<
                " current_total:" << mru_cache.get_current_size() <<
                " max:" << mru_cache.get_max_size());

      // if this file will go over cache's max size, then throw out oldest items until it will fit.
      while (cacheSize + newItemLen > mru_cache.get_max_size())
      {
        if (mru_cache.empty()) // if the cache is empty at this point, then the catalog is out of sync, so flush the cache.
        {
          Flush();
          break;
        }

        CachedItem poppedItem = mru_cache.pop_back();

        LOG_DEBUG(LOGGER, "Cache cannot fit new item, removing oldest item.\n\tUri:" <<
                  poppedItem.uri() << "\n\tSize: " << poppedItem.sizeOnDisk() << "\n\t" <<
                  poppedItem.cacheKey());

        // remove popped item from storage
        //
        LOG_DEBUG(LOGGER, "Removing cache file: " << GetCachePath(poppedItem.cacheKey()));
        int result = remove(GetCachePath(poppedItem.cacheKey()).c_str());

        if (result != 0 && errno == ENOENT)
        {
          LOG_DEBUG(LOGGER, "Error unlinking cache file: " << poppedItem.cacheKey());
          Flush();
          break;
        }

        cacheSize = mru_cache.get_current_size();
      }

      CachedItem item = {aResponse->cache_key(), newItemLen, aResponse->uri()};

      // Add this cached item to the catalog
      mru_cache.insert(item);

      // stream response to archive
      std::ofstream out_file(GetCachePath(aResponse->cache_key()));
      out_file << out_buf.rdbuf();
      LOG_DEBUG(LOGGER, "Archive Bytes written: " << out_file.tellp());

      return true;
    }
  }
  else
  {
    LOG_DEBUG(LOGGER, "Not cacheable: " << aResponse->uri());
  }

  return false;
}

} /* namespace Resource */
