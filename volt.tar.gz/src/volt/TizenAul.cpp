/*
 * AulApp.cpp
 *
 *  Created on: June 26, 2014
 *      Author: Joe Yee
 */

#include "AulBridge.h"
#include "TizenAul.h"
#include <clutter/clutter.h>

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include "aul_service.h"
#include "aul.h"
#include "aul-ex.h"
#endif

volt::util::Logger TizenAul::LOGGER = volt::util::Logger("volt.tizen.aul");
bool TizenAul::isAulInitialized = false;

#if defined(BUILD_FOR_TV) && defined(TIZEN)
static void AulServiceCallback(bundle *b, int reserved, void *user_data)
{
  if(not user_data)
  {
    if(b)
    {
      bundle_free(b); // TODO do we do this here?
    }

    return;
  }

  Bridge::AulBridge::ProxyLaunchServiceCallback((TizenAul *) user_data, b);
}
#endif

TizenAul::TizenAul()
  : pid_(-1)
{
  LOG_DEBUG(LOGGER, "AulApp born @ " << this);
#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(not isAulInitialized)
  {
    aul_launch_init(NULL, NULL);
    isAulInitialized = true;
  }

#endif
}

TizenAul::~TizenAul()
{
  LOG_DEBUG(LOGGER, "AulApp dead @ " << this);
}

#if defined(BUILD_FOR_TV) && defined(TIZEN)
int TizenAul::LaunchApp(std::string &appId, bundle *args)
{
  LOG_ERROR(LOGGER, "Launch App " << appId);

  if(pid_ > 0)
  {
    LOG_ERROR(LOGGER, "Failed to launch app, existing pid " << pid_);
    return -1;
  }

  int result = aul_launch_app(appId.c_str(), args);

  if(result > 0)
  {
    pid_ = result;
    LOG_ERROR(LOGGER, "Launch App success" << appId << ", pid " << pid_);
  }
  else
  {
    LOG_ERROR(LOGGER, "Launch App failed" << appId << ", result " << result);
  }

  return result;
}

int TizenAul::LaunchAppEx(std::string &appId, bundle *args)
{
  LOG_ERROR(LOGGER, "Launch AppEx " << appId);

  if(pid_ > 0)
  {
    LOG_ERROR(LOGGER, "Failed to launch app, existing pid " << pid_);
    return -1;
  }

  int result = aul_launch_app_ex(appId.c_str(), args);

  if(result > 0)
  {
    pid_ = result;
    LOG_ERROR(LOGGER, "Launch App success" << appId << ", pid " << pid_);
  }
  else
  {
    LOG_ERROR(LOGGER, "Launch App failed" << appId << ", result " << result);
  }

  return result;
}

int TizenAul::OpenApp(std::string &appId)
{
  LOG_ERROR(LOGGER, "Open App " << appId);

  if(pid_ > 0)
  {
    LOG_ERROR(LOGGER, "Failed to open app, existing pid " << pid_);
    return -1;
  }

  int result = aul_open_app(appId.c_str());

  if(result > 0)
  {
    pid_ = result;
    LOG_ERROR(LOGGER, "Open App success" << appId << ", pid " << pid_);
  }
  else
  {
    LOG_ERROR(LOGGER, "Open App failed" << appId << ", result " << result);
  }

  return result;
}

int TizenAul::ResumeApp(std::string &appId)
{
  LOG_ERROR(LOGGER, "Resume App " << appId);

  if(pid_ > 0)
  {
    LOG_ERROR(LOGGER, "Failed to resume app, existing pid " << pid_);
    return -1;
  }

  int result = aul_resume_app(appId.c_str());

  if(result > 0)
  {
    pid_ = result;
    LOG_ERROR(LOGGER, "Resume App success" << appId << ", pid " << pid_);
  }
  else
  {
    LOG_ERROR(LOGGER, "Resume App failed" << appId << ", result " << result);
  }

  return result;
}

int TizenAul::ResumePID(int in_pid)
{
  LOG_ERROR(LOGGER, "Resume App ");

  if(in_pid > 0)
  {
    LOG_ERROR(LOGGER, "Failed to resume app, existing pid " << in_pid);
    return -1;
  }

  int result = aul_resume_pid(in_pid);

  if(result > 0)
  {
  //  pid_ = result;
    LOG_ERROR(LOGGER, "Resume App success pid " << in_pid);
  }
  else
  {
    LOG_ERROR(LOGGER, "Resume App failed result " << result);
  }

  return result;
}

int TizenAul::AppIsRunning(std::string &appId)
{
  LOG_ERROR(LOGGER, "App Is Running " << appId);

  if(pid_ > 0)
  {
    LOG_ERROR(LOGGER, "Failed to app is running, existing pid " << pid_);
    return -1;
  }

  int result = aul_app_is_running(appId.c_str());

  if(result > 0)
  {
    pid_ = result;
    LOG_ERROR(LOGGER, "App Is Running success" << appId << ", pid " << pid_);
  }
  else
  {
    LOG_ERROR(LOGGER, "App Is Running failed" << appId << ", result " << result);
  }

  return result;
}

int TizenAul::OpenService(std::string &serviceId, bundle *args, bool callback)
{
  LOG_ERROR(LOGGER, "OpenService " << serviceId << ", callback flag " << callback );

  if(pid_ > 0)
  {
    LOG_ERROR(LOGGER, "Failed to open service, existing pid " << pid_);
    return -1;
  }

  int result = -1;

  if(callback)
  {
    result = aul_open_service(serviceId.c_str(), args, AulServiceCallback, (void *) this);
  }
  else
  {
    result = aul_open_service(serviceId.c_str(), args, NULL, NULL);
  }

  if(result > 0)
  {
    pid_ = result;
    LOG_ERROR(LOGGER, "OpenService success " << serviceId << ", pid " << pid_);
  }
  else
  {
    LOG_ERROR(LOGGER, "OpenService failed " << serviceId << ", result " << result);
  }

  return result;
}

int TizenAul::Terminate()
{
  LOG_ERROR(LOGGER, "Terminating app" << this);

  if(pid_ > 0)
  {
    int result = aul_terminate_pid(pid_);

    if(result < 0)
    {
      LOG_ERROR(LOGGER, "Failed to terminate AUL app with pid " << pid_ << ", result " << result);
    }

    pid_ = -1; // reset, so this object can be reused

    return result;
  }
  else
  {
    LOG_ERROR(LOGGER, "nothing to terminate");
  }

  return -1;
}


int TizenAul::TerminatePID(int in_pid)
{
  LOG_ERROR(LOGGER, "Terminating app");

  if(in_pid > 0)
  {
    int result = aul_terminate_pid(in_pid);

    if(result < 0)
    {
      LOG_ERROR(LOGGER, "Failed to terminate AUL app with pid " << in_pid << ", result " << result);
    }

//    pid_ = -1; // reset, so this object can be reused

    return result;
  }
  else
  {
    LOG_ERROR(LOGGER, "nothing to terminate");
  }

  return -1;
}

static int iterfunc(const aul_app_info* info, void* data)
{
	std::string *userData = reinterpret_cast<std::string *>(data);
	if(strcmp(info->appid, userData->c_str()) == 0 || strcmp(info->pkg_name, userData->c_str()) == 0 ){
		return aul_terminate_pid(info->pid);
	}

	return 0;
}

int TizenAul::TerminateApp(std::string &appId)
{
	LOG_ERROR(LOGGER, "Terminating app");


	int result = aul_app_get_running_app_info(iterfunc, &appId);



	//    pid_ = -1; // reset, so this object can be reused

	return result;
}


int TizenAul::TerminatePkg(std::string &pkgName)
{
	LOG_ERROR(LOGGER, "Terminating app");


	int result = aul_app_get_running_app_info(iterfunc, &pkgName);



	//    pid_ = -1; // reset, so this object can be reused

	return result;
}

#endif
