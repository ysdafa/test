#include "Environment.h"

#include <fstream>
#include <strings.h>
#include <boost/program_options.hpp>

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>

#ifdef BUILD_FOR_TV
#ifdef TIZEN
#include "system_info.h"
#else
#include "SefClient.h"
#endif
#endif

#include "logger.h"

#include "AppConfig.h"

namespace volt
{

static volt::util::Logger LOGGER("volt.environment");

Environment::DeviceType
Environment::StringToDeviceType(const std::string &aType)
{
  if (strcasecmp(aType.c_str(), "TV") == 0)
  {
    return kDeviceTV;
  }
  else if (strcasecmp(aType.c_str(), "BD") == 0)
  {
    return kDeviceBD;
  }
  else if (strcasecmp(aType.c_str(), "PC") == 0)
  {
    return kDevicePC;
  }
  else
  {
    return kDeviceDefault;
  }
}

const std::string& Environment::DeviceTypeToString(const DeviceType aType)
{
  static const std::string &tv = "TV";
  static const std::string &bd = "BD";
  static const std::string &pc = "PC";
  static const std::string &def = "default";

  switch (aType)
  {
  case kDeviceTV:
    return tv;
  case kDeviceBD:
    return bd;
  case kDevicePC:
    return pc;
  default:
    return def;
  }
}

Environment::Environment():
  device_type_(kDeviceInvalid), device_code_(), cache_file_()
{
  cache_file_ = AppConfig::Instance().GetVoltDataPath() + "/device.info";
}

Environment::~Environment()
{
}

void Environment::UpdateDeviceInfo()
{
  LOG_DEBUG(LOGGER, "Getting device information");

  bool cache_available = LoadDeviceInfoCache();

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
  SefClient sef;
  bool sef_opened = false;

  /* Used when calling Execute. */
  std::vector<std::string> args;
#endif

  do
  {
    /* The command line option always overrides others. */
    if (AppConfig::Instance().IsSet("device-type"))
    {
      std::string type = AppConfig::Instance().GetValue<std::string>("device-type");

      if (type.empty() == false)
      {
        LOG_DEBUG(LOGGER, "Forcing device type to " << type);
        set_device_type(StringToDeviceType(type));
        break;
      }
    }

    if (cache_available)
    {
      LOG_DEBUG(LOGGER, "Using the cached device type: " << DeviceTypeToString(device_type()));
      break;
    }

#ifdef BUILD_FOR_TV
#ifdef TIZEN
    int product_val = SYSTEM_INFO_PRODUCT_TYPE_TV;

    if (system_info_get_value_int(SYSTEM_INFO_KEY_PRODUCT_TYPE, &product_val) == SYSTEM_INFO_ERROR_NONE)
    {
      LOG_DEBUG(LOGGER, "Got SYSTEM_INFO_PRODUCT_TYPE_TV: " << product_val);

      switch (product_val)
      {
      case SYSTEM_INFO_PRODUCT_TYPE_TV:
        set_device_type(kDeviceTV);
        break;
      case SYSTEM_INFO_PRODUCT_TYPE_BD:
        set_device_type(kDeviceBD);
        break;
      default:
        /* Treat everything else as a PC for now */
        set_device_type(kDevicePC);
        break;
      }
    }
    else
    {
      LOG_WARN(LOGGER, "Failed to get device type.");
    }

#else

    if (sef_opened == false)
    {
      sef.Open("TV", "1.009", "TV");
    }

    sef_opened = true;

    args.clear();
    std::string result = sef.Execute("GetProductType", args);

    /* Must be an integer value. */
    if (result.empty() == false && result[0] == 'I')
    {
      long int value = 0;
      char *end_ptr = NULL;
      value = strtol(&(result.c_str()[1]), &end_ptr, 0);

      if (*end_ptr == '\0')
      {
        /* Convert values from EMP to DeviceType enum.
         * http://www.samsungdforum.com/Guide/ref00014/PL_TV_PRODUCT_TYPE.html
         */
        switch (value)
        {
        case 0:
          set_device_type(kDeviceTV);
          break;
        case 2:
          set_device_type(kDeviceBD);
          break;
        default:
          LOG_WARN(LOGGER,
                   "Unknown device type (" << value << "); using default");
          set_device_type(kDeviceDefault);
          break;
        }
      }
      else
      {
        LOG_WARN(LOGGER,
                 "Failed to convert to numeric value: " << &(result.c_str()[1]));
      }
    }
    else
    {
      LOG_WARN(LOGGER, "Failed to get device type.");
    }

#endif
#else
    set_device_type(kDevicePC);
#endif
  }
  while (0);

  do
  {
    if (AppConfig::Instance().IsSet("device-code"))
    {
      std::string code = AppConfig::Instance().GetValue<std::string>("device-code");

      if (code.empty() == false)
      {
        LOG_DEBUG(LOGGER, "Forcing device code to " << code);
        set_device_code(code);
        break;
      }
    }

    if (cache_available)
    {
      LOG_DEBUG(LOGGER, "Using the cached device code: " << device_code());
      break;
    }

#ifdef BUILD_FOR_TV
#ifdef TIZEN
    char *model_val = NULL;

    if (system_info_get_value_string(SYSTEM_INFO_KEY_MODEL, &model_val) == SYSTEM_INFO_ERROR_NONE)
    {
      LOG_DEBUG(LOGGER, "Got SYSTEM_INFO_KEY_MODEL: " << model_val);
      set_device_code(model_val);
    }
    else
    {
      LOG_WARN(LOGGER, "Failed to get model name.");
    }

    if (model_val)
    {
      free(model_val);
    }

#else

    if (sef_opened == false)
    {
      sef.Open("TV", "1.009", "TV");
    }

    sef_opened = true;

    args.clear();
    args.push_back("1"); /* region code: 1 == US? */
    std::string result = sef.Execute("GetProductCode", args);

    /* Must be a string value. */
    if (result.empty() == false && result[0] == 'A')
    {
      set_device_code(&(result.c_str()[1]));
    }
    else
    {
      LOG_WARN(LOGGER, "Failed to get device code.");
    }

#endif
#else
    set_device_code("");
#endif
  }
  while (0);

#if defined(BUILD_FOR_TV) && !defined(TIZEN)

  if (sef_opened)
  {
    sef.Close();
  }

#endif

  if (cache_available == false)
  {
    SaveDeviceInfoCache();
  }

  LOG_DEBUG(LOGGER, "Device type: " << DeviceTypeToString(device_type()));
  LOG_DEBUG(LOGGER, "Device code: " << device_code());
}

bool Environment::SaveDeviceInfoCache()
{
  try
  {
    std::ofstream output_stream(cache_file_);
    boost::archive::binary_oarchive oa(output_stream);
    oa << device_type_;
    oa << device_code_;

    return true;
  }
  catch (std::exception &e)
  {
    LOG_WARN(LOGGER, "Failed to write cached device info to " << cache_file_
             << ": " << e.what());
  }

  return false;
}

bool Environment::LoadDeviceInfoCache()
{
  try
  {
    /* Try to use the cached device info. */
    std::ifstream input_stream(cache_file_);
    boost::archive::binary_iarchive ia(input_stream);
    ia >> device_type_;
    ia >> device_code_;

    return true;;
  }
  catch (std::exception &e)
  {
    LOG_WARN(LOGGER, "Failed to read cached device info from " << cache_file_
             << ": " << e.what());

    device_type_ = kDeviceInvalid;
    device_code_.clear();
  }

  return false;
}

} /* end namespace volt */


/****************************************************************************
 *                    Serialization code for DeviceType                     *
 ****************************************************************************/

namespace boost
{
namespace serialization
{

template<class Archive>
void serialize(Archive &aAr, volt::Environment::DeviceType &aDeviceType, const unsigned int aVersion)
{
  aAr << aDeviceType;
}

} /* serialization */
} /* boost */


