/*
 * ResourceManager.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "ResourceManager.h"

#include "CacheManager.h"
#include "FileIORequest.h"
#include "Exception.h"
#include "stdio.h"
#include <cstring>
#include <unistd.h>
#include <iomanip>

using namespace volt::util;

//#define TEST_MULTI_THREAD_WORKER

namespace Resource
{

/******************************************************************************
 * ResourceManager
 *****************************************************************************/

std::string ResourceManager::LOGGER_NAME = "volt.resource.manager";

#ifdef TEST_MULTI_THREAD_WORKER
static void NetworkAioWorkerThread(NetworkIORequest::SharedPtr aRequest)
{
  volt::util::Logger logger("volt.resource.network.worker");
  LOG_DEBUG(logger, "Network AIO worker thread started");

  /* Not really async, but ok for now... */
  LOG_DEBUG(logger, "Handling in async thread: " << aRequest->uri());

  aRequest->Execute();

  aRequest->FinalizeResponse();

  /* Post request cache validation. */
  aRequest->ValidateCachedResponseAfterRequest();

  aRequest->Callback();

  /* TODO: Cache response if possible */
  CacheManager::Instance().TryCache(aRequest->response());

  LOG_DEBUG(logger, "File AIO worker thread ending");
}
#endif

ResourceManager& ResourceManager::Instance()
{
  static ResourceManager singleton;
  return singleton;
}

ResourceManager::ResourceManager():
  logger_(LOGGER_NAME), req_id_(0), thread_(),
  multi_handle_(NULL), num_active_(0),
  ev_base_(NULL), timer_event_(NULL), pipe_event_(NULL),
  requests_(), handles_(), events_()
{
  LOG_DEBUG(logger_, "Born (" << this << ")");

  /* Create a pipe to send requests to worker thread */
  if (pipe(pipe_) < 0)
  {
    LOG_ERROR(logger_, "Failed to open pipe");
  }
  else
  {
    LOG_DEBUG(logger_, "Opened pipe " << pipe_[0] << " " << pipe_[1]);
  }

  curl_global_init(CURL_GLOBAL_ALL);
}

ResourceManager::~ResourceManager()
{
  LOG_DEBUG(logger_, "Dead (" << this << ")");

  // Is this going to cause a crash/deadlock?
  StopWorkerThread();
  close(pipe_[0]);
  close(pipe_[1]);
}

void ResourceManager::StartWorkerThread()
{
  LOG_DEBUG(logger_, "Start worker thread");
  thread_ = std::thread(std::ref(*this));
}

inline void ResourceManager::SendEventMessage(ResourceManager::Message *outgoingMessage)
{
  if (outgoingMessage == NULL)
  {
    return;
  }

  int num_written = write(pipe_[1], &outgoingMessage, sizeof(ResourceManager::Message *));

  if (num_written != sizeof(ResourceManager::Message *))
  {
    LOG_ERROR(logger_, "Failed to request worker threads to stop");

    if (num_written < 0)
    {
      PrintErrno(errno);
    }

    // delete when send fails, otherwise the other side will delete
    delete outgoingMessage;
  }
}

void ResourceManager::StopWorkerThread()
{
  LOG_DEBUG(logger_, "Requesting to stop worker threads");

  ResourceManager::Message *outgoingMessage = new ResourceManager::Message();
  outgoingMessage->handle = 0;
  outgoingMessage->payload = nullptr;
  outgoingMessage->type = ResourceManager::MessageType::StopThread;

  SendEventMessage(outgoingMessage);
}

void ResourceManager::JoinWorkerThread()
{
  LOG_DEBUG(logger_, "Joining threads");

  if (thread_.joinable())
  {
    thread_.join();  /* blocks */
  }

  LOG_DEBUG(logger_, "Joined threads done");
}

IORequest::SharedPtr
ResourceManager::CreateRequest(const std::string &aUri)
{
  Logger logger(ResourceManager::LOGGER_NAME);

  IORequest::SharedPtr request;

  do
  {
    if (aUri.compare(0, 7, "http://") == 0
        or aUri.compare(0, 8, "https://") == 0)
    {
      request.reset(new Resource::NetworkIORequest(aUri));
    }
    else if (aUri.compare(0, 7, "file://") == 0)
    {
      request.reset(new Resource::FileIORequest(aUri));
    }
    else if(aUri.compare(0, 6, "dir://") == 0)
    {
      request.reset(new Resource::DirIORequest(aUri));
    }
    else
    {
      /* Default to file */
      request.reset(new Resource::FileIORequest(std::string("file://") + aUri));
    }

    request->set_method(IORequest::METHOD_GET);
    request->set_async(false);

  }
  while(0);

  return request;
}

IORequest::SharedPtr
ResourceManager::CreateRequest(const std::string &aUri,
                               IORequest::OnCompleteCallback aCallback)
{
  Logger logger(ResourceManager::LOGGER_NAME);

  IORequest::SharedPtr request = CreateRequest(aUri);

  if (request)
  {
    request->set_async(true);
    request->set_on_complete_callback(aCallback);
  }

  return request;
}

IORequest::SharedPtr
ResourceManager::CreateRequest(const ResourceRequest &aRequest)
{
  Logger logger(ResourceManager::LOGGER_NAME);

  IORequest::SharedPtr request;

  do
  {
    request = CreateRequest(aRequest.uri());

    if (!request)
    {
      break;
    }

    IORequest::Method method = IORequest::StringToMethod(aRequest.method());

    if (method == IORequest::METHOD_INVALID)
    {
      LOG_WARN(logger, "Invalid method: " << aRequest.method());
      break;
    }

    request->set_method(method);
    request->set_data(aRequest.data());
    request->set_src(aRequest.src());
    request->set_recursive(aRequest.recursive());
    request->set_no_cache(aRequest.no_cache());
    request->SetHeaders(aRequest.GetHeaders());

    if (aRequest.response_type() == "string")
    {
      request->set_response_type(IORequest::RESPONSE_STRING);
    }
    else if (aRequest.response_type() == "arraybuffer")
    {
      request->set_response_type(IORequest::RESPONSE_ARRAY_BUFFER);
    }
    else
    {
      LOG_WARN(logger,
               "Invalid response type (" << aRequest.response_type() <<
               "); defaulting to " <<
               IORequest::ResponseTypeToString(IORequest::RESPONSE_STRING));
      request->set_response_type(IORequest::RESPONSE_STRING);
    }
  }
  while(0);

  return request;
}

IORequest::SharedPtr
ResourceManager::CreateRequest(const ResourceRequest &aRequest,
                               IORequest::OnCompleteCallback aCallback)
{
  Logger logger(ResourceManager::LOGGER_NAME);

  IORequest::SharedPtr request = CreateRequest(aRequest);

  if (request)
  {
    request->set_async(aRequest.async());
    request->set_on_complete_callback(aCallback);
  }

  return request;
}

bool ResourceManager::Process(IORequest::SharedPtr &aRequest, unsigned int *requestHandle)
{
  LOG_DEBUG(logger_, "Process request: " << aRequest->uri());

  aRequest->Finalize();

  if (aRequest->IsValid() == false)
  {
    LOG_WARN(logger_, "Cannot process invalid request: " << aRequest->uri());
    aRequest->InitResponse();
    aRequest->FinalizeResponse();
    return false;
  }

  bool retval = true;

  if (aRequest->async())
  {
    // increment the id
    ++req_id_;

    if (req_id_ == 0)
    {
      ++req_id_; /* wrap around */
    }

    // returns unique handle id for tracking the request
    if(requestHandle != nullptr)
    {
      *requestHandle = req_id_;
    }

    LOG_DEBUG(logger_, "Asyc request id " << req_id_);
    IORequest::SharedPtr *request = new IORequest::SharedPtr();
    aRequest->set_id(req_id_);
    (*request).swap(aRequest); /* aRequest not needed anymore */

    ResourceManager::Message *outgoingMessage = new ResourceManager::Message();
    outgoingMessage->type = ResourceManager::MessageType::ProcessRequest;
    outgoingMessage->handle = req_id_;
    outgoingMessage->payload = (void*) request;

    SendEventMessage(outgoingMessage);

    request = NULL;
  }
  else
  {
    /* synchronous */

    /* Try getting cached response.
     *   1. Check if request is cacheable.
     *   2. Check if cache revalidation required (no_cache).
     *   3. Query CacheManager for cached response.
     *   4. Check if it is still fresh.
     *   5. Validate cache if possible.
     */

    if(requestHandle != nullptr)
    {
      *requestHandle = 0; // sync requests are not tracked by handle, return 0
    }

    bool result = aRequest->ShouldCacheResponse() && !aRequest->no_cache() &&
                  CacheManager::Instance().GetCachedResponse(aRequest) &&
                  (aRequest->response()->IsExpired() == false ||
                   aRequest->ValidateCachedResponseBeforeRequest());

    if (result == false)
    {
      LOG_DEBUG(logger_, "Executing uncached sync request");

      /* Not cached yet. */

      aRequest->InitResponse();

      result = aRequest->Execute();

      aRequest->FinalizeResponse();

      /* Post request cache validation. */
      aRequest->ValidateCachedResponseAfterRequest();
    }

    if (result)
    {
      LOG_DEBUG(logger_, "Status: " << aRequest->response()->status());
      LOG_DEBUG(logger_, "Size: " << aRequest->response()->data().size());

      /* Cache response if possible */
      CacheManager::Instance().TryCache(aRequest->response());
    }
    else
    {
      LOG_WARN(logger_, "Failed to get resource: " << aRequest->uri());
      retval = false;
    }
  }

  return retval;
}

void ResourceManager::Cancel(unsigned int requestHandle)
{
  LOG_DEBUG(logger_, "Sending cancel for request id " << requestHandle);

  ResourceManager::Message *outgoingMessage = new ResourceManager::Message();
  outgoingMessage->type = ResourceManager::MessageType::CancelRequest;
  outgoingMessage->handle = requestHandle;
  outgoingMessage->payload = nullptr;

  SendEventMessage(outgoingMessage);
}

void ResourceManager::operator()()
{
  LOG_DEBUG(logger_, "Start worker thread in operator");
  pthread_setname_np(pthread_self(), "Volt:Resource");

  /* Initialize curl */
  multi_handle_ = curl_multi_init();

  curl_multi_setopt(multi_handle_,CURLMOPT_SOCKETFUNCTION,
                    ResourceManager::SocketCallback);
  curl_multi_setopt(multi_handle_, CURLMOPT_SOCKETDATA, this);
  curl_multi_setopt(multi_handle_, CURLMOPT_TIMERFUNCTION,
                    ResourceManager::MultiTimerCallback);
  curl_multi_setopt(multi_handle_, CURLMOPT_TIMERDATA, this);

  /* Initialize libevent */
  ev_base_ = event_base_new();
  timer_event_ =
    evtimer_new(ev_base_, ResourceManager::TimerCallback, this);
  pipe_event_ = event_new(ev_base_, pipe_[0], EV_READ | EV_PERSIST,
                          ResourceManager::PipeCallback, this);
  event_add(pipe_event_, NULL);

  /* Start the libevent main loop */
  event_base_dispatch(ev_base_);

  /* Clean up */
  event_free(timer_event_);
  event_free(pipe_event_);

  event_base_free(ev_base_);

  curl_multi_cleanup(multi_handle_);

  std::map<CURL *, NetworkIORequest::SharedPtr>::iterator iter = requests_.begin();

  for (; iter != requests_.end(); ++iter)
  {
    iter->second.reset();
  }

  handles_.clear();
  events_.clear();

  LOG_DEBUG(logger_, "Worker thread done");
}

void ResourceManager::RemoveCompletedHandles()
{
  char *url = NULL;
  CURLMsg *info = NULL;
  int info_left = 0;

  LOG_DEBUG(logger_, "Remaining handles: " << num_active_);

  while ((info = curl_multi_info_read(multi_handle_, &info_left)))
  {
    if (info->msg == CURLMSG_DONE)
    {
      curl_easy_getinfo(info->easy_handle, CURLINFO_EFFECTIVE_URL, &url);

      LOG_DEBUG(logger_, "Completed handle " << info->easy_handle << ": " <<
                url << " => (" << info->data.result << ")");

      RequestMap::iterator iter = requests_.find(info->easy_handle);

      if (iter != requests_.end())
      {
        iter->second->FinalizeResponse();

        /* Post request cache validation. */
        iter->second->ValidateCachedResponseAfterRequest();

        LOG_DEBUG(logger_, "Executing callback for " << url);
        iter->second->Callback();

        /* Cache response if possible */
        CacheManager::Instance().TryCache(iter->second->response());

        if(events_.count(info->easy_handle))
        {
          events_.erase(info->easy_handle);
        }

        LOG_DEBUG(logger_, "cleaned up");

        /* now release both references to the NetworkIORequest */
        if(handles_.count(iter->second->id()))
        {
          handles_.erase(iter->second->id());
        }

        requests_.erase(iter);
      }
      else
      {
        /* Shouldn't happen */
        LOG_ERROR(logger_, "Failed to find network request: "
                  << info->easy_handle);
      }

      /* clean up the curl handles */
      /* Copy info->easy_handle because the CURLMsg struct does not survive
       * the calls to curl_multi_remove_handle/curl_easy_cleanup. */
      CURL *handle = info->easy_handle;
      curl_multi_remove_handle(multi_handle_, handle);
      curl_easy_cleanup(handle);

      /* free url? */
    }
  }

  LOG_DEBUG(logger_, "return");
}

const std::string& ResourceManager::McodeToString(CURLMcode aCode)
{
  switch (aCode)
  {
  case CURLM_OK:
  {
    static std::string str = "CURLM_OK";
    return str;
  }
  case CURLM_CALL_MULTI_PERFORM:
  {
    static std::string str = "CURLM_CALL_MULTI_PERFORM";
    return str;
  }
  case CURLM_BAD_HANDLE:
  {
    static std::string str = "CURLM_BAD_HANDLE";
    return str;
  }
  case CURLM_BAD_EASY_HANDLE:
  {
    static std::string str = "CURLM_BAD_EASY_HANDLE";
    return str;
  }
  case CURLM_OUT_OF_MEMORY:
  {
    static std::string str = "CURLM_OUT_OF_MEMORY";
    return str;
  }
  case CURLM_INTERNAL_ERROR:
  {
    static std::string str = "CURLM_INTERNAL_ERROR";
    return str;
  }
  case CURLM_UNKNOWN_OPTION:
  {
    static std::string str = "CURLM_UNKNOWN_OPTION";
    return str;
  }
  case CURLM_LAST:
  {
    static std::string str = "CURLM_LAST";
    return str;
  }
  case CURLM_BAD_SOCKET:
  {
    static std::string str = "CURLM_BAD_SOCKET";
    return str;
  }
  default:
  {
    static std::string str = "CURLM_unknown";
    return str;
  }
  }
}

int ResourceManager::SocketCallback(CURL *aEasyHandle, curl_socket_t aSocket,
                                    int aAction, void *aSelf,
                                    void *aEvent)
{
  ResourceManager *self = (ResourceManager *) aSelf;
  struct event *event = (struct event *) aEvent;

  static const char *action_str[]= { "none", "IN", "OUT", "INOUT", "REMOVE" };

  LOG_DEBUG(self->logger_, "Socket=" << aSocket <<
            " handle=" << aEasyHandle <<
            " action=" << action_str[aAction]);

  /* Delete existing event. */
  if (event)
  {
    LOG_DEBUG(self->logger_, "Freeing event " << event);

    if(self->events_.count(aEasyHandle))
    {
      self->events_.erase(aEasyHandle);
    }

    event_free(event);
  }

  if (aAction != CURL_POLL_REMOVE)
  {
    /* Convert CURL type to libevent type */
    int kind = (aAction & CURL_POLL_IN ? EV_READ : 0) |
               (aAction & CURL_POLL_OUT ? EV_WRITE : 0) | EV_PERSIST;

    event = event_new(self->ev_base_, aSocket, kind,
                      ResourceManager::EventCallback, self);
    LOG_DEBUG(self->logger_, "Created new event " << event);

    event_add(event, NULL);
    /* add the new event to map, so it can be removed from event queue later */
    self->events_[aEasyHandle] = event;

    /* Associate newly created event with this handle/socket */
    curl_multi_assign(self->multi_handle_, aSocket, event);
  }

  return 0;
}

int ResourceManager::MultiTimerCallback(CURLM * /* aMultiHandle */,
                                        long aTimeoutMs,
                                        ResourceManager *aSelf)
{
  /* Update the event timer to what CURL is suggesting. */
  LOG_DEBUG(aSelf->logger_, "Setting timeout to " << aTimeoutMs << "ms");

  struct timeval timeout;
  timeout.tv_sec = aTimeoutMs / 1000;
  timeout.tv_usec = (aTimeoutMs % 1000) * 1000;
  evtimer_add(aSelf->timer_event_, &timeout);
  return 0;
}

void ResourceManager::EventCallback(int aFd, short aKind, void *aSelf)
{
  ResourceManager *self = (ResourceManager *) aSelf;

  /* Convert libevent type to CURL type */
  int action = (aKind & EV_READ ? CURL_CSELECT_IN : 0) |
               (aKind & EV_WRITE ? CURL_CSELECT_OUT : 0);

  /* Let curl handle socket. */
  CURLMcode result = curl_multi_socket_action(self->multi_handle_, aFd, action,
                     &(self->num_active_));

  if (result != CURLM_OK)
  {
    LOG_DEBUG(self->logger_, "curl_multi_socket_action failed: " <<
              self->McodeToString(result));
  }

  self->RemoveCompletedHandles();

  if (self->num_active_ <= 0)
  {
    LOG_DEBUG(self->logger_, "No more active handle; remove timer");

    if (evtimer_pending(self->timer_event_, NULL))
    {
      evtimer_del(self->timer_event_);
    }
  }
}

void ResourceManager::TimerCallback(int /* aFd */, short /* aKind */,
                                    void *aSelf)
{
  ResourceManager *self = (ResourceManager *) aSelf;

  /* Let curl handle socket. */
  CURLMcode result = curl_multi_socket_action(self->multi_handle_,
                     CURL_SOCKET_TIMEOUT, 0,
                     &(self->num_active_));

  if (result != CURLM_OK)
  {
    LOG_DEBUG(self->logger_, "curl_multi_socket_action failed: " <<
              self->McodeToString(result));
  }

  self->RemoveCompletedHandles();
}

void ResourceManager::HandleProcessRequest(IORequest::SharedPtr *request_ptr)
{
  LOG_DEBUG(logger_, "Received request at address " << request_ptr);

  if (request_ptr == nullptr)
  {
    LOG_ERROR(logger_, "null request ptr, unable to process");
    return;
  }

  IORequest::SharedPtr request;
  request.swap(*request_ptr);

  /* request_ptr not needed. */
  delete request_ptr;
  request_ptr = NULL;

  /* Try getting cached response.
   *   1. Check if request is cacheable.
   *   2. Check if cache revalidation required (no_cache).
   *   3. Query CacheManager for cached response.
   *   4. Check if it is still fresh.
   *   5. Validate cache if possible.
   */
  if (request->ShouldCacheResponse()
      && !request->no_cache()
      && CacheManager::Instance().GetCachedResponse(request)
      && (request->response()->IsExpired() == false
          || request->ValidateCachedResponseBeforeRequest()))
  {
    LOG_DEBUG(logger_, "Found cached response: " << request->uri());

    if (request->response()->IsExpired())
    {
      LOG_DEBUG(logger_, "Stale response: " << request->uri());
      /* revalidate */
    }

    CacheManager::Instance().CachedResponseAccessed(request->response());

    request->Callback();
  }
  else
  {
    request->InitResponse();

    if (request->response()->source() == IOResponse::SOURCE_NETWORK)
    {
      NetworkIORequest::SharedPtr nw_request = boost::static_pointer_cast<
          NetworkIORequest>(request);

#ifdef TEST_MULTI_THREAD_WORKER
      std::thread worker = std::thread(NetworkAioWorkerThread, nw_request);
      worker.detach();
#else
      requests_[nw_request->curl_handle()] = nw_request;
      handles_[nw_request->id()] = nw_request;

      LOG_DEBUG(logger_,
                "Received request: " << nw_request->uri() << ", handle: " << nw_request->id());

      CURLMcode result = curl_multi_add_handle(multi_handle_,
                         nw_request->curl_handle());

      if (result != CURLM_OK)
      {
        LOG_DEBUG(logger_,
                  "curl_multi_add_handle failed: " << McodeToString(result));
      }

#endif
    }
    else
    {
      /* Not really async, but ok for now... */
      LOG_DEBUG(logger_, "Handling in async thread: " << request->uri());

      request->Execute();

      request->FinalizeResponse();

      /* Post request cache validation. */
      request->ValidateCachedResponseAfterRequest();

      request->Callback();

      /* TODO: Cache response if possible */
      CacheManager::Instance().TryCache(request->response());
    }
  }
}

void ResourceManager::HandleCancelRequest(unsigned int requestHandle)
{
  LOG_DEBUG(logger_, "Got request to cancel handle " << requestHandle);

  // make sure that we still have the handle before proceeding
  if(not handles_.count(requestHandle))
  {
    LOG_ERROR(logger_, "request with handle " << requestHandle << " is not found, unable to cancel");
    return;
  }

  CURL* curlHandle = handles_[requestHandle]->curl_handle();

  /* clean up curl handles */
  curl_multi_remove_handle(multi_handle_, curlHandle);
  curl_easy_cleanup(curlHandle);

  /* remove event from event queue */
  if(events_.count(curlHandle))
  {
    event_del(events_[curlHandle]);
    event_free(events_[curlHandle]);
    events_.erase(curlHandle);
  }

  /* release references to NetworkIORequest */
  if(requests_.count(curlHandle))
  {
    requests_.erase(curlHandle);
  }

  handles_.erase(requestHandle);
}

void ResourceManager::HandleStopThread()
{
  LOG_DEBUG(logger_, "Got request to exit resource manager thread");
  event_base_loopexit(ev_base_, NULL);
}

void ResourceManager::PipeCallback(int aFd, short aEvent, void *aSelf)
{
  ResourceManager *self = (ResourceManager *) aSelf;

  LOG_DEBUG(self->logger_, "Got pipe event " << aEvent);

  if ((aEvent & EV_READ) == 0)
  {
    LOG_DEBUG(self->logger_, "Only interested in READ event");
    return;
  }

  ResourceManager::Message *incommingMessage = NULL;
  int num_read = read(aFd, &incommingMessage, sizeof(ResourceManager::Message *));

  if (num_read != sizeof(ResourceManager::Message *))
  {
    LOG_ERROR(self->logger_, "Failed to read from pipe");

    if (num_read < 0)
    {
      ResourceManager::PrintErrno(errno);
    }

    return;
  }

  LOG_DEBUG(self->logger_, "received message type " << incommingMessage->type);

  switch(incommingMessage->type)
  {
  case ResourceManager::MessageType::ProcessRequest:
    self->HandleProcessRequest((IORequest::SharedPtr *)incommingMessage->payload);  // deletes payload
    incommingMessage->payload = nullptr; // set to null so message destructor does not double delete payload
    break;

  case ResourceManager::MessageType::CancelRequest:
    self->HandleCancelRequest(incommingMessage->handle);
    break;

  case ResourceManager::MessageType::StopThread:
    self->HandleStopThread();
    break;

  default:
    LOG_ERROR(self->logger_, "unhandled resource manager message type " << incommingMessage->type);
    break;
  }

  // free memory
  delete incommingMessage;
}

void ResourceManager::PrintErrno(const int aErrno)
{
  Logger logger(ResourceManager::LOGGER_NAME);
  char err_buf[1024];
#if (_POSIX_C_SOURCE >= 200112L || _XOPEN_SOURCE >= 600) && ! _GNU_SOURCE

  if (strerror_r(aErrno, err_buf, sizeof(err_buf) / sizeof(err_buf[0])) == 0)
  {
    LOG_ERROR(logger, "errno " << aErrno << ": " << err_buf);
  }

#else
  char *the_err_buf =
    strerror_r(aErrno, err_buf, sizeof(err_buf) / sizeof(err_buf[0]));
  LOG_ERROR(logger, "errno " << aErrno << ": " << the_err_buf);
#endif
}

} /* namespace Resource */
