/*
 * FirstScreenListWidgetBridge.cpp
 *
 *  Created on: Oct 1, 2014
 *      Author: backki.kim
 */

#include "FirstScreenListWidgetBridge.h"
#include "event_manager.h"

using namespace volt::util;
using namespace volt::graphics;

namespace Bridge
{

static volt::util::Logger logger;
	
void FirstScreenListWidgetBridge::mapScriptInterface(ScriptContext& aContext)
{
	aContext.captureMethodCall<FirstScreenListWidget, &addCategory>("addCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &addContents>("addContents");
	aContext.captureMethodCall<FirstScreenListWidget, &moveLeft>("moveLeft");
	aContext.captureMethodCall<FirstScreenListWidget, &moveRight>("moveRight");
	aContext.captureMethodCall<FirstScreenListWidget, &setFocus>("setFocus");
	aContext.captureMethodCall<FirstScreenListWidget, &removeCategory>("removeCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &removeContents>("removeContents");
	aContext.captureMethodCall<FirstScreenListWidget, &sendEnterSignal>("sendEnterSignal");
	aContext.captureMethodCall<FirstScreenListWidget, &getCategory>("getCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &getContents>("getContents");
	aContext.captureMethodCall<FirstScreenListWidget, &findContents>("findContents");
	aContext.captureMethodCall<FirstScreenListWidget, &findCategory>("findCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &riseFirstScreen>("riseFirstScreen");
	aContext.captureMethodCall<FirstScreenListWidget, &stopTransition>("stopTransition");
	aContext.captureMethodCall<FirstScreenListWidget, &getPositionX>("getPositionX");
	aContext.captureMethodCall<FirstScreenListWidget, &getPositionY>("getPositionY");
	aContext.captureMethodCall<FirstScreenListWidget, &changeIcon>("changeIcon");
	aContext.captureMethodCall<FirstScreenListWidget, &reverseOSD>("reverseOSD");
	aContext.captureMethodCall<FirstScreenListWidget, &fallFirstScreen>("fallFirstScreen");
	aContext.captureMethodCall<FirstScreenListWidget, &off_transition_noanimaition>("off_transition_noanimaition");
	aContext.captureMethodCall<FirstScreenListWidget, &setFirstState>("setFirstState");
	aContext.captureMethodCall<FirstScreenListWidget, &returnAnimation>("returnAnimation");
	aContext.captureMethodCall<FirstScreenListWidget, &addSubMain>("addSubMain");
	aContext.captureMethodCall<FirstScreenListWidget, &changeContentLive>("changeContentLive");
	aContext.captureMethodCall<FirstScreenListWidget, &getCategoryIndexByID>("getCategoryIndexByID");
	aContext.captureMethodCall<FirstScreenListWidget, &setProgress>("setProgress");
	aContext.captureMethodCall<FirstScreenListWidget, &focusOptions>("focusOptions");
	aContext.captureMethodCall<FirstScreenListWidget, &unfocusOptions>("unfocusOptions");
	aContext.captureMethodCall<FirstScreenListWidget, &enterOptions>("enterOptions");
	aContext.captureMethodCall<FirstScreenListWidget, &setExtendBezierAndTime>("setExtendBezierAndTime");
	aContext.captureMethodCall<FirstScreenListWidget, &setLiveImageBezierAndTime>("setLiveImageBezierAndTime");
	aContext.captureMethodCall<FirstScreenListWidget, &setHorizontalFoveaBezier>("setHorizontalFoveaBezier");
	aContext.captureMethodCall<FirstScreenListWidget, &setVerticalFoveaBezier>("setVerticalFoveaBezier");
	aContext.captureMethodCall<FirstScreenListWidget, &setContentLiveBezierAndTime>("setContentLiveBezierAndTime");
	
	aContext.captureMethodCall<FirstScreenListWidget, &sendKeyEvent>("sendKeyEvent");
	aContext.captureMethodCall<FirstScreenListWidget, &getSelectedItemPos>("getSelectedItemPos");
	aContext.captureMethodCall<FirstScreenListWidget, &updateDominantColor>("updateDominantColor");
	aContext.captureMethodCall<FirstScreenListWidget, &startFovea>("startFovea");
	aContext.captureMethodCall<FirstScreenListWidget, &stopFovea>("stopFovea");
	aContext.captureMethodCall<FirstScreenListWidget, &setOnItemSelectedListener>("setOnItemSelectedListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setOnItemLongPressedListener>("setOnItemLongPressedListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setOnItemChangedListener>("setOnItemChangedListener");
	aContext.captureMethodCall<FirstScreenListWidget, &getLastMouseMovedTime>("getLastMouseMovedTime");

	aContext.captureMethodCall<FirstScreenListWidget, &setBarOpacityMax>("setBarOpacityMax");
	aContext.captureMethodCall<FirstScreenListWidget, &setBarOpacityZero>("setBarOpacityZero");
}

Widget* FirstScreenListWidgetBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	LOG_DEBUG(logger, "FirstScreenListWidgetBridge::constructWidget");
	FirstScreenListWidget* listWidget = new FirstScreenListWidget(parent);
	
	return listWidget;
}

ScriptObject FirstScreenListWidgetBridge::addCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	LOG_DEBUG(logger, "FirstScreenListWidgetBridge::addCategory");
	
	FirstScreenCategory* item = new FirstScreenCategory();
	
	ScriptObject options = args[0];
	item->jsInstance = options;
	
	if(options.has("categoryWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("categoryWrapper"));
		item->categoryWrapper = wzd->getActor();
    }
	
	if(options.has("categoryTitle"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("categoryTitle"));
		item->categoryTitle = wzd->getActor();
    }
	
	if(options.has("listWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("listWrapper"));
		item->listWrapper = wzd->getActor();
    }
	
	if(options.has("color"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("color"));
		item->color = wzd->getActor();
    }
	
	if(options.has("liveParent1"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("liveParent1"));
		item->liveParent1 = wzd->getActor();
    }
	
	if(options.has("liveParent2"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("liveParent2"));
		item->liveParent2 = wzd->getActor();
    }
	
	if(options.has("post1"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post1"));
		item->post1 = wzd->getActor();
    }
	
	if(options.has("post2"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post2"));
		item->post2 = wzd->getActor();
    }
	
	if(options.has("post3"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post3"));
		item->post3 = wzd->getActor();
    }
	
	if(options.has("post4"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post4"));
		item->post4 = wzd->getActor();
    }
	
	if(options.has("post5"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post5"));
		item->post5 = wzd->getActor();
    }
	
	if(options.has("post6"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post6"));
		item->post6 = wzd->getActor();
    }
	
	if(options.has("border"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("border"));
		item->border = wzd->getActor();
    }

	if(options.has("id"))
	{
		item->id = options.get("id").asString();
	}
	
	if(options.has("onExtend"))
    {
		item->onExtendCallback = options.get("onExtend").asFunction();
	}
	
	self->createChild(item);
	
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::addContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	LOG_DEBUG(logger, "FirstScreenListWidgetBridge::addContents");
	
	FirstScreenContents* item = new FirstScreenContents();
	
	ScriptObject options = args[0];
	item->jsInstance = options;

	if(options.has("contentsWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("contentsWrapper"));
		item->contentsWrapper = wzd->getActor();
    }
	
	if(options.has("dominant"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("dominant"));
		item->dominant = wzd->getActor();
    }
	
	if(options.has("titleParent"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("titleParent"));
		item->titleParent = wzd->getActor();
    }
	
	if(options.has("mainWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("mainWrapper"));
		item->mainWrapper = wzd->getActor();
    }
	
	if(options.has("main"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("main"));
		item->main = wzd->getActor();
    }
	
	if(options.has("overRay"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("overRay"));
		item->overRay = wzd->getActor();
    }
	
	if(options.has("normalTitle"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("normalTitle"));
		item->normalTitle = wzd->getActor();
    }
	
	if(options.has("focusTitle"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("focusTitle"));
		item->focusTitle = wzd->getActor();
    }
	
	if(options.has("border"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("border"));
		item->border = wzd->getActor();
    }
	
	if(options.has("iconParent1"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("iconParent1"));
		item->iconParent1 = wzd->getActor();
    }
	
	if(options.has("iconParent2"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("iconParent2"));
		item->iconParent2 = wzd->getActor();
    }
	
	if(options.has("subMain"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("subMain"));
		item->subMain = wzd->getActor();
    }
	
	if(options.has("progress"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("progress"));
		item->progressP = wzd->getActor();
    }

	if (options.has("haveOptions"))
	{
		item->haveOptions = options.get("haveOptions").asBool();
	}
	else
	{
		item->haveOptions = false;
	}

	if(options.has("options") && item->haveOptions)
	{
		Widget* wzd = unwrapNativeObject<Widget>(options.get("options"));
		item->options = wzd->getActor();
	}
	
	if(options.has("dominantColor"))
    {
		item->dominantColor = ScriptToColor(options.get("dominantColor"));
	}
	
	if(options.has("index"))
    {
		item->index = options.get("index").asNumber();
	}
	
	if(options.has("categoryType"))
    {
		item->categoryType = options.get("categoryType").asString();
	}
	
	if(options.has("onClick"))
    {
		item->onClickCallback = options.get("onClick").asFunction();
	}

	if(options.has("startTransitionCallback"))
    {
		item->startTransitionCallback = options.get("startTransitionCallback").asFunction();
	}

	if(options.has("stopTransitionCallback"))
    {
		item->stopTransitionCallback = options.get("stopTransitionCallback").asFunction();
	}

	if (options.has("focusOptionsCallback"))
	{
		item->focusOptionsCallback = options.get("focusOptionsCallback").asFunction();
	}
	
	if (options.has("unfocusOptionsCallback"))
	{
		item->unfocusOptionsCallback = options.get("unfocusOptionsCallback").asFunction();
	}

	if (options.has("enterOptionsCallback"))
	{
		item->enterOptionsCallback = options.get("enterOptionsCallback").asFunction();
	}
	
	if(options.has("id"))
	{
		item->id = options.get("id").asString();
	}
	
	if(options.has("skipTransition"))
	{
		item->skipTransition = options.get("skipTransition").asBool();
	}
	else
	{
		item->skipTransition = false;
	}
	

	if(options.has("longPressCallback"))
    {
		item->longPressCallback = options.get("longPressCallback").asFunction();
	}


	self->createContents(item);
	
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::off_transition_noanimaition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->off_transition_noanimaition();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::moveLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->moveLeft();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::moveRight(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->moveRight();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setFocus(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	int contentsIndex = (int) args[0].asNumber();
	
	self->setFocus(contentsIndex);
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::removeCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	
	int categoryIndex = (int) args[0].asNumber();
	
	self->removeCategory(categoryIndex);
	
	//self->removeCategoryById(args[0].asString());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::removeContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	/*
	int categoryIndex = (int) args[0].asNumber();
	int contentsIndex = (int) args[1].asNumber();
	
	self->removeContents(categoryIndex, contentsIndex);
	*/
	self->removeContentsById(args[0].asString());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::sendEnterSignal(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->animateOnEnter();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::getCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->returnCategory());
}

ScriptObject FirstScreenListWidgetBridge::getContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->returnContents());
}

ScriptObject FirstScreenListWidgetBridge::riseFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->riseFirstScreen();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::getSelectedItemPos(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getSelectedItemPos());
}

ScriptObject FirstScreenListWidgetBridge::startFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->startAnimation();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::stopFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->stopAnimation();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::stopTransition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->stop_transition();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::getPositionX(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getPositionX(args[0].asString(), (int)args[1].asNumber()));
}

ScriptObject FirstScreenListWidgetBridge::getPositionY(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getPositionY(args[0].asString(), (int)args[1].asNumber()));
}

ScriptObject FirstScreenListWidgetBridge::changeIcon(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	Widget* wzd = unwrapNativeObject<Widget>(args[3]);
	ClutterActor* newIconParent = wzd->getActor();
	
	self->changeIcon(args[0].asString(), (int)args[1].asNumber(), (int)args[2].asNumber(), newIconParent);
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::reverseOSD(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if (args.Length() != 0 && args[0].isBool())
	{
		self->reverseOSD(args[0].asBool());
	}
	else
	{
		self->reverseOSD(false); // default do not reverse OSD
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::addSubMain(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	try
	{
		Widget* wzd = unwrapNativeObject<Widget>(args[2]);
		ClutterActor* newSubMain = wzd->getActor();
	
		self->addSubMain(args[0].asString(), (int)args[1].asNumber(), newSubMain);
	}
	catch (VoltJsRuntimeException &e)
	{
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::changeContentLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	try
	{
		Widget* wzd = unwrapNativeObject<Widget>(args[4]);
		ClutterActor* contentLive = wzd->getActor();
	
		self->changeContentLive(args[0].asString(), args[1].asString(), (int)args[2].asNumber(), (int)args[3].asNumber(), contentLive);
	}
	catch (VoltJsRuntimeException &e)
	{
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setProgress(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setProgress(args[0].asString(), (int)args[1].asNumber(), (gfloat)args[2].asNumber());
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::focusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if (self->focusOptions())
	{
		return ScriptObject(true);
	}
	else
	{
		return ScriptObject(false);
	}
}

ScriptObject FirstScreenListWidgetBridge::unfocusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->unfocusOptions();

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::enterOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if (self->enterOptions())
	{
		return ScriptObject(true);
	}
	else
	{
		return ScriptObject(false);
	}
}


ScriptObject FirstScreenListWidgetBridge::setExtendBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setExtendBezierAndTime((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber(), (gfloat)args[4].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setLiveImageBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setLiveImageBezierAndTime((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber(), (gfloat)args[4].asNumber(), (gfloat)args[5].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setHorizontalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setHorizontalFoveaBezier((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setVerticalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setVerticalFoveaBezier((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setContentLiveBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setContentLiveBezierAndTime((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber(), (gfloat)args[4].asNumber(), (gfloat)args[5].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::getCategoryIndexByID(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getCategoryIndexByID(args[0].asString()));
}

ScriptObject FirstScreenListWidgetBridge::fallFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->fallFirstScreen();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::updateDominantColor(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	Widget* wzd = unwrapNativeObject<Widget>(args[0]);
	ClutterActor* dominant = wzd->getActor();
	
	Color dominantColor = ScriptToColor(args[1]);
	
	self->updateDominantColor(dominant, dominantColor);

	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::sendKeyEvent(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	LOG_DEBUG(logger, "FirstScreenListWidgetBridge::sendKeyEvent");
	int keyType = args[0].asNumber();
	int keyCode = args[1].asNumber();

	if (keyCode == KEY_JOYSTICK_OK)
	{
		if (keyType == EVENT_KEY_PRESS)
		{
			ScriptArray args;
			args.set(0, ScriptObject(self->getSelectedItemPos()));
			
			self->onItemSelectedListener.invoke(args);
		}
	}
	else
	{
		self->sendKeyEvent(keyType, keyCode);
	}

	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::findCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	FirstScreenCategory* category = self->findCategory(args[0].asString());

	if (category != NULL)
	{
		return category->jsInstance;
	}

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::findContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	std::string id = args[0].asString();
	FirstScreenContents* contents = self->findContents(id);
	printf("id: %s data: %d\n", id.c_str(), contents);

	if (contents != NULL)
	{
		return contents->jsInstance;
	}

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setOnItemSelectedListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setOnItemSelectedListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setOnItemLongPressedListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setOnItemLongPressedListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setOnItemChangedListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setOnItemChangedListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::getLastMouseMovedTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getLastMouseMovedTime());
}


ScriptObject FirstScreenListWidgetBridge::setFirstState(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setFirstState();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::returnAnimation(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->returnAnimation();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setBarOpacityZero(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setBarOpacityZero();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setBarOpacityMax(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setBarOpacityMax();
	
	return ScriptObject();
}

} /* namespace Bridge */
