/*
 * ResourceBridge.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "ResourceBridge.h"

#include <clutter/clutter.h>

#include "ResourceManager.h"
#include "DirIORequest.h"
#include "Exception.h"
#include "StaticUI.h"

using namespace v8;
using namespace Bridge;
using namespace Resource;
using namespace volt::util;

/* Loggers for performance measurements. */
static volt::util::Logger s_logger_perf_request_sync("volt.perf.request.sync");

class OnCompleteData
{
  public:
    OnCompleteData(IORequest::SharedPtr aRequest,
                   const ScriptFunction &aJsSuccessCallback,
                   const ScriptFunction &aJsErrorCallback,
                   const ScriptFunction &aJsCompleteCallback,
                   const ScriptFunction &aJsCallback):
      request(aRequest),
      js_success_callback(aJsSuccessCallback),
      js_error_callback(aJsErrorCallback),
      js_complete_callback(aJsCompleteCallback),
      js_callback(aJsCallback)
    {
    }

    IORequest::SharedPtr request;
    const ScriptFunction &js_success_callback;
    const ScriptFunction &js_error_callback;
    const ScriptFunction &js_complete_callback;
    const ScriptFunction &js_callback;
};

std::string ResourceBridge::LOGGER_NAME = "volt.resource.bridge";

ResourceBridge::ResourceBridge(): ScriptBridge(), logger_(LOGGER_NAME)
{
}

ResourceBridge::~ResourceBridge()
{
}

void ResourceBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(logger_, "Mapping script interfaces");

  aContext.bindNumber<ResourceRequest,
                      unsigned int,
                      &ResourceRequest::id,
                      &ResourceRequest::set_id>("id");

  aContext.bindConstString<ResourceRequest,
                           &ResourceRequest::uri,
                           &ResourceRequest::set_uri>("uri");

  aContext.bindConstString<ResourceRequest,
                           &ResourceRequest::method,
                           &ResourceRequest::set_method>("method");

  aContext.bindConstString<ResourceRequest,
                           &ResourceRequest::src,
                           &ResourceRequest::set_src>("src");

  aContext.bindBoolean<ResourceRequest,
                       &ResourceRequest::async,
                       &ResourceRequest::set_async>("async");

  aContext.bindBoolean<ResourceRequest,
                       &ResourceRequest::recursive,
                       &ResourceRequest::set_recursive>("recursive");

  aContext.bindFunction<ResourceRequest,
                        &ResourceRequest::success_callback,
                        &ResourceRequest::set_success_callback>("success");

  aContext.bindFunction<ResourceRequest,
                        &ResourceRequest::error_callback,
                        &ResourceRequest::set_error_callback>("error");

  aContext.bindFunction<ResourceRequest,
                        &ResourceRequest::complete_callback,
                        &ResourceRequest::set_complete_callback>("complete");

  aContext.bindFunction<ResourceRequest,
                        &ResourceRequest::async_callback,
                        &ResourceRequest::set_async_callback>("callback");

  aContext.bindNumber<ResourceRequest,
                      long int,
                      &ResourceRequest::status,
                      &ResourceRequest::set_status>("status");

  aContext.bindConstString<ResourceRequest,
                           &ResourceRequest::response_type,
                           &ResourceRequest::set_response_type>("response_type");

  aContext.captureMethodCall<ResourceRequest, &HandleAddHeader>("addHeader");
  aContext.captureMethodCall<ResourceRequest, &HandleRemoveHeader>("removeHeader");
  aContext.captureMethodCall<ResourceRequest, &HandleClearHeaders>("clearHeaders");
  aContext.captureMethodCall<ResourceRequest, &HandleReplaceHeader>("replaceHeader");
  aContext.captureMethodCall<ResourceRequest, &HandleAssignHeaders>("assignHeaders");
  aContext.captureMethodCall<ResourceRequest, &HandleSetHeaders>("setHeaders");
  aContext.captureMethodCall<ResourceRequest, &HandleSetHeaderBlock>("setHeaderBlock");
  aContext.captureMethodCall<ResourceRequest, &HandleProcess>("process");
  aContext.captureMethodCall<ResourceRequest, &HandleCancel>("cancel");

  aContext.capturePropertyAccess<ResourceRequest,
                                 &getResourceRequestData,
                                 &setResourceRequestData>("data");

  aContext.bindBoolean<ResourceRequest, &ResourceRequest::no_cache,
                       &ResourceRequest::set_no_cache>("noCache");
}

void* ResourceBridge::constructFromScript(const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);

  if (aArgs.Length() == 0)
  {
    return new ResourceRequest("");
  }

  ResourceRequest *retval = NULL;

  ScriptObject obj;

  if (aArgs.Length() == 1 && aArgs[0].tryGet("uri", obj))
  {
    /* Map as an argument */
    retval = new ResourceRequest(obj.asString());

    ScriptObject obj;

    if (aArgs[0].tryGet("method", obj))
    {
      retval->set_method(obj.asString());
    }

    if (aArgs[0].tryGet("async", obj))
    {
      retval->set_async(obj.asBool());
    }

    if (aArgs[0].tryGet("recursive", obj))
    {
      retval->set_recursive(obj.asBool());
    }

    if (aArgs[0].tryGet("success", obj))
    {
      retval->set_success_callback(obj.asFunction());
    }

    if (aArgs[0].tryGet("error", obj))
    {
      retval->set_error_callback(obj.asFunction());
    }

    if (aArgs[0].tryGet("complete", obj))
    {
      retval->set_complete_callback(obj.asFunction());
    }

    if (aArgs[0].tryGet("callback", obj))
    {
      retval->set_async_callback(obj.asFunction());
    }

    if (aArgs[0].tryGet("response_type", obj))
    {
      retval->set_response_type(obj.asString());
    }

    if (aArgs[0].tryGet("src", obj))
    {
      retval->set_src(obj.asString());
    }

    if (aArgs[0].tryGet("data", obj))
    {
      // array buffer type
      if(obj.isArrayBuffer())
      {
        const char *buffer = (const char*) obj.getExternalData();
        size_t bufferLength = (size_t) obj.getExternalDataLength();

        if (buffer != NULL and bufferLength > 0)
        {
          // this should just copy the data over, since by the time it gets done, the script object could be gone
          retval->set_data(std::string(buffer, bufferLength));
          LOG_DEBUG(logger, "got request data in array buffer, length: " << retval->data().length());
        }
        else
        {
          LOG_WARN(logger, "Can't set an empty external data field as array buffer");
        }
      }
      // string type
      else
      {
        retval->set_data(obj.asString());
        LOG_DEBUG(logger, "got request data in string, length" << retval->data().length());
      }
    }

    if (aArgs[0].tryGet("noCache", obj))
    {
      retval->set_no_cache(obj.asBool());
    }
  }
  else
  {
    /* positional */
    retval = new ResourceRequest(aArgs[0].asString());

    if (aArgs.Length() > 1)
    {
      retval->set_async(aArgs[1].asBool());
    }

    if (aArgs.Length() > 2)
    {
      retval->set_async_callback(aArgs[2].asFunction());
    }
  }

  return retval;
}

ScriptObject ResourceBridge::HandleAddHeader(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling addHeader");

  do
  {
    std::string key = aArgs[0].asString();
    std::string val = aArgs[1].asString();

    LOG_DEBUG(logger, "Add header: " << key << ": " << val);
    aReqInfo->AddHeader(key, val);
    return ScriptObject(true);
  }
  while(0);

  LOG_WARN(logger, "Invalid arguments given");
  return ScriptObject(false);
}

ScriptObject ResourceBridge::HandleRemoveHeader(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling removeHeader");

  do
  {
    std::string header = aArgs[0].asString();

    bool remove_all = aArgs.Length() > 1 ? aArgs[1].asBool() : false;

    LOG_DEBUG(logger, "Remove " << (remove_all ? "all " : "") << "header: " << header);
    bool result = aReqInfo->RemoveHeader(header, remove_all);
    return ScriptObject(result);
  }
  while(0);

  LOG_WARN(logger, "Invalid arguments given");
  return ScriptObject(false);
}

ScriptObject ResourceBridge::HandleClearHeaders(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling clearHeaders");

  aReqInfo->ClearHeaders();
  return ScriptObject(true);
}

ScriptObject ResourceBridge::HandleReplaceHeader(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling replaceHeader");

  do
  {
    std::string name = aArgs[0].asString();
    std::string val = aArgs[1].asString();

    bool create_new = aArgs.Length() > 2 ? aArgs[2].asBool() : false;

    LOG_DEBUG(logger, "Replace " << (create_new ? " or create " : "") <<
              "header: " << name << ": " << val);

    if (aReqInfo->RemoveHeader(name, true) || create_new)
    {
      /* Removed at least 1 existing header or the create_new flag is set*/
      aReqInfo->AddHeader(name, val);
      return ScriptObject(true);
    }
    else
    {
      /* No existing header and create_new is false */
      return ScriptObject(false);
    }
  }
  while(0);

  LOG_WARN(logger, "Invalid arguments given");
  return ScriptObject(false);
}

ScriptObject ResourceBridge::HandleAssignHeaders(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling assignHeaders");

  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger, "assignHeaders requires a list of key-val pairs");
    return ScriptObject(false);
  }

  aReqInfo->ClearHeaders();

  const ScriptArray &headers = aArgs[0].asArray();

  std::string name;
  ScriptArray namesArray;
  ScriptObject valObj;

  for (unsigned int index = 0; index < headers.Length(); ++index)
  {
    namesArray = headers[index].getKeyNames();

    for (unsigned int nindex = 0; nindex < namesArray.Length(); ++nindex)
    {
      name = namesArray[nindex].asString();

      if (headers[index].tryGet(name, valObj))
      {
        aReqInfo->AddHeader(name, valObj.asString());
      }
    }
  }

  return ScriptObject(true);
}

ScriptObject ResourceBridge::HandleSetHeaders(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling setHeaders");

  do
  {
    ScriptObject obj;

    if (aArgs[0].tryGet("contentType", obj) )
    {
      aReqInfo->AddHeader("Content-Type", obj.asString());
    }

    if (aArgs[0].tryGet("contentLength", obj))
    {
      aReqInfo->AddHeader("Content-Length", obj.asString());
    }

    if (aArgs[0].tryGet("accept", obj) || aArgs[0].tryGet("Accept", obj))
    {
      aReqInfo->AddHeader("Accept:", obj.asString());
    }

    if (aArgs[0].tryGet("Host", obj) || aArgs[0].tryGet("host", obj))
    {
      aReqInfo->AddHeader("Host", obj.asString());
    }

    if (aArgs[0].tryGet("cacheControl", obj))
    {
      aReqInfo->AddHeader("Cache-Control", obj.asString());
    }

    if (aArgs[0].tryGet("acceptEncoding", obj))
    {
      aReqInfo->AddHeader("Accept-Encoding", obj.asString());
    }

    if (aArgs[0].tryGet("aToken", obj) || aArgs[0].tryGet("AToken", obj))
    {
      aReqInfo->AddHeader("AToken", obj.asString());
    }

    if (aArgs[0].tryGet("userToken", obj) || aArgs[0].tryGet("UserToken", obj))
    {
      aReqInfo->AddHeader("UserToken", obj.asString());
    }

    if (aArgs[0].tryGet("DUID", obj))
    {
      aReqInfo->AddHeader("DUID", obj.asString());
    }

    if (aArgs[0].tryGet("smartTVClient", obj) || aArgs[0].tryGet("SmartTVClient", obj))
    {
      aReqInfo->AddHeader("SmartTVClient", obj.asString());
    }

    return ScriptObject(true);
  }
  while(0);

  LOG_DEBUG(logger, "Invalid arguments given");
  return ScriptObject(false);
}

ScriptObject ResourceBridge::HandleSetHeaderBlock(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling setHeaders");

  do
  {
    std::string headers = aArgs[0].asString();
    LOG_DEBUG(logger, "Set headers: " << headers);
    aReqInfo->SetHeaderBlock(headers);

    return ScriptObject(true);
  }
  while(0);

  LOG_DEBUG(logger, "Invalid arguments given");
  return ScriptObject(false);
}

ScriptObject ResourceBridge::HandleProcess(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Handling Process");

  do
  {
    if (aArgs.Length() > 0)
    {
      break;
    }

    LOG_DEBUG(logger, "Process: " << aReqInfo->method() << " " << aReqInfo->uri());

    IORequest::OnCompleteCallback callback =
      std::bind(&ResourceBridge::OnComplete, std::placeholders::_1,
                aReqInfo->success_callback(), aReqInfo->error_callback(),
                aReqInfo->complete_callback(), aReqInfo->async_callback());

    IORequest::SharedPtr request = ResourceManager::CreateRequest(*aReqInfo, callback);

    if (not request)
    {
      break;
    }

    if(request->src().length() and request->data().length())
    {
      LOG_ERROR(logger, "invalid params, both data and src path are set");
      break;
    }

    unsigned int handle = 0;
    bool result = ResourceManager::Instance().Process(request, &handle);

    if (aReqInfo->async())
    {
      aReqInfo->set_requestHandle(handle);
      return ScriptObject(result);
    }
    else
    {
      gint64 prof_start = g_get_monotonic_time();

      LOG_INFO(s_logger_perf_request_sync,
               "Took " << (g_get_monotonic_time() - prof_start) <<
               " usec to process sync request (" << request->uri() << ")");

      OnCompleteData *ptr = new OnCompleteData(request,
          aReqInfo->success_callback(),
          aReqInfo->error_callback(),
          aReqInfo->complete_callback(),
          aReqInfo->async_callback());
      FireOnCompleteCallbacks(ptr);

      /* These will be deprecated/removed soon.
       * Synchronous request will also be a void function.  Result is returned
       * to the JS layer via the registered callbacks. */
      if (result == false)
      {
        return ScriptObject::Null();
      }
      else
      {
        return CreateResponseScriptObject(request);
      }
    }
  }
  while(0);

  LOG_DEBUG(logger, "Invalid arguments given");
  return ScriptObject(false);
}

ScriptObject ResourceBridge::HandleCancel(ResourceRequest *aReqInfo, const ScriptArray &aArgs)
{
  Logger logger(ResourceBridge::LOGGER_NAME);

  if (not aReqInfo->async())
  {
    LOG_ERROR(logger, "request is not async, unable to cancel");
    ScriptObject(false);
  }

  ResourceManager::Instance().Cancel(aReqInfo->requestHandle());
  return ScriptObject(true);
}
void ResourceBridge::OnComplete(IORequest::SharedPtr aRequest,
                                const ScriptFunction &aJsSuccessCallback,
                                const ScriptFunction &aJsErrorCallback,
                                const ScriptFunction &aJsCompleteCallback,
                                const ScriptFunction &aJsCallback)
{
  Logger logger(ResourceBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "IO complete event");

  if (aRequest)
  {
    OnCompleteData *ptr = new OnCompleteData(aRequest,
        aJsSuccessCallback, aJsErrorCallback,
        aJsCompleteCallback, aJsCallback);
    clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                  FireOnCompleteCallbacks, ptr, NULL);
  }
  else
  {
    LOG_WARN(logger, "Request object not given");
  }
}

gboolean ResourceBridge::FireOnCompleteCallbacks(gpointer aData)
{
  OnCompleteData *data = reinterpret_cast<OnCompleteData *>(aData);
  IORequest::SharedPtr request = data->request;
  IOResponse::SharedPtr response = data->request->response();

  Logger logger(ResourceBridge::LOGGER_NAME);

  LOG_DEBUG(logger, "Firing complete callback functions in JS: " << request->uri() << " data length " << response->data().length());

  bool success = false;
  ScriptObject js_response;

  js_response = CreateResponseScriptObject(request);

  if (response->status() >= 200 && response->status() < 300)
  {
    success = true;

    if (data->js_success_callback.isFunction())
    {
      ScriptArray arg;
      arg.set(0, js_response.get("data"));
      arg.set(1, ScriptObject::Null());
      arg.set(2, js_response);

      try
      {
        LOG_DEBUG(logger, "Calling the success callback for " << request->uri());
        data->js_success_callback.invoke(arg);
      }
      catch (VoltJsRuntimeException &e)
      {
        volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute success "
            "event callback", &e);
      }
    }
  }
  else
  {
    if (data->js_error_callback.isFunction())
    {
      ScriptArray arg;
      arg.set(0, js_response);
      arg.set(1, ScriptObject::Null());
      arg.set(2, response->reason_string());

      try
      {
        LOG_DEBUG(logger, "Calling the error callback for " << request->uri());
        data->js_error_callback.invoke(arg);
      }
      catch (VoltJsRuntimeException &e)
      {
        volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute error "
            "event callback", &e);
      }
    }
  }

  if (data->js_complete_callback.isFunction())
  {
    /* TODO: should support more status... */
    std::string status(success ? "success" : "error");

    ScriptArray arg;
    arg.set(0, js_response);
    arg.set(1, status);

    try
    {
      LOG_DEBUG(logger, "Calling the complete callback for " << request->uri());
      data->js_complete_callback.invoke(arg);
    }
    catch (VoltJsRuntimeException &e)
    {
      volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute resource "
          "event callback", &e);
    }
  }

  if (data->js_callback.isFunction())
  {
    ScriptArray arg;
    arg.set(0, js_response);

    try
    {
      LOG_DEBUG(logger, "Calling the default callback for " << request->uri());
      data->js_callback.invoke(arg);
    }
    catch (VoltJsRuntimeException &e)
    {
      volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute resource "
          "event callback", &e);
    }
  }

  delete data;

  return FALSE;
}

ScriptObject
ResourceBridge::CreateResponseScriptObject(const IORequest::SharedPtr aRequest)
{
  ScriptObject obj;
  obj.set("id", ScriptObject((double) aRequest->id()));
  obj.set("source",
          ScriptObject(IOResponse::SourceToString(aRequest->response()->source())));
  obj.set("uri", ScriptObject(aRequest->uri()));
  obj.set("status", ScriptObject((double) aRequest->response()->status()));
  obj.set("reason", ScriptObject(aRequest->response()->reason_string()));
  obj.set("type", ScriptObject(aRequest->response()->type()));
  obj.set("recursive", ScriptObject(aRequest->recursive()));
  obj.set("response_type",
          ScriptObject(IORequest::ResponseTypeToString(aRequest->response_type())));

  ScriptObject headers;

  for (auto iter = aRequest->response()->headers().begin();
       iter != aRequest->response()->headers().end(); ++iter)
  {
    headers.set(iter->first, ScriptObject(iter->second));
  }

  obj.set("headers", ScriptObject(headers));

  if (aRequest->response_type() == IORequest::RESPONSE_ARRAY_BUFFER)
  {
    obj.set("data", ScriptArrayBuffer(aRequest->response()->data().c_str(),
                                      aRequest->response()->data().length()));
  }
  else if(aRequest->response_type() == IORequest::RESPONSE_DIRECTORY)
  {
    obj.set("data", CreateDirResponseScriptObject(aRequest));
  }
  else  // default to string type
  {
    obj.set("data", ScriptObject(aRequest->response()->data()));
  }

  return obj;
}

static ScriptObject ParseDirInfo(const DirInfo &info)
{
  ScriptObject current;
  ScriptArray directories;
  ScriptArray files;

  for(unsigned i = 0; i < info.files.size(); i++)
  {
    ScriptObject file;
    file.set("name", ScriptObject(info.files[i].name));
    file.set("size", ScriptObject(info.files[i].size));
    files.set(i, file);
  }

  for(unsigned i = 0; i < info.directories.size(); i++)
  {
    ScriptObject directory = ParseDirInfo(info.directories[i]);
    directories.set(i, directory);
  }

  current.set("name", ScriptObject(info.name));
  current.set("directories", directories);
  current.set("files", files);
  return current;
}

ScriptObject
ResourceBridge::CreateDirResponseScriptObject(const IORequest::SharedPtr aRequest)
{
  DirIORequest *request = (DirIORequest *) aRequest.get();

  if(not request)
  {
    ScriptObject();
  }

  const DirInfo *info = request->GetDirectoryInfo();

  if(not info->name.length())
  {
    return ScriptObject();
  }

  return ParseDirInfo(*info);
}

ScriptObject ResourceBridge::getResourceRequestData(ResourceRequest* self)
{
  Logger logger(ResourceBridge::LOGGER_NAME);

  if(self->response_type() == "arraybuffer")
  {
    return ScriptArrayBuffer(self->data().c_str(), self->data().length());
  }

  return ScriptObject(self->data());
}

void ResourceBridge::setResourceRequestData(ResourceRequest* self, ScriptObject value)
{
  Logger logger(ResourceBridge::LOGGER_NAME);

  if(value.isArrayBuffer())
  {
    const char *buffer = (const char*) value.getExternalData();
    size_t bufferLength = (size_t) value.getExternalDataLength();

    if (buffer != NULL and bufferLength > 0)
    {
      self->set_data(std::string(buffer, bufferLength));
      LOG_DEBUG(logger, "set data field as array buffer, length " << self->data().length());
    }
    else
    {
      LOG_WARN(logger, "Can't set an empty external data field as array buffer");
    }
  }
  else
  {
    self->set_data(value.asString());
    LOG_DEBUG(logger, "set data field as string, length " << self->data().length());
  }
}
