/*
 * ImageBridge.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "ImageBridge.h"

using namespace volt::util;
using namespace volt::graphics;

namespace Bridge
{

std::string ImageBridge::LOGGER_NAME = "volt.image.bridge";
std::map<Image*, ScriptFunction> Bridge::ImageBridge::gifCompleteCallbacks;

std::map<Image*, Image::SharedPtr> Bridge::ImageBridge::SharedImages;
ImageBridge::ImageBridge(): ScriptBridge(), logger_(LOGGER_NAME)
{
  // this must be set to false for situations
  // where app developer create a function that makes an image,
  // sets it to be child of another class, then goes out of scope
  allowGarbageCollection = false;
}

ImageBridge::~ImageBridge()
{
}

void ImageBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(logger_, "Mapping script interfaces");

  aContext.bindConstString<Image,
                           &Image::uri,
                           &Image::set_uri>("uri");

  aContext.bindBoolean<Image,
                       &Image::async,
                       &Image::set_async>("noAtlas");

  aContext.bindBoolean<Image,
                       &Image::async,
                       &Image::set_async>("noSlicing");

  aContext.bindBoolean<Image,
                       &Image::async,
                       &Image::set_async>("noAutoMipmap");

  aContext.bindBoolean<Image,
                       &Image::async,
                       &Image::set_async>("async");

  aContext.bindFunction<Image,
                        &Image::success_callback,
                        &Image::set_success_callback>("success");

  aContext.bindFunction<Image,
                        &Image::error_callback,
                        &Image::set_error_callback>("error");

  aContext.capturePropertyAccess<Image,
                                 getOnGifComplete,
                                 setOnGifComplete>("onGifComplete");

  //Function calls
#ifdef SUPPORT_CANCEL_ANIMATION
  aContext.captureMethodCall<Image, &cancelGifAnimation>("cancelGifAnimation");
#endif
  aContext.captureMethodCall<Image, &pauseGifAnimation>("pauseGifAnimation");
  aContext.captureMethodCall<Image, &resumeGifAnimation>("resumeGifAnimation");
  aContext.captureMethodCall<Image, &rewindGifAnimation>("rewindGifAnimation");
  aContext.captureMethodCall<Image, &handleDestroy>("destroy");
}

void* ImageBridge::constructFromScript(const ScriptArray &aArgs)
{
  // generate shared pointer and push on to map
  Image::SharedPtr sharedImage = Image::SharedPtr(new Image());
  Image *retval = sharedImage.get();

  // keep a reference of the shared pointer, deref when JS layer call destroy
  SharedImages[retval] = sharedImage;

  if (aArgs.Length() == 0)
  {
    return retval;
  }


  std::string uri;
  ScriptObject obj;

  if (aArgs.Length() == 1 && aArgs[0].tryGet("uri", obj))
  {
    uri = obj.asString();

    if (aArgs[0].tryGet("async", obj))
    {
      retval->set_async(obj.asBool());
    }

    if (aArgs[0].tryGet("noAtlas", obj))
    {
      retval->set_noAtlas(obj.asBool());
    }

    if (aArgs[0].tryGet("noSlicing", obj))
    {
      retval->set_noSlicing(obj.asBool());
    }

    if (aArgs[0].tryGet("noAutoMipmap", obj))
    {
      retval->set_noAutoMipmap(obj.asBool());
    }

    if (aArgs[0].tryGet("success", obj))
    {
      retval->set_success_callback(obj.asFunction());
    }

    if (aArgs[0].tryGet("error", obj))
    {
      retval->set_error_callback(obj.asFunction());
    }

    if (aArgs[0].tryGet("onGifComplete", obj))
    {
      setOnGifComplete(retval, obj);
    }
  }
  else
  {
    /* positional */
    uri = aArgs[0].asString();

    if (aArgs.Length() > 1)
    {
      retval->set_async(aArgs[1].asBool());
    }

    if (aArgs.Length() > 2)
    {
      retval->set_success_callback(aArgs[2].asFunction());
    }

    if (aArgs.Length() > 3)
    {
      retval->set_error_callback(aArgs[3].asFunction());
    }
  }

  retval->set_uri(uri);

  //Register for destruction event. Necessary for proper cleanup of JavaScript objects
  ImageDestructionCallback destructionCallback = std::bind( onDestruction, this, retval);
  retval->registerDestructionEvent(destructionCallback);
  return retval;
}

ScriptObject ImageBridge::getOnGifComplete(Image* self)
{
  if (gifCompleteCallbacks.count(self))
  {
    return gifCompleteCallbacks[self];
  }
  else
  {
    return ScriptObject::Null();
  }
}


void ImageBridge::setOnGifComplete(Image* self, ScriptObject value)
{
  ScriptFunction callback = value.asFunction();
  self->setOnGifComplete(registerGifCompleteCallback(self, callback));
}

ImageGifCompleteCallback ImageBridge::registerGifCompleteCallback(Image* self,
    ScriptFunction onGifComplete)
{
  ImageGifCompleteCallback gifCompleteCallback =
    std::bind(invokeGifCompleteCallback, self, onGifComplete);
  gifCompleteCallbacks[self] = onGifComplete;
  return gifCompleteCallback;
}

void ImageBridge::unregisterGifCompleteCallback(Image* self)
{
  if (gifCompleteCallbacks.count(self))
  {
    gifCompleteCallbacks.erase(self);
  }
}

void ImageBridge::invokeGifCompleteCallback(Image* self, const ScriptFunction& callback)
{
  ScriptArray args;
  callback.invoke(args);

  //once invoked, it need not be invoked again, so unregister it
  unregisterGifCompleteCallback(self);
}

//Function calls:

ScriptObject ImageBridge::cancelGifAnimation(Image* self, const ScriptArray& args)
{
  self->CancelGifAnimation();
  return ScriptObject();
}

ScriptObject ImageBridge::pauseGifAnimation(Image* self, const ScriptArray& args)
{
  self->PauseGifAnimation();
  return ScriptObject();
}

ScriptObject ImageBridge::resumeGifAnimation(Image* self, const ScriptArray& args)
{
  self->ResumeGifAnimation();
  return ScriptObject();
}

ScriptObject ImageBridge::rewindGifAnimation(Image* self, const ScriptArray& args)
{
  self->RewindGifAnimation();
  return ScriptObject();
}
ScriptObject ImageBridge::handleDestroy(Image* self, const ScriptArray& args)
{
  self->HandleDestroy();

  return ScriptObject();
}

void ImageBridge::onDestruction(ImageBridge* bridge, Image* destroyedImage)
{
  releaseForGarbageCollection(bridge, destroyedImage);

  // lose reference to our smart pointer, so it triggers the actual destroy
  SharedImages.erase(destroyedImage);
}
};
