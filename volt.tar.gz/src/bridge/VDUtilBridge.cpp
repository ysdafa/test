/*
* VconfBridge.cpp
*
*  Created on: May 20, 2013
*      Author: ytakebuchi
*/

#include "VDUtilBridge.h"

#include <v8/v8.h>
#include <v8/v8-profiler.h>
#include <boost/config.hpp>
#include <clutter/clutter.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <stdlib.h>

#include "AppConfig.h"
#include "Exception.h"

#include "clutter_helper.h"
#include <clutter/x11/clutter-x11.h>
#include <streamline/streamline_annotate.h>
#include "vconf.h"
#include "system_info.h"
#include <KeyEvent.h>

extern void* GetMainStage();

using namespace v8;
using namespace Bridge;
using namespace volt::util;
using namespace std;

KeyEventRepository repository;

class FileOutputStream : public OutputStream {
 public:
  FileOutputStream(FILE* stream) : stream_(stream) {}

  virtual int GetChunkSize() {
    return 65536;  // big chunks == faster
  }

  virtual void EndOfStream() {}

  virtual WriteResult WriteAsciiChunk(char* data, int size) {
    const size_t len = static_cast<size_t>(size);
    size_t off = 0;

    while (off < len && !feof(stream_) && !ferror(stream_))
      off += fwrite(data + off, 1, len - off, stream_);

    return off == len ? kContinue : kAbort;
  }

 private:
  FILE* stream_;
};

std::string VDUtilBridge::LOGGER_NAME = "volt.vdutil.bridge";
volt::util::Logger VDUtilBridge::logger_(LOGGER_NAME);

VDUtilBridge::VDUtilBridge(): ScriptInstanceBridge(this)
{
}

VDUtilBridge::~VDUtilBridge()
{
}

void VDUtilBridge::mapScriptInterface(ScriptContext& aContext)
{
	LOG_DEBUG(logger_, "Mapping VoltUtil script interfaces");

	aContext.captureMethodCall<VDUtilBridge, &HandleVDSetTimeOfDay>("vd_settimeofday");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDGetTimeOfDay>("vd_gettimeofday");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDLocalTime>("vd_localtime");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDGetTimeZone>("vd_gettimezone");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetProcMemory>("getProcMemory");
	aContext.captureMethodCall<VDUtilBridge, &HandleFirstScreenReady>("firstScreenReady");
	aContext.captureMethodCall<VDUtilBridge, &HandleIsExistWASTempFile>("isExistWASTempFile");
	aContext.captureMethodCall<VDUtilBridge, &HandleHeapSnapShot>("heapSnapshot");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetXWindowID>("getXWindowID");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDAnnotate>("vd_annotate");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDRaiseXWindow>("vd_raiseXWindow");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetMLSstate>("getMLSstate");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetResolution>("getResolution");	
	aContext.captureMethodCall<VDUtilBridge, &HandleScreenCapture>("screenCapture");
	aContext.captureMethodCall<VDUtilBridge, &HandleChangeXPropertyNormal>("changeXPropertynormal");
	aContext.captureMethodCall<VDUtilBridge, &HandleRegisterKey>("registerKey");
	aContext.captureMethodCall<VDUtilBridge, &HandleUnRegisterKey>("unregisterKey");	
}

void* VDUtilBridge::constructFromScript(const ScriptArray &aArgs)
{
	return this;
}

// int vd_settimeofday(long long utctime, int otcoff, int dstoff)
ScriptObject VDUtilBridge::HandleVDSetTimeOfDay(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	if (aArgs.Length() < 3)
	{
		LOG_WARN(logger_, "Argument Error");
		return ScriptObject(-1);
	}

	int utctime = aArgs[0].asNumber();
	int otcoff = aArgs[1].asNumber();
	int dstoff = aArgs[2].asNumber();

	LOG_WARN(logger_, "HandleVDSetTimeOfDay: " << utctime << " " << otcoff << " " << dstoff);

	int ret = vd_settimeofday(utctime, otcoff, dstoff);

	LOG_WARN(logger_, "ret: " << ret);

	return ScriptObject(ret);
}

ScriptObject VDUtilBridge::HandleVDGetTimeOfDay(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	struct timeval tv;
	int ret;

	ret = gettimeofday(&tv, NULL);
	if (ret == -1)
	{
		LOG_ERROR(logger_, "Get Time Of Day Fail!");
		return ScriptObject(ret);
	}
	
	return ScriptObject((int)tv.tv_sec);
}

ScriptObject VDUtilBridge::HandleVDLocalTime(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	time_t sec;
	struct tm *p;

	sec = time(NULL);
	p = localtime(&sec);
	if(p == NULL)
	{
		LOG_ERROR(logger_, "Get Local Time Fail!");
		return ScriptObject(0);
	}

	sec = mktime(p);
	
	return ScriptObject((int)sec);
}

ScriptObject VDUtilBridge::HandleVDGetTimeZone(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int utcoff = 0;
	int dstoff = 0;
	ScriptObject ret;
	
	time_t cur, local, gmt;
	struct tm *q;
	struct tm mytime;
	long diff;

	tzset();
	utcoff = timezone / 60;
	
	time(&cur);
	q = localtime_r(&cur, &mytime);
	if(q == NULL)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;
	}
	

	local = mktime(q);
	if(local == -1)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;		
	}

	q = gmtime_r(&cur, &mytime);
	if(q == NULL)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;		
	}
	
	gmt = mktime(q);
	if(gmt == -1)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;		
	}

	diff = local - gmt;

	dstoff = (q->tm_gmtoff - diff) /60;

	ret.set("utcoff", utcoff);
	ret.set("dstoff", dstoff);

	return ret;
}

ScriptObject VDUtilBridge::HandleGetProcMemory(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	pid_t pid = getpid();
	std::string line;
	std::string data;
	std::ostringstream s;
	s << "/proc/" << (int)pid << "/vd_memstat";
	std::string fileName(s.str());

	LOG_WARN(logger_, "fileName: " << fileName);
	std::ifstream  memfile(fileName);

	if (memfile.is_open())
	{
		while(getline(memfile, line))
		{
			data = data + line + "\n";
		}

		memfile.close();
	}

	return ScriptObject(data);
}

ScriptObject VDUtilBridge::HandleFirstScreenReady(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	syscall(380, "-------------------------FirstScreen display-------------------------"); 
	printf("\n-------------------------FirstScreen display-------------------------");
	
	FILE* fp = NULL;

	fp = fopen("/tmp/firstscreen_ready", "wb");
	fclose(fp);

	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleIsExistWASTempFile(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	FILE* fp = NULL;

	fp = fopen("/tmp/sef_ready", "rb");
	if (fp == NULL)
	{
		return ScriptObject(false);
	}
	fclose(fp);

	fp = fopen("/tmp/was_ready", "rb");
	if (fp == NULL)
	{
		return ScriptObject(false);
	}
	fclose(fp);

	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleHeapSnapShot(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	v8::Isolate* isolate = v8::Isolate::GetCurrent();
	
	const HeapSnapshot* const snapshot = isolate->GetHeapProfiler()->TakeHeapSnapshot(v8::String::Empty(isolate));

	FILE* fp = NULL;
	if (aArgs.Length() > 0)
	{
		LOG_WARN(logger_, "Saving HeapSnapShot to " << aArgs[0].asString());
		fp = fopen(aArgs[0].asString().c_str(), "w");
	}
	else
	{
		char scratch[1024];
		
		struct timeval mytime;
		gettimeofday(&mytime, NULL);

		snprintf(scratch, sizeof(scratch), "%s/heapdump-%ld-%ld.heapsnapshot", AppConfig::Instance().GetAppDataPath().c_str(), mytime.tv_sec, mytime.tv_usec);
		LOG_WARN(logger_, "Saving HeapSnapShot to " << scratch);

		fp = fopen(scratch, "w");
	}

	if (fp == NULL) {
		return false;
	}

	FileOutputStream stream(fp);
	snapshot->Serialize(&stream, HeapSnapshot::kJSON);
	fclose(fp);

	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleGetXWindowID(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Window window = (Window)clutter_x11_get_stage_window ((ClutterStage*) GetMainStage());
	printf("[WindowID] %d\n", window);
	return ScriptObject((int) window);
}

ScriptObject VDUtilBridge::HandleVDAnnotate(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	
	std::string log;
	if( aArgs.Length() > 0)
	{
		ANNOTATE_SETUP;
		log = aArgs[0].asString();
		char* pLog = (char *)log.c_str();
		ANNOTATE_CHANNEL_COLOR(2, ANNOTATE_BLUE, pLog);
		ANNOTATE_CHANNEL_END(2);
	}
	
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleVDRaiseXWindow(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	VDRaiseXWindow((ClutterActor*) GetMainStage());
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleGetMLSstate(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int status = 0;

	vconf_get_int("db/mls/mls_state", &status);

	if(status == 1)
	{
		return ScriptObject(true);
	}

	else
	{
		return ScriptObject(false);
	}

	return ScriptObject(false);
}

ScriptObject VDUtilBridge::HandleGetResolution(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int value = 0;
	int systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_OSD_RESOLUTION_WIDTH, &value);

	return ScriptObject(value);
}

ScriptObject VDUtilBridge::HandleScreenCapture(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	ScreenCapture((ClutterActor*) GetMainStage(), aArgs[0].asString().c_str(), 720);
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleChangeXPropertyNormal(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Display* dpy = clutter_x11_get_default_display();
	Window w = (Window)clutter_x11_get_stage_window ((ClutterStage*)GetMainStage());
	Atom type = XInternAtom(dpy, "_NET_WM_STATE_NORMAL", False);
	XChangeProperty(dpy, w, XInternAtom(dpy, "_NET_WM_STATE", False), XInternAtom(dpy, "ATOM", False), 32, PropModeReplace, (unsigned char *)&type, 1);
	LOG_DEBUG(logger_, "Change _NET_WM_STATE(ATOM) -> _NET_WM_STATE_NORMAL!");

	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleRegisterKey(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Display* dpy = clutter_x11_get_default_display();
	Window w = (Window)clutter_x11_get_stage_window ((ClutterStage*)GetMainStage());
	KeyRepository_RemoveAllKeys(&repository);
	KeyRepository_AddKey(&repository,R_KEY_HOME);
	KeyRepository_AddKey(&repository,R_KEY_UP);
	KeyRepository_AddKey(&repository,R_KEY_DOWN);
	KeyRepository_AddKey(&repository,R_KEY_LEFT);
	KeyRepository_AddKey(&repository,R_KEY_RIGHT);
	KeyRepository_AddKey(&repository,R_KEY_ENTER);
	KeyRepository_AddKey(&repository,R_KEY_BACK);
	KeyRepository_AddKey(&repository,R_KEY_EXIT);	
	KeyRepository_AddKey(&repository, R_KEY_VOLUMEUP);
	KeyRepository_AddKey(&repository, R_KEY_VOLUMEDOWN);
	KeyRepository_AddKey(&repository, R_KEY_MUTE);
	KeyRepository_AddKey(&repository,R_KEY_0);
	KeyRepository_AddKey(&repository,R_KEY_1);
	KeyRepository_AddKey(&repository,R_KEY_2);
	KeyRepository_AddKey(&repository,R_KEY_3);
	KeyRepository_AddKey(&repository,R_KEY_4);
	KeyRepository_AddKey(&repository,R_KEY_5);
	KeyRepository_AddKey(&repository,R_KEY_6);
	KeyRepository_AddKey(&repository,R_KEY_7);
	KeyRepository_AddKey(&repository,R_KEY_8);
	KeyRepository_AddKey(&repository,R_KEY_9);
	LOG_FATAL(logger_, "[First Screen] Register Key !");
	KeyRepository_Register(dpy, w, &repository);
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleUnRegisterKey(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Display* dpy = clutter_x11_get_default_display();
	Window w = (Window)clutter_x11_get_stage_window ((ClutterStage*)GetMainStage());
	KeyRepository_RemoveAllKeys(&repository);
	LOG_FATAL(logger_, "[First Screen] UnRegister VolumeKey !");
	KeyRepository_Register(dpy, w, &repository);
	return ScriptObject(true);
}