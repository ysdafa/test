/*
* TTSBridge
*
*  Created on: 2014-10-14
*      Author: backki.kim
*/

#include "TTSBridge.h"
#include <stdio.h>
#include <stdlib.h>
#include <tts.h>
#include "TaskDispatcher.h"

using namespace v8;
using namespace Bridge;
using namespace volt::util;
using namespace std;

bool ttsInited = false;
tts_h ttsHandle;
tts_mode_e ttsMode;

static void __volt_tts_test_state_changed_cb(tts_h tts, tts_state_e previous, tts_state_e current, void* user_data)
{
	printf("__volt_tts_test_state_changed_cb\n");
}

static void __volt_tts_test_utt_started_cb(tts_h tts, int utt_id, void* user_data)
{
	printf("__volt_tts_test_utt_started_cb\n");
}

static void __volt_tts_test_utt_completed_cb(tts_h tts, int utt_id, void* user_data)
{
	printf("__volt_tts_test_utt_completed_cb\n");
}

static void __volt_init_tts_engine()
{
	if (ttsInited)
	{
		return;
	}

	ttsMode = TTS_MODE_DEFAULT;

	int ret;
	int utt_id;	
				
	ret = tts_create(&ttsHandle);
	if (TTS_ERROR_NONE != ret)
	{
		printf("tts_create_fail\n");
	}

	ret = tts_set_mode(ttsHandle, ttsMode);
	if (TTS_ERROR_NONE != ret)
	{
		printf("tts_setmode fail\n");
		tts_destroy(ttsHandle);
	}

	ret = tts_set_state_changed_cb(ttsHandle, __volt_tts_test_state_changed_cb, NULL);
	if (TTS_ERROR_NONE != ret)
	{
		printf("tts_set_stage_changed fail\n");
		tts_destroy(ttsHandle);	
	}

	ret = tts_set_utterance_started_cb(ttsHandle, __volt_tts_test_utt_started_cb, NULL);
	if (TTS_ERROR_NONE != ret)
	{	
		printf("tts_set_utterance_started fail\n");
		tts_destroy(ttsHandle);	
	}

	ret = tts_set_utterance_completed_cb(ttsHandle, __volt_tts_test_utt_completed_cb, NULL);
	if (TTS_ERROR_NONE != ret)
	{
		printf("tts_set_utterance_completed fail\n");
		tts_destroy(ttsHandle);	
	}
	
	ret = tts_prepare(ttsHandle);	
	if (TTS_ERROR_NONE != ret) 
	{
		printf("tts_prepare fail\n");		
		tts_destroy(ttsHandle);
	}

	ttsInited = true;
}

TTSBridge::TTSBridge(): ScriptInstanceBridge(this)
{
}

TTSBridge::~TTSBridge()
{
}

void TTSBridge::mapScriptInterface(ScriptContext& aContext)
{
	aContext.captureMethodCall<TTSBridge, &HandlePlayText>("play");
}

void* TTSBridge::constructFromScript(const ScriptArray &aArgs)
{
	return this;
}


static void TTSExecuteTask(std::string text)
{
	printf("TTSExecuteTask: %s\n", text.c_str());

	int utt_id;
	int ret = 0;

	tts_stop(ttsHandle);
	tts_add_text(ttsHandle, text.c_str(), NULL, TTS_VOICE_TYPE_AUTO, TTS_SPEED_AUTO, &utt_id);
	ret = tts_play(ttsHandle);
}

ScriptObject TTSBridge::HandlePlayText(TTSBridge *aSelf, const ScriptArray &aArgs)
{
	__volt_init_tts_engine();

	std::string text = aArgs[0].asString();
	/*
	volt::util::TaskDispatcher::Instance().AddTask(std::bind(TTSExecuteTask, text));
	*/

	int utt_id;
	int ret = 0;

	tts_stop(ttsHandle);
	tts_add_text(ttsHandle, text.c_str(), NULL, TTS_VOICE_TYPE_AUTO, TTS_SPEED_AUTO, &utt_id);
	ret = tts_play(ttsHandle);

	return ScriptObject(0);
}
