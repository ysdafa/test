/*
 * ListWidgetBridge.cpp
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#include "ListWidgetBridge.h"

namespace Bridge
{

void Bridge::ListWidgetBridge::mapScriptInterface(ScriptContext& context)
{
  LayoutBridge::mapScriptInterface(context);

  context.bindBoolean<ListWidget, &ListWidget::getUniformSpacing, &ListWidget::setUniformSpacing>("uniform");

  context.capturePropertyAccess<ListWidget, &getSpacing, &setSpacing>("spacing");
}

Widget* Bridge::ListWidgetBridge::constructWidget(float x, float y, float width, float height,
    Widget* parent, const ScriptArray& args)
{
  LayoutOrientation orientation = LayoutOrientation::Horizontal;
  Vector2 spacing;

  if(args.Length() > 0)
  {
    if( args[0].has("orientation") && args[0]["orientation"].isString() )
    {
      orientation = deserializeLayoutOrientation(args[0]["orientation"].asString());
    }

    if (args[0].has("spacing"))
    {
      ScriptObject value = args[0]["spacing"];

      if(value.isNumber())
      {
        float num = value.asNumber();
        spacing = Vector2(num, num);
      }
      else
      {
        spacing = ScriptToVector2(value);
      }
    }
  }

  if(width == -1)
  {
    width = 0;
  }

  if(height == -1)
  {
    height = 0;
  }

  return new ListWidget(x, y, width, height, parent, spacing, orientation);
}

ScriptObject ListWidgetBridge::getSpacing(ListWidget* self)
{
  return ScriptObject(self->getSpacing().x);
}

void ListWidgetBridge::setSpacing(ListWidget* self, ScriptObject value)
{
  if(value.isNumber())
  {
    float num = value.asNumber();
    self->setSpacing(Vector2(num, num));
  }
  else
  {
    self->setSpacing(ScriptToVector2(value));
  }
}




}



