/*
 * VconfBridge.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "VconfBridge.h"

#include <boost/config.hpp>
#include <clutter/clutter.h>
#include <sstream>

#include "Exception.h"

using namespace v8;
using namespace Bridge;
using namespace volt::util;

std::string VconfBridge::LOGGER_NAME = "volt.vconf.bridge";
volt::util::Logger VconfBridge::logger_(LOGGER_NAME);

namespace /* anonymous */
{
/**
 * This is the struct sent from the vconf notify thread to the clutter thread.
 * Can't simply pass keynode_t pointer around because the reference object
 * seem to be invalidated/destroyed after OnChangeHandlerProxy goes out of
 * scope. */
struct OnChangeData
{
  OnChangeData(VconfBridge *aSelf, int aType, std::string aKey):
    self(aSelf), type(aType), key(aKey) {}

  VconfBridge *self;
  int type;
  std::string key;
};
}

VconfBridge::VconfBridge(): ScriptInstanceBridge(this)
{
}

VconfBridge::~VconfBridge()
{
}

void VconfBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(logger_, "Mapping Vconf script interfaces");

  aContext.captureMethodCall<VconfBridge, &HandleGetValue>("getValue");
  aContext.captureMethodCall<VconfBridge, &HandleGetInteger>("getInteger");
  aContext.captureMethodCall<VconfBridge, &HandleGetDouble>("getDouble");
  aContext.captureMethodCall<VconfBridge, &HandleGetBool>("getBool");
  aContext.captureMethodCall<VconfBridge, &HandleGetString>("getString");
  aContext.captureMethodCall<VconfBridge, &HandleGetValues>("getValues");
  aContext.captureMethodCall<VconfBridge, &HandleSetValue>("setValue");
  aContext.captureMethodCall<VconfBridge, &HandleSetInteger>("setInteger");
  aContext.captureMethodCall<VconfBridge, &HandleSetDouble>("setDouble");
  aContext.captureMethodCall<VconfBridge, &HandleSetBool>("setBool");
  aContext.captureMethodCall<VconfBridge, &HandleSetString>("setString");
  aContext.captureMethodCall<VconfBridge, &HandleUnsetValue>("unsetValue");
  aContext.captureMethodCall<VconfBridge, &HandleSetOnChangeHandler>("setOnChangeHandler");
  aContext.captureMethodCall<VconfBridge, &HandleUnsetOnChangeHandler>("unsetOnChangeHandler");
}

void* VconfBridge::constructFromScript(const ScriptArray &aArgs)
{
  return this;
}

ScriptObject VconfBridge::HandleGetValue(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() != 1)
  {
    std::stringstream sstream;
    sstream << "Expected 1 argument, got " << aArgs.Length();
    throw VoltJsRuntimeException(sstream.str().c_str());
  }

  std::string key = aArgs[0].asString();
  if (key.empty())
  {
    LOG_WARN(logger_, "Empty key given");
    return ScriptObject();
  }

  LOG_DEBUG(logger_, "Get vconf value: " << key);

#ifdef HAS_VCONF
  union
  {
    int i;
    double d;
    char *s;
  } val;

  if (vconf_get_int(key.c_str(), &val.i) == 0)
  {
    LOG_DEBUG(logger_, "Got int value: " << key << " = " << val.i);
    return ScriptObject(val.i);
  }
  else if (vconf_get_dbl(key.c_str(), &val.d) == 0)
  {
    LOG_DEBUG(logger_, "Got double value: " << key << " = " << val.d);
    return ScriptObject(val.d);
  }
  else if (vconf_get_bool(key.c_str(), &val.i) == 0)
  {
    LOG_DEBUG(logger_, "Got bool value: " << key << " = " << val.i);
    return ScriptObject(val.i != 0);
  }
  else if ((val.s = vconf_get_str(key.c_str())))
  {
    std::string the_val(val.s);
    free(val.s);

    LOG_DEBUG(logger_, "Got string value: " << key << " = " << the_val);
    return ScriptObject(the_val);
  }
  else
  {
    LOG_WARN(logger_, "Failed to get vconf value: " << key);
    return ScriptObject();
  }
#else
  LOG_WARN(logger_, "Vconf.getValue is not supported in this build: " << key);
  return ScriptObject();
#endif
}

ScriptObject VconfBridge::HandleGetInteger(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() != 1)
  {
    std::stringstream sstream;
    sstream << "Expected 1 argument, got " << aArgs.Length();
    throw VoltJsRuntimeException(sstream.str().c_str());
  }

  std::string key = aArgs[0].asString();
  if (key.empty())
  {
    LOG_WARN(logger_, "Empty key given");
    return ScriptObject();
  }

  LOG_DEBUG(logger_, "Get vconf integer value: " << key);

#ifdef HAS_VCONF
  int val;

  if (vconf_get_int(key.c_str(), &val) == 0)
  {
    LOG_DEBUG(logger_, "Got integer value: " << key << " = " << val);
    return ScriptObject(val);
  }
  else
  {
    LOG_WARN(logger_, "Failed to get vconf integer value: " << key);
    return ScriptObject();
  }
#else
  LOG_WARN(logger_, "Vconf.getInteger is not supported in this build: " << key);
  return ScriptObject();
#endif
}

ScriptObject VconfBridge::HandleGetDouble(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() != 1)
  {
    std::stringstream sstream;
    sstream << "Expected 1 argument, got " << aArgs.Length();
    throw VoltJsRuntimeException(sstream.str().c_str());
  }

  std::string key = aArgs[0].asString();
  if (key.empty())
  {
    LOG_WARN(logger_, "Empty key given");
    return ScriptObject();
  }

  LOG_DEBUG(logger_, "Get vconf double value: " << key);

#ifdef HAS_VCONF
  double val;

  if (vconf_get_dbl(key.c_str(), &val) == 0)
  {
    LOG_DEBUG(logger_, "Got double value: " << key << " = " << val);
    return ScriptObject(val);
  }
  else
  {
    LOG_WARN(logger_, "Failed to get vconf double value: " << key);
    return ScriptObject();
  }
#else
  LOG_WARN(logger_, "Vconf.getDouble is not supported in this build: " << key);
  return ScriptObject();
#endif
}

ScriptObject VconfBridge::HandleGetBool(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() != 1)
  {
    std::stringstream sstream;
    sstream << "Expected 1 argument, got " << aArgs.Length();
    throw VoltJsRuntimeException(sstream.str().c_str());
  }

  std::string key = aArgs[0].asString();
  if (key.empty())
  {
    LOG_WARN(logger_, "Empty key given");
    return ScriptObject();
  }

  LOG_DEBUG(logger_, "Get vconf bool value: " << key);

#ifdef HAS_VCONF
  int val;

  if (vconf_get_bool(key.c_str(), &val) == 0)
  {
    LOG_DEBUG(logger_, "Got bool value: " << key << " = " << val);
    return ScriptObject(val != 0);
  }
  else
  {
    LOG_WARN(logger_, "Failed to get vconf bool value: " << key);
    return ScriptObject();
  }
#else
  LOG_WARN(logger_, "Vconf.getBool is not supported in this build: " << key);
  return ScriptObject();
#endif
}

ScriptObject VconfBridge::HandleGetString(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() != 1)
  {
    std::stringstream sstream;
    sstream << "Expected 1 argument, got " << aArgs.Length();
    throw VoltJsRuntimeException(sstream.str().c_str());
  }

  std::string key = aArgs[0].asString();
  if (key.empty())
  {
    LOG_WARN(logger_, "Empty key given");
    return ScriptObject();
  }

  LOG_DEBUG(logger_, "Get vconf string value: " << key);

#ifdef HAS_VCONF
  char *val;

  if ((val = vconf_get_str(key.c_str())))
  {
    std::string the_val(val);
    free(val);

    LOG_DEBUG(logger_, "Got string value: " << key << " = " << the_val);
    return ScriptObject(the_val);
  }
  else
  {
    LOG_WARN(logger_, "Failed to get vconf string value: " << key);
    return ScriptObject();
  }
#else
  LOG_WARN(logger_, "Vconf.getString is not supported in this build: " << key);
  return ScriptObject();
#endif
}

ScriptObject VconfBridge::HandleGetValues(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() != 1)
  {
    std::stringstream sstream;
    sstream << "Expected 1 argument, got " << aArgs.Length();
    throw VoltJsRuntimeException(sstream.str().c_str());
  }

  std::string root = aArgs[0].asString();
  if (root.empty())
  {
    LOG_WARN(logger_, "No root key given");
    return ScriptObject();
  }

#ifdef HAS_VCONF
  /* construct ScriptObject with values under the given root. */
  ScriptObject obj;
  VconfTreeToScriptObject(root, obj);
  return obj;
#else
  LOG_WARN(logger_, "Vconf.getValues is not supported in this build: " << root);
  return ScriptObject();
#endif
}

ScriptObject VconfBridge::HandleSetValue(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

#ifdef HAS_VCONF
    if (aArgs[1].isString())
    {
      LOG_DEBUG(logger_, "Set vconf value: " << key << " = " << aArgs[1].asString());
      retval = vconf_set_str(key.c_str(), aArgs[1].asString().c_str());
    }
    else if (aArgs[1].isNumber())
    {
      LOG_DEBUG(logger_, "Set vconf value: " << key << " = " << aArgs[1].asNumber());
      retval = vconf_set_dbl(key.c_str(), aArgs[1].asNumber());
    }
    else if (aArgs[1].isBool())
    {
      LOG_DEBUG(logger_, "Set vconf value: " << key << " = " << aArgs[1].asBool());
      retval = vconf_set_bool(key.c_str(), aArgs[1].asBool());
    }
    else
    {
      throw VoltJsRuntimeException("Only number/bool/string values are supported in Vconf.setValue");
    }
#else
    LOG_WARN(logger_, "Vconf.setValue is not supported in this build: " << key);
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to set vconf value: " << key);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

ScriptObject VconfBridge::HandleSetInteger(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

    double val = aArgs[1].asNumber();

#ifdef HAS_VCONF
    LOG_DEBUG(logger_, "Set vconf integer value: " << key << " = " << val);
    retval = vconf_set_int(key.c_str(), val);
#else
    LOG_WARN(logger_, "Vconf.setInteger is not supported in this build: " << key << " = " << val);
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to set vconf integer value: " << key << " = " << val);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

ScriptObject VconfBridge::HandleSetDouble(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

    double val = aArgs[1].asNumber();

#ifdef HAS_VCONF
    LOG_DEBUG(logger_, "Set vconf double value: " << key << " = " << val);
    retval = vconf_set_dbl(key.c_str(), val);
#else
    LOG_WARN(logger_, "Vconf.setDouble is not supported in this build: " << key << " = " << val);
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to set vconf double value: " << key << " = " << val);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

ScriptObject VconfBridge::HandleSetBool(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

    bool val = aArgs[1].asBool();

#ifdef HAS_VCONF
    LOG_DEBUG(logger_, "Set vconf bool value: " << key << " = " << val);
    retval = vconf_set_bool(key.c_str(), val);
#else
    LOG_WARN(logger_, "Vconf.setBool is not supported in this build: " << key << " = " << val);
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to set vconf double value: " << key << " = " << val);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

ScriptObject VconfBridge::HandleSetString(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

    std::string val = aArgs[1].asString();

#ifdef HAS_VCONF
    LOG_DEBUG(logger_, "Set vconf value: " << key << " = " << val);
    retval = vconf_set_str(key.c_str(), val.c_str());
#else
    LOG_WARN(logger_, "Vconf.setString is not supported in this build: " << key << " = " << val);
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to set vconf string value: " << key << " = " << val);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

ScriptObject VconfBridge::HandleUnsetValue(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 1 && aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 1 or 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

#ifdef HAS_VCONF
    bool recursive = false;

    if (aArgs.Length() > 1)
    {
      recursive = aArgs[1].asBool();
    }

    if (recursive)
    {
      LOG_DEBUG(logger_, "Unset vconf value recursively: " << key);
      retval = vconf_unset_recursive(key.c_str());
    }
    else
    {
      LOG_DEBUG(logger_, "Unset vconf value: " << key);
      retval = vconf_unset(key.c_str());
    }
#else
    LOG_WARN(logger_, "Vconf.unsetValue is not supported in this build: " << key);
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to unset vconf value: " << key);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

ScriptObject VconfBridge::HandleSetOnChangeHandler(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

    ScriptFunction handler = aArgs[1].asFunction();

    /* Check if there's an existing handler for the key. */
    auto existing_iter = aSelf->on_change_handlers_.end();
    auto existing_range = aSelf->on_change_handlers_.equal_range(key);

    for (auto iter = existing_range.first; iter != existing_range.second; ++iter)
    {
      if (iter->second == handler)
      {
        LOG_WARN(logger_, "Found an existing handler: " << key);
        existing_iter = iter;
        break;
      }
    }

#ifdef HAS_VCONF
    if (existing_range.first == existing_range.second)
    {
      /* No native handler proxy registered yet */
      if ((retval = vconf_notify_key_changed(key.c_str(), OnChangeHandlerProxy, aSelf)) < 0)
      {
        LOG_WARN(logger_, "vconf_notify_key_changed failed: " << key);
      }
    }
    else
    {
      /* Native handler proxy already registered */
      LOG_WARN(logger_, "Not re-registering native handler proxy: " << key);
      retval = 0; /* but still a success */
    }

    if (retval == 0 && existing_iter == aSelf->on_change_handlers_.end())
    {
      /* Save the JS callback */
      aSelf->on_change_handlers_.insert(std::make_pair(key, handler));
    }
#else
    if (existing_iter == aSelf->on_change_handlers_.end())
    {
      aSelf->on_change_handlers_.insert(std::make_pair(key, handler));
    }
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to set handler: " << key);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

ScriptObject VconfBridge::HandleUnsetOnChangeHandler(VconfBridge *aSelf, const ScriptArray &aArgs)
{
  int retval = -1;

  do
  {
    if (aArgs.Length() != 2)
    {
      std::stringstream sstream;
      sstream << "Expected 2 arguments, got " << aArgs.Length();
      throw VoltJsRuntimeException(sstream.str().c_str());
    }

    std::string key = aArgs[0].asString();
    if (key.empty())
    {
      LOG_WARN(logger_, "Empty key given");
      break;
    }

    ScriptFunction handler = aArgs[1].asFunction();

    /* Check if there's an existing handler for the key. */
    auto existing_iter = aSelf->on_change_handlers_.end();
    auto existing_range = aSelf->on_change_handlers_.equal_range(key);

    for (auto iter = existing_range.first; iter != existing_range.second; ++iter)
    {
      if (iter->second == handler)
      {
        LOG_DEBUG(logger_, "Found an existing handler: " << key);
        existing_iter = iter;
        break;
      }
    }

#ifdef HAS_VCONF
    if (existing_iter != aSelf->on_change_handlers_.end())
    {
      /* Remove the JS handler */
      aSelf->on_change_handlers_.erase(existing_iter);

      unsigned int handler_count = aSelf->on_change_handlers_.count(key);

      if (handler_count == 0)
      {
        /* No more JS handlers; remove native handler too. */
        if ((retval = vconf_ignore_key_changed(key.c_str(), OnChangeHandlerProxy)) < 0)
        {
          LOG_WARN(logger_, "vconf_ignore_key_changed failed: " << key);
        }
      }
      else
      {
        /* There's still other JS handlers for the same key. */
        LOG_WARN(logger_, "Not removing native handler, " << handler_count <<
                 " JS handlers left: " << key);
        retval = 0; /* still a success */
      }
    }
#else
    if (existing_iter != aSelf->on_change_handlers_.end())
    {
      aSelf->on_change_handlers_.erase(existing_iter);
    }
#endif

    if (retval != 0)
    {
      LOG_WARN(logger_, "Failed to unset handler: " << key);
    }
  }
  while(0);

  return ScriptObject(retval == 0);
}

#ifdef HAS_VCONF
void VconfBridge::VconfTreeToScriptObject(const std::string &aRoot, ScriptObject &aObj)
{
  keylist_t *list = vconf_keylist_new();

  if (vconf_get(list, aRoot.c_str(), VCONF_GET_ALL) != 0)
  {
    LOG_WARN(logger_, "Failed to get keys from vconf: " << aRoot.c_str());
    return;
  }

  keynode_t *node = NULL;

  while ((node = vconf_keylist_nextnode(list)))
  {
    VconfNodeToScriptObject(node, aObj);
  }

  vconf_keylist_free(list);
}

void VconfBridge::VconfNodeToScriptObject(keynode_t *aNode, ScriptObject &aObj)
{
  std::string key(vconf_keynode_get_name(aNode));

  switch (vconf_keynode_get_type(aNode))
  {
  case VCONF_TYPE_INT:
    LOG_DEBUG(logger_, key << " = " << vconf_keynode_get_int(aNode));
    aObj.set(key, ScriptObject(vconf_keynode_get_int(aNode)));
    break;
  case VCONF_TYPE_BOOL:
    LOG_DEBUG(logger_, key << " = " << vconf_keynode_get_bool(aNode));
    aObj.set(key, ScriptObject(static_cast<bool>(vconf_keynode_get_bool(aNode))));
    break;
  case VCONF_TYPE_DOUBLE:
    LOG_DEBUG(logger_, key << " = " << vconf_keynode_get_dbl(aNode));
    aObj.set(key, ScriptObject(vconf_keynode_get_dbl(aNode)));
    break;
  case VCONF_TYPE_STRING:
  {
    std::string val(vconf_keynode_get_str(aNode));
    LOG_DEBUG(logger_, key << " = " << val);
    aObj.set(key, ScriptObject(val));
    break;
  }
  case VCONF_TYPE_DIR:
  {
    LOG_DEBUG(logger_, key << " is a dir");
    VconfTreeToScriptObject(key, aObj);
    break;
  }
  default:
    LOG_DEBUG(logger_, "Unknown type: " << key);
    break;
  }
}

void VconfBridge::OnChangeHandlerProxy(keynode_t *aNode, void *aSelf)
{
  std::string key(vconf_keynode_get_name(aNode));
  LOG_DEBUG(logger_, "Value changed for key " << key);

  /* Gotta copy info because aNode seem to be invalidated by the time
   * OnChangeHandler is executed. */
  OnChangeData *data =
    new OnChangeData(reinterpret_cast<VconfBridge *>(aSelf),
                     vconf_keynode_get_type(aNode), key);
  /* Gotta invoke the js handlers in the v8/clutter thread */
  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
                                [](gpointer aData) -> gboolean
  {
    OnChangeData *data = reinterpret_cast<OnChangeData *>(aData);
    data->self->OnChangeHandler(data->type, data->key);
    delete data;
    return FALSE;
  }, data, NULL);
}

void VconfBridge::OnChangeHandler(const int aType, const std::string &aKey)
{
  LOG_DEBUG(logger_, "Value changed for key " << aKey);

  auto existing_range = on_change_handlers_.equal_range(aKey);

  /* Saving the handlers before invoking them in case the
   * handlers register additional handlers.
   * It is not safe to iterate ranges and inserting to the multimap. */
  std::vector<ScriptFunction> handlers;

  for (auto iter = existing_range.first; iter != existing_range.second; ++iter)
  {
    handlers.push_back(iter->second);
  }

  ScriptObject js_val = ScriptObject::Null();

  bool fire_js_handler = true;
  union
  {
    int i;
    double d;
    char *s;
  } val;

  switch (aType)
  {
  case VCONF_TYPE_NONE:
    LOG_DEBUG(logger_, "Key removed " << aKey);
    break;
  case VCONF_TYPE_INT:

    if (vconf_get_int(aKey.c_str(), &val.i) == 0)
    {
      LOG_DEBUG(logger_, aKey << " = " << val.i);
      js_val = ScriptObject(val.i);
    }
    else
    {
      LOG_WARN(logger_, "Failed to get int val: " << aKey);
    }

    break;
  case VCONF_TYPE_BOOL:

    if (vconf_get_bool(aKey.c_str(), &val.i) == 0)
    {
      LOG_DEBUG(logger_, aKey << " = " << val.i);
      js_val = ScriptObject(static_cast<bool>(val.i));
    }
    else
    {
      LOG_WARN(logger_, "Failed to get bool val: " << aKey);
    }

    break;
  case VCONF_TYPE_DOUBLE:

    if (vconf_get_dbl(aKey.c_str(), &val.d) == 0)
    {
      LOG_DEBUG(logger_, aKey << " = " << val.d);
      js_val = ScriptObject(val.d);
    }
    else
    {
      LOG_WARN(logger_, "Failed to get double val: " << aKey);
    }

    break;
  case VCONF_TYPE_STRING:

    if ((val.s = vconf_get_str(aKey.c_str())))
    {
      LOG_DEBUG(logger_, aKey << " = " << val.s);
      std::string the_val(val.s);
      free(val.s);
      js_val = ScriptObject(the_val);
    }
    else
    {
      LOG_WARN(logger_, "Failed to get string val: " << aKey);
    }

    break;
  case VCONF_TYPE_DIR:
    /* What to do? */
    LOG_WARN(logger_, "New value is a dir: " << aKey);
    fire_js_handler = false;
    break;
  default:
    LOG_WARN(logger_, "Unknown type: " << aKey);
    fire_js_handler = false;
    break;
  }

  if (fire_js_handler)
  {
    /* The JS callback would get key & val as its args */
    ScriptArray args;
    args.set(0, ScriptObject(aKey));
    args.set(1, js_val);

    /* Fire every JS handler */
#ifdef BOOST_NO_CXX11_RANGE_BASED_FOR

    for (auto iter = handlers.begin(); iter != handlers.end(); ++iter)
    {
      iter->invoke(args);
    }

#else

for (auto handler: handlers)
    {
      handler.invoke(args);
    }

#endif
  }
}
#endif
