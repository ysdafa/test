/*
 * SystemInfoBridge.cpp
 *
 *  Created on: July 30th, 2014
 *      Author: Joe Yee
 */

#include "SystemInfoBridge.h"

#include <boost/config.hpp>
#include <clutter/clutter.h>
#include <stdlib.h>

#include "Exception.h"

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include "system_info.h"
#endif

#define DEFINE_KEY_MAP(context,key) (context).bindNumber<SystemInfoBridge, int, \
                                                         &SystemInfoBridge::get##key, \
                                                         &SystemInfoBridge::set##key>(#key)

using namespace v8;
using namespace Bridge;
using namespace volt::util;

std::string SystemInfoBridge::LOGGER_NAME = "volt.systeminfo.bridge";
volt::util::Logger SystemInfoBridge::logger_(LOGGER_NAME);

SystemInfoBridge::SystemInfoBridge(): ScriptInstanceBridge(this)
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  if((int)KEY_PRIVATE_LAST != (int)SYSTEM_INFO_KEY_PRIVATE_LAST
      or (int)KEY_COMMON_LAST != (int)SYSTEM_INFO_KEY_COMMON_LAST)
  {
    LOG_ERROR(logger_, "WARNING!! Key values has changed in system_info library");
    LOG_ERROR(logger_, "WARNING!! Please use the supported version of Tizen Image as specified in the Release Note (capi-system-info-0.3.02+tvprd-1.1.armv7l)");
    LOG_ERROR(logger_, "WARNING!! If that is not possible, please directly use integer values in system_info_key.h instead of predefined SystemInfo constants for the missing keys");
  }
#endif
}

SystemInfoBridge::~SystemInfoBridge()
{
}

void SystemInfoBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(logger_, "Mapping system-info script interfaces, only supported on Tizen");

  aContext.captureMethodCall<SystemInfoBridge, &HandleGetIntValue>("getIntValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetBoolValue>("getBoolValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetDoubleValue>("getDoubleValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetStringValue>("getStringValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetIntArrayValue>("getIntArrayValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetPlatformBoolValue>("getPlatformBoolValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetPlatformIntValue>("getPlatformIntValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetPlatformDoubleValue>("getPlatformDoubleValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetPlatformStringValue>("getPlatformStringValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetCustomBoolValue>("getCustomBoolValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetCustomIntValue>("getCustomIntValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetCustomDoubleValue>("getCustomDoubleValue");
  aContext.captureMethodCall<SystemInfoBridge, &HandleGetCustomStringValue>("getCustomStringValue");

  DEFINE_KEY_MAP(aContext, KEY_MODEL);
  DEFINE_KEY_MAP(aContext, KEY_TIZEN_VERSION);    //1
  DEFINE_KEY_MAP(aContext, KEY_PLATFORM_NAME);    //2
  DEFINE_KEY_MAP(aContext, KEY_TIZEN_VERSION_NAME);   //3
  DEFINE_KEY_MAP(aContext, KEY_MANUFACTURER);   //4
  DEFINE_KEY_MAP(aContext, KEY_CORE_CPU_ARCH);    //5
  DEFINE_KEY_MAP(aContext, KEY_CORE_CPU_FREQ);    //6
  DEFINE_KEY_MAP(aContext, KEY_BUILD_STRING);   //7
  DEFINE_KEY_MAP(aContext, KEY_BUILD_DATE);   //8
  DEFINE_KEY_MAP(aContext, KEY_BUILD_TIME);   //9
  DEFINE_KEY_MAP(aContext, KEY_SCREEN_HEIGHT);    //10
  DEFINE_KEY_MAP(aContext, KEY_SCREEN_WIDTH);   //11
  DEFINE_KEY_MAP(aContext, KEY_PHYSICAL_SCREEN_HEIGHT);   //12
  DEFINE_KEY_MAP(aContext, KEY_PHYSICAL_SCREEN_WIDTH);    //13
  DEFINE_KEY_MAP(aContext, KEY_TETHERING_SUPPORTED);    //14
  DEFINE_KEY_MAP(aContext, KEY_UD_PANEL_SUPPORTED);   //15
  DEFINE_KEY_MAP(aContext, KEY_ARC_SUPPORTED);    //16
  DEFINE_KEY_MAP(aContext, KEY_EXTERNAL_AUDIO_SUPPORTED);   //17
  DEFINE_KEY_MAP(aContext, KEY_WIFI_DIRECT_SUPPORTED);    //18
  DEFINE_KEY_MAP(aContext, KEY_BLUETOOTH_SUPPORTED);    //19
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_TUNER);   //20
  DEFINE_KEY_MAP(aContext, KEY_NATIVE_API_VERSION);   //21
  DEFINE_KEY_MAP(aContext, KEY_OSP_COMPATIBLE);   //22
  DEFINE_KEY_MAP(aContext, KEY_SCREEN_SIZE_1920_1080);    //23
  DEFINE_KEY_MAP(aContext, KEY_WEB_API_VERSION);    //24
  DEFINE_KEY_MAP(aContext, KEY_INTERNET_SUPPORT);   //25
  DEFINE_KEY_MAP(aContext, KEY_COMMON_LAST);
  DEFINE_KEY_MAP(aContext, KEY_PRINTER_SUPPORTED);
  DEFINE_KEY_MAP(aContext, KEY_MULTI_REGION_SUPPORTED);   //1001
  DEFINE_KEY_MAP(aContext, KEY_FULL_BROWSER_SUPPORTED);   //1002
  DEFINE_KEY_MAP(aContext, KEY_EMANUAL_SUPPORTED);    //1003
  DEFINE_KEY_MAP(aContext, KEY_SMART_HUB_SEARCH_SUPPORTED);   //1004
  DEFINE_KEY_MAP(aContext, KEY_CHANNEL_MANAGER_SUPPORTED);    //1005
  DEFINE_KEY_MAP(aContext, KEY_SMART_HUB_SCHEDULE_MANAGER_SUPPORTED);   //1006
  DEFINE_KEY_MAP(aContext, KEY_SMART_HUB_FAVORITE_SUPPORTED);   //1007
  DEFINE_KEY_MAP(aContext, KEY_SMART_HUB_COLOR_KEYS_SUPPORTED);   //1008
  DEFINE_KEY_MAP(aContext, KEY_SMART_HUB_MULTI_APPLICATION_SUPPORTED);    //1009
  DEFINE_KEY_MAP(aContext, KEY_FREE_VIEW_HD_SUPPORTED);   //1010
  DEFINE_KEY_MAP(aContext, KEY_MHEG_DVR_SUPPORTED);   //1011
  DEFINE_KEY_MAP(aContext, KEY_UPC_SUPPORTED);    //1012
  DEFINE_KEY_MAP(aContext, KEY_NUMERIC_SUPPORTED);    //1013
  DEFINE_KEY_MAP(aContext, KEY_GINGA_DUAL_DECODING_SUPPORTED);    //1014
  DEFINE_KEY_MAP(aContext, KEY_CAMERA_MODULE_SUPPORTED);    //1015
  DEFINE_KEY_MAP(aContext, KEY_WELCOME_VIDEO_SUPPORTED);    //1016
  DEFINE_KEY_MAP(aContext, KEY_STAMRT_HUB_HBBTV_SUPPORTED);   //1017
  DEFINE_KEY_MAP(aContext, KEY_ANYNET_PLUS_SUPPORTED);    //1018
  DEFINE_KEY_MAP(aContext, KEY_ROOM_EQ_SUPPORTED);    //1019
  DEFINE_KEY_MAP(aContext, KEY_XVYCC_SUPPORTED);    //1020
  DEFINE_KEY_MAP(aContext, KEY_3D_EFFECT_SUPPORTED);    //1021
  DEFINE_KEY_MAP(aContext, KEY_HDMI_SWITCH_PATTERN);    //1022
  DEFINE_KEY_MAP(aContext, KEY_3D_FRAME_DETECTION_SUPPORTED);   //1023
  DEFINE_KEY_MAP(aContext, KEY_3D_FOCAL_VIEW_POINT_SUPPORTED);    //1024
  DEFINE_KEY_MAP(aContext, KEY_ALL_SHARE_SUPPORTED);    //1025
  DEFINE_KEY_MAP(aContext, KEY_3D_MODE_SELECTABLE_SUPPORTED);   //1026
  DEFINE_KEY_MAP(aContext, KEY_DTCP_KEY_VERSION_SUPPORTED);   //1027
  DEFINE_KEY_MAP(aContext, KEY_BLUETOOTH_FREEPARING_SUPPORTED);   //1028
  DEFINE_KEY_MAP(aContext, KEY_MOTION_LIGHTING_SUPPORTED);    //1029
  DEFINE_KEY_MAP(aContext, KEY_BLACK_ENHANCER_SUPPORTED);   //1030
  DEFINE_KEY_MAP(aContext, KEY_BLACK_OPTIMIZER_SUPPORTED);    //1031
  DEFINE_KEY_MAP(aContext, KEY_SMART_LED_SUPPORTED);    //1032
  DEFINE_KEY_MAP(aContext, KEY_SMARTHUB_BLOCK_SUPPORTED);   //1033
  DEFINE_KEY_MAP(aContext, KEY_UART_IR_BLASTER_SUPPORTED);    //1034
  DEFINE_KEY_MAP(aContext, KEY_KR_CABLE_QAM_SUPPORTED);   //1035
  DEFINE_KEY_MAP(aContext, KEY_CLONE_VIEW_ON_FRAME_PACKING_SUPPORTED);    //1036
  DEFINE_KEY_MAP(aContext, KEY_VOICE_RECOGNITION_SUPPORTED);    //1037
  DEFINE_KEY_MAP(aContext, KEY_MOTION_RECOGNITION_SUPPORTED);   //1038
  DEFINE_KEY_MAP(aContext, KEY_SMART_LED_DEMO_POSITION);    //1039
  DEFINE_KEY_MAP(aContext, KEY_MICRO_DIMMING_ULTIMATE_DEMO_POSITION);   //1040
  DEFINE_KEY_MAP(aContext, KEY_DUAL_VIEW_USER_CHANGE_KEY);    //1041
  DEFINE_KEY_MAP(aContext, KEY_CIP_VERSION);    //1042
  DEFINE_KEY_MAP(aContext, KEY_MP_TYPE);    //1043
  DEFINE_KEY_MAP(aContext, KEY_VIRTUAL_REMOCON_COLOR);    //1044
  DEFINE_KEY_MAP(aContext, KEY_PANEL_SIZE);   //1045
  DEFINE_KEY_MAP(aContext, KEY_SOCCER_MODE);    //1046
  DEFINE_KEY_MAP(aContext, KEY_DETAILED_PANEL_TYPE);    //1047
  DEFINE_KEY_MAP(aContext, KEY_NETWORK_TYPE);   //1048
  DEFINE_KEY_MAP(aContext, KEY_PANEL_TYPE);   //1049
  DEFINE_KEY_MAP(aContext, KEY_PANEL_TYPE_STRING);    //1050
  DEFINE_KEY_MAP(aContext, KEY_DEFAULT_COLOR_SYSTEM);   //1051
  DEFINE_KEY_MAP(aContext, KEY_PROJECTOR_TYPE);   //1052
  DEFINE_KEY_MAP(aContext, KEY_PRODUCT_TYPE);   //1053
  DEFINE_KEY_MAP(aContext, KEY_MICRO_DIMMING_TYPE);   //1054
  DEFINE_KEY_MAP(aContext, KEY_USB_MEDIA_MODE);   //1055
  DEFINE_KEY_MAP(aContext, KEY_3D_EFFECT_MODE);   //1056
  DEFINE_KEY_MAP(aContext, KEY_EPG_RAM_SIZE);   //1057
  DEFINE_KEY_MAP(aContext, KEY_CINEMA_BLACK_TYPE);    //1058
  DEFINE_KEY_MAP(aContext, KEY_ECO_SENSOR_DEFAULT_VALUE);   //1059
  DEFINE_KEY_MAP(aContext, KEY_MICRO_DIMMING_BLOCK_SIZE);   //1060
  DEFINE_KEY_MAP(aContext, KEY_SOCCER_MODE_SUPPORTED);    //1061
  DEFINE_KEY_MAP(aContext, KEY_PIP_SOURCE_SUPPORTED);   //1062
  DEFINE_KEY_MAP(aContext, KEY_HDMI_OUTPUT_SUPPORTED);    //1063
  DEFINE_KEY_MAP(aContext, KEY_WIRELESS_NETWORK_SUPPORTED);   //1064
  DEFINE_KEY_MAP(aContext, KEY_PANEL_CATEGORY_TYPE);    //1065
  DEFINE_KEY_MAP(aContext, KEY_LOCAL_SET);    //1066
  DEFINE_KEY_MAP(aContext, KEY_CHIPSET);    //1067
  DEFINE_KEY_MAP(aContext, KEY_IME_ZERO_LEFT);    //1068
  DEFINE_KEY_MAP(aContext, KEY_IME_ZERO_RIGHT);   //1069
  DEFINE_KEY_MAP(aContext, KEY_IME_ZERO_LEFT_CODE);   //1070
  DEFINE_KEY_MAP(aContext, KEY_IME_ZERO_RIGHT_CODE);    //1071
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_TRANS_DIS);    //1072
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_PAIR_DIS_SHOP);    //1073
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_PAIR_DIS_HOME);    //1074
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_DUTY_D);   //1075
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_DUTY_S);   //1076
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_DUTY_R);   //1077
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_DUTY_M);   //1078
  DEFINE_KEY_MAP(aContext, KEY_BT_GLASS_INFO_DUTY);   //1079
  DEFINE_KEY_MAP(aContext, KEY_AUTO_STAND_SUPPORTED);   //1080
  DEFINE_KEY_MAP(aContext, KEY_WALL_MOUNT_OPERATION_SUPPORTED);   //1081
  DEFINE_KEY_MAP(aContext, KEY_HOTEL_INTERACTIVE_SUPPORTED);    //1082
  DEFINE_KEY_MAP(aContext, KEY_SMART_HUB_INTERACTIVE_DEMO_SUPPORTED);   //1083
  DEFINE_KEY_MAP(aContext, KEY_10P_WHITE_BALANCE_SUPPORTED);    //1084
  DEFINE_KEY_MAP(aContext, KEY_WIFI_REGION);    //1085
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_DTV);   //1086
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_AV);    //1087
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_ATV);   //1088
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_COMP);    //1089
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_PC);    //1090
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_SCART);   //1091
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_DVI);   //1092
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_FM_RADIO);    //1093
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_MEDIA);   //1094
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_IPTV);    //1095
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_IPTV_CIP);    //1096
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_RVU);   //1097
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_HDMI);    //1098
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_RUI);   //1099
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_DIIVA);   //1100
  DEFINE_KEY_MAP(aContext, KEY_PVR_SUPPORTED);    //1101
  DEFINE_KEY_MAP(aContext, KEY_INFO_LINK_SERVER_TYPE);    //1102
  DEFINE_KEY_MAP(aContext, KEY_REGION_KIND);    //1103
  DEFINE_KEY_MAP(aContext, KEY_SW_VERSION);   //1104
  DEFINE_KEY_MAP(aContext, KEY_OSD_RESOLUTION_WIDTH);   //1105
  DEFINE_KEY_MAP(aContext, KEY_OSD_RESOLUTION_HEIGHT);    //1106
  DEFINE_KEY_MAP(aContext, KEY_TUNER_TYPE);   //1107
  DEFINE_KEY_MAP(aContext, KEY_VERSION_FULL);   //1108
  DEFINE_KEY_MAP(aContext, KEY_VERSION_MICOM);    //1109
  DEFINE_KEY_MAP(aContext, KEY_VERSION_HOTEL_SI_VENDOR);    //1110
  DEFINE_KEY_MAP(aContext, KEY_VERSION_HOTEL_VCP);    //1111
  DEFINE_KEY_MAP(aContext, KEY_VERSION_CAMERA);   //1112
  DEFINE_KEY_MAP(aContext, KEY_VERSION_MIC);    //1113
  DEFINE_KEY_MAP(aContext, KEY_VERSION_SBB_CS);   //1114
  DEFINE_KEY_MAP(aContext, KEY_VERSION_BLUETOOTH);    //1115
  DEFINE_KEY_MAP(aContext, KEY_VERSION_EMANUAL);    //1116
  DEFINE_KEY_MAP(aContext, KEY_INPUT_KEYBOARD_SUPPORTED);   //1117
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_SUPPORTED);   //1118
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_TEXTURE_FORMAT_3DC_SUPPORTED);    //1119
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_VERSION_1_1_SUPPORTED);   //1120
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_VERSION_2_0_SUPPORTED);   //1121
  DEFINE_KEY_MAP(aContext, KEY_USB_HOST_SUPPORTED);   //1122
  DEFINE_KEY_MAP(aContext, KEY_PLATFORM_CORE_FPU_ARCH_VFPV3_SUPPORTED);   //1123
  DEFINE_KEY_MAP(aContext, KEY_PLATFORM_CORE_FPU_ARCH_SSE2_SUPPORTED);    //1124
  DEFINE_KEY_MAP(aContext, KEY_PLATFORM_CORE_FPU_ARCH_SSE3_SUPPORTED);    //1125
  DEFINE_KEY_MAP(aContext, KEY_PLATFORM_CORE_FPU_ARCH_SSSE3_SUPPORTED);   //1126
  DEFINE_KEY_MAP(aContext, KEY_SPEECH_SYNTHESIS_SUPPORTED);   //1127
  DEFINE_KEY_MAP(aContext, KEY_BAROMETER_SENSOR_SUPPORTED);   //1128
  DEFINE_KEY_MAP(aContext, KEY_BAROMETER_SENSOR_WAKEUP_SUPPORTED);    //1129
  DEFINE_KEY_MAP(aContext, KEY_GRAPHICS_ACCELATION_SUPPORTED);    //1130
  DEFINE_KEY_MAP(aContext, KEY_IMAGE_RECOGNITION_SUPPORTED);    //1131
  DEFINE_KEY_MAP(aContext, KEY_QRCODE_GENERATION_SUPPORTED);    //1132
  DEFINE_KEY_MAP(aContext, KEY_QRCODE_RECOGNITION_SUPPORTED);   //1133
  DEFINE_KEY_MAP(aContext, KEY_FACE_RECOGNITION_SUPPORTED);   //1134
  DEFINE_KEY_MAP(aContext, KEY_OPEN_SOURCE_LICENSE_FILES);    //1135
  DEFINE_KEY_MAP(aContext, KEY_AUTOSIZE_SUPPORTED);   //1136
  DEFINE_KEY_MAP(aContext, KEY_SBB_SUPPORTED);    //1137
  DEFINE_KEY_MAP(aContext, KEY_CABLE_MODULATION_SUPPORTED);   //1138
  DEFINE_KEY_MAP(aContext, KEY_VCHIP_SUPPORTED);    //1139
  DEFINE_KEY_MAP(aContext, KEY_LOCAL_SET_SUPPORTED);    //1140
  DEFINE_KEY_MAP(aContext, KEY_ARABIC_LANG_SUPPORTED);    //1141
  DEFINE_KEY_MAP(aContext, KEY_DEMODULATOR_SUPPORTED);    //1142
  DEFINE_KEY_MAP(aContext, KEY_PNP_LANG_SUPPORTED);   //1143
  DEFINE_KEY_MAP(aContext, KEY_POWER_ON_CHANNEL_SUPPORTED);   //1144
  DEFINE_KEY_MAP(aContext, KEY_VIDEO_ENHANCER_SUPPORTED);   //1145
  DEFINE_KEY_MAP(aContext, KEY_PANEL_SUPPORTED);    //1146
  DEFINE_KEY_MAP(aContext, KEY_AUDIO_AMP1_SUPPORTED);   //1147
  DEFINE_KEY_MAP(aContext, KEY_AUDIO_AMP3_SUPPORTED);   //1148
  DEFINE_KEY_MAP(aContext, KEY_EXTERNAL_INPUT_PROCESSOR_SUPPORTED);   //1149
  DEFINE_KEY_MAP(aContext, KEY_ANALOG_VIDEO_PROCESSOR_SUPPORTED);   //1150
  DEFINE_KEY_MAP(aContext, KEY_MTS_CONTROL);    //1151
  DEFINE_KEY_MAP(aContext, KEY_AUTOSTORE);    //1152
  DEFINE_KEY_MAP(aContext, KEY_OPEN_SOURCE_QR_FILES);   //1153
  DEFINE_KEY_MAP(aContext, KEY_ANALOG_CLEAN_VIEW_SUPPORTED);    //1154
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_TEXTURE_FORMAT_ATC_SUPPORTED);    //1155
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_TEXTURE_FORMAT_ETC_SUPPORTED);    //1156
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_TEXTURE_FORMAT_PVRTC_SUPPORTED);    //1157
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_TEXTURE_FORMAT_ASTC_SUPPORTED);   //1158
  DEFINE_KEY_MAP(aContext, KEY_MPEG_NOISE_FILTER_SUPPORTED);    //1159
  DEFINE_KEY_MAP(aContext, KEY_FILM_MODE_SUPPORTED);    //1160
  DEFINE_KEY_MAP(aContext, KEY_MOTION_PLUS_SUPPORTED);    //1161
  DEFINE_KEY_MAP(aContext, KEY_PICTURE_RESPONSE_TIME_SUPPORTED);    //1162
  DEFINE_KEY_MAP(aContext, KEY_LED_CLEAR_MOTION_SUPPORTED);   //1163
  DEFINE_KEY_MAP(aContext, KEY_DYNAMIC_BACKLIGHT_SUPPORTED);    //1164
  DEFINE_KEY_MAP(aContext, KEY_SERIAL_NUMBER);    //1165
  DEFINE_KEY_MAP(aContext, KEY_APP_PRE_INSTALL_SUPPORTED);    //1166
  DEFINE_KEY_MAP(aContext, KEY_VERSION_APP_PRE_INSTALL);    //1167
  DEFINE_KEY_MAP(aContext, KEY_VERSION_CPLD);   //1168
  DEFINE_KEY_MAP(aContext, KEY_RGB_ONLY_MODE_SUPPORTED);    //1169
  DEFINE_KEY_MAP(aContext, KEY_COLOR_SPACE_SUPPORTED);    //1170
  DEFINE_KEY_MAP(aContext, KEY_COLOR_SPACE_MODE_SUPPORTED);   //1171
  DEFINE_KEY_MAP(aContext, KEY_3D_SUPPORT);   //1172
  DEFINE_KEY_MAP(aContext, KEY_PLATFORM_CORE_FPU_ARCH_VFPV2_SUPPORTED);   //1173
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_TEXTURE_FORMAT_PTC_SUPPORTED);    //1174
  DEFINE_KEY_MAP(aContext, KEY_OPENGLES_TEXTURE_FORMAT_UTC_SUPPORTED);    //1175
  DEFINE_KEY_MAP(aContext, KEY_CONVERSATION_SUPPORTED);   //1176
  DEFINE_KEY_MAP(aContext, KEY_SW_VERSION_MODEL);   //1177
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_3D_JPEG);   //1178
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_3D_UD_JPEG);    //1179
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_CHESS_JPEG);    //1180
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_GRAY_RGB_RAMP_BMP);   //1181
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_GRAY_RGB_RAMP_BMP_720);   //1182
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_HV_RAMP_JPEG);    //1183
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_RGP_RAMP_JPEG);   //1184
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_RGP_COMP_JPEG);   //1185
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_VISION1_JPEG);    //1186
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_VISION2_JPEG);    //1187
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_10_SEC);    //1188
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_200_1000);    //1189
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_1000_200);    //1190
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L1K_R10K);    //1191
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L1K_R100);    //1192
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L10K_R1K);    //1193
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L10K_R100);   //1194
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L100_R1K);    //1195
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L100_R10K);   //1196
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L100);    //1197
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L10K);    //1198
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L1K);   //1199
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_L600);    //1200
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_R100);    //1201
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_R10K);    //1202
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_R1K);   //1203
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_PATTERN_DFX_R600);    //1204
  DEFINE_KEY_MAP(aContext, KEY_CINEMA_BLACK_SUPPORTED);   //1205
  DEFINE_KEY_MAP(aContext, KEY_TARGET_LOCATION);    //1206
  DEFINE_KEY_MAP(aContext, KEY_PANEL_RESOLUTION_WIDTH);   //1207
  DEFINE_KEY_MAP(aContext, KEY_PANEL_RESOLUTION_HEIGHT);    //1208
  DEFINE_KEY_MAP(aContext, KEY_PANEL_VFREQ);    //1209
  DEFINE_KEY_MAP(aContext, KEY_PANEL_ASPECT_RATIO);   //1210
  DEFINE_KEY_MAP(aContext, KEY_HDMI_FLT_CNT_SIG);   //1211
  DEFINE_KEY_MAP(aContext, KEY_HDMI_FLT_CNT_LOS);   //1212
  DEFINE_KEY_MAP(aContext, KEY_VERSION_SMART_RC);   //1213
  DEFINE_KEY_MAP(aContext, KEY_IR_BLASTER_FW_DATA_PATH);    //1214
  DEFINE_KEY_MAP(aContext, KEY_WIRELESS_MIC_SUPPORTED);   //1215
  DEFINE_KEY_MAP(aContext, KEY_E_POP_SUPPORTED);    //1216
  DEFINE_KEY_MAP(aContext, KEY_3D_MULTI_ES_SUPPORTED);    //1217
  DEFINE_KEY_MAP(aContext, KEY_DEFAULT_SOUND_SYSTEM);   //1218
  DEFINE_KEY_MAP(aContext, KEY_RATING_SUPPORTED);   //1219
  DEFINE_KEY_MAP(aContext, KEY_VERSION_WIFI);   //1220
  DEFINE_KEY_MAP(aContext, KEY_VIRTUAL_SURROUND_SUPPORTED);   //1221
  DEFINE_KEY_MAP(aContext, KEY_TEMP_PRIVATE_RANGE_USE);   //1222
  DEFINE_KEY_MAP(aContext, KEY_DATA_SERVICE);   //1223
  DEFINE_KEY_MAP(aContext, KEY_SATELLITE_MASK);   //1224
  DEFINE_KEY_MAP(aContext, KEY_THEATER_SOUND_SUPPORTED);    //1225
  DEFINE_KEY_MAP(aContext, KEY_SUPPORT_T2_AUTO_DETECTION);    //1226
  DEFINE_KEY_MAP(aContext, KEY_VPS_TTX_SUPPORT_MODE);   //1227
  DEFINE_KEY_MAP(aContext, KEY_VPS_TIME_OUT);   //1228
  DEFINE_KEY_MAP(aContext, KEY_TTX_TIME_OUT);   //1229
  DEFINE_KEY_MAP(aContext, KEY_INSTANT_ON_SUPPORTED);   //1230
  DEFINE_KEY_MAP(aContext, KEY_LANGUAGE_LIST);    //1231
  DEFINE_KEY_MAP(aContext, KEY_PANORAMA_FONT_ENGINE_SUPPORTED);   //1232
  DEFINE_KEY_MAP(aContext, KEY_3D_AUTO_VIEW);   //1233
  DEFINE_KEY_MAP(aContext, KEY_3D_FRAME_DETECTION);   //1234
  DEFINE_KEY_MAP(aContext, KEY_BROSWER_PRELOADING);   //1235
  DEFINE_KEY_MAP(aContext, KEY_COLOR_KEY_ON);   //1236
  DEFINE_KEY_MAP(aContext, KEY_AUTO_POWER_OFF_DEFAULT_ON_SUPPORTED);    //1237
  DEFINE_KEY_MAP(aContext, KEY_CHINA_READY_SUPPORTED);    //1238
  DEFINE_KEY_MAP(aContext, KEY_REMOTE_SCHEDULER_SUPPORTED);   //1239
  DEFINE_KEY_MAP(aContext, KEY_USB_COPY_FORMAT_SUPPORTED);    //1240
  DEFINE_KEY_MAP(aContext, KEY_WEAK_SIGNAL_HISTORY_SUPPORTED);    //1241
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_PVR_RECORD);    //1242
  DEFINE_KEY_MAP(aContext, KEY_CI_SUPPORT);   //1243
  DEFINE_KEY_MAP(aContext, KEY_CERT_OPTION);    //1244
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_CI);    //1245
  DEFINE_KEY_MAP(aContext, KEY_PC_MODE_IDENT);    //1246
  DEFINE_KEY_MAP(aContext, KEY_LONG_DISTANCE_VOICE_RECOGNISION_SUPPORTED);    //1247
  DEFINE_KEY_MAP(aContext, KEY_JP_MIGRATION_BACKUP_SUPPORTED);    //1248
  DEFINE_KEY_MAP(aContext, KEY_JP_MIGRATION_RESTORE_SUPPORTED);   //1249
  DEFINE_KEY_MAP(aContext, KEY_JP_MIGRATION_PVR_IMPORT_SUPPORTED);    //1250
  DEFINE_KEY_MAP(aContext, KEY_GET_JP_MIGRATION_BACKUP_SOURCE_PATH);    //1251
  DEFINE_KEY_MAP(aContext, KEY_GET_JP_MIGRATION_RESTORE_SOURCE_PATH);   //1252
  DEFINE_KEY_MAP(aContext, KEY_GET_CONFIG_JP_MIGRATION_BACKUP);   //1253
  DEFINE_KEY_MAP(aContext, KEY_GET_CONFIG_JP_MIGRATION_RESTORE);    //1254
  DEFINE_KEY_MAP(aContext, KEY_JACKPACK_CHIP_TYPE);   //1255
  DEFINE_KEY_MAP(aContext, KEY_JACKPACK_YEAR);    //1256
  DEFINE_KEY_MAP(aContext, KEY_TV_CHIP_TYPE);   //1257
  DEFINE_KEY_MAP(aContext, KEY_TV_YEAR);    //1258
  DEFINE_KEY_MAP(aContext, KEY_INTERNAL_SPEAKER_SUPPORTED);   //1259
  DEFINE_KEY_MAP(aContext, KEY_STORE_DEMO_MOVIE_BUILT_IN_SUPPORTED);    //1260
  DEFINE_KEY_MAP(aContext, KEY_HDMI_BLACK_LEVEL_AUTO_SUPPORTED);    //1261
  DEFINE_KEY_MAP(aContext, KEY_AUTOMOTIONPLUS_CLEAR_BLUR_SUPPORTED);    //1262
  DEFINE_KEY_MAP(aContext, KEY_SPDIF_OUTPUT_SUPPORTED);   //1263
  DEFINE_KEY_MAP(aContext, KEY_MULTIROOM_SPEAKER_SUPPORTED);    //1264
  DEFINE_KEY_MAP(aContext, KEY_SOUND_BALANCE_SUPPORTED);    //1265
  DEFINE_KEY_MAP(aContext, KEY_PICTURE_MODE_MEMORY_SUPPORTED);    //1266
  DEFINE_KEY_MAP(aContext, KEY_ALTERNATIVE_VIEW_SUPPORTED);   //1267
  DEFINE_KEY_MAP(aContext, KEY_CUSTOM_AUDIO_SUPPORTED);   //1268
  DEFINE_KEY_MAP(aContext, KEY_SPEAKER_TV_INSTALLATION_MODE_SUPPORTED);   //1269
  DEFINE_KEY_MAP(aContext, KEY_SHOP_LOGO_SUPPORTED);    //1270
  DEFINE_KEY_MAP(aContext, KEY_MAGIC_ANGLE_SUPPORTED);    //1271
  DEFINE_KEY_MAP(aContext, KEY_3D_DEPTH_SUPPORTED);   //1272
  DEFINE_KEY_MAP(aContext, KEY_3D_OPTIMIZE_SUPPORTED);    //1273
  DEFINE_KEY_MAP(aContext, KEY_3D_BRIGHTNESS_SUPPORTED);    //1274
  DEFINE_KEY_MAP(aContext, KEY_EDID_2_0_SUPPORTED);   //1275
  DEFINE_KEY_MAP(aContext, KEY_MOUSE_CONTROL_SUPPORTED);    //1276
  DEFINE_KEY_MAP(aContext, KEY_ECO_SOLUTION_ZERO_WATT_SUPPORTED);   //1277
  DEFINE_KEY_MAP(aContext, KEY_PC_MAGIC_RETURN_SUPPORTED);    //1278
  DEFINE_KEY_MAP(aContext, KEY_AUDIO_UI_SUPPORTED);   //1279
  DEFINE_KEY_MAP(aContext, KEY_USB_HUB_SWITCH_SUPPORTED);   //1280
  DEFINE_KEY_MAP(aContext, KEY_PANEL_SLIDE_KEY_SUPPORTED);    //1281
  DEFINE_KEY_MAP(aContext, KEY_LIGHT_LEVEL_SUPPORTED);    //1282
  DEFINE_KEY_MAP(aContext, KEY_CANAL_READY_TNT_BIN_PATH);   //1283
  DEFINE_KEY_MAP(aContext, KEY_CHECK_SKIP_LOCALSET);    //1284
  DEFINE_KEY_MAP(aContext, KEY_CHECK_WIFI_VENDOR);    //1285
  DEFINE_KEY_MAP(aContext, KEY_RM_AUTO_DIAGNOSIS_SUPPORTED);    //1286
  DEFINE_KEY_MAP(aContext, KEY_EOS_CLICK_ON_OFF);   //1287
  DEFINE_KEY_MAP(aContext, KEY_LOCAL_SET_ENUM);   //1288
  DEFINE_KEY_MAP(aContext, KEY_REGION_KIND_ENUM);   //1289
  DEFINE_KEY_MAP(aContext, KEY_MULTITASKING_SUPPORT);   //1290
  DEFINE_KEY_MAP(aContext, KEY_PRELOADING_SUPPORT);   //1291
  DEFINE_KEY_MAP(aContext, KEY_DVI_HDMI_PORT);    //1292
  DEFINE_KEY_MAP(aContext, KEY_CHMAP_PATH);   //1293
  DEFINE_KEY_MAP(aContext, KEY_PARTITION_FILE_NAME);    //1294
  DEFINE_KEY_MAP(aContext, KEY_PRODUCT_CODE_SW);    //1295
  DEFINE_KEY_MAP(aContext, KEY_PRODUCT_CODE_BOM);   //1296
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_ISP);   //1297
  DEFINE_KEY_MAP(aContext, KEY_NUM_OF_HYBRID_TV );    //1298
  DEFINE_KEY_MAP(aContext, KEY_ACM_MULTI_CH_SUPPORT);   //1299
  DEFINE_KEY_MAP(aContext, KEY_MHL_SUPPORT);    //1300
  DEFINE_KEY_MAP(aContext, KEY_SCSA_SUPPORTED);   //1301
  DEFINE_KEY_MAP(aContext, KEY_MHEG_MMI_CACHE_SIZE);    //1302
  DEFINE_KEY_MAP(aContext, KEY_MHEG_MMI_CACHE_PATH);    //1303
  DEFINE_KEY_MAP(aContext, KEY_PNP_COUNTRY_LIST);   //1304
  DEFINE_KEY_MAP(aContext, KEY_DIGITAL_COUNTRY_LIST);   //1305
  DEFINE_KEY_MAP(aContext, KEY_ANALOG_COUNTRY_LIST);    //1306
  DEFINE_KEY_MAP(aContext, KEY_DEFAULT_DIGITAL_COUNTRY);    //1307
  DEFINE_KEY_MAP(aContext, KEY_DEFAULT_ANALOG_COUNTRY);   //1308
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_HOT_KEY_LIST_TV);    //1309
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_HOT_KEY_LIST_STB);   //1310
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_HOT_KEY_LIST_BD);    //1311
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_HOT_KEY_LIST_HTS_AUDIO);   //1312
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_HOT_KEY_LIST_HTS_HDMI);    //1313
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_HOT_KEY_LIST_STB_HTS);   //1314
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_HOT_KEY_LIST_BD_HTS);    //1315
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_SUPPORT);    //1316
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_3D_GLASS);   //1317
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_3D_REMOCON);   //1318
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_HEADPHONE);    //1319
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_HEALTH_DEVICE);    //1320
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_AUDIO_SINK);   //1321
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_KEYBOARD);   //1322
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_MOUSE);    //1323
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_HEADLESS);   //1324
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_SMART_CONTROL);    //1325
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_IR_BLASTER);   //1326
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_AUDIO_DOCKING);    //1327
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_SOUND_SHARE_SINK);   //1328
  DEFINE_KEY_MAP(aContext, KEY_BT_PROFILE_BT_NFC_REMOCON);    //1329
  DEFINE_KEY_MAP(aContext, KEY_DVI_I_SUPPORTED);    //1330
  DEFINE_KEY_MAP(aContext, KEY_YAHOO_WIDGET_SUPPORTED);   //1331
  DEFINE_KEY_MAP(aContext, KEY_EXPERT_PATTERN_SUPPORTED);   //1332
  DEFINE_KEY_MAP(aContext, KEY_MELFAS_FUNCTION_SUPPORTED);    //1333
  DEFINE_KEY_MAP(aContext, KEY_VERSION_SWENGINE);   //1334
  DEFINE_KEY_MAP(aContext, KEY_VERSION_IR_BLASTER_MICOM);   //1335
  DEFINE_KEY_MAP(aContext, KEY_MICROPHONE_SUPPORTED);   //1336
  DEFINE_KEY_MAP(aContext, KEY_HOTEL_TV_SUPPORTED);   //1337
  DEFINE_KEY_MAP(aContext, KEY_PIXELSHIFT_SUPPORTED);   //1338
  DEFINE_KEY_MAP(aContext, KEY_MODEL_ID_SUPPORTED);   //1339
  DEFINE_KEY_MAP(aContext, KEY_PRIVATE_LAST);
}

void* SystemInfoBridge::constructFromScript(const ScriptArray &aArgs)
{
  return this;
}

ScriptObject SystemInfoBridge::HandleGetIntValue(SystemInfoBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  int key = (int)aArgs[0].asNumber();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  int value = 0;
  int result = system_info_get_value_int((system_info_key_e) key, &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetBoolValue(SystemInfoBridge *aSelf,
    const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  int key = (int)aArgs[0].asNumber();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  bool value = false;
  int result = system_info_get_value_bool((system_info_key_e) key, &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetDoubleValue(SystemInfoBridge *aSelf,
    const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  int key = (int)aArgs[0].asNumber();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  double value = 0;
  int result = system_info_get_value_double((system_info_key_e) key, &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetStringValue(SystemInfoBridge *aSelf,
    const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  int key = (int)aArgs[0].asNumber();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  char *value = nullptr;
  int result = system_info_get_value_string((system_info_key_e) key, &value);
  ScriptObject output;

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    output = ScriptObject(std::string(value));
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    output = ScriptObject();
  }

  if(value != nullptr)
  {
    free(value);
    value = nullptr;
  }

  return output;
#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetIntArrayValue(SystemInfoBridge *aSelf,
    const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  int key = (int)aArgs[0].asNumber();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  system_info_int_array intArray;
  intArray.value_num = 0;
  intArray.values = nullptr;

  int result = system_info_get_value_int_array((system_info_key_e) key, &intArray);
  ScriptObject output;

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    ScriptArray array;

    for(int i = 0; i < intArray.value_num; i++)
    {
      array.set(i, ScriptObject(intArray.values[i]));
    }

    output = array;
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    output = ScriptObject();
  }

  if(intArray.values != nullptr)
  {
    intArray.value_num = 0;
    free(intArray.values);
    intArray.values = nullptr;
  }

  return output;
#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetPlatformBoolValue(
  SystemInfoBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  bool value = false;
  int result = system_info_get_platform_bool(key.c_str(), &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetPlatformIntValue(
  SystemInfoBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  int value = 0;
  int result = system_info_get_platform_int(key.c_str(), &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetPlatformDoubleValue(
  SystemInfoBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  double value = 0;
  int result = system_info_get_platform_double(key.c_str(), &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetPlatformStringValue(
  SystemInfoBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  char *value = nullptr;
  int result = system_info_get_platform_string(key.c_str(), &value);
  ScriptObject output;

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    output = ScriptObject(std::string(value));
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    output = ScriptObject();
  }

  if(value != nullptr)
  {
    free(value);
    value = nullptr;
  }

  return output;
#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetCustomBoolValue(SystemInfoBridge *aSelf,
    const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  bool value = false;
  int result = system_info_get_custom_bool(key.c_str(), &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetCustomIntValue(SystemInfoBridge *aSelf,
    const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  bool value = 0; // <--- shouldnt this be an INT? but the API wont take it if its not bool..
  int result = system_info_get_custom_int(key.c_str(), &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetCustomDoubleValue(
  SystemInfoBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  double value = 0;
  int result = system_info_get_custom_double(key.c_str(), &value);

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    return ScriptObject(value);
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    return ScriptObject();
  }

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}

ScriptObject SystemInfoBridge::HandleGetCustomStringValue(
  SystemInfoBridge *aSelf, const ScriptArray &aArgs)
{
  if (aArgs.Length() < 1)
  {
    LOG_WARN(logger_, "No key given");
    return ScriptObject();
  }

  std::string key = aArgs[0].asString();

  LOG_DEBUG(logger_, "Get system info value: " << key);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  char *value = nullptr;
  int result = system_info_get_custom_string(key.c_str(), &value);
  ScriptObject output;

  if(result == SYSTEM_INFO_ERROR_NONE)
  {
    output = ScriptObject(std::string(value));
  }
  else
  {
    LOG_ERROR(logger_, "failed to get value, error " << result);
    output = ScriptObject();
  }

  if(value != nullptr)
  {
    free(value);
    value = nullptr;
  }

  return output;

#else
  LOG_WARN(logger_, "system info is not supported on this platform.");
  return ScriptObject();
#endif
}
