/*
 * ImageWidgetBridge.cpp
 *
 *  Created on: May 23, 2013
 *      Author: reza
 */

#include "ImageWidgetBridge.h"
#include "ImageWidget.h"

#include <boost/program_options.hpp>

/* Volt configuration options. */
#include "AppConfig.h"

using namespace volt::graphics;

namespace Bridge
{

std::map<Widget*, ScriptFunction> Bridge::ImageWidgetBridge::readyCallbacks;

void Bridge::ImageWidgetBridge::mapScriptInterface(ScriptContext& context)
{
  WidgetBridge::mapScriptInterface(context);

  context.capturePropertyAccess<ImageWidget, getSource, setSource>("src");
  context.capturePropertyAccess<ImageWidget, getOnReady, setOnReady>("onReady");
  context.capturePropertyAccess<ImageWidget, getFillMode, setFillMode>("fillMode");
  context.bindBoolean<ImageWidget, &ImageWidget::getAsyncLoading, &ImageWidget::setAsyncLoading>("async");

  context.captureMethodCall<ImageWidget, &getColorPicking>("getColorPicking");
}


Widget* Bridge::ImageWidgetBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
  std::string src = "", fill = "";
  const uint8_t *buffer = nullptr;
  unsigned int bufferLength = 0;
  Image *src_image = nullptr;
  ScriptFunction onReady;
  bool isOnReadySet = false;
  bool async = AppConfig::Instance().IsSet("sync-img-load") ? false : true;

  if(args.Length() > 0)
  {
    ScriptObject options = args[0];

    if(options.has("src"))
    {
      if(options["src"].isString())
      {
        src = options["src"].asString();
      }
      else if(options["src"].isArrayBuffer())
      {
        buffer = options["src"].getExternalData();
        bufferLength = options["src"].getExternalDataLength();
      }
      else
      {
        src_image = unwrapNativeObject<Image>(options["src"]);
      }

      if(options.has("fillMode") )
      {
        fill = options["fillMode"].asString();
      }

      if(options.has("onReady") )
      {
        onReady = options["onReady"].asFunction();
        isOnReadySet = true;
      }

      if (options.has("async") )
      {
        async = options["async"].asBool();
      }
    }
    else
    {
      if(args.has(0))
      {
        if(args[0].isString())
        {
          src = args[0].asString();
        }
        else if(args[0].isArrayBuffer())
        {
          buffer = args[0].getExternalData();
          bufferLength = args[0].getExternalDataLength();
        }
        else if(args.has(2))
        {
          if(args[2].isString())
          {
            src = args[2].asString();
          }
          else if(args[2].isArrayBuffer())
          {
            buffer = args[2].getExternalData();
            bufferLength = args[2].getExternalDataLength();
          }
        }
      }

      if(args.has(1) && args[1].isFunction())
      {
        onReady = args[1].asFunction();
        isOnReadySet = true;
      }
      else if(args.has(3) && args[3].isFunction())
      {
        onReady = args[3].asFunction();
        isOnReadySet = true;
      }
    }
  }

  ImageWidget* cIWidget = constructImageWidget(x, y, width, height, parent, args);

  if (isOnReadySet)
  {
    cIWidget->setOnReady(registerReadyCallback(cIWidget, onReady));
  }

  if (fill != "")
  {
    cIWidget->setFillMode(deserializeFillMode(fill));
  }

  cIWidget->setAsyncLoading(async);

  if (src_image)
  {
    cIWidget->setSource(src_image);
  }
  else if(bufferLength > 0)
  {
    cIWidget->setSource(buffer, bufferLength);
  }
  else
  {
    cIWidget->setSource(src);
  }

  //Register for destruction event. Need to cleanup
  WidgetDestructionCallback destructionCallback = std::bind( onDestruction, cIWidget);
  cIWidget->registerDestructionEvent(destructionCallback);

  return cIWidget;
}

ImageWidget* ImageWidgetBridge::constructImageWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
  if(width == -1 && height == -1)
  {
    return new ImageWidget(x, y, parent);
  }
  else
  {
    return new ImageWidget(x, y, (width == -1) ? 0 : width, (height == -1) ? 0 : height, parent);
  }
}

void ImageWidgetBridge::onDestruction(ImageWidget* self)
{
  unregisterReadyCallback(self);
}

ScriptObject ImageWidgetBridge::getImageColor(ImageWidget* self)
{
  Color color = self->getColor();
  return ColorToScript(color);
}

void ImageWidgetBridge::setImageColor(ImageWidget* self,
                                      ScriptObject scriptObject)
{
}


ScriptObject ImageWidgetBridge::getFillMode(ImageWidget* self)
{
  return ScriptObject(serializeFillMode(self->getFillMode()));
}

void ImageWidgetBridge::setFillMode(ImageWidget* self, ScriptObject value)
{
  ImageWidget::FillMode mode = deserializeFillMode(value.asString());
  self->setFillMode(mode);
}

ScriptObject ImageWidgetBridge::getSource(ImageWidget* self)
{
  if (self->getSourceImage())
  {
    return wrapExistingNativeObject(self->getSourceImage());
  }
  else
  {
    return self->getSource();
  }
}

void ImageWidgetBridge::setSource(ImageWidget* self, ScriptObject value)
{
  // load via URI
  if (value.isString())
  {
    self->setSource(value.asString());
  }
  // load via buffer
  else if (value.isArrayBuffer())
  {
    self->setSource(value.getExternalData(), value.getExternalDataLength());
  }
  // load via existing image object
  else
  {
    self->setSource(unwrapNativeObject<Image>(value));
  }
}

ScriptObject ImageWidgetBridge::getOnReady(ImageWidget* self)
{
  if (readyCallbacks.count(self))
  {
    return readyCallbacks[self];
  }
  else
  {
    return ScriptObject::Null();
  }
}


void ImageWidgetBridge::setOnReady(ImageWidget* self, ScriptObject value)
{
  ScriptFunction callback = value.asFunction();
  self->setOnReady(registerReadyCallback(self, callback));
}

ImageWidgetReadyCallback ImageWidgetBridge::registerReadyCallback(ImageWidget* self, ScriptFunction onReady)
{
  ImageWidgetReadyCallback readyCallback = std::bind(invokeReadyCallback, self, onReady, std::placeholders::_1);
  readyCallbacks[self] = onReady;
  return readyCallback;
}

void ImageWidgetBridge::unregisterReadyCallback(ImageWidget* self)
{
  if (readyCallbacks.count(self))
  {
    readyCallbacks.erase(self);
  }
}

void ImageWidgetBridge::invokeReadyCallback(ImageWidget* self, const ScriptFunction& callback, bool success)
{
  ScriptArray args;
  args.set(0, ScriptObject(success));
  callback.invoke(args);

  //once invoked, it need not be invoked again, so unregister it
  unregisterReadyCallback(self);
}

ImageWidget::FillMode ImageWidgetBridge::deserializeFillMode(const std::string& alignment)
{
  if (compareStrChar(alignment, "stretch"))
  {
    return ImageWidget::FillMode::Stretch;
  }
  else if (compareStrChar(alignment, "fit"))
  {
    return ImageWidget::FillMode::Fit;
  }
  else if (compareStrChar(alignment, "top"))
  {
    return ImageWidget::FillMode::Top;
  }
  else if (compareStrChar(alignment, "top-left"))
  {
    return ImageWidget::FillMode::Top_Left;
  }
  else if (compareStrChar(alignment, "top-right"))
  {
    return ImageWidget::FillMode::Top_Right;
  }
  else if (compareStrChar(alignment, "left"))
  {
    return ImageWidget::FillMode::Left;
  }
  else if (compareStrChar(alignment, "right"))
  {
    return ImageWidget::FillMode::Right;
  }
  else if (compareStrChar(alignment, "center"))
  {
    return ImageWidget::FillMode::Center;
  }
  else if (compareStrChar(alignment, "bottom-left"))
  {
    return ImageWidget::FillMode::Bottom_Left;
  }
  else if (compareStrChar(alignment, "bottom"))
  {
    return ImageWidget::FillMode::Bottom;
  }
  else if (compareStrChar(alignment, "bottom-right"))
  {
    return ImageWidget::FillMode::Bottom_Right;
  }
  else
  {
    return ImageWidget::FillMode::Stretch;
  }
}

std::string ImageWidgetBridge::serializeFillMode(const ImageWidget::FillMode alignment)
{
  switch (alignment)
  {
  case ImageWidget::FillMode::Stretch:
    return "stetch";
  case ImageWidget::FillMode::Fit:
    return "fit";
  case ImageWidget::FillMode::Top:
    return "top";
  case ImageWidget::FillMode::Top_Left:
    return "top-left";
  case ImageWidget::FillMode::Top_Right:
    return "top-right";
  case ImageWidget::FillMode::Left:
    return "left";
  case ImageWidget::FillMode::Right:
    return "right";
  case ImageWidget::FillMode::Center:
    return "center";
  case ImageWidget::FillMode::Bottom_Left:
    return "bottom-left";
  case ImageWidget::FillMode::Bottom:
    return "bottom";
  case ImageWidget::FillMode::Bottom_Right:
    return "bottom-right";

  default:
    return "stetch";
  }
}

ScriptObject ImageWidgetBridge::getColorPicking(ImageWidget* self, const ScriptArray& args)
{
  int percentage = 10;

  if (args.has(0) && args[0].isNumber())
  {
    percentage = args[0].asNumber();
  }

  Color color;
  ScriptObject retval = ScriptObject();
  retval.set("success", ScriptObject(self->getColorPicking(percentage, &color)));
  ScriptObject colval = ScriptObject();
  colval.set("r", ScriptObject((double)color.r));
  colval.set("g", ScriptObject((double)color.g));
  colval.set("b", ScriptObject((double)color.b));
  colval.set("a", ScriptObject((double)color.a));
  retval.set("color", colval);

  return retval;
}

} /* namespace Bridge */


