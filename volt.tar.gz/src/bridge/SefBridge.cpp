/*
 * SefBridge.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "SefBridge.h"
#include "StaticUI.h"
#include "Exception.h"

using namespace v8;
using namespace Bridge;
using namespace volt::util;

std::string SefBridge::LOGGER_NAME = "volt.sef.bridge";
SefBridge::CALLBACK_MAP SefBridge::callbackMap;
volt::util::Logger SefBridge::logger_(LOGGER_NAME);

SefBridge::SefBridge(): ScriptBridge()
{
}

SefBridge::~SefBridge()
{
}

gboolean SefBridge::FireSefOnEvent(gpointer aEventData)
{
  SefEventData *eventData = reinterpret_cast<SefEventData *>(aEventData);

  LOG_DEBUG(logger_,
            "Firing OnEvent function in JS (" << eventData->type << ", " <<
            eventData->param1 << ", " << eventData->param2 << ")");

  CALLBACK_MAP::const_iterator callbackIt = callbackMap.find(eventData->client);

  if (callbackIt == callbackMap.end())
  {
    // event callback is not defined

#ifdef ALLOW_DEPRECATED_SEF_CALLBACK
    Isolate* isolate = Isolate::GetCurrent();
    HandleScope handle_scope(isolate);

    /* Check if the function is defined in JS */
    Handle<String> name_handle = StringToV8("onSefEvent");
    Handle<Value> val_handle = isolate->GetCurrentContext()->Global()->Get(name_handle);

    if (val_handle->IsFunction())
    {
      LOG_WARN(logger_, "The onSefEvent global function is deprecated.  Do not use in new code.  Use (Sef Object).onEventCallback = (func)");
      Handle<Function> func_handle = Handle<Function>::Cast(val_handle);

      Handle<Value> args[3] =
      {
        Number::New(isolate, eventData->type),
        StringToV8(eventData->param1.c_str()),
        StringToV8(eventData->param2.c_str())
      };

      Handle<Value> val =
        func_handle->Call(isolate->GetCurrentContext()->Global(), 3, args);
      delete eventData;

      if (val.IsEmpty())
      {
        volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute Sef event callback");
      }

      return FALSE;
    }

#endif

    LOG_DEBUG(logger_, "onEventCallback function not set.");
    delete eventData;
    return FALSE;
  }

  // call the javascript callback with the event data parameters
  onSefEvent(callbackIt->second.onEventCB, eventData);

  delete eventData;

  return FALSE;
}

void SefBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(logger_, "Mapping script interfaces");

  aContext.capturePropertyAccess<SefClient, &GetOnEventCallback, &SetOnEventCallback>("onEventCallback");
  aContext.captureMethodCall<SefClient, &HandleOpen>("open");
  aContext.captureMethodCall<SefClient, &HandleOpenAsync>("openAsync");
  aContext.captureMethodCall<SefClient, &HandleClose>("close");
  aContext.captureMethodCall<SefClient, &HandleExecute>("execute");
  aContext.captureMethodCall<SefClient, &HandleExecuteAsync>("executeAsync");
}

void* SefBridge::constructFromScript(const ScriptArray &aArgs)
{
  LOG_DEBUG(logger_, "Creating a new instance");

  SefClient* client = new SefClient();

  ScriptFunction callback;
  int argsLen = aArgs.Length();

  if (argsLen > 0)
  {
    ScriptObject options = aArgs[0];

    if (options.has("onEventCallback"))
    {
      callback = options.get("onEventCallback").asFunction();
    }
    else if (aArgs.has(0) && aArgs[0].isFunction())
    {
      callback = aArgs[0].asFunction();
    }

    SetOnEventCallback(client, callback);
  }

  return client;
}

void SefBridge::onSefEvent(const ScriptFunction& callback, gpointer aData)
{
  LOG_DEBUG(logger_, "calling onSefEvent javascipt callback");
  SefEventData *eventData = reinterpret_cast<SefEventData *>(aData);
  ScriptArray args;
  args.set(0, ScriptObject(eventData->type));
  args.set(1, ScriptObject(eventData->param1));
  args.set(2, ScriptObject(eventData->param2));
  callback.invoke(args);
}

ScriptObject SefBridge::GetOnEventCallback(SefClient* self)
{
  CALLBACK_MAP::const_iterator it = callbackMap.find(self);

  if (it == callbackMap.end())
  {
    return ScriptObject();
  }
  else
  {
    return it->second.onEventCB;
  }
}

void SefBridge::SetOnEventCallback(SefClient* aSelf, ScriptObject scriptObj)
{
  LOG_DEBUG(logger_, "Setting OnEventCallback.");
  callbackMap[aSelf].onEventCB = scriptObj.asFunction();
}

ScriptObject SefBridge::HandleOpen(SefClient *aSelf, const ScriptArray &aArgs)
{
  return HandleOpenDoTheWork(false, aSelf, aArgs);
}

ScriptObject SefBridge::HandleOpenAsync(SefClient *aSelf, const ScriptArray &aArgs)
{
  return HandleOpenDoTheWork(true, aSelf, aArgs);
}

static void SefOpenThread(SefClient* aSelf, std::string name_str, std::string version_str, std::string credential_str);

ScriptObject SefBridge::HandleOpenDoTheWork(bool async, SefClient *aSelf,
    const ScriptArray &aArgs)
{
  do
  {
    if (async)
    {
      if (aArgs.Length() < 3 || aArgs.Length() > 4)
      {
        break;
      }
    }
    else
    {
      if (aArgs.Length() != 3)
      {
        break;
      }
    }

    if (aArgs[0].isString() == false)
    {
      break;
    }

    if (aArgs[1].isString() == false)
    {
      break;
    }

    if (aArgs[2].isString() == false)
    {
      break;
    }

    std::string name_str = aArgs[0].asString();
    aSelf->setName(name_str);
    std::string version_str = aArgs[1].asString();
    std::string credential_str = aArgs[2].asString();

    if (aSelf->getOpenThread().joinable() || aSelf->getExeThread().joinable())
    {
      return ScriptException("Unable to open Sef object \"" + name_str +
                             "\" while open or another execute is still in progress.");
    }

    bool result = true;

    if (async)
    {
      if (aArgs.Length() == 4 && aArgs[3].isFunction() == true)
      {
        callbackMap[aSelf].onOpenedCB = aArgs[3].asFunction();
      }

      // Start SefOpenThread to run the SefClient open command.  When it's finished
      // it will call the onOpenedCB if supplied.
      aSelf->setOpenThread(std::thread(SefOpenThread, aSelf, name_str, version_str, credential_str));
    }
    else
    {
      // synchronous version
      result = aSelf->Open(name_str, version_str, credential_str);
    }

    return ScriptObject(result);
  }
  while(0);

  return ScriptException("Failed to handle the Sef Open call due to invalid parameters");
}

gboolean SefBridge::HandleOpenResponse(gpointer aResponseData)
{
  SefOpenResponse* openData = reinterpret_cast<SefOpenResponse*>(aResponseData);

  // By the time this is called the openThread will have completed. Join it here so
  // other operations are allowed.
  openData->client->getOpenThread().join();

  CALLBACK_MAP::iterator callbackIt = callbackMap.find(openData->client);

  if (callbackIt == callbackMap.end() || callbackIt->second.onOpenedCB.isNull())
  {
    // open callback is not defined
    LOG_DEBUG(logger_, "onOpenCB function not set.");
    delete openData;
    return FALSE;
  }

  ScriptArray args;
  args.set(0, ScriptObject(openData->response));

  // call the javascript callback with the result
  // take a copy of the func and set the func to null before calling
  // it so that the callback can call another sef->open()
  ScriptFunction func = callbackIt->second.onOpenedCB;
  callbackIt->second.onOpenedCB = ScriptFunction();
  func.invoke(args);

  delete openData;
  return FALSE;
}

static void SefOpenThread(SefClient* aSelf, std::string name_str, std::string version_str, std::string credential_str)
{
  Logger logger(SefBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Starting SefOpenThread.");

  /* HACK HACK HACK */
  /* Register an idle callback to be executed on the main thread.
   * HandleOpenResponse MUST be run on the main thread (or the same thread as v8)
   * since v8 is not thread-safe (by design?)!  */
  Bridge::SefBridge::SefOpenResponse* responseData = new Bridge::SefBridge::SefOpenResponse();
  responseData->client = aSelf;
  responseData->response = aSelf->Open(name_str, version_str, credential_str);
  clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                Bridge::SefBridge::HandleOpenResponse, responseData, NULL);
  LOG_DEBUG(logger, "Ending SefOpenThread.");
}

ScriptObject SefBridge::ExeResponseToScriptObject(const std::string& result,
                                                  SefClient* aSelf)
{
  std::string name = aSelf->getName();
  std::string cmd_str = aSelf->getLastCmd();
  LOG_DEBUG(logger_, "Execute of \"" + cmd_str + "\" result from Sef \"" << 
            name << "\": " << result);

  do
  {
    if (result.empty())
    {
      break;
    }

    if (result[0] == 'A')
    {
      /* ASCII */
      return ScriptObject(result.substr(1));
    }
    else if (result[0] == 'U')
    {
      /* 2-byte characters */
      return ScriptObject(result); /* TEMP */
    }
    else if (result[0] == 'I')
    {
      /* Number */
      long int value = 0;
      char *end_ptr = NULL;
      value = strtol(&(result.c_str()[1]), &end_ptr, 0);

      if (*end_ptr == '\0')
      {
        /* Good string (assuming non-empty string) */
        return ScriptObject(static_cast<double>(value));
      }
      else
      {
        LOG_WARN(logger_, "Failed to convert to numeric value");
        break;
      }
    }
  }
  while (0);

  return ScriptException("Failed to handle the Sef, \"" + name + "\" Execute command \"" +
                         cmd_str + "\".");
}

gboolean SefBridge::HandleExecuteResponse(gpointer aResponseData)
{
  SefExecuteResponse* exeData = reinterpret_cast<SefExecuteResponse*>(aResponseData);

  // By the time this is called the exeThread will have completed. Join it here so
  // other operations are allowed.
  exeData->client->getExeThread().join();

  CALLBACK_MAP::iterator callbackIt = callbackMap.find(exeData->client);

  if (callbackIt == callbackMap.end() || callbackIt->second.onExecutedCB.isNull())
  {
    // executed callback is not defined
    LOG_DEBUG(logger_, "onExecutedCB function not set.");
    delete exeData;
    return FALSE;
  }

  ScriptArray args;
  args.set(0, ExeResponseToScriptObject(exeData->response, exeData->client));

  // call the javascript callback with the event data parameters
  // take a copy of the func and set the func to null before calling
  // it so that the callback can call another sef->execute()
  ScriptFunction func = callbackIt->second.onExecutedCB;
  callbackIt->second.onExecutedCB = ScriptFunction();
  func.invoke(args);

  delete exeData;
  return FALSE;
}

static void SefExecuteThread(SefClient *aSelf, std::string cmd_str, std::vector<std::string> args)
{
  Logger logger(SefBridge::LOGGER_NAME);
  LOG_DEBUG(logger, "Starting SefExecuteThread.");

  /* HACK HACK HACK */
  /* Register an idle callback to be executed on the main thread.
   * HandleExecuteResponse MUST be run on the main thread (or the same thread as v8)
   * since v8 is not thread-safe (by design?)!  */
  Bridge::SefBridge::SefExecuteResponse* responseData = new Bridge::SefBridge::SefExecuteResponse();
  responseData->client = aSelf;
  responseData->response = aSelf->Execute(cmd_str, args);
  clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                Bridge::SefBridge::HandleExecuteResponse, responseData, NULL);
}

ScriptObject SefBridge::HandleExecuteDoTheWork(bool async, SefClient *aSelf,
    const ScriptArray &aArgs)
{
  std::string cmd_str;
  do
  {
    if (aArgs.Length() == 0)
    {
      break;
    }

    if (aArgs[0].isString() == false)
    {
      break;
    }

    cmd_str = aArgs[0].asString();
    aSelf->setLastCmd(cmd_str);

    std::vector<std::string> args;
    unsigned int index = 1;

    for (; index < aArgs.Length(); ++index)
    {
      if (aArgs[index].isString() == false)
      {
        break;
      }

      args.push_back(aArgs[index].asString());
    }

    // create cmd args as string for error reporting.
    std::string cmd_args = "(";
    auto it = args.begin();
    if (it != args.end())
    {
      cmd_args += *it;
    }
    ++it;
    for (; it < args.end(); ++it)
    {
      cmd_args += ", " + *it;
    }
    cmd_args += ")";
    aSelf->setLastCmd(cmd_str + cmd_args);
    LOG_DEBUG(logger_, "Running execute command \"" << aSelf->getLastCmd() << 
              "\" on Sef, \"" << aSelf->getName() << "\"");

    if (aSelf->getOpenThread().joinable() || aSelf->getExeThread().joinable())
    {
      return ScriptException("Unable to execute command, \"" + aSelf->getLastCmd() + 
                             "\" on Sef, \"" + aSelf->getName() +
                             "\" while open or another execute is still running.");
    }

    // If optional callback function is supplied in last JS argument call it after async execution.
#ifdef ALLOW_DEPRECATED_SEF_EXECUTE_API
    bool condition = index < aArgs.Length() and aArgs[index].isFunction();
#else
    bool condition = async and index < aArgs.Length() and aArgs[index].isFunction();
#endif

    if (condition)
    {
#ifdef ALLOW_DEPRECATED_SEF_EXECUTE_API

      if (!async)
      {
        LOG_WARN(logger_, "DEPRECATED: The use of a callback function as the last param of sef.execute() is deprecated (Volt 1.8).  Please use executeAsync() in new code.");
      }

      // The following "async = true" is code supporting the old API for Execute() which runs asynchronous
      // if the user supplied a JS function as the last argument.
      async = true;
#endif

      if (!callbackMap[aSelf].onExecutedCB.isNull())
      {
        LOG_ERROR(logger_, "Trying to call an execute on the same Sef, \"" << 
                  aSelf->getName() << "\" with another in progress.");
        break;
      }

      LOG_DEBUG(logger_, "Setting onExecutedCB.");
      callbackMap[aSelf].onExecutedCB = aArgs[index].asFunction();
      ++index;
    }

    if (index < aArgs.Length())
    {
      break;
    }

    if (async)
    {
      // Start SefExecuteThread to run the SefClient execute command. When its finished
      // it will call the onExcectedCB supplied.
      aSelf->setExeThread(std::thread(SefExecuteThread, aSelf, cmd_str, args));
      return ScriptObject(true);
    }
    else
    {
      // run execute synchronously and return result immediately
      return ExeResponseToScriptObject( aSelf->Execute(cmd_str, args), aSelf);
    }
  } while (0);

  return ScriptException("Failed to handle the Sef execute command, \"" + cmd_str +
                         "\" on Sef, \"" + aSelf->getName() + "\".");
}

ScriptObject SefBridge::HandleExecute(SefClient *aSelf, const ScriptArray &aArgs)
{
  // Currently this can execute synchronously or asynchronously based on whether
  // the optional last JS parameter is a function.
  // TBD: In a future major release, it will only execute synchronously.
  // See HandleExecuteDoTheWork().
  return HandleExecuteDoTheWork(false, aSelf, aArgs);
}

ScriptObject SefBridge::HandleExecuteAsync(SefClient *aSelf, const ScriptArray &aArgs)
{
  return HandleExecuteDoTheWork(true, aSelf, aArgs);
}

ScriptObject SefBridge::HandleClose(SefClient *aSelf, const ScriptArray &aArgs)
{
  if (aSelf->getOpenThread().joinable() || aSelf->getExeThread().joinable())
  {
    return ScriptException("Unable to close Sef \"" + aSelf->getName() +
                           "\" while open or another execute is still in progress.");
  }

  bool result = aSelf->Close();
  return ScriptObject(result);
}

