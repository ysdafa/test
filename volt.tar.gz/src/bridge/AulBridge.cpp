/*
 * AulBridge.cpp
 *
 *  Created on: June 26th, 2014
 *      Author: Joe Yee
 */

#include "AulBridge.h"
#include "Exception.h"

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include <clutter/clutter.h>
#include <bundle.h>
#endif

namespace Bridge
{
std::string AulBridge::LOGGER_NAME = "volt.aul.bridge";
volt::util::Logger AulBridge::logger_(LOGGER_NAME);
AulBridge::CALLBACK_MAP AulBridge::callbackMap;

AulBridge::AulBridge()
  : ScriptBridge()
{
}

AulBridge::~AulBridge()
{
}

void AulBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(logger_, "Mapping AUL script interfaces");

  aContext.captureMethodCall<TizenAul, &HandleLaunchApp>("launchApp");
  aContext.captureMethodCall<TizenAul, &HandleLaunchAppEx>("launchAppEx");
  aContext.captureMethodCall<TizenAul, &HandleOpenApp>("openApp");
  aContext.captureMethodCall<TizenAul, &HandleResumeApp>("resumeApp");
  aContext.captureMethodCall<TizenAul, &HandleResumePID>("resumePID");
  aContext.captureMethodCall<TizenAul, &HandleAppIsRunning>("appIsRunning");
  aContext.captureMethodCall<TizenAul, &HandleOpenSerivce>("openService");

  aContext.captureMethodCall<TizenAul, &HandleTerminate>("terminate");
  aContext.captureMethodCall<TizenAul, &HandleTerminatePID>("terminatePID");
  aContext.captureMethodCall<TizenAul, &HandleTerminateApp>("terminateApp");
  aContext.captureMethodCall<TizenAul, &HandleTerminatePkg>("terminatePkg");
  

}

void* AulBridge::constructFromScript(const ScriptArray &aArgs)
{
  LOG_DEBUG(logger_, "Creating a new instance");

  TizenAul* client = new TizenAul();

  return client;
}

ScriptObject AulBridge::HandleLaunchApp(TizenAul *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null aul app pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen)
  {
    // get id
    std::string appId = aArgs[0].asString();

    LOG_DEBUG(logger_, "launch app " << appId);

    // extract arguments
#if defined(BUILD_FOR_TV) && defined(TIZEN)
    bundle *aulBundle = NULL;

    if(argsLen > 1)
    {
      ScriptObject aulArgs = aArgs[1];
      aulBundle = extractArguments(aulArgs);
    }

    if(aSelf->LaunchApp(appId, aulBundle) > 0)
    {
      result = true;
    }

    if(aulBundle)
    {
      bundle_free(aulBundle);
    }

#endif
  }

  return ScriptObject(result);
}

ScriptObject AulBridge::HandleLaunchAppEx(TizenAul *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null aul app pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen)
  {
    // get id
    std::string appId = aArgs[0].asString();

    LOG_DEBUG(logger_, "launch app ex " << appId);

    // extract arguments
#if defined(BUILD_FOR_TV) && defined(TIZEN)
    bundle *aulBundle = NULL;

    if(argsLen > 1)
    {
      ScriptObject aulArgs = aArgs[1];
      aulBundle = extractArguments(aulArgs);
    }

    if(aSelf->LaunchAppEx(appId, aulBundle) > 0)
    {
      result = true;
    }

    if(aulBundle)
    {
      bundle_free(aulBundle);
    }

#endif
  }

  return ScriptObject(result);
}

ScriptObject AulBridge::HandleOpenApp(TizenAul *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null aul app pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen)
  {
    // get id
    std::string appId = aArgs[0].asString();

    LOG_DEBUG(logger_, "open app " << appId);

    // extract arguments
#if defined(BUILD_FOR_TV) && defined(TIZEN)

    if(aSelf->OpenApp(appId) > 0)
    {
      result = true;
    }

#endif
  }

  return ScriptObject(result);
}

ScriptObject AulBridge::HandleResumeApp(TizenAul *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null aul app pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen)
  {
    // get id
    std::string appId = aArgs[0].asString();

    LOG_DEBUG(logger_, "resume app " << appId);

    // extract arguments
#if defined(BUILD_FOR_TV) && defined(TIZEN)

    if(aSelf->ResumeApp(appId) > 0)
    {
      result = true;
    }

#endif
  }

  return ScriptObject(result);
}


ScriptObject AulBridge::HandleResumePID(TizenAul *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null aul app pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen)
  {
    // get pid
    int pid = aArgs[0].asNumber();

    LOG_DEBUG(logger_, "resume app " << pid);

    // extract arguments
#if defined(BUILD_FOR_TV) && defined(TIZEN)

    if(aSelf->ResumePID(pid) > 0)
    {
      result = true;
    }

#endif
  }

  return ScriptObject(result);
}

ScriptObject AulBridge::HandleAppIsRunning(TizenAul *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null aul app pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen)
  {
    // get id
    std::string appId = aArgs[0].asString();

    LOG_DEBUG(logger_, "app is running " << appId);

    // extract arguments
#if defined(BUILD_FOR_TV) && defined(TIZEN)

    if(aSelf->AppIsRunning(appId) > 0)
    {
      result = true;
    }

#endif
  }

  return ScriptObject(result);
}


ScriptObject AulBridge::HandleOpenSerivce(TizenAul *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen)
  {
    // extract id
    std::string serviceId = aArgs[0].asString();

    LOG_DEBUG(logger_, "open service " << serviceId);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
    bool hasCallback = false;

    // extract the callback function
    if (argsLen == 3)
    {
      if(aArgs[2].isFunction())
      {
        if(callbackMap.count(aSelf) == 0)
        {
          callbackMap[aSelf] = aArgs[2].asFunction();
          hasCallback = true;
        }
        else
        {
          LOG_ERROR(logger_, "callback already registered for " << aSelf);
        }
      }
      else
      {
        LOG_ERROR(logger_, "3rd parameter is not passed in as a function");
      }
    }

    // extract arguments
    bundle *aulBundle = NULL;

    if(argsLen > 1)
    {
      ScriptObject aulArgs = aArgs[1];
      aulBundle = extractArguments(aulArgs);
    }

    if(aSelf->OpenService(serviceId, aulBundle, hasCallback) > 0)
    {
      result = true;
    }

    if(aulBundle)
    {
      bundle_free(aulBundle); // TODO do we do this here?
    }

#endif
  }

  return ScriptObject(result);
}

ScriptObject AulBridge::HandleTerminate(TizenAul *aSelf, const ScriptArray &aArgs)
{
  LOG_DEBUG(logger_, "terminate " << aSelf);

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null pointer");
    return ScriptObject(false);
  }

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(aSelf->Terminate() < 0)
  {
    return ScriptObject(false);
  }

  // remove callback
  if(callbackMap.count(aSelf))
  {
    callbackMap.erase(aSelf);
  }

#endif

  return ScriptObject(true);
}


ScriptObject AulBridge::HandleTerminatePID(TizenAul *aSelf, const ScriptArray &aArgs)
{
  LOG_DEBUG(logger_, "terminate " << aSelf);

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null pointer");
    return ScriptObject(false);
  }

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  int argsLen = aArgs.Length();

  if (argsLen)
  {
	  int pid = aArgs[0].asNumber();

	  LOG_DEBUG(logger_, "resume app " << pid);
	  if(aSelf->TerminatePID(pid) < 0)
	  {
		return ScriptObject(false);
	  }

	  // remove callback
	  if(callbackMap.count(aSelf))
	  {
		callbackMap.erase(aSelf);
	  }

  }
#endif
  return ScriptObject(true);
}


ScriptObject AulBridge::HandleTerminateApp(TizenAul *aSelf, const ScriptArray &aArgs)
{
  LOG_DEBUG(logger_, "terminate " << aSelf);

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null pointer");
    return ScriptObject(false);
  }

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  int argsLen = aArgs.Length();

  if (argsLen)
  {
	  std::string appId = aArgs[0].asString();

	  LOG_DEBUG(logger_, "resume app " << appId);
	  if(aSelf->TerminateApp(appId) < 0)
	  {
		return ScriptObject(false);
	  }

	  // remove callback
	  if(callbackMap.count(aSelf))
	  {
		callbackMap.erase(aSelf);
	  }

  }
#endif
  return ScriptObject(true);
}

ScriptObject AulBridge::HandleTerminatePkg(TizenAul *aSelf, const ScriptArray &aArgs)
{
  LOG_DEBUG(logger_, "terminate " << aSelf);

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null pointer");
    return ScriptObject(false);
  }

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  int argsLen = aArgs.Length();

  if (argsLen)
  {
	  std::string pkgName = aArgs[0].asString();

	  LOG_DEBUG(logger_, "resume app " << pkgName);
	  if(aSelf->TerminatePkg(pkgName) < 0)
	  {
		return ScriptObject(false);
	  }

	  // remove callback
	  if(callbackMap.count(aSelf))
	  {
		callbackMap.erase(aSelf);
	  }

  }
#endif
  return ScriptObject(true);
}


#if defined(BUILD_FOR_TV) && defined(TIZEN)

void AulBridge::ProxyLaunchServiceCallback(TizenAul *aSelf, bundle *b)
{
  CallbackMessage *msg = new CallbackMessage();
  msg->aul = aSelf; // i think there is a bug here
  msg->aulBundle = b; // memory for this will be deallocated in the callback funciton

  /* Gotta invoke the js handlers in the v8/clutter thread */
  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
                                [](gpointer aData) -> gboolean
  {
    CallbackMessage *data = reinterpret_cast<CallbackMessage *>(aData);
    AulBridge::FireLaunchServiceCallback(data);
    return FALSE;
  }, msg, NULL);
}

bundle *AulBridge::extractArguments(ScriptObject &args)
{
  bundle *aulBundle = nullptr;
  ScriptArray keyNames = args.getKeyNames();

  if(keyNames.Length() == 0)
  {
    LOG_ERROR(logger_, "no key found");
    return aulBundle;
  }

  int result = -1;

  aulBundle = bundle_create();

  for(unsigned i = 0; i < keyNames.Length(); i ++)
  {
    ScriptObject value;
    std::string key = keyNames[i].asString();

    if(key.length() && args.tryGet(key, value))
    {
      if(value.isArray())
      {
        // extract element for byte array or string array..
        ScriptArray valueArray(value);
        bool isString = false;
        unsigned arraySize = valueArray.Length();

        if(arraySize == 0)
        {
          LOG_ERROR(logger_, "0 length string/byte array type for key [" << key << "]");
          break;
        }
        else
        {
          // determine array type
          const char *data[arraySize];
          int failed = false;
          isString = valueArray[0].isString();

          for(unsigned j = 0; j < arraySize; j ++)
          {
            // validate every element in array is of same type
            if(isString == valueArray[j].isString())
            {
              // string type
              if(isString)
              {
                LOG_DEBUG(logger_, "got key: " << key << ", array string: " << valueArray[j].asString());
                data[j] = valueArray[j].asString().c_str();
              }
              // byte array
              else
              {
                LOG_DEBUG(logger_, "got key: " << key << ", array byte data at: %p" << valueArray[j].getExternalData());
                data[j] = (const char *)valueArray[j].getExternalData();
              }
            }
            else
            {
              failed = true;
              LOG_ERROR(logger_, "array type mismatch key [" << key << "]");
            }
          }

          if(not failed)
          {
            if(isString)
            {
              result = bundle_add_str_array(aulBundle, key.c_str(), data, arraySize);
            }
            else
            {
              //TODO JOE: I'm confused about what this is doing, there is no place to put in byte size
              //              result = bundle_add_byte_array(aulBundle, key.c_str(), (void **)data, arraySize);
              LOG_ERROR(logger_, "unsupported value type byte array for key [" << key << "]");
            }
          }
        }
      }
      else if(value.isArrayBuffer())
      {
        if(value.getExternalData() != NULL)
        {
          LOG_DEBUG(logger_, "got key: " << key << ", byte data at: %p" << value.getExternalData());
          result = bundle_add_byte(aulBundle, key.c_str(), value.getExternalData(),
                                   value.getExternalDataLength());
        }
        else
        {
          LOG_ERROR(logger_, "null external data for array buffer at [" << key << "]");
        }
      }
      else if(value.isBool())
      {
        LOG_ERROR(logger_, "unsupported value type BOOL for key [" << key << "]");
      }
      else if(value.isNumber())
      {
        LOG_ERROR(logger_, "unsupported value type NUMBER for key [" << key << "]");
      }
      else if(value.isString())
      {
        LOG_DEBUG(logger_, "got key: " << key << ", string: " << value.asString());
        result = bundle_add_str(aulBundle, key.c_str(), value.asString().c_str());
      }
      else
      {
        LOG_ERROR(logger_, "unsupported value type for key [" << key << "]");
      }
    }
    else
    {
      LOG_ERROR(logger_, "no value found for key [" << key << "]");
    }
  }

  // something went bad, clean up
  if(result == -1)
  {
    LOG_ERROR(logger_, "fatal error, failed to create bundle");
    bundle_free(aulBundle);
    aulBundle = nullptr;
  }

  return aulBundle;
}

static void populateScriptObjects(const char *key, const int type, const bundle_keyval_t *kv, void *user_data)
{
  volt::util::Logger logger("volt.resource.directory");

  if(not key || not kv || not user_data)
  {
    LOG_ERROR(logger, "AulBridge.cpp::populateScriptObjects null pointer");
    return;
  }

  ScriptObject *output = (ScriptObject*) user_data;
  std::string outputKey(key);

  // copied from bundle.h
  void *basic_val = NULL;
  size_t basic_size = 0;
  void **array_val = NULL;
  unsigned int array_len = 0;
  size_t *array_elem_size = NULL;

  if(bundle_keyval_type_is_array((bundle_keyval_t*)kv))
  {
    ScriptArray subArray;

    if(type == BUNDLE_TYPE_STR)
    {
      bundle_keyval_get_array_val((bundle_keyval_t*)kv, &array_val, &array_len, &array_elem_size);

      for(size_t i = 0; i < array_len; i++)
      {
        std::string stringValue((const char*)array_val[i], array_elem_size[i]);
        subArray.set(i, ScriptObject(stringValue));
      }

      output->set(outputKey, subArray);
    }
    else if(type == BUNDLE_TYPE_BYTE)
    {
      bundle_keyval_get_array_val((bundle_keyval_t*)kv, &array_val, &array_len, &array_elem_size);

      for(size_t i = 0; i < array_len; i++)
      {
        subArray.set(i, ScriptArrayBuffer(array_val[i], array_elem_size[i]));
      }

      output->set(outputKey, subArray);
    }
    else
    {
      LOG_ERROR(logger, "AulBridge.cpp::populateScriptObjects unhandled array bundle key value type " << type);
    }
  }
  else
  {
    if(type == BUNDLE_TYPE_STR)
    {
      bundle_keyval_get_basic_val((bundle_keyval_t*)kv, &basic_val, &basic_size);

      std::string stringValue((char*)basic_val, basic_size);

      output->set(outputKey, stringValue);
    }
    else if(type == BUNDLE_TYPE_BYTE)
    {
      bundle_keyval_get_basic_val((bundle_keyval_t*)kv, &basic_val, &basic_size);

      output->set(outputKey, ScriptArrayBuffer(basic_val, basic_size));
    }
    else
    {
      LOG_ERROR(logger, "AulBridge.cpp::populateScriptObjects unhandled bundle key value type " << type);
    }
  }
}

void AulBridge::FireLaunchServiceCallback(CallbackMessage *msg)
{
  TizenAul *aSelf = msg->aul;
  bundle *b = msg->aulBundle;

  if(aSelf == nullptr || b == nullptr)
  {
    LOG_ERROR(logger_, "null AulApp or bundle pointer, failed to fire launch service callback");
    delete msg;
    return;
  }

  // just in case if the TizenAul object is gone already
  if(callbackMap.count(aSelf) == 0)
  {
    LOG_WARN(logger_, "no callback registered, skipping launch service callback");

    if(b)
    {
      bundle_free(b);
    }

    delete msg;
    return;
  }

  // parse the bundle
  int bundleCount = bundle_get_count(b);

  ScriptArray result;
  ScriptObject output;

  if(bundleCount > 0)
  {
    bundle_foreach(b, populateScriptObjects, &output);
  }
  else
  {
    LOG_ERROR(logger_, "received empty bundle");
  }

  result.set(0, output);

  callbackMap[aSelf].invoke(result);

  callbackMap.erase(aSelf);

  if(b)
  {
    bundle_free(b);
  }

  delete msg;
}

#endif
};

