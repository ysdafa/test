#include "LogBridge.h"
using namespace Bridge;

std::string LogBridge::LOGGER_NAME = "volt.log.bridge";
volt::util::Logger LogBridge::logger_(LOGGER_NAME);

LogBridge::LogBridge(): ScriptInstanceBridge(this)
{
}

LogBridge::~LogBridge()
{
}

void LogBridge::mapScriptInterface(ScriptContext& aContext)
{
	aContext.captureMethodCall<LogBridge, &HandlePrint>("print");
	aContext.captureMethodCall<LogBridge, &HandleDebug>("d");
	aContext.captureMethodCall<LogBridge, &HandleInfo>("i");
	aContext.captureMethodCall<LogBridge, &HandleFatal>("f");
	aContext.captureMethodCall<LogBridge, &HandleError>("e");
	aContext.captureMethodCall<LogBridge, &HandleFirstSyscall>("syscall");
}

void* LogBridge::constructFromScript(const ScriptArray &aArgs)
{
	return this;
}

/* This is called when the global print function is called. */
ScriptObject LogBridge::HandlePrint(LogBridge *aSelf, const ScriptArray &args)
{
	static volt::util::Logger logger("volt.js");
	v8::Isolate* isolate = v8::Isolate::GetCurrent();

	std::string msg = "";
	bool first = true;
	for (int i = 0; i < args.Length(); i++)
	{
		v8::HandleScope handle_scope(isolate);
		if (first)
		{
			first = false;
		}
		else
		{
			msg += " ";
		}
		std::string str = args[i].asString();
		if(str == NULL)
			str = "";
		msg += str;
	}

#ifdef USE_DLOG
#pragma push_macro("LOG_TAG")
#undef LOG_TAG
#define LOG_TAG "VOLT_JS"
#endif
	LOG_INFO_APP(logger, msg);
#ifdef USE_DLOG
#pragma pop_macro("LOG_TAG")
#endif

	return ScriptObject(true);
}

/* This is called when the global print function is called. */
ScriptObject LogBridge::HandleDebug(LogBridge *aSelf, const ScriptArray &args)
{
	static volt::util::Logger logger("volt.js");
	v8::Isolate* isolate = v8::Isolate::GetCurrent();

	std::string msg = "";
	bool first = true;
	for (int i = 0; i < args.Length(); i++)
	{
		v8::HandleScope handle_scope(isolate);
		if (first)
		{
			first = false;
		}
		else
		{
			msg += " ";
		}
		std::string str = args[i].asString();
		if(str == NULL)
			str = "";
		msg += str;
	}

#ifdef USE_DLOG
#pragma push_macro("LOG_TAG")
#undef LOG_TAG
#define LOG_TAG "VOLT_JS"
#endif
	LOG_DEBUG_APP(logger, msg);
#ifdef USE_DLOG
#pragma pop_macro("LOG_TAG")
#endif

	return ScriptObject(true);
}

/* This is called when the global print function is called. */
ScriptObject LogBridge::HandleInfo(LogBridge *aSelf, const ScriptArray &args)
{
	static volt::util::Logger logger("volt.js");
	v8::Isolate* isolate = v8::Isolate::GetCurrent();

	std::string msg = "";
	bool first = true;
	for (int i = 0; i < args.Length(); i++)
	{
		v8::HandleScope handle_scope(isolate);
		if (first)
		{
			first = false;
		}
		else
		{
			msg += " ";
		}
		std::string str = args[i].asString();
		if(str == NULL)
			str = "";
		msg += str;
	}

#ifdef USE_DLOG
#pragma push_macro("LOG_TAG")
#undef LOG_TAG
#define LOG_TAG "VOLT_JS"
#endif
	LOG_INFO_APP(logger, msg);
#ifdef USE_DLOG
#pragma pop_macro("LOG_TAG")
#endif

	return ScriptObject(true);
}

/* This is called when the global print function is called. */
ScriptObject LogBridge::HandleError(LogBridge *aSelf, const ScriptArray &args)
{
	static volt::util::Logger logger("volt.js");
	v8::Isolate* isolate = v8::Isolate::GetCurrent();

	std::string msg = "";
	bool first = true;
	for (int i = 0; i < args.Length(); i++)
	{
		v8::HandleScope handle_scope(isolate);
		if (first)
		{
			first = false;
		}
		else
		{
			msg += " ";
		}
		std::string str = args[i].asString();
		if(str == NULL)
			str = "";
		msg += str;
	}

#ifdef USE_DLOG
#pragma push_macro("LOG_TAG")
#undef LOG_TAG
#define LOG_TAG "VOLT_JS"
#endif
	LOG_ERROR_APP(logger, msg);
#ifdef USE_DLOG
#pragma pop_macro("LOG_TAG")
#endif
	return ScriptObject(true);
}

/* This is called when the global print function is called. */
ScriptObject LogBridge::HandleFatal(LogBridge *aSelf, const ScriptArray &args)
{
	static volt::util::Logger logger("volt.js");
	v8::Isolate* isolate = v8::Isolate::GetCurrent();

	std::string msg = "";
	bool first = true;
	for (int i = 0; i < args.Length(); i++)
	{
		v8::HandleScope handle_scope(isolate);
		if (first)
		{
			first = false;
		}
		else
		{
			msg += " ";
		}
		std::string str = args[i].asString();
		if(str == NULL)
			str = "";
		msg += str;
	}

#ifdef USE_DLOG
#pragma push_macro("LOG_TAG")
#undef LOG_TAG
#define LOG_TAG "VOLT_JS"
#endif
	LOG_FATAL_APP(logger, msg);
#ifdef USE_DLOG
#pragma pop_macro("LOG_TAG")
#endif

	return ScriptObject(true);
}

ScriptObject LogBridge::HandleFirstSyscall(LogBridge *aSelf, const ScriptArray &args)
{
	int number = (int) args[0].asNumber();
	std::string msg = args[1].asString();
	
	printf("syscall: %d %s\n", number, msg.c_str());
	syscall(number, msg.c_str()); 

	return ScriptObject(true);
}
