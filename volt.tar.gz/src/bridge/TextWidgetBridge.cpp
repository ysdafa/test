/*
 * TextWidgetBridge.cpp
 *
 *  Created on: May 22, 2013
 *      Author: reza
 */

#include "TextWidgetBridge.h"

using namespace volt::graphics;

namespace Bridge
{

volt::util::Logger TextWidgetBridge::logger("volt.text.bridge");

void TextWidgetBridge::mapScriptInterface(ScriptContext& context)
{
  WidgetBridge::mapScriptInterface(context);

  context.bindString<TextWidget, &TextWidget::getText, &TextWidget::setText>("text");
  context.bindString<TextWidget, &TextWidget::getFontName, &TextWidget::setFontName>("font");
  context.bindBoolean<TextWidget, &TextWidget::getUseEllipses, &TextWidget::setUseEllipses>("ellipsize");
  context.bindBoolean<TextWidget, &TextWidget::getJustifyText, &TextWidget::setJustifyText>("justify");
  context.bindBoolean<TextWidget, &TextWidget::getSingleLineMode, &TextWidget::setSingleLineMode>("singleLineMode");
  context.bindNumber<TextWidget, int, &TextWidget::getLineSpacing, &TextWidget::setLineSpacing>("lineSpacing");

  context.capturePropertyAccess<TextWidget, &getAlignment, &setAlignment>("horizontalAlignment"); //support both for backwards compatibility
  context.capturePropertyAccess<TextWidget, &getVAlignment, &setVAlignment>("verticalAlignment");

  context.capturePropertyAccess<TextWidget, &getTextColor, &setTextColor>("textColor");
  context.capturePropertyAccess<TextWidget, &getShadow, &setShadow>("textShadow");

  context.captureMethodCall<TextWidget, &charIndexAtCoordinate>("charIndexAtCoordinate");
  context.captureMethodCall<TextWidget, &coordinateAtCharIndex>("coordinateAtCharIndex");
  context.captureMethodCall<TextWidget, &getHeightInLines>("getHeightInLines");
  context.captureMethodCall<TextWidget, &setHeightInLines>("setHeightInLines");
  context.captureMethodCall<TextWidget, &getLineHeight>("getLineHeight");
  context.captureMethodCall<TextWidget, &getTextOverflow>("getTextOverflow");
  context.captureMethodCall<TextWidget, &getTextOverflowLines>("getTextOverflowLines");
  context.captureMethodCall<TextWidget, &insertText>("insertText");
  context.captureMethodCall<TextWidget, &removeText>("removeText");
  context.captureMethodCall<TextWidget, &isRightToLeft>("isRightToLeft");
}

Widget* TextWidgetBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
  std::string text, font;
  bool justify = false, ellipsize = false, singleLineMode = false;
  LayoutAlignment align = LayoutAlignment::Left;
  VerticalLayoutAlignment valign = VerticalLayoutAlignment::Top;
  Color color = Color::White();
  int lineSpacing = 0;
  int maxLines = 0;
  bool maxLinesSpecified = false;

  if(args.Length() > 0)
  {
    //Get available arguments, either by options arguments or ordered, but not both.

    ScriptObject options = args[0];

    if(options.has("text") || options.has("font") || options.has("textColor") || options.has("horizontalAlignment") || options.has("verticalAlignment") ||
       options.has("ellipsize") ||  options.has("justify") || options.has("singleLineMode") ||
       options.has("lineSpacing"))
    {
      //options arguments
      if( options.has("text") )
      {
        text = options.get("text").asString();
      }

      if( options.has("font") )
      {
        font = options.get("font").asString();
      }

      if( options.has("textColor") )
      {
        color = ScriptToColor(options.get("textColor"));
      }

      if( options.has("ellipsize") )
      {
        ellipsize = options.get("ellipsize").asBool();
      }

      if( options.has("justify") )
      {
        justify = options.get("justify").asBool();
      }

      if( options.has("singleLineMode") )
      {
        singleLineMode = options.get("singleLineMode").asBool();
      }

      if( options.has("horizontalAlignment") )
      {
        align = deserializeLayoutAlignment(options.get("horizontalAlignment").asString(), Left);
      }

      if( options.has("verticalAlignment") )
      {
        valign = deserializeVerticalAlignment(options.get("verticalAlignment").asString());
      }

      if ( options.has("lineSpacing") )
      {
        lineSpacing = options.get("lineSpacing").asNumber();
      }

      if (options.has("maxLines"))
      {
        maxLines = options.get("maxLines").asNumber();
        maxLinesSpecified = true;
      }
    }
    else //regular arguments
    {
      //Special case where only text is specified
      if(args[0].isString())
      {
        text = args[0].asString();
      }
    }
  }

  TextWidget* textWidget = new TextWidget( x, y, text, font, parent );
  textWidget->setLineSpacing(lineSpacing);

  if(width != -1)
  {
    textWidget->setWidth(width);
  }

  if(height != -1 && !maxLinesSpecified)
  {
    textWidget->setHeight(height);
  }

  if (maxLinesSpecified)
  {
    textWidget->setHeightInLines(maxLines);
  }

  textWidget->setTextColor(color);
  textWidget->setHorizontalAlignment(align);
  textWidget->setVerticalAlignment(valign);
  textWidget->setJustifyText(justify);
  textWidget->setUseEllipses(ellipsize);
  textWidget->setSingleLineMode(singleLineMode);

  if(args.Length() > 0)
  {
    ScriptObject options = args[0];

    if(options.has("textShadow"))
    {
      setShadow(textWidget, options.get("textShadow"));
    }
  }

  return textWidget;
}


ScriptObject TextWidgetBridge::getAlignment(TextWidget* self)
{
  return serializeLayoutAlignment(self->getHorizontalAlignment());
}

void TextWidgetBridge::setAlignment(TextWidget* self, ScriptObject value)
{
  self->setHorizontalAlignment( deserializeLayoutAlignment(value.asString(), Left) );
}

ScriptObject TextWidgetBridge::getVAlignment(TextWidget* self)
{
  return serializeVerticalAlignment(self->getVerticalAlignment());
}

void TextWidgetBridge::setVAlignment(TextWidget* self, ScriptObject value)
{
  self->setVerticalAlignment( deserializeVerticalAlignment(value.asString()) );
}

VerticalLayoutAlignment TextWidgetBridge::deserializeVerticalAlignment(std::string stringValign)
{
  if(compareStrChar(stringValign, "center"))
  {
    return VerticalLayoutAlignment::Middle;
  }
  else if(compareStrChar(stringValign, "bottom"))
  {
    return VerticalLayoutAlignment::Bottom;
  }
  else
  {
    return VerticalLayoutAlignment::Top;
  }
}

std::string TextWidgetBridge::serializeVerticalAlignment(VerticalLayoutAlignment valign)
{
  switch(valign)
  {
  case VerticalLayoutAlignment::Middle:
    return "center";
  case VerticalLayoutAlignment::Bottom:
    return "bottom";
  default:
    return "top";
  }
}

void TextWidgetBridge::setTextColor(TextWidget* self, ScriptObject val)
{
  Color color = ScriptToColor(val);
  self->setTextColor(color);
}

ScriptObject TextWidgetBridge::getTextColor(TextWidget* self)
{
  const std::string name = "textColor";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject color = getColor<TextWidget, &TextWidget::getTextColor, &TextWidget::setTextColor>(self);
  addPropertyProxy(self, name, color);
  return color;
}

void TextWidgetBridge::setShadow(TextWidget* self, ScriptObject val)
{
  if(val.isNull())
  {
    self->setHasShadow(false);
  }
  else
  {
    float xOffset = val["xOffset"].asNumber();
    float yOffset = val["yOffset"].asNumber();

    if(val.has("color"))
    {
      Color color = ScriptToColor(val["color"]);
      self->setShadowColor(color);
    }

    self->setShadowXOffset(xOffset);
    self->setShadowYOffset(yOffset);
    self->setHasShadow(true);
  }
}

ScriptObject TextWidgetBridge::getShadow(TextWidget* self)
{
  const std::string name = "textShadow";

  if(self->getHasShadow())
  {
    if (hasPropertyProxy(self, name))
    {
      return getPropertyProxy(self, name);
    }

    ScriptObject shadow;

    shadow.SetAccessor<TextWidget,
                       numberGetter<TextWidget, float, &TextWidget::getShadowXOffset>,
                       numberSetter<TextWidget, float, &TextWidget::setShadowXOffset> >("xOffset",self);
    shadow.SetAccessor<TextWidget,
                       numberGetter<TextWidget, float, &TextWidget::getShadowYOffset>,
                       numberSetter<TextWidget, float, &TextWidget::setShadowYOffset> >("yOffset",self);
    shadow.SetAccessor<TextWidget, getColor<TextWidget, &TextWidget::getShadowColor,
                       &TextWidget::setShadowColor>, setColor<TextWidget, &TextWidget::setShadowColor> >("color", self);
    addPropertyProxy(self, name, shadow);
    return shadow;
  }
  else
  {
    return ScriptObject::Null();
  }
}


ScriptObject TextWidgetBridge::charIndexAtCoordinate(TextWidget* self, const ScriptArray& args)
{
  Vector2 coords = ScriptToVector2(args[0]);
  int charIndex = self->charIndexAtCoordinate(coords);
  return ScriptObject(charIndex);
}

ScriptObject TextWidgetBridge::coordinateAtCharIndex(TextWidget* self, const ScriptArray& args)
{
  int charIndex = args[0].asNumber();
  Vector2 result = self->coordinateAtCharIndex(charIndex);
  return Vector2ToScript(result);
}

ScriptObject TextWidgetBridge::getHeightInLines(TextWidget* self, const ScriptArray& args)
{
  return ScriptObject(self->getHeightInLines());
}

ScriptObject TextWidgetBridge::setHeightInLines(TextWidget* self, const ScriptArray& args)
{
  self->setHeightInLines(args[0].asNumber());
  return ScriptObject();
}

ScriptObject TextWidgetBridge::getLineHeight(TextWidget* self, const ScriptArray& args)
{
  return ScriptObject(self->getLineHeight());
}

ScriptObject TextWidgetBridge::getTextOverflow(TextWidget* self, const ScriptArray& args)
{
  return ScriptObject(self->getTextOverflow());
}

ScriptObject TextWidgetBridge::getTextOverflowLines(TextWidget* self, const ScriptArray& args)
{
  return ScriptObject(self->getTextOverflowLines());
}

ScriptObject TextWidgetBridge::insertText(TextWidget* self, const ScriptArray& args)
{
  self->insertText(args[0].asString(), args[1].asNumber());
  return ScriptObject();
}

ScriptObject TextWidgetBridge::removeText(TextWidget* self, const ScriptArray& args)
{
  if (args.has(1))
  {
    self->removeText(args[0].asNumber(), args[1].asNumber());
  }
  else
  {
    self->removeText(args[0].asNumber());
  }

  return ScriptObject();
}

ScriptObject TextWidgetBridge::isRightToLeft(volt::graphics::TextWidget* self, const ScriptArray& args)
{
  return ScriptObject(self->isRightToLeft());
}

} /* namespace Bridge */
