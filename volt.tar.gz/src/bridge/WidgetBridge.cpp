/*
 * WidgetBridge.cpp
 *
 *  Created on: May 10, 2013
 *      Author: reza
 */

#include "WidgetBridge.h"
#include "PageCurlEffect.h"
#include "AnimationBridge.h"
#include "ColorizeEffect.h"
#include "logger.h"

#include <algorithm>

using namespace Bridge;
using namespace volt::graphics;

std::unordered_map<Widget*, WidgetBridgeData> WidgetBridge::perWidgetData;

ScriptObject WidgetBridge::ColorToScript(const Color& color)
{
  ScriptObject retval = ScriptObject();
  retval.set("r", ScriptObject((double)color.r));
  retval.set("g", ScriptObject((double)color.g));
  retval.set("b", ScriptObject((double)color.b));
  retval.set("a", ScriptObject((double)color.a));

  return retval;
}

Color WidgetBridge::ScriptToColor(const ScriptObject& val)
{
  Color retval;
  ScriptObject r,g,b,a;

  if( val.has("r") || val.has("g") || val.has("b") || val.has("a") )
  {
    retval.r = (val.has("r")) ? val["r"].asNumber() : 0;
    retval.g = (val.has("g")) ? val["g"].asNumber() : 0;
    retval.b = (val.has("b")) ? val["b"].asNumber() : 0;
    retval.a = (val.has("a")) ? val["a"].asNumber() : 255;
    return retval;
  }

  throw VoltJsRuntimeException("Bad Type: Color object expected for color value.");
}

ScriptObject WidgetBridge::CornerToScript(const Corner& corner)
{
  ScriptObject retval = ScriptObject();
  retval.set("arcStep", ScriptObject((double)corner.arcStep));
  retval.set("radius", ScriptObject((double)corner.radius));
  return retval;
}

Corner WidgetBridge::ScriptToCorner(const ScriptObject& val)
{
  Corner retval;
  ScriptObject r,g,b,a;

  if( val.has("arcStep") || val.has("radius"))
  {
    retval.arcStep = (val.has("arcStep")) ? val["arcStep"].asNumber() : 0;
    retval.radius = (val.has("radius")) ? val["radius"].asNumber() : 0;
    return retval;
  }

  throw VoltJsRuntimeException("Bad Type: Corner object expected for corner value.");
}

ScriptObject WidgetBridge::Vector2ToScript(Vector2 scale)
{
  ScriptObject scriptScale;
  scriptScale.set("x", scale.x);
  scriptScale.set("y", scale.y);
  return scriptScale;
}

Vector2 WidgetBridge::ScriptToVector2(const ScriptObject& scriptScale)
{
  if (scriptScale.isNumber()) //allow scalers, and just auto convert to a uniform vector2
  {
    float num = scriptScale.asNumber();
    return Vector2(num, num);
  }
  else
  {
    float x = scriptScale["x"].asNumber();
    float y = scriptScale["y"].asNumber();
    return Vector2(x, y);
  }
}

ScriptObject WidgetBridge::Vector3ToScript(Vector3 scale)
{
  ScriptObject scriptScale;
  scriptScale.set("x", scale.x);
  scriptScale.set("y", scale.y);
  scriptScale.set("z", scale.z);
  return scriptScale;
}

Vector3 WidgetBridge::ScriptToVector3(const ScriptObject& scriptScale)
{
  //not excepting scalers here as in ScriptToVector2 because the only use case is rotation where it doesn't make sense

  float x = scriptScale["x"].asNumber();
  float y = scriptScale["y"].asNumber();
  float z = scriptScale["z"].asNumber();
  return Vector3(x, y, z);
}

void WidgetBridge::mapScriptInterface(ScriptContext& context)
{
  //Direct bindings:
  context.bindBoolean<Widget, &Widget::getDepthTestEnabled, &Widget::setDepthTestEnabled>("drawWithDepth");
  context.bindBoolean<Widget, &Widget::getBackfaceCullingEnabled, &Widget::setBackfaceCullingEnabled>("backfaceCulling");
  context.bindNumber<Widget, float, &Widget::getX, &Widget::setX>("x");
  context.bindNumber<Widget, float, &Widget::getY, &Widget::setY>("y");
  context.bindNumber<Widget, float, &Widget::getWidth, &Widget::setWidth>("width");
  context.bindNumber<Widget, float, &Widget::getHeight, &Widget::setHeight>("height");
  context.bindNumber<Widget, float, &Widget::getDepth, &Widget::setDepth>("depth");
  context.bindNumber<Widget, int, &Widget::getOpacity, &Widget::setOpacity>("opacity");
  context.bindNativeReference<Widget, Widget, &Widget::getParent, &Widget::setParent>("parent");
  context.bindString<Widget, &Widget::getID, &Widget::setID>("id");
  context.bindBoolean<Widget, &Widget::getCropOverflow, &Widget::setCropOverflow>("cropOverflow");
  context.bindBoolean<Widget, &Widget::getAutoSortChildrenByDepth, &Widget::setAutoSortChildrenByDepth>("autoSortChildrenByDepth");
#ifdef EXPERIMENTAL_BUILD
  context.bindBoolean<Widget, &Widget::getBlur, &Widget::setBlur>("blur");
  context.bindNumber<Widget, float, &Widget::getBrightness, &Widget::setBrightness>("brightness");
  context.bindNumber<Widget, float, &Widget::getContrast, &Widget::setContrast>("contrast");
  context.bindNumber<Widget, double, &Widget::getDesaturateFactor, &Widget::setDesaturateFactor>("desaturate");
#endif

  //Properties that need special handling
  context.capturePropertyAccess<Widget, &getPropertyColor, &setColor<Widget, &Widget::setColor> >("color");
  context.capturePropertyAccess<Widget, &getScale, &setScale>("scale");
  context.capturePropertyAccess<Widget, &getPivot, &setPivot>("pivot");
  context.capturePropertyAccess<Widget, &getOrigin, &setOrigin>("origin");
  context.capturePropertyAccess<Widget, &getAnchor, &setAnchor>("anchor");
  context.capturePropertyAccess<Widget, &getRotation, &setRotation>("rotation");
  context.capturePropertyAccess<Widget, &getBorder, &setBorder>("border");
  context.capturePropertyAccess<Widget, &getRoundedCorners, &setRoundedCorners>("roundedCorners");
  context.capturePropertyAccess<Widget, &getGradient, &setGradient>("gradient");
  context.capturePropertyAccess<Widget, &getMinScalingFilter, &setMinScalingFilter>("minScalingFilter");
  context.capturePropertyAccess<Widget, &getMaxScalingFilter, &setMaxScalingFilter>("maxScalingFilter");
  context.capturePropertyAccess<Widget, &getShadow, &setShadow>("shadow");
  context.capturePropertyAccess<Widget, &getCutThrough, &setCutThrough>("cutThrough");
#ifdef EXPERIMENTAL_BUILD
  context.capturePropertyAccess<Widget, &getPropertyTint, &setTint>("tint");
  context.capturePropertyAccess<Widget, &getCurl, &setCurl>("curl");
#endif

  //Function calls
  context.captureMethodCall<Widget, &show>("show");
  context.captureMethodCall<Widget, &hide>("hide");
  context.captureMethodCall<Widget, &getAbsolutePosition>("getAbsolutePosition");
  context.captureMethodCall<Widget, &getAbsoluteSize>("getAbsoluteSize");
  context.captureMethodCall<Widget, &getPositionOnScreen>("getPositionOnScreen");
  context.captureMethodCall<Widget, &getSizeOnScreen>("getSizeOnScreen");
  context.captureMethodCall<Widget, &getChildCount>("getChildCount");
  context.captureMethodCall<Widget, &addChild>("addChild");
  context.captureMethodCall<Widget, &removeChild>("removeChild");
  context.captureMethodCall<Widget, &getChild>("getChild");
  context.captureMethodCall<Widget, &getAncestor>("getAncestor");
  context.captureMethodCall<Widget, &getDescendent>("getDescendant");
  context.captureMethodCall<Widget, &getDescendent>("getDescendent"); //TODO: Deprecate this, -ant is correct spelling
  context.captureMethodCall<Widget, &handleDestroy>("destroy");
  context.captureMethodCall<Widget, &handleDestroyChildren>("destroyChildren");
  context.captureMethodCall<Widget, &getTransformedDepth>("getTransformedDepth");

  //Event handling functions
  context.captureMethodCall<Widget, &addEventListener>("addEventListener");
  context.captureMethodCall<Widget, &removeEventListener>("removeEventListener");
  context.captureMethodCall<Widget, &dispatchEvent>("dispatchEvent");

  //Refer to the bridging logic in AnimationBridge.
  context.captureMethodCall<Widget, &AnimationBridge::parseAnimateFunctionParams>("animate");
  context.captureMethodCall<Widget, &AnimationBridge::parseCancelAnimateFunction>("cancelAnimation");
  context.captureMethodCall<Widget, &reorderChildrenByDepth>("reorderChildrenByDepth");

  context.captureMethodCall<Widget, &hasKeyFocus>("hasKeyFocus");
}

Widget* WidgetBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
  if(width == -1)
  {
    width = 0;
  }

  if(height == -1)
  {
    height = 0;
  }

  return new Widget( x, y, width, height, parent );
}

void* WidgetBridge::constructFromScript(const ScriptArray& args)
{
#ifdef EXPERIMENTAL_BUILD
  float brightness = 0.0;
  float contrast = 0.0;
  bool applyBrightnessContrast = false;
  double desaturation = 0.0;
  bool applyDesaturation = false;
  bool blur = false;
  bool applyTint = false;
  Color tint = Color(255,255,255,255);
#endif

  double x, y, width, height, depth;
  x = y = 0;
  depth = 0.03; //give small initial depth so children render above parents with depth test on
  width = height = -1;
  bool depthTest = false;
  bool backfaceCulling = false;
  bool hasColor = false;
  int opacity = 255;
  Color color = Color(255,255,255,255);
  Color tlColor, trColor, blColor, brColor;
  std::string name = "";
  Widget* parent = nullptr;
  Vector2 origin(0, 0), pivot(0.5, 0.5), anchor(0, 0), scale(1, 1);
  Vector3 rotation(0,0,0);
  bool cropOverflow = false;
  bool autoSortChildrenByDepth = false;
  ScalingFilter minScalingFilter = FILTER_LINEAR;
  ScalingFilter maxScalingFilter = FILTER_LINEAR;

  ScriptObject options;
  int argsLen = args.Length();

  if(argsLen > 0)
  {
    options = args[0];

    //Get available arguments, either by options arguments or ordered, but not both.
    if(options.has("x") || options.has("y") || options.has("width") || options.has("height") || options.has("id") || options.has("color") ||
       options.has("parent") || options.has("pivot") || options.has("origin") || options.has("anchor") || options.has("cropOverflow") ||
#ifdef EXPERIMENTAL_BUILD
       options.has("tint") || options.has("blur") || options.has("brightness") || options.has("contrast") || options.has("desaturate") ||
#endif
       options.has("drawWithDepth") || options.has("rotation") || options.has("scale") || options.has("opacity") ||
       options.has("backfaceCulling") || options.has("autoSortChildrenByDepth"))
    {
      //options arguments
      if(options.has("x"))
      {
        x = options.get("x").asNumber();
      }

      if(options.has("y"))
      {
        y = options.get("y").asNumber();
      }

      if(options.has("width"))
      {
        width = options.get("width").asNumber();
      }

      if(options.has("height"))
      {
        height = options.get("height").asNumber();
      }

      if(options.has("id"))
      {
        name =  options.get("id").asString();
      }

      if(options.has("color"))
      {
        color = ScriptToColor(options.get("color"));
        hasColor = true;
      }

      if(options.has("opacity"))
      {
        opacity = options.get("opacity").asNumber();
      }

      if(options.has("depth"))
      {
        depth = options.get("depth").asNumber();
      }

      if(options.has("parent"))
      {
        parent = unwrapNativeObject<Widget>(options.get("parent"));
      }

      if(options.has("rotation"))
      {
        rotation = ScriptToVector3(options.get("rotation"));
      }

      if(options.has("scale"))
      {
        scale = ScriptToVector2(options.get("scale"));
      }

      if(options.has("pivot"))
      {
        pivot = ScriptToVector2(options.get("pivot"));
      }

      if(options.has("origin"))
      {
        origin = ScriptToVector2(options.get("origin"));
      }

      if(options.has("anchor"))
      {
        anchor = ScriptToVector2(options.get("anchor"));
      }

      if(options.has("cropOverflow"))
      {
        cropOverflow = options.get("cropOverflow").asBool();
      }

      if(options.has("minScalingFilter"))
        minScalingFilter = deserializeScalingFilter(options.get("minScalingFilter").asString(),
                           minScalingFilter);

      if(options.has("maxScalingFilter"))
        maxScalingFilter = deserializeScalingFilter(options.get("maxScalingFilter").asString(),
                           maxScalingFilter);

#ifdef EXPERIMENTAL_BUILD

      if(options.has("tint"))
      {
        applyTint = true;
        tint = ScriptToColor(options.get("tint"));
      }

      if(options.has("blur"))
      {
        blur = options.get("blur").asBool();
      }

      if(options.has("brightness"))
      {
        applyBrightnessContrast = true;
        brightness = options.get("brightness").asNumber();
      }

      if(options.has("contrast"))
      {
        applyBrightnessContrast = true;
        contrast = options.get("contrast").asNumber();
      }

      if(options.has("desaturate"))
      {
        applyDesaturation = true;
        desaturation = options.get("desaturate").asNumber();
      }

#endif

      if(options.has("drawWithDepth"))
      {
        depthTest = options.get("drawWithDepth").asBool();
      }

      if(options.has("backfaceCulling"))
      {
        backfaceCulling = options.get("backfaceCulling").asBool();
      }

      if(options.has("autoSortChildrenByDepth"))
      {
        autoSortChildrenByDepth = options.get("autoSortChildrenByDepth").asBool();
      }
    }
    else //regular arguments
    {
      if(args.has(0) && args[0].isNumber() )
      {
        x = args[0].asNumber();
      }

      if(args.has(1) && args[1].isNumber())
      {
        y = args[1].asNumber();
      }

      if(args.has(2) && args[2].isNumber())
      {
        width = args[2].asNumber();
      }

      if(args.has(3) && args[3].isNumber())
      {
        height = args[3].asNumber();
      }

      if(args.has(4))
      {
        color = ScriptToColor(args[4]);
      }
    }
  }

  //constructWidget can be overridden in subtypes of WidgetBridge that need to construct different subtypes of Widget.
  Widget* cWidget = constructWidget( x, y, width, height, parent, args );
  cWidget->setColor( hasColor ? color : getDefaultColor() );
  cWidget->setOpacity(opacity);
  cWidget->setID(name);
  cWidget->setPivot(pivot);
  cWidget->setDepth(depth);
  cWidget->setRotation(rotation);
  cWidget->setScale(scale);
  cWidget->setOrigin(origin);
  cWidget->setAnchor(anchor);
  cWidget->setCropOverflow(cropOverflow);
  cWidget->setMinScalingFilter(minScalingFilter);
  cWidget->setMaxScalingFilter(maxScalingFilter);

#ifdef EXPERIMENTAL_BUILD
  cWidget->setBlur(blur);

  if(applyTint)
  {
    cWidget->setTint(tint);
  }

  if(applyBrightnessContrast)
  {
    cWidget->setBrightness(brightness);
    cWidget->setContrast(contrast);
  }

  if(applyDesaturation)
  {
    cWidget->setDesaturateFactor(desaturation);
  }

#endif

  cWidget->setDepthTestEnabled(depthTest);
  cWidget->setBackfaceCullingEnabled(backfaceCulling);
  cWidget->setAutoSortChildrenByDepth(autoSortChildrenByDepth);

  if(argsLen)
  {
    if(options.has("border"))
    {
      setBorder(cWidget, options.get("border"));
    }

    if(options.has("roundedCorners"))
    {
      setRoundedCorners(cWidget, options.get("roundedCorners"));
    }

    if(options.has("gradient"))
    {
      setGradient(cWidget, options.get("gradient"));
    }

    if(options.has("shadow"))
    {
      setShadow(cWidget, options.get("shadow"));
    }

#ifdef EXPERIMENTAL_BUILD

    if(options.has("curl"))
    {
      setCurl(cWidget, options.get("curl"));
    }

#endif

    if(options.has("cutThrough")) // Set cut through at the end since it needs several widget properties to already be set.
    {
      setCutThrough(cWidget, options.get("cutThrough"));
    }
  }


  //Add an entry in the widget data map
  perWidgetData[cWidget] = WidgetBridgeData();

  //Register for destruction event. Necessary for proper cleanup of JavaScript objects
  WidgetDestructionCallback destructionCallback = std::bind( onDestruction, this, cWidget);
  cWidget->registerDestructionEvent(destructionCallback);

  return cWidget;
}

void WidgetBridge::onDestruction(WidgetBridge* bridge, Widget* destroyedWidget)
{
  releaseForGarbageCollection(bridge, destroyedWidget);

  //Clear the data we kept for this widget. Without doing this, another widget might be allocated with the same address, leading
  //to a crash, or at least we would leak memory
  perWidgetData.erase( destroyedWidget );
}

ScriptObject WidgetBridge::handleDestroy(Widget* self, const ScriptArray& args)
{
  delete self;
  return ScriptObject();
}

ScriptObject WidgetBridge::handleDestroyChildren(Widget* self, const ScriptArray& args)
{
  self->destroyChildren();
  return ScriptObject();
}



//Function calls:

ScriptObject WidgetBridge::show(Widget* self, const ScriptArray& args)
{
  self->show();
  return ScriptObject();
}

ScriptObject WidgetBridge::hide(Widget* self, const ScriptArray& args)
{
  self->hide();
  return ScriptObject();
}


/*
 * Multi-dimensional getters and setters. These all follow the pattern of the getter object
 * returning another fake JavaScript object that has accessors set on it for individual components.
 * These individual components then have getters and setters that call the widget.
 */

//Scale getters and helpers:

ScriptObject scaleXGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getScale().x);
}

void scaleXSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setScale(Vector2(value.asNumber(), typedSelf->getScale().y));
}

ScriptObject scaleYGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getScale().y);
}

void scaleYSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setScale(Vector2(typedSelf->getScale().x, value.asNumber()));
}

ScriptObject Bridge::WidgetBridge::getScale(Widget* self)
{

  const std::string name = "scale";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject scale = ScriptObject();
  scale.SetAccessor<Widget, scaleXGetter, scaleXSetter>("x", self);
  scale.SetAccessor<Widget, scaleYGetter, scaleYSetter>("y", self);

  addPropertyProxy(self, name, scale);
  return scale;
}

void Bridge::WidgetBridge::setScale(Widget* self, ScriptObject scriptScale)
{
  self->setScale(ScriptToVector2(scriptScale));
}

//Pivot getter and helpers

ScriptObject pivotXGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getPivot().x);
}

void pivotXSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setPivot(Vector2(value.asNumber(), typedSelf->getPivot().y));
}

ScriptObject pivotYGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getPivot().y);
}

void pivotYSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setPivot(Vector2(typedSelf->getPivot().x, value.asNumber()));
}


ScriptObject Bridge::WidgetBridge::getPivot(Widget* self)
{
  const std::string name = "pivot";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject pivot = ScriptObject();
  pivot.SetAccessor<Widget, pivotXGetter, pivotXSetter>("x", self);
  pivot.SetAccessor<Widget, pivotYGetter, pivotYSetter>("y", self);

  addPropertyProxy(self, name, pivot);
  return pivot;
}

void Bridge::WidgetBridge::setPivot(Widget* self, ScriptObject scriptObject)
{
  self->setPivot(ScriptToVector2(scriptObject));
}


//Origin getters and helpers:

ScriptObject originXGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getOrigin().x);
}

void originXSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setOrigin(Vector2(value.asNumber(), typedSelf->getOrigin().y));
}

ScriptObject originYGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getOrigin().y);
}

void originYSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setOrigin(Vector2(typedSelf->getOrigin().x, value.asNumber()));
}


ScriptObject Bridge::WidgetBridge::getOrigin(Widget* self)
{
  const std::string name = "origin";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject origin = ScriptObject();
  origin.SetAccessor<Widget, originXGetter, originXSetter>("x", self);
  origin.SetAccessor<Widget, originYGetter, originYSetter>("y", self);

  addPropertyProxy(self, name, origin);
  return origin;
}

void Bridge::WidgetBridge::setOrigin(Widget* self, ScriptObject scriptObject)
{
  self->setOrigin(ScriptToVector2(scriptObject));
}

//Anchor getters and helpers:

ScriptObject anchorXGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getAnchor().x);
}

void anchorXSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setAnchor(Vector2(value.asNumber(), typedSelf->getAnchor().y));
}

ScriptObject anchorYGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getAnchor().y);
}

void anchorYSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  typedSelf->setAnchor(Vector2(typedSelf->getAnchor().x, value.asNumber()));
}


ScriptObject Bridge::WidgetBridge::getAnchor(Widget* self)
{
  const std::string name = "anchor";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject anchor = ScriptObject();
  anchor.SetAccessor<Widget, anchorXGetter, anchorXSetter>("x", self);
  anchor.SetAccessor<Widget, anchorYGetter, anchorYSetter>("y", self);

  addPropertyProxy(self, name, anchor);
  return anchor;
}


void Bridge::WidgetBridge::setAnchor(Widget* self, ScriptObject scriptObject)
{
  self->setAnchor(ScriptToVector2(scriptObject));
}

//Rotation and helpers:

ScriptObject rotationXGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getRotation().x);
}

void rotationXSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  Vector3 rotation = typedSelf->getRotation();
  typedSelf->setRotation( Vector3(value.asNumber(), rotation.y, rotation.z) );
}

ScriptObject rotationYGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getRotation().y);
}

void rotationYSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  Vector3 rotation = typedSelf->getRotation();
  typedSelf->setRotation( Vector3(rotation.x, value.asNumber(), rotation.z) );
}

ScriptObject rotationZGetter(Widget* self)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  return ScriptObject(typedSelf->getRotation().z);
}

void rotationZSetter(Widget* self, ScriptObject value)
{
  Widget* typedSelf = reinterpret_cast<Widget*>(self);
  Vector3 rotation = typedSelf->getRotation();
  typedSelf->setRotation( Vector3(rotation.x, rotation.y, value.asNumber()) );
}


ScriptObject Bridge::WidgetBridge::getRotation(Widget* self)
{
  const std::string name = "rotation";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject rotation = ScriptObject();
  rotation.SetAccessor<Widget, rotationXGetter, rotationXSetter>("x",self);
  rotation.SetAccessor<Widget, rotationYGetter, rotationYSetter>("y",self);
  rotation.SetAccessor<Widget, rotationZGetter, rotationZSetter>("z",self);

  addPropertyProxy(self, name, rotation);
  return rotation;
}

void Bridge::WidgetBridge::setRotation(Widget* self,
                                       ScriptObject scriptObject)
{
  self->setRotation(ScriptToVector3(scriptObject));
}


/* Border stuff */
ScriptObject WidgetBridge::getBorder(Widget* self)
{
  const std::string name = "border";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject border = ScriptObject();
  border.SetAccessor<Widget, getColor<Widget, &Widget::getBorderColor, &Widget::setBorderColor>,
                     setColor<Widget, &Widget::setBorderColor> >("color", self);
  border.SetAccessor<Widget,
                     numberGetter<Widget, float, &Widget::getBorderWidth>,
                     numberSetter<Widget, float, &Widget::setBorderWidth> >("width", self);

  addPropertyProxy(self, name, border);
  return border;
}

void WidgetBridge::setBorder(Widget* self, ScriptObject value)
{
  if(value.isNull())
  {
    self->setBorderColor(Color::Transparent());
  }
  else
  {
    float width =  value["width"].asNumber();
    Color color = ScriptToColor(value["color"]);
    self->setBorderColor(color);
    self->setBorderWidth(width);
  }
}

/* Rounded Corners stuff */
ScriptObject WidgetBridge::getRoundedCorners(Widget* self)
{
  const std::string name = "corners";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject roundedCorners = ScriptObject();

  roundedCorners.SetAccessor<Widget,
                             numberGetter<Widget, float, &Widget::getRCornerRadius>,
                             numberSetter<Widget, float, &Widget::setRCornerRadius> >("radius",self);

  roundedCorners.SetAccessor<Widget,
                             numberGetter<Widget, float, &Widget::getRCornerArcStep>,
                             numberSetter<Widget, float, &Widget::setRCornerArcStep> >("arcStep", self);

  roundedCorners.SetAccessor<Widget,
                             getCorner<Widget, &Widget::getRCornerBLeft, &Widget::setRCornerBLeft>,
                             setCorner<Widget, &Widget::setRCornerBLeft> >("bLeft", self);

  roundedCorners.SetAccessor<Widget,
                             getCorner<Widget, &Widget::getRCornerBRight, &Widget::setRCornerBRight>,
                             setCorner<Widget, &Widget::setRCornerBRight> >("bRight", self);

  roundedCorners.SetAccessor<Widget,
                             getCorner<Widget, &Widget::getRCornerTLeft, &Widget::setRCornerTLeft>,
                             setCorner<Widget, &Widget::setRCornerTLeft> >("tLeft", self);

  roundedCorners.SetAccessor<Widget,
                             getCorner<Widget, &Widget::getRCornerTRight, &Widget::setRCornerTRight>,
                             setCorner<Widget, &Widget::setRCornerTRight> >("tRight", self);

  addPropertyProxy(self, name, roundedCorners);
  return roundedCorners;
}

void WidgetBridge::setRoundedCorners(Widget* self, ScriptObject value)
{
  if(value.isNull())
  {
    self->setRoundedCorners(false);
  }
  else
  {
    // everything is optional..
    if(value.has("radius"))
    {
      float radius = value["radius"].asNumber();
      self->setRCornerRadius(radius);
      self->setRoundedCorners(true);
    }

    if(value.has("arcStep"))
    {
      float arcStep = value["arcStep"].asNumber();
      self->setRCornerArcStep(arcStep);
      self->setRoundedCorners(true);
    }

    if(value.has("bLeft"))
    {
      self->setRCornerBLeft(ScriptToCorner(value["bLeft"]));
      self->setRoundedCorners(true);
    }

    if(value.has("bRight"))
    {
      self->setRCornerBRight(ScriptToCorner(value["bRight"]));
      self->setRoundedCorners(true);
    }

    if(value.has("tLeft"))
    {
      self->setRCornerTLeft(ScriptToCorner(value["tLeft"]));
      self->setRoundedCorners(true);
    }

    if(value.has("tRight"))
    {
      self->setRCornerTRight(ScriptToCorner(value["tRight"]));
      self->setRoundedCorners(true);
    }
  }
}


/* Gradient stuff */

ScriptObject WidgetBridge::getGradient(Widget* self)
{
  const std::string name = "gradient";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject gradient;

  if(self->getGradientFill())
  {
    gradient.SetAccessor<Widget, getColor<Widget, &Widget::getGradTlColor,
                         &Widget::setGradTlColor>, setColor<Widget, &Widget::setGradTlColor> >("tlColor", self);
    gradient.SetAccessor<Widget, getColor<Widget, &Widget::getGradTrColor,
                         &Widget::setGradTrColor>, setColor<Widget, &Widget::setGradTrColor> >("trColor", self);
    gradient.SetAccessor<Widget, getColor<Widget, &Widget::getGradBlColor,
                         &Widget::setGradBlColor>, setColor<Widget, &Widget::setGradBlColor> >("blColor", self);
    gradient.SetAccessor<Widget, getColor<Widget, &Widget::getGradBrColor,
                         &Widget::setGradBrColor>, setColor<Widget, &Widget::setGradBrColor> >("brColor", self);
  }

  addPropertyProxy(self, name, gradient);
  return gradient;
}

void WidgetBridge::setGradient(Widget* self, ScriptObject value)
{
  if(value.isNull())
  {
    self->setGradientFill(false);
  }
  else
  {
    self->setGradTlColor( ScriptToColor( value["tlColor"] ) );
    self->setGradTrColor( ScriptToColor( value["trColor"] ) );
    self->setGradBlColor( ScriptToColor( value["blColor"] ) );
    self->setGradBrColor( ScriptToColor( value["brColor"] ) );
    self->setGradientFill(true);
  }
}

// Scaling Filter

ScriptObject WidgetBridge::getMinScalingFilter(Widget *self)
{
  return serializeScalingFilter(self->getMinScalingFilter());
}


void WidgetBridge::setMinScalingFilter(Widget *self, ScriptObject value)
{
  self->setMinScalingFilter(deserializeScalingFilter(value.asString(), FILTER_LINEAR));
}


ScriptObject WidgetBridge::getMaxScalingFilter(Widget *self)
{
  return serializeScalingFilter(self->getMaxScalingFilter());
}


void WidgetBridge::setMaxScalingFilter(Widget* self, ScriptObject value)
{
  self->setMaxScalingFilter( deserializeScalingFilter(value.asString(), FILTER_LINEAR) );
}

ScriptObject WidgetBridge::getShadow(Widget* self)
{
  const std::string name = "shadow";

  if(self->getShadow())
  {
    if (hasPropertyProxy(self, name))
    {
      return getPropertyProxy(self, name);
    }

    ScriptObject shadow;

    shadow.SetAccessor<Widget,
                       numberGetter<Widget, float, &Widget::getShadowXOffset>,
                       numberSetter<Widget, float, &Widget::setShadowXOffset> >("xOffset",self);
    shadow.SetAccessor<Widget,
                       numberGetter<Widget, float, &Widget::getShadowYOffset>,
                       numberSetter<Widget, float, &Widget::setShadowYOffset> >("yOffset",self);
    shadow.SetAccessor<Widget,
                       numberGetter<Widget, int, &Widget::getShadowBlur>,
                       numberSetter<Widget, int, &Widget::setShadowBlur> >("blur",self);
    shadow.SetAccessor<Widget,
                       numberGetter<Widget, int, &Widget::getShadowSpread>,
                       numberSetter<Widget, int, &Widget::setShadowSpread> >("spread",self);
    shadow.SetAccessor<Widget, getColor<Widget, &Widget::getShadowColor,
                       &Widget::setShadowColor>, setColor<Widget, &Widget::setShadowColor> >("color", self);

    addPropertyProxy(self, name, shadow);
    return shadow;
  }
  else
  {
    return ScriptObject::Null();
  }
}

void WidgetBridge::setShadow(Widget* self, ScriptObject value)
{
  if(value.isNull())
  {
    self->setShadow(false);
  }
  else
  {
    // required parameters
    float xOffset = value["xOffset"].asNumber();
    float yOffset = value["yOffset"].asNumber();

    int blur = 0;
    int spread = 0;
    Color color(0,0,0,255);

    // optional parameters
    if(value.has("blur"))
    {
      blur = value["blur"].asNumber();
    }

    if(value.has("spread"))
    {
      spread = value["spread"].asNumber();
    }

    if(value.has("color"))
    {
      color = ScriptToColor(value["color"]);
    }

    self->setShadow(true, xOffset, yOffset, blur, spread, color);
  }
}

#ifdef EXPERIMENTAL_BUILD
void WidgetBridge::setTint(Widget* self, ScriptObject value)
{
  if(value.isNull())
  {
    self->removeEffect(ColorizeEffect::EFFECT_NAME);
  }
  else
  {
    self->setTint(ScriptToColor(value));
  }
}

ScriptObject WidgetBridge::getCurl(Widget* self)
{
  const std::string name = "curl";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject curl;
  curl.SetAccessor<Widget,
                   numberGetter<Widget, double, &Widget::getPageCurlPeriod>,
                   numberSetter<Widget, double, &Widget::setPageCurlPeriod> >("period", self);
  curl.SetAccessor<Widget,
                   numberGetter<Widget, double, &Widget::getPageCurlAngle>,
                   numberSetter<Widget, double, &Widget::setPageCurlAngle> >("angle", self);
  curl.SetAccessor<Widget,
                   numberGetter<Widget, float, &Widget::getPageCurlRadius>,
                   numberSetter<Widget, float, &Widget::setPageCurlRadius> >("radius", self);

  addPropertyProxy(self, name, curl);
  return curl;
}


void WidgetBridge::setCurl(Widget* self, ScriptObject value)
{
  if(value.isNull())
  {
    self->removeEffect(PageCurlEffect::EFFECT_NAME);
  }
  else
  {
    double period = value["period"].asNumber();
    double angle  =  value["angle"].asNumber();
    float radius  =  value["radius"].asNumber();
    self->setEffect(new PageCurlEffect(period, angle, radius), PageCurlEffect::EFFECT_NAME);
  }
}


ScriptObject WidgetBridge::getPropertyTint(Widget* self)
{
  const std::string name = "tint";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject tint = getColor<Widget, &Widget::getTint, &Widget::setTint>(self);
  addPropertyProxy(self, name, tint);
  return tint;
}
#endif


ScriptObject WidgetBridge::getCutThrough(Widget* self)
{
  const std::string name = "cutThrough";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  Widget* cutThrough = self->getCutThrough();

  if(cutThrough)
  {
    return wrapExistingNativeObject(cutThrough);
  }

  return ScriptObject();
}

void WidgetBridge::setCutThrough(Widget* self, ScriptObject value)
{
  Widget* cutThrough = nullptr;

  if(!value.isNull())
  {
    cutThrough = unwrapNativeObject<Widget>(value);

    if(!cutThrough)
    {
      throw VoltJsRuntimeException("Non-widget specified as Widget.cutThrough property.");
    }
  }

  self->setCutThrough(cutThrough);
}

ScriptObject WidgetBridge::getPropertyColor(Widget* self)
{
  const std::string name = "color";

  if (hasPropertyProxy(self, name))
  {
    return getPropertyProxy(self, name);
  }

  ScriptObject color = getColor<Widget, &Widget::getColor, &Widget::setColor>(self);
  addPropertyProxy(self, name, color);
  return color;
}


ScriptObject WidgetBridge::getAbsolutePosition(Widget* self, const ScriptArray& args)
{
  return Vector3ToScript(self->getAbsolutePosition());
}

ScriptObject WidgetBridge::getAbsoluteSize(Widget* self, const ScriptArray& args)
{
  return Vector2ToScript(self->getAbsoluteSize());
}

ScriptObject WidgetBridge::getPositionOnScreen(Widget* self, const ScriptArray& args)
{
  /* Same as getAbsolutePosition for now.
   * Keep the API in case VoltWorker with different window/stage size is
   * supported in future. */
  LOG_WARN(volt::util::Logger("volt"), "DEPRECATED: getPositionOnScreen is deprecated (Volt 1.8). Use getAbsolutePosition instead.");
  return getAbsolutePosition(self, args);
}

ScriptObject WidgetBridge::getSizeOnScreen(Widget* self, const ScriptArray& args)
{
  /* Same as getAbsoluteSize for now.
   * Keep the API in case VoltWorker with different window/stage size is
   * supported in future. */
  LOG_WARN(volt::util::Logger("volt"), "DEPRECATED: getSizeOnScreen is deprecated (Volt 1.8). Use getAbsoluteSize instead.");
  return getAbsoluteSize(self, args);
}

ScriptObject WidgetBridge::getTransformedDepth(Widget* self, const ScriptArray& args)
{
  return self->getTransformedDepth();
}

/*
 * Scene graph stuff (children functions)
 */

ScriptObject Bridge::WidgetBridge::getChildCount(Widget* self,
    const ScriptArray& args)
{
  return ScriptObject((double)self->getChildCount());
}

ScriptObject Bridge::WidgetBridge::addChild(Widget* self,
    const ScriptArray& args)
{
  int index = -1;

  if(args.Length() > 0)
  {
    if(args.Length() == 2 && args[1].isNumber())
    {
      index = args[1].asNumber();
    }

    Widget* child = unwrapNativeObject<Widget>(args[0]);

    if (child != nullptr)
    {
      index = self->addChild(child, index);
      return ScriptObject(index);
    }
    else
    {
      return ScriptException("Non-widget passed as argument to Widget.addChild");
    }
  }

  return ScriptException("Widget.addChild expects a Widget object as first parameter");
}


ScriptObject Bridge::WidgetBridge::removeChild(Widget* self,
    const ScriptArray& args)
{
  if(args.Length() > 0)
  {
    Widget* orphan = unwrapNativeObject<Widget>(args[0]);

    if(orphan == nullptr && args[0].isNumber())
    {
      orphan = self->removeChildByIndex(args[0].asNumber());
    }
    else if (orphan == nullptr && args[0].isString())
    {
      orphan = self->getChildByName(args[0].asString());
      self->removeChild( orphan );
    }
    else if (orphan != nullptr)
    {
      self->removeChild(orphan);
    }

    if (orphan != nullptr) //if we ended up finding a widget
    {
      //If called with an index it may be useful to return the widget that we looked up.
      return wrapExistingNativeObject(orphan);
    }
    else
    {
      return ScriptException("Non-widget or valid index passed as argument to Widget.removeChild");
    }
  }

  return ScriptException("Widget.removeChild expects a Widget object or valid index as first parameter");
}

ScriptObject Bridge::WidgetBridge::getChild(Widget* self,
    const ScriptArray& args)
{
  if(args.Length() > 0)
  {
    return wrapExistingNativeObject( getChildWidget(self, args[0]) );
  }

  return ScriptObject();
}

Widget* WidgetBridge::getChildWidget(Widget* self, ScriptObject identifier)
{
  Widget* target = nullptr;

  if(identifier.isNumber())
  {
    target = self->getChildByIndex(identifier.asNumber());
  }
  else if (identifier.isString())
  {
    target = self->getChildByName(identifier.asString());
  }

  return target;
}

ScriptObject Bridge::WidgetBridge::getAncestor(Widget* self, const ScriptArray& args)
{
  if(args.Length() > 0 && args[0].isString())
  {
    return wrapExistingNativeObject( self->getAncestor(args[0].asString()) );
  }

  return ScriptObject();
}

ScriptObject Bridge::WidgetBridge::getDescendent(Widget* self, const ScriptArray& args)
{
  if(args.Length() > 0 && args[0].isString())
  {
    return wrapExistingNativeObject( self->getDescendent(args[0].asString()) );
  }

  return ScriptObject();
}


LayoutAlignment WidgetBridge::deserializeLayoutAlignment(std::string alignmentStr, LayoutAlignment theDefault)
{
  if(compareStrChar(alignmentStr, "right"))
  {
    return LayoutAlignment::Right;
  }

  if(compareStrChar(alignmentStr, "center"))
  {
    return LayoutAlignment::Center;
  }

  if(compareStrChar(alignmentStr, "left"))
  {
    return LayoutAlignment::Left;
  }
  else
  {
    return theDefault;
  }
}

std::string WidgetBridge::serializeLayoutAlignment(LayoutAlignment alignment)
{
  switch(alignment)
  {
  case LayoutAlignment::Right:
    return "right";
  case LayoutAlignment::Center:
    return "center";
  default:
    return "center";
  }
}


ScalingFilter WidgetBridge::deserializeScalingFilter(std::string scalingFilterStr, ScalingFilter theDefault)
{
  if(compareStrChar(scalingFilterStr, "linear"))
  {
    return FILTER_LINEAR;
  }

  if(compareStrChar(scalingFilterStr, "nearest"))
  {
    return FILTER_NEAREST;
  }

  if(compareStrChar(scalingFilterStr, "trilinear"))
  {
    return FILTER_TRILINEAR;
  }
  else
  {
    return theDefault;
  }
}


std::string WidgetBridge::serializeScalingFilter(ScalingFilter filter)
{
  switch(filter)
  {
  default:
  case FILTER_LINEAR:
    return "linear";
  case FILTER_NEAREST:
    return "nearest";
  case FILTER_TRILINEAR:
    return "trilinear";
  }
}

ScriptObject WidgetBridge::hasKeyFocus(volt::graphics::Widget* self, const ScriptArray& args)
{
  return ScriptObject(self->hasKeyFocus());
}

ScriptObject WidgetBridge::addEventListener(Widget* self, const ScriptArray& args)
{
  ScriptFunction listener = args[1].asFunction();

  //Key events
  if (args[0].isNumber())
  {
    unsigned eventID = (unsigned int)args[0].asNumber();
    std::vector<WidgetKeyEventCallback>& callbacks = perWidgetData[self].keyEventCallbacks[eventID];
    for (auto it = callbacks.begin(); it != callbacks.end(); ++it)
    {
      if (it->first == listener)
      {
        return ScriptObject(); //do nothing
      }
    }
    KeyEventCallback nativeCallback = std::bind(invokeKeyCallback, listener, std::placeholders::_1, std::placeholders::_2);
    Widget::KeyEventHandle eventHandle = self->registerKeyEvent(eventID, nativeCallback);
    callbacks.push_back( std::make_pair(listener, eventHandle) );
    return ScriptObject();
  }

  std::string eventID = args[0].asString(); 
  std::transform(eventID.begin(), eventID.end(), eventID.begin(), ::tolower); //ignore case

  //Mouse Events
  auto it = mouseEventIDMap.find(eventID);
  if (it != mouseEventIDMap.end())
  {
    Widget::MouseEvent event = it->second;
    //Check if this function is already registered to this widget and event. If it is, break out.
    std::vector<WidgetEventCallback>& callbacks = perWidgetData[self].eventCallbacks[event];

    for (auto it = callbacks.begin(); it != callbacks.end(); ++it)
    {
      if (it->first == listener)
      {
        return ScriptObject(); //do nothing
      }
    }

    ButtonPressCallback native_callback =
      std::bind(invokeMouseCallback, listener,
                std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4);

    Widget::EventHandle eventHandle = self->registerMouseEvent(event, native_callback);

    callbacks.push_back( std::make_pair(listener, eventHandle) );

  }
  else
  {
    //Focus Events
    auto it = focusEventIDMap.find(eventID);
    if (it != focusEventIDMap.end())
    {
      Widget::FocusEvent event = it->second;
      //Check if this function is already registered to this widget and event. If it is, break out.
      std::vector<WidgetFocusEventCallback>& callbacks = perWidgetData[self].focusEventCallbacks[event];
      for (auto it = callbacks.begin(); it != callbacks.end(); ++it)
      {
        if (it->first == listener)
        {
          return ScriptObject(); //do nothing
        }
      }
      FocusEventCallback nativeCallback = std::bind(invokeFocusCallback, listener);
      Widget::FocusEventHandle eventHandle = self->registerFocusEvent(event, nativeCallback);
      callbacks.push_back( std::make_pair(listener, eventHandle) );
    }

  }


  return ScriptObject();
}

ScriptObject WidgetBridge::removeEventListener(Widget* self, const ScriptArray& args)
{
  ScriptFunction targetListener = args[1].asFunction();

  //Key event handling
  if (args[0].isNumber())
  {
    unsigned eventID = (unsigned)args[0].asNumber();
    std::vector<WidgetKeyEventCallback>& callbacks = perWidgetData[self].keyEventCallbacks[eventID];

    for (auto it = callbacks.begin(); it != callbacks.end(); ++it) //if the target callbacks is there, remove it.
    {
      if (it->first == targetListener)
      {
        Widget::KeyEventHandle handle = it->second;
        self->unregisterKeyEvent(handle);
        callbacks.erase(it);
        break;
      }
    }
    if (callbacks.size() == 0) //if this was the last callback for this event type, delete the key from the map
    {
      perWidgetData[self].keyEventCallbacks.erase(eventID);
    }

    return ScriptObject();
  }
  std::string eventID = args[0].asString(); 
  

  std::transform(eventID.begin(), eventID.end(), eventID.begin(), ::tolower); //ignore case

  //Mouse Events handling
  auto it = mouseEventIDMap.find(eventID);
  if (it != mouseEventIDMap.end())
  {
    Widget::MouseEvent event = it->second;

    if ( perWidgetData[self].eventCallbacks.count(event) ) //if there are callbacks for this widget and event type
    {
      std::vector<WidgetEventCallback>& callbacks = perWidgetData[self].eventCallbacks[event];

      for (auto it = callbacks.begin(); it != callbacks.end(); ++it) //if the target callbacks is there, remove it.
      {
        if (it->first == targetListener)
        {
          Widget::EventHandle handle = it->second;
          self->unregisterMouseEvent(event, handle);
          callbacks.erase(it);
          break;
        }
      }
      if (callbacks.size() == 0) //if this was the last callback for this event type, delete the key from the map
      {
        perWidgetData[self].eventCallbacks.erase(event);
      }
    }
  }
  else //Focus Events handling
  {
    auto it = focusEventIDMap.find(eventID);
    if (it != focusEventIDMap.end())
    {
      Widget::FocusEvent event = it->second;
      if ( perWidgetData[self].focusEventCallbacks.count(event) ) //if there are callbacks for this widget and event type
      {
       std::vector<WidgetFocusEventCallback>& callbacks = perWidgetData[self].focusEventCallbacks[event];

       for (auto it = callbacks.begin(); it != callbacks.end(); ++it) //if the target callbacks is there, remove it.
       {
         if (it->first == targetListener)
         {
           Widget::FocusEventHandle handle = it->second;
           self->unregisterFocusEvent(handle);
           callbacks.erase(it);
           break;
         }
       }
       if (callbacks.size() == 0) //if this was the last callback for this event type, delete the key from the map
       {
         perWidgetData[self].focusEventCallbacks.erase(event);
       }

      }
    }
  }

  return ScriptObject();
}

ScriptObject WidgetBridge::dispatchEvent(Widget* self, const ScriptArray& args)
{
  std::string eventID = args[0].asString();
  guint32 mouseButton = 0;
  Vector2 coordinates = Vector2(0,0);

  if(args.has(1))
  {
    ScriptObject eventData = args[1];

    if(eventData.has("button"))
    {
      mouseButton = eventData.get("button").asNumber();
    }

    if(eventData.has("coordinates"))
    {
      coordinates = ScriptToVector2(eventData.get("coordinates"));
    }
  }

  std::transform(eventID.begin(), eventID.end(), eventID.begin(), ::tolower); //ignore case
  auto it = mouseEventIDMap.find(eventID);
  if (it != mouseEventIDMap.end())
  {
    self->fireMouseEvent(it->second, (volt::util::MOUSE_BUTTON)mouseButton, coordinates); 
  }
  else
  {
    auto it = focusEventIDMap.find(eventID);
    if (it != focusEventIDMap.end())
    {
      self->fireFocusEvent(it->second);
    }
  }
  return ScriptObject();
}

bool WidgetBridge::invokeMouseCallback(const ScriptFunction& callback, Widget* self, Widget* origin,
                                       const volt::util::MOUSE_BUTTON mouseButton, Vector2 coordinates)
{
  ScriptObject eventObj;
  eventObj.set("button", ScriptObject(mouseButton));
  eventObj.set("coordinates", Vector2ToScript(coordinates));
  eventObj.set("origin", wrapExistingNativeObject(origin));

  ScriptArray args;
  args.set(0, wrapExistingNativeObject(self));
  args.set(1, eventObj);

  ScriptObject callbackResult = callback.invoke(args);

  if (callbackResult.isBool())
  {
    bool result = callbackResult.asBool();

    if (!result)
    {
      return false;
    }
  }

  return true;
}

void WidgetBridge::invokeFocusCallback(const ScriptFunction& callback)
{
  ScriptArray args;
  callback.invoke(args);
}

void WidgetBridge::invokeKeyCallback(const ScriptFunction& callback, unsigned int key, unsigned int type)
{
  ScriptArray args;
  ScriptObject eventData;
  eventData.set("keycode", ScriptObject((int)key));
  eventData.set("type", ScriptObject((int)type));
  args.set(0, eventData);
  callback.invoke(args);
}

std::unordered_map<std::string, volt::graphics::Widget::FocusEvent> WidgetBridge::focusEventIDMap =
{
  { "onunfocus",Widget::ON_UNFOCUS },
  { "onfocus", Widget::ON_FOCUS },
};


std::unordered_map<std::string, Widget::MouseEvent> WidgetBridge::mouseEventIDMap =
{
  { "onmousedown",Widget::MOUSE_DOWN },
  { "onmouseup", Widget::MOUSE_UP },
  { "onmouseover",Widget::MOUSE_OVER },
  { "onmouseout",Widget::MOUSE_OUT },
  { "onmousemove",Widget::MOUSE_MOVE },
  { "onmouseclick",Widget::MOUSE_CLICK }
};

ScriptObject WidgetBridge::reorderChildrenByDepth(Widget* self, const ScriptArray& args)
{
  self->reorderChildrenByDepth();
  return ScriptObject();
}

