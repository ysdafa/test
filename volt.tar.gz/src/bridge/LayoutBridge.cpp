/*
 * LayoutBridge.cpp
 *
 *  Created on: Jul 23, 2013
 *      Author: reza
 */

#include "LayoutBridge.h"

namespace Bridge
{

void Bridge::LayoutBridge::mapScriptInterface(ScriptContext& context)
{
  WidgetBridge::mapScriptInterface(context);

  //context.bindNumber<LayoutWidget, float, &LayoutWidget::getSpacing, &LayoutWidget::setSpacing>("spacing");
  //Spacing doesn't work well with alignment. Most likely should seperate to different layout
  context.capturePropertyAccess<LayoutWidget, &getOrientation, &setOrientation>("orientation");
}


LayoutOrientation LayoutBridge::deserializeLayoutOrientation(std::string orientationStr)
{
  if(compareStrChar(orientationStr, "vertical"))
  {
    return LayoutOrientation::Vertical;
  }
  else
  {
    return LayoutOrientation::Horizontal;
  }
}

std::string LayoutBridge::serializeLayoutOrientation(LayoutOrientation orientation)
{
  switch(orientation)
  {
  case LayoutOrientation::Vertical:
    return "vertical";
  default:
    return "horizontal";
  }
}


ScriptObject LayoutBridge::getOrientation(LayoutWidget* self)
{
  return ScriptObject(serializeLayoutOrientation(self->getOrientation()));
}

void LayoutBridge::setOrientation(LayoutWidget* self, ScriptObject value)
{
  self->setOrientation(deserializeLayoutOrientation(value.asString()));
}


} /* namespace Bridge */


