#include "NinePatchWidgetBridge.h"

using namespace Bridge;
using namespace volt::graphics;

void NinePatchWidgetBridge::mapScriptInterface(ScriptContext& context)
{
  ImageWidgetBridge::mapScriptInterface(context);
}

ImageWidget* NinePatchWidgetBridge::constructImageWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
  Vector2 cornerDims = ScriptToVector2(args[0]["cornerDimensions"]);
  NinePatchWidget* result = new NinePatchWidget(x, y, parent, cornerDims);

  if(width != -1 || height != -1) //if either width or height has been assigned
  {
    result->setWidth((width == -1) ? 0 : width);
    result->setHeight((height == -1) ? 0 : height);
  }

  return result;
}
