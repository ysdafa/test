#include "gtest/gtest.h"

#include "time_util.h"

TEST(TestTime, RFC1123)
{
  volt::util::Time time;

  /* Positive test cases. */
  EXPECT_TRUE(time.ParseHttpTime("Sun, 06 Nov 1994 08:49:37 GMT"));
  EXPECT_TRUE(time.ParseHttpTime("Sun, 6 Nov 1994 08:49:37 GMT"));

  /* Negative test cases. */
  /* Timezone MUST be GMT */
  EXPECT_FALSE(time.ParseHttpTime("Sun, 06 Nov 1994 08:49:37 UTC"));
}

TEST(TestTime, RFC1036)
{
  volt::util::Time time;

  /* Positive test cases. */
  EXPECT_TRUE(time.ParseHttpTime("Sunday, 06-Nov-94 08:49:37 GMT"));
  EXPECT_TRUE(time.ParseHttpTime("Sunday, 6-Nov-94 08:49:37 GMT"));

  /* Negative test cases. */
  /* Timezone MUST be GMT */
  EXPECT_FALSE(time.ParseHttpTime("Sunday, 06-Nov-94 08:49:37 UTC"));
}

TEST(TestTime, ANSI)
{
  volt::util::Time time;

  /* Positive test cases. */
  EXPECT_TRUE(time.ParseHttpTime("Sun Nov 06 08:49:37 1994"));
  EXPECT_TRUE(time.ParseHttpTime("Sun Nov 6 08:49:37 1994"));
}

TEST(TestTime, Invalid)
{
  volt::util::Time time;

  /* Negative test cases. */
  EXPECT_FALSE(time.ParseHttpTime(""));
  EXPECT_FALSE(time.ParseHttpTime("Invalid Input"));
}
