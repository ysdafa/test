#include "gtest/gtest.h"
#include "Widget.h"
#include "SceneRoot.h"
#include "clutter_helper.h"

bool isClutterInitialized  = false;

using namespace volt::graphics;

Widget* clearWidgetChildren(Widget* widget)
{
  while (widget->getChildCount() > 0)
  {
    widget->removeChild(widget->getChildByIndex(0));
  }

  return widget;
}

class TestWidgetPosition : public ::testing::Test
{

  public:

    Widget* widget;
    SceneRoot* root;

    TestWidgetPosition()
    {
      if (!isClutterInitialized)
      {
        isClutterInitialized = clutter_init(0, 0);
      }

      ClutterActor* stage = clutter_stage_new();
      root = new SceneRoot(stage);
      widget = new Widget(0,0,0,0, root);
    }

    ~TestWidgetPosition()
    {
      delete widget;
    }
};


/* Test setting the position of a widget*/
TEST_F(TestWidgetPosition, TestWidgetPosition)
{
  EXPECT_EQ(widget->getX(), 0);
  EXPECT_EQ(widget->getY(), 0);

  widget->setX(10);
  widget->setY(15);

  EXPECT_EQ(widget->getX(), 10);
  EXPECT_EQ(widget->getY(), 15);
}

class TestAbsoluteQueries : public ::testing::Test
{
  public:

    Widget *widget1, *widget2;
    SceneRoot* root;

    TestAbsoluteQueries()
    {
      if (!isClutterInitialized)
      {
        isClutterInitialized = clutter_init(0, 0);
      }

      ClutterActor* stage = clutter_stage_new();
      root = new SceneRoot(stage);
      widget1 = new Widget(0,0,0,0, root);
      widget2 = new Widget(0,0,0,0, root);
    }

    ~TestAbsoluteQueries()
    {
      delete clearWidgetChildren(widget1);
      delete clearWidgetChildren(widget2);
    }


};

TEST_F(TestAbsoluteQueries, TestAbsolutePosition)
{
  widget1->setX(10);
  widget1->setY(3);

  widget2->setX(5);
  widget2->setY(2);

  Vector3 absPos = widget2->getAbsolutePosition();
  EXPECT_EQ(absPos.x, 5);
  EXPECT_EQ(absPos.y, 2);

  widget2->setParent(widget1);
  absPos = widget2->getAbsolutePosition();

  EXPECT_EQ(absPos.x, 15);
  EXPECT_EQ(absPos.y, 5);
}

TEST_F(TestAbsoluteQueries, TestAbsoluteSize)
{
  widget1->setWidth(1);
  widget1->setHeight(1);

  widget2->setWidth(10);
  widget2->setHeight(5);

  widget2->setParent(widget1);
  Vector2 absDim = widget2->getAbsoluteSize();

  EXPECT_EQ(absDim.x, 10);
  EXPECT_EQ(absDim.y, 5);

  float scale = 2;
  widget2->setScale(Vector2(scale, scale));
  absDim = widget2->getAbsoluteSize();

  EXPECT_EQ(absDim.x, 10 * scale);
  EXPECT_EQ(absDim.y, 5 * scale);
}


class TestSceneGraph : public ::testing::Test
{
  public:

    Widget *widget1, *widget2, *widget3;
    SceneRoot* root;

    TestSceneGraph()
    {
      if (!isClutterInitialized)
      {
        isClutterInitialized = clutter_init(0, 0);
      }

      ClutterActor* stage = clutter_stage_new();
      root = new SceneRoot(stage);

      widget1 = new Widget(0,0,0,0, root);
      widget2 = new Widget(0,0,0,0, root);
      widget3 = new Widget(0,0,0,0, root);

      widget1->setID("widget1");
      widget2->setID("widget2");
    }

    ~TestSceneGraph()
    {
      delete clearWidgetChildren(widget1);
      delete clearWidgetChildren(widget2);
      delete clearWidgetChildren(widget3);
    }
};


/* Test setting children of widgets */
TEST_F(TestSceneGraph, TestSetParent)
{
  EXPECT_TRUE(widget2->getParent() == root) << "Widget initial parent is not root";

  widget2->setParent(widget1);
  ASSERT_EQ(widget2->getParent(), widget1) << "setParent did not set the parent";
  ASSERT_EQ(widget1->getChildByIndex(0), widget2) << "setParent did not set the parent(getChildByIndex)";
}

TEST_F(TestSceneGraph, TestAddChild)
{
  EXPECT_TRUE(widget1->getChildByIndex(0) == nullptr) << "Widget with no children not reporting nullptr as first child";

  widget1->addChild(widget2);
  EXPECT_TRUE(widget2->getParent() == widget1) << "addChild added child not seen by child->getParent";

  EXPECT_TRUE(widget1->getChildByIndex(0) == widget2) << "addChild added child not seen by child->getParent";

  widget1->addChild(widget3);

  EXPECT_TRUE(widget1->getChildByIndex(1) == widget3) << "addChild added child not seen by child->getParent (index 1)";
  EXPECT_TRUE(widget1->getChildByIndex(0) == widget2) << "addChild added child not seen by child->getParent (index 1)";
}

TEST_F(TestSceneGraph, TestAddChildIdentity)
{
  widget1->addChild(widget2);
  EXPECT_TRUE(widget1->getChildByIndex(0) == widget2);

  //test that re-adding the same child works
  widget1->addChild(widget2);
  EXPECT_TRUE(widget1->getChildByIndex(0) == widget2);

  widget2->setParent(widget1);
  EXPECT_TRUE(widget1->getChildByIndex(0) == widget2);
}

TEST_F(TestSceneGraph, TestPositionInheritence)
{
  ASSERT_TRUE(widget1->getX() == 0);
  ASSERT_TRUE(widget1->getY() == 0);
  ASSERT_TRUE(widget2->getX() == 0);
  ASSERT_TRUE(widget2->getY() == 0);

  widget1->addChild(widget2);

  widget1->setX(10);
  widget2->setX(5);
  EXPECT_TRUE(widget2->getAbsolutePosition().x == 15);
}

TEST_F(TestSceneGraph, TestRemoveChild)
{
  widget1->addChild(widget2);
  widget1->addChild(widget3);

  ASSERT_TRUE(widget1->getChildByIndex(0) == widget2);
  ASSERT_TRUE(widget1->getChildByIndex(1) == widget3);

  widget1->removeChild(widget3);
  ASSERT_TRUE(widget1->getChildByIndex(1) == nullptr);

  widget1->addChild(widget3);

  widget1->removeChild(widget2);
  ASSERT_TRUE(widget1->getChildByIndex(0) == widget3);

  widget1->removeChild(widget3);
  ASSERT_TRUE(widget1->getChildByIndex(0) == nullptr);
}

TEST_F(TestSceneGraph, TestSwapChildren)
{
  widget1->addChild(widget2);
  widget1->addChild(widget3);

  ASSERT_TRUE(widget1->getChildByIndex(0) == widget2);
  ASSERT_TRUE(widget1->getChildByIndex(1) == widget3);

  widget1->addChild(widget3, 0);

  ASSERT_TRUE(widget1->getChildByIndex(1) == widget2);
  ASSERT_TRUE(widget1->getChildByIndex(0) == widget3);

}

TEST_F(TestSceneGraph, TestGetById)
{
  EXPECT_TRUE(root->getChildByName("widget1") == widget1);
  EXPECT_TRUE(root->getChildByName("widget2") == widget2);
}

TEST_F(TestSceneGraph, TestGlobalGetById)
{
  EXPECT_TRUE(Widget::getWidgetByID("widget1") == widget1);
  EXPECT_TRUE(Widget::getWidgetByID("widget2") == widget2);
}


TEST_F(TestSceneGraph, TestGetDescendent)
{
  widget1->addChild(widget3); //order is 1 3 2
  widget3->addChild(widget2);

  EXPECT_TRUE(widget1->getDescendent("widget2"));
}

TEST_F(TestSceneGraph, TestGetAncestor)
{
  widget1->addChild(widget3); //order is 1 3 2
  widget3->addChild(widget2);

  EXPECT_TRUE(widget2->getAncestor("widget1"));
}




