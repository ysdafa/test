#include "gtest/gtest.h"

#include "NetworkIORequest.h"
#include "FileIORequest.h"
#include "CacheManager.h"

#include "logger.h"
#include "time_util.h"

/* For logging. */
static volt::util::Logger LOGGER("test.CacheManager");

using namespace Resource;

static volt::util::Time base_time;
static volt::util::Time time_offset;

static volt::util::Time DummyClock()
{
  return base_time + time_offset;
}

static void init_clock()
{
  base_time = volt::util::Time::Now();
  time_offset = 0;
  volt::util::Time::NowFunction = DummyClock;
}

class TestCacheManager : public ::testing::Test
{
  public:
    virtual void SetUp()
    {
      init_clock();

      /* Clean cached data. */
      CacheManager::Instance().Flush();
      CacheManager::Instance().SetMaxSize(1);

      /* Setup some requests/responss. */
      request1.reset(new NetworkIORequest("http://request.1"));
      response1.reset(new NetworkIOResponse());
      request1->ResetCacheKey();
      response1->set_uri(request1->uri());
      response1->set_cache_key(request1->cache_key());
      response1->set_data(std::string(300000, '1'));
      response1->set_type("image/jpeg");

      request2.reset(new NetworkIORequest("http://request.2"));
      response2.reset(new NetworkIOResponse());
      request2->ResetCacheKey();
      response2->set_uri(request2->uri());
      response2->set_cache_key(request2->cache_key());
      response2->set_data(std::string(300000, '2'));
      response2->set_type("image/jpeg");

      request3.reset(new NetworkIORequest("http://request.3"));
      response3.reset(new NetworkIOResponse());
      request3->ResetCacheKey();
      response3->set_uri(request3->uri());
      response3->set_cache_key(request3->cache_key());
      response3->set_data(std::string(300000, '3'));
      response3->set_type("image/jpeg");

      request4.reset(new NetworkIORequest("http://request.4"));
      response4.reset(new NetworkIOResponse());
      request4->ResetCacheKey();
      response4->set_uri(request4->uri());
      response4->set_cache_key(request4->cache_key());
      response4->set_data(std::string(300000, '4'));
      response4->set_type("image/jpeg");

      std::string header;
      header = "Date: " + volt::util::Time::Now().HttpTimeString();
      response1->ParseHeader(header.c_str(), header.size(), response1);
      response2->ParseHeader(header.c_str(), header.size(), response2);
      response3->ParseHeader(header.c_str(), header.size(), response3);
      response4->ParseHeader(header.c_str(), header.size(), response4);
      header = "Cache-Control: max-age=10";
      response1->ParseHeader(header.c_str(), header.size(), response1);
      response2->ParseHeader(header.c_str(), header.size(), response2);
      header = "Expires: " + (volt::util::Time::Now() + 20).HttpTimeString();
      response1->ParseHeader(header.c_str(), header.size(), response1);
      response3->ParseHeader(header.c_str(), header.size(), response3);

      /* response1 = max-age & expires
       * response2 = max-age only
       * response3 = expires only
       * response4 = no cache headers (defaults to 1hr) */
    }

    virtual void TearDown()
    {
      /* Clean cached data. */
      CacheManager::Instance().Flush();
    }

    NetworkIORequest::SharedPtr request1;
    NetworkIOResponse::SharedPtr response1;
    NetworkIORequest::SharedPtr request2;
    NetworkIOResponse::SharedPtr response2;
    NetworkIORequest::SharedPtr request3;
    NetworkIOResponse::SharedPtr response3;
    NetworkIORequest::SharedPtr request4;
    NetworkIOResponse::SharedPtr response4;
};

/* Verify GetCachedResponse fails for responses that are not yet cached. */
TEST_F(TestCacheManager, CacheMiss)
{
  NetworkIORequest::SharedPtr nw_request(new NetworkIORequest(""));
  EXPECT_FALSE(CacheManager::Instance().GetCachedResponse(nw_request));

  nw_request->set_uri("http://not.cached.yet");
  EXPECT_FALSE(CacheManager::Instance().GetCachedResponse(nw_request));

  FileIORequest::SharedPtr file_request(new FileIORequest(""));
  EXPECT_FALSE(CacheManager::Instance().GetCachedResponse(file_request));

  file_request->set_uri("file://not/cached/yet");
  EXPECT_FALSE(CacheManager::Instance().GetCachedResponse(file_request));
}

/* Verify the normal caching flow works. */
TEST_F(TestCacheManager, NewCache)
{
  /* Should NOT find cached data. */
  ASSERT_FALSE(CacheManager::Instance().GetCachedResponse(request1));

  ASSERT_TRUE(CacheManager::Instance().TryCache(response1));

  /* Now,it should find the just cached data. */
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request1));

  EXPECT_TRUE(request1->response()->IsFromCache());
  EXPECT_EQ(request1->response()->uri(), response1->uri());
  EXPECT_EQ(request1->response()->type(), response1->type());
  EXPECT_EQ(request1->response()->data(), response1->data());
}

/* Verify that the TryCache fails for bad/unsupported responses. */
TEST_F(TestCacheManager, NotCacheable)
{
  /* Should not cache unsupported types. */
  response1->set_type("no/cache");
  EXPECT_FALSE(CacheManager::Instance().TryCache(response1));

  std::string header;

  /* Should not cache max-age=0 */
  response1->set_type("image/jpeg");
  header = "Cache-Control: max-age=0";
  response1->ParseHeader(header.c_str(), header.size(), response1);
  EXPECT_FALSE(CacheManager::Instance().TryCache(response1));

  /* Should not cache if private. */
  header = "Cache-Control: private, max-age=10";
  response1->ParseHeader(header.c_str(), header.size(), response1);
  EXPECT_FALSE(CacheManager::Instance().TryCache(response1));
}

/* Verify that the TryCache fails if the response size is larger than the max
 * size. */
TEST_F(TestCacheManager, LargerThanMaxCacheSize)
{
  /* bigger than CacheManager max size */
  response1->set_data(std::string(1500000, 'x'));
  ASSERT_FALSE(CacheManager::Instance().TryCache(response1));
}

/* Verify that the old cache are purged with LRU policy. */
TEST_F(TestCacheManager, LRUPurge)
{
  /* This should succeed. */
  ASSERT_TRUE(CacheManager::Instance().TryCache(response1));
  /* Now,it should find the just cached data. */
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request1));

  /* This should succeed. */
  ASSERT_TRUE(CacheManager::Instance().TryCache(response2));
  /* Now,it should find both cached data. */
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request1));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request2));

  /* This should succeed. */
  ASSERT_TRUE(CacheManager::Instance().TryCache(response3));
  /* It should find all cached data. */
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request1));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request2));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request3));

  /* This should remove the cache for req1 (LRU purging). */
  ASSERT_TRUE(CacheManager::Instance().TryCache(response4));
  /* It should NOT find request1. */
  ASSERT_FALSE(CacheManager::Instance().GetCachedResponse(request1));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request2));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request3));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request4));

  /* Simulate cache hit for response2. */
  CacheManager::Instance().CachedResponseAccessed(response2);
  /* Re-cache response1.  This should remove request3. */
  ASSERT_TRUE(CacheManager::Instance().TryCache(response1));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request1));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request2));
  ASSERT_FALSE(CacheManager::Instance().GetCachedResponse(request3));
  ASSERT_TRUE(CacheManager::Instance().GetCachedResponse(request4));
}

/* Verify that the response expiry is according to the cache control flags. */
TEST_F(TestCacheManager, Expiry)
{
  time_offset = 10; /* advance clock */
  /* This should be expired now. */
  ASSERT_TRUE(response1->IsExpired());
  ASSERT_TRUE(response2->IsExpired());
  /* This is still fresh. */
  ASSERT_FALSE(response3->IsExpired());
  ASSERT_FALSE(response4->IsExpired());

  time_offset = 20; /* advance clock */
  /* This should be expired now. */
  ASSERT_TRUE(response1->IsExpired());
  ASSERT_TRUE(response2->IsExpired());
  ASSERT_TRUE(response3->IsExpired());
  /* This is still fresh. */
  ASSERT_FALSE(response4->IsExpired());

  time_offset = 60 * 60; /* advance clock */
  /* This should be expired now. */
  ASSERT_TRUE(response1->IsExpired());
  ASSERT_TRUE(response2->IsExpired());
  ASSERT_TRUE(response3->IsExpired());
  ASSERT_TRUE(response4->IsExpired());
}
