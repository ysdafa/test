#include "TaskDispatcher.h"

#include "logger.h"

namespace volt
{
namespace util
{

static volt::util::Logger LOGGER("volt.util.task");


unsigned int TaskDispatcher::TaskHandler::id_counter_ = 0;

TaskDispatcher::TaskHandler::TaskHandler(Task aTask):
  id_(id_counter_++), task_(aTask)
{
  LOG_DEBUG(LOGGER, "Task " << id() << " born");
}

TaskDispatcher::TaskHandler::~TaskHandler()
{
  LOG_DEBUG(LOGGER, "Task " << id() << " dead");
}

unsigned int TaskDispatcher::TaskHandler::id() const
{
  return id_;
}

TaskDispatcher::Task TaskDispatcher::TaskHandler::task() const
{
  return task_;
}

void TaskDispatcher::TaskHandler::RunTask(SharedPtr aSelf)
{
  LOG_DEBUG(LOGGER, "Running task " << aSelf->id());
  aSelf->task()();
}






TaskDispatcher::DelayedTaskHandler::DelayedTaskHandler(Task aTask,
    boost::asio::io_service &aIO):
  TaskHandler(aTask), timer_(aIO)
{
  LOG_DEBUG(LOGGER, "Delayed task " << id() << " born");
}

TaskDispatcher::DelayedTaskHandler::~DelayedTaskHandler()
{
  LOG_DEBUG(LOGGER, "Delayed task " << id() << " dead");
  Cancel();
}

void TaskDispatcher::DelayedTaskHandler::Cancel()
{
  LOG_DEBUG(LOGGER, "Cancel delayed task " << id());
  timer_.cancel();
}

void TaskDispatcher::DelayedTaskHandler::Wait(const unsigned int aDelayMsec)
{
  timer_.expires_from_now(boost::posix_time::milliseconds(aDelayMsec));
  timer_.async_wait(std::bind(RunTask, std::placeholders::_1, shared_from_this()));
}

void TaskDispatcher::DelayedTaskHandler::RunTask(const boost::system::error_code &aError, SharedPtr aSelf)
{
  if (aError == boost::asio::error::operation_aborted)
  {
    LOG_DEBUG(LOGGER, "Delayed task " << aSelf->id() << " is caceled");
  }
  else
  {
    LOG_DEBUG(LOGGER, "Execute delayed task " << aSelf->id());
    aSelf->task()();
  }
}





TaskDispatcher& TaskDispatcher::Instance()
{
  static TaskDispatcher singleton;
  return singleton;
}

void TaskDispatcher::Initialize(const unsigned int aNumThreads)
{
  LOG_DEBUG(LOGGER, "Initializing with " << aNumThreads << " workers");

  /* Create a work to keep io_service::run running. */
  work_.reset(new boost::asio::io_service::work(io_service_));

  for (unsigned int num = 0; num < aNumThreads; ++num)
  {
    /* Using RunWrapper as std::bind complains about io_service::run
     * ambiguity. */
    workers_.push_back(std::thread(std::bind(TaskDispatcher::RunWrapper, &io_service_)));
  }
}

TaskDispatcher::~TaskDispatcher()
{
  io_service_.stop();
  Finish();
}

void TaskDispatcher::Finish()
{
  work_.reset();

  for (unsigned int num = 0; num < workers_.size(); ++num)
  {
    if (workers_[num].joinable())
    {
      LOG_DEBUG(LOGGER, "Joining worker " << num);
      workers_[num].join();
      LOG_DEBUG(LOGGER, "Joined worker " << num);
    }
  }
}

void TaskDispatcher::AddTask(TaskDispatcher::Task aTask)
{
  TaskHandler::SharedPtr handler(new TaskHandler(aTask));
  io_service_.post(std::bind(TaskHandler::RunTask, handler));
}

void TaskDispatcher::AddDelayedTask(const unsigned int aDelayMsec, Task aTask)
{
  CreateDelayedTask(aDelayMsec, aTask);
}

TaskDispatcher::DelayedTaskHandler::SharedPtr TaskDispatcher::CreateDelayedTask(const unsigned aDelayMsec,
    Task aTask)
{
  DelayedTaskHandler::SharedPtr handler(new DelayedTaskHandler(aTask, io_service_));
  handler->Wait(aDelayMsec);
  return handler;
}

TaskDispatcher::TaskDispatcher(): io_service_(), work_(), workers_()
{
}

void TaskDispatcher::RunWrapper(boost::asio::io_service *aIO)
{
  LOG_DEBUG(LOGGER, "Running io_service");
  aIO->run();
}

void TaskDispatcher::PrepFork()
{
#ifdef BUILD_FOR_TV
  io_service_.notify_fork(boost::asio::io_service::fork_prepare);
#endif
}

void TaskDispatcher::AfterForkParent()
{
#ifdef BUILD_FOR_TV
  io_service_.notify_fork(boost::asio::io_service::fork_parent);
#endif
}

void TaskDispatcher::AfterForkChild()
{
#ifdef BUILD_FOR_TV
  io_service_.notify_fork(boost::asio::io_service::fork_child);
#endif
}

} /* namespace util */
} /* namespace volt */
