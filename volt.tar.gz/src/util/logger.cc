#include "logger.h"

#include <sys/types.h>
#include <unistd.h>
#include <strings.h>

#ifdef USE_LOG4CPLUS
#include <log4cplus/configurator.h>
#else
#include <boost/algorithm/string.hpp>
#endif

namespace volt
{
namespace util
{

#ifdef USE_LOG4CPLUS
#else
Logger::LogLevel Logger::level_ = Logger::kFatal;
#endif

Logger::Logger(const std::string &aName):
#ifdef USE_LOG4CPLUS
  logger_(log4cplus::Logger::getInstance(aName))
#else
  name_(aName)
#endif
{
#if !defined(USE_LOG4CPLUS) && defined(USE_DLOG)
  if (name_.empty())
  {
    name_ = "VOLT";
  }
  else
  {
    /* Make the string to the first dot the tag to be used for dlog. */
    size_t dot = name_.find('.');
    if (dot != std::string::npos) name_.erase(dot);
    boost::to_upper(name_);

    /* Temp: just to make sure we don't have any unwanted non-volt tags */
    if (name_.find("VOLT", 0) != 0)
    {
      fprintf(stderr, "\n\n[%s:%d] Weird name: %s\n\n", __FILE__, __LINE__, name_.c_str());
    }
  }
#endif
}

Logger::~Logger()
{
}

void Logger::Configure(const std::string &aConfigPath)
{
#ifdef USE_LOG4CPLUS
  log4cplus::PropertyConfigurator config(aConfigPath);
  config.configure();
#endif
}

void Logger::SetLogLevel(const LogLevel aLevel)
{
#ifdef USE_LOG4CPLUS
  log4cplus::Logger::getRoot().setLogLevel(Log4CplusLevel(aLevel));
#else
  level_ = aLevel;
#endif
}

const char* Logger::LevelToString(const LogLevel aLevel)
{
  switch(aLevel)
  {
    case kFatal: return "Fatal";
    case kMajor: return "Major";
    case kWarn: return "Warn";
    case kDebug: return "Debug";
    case kInfo: return "Info";
    default: return "???";
  }
}

Logger::LogLevel Logger::StringToLevel(const char *aLevelStr)
{
  if (aLevelStr == NULL) return kFatal;
  else if(strcasecmp(aLevelStr, "major") == 0) return kMajor;
  else if(strcasecmp(aLevelStr, "warn") == 0) return kWarn;
  else if(strcasecmp(aLevelStr, "debug") == 0) return kDebug;
  else if(strcasecmp(aLevelStr, "info") == 0) return kInfo;
  else return kFatal;
}

#ifdef USE_LOG4CPLUS
log4cplus::LogLevel Logger::Log4CplusLevel(const LogLevel aLevel)
{
  switch (aLevel)
  {
    case kMajor: return log4cplus::ERROR_LOG_LEVEL;
    case kWarn: return log4cplus::WARN_LOG_LEVEL;
    case kDebug: return log4cplus::DEBUG_LOG_LEVEL;
    case kInfo: return log4cplus::TRACE_LOG_LEVEL;
    case kFatal:
    default: return log4cplus::FATAL_LOG_LEVEL;
  }
}
#else
void Logger::Log(const char *aFile, const char *aFunc, const unsigned int aLine,
                 const LogLevel aLevel, std::string aMsg) const
{
  time_t time_stamp = time(NULL);
  struct tm tm_buf;
  localtime_r(&time_stamp, &tm_buf);
  char date_buf[20];
  if (strftime(date_buf, 20, "%Y-%m-%dT%H:%M:%S", &tm_buf) == 0) date_buf[0] = '\0';

  const char *file_name = strrchr(aFile, '/') ? strrchr(aFile, '/') + 1 : aFile;

  static const char *fmt = "[Volt|Engine|%s|%lu|%lu|%s:%s:%d] %s\n";

#ifdef USE_DLOG
  log_priority prio = DLOG_VERBOSE;

  switch (aLevel)
  {
    case kFatal:
      prio = DLOG_FATAL;
      break;
    case kMajor:
      prio = DLOG_ERROR;
      break;
    case kWarn:
      prio = DLOG_WARN;
      break;
    case kDebug:
      prio = DLOG_DEBUG;
      break;
    case kInfo:
      prio = DLOG_VERBOSE;
      break;
    default:
      break;
  }

  /* Log every msg.  Filtering is done by dlog/dlogutil. */
  __dlog_print(LOG_ID_MAIN, prio, name_.c_str(), fmt,
               date_buf, getpid(), pthread_self(),
               file_name, aFunc, aLine, aMsg.c_str());
#else
  if (aLevel > level_) return;

  printf(fmt,
         date_buf, getpid(), pthread_self(),
         file_name, aFunc, aLine, aMsg.c_str());
#endif
}
#endif

} /* namespace util */
} /* namespace snap */
