#include "MessageTypes.h"

#include <boost/date_time/posix_time/posix_time.hpp>

#include "MessageCenter.h"

#include "logger.h"

using namespace boost::interprocess;

static volt::util::Logger LOGGER("volt.ipc");

namespace volt
{
namespace util
{
namespace ipc
{

Message::Message():
  type_(MessageType::Invalid()), is_command_(false),
  data_handle_set_(false), data_handle_(), data_size_(0), raw_data_(NULL)
{
  reply_to_[0] = '\0';
}

Message::~Message()
{
}

Message& Message::operator=(const Message &aRhs)
{
  if (this == &aRhs)
  {
    return *this;
  }

  type_ = aRhs.type_;
  memcpy(reply_to_, aRhs.reply_to_, sizeof(reply_to_));
  is_command_ = aRhs.is_command_;
  data_handle_ = aRhs.data_handle_;
  data_handle_set_ = aRhs.data_handle_set_;
  data_size_ = aRhs.data_size_;
  raw_data_ = aRhs.raw_data_;

  return *this;
}

const MessageType& Message::Type() const
{
  return type_;
}

void Message::Type(const MessageType aType)
{
  type_ = aType;
}

const char* Message::ReplyTo() const
{
  return reply_to_;
}

void Message::SetReplyTo(const std::string aReplyTo)
{
  reply_to_[0] = '\0';

  if (aReplyTo.empty())
  {
    return;
  }

  if (aReplyTo.length() > 15)
  {
    LOG_FATAL(LOGGER, "ReplyTo must be less than 16 characters: " << aReplyTo);
    return;
  }

  snprintf(reply_to_, sizeof(reply_to_), "%s", aReplyTo.c_str());
}

bool Message::IsCommand() const
{
  return is_command_;
}

void* Message::GetData() const
{
  void *ret = raw_data_;
  LOG_TRACE(LOGGER, "raw data: " << raw_data_);

  if (data_handle_set_)
  {
    ret = MessageCenter::Instance().GetLocalAddr(data_handle_);
    LOG_TRACE(LOGGER, "data: " << ret << "<-" << data_handle_);
  }

  return ret;
}

size_t Message::GetDataSize() const
{
  return data_size_;
}

bool Message::SetData(void *aData, const size_t aSize)
{
  void *data = MessageCenter::Instance().CreateSharedData(aData, aSize);

  if (data == NULL)
  {
    LOG_FATAL(LOGGER, "Failed to create shared data " <<
              aData << " (" << aSize << " bytes)");
    return false;
  }

  data_handle_ = MessageCenter::Instance().GetSharedHandle(data);
  data_handle_set_ = true;
  LOG_TRACE(LOGGER, "data: " << aData << "->" << data_handle_);

  data_size_ = aSize;

  return true;
}


















Command::Command():
  Message(),
  result_set_(false), result_handle_set(false), result_handle_(), result_size_(0),
  raw_result_(NULL), mutex_(), cond_ready_()
{
  is_command_ = true;
}

Command::~Command()
{
}

Command& Command::operator=(const Command &aRhs)
{
  if (this == &aRhs)
  {
    return *this;
  }

  Message::operator=(aRhs);
  result_set_ = aRhs.result_set_;
  result_handle_set = aRhs.result_handle_set;
  result_handle_ = aRhs.result_handle_;
  result_size_ = aRhs.result_size_;
  raw_result_ = aRhs.raw_result_;
  return *this;
}

Command::ResultPair Command::GetResult(const int aMaxWaitTime)
{
  ResultPair result(NULL, 0);

  if (aMaxWaitTime >= 0)
  {
    try
    {
      boost::posix_time::ptime current = boost::posix_time::microsec_clock::universal_time();
      boost::posix_time::ptime deadline = current + boost::posix_time::milliseconds(aMaxWaitTime);
      LOG_DEBUG(LOGGER, "Current: " << boost::posix_time::to_simple_string(current));
      LOG_DEBUG(LOGGER, "Deadline: " << boost::posix_time::to_simple_string(deadline));
      scoped_lock<interprocess_mutex> lock(mutex_, deadline);

      LOG_TRACE(LOGGER, "Waiting for result");
      bool ready = cond_ready_.timed_wait(lock, deadline,
                                          [this] { return result_set_; });

      if (ready)
      {
        if (result_handle_set)
        {
          result.first = MessageCenter::Instance().GetLocalAddr(result_handle_);
          LOG_TRACE(LOGGER, "result: " << result.first << "<-" << result_handle_);
        }
        else
        {
          result.first = raw_result_;
          LOG_TRACE(LOGGER, "raw result: " << raw_result_);
        }

        result.second = result_size_;
      }
      else
      {
        LOG_WARN(LOGGER, "Failed to get condition in " << aMaxWaitTime << " msec");
        return result;
      }
    }
    catch (lock_exception &e)
    {
      /* Failed to acquire lock */
      LOG_WARN(LOGGER, "Failed to acquire lock in " << aMaxWaitTime << " msec");
      return result;
    }
  }
  else
  {
    scoped_lock<interprocess_mutex> lock(mutex_);
    cond_ready_.wait(lock, [this] { return result_set_; });

    if (result_handle_set)
    {
      result.first = MessageCenter::Instance().GetLocalAddr(result_handle_);
      LOG_TRACE(LOGGER, "result: " << result.first << "<-" << result_handle_);
    }
    else
    {
      result.first = raw_result_;
      LOG_TRACE(LOGGER, "raw result: " << raw_result_);
    }

    result.second = result_size_;
  }

  return result;
}

bool Command::SetResult(void *aResult, const size_t aSize)
{
  {
    scoped_lock<interprocess_mutex> lock(mutex_);
    raw_result_ = NULL;

    if (aResult)
    {
      result_size_ = aSize;

      raw_result_ = aResult;

      if (aResult)
      {
        void *data = MessageCenter::Instance().CreateSharedData(aResult, result_size_);

        if (data == NULL)
        {
          LOG_FATAL(LOGGER, "Failed to create shared data " <<
                    aResult << " (" << result_size_ << " bytes)");
          return false;
        }

        result_handle_ = MessageCenter::Instance().GetSharedHandle(data);
        result_handle_set = true;
        LOG_TRACE(LOGGER, "result: " << aResult << "->" << result_handle_);
      }
    }

    result_set_ = true;
  }
  cond_ready_.notify_one();

  return true;
}

}; /* namespace ipc */
}; /* namespace util */
}; /* namespace volt */
