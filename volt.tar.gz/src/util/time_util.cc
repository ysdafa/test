#include "time_util.h"

#include <iostream>
#include <iomanip>

#include "logger.h"

namespace volt
{
namespace util
{
static Logger LOGGER("volt.util.time");

static Time DefaultNowFunction()
{
#if 0
  struct timeval tv;
  if (gettimeofday(&tv, nullptr) == 0)
  {
    return Time(tv.tv_sec, tv.tv_usec);
  }
  else
  {
    return Time(0, 0);
  }
#else
  struct tm tm;
  time_t curr_ts = time(NULL);

  static uint8_t dst_flag = 0;
  static uint8_t mask_dst_true = 0x01;
  static uint8_t mask_dst_checked = 0x80;
  static uint8_t mask_is_dst = mask_dst_true | mask_dst_checked;

  if ((mask_dst_checked & dst_flag) == 0)
  {
    /* Check for DST by getting the local time. */
    if (localtime_r(&curr_ts, &tm))
    {
      if (tm.tm_isdst)
      {
        LOG_DEBUG(LOGGER, "DST!");
        dst_flag |= mask_dst_true;
      }
    }
    dst_flag |= mask_dst_checked;
  }

  struct timeval tv;
  gettimeofday(&tv, NULL);

  if (gmtime_r(&curr_ts, &tm))
  {
    /* Get UTC/GMT. */
    if ((dst_flag & mask_is_dst) == mask_is_dst)
    {
      /* Adjust for DST. */
      return Time(mktime(&tm) - (60 * 60), tv.tv_usec);
    }
    else
    {
      return Time(mktime(&tm), tv.tv_usec);
    }
  }
  else
  {
    return Time::Epoch();
  }
#endif
}

std::function<Time ()> Time::NowFunction = DefaultNowFunction;

Time::Time():
  time_{0, 0}, valid_(false)
{
}

Time::Time(const time_t aSec, const suseconds_t aUsec):
  time_{aSec, aUsec}, valid_(true)
{
}

Time::Time(const Time &aSrc):
  time_{aSrc.Sec(), aSrc.Usec()}, valid_(aSrc.valid_)
{
}

Time::~Time()
{
}

bool Time::IsValid() const
{
  return valid_;
}

time_t Time::Sec() const
{
  return time_.tv_sec;
}

suseconds_t Time::Usec() const
{
  return time_.tv_usec;
}

bool Time::ParseHttpTime(const std::string &aHttpTime)
{
  /* As per RFC 2616 */
  static const char *rfc1123_format = "%a, %d %b %Y %H:%M:%S GMT";
  static const char *rfc1036_format = "%a, %d-%b-%y %H:%M:%S GMT";
  static const char *asctime_format = "%a %b %d %H:%M:%S %Y";

  valid_ = false;

  struct tm tm;
  if (strptime(aHttpTime.c_str(), rfc1123_format, &tm) == NULL)
  {
    if (strptime(aHttpTime.c_str(), rfc1036_format, &tm) == NULL)
    {
      if (strptime(aHttpTime.c_str(), asctime_format, &tm) == NULL)
      {
        return false;
      }
    }
  }

  time_.tv_sec = mktime(&tm);
  time_.tv_usec = 0;

  valid_ = true;

  LOG_DEBUG(LOGGER, "Parsed " << aHttpTime << ": " << time_.tv_sec << ":" << time_.tv_usec);

  return true;
}

std::string Time::HttpTimeString() const
{
  /* As per RFC 2616 */
  static const char *rfc1123_format = "%a, %d %b %Y %H:%M:%S GMT";

  std::string result;

  time_t sec = time_.tv_sec;
  struct tm tm;
  char buf[64];
  if (localtime_r(&sec, &tm) &&
      strftime(buf, sizeof(buf), rfc1123_format, &tm) != 0)
  {
    result = buf;
  }
  else
  {
    LOG_WARN(LOGGER, "Failed to generated HTTP time string from " << *this);
  }
  return result;
}

Time Time::Epoch()
{
  static Time epoch(0, 0);
  return epoch;
}

Time Time::Now()
{
  return NowFunction();
}

bool Time::operator<(const Time &aRhs) const
{
  return timercmp(&time_, &(aRhs.time_), <);
}

bool Time::operator<=(const Time &aRhs) const
{
  return (*this > aRhs) == false;
}

bool Time::operator>(const Time &aRhs) const
{
  return timercmp(&time_, &(aRhs.time_), >);
}

bool Time::operator>=(const Time &aRhs) const
{
  return (*this < aRhs) == false;
}

bool Time::operator==(const Time &aRhs) const
{
  return (*this != aRhs) == false;
}

bool Time::operator!=(const Time &aRhs) const
{
  return timercmp(&time_, &(aRhs.time_), !=);
}

Time& Time::operator=(const Time &aRhs)
{
  if (this != &aRhs)
  {
    time_ = aRhs.time_;
    valid_ = aRhs.valid_;
  }
  return *this;
}

Time& Time::operator+=(const Time &aRhs)
{
  if (this != &aRhs)
  {
    struct timeval result;
    timeradd(&time_, &(aRhs.time_), &result);
    time_ = result;
  }
  return *this;
}

Time& Time::operator-=(const Time &aRhs)
{
  if (this != &aRhs)
  {
    if (*this < aRhs)
    {
      LOG_WARN(LOGGER, "Reset to epoch since " << *this << " < " << aRhs);
      *this = Epoch();
    }
    else
    {
      struct timeval result;
      timersub(&time_, &(aRhs.time_), &result);
      time_ = result;
    }
  }
  return *this;
}

const Time Time::operator+(const Time &aRhs) const
{
  return (Time(*this) += aRhs);
}

const Time Time::operator-(const Time &aRhs) const
{
  return (Time(*this) -= aRhs);
}

std::ostream& operator<<(std::ostream &aStream, const Time &aTime)
{
  return aStream << aTime.Sec() << "." << std::setprecision(6) << std::fixed << aTime.Usec();
}

std::ostream& operator<<(std::ostream &aStream, const Stopwatch &aStopwatch)
{
  return aStream << std::setprecision(6) << std::fixed << aStopwatch.Elapsed();
}

} /* namespace util */
} /* namespace volt */
