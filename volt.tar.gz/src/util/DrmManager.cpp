#include "DrmManager.h"

#include "logger.h"

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include "appdrm_api.h"
#endif

namespace
{
volt::util::Logger LOGGER;
}

DrmManager& DrmManager::Instance()
{
  static DrmManager singleton;
  return singleton;
}

DrmManager::DrmManager(): license_loaded_(false)
#if defined(BUILD_FOR_TV)
#if defined(GOLFP) || defined(X14) || defined(NT14U)
  , decryptor_()
#elif defined(TIZEN)
  , license_handle_(0)
#endif
#endif
{
}

DrmManager::~DrmManager()
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if (license_handle_ != 0)
  {
    appdrm_release_license(&license_handle_);
  }

  license_handle_ = 0;
#endif
}

bool DrmManager::LoadLicense(const std::string &aLicPath)
{
  if (license_loaded_)
  {
    return true;
  }

  LOG_DEBUG(LOGGER, "Loading license: " << aLicPath);

#if defined(BUILD_FOR_TV)
#if defined(GOLFP) || defined(X14) || defined(NT14U)

  if (decryptor_.get() == NULL)
  {
    decryptor_.reset(new appdrm::AppDrmDecryptor());
    int ret = decryptor_->LoadLicense(aLicPath.c_str());
    LOG_DEBUG(LOGGER, "LoadLicense returned " << ret);

    /* Is this the right return value? */
    if (ret == 0)
    {
      license_loaded_ = true;
      return true;
    }

    LOG_WARN(LOGGER, "Failed to load license: " << aLicPath);
    decryptor_.reset();
  }

  return false;
#elif defined(TIZEN)

  if (appdrm_load_license(aLicPath.c_str(), &license_handle_) == 0)
  {
    LOG_DEBUG(LOGGER, "Loaded license: " << aLicPath);
    license_loaded_ = true;
    return true;
  }
  else
  {
    LOG_WARN(LOGGER, "Failed to load license: " << aLicPath);
    return false;
  }

#endif
#else
  return false;
#endif
}

bool DrmManager::LicenseLoaded() const
{
  return license_loaded_;
}

bool DrmManager::DecryptFile(const std::string &aPath,
                             unsigned char * &aData, int &aSize)
{
  if (LicenseLoaded() == false)
  {
    LOG_WARN(LOGGER, "License not loaded yet: " << aPath);
    return false;
  }

#if defined(BUILD_FOR_TV)
#if defined(GOLFP) || defined(X14) || defined(NT14U)
  LOG_DEBUG(LOGGER, "Decrypting file: " << aPath);

  if (decryptor_->DecryptSPM(aPath.c_str(), &aData, &aSize) != 0)
  {
    LOG_WARN(LOGGER, "Failed to decrypt file: " << aPath);
    return false;
  }

  return true;
#elif defined(TIZEN)

  if (appdrm_decrypt_spm(&license_handle_, aPath.c_str(), &aData, &aSize) != 0)
  {
    LOG_WARN(LOGGER, "Failed to decrypt file: " << aPath);
    return false;
  }

  return true;
#endif
#else
  return false;
#endif
}
