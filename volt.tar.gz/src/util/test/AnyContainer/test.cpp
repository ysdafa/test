#include "AnyContainer.h"

void print_list(const AnyList &aList, const std::string &aIndent = "");

void print_map(const AnyMap &aMap, const std::string &aIndent = "")
{
  std::vector<std::string> keys;

  int ival;
  std::string sval;
  std::pair<size_t, uint8_t *> bval;
  AnyList lval;
  AnyMap mval;

for (auto key: aMap.GetKeys(keys))
  {
    if (aMap.Get<int>(key, ival))
    {
      printf("%s%s:int = %d\n", aIndent.c_str(), key.c_str(), ival);
    }
    else if (aMap.Get<std::string>(key, sval))
    {
      printf("%s%s:string = %s\n", aIndent.c_str(), key.c_str(), sval.c_str());
    }
    else if (aMap.Get<std::pair<size_t, uint8_t *>>(key, bval))
    {
      printf("%s%s:bytes = %lu:", aIndent.c_str(), key.c_str(), bval.first);

      for (size_t index = 0; index < bval.first; ++index)
      {
        printf("%02x ", bval.second[index]);
      }

      printf("\n");

    }
    else if (aMap.Get<AnyMap>(key, mval))
    {
      printf("%s%s:map\n", aIndent.c_str(), key.c_str());
      print_map(mval, aIndent + "  ");
    }
    else if (aMap.Get<AnyList>(key, lval))
    {
      printf("%s%s:list\n", aIndent.c_str(), key.c_str());
      print_list(lval, aIndent + "  ");
    }
    else
    {
      printf("%sUnknown type: %s\n", aIndent.c_str(), key.c_str());
    }
  }
}

void print_list(const AnyList &aList, const std::string &aIndent)
{
  std::vector<std::string> keys;

  int ival;
  std::string sval;
  std::pair<size_t, uint8_t *> bval;
  AnyList lval;
  AnyMap mval;

  for (size_t index = 0; index < aList.Size(); ++index)
  {
    if (aList.Get<int>(index, ival))
    {
      printf("%s%lu:int = %d\n", aIndent.c_str(), index, ival);
    }
    else if (aList.Get<std::string>(index, sval))
    {
      printf("%s%lu:string = %s\n", aIndent.c_str(), index, sval.c_str());
    }
    else if (aList.Get<std::pair<size_t, uint8_t *>>(index, bval))
    {
      printf("%s%lu:bytes = %lu:", aIndent.c_str(), index, bval.first);

      for (size_t index = 0; index < bval.first; ++index)
      {
        printf("%02x ", bval.second[index]);
      }

      printf("\n");
    }
    else if (aList.Get<AnyMap>(index, mval))
    {
      printf("%s%lu:map\n", aIndent.c_str(), index);
      print_map(mval, aIndent + "  ");
    }
    else if (aList.Get<AnyList>(index, lval))
    {
      printf("%s%lu:list\n", aIndent.c_str(), index);
      print_list(lval, aIndent + "  ");
    }
    else
    {
      printf("%sUnknown type: %lu\n", aIndent.c_str(), index);
    }
  }
}

int main(int argc, char **argv)
{
  AnyMap map1;
  map1.Insert<std::string>("first", "abc");
  map1.Insert<std::string>("second", "def");
  map1.Insert<std::string>("third", "ghi");

  AnyMap map2;
  map2.Insert<std::string>("hello", "world");
  map2.Insert<std::string>("hey", "you");
  map2.Insert<std::string>("whatta", "heck");

  AnyList list1;
  list1.Add<std::string>("jkl");
  list1.Add<std::string>("mno");
  list1.Add<AnyMap>(map2);
  list1.Add<std::string>("pqr");

  std::pair<size_t, uint8_t *> bytes(4, new uint8_t[4]);

  for (size_t index = 0; index < bytes.first; ++index)
  {
    bytes.second[index] = index;
  }

  list1.Add<std::pair<size_t, uint8_t *>>(bytes);

  map1.Insert<AnyList>("list", list1);

  std::pair<size_t, uint8_t *> bytes2(2, new uint8_t[2]);
  bytes2.second[0] = 0xab;
  bytes2.second[1] = 0xcd;

  map1.Insert<std::pair<size_t, uint8_t *>>("bytes", bytes2);

  print_map(map1);

  return 0;
}
