#include "logger.h"
#include "MessageCenter.h"
#include "TaskDispatcher.h"

#include <boost/serialization/vector.hpp>
#include <boost/serialization/export.hpp>
#include <vector>
#include <iostream>

using namespace volt::util;
using namespace volt::util::ipc;

static Logger LOGGER("test.ipc");

static int SHM_SIZE = 1000000;
static char SHM_NAME[128];

static int SHM_Q_SIZE = 1000;

static int NUM_LOAD = 100000;
static int NUM_RECV = 0;

DEFINE_MSG_GROUP_BEGIN(CustomMsgGroup);
ADD_MSG_GROUP(CustomMsgGroup, Group1, 1);
ADD_MSG_GROUP(CustomMsgGroup, Group2, 2);
DEFINE_MSG_GROUP_END(CustomMsgGroup);

DEFINE_MSG_TYPE_BEGIN(CustomMsgType);
ADD_MSG_TYPE(CustomMsgType, NoData, CustomMsgGroup::Group1(), 1);
ADD_MSG_TYPE(CustomMsgType, WithInput, CustomMsgGroup::Group1(), 2);
ADD_MSG_TYPE(CustomMsgType, WithOutput, CustomMsgGroup::Group1(), 3);
ADD_MSG_TYPE(CustomMsgType, WithInputOutput, CustomMsgGroup::Group1(), 4);
ADD_MSG_DEF_TYPE(CustomMsgType, End, 5);
DEFINE_MSG_TYPE_END(CustomMsgType);

DEFINE_MSG_TYPE_BEGIN(CustomMsgType2);
ADD_MSG_TYPE(CustomMsgType2, NoData, CustomMsgGroup::Group2(), 1);
ADD_MSG_TYPE(CustomMsgType2, WithInput, CustomMsgGroup::Group2(), 2);
ADD_MSG_TYPE(CustomMsgType2, WithOutput, CustomMsgGroup::Group2(), 3);
ADD_MSG_TYPE(CustomMsgType2, WithInputOutput, CustomMsgGroup::Group2(), 4);
DEFINE_MSG_TYPE_END(CustomMsgType2);

class BaseData
{
  public:
    BaseData(): name("BaseData"), text(), strings() {}
    virtual ~BaseData() {}

    std::string name;
    std::string text;
    std::vector<std::string> strings;

    void Print() const
    {
      printf("Name: %s\n", name.c_str());
      printf("Text: %s\n", text.c_str());

      for (unsigned int index = 0; index < strings.size(); ++index)
      {
        printf("String[%d]: %s\n", index, strings[index].c_str());
      }
    }

    friend std::ostream& operator<<(std::ostream &aOstream,
                                    const BaseData &aObj)
    {
      aOstream << "name(" << aObj.name << ") ";
      aOstream << "text(" << aObj.text << ") ";

      for (unsigned int index = 0; index < aObj.strings.size(); ++index)
      {
        aOstream << "strings[" << index << "](" << aObj.strings[index] << ") ";
      }

      return aOstream;
    }

  private:
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive& aArchive, const unsigned int aVersion)
    {
      LOG_DEBUG(LOGGER, "Serializing/Unserializing BaseData...");

      aArchive & text;
      aArchive & strings;
    }
};

class DerivedData : public BaseData
{
  public:
    DerivedData(): BaseData()
    {
      name = "DerivedData";
    }
    virtual ~DerivedData() {}

    std::string extra_string;

    friend std::ostream& operator<<(std::ostream &aOstream,
                                    const DerivedData &aObj)
    {
      return operator<<(aOstream, static_cast<BaseData>(aObj))
             << " extra_string(" << aObj.extra_string << ") ";
      return aOstream;
    }

  private:
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive& aArchive, const unsigned int aVersion)
    {
      LOG_DEBUG(LOGGER, "Serializing/Unserializing DerivedData...");

      /* Serialize base class first */
      aArchive & boost::serialization::base_object<BaseData>(*this);

      aArchive & extra_string;
    }
};

/* MUST export for polymorphism to work. */
BOOST_CLASS_EXPORT_GUID(DerivedData, "DerivedData")

void register_handlers(const char *aQueue)
{
  MessageCenter::Instance().RegisterHandler(aQueue,
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received default handler: " << *aMsg);
    ++NUM_RECV;
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType::NoData(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType::NoData: " << *aMsg);
    ++NUM_RECV;

    if (aMsg->IsCommand())
    {
      Command *cmd = static_cast<Command *>(aMsg);
      cmd->SetResult(NULL, 0);
    }
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType::WithInput(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType::WithInput: " << *aMsg);
    ++NUM_RECV;

    BaseData *obj;
    Unserialize(obj, static_cast<char *>(aMsg->GetData()), aMsg->GetDataSize());

    DerivedData *derived = dynamic_cast<DerivedData *>(obj);

    if (derived)
    {
      LOG_DEBUG(LOGGER, "  with data: " << *obj);
    }

    if (aMsg->IsCommand())
    {
      Command *cmd = static_cast<Command *>(aMsg);
      cmd->SetResult(NULL, 0);
    }
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType::WithOutput(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType::WithOutput: " << *aMsg);
    ++NUM_RECV;
    Command *cmd = static_cast<Command *>(aMsg);
    DerivedData result;
    result.text = "this is a result of CustomMsgType::WithOutput command";
    BufferType buffer;

    if (Serialize(result, buffer))
    {
      cmd->SetResult(&buffer[0], buffer.size());
    }
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType::WithInputOutput(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType::WithInputOutput: " << *aMsg);
    ++NUM_RECV;

    BaseData *obj;
    Unserialize(obj, static_cast<char *>(aMsg->GetData()), aMsg->GetDataSize());

    LOG_DEBUG(LOGGER, "  with data: " << *obj);

    Command *cmd = static_cast<Command *>(aMsg);
    DerivedData result;
    result.text = "this is a result of CustomMsgType::WithInputOutput command";
    BufferType buffer;

    if (Serialize(result, buffer))
    {
      cmd->SetResult(&buffer[0], buffer.size());
    }
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType::End(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType::End: " << *aMsg);
    ++NUM_RECV;
    MessageCenter::Instance().StopMainLoops();
  });




  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType2::NoData(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType2::NoData: " << *aMsg);
    ++NUM_RECV;

    if (aMsg->IsCommand())
    {
      Command *cmd = static_cast<Command *>(aMsg);
      cmd->SetResult(NULL, 0);
    }
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType2::WithInput(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType2::WithInput: " << *aMsg);
    ++NUM_RECV;

    BaseData *obj;
    Unserialize(obj, static_cast<char *>(aMsg->GetData()), aMsg->GetDataSize());

    DerivedData *derived = dynamic_cast<DerivedData *>(obj);

    if (derived)
    {
      LOG_DEBUG(LOGGER, "  with data: " << *obj);
    }

    if (aMsg->IsCommand())
    {
      Command *cmd = static_cast<Command *>(aMsg);
      cmd->SetResult(NULL, 0);
    }
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType2::WithOutput(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType2::WithOutput: " << *aMsg);
    ++NUM_RECV;
    Command *cmd = static_cast<Command *>(aMsg);
    DerivedData result;
    result.text = "this is a result of CustomMsgType2::WithOutput command";
    BufferType buffer;

    if (Serialize(result, buffer))
    {
      cmd->SetResult(&buffer[0], buffer.size());
    }
  });

  MessageCenter::Instance().RegisterHandler(aQueue, CustomMsgType2::WithInputOutput(),
      [](Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Received CustomMsgType2::WithInputOutput: " << *aMsg);
    ++NUM_RECV;

    BaseData *obj;
    Unserialize(obj, static_cast<char *>(aMsg->GetData()), aMsg->GetDataSize());

    LOG_DEBUG(LOGGER, "  with data: " << *obj);

    Command *cmd = static_cast<Command *>(aMsg);
    DerivedData result;
    result.text = "this is a result of CustomMsgType2::WithInputOutput command";
    BufferType buffer;

    if (Serialize(result, buffer))
    {
      cmd->SetResult(&buffer[0], buffer.size());
    }
  });
}

void writer()
{
  LOG_FATAL(LOGGER, "SHM_SIZE: " << SHM_SIZE);
  LOG_FATAL(LOGGER, "SHM_Q_SIZE: " << SHM_Q_SIZE);

  TaskDispatcher::Instance().Initialize();

  MessageCenter::Instance().Initialize(SHM_NAME, SHM_SIZE);

  LOG_DEBUG(LOGGER, "Page size: " << MessageCenter::Instance().PageSize());
  LOG_DEBUG(LOGGER, "sizeof(Message): " << sizeof(Message));

  MessageCenter::Instance().CreateNamedQueue("WriterQueue", SHM_Q_SIZE);
  MessageCenter::Instance().CreateNamedQueue("ReaderQueue", SHM_Q_SIZE);

  register_handlers("WriterQueue");

  MessageCenter::Instance().StartMainLoopThread("WriterQueue");

  LOG_DEBUG(LOGGER, "Send CustomMsgType::NoData");
  MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType::NoData());

  BaseData *derived = new DerivedData();
  derived->text = "This is a test string for a derived serializable object";
  derived->strings.push_back("String 1 derived");
  static_cast<DerivedData *>(derived)->extra_string = "This an extra string in the derived class";

  LOG_DEBUG(LOGGER, "Send CustomMsgType::WithInput: " << *derived);

  BufferType buffer;

  if (Serialize(derived, buffer))
  {
    MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType::WithInput(),
                                          &buffer[0], buffer.size());
  }
  else
  {
    LOG_DEBUG(LOGGER, "Failed to serialize!");
  }

  LOG_DEBUG(LOGGER, "Send CustomMsgType::WithOutput");
  MessageCenter::Instance().ExecuteCommand("ReaderQueue", 1000, CustomMsgType::WithOutput(),
      [] (void *aResult, const size_t aSize)
  {
    LOG_DEBUG(LOGGER, "Waiting for output");
    DerivedData result;
    Unserialize(result, static_cast<char *>(aResult), aSize);
    LOG_DEBUG(LOGGER, "Got output: " << result);
  });

  derived->strings.push_back("String 2 derived");

  LOG_DEBUG(LOGGER, "Send CustomMsgType::WithInputOutput: " << *derived);

  if (Serialize(derived, buffer))
  {
    MessageCenter::Instance().ExecuteCommand("ReaderQueue", CustomMsgType::WithInputOutput(),
        [] (void *aResult, const size_t aSize)
    {
      LOG_DEBUG(LOGGER, "Waiting for output");
      DerivedData result;
      Unserialize(result, static_cast<char *>(aResult), aSize);
      LOG_DEBUG(LOGGER, "Got output: " << result);
    }, &buffer[0], buffer.size());
  }
  else
  {
    LOG_DEBUG(LOGGER, "Failed to serialize!");
  }




  LOG_DEBUG(LOGGER, "Send CustomMsgType2::NoData");
  MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType2::NoData());

  derived->text = "This is a test string for a derived serializable object";
  derived->strings.push_back("String 3 derived");
  static_cast<DerivedData *>(derived)->extra_string = "This an extra string in the derived class";

  LOG_DEBUG(LOGGER, "Send CustomMsgType2::WithInput: " << *derived);

  if (Serialize(derived, buffer))
  {
    MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType2::WithInput(),
                                          &buffer[0], buffer.size());
  }
  else
  {
    LOG_DEBUG(LOGGER, "Failed to serialize!");
  }

  LOG_DEBUG(LOGGER, "Send CustomMsgType2::WithOutput");
  MessageCenter::Instance().ExecuteCommand("ReaderQueue", 1000, CustomMsgType2::WithOutput(),
      [] (void *aResult, const size_t aSize)
  {
    LOG_DEBUG(LOGGER, "Waiting for output");
    DerivedData result;
    Unserialize(result, static_cast<char *>(aResult), aSize);
    LOG_DEBUG(LOGGER, "Got output: " << result);
  });

  derived->strings.push_back("String 4 derived");

  LOG_DEBUG(LOGGER, "Send CustomMsgType2::WithInputOutput: " << *derived);

  if (Serialize(derived, buffer))
  {
    MessageCenter::Instance().ExecuteCommand("ReaderQueue", CustomMsgType2::WithInputOutput(),
        [] (void *aResult, const size_t aSize)
    {
      LOG_DEBUG(LOGGER, "Waiting for output");
      DerivedData result;
      Unserialize(result, static_cast<char *>(aResult), aSize);
      LOG_DEBUG(LOGGER, "Got output: " << result);
    }, &buffer[0], buffer.size());
  }
  else
  {
    LOG_DEBUG(LOGGER, "Failed to serialize!");
  }

  MessageCenter::Instance().FlushMessages("WriterQueue", 2000);

  LOG_DEBUG(LOGGER, "Send CustomMsgType::End");
  MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType::End());

  MessageCenter::Instance().JoinMainLoopThreads();
}

static const unsigned LOAD_POST = 0x1;
static const unsigned LOAD_EXEC = 0x2;
static const unsigned LOAD_2POST = 0x4;

void load_writer(const unsigned aLoadType = LOAD_POST)
{
  LOG_FATAL(LOGGER, "SHM_SIZE: " << SHM_SIZE);
  LOG_FATAL(LOGGER, "SHM_Q_SIZE: " << SHM_Q_SIZE);
  LOG_FATAL(LOGGER, "NUM_LOAD: " << NUM_LOAD);

  int num_sent = 0;

  TaskDispatcher::Instance().Initialize();

  MessageCenter::Instance().Initialize(SHM_NAME, SHM_SIZE);

  LOG_DEBUG(LOGGER, "Page size: " << MessageCenter::Instance().PageSize());
  LOG_DEBUG(LOGGER, "sizeof(Message): " << sizeof(Message));

  MessageCenter::Instance().CreateNamedQueue("WriterQueue", SHM_Q_SIZE);
  MessageCenter::Instance().CreateNamedQueue("ReaderQueue", SHM_Q_SIZE);

  register_handlers("WriterQueue");

  MessageCenter::Instance().StartMainLoopThread("WriterQueue");

  BaseData *derived = new DerivedData();
  derived->text = "This is a test string for a derived serializable object";
  derived->strings.push_back("String 1 derived");
  static_cast<DerivedData *>(derived)->extra_string = "This an extra string in the derived class";

  MessageCenter::ResultHandler result_handler = [] (void *, const size_t) {};

  struct timeval start;
  gettimeofday(&start, NULL);

  for (int loop = 0; loop < NUM_LOAD; ++loop)
  {
    LOG_DEBUG(LOGGER, "Send CustomMsgType::WithInput: " << *derived);

    BufferType buffer;

    if (Serialize(derived, buffer))
    {
      if (aLoadType & LOAD_POST)
      {
        MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType::WithInput(),
                                              &buffer[0], buffer.size());
        ++num_sent;
      }

      if (aLoadType & LOAD_2POST)
      {
        MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType::WithInput(),
                                              &buffer[0], buffer.size());
        ++num_sent;
        MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType::WithInput(),
                                              &buffer[0], buffer.size());
        ++num_sent;
      }

      if (aLoadType & LOAD_EXEC)
      {
        MessageCenter::Instance().ExecuteCommand("ReaderQueue", CustomMsgType::WithInput(),
            result_handler,
            &buffer[0], buffer.size());
        ++num_sent;
      }
    }
    else
    {
      LOG_DEBUG(LOGGER, "Failed to serialize!");
    }
  }

  MessageCenter::Instance().FlushMessages("WriterQueue", 2000);

  struct timeval end;
  gettimeofday(&end, NULL);

  struct timeval diff;
  timersub(&end, &start, &diff);

  double elapsed = diff.tv_sec + diff.tv_usec / 1000000.0;
  LOG_FATAL(LOGGER, "Sent " << num_sent << " msg in " << elapsed << " sec");

  LOG_DEBUG(LOGGER, "Send CustomMsgType::End");
  MessageCenter::Instance().PostMessage("ReaderQueue", CustomMsgType::End());

  MessageCenter::Instance().JoinMainLoopThreads();
}

void reader()
{
  TaskDispatcher::Instance().Initialize();

  while (MessageCenter::Instance().Attach(SHM_NAME) == false)
  {
    LOG_WARN(LOGGER, "Failed to attach; retry");
    usleep(1000);
  }

  MessageCenter::Instance().CreateNamedQueue("WriterQueue", SHM_Q_SIZE);
  MessageCenter::Instance().CreateNamedQueue("ReaderQueue", SHM_Q_SIZE);

  register_handlers("ReaderQueue");

  struct timeval start;
  gettimeofday(&start, NULL);

  MessageCenter::Instance().StartMainLoop("ReaderQueue");

  struct timeval end;
  gettimeofday(&end, NULL);

  struct timeval diff;
  timersub(&end, &start, &diff);

  double elapsed = diff.tv_sec + diff.tv_usec / 1000000.0;
  LOG_FATAL(LOGGER, "Handled " << NUM_RECV << " msg in " << elapsed << " sec");
}

void fork_and_run(const bool aLoad = false, const unsigned aLoadType = LOAD_POST)
{
  pid_t child_pid = -1;

  if ((child_pid = fork()) > 0)
  {
    /* parent */
    LOG_DEBUG(LOGGER, "Writer Process");

    if (aLoad)
    {
      load_writer(aLoadType);
    }
    else
    {
      writer();
    }
  }
  else if (child_pid == 0)
  {
    /* child */
    LOG_DEBUG(LOGGER, "Reader Process");
    reader();
  }
  else
  {
    /* error */
  }
}

void test_serialize()
{
  BaseData src_obj;
  src_obj.text = "This is a test string for a serializable object";
  src_obj.strings.push_back("String 1");
  src_obj.strings.push_back("String 2");
  src_obj.strings.push_back("String 3");
  src_obj.strings.push_back("String 4");

  src_obj.Print();

  BufferType buffer;
  Serialize(src_obj, buffer);

  BaseData dst_obj;
  Unserialize(dst_obj, buffer);

  dst_obj.Print();
}

int main(int argc, char **argv)
{
  Logger::Configure("../log4cplus.conf");

  MessageCenter::PrepareInstance();

#if 0
  test_serialize();
  exit(EXIT_SUCCESS);
#endif

  snprintf(SHM_NAME, sizeof(SHM_NAME), "Test-%d", getpid());

#if 0
  /* Clean shm */
  MessageCenter::Instance().Attach(SHM_NAME);
  MessageCenter::Instance().Destroy();
#else

  if (argc > 2 && strcmp(argv[1], "writer") == 0)
  {
    printf("Using MessageCenter: %s\n", SHM_NAME);
    LOG_DEBUG(LOGGER, "Writer Process");
    writer();
  }
  else if (argc > 2 && strcmp(argv[1], "reader") == 0)
  {
    snprintf(SHM_NAME, sizeof(SHM_NAME), "%s", argv[2]);
    printf("Using MessageCenter: %s\n", SHM_NAME);
    LOG_DEBUG(LOGGER, "Reader Process");
    reader();
  }
  else if (argc > 2 && strcmp(argv[1], "load") == 0)
  {
    if (argc > 2)
    {
      NUM_LOAD = atoi(argv[2]);
    }

    if (argc > 3)
    {
      SHM_SIZE = atoi(argv[3]);
    }

    if (argc > 4)
    {
      SHM_Q_SIZE = atoi(argv[4]);
    }

    fork_and_run(true);
  }
  else if (argc > 2 && strcmp(argv[1], "load-exec") == 0)
  {
    if (argc > 2)
    {
      NUM_LOAD = atoi(argv[2]);
    }

    if (argc > 3)
    {
      SHM_SIZE = atoi(argv[3]);
    }

    if (argc > 4)
    {
      SHM_Q_SIZE = atoi(argv[4]);
    }

    fork_and_run(true, LOAD_EXEC);
  }
  else if (argc > 2 && strcmp(argv[1], "load-post-exec") == 0)
  {
    if (argc > 2)
    {
      NUM_LOAD = atoi(argv[2]);
    }

    if (argc > 3)
    {
      SHM_SIZE = atoi(argv[3]);
    }

    if (argc > 4)
    {
      SHM_Q_SIZE = atoi(argv[4]);
    }

    fork_and_run(true, LOAD_POST | LOAD_EXEC);
  }
  else if (argc > 2 && strcmp(argv[1], "load-post-post-exec") == 0)
  {
    if (argc > 2)
    {
      NUM_LOAD = atoi(argv[2]);
    }

    if (argc > 3)
    {
      SHM_SIZE = atoi(argv[3]);
    }

    if (argc > 4)
    {
      SHM_Q_SIZE = atoi(argv[4]);
    }

    fork_and_run(true, LOAD_2POST | LOAD_EXEC);
  }
  else
  {
    if (argc > 1)
    {
      SHM_SIZE = atoi(argv[1]);
    }

    if (argc > 2)
    {
      SHM_Q_SIZE = atoi(argv[2]);
    }

    fork_and_run(false);
  }

#endif

  return 0;
}
