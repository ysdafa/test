#ifndef VOLT_UTIL_LOGGER_H
#define VOLT_UTIL_LOGGER_H

#include <cstddef>
#include <string>

#ifdef USE_LOG4CPLUS
#include <log4cplus/helpers/threads.h>
#include <log4cplus/logger.h>
#else
#include <sstream>

#ifdef USE_DLOG
#include <dlog.h>
#endif
#endif
#include <unistd.h>

namespace volt
{
namespace util
{


#ifdef USE_LOG4CPLUS
#define LOG_TRACE(logger, msg) LOG4CPLUS_TRACE((logger).GetLogger(), msg)
#define LOG_DEBUG(logger, msg) LOG4CPLUS_DEBUG((logger).GetLogger(), msg)
#define LOG_INFO(logger, msg) LOG4CPLUS_INFO((logger).GetLogger(), msg)
#define LOG_WARN(logger, msg) LOG4CPLUS_WARN((logger).GetLogger(), msg)
#define LOG_ERROR(logger, msg) LOG4CPLUS_ERROR((logger).GetLogger(), msg)
#define LOG_FATAL(logger, msg) LOG4CPLUS_FATAL((logger).GetLogger(), msg)
#else
#define LOG_TRACE(logger, msg) if(volt::util::Logger::IsInfoEnable()) do { \
  LOG_WRITE((logger), volt::util::Logger::kInfo, msg); \
} while(0)
#define LOG_DEBUG(logger, msg) if(volt::util::Logger::IsDebugEnable()) do { \
  LOG_WRITE((logger), volt::util::Logger::kDebug, msg); \
} while(0)
#define LOG_INFO(logger, msg) if(volt::util::Logger::IsInfoEnable()) do { \
  LOG_WRITE((logger), volt::util::Logger::kInfo, msg); \
} while(0)
#define LOG_WARN(logger, msg) if(volt::util::Logger::IsWarnEnable()) do { \
  LOG_WRITE((logger), volt::util::Logger::kWarn, msg); \
} while(0)
#define LOG_ERROR(logger, msg) if(volt::util::Logger::IsMajorEnable()) do { \
  LOG_WRITE((logger), volt::util::Logger::kMajor, msg); \
} while(0)
#define LOG_FATAL(logger, msg) if(volt::util::Logger::IsFatalEnable()) do { \
  LOG_WRITE((logger), volt::util::Logger::kFatal, msg); \
} while(0)

#define LOG_TRACE_APP(logger, msg) if(volt::util::Logger::IsInfoEnableApp()) do { \
  LOG_WRITE((logger), volt::util::Logger::kInfo, msg); \
} while(0)
#define LOG_DEBUG_APP(logger, msg) if(volt::util::Logger::IsDebugEnableApp()) do { \
  LOG_WRITE((logger), volt::util::Logger::kDebug, msg); \
} while(0)
#define LOG_INFO_APP(logger, msg) if(volt::util::Logger::IsInfoEnableApp()) do { \
  LOG_WRITE((logger), volt::util::Logger::kInfo, msg); \
} while(0)
#define LOG_WARN_APP(logger, msg) if(volt::util::Logger::IsWarnEnableApp()) do { \
  LOG_WRITE((logger), volt::util::Logger::kWarn, msg); \
} while(0)
#define LOG_ERROR_APP(logger, msg) if(volt::util::Logger::IsMajorEnableApp()) do { \
  LOG_WRITE((logger), volt::util::Logger::kMajor, msg); \
} while(0)
#define LOG_FATAL_APP(logger, msg) if(volt::util::Logger::IsFatalEnable()) do { \
  LOG_WRITE((logger), volt::util::Logger::kFatal, msg); \
} while(0)



#define LOG_WRITE(logger, level, msg) do { \
  std::ostringstream os; \
  os << msg; \
  (logger).Log(__FILE__, __func__, __LINE__, (level), os.str()); \
} while(0)
#endif

#define LOG_PATH "/opt/down/panels/volt_log"
class Logger
{
  public:
    enum LogLevel { kFatal, kMajor, kWarn, kDebug, kInfo };

  public:
    Logger(const std::string &aName = "");
    virtual ~Logger();

    static void Configure(const std::string &aConfigPath);

    static void SetLogLevel(const LogLevel aLevel);

    static const char* LevelToString(const LogLevel aLevel);

    static LogLevel StringToLevel(const char *aLevelStr);

    inline static bool IsDebugEnable() { return (access(LOG_PATH, F_OK) == 0);};

    inline static bool IsInfoEnable() { return (access(LOG_PATH, F_OK) == 0);};

    inline static bool IsWarnEnable() { return (access(LOG_PATH, F_OK) == 0);};

    inline static bool IsMajorEnable() { return true;};

    inline static bool IsFatalEnable() { return true;};

    static bool IsDebugEnableApp() { return true; };

    static bool IsInfoEnableApp() { return true; };

    static bool IsWarnEnableApp() { return true; };

    static bool IsMajorEnableApp() { return true; };

    static bool IsFatalEnableApp() { return true; };	

#ifdef USE_LOG4CPLUS
    log4cplus::Logger GetLogger() const
    {
      return logger_;
    }

    static log4cplus::LogLevel Log4CplusLevel(const LogLevel aLevel);
#else
    void Log(const char *aFile, const char *aFunc, const unsigned int aLine,
             const LogLevel aLevel, std::string aMsg) const;
#endif

  private:
#ifdef USE_LOG4CPLUS
    log4cplus::Logger logger_;
#else
    std::string name_;
    static LogLevel level_;
#endif
};

} /* namespace util */
} /* namespace volt */

#endif /* VOLT_UTIL_LOGGER_H */
