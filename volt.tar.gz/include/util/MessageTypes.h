#ifndef MESSAGE_TYPES_H
#define MESSAGE_TYPES_H

#include <stdint.h>
#include <stdlib.h>
#include <iostream>

#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/interprocess/sync/interprocess_mutex.hpp>
#include <boost/interprocess/sync/interprocess_condition.hpp>

#include <boost/serialization/vector.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/iostreams/device/back_inserter.hpp>

/**
 * Utility macros to simplify defining custom MessageType classes.
 * Custom MessageType definitions starts with one DEFINE_MSG_BEGIN, one or
 * more of ADD_MSG_TYPE, and ending with DEFINE_MSG_END.
 * @param[in] class_name Name of the derived MessageType class.
 * @param[in] name Name of the new message type.
 * @param[in] val Integer value of the new message type.
 */
#define DEFINE_MSG_GROUP_BEGIN(class_name) \
  class class_name : public volt::util::ipc::MessageGroup {

#define ADD_MSG_GROUP(class_name, name, val) \
  public: \
    static const MessageGroup& name() \
    { static class_name singleton(val); return singleton; }

#define DEFINE_MSG_GROUP_END(class_name) \
  protected: \
    class_name(const uint16_t aVal): MessageGroup(aVal) {} \
  }

#define DEFINE_MSG_TYPE_BEGIN(class_name) \
  class class_name : public volt::util::ipc::MessageType {

#define ADD_MSG_TYPE(class_name, name, group, val) \
  public: \
    static const MessageType& name() \
    { static class_name singleton((group), (val)); return singleton; }

#define ADD_MSG_DEF_TYPE(class_name, name, val) \
  public: \
    static const MessageType& name() \
    { static class_name singleton((val)); return singleton; }

#define DEFINE_MSG_TYPE_END(class_name) \
  protected: \
    class_name(const uint16_t aVal): MessageType(aVal) {} \
    class_name(const volt::util::ipc::MessageGroup& aGroup, \
               const uint16_t aVal): MessageType(aGroup, aVal) {} \
  }

namespace volt
{
namespace util
{
namespace ipc
{

/** Type of the buffer to store serialized data. */
typedef std::vector<char> BufferType;

/**
 * Utility function to serialize an object to the supplied buffer.
 *
 * @param[in] aObj Object to serialize.  It must implement the "serialize"
 *                 function as per the boost::serialization library.
 * @param[out] aBuffer Buffer to write serialized data.
 *
 * @return true on success, false otherwise.
 */
template <typename Type>
bool Serialize(const Type &aObj, BufferType &aBuffer)
{
  aBuffer.clear();

  try
  {
    boost::iostreams::stream<boost::iostreams::back_insert_device<BufferType>> output_stream(aBuffer);
    boost::archive::binary_oarchive oa(output_stream);

    oa << aObj;
    output_stream.flush();

    return true;
  }
  catch (std::exception &e)
  {
    // TBD remove this throw for production
    throw;
    return false;
  }
}

/**
 * Utility function to unserialize an object from the supplied buffer.
 *
 * @param[out] aObj Object to unserialize data to.  It must implement the
 *                  "serialize" function as per the boost::serialization
 *                  library.
 * @param[in] aBuffer Buffer to read serialized data.
 * @param[int] aSize Size of the buffer.
 *
 * @return true on success, false otherwise.
 */
template <typename Type>
bool Unserialize(Type &aObj, const char *aBuffer, const size_t aSize)
{
  try
  {
    boost::iostreams::basic_array_source<char> source(aBuffer, aSize);
    boost::iostreams::stream<boost::iostreams::basic_array_source<char>> input_stream(source);
    boost::archive::binary_iarchive ia(input_stream);

    ia >> aObj;

    return true;
  }
  catch (std::exception &e)
  {
    return false;
  }
}

/**
 * Utility function to unserialize an object from the supplied buffer.
 *
 * @param[out] aObj Object to unserialize data to.  It must implement the
 *                  "serialize" function as per the boost::serialization
 *                  library.
 * @param[in] aBuffer Buffer to read serialized data.
 *
 * @return true on success, false otherwise.
 */
template <typename Type>
bool Unserialize(Type &aObj, const BufferType &aBuffer)
{
  return Unserialize(aObj, &aBuffer[0], aBuffer.size());
}

/**
 * Class defining a number of message groups.
 * MessageTypes (declared below) can be associated with a MessageGroup to
 * allow message filtering based on the group a message belong to.
 */
class MessageGroup
{
  public:
    /* All MessageGroup classes have Invalid type.
     * Use the DEFINE_MSG_GROUP_BEGIN, ADD_MSG_GROUP, DEFINE_MSG_GROUP_END
     * macros to add custom message types. */

    static const MessageGroup& Invalid()
    {
      static MessageGroup singleton(0xffff);
      return singleton;
    }

    /** Default message group. */
    static const MessageGroup& Default()
    {
      static MessageGroup singleton(0);
      return singleton;
    }

    /**
     * Integer value of the message type.
     * @return Integer value of of the message type.
     */
    uint16_t Value() const
    {
      return val_;
    }

    bool operator==(const MessageGroup &aRhs) const
    {
      return (*this < aRhs) == false && (*this > aRhs) == false;
    }

    bool operator!=(const MessageGroup &aRhs) const
    {
      return (*this == aRhs) == false;
    }

    bool operator<(const MessageGroup &aRhs) const
    {
      return val_ < aRhs.val_;
    }

    bool operator>(const MessageGroup &aRhs) const
    {
      return val_ > aRhs.val_;
    }

  protected:
    /* Non-public ctor.
     * Use the named ctors create MessageType instances. */
    MessageGroup(const uint16_t aVal): val_(aVal) {}

  private:
    uint16_t val_;
};


/**
 * This class provides named constructors for the supported message types
 * to be handled by MessageCenter.
 * This base class only provides the Invalid type.
 * Users of this class should extend this class to define their own
 * message types (message value of 0xffff is resereved for the Invalid type).
 * There are helper macros to simplify adding definitions of custom
 * message types (DEFINE_MSG_TYPE_BEGIN, ADD_MSG_TYPE, DEFINE_MSG_TYPE_END).
 */
class MessageType
{
  public:
    /* All MessageType classes have Invalid type.
     * Use the DEFINE_MSG_TYPE_BEGIN, ADD_MSG_TYPE, DEFINE_MSG_TYPE_END
     * macros to add custom message types. */
    static const MessageType& Invalid()
    {
      static MessageType singleton(0xffff);
      return singleton;
    }

    /** Special message to break the main loop. */
    static const MessageType& BreakMainLoop()
    {
      static MessageType singleton(0xfffe);
      return singleton;
    }

    const MessageGroup& Group() const
    {
      return group_;
    }

    /**
     * Integer value of the message type.
     * @return Integer value of of the message type.
     */
    uint16_t Value() const
    {
      return val_;
    }

    bool operator==(const MessageType &aRhs) const
    {
      return (*this < aRhs) == false && (*this > aRhs) == false;
    }

    bool operator!=(const MessageType &aRhs) const
    {
      return (*this == aRhs) == false;
    }

    bool operator<(const MessageType &aRhs) const
    {
      if (group_ < aRhs.group_)
      {
        return true;
      }
      else if (group_ > aRhs.group_)
      {
        return false;
      }
      else
      {
        /* Same group */
        return val_ < aRhs.val_;
      }
    }

    bool operator>(const MessageType &aRhs) const
    {
      if (group_ > aRhs.group_)
      {
        return true;
      }
      else if (group_ < aRhs.group_)
      {
        return false;
      }
      else
      {
        /* Same group */
        return val_ > aRhs.val_;
      }
    }

  protected:
    /* Non-public ctor.
     * Use the named ctors create MessageType instances. */
    MessageType(const uint16_t aVal):
      group_(MessageGroup::Default()), val_(aVal) {}
    MessageType(const MessageGroup aGroup, const uint16_t aVal):
      group_(aGroup), val_(aVal) {}

  private:
    MessageGroup group_;
    uint16_t val_;
};

/**
 * Message to be sent/received to/from other processes/threads.
 *
 * Care should be taken when accessing the data contained in this class.
 *
 * Message receiver is responsible for destroying the data contained in
 * this message.
 */
class Message
{
  public:
    Message();
    ~Message();
    Message& operator=(const Message &aRhs);

    const MessageType& Type() const;
    void Type(const MessageType aType);

    const char* ReplyTo() const;
    void SetReplyTo(const std::string aReplyTo);

    bool IsCommand() const;

    /**
     * Data to be sent.
     * @return Address valid for the current process.
     */
    void* GetData() const;

    size_t GetDataSize() const;

    /**
     * Set data to be sent.
     * The data will be copied to an internal data structure.
     *
     * @param[in] aData Pointer to the data to be sent.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    bool SetData(void *aData, const size_t aSize);

    friend std::ostream& operator<<(std::ostream &aOstream,
                                    const Message &aMsg)
    {
      aOstream << "addr(" << &aMsg << ") "
               << "group(" << aMsg.Type().Group().Value() << ") "
               << "type(" << aMsg.Type().Value() << ") "
               << "reply_to(" << aMsg.ReplyTo() << ") "
               << "cmd(" << (aMsg.IsCommand() ? "yes) " : "no) ")
               << "data(" << aMsg.GetData() << ") "
               << "size(" << aMsg.GetDataSize() << ")";
      return aOstream;
    }

  protected:
    MessageType type_;

    char reply_to_[16];

    bool is_command_;

    /** Flag indicating if the data_handle_ has been set. */
    bool data_handle_set_;

    /**
     * Handle for the input data.
     * The handle is valid and can be used by multiple threads/processes
     * to access the same data.
     */
    boost::interprocess::managed_shared_memory::handle_t data_handle_;

    size_t data_size_;

    void *raw_data_;
};

/**
 * Command to be sent/received to/from other processes/threads.
 *
 * Care should be taken when accessing the data contained in this class.
 *
 * The Command object MUST be created using MessageCenter::CreateObject
 * API to make sure that the object is allocated on a shared memory
 * space.
 *
 * Senders should call GetResult to wait for the output data.
 * Senders should not call any other API's until the GetResult
 * function returns.
 *
 * Senders are responsible for destroying the Command object and
 * its input/output data.
 */
class Command : public Message
{
  public:
    Command();
    ~Command();
    Command& operator=(const Command &aRhs);

    typedef std::pair<void *, size_t> ResultPair;

    /**
     * Data received.
     * This will block until the output data is set.
     *
     * @param[in] aMaxWaitTime Maximum time in milli-seconds allowed to
     *                         get result. (0 == nonblocking,
     *                         -1 == block indefinitely)
     *
     * @return Address valid for the current process.
     */
    ResultPair GetResult(const int aMaxWaitTime = -1);

    /**
     * Set data output data.
     * The data will be copied to an internal data structure.
     *
     * @param[in] aResult Pointer to the result data to be set.
     * @param[in] aSize Size of the data.
     *
     * @return true on success, false otherwise.
     */
    bool SetResult(void *aResult, const size_t aSize);

  private:
    bool result_set_;

    /** Flag indicating if the out has been set. */
    bool result_handle_set;

    /**
     * Handle for the output data.
     * The handle is valid and can be used by multiple threads/processes
     * to access the same data.
     */
    boost::interprocess::managed_shared_memory::handle_t result_handle_;

    size_t result_size_;

    void *raw_result_;

    /** Mutex for synchronizing output data. */
    boost::interprocess::interprocess_mutex mutex_;
    /** Cond var to signal readiness of output data. */
    boost::interprocess::interprocess_condition cond_ready_;
};

}; /* namespace ipc */
}; /* namespace util */
}; /* namespace volt */

#endif
