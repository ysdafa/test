#ifndef VOLT_UTIL_EVENT_MANAGER_H
#define VOLT_UTIL_EVENT_MANAGER_H

#include <clutter/clutter.h>

#include <thread>

#include "event_const.h"
#include "logger.h"

namespace volt
{
namespace util
{

/**
 * This class implements a way of receiving events from TV application.
 */
class EventManager
{
  public:
    static std::string LOGGER_NAME;

  public:
    /**
     * The class to be passed to the event callback function.
     */
    class CallbackData
    {
      public:
        ClutterEvent *event; /**< Caught event. */
        void *user_data; /**< User data as given to StartEventCheckThread. */

        ~CallbackData()
        {
          if (event)
          {
            clutter_event_free(event);
          }

          user_data = NULL;
        }
    };

  public:
    static EventManager& Instance();

    EventManager();
    virtual ~EventManager();

    void SetStage(ClutterStage *aStage);

    void SetRemoteControlEventCallback(GSourceFunc aCallback,
                                       void *aUserData = NULL);
    void SetMouseEventCallback(GSourceFunc aCallback,
                               void *aUserData = NULL);
    void SetFlickEventCallback(GSourceFunc aCallback,
                               void *aUserData = NULL);
    void SetShowHideEventHandlers(GSourceFunc aShowHandler,
                                  void *aShowHandlerArg,
                                  GSourceFunc aHideHandler,
                                  void *aHideHandlerArg);

    /**
     * Start checking for event.
     * When an event is caught, it is passed to the specified ClutterStage
     * instance.
     * This will create a new thread to check for events.
     *
     * The supplied callback function must map the hardware_keycode to
     * a valid keyval that clutter understands.
     *
     * @param[in] aStage ClutterStage where the events should be forwarded.
     * @param[in] aCallback Function to be called when events are caught.
     * @param[in] aUserData User-supplied data.
     */
    void StartEventCheckThread(ClutterStage *aStage,
                               GSourceFunc aCallback = DefaultRemoteControlCallback,
                               void *aUserData = NULL);
    /**
     * Stop checking for event.
     * This will trigger the event check thread to exit.
     */
    void StopEventCheckThread();

    void JoinEventCheckThread();

    /**
     * Handle an event of the given type/code.
     * This function will create/initialize a new ClutterEvent and
     * pass the event to the registered callback function.
     *
     * @param[in] aType Event type.
     * @param[in] aCode Event code.
     */
    void HandleEvent(const int aType, const int aCode);

    void HandleMouseEvent(const EVENT_TYPE aType, const MOUSE_BUTTON aButton,
                          const unsigned int aX, const unsigned int aY);

    void HandleFlickEvent(const MOUSE_FLICK aFlick);

    void HandleShow();
    void HandleHide();

    /**
     * Default IR event handler.
     * This function handles navigational keys and return/exit keys.
     * When the exit key is pressed, the event check thread is stopped
     * and the clutter_main_quit is called.
     *
     * @param[in] aCallbackData Callback data.
     */
    static int DefaultRemoteControlCallback(void *aCallbackData);

    static MOUSE_FLICK VoltFlickEvent(const int aTvFlick);

  private:
    /**
     * This class defines the thread created by EventManager
     * to receive events from TV and call the registered callback.
     */
    class EventChecker
    {
      public:
        /**
         * Construct an instance with the parent EventManager.
         * @param[in] aParent EventManager instance which created this
         *                    object.
         */
        EventChecker();

        /**
         * Stop this thread.
         */
        void Stop();

        /**
         * Set the stage where the events will be sent.
         * @param[in] aStage Target stage.
         */
        void set_stage(ClutterStage *aStage);
        /**
         * Set the callback to be called when an event is received.
         * @param[in] aCallbackData Target callback.
         * @param[in] aUserData The argument for the callback.
         */
        void set_callback(GSourceFunc aCallback,
                          void *aUserData = NULL);

        /**
         * Entry point for this thread.
         * This is currently implemented using a FIFO/named-pipe.
         */
        void operator()();

      private:
        /** Flag to indicate if this thread is running or not. */
        volatile sig_atomic_t running_;
        /** Stage where the events will be sent. */
        ClutterStage *stage_;
        /** The callback function. */
        GSourceFunc remote_control_callback_;
        /** The argument to be used to call the callback function. */
        void *remote_control_user_data_;
    };

  private:
    volt::util::Logger logger_; /**< Logger. */

    std::thread thread_;

    /** Thread to receive events from TV. */
    EventChecker event_checker_;

    /** Stage where the events will be sent. */
    ClutterStage *stage_;

    /** The callback function for remote control events. */
    GSourceFunc remote_control_callback_;
    /** The argument to be used to call the remote control event callback
     * function. */
    void *remote_control_user_data_;
    /** The callback function for mouse events. */
    GSourceFunc mouse_callback_;
    /** The argument to be used to call the mouse event callback function. */
    void *mouse_user_data_;
    /** The callback function for flick events. */
    GSourceFunc flick_callback_;
    /** The argument to be used to call the flick callback function. */
    void *flick_user_data_;

    GSourceFunc show_event_handler_;
    void *show_event_handler_arg_;
    GSourceFunc hide_event_handler_;
    void *hide_event_handler_arg_;
};

} /* namespace util */
} /* namespace volt */

#endif /* VOLT_UTIL_EVENT_MANAGER_H */
