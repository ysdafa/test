#ifndef VOLT_UTIL_TASK_DISPATCHER_H
#define VOLT_UTIL_TASK_DISPATCHER_H

#include <thread>
#include <functional>
#include <vector>
#include <boost/asio.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

namespace volt
{
namespace util
{

class TaskDispatcher
{
  public:
    typedef std::function<void ()> Task;

    class TaskHandler
    {
      public:
        typedef std::shared_ptr<TaskHandler> SharedPtr;

      public:
        virtual ~TaskHandler();

        unsigned int id() const;

        Task task() const;

        static void RunTask(SharedPtr aSelf);

      private:
        friend class TaskDispatcher;

        TaskHandler(Task aTask);

      private:
        static unsigned int id_counter_;
        unsigned int id_;
        Task task_;
    };

    class DelayedTaskHandler : public TaskHandler,
      public std::enable_shared_from_this<DelayedTaskHandler>
    {
      public:
        typedef std::shared_ptr<DelayedTaskHandler> SharedPtr;

      public:
        ~DelayedTaskHandler();

        void Cancel();

      private:
        friend class TaskDispatcher;

        DelayedTaskHandler(Task aTask, boost::asio::io_service &aIO);

        void Wait(const unsigned aDelayMsec);

        static void RunTask(const boost::system::error_code &aError, SharedPtr aSelf);

      private:
        boost::asio::deadline_timer timer_;
    };

  public:
    static TaskDispatcher& Instance();

    void Initialize(const unsigned int aNumThreads = 4);

    ~TaskDispatcher();

    void Finish();

    void AddTask(Task aTask);

    void AddDelayedTask(const unsigned int aDelayMsec, Task aTask);

    DelayedTaskHandler::SharedPtr CreateDelayedTask(const unsigned int aDelayMsec,
        Task aTask);

    void PrepFork();
    void AfterForkParent();
    void AfterForkChild();

  private:
    TaskDispatcher();

    static void RunWrapper(boost::asio::io_service *aIO);

    static void DelayedTaskWrapper(const boost::system::error_code &aError,
                                   boost::asio::deadline_timer *aTimer, Task aTask);

  private:
    boost::asio::io_service io_service_;
    std::unique_ptr<boost::asio::io_service::work> work_;

    std::vector<std::thread> workers_;
};

} /* namespace util */
} /* namespace volt */

#endif
