#ifndef VOLT_UTIL_STRING_UTIL_H
#define VOLT_UTIL_STRING_UTIL_H

#include <algorithm>
#include <boost/algorithm/string.hpp>

namespace volt
{
namespace util
{

// trim from start
static inline std::string& LeftTrim(std::string &aStr)
{
  aStr.erase(aStr.begin(),
             std::find_if(aStr.begin(), aStr.end(),
                          std::not1(std::ptr_fun<int, int>(std::isspace))));
  return aStr;
}

// trim from end
static inline std::string& RightTrim(std::string &aStr)
{
  aStr.erase(std::find_if(aStr.rbegin(), aStr.rend(),
                          std::not1(std::ptr_fun<int, int>(std::isspace))).base(),
             aStr.end());
  return aStr;
}

// trim from both ends
static inline std::string& Trim(std::string &aStr)
{
  return LeftTrim(RightTrim(aStr));
}
 
/** Case-insensitive compare */
static inline bool CompareIC(const std::string &aStr1, const std::string &aStr2)
{
	return boost::iequals(aStr1, aStr2);
}

} /* namespace util */
} /* namespace volt */

#endif /* VOLT_UTIL_STRING_UTIL_H */
