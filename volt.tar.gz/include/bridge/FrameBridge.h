/*
 * FrameBridge.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef FRAMEBRIDGE_H_
#define FRAMEBRIDGE_H_

#include "LayoutBridge.h"
#include "FrameWidget.h"

namespace Bridge
{

class FrameBridge : public LayoutBridge
{

  protected:
    virtual inline const char* getScriptClassName() const
    {
      return "FrameWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

  private:

    static ScriptObject getAlignX(FrameWidget* self);
    static void setAlignX(FrameWidget* self, ScriptObject value);

    static ScriptObject getAlignY(FrameWidget* self);
    static void setAlignY(FrameWidget* self, ScriptObject value);

};

} /* namespace Bridge */
#endif /* FRAMEBRIDGE_H_ */
