/*
 * ImageWidgetBridge.h
 *
 *  Created on: May 23, 2013
 *      Author: reza
 */

#ifndef IMAGEWIDGETBRIDGE_H_
#define IMAGEWIDGETBRIDGE_H_

#include "WidgetBridge.h"
#include "ImageWidget.h"

namespace Bridge
{
/**
 * Bridge ImageWidget to JavaScript
 */
class ImageWidgetBridge : public WidgetBridge
{

    static std::map<volt::graphics::Widget*, ScriptFunction> readyCallbacks;

  public:

    virtual inline const char* getScriptClassName() const
    {
      return "ImageWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual inline void destroyFromScript(void* destroyedObject)
    {
      volt::graphics::ImageWidget* widget = reinterpret_cast<volt::graphics::ImageWidget*>(destroyedObject);
      delete widget;
    }

    virtual volt::graphics::Widget* constructWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual volt::graphics::ImageWidget* constructImageWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual Color getDefaultColor()
    {
      return Color(0, 0, 0, 0);
    }


  private:
    //Properties

    /*Translate access to the color property between JS and native. */
    static ScriptObject getImageColor(volt::graphics::ImageWidget* self);
    static void setImageColor(volt::graphics::ImageWidget* self, ScriptObject);

    static void onDestruction(volt::graphics::ImageWidget* self);

    /** Translate access to the onLoad property between JS and
     *  native */
    static ScriptObject getSource(volt::graphics::ImageWidget* self);
    static void setSource(volt::graphics::ImageWidget* self, ScriptObject);
    static ScriptObject getOnReady(volt::graphics::ImageWidget* self);
    static void setOnReady(volt::graphics::ImageWidget* self, ScriptObject);
    static volt::graphics::ImageWidgetReadyCallback registerReadyCallback(volt::graphics::ImageWidget* self, ScriptFunction onReady);
    static void unregisterReadyCallback(volt::graphics::ImageWidget* self);
    static void invokeReadyCallback(volt::graphics::ImageWidget* self, const ScriptFunction& callback, bool success);

    static ScriptObject getFillMode(volt::graphics::ImageWidget* self);
    static void setFillMode(volt::graphics::ImageWidget* self, ScriptObject);

    static volt::graphics::ImageWidget::FillMode deserializeFillMode(const std::string& );
    static std::string serializeFillMode(const volt::graphics::ImageWidget::FillMode);

    static ScriptObject getColorPicking(volt::graphics::ImageWidget* self, const ScriptArray& args);
};

} /* namespace Bridge */
#endif /* IMAGEWIDGETBRIDGE_H_ */
