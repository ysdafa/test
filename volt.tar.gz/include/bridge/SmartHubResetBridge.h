/*
* TTSBridge.h
*
*  Created on: August 11, 2014
*      Author: Backki Kim
*/

#ifndef SAMSUNG_KINGSCANYON_SMARTHUBRESET_H_
#define SAMSUNG_KINGSCANYON_SMARTHUBRESET_H_

#include "ScriptBridge.h"

#include "logger.h"

namespace Bridge
{
	class SmartHubResetBridge : public ScriptInstanceBridge
	{
	public:

		SmartHubResetBridge();

		virtual ~SmartHubResetBridge();

		static std::string LOGGER_NAME;

	protected:

		virtual inline const char* getScriptClassName() const
		{
			return "SmartHubReset";
		}

		virtual void mapScriptInterface(ScriptContext& aContext);

		virtual void* constructFromScript(const ScriptArray &aArgs);

		virtual inline void destroyFromScript(void *aDestroyedObject)
		{
			// got nothing to do for now..
		}

		static ScriptObject HandleNeedReset(SmartHubResetBridge *aSelf, const ScriptArray &aArgs);
		static ScriptObject HandleResetCompleted(SmartHubResetBridge *aSelf, const ScriptArray &aArgs);
		static ScriptObject HandleClearCacheFolder(SmartHubResetBridge *aSelf, const ScriptArray &aArgs);

	private:
		static volt::util::Logger logger_;

		static std::string GetVconfKey();
		static std::string GetTempFolder();
	};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_TTSBRDIGE_H_ */
