/*
 * VconfBridge.h
 *
 *  Created on: June 26, 2014
 *      Author: Joe Yee
 */

#ifndef SAMSUNG_KINGSCANYON_VCONFBRIDGE_H_
#define SAMSUNG_KINGSCANYON_VCONFBRIDGE_H_

#ifdef HAS_VCONF
#include "vconf.h"
#endif

#include "ScriptBridge.h"

#include "logger.h"

namespace Bridge
{
class VconfBridge : public ScriptInstanceBridge
{
  public:

    VconfBridge();

    virtual ~VconfBridge();

    static std::string LOGGER_NAME;

  protected:

    virtual inline const char* getScriptClassName() const
    {
      return "Vconf";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      // got nothing to do for now..
    }

    static ScriptObject HandleGetValue(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleGetInteger(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleGetDouble(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleGetBool(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleGetString(VconfBridge *aSelf, const ScriptArray &aArgs);

    static ScriptObject HandleGetValues(VconfBridge *aSelf, const ScriptArray &aArgs);

    static ScriptObject HandleSetValue(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleSetInteger(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleSetDouble(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleSetBool(VconfBridge *aSelf, const ScriptArray &aArgs);
    static ScriptObject HandleSetString(VconfBridge *aSelf, const ScriptArray &aArgs);

    static ScriptObject HandleUnsetValue(VconfBridge *aSelf, const ScriptArray &aArgs);

    static ScriptObject HandleSetOnChangeHandler(VconfBridge *aSelf, const ScriptArray &aArgs);

    static ScriptObject HandleUnsetOnChangeHandler(VconfBridge *aSelf, const ScriptArray &aArgs);

#ifdef HAS_VCONF
    /**
     * Translate a tree in vconf to ScriptObject.
     * @param[in] aRoot Root of the vconf tree.
     * @param[out] aObj ScriptObject to store result.
     */
    static void VconfTreeToScriptObject(const std::string &aRoot, ScriptObject &aObj);

    /**
     * Translate a node in vconf to ScriptObject.
     * @param[in] aNode A node in vconf.
     * @param[out] aObj ScriptObject to store result.
     */
    static void VconfNodeToScriptObject(keynode_t *aNode, ScriptObject &aObj);

    /**
     * Call the VconfBridgeMsg::OnChange handler.
     * This function simply serialize the useful data and send a Message to
     * self so that the event can be handled by the v8 thread.
     *
     * @param[in] aNode A node in vconf.
     * @param[in] aSelf Pointer to VconfBridge.
     */
    static void OnChangeHandlerProxy(keynode_t *aNode, void *aSelf);

    void OnChangeHandler(const int aType, const std::string &aKey);
#endif

  protected:
    static volt::util::Logger logger_;

    /** Multimap of vconf key to its handlers. */
    std::multimap<std::string, ScriptFunction> on_change_handlers_;
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_VCONFBRIDGE_H_ */
