/*
 * TextWidgetBridge.h
 *
 *  Created on: May 22, 2013
 *      Author: reza
 */

#ifndef TEXTWIDGETBRIDGE_H_
#define TEXTWIDGETBRIDGE_H_

#include "WidgetBridge.h"
#include "TextWidget.h"

#include "logger.h"

namespace Bridge
{

/**
 * Bridges TextWidgets to JavaScript
 */
class TextWidgetBridge : public WidgetBridge
{
  public:

    virtual inline const char* getScriptClassName() const
    {
      return "TextWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual volt::graphics::Widget* constructWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual Color getDefaultColor()
    {
      return Color(0, 0, 0, 0);
    }


  private:

    static volt::util::Logger logger;

    //Properties

    /**Translate access to the text color property between JS and native. */
    static ScriptObject getTextColor(volt::graphics::TextWidget* self);
    static void setTextColor(volt::graphics::TextWidget* self, ScriptObject);

    //TODO: Deprecated at 1.3. Remove permentally when possible
    static void setTextColorDeprecated(volt::graphics::TextWidget* self, ScriptObject val);
    static ScriptObject getTextColorDeprecated(volt::graphics::TextWidget* self);


    static ScriptObject getAlignment(volt::graphics::TextWidget* self);
    static void setAlignment(volt::graphics::TextWidget* self, ScriptObject);

    static ScriptObject getVAlignment(volt::graphics::TextWidget* self);
    static void setVAlignment(volt::graphics::TextWidget* self, ScriptObject);

    static ScriptObject getShadow(volt::graphics::TextWidget* self);
    static void setShadow(volt::graphics::TextWidget* self, ScriptObject val);

    //Methods:
    static ScriptObject setSizeByLines(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject charIndexAtCoordinate(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject coordinateAtCharIndex(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject getHeightInLines(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject setHeightInLines(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject getLineHeight(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject getTextOverflow(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject getTextOverflowLines(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject insertText(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject removeText(volt::graphics::TextWidget* self, const ScriptArray& args);
    static ScriptObject isRightToLeft(volt::graphics::TextWidget* self, const ScriptArray& args);


    static volt::graphics::VerticalLayoutAlignment deserializeVerticalAlignment(std::string);
    static std::string serializeVerticalAlignment(volt::graphics::VerticalLayoutAlignment);

};

} /* namespace Bridge */
#endif /* TEXTWIDGETBRIDGE_H_ */
