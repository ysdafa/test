/*
 * ImageBridge.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_IMAGE_BRIDGE_H
#define SAMSUNG_KINGSCANYON_IMAGE_BRIDGE_H

#include "ScriptBridge.h"
#include "Image.h"

#include <vector>
#include "logger.h"

namespace Bridge
{

class ImageBridge : public ScriptBridge
{
    static std::map<volt::graphics::Image*, ScriptFunction> gifCompleteCallbacks;
    static std::map<volt::graphics::Image*, volt::graphics::Image::SharedPtr> SharedImages;

  public:
    static std::string LOGGER_NAME;

  public:
    ImageBridge();
    virtual ~ImageBridge();

    /** Function invoked when a Widget is destroyed.*/
    static void onDestruction(ImageBridge* bridge, volt::graphics::Image* destroyedImage);
  protected:
    /* Redefined virtuals */

    virtual inline const char* getScriptClassName() const
    {
      return "Image";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      volt::graphics::Image *object =
        reinterpret_cast<volt::graphics::Image *>(aDestroyedObject);

      if(SharedImages.count((volt::graphics::Image*)object))
      {
        SharedImages.erase((volt::graphics::Image*)object);
      }
    }

  protected:
    volt::util::Logger logger_;

  private:
    static ScriptObject getOnGifComplete(volt::graphics::Image* self);
    static void setOnGifComplete(volt::graphics::Image* self, ScriptObject);
    static volt::graphics::ImageGifCompleteCallback registerGifCompleteCallback(volt::graphics::Image* self, ScriptFunction onGifComplete);
    static void unregisterGifCompleteCallback(volt::graphics::Image* self);
    static void invokeGifCompleteCallback(volt::graphics::Image* self, const ScriptFunction& callback);

    static ScriptObject cancelGifAnimation(volt::graphics::Image* self, const ScriptArray& args);
    static ScriptObject resumeGifAnimation(volt::graphics::Image* self, const ScriptArray& args);
    static ScriptObject pauseGifAnimation(volt::graphics::Image* self, const ScriptArray& args);
    static ScriptObject rewindGifAnimation(volt::graphics::Image* self, const ScriptArray& args);
    static ScriptObject handleDestroy(volt::graphics::Image* self, const ScriptArray& args);
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_IMAGE_BRIDGE_H */
