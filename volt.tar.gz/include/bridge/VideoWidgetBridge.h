/*
 * VideoWidgetBridge.h
 *
 *  Created on: June 18, 2014
 *      Author: jim dinunzio
 */

#pragma once

#include "WidgetBridge.h"
#include "VideoWidget.h"

namespace Bridge
{

class VideoWidgetBridge : public WidgetBridge
{

  protected:
    virtual inline const char* getScriptClassName() const
    {
      return "VideoWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual volt::graphics::Widget* constructWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual Color getDefaultColor()
    {
      return Color();
    }

  private:

    static ScriptObject getPlayerSef(volt::graphics::VideoWidget* self);
    static void setPlayerSef(volt::graphics::VideoWidget* self, ScriptObject value);

};

} /* namespace Bridge */

