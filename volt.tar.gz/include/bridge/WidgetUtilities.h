/*
 * WidgetUtilities.h
 *
 *  Created on: Aug 1, 2013
 *      Author: reza
 */

#ifndef WIDGETUTILITIES_H_
#define WIDGETUTILITIES_H_

#include <clutter/clutter.h>

enum WidgetPropertyType
{
  WByte,
  Scaler,
  Vector2D,
  Vector3D,
  ColorValue
};

/**
 * A bare bones struct for rounded corner
 */
struct Corner
{
  float radius;
  float arcStep;

  Corner(float radiusVal, float arcStepVal) : radius(radiusVal), arcStep(arcStepVal) { }
  Corner() : radius(0), arcStep(0) { }

  inline bool operator==(const Corner &other) const
  {
    return this->radius == other.radius && this->arcStep == other.arcStep;
  }

  inline bool operator!=(const Corner &other) const
  {
    return !(*this == other);
  }

  inline Corner operator+(const Corner &other) const
  {
    return Corner(radius + other.radius, arcStep + other.arcStep);
  }
};

/**
 * A bare bones 2D vector class
 */
struct Vector2
{
  double x;
  double y;

  Vector2(double xVal, double yVal):x(xVal), y(yVal) {}
  Vector2() : x(0), y(0) {}

  inline bool operator==(const Vector2& other) const
  {
    return this->x == other.x && this->y == other.y;
  }

  inline bool operator!=(const Vector2& other) const
  {
    return !(*this == other);
  }

  inline Vector2 operator+(const Vector2& other) const
  {
    return Vector2(x + other.x, y + other.y );
  }
};

/**
 * A bare bones 3d vector class
 */
struct Vector3
{
  double x;
  double y;
  double z;

  Vector3(double xVal, double yVal, double zVal):x(xVal), y(yVal), z(zVal) {}
  Vector3():x(0), y(0), z(0) {}

  inline bool operator==(const Vector3& other) const
  {
    return this->x == other.x && this->y == other.y && this->z == other.z;
  }

  inline bool operator!=(const Vector3& other) const
  {
    return !(*this == other);
  }

  inline Vector3 operator+(const Vector3& other) const
  {
    return Vector3(x + other.x, y + other.y, z + other.z );
  }

};

/**
 * A color, specified with a Red, Blue, Green and Alpha component.
 */
class Color
{
  public:
    u_int8_t r, g, b, a;
    Color():r(0), g(0), b(0), a(0) {};
    Color(uint red, uint green, uint blue, uint alpha)
      :r(red), g(green), b(blue), a(alpha) {}

    Color(ClutterColor cCol): r(cCol.red), g(cCol.green), b(cCol.blue), a(cCol.alpha) {}

    bool isTransparent() const
    {
      return r == 0 && g == 0 && b == 0 && a == 0;
    }

    static Color Transparent()
    {
      return Color(0,0,0,0);
    }

    bool isWhite() const
    {
      return r == 255 && g == 255 && b == 255 && a == 255;
    }

    static Color White()
    {
      return Color(255,255,255,255);
    }

    bool operator==(const Color& color) const
    {
      return r == color.r && g == color.g && b == color.b && a == color.a;
    }

    Color operator+(const Color& color) const
    {
      return Color( r + color.r, g + color.g, b + color.b, a + color.a);
    }

    const ClutterColor* toClutterColor() const
    {
      cColor.red = r;
      cColor.green = g;
      cColor.blue = b;
      cColor.alpha = a;

      return &cColor;
    }

  private:
    mutable ClutterColor cColor;

};

enum LayoutOrientation
{
  Horizontal,
  Vertical
};

enum LayoutAlignment
{
  Left, Right, Center
};

enum ScalingFilter
{
  FILTER_LINEAR = CLUTTER_SCALING_FILTER_LINEAR,
  FILTER_NEAREST = CLUTTER_SCALING_FILTER_NEAREST,
  FILTER_TRILINEAR = CLUTTER_SCALING_FILTER_TRILINEAR
};

enum TweenMode /*One-to-one enumeration with ClutterAnimationMode, do NOT add new names unless they are matched in ClutterAnimationMode*/
{
  LINEAR = 1,   //Simple linear interpolation (tweening) This is the default.
  QUADRATIC_IN,   QUADRATIC_OUT,   QUADRATIC,       //2nd power tweening, basic "easing"
  CUBIC_IN,       CUBIC_OUT,       CUBIC,           //3rd power tweening
  QUARTIC_IN,     QUARTIC_OUT,     QUARTIC,         //4th power tweening
  QUINTIC_IN,     QUINTIC_OUT,     QUINTIC,         //5th power tweening
  SINE_IN,        SINE_OUT,        SINE,            //sine wave tweening
  EXPONENTIAL_IN, EXPONENTIAL_OUT, EXPONENTIAL,     //Exponential tweening
  CIRCULAR_IN,    CIRCULAR_OUT,    CIRCULAR,        //Circular tweening
  ELASTIC_IN,     ELASTIC_OUT,     ELASTIC,         //Elastic tweening with offshoot
  OVERSHOOT_IN,   OVERSHOOT_OUT,   OVERSHOOT,       //overshooting cubic tweening with backtracking
  BOUNCE_IN,      BOUNCE_OUT,      BOUNCE,           //Exponentially decaying parabolic (bounce) tweening
  CUBIC_BEZIER = 36 //clutter cubic bez is 36
};

namespace GValueConversion
{
//Utility functions for creating GValues for animatable types
GValue getGValue(WidgetPropertyType type, float theValue);
GValue getGValue(Vector2 theValue);
GValue getGValue(Vector3 theValue);
GValue getGValue(Color color);

double decodeGValue(GValue value, WidgetPropertyType type);
Vector2 decode2DGValue(GValue value);
Vector3 decode3DGValue(GValue value);
Color decodeColorGValue(GValue value);
}

#endif /* WIDGETUTILITIES_H_ */
