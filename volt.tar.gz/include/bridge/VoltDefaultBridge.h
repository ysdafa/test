/*
 * VoltDefaultBridge.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_VOLTDEFAULTBRIDGE_H_
#define SAMSUNG_KINGSCANYON_VOLTDEFAULTBRIDGE_H_

#include <glib.h>
#include <memory>

#include "ScriptBridge.h"
#include "event_const.h"
#include "logger.h"
#include "macros.h"
#include "ScriptEngine.h"

#define DEFINE_KEY_MAP_FUNCS(ns,key) int get##key() const { return ns::key; } \
                                     void set##key(int) {}

namespace Bridge
{

class VoltDefaultBridge : public ScriptInstanceBridge
{
  public:
    static volt::util::Logger LOGGER;

  public:
    VoltDefaultBridge(ScriptEngine *aJsEngine);
    virtual ~VoltDefaultBridge();

  protected:
    /**
     * Handles the "exit" JS API.
     *
     * The JS "exit" API expects no arguments.
     * This function will call XLowerWindow.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleExit(VoltDefaultBridge *aSelf,
                                   const ScriptArray &aArgs);
    /**
     * Handles the "quit" JS API.
     *
     * The JS "quit" API expects no arguments.
     * This function will call clutter_main_quit to stop the main loop.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleQuit(VoltDefaultBridge *aSelf,
                                   const ScriptArray &aArgs);

    /**
     * Handles the "load" JS API.
     *
     * The JS "load" API expects 1 argument.  The argument is the JavaScript
     * to load (not the file, but the actual JS).  The function would return
     * true on success, false otherwise.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleLoad(VoltDefaultBridge *aSelf,
                                   const ScriptArray &aArgs);

    static ScriptObject HandleLoadApp(VoltDefaultBridge *aSelf,
                                      const ScriptArray &aArgs);

    /**
     * Handles the "getWidgetById" JS API.
     *
     * The JS "getWidgetById" API expects 1 argument, the Id of the desired Widget. Id is an std::string.
     * If the ID matches an existing Widget, a reference to that Widget will be returned. If not, the JavaScript
     * null value is returned.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleGetWidgetById(VoltDefaultBridge *aSelf,
                                            const ScriptArray &aArgs);

    /**
     * Handles the "setTimeout" JS API.
     *
     * The JS "setTimeout" API expects at least 2 arguments.
     * The first argument is the callback to be used.
     * The second argument is the delay in milli-seconds.
     * Any additional arguments will be given to the callback.
     * The function returns an ID which can be used to clear the timeout.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleSetTimeout(VoltDefaultBridge *aSelf,
                                         const ScriptArray &aArgs);


    /**
     * Handles the "clearTimeout" JS API.
     *
     * The JS "clearTimeout" API expects exactly 1 argument.
     * The argument is the timer ID return from the setTimeout JS API.
     * The function returns true on success, false otherwise.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleClearTimeout(VoltDefaultBridge *aSelf,
                                           const ScriptArray &aArgs);

    /**
     * Handles the "setInterval" JS API.
     *
     * The JS "setInterval" API expects at least 2 arguments.
     * The first argument is the callback to be used.
     * The second argument is the delay in milli-seconds.
     * Any additional arguments will be given to the callback.
     * The function returns an ID which can be used to clear the interval.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleSetInterval(VoltDefaultBridge *aSelf,
                                          const ScriptArray &aArgs);

    /**
     * Handles the "clearInterval" JS API.
     *
     * The JS "clearInterval" API expects exactly 1 argument.
     * The argument is the timer ID return from the setInterval JS API.
     * The function returns true on success, false otherwise.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleClearInterval(VoltDefaultBridge *aSelf,
                                            const ScriptArray &aArgs);

    /**
     * Handles the "clearTimer" JS API.
     *
     * The JS "clearTimer" API expects exactly 1 argument.
     * The argument is the timer ID return from the setInterval JS API.
     * The function returns true on success, false otherwise.
     *
     * This JS function can be used anywhere clearTimeout and clearInterval is
     * used since both the timeout and interval use the same pool of ID's.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleClearTimer(VoltDefaultBridge *aSelf,
                                         const ScriptArray &aArgs);

    /**
     * Handles the "setDefaultFont" JS API.
     *
     * The JS "setDefaultFont" API expects exactly 1 argument.
     * The argument is the name of the default font to be used in the
     * calling application.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleSetDefaultFont(VoltDefaultBridge *aSelf,
        const ScriptArray &aArgs);

    /**
     * Handles the "getAbsolutePath" JS API.
     *
     * The JS "getAbsolutePath" API expects exactly 1 argument.
     * The argument is the path to a locally available file.
     * The function returns the "real" absolute path if the file exists and is
     * accessible by the application, otherwise the function returns an empty
     * string.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleGetAbsolutePath(VoltDefaultBridge *aSelf,
        const ScriptArray &aArgs);

    /**
     *
     * Expects two arguments.
     *
     * The id of an event eg: VOLT_KEY_JOYSTICK*
     *
     * A function which will be invoked when this event takes place
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleAddEventListener(VoltDefaultBridge *aSelf,
        const ScriptArray &aArgs);

    /**
    *
    * Expects two arguments.
    *
    * The id of an event eg: VOLT_KEY_JOYSTICK*
    *
    * A function which has previously been added as an event
    * listener
    *
    * This function will unregister the event listener
    *
    * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
    * @param[in] aArgs Arguments given from the JS.
    * @return ScriptObject
    */
    static ScriptObject HandleRemoveEventListener(VoltDefaultBridge *aSelf,
        const ScriptArray &aArgs);

    /**
    *
    * Expects 1 arguments.
    *
    * The id of an event eg: VOLT_KEY_JOYSTICK*
    *
    * This function will simulate the event.
    *
    * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
    * @param[in] aArgs Arguments given from the JS.
    * @return ScriptObject
    */
    static ScriptObject HandleDispatchEvent(VoltDefaultBridge *aSelf,
                                            const ScriptArray &aArgs);

    /**
     * Post a message to the parent process.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     *
     * @return ScriptObject
     */
    static ScriptObject HandlePostMessage(VoltDefaultBridge *aSelf,
                                          const ScriptArray &aArgs);

    /**
     * Execute a command on the parent process.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS.
     *
     * @return ScriptObject with the execution result, or ScriptObject::Null
     *         on error.
     */
    static ScriptObject HandleExecCommand(VoltDefaultBridge *aSelf,
                                          const ScriptArray &aArgs);

    static ScriptObject HandleGetVersion(VoltDefaultBridge *aSelf,
                                         const ScriptArray &aArgs);

    /**
     * Return true if a given string is displayed right to left.
     *
     * @param[in] aSelf Pointer to the instance of VoltDefaultBridge.
     * @param[in] aArgs Arguments given from the JS (should be one param, a string)
     *
     * @return ScriptObject with true if the given string is displayed right to left.
     */
    static ScriptObject HandleIsRightToLeft(VoltDefaultBridge *aSelf,
                                            const ScriptArray &aArgs);

    DEFINE_KEY_MAP_FUNCS(volt::util, EVENT_KEY_PRESS)
    DEFINE_KEY_MAP_FUNCS(volt::util, EVENT_KEY_RELEASE)

    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_BUTTON_LEFT)
    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_BUTTON_MIDDLE)
    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_BUTTON_RIGHT)
    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_BUTTON_SIDE_LEFT)
    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_BUTTON_SIDE_RIGHT)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_JOYSTICK_OK)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MENU)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_JOYSTICK_UP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_JOYSTICK_DOWN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_JOYSTICK_LEFT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_JOYSTICK_RIGHT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_3)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_VOLUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_4)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_5)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_6)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_VOLDOWN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_7)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_8)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_9)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MUTE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CHDOWN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_0)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CHUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PRECH)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_GREEN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_YELLOW)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CYAN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BLUE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_STEP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DEL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ADDDEL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SOURCE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TV)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MOIP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PMENU)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_INFO)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_ONOFF)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_SWAP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_ROTATE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PLUS100)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_INPUT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CAPTION)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_STILL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AD)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PMODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SOUND_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_NR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SMODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TTX_MIX)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_EXIT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ENTER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_SIZE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MAGIC_CHANNEL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_SCAN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_CHUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PIP_CHDOWN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DEVICE_CONNECT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HELP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ANTENA)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CONVERGENCE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_11)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_12)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_PROGRAM)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FACTORY)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_3SPEED)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SCROLL_UP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ASPECT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_EMANUAL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_GAME)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SCROLL_RIGHT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_STILL_PICTURE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DTV)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FAVCH)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_REWIND)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_STOP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PLAY)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FF)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_REC)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PAUSE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TOOLS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SCROLL_LEFT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_LINK)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FF_)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_GUIDE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_REWIND_)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ANGLE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_RESERVED1)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ZOOM1)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PROGRAM)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BOOKMARK)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DISC_MENU)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SCROLL_DOWN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_RETURN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SUB_TITLE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CLEAR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_VCHIP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_REPEAT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DOOR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_OPEN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_WHEEL_LEFT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_POWER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SLEEP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_2)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DMA)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TURBO)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_1)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FM_RADIO)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DVR_MENU)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MTS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PCMODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TTX_SUBFACE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CH_LIST)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_RED)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DNIe)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SRS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CONVERT_AUDIO_MAINSUB)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MDC)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SEFFECT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DVR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DTV_SIGNAL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_LIVE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PERPECT_FOCUS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HOME)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ESAVING)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_WHEEL_RIGHT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CONTENTS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_VCR_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CATV_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DSS_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TV_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DVD_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_STB_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CALLER_ID)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SCALE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ZOOM_MOVE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CLOCK_DISPLAY)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AV1)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SVIDEO1)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_COMPONENT1)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SETUP_CLOCK_TIMER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_COMPONENT2)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MAGIC_BRIGHT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DVI)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HDMI)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_W_LINK)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DTV_LINK)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_RESERVED5)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_APP_LIST)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BACK_MHP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ALT_MHP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DNSe)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_RSS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ENTERTAINMENT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ID_INPUT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ID_SETUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ANYNET)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_POWEROFF)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_POWERON)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ANYVIEW)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MORE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_POWER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_CHUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_CHDOWN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_VOLUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_VOLDOWN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_ENTER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_MENU)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_SOURCE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AV2)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AV3)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SVIDEO2)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SVIDEO3)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ZOOM2)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANORAMA)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_4_3)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_16_9)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DYNAMIC)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_STANDARD)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MOVIE1)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CUSTOM)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TILT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_EZ_VIEW)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_3D)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_RESET)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_LNA_ON)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_LNA_OFF)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_ANYNET_MODE_OK)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_ANYNET_AUTO_START)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_FORMAT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DNET)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HDMI1)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_CAPTION_ON)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_CAPTION_OFF)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_DOUBLE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_LARGE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_SMALL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_WIDE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_LEFT_TOP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_RIGHT_TOP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_LEFT_BOTTOM)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_RIGHT_BOTTOM)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_CH_CHANGE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_AUTOCOLOR_SUCCESS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_AUTOCOLOR_FAIL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_C_FORCE_AGING)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_USBJACK_INSPECT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_JACK_IDENT)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_NINE_SEPERATE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ZOOM_IN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_ZOOM_OUT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MIC)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HDMI2)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HDMI3)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_CAPTION_KOR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_CAPTION_ENG)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_SOURCE_CHANGE)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HDMI4)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_ANTENNA_AIR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_ANTENNA_CABLE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_ANTENNA_SATELLITE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_CIP_TEST)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_CH_CHANGE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_START_MBR_TEST)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PVR_RECORDING_TEST)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PVR_PLAY_TEST)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PVR_DELETE_ALL)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_HOTEL_INTERACTIVE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIC_SND_TEST_START)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIC_SND_TEST_END)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PICTURE_HIDE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_CH_CHANGE_2ND_TUNER)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_FUNCTION)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_REMOTE_POWER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_MUTE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_HOLD)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PANNEL_PIP)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_AUTOCOLOR_VIDEO)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_AUTOCOLOR_PC)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_AUTOCOLOR_COMP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_COLOR_WHEEL_INDEX)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_EEPROM_COPY)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_TIME_CLEAR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PLAY_INTERNAL_TEST_PATTERN)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TV_SNS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SEARCH)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_DOTCOM)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BS)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CS)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_SOUND_CHANGE_MAIN)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_AUTO_ARC_PIP_SOUND_CHANGE_SUB)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_CONTENTSBAR)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_NUMBER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_HOTKEY)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_DEVICE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_TRIGGER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_VOICE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FAMILYHUB)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_CAMERA)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_COLOR_MECHA)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_SETUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_WATCH_TV)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_WATCH_MOVIE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_SETUP_CONFIRM)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_USBHUB_SWITCH)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_SETUP_FAILURE)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_ALLSHARE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_SAMSUNG_APPS)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HOTEL_LANGUAGE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HOTEL_ROOMCONTROL)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HOTEL_TVGUIDE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_HOTEL_MOVIES)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_BT_DUALVIEW)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PAGE_LEFT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_PAGE_RIGHT)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_SOCCER_MODE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_STB_POWER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_WIFI_PAIRING)

    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_BDDVD_POWER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_STBBD_MENU)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_BD_POPUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_TV)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_MBR_STB_GUIDE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_RECOMMEND_SEARCH_TOGGLE)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FUNCTIONS_NETFLIX)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FUNCTIONS_AMAZON)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FUNCTIONS_SCHEDULEMANAGER)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_FUNCTIONS_4DIVISION_VIEW)
    DEFINE_KEY_MAP_FUNCS(volt::util, KEY_TURN)

    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_FLICK_LEFT)
    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_FLICK_RIGHT)
    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_FLICK_UP)
    DEFINE_KEY_MAP_FUNCS(volt::util, MOUSE_FLICK_DOWN)

    DEFINE_KEY_MAP_FUNCS(volt::util, ON_LOAD)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_SHOW)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_PAUSE)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_RESUME)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_HIDE)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_UNLOAD)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_RESET)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_ACTIVATE)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_DEACTIVATE)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_SUSPEND)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_WAKEUP)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_RESIZE)

    DEFINE_KEY_MAP_FUNCS(volt::util, ON_MESSAGE)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_COMMAND)

	DEFINE_KEY_MAP_FUNCS(volt::util, ON_FACTORY_RESET)
    DEFINE_KEY_MAP_FUNCS(volt::util, ON_SERVICE_RESET)


    /* Redefined virtuals */

    virtual inline const char* getScriptClassName() const
    {
      return "Volt";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
    }

  private:
    ScriptObject SetTimer(const ScriptArray &aArgs,
                          const bool aRepeat);

    static gboolean HandleTimer(gpointer aData);
    bool HandleTimer(const unsigned int aId);

  private:
    class TimerInfo
    {
      public:
        typedef std::shared_ptr<TimerInfo> SharedPtr;

      public:
        TimerInfo(VoltDefaultBridge *aBridge);
        ~TimerInfo();

        PROPERTY_RO(VoltDefaultBridge *, bridge);
        PROPERTY(unsigned int, id);
        PROPERTY(bool, valid);
        PROPERTY(ScriptFunction, callback);
        PROPERTY_REF(ScriptArray, callback_args);
        PROPERTY(bool, repeat);
    };

  private:
    ScriptEngine* js_engine_;
    std::map<unsigned int, TimerInfo::SharedPtr> timers_;
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_VOLTDEFAULTBRIDGE_H_ */
