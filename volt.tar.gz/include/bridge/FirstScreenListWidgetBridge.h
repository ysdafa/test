/*
 * FirstScreenListWidget.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef FIRSTSCREENLISTWIDGETBRIDGE_H_
#define FIRSTSCREENLISTWIDGETBRIDGE_H_

#include "WidgetBridge.h"
#include "FirstScreenListWidget.h"
#include <vector>

/*
 * Abstract Base class of all Widgets which impose positioning on their children
 */

namespace Bridge
{

class FirstScreenListWidgetBridge : public WidgetBridge
{
  public:

    virtual inline const char* getScriptClassName() const
    {
      return "FirstScreenListWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual volt::graphics::Widget* constructWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual Color getDefaultColor()
    {
      return Color(0, 0, 0, 0);
    }


  private:

	// widget , fovea_meta
	static ScriptObject addCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject addContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject moveLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject moveRight(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setFocus(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject removeCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject removeContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject sendEnterSignal(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject riseFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject findCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject findContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject stopTransition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getPositionX(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getPositionY(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject changeIcon(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject reverseOSD(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject fallFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject off_transition_noanimaition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setFirstState(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject returnAnimation(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject addSubMain(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject changeContentLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getCategoryIndexByID(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setProgress(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject focusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject unfocusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject enterOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setExtendBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setLiveImageBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setHorizontalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setVerticalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setContentLiveBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);

    static ScriptObject sendKeyEvent(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject startFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject stopFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getSelectedItemPos(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject updateDominantColor(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject getLastMouseMovedTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);

    static ScriptObject setOnItemSelectedListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject setOnItemLongPressedListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject setOnItemChangedListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);

	static ScriptObject setBarOpacityMax(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setBarOpacityZero(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	
};

} /* namespace Bridge */

#endif /* FIRSTSCREENLISTWIDGETBRIDGE_H_ */
