/*
 * SefBridge.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_SEFBRIDGE_H_
#define SAMSUNG_KINGSCANYON_SEFBRIDGE_H_

#include "ScriptBridge.h"
#include "SefClient.h"

#include <glib.h>
#include <map>
#include <thread>

#include "logger.h"

namespace Bridge
{

typedef std::map<SefClient*, ScriptFunction> CALLBACK_MAP;

class SefBridge : public ScriptBridge
{
  public:
    static std::string LOGGER_NAME;

  public:
    SefBridge();
    virtual ~SefBridge();

    /**
     * Data to be passed to FireSefOnEvent.
     * The data contained in this struct correspond to the arguments
     * given to CSefPluginWrapper::OnEvent.
     */
    typedef struct
    {
      SefClient* client;
      int type;
      std::string param1;
      std::string param2;
    } SefEventData;

    /**
     * Data to be passed to HandleExecuteResponse.
     * The data contained in this struct is the response from the execute function
     * used for asynchronous run of execute.
     */
    typedef struct
    {
      SefClient* client;
      std::string response;
    } SefExecuteResponse;

    /**
     * Data to be passed to HandleOpenResponse
     * The data contained in this struct is the response from the open function
     * used for asynchronous run of open
     */
    typedef struct
    {
      SefClient* client;
      bool response;
    } SefOpenResponse;

    /**
     * The callback function to execute JS OnSefEvent API.
     * The JS API should be named OnSefEvent and take in 3 arguments.
     * The arguments correspond to the values given to
     * CSefPluginWrapper::OnEvent.
     *
     * This is a hack until VOLT adds support for callback to JS function!
     *
     * @param[in] aData Pointer to SefEventData.
     * @return TRUE
     */
    static gboolean FireSefOnEvent(gpointer aEventData);

    /**
     * The callback function to handle when the async SefClient::Execute call run by
     * SefExecuteThread completes
     *
     * @param[in] aResponseData Pointer to SefExecuteResponse.
     * @return TRUE
     */
    static gboolean HandleExecuteResponse(gpointer aResponseData);

    /**
     * The callback function to handle when the async SefClient::Open call run by
     * SefOpenThread completes
     *
     * @param[in] aResponseData Pointer to SefOpenResponse.
     * @return TRUE
     */
    static gboolean HandleOpenResponse(gpointer aResponseData);

  protected:

    /** JS Callback functions for SefClient
     */
    struct SefCallbackFuncs
    {
      ScriptFunction onEventCB;
      ScriptFunction onExecutedCB;
      ScriptFunction onOpenedCB;
    };

    /** Map holding the JS Sef callback functions for each SefClient object */
    typedef std::map<SefClient*, SefCallbackFuncs> CALLBACK_MAP;

    /**
     * Bridge to Open an EMP.
     * @param[in] aSelf An instance of SefClient class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleOpen(SefClient *aSelf, const ScriptArray &aArgs);
    /**
     * Bridge to Open an EMP asynchronously.
     * @param[in] aSelf An instance of SefClient class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleOpenAsync(SefClient *aSelf, const ScriptArray &aArgs);
    /**
     * Bridge to Close an EMP.
     * @param[in] aSelf An instance of SefClient class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleClose(SefClient *aSelf, const ScriptArray &aArgs);
    /**
     * Bridge to Execute an EMP API.
     * @param[in] aSelf An instance of SefClient class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleExecute(SefClient *aSelf, const ScriptArray &aArgs);

    /**
     * Bridge to Execute an EMP API asynchronously.
     * @param[in] aSelf An instance of SefClient class.
     * @param[in] aArgs Arguments given by the JS.
     * @return ScriptObject
     */
    static ScriptObject HandleExecuteAsync(SefClient *aSelf, const ScriptArray &aArgs);

    /**
     * Get the on Sef event JS callback function.
     * @param[in] aSelf An instance of SefClient class.
     * @return ScriptObject
     */
    static ScriptObject GetOnEventCallback(SefClient* self);

    /**
     * Set the on Sef event JS callback function with event data.
     * @param[in] aSelf An instance of SefClient class.
     * @param[in] sobj ScriptObject from the javascript.
     * @return void
     */
    static void SetOnEventCallback(SefClient *aSelf, ScriptObject sobj);

    /**
     * Call the Sef event JS callback function
     * @param[in] callback The Sef event JS callback function.
     * @param[in] aData pointer to SefEventData structure.
     * @return void
     */
    static void onSefEvent(const ScriptFunction& callback, gpointer aData);

    /**
     * Converts the string response from SefClient::Execute routine
     * to a ScriptObject
     * @param[in] result The string response from SefClient::Execute. 
     * @param[in] name The name of the sef client 
     * @return ScriptObject
     */
    static ScriptObject ExeResponseToScriptObject(const std::string& result,
                                                  SefClient *aSelf);

    static ScriptObject HandleExecuteDoTheWork(bool async, SefClient *aSelf,
        const ScriptArray &aArgs);
    static ScriptObject HandleOpenDoTheWork(bool async, SefClient* aSelf,
                                            const ScriptArray &aArgs);

    /* Redefined virtuals */

    virtual inline const char* getScriptClassName() const
    {
      return "Sef";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      SefClient *object = reinterpret_cast<SefClient *>(aDestroyedObject);
      // remove callback map entry for this SefClient
      callbackMap.erase(object);
      delete object;
    }

  protected:
    static volt::util::Logger logger_;
    static CALLBACK_MAP callbackMap;
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_SEFBRIDGE_H_ */
