/*
 * LayoutBridge.h
 *
 *  Created on: Jul 23, 2013
 *      Author: reza
 */

#ifndef LAYOUTBRIDGE_H_
#define LAYOUTBRIDGE_H_

#include "WidgetBridge.h"
#include "LayoutWidget.h"

namespace Bridge
{

/**
 * A base class for all bridges of LayoutWidgets
 */
class LayoutBridge: public WidgetBridge
{

  protected:
    //virtual inline const char* getScriptClassName() const {return "Layout";}

    virtual void mapScriptInterface(ScriptContext& context);

    static ScriptObject getOrientation(LayoutWidget* self);
    static void setOrientation(LayoutWidget* self, ScriptObject value);


  public:

    /** Interpret string values to the appropriate Layout Orientation enumeration */
    static LayoutOrientation deserializeLayoutOrientation(std::string);
    static std::string serializeLayoutOrientation(LayoutOrientation orientation);

};

} /* namespace Bridge */
#endif /* LAYOUTBRIDGE_H_ */
