/*
 * ResourceRequest.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_RESOURCE_REQUEST_H
#define SAMSUNG_KINGSCANYON_RESOURCE_REQUEST_H

#include "ScriptTypes.h"
#include "logger.h"
#include "macros.h"

/**
 * This class encapsulates the information of a resource request made from
 * the JavaScript applications.
 */
class ResourceRequest
{
  public:
    static std::string LOGGER_NAME;

    /**
     * Class to hold header information (header name & value).
     * This is mainly for HTTP requests but may be used for other protocols as
     * well.
     */
    struct HeaderInfo
    {
      std::string name;
      std::string value;

      HeaderInfo(): name(), value() {}
      HeaderInfo(const std::string &aName,
                 const std::string &aValue):
        name(aName), value(aValue)
      {
      }

      HeaderInfo(const HeaderInfo &aSrc):
        name(), value()
      {
        *this = aSrc;
      }

      HeaderInfo& operator=(const HeaderInfo &aRhs)
      {
        if (this != &aRhs)
        {
          name = aRhs.name;
          value = aRhs.value;
        }

        return *this;
      }
    };

    /**
     * A list of HeaderInfo objects.
     * This is a sequential container rather than an associative container
     * because the order is significant in some protocols (eg HTTP).
     */
    typedef std::vector<HeaderInfo> HeaderList;

  public:
    ResourceRequest(const std::string &aUrl);
    virtual ~ResourceRequest();

    bool AddHeader(const std::string &aName,
                   const std::string &aValue);
    bool RemoveHeader(const std::string &aName,
                      const bool &aRemoveAll = false);
    void ClearHeaders();
    void SetHeaderBlock(const std::string &aHeaders);
    const HeaderList& GetHeaders() const;

  private:
    volt::util::Logger logger_;

    HeaderList headers_;

    PROPERTY(unsigned int, id);
    PROPERTY(unsigned int, requestHandle); // handle mapping ResourceRequest to IORequest
    PROPERTY_CONST_REF(std::string, uri);
    PROPERTY(bool, async);
    PROPERTY(bool, recursive);
    PROPERTY_CONST_REF(Bridge::ScriptFunction, success_callback);
    PROPERTY_CONST_REF(Bridge::ScriptFunction, error_callback);
    PROPERTY_CONST_REF(Bridge::ScriptFunction, complete_callback);
    PROPERTY_CONST_REF(Bridge::ScriptFunction, async_callback);
    PROPERTY_CONST_REF(std::string, method);
    PROPERTY_CONST_REF(std::string, data);
    PROPERTY_CONST_REF(std::string, src);
    PROPERTY(long int, status);
    PROPERTY_CONST_REF(std::string, response_type);
    PROPERTY(bool, no_cache);
};

#endif /* SAMSUNG_KINGSCANYON_RESOURCE_REQUEST_H */
