#ifndef SAMSUNG_KINGSCANYON_STATICUI_H_
#define SAMSUNG_KINGSCANYON_STATICUI_H_

#include "Widget.h"
#include "SceneRoot.h"
#include "ScriptEngine.h"
#include "TextWidget.h"
#include "logger.h"

#include <memory>

namespace volt
{

/**
 * This is a utility class to manage some UI's that are somewhat static and
 * used across different Volt applications (eg splash screen).
 */
class StaticUI
{
  public:
    static util::Logger LOGGER;

  public:
    static StaticUI& Instance();

    /**
     * Attach info required to construct and manage UI's.
     * @param[in] aEngine JS engine to load Volt JS.
     */
    void Attach(Bridge::ScriptEngine *aEngine);
    /**
     * Detach the attached objects.
     */
    void Detach();

    /**
     * Show the splash screen.
     * JS loading will also be scheduled and the splash screen will be hidden
     * once the loading is complete.
     *
     * @param[in] aAppJs Path to the application JS.
     */
    void ShowSplashScreen(const std::string &aAppJs,
                          const VoltEventArgsMap &aData,
                          const std::string &aAppName = "",
                          const std::string &aAppIcon = "");
    void HideSplashScreen();

    /**
     * Show the exception message and exit the app.
     * @param[in] aMsg Message to be displayed.
     * @param[in] aException Info of an exception if available.
     */
    void ShowExceptionPopup(const char *aMsg = NULL,
                            const VoltJsException *aException = NULL);

    bool ExceptionPopupVisible() const;

  private:
    StaticUI();
    virtual ~StaticUI();

    static gboolean LoadAppJS(gpointer aAppJs);

  private:
    std::unique_ptr<SceneRoot> scene_root_;
    volt::graphics::Widget *splash_screen_;

    bool exception_popup_visible_;

    Bridge::ScriptEngine *engine_;

    typedef std::pair<std::string, VoltEventArgsMap> InterthreadData;
};

} /* namespace Volt */
#endif /* SAMSUNG_KINGSCANYON_STATICUI_H_ */
