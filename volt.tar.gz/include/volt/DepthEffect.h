/*
 * DepthEffect.h
 *
 *  Created on: July 3, 2013
 *      Author: jim dinunzio
 */

#ifndef DEPTHEFFECT_H
#define DEPTHEFFECT_H

#include <clutter/clutter.h>

#ifndef STAND_ALONE
#include "Widget.h"
#endif

GType depth_effect_get_type (void);


#define TYPE_DEPTH_EFFECT (depth_effect_get_type ())
#define DEPTH_EFFECT(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), \
                                                           TYPE_DEPTH_EFFECT, \
                                                           CDepthEffect))
#define IS_DEPTH_EFFECT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), \
                                                                      TYPE_DEPTH_EFFECT))
#define DEPTH_EFFECT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), \
                                                                   TYPE_DEPTH_EFFECT, \
                                                                   CDepthEffectClass))
#define IS_DEPTH_EFFECT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), \
                                                                   TYPE_DEPTH_EFFECT))
#define DEPTH_EFFECT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), \
                                                                     TYPE_DEPTH_EFFECT, \
                                                                     CDepthEffectClass))

typedef struct _CDepthEffect        CDepthEffect;
typedef struct _CDepthEffectClass   CDepthEffectClass;

ClutterEffect *depth_effect_new ();

/* object */
struct _CDepthEffect
{
  ClutterEffect          parent_instance;
};

/* class */
struct _CDepthEffectClass
{
  ClutterEffectClass parent_class;
};


#ifndef STAND_ALONE
class DepthEffect : public Effect
{

  public:
    DepthEffect();
    virtual ~DepthEffect();
};
#endif
#endif /* DEPTHEFFECT_H */
