/*
 * CustomEffect.h
 *
 *  Created on: July 21, 2013
 *      Author: jim dinunzio
 */

#ifndef CUSTOMEFFECT_H
#define CUSTOMEFFECT_H

#include <clutter/clutter.h>

#ifndef STAND_ALONE
#include "Widget.h"
#endif

GType custom_effect_get_type (void);


#define TYPE_CUSTOM_EFFECT (custom_effect_get_type ())
#define CUSTOM_EFFECT(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), \
                                                           TYPE_CUSTOM_EFFECT, \
                                                           CCustomEffect))
#define IS_CUSTOM_EFFECT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), \
                                                                      TYPE_CUSTOM_EFFECT))
#define CUSTOM_EFFECT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), \
                                                                   TYPE_CUSTOM_EFFECT, \
                                                                   CCustomEffectClass))
#define IS_CUSTOM_EFFECT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), \
                                                                   TYPE_CUSTOM_EFFECT))
#define CUSTOM_EFFECT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), \
                                                                     TYPE_CUSTOM_EFFECT, \
                                                                     CCustomEffectClass))

typedef struct _CCustomEffect        CCustomEffect;
typedef struct _CCustomEffectClass   CCustomEffectClass;

typedef gboolean (* PrePaintCallback) (CCustomEffect* effect);
typedef void     (* PostPaintCallback) (CCustomEffect* effect);

ClutterEffect *custom_effect_new ();
void custom_effect_set_pre_paint_cb (CCustomEffect* effect, PrePaintCallback cb);
void custom_effect_set_post_paint_cb (CCustomEffect* effect, PostPaintCallback cb);


/* object */
struct _CCustomEffect
{
  ClutterEffect          parent_instance;
  PrePaintCallback       pre_paint_cb;
  PostPaintCallback      post_paint_cb;
};

/* class */
struct _CCustomEffectClass
{
  ClutterEffectClass parent_class;
};


#ifndef STAND_ALONE
class CustomEffect : public Effect
{

  public:
    CustomEffect();
    virtual ~CustomEffect();
};
#endif
#endif /* CUSTOMEFFECT_H */
