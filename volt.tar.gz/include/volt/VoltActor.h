/*
 * VoltActor.h
 *
 *  Created on: July 17, 2013
 *      Author: jim dinunzio
 */

/* inclusion guard */
#ifndef _VOLT_ACTOR_H_
#define _VOLT_ACTOR_H_

/* include any dependencies */
#include <clutter/clutter.h>

G_BEGIN_DECLS
/* GObject implementation */

/* declare this function signature to remove compilation errors with -Wall;
 * the volt_actor_get_type() function is actually added via the
 * G_DEFINE_TYPE macro in the .c file
 */
GType volt_actor_get_type (void);

/* GObject type macros */
/* returns the class type identifier (GType) for VoltActor */
#define VOLT_ACTOR_TYPE            (volt_actor_get_type ())

/* cast obj to a VoltActor object structure*/
#define VOLT_ACTOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), VOLT_ACTOR_TYPE, VoltActor))

/* check whether obj is a VoltActor */
#define IS_VOLT_ACTOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), VOLT_ACTOR_TYPE))

/* cast klass to VoltActorClass class structure */
#define VOLT_ACTOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), VOLT_ACTOR_TYPE, VoltActorClass))

/* check whether klass is a member of the VoltActorClass */
#define IS_VOLT_ACTOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), VOLT_ACTOR_TYPE))

/* get the VoltActorClass structure for a VoltActor obj */
#define VOLT_ACTOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), VOLT_ACTOR_TYPE, VoltActorClass))

// public property enum
enum
{
  VOLT_ACTOR_PROP_RC_RADIUS = 1,
  VOLT_ACTOR_PROP_RC_BL_RADIUS,
  VOLT_ACTOR_PROP_RC_BR_RADIUS,
  VOLT_ACTOR_PROP_RC_TL_RADIUS,
  VOLT_ACTOR_PROP_RC_TR_RADIUS,
  VOLT_ACTOR_PROP_RC_ARC_STEP,
  VOLT_ACTOR_PROP_RC_BL_ARC_STEP,
  VOLT_ACTOR_PROP_RC_BR_ARC_STEP,
  VOLT_ACTOR_PROP_RC_TL_ARC_STEP,
  VOLT_ACTOR_PROP_RC_TR_ARC_STEP,
  VOLT_ACTOR_PROP_LAST_PUBLIC
};

enum
{
  ROUNDED_CORNERS_DISABLED = 0,
  ROUNDED_CORNERS_DEFAULT,
  ROUNDED_CORNERS_CUSTOM
};
/*
 * Private instance fields; see
 * http://www.gotw.ca/gotw/024.htm for the rationale
 */
typedef struct _VoltActorPrivate VoltActorPrivate;
typedef struct _VoltActor        VoltActor;
typedef struct _VoltActorClass   VoltActorClass;

/* object structure */
struct _VoltActor
{
  /*<private>*/
  ClutterActor parent_instance;

  /* structure containing private members */
  /*<private>*/
  VoltActorPrivate *priv;
};

/* class structure */
struct _VoltActorClass
{
  /*<private>*/
  ClutterActorClass parent_class;
};

typedef void (*VoltActorPaintFunc)(VoltActor*);

/* public API */

/* constructor - note this returns a ClutterActor instance */
ClutterActor *volt_actor_new (void);

ClutterPaintNode *volt_actor_get_round_corner_clip_node(VoltActor *actor);
gboolean volt_actor_has_custom_corner(VoltActor *actor);

void volt_actor_custom_rounded_rect(VoltActor *actor, float origin_x, float origin_y,
                                    float width, float height,
                                    float border_width, gboolean painting_border_edge);

void volt_actor_custom_rounded_rect_draw(float origin_x, float origin_y,
    float width,    float height,
    float radius_1, float arc_step_1, // tLeft
    float radius_2, float arc_step_2, // tRight
    float radius_3, float arc_step_3, // bLeft
    float radius_4, float arc_step_4); // bRight

void volt_actor_arc_path(float center_x, float center_y,
                         float radius_x, float radius_y,
                         float angle_1, float angle_2,
                         float angle_step,
                         float *final_x, float *final_y);

/* Transition creator */
ClutterTransition *
volt_actor_create_transition (VoltActor *sActor,
                              const char *propNameOverride,
                              const char *transitionName,
                              GParamSpec   *pspec,
                              ...);

/** Update the volt actor's horizontal translation, taking into
 *  account the origin, anchor, size, and parent's size */
void volt_actor_update_translation_x(VoltActor* self);

/** Update the volt actor's vertical translation, taking into
 *  account the origin, anchor, size, and parent's size */
void volt_actor_update_translation_y(VoltActor* self);

/**
 * volt_actor_draw_path_footprint - Draws the footprint (shape, no color) of actor to the
 * current Cogl path in stage coordinates. This does not included the shadow.
 * The modelview must be set to the stage modelview
 * transformation.
 * This is primarily used by the CutoutEffect to set a clipping path.
 * @author jim (8/4/2014)
 *
 * @param voltActor the actor instance
 */
void volt_actor_draw_path_footprint(VoltActor *voltActor);

/* getter */

gfloat volt_actor_get_width(VoltActor *self);

gfloat volt_actor_get_height(VoltActor *self);

gfloat volt_actor_get_anchor_x(VoltActor *self);

gfloat volt_actor_get_anchor_y(VoltActor *self);

gfloat volt_actor_get_origin_x(VoltActor *self);

gfloat volt_actor_get_origin_y(VoltActor *self);

gfloat volt_actor_get_width(VoltActor *self);

gfloat volt_actor_get_height(VoltActor *self);

gboolean volt_actor_get_rounded_corners(VoltActor *self);

gfloat volt_actor_get_rc_radius(VoltActor *self, int property_id);

gfloat volt_actor_get_rc_arc_step(VoltActor *self, int property_id);

void volt_actor_get_override_color(VoltActor *self, ClutterColor* color);

void volt_actor_get_border_color(VoltActor *self, ClutterColor* color);

gfloat volt_actor_get_border_width(VoltActor *self);

gboolean volt_actor_get_gradient_fill (VoltActor *self);

void volt_actor_get_grad_tl_color(VoltActor *self, ClutterColor* color);

void volt_actor_get_grad_tr_color(VoltActor *self, ClutterColor* color);

void volt_actor_get_grad_bl_color(VoltActor *self, ClutterColor* color);

void volt_actor_get_grad_br_color(VoltActor *self, ClutterColor* color);

void* volt_actor_get_user_data (VoltActor *self);

gboolean volt_actor_get_shadow(VoltActor *self);

gfloat volt_actor_get_shadow_h(VoltActor *self);

gfloat volt_actor_get_shadow_v(VoltActor *self);

gfloat volt_actor_get_shadow_blur(VoltActor *self);

gfloat volt_actor_get_shadow_spread(VoltActor *self);

void volt_actor_get_shadow_color(VoltActor *self, ClutterColor* color);

gboolean volt_actor_get_clip_to_shape(VoltActor *self);

gfloat volt_actor_get_transformed_depth(VoltActor *self);

gboolean volt_actor_get_auto_sort_children_by_depth(VoltActor *self);

/* setters - these are wrappers round functions
 * which change properties of the internal actors
 */

void volt_actor_set_rounded_corners (VoltActor    *self,
                                     gboolean rounded_corners);

void volt_actor_set_rc_radius (VoltActor    *self,
                               gfloat radius, int property_id);

void volt_actor_set_rc_arc_step (VoltActor    *self,
                                 gfloat arc_step, int property_id);


void volt_actor_set_override_color (VoltActor     *self,
                                    const ClutterColor  *color);

void volt_actor_set_border_color (VoltActor     *self,
                                  const ClutterColor  *color);

void volt_actor_set_border_width (VoltActor     *self,
                                  gfloat        width);

void volt_actor_set_anchor_x(VoltActor *self, gfloat value);

void volt_actor_set_anchor_y(VoltActor *self, gfloat value);

void volt_actor_set_origin_x(VoltActor *self, gfloat value);

void volt_actor_set_origin_y(VoltActor *self, gfloat value);

void volt_actor_set_width(VoltActor *self, gfloat value);

void volt_actor_set_height(VoltActor *self, gfloat value);

void volt_actor_set_gradient_fill(VoltActor *self, gboolean gradient_fill);

void volt_actor_set_grad_tl_color (VoltActor     *self,const ClutterColor  *color);

void volt_actor_set_grad_tr_color (VoltActor     *self,const ClutterColor  *color);

void volt_actor_set_grad_bl_color (VoltActor     *self,const ClutterColor  *color);

void volt_actor_set_grad_br_color (VoltActor     *self,const ClutterColor  *color);

void volt_actor_set_user_data(VoltActor *self, void *user_data);

void volt_actor_set_shadow(VoltActor *self, gboolean hasShadow, gfloat xOffset, gfloat yOffset,
                           gfloat blur, gfloat spread, const ClutterColor* color);

void volt_actor_set_shadow_h(VoltActor *self, gfloat hShadow);

void volt_actor_set_shadow_v(VoltActor *self, gfloat vShadow);

void volt_actor_set_shadow_blur(VoltActor *self, gfloat blur);

void volt_actor_set_shadow_spread(VoltActor *self, gfloat spread);

void volt_actor_set_shadow_color(VoltActor *self, const ClutterColor* color);

void volt_actor_shadow_update(VoltActor *self);

void volt_actor_set_clip_to_shape(VoltActor *self, gboolean clip_set);

void volt_actor_set_auto_sort_children_by_depth(VoltActor *self, gboolean auto_sort_children_by_depth);

G_END_DECLS

#endif /* _VOLT_ACTOR_H_ */

