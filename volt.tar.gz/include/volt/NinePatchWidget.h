#pragma once

#include "ImageWidget.h"
#include "VoltActor.h"

namespace volt
{
namespace graphics
{

class NinePatchWidget : public ImageWidget
{
    enum PatchDirection
    {
      Center,
      Up,
      Down,
      Left,
      Right,
      UpperLeft,
      UpperRight,
      LowerLeft,
      LowerRight
    };

    ClutterActor* patches[9];

    Vector2 corner;

  public:

    NinePatchWidget(float x, float y, Widget* parent, Vector2 cornerDimension);
    virtual ~NinePatchWidget();

  protected:

    /** Attach the given volt image to this ImageWidget using
     *  clutter_content_set */
    virtual void attachVoltImage(VoltImage *image);

  private:
    static void onResize(GObject* object, GParamSpec* paramSpec, gpointer data);

    /**Initializes the positions and dimensions of each patch.   */
    void initializePatches();

    /** Based on the width and height of the widget, position and
     *  scale each patch using nine slice scaling */
    void updatePatches();

    VoltActor* getPatch(PatchDirection);

    void setPatchImageTextureCoords(VoltImage*, PatchDirection, float nativeWidth, float nativeHeight);

};
};
};

