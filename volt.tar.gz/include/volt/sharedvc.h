#include <aul.h>
void parse_bundle(bundle *b);
int startVoltContainer(int argc, char **argv,bundle *b);
int startVoltContainerFirstScreen(int argc, char **argv,bundle *b);