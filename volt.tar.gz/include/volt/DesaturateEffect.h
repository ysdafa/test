/*
 * DesaturateEffect.h
 *
 *  Created on: Aug 6, 2013
 *      Author: Jim DiNunzio
 */

#include "Widget.h"
#include "Effect.h"

class DesaturateEffect : public Effect
{
  public:
    static const char* FACTOR_TRANSITION_NAME;
    static const char* EFFECT_NAME;

    DesaturateEffect();
    virtual ~DesaturateEffect();

    void setFactor(double factor);
    double getFactor() const;
};

