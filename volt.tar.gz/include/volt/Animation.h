#ifndef __ANIMATION_H_INCL__
#define __ANIMATION_H_INCL__

#include <functional>
#include <clutter/clutter.h>
#include "AnimationSpec.h"
#include "AnimationHandle.h"

namespace volt
{
namespace graphics
{

class Widget;

/**
 * A template of an animation to be applied
 * to a widget
 */
class Animation : IAnimationCallbacks
{
    float duration, repeat;

    std::map<AnimatableProperty, AnimationSpec > animations;
    std::vector<AnimationCallback> onCompleteCallbacks;

    typedef std::pair<double, AnimationCallback> KeyCallback;
    std::vector<KeyCallback> keyCallbacks;

    std::set<AnimatableProperty> props;

    bool isAnimatingRoundedCorners;

  public:
    // Constructor
    Animation(float duration, int repeat);

    // Destructor
    virtual ~Animation();

    // Copy constructor
    //Animation(const Animation& src);

    // Assignment operator
    //Animation& operator=(const Animation& src);

    /** Cancel ongoing animations by property name */
    static void cancelAnimation(Widget* widget, const std::vector<AnimatableProperty>& propertiesToCancel);

    /** Add a keyframe for one property with a byte or float value
     *  to the Animation */
    void addKey(AnimatableProperty property, float value,  bool isByte = false, TweenMode tweenMode = LINEAR, double key = 1, bool isRelative = false,
                BezierCurve customCurve = BezierCurve());

    /** Add a keyframe for one property with a Vector2 value
     *  to the Animation */
    void addKey(AnimatableProperty property, Vector2 value, TweenMode tweenMode = LINEAR, double key = 1, bool isRelative = false, BezierCurve customCurve = BezierCurve());

    /** Add a keyframe for one property with a Vector3 value to the
     *  Animation */
    void addKey(AnimatableProperty property, Vector3 value, TweenMode tweenMode = LINEAR, double key = 1, bool isRelative = false, BezierCurve customCurve = BezierCurve());

    /** Add a keyframe for one property with a Color value to the
     *  Animation */
    void addKey(AnimatableProperty property, Color value, TweenMode tweenMode = LINEAR, double key = 1, bool isRelative = false, BezierCurve customCurve = BezierCurve());

    /** Apply this animation to a widget */
    AnimationHandle* apply(Widget* widget, AnimationCallback callback = nullptr);

    /** Add a callback function which will be invoked when any
     *  running instance of this animation finishes */
    void addCompletionCallback(AnimationCallback callback);

    /** Add a callback function which will be invoked when any
     *  running instance of this animation reaches the given key */
    void addKeyCallback(double key, AnimationCallback callback);

    float getDuration() const
    {
      return duration;
    }
    void setDuration(float);

    float getRepeat() const
    {
      return repeat;
    }
    void setRepeat(float);

  private:

    static void onAnimationComplete(ClutterTimeline* timeline, gboolean isFinished, gpointer callbackPtr);

    static void deleteFinishedTimeline(ClutterTimeline* timeline, gboolean isFinished, gpointer callbackPtr);

    void addKeyFinal(AnimatableProperty property, GValue value, WidgetPropertyType type, TweenMode tweenMode, double key, bool isRelative, BezierCurve customCurve);

    /** Adds transition to group and unrefs it */
    void addTransitionToWidget(const AnimationSpec& spec, Widget* widget);

    void scheduleCompletionCallback(ClutterTimeline* transition, AnimationCallback callback);

};
};
};

#endif // __ANIMATION_H_INCL__

