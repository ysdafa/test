/*
 * PageCurlEffect.h
 *
 *  Created on: Jul 1, 2013
 *      Author: reza
 */

#ifndef PAGECURLEFFECT_H_
#define PAGECURLEFFECT_H_

#include "Effect.h"

class PageCurlEffect : public Effect
{
  public:
    static const char* PERIOD_TRANSITION_NAME;
    static const char* RADIUS_TRANSITION_NAME;
    static const char* ANGLE_TRANSITION_NAME;
    static const char* EFFECT_NAME;

    PageCurlEffect(double period, double angle, float radius);
    virtual ~PageCurlEffect();

    void setAngle(double angle);
    double getAngle() const;

    void setRadius(float radius);
    float getRadius() const;

    void setPeriod(double period);
    double getPeriod() const;
};

#endif /* PAGECURLEFFECT_H_ */
