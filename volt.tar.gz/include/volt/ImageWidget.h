/*
 * ImageWidget.h
 *
 *  Created on: May 23, 2013
 *      Author: reza
 */

#ifndef IMAGEWIDGET_H_
#define IMAGEWIDGET_H_

#include "VoltImage.h"
#include "Widget.h"
#include "logger.h"
#include <memory>
#include <boost/enable_shared_from_this.hpp>

namespace volt
{
namespace graphics
{

class Image;

typedef std::function<void(bool success)> ImageWidgetReadyCallback;

/**
 * A Widget that displays an Image.
 */
class ImageWidget: public Widget
{

  public:
    enum FillMode //Warning: This is one to one with ClutterContentGravity enum. Do not re-order.
    {
      Top_Left,
      Top,
      Top_Right,
      Left,
      Center,
      Right,
      Bottom_Left,
      Bottom,
      Bottom_Right,
      Stretch,
      Fit
    };

    ImageWidget(float x, float y, Widget* parent = nullptr,
                ImageWidgetReadyCallback ready = nullptr);
    ImageWidget(float x, float y, float width, float height, Widget* parent =
                  nullptr, ImageWidgetReadyCallback ready = nullptr);
    virtual ~ImageWidget();

    /** The source URI from which to get and load the image. Can be file path or URL. */
    void setSource(const std::string&);
    void setSource(const uint8_t *buffer, unsigned int length);
    std::string getSource() const;
    void setSource(Image *aImage);
    Image* getSourceImage() const;

    bool getColorPicking(int percentage, Color* color);

    void setAsyncLoading(const bool async);
    bool getAsyncLoading() const;

    FillMode getFillMode() const
    {
      return fillMode;
    }
    void setFillMode(FillMode mode);

    /** Width in pixels. Width on ImageWidgets is determined by default by the native size of the image. Setting it will scale the image */
    virtual float getWidth() const;
    virtual void setWidth(float width);

    /** Height in pixels. Height on ImageWidgets is determined by default by the native size of the image. Setting it will scale the image */
    virtual float getHeight() const;
    virtual void setHeight(float height);

    inline ImageWidgetReadyCallback getOnReady() const
    {
      return onReady;
    }
    inline void setOnReady(const ImageWidgetReadyCallback& readyCallback)
    {
      onReady = readyCallback;
    }

    static std::string LOGGER_NAME;

    /** Callback triggered when an image is finished loading */
    void onImageLoaded(VoltImage* image, bool success);

  protected:
    /** True if image dimensions have been scaled*/
    bool scaleImageDimensions;

    /** Attach the given volt image to this ImageWidget using
     *  clutter_content_set */
    virtual void attachVoltImage(VoltImage *image);

  private:

    /** The source URI for the displayed image*/
    std::string imageSourceUri;

    /** The Image for the displayed image */
    boost::shared_ptr<Image> imageSource;

    /** Callback invoked when image is loaded */
    ImageWidgetReadyCallback onReady;

    bool isReady;

    /** What to do with the image if the widget size is greater
     *  than the image size. */
    FillMode fillMode;

    static std::unordered_map<int, ImageWidget*> loadImageReceivers;

    static int nextLoadImageReceiverID;

    int loadImageReceiverID;

    bool asyncLoad;

    volt::util::Logger logger_;

    /** Create kicks off the process of loading an image and
     *  registers for a callback on completion */
    void BeginLoadImage(std::string imageUri);

    /** Routes image loaded callbacks to ImageWidgets registered to
     *  receive them */
    static void onImageLoadedRouter(int recieverID, VoltImage* image,
                                    bool success);

    /** Cancel loading any images  */
    void CancelLoadImage();

    /**
     * This is the callback called by the Image class when it finishes loading
     * the image data.
     * @param[in] image Pointer to an Image object.
     */
    void OnImageLoadedCallback(Image *aImage);

};
};
};

#endif /* IMAGEWIDGET_H_ */
