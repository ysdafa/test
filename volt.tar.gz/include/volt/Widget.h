/*
 * Widget.h
 *
 *  Created on: Apr 30, 2013
 *      Author: reza
 */

#ifndef WIDGET_H_
#define WIDGET_H_

#include <clutter/clutter.h>
#include <v8/v8.h>
#include <string>
#include <functional>
#include <deque>
#include <unordered_map>
#include <map>
#include <vector>
#include <set>
#include "Effect.h"
#include "Fill.h"
#include "WidgetUtilities.h"
#include "event_const.h"

namespace volt
{
namespace graphics
{
class Widget;
class AnimationHandle;

typedef std::function<void()> WidgetDestructionCallback;
typedef std::function<void()> FocusEventCallback;
typedef std::function<void(const unsigned, const unsigned)> KeyEventCallback;
typedef std::function<bool(Widget* widget, Widget* origin, const volt::util::MOUSE_BUTTON, Vector2 coordinates)> ButtonPressCallback;

enum AnimatableProperty
{
  InvalidAnimation,

  //1D
  PositionX,
  PositionY,
  Width,
  Height,
  Depth,
  Opacity,
  RotationX,
  RotationY,
  RotationZ,
  ScaleX,
  ScaleY,
  PivotX,
  PivotY,
  AnchorX,
  AnchorY,
  OriginX,
  OriginY,
  ColorR,
  ColorG,
  ColorB,
  ColorA,
  BorderWidth,
  BorderColorR,
  BorderColorG,
  BorderColorB,
  BorderColorA,
  TextColorR,
  TextColorG,
  TextColorB,
  TextColorA,
  RoundedCornersRadius,
  RoundedCornersArcStep,
  CurlPeriod,
  CurlAngle,
  CurlRadius,
  Desaturate,
  Brightness,
  Contrast,
  LineSpacing,
  TextShadowXOffset,
  TextShadowYOffset,
  TextShadowColorR,
  TextShadowColorG,
  TextShadowColorB,
  TextShadowColorA,
  ShadowXOffset,
  ShadowYOffset,
  ShadowBlur,
  ShadowSpread,
  ShadowColorR,
  ShadowColorG,
  ShadowColorB,
  ShadowColorA,

  //2D
  Pivot,
  Scale,
  Anchor,
  Origin,
  RoundedCorners,
  Border,

  //3D
  Rotation,

  //Color
  BackgroundColor,
  BackgroundColor_RC, //used in place of background color when rounded corners are applied
  BorderColor,
  Tint,
  TextColor,
  TextShadowColor,
  ShadowColor
};


/**
 * Widget is the base class of all discrete UI Elements. All Widgets are a node in the scene graph -- they have a parent widget and
 * their position coordinate gives there position relative to their parent in pixels. The SceneRoot itself can be the parent. Widgets
 * with no parent are not rendered. Widgets also have width, height, color, 3d rotation, scale and depth (z-position),
 * and a pivot that is used with the 3d properties.
 */
class Widget
{
    friend class FrameWidget; //FrameWidget needs access to clutter internals of all widgets

    /** A dictionary of all widgets with IDs */
    static std::unordered_map<std::string, Widget*> widgetDictionary;

    static bool registerWidget(Widget* widget, std::string id);
    static void unregisterWidget(std::string id);

    CoglMatrix calculateTransform() const;

  public:

    static Widget* getWidgetByID(std::string id);

    enum MouseEvent
    {
      MOUSE_DOWN = 0, //MouseEvent is used as index into mouseEventGSignalHandlerIDs. Don't do anything unusual with the numeric values!
      MOUSE_UP,
      MOUSE_OVER,
      MOUSE_OUT,
      MOUSE_MOVE,
      MOUSE_CLICK,
      MOUSE_EVENT_COUNT
    };

    enum FocusEvent
    {
      ON_FOCUS = 0, 
      ON_UNFOCUS
    };


    typedef std::multimap<MouseEvent, ButtonPressCallback>::iterator EventHandle;
    typedef std::multimap<FocusEvent, FocusEventCallback>::iterator FocusEventHandle;
    typedef std::multimap<unsigned int, KeyEventCallback>::iterator KeyEventHandle;

    /* IDs for the g_object callbacks associated with clutter
     *  mouse events. One per type of mouse event. Should be
     *  equal to the number of MouseEvents. Must be initialized to all 0. */
    gulong mouseEventGSignalHandlerIDs[MOUSE_EVENT_COUNT];

    Widget();

    Widget( float x, float y, float width, float height, Widget* aParent = nullptr);

    virtual ~Widget();

    /** X position (pixels)*/
    float getX() const;
    void setX(float x);

    /** Y position (pixels)*/
    float getY() const;
    void setY(float y);

    /** Width (pixels) */
    virtual float getWidth() const;
    virtual void setWidth(float width);

    /** Width (height) */
    virtual float getHeight() const;
    virtual void setHeight(float height);

    /** User defined name*/
    std::string getID() const;
    void setID(const std::string & name);

    /** Background color (rgba) */
    virtual Color getColor() const;
    virtual void setColor(const Color& color);

    /** Opacity. 0 - 1. Applied on top of alpha channel of color */
    int getOpacity() const;
    void setOpacity(int opacity);

    /** Whether or not to render using depth testing, in order to guarantee proper draw order of 3d shapes */
    bool getDepthTestEnabled() const;
    void setDepthTestEnabled(bool enable);

    /** Whether or not to cull (remove) back faces from the render (e.g. useful for rendering
     *  3D cube without depth testing) */
    bool getBackfaceCullingEnabled() const;
    void setBackfaceCullingEnabled(bool enable);

    /** Depth, Z-position. Does not determine draw order */
    float getDepth() const;
    void setDepth(float);

    /** Parent property. Positioning is relative to parent's position */
    virtual Widget* getParent() const;
    virtual void setParent(Widget* parent);

    Vector2 getOrigin() const;
    void setOrigin(Vector2 origin);

    Vector2 getAnchor() const;
    void setAnchor(Vector2 origin);


    /** Pivot. All rotations and scales are applied with the pivot as the origin point */
    Vector2 getPivot() const;
    void setPivot(Vector2);

    /** Scale. Applies to all children, unlike width and height*/
    virtual Vector2 getScale() const;
    virtual void setScale(Vector2);
    virtual void setScale(double); //uniform scale

    /** Rotation around the pivot in 3D space */
    Vector3 getRotation() const;
    void setRotation(Vector3);

    /** Whether or not to hide overflow */
    bool getCropOverflow() const;
    void setCropOverflow(bool crop);

    /** Border */
    Color getBorderColor() const;
    void setBorderColor(const Color& color);
    float getBorderWidth() const;
    void setBorderWidth(float width);

    /** Gradient */
    void setGradientFill(bool gradientFill);
    bool getGradientFill() const;

    void setGradTlColor(const Color& tlColor);
    Color getGradTlColor() const;

    void setGradTrColor(const Color& trColor);
    Color getGradTrColor() const;

    void setGradBlColor(const Color& blColor);
    Color getGradBlColor() const;

    void setGradBrColor(const Color& brColor);
    Color getGradBrColor() const;

    //Effects

    Effect* getEffect(std::string id);
    void setEffect(Effect* effect, std::string id);
    void removeEffect(std::string id);

#if EXPERIMENTAL_BUILD
    bool getBlur() const;
    void setBlur(bool enabled);

    Color getTint() const;
    void setTint(const Color& tint);

    float getBrightness() const;
    void setBrightness(float value);

    float getContrast() const;
    void setContrast(float value);

    double getDesaturateFactor() const;
    void setDesaturateFactor(double factor);

    double getPageCurlPeriod() const;
    void setPageCurlPeriod(double period);

    double getPageCurlAngle() const;
    void setPageCurlAngle(double angle);

    float getPageCurlRadius() const;
    void setPageCurlRadius(float radius);
#endif

    // Paint Contents
    Fill* getFill()
    {
      return fill;
    }
    void setFill(Fill* fill);

    // Scaling Filters
    void setMinScalingFilter( ScalingFilter filter );
    ScalingFilter getMinScalingFilter() const;
    void setMaxScalingFilter( ScalingFilter filter );
    ScalingFilter getMaxScalingFilter() const;

    /** Makes the widget visible if it had been hidden. Affects children. */
    void show();

    /** Makes the widget and all its children invisible. */
    void hide();

    /** Set the direction in which new children are automatically positioned relative to old children.
     * @param[in] orientation Possible values: "horizontal" and "vertical" */
    /*void setLayout(LayoutOrientation orientation = Horizontal, int spacing = 0,
        LayoutAlignment alignmentX = Left, LayoutAlignment alignmentY = Left);*/

    //scene graph

    /** Return the absolute position of this widget in pixels */
    Vector3 getAbsolutePosition() const;

    /** Return the absolute size of this widget in pixels,
     *  including size chage due to scale, parent scale, etc. */
    Vector2 getAbsoluteSize() const;

    int getChildCount() const;

    /**  Add a child widget to this one. The child will immediately be position relative to this widget, and
     * if it already had a parent, it will be removed from that parent
     * @param[in] child The Widget to adopt
     * @param[in] index Optional. The index to put the new child in (shifting other children about as needed. Child-index determines
     * draw order. If not provided the child is added as the last child.
     * @return The index at which the child was added.*/
    virtual int addChild(Widget* child, int index = -1);

    /** Remove the widget the children list. */
    virtual void removeChild(Widget* target);

    /** Remove the widget at the given index from the children
     *  list. Returns nullptr if invalid index */
    Widget* removeChildByIndex(uint index);

    /** Get a reference to the child at a given index.
     * @return A reference to the removed child*/
    Widget* getChildByIndex(uint index);

    /** Get a reference to the child with a given name.
     * @return A reference to the removed child or nullptr*/
    Widget* getChildByName(std::string id);

    /** @return The number of children this widget has */
    uint getChildCount()
    {
      return children.size();
    }

    /** @return a reference to the descendent Widget with the given ID, or null if none exists */
    virtual Widget* getDescendent(std::string id);

    /** @return a reference to the ancestor Widget with the given ID, or null if none exists */
    virtual Widget* getAncestor(std::string id);

    /** Irreversibly delete all children of widget */
    void destroyChildren();

    /** @return a bool indicating whether this Widget has rounded
     *          corners */
    bool getRoundedCorners() const;

    /** Sets whether the Widget has rounded corners */
    void setRoundedCorners(bool isRoundedRect);

    /** @return a float with the radius of the rounded corners */
    float getRCornerRadius() const;

    /** Sets the radius of the rounded corners */
    void setRCornerRadius(float radius);

    /** @return a float with the arc step (degrees, smaller is
     *          smoother) of the rounded corners */
    float getRCornerArcStep() const;

    /** Sets the arc step (degrees, smaller is
     *          smoother) of the rounded corners.  */
    void setRCornerArcStep(float arcStep);

    /** Returns the underlying ClutterActor that should be used
     *  for animation. */
    virtual ClutterActor* getAnimationActor(AnimatableProperty = InvalidAnimation)
    {
      return actor;
    }

    /** Sets the arc step (degrees, smaller is
     *          smoother) and radius of the bottom left corner.  */
    void setRCornerBLeft(const Corner& corner);

    /** Gets the arc step (degrees, smaller is
     *          smoother) and radius of the bottom left corner.  */
    Corner getRCornerBLeft() const;

    /** Sets the arc step (degrees, smaller is
     *          smoother) and radius of the bottom right corner.  */
    void setRCornerBRight(const Corner& corner);

    /** Gets the arc step (degrees, smaller is
     *          smoother) and radius of the bottom right corner.  */
    Corner getRCornerBRight() const;

    /** Sets the arc step (degrees, smaller is
     *          smoother) and radius of the top left corner.  */
    void setRCornerTLeft(const Corner& corner);

    /** Gets the arc step (degrees, smaller is
     *          smoother) and radius of the top left corner.  */
    Corner getRCornerTLeft() const;

    /** Sets the arc step (degrees, smaller is
     *          smoother) and radius of the top right corner.  */
    void setRCornerTRight(const Corner& corner);

    /** Gets the arc step (degrees, smaller is
     *          smoother) and radius of the top right corner.  */
    Corner getRCornerTRight() const;

    /** @return a bool indicating whether this Widget has a shadow */
    bool getShadow() const;

    /** Sets whether the widget has a shadow */
    void setShadow(bool hasShadow, float xOffset = 0.0f, float yOffset = 0.0f,
                   int blur = 0, int spread = 0, const Color& color = Color(0,0,0,255));

    /** @return a float with the shadow x position offset */
    float getShadowXOffset() const;

    /** Sets the shadow's x position offset */
    void setShadowXOffset(float xOffset);

    /** @return a float with the shadow y position offset */
    float getShadowYOffset() const;

    /** Sets the shadow's y position offset */
    void setShadowYOffset(float yOffset);

    /** @return an int with the shadow's blur size */
    int getShadowBlur() const;

    /** Sets the shadow's blur size */
    void setShadowBlur(int shadowBlur);

    /** @return an int with the shadow's spread */
    int getShadowSpread() const;

    /** Sets the shadow's spread */
    void setShadowSpread(int shadowSpread);

    /** @return a Color with the shadow's color */
    Color getShadowColor() const;

    /** Sets the shadow's color */
    void setShadowColor(const Color& shadowColor);

    /** Sets the cutThrough Widget */
    void setCutThrough(Widget* cutThrough);

    /** Gets the cutThrough Widget */
    Widget* getCutThrough() const;

    /** Gets the autoSortChildrenByDepth flag */
    bool getAutoSortChildrenByDepth() const;

    /** Sets the autoSortChildrenByDepth */
    void setAutoSortChildrenByDepth(bool autoSortChildrenByDepthIn);

    /** Reorders the widget's children from smallest (1st child) to largest depth (last child) */
    void reorderChildrenByDepth();

    /** Computes the widget's depth transformed to stage coordinates */
    float getTransformedDepth() const;

    //Event handling
    void registerDestructionEvent(WidgetDestructionCallback callback);

    FocusEventHandle registerFocusEvent(FocusEvent, FocusEventCallback);
    void unregisterFocusEvent(FocusEventHandle);
    void fireFocusEvent(FocusEvent);

    KeyEventHandle registerKeyEvent(unsigned, KeyEventCallback);
    void unregisterKeyEvent(KeyEventHandle);
    //void fireKeyEvent(unsigned); //here or tied to global, or both

    EventHandle registerMouseEvent(MouseEvent, ButtonPressCallback);

    void unregisterMouseEvent(MouseEvent, EventHandle handle);

    /** Trigger this mouse event.*/
    void fireMouseEvent(MouseEvent, volt::util::MOUSE_BUTTON, Vector2 coords);

    /** Invoke any callbacks associated with this event on this Widget, with given values. Will NOT bubble up the widget
      heirarchy. */
    bool invokeMouseEventCallbacks(MouseEvent, Widget* origin, volt::util::MOUSE_BUTTON, Vector2 coords);

    /** Checks whether the given property is currently animated. */
    bool hasAnimationProp(AnimatableProperty) const;

    /** Remove and cancel any animation of the given property from
     *  this widget. */
    void removeAnimation(AnimatableProperty);

    /** Remove an animation handle from this widget. This should
     *  only be done if the handle has first been cancelled. */
    void removeAnimationHandle(AnimationHandle*);

    /**Add an Animation handle to this widget. This should only
     * be done after the animation has been applied. */
    void addAnimationHandle(AnimationHandle*);

    bool hasKeyFocus() const; 
	
	inline ClutterActor* getActor() 
	{
		return actor;
	} 
    

#ifdef UNUSED_CODE
    /**
     * FindWhichChildOfAncestor - find which child of the given ancestor is an ancestor
     * of the given widget
     *
     * @author jim (7/31/2014)
     *
     * @param widget - the given widget
     * @param ancestor - an ancestor of the given widget
     *
     * @return Widget* - the child of the ancestor which is also an ancestor of the widget
     */
    Widget* FindWhichChildOfAncestor(Widget* widget, Widget* ancestor);

    /**
     * FindFirstCommonAncestor - find the first common ancestor of two widgets
     *
     * @author jim (7/31/2014)
     *
     * @param w1 first widget
     * @param w2 second widget
     *
     * @return Widget* the first common ancestor of w1 and w2 widgets
     */
    2
    Widget* FindFirstCommonAncestor(Widget* w1, Widget* w2);
#endif

  protected:

    /** The parent widget in the scene graph */
    Widget* parent;

    /** List of child widgets */
    std::deque<Widget*> children;

    /** List of functions to call when object is destroyed */
    std::vector<std::function<void()>> destructionCallbacks;

    /** A map of effects applied to the object, they are mapped by string ids*/
    std::map<std::string, Effect*> effects;

    ClutterActor* actor;

    /** User assigned name*/
    std::string uniqueID;

    /** How the widget is painted */
    Fill* fill;

    /** The widget (and its descendants) that will have a hole cut in them so this
    *  widget will show through */
    Widget* cutThrough;

    /** Cached transformed depth used for sorting by depth. */
    float cachedTransformedDepth;

    /** Signal handler for the children's depth changed signal */
    gulong childrenDepthsSignalHandlerId;

    /**Currently active animations. */
    std::vector<AnimationHandle*> animations;

    /**Hold registered callbacks for focus/unfocus event */ 
    std::multimap<FocusEvent, FocusEventCallback>  focusEventCallbacks;

    /**Hold registered callbacks for key events */ 
    std::multimap<unsigned, KeyEventCallback> keyEventCallbacks;


    // Mouse events:
    /** The callbacks to be triggered in response to registered
     *  mouse events */
    std::multimap<MouseEvent, ButtonPressCallback> mouseCallbacks;

    //Mouse events helper stuff:

    //Widgets in this set have been clicked since the mouse button was last released
    static std::set<Widget*> clickedWidgets;

    //Currently focused widget
    static Widget* focusedWidget;

    static gboolean onFocusInEvent(ClutterActor* /* unused */, gpointer aWidget);
    static gboolean onFocusOutEvent(ClutterActor* /* unused */, gpointer aWidget);
    static gboolean onKeyEvent(ClutterActor* /* unused */, ClutterEvent *aEvent, gpointer aWidget);

    static gboolean onGlobalMouseRelease(ClutterActor*, ClutterEvent *aEvent, gpointer aWidget);
    static gboolean onMouseEvent(ClutterActor* /* unused */, ClutterEvent *aEvent, gpointer aWidget);
    static gboolean onMouseClickPress(ClutterActor* actor, ClutterEvent *aEvent, gpointer aWidget);

    static MouseEvent clutterToVoltMouseEvent(ClutterEventType eventType);
    static const char* getClutterEventStringID(Widget::MouseEvent eventType);
    static void onChildrenDepthsChanged(GObject* object, gpointer data);

    void insertSortChildren();
    void updateChildrenCachedDepths();

    /** Default initialization of the wrapped ClutterActor.
     * @param[in] x position
     * @param[in] y position */
    void init(float x, float y, Widget* parent = nullptr);

    void updateAnchorOrigin();
    void checkAddBrightCont(class BrightnessContrastEffect*& brightCont, float value);

    bool hasRoundedCornerCroppingAncestor() const;

    static bool compWidgetByDepth(Widget* w1, Widget* w2);

#if UNUSED_CODE
    Widget* FindFirstCommonAncestorRecurse(Widget* w1, Widget* w2, Widget* ancestor);
#endif
};
};
};

#endif /* WIDGET_H_ */
