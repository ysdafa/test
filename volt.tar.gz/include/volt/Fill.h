/*
 * Fill.h
 *
 *  Created on: July 19, 2013
 *      Author: jim dinunzio
 */


#ifndef FILL_H
#define FILL_H


class Fill
{
  public:
    Fill() : content(0) {};
    virtual ~Fill()
    {
      if (content)
      {
        g_object_unref(content);
        content = NULL;
      }
    }

    ClutterContent* getContent() const
    {
      return content;
    }

  protected:
    ClutterContent* content;
};

#endif /* FILL_H */

