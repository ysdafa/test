/*
* VoltText.h
*
*  Created on: June 25, 2014
*      Author: jim dinunzio
*/

#pragma once

#include <clutter/clutter.h>
#include <pango/pango.h>

G_BEGIN_DECLS

#define VOLT_TYPE_TEXT               (volt_text_get_type ())
#define VOLT_TEXT(obj)               (G_TYPE_CHECK_INSTANCE_CAST ((obj), VOLT_TYPE_TEXT, VoltText))
#define VOLT_TEXT_CLASS(klass)       (G_TYPE_CHECK_CLASS_CAST ((klass), VOLT_TYPE_TEXT, VoltTextClass))
#define VOLT_IS_TEXT(obj)            (G_TYPE_CHECK_INSTANCE_TYPE ((obj), VOLT_TYPE_TEXT))
#define VOLT_IS_TEXT_CLASS(klass)    (G_TYPE_CHECK_CLASS_TYPE ((klass), VOLT_TYPE_TEXT))
#define VOLT_TEXT_GET_CLASS(obj)     (G_TYPE_INSTANCE_GET_CLASS ((obj), VOLT_TYPE_TEXT, VoltTextClass))

typedef struct _VoltText        VoltText;
typedef struct _VoltTextClass   VoltTextClass;

ClutterActor *volt_text_new (void);

ClutterActor *volt_text_new_full (const gchar        *font_name,
                                  const gchar        *text,
                                  const ClutterColor *color);

GType volt_text_get_type (void) G_GNUC_CONST;

gint volt_text_get_line_spacing (VoltText *self);

gboolean volt_text_get_has_shadow (VoltText *self);

gfloat volt_text_get_shadow_x_offset(VoltText *self);

gfloat volt_text_get_shadow_y_offset(VoltText *self);

void volt_text_get_shadow_color(VoltText *self, ClutterColor* color);

gboolean volt_text_get_is_right_to_left(VoltText *self);

gboolean volt_get_is_right_to_left(const gchar* string);

void volt_text_set_line_spacing (VoltText *self,
                                 gint line_spacing);

void volt_text_set_has_shadow (VoltText *self, gboolean has_shadow);

void volt_text_set_shadow_x_offset(VoltText *self, gfloat x_offset);

void volt_text_set_shadow_y_offset(VoltText *self, gfloat y_offset);

void volt_text_set_shadow_color(VoltText *self, const ClutterColor* color);

G_END_DECLS
