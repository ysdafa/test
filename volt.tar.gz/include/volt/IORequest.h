/*
 * IORequest.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_IO_REQUEST_H
#define SAMSUNG_KINGSCANYON_IO_REQUEST_H

#include <memory>
#include <vector>
#include <boost/enable_shared_from_this.hpp>
#include <boost/serialization/map.hpp>

#include "ResourceRequest.h"
#include "time_util.h"
#include "logger.h"
#include "macros.h"

namespace Resource
{

/* Forward */
class IORequest;

class IOResponse : public boost::enable_shared_from_this<IOResponse>
{
  public:
    static std::string LOGGER_NAME;

    typedef boost::shared_ptr<IOResponse> SharedPtr;

    /** Supported data source. */
    enum Source { SOURCE_FILE, SOURCE_DIRECTORY, SOURCE_NETWORK, SOURCE_INVALID };

    /**
     * Utility function to convert Source enum to string.
     * @param[in] aSource Source enum to convert to string.
     * @return Converted string.
     */
    static const std::string& SourceToString(const Source &aSource);

  public:
    IOResponse();
    IOResponse(const IORequest &aRequest);
    virtual ~IOResponse();

    /**
     * Append data bytes to the internal buffer.
     * @param[in] aBuffer Data buffer.
     * @param[in] aSize Size of the buffer.
     */
    void AppendData(const void *aBuffer, const size_t aSize);

    void SetHeader(const std::string& key, const std::string& value);

    virtual bool IsCacheable() const;

    virtual bool IsFromCache() const;

    virtual bool IsExpired() const;

    template<class Archive>
    void serialize(Archive &aArchive, const unsigned int aVersion)
    {
      LOG_DEBUG(logger_, "Serialize: " << uri_);
      LOG_DEBUG(logger_, "Version: " << aVersion);

      aArchive & uri_;
      aArchive & status_;
      aArchive & reason_string_;
      aArchive & source_;
      aArchive & type_;
      aArchive & data_;
      aArchive & cache_key_;
      aArchive & headers_;

      LOG_DEBUG(logger_, "URI: " << uri_);
      LOG_DEBUG(logger_, "Status: " << status_);
      LOG_DEBUG(logger_, "Reason string: " << reason_string_);
      LOG_DEBUG(logger_, "Source: " << SourceToString(source_));
      LOG_DEBUG(logger_, "Type: " << type_);
      LOG_DEBUG(logger_, "Data size: " << data_.size());
      LOG_DEBUG(logger_, "Cache key: " << cache_key_);
      LOG_DEBUG(logger_, "Headers:");

      for (auto iter = headers_.begin(); iter != headers_.end(); ++iter)
      {
        LOG_DEBUG(logger_, iter->first << ": " << iter->second);
      }

      is_from_cache_ = true;
    }

  private:
    volt::util::Logger logger_; /**< Logger name. */

    PROPERTY_RO(bool, is_from_cache);

    PROPERTY_CONST_REF(std::string, uri);
    PROPERTY(long int, status);
    PROPERTY_CONST_REF(std::string, reason_string);
    PROPERTY(Source, source);
    PROPERTY_CONST_REF(std::string, type);
    PROPERTY_CONST_REF(std::string, data);
    PROPERTY_CONST_REF(std::string, cache_key);
    typedef std::map<std::string, std::string> HeaderMapType;
    PROPERTY_CONST_REF(HeaderMapType, headers);
};

/**
 * This class holds the data and callbacks to handle single HTTP transaction.
 */
class IORequest : public boost::enable_shared_from_this<IORequest>
{
  public:
    static std::string LOGGER_NAME;

    typedef boost::shared_ptr<IORequest> SharedPtr;

    /** Supported HTTP methods. */
    enum Method { METHOD_GET, METHOD_PUT, METHOD_POST, METHOD_DELETE,
                  METHOD_INVALID
                };

    /** Signature of the callback required for async requests. */
    typedef std::function<void (SharedPtr)> OnCompleteCallback;

    /**
     * Utility function to convert Source enum to string.
     * @param[in] aSource Source enum to convert to string.
     * @return Converted string.
     */
    //static const std::string& SourceToString(const Source &aSource);

    /**
     * Utility function to convert string to enum Method.
     * @param[in] aMethodStr Method string (eg "GET").
     * @return Corresponding enum Method.
     */
    static Method StringToMethod(const std::string &aMethodStr);

    /** Supported response type requested by the caller. */
    enum ResponseType { RESPONSE_STRING, RESPONSE_ARRAY_BUFFER, RESPONSE_DIRECTORY, RESPONSE_INVALID };

    /**
     * Utility function to convert ResponseType enum to string.
     * @param[in] aType ResponseType enum to convert to string.
     * @return Converted string.
     */
    static const std::string& ResponseTypeToString(const ResponseType &aType);

  public:
    /**
     * Construct with URL.
     * @param[in] aUri URL of the request.
     */
    IORequest(const std::string &aUri);
    virtual ~IORequest();

    /**
     * Copy request headers from the supplied source.
     * @param[in] aHeaders List of headers.
     */
    virtual void SetHeaders(const ResourceRequest::HeaderList &aHeaders);

    /**
     * Perform any finalization steps required before processing this request.
     */
    virtual void Finalize();

    virtual void FinalizeResponse();

    virtual void InitResponse();

    virtual bool ValidateCachedResponseBeforeRequest();
    virtual bool ValidateCachedResponseAfterRequest();

    virtual void ResetCacheKey();

    /**
     * Execute synchronous IO operation.
     * Though this is a synchronous operation, every derived class of
     * IORequest must implement this function.  IOManager may call this
     * function in its worker thread for requests that can not be made fully
     * asynchronous.
     *
     * @return true if successful, false otherwise.
     */
    virtual bool Execute() = 0;

    /**
     * Callback function to be called by IOManager when the IO completes.
     */
    virtual void Callback();

    /**
     * Check if the request is valid.
     * @return true if valid.
     */
    virtual bool IsValid() const;

    virtual bool ShouldCacheResponse() const;

  private:
    volt::util::Logger logger_; /**< Logger name. */

    PROPERTY(unsigned int, id);
    PROPERTY_CONST_REF(std::string, uri);
    PROPERTY_CONST_REF(std::string, src);
    PROPERTY(bool, async);
    PROPERTY(bool, recursive);
    PROPERTY_CONST_REF(OnCompleteCallback, on_complete_callback);
    PROPERTY(Method, method);
    PROPERTY_CONST_REF(std::string, data);

    PROPERTY(ResponseType, response_type);
    PROPERTY_CONST_REF(IOResponse::SharedPtr, response);
    PROPERTY_CONST_REF(IOResponse::SharedPtr, cached_response);

    PROPERTY_CONST_REF(std::string, cache_key);
    PROPERTY(bool, no_cache);
};

} /* namespace Resource */

#endif /* SAMSUNG_KINGSCANYON_IO_REQUEST_H */
