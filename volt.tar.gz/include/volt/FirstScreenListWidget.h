/*
 * FirstScreenListWidget.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef FIRSTSCREENLISTWIDGET_H_
#define FIRSTSCREENLISTWIDGET_H_

#include "Widget.h"
#include "logger.h"
#include "ScriptBridge.h"

using namespace Bridge;

/*
 * Abstract Base class of all Widgets which impose positioning on their children
 */

namespace volt
{
namespace graphics
{

class FirstScreenListItem 
{
public:
	ClutterActor* container;
	ClutterActor* mainImage;
	ClutterActor* titleBox;
	ClutterActor* title1;
	ClutterActor* title2;
	ClutterActor* iconBox;
	ClutterActor* icon1;
	ClutterActor* icon2;
	ClutterActor* icon3;
	ClutterActor* icon4;
	ClutterActor* icon5;
	ClutterActor* border;
};

class FirstScreenCategory 
{
public:
	std::string id;
	ScriptObject jsInstance;

	ClutterActor* categoryWrapper;
	ClutterActor* categoryTitle;
	ClutterActor* listWrapper;
	ClutterActor* color;
	ClutterActor* liveParent1;
	ClutterActor* liveParent2;
	ClutterActor* post1;
	ClutterActor* post2;
	ClutterActor* post3;
	ClutterActor* post4;
	ClutterActor* post5;
	ClutterActor* post6;
	ClutterActor* border;
	
	ScriptFunction onExtendCallback;
};

class FirstScreenContents
{
public:
	std::string id;
	ScriptObject jsInstance;

	ClutterActor* contentsWrapper;
	ClutterActor* dominant;
	ClutterActor* titleParent;
	ClutterActor* mainWrapper;
	ClutterActor* main;
	ClutterActor* overRay;
	ClutterActor* normalTitle;
	ClutterActor* focusTitle;
	ClutterActor* border;
	ClutterActor* iconParent1;
	ClutterActor* iconParent2;
	ClutterActor* subMain;
	ClutterActor* progressP;
	ClutterActor* options;
	Color dominantColor;
	int index;
	std::string categoryType;
	bool skipTransition;
	bool haveOptions;
	
	ScriptFunction onClickCallback;
	ScriptFunction startTransitionCallback;
	ScriptFunction stopTransitionCallback;
    ScriptFunction focusOptionsCallback;
	ScriptFunction unfocusOptionsCallback;
	ScriptFunction enterOptionsCallback;
	ScriptFunction longPressCallback;
};

class FirstScreenListWidget : public Widget
{
public:
	FirstScreenListWidget(Widget* parent);
    virtual ~FirstScreenListWidget() {}


	void redefineGlobalParams(float scene_height);
	//void createCategory(FirstScreenCategory* Item, ClutterActor* parent);
	void createChild(FirstScreenCategory* Item);
	void createContents(FirstScreenContents* Item);
	
	void removeCategory(int categoryIndex);
	void removeCategoryById(std::string id);
	void removeContents(int categoryIndex, int contentsIndex);
	void removeContentsById(std::string id);
	
	void setFocus(int contentsIndex);
	void setFocusById(std::string id);
	bool focusOptions();
	void unfocusOptions();
	bool enterOptions();
	
	void animateOnEnter();
	
	void moveLeft();
	void moveRight();
	
	int returnCategory();
	int returnContents();
	void riseFirstScreen();
	
	void off_transition_noanimaition();
	void stop_transition();

	float getPositionX(std::string categoryType, int contentsIndex);
	float getPositionY(std::string categoryType, int contentsIndex);
	
	void changeIcon(std::string categoryType, int contentsIndex, int number, ClutterActor *newIconParent);
	
	void addSubMain(std::string categoryType, int contentsIndex, ClutterActor* subMain);
	void changeContentLive(std::string categoryType, std::string contentsType, int contentsIndex, int num, ClutterActor* contentLive);

	int getCategoryIndexByID(std::string categoryType);
	void setProgress(std::string categoryType, int contentsIndex, gfloat progress);
	
	void setExtendBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time);
	void setLiveImageBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2);
	void setHorizontalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2);
	void setVerticalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2);
	void setContentLiveBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2);
	
	void fallFirstScreen();

	int addItem(FirstScreenListItem* item);

	int size();
	int clear();

	int getSelectedItemPos();

	void sendKeyEvent(int keyType, int keyCode);
	void startAnimation();
	void stopAnimation();
	void updateDominantColor(ClutterActor* dominant, Color dominantColor);
	int getLastMouseMovedTime();

	FirstScreenCategory* findCategory(std::string tag);
	FirstScreenContents* findContents(std::string tag);
	
	void setOnItemSelectedListener(ScriptFunction callback);
	void setOnItemLongPressedListener(ScriptFunction callback);
	void setOnItemChangedListener(ScriptFunction callback);

	//////// shuhao.yan
	void rotateWgt_Y_axis(ClutterActor* actor);
	void reverseOSD(bool reverseFlag);
	
	void setFirstState();
	void returnAnimation();

	
	void setBarOpacityZero();
	void setBarOpacityMax();

public:
	ScriptFunction onItemSelectedListener;
	ScriptFunction onItemLongPressedListener;
	ScriptFunction onItemChangedListener;
	Widget *SCENEROOT;
};

} /* namespace Bridge */
}
#endif /* FIRSTSCREENLISTWIDGET_H_ */
