#include <iostream>
#include <functional>
#include <map>
#include <queue>
#include <string>
#include <cstring>
#include <libwebsockets.h>

#ifdef _WIN32 || _WIN64
#include<WS2tcpip.h> 
#include <Windows.h>
#include <process.h>
#elif defined __linux__
#include <thread>
#include <glib.h>
#include <mutex>
#endif




class WebSocketMessenger{
public:
	WebSocketMessenger();
	~WebSocketMessenger();
	WebSocketMessenger(std::string address);
	WebSocketMessenger(std::string address, std::string protocolName);

	void connect();
	void startService();
	void destroyService();
	void send(std::string message);
	void onOpen();
	void onMessage(std::string data);
	void onError();
	void onClose();
	bool isRun() const; 
	void setIsRun(bool isRun);
	unsigned char* getMessage();
private:
	void init(std::string address, std::string protocolName);
	struct libwebsocket_context *context;
	struct lws_context_creation_info info;
	struct libwebsocket *wsi_dumb;
	char *address; 
	char *protocolName;
	int port;
	int ssl;
	bool run;
	struct libwebsocket_protocols protocols[2];
	std::queue<std::string> messageQueue;

#ifdef _WIN32 || _WIN64
	HANDLE hThread;
#elif defined __linux__
	std::thread serviceThread;
#endif

public:
	std::function<void()> onOpenCallback;
	std::function<void(std::string data)> onMessageCallback;
	std::function<void()> onErrorCallback;
	std::function<void()> onCloseCallback;
};

