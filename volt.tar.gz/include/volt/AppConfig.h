#ifndef SAMSUNG_KINGSCANYON_APP_CONFIG_H
#define SAMSUNG_KINGSCANYON_APP_CONFIG_H

#include <libxml++/libxml++.h>
#ifdef TIZEN
#include <jsoncpp/json/json.h>
#else
#include <json/json.h>
#endif
#include <boost/program_options.hpp>

class AppConfig
{
  public:
    static AppConfig& Instance();

    const std::string& GetProgramName() const;

    void SetProgramName(const char *aName);

    void PrintUsage() const;

    /**
     * Parse the command line arguments.
     * This will clear the previously parsed command line arguments.
     * @param[in] aArgc Number of arguments (including the program name).
     * @param[in] aArgv Arguments (including the program name).
     * @return true on success, false otherwise.
     */
    bool ParseCommandLineArgs(const int aArgc, char *aArgv[]);

    /**
     * Parse a text configuration file (typically volt.conf).
     * The configuration file should be a plain text with key-value pair
     * delimited by '='.
     * param[in] aPath Path to the configuration file.
     * @return true on success, false otherwise.
     */
    bool ParseVoltConf(const std::string aPath);

    /**
     * Parse a XML configuration file (typically config.xml).
     * Volt configuration options should be inside the <volt> element.
     * Each element with text value is treated as a command line equivalent.
     * For example, <msaa-samples>8</msaa-samples> will be treated as if you
     * are passing in --msaa-samples=8 on the command line.
     * param[in] aPath Path to the configuration file.
     * @return true on success, false otherwise.
     */
    bool ParseConfigXml(const std::string aPath);

    /**
     * Parse a JSON configuration file (typically config.json).
     * Volt configuration file should have a JSON object at its root (ie not
     * an array).
     * Each value is treated as a command line equivalent.
     * For example, "msaa-samples":8 will be treated as if you
     * are passing in --msaa-samples=8 on the command line.
     * param[in] aPath Path to the configuration file.
     * @return true on success, false otherwise.
     */
    bool ParseConfigJson(const std::string aPath);

    /**
     * Clear configuration options parsed so far.
     */
    void Clear();

    /**
     * Check if a configuration option is set.
     * This will return true for the options with default value as well.
     * @param[in] aKey Configuration option name.
     * @return true if the option is set, false otherwise.
     */
    bool IsSet(const std::string aKey) const;

    /**
     * Get the value of a configuration option in the specified/templated data
     * type.
     * @param[in] ValueType The expected data type of the configuration value.
     * @param[in] aKey Configuraiton option name.
     * @return Configuration option value.
     */
    template<typename ValueType>
    ValueType GetValue(const std::string aKey) const
    {
      try
      {
        return GetVariableValue(aKey).as<ValueType>();
      }
      catch (boost::bad_any_cast)
      {
        return GetLastValue<ValueType>(aKey);
      }
    }

    template<typename ValueType>
    ValueType GetFirstValue(const std::string aKey) const
    {
      std::vector<ValueType> values = GetVariableValue(aKey).as<std::vector<ValueType>>();

      if (values.empty())
      {
        throw new boost::bad_any_cast;
      }

      return values.front();
    }

    template<typename ValueType>
    ValueType GetLastValue(const std::string aKey) const
    {
      std::vector<ValueType> values = GetVariableValue(aKey).as<std::vector<ValueType>>();

      if (values.empty())
      {
        throw new boost::bad_any_cast;
      }

      return values.back();
    }

    /**
     * Get the path to the Volt root directory.
     * @return Volt root path.
     */
    const std::string& GetVoltRootPath() const;

    /**
     * Get the path to the Volt config directory.
     * @return Volt config path.
     */
    const std::string& GetVoltConfigPath() const;

    /**
     * Get the path to the Volt data directory.
     * @return Volt data path.
     */
    const std::string& GetVoltDataPath() const;

    /**
     * Get the path to the Volt app root directory.
     * @return Volt app root path.
     */
    const std::string& GetAppRootPath() const;

    /**
     * Get the path to the Volt app data directory.
     * @return Volt app data path.
     */
    const std::string& GetAppDataPath() const;

    /**
     * Get the path of the application JS relative to the Volt app root path.
     * @return Application JS path relative to the Volt app root path.
     */
    const std::string& GetRelativeAppJsPath() const;

    /**
     * Update the application root path.
     * @param[in] aRoot New application root path.
     */
    void UpdateAppRootPath(const std::string aRoot);

    const std::vector<char *>& OriginalArgs();

    /**
     * Print configuration option/values.
     */
    void PrintValues() const;

  private:
    AppConfig();
    ~AppConfig();

    /**
     * Get the variable_value for the desired configuration option.
     * @param[in] aKey Configuration option name.
     * @param[out] aFound Pointer to a boolean variable to check if the option
     *                    was found or not.
     * @param[out] aSource Pointer to a pointer to a variables_map variable to
     *                     check the source of the configuration option
     *                     (if found).
     * @return variable_value object for the configuration option.
     */
    boost::program_options::variable_value
    GetVariableValue(const std::string aKey,
                     bool *aFound = NULL,
                     const boost::program_options::variables_map **aSource = NULL) const;

    /**
     * Utility function to traverse XML options and construct command line
     * arguments equivalents.
     * For example, <debuger><enable>true</enable><debugger> will be converted
     * to --debugger.enable true.
     * @param[in] aNodes List of XML nodes to traverse.
     * @param[out] aResult Constructed command line arguments.
     * @param[in] aKey Name of the configuration option for the current XML
     *                 node.
     */
    void Xml2CommandLineArgs(const xmlpp::Node::NodeList aNodes,
                             std::vector<std::string> &aResult,
                             const std::string aKey = "");

    void Json2CommandLineArgs(const Json::Value aRoot,
                              std::vector<std::string> &aResult,
                              const std::string aKey = "");

    /**
     * Update paths information used by Volt.
     */
    void UpdateVoltPaths();

    void SaveArgv(const int aArgc, char *aArgv[]);

  private:
    boost::program_options::options_description help_desc_;
    boost::program_options::options_description cmd_option_desc_;
    boost::program_options::options_description file_option_desc_;

    boost::program_options::variables_map cmd_options_;
    boost::program_options::variables_map conf_options_;
    boost::program_options::variables_map json_options_;
    boost::program_options::variables_map xml_options_;

    std::string volt_root_path_;
    std::string volt_config_path_;
    std::string volt_data_path_;
    std::string app_root_path_;
    std::string app_data_path_;
    std::string relative_app_js_;

    std::string prog_name_;
    std::vector<char *> orig_argv_;
};

#endif
