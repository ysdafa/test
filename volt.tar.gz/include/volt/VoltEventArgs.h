#pragma once

#include <stdint.h>
#include <memory>
#include <vector>

class AnyMap;
class AnyList;

class VoltEventArgsList;

/**
 * This is a key-value container supporting various types of data types for
 * the mapped values.
 */
class VoltEventArgsMap
{
  public:
    VoltEventArgsMap();
    VoltEventArgsMap(const VoltEventArgsMap &aSrc);
    virtual ~VoltEventArgsMap();

    VoltEventArgsMap& operator=(const VoltEventArgsMap &aRhs);

    /**
     * Insert a new mapping to a string value.
     *
     * @param[in] aKey Key.
     * @param[in] aVal String value.
     *
     * @return true on success, false otherwise.
     */
    bool InsertString(const std::string &aKey, const std::string &aVal);

    /**
     * Get a string value for the supplied key.
     *
     * @param[in] aKey Key.
     * @param[out] aVal String value.
     *
     * @return true on success, false otherwise.
     */
    bool GetString(const std::string &aKey, std::string &aVal) const;

    /**
     * Insert a new mapping to a byte array.
     * A copy of the supplied byte array will be made.  Caller is free to
     * modify/delete the array after this function returns.
     *
     * @param[in] aKey Key.
     * @param[in] aVal Byte array.
     * @param[in] aSize Size of the byte array.
     *
     * @return true on success, false otherwise.
     */
    bool InsertByteArray(const std::string &aKey,
                         const uint8_t *aVal, const size_t aSize);

    /**
     * Get a byte array value for the supplied key.
     *
     * @param[in] aKey Key.
     * @param[out] aVal Byte array value.  This is the buffer maintained in
     *                  the container and should not be modified/deleted by
     *                  the caller.
     * @param[out] aSize Size of the byte array.
     *
     * @return true on success, false otherwise.
     */
    bool GetByteArray(const std::string &aKey,
                      const uint8_t * &aVal, size_t &aSize) const;

    /**
     * Insert a new mapping to another VoltEventArgsMap object.
     *
     * @param[in] aKey Key.
     * @param[in] aVal VoltEventArgsMap object.
     *
     * @return true on success, false otherwise.
     */
    bool InsertMap(const std::string &aKey, const VoltEventArgsMap &aVal);

    /**
     * Get a VoltEventArgsMap value for the supplied key.
     *
     * @param[in] aKey Key.
     * @param[out] aVal VoltEventArgsMap value.
     *
     * @return true on success, false otherwise.
     */
    bool GetMap(const std::string &aKey, VoltEventArgsMap &aVal) const;

    /**
     * Insert a new mapping to a VoltEventArgsList object.
     *
     * @param[in] aKey Key.
     * @param[in] aVal VoltEventArgsList object.
     *
     * @return true on success, false otherwise.
     */
    bool InsertList(const std::string &aKey, const VoltEventArgsList &aVal);

    /**
     * Get a VoltEventArgsList value for the supplied key.
     *
     * @param[in] aKey Key.
     * @param[out] aVal VoltEventArgsList value.
     *
     * @return true on success, false otherwise.
     */
    bool GetList(const std::string &aKey, VoltEventArgsList &aVal) const;

    /**
     * Checks if this VoltEventArgsMap contains a value with the given key.
     *
     * @param[in] aKey Key.
     *
     * @return true if the key is found, false otherwise.
     */
    bool Has(const std::string &aKey) const;

    /**
     * Get the number of mappings store in this VoltEventArgsMap.
     *
     * @return Number of mappings.
     */
    size_t Size() const;

    /**
     * Check if this VoltEventArgsMap is empty.
     *
     * @return true if empty, false otherwise.
     */
    bool Empty() const;

    /**
     * Get the keys store in this VoltEventArgsMap.
     *
     * @param[out] aKeys Vector where the keys are stored.
     *
     * @return Reference to aKeys.
     */
    std::vector<std::string>& GetKeys(std::vector<std::string> &aKeys) const;

  private:
    std::unique_ptr<AnyMap> map_;
};

/**
 * This is a sequence container supporting various types of data types for
 * the stored values.
 */
class VoltEventArgsList
{
  public:
    VoltEventArgsList();
    VoltEventArgsList(const VoltEventArgsList &aSrc);
    virtual ~VoltEventArgsList();

    VoltEventArgsList& operator=(const VoltEventArgsList &aRhs);

    /**
     * Add a string value.
     *
     * @param[in] aVal String value.
     *
     * @return true on success, false otherwise.
     */
    bool AddString(const std::string &aVal);

    /**
     * Get a string value at the given index.
     *
     * @param[in] aIndex Index.
     * @param[out] aVal String value.
     *
     * @return true on success, false otherwise.
     */
    bool GetString(const size_t aIndex, std::string &aVal) const;

    /**
     * Add a new mapping to a byte array.
     * A copy of the supplied byte array will be made.  Caller is free to
     * modify/delete the array after this function returns.
     *
     * @param[in] aVal Byte array.
     * @param[in] aSize Size of the byte array.
     *
     * @return true on success, false otherwise.
     */
    bool AddByteArray(const uint8_t *aVal, const size_t aSize);

    /**
     * Get a byte array value at the given index.
     *
     * @param[in] aIndex Index.
     * @param[out] aVal Byte array value.  This is the buffer maintained in
     *                  the container and should not be modified/deleted by
     *                  the caller.
     * @param[out] aSize Size of the byte array.
     *
     * @return true on success, false otherwise.
     */
    bool GetByteArray(const size_t aIndex,
                      const uint8_t * &aVal, size_t &aSize) const;

    /**
     * Add a VoltEventArgsMap object.
     *
     * @param[in] aVal VoltEventArgsMap object.
     *
     * @return true on success, false otherwise.
     */
    bool AddMap(const VoltEventArgsMap &aVal);

    /**
     * Get a VoltEventArgsMap value at the given index.
     *
     * @param[in] aIndex Index.
     * @param[out] aVal VoltEventArgsMap value.
     *
     * @return true on success, false otherwise.
     */
    bool GetMap(const size_t aIndex, VoltEventArgsMap &aVal) const;

    /**
     * Add a VoltEventArgsList object.
     *
     * @param[in] aVal VoltEventArgsList object.
     *
     * @return true on success, false otherwise.
     */
    bool AddList(const VoltEventArgsList &aVal);

    /**
     * Get a VoltEventArgsList value at the given index.
     *
     * @param[in] aIndex Index.
     * @param[out] aVal VoltEventArgsList value.
     *
     * @return true on success, false otherwise.
     */
    bool GetList(const size_t aIndex, VoltEventArgsList &aVal) const;

    /**
     * Get the number of mappings store in this VoltEventArgsList.
     *
     * @return Number of mappings.
     */
    size_t Size() const;

    /**
     * Check if this VoltEventArgsList is empty.
     *
     * @return true if empty, false otherwise.
     */
    bool Empty() const;

  private:
    std::unique_ptr<AnyList> list_;
};
