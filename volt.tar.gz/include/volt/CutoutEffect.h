/*
 * CutoutEffect.h
 *
 *  Created on: July 3, 2013
 *      Author: jim dinunzio
 */

#ifndef CUTOUTEFFECT_H
#define CUTOUTEFFECT_H

#include <clutter/clutter.h>

#ifndef STAND_ALONE
#include "Widget.h"
#endif

#include "VoltActor.h"

GType cutout_effect_get_type (void);


#define TYPE_CUTOUT_EFFECT (cutout_effect_get_type ())
#define CUTOUT_EFFECT(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), \
                                                           TYPE_CUTOUT_EFFECT, \
                                                           CCutoutEffect))
#define IS_CUTOUT_EFFECT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), \
                                                                      TYPE_CUTOUT_EFFECT))
#define CUTOUT_EFFECT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), \
                                                                   TYPE_CUTOUT_EFFECT, \
                                                                   CCutoutEffectClass))
#define IS_CUTOUT_EFFECT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), \
                                                                   TYPE_CUTOUT_EFFECT))
#define CUTOUT_EFFECT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), \
                                                                     TYPE_CUTOUT_EFFECT, \
                                                                     CCutoutEffectClass))

typedef struct _CCutoutEffect        CCutoutEffect;
typedef struct _CCutoutEffectClass   CCutoutEffectClass;

void cutout_effect_set_cutout_actor(CCutoutEffect* effect, VoltActor* cutout_actor);
void cutout_effect_get_cutout_actor(CCutoutEffect* effect, VoltActor* cutout_actor);

ClutterEffect *cutout_effect_new ();

#ifndef STAND_ALONE
class CutoutEffect : public Effect
{

  public:
    CutoutEffect(VoltActor* cutoutActor);
    virtual ~CutoutEffect();
};
#endif
#endif /* CUTOUTEFFECT_H */
