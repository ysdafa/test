/*
* VideoWidget.h
*
*  Created on: June 10, 2014
*      Author: jim.dinunzio
*/

#pragma once

#include "Widget.h"
#include "logger.h"

class SefClient;

namespace volt
{
namespace graphics
{
class VideoWidget : public Widget
{
  public:
    static volt::util::Logger LOGGER;

    VideoWidget(float xIn, float yIn, float widthIn, float heightIn, Widget* aParent,
                SefClient* playerSefIn);
    virtual ~VideoWidget();

    void setPlayerSef(SefClient* sefClient);
    SefClient* getPlayerSef() const;

    void SetDisplayArea(float x, float y, float width, float height);

  protected:

    static void on_allocation_changed (ClutterActor           *actor,
                                       const ClutterActorBox  *allocation,
                                       ClutterAllocationFlags  flags,
                                       gpointer                user_data);

    static void on_transform_changed (GObject* object,
                                      GParamSpec* paramSpec,
                                      gpointer user_data);


    static gboolean UpdateSefPlayer(VideoWidget* vw);

    static void onExecutedCB(std::string result);

    virtual const std::string& getWidgetTypeString() const;

    guint repaint_func_id;
    bool needUpdateSefPlayer;
    SefClient* playerSef;
};
};
};
