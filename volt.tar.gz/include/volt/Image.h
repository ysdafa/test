/*
 * Image.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_IMAGE_H
#define SAMSUNG_KINGSCANYON_IMAGE_H

#include <gdk-pixbuf/gdk-pixbuf-animation.h>
#include <clutter/clutter.h>

#include <boost/enable_shared_from_this.hpp>
#include <functional>
#include <vector>
#include "ScriptTypes.h"
#include "ImageWidget.h"
#include "logger.h"
#include "macros.h"

namespace volt
{
namespace graphics
{
typedef std::function<void(void)> ImageGifCompleteCallback;
typedef std::function<void()> ImageDestructionCallback;

class Image : public boost::enable_shared_from_this<Image>
{
  public:
    static std::string LOGGER_NAME;

    /* The callback to be registered by the ImageWidgets wishing to be
     * notified when this image finishes loading. */
    typedef std::function<void (Image *)> OnLoadCallback;

  public:
    Image();
    virtual ~Image();

    typedef boost::shared_ptr<Image> SharedPtr;

    SharedPtr getSharedPtr()
    {
      return shared_from_this();
    }

    void set_uri(const std::string &aUri);

    void set_noAtlas(bool noAtlas);
    void set_noSlicing(bool noSlicing);
    void set_noAutoMipmap(bool noAutoMipmap);

    bool RegisterOnLoadCallback(const ImageWidget *aWidget,
                                OnLoadCallback aCallback);

    bool UnregisterOnLoadCallback(const ImageWidget *aWidget);

    inline ImageGifCompleteCallback getOnGifComplete() const
    {
      return onGifComplete;
    }
    inline void setOnGifComplete(const ImageGifCompleteCallback& gifCompleteCallback)
    {
      onGifComplete= gifCompleteCallback;
    }

    // Gif Animation interface
    void CancelGifAnimation();
    void PauseGifAnimation();
    void ResumeGifAnimation();
    void RewindGifAnimation();

    /**
     * Adds an actor to the array of actors using this Image.
     *
     * @author jim (3/14/2014)
     *
     * @param actor actor to add that uses this Image
     */
    void AddActor(ClutterActor* actor);
    /**
     * Removes an actor from the array of actors using this Image
     *
     * @author jim (3/14/2014)
     *
     * @param actor actor to remove that no longer uses this Image
     */
    void RemoveActor(ClutterActor* actor);

    // WARNING no further operation can be done after this
    // since its highly possible that this object will be destroyed
    void HandleDestroy();

    void registerDestructionEvent(ImageDestructionCallback callback);

  private:
    /** List of functions to call when object is destroyed */
    std::vector<std::function<void()>> destructionCallbacks;

    void OnImageLoaded(VoltImage *aImage, bool aSuccess);

  private:

    typedef std::vector<ClutterActor*> ClutterActorVector;
    typedef std::vector<ClutterActor*>::iterator ClutterActorVectorIter;

    /** Callback invoked when Gif animation is complete. */
    ImageGifCompleteCallback onGifComplete;

    /**
     * This is the class for handling image animations like animated GIFs
     *
     * @author jim (3/13/2014)
     */
    class Animation
    {
      public:
        Animation(Image* imageIn, GdkPixbufAnimation *pixbufAnim) : base_time_(0),
          elapsed_time_(0), last_frame_time_(0), image_(imageIn), iter_(NULL),
          sched_redraw_func_id_(0), repaint_func_id_(0) { }

        ~Animation();
        void Play();
        void Stop();
        void Rewind();
        bool IsPlaying()
        {
          return repaint_func_id_ != 0;
        }

      private:
        PROPERTY(gint64, base_time);
        PROPERTY(gint64, elapsed_time);
        PROPERTY(gint64, last_frame_time);
        PROPERTY_PTR_RO(Image, image);
        PROPERTY_PTR(GdkPixbufAnimationIter, iter);
        PROPERTY(guint, sched_redraw_func_id);
        PROPERTY(guint, repaint_func_id);
    };

    static gboolean GifComplete(Animation* ia);
    static gboolean RenderFrame(Animation *ia);
    static gboolean ScheduleRedraw(Animation* ia);

    Animation* anim;

    volt::util::Logger logger_;

    std::map<const ImageWidget*, OnLoadCallback> on_load_callbacks_;

    /* Not really read-only, but with our custom setter. */
    PROPERTY_CONST_REF_RO(std::string, uri);
    PROPERTY(bool, async);

    PROPERTY_RO(CoglTextureFlags, textureFlags);
    PROPERTY_RO(VoltImage *, image);
    PROPERTY_CONST_REF(Bridge::ScriptFunction, success_callback);
    PROPERTY_CONST_REF(Bridge::ScriptFunction, error_callback);
    /**
     * List of actors using this Image
     */
    PROPERTY_REF_RO(ClutterActorVector, actors);
};
};
};
#endif /* SAMSUNG_KINGSCANYON_RESOURCE_REQUEST_H */
