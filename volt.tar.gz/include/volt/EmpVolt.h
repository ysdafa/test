#ifndef VOLT_EMP_VOLT_H
#define VOLT_EMP_VOLT_H

#include "EmpApp.h"
#include "EmpEngine.h"

/* The EMP_VOLT_NAME is used in cmake too, be careful when changing.
 * You must run cmake when changing them. */
#define EMP_VOLT_NAME "Volt"

namespace sef
{

class EmpVolt : public CEmpAppBase
{
  public:
    EmpVolt();
    virtual ~EmpVolt();

  protected:
    virtual CEmpEngineBase* CreateEmpEngine();
    virtual bool CheckVersion(const std::string aVersion);
};

} /* namespace sef */

#endif /* VOLT_EMP_VOLT_H */
