/*
 * ResourceManager.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_RESOURCE_MANAGER_H
#define SAMSUNG_KINGSCANYON_RESOURCE_MANAGER_H

#include <curl/curl.h>
#include <thread>
#include <memory>
#include <queue>
#include <functional>
#include <map>
#include <event2/event.h>

#include "ResourceRequest.h"
#include "NetworkIORequest.h"
#include "macros.h"
#include "logger.h"



namespace Resource
{

/**
 * This class handles fetching/caching resources requested from JS and other
 * components.
 */
class ResourceManager
{
  public:
    static std::string LOGGER_NAME;

    enum MessageType
    {
      ProcessRequest = 0,
      CancelRequest,
      StopThread
    };

    struct Message
    {
      Message()
        : type(CancelRequest),
          handle(0),
          payload(nullptr)
      {
      }

      virtual ~Message()
      {
        if(type == ProcessRequest and payload != nullptr)
        {
          IORequest::SharedPtr *ptr = (IORequest::SharedPtr *)payload;
          payload = nullptr;
          delete ptr;
        }
      }

      MessageType type; // type of message
      unsigned int handle;  // id used to uniquely identify the request
      void *payload; // the actual request;
    };
  public:
    /**
     * Get a singleton instance of ResourceManager.
     * @return ResourceManager singleton.
     */
    static ResourceManager& Instance();

    /**
     * Start a worker thread to handle async events.
     */
    void StartWorkerThread();
    /**
     * Request to stop the worker thread.
     * This may not stop the thread immediately.  JoinWorkerThread should
     * be called to make sure that the thread has joined.
     */
    void StopWorkerThread();
    /**
     * Join the worker thread.
     * This is a blocking call.
     */
    void JoinWorkerThread();

    /**
     * Utility function to create a new IORequest::SharedPtr from URI.
     * Note: this returns a synchronous request object.
     *
     * @param[in] aUri URI of a resource.
     * @return Newly created IORequest::SharedPtr.
     */
    static IORequest::SharedPtr CreateRequest(const std::string &aUri);

    /**
     * Utility function to create a new IORequest::SharedPtr from URI.
     * Note: this returns an asynchronous request object.
     *
     * @param[in] aUri URI of a resource.
     * @param[in] aCallback Callback to fire when IO completes.
     * @return Newly created IORequest::SharedPtr.
     */
    static IORequest::SharedPtr CreateRequest(const std::string &aUri,
        IORequest::OnCompleteCallback aCallback);

    /**
     * Utility function to create a new IORequest::SharedPtr from
     * ResourceRequest.
     * The created request would be sufficient to initiate IO handling.
     * Note: this returns a synchronous request object.
     *
     * @param[in] aRequest Request for resource made by the JS.
     * @param[in] aCallback Callback to fire when IO completes.
     * @return Newly created IORequest::SharedPtr.
     */
    static IORequest::SharedPtr CreateRequest(const ResourceRequest &aRequest);

    /**
     * Utility function to create a new IORequest::SharedPtr from
     * ResourceRequest.
     * The created request would be sufficient to initiate IO handling.
     * Note: this returns an asynchronous request object.
     *
     * @param[in] aRequest Request for resource made by the JS.
     * @param[in] aCallback Callback to fire when IO completes.
     * @return Newly created IORequest::SharedPtr.
     */
    static IORequest::SharedPtr CreateRequest(const ResourceRequest &aRequest,
        IORequest::OnCompleteCallback aCallback);

    /**
     * Process a new IO request.
     *
     * If aRequest is a synchronous/blocking request, then this function
     * would block until the IO is complete.  aRequest will be updated
     * with the result of the IO.
     *
     * If aRequest is an asynchronous/non-blocking request, then this function
     * would pass the request to the worker thread.  aRequest would be reset
     * and thus the caller would not have access to the request after this
     * call.  When the transaction is completed, the callback registered with
     * the aRequest would be fired.
     *
     * @param[inout] aRequest Request to be processed.
     *                        This would be updated with the result of the
     *                        transaction for synchronous requests.
     * @param[out]   requestId Returns unique handle for async request
     *                         0 if sync request
     */
    bool Process(IORequest::SharedPtr &aRequest, unsigned int *requestHandle = nullptr);

    /**
     * Cancel an existing Async IO request.
     *
     * If aRequest is a Asynchronous request, then this function
     * would attempt to cancel.
     *
     * If the request is an asynchronous/non-blocking, then this function
     * would pass the request to the worker thread to cancel the CURL transaction
     *
     * @param[in] requestHandle   Id that helps to uniquely identify the original request
     */

    void Cancel(unsigned int requestHandle);

    /**
     * Worker thread entry point.
     * This internally uses curl multi handle with libevent to handle
     * asynchronous transactions.
     */
    void operator()();

  private:
    ResourceManager();
    virtual ~ResourceManager();

    /**
     * Check and remove completed CURL handles from internal data structures.
     */
    void RemoveCompletedHandles();

    /**
     * Convert CURLMcode to string.
     * @param[in] aCode CURLMcode.
     * @return String equivalent of the given CURLMcode.
     */
    static const std::string& McodeToString(CURLMcode aCode);

    /**
     * Callback registered with curl for socket updates.
     * @param[in] aEasyHandle Handle associated with this socket.
     * @param[in] aSocket Socket requiring updates.
     * @param[in] aAction Required update actions.
     * @param[in] aSelf Pointer to ResourceManager object.
     * @param[in] aEvent Associated event for this socket.
     * @return 0.
     */
    static int SocketCallback(CURL *aEasyHandle, curl_socket_t aSocket,
                              int aAction, void *aSelf, void *aEvent);

    /**
     * Callback registered with curl for timer updates.
     * @param[in] aEasyHandle Handle associated with this socket.
     * @param[in] aTimeoutMs New timeout in milli seconds.
     * @param[in] aSelf Pointer to ResourceManager object.
     * @return 0.
     */
    static int MultiTimerCallback(CURLM *aMultiHandle, long aTimeoutMs,
                                  ResourceManager *aSelf);

    /**
     * Callback registered with libevent for sockets handled by curl.
     * @param[in] aFd The file descriptor with events.
     * @param[in] aKind Event type bitmask.
     * @param[in] aSelf Pointer to ResourceManager object.
     */
    static void EventCallback(int aFd, short aKind, void *aSelf);

    /**
     * Callback registered with libevent for timer events.
     * @param[in] aFd The file descriptor with events.
     * @param[in] aKind Event type bitmask.
     * @param[in] aSelf Pointer to ResourceManager object.
     */
    static void TimerCallback(int aFd, short aKind, void *aSelf);

    /**
     * Callback registered with libevent for pipe events.
     * This is where V8 request come in to talk to Resource
     * Manager Thread
     * @param[in] aFd The file descriptor with events.
     * @param[in] aKind Event type bitmask.
     * @param[in] aSelf Pointer to ResourceManager object.
     */
    static void PipeCallback(int aFd, short aEvent, void *aSelf);

    /**
     * Utility function to print error assocaited with an errno.
     * @param[in] aErrno Error number.
     */
    static void PrintErrno(const int aErrno);

    // functions to handle messages based on message type by the worker thread
    void HandleProcessRequest(IORequest::SharedPtr *request_ptr);

    void HandleCancelRequest(unsigned int requestHandle);

    void HandleStopThread();

    // send message to worker thread
    inline void SendEventMessage(ResourceManager::Message *outgoingMessage);
  private:
    volt::util::Logger logger_; /**< Logger. */

    unsigned int req_id_; /**< ID for async requests. */

    std::thread thread_; /**< Handle for worker thread. */

    int pipe_[2]; /**< Pipe to communicate with worker thread. */

    CURLM *multi_handle_; /**< Handle for async transactions. */
    int num_active_; /**< Number of active handles. */

    struct event_base *ev_base_; /**< libevent base. */
    struct event *timer_event_; /**< Timer event. */
    struct event *pipe_event_; /**< Pipe event. */

    /** Lookup table mapping CURL* => NetworkIORequest::SharedPtr. */
    typedef std::map<CURL *, NetworkIORequest::SharedPtr> RequestMap;
    RequestMap requests_; /**< Map of async requests. */
    /** Lookup table mapping handle id* => NetworkIORequest::SharedPtr. */
    typedef std::map<unsigned int, NetworkIORequest::SharedPtr> HandleMap;
    HandleMap handles_; /**< Map of async requests. */

    /** Lookup table mapping handle id* => Event. */
    typedef std::map<CURL *, struct event*> EventMap;
    EventMap events_; /**< Map of curl events. */
};

} /* namespace Resource */

#endif /* SAMSUNG_KINGSCANYON_RESOURCE_MANAGER_H */
