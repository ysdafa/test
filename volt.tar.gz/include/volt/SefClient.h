/*
 * SefClient.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_SEFCLIENT_H_
#define SAMSUNG_KINGSCANYON_SEFCLIENT_H_

#include <string>
#include <vector>
#include <thread>
#include <functional>
#include <map>
#include <glib.h>

#include "logger.h"

#ifdef BUILD_FOR_TV
#include "CSefPluginWrapper.h"
#endif

/** Class to call API's of other plugin's via SEF. */
#ifdef BUILD_FOR_TV
class SefClient : public sef::CSefPluginWrapper
#else
class SefClient
#endif
{
  public:
    static volt::util::Logger LOGGER;

  public:

    typedef std::function<void(std::string)> OnExecuteCallbackType;
    /**
     * Data to be passed to HandleExecuteResponse.
     * The data contained in this struct is the response from the execute function
     * used for asynchronous run of execute.
     */
    typedef struct
    {
      SefClient* client;
      std::string response;
    } ExecuteResponse;

    /**
     * Data to be passed to HandleOpenResponse
     * The data contained in this struct is the response from the open function
     * used for asynchronous run of open
     */
    typedef struct
    {
      SefClient* client;
      bool response;
    } OpenResponse;

    /** Native Callback functions for SefClient
     */
    struct CallbackFuncs
    {
      OnExecuteCallbackType onExecutedCB;
    };

    /** Map holding the Native callback functions for each SefClient object */
    typedef std::map<SefClient*, CallbackFuncs> CALLBACK_MAP;

    SefClient();

    virtual ~SefClient();

    /**
     * Open the EMP with the given name/version/credential.
     * @param[in] aName Name of the EMP to open.
     * @param[in] aVersion Version of the EMP.
     * @param[in] aCredential Credential to be used.
     * @return true on success, false otherwise.
     */
    bool Open(std::string aName, std::string aVersion, std::string aCredential);

    /**
     * Close the EMP associated with this client object.
     * @return true on success, false otherwise.
     */
    bool Close();

    /**
     * Execute an EMP command.
     * @param[in] aCmd Command name.
     * @param[in] aArgs List of arguments.
     * @return Return value of the executed command.
     *         The very first character is a type classifier
     *         (I == number, A == string)
     */
    std::string Execute(std::string aCmd, std::vector<std::string> &aArgs);

    void ExecuteAsync(std::string aCmd, std::vector<std::string> &aArgs,
                      OnExecuteCallbackType callback);

    virtual bool OnEvent(int aEventType, std::string aParam1, std::string aParam2);

    void setOpenThread(std::thread&& thread)
    {
      openThread.swap(thread);
    }
    void setExeThread(std::thread&& thread)
    {
      exeThread.swap(thread);
    }

    std::thread& getOpenThread()
    {
      return openThread;
    }
    std::thread& getExeThread()
    {
      return exeThread;
    }

    const std::string& getName() const { return name; }

    void setName(const std::string& nameIn) { name = nameIn; }

    const std::string& getLastCmd() const { return lastCmd; }

    void setLastCmd(const std::string& lastCmdIn) { lastCmd = lastCmdIn; }

    static gboolean HandleExecuteResponse(gpointer aResponseData);
    
protected:
    std::thread openThread;
    std::thread exeThread;
    std::string name;
    std::string lastCmd;

    static CALLBACK_MAP callbackMap;
};

#endif /* SAMSUNG_KINGSCANYON_SEFCLIENT_H_ */
