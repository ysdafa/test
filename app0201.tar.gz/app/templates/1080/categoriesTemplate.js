var CategoriesTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        id: 'categories-main-container',
        x: 0,
        y: 0,
        width: 1920,
        height: 864,
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            {
                id: 'categories-content-container',
                type: 'widget',
                x: 0,
                y: 0,
                width: 1920,
                height: 864,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'categories-no-content-container',
                type: 'text',
                x: 90,
                y: 386,
                height: 55,
                width: 1920 - 180,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: '35px'
            }
        ]
    },

    categoriesInfo_others: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 480,
        height: 432,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'image',
                x: 0,
                y: 0,
                width: 480,
                height: 432,
                src: '{{ imageUrl }}'
            }, {
                type: 'text',
                x: 30,
                y: 293,
                width: 420,
                height: 60,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000'),
                opacity: 140,
                text: '{{ title }}',
                font: '35px'
            }
        ]
    },

    categoriesInfo_all: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 480,
        height: 432,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'image',
                x: 0,
                y: 0,
                width: 480,
                height: 432,
                src: '{{ imageUrl }}'
            }, {
                type: 'text',
                x: 30,
                y: 156,
                width: 420,
                height: 120,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000'),
                opacity: 128,
                text: 'All',
                font: '90px'
            }
        ]
    },

    gridList: {
        x: 0,
        y: 0,
        width: 1920,
        height: 864,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        itemWidth: 480,
        itemHeight: 432
    }
};

exports = CategoriesTemplate;