var OptionMenuTemplate = {
    optionMenuBG: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 1920,
        height: 1080,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 153
        },
        parent: scene,
        children: [{
            custom: {
                className: 'option-menu-icon-focused'
            },
            type: 'image',
            x: 1854,
            y: 55,
            width: 33,
            height: 33,
            opacity: 153,
            src: Volt.getRemoteUrl('images/1080/common/comn_icon_topmenu_option.png')
        }]
    },

    optionMenu: {
        type: 'OptionMenu',
        x: Volt.width * (1 - 0.010417 - 0.186458) - 5,
        y: Volt.height * 0.111111,
        width: Volt.width * 0.186458 + 5,
        text: [Volt.i18n.t('TV_SID_DELETE_MY_APPS'), Volt.i18n.t('TV_SID_LOCK_UNLOCK_MY_APPS'), Volt.i18n.t('COM_TV_SID_UPDATE_APPS_KR_SINGULAR'), Volt.i18n.t('UID_SORT_BY')],
        subText: [
            {
                index: 3,
                text: [Volt.i18n.t('TV_SID_BY_DATE'), Volt.i18n.t('SID_MOST_USED'), Volt.i18n.t('COM_SID_TITLE_A_Z'), Volt.i18n.t('COM_SID_TITLE_Z_A')],
                width: Volt.width * 0.186458 + 5,
                loop: false
            }
        ],
        custom: {
            focusable: true
        },
        loop: true,
        selectedIdx: 0,
        selectedSubIdx: [0, 0],
        parent: scene
    }
};

exports = OptionMenuTemplate;