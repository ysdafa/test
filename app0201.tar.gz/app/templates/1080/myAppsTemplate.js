var MyAppsTemplate = {

    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'myapps-content-container',
                type: 'widget',
                x: 0,
                y: 0,
                width: Volt.width,
                height: Volt.height * 0.8,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'myapps-no-content',
                type: 'text',
                x: Volt.width * 0.046875,
                y: Volt.height * 0.285185,
                width: Volt.width * 0.90625,
                height: Volt.height * 0.050926,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: (Volt.APPS720P) ? '23px' : '35px'
            },
            {
                id: 'myapps-content-index',
                type: 'text',
                x: Volt.width * 0.9375,
                y: -Volt.height * 0.055556,
                width: Volt.width * 0.052083,
                height: Volt.height * 0.050926,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 40),
                text: '',
                font: (Volt.APPS720P) ? '17px' : '26px'
            }
        ]
    },

    gridList: {
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        itemWidth: Volt.width * 0.132812,
        itemHeight: Volt.height * 0.266666
    },

    item: {

        // HALO_ITEM_ALL_SAME:                 0,
        // HALO_ITEM_NOT_ALL_SAME:             1,
        // THUMB_STYLE_BLANK:                  0x00,
        // THUMB_STYLE_IMAGE:                  0x01,
        // THUMB_STYLE_ICON:                   0x02,
        // THUMB_STYLE_TEXT:                   0x04,
        // THUMB_STYLE_PROGRESSBAR:            0x08,
        // THUMB_STYLE_CHECKBOX:               0x10,
        // THUMB_STYLE_INFO:                   0x20

        visibleStyles: (0x01 | // CommonDefines.Const.THUMB_STYLE_IMAGE
            0x20), // CommonDefines.Const.THUMB_STYLE_INFO
        image: {
            x: 0,
            y: 0,
            width: Volt.width * 0.132812,
            height: Volt.height * 0.196296,
            src: '',
            async: true
        },

        progressBar: {
            x: Volt.width * 0.009375,
            y: Volt.height * 0.196296,
            width: Volt.width * 0.114062,
            height: 2,
            backgroundColor: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100),
            normalThumbSrc: '',
            focusThumbSrc: '',
            thumbWidth: Volt.width * 0.004167,
            thumbHeight: Volt.height * 0.009259,
            slidable: false
        },
        information: {
            x: 0,
            y: Volt.height * 0.196296,
            width: Volt.width * 0.1328125,
            height: Volt.height * 0.07037,

            colorPickingRange: {
                l: 0,
                r: 100,
                t: 80,
                b: 100
            }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
            icon1: {
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                src: '',
                async: true
            },
            icon2: {
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                src: '',
                async: true
            },
            icon3: {
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                src: '',
                async: true
            },
            icon4: {
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                src: '',
                async: true
            },

            text1: {
                x: Volt.width * 0.010417,
                y: 0,
                width: Volt.width * 0.111979,
                height: Volt.height * 0.07037,
                font: (Volt.APPS720P) ? 'SamsungSVD_Light 17px' : 'SamsungSVD_Light 26px',
                singleLineMode: true,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },
            }
        },
        checkBox: {
            x: Volt.width * 0.030208,
            y: Volt.height * 0.069444,
            width: Volt.width * 0.071875,
            height: Volt.height * 0.127778,
            uncheckSrc: Volt.getRemoteUrl('images/1080/common/check/check_ms_tb.png'),
            checkedSrc: Volt.getRemoteUrl('images/1080/common/check/check_ms_tb.png'),
        },
    },

    lockIcon_w: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        width: Volt.width * 0.008333,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_lock_white.png'),
        async: true
    },

    lockIcon_b: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        width: Volt.width * 0.008333,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_lock_black.png'),
        async: true
    },

    usbIcon_w: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        width: Volt.width * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_usb_white.png'),
        async: true
    },

    usbIcon_b: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        width: Volt.width * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_usb_black.png'),
        async: true
    },

    updateIcon: {
        type: 'image',
        x: Volt.width * 0.105729,
        y: Volt.height * 0.02037,
        width: Volt.width * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon_update_sequence_01.png'),
        async: true
    },

    updatedIcon: {
        type: 'image',
        x: Volt.width * 0.105729,
        y: Volt.height * 0.02037,
        width: Volt.width * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon_update_sequence_06.png'),
        async: true
    },

    editModeContainer: {
        type: 'WinsetBackground',
        id: 'edit-mode-container',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.066667,
        style: '{{highconstract}}',
        bgColor: Volt.hexToRgb('#0f1826'),
        bgHighContrastColor: Volt.hexToRgb('#000000', 100),
        children: [
            {
                type: 'text',
                id: 'select-title',
                x: Volt.width * 0.020833,
                y: 0,
                /*width : Volt.width*0.15625,*/ height: Volt.height * 0.066667,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                font: (Volt.APPS720P) ? '18px' : '28px',
                textColor: Volt.hexToRgb('#ffffff'),
                text: Volt.i18n.t('COM_SID_MIX_SELECTED_ITEMS_KR_SPACE').replace('<<A>>', ""), //'Selected items : ',
                custom: {
                    className: 'edit-mode-selected-text'
                }
            },
            {
                type: 'text',
                id: 'select-count',
                x: 0,
                y: 0,
                width: Volt.width * 0.052083,
                height: Volt.height * 0.066667,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                font: (Volt.APPS720P) ? '21px' : '31px',
                textColor: Volt.hexToRgb('#24b6f4'),
                text: '0',
                custom: {
                    className: 'edit-mode-selected-count'
                }
            },
            {
                custom: {
                    'focusable': true
                },
                id: 'edit-select-button',
                type: 'widget',
                x: Volt.width * 0.53125,
                y: 0,
                width: Volt.width * 0.15625,
                height: Volt.height * 0.066667,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                custom: {
                    'focusable': true
                },
                id: 'edit-exceute-button',
                type: 'widget',
                x: Volt.width * 0.6875,
                y: 0,
                width: Volt.width * 0.15625,
                height: Volt.height * 0.066667,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                custom: {
                    'focusable': true
                },
                id: 'edit-cancel-button',
                type: 'widget',
                x: Volt.width * 0.84375,
                y: 0,
                width: Volt.width * 0.15625,
                height: Volt.height * 0.066667,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            },
        ]
    },
    generalBtn: {
        type: 'Button',
        //style : '{{style}}',
        //buttonType : '{{buttonType}}',
        x: (Volt.APPS720P) ? -3 : -4,
        y: (Volt.APPS720P) ? -3 : -4,
        width: Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8),
        height: Volt.height * 0.066667 + ((Volt.APPS720P) ? 6 : 8),
        children: [
            {
                type: 'widget',
                x: (Volt.APPS720P) ? 3 : 4,
                y: (Volt.APPS720P) ? 3 : 4,
                width: 1,
                height: Volt.height * 0.066667,
                color: {
                    r: 255,
                    g: 255,
                    b: 255,
                    a: 51
                },
                custom: {
                    className: 'multi_seletion_buttons_bar'
                }
            },
        ]

    },

    itemDim: {
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width * 0.102083,
        height: Volt.height * 0.266667,
        color: Volt.hexToRgb('#0f1826'),
        opacity: Volt.getPercentage(80)
    },

    headerCover: {
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.133333,
        color: Volt.hexToRgb('#000000'),
        opacity: Volt.getPercentage(20),
        parent: scene
    }
};

exports = MyAppsTemplate;