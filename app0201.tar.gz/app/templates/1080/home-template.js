var HomeTemplate = {
    header: {
        type: 'WinsetBackground',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.133333,
        style: '{{highconstract}}',
        bgColor: Volt.hexToRgb('#0f1826'),
        bgHighContrastColor: Volt.hexToRgb('#000000', 100),
        children: [
            {
                id: 'main-header-title',
                type: 'text',
                x: Volt.width * 0.018750,
                y: 0,
                width: Volt.width * 0.378125,
                height: Volt.height * 0.133333,
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 80),
                text: Volt.i18n.t('TV_SID_NON_APPS_PANEL'),
                font: (Volt.APPS720P) ? '33px' : '50px'
            },
            {
                id: 'main-header-develop-title',
                type: 'text',
                x: Volt.width * (0.018750 + 0.1) + 10,
                y: 0,
                width: Volt.width * 0.378125,
                height: Volt.height * 0.133333,
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ff0000', 80),
                text: '',
                font: (Volt.APPS720P) ? '33px' : '50px'
            }, {
                type: 'WinsetBackground',
                x: Volt.width * (1 - 0.052083 * 3),
                y: 0,
                width: Volt.width * 0.052083 * 3,
                height: Volt.height * 0.133333,
                id: 'header-container',
                style: '{{highconstract}}',
                bgColor: Volt.hexToRgb('#0f1826'),
                bgHighContrastColor: Volt.hexToRgb('#000000', 100),
                children: [
                    {
                        id: 'main-header-icon-search',
                        type: 'WinsetBackground',
                        x: Volt.width * 0.052083 + 1,
                        y: 0,
                        width: Volt.width * 0.052083 - 1,
                        height: Volt.height * 0.133333,
                        style: '{{highconstract}}',
                        bgColor: Volt.hexToRgb('#0f1826'),
                        bgHighContrastColor: Volt.hexToRgb('#000000', 100),
                        custom: {
                            'focusable': true
                        },
                    },
                    {
                        id: 'main-header-icon-option',
                        type: 'WinsetBackground',
                        x: Volt.width * 0.052083 * 2 + 1,
                        y: 0,
                        width: Volt.width * 0.052083 - 1,
                        height: Volt.height * 0.133333,
                        style: '{{highconstract}}',
                        bgColor: Volt.hexToRgb('#0f1826'),
                        bgHighContrastColor: Volt.hexToRgb('#000000', 100),
                        custom: {
                            'focusable': true
                        },
                    },
                    {
                        id: 'main-header-icon-close',
                        type: 'WinsetBackground',
                        x: Volt.width * 0.052083 * 2 + 1,
                        y: 0,
                        width: Volt.width * 0.052083 - 1,
                        height: Volt.height * 0.133333,
                        style: '{{highconstract}}',
                        bgColor: Volt.hexToRgb('#0f1826'),
                        bgHighContrastColor: Volt.hexToRgb('#000000', 100),
                        custom: {
                            'focusable': true
                        },
                    },
                    {
                        id: 'main-header-icon-search-border',
                        type: 'widget',
                        x: Volt.width * 0.052083,
                        y: 0,
                        width: 1,
                        height: Volt.height * 0.133333,
                        color: Volt.hexToRgb('#ffffff'),
                        opacity: 25.5
                    },
                    {
                        id: 'main-header-icon-option-border',
                        type: 'widget',
                        x: Volt.width * 0.052083 * 2,
                        y: 0,
                        width: 1,
                        height: Volt.height * 0.133333,
                        color: Volt.hexToRgb('#ffffff'),
                        opacity: 25.5
                    },
                    {
                        id: 'main-header-icon-close-border',
                        type: 'widget',
                        x: Volt.width * 0.052083 * 3,
                        y: 0,
                        width: 1,
                        height: Volt.height * 0.133333,
                        color: Volt.hexToRgb('#ffffff'),
                        opacity: 25.5
                    },
                ]
            }
        ]
    },
    iconBtn: {
        type: 'Button',
        id: '{{WinsetID}}',
        x: (Volt.APPS720P) ? -3 : -4,
        y: (Volt.APPS720P) ? -3 : -4,
        width: Volt.width * 0.052083 - 1 + ((Volt.APPS720P) ? 6 : 8),
        height: Volt.height * 0.133333 + ((Volt.APPS720P) ? 6 : 8),
    },

    dim: {
        id: 'dim',
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#000000'),
        opacity: Volt.getPercentage(80)
    },

    toolTip: {
        type: 'WinsetToolTip',
        x: '{{x}}',
        y: Volt.height * 0.133333,
        width: '{{w}}',
        height: Volt.height * 0.054630,
        style: '{{style}}',
        nResoultionStyle: '{{nResoultionStyle}}',
        text: '{{text}}',
        tailPostion: '{{tailPostion}}',
        parent: scene
    },
    optionMenu: {
        x: Volt.width * (1 - 0.186458 - 0.010417),
        y: Volt.height * 0.111111,
        width: Volt.width * 0.186458,
        id: "option",
        nResoultionStyle: (Volt.APPS720P) ? "0" : "1",
        parent: scene,
        subSelectIndex: 0,
        //bgColor:{ r: 15, g: 24, b: 38, a: 255 },
        showNumber: 4,
        //bTextScroll: true,		
        bKeyCommon: true,
        items: [{
            style: 12,
            text: Volt.i18n.t('TV_SID_DELETE_MY_APPS')
        }, {
            style: 12,
            text: Volt.i18n.t('TV_SID_LOCK_UNLOCK_MY_APPS')
        }, {
            style: 12,
            text: Volt.i18n.t('UID_SORT_BY')
        }, {
            style: 12,
            text: Volt.i18n.t('COM_TV_SID_UPDATE_APPS_KR_SINGULAR')
        }],
        subx: -Volt.width * 0.146875,
        suby: Volt.height * 0.133797,
        isSubtextShow: true,
        subText: [
            {
                index: 2,
                showNumber: 4,
                //bTextScroll: true,		
                bKeyCommon: true,
                items: [{
                    style: 13,
                    text: Volt.i18n.t('TV_SID_BY_DATE')
                }, {
                    style: 13,
                    text: Volt.i18n.t('SID_MOST_USED')
                }, {
                    style: 13,
                    text: Volt.i18n.t('COM_SID_TITLE_A_Z')
                }, {
                    style: 13,
                    text: Volt.i18n.t('COM_SID_TITLE_Z_A')
                }],
                width: Volt.width * 0.186458,
                nResoultionStyle: (Volt.APPS720P) ? "0" : "1",
  }
  ],
    },

    loading: {
        type: 'WinsetLoading',
        x: (Volt.width - Volt.width * 0.156771) / 2,
        y: Volt.height * 0.521296,
        style: '{{style20}}',
        nResoultionStyle: '{{nResoultionStyle}}',
        text: Volt.i18n.t('COM_SID_LOADING_DOT')
    },
};

exports = HomeTemplate;