var FeaturedListTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'featured-list-content-container-{{ type }}',
                type: 'widget',
                x: 0,
                y: 0,
                width: Volt.width,
                height: Volt.height * 0.8,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'featured-list-no-content-{{ type }}',
                type: 'text',
                x: Volt.width * 0.046875,
                y: Volt.height * (0.8-0.044444*2-0.041667-0.060185)/2,   
                width: Volt.width * (1-0.046875*2),
                height: Volt.height * 0.044444*2 + 10,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: '35px'
            },
            {
                id: 'featured-list-content-index-{{ type }}',
                type: 'text',
                x: Volt.width * 0.9375,
                y: Volt.height * 0.055556,
                height: Volt.height * 0.050926,
                width: Volt.width * 0.052083,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 40),
                text: '',
                font: '26px'
            },
            {
                id: 'featured-list-button-index-{{ type }}',
                type: 'widget',
                x: Volt.width * (1 - 0.140104)/2,
                y: Volt.height * (0.8-0.044444*2-0.041667-0.060185)/2 + Volt.height * (0.044444*2+0.041667), 
                width: Volt.width * 0.140104,
                height: Volt.height * 0.060185,
                color: Volt.hexToRgb('#000000', 0),
                custom: {
                    'focusable': false
                }
            }
        ]
    },
     // Deprecated Start
    troubelShootBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        x: 0,
        y: 0,
        width: Volt.width * 0.140104,
        height: Volt.height * 0.060185,
    },
    eventContainer: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                type: 'image',
                x: 0,
                y: 0,
                width: 378,
                height: 864,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'featured-list-content-container-{{ type }}',
                type: 'widget',
                x: 378,
                y: 0,
                width: 1920 - 378,
                height: 864,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'featured-list-no-content-{{ type }}',
                type: 'text',
                x: 90,
                y: 308,
                height: 55,
                width: 1920 - 180,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: '35px'
            },
            {
                id: 'featured-list-content-index-{{ type }}',
                type: 'text',
                x: 1800,
                y: -60,
                height: 55,
                width: 100,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 40),
                text: '',
                font: '26px'
            }
        ]
    },

    appinfo: {
        visibleStyles: (0x01 | // CommonDefines.Const.THUMB_STYLE_IMAGE
            0x20), // CommonDefines.Const.THUMB_STYLE_INFO
        coverColor: Volt.hexToRgb('#000000', 8),
        image: {
            x: Volt.width * 0.013542,
            y: Volt.height * 0.056481,
            width: Volt.width * (0.196875 - 0.013542 * 2) /*328*/ ,
            height: Volt.height * (0.4 - 0.056481 - 0.030556 - 0.056481 - 0.087963) /*184*/ ,
            async: true,
            cropOverflow: false,
            pivot: {
                x: 0.5,
                y: 1
            },
        },
        progressBar: {
            x: Volt.width * 0.013542,
            y: Volt.height * 0.22778,
            width: Volt.width * (0.196875 - 0.013542 * 2),
            height: 2,
            backgroundColor: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100),
            normalThumbSrc: '',
            focusThumbSrc: '',
            thumbWidth: 8,
            thumbHeight: 10,
        },
        information: {
            x: 0,
            y: Volt.height * (0.4 - 0.056481 - 0.087963) + 2 /*278*/ ,
            width: Volt.width * 0.196875,
            height: Volt.height * 0.14259,
            colorPickingRange: {
                l: 0,
                r: 100,
                t: 80,
                b: 100
            }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
            setAsBackground: true,
            pivot: {
                x: 0.5,
                y: 0
            },


            icon1: {
                x: Volt.width * 0.013542,
                y: 0,
                width: Volt.width * 0.059896,
                height: Volt.height * 0.087963, //115*95
                src: '',
                async: true
            },
            text1: {
                x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                y: 0,
                width: Volt.width * 0.101042,
                height: Volt.height * 0.040741,
                font: (Volt.APPS720P) ? 'SamsungSVD_Light 19px' : 'SamsungSVD_Light 28px',
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },
            },
            text2: {
                x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                y: Volt.height * 0.040741,
                width: Volt.width * 0.101042,
                height: Volt.height * 0.025926,
                font: (Volt.APPS720P) ? 'SamsungSVD_Light 13px' : 'SamsungSVD_Light 20px',
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },

            },
            text3: {
                x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                y: Volt.height * (0.040741 + 0.025926),
                width: Volt.width * (0.101042 - 0.016667),
                height: Volt.height * 0.028926, //Volt.height*0.025926,
                font: (Volt.APPS720P) ? 'SamsungSVD_Light 13px' : 'SamsungSVD_Light 20px',
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },

            },
            icon2: {
                x: Volt.width * (0.196875 - 0.014583 - 0.016667),
                y: Volt.height * (0.040741 + 0.025926),
                width: Volt.width * 0.016667,
                height: Volt.height * 0.02963,
                src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                async: true
            },

        }
    },

    mostPopularAppinfo: {
        visibleStyles: (0x01 | // CommonDefines.Const.THUMB_STYLE_IMAGE
            0x20), // CommonDefines.Const.THUMB_STYLE_INFO
        coverColor: Volt.hexToRgb('#000000', 8),
        image: {
            x: Volt.width * 0.013542,
            y: Volt.height * 0.056481,
            width: Volt.width * (0.196875 - 0.013542 * 2),
            height: Volt.height * (0.4 - 0.056481 - 0.030556 - 0.056481 - 0.087963),
            src: '',
            async: true,
            cropOverflow: false,
            pivot: {
                x: 0.5,
                y: 1
            },

        },
        progressBar: {
            x: Volt.width * 0.013542,
            y: Volt.height * 0.22778,
            width: Volt.width * (0.196875 - 0.013542 * 2),
            height: 2,
            backgroundColor: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100),
            normalThumbSrc: '',
            focusThumbSrc: '',
            thumbWidth: 8,
            thumbHeight: 10,
        },
        information: {
            x: 0,
            y: Volt.height * (0.4 - 0.056481 - 0.087963) + 2,
            width: Volt.width * 0.196875,
            height: Volt.height * 0.14259,
            colorPickingRange: {
                l: 0,
                r: 100,
                t: 80,
                b: 100
            }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
            setAsBackground: true,
            pivot: {
                x: 0.5,
                y: 0
            },


            icon1: {
                x: Volt.width * 0.013542,
                y: 0,
                width: Volt.width * 0.059896,
                height: Volt.height * 0.087963, //115*95
                src: '',
                async: true
            },
            text1: {
                x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                y: 0,
                width: Volt.width * 0.101042,
                height: Volt.height * 0.040741,
                font: (Volt.APPS720P) ? 'SamsungSVD_Light 19px' : 'SamsungSVD_Light 28px',
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },
            },
            text2: {
                x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                y: Volt.height * (0.040741 + 0.025926),
                width: Volt.width * (0.101042 - 0.016667),
                height: Volt.height * 0.028926, //Volt.height*0.025926,
                font: (Volt.APPS720P) ? 'SamsungSVD_Light 13px' : 'SamsungSVD_Light 20px',
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },
            },
            text3: {
                x: Volt.width * 0.082292,
                y: Volt.height * 0.040741,
                width: Volt.width * 0.101042,
                height: Volt.height * 0.028926,
                font: (Volt.APPS720P) ? 'SamsungSVD_Light 13px' : 'SamsungSVD_Light 20px',
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },

            },
            /*for no ratings*/
            rating: {
                x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                y: Volt.height * 0.040741,
                width: Volt.width * 0.052083,
                height: Volt.height * 0.025926,
                onSrc: Volt.getRemoteUrl('images/1080/common/apps_contents_star_wh.png'),
                onOpacity: 127,
                halfSrc: Volt.getRemoteUrl('images/1080/common/apps_contents_star_wh_half.png'),
                halfOpacity: 127,
                bgSrc: Volt.getRemoteUrl('images/1080/common/apps_contents_star_bg.png'),
                bgOpacity: 51,
                //offSrc:  Volt.getRemoteUrl('images/1080/common/apps_contents_star_bg.png'),         
                iconWidth: Volt.width * 0.010417,
                iconHeight: Volt.height * 0.018518,
                value: 5,
                gap: 0
            },

            icon2: {
                x: Volt.width * (0.196875 - 0.014583 - 0.016667),
                y: Volt.height * (0.040741 + 0.025926),
                width: Volt.width * 0.016667,
                height: Volt.height * 0.02963,
                src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                async: true
            }
        }
    },

    /*piainfo : {
        visibleStyles: (0x01), //CommonDefines.Const.THUMB_STYLE_IMAGE
        image: {
            x: 0, y: 0, width: Volt.width*0.196875, height: Volt.height*0.4, 
            fillMode: 'fit',
            src: Volt.getRemoteUrl('images/1080/common/PIA_15.jpg'),// Volt.getRemoteUrl("images/1080/common/PIA_15.jpg")
            async: true
        },
    },*/

    piainfo: {
        visibleStyles: (0x40),
        scrollPlayer: {
            x: 0,
            y: 0,
            width: Volt.width * 0.196875,
            height: Volt.height * 0.4,
            duration: 1000,
            itemNumber: 1,
            mode: 'QUADRATIC-in',
            fillMode: 'fit',
            src1: Volt.getRemoteUrl('images/1080/common/PIA_15.jpg'),
            src2: Volt.getRemoteUrl('images/1080/common/PIA_15.jpg'),
            async: true,
        }
    },

    progressbar: {
        x: Volt.width * 0.013542,
        y: Volt.height * 0.22778,
        width: Volt.width * 0.17083,
        height: 2,
        percentage: 0
    },

    gridList: {
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        itemHeight: Volt.height * 0.4,
        itemWidth: Volt.width * 0.196875,
        rows: 2
    },
};

exports = FeaturedListTemplate;