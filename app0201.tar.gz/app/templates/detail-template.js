var CommonTemplate = Volt.requireTemplate('common'),
    SCREEN_WIDTH = Volt.width,
    SCREEN_HEIGHT = Volt.height,

    titleHeight = SCREEN_HEIGHT * 0.133333,

    titleButtonWidth = SCREEN_WIDTH * 0.052083,
    titleButtonHeight = titleHeight,
    titleButtonIconWidth = Volt.getMultiResParam(24, 36),

    btnMoreWidth = Volt.getMultiResParam(27, 40),

    thumbWidth = SCREEN_WIDTH * 0.266667,
    thumbHeight = SCREEN_HEIGHT * 0.391667,

    thumbAreaX = SCREEN_WIDTH * 0.020833,
    thumbAreaHeight = thumbHeight + SCREEN_HEIGHT * (0.013889 + 0.014815 * 2),

    textX = thumbAreaX + thumbWidth + SCREEN_WIDTH * 0.020833,
    textWidth = SCREEN_WIDTH * (0.643750 + 0.014583) + btnMoreWidth,


    appInfoY = titleHeight + SCREEN_HEIGHT * 0.041667,
    appInfoHeight = SCREEN_HEIGHT * (0.035185 * 3 + 0.041667),

    descY = appInfoY + appInfoHeight,
    descHeight = SCREEN_HEIGHT * 0.035185 * 3,

    shotY = descY + descHeight + SCREEN_HEIGHT * 0.033333,
    shotWidth = SCREEN_WIDTH * (0.160417 * 3 + 0.155730),

    shotItemHeight = SCREEN_HEIGHT * 0.154630,
    shotItemWidth = SCREEN_WIDTH * 0.155730,

    buttonWidth = SCREEN_WIDTH * 0.213542,
    buttonHeight = SCREEN_HEIGHT * 0.059259,

    buttonsY = shotY + shotItemHeight + SCREEN_HEIGHT * 0.024075,
    buttonsWidth = SCREEN_WIDTH * 0.229167 * 2 + buttonWidth,

    iconWidth = Volt.getMultiResParam(24, 36),
    starWidth = Volt.getMultiResParam(13, 20);

var detailViewTemplate = {

    screenShotGap: 320,
    normalDescription: 38 * 3,
    moreDescription: 410,
    buttonGap: 440,

    dim: {
        id: 'detail-dim',
        type: 'widget',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH,
        height: SCREEN_HEIGHT,
        color: Volt.hexToRgb('#000000'),
        opacity: Volt.getPercentage(80)
    },

    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH,
        height: SCREEN_HEIGHT,
        /*
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        */
        color: Volt.hexToRgb('#233146', 0),
        children: [
            {
                type: 'WinsetBackground',
                id: 'detail-background-colorpick',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH,
                height: SCREEN_HEIGHT,
                style: '{{highconstract}}',
                bgColor: Volt.hexToRgb('#233146'),
                bgHighContrastColor: Volt.hexToRgb('#000000', 100), // 1f2b3d
                /*children: [{
                    type: 'widget',
                    x: 0,
                    y: 0,
                    width: SCREEN_WIDTH,
                    height: SCREEN_HEIGHT,
                    color:Volt.hexToRgb('#000000', 64),
                    children: [{
	                    type: 'widget',
	                    x: 0,
	                    y: 0,
	                    width: SCREEN_WIDTH,
	                    height: SCREEN_HEIGHT*0.133333,
	                    color:Volt.hexToRgb('#000000', 20),
                    },
                    {
	                    type: 'widget',
	                    x: 0,
	                    y: SCREEN_HEIGHT*(1-0.204630),
	                    width: SCREEN_WIDTH,
	                    height: SCREEN_HEIGHT*0.204630,
	                    color:Volt.hexToRgb('#000000', 20),
                    }]
                }]*/
            },

   /*{
                type: 'widget',
                id: 'detail-center-colorpick',
                x: 0,
                y: titleHeight,
                width: SCREEN_WIDTH,
                height: SCREEN_HEIGHT * 0.866667, // 936,
                color: Volt.hexToRgb('#233146'),
            }, 
            */
            {
                type: 'WinsetBackground',
                id: 'detail-title-area',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH,
                height: titleHeight, //144,
                style: '{{highconstract}}',
                bgColor: Volt.hexToRgb('#1f2b3d', 0), // 1f2b3d
                bgHighContrastColor: Volt.hexToRgb('#ffffff', 0),
            },


            {
                type: 'widget',
                id: 'detail-thumb-area',
                x: thumbAreaX,
                y: titleHeight, //144,
                width: thumbWidth, //512,
                height: thumbAreaHeight, //423 + 15 + 16 + 16 + 15,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                type: 'widget',
                id: 'detail-appInfo-area',
                x: textX, //40 + 512 + 40,
                y: appInfoY, //144 + 45,
                width: textWidth, //1236 + 28 + 40,
                height: appInfoHeight, //45 + 38,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                type: 'widget',
                id: 'detail-description-area',
                x: textX, //40 + 512 + 40,
                y: descY, //144 + 45 + 38 + 70,
                width: textWidth, //1236 + 28 + 40,
                height: descHeight, //74 + 40,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                id: 'detail-screenshot-area',
                type: 'widget',
                x: textX,
                y: shotY, //447 - 4,
                width: shotWidth, //1358,
                height: shotItemHeight, //176, //45+38+70+38+38+36,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                type: 'widget',
                x: textX,
                y: buttonsY, ////447 + 168 + 50 - 4,
                width: buttonsWidth, //1358,
                height: buttonHeight, //72,
                id: 'detail-button-area',
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                type: 'widget',
                x: thumbAreaX,
                y: titleHeight + thumbAreaHeight + 0.027778 * SCREEN_HEIGHT,
                width: SCREEN_WIDTH * 0.144271,
                height: SCREEN_HEIGHT * (0.037963 + 0.024074 * 2),
                id: 'detail-storage-area',
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            },

   /*{
                type: 'WinsetBackground',
                x: 0,
                y: SCREEN_HEIGHT - SCREEN_HEIGHT * (1 - 0.795370), //812,
                width: SCREEN_WIDTH,
                height: SCREEN_HEIGHT * (1 - 0.795370 ), //268,
                id: 'detail-list-area',
				style: '{{highconstract}}',
				bgColor: Volt.hexToRgb('#1f2b3d'),
				bgHighContrastColor: Volt.hexToRgb('#ffffff', 10),
				///*
				children: [{
                    type: 'widget',
                    x: 0,
                    y: 0, //47,
                    width: SCREEN_WIDTH,
                    height: SCREEN_HEIGHT * (1 - 0.795370), //221,
                    color: Volt.hexToRgb('#233146',0), // 1f2b3d
                }]
                */

            {
                type: 'widget',
                x: 0,
                y: SCREEN_HEIGHT * (1 - 0.20463 - 0.043519), //812,
                width: SCREEN_WIDTH,
                height: SCREEN_HEIGHT * (0.20463 + 0.043519), //268,
                id: 'detail-list-area',
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                children: [{
                    type: 'WinsetBackground',
                    x: 0,
                    y: SCREEN_HEIGHT * 0.043519, //47,
                    width: SCREEN_WIDTH,
                    height: SCREEN_HEIGHT * 0.20463, //221,
                    style: '{{highconstract}}',
                    bgColor: Volt.hexToRgb('#1f2b3d', 0),
                    bgHighContrastColor: Volt.hexToRgb('#ffffff', 0),
                }]
            }


           // }
        ]
    },

    title: [
        {
            type: 'text',
            x: 0,
            y: 0,
            width: SCREEN_WIDTH,
            height: titleHeight,
            font: Volt.getMultiResParam('44px', '66px'),
            text: '{{title}}',
            textColor: Volt.hexToRgb('#ffffff', 100),
            horizontalAlignment: "center",
            verticalAlignment: "center"
        }, {
            id: 'detail-return-button',
            type: 'Button',
            x: 0,
            y: 0,
            width: titleButtonWidth,
            height: titleButtonHeight,
            color: CommonTemplate.COLOR_TRANSPARENCY,
            icon: {
                x: (titleButtonWidth - titleButtonIconWidth) / 2,
                y: (titleButtonHeight - titleButtonIconWidth) / 2,
                width: titleButtonIconWidth,
                height: titleButtonIconWidth,
                src: Volt.getMultiResImage('icon/comn_icon_tm_return.png'),
                opacity: 255 * 0.6
            },
            custom: {
                cmStyle: 'TITLE_LEFT'
            }
        }, {
            id: 'detail-exit-button',
            type: 'Button',
            x: SCREEN_WIDTH - titleButtonWidth,
            y: 0,
            width: titleButtonWidth,
            height: titleButtonHeight,
            color: CommonTemplate.COLOR_TRANSPARENCY,
            icon: {
                x: (titleButtonWidth - titleButtonIconWidth) / 2,
                y: (titleButtonHeight - titleButtonIconWidth) / 2,
                width: titleButtonIconWidth,
                height: titleButtonIconWidth,
                src: Volt.getMultiResImage('common/comn_icon_tm_close_nor.png'),
                opacity: 255 * 0.6
            },
            custom: {
                cmStyle: 'TITLE_RIGHT'
            }
        }
    ],
    /*
    title: [
        {
            type: 'text',
            x: 0,
            y: 0,
            width: SCREEN_WIDTH,
            height: titleHeight,
            font: Volt.getMultiResParam('44px', '66px'),
            text: '{{title}}',
            textColor: Volt.hexToRgb('#ffffff', 90),
            horizontalAlignment: "center",
            verticalAlignment: "center"
        },
        {
            id: 'detail-return-button',
            type: 'ButtonControl',
            x: 0,
            y: 0,
            width: titleButtonWidth,
            height: titleButtonHeight,
            color: CommonTemplate.COLOR_TRANSPARENCY
            opacity: 255 * 0.6,
            // icon: {
                // x: 20,
                // y: 100,
                // width: 50,
                // height: 50,
                // src: "./images/btn/obe_navi_arrow_r_skip_n.png"
            // },
            // backgroundImage: {
            // x: 0,
            // y: 0,
            // width: 150,
            // height: 150,
            // src: "./images/btn/btn_style_a_n.png"},
        
            custom: {
                 cmPosition: 'left',
                 cmIconWidth: Volt.getMultiResParam(24, 36),
                 cmIconHeight: Volt.getMultiResParam(24, 36),
            }
        },
        {
            id: 'detail-close-button',
            type: 'ButtonControl',
            x: SCREEN_WIDTH - titleButtonWidth,
            y: 0,
            width: titleButtonWidth,
            height: titleButtonHeight,
            color: CommonTemplate.COLOR_TRANSPARENCY
            opacity: 255 * 0.6,
            custom: {
                
            }
        }
    ],
    */


    ThumbArea: {
        type: 'widget',
        x: 0,
        y: 0,
        width: thumbWidth, //560,
        height: thumbAreaHeight, //420,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'image',
                id: 'thumb-area',
                x: 0,
                y: 0,
                width: thumbWidth, //512,
                height: thumbHeight, //423,
                src: '{{ thumbnail }}',
                fillMode: 'center',
            }, {
                type: 'text',
                x: 0,
                y: thumbHeight, //423 + 15,
                width: thumbWidth, //512,
                height: thumbAreaHeight - thumbHeight, //16 + 16,
                font: Volt.getMultiResParam('9px', '13px'),
                text: Volt.i18n.t('TV_SID_SAMSUNG_ELECTRONICS_PLAY_ROLE_INTERMEDIARY_REGISTERED'),
                textColor: Volt.hexToRgb('#ffffff', 100),
                horizontalAlignment: "left",
                verticalAlignment: "center",
            }
        ]
    },

    appInfo: {
        type: 'widget',
        x: 0,
        y: 0,
        width: textWidth, //1236 + 28 + 40,
        height: appInfoHeight, //222,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'text',
                id: 'detail-description-firstLine',
                x: 0.009896 * SCREEN_WIDTH + 5 * starWidth + 0.004167 * SCREEN_WIDTH, //126,
                y: 0,
                height: SCREEN_HEIGHT * 0.035185, //38,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: '{{avgRating}}   ',
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
            }, {
                type: 'text',
                id: 'detail-description-secondLine1',
                x: 0,
                y: SCREEN_HEIGHT * 0.035185, //38,
                height: SCREEN_HEIGHT * 0.035185, //38, // width : 1236,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('SID_FREE_M_FREE'),
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
            },
            {
                type: 'widget',
                id: 'detail-description-secondLine_bar1',
                y: SCREEN_HEIGHT * 0.035185 + SCREEN_HEIGHT * 0.008334, //38,
                width: SCREEN_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519, //38, // width : 1236,
                color: Volt.hexToRgb('#ffffff', 20),
   },
            {
                type: 'text',
                id: 'detail-description-secondLine2',
                y: SCREEN_HEIGHT * 0.035185, //38,
                height: SCREEN_HEIGHT * 0.035185, //38, // width : 1236,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('SID_RATED') + ': ',
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
            },
            {
                type: 'image',
                x: 9,
                y: 38 + 8,
                width: 21,
                height: 21,
                src: ''
            }, {
                type: 'text',
                id: 'detail-description-secondLine3',
                y: SCREEN_HEIGHT * 0.035185, //38,
                height: SCREEN_HEIGHT * 0.035185, //38 // width : 1236,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: "{{rated}} ",
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
            },
            {
                type: 'widget',
                id: 'detail-description-secondLine_bar2',
                y: SCREEN_HEIGHT * 0.035185 + SCREEN_HEIGHT * 0.008334, //38,
                width: SCREEN_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519, //38, // width : 1236,
                color: Volt.hexToRgb('#ffffff', 20),
   },
            {
                type: 'text',
                id: 'detail-description-secondLine4',
                y: SCREEN_HEIGHT * 0.035185, //38,
                height: SCREEN_HEIGHT * 0.035185, //38 // width : 1236,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('UID_M_M_SIZE') + ": {{size}}",
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
            },
            {
                type: 'widget',
                id: 'detail-description-secondLine_bar3',
                y: SCREEN_HEIGHT * 0.035185 + SCREEN_HEIGHT * 0.008334, //38,
                width: SCREEN_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519, //38, // width : 1236,
                color: Volt.hexToRgb('#ffffff', 20),
   },
            {
                type: 'text',
                id: 'detail-description-secondLine5',
                y: SCREEN_HEIGHT * 0.035185, //38,
                height: SCREEN_HEIGHT * 0.035185, //38 // width : 1236,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('COM_SID_UPDATED') + " {{updated}}",
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
            },
            {
                type: 'text',
                id: 'detail-description-thirdLine1',
                x: 0,
                y: SCREEN_HEIGHT * (0.035185 * 2), //38,
                height: SCREEN_HEIGHT * 0.035185, //38 // width : 1236,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('COM_IDS_VERSION') + ': {{version}} {{installed}}',
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
         },
            {
                type: 'widget',
                id: 'detail-description-thirdLine_bar1',
                y: SCREEN_HEIGHT * (0.035185 * 2) + SCREEN_HEIGHT * 0.008334, //38,
                width: SCREEN_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519, //38, // width : 1236,
                color: Volt.hexToRgb('#ffffff', 20),
   },
            {
                type: 'text',
                id: 'detail-description-thirdLine2',
                y: SCREEN_HEIGHT * (0.035185 * 2), //38,
                height: SCREEN_HEIGHT * 0.035185, //38 // width : 1236,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: 'Languages: {{language}}',
                font: Volt.getMultiResParam('17px', '26px'),
                singleLineMode: true,
         },
        ]
    },

    descriptionOneLineHeight: SCREEN_HEIGHT * 0.035185, //38,
    descriptionLineHeight: SCREEN_HEIGHT * 0.105556, //114,
    descriptionMaxLineHight: SCREEN_HEIGHT * 0.527775, // 595,

    description: {
        type: 'widget',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH * 0.679167, //1236 + 28 + 40,
        height: SCREEN_HEIGHT * 0.105556, //74 + 40,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'widget',
                id: 'detail-description-text-container',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH * 0.64375, //1236,
                height: SCREEN_HEIGHT * 0.553704, //598,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                cropOverflow: true,
                children: [
                    {
                        type: 'text',
                        id: 'detail-description-text',
                        x: 0,
                        y: 0,
                        width: SCREEN_WIDTH * 0.64375, //1236,
                        horizontalAlignment: 'left',
                        textColor: Volt.hexToRgb('#ffffff', 100),
                        text: '{{description}}',
                        font: (Volt.APPS720P) ? '20px' : '30px'
                    }
                ]
            }, {
                type: 'image',
                id: 'detail-description-up-arrow',
                x: 0,
                y: -SCREEN_HEIGHT * 0.02963, //-32,
                width: SCREEN_WIDTH * 0.64375, //1236,
                height: SCREEN_HEIGHT * 0.02963, //32,
                opacity: 153,
                src: Volt.getRemoteUrl('images/1080/common/apps_detail_arrow_u.png')
            }, {
                type: 'image',
                id: 'detail-description-down-arrow',
                x: 0,
                y: SCREEN_HEIGHT * 0.553704, //608,
                width: SCREEN_WIDTH * 0.64375, //1236,
                height: SCREEN_HEIGHT * 0.02963,
                opacity: 153,
                src: Volt.getRemoteUrl('images/1080/common/apps_detail_arrow_d.png')
            }, {
                type: 'widget',
                id: 'detail-more-button',
                x: SCREEN_WIDTH * 0.648958, //1236 + 10,
                y: SCREEN_HEIGHT * 0.068518, //74,
                width: SCREEN_WIDTH * 0.020833, //40,
                height: SCREEN_HEIGHT * 0.037037, //40,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                custom: {
                    'focusable': false
                }
            }, {
                type: 'widget',
                id: 'detail-close-button',
                x: SCREEN_WIDTH * 0.200167, //440,
                y: SCREEN_HEIGHT * (0.553704 + 0.02963 + 0.032407 - 0.02), //675,
                width: SCREEN_WIDTH * 0.15625, //300,
                height: SCREEN_HEIGHT * 0.059259, //64,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                custom: {
                    'focusable': false
                }
            },
        ]
    },

    setScrollbar: {
        x: SCREEN_WIDTH * 0.645833, //1240,
        y: 0,
        width: SCREEN_WIDTH * 0.010417, //20,
        height: SCREEN_HEIGHT * 0.550926, //595,
        isVertical: true,
    },

    moreBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: 'moreBtn',
        x: 0,
        y: 0,
        width: btnMoreWidth, //40,
        height: btnMoreWidth, //40,
        iconWidth: SCREEN_WIDTH * 0.011458, //22,
        iconHeight: SCREEN_HEIGHT * 0.02037, //22,
        iconImgSrc: Volt.getRemoteUrl("images/1080/common/btn_icon_more.png"),
    },

    closeBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "closeBtn",
        x: 0,
        y: 0,
        width: SCREEN_WIDTH * 0.156250,//300,
        height: SCREEN_HEIGHT * 0.059259, // 64,
        text: Volt.i18n.t('COM_SID_CLOSE'),
    },

    // Deprecated
    /*screenShot: {
        type: 'widget',
        id: 'screenshot-list-item-{{ id }}',
        width: 300,
        height: 168,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'image',
                x: 0,
                y: 0,
                width: 300,
                height: 168,
                src: '{{screenShotURL}}',
            }
        ],
        custom: {
            'focusable': true
        }
    },*/
    screenShotGridList: {
        x: 0,
        y: 0,
        width: shotWidth, //1224,
        height: shotItemHeight, //168,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: SCREEN_WIDTH * (0.160417 - 0.156250), //8,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        itemHeight: shotItemHeight, //168,
        itemWidth: shotItemWidth, //300,
        rows: 1
    },
    screenShotThumbnailStyle: {
        visibleStyles: (0x01 | 0x20), //  | 0x10 | 0x08),
        image: {
            width: shotItemWidth, //300,
            height: shotItemHeight, //168,
            async: true
        },
    },
    buttonContainer: {
        type: 'widget',
        x: 0,
        y: 0,
        width: buttonsWidth, //1358,
        height: buttonHeight, //60,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                custom: {
                    'focusable': true
                },
                type: 'widget',
                id: 'download_button_widget',
                color: Volt.hexToRgb('#FFFFFF', 0),
                x: 0,
                y: 0, //4,
                width: buttonWidth, //410,
                height: buttonHeight, //64,
            }, {
                custom: {
                    'focusable': true
                },
                type: 'widget',
                id: 'rating_button_widget',
                color: Volt.hexToRgb('#FFFFFF', 0),
                x: SCREEN_WIDTH * 0.229167, //440,
                y: 0, //4,
                width: buttonWidth, //410,
                height: buttonHeight, //65,
            },
        ]
    },

    // Deprecated Start
    downloadBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "downloadBtn",
        x: 0,
        y: 0,
        width: buttonWidth, //410,
        height: buttonHeight, // 64,
        //text : "Download",
    },

    ratingBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "ratingBtn",
        x: 0,
        y: 0,
        width: buttonWidth, // 410,
        height: buttonHeight, //64,
        text: "",
    },

    contentStar: {
        type: 'image',
        x: 0,
        y: SCREEN_HEIGHT * 0.00787, //8.5,
        width: SCREEN_WIDTH * 0.010417, //20,
        height: SCREEN_HEIGHT * 0.018518, //20,
        src: '{{imageUrl}}'
    },

    btnStar: {
        type: 'image',
        x: 0,
        y: SCREEN_HEIGHT * 0.014815, //16,
        width: SCREEN_WIDTH * 0.016667, //32,
        height: SCREEN_HEIGHT * 0.02963, //32,
    },

    // Deprecated End

    storage: {
        type: 'widget',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH * 0.180209,
        height: SCREEN_HEIGHT * (0.037963 + 0.024074 * 2),
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'widget',
                id: 'storage-info-progress-bg',
                x: 0,
                y: SCREEN_HEIGHT * 0.031481,
                width: SCREEN_WIDTH * 0.180209,
                height: SCREEN_HEIGHT * 0.001852,
                color: Volt.hexToRgb('#ffffff', 0)
            },
            {
                type: 'text',
                id: 'storage-info-text-all',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH * 0.180209,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: Volt.APPS_REVERSE ? 'right' : 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
                singleLineMode: true,
                text: Volt.i18n.t('COM_SID_MEMORY_USE'),
            }, {
                type: 'text',
                id: 'storage-info-text-all-value',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH * 0.180209,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
                singleLineMode: true,
            }, {
                type: 'text',
                id: 'storage-info-text-used',
                x: 0,
                y: SCREEN_HEIGHT * 0.037963,
                width: SCREEN_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.024075,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
                text: Volt.i18n.t('COM_SID_USED_KR_ING'),
            }, {
                type: 'text',
                id: 'storage-info-text-available',
                x: SCREEN_WIDTH * (0.087500 + 0.005208),
                y: SCREEN_HEIGHT * 0.037963,
                width: SCREEN_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.024075,
                horizontalAlignment: 'right',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
                text: Volt.i18n.t('TV_SID_AVAILABLE_EMPTY'),
            }, {
                type: 'text',
                id: 'storage-info-text-used-value',
                x: 0,
                y: SCREEN_HEIGHT * (0.037963 + 0.024075),
                width: SCREEN_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.024075,
                horizontalAlignment: Volt.APPS_REVERSE ? 'right' : 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
            }, {
                type: 'text',
                id: 'storage-info-text-available-value',
                x: SCREEN_WIDTH * (0.087500 + 0.005208),
                y: SCREEN_HEIGHT * (0.037963 + 0.024075),
                width: SCREEN_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.024075,
                horizontalAlignment: Volt.APPS_REVERSE ? 'left' : 'right',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
            }
        ]
    },

    setGridList: {
        x: 0,
        y: SCREEN_HEIGHT * 0.043519, //47,
        width: SCREEN_WIDTH,
        height: SCREEN_HEIGHT * 0.20463, //221,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        itemHeight: SCREEN_HEIGHT * 0.20463, //221,
        itemWidth: SCREEN_WIDTH * 0.102083, //196,
        rows: 1
    },

    setBtnProgressBar: {
        x: 0,
        y: SCREEN_HEIGHT * 0.07037, //64 + 12,
        width: SCREEN_WIDTH * 0.213542, //410,
        height: 2,
        percentage: 0
    },

    downloadGuideText: {
        type: 'text',
        x: 0,
        y: SCREEN_HEIGHT * 0.0777778, //64 + 12 + 2 + 6,
        width: SCREEN_WIDTH * 0.707292, //1358,
        height: SCREEN_HEIGHT * 0.027778, //30,
        horizontalAlignment: 'left',
        verticalAlignment: 'top',
        font: Volt.getMultiResParam('13px', '20px'),
        textColor: Volt.hexToRgb('#ffffff', 100),
        opacity: Volt.getPercentage(100),
        text: Volt.i18n.t('COM_SID_INTERNAL_MEMORY_LOW_USB_INSTALL')
    },

    relatedText: {
        type: 'text',
        x: SCREEN_WIDTH * 0.013542, //26,
        y: 0,
        width: SCREEN_WIDTH * (1 - 0.013542), //486,
        height: SCREEN_HEIGHT * 0.037037, //40,
        font: Volt.getMultiResParam('17px', '26px'),
        text: Volt.i18n.t('TV_SID_USER_THIS_APP_DOWNLOADED'),
        textColor: Volt.hexToRgb('#ffffff', 100),
        horizontalAlignment: "left",
        verticalAlignment: "center"
    },

    /*appTitleScrollTextWidget: {
        type: 'AutoScrollTextWidget',
        x: 10,
        y: 172,
        width: 176,
        height: 40,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        }
    },

    appTitleScrollTextContent: {
        text: '',
        textfont: '26px',
        textVerticalAlignment: 'center',
        textHorizontalAlignment: 'center'
    },

    setProgressBar: {
        x: 0,
        y: 33,
        width: 210,
        height: 2,
        color: {
            r: 255,
            g: 255,
            b: 255,
            a: 51
        },
        foreColor: {
            r: 255,
            g: 255,
            b: 255,
            a: 153
        },
    },*/

    storageProgressBar: {
        type: 'WinsetProgress',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH * 0.180209,
        height: 2,
        nProgressStyle: '{{nProgressStyle}}',
        nResoultionStyle: '{{nResoultionStyle}}'
    },

    toolTip: {
        type: 'WinsetToolTip',
        x: '{{x}}',
        y: '{{y}}',
        width: '{{w}}',
        height: Volt.height * 0.054630,
        style: '{{style}}',
        nResoultionStyle: '{{nResoultionStyle}}',
        text: '{{text}}',
        tailPostion: '{{tailPostion}}',
        parent: scene
    },

    loading: {
        type: 'WinsetLoading',
        x: (Volt.width - Volt.width * 0.156771) / 2,
        y: Volt.height * 0.521296,
        style: '{{style20}}',
        nResoultionStyle: '{{nResoultionStyle}}',
        text: Volt.i18n.t('COM_SID_LOADING_DOT')
    },
};

exports = detailViewTemplate;


////////////////////////////////////
// Deprecated. Old Code
/*
    title: {
        type: 'widget',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH,
        height: titleHeight,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'text',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH,
                height: titleHeight,
                font: Volt.getMultiResParam('44px', '66px'),
                text: '{{title}}',
                textColor: Volt.hexToRgb('#ffffff', 90),
                horizontalAlignment: "center",
                verticalAlignment: "center"
            }, {
                type: 'widget',
                id: 'detail-page-back-arrow',
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 20.4
                },
                x: 0,
                y: 0,
                width: SCREEN_WIDTH * 0.052083, //100,
                height: titleHeight,
                children: [
                    {
                        type: 'image',
                        x: (SCREEN_WIDTH * 0.052083 - iconWidth) / 2, //(100 - 36) / 2,
                        y: (titleHeight - iconWidth) / 2,
                        width: iconWidth,
                        height: iconWidth,
                        src: Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_nor.png')
                    }
                ]
            }, {
                type: 'widget',
                id: 'detail-page-exit-arrow',
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 20.4
                },
                x: Volt.width * (1 - 0.052083),
                y: 0,
                width: Volt.width * 0.052083,
                height: Volt.height * 0.133333,
                children: [
                    {
                        type: 'image',
                        x: Volt.width * 0.0171875,
                        y: Volt.height * 0.050926,
                        width: Volt.width * 0.0171875,
                        height: Volt.height * 0.030555,
                        src: Volt.getRemoteUrl('images/1080/common/comn_icon_tm_close_nor.png')
                    }
                ]
            },
        ]
    },
    */
// end
////////////////////////////////////