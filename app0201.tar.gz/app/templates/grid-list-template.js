/** 
 * @author Common Module Team
 * @fileoverview Template for Grid List View
 * @date 2014/11/18
 *
 * @version 2.0
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Thumbnail Visibile Style Definitions
var THUMB_VISIBLE_STYLE_IMAGE = 0x01,
    THUMB_VISIBLE_STYLE_INFO = 0x20;

// Get Common Parameters from CommonTemplate
var CommonTemplate = Volt.requireTemplate('common'),
    SCREEN_WIDTH = Volt.width,
    SCREEN_HEIGHT = Volt.height;

// Calc Multi-Resolution Parameters
var wUpdateIcon = Volt.getMultiResParam(21, 32);

//
var GridListTemplate = {
    //GRID_STYLE_GENERAL: 0,
    //GRID_STYLE_MYAPPS: 2,

    // Thumbnail Styles Definition
    //THUMB_STYLE_GENERAL: 0, // 
    //THUMB_STYLE_POPULAR: 1,
    THUMB_RELATED: 0,

    // getGridTemplate: function (categoryId) {
    // if (categoryId == 'C0010') {
    // return this.spotlightGrid;
    // } else {
    // return this.generalGrid;
    // }
    // },

    // Get a thumbnail template according to thumbnail style defined in GUI doc
    getThumbnailTemplate: function (thumbStyle) {
        return this.thumbnails[this[thumbStyle]];
    },

    //// Thumbnail Styles
    thumbnails: [
        {
            visibleStyles: (THUMB_VISIBLE_STYLE_IMAGE | THUMB_VISIBLE_STYLE_INFO), //  | 0x10 | 0x08),
            coverColor: Volt.hexToRgb('#000000', 8),
            image: { //// App Icon
                width: SCREEN_WIDTH * 0.102083, //196,
                height: SCREEN_HEIGHT * 0.15, //162,
                async: true
            },
            progressBar: {
                x: SCREEN_WIDTH * 0.010417, //20,
                y: SCREEN_HEIGHT * 0.15, //162,
                width: SCREEN_WIDTH * 0.08125, //156,
                height: 2,
                backgroundColor: Volt.hexToRgb('#ffffff', 40),
                progressColor: Volt.hexToRgb('#ffffff', 100),
                normalThumbSrc: '',
                focusThumbSrc: '',
                thumbWidth: 2,
                thumbHeight: 2,

                slidable: false
            },
            information: {
                x: 0,
                y: SCREEN_HEIGHT * 0.15, //162,
                width: SCREEN_WIDTH * 0.102083, //196,
                height: SCREEN_HEIGHT * 0.05463, //59,
                colorPickingRange: {
                    l: 0,
                    r: 100,
                    t: 80,
                    b: 100
                }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
                text1: { //// App Title
                    x: SCREEN_WIDTH * 0.010417,
                    y: SCREEN_HEIGHT * 0.009259,
                    width: SCREEN_WIDTH * (0.081249) - wUpdateIcon,
                    height: SCREEN_HEIGHT * 0.037037,
                    font: Volt.getMultiResParam('SamsungSVD_Light 17px', 'SamsungSVD_Light 26px'),
                    singleLineMode: true,
                    opacity: 255 * 0.6,
                    horizontalAlignment: "center",
                    verticalAlignment: "center",
                    ellipsize: true,
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },
                },
                icon1: { //// Update Icon
                    x: SCREEN_WIDTH * (0.102083 - 0.010417) - wUpdateIcon, //196 - 32 - 9,
                    y: SCREEN_HEIGHT * 0.012963, //14,
                    width: wUpdateIcon, //32,
                    height: wUpdateIcon, //32,
                    src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                    async: true
                }
            },
        },
    ],

    defaultScreenShot: Volt.getMultiResImage('common/apps_screenshot_default.png'),
};

exports = GridListTemplate;



/*
    var gridHeight = SCREEN_HEIGHT * 0.8,

    //
    generalThumbWidth = SCREEN_WIDTH * 0.196875,
    generalThumbHeight = SCREEN_HEIGHT * 0.4,
    generalImageWidth = Volt.getMultiResParam(217, 328),
    generalImageHeight = Volt.getMultiResParam(122, 184),
    generalPaddingX = SCREEN_WIDTH * 0.013542,
    generalPaddingY = SCREEN_WIDTH * 0.56481,
    generalIconWidth = Volt.getMultiResParam(115, 77),
    generalIconWidth = Volt.getMultiResParam(95, 63);
    
    
    // Grid
    general_grid: {
        type: 'GridListControl',
        width: SCREEN_WIDTH,
        height: gridHeight,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        itemHeight: generalThumbWidth,
        itemWidth: generalThumbHeight,
        rows: 2,
        custom: {
            focusable: true
        }
    },

    // Template for General Apps Item: What's New and Categories
    general_thumbnail: { // Style General
        type: 'Thumbnail',
        visibleStyles: (THUMB_VISIBLE_STYLE_IMAGE | THUMB_VISIBLE_STYLE_INFO),
        width: generalThumbWidth,
        height: generalThumbHeight,

        image: {
            x: generalPaddingX,
            y: generalPaddingY,
            width: generalImageWidth, // 328
            height: generalImageHeight,// 184
            async: true,
            defaultSrc: Volt.getMultiResImage('icon/icon_blank_thumbnail.png'),
        },

        progressBar: {
            x: SCREEN_WIDTH * 0.013542,
            y: SCREEN_HEIGHT * 0.22778,
            width: SCREEN_WIDTH * (0.196875 - 0.013542 * 2),
            height: 2,
            backgroundColor: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100),
            normalThumbSrc: '',
            focusThumbSrc: '',
            thumbWidth: 8,
            thumbHeight: 10,
        },

        information: {
            x: generalPaddingX,
            y: generalPaddingY + generalImageHeight + SCREEN_HEIGHT * 0.030556//278 ,
            width: generalThumbWidth - generalPaddingX,
            height: SCREEN_HEIGHT * 0.14259,
            
            colorPickingRange: {
                l: 0,
                r: 100,
                t: 80,
                b: 100
            }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom

            icon1: {    // App Icon
                x: 0,
                y: 0,
                width: generalIconWidth,
                height: generalIconHeight, //115*95
                //src: '',
                async: true
            },
            
            text1: {    // Title
                x: generalIconWidth + SCREEN_WIDTH * 0.008854,
                y: 0,
                width: SCREEN_WIDTH * 0.101042,
                height: SCREEN_HEIGHT * 0.035185,
                font: Volt.getMultiResParam('SamsungSVD_Light 18px', 'SamsungSVD_Light 28px'),
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },
            },
            
            text2: {    // Date
                x: generalIconWidth + SCREEN_WIDTH * 0.008854,
                y: SCREEN_HEIGHT * 0.040741,
                width: SCREEN_WIDTH * 0.101042,
                height: SCREEN_HEIGHT * 0.025926,
                font: Volt.getMultiResParam('SamsungSVD_Light 13px', 'SamsungSVD_Light 20px'),
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },

            },
            text3: { // Volume
                x: SCREEN_WIDTH * (0.196875 - 0.101042 - 0.013542),
                y: SCREEN_HEIGHT * (0.040741 + 0.025926),
                width: SCREEN_WIDTH * (0.101042 - 0.016667),
                height: SCREEN_HEIGHT * 0.028926, //SCREEN_HEIGHT*0.025926,
                font: CommonTemplate.getParam('SamsungSVD_Light 13px' : 'SamsungSVD_Light 20px'),
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },

            },
            icon2: {    // Downloaded
                x: SCREEN_WIDTH * (0.196875 - 0.014583 - 0.016667),
                y: SCREEN_HEIGHT * (0.040741 + 0.025926),
                width: SCREEN_WIDTH * 0.016667,
                height: SCREEN_HEIGHT * 0.02963,
                src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                async: true
            },
        }
    },

    progressbar: {
        x: SCREEN_WIDTH * 0.013542,
        y: SCREEN_HEIGHT * 0.22778,
        width: SCREEN_WIDTH * 0.17083,
        height: 2,
        percentage: 0
    },
 */