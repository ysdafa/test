/** 
 * @author hyoseon Ju (hyoseon.ju@samsung.com)
 * @fileoverview This module show connected usb list in tv.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var _ = Volt.require('modules/underscore.js')._,
    Backbone = Volt.require('modules/backbone.js'),
    VoltJSON = Volt.require('modules/VoltJSON.js');

// Include Template
var Template = Volt.require('app/templates/1080/developModeSetTemplate.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js');
CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');

/**
 * @name UpdateAppsView
 */
var smartHubPopupView = Volt.BaseView.extend({
    /** @lends UpdateAppsView.prototype */
    template: Template.smartHubContainer,
    /**
     * Initialize UpdateAppsView
     * @name UpdateAppsView
     * @constructs
     */
    initialize: function () {
        print("[UpdateAppsView.js] initialize");
    },

    /**
     * Render this widget
     * @method
     * @memberof UpdateAppsView
     */
    render: function () {
        Volt.log("[UpdateAppsView.js] render");

    },
    /**
     * Show this widget, fetch usbListm and bind event
     * @method
     * @memberof UpdateAppsView
     */
    show: function () {
        Volt.log("[UpdateAppsView.js] show");
        this.setWidget(Volt.loadTemplate(this.template));
        this.widget.show();
        Volt.Nav.setRoot(this.widget);
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SMARTHUB_INFO_VIEW);
    },
    /**
     * Hide this widget
     * @method
     * @memberof UpdateAppsView
     */
    hide: function () {
        Volt.log('[UpdateAppsView.js] hide');
        this.widget.hide();
        this.destroy(this.widget);
    },
})
exports = smartHubPopupView;