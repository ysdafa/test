var Backbone = Volt.require('lib/volt-backbone.js'),
    DimView = Volt.require("lib/views/dim-view.js"),
    LoadingPopup = Volt.require("lib/views/loading-popup.js"),

    EventMediator = Volt.require('app/common/eventMediator.js');

var OverlayView = Backbone.View.extend({
    initialize: function () {
        this.listenTo(EventMediator, 'EVENT_OVERLAY_SHOW_DIM', this.onShowDim);
        this.listenTo(EventMediator, 'EVENT_OVERLAY_HIDE_DIM', this.onHideDim);
        this.listenTo(EventMediator, 'EVENT_OVERLAY_SHOW_LOADING', this.onShowLoading);
        this.listenTo(EventMediator, 'EVENT_OVERLAY_HIDE_LOADING', this.onHideLoading);
    },

    //    show: function () {
    //
    //    },
    //
    //    hide: function () {
    //
    //    },

    onShowDim: function () {
        Volt.log('[overlay-view.js @onShowDim]');
        DimView.show();
    },

    onHideDim: function () {
        Volt.log('[overlay-view.js @onHideDim]');
        DimView.hide();
    },
    
    onShowLoading: function () {
        Volt.log('[overlay-view.js @onShowLoading]');
        LoadingPopup.show();
    },

    onHideLoading: function () {
        Volt.log('[overlay-view.js @onHideLoading]');
        LoadingPopup.hide();
    },

});

exports = new OverlayView();