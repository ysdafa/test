/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages categories list view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require("modules/VoltJSON.js");

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js'),
    CategoriesListTemplate = Volt.require('app/templates/1080/categoriesListTemplate.js'),
    GridListView = Volt.require('app/views/gridListView.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js'),
    voltapi = Volt.require('voltapi.js'),
    AppInfoProgressView = Volt.require("app/views/appInfoProgressView.js"),
    GridListTemplate = Volt.require('app/templates/grid-list-template.js');

var AppInfoVMCollection = Volt.require('app/models/appInfoVMCollection.js');

var PanelCommon = Volt.require('lib/volt-common.js'),
    Models = Volt.require('app/models/models.js'),
    localStorage = Volt.require("lib/volt-local-storage.js");
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var WinsetButton = Volt.require("WinsetUIElement/winsetButton.js");
var tvResoultion = (Volt.APPS720P) ? WinsetButton.ResoultionStyle.Resoultion_720 : WinsetButton.ResoultionStyle.Resoultion_1080;
var isRemainGridList = false,
    sortOption = ['releasedate', 'popularity', 'titleasc', 'titledesc'];

var CategoriesListView = Volt.BaseView.extend({
    /** @lends CategoriesListView.prototype */
    appInfoVMCollection: null,
    gridListView: null,
    template: CategoriesListTemplate.container,
    parameters: {},
    currentFetchedPage: 0,
    viewList: null,
    isShown: false,
    sortStandard: sortOption[0],
    noContentBtn:null,
    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * Initialize this view
     * @method
     */
    initialize: function () {
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
        this.listenTo(EventMediator, 'GRID_FOVEA_DISABLE', _.bind(this.removefoveaEffect, this));
        this.listenTo(EventMediator, 'GRID_FOVEA_ENABLE', _.bind(this.addfoveaEffect, this));
    },
    /**
     * set msgbox button click callback
     * @method  caoyr 11.15
     * @memberof categoriesListView
     */
    processMsgBoxEvent: function (data) {
        Volt.log('[categoriesListView] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
                Volt.log('[categoriesListView] processMsgBoxEvent: ok');
                Backbone.history.back();

                break;
            default:
                break;
            }
        } else if (data.eventType == CommonDefines.Event.SELECT_BTN2) {
            Volt.log('[detail-view.js] processMsgBoxEvent:SELECT_BTN2');
        }
    },
        /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (widget) {
            if (widget.id == ('categories-list-button-' + this.parameters.categoryId)) {
                    if(this.noContentBtn){
                         this.noContentBtn.setFocus();
                    }
            } 
        }
    },

    /**
     * When blured on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onBlur: function (widget) {
    },
    /**
     * Render once after view is created
     * @method
     */
    render: function (parentWidget, categoryId) {
        Volt.log('[CategoriesListView] render');
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_FOCUS_ZOOM, this.resetListImage);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_HIGH_CONTRAST, this.resetListImage);
        
        var contentContainer = parentWidget.widget.getChild('main-content-container');
        this.parameters = new Object();
        this.parameters = _.extend(this.parameters, {
            categoryId: categoryId,
            categoryTitle: '',
            param: {
                perPage: 60,
                sort: sortOption[0],
                page: '1'
            }
        });

        this.parameters.categoryId = categoryId;

        this.setWidget(Volt.loadTemplate(this.template, {
            type: this.parameters.categoryId
        }));
        contentContainer.addChild(this.widget);
        if (!this.appInfoVMCollection) {
            this.appInfoVMCollection = new AppInfoVMCollection();
            print("this.parameters.categoryId is " + this.parameters.categoryId);
            this.appInfoVMCollection.setCollection('categories', this.parameters.categoryId);
        }

    },
    createNocontentButton:function(){
       Volt.err('[CategoriesListView] createNocontentButton');
       if(this.noContentBtn){
            Volt.err('[CategoriesListView] this.noContentBtn is exist');
            return;
       }
       var btnStyle = {
                style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text,
                buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
                resoultion: tvResoultion,
       };
        var btnBG = this.widget.getDescendant('categories-list-button-' + this.parameters.categoryId);
        if(btnBG){
            Volt.err('[CategoriesListView] createNocontentButton');
            this.noContentBtn = Volt.loadTemplate(CategoriesListTemplate.troubelShootBtn, btnStyle);
            btnBG.addChild(this.noContentBtn);
            this.noContentBtn.setText({
                 state: "all",
                 text: Volt.i18n.t('TV_SID_TROUBLESHOOT'),
             });
        }
         btnBG.custom = {
                focusable: true
         };
         Volt.Nav.setNextItemRule(btnBG, 'right', btnBG);
         var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
         if(wzNoContent){
               wzNoContent.text =  Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>', 'AS000');
         }
         
         Volt.err('[CategoriesListView] createNocontentButton');
         var btnListener = this.btnListener = new ButtonListener();
         btnListener.onButtonClicked = function (button, type) {
               var aulApp = new Aul();
 	        aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
         }.bind(this);

         this.noContentBtn.addListener(btnListener);
         Volt.Nav.reload();
         Volt.Nav.focus(btnBG);
         
    },
     destroyNocontentButton:function(){
       Volt.err('[CategoriesListView] destroyNocontentButton');
       if(this.noContentBtn){
             var btnBG = this.widget.getDescendant('categories-list-button-' + this.parameters.categoryId);
             if(btnBG){
                   btnBG.custom = {
                          focusable: false
                   };
             }
             btnBG.removeChild(this.noContentBtn);
             this.noContentBtn.destroy();
             Volt.Nav.reload();
              var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
              if(wzNoContent){
                    wzNoContent.text =  "";
              }
             this.noContentBtn = null;
       }
    },
    /**
     * Render contents of this view.
     * @method
     * @param  {collection} collection Fetched data from server of categories app list.
     */
    renderContent: function (collection, options) {
        Volt.log('[CategoriesListView] renderContent');

        var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
        if (this.appInfoVMCollection.length > 0) {
            EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
            if (wzNoContent) {
                wzNoContent.text = '';
            }
            if (this.gridListView) {
                this.updateContent();
                return;
            }
            var gridListContainer = this.widget.getChild('categories-list-content-container-' + this.parameters.categoryId);

            CategoriesListTemplate.gridList.parent = gridListContainer;
            var grid = this.gridListView = this.initNativeGrid();

            gridListContainer.addChild(grid);
            grid.showWithAnimation();

            this.currentFetchedPage = this.appInfoVMCollection.collection.getPageInfo().page;

            Volt.Nav.setNextItemRule(grid, 'up', 'category-list-container');
            Volt.Nav.setNextItemRule(grid, 'left', grid);
            Volt.Nav.setNextItemRule(grid, 'right', grid);

            Volt.Nav.reload();
            //    Volt.Nav.focus(this.gridListView);
        } else {
            //if (wzNoContent && options.previousModels.length == 0) {
            if (wzNoContent && !this.gridListView) {
                EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
                wzNoContent.text = Volt.i18n.t('COM_NO_CONTENT_FOUND');
            }
        }
    },
    updateContent: function () {
        Volt.log("[CategoriesListView.js] updateContent this.gridListView.itemCount = " + this.gridListView.itemCount(0));
        Volt.log("[CategoriesListView.js] updateContent this.appInfoVMCollection.length = " + this.appInfoVMCollection.length);
        if (this.gridListView && this.gridListViewPtr) {
            if (this.appInfoVMCollection.length > 0) {
                for (var i = 0; i < this.appInfoVMCollection.length; i++) {

                    if (i >= this.gridListView.itemCount(0)) {
                        this.gridListViewPtr.addItem(this.appInfoVMCollection.at(i));
                    } else {
                        var data = this.gridListView.getData(0, i);
                        data.model = this.appInfoVMCollection.at(i);
                        Volt.log('update content:data.model.title ' + data.model.get('title'));
                    }
                }
            }
            this.gridListView.updateAllItems(0);
        }
    },
    /**
     * Render content each item by added to model.
     * @method
     * @param  {model} model Added model.
     */
    renderContentPerItem: function (model, collection) {
        Volt.log('[CategoriesListView] renderContentPerItem');
        this.currentFetchedPage = this.appInfoVMCollection.collection.getPageInfo().page;
        this.gridListViewPtr.addItem(model);
    },

    renderReturnButton: function () {
        var wzReturnButton = this.widget.find('.categories-list-header-returnicon-area'),
            wzTitle = this.widget.find('.categories-list-header-text'),
            nTitleX = 36;

        if (Volt.DeviceInfoModel.get('visibleCursor') == '1') {
            wzReturnButton[0].show();
            wzTitle[0].x = wzReturnButton[0].width + nTitleX;
        } else {
            wzReturnButton[0].hide();
            wzTitle[0].x = nTitleX;
        }
    },

    initNativeGrid: function () {
        var self = this;
        var wzGridView = null;
        // var gridListData = {
        //     style : CommonDefines.Const.HALO_ITEM_ALL_SAME,
        //     groups : [{
        //         modelArr : this.appInfoVMCollection
        //     }]
        // };

        this.viewList = new Array();

        this.gridListViewPtr = new GridListView({
            gridListControlParam: CategoriesListTemplate.gridList,
            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[CategoryListView @onDrawLoadData] index: ' + data._index);
                    var model = data.model;

                    var iCategoriesAppInfoView = new CategoriesAppInfoView(model);
                    iCategoriesAppInfoView.render(data._index, thumbnail);

                    self.viewList[data._index] = iCategoriesAppInfoView;
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.log('[CategoryListView @onDrawUpdateData] index: ' + data._index);
                    self.viewList[data._index].updateItemView(thumbnail, data);
                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[CategoryListView @onDrawUnloadData] index: ' + data._index);

                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }

                    //// @xiaojun.wang|20150120: Fix DF150119-00713
                    delete self.viewList[data._index];
                },
                onGridFocus: function (wzFocused) {
                    Volt.log('[CategoryListView] onGridFocus');

                    gc();

                    if (wzFocused) {
                        var voiceText = self.parameters.categoryTitle + ' ' +
                            Volt.i18n.t('SID_CATEGORY_KR_CA') + ',' +
                            Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', self.appInfoVMCollection.length) + ',' +
                            wzFocused.customTitle + ',' + Volt.i18n.t('TV_SID_VOICE_GUIDE_NOT_AVAIIL_ALL_APPS');

                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.log('[CategoryListView] onGridBlur');

                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo, fromItemIndex, toItemIndex) {
                    Volt.log('[CategoryListView] onFocusChanged wzFrom is ' + fromItemIndex + ',wzTo is ' + toItemIndex);
                    if (wzTo) {
                        CommonFunctions.voiceGuide(wzTo.customTitle);
                    }
                    //add by pei828.yang 20141206 If total items is bigger than 60 and move to last item, need to request next more 60 items & add them to gridlist.
                    if (self.appInfoVMCollection.length >= 10) {
                        if (toItemIndex >= (self.appInfoVMCollection.length - 10)) {
                            Volt.log('[CategoryListView] self.appInfoVMCollection.length = ' + self.appInfoVMCollection.length);
                            Volt.log('[CategoryListView] self.appInfoVMCollection.collection.getPageInfo().total = ' + self.appInfoVMCollection.collection.getPageInfo().total);
                            if (self.appInfoVMCollection.length < self.appInfoVMCollection.collection.getPageInfo().total) {
                                self.parameters.param.page = (parseInt(self.currentFetchedPage) + 1).toString();
                                Volt.log('[CategoryListView] this.parameters.param.page is ' + self.parameters.param.page);
                                Volt.log('[CategoryListView] self.appInfoVMCollection.collection.getPageInfo().lastPage is ' + self.appInfoVMCollection.collection.getPageInfo().lastPage);
                                if (parseInt(self.parameters.param.page) <= parseInt(self.appInfoVMCollection.collection.getPageInfo().lastPage)) {
                                    self.appInfoVMCollection.setDefaultParameters(self.parameters);
                                    self.appInfoVMCollection.fetch(false);
                                }
                            }
                        }
                    }
                },
                onItemPress: function (wz, itemData, data) {
                    Volt.log('[CategoryListView] onItemPress');

                    self.SelectItem(itemData.itemIndex, data.model);
                },
                onEnterKeyLongPressed: function (wzFocused, itemIndex, type) {
                    if (wzFocused && itemIndex != -1) {
                        if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                            return;
                        }
                        var vmSelected = self.appInfoVMCollection.collection.at(itemIndex),
                            iSelectedContext = self.viewList[itemIndex];

                        var param = {
                            baseWidget: wzFocused,
                            appInfoVM: vmSelected,
                            parentView: iSelectedContext,
                            type: iSelectedContext.type,
                            feature: iSelectedContext.feature
                        }
                        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU, param);
                        if (type == 'mouse') {
                            EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_RELEASE);
                        }

                        Volt.KpiMapper.addEventLog('LONGPRESSSC');
                    }
                }
            }
        });

        wzGridView = this.gridListViewPtr.render(this.appInfoVMCollection).widget;
        wzGridView.custom = {
            focusable: true
        };
        return wzGridView;
    },


    /**
     * When user select the app info, this function will triggered.
     * @method
     * @param  {int} index Triggered item index
     */
    SelectItem: function (index, model) {
        Volt.log('[CategoriesListView] CategoriesAppInfoView :: onSelect : ' + index);
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
            return;
        }
        isRemainGridList = true;


        var sCategoryId = this.appInfoVMCollection.categoryId || this.appInfoVMCollection.collection.categoryId,
            nRemain = sCategoryId % 11,
            sCategoryName = '';

        Volt.log('[CategoriesListView] SelectItem :: nRemain : ' + nRemain);

        switch (nRemain) {
        case 5:
            sCategoryName = 'VIDEO';
            break;
        case 6:
            sCategoryName = 'SPORT';
            break;
        case 7:
            sCategoryName = 'GAME';
            break;
        case 8:
            sCategoryName = 'LIFESTYLE';
            break;
        case 9:
            sCategoryName = 'INFORMATION';
            break;
        case 10:
            sCategoryName = 'EDUCATION';
            break;
        case 0:
            sCategoryName = 'KIDS';
            break;

        default:
            sCategoryName = 'ALL';
            break;
        }

        Backbone.history.navigate('detail/' + model.get('id'), {
            trigger: true
        });


        Volt.KpiMapper.addEventLog('SELECTSC', {
            d: {
                cn: sCategoryName,
                appid: model.get('id'),
                pn: model.get('order')
            }
        });
    },



    removeGrid: function () {
        Volt.log('[CategoriesListView] remove grid list');

        if (this.gridListView) {
            this.gridListView = null;
        }
    },

    /**
     * Show this view.
     * @method
     * @param  {object} param Parameters
     * @param  {enum} animationType Animation type to showing this view.
     * @return {deferred} Deferred promise return.
     */
    show: function (param, animationType) {
        Volt.log('[CategoriesListView] show');

        // this.listenTo(EventMediator, 'VOLT_PAUSE', this.pause);
        // this.listenTo(EventMediator, 'VOLT_HIDE', this.pause);
        //this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.dim);
        this.listenTo(EventMediator, 'SORT_GRID_LIST', this.onSortGridList);

        this.isShown = true;

        var self = this;
        var deferred = Q.defer();

        isRemainGridList = false;
        this.parameters.categoryId = param.id;
        this.parameters.categoryTitle = param.title;

        if (this.gridListView && this.sortStandard == sortOption[localStorage.getItem('sortOption')]) { // to be changed :: 
            this.widget.show();
            EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);

            if (this.gridListView) {
                this.gridListView.showWithAnimation();
                this.gridListView.custom = {
                    focusable: true
                };
                for (var i in this.viewList) {
                    this.viewList[i].showProgressBar();
                }
            }

            Volt.Nav.reload();

            if (this.gridListView) {
                var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
                var isDetail = (/#detail/g).test(previousHistory);

                if (isDetail) {
                    Volt.Nav.focus(this.gridListView);
                } else {
                    this.gridListView.setFocusItemIndex(0, 0);
                }
            }

        } else {
            if (Volt.DeviceInfoModel.get('networksStatus') == 'OK') {

                if (this.gridListView) {
                    for (var i in this.viewList) {
                        this.viewList[i].hideProgressBar();
                    }
                    this.gridListView = null;
                }

                this.sortStandard = sortOption[localStorage.getItem('sortOption')];
                this.parameters.param.sort = this.sortStandard; // to be changed :: sortOption[index];
                this.appInfoVMCollection.setDefaultParameters(this.parameters);

                EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);

                if (Volt.DeviceInfoModel.get('networksStatus') == "OK") {
                    this.destroyNocontentButton();
                    Q.all([
                           this.appInfoVMCollection.fetch(true)
                       ])
                        .then(_.bind(function () {
                            deferred.resolve();
                        }, this))
                        .fail(_.bind(function () {
                            EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
                            deferred.reject();
                        }, this));
                } else {
                    EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
                    CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                }
            } else {
                 //CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                 this.createNocontentButton();
            }
            this.widget.show();
        }

        // Listen to model
        if (this.appInfoVMCollection) {
            this.listenTo(this.appInfoVMCollection, 'reset', this.renderContent);
            this.listenTo(this.appInfoVMCollection, 'add', this.renderContentPerItem);
            this.listenTo(this.appInfoVMCollection, 'error', this.showErrorPopup);
            this.appInfoVMCollection.startListeningEvent();
        }


        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS, this.onFocusGrid);

        return deferred.promise;
    },
    removefoveaEffect: function () {
        this.gridListView.foveaEffect = false;

    },
    addfoveaEffect: function () {
        this.gridListView.foveaEffect = true;
    },
    /**
     * hide this view.
     * @method
     * @param  {enum} animationType Animation type to hiding this view.
     * @return {deferred} Deferred promise return.
     */
    hide: function (animationType) {
        Volt.log('[CategoriesListView] hide');
        var deferred = Q.defer();
        deferred.resolve();

        // this.renderTotalCount(true);
        this.isShown = false;
        this.widget.hide();
        this.destroyNocontentButton();
        if (!isRemainGridList) {
            // force to deactive auto scroll widget
            if (this.gridListView) {
                this.gridListView.hideWithAnimation("autoDestroy");
                this.gridListView.custom.focusable = false;

                if (this.appInfoVMCollection) {
                    this.stopListening(this.appInfoVMCollection);
                    this.appInfoVMCollection.stopListeningEvent();
                }

                for (var i in this.viewList) {
                    this.viewList[i].hideProgressBar();
                }
            }

            //  this.initParameters();
        }

        this.stopListening(EventMediator, 'SORT_GRID_LIST');
        this.stopListening(EventMediator, 'VOLT_DEACTIVATE');
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS);
        
        return deferred.promise;
    },

    showLoading: function () {
        EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);
    },

    /**
     * Pause this view.
     * @method
     */
    pause: function () {
        Volt.log('[CategoriesListView] pause');

        /*if (this.loading) {
            this.hideLoading();
        }*/
        if (this.isShown) {
            EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);

            //this.widget.hide();
            // this.listenTo(EventMediator, 'VOLT_RESUME', this.resume);
        }
    },

    /**
     * Resume this view.
     * @method
     */
    resume: function () {
        Volt.log('[CategoriesListView] resume');
        if (this.isShown) {
            this.widget.show();
            // this.stopListening(EventMediator, 'VOLT_RESUME');
        }
    },


    /**
     * Callback function of plus button select.
     * @method
     * @param  {int} index    Selected index of menu
     * @param  {int} subIndex Selected index of sub menu
     */
    onSortGridList: function (index) {
        Volt.log('[CategoriesListView] onSortGridList');
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
            return;
        }
        var deferred = Q.defer(),
            optionMenu = parseInt(index, 10);

        this.sortStandard = sortOption[optionMenu];

        if (index == -1) return;

        this.parameters.param.page = '1,2';

        // force to deactive auto scroll widget
        if (this.gridListView) {
            for (var i in this.viewList) {
                this.viewList[i].hideProgressBar();
            }
        }

        var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
        wzNoContent.text = '';

        //this.gridListView = null;

        this.parameters.param.sort = this.sortStandard;
        this.appInfoVMCollection.setDefaultParameters(this.parameters);

        EventMediator.trigger(CommonDefines.Event.EVENT_HOME_SHOW_LOADING);

        Q.all([
            this.appInfoVMCollection.fetch(true)
        ])
            .then(_.bind(function () {
                deferred.resolve();
            }, this))
            .fail(_.bind(function () {
                EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
                deferred.reject();
            }, this));

        Volt.KpiMapper.addEventLog('SELECTOPTION', {
            d: {
                //con: this.sortStandard //EV005 : {cp=N01_NEW;sappid=org.volt.apps;sappver=1412}
            }
        });
        deferred.resolve();
        return deferred.promise;
    },

    showErrorPopup: function (serverError) {

        this.renderContent();

        //EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);

        //        if (serverError.code == 'AS666') {
        //            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        //        } else {
        //            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE, serverError);
        //        }

        return;
    },

    initParameters: function () {
        this.parameters.param.perPage = 30;
        // no need to init sort option.
        // this.parameters.param.sort = sortOption[0];
        this.parameters.param.page = '1';
        this.currentFetchedPage = 0;
    },

    resetListImage: function(){
        Volt.log('[categoriesListView.js @resetListImage]');
        if(Volt.DeviceInfoModel.get('highContrast')){
            if(this.gridListView){
                this.gridListView.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/acc_focus.png'), -4, -4);
            }
        }
        else{
            if(this.gridListView){
                this.gridListView.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -4, -4);
            }
        }
    },


    onFocusGrid:function(){
        Volt.log('[featuredListView.js @onFocusGrid]');
        if ( this.gridListViewPtr.widget ){
            Volt.Nav.focus(this.gridListViewPtr.widget);
        }

    }

});

var CategoriesAppInfoView = Volt.BaseView.extend({
    /** @lends CategoriesAppInfoView.prototype */
    thumbnail: null,
    thumbListener: null, // Thumbnail Listener for color pick

    AppInfoProgressView: null,
    /**
     * Initialize CategoriesInfoView
     * @method
     * @param  {model} viewModel CategoriesInfoView view model
     */
    initialize: function (viewModel) {
        this.VM = viewModel;
        this.listenTo(this.VM, 'change', this.renderChange);
    },

    bindListener: function () {
        this.listenTo(this.VM, 'change', this.renderChange);
        this.listenTo(this.VM, 'DESTROY_VIEW', this.remove);
        this.showProgressBar();
    },

    unbindListener: function () {
        this.stopListening();
        this.hideProgressBar();
    },

    /**
     * Render this view
     * @method
     * @param  {int} index  Index of CategoriesInfoView
     * @param  {widget} widget Widget of CategoriesInfoView
     */
    render: function (index, iThumbnail) {
        var data = this.VM.toJSON();

        if (iThumbnail) {
            this.thumbnail = iThumbnail;
            var icon = data.icon ? data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT) : '';
            var screenshot = data.screenshot ? data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT) : '';
            var oThumbnailStyle = _.clone(CategoriesListTemplate.thumbnailStyle);

            if (screenshot) {
                oThumbnailStyle.image.src = screenshot;
                this.useDefaultImage = false;
            } else {
                oThumbnailStyle.image.src = Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png');
                this.useDefaultImage = true;
            }
            oThumbnailStyle.information.icon2.src = icon;
            oThumbnailStyle.information.text1.text = data.title ? data.title : '';
            oThumbnailStyle.information.text2.text = data.updated ? data.updated.split('T')[0] : '';
            oThumbnailStyle.information.text3.text = data.fileSize ? this.convertByte(data.fileSize) : '';

            var self = this;

            this.thumbListener = new ThumbnailListener;
            this.thumbListener.onImageReady = function (thumbnail, id, success) {
                if (success) {
                    if (self.useDefaultImage) {
                        /*
                        thumbnail.setInformationColor = {
                            r: 0x46,
                            g: 0x55,
                            b: 0x63,
                            a: 255
                        };
                        */
                    }
                } else {
                    thumbnail.timeId = Volt.setTimeout(function () {
                        thumbnail.setContentImage(GridListTemplate.defaultScreenShot);
                        self.useDefaultImage = true;
                        thumbnail.timeId = null;
                    }, 0);
                }
            }
            this.thumbnail.setThumbnailStyle(oThumbnailStyle);
            this.thumbnail.addThumbnailListener(this.thumbListener);
            this.thumbnail.setDimBackgroundColor({
                r: 0,
                g: 0,
                b: 0,
                a: 153
            });
            this.thumbnail.dim(false);
            this.thumbnail.visualizeInformationIcon(false, 'icon1');

            this.thumbnail.setProgressRange(0, 100);
            this.setWidget(this.thumbnail);
            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
            this.thumbnail.customSupportVoice = data.is_support_voice;
            this.setDownloadIcon(this.VM.get('isDownloaded'));
            this.bindListener();
        }
    },

    remove: function () {
        if (this.thumbnail) {
            this.thumbnail.removeThumbnailListener(this.thumbListener);
            this.unbindListener();

            if (this.thumbnail.timeId) {
                Volt.clearTimeout(this.thumbnail.timeId);
                this.thumbnail.timeId = null;
            }

            this.thumbnail = null;
            this.thumbListener = null;
        }
    },

    updateItemView: function (Thumbnail, data) {
        Volt.err('CategoriesAppInfoView updateItemView : ');
        this.VM = data.model;
        var data = this.VM.toJSON();
        if (Thumbnail) {
            this.thumbnail = Thumbnail;
            var icon = data.icon ? data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT) : '';
            var screenshot = data.screenshot ? data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT) : '';
            print('icon is ' + icon);
            print('screenshot is ' + screenshot);
            if (screenshot) {
                this.thumbnail.setContentImage(screenshot);
                this.useDefaultImage = false;
            } else {
                this.thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                this.useDefaultImage = true;
            }
            this.thumbnail.setInformationIcon("icon2", icon);
            this.thumbnail.setInformationText("text1", data.title ? data.title : '');
            this.thumbnail.setInformationText("text2", data.updated ? data.updated.split('T')[0] : '');
            this.thumbnail.setInformationText("text3", data.fileSize ? this.convertByte(data.fileSize) : '');
            this.thumbnail.visualizeInformationIcon(false, 'icon1');
            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
            this.thumbnail.customSupportVoice = data.is_support_voice;
            this.setDownloadIcon(this.VM.get('isDownloaded'));
        }
        this.resetProgressBar();
    },
    /**
     * convert bytes mark
     * @method
     * @param  {number} value app size
     * @return {string}       converted size
     */
    convertByte: function (value) {

        if (value >= 1048576) {
            return parseFloat(value / 1048576).toFixed(2) + " " + Volt.i18n.t('SID_MB');
        } else if (value >= 1024) {
            return parseInt(value / 1024) + " " + Volt.i18n.t('SID_KB');
        } else {
            return parseInt(value) + " " + Volt.i18n.t('SID_BYTE');
        }
    },
    /**
     * Render changed model.
     * @method
     * @param {model} changedModel Changed model.
     */
    renderChange: function (changedModel) {

        if (_.keys(changedModel.changed)[0]) {
            switch (_.keys(changedModel.changed)[0]) {
            case 'isDownloaded':
                if (_.values(changedModel.changed)[0]) {
                    if (this.thumbnail) {
                        this.thumbnail.visualizeInformationIcon(true, 'icon1');
                    }

                } else {
                    if (this.thumbnail) {
                        this.thumbnail.visualizeInformationIcon(false, 'icon1');
                    }
                }
                break;
            }
        }
    },

    setDownloadIcon: function (bDownloaded) {
        if (bDownloaded) {
            if (this.thumbnail) {
                this.thumbnail.visualizeInformationIcon(true, 'icon1');
            }
        } else {
            if (this.thumbnail) {
                this.thumbnail.visualizeInformationIcon(false, 'icon1');
            }
        }
    },

    /**
     * Event delegation
     * @type {Object}
     */
    events: {
        //'NAV_SELECT' : 'onSelect',
        'NAV_BLUR': 'onBlur',
        'NAV_FOCUS': 'onFocus'
    },

    /**
     * Call when it is blurred
     * @method
     */
    onBlur: function () {

    },

    /**
     * Call when it is focused
     * @method
     */
    onFocus: function () {

    },




    /**
     * install
     * @method
     */
    installApp: function () {
        Volt.log('[CategoriesListView] CategoriesAppInfoView :: Install App : ' + this.VM.get('id'));

        if (!this.AppInfoProgressView) {
            this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }
        this.AppInfoProgressView.installApp();
    },

    cancelInstallApp: function () {
        Volt.log('[CategoriesListView] CategoriesAppInfoView :: cancelInstall App : ' + this.VM.get('id'));

        if (!this.AppInfoProgressView) {
            this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }

        this.AppInfoProgressView.cancelInstallApp();
    },

    /**
     * show view
     * @method
     */
    showProgressBar: function () {
        if (!this.AppInfoProgressView) {
            this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }
        this.AppInfoProgressView.updateThumbnail(this.thumbnail);
        this.AppInfoProgressView.show();
    },

    /**
     * hide view
     * @method
     */
    hideProgressBar: function () {
        if (this.AppInfoProgressView) {
            this.AppInfoProgressView.hideProgressBar();
        }
    },

    resetProgressBar: function () {
        if (!this.AppInfoProgressView) {
            this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        } else {
            this.AppInfoProgressView.resetProgressBar(this.thumbnail, this.VM);
        }
        this.AppInfoProgressView.show();
    }
});

exports = CategoriesListView;




/*

            /*var iconUrl = '';

            if( data.icon && data.icon.lastIndexOf ){
                if ( data.icon.lastIndexOf('png') != -1) {  
                    iconUrl = data.icon ? data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT) : '';
                } else if (data.icon.lastIndexOf('jpg') != -1) { 
                    iconUrl = data.icon ? data.icon.replace("{w}", CommonDefines.ImageSize.JPG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.JPG_ICON_HEIGHT) : '';
                }
            }

            var oThumbnailStyle = _.clone(CategoriesListTemplate.thumbnailStyle);
            oThumbnailStyle.image.src  = iconUrl;
            oThumbnailStyle.information.text1.text = data.title ? data.title : '';

            var thumbListener = new ThumbnailListener;
            thumbListener.onImageReady = function (thumbnail, id, success) {
                Volt.setTimeout(function(){
                    var informationColorpick = thumbnail.getInformationColorPicking();
                    thumbnail.color = {
                        r : informationColorpick.r,
                        g : informationColorpick.g,
                        b : informationColorpick.b,
                        a : 255
                    };
                }, 0);
            }

            this.thumbnail.setThumbnailStyle(oThumbnailStyle);
            this.thumbnail.addThumbnailListener(thumbListener);

            var dimWin = new DimWindow({
                parent: this.thumbnail, 
                x:     oThumbnailStyle.information.x, 
                y:     oThumbnailStyle.information.y, 
                width: oThumbnailStyle.information.width, 
                height:oThumbnailStyle.information.height, 
                color: {r:0, g:0, b:0, a: 20.4}
            });

            this.thumbnail.setDimBackgroundColor({r:0, g:0, b:0, a:153});
            this.thumbnail.dim(false);

            this.thumbnail.setProgressRange(0, 100);
            this.thumbnail.visualizeInformationIcon(false, 'icon1');
            this.setWidget(this.thumbnail);

            this.thumbnail.customTitle = data.title || '';
            //this.thumbnail.setTTSText({text: data.title || ''});
            this.setDownloadIcon(this.VM.get('isDownloaded'));

            this.bindListener();*/
