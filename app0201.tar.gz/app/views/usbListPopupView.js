/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module show connected usb list in tv.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('modules/backbone.js');
var VoltJSON = Volt.require('modules/VoltJSON.js');

// Include Template
var Template = Volt.require('app/templates/1080/usbListPopupTemplate.js');

// Include Event Mediator
var EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js');

// Include External Stroage Collection
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
// var ExternalStorageModel = Volt.require("app/models/externalStorageModel.js");
var Models = Volt.require("app/models/models.js");
var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var PanelCommon = Volt.require('lib/panel-common.js');

var Singlelist = Volt.require('app/views/singlelineListView.js');
PanelCommon.mapWidget('Singlelist', Singlelist);
var WinsetButton = Volt.require("WinsetUIElement/winsetButton.js");
PanelCommon.mapWidget('WinsetButton', WinsetButton);
var dataPointers = [];
/**
 * @name USBListPopupView
 */
var USBListPopupView = Volt.BaseView.extend({
    /** @lends USBListPopupView.prototype */
    template: Template.container,
    selectedUSBView: null,
    usbListView: null,

    /**
     * Initialize USBListPopupView
     * @name USBListPopupView
     * @constructs
     */
    initialize: function () {
        Volt.log("[USBListPopupView.js] initialize");
    },

    /**
     * Render this widget
     * @method
     * @memberof USBListPopupView
     */
    render: function () {
        Volt.log("[USBListPopupView.js] render");
    },

    /**
     * Show this widget, fetch usbListm and bind event
     * @method
     * @memberof USBListPopupView
     */
    show: function (viewInfo) {
        Volt.log("[USBListPopupView.js] show(), viewInfo: " + viewInfo);
        Models.externalStorageModel.set("usbList", []);
        this.setWidget(Volt.loadTemplate(this.template));
        Volt.Nav.setRoot(this.widget);
        this.widget.show();
        Models.externalStorageModel.updateUSBList();
        this.renderUSBListPopup(viewInfo);
        // Volt.Nav.bindListener( this.widget, 'keydown', _.bind(this.onKeyDown,this) );      
    },

    /**
     * Render usbList popup
     * @method
     * @memberof USBListPopupView
     */
    renderUSBListPopup: function (viewInfo) {
        Volt.log('[USBListPopupView.js] renderUSBListPopup');

        if (Models.externalStorageModel.get('usbList').length > 0) {
            this.renderTitle();
            this.renderLine();
            this.renderSelectedUSB();
            this.renderButton();
            /*
            var appID = '';
            if( viewInfo && viewInfo.appid ){
                appID = viewInfo.appid;
            }
    */
            this.renderUSBList(viewInfo);

            var showArrow = false;
            if ( Models.externalStorageModel.get('usbList').length > 5 )
                showArrow = true;

            this.setArrow(showArrow );
        }
    },

    /**
     * create titleView for rendering title
     * @method
     * @memberof USBListPopupView
     */
    renderTitle: function () {
        Volt.log('[USBListPopupView.js] renderTitle');
        var container = this.widget.getChild(0).getChild('usbList-title-container');
        container.addChild(Volt.loadTemplate(Template.title));
    },

    /**
     * create lineView for rendering line
     * @method
     * @memberof USBListPopupView
     */
    renderLine: function () {
        Volt.log('[USBListPopupView.js] renderLine');
        var container = this.widget.getChild(0).getChild('usbList-line-container');
        container.addChild(Volt.loadTemplate(Template.line));
    },

    /**
     * create selectedUSBView for rendering selected usb info
     * @method
     * @memberof USBListPopupView
     */
    renderSelectedUSB: function () {
        Volt.log('[USBListPopupView.js] renderSelectedDevice');
        var container = this.widget.getChild(0).getChild('usbList-selectedUSBInfo-container');
        this.selectedUSBView = new SelectedUSBView();
        container.addChild(this.selectedUSBView.render().widget);
    },

    /**
     * create usbListView for rendering selected usb info
     * @method
     * @memberof USBListPopupView
     */
    renderUSBList: function (appID) {
        Volt.log('[USBListPopupView.js] renderUSBList');
        var container = this.widget.getChild(0).getChild('usbList-list-container');
        this.usbListView = new USBListView(appID);
        container.addChild(this.usbListView.render(container).widget);
        Volt.Nav.focus(this.usbListView.usbList);
        Volt.Nav.setNextItemRule(this.widget.getDescendant('usbList-button-container'), 'left', this.usbListView.usbList);
    },
    /*
    updateUSBList : function(){ 
        if( this.usbListView ){
            this.usbListView.destroy();
            Models.externalStorageModel.updateUSBList();
            this.renderUSBList();
        }
    },
    */

    /**
     * create buttonView for rendering cancel button
     * @method
     * @memberof USBListPopupView
     */
    renderButton: function () {
        Volt.log('[USBListPopupView.js] renderButton');
        var container = this.widget.getChild(0).getChild('usbList-button-container');
        this.cancelButtonView = new ButtonView();
        this.cancelButtonView.render(container);
    },

    setArrow: function (flag) {
        if (flag == true) {
            Volt.log("[USBListPopupView.js]setArrow%%%%%%%%%  true  %%%%%");

            this.widget.getDescendant('arrow_up').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png');
            this.widget.getDescendant('arrow_down').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png');
        } else {
            this.widget.getDescendant('arrow_up').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_d.png');
            this.widget.getDescendant('arrow_down').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_d.png');
        }

        if ( flag ){
            var mouseListener = new MouseListener;

            mouseListener.onMousePointerIn = function (actor, event) {
                if (actor.id == 'arrow_down' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png');
                }
                if (actor.id == 'arrow_up' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png');
                }
            };
            mouseListener.onMousePointerOut = function (actor, event) {
                if (actor.id == 'arrow_down' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png');
                }
                if (actor.id == 'arrow_up' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png');
                }
            };
            mouseListener.onMouseButtonReleased = function (actor, event) {
                print('onMouseButtonReleased');
                if (actor.id == 'arrow_up') {
                    this.usbListView.usbList.moveFocus('Up');
                } else {
                    this.usbListView.usbList.moveFocus('Down');
                }
            }.bind(this);

            this.widget.getDescendant('arrow_up').addMouseListener(mouseListener);
    		this.widget.getDescendant('arrow_down').addMouseListener(mouseListener);
        }
	},


    /**
     * Hide this widget
     * @method
     * @memberof USBListPopupView
     */
    hide: function () {
        Volt.log('[USBListPopupView.js] hide');
        this.stopListening(Models.externalStorageModel);
        this.widget.hide();
        if (this.usbListView) {
            this.usbListView.stopListening();
        }
        this.destroy(this.widget);
    },

    /**
     * Destory this widget
     * @method
     * @memberof USBListPopupView
     */
    destroy: function (widget) {
        Volt.log('[USBListPopupView.js] destroy');

        if (!widget) return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = 0; i < nChildLength; i++) {
                this.destroy(widget.getChild(i));
            }
        }
        widget.id = '';
        delete widget;
        widget = null;
        dataPointers = [];
    }

});
/**
 * @name SelectedUSBView
 */
var SelectedUSBView = Volt.BaseView.extend({
    /** @lends SelectedUSBView.prototype */
    template: Template.usbItem,

    /**
     * Initialize selectedUSBView
     * @name SelectedUSBView
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, 'EVENT_UPDATE_SELECTED_USB', this.updateInfo);
    },

    /**
     * Render line of usbList popup
     * @method
     * @memberof SelectedUSBView
     * @param object    container   parent widget
     */
    render: function (container) {
        this.setWidget(Volt.loadTemplate(this.template));
        this.usbName = this.widget.getChild("usbList-usb-name");
        this.usbStorage = this.widget.getChild("usbList-usb-storage");
        this.updateInfo({
            name: Models.externalStorageModel.get('usbList')[0].name,
            availableSize: convertMemory(Models.externalStorageModel.get('usbList')[0].availableSize),
            totalSize: convertMemory(Models.externalStorageModel.get('usbList')[0].totalSize)
        });
        return this;
    },

    /**
     * Update focued usb information
     * @method
     * @memberof SelectedUSBView
     * @param {number}    idx   focused index number of list
     */
    updateInfo: function (param) {
        Volt.log('[USBListPopupView.js]  param.name + ' + param.name);
        this.usbName.text = param.name;
        this.usbStorage.text = param.availableSize + '/' + param.totalSize;
    },
});

/**
 * @namespace USBListPopupView
 * @name ButtonView
 */
var ButtonView = Volt.BaseView.extend({
    /** @lends ButtonView.prototype */
    template: Template.button,
    btnListener: new ButtonListener(),

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * Initialize ButtonView
     * @name ButtonView
     * @constructs
     */
    initialize: function () {},

    /**
     * Render button
     * @method
     * @memberof ButtonView
     */
    render: function (Parent) {
        var btnStyle = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resoultion: (Volt.APPS720P) ? WinsetButton.ResoultionStyle.Resoultion_720 : WinsetButton.ResoultionStyle.Resoultion_1080,
        }
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);
        this.cancelButton = PanelCommon.loadTemplate(this.template, btnStyle, Parent);
        this.cancelButton.addListener(this.btnListener);
        this.setWidget(Parent);
        return this;
    },

    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onSelect: function (widget) {
        if (widget) {
            // EventMediator.trigger(CommonDefines.Event.CONNECT_USB);
            //widget.border  = {
            //    width : 2 , color :  Volt.hexToRgb('#ffffff', 95)
            //}; 
            Backbone.history.back();
        }
    },

    /**
     * When focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (widget && widget.id == 'usbList-button-container') {
            this.cancelButton.setFocus();
            CommonFunctions.voiceGuide(this.cancelButton.text() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON'));
        }
    },

    /**
     * When blured focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param   {object}  widget  blured widget
     */
    onBlur: function (widget) {
        if (widget && widget.id == 'usbList-button-container') {
            this.cancelButton.killFocus();
        }
    }
});

/**
 * @name USBListView
 */
var USBListView = Volt.BaseView.extend({
    /** @lends USBListView.prototype */
    usbList: null,
    appID: '',
    /**
     * Initialize USBListView
     * @name USBListView
     * @constructs
     */
    initialize: function (appInfo) {
        this.listenTo(EventMediator, CommonDefines.Event.CONNECT_USB, this.updateUSBList);
        this.listenTo(EventMediator, CommonDefines.Event.DISCONNECT_USB, this.updateUSBList);
        this.appID = appInfo ? appInfo.appid : '';
    },

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    onFocus: function (widget) {
        Volt.log("USBListView onFocus");
        if (widget) {
            this.usbList.enableFocus();
            this.usbList.setFocus();
            this.usbList.showFocus("true");
        }
    },

    onBlur: function (widget) {
        Volt.log("USBListView onBlur");
        if (widget) {
            this.usbList.hideFocus("true");
            this.usbList.killFocus();
        }
    },
    /**
     * Render usbList to use ContextMenu
     * @method
     * @memberof USBListView
     * @param  {object}  widget  focued widget
     */
    render: function (parent) {
        Volt.log('[USBListView] render');

        this.usbList = initList(parent);
        this.usbList.appID = this.appID;
        this.setWidget(this.usbList);
        parent.addChild(this.usbList);
        Volt.Nav.reload();
        return this;
    },

    destroy: function () {
        if (this.usbList) {
            this.usbList.destroy();
        }
    },

    updateUSBList: function () {
        Volt.log('[USBListView] updateUSBList');
        if (this.usbList) {
            var result = Models.externalStorageModel.updateUSBList();
            if (result && result.storages) {
                var nList = result.storages.length;

                if (nList == 0) {
                    Volt.log('[USBListView] Backbone.history.back');
                    this.stopListening();
                    Backbone.history.back();
                } else {
                    Volt.log('[USBListView111] focusIndex : ' + this.usbList.focusItemIndex);
                    Volt.log('[USBListView] deleteItem count : ' + this.usbList.numOfItem());
                    this.usbList.deleteItem({
                        fromItem: 0,
                        itemNum: this.usbList.numOfItem()
                    });

                    Volt.log('[USBListView] addItem count : ' + result.storages.length);
                    this.usbList.addItem({
                        itemNum: result.storages.length,
                        itemSpace: Volt.height * 0.066667
                    });
                    for (var i = 0; i < nList; i++) {
                        var data = new Data();
                        data.name = result.storages[i].name;
                        data.mountPath = result.storages[i].mountPath;
                        data.fileSystem = result.storages[i].fileSystem;
                        data.availableSize = convertMemory(result.storages[i].availableSize);
                        data.totalSize = convertMemory(result.storages[i].totalSize);
                        // Avoid garbage collecting Halo Data instances
                        dataPointers.push(data);
                        this.usbList.addData(data);
                    }
                    this.usbList.loadData();
                    this.usbList.focusItemIndex = 0;
                    var params = {
                        name: result.storages[0].name,
                        availableSize: convertMemory(result.storages[0].availableSize),
                        totalSize: convertMemory(result.storages[0].totalSize),
                        fileSystem: result.storages[0].fileSystem
                    }
                    CommonFunctions.voiceGuide(params.name + ',' + params.totalSize + ',' + params.fileSystem);
                    EventMediator.trigger('EVENT_UPDATE_SELECTED_USB', params);
                }
            }
        }
    },
});

function convertMemory(memory) {
    if (memory) {
        return parseFloat(memory / 1048576).toFixed(2) + "GB";
    } else {
        return 0;
    }
};

function initList(parent) {
    var bFirstEnter = true;
    var list = PanelCommon.loadTemplate(Template.list, null, parent).render().widget;
    list.custom = {};
    list.custom.focusable = true;

    Volt.Nav.setNextItemRule(list, 'up', list);
    Volt.Nav.setNextItemRule(list, 'down', list);

    var storages = Models.externalStorageModel.get('usbList');

    Volt.log('storages.length - ' + storages.length);
    list.addItem({
        itemNum: storages.length ,
        itemSpace: Volt.height * 0.066667
    });

    list.setBackgroundColor(0, 0, 0, 0);
    list.enlargeFocusedItem(10, 0);
    list.shadowEffectFlag = false;
    list.setAnimationDuration("focusMove", 100);
    list.setAnimationDuration("loop", 100);
    list.foveaEffect = false;
    list.useMarginWhenFocusEdgeItem = false;
    list.show();

    list.initRenderer = function (renderer, data, parentWidth, parentHeight) {
        Volt.log('data - ' + JSON.stringify(data));
        var device = PanelCommon.loadTemplate(Template.deviceList, null, renderer.root);
        renderer.thumbnail = renderer.root.getChild(0);
        
        
        renderer.thumbnail.setInformationText("text1", data.name);
		//var versionInfo = 'v'+ data.app_version + '  ' + convertDateFormat(data.updated_date);
		renderer.thumbnail.setInformationText("text2", data.totalSize + " " + data.fileSystem);
        

        renderer.thumbnail.onFocus = function () {
            //Volt.log('onFocus    HALOUtil.highContrast -     ' + HALOUtil.highContrast);
            if ( HALOUtil.highContrast == false ){
                device.color = Volt.hexToRgb('#ffffff', 100);
        		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_f.png");

        		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.focused);
        		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.focused);
            }

            
        };
        renderer.thumbnail.onNormal = function () {
            //Volt.log('onNormal    HALOUtil.highContrast -     ' + HALOUtil.highContrast);
            device.color = Volt.hexToRgb('#ffffff', 0);
            if ( HALOUtil.highContrast == false ){

    		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_n.png");
    		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.normal);
    		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.normal);
            }
        };
        renderer.thumbnail.onSelect = function () {
		device.color = Volt.hexToRgb('#ffffff', 100);

		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_f.png");
		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.selected);
		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.selected);


            
        };
        renderer.thumbnail.onDim = function () {
		device.color = Volt.hexToRgb('#ffffff', 0);

		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_f.png");
		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.disabled);
		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.disabled);
            
        };

        if (this.app_size + 10 > data.availableSize) {
            renderer.thumbnail.onDim();
        }
    };
    list.onItemMouseClick = function (index) {
        list.onItemPress(index);
    };
    list.onItemPress = function (index) {
        Volt.log('click - ' + index);
        var data = list.getData(index);
        print(' DevicesView.onSelect, this.app_id = ' + this.app_id + ' ,path = ' + data.mountPath);
        var storagepath = data.mountPath;
        var nIndex = storagepath.indexOf('/');

        var usbInfo = Models.externalStorageModel.get('usbList')[index];
        usbInfo.mountPath = usbInfo.mountPath.replace('$USB_DIR', '/opt/storage/usb');

        if (this.appID && usbInfo.mountPath) {
            EventMediator.trigger(CommonDefines.Event.EVENT_USB_INSTALL_APP, {
                app_id: this.appID,
            });
            AppInstallMgr.installApp(this.appID, usbInfo.mountPath);
        }

        Backbone.history.back();
    };

    list.onDrawFromFocusChangeStart = function (root, data, parentWidth, parentHeight) {
        //root.getChild(0).onNormal();
    };

    list.onDrawToFocusChangeEnd = function (root, data, parentWidth, parentHeight) {};
    list.onItemLoaded = function (singleLineList, itemIndex) {
        Volt.log("list.onItemLoaded~~~~~~");
    };

    list.onFocusChanged = function (singleList, fromIndex, toIndex) {
        Volt.log("[usbListPopupView.js]onFocusChanged fromIndex = " + fromIndex + ",toIndex = " + toIndex);
        var usbStorages = Models.externalStorageModel.get('usbList');
        Volt.log("[usbListPopupView.js]onFocusChanged dataPointers.length = " + dataPointers.length );
    	var endTotopflag = (usbStorages.length>5&&fromIndex ==(usbStorages.length-1)&&toIndex==0);
    	var topToendflag = (usbStorages.length>5&&toIndex ==(usbStorages.length-1)&&fromIndex==0);


        
        if (fromIndex >= 0 &&  !endTotopflag && !topToendflag ) {
            singleList.renderer(fromIndex).thumbnail.onNormal();
        }
        if (toIndex >= usbStorages.length) {
            return;
        }
        if (toIndex >= 0) {
            singleList.renderer(toIndex).thumbnail.onFocus();
            var params = {
                name: usbStorages[toIndex].name,
                availableSize: convertMemory(usbStorages[toIndex].availableSize),
                totalSize: convertMemory(usbStorages[toIndex].totalSize),
                fileSystem: usbStorages[toIndex].fileSystem
            };
            if (bFirstEnter) {
                CommonFunctions.voiceGuide(Volt.i18n.t('COM_SID_CHOOSE_WHERE_INSTALL_THE_APP') +
                    Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', usbStorages.length) + ',' +
                    params.name + ',' + params.totalSize + ',' + params.fileSystem);
                bFirstEnter = false;
            } else {
                CommonFunctions.voiceGuide(params.name + ',' + params.totalSize + ',' + params.fileSystem);
            }
            EventMediator.trigger('EVENT_UPDATE_SELECTED_USB', params);
        }
    }

    for (var i = 0; i < storages.length ; i++) {
        var data = new Data();
        data.name = storages[i].name;
        data.mountPath = storages[i].mountPath;
        data.fileSystem = storages[i].fileSystem;
        data.availableSize = convertMemory(storages[i].availableSize);
        data.totalSize = convertMemory(storages[i].totalSize);
        
        dataPointers.push(data);
        list.addData(data);

    }
    list.loadData();

    return list;
}

exports = USBListPopupView;