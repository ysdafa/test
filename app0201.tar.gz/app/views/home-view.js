/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages home view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Public libraries
var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require("modules/VoltJSON.js");
var _ = Volt.require("modules/underscore.js")._;

// Common components
var MainTemplate = Volt.requireCommonTemplate('main');

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js'),
    HomeTemplate = Volt.require('app/templates/1080/home-template.js');

var CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js'),
    //Models = Volt.require('app/models/models.js'),
    voltapi = Volt.require('voltapi.js'),
    AppInstallMgr = Volt.require('app/common/appInstallMgr.js');

//var localStorage = Volt.require("lib/volt-local-storage.js");
var winsetDimView = Volt.require("lib/views/dim-view.js");
var loadingPopup = Volt.require("lib/views/loading-popup.js");

var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var WinsetButton = Volt.require("WinsetUIElement/winsetButton.js");
var PanelCommon = Volt.require('lib/panel-common.js');
PanelCommon.mapWidget('WinsetButton', WinsetButton);
var tvResoultion = (Volt.APPS720P) ? WinsetButton.ResoultionStyle.Resoultion_720 : WinsetButton.ResoultionStyle.Resoultion_1080;

var MENU_ANIM_DURATION = 200;

var WinsetToolTip = Volt.require('WinsetUIElement/winsetToolTip.js');
Volt.mapWidget('WinsetToolTip', WinsetToolTip);
var WinsetLoading = Volt.require('WinsetUIElement/winsetLoading.js');
Volt.mapWidget('WinsetLoading', WinsetLoading);

var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
var MagicKey = Volt.require('app/common/MagicKey.js');
var Model;

/**
 * @name HomeView
 */
var HomeView = Volt.BaseView.extend({
    /** @lends HomeView.prototype */
    template: MainTemplate.container, // Template of Main View is a container framework
    bLoading: false,
    bLastFocus: false,
    bLaunching: false,
    bMyAppsEditMode: false,
    bFirstShow: true,

    /**
     * Initialize HomeView
     * @name HomeView
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_HOME_SHOW_LOADING, this.showLoading);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_HOME_HIDE_LOADING, this.hideLoading);
        this.listenTo(EventMediator, 'SHOW_EDIT_MODE', this.onMyAppsEditMode);
        this.listenTo(EventMediator, 'HIDE_EDIT_MODE', this.offMyAppsEditMode);
        MagicKey.addListener(CommonDefines.Magic.SHOW_VERSION, function () {
            CommonWidgetPopup.showMessage(CommonDefines.Magic.SHOW_VERSION);
        });
    },

    /**
     * Render once after view is created
     * @method
     */
    render: function () {
        Volt.log('[HomeView] render()');
        // Parse the template
        this.setWidget(Volt.loadTemplate(this.template));

        // Render everything
        this.renderHeader();
        //this.renderCategory();
        //this.renderContent();

        //Volt.Nav.reload();
    },

    /**
     * Show this view.
     * @method
     * @param  {object} param Parameters
     * @param  {enum} animationType Animation type to showing this view.
     * @return {deferred} Deferred promise return.
     */
    show: function (options, animationType) {
        Volt.log('[home-view.js]@show');
        /*if(CommonFunctions.getFirstEnterMark() == 1){
            CommonFunctions.forceDisableVoiceGuide(false);
            CommonFunctions.voiceGuide(Volt.i18n.t('COM_SID_LOADING_WAIT'));
            CommonFunctions.forceDisableVoiceGuide(true);
            CommonFunctions.setFirstEnterMark(0);
        }
        else if(CommonFunctions.getFirstEnterMark() == 2){
            CommonFunctions.setFirstEnterMark(1);
        }*/
        var deferred = Q.defer();
        deferred.resolve();

        //// If view is not changed and not the first time to show, just ignore.
        if (options && options.change === false && !this.bFirstShow) {
            return deferred.promise;
        }

        this.widget.show();
        Stage.show(); // show apps panel, request from Volt UIFW

        //// if not to a sub view, show loading
        if (Volt.bQuickView) {
            winsetDimView.show();
            return deferred.promise;
        }

        this.renderCategory();

        // this.listenTo(EventMediator, 'VOLT_PAUSE', this.pause);
        // this.listenTo(EventMediator, 'VOLT_HIDE', this.pause);
        
        this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.dim);
        //this.listenTo(EventMediator, 'VOLT_ACTIVATE', this.hideLoading);
        this.listenTo(EventMediator, 'HOMEVIEW_LAUNCH_APP', this.startLaunch);
        this.listenTo(EventMediator, 'COMMON_POPUP_KEY_RETURN_RELEASE', this.cancelLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS, this.onNetworkStatus);
        this.listenTo(EventMediator, CommonDefines.Event.DISCONNECT_USB, this.showUsbPopup);
        //// TODO: temporarily Comment this

        var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
        var isDetail = (/#detail/g).test(previousHistory);
        if (isDetail) {
            if (this.headerview) {
                this.headerview.setCursorEvent(true);
            }
        }
        var Models = Volt.require('app/models/models.js');

        //call Volt.Nav.setRoot, for reset the root when coming back to this view.
        Volt.Nav.setRoot(this.widget, {
            focus: null
        });

        if (false == this.bFirstShow) {
            Volt.Nav.focus(this.widget.getDescendant('category-list-container'));
        } else {
            if (Volt.DeviceInfoModel.get('networksStatus') == "OK") {
                this.bFirstShow = false;
            } else {
                Volt.Nav.focus(this.widget.getDescendant('category-list-container'));
            }
        }

        var self = this;
        this.widget._navOnKeyEvent = function (keycode, type) {
            if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS && Backbone.history.getFragment() == 'myapps' && this.bMyAppsEditMode) {
                EventMediator.trigger('HIDE_EDIT_MODE');
                return true;
            }
            return false;

        }.bind(this);
        var developMode = voltapi.vconf.getValue(CommonDefines.Vconf.DB_DEVELOP_MODE);
        Volt.log('[home-view.js] developMode is ' + developMode);
        if (developMode) {
            if ('0' == developMode) {
                this.widget.getDescendant('main-header-develop-title').text = '';
            } else if ('1' == developMode) {
                this.widget.getDescendant('main-header-develop-title').text = 'Developer Mode';
            }
        } else {
            this.widget.getDescendant('main-header-develop-title').text = '';
        }
        //this.widget.show();

        return deferred.promise;
    },
    showUsbPopup: function () {
        Volt.log('[HomeView] showUsbPopup');
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_USB_NOT_CONNECT);
    },
    /**
     * hide this view.
     * @method
     * @param  {enum} animationType Animation type to hiding this view.
     * @return {deferred} Deferred promise return.
     */
    hide: function (options, animationType) {
        var deferred = Q.defer();
        deferred.resolve();

        //// If it is switching sub views, just ignore.
        if (options && options.change === false) {
            return deferred.promise;
        }

        // if (type != 'update') {
        // if (this.headerview) {
        // this.headerview.hide();
        // }
        // this.widget.hide();
        // }

        this.widget.hide();

        // this.stopListening(EventMediator, 'VOLT_PAUSE');
        // this.stopListening(EventMediator, 'VOLT_HIDE');
        this.stopListening(EventMediator, 'VOLT_DEACTIVATE');

        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS);

        this.stopListening(EventMediator, 'HOMEVIEW_LAUNCH_APP');
        this.stopListening(EventMediator, 'COMMON_POPUP_KEY_RETURN_RELEASE');
        this.stopListening(EventMediator, CommonDefines.Event.DISCONNECT_USB);
        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);

        this.widget._navOnKeyEvent = null;

        if (this.headerview) {
            this.headerview.setCursorEvent(false);
        }
        return deferred.promise;
    },

    /**
     * Pause this view.
     * @method
     */
    pause: function () {
        Volt.log('[HomeView] pause');

        if (this.loading) {
            this.hideLoading();
        }

        // this.widget.hide();
        Volt.Nav.pause();
        //this.listenTo(EventMediator, 'VOLT_RESUME', this.resume);
    },

    /**
     * Resume this view.
     * @method
     */
    resume: function (params, showType, beforeType) {
        Volt.log('[HomeView] resume');

        this.widget.show();

        Volt.Nav.setRoot(this.widget);
        if ('#popup/updateAppsList' == Backbone.history.hashstack[Backbone.history.hashstack.length - 2]) {
            Volt.Nav.focus(this.widget.getDescendant('main-header-icon-option'));
        }
        if (4 != beforeType) { //if  beforeType is popup
            Volt.Nav.resume();
        }
        this.headerview.bPopupshowing = false;
        // this.stopListening(EventMediator, 'VOLT_RESUME');
    },

    /**
     * Render header view
     * @method
     */
    renderHeader: function () {
        Volt.log('[HomeView] renderHeaderIcon');
        var container = this.widget.getDescendant('main-header-container');
        this.headerview = new HeaderView();
        container.addChild( /*new HeaderView()*/ this.headerview.render(this).widget);
    },

    /**
     * Render menu list view
     * @method
     */
    renderCategory: function () {
        Volt.log('[HomeView] renderCategory()');

        if (!this.category) {
            var CategoryView = Volt.require('app/views/menuListView.js');

            this.category = new CategoryView({
                parent: this
            }).render();
        }
    },

    /**
     * Render content view
     * @method
     */
    renderContent: function () {
        Volt.log('[HomeView] renderContent');
    },

    startLaunch: function () {
        Volt.log('[HomeView] startLaunch');

        this.bLaunching = true;

        this.bindLaunchEvents();
    },

    cancelLaunch: function () {
        Volt.log('[HomeView] cancelLaunch');

        if (this.bLaunching) {
            var sLaunchedAppId = AppInstallMgr.getLaunchedAppID();
            AppInstallMgr.terminateApp(sLaunchedAppId);
            this.bLaunching = false;
        }

    },

    failLaunch: function () {
        Volt.log('[HomeView] failLaunch');
        this.bLaunching = false;
        this.unbindLaunchEvents();

    },

    bindLaunchEvents: function () {
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE, this.failLaunch);

        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_LAUNCH, this.onLaunched);
    },

    unbindLaunchEvents: function () {
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE);

        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_LAUNCH);
    },

    onLaunched: function () {
        Volt.log('[HomeView] onLaunched');

        this.bLaunching = false;

        this.unbindLaunchEvents();
    },


    /**
     * Show loading popup
     */
    showLoading: function (options) {
        Volt.log('[HomeView] showLoading()');
        /*if (!this.bLoading){ 
	     winsetDimView.show();
            var mustache = {
                style20 : WinsetLoading.LoadingStyle.Loading_Dark_20,
                nResoultionStyle : (Volt.APPS720P)? WinsetLoading.ResoultionStyle.Resoultion_720 : WinsetLoading.ResoultionStyle.Resoultion_1080
            }
            this.loading = Volt.loadTemplate(HomeTemplate.loading,mustache,scene);
            this.loading.play();
            CommonFunctions.voiceGuide(Volt.i18n.t('COM_SID_LOADING_WAIT'));
	        this.bLoading = true;        
        }*/
        var options = {
            bLaunching: (options ? options.bLaunching : false)
        };

        if (!this.bLoading) {
            this.bLoading = true;
            loadingPopup.show(options);
        }
    },

    /**
     * Hide loading popup
     */
    hideLoading: function () {
        Volt.log('[home-view.js @hideLoading]');
        this.bLoading = false;
        /*if(this.loading){
            this.loading.stop();
            this.loading.hide();
            this.loading.destroy();
            this.loading = null;
	      
        }*/
        winsetDimView.hide();
        loadingPopup.hide();
        //Volt.Nav.setRoot(this.widget);
    },

    onNetworkStatus: function () {
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            //var networkPopup = new MsgPopupView({type: CommonDefines.Popup.TYPE_NETWORK});
            //CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);//when network disconnect,do not show popup
        }
    },

    dim: function () {
        Volt.log('[HomeView] dim');

        Volt.setTimeout(function () {
            CommonWidgetPopup.destroyWidgetPopup();

            winsetDimView.show();
        }, 0);
    },

    onMyAppsEditMode: function () {
        this.bMyAppsEditMode = true;
    },

    offMyAppsEditMode: function () {
        this.bMyAppsEditMode = false;
    }
});

/**
 * @namespace HomeView
 * @name HeaderView
 */
var HeaderView = Volt.BaseView.extend({
    /** @lends HeaderView.prototype */
    template: HomeTemplate.header,
    parent: null,
    bPopupshowing: false,
    timeId: null,
    offsetFlag: true,
    toolTipWidget: null,
    btnListener: new ButtonListener(),
    expendAnimation: null,
    shrinkAnimation: null,
    /**
     * Events delegation
     * @type {object}
     */
    events: {
        /*'NAV_SELECT #main-header-icon-search': 'onSelectSearch',
        'NAV_SELECT #main-header-icon-option': 'onSelectOption',
        'NAV_SELECT #main-header-icon-close': 'onSelectClose',*/

        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * Initialize HeaderView
     * @name HeaderView
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS, this.shrink);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR, this.expand);
        this.listenTo(EventMediator, 'OPTIONMENU_POPUP_HIDE', this.changePoupStatus);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);

        btnListener: new ButtonListener(),
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);
    },

    /**
     * Render this view
     * @method
     */
    render: function (parentWidget) {
        Volt.log('[HeaderView] render()');

        var highContrast = DeviceInfoModel.get('highContrast');
        //Volt.log(highContrast+"********************************highContrast*****************loadTemplate*****");

        var flag = highContrast || '0';
        //Volt.log(highcontrast+"********************************highcontrast*****************loadTemplate*****");
        this.setWidget(Volt.loadTemplate(this.template, {
            highconstract: flag
        }));

        this.parent = parentWidget;

        var iconSearchBtnBG = this.widget.getDescendant('main-header-icon-search');
        this.iconSearchBtn = PanelCommon.loadTemplate(HomeTemplate.iconBtn, {
            WinsetID: "SearchBtnId"
        }, iconSearchBtnBG);
        this.initButton(this.iconSearchBtn, Volt.getRemoteUrl('images/1080/common/comn_icon_tm_search.png'));

        var iconOptionBtnBG = this.widget.getDescendant('main-header-icon-option');
        this.iconOptionBtn = PanelCommon.loadTemplate(HomeTemplate.iconBtn, {
            WinsetID: "OptionBtnId"
        }, iconOptionBtnBG);
        this.initButton(this.iconOptionBtn, Volt.getRemoteUrl('images/1080/common/comn_icon_tm_setting.png'));

        var iconCloseBtnBG = this.widget.getDescendant('main-header-icon-close');
        this.iconCloseBtn = PanelCommon.loadTemplate(HomeTemplate.iconBtn, {
            WinsetID: "CloseBtnId"
        }, iconCloseBtnBG);
        this.initButton(this.iconCloseBtn, Volt.getRemoteUrl('images/1080/common/comn_icon_tm_close.png'));

        var iconContainer = this.widget.getChild('header-container')
        this.wzCloseButton = iconContainer.getChild('main-header-icon-close');
        this.onChangeCursor(Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE));

        Volt.Nav.setNextItemRule(iconContainer.getChild('main-header-icon-search'), 'down', 'category-list-container');
        Volt.Nav.setNextItemRule(iconContainer.getChild('main-header-icon-search'), 'left', 'main-header-icon-search');

        return this;
    },
    setCursorEvent: function (flag) {
        Volt.log('[HeaderView] setCursorEvent:flag is ' + flag);
        if (true == flag) {
            this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
        } else {
            this.stopListening(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        }
    },
    initButton: function (iconButton, iconImage) {
        Volt.log('[HeaderView] initButton()');
        iconButton.setBackgroundColor({
            state: "all",
            color: Volt.hexToRgb('#0f1826', 0)
        });

        iconButton.setBackgroundImage({
            state: "focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        iconButton.setBackgroundImage({
            state: "normal",
            src: '',
        });

        iconButton.setBackgroundImage({
            state: "disabled",
            src: '',
        });
        iconButton.setBackgroundImage({
            state: "disabled-focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        iconButton.setBackgroundImage({
            state: "selected",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });


        iconButton.setIconImage({
            state: "all",
            src: iconImage
        });

        iconButton.setIconAlpha({
            state: "normal",
            alpha: 255 * 0.6
        });
        iconButton.setIconAlpha({
            state: "disabled",
            alpha: 255 * 0.6
        });
        iconButton.setIconAlpha({
            state: "focused-roll-over",
            alpha: 255
        });
        iconButton.setIconAlpha({
            state: "roll-over",
            alpha: 255
        });


        if (iconButton.setIconScaleFactor) {
            iconButton.setIconScaleFactor({
                state: "focused-roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });


            iconButton.setIconScaleFactor({
                state: "roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });
        }

        iconButton.setIconAttr({
            x: Volt.width * 0.017187 + ((Volt.APPS720P) ? 3 : 4),
            y: Volt.height * 0.050926 + ((Volt.APPS720P) ? 3 : 4),
            width: Volt.width * 0.01875,
            height: Volt.height * 0.033333
        });

        iconButton.addListener(this.btnListener);
    },
    /**
     * Call when this view focused
     * @method
     * @param  {widget} widget Focused widget
     */
    onFocus: function (widget) {
        Volt.log('[HeaderView] onFocus() ' + widget.id);

        var iconContainer = this.widget.getChild('header-container');
        if (widget) {
            switch (widget.id) {
            case 'main-header-icon-search':
                Volt.log('[HeaderView] iconSearchBtn.setFocus()');
                this.iconSearchBtn.setFocus();
                CommonFunctions.voiceGuide(Volt.i18n.t('UID_SEARCH') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                this.showToolTip(widget);
                break;
            case 'main-header-icon-option':
                Volt.log('[HeaderView] iconOptionBtn.setFocus()');
                this.iconOptionBtn.setFocus();
                CommonFunctions.voiceGuide(Volt.i18n.t('UID_OPTIONS') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                this.showToolTip(widget);

                break;
            case 'main-header-icon-close':
                Volt.log('[HeaderView] iconCloseBtn.setFocus()');
                if (true == this.offsetFlag) {
                    var iconContainer = this.widget.getChild('header-container');
                    Volt.Nav.focus(iconContainer.getChild('main-header-icon-option'));
                } else {
                    this.iconCloseBtn.setFocus();
                    CommonFunctions.voiceGuide("Exit, button");
                    this.showToolTip(widget);
                }
                break;
            }
        }
    },
    /**
     * Call when this view blurred
     * @method
     * @param  {Widget} widget Blurred widget
     */
    onBlur: function (widget) {
        Volt.log('[HeaderView] onBlur() id: #' + widget.id);

        if (widget) {
            switch (widget.id) {
            case 'main-header-icon-search':
                // this.iconSearchBtn.killFocus();
                this.hideToolTip();
                break;
            case 'main-header-icon-option':
                // this.iconOptionBtn.killFocus();
                this.hideToolTip();
                break;
            case 'main-header-icon-close':
                // this.iconCloseBtn.killFocus();
                this.hideToolTip();
                break;
            }
        }
    },
    onSelect: function (widget) {
        if (widget) {
            Volt.log("widget.id: " + widget.id);

            switch (widget.id) {
            case "SearchBtnId":
                this.onSelectSearch();
                break;
            case "OptionBtnId":
                this.onSelectWinsetOption();
                break;
            case "CloseBtnId":
                this.onSelectClose();
                break;
            }
        }
    },
    onSelectWinsetOption: function () {
        Volt.log('[HeaderView] onSelectWinsetOption()');
        this.bLastFocus = true;
        Volt.KpiMapper.addEventLog('SELECTOPTION', {
            d: {
                cp: ''
            }
        });
        if (!this.bPopupshowing) {

            var localStorage = Volt.require("lib/volt-local-storage.js");

            //if (Models.menuVMCollection.where({route:'myapps'})[0]){
            //if(Models.menuVMCollection.currentMenuIndex <=2){
            this.listenTo(EventMediator, CommonDefines.Event.OPTION_MENU, this.processOptionMenuEvent, this);
            HomeTemplate.optionMenu.subSelectIndex = localStorage.getItem('sortOption') ? localStorage.getItem('sortOption') : 0;
            if (!(HomeTemplate.optionMenu.subSelectIndex >= 0 && HomeTemplate.optionMenu.subSelectIndex <= 3)) {
                HomeTemplate.optionMenu.subSelectIndex = 0;
            }
            Volt.log('[HeaderView] onSelectWinsetOption:sortPostion is ' + HomeTemplate.optionMenu.subSelectIndex);
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_OPTIONMENU, HomeTemplate.optionMenu);
            this.bPopupshowing = true;
        } else {
            Volt.log('[HeaderView] this.bPopupshowing is true');
        }

    },

    processOptionMenuEvent: function (data) {
        Volt.log('[home-view.js] processOptionMenuEvent:data.parentIndex is ' + data.parentIndex + " data.subIndex is " + data.subIndex);

        var localStorage = Volt.require("lib/volt-local-storage.js");
        var Models = Volt.require('app/models/models.js');

        nSelectedSortOption = localStorage.getItem('sortOption'),
        this.stopListening(EventMediator, CommonDefines.Event.OPTION_MENU);
        sSortStandards = ['By Date', 'Most Used', 'TITLE A-Z', 'TITLE Z-A'];
        this.bPopupshowing = false;
        switch (data.parentIndex) {
        case 0: // Delete
            Volt.KpiMapper.addEventLog('SELECTDELETE');
            EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
            Volt.setTimeout(function () {
                EventMediator.trigger('SHOW_EDIT_MODE', 'delete');
            }, 0);
            break;
        case 1: // Lock / Unlock
            Volt.KpiMapper.addEventLog('SELECTLOCKUNLOCK');
            var param = {
                callback: function () {
                    EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
                    Volt.setTimeout(function () {
                        EventMediator.trigger('SHOW_EDIT_MODE', 'lock');
                    }, 0);
                }
            };
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_PIN, param);
            break;
        case 2: // Sort
            Volt.KpiMapper.addEventLog('SELECTSORT');
            subOptionMenu = parseInt(data.subIndex, 10);
            Volt.log('[home-view.js] subOptionMenu is ' + subOptionMenu);
            Volt.log('[home-view.js] nSelectedSortOption is ' + nSelectedSortOption);
            if (nSelectedSortOption != subOptionMenu) {
                // 0 : 'By Date', 1: 'Most Used', 2: 'Title A-Z', 3 : 'Title Z-A'
                // nSelectedSortOption = localStorage.setItem('sortOption', subOptionMenu);
                Volt.KpiMapper.addEventLog('CHANGESORT', {
                    d: {
                        con: sSortStandards[subOptionMenu]
                    }
                });
                localStorage.setItem('sortOption', subOptionMenu);
                EventMediator.trigger('SORT_GRID_LIST', subOptionMenu);
            }
            break;
        case 3: // Update Apps
            Volt.KpiMapper.addEventLog('SELECTUPDATE');
            if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);//when network disconnect,do not show popup
                break;
            }
            Models.updateAppsCollection.fetch();

            if (data.dimflag == true) {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS);
            } else {
                this.bPopupshowing = true;
                Backbone.history.navigate('popup/updateAppsList', {
                    trigger: true
                });
            }
            break;
        default:
            Volt.log('[home-view.js] invalid parentIndex is ' + data.parentIndex);
            break;
        }
    },
    /**
     * Call when search button selected
     * @method
     */
    onSelectSearch: function () {
        Volt.err('[HeaderView] onSelectSearch()');
        Volt.KpiMapper.addEventLog('SELECTSEARCH', {
            d: {
                cp: ''
            }
        });

        if (!Volt.browser) {
            Volt.log('[HeaderView] Launch search all');
            var appName = "org.tizen.search-all",
                args = {
                    "--root": "/usr/apps/org.tizen.search-all/",
                    "domain": "apps"
                },
                aulApp = new Aul();

            var result = aulApp.launchApp(appName, args);
            Volt.err('[HeaderView] Launch Search-All, result: ' + result);
            winsetDimView.show();
            Volt.Nav.focus(null);
            /*
            var args1 = {"--root": "/usr/apps/org.tizen.search-all/", "domain": "apps"};
            var appName = "org.tizen.search-all";
            var aulApp = new Aul();
            aulApp.launchApp(appName, args1);
            */
        }
    },

    onSelectClose: function () {
        Volt.log('[HomeView.js] onSelectClose(), exit apps panel, apps panel will hide in background');
        Volt.exit();
        //Volt.quit();
    },

    /**
     * Callback function of plus button select.
     * @method
     * @param  {int} index    Selected index of menu
     * @param  {int} subIndex Selected index of sub menu
     */
    onOptionMenuCallback: function (index, subIndex, bDim) {
        var optionMenu = parseInt(index, 10),
            subOptionMenu = parseInt(subIndex, 10),
            nSelectedSortOption = localStorage.getItem('sortOption'),
            sSortStandards = ['By Date', 'Most Used', 'TITLE A-Z', 'TITLE Z-A'];

        if (index == -1 || bDim) return;

        this.bPopupshowing = false;

        switch (optionMenu) {
        case 0: // Delete
            EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
            Volt.setTimeout(function () {
                EventMediator.trigger('SHOW_EDIT_MODE', 'delete');
            }, 0);
            Volt.KpiMapper.addEventLog('SELECTDELETE');
            break;
        case 1: // Lock / Unlock
            Volt.KpiMapper.addEventLog('SELECTLOCKUNLOCK');
            /* var pinPopup = new MsgPopupView({
                    type: CommonDefines.Popup.TYPE_PIN,
                    title: 'Unlock',
                    callback: function() {
                        EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
                        Volt.setTimeout(function(){
                            EventMediator.trigger('SHOW_EDIT_MODE', 'lock');
                        }, 0);
                    }
                 
                });*/
            var param = {
                callback: function () {
                    EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
                    Volt.setTimeout(function () {
                        EventMediator.trigger('SHOW_EDIT_MODE', 'lock');
                    }, 0);
                }
            }
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_PIN, param);
            break;
        case 3: // Sort
            Volt.KpiMapper.addEventLog('SELECTSORT');
            if (nSelectedSortOption != subOptionMenu) {
                // subOptionMenu 
                // 0 : 'By Date', 1: 'Most Used', 2: 'Title A-Z', 3 : 'Title Z-A'
                nSelectedSortOption = localStorage.setItem('sortOption', subOptionMenu);
                Volt.KpiMapper.addEventLog('CHANGESORT', {
                    d: {
                        con: sSortStandards[subOptionMenu]
                    }
                });
                EventMediator.trigger('SORT_GRID_LIST', subOptionMenu);
            }
            break;
        case 2: // Update Apps
            var Models = Volt.require('app/models/models.js');
            Volt.KpiMapper.addEventLog('SELECTUPDATE');
            Models.updateAppsCollection.fetch();
            Backbone.history.navigate('popup/updateAppsList', {
                trigger: true
            });
            break;
        }
    },

    onChangeCursor: function (bVisible) {
        var iconContainer = this.widget.getChild('header-container');
        print('onChangeCursor: bVisible is ' + bVisible);
        if (this.wzCloseButton && iconContainer && !this.bPopupshowing && !(this.parent && this.parent.bMyAppsEditMode)) {
            if (bVisible) {
                iconContainer.getChild('main-header-icon-search-border').x = 0;
                iconContainer.getChild('main-header-icon-search').x = 1;
                iconContainer.getChild('main-header-icon-option-border').x = Volt.width * 0.052083;
                iconContainer.getChild('main-header-icon-option').x = Volt.width * 0.052083 + 1;
                iconContainer.getChild('main-header-icon-close-border').x = Volt.width * 0.052083 * 2;
                this.wzCloseButton.show();
                this.offsetFlag = false;
            } else {
                iconContainer.getChild('main-header-icon-search-border').x = Volt.width * 0.052083;
                iconContainer.getChild('main-header-icon-search').x = Volt.width * 0.052083 + 1;
                iconContainer.getChild('main-header-icon-option-border').x = Volt.width * 0.052083 * 2;
                iconContainer.getChild('main-header-icon-option').x = Volt.width * 0.052083 * 2 + 1;
                iconContainer.getChild('main-header-icon-close-border').x = Volt.width * 0.052083 * 3;
                this.wzCloseButton.hide();
                this.offsetFlag = true;

                if (Volt.Nav.getFocusedWidget() && Volt.Nav.getFocusedWidget().id == 'main-header-icon-close') {
                    Volt.Nav.focus(iconContainer.getChild('main-header-icon-option'));
                }
            }
            this.updateToolTip();
        }
    },

    changePoupStatus: function () {
        Volt.log('[HeaderView] changePoupStatus()');

        this.bPopupshowing = false;

        if (!Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)) {
            this.onChangeCursor(false);
        } else {
            this.onChangeCursor(true);
        }
    },

    /**
     * Call when expand header view
     * @method
     */
    expand: function () {
        if (!this.parent.bLoading) {
            Volt.log('[HeaderView] expand()');
            if (this.expendAnimation) {
                this.expendAnimation.stop();
            }
            if (this.shrinkAnimation) {
                this.shrinkAnimation.stop(true);
            }

            this.expendAnimation = new MultiObjectTransition();
            this.expendAnimation.setDuration(MENU_ANIM_DURATION);
            this.expendAnimation.AddObjectDestination(this.widget, "y", 0);
            this.expendAnimation.play();
        }
    },

    /**
     * Call when shrink header view
     * @method
     */
    shrink: function () {
        Volt.log('[HeaderView] shrink()');
        if (this.shrinkAnimation) {
            this.shrinkAnimation.stop();
        }
        if (this.expendAnimation) {
            this.expendAnimation.stop(true);
        }
        this.shrinkAnimation = new MultiObjectTransition();
        this.shrinkAnimation.setDuration(MENU_ANIM_DURATION);
        this.shrinkAnimation.AddObjectDestination(this.widget, "y", -Volt.height * 0.016667);
        this.shrinkAnimation.play();
    },

    showToolTip: function (widget) {
        var absolutePosition = widget.getAbsolutePosition();
        Volt.log("[homeView.js] showToolTip absolutePosition.x = " + absolutePosition.x);
        Volt.log("[homeView.js] showToolTip absolutePosition.y = " + absolutePosition.y);
        var text = '';

        if (widget && widget.id == 'main-header-icon-search') {
            text = Volt.i18n.t('UID_SEARCH');
        } else if (widget && widget.id == 'main-header-icon-option') {
            text = Volt.i18n.t('UID_OPTIONS');
            //postionOffset = Volt.width*0.0078125;
        } else if (widget && widget.id == 'main-header-icon-close') {
            text = Volt.i18n.t('SID_EXIT');
        }
        if (text == '') {
            Volt.log("[HomeView.js] showtooltip error, text is empty");
            return;
        }
        // if(false == this.offsetFlag){
        // 	postionOffset = 0;
        //}
        //Volt.log('[HomeView.js] postionOffset is ' + postionOffset);
        var mustache = {
            x: absolutePosition.x + widget.width / 2 - Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) / 2 - Volt.width * 0.0078125,
            w: Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) + Volt.width * 0.015625,
            style: WinsetToolTip.TooltipStyle.Tooltip_Tail_Up,
            nResoultionStyle: (Volt.APPS720P) ? WinsetToolTip.ResoultionStyle.Resoultion_720 : WinsetToolTip.ResoultionStyle.Resoultion_1080,
            text: text,
            tailPostion: "center"
        }
        if (mustache.x + mustache.w > Volt.width) {
            mustache.x = absolutePosition.x + widget.width / 2 + Volt.width * 0.0109375 - mustache.w;
            mustache.tailPostion = "end";
        }
        if (this.toolTip) {
            this.hideToolTip();
        }
        this.toolTipWidget = widget;
        this.toolTip = Volt.loadTemplate(HomeTemplate.toolTip, mustache);
        // if(0 != postionOffset){
        // 	this.toolTip.setTailPosition("up", Volt.getTextWidth({text : text, font : (Volt.APPS720P)? "SVD Light 20px" : "SVD Light 30px"}) / 2 + Volt.width*0.003125 + postionOffset, 0);
        // }

        this.toolTip.show();
        this.startToolTipTimeOut();
    },
    hideToolTip: function () {
        Volt.log("[homeView.js] hideToolTip");
        if (this.toolTip) {
            Volt.log("[homeView.js] hideToolTip destroy tooltip");
            this.toolTip.destroy();
            this.toolTip = null;
        }
        this.toolTipWidget = null;
        this.clearToolTipTimeOut();
    },

    startToolTipTimeOut: function () {
        Volt.log('[HeaderView] startToolTipTimeOut');
        this.clearToolTipTimeOut();
        this.timeId = Volt.setTimeout(_.bind(this.hideToolTip, this), 2000);
    },
    clearToolTipTimeOut: function () {
        Volt.log('[HeaderView] clearToolTipTimeOut');
        if (this.timeId) {
            Volt.clearTimeout(this.timeId);
            this.timeId = null;
        }
    },

    updateToolTip: function () {
        Volt.log('[HeaderView] updateToolTip');
        if (this.toolTipWidget) {
            var tempWidget = this.toolTipWidget;
            this.hideToolTip();
            this.toolTipWidget = tempWidget;
            this.showToolTip(this.toolTipWidget);
        }
    },

    hide: function () {
        this.hideToolTip();
    }

});

exports = HomeView;