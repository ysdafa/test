/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview MostPopularView
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require("modules/VoltJSON.js");

var FeaturedListView = Volt.require('app/views/featuredListView.js').listView;
var AppInfoView = Volt.require('app/views/featuredListView.js').appInfoView;
var FeaturedListTemplate = Volt.require('app/templates/1080/featuredListTemplate.js');
var _ = Volt.require("modules/underscore.js")._;

/**
 * @name MostPopularView
 */
var MostPopularView = FeaturedListView.extend({
    /** @lends MostPopularView.prototype */
    featuredType: "mostPopular",

    /**
     * Initialize MostPopularView
     * @name MostPopularView
     * @constructs
     */
    initialize: function () {},

    setAppInfoView: function () {
        this.appInfoView = MostPopularInfoView;
    },
});

var MostPopularInfoView = AppInfoView.extend({

    appinfo: FeaturedListTemplate.mostPopularAppinfo,

    extendData: function (mustache, data) {
        return mustache;
    },

    setChildColorPicking: function (color) {
        if (color != null) {
            this.widget.getChild(0).getChild(1).getChild(3).textColor = {
                r: color.r,
                g: color.g,
                b: color.b
            };
            this.autoScrollTextWidget.setTextContent({
                textcolor: {
                    normal: {
                        r: color.r,
                        g: color.g,
                        b: color.b,
                        a: 153
                    },
                    focus: {
                        r: color.r,
                        g: color.g,
                        b: color.b,
                        a: 153
                    }
                }
            });
        }
        this.setGradeAvg();
    },

    setGradeAvg: function () {

        var srcStarbg = Volt.getRemoteUrl('images/1080/common/apps_contents_star_bg.png');
        var srcStarbk = Volt.getRemoteUrl('images/1080/common/apps_contents_star_bk.png');
        var srcStarbkHalf = Volt.getRemoteUrl('images/1080/common/apps_contents_star_bk_half.png');
        var srcStarwh = Volt.getRemoteUrl('images/1080/common/apps_contents_star_wh.png');
        var srcStarwhHalf = Volt.getRemoteUrl('images/1080/common/apps_contents_star_wh_half.png');

        var nAvgRating = this.VM.get('gradeAvg');
        var bRating;

        if (nAvgRating !== null) {
            bRating = true;
        } else {
            bRating = false;
        }

        var MAX_RATING_NUM = 5;
        var starUrl = new Array(MAX_RATING_NUM);
        var noRatings = "";

        if (bRating) {
            var integerRating = Math.floor(Number(nAvgRating));
            var pointRating = nAvgRating - integerRating;

            for (var i = 0; i < MAX_RATING_NUM; i++) {

                starUrl[i] = '';
                if (i < integerRating) {
                    this.bgmode == "LIGHT" ? starUrl[i] = srcStarwh : starUrl[i] = srcStarbk;
                } else {
                    if (i == integerRating && pointRating >= 0.5) {
                        this.bgmode == "LIGHT" ? starUrl[i] = srcStarwhHalf : starUrl[i] = srcStarbkHalf;
                    } else {
                        starUrl[i] = srcStarbg;
                    }
                }
                this.widget.getChild(0).getChild(1).getChild(2).getChild(i).src = starUrl[i];
                if (starUrl[i] == srcStarbg) {
                    this.widget.getChild(0).getChild(1).getChild(2).getChild(i).opacity = Volt.getPercentage(20);
                } else {
                    this.widget.getChild(0).getChild(1).getChild(2).getChild(i).opacity = Volt.getPercentage(50);
                }
            }
        } else {
            this.widget.getChild(0).getChild(1).getChild(2).getChild(5).text = "No Ratings";
        }
    }

});

exports = MostPopularView;