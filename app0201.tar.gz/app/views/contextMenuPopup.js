var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var EventMediator = Volt.require('app/common/eventMediator.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var OptionMenu = Volt.require('lib/custom-widgets/cm_option_menu_new.js');
var winsetDimView = Volt.require("lib/views/dim-view.js");
var Template = Volt.require("app/templates/1080/contextMenuTemplate.js");
var DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js');
var AppInstallMgr = Volt.require('app/common/appInstallMgr.js');

var ContextMenuPopup = Volt.BaseView.extend({
    contextMenuPopup: null,
    option: null,
    select_delete: false,
    successEvent: [
        CommonDefines.Event.INSTALL_COMPLETED
    ],

    failEvent: [
        CommonDefines.Event.DOWNLOAD_FAIL_NOT_EXIST,
        CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE,
        CommonDefines.Event.DOWNLOAD_FAIL_LICENSE_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_SERVER_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_NETWORK_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_OTHERS,

        CommonDefines.Event.DOWNLOAD_FAIL_DECRYPY_CONFIG,
  CommonDefines.Event.DOWNLOAD_FAIL_ICON_URL_IS_EMPTY,
  CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_ICON,
  CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_APP,
  CommonDefines.Event.DOWNLOAD_FAIL_APP_NOT_EXIST,
  CommonDefines.Event.DOWNLAOD_LOAD_WIDGET_INFO,
  CommonDefines.Event.DOWNLOAD_FAIL_CONVERT_ID_FROM_RUNTITLE,
  CommonDefines.Event.DOWNLOAD_FAIL_INPUT_PARAMETER,
  CommonDefines.Event.DOWNLOAD_FAIL_MOVE_DIR,
  CommonDefines.Event.DOWNLOAD_FAIL_UNZIP_FILES,
  CommonDefines.Event.DOWNLOAD_FAIL_NO_LICENSE_FILE,
  CommonDefines.Event.DOWNLOAD_FAIL_NO_INSTALL_DIR,
  CommonDefines.Event.DOWNLOAD_FAIL_TEMP_DIR_NOT_EXIST,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_URL,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_EMP_INFO,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_NOT_ENOUGH_MEMORY,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_MOVE,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_DOWNLOAD,

        CommonDefines.Event.INSTALL_FAIL_EXIST,
        CommonDefines.Event.INSTALL_FAIL_PKGMGR_ERROR,
        CommonDefines.Event.INSTALL_FAIL_LICENSE_ERROR,
        CommonDefines.Event.INSTALL_FAIL_OTHERS,
        CommonDefines.Event.INSTALL_CANCEL_COMPLETED,
        // CommonDefines.Event.INSTALL_CANCEL_FAILED
    ],

    initialize: function () {
        Volt.log('[contextMenuPopup.js] initialize');
    },


    show: function (param) {
        Volt.log('[contextMenuPopup.js] show');
        this.option = param;
        var template = _.clone(Template.contextMenu);
        this.select_delete = false;

        Volt.log('[contextMenuPopup.js] this.option.baseWidget.getAbsolutePosition().x = ' + this.option.baseWidget.getAbsolutePosition().x);
        Volt.log('[contextMenuPopup.js] this.option.baseWidget.getAbsolutePosition().y = ' + this.option.baseWidget.getAbsolutePosition().y);

        var xPos = this.option.baseWidget.getAbsolutePosition().x + this.option.baseWidget.width;
        if (xPos + template.width > Volt.width) {
            xPos = this.option.baseWidget.getAbsolutePosition().x - template.width;
        }
        var yPos = this.option.baseWidget.getAbsolutePosition().y;
        /*if(Volt.APPS_REVERSE){
            xPos = Volt.width - this.option.baseWidget.getAbsolutePosition().x;
	      if(xPos + template.width > scene.width){
                xPos = Volt.width - this.option.baseWidget.getAbsolutePosition().x - this.option.baseWidget.width - template.width;
            }
	 }*/
        template.x = xPos;
        template.y = yPos;

        var appID = this.option.appInfoVM.get('id');
        Volt.log("[contextMenuPopup.js] appID is " + appID);
        if (this.option.type == 'myapps' && this.option.feature == 1) {
            if (this.option.is_removable == true) {
                template.showNumber = 2;
                template.height = Volt.height * 0.138889 * 2;
                template.items[0].text = Volt.i18n.t('COM_SID_DELETE');
                if (template.items[1]) {
                    template.items[1].text = Volt.i18n.t('SID_DETAIL');
                } else {
                    template.items.push({
                        style: 12,
                        text: Volt.i18n.t('SID_DETAIL')
                    });
                }
            } else {
                template.showNumber = 1;
                template.height = Volt.height * 0.138889;
                if (template.items[1]) {
                    template.items.pop();
                }
                template.items[0].text = Volt.i18n.t('SID_DETAIL');
            }
        } else {
            template.showNumber = 1;
            template.height = Volt.height * 0.138889;
            if (template.items[1]) {
                template.items.pop();
            }
            if (this.option.type == 'myapps') {
                template.items[0].text = Volt.i18n.t('TV_SID_REINSTALL');
            } else if (DownloadedAppsMgr.isDownloaded(appID) == true) {
                template.items[0].text = Volt.i18n.t('UID_OPEN');
            } else if (AppInstallMgr.getInstallList(appID).app_id == undefined) {
                template.items[0].text = Volt.i18n.t('COM_SID_DOWNLOAD');
            } else {
                template.items[0].text = Volt.i18n.t('COM_SID_CANCEL');
            }
        }

        this.contextMenuPopup = new OptionMenu(template);
        this.contextMenuPopup.setCallback(_.bind(this.onContextMenuCB, this));
        this.contextMenuPopup.setFocusChangeCallback(_.bind(this.onContextMenuFocusChange, this));
        this.contextMenuPopup.setSelectIndex(0);

        if (this.option.type == 'myapps' && (this.option.appInfoVM.get('app_title') == 'e-Manual' ||
            this.option.appInfoVM.get('app_id') == "org.tizen.browser")) {
            this.contextMenuPopup.dimListItem(0);
        }
        this.contextMenuPopup.setTimeout(30 * 1000, _.bind(this.hide, this));
        //this.contextMenuPopup.setFocus();
        this.contextMenuPopup.showFocus('false');
        this.contextMenuPopup.show();
        //Volt.Nav.beginModal(this.contextMenuPopup);

        EventMediator.on(CommonDefines.Event.EVENT_CLOSE_POPUP, this.hide, this);
        EventMediator.on(CommonDefines.Event.EVENT_LONGPRESS_RELEASE, this.focusmenu, this);
        this.listenToSucessEvent();
        this.listenToFailEvent();
    },

    onContextMenuCB: function (index, subIndex, bDim) {
        Volt.log('[contextMenuPopup.js] index is ' + index + ', subIndex is ' + subIndex + ', bDim is ' + bDim);
        if (bDim) {
            Volt.log('[contextMenuPopup.js] this item is dimmed');
            return;
        }
        if (this.option.type == 'myapps' && this.option.feature == 1 && index == 0 && this.option.is_removable == true) {
            Volt.log('[contextMenuPopup.js] EVENT_MY_APPS_SINGLE_DELETE ' + this.option.appInfoVM.get('app_id'));
            this.select_delete = true;
            EventMediator.trigger(CommonDefines.Event.EVENT_MY_APPS_SINGLE_DELETE, this.option.appInfoVM.get('app_id'));

            Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                d: {
                    cmn: 'delete'
                }
            });
        } else if (this.option.type == 'myapps' && this.option.feature == 1 && index == 0 && this.option.is_removable == false) {
            if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                return;
            } else {
                Backbone.history.navigate('detail/' + this.option.appInfoVM.get('app_id'), {
                    trigger: true
                });

                Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                    d: {
                        cmn: 'viewdetail'
                    }
                });
            }
        } else if (this.option.type == 'myapps' && this.option.feature == 1 && index == 1) {
            if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                return;
            } else {
                Backbone.history.navigate('detail/' + this.option.appInfoVM.get('app_id'), {
                    trigger: true
                });

                Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                    d: {
                        cmn: 'viewdetail'
                    }
                });
            }
        } else if (this.option.type == 'myapps' && this.option.feature == 2 && index == 0) {
            AppInstallMgr.installApp(this.option.appInfoVM.get('app_id'), "");

            Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                d: {
                    cmn: 'reinstall'
                }
            });
        } else if (index == 0) {
            Volt.log(DownloadedAppsMgr.isDownloaded(this.option.appInfoVM.get('id')));

            if (DownloadedAppsMgr.isDownloaded(this.option.appInfoVM.get('id')) == true) {
                AppInstallMgr.launchApp(this.option.appInfoVM.get('id'), "");
                EventMediator.trigger('HOMEVIEW_LAUNCH_APP');

                switch (this.option.type) {
                case 'whatsNew':
                    Volt.KpiMapper.addEventLog('SELECTLONGPRESSWN', {
                        d: {
                            cmn: 'open'
                        }
                    });
                    break;
                case 'mostPopular':
                    Volt.KpiMapper.addEventLog('SELECTLONGPRESSMP', {
                        d: {
                            cmn: 'open'
                        }
                    });
                    break;
                case 'categories':
                default:
                    Volt.KpiMapper.addEventLog('SELECTLONGPRESSSC', {
                        d: {
                            cmn: 'open'
                        }
                    });
                    break;
                }
            } else {
                if (AppInstallMgr.getInstallList(this.option.appInfoVM.get('id')).app_id == undefined) {

                    this.option.parentView.installApp();

                    switch (this.option.type) {
                    case 'whatsNew':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSWN', {
                            d: {
                                cmn: 'download'
                            }
                        });
                        break;
                    case 'mostPopular':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSMP', {
                            d: {
                                cmn: 'download'
                            }
                        });
                        break;
                    case 'categories':
                        //fall through
                    default:
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSSC', {
                            d: {
                                cmn: 'download'
                            }
                        });
                        break;
                    }
                } else {
                    this.option.parentView.cancelInstallApp();

                    switch (this.option.type) {
                    case 'whatsNew':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSWN', {
                            d: {
                                cmn: 'cancel'
                            }
                        });
                        break;
                    case 'mostPopular':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSMP', {
                            d: {
                                cmn: 'cancel'
                            }
                        });
                        break;

                    case 'categories':
                        //fall through
                    default:
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSSC', {
                            d: {
                                cmn: 'cancel'
                            }
                        });
                        break;
                    }
                }
            }
        }
        this.hide();
    },

    onContextMenuFocusChange: function (preIndex, preSubIndex, curIndex, curSubIndex, bDim) {
        Volt.log("[contextMenuPopup.js] onOptionMenuFocusChange ::: " + preIndex + ',' + preSubIndex + ',' + curIndex + ',' + curSubIndex + ',' + bDim);
        //var voiceText;
        //CommonFunctions.voiceGuide(voiceText);
    },


    listenToSucessEvent: function () {
        var self = this;
        _.each(this.successEvent, function (eventType, i) {
            self.listenTo(EventMediator, eventType, self.processSuccessEvent);
        });
    },

    listenToFailEvent: function () {
        var self = this;
        _.each(this.failEvent, function (eventType, i) {
            self.listenTo(EventMediator, eventType, self.processFailEvent);
        });
    },

    stopListenToEvent: function (eventList) {
        var self = this;
        if (eventList == null) {
            this.stopListenToEvent(this.successEvent);
            this.stopListenToEvent(this.failEvent);
        } else {
            _.each(eventList, function (eventType, i) {
                self.stopListening(EventMediator, eventType);
            });
        }
    },

    processSuccessEvent: function (data) {
        Volt.log('[contextMenuPopup] get download complete event');
        if (this.contextMenuPopup && this.option.appInfoVM.get('id') == data.app_id) {
            this.contextMenuPopup.setListText(0, Volt.i18n.t('UID_OPEN'));
        }
    },

    processFailEvent: function (data) {
        Volt.log('[contextMenuPopup] get parse error event');
        if (this.contextMenuPopup && this.option.appInfoVM.get('id') == data.app_id) {
            this.contextMenuPopup.setListText(0, Volt.i18n.t('COM_SID_DOWNLOAD'));
        }
    },

    hide: function () {
        Volt.log('[contextMenuPopup.js] hide');
        if (this.contextMenuPopup) {
            this.contextMenuPopup.hide();
            this.contextMenuPopup.destroy();
            this.contextMenuPopup = null;
        }
        this.stopListenToEvent();

        if (this.select_delete == false) {
            winsetDimView.hide();
        }

        //Volt.Nav.endModal();

        EventMediator.off(CommonDefines.Event.EVENT_CLOSE_POPUP, this.hide, this);
        EventMediator.off(CommonDefines.Event.EVENT_LONGPRESS_RELEASE, this.focusmenu, this);
    },


    focusmenu: function () {
        Volt.log('[contextMenuPopup] ~~~~~~~focusmenu~~~~~~~~~~~');
        this.contextMenuPopup.setFocus();

    }
});

exports = new ContextMenuPopup;