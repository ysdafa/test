/** 
 * @author hyoseon Ju (hyoseon.ju@samsung.com)
 * @fileoverview This module show connected usb list in tv.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var _ = Volt.require('modules/underscore.js')._,
    Backbone = Volt.require('modules/backbone.js'),
    VoltJSON = Volt.require('modules/VoltJSON.js');

// Include Template
var Template = Volt.require('app/templates/1080/updateAppsTemplate.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    AppInstallMgr = Volt.require("app/common/appInstallMgr.js"),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js'),
    CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var LOADING_MARING = 10;
var nFPS = 15;
var nInterval = Math.floor(1000 / nFPS);

var Models = Volt.require("app/models/models.js");

var WinsetLoading = Volt.require('WinsetUIElement/winsetLoading.js');
Volt.mapWidget('WinsetLoading', WinsetLoading);
var WinsetButton = Volt.require("WinsetUIElement/winsetButton.js");
var PanelCommon = Volt.require('lib/panel-common.js');
PanelCommon.mapWidget('WinsetButton', WinsetButton);
var Singlelist = Volt.require('app/views/singlelineListView.js');
PanelCommon.mapWidget('Singlelist', Singlelist);
var tvResoultion = (Volt.APPS720P) ? WinsetButton.ResoultionStyle.Resoultion_720 : WinsetButton.ResoultionStyle.Resoultion_1080;

function pad(num, size) {
    var s = num.toString();
    while (s.length < size) {
        s = "0" + s;
    }
    return s;
}

/**
 * @name UpdateAppsView
 */
var UpdateAppsView = Volt.BaseView.extend({
    /** @lends UpdateAppsView.prototype */
    template: Template.container,

    updateAppInfoView: null,
    loadingInterval: 0,

    wzLoadingIcon: null,

    /**
     * Initialize UpdateAppsView
     * @name UpdateAppsView
     * @constructs
     */
    initialize: function () {
        Volt.log("[UpdateAppsView.js] initialize");
    },

    /**
     * Render this widget
     * @method
     * @memberof UpdateAppsView
     */
    render: function () {
        Volt.log("[UpdateAppsView.js] render");
    },

    /**
     * Show this widget, fetch usbListm and bind event
     * @method
     * @memberof UpdateAppsView
     */
    show: function () {
        Volt.log("[UpdateAppsView.js] show");
        EventMediator.trigger('GRID_FOVEA_DISABLE');

        this.setWidget(Volt.loadTemplate(this.template));
        this.widget.show();

        this.bindListener();

        this.showLoading();
        this.renderUpdateAppsPopup();
        Volt.Nav.setRoot(this.widget);
    },

    showLoading: function () {
        Volt.log('[UpdateAppsView.js] showLoading');

        container = this.widget.getChild(0).getChild('updateApps-loading-container');
        var mustache = {
            style20: WinsetLoading.LoadingStyle.Loading_Dark_20,
            nResoultionStyle: (Volt.APPS720P) ? WinsetLoading.ResoultionStyle.Resoultion_720 : WinsetLoading.ResoultionStyle.Resoultion_1080
        }
        this.wzLoadingIcon = Volt.loadTemplate(Template.loading, mustache);

        container.addChild(this.wzLoadingIcon);
        this.wzLoadingIcon.play();

        /*var self = this,
        container = this.widget.getChild(0).getChild('updateApps-loading-container');

        var loadingIconX, loadingIconY, index;

        this.wzLoadingIcon = Volt.loadTemplate(Template.loading.icon);
        
        loadingIconX = 1920 * 0.329688;
        loadingIconY = 756 * 0.400926;

        this.wzLoadingIcon.x = loadingIconX;
        this.wzLoadingIcon.y = loadingIconY;

        container.addChild(this.wzLoadingIcon);
        index = 1;

        this.loadingInterval = Volt.setInterval(function(){
            if(index == 63){
                index = 1;
            }
            self.wzLoadingIcon.src = Volt.getRemoteUrl('images/1080/common/loading/white/20x20/loading_bright_20_'+ pad(index,2) +'.png');
            ++index;
        }, nInterval);*/
    },

    hideLoading: function () {
        Volt.log('[UpdateAppsView.js] hideLoading');

        if (!this.wzLoadingIcon) {
            Volt.log('[UpdateAppsView.js] do not have widget');
            return;
        }
        this.wzLoadingIcon.stop();
        this.wzLoadingIcon.hide();
        Volt.clearInterval(this.loadingInterval);
    },

    /**
     * Render UpdateApps Popup
     * @method
     * @memberof UpdateAppsView
     */
    renderUpdateAppsPopup: function () {
        Volt.log('[UpdateAppsView.js] renderUpdateAppsPopup');

        this.renderTitle();
        this.renderLine();
        this.renderButton();
        this.showHeaderCover();
    },

    /**
     * create titleView for rendering title
     * @method
     * @memberof UpdateAppsView
     */
    renderTitle: function () {
        Volt.log('[UpdateAppsView.js] renderTitle');

        var container = this.widget.getChild(0).getChild('updateApps-title-container');
        container.addChild(Volt.loadTemplate(Template.title));
    },

    /**
     * create lineView for rendering line
     * @method
     * @memberof USBListPopupView
     */
    renderLine: function () {
        Volt.log('[UpdateAppsView.js] renderLine');
        var container = this.widget.getChild(0).getChild('updateApps-line-container');
        container.addChild(Volt.loadTemplate(Template.line));
    },

    /**
     * create usbListView for rendering selected usb info
     * @method
     * @memberof UpdateAppsView
     */
    renderUpdateAppInfoView: function () {
        Volt.log('[UpdateAppsView.js] renderUpdateAppInfoView');
        this.hideLoading();
        var container = this.widget.getChild(0).getChild('updateApps-list-container');
        this.updateAppInfoView = new UpdateAppInfoView();
        container.addChild(this.updateAppInfoView.render(container).widget);
        container.addChild(this.updateAppInfoView.updateAppsList);
        Volt.Nav.setNextItemRule(this.btnView.widget.getChild('update-selectall-button'), 'left', this.updateAppInfoView.updateAppsList);
        Volt.Nav.setNextItemRule(this.btnView.widget.getChild('update-selectall-button'), 'up', this.btnView.widget.getChild('update-selectall-button'));
        //Volt.Nav.focus(this.updateAppInfoView.updateAppsList);
        Volt.Nav.reload();
    },

    /**
     * create buttonView for rendering cancel button
     * @method
     * @memberof UpdateAppsView
     */
    renderButton: function () {
        Volt.log('[UpdateAppsView.js] renderButton');
        var container = this.widget.getChild(0).getChild('updateApps-button-container');
        this.btnView = new ButtonView();
        container.addChild(this.btnView.render().widget);
    },
    showHeaderCover: function () {
        Volt.log('[UpdateAppsView] renderHeaderCover');

        if (this.headerCover) {
            this.headerCover.show();
            this.headerCover.addEventListener('OnMouseOver', this._blockMouse);
            return;
        }

        this.headerCover = Volt.loadTemplate(Template.headerCover);
        this.headerCover.addEventListener('OnMouseOver', this._blockMouse);
    },

    hideHeaderCover: function () {
        Volt.log('[UpdateAppsView] destroyHeaderCover');
        if (this.headerCover) {
            this.headerCover.removeEventListener('onMouseOver', this._blockMouse);
            this.headerCover.hide();
        }
    },

    _blockMouse: function () {},
    setArrow: function (flag) {
        this.widget.getDescendant('list_first_line').color = {
            r: 255,
            g: 255,
            b: 255,
            a: 26
        };
        if (flag == true) {
            Volt.log("[UpdateAppsView.js]setArrow%%%%%%%%%  true  %%%%%");

            this.widget.getDescendant('arrow_up').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png');
            this.widget.getDescendant('arrow_down').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png');
        } else {
            this.widget.getDescendant('arrow_up').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_d.png');
            this.widget.getDescendant('arrow_down').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_d.png');
        }
        var mouseListener = new MouseListener;

        mouseListener.onMousePointerIn = function (actor, event) {
            if (actor.id == 'arrow_down' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png')) {
                actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png');
            }
            if (actor.id == 'arrow_up' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png')) {
                actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png');
            }
        };
        mouseListener.onMousePointerOut = function (actor, event) {
            if (actor.id == 'arrow_down' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png')) {
                actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png');
            }
            if (actor.id == 'arrow_up' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png')) {
                actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png');
            }
        };
        mouseListener.onMouseButtonReleased = function (actor, event) {
            print('onMouseButtonReleased');
            if (actor.id == 'arrow_up') {
                ListView.updateAppsList.moveFocus('Up');
            } else {
                ListView.updateAppsList.moveFocus('Down');
            }
        };

        this.widget.getDescendant('arrow_up').addMouseListener(mouseListener);
        this.widget.getDescendant('arrow_down').addMouseListener(mouseListener);
    },
    /**
     * Hide this widget
     * @method
     * @memberof UpdateAppsView
     */
    hide: function () {
        Volt.log('[UpdateAppsView.js] hide');
        this.hideHeaderCover();
        this.unbindListener();
        this.widget.hide();
        this.destroy(this.widget);
    },

    /**
     * Destory this widget
     * @method
     * @memberof UpdateAppsView
     */
    destroy: function (widget) {
        Volt.log('[UpdateAppsView.js] destroy:');
        if (!widget) return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = 0; i < nChildLength; i++) {
                this.destroy(widget.getChild(i));
            }
        }
        widget.id = '';
        delete widget;
        widget = null;
    },

    showNotNeedUpdateAppsError: function () {
        Volt.log("[updateAppsView.js] showNotNeedUpdateAppsError");

        this.hideLoading(this.wzLoadingIcon);
        //this.hide();
        this.widget.hide();
        Backbone.history.back();
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS);
        return;
    },
    showUpdateApps: function () {
        Volt.log("[updateAppsView.js] showUpdateApps");
        //Volt.Nav.setRoot(this.widget);
        var self = this;

        if (Models.updateAppsCollection.length > 0) {
            this.renderUpdateAppInfoView();
        } else {
            Volt.setTimeout(function () {
                Volt.Nav.focus(null);
                self.showNotNeedUpdateAppsError();
            }, 1000);
        }

    },

    bindListener: function () {
        Volt.log('[updateAppsView] bindListener');
        this.listenTo(EventMediator, 'UPDATE_ARROW_STATE', this.setArrow);
        this.listenTo(Models.updateAppsCollection, 'reset', this.showUpdateApps);
        this.listenTo(EventMediator, 'COMPLETE_RENDER_UPDATEAPPS_LIST', this.hideLoading);
        //this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON,  this.processMsgBoxEvent, this);//add by yangpei 20141110
    },

    unbindListener: function () {
        Volt.log('[updateAppsView] unbindListener');
        EventMediator.trigger('GRID_FOVEA_ENABLE');
        EventMediator.off('RENDER_ALL_CHECK');
        EventMediator.off('RENDER_ALL_UNCHECK');
        EventMediator.off('REQUEST_APP_UPDATE');

        this.stopListening(EventMediator, 'UPDATE_ARROW_STATE');
        this.stopListening(EventMediator);
        this.stopListening(Models.updateAppsCollection);
    },
});

/**
 * @namespace UpdateAppsView
 * @name ButtonView
 */
var ButtonView = Volt.BaseView.extend({
    /** @lends ButtonView.prototype */

    template: Template.buttonArea,
    btnListener: new ButtonListener(),
    updateButtonEnableFlag: false,
    firstEnterFlag: true,
    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },
    /**
     * Initialize ButtonView
     * @name ButtonView
     * @constructs
     */
    initialize: function () {
        EventMediator.once(CommonDefines.Event.INSTALLING, this.buttonDim, this);
        this.listenTo(EventMediator, 'READY_TO_UPDATE', this.buttonUnDim);
        this.listenTo(EventMediator, 'NOT_READY_TO_UPDATE', this.buttonDim);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_COMPLETED, this.buttonUnDim);
    },

    /**
     * Render button
     * @method
     * @memberof ButtonView
     */
    render: function (widget) {
        Volt.log('[UpdateAppsView.buttonView] render ');

        this.widget = widget;

        this.setWidget(Volt.loadTemplate(this.template));
        var btnStyleText = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resoultion: tvResoultion,
        }
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);
        var closeBtnBG = this.widget.getChild('update-close-button');
        this.closeButton = PanelCommon.loadTemplate(Template.closeBtn, btnStyleText, closeBtnBG);
        this.closeButton.addListener(this.btnListener);
        var updateBtnBG = this.widget.getChild('update-update-button');
        this.updateButton = PanelCommon.loadTemplate(Template.updateBtn, btnStyleText, updateBtnBG);
        this.updateButton.addListener(this.btnListener);
        var deselectAllBtnBG = this.widget.getChild('update-deselectall-button');
        this.deselectAllButton = PanelCommon.loadTemplate(Template.deselectAllBtn, btnStyleText, deselectAllBtnBG);
        this.deselectAllButton.addListener(this.btnListener);
        var selectAllBtnBG = this.widget.getChild('update-selectall-button');
        this.selectAllButton = PanelCommon.loadTemplate(Template.selectAllBtn, btnStyleText, selectAllBtnBG);
        this.selectAllButton.addListener(this.btnListener);
        //Volt.Nav.focus(this.widget.getChild('update-selectall-button'));
        this.buttonDim();
        return this;
    },

    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onSelect: function (widget) {
        Volt.log('[updateAppsView.buttonView] onSelect');

        /*if (widget) {

            widget.color = Volt.hexToRgb('#ffffff', 0);

            widget.getChild(0).font = '36px';
            widget.getChild(0).textColor = Volt.hexToRgb('#e9b321', 100);

            widget.border = {
                width : 2 , color :  Volt.hexToRgb('#ffc21f', 60)
            }

        }*/

        switch (widget.id) {
        case 'updateBtn':
            EventMediator.trigger('REQUEST_APP_UPDATE');

            break;

        case 'selectAllBtn':
            EventMediator.trigger('RENDER_ALL_CHECK');
            break;

        case 'deselectAllBtn':
            EventMediator.trigger('RENDER_ALL_UNCHECK');
            break;

        case 'closeBtn':

            Backbone.history.back();
            break;
        }
    },

    /**
     * When focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        Volt.log('[updateAppsView.buttonView] onFocus');
        /*if (widget){
            widget.color = Volt.hexToRgb('#ffffff', 95);
            widget.getChild(0).textColor = Volt.hexToRgb('#464646', 100);
            widget.getChild(0).font = '36px';
            widget.border  = {
                width : 2 , color :  Volt.hexToRgb('#ffffff', 95)
            }
        }*/
        var voiceText = '';
        switch (widget.id) {
        case 'update-update-button':
            this.updateButton.setFocus();
            if (this.updateButtonEnableFlag) {
                voiceText = Volt.i18n.t('UID_UPDATE') + ',' +
                    Volt.i18n.t('TV_SID_BUTTON');
            } else {
                voiceText = Volt.i18n.t('UID_UPDATE') + ',' +
                    Volt.i18n.t('TV_SID_BUTTON') + ',' +
                    Volt.i18n.t('TV_SID_DISABLED');
            }
            break;

        case 'update-selectall-button':
            this.selectAllButton.setFocus();

            if (this.firstEnterFlag) {
                voiceText = Volt.i18n.t('COM_TV_SID_UPDATE_APPS_KR_SINGULAR') +
                    Volt.i18n.t('COM_SID_SELECT_ALL') + ',' +
                    Volt.i18n.t('TV_SID_BUTTON');
                this.firstEnterFlag = false;
            } else {
                voiceText = Volt.i18n.t('COM_SID_SELECT_ALL') + ',' +
                    Volt.i18n.t('TV_SID_BUTTON');
            }
            break;

        case 'update-deselectall-button':
            this.deselectAllButton.setFocus();
            voiceText = Volt.i18n.t('UID_DESELECT_ALL') + ',' +
                Volt.i18n.t('UID_DESELECT_ALL');
            break;

        case 'update-close-button':
            this.closeButton.setFocus();
            voiceText = Volt.i18n.t('COM_SID_CLOSE') + ',' +
                Volt.i18n.t('TV_SID_BUTTON');
            break;
        }
        CommonFunctions.voiceGuide(voiceText);
    },

    /**
     * When blured focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param   {object}  widget  blured widget
     */
    onBlur: function (widget) {
        /*if (widget) {
            widget.color = Volt.hexToRgb('#ffffff', 0);
            widget.getChild(0).textColor = Volt.hexToRgb('#ffffff', 80);
            widget.getChild(0).font = '32px';
            widget.border = {
                width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
            }
        }*/
        switch (widget.id) {
        case 'update-update-button':
            this.updateButton.killFocus();
            break;

        case 'update-selectall-button':
            this.selectAllButton.killFocus();
            break;

        case 'update-deselectall-button':
            this.deselectAllButton.killFocus();
            break;

        case 'update-close-button':
            this.closeButton.killFocus();
            break;
        }
    },

    buttonDim: function () {
        Volt.log('[UpdateAppsView.buttonView] buttonDim ');

        var btnUpdate = this.widget.getChild('update-update-button');

        if (btnUpdate) {

            /*btnUpdate.color = Volt.hexToRgb('#ffffff', 0);
            btnUpdate.getChild(0).textColor = Volt.hexToRgb('#ffffff', 30);
            btnUpdate.getChild(0).font = '32px';
            btnUpdate.border  = {
                width : 2 , color :  Volt.hexToRgb('#ffffff', 30)
            }
			 btnUpdate.custom.focusable = false;
			*/
            this.updateButton.enable(false);
            this.updateButtonEnableFlag = false;
            this.widget.getChild('update-update-button').custom = {
                focusable: false
            };

        }

        Volt.Nav.reload();
    },

    buttonUnDim: function () {
        Volt.log('[UpdateAppsView.buttonView] buttonUnDim ');

        var btnUpdate = this.widget.getChild('update-update-button');

        if (btnUpdate) {

            /*btnUpdate.color = Volt.hexToRgb('#ffffff', 0);
            btnUpdate.getChild(0).textColor = Volt.hexToRgb('#ffffff', 80);
            btnUpdate.getChild(0).font = '32px';
            btnUpdate.border  = {
                width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
            }
                        
            btnUpdate.custom.focusable = true;*/
            this.updateButton.enable(true);
            this.updateButtonEnableFlag = true;
            this.widget.getChild('update-update-button').custom = {
                focusable: true
            };
        }
        Volt.Nav.reload();
    }
});

var WIDTH_TOTAL = 1050;
var WIDTH_CONTEXTMENU = 800;



/**
 * @name updateAppInfoView
 */
var UpdateAppInfoView = Volt.BaseView.extend({
    /** @lends UpdateAppInfoView.prototype */
    updateAppsList: null,
    dataCollection: null,
    aRequestAppList: null,
    dataPointers: [],
    /**
     * Initialize UpdateAppInfoView
     * @name UpdateAppInfoView
     * @constructs
     */
    initialize: function (appInfo) {
        print('[updateAppInfoView] initialize');

        EventMediator.on('RENDER_ALL_CHECK', this.renderAllCheck, this);
        EventMediator.on('RENDER_ALL_UNCHECK', this.renderAllUnCheck, this);
        EventMediator.on('REQUEST_APP_UPDATE', this.requestUpdateApps, this);

        ListView = this;
    },

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    onFocus: function (widget) {

        print("updateList onFocus");
        this.updateAppsList.enableFocus();
        this.updateAppsList.setFocus();
        print("updateList onFocus updateAppsList.showFocus");
        this.updateAppsList.showFocus("true");
        this.updateAppsList.onMoveIn();

    },

    onBlur: function (widget) {
        print("updateList onBlur");
        this.updateAppsList.onMoveOut();
        /*if(widget){
            this.updateAppsList.hideFocus("true");
            this.updateAppsList.killFocus();
        }*/
    },
    /**
     * Render updateList to use ContextMenu
     * @method
     * @memberof updateList
     * @param  {object}  widget  focued widget
     */
    render: function (parent) {
        print('[updateListView] render');

        this.updateAppsList = initList(parent);

        //this.updateList.appID = this.appID;
        this.setWidget(this.updateAppsList);
        Volt.Nav.reload();
        return this;
    },
    renderAllCheck: function () {
        this.updateAppsList.allCheck();
    },

    renderAllUnCheck: function () {
        this.updateAppsList.allUncheck();
    },
    requestUpdateApps: function () {
        this.aRequestAppList = Models.updateAppsCollection.where({
            is_checked: true
        });

        var aRequestAppIdList = [];

        _.each(this.aRequestAppList, function (models) {
            var sAppId = models.get('app_id');
            aRequestAppIdList.push(sAppId);
        });

        AppInstallMgr.updateApp(aRequestAppIdList);
        Volt.KpiMapper.addEventLog('UPDATEAPPS', {
            d: {
                appid: aRequestAppIdList,
                san: aRequestAppIdList.length
            }
        });

        Backbone.history.back();
    },
});

function initList(parent) {
    var list = PanelCommon.loadTemplate(Template.list, null, parent).render().widget;
    list.custom = {};
    list.custom.focusable = true;

    Volt.Nav.setNextItemRule(list, 'up', list);
    Volt.Nav.setNextItemRule(list, 'down', list);
    /*test_array = [
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.01",app_size:100000,app_title:'text1',is_selected:false,is_checked:false,updated_date:"2008T06T24"},
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.02",app_size:200000,app_title:'text2',is_selected:false,is_checked:false,updated_date:"2008T06T24"},
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.02",app_size:30000,app_title:'text3',is_selected:false,is_checked:false,updated_date:"2008T06T24"},
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.02",app_size:50000,app_title:'text4',is_selected:false,is_checked:false,updated_date:"2008T06T24"},
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.03",app_size:40000,app_title:'text5',is_selected:false,is_checked:false,updated_date:"2008T06T24"},
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.06",app_size:40000,app_title:'text6',is_selected:false,is_checked:false,updated_date:"2008T06T24"},
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.07",app_size:40000,app_title:'text7',is_selected:false,is_checked:false,updated_date:"2008T06T24"},
	{app_icon:"images/1080/common/btn_icon_favorite_on.png",app_version:"1.08",app_size:40000,app_title:'text8',is_selected:false,is_checked:false,updated_date:"2008T06T24"}];
	var test_ListModel = Backbone.Model.extend({
		defaults : {
			  'app_icon' : null, 
			  'app_size' : null,
			  'app_title' : null,
			  'is_selected': null,
			  'is_checked' : null,
			  'app_version' :null,
			  'updated_date' :null,
		},
	});
	var test_Collection = Backbone.Collection.extend({
		model : test_ListModel,
	});
	test_updateAppsCollection = new test_Collection;
	test_updateAppsCollection.add(test_array);
	print("test_updateAppsCollection"+JSON.stringify(test_updateAppsCollection));
    var updateApps = test_array;
	Models.updateAppsCollection = test_updateAppsCollection;*/
    if (Models.updateAppsCollection.length > 4) {
        EventMediator.trigger('UPDATE_ARROW_STATE', true);
    } else {
        EventMediator.trigger('UPDATE_ARROW_STATE', false);
    }
    // print('updateApps.length - ' + Models.updateAppsCollection.length+"test_array.length:"+test_array.length);
    list.addItem({
        itemNum: Models.updateAppsCollection.length,
        itemSpace: Volt.height * 0.133333
    });

    list.setBackgroundColor(0, 0, 0, 0);
    list.shadowEffectFlag = false;
    list.setAnimationDuration("focusMove", 100);
    list.setAnimationDuration("loop", 100);
    list.foveaEffect = false;
    //list.setScrollBar(chooseDevicePopupSelf.widget.getChild('devices-container'), updateApps.length);
    list.show();

    list.initRenderer = function (renderer, data, parentWidth, parentHeight) {
        //print('data - ' + JSON.stringify(data)+renderer);
        PanelCommon.loadTemplate(Template.UpdateItem, null, renderer.root);
        renderer.thumbnail = renderer.root.getChild(0);
    };
    list.onDrawLoadData = function (render, data, parentWidth, parentHeight) {
        //print('onDrawLoadData'+list.numOfItem()+"data.index"+data.index);
        var index = list.renderIndex;
        if (data == null) {
            //if (index>list.numOfItem()) return;
            render.thumbnail.setInformationText("text1", Models.updateAppsCollection.at(index).get("app_title"));
            var versionInfo = 'v' + Models.updateAppsCollection.at(index).get("app_version") + '  ' + convertDateFormat(Models.updateAppsCollection.at(index).get("updated_date"));
            render.thumbnail.setInformationText("text2", versionInfo);

            render.thumbnail.setInformationText("text3", __convertMemory(Models.updateAppsCollection.at(index).get("app_size")));
            render.thumbnail.setInformationIcon("icon1", Models.updateAppsCollection.at(index).get("app_icon"));
            render.thumbnail.setInformationIcon("icon2", "images/1080/common/check/popup_check_box.png");
            //print('@@@@@@@@@@@@@@@@@@@@@@@list.onDrawLoadData  data  is    '+index+updateApps[index].app_title);
        } else {
            var mustache = {
                imgUrl: data.app_icon,
                title: data.app_title,
                size: data.app_size,
                version: data.app_version,
                date: data.updated_date,
            };

            //print('@@@@@@@@@@@@@@@@@@@@@@@list.onDrawLoadData  data  is    '+data.app_title);
            render.thumbnail.setInformationText("text1", data.app_title);
            var versionInfo = 'v' + data.app_version + '  ' + convertDateFormat(data.updated_date);
            render.thumbnail.setInformationText("text2", versionInfo);
            render.thumbnail.setInformationText("text3", data.app_size);
            render.thumbnail.setInformationIcon("icon1", data.app_icon);
            render.thumbnail.setInformationIcon("icon2", "images/1080/common/check/popup_check_box.png");
        }
        var iUpdateModel = Models.updateAppsCollection.at(index);

        if (iUpdateModel.get('is_checked')) {
            render.thumbnail.setInformationIcon("icon3", "images/1080/common/check/popup_check_icon_n.png");
        } else {
            render.thumbnail.setInformationIcon("icon3", "");
        }

    };
    /*list.onItemMouseClick = function(index){
		list.onItemPress(index);
	};*/
    var listMouseListener = new MouseListener;
    listMouseListener.onMouseButtonReleased = function (actor, event) {
        print('onMouseButtonReleased ');
        var index = list.focusItemIndex;
        var rendrerer = list.renderer(index);
        thumbnailOnFocus(rendrerer.thumbnail, index);
    };
    listMouseListener.onMouseButtonPressed = function (actor, event) {
        print('onMouseButtonPressed  ');
        var index = list.focusItemIndex;
        list.onItemPress(index);
    };
    list.addMouseListener(listMouseListener);
    list.onItemPress = function (index) {
        print('click - list.onItemPress' + index);
        var data = list.getData(index);
        var rendrerer = list.renderer(index);
        var iUpdateModel = Models.updateAppsCollection.at(index);

        if (iUpdateModel.get('is_checked')) {
            iUpdateModel.set('is_checked', false);
            CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_UNCHECKED'));
        } else {
            iUpdateModel.set('is_checked', true);
            CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_CHECKED'));
        }
        if (iUpdateModel.get('is_selected')) {
            iUpdateModel.set('is_selected', false);
        } else {
            iUpdateModel.set('is_selected', true);
        }
        if (Models.updateAppsCollection.where({
            'is_checked': true
        }).length > 0) {
            EventMediator.trigger('READY_TO_UPDATE');
        } else {
            EventMediator.trigger('NOT_READY_TO_UPDATE');
        }
        thumbnailOnSelect(rendrerer.thumbnail, index);
        //this.updateAppsList.itemUpdate(this.updateAppsList.currentIndex, iUpdateModel);     

    };
    list.onItemRelease = function (index) {
        print('click - list.onItemRelease' + index);
        var rendrerer = list.renderer(index);
        thumbnailOnFocus(rendrerer.thumbnail, index);
    };
    list.onDrawFromFocusChangeStart = function (root, data, parentWidth, parentHeight, rendererInstance) {
        print("list.onDrawFromFocusChangeStart");
        //rendererInstance.thumbnail.setInformationText("text1", data.app_title);
    };

    list.onDrawToFocusChangeEnd = function (root, data, parentWidth, parentHeight, rendererInstance) {
        print("list.onDrawToFocusChangeEnd");
        //root.getChild(0).onFocus();
        //rendererInstance.thumbnail.setInformationIcon("icon2","images/1080/common/check/popup_check_icon_n.png");
        //rendererInstance.thumbnail.setInformationText("text1", data.app_title+'focus');

    };
    list.onFocusChanged = function (singleLineList, fromItemIndex, toItemIndex) {
        print("list.onFocusChanged");
        //singleLineList.renderer(fromItemIndex).thumbnail.setInformationText("text1", data.app_title);
        var endTotopflag = (Models.updateAppsCollection.length > 4 && fromItemIndex == (Models.updateAppsCollection.length - 1) && toItemIndex == 0);
        var topToendflag = (Models.updateAppsCollection.length > 4 && toItemIndex == (Models.updateAppsCollection.length - 1) && fromItemIndex == 0);
        if (Models.updateAppsCollection.length > 1 && !endTotopflag && !topToendflag) {
            if (fromItemIndex != -1) {
                print("fromItemIndex" + fromItemIndex);
                thumbnailOnBlur(singleLineList.renderer(fromItemIndex).thumbnail, fromItemIndex);
            }
        }
        thumbnailOnFocus(singleLineList.renderer(toItemIndex).thumbnail, toItemIndex);

        var voiceText = '';
        if (fromItemIndex < 0) {
            voiceText = Volt.i18n.t('COM_TV_SID_UPDATE_APPS_KR_SINGULAR') + ',' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', Models.updateAppsCollection.length) + ',';
        }
        if (toItemIndex >= 0 && toItemIndex < Models.updateAppsCollection.length) {
            if (Models.updateAppsCollection.at(toItemIndex).get('is_checked')) {
                voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' +
                    Volt.i18n.t('TV_SID_CHECKED') + ','
            } else {
                voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' +
                    Volt.i18n.t('TV_SID_UNCHECKED') + ','
            }
            voiceText = voiceText + Models.updateAppsCollection.at(toItemIndex).get("app_title") + ',' + Models.updateAppsCollection.at(toItemIndex).get("app_version") + ',' + Models.updateAppsCollection.at(toItemIndex).get("updated_date") + ',' + __convertMemory(Models.updateAppsCollection.at(toItemIndex).get("app_size"));
        }
        CommonFunctions.voiceGuide(voiceText);
    };
    list.onFocusChangeStart = function (singleLineList, fromItemIndex, toItemIndex) {
        print("list.onFocusChangeStart");

    };
    list.onItemLoaded = function (singleLineList, itemIndex) {
        print("list.onItemLoaded~~~~~~");
        singleLineList.renderIndex = itemIndex;
    };

    list.onMoveOut = function () {
        print("list.onMoveOut");
        var index = list.focusItemIndex;
        var rendrerer = list.renderer(index);
        thumbnailOnBlur(rendrerer.thumbnail, index);
    };
    list.onMoveIn = function () {
        print("list.onMoveIn");
        var index = list.focusItemIndex;
        var rendrerer = list.renderer(index);
        thumbnailOnFocus(rendrerer.thumbnail, index);

        var voiceText = Volt.i18n.t('COM_TV_SID_UPDATE_APPS_KR_SINGULAR') + ',' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', Models.updateAppsCollection.length) + ',';
        if (index >= 0 && index < Models.updateAppsCollection.length) {
            if (Models.updateAppsCollection.at(index).get('is_checked')) {
                voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' +
                    Volt.i18n.t('TV_SID_CHECKED') + ','
            } else {
                voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' +
                    Volt.i18n.t('TV_SID_UNCHECKED') + ','
            }
            voiceText = voiceText + Models.updateAppsCollection.at(index).get("app_title") + ',' + Models.updateAppsCollection.at(index).get("app_version") + ',' + Models.updateAppsCollection.at(index).get("updated_date") + ',' + __convertMemory(Models.updateAppsCollection.at(index).get("app_size"));
        }
        CommonFunctions.voiceGuide(voiceText);
    };
    list.allCheck = function () {
        print("list.windowStartIndex(0)" + list.windowStartIndex(0) + "list.windowStartIndex(3)" + list.windowStartIndex(3));
        var needCheckNO;
        if (Models.updateAppsCollection.length > 4) {
            needCheckNO = 4;
        } else {
            needCheckNO = Models.updateAppsCollection.length;
        }
        for (var i = list.windowStartIndex(0); i < list.windowStartIndex(0) + needCheckNO; i++) {
            var rendrerer = list.renderer(i);
            rendrerer.thumbnail.setInformationIcon("icon3", "images/1080/common/check/popup_check_icon_n.png");
        }
        for (var i = 0; i < Models.updateAppsCollection.length; i++) {
            var iUpdateModel = Models.updateAppsCollection.at(i);
            iUpdateModel.set('is_checked', true);
            iUpdateModel.set('is_selected', true);
        }
        EventMediator.trigger('READY_TO_UPDATE');

    };
    list.allUncheck = function () {
        var needCheckNO;
        if (Models.updateAppsCollection.length > 4) {
            needCheckNO = 4;
        } else {
            needCheckNO = Models.updateAppsCollection.length;
        }
        for (var i = list.windowStartIndex(0); i < list.windowStartIndex(0) + needCheckNO; i++) {
            var rendrerer = list.renderer(i);
            rendrerer.thumbnail.setInformationIcon("icon3", "");
        }
        for (var i = 0; i < Models.updateAppsCollection.length; i++) {
            var iUpdateModel = Models.updateAppsCollection.at(i);
            iUpdateModel.set('is_checked', false);
            iUpdateModel.set('is_selected', false);
        }
        EventMediator.trigger('NOT_READY_TO_UPDATE');
    };
    insertData();
    list.loadData();

    function insertData() {
        for (var i = 0; i < Models.updateAppsCollection.length; i++) {
            var data = new Data();
            print(i);
            data.app_icon = Models.updateAppsCollection.at(i).get("app_icon");
            data.app_title = Models.updateAppsCollection.at(i).get("app_title");
            data.app_version = Models.updateAppsCollection.at(i).get("app_version");
            data.updated_date = Models.updateAppsCollection.at(i).get("updated_date");
            data.app_size = __convertMemory(Models.updateAppsCollection.at(i).get("app_size"));
            ListView.dataPointers.push(data);
            list.addData(data);
        }
    };

    function __convertMemory(memory) {
        if (memory) {
            return parseFloat(memory / 1048576).toFixed(2) + "MB";
        } else {
            return 0;
        }
    };

    function convertDateFormat(date) {
        var sDate = date,
            strArray = sDate.split('T');

        return strArray[0];
    };

    function thumbnailOnBlur(thumbnail, index) {
        if (thumbnail) {
            thumbnail.setInformationIcon("icon2", "images/1080/common/check/popup_check_box.png");
            thumbnail.setInformationColor({
                r: 255,
                g: 255,
                b: 255,
                a: 0
            });
            thumbnail.setInformationTextColor("text1", {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            });
            thumbnail.setInformationTextColor("text2", {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            });
            thumbnail.setInformationTextColor("text3", {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            });
            var iUpdateModel = Models.updateAppsCollection.at(index);

            if (iUpdateModel.get('is_checked')) {
                thumbnail.setInformationIcon("icon3", "images/1080/common/check/popup_check_icon_n.png");
            } else {

                thumbnail.setInformationIcon("icon3", "");
            }
        }

    }

    function thumbnailOnFocus(thumbnail, index) {
        if (thumbnail) {
            thumbnail.setInformationIcon("icon2", "images/1080/common/check/popup_check_box_f.png");
            thumbnail.setInformationColor({
                r: 255,
                g: 255,
                b: 255,
                a: 255
            });
            thumbnail.setInformationTextColor("text1", {
                r: 0,
                g: 0,
                b: 0,
                a: 255
            });
            thumbnail.setInformationTextColor("text2", {
                r: 0,
                g: 0,
                b: 0,
                a: 255
            });
            thumbnail.setInformationTextColor("text3", {
                r: 0,
                g: 0,
                b: 0,
                a: 255
            });
            var iUpdateModel = Models.updateAppsCollection.at(index);

            if (iUpdateModel.get('is_checked')) {
                thumbnail.setInformationIcon("icon3", "images/1080/common/check/popup_check_icon_f.png");
            } else {

                thumbnail.setInformationIcon("icon3", "");
            }
        }

    }

    function thumbnailOnSelect(thumbnail, index) {
        if (thumbnail) {
            thumbnail.setInformationIcon("icon2", "images/1080/common/check/popup_check_box_s.png");
            thumbnail.setInformationColor({
                r: 255,
                g: 255,
                b: 255,
                a: 0
            });
            thumbnail.setInformationTextColor("text1", {
                r: 250,
                g: 191,
                b: 10,
                a: 255
            });
            thumbnail.setInformationTextColor("text2", {
                r: 250,
                g: 191,
                b: 10,
                a: 255
            });
            thumbnail.setInformationTextColor("text3", {
                r: 250,
                g: 191,
                b: 10,
                a: 255
            });
            var iUpdateModel = Models.updateAppsCollection.at(index);

            if (iUpdateModel.get('is_checked')) {
                thumbnail.setInformationIcon("icon3", "images/1080/common/check/popup_check_icon_s.png");
            } else {

                thumbnail.setInformationIcon("icon3", "");
            }
        }

    }
    /*if(storages.length > 4){
        popupDevicesView.upArrow.show();
        popupDevicesView.downArrow.show();
    } else {
        popupDevicesView.upArrow.hide();
        popupDevicesView.downArrow.hide();
    }*/

    return list;
}
exports = UpdateAppsView;