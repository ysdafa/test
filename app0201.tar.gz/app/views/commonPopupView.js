/** 
 * @author hyoseon Ju (hyoseon.ju@samsung.com)
 * @fileoverview This module show connected usb list in tv.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var _ = Volt.require('modules/underscore.js')._,
    Backbone = Volt.require('modules/backbone.js'),
    VoltJSON = Volt.require('modules/VoltJSON.js');

// Include Template
var Template = Volt.require('app/templates/1080/developModeSetTemplate.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js');
CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var voltapi = Volt.require('voltapi.js');
var WinsetButton = Volt.require("WinsetUIElement/winsetButton.js");
var WinsetInputBox = Volt.require("WinsetUIElement/winsetInputBox.js");
var PanelCommon = Volt.require('lib/panel-common.js');
PanelCommon.mapWidget('WinsetButton', WinsetButton);
PanelCommon.mapWidget('WinsetInputBox', WinsetInputBox);
var tvResoultion = (Volt.APPS720P) ? WinsetButton.ResoultionStyle.Resoultion_720 : WinsetButton.ResoultionStyle.Resoultion_1080;

/**
 * @name UpdateAppsView
 */
var UpdateAppsView = Volt.BaseView.extend({
    /** @lends UpdateAppsView.prototype */
    template: Template.container,
    btnListener: new ButtonListener(),
    binputBox: [],
    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },
    /**
     * Initialize UpdateAppsView
     * @name UpdateAppsView
     * @constructs
     */
    initialize: function () {
        print("[UpdateAppsView.js] initialize");
    },

    /**
     * Render this widget
     * @method
     * @memberof UpdateAppsView
     */
    render: function () {
        Volt.log("[UpdateAppsView.js] render");

    },

    /**
     * Show this widget, fetch usbListm and bind event
     * @method
     * @memberof UpdateAppsView
     */
    show: function () {
        Volt.log("[UpdateAppsView.js] show");
        this.setWidget(Volt.loadTemplate(this.template));
        this.renderTitle();
        this.renderInputBox();
        this.renderButton();
        this.dimButton();
        Volt.Nav.setNextItemRule(this.widget.getDescendant('set-on-button'), 'down', this.widget.getDescendant('set-inpux-button1'));
        Volt.Nav.setNextItemRule(this.widget.getDescendant('set-off-button'), 'down', this.widget.getDescendant('set-inpux-button1'));

        this.widget._navOnKeyEvent = _.bind(function (keycode, type) {
            if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS) {

                Volt.log('[commonPopupView.js] return');
                Backbone.history.back();
                return true;
            }
        }, this);
        this.widget.show();
        Volt.Nav.setRoot(this.widget);
    },
    /**
     * create titleView for rendering title
     * @method
     * @memberof UpdateAppsView
     */
    renderTitle: function () {
        Volt.log('[UpdateAppsView.js] renderTitle');

        var container = this.widget.getChild(0).getChild('updateApps-title-container');
        container.addChild(Volt.loadTemplate(Template.title));
    },
    /**
     * create buttonView for rendering cancel button
     * @method
     * @memberof UpdateAppsView
     */
    renderButton: function () {
        Volt.log('[UpdateAppsView.js] renderButton');
        var btnStyleText = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resoultion: tvResoultion,
        }
        this.btnListener.onButtonClicked = function (button, type) {
            Volt.log('[commonPopupView.js] onButtonClicked');
            this.onSelect(button);
        }.bind(this);
        var onBtnBG = this.widget.getDescendant('set-on-button');
        this.onButton = PanelCommon.loadTemplate(Template.onBtn, btnStyleText, onBtnBG);
        this.onButton.addListener(this.btnListener);
        var offBtnBG = this.widget.getDescendant('set-off-button');
        this.offButton = PanelCommon.loadTemplate(Template.offBtn, btnStyleText, offBtnBG);
        this.offButton.addListener(this.btnListener);
        var okBtnBG = this.widget.getDescendant('set-ok-button');
        this.okButton = PanelCommon.loadTemplate(Template.okBtn, btnStyleText, okBtnBG);
        this.okButton.addListener(this.btnListener);
        var cancelBtnBG = this.widget.getDescendant('set-cancel-button');
        this.cancelButton = PanelCommon.loadTemplate(Template.cancelBtn, btnStyleText, cancelBtnBG);
        this.cancelButton.addListener(this.btnListener);
    },
    dimButton: function () {
        var developMode = voltapi.vconf.getValue(CommonDefines.Vconf.DB_DEVELOP_MODE);
        Volt.log('[commonPopupView.js] developMode is ' + developMode);
        if (developMode) {
            if ('0' == developMode) {
                this.onButton.enable(true);
                this.widget.getDescendant('set-on-button').custom = {
                    focusable: true
                };
                this.offButton.enable(false);
                this.widget.getDescendant('set-off-button').custom = {
                    focusable: false
                };
                this.widget.getChild(0).getChild('updateApps-title-container').getChild(0).getChild(0).text = "Developer mode : Off";

            } else if ('1' == developMode) {
                this.onButton.enable(false);
                this.widget.getDescendant('set-on-button').custom = {
                    focusable: false
                };
                this.offButton.enable(true);
                this.widget.getDescendant('set-off-button').custom = {
                    focusable: true
                };
                Volt.Nav.reload();
                this.widget.getChild(0).getChild('updateApps-title-container').getChild(0).getChild(0).text = "Developer mode : On";
            }
        } else {
            this.onButton.enable(true);
            this.widget.getDescendant('set-on-button').custom = {
                focusable: true
            };
            this.offButton.enable(false);
            this.widget.getDescendant('set-off-button').custom = {
                focusable: false
            };
            this.widget.getChild(0).getChild('updateApps-title-container').getChild(0).getChild(0).text = "Developer mode : Off";
        }
        Volt.Nav.reload();
    },
    renderInputBox: function () {
        var inputBoxStyleText = {
            style: WinsetInputBox.InputBoxStyle.InputBox_Style_E_Left,
            nResoultionStyle: tvResoultion,
            id: ''
        }
        var inputBoxBtn = this.widget.getDescendant('set-inpux-button1');
        inputBoxStyleText.id = 'inputBox1';
        this.binputBox[0] = PanelCommon.loadTemplate(Template.inputBox, inputBoxStyleText, inputBoxBtn);
        this.initInputBox(this.binputBox[0]);

        inputBoxBtn = this.widget.getDescendant('set-inpux-button2');
        inputBoxStyleText.id = 'inputBox2';
        this.binputBox[1] = PanelCommon.loadTemplate(Template.inputBox, inputBoxStyleText, inputBoxBtn);
        this.initInputBox(this.binputBox[1]);

        inputBoxBtn = this.widget.getDescendant('set-inpux-button3');
        inputBoxStyleText.id = 'inputBox3';
        this.binputBox[2] = PanelCommon.loadTemplate(Template.inputBox, inputBoxStyleText, inputBoxBtn);
        this.initInputBox(this.binputBox[2]);

        inputBoxBtn = this.widget.getDescendant('set-inpux-button4');
        inputBoxStyleText.id = 'inputBox4';
        this.binputBox[3] = PanelCommon.loadTemplate(Template.inputBox, inputBoxStyleText, inputBoxBtn);
        this.initInputBox(this.binputBox[3]);
    },
    initInputBox: function (inputBox) {

        inputBox.setPosition(0, 0, 0);
        inputBox.setText("");
        inputBox.setImage("normal", Volt.getRemoteUrl('images/1080/common/input/input_box_n.png'));
        inputBox.setImage("focus", Volt.getRemoteUrl('images/1080/common/input/input_box_f.png'));
        inputBox.setTextColor("normal", 64, 64, 64, 204);
        inputBox.setTextColor("focus", 33, 158, 230, 255);
        inputBox.setTextHAlignment("left");
        inputBox.setSelectionColor(100, 100, 0, 100);
        inputBox.setCursorColor(96, 96, 96, 255);
        inputBox.setFont("Sans 30px");
        inputBox.setFontSize(30);
        inputBox.setTextMaxCount(3);
        inputBox.show();
    },
    /**
     * Hide this widget
     * @method
     * @memberof UpdateAppsView
     */
    hide: function () {
        Volt.log('[UpdateAppsView.js] hide');
        this.widget.hide();
        this.destroy(this.widget);
    },
    processMsgBoxEvent: function (data) {
        Volt.log('[myAppsView] processMsgBoxEvent:type is:' + data.msgBoxtype + " eventType is:" + data.eventType);

        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP:
                Volt.log('[myAppsView] processMsgBoxEvent: ok' + data.appID);
                this.stopListening(EventMediator, CommonDefines.Event.MSGBOX_BUTTON);
                Backbone.history.back();
                break;
            default:
                break;
            }
        }
    },
    configIp: function () {
        Volt.log('[commonPopupView.js] configIp');
        var ipData = this.binputBox[0].text() + '.' + this.binputBox[1].text() + '.' + this.binputBox[2].text() + '.' + this.binputBox[3].text();
        Volt.log('[commonPopupView.js] configIp: ipData is ' + ipData);
        var developMode = voltapi.vconf.getValue(CommonDefines.Vconf.DB_DEVELOP_MODE);
        Volt.log('[commonPopupView.js] developMode is ' + developMode);
        var info = {};
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
        if (developMode) {
            if ('1' == developMode) {
                this.widget.hide();
                voltapi.vconf.setValue(CommonDefines.Vconf.DB_DEVELOP_IP, ipData);
                info.message = "Please reboot for applying develop mode"
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP, info);
            } else {
                this.widget.hide();
                info.message = "developMode is in Off status"
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP, info);
            }
        } else {
            this.widget.hide();
            info.message = "developMode is in Off status"
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP, info);
        }
    },
    /**
     * Destory this widget
     * @method
     * @memberof UpdateAppsView
     */
    destroy: function (widget) {
        Volt.log('[UpdateAppsView.js] destroy');

        if (!widget) return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = 0; i < nChildLength; i++) {
                this.destroy(widget.getChild(i));
            }
        }
        widget.id = '';
        delete widget;
        widget = null;
    },
    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onSelect: function (widget) {
        Volt.log('[commonPopupView.buttonView] onSelect :widget .id is ' + widget.id);

        switch (widget.id) {
        case 'onBtn':
            this.onButton.enable(false);
            this.widget.getDescendant('set-on-button').custom = {
                focusable: false
            };
            this.offButton.enable(true);
            this.offButton.setFocus();
            this.widget.getDescendant('set-off-button').custom = {
                focusable: true
            };
            voltapi.vconf.setValue(CommonDefines.Vconf.DB_DEVELOP_MODE, 1);

            this.widget.getChild(0).getChild('updateApps-title-container').getChild(0).getChild(0).text = "Developer mode : On";
            Volt.log('[commonPopupView.buttonView] voltapi.vconf.setValue 1');
            Volt.Nav.reload();
            break;
        case 'offBtn':
            this.offButton.enable(false);
            this.widget.getDescendant('set-off-button').custom = {
                focusable: false
            };
            this.onButton.enable(true);
            this.onButton.setFocus();
            this.widget.getDescendant('set-on-button').custom = {
                focusable: true
            };
            voltapi.vconf.setValue(CommonDefines.Vconf.DB_DEVELOP_MODE, 0);
            this.widget.getChild(0).getChild('updateApps-title-container').getChild(0).getChild(0).text = "Developer mode : Off";
            Volt.log('[commonPopupView.buttonView] voltapi.vconf.setValue 0');
            Volt.Nav.reload();
            break;
        case 'okBtn':
            this.configIp();
            break;
        case 'cancelBtn':
            Backbone.history.back();
            break;
        }
    },

    /**
     * When focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        Volt.log('[updateAppsView.buttonView] onFocus widget.id is ' + widget.id);
        switch (widget.id) {
        case 'set-on-button':
            this.onButton.setFocus();
            break;

        case 'set-off-button':
            this.offButton.setFocus();
            break;

        case 'set-ok-button':
            this.okButton.setFocus();
            break;

        case 'set-cancel-button':
            this.cancelButton.setFocus();
            break;
        case 'set-inpux-button1':
            this.binputBox[0].setFocus();
            break;
        case 'set-inpux-button2':
            this.binputBox[1].setFocus();
            break;
        case 'set-inpux-button3':
            this.binputBox[2].setFocus();
            break;
        case 'set-inpux-button4':
            this.binputBox[3].setFocus();
            break;
        }
    },

    /**
     * When blured focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param   {object}  widget  blured widget
     */
    onBlur: function (widget) {
        Volt.log('[updateAppsView.buttonView] onBlur widget.id is ' + widget.id);
        return;
        switch (widget.id) {
        case 'set-on-button':
            break;

        case 'set-off-button':
            break;

        case 'set-ok-button':
            break;

        case 'set-cancel-button':
            break;

        case 'set-inpux-button1':
            break;

        case 'set-inpux-button2':
            break;

        case 'set-inpux-button3':
            break;

        case 'set-inpux-button4':
            break;
        }
    },
});

exports = UpdateAppsView;