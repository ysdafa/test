/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module show selected large screenshot on detail.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var _ = Volt.require('modules/underscore.js')._;
var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('modules/backbone.js');

var Template = Volt.require("app/templates/1080/screenShotTemplate.js");
var Models = Volt.require('app/models/models.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var EventMediator = Volt.require('app/common/eventMediator.js');
var WinsetButton = Volt.require("WinsetUIElement/winsetButton.js");
var PanelCommon = Volt.require('lib/panel-common.js');
PanelCommon.mapWidget('WinsetButton', WinsetButton);
var tvResoultion = (Volt.APPS720P) ? WinsetButton.ResoultionStyle.Resoultion_720 : WinsetButton.ResoultionStyle.Resoultion_1080;
/**
 * @name screenShotPopupView
 */
var screenShotPopupView = Volt.BaseView.extend({
    /** @lends screenShotPopupView.prototype */
    curIndex: 0,
    maxLength: 0,
    nScreenShot: 0,
    destroyFlag: false,
    btnListener: new ButtonListener(),
    pageControlImage: [],

    /**
     * Initialize screenShotPopupView
     * @name screenShotPopupView
     * @constructs
     */
    initialize: function () {

    },

    events: {
        //'NAV_SELECT' : 'onSelect',
        //'NAV_SELECT #screenshot-left-arrow' : 'onSelect',
        //'NAV_SELECT #screenshot-right-arrow' : 'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * When focued button, changed border
     * @method
     * @memberof screenShotPopupView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (true == this.destroyFlag) {
            Volt.log('[screenShotPopupView.js]onFocus: view has been destryed');
            return;
        }
        if (widget) {
            switch (widget.id) {
            case 'screenshot-close-button':
                /*widget.color = Volt.hexToRgb('#ffffff', 95);
                    widget.getChild(0).font = '36px';
                    widget.border  = {
                        width : 2 , color :  Volt.hexToRgb('#ffffff', 95)
                    };
                    widget.getChild(0).textColor = Volt.hexToRgb('#464646', 100);*/
                this.closeButton.setFocus();
                CommonFunctions.voiceGuide(Volt.i18n.t('COM_SID_CLOSE') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                break;
            case 'screenshot-left-arrow':
                //widget.src = Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_l_f.png');
                //this.leftArrowButton.setFocus();
                break;
            case 'screenshot-right-arrow':
                //widget.src = Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_r_f.png');
                //this.rightArrowButton.setFocus();
                break;
            }
        }
    },

    /**
     * When blured button, changed border
     * @method
     * @memberof screenShotPopupView
     * @param  {object}  widget  blured widget
     */
    onBlur: function (widget) {
        if (true == this.destroyFlag) {
            Volt.log('[screenShotPopupView.js] onBlur:view has been destryed');
            return;
        }
        try {
            if (widget) {
                switch (widget.id) {
                case 'screenshot-close-button':
                    /*widget.color = Volt.hexToRgb('#ffffff', 0);
                        widget.getChild(0).font = '32px';
                        widget.border  = {
                            width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
                        };
                        widget.getChild(0).textColor = Volt.hexToRgb('#ffffff', 80);*/
                    this.closeButton.killFocus();
                    break;
                case 'screenshot-left-arrow':
                    //widget.src = Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_l_n.png');
                    //this.leftArrowButton.killFocus();
                    break;
                case 'screenshot-right-arrow':
                    //widget.src = Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_r_n.png');
                    //this.rightArrowButton.killFocus();
                    break;
                }
            }
        } catch (e) {
            Volt.log("[Screenshot.js] onBlur, exception: " + e);
        }
    },

    /**
     * When select button, doing return
     * @method
     * @memberof screenShotPopupView
     * @param  {object}  widget  blured widget
     */
    onSelect: function (widget) {
        print('[screenShotPopupView.js] onSelectBtn');

        if (widget) {
            switch (widget.id) {
            case 'screenShotcloseBtn':
                print('[screenShotPopupView.js] onSelect screenShotcloseBtn');
                Volt.KpiMapper.addEventLog('COUNTSCREENSHOT', {
                    d: {
                        css: this.nScreenShot
                    }
                });
                this.nScreenShot = 0;
                Backbone.history.back();
                break;
            case 'screenshot-left-arrow':
                if (this.curIndex > 0) {
                    this.curIndex--;
                } else {
                    this.curIndex = (this.maxLength - 1);
                }
                this.setScreenshot();
                break;
            case 'screenshot-right-arrow':
                if (this.curIndex < (this.maxLength - 1)) {
                    this.curIndex++;
                } else {
                    this.curIndex = 0;
                }
                this.setScreenshot();
                break;
            }
        }
    },

    /**
     * Render
     * @method
     * @memberof screenShotPopupView
     */
    render: function () {
        Volt.log('[screenShotPopupView.js] render');
    },

    /**
     * Show screenshot popup
     * @method
     * @memberof screenShotPopupView
     * @param   number  idx     index of selected screenshot.
     */
    show: function (idx) {
        var deferred = Q.defer();
        Volt.log('[screenShotPopupView.js] show idx : ' + idx);
        this.destroyFlag = false;
        this.curIndex = idx;
        if (Models.detailModel.get('screenshotList')) {
            this.maxLength = Models.detailModel.get('screenshotList').length;
        } else {
            this.maxLength = 0;
        }
        this.maxLength = Models.detailModel.get('screenshotList').length;

        this.renderScreenshot();
        this.renderPageControl();
        this.setScreenshot();
        // this.showArrows();
        this.widget.show();

        Volt.Nav.bindListener(this.widget, 'keydown', _.bind(this.onKeyDown, this));
        Volt.Nav.setRoot(this.widget);
        //Volt.Nav.focus(Volt.Nav.getItem(0));
        Volt.Nav.focus(this.widget.getDescendant('screenshot-close-button'));
        /*this.listenTo(EventMediator, 'VOLT_DEACTIVATE', function(){
            Backbone.history.back();
            Volt.KpiMapper.addEventLog('COUNTSCREENSHOT', {
                d: {
                    css : this.nScreenShot
                }
            });
        });*/

        deferred.resolve();
        return deferred.promise;
    },

    /**
     * Set screenshot template for rendering
     * @method
     * @memberof screenShotPopupView
     */
    renderScreenshot: function () {
        var wzContainer = Volt.loadTemplate(Template.container);
        //this.closeButton = wzContainer.getDescendant('screenshot-close-button');
        this.setWidget(wzContainer);
        this.widget.addEventListener('OnMouseOver', this._blockMouse);
        var btnStyle = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_F_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resoultion: tvResoultion,
        }

        if (WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA) {
            btnStyle.style = WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA;
        }

        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);

        var closeBtnBG = wzContainer.getDescendant('screenshot-close-button');
        this.closeButton = PanelCommon.loadTemplate(Template.screenShotcloseBtn, btnStyle, closeBtnBG);
        this.closeButton.addListener(this.btnListener);

        this.leftArrow = wzContainer.getDescendant('screenshot-left-arrow');
        this.rightArrow = wzContainer.getDescendant('screenshot-right-arrow');
        this.wzThumbnail = wzContainer.getDescendant('screenshot-thumbnail');

        this.leftArrow.addEventListener('OnMouseClick', function () {
            if (this.curIndex > 0) {
                this.curIndex--;
            } else {
                this.curIndex = (this.maxLength - 1);
            }
            this.setScreenshot();
        }.bind(this));
        this.rightArrow.addEventListener('OnMouseClick', function () {
            if (this.curIndex < (this.maxLength - 1)) {
                this.curIndex++;
            } else {
                this.curIndex = 0;
            }
            this.setScreenshot();
        }.bind(this));

    },

    /**
     * Handle showing screeshot image by index
     * @method
     * @memberof screenShotPopupView
     */
    setScreenshot: function () {
        Volt.log('[screenShotPopupView.js] changeScreenshot');

        if (this.nScreenShot < this.maxLength) {
            this.nScreenShot++;
        }

        if (this.wzThumbnail && Models.detailModel.get('screenshotList')) {
            var imageURL = Models.detailModel.get('screenshotList')[this.curIndex];
            this.wzThumbnail.src = imageURL.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_LARGE_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_LARGE_HEIGHT);
        }

        this.updatePageControl();
    },

    renderPageControl: function () {
        Volt.log("[screenShotPopupView.js] renderPageControl");

        /*this.pageControl = new PageControl(scene,400,50);
	 this.pageControl.setPosition(0, 500);
	 this.pageControl.setPageIndicatorImage(Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_r_f.png'));
	 this.pageControl.setPageIndicatorImageSize(100,100);
	 this.pageControl.color = {r:255,g:0,b:0,a:255};
	 //this.pageControl.setBackgroudColor(0, 125, 200, 125);
	 //this.pageControl.setPageIndicatorTintColor(255, 255, 255, 80);
	 //this.pageControl.setCurrentPageIndicatorTintColor(255, 255, 255, 200);
	 this.pageControl.setNumberOfPages(6);
	 this.pageControl.setCurrentPage(2);
	 //this.pageControl.setHideForSinglePageFlag(true);
	 this.pageControl.show();*/

        for (i = 0; i < Models.detailModel.get('screenshotList').length; i++) {
            this.pageControlImage[i] = new ImageWidgetEx({
                x: (Volt.width - Models.detailModel.get('screenshotList').length * Volt.width * 0.010417) / 2 + i * Volt.width * 0.010417,
                y: Volt.height * 0.813888,
                src: Volt.getRemoteUrl('images/1080/common/input/obe_pin_n.png'),
                parent: this.widget,
            });
            if (this.curIndex == i) {
                this.pageControlImage[this.curIndex].src = Volt.getRemoteUrl('images/1080/common/input/obe_pin_f.png');
            }
            this.pageControlImage[i].show();
        }
    },

    updatePageControl: function () {
        Volt.log("[screenShotPopupView.js] updatePageControl");
        for (i = 0; i < Models.detailModel.get('screenshotList').length; i++) {
            if (i == this.curIndex) {
                this.pageControlImage[i].src = Volt.getRemoteUrl('images/1080/common/input/obe_pin_f.png');
            } else {
                if (this.pageControlImage[i].src != Volt.getRemoteUrl('images/1080/common/input/obe_pin_n.png')) {
                    this.pageControlImage[i].src = Volt.getRemoteUrl('images/1080/common/input/obe_pin_n.png');
                }
            }
        }
    },
    /**
     * Handle key when focued screenshot thumb area
     * @method
     * @memberof screenShotPopupView
     * @param  {string}  keyCode  Volt key number
     * @param  {object}  wzFrom   Previous focued widget object
     * @param  {object}  wzTo     Cuttrent focued widget object
     */
    onKeyDown: function (keyCode, wzFrom, wzTo) {
        Volt.log('[screenShotPopupView.js] onKeyDown');
        switch (keyCode) {
        case Volt.KEY_JOYSTICK_LEFT:
            //Volt.Nav.focus(this.leftArrow);

            if (this.curIndex > 0) {
                this.curIndex--;
            } else {
                this.curIndex = (this.maxLength - 1);
            }

            this.setScreenshot();
            return {
                focus: null
            }
            break;
        case Volt.KEY_JOYSTICK_RIGHT:
            //Volt.Nav.focus(this.rightArrow);

            if (this.curIndex < (this.maxLength - 1)) {
                this.curIndex++;
            } else {
                this.curIndex = 0;
            }

            this.setScreenshot();
            return {
                focus: null
            }
            break;
        }
    },

    /**
     * Hide this widget
     * @method
     * @memberof screenShotPopupView
     */
    hide: function () {
        print('[screenShotPopupView.js] Screenshot hide ~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
        var deferred = Q.defer();
        //this.stopListening(EventMediator, 'VOLT_DEACTIVATE');
        this.widget.removeEventListener('OnMouseOver', this._blockMouse);
        this.widget.hide();
        //Volt.setTimeout(_.bind(this.destroy,this),1);
        this.destroy(this.widget);
        this.destroyFlag = true;
        deferred.resolve();
        return deferred.promise;
    },
    /**
     * destroy this widget
     * @method
     * @memberof screenShotPopupView
     
     destroy: function(){
		print('[screenShotPopupView.js] Screenshot destroy ~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
        this.widget.destroy();
 	this.destroyFlag = true;
    }*/
    destroy: function (widget) {
        Volt.log("[screenShotPopupView.js] destroy");
        if (!widget) return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = 0; i < nChildLength; i++) {
                this.destroy(widget.getChild(i));
            }
        }
        widget.id = '';
        delete widget;
        widget = null;
    },

    _blockMouse: function () {},
});

exports = screenShotPopupView;