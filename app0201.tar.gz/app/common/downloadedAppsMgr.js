/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview manages downloaded list.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require("modules/q.js"),
    voltapi = Volt.require('voltapi.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    EventMediator = Volt.require('app/common/eventMediator.js');
/**
 * DownloadedAppsMgr manages downloaded list.
 * @class
 */
var DownloadedAppsMgr = {

    downloadedAppList: [],
    sortOption: CommonDefines.WAS.VIEWMODE_CUSTOM,
    /**
     * initialize mgr
     * @method
     */
    initialize: function () {
        _.extend(this, Backbone.Events);
        this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, _.bind(this.onWASInitialized, this));
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_COMPLETED, _.bind(this.resetList, this));
        this.listenTo(EventMediator, CommonDefines.Event.APPS_SYNC_COMPLETED, _.bind(this.resetList, this));
        this.listenTo(EventMediator, CommonDefines.Event.UNINSTALL_COMPLETED, _.bind(this.resetList, this));
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_DOWNLOADED_APPS, _.bind(this.resetList, this));
    },

    /**
     * callback func. When WAS is ready, it'll be called
     * @method
     */
    onWASInitialized: function () {
        this.fetch();
    },
    /**
     * fetching server data
     * @method
     */
    fetch: function (sortOption) {
        Volt.log("[DownloadedAppsMgr.js] fetch()");

        if (sortOption) {
            this.sortOption = sortOption;
        }

        var count = voltapi.WAS.getAppCount(CommonDefines.WAS.APPS_TYPE_ALL, CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE, CommonDefines.WAS.APPS_INFO_FEATURED_ALL);
        var list = voltapi.WAS.getAppList(CommonDefines.WAS.APPS_TYPE_ALL, CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE, CommonDefines.WAS.APPS_INFO_FEATURED_ALL, this.sortOption, 0, count);

        Volt.log("[DownloadedAppsMgr.js] fetch() getAppCount : " + count);
        Volt.log("[DownloadedAppsMgr.js] fetch() getAppList : " + JSON.stringify(list));
        if (count > 0) {
            this.downloadedAppList = [];
            this.parse(list, sortOption);
        }
    },
    /**
     * parse data
     * @method
     * @param  {object} data      data obj
     * @param  {object} status    status obj
     * @param  {object} exception exception obj
     */
    parse: function (data, sortOption) {
        Volt.log("[DownloadedAppsMgr.js] parse()");

        var self = this,
            results = data;
        var strGetAppList = '| ';

        _.each(results, function (app, index) {
            try {

                if (app.app_id) {
                    strGetAppList += app.app_id + ' | ';
                }

                self.downloadedAppList.push({
                    app_featured: app.app_featured,
                    app_icon_path: app.app_icon_path,
                    app_id: app.app_id,
                    app_index: app.app_index,
                    app_installed_path: app.app_installed_path,
                    app_package_name: app.app_package_name,
                    app_panel_icon_path: app.app_panel_icon_path,
                    app_runtitle: app.app_runtitle,
                    app_size: app.app_size,
                    app_title: app.app_title,
                    app_tizen_id: app.app_tizen_id,
                    app_type: app.app_type,
                    app_version: app.app_version,
                    app_widget_category: app.app_widget_category,
                    icon_colorpick: app.icon_colorpick,
                    installState: app.installState,
                    install_date: app.install_date,
                    installed_source_type: app.installed_source_type,
                    is_display: app.is_display,
                    is_hidden: app.is_hidden,
                    is_lock: app.is_lock,
                    is_multi_screen: app.is_multi_screen,
                    is_need_update: app.is_need_update,
                    is_network: app.is_network,
                    is_premium_game: app.is_premium_game,
                    is_removable: app.is_removable,
                    is_support_gesture: app.is_support_gesture,
                    is_support_voice: app.is_support_voice,
                    is_updated: app.is_updated,
                    rating: app.rating,
                    title_font_colorpick: app.title_font_colorpick,
                    type: app.type,
                    use_count: app.use_count
                });
            } catch (e) {
                Volt.err('[DownloadedAppsMgr.js] parse error : ' + e);
                Volt.err('[DownloadedAppsMgr.js] index: ' + index);
                Volt.err(JSON.stringify(app));
                // return false;
            }
        });

        Volt.err('[GetAppList] List: ' + strGetAppList);

        if (!sortOption) {
            EventMediator.trigger(CommonDefines.Event.DOWNLOADED_MGR_READY);
        } else {
            EventMediator.trigger(CommonDefines.Event.DOWNLOADED_MGR_SORT_READY);
        }
    },
    /**
     * error callback func on fetching
     * @method
     * @param  {object} data      data obj
     * @param  {object} status    status obj
     * @param  {object} exception exception obj
     */
    error: function (data, status, exception) {
        Volt.log("[DownloadedAppsMgr.js] error()");

    },
    /**
     * check mgr status
     * @method
     * @return {boolean} current status if list is ready or not.
     */
    checkReady: function () {
        if (this.downloadedAppList.length <= 0)
            return false;
        else
            return true;
    },
    /**
     * find element
     * @method
     * @param  {string} appID appID
     * @return {object}       the element the user want
     */
    find: function (appID) {

        var findObj = _.find(this.downloadedAppList, function (obj) {

            if (obj.app_id == appID) {
                return obj;
            }
        });

        return findObj;
    },
    /**
     * check if it's downloaded
     * @method
     * @param  {string}  appID appID
     * @return {Boolean}       return if it's downloaded or not
     */
    isDownloaded: function (appID) {
        // return bool whether appID is or not.

        var findObj = this.find(appID);

        return (findObj !== undefined);
    },
    /**
     * check if it is lock
     * @method
     * @param  {string}  appID appID
     * @return {Boolean}       return if it's lock or not
     */
    isLock: function (appID) {
        // return bool whether appID is or not.

        var findObj = this.find(appID);

        if (findObj !== undefined)
            return findObj.is_lock;
        else
            return undefined;
    },
    /**
     * get element's info
     * @method
     * @param  {string} appID appID
     * @return {obejct}       info object
     */
    getDownloadedAppInfo: function (appID) {
        // return bool whether appID is or not.

        var findObj = this.find(appID);

        return findObj;
    },
    /**
     * get downloaded full list.
     * @method
     * @return {Array} downloaded full list
     */
    getDownloadedList: function () {
        // return list
        return this.downloadedAppList;
    },
    /**
     * add element
     * @method
     * @param {string} appID appID
     */
    add: function (appID) {
        // add to element
        var findObj = this.find(appID);

        if (findObj === undefined) {
            this.downloadedAppList.push(appID);
        }
    },
    /**
     * delete element.
     * @method
     * @param  {string} appID appID
     */
    delete: function (appID) {
        // detlete element
        var findObj = this.find(appID);

        if (findObj !== undefined) {
            var findIndex = _.indexOf(this.downloadedAppList, findObj);
            this.downloadedAppList.splice(findIndex, 1);
        }
    },
    /**
     * reset List
     * @method
     * @param  {object} eventInfo data about event
     */
    resetList: function (eventInfo) {
        Volt.log("[DownloadedAppsMgr.js] resetList()");
        // To reset downloadedList, fetch WAS data of getAppList().

        var wasSyncState = voltapi.WAS.getAppsSyncState();
        if (wasSyncState != CommonDefines.WAS.WAS_APPS_SYNC_COMPLETED) {
            Volt.err("[DownloadedAppsMgr.js] Now Syncing... Skip reset list..");
            return;
        }

        if (eventInfo.result == 0) {
            this.downloadedAppList = [];
            this.fetch();
        }
    }
}

exports = DownloadedAppsMgr;