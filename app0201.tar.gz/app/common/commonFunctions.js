/** 
 * @author lihao Zha (lihao.zha@samsung.com)
 * @fileoverview This module defines common functions.
 * @date    2014/11/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var DeviceInfoModel = Volt.require('app/models/deviceInfoModel.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');

var bForceDisableVoiceGuide = true;
var firstEnterMark = 2;
var appState = CommonDefines.AppState.APP_STATE_ACTIVATE;

var voiceGuide = function (voiceText, bQueuingPlay) {
    Volt.log('[commonFunctions.js] [appsvoice] voice guide text : ' + voiceText);
    if (bForceDisableVoiceGuide) {
        Volt.log('[commonFunctions.js] [appsvoice] forceDisableVoiceGuide, do not need to play unnecessary tts');
        return;
    }
    if (1 != DeviceInfoModel.get('tts')) {
        Volt.log('[commonFunctions.js] [appsvoice] voice guide function is off, do not need to play tts');
        return;
    }
    if (bQueuingPlay) {
        Volt.log('[commonFunctions.js] [appsvoice] queuingPlay');
        TTS.queuingPlay(voiceText);
    } else {
        TTS.setText(voiceText);
        TTS.play();
    }
}

var forceDisableVoiceGuide = function (bForceDisable) {
    bForceDisableVoiceGuide = bForceDisable;
}

var getAppState = function () {
    return appState;
}

var setAppState = function (state) {
    appState = state;
}

var getFirstEnterMark = function () {
    return firstEnterMark;
}

var setFirstEnterMark = function (value) {
    firstEnterMark = value;
}

var disableMenu = function () {
    Volt.log("[commonFunctions.js] disableMenu");
    VDUtil.AppControl_InitDbusConnection();
    VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.apps");
    VDUtil.AppControl_DisableItem("pip", "org.volt.apps");//DF141225-00850 disable PIP sound  
    VDUtil.AppControl_DisableItem("3d", "org.volt.apps");//DF150125-00081 disable 3D  
    VDUtil.AppControl_DisableItem("picturesize", "org.volt.apps");//DF141225-00447 disable picture size 
    VDUtil.AppControl_FiniDbusConnection();
}

var enableMenu = function () {
    Volt.log("[commonFunctions.js] enableMenu");
    VDUtil.AppControl_InitDbusConnection();
    VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.apps");
    VDUtil.AppControl_FiniDbusConnection();
}

////////////////////////////////////////////////////////////////////////////////
//// Common Functions about storage calculation
/**
 * Return to convert app size
 * @method
 * @memberof DetailView
 */
function getFormattedSize(value,Kunit) {
    if (value >= 1048576) {
        return parseFloat(value / 1048576).toFixed(2) + ( Kunit ? Volt.i18n.t('SID_GB'):Volt.i18n.t('SID_MB'));
    } else if (value >= 1024) {
        return parseInt(value / 1024) +  (Kunit ? Volt.i18n.t('SID_MB'):Volt.i18n.t('SID_KB') );
    } else {
        return parseInt(value) + (Kunit? Volt.i18n.t('SID_KB'):Volt.i18n.t('SID_BYTE'));
    }
}

////////////////////////////////////////////////////////////////////////////////
exports = {
    voiceGuide: voiceGuide,
    forceDisableVoiceGuide: forceDisableVoiceGuide,
    getAppState: getAppState,
    setAppState: setAppState,
    getFirstEnterMark: getFirstEnterMark,
    setFirstEnterMark: setFirstEnterMark,
    disableMenu: disableMenu,
    enableMenu: enableMenu,
    
    getFormattedSize: getFormattedSize,
};