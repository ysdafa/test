function MagicKey() {
    var timerInstance = null;
    var listeners = [];
    var buffers = '';

    function onKeyPress(keycode) {
        if (timerInstance)
            Volt.clearTimeout(timerInstance);
        switch (keycode) {
        case Volt.KEY_0:
            buffers += '0';
            break;
        case Volt.KEY_1:
            buffers += '1';
            break;
        case Volt.KEY_2:
            buffers += '2';
            break;
        case Volt.KEY_3:
            buffers += '3';
            break;
        case Volt.KEY_4:
            buffers += '4';
            break;
        case Volt.KEY_5:
            buffers += '5';
            break;
        case Volt.KEY_6:
            buffers += '6';
            break;
        case Volt.KEY_7:
            buffers += '7';
            break;
        case Volt.KEY_8:
            buffers += '8';
            break;
        case Volt.KEY_9:
            buffers += '9';
            break;
        }
        Volt.log('MagicKey.js: buffers is ' + buffers);
        if (executeListener()) {
            clearBuffer();
        }
        timerInstance = Volt.setTimeout(clearBuffer, 3000);
    }

    function executeListener() {
        var execute = false;
        for (var idx = 0; idx < listeners.length; idx++) {
            if (listeners[idx].key == buffers) {
                listeners[idx].listener();
                execute = true;
            }
        }
        return execute;
    }

    function clearBuffer() {
        //        Volt.log("[MagicKey.js] clearBuffer :" + buffers);
        buffers = '';
    }

    function addListener(keyword, callback) {
        listeners.push({
            key: keyword,
            listener: callback
        });
    }

    function removeListener() {
        listeners = [];
    }

    return {
        'onKeyPress': onKeyPress,
        'addListener': addListener,
        'removeListener': removeListener
    };
}
exports = new MagicKey();