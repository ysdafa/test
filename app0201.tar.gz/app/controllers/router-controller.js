/** 
 * @author changkyo Seo (ck1.seo@samsung.com)
 * @fileoverview This module manages router of app.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Q = Volt.require('modules/q.js');
var _ = Volt.require("modules/underscore.js")._;
var Backbone = Volt.require('lib/volt-backbone.js');

var VIEW_TYPE_ROOT = 1,
    VIEW_TYPE_2ND_DEPTH = 2,
    VIEW_TYPE_DETAIL = 3,
    VIEW_TYPE_POPUP = 4;

var oCurrentView = {
        instance: null,
        name: '',
        type: VIEW_TYPE_ROOT
    },
    oViewCache = {};

var showMatrix = {};
showMatrix[VIEW_TYPE_ROOT] = {};
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_ROOT] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_UP';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH] = {};
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_ROOT] = 'SHOW_FADE_UP';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL] = {};
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_ROOT] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_POPUP] = {};
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_ROOT] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_2ND_DEPTH] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_DETAIL] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';

var hideMatrix = {};
hideMatrix[VIEW_TYPE_ROOT] = {};
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_ROOT] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_DOWN';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_2ND_DEPTH] = {};
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_ROOT] = 'HIDE_FADE_DOWN';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_DETAIL] = {};
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_ROOT] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_POPUP] = {};
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_ROOT] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_POPUP] = 'HIDE_FADE_OUT';

/**
 * Get show type
 * @method
 * @param  {enum} fromType From animation type
 * @param  {enum} toType   To animation tyle
 * @return {enum}          Return animation type
 */
function getShowType(fromType, toType) {
    return showMatrix[fromType][toType];
}

/**
 * Get hide type
 * @method
 * @param  {enum} fromType From animation type
 * @param  {enum} toType   To animation tyle
 * @return {enum}          Return animation type
 */
function getHideType(fromType, toType) {
    return hideMatrix[fromType][toType];
}

/**
 * Get page transition log
 * @method
 * @param  {string} sHideView View to hide
 * @param  {string} sShowView View to show
 * @param  {enum} nFromType From animation type
 * @param  {enum} nToType   To animation type
 * @return {string}           Message
 */
function getPageTransitionLog(sHideView, sShowView, nFromType, nToType) {
    var sMsg = '';
    switch (nToType) {
    case VIEW_TYPE_ROOT:
        sMsg += 'rootView';
        break;
    case VIEW_TYPE_2ND_DEPTH:
        sMsg += 'secondDepthView';
        break;
    case VIEW_TYPE_DETAIL:
        sMsg += 'detailView';
        break;
    case VIEW_TYPE_POPUP:
        sMsg += 'popupView';
        break;
    }
    sMsg += ' from ' + sHideView + '(' + getHideType(nFromType, nToType) + ')';
    sMsg += ' to ' + sShowView + '(' + getShowType(nFromType, nToType) + ')';

    return sMsg;
}

/**
 * Cache controller
 * @method
 */
function CacheCtrl() {
    var cache = oViewCache;

    function initCache(viewname) {
        cache[viewname] = {
            name: viewname,
            instance: new(Volt.require('app/views/' + viewname + '.js')),
            sublist: {},
            visible: true,
        };
        cache[viewname].instance.render();
        cache[viewname].sub = _.bind(sub, cache[viewname]);
        cache[viewname].categories = _.bind(categories, cache[viewname]);
        //cache[viewname].show = _.bind(show, cache[viewname]); // Not used temporarily
        cache[viewname].hide = _.bind(hide, cache[viewname]);
    }

    function get(viewname) {
        if (!(cache[viewname] && cache[viewname].instance)) {
            initCache(viewname);
        }
        return cache[viewname];
    }

    function sub() {

        var subview, visible, subviews = Array.prototype.slice.call(arguments, 0);
        for (var idx = 0; idx < subviews.length; idx++) {
            if (!this.sublist[subviews[idx]]) {
                subview = this.sublist[subviews[idx]] = {
                    instance: new(Volt.require('app/views/' + subviews[idx] + '.js')),
                    display: false,
                    hidden: true
                };
                subview.instance.render(this.instance);
            }
        }

        for (var key in this.sublist) {
            visible = false;
            for (var idx = 0; idx < subviews.length; idx++) {
                if (key == subviews[idx]) {
                    visible = true;
                }
            }
            if (!visible) {
                this.sublist[key].display = false;
                if (!this.sublist[key].hidden) {
                    this.sublist[key].instance.hide();
                    this.sublist[key].hidden = true;
                }
            }
        }

        this.deferred.promise.then(_.bind(function () {
            for (var idx = 0; idx < subviews.length; idx++) {
                subview = this.sublist[subviews[idx]];
                if (!subview.display) {
                    subview.display = true;
                    subview.hidden = false;
                    subview.instance.show();
                }
            }
        }, this));
        return this;
    }

    function categories() {

        var subview, visible, subviews = Array.prototype.slice.call(arguments, 0, 1);
        var subId = '_' + arguments[1];
        var param = arguments[2];
        for (var idx = 0; idx < subviews.length; idx++) {
            if (!this.sublist[subviews[idx] + subId]) {
                subview = this.sublist[subviews[idx] + subId] = {
                    instance: new(Volt.require('app/views/' + subviews[idx] + '.js')),
                    display: false,
                    hidden: true
                };
                subview.instance.render(this.instance, arguments[1]);
            }
        }

        for (var key in this.sublist) {
            visible = false;
            for (var idx = 0; idx < subviews.length; idx++) {
                if (key == subviews[idx] + subId) {
                    visible = true;
                }
            }
            if (!visible) {
                this.sublist[key].display = false;
                if (!this.sublist[key].hidden) {
                    this.sublist[key].instance.hide();
                    this.sublist[key].hidden = true;
                }
            }
        }

        this.deferred.promise.then(_.bind(function () {
            for (var idx = 0; idx < subviews.length; idx++) {
                subview = this.sublist[subviews[idx] + subId];
                if (!subview.display) {
                    subview.display = true;
                    subview.hidden = false;
                    subview.instance.show(param);
                }
            }
        }, this));
        return this;
    }

    /*
    // this show() is not used. we use .sub() to show sub view
    function show(param, animationType) {
        var deferred = Q.defer();
        var showList = [];
        if (!this.display) {
            showList.push(this.instance.show(param, animationType));
            this.display = true;
        }
        for (var key in this.sublist) {
            if (this.sublist[key].display && this.sublist[key].hidden) {
                this.sublist[key].hidden = false;
                showList.push(this.sublist[key].instance.show(param, animationType));
            }
        }
        Q.all(showList).then(function () {}).fail(function (e) {
            print(e);
        });
        deferred.resolve();
        return deferred.promise;
    }
    */

    // Hide Parent View and Sub Views
    function hide(options) {
        var deferred = Q.defer();

        if (!this.visible) {
            deferred.resolve();
            return deferred.promise;
        }

        var hideList = [];
        hideList.push(this.instance.hide(options)); // Hide parent view
        this.visible = false;

        if (options.change) { // when view is changed, we should hide sub views
            for (var key in this.sublist) {
                if (this.sublist[key].display) {
                    this.sublist[key].display = false;
                    this.sublist[key].hidden = true;
                    hideList.push(this.sublist[key].instance.hide());
                }
            }
        }

        Q.all(hideList).then(function () {
            deferred.resolve();
        }).fail(function (e) {
            print(e);
        });
        return deferred.promise;
    }

    return {
        get: get
    };
}

var cacheCtrl = CacheCtrl();

/**
 * Change view
 * @method
 * @param  {string} sViewName View name
 * @param  {string} type      View type
 * @param  {object} options     Parameters
 * @return {object}           View object
 */
function changeView(sViewName, type, options) {
    print('[router.js] ' + getPageTransitionLog(oCurrentView.name, sViewName, oCurrentView.type, type));
    //Volt.log('[DEBUG]' + ' n: ' + sViewName + ' o: ' + oCurrentView.name + ' ' + (oCurrentView.name == sViewName));

    var prevView;

    options = options || {};

    // If switch to a new view, store previous view and update oCurrentView
    if (oCurrentView.name != sViewName) {
        prevView = _.clone(oCurrentView);

        oCurrentView = cacheCtrl.get(sViewName);
        oCurrentView.type = type;

        options.change = true; //// Indicate that the view is changed

    } else { // If switching between sub view. add <change> into options to notify hide() and show().
        prevView = oCurrentView;
        options.change = false; //// Indicate that the view is not changed
    }
    oCurrentView.deferred = Q.defer();

    hideView(prevView, options, getHideType(prevView.type, oCurrentView.type))
        .then(function () {
            showView(oCurrentView, options, getShowType(prevView.type, oCurrentView.type), prevView);
            oCurrentView.deferred.resolve();
        }).fail(function (e) {
            print(e);
        });

    return oCurrentView;
}

/**
 * Change to root view
 * @method
 * @param  {string} sViewName View name
 * @param  {object} params    Parameters
 * @return {object}           View
 */
function rootView(sViewName, params) {
    Backbone.history.setCache('viewName', 'main');
    return changeView(sViewName, VIEW_TYPE_ROOT, params);
}

/**
 * Change to second depth view
 * @method
 * @param  {string} sViewName View name
 * @param  {object} params    Parameters
 * @return {object}           View
 */
function secondDepthView(sViewName, params) {
    Backbone.history.setCache('viewName', 'second');
    return changeView(sViewName, VIEW_TYPE_2ND_DEPTH, params);
}

/**
 * Change to detail view
 * @method
 * @param  {string} sViewName View name
 * @param  {object} params    Parameters
 * @return {object}           View
 */
function detailView(sViewName, params) {
    Backbone.history.setCache('viewName', 'detail');
    return changeView(sViewName, VIEW_TYPE_DETAIL, params);
}

/**
 * Change to popup view
 * @method
 * @param  {string} sViewName View name
 * @param  {object} params    Parameters
 * @return {object}           View
 */
function popupView(sViewName, params) {
    print('[router.js] ' + getPageTransitionLog(oCurrentView.name, sViewName, oCurrentView.type, VIEW_TYPE_POPUP));
    // if (oCurrentView.instance) {
    //     pauseView(oCurrentView)
    // }

    Backbone.history.setCache('viewName', 'popup');

    var before = _.clone(oCurrentView);
    oCurrentView = cacheCtrl.get(sViewName);
    oCurrentView.type = VIEW_TYPE_POPUP;
    showView(oCurrentView, params, getShowType(before.type, oCurrentView.type));

    return oCurrentView;
}

/**
 * Pause view
 * @method
 * @param  {object} viewCtrl View controller
 */
function pauseView(viewCtrl) {
    if (viewCtrl.instance.pause && viewCtrl.instance.pause instanceof Function) {
        viewCtrl.instance.pause();
    }
}

/**
 * Hide view
 * @method
 * @param  {object} viewCtrl View controller
 * @param {enum} hideType Hide animationn type
 */
function hideView(viewCtrl, options, hideType) {
    var deferred = Q.defer();

    if (!viewCtrl.instance) {
        deferred.resolve();
        return deferred.promise;
    }

    // When hiding Parent View, sub views will also be hidden.
    viewCtrl.hide(options, hideType)
        .then(function () {
            deferred.resolve();
        });

    //deferred.resolve();
    return deferred.promise;
}

/**
 * Show view. When showing parent view, only parent view itself will be shown. sub views will stay invisible.
 * @method
 * @param  {object} viewCtrl View controller
 * @param  {object} options    Parameters
 * @param {enum} showType Show animation type
 * @param {object} before Object of before view
 */
function showView(viewCtrl, options, showType, before) {
    if (before && before.type == VIEW_TYPE_POPUP) {
        viewCtrl.instance.resume(options, showType, before.type);
    } else {
        viewCtrl.instance.show(options, showType);
        viewCtrl.visible = true;
    }
}

function hide() {
    var key;
    for (key in cacheCtrl) {
        hideView(cacheCtrl[key]);
    }
}

exports = {
    'root': rootView,
    'secondDepth': secondDepthView,
    'detail': detailView,
    'popup': popupView,

    hide: hide
};