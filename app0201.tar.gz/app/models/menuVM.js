/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview Menu view model.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js');

/**
 * @name MenuVM
 */
var MenuVM = Backbone.Model.extend({
    /** @lends MenuVM.prototype */

    defaults: {
        route: '',
        sid: '',
    }
});

exports = MenuVM;