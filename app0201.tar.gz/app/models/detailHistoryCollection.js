/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module handle history data of datailModel when select relatedApp
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require("modules/underscore.js")._;

/**
 * @name DetailHistoryModel
 */
var DetailHistoryModel = Backbone.Model.extend(
    /** @lends DetailHistoryModel.prototype */
    {
        defaults: {},

        /**
         * Initialize DetailHistoryModel
         * @name DetailHistoryModel
         * @constructs
         */
        initialize: function () {}
    });

/**
 * @name DetailHistoryCollection
 */
var DetailHistoryCollection = Backbone.Collection.extend({
    /** @lends DetailHistoryCollection.prototype */
    model: DetailHistoryModel,

    /**
     * Initialize DetailHistoryCollection
     * @name DetailHistoryCollection
     * @constructs
     */
    initialize: function () {}
});

exports = new DetailHistoryCollection;