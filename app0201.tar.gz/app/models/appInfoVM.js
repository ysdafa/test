/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview AppInfo ViewModel
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    AppInstallMgr = Volt.require("app/common/appInstallMgr.js"),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    _ = Volt.require("modules/underscore.js")._;

/**
 * @name AppInfoVM
 */
var AppInfoVM = Backbone.Model.extend(
    /** @lends AppInfoVM.prototype */
    {
        defaults: {
            id: '',
            icon: '',
            title: '',
            titleLang: '',
            version: '',
            categoryTitle: '',
            categoryTitleLang: '',
            screenshot: '',
            order: '',
            fileSize: '',
            contact: '',
            updatedDate: '',
            usbInstall: '',
            wasAppInstallState: '',
            price: '',
            isHighlighted: '',
            uiState: '',
            progress: '',
            colorPick: '',
            isDownloaded: ''
        },
        /**
         * Initialize AppInfoVM
         * @name AppInfoVM
         * @constructs
         */
        initialize: function () {

        },
        /**
         * parse Model's data
         * @method
         * @param  {Model} appInfoModel appInfoModel
         * @return {object}              appInfoModel's data object
         */
        parse: function (appInfoModel) {

            return appInfoModel.attributes;
        },
        /**
         * set donwloaded flag
         * @method
         * @param {boolean} flag boolean flag
         */
        setDownloaded: function (flag) {
            Volt.log("[AppInfoVM.js] setDownloaded() " + this.id + " " + flag);
            this.set("isDownloaded", flag);
        },

        destroyView: function () {
            this.trigger('DESTROY_VIEW');
        }
    });

exports = AppInfoVM;