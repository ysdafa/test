/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module handle data of related apps data of detail
 * @date    2014/07/28 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require("modules/underscore.js")._;

var RelatedAppModel = Volt.require("app/models/appInfoModel.js");

/**
 * @name RelatedAppInfoCollection
 */
var RelatedAppInfoCollection = Backbone.Collection.extend({
    /** @lends RelatedAppInfoCollection.prototype */
    model: RelatedAppModel,

    /**
     * Initialize RelatedAppInfoCollection
     * @name RelatedAppInfoCollection
     * @constructs
     */
    initialize: function () {},

    /**
     * Set relatedAppModel of Collection
     * @method
     * @memberof RelatedAppInfoCollection
     * @param  {object}  widget  focued widget
     */
    setCollection: function (collection) {
        Volt.log("[RelatedAppInfoCollection.js] setCollection()");

        var arrCollection = [];

        _.each(collection, function (app) {
            var model = new RelatedAppModel(app, {
                parse: true
            });
            if (model.get('id')) {
                arrCollection.push(model);
            }
        });

        this.reset(arrCollection);
    }

});

exports = RelatedAppInfoCollection