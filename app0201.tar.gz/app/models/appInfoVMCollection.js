/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview AppInfo ViewModel's Collection
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),

    Models = Volt.require('app/models/models.js'),
    AppInfoVM = Volt.require("app/models/appInfoVM.js"),

    DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js');

/**
 * @name AppInfoVMCollection
 */
var AppInfoVMCollection = Backbone.Collection.extend({
    /** @lends AppInfoVMCollection.prototype */

    model: AppInfoVM,
    collection: null,
    defaultParameters: {},
    type: null,
    additionalData: null,

    /**
     * Initialize AppInfoVMCollection
     * @name AppInfoVMCollection
     * @constructs
     */
    initialize: function () {},

    /**
     * set model collection
     * @method
     * @param {string} type  collection type
     * @param {object} param params for fetching
     */
    setCollection: function (type, categoriesID) {
        this.type = type;
        switch (type) {
        case 'categories':
            if (!Models.categoriesListCollection[categoriesID]) {
                Models.createCategoriesList(categoriesID);
            }
            this.collection = Models.categoriesListCollection[categoriesID];
            break;
        case 'whatsNew':
            this.collection = Models.whatsNewCollection;
            break;
        case 'event':
            this.collection = Models.eventCollection;
            break;
        case 'mostPopular':
            this.collection = Models.mostPopularCollection;
            break;
        case 'detail':
            this.collection = Models.detailModel.get('relatedAppInfoCollection');
            break;
        }

        this.listenTo(this.collection, 'reset', this.parse);
        this.listenTo(this.collection, 'add', this.modelAdded);
        this.listenTo(this.collection, 'change', this.modelChanged);
        this.listenTo(this.collection, 'remove', this.modelRemoved);
        this.listenTo(this.collection, 'error', this.error);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADED_MGR_READY, _.bind(this.setDownloadedList, this));
    },

    offline: function (data) {
        var deferred = Q.defer();

        if (this.collection.offline != undefined) {
            Q.all([this.collection.offline(data)])
                .then(function () {
                    deferred.resolve();
                })
                .fail(function () {
                    deferred.reject();
                });
        }

        return deferred.promise;
    },

    /**
     * call model's fetch func
     * @method
     */
    fetch: function (isReset) {
        var deferred = Q.defer();

        if (isReset) {
            this.collection.clear();
        }

        Q.all([this.collection.fetch(this.defaultParameters)])
            .then(function () {
                deferred.resolve();
            })
            .fail(function () {
                deferred.reject();
            });

        return deferred.promise;
    },

    /**
     * parse given data
     * @method
     * @param  {Collection} collection collection correspond to this
     * @param  {object} options    additional data
     */
    parse: function (collection, options) {
        Volt.log("[AppInfoVMCollection.js] parse()");
        var self = this,
            aAppList = [];

        _.each(collection.models, function (appData, i) {
            var appInfoVM = new AppInfoVM(appData, {
                parse: true
            });
            if (appInfoVM.get('id')) {
                if (DownloadedAppsMgr.checkReady()) {
                    var isDownloaded = DownloadedAppsMgr.isDownloaded(appData.get('id'));
                    if (appInfoVM && appInfoVM.setDownloaded && typeof appInfoVM.setDownloaded === 'function') {
                        appInfoVM.setDownloaded(isDownloaded);
                    }
                }
                aAppList.push(appInfoVM);
            }
        });

        if (options != null) {
            this.additionalData = options;
            this.reset(aAppList, this.additionalData);
        } else {
            this.reset(aAppList);
        }

        if (DownloadedAppsMgr.checkReady())
            this.setDownloadedList();
    },

    setDefaultParameters: function (param) {
        this.defaultParameters = _.extend(this.defaultParameters, param);
    },
    /**
     * callback func called when was response's delay
     * @method
     */
    setDownloadedList: function () {

        Volt.log("[AppInfoVMCollection.js] setDownloadedList()");

        _.each(this.models, function (appData) {

            var isDownloaded = DownloadedAppsMgr.isDownloaded(appData.get('id'));
            if (appData && appData.setDownloaded && typeof appData.setDownloaded === 'function') {
                appData.setDownloaded(isDownloaded);
            }
        });
    },

    /**
     * callback func called when add model to collection
     * @method
     * @param  {Model} model      AppInfoVM
     * @param  {Collection} collection AppInfoVMCollection
     * @param  {object} options    additional data
     */
    modelAdded: function (model, collection, options) {
        var appInfoVM = new AppInfoVM(model, {
            parse: true
        });
        if (appInfoVM.get('id')) {
            if (DownloadedAppsMgr.checkReady()) {
                var isDownloaded = DownloadedAppsMgr.isDownloaded(appInfoVM.get('id'));
                if (appInfoVM && appInfoVM.setDownloaded && typeof appInfoVM.setDownloaded === 'function') {
                    appInfoVM.setDownloaded(isDownloaded);
                }
            }
            this.add(appInfoVM);
        }
    },
    /**
     * callback func called when model's chagned
     * @method
     * @param  {Model} model      AppInfoVM
     * @param  {object} options    additional data
     */
    modelChanged: function (model, options) {
        print("[AppInfoVMCollection.js] modelChanged()");
        if (model.changed) {
            var changedModel = this.where({
                id: model.id
            });
            if (changedModel.length > 0) {
                changedModel[0].set(model.changed);
            }
        }
    },
    /**
     * get entire downloaded list
     * @method
     * @return {Array} downloaded list
     */
    getDownloadedList: function () {
        return DownloadedAppsMgr.getDownloadedList();
    },
    /**
     * find VM's got appID of param.
     * @method
     * @param  {string} appID appID
     * @return {Model}       VM the caller want
     */
    find: function (appID) {
        // find where model
        return this.where({
            id: appID
        });
    },
    /**
     * set progress flag of installing item.
     * @method
     * @param {Object} list mixed list installing item & readytoInstall list
     */
    setProgress: function (list) {

        _.each(list, function (appData) {
            var model = find(appData.appID);
            model.setProgress(appData.status, appData.progress);
        });
    },
    /**
     * set downloaded flag
     * @method
     * @param {string} appID appID
     */
    setDownloaded: function (appID) {
        // downloaded flag set
        var model = find(appID);
        model.setDownloaded(true);
    },
    /**
     * callback func called when fetch error occur
     * @method
     * @param  {object} object    object
     * @param  {number} status    ResourceRequest status
     * @param  {object} exception exception object got exception data.
     */
    error: function (serverError) {
        EventMediator.trigger(CommonDefines.Event.EVENT_HOME_HIDE_LOADING);
        this.trigger('error', serverError);
        print('[AppInfoVMCollection.js] fetch error : ' + serverError);
    },
    /**
     * reset collection
     * @method
     */
    clear: function () {
        this.reset([]);
    },

    stopListeningEvent: function () {
        this.stopListening(EventMediator);
    },

    startListeningEvent: function () {
        this.setDownloadedList();
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADED_MGR_READY, _.bind(this.setDownloadedList, this));
    }
});

exports = AppInfoVMCollection;