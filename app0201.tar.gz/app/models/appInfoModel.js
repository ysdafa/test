/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview AppInfo Model.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._;

/**
 * @name AppInfoModel
 */
var AppInfoModel = Backbone.Model.extend(
    /** @lends AppInfoModel.prototype */
    {
        defaults: {
            id: '',
            icon: '',
            title: '',
            titleLang: '',
            version: '',
            categoryTitle: '',
            categoryTitleLang: '',
            screenshot: '',
            order: '',
            fileSize: '',
            contact: '',
            updatedDate: '',
            usbInstall: true,
            wasAppInstallState: '',
            price: '',
            isHighlighted: '',
            uiState: '',
            progress: '',
            colorPick: ''
        },

        /**
         * Initialize AppInfoModel
         * @name AppInfoModel
         * @constructs
         */
        initialize: function () {},

        /**
         * parse given data
         * @method
         * @param  {object} appInfoData object coverted into json string
         * @return {object}             object coverted into json string
         */
        parse: function (appInfoData) {

            try {
                return appInfoData;

            } catch (e) {
                console.error('[appInfoModel.js] parse error : ' + e);
                return false;
            }

        }
    });

exports = AppInfoModel;