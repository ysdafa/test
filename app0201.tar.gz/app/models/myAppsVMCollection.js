/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview MyApps View Model Collection.
 * @date    2014/09/17 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require('modules/underscore.js')._,
    Q = Volt.require('modules/q.js'),

    Models = Volt.require('app/models/models.js'),
    MyAppsVM = Volt.require('app/models/myAppsVM.js'),

    AppInstallMgr = Volt.require('app/common/appInstallMgr.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    voltapi = Volt.require('voltapi.js');
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');

/**
 * @name MyAppsVMCollection
 */
var MyAppsVMCollection = Backbone.Collection.extend({
    /** @lends MyAppsVMCollection.prototype */

    model: MyAppsVM,
    collection: null,
    uninstallCount: 0,
    totalUninstallCount: 0,
    modeType: false,

    /**
     * Initialize MyAppsVMCollection
     * @name MyAppsVMCollection
     * @constructs
     */
    initialize: function () {
        Volt.log('[MyAppsVMCollection] initialize');

        this.collection = Models.myAppsCollection;

        this.bindCollectionEvents();
        this.bindUpdateEvents();

        this.reset(this.parse(this.collection));
    },

    fetch: function (viewmode) {
        Volt.log('[MyAppsVMCollection] fetch');

        this.collection.fetch(viewmode);
    },

    /**
     * parse given data
     * @method
     * @param  {Collection} collection collection correspond to this
     */
    parse: function (collection) {
        Volt.log('[MyAppsVMCollection] parse');

        return collection.toJSON();
    },

    refresh: function () {
        Volt.log('[MyAppsVMCollection] refresh');

        this.collection.refresh();
    },

    /**
     * callback func called when fetch error occur
     * @method
     * @param  {object} object    object
     * @param  {number} status    ResourceRequest status
     * @param  {object} exception exception object got exception data.
     */
    error: function (exception) {
        Volt.log('[MyAppsVMCollection] error : ' + exception);

        this.trigger('error', exception);
    },

    /**
     * reset collection
     * @method
     */
    clear: function () {
        Volt.log('[MyAppsVMCollection] clear');

        this.reset([]);
    },

    setAppLock: function () {
        var self = this;

        _.each(this.models, function (myAppsVM) {
            if (myAppsVM.get('is_edit_mode') && (myAppsVM.get('is_lock') != myAppsVM.get('is_checked'))) {
                var result = self.wasAppLock(myAppsVM.get('app_id'), myAppsVM.get('is_checked'));

                if (result == '0') {
                    if (myAppsVM.get('is_checked')) {
                        myAppsVM.set('is_lock', true);
                    } else {
                        myAppsVM.set('is_lock', false);
                    }
                }
            }
        });

        EventMediator.trigger(CommonDefines.Event.CHANGE_DOWNLOADED_APPS, {
            result: 0
        });
    },

    checkHaveMultiDeleteApps: function () {
        if (this.where({
            'is_edit_mode': true,
            'is_checked': true
        }).length > 0) {
            return true;
        } else {
            return false;
        }
    },

    deleteApps: function (type, app_id, bIsLock) {
        var self = this;
        var flag = false;
        if (type == 'multi') flag = true;
        this.deletePopShow = false;
        this.uninstallCount = 0;
        print('myAppsVMcollection.js deleteApps app_id' + app_id + 'flag:' + type + flag);
        /***add deleting popup caoyr***/
        print('myAppsVMcollection.js deleteApps app_id' + app_id + 'flag:' + type + flag);
        deleteParams = {
            app_id: app_id,
            isMulti: flag,
        }
        print('myAppsVMcollection.js deleteApps' + deleteParams.app_id);
        if (bIsLock == false) {
            this.deletePopShow = true;
            print("CommonWidgetPopup.showMessage MSGBOX_TYPE_DELETE");
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_DELETE, JSON.stringify(deleteParams));
        } else {
            print("listenToOnce UNINSTALLING");
            this.listenToOnce(EventMediator, CommonDefines.Event.UNINSTALLING, this.showDeletePop, this);
        }
        //for (var i = 0; i < app_id.length; i++) {
        //  if (app_id[i]) {
        AppInstallMgr.unInstallApp(app_id);
        //}
        // }
        /*****/

        /*if (type == 'multi') {
            this.totalUninstallCount = this.where({
                'is_edit_mode' : true,
                'is_checked' : true
            }).length;

            Volt.log('[MyAppsVMCollection] deleteApps() - Multi Delete mode - totalUninstallCount ::: ' + this.totalUninstallCount);

            if (this.totalUninstallCount > 0) {
                _.each(this.models, function(myAppsVM) {
                    if (myAppsVM.get('is_edit_mode') && myAppsVM.get('is_checked')) {
                        AppInstallMgr.unInstallApp(myAppsVM.get('app_id'));
                    }
                });
            } else {
                Volt.log('[MyAppsVMCollection] deleteApps() - Multi Delete mode ::: totalUninstallCount is 0. check it!!');
            }
        } else if (type == 'single') {
            if (app_id) {
                Volt.log('[MyAppsVMCollection] deleteApps() - Single Delete mode');
                this.totalUninstallCount = 1;

                AppInstallMgr.unInstallApp(app_id);
            } else {
                Volt.log('[MyAppsVMCollection] deleteApps() - Single Delete mode ::: there is no app_id. check app_id!!');
            }
        }*/
    },
    showDeletePop: function () {
        print("showDeletePopshowDeletePopshowDeletePopshowDeletePopshowDeletePopshowDeletePopshowDeletePop");
        if (this.deletePopShow == true) {
            return;
        }
        this.deletePopShow = true;
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_DELETE, JSON.stringify(deleteParams));
    },
    /**
     * Set app lock by AppID.
     * @method
     * @returns {string} appID
     */
    wasAppLock: function (appID, flag) {
        Volt.log('[MyAppsVMCollection] setAppLock() : ' + appID + ' - ' + flag);

        // 0 means unlock, 1 means lock
        var setLockFlag = flag ? '1' : '0',
            ret = voltapi.WAS.setAppLock(appID, setLockFlag);

        Volt.log('[MyAppsVMCollection] voltapi.WAS.setAppLock() ret : ' + ret);

        return ret;
    },

    setEditMode: function (modeType, flag) {

        var self = this;

        if (flag) {
            this.modeType = modeType;
        } else {
            this.modeType = '';
        }

        _.each(this.models, function (myAppsVM) {
            self.refreshProps(myAppsVM, modeType, flag);
        });
    },

    refreshProps: function (myAppsVM, modeType, flag) {
        if (flag) {
            myAppsVM.set('is_edit_mode', true);

            if (myAppsVM.get('is_updating')) {
                myAppsVM.set('is_dim', true);
                myAppsVM.set('is_checkable', false);
            } else {
                if (modeType == 'delete') {
                    if (myAppsVM.get('is_removable') == '0' || myAppsVM.get('app_featured') == CommonDefines.WAS.APPS_INFO_FEATURED_RECOMMONDED) {
                        myAppsVM.set('is_dim', true);
                        myAppsVM.set('is_checkable', false);
                    } else {
                        myAppsVM.set('is_dim', false);
                        myAppsVM.set('is_checkable', true);
                    }
                } else if (modeType == 'lock') {
                    if (myAppsVM.get('is_lock') != '0') {
                        myAppsVM.set('is_checked', true);
                        myAppsVM.set('is_dim', true);
                        myAppsVM.set('is_checkable', true);
                    } else {
                        myAppsVM.set('is_checked', false);
                        myAppsVM.set('is_dim', false);
                        myAppsVM.set('is_checkable', true);
                    }
                    if (myAppsVM.get('app_title') == "e-Manual" || myAppsVM.get('app_title') == "Browser") {
                        myAppsVM.set('is_checked', false);
                        myAppsVM.set('is_dim', true);
                        myAppsVM.set('is_checkable', false);
                    }
                }
            }
        } else {
            myAppsVM.set('is_edit_mode', false);
            myAppsVM.set('is_checked', false);
            myAppsVM.set('is_checkable', false);

            if (!myAppsVM.get('is_updating')) {
                myAppsVM.set('is_dim', false);
            }
        }
    },

    setSelectAll: function (flag) {
        _.each(this.models, function (myAppsVM) {
            if (flag) {
                if (myAppsVM.get('is_edit_mode') && myAppsVM.get('is_checkable')) {
                    myAppsVM.set('is_checked', true);
                    myAppsVM.set('is_dim', true);
                }
            } else {
                if (myAppsVM.get('is_checkable')) {
                    myAppsVM.set('is_checked', false);
                    myAppsVM.set('is_dim', false);
                }
            }
        });
    },

    getCheckedItemCount: function () {
        var itemCount = 0;

        _.each(this.models, function (myAppsVM) {
            if (myAppsVM.get('is_edit_mode')) {
                if (myAppsVM.get('is_checked')) itemCount++;
            }
        });

        return itemCount;
    },

    getCheckableItemCount: function () {
        var itemCount = 0;

        _.each(this.models, function (myAppsVM) {
            if (myAppsVM.get('is_edit_mode')) {
                if (myAppsVM.get('is_checkable')) itemCount++;
            }
        });

        return itemCount;
    },

    getCheckedItemAppID: function () {
        var App_ID = [];
        var i = 0
        _.each(this.models, function (myAppsVM) {
            if (myAppsVM.get('is_edit_mode')) {
                if (myAppsVM.get('is_checked')) {
                    App_ID[i] = myAppsVM.get('app_id');
                    print("[myAppsVMCollection]getCheckedItemAppID" + App_ID[i]);
                    i++;
                }

            }
        });

        return App_ID;
    },
    getLockedFlag: function (app_id) {
        var App_ID = [];
        var i = 0;
        var bIsLock = false;
        print("getLockedItemAppID:!!!!!!!!!!!" + app_id);
        _.each(this.models, function (myAppsVM) {
            if (myAppsVM.get('is_edit_mode')) {
                print("is_lock:  " + myAppsVM.get('is_lock') + "   is_checked  " + myAppsVM.get('is_checked'));
                if (myAppsVM.get('is_lock') && myAppsVM.get('is_checked')) {
                    App_ID[i] = myAppsVM.get('app_id');
                    print("[myAppsVMCollection]getLocked&&checkedItemAppID" + App_ID[i]);
                    i++;
                }
            } else {
                if (myAppsVM.get('app_id') == app_id && myAppsVM.get('is_lock')) {
                    i++;
                }
            }
        });
        if (i > 0) {
            bIsLock = true;
        }
        return bIsLock;

    },
    bindCollectionEvents: function () {
        this.listenTo(this.collection, 'reset', this.onReset);
        this.listenTo(this.collection, 'add', this.onAdd);
        this.listenTo(this.collection, 'remove', this.onRemove);
    },

    onReset: function (collection, options) {
        Volt.err('[MyAppsVMCollection] onReset');

        this.reset(this.parse(this.collection));

    },

    onAdd: function (model, collection, options) {
        Volt.err('[MyAppsVMCollection] onAdd');

        this.add(model.toJSON());
    },

    onRemove: function (model, collection, options) {
        Volt.err('[MyAppsVMCollection] onRemove');

        this.remove(this.findWhere({
            app_id: model.get('app_id')
        }));
    },

    // Handle Update Events
    bindUpdateEvents: function () {
        this.listenTo(EventMediator, CommonDefines.Event.UPDATE_START, this.onUpdateStart);

        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADING, this.onDownloading);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_COMPLETED, this.onDownloadComplete);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_NOT_EXIST, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_LICENSE_ERROR, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_SERVER_ERROR, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_NETWORK_ERROR, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_OTHERS, this.onDownloadFail);

        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_DECRYPY_CONFIG, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_ICON_URL_IS_EMPTY, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_ICON, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_APP, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_APP_NOT_EXIST, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLAOD_LOAD_WIDGET_INFO, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_CONVERT_ID_FROM_RUNTITLE, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_INPUT_PARAMETER, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_MOVE_DIR, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_UNZIP_FILES, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_NO_LICENSE_FILE, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_NO_INSTALL_DIR, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_TEMP_DIR_NOT_EXIST, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_URL, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_EMP_INFO, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_EMP_NOT_ENOUGH_MEMORY, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_MOVE, this.onDownloadFail);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_EMP_DOWNLOAD, this.onDownloadFail);


        this.listenTo(EventMediator, CommonDefines.Event.INSTALLING, this.onInstalling);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_CANCEL_COMPLETED, this.onInstallFail);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_CANCEL_FAILED, this.onInstallFail);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_COMPLETED, this.onInstallComplete);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_FAIL_EXIST, this.onInstallFail);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_FAIL_PKGMGR_ERROR, this.onInstallFail);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_FAIL_LICENSE_ERROR, this.onInstallFail);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_FAIL_OTHERS, this.onInstallFail);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, this.onInstallFail);
    },

    onUpdateStart: function (info) {
        Volt.log('[MyAppsVMCollection] onUpdateStart()');

        // info: {
        //     'app_id': '111477000639',
        //     'result': 100
        // }

        var vm = this.findWhere({
            app_id: info.app_id
        });

        if (vm) {
            vm.set('state', 'UPDATE_START');
            vm.set('progress', 0);
            vm.set('is_updating', true);
            vm.set('is_dim', true);
        }
    },

    onDownloading: function (info) {
        Volt.log('[MyAppsVMCollection] onDownloading()');

        var vm = this.findWhere({
            app_id: info.app_id
        });
        if (vm) {
            vm.set('state', 'DOWNLOADING');
            vm.set('progress', info.result);
            vm.set('is_updating', true);
            vm.set('is_dim', true);
        }
    },

    onDownloadComplete: function (info) {
        Volt.log('[MyAppsVMCollection] onDownloadComplete()');

        var vm = this.findWhere({
            app_id: info.app_id
        });
        if (vm) {
            vm.set('state', 'DOWNLOAD_COMPLETED');
            vm.set('is_updating', true);
            vm.set('is_dim', true);
        }
    },

    onDownloadFail: function (info) {
        Volt.log('[MyAppsVMCollection] onDownloadFail()');

        var vm = this.findWhere({
            app_id: info.app_id
        });
        if (vm) {
            vm.set('state', 'DOWNLOAD_FAIL');
            vm.set('progress', 0);
            vm.set('is_updating', false);
            this.refreshProps(vm, this.modeType, vm.get('is_edit_mode'));
        }
    },

    onInstalling: function (info) {
        Volt.log('[MyAppsVMCollection] onInstalling()');

        var vm = this.findWhere({
            app_id: info.app_id
        });
        if (vm) {
            vm.set('state', 'INSTALLING');
            vm.set('progress', info.result);
            vm.set('is_updating', true);
            vm.set('is_dim', true);
        }
    },

    onInstallComplete: function (info) {
        Volt.log('[MyAppsVMCollection] onInstalling()');

        var vm = this.findWhere({
            app_id: info.app_id
        });
        if (vm) {
            vm.set('state', 'INSTALL_COMPLETED', info);
            vm.set('progress', 0);
            vm.set('is_updating', false);

            if (vm.get('is_need_update') == 1) {
                vm.set('is_need_update', 0);
                vm.set('is_updated', 1);
            }
            this.refreshProps(vm, this.modeType, vm.get('is_edit_mode'));
        }
    },

    onInstallFail: function (info) {
        Volt.log('[MyAppsVMCollection] onInstallFail() info.app_id = ' + info.app_id);
        var vm = this.findWhere({
            app_id: info.app_id
        });
        if (vm) {
            vm.set('state', '', info);
            vm.set('state', 'INSTALL_FAIL', info);
            vm.set('progress', 0);
            vm.set('is_updating', false);
            this.refreshProps(vm, this.modeType, vm.get('is_edit_mode'));
        }
    },


    ////////////////////////////////////////////////////////////////////
    // Test code for grid list control add or remove item.

    idx: 1,

    removeTestItem: function () {
        // this.remove(this.collection.at(this.idx++));
        this.remove(this.at(1));
    },

    addTestItem: function () {
        this.add(_.extend(this.at(0).toJSON(), {
            app_id: '999' + this.idx,
            app_title: 'TEST' + this.idx
        }));
        this.idx++;
    }
    ////////////////////////////////////////////////////////////////////

});

exports = MyAppsVMCollection;