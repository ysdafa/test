/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module handle usb data getting by contentsMgr
 * @date    2014/07/26 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    voltapi = Volt.require('voltapi.js'),
    _ = Volt.require("modules/underscore.js")._,
    VoltJSON = Volt.require("modules/VoltJSON.js"),
    Q = Volt.require('modules/q.js'),
    AppInstallMgr = Volt.require("app/common/appInstallMgr.js"),
    CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js');

/**
 * @name ExternalStorageModel
 */
var ExternalStorageModel = Backbone.Model.extend({
    /** @lends ExternalStorageModel.prototype */
    defaults: {
        usbList: []
    },

    /**
     * Initialize ExternalStorageModel
     * @name ExternalStorageModel
     * @constructs
     */
    initialize: function () {},

    /**
     * Check to connect usb
     * @method
     * @memberof ExternalStorageModel
     */
    checkConnectUSB: function (app_id) {

        var result = this.updateUSBList();
        if (result && result.storages) {
            var len = result.storages.length;

            if (len == 0) {
                /*var setPopup = {
                    text: Volt.i18n.t('COM_SID_MEMORY_FULL_CONNECT_USB_INSTALL'),
                    buttons: [
                        {
                            name: Volt.i18n.t('COM_SID_OK')
                        }
                    ]
                }

                var guidePopup = new MsgPopupView(setPopup);*/
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_MEMORY_FULL_CONNECT_USB_INSTALL);

            } else if (len == 1) {
                var usbPath = result.storages[0].mountPath;
                // usbPath = usbPath.replace('$USB_DIR', '/opt/storage/usb');

                Volt.log('[externalStorageModel.js @checkConnectUSB] Only one usb inserted, install in it!');
                Volt.log('[externalStorageModel.js @checkConnectUSB] app_id: ' + app_id + ' usbPath:' + usbPath);

                if (app_id && usbPath) {
                    EventMediator.trigger(CommonDefines.Event.EVENT_USB_INSTALL_APP, {
                        app_id: app_id,
                    });
                    AppInstallMgr.installApp(app_id, usbPath);
                }

            } else {
                Backbone.history.navigate('popup/usbList/' + app_id, {
                    trigger: true
                });
            }
            return true;

        }
        return false;
    },

    /**
     * Check to connect usb
     * @method
     * @memberof ExternalStorageModel
     */
    updateUSBList: function () {
        var result = voltapi.ContentsMgr.getStorages();
        this.set("usbList", result.storages);
        Volt.log(this.get('usbList'));
        return result;
    }
});

exports = ExternalStorageModel;