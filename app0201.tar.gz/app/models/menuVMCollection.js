/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview Menu view model collection.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    MenuVM = Volt.require('app/models/menuVM.js');
var EventMediator = Volt.require('app/common/eventMediator.js');

var ServerAPI = Volt.require("app/common/serverAPI.js"),
    CategoriesInfoModel = Volt.require("app/models/categoriesInfoModel.js");
var localStorage = Volt.require("lib/volt-local-storage.js");

var aAllMenus = [];

/**
 * @name MenuVMCollection
 */
var MenuVMCollection = Backbone.Collection.extend({
    /** @lends MenuVMCollection.prototype */

    model: MenuVM,
    currentMenuIndex: 0,
    switchFlag: false,
    nextMenuIndex: 0,
    isExpand: false,

    /**
     * Initialize MenuVMCollection
     * @name MenuVMCollection
     * @constructs
     */
    initialize: function () {
        Volt.log(Volt.i18n.t('UID_APPS_WHATS_NEW'));

        aAllMenus = [
            {
                index: 0,
                route: 'myapps',
                isDefault: true,
                sid: '',
                tmpName: Volt.i18n.t('TV_SID_MY_APPS_KR_PANEL'),
                pageName: 'M01_MYAPPS'
            },
            {
                index: 1,
                route: 'whatsnew',
                isDefault: true,
                sid: '',
                tmpName: Volt.i18n.t('UID_APPS_WHATS_NEW'),
                pageName: 'N01_NEW'
            },
            {
                index: 2,
                route: 'mostpopular',
                isDefault: true,
                sid: '',
                tmpName: Volt.i18n.t('COM_SID_MOSTPOPULAR_CATEGORY'),
                pageName: 'M01_MOST'
            }
        /*  {index: 3, route: 'events',      isDefault: true,  sid: '', uiState: 'NORMAL', tmpName: 'Events', pageName: 'E01_EVENT'},
            {index: 4, route: 'categories',  isDefault: true,  sid: '', uiState: 'NORMAL', tmpName: 'Categories', pageName: 'C01_CATEGORY'}*/
        ];
        var cachingData = localStorage.getItem('apps-category-caching-data');
        if (cachingData && cachingData.length > 0) {
            Volt.log("apps-category-caching-data existed");
            Volt.log('[menuVMCollection.js] offline' + JSON.stringify(cachingData));
            var oJson = JSON.parse(cachingData);
            results = oJson.categories ? oJson.categories : '';
            for (var i = 0; i < results.length; i++) {
                if (results[i].id && results[i].id != "all") {
                    aAllMenus.push({
                        index: aAllMenus.length,
                        route: 'categoriesList/' + results[i].id + '/' + results[i].title,
                        isDefault: true,
                        sid: '',
                        tmpName: results[i].title,
                        pageName: ""
                    });
                }
            }
        } else {
            Volt.log("apps-category-caching-data is empty");
        }

        this.setDefaultMenus();
    },

    /**
     * Set default menu
     * @method
     */
    setDefaultMenus: function () {
        var defaultMenus = _.filter(aAllMenus, function (menu) {
            return menu.isDefault == true;
        });

        this.reset(this.reArrangeIndex(defaultMenus));
    },
    setSwitchFlag: function (flag) {
        this.switchFlag = flag;
    },
    getSwitchFlag: function () {
        return this.switchFlag;
    },
    reArrangeIndex: function (menuArray) {
        var nIndex = 0;

        _.each(menuArray, function (menu) {
            menu.index = nIndex;
            nIndex++;
        });

        return menuArray;
    },

    fetch: function () {
        Volt.log('[CategoriesInfoCollection] fetch');
        var self = this;
        var deferred = Q.defer();

        ServerAPI.getCategoryList({
            success: function (data, status, response) {
                self.parse(data, status, response);
                Volt.setTimeout(function () {
                    EventMediator.trigger('EVENT_SUCCESS_CATEGORYLIST');
                }, 10);
                deferred.resolve();
            },

            error: function (serverError) {
                self.error(serverError);
                deferred.reject();
            },

            complete: function (object, status) {

            }
        });

        return deferred.promise;
    },

    /**
     * Parse the fetched data
     * @method
     * @param  {string} data     Raw data
     * @param  {string} status   Response status of server
     * @param  {string} response Response from server
     */
    parse: function (data, status, response) {

        var oJson = JSON.parse(data);
        results = oJson.categories ? oJson.categories : '';
        localStorage.setItem('apps-category-caching-data', data); //save category data
        var Models = Volt.require('app/models/models.js');
        //modify by yangpei 20141105   if the function is called many times,there will cause problem,need reset the aAllMenus
        aAllMenus = [
            {
                index: 0,
                route: 'myapps',
                isDefault: true,
                sid: '',
                tmpName: Volt.i18n.t('TV_SID_MY_APPS_KR_PANEL'),
                pageName: 'M01_MYAPPS'
            },
            {
                index: 1,
                route: 'whatsnew',
                isDefault: true,
                sid: '',
                tmpName: Volt.i18n.t('UID_APPS_WHATS_NEW'),
                pageName: 'N01_NEW'
            },
            {
                index: 2,
                route: 'mostpopular',
                isDefault: true,
                sid: '',
                tmpName: Volt.i18n.t('COM_SID_MOSTPOPULAR_CATEGORY'),
                pageName: 'M01_MOST'
            }
        ];
        _.each(results, function (categories) {

            if (categories.id && categories.id != "all") {
                var nRemain = categories.id % 11,
                    sPageName = null;

                switch (nRemain) {
                case 5:
                    sPageName = 'C02_VIDEO';
                    break;
                case 6:
                    sPageName = 'C02_SPORT';
                    break;
                case 7:
                    sPageName = 'C02_GAME';
                    break;
                case 8:
                    sPageName = 'C02_LIFE';
                    break;
                case 9:
                    sPageName = 'C02_INFO';
                    break;
                case 10:
                    sPageName = 'C02_EDU';
                    break;
                case 0:
                    sPageName = 'C02_KIDS';
                    break;
                }

                aAllMenus.push({
                    index: aAllMenus.length,
                    route: 'categoriesList/' + categories.id + '/' + categories.title,
                    isDefault: true,
                    sid: '',
                    tmpName: categories.title,
                    pageName: sPageName
                });

                Models.createCategoriesList(categories.id);
            }
        });
        this.isExpand = true;

        this.setDefaultMenus();
    },

    /**
     * Parse error handler
     * @method
     * @param  {string} object   Eror object
     * @param  {string} status   Response status of server
     * @param  {string} exception Error response from server
     */
    error: function (serverError) {

        Volt.log('[CategoriesInfoCollection] fetch error : ' + serverError.code + ':::' + serverError.message);
        this.trigger('error', serverError);
    },

    /**
     * Clear this collection's data
     * @method
     */
    clear: function () {
        this.reset([]);
    },

});

exports = MenuVMCollection;