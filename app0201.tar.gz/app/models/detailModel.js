/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module handle store data of detail.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require("modules/underscore.js")._;
var ServerAPI = Volt.require("app/common/serverAPI.js");
var RelatedAppInfoCollection = Volt.require("app/models/relatedAppInfoCollection.js");
var EventMediator = Volt.require('app/common/eventMediator.js');
/**
 * @name DetailModel
 */
var DetailModel = Backbone.Model.extend({
    /** @lends DetailModel.prototype */
    defaults: {

    },
    /**
     * Initialize DetailModel
     * @name DetailModel
     * @constructs
     */
    initialize: function () {
        Volt.log("[detailModel.js] initialize");
    },

    /**
     * fetch DetailModel's data from server
     * @method
     * @memberof DetailModel
     * @param  {object}   param   path(appID)
     */
    fetch: function (param) {
        Volt.log("[detailModel.js] fetch");
        var self = this;

        ServerAPI.getAppDetail({
            path: param,
            success: function (data, status, response) {
                // Volt.log("[getDetail] Success");          
                self.parse(data);
            },
            error: function (serverError) {
                Volt.log("[getDetail] Occued exception");
                self.error(serverError);
            },
            complete: function (object, status) {
                Volt.log("[getDetail] complete");
            }
        });
    },

    /**
     * parse data from detailModel.
     * @method
     * @memberof DetailVM
     * @param  {object}    data  detail's server data
     */
    parse: function (data, status, response) {
        Volt.log("[detailModel.js] parse");
        var app = JSON.parse(data).apps[0];

        if (app && app.id) {
            app.screenshotList = this.setArray([app.screenshot1 ? app.screenshot1 : app.screenshotLarge1, app.screenshot2, app.screenshot3, app.screenshot4 ? app.screenshot4 : '']);

            if (!app.relatedAppInfoCollection) {
                app.relatedAppInfoCollection = new RelatedAppInfoCollection();
            }

            app.relatedAppInfoCollection.setCollection(app.relatedApps);

            this.set(app);
        } else {
            Volt.err("[detailModel.js] parse()");
            Volt.err(data);

            this.error({
                code: 'AS444',
                message: Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', 'AS444')
            });
        }
    },

    cashedParse: function (data) {
        if (data) {
            //data.relatedAppInfoCollection = new RelatedAppInfoCollection();
            //data.relatedAppInfoCollection.setCollection(data.relatedApps);
            // Fixed it by DF141030-00717
            var that = this;
            Volt.setTimeout(function () {
                that.set(data);
            }, 100);

        }
    },

    /**
     * Check valid data of screenshot
     * @method
     * @memberof DetailVM
     * @param  {object}    data  detail's server data
     */
    setArray: function (arrScreenList) {
        Volt.log("[detailModel.js] setArray");
        var arrList = [];

        var arrScreenListLength = arrScreenList.length;
        for (var i = 0; i < arrScreenListLength; i++) {
            if (arrScreenList[i] && arrScreenList[i] !== undefined && arrScreenList[i] !== null) {
                arrList.push(arrScreenList[i]);
            }
        }

        return arrList;
    },

    /**
     * Print error log when occured error from server
     * @method
     * @memberof DetailVM
     * @param  {string}    exception  error_description
     */
    error: function (serverError) {
        Volt.log('[DetailModel.js] fetch error : ' + serverError.code + ':::' + serverError.message);
        this.trigger('error', serverError);
    }

});

exports = DetailModel;