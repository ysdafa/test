/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module handle view data of detail.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require("modules/underscore.js")._;
var Models = Volt.require('app/models/models.js');

var ServerAPI = Volt.require("app/common/serverAPI.js");
var AppInfoVMCollection = Volt.require("app/models/appInfoVMCollection.js");

var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var DownloadedAppsMgr = Volt.require("app/common/downloadedAppsMgr.js");
var EventMediator = Volt.require('app/common/eventMediator.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');

var MsgBoxPopupView = Volt.require('lib/views/message-box-popup.js');
var LocalStorage = Volt.require('lib/volt-local-storage.js');
var voltapi = Volt.require('voltapi.js');

var self;

var detailHistoryCollection = Volt.require('app/models/detailHistoryCollection.js');

/**
 * @name DetailVM
 */
var DetailVM = Backbone.Model.extend({
    /** @lends DetailVM.prototype */
    defaults: {
        id: '',
        userRating: 3,
        installedVersion: '',
        isDownloaded: false,
        isInstalling: false,
        storageInfo: '',
        nInitProgress: 0,
    },

    arrInstallErrorEvents: [
        CommonDefines.Event.DOWNLOAD_FAIL_NOT_EXIST,
        CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE,
        CommonDefines.Event.DOWNLOAD_FAIL_LICENSE_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_SERVER_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_NETWORK_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_OTHERS,

        CommonDefines.Event.DOWNLOAD_FAIL_DECRYPY_CONFIG,
        CommonDefines.Event.DOWNLOAD_FAIL_ICON_URL_IS_EMPTY,
        CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_ICON,
        CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_APP,
        CommonDefines.Event.DOWNLOAD_FAIL_APP_NOT_EXIST,
        CommonDefines.Event.DOWNLAOD_LOAD_WIDGET_INFO,
        CommonDefines.Event.DOWNLOAD_FAIL_CONVERT_ID_FROM_RUNTITLE,
        CommonDefines.Event.DOWNLOAD_FAIL_INPUT_PARAMETER,
        CommonDefines.Event.DOWNLOAD_FAIL_MOVE_DIR,
        CommonDefines.Event.DOWNLOAD_FAIL_UNZIP_FILES,
        CommonDefines.Event.DOWNLOAD_FAIL_NO_LICENSE_FILE,
        CommonDefines.Event.DOWNLOAD_FAIL_NO_INSTALL_DIR,
        CommonDefines.Event.DOWNLOAD_FAIL_TEMP_DIR_NOT_EXIST,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_URL,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_EMP_INFO,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_NOT_ENOUGH_MEMORY,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_MOVE,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_DOWNLOAD,

        CommonDefines.Event.INSTALL_FAIL_EXIST,
        CommonDefines.Event.INSTALL_FAIL_PKGMGR_ERROR,
        CommonDefines.Event.INSTALL_FAIL_LICENSE_ERROR,
        CommonDefines.Event.INSTALL_FAIL_OTHERS,
        CommonDefines.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE,

    ],
    /**
     * Initialize DetailVM
     * @name DetailVM
     * @constructs
     */
    initialize: function () {
        Volt.log("[DetailVM.js] initialize");
        self = this;
    },

    /**
     * fetch DetailVM's data
     * @method
     * @memberof DetailVM
     * @param  {sting}      appID  appID
     */
    fetch: function (appID) {
        Volt.log("[DetailVM.js] fetch");
        // [TODO] Request Server Data to DetailModel
        this.listenTo(Models.detailModel, 'change:id', this.parse);
        this.listenTo(Models.detailModel, 'error', this.error);

        Models.detailModel.fetch({
            appId: appID
        });
    },

    /**
     * parse data from detailModel.
     * @method
     * @memberof DetailVM
     * @param  {object}     data  detail's server data
     */
    parse: function (data) {
        Volt.log("[DetailVM.js] parse      " + JSON.stringify(data));
        var item = {
            'id': data.get('id'),
            'version': data.get('version'),
            'title': data.get('title'),
            'updated': data.get('updated'),
            'vendor': data.get('vendor'),
            'contact': data.get('contact'),
            'description': data.get('description') ? data.get('description') : '',
            'fileSize': data.get('fileSize'),
            'fileDecompSize': data.get('fileDecompSize') ? data.get('fileDecompSize') : data.get('fileSize'),
            'rated': data.get('rated'),
            'ratedIcon': data.get('ratedIcon') ? data.get('ratedIcon') : '',
            'gradeAvg': data.get('gradeAvg'),
            'icon': data.get('icon'),
            //'backgroundColorpick' : data.get('backgroundColorpick') ? data.get('backgroundColorpick') : '',
            //'titleFontColorpick'  : '#ffffff', // data.get('titleFontColorpick') ? data.get('backgroundColorpick') : '#ffffff',
            'usbInstall': data.get('usbInstall'),
            'screenshotLarge1': data.get('screenshotLarge1'),
            'screenshotList': data.get('screenshotList'),
            'lastIndex': String(data.get('lastIndex')) ? data.get('lastIndex') : '',
            'titleLang': data.get('titleLang')
        };

        item.isDownloaded = DownloadedAppsMgr.isDownloaded(data.get('id'));

        if (item.isDownloaded) {
            item.installedVersion = DownloadedAppsMgr.getDownloadedAppInfo(data.get('id')).app_version;
            item.userRating = voltapi.WAS.getAppRating(data.get('id')) ? voltapi.WAS.getAppRating(data.get('id')) : 0;
        } else {
            var result = AppInstallMgr.getInstallList(data.get('id'));

            if (result && result.app_id == data.get('id')) {
                item.isInstalling = true;
                this.setInstallingRate(result);
            } else {
                item.isInstalling = false;
            }

            item.userRating = 0;
        }

        item.storageInfo = this.getStorageInfo();
        item.appInfoVMCollection = new AppInfoVMCollection();
        item.appInfoVMCollection.setCollection('detail');
        item.appInfoVMCollection.parse(data.get('relatedAppInfoCollection'));
        this.set(item);
        this.startListeningEvent();
    },

    /**
     * Check to download's button name
     * @method
     * @memberof DetailVM
     * @return {string}     btnName  Download, Cancel, Open
     */
    getDownloadBtnName: function () {
        var btnName = Volt.i18n.t('COM_SID_DOWNLOAD');

        if (this.get('isDownloaded')) {
            btnName = Volt.i18n.t('UID_OPEN');
        } else {
            if (this.checkInstallingApp()) {
                btnName = Volt.i18n.t('COM_SID_CANCEL');
            }
        }
        return btnName;
    },

    /**
     * Check to installing app
     * @method
     * @memberof DetailVM
     * @return {boolean}     boolean  If installing app then return true
     */
    checkInstallingApp: function () {
        var result = AppInstallMgr.getInstallList(this.get('id'));
        if (result && result.app_id == this.get('id')) {
            return true;
        }
        return false;
    },

    /**
     * Get app information frem WAS
     * @method
     * @memberof DetailVM
     * @return {object}     boolean
     */
    getAppInfo: function () {
        Volt.log("[DetailVM.js] getAppInfo ");
        voltapi.WAS.getAppInfo(this.get('id'));
    },

    /**
     * Reuqest to install app to AppInstallMgr
     * @method
     * @memberof DetailVM
     */
    installApp: function () {
        Volt.log("[DetailVM.js] installApp ");
        if (this.isDownloadableApp()) {
            AppInstallMgr.installApp(this.get('id'));

            if (AppInstallMgr.getAllInstallList().length > 1) {
                this.set('isInstalling', true);
            }

        } else {
            Models.externalStorageModel.checkConnectUSB(this.get('id'));
        }
    },

    /**
     * Reuqest to run app to WAS
     * @method
     * @memberof DetailVM
     */
    runApp: function (appID, payload) {
        Volt.log("[DetailVM.js] runApp ");
        EventMediator.trigger('DETAIL_LAUNCH_APP');
        AppInstallMgr.launchApp(this.get('id'), '');
    },

    /**
     * Reuqest to cancel installing app to App
     * @method
     * @memberof DetailVM
     */
    cancelInstallApp: function () {
        // [TODO] When press Cancel button, cancal installing app.
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_CANCEL_COMPLETED, this.handleInstalling);
        AppInstallMgr.cancelInstallApp(String(this.get('id')));
    },

    /**
     * Reuqest to show rating popup
     * @method
     * @memberof DetailVM
     */
    showRatingPopup: function () {
        Volt.log("[DetailVM.js] showRatingPopup ");
        //if(this.get('isDownloaded')){
        //Backbone.history.navigate('detail/popup/rating/'+ this.get('id') + "/" + this.get('userRating'), { trigger: true });
        //}
        var params = {
            app_id: this.get('id'),
            star_num: this.get('userRating')
        }
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_RATEING, JSON.stringify(params));

    },

    /**
     * Set default initialize data
     * @method
     * @memberof DetailVM
     */
    setDefault: function (bSearchAll) {
        this.clear().set(this.default);
        this.set('bSearchAll', bSearchAll);
        Models.detailModel.clear().set(Models.detailModel.default);
    },

    /**
     * Put user rating value to server
     * @method
     * @memberof DetailVM
     * @param {number} rating selected user's rating value.
     */
    setUserRating: function (userRating) {
        var self = this;

        Volt.log("[DetailVM.js] putAppGradePoint ");

        if (userRating !== this.get('userRating')) {

            self.set('userRating', userRating);
            // LocalStorage.setItem(self.get('id').toString(), userRating);
            var ret = voltapi.WAS.setAppRating(self.get('id').toString(), userRating);
            ServerAPI.putAppGradePoint({
                path: {
                    appId: this.get('id')
                },
                param: {
                    rate: userRating
                },
                success: function (data, status, response) {
                    Volt.log("[setUserRating] success");
                    Volt.KpiMapper.addEventLog('RATINGAPP', {
                        d: {
                            appid: this.appid
                        }
                    });
                },
                error: function (object, status, exception) {
                    Volt.log("[setUserRating] Occued error");

                },
                complete: function (object, status) {
                    Volt.log("[setUserRating] complete");
                }
            });
        }
    },
    /*
    DOWNLOAD_PROGRESS, downloadProgress
    DOWNLOAD , downloadResult === 0
    INSTALL_PROGRESS , downloadProgress
    INSTALL , installResult , installResult !== undefined
    DOWNLOAD_CANCELED   , cancelResult !== undefined  undefined ?�경??무시
    */
    startListeningEvent: function () {
        this.listenTo(EventMediator, 'DETAIL_POST_RATING', this.setUserRating);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_COMPLETED, this.handleInstalling);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_COMPLETED, this.handleInstalling);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADED_MGR_READY, this.installComplete);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_START, this.handleInstalling);
        this.listenToErrorEvent();
        // this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_CANCELED, this.handleInstalling);
    },

    stopListeningEvent: function () {
        try {
            this.stopListening(Models.detailModel);
            this.stopListening(EventMediator);
            if (this.get('appInfoVMCollection')) {
                this.get('appInfoVMCollection').stopListeningEvent();
            }
        } catch (e) {
            Volt.log('[DetailVM.js] stopListeningEvent(), error : ' + e);
        }
    },

    setInstallingRate: function (obj) {
        if (obj && obj.status) {
            switch (obj.status) {
            case CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_PROGRESS:
                this.set('nInitProgress', (obj.value / 100));
                break;
            case CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_RESULT:
            case CommonDefines.AppInstallMgr.STATUS_INSTALL_PROGRESS:
                this.nInitProgress = 100;
                break;
            }
        }
    },

    handleInstalling: function (eventInfo) {
        if (eventInfo && eventInfo.app_id == this.get('id')) {
            switch (eventInfo.eventType) {
            case CommonDefines.Event.INSTALL_START:
                if (eventInfo.value == 0) {
                    this.set('isInstalling', true);
                }
                break;
            case CommonDefines.Event.DOWNLOAD_COMPLETED:
                if (eventInfo.result !== 0) {
                    this.set('isInstalling', false);
                } else {
                    EventMediator.trigger('EVENT_DETAIL_SUCCESS_DOWNLOAD', {
                        app_id: this.get('id'),
                        result: 100
                    });
                }
                break;
            case CommonDefines.Event.INSTALL_COMPLETED:
                if (eventInfo.result !== 0) {
                    this.set('isInstalling', false);
                }
                break;
            case CommonDefines.Event.INSTALL_CANCEL_COMPLETED:
                if (eventInfo.result == 0) {
                    this.set('isInstalling', false);
                }
                break;
            case CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE:
                this.set('isInstalling', false);
                if (this.get('usbInstall')) {
                    Models.externalStorageModel.checkConnectUSB(this.get('id'));
                } else {
                    /*var setPopup = {
                            text: "This app cannot be downloaded to a USB storage device",
                            buttons: [
                                {
                                    name: Volt.i18n.t('COM_SID_OK')
                                }
                            ]
                        }
                        var msgPopup = new MsgPopupView(setPopup);*/
                    CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CANNT_DOWNLOADTOUSB);
                }
                break;
            case CommonDefines.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE:
                this.set('isInstalling', false);
                /* var setPopup = {
                        text: Volt.i18n.t('TV_SID_PREPARING_THE_TV_PLEASE_TRY_AGAIN_LATER'),
                        buttons: [
                            {
                                name: Volt.i18n.t('COM_SID_OK')
                            
                            }
                        ]
                    };
                    var msgPopup = new MsgPopupView(setPopup);*/
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE);

                break;
            default:
                this.set('isInstalling', false);
                if (CommonDefines.Event.INSTALL_FAIL_OTHERS == eventInfo.eventType) {
                    if (eventInfo.failCode) {
                        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD, eventInfo.failCode);
                        break;
                    }
                }
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD, eventInfo.eventType);
                break;
            }
        }
    },

    listenToErrorEvent: function () {
        var self = this;
        _.each(this.arrInstallErrorEvents, function (eventType, i) {
            self.listenTo(EventMediator, eventType, self.handleInstalling);
        });
    },

    stopListeningErrorEvent: function () {
        var self = this;
        _.each(this.arrInstallErrorEvents, function (eventType, i) {
            self.stopListening(eventType);
        });
    },

    installComplete: function () {
        if (DownloadedAppsMgr.isDownloaded(this.get('id'))) {
            this.set({
                'isDownloaded': true,
                'isInstalling': false
            });

        } else {
            this.set({
                'isDownloaded': false,
                'isInstalling': false
            });
        }
        EventMediator.trigger('EVENT_UPDATE_DOWNLOAD_BUTTON'); //fix bug of download button not update 
        this.set('storageInfo', this.getStorageInfo());
    },

    /**
     * Get storage information by WAS
     * @method
     * @memberof DetailVM
     * @return  {object}  storageText, usedMemory, totalMemory
     */
    getStorageInfo: function (WASMemory) {
        Volt.log("[DetailVM.js] getStorageInfo ");

        var localMemory = '';

        if (WASMemory) {
            localMemory = WASMemory;
        } else {
            localMemory = Volt.DeviceInfoModel.get('localMemory');
        }

        if (localMemory && localMemory !== -1) {

            Volt.err('[getStorageInfo] getMemory(): ' + localMemory);
            var arrTemp = localMemory.split('/');
            var storageRate = 0;
            var bFullMemory = false;
            var memoryInfo = [];
            var bCountUnit = 0;

            for (var i = 0; i < arrTemp.length; i++) {
                memoryInfo[i] = this.convertMbyte(arrTemp[i]);
            }

            if (!memoryInfo[0] || !memoryInfo[1]) {
                storageRate = 0;
            } else {
                var nRate = memoryInfo[0] / memoryInfo[1];
                storageRate = nRate ? nRate : 0;
            }

            return {
                storageRate: storageRate,
                storageInfo: localMemory,
            };

        } else {
            return {
                storageRate: 0.0,
                storageInfo: ''
            };
        }
    },

    /**
     * Cach detailModel's data to get data when historyback case
     * @method
     * @memberof DetailVM
     * @param   {num}     index  last focus of relatedApps
     */
    cacheData: function (index) {
        Volt.log("[DetailVM.js] cacheData ");
        var cacheData = _.clone(Models.detailModel.toJSON());
        cacheData.lastIndex = index;
        // cacheData.relatedAppInfoCollection = null;
        // cacheData.relatedAppInfoCollection.reset([]);
        detailHistoryCollection.add(cacheData);
        Models.detailModel.clear({
            silent: true
        });
    },

    /**
     * Get detailModel data to use historyback case
     * @method
     * @memberof DetailVM
     * @param   {string}   model_id  model_id to find data
     * @return  {boolean}  boolean   whether get cached data
     */
    pullCachedData: function (model_id) {
        Volt.log("[DetailVM.js] pullCachedData ");
        var model = detailHistoryCollection.get(model_id);

        if (model) {
            this.listenTo(Models.detailModel, 'change:id', this.parse);
            Models.detailModel.cashedParse(model.toJSON());
            detailHistoryCollection.remove(model_id);
            return true;
        }
        return false;
    },

    error: function (serverError) {
        this.trigger('error', serverError);
        Volt.log("[DetailVM.js] error" + serverError.code + ':::' + serverError.message);
    },

    isDownloadableApp: function () {
        Volt.log("[DetailVM.js] isDownloadableApp ");

        if (Volt.__SIM_STORAGE_FULL__) {
            return false;
        }

        var nMegabyte = 1048576;
        var needInstallingSize = parseInt(this.get('fileSize')) + parseInt(this.get('fileDecompSize'));
        var localMemory = Volt.DeviceInfoModel.get('localMemory');
        var arrTemp = localMemory.split('/');
        var remainedLocalMemory = 0;
        needInstallingSize = needInstallingSize + 10 * nMegabyte;
        needInstallingSize = Math.ceil(needInstallingSize / nMegabyte);
        for (var i = 0; i < arrTemp.length; i++) {
            arrTemp[i] = this.convertMbyte(arrTemp[i]);
        }

        remainedLocalMemory = Number(arrTemp[1]) - Number(arrTemp[0]);
        if (needInstallingSize < remainedLocalMemory) {
            return true;
        } else {
            return false;
        }
    },
    checkUsbMemory: function () {
        Volt.log("[DetailVM.js] checkUsbMemory ");
        return true
        var nMegabyte = 1048576;
        var needInstallingSize = parseInt(this.get('fileSize')) + parseInt(this.get('fileDecompSize'));
        needInstallingSize = needInstallingSize + 10 * nMegabyte;
        needInstallingSize = Math.ceil(needInstallingSize / nMegabyte);

        var result = this.getUsbStorages();
        var i = 0;
        if (result && result.storages) {
            len = result.storages.length;
            for (i = 0; i < len; i++) {
                Volt.log("[DetailVM.js] checkUsbMemory:i is " + i + " availableSize is " + result.storages[i].availableSize);
                Volt.log("[DetailVM.js] checkUsbMemory:needInstallingSize is " + needInstallingSize);
                if (needInstallingSize < this.setSuitablyUnit(result.storages[i].availableSize)) {
                    return true;
                }
            }
        } else {
            return false;
        }
        return false;
    },
    getUsbStorages: function () {
        if (!voltapi.ContentsMgr.isOpened()) {
            Volt.log('voltapi.ContentsMgr is not opened');
            return;
        }

        var bFlg = voltapi.ContentsMgr.connect();
        //var bFlg2 = voltapi.ContentsMgr.disconnect();
        Volt.log("[VoltApiWrapper.js] bFlg: " + bFlg);
        if (bFlg) {
            var UsbInfo = voltapi.ContentsMgr.getStorages();
            Volt.log("[VoltApiWrapper.js] getUsbStorages: " + JSON.stringify(UsbInfo));
            return UsbInfo;
        }

        return;
    },
    convertMbyte: function (strMemory) {
        Volt.log('[DetailVM.js] convertMbyte(), strMemory: ' + strMemory);
        var nMemory = strMemory.replace(/[^0-9.]/g, '');
        var strUnit = strMemory.replace(/[^a-zA-Z]/gi, '').toUpperCase();

        switch (strUnit) {
        case "KB":
            nMemory = nMemory / 1024;
            break;
        case "GB":
            nMemory = nMemory * 1024;
            break;
        case "BYTE":
            nMemory = nMemory;
            break;
        }
        return nMemory;
    },
    setSuitablyUnit: function (size) { //the unit of size is B
        var COUNTMB = 1024;
        var COUNTGB = 1024 * 1024;
        var unit = 'B';
        if (size >= COUNTGB) {
            size /= COUNTGB;
            unit = 'GB';
        } else if (size >= COUNTMB) {
            size /= COUNTMB;
            unit = 'MB';
        }
        size = parseFloat(size).toFixed(2);
        return {
            size: size,
            unit: unit
        };
    }

});

exports = new DetailVM;