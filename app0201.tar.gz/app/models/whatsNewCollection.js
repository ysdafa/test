/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview collection to manage whatsNew models.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    Q = Volt.require('modules/q.js'),
    _ = Volt.require("modules/underscore.js")._,
    ServerAPI = Volt.require("app/common/serverAPI.js"),
    AppInfoModel = Volt.require("app/models/appInfoModel.js");
var localStorage = Volt.require("lib/volt-local-storage.js");
var EventMediator = Volt.require('app/common/eventMediator.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
/**
 * @name WhatsNewCollection
 */
var WhatsNewCollection = Backbone.Collection.extend({
    /** @lends WhatsNewCollection.prototype */
    model: AppInfoModel,

    /**
     * Initialize WhatsNewCollection
     * @name WhatsNewCollection
     * @constructs
     */
    initialize: function () {},

    offline: function (data) {
        var deferred = Q.defer();

        if (data) {
            this.parse(data, "offline");
            deferred.resolve();
        } else {
            var cachingData = localStorage.getItem('apps-whatsnew-caching-data');
            Volt.log('[WhatsNewCollection] offline' + JSON.stringify(cachingData));
            if (cachingData && cachingData.length > 0) {
                data = cachingData;
                this.parse(data, "offline");
                deferred.resolve();
            } else {
                deferred.reject();
            }
        }
        if (Volt.DeviceInfoModel.get('networksStatus') == "OK") {
            this.listenTo(EventMediator, CommonDefines.Event.SERVERAPI_READY, this.fetch);
        } else {
            Volt.log('[WhatsNewCollection] networksStatus is not work');
        }

        return deferred.promise;
    },

    /**
     * request to fetch data
     * @method
     */
    fetch: function () {

        var self = this;
        var deferred = Q.defer();

        ServerAPI.getWhatsNew({
            success: function (data, status, response) {
                Volt.log("[whatsNewCollection.js] getWhatsNew sETag : " + response.headers.ETag);
                self.parse(data, status, response);
                deferred.resolve();
            },

            error: function (serverError) {
                self.error(serverError);
                deferred.reject();
            },

            complete: function (object, status) {

            }
        });

        return deferred.promise;
    },
    /**
     * on fetch success, call this func to parse given data from server.
     * @method
     * @param  {obejct} data      received data from server
     * @param  {object} status    RequestRequest's status
     * @param  {object} exception exception object
     */
    parse: function (data, status, response) {

        var self = this,
            aAppList = [],
            results = JSON.parse(data).apps,
            sETag = response && response.headers.ETag != undefined ? response.headers.ETag : '';

        var cachedETag = localStorage.getItem('apps-whatsnew-caching-etag');
        localStorage.setItem('apps-whatsnew-caching-data', data);

        Volt.log("[whatsNewCollection.js] parse sETag : " + status + " " + sETag);
        if (sETag != '') {
            Volt.log("[whatsNewCollection.js] apps-whatsnew-caching-etag : " + sETag);
            if (cachedETag == sETag) {
                return;
            } else {
                localStorage.setItem('apps-whatsnew-caching-etag', sETag);
            }
        }

        _.each(results, function (app, i) {

            var appInfoModel = new AppInfoModel(app, {
                parse: true
            });

            if (appInfoModel.get('id')) {
                aAppList.push(appInfoModel);
            }

            if (i == 0) {
                aAppList.push({
                    id: "PIA"
                });
            }
        });

        this.reset(aAppList);
    },

    /**
     * error func when fetch error occur
     * @method
     * @param  {object} object    received data from server
     * @param  {object} status    RequestRequest's status
     * @param  {object} exception exception object
     */
    error: function (serverError) {
        print('[WhatsNewCollection.js] fetch error : ' + serverError.code + ':::' + serverError.message);

        this.trigger('error', serverError);
    },
    /**
     * reset collection
     * @method
     */
    clear: function () {
        this.reset([]);
    }
});

exports = WhatsNewCollection;