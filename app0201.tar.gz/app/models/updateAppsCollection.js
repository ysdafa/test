/** 
 * @author hyoseon Ju (hyoseon.ju@samsung.com)
 * @fileoverview UpdateApps Collection.
 * @date    2014/09/17 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    voltapi = Volt.require('voltapi.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js'),
    UpdateAppsModel = Volt.require("app/models/updateAppsModel.js"),
    EventMediator = Volt.require('app/common/eventMediator.js');

/**
 * @name UpdateAppsCollection
 */
var UpdateAppsCollection = Backbone.Collection.extend({
    /** @lends UpdateAppsCollection.prototype */

    model: UpdateAppsModel,

    /**
     * Initialize UpdateAppsCollection
     * @name UpdateAppsCollection
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, CommonDefines.Event.REQUEST_APP_LIST, this.parse);
    },

    fetch: function () {
        Volt.log("[UpdateAppsCollection.js] fetch()");

        var retValue = voltapi.WAS.requestAppList(CommonDefines.WAS.WAS_LIST_TYPE_APP_UPDATE_LIST);

        if (retValue) {
            Volt.log('[UpdateAppsCollection] fetch() :::: return Value' + retValue);
        } else {
            Volt.log('[UpdateAppsCollection] fetch() Error :::: getAppList not reasonable retValue');
            // var count = voltapi.WAS.getAppCount(CommonDefines.WAS.APPS_TYPE_ALL, CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE, CommonDefines.WAS.APPS_INFO_FEATURED_ALL);        
            // var sList = voltapi.WAS.getAppList(CommonDefines.WAS.APPS_TYPE_ALL, CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE, CommonDefines.WAS.APPS_INFO_FEATURED_ALL, CommonDefines.WAS.VIEWMODE_CUSTOM, 0, count);

            // this.parse(sList);
        }
    },

    /**
     * parse given data
     * @method
     * @param  {Collection} collection collection correspond to this
     * @param  {object} options    additional data
     */
    parse: function (data, status, exception) {
        Volt.log("[UpdateAppsCollection.js] parse()");

        var self = this,
            results = data,
            aAppList = [];

        _.each(results, function (appData) {
            var oUpdateAppsModel = new UpdateAppsModel(appData, {
                parse: true
            });

            if (oUpdateAppsModel.get('app_id') && oUpdateAppsModel.get('app_featured') == CommonDefines.WAS.APPS_INFO_FEATURED_MYAPP) {
                aAppList.push(oUpdateAppsModel);
            }
        });

        Volt.log(aAppList);
        this.reset(aAppList);
        EventMediator.trigger('UPDATE_APPS_COLLECTION_FETCHED');
    }
});

exports = UpdateAppsCollection;