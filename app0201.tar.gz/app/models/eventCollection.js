/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview collection to manage event models.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    Q = Volt.require('modules/q.js'),
    _ = Volt.require("modules/underscore.js")._,
    ServerAPI = Volt.require("app/common/serverAPI.js"),
    AppInfoModel = Volt.require("app/models/appInfoModel.js");

/**
 * @name EventCollection
 */
var EventCollection = Backbone.Collection.extend({
    /** @lends EventCollection.prototype */
    model: AppInfoModel,
    commonData: {},

    /**
     * Initialize EventCollection
     * @name EventCollection
     * @constructs
     */
    initialize: function () {},

    /**
     * request to fetch data
     * @method
     */
    fetch: function () {

        var self = this;
        var deferred = Q.defer();

        ServerAPI.getEvent({
            success: function (data, status, response) {
                self.parse(data, status, response);
                deferred.resolve();
            },

            error: function (serverError) {
                self.error(serverError);
                deferred.reject();
            },

            complete: function (object, status) {

            }
        });

        return deferred.promise;
    },
    /**
     * on fetch success, call this func to parse given data from server.
     * @method
     * @param  {obejct} data      received data from server
     * @param  {object} status    RequestRequest's status
     * @param  {object} exception exception object
     */
    parse: function (data, status, exception) {

        var self = this,
            aAppList = [],
            result = JSON.parse(data),
            results = result.apps;

        this.commonData = {
            eventBannerImg: result.eventBannerImg,
            eventTitleLang: result.eventTitleLang,
            eventTitle: result.eventTitle
        };

        _.each(results, function (app, i) {

            var appInfoModel = new AppInfoModel(app, {
                parse: true
            });

            if (appInfoModel.get('id')) {
                aAppList.push(appInfoModel);
            }
        });

        this.reset(aAppList, this.commonData);
    },
    /**
     * error func when fetch error occur
     * @method
     * @param  {object} object    received data from server
     * @param  {object} status    RequestRequest's status
     * @param  {object} exception exception object
     */
    error: function (serverError) {
        print('[EventCollection.js] fetch error : ' + serverError.code + ':::' + serverError.message);

        this.trigger('error', serverError);
    },
    /**
     * reset collection
     * @method
     */
    clear: function () {
        this.reset([]);
    }
});

exports = EventCollection;