/** 
 * @author dohyoung Kim (dohyoung7.kim@samsung.com)
 * @fileoverview This module get device information form WAS.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    voltapi = Volt.require('voltapi.js');

var self;

/**
 * @name DeviceInfoModel
 */
var DeviceInfoModel = Backbone.Model.extend({
    /** @lends DeviceInfoModel.prototype */
    defaults: {

        // START WAS "GetDebugInfo"
        appsDbStatus: '',
        categoryType: '',
        chipInfo: '',
        country: '',
        duid: '',
        firmwareVersion: '',
        hubsiteStatus: '',
        lineupModel: '',
        localSet: '',
        localTime: '',
        macAddr: '',
        managerStatus: '',
        modelId: '',
        networksStatus: 'OK',
        productType: '',
        sefVersion: '',
        serverType: '',
        syncStatus: '',
        wpBaseline: '',
        countryCode: '',
        language: '',
        resolution: '',
        highContrast: '',
        tts: '',
        visibleCursor: '',
        mls: 0,
        restHeaderStatus: 1,
        // END WAS "GetDebugInfo"
    },

    bWASReady: false,

    /**
     * Initialize DeviceInfoModel
     * @name DeviceInfoModel
     * @constructs
     */
    initialize: function () {
        self = this;
        this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, this.onWASInitialized);
        this.listenTo(EventMediator, CommonDefines.Event.CONNECT_NETWORK, this.onConnectNetwork);
        this.listenTo(EventMediator, CommonDefines.Event.DISCONNECT_NETWORK, this.onDisConnectNetwork);
        this.listenTo(EventMediator, CommonDefines.Event.NETWORK_ERROR, this.onNetworkError);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADED_MGR_READY, this.onChangeLocalMemory);

        Volt.log("[deviceInfoModel] init tts status is: " + Vconf.getInteger(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS));
        self.set('tts', Vconf.getInteger(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS));
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS, this.onChangeTTS);
    },

    /**
     * Initialize when WAS is ready.
     * @method
     */
    onWASInitialized: function () {
        this.bWASReady = true;
        this.updateInfoFromWAS();
        EventMediator.trigger(CommonDefines.Event.DEVICE_INFO_READY);
    },

    isWASReady: function () {
        return this.bWASReady;
    },

    /**
     * Connect network.
     * @method
     */
    onConnectNetwork: function () {
        Volt.err("[deviceInfoModel.js] onConnectNetwork()");
        this.set('networksStatus', 'OK');
        EventMediator.trigger(CommonDefines.Event.CHANGE_NETWORK_STATUS, {
            "networksStatus": "OK"
        });
    },

    /**
     * Disconnect network.
     * @method
     */
    onDisConnectNetwork: function () {
        Volt.err("[deviceInfoModel.js] onDisConnectNetwork()");
        this.set('networksStatus', 'NG');
        EventMediator.trigger(CommonDefines.Event.CHANGE_NETWORK_STATUS, {
            "networksStatus": "NG"
        });
    },

    /**
     * Error network.
     * @method
     */
    onNetworkError: function () {
        Volt.err("[deviceInfoModel.js] onNetworkError()");
        this.set('networksStatus', 'NG');
    },

    /**
     * Update the device info from WAS.
     * @method
     */
    updateInfoFromWAS: function () {

        var oDebugInfo = {};

        oDebugInfo.firmware_version = voltapi.WAS.getInfolinkVer();
        oDebugInfo.model_id = Vconf.getString(CommonDefines.Vconf.DB_COMSS_MODELID);
        oDebugInfo.duid = Vconf.getString(CommonDefines.Vconf.DB_COMSS_DUID);

        oDebugInfo.country_code = Vconf.getString(CommonDefines.Vconf.DB_COMSS_COUNTRYCODE);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_COMSS_COUNTRYCODE, self.onChangeCountryCode);
        oDebugInfo.language = self.getLanguageCode();
        //voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_WIDGET_LANGUAGE, self.onChangeLanguage);

        if (voltapi.util.onLangunageChangedListener) {
            voltapi.util.onLangunageChangedListener(self.onChangeLanguagelistener);
        } else {
            voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_WIDGET_LANGUAGE, self.onChangeLanguage);
        }

        oDebugInfo.resolution = String(Volt.height);

        // Accessibility
        oDebugInfo.highContrast = Vconf.getInteger(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST, this.onChangeHighContrast);
        oDebugInfo.tts = Vconf.getInteger(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS, this.onChangeTTS);
        oDebugInfo.audioDescription = Vconf.getInteger(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_AUDIO_DESCRIPTION);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_AUDIO_DESCRIPTION, this.onChangeAudioDescription);
        oDebugInfo.focusZoom = Vconf.getInteger(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_FOCUSZOOM);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_FOCUSZOOM, this.onChangeFocusZoom);

        oDebugInfo.visibleCursor = Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE, this.onChangeVisibleCursor);

        /*vonf events*/
        oDebugInfo.localMemory = voltapi.WAS.getMemory();
        //voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.SYSTEM_WAS_APP_CHANGE, this.onChangeLocalMemory);

        oDebugInfo.mls = Vconf.getInteger(CommonDefines.Vconf.DB_MLS_STATE);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MLS_STATE, this.onMLSStateChange);

        // Check CEC Mode
        /* var CECMode = Vconf.getInteger(CommonDefines.Vconf.MEMORY_VOLT_PANEL_HIDE);
        if (CECMode == 1) {
            Volt.err("[deviceInfoModel.js] CEC Mode : " + CECMode);
	     Volt.log('[deviceInfoModel.js] updateInfoFromWAS, exit apps panel, apps panel will hide in background');
            Volt.exit();
        }*/
        //voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.MEMORY_VOLT_PANEL_HIDE, this.onPanelHide);

        this.set('appsDbStatus', oDebugInfo.apps_db_status || '');
        this.set('categoryType', oDebugInfo.category_type || '');
        this.set('chipInfo', oDebugInfo.chip_info || '');
        this.set('duid', oDebugInfo.duid || '');
        this.set('firmwareVersion', oDebugInfo.firmware_version || 'T-INFOLINK2014-1002');
        this.set('hubsiteStatus', oDebugInfo.hubsite_status || '');
        this.set('lineupModel', oDebugInfo.lineup_model || '');
        this.set('localSet', oDebugInfo.local_set || '');
        this.set('localTime', oDebugInfo.local_time || '');
        this.set('macAddr', oDebugInfo.mac_addr || '');
        this.set('managerStatus', oDebugInfo.manager_status || '');
        this.set('modelId', oDebugInfo.model_id || '14_GOLFP_TIZEN');
        // this.set('networksStatus', '');
        this.set('productType', oDebugInfo.product_type || '');
        this.set('sefVersion', oDebugInfo.sef_version || '');
        this.set('serverType', oDebugInfo.server_type || '');
        this.set('syncStatus', oDebugInfo.sync_status || '');
        this.set('wpBaseline', oDebugInfo.wp_baseline || '');
        this.set('countryCode', oDebugInfo.country_code || '');
        this.set('language', oDebugInfo.language || 'en');
        this.set('resolution', oDebugInfo.resolution || '1080');
        this.set('highContrast', oDebugInfo.highContrast || '');
        this.set('focusZoom', oDebugInfo.focusZoom || '');
        this.set('tts', oDebugInfo.tts || '');
        this.set('visibleCursor', oDebugInfo.visibleCursor || '');
        this.set('mls', oDebugInfo.mls || 0);
        this.set('localMemory', oDebugInfo.localMemory || '');

        Volt.err("[deviceInfoModel.js] updateInfoFromWAS() deviceInfo : " + JSON.stringify(oDebugInfo));
    },

    /**
     * onChangeCountryCode Callback.
     * @method
     */
    onChangeCountryCode: function (key, value) {
        Volt.err("[deviceInfoModel.js] onChangeCountryCode() : " + value);
        self.set('countryCode', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_COUNTRY_CODE);
    },

    /**
     * onChangeLanguage Callback.
     * @method
     */
    onChangeLanguage: function (key, value) {
        Volt.err("[deviceInfoModel.js] onChangeLanguage() : " + value);
        self.set('language', value || '');
        //EventMediator.trigger(CommonDefines.Event.CHANGE_LANGUAGE);
        Volt.quit();
    },


    onChangeLanguagelistener: function (lang) {
        Volt.err("[deviceInfoModel.js] onLangunageChangedListener() : " + lang);
        self.set('language', lang || '');
        //EventMediator.trigger(CommonDefines.Event.CHANGE_LANGUAGE);
        Volt.quit();
    },


    /**
     * onChangeHighContrast Callback.
     * @method
     */
    onChangeHighContrast: function (key, value) {
        Volt.err("[deviceInfoModel.js] onChangeHighContrast() : " + value);
        self.set('highContrast', value || '');
        if (value) {
            HALOUtil.highContrast = true;
        } else {
            HALOUtil.highContrast = false;
        }
        EventMediator.trigger(CommonDefines.Event.CHANGE_HIGH_CONTRAST);
    },

    /**
     * onChangeTTS Callback.
     * @method
     */
    onChangeTTS: function (key, value) {
        Volt.err("[deviceInfoModel.js] onChangeTTS() : " + value);
        self.set('tts', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_TTS);
    },

    /**
     * onChangeAudioDescription Callback.
     * @method
     */
    onChangeAudioDescription: function (key, value) {
        Volt.err("[deviceInfoModel.js] onChangeAudioDescription() : " + value);
        self.set('audioDescription', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_AUDIO_DESCRIPTION);
    },

    /**
     * onChangeFocusZoom Callback.
     * @method
     */
    onChangeFocusZoom: function (key, value) {
        Volt.err("[deviceInfoModel.js] onChangeFocusZoom() : " + value);
        self.set('focusZoom', value || '');
        if (value) {
            HALOUtil.enlarge = true;
        } else {
            HALOUtil.enlarge = false;
        }
        EventMediator.trigger(CommonDefines.Event.CHANGE_FOCUS_ZOOM);
    },

    /**
     * onChangeVisibleCursor Callback.
     * @method
     */
    onChangeVisibleCursor: function (key, value) {
        Volt.err("[deviceInfoModel.js] onChangeVisibleCursor() : " + value);
        self.set('visibleCursor', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_VISIBLE_CURSOR, value);
    },

    onMLSStateChange: function (key, value) {
        Volt.err("[deviceInfoModel.js] onMLSStateChange() : " + value);
        self.set('mls', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_MLS_STATE, value);
    },
    /**
     * onPanelHide Callback.
     * @method
     */
    onPanelHide: function (key, value) {
        Volt.err("[deviceInfoModel.js] onPanelHide() : " + value);
        if (value == 1) {
            Volt.log('[deviceInfoModel.js] onPanelHide, exit apps panel, apps panel will hide in background');
            Volt.exit();
        }
    },

    onChangeLocalMemory: function () {
        Volt.err("[deviceInfoModel.js] onChangeLocalMemory()");
        var localMemory = voltapi.WAS.getMemory();
        self.set('localMemory', localMemory || '');
        EventMediator.trigger(CommonDefines.Event.CHAHGE_LOCAL_MEMORY, localMemory);
    },

    getLanguageCode: function () {
        var languageCode = '';

        var preDefine = {
            'fr_CA': 'fr-US',
            'es_MX': 'es-US',
            'pt_BR': 'pt-US',
            'en_GB': 'en-GB',
            'zh_CN': 'zh-CN',
            'zh_HK': 'zh-HK',
            'zh_TW': 'zh-TW'
        }

        var vconfMenuLang = Vconf.getString(CommonDefines.Vconf.DB_MENU_WIDGET_LANGUAGE);
        var lang = vconfMenuLang.split('.')[0];
        Volt.err("[deviceInfoModel.js] getLanguageCode(), Lang: " + vconfMenuLang);

        if (preDefine[lang]) {
            languageCode = preDefine[lang];
        } else {
            languageCode = lang.split('_')[0];
        }

        return languageCode;
    }
});

exports = new DeviceInfoModel();