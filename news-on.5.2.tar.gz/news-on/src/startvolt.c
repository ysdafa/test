#include <sharedvc.h>
#include <dbg.h>

int main(int argc, char **argv)
{
	LOGE("In main function");
	bundle *b = bundle_create();
 	bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
	bundle_add(b,"--app-js", "/opt/down/panels/newson/src/app.js");
    bundle_add(b,"--data-path", "/opt/down/panels/newson_temp");		
	bundle_add(b, "--v8.gc.threshold", "102400");
	bundle_add(b, "--v8.gc.threshold-poll-interval", "3");
	startVoltContainer(argc, argv, b);
	bundle_free(b);
	LOGE("wainting");
	return 0;
}

