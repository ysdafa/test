//scene.width
var resolution = null;
if(scene.width == 1280){
    resolution = 720;
}else{
    resolution = 1080;
}
var ResourcePath = "images/"+resolution+"/";
print('ResourcePath-------------------------'+ResourcePath);
var NewsonResourceMgrTemplate = {
    DetailArrowUp             : Volt.getRemoteUrl(ResourcePath + 'arrow/detail_arrow_up.png'),
    DetailArrowDown             : Volt.getRemoteUrl(ResourcePath + 'arrow/detail_arrow_down.png'),
    WeatherArrowLeft            : Volt.getRemoteUrl(ResourcePath + 'arrow/weather_arrow_left.png'),    
    WeatherArrowRight           : Volt.getRemoteUrl(ResourcePath + 'arrow/weather_arrow_right.png'),
    SettingArrowLeft            : Volt.getRemoteUrl(ResourcePath + 'arrow/setting_arrow_left.png'),
    SettingArrowRight           : Volt.getRemoteUrl(ResourcePath + 'arrow/setting_arrow_right.png'),
    WeatherTempUp               : Volt.getRemoteUrl(ResourcePath + 'news_temperature_icon_h.png'),
    WeatherTempDown             : Volt.getRemoteUrl(ResourcePath + 'news_temperature_icon_l.png'),
    WeatherSinaIcon             : Volt.getRemoteUrl(ResourcePath + 'news_weather_ch_cp_icon.png'),
    AppsCheck                   : Volt.getRemoteUrl(ResourcePath + "common/arrow/apps_check.png"),
    PopupSublistArrowDownNormal : Volt.getRemoteUrl(ResourcePath + "common/arrow/popup_sublist_arrow_up_n.png"),
    PopupSublistArrowDownFocus  : Volt.getRemoteUrl(ResourcePath + "common/arrow/popup_sublist_arrow_up_f.png"),
    IconBlankThumbnail          : Volt.getRemoteUrl(ResourcePath + 'icon/icon_blank_thumbnail.png'),
    FocusGrid                   : Volt.getRemoteUrl(ResourcePath + "icon/focus_grid.png"),
    ComnIconTmSetting           : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_setting.png'),
    ComnIconTmSettingSel        : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_setting_sel.png'),
    ComnIconTmSettingNor        : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_setting_nor.png'),
    ComnIconTmClose             : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_close.png'),
    ComnIconTmCloseSel          : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_close_sel.png'),
    ComnIconTmCloseNor          : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_close_nor.png'),
    ComnIconPageReturn          : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_return.png'),
    ComnIconPageReturnSel         : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_return_sel.png'),
    ComnIconPageReturnNor         : Volt.getRemoteUrl(ResourcePath + 'icon/comn_icon_tm_return_nor.png'),
    NewsCpIconSinaW             : Volt.getRemoteUrl(ResourcePath + 'news_cp_icon_sina_w.png'),
    NewsCpIconSinaB             : Volt.getRemoteUrl(ResourcePath + 'news_cp_icon_sina_b.png'),
    NewsCpIconYahooBrasil       : Volt.getRemoteUrl(ResourcePath + 'news_cpicon_yahoo_brasil.png'),
    KeyscreenScrollPNormal      : Volt.getRemoteUrl(ResourcePath + "scroll/keyscreen_scroll_pn.png"),
    KeyscreenScrollPOver        : Volt.getRemoteUrl(ResourcePath + "scroll/keyscreen_scroll_po.png"),
    KeyscreenScrollPFocus       : Volt.getRemoteUrl(ResourcePath + "scroll/keyscreen_scroll_pf.png"),
    KeyscreenScrollVPNormal     : Volt.getRemoteUrl(ResourcePath + "scroll/keyscreen_scroll_vertical_pn.png"),
    ChDefaultImageLl01          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_ll_01.jpg'),
    ChDefaultImageLl02          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_ll_02.jpg'),
    ChDefaultImageSl01          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_sl_01.jpg'),
    ChDefaultImageSL02          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_sl_02.jpg'),
    ChDefaultImageSs01          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_ss_01.jpg'),
    ChDefaultImageSs02          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_ss_02.jpg'),
    ChDefaultImageSs03          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_ss_03.jpg'),
    ChDefaultImageSs04          : Volt.getRemoteUrl(ResourcePath + 'china_main_default_image/ch_default_image_ss_04.jpg'),
    PopupCheckBox               : Volt.getRemoteUrl(ResourcePath + 'checkbox/popup_check_box.png'),
    PopupCheckBoxFocus          : Volt.getRemoteUrl(ResourcePath + 'checkbox/popup_check_box_f.png'),
    PopupCheckIconNormal        : Volt.getRemoteUrl(ResourcePath + 'checkbox/popup_check_icon_n.png'),
    PopupCheckIconFocus         : Volt.getRemoteUrl(ResourcePath + 'checkbox/popup_check_icon_f.png'),
    BtnStyleCFocus              : Volt.getRemoteUrl(ResourcePath + 'btn/btn_style_c_f.png'),
    BtnStyleCNormal             : Volt.getRemoteUrl(ResourcePath + 'btn/btn_style_c_n.png'),
    BtnStyleCSelected           : Volt.getRemoteUrl(ResourcePath + 'btn/btn_style_c_s.png'),
    BtnStyleCDisabled           : Volt.getRemoteUrl(ResourcePath + 'btn/btn_style_c_d.png'),
    NewsTemperatureIconHigh     : Volt.getRemoteUrl(ResourcePath + 'news_temperature_icon_h.png'),
    NewsTemperatureIconLow      : Volt.getRemoteUrl(ResourcePath + 'news_temperature_icon_l.png'),
    ToolTipBalloon              : Volt.getRemoteUrl(ResourcePath + 'balloon/popup_balloon.png'),
    ToolTipTailUp               : Volt.getRemoteUrl(ResourcePath + 'balloon/popup_balloon_tail_u.png'),
    ToolTipTailDown             : Volt.getRemoteUrl(ResourcePath + 'balloon/popup_balloon_tail_d.png'),
    ToolTipTailLeft             : Volt.getRemoteUrl(ResourcePath + 'balloon/popup_balloon_tail_l.png'),
    ToolTipTailRight            : Volt.getRemoteUrl(ResourcePath + 'balloon/popup_balloon_tail_r.png'),
}
exports = NewsonResourceMgrTemplate;

