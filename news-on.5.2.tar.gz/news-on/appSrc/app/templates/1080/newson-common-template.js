var ScreenTemplate = Volt.require('app/templates/1080/newson-screen-template.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
var MessageBoxCommon = {
        bgColor :  Volt.hexToRgb('#0f1826'),
        buttonSize : {
            width : Volt.width*270/1920,
            height : Volt.height*66/1080
        },
        buttonStyle : {
            textColor : {
                all : Volt.hexToRgb('#464646'),
                normal : Volt.hexToRgb('#ffffff', 60),
                selected : Volt.hexToRgb('#fbba2d'),
                disabled : Volt.hexToRgb('#ffffff', 10)
            },
            image : {
                all : Volt.getRemoteUrl('images/1080/btn/btn_style_c_f.png'),
                normal : Volt.getRemoteUrl('images/1080/btn/btn_style_c_n.png'),
                selected : Volt.getRemoteUrl('images/1080/btn/btn_style_c_s.png'),
                disabled : Volt.getRemoteUrl('images/1080/btn/btn_style_c_d.png')
            },
            fontSize : {
                all : 36,
                normal : 36
            },
            color : {
                //all : Volt.hexToRgb('#ffffff', 95),
                "normal" : Volt.hexToRgb('#ffffff', 0),
                "disabled" : Volt.hexToRgb('#ffffff', 0),
                "focused":Volt.hexToRgb('#ffffff', 100),
                "roll-over":Volt.hexToRgb('#ffffff', 100),
                "focused-roll-over":Volt.hexToRgb('#ffffff', 100),
                "selected":Volt.hexToRgb('#ffffff', 100),
                "disabled-focused":Volt.hexToRgb('#ffffff', 100)
            }
        }
};
var CommonTemplate = {

    container : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : ScreenTemplate.height,
        color : ScreenTemplate.transparentColor
    },
    arrow : {
        normal : {
            opacity : 153 //255 * 0.6
        },
        focus : {
            opacity : 255
        }
    },
    pageReturn : {
        normal : {
            src : ResourceMgr.ComnIconPageReturn,//Volt.getRemoteUrl('images/1080/icon/comn_arrow_page_return.png'),
            opacity : 255 //255 * 0.6
        },
        focus : {
            src : ResourceMgr.ComnIconPageReturnSel,//Volt.getRemoteUrl('images/1080/icon/comn_arrow_page_return.png'),
            opacity : 255
        }
    },
    
    pageClose : {
        normal : {
            src : ResourceMgr.ComnIconTmClose,//Volt.getRemoteUrl('images/1080/icon/comn_arrow_page_return.png'),
            opacity : 255 //255 * 0.6
        },
        focus : {
            src : ResourceMgr.ComnIconTmCloseSel,//Volt.getRemoteUrl('images/1080/icon/comn_arrow_page_return.png'),
            opacity : 255
        }
    },

    nonCursor : {
        left : '',
        right : '',
        top : '',
        bottom : '',
        topLeft : '',
        topRight : '',
        bottomRight : '',
        bottomLeft : ''
    },

    buttonTextStyleC : {
        fontSize : {
            all : 36,
            normal : 32
        },
        textColor : {
            all : Volt.hexToRgb('#464646'),
            normal : Volt.hexToRgb('#ffffff', 60),
            selected : Volt.hexToRgb('#fbba2d'),
            disabled : Volt.hexToRgb('#ffffff', 10)
        },
//        border : {
//            normal : {
//                width : 1,
//                color : Volt.hexToRgb('#ffffff', 20)
//            },
//            focused : {
//                width : 3,
//                color : Volt.hexToRgb('#ffffff')
//            },
//            selected : {
//                width : 3,
//                color : Volt.hexToRgb('#fbba2d', 80)
//            },
//            disabled : {
//                width : 1,
//                color : Volt.hexToRgb('#ffffff', 10)
//            }
//        },
        color : {
            all : Volt.hexToRgb('#ffffff', 95),
            normal : Volt.hexToRgb('#ffffff', 0),
            selected : Volt.hexToRgb('#ffffff', 95),
            disabled : Volt.hexToRgb('#ffffff', 0)
        },
        image : {
            all : Volt.getRemoteUrl('images/1080/btn/btn_style_c_f.png'),
            normal : Volt.getRemoteUrl('images/1080/btn/btn_style_c_n.png'),
            selected : Volt.getRemoteUrl('images/1080/btn/btn_style_c_s.png'),
            disabled : Volt.getRemoteUrl('images/1080/btn/btn_style_c_d.png')
        }
    },

    MessageBoxNoTitle : {
        type : 'MessageBox',
        width : ScreenTemplate.width,
        height : ScreenTemplate.height,
        color : MessageBoxCommon.bgColor,
        contentType : '{{contentType}}',
        contentTextFont : '34px',
        buttonType : '{{buttonType}}'
    },

    tooltip : {
        type : 'WinsetToolTip',
        x: '{{x}}',
    	y: '{{y}}',
    	width: '{{w}}',
    	height: '{{h}}',
    	style: '{{style}}',
    	nResoultionStyle: '{{nResoultionStyle}}',
    	text: '{{text}}',
    	tailPostion: '{{tailPostion}}',
    	//parent:Volt.WinsetRoot
    },
        
    MessageBoxCommon : MessageBoxCommon
};
exports = CommonTemplate;
