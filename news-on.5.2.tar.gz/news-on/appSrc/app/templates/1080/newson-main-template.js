var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
var WinsetButton = Volt.require('WinsetUIElement/winsetButton.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var NewsonMainTemplate = {
    header : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.width,//1920,
        height : Volt.height * 0.133333,//144, //1080 * 0.133333
        color : Volt.hexToRgb('#0f1826',0),
        children : [{
            id : 'main-header-tools',
            type : 'widget',
            x : Volt.width  - Volt.sourceControlWidth * 0.052604 ,//1820, //1920 * (1 - 1 * 0.052083)
            y : 0,
            width : 200 ,//200,// 1920 * 0.052083 * 2
            height : Volt.height * 0.133333,//144,//1080 * 0.133333
            color : Volt.hexToRgb('#0f1826',0),
            children : [{
                id : 'main-header-icon-setting',
                type : 'Button',
                x : (Volt.is720p)? 0 : -Volt.sourceControlWidth*4/1920,
                y : (Volt.is720p)? 0 : -Volt.height*4/1080,
                width : 101+((Volt.is720p)? 0: 2*(Volt.sourceControlWidth*4/1920)),//101, // 1920 * 0.052604
                height : Volt.height * 0.133333+((Volt.is720p)? 0 :Volt.height*8/1080),//144, //1080 * 0.133333
                icon: {
                    x: (Volt.sourceControlWidth * 0.052604 + ((Volt.is720p)? 0 : Volt.sourceControlWidth*8/1920) - Volt.sourceControlWidth*36/1920)/2,
                    y: (Volt.height * 0.133333 + ((Volt.is720p)? 0 : Volt.height*8/1080) - Volt.height*36/1080)/2,
                    width: 36,
                    height: 36,
                    src: ResourceMgr.ComnIconTmSetting,
                },
                custom : {
                    'focusable' : true
                },
            }, {
                id : 'main-header-icon-close',
                type : 'Button',
                x : Volt.sourceControlWidth * 0.052604 - ((Volt.is720p)? 0 : Volt.sourceControlWidth*4/1920),//100, // 1920 * 0.052083
                y : ((Volt.is720p)? 0 : -Volt.height*4/1080),
                width : 101+((Volt.is720p)? 0: 2*(Volt.sourceControlWidth*4/1920)),//101, // 1920 * 0.052604
                height : Volt.height * 0.133333 + ((Volt.is720p)?0:Volt.height*8/1080),//144, //1080 * 0.133333
                icon: {
                    x: (Volt.sourceControlWidth * 0.052604 + ((Volt.is720p)?0:Volt.sourceControlWidth*8/1920) - Volt.sourceControlWidth*36/1920)/2,
                    y: (Volt.height * 0.133333 + ((Volt.is720p)?0:Volt.height*8/1080) - Volt.height*36/1080)/2,
                    width: 36,
                    height: 36,
                    src: ResourceMgr.ComnIconTmClose,
                },
                custom : {
                    'focusable' : false
                },
            },
            {
                    type : 'widget',
                    width : 1,
                    x:0,
                    id:'main-header-icon-divide-one',
                    height : Volt.height * 0.133333,//144,//1080 * 0.133333
                    color : Volt.hexToRgb('#ffffff'),
                    opacity : 25 //255 * 0.1
            },
            {
                    type : 'widget',
                    width : 1,
                    x:1+Volt.sourceControlWidth * 0.052604,
                    height : Volt.height * 0.133333,//144,//1080 * 0.133333
                    color : Volt.hexToRgb('#ffffff'),
                    opacity : 25 //255 * 0.1
            },
            ]
        }]
    },

    category : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.width,//1920,
        height : Volt.height * 0.066667,//72, // 1080 * 0.066667
        color : Volt.hexToRgb('#f2f2f2',0),
        children : [{
            type : 'text',
            x : 0,
            y : Volt.height * (0.005556 + 45 / 1080),//52, //1080 * (0.066667 - 0.018519) 
            width : Volt.width - Volt.width * 0.018229,//1885,//1920 - 1920 * 0.018229
            height : Volt.height * 0.018519,//20,//1080 * 0.018519
            font : "Samsung SVD_Medium 13px",
            id : 'properity',
            text : '{{properity}}',
            horizontalAlignment : 'right',
            textColor : Volt.hexToRgb('#ffffff', 30)
        }, {
            type : 'image',
            x : Volt.width - Volt.width*192/1920,//1774, //1920 - 1920 * 0.018229 - 111
            y : Volt.height * 0.005556,//15, // 1080 * 0.013889
            width : Volt.width*192/1920,
            height : Volt.height*45/1080,
            id : 'cpLogo',
            src : '{{cpLogo}}'
        }, {
            
            type : 'widget',
            color : Volt.hexToRgb('#ffffff',10),
            x:0,
            y:0,
            width:Volt.width,
            height : 1,// 1080 * 0.066667
        }]
    },

    content : {
        type : 'GridListControl',
        id:'main-content-grid',
        x : 0,
        y : 0,
        width : Volt.width,//1920,
        height : Volt.height * 0.8,//864, //1080 * 0.8
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        custom : {
            'focusable' : true
        },
        color : {
            r : 0,
            g : 111,
            b : 0,
            a : 0
        }
    },
    
    error : {
        type : 'widget',
        id : 'main-content-error',
        x:0,
        y:0,
        width : Volt.width,//1920,
        height : Volt.height * 0.8,//864, //1080 * 0.8
        children : [{
                type : 'text',
                id:'main-content-error-text',
                x : 1920/2,
                y : 329,//52, //1080 * (0.066667 - 0.018519) 
                //width : 1920 - 180,//1885,//1920 - 1920 * 0.018229
                //height : 48*2,//20,//1080 * 0.018519
                textColor : Volt.hexToRgb('#000000', 60),
                horizontalAlignment : "center",
                font : 'Samsung SVD_Light 36px',
                text :Volt.i18n.t('TV_SID_MIX_NOT_CONNECTED_INTERNET_FEATURE', {A : CommonDefines.ErrorCode.NETWORK_ERROR_CODE}),
            },
            {
                type : 'WinsetButton',
                id:'main-content-error-button',
                x : (Volt.width - Volt.width*0.140104)/2,
                y : 329 + 45 + 48,//52, //1080 * (0.066667 - 0.018519) 
                style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text,
                buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
                text: Volt.i18n.t('UID_ONTV_TROUBLESHOT'),
                bHasBorder: true,
                width : Volt.width*0.140104,
                height : Volt.height*0.060185,
                color:Volt.hexToRgb('#ffffff',0),
                custom : {
                    focusable : false,
                }
            },
        ]
    },
   /* optionMenuForChina : {
        type : 'OptionMenu',
        x : Volt.width - Volt.width*435/1920,//1485,// 1920 - 435
        y : Volt.height * 0.133333,//144, // 1080 * 0.133333
        width : Volt.width*435/1920,
        renderNum : 1,
        loop : false,
        text : [Volt.i18n.t('TV_SID_WEATHER_SETTINGS')],
        custom : {
            'focusable' : true
        }
    },*/


	optionMenuForChina : {
	        type : 'widget',
	        x : Volt.width - Volt.width*435/1920,//1485,// 1920 - 435
	        y : Volt.height * 0.133333,//144, // 1080 * 0.133333
	        width : Volt.width*435/1920,
	        height : Volt.height *120/1080,//144,//1080 * 0.133333
	        //color:{r:0,g:0,b:0,a:0},
	        color : Volt.hexToRgb('#0f1826'),
            border:{width:0.2,color:{r:0xff,g:0xff,b:0xff,a:5}},
            opacity:250,
           	children : [
	        {
		        type : 'Button',
		        x : Volt.width*30/1920,//1485,// 1920 - 435
		        y : 0,//144, // 1080 * 0.133333
		        width : Volt.width*435/1920,
		        height : Volt.height *120/1080,//144,//1080 * 0.133333
		        color : Volt.hexToRgb('#0f1826'),
				/*text: {
	    			x:0,
	    			y:0,
	    			width: Volt.width*435/1920,
		            height: 120 ,
		            text: Volt.i18n.t('TV_SID_WEATHER_SETTINGS'),
		            font:"Samsung SVD_Medium 36px",
				    color: { r:255, g:255, b:255, a:255 * 0.8 },
		            hAlign: "left", //horizontal alignment, "center" in default
		            //vAlign: "cneter"  //vertical alignment, "middle" in default
				}, */

		    },
		    {
				type : 'widget',
    			x:Volt.width*23/1920,
    			y:Volt.height*23/1080,
    			width:Volt.width*(435 - 40)/1920,
    			height:Volt.height *70/1080,
    			color : Volt.hexToRgb('#0f1826'),
    			border:{width:2,color:{r:0xff,g:0xff,b:0xff,a:255}},
    			horizontalAlignment : "left",
    			verticalAlignment : "center",
	        },
	       {
				type : 'text',
    			x:Volt.width*30/1920,
    			y:0,
    			width: Volt.width*(435-4)/1920,
    			height: Volt.height *(120 - 4)/1080,
    			textColor:{r:255, g:255, b:255, a:255 * 0.8},
    			text: Volt.i18n.t('TV_SID_WEATHER_SETTINGS'),
    			font:"Samsung SVD_Medium 36px",
    			horizontalAlignment : "left",
    			verticalAlignment : "center",
	        }]

    },

    containerMap : {
        news_thumbnail1 : {
            width : Volt.sourceControlWidth * 0.337500 ,//648, // 1920 * 0.337500 
            height : Volt.height * 0.500000,//540, // 1080 * 0.500000
            imageHeight : Volt.sourceControlWidth*412/1920,
            infoHeight : Volt.height*128/1080,
            title : {
                x : 23,//20, // 1920 * 0.010417
                y : 16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : 602,//608,// 1920 * (0.337500 - 2 * 0.010417)
                height : 64,//64, // 1920 * 0.016667 * 2
                font : 'Samsung SVD_Light 26px'
            },
            time : {
                x : 23,//20,// 1920 * 0.010417
                y : 82,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 602,//608,// 1920 * (0.337500 - 2 * 0.010417)
                height : 35,//30, // 1920 * 0.015625
                font : 'Samsung SVD_Medium 20px'
            },
            cp_icon : {
                x : 584,//589, // 1920 * (0.337500 - 0.010417) - 39
                y : 82,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 39,
                height : Volt.height*30/1080,
                opacity : 102
            // 255 * 0.4
            }
        },
        news_thumbnail2 : {
            width : Volt.sourceControlWidth * 0.168750,//324, //1920 * 0.168750
            height : Volt.height * 0.300000,//324, // 1080 * 0.300000
            imageHeight : Volt.sourceControlWidth*196/1920,
            infoHeight : Volt.height*128/1080,
            title : {
                x : 20,//20, // 1920 * 0.010417
                y : 16,//16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : 284,//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 64,//64, // 1920 * 0.016667 * 2
                font : 'Samsung SVD_Light 26px'
            },
            time : {
                x : 20,//20,// 1920 * 0.010417
                y : 82,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 284,//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 35,//30, // 1920 * 0.015625
                font : 'Samsung SVD_Medium 20px'
            },
            cp_icon : {
                x : 265,//265, // 1920 * (0.168750 - 0.010417) - 39
                y : 82,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 39,
                height : Volt.height*30/1080,
                opacity : 102
            // 255 * 0.4
            }
        },
        news_thumbnail3 : {
            width : Volt.sourceControlWidth * 0.168750,//324, // 1920 * 0.168750
            height : Volt.height * 0.400000,//432, // 1080 * 0.400000
            imageHeight : Volt.sourceControlWidth*304/1920,
            infoHeight : Volt.height*128/1080,
            title : {
                x : Volt.width * 0.010417,//20, // 1920 * 0.010417
                y : 16,//16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : 284,//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 64,//64, // 1920 * 0.016667 * 2
                font : 'Samsung SVD_Light 26px'
            },
            time : {
                x : Volt.width * 0.010417,//20,// 1920 * 0.010417
                y : 82,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 284,//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 35,//30, // 1920 * 0.015625
                font : 'Samsung SVD_Medium 20px'
            },
            cp_icon : {
                x : Volt.width * (0.168750 - 0.010417) - 39,//265, // 1920 * (0.168750 - 0.010417) - 39
                y : 82,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : 39,
                height : Volt.height*30/1080,
                opacity : 102
            // 255 * 0.4
            }
        },
        weather_thumbnail : {
            width : Volt.sourceControlWidth * 0.337500 ,//648, // 1920 * 0.337500 
            height : Volt.height * 0.500000,//540, // 1080 * 0.500000
            imageHeight : Volt.sourceControlWidth*412/1920,
            infoHeight : Volt.height*128/1080,
            weather_icon : {
                x : Volt.sourceControlWidth * 0.010417,//20, //1920 * 0.010417
                y : Volt.height * 0.021296,//23, //1080 * 0.021296
                width : Volt.sourceControlWidth*83/1920,
                height : Volt.height*83/1080
            },
            icon_h : {
                x : Volt.sourceControlWidth * 0.337500 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*110/1920 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*50/1920 - Volt.sourceControlWidth * 0.003125 - Volt.sourceControlWidth*19/1920,//423,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50 - 1920 * 0.003125 - 19
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : Volt.sourceControlWidth*19/1920,
                height : Volt.height*41/1080
            },
            icon_l : {
                x : Volt.sourceControlWidth * 0.337500 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*110/1920 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*50/1920 - Volt.sourceControlWidth * 0.003125 - Volt.sourceControlWidth*19/1920,//423,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50 - 1920 * 0.003125 - 19
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2 + Volt.height * 0.037963 + Volt.height * 0.001852,//65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : Volt.sourceControlWidth*19/1920,
                height : Volt.height*41/1080
            },
            location : {
                x : Volt.sourceControlWidth * 0.010417 + Volt.sourceControlWidth*83/1920 + Volt.sourceControlWidth * 0.00625,//115,//1920 * 0.010417 + 83 + 1920 * 0.00625
                y :  (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                //width : Volt.sourceControlWidth * 0.156250,//300, //1920 * 0.156250
                width :Volt.sourceControlWidth * 0.1500,
                height : Volt.height * 0.037963,//41,//1080 * 0.037963
                opacity : 153, // 255 * 0.6
                font : "Samsung SVD_Light 26px"
            },
            conditions : {
                x : Volt.sourceControlWidth * 0.010417 + Volt.sourceControlWidth*83/1920 + Volt.sourceControlWidth * 0.00625,//115,//1920 * 0.010417 + 83 + 1920 * 0.00625
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2 + Volt.height * 0.037963 + Volt.height * 0.001852,//65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                //width : Volt.sourceControlWidth * 0.156250,//300, //1920 * 0.156250
                width : Volt.sourceControlWidth * 0.1500,//300, //1920 * 0.156250                
                height : Volt.height * 0.037963,//41,//1080 * 0.037963
                opacity : 153, // 255 * 0.6
                font : "Samsung SVD_Light 40px"
            },
            highTemperature : {
                x : Volt.sourceControlWidth * 0.337500 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*110/1920 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*50/1920,//448,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : Volt.sourceControlWidth*50/1920, //special value
                height : Volt.height*0.037963,//41,//1080*0.037963
                opacity : 153, // 255 * 0.6
                font : "Samsung SVD_Light 30px"
            },
            lowTemperature : {
                x : Volt.sourceControlWidth* 0.337500 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*110/1920 - Volt.sourceControlWidth * 0.010417 - Volt.sourceControlWidth*50/1920,//448,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50
                y : (Volt.height*128/1080 - Volt.height*0.037963 - Volt.height* 0.001852 - Volt.height* 0.037963)/2 + Volt.height* 0.037963 + Volt.height* 0.001852,//65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : Volt.sourceControlWidth*50/1920, //special value
                height : Volt.height*0.037963,//41,//1080*0.037963
                opacity : 153, // 255 * 0.6
                font : "Samsung SVD_Light 30px"
            },
            temperature : {
                x : Volt.sourceControlWidth * 0.337500 - Volt.sourceControlWidth * 0.01250 - Volt.sourceControlWidth*110/1920,//518, // 1920 * 0.337500 - 1920 * 0.010417 - 110
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : Volt.width*110/1920, //special value
                height : Volt.height * 0.077778,//84,// 1080 * 0.077778
                opacity : 153, // 255 * 0.6
                font : "Samsung SVD_Light 70px"
            },
            photoAttribute : {
                x : 0,//338,// 1920 * 0.337500 - 1920 * 0.005208 - 300
                y : Volt.is720p?98:100,//108, //128 - 1080 * 0.018519
                //width : Volt.width *300/1920,//special value
                width :Volt.sourceControlWidth * (0.337500-0.0125),
                height : Volt.height * 26 / 1080,//20,//1080 * 0.018519
                font : "Samsung SVD_Medium 13px"
            },
            cp_icon : {
                x : Volt.sourceControlWidth * 0.337500 - Volt.sourceControlWidth*42/1920,//606, // 1920 * 0.337500 - 42
                y : Volt.height*370/1080, // 412 - 42
                width : Volt.sourceControlWidth*42/1920,
                height : Volt.height*42/1080
            }
        }
    },

    constNum : {
        iconBgBlurWidth : 1,
        iconBgFocusWidth : 101,
        showCloseToolX:  Volt.width  - 2 * Volt.sourceControlWidth* 0.052604 - 4 * Volt.sourceControlWidth/1920,//1720, // 1920 * (1 - 2 * 0.052083)
        hideCloseToolX : Volt.width  - Volt.sourceControlWidth * 0.052604 - 0 * Volt.sourceControlWidth/1920,//1820, //1920 * (1 - 1 * 0.052083)
        showCloseOptionMenuX : Volt.width - Volt.sourceControlWidth * 0.052604 - 435,//1384, // 1920 - 1920 * 0.052604 - 435
        hideCloseOptionMenuX : Volt.width - 435,// 1920 - 435
    //1920 * 0.052604
    },
};

exports = NewsonMainTemplate;
