var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
var DetailTemplate = {
    container : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.width * 0.83125,//1596, // 1920 * 0.83125
        height : Volt.height * 0.343519,//371, // 1080 * 0.343519
        color : Volt.hexToRgb('#000000', 0),
        children : [{
            type : 'image',
            x : 0,
            y : 0,
            width : Volt.width * 0.343229,//659,//1920 * 0.343229
            height : Volt.height * 0.343519,//371,// 1080 * 0.343519
            src : ResourceMgr.IconBlankThumbnail,
            fillMode : 'center',
            color : Volt.hexToRgb('#d4d4d4', 100),
            children : [{
				id : 'thumb_linewidth',
                type : 'widget',
                x : Volt.width * 0.343229 -1,//658, //1920 * 0.343229 -1
                y : 0,
                width : 1,
                height : Volt.height * 0.343519,//371,// 1080 * 0.343519
                color : Volt.hexToRgb('#c9c9c9', 100)
            }, {
				id : 'thumb_lineheight',
                type : 'widget',
                x : 0,
                y : Volt.height * 0.343519 - 1,//370, // 1080 * 0.343519 - 1
                width : Volt.width * 0.343229,//659, //1920 * 0.343229
                height : 1,
                color : Volt.hexToRgb('#c9c9c9', 100)
            },{
				id : 'thumb_thumbnail',
			    type: 'Thumbnail',
				visibleStyles: (0x01 | 0x20),
                width: Volt.width * 0.343229,//659,
				height: Volt.height * 0.343519,
				x : 0,
				y : 0,
				image:{//src: '{{ source_icon }}',
				width: Volt.width * 0.343229,//659,
				height: Volt.height * 0.343519,
                fillMode:"top-crop",
                }//371}
			}
			
			/*{
                id : 'thumb_thumbnail',
                type : 'ImageWidgetEx',
                cropMode : "cropCenter",
                async : true,
                x : 0,
                y : 0,
                width : 659,//1920 * 0.343229
                height : 371,// 1080 * 0.343519
                src : '{{source_icon}}'
            }*/]
        },

        {
            type : 'widget',
            x : Volt.width * 0.343229,//659,//1920 * 0.343229
            y : 0,
            width : Volt.width * (0.83125 - 0.343229),//937, //1920 * (0.83125 - 0.343229)
            height : Volt.height * 0.343519,//371, // 1080 * 0.343519
            color : Volt.hexToRgb('#111111', 0),
            id : 'thumb_title_info',
            children : [{
                type : 'text',
                x : Volt.width * 0.015625,//30, // 1920 * 0.015625
                y : Volt.height * 0.037037,//40, // 1080 * 0.037037
                width : Volt.width * (0.83125 - 0.343229 - 0.015625 - 0.015625),//877, //1920 * (0.83125 - 0.343229 - 0.015625 - 0.015625)
                height : Volt.height * 0.062963 * 3,//204,// 1080 * 0.062963 * 3
                color : Volt.hexToRgb('#000000', 0),
                id : 'thumb_headline',
                ellipsize : true,
                text : '{{ headline }}',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
                font : 'Samsung SVD_Light 56px'
            }, {
                id : 'thumb_source_icon',
                type : 'image',
                async : true,
                x : Volt.width * 0.015625,//30, // 1920 * 0.015625
                y : Volt.height * (0.343519 - 0.026852 - 0.009259 - 0.027778 - 0.018519),//282, // 1080 * (0.343519 - 0.026852 - 0.009259 - 0.027778 - 0.018519)
                //width : Volt.height * 0.026852*3,//29 * 3,
                //height : Volt.height * 0.026852,//29, // 1080 * 0.026852
                //fillMode:"fit",
                src : '{{source_icon}}'
            }, {
                id : 'thumb_source_container',
                type : 'widget',
                x : Volt.width * 0.015625,//30, // 1920 * 0.015625
                y : Volt.height * (0.343519 - 0.027778 - 0.018519),//321,// 1080 * (0.343519 - 0.027778 - 0.018519)
                width : Volt.width * (0.83125 - 0.343229 - 0.015625 - 0.015625),//877, //1920 * (0.83125 - 0.343229 - 0.015625 - 0.015625)
                height : Volt.height * 0.027778,//30, // 1080 * 0.027778
                color : Volt.hexToRgb('#000000', 0),
                children : [{
                    id : 'thumb_source',
                    type : 'text',
                    x : 0,
                    y : 0,
                    height : Volt.height*30/1080,
                    font : 'Samsung SVD_Light 26px',
                    verticalAlignment : 'center',
                    horizontalAlignment : 'left',
                    singleLineMode : true,
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    text : '{{source}}'
                },

                {
                    id : 'thumb_press_time',
                    type : 'text',
                    font : 'Samsung SVD_Light 26px',
                    verticalAlignment : 'center',
                    horizontalAlignment : 'left',
                    x : 0,
                    y : 0,
                    height : Volt.height*30/1080,
                    singleLineMode : true,
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    src : '{{press_time}}'
                },

                {
                    id : 'thumb_timestamp',
                    type : 'text',
                    font : 'Samsung SVD_Light 26px',
                    verticalAlignment : 'center',
                    horizontalAlignment : 'left',
                    x : 0,
                    y : 0,
                    height : Volt.height*30/1080,
                    singleLineMode : true,
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    src : '{{timestamp}}'
                },

                {
                    id : 'thumb_color_drawing01',
                    type : 'widget',
                    x : 0,
                    //y : Volt.is720p?Volt.height * 0.0080:Volt.height * 0.002778,//3,//1080 * 0.002778
                    y :Volt.height * 0.002778,
                    height : Volt.height * 0.022222,//24,//1080 * 0.022222
                    width : Volt.width * 0.001563,//3,//1920 * 0.001563
                    color : Volt.hexToRgb('#FFFFFF', 60)
                },

                {
                    id : 'thumb_color_drawing02',
                    type : 'widget',
                    x : 0,
                    //y : Volt.is720p?Volt.height * 0.0080:Volt.height * 0.002778,//3,//1080 * 0.002778
                    y :Volt.height * 0.002778,
                    height : Volt.height * 0.022222,//24,//1080 * 0.022222
                    width : Volt.width * 0.001563,//3,//1920 * 0.001563
                    color : Volt.hexToRgb('#FFFFFF', 60)
                }]
            }]
        }]
    }
};

exports = DetailTemplate;
