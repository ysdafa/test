var ScreenTemplate = {
    width : Volt.width,
    height : Volt.height,
    defaultColor : Volt.hexToRgb('#0f1826'),
    transparentColor : Volt.hexToRgb('#ffffff', 0)
};

exports = ScreenTemplate;