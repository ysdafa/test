var DetailTextTemplate = {
    container : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.width * 0.83125,//1596, // 1920 * 0.83125
        height : Volt.height * 0.343519,//371, // 1080 * 0.343519
        color : Volt.hexToRgb('#000000', 0),
        children : [{
            type : 'text',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            y : Volt.height * 0.037037,//40, // 1080 * 0.037037
            width : Volt.width  * 0.83125 - 2 * Volt.width * 0.044792,//1424, // 1920 * 0.83125 - 2 * 1920 * 0.044792
            height : Volt.height * 0.062963 * 3,//204, // 1080 * 0.062963 * 3
            color : Volt.hexToRgb('#000000', 0),
            id : 'text_headline',
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            ellipsize : true,
            text : '{{ headline }}',
            font : 'Samsung SVD_Light 56px'
        }, {
            id : 'text_source_icon',
            type : 'image',
            async : true,
            x : Volt.width * 0.044792,//86,// 1920 * 0.044792
            y : Volt.height * (0.343519 - 0.026852 - 0.009259 - 0.027778 - 0.018519),//282, // 1080 * (0.343519 - 0.026852 - 0.009259 - 0.027778 - 0.018519)
//                width : 29 * 3,
//                height : 29, // 1080 * 0.026852
            src : '{{source_icon}}'
        }, {
            id : 'text_source_container',
            type : 'widget',
            x : Volt.width * 0.044792,//86,// 1920 * 0.044792
            y : Volt.height * (0.343519 - 0.027778 - 0.018519),//321, // 1080 * (0.343519 - 0.027778 - 0.018519)
            width : Volt.width * 0.83125 - 2 * Volt.width * 0.044792,//1424, // 1920 * 0.83125 - 2 * 1920 * 0.044792
            height : Volt.height * 0.027778,//30,//1080 * 0.027778
            color : Volt.hexToRgb('#000000', 0),
            children : [{
                id : 'text_source',
                type : 'text',
                x : 0,
                y : 0,
                height : Volt.height*30/1080,
                font : 'Samsung SVD_Light 26px',
                singleLineMode : true,
                textColor : Volt.hexToRgb('#FFFFFF', 60),
                verticalAlignment : 'center',
                horizontalAlignment : 'left',
                text : '{{source}}'
            }, {
                id : 'text_press_time',
                type : 'text',
                font : 'Samsung SVD_Light 26px',
                singleLineMode : true,
                verticalAlignment : 'center',
                horizontalAlignment : 'left',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
                x : 0,
                y : 0,
                height : Volt.height*30/1080,
                src : '{{press_time}}'
            },

            {
                id : 'text_timestamp',
                type : 'text',
                singleLineMode : true,
                font : 'Samsung SVD_Light 26px',
                verticalAlignment : 'center',
                horizontalAlignment : 'left',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
                x : 0,
                y : 0,
                height : Volt.height*30/1080,
                src : '{{timestamp}}'
            },

            {
                id : 'text_color_drawing01',
                type : 'widget',
                x : 0,
                y : Volt.height * 0.002778,//3,//1080 * 0.002778
                height : Volt.height * 0.022222,//24,//1080 * 0.022222
                width : Volt.width * 0.001563,//3,//1920 * 0.001563
                color : Volt.hexToRgb('#FFFFFF', 60)
            },

            {
                id : 'text_color_drawing02',
                type : 'widget',
                x : 0,
                y : Volt.height * 0.002778,//3,//1080 * 0.002778
                height : Volt.height * 0.022222,//24,//1080 * 0.022222
                width : Volt.width * 0.001563,//3,//1920 * 0.001563
                color : Volt.hexToRgb('#FFFFFF', 60)
            }]
        }]
    }
};

exports = DetailTextTemplate;
