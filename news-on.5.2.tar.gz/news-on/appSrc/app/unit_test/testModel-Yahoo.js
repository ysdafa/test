
var CPAPI = Volt.require('app/common/CPAPI.js');
var DeviceModel = Volt.require('app/common/deviceModel.js');

//set country BR, using yahoo
DeviceModel.set("countryCode", 'BR');

//cp api init
jasmine.describe('cpapi init (Yahoo)', function()
{
    var flag;

    jasmine.beforeEach(function()
    {
        flag = false;
    });
    
	jasmine.it('cpapi init, should succeed', function()
    {
		jasmine.runs(function(){
            CPAPI.initialize().then(function(result){
				jasmine.expect(result).toBe(true);
				flag = true;
			});
		});
		
		jasmine.waitsFor(function() {
      		return flag; 
    	}, 'not responsed in 10000ms', 10000);
	});
});

//test MainNewsModel
var MainNewsModel = require('file://app/models/mainNewsModel.js');

jasmine.describe('main news model (Yahoo)', function()
{
    var flag;

    jasmine.beforeEach(function()
    {
        flag = false;
    });
    
	jasmine.it('get main news, should succeed', function()
    {
		jasmine.runs(function(){
            MainNewsModel.setInitData(CPAPI.getMainNewsAPI());
			MainNewsModel.fetch().then(function(response){
			    //Volt.log('hemctest main news responsed');
				jasmine.expect(response).toBe(true);
				flag = true;
			});
		});
		
		jasmine.waitsFor(function() {
      		return flag; 
    	}, 'not responsed in 10000ms', 10000);
	});
});


//test MoreNewsModel
var MoreNewsModel = Volt.require('app/models/moreNewsModel.js');

jasmine.describe('more news model (Yahoo)', function()
{
    var flag;

    jasmine.beforeEach(function()
    {
        flag = false;
    });
    
	jasmine.it('get more news, should succeed', function()
    {
		jasmine.runs(function(){
            var url = MainNewsModel.get('more_news_url');
            var options = {'pageIdx':0,'more_news_url':url};
            MoreNewsModel.setInitData(options);
			MoreNewsModel.fetch().then(function(response){
			    //Volt.log('hemctest main news responsed');
				jasmine.expect(response).toBe(true);
				flag = true;
			});
		});
		
		jasmine.waitsFor(function() {
      		return flag; 
    	}, 'not responsed in 10000ms', 10000);
	});
});

//test NewsDetailModel
var DetailNewsModel = require('file://app/models/newsDetailModel.js');

jasmine.describe('detail news model (Yahoo)', function()
{
    //Volt.log('[hemctest]detail news test start');
    var flag;

    jasmine.beforeEach(function()
    {
        flag = false;
    });

	jasmine.it('get detail news, should succeed', function()
    {
        //Volt.log('[hemctest]success detail news it start');
            
        jasmine.runs(function(){
            
            DetailNewsModel.setInitData({'url':'https://api.digitalhomeservices.yahoo.com/V0_3/GetNewsDetails?id=098f1192-66ad-3cf1-b5f4-6663ecad7db5'});
            DetailNewsModel.fetch().then(function(response){
                jasmine.expect(response).toBe(true);
                flag = true;
            });
        });
        
        jasmine.waitsFor(function() {
            return flag; 
        }, 'not responsed in 10000ms', 10000);
    });
});

//test WeatherDetailModel
var WeatherDetailModel = require('file://app/models/weatherDetailModel.js');

jasmine.describe('weather detail model (Yahoo)', function()
{
    //Volt.log('[hemctest]detail news test start');
    var flag;

    jasmine.beforeEach(function()
    {
        flag = false;
    });

	jasmine.it('get weather detail, should succeed', function()
    {
        //Volt.log('[hemctest]success detail news it start');
            
        jasmine.runs(function(){
            WeatherDetailModel.setInitData();
            WeatherDetailModel.fetch().then(function(response){
                jasmine.expect(response).toBe(true);
                flag = true;
            });
        });
        
        jasmine.waitsFor(function() {
            return flag; 
        }, 'not responsed in 10000ms', 10000);
    });
});


