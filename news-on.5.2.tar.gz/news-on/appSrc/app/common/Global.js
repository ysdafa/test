var APP_ACTIVE = 'ON_ACTIVATE';
var APP_DEACTIVATE = 'ON_DEACTIVATE';
var APP_UNKNOWN = 'ON_UNKNOWN';
var MEMORY_TEST_ON = 1;
var MEMORY_TEST_OFF = 0;
var voltapi = Volt.require('voltapi.js');
var DeviceModel = Volt.require('app/common/deviceModel.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');

var getOccurStamp = function(now_utc_timestamp, last_utc_timestamp)
{
    if(now_utc_timestamp === undefined || last_utc_timestamp === undefined) {
        return '';
    }
    var temp = ((parseInt(now_utc_timestamp) - parseInt(last_utc_timestamp)));
	var status = null;
	if(temp >= 0 && temp <= 59)
	{
        status = Volt.i18n.t('COM_SID_JUST_NOW');
	}else if(temp >= 60 && temp <= 119)
	{
        status = Volt.i18n.t('TV_SID_1_MINUTES_AGO');
	}else if(temp >= 120 && temp <= 3600 - 1)
	{
        status = Volt.i18n.t('SID_MIX_MINUTES_AGO_KR_BLANK', {A : Math.floor(temp/60)});
	}else if(temp >= 3600 && temp <= 7200 - 1)
	{
        status = Volt.i18n.t('TV_SID_1_HOUR_AGO');
	}else if(temp >= 3600 && temp <= 3600*24 - 1)
	{
        status = Volt.i18n.t('SID_MIX_HOURS_AGO', {A : Math.floor(temp/3600)});
	}else if(temp >= 3600*24 && temp <= 3600*48 - 1)
	{
        status = Volt.i18n.t('TV_SID_1_DAY_AGO');
	}
    else
	{
        status = Volt.i18n.t('TV_SID_MIX_DAYS_AGO', {A : Math.floor(temp/(3600*24))});
	}
    return status;
};

var getOccurStamp_Short = function(now_utc_timestamp, last_utc_timestamp)
{
    if(now_utc_timestamp === undefined || last_utc_timestamp === undefined) {
        return '';
    }
    var temp = ((parseInt(now_utc_timestamp) - parseInt(last_utc_timestamp)));
	var status = null;
	if(temp >= 0 && temp <= 59)
	{
        status = Volt.i18n.t('COM_SID_JUST_NOW');
	}else if(temp >= 60 && temp <= 119)
	{
        status = Volt.i18n.t('TV_SID_1_MIN_AGO');
	}else if(temp >= 120 && temp <= 3600 - 1)
	{
        status = Volt.i18n.t('COM_SID_MIX_MINS_AGO', {A : Math.floor(temp/60)});
	}else if(temp >= 3600 && temp <= 7200 - 1)
	{
        status = Volt.i18n.t('COM_SID_1_HR_AGO');
	}else if(temp >= 3600 && temp <= 3600*24 - 1)
	{
        status = Volt.i18n.t('COM_SID_MIX_HRS_AGO', {A : Math.floor(temp/3600)});
	}else if(temp >= 3600*24 && temp <= 3600*48 - 1)
	{
        status = Volt.i18n.t('COM_SID_1D_AGO');
	}
    else
	{
        status = Volt.i18n.t('COM_SID_MIX_D_AGO', {A : Math.floor(temp/(3600*24))});
	}
    return status;
};

var voiceGuide = function(voiceText, queuePlay){
    if (true == Volt.isDeactive)return;
    Volt.log('voice guide text : '+voiceText);
    if (queuePlay && true == queuePlay){
        TTS.queuingPlay(voiceText);
    }else{
        TTS.setText(voiceText);
        TTS.play();
    }
    //TTS.play(voiceText);
};
var string2Json = function(s) {     
    var newstr = "";  
    for (var i=0; i<s.length; i++) {  
        c = s.charAt(i);       
        switch (c) {       
            case '\"':       
                newstr+="\\\"";       
                break;       
            case '\\':       
                newstr+="\\\\";       
                break;       
            case '/':       
                newstr+="\\/";       
                break;       
            case '\b':       
                newstr+="\\b";       
                break;       
            case '\f':       
                newstr+="\\f";       
                break;       
            case '\n':       
                newstr+="\\n";       
                break;       
            case '\r':       
                newstr+="\\r";       
                break;       
            case '\t':       
                newstr+="\\t";       
                break;       
            default:       
                newstr+=c;       
        }  
   }  
   return newstr;       
};

var MagicKey = function() {
    var timerInstance = null;
    var listeners = [];
    var buffers = '';

    function onKeyPress(keycode) {
        if (timerInstance)
            Volt.clearTimeout(timerInstance);
        switch(keycode) {
            case Volt.KEY_0: buffers += '0'; break;
            case Volt.KEY_1: buffers += '1'; break;
            case Volt.KEY_2: buffers += '2'; break;
            case Volt.KEY_3: buffers += '3'; break;
            case Volt.KEY_4: buffers += '4'; break;
            case Volt.KEY_5: buffers += '5'; break;
            case Volt.KEY_6: buffers += '6'; break;
            case Volt.KEY_7: buffers += '7'; break;
            case Volt.KEY_8: buffers += '8'; break;
            case Volt.KEY_9: buffers += '9'; break;
        }
        if (executeListener()) {
            clearBuffer();
        }
        timerInstance = Volt.setTimeout(clearBuffer, 3000);
    }

    function executeListener() {
        var execute = false;
        for (var idx=0; idx<listeners.length; idx++) {
            if (listeners[idx].key == buffers) {
                if ('development' != DeviceModel.getServerType() && buffers != CommonDefines.Magic.SHOW_CONFIG_VERSION){
                    return true;
                }
                listeners[idx].listener();
                execute = true;
            }
        }
        return execute;
    }

    function clearBuffer() {
        Volt.log('clear buffer : '+buffers);
        buffers = '';
    }

    function addListener(keyword, callback) {
        listeners.push({
            key: keyword,
            listener: callback
        });
    }

    function removeListener() {
        listeners = [];
    }

    return {
        'onKeyPress': onKeyPress,
        'addListener': addListener,
        'removeListener': removeListener
    }
};

//KPI LOG START
var ExitWay = 'EXIT';  //default is EXIT key
var ExitWayForKPILog = function(){

    function get(){
        return ExitWay;
    }
    function set(value){
        ExitWay = value;
    }

    return {
        'get' : get,
        'set' : set
    }
}
var LeaveWay = '';
var LeaveWayForKPILog = function(){

    function get(){
        return LeaveWay;
    }
    function set(value){
        LeaveWay = value;
    }

    return {
        'get' : get,
        'set' : set
    }
}

var LeaveByReturnForKPILog = false;
var LeaveByReturnForKPILog = function(){

    function get(){
        return LeaveByReturnForKPILog;
    }
    function set(value){
        LeaveByReturnForKPILog = value;
    }

    return {
        'get' : get,
        'set' : set
    }
}
//KPI LOG END
var WeekDayText = [];
var MonthText = [];
var DateMultiLang = function(){
    function init(){
        WeekDayText = [Volt.i18n.t('COM_SID_SUN'), Volt.i18n.t('COM_SID_MON'), Volt.i18n.t('COM_SID_TUE'), 
            Volt.i18n.t('COM_SID_WED'), Volt.i18n.t('COM_SID_THU'), Volt.i18n.t('COM_SID_FRI'), Volt.i18n.t('COM_SID_SAT')];
        MonthText = [Volt.i18n.t('COM_SID_JAN'), Volt.i18n.t('COM_SID_FEB'), Volt.i18n.t('COM_SID_MAR'), 
            Volt.i18n.t('COM_SID_APR'), Volt.i18n.t('COM_SID_MAY'), Volt.i18n.t('COM_SID_JUN'), 
            Volt.i18n.t('COM_SID_JUL'), Volt.i18n.t('COM_SID_AUG'), Volt.i18n.t('COM_SID_SEP'), 
            Volt.i18n.t('COM_SID_OCT'), Volt.i18n.t('COM_SID_NOV'), Volt.i18n.t('COM_SID_DEC')];
    }

    function getWeekDay(){
        return WeekDayText;
    }

    function getMonth(){
        return MonthText;
    }

    return {
        'init' : init,
        'getWeekDay' : getWeekDay,
        'getMonth' : getMonth
    }
}

var formatTime = function(javaTimestamp) {
    var dt = new Date(javaTimestamp * 1000);
    var format = function(d)
    {    
        var fmt = '';
        fmt += WeekDayText[d.getDay()]+', ';
        fmt += MonthText[d.getMonth()]+' ';
        fmt += d.getDate() + ', ';
        fmt += d.getFullYear();
        return fmt; 
    }
    return format(dt);
}

var Request = [];
var RequestMgr = {
	add : function add(request){
        Volt.log('[RequestMgr]add request, id is '+request.request_id);
    	Request.push(request);
    },
    cancel : function cancel(){
	    var _ = Volt.require("modules/underscore.js")._;
    	_.each(Request, function(request){
            if (request.request_id){
                var ret = voltapi.rest.cancel(request.request_id);
                Volt.log('[RequestMgr]cancel request, id is '+request.request_id+', ret is '+ret);
                /*if (voltapi.rest.m_requestMap[request.request_id].intervalId){
                    Volt.clearInterval(voltapi.rest.m_requestMap[request.request_id].intervalId);
                }
                delete voltapi.rest.m_requestMap[request.request_id];*/
            }
    	})
    	Request = [];
    },
	clear : function clear(){
	    var _ = Volt.require("modules/underscore.js")._;
    	_.each(Request, function(request){
            if (request.timer_id){
                Volt.clearTimeout(request.timer_id);
            }
            if (request.request_id){
                var ret = voltapi.rest.cancel(request.request_id);
                Volt.log('[RequestMgr]cancel request, id is '+request.request_id+', ret is '+ret);
                /*if (voltapi.rest.m_requestMap[request.request_id].intervalId){
                    Volt.clearInterval(voltapi.rest.m_requestMap[request.request_id].intervalId);
                }
                delete voltapi.rest.m_requestMap[request.request_id];*/
            }
            Volt.log('[RequestMgr]before execute callback '+request.callback);
            if (request.callback){
                Volt.log('[RequestMgr]execute callback');
                request.callback();
            }
    	})
    	Request = [];
    },
    reset : function reset(){
        Request = [];
    }
}

exports = {
    APP_STATUS : APP_UNKNOWN,
    APP_ACTIVE : APP_ACTIVE,
    APP_DEACTIVATE : APP_DEACTIVATE,
    APP_UNKNOWN : APP_UNKNOWN,
    MEMORY_TEST_ON : MEMORY_TEST_ON,
    MEMORY_TEST_OFF : MEMORY_TEST_OFF,
    MEMORY_TEST_STATUS : MEMORY_TEST_OFF,
    string2Json : string2Json,
    getOccurStamp : getOccurStamp,
    getOccurStamp_Short : getOccurStamp_Short,
    voiceGuide : voiceGuide,
    MagicKey : new MagicKey(),
    //KPI LOG START
    ExitWayForKPILog : ExitWayForKPILog(),
    LeaveWayForKPILog : LeaveWayForKPILog(),
    LeaveByReturnForKPILog : LeaveByReturnForKPILog(),
    //KPI LOG END
    DateMultiLang : DateMultiLang(),
    formatTime : formatTime,
    RequestMgr : RequestMgr,
    NETWORK_CONFIG_LAUNCH : false,
};
