var showLog = false;

function assert(condition, strErrorInfo) {
    strErrorInfo = strErrorInfo || '';
    if (!(condition)) {
        throw new Error(strErrorInfo);
    }
}

function defaultValue(value, defaultValue) {
    if (value === undefined) {
        return defaultValue;
    } else {
        return value;
    }
}

/*
 * @function This function will return a table widget
 * @example
 *  1. define a template for table widget
 *      provinceList : {
        type : 'TableWidget',
        x : 0,
        y : 0,
        rows : 1,
        cols : 5,
        width : 500,
        height : 100,
        itemWidth : 100,
        itemHeight : 100,
        looping : true,
        nAniTimePageMove : 0,
        pageMoveMode : 'colbycol',
        custom : {
            'focusable' : true
        }
    },
    2. init table widget 
        this.template = provinceList;
        this.setWidget(PanelCommon.loadTemplate(this.template, null, container));
        __initProvinceList(this.widget);
    3. implements below function
        ①use setItems to set the data of items
        function __initProvinceList(provinceList) {
            provinceList.setItemsByModel = function(provinces) {
                var arrItems = [];
                _.each(provinces , function(provinceName, i){
                    arrItems[i] = {
                        provinceName : provinceName
                    };
                });
            }
            this.setItems(arrItems);
        };
        ②rewrite ifItemLoad,onMouseClickItem
        function __initProvinceList(provinceList) {
            provinceList.ifItemLoad = function(item, data) {
                if (!item.custom) {
                    item.custom = new XXX();
                    this.configMouseEvent(item);
                }
                ……
            };
            provinceList.onMouseClickItem = function(item) {
                var index = this.getRealIndex(item);
                ……
                item.custom.onFocus();
                ……
            };
        };
        
 */
function TableWidget(param) {
    var table = new Widget({
        color : Volt.hexToRgb('#ffffff', 0),
        cropOverflow : true
    });
    
  /*public*/
    table.DIR = { UP : 'UP', DOWN : 'DOWN', LEFT : 'LEFT', RIGHT : 'RIGHT'};
    table.onFocus = rgcIfItemFocus;
    table.onBlur = rgcIfItemUnFocus;
    table.setItems = rgcSetItems;
    table.release = rgcReleaseItems;
    table.onKeyEvent = table.handleKey = rgcHandleKey;
    table.configMouseEvent = rgcConfigMouseEvent;
    table.getItemByIndex = rgcGetItemByIndex;
    table.getRealIndex = rgcGetRealIndex;
    table.modifyItemsData = rgcModifyItemsData;
    table.onKeyLeft = rgcOnKeyLeft;
    table.onKeyRight = rgcOnKeyRight;
    table.onPageLeft = rgcPageLeft;
    table.onPageRight = rgcPageRight;
    table.ifItemLoad =  function(item, data){
        if(showLog) Volt.log('data - ' + JSON.stringify(data));
    };
    table.ifScroll = function(row) {
        if(showLog) Volt.log('row - ' + row);
    };
    table.ifMoveOut = function(dir){
        if(showLog) Volt.log('dir - ' + dir);
        return false;
    };
    table.onMouseClickItem = function(item){};
    table.flagCanMoveRight = function() {
        return this.m_page.index < this.m_page.count;
    };
    table.flagCanMoveLeft = function() {
        return this.m_page.index > 0;
    };
    table.getSize = function() {
        return this.m_size;
    };
    table.getCount = function(){
        return this.m_arrItems.length;
    };
    table.setFocusReset = function(bool){
        if("boolean" == typeof bool) {
            this.m_pageTurnReset = bool;
        }
    };
    /*private*/
    table._initList = rgcInit;
    table._updateItems = rgcUpdateItems;
    table._updateItemsByPage = rgcUpdateItemsByPage;
    table._drawItem = rgcDrawItem;
    table._onKeyUp = rgcOnKeyUp;
    table._onKeyDown = rgcOnKeyDown;
    table._onPressItem = rgcOnPressItem;
    table._getItemPos = rgcGetItemPos;
    table._getItemIndex = rgcGetItemIndex;
    table._getValidItem = rgcGetValidItem;
    table._ifItemFocus = rgcIfItemFocus;
    table._ifItemUnFocus = rgcIfItemUnFocus;
    table._initList(param);

    return table;
}

function rgcInit(param) {
    var parent = param['parent'];
    if (parent !== undefined) {
        this.parent = parent;
    }

    this.m_cols = param['cols'];
    this.m_rows = param['rows'];
    this.m_itemWidth = param['itemWidth'];
    this.m_itemHeight = param['itemHeight'];

    assert(this.m_cols !== undefined || this.m_rows !== undefined || this.m_itemWidth !== undefined || this.m_itemHeight !== undefined);

    this.orientation = defaultValue(param['orientation'], 'vertical');
    this.pageMoveMode = defaultValue(param['pageMoveMode'], 'pagebypage');

    this.m_itemX = defaultValue(param['x'], 0);
    this.m_itemY = defaultValue(param['y'], 0);
    this.m_looping = defaultValue(param['looping'], false);
    this.m_itemXSpace = defaultValue(param['itemXSpace'], 0);
    this.m_itemYSpace = defaultValue(param['itemYSpace'], 0);
//    this.m_aniTimePageMove = defaultValue(param['nAniTimePageMove'], 0);
    this.m_itemBorder = defaultValue(param['itemBorder'], 2);
    
    /*used for move focus smoothly*/
    this.m_moveNearby = true;
    /*used for reset focus to (0,0) when turn page*/
    this.m_pageTurnReset = false;

    /*initialize other parameter*/
    this.x = 0;
    this.y = 0;
    this.width = defaultValue(param['width'], 0);
    this.height = defaultValue(param['height'], 0);
    this.m_item = [];
    this.m_itemLeft = [];
    this.m_itemRight = [];
    this.m_size = this.m_cols * this.m_rows;
//    if (this.m_aniTimePageMove > 0) {
//        this.m_preload = {};
//    } else {
//        this.m_preload = false;
//    }
    
    /*used to save the focus position*/
    this.m_focusPos = {
        x : 0,
        y : 0
    };
    
    /*used to save current page index and the count of total page*/
    this.m_page = {
        index : 0,
        count : 0
    };

    /*used to save the begin index and total count in current page*/
    this.m_currentPage = {
        beginIndex : 0,
        count : 0
    };

    this.m_table = new Widget({
        x : this.m_itemX,
        y : this.m_itemY,
        width : this.width,
        height : this.height,
        parent : this,
        color : Volt.hexToRgb('#ffffff', 0)
    });
    this.m_tableLeft = new Widget({
        x : -this.width + this.m_itemX,
        y : this.m_itemBorder,
        width : this.width,
        height : this.height,
        parent : this,
        color : Volt.hexToRgb('#ffffff', 0)
    });
    this.m_tableRight = new Widget({
        x : this.width + this.m_itemX,
        y : this.m_itemBorder,
        width : this.width,
        height : this.height,
        parent : this,
        color : Volt.hexToRgb('#ffffff', 0)
    });

    var kBegin = 0, kEnd = 0;
    if (this.m_preload) {
        kBegin = -1, kEnd = 1;
    }
    var index = 0;
    for ( var k = kBegin; k <= kEnd; k++) {
        if (k == -1) {
            for ( var x = 0; x < this.m_cols; x++) {
                for ( var y = 0; y < this.m_rows; y++) {
                    if (this.orientation == 'horizontal') {
                        index = x + y * this.m_cols;
                    } else {
                        index = x * this.m_rows + y;
                    }
                    this.m_itemLeft[index] = {};
                    this.m_itemLeft[index].index = index;
                    this.m_itemLeft[index].widget = new Widget({
                        x : x * (this.m_itemWidth + this.m_itemXSpace),
                        y : y * (this.m_itemHeight + this.m_itemYSpace),
                        width : this.m_itemWidth,
                        height : this.m_itemHeight,
                        color : Volt.hexToRgb('#ffffff', 0),
                        parent : this.m_tableLeft
                    });
                    this.m_itemLeft[index].widget.hide();
                }
            }
        } else if (k == 1) {
            for ( var x = 0; x < this.m_cols; x++) {
                for ( var y = 0; y < this.m_rows; y++) {
                    if (this.orientation == 'horizontal') {
                        index = x + y * this.m_cols;
                    } else {
                        index = x * this.m_rows + y;
                    }
                    this.m_itemRight[index] = {};
                    this.m_itemRight[index].index = index;
                    this.m_itemRight[index].widget = new Widget({
                        x : x * (this.m_itemWidth + this.m_itemXSpace),
                        y : y * (this.m_itemHeight + this.m_itemYSpace),
                        width : this.m_itemWidth,
                        height : this.m_itemHeight,
                        color : Volt.hexToRgb('#ffffff', 0),
                        parent : this.m_tableRight
                    });
                    this.m_itemRight[index].widget.hide();
                }
            }
        } else {
            for ( var x = 0; x < this.m_cols; x++) {
                for ( var y = 0; y < this.m_rows; y++) {
                    if (this.orientation == 'horizontal') {
                        index = x + y * this.m_cols;
                    } else {
                        index = x * this.m_rows + y;
                    }
                    this.m_item[index] = {};
                    this.m_item[index].index = index;
                    this.m_item[index].widget = new Widget({
                        x : x * (this.m_itemWidth + this.m_itemXSpace),
                        y : y * (this.m_itemHeight + this.m_itemYSpace),
                        width : this.m_itemWidth,
                        height : this.m_itemHeight,
                        color : Volt.hexToRgb('#ffffff', 0),
                        parent : this.m_table
                    });
                    this.m_item[index].widget.hide();
                }
            }
        }
    }
}

/*
 * @description Set the data of items. 
 *  This function will count the count of total page, update the items.
 * @function rgcSetItems
 * @memberof TableWidget
 * @param {Array} arrItems - the data of items
 * @return None
 */
function rgcSetItems(arrItems) {
    assert(arrItems !== undefined);
    assert(arrItems.length > 0);
    this.m_focusPos.x = 0;
    this.m_focusPos.y = 0;
    this.m_page.index = 0;
    if (this.pageMoveMode == 'pagebypage' || this.orientation == 'horizontal') {
        this.m_page.count = Math.floor((arrItems.length - 1) / this.m_size) + 1;
    } else {
        var colNumber = Math.floor((arrItems.length - 1) / this.m_rows) + 1;
        this.m_page.count = Math.max(colNumber - this.m_cols, 0) + 1;
    }
    
    if (this.m_aniTimePageMove > 0) {
        this.m_preload = {};
    } else {
        this.m_preload = false;
    }
    this.m_arrItems = arrItems;
    this._updateItems();
//    this._ifItemFocus();
}

/*
 * @description Release this TableWidget
 * @function rgcReleaseItems
 * @memberof TableWidget
 * @return None
 */
function rgcReleaseItems(){
    this.m_arrItems = [];
    this.m_focusPos.x = 0;
    this.m_focusPos.y = 0;
    this.m_page.index = 0;
    this.m_page.count = 0;
    if (this.m_preload) {
        for ( var i = 0; i < this.m_size; i++) {
            this._drawItem(this.m_itemLeft[i], false);
            this._drawItem(this.m_item[i], false);
            this._drawItem(this.m_itemRight[i], false);
        }
    } else {
        for ( var i = 0; i < this.m_size; i++) {
            this._drawItem(this.m_item[i], false);
        }
    }
}

/*
 * @description Update the data of items. 
 *  This function will update the data of current page, call ifScroll.
 * @function rgcUpdateItems
 * @memberof TableWidget
 * @return None
 */
function rgcUpdateItems() {
    if (this.m_preload && this.m_page.count > 1) {
//        var leftBeginIndex = 0, leftCount = this.m_size;
        if(this.m_page.index == 0) {
            if(!this.m_preload.cur) {
                this.m_preload.left = {table : this.m_tableLeft, item : this.m_itemLeft, pageInfo : null};
                this.m_preload.right = {table : this.m_tableRight, item : this.m_itemRight, pageInfo : null};
                this.m_preload.cur = {table : this.m_table, item : this.m_item, pageInfo : null};
                this.m_preload.cur.pageInfo = this._updateItemsByPage(this.m_preload.cur.item, this.m_page.index);
            }
        }
        this.m_preload.left.pageInfo = this._updateItemsByPage(this.m_preload.left.item, this.m_page.index - 1);
        this.m_preload.right.pageInfo = this._updateItemsByPage(this.m_preload.right.item, this.m_page.index + 1);
        this.m_currentPage = this.m_preload.cur.pageInfo;
        if (this.orientation == 'horizontal') {
            this.ifScroll(Math.floor((this.m_currentPage.count - 1) / this.m_cols) + 1);
        } else {
            this.ifScroll(Math.min(this.m_currentPage.count, this.m_rows));
        }
    } else {
        this.m_currentPage = this._updateItemsByPage(this.m_item, this.m_page.index);
        if(this.pageMoveMode == 'pagebypage' || this.orientation == 'horizontal') {
            if (this.orientation == 'horizontal') {
                this.ifScroll(Math.floor((this.m_currentPage.count - 1) / this.m_cols) + 1);
            } else {
                this.ifScroll(Math.min(this.m_currentPage.count, this.m_rows));
            }
        } else {
            this.ifScroll(Math.min(this.m_currentPage.count, this.m_rows));
        }
    }
}

/*
 * @description Update the data of items by assigned page index. 
 *  This function will count the count of total page, update the items.
 * @function rgcSetItems
 * @memberof TableWidget
 * @param {Array} items - the data of items
 * @param {Number} pageIndex - the page index
 * @return None
 */
function rgcUpdateItemsByPage(items, pageIndex) {
    if(showLog) Volt.log('pageIndex - ' + pageIndex + ' totalPage - ' + this.m_page.count);
    if(pageIndex >= this.m_page.count || pageIndex < 0) return null;
    var pageInfo = {};
    if(this.pageMoveMode == 'pagebypage' || this.orientation == 'horizontal') {
        pageInfo.beginIndex = pageIndex * this.m_size;
        pageInfo.count = Math.min(this.m_arrItems.length - pageInfo.beginIndex, this.m_size);
    } else {
        pageInfo.beginIndex = pageIndex * this.m_rows;
        pageInfo.count = Math.min(this.m_arrItems.length - pageIndex * this.m_rows, this.m_size);
    }
    if(showLog) Volt.log('pageInfo - ' + JSON.stringify(pageInfo));
    for ( var i = 0; i < pageInfo.count; i++) {
        this._drawItem(items[i], true, this.m_arrItems[i + pageInfo.beginIndex]);
    }
    for ( var i = pageInfo.count; i < this.m_size; i++) {
        this._drawItem(items[i], false);
    }

    return pageInfo;
}

function rgcDrawItem(item, isShow, data) {
    if (isShow) {
        this.ifItemLoad(item, data);
        item.widget.show();
    } else {
        item.widget.hide();
    }
    item.isShow = isShow;
}

function rgcIfItemUnFocus() {
    var item = this._getValidItem(this.m_focusPos);
    if (item && item.custom && item.custom.onFocus) {
        item.custom.onBlur();
    }
}

function rgcIfItemFocus() {
    var item = this._getValidItem(this.m_focusPos);
    if (item && item.custom && item.custom.onFocus) {
        item.custom.onFocus();
    }
}

function rgcHandleKey(keyCode, keyType) {
    if (keyType == Volt.EVENT_KEY_PRESS) {
        if (keyCode == Volt.KEY_JOYSTICK_LEFT) {
            return this.onKeyLeft();
        } else if (keyCode == Volt.KEY_JOYSTICK_RIGHT) {
            return this.onKeyRight();
        } else if (keyCode == Volt.KEY_JOYSTICK_UP) {
            return this._onKeyUp();
        } else if (keyCode == Volt.KEY_JOYSTICK_DOWN) {
            return this._onKeyDown();
        } else if (keyCode == Volt.KEY_JOYSTICK_OK) {
            return this._onPressItem();
        }
    } else {
        if(showLog) Volt.log('this.m_focusPos.x - ' + this.m_focusPos.x);
        if(showLog) Volt.log('this.m_focusPos.y - ' + this.m_focusPos.y);
        if(showLog) Volt.log('this.m_page.index - ' + this.m_page.index);
    }

    return false;
}

function rgcOnKeyLeft() {
    if (this.m_focusPos.x > 0) {
        this._ifItemUnFocus();
        this.m_focusPos.x--;
        this._ifItemFocus();
        return true;
    }
    return this.onPageLeft();
}

function rgcPageLeft(){
    var item = undefined;
    if (this.m_page.index > 0) {
        if(this.m_preload && this.m_page.count > 1) {
            this.m_preload.cur.table.animate('x', this.width + this.m_itemX, this.m_aniTimePageMove);
            this.m_preload.left.table.animate('x', this.m_itemX, this.m_aniTimePageMove);
            var tempRight = this.m_preload.right; 
            this.m_preload.right = this.m_preload.cur;
            this.m_preload.cur = this.m_preload.left;
            this.m_preload.left = tempRight;
        } else {
            this.m_page.index--;
            this._ifItemUnFocus();
            this._updateItems();
            if(this.m_pageTurnReset && this.pageMoveMode == 'pagebypage'){
                this.m_focusPos.x = 0;
                this.m_focusPos.y = 0;
            } else {
                if(this.pageMoveMode == 'pagebypage' || this.orientation == 'horizontal') {
                    this.m_focusPos.x = this.m_cols - 1;
                }
            }
            this._ifItemFocus();
            return true;
        }
    } else {
        if (this.m_looping) {
            this.m_page.index = this.m_page.count - 1;
            this._ifItemUnFocus();
            
            if(this.m_preload && this.m_page.count > 1) {
                var anim1 = new Animation(this.m_aniTimePageMove);
                anim1.addProperty('x', this.m_itemX-384);
                anim1.addProperty('opacity', 0);
                var anim2 = new Animation(this.m_aniTimePageMove);
                anim2.addProperty('x', this.m_itemX);
                anim2.addProperty('opacity', 255);
                this.m_table.animate(anim1, function () {
                    this._updateItems();
                    this.m_focusPos.x = this.m_cols;
                    do {
                        item = this._getValidItem({x : this.m_focusPos.x - 1, y : this.m_focusPos.y});
                        this.m_focusPos.x--;
                    } while (item === undefined && this.m_focusPos.x > 0);
                    if(item === undefined) {
                        this.m_focusPos.y = 0;
                    }
                    this._ifItemFocus();
                    this.m_table.animate(anim2, function () {
                    });
                }.bind(this));
                return true;
            } else {
                if (this.m_page.count > 1) {
                    this._updateItems();
                }
                if(this.m_pageTurnReset && this.pageMoveMode == 'pagebypage'){
                    this.m_focusPos.x = 0;
                    this.m_focusPos.y = 0;
                    this._ifItemFocus();
                    return true;
                } else {
                    var newPosX = this.m_cols - 1;
                    var newPosY = 0;
                    do {
                        item = this._getValidItem({x : newPosX, y : newPosY});
                        newPosX--;
                    } while (item === undefined && newPosX >= 0);
                    newPosX++;
                    newPosY = this.m_focusPos.y;
                    if(item !== undefined) {
                        do {
                            item = this._getValidItem({x : newPosX, y : newPosY});
                            newPosY--;
                        } while (item === undefined && newPosY >= 0);
                        if(item !== undefined) {
                            if(!this.m_moveNearby && newPosX > 0 && this.m_focusPos.y != newPosY + 1) {
                                this.m_focusPos.x = newPosX - 1;
                            } else {
                                this.m_focusPos.x = newPosX;
                                this.m_focusPos.y = newPosY + 1;
                            }
                            this._ifItemFocus();
                            return true;
                        }
                    }
                }
            }
        }
    }
    return this.ifMoveOut(this.DIR.LEFT);
}

function rgcOnKeyRight() {
    var item = undefined;
    if (this.m_focusPos.x < this.m_cols - 1) {
        var newPosY = this.m_focusPos.y;
        do {
            item = this._getValidItem({x : this.m_focusPos.x + 1, y : newPosY});
            newPosY--;
            if(!this.m_moveNearby) {
                break;
            }
        } while (item === undefined && newPosY >= 0);
        if(item !== undefined) {
            this._ifItemUnFocus();
            this.m_focusPos.y = newPosY + 1;
            this.m_focusPos.x++;
            this._ifItemFocus();
            return true;
        }
    }
    return this.onPageRight();
}

function rgcPageRight(){
    if (this.m_page.index < this.m_page.count - 1) {
        this.m_page.index++;
        this._ifItemUnFocus();
        this._updateItems();
        if(this.m_pageTurnReset && this.pageMoveMode == 'pagebypage'){
            this.m_focusPos.x = 0;
            this.m_focusPos.y = 0;
        } else {
            if(this.pageMoveMode == 'pagebypage' || this.orientation == 'horizontal') {
                this.m_focusPos.x = 0;
            }
            do {
                item = this._getValidItem(this.m_focusPos);
                this.m_focusPos.y--;
            } while (item === undefined && this.m_focusPos.y >= 0);
            this.m_focusPos.y++;
        }
        this._ifItemFocus();
        return true;
    } else {
        if (this.m_looping) {
            this.m_page.index = 0;
            this._ifItemUnFocus();
            if(this.m_preload && this.m_page.count > 1) {
                var anim1 = new Animation(this.m_aniTimePageMove);
                anim1.addProperty('x', this.m_itemX+384);
                anim1.addProperty('opacity', 0);
                var anim2 = new Animation(this.m_aniTimePageMove);
                anim2.addProperty('x', this.m_itemX);
                anim2.addProperty('opacity', 255);
                
                this.m_table.animate(anim1, function () {
                    this._updateItems();
                    this.m_focusPos.x = 0;
                    item = this._getValidItem(this.m_focusPos);
                    if (item === undefined) {
                        this.m_focusPos.y = 0;
                    }
                    this._ifItemFocus();
                    this.m_table.animate(anim2, function () {
                        
                    });
                }.bind(this));
                return true;
            } else {
                if(this.m_page.count > 1) {
                  this._updateItems();
                }
                if(this.m_pageTurnReset && this.pageMoveMode == 'pagebypage'){
                    this.m_focusPos.x = 0;
                    this.m_focusPos.y = 0;
                } else {
                    this.m_focusPos.x = 0;
                }
                this._ifItemFocus();
                return true;
            }
        }
    }
    return this.ifMoveOut(this.DIR.RIGHT);
}

function rgcOnKeyUp() {
    if (this.m_focusPos.y > 0) {
        this._ifItemUnFocus();
        this.m_focusPos.y--;
        this._ifItemFocus();
        return true;
    }
    return this.ifMoveOut(this.DIR.UP);
}

function rgcOnKeyDown() {
    var item = undefined;
    if (this.m_focusPos.y < this.m_rows - 1) {
        var newPosX = this.m_focusPos.x;
        do {
            item = this._getValidItem({ x : newPosX, y : this.m_focusPos.y + 1});
            newPosX--;
            if(!this.m_moveNearby) {
                break;
            }
        } while (item === undefined && newPosX >= 0);
        if (item !== undefined) {
            this._ifItemUnFocus();
            this.m_focusPos.x = newPosX + 1;
            this.m_focusPos.y++;
            this._ifItemFocus();
            return true;
        }
    }
    return this.ifMoveOut(this.DIR.DOWN);
}

function rgcOnPressItem() {
    var item = this._getValidItem(this.m_focusPos);
    if (item !== undefined) {
        this.onMouseClickItem(item);
    }
    return true;
}

function rgcGetItemIndex(pos) {
//    if(showLog) Volt.log(JSON.stringify(pos));
    var index = 0;
    var x = pos.x;
    var y = pos.y;
    if(x < 0 || x >= this.m_cols || y < 0 || y >= this.m_rows) {
//        if(showLog) Volt.log('-1');
        return -1;
    }
    if (this.m_preload) {
        index = this.m_currentPage.beginIndex;
        if (this.orientation == 'horizontal') {
            index += x + y * this.m_cols;
        } else {
            index += x * this.m_rows + y;
        }
    } else {
        if (this.orientation == 'horizontal') {
            index = x + y * this.m_cols;
        } else {
            index = x * this.m_rows + y;
        }
    }
//    if(showLog) Volt.log('index - ' + index);
    return index;
}

function rgcGetItemPos(index){
//    if(showLog) Volt.log(index);
    var pos = {x : 0, y : 0};
    index = index % this.m_size;
    if (this.orientation == 'horizontal') {
        pos.x = index % this.m_cols;
        pos.y = Math.floor(index / this.m_cols);
    } else {
        pos.x = Math.floor(index / this.m_rows);
        pos.y = index % this.m_rows;
    }
//    if(showLog) Volt.log(JSON.stringify(pos));
    return pos;
}

function rgcGetValidItem(pos) {
//    if(showLog) Volt.log(JSON.stringify(pos));
    var index = this._getItemIndex(pos);
//    if(showLog) Volt.log('index - ' + index);
    if (index >= 0 && index < this.m_size && this.m_item[index] && this.m_item[index].isShow) {
        return this.m_item[index];
    } else {
        return undefined;
    }
}

function rgcGetItemByIndex(index) {
//    if(showLog) Volt.log('index - ' + index);
    if(index >= this.m_currentPage.beginIndex && index < this.m_currentPage.beginIndex + this.m_currentPage.count){
        return this._getValidItem(this._getItemPos(index - this.m_currentPage.beginIndex));
    }
    return undefined;
}

function rgcGetRealIndex(item){
    if(showLog) Volt.log('item.index - ' + item.index + 'real - ' + (this.m_currentPage.beginIndex + item.index));
    return this.m_currentPage.beginIndex + item.index;
}

function rgcModifyItemsData(index, option, newData){
    if(showLog) Volt.log('index - ' + index + ' option - ' + option + ' newData - ' + newData);
    if(index >= 0 && index < this.m_arrItems.length) {
        if(this.m_arrItems[index].hasOwnProperty(option)){
            this.m_arrItems[index][option] = newData;
        }
    }
}

function rgcConfigMouseEvent(item){
    Volt.log(item.index);
    item.widget.addEventListener("OnMouseClick", function(targetWidget, eventData)
    {
        this.onMouseClickItem(item);
    }.bind(this));

    item.widget.addEventListener("OnMouseOver", function(targetWidget, eventData)
    {
        var lastItem = this._getValidItem(this.m_focusPos);
        if(lastItem !== undefined && lastItem.custom) {
            lastItem.custom.onBlur();
        }
        item.custom.onFocus();
        var pos = this._getItemPos(item.index);
        this.m_focusPos.x = pos.x;
        this.m_focusPos.y = pos.y;
    }.bind(this));
}

exports = TableWidget;
