/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview YahooServerAPI.js get info for yahoo server api.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
//var Backbone = Volt.require('lib/volt-backbone.js');
var md5 = Volt.require('app/common/md5.js');

var DeviceInfoModel = Volt.require('app/common/deviceModel.js');

/**
 * @description YahooServerAPI 
 * @class YahooServerAPI
 * 
 * @property {Function} getMainNewsAPI - get yahoo MainNews API.
 * @property {Function} getMoreNewsAPI - get yahoo MoreNews API
 * @property {Function} getNewsDetailAPI - get yahoo News Detail API
 * @property {Function} getWeatherDetailAPI - get yahoo Weather Detail API
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 */
var YahooServerAPI = {
	oGlobalParams : {
		appid : 'com.samsung.panels.tv.ytoday',
		// appver: '', // this query removed (???D)
		contextid : 'samsung.main.2014', // [TODO] this value should be changed to 'samsung.main.2014', but 131126, Yahoo do not send data.
		man : 'SEC',
		model : '', // 13_FOXP
		deviceid : '', // H3CJYYHX5O3BO
		// hwversion: '', // this query removed (???D)
		swversion : '', // T-FXPUABC-1611.1
		region : '', // NZ
		language : '', // en
		res : '',
		// firmware: '', // this query removed (???D)
		//ts: '', // 1378895947 // [TODO] ?? ?? ?? ???? ?
		// sig: '', // 34837e23758375b2c02dcb3c0b94ce5d // added in call() by addSignature()
		format : 'json'
	},
	ts : '0',
	baseQueryString : '',
	SAMSUNG_SECRET_KEY : 'YA5qZfUCUgSPIj4KuGLuQsdykXSRZPWhLSUVBn1ifGc-',
	domain : '',

	initialize : function (options) {
		this.domain = options.domain;

		this.oGlobalParams.deviceid = DeviceInfoModel.get('duid');
		var tmpModel = DeviceInfoModel.get('modelId');
		this.oGlobalParams.model = (tmpModel != '') ? tmpModel : this.oGlobalParams.deviceid;
		this.oGlobalParams.swversion = DeviceInfoModel.get('firmware');
		this.oGlobalParams.region = DeviceInfoModel.get('countryCode');
		this.oGlobalParams.language = options.languageCode;
		this.oGlobalParams.res = DeviceInfoModel.get('resolutionX') + 'x' + DeviceInfoModel.get('resolutionY');
		this.baseQueryString = makeQueryString(this.oGlobalParams);
		Volt.log('baseQueryString is ' + this.baseQueryString);

		function makeQueryString(queryMap) {
			var aQuery = [],
			sProp,
			sQueryString;

			for (sProp in queryMap) {
				if (queryMap[sProp] != '') {
					aQuery.push(sProp + '=' + queryMap[sProp]);
				}
			}

			sQueryString = aQuery.join('&');

			return sQueryString;
		}
	},

	getQueryString : function () {
	    return this.baseQueryString + '&ts=0';
		var nEpochMs = new Date().getTime();
		this.ts = parseInt(nEpochMs / 1000);
		return this.baseQueryString + '&ts=' + this.ts;
	},

	getQueryUrl : function (options) {
	    return this.domain + options + '?' + this.baseQueryString + '&ts=0';
		var nEpochMs = new Date().getTime();
		this.ts = parseInt(nEpochMs / 1000);
		return this.domain + options + '?' + this.baseQueryString + '&ts=' + this.ts;

	},

    getDomain : function () {
	    return this.domain;
	},

    /**
     * @description get yahoo Main News API
     * @function getMainNewsAPI
     * @memberof YahooServerAPI
     * @return {string} return yahoo Main News API
     */
	getMainNewsAPI : function () {
		var url = this.domain + 'GetYTodayContent' + '?' + this.getQueryString();
		return this.addSignature(url);
	},

	/**
     * @description get yahoo More News API
     * @function getMoreNewsAPI
     * @memberof YahooServerAPI
       * @param {object} options - options data
     * @return {string} return yahoo More News API
     */
    getMoreNewsAPI : function(options) {
    	var url = options.url + '&page='+ options.page + '&' + this.getQueryString();
    	return this.addSignature(url);
	},

		/**
     * @description get yahoo News Detail API
     * @function getNewsDetailAPI
     * @memberof YahooServerAPI
     * @param {object} options - options data
     * @return {string} return yahoo News Detail API
     */
    getNewsDetailAPI : function(options) {
    	var url = options.url +'&' + this.getQueryString();
    	return this.addSignature(url);
	},

		/**
     * @description get yahoo Weather Detail API
     * @function getWeatherDetailAPI
     * @memberof YahooServerAPI
     * @return {string} return yahoo Weather Detail API
     */
    getWeatherDetailAPI : function() {
        var url = this.domain + 'GetWeatherDetails' +'?' + this.getQueryString();
    	return this.addSignature(url);
    },
	
	addSignature : function (url) {
		var sSignature = md5(url + this.SAMSUNG_SECRET_KEY);
		return url + '&sig=' + sSignature;
	}
};

exports = YahooServerAPI;
