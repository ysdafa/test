function rgcDownPage()
{
    if(typeof this.index !== 'number' || this.index < 0 || this.index >= this.total)
        return;
    if(this.index >= 0 && this.index <= this.total - 1)
    {
        this.index++;
    }
    if(this.index == this.total)
    {
        if(this.loop)
        {
            this.index = 0;
        }else
        {
            this.index = this.total - 1;
        }
    }
    this.__updateScrollBar('up');
}
function rgcUpPage()
{
    if(typeof this.index !== 'number' || this.index < 0 || this.index >= this.total)
        return;
    if(this.index >= 0)
    {
        this.index--;
    }
    if(this.index < 0)
    {
        if(this.loop)
        {
            this.index = this.total - 1;
        }else
        {
            this.index = 0;
        }
    }
    this.__updateScrollBar('down');
    
}
function rgcUpdateScrollBar(direction)
{
    var widget = this;
    this.thumb.y = this.index * Math.floor(this.height / this.total);
    if(this.index == this.total - 1)
    {
        this.thumb.height = Math.floor(this.height / this.total) + this.extraPart; //adjust the thumb height when it goes to end
    }else
    {
        this.thumb.height = Math.floor(this.height / this.total);
    }
    
    if(!this.bThumbShow)
    {
        /*
        if(this.animationShowHandle !== null)
        {
            this.animationShowHandle.cancel();
            this.animationShowHandle = null;
        }
        this.bThumbShow = true;
        this.animationShowHandle = this.animate(this.animationShow,function(){});*/
        this.bThumbShow = true;
        this.transOne.AddObjectDestination(this, 'alpha', 255);
        this.transOne.play();
    }
    if(this.timeout !== null)
    {
        Volt.clearTimeout(this.timeout);
        this.timeout = null;
    }
    this.timeout = Volt.setTimeout(function(){
        widget.transTwo.AddObjectDestination(widget, 'alpha', 0);
        widget.transTwo.play();
    },3000);
}
function defaultValue(value, defaultValue)
{
	if (value === undefined)
	{
		return defaultValue;
	}
	else
	{
		return value;
	}
}
function rgcSetCount(count)
{
    if(typeof count !== 'number' || count <= 0)
        return;
    this.total = count;
    this.index = 0;
    this.thumb.height = Math.floor(this.height/this.total);
    this.extraPart = this.height % this.total;
}
function rgcReset(){
    if(this.transOne){
        this.transOne.stop();
    }
    if(this.transTwo){
        this.transOne.stop();
    }
    if(this.timeout !== null)
    {
        Volt.clearTimeout(this.timeout);
        this.timeout = null;
    }
    this.opacity = 0;
    this.bThumbShow = false;
    this.index = 0;
    this.total = 0;
    this.thumb.y = 0;
    this.show();
}
function ScrollBar(param)
{
    var height = parseInt(defaultValue(param['height'],Volt.height));
    var width = parseInt(defaultValue(param['width'],5));
    var x = parseInt(defaultValue(param['x'],0));
    var y = parseInt(defaultValue(param['y'],0));
    var total = 0;
    var index = 0;
    var loop = defaultValue(param['loop'],false);
    var scrollBar = new WidgetEx({
        height:height,
        width:width,
        color : {r:220,g:220,b:220,a:255*0.2},
        x:x,
        y:y,
    });
    scrollBar.black = new WidgetEx({
      x:Volt.width * (0.002083 - 0.000521),
      y:0,
      height:height,
      width:Volt.height * 0.000521,
      color:{r:0,g:0,b:0,a:255*0.2},
      parent:scrollBar,
    });
    scrollBar.parent = param['parent'];
    scrollBar.id = param['id'];
    scrollBar.total = total;
    scrollBar.index = index;
    scrollBar.loop = loop;
    scrollBar.timeout = null;
    var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
    scrollBar.thumb = new ImageWidgetEx({
      x:0,
      y:0,
      height:0,
      width:width,
      //color:{r:255,g:255,b:255,a:255},
      src:null,//Volt.getRemoteUrl('images/1080/scroll/keyscreen_scroll_vertical_pn.png'),
      parent:scrollBar,
    });
    scrollBar.thumb.src = ResourceMgr.KeyscreenScrollVPNormal;
    scrollBar.transOne = new MultiObjectTransition(200);
    scrollBar.transTwo = new MultiObjectTransition(200);
    var transListenerOne = new MultiObjectTransitionListener();
    var transListenerTwo = new MultiObjectTransitionListener();
    transListenerOne.onStoped = function(transition, isFinished){
        Volt.log('transListenerOne---isFinished'+isFinished);
        
    }
    transListenerTwo.onStoped = function(transition, isFinished){
        Volt.log('transListenerTwo---isFinished'+isFinished);
        scrollBar.bThumbShow = false;
    }
    scrollBar.transOne.addListener(transListenerOne);
    scrollBar.transTwo.addListener(transListenerTwo);
    /*
    scrollBar.animationShow = new Animation(200, 0);
    scrollBar.animationShowHandle = null;
    scrollBar.animationShow.addProperty("opacity", 255);
    scrollBar.animationHide = new Animation(200, 0);
    scrollBar.animationHide.addProperty("opacity", 0);
    scrollBar.animationHideHandle = null;*/
    scrollBar.setCount = rgcSetCount;
    scrollBar.bThumbShow = false;
    scrollBar.upPage = rgcUpPage;
    scrollBar.downPage = rgcDownPage;
    scrollBar.reset = rgcReset;
    scrollBar.__updateScrollBar = rgcUpdateScrollBar;
    scrollBar.opacity = 0;
    scrollBar.show();
    return scrollBar;
}

exports = ScrollBar;
    
