 /** 
 * @author  qiu weihua (weihua.qiu@samsung.com)
 * 			 
 * @fileoverview  Model controller
 * @date    2014/08/22 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var MenuController = function() {
	this.enableMenu = function(){
		print('menu-controller.js enableMenu()');
		VDUtil.AppControl_InitDbusConnection();
		VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.newson");
		VDUtil.AppControl_FiniDbusConnection();  
	};

	this.disableMenu = function(){
		print('menu-controller.js disableMenuItem()');
		VDUtil.AppControl_InitDbusConnection();
		VDUtil.AppControl_DisableItem("sound-mode", "org.volt.newson");
        VDUtil.AppControl_DisableItem("picturesize", "org.volt.newson");
        VDUtil.AppControl_DisableItem("3d", "org.volt.newson");
        VDUtil.AppControl_DisableItem("resetpicture", "org.volt.newson");
        VDUtil.AppControl_DisableItem("setup", "org.volt.newson");
        VDUtil.AppControl_DisableItem("osd-language", "org.volt.newson");
        VDUtil.AppControl_DisableItem("softwareupdate", "org.volt.newson");
        VDUtil.AppControl_DisableItem("self-diagnosis", "org.volt.newson");

		VDUtil.AppControl_FiniDbusConnection();
	};
};

var menuController = new MenuController();
exports = menuController;
