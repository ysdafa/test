/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview CAPI.js cpapi init.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
var SICServerAPI = Volt.require('app/common/SICServerAPI.js');
var YahooServerAPI = Volt.require('app/common/YahooServerAPI.js');
var SinaHuafengAPI = Volt.require('app/common/SinaHuafengAPI.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var DeviceModel = Volt.require('app/common/deviceModel.js');

/**
 * @description CPAPI 
 * @class CPAPI
 * 
 * @property {Function} getMainNewsAPI - get MainNews API.
 * @property {Function} getMainWeatherAPI - get MainWeather API
 * @property {Function} getMoreNewsAPI - get MoreNews API
 * @property {Function} getNewsDetailAPI - get News Detail API
 * @property {Function} getWeatherDetailAPI - get Weather Detail API
 * @property {Function} getWeatherCityListAPI - get Weather CityList API
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 */
var CPAPI = {
	oCPModule : null,
	tryCount : 0,
	RETRY_LIMIT : 3,
	serviceType : 'yahoo',

	initialize : function () {
	    var deferred =  Q.defer();
		//SICServerAPI.initialize();
		onSICAuthSuccess();
		return deferred.promise;

		/*SICServerAPI.authenticate({
		success: function() {
		Volt.log('[initialize]auth succeed.');
		onSICAuthSuccess();
		},
		error: function(error) {
		//CPAPI.state = CPAPI.INIT_STATE_FAIL;
		Volt.log('[initialize]auth fail.');
		//onError(error);
		}
		});*/

		function onSICAuthSuccess() {
			//CPAPI.oCPModule = null;
			SICServerAPI.domainlist({
				success : function (result) {
					Volt.log('domainTotalCount: ' + result.domainTotalCount);
					if (result.domainTotalCount > 0) {
						CPAPI.serviceType = result.servicetype;
						switch (result.servicetype) {
		                    case 'yahoo':
			                    YahooServerAPI.initialize({
			                        domain: result.domainlist[0].apidomain,
			                        languageCode: result.domainlist[0].lang
			                    });
								CPAPI.oCPModule = YahooServerAPI;
								break;

		                    case 'sina_huafeng':
			                    SinaHuafengAPI.initialize({
			                        domainlist: result.domainlist
			                    });
								CPAPI.oCPModule = SinaHuafengAPI;
		                        break;

		                    default:
			                    YahooServerAPI.initialize({
			                        domain: result.domainlist[0].apidomain,
			                        languageCode: result.domainlist[0].lang
			                    });
								CPAPI.oCPModule = YahooServerAPI;
		                        break;
	                	}

						deferred.resolve(true);
					} else {
						Volt.log('get domainlist fail.');

						if (CPAPI.tryCount < CPAPI.RETRY_LIMIT) {
							Volt.log('Retry getting domainlist after 3 sec...');
							CPAPI.tryCount++;
							Volt.setTimeout(function () {
								//SICServerAPI.initialize();
								onSICAuthSuccess();
							}, 3000);

						} else {
							Volt.log('get domainlist timeout');
							deferred.resolve(false);
						}
					}
				},
				error : function (error) {
					CPAPI.tryCount = 0;
					Volt.log('get domainlist fail');
					deferred.resolve(false);
				},
				reject : function () {
				    Volt.log('get domainlist is cancelled');
                    deferred.reject();
                }
			});
		}

		function onSuccess(result) {
			Volt.log('onSuccess in CPAPI');
		}

		function OnError(error) {
			Volt.log('OnError in CPAPI');
		}
	},

    /**
     * @description get Main News API
     * @function getMainNewsAPI
     * @memberof CPAPI
     * @return {string} return Main News API
     */
	getMainNewsAPI : function () {
		return CPAPI.oCPModule?CPAPI.oCPModule.getMainNewsAPI():'';
	},

	    /**
     * @description get Main Weather API
     * @function getMainWeatherAPI
     * @memberof CPAPI
     * @return {string} return Main Weather API
     */
	getMainWeatherAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getMainWeatherAPI(options):'';
    },

		    /**
     * @description get More Weather API
     * @function getMoreNewsAPI
     * @memberof CPAPI
     * @return {string} return More Weather API
     */
    getMoreNewsAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getMoreNewsAPI(options):'';
    },

	/**
     * @description get News Detail API
     * @function getNewsDetailAPI
     * @memberof CPAPI
     * @return {string} return News Detail API
     */
    getNewsDetailAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getNewsDetailAPI(options):'';
    },

	/**
     * @description get Weather Detail API
     * @function getWeatherDetailAPI
     * @memberof CPAPI
     * @return {string} return Weather Detail API
     */
    getWeatherDetailAPI : function(options) {
		return CPAPI.oCPModule?CPAPI.oCPModule.getWeatherDetailAPI(options):'';
    },

	/**
     * @description get Weather CityList API
     * @function getWeatherCityListAPI
     * @memberof CPAPI
     * @return {string} return Weather CityList API
     */
    getWeatherCityListAPI : function() {
		return CPAPI.oCPModule?CPAPI.oCPModule.getWeatherCityListAPI():'';
    },
	
	getServiceType : function() {
		return CPAPI.serviceType;
	}


};

exports = CPAPI;
