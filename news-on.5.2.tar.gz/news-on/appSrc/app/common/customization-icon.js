/**
 * @author Zhu Hongjie (hj00.zhu@samsung.com)
 * @fileoverview Draw a icon.
 * @date 2014/08/28(last modified date)
 * 
 * Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung Electronics, Inc. ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Samsung.
 */

//Require common template for customization-button
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');

/**
 * Custom a icon by assigned template base on GUI.
 * @function customizationIcon
 * @param {ImageWidget} icon - the icon defined in template
 * @param {JSON} template - a template used basic template. basic template defined in newson-common-template.js
 * @example
 *  1. define a ImageWidget in template
 *     {
 *         id : 'newson-tutorial-cold-start-left-arrow',
 *         type : 'image',
 *         x : 50,
 *         y : 500,
 *         width : 36,
 *         height : 48,
 *         color : ScreenTemplate.transparentColor
 *     }
 *  2. use customizationIcon to custom icon
 *     this.leftArrow = this.widget.getDescendant('newson-tutorial-cold-start-left-arrow');
 *     customizationIcon(this.leftArrow, {imageStyle : 'leftArrow',});
 *  3. rewrite needed event
 *     this.leftArrow.onMouseClick = function() {
 *         this.list.pageLeft();
 *     }.bind(this);
 */
var customizationIcon = function(icon, template) {
    if (icon && template) {
        var commonButtonTemplate;
        if (template.hasOwnProperty('imageStyle')) {
            commonButtonTemplate = CommonTemplate[template.imageStyle];
            if (commonButtonTemplate) {
                if (commonButtonTemplate.normal) {
                    if (commonButtonTemplate.normal.src) {
                        //modified by yipeng.zhu @2014.12.5
                        icon.getChild(0).src = commonButtonTemplate.normal.src;
                        icon.transOne = new MultiObjectTransition();
                        icon.transOne.setDuration(10);
                    }
                    icon.onMouseOutDefault = function() {
                        Volt.log();
                        //modified by yipeng.zhu @2015.01.14
                        icon.transOne.AddObjectDestination(icon.getChild(0), "scale-x", 1.0);
                        icon.transOne.AddObjectDestination(icon.getChild(0), "scale-y", 1.0);
                        icon.getChild(0).opacity = 255 * 0.6;
                        icon.transOne.play();
                        //end of modified
                    };
                    icon.onBlur = function(){
                        Volt.log();
                        if(icon.onMouseOut) return;
                    };
                    icon.onMouseOutDefault();
                }
                if (commonButtonTemplate.focus) {
                    icon.onMouseOverDefault = function() {
                        Volt.log();
                        //modified by yipeng.zhu @2015.01.14
                        icon.transOne.AddObjectDestination(icon.getChild(0), "scale-x", 1.1);
                        icon.transOne.AddObjectDestination(icon.getChild(0), "scale-y", 1.1);
                        icon.transOne.play();
                        icon.getChild(0).opacity = 255;
                        //end of modified
                    };
                    icon.onFocus = function(){
                        Volt.log();
                        if(icon.onMouseOver) return;
                    };
                }
            } else {
                throw new Error('bad imageStyle for customization icon');
            }
        } else {
            throw new Error('bad arguments for customization icon');
        }
//        icon.onMouseOver = icon.onMouseOverDefault;
//        icon.onMouseOut = icon.onMouseOutDefault;
//        icon.onMouseClick = icon.onMouseClickDefault;
//        icon.modal = false;
        icon.addEventListener('OnMouseOver', function() {
//            Volt.Nav.beginModal(icon);
//            icon.modal = true;
            if(icon.onMouseOver) {
                if(icon.onMouseOver()){
                    icon.onMouseOverDefault();
                }
            } else {
                icon.onMouseOverDefault();
            }
        });
        icon.addEventListener('OnMouseOut', function() {
            if(icon.onMouseOut) {
                if(icon.onMouseOut()){
                    icon.onMouseOutDefault();
                }
            } else {
                icon.onMouseOutDefault();
            }
//            if(icon.modal) {
//                icon.modal = false;
//                Volt.Nav.endModal();
//            }
        });
        icon.addEventListener('OnMouseClick', function() {
//            if(icon.modal) {
//                icon.modal = false;
//                Volt.Nav.endModal();
//            }
            if(icon.onMouseClick) {
                icon.onMouseClick();
            } else {
                icon.onMouseClickDefault();
            }
        });
        
        icon.hide();
    } else {
        throw new Error('Error to create Arrow');
    }
    return icon;
};

exports = customizationIcon;