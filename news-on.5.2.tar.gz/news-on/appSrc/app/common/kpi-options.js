var _ = Volt.require("modules/underscore.js")._;
var CommonDefines = Volt.require('app/common/commonDefines.js');
var voltapi = Volt.require('voltapi.js');

var KPI = function(view){
	this.view = view;
	this.options = {};
	this.send = function(desc){
		try{
			this.setOptions();
			_.extend(this.options.d, desc);
            _.extend(this.options.d, {
        		sappid : CommonDefines.Config.app_id,
        		sappver : CommonDefines.Config.app_version
        	});
			Volt.KPIMapper.addEventLog(this.kpiName, this.options);
		}catch(e){
			Volt.log('[kpi-options.js] send Error - ' + e);
		}
	};
};


var CPAPI = Volt.require('app/common/CPAPI.js');
function getCPName(){
	return CPAPI.getServiceType();
}

function getAgreedViewing() {
    return true; //remove restriction
    var	sAgreedViewing = '0';
    if(true == voltapi.Logging.isOpened()){
    	sAgreedViewing = voltapi.Logging.isAgreedWith('viewing');
    	Volt.log('Viewing History Privacy Notice : ' + sAgreedViewing);
    }

	return sAgreedViewing == '1' ? true : false;
}

function extend(protoProps, staticProps) {
    var parent = this;
    var child;

    // The constructor function for the new subclass is either defined by you
    // (the "constructor" property in your `extend` definition), or defaulted
    // by us to simply call the parent's constructor.
    if (protoProps && _.has(protoProps, 'constructor')) {
      child = protoProps.constructor;
    } else {
      child = function(){ return parent.apply(this, arguments); };
    }

    // Add static properties to the constructor function, if supplied.
    _.extend(child, parent, staticProps);

    // Set the prototype chain to inherit from `parent`, without calling
    // `parent`'s constructor function.
    var Surrogate = function(){ this.constructor = child; };
    Surrogate.prototype = parent.prototype;
    child.prototype = new Surrogate();

    // Add prototype properties (instance properties) to the subclass,
    // if supplied.
    if (protoProps){
		_.extend(child.prototype, protoProps);
    }

    // Set a convenience property in case the parent's prototype is needed
    // later.
    child.__super__ = parent.prototype;

    return child;
}

KPI.extend = extend;

// ============================ HomeView ============================//
var SelectNews = KPI.extend({
    kpiName : 'SELECTNEWS',
    setOptions : function(){
        this.options = {
            d : {
				//cp : 'H01_HOME',
				//sp is from parameter
                //sp : tile.get('position'),
				//ct : tile.get('tile_type'),
				//cn : getCPName(),
				//ai : tile.get('id'),
				//at : tile.get('title')
            }
        };
    }
});


var SelectWeather = KPI.extend({
	kpiName : 'SELECTWEATHER',
	setOptions : function(){
    	var cityCollection, cityIdx;
		for ( var i = 0; i < this.view.tileCollection.length; i++) {
            if (this.view.tileCollection.at(i).get('tile_type') == 'weather') {
                cityCollection = this.view.tileCollection.at(i).get('weatherTileCityCollection');
				cityIdx = this.view.tileCollection.at(i).get('cityIdx');
        	}
		}

		this.options = {
			d : {
				cp : 'H01_HOME',
				ci : cityCollection.at(cityIdx).get('id')
			}
		};
	}
});

var SelectCP = KPI.extend({
	kpiName : 'SELECTCP',
	setOptions : function(){
		this.options = {
			d : {
				cp : 'H01_HOME',
				sp : 'S-P-01',
				cn : getCPName()
			}
		};
	}
});

var SelectSetting = KPI.extend({
	kpiName : 'SETTING',
	setOptions : function(){
		this.options = {
			d : {
				//cp : 'H01_HOME'
			}
		};
	}
});

// ============================ NewsDetail ============================//
var SelectRelatedNews = KPI.extend({
	kpiName : 'SELECTRELATEDNEWS',
	setOptions : function(){
		this.options = {
			d : {
				//cp : 'H02_DETAIL',
				//sp is from parameter
                //sp : tile.get('position'),
				//cl : 'C-L-01',//TBD
				//cn : getCPName(),
				//ai : tile.get('id'),
				//at : tile.get('title')
			}
		};
	}
});
var UpScroll = KPI.extend({
	kpiName : 'UPSCROLL',
	setOptions : function(){
		this.options = {
			d : {
				cp : 'H02_DETAIL'
			}
		};
	}
});

var DownScroll = KPI.extend({
	kpiName : 'DOWNSCROLL',
	setOptions : function(){
		this.options = {
			d : {
				cp : 'H02_DETAIL'
			}
		};
	}
});
// ============================ NewsDetailVideo ============================//
var PlayArticleVideo = KPI.extend({
	kpiName : 'PLAYARTICLEVIDEO',
	setOptions : function(){
		this.options = {
			d : {
			}
		};
	}
});
// ============================ WeatherDetail ============================//
var MovePrevious = KPI.extend({
    kpiName : 'MOVEPREVIOUS',
    setOptions : function(){
    	var tile = this.view.model.get('weatherDetailCityCollection').at(this.view.contentView.index-1);
        this.options = {
            d : {
				cp : 'H04_WEATHER',
				sp : 'S-P-'+(this.view.contentView.index<10 ? '0' : '') + this.view.contentView.index,
				ci : tile.get('id')
            }
        };
    }
});
var MoveNext = KPI.extend({
    kpiName : 'MOVENEXT',
    setOptions : function(){
        var tile = this.view.model.get('weatherDetailCityCollection').at(this.view.contentView.index-1);
        this.options = {
            d : {
				cp : 'H04_WEATHER',
				sp : 'S-P-'+(this.view.contentView.index<10 ? '0' : '') + this.view.contentView.index,
				ci : tile.get('id')
            }
        };
    }
});
// ============================ WeatherSetting ============================//
var WeatherSetting = KPI.extend({
	kpiName : 'WEATHERSETTING',
	setOptions : function(){
		this.options = {
			d : {
				cp : 'H01_HOME'
			}
		};
	}
});

var Save = KPI.extend({
	kpiName : 'SAVE',
	setOptions : function(){
	    var weatherSettingCodeCityList = this.view.model.codeArray.toString();
		var cityIDList = weatherSettingCodeCityList.replace(/\,/g, '|');
		this.options = {
			d : {
				cp : 'H05_WEATHER',
				ci : cityIDList,
				cn : this.view.model.codeArray.length
			}
		};
	}
});


var Cancel = KPI.extend({
	kpiName : 'CANCEL',
	setOptions : function(){
		this.options = {
			d : {
				cp : 'H05_WEATHER'
			}
		};
	}
});
// ============================ Common ============================//
var Exit = KPI.extend({
	kpiName : 'EXIT',
	setOptions : function(){
		this.options = {
			d : {
			}
		};
	}
});
var Return = KPI.extend({
	kpiName : 'RETURN',
	setOptions : function(){
		this.options = {
			d : {
			}
		};
	}
});


exports = {
	Home : {
        SelectNews : SelectNews,
		SelectWeather : SelectWeather,
		SelectCP : SelectCP,
		SelectSetting : SelectSetting,
	},
	NewsDetail : {
		SelectRelatedNews : SelectRelatedNews,
		UpScroll : UpScroll,
		DownScroll : DownScroll
	},
	NewsDetailVideo : {
		PlayArticleVideo : PlayArticleVideo
	},
	WeatherDetail : {
		MovePrevious : MovePrevious,
		MoveNext : MoveNext
	},
	WeatherSetting : {
		WeatherSetting : WeatherSetting,
		Save : Save,
		Cancel : Cancel
	},
	Common : {
        Exit : Exit,
        Return : Return
    },
    getAgreedViewing : getAgreedViewing
};
