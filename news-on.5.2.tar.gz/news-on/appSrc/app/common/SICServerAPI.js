/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview SICServerAPI.js.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
var voltapi = Volt.require('voltapi.js');
var DeviceInfoModel = Volt.require('app/common/deviceModel.js');
var Global = Volt.require('app/common/Global.js');
var RestRequestId = null;
/* A Module for accessing to Samsung Information panel Configuration Server. */

var SICServerAPI = {
	domainlist : function (options) {
		Volt.log('domainlist start');

        var url = 'newson/service/v2/domainlist?CountryCode='+DeviceInfoModel.get('countryCode');
        if (false === voltapi.rest.isOpened()) {
            Volt.log('begin to open rest client async');
	        voltapi.rest.initAsync(sendRequest);
	    }else{
	        Volt.log('rest client is already opened');
            sendRequest(true);
        }
        
        function sendRequest(isOpened){
            Volt.log('end openning rest client, result is '+isOpened);
            if (true == isOpened){
                voltapi.rest.clearParam();
        	    voltapi.rest.clearBody();
                
                voltapi.rest.setSmartTVHeader(true);
                voltapi.rest.sendAsync('GET', url,
                	function(data, status, response) {
                		Volt.log('data is ' + data);
                		Volt.log('url is ' + response.uri);
                		options.success(JSON.parse(data));
                	},
                	function(object, status, err) {
                		Volt.log('err is ' + err);
                		options.error(err);
                	},
                	function(object, status) {
                	    Volt.clearTimeout(timer_id);
                		Volt.log('On complete');
                        /*var id = RestRequestId;
                        Volt.post(function(){
                            if (voltapi.rest.m_requestMap[id]){
                                delete voltapi.rest.m_requestMap[id];
                            }
                        });*/
                	},
                	function(id){
                	    RestRequestId = id;
                        Volt.log('RestRequest readyCallback, id is '+id);
                    }
                );
                var timer_id = Volt.setTimeout(function(){
                    Global.RequestMgr.cancel();
                	Volt.log('request timeout!');
                	options.error('request timeout!');
                }, 40000);
                Global.RequestMgr.add({request_id:RestRequestId, timer_id:timer_id, callback:options.reject});
            }else{
                Volt.log('init rest failed!');
                options.error('init rest failed!');
            }
        }
	}
};

exports = SICServerAPI;
