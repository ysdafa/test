/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview deviceModel.js get device info.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
var Backbone = Volt.require('lib/volt-backbone.js');
var voltapi = Volt.require('voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
var self = null;


/**
 * @description DeviceInfoModel 
 * @class DeviceInfoModel
 * 
 * @property {Function} setResolution - set Resolution.
 * @property {Function} getScreenWidth - get Screen Width
 * @property {Function} getNetWorkState - get NetWork State
 * @property {Function} getLanguageCode - get Language Code
 * @property {Function} getHighContrast - get High Contrast
 * @property {Function} getEnlarge - get Enlarge flag
 * @property {Function} getMenuTTS - get Menu TTS flag
 * @property {Function} getServerType - get Server Type.
 * @property {Function} updateInfoFromVCONF - update Info From VCONF
 * @property {Function} updateInfoFromWAS - update info From WAS
 * @property {Function} listenNetworkStatus - listen Network Status
 * @property {Function} networkSetWatchListener -set network Watch Listener
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 */
var DeviceInfoModel = Backbone.Model.extend({
    deviceInfoReady : false,
    defaults : {
    	duid : "",
    	modelId : "",
    	countryCode : "",
    	languageCode : "",
    	//serverType : "",
    	vdToken : "",
    	firmware : "",
    	server_type : "",   //for debug
    	resolutionX : "",
    	resolutionY : "",
    	networkState : 0,
    	tts : 0,
    	highContrast:false,
        enlarge : false,
        
    },
    empReayFlag : {network:false, device:false},
    firstTimeNetworkFailed : false, //for first time fetch data,may failed flag 
    firstTimeNetworkTimeout : null,
    initialize : function () {
        self = this;
        //this.destroyVoltApi();
        this.listenNetworkStatus();
        this.getFirmwareFromDevice();
        this.updateInfoFromVCONF();
        this.setResolution();
        //this.updateInfoFromWAS();//not pre-requisite
    },

    /**
     * @description set Resolution
     * @function setResolution
     * @memberof DeviceInfoModel
     * @return None
     */
    setResolution : function () {
    	this.set("resolutionX", scene.width);
    	this.set("resolutionY", scene.height);
    },


    /**
     * @description get Screen Width
     * @function getScreenWidth
     * @memberof DeviceInfoModel
     * @return {int} return width
     */
    getScreenWidth : function () {
		var width = SystemInfo.getIntValue(SystemInfo.KEY_SCREEN_WIDTH);
		return width;
    },


    /**
     * @description get NetWork State
     * @function getNetWorkState
     * @memberof DeviceInfoModel
     * @return {string} return NetWorkState
     */
    getNetWorkState : function () {
        return this.get("networkState");
    },

	    /**
     * @description get Language Code
     * @function getLanguageCode
     * @memberof DeviceInfoModel
     * @return {string} return LanguageCode
     */
    getLanguageCode : function() {
        return this.get("languageCode");
    },

	    /**
     * @description get HighContrast
     * @function getHighContrast
     * @memberof DeviceInfoModel
     * @return {string} return HighContrast
     */
	getHighContrast : function() {
        return this.get("highContrast");
    },

   /**
     * @description get Enlarge flag
     * @function getEnlarge
     * @memberof DeviceInfoModel
     * @return {string} return Enlarge flag
     */
    getEnlarge : function() {
        return this.get("enlarge");
    },

    //1: true, 0: false
       /**
     * @description get TTS flag
     * @function getMenuTTS
     * @memberof DeviceInfoModel
     * @return {string} return TTS flag
     */
    getMenuTTS : function() {
        return this.get('tts');
    },

       /**
     * @description get Server flag
     * @function getServerType
     * @memberof DeviceInfoModel
     * @return {string} return Server flag
     */
    getServerType : function(){
        if ('' == this.get('server_type')){
            this.updateInfoFromWAS();//not pre-requisite
        }
        return this.get('server_type');
    },
    
    checkDeviceInfoReady : function() {
        Volt.log();

        if (false == self.empReayFlag.network){
            return;
        }
        if (false == self.empReayFlag.device){
            return;
        }
        Volt.log('emp init finished, device info is ok.');
        self.deviceInfoReady = true;
        GlobalMediator.trigger(CommonDefines.Event.ON_DEVICEINFO_READY);
    },
    
    isDeviceInfoReady : function() {
        Volt.log('deviceInfoReady is '+this.deviceInfoReady);
        return this.deviceInfoReady;
    },

	/**
     * @description update Info From VCONF
     * @function updateInfoFromVCONF
     * @memberof DeviceInfoModel
     * @return None
     */
    updateInfoFromVCONF : function () {
        var atoken = voltapi.vconf.getValue(CommonDefines.Vconf.DEVICE_ATOKEN);
        Volt.log('atoken get by vconf is '+atoken);
        this.set("vdToken", atoken || getAToken());

        var model_id = voltapi.vconf.getValue(CommonDefines.Vconf.DEVICE_MODEL_ID);
        Volt.log('model_id get by vconf is '+model_id);
        this.set("modelId", model_id || getModelId());

        var duid = voltapi.vconf.getValue(CommonDefines.Vconf.DEVICE_DUID);
        Volt.log('duid get by vconf is '+duid);
        this.set("duid", duid || getDUID());
		
        var country_code = voltapi.vconf.getValue(CommonDefines.Vconf.COUNTRY_CODE);
        
        //add for forum hijeck
        if(country_code == 'XG'){
            country_code = 'TH';
        }else if(country_code == 'XF' || country_code == 'XP'){
            country_code = 'BR';
        }else if(country_code == 'XJ'){
            country_code = 'CN';
        }
        //end 
        Volt.log('country code get by vconf is '+country_code);
        /*if (country_code != 'CN'){
            country_code = 'BR';//dummy Brazil
        }*/
        this.set("countryCode", country_code || getCountryCode());
		//this.set("countryCode", 'CN');
        
        var lang = voltapi.vconf.getValue(CommonDefines.Vconf.LANGUAGE);
        Volt.log('menu language get by vconf is '+ lang);
        this.set("languageCode", analyzeLanguageCode(lang || "en_US"));
        if (voltapi.util.onLangunageChangedListener) {
            voltapi.util.onLangunageChangedListener(this.onLanguageChanged);
        } else {
            voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.LANGUAGE, this.onLanguageChanged);
        }
        

        var tts = voltapi.vconf.getValue(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS);
        Volt.log('menu tts get by vconf is '+ tts);
        this.set('tts', tts || '');
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS, this.onChangeTTS);

        var highContrast = voltapi.vconf.getValue(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST);
        Volt.log('highContrast get by vconf is '+ highContrast);
        if(highContrast === 0){
            this.set('highContrast', false);
            HALOUtil.highContrast = false;
        } else{
            this.set('highContrast', true);
            HALOUtil.highContrast = true;
        }
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST, this.onChangeHighContrast);
        
        var enlarge = voltapi.vconf.getValue(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_FOCUSZOOM);
        Volt.log('enlarge get by vconf is '+ enlarge);
        if(enlarge === 0){
            this.set('enlarge', false);
            HALOUtil.enlarge = false;
        } else{
            this.set('enlarge', true);
            HALOUtil.enlarge = true;
        }
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_FOCUSZOOM, this.onChangeFcousZoom);
        //set cursor change callback
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE, this.onChangeVisibleCursor);
    },

		/**
     * @description update Info From WAS
     * @function updateInfoFromWAS
     * @memberof DeviceInfoModel
     * @return None
     */
    updateInfoFromWAS : function(){
        Volt.log("begin to get info from WAS");
    
        var self = this;
        if (true == voltapi.WAS.isOpened()){
            Volt.log('WAS is already opened');
            var server_type = voltapi.WAS.getDebugInfo().server_type;
            Volt.log('server tyep from WAS is '+server_type);
            this.set('server_type', server_type);
        }else{
            voltapi.WAS.initAsync(function(is_success){
                Volt.log('WAS initAsync result is '+is_success);
                var server_type = voltapi.WAS.getDebugInfo().server_type;
                Volt.log('server tyep from WAS is '+server_type);
                self.set('server_type', server_type);
            });
        }
    },

	getWaitingScreenAppVisibleConf : function() {
        return voltapi.vconf.getValue(CommonDefines.Vconf.DB_WAITINGSCREENAPP_VISIBLE);
    },

	setWaitingScreenAppVisibleConf : function(flag) {
        voltapi.vconf.setValue(CommonDefines.Vconf.DB_WAITINGSCREENAPP_VISIBLE, flag);
    },

   /**
     * onChangeTTS Callback.
     * @method
     */
    onChangeTTS : function(key, value) {
        Volt.log("[deviceModel.js] onChangeTTS() : " + value);
        self.set('tts', value || '');
    },

     /**
     * onChangeFcousZoom Callback.
     * @method
     */
    onChangeFcousZoom : function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeFcousZoom() : " + value);
        if (value === 1) {
            HALOUtil.enlarge = true;
			self.set('enlarge', true);

        } else {
            HALOUtil.enlarge = false;
			self.set('enlarge', false);
        }
    },
    
    /**
     * onChangeHighContrast Callback.
     * @method
     */
    onChangeHighContrast: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeHighContrast() : " + value);
        if (value === 1) {
            HALOUtil.highContrast = true;
			self.set('highContrast', true);

        } else {
            HALOUtil.highContrast = false;
			self.set('highContrast', false);
        }
        //EventMediator.trigger(CommonDefines.Event.CHANGE_HIGH_CONTRAST);
    },


    getFirmwareFromDevice : function() {
        Volt.log("begin to get info from device");
    
        var self = this;
        var version = '';
        if (true == voltapi.device.isOpened()){
            Volt.log('device is already opened');
            //version = voltapi.device.getSWVersion(0, 1);
            Volt.log('version get from device is '+version);
            this.set('firmware', version || getFirmware());
            self.empReayFlag.device = true;
            self.checkDeviceInfoReady();
        }else{
            voltapi.device.initAsync(function(is_success){
                Volt.log('device initAsync finished, result is '+is_success);
                if (true == is_success){
        		    //version = voltapi.device.getSWVersion(0, 1);
                    Volt.log('version get from device is '+version);
                }
                self.set('firmware', version || getFirmware());
                self.empReayFlag.device = true;
                self.checkDeviceInfoReady();
    	    });
        }
    },

	/**
     * @description listen Network Status
     * @function listenNetworkStatus
     * @memberof DeviceInfoModel
     * @return None
     */
    listenNetworkStatus : function() {
        Volt.log("begin to check network");

        if (true == voltapi.network.isOpened()){
            if (false == voltapi.network.checkNetworkStatus()){
                Volt.log('network is disconnected');
                self.set("networkState", -1);
                Volt.log('self.firstTimeNetworkFailed------------00'+self.firstTimeNetworkFailed);
                
                var MaxFetchTimeoutValue = 40 * 1000;
                self.firstTimeNetworkFailed = true;
                self.firstTimeNetworkTimeout = Volt.setTimeout(function(){
                    self.firstTimeNetworkFailed = false;
                    self.firstTimeNetworkTimeout = null;
                }, MaxFetchTimeoutValue);
            }
            self.empReayFlag.network = true;
            self.checkDeviceInfoReady();
            this.networkSetWatchListener();
        } else {
            voltapi.network.initAsync(function(){
                if (false == voltapi.network.checkNetworkStatus()){
                    Volt.log('network is disconnected');
                    self.set("networkState", -1);
                    
                    var MaxFetchTimeoutValue = 40 * 1000;
                    self.firstTimeNetworkFailed = true;
                    Volt.log('self.firstTimeNetworkFailed------------01'+self.firstTimeNetworkFailed);
                    self.firstTimeNetworkTimeout = Volt.setTimeout(function(){
                        Volt.log('timeout clear ');
                        self.firstTimeNetworkFailed = false;
                        self.firstTimeNetworkTimeout = null;
                    }, MaxFetchTimeoutValue);
                }
                self.empReayFlag.network = true;
                self.checkDeviceInfoReady();
                self.networkSetWatchListener();
            });
        }
    },

		/**
     * @description Set network WatchListener
     * @function networkSetWatchListener
     * @memberof DeviceInfoModel
     * @return None
     */
    networkSetWatchListener : function(networkList) {
        Volt.log('begin to set network listener');
        voltapi.network.networkConnectionListener(function(type){// type 0:cable, 1: wireless, 2: gateway
            Volt.log("network onconnect, type is " + type);
            var bNetworkErr = false;
            if(self.get("networkState") == -1){
                bNetworkErr = true;
            }
            self.set("networkState", 0);
            if(bNetworkErr){
                Volt.log('trigger NETWORK_BAD_TO_GOOD');
                GlobalMediator.trigger(CommonDefines.Event.NETWORK_BAD_TO_GOOD);
            }
            GlobalMediator.trigger(CommonDefines.Event.NETWORK_GOOD);
        },function(type){
            Volt.log("network ondisconnect, type is " + type);
            if (type == 0 && voltapi.network.checkPhysicalConnection(0) > 0) {
                Volt.log("wireless network is still connected");
                return;
            }
            if (type == 1 && voltapi.network.checkPhysicalConnection(1) > 0) {
                Volt.log("cable network is still connected");
                return;
            }
            var bNetworkReady = false;
            if(self.get("networkState") == 0){
                bNetworkReady = true;
            }
            GlobalMediator.trigger(CommonDefines.Event.NETWORK_BAD);
            self.set("networkState", -1);
            if(bNetworkReady){
                GlobalMediator.trigger(CommonDefines.Event.NETWORK_GOOD_TO_BAD);
            }
        });
        //self.empReayFlag.network = true;
        //self.checkDeviceInfoReady();
    },
    
    destroyVoltApi : function() {
        if (voltapi.network.isOpened()){
            Volt.log('voltapi.network.destroy');
            voltapi.network.destroy();
        }
        if (voltapi.device.isOpened()){
            Volt.log('voltapi.device.destroy');
            voltapi.device.destroy();
        }
        if (voltapi.WAS.isOpened()){
            Volt.log('voltapi.WAS.destroy');
            voltapi.WAS.destroy();
        }
    },
    
    onChangeVisibleCursor : function(key, value) {
    	Volt.log("onChangeVisibleCursor() : " + value);
    	//self.set('visibleCursor', value || '');
    	GlobalMediator.trigger(CommonDefines.Event.CHANGE_VISIBLE_CURSOR, value);
    },
    
    onLanguageChanged : function(lang){
        Volt.log('Volt.onLanguageChanged : ' + lang);
        Volt.quit();
        return;
        var candidates = Volt.multilingualWidget;
        
        Volt.i18n.setLng(lang, function(t) {
            self.set("languageCode", lang);
            var length = candidates.length;

            var _ = Volt.require("modules/underscore.js")._;
            _.each(candidates, function(widget){
                try{
                    if (null == widget || undefined == widget)return;
                    var multilingual = widget.custom['multilingual'];
                    if(multilingual.translate){
                        multilingual.translate(widget);
                    }else{
                        if(multilingual.SID){
                            widget.text = t(multilingual.SID, {A : multilingual.replace_value});
                        }
                    }

                }catch(e){
                    Volt.log('Volt.onLanguageChanged : ' + e);
                }
            });
        });
    }
})

var getAToken = function () {
    return "VdFXu65a83meaVhanWLtQFe86V82ARh1+zDhS9hwZfDu5y1Zv3QoAp+Pk1ULtr0CfUJ0LNaeEneXeWHTZJNgSAojRR6mK0wKIx79kMxhryGKB3MNSqSx5x7+RaiD9wsryO26CTBV74wD7KsnkqeV5Aei=SASAT=";
};

var getDUID = function () {
    return "15PreHawk";
};

var getModelId = function () {
	return "14_GOLFP_TIZEN";
};

var getCountryCode = function () {
	return "BR";
};

var getFirmware = function () {
	return "T-GFP9AKUC-1106.4";
};

var getServerType = function () {
	return "SERVERTYPE_DEVELOPMENT";
};

var analyzeLanguageCode = function(vconfMenuLang) {
    Volt.log("Lang: " + vconfMenuLang);
    var languageCode = '';

    var preDefine = {
        'fr_US' : 'fr-US',
        'fr_CA' : 'fr-US',
        'es_US' : 'es-US',
        'es_MX' : 'es-US',
        'pt_US' : 'pt-US',
        'pt_BR' : 'pt-US',
        'en_GB' : 'en-GB',
        'zh_CN' : 'zh-CN',
        'zh_HK' : 'zh-HK',
        'zh_TW' : 'zh-TW'
    };

    var lang = vconfMenuLang.split('.')[0];

    if (preDefine[lang]) {
        languageCode = preDefine[lang];
    } else {
        languageCode = lang.split('_')[0];
    }

    Volt.log("languageCode: " + languageCode);
    return languageCode;
};

exports = new DeviceInfoModel();
