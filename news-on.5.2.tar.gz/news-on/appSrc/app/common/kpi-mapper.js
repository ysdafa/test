var _ = Volt.require("modules/underscore.js")._;
var KPI = Volt.require('lib/volt-kpi.js');
var DeviceModel = Volt.require("app/common/deviceModel.js");
var CommonDefines = Volt.require('app/common/commonDefines.js');

function KPIMapper(){

	var CATEGORY_MAPPER = {
		'H01_HOME' : 'PG001',
		'H02_DETAIL' : 'PG002',
		'H03_DETAIL' : 'PG003',
		'H04_WEATHER' : 'PG004',
		'H05_WEATHER' : 'PG005',

		'SELECTNEWS' : 'EV001',
		'SELECTWEATHER' : 'EV002',
		'SELECTCP' : 'EV003',
		'SETTING' : 'EV005',
		'SELECTRELATEDNEWS' : 'EV006',
		'UPSCROLL' : 'EV007',
		'DOWNSCROLL' : 'EV008',
		'PLAYARTICLEVIDEO' : 'EV009',
        'MOVEPREVIOUS' : 'EV010',
        'MOVENEXT' : 'EV011',
		'WEATHERSETTING' : 'EV012',
		'SAVE' : 'EV013',
		'CANCEL' : 'EV014',
		'EXIT'  : 'EV015',
		'RETURN' : 'EV016'
	};

	this.init = function(){
		KPI.init({
	        serviceName : '15_newson',
	        modelId : DeviceModel.get('modelId'),
	        uid : ' ',
	        duid : DeviceModel.get('duid'),
	        countryCode : DeviceModel.get('countryCode'),
	        version : CommonDefines.Config.app_id + '|' + CommonDefines.Config.app_version,
	        configFallbackPath : 'app/common/LogPolicyConfig.xml',
	        debug : true
	    });
	};

	this.addEventLog = function(eventName, pOptions){
		Volt.log('[kpi-mapper.js]addEventLog - ' + eventName);
		Volt.log('[kpi-mapper.js]addEventLog - ' + JSON.stringify(pOptions));
		var options = pOptions || {};
		options['c'] = CATEGORY_MAPPER[eventName];
		KPI.add(eventName, options);
	};

	var lastPage = null;
	//startPage, endPage
	this.enterPage = function(eventName, pOptions){
		var options = pOptions || {};
		var pageName = eventName;
		var cartegory = CATEGORY_MAPPER[eventName];
		options['c'] = cartegory;

		if(lastPage != null){
			if(lastPage.eventName != eventName){
                var tempOptions = lastPage.options || {};
                tempOptions['d'] = tempOptions['d'] || {};
                if (pOptions['d'] && pOptions['d']['lw']){
                    _.extend(tempOptions['d'], {
                		lw : pOptions['d']['lw']
                	})
                }
				this.leavePage(lastPage.eventName, tempOptions);
			}
            else if (options.hasOwnProperty('id')) {
                if (options['id'] != lastPage.options['id']) {
                    var tempOptions = lastPage.options || {};
                    tempOptions['d'] = tempOptions['d'] || {};
                    if (pOptions['d'] && pOptions['d']['lw']){
                        _.extend(tempOptions['d'], {
                    		lw : pOptions['d']['lw']
                    	})
                    }
                    this.leavePage(lastPage.eventName, tempOptions);
                }
            }
            else{
				Volt.log('[kpi-mapper.js] This page is already entered!' + lastPage.eventName);
				return;
			}
		}

		
		if(lastPage != null){
			options['d'] = {};
			options['d']['pp'] = lastPage.eventName;
			Volt.log('[kpi-mapper.js] Last Page : ' + options.d.pp);
		}

		KPI.startPage(pageName, options);
		lastPage = {eventName : eventName, options : options};
	};

	this.leavePage = function(eventName, pOptions){
		var pageName,
			cartegory,
			options;

		if(eventName){ //target Page
			pageName = eventName;
			options = pOptions || {};
			options['c'] = CATEGORY_MAPPER[eventName];
		}else{ //Last Page
			if(lastPage){
				pageName = lastPage.eventName;
				options = pOptions || {};
				options['c'] = CATEGORY_MAPPER[eventName];
			}
		}

		if(pageName){
            options['d'] = options['d'] || {};
            _.extend(options['d'], {
        		sappid : CommonDefines.Config.app_id,
        		sappver : CommonDefines.Config.app_version
        	});
            delete options['id'];
            KPI.endPage(pageName, options);
			lastPage = null;
		}else{
			Volt.log('[kpi-mapper.js] There is no page event to be leave');
		}
	};

	this.changeUID = function() {
        KPI.changeUID(KPI.getUID());
    };

    this.getCategory = function(eventName){
		return CATEGORY_MAPPER[eventName];
    };

}

exports = new KPIMapper();
