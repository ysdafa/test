/*
* China Server API (News: Sina, Weather: Haufeng)
*/
var _ = Volt.require('modules/underscore.js')._;


/**
 * @description SinaHuafengAPI 
 * @class SinaHuafengAPI
 * 
 * @property {Function} getMainNewsAPI - get Sina MainNews API.
  * @property {Function} getMainWeatherAPI - get Sina MainWeather API
 * @property {Function} getMoreNewsAPI - get Sina MoreNews API
 * @property {Function} getNewsDetailAPI - get Sina News Detail API
 * @property {Function} getWeatherDetailAPI - get Sina Weather Detail API
  * @property {Function} getWeatherCityListAPI - get Sina Weather CityList API
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 */
var SinaHuafengAPI = {
	sAppKey : '?app_key=1204660113',
    sDomainSina : '',
    sDomainHuafeng : '',


    initialize: function(options) {
		var self = this;
        _.each(options.domainlist, function(domainList) {
            if (domainList.categoryid && domainList.categoryid == '100') { // 100: News
                self.sDomainSina = domainList.apidomain;
            } else if (domainList.categoryid && domainList.categoryid == '200') { // 200: Weather
                self.sDomainHuafeng = domainList.apidomain;
            }
        })
    },

    /**
     * @description get sina Main News API
     * @function getMainNewsAPI
     * @memberof SinaHuafengAPI
     * @return {string} return sina Main News API
     */
    getMainNewsAPI : function() {
    	return this.sDomainSina + 'main_news' + this.sAppKey;
    },

	    /**
     * @description get sina Main Weather API
     * @function getMainWeatherAPI
     * @memberof SinaHuafengAPI
     * @param {object} options - options data
     * @return {string} return sina Main Weather API
     */
    getMainWeatherAPI : function(options) {
    	var queryString = options.cid ? '?cid='+options.cid : '';
    	return this.sDomainHuafeng + 'getsamsungmainweather' + queryString;
    },

		    /**
     * @description get sina More Weather API
     * @function getMoreNewsAPI
     * @memberof SinaHuafengAPI
     * @param {object} options - options data
     * @return {string} return sina More Weather API
     */
    getMoreNewsAPI : function(options) {
    	return options.url + '&page=' + options.page;
    },

	/**
     * @description get sina News Detail API
     * @function getNewsDetailAPI
     * @memberof SinaHuafengAPI
     * @param {object} options - options data
     * @return {string} return sina News Detail API
     */
    getNewsDetailAPI : function(options) {
    	return this.sDomainSina + 'news_details' + this.sAppKey + '&url=' + options.url;
    },

	/**
     * @description get sina Weather Detail API
     * @function getWeatherDetailAPI
     * @memberof SinaHuafengAPI
     * @param {object} options - options data
     * @return {string} return sina Weather Detail API
     */
    getWeatherDetailAPI : function(options) {
		var queryString = options.cid ? '?cid=' + options.cid : '';
		print("in sina getWeatherDetailAPI, query is "+queryString);
    	return this.sDomainHuafeng + 'getsamsungdetail' + queryString;
    },

	
	/**
     * @description get sina Weather setting info API
     * @function getWeatherCityListAPI
     * @memberof SinaHuafengAPI
     * @param {object} options - options data
     * @return {string} return sina Weather setting info API
     */
    getWeatherCityListAPI : function() {
    	return this.sDomainHuafeng + 'getsamsungcitylist';
    }

}

exports = SinaHuafengAPI;


