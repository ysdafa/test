
var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._;

var Mediator = function () {
    return _.clone(Backbone.Events);
};

// Experimental. Use GlobalMediator to pass Events between Views.
var GlobalMediator = new Mediator();

exports = GlobalMediator;
