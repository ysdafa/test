var bAPIReady = false;
var _ = Volt.require('modules/underscore.js')._;
var MainNewsModel = Volt.require('app/models/mainNewsModel.js');
var MoreNewsModel = Volt.require('app/models/moreNewsModel.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
//Core Init
var CPAPI = Volt.require('app/common/CPAPI.js');
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var moreNewsPageCount = 0;
var moreNewsMaxPage = 0;
var moreNewsUrl = null;
function isReady() {
    return bAPIReady;
}

function offline() {
    var deferred = Q.defer();
    //disable cache function
    deferred.reject();
    return deferred.promise;
    var localStorage = Volt.require("lib/volt-local-storage.js");
    var DeviceModel = Volt.require('app/common/deviceModel.js');
    
    if(localStorage.getItem('countryCode') !== DeviceModel.get('countryCode'))
    {
        deferred.reject();
        return deferred.promise;
    }
    MainNewsModel.offline().then(function(){
        MoreNewsModel.offline().then(function(){
            GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_READY,true);
            deferred.resolve();
        }).fail(function(){
            deferred.reject();
        })
    }).fail(function(){
        deferred.reject();
    });
    return deferred.promise;
}
function weatherReady(bSolo){
    var deferred = Q.defer();
    if(CPAPI.getServiceType() == 'sina_huafeng') {
        var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
    	var citylist = WeatherSettingModel.get('weatherSettingCodeCityList');
        MainNewsModel.setInitData(CPAPI.getMainWeatherAPI({cid:citylist}), bSolo); //test
        MainNewsModel.fetch().then(function(result){
            deferred.resolve(result);
        });
    }
    return deferred.promise;
}
function ready() {
    var deferred = Q.defer();
    moreNewsPageCount  = 0;
    if(CPAPI.getServiceType() == 'sina_huafeng') {
        weatherReady(false).then(function(result){
            if(result){
                 MainNewsModel.setInitData(CPAPI.getMainNewsAPI());
                 MainNewsModel.fetch().then(function(result) {
                    if(result) {
                        var url = MainNewsModel.get('more_news_url');
                        moreNewsUrl = _.clone(url); //copy a url
                        Volt.log('first time get moreNewsUrl------'+moreNewsUrl);
                        var pageIdx = moreNewsPageCount;
                        var options = {'pageIdx':pageIdx,'more_news_url':url};
                        MoreNewsModel.setInitData(options);
                        MoreNewsModel.fetch().then(function(result) {
                            if(result) {
                                moreNewsPageCount++;
                                moreNewsMaxPage = parseInt(MoreNewsModel.get('number_of_page')); // update moreNewsMaxPage
                                var url = MainNewsModel.get('more_news_url');
                                var pageIdx = moreNewsPageCount;
                                var options = {'pageIdx':pageIdx,'more_news_url':url};
                                MoreNewsModel.setInitData(options);
                                MoreNewsModel.fetch().then(function(result) {
                                    if(result) {
                                        moreNewsPageCount++;
                                        //GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_READY,false);
                                        var url = MainNewsModel.get('more_news_url');
                                        var pageIdx = moreNewsPageCount;
                                        var options = {'pageIdx':pageIdx,'more_news_url':url};
                                        MoreNewsModel.setInitData(options);
                                        MoreNewsModel.fetch().then(function(result) {
                                            if(result){
                                                moreNewsPageCount++;
                                                GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_READY,false);
                                            }else{
                                                GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
                                            }
											deferred.resolve(result);
                                        });
                                    }else {
                                        GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
										deferred.resolve(result);
                                    }
                                    //deferred.resolve(result);
                                });
                            }else {
                                deferred.resolve(result);
                                GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
                            }
                        });
                    } else {
                        deferred.resolve(result);
                        GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
                    }
                });
            } else {
               deferred.resolve(result);
               GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
            }
        });
    } else {
        MainNewsModel.setInitData(CPAPI.getMainNewsAPI());
        MainNewsModel.fetch().then(function(result) {
            if(result) {
                var url = MainNewsModel.get('more_news_url');
                var pageIdx = 1;
                var options = {'pageIdx':pageIdx,'more_news_url':url};
                MoreNewsModel.setInitData(options);
                MoreNewsModel.fetch().then(function(result){
                    if(result) {
                        GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_READY,false);
                    } else {
                        GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
                    }
                    deferred.resolve(result);
                });
            } else {
                deferred.resolve(result);
                GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
            }
        });
    }

    return deferred.promise;
}

function getMoreNews()
{
    var deferred = Q.defer();
    Volt.log('moreNewsPageCount----'+moreNewsPageCount);
    Volt.log('moreNewsMaxPage----'+moreNewsMaxPage);
    if(moreNewsPageCount >= moreNewsMaxPage) {
        deferred.reject();
        return deferred.promise;
    }
    Volt.log('getMoreNews----url-------'+moreNewsUrl);
    var pageIdx = moreNewsPageCount;
    var options = {'pageIdx':pageIdx, 'more_news_url':moreNewsUrl};
    MoreNewsModel.setInitData(options);
    MoreNewsModel.fetch().then(function(result) {
        if(result){
            moreNewsPageCount++;
            var pageIdx = moreNewsPageCount;
            var options = {'pageIdx':pageIdx, 'more_news_url':moreNewsUrl};
            MoreNewsModel.setInitData(options);
            MoreNewsModel.fetch().then(function(result){
                if(result){
                    moreNewsPageCount++;
                    deferred.resolve();
                }else{
                    deferred.reject();
                }
            });
        } else {
            deferred.reject();
        }
    });
    return deferred.promise;
}

function bGetMoreNewsPage(){
    if(moreNewsPageCount == moreNewsMaxPage){
        return false;
    }else{
        return true;
    }
}

function onAPIReady(result) {
	/*
    if (result) {
        Volt.log('API is ready - ' + result);
        bAPIReady = true;
        initialize();
    }*/
}

function initialize() {
	/*
    Volt.log('initialize');
    LocalDB.setResource()
        .then(function(){
            // Request team data
            homeNewsCollection.fetch({reset: true});
        }).fail(function(){});
		*/
}

exports = {
    ready: ready,
    isReady: isReady,
    offline : offline,
    weatherReady : weatherReady,
    getMoreNews : getMoreNews,
    bGetMoreNewsPage : bGetMoreNewsPage,
};