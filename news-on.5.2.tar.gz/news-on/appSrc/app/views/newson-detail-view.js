/**
 * @author  Yipeng Zhu (yipeng.zhu@samsung.com)
 * @fileoverview Description of a file
 * @date    2014/07/04 (last modified date)
 *
 * Copyright 2012 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Include libraries
var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require('modules/VoltJSON.js');
var CPAPI = Volt.require('app/common/CPAPI.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var BaseView = PanelCommon.BaseView;
var Q = PanelCommon.Q;
var voltapi = Volt.require('voltapi.js');

// Include models
var NewsDetailModel = Volt.require('app/models/newsDetailModel.js');
var MainNewsModel = Volt.require('app/models/mainNewsModel.js');
var MoreNewsModel = Volt.require('app/models/moreNewsModel.js');
var newsCollection = null;//MainNewsModel.get('pageModel').get('tileCollection');

// Include example templates(should implement by apps panel member)
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');
var NewsonMainDetailTemplate = Volt.requireAppTemplate('newson-main-detail-template.js');
var DetailThumbTemplate = Volt.requireAppTemplate('newson-detail-thumb-template.js');
var DetailTextTemplate = Volt.requireAppTemplate('newson-detail-text-template.js');
//var DetailVideoTemplate = Volt.requireAppTemplate('newson-detail-video-template.js');
var NewsonDetailTemplate = Volt.requireAppTemplate('newson-detail-template.js');
//Include newson common templates
var NewsOnDetailCommonTemplate = Volt.requireTemplate('newson-detail');

var DeviceModel = Volt.require('app/common/deviceModel.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');

var LoadingDialog = Volt.require('app/views/loading-view.js');
var WinsetScroll = Volt.require("WinsetUIElement/winsetScroll.js");
//Require dim view
var dimView = PanelCommon.requireView('dim');
//Require customization
var customizationIcon = Volt.require('app/common/customization-icon.js');
var ToolTip = Volt.require('app/views/tooltip-view.js');

//KPI start
var KPI = Volt.require('app/common/kpi-options.js');
var KPIOptions = KPI.NewsDetail;
//KPI end

//define list item attribute
var detailViewSelf = null;

var Global = Volt.require('app/common/Global.js');
//Require GlobalMediator
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
var ScrollBar = Volt.require('app/common/ScrollBar.js');
PanelCommon.mapWidget('ScrollBar', ScrollBar);
//var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetButton = Volt.require('WinsetUIElement/winsetButton.js');
PanelCommon.mapWidget('WinsetButton', WinsetButton);

var relatedItemViewSelf = null;

/** News Detail View -BackboneView
* @class 
* @name DetailView
* @augments Backbone.View
*/
var DetailView = BaseView.extend({
        isFresh : true,
        /**
         * This property represents the default template in DetailView.
         * @name template
         * @type JSON
         * @default NewsOnDetailCommonTemplate.container
         * @fieldOf DetailView.prototype
         */
		template : NewsOnDetailCommonTemplate.container,
        
        /**
         * This property represents the parameter passed from other view.
         * @name options
         * @type JSON
         * @default null
         * @fieldOf DetailView.prototype
         */
		options : null,
        
         /**
         * This property represents the news' map on the news collection.
         * @name map
         * @type Array
         * @default []
         * @fieldOf DetailView.prototype
         */
		map : [],
        
        /**
         * This property represents the detail news' model.
         * @name newsDetailModel
         * @type JSON
         * @default null
         * @fieldOf DetailView.prototype
         */
		newsDetailModel : null,
        
        /**
         * This property represents the child view's reference in DetailView.
         * @name titleView
         * @type Class
         * @default null
         * @fieldOf DetailView.prototype
         */
		titleView : null,
        
        /**
         * This property represents the child view's reference in DetailView.
         * @name contentView
         * @type Class
         * @default null
         * @fieldOf DetailView.prototype
         */
		contentView : null,
        
        /**
         * This property represents the child view's reference in DetailView.
         * @name relatedView
         * @type Class
         * @default null
         * @fieldOf DetailView.prototype
         */
		relatedView : null,
        
        /**
         * This property represents detail news model request status.
         * @name status
         * @type string
         * @default success
         * @fieldOf DetailView.prototype
         */
		status : 'success',
        sceneColorMgr : [],
        urlCacheMgr : [],
        tileCollection : null,
        lastFocus : null,
        /** Initialize DetailView. 
        * @function initialize
        * @memberof DetailView
        */
		initialize : function () {
			this.newsDetailModel = NewsDetailModel;
			this.loadingDialog = LoadingDialog;
            this.tileCollection = new Backbone.Collection();
            detailViewSelf = this;
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('detail view initialize');
                print(VDUtil.getProcMemory());
            }
		},
        
        /** render DetailView. 
        * @function render
        * @memberof DetailView
        */
		render : function () {
        
           
			this.setWidget(PanelCommon.loadTemplate(this.template)); //load newson detail view(include titile-area,content-area and related area)
            this.widget.hide();
			this.renderTitle();
			this.renderContent();
			this.renderRelated();
			this.renderReturnButton();
            this.renderCloseButton();
		},
		
        /** callback of detail view's model if the detail view model fetch error. 
        * @function show
        * @param {Object}  object                  	- the http request object
        * @param {string}  status          		- show the http request's status
        * @param {string}  exception                  	- pass the exception
        * @memberof DetailView
        */
		errorHappened : function (object, status, exception) {
		    Volt.log('errorHandle');
			this.loadingDialog.hide();
			var ErrorHandler = Volt.require('app/common/errorHandler.js');
            var errorCode = object?object.status : CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE;
            ErrorHandler.handleNetworkError(errorCode,this.returnFun);
		},		

		returnFun : function() {
			detailViewSelf.widget.hide();
			Backbone.history.location.history.length = 0;
            detailViewSelf.sceneColorMgr.length = 0;
            detailViewSelf.sceneColorMgr = [];
            detailViewSelf.urlCacheMgr.length = 0;
            detailViewSelf.urlCacheMgr = [];
            Global.LeaveWayForKPILog.set('ERROR');
			Backbone.history.navigate('home', {
						trigger : true
					});
		},
		
        /** show the detail view 
        * @function show
        * @param {JSON}  options                  	- the parameter
        * @param {string}  animationType          		-animation type
        * @memberof DetailView
        */
		show : function (options, animationType) {
			var deferred = Q.defer();
            this.isFresh = true;
            
			if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
	            this.returnButton.hide();
                this.closeButton.hide();
	        } else {
	            this.returnButton.show();
                this.closeButton.show();
	        }

	        this.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
	        
			this.loadingDialog.show(1);
			this.options = options;
            //scene color mgr
            //first time should save scene color
            if(this.sceneColorMgr.length === 0) {// from main view into detail
                var color = Volt.WinsetRoot.getBackgroundColor();
                this.sceneColorMgr.push({r:color.r, g:color.g, b:color.b});
            }
            if(this.options.focus != '<-1>') {
                if(this.sceneColorMgr.length > 1) {
                    this.sceneColorMgr.pop();
                    if(!DeviceModel.getHighContrast()){
                        Volt.WinsetRoot.color = this.sceneColorMgr[this.sceneColorMgr.length - 1];
                    }
                    Volt.WinsetRoot.setBackgroundColor(this.sceneColorMgr[this.sceneColorMgr.length - 1]);
                    //scene.color = this.sceneColorMgr[this.sceneColorMgr.length - 1];
                }
                if(this.urlCacheMgr.length > 1)
                    this.urlCacheMgr.pop();
            }
            //end scene color mgr
            
            this.tileCollection.reset();
            for(var i = 0; i < MainNewsModel.get('pageModel').get('tileCollection').length; i++)
            {
                this.tileCollection.add(MainNewsModel.get('pageModel').get('tileCollection').at(i));
            }
            
            for(var i = 0; i < MoreNewsModel.get('pageCollection').length; i++)
            {
                var pageModel = MoreNewsModel.get('pageCollection').at(i);
                for(var j = 0; j < pageModel.get('tileCollection').length;j++)
                {
                    this.tileCollection.add(pageModel.get('tileCollection').at(j));
                }
            }
            var iCount = 0;
			for (var i = 0; i < this.tileCollection.length; i++) {
				if (this.tileCollection.at(i).get('tile_type') == 'news') {
					this.map[iCount] = i;
					iCount++;
				}
			}
            this.model = null;
            if(this.urlCacheMgr.length === 0) {
                for(var i = 0; i < this.tileCollection.length;i++){
                    if(this.tileCollection.at(i).id === options.id){
                        this.model = this.tileCollection.at(i);
                        print('found the tile model-------------------');
                        break;
                    }
                }
                this.urlCacheMgr.push(this.model.get('detail_url'));
            }
			this.listenTo(this.newsDetailModel, 'error', this.errorHappened);
			this.listenTo(this.newsDetailModel, 'complete', this.showDetail);
			var url = null;
            
            url = this.urlCacheMgr[this.urlCacheMgr.length - 1];
            print('this.urlCacheMgr.length-------------------------'+this.urlCacheMgr.length);
            this.newsDetailModel.setInitData({
                'url' : url
            });
            detailViewSelf.newsDetailModel.fetch({}).then(function () {});
			deferred.resolve();
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('detail view show');
                print(VDUtil.getProcMemory());
            }
            this.listenTo(DeviceModel, 'change:languageCode', this.updateTextbyLang);
			return deferred.promise;
		},

        updateTextbyLang : function(){
            titleViewSelf.updateTextbyLang();
            contentViewSelf.updateTextbyLang();
            relatedItemViewSelf.updateTextbyLang();
        },

		
		/** hide the detail view 
        * @function hide
        * @param {JSON}  options                  	- the parameter
        * @param {string}  animationType          		-animation type
        * @memberof DetailView
        */
		hide : function (options, animationType) {
			var deferred = Q.defer();
			this.stopListening();
			this.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
			this.newsDetailModel.clear();
            this.contentView.hide();
            this.relatedView.hide();
			this.widget.hide();
            //scene color mgr
            if(Backbone.history.location.history.length === 1)
            {
                this.sceneColorMgr.length = 0;//clear scene color mgr stack
                this.sceneColorMgr = [];
                this.urlCacheMgr.length = 0;
                this.urlCacheMgr = [];
            }
            //end of scene color mgr
            
			this.loadingDialog.hide();
            if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
            {
                print('detail view hide');
                gc();
                print(VDUtil.getProcMemory());
            }
			deferred.resolve();
			return deferred.promise;
		},
		
		update : function(options, animationType){
			this.hide(options, animationType);
			this.show(options, animationType);
		},
        
        /** show the detail content callback
        * @function showDetail
        * @memberof DetailView
        */
		showDetail : function (object, status) {
			Volt.log('showDetail');
			if (status != 'success')
            {
            	Volt.log('status is not success');
				this.loadingDialog.hide();
				this.errorHappened();
                return; // for error handler extension
            }
            if(!this.newsDetailModel.isValid()){
                Volt.log(this.newsDetailModel.validationError);
                this.loadingDialog.hide();
				this.errorHappened();
                return;
            }
            //clear the last focus
            Volt.Nav.setRoot(this.widget,{focus:null});
			this.titleView.show();
			this.contentView.show();
			//this.renderRelated();
            if(this.newsDetailModel.relatedTileCollection.length > 0) {
                Volt.log('this.newsDetailModel.relatedTileCollection.length'+this.newsDetailModel.relatedTileCollection.length);
                this.relatedView.show(this.options, this.newsDetailModel.relatedTileCollection);
            }
            else {
                Volt.log('related else');
                this.relatedView.show(this.options);
            }
            //Volt.Nav.setRoot(this.widget, {focus:this.relatedView.widget});
            this.widget.show();
            Volt.setTimeout(function(){
                detailViewSelf.loadingDialog.hide();
            },30);
            
		},
		
        /** render title view 
        * @function renderTitle
        * @memberof DetailView
        */
		renderTitle : function () {
			var container = this.widget.getDescendant('detail-title-area');
			if (container && container.addChild) {
				this.titleView = new TitleView(this.newsDetailModel);
				container.addChild(this.titleView.render().widget);
			}
		},
		
        /** render content view 
        * @function renderContent
        * @memberof DetailView
        */
		renderContent : function () {
			var container = this.widget.getDescendant('detail-content-area');
			if (container && container.addChild) {
				this.contentView = new ContentView(this.newsDetailModel);
				container.addChild(this.contentView.render().widget);
			}
		},
		
        /** render related view 
        * @function renderRelated
        * @memberof DetailView
        */
		renderRelated : function () {
			var container = this.widget.getDescendant('detail-relate-area');
			if (container && container.addChild) {
				this.relatedView = new RelatedItemView(this.map);
				container.addChild(this.relatedView.render(container).widget, 0);
			}
		},
		
		/**
	     * @description Render the return button.
	     * @function renderReturnButton
	     * @memberof DetailView
	     * @return None
	     */
	    renderReturnButton : function() {
	        this.returnButton = this.widget.getDescendant('newson-news-detail-return-button');
	        customizationIcon(this.returnButton, {
	            imageStyle : 'pageReturn'
	        });
	        this.returnButton.onMouseOver = function(){
	            var opt = {
        			text: Volt.i18n.t('COM_SID_RETURN'),
        			x: this.returnButton.x,
        			y: this.returnButton.y,
        			width: this.returnButton.width,
        			height: this.returnButton.height,
        			direction:'up',
        			parent: this.returnButton
        		};
        		
        		ToolTip.show(opt, CommonTemplate.tooltip);
                return true;
	        }.bind(this);
            this.returnButton.onMouseOut = function(){
                ToolTip.hide();
                return true;
            };
	        this.returnButton.onMouseClick = function(){
                ToolTip.hide();
                //KPI log start
                //record RETURN kpi event log
                var kpiReturn = new KPI.Common.Return();
                kpiReturn.send({cp : 'H02_DETAIL', rw : 'POINTING_RETURN'});
                //kpi log end
                //kpi log start
                Global.LeaveWayForKPILog.set('POINTING_RETURN');
                //kpi log end
                //voice start
				TTS.stop();
				//voice end
	            Backbone.history.back();
	        };
	    },
        
        /**
	     * @description Render the close button.
	     * @function renderCloseButton
	     * @memberof DetailView
	     * @return None
	     */
        renderCloseButton : function() {
	        this.closeButton = this.widget.getDescendant('newson-news-detail-close-button');
	        customizationIcon(this.closeButton, {
	            imageStyle : 'pageClose'
	        });
	        this.closeButton.onMouseClick = function(){
                ToolTip.hide();
	            //Volt.exit();
                //kpi log start
                Global.ExitWayForKPILog.set('POINTING_X');
                Global.LeaveWayForKPILog.set('POINTING_X');
                Global.LeaveByReturnForKPILog.set(true);
                //kpi log end
                //voice start
				TTS.stop();
				//voice end
                Volt.exit();
	        };
	        this.closeButton.onMouseOver = function(){
	            var opt = {
        			text: Volt.i18n.t('COM_SID_EXIT'),
        			x: this.closeButton.x,
        			y: this.closeButton.y,
        			width: this.closeButton.width,
        			height: this.closeButton.height,
        			direction:'up',
        			parent: this.closeButton
        		};
        		
        		ToolTip.show(opt, CommonTemplate.tooltip);
                return true;
	        }.bind(this);
            this.closeButton.onMouseOut = function(){
                ToolTip.hide();
                return true;
            };
	    },
        
	    /** pause the main view Invoked when some popup view popup over this View
        * @function onChangeCursor
        * @memberof DetailView
        */
	    onChangeCursor : function(visible){
	        if( this.returnButton){
	            if(visible){
	                this.returnButton.show();
	            }else{
	                this.returnButton.hide();
	            }
	        }
            if(this.closeButton){
                if(visible){
					Volt.log("show close button");
                    //this.widget.removeChild(this.closeButton);
                    //this.widget.addChild(this.closeButton);
			//		Volt.log("close Button  x is :"+ this.closeButton.x);					
	                this.closeButton.show();
					//this.closeButton.raise();
	            }else{
	            	Volt.log("hide close button");
	                this.closeButton.hide();
	            }
	        }

			if(detailViewSelf.lastFocus){
				if(detailViewSelf.lastFocus.id == 'single_line_list_id'){
					if(relatedItemViewSelf) {
						Volt.log('showEnlargeText');
						relatedItemViewSelf.showEnlargeText();
					}
				}
			}

			
	    },
        /**
         * pause the main view Invoked when some popup view popup over this View
         * @function
         * @memberof MainView
         */
        pause : function() {
            Volt.log();

            dimView.show({
                parent: Volt.WinsetRoot
            });
        },

        /**
         * Invoked when come back from popup
         * @function
         * @memberof MainView
         */
        resume : function() {
            Volt.log();
            dimView.hide();
            if(this.lastFocus)
            {
                Volt.Nav.focus(this.lastFocus);
            }
        }
	});

var titleViewSelf = null;
//template of title area

/** TitleView -BackboneView
* @class 
* @name TitleView
* @augments Backbone.View
*/
var TitleView = BaseView.extend({

        /**
        * This property represents the template type.text,thumb,or video.
        * @name template_type
        * @type string
        * @default null
        * @fieldOf TitleView.prototype
        */
		template_type : null,
        
        /**
        * This property represents the text template container
        * @name text_container
        * @type Widget
        * @default null
        * @fieldOf TitleView.prototype
        */
        text_container : null,
        
        /**
        * This property represents the thumb template container
        * @name thumb_contaner
        * @type Widget
        * @default null
        * @fieldOf TitleView.prototype
        */
		thumb_contaner : null,
        
        /** Initialize TitleView. 
        * @function initialize
        * @memberof TitleView
        */
		initialize : function (model) {
			this.model = model;
            titleViewSelf = this;
		},
		
        /** render TitleView. 
        * @function render
        * @memberof TitleView
        */
		render : function () {

            var container = new WidgetEx();
			
			this.text_container = PanelCommon.loadTemplate(DetailTextTemplate.container);
			this.thumb_contaner = PanelCommon.loadTemplate(DetailThumbTemplate.container);
            
			container.addChild(this.text_container);
			container.addChild(this.thumb_contaner);
			this.setWidget(container);
            this.thumbTitleInfoWithoutThumbWidth = this.thumb_contaner.width;

            this.thumbLineWidth = this.widget.getDescendant('thumb_linewidth');
			this.thumbLineWidth.show();
            this.thumbLineHeight = this.widget.getDescendant('thumb_lineheight');
			this.thumbLineHeight.show();
			
            this.thumbTitleInfoWithThumbWidth = this.widget.getDescendant('thumb_title_info').width;
            this.thumbTitleInfoWithThumbX = this.widget.getDescendant('thumb_title_info').x;
            this.thumbTitleInfoChildWithThumbX = this.widget.getDescendant('thumb_headline').x;
            this.thumbTitleInfoChildWithoutThumbX = this.widget.getDescendant('text_headline').x;
            var thumbnail = titleViewSelf.widget.getDescendant('thumb_thumbnail');
            var thumbListener = new ThumbnailListener;
            thumbListener.onImageReady = function (thumbnail, id, success) {
                var thumbTitleInfo = titleViewSelf.widget.getDescendant('thumb_title_info');
                var thumbnail = titleViewSelf.widget.getDescendant('thumb_thumbnail');
                var headline = thumbTitleInfo.getChild('thumb_headline');
                var thumbSourceIcon = titleViewSelf.widget.getDescendant('thumb_source_icon');
                var thumbSourceContainer = titleViewSelf.widget.getDescendant('thumb_source_container');

	            var thumbLineWidth = titleViewSelf.widget.getDescendant('thumb_linewidth');
				thumbLineWidth.hide();
	            var thumbLineHeight = titleViewSelf.widget.getDescendant('thumb_lineheight');
				thumbLineHeight.hide();

				
                print('===================onImageReady'+success);
                if(!success)
                {
                    thumbTitleInfo.x = 0;
                    thumbTitleInfo.width = titleViewSelf.thumbTitleInfoWithoutThumbWidth;
                    headline.x = titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                    headline.width = titleViewSelf.thumbTitleInfoWithoutThumbWidth - 2 * titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                    thumbSourceIcon.x = titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                    thumbSourceContainer.x = titleViewSelf.thumbTitleInfoChildWithoutThumbX;
                    if(thumbnail.parent)
                        thumbnail.parent.hide();
                }
                else
                {
                    thumbTitleInfo.x = titleViewSelf.thumbTitleInfoWithThumbX;
                    thumbTitleInfo.width = titleViewSelf.thumbTitleInfoWithThumbWidth;
                    headline.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                    headline.width = titleViewSelf.thumbTitleInfoWithThumbWidth - 2 * headline.x;
                    thumbSourceIcon.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                    thumbSourceContainer.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                    thumbnail.show();
                }
            }
            thumbnail.addThumbnailListener(thumbListener);	
			this.text_container.hide();
			this.thumb_contaner.hide();
			this.widget.hide();
			return this;
		},
		
        /** show the title view 
        * @function show
        * @memberof TitleView
        */
		show : function () {
            if (this.model.get('img_url') == null || this.model.get('img_url').length == 0) {
				this.template_type = 'text';
				this.thumb_contaner.hide();
				this.text_container.show();
				
			} else {
				this.template_type = 'thumb';
				this.text_container.hide();
                
                //add for a situation that the thumbnail load failed,the thumbnail coordination need initialize
                //add by yipeng.zhu @2015,01,29
                var thumbTitleInfo = titleViewSelf.widget.getDescendant('thumb_title_info');
                var thumbnail = titleViewSelf.widget.getDescendant('thumb_thumbnail');
                var headline = thumbTitleInfo.getChild('thumb_headline');
                var thumbSourceIcon = titleViewSelf.widget.getDescendant('thumb_source_icon');
                var thumbSourceContainer = titleViewSelf.widget.getDescendant('thumb_source_container');
                thumbTitleInfo.x = titleViewSelf.thumbTitleInfoWithThumbX;
                thumbTitleInfo.width = titleViewSelf.thumbTitleInfoWithThumbWidth;
                headline.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                headline.width = titleViewSelf.thumbTitleInfoWithThumbWidth - 2 * headline.x;
                thumbSourceIcon.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                thumbSourceContainer.x = titleViewSelf.thumbTitleInfoChildWithThumbX;
                //end of add
                
	            var thumbLineWidth = titleViewSelf.widget.getDescendant('thumb_linewidth');
				thumbLineWidth.show();
	            var thumbLineHeight = titleViewSelf.widget.getDescendant('thumb_lineheight');
				thumbLineHeight.show();

                
				this.thumb_contaner.show();
			}
            
            var thumbnail = this.widget.getDescendant(this.template_type + '_thumbnail');
			if (thumbnail) {
                if(thumbnail.parent)
                    thumbnail.parent.show();
                thumbnail.hide();
				thumbnail.setContentImage(this.model.get('img_url')); //load src maybe failed
				thumbnail.loadImageSource();
			}
            /*
            var utility = new Utility;
            var extractColor = utility.extractForegroundColor(scene.color.r, scene.color.g, scene.color.b);
            var color = {r:extractColor.color.r, g:extractColor.color.g, b:extractColor.color.b};
            */
            var headline = this.widget.getDescendant(this.template_type + '_headline');
			if (headline && headline.text !== undefined) {
				headline.text = this.model.get('title')+'';
			}
            //headline.textColor = color;
            var source_icon = this.widget.getDescendant(this.template_type + '_source_icon');
			if (source_icon) {
				var testImage = new ImageWidgetEx({
					src:this.model.get('source_icon')+'',
					onReady :function(flag) {
						var width = testImage.width;
						var height = testImage.height;
						Volt.log('width:'+width+'height:'+height);
						if(height > 30){
							source_icon.height = 30;
							source_icon.width = width*30/height;
						} else{
							source_icon.height = height;
							source_icon.width = width;
						}
						source_icon.show();
					}
				});
				
				source_icon.hide();
				Volt.log('source_icon:'+this.model.get('source_icon'));
				source_icon.src = this.model.get('source_icon')+'';
			}
            
            var source = this.widget.getDescendant(this.template_type + '_source');
			if (source && source.text !== undefined && this.model.get('source') !== undefined) {
				source.text = this.model.get('source');//this.model.get('source');
			}
            
            
            var colorDrawing01 = this.widget.getDescendant(this.template_type + '_color_drawing01');
            if(colorDrawing01 && source)
            {
                colorDrawing01.x = source.x + source.width + NewsonDetailTemplate.constNum.infoSpace;
            }
            var pressTime = this.widget.getDescendant(this.template_type + '_press_time');
			if (pressTime && pressTime.text !== undefined && colorDrawing01) {
				pressTime.text = this.model.get('stringstamp');//this.model.get('source');
                pressTime.x = colorDrawing01.x + colorDrawing01.width + NewsonDetailTemplate.constNum.infoSpace;
			}
            var colorDrawing02 = this.widget.getDescendant(this.template_type + '_color_drawing02');
            if(colorDrawing02 && pressTime)
            {
                colorDrawing02.x = pressTime.x + pressTime.width + NewsonDetailTemplate.constNum.infoSpace;
            }
            var timestamp = this.widget.getDescendant(this.template_type + '_timestamp');
			if (timestamp && timestamp.text !== undefined && colorDrawing02) {
				timestamp.text = this.model.get('timestatus');//this.model.get('source');
                timestamp.x = colorDrawing02.x + colorDrawing02.width + NewsonDetailTemplate.constNum.infoSpace;
			}
			this.widget.show();
		},

        updateTextbyLang : function(){
            //update updated date
            Global.DateMultiLang.init();
            var pressTime = this.widget.getDescendant(this.template_type + '_press_time');
			if (pressTime && pressTime.text) {
                pressTime.text = Global.formatTime(parseInt(this.model.get('timestamp')));
			}

            //update hours
            var timestamp = this.widget.getDescendant(this.template_type + '_timestamp');
			if (timestamp && timestamp.text) {
				timestamp.text = Global.getOccurStamp(this.model.get('now_utc_timestamp'), this.model.get('timestamp'));
            }
        },

        /** hide the title view 
        * @function hide
        * @memberof TitleView
        */
		hide : function () {
			var deferred = Q.defer();
			this.widget.hide();
			deferred.resolve();
			return deferred.promise;
		},
	});

var contentViewSelf = null;
//template of content area

/** ContentView -BackboneView
* @class 
* @name ContentView
* @augments Backbone.View
*/
var ContentView = BaseView.extend({
    readArticle : null,
    voice_timer_id : null, 
    /**
        * This property represents the default template in ContentView.
        * @name template
        * @type JSON
        * @default NewsOnDetailCommonTemplate.DetailContentArea
        * @fieldOf ContentView.prototype
        */
        template : NewsOnDetailCommonTemplate.DetailContentArea,
        
        /** Initialize content view. 
        * @function initialize
        * @memberof ContentView
        */
		initialize : function (model) {
			this.model = model;
            contentViewSelf = this;
		},

        switchVoiceOrNormal : function(){
            Volt.log();
            if (1 == DeviceModel.getMenuTTS()){
                contentViewSelf.detailContentSwap[0].y = 0;
                contentViewSelf.detailContentSwap[1].y = 0;
                contentViewSelf.scrollIndex = 0;
                if(contentViewSelf.pageHeightMgr.length > 0){
                    contentViewSelf.widget.getDescendant('contentArea').height = contentViewSelf.pageHeightMgr[0];
                }
                var scrollBar = contentViewSelf.widget.getDescendant('detail_scroll_bar');
                scrollBar.setCount(contentViewSelf.scrollTotal);
                contentViewSelf.disableArticleScroll();
                contentViewSelf.widget.getDescendant('read_article').custom.focusable = true;
                contentViewSelf.widget.getDescendant('read_article').enable(true);
                contentViewSelf.widget.getDescendant('read_article').show();
                if (detailViewSelf.lastFocus != detailViewSelf.relatedView.widget){
                    detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('read_article');
                    Volt.Nav.setLastFocus(detailViewSelf.lastFocus);
                }
            } else {
                contentViewSelf.widget.getDescendant('read_article').hide();
                contentViewSelf.widget.getDescendant('read_article').custom.focusable = false;
                contentViewSelf.widget.getDescendant('read_article').enable(false);
                contentViewSelf.widget.getDescendant('artical_up').show();
                contentViewSelf.widget.getDescendant('artical_down').show();
                if (contentViewSelf.pageHeightMgr.length > 1){
                    contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                }
                if (contentViewSelf.widget.getDescendant('read_article') == detailViewSelf.lastFocus){
                    if (contentViewSelf.pageHeightMgr.length > 1){
                        detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('artical_down');
                        Volt.Nav.setLastFocus(detailViewSelf.lastFocus);
                    }else{
                        detailViewSelf.lastFocus = detailViewSelf.relatedView.widget;
                        Volt.Nav.setLastFocus(detailViewSelf.lastFocus);
                    }
                }
                
            }
            Volt.Nav.reload();
            //Volt.Nav.focus(contentViewSelf.lastFocus);
        },

        updateTextbyLang : function(){
            if (this.readArticle){
                this.readArticle.setText({state:'all', text:Volt.i18n.t('TV_SID_READ_ARTICLE')});
            }
        },
        
        /** render content view. 
        * @function render
        * @memberof ContentView
        */
        render : function () {
            this.setWidget(PanelCommon.loadTemplate(this.template));
            var articalUp = null,articalDown = null;
            articalUp = this.widget.getDescendant('artical_up');
            articalDown = this.widget.getDescendant('artical_down');
            Volt.Nav.setNextItemRule(articalDown,"up",articalDown);
            Volt.log('setIconScaleFactor-----');
            articalUp.setIconScaleFactor({
                state: "focused-roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });
            articalUp.setIconScaleFactor({
                state: "roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });

            articalDown.setIconScaleFactor({
                state: "focused-roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });
            articalDown.setIconScaleFactor({
                state: "roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });
            
            articalUp.onKeyEvent  = this.onKeyEvent.bind(this);
            articalDown.onKeyEvent  = this.onKeyEvent.bind(this);
            var buttonListener = new ButtonListener();
            buttonListener.onButtonClicked = function(Button, type) {
                print('detail button clicked'+Button.id);
                if(contentViewSelf !== null && (Button.id === 'artical_down' || Button.id === 'artical_up'))
                {
                    print('detail button clicked');
                    contentViewSelf.onSelect(Button);
                }
            };//.bind(this);
            this.widget.getDescendant('artical_down').addListener(buttonListener);
            this.widget.getDescendant('artical_up').addListener(buttonListener);

            var focusListener1 = new FocusListener();
            focusListener1.onFocusIn = function(){
                if (0 == DeviceModel.getMenuTTS()){
                    detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('artical_down');
                }
            };
            this.widget.getDescendant('artical_down').addFocusListener(focusListener1);
            var focusListener2 = new FocusListener();
            focusListener2.onFocusIn = function(){
                if (0 == DeviceModel.getMenuTTS()){
                    detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('artical_up');
                }
            };
            this.widget.getDescendant('artical_up').addFocusListener(focusListener2);
            
            this.widget.hide();

            //render read article button
            this.renderReadArticleButton();
            //KPI start
            this.KPIUpScroll = new KPIOptions.UpScroll(this);
            this.KPIDownScroll = new KPIOptions.DownScroll(this);
            //KPI end

            return this;
        },

        disableArticleScroll : function () {
            this.disableButton(this.widget.getDescendant('artical_up'));
            this.disableButton(this.widget.getDescendant('artical_down'));
            this.widget.getDescendant('artical_up').hide();
            this.widget.getDescendant('artical_down').hide();
            //Volt.Nav.reload();
        },

        renderReadArticleButton : function () {
            this.readArticle = this.widget.getDescendant('read_article');
            Volt.Nav.setNextItemRule(this.readArticle,"up",this.readArticle);

            this.readArticle.onKeyEvent  = function(keycode, keytype){
                if (keycode == Volt.KEY_RETURN && keytype == Volt.EVENT_KEY_PRESS) {
    				//voice start
    				TTS.stop();
    				//voice end
    			}
                return false;
            };
            
            var buttonListener = new ButtonListener();
            buttonListener.onButtonClicked = function(button, type) {
                //voice start
                if (contentViewSelf.voice_timer_id){
                    Volt.clearTimeout(contentViewSelf.voice_timer_id);
                    contentViewSelf.voice_timer_id = null;
                }
				contentViewSelf.voice_timer_id = Volt.setTimeout(function(){
                    contentViewSelf.voice_timer_id = null;
					var voiceText = contentViewSelf.widget.getDescendant('fullarticle').text;
					Volt.log('Length of full article is '+voiceText.length);
                    Volt.log('Length of full article is haha');
					if (voiceText.length <= 2000){
						Global.voiceGuide(voiceText);
					} else {
						TTS.stop();
                        var newText = '';
                        var voiceTextArray = voiceText.split('\n');
						for (var i = 0; i < voiceTextArray.length; i++ ){
                            Volt.log('=================split by section: '+i);
							if (voiceTextArray[i].length <= 2000){
                                if ((newText + '\n' + voiceTextArray[i]).length > 2000)                                {
                                    Global.voiceGuide(newText, true);
                                    newText = voiceTextArray[i];
                                }else{
                                    newText = newText + '\n' + voiceTextArray[i];
                                }
								//Global.voiceGuide(voiceTextArray[i], true);
							} else {
    							if (newText != ''){
                                    Global.voiceGuide(newText, true);
                                    newText = '';
                                }
                                var newTextSub = '';
								var voiceTextArray1 = voiceTextArray[i].split('. ');
								for (var j = 0; j < voiceTextArray1.length; j++){
                                    Volt.log('=================split by sentence: '+j);
									if (voiceTextArray1[j].length <= 2000){
                                        if ((newTextSub + '. ' + voiceTextArray1[j]).length > 2000)                                {
                                            Global.voiceGuide(newTextSub, true);
                                            newTextSub = voiceTextArray1[j];
                                        }else{
                                            newTextSub = newTextSub + '. ' + voiceTextArray1[j];
                                        }
                                    }else{
                                        if (newTextSub != ''){
                                            Global.voiceGuide(newTextSub, true);
                                            newTextSub = '';
                                        }
										Volt.log('Text is too long to be read!');
										Volt.log('Text is : '+voiceTextArray1[j]);
                                        Global.voiceGuide(voiceTextArray1[j], true); //still try
									}
									//Global.voiceGuide(voiceTextArray1[j], true);
								}
                                if (newTextSub != ''){
                                    Global.voiceGuide(newTextSub, true);
                                    newTextSub = '';
                                }
							}
						}
                        if (newText != ''){
                            Global.voiceGuide(newText, true);
                            newText = '';
                        }
					}
				}, 500);
                //voice end
            };
            this.readArticle.addListener(buttonListener);
            
            var focusListener = new FocusListener();
            focusListener.onFocusIn = function(){
                //voice start
                var intervalId = Volt.setInterval(function(){
    				if (!LoadingDialog.isLoading){
                        if (1 == DeviceModel.getMenuTTS()){
                            detailViewSelf.lastFocus = contentViewSelf.readArticle;
                            var voiceText = Volt.i18n.t('TV_SID_READ_ARTICLE') + ', button';
                            if (true == detailViewSelf.isFresh){
                                voiceText = titleViewSelf.model.get('title') + ', ' + titleViewSelf.model.get('stringstamp')+', '+voiceText;
                                detailViewSelf.isFresh = false;
                            }
                            Global.voiceGuide(voiceText);
                        }
                        Volt.clearInterval(intervalId);
                    }
                }, 100);
                //voice end
            };
            this.readArticle.addFocusListener(focusListener);

            /*var firstShownListener = new FirstShownListener();
            firstShownListener.onFirstShown = function(){
                //voice start
                if (1 == DeviceModel.getMenuTTS()){
                    var voiceText = titleViewSelf.model.get('title') + ', ' + titleViewSelf.model.get('stringstamp')+', '+Volt.LANG.READ_ARTICLE + ', button';
                    Global.voiceGuide(voiceText);
                }
                detailViewSelf.isFresh = false;
                //voice end
            };
            this.readArticle.getChild(0).addFirstShownListener(firstShownListener);*/
        },
        
		pageHeightMgr : [],
        /** show the content view 
        * @function show
        * @memberof ContentView
        */
		show : function () {
            var stripText = this.model.get('full_story_txt');
            if(stripText && stripText.length > 0)
            {
                stripText = stripText.replace(/<(?:.|\n)*?>/gm, '').replace(/&nbsp/g, '');
                //remove last \\n
                print('stripText.length------0'+stripText.length);
                stripText = stripText.trim(); //remove unrelevant space
                while(stripText.charAt(stripText.length - 1) == '\n')
                {
                    stripText = stripText.slice(0,stripText.length - 1);
                    print('stripText.length----1--'+stripText.length);
                    Volt.log('remove last \\n');
                }
                stripText = stripText.replace(/\n\s+/g, '\\n');
                stripText = stripText.replace(/\n/g, '\\n');
                stripText = stripText.replace(/\t/g, '\\t');
                if(this.model.get('source_copyright') !== null && this.model.get('source_copyright').length && this.model.get('source_copyright').length > 0){

					if(HALOUtil.getOrientation() == 'right-to-left') {
                    	stripText = '\u200f'+stripText + '\\n\\n'+'\u200f'+this.model.get('source_copyright');
					} else {
                    	stripText = stripText + '\\n\\n'+this.model.get('source_copyright');
					}
                }
            }
            var summaryText = this.model.get('summary');
            if(summaryText && summaryText.length > 0)
            {
                summaryText = summaryText.replace(/<(?:.|\n)*?>/gm, '').replace(/&nbsp/g, '').replace(/(?:\r\n|\r|\n|\t)/g, '');
            }
            var brandImgUrl = null;
            if(CPAPI.getServiceType() == 'sina_huafeng') {
                brandImgUrl = ResourceMgr.NewsCpIconSinaW;//Volt.getRemoteUrl('images/1080/news_cp_icon_sina_w.png');
                summaryText = '';
                //clear first '\\n' when in sina_huafeng
                while(String(stripText).indexOf('\\n') === 0)
                {
                    stripText = stripText.replace('\\n','');
                }
            } else {
                brandImgUrl = this.model.get('brand_img_url');
            }
            var mastash = {
                brand_img_url: brandImgUrl,
                summary: summaryText,
                fullarticle:stripText,
            };
            //data is ready
            this.pageHeightMgr = [];
            this.pageHeightMgr.length = 0;
            var contentArea = this.widget.getDescendant('contentArea');
            //clear contentArea's child if hide operation didn't function well
            var destroyList = [];
            if(contentArea && contentArea.getChildCount() > 0){
                for(var i = 0; i < contentArea.getChildCount(); i++){
                    destroyList.push(contentArea.getChild(i));
                }
                for(var i = 0; i < destroyList.length;i++){
                    contentArea.removeChild(destroyList[i]);
                    Volt.log('destroyList[i].id'+destroyList[i].id);
                    destroyList[i].id = "";
                    destroyList[i].destroy();
                }
            }
            //attach to crop widget
            var contentAppend = PanelCommon.loadTemplate(NewsOnDetailCommonTemplate.contentAppend, mastash);
            contentArea.addChild(contentAppend);
            
            //added @2014.12.10 for motion
            
            var contentAppendBackup = PanelCommon.loadTemplate(NewsOnDetailCommonTemplate.contentAppendBackup, mastash); //backup widget
            contentArea.addChild(contentAppendBackup);
            
            var contentRealArea = this.widget.getDescendant('contentRealArea');
            var contentRealAreaBackup = this.widget.getDescendant('contentRealArea_backup'); //backup widget
            this.detailContentSwap = [];
            this.detailContentSwap[0] = contentRealArea;
            this.detailContentSwap[1] = contentRealAreaBackup;
            var colorDrowingHorizontal = this.widget.getDescendant('color_drowing_horizontal');
            var colorDrowingHorizontalBackup = this.widget.getDescendant('color_drowing_horizontal_backup'); //backup widget
            
            var osdFullarticle = this.widget.getDescendant('osd_fullarticle');
            var osdFullarticleBackup = this.widget.getDescendant('osd_fullarticle_backup');//backup widget
            
            var fullarticle = this.widget.getDescendant('fullarticle');
            var fullarticleBackup = this.widget.getDescendant('fullarticle_backup');//backup widget
            
            var summaryWidget = this.widget.getDescendant('summary');
            var summaryWidgetBackup = this.widget.getDescendant('summary_backup');//backup widget
            //in china cp,change the brand image width
            if(CPAPI.getServiceType() == 'sina_huafeng') {
                this.widget.getDescendant('brand_img_url').width = this.widget.getDescendant('brand_img_url').height * 1.3; //adjust the image width manually
                this.widget.getDescendant('brand_img_url_backup').width = this.widget.getDescendant('brand_img_url_backup').height * 1.3; ////backup widget adjust
            }

			var lineHeight = Volt.is720p? 48:50;
			var fullArticlePageHeight = 11*lineHeight;

			Volt.log('lineHeight------------------'+lineHeight);
			Volt.log('fullArticlePageHeight------------------'+fullArticlePageHeight);

			
            var maxLineCount = null;
            if(summaryText === null || summaryText === '')
            {
                summaryWidget.height = 0;
                summaryWidgetBackup.height = 0;         //backup widget
                colorDrowingHorizontal.hide();
                colorDrowingHorizontalBackup.hide();    //backup widget
                osdFullarticle.hide();
                osdFullarticleBackup.hide();            //backup widget
                fullarticle.y = 56;
                fullarticleBackup.y = 56;        //backup widget
            }
            else
            {
                summaryWidget.lineSpacing = 15;
                summaryWidgetBackup.lineSpacing = 15; //backup widget
                Volt.log('summaryWidget.getFullTextLineCount()'+summaryWidget.getFullTextLineCount());
                Volt.log('summary.y------------------'+summaryWidget.y);
                Volt.log('summary.height------------------'+summaryWidget.height);
                Volt.log('maxLineCount------------------'+maxLineCount);
                summaryWidget.y = 56;
                summaryWidgetBackup.y = 56;
                maxLineCount = summaryWidget.getFullTextLineCount();
                if(maxLineCount >= 8){
                    maxLineCount = 8;
                }
                colorDrowingHorizontal.y = summaryWidget.y + summaryWidget.getLineHeight(0,maxLineCount) + NewsonDetailTemplate.constNum.lineSpace;
                summaryWidget.height = summaryWidget.getLineHeight(0,maxLineCount);
                //backup widget
                colorDrowingHorizontalBackup.y = summaryWidgetBackup.y + summaryWidgetBackup.getLineHeight(0,maxLineCount) + NewsonDetailTemplate.constNum.lineSpace;
                summaryWidgetBackup.height = summaryWidgetBackup.getLineHeight(0,maxLineCount);
                Volt.log('colorDrowingHorizontal.y------------------'+colorDrowingHorizontal.y);
                Volt.log('colorDrowingHorizontal.height------------------'+colorDrowingHorizontal.height);
                osdFullarticle.y = colorDrowingHorizontal.y + colorDrowingHorizontal.height + NewsonDetailTemplate.constNum.lineSpace;
                osdFullarticleBackup.y = colorDrowingHorizontalBackup.y + colorDrowingHorizontalBackup.height + NewsonDetailTemplate.constNum.lineSpace; //backup widget
                fullarticle.y = 156+lineHeight*maxLineCount;
                fullarticleBackup.y = 156+lineHeight*maxLineCount; //backup widget
            }
            
            fullarticle.lineSpacing = 15;
            fullarticleBackup.lineSpacing = 15;//backup widget
            //ready to adjust
            var pageShowLineTotal = 11;
            this.scrollIndex = 0;
            this.scrollTotal = -1;
            if(CPAPI.getServiceType() == 'sina_huafeng') {
                var Total = 1;
                var lineTotal = fullarticle.getFullTextLineCount();
                lineTotal -= 10;
                Total += Math.floor(lineTotal/11) +(lineTotal%11 == 0?0:1);
                for(var i = 0; i < Total;i++){
                    this.pageHeightMgr.push(fullArticlePageHeight);
                }
            }else {
                //in yahoo first page total is 8
                var Total = 1;
                var lineTotal = fullarticle.getFullTextLineCount();
                var pageFirstLineCount = 8;
                lineTotal -= (pageFirstLineCount - maxLineCount);
                Total += Math.floor(lineTotal/11) +(lineTotal%11 == 0?0:1);
                for(var i = 0; i < Total;i++){
                    this.pageHeightMgr.push(fullArticlePageHeight);
                }
				
            }
            this.scrollTotal = this.pageHeightMgr.length;
            Volt.log('this.pageHeightMgr'+this.pageHeightMgr);
            //change crop widget height
            if(this.pageHeightMgr.length > 0)
                contentArea.height = this.pageHeightMgr[0];
            
            //update change the font color
            /*
            var utility = new Utility;
            var extractColor = utility.extractForegroundColor(scene.color.r, scene.color.g, scene.color.b);
            extractColor.color.a = 153;
            
            osdFullarticle.textColor = extractColor.color;
            summaryWidget.textColor = extractColor.color;
            fullarticle.textColor = extractColor.color;*/
            //end of update change the font color
            //var height = fullarticle.height + fullarticle.y;
            
            //this.scrollIndex = 0;
            //this.scrollTotal = Math.floor( height / NewsonDetailTemplate.constNum.contentHeight )  + (height % NewsonDetailTemplate.constNum.contentHeight == 0 ? 0:1 );
            var scrollBar = this.widget.getDescendant('detail_scroll_bar');
            scrollBar.setCount(this.scrollTotal);
            this.onBlur(this.widget.getDescendant('artical_down')); //clear focus first
            this.onBlur(this.widget.getDescendant('artical_up'));
            Volt.Nav.focus(null);
            if(this.pageHeightMgr.length == 1) {
                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_up'));
                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_down'));
                Volt.Nav.reload();
            }
            else if(this.pageHeightMgr.length > 1) {
                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_up'));
                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                Volt.Nav.reload();
                if(detailViewSelf)
                {
                    detailViewSelf.lastFocus = null;
                }
                if(Global.APP_STATUS === Global.APP_ACTIVE)
                {
                    Volt.Nav.focus(this.widget.getDescendant('artical_down'));
                } 
                else if(Global.APP_STATUS === Global.APP_DEACTIVATE)
                {
                    detailViewSelf.lastFocus = this.widget.getDescendant('artical_down');
                } 
                else
                {
                    Volt.Nav.focus(this.widget.getDescendant('artical_down'));
                }
                //Volt.Nav.focus(this.widget.getDescendant('artical_down')); //if pagecount > 1, should focus page down
            }
            this.keySelectEnable = true;
            this.viceKeySelectEnable = true;
            if (1 == DeviceModel.getMenuTTS()){
                this.onBlur(this.widget.getDescendant('artical_down'));
                this.disableArticleScroll();
                this.widget.getDescendant('read_article').custom.focusable = true;
                this.widget.getDescendant('read_article').enable(true);
                this.widget.getDescendant('read_article').show();
                Volt.Nav.reload();
                Volt.Nav.focus(this.widget.getDescendant('read_article'));
            } else {
                this.widget.getDescendant('read_article').custom.focusable = false;
                this.widget.getDescendant('read_article').enable(false);
                this.widget.getDescendant('read_article').hide();
                this.widget.getDescendant('artical_up').show();
                this.widget.getDescendant('artical_down').show();
            }
            this.widget.show();
            this.listenTo(DeviceModel, 'change:tts', this.switchVoiceOrNormal);
		},
		scrollIndex : 0,
        scrollTotal : 0,
		events : {
			'NAV_FOCUS' : 'onFocus',
			'NAV_BLUR' : 'onBlur',
            //'NAV_SELECT': 'onSelect',
		},
        focusWidget:null, // mgr which focus now is focused in detail view
		keySelectEnable : false,
        viceKeySelectEnable:false,
        onKeyEvent : function (keycode, keytype){
            if (keytype == Volt.EVENT_KEY_RELEASE) {
				return ;
			}
            //Volt.KEY_JOYSTICK_DOWN,Volt.KEY_JOYSTICK_UP
            if (keycode == Volt.KEY_JOYSTICK_DOWN){
                Volt.log();
                this.onSelect(this.widget.getDescendant('artical_down'));
                return true;
            } else if (keycode == Volt.KEY_JOYSTICK_UP){
                Volt.log();
                this.onSelect(this.widget.getDescendant('artical_up'));
                return true;
            } else {
                return false;
            }
        },
        detailContentSwap :[],
        transOne:null,
        transTwo:null,
        transThree:null,
        transFour:null,
        
        /** contentView's selected callback. 
        * @function onSelect
        * @param {Widget}  widget                  	- the widget is selected
        * @memberof ContentView
        */
		onSelect : function (widget) {
            print('this.keySelectEnable'+this.keySelectEnable);
            print('this.viceKeySelectEnable'+this.viceKeySelectEnable);
            if(widget.id == 'artical_down' && contentViewSelf.scrollIndex == contentViewSelf.scrollTotal - 1)
                return;
            if(widget.id == 'artical_up' && contentViewSelf.scrollIndex == 0)
                return;
            if(this.keySelectEnable && this.viceKeySelectEnable)
            {
                var contentRealAreaContaner = this.widget.getDescendant('contentRealArea');
                var needMoveWidgetBackup = this.widget.getDescendant('contentRealArea_backup');
                var scrollBar = this.widget.getDescendant('detail_scroll_bar');
                var contentArea = this.widget.getDescendant('contentArea');
                if(contentRealAreaContaner === undefined)
                    return;
                this.keySelectEnable = false;
                this.viceKeySelectEnable = false;
                var needMoveWidget = contentRealAreaContaner;
                print('start contentViewSelf.detailContentSwap[0].y'+contentViewSelf.detailContentSwap[0].y);
                print('start contentViewSelf.detailContentSwap[1].y'+contentViewSelf.detailContentSwap[1].y);
                if(widget.id == 'artical_down' && contentViewSelf.scrollIndex < contentViewSelf.scrollTotal - 1)
                {
                    contentArea.height = this.pageHeightMgr[this.scrollIndex+1];
                    Volt.log('down--------'+contentViewSelf.pageHeightMgr[contentViewSelf.scrollIndex]);
                    contentViewSelf.transOne = new MultiObjectTransition();
                    contentViewSelf.transOne.setDuration(500);
                    contentViewSelf.transOne.AddObjectDestination(this.detailContentSwap[0], 'alpha', 0);
                    var transListener = new MultiObjectTransitionListener();
                    var transListenerTwo = new MultiObjectTransitionListener();
                    contentViewSelf.transTwo = new MultiObjectTransition();
                    contentViewSelf.transTwo.setDuration(500*0.8);
                    contentViewSelf.transTwo.AddObjectDestination(this.detailContentSwap[0], "y", this.detailContentSwap[0].y - 20);
                    transListenerTwo.onStoped = function(transition, isFinished){
                        Volt.log('transListenerTwo---isFinished'+isFinished);
                    }
                    transListener.onStoped = function(transition, isFinished){
                        Volt.log('transListener---isFinished'+isFinished);
                        if(isFinished){
                            contentViewSelf.detailContentSwap[0].opacity = 0;
                            contentViewSelf.detailContentSwap[1].y = contentViewSelf.detailContentSwap[1].y - contentViewSelf.pageHeightMgr[contentViewSelf.scrollIndex] + 20;
                            Volt.log('0----contentViewSelf.detailContentSwap[1].y'+contentViewSelf.detailContentSwap[1].y);
                            contentViewSelf.transThree = new MultiObjectTransition();
                            contentViewSelf.transThree.setDuration(500);
                            contentViewSelf.transThree.AddObjectDestination(contentViewSelf.detailContentSwap[1], 'alpha', 255);
                            contentViewSelf.transFour = new MultiObjectTransition();
                            contentViewSelf.transFour.setDuration(500*0.8);
                            contentViewSelf.transFour.AddObjectDestination(contentViewSelf.detailContentSwap[1], 'y', contentViewSelf.detailContentSwap[1].y-20);
                            var transListenerThree = new MultiObjectTransitionListener();
                            var transListenerFour = new MultiObjectTransitionListener();
                            transListenerFour.onStoped = function(transition, isFinished){
                                Volt.log('transListenerFour---isFinished'+isFinished);
                            }
                            transListenerThree.onStoped = function(transition, isFinished){
                                Volt.log('transListenerThree---isFinished'+isFinished);
                                if(isFinished){
                                    var tmp  = contentViewSelf.detailContentSwap[0];
                                    contentViewSelf.detailContentSwap[1].opacity = 255;
                                    contentViewSelf.detailContentSwap[0] = contentViewSelf.detailContentSwap[1];
                                    contentViewSelf.detailContentSwap[1] = tmp;
                                    print('contentViewSelf.detailContentSwap[0].y'+contentViewSelf.detailContentSwap[0].y);
                                    print('contentViewSelf.detailContentSwap[1].y'+contentViewSelf.detailContentSwap[1].y);
                                    contentViewSelf.viceKeySelectEnable = true;
                                }
                            }
                            contentViewSelf.transThree.addListener(transListenerThree);
                            contentViewSelf.transFour.addListener(transListenerFour);
                            contentViewSelf.transThree.play();
                            contentViewSelf.transFour.play();
                            contentViewSelf.detailContentSwap[0].y = contentViewSelf.detailContentSwap[0].y - contentViewSelf.pageHeightMgr[contentViewSelf.scrollIndex] + 20;
                            Volt.log('0----contentViewSelf.detailContentSwap[0].y'+contentViewSelf.detailContentSwap[0].y);
                            contentViewSelf.scrollIndex++;
                            if(contentViewSelf.scrollIndex == 1 && contentViewSelf.scrollTotal >= 3)
                            {
                                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_up'));
                                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                                Volt.Nav.reload();
                            }
                            if(contentViewSelf.scrollIndex == contentViewSelf.scrollTotal - 1) // arrive bottom
                            {
                                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_up'));
                                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_down'));
                                Volt.Nav.blur();
                                Volt.Nav.reload();
                                if(detailViewSelf)
                                {
                                    detailViewSelf.lastFocus = null;
                                }
                                if(Global.APP_STATUS === Global.APP_ACTIVE)
                                {
                                    Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_up'));
                                } 
                                else if(Global.APP_STATUS === Global.APP_DEACTIVATE)
                                {
                                    detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('artical_up');
                                } 
                                else
                                {
                                    Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_up'));
                                }
                            }
                            scrollBar.downPage();
                            contentViewSelf.keySelectEnable = true;
                        }
                    }
                    contentViewSelf.transOne.addListener(transListener);
                    contentViewSelf.transTwo.addListener(transListenerTwo);
                    contentViewSelf.transOne.play();
                    contentViewSelf.transTwo.play();
                    //KPI start
                    this.KPIDownScroll.send();
                    //KPI end
                }else if(widget.id == 'artical_up' && contentViewSelf.scrollIndex > 0) {
                    contentArea.height = this.pageHeightMgr[this.scrollIndex - 1];
                    Volt.log('up--------'+contentViewSelf.pageHeightMgr[contentViewSelf.scrollIndex]);
                    var distance = contentViewSelf.pageHeightMgr[contentViewSelf.scrollIndex] - this.pageHeightMgr[this.scrollIndex - 1];
                    Volt.log('distance--------------------------'+distance);                    
                    contentViewSelf.transOne = new MultiObjectTransition();
                    contentViewSelf.transOne.setDuration(500);
                    contentViewSelf.transOne.AddObjectDestination(this.detailContentSwap[0], 'alpha', 0);
                    var transListener = new MultiObjectTransitionListener();
                    var transListenerTwo = new MultiObjectTransitionListener();
                    contentViewSelf.transTwo = new MultiObjectTransition();
                    contentViewSelf.transTwo.setDuration(500*0.8);
                    contentViewSelf.transTwo.AddObjectDestination(this.detailContentSwap[0], "y", this.detailContentSwap[0].y + 20);
                    transListener.onStoped = function(transition, isFinished){
                        if(isFinished){
                            contentViewSelf.detailContentSwap[0].y = contentViewSelf.detailContentSwap[0].y + contentViewSelf.pageHeightMgr[contentViewSelf.scrollIndex] - distance - 20;
                            contentViewSelf.detailContentSwap[1].y = contentViewSelf.detailContentSwap[1].y + contentViewSelf.pageHeightMgr[contentViewSelf.scrollIndex] - distance - 20;
                            ////////////////////
                            contentViewSelf.transThree = new MultiObjectTransition();
                            contentViewSelf.transThree.setDuration(500);
                            contentViewSelf.transThree.AddObjectDestination(contentViewSelf.detailContentSwap[1], 'alpha', 255);
                            contentViewSelf.transFour = new MultiObjectTransition();
                            contentViewSelf.transFour.setDuration(500*0.8);
                            contentViewSelf.transFour.AddObjectDestination(contentViewSelf.detailContentSwap[1], 'y', contentViewSelf.detailContentSwap[1].y + 20);
                            var transListenerThree = new MultiObjectTransitionListener();
                            var transListenerFour = new MultiObjectTransitionListener();
                            transListenerThree.onStoped = function(transition, isFinished){
                                if(isFinished){
                                    contentViewSelf.detailContentSwap[1].opacity = 255;
                                    var tmp  = contentViewSelf.detailContentSwap[0];
                                    contentViewSelf.detailContentSwap[0] = contentViewSelf.detailContentSwap[1];
                                    contentViewSelf.detailContentSwap[1] = tmp;
                                    contentViewSelf.viceKeySelectEnable = true;
                                }
                            }
                            transListenerFour.onStoped = function(transition, isFinished){
                                Volt.log('transListenerFour---isFinished'+isFinished);
                            }
                            contentViewSelf.transThree.addListener(transListenerThree);
                            contentViewSelf.transFour.addListener(transListenerFour);
                            contentViewSelf.transThree.play();
                            contentViewSelf.transFour.play();
                            /////////////////////
                            contentViewSelf.scrollIndex--;
                            Volt.log('needMoveWidget.y-----'+needMoveWidget.y);
                            if(contentViewSelf.scrollIndex == 0)
                            {
                                contentViewSelf.disableButton(contentViewSelf.widget.getDescendant('artical_up'));
                                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                                Volt.Nav.blur();
                                Volt.Nav.reload();
                                if(detailViewSelf)
                                {
                                    detailViewSelf.lastFocus = null;
                                }
                                if(Global.APP_STATUS === Global.APP_ACTIVE)
                                {
                                    Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_down'));
                                } 
                                else if(Global.APP_STATUS === Global.APP_DEACTIVATE)
                                {
                                    detailViewSelf.lastFocus = contentViewSelf.widget.getDescendant('artical_down');
                                } 
                                else
                                {
                                    Volt.Nav.focus(contentViewSelf.widget.getDescendant('artical_down'));
                                }
                            }
                            if(contentViewSelf.scrollTotal >= 3 && contentViewSelf.scrollIndex == contentViewSelf.scrollTotal - 2)
                            {
                                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_up'));
                                contentViewSelf.enableButton(contentViewSelf.widget.getDescendant('artical_down'));
                                Volt.Nav.reload();
                            }
                            scrollBar.upPage();
                            contentViewSelf.keySelectEnable = true;
                        }
                    }
                    transListenerTwo.onStoped = function(transition, isFinished){
                        Volt.log('transListenerTwo---isFinished'+isFinished);
                    }
                    
                    contentViewSelf.transOne.addListener(transListener);
                    contentViewSelf.transTwo.addListener(transListenerTwo);
                    contentViewSelf.transOne.play();
                    contentViewSelf.transTwo.play();
                    //KPI start
                    this.KPIUpScroll.send();
                    //KPI end
                }else {
                    this.keySelectEnable = true;                
                }
            }
        },
		
        enableButton : function(wzButton){
            wzButton.opacity = Volt.getPercentage(100);
            wzButton.custom.focusable = true;
            wzButton.enable(true);
        },
        
        disableButton : function(wzButton){
            //wzButton.opacity = Volt.getPercentage(10);
            wzButton.custom.focusable = false;
            wzButton.enable(false);
        },
        /** contentView's focus callback. 
        * @function onFocus
        * @param {Widget}  widget                  	- the widget is focused
        * @memberof ContentView
        */
		onFocus : function (widget) {
			if (widget === undefined)
				return;
            try{
                if (widget) {
                    widget.setFocus();
                    this.focusWidget = widget; // save the focus widget
                }
            }catch(e){
                Volt.err(e);
            }
		},
		destroy : function(widget){
            if (!widget) {
                return;
            }
            Volt.log('widget.id' + widget.id);
            var nChildLength = widget.getChildCount();
            if (nChildLength > 0) {
                var i = 0;
                for(i = 0; i < nChildLength; i++){
                    this.destroy(widget.getChild(i));
                }
            }
            widget.id = '';
            //delete widget;
            widget.destroy();
            widget = null;
        },
        /** contentView's blur callback. 
        * @function onBlur
        * @param {Widget}  widget                  	- the widget is blurred
        * @memberof ContentView
        */
		onBlur : function (widget) {
			if (widget === undefined)
				return;
            try {
                if (widget) {
                    widget.killFocus();
                }
            }catch(e){
                Volt.err(e);
            }
		},
		
        /** contentView's focus callback. 
        * @function onFocusVideo
        * @param {Widget}  widget                  	- the widget is focused
        * @memberof ContentView
        */
		onFocusVideo : function (widget) {
			if (widget === undefined)
				return;
			if (widget.setFocus) {
				widget.setFocus();
			} else {
				if (widget && widget.border)
					widget.border = {
						width : NewsonDetailTemplate.constNum.videoFocusBW,
						color : {
							r : 255,
							g : 0,
							b : 255,
							a : 255
						}
					};
			}
			
		},
		
        /** contentView's blur callback. 
        * @function onBlurVideo
        * @param {Widget}  widget                  	- the widget is blurred
        * @memberof ContentView
        */
		onBlurVideo : function (widget) {
			if (widget === undefined)
				return;
			if (widget.killFocus) {
				widget.killFocus();
			} else
				widget.border = {
					width : NewsonDetailTemplate.constNum.videoBlurBW,
					color : {
						r : 255,
						g : 0,
						b : 255,
						a : 0
					}
				};
		},
		
        /** hide the content view 
        * @function hide
        * @memberof ContentView
        */
		hide : function () {
			var deferred = Q.defer();
            var articalUp = this.widget.getDescendant('artical_up');
            var articalDown = this.widget.getDescendant('artical_down');
            if(articalUp !== undefined && articalUp.getChildCount() == 2)
            {
                this.onBlur(articalUp);
            }
            
            if(articalDown !== undefined && articalDown.getChildCount() == 2)
            {
                this.onBlur(articalDown);
            }
            //open the key 
            this.keySelectEnable = true;//because of widget destory may cancel the animation
            this.viceKeySelectEnable = true;
            if(this.transOne){
                this.transOne.stop();
                this.transOne = null;
            }
            if(this.transTwo){
                this.transTwo.stop();
                this.transTwo = null;
            }
            if(this.transThree){
                this.transThree.stop();
                this.transThree = null;
            }
            if(this.transFour){
                this.transFour.stop();
                this.transFour = null;
            }
            var scrollBar = this.widget.getDescendant('detail_scroll_bar');
            scrollBar.reset();
            contentViewSelf.detailContentSwap = [];
            contentViewSelf.detailContentSwap.length = 0; //
			this.widget.hide();
            var contentRealArea = this.widget.getDescendant('contentRealArea');
            if(contentRealArea)
                this.destroy(contentRealArea);
            var contentRealAreaBackup = this.widget.getDescendant('contentRealArea_backup');
            if(contentRealAreaBackup)
                this.destroy(contentRealAreaBackup);
            this.focusWidget = null; // clear focus widget
            this.stopListening(DeviceModel, 'change:tts');
			deferred.resolve();
			return deferred.promise;
		},
		
	});

//template of related area

/** RelatedItemView -BackboneView
* @class 
* @name RelatedItemView
* @augments Backbone.View
*/
var RelatedItemView = BaseView.extend({
        
        /**
        * This property represents the default template in RelatedItemView.
        * @name template
        * @type JSON
        * @default NewsonDetailTemplate.verticallist
        * @fieldOf RelatedItemView.prototype
        */
		template : NewsonDetailTemplate.verticallist,
        
        /**
         * This property represents the news' map on the news collection.
         * @name cacheMap
         * @type Array
         * @default []
         * @fieldOf RelatedItemView.prototype
         */
		cacheMap : [],
        
        /**
         * This property represents the news' map without current news.
         * @name map
         * @type Array
         * @default []
         * @fieldOf RelatedItemView.prototype
         */
		map : [],
        
        /** Initialize RelatedItemView. 
        * @function initialize
        * @param {Array}  map                  	- the detail news' map
        * @memberof RelatedItemView
        */
        initialize : function (map) {
			relatedItemViewSelf = this;
        	this.cacheMap = map;

            //KPI start
            this.KPISelectRelatedNews = new KPIOptions.SelectRelatedNews(this);
            //KPI end
            this.initList = _.bind(__initList, this);
        },

        updateHighContrast : function(thumbnail, index){
            if (0 == index%2){
                thumbnail.color = Volt.hexToRgb('#252525', 100);
            }else{
                thumbnail.color = Volt.hexToRgb('#464646', 100);
            }
        },
        
        /** render RelatedItemView. 
        * @function render
        * @memberof RelatedItemView
        */
		render : function (parent) {
			//relatedItemViewSelf = this;
			//use resizeablelist to render related list
			var grid = null; //__initGrid();
			grid = PanelCommon.loadTemplate(this.template, null, parent);
            this.initList(grid);
            this.setWidget(grid);
            Volt.Nav.setNextItemRule(this.widget,"down",this.widget);
            grid.onFocusChange = function(oldIndex, newIndex){
                if (1 == DeviceModel.getMenuTTS() && newIndex != -1){
                    var position = -1, tile = null, count = 0;
                    if(relatedItemViewSelf.relatedCollection !== null && relatedItemViewSelf.relatedCollection.length > 0) {
                        position = newIndex;
                        tile = relatedItemViewSelf.relatedCollection.at(position);
                        count = relatedItemViewSelf.relatedCollection.length;
                    } else {
                        position = relatedItemViewSelf.map[newIndex % relatedItemViewSelf.map.length];
                        tile = detailViewSelf.tileCollection.at(position);
                        count = relatedItemViewSelf.map.length - 1;
                    }
                    //voice start
                    var voiceText = tile.get('title');
                    if (-1 == oldIndex){
                        var item = (1 == count) ? 'item' : 'items';
                        voiceText = 'News List, ' + count + ', ' + item + ', ' + voiceText;
                    }
                    Global.voiceGuide(voiceText);
                    //voice end
                }
            };
            grid.onDrawLoadData = function(thumbnail,data, parentWidth, parentHeight)
            {
                data.root = thumbnail;
                
                //apply highcontrast
                if (true == DeviceModel.get('highContrast')){
                    relatedItemViewSelf.updateHighContrast(thumbnail, data.index);
                }
                //add highcontrast listener
                var widgetExListener = new WidgetExListener;
                widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
                    Volt.log("flagHighContrast is " + flagHighContrast);
                    if(true == flagHighContrast){
                        relatedItemViewSelf.updateHighContrast(thumbnail, data.index);
                    }else{
                        widgetEx.color = Volt.hexToRgb('#d4d4d4', 100);
                    }
                },
                thumbnail.addWidgetExListener(widgetExListener);
				thumbnail.widgetExListener = widgetExListener;

                
                createRelatedItem(thumbnail,data.index, data.model);
            };

			grid.onDrawUnLoadData = function(thumbnail,data, parentWidth, parentHeight)
            {
		        Volt.log('onDrawUnLoadData-----------------------')
		        if(thumbnail === undefined)
		            return;

				if(thumbnail.listener) {
					Volt.log('_remove the thumbnail listener')
					thumbnail.removeThumbnailListener(thumbnail.listener);
					thumbnail.listener.destroy();
					thumbnail.listener = null;
				}	

				if(thumbnail.widgetExListener) {
					Volt.log('_remove the widgetExListener11 listener')
					thumbnail.removeWidgetExListener(thumbnail.widgetExListener);
					thumbnail.widgetExListener.destroy();
					thumbnail.widgetExListener = null;
				}	

				if (thumbnail.timer) {
					Volt.log('_remove the thumbnail timer')
					Volt.clearTimeout(thumbnail.timer);
					thumbnail.timer = null;
				}

            };
            
            grid.onDrawUpdateData = function(widget,data,parentWidth,parentHeight)
            {
                //createRelatedItem(data.index, widget, data.model);
            };
            
            grid.onItemMouseClick = function(index)
            {
                grid.onItemPress(index);
            };
            
            grid.onItemPress = function(index)
            {
                //var widget = relatedItemViewSelf.dataCollection[index].root;
                if(-1 == DeviceModel.getNetWorkState()){
                    var ErrorHandler = Volt.require('app/common/errorHandler.js');
					ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,CommonDefines.ErrorCode.NETWORK_ERROR_CODE);
					return;
				}
			
				if (index >= 0) {
					//switch view when press item of the related list
					//this.model = newsCollection.at;
                    //only happened want exclude news (index==5)
					var length = Backbone.history.location.history.length;
                    var postion = -1;
                    if(relatedItemViewSelf.relatedCollection !== null && relatedItemViewSelf.relatedCollection.length > 0) {
                        postion = index;
                    } else {
                        postion = relatedItemViewSelf.map[index % relatedItemViewSelf.map.length];
                    }
                    if (length > 1) {
                        //KPI start
                        var tile = null;
                        if(relatedItemViewSelf.relatedCollection !== null && relatedItemViewSelf.relatedCollection.length > 0) {
                            tile = relatedItemViewSelf.relatedCollection.at(postion);
                        } else {
                            tile = detailViewSelf.tileCollection.at(postion);
                        }
                        var windowStartIndex = relatedItemViewSelf.widget.windowStartIndex();
                        var contentLocation = 1 + relatedItemViewSelf.widget.focusItemIndex - windowStartIndex;
                        var cpname = ('yahoo' == CPAPI.getServiceType()) ? 'YAHOO':'SINA';
                        var options = {
                            cp : 'H02_DETAIL',
                            sp : 'S-P-' + ((index+1)<10 ? '0' : '') + (index+1).toString(),
							cl : 'C-L-' + (contentLocation<10 ? '0' : '') + contentLocation.toString(),
							ct : 'article',
							cn : cpname};
                        if (true == KPI.getAgreedViewing()){
                            _.extend(options, {
    							ai : tile.get('id'),
    							at : tile.get('title')
                        	});
                        }
                        relatedItemViewSelf.KPISelectRelatedNews.send(options);
                        //KPI end
                    	var url = Backbone.history.location.history[length - 1];
                        //save scene color
						var thumbnail = relatedItemViewSelf.dataCollection[index].root;
						
						if (thumbnail && thumbnail.getInformationColorPicking) {						
							
							var color = thumbnail.getInformationColorPicking();							
							Volt.log("backcolor:color.r " + color.r);
							Volt.log("backcolor:color.g " + color.g);
							Volt.log("backcolor:color.b " + color.b);
							Volt.log("backcolor:color.a " + color.a);
							color.a = 255;
                            if(!DeviceModel.getHighContrast()){
                                Volt.WinsetRoot.color = color;
                            }
                            Volt.WinsetRoot.setBackgroundColor(color);
							//scene.color = color;
							
						}
                        //scene.color = thumbnail.getChild(1).color;
                        detailViewSelf.sceneColorMgr.push({r: color.r, g: color.g, b: color.b});
                        //end save scene color
                    	// need improvement,maybe more options could be passed
                    	Backbone.history.location.history[length - 1] = url.replace(/<(?:.|\n)*?>/gm, '<' + postion + '>');
                        //cache url for have related news
                        detailViewSelf.urlCacheMgr.push(tile.get('detail_url'));
                        
                    	Backbone.history.navigate('detail/' + tile.get('id') + '/' + '<-1>', {
                    		trigger : true
                    	});
                        
                    }
                } else {
                    Volt.log('index is invalid' + index);
                }
            };
            
            grid.onDrawFromFocusChangeStart = function(widget, data, parentWidth, parentHeight)
            {
                //widget.getChild(1).getChild(0).killFocus();
            };
            
            grid.onDrawToFocusChangeEnd = function(widget, data, parentWidth, parentHeight)
            {
               // widget.getChild(1).getChild(0).setFocus();
            };
            var _initScrollBar = function (width,height)
            {
                var scroll = new WinsetScroll({
                    parent: Volt.WinsetRoot,
                    x:Volt.width * (0.16875 - 0.00521),
                    y:0,
                    width: Volt.width*0.002083, //initial scroll bar width
                    height: Volt.height,//1080,   //initial scroll bar height
                    minValue: 0,
                    maxValue: 100,
                    style: WinsetScroll.ScrollStyle.Scroll_Style_C,
                    direction: "vertical", 
                });
                scroll.setBackgroundColor(220, 220, 220, 51);
                scroll.setTrackShadowColor(0, 0, 0, 51);
                scroll.setTrackShadowHeight(Volt.width*0.000521);
                scroll.setPointingNormalThumbSize(0.002083*Volt.width, Volt.height *36/1080);
                scroll.show();
                return scroll;
            }
            var scroll = _initScrollBar(grid.width,grid.height);
            grid.attachScrollBar(scroll);
            grid.focusImageSetted = false;
			grid.hide();
			return this;
		},
		dataCollection : [],
        relatedCollection : null,
        /** show RelatedItemView. 
        * @function show
        * @param {JSON}  options                  	- the options passed from other view
        * @memberof RelatedItemView
        */
		show : function (options,relatedCollection) {
            Volt.log('detail view show');
			this.map = [];
			this.map = this.cacheMap.slice(0);
            this.relatedCollection = null;
            if(relatedCollection !== undefined)
            {
                this.relatedCollection = relatedCollection;
            }
			
            if(this.relatedCollection === null) {
                //remove the show news in map
                var index = -1;
                var indexInTileCollection = -1;
                for(var i = 0; i < detailViewSelf.tileCollection.length;i++)
                {
                    print('detailViewSelf.tileCollection.at'+i+'id'+detailViewSelf.tileCollection.at(i).id);
                    print('options.id'+options.id);
                    if(detailViewSelf.tileCollection.at(i).id === options.id){
                        indexInTileCollection = i;
                        break;
                    }
                }
                for (var i = 0; i < this.map.length; i++) {
                    
                    if (this.map[i] == indexInTileCollection) {
                        index = i;
                    }
                }
                if (index != -1)
                    this.map.splice(index, 1);
            }
			
            var length = this.map.length <= 15 ? this.map.length : 15;
            length--;//setItem length need exclude news index == 5;
            
            if(this.relatedCollection !== null)
            {
                Volt.log('this.relatedCollection.length'+this.relatedCollection.length);
                length = this.relatedCollection.length
                
            }
            
            if(this.widget.numOfItem() > 0)
            {
                this.widget.deleteItem({fromItem:0,  itemNum:this.widget.numOfItem()});
            }
            this.dataCollection = [];
            this.widget.addItem({itemNum:length, itemSpace:Volt.height*(0.18148 + 0.088889)});
            for(var i = 0; i < length;i++)
            {
                var data = new Data();
                data.index = i;
                data.parent = this.widget;
                if(this.relatedCollection !== null) {
                    data.model = this.relatedCollection.at(i);
                } else {
                    data.model = detailViewSelf.tileCollection.at(this.map[i]);
                }
                data.root = null;
                data.isReady = false;
                this.dataCollection.push(data);
                this.widget.addData(data);
            }
            this.widget.loadData();
            Volt.log('related news begin load data');
            if(length > 0) {
                if (options.focus != '<-1>') {
                    var index = -1;
                    var focusIndex = parseInt(options.focus.replace("<", '').replace(">", ''));
                    for (var i = 0; i < this.map.length; i++) {
                        if (detailViewSelf.tileCollection.at(this.map[i]) == detailViewSelf.tileCollection.at(focusIndex)) {
                            index = i;
                            break;
                        }
                    }
                    //if have related news ,modify focus index
                    if(this.relatedCollection && this.relatedCollection.length > 0)
                    {
                        index = focusIndex;
                    }
                    
                    if (index >= 0) {
                        if(detailViewSelf) {
                            detailViewSelf.lastFocus = null;
                        }
                        this.widget.focusItemIndex = index;
                        if(Global.APP_STATUS === Global.APP_ACTIVE) {
                            Volt.Nav.focus(this.widget);
                        } else if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                            detailViewSelf.lastFocus = this.widget;
                        } else {
                            Volt.Nav.focus(this.widget);
                        }
                        
                    }
                } else {
                    if(contentViewSelf && contentViewSelf.scrollTotal <= 1) {// when page count <=1 set Focust
                        this.widget.focusItemIndex = 0;
                        if (0 == DeviceModel.getMenuTTS()){
                            if(detailViewSelf) {
                                detailViewSelf.lastFocus = null;
                            }
                            if(Global.APP_STATUS === Global.APP_ACTIVE) {
                                Volt.Nav.focus(this.widget);
                            } else if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                                if(detailViewSelf)
                                    detailViewSelf.lastFocus = this.widget;
                            } else {
                                Volt.Nav.focus(this.widget);
                            }
                        }
                    }
                }
            } else {
                this.widget.focusable = false;
            }
            this.widget.show();
        },


	showEnlargeText : function() {
  		Volt.log('showEnlargeText ');

		var index = relatedItemViewSelf.widget.focusItemIndex;
	    Volt.log('index: ' + index);
	    if (HALOUtil.enlarge ) {
 			var thumbnail = relatedItemViewSelf.dataCollection[index].root;
	        if(thumbnail == null){ 
				Volt.log('thumbnail is null!');
				return;
            }

			Volt.log('onMousePointerIn: get thumbnail ');
            //var thumbnail = gridList.renderer(0, itemIndex).thumbnail;
			
			thumbnail.visualizeInformationText(true, "text5");	
			thumbnail.visualizeInformationText(false, "text2");
			thumbnail.visualizeInformationText(false, "text3");
			thumbnail.visualizeInformationText(false, "text4");	
	   }

	},

	_modifyNewsText : function(thumbnail, status){
	    Volt.log('_modifyNewsText'+status);
	    if (HALOUtil.enlarge) {
			//thumbnailViewSelf.updateNewsTextPos(thumbnail);

			if('ToItemStart' == status) {	
				Volt.log('ToItemStart');
				thumbnail.visualizeInformationText(false, "text2");
				thumbnail.visualizeInformationText(false, "text3");
				thumbnail.visualizeInformationText(false, "text4");
				relatedItemViewSelf.updateNewsTextPos(thumbnail);
				//thumbnail.visualizeInformationText(true, "text5");
			} else if('ToItemEnd' == status){
				Volt.log('ToItemEnd');
				thumbnail.visualizeInformationText(true, "text5");
				
				thumbnail.visualizeInformationText(false, "text2");
				thumbnail.visualizeInformationText(false, "text3");
				thumbnail.visualizeInformationText(false, "text4");
			} else if('FromItemStart' == status){

				//thumbnail.visualizeInformationText(true, "text5");
				Volt.log('FromItemStart');
				
				thumbnail.visualizeInformationText(false, "text5");
	
			}else if('FromItemEnd' == status){

				Volt.log('FromItemEnd');
				relatedItemViewSelf.updateNewsTextPos(thumbnail);

				thumbnail.visualizeInformationText(true, "text2");
				thumbnail.visualizeInformationText(true, "text3");
				thumbnail.visualizeInformationText(true, "text4");
				
			}
	    }

	},


	updateNewsTextPos:function(thumbnail) {

        var  sourceCpText = thumbnail.getInformationText('text2');
		var  timeText = thumbnail.getInformationText('text4');
		Volt.log('sourceCpText = '+sourceCpText + 'timeText = '+timeText);
		
		var sourceCpTextWgt = HALOUtil.getTextSize(sourceCpText, "Samsung SVD_Medium 20px");

		var sourceCpTextX = Volt.width*20/1920;

		Volt.log('sourceCpTextX = '+sourceCpTextX + 'sourceCpTextWgt.width= '+sourceCpTextWgt.width);
		var  separateX = sourceCpTextX + sourceCpTextWgt.width;
		thumbnail.setElementAllocation('information-text3', {x: separateX});
		Volt.log('separateX = '+separateX);
		
		var separateWgt = HALOUtil.getTextSize('-', "Samsung SVD_Medium 20px");		

		var  timestampX = separateX + separateWgt.width;
		Volt.log('timestampX = '+timestampX);
		
		var timestampWgt = HALOUtil.getTextSize(timeText, "Samsung SVD_Medium 20px");
		

		var maxWidth = Volt.width*(324- 20*2)/1920 - (sourceCpTextWgt.width + separateWgt.width);	
		
		//var wgtWidth = timestampWgt.width + timestampX;
		var timestampWidth = timestampWgt.width;
		
		Volt.log('timestampWidth = '+timestampWidth + 'maxWidth = '+maxWidth);		

		if(timestampWidth > maxWidth) {
			timestampWidth = maxWidth;
		}
		
		thumbnail.setElementAllocation('information-text4', {x: timestampX,width:maxWidth});
	
	  },
        
        updateTextbyLang : function(){
            for (var index = 0; index < relatedItemViewSelf.dataCollection.length; index++){
                //udpate model
                var tile = relatedItemViewSelf.dataCollection[index].model;
                var last_utc_timestamp = 0;
                if(tile.get('stringstamp_standard')) {
                    last_utc_timestamp = tile.get('timestamp');
                }else{
                    last_utc_timestamp = Math.round(new Date(tile.get('timestamp')).getTime()/1000);
                }
                var now_utc_timestamp = detailViewSelf.newsDetailModel.get('now_utc_timestamp');
                
                var stringstamp_standard = Global.getOccurStamp(now_utc_timestamp, last_utc_timestamp);
                //update model
                //if(tile.get('stringstamp_standard')) {
                    //tile.set('stringstamp_standard', stringstamp_standard);
                //}
                //update screen items
                var thumbnail = relatedItemViewSelf.dataCollection[index].root;
                if (thumbnail){
                    thumbnail.setInformationText("text2", tile.get('source')+' - '+stringstamp_standard);
                }
            }
        },
        
        hide : function()
        {
            this.widget.focusItemIndex = 0;
            this.widget.hideFocus("false");
            this.widget.hide();
            this.firstTimeFocusFlag = true;
        },
        
		events : {
			'NAV_FOCUS' : 'onFocus',
			'NAV_BLUR' : 'onBlur'
		},
		
        /** relatedItemView's selected callback. 
        * @function onSelect
        * @param {Widget}  widget                  	- the widget is selected
        * @memberof RelatedItemView
        */
		onSelect : function (widget) {},
        
        firstTimeFocusFlag : true,  
        /** relatedItemView's focus callback. 
        * @function onFocus
        * @param {Widget}  widget                  	- the widget is focused
        * @memberof relatedItemView
        */
		onFocus : function (widget) {
			if (widget === undefined)
				return;
            
            if(!widget.focusImageSetted){
				if(!Volt.is720p){
					Volt.log('1080 focus grind');
	            	widget.setFocusImage(ResourceMgr.FocusGrid, -5*Volt.width/1920, -5*Volt.height/1080);
				} else {
					Volt.log('720 focus grind');
	            	widget.setFocusImage(ResourceMgr.FocusGrid, -1*Volt.width/1920, 0*Volt.height/1080);
				}                
                widget.focusImageSetted = true;
            }
			widget.enableFocus();
            if(contentViewSelf.pageHeightMgr.length > 1){
                Volt.log('widget.getWindowItemRange');
                if(widget.getWindowItemRange) {
                    var range = widget.getWindowItemRange(true);
                    Volt.log('widget.getWindowItemRange1 end'+range.end);
                    if(relatedItemViewSelf.firstTimeFocusFlag && detailViewSelf.options.focus != '<-1>'){
                        
                    }else{
                        widget.focusItemIndex = range.end;
                    }
                }
            }
            widget.setFocus();
            widget.showFocus("false");
            detailViewSelf.lastFocus = widget;
            if(relatedItemViewSelf.firstTimeFocusFlag){
                relatedItemViewSelf.firstTimeFocusFlag = false;
            }
		},
		
        /** relatedItemView's blur callback. 
        * @function onBlur
        * @param {Widget}  widget                  	- the widget is blurred
        * @memberof relatedItemView
        */
		onBlur : function (widget) {
			if (widget === undefined)
				return;
            Volt.log();
            widget.hideFocus("false");
            widget.killFocus();
		},
	});
var getRenderer = function(singleList,parentWidth, parentHeight, data) {

	print("~~~~~~~~~~~~~~render root parent w  h " + parentWidth + "  :" + parentHeight);
    
	var renderer = new Renderer(parentWidth, parentHeight);
	
	renderer.root = new WidgetEx({
		x : 0,
		y : 0,
		width : parentWidth,
		height : parentHeight,
		parent : Volt.WinsetRoot,
	});
	renderer.root.show();
	
	PanelCommon.loadTemplate(NewsOnDetailCommonTemplate.RelatedItem, null, renderer.root);
	renderer.thumbnail = renderer.root.getChild(0).getChild(2);


	/*renderer.thumbnail.setInformationTextScrollAttribute('text1', {
        //duration: 6000,
        speed: 0.1,
        delay: 0,
        repeat: -1,
        //scrollType: "start_outside_stop_outsid",
        //direction: "backward"
        //continueGap:""
	});*/

	renderer.onDraw = function(rendererInstance,drawTypeString, data, parentWidth, parentHeight) {
		if (!data) {
			return;
		}

		if ("LoadData" == drawTypeString) {
			
			//response the callback onDrawLoadData to draw on listitem
			singleList.onDrawLoadData(rendererInstance.thumbnail,data, parentWidth, parentHeight);
			print("~~~~~~~~~~~~~~renderer.onDraw     LoadData       " );

		}
		else if("UpdateData" == drawTypeString)
        {
			//response the callback onDrawUpdateData to update on listitem
			singleList.onDrawUpdateData(rendererInstance.root,data,parentWidth,parentHeight);
			print("~~~~~~~~~~~~~~renderer.onDraw     UpdateData       " );
        }
		else if ("UnloadData" == drawTypeString)
        {
            Volt.log('UnloadData---------------------'+data.index);
            singleList.onDrawUnLoadData(rendererInstance.thumbnail, data, parentWidth, parentHeight);
        }
		else if("FromItemFocusChangeAniStart" == drawTypeString)
        {
            //The from item of focus change motion start
			singleList.onDrawFromFocusChangeStart(rendererInstance.root,data,parentWidth,parentHeight);
			
			relatedItemViewSelf._modifyNewsText(rendererInstance.thumbnail,'FromItemStart');
			
			//print("~~~~~~~~~~~~~~renderer.onDraw     FromItemFocusChangeAniStart       " );
        }
        else if("ToItemFocusChangeAniEnd" == drawTypeString)
        {
            //The to item of focus change motion end
			singleList.onDrawToFocusChangeEnd(rendererInstance.root,data,parentWidth,parentHeight);
			relatedItemViewSelf._modifyNewsText(rendererInstance.thumbnail,'ToItemEnd');			
        }

		else if("FormItemFocusChangeAniEnd" == drawTypeString)
        {
 			Volt.log('FormItemFocusChangeAniEnd'+data.index);	
			relatedItemViewSelf._modifyNewsText(rendererInstance.thumbnail,'FromItemEnd');	
        }
		else if (drawTypeString == "ToItemFocusChangeAniStart")
        {
        	Volt.log('ToItemFocusChangeAniStart'+data.index);
			relatedItemViewSelf._modifyNewsText(rendererInstance.thumbnail,'ToItemStart');
		            
        }
	};

	renderer.onResize = function(rendererInstance,data, destWidth, destHeight, flagWithAni, duration) {
		if ("withAni" == flagWithAni) {
		} else if ("noAni" == flagWithAni) {
		}
	};

	renderer.onUpdate = function(width, height) {

	};

	renderer.onRelease = function() {
		print("~~~~~~~~~~~~~~render onRelease " + renderer.root.getChildCount());
		renderer.root.destroy();
		delete renderer;
	};

	return renderer;
};

function itemClicked(singleLineList, itemIndex) {

		var index = itemIndex;	

        print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   index    ' + index);
		
		//response the callback onItemMouseClick to mouse click on listitem
	    singleLineList.onItemMouseClick(index);
};

function __initList(singleList)
{
    var rendererProvider = new RendererProvider;
    
	rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data) {
		return getRenderer(singleList,parentWidth, parentHeight, data);
	};

	singleList.setRendererProvider(rendererProvider);

	var singleLineListener = new SingleLineListControlListener;
	singleLineListener.onItemClicked = itemClicked;

	

	


	/*******************set call back api from common-module begin******************/
	//callback to draw list item
	singleList.onDrawLoadData = function(thumbnail,data, parentWidth, parentHeight){};
	//callback to response "enter" key press
	singleList.onItemPress = function(index){};
	//callback to response update list item
	singleList.onDrawUpdateData = function(widget,data, parentWidth, parentHeight){};
	//callback to response focus change start( from item)
	singleList.onDrawFromFocusChangeStart = function(widget,data, parentWidth, parentHeight){};
	//callback to response focus change start( to item)
	singleList.onDrawToFocusChangeEnd = function(widget,data, parentWidth, parentHeight){};
	//callback to response mouse click
	singleList.onItemMouseClick = function(groupIndex,index){};
    
    singleList.onFocusChange = function(fromItemIndex, toItemIndex){};
    
    singleLineListener.onFocusChanged = function(singleLineList, fromItemIndex, toItemIndex)
    {
        singleLineList.onFocusChange(fromItemIndex,toItemIndex);
    };

	singleLineListener.onMousePointerIn = function(gridList, itemIndex)
	{
		Volt.log('onMousePointerIn--itemIndex '+itemIndex);
	 	if (HALOUtil.enlarge) {

			var thumbnail = relatedItemViewSelf.dataCollection[itemIndex].root;
	        if(thumbnail == null){ 
				Volt.log('thumbnail is null!');
				return;
            }

			Volt.log('onMousePointerIn: get thumbnail ');
            //var thumbnail = gridList.renderer(0, itemIndex).thumbnail;
			
			thumbnail.visualizeInformationText(true, "text5");	
			thumbnail.visualizeInformationText(false, "text2");
			thumbnail.visualizeInformationText(false, "text3");
			thumbnail.visualizeInformationText(false, "text4");	
			
	 	}else {
			Volt.log('no need handle!');
	 	}
	
	};
	
	singleLineListener.onMousePointerOut = function(gridList, itemIndex)
	{
		Volt.log('onMousePointerOut--itemIndex '+itemIndex);
		if (HALOUtil.enlarge) {

			var thumbnail = relatedItemViewSelf.dataCollection[itemIndex].root;
	        if(thumbnail == null){ 
				Volt.log('thumbnail is null!');
				return;
            }
			
			Volt.log('onMousePointerOut:get thumbnail ');
			
            //var thumbnail = gridList.renderer(0, itemIndex).thumbnail;
			
			thumbnail.visualizeInformationText(true, "text2");
			thumbnail.visualizeInformationText(true, "text3");
			thumbnail.visualizeInformationText(true, "text4");
			thumbnail.visualizeInformationText(false, "text5");	
	 	}
	
	};
    
    singleList.addListListener(singleLineListener);
    var keyboardListener = new KeyboardListener;
    keyboardListener.onKeyPressed = function (actor, keycode) {
        Volt.log('in detail view keyboardListener');
        switch(keycode) {
            case Volt.KEY_JOYSTICK_OK:{
                var index = singleList.focusItemIndex;
                print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + ']   singleList.focusItemIndex    ' + singleList.focusItemIndex);
                if ( index == undefined){
                    index = 0;
                }
                singleList.onItemPress(index);
            }
            default:
            // to do
                break;
        }
    }
    singleList.addKeyboardListener(keyboardListener);
	
	/*******************set onkeyevent process begin******************/
	this.onKeyEvent = function (keycode, keytype) {
		var ret = false;
		if (keytype == Volt.EVENT_KEY_RELEASE) {
            
			return ret;
		}		
    	switch(keycode) {
			case Volt.KEY_JOYSTICK_UP:
				ret =  singleList.moveFocus("Up");
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				ret =  singleList.moveFocus("Down");
				break;	
			case Volt.KEY_JOYSTICK_LEFT:
				if(Volt.isReverseOsd) {
					ret =  singleList.moveFocus("Left");
				} else {
					ret = false;
				}
                //ret = false;
				break;	
			case Volt.KEY_JOYSTICK_RIGHT:
				//ret =  singleList.moveFocus("Right");

				if(!Volt.isReverseOsd) {
					ret =  singleList.moveFocus("Right");
				} else {
					ret = false;
				}
				break;	
			case Volt.KEY_JOYSTICK_OK:
                break;
			default:
			// to do
                break;
		}
        print('single list onkeyevent return '+ret);
		return ret;
	}
    singleList.enlargeFocusedItem(20, 20);
    singleList.shadowEffectFlag = false;
	singleList.canLoopWhenContinuosKey = false;

    //singleList.setAnimationDuration("focusMove" , 300)
	singleList.onKeyEvent =  this.onKeyEvent.bind(this);
}

/**
 * append related news into grid list.
 * @function
 * @param {Number} index   - the index of related news
 * @param {Widget} widget   - the widget of related news
 * @param {Backbone.Model} model   - the model of related news
 */

function createRelatedItem(thumbnail,index, model) {
    
	print('createRelatedItem---------index'+index);
    thumbnail.index = index;
    var last_utc_timestamp = 0;
    var occurStamp = model.get('stringstamp_standard');
	var now_utc_timestamp = null;
    if(occurStamp === undefined || occurStamp === null) {
		Volt.log('occurStamp is null, have relates news ');
        last_utc_timestamp = Math.round(new Date(model.get('timestamp')).getTime()/1000);
		now_utc_timestamp = detailViewSelf.newsDetailModel.get('now_utc_timestamp');
    }else {
    	Volt.log('occurStamp is not null, not have relates news');
        last_utc_timestamp = model.get('timestamp');
		now_utc_timestamp = model.get('now_utc_timestamp');
    }
    //var now_utc_timestamp = detailViewSelf.newsDetailModel.get('now_utc_timestamp');
   // var now_utc_timestamp = model.get('now_utc_timestamp');
//	if(now_utc_timestamp == undefined){
	//	now_utc_timestamp = detailViewSelf.newsDetailModel.get('now_utc_timestamp');
	//}
    occurStamp = Global.getOccurStamp(now_utc_timestamp, last_utc_timestamp);

    var imgUrl = model.get('img_url');
    if(CPAPI.getServiceType() == 'sina_huafeng') {
        if(imgUrl === null || imgUrl.length ===0) {
            imgUrl = NewsonMainDetailTemplate.main_detail_default[index%8];
        }
    }
   /*var mustache = {
		imgUrl : model.get('img_url'),
		title : model.get('title').replace(/(?:\r\n|\r|\n)/g, ''),
		timestamp : model.get('source')+' - ' + occurStamp,
	};	*/
    var thumbListener = new ThumbnailListener;
    thumbListener.onImageReady = function (thumbnail, id, success) {
        if(success && !DeviceModel.getHighContrast()) {
            /*var backColor = thumbnail.getInformationExtractColor();		
            Volt.log("backcolor:color.r " + backColor.r);
            Volt.log("backcolor:color.g " + backColor.g);
            Volt.log("backcolor:color.b " + backColor.b);	
            backColor.a = 153;
            thumbnail.setInformationTextColor('text1',backColor);
            thumbnail.setInformationTextColor('text2',backColor);
			thumbnail.setInformationTextColor('text3',backColor);
			thumbnail.setInformationTextColor('text4',backColor);
			thumbnail.setInformationTextColor('text5',backColor);*/
        }else if(!success){
            var imgUrl = null;
            imgUrl = NewsonMainDetailTemplate.main_detail_default[thumbnail.index%8];
            Volt.log('failed-----------------'+imgUrl);
            thumbnail.timer = Volt.setTimeout(function(thumbnail) {
                if(thumbnail && thumbnail.setContentImage){
                    thumbnail.setContentImage(imgUrl);
                    thumbnail.loadImageSource();
                }
            },0,thumbnail);
        }
    }
    if(thumbnail.listener && thumbnail.removeThumbnailListener !== undefined){
        thumbnail.removeThumbnailListener(thumbnail.listener);
        thumbnail.listener = null;
    }
    thumbnail.addThumbnailListener(thumbListener);
    thumbnail.listener = thumbListener;
	thumbnail.setContentImage(imgUrl);

	thumbnail.setInformationText('text1',(model.get('title').replace(/(?:\r\n|\r|\n)/g, '')));
	//thumbnail.setInformationText('text2',(model.get('source')+' - ' + occurStamp));
	Volt.log('source='+model.get('source'));
	thumbnail.setInformationText('text2',model.get('source'));
	Volt.log('timestamp='+occurStamp);
	thumbnail.setInformationText('text4',occurStamp);

	//var  sourceCpText = thumbnail.getInformationText('text2');
	//var  timeText = thumbnail.getInformationText('text4');
	//Volt.log('original sourceCpText = '+sourceCpText + 'timeText = '+timeText);	

	var sourceCpLen = model.get('source').length;
	var enlargeText = null;

	if(sourceCpLen < 3) {
		enlargeText =  model.get('source') + '-'+ occurStamp;
	} else {
		var subsourceCp =  model.get('source').substr(0,2);
		enlargeText = subsourceCp + '...-'+occurStamp;
	}

	//var subsourceCp = model.get('source').substr(0,2);
	//var enlargeText = subsourceCp + '...-' + occurStamp;
	thumbnail.setInformationText("text5", enlargeText);
	thumbnail.visualizeInformationText(false, "text5");
	
	relatedItemViewSelf.updateNewsTextPos(thumbnail);

}
exports = DetailView;
