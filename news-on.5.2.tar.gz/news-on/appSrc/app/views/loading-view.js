var _           = Volt.require('modules/underscore.js')._;
var Backbone    = Volt.require('lib/volt-backbone.js');
var VoltJSON    = Volt.require('modules/VoltJSON.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var BaseView    = PanelCommon.BaseView;
var Global = Volt.require('app/common/Global.js');
var DeviceModel = Volt.require('app/common/deviceModel.js');

var LoadingTemplate2 = Volt.requireAppTemplate('newson-loading-template2.js');
//var LoadingDialog2   = Volt.require("app/common/loadingDialog2.js");
//PanelCommon.mapWidget('LoadingDialog2', LoadingDialog2);
var winsetLoading   = Volt.require("WinsetUIElement/winsetLoading.js");
//var winsetLoading   = Volt.require("modules/WinsetUIElement/winsetLoading.js");
PanelCommon.mapWidget('winsetLoading', winsetLoading);
var Q = PanelCommon.Q;

var LoadingView = BaseView.extend({
    loading01 : null,
    loading02 : null,
    isLoading : false,
    type : 1,  //default 01 loading
	initialize : function() {
		this.render();
	},
	render: function() {
        var tempTemplate = _.clone(LoadingTemplate2.loading);
        tempTemplate.children[0].style = winsetLoading.LoadingStyle.Loading_Dark_20;
        tempTemplate.children[0].nResoultionStyle = winsetLoading.ResoultionStyle.Resoultion_1080;
        this.loading01 = PanelCommon.loadTemplate(tempTemplate);
        this.loading01.opacity = 0;
        this.loading01.addEventListener('OnMouseOver', function() {});
        this.loading01.addEventListener('OnMouseClick', function() {});
        this.loading01.addEventListener('OnMouseOut', function() {});
        var text = this.loading01.getChild(1);
        text.x = (Volt.width - text.width)/2;
        //this.loading02 = PanelCommon.loadTemplate(LoadingTemplate2.loading2);
	},
	
	show : function(type) {
		var deferred =  Q.defer();
        if(type)
            this.type = type;
        else
            this.type = 1;
        switch(this.type) {
            case 1: {
                //scene.removeChild(this.loading01);
                Volt.WinsetRoot.addChild(this.loading01);//make the loading on the top
                this.loading01.opacity = 255;
                this.loading01.getChild(0).play();
                break;
            }
            case 2: {
                //this.loading02.play();
                break;
            }
            default: {
                //scene.removeChild(this.loading01);
                Volt.WinsetRoot.addChild(this.loading01);//make the loading on the top
                this.loading01.opacity = 255;
                this.loading01.getChild(0).play();
                break;
            }
        }
        //voiceguide start
        if (1 == DeviceModel.getMenuTTS()){
            var voiceText = 'loading, please wait.';
            Global.voiceGuide(voiceText, true);
        }
        //voiceguide end
		deferred.resolve();
        this.isLoading = true;
		return deferred.promise;
	},
	
	hide : function() {
		var deferred =  Q.defer();
		switch(this.type) {
            case 1: {
                this.loading01.opacity = 0;
                this.loading01.getChild(0).stop();
				Volt.WinsetRoot.removeChild(this.loading01);
                break;
            }
            case 2: {
                //this.loading02.stop();
                break;
            }
            default: {
                this.loading01.opacity = 0;
                this.loading01.getChild(0).stop();
				Volt.WinsetRoot.removeChild(this.loading01);
                break;
            }
        }
        this.isLoading = false;
		deferred.resolve();
		return deferred.promise;
	},
});

exports = new LoadingView();