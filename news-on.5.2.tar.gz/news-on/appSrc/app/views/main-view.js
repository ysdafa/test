/**
 * @author Weihua Qiu (weihua.qiu@samsung.com) / Hongjie Zhu (hongjie.zhu@samsung.com) / Yipeng Zhu (yipeng.zhu@samsung.com) / 
 * @fileoverview Description of a file
 * @date 2014/07/09 (last modified date)
 * 
 * Copyright 2012 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */

// Include libraries
var Backbone = Volt.require('lib/volt-backbone.js');

// Require Common Modules
var PanelCommon = Volt.require('lib/panel-common.js');
var BaseView = PanelCommon.BaseView;
var Q = PanelCommon.Q;
var CPAPI = Volt.require('app/common/CPAPI.js');
//var CpList = Volt.require('app/common/cpList.js');

// Include models
var ModelController = Volt.require('app/controller/model-controller.js');
var MainNewsModel = Volt.require('app/models/mainNewsModel.js');
var MoreNewsModel = Volt.require('app/models/moreNewsModel.js');
// Require Common templates of Main View
var MainTemplate = Volt.requireTemplate('main');
/*
var ImageWidgetEx = Volt.require('app/common/Crop.js');
PanelCommon.mapWidget('ImageWidgetEx', ImageWidgetEx);
*/
// Require Specific template for Games Main View
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');
var NewsonMainTemplate = Volt.requireAppTemplate('newson-main-template.js');
var NewsonMainDetailTemplate = Volt.requireAppTemplate('newson-main-detail-template.js');
var NewsonWeatherDetailImageTemplate = Volt.requireAppTemplate('newson-weather-detail-image-template.js');
var containerMap = NewsonMainTemplate.containerMap;
// Require Libs
_ = Volt.require('modules/underscore.js')._;
// Create an Mediator to commumicate between Views
var MainMediator = new PanelCommon.Mediator;
var LoadingDialog = Volt.require('app/views/loading-view.js');

var DeviceModel = Volt.require('app/common/deviceModel.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
//Require sub view
var dimView = PanelCommon.requireView('dim');

//Require global Variation
var Global = Volt.require('app/common/Global.js');
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
//KPI start
var KPI = Volt.require('app/common/kpi-options.js');
var KPIOptions = KPI.Home;
var KPILeaveContentIndex = 0;
//KPI end

var voltapi = Volt.require('voltapi.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
var ToolTip = Volt.require('app/views/tooltip-view.js');
var WinsetScroll = Volt.require("WinsetUIElement/winsetScroll.js");
//var WinsetScroll = Volt.require("modules/WinsetUIElement/winsetScroll.js");
//var WinsetSubList = Volt.require("modules/WinsetUIElement/winsetSubList.js");
var WinsetSubList = Volt.require('WinsetUIElement/winsetSubList.js');
var WinsetButton = Volt.require('WinsetUIElement/winsetButton.js');
PanelCommon.mapWidget('WinsetButton', WinsetButton);
////////////////////////////////////////////////////////////////////////////////
var mainViewSelf = null;
var thumbnailViewSelf = null; // can replaced by middleware MainMediator
var headViewSelf = null;
var weatherIndex = null; // for interval
var cycleSeconds = null;
function setInterval(cb, interval, param){
	return Volt.setInterval(cb, interval, param);
}

function clearInterval(id){
	if (id !== undefined) {
		Volt.clearInterval(id);
	}
}

////////////////////////////////////////////////////////////////////////////////
/** MainView -BackboneView
* @class 
* @name MainView
* @augments Backbone.View
*/
var MainView = BaseView.extend({
    
    /**
     * This property represents the default template in MainView.
     * @name template
     * @type JSON
     * @default MainTemplate.container
     * @fieldOf MainView.prototype
     */
    template : MainTemplate.container, // Template of Main View is a container framework
    
    /**
     * This property represents the main news model reference in MainView.
     * @name model
     * @type JSON
     * @default null
     * @fieldOf MainView.prototype
     */
    model : null,
    
    /**
     * This property represents the more news model reference in MainView.
     * @name model
     * @type JSON
     * @default null
     * @fieldOf MainView.prototype
     */
    moreNewsModel : null,
    
    /**
     * This property represents the child view's reference in MainView.
     * @name contentView
     * @type Class
     * @default null
     * @fieldOf MainView.prototype
     */
    contentView : null,
    
    /**
     * This property represents main news model request status.
     * @name mainNewsStatus
     * @type string
     * @default success
     * @fieldOf MainView.prototype
     */
    mainNewsStatus : 'success',
    
    /**
     * This property represents more news model request status.
     * @name mainNewsStatus
     * @type string
     * @default success
     * @fieldOf MainView.prototype
     */
    moreNewsStatus : 'success',
    
    /**
     * This property represents whether the view show in the first time.
     * @name firstTime
     * @type bool
     * @default true
     * @fieldOf MainView.prototype
     */
    firstTime : true,
    isFresh : true,
    isReadyForVoice : true,
    //troubleShoot: false,
    /** Initialize MainView. 
	* @function initialize
	* @memberof MainView
	*/
    
    /**
     * For record last focus in MainView
     */
    lastFocus : null,
    
    /**
     * For record the status for app status is or not active
     */
    isNeedSetFocus : false,
    
    initialize : function() {
        this.model = MainNewsModel;
        this.moreNewsModel = MoreNewsModel;
        this.loadingDialog = LoadingDialog;
        mainViewSelf = this;
        MainMediator.on(CommonDefines.Event.SHOW_OPTION_MENU, this.pause, this);
        MainMediator.on(CommonDefines.Event.HIDE_OPTION_MENU, this.resume, this);
        GlobalMediator.on(CommonDefines.Event.MAINVIEW_DATA_READY, this.renderForFirstTime, this);
        GlobalMediator.on(CommonDefines.Event.MAINVIEW_DATA_FAILED, this.mainNewsErrorHappend, this);
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('main-view initialize mem-size'+VDUtil.getProcMemory());
        }


    },

    /** render MainView. 
	* @function render
	* @memberof MainView
	*/
    render : function() {
        Volt.log();
        // Parse the template
        this.setWidget(Volt.mainViewWidget);
        //this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
        // Render everything
        
        Volt.Nav.setRoot(this.widget,{focus:null});
        this.block();
        this.renderHeader();
        this.renderPopup();
        this.renderCategory();
        this.renderContent();
        //this.listenTo(this.model, 'error', this.mainNewsErrorHappend);
        //this.listenTo(this.moreNewsModel, 'error', this.moreNewsErrorHappend);
        if('CN' == DeviceModel.get('countryCode')){
            var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
            this.listenTo(WeatherSettingModel, 'change:weatherSettingCodeCityList', function(){
                mainViewSelf.weatherSettingCodeCityListChange = true;
            });
        }
        Volt.log('render-----------------end');
    },
    
    /** callback of main view's model if the main view model fetch error. 
	* @function show
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
    * @param {string}  exception                  	- pass the exception
	* @memberof MainView
	*/
    mainNewsErrorHappend : function(object, status, exception) {
        Volt.log('mainNewsErrorHappend');
        if (mainViewSelf.errorView && mainViewSelf.errorView.isShow)
        {
            return;
        }
		//DeviceModel.setWaitingScreenAppVisibleConf(true);

        if(mainViewSelf.firstTime === true)
        {
            mainViewSelf.firstTime = false;
            mainViewSelf.lastFocus = Volt.Nav.getItem(0);
        }
        this.mainNewsStatus = 'failed';
        this.loadingDialog.hide();
        //Volt.Nav.resume();
		this.unblock();
		Volt.Nav.focus(null);
        print('main view error');
		var ErrorHandler = Volt.require('app/common/errorHandler.js');
        var errorCode = object?object.status : CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE;
        ErrorHandler.handleNetworkError(errorCode,this.setFocusForAppStatusChange);
    },

    /** callback of more view model if the more view model fetch error. 
	* @function show
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
    * @param {string}  exception                  	- pass the exception
	* @memberof MainView
	*/
    moreNewsErrorHappend : function(object, status, exception) {
        Volt.log('moreNewsErrorHappend');

		//DeviceModel.setWaitingScreenAppVisibleConf(true);

        if(mainViewSelf.firstTime === true)
        {
            mainViewSelf.firstTime = false;
            mainViewSelf.lastFocus = Volt.Nav.getItem(0);
        }
        this.moreNewsStatus = status;
        this.loadingDialog.hide();
        //Volt.Nav.resume();
		this.unblock();
		Volt.Nav.focus(null);
		var ErrorHandler = Volt.require('app/common/errorHandler.js');
        var errorCode = object?object.status : CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE;
        ErrorHandler.handleNetworkError(errorCode,this.setFocusForAppStatusChange);
    },
	
	/**
     */
    setFocusForAppStatusChange : function() {
        Volt.log('lastFocus - ' + mainViewSelf.lastFocus);
        Volt.log('Global.APP_STATUS - ' + Global.APP_STATUS);
        mainViewSelf.isNeedSetFocus = false;
        if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
            mainViewSelf.isNeedSetFocus = true;
        } else {
            mainViewSelf.isNeedSetFocus = false;
            Volt.Nav.focus(mainViewSelf.lastFocus);
        }
     },
    
    /** block this view's event. 
	* @function block
	* @memberof MainView
	*/
    block : function()
    {
        Volt.Nav.block('key');
        Volt.Nav.block('mouse');
    },
    
    /** unblock this view's event. 
	* @function unblock
	* @memberof MainView
	*/
    unblock : function()
    {
        Volt.Nav.unblock('key');
        Volt.Nav.unblock('mouse');
    },
    
    /** refresh main view's content. 
	* @function contentFresh
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
	* @memberof MainView
	*/
    renderForFirstTime : function(offline) {
        Volt.log();
		//DeviceModel.setWaitingScreenAppVisibleConf(true);
		//Stage.show();
        mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.hideCloseOptionMenuX;
        if (this.mainNewsStatus != 'success' || this.moreNewsStatus != 'success')
            return;
        /*
        if(!offline)
        {
            this.loadingDialog.hide();
        }*/
        this.loadingDialog.hide();
        this.categoryView.show(this.model, this.moreNewsModel);
        Volt.log('show contentView');
        this.contentView.show(this.model, this.moreNewsModel);
        Volt.Nav.reload();
        if(mainViewSelf.firstTime === true)
        {
            mainViewSelf.firstTime = false;
            mainViewSelf.lastFocus = thumbnailViewSelf.widget;
        }
        mainViewSelf.setFocusForAppStatusChange();
        if(thumbnailViewSelf !== null){
            thumbnailViewSelf.openTimerAndEvent();
        }
        this.unblock();
        GlobalMediator.off(CommonDefines.Event.MAINVIEW_DATA_READY);
        GlobalMediator.on(CommonDefines.Event.MAINVIEW_DATA_READY, this.mainViewUpdate, this);
    },
    mainViewUpdate : function(offline)
    {
        categorySelf.trigger('refresh');
        mainViewSelf.contentView.trigger('refresh');
        if(!offline)
        {
            this.loadingDialog.hide();
        }
    },
    /** render header view 
	* @function renderHeader
	* @memberof MainView
	*/
    renderHeader : function() {
        Volt.log();
        var container = this.widget.getDescendant('main-header-container');
		this.headerView = new HeaderView();
        container.addChild(this.headerView.render().widget);
    },

    /** render category view 
	* @function renderCategory
	* @memberof MainView
	*/
    renderCategory : function() {
        Volt.log();
        var container = this.widget.getChild('main-category-container');
        this.categoryView = new CategoryView();
        container.addChild(this.categoryView.render().widget);
    },

    /** render content view 
	* @function renderContent
	* @memberof MainView
	*/
    renderContent : function() {
        Volt.log('renderContent');
        var container = this.widget.getChild('main-content-container');
        this.contentView = new ContentView();
        this.contentView.render(container);
        if(-1 == DeviceModel.getNetWorkState()){
            Volt.log('errorView');
            this.contentView.disableView();
            if('CN' == DeviceModel.get('countryCode') && this.headerView){
                this.headerView.disableView();
            }
            this.errorView = new ErrorView();
            this.errorView.render(container);
            this.unblock();
            this.errorView.show();
        }
    },
    
    
    /** render Popup view 
	* @function renderPopup
	* @memberof MainView
	*/
    renderPopup : function() {
        Volt.log();
        this.popupView = new PopupView();
        this.popupView.render(this.widget.getChild('main-popup-container'));
    },
    
    /** show the main view 
	* @function show
    * @param {Object}  options                  	- the parameter
	* @param {string}  animationType          		-animation type
	* @memberof MainView
	*/
    show : function(options, animationType) {
        Volt.log();
        var deferred = Q.defer();
        if(!DeviceModel.getHighContrast()){
            Volt.WinsetRoot.color = Volt.hexToRgb('#0f1826');
        }
        Volt.WinsetRoot.setBackgroundColor(Volt.hexToRgb('#0f1826'));
        this.widget.show();
        if(this.firstTime !== true){
            Volt.log('firstTime----not true');
            Volt.Nav.setRoot(this.widget,{focus:null});
        }
        this.headerView.show();
        headViewSelf.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, headViewSelf.onChangeCursor);
        if(thumbnailViewSelf !== null){
            thumbnailViewSelf.closeTimerAndEvent();
        }
        if (this.mainNewsStatus != 'success' || this.moreNewsStatus != 'success') {
            Volt.log();
            mainViewSelf.setFocusForAppStatusChange();
            if(thumbnailViewSelf !== null){
                thumbnailViewSelf.openTimerAndEvent();
            }
            deferred.resolve();
            return deferred.promise;
        }
        Volt.log();
        //till now every thing is fine
        if(this.firstTime !== true) {
            Volt.log();
            if(this.weatherSettingCodeCityListChange === true){
                Volt.log();
                this.weatherSettingCodeCityListChange = false;
                thumbnailViewSelf.weatherDataRefresh();
            }
            mainViewSelf.setFocusForAppStatusChange(); // set last focus
        }
        if(thumbnailViewSelf !== null){
            thumbnailViewSelf.openTimerAndEvent();
        }
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON) {
            print('main view show');
            print(VDUtil.getProcMemory());
        }
        this.listenTo(DeviceModel, 'change:languageCode', this.updateTextbyLang);
        deferred.resolve();
        return deferred.promise;
    },

    updateTextbyLang : function(){
        thumbnailViewSelf.updateTextbyLang();
        selfPopupView.updateTextbyLang();
    },

    /** hide the main view 
	* @function hide
	* @param {string}  animationType          		-animation type
	* @memberof MainView
	*/
    hide : function(options, animationType) {
        var deferred = Q.defer();
        Volt.Nav.blur();
        headViewSelf.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        if(thumbnailViewSelf !== null){
            thumbnailViewSelf.closeTimerAndEvent();
        }
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('main view hide');
            gc();
            print(VDUtil.getProcMemory());
        }
        this.widget.hide();
        deferred.resolve();
        return deferred.promise;
    },
    /**
     * pause the main view Invoked when some popup view popup over this View
     * @function
     * @memberof MainView
     */
    pause : function() {
        Volt.log();
        this.isReadyForVoice = false;
        this.isFresh = true;
        if(headViewSelf !== null){
            headViewSelf.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        }
        if(mainViewSelf.popupView.isShown) {
            mainViewSelf.popupView.hide();
        }
        dimView.show({
            parent: this.widget.getChild('main-dim-container')
        });
        mainViewSelf.isNeedSetFocus = true;
    },
    /**
     * Invoked when come back from popup
     * @function
     * @memberof MainView
     */
    resume : function(options) {
        Volt.log();
        this.isReadyForVoice = true;
        //this.isFresh = true;
        dimView.hide();
        if(headViewSelf){
            Volt.log('head view update');
            headViewSelf.show(); //check if show "x" or not
        }
        if(headViewSelf !== null){
            headViewSelf.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, headViewSelf.onChangeCursor);
        }
        Volt.log('this.firsTime'+this.firstTime);
        //if troubleshoot is true
        if(Global.NETWORK_CONFIG_LAUNCH && this.firstTime && !LoadingDialog.isLoading){
            Global.NETWORK_CONFIG_LAUNCH = false;
            if(DeviceModel.getNetWorkState() == -1){
                
            }else{
                mainViewSelf.errorView.hide();  //
                mainViewSelf.contentView.enableView();
                //refetch data
                LoadingDialog.show(1);
                CPAPI.initialize().then(function(){
                    ModelController.ready().then(function(result){
                        if(result && 'CN' == DeviceModel.get('countryCode') && mainViewSelf.headerView){
                            mainViewSelf.headerView.enableView();
                        }
                        LoadingDialog.hide();
                    });
                });
                return;
            }
        }
        
        if( voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE) && mainViewSelf.lastFocusForClose != null){
            if(mainViewSelf.lastFocusForClose != null){
                if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                    mainViewSelf.lastFocus = mainViewSelf.lastFocusForClose;
                }else{
                    Volt.Nav.focus(mainViewSelf.lastFocusForClose);
                }
                mainViewSelf.lastFocusForClose = null;
            }
        } else {
            Volt.log('mainViewSelf.isNeedSetFocus'+mainViewSelf.isNeedSetFocus);
            if(mainViewSelf.isNeedSetFocus){
                Volt.Nav.blur();
                if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                    
                }else{
                    Volt.Nav.focus(mainViewSelf.lastFocus);
                }
                
            }
        }
    },
    /*
    hideCustomPopups : function() {
        if (this.popupView.optionMenu != null){
            MainMediator.trigger(CommonDefines.Event.HIDE_OPTION_MENU, {
                type : 'OPTION_MENU'
            });
        }
    },*/
    
    onKeyEvent : function(keyCode, keyType) {
    	Volt.log('MainView onKeyEvent'+keyCode+keyType);
        
		if(mainViewSelf.popupView) {
			if(mainViewSelf.popupView.isShown) {
				Volt.log('optionmenu is showing');
				if(keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS){
					Volt.log('hide optionmenu');				
					mainViewSelf.popupView.hide(true);
					mainViewSelf.headerView.onFocusSetting();
					//mainViewSelf.popupView.isShown = false;
				}
				return true;
			}
		}
        
        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {
            mainViewSelf.isNeedSetFocus = true;
        }
    }
});
/**
 * HeaderView -BackboneView
 * @class
 * @name HeaderView
 * @augments Backbone.View
 */
var HeaderView = BaseView.extend({
    
    /**
     * This property represents the default template in HeaderView.
     * @name template
     * @type JSON
     * @default NewsonMainTemplate.header
     * @fieldOf HeaderView.prototype
     */
    template : NewsonMainTemplate.header,
    
    /** Initialize HeaderView. 
	* @function initialize
	* @memberof HeaderView
	*/
    initialize : function () {
        //
        //MainMediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink);
        //MainMediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand);
        //KPI start
        this.KPISelectSetting = new KPIOptions.SelectSetting(this);
        headViewSelf = this;
	//KPI end
        MainMediator.on(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON, function(){
            if('CN' == DeviceModel.get('countryCode')){
                Volt.log(DeviceModel.get('countryCode'));
                this.settingButton.show();
                this.devideOne.show();
                if(!this.settingButton.custom) {
                    this.settingButton.custom = {};
                }
                this.settingButton.custom.focusable = true;
                Volt.Nav.reload();
            } else {
                Volt.log(DeviceModel.get('countryCode'));
                this.settingButton.hide();
                this.devideOne.hide();
                if(!this.settingButton.custom) {
                    this.settingButton.custom = {};
                }
                this.settingButton.custom.focusable = false;
                Volt.Nav.reload();
                if(thumbnailViewSelf) {
                    mainViewSelf.setFocusForAppStatusChange();
                }
            }
        }.bind(this));
    },
    /** render HeaderView. 
	* @function render
	* @memberof HeaderView
	*/
    render : function() {
        Volt.log();
        this.widget = PanelCommon.loadTemplate(this.template);
        this.tools = this.widget.getDescendant('main-header-tools');
        this.devideOne = this.widget.getDescendant('main-header-icon-divide-one');
        this.renderSettingButton();
        this.renderCloseButton();
        this.setWidget(this.widget);
        var buttonListener = new ButtonListener();
        buttonListener.onButtonClicked = function(Button, type) {
            if(headViewSelf !== null && Button.id === 'main-header-icon-setting'){
                headViewSelf.onSelectSetting(Button);
            }else if(headViewSelf !== null && Button.id === 'main-header-icon-close' && type === 'mouse'){
                headViewSelf.onSelectClose(Button);
            }
        };//.bind(this);
        this.settingButton.addListener(buttonListener);
        this.closeButton.addListener(buttonListener);
        MainMediator.trigger(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON);
        return this;
    },
    
    renderSettingButton : function(){
        this.settingButton = this.widget.getDescendant('main-header-icon-setting');
        this.settingButton.setBackgroundImage({
            state: "focused",
            src: ResourceMgr.FocusGrid//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.setBackgroundImage({
            state: "normal",
            src: "",//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png'),
        });
        this.settingButton.setIconAlpha({
            state: "normal",
            alpha: 255 * 0.6
        });
        this.settingButton.setIconAlpha({
            state: "disabled",
            alpha: 255 * 0.6
        });
        this.settingButton.setBackgroundImage({
            state: "roll-over",
            src: ResourceMgr.FocusGrid//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.setBackgroundImage({
            state: "focused-roll-over",
            src: ResourceMgr.FocusGrid//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.setBackgroundImage({
            state: "disabled",
            src: "",//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png'),
        });
        this.settingButton.setBackgroundImage({
            state: "disabled-focused",
            src: ResourceMgr.FocusGrid//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.setBackgroundImage({
            state: "selected",
            src: ResourceMgr.FocusGrid//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_sel.png'),
        });
        this.settingButton.setBackgroundColor({
            state: "all",
            color: Volt.hexToRgb('#0f1826',0),
        });
        this.settingButton.setIconScaleFactor({
            state: "focused-roll-over",
            scaleX: 1.1,
            scaleY: 1.1,
        });
        this.settingButton.setIconScaleFactor({
            state: "roll-over",
            scaleX: 1.1,
            scaleY: 1.1,
        });
        Volt.Nav.setNextItemRule(this.settingButton,"left",this.settingButton);
        Volt.Nav.setNextItemRule(this.settingButton,"right",this.settingButton);
        var mouseListener = new MouseListener;
        mouseListener.onMousePointerIn = function(widget){
            Volt.log('setting button onMousePointerIn');
            var opt = {
    			text: Volt.i18n.t('UID_OPTIONS'),
    			x: widget.getAbsolutePosition().x,
    			y: widget.getAbsolutePosition().y,
    			width: widget.width,
    			height: widget.height,
    			direction:'up',
    			parent:widget
    		};
    		ToolTip.show(opt, CommonTemplate.tooltip);
        };
        this.settingButton.addMouseListener(mouseListener);
    },
    
    renderCloseButton : function(){
        this.closeButton = this.widget.getDescendant('main-header-icon-close');
        this.closeButton.setIconAlpha({
            state: "normal",
            alpha: 255 * 0.6
        });
        this.closeButton.setIconAlpha({
            state: "disabled",
            alpha: 255 * 0.6
        });
        this.closeButton.setBackgroundImage({
            state: "focused",
            src: ResourceMgr.FocusGrid,
        });
        this.closeButton.setBackgroundImage({
            state: "normal",
            src: '',
        });
        this.closeButton.setBackgroundImage({
            state: "roll-over",
            src: ResourceMgr.FocusGrid,
        });
        this.closeButton.setBackgroundImage({
            state: "focused-roll-over",
            src: ResourceMgr.FocusGrid,
        });
        this.closeButton.setBackgroundImage({
            state: "disabled",
            src: '',
        });
        this.closeButton.setBackgroundImage({
            state: "disabled-focused",
            src: ResourceMgr.FocusGrid,
        });
        this.closeButton.setBackgroundImage({
            state: "selected",
            src: ResourceMgr.FocusGrid,
        });
         this.closeButton.setBackgroundColor({
            state: "all",
            color: Volt.hexToRgb('#0f1826',0),
        });
        this.closeButton.setIconScaleFactor({
            state: "focused-roll-over",
            scaleX: 1.1,
            scaleY: 1.1,
        });
        this.closeButton.setIconScaleFactor({
            state: "roll-over",
            scaleX: 1.1,
            scaleY: 1.1,
        });
        Volt.Nav.setNextItemRule(this.closeButton,"left",this.closeButton);
        Volt.Nav.setNextItemRule(this.closeButton,"right",this.closeButton);
        Volt.Nav.setNextItemRule(this.closeButton,"up",this.closeButton);
        Volt.Nav.setNextItemRule(this.closeButton,"down",this.closeButton);
        var mouseListener = new MouseListener;
        mouseListener.onMousePointerIn = function(widget){
            Volt.log('close button onMousePointerIn');
            var opt = {
    			text: Volt.i18n.t('COM_SID_EXIT'),
    			x: widget.getAbsolutePosition().x,
    			y: widget.getAbsolutePosition().y,
    			width: widget.width,
    			height: widget.height,
    			direction:'up',
    			parent:widget
    		};
    		
    		ToolTip.show(opt, CommonTemplate.tooltip);
        };
        this.closeButton.addMouseListener(mouseListener);
    },
    show : function(){
        if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
            Volt.log();
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.hideCloseOptionMenuX;
            if(this.closeButton){
                this.tools.x = NewsonMainTemplate.constNum.hideCloseToolX;
                this.closeButton.hide();
                this.closeButton.custom.focusable = false;
                Volt.Nav.reload();
            }
        } else {
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.showCloseOptionMenuX;
            if(this.closeButton){
                this.tools.x = NewsonMainTemplate.constNum.showCloseToolX;
                this.closeButton.show();
                this.closeButton.custom.focusable = true;
                Volt.Nav.reload();
            }
        }
    },
    onChangeCursor : function(visible) {
        Volt.log('visible - ' + visible);
        if (visible) {
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.showCloseOptionMenuX;
            if (this.closeButton) {
                this.tools.x = NewsonMainTemplate.constNum.showCloseToolX;
                this.closeButton.show();
                this.closeButton.custom.focusable = true;
                if (ToolTip.isShown()){
                    ToolTip.hide();
                    var opt = {
            			text: Volt.i18n.t('UID_OPTIONS'),
            			x: this.settingButton.getAbsolutePosition().x,
            			y: this.settingButton.getAbsolutePosition().y,
            			width: this.settingButton.width,
            			height: this.settingButton.height,
            			direction:'up',
            			parent:this.settingButton
            		};
            		ToolTip.show(opt, CommonTemplate.tooltip);
                }
                Volt.Nav.reload();
            }
        } else {
            mainViewSelf.optionMenuX = NewsonMainTemplate.constNum.hideCloseOptionMenuX;
            if (this.closeButton) {
                this.tools.x = NewsonMainTemplate.constNum.hideCloseToolX;
                this.closeButton.hide();
                this.closeButton.custom.focusable = false;
                if (ToolTip.isShown()){
                    ToolTip.hide();
                    var opt = {
            			text: Volt.i18n.t('UID_OPTIONS'),
            			x: this.settingButton.getAbsolutePosition().x,
            			y: this.settingButton.getAbsolutePosition().y,
            			width: this.settingButton.width,
            			height: this.settingButton.height,
            			direction:'up',
            			parent: this.settingButton
            		};
            		ToolTip.show(opt, CommonTemplate.tooltip);
                }
                Volt.Nav.reload();
                if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                } else {

					if(mainViewSelf.lastFocus) {                
                   		Volt.Nav.focus(mainViewSelf.lastFocus);

						if(mainViewSelf.lastFocus.id == 'main-content-grid'){
							if(thumbnailViewSelf) {
								thumbnailViewSelf.showEnlargeText();
							}
						}						

					}
                }
            }
        }
    },
    
    events : {
        //'NAV_SELECT #main-header-icon-setting' : 'onSelectSetting',
        //'NAV_SELECT #main-header-icon-close' : 'onSelectClose',

        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },
    
    /** headerView's focus callback. 
	* @function onFocus
    * @param {Widget}  widget                  	- the widget is focused
	* @memberof HeaderView
	*/
    onFocus : function(widget) {
        Volt.log('HeaderView.focus - ' + widget.id);

        if(widget != this.closeButton) {
            mainViewSelf.lastFocus = widget;
        }
        if(widget && widget.getChildCount() > 0)
        {
            widget.setFocus();
            /*
            widget.setIconAttr({
                x: (Volt.width * 0.052604 + Volt.width*8/1920 - Volt.width*36*1.1/1920)/2,
                y: (Volt.height * 0.133333 + Volt.height*8/1080 - Volt.height*36*1.1/1080)/2,
                width: Volt.width*36*1.1/1920,
                height: Volt.height*36*1.1/1080,
            });*/
            //set voice guide
            if (1 == DeviceModel.getMenuTTS()){
                var voiceText = 'Options, button';
                Global.voiceGuide(voiceText);
            }

            //show tooltip
            if(widget.id == 'main-header-icon-setting'){
                var opt = {
        			text: Volt.i18n.t('UID_OPTIONS'),
        			x: this.settingButton.getAbsolutePosition().x,
        			y: this.settingButton.getAbsolutePosition().y,
        			width: this.settingButton.width,
        			height: this.settingButton.height,
        			direction:'up',
        			parent:this.settingButton
        		};
        		
        		ToolTip.show(opt, CommonTemplate.tooltip);
            } else {
                var opt = {
        			text: Volt.i18n.t('COM_SID_EXIT'),
        			x: this.closeButton.getAbsolutePosition().x,
        			y: this.closeButton.getAbsolutePosition().y,
        			width: this.closeButton.width,
        			height: this.closeButton.height,
        			direction:'up',
        			parent:this.closeButton
        		};
        		
        		ToolTip.show(opt, CommonTemplate.tooltip);
            }
        }
    },
    
    disableView : function(){
        Volt.log('disable header view');
        if(this.settingButton){
            this.settingButton.custom.focusable = false;
            this.settingButton.enable(false);
            Volt.Nav.reload();
        }
    },
    
    enableView: function(){
        Volt.log('enable header view');
        if(this.settingButton){
            this.settingButton.custom.focusable = true;
            this.settingButton.enable(true);
            Volt.Nav.reload();
        }
    },
    
	onFocusSetting: function() {
		Volt.log('onFocusSetting');
        Volt.Nav.blur();
        if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
        } else {
            Volt.Nav.focus(mainViewSelf.lastFocus);
        }
    },	

    /** headerView's blur callback. 
	* @function onBlur
    * @param {Widget}  widget                  	- the widget is blurred
	* @memberof HeaderView
	*/
    onBlur : function(widget) {
        Volt.log('HeaderView.onBlur - ' + widget.id);
        if(widget)
        {
            widget.killFocus();
            //hide tooltip
            ToolTip.hide();
        }
    },
    
    /** headerView's selected callback. 
	* @function onSelectSetting
    * @param {Widget}  widget                  	- the widget is selected
	* @memberof HeaderView
	*/
    onSelectSetting : function(widget) {
        Volt.log();
		//this.onBlur(this.settingButton);
        Volt.Nav.blur();
		
        //KPI start
        var previousLocation = 0;
        if (5 == KPILeaveContentIndex){
            previousLocation = 10;
        }else if (thumbnailViewSelf != null){
            if (KPILeaveContentIndex>5)KPILeaveContentIndex--;
            var range = thumbnailViewSelf.widget.getOnScreenRange();
            previousLocation = KPILeaveContentIndex - range.startItemIndex + 1;
        }
        KPILeaveContentIndex = 0; //reset
        
        this.KPISelectSetting.send({pl : 'P-L-'+((previousLocation<10)?'0':'') + previousLocation.toString()});
        mainViewSelf.popupView.show();
        //KPI end
        /*
        MainMediator.trigger(CommonDefines.Event.SHOW_OPTION_MENU, {
            type : CommonDefines.PopupType.OPTION_MENU
        });*/
    },
    
    /** headerView's selected callback. 
     * @function onSelectClose
     * @param {Widget}  widget                   - the widget is selected
     * @memberof HeaderView
     */
    onSelectClose : function(widget) {
         Volt.log();
         ToolTip.hide();
         
         mainViewSelf.lastFocusForClose = widget;
         Volt.log('newson exit');
         //kpi log start
         Global.ExitWayForKPILog.set('POINTING_X');
         Global.LeaveWayForKPILog.set('POINTING_X');
         Global.LeaveByReturnForKPILog.set(true);
         //kpi log end
         Volt.exit();
     },

    /*expand : function() {
        Volt.log('HeaderView.expand');
        this.headerView.widget.animate('y', 0, MENU_ANIM_DURATION);
    },

    shrink : function() {
        Volt.log('HeaderView.shrink');
        this.headerView.widget.animate('y', -18, MENU_ANIM_DURATION);
    }*/
});
var categorySelf = null;
/** CategoryView -BackboneView
* @class 
* @name CategoryView
* @augments Backbone.View
*/ 
var CategoryView = BaseView
        .extend({
            
            /**
             * This property represents the default template in CategoryView.
             * @name template
             * @type JSON
             * @default NewsonMainTemplate.category
             * @fieldOf CategoryView.prototype
             */
            template : NewsonMainTemplate.category,
            
            /**
             * This property represents the related model reference in CategoryView.
             * @name model
             * @type Object
            * @default NewsonMainTemplate.category
             * @fieldOf CategoryView.prototype
             */
			model : null,
            /** Initialize CategoryView. 
            * @function initialize
            * @memberof CategoryView
            */
            initialize : function() {
                categorySelf = this;
                //MainMediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.expand);
                //MainMediator.on('EVENT_MAIN_CATEGORY_BLUR', this.shrink);
                this.listenTo(this, 'refresh', this.refresh);
            },
            
           /** render CategoryView. 
            * @function render
            * @param {Object}  model          		- main news' model based on 2014 yahoo API
            * @memberof CategoryView
            */
            render : function() {
                var mustash = null;
                mustash = {
                    cpLogo : null,
                    properity : null,
                };
                var tmpWidget = PanelCommon.loadTemplate(this.template, mustash);
                if(DeviceModel.getHighContrast()){
                    tmpWidget.getChild('properity').textColor = Volt.hexToRgb('#ffffff', 100);
                }
                var widgetExListener = new WidgetExListener;
                widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
                    if(widgetEx.getChildCount() > 0 && widgetEx.getChild('properity')){
                        if(flagHighContrast){
                            widgetEx.getChild('properity').textColor = Volt.hexToRgb('#ffffff', 100);
                        }else{
                            widgetEx.getChild('properity').textColor = Volt.hexToRgb('#ffffff', 30);
                        }
                    }
                }
                tmpWidget.addWidgetExListener(widgetExListener);
                this.setWidget(tmpWidget);
                return this;
            },
            show : function(model,moreNewsModel){
                this.model = model;
                this.moreNewsModel = moreNewsModel;
                if(CPAPI.getServiceType() == 'sina_huafeng') {
                    categorySelf.widget.getChild('cpLogo').src = null;//Volt.getRemoteUrl('images/1080/news_cp_icon_sina_b.png');
                    categorySelf.widget.getChild('cpLogo').opacity = 0;
                } else {
                   categorySelf.widget.getChild('cpLogo').src = categorySelf.moreNewsModel.get('brand_img_url');//ResourceMgr.NewsCpIconYahooBrasil;//Volt.getRemoteUrl('images/1080/news_cpicon_yahoo_brasil.png');
                   categorySelf.widget.getChild('cpLogo').opacity = 255;
                }
                if(categorySelf.model.get('tos_text') !== undefined) {
                    categorySelf.widget.getChild('properity').text = categorySelf.model.get('tos_text')+'';
                }
                else {
                   categorySelf.widget.getChild('properity').text = '';
                }
            },
            refresh : function()
            {
                if(categorySelf.widget.getChildCount() > 0)
                {
                    if(CPAPI.getServiceType() == 'sina_huafeng')
                    {
                        categorySelf.widget.getChild('cpLogo').src = null;//Volt.getRemoteUrl('images/1080/news_cp_icon_sina_b.png');
                        categorySelf.widget.getChild('cpLogo').opacity = 0;
                    }
                    else
                    {
                       categorySelf.widget.getChild('cpLogo').src = categorySelf.moreNewsModel.get('brand_img_url');//ResourceMgr.NewsCpIconYahooBrasil;//Volt.getRemoteUrl('images/1080/news_cpicon_yahoo_brasil.png');
                       categorySelf.widget.getChild('cpLogo').opacity = 255;
                   }
                    if(categorySelf.model.get('tos_text') !== undefined)
                    {
                        categorySelf.widget.getChild('properity').text = categorySelf.model.get('tos_text')+'';
                   }
                    else
                    {
                       categorySelf.widget.getChild('properity').text = '';
                    }
                    
               }
            },
            
            events : {
                'NAV_SELECT' : 'onSelect',
                'NAV_FOCUS' : 'onFocus',
                'NAV_BLUR' : 'onBlur'
            },
            
            /** CategoryView's focus callback. 
            * @function onFocus
            * @param {Widget}  widget                  	- the widget is focused
            * @memberof CategoryView
            */
            onFocus : function(widget) {
                mainViewSelf.lastFocus = widget;
                widget.setFocus();
            },
            
            /** CategoryView's blur callback. 
            * @function onBlur
           * @param {Widget}  widget                  	- the widget is blurred
            * @memberof CategoryView
            */
            onBlur : function(widget) {
                widget.killFocus();
            },
            
            /** CategoryView's select callback. 
            * @function onSelect
            * @param {Widget}  widget                  	- the widget is selected
            * @memberof CategoryView
            */
           onSelect : function(widget) {
            },
            /*expand : function() {
                this.categoryView.widget.animate('y', -36, MENU_ANIM_DURATION);
                this.categoryView.widget.animate('height', 108, MENU_ANIM_DURATION);
               this.categoryView.widget.getChild(0).animate('y', 18, MENU_ANIM_DURATION);
            },

           shrink : function() {
                this.categoryView.widget.animate('y', 0, MENU_ANIM_DURATION);
                this.categoryView.widget.animate('height', 72, MENU_ANIM_DURATION);
                this.categoryView.widget.getChild(0).animate('y', 0, MENU_ANIM_DURATION);
            }*/

       });



var mustashWeather = {
    src : null,
    defaultSrc : null,
    currentConditionIcon : null,
    location : null,
    currentConditions : null,
    todayHighTemp : null,
    todayLowTemp : null,
    currentTemp : null,
    photoAttribute : null,
};

//var weatherTileCollection = null;
var weatherTileModel = null;

var mustash = {
    src : null,
    title : null,
    time : null,
};
/** ContentView -BackboneView
* @class 
* @name ContentView
* @augments Backbone.View
*/ 
var ContentView = BaseView.extend({

    /**
     * This property represents the default template in ContentView.
     * @name template
     * @type JSON
     * @default NewsonMainTemplate.content
     * @fieldOf ContentView.prototype
     */
    template : NewsonMainTemplate.content,
    layoutCache : [],
    //maxItemSize : 1024,
    map : [],
    weatherSwitchTimer : null,
    firstTime : true,
    freshTimer : null,
	weatherCityIdx : 0,
    moreNewsCount : 0,
    moreNewsMaxSize : 1,
    tileCollection : null,
    //_stuffviewContainer :[],
    //_stuffViewHead:0,
    //_stuffViewTail:0,
    newsCount : 0,
    /** Initialize ContentView. 
    * @function initialize
    * @memberof ContentView
    */
    initialize : function () {
        //this.__initLayout();
        thumbnailViewSelf = this;
        //this.listenTo(this, 'update', this.updateChildView);
        this.listenTo(this, 'refresh', this.refresh);
        //KPI start
        this.KPISelectNews = new KPIOptions.SelectNews(this);
        this.KPISelectWeather = new KPIOptions.SelectWeather(this);
        //KPI end

        //magickey for debug
        Global.MagicKey.addListener(CommonDefines.Magic.SHOW_TIMESTAMP, function(){
            var thumbnail = thumbnailViewSelf.widget.renderer(0, 0).thumbnail;
            var postion = thumbnailViewSelf.map[0];
            var tile = thumbnailViewSelf.tileCollection.at(postion);

            var counter = 0;
            var source = tile.get('source');
            var originalText = tile.get('stringstamp');
            var timeStamp = '';

            var timestamps = ['Just Now', '1 min ago', '5 mins ago', '1 hr ago' , '10 hrs ago', '1d ago', '2ds ago'];
            var interval = Volt.setInterval(function(){
                timeStamp = timestamps[counter];
                ++counter;
                if(counter > timestamps.length){
                    timeStamp = originalText;
                    Volt.clearInterval(interval);
                }
                thumbnail.setInformationText("text2", source+' - '+timeStamp);
            }, 1000);
        });
    },
    
    events : {
        'NAV_SELECT':'onSelect',
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },
    
    __loadTemplate : function(parent, parentHeight, index){
        Volt.log('parentHeight - ' + parentHeight + ' index - ' + index);
        var thumbnail = undefined;
        var isSinaHuafeng = (CPAPI.getServiceType() == 'sina_huafeng');
        if (parentHeight == containerMap.news_thumbnail1.height) {
            if (index != 5) {
                thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_news_thumbnail1, null, parent).getChild(2);
				thumbnail.type = 'news_thumbnail1';
                /*if(isSinaHuafeng){
                    thumbnail.setElementAllocation("information-text2", {
                        x:containerMap.news_thumbnail1.time.x,
                        width:containerMap.news_thumbnail1.time.width
                    });
                }else{
                    thumbnail.setElementAllocation("information-text2", {
                        x:containerMap.news_thumbnail1.time.x,
                        width:containerMap.news_thumbnail1.title.width
                    });
                }*/
            } else{
                thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_weather_thumbnail, null, parent).getChild(2);
            }
        } else if (parentHeight == containerMap.news_thumbnail2.height) {
            thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_news_thumbnail2, null, parent).getChild(2);
			thumbnail.type = 'news_thumbnail2';

            /*if(isSinaHuafeng){
                thumbnail.setElementAllocation("information-text2", {
                    x:containerMap.news_thumbnail2.time.x,
                    width:containerMap.news_thumbnail2.time.width
                });
            }else{
                thumbnail.setElementAllocation("information-text2", {
                    x:containerMap.news_thumbnail2.time.x,
                    width:containerMap.news_thumbnail2.title.width
                });
            }*/
        } else if (parentHeight == containerMap.news_thumbnail3.height) {
            thumbnail = PanelCommon.loadTemplate(NewsonMainDetailTemplate.container_news_thumbnail3, null, parent).getChild(2);
			thumbnail.type = 'news_thumbnail3';

			/*if(isSinaHuafeng){
                thumbnail.setElementAllocation("information-text2", {
                    x:containerMap.news_thumbnail3.time.x,
                    width:containerMap.news_thumbnail3.time.width
                });
            }else{
                thumbnail.setElementAllocation("information-text2", {
                    x:containerMap.news_thumbnail3.time.x,
                    width:containerMap.news_thumbnail3.title.width
                });
            }*/
        }

        //apply highcontrast
        if (true == DeviceModel.get('highContrast')){
            this.updateHighContrast(thumbnail, index);
        }

        //add highcontrast listener
        var widgetExListener = new WidgetExListener;
        widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
            Volt.log("flagHighContrast is " + flagHighContrast);
            if(true == flagHighContrast){
                thumbnailViewSelf.updateHighContrast(widgetEx, index);
            }else{
                widgetEx.color = Volt.hexToRgb('#d4d4d4', 100);
            }
        },

		widgetExListener.onEnlargeChanged  = function (widgetEx, flagEnlarge) {
            Volt.log("Enlarge is " + flagEnlarge);

			if ((CPAPI.getServiceType() == 'sina_huafeng')) // china cp
            {	
            	var listItem = thumbnailViewSelf.widget.renderer(0, 5);
				if((listItem == null) || (listItem == undefined)){
					Volt.log("listItem is undefined!");
					return;
				}

			    var thumbnail = thumbnailViewSelf.widget.renderer(0, 5).thumbnail;

				if(thumbnail == undefined){
					Volt.log("thumbnail is undefined!");
					return;
				}

                if(flagEnlarge) {
                    thumbnail.visualizeAttachIcon(false, "icon1");
                    thumbnail.visualizeInformationIcon(true, "icon4"); 
                } else {
                    thumbnail.visualizeAttachIcon(true, "icon1");
                    thumbnail.visualizeInformationIcon(false, "icon4"); 
                }                
            }
      
        },
		
        thumbnail.addWidgetExListener(widgetExListener);
		thumbnail.widgetExListener = widgetExListener;
        
        return thumbnail;
    },
    
    updateHighContrast : function(thumbnail, index){
        if (0 == index%5 || 4 == index%5){
            thumbnail.color = Volt.hexToRgb('#0d0d0d', 100);
        }else if (1 == index%5 || 3 == index%5){
            thumbnail.color = Volt.hexToRgb('#252525', 100);
        }else{
            thumbnail.color = Volt.hexToRgb('#464646', 100);
        }
    },
    
    __updateData : function(thumbnail, parentHeight, index, model){
        Volt.log('__updateData-----------------------'+index)
        var isSinaHuafeng = (CPAPI.getServiceType() == 'sina_huafeng');
        if(thumbnail === undefined)
            return;
        if(index < 0)
            return;
        if(model == null)
            return;
        var bgUrl = null;
		thumbnail.model = model;
        if (5 == index) {
            bgUrl = thumbnail.model.get('background_image');
            if(isSinaHuafeng){
                if(bgUrl === null ||bgUrl.length === 0)
                {
                    bgUrl = NewsonWeatherDetailImageTemplate.WeatherDefaultBgIconImageTemplate['weather-defaultbg-'+thumbnail.model.get(
                        'current_condition_icon')];
                }
            }
            var thumbListener = new ThumbnailListener;
            thumbListener.onImageReady = function (thumbnail, id, success) {
                Volt.log('weather update------ready'+success);
                if(success && !DeviceModel.getHighContrast()) {
                    Volt.log('weather update---------------succesfully');
                    var backColor = thumbnail.getInformationExtractColor();	
                    backColor.a = 153;
                }else if(!success){
                    if('CN' == DeviceModel.get('countryCode')) {
                        var defaultSrc = NewsonWeatherDetailImageTemplate.WeatherDefaultBgIconImageTemplate['weather-defaultbg-'+thumbnail.model.get(
                                    'current_condition_icon')];
                                    
                        Volt.log("defaultSrc:" + defaultSrc );
                        thumbnail.timer = Volt.setTimeout(function(){
	                            thumbnail.setContentImage(defaultSrc);
	                          },100);							
                    }
                }
                
                var mustashWeather = {
                        src : null,
                        defaultSrc : null,
                        currentConditionIcon : null,
                        location : null,
                        currentConditions : null,
                        todayHighTemp : null,
                        todayLowTemp : null,
                        currentTemp : null,
                        photoAttribute : null,
                };
                
                if(CPAPI.getServiceType() == 'sina_huafeng'){
                    if(thumbnail.model.get('current_condition_icon') === '00' || thumbnail.model.get('current_condition_icon') === '03') {
                        if(new Date(model.get('local_time')).getHours() >= 8 && new Date(thumbnail.model.get('local_time')).getHours() < 20) {
                            mustashWeather.currentConditionIcon = NewsonWeatherDetailImageTemplate.WeatherIconImageTemplate['weathericon-normal-type'+thumbnail.model.get(
                            'current_condition_icon')+'-1'];
                        }
                        else
                        {
                           mustashWeather.currentConditionIcon = NewsonWeatherDetailImageTemplate.WeatherIconImageTemplate['weathericon-normal-type'+thumbnail.model.get(
                            'current_condition_icon')+'-2'];
                        }
                    }else {
                        mustashWeather.currentConditionIcon = NewsonWeatherDetailImageTemplate.WeatherIconImageTemplate['weathericon-normal-type'+thumbnail.model.get(
                        'current_condition_icon')];
                    }
                }else{
                    mustashWeather.currentConditionIcon = thumbnail.model.get('current_condition_icon');
                }
                mustashWeather.location = thumbnail.model.get('location');
                mustashWeather.currentConditions = thumbnail.model.get('current_conditions');
                mustashWeather.todayHighTemp = Math.floor(thumbnail.model.get('today_high_temp')) + '°';
                mustashWeather.todayLowTemp = Math.floor(thumbnail.model.get('today_low_temp')) + '°';
                mustashWeather.currentTemp = Math.floor(thumbnail.model.get('current_temp')) + '°';
                mustashWeather.photoAttribute = thumbnail.model.get('photo_attribution');
                Volt.log('mustashWeather.currentTemp----------------'+mustashWeather.currentTemp);
                Volt.log('mustashWeather.currentConditionIcon----------------'+mustashWeather.currentConditionIcon);
                if('string' == typeof mustashWeather.currentConditionIcon){
                    thumbnail.setInformationIcon("icon1", mustashWeather.currentConditionIcon);
                }
                
                if('string' == typeof mustashWeather.location){
                    thumbnail.setInformationText("text1", mustashWeather.location);
                }
                
                if('string' == typeof mustashWeather.currentConditions){
                    thumbnail.setInformationText("text2", mustashWeather.currentConditions);
                }
                
                if('string' == typeof mustashWeather.todayHighTemp){
                    thumbnail.setInformationText("text3", mustashWeather.todayHighTemp);
                }
                
                if('string' == typeof mustashWeather.todayLowTemp) {
                    thumbnail.setInformationText("text4", mustashWeather.todayLowTemp);
                }
                
                if('string' == typeof mustashWeather.currentTemp){
                    thumbnail.setInformationText("text5", mustashWeather.currentTemp);
                }
                
                if (CPAPI.getServiceType() == 'sina_huafeng') // china cp
                {
                    thumbnail.visualizeAttachIcon(true, "icon1");
                    thumbnail.visualizeInformationText(false, "text6");
                } else {
                    thumbnail.visualizeAttachIcon(false, "icon1");
                    thumbnail.visualizeInformationText(true, "text6");
                    if('string' == typeof mustashWeather.photoAttribute){
                        thumbnail.setInformationText("text6", mustashWeather.photoAttribute);
                    }
                }
                Volt.log('thumbnail.model.location'+thumbnail.model.get('location'));
                if ((CPAPI.getServiceType() == 'sina_huafeng')) // china cp
                {
                    if(HALOUtil.enlarge) {
                        thumbnail.visualizeAttachIcon(false, "icon1");
                        thumbnail.visualizeInformationIcon(true, "icon4"); 
                    } else {
                        thumbnail.visualizeAttachIcon(true, "icon1");
                        thumbnail.visualizeInformationIcon(false, "icon4"); 
                    }
                    
                } else {
                    thumbnail.visualizeAttachIcon(false, "icon1");
                    thumbnail.visualizeInformationIcon(false, "icon4");
                }
                thumbnailViewSelf._updateWeatherText(thumbnail);
                var currentTempText = new TextWidgetEx({
                    x:0,
                    y:0,							
                    width: -1,
                    height: -1,
                    //font: NewsonMainTemplate.containerMap.weather_thumbnail.temperature.font*1.5,
                    font:"Samsung SVD_Light 105px",
                    text:mustashWeather.currentTemp
                });
                //var  currentTempTextEnlargeX= thumbnail.width - currentTempText.width - Volt.width * 0.01250;
                var  currentTempTextEnlargeX= thumbnail.width - currentTempText.width - Volt.width * 0.002;
                thumbnail.setElementEnlargeAllocation('information-text5', {x: currentTempTextEnlargeX});
                var todayLowTempText = new TextWidgetEx({
                    x:0,
                    y:0,							
                    width: -1,
                    height: -1,
                    //font: NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.font*1.5,
                    font:"Samsung SVD_Light 45px",
                    text:mustashWeather.todayLowTemp
                });
                //var  todayLowTempTextEnlargeX= currentTempTextEnlargeX - Volt.width * 0.007813 - todayLowTempText.width;
                var  todayLowTempTextEnlargeX= currentTempTextEnlargeX - Volt.width * 0.004 - todayLowTempText.width;
                thumbnail.setElementEnlargeAllocation('information-text4', {x: todayLowTempTextEnlargeX});
                var todayHighTempText = new TextWidgetEx({
                    x:0,
                    y:0,							
                    width: -1,
                    height: -1,
                    //font: NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.font*1.5,
                    font:"Samsung SVD_Light 45px",
                    text:mustashWeather.todayHighTemp
                });
                //var  todayHighTempTextEnlargeX= currentTempTextEnlargeX - Volt.width * 0.007813 - todayHighTempText.width ;
                var  todayHighTempTextEnlargeX= currentTempTextEnlargeX - Volt.width * 0.004 - todayHighTempText.width ;
                thumbnail.setElementEnlargeAllocation('information-text3', {x: todayHighTempTextEnlargeX});
                var icon2X = todayHighTempTextEnlargeX - 25;
                if(todayHighTempTextEnlargeX > todayLowTempTextEnlargeX){
                    icon2X = todayLowTempTextEnlargeX - 25;
                }
                thumbnail.setElementEnlargeAllocation('information-icon2', {x: icon2X,y:37});
                //var icon3X = todayLowTempTextEnlargeX - 33;
                thumbnail.setElementEnlargeAllocation('information-icon3', {x: icon2X,y:107});
				
				thumbnail.setElementEnlargeAllocation('information-icon4', {x: 606,y:-40});


				currentTempText.destroy();
				currentTempText = null;
				todayLowTempText.destroy();
				todayLowTempText = null;
				todayHighTempText.destroy();
				todayHighTempText = null;
				
            }
            if(thumbnail.listener && thumbnail.removeThumbnailListener !== undefined){
                thumbnail.removeThumbnailListener(thumbnail.listener);
                thumbnail.listener = null;
            }
            thumbnail.addThumbnailListener(thumbListener);
            thumbnail.listener = thumbListener;
            if('string' == typeof bgUrl){
                Volt.log('set bg------------'+bgUrl);
                thumbnail.setContentImage(bgUrl);
            }
        }
    
    },

	_updateWeatherText : function(thumbnail){
    	Volt.log('_updateWeatherText ');

	    var todayHighTempText = Math.floor(thumbnail.model.get('today_high_temp')) + '°';
        var todayLowTempText = Math.floor(thumbnail.model.get('today_low_temp')) + '°';
        var currentTempText = Math.floor(thumbnail.model.get('current_temp')) + '°';

		Volt.log('todayHighTempText: '+todayHighTempText + 'todayLowTempText: '+todayLowTempText+ 'currentTempText: '+currentTempText);


		var currentTempTextWgt = new TextWidgetEx({
				x:0,
				y:0,							
	            width: -1,
	            height: -1,
				//font: NewsonMainTemplate.containerMap.weather_thumbnail.temperature.font*1.5,
				font:"Samsung SVD_Light 70px",
				text:currentTempText
		});		


		var  currentTempTextX= thumbnail.width - currentTempTextWgt.width - Volt.width * 0.01250;
		thumbnail.setElementAllocation('information-text5', {x: currentTempTextX});
		//thumbnail.setElementAllocation('information-text5', {x: currentTempTextX,width:currentTempTextWgt.width});


		var todayLowTempTextWgt = new TextWidgetEx({
			x:0,
			y:0,							
            width: -1,
            height: -1,
			//font: NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.font*1.5,
			font:"Samsung SVD_Light 30px",
			text:todayLowTempText
		});

		var  todayLowTempTextX= currentTempTextX - Volt.width * 0.007813 - todayLowTempTextWgt.width;
		Volt.log('todayLowTempTextX: '+todayLowTempTextX + 'todayLowTempTextWgt.width: '+todayLowTempTextWgt.width);

		thumbnail.setElementAllocation('information-text4', {x: todayLowTempTextX});

		//thumbnail.setElementAllocation('information-text4', {x: todayLowTempTextX, width:todayLowTempTextWgt.width});

		var todayHighTempTextWgt = new TextWidgetEx({
			x:0,
			y:0,							
            width: -1,
            height: -1,
			//font: NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.font*1.5,
			font:"Samsung SVD_Light 30px",
			text:todayHighTempText
		});

		var  todayHighTempTextX= currentTempTextX - Volt.width * 0.007813 - todayHighTempTextWgt.width ;
		Volt.log('todayHighTempTextX: '+todayHighTempTextX + 'todayHighTempTextWgt.width: '+todayHighTempTextWgt.width);

		thumbnail.setElementAllocation('information-text3', {x: todayHighTempTextX});

		var icon2X = todayHighTempTextX - 35;
		thumbnail.setElementAllocation('information-icon2', {x: icon2X});

		//var icon3X = todayLowTempTextX - 33;
		thumbnail.setElementAllocation('information-icon3', {x: icon2X});
		
		currentTempTextWgt.destroy();
		currentTempTextWgt = null;
		todayLowTempTextWgt.destroy();
		todayLowTempTextWgt = null;
		todayHighTempTextWgt.destroy();
		todayHighTempTextWgt = null;

		//thumbnail.setElementAllocation('information-text3', {x: todayHighTempTextX,width:todayHighTempTextWgt.width});


    },

	_modifyWeatherText : function(thumbnail, data){
		var index = data.index;				
	    Volt.log('_modifyWeatherText');
	    if (HALOUtil.enlarge && (5 == index)) {

			/*thumbnail.visualizeInformationText(false, "text5");
			thumbnail.visualizeInformationText(false, "text4");
			thumbnail.visualizeInformationText(false, "text3");
			thumbnail.visualizeInformationIcon(false, "icon2");
			thumbnail.visualizeInformationIcon(false, "icon3");*/

			thumbnailViewSelf._updateWeatherText(thumbnail);

			/*thumbnail.visualizeInformationText(true, "text5");
			thumbnail.visualizeInformationText(true, "text4");
			thumbnail.visualizeInformationText(true, "text3");
			thumbnail.visualizeInformationIcon(true, "icon2");
			thumbnail.visualizeInformationIcon(true, "icon3");*/
	    }

	},


	updateNewsTextPos:function(thumbnail) {
        
        var  sourceCpText = thumbnail.getInformationText('text2');
		var  timeText = thumbnail.getInformationText('text4');

		Volt.log('sourceCpText = '+sourceCpText + 'timeText = '+timeText);

		var NewsonMainTemplate = Volt.require('app/templates/1080/newson-main-template.js');
		
		var sourceCpTextWgt = HALOUtil.getTextSize(sourceCpText, "Samsung SVD_Medium 20px");
		

		/*var sourceCpTextWgt = new TextWidget({
				x:0,
				y:0,							
	            width: -1,
	            height: -1,
				//font:NewsonMainTemplate.containerMap.news_thumbnail1.time.font,
				font:'SVD Medium 20px',
				text:sourceCpText
		});	*/

		var sourceCpTextX = 0;
		if('news_thumbnail1' == thumbnail.type) {
			sourceCpTextX = NewsonMainTemplate.containerMap.news_thumbnail1.time.x;			
		} else if('news_thumbnail2' == thumbnail.type){
			sourceCpTextX = NewsonMainTemplate.containerMap.news_thumbnail2.time.x;
		}else if('news_thumbnail3' == thumbnail.type){
			sourceCpTextX = NewsonMainTemplate.containerMap.news_thumbnail3.time.x;
		}

		Volt.log('sourceCpTextX = '+sourceCpTextX + 'sourceCpTextWgt.width= '+sourceCpTextWgt.width);
		var  separateX = sourceCpTextX + sourceCpTextWgt.width;
		thumbnail.setElementAllocation('information-text3', {x: separateX});
		Volt.log('separateX = '+separateX);

		/*var separateWgt = new TextWidgetEx({
				x:0,
				y:0,							
	            width: -1,
	            height: -1,
				//font:NewsonMainTemplate.containerMap.news_thumbnail1.time.font,
				font:'SVD Medium 20px',
				text:'-'
		});	*/
		
		var separateWgt = HALOUtil.getTextSize('-', "Samsung SVD_Medium 20px");		

		var  timestampX = separateX + separateWgt.width;
		Volt.log('timestampX = '+timestampX);

		/*var timestampWgt = new TextWidgetEx({
				x:0,
				y:0,							
	            width: -1,
	            height: -1,
				//font:NewsonMainTemplate.containerMap.news_thumbnail1.time.font,
				font:'SVD Medium 20px',
				text:timeText
		});	*/
		
		var timestampWgt = HALOUtil.getTextSize(timeText, "Samsung SVD_Medium 20px");
		

		var maxWidthCN = 0;
		var maxWidth = 0;
		if('news_thumbnail1' == thumbnail.type) {
			maxWidthCN = NewsonMainTemplate.containerMap.news_thumbnail1.cp_icon.x - timestampX -1;
			maxWidth = NewsonMainTemplate.containerMap.news_thumbnail1.title.width -(sourceCpTextWgt.width + separateWgt.width);
		} else if('news_thumbnail2' == thumbnail.type){
			maxWidthCN = NewsonMainTemplate.containerMap.news_thumbnail2.cp_icon.x - timestampX -1;
			maxWidth = NewsonMainTemplate.containerMap.news_thumbnail2.title.width -(sourceCpTextWgt.width + separateWgt.width);
		}else if('news_thumbnail3' == thumbnail.type){
			maxWidthCN = NewsonMainTemplate.containerMap.news_thumbnail3.cp_icon.x- timestampX -1;
			maxWidth = NewsonMainTemplate.containerMap.news_thumbnail3.title.width -(sourceCpTextWgt.width + separateWgt.width);
		}		
		
		//var wgtWidth = timestampWgt.width + timestampX;
		var timestampWidth = timestampWgt.width;
		
		Volt.log('timestampWidth = '+timestampWidth + 'maxWidth = '+maxWidthCN);		

		if(timestampWidth > maxWidthCN) {
			timestampWidth = maxWidthCN;
		}

		if('CN' == DeviceModel.get('countryCode')){
			thumbnail.setElementAllocation('information-text4', {x: timestampX,width:maxWidthCN});
		} else {
			thumbnail.setElementAllocation('information-text4', {x: timestampX,width:maxWidth});
		}

    },

	_modifyNewsText : function(thumbnail, status){
	    Volt.log('_modifyNewsText'+status + 'isAddingPages: '+thumbnailViewSelf.isAddingPages);

		if('ToItemEnd' == status && thumbnailViewSelf.isAddingPages){
			Volt.log('set AddingPages to false!');
			thumbnailViewSelf.isAddingPages = false;
			return;
		}
		
		if(thumbnailViewSelf.isAddingPages) {
			Volt.log('isAddingPages now!');
			return;
		}

		
	    if (HALOUtil.enlarge) {
			//thumbnailViewSelf.updateNewsTextPos(thumbnail);

			if('ToItemStart' == status) {	
				Volt.log('ToItemStart');
				thumbnail.visualizeInformationText(false, "text2");
				thumbnail.visualizeInformationText(false, "text3");
				thumbnail.visualizeInformationText(false, "text4");
				thumbnailViewSelf.updateNewsTextPos(thumbnail);
				//thumbnail.visualizeInformationText(true, "text5");
			} else if('ToItemEnd' == status){
				Volt.log('ToItemEnd');
				thumbnail.visualizeInformationText(true, "text5");
				
				//thumbnail.visualizeInformationText(false, "text5");
				//thumbnail.visualizeInformationText(true, "text2");
				//thumbnail.visualizeInformationText(true, "text3");
				//thumbnail.visualizeInformationText(true, "text4");
			} else if('FromItemStart' == status){

				//thumbnail.visualizeInformationText(true, "text5");
				Volt.log('FromItemStart');
				
				thumbnail.visualizeInformationText(false, "text5");
	
			}else if('FromItemEnd' == status){

				Volt.log('FromItemEnd');
				thumbnailViewSelf.updateNewsTextPos(thumbnail);

				thumbnail.visualizeInformationText(true, "text2");
				thumbnail.visualizeInformationText(true, "text3");
				thumbnail.visualizeInformationText(true, "text4");			
			}
	    }

	},

    _unloadData : function(thumbnail, parentHeight, index, model)
    {
        Volt.log('_unloadData-----------------------'+index)
        if(thumbnail === undefined)
            return;

		if(thumbnail.listener) {
			Volt.log('_remove the thumbnail listener')
			thumbnail.removeThumbnailListener(thumbnail.listener);
			thumbnail.listener.destroy();
			thumbnail.listener = null;
		}	
		
		if(thumbnail.widgetExListener) {
			Volt.log('_remove the widgetExListener11 listener')
			thumbnail.removeWidgetExListener(thumbnail.widgetExListener);
			thumbnail.widgetExListener.destroy();
			thumbnail.widgetExListener = null;
		}	
		

		if (thumbnail.timer) {
			Volt.log('_remove the thumbnail timer')
			Volt.clearTimeout(thumbnail.timer);
			thumbnail.timer = null;
		}
		

	},
	
    __loadData : function(thumbnail, parentHeight, index, model)
    {
        Volt.log('__loadData-----------------------'+index)
        if(thumbnail === undefined)
            return;
        if(index < 0)
            return;
        if(model == null)
            return;
			
		thumbnail.model = model;
        var isSinaHuafeng = (CPAPI.getServiceType() == 'sina_huafeng');
        var bgUrl = null;

		thumbnail.index = index;
		if (5 == index){
			Volt.log('index is 5, return');
			return;
		}
		
        var thumbListener = new ThumbnailListener;
	   	thumbListener.onImageReady = function (thumbnail, id, success) {
            Volt.log('loadData update------ready'+success);
			Volt.log('loadData thumbnail.index: '+thumbnail.index);
            if(success && !DeviceModel.getHighContrast() && (5 != thumbnail.index)) {
                /*var backColor = thumbnail.getInformationExtractColor();
                Volt.log('backColor.r------------'+backColor.r);
                if(backColor.r == 0 && isSinaHuafeng){
                    thumbnail.setInformationIcon("icon1", ResourceMgr.NewsCpIconSinaB);
                }*/
               /* backColor.a = 153;
                thumbnail.setInformationTextColor('text1',backColor);
                thumbnail.setInformationTextColor('text2',backColor);
				thumbnail.setInformationTextColor('text3',backColor);
				thumbnail.setInformationTextColor('text4',backColor);
				thumbnail.setInformationTextColor('text5',backColor);*/
            } else if(!success && thumbnail.index != 5){
                Volt.log('failed-----------------need default'+thumbnail.index);
                var imgUrl = null;
                switch(thumbnail.height)
                {
                    case containerMap.news_thumbnail1.height :
                    {
                        imgUrl = NewsonMainDetailTemplate.main_detail_default[thumbnail.index%2];
                        break;
                    }
                    case containerMap.news_thumbnail2.height :
                    {
                        imgUrl = NewsonMainDetailTemplate.main_detail_default[2 + thumbnail.index % 4];
                        break;
                    }
                    case containerMap.news_thumbnail3.height :
                    {
                        imgUrl = NewsonMainDetailTemplate.main_detail_default[6 + thumbnail.index % 2];
                        break;
                    }
                    default :
                    {
                        imgUrl = NewsonMainDetailTemplate.main_detail_default[thumbnail.index%2];
                        break;
                    }
                }
                Volt.log('failed-----------------'+imgUrl);
                thumbnail.timer = Volt.setTimeout(function(thumbnail) {
                    if(thumbnail && thumbnail.setContentImage){
                        thumbnail.setContentImage(imgUrl);
                        thumbnail.loadImageSource();
                    }
                },0,thumbnail);
            }

        }
        if(thumbnail.listener && thumbnail.removeThumbnailListener !== undefined){
            thumbnail.removeThumbnailListener(thumbnail.listener);
            thumbnail.listener = null;
        }
        thumbnail.addThumbnailListener(thumbListener);
        thumbnail.listener = thumbListener;		

            var imgUrl = model.get('img_url');
            if(imgUrl === null || imgUrl.length == 0) //imgUrl == null
            {
                if(isSinaHuafeng) // china cp
                {
                    switch(parentHeight)
                    {
                        case containerMap.news_thumbnail1.height :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[index%2];
                            break;
                        }
                        case containerMap.news_thumbnail2.height :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[2 + index % 4];
                            break;
                        }
                        case containerMap.news_thumbnail3.height :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[6 + index % 2];
                            break;
                        }
                        default :
                        {
                            imgUrl = NewsonMainDetailTemplate.main_detail_default[index%2];
                            break;
                        }
                    }
                }
            }
            mustash = {
                src : imgUrl,
                title : model.get('title') + '',
                sourceCp:model.get('source'),
                time : model.get('stringstamp'),
            };
            Volt.log('mustash - ' + JSON.stringify(mustash));

            
            if('string' == typeof mustash.src){
                thumbnail.setContentImage(mustash.src);
            }
            if('string' == typeof mustash.title){
                thumbnail.setInformationText("text1", mustash.title);
            }
			
			if('string' == typeof mustash.sourceCp){
                thumbnail.setInformationText("text2", mustash.sourceCp);
            }
            if('string' == typeof mustash.time){
                thumbnail.setInformationText("text4", mustash.time);
            }


			var sourceCpLen = mustash.sourceCp.length;
			var enlargeText = null;

			if(sourceCpLen < 3) {
				enlargeText = mustash.sourceCp + '-'+mustash.time;
			} else {
				var subsourceCp = mustash.sourceCp.substr(0,2);
				enlargeText = subsourceCp + '...-'+mustash.time;
			}
			

			//var subsourceCp = mustash.sourceCp.substr(0,2);


			//var enlargeText = subsourceCp + '...-'+mustash.time;
			thumbnail.setInformationText("text5", enlargeText);
			thumbnail.visualizeInformationText(false, "text5");
			
            if (isSinaHuafeng) // china cp
            {
				thumbnail.visualizeInformationIcon(true, "icon1");
                //thumbnail.setInformationIcon("icon1", ResourceMgr.NewsCpIconSinaW/*Volt.getRemoteUrl('images/1080/news_cp_icon_sina_w.png')*/);
            } else {
              	thumbnail.visualizeInformationIcon(false, "icon1");
                //thumbnail.setInformationIcon("icon1", '');
            }

			thumbnailViewSelf.updateNewsTextPos(thumbnail);

    },
    
    /** weather city switch callback. 
	* @function onWeatherCitySwitch
	* @param {Object}  model                  	- main news' model
	* @memberof ContentView
	*/ 
    
    onWeatherCitySwitch : function(model) {
        
        var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
        var cityIdx = model.get('cityIdx');
        cityIdx++;
        if (cityIdx >= iWeatherTileCityCollection.length) {
            cityIdx = 0;
        }
		
        thumbnailViewSelf.weatherCityIdx = cityIdx;
        model.set('cityIdx', cityIdx);
        if(iWeatherTileCityCollection.length <= 1)
            return;
        //modified by yipeng.zhu @2015.01.14 for more news 
        var renderer = thumbnailViewSelf.widget.renderer(0, 5);//.thumbnail;//get weather thumbnail
        if(renderer == null)
            return;
        //thumbnail.hide();
        //end of modify 
        var cityModel = iWeatherTileCityCollection.at(cityIdx);//.get('background_image');
        var data = thumbnailViewSelf.widget.getData(0, 5);
        data.model = cityModel;
        thumbnailViewSelf.widget.updateItem(0, 5);
    },

  	showEnlargeText : function() {
  		Volt.log('showEnlargeText ');
        var focusItem = thumbnailViewSelf.widget.getFocusItemIndex();
		var index = focusItem .itemIndex;				
	    Volt.log('index: ' + index);
	    if (HALOUtil.enlarge && (index != 5)) {
            if(thumbnailViewSelf.widget.renderer(0, index) == null){ //null equal undefined right here
            	Volt.log('get rnder failed: ' + index);
                return;
            }
            var thumbnail = thumbnailViewSelf.widget.renderer(0, index).thumbnail;

			Volt.log('visualizeInformationText ');
			thumbnail.visualizeInformationText(true, "text5");	
			thumbnail.visualizeInformationText(false, "text2");
			thumbnail.visualizeInformationText(false, "text3");
			thumbnail.visualizeInformationText(false, "text4");	
	   }

	},

						
    
    __initGridWidget : function (grid)
    {
        grid.addGroup(1);
        grid.addStyle(1);
        var rendererProvider = new RendererProvider;
        rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data)
        {
            var renderer = new Renderer(parentWidth, parentHeight);
            renderer.root = new WidgetEx(
            {
               x:0,
               y:0,
               width:parentWidth,
               height:parentHeight,
               parent:data.parent,
            });
            
            renderer.thumbnail = thumbnailViewSelf.__loadTemplate(renderer.root, parentHeight, data.index);
            renderer.thumbnail.index = data.index;
            renderer.onRelease = function() 
            {
                renderer.thumbnail.destroy();
                renderer.root.destroy();
                delete renderer;
            };
            
            renderer.onDraw = function(rendererInstance, drawTypeString, data, parentWidth, parentHeight)
            {
                
                /*
                */
                if ("LoadData" == drawTypeString)
                {
                    Volt.log('LoadData---------------------'+data.index);
                    thumbnailViewSelf.__loadData(rendererInstance.thumbnail, parentHeight, data.index, data.model);
                }
                else if("UpdateData" == drawTypeString)
                {
                    Volt.log('UpdateData---------------------'+data.index);
                    thumbnailViewSelf.__updateData(rendererInstance.thumbnail, parentHeight, data.index, data.model);
                    
                }
				else if ("UnloadData" == drawTypeString)
		        {
		            Volt.log('UnloadData---------------------'+data.index);
		            thumbnailViewSelf._unloadData(rendererInstance.thumbnail, parentHeight, data.index, data.model);
		        }
				else if("FromItemFocusChangeAniStart" == drawTypeString)
		        {
		            //The from item of focus change motion start
					//gridlist.onDrawFromFocusChangeStart(rendererInstance.root,data,parentWidth,parentHeight);
					Volt.log('FromItemFocusChangeAniStart'+data.index);
				
					if(5 == data.index){
						//thumbnailViewSelf._modifyWeatherText(rendererInstance.thumbnail,data);
					} else {

						thumbnailViewSelf._modifyNewsText(rendererInstance.thumbnail,'FromItemStart');
					}

					//print("~~~~~~~~~~~~~~renderer.onDraw     FromItemFocusChangeAniStart       " );
		        }

				else if("FormItemFocusChangeAniEnd" == drawTypeString)
		        {
		            //The from item of focus change motion start
					//gridlist.onDrawFromFocusChangeStart(rendererInstance.root,data,parentWidth,parentHeight);
					Volt.log('FormItemFocusChangeAniEnd'+data.index);
				
					if(5 != data.index){

						thumbnailViewSelf._modifyNewsText(rendererInstance.thumbnail,'FromItemEnd');
					} else {
						//thumbnailViewSelf._modifyWeatherText(rendererInstance.thumbnail,data);
					}

					//print("~~~~~~~~~~~~~~renderer.onDraw     FromItemFocusChangeAniStart       " );
		        }


				else if (drawTypeString == "ToItemFocusChangeAniStart")
		        {
		        	Volt.log('ToItemFocusChangeAniStart'+data.index);
					if(5 != data.index){
						thumbnailViewSelf._modifyNewsText(rendererInstance.thumbnail,'ToItemStart');
					}		            
		        }
	
				else if("ToItemFocusChangeAniEnd" == drawTypeString)
		        {
		            //The to item of focus change motion end
					//thumbnailViewSelf._onDrawToFocusChangeEnd(rendererInstance.thumbnail,data);
					//thumbnailViewSelf._modifyWeatherText(rendererInstance.thumbnail,data);

					Volt.log('ToItemFocusChangeAniEnd'+data.index);

					if(5 == data.index){
						//thumbnailViewSelf._modifyWeatherText(rendererInstance.thumbnail,data);
					} else {

						thumbnailViewSelf._modifyNewsText(rendererInstance.thumbnail,'ToItemEnd');
					}

					//print("~~~~~~~~~~~~~~renderer.onDraw     ToItemFocusChangeAniEnd       " );
		        }
            };
            
            return renderer;
        };
        grid.setRendererProvider(rendererProvider);
        
        var gridListener = new GridListControlListener;
        
        for (var i = 0; i < 12; i++){
            grid.addColumn({groupIndex: 0, styleIndex: 0, columnWidth: containerMap.news_thumbnail2.height});
        }
        for(var i = 0;i < 6;i++){
            if(i != 2 && i != 5)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                
                if(i == 1 || i == 4)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 0, startCol: i - 1, endRow: 0, endCol: i});
                }
            }
            else {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
            }
        }
        for(var i = 6;i < 12;i++){
            if( (i % 6 == 0) || (i % 6) == 1)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                if((i % 6) == 1)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 1, startCol: i - 1, endRow: 1, endCol: i});
                }
            }else if(i % 6 == 2 || i % 6 == 5){
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
            }else if( (i % 6 == 3) || (i % 6) == 4)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                if((i % 6) == 4)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 1, startCol: i - 1, endRow: 1, endCol: i});
                }
            }
        }
        /*
        for(var i = 5; i < 10; i++)
        {
            if(i % 5 == 0)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
            }else if( (i % 5 == 1) || (i % 5) == 2)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                if((i % 5) == 2)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 1, startCol: i - 1, endRow: 1, endCol: i});
                }
            }
            else if( (i % 5 == 3) || (i % 5) == 4)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                if((i % 5) == 4)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 0, startCol: i - 1, endRow: 0, endCol: i});
                }
            }
        }*/
        gridListener.onItemClicked  = function(gridList, groupIndex, itemIndex)
        {
            thumbnailViewSelf.onItemClickedCallBack(gridList, groupIndex, itemIndex);
        };

		gridListener.onMousePointerIn = function(gridList, groupIndex, itemIndex)
		{
			Volt.log('onMousePointerIn--itemIndex '+itemIndex);
		 	if (HALOUtil.enlarge && (5 != itemIndex)) {

		        if(thumbnailViewSelf.widget.renderer(0, itemIndex) == null){ 
					Volt.log('item renderer is null!');
					return;
                }

				Volt.log('onMousePointerIn: get thumbnail ');
                var thumbnail = thumbnailViewSelf.widget.renderer(0, itemIndex).thumbnail;
				
				thumbnail.visualizeInformationText(true, "text5");	
				thumbnail.visualizeInformationText(false, "text2");
				thumbnail.visualizeInformationText(false, "text3");
				thumbnail.visualizeInformationText(false, "text4");	
				
		 	}else {
				Volt.log('no need handle!');
		 	}
		
		};
		
		gridListener.onMousePointerOut = function(gridList, groupIndex, itemIndex)
		{
			Volt.log('onMousePointerOut--itemIndex '+itemIndex);
			if (HALOUtil.enlarge && (5 != itemIndex)) {

		        if(thumbnailViewSelf.widget.renderer(0, itemIndex) == null){ 
					Volt.log('item renderer is null!');
					return;
                }

				Volt.log('onMousePointerOut:get thumbnail ');
				
                var thumbnail = thumbnailViewSelf.widget.renderer(0, itemIndex).thumbnail;
				
				thumbnail.visualizeInformationText(true, "text2");
				thumbnail.visualizeInformationText(true, "text3");
				thumbnail.visualizeInformationText(true, "text4");
				thumbnail.visualizeInformationText(false, "text5");	
		 	}
		
		};

        gridListener.onFocusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
            grid.onFocusChanged(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex);
        };
        grid.addListListener(gridListener);
        var keyboardListener = new KeyboardListener;
        keyboardListener.onKeyReleased = function (actor, keycode) {
            Volt.log('in main view keyboardListener');
            if(actor.id !== 'main-content-grid'){
                return;
            }
            switch(keycode) {
                case Volt.KEY_JOYSTICK_OK:{
                    var focusItem = thumbnailViewSelf.widget.getFocusItemIndex();
					var index = focusItem .itemIndex;				
				    Volt.log('index: ' + index);
                    //modify scene color 
				    if (index != 5) {
                        if(thumbnailViewSelf.widget.renderer(0, index) == null){ //null equal undefined right here
                            return;
                        }
                        var thumbnail = thumbnailViewSelf.widget.renderer(0, index).thumbnail;
                        if (thumbnail && thumbnail.getInformationColorPicking) {
                            Volt.log('getInformationColorPicking - ' + JSON.stringify(thumbnail.getInformationColorPicking()));
                            Volt.log('getInformationExtractColor - ' + JSON.stringify(thumbnail.getInformationExtractColor()));
                            var color = thumbnail.getInformationColorPicking();
                            color.a = 255;//make sure it is not transparent
                            if(!DeviceModel.getHighContrast()){
                                Volt.WinsetRoot.color = color
                            }
                            Volt.WinsetRoot.setBackgroundColor(color);
                        }
                    }
                    
				    if (index >= 0) {
				       if(-1 == DeviceModel.getNetWorkState()) {
				           var ErrorHandler = Volt.require('app/common/errorHandler.js');
                            ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,CommonDefines.ErrorCode.NETWORK_ERROR_CODE);
                            return;
                        }
                        if (5 != index) {
		            //skip weather index
                            if(index > 5)
                            {
                                index--;
                            }
                            var postion = thumbnailViewSelf.map[index];
                            var tile = thumbnailViewSelf.tileCollection.at(postion);
                            //KPI start
                            var cpname = ('yahoo' == CPAPI.getServiceType()) ? 'YAHOO':'SINA';
                            var range = thumbnailViewSelf.widget.getOnScreenRange();
                            var pageLocation = index - range.startItemIndex + 1;
                            var options = {cp : 'H01_HOME',
                                sp : 'S-P-' + ((index+1<10) ? '0' : '') + (index+1).toString(),
                                cl : 'C-L-' + (pageLocation<10 ? '0' : '') + pageLocation.toString(),
                                ct : 'article',
                                cn : cpname};
                            if (true == KPI.getAgreedViewing()){
                                _.extend(options, {
                            		ai : tile.get('id'),
                            	    at : tile.get('title')
                            	});
                            }
                            thumbnailViewSelf.KPISelectNews.send(options);
                            //kpi end
                            //kpi log start
                            Global.LeaveWayForKPILog.set('ARTICLE');
                            //kpi log end
                            Backbone.history.navigate('detail/' + tile.get('id') + '/' + '<-1>', {
                                trigger : true
                            });
                        } else {
                            //KPI start
                            thumbnailViewSelf.KPISelectWeather.send();
                            //KPI end
                            //kpi log start
                            Global.LeaveWayForKPILog.set('WEATHER_DETAIL');
                            //kpi log end
                            Backbone.history.navigate('weather/' + thumbnailViewSelf.weatherCityIdx, {
                                trigger : true,
                                weatherTile: weatherTileModel,
                            });
                        }
				    } else {
				        //print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'index is invalid');
				        Volt.log('Erro: Invalid Index!');
				    }
                }
                default:
				// to do
				break;
                
            }
        }
        grid.addKeyboardListener(keyboardListener);
        grid.enlargeFocusItem(20, 20);
        grid.setAnimationDuration(200);
        grid.shadowEffectFlag = false;
        grid.straightPath = false;
        grid.focusImageSetted = false;
		grid.canLoopWhenContinuosKey = false;
        var _initScrollBar = function (width,height)
        {
            var scroll = new WinsetScroll({
                parent: Volt.WinsetRoot,
                width: Volt.width,
                x:0,
                y:Volt.height * 864/1080 - Volt.height*(0.011111 + 0.006481) - 1,
                minValue : 0,
                maxValue : 100,
                height:Volt.height*0.006481 + 1,
                style: WinsetScroll.ScrollStyle.Scroll_Style_D,
                direction: "horizontal",
            });
            scroll.show();
            return scroll;
        };
        var scroll = _initScrollBar(grid.width,grid.height);
        
        grid.attachScrollBar(scroll);
    },
    DataCollection : [],
    onItemClickedCallBack : function (gridList, groupIndex, itemIndex)
    {
        var focusItem = this.widget.getFocusItemIndex();
        var index = focusItem .itemIndex;				
        Volt.log('index: ' + index);
        if (index != 5) {
            var thumbnail = this.widget.renderer(0, index).thumbnail;
            if (thumbnail && thumbnail.getInformationColorPicking) {
                var color = thumbnail.getInformationColorPicking();
                color.a = 255;//make sure it is not transparent
                if(!DeviceModel.getHighContrast()){
                    Volt.WinsetRoot.color = color;
                }
                Volt.WinsetRoot.setBackgroundColor(color);
            }
        }
        if (index >= 0) {
           if(-1 == DeviceModel.getNetWorkState()) {
               var ErrorHandler = Volt.require('app/common/errorHandler.js');
                ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,CommonDefines.ErrorCode.NETWORK_ERROR_CODE);
                return;
            }
            if (5 != index) {
                //skip weather index
                if(index > 5)
                {
                    index--;
                }
                var postion = this.map[index];
                var tile = thumbnailViewSelf.tileCollection.at(postion);
                //KPI start
                var range = thumbnailViewSelf.widget.getOnScreenRange();
                var pageLocation = index - range.startItemIndex + 1;
                var cpname = ('yahoo' == CPAPI.getServiceType()) ? 'YAHOO':'SINA';
                var options = {cp : 'H01_HOME',
                    sp : 'S-P-' + ((index+1<10) ? '0' : '') + (index+1).toString(),
                    cl : 'C-L-' + (pageLocation<10 ? '0' : '') + pageLocation.toString(),
                    ct : 'article',
                    cn : cpname};
                if (true == KPI.getAgreedViewing()){
                    _.extend(options, {
                		ai : tile.get('id'),
                	    at : tile.get('title')
                	});
                }
                thumbnailViewSelf.KPISelectNews.send(options);
                //kpi end
                //kpi log start
                Global.LeaveWayForKPILog.set('ARTICLE');
                //kpi log end
                Backbone.history.navigate('detail/' + tile.get('id') + '/' + '<-1>', {
                    trigger : true
                });
            } else {
                //KPI start
                thumbnailViewSelf.KPISelectWeather.send();
                //KPI end
                //kpi log start
                Global.LeaveWayForKPILog.set('WEATHER_DETAIL');
                //kpi log end
                Backbone.history.navigate('weather/' + this.weatherCityIdx, {
                    trigger : true,
                    weatherTile: weatherTileModel,
                });
            }
        } else {
            //print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'index is invalid');
            Volt.log('Erro: Invalid Index!');
        }
    },
    
    show : function (mainNewsModel, moreNewsModel){
        Volt.log('Content View show');
        this.mainNewsModel = mainNewsModel;
        this.moreNewsModel = moreNewsModel;
        //this._stuffViewHead = 0;
        this.tileCollection = _.clone(mainNewsModel.get('pageModel').get('tileCollection'));
        this.moreNewsCount = 0;
        for(var i = 0; i < moreNewsModel.get('pageCollection').length; i++)
        {
            var pageModel = moreNewsModel.get('pageCollection').at(i);
            for(var j = 0; j < pageModel.get('tileCollection').length;j++)
            {
                this.tileCollection.add(pageModel.get('tileCollection').at(j));
            }
            this.moreNewsCount++;
        }
        
        var iCount = 0;
        for ( var i = 0; i < this.tileCollection.length; i++) {
            if (this.tileCollection.at(i).get('tile_type') == 'news') {
                this.map[iCount] = i;
                iCount++;
            }
        }
        if('CN' == DeviceModel.get('countryCode')){
            this.newsCount = iCount <= 20 ? iCount: 20;
        }else{
            this.newsCount = iCount <= 15 ? iCount: 15;
        }
        //this.newsCount = 16;
        
        /*************could be export as a function*************/
        this.widget.addDataGroup(1);
        this.updateGridData();
        //first time show save layout
        var maxPageCount = 20;
        for(var i = 0; i < maxPageCount; i++){
            this.layOutMgr[i] = 0;
        }
        this.layOutMgr[0] = 1;
        this.layOutMgr[1] = 1;
        /*************could be export as a function*************/
    },
    
    updateTextbyLang : function(){
        for (var index = 0; index < thumbnailViewSelf.newsCount; index++){
            if (5 == index)continue;
            //update model
            var position = thumbnailViewSelf.map[index];
            var tile = thumbnailViewSelf.tileCollection.at(position);
            var source = tile.get('source');
            var last_utc_timestamp = tile.get('timestamp');
            var now_utc_timestamp = tile.get('now_utc_timestamp');
            var text = Global.getOccurStamp_Short(now_utc_timestamp, last_utc_timestamp);
            tile.set('stringstamp', source+' - '+text);
            //update screen items
            if (thumbnailViewSelf.widget.renderer(0, index)){
                thumbnailViewSelf.widget.renderer(0, index).thumbnail.setInformationText("text2", source+' - '+text);
            }
        }
    },
    addMoreNewsLock: true,
    render : function (parent) {
		Volt.log('render entry');
		this.widget = PanelCommon.loadTemplate(this.template, null, parent);
        this.__initGridWidget(this.widget);
        Volt.Nav.setNextItemRule(this.widget,"right",this.widget);
        Volt.Nav.setNextItemRule(this.widget,"left",this.widget);
        if(headViewSelf && 'CN' == DeviceModel.get('countryCode')) {
            Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",headViewSelf.settingButton);
        }else {
            Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",thumbnailViewSelf.widget);
        }
		this.setWidget(this.widget);
        this.widget.onFocusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
            if (toItemIndex <  0) {
                KPILeaveContentIndex = fromItemIndex;
                return;
            }
			
            if (1 == DeviceModel.getMenuTTS()){
                if (mainViewSelf.isReadyForVoice != true)return;
                if (5 != toItemIndex) {
                    var voiceText = thumbnailViewSelf.DataCollection[toItemIndex].model.get('title');
                    if ( mainViewSelf.isFresh == true ){
                        mainViewSelf.isFresh = false;
                        voiceText = "NewsON, " + thumbnailViewSelf.newsCount + ", items, " + voiceText;
                    }
                    Global.voiceGuide(voiceText);
                } else {
                    var tile = thumbnailViewSelf.DataCollection[toItemIndex].model;
                    var city = tile.get('location');
                    var condition = tile.get('current_conditions');
                    var current_temp = Math.floor(tile.get('current_temp'));
                    var degree = ' degrees';
                    if ((-1 == current_temp)||(0 == current_temp)||(1 == current_temp)){
                        degree = ' degree';
                    }
                    var voiceText = city + ', ' + condition + ', ' + current_temp + degree;
                    Global.voiceGuide(voiceText);
                    if ( mainViewSelf.isFresh == true ){
                        mainViewSelf.isFresh = false;
                    }
                }
            }
            if(ModelController.bGetMoreNewsPage()&& 'CN' == DeviceModel.get('countryCode')){
                if(gridList.itemCount(0) > 10 && (gridList.getFocusItemIndex().itemIndex === gridList.itemCount(0) - 1 ||  gridList.getFocusItemIndex().itemIndex  === gridList.itemCount(0) - 2) && thumbnailViewSelf.addMoreNewsLock){
                    LoadingDialog.show(1);
                    thumbnailViewSelf.addMoreNewsLock = false;
                    Volt.log('gridList.itemCount(0) > 8-----'+toItemIndex);
                    Volt.log('thumbnailViewSelf.addMoreNewsLock-----'+thumbnailViewSelf.addMoreNewsLock);
                    Volt.log('thumbnailViewSelf.tileCollection.length'+thumbnailViewSelf.tileCollection.length);
                    Volt.log('gridList.itemCount'+gridList.itemCount(0));
                    if(thumbnailViewSelf.tileCollection.length - gridList.itemCount(0) < 10){
                        ModelController.getMoreNews().then(function(){
                            thumbnailViewSelf.addPageNews();
                            LoadingDialog.hide(1);
							thumbnailViewSelf.isAddingPages = false;
                            thumbnailViewSelf.addMoreNewsLock = true;
                        }).fail(function(){
                            LoadingDialog.hide(1);
                            thumbnailViewSelf.addMoreNewsLock = true;
                        });
                    }else {
                        thumbnailViewSelf.addPageNews();
                        LoadingDialog.hide(1);
                        thumbnailViewSelf.addMoreNewsLock = true;
                    }
                }
            }
        };
        this.onKeyEvent = function (keycode, keytype) {
			Volt.log('onKeyEvent'+keycode+keytype);
			
			var ret = false;
			//print('-----------------gridwidget.onKeyEvent ---------this.grid is-------------------',this.grid);
            //EVENT_KEY_RELEASE EVENT_KEY_PRESS
			if (keytype == Volt.EVENT_KEY_RELEASE) {
				return ;
			}

			if(keycode == Volt.KEY_JOYSTICK_OK)
                return;
	    	switch(keycode) {
				case Volt.KEY_JOYSTICK_UP:
					ret =  this.widget.moveFocus("Up");
					break;
				case Volt.KEY_JOYSTICK_DOWN:
					ret =  this.widget.moveFocus("Down");
					break;	
				case Volt.KEY_JOYSTICK_LEFT:
					ret =  this.widget.moveFocus("Left");
					break;	
				case Volt.KEY_JOYSTICK_RIGHT:
					ret =  this.widget.moveFocus("Right");
					break;		
				default:
				// to do
                    break;
			}
			return ret;
		};
		this.widget.onKeyEvent =  this.onKeyEvent.bind(this);
        //end of hijeck stuff
        return this;
    },
    
    drawPageLayout : function(pageIndex, grid){
        Volt.log('drawPageLayout');
        if(pageIndex <= 0 || grid === undefined)
            return;
        print('drawPageLayout---------------------'+pageIndex);
        for (var i = pageIndex * 6; i < pageIndex * 6 + 6; i++){
            grid.addColumn({groupIndex: 0, styleIndex: 0, columnWidth: containerMap.news_thumbnail2.height});
        } 
        for(i = 6 * pageIndex; i < 6 * pageIndex + 6; i++)
        {
            if(i % 6 == 2 || i % 6 == 5)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail3.height});
            }else if( (i % 6 == 0) || (i % 6) == 1)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                if((i % 6) == 1)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 1, startCol: i - 1, endRow: 1, endCol: i});
                }
            }
            else if( (i % 6 == 3) || (i % 6) == 4)
            {
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail2.height});
                grid.addRowToColumn({groupIndex: 0, styleIndex: 0, columnIndex:i, rowHeight: containerMap.news_thumbnail1.height});
                if((i % 6) == 4)
                {
                    grid.mergeCells({groupIndex: 0, styleIndex: 0, startRow: 1, startCol: i - 1, endRow: 1, endCol: i});
                }
            }
        }
    },
    
    addPageNews : function(){
        //add data
        print('addPageNews-----------------------'+this.newsCount);
        print('start this.moreNewsCount--------------------'+this.moreNewsCount);
        print('this.moreNewsModel.get(\'pageCollection\')'+this.moreNewsModel.get('pageCollection').length);
        for(var i = this.moreNewsCount; i < this.moreNewsModel.get('pageCollection').length; i++)
        {
            var pageModel = this.moreNewsModel.get('pageCollection').at(i);
            for(var j = 0; j < pageModel.get('tileCollection').length;j++)
            {
                this.tileCollection.add(pageModel.get('tileCollection').at(j));
            }
            this.moreNewsCount++;
        }
        if(thumbnailViewSelf.tileCollection.length - thumbnailViewSelf.widget.itemCount(0) < 10) {
            return false;
        }
        
        Volt.log('0------------this.widget.itemCount-------------'+this.widget.itemCount(0));
        Volt.log('1---------this.newsCount----------------'+this.newsCount);
        if(thumbnailViewSelf.layOutMgr[Math.floor(this.newsCount / 10)] === 0){
            this.drawPageLayout(Math.floor(this.newsCount / 10), this.widget);
            thumbnailViewSelf.layOutMgr[Math.floor(this.newsCount / 10)] = 1;
        }
        print('end this.moreNewsCount--------------------'+this.moreNewsCount);
        //update map
        this.map = [];
        this.map.length = 0;
        var iCount = 0;
        for ( var i = 0; i < this.tileCollection.length; i++) {
            if (this.tileCollection.at(i).get('tile_type') == 'news') {
                this.map[iCount] = i;
                iCount++;
            }
        }
        for(var i = 0;i < 10;i++)
        {
            var data = new Data();
            data.parent = this.widget;
            data.index = i + this.newsCount;
            data.model = this.tileCollection.at(this.map[i + this.newsCount- 1]);
            this.DataCollection.push(data);
            this.widget.addData({groupIndex:0, data:data});
        }
        print('this.widget.columnCount()'+this.widget.columnCount(0,0));
        print('this.map-------------------'+this.map);
		thumbnailViewSelf.isAddingPages = true;
        this.widget.loadData();
        
        this.newsCount += 10;

        return true;
        
    },
    
    switchBRorCN : function(object, attr, options)
    {
        if(!LoadingDialog.isLoading)
        {
            mainViewSelf.isFresh = true;
            LoadingDialog.show(1);
            thumbnailViewSelf.closeTimerAndEvent();
            CPAPI.initialize().then(function(){
                ModelController.ready().then(function(result){
                    if(result)
                    {
                        MainMediator.trigger(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON);
                        var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
                        if(attr === 'BR') {
                            mainViewSelf.stopListening(WeatherSettingModel, 'change:weatherSettingCodeCityList');
                            Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",thumbnailViewSelf.widget);
                        } else {
                            mainViewSelf.listenTo(WeatherSettingModel, 'change:weatherSettingCodeCityList', function(){
                                mainViewSelf.weatherSettingCodeCityListChange = true;
                            });
                            if(headViewSelf) {
                                Volt.Nav.setNextItemRule(thumbnailViewSelf.widget,"up",headViewSelf.settingButton);
                            }
                        }
                    } else {
                        if(attr === 'BR') {
                            DeviceModel.set('countryCode', 'CN');
                        }else {
                            DeviceModel.set('countryCode', 'BR');
                        }
                    }
                    thumbnailViewSelf.openTimerAndEvent();
                    mainViewSelf.loadingDialog.hide();
                });
            });
        }
    },
    
    weatherDataRefresh : function(){
        if(!LoadingDialog.isLoading){
            LoadingDialog.show(1);
            ModelController.weatherReady(true).then(function(result){
                if(result) {
                    var weatherModel = null;
                    for ( var i = 0; i < thumbnailViewSelf.mainNewsModel.get('pageModel').get('tileCollection').length; i++) {
                        if(thumbnailViewSelf.mainNewsModel.get('pageModel').get('tileCollection').at(i).get('tile_type') === 'weather'){
                            weatherModel = thumbnailViewSelf.mainNewsModel.get('pageModel').get('tileCollection').at(i);
                            break;
                        }
                    }
                    if(weatherModel !== null) {
                        for ( var i = 0; i < thumbnailViewSelf.tileCollection.length; i++) {
                            if (thumbnailViewSelf.tileCollection.at(i).get('tile_type') == 'weather') {
                                var model = thumbnailViewSelf.tileCollection.at(i);
                                model.set(weatherModel); // update weather model
                                break;
                            }
                        }
                        var weatherModel = thumbnailViewSelf.tileCollection.at(weatherIndex);
                        var iWeatherTileCityCollection = weatherModel.get('weatherTileCityCollection');
                        weatherModel.set('cityIdx',0);
                        if (iWeatherTileCityCollection !== null && iWeatherTileCityCollection !== undefined) {
                            var cityIdx = weatherModel.get('cityIdx');
                            thumbnailViewSelf.weatherCityIdx = cityIdx;	
                            var cityModel = iWeatherTileCityCollection.at(cityIdx);
                            var data = thumbnailViewSelf.widget.getData(0, 5);
                            data.model = cityModel;
                            thumbnailViewSelf.widget.updateItem(0, 5);//update if view return from weather detail view
                        }
                    }
                }
                LoadingDialog.hide();
            })
        }
    },
    
    intervalRefresh : function()
    {
        if(!LoadingDialog.isLoading) {
            mainViewSelf.isFresh = true;
            LoadingDialog.show(1);
            //close event
            thumbnailViewSelf.closeTimerAndEvent();
            ModelController.ready().then(function(result){
                if(result)
                {
                    MainMediator.trigger(CommonDefines.Event.SHOW_OR_HIDE_SETTING_BUTTON);
                }
                thumbnailViewSelf.openTimerAndEvent();
                mainViewSelf.loadingDialog.hide();
            });
        }
    },
    
    updateGridData : function(){
        this.widget.addDataGroup(1);
        this.DataCollection = [];
        this.DataCollection.length = 0;
        for(var i = 0 ; i < this.newsCount;i++)
        {
            var data = new Data();
            data.parent = this.widget;
            data.index = i;
            if(i != 5) {
                if(i > 5)
                    data.model = this.tileCollection.at(this.map[i - 1]);
                else
                    data.model = this.tileCollection.at(this.map[i]);
            } else if(i == 5) {
                for ( var j = 0; j < this.tileCollection.length; j++) {
                    if (this.tileCollection.at(j).get('tile_type') == 'weather') {
                        var iWeatherTileCityCollection = this.tileCollection.at(j).get(
                                'weatherTileCityCollection');
                        //weatherTileCollection = _.clone(iWeatherTileCityCollection);
						weatherTileModel = this.tileCollection.at(j);  //global param to weather detail
                        data.model = iWeatherTileCityCollection.at(0);
                        if('CN' == DeviceModel.get('countryCode')){
                            var cityList = '';
                            for(var k = 0; k < iWeatherTileCityCollection.length;k++)
                            {
                                cityList += iWeatherTileCityCollection.at(k).get('id');
                                if(k != iWeatherTileCityCollection.length - 1)
                                    cityList += ',';
                            }
                            Volt.log('cityList - ' + cityList);
                            var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
                            WeatherSettingModel.set('weatherSettingCodeCityList', cityList);
                        }
                        cycleSeconds = this.tileCollection.at(j).get('cycle_seconds');
                        weatherIndex = j;
                        break;
                    }
                }
            }
            this.DataCollection.push(data);
            this.widget.addData({groupIndex:0, data:data});
        }
        this.widget.loadData();
        //this.widget.updateAllItems(0);
        this.widget.setFocusItemIndex(0, 0);
    },
    layOutMgr : [],
    refresh : function () {
        
        if(this.tileCollection !== null)
            this.tileCollection.reset();
        for ( var i = 0; i < this.mainNewsModel.get('pageModel').get('tileCollection').length; i++) {
            this.tileCollection.add(this.mainNewsModel.get('pageModel').get('tileCollection').at(i));
        }
        this.moreNewsCount = 0;
        for(var i = 0; i < this.moreNewsModel.get('pageCollection').length; i++)
        {
            var pageModel = this.moreNewsModel.get('pageCollection').at(i);
            for(var j = 0; j < pageModel.get('tileCollection').length;j++)
            {
                this.tileCollection.add(pageModel.get('tileCollection').at(j));
            }
            this.moreNewsCount++;
        }
        this.map = [];
        this.map.length = 0;
        var iCount = 0;
        for ( var i = 0; i < this.tileCollection.length; i++) {
            if (this.tileCollection.at(i).get('tile_type') == 'news') {
                this.map[iCount] = i;
                iCount++;
            }
        }
        
        this.newsCount = iCount <= 15 ? iCount: 15;
        this.widget.clearDataSource(0);
        this.widget.addDataGroup(1);
        this.updateGridData();
        this.weatherCityIdx = 0;
        if('CN' !== DeviceModel.get('countryCode')){
            mainViewSelf.lastFocus = thumbnailViewSelf.widget;
        }
        mainViewSelf.setFocusForAppStatusChange();
    },
    
    openTimerAndEvent : function(){
        Volt.log('content view openTimerAndEvent');
        if(this.freshTimer !== null) {
            clearInterval(this.freshTimer);
            this.freshTimer = null;
        }
        if(this.freshTimer == null)
            this.freshTimer = setInterval(this.intervalRefresh, CommonDefines.RefreshTime.REFRESH_NEWS_TIMEOUT,null);
        if (this.weatherSwitchTimer){		
            Volt.clearInterval(this.weatherSwitchTimer);
            this.weatherSwitchTimer = null;
        }
        if(this.tileCollection && this.tileCollection.length > 0 && this.weatherSwitchTimer == null){ // model is ready
            var weatherModel = this.tileCollection.at(weatherIndex);
            var iWeatherTileCityCollection = weatherModel.get('weatherTileCityCollection');
            if (iWeatherTileCityCollection !== null && iWeatherTileCityCollection !== undefined) {
                var model = this.tileCollection.at(weatherIndex);
                var iWeatherTileCityCollection = model.get('weatherTileCityCollection');
                var cityIdx = model.get('cityIdx');
                this.weatherCityIdx = cityIdx;		
                var cityModel = iWeatherTileCityCollection.at(cityIdx);
                var data = this.widget.getData(0, 5);
                data.model = cityModel;
                this.widget.updateItem(0, 5);
            }
            this.weatherSwitchTimer = Volt.setInterval(this.onWeatherCitySwitch, cycleSeconds * 1000,
                            this.tileCollection.at(weatherIndex));
        }
        this.stopListening(DeviceModel);
        this.listenTo(DeviceModel, 'change:countryCode', this.switchBRorCN);
    },
    
    closeTimerAndEvent : function(){
        Volt.log('content view closeTimerAndEvent');
        if(this.freshTimer !== null) {
            clearInterval(this.freshTimer);
            this.freshTimer = null;
        }
        if (this.weatherSwitchTimer !== null ) {
            Volt.clearInterval(this.weatherSwitchTimer);
            this.weatherSwitchTimer = null;
        }
        this.stopListening(DeviceModel);
    },
    
    hide : function () {
        /*
        this.stopListening(DeviceModel);
        this.widget.hide();
        if(this.freshTimer) {
            clearInterval(this.freshTimer);
            this.freshTimer = null;
        }*/
    },
    
     /** ContentView's focus callback. 
    * @function onFocus
    * @param {Widget}  widget                  	- the widget is focused
    * @memberof ContentView
    */
    onFocus : function (widget)
    {
        mainViewSelf.lastFocus = widget;
        if(!widget.focusImageSetted){
			if(!Volt.is720p){
				Volt.log('1080 focus grind');
            	widget.setFocusImage(ResourceMgr.FocusGrid, -5*Volt.sourceControlWidth/1920, -5*Volt.height/1080);
			} else {
				Volt.log('720 focus grind');
            	widget.setFocusImage(ResourceMgr.FocusGrid, 0, 0);
			}
            widget.focusImageSetted = true;
        }
        widget.enableFocus();
        widget.setFocus();
        widget.showFocus("false");
       
    },
    /** ContentView's blur callback. 
    * @function onBlur
    * @param {Widget}  widget                  	- the widget is blurred
    * @memberof ContentView
    */
    onBlur : function(widget)
    {
        Volt.log();
		widget.hideFocus("true");
        widget.killFocus();
    },
    
    enableView : function(){
        this.widget.custom.focusable = true;
        Volt.Nav.reload();
    },
    
    disableView:function(){
        this.widget.custom.focusable = false;
        Volt.Nav.reload();
    },
    
    onSelect : function(widget)
    {
        
    }
});

var ErrorView = BaseView.extend({
    isShow: false,
    template : NewsonMainTemplate.error,
    button : null,
    text : null,
    initialize : function() {
        
    },
    events : {
        //'NAV_SELECT':'onSelect',
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },
    render : function(parent) {
        this.widget = PanelCommon.loadTemplate(this.template, null, parent);
        this.setWidget(this.widget);
        
        var buttonListener = new ButtonListener();
        buttonListener.onButtonClicked = function(button, type) {
            Volt.log('button'+button.id+'clicked');
            if(button.id == 'main-content-error-button'){
                var aulApp = new Aul();
                var ret = aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                if(Global && !Global.NETWORK_CONFIG_LAUNCH){
                    Global.NETWORK_CONFIG_LAUNCH = true;
                }
            }
        }
        this.button = this.widget.getDescendant('main-content-error-button');
        this.button.addListener(buttonListener);
        this.text = this.widget.getDescendant('main-content-error-text');
        this.text.x = (Volt.width - this.text.width)/2;
        this.text.lineSpacing = 50 - this.text.getLineHeight();
        this.text.height = this.text.getLineHeight(0,this.text.getFullTextLineCount());
        this.button.y = this.text.y + this.text.height+10;
        this.widget.hide();
    },
    
    show : function(){
        Volt.log('Error View show');
        this.isShow = true;
        this.widget.show();
        this.enableView();
        if(this.button){
            if (Global.APP_STATUS === Global.APP_DEACTIVATE) {
                mainViewSelf.lastFocus = this.button;
            } else {
                Volt.Nav.focus(this.button);
                mainViewSelf.lastFocus = this.button;
            }
        }
    },
    
    hide : function(){
        this.isShow = false;
        this.disableView();
        this.widget.hide();
        Volt.log('Error View hide');
    },
    
    enableView : function(){
        if(this.button){
            this.button.custom.focusable = true;
        }
        Volt.Nav.reload();
    },
    
    disableView:function(){
        if(this.button){
            this.button.custom.focusable = false;
        }
        Volt.Nav.reload();
    },
    
    onFocus : function(widget)
    {
        Volt.log(widget.id+'setFocus');
        widget.setFocus();
        mainViewSelf.lastFocus = widget;
    },
    
    onBlur : function(widget)
    {
        Volt.log(widget.id+'killFocus');
        widget.killFocus();
    },
    
});


var selfPopupView = null;
var PopupView = BaseView.extend({
    optionMenuTimeOut : null,
    
    initialize : function() {
        this.KPIWeatherSetting = new KPI.WeatherSetting.WeatherSetting(this);
        selfPopupView = this;
    },
    
    render : function(parent) {
        Volt.log();
        this.widget = new WinsetSubList({
		x: Volt.width  - Volt.width * 308/1920,
		y: Volt.height * 0.133333,
		width: Volt.width *308/1920,
    	parent: parent,
        id:'option_popup',
		//bgColor: {r: 100, g: 0, b: 100, a: 0},
		bTextScroll: false,
        bKeyCommon: true,
		items: [{ 
            style: 12, 
            text: Volt.i18n.t('TV_SID_WEATHER_SETTINGS'),
            bDim: false,
        }]
        });
        this.widget.RootView = this; //get this view reference
        var subListListener = new SubListListener();
        subListListener.OnItemClicked = function(subList , itemIndex)
        {
            subList.RootView.onOptionMenuClick(itemIndex);
        };
        subListListener.OnFocusChanged = function(subList , fromItemIndex, toItemIndex){
            Volt.log('OnFocusChanged, item index is '+toItemIndex);
            //voice guide start
            /*if (1 == DeviceModel.getMenuTTS()){
                var voiceText = '';
                if (toItemIndex != -1){
                    voiceText = subList.text({index : toItemIndex});
                }
                if (voiceText != ''){
                    Global.voiceGuide(voiceText);
                }
            }*/
            //voice guide end
        };
        this.widget.addListener(subListListener);
        /*
        var keyboardListener = new KeyboardListener;
        keyboardListener.onKeyPressed = function (actor, keycode) {
            if(actor.id == 'option_popup' && keycode == Volt.KEY_RETURN){
               actor.RootView.hide();
            }
        }
        this.widget.addKeyboardListener(keyboardListener);*/
        this.widget.hide();
    },
    
    onOptionMenuClick : function(index){
        Volt.log();
        if (-1 == DeviceModel.getNetWorkState() && index == 0) {
            this.hide(false);
            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1, CommonDefines.ErrorCode.NETWORK_ERROR_CODE, function() {
            });
            return;
        }
        this.hide(false);
        if (index == 0) {
            //KPI start
            this.KPIWeatherSetting.send();
            //KPI end
            //kpi log start
            Global.LeaveWayForKPILog.set('WEATHER_SETTING');
            //kpi log end
            Backbone.history.navigate('weatherSetting', {
                trigger : true
            });
        }
    },
    
    show: function(){
        Volt.log();
        //Volt.Nav.beginModal(this.widget);
        MainMediator.trigger(CommonDefines.Event.SHOW_OPTION_MENU);
        //Volt.Nav.beginModal(this.widget);
        this.widget.showFocus("false");
        this.widget.setFocus();
        this.widget.checkItemIndex = 0;
        //voice guide start
        if (1 == DeviceModel.getMenuTTS()){
            var itemCnt = this.widget.numofItem();
            var itemText = (1 == itemCnt) ? ', item, ' : ', items, ';
            var voiceText = 'Options, ' + itemCnt + itemText + this.widget.text({index : 0});
            Global.voiceGuide(voiceText);
        }
        //voice guide end
        this.widget.show();
        if(this.optionMenuTimeOut){
			Volt.clearTimeout(this.optionMenuTimeOut);
            this.optionMenuTimeOut = null;
		}
        this.optionMenuTimeOut = Volt.setTimeout(function(){
            selfPopupView.hide(true);
        }, CommonDefines.PopupTime.OPTION_TIMEOUT);
        this.isShown = true;
    },

    updateTextbyLang : function(){
        this.widget.updateItem({
            index: 0,
            text:{itemTextString: Volt.i18n.t('TV_SID_WEATHER_SETTINGS')}
        });
    },
    
    hide:function(hidebyReturn){
        Volt.log();
        this.widget.killFocus();
        this.widget.hide();
        if (hidebyReturn){
            MainMediator.trigger(CommonDefines.Event.HIDE_OPTION_MENU);
        }
        //Volt.Nav.endModal();
        if(this.optionMenuTimeOut){
			Volt.clearTimeout(this.optionMenuTimeOut);
            this.optionMenuTimeOut = null;
		}
        //Volt.Nav.endModal();
        this.isShown = false;
    }
});

exports = MainView;
