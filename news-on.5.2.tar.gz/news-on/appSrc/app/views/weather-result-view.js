
/**
 * @author Qiu weihua (weihua.qiu@samsung.com)
 * @fileoverview Weather Setting View.
 * @date 2014/09/11(last modified date)
 * 
 * Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
/* Include libraries*/
var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require('modules/VoltJSON.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var voltapi = Volt.require('voltapi.js');

var BaseView = PanelCommon.BaseView;
// Include templates
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');
var WeatherTemplate = Volt.requireAppTemplate('newson-weather-result-template.js');
var WeatherDetailModel = Volt.require('app/models/weatherDetailModel.js');
var WeatherSettingViewModel = Volt.require('app/models/newson-weather-setting-model.js');
//var LoadingWidget = Volt.require('app/common/LoadingWidget.js');
var LoadingDialog = Volt.require('app/views/loading-view.js');
var DeviceModel = Volt.require('app/common/deviceModel.js');
var WeatherImageTemplate = Volt.requireAppTemplate('newson-weather-detail-image-template.js');
//Require dim view
var dimView = PanelCommon.requireView('dim');
//Require customization function 
var customizationIcon = Volt.require('app/common/customization-icon.js');
//Require Utility
var utility = new Utility;
var Global = Volt.require('app/common/Global.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
//Require GlobalMediator
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
var ToolTip = Volt.require('app/views/tooltip-view.js');

var MainMediator = new PanelCommon.Mediator;

var weatherBaseView = BaseView.extend({	
	destroy : function(widget){
	
		if(!widget) {
			return;
		}
		var nChildLength = widget.getChildCount();
		if(nChildLength > 0)
		{
			for(var i = 0; i < nChildLength; i++)
			{
				this.destroy(widget.getChild(i));
			}
		}
		widget.id = '';
		widget.destroy();
		delete widget;
		widget = null;
		
		},
});

var HomeMediator = _.clone(Backbone.Events);

var selfDetail = null;
var weatherTileModel = null;
var isEnterFromMainView = true;
var WeatherDetailResultView = weatherBaseView.extend({
    template: WeatherTemplate.container,
    model:null,
    contentView:null,
    container:null,
    loadingTime:null,
    IsDeepLink : false,
    isGetData:false,
    initialize:function() {	
        Volt.log();
        this.model = WeatherDetailModel;		
        this.loadingDialog = LoadingDialog;
        selfDetail = this;	
		MainMediator.on(CommonDefines.Event.HIDE_LOADING, this.finishLoading, this);
    },
    render: function() {
        Volt.log('weather.render');	
		this.setWidget(VoltJSON.load(this.template));
    },

	onComplete:function(object, staus){
		Volt.log();
		if((staus == 'success') && (!selfDetail.isGetData)){
			selfDetail.isGetData = true;
			selfDetail.updateContent();
		}
	},

	finishLoading: function() {	
		Volt.log();		
		this.loadingDialog.hide();
		this.widget.show();
		Volt.Nav.setRoot(selfDetail.widget);
		Volt.Nav.focus(Volt.Nav.getItem(0));
    },	
	
	renderContent: function() {	
		Volt.log();		
		selfDetail.container = selfDetail.widget.getChild('weather-content-container-result');
		selfDetail.contentView =  new ContentView();
		selfDetail.container.addChild(selfDetail.contentView.render().widget);
    },	
    
    /**
     * @description Render the return button.
     * @function renderReturnButton
     * @memberof WeatherDetailResultView
     * @return None
     */
    renderReturnButton : function() {
        this.returnButton = this.widget.getDescendant('newson-weather-detail-return-button-result');
        customizationIcon(this.returnButton, {
            imageStyle : 'pageReturn'
        });
        this.returnButton.onMouseOver = function(){
            var opt = {
    			text: Volt.i18n.t('COM_SID_RETURN'),
    			x: this.returnButton.x,
    			y: this.returnButton.y,
    			width: this.returnButton.width,
    			height: this.returnButton.height,
    			direction:'up',
    			parent: this.returnButton
    		};
    		
    		ToolTip.show(opt, CommonTemplate.tooltip);
            return true;
        }.bind(this);
        this.returnButton.onMouseOut = function(){
            ToolTip.hide();
            return true;
        };
        this.returnButton.onMouseClick = function(){
            ToolTip.hide();
            Backbone.history.back();
        };
    },
    
    /**
     * @description Render the close button.
     * @function renderCloseButton
     * @memberof WeatherDetailResultView
     * @return None
     */
    renderCloseButton : function() {
        this.closeButton = this.widget.getDescendant('newson-weather-detail-close-button-result');
        customizationIcon(this.closeButton, {
            imageStyle : 'pageClose'
        });
        this.closeButton.onMouseClick = function(){
            ToolTip.hide();
            Volt.exit();
        };
        this.closeButton.onMouseOver = function(){
            var opt = {
    			text: Volt.i18n.t('COM_SID_EXIT'),
    			x: this.closeButton.x,
    			y: this.closeButton.y,
    			width: this.closeButton.width,
    			height: this.closeButton.height,
    			direction:'up',
    			parent: this.closeButton
    		};
    		
    		ToolTip.show(opt, CommonTemplate.tooltip);
            return true;
        }.bind(this);
        this.closeButton.onMouseOut = function(){
            ToolTip.hide();
            return true;
        };
    },
    /** pause the main view Invoked when some popup view popup over this View
     * @function onChangeCursor
     * @memberof WeatherDetailResultView
     */
     onChangeCursor : function(visible){
         if( this.returnButton ){
             if(visible){
                 this.returnButton.show();
                 this.closeButton.show();
             }else{
                 this.returnButton.hide();
                 this.closeButton.hide();
             }
         }
     },
	
	updateContent: function() {	
		Volt.log();
		
		if(-1 == DeviceModel.getNetWorkState()) {			
			Volt.Nav.focus(null);
			var ErrorHandler = Volt.require('app/common/errorHandler.js');
			ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1,CommonDefines.ErrorCode.NETWORK_ERROR_CODE,selfDetail.returnFun);
			return;
		}		

		selfDetail.contentView.update(selfDetail.model);		
    },	
	
    show: function(options, animationType) {
		if (false == this.loadingDialog.isLoading){
		    this.loadingDialog.show(1);
        }
        var deferred = Q.defer();
		Volt.Nav.setRoot(this.widget, {focus : this.widget});
        if (options.hasOwnProperty('isDeepLink') && options.isDeepLink){
            this.IsDeepLink = options.isDeepLink;
            this.model.setInitData(options.cid);
        } else {
		    this.model.setInitData();
        }
        
		this.model.set('cityIdx', parseInt(options.id));	
		this.listenTo(this.model, 'complete', this.onComplete);
		this.listenTo(this.model, 'change:cityIdx', this.updateContent);
		this.listenTo(this.model, 'error', this.errorHandle);
        
		this.model.fetch({});
		Volt.log('options.id:'+ options.id);
		print(typeof options.weatherTile);
		weatherTileModel  = options.weatherTile;
		
		isEnterFromMainView = true;
		this.renderContent();		
		this.renderReturnButton();
		this.renderCloseButton();
		if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
            this.returnButton.hide();
            this.closeButton.hide();
        } else {
            this.returnButton.show();
            this.closeButton.show();
        }

        this.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);

        deferred.resolve();
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('wether detail view show');
            print(VDUtil.getProcMemory());
        }
        return deferred.promise;
    },
	
    hide : function(options, animationType){
        var deferred = Q.defer();	
        this.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        selfDetail.widget.hide();
		
		selfDetail.isGetData = false;

		isEnterFromMainView = false;
		selfDetail.stopListening();
		selfDetail.loadingDialog.hide();
		if(selfDetail.contentView) {
			selfDetail.contentView.destroy(selfDetail.container);
		}
        deferred.resolve();
        if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
        {
            print('wether detail view hide');
            gc();
            print(VDUtil.getProcMemory());
        }
        return deferred.promise;
    },

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    onFocus : function(widget) {
        Volt.log();
    },

    onBlur : function(widget) {
        Volt.log();
    },
	
	/** callback of WeatherDetail view's model if the WeatherDetail view model fetch error. 
	* @function show
    * @param {Object}  object                  	- the http request object
	* @param {string}  status          		- show the http request's status
    * @param {string}  exception                  	- pass the exception
	* @memberof WeatherDetailResultView
	*/
    errorHandle : function(object, status, exception) {
		Volt.log('errorHandle');
        selfDetail.loadingDialog.hide();
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        if (this.IsDeepLink){
            var errorCode = object?object.status : CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE;
            ErrorHandler.handleNetworkError(errorCode,function(){
                Volt.quit();
            });
        }else {
            var errorCode = object?object.status : CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE;
            ErrorHandler.handleNetworkError(errorCode,selfDetail.returnFun);
        }
    },
	

	returnFun : function() {
		Backbone.history.back();
    },
	
        /**
         * pause the main view Invoked when some popup view popup over this View
         * @function
         * @memberof WeatherDetailResultView
         */
    pause : function() {
        Volt.log();
        dimView.show({
            parent: Volt.WinsetRoot
        });
    },

        /**
         * Invoked when come back from popup
         * @function
         * @memberof WeatherDetailResultView
         */
    resume : function() {
        Volt.log();
        dimView.hide();
    },
    
    onKeyEvent : function(keyCode, keyType) {
        if(keyType == Volt.EVENT_KEY_RELEASE)
            return false;
        
        if (keyCode == Volt.KEY_RETURN && true == this.IsDeepLink && Backbone.history.location.history.length == 1) {
            Volt.quit();
            return true;
        }
        return false;
    },
});

var self = null;

var ContentView = weatherBaseView.extend({
    template: WeatherTemplate.weathercontent,
	backgoundImageList:[],
	imageBgWgtList:[],
	imageCurrentConditionList:[],	
	imageSourceIconList:[],
	bgColorPickList:[],
	dayView:null,
	dayContainer:null,
	iCurWeatherDetailCityModel:null,
	iWeatherDetailCityCollection:null,
	isWidgetReady:false,
	isDestroying:false,
	thumbnailCount:0,
	isViewReady:false,
	widgetExListener:null,
	    
    render: function(model) {
        Volt.log('renderContent');
		self  = this;
	
		self.setWidget(PanelCommon.loadTemplate(self.template));
		Volt.Nav.reload();
				
		self.arrowLeft = self.widget.getChild('image_arrow_left_unfocus-result');
		self.arrowRight = self.widget.getChild('image_arrow_right_unfocus-result');

		if(Volt.isReverseOsd){
			self.arrowLeft.src = ResourceMgr.WeatherArrowRight;//Volt.getRemoteUrl('images/1080/arrow/weather_arrow_right.png')		
			self.arrowRight.src = ResourceMgr.WeatherArrowLeft;//('images/1080/arrow/weather_arrow_left.png')
		} else {
			self.arrowLeft.src = ResourceMgr.WeatherArrowLeft;//('images/1080/arrow/weather_arrow_left.png')		
			self.arrowRight.src = ResourceMgr.WeatherArrowRight;//('images/1080/arrow/weather_arrow_right.png')
		}

		
		var textCityTitle = self.widget.getChild('text-city-title-result');
		var textPageIndex = self.widget.getChild('text-page-index-result');
		textCityTitle.x = (Volt.width - textCityTitle.width)/2;
		textPageIndex.x = textCityTitle.x + textCityTitle.width + WeatherTemplate.constNum.indexSpace;
		
		self.dayContainer = self.widget.getChild('weather-day-container-result');
		self.dayView = new DayView();
		self.dayContainer.addChild(self.dayView.render().widget);
		
		self.widget.hide();
        self.widget.custom = {};
		self.widget.custom.focusable = true;
		self.widget.onKeyEvent = function(keycode, type)
		{
			Volt.log(keycode + ' ' + type);

			if(type == Volt.EVENT_KEY_RELEASE){					
				return false;
			}	

			if(self.isDestroying) {
				Volt.log("isDestroying widget onKeyEvent");
				return;		
			}	

			if(isEnterFromMainView) {		
				Volt.log('isEnterFromMainView is not ready');	
				return false;
			}	
			

			if(!self.isWidgetReady) {		
				Volt.log('widget is not ready');	
				return false;
			}
            
			switch(keycode) {
			    case Volt.KEY_RETURN:
				{
			        return false;
				}
			    default:
			        break;
			}			

			return true;
		};	
        return self;
    },	
	
	update: function(model) {
        Volt.log('update weather');
		self.isWidgetReady = false;
		if(self.isViewReady){
			self.widget.show();
		}

		self.model = model;	
		self.iWeatherDetailCityCollection = model.get('weatherDetailCityCollection');
		self.index = model.get('cityIdx')+1;	
		
		self.total = self.iWeatherDetailCityCollection.length;		
		Volt.log('this.index:'+self.index +'this.total:'+self.total);
		
		if(0 == self.total) {
			Volt.log('title collection length is 0!');
			return;
		} else if(1 == self.total) {
			if(self.arrowLeft) {
				self.arrowLeft.opacity = 0;
			}
			if(self.arrowRight) {
				self.arrowRight.opacity = 0;
			}
		}
		
		
		if(self.index > self.total){
			Volt.log('error:this.index: is larger than this.total');
			return;
		}		
		 
		if(isEnterFromMainView) {
            self.widgetExListener = new WidgetExListener;
            self.widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) { 
				Volt.log("onHighContrastChanged:"+flagHighContrast);
			    var fontColor = self.bgColorPickList[self.index-1]
			    if(fontColor){
			    	__colorPickingWeather(fontColor);
			    }      
            }
            self.widget.addWidgetExListener(self.widgetExListener);

			
			var imageBgContainer = self.widget.getChild('image-bg-container-result');
			self.imageConditionContainer = self.widget.getChild('image-condition-container-result');
			self.imageSourceIconContainer = self.widget.getChild('image-source-container-result');
			
			self.thumbListener = new ThumbnailListener;
			self.thumbListener.onImageReady = function (thumbnail, id, success) {
				print("thumb" + thumbnail + " load " + success);
				
				if(self.isDestroying) {
					Volt.log("isDestroying widget");
					return;		
				}				
			

				if(success) {
	

					if(self.bgColorPickList[thumbnail.index] == undefined){	
						Volt.log("thumbnail bg,index="+thumbnail.index);
						var fontColor = thumbnail.getInformationExtractColor();	
						Volt.log("fontColor:color.r " + fontColor.r);
						Volt.log("fontColor:color.g " + fontColor.g);
						Volt.log("fontColor:color.b " + fontColor.b);	
						self.bgColorPickList[thumbnail.index] = fontColor;
						self.thumbnailCount++;
						self.index == (i+1)
						if(self.index == (thumbnail.index+1)){							
							__colorPickingWeather(fontColor);
						}
					}
				}

				
				if(thumbnail.index != (self.index-1)) {
					Volt.log("index is not the same" + thumbnail.index);
				//	return;				
				}else {
					Volt.log("index is the same: " + thumbnail.index);
				}
				
								
				if(success) {
				
				} else {
					if('CN' != DeviceModel.get('countryCode')) {
						Volt.log("not CN and thumbnail load failed!");					
					} else {
			
						var iCurWeatherDetailCityModel = self.iWeatherDetailCityCollection.at(thumbnail.index);	
						if(!iCurWeatherDetailCityModel) {
							Volt.log("iCurWeatherDetailCityModel is null ");
							return;
						}
						var iconName = 'weather-defaultbg-' + iCurWeatherDetailCityModel.get('current_condition_icon');
						var defaultImage = WeatherImageTemplate.WeatherDetailBgIconImageTemplate[iconName];						
						//thumbnail.setContentImage(defaultImage);
						Volt.log("CN defaultImage = "+defaultImage);	

						Volt.setTimeout(function(){
							thumbnail.setContentImage(defaultImage);
							thumbnail.loadImageSource();

							},100);
					
					}				
				}
				
			}
			
			for(var i = 0; i < self.total; i++) {		
				
				self.imageBgWgtList[i] = new Thumbnail({
					x:0,
					y:0,
					visibleStyles: (0x01 | 0x20),
					image:{
                        src: '',
						width: Volt.width,
						height: Volt.height
                    },								
                    width: Volt.width,
                    height: Volt.height,
					information:{
						x: 0,
						y: Volt.height*(1 - 0.212963),
						width: Volt.width,
						height: Volt.height * 0.212963,
					},

				});
				
				self.imageBgWgtList[i].index = i;							
				self.imageBgWgtList[i].addThumbnailListener(self.thumbListener);				
				imageBgContainer.addChild(self.imageBgWgtList[i]);
				
				self.imageCurrentConditionList[i] = new ImageWidget();
				self.imageConditionContainer.addChild(self.imageCurrentConditionList[i]);
				
				self.imageSourceIconList[i] = new ImageWidget();
				self.imageSourceIconContainer.addChild(self.imageSourceIconList[i]);				
			}
		}
		
		for(var i = 0; i < self.total; i++) {
			if(self.index == (i+1)) {			
				self.imageBgWgtList[i].show();
				self.imageCurrentConditionList[i].opacity = 255;
				self.imageSourceIconList[i].opacity = 255;
			} else {
				self.imageBgWgtList[i].hide();
				self.imageCurrentConditionList[i].opacity = 0;
				self.imageSourceIconList[i].opacity = 0;
			}
		}		
		
		Volt.log('this.index:'+ self.index);		
		self.iCurWeatherDetailCityModel = self.iWeatherDetailCityCollection.at(self.index-1);

		var iweatherTileModel = self.iWeatherDetailCityCollection.at(self.index-1);
		var imageBrand = self.widget.getChild('brand-image-result');
		imageBrand.src = model.get('brand_img_url-result');
		var textPageIndex = self.widget.getChild('text-page-index-result');
		textPageIndex.text = self.index+'/'+self.total;
		var textCityTitle = self.widget.getChild('text-city-title-result');
		textCityTitle.text = self.iCurWeatherDetailCityModel.get('location');		
		var textLocalTime = self.widget.getChild('text-local-time-result');

		var relatedTempUpWgt = null;
		var relatedTempDownWgt = null;
		
		if('CN' !== DeviceModel.get('countryCode')) {
		    self.widget.getChild('text-temp-up-result').hide();
		    self.widget.getChild('text-temp-up-colon-result').hide();
		    self.widget.getChild('text-temp-down-result').hide();
            self.widget.getChild('text-temp-down-colon-result').hide();
		    self.widget.getChild('image-temp-up-result').show();
            self.widget.getChild('image-temp-down-result').show();

			relatedTempUpWgt = self.widget.getChild('image-temp-up-result');
			relatedTempDownWgt = self.widget.getChild('image-temp-down-result');
			
		} else {
		    self.widget.getChild('image-temp-up-result').hide();
            self.widget.getChild('image-temp-down-result').hide();
		    self.widget.getChild('text-temp-up-result').show();
		    self.widget.getChild('text-temp-up-colon-result').show();
            self.widget.getChild('text-temp-down-result').show();
            self.widget.getChild('text-temp-down-colon-result').show();

			relatedTempUpWgt = self.widget.getChild('text-temp-up-colon-result');
			relatedTempDownWgt = self.widget.getChild('text-temp-down-colon-result');
		}
		    
        //handle format time
        
        if('CN' !== DeviceModel.get('countryCode'))
        {
            var text = self.iCurWeatherDetailCityModel.get('local_time');
            text = text.replace('AM','am');
            text = text.replace('PM','pm');
            if(text.split(':').length >= 2)
            {
                var hour = parseInt(text.split(':')[0]);
                text = hour + ':' + (text.split(':')[1]);
            }
            textLocalTime.text = text;
        }
        else
        {
            var format = function(d)
            {    
                var fmt = '';
                function pad(value) {
                    return (value.toString().length < 2) ? '0' + value : value;
                }
                fmt += (d.getHours() % 12 || 12)+':';
                fmt += pad(d.getMinutes()) + ' ';
                fmt += d.getHours() < 12 ? 'am' : 'pm';
                fmt += ' CST';
                return fmt;
            };
            textLocalTime.text = format(new Date(self.iCurWeatherDetailCityModel.get('local_time')));
        }
        //end of format time
		var textPhotoAttribution = self.widget.getChild('text-photo-attribution-result');
		textPhotoAttribution.text = self.iCurWeatherDetailCityModel.get('photo_attribution');
		
		var imageCurrentCondition = self.imageCurrentConditionList[self.index-1];
		imageCurrentCondition.opacity = 255;
		if('CN' != DeviceModel.get('countryCode')) {	
			imageCurrentCondition.src = self.iCurWeatherDetailCityModel.get('current_condition_icon');
		}
		else {		
			if(self.iCurWeatherDetailCityModel.get('current_condition_icon') == '00' || self.iCurWeatherDetailCityModel.get('current_condition_icon') == '03') {
				if(new Date(self.iCurWeatherDetailCityModel.get('local_time')).getHours() >= 8 && new Date(self.iCurWeatherDetailCityModel.get('local_time')).getHours() < 20) {				
					var iconName = 'weathericon-small-type'+ self.iCurWeatherDetailCityModel.get('current_condition_icon') + '-1';
					imageCurrentCondition.src = WeatherImageTemplate.WeatherIconImageTemplate[iconName];	
					Volt.log('current condition1-1:icon:'+ iconName);
				} else {
					var iconName = 'weathericon-small-type'+ self.iCurWeatherDetailCityModel.get('current_condition_icon') + '-2';
					imageCurrentCondition.src = WeatherImageTemplate.WeatherIconImageTemplate[iconName];		
					Volt.log('current condition1-2:icon:'+ iconName);					
				}			
			}
			else {
				var iconName = 'weathericon-small-type'+ self.iCurWeatherDetailCityModel.get('current_condition_icon');
				imageCurrentCondition.src = WeatherImageTemplate.WeatherIconImageTemplate[iconName];
	
				Volt.log('current condition2-1:icon:'+ iconName);					
			}		
		}	
				
		var textCurrentCondition = self.widget.getChild('text-current-condition-result');
		textCurrentCondition.text = self.iCurWeatherDetailCityModel.get('current_conditions');	
		var textTodayHigh = self.widget.getChild('text-today-high-result');
		textTodayHigh.text = Math.floor(iweatherTileModel.get('today_high_temp'))+'°';
		var textTodayLow = self.widget.getChild('text-today-low-result');		
		textTodayLow.text = Math.floor(iweatherTileModel.get('today_low_temp'))+'°';	
		var textCurrentTemp = self.widget.getChild('text-current-temp-result');
		textCurrentTemp.text = Math.floor(iweatherTileModel.get('current_temp'))+'°';

		var distance = Volt.is720p?6:8;
		var relatedWidth = (textTodayHigh.width > textTodayLow.width)?textTodayHigh.width:textTodayLow.width;
		var textTodayHighX = relatedTempUpWgt.x + distance + (relatedWidth - textTodayHigh.width);
		var textTodayLowX = relatedTempUpWgt.x + distance + (relatedWidth - textTodayLow.width);

		textTodayHigh.x = textTodayHighX;
		textTodayLow.x = textTodayLowX;

		
		var imageSourceIcon = self.imageSourceIconList[self.index-1];
		imageSourceIcon.opacity = 255;
		
		if('CN' != DeviceModel.get('countryCode')) {			
			imageSourceIcon.src = model.get('source_icon');		
		}
		else {
			if('' == model.get('source_icon')) {
				imageSourceIcon.src = WeatherImageTemplate.WeatherIconImageTemplate['icon_china_weather_tv_l'];	
				Volt.log('imageSourceIcon2-1:icon:'+ imageSourceIcon.src);	
			} else {			
				imageSourceIcon.src = model.get('source_icon');
				Volt.log('imageSourceIcon2-2:icon:'+ imageSourceIcon.src);	
			}
		}
		
		
		var weatherFeatures = self.iCurWeatherDetailCityModel.get('weather_features');
		
		//empty text first
		for(var i = 0; i < 3; i++) {
			var textFeatureDesc = 'text-feature-desc'+(i+1)+'-result';
			var textFeatureLabelWgt = self.widget.getChild(textFeatureDesc);
			textFeatureLabelWgt.text = '';

			var textFeatureValue = 'text-feature-value'+(i+1)+'-result';
			var textFeatureValueWgt = self.widget.getChild(textFeatureValue);
			textFeatureValueWgt.text = '';		
		}
		
		for(var j = 2, i = 2; i >= 0 ; i--) {
		
			if(weatherFeatures.length <= i)
			{
				continue;
			}

			if('' != weatherFeatures[i].value) {
			
				var textFeatureDesc = 'text-feature-desc'+(j+1)+'-result';
				var textFeatureLabelWgt = self.widget.getChild(textFeatureDesc);
				textFeatureLabelWgt.text = weatherFeatures[i].label+' :';

				var textFeatureValue = 'text-feature-value'+(j+1)+'-result';
				var textFeatureValueWgt = self.widget.getChild(textFeatureValue);
				textFeatureValueWgt.text = weatherFeatures[i].value;
				j--;
			}		
		}
		
		textCityTitle.x = (Volt.width - textCityTitle.width)/2;
		textPageIndex.x = textCityTitle.x + textCityTitle.width + WeatherTemplate.constNum.indexSpace;

		if(self.dayView) {
			self.dayView.update(self.iCurWeatherDetailCityModel);
		}

        //voice start
        if (1 == DeviceModel.getMenuTTS()){
            var city = textCityTitle.text;
            var condition = textCurrentCondition.text;
            var current_temp = Math.floor(iweatherTileModel.get('current_temp'));
            var degree = ' degrees';
            if ((-1 == current_temp)||(0 == current_temp)||(1 == current_temp)){
                degree = ' degree';
            }
            var voiceText = city + ', ' + condition + ', ' + current_temp + degree;
            for (var k = 0; k < weatherFeatures.length; k++){
                voiceText = voiceText + ', ' + weatherFeatures[k].label + ', ' + weatherFeatures[k].value;
            }
            Global.voiceGuide(voiceText);
        }
        //voice end
        
		self.isWidgetReady = true;

		MainMediator.trigger(CommonDefines.Event.HIDE_LOADING);
		self.widget.show();
		self.isViewReady = true;

		if(isEnterFromMainView) {
			Volt.log('load image');	
			for(var i = 0; i < self.total; i++){		

				var imageBg = self.imageBgWgtList[i];
				var curWeatherDetailCityModel = self.iWeatherDetailCityCollection.at(i);
				imageBg.setContentImage(curWeatherDetailCityModel.get('background_image'));	
				imageBg.loadImageSource();
			}
		}

		isEnterFromMainView = false;

		Volt.log('widget is ready');
    },	

	
	switchToNext:function(index)
	{		
		Volt.log('switchToNext');	
		if(isEnterFromMainView || !self.isWidgetReady) {		
			Volt.log('widget is not ready');	
			return;
		}
	    var fontColor = self.bgColorPickList[index-1]
	    if(fontColor){
	    	__colorPickingWeather(fontColor);
	    } else {

	   		var tempColor = {r:255,g:255,b:255};
			__colorPickingWeather(tempColor);
	    }
		

		self.widget.hide();
		self.model.set('cityIdx',index-1);
		if(weatherTileModel !== undefined) {
			weatherTileModel.set('cityIdx',index-1);
		}
		

		return;		
	},
	
	destroy:function(contentContainer)
	{		
		self.isDestroying = true;
		self.thumbnailCount = 0;
		self.isViewReady = false;

		if(self.widgetExListener){

			delete self.widgetExListener;
			self.widgetExListener = null;
		}


		for(var i = 0; i < self.total; i++) {
			self.bgColorPickList[i] = undefined;

			if(self.thumbListener){
				Volt.log('removeThumbnailListener')
				self.imageBgWgtList[i].removeThumbnailListener(self.thumbListener);
			}
			
			self.imageBgWgtList[i].destroy();
			self.imageBgWgtList[i] = null;
			
			self.destroyChild(self.imageConditionContainer, self.imageCurrentConditionList[i]);
			self.destroyChild(self.imageSourceIconContainer, self.imageSourceIconList[i]);		
		}

		if(self.thumbListener){
			Volt.log('delete thumbListener')
			delete self.thumbListener;
			self.thumbListener = null;
		}
		

		self.bgColorPickList.length =0;
		if(self.dayView) {
			self.dayView.destroy(self.dayContainer); 
		}
		if(contentContainer) {	
			self.destroyChild(contentContainer, self.widget);
		}		
		return;		
	},
	
	destroyChild:function(parentWgt,childWgt)
	{
		if(parentWgt) {
			parentWgt.removeChild(childWgt);	
			childWgt.id = '';			
			childWgt.destroy();
			childWgt = null;	
		}		
		return;		
	},
	
		

});

var selfDayView = null;
var DayView = weatherBaseView.extend({
    template: WeatherTemplate.weatherday,
	dayListTypeOne:[],
	dayListTypeTwo:[],
	containerList:[],
	dayNum:5,	
	
	render: function(dayContainer) {
        Volt.log('DayView render');
		
		selfDayView = this;						
		this.setWidget(PanelCommon.loadTemplate(this.template));
		for(var i = 0; i < this.dayNum; i++) {
		    var containerInfo = 'weather-day-container'+(i+1)+'-result';
            Volt.log(containerInfo);
            this.containerList[i] = this.widget.getChild(containerInfo);
            this.dayListTypeOne[i] = new DayViewTypeOne(); 
            this.dayListTypeOne[i].render(this.containerList[i]);
            this.dayListTypeTwo[i] = new DayViewTypeTwo(); 
            this.dayListTypeTwo[i].render(this.containerList[i]);
		}
		return this;
    },
    
    update: function(curWeatherDetailCityModel) {
        Volt.log('DayView update');
		var forecasts = curWeatherDetailCityModel.get('forecasts');	
		this.dayNum =  forecasts.length;
		for(var i = 0; i < forecasts.length; i++)
		{	
			if(i > 4)
			{
				break;
			}
			
			Volt.log('weather-day-container'+(i+1));
			
			if('CN' != DeviceModel.get('countryCode')) {	
			    this.containerList[i].type = 'weatherdaytype1';
			    this.dayListTypeTwo[i].widget.hide();
				this.dayListTypeOne[i].update(forecasts[i]);
			}
			else {
			
				if (forecasts[i].forecast_conditions_icon1 != forecasts[i].forecast_conditions_icon2) {
				
					var icon1Src  = null;
					var icon2Src  = null;
				    if (forecasts[i].forecast_conditions_icon1 == '00' || forecasts[i].forecast_conditions_icon1 == '03') { 
							var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1 + '-1';
							icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];							
					}
					else {						
						var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1;
						icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];
					}			
					

					if (forecasts[i].forecast_conditions_icon2 == '00' || forecasts[i].forecast_conditions_icon2 == '03') { 
							var icon2Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon2 + '-1';	
							icon2Src = WeatherImageTemplate.WeatherIconImageTemplate[icon2Name];									
					}
					else {						
						var icon2Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon2;
						icon2Src = WeatherImageTemplate.WeatherIconImageTemplate[icon2Name];	
					}
					
					Volt.log('icontype2-1:icon1:'+ icon1Src +' icon2'+ icon2Src );

					this.containerList[i].type = 'weatherdaytype2';
					this.dayListTypeOne[i].widget.hide();
					this.dayListTypeTwo[i].update(forecasts[i], icon1Src, icon2Src);	
				}
				else {				
					var icon1Src  = null;
					var icon2Src  = null;					
				    if (forecasts[i].forecast_conditions_icon1 == '00' || forecasts[i].forecast_conditions_icon1 == '03') { 
						var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1 + '-1';
						icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];
						var icon2Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1 + '-2';
						icon2Src = WeatherImageTemplate.WeatherIconImageTemplate[icon2Name];
						
						Volt.log('icontype2-2:icon1:'+ icon1Src +' icon2'+ icon2Src );	
					
						this.containerList[i].type = 'weatherdaytype2';
						this.dayListTypeOne[i].widget.hide();
						this.dayListTypeTwo[i].update(forecasts[i], icon1Src, icon2Src);	
					}
					else {						
						var icon1Name = 'weathericon-normal-type'+ forecasts[i].forecast_conditions_icon1;
						icon1Src = WeatherImageTemplate.WeatherIconImageTemplate[icon1Name];
						
						this.containerList[i].type = 'weatherdaytype1';
						Volt.log('icontype1-1:icon1:'+ icon1Src);
						this.dayListTypeTwo[i].widget.hide();
						this.dayListTypeOne[i].update(forecasts[i], icon1Src);	
					}				
				}			
			}
		}
				   
        return this;
    },
	
	destroy: function(dayContainer) {
        Volt.log('DayView destroy');
		
		if(dayContainer) {		
			for(var i = 0; i < selfDayView.dayNum; i++)
			{
				if(selfDayView.dayListTypeOne[i]) {
					selfDayView.dayListTypeOne[i].destroy(selfDayView.dayListTypeOne[i],selfDayView.containerList[i]);
					delete selfDayView.dayListTypeOne[i];
					selfDayView.dayListTypeOne[i] = null;
				}
				
				if(selfDayView.dayListTypeTwo[i]) {
                    selfDayView.dayListTypeTwo[i].destroy(selfDayView.dayListTypeTwo[i],selfDayView.containerList[i]);
                    delete selfDayView.dayListTypeTwo[i];
                    selfDayView.dayListTypeTwo[i] = null;
                }
			
			}
		}		

    },
	
});


var DayViewTypeOne = weatherBaseView.extend({
    template: WeatherTemplate.weatherdaytype1,
    
    render: function(container) {
        Volt.log('DayViewTypeOne render');
				
        var day_info = {
            text_day_labe:'',
            image_forecast_conditions:'',
            text_forecast_high_temp:'°',
            text_forecast_low_temp:'°', 
        };
		this.setWidget(PanelCommon.loadTemplate(this.template, day_info, container));
		this.widget.hide();
        return this;
    },
    
    update : function(forecastsItem, icon1src){
        Volt.log('DayViewTypeOne update');
        var iconsrc = null;
        if(icon1src) {
            iconsrc = icon1src;     
        } else {
            iconsrc = forecastsItem.forecast_conditions_icon;
        }
        
        var text_day_label = this.widget.getChild(1);
        var image_forecast_conditions = this.widget.getChild(2);
        var text_forecast_temp = this.widget.getChild(3);
        
        text_day_label.text = forecastsItem.day_label;
        image_forecast_conditions.src = iconsrc;
        text_forecast_temp.text = Math.floor(forecastsItem.forecast_high_temp)+'°' + '/' + Math.floor(forecastsItem.forecast_low_temp)+'°';
        this.widget.show();
    },
	
	destroy: function(dataPtr,dayContainer) {
        Volt.log('DayViewTypeOne destroy');
		if(dayContainer) {		

			dayContainer.removeChild(dataPtr.widget);
			dataPtr.widget.id = '';			
			dataPtr.widget.destroy();
			dataPtr.widget = null;
		}
    },
});


var DayViewTypeTwo = weatherBaseView.extend({
    template: WeatherTemplate.weatherdaytype2,
    
    render: function(container) {
        Volt.log('DayViewTypeTwo render');
		
		var day_info = {
			text_day_labe:'',
			image_forecast_conditions1:'',
			image_forecast_conditions2:'',
			text_forecast_high_temp:'°',
			text_forecast_low_temp:'°',	
		};	
		this.setWidget(PanelCommon.loadTemplate(this.template, day_info, container));
		this.widget.hide();
        return this;
    },
    
    update : function(forecastsItem, icon1src, icon2src){
        Volt.log('DayViewTypeTwo update');
        var text_day_label = this.widget.getChild(1);
        var image_forecast_conditions1 = this.widget.getChild(2);
        var image_forecast_conditions2 = this.widget.getChild(3);
        var text_forecast_temp = this.widget.getChild(4);
        
        text_day_label.text = forecastsItem.day_label;
        image_forecast_conditions1.src = icon1src;
        image_forecast_conditions2.src = icon2src;
        text_forecast_temp.text = Math.floor(forecastsItem.forecast_high_temp)+'°' + '/' + Math.floor(forecastsItem.forecast_low_temp)+'°';
        this.widget.show();
    },
	
	destroy: function(dataPtr,dayContainer) {
        Volt.log('DayViewTypeTwo destroy');
		
		if(dayContainer) {		

			dayContainer.removeChild(dataPtr.widget);	
			dataPtr.widget.id = '';		
			dataPtr.widget.destroy();
			dataPtr.widget = null;
		}
    },
});

function __colorPickingWeather(extractColor){

	if(self.isDestroying) {
		Volt.log("isDestroying widget");
		return;		
	}	


	var fontColor = { r: extractColor.r, g: extractColor.g, b: extractColor.b};

	fontColor.a = 153;
	if(HALOUtil.highContrast){
		Volt.log('highContrast');
		fontColor.r = 255;
		fontColor.g = 255;
		fontColor.b = 255;	
		fontColor.a = 255;
	}
	
    __textColorWidget(self.widget.getChild('text-current-condition-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-current-temp-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-up-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-down-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-up-colon-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-temp-down-colon-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-today-high-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-today-low-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-desc1-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-value1-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-desc2-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-value2-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-desc3-result'), fontColor, 153);
    __textColorWidget(self.widget.getChild('text-feature-value3-result'), fontColor, 153);
    
    if(self.dayView) {
        for(var i = 0; i < selfDayView.dayNum; i++)
        {   
            if(i > 4)
            {
                break;
            }
			__textColorWidget( selfDayView.dayListTypeOne[i].widget.getChild(1), fontColor, 153);
            __textColorWidget( selfDayView.dayListTypeOne[i].widget.getChild(3), fontColor, 153);
			__textColorWidget( selfDayView.dayListTypeTwo[i].widget.getChild(1), fontColor, 153);
            __textColorWidget( selfDayView.dayListTypeTwo[i].widget.getChild(4), fontColor, 153);
        }
    } else {
        Volt.log('error to colorPicking day');
    }
}

function __colorWidget(widget, color, a) {
    if(a == undefined) {
        a = 255;
    }
    if(widget) {
        widget.color = { r: color.r, g: color.g, b: color.b, a: color.a };
    }
}

function __textColorWidget(widget, textColor, a) {
    if(a == undefined) {
        a = 255;
    }
    if(widget) {
        widget.textColor = { r: textColor.r, g: textColor.g, b: textColor.b, a: textColor.a};
    }
}

exports = WeatherDetailResultView;
