/**
 * @author Zhu Hongjie (hj00.zhu@samsung.com)
 * @fileoverview Weather Setting View.
 * @date 2014/09/11(last modified date)
 * 
 * Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
/* Include libraries*/
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var BaseView = PanelCommon.BaseView;
var Backbone = Volt.require('lib/volt-backbone.js');
var _ = Volt.require('modules/underscore.js')._;
var voltapi = Volt.require('voltapi.js');

/*Require LoadingDialog*/
var LoadingDialog = Volt.require('app/views/loading-view.js');

var DeviceModel = Volt.require('app/common/deviceModel.js');

/*Require customization function*/ 
var customizationButton = Volt.require('app/common/customization-button.js');
var customizationIcon = Volt.require('app/common/customization-icon.js');

var Gridlist = Volt.require('app/views/grid-list-view.js');

/* Include models*/
var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
var WeatherCityListModel = Volt.require('app/models/newson-weather-city-list-model.js');

/* Require Specific template for WeatherSettingView*/
var WeatherSettingTemplate = Volt.requireAppTemplate('newson-weather-setting-template-china.js');
/*Require Common templates of Newson*/
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
/*Require dim view*/
var dimView = PanelCommon.requireView('dim');
/*Create an Mediator to commumicate between WeatherSettingView and its sub Views*/
var Mediator = new PanelCommon.Mediator();
/*Require global Variation*/
var Global = Volt.require('app/common/Global.js');
/*Require GlobalMediator*/
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
/*Require common defines*/
var CommonDefines = Volt.require('app/common/commonDefines.js');
var ToolTip = Volt.require('app/views/tooltip-view.js');
//var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetButton = Volt.require('WinsetUIElement/winsetButton.js');

PanelCommon.mapWidget('WinsetButton', WinsetButton);
//KPI start
var KPI = Volt.require('app/common/kpi-options.js');
var KPIOptions = KPI.WeatherSetting;
var selfSetting = null;
//KPI end

/**
 * @description WeatherSettingView is view of "4.1. Settigs Screen_Weather Settings" in "TV_2015_SmartHub_NewsON_IA
 * Guideline_v1.0a_20140718.pdf", and "News Setting / China" in "2015_News_GUI_Guideline_v1.0a_20140718.pdf".
 * @class WeatherSettingView
 * 
 * @property {Widget} widget - Basic Widget of this view. All content of this view should be drawn on this widget.
 * @property {Function} render - Core function to render element in this View.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} hide - Hide this view. Invoked when leave from this view
 * @property {Function} onKeyEvent - Let the View have the chance to handle key events in this view.
 * @property {Function} renderTitle - Render title.
 * @property {Function} renderContainer - Render container.
 * @property {Function} renderPopup - Render popup.
 * @property {Function} backToMainView - Back to panel main view.
 * @property {Function} onError - Callback of WeatherSettingModel if WeatherSettingModel fetch error.
 * @property {Function} setFocus - Set focus by index
 * @property {Function} updateToServer - Update selected cities to server
 * @property {Function} pause - Pause this view. Invoked when some popup view popup over this View
 * @property {Function} resume - Invoked when come back from popup
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 * @requires {@link Volt}
 * @requires {@link Volt.Nav}
 * @requires {@link WeatherSettingModel}
 * @requires {@link WeatherCityListModel}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link LoadingDialog}
 */
var WeatherSettingView = BaseView.extend({
    template : WeatherSettingTemplate.main,
    isFresh : true,
    successLock : false,
    /**
     * @description Render the static display elements.
     * @function render
     * @memberof WeatherSettingView
     * @return {View} return this WeatherSettingView
     */
    render : function() {
        Volt.log();

        /* Parse and load the template*/
        this.setWidget(PanelCommon.loadTemplate(this.template, null, null, false));
        /*Render every sub view*/
        this.renderTitle();
        this.renderContainer();
//        this.renderPopup();
        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof WeatherSettingView
     * @param {Object} options - All options from router path or navigate/back parameters.
     * @param {String} animationType - Type of Animation
     * @return None
     */
    show : function(options, animationType) {
        Volt.log();
        Volt.Nav.block();

        this.isFresh = true;
        /* Listen to this event to set focus to city when focusIndex is 2, and hide the loadingDialog, and unblock*/
        this.listenTo(Mediator, CommonDefines.Event.SET_FOCUS_BY_INDEX, this.setFocus);

        /* Listen to this event to update the server data by WeatherSettingModel*/
        this.listenTo(Mediator, CommonDefines.Event.UPDATE_SETTING_CITIES_TO_SERVER, this.updateToServer);

        this.listenTo(WeatherSettingModel, 'complete', function(cityListLength) {
            if (cityListLength > 0) {
                /* Listen to completed parse in WeatherCityListModel to update provincecontent and citycontent*/
                this.listenTo(WeatherCityListModel, 'complete', function(object, staus) {
					Volt.log('complete status:'+ staus);
	                if(staus == 'success' && !selfSetting.successLock){	
	                    WeatherSettingModel.beginListeningChange();
	                    selfSetting.isShow = true;
	                    Mediator.trigger(CommonDefines.Event.REFRESH_PROVINCE);
	                    Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_2);
                        selfSetting.successLock = true;
	                }
                });

                /* Listen to the status of error in WeatherCityListModel to handle error*/
                this.listenTo(WeatherCityListModel, 'error', this.onError.bind(this));

                /* Listen to the status of saveSuccess in WeatherSettingModel to show save popup*/ 
                this.listenTo(WeatherSettingModel, 'success', function() {
                    var ErrorHandler = Volt.require('app/common/errorHandler.js');
                    ErrorHandler.show(CommonDefines.PopupType.SAVE, null, this.backToMainView);
                });

                WeatherCityListModel.setInitData();
                WeatherCityListModel.fetch({});
            } else {
                Volt.log('Should not be here!');
                this.onError({status:0, msg:'0 city is currently saved on server.'});
            }
        }.bind(this));

        this.containerView.show();
        this.titleView.show();
//        this.popupView.show();

        this.loadingDialog = LoadingDialog;
        this.loadingDialog.show(1);
        
      //KPI start
        selfSetting = this;
        this.model = WeatherSettingModel;
        this.KPISave = new KPIOptions.Save(this);
        this.KPICancel = new KPIOptions.Cancel(this);
	//KPI end
        if(Volt.is720p){
            WeatherSettingModel.fetch();
            this.widget.show();
        }else {
            PanelCommon.doViewSwitchAni(this.widget, animationType).then(function() {
                WeatherSettingModel.fetch();
                if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
                {
                    print('wether setting view show');
                    print(VDUtil.getProcMemory());
                }
            });
        }
        this.listenTo(DeviceModel, 'change:languageCode', this.updateTextbyLang);
    },

    updateTextbyLang : function(){
        this.containerView.tipView.updateTextbyLang();
        selfButtonView.updateTextbyLang();
    },

    /**
     * @description Opposite operation of show, hide what you have shown.
     * @function hide
     * @memberof WeatherSettingView
     * @param {Object} options - All options from router path or navigate/back parameters.
     * @param {String} animationType - Type of Animation
     * @return {Object} return deferred.promise
     */
    hide : function(options, animationType) {
        selfSetting.isShow = false;
        Volt.log();
        var deferred = Q.defer();
        Volt.Nav.focus(null);
        this.stopListening();
        if(this.loadingDialog) {
            this.loadingDialog.hide();
            Volt.Nav.unblock();
            this.loadingDialog = null;
        }
        Mediator.off();
        this.stopListening(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        if(Volt.is720p){
            this.containerView.release();
            deferred.resolve();
            this.widget.hide();
        }else{
            PanelCommon.doViewSwitchAni(this.widget, animationType).then(function() {
                this.containerView.release();
                deferred.resolve();
                if(Global.MEMORY_TEST_STATUS == Global.MEMORY_TEST_ON)
                {
                    print('wether setting view hide');
                    gc();
                    print(VDUtil.getProcMemory());
                }
            }.bind(this));
        }
        this.successLock = false; //this lock in case of voltapi request muti response;
        return deferred.promise;
    },

    /**
     * @description View handle key event, if return false, let nav to handle this key event.
     * @function onKeyEvent
     * @memberof WeatherSettingView
     * @param {enum} keyCode - key code
     * @param {enum} keyType - key type
     * @return {boolean} return the status of handle key event
     */
    onKeyEvent : function(keyCode, keyType) {
        if(keyType == Volt.EVENT_KEY_RELEASE)
            return false;
        
        if (keyCode == Volt.KEY_RETURN) {
            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            //ErrorHandler.show(CommonDefines.PopupType.CANCEL);
            ErrorHandler.show(CommonDefines.PopupType.CANCEL,null,selfSetting.CancelCallback);
            
            return true;
        }
        return false;
    },

	CancelCallback : function() {
		//selfButtonView.cancelButton.removeListener(selfButtonView.CancelButtonListener);
		Global.LeaveWayForKPILog.set('RETURN');
		Backbone.history.back();
    },
	
    /**
     * @description Render title.
     * @function renderTitle
     * @memberof WeatherSettingView
     * @return None
     */
    renderTitle : function(){
        (this.titleView || (this.titleView = new TitleView({
            widget : this.widget.getChild('newson-weather-setting-title-area')
        }))).render();
    },

    /**
     * @description Render container.
     * @function renderContainer
     * @memberof WeatherSettingView
     * @return None
     */
    renderContainer : function() {
        (this.containerView || (this.containerView = new ContainerView({
            widget : this.widget.getChild('newson-weather-setting-container-area')
        }))).render();
    },

    /**
     * @description Back to panel main view.
     * @function backToMainView
     * @memberof WeatherSettingView
     * @return None
     */
    backToMainView : function() {
        //Global.LeaveWayForKPILog.set('RETURN');
        Backbone.history.back();
    },

    /**
     * @description Callback of WeatherSettingModel if WeatherSettingModel fetch error.
     * @function onError
     * @memberof WeatherSettingView
     * @param {Object} object - the http request object
     * @param {String} status - show the http request's status
     * @param {String} exception - pass the exception
     * @return None
     */
    onError : function(object, status, exception) {
        Volt.log();
        Volt.Nav.unblock();
        selfSetting.loadingDialog.hide();
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        
        if(arguments.length === 0){
            ErrorHandler.show(CommonDefines.PopupType.EM_FROM_CITYLIST_SERVER, null, selfSetting.backToMainView);
        } else {
            var errorCode = object?object.status : CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE;
            ErrorHandler.handleNetworkError(errorCode,selfSetting.backToMainView);
        }
    },
    
    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.SET_FOCUS_BY_INDEX);].
     * @description Set focus by index
     * @function setFocus
     * @memberof WeatherSettingView
     * @param {Number} index - the focus index
     * @return None
     */
    setFocus : function(focusIndex) {
        Volt.log('focusIndex - ' + focusIndex);
        if(Global.APP_STATUS === Global.APP_DEACTIVATE)
        {
            this.lastFocusIndex = focusIndex;
            Volt.log('Global.APP_DEACTIVATE');
        } 
        else
        {
            this.lastFocusIndex = null;
            if (focusIndex == 2) {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_CITY, this.widget);
            } else {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_PROVINCE, this.widget);
            }
            Volt.log('Global.APP_ACTIVATE');
        }
        if(this.loadingDialog) {
            this.loadingDialog.hide();
            Volt.Nav.unblock();
            this.loadingDialog = null;
        }
    },
    
    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.UPDATE_SETTING_CITIES_TO_SERVER);].
     * @description Update selected cities to server
     * @function updateToServer
     * @memberof WeatherSettingView
     * @return None
     */
    updateToServer : function() {
        if (-1 == DeviceModel.getNetWorkState()) {
            Volt.Nav.focus(null);
            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            ErrorHandler.show(CommonDefines.PopupType.NETWORK_ERROR1, CommonDefines.ErrorCode.NETWORK_ERROR_CODE, this.backToMainView);
            return;
        }
        WeatherSettingModel.updateToServer();
    },
    
    /**
         * Pause this view. Invoked when some popup view popup over this View
         * @function
         * @memberof WeatherSettingView
         */
    pause : function() {
        Volt.log();
        dimView.show({
            parent : Volt.WinsetRoot
        });
    },

    /**
     * Invoked when come back from popup
     * @function
     * @memberof WeatherSettingView
     */
    resume : function() {
        Volt.log();
        dimView.hide();
        Volt.log('lastFocusIndex - ' + this.lastFocusIndex);
        if (this.lastFocusIndex != null) {
            if (this.lastFocusIndex == 2) {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_CITY, this.widget);
            } else {
                Mediator.trigger(CommonDefines.Event.SET_FOCUS_TO_PROVINCE, this.widget);
            }
            this.lastFocusIndex = null;
        }
    }


});

/**
 * @description TitleView is sub view of WeatherSettingView.
 * @class TitleView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Function} render - Core function to render element in the View.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} hide - Hide this view. Invoked when back to other View
 * @property {Function} renderText - Render the text of title.
 * @property {Function} renderReturnButton - Render the return button.
 * @property {Function} onChangeCursor - Show or Hide Return button
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var TitleView = BaseView.extend({
    template : WeatherSettingTemplate.titleArea,

    /**
     * @description Render the static display elements.
     * @function render
     * @memberof TitleView
     * @return {View} return this TitleView
     */
    render : function() {
        Volt.log();
        this.setWidget(PanelCommon.loadTemplate(this.template, null, this.widget));
        this.renderText();
        this.renderReturnButton();
        this.renderCloseButton();
        return this;
    },
    
    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof TitleView
     * @return None
     */
    show : function(){
        if( !voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
            Volt.log();
            this.returnButton.hide();
            this.closeButton.hide();
        } else {
            this.widget.getDescendant('newson-weather-setting-title-text').x = this.template.children[0].x_cursor;
            this.returnButton.show();
            this.closeButton.show();
        }

        this.listenTo(GlobalMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
    },
    
    /**
     * @description Render the text of title.
     * @function renderText
     * @memberof TitleView
     * @return None
     */
    renderText : function() {
        this.text = this.widget.getDescendant('newson-weather-setting-title-text');
    },

    /**
     * @description Render the return button.
     * @function renderReturnButton
     * @memberof TitleView
     * @return None
     */
    renderReturnButton : function() {
        this.returnButton = this.widget.getDescendant('newson-weather-setting-return-button');
        customizationIcon(this.returnButton, {
            imageStyle : 'pageReturn'
        });
        this.returnButton.onMouseOver = function(){
            var opt = {
    			text: Volt.i18n.t('COM_SID_RETURN'),
    			x: this.returnButton.x,
    			y: this.returnButton.y,
    			width: this.returnButton.width,
    			height: this.returnButton.height,
    			direction:'up',
    			parent: this.returnButton
    		};
    		
    		ToolTip.show(opt, CommonTemplate.tooltip);
            return true;
        }.bind(this);
        this.returnButton.onMouseOut = function(){
            ToolTip.hide();
            return true;
        };
        this.returnButton.onMouseClick = function() {
            ToolTip.hide();
            //KPI log start
            //record RETURN kpi event log
            var kpiReturn = new KPI.Common.Return();
            kpiReturn.send({cp : 'H05_WEATHER', rw : 'POINTING_RETURN'});
            Global.LeaveWayForKPILog.set('POINTING_RETURN');
            //kpi log end

            var ErrorHandler = Volt.require('app/common/errorHandler.js');
            //ErrorHandler.show(CommonDefines.PopupType.CANCEL);
            ErrorHandler.show(CommonDefines.PopupType.CANCEL,null,selfSetting.CancelCallback);

        };
    },

    
    /**
     * @description Render the close button.
     * @function renderCloseButton
     * @memberof TitleView
     * @return None
     */
    renderCloseButton : function() {
        this.closeButton = this.widget.getDescendant('newson-weather-setting-close-button');
        customizationIcon(this.closeButton, {
            imageStyle : 'pageClose'
        });
        this.closeButton.onMouseClick = function(){
            ToolTip.hide();
            //Volt.exit();
            //kpi log start
            Global.ExitWayForKPILog.set('POINTING_X');
            Global.LeaveWayForKPILog.set('POINTING_X');
            Global.LeaveByReturnForKPILog.set(true);
            //kpi log end
            Volt.exit();
        };
        this.closeButton.onMouseOver = function(){
            var opt = {
    			text: Volt.i18n.t('COM_SID_EXIT'),
    			x: this.closeButton.x,
    			y: this.closeButton.y,
    			width: this.closeButton.width,
    			height: this.closeButton.height,
    			direction:'up',
    			parent: this.closeButton
    		};
    		
    		ToolTip.show(opt, CommonTemplate.tooltip);
            return true;
        }.bind(this);
        this.closeButton.onMouseOut = function(){
            ToolTip.hide();
            return true;
        };
    },
    
    /** 
     * This function will be called when coding like [GlobalMediator.trigger(CommonDefines.Event.CHANGE_VISIBLE_CURSOR);].
     * Show or Hide Return button
     * @function onChangeCursor
     * @memberof TitleView
     */
     onChangeCursor : function(visible){
        Volt.log();
        if( this.returnButton ){
            if(visible){
                this.widget.getDescendant('newson-weather-setting-title-text').x = this.template.children[0].x_cursor;
                this.returnButton.show();
                this.closeButton.show();
            }else{
                this.widget.getDescendant('newson-weather-setting-title-text').x = this.template.children[0].x;
                this.returnButton.hide();
                this.closeButton.hide();
            }
        }
     },
});

/**
 * @description ContainerView is sub view of WeatherSettingView.
 * @class ContainerView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Function} render - Core function to render element in the View.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} renderTipView - Render the tips.
 * @property {Function} renderButtons - Render the buttons.
 * @property {Function} renderProvinceContentView - Render province content.
 * @property {Function} renderCityContentView - Render city content.
 * @property {Function} release - Release resource used in sub view of this view or re-initialize sub view of this view.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var ContainerView = BaseView.extend({
    template : WeatherSettingTemplate.containerArea,

    /**
     * @description Render the static display elements.
     * @function render
     * @memberof ContainerView
     * @return {View} return this ContainerView
     */
    render : function() {
        Volt.log();
        PanelCommon.loadTemplate(this.template, null, this.widget);
        this.renderTipView();
        this.renderButtons();
        this.renderProvinceContentView();
        this.renderCityContentView();

        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof ContainerView
     * @return None
     */
    show : function() {
        this.tipView.show();
        this.provinceView.show();
        this.cityView.show();
        this.buttonView.show();
    },

    /**
     * @description Render the tips.
     * @function renderTipView
     * @memberof ContainerView
     * @return None
     */
    renderTipView : function() {
        (this.tipView || (this.tipView = new TipView({
            widget : this.widget.getDescendant('newson-weather-setting-tip-area')
        }))).render();
    },

    /**
     * @description Render the buttons.
     * @function renderButtons
     * @memberof ContainerView
     * @return None
     */
    renderButtons : function() {
        (this.buttonView || (this.buttonView = new ButtonView({
            widget : this.widget.getDescendant('newson-weather-setting-button-area')
        }))).render();
    },

    /**
     * @description Render province content, include province list
     * @function renderProvinceContentView
     * @memberof ContainerView
     * @return None
     */
    renderProvinceContentView : function() {
        (this.provinceView || (this.provinceView = new ProvinceContentView({
            widget : this.widget.getDescendant('newson-weather-setting-province-content-area')
        }))).render();
    },

    /**
     * @description Render city content, include city list
     * @function renderCityContentView
     * @memberof ContainerView
     * @return None
     */
    renderCityContentView : function() {
        (this.cityView || (this.cityView = new CityContentView({
            widget : this.widget.getDescendant('newson-weather-setting-city-content-area')
        }))).render();
    },

    /**
     * @description Release resource used in sub view of this view or re-initialize sub view of this view.
     * @function release
     * @memberof ContainerView
     * @return None
     */
    release : function() {
        this.provinceView.release();
        this.cityView.release();
        this.tipView.release();
        this.buttonView.release();
    }
});

/**
 * @description TipView is sub view of ContainerView.
 * @class TipView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {TextWidget} selectedCountItem - This widget displays the selected count of WeatherSettingModel.
 * @property {Function} render - Render tip area in this view.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} updateSelectedCount - Update the text of selectedCountItem in this view.
 * @property {Function} release - Release resource used in this view or re-initialize this view.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var TipView = BaseView.extend({
    template : WeatherSettingTemplate.tipArea,
    selectedCountItem : null,

    /**
     * @description Render tip area in this view.
     * @function render
     * @memberof TipView
     * @return {View} return this TipView
     */
    render : function() {
        Volt.log();
        PanelCommon.loadTemplate(this.template, null, this.widget);
        this.selectedCountItem = this.widget.getDescendant('newson-weather-setting-selected-count');
        this.updateSelectedCount(0);
        return this;
    },

    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof TipView
     * @return None
     */
    show : function() {
        /* Listen to this event to update the text of selectedCountItem in this view.*/
        this.listenTo(Mediator, CommonDefines.Event.UPDATE_SELECTED_CITIES_2, this.updateSelectedCount.bind(this));
    },

    updateTextbyLang : function() {
        this.updateSelectedCount(undefined);
    },

    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_2);].
     * @description Update the text of selectedCountItem in this view.
     * @function updateSelectedCount
     * @memberof TipView
     * @param {Number} count - The selected count
     * @return None
     */
    updateSelectedCount : function(count) {
        if('number' != typeof count) {
            count = WeatherSettingModel.getSelectedCount();
        }
        var content;
        if (count > 1) {
            content = Volt.i18n.t('COM_SID_MIX_CITIES_CURRENTLY_SELECTED', {A : count});
        } else {
            content = Volt.i18n.t('COM_SID_1_CITY_CURRENTLY_SELECTED');
            if(count == 0) {
                content = content.replace('1', '0');
            }
        }
        this.selectedCountItem.text = content;
    },

    /**
     * @description Release resource used in this view or re-initialize this view.
     * @function release
     * @memberof TipView
     * @return None
     */
    release : function() {
        this.updateSelectedCount(0);
    }

});

/**
 * @description ButtonView is sub view of ContainerView.
 * @class ButtonView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Button_Generic} cancelButton - The cancel button.
 * @property {Button_Generic} saveButton - The save button.
 * @property {Function} render -Render buttons in this view.
 * @property {Function} renderCancelButton - Render the cancel button.
 * @property {Function} renderSaveButton - Render the save button.
 * @property {Function} onSelectCancelButton - ButtonView's selected callback.
 * @property {Function} onSelectSaveButton - ButtonView's selected callback.
 * @property {Function} onFocus - ButtonView's focus callback.
 * @property {Function} onBlur - ButtonView's blur callback.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link customizationButton}
 */

var selfButtonView = null;
var ButtonView = BaseView.extend({
    template : WeatherSettingTemplate.buttonArea,
    cancelButton : null,
    saveButton : null,

    /**
     * @description Render buttons in this view.
     * @function render
     * @memberof ButtonView
     * @return {View} return this ButtonView
     */
    render : function() {
    	selfButtonView = this;
        Volt.log();
        PanelCommon.loadTemplate(this.template, null, this.widget);
        this.renderSaveButton();
        this.renderCancelButton();
        this.setWidget(this.widget);
        return this;
    },
    
    show : function() {
    	if(selfButtonView && selfButtonView.CancelButtonListener && selfButtonView.cancelButton) {
        	selfButtonView.cancelButton.addListener(selfButtonView.CancelButtonListener);
    	}
    },

    updateTextbyLang : function() {
        if (this.cancelButton){
            this.cancelButton.setText({state:'all', text:Volt.i18n.t('SID_CANCEL')});
        }
        if (this.saveButton){
            this.saveButton.setText({state:'all', text:Volt.i18n.t('SID_DONE')});
        }
    },
    
    release : function() {
        /*
        Volt.setTimeout(function(){
            this.saveButton.release();
            this.cancelButton.release();
            this.saveButton = null;
            this.cancelButton = null;
        }.bind(this), 1);*/
        this.cancelButton.killFocus();
        this.saveButton.killFocus();
    },

    /**
     * @description Render the cancel button.
     * @function renderCancelButton
     * @memberof ButtonView
     * @return None
     */
    renderCancelButton : function() {
        Volt.log();
        this.cancelButton = this.widget.getDescendant('newson-weather-setting-cancel-button');
        this.cancelButton.rootView = this;
        this.CancelButtonListener = new ButtonListener();
        this.CancelButtonListener.onButtonClicked = function(button, type) {
            if(button.id == "newson-weather-setting-cancel-button"){
                button.rootView.onSelectCancelButton();
            }
        };
        this.cancelButton.addListener(this.CancelButtonListener);
        this.cancelButton.custom = {};
        this.cancelButton.custom.focusable = true;
        /*
        this.cancelButton = new Button({
            x : 0,
            y : 0,
            width : cancelButtonWidget.width,
            height : cancelButtonWidget.height,
            color : Volt.hexToRgb('#ffffff', 0),
            parent : cancelButtonWidget
        });
        customizationButton(this.cancelButton, {
            text : Volt.i18n.t('SID_CANCEL'),
            style : CommonTemplate.buttonTextStyleC,
            callback : this.onSelectCancelButton
        });*/
    },

    /**
     * @description Render the save button.
     * @function renderSaveButton
     * @memberof ButtonView
     * @return None
     */
    renderSaveButton : function() {
        Volt.log();
        this.saveButton = this.widget.getDescendant('newson-weather-setting-save-button');
        this.saveButton.rootView = this;
        var buttonListener = new ButtonListener();
        buttonListener.onButtonClicked = function(button, type) {
            if(button.id == "newson-weather-setting-save-button"){
                button.rootView.onSelectSaveButton();
            }
        };
        this.saveButton.addListener(buttonListener);
        this.saveButton.custom = {};
        this.saveButton.custom.focusable = true;
        /*
        this.saveButton = new Button({
            x : 0,
            y : 0,
            width : saveButtonWidget.width,
            height : saveButtonWidget.height,
            color : Volt.hexToRgb('#ffffff', 0),
            parent : saveButtonWidget
        });
        customizationButton(this.saveButton, {
            text : Volt.i18n.t('SID_DONE'),
            style : CommonTemplate.buttonTextStyleC,
            callback : this.onSelectSaveButton
        });*/
    },

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    /**
     * @description ButtonView's selected callback.
     * @function onSelectCancelButton
     * @memberof ButtonView
     * @return None
     */
    onSelectCancelButton : function() {
        //KPI start
        selfSetting.KPICancel.send();
        //KPI end
        Volt.log();
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        ErrorHandler.show(CommonDefines.PopupType.CANCEL,null,selfButtonView.CancelCallback);
    },

	CancelCallback : function() {
		selfButtonView.cancelButton.removeListener(selfButtonView.CancelButtonListener);
        Global.LeaveWayForKPILog.set('CANCEL');
		Backbone.history.back();
    },
	

    /**
     * @description ButtonView's selected callback.
     * @function onSelectSaveButton
     * @memberof ButtonView
     * @return None
     */
    onSelectSaveButton : function() {
        //KPI start
        selfSetting.KPISave.send();
        Global.LeaveWayForKPILog.set('SAVE');
        //KPI end
        Volt.log();
        Mediator.trigger(CommonDefines.Event.UPDATE_SETTING_CITIES_TO_SERVER);
    },

    /**
     * @description ButtonView's focus callback.
     * @function onFocus
     * @memberof ButtonView
     * @param {Widget} widget - the widget is focused
     * @return None
     */
    onFocus : function(widget) {
        Volt.log('Button');
        widget.setFocus();
        /*
        if(widget.getChild(0)){
            widget.getChild(0).setFocus();
        }*/
        //voice guide
        if (1 == DeviceModel.getMenuTTS()){
            var voiceText = 'Done, button';
            if ('newson-weather-setting-cancel-button' == widget.id){
                voiceText = 'Cancel, button';
            }
            Global.voiceGuide(voiceText);
        }
    },

    /**
     * @description ButtonView's blur callback.
     * @function onBlur
     * @memberof ButtonView
     * @param {Widget} widget - the widget is blurred
     * @return None
     */
    onBlur : function(widget) {
        Volt.log('Button');
        widget.killFocus();
        /*
        if(widget.getChild(0)){
            widget.getChild(0).killFocus();
        }*/
    }

});
ProvinceContentViewSelf = null;
/**
 * @description ProvinceContentView is sub view of ContainerView.
 * @class ProvinceContentView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {GridListControl} list - The list of this view.
 * @property {Function} render - Render list, list background in this view.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} provinceRefresh - Update the data of list in this view.
 * @property {Function} release - Release resource used in this view or re-initialize this view.
 * @property {Function} renderList - Render list in this view.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link WeatherCityListModel}
 * @requires {@link customizationIcon}
 */
var ProvinceContentView = BaseView.extend({
    template : WeatherSettingTemplate.provinceContentArea,
    list : null,
    provinceButtonLeft : null,
    provinceButtonRight : null,
    initialize : function () {
        ProvinceContentViewSelf = this;
    },
    /**
     * @description Render list, list background in this view.
     * @function render
     * @memberof ProvinceContentView
     * @return {View} return this ProvinceContentView
     */
    render : function() {
        PanelCommon.loadTemplate(this.template, null, this.widget);
        //added by yipeng.zhu 2014.12.04
        //add button listener
        this.provinceButtonLeft = this.widget.getChild(0);//get left button of provice
        this.provinceButtonRight = this.widget.getChild(1);//get left button of provice
        this.provinceButtonLeft.addEventListener('OnMouseOver', function() {
            ProvinceContentViewSelf.provinceButtonLeft.opacity = 255;
        });
        this.provinceButtonLeft.addEventListener('OnMouseOut', function() {
            ProvinceContentViewSelf.provinceButtonLeft.opacity = 255 * 0.5;
        });
        this.provinceButtonLeft.addEventListener('OnMouseClick', function() {
            if(ProvinceContentViewSelf.list != null && ProvinceContentViewSelf.list.widget){
                if(ProvinceContentViewSelf.list.widget.index == 0){
                    ProvinceContentViewSelf.list.widget.changeTab(ProvinceContentViewSelf.list.widget.total - 1);
                }else{
                    ProvinceContentViewSelf.list.widget.changeTab(ProvinceContentViewSelf.list.widget.index - 1);
                }
            }
        });
        this.provinceButtonRight.addEventListener('OnMouseOver', function() {
            ProvinceContentViewSelf.provinceButtonRight.opacity = 255;
        });
        this.provinceButtonRight.addEventListener('OnMouseOut', function() {
            ProvinceContentViewSelf.provinceButtonRight.opacity = 255 * 0.5;
        });
        this.provinceButtonRight.addEventListener('OnMouseClick', function() {
            if(ProvinceContentViewSelf.list != null && ProvinceContentViewSelf.list.widget){
                //ProvinceContentViewSelf.list.widget.moveFocus("Right");
                if(ProvinceContentViewSelf.list.widget.index == ProvinceContentViewSelf.list.widget.total - 1){
                    ProvinceContentViewSelf.list.widget.changeTab(0);
                }else{
                    ProvinceContentViewSelf.list.widget.changeTab(ProvinceContentViewSelf.list.widget.index + 1);
                }
            }
        });
        this.provinceButtonRight.hide();
        this.provinceButtonLeft.hide();
        //end of add 2014.12.04
        return this;
    },
    /**
     * @description Update indicator
     * @function updateIndicator
     * @memberof ProvinceContentView
     * @return None
     */
    updateIndicator : function(focusIndex){
        print('update province view indicator');
        if(focusIndex == 2){
            this.provinceButtonRight.hide();
            this.provinceButtonLeft.hide();
        }else{
            this.provinceButtonRight.show();
            this.provinceButtonLeft.show();
        }
    },
    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof ProvinceContentView
     * @return None
     */
    show : function() {
        /* Listen to this event to update the data of list in this view*/
        this.listenTo(Mediator, CommonDefines.Event.REFRESH_PROVINCE, this.provinceRefresh);

        /* Listen to this event to set focus to the list of this view*/
        this.listenTo(Mediator, CommonDefines.Event.SET_FOCUS_TO_PROVINCE, function(root) {
            Volt.Nav.setRoot(root, {
                focus : this.list.widget
            });
        }.bind(this));
    },

    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.REFRESH_PROVINCE)].
     * @description Update the data of list in this view.
     * @function provinceRefresh
     * @memberof ProvinceContentView
     * @return None
     */
    provinceRefresh : function() {
        Volt.log(JSON.stringify(WeatherCityListModel.get('provinceCollection').pluck('index')));
        this.renderList(WeatherCityListModel.get('provinceCollection').pluck('province'));
    },

    /**
     * @description Release resource used in this view or re-initialize this view.
     * @function release
     * @memberof ProvinceContentView
     * @return None
     */
    release : function() {
        Volt.log('release');
    	if(this.list!=null) {
	        this.list.destroy();
	        this.list = null;
    	}
    },

    /**
     * @description Render list in this view.
     * @function renderList
     * @memberof ProvinceContentView
     * @return None
     */
    renderList : function(provinces) {
        if(this.list == null){
            this.list = new ProvinceList(this.widget.getDescendant('newson-weather-setting-province-list'), provinces.length, this);
        }
        if(this.list != null){
            this.list.render(provinces);
        }
    }
    
});
CityContentViewSelf = null;
/**
 * @description CityContentView is sub view of ContainerView.
 * @class CityContentView
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {GridListControl} list - The list of this view.
 * @property {Object} cityCollection - The collection of city of WeatherCityListModel.
 * @property {Number} provinceIndex - The index of the selected province.
 * @property {Function} render - Render list, list background in this view.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} updateSelectedCity - Update the codeArray of WeatherSettingModel.
 * @property {Function} cityRefresh - Update the data of list in this view.
 * @property {Function} release - Release resource used in this view or re-initialize this view.
 * @property {Function} renderList - Render list in this view.
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link WeatherCityListModel}
 * @requires {@link WeatherSettingModel}
 * @requires {@link customizationIcon}
 */
var CityContentView = BaseView.extend({
    template : WeatherSettingTemplate.cityContentArea,
    list : null,
    cityCollection : null,
    provinceIndex : null,
    cityButtonLeft : null,
    cityButtonRight : null,
    divisionMgr: [],
    initialize : function () {
        CityContentViewSelf = this;
    },
    /**
     * @description Render list, list background in this view.
     * @function render
     * @memberof CityContentView
     * @return {View} return this CityContentView
     */
    render : function() {
        PanelCommon.loadTemplate(this.template, null, this.widget);
        //added by yipeng.zhu 2014.12.04
        //add button listener
        this.cityButtonLeft = this.widget.getChild(0);//get left button of city
        this.cityButtonRight = this.widget.getChild(1);//get left button of city
        this.divisionMgr.push(this.widget.getChild(2));
        this.divisionMgr.push(this.widget.getChild(3));
        this.divisionMgr.push(this.widget.getChild(4));
        this.divisionMgr.push(this.widget.getChild(5));
        this.cityButtonLeft.addEventListener('OnMouseOver', function() {
            CityContentViewSelf.cityButtonLeft.opacity = 255;
        });
        this.cityButtonLeft.addEventListener('OnMouseOut', function() {
            CityContentViewSelf.cityButtonLeft.opacity = 255 * 0.5;
        });
        this.cityButtonLeft.addEventListener('OnMouseClick', function() {
            if(CityContentViewSelf.list != null && CityContentViewSelf.list.widget){
                CityContentViewSelf.list.widget.moveFocus("Left");
            }
        });
        this.cityButtonRight.addEventListener('OnMouseOver', function() {
            CityContentViewSelf.cityButtonRight.opacity = 255;
        });
        this.cityButtonRight.addEventListener('OnMouseOut', function() {
            CityContentViewSelf.cityButtonRight.opacity = 255 * 0.5;
        });
        this.cityButtonRight.addEventListener('OnMouseClick', function() {
            if(CityContentViewSelf.list != null && CityContentViewSelf.list.widget){
                CityContentViewSelf.list.widget.moveFocus("Right");
            }
        });
        this.cityButtonRight.hide();
        this.cityButtonLeft.hide();
        //end of add 2014.12.04
        return this;
    },
    
    /**
     * @description Update button show&hide.
     * @function updateIndicator
     * @memberof CityContentView
     * @return None
     */
    
    updateIndicator: function(focusIndex){
        print('update city view indicator');
        if(focusIndex == 2){
            if(this.cityCollection && this.cityCollection.length > 16){
                this.cityButtonRight.show();
                this.cityButtonLeft.show();
            }else if(this.cityCollection && this.cityCollection.length <= 16){
                this.cityButtonRight.hide();
                this.cityButtonLeft.hide();
            }
        } else {
            this.cityButtonRight.hide();
            this.cityButtonLeft.hide();
        }
    },
    
    /**
     * @description Show this view. Invoked when come back from other View
     * @function show
     * @memberof CityContentView
     * @return None
     */
    show : function() {
        /* Listen to this event to update the codeArray of WeatherSettingModel.*/
        this.listenTo(Mediator, CommonDefines.Event.UPDATE_SELECTED_CITIES_1, this.updateSelectedCity.bind(this));

        /* Listen to this event to set focus to the list of this view*/
        this.listenTo(Mediator, CommonDefines.Event.SET_FOCUS_TO_CITY, function(root) {
            Volt.Nav.setRoot(root, {
                focus : this.list.widget
            });
        }.bind(this));

        /* Listen to this event to update the data of list in this view*/
        this.listenTo(Mediator, CommonDefines.Event.REFRESH_CITY, this.cityRefresh.bind(this));
    },

    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_1)].
     * @description update the codeArray of WeatherSettingModel.
     * @function updateSelectedCity
     * @memberof CityContentView
     * @param {Number} index - The index of selected city
     * @return None
     */
    updateSelectedCity : function(index) {
        WeatherSettingModel.updateCityStatus(this.cityCollection.at(index).get('code'));
        Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_2);
    },
    
    updateDivison : function(){
        if(this.divisionMgr.length != 4){
            return;
        }
        Volt.log('updateDivison this.cityCollection.length'+this.cityCollection.length);
        Volt.log('updateDivison this.divisionMgr.length'+this.cityCollection.length);
        if(this.cityCollection.length <= 1){
            for(var i = 0; i < this.divisionMgr.length;i++){
                this.divisionMgr[i].opacity = 0;
            }
        }else if(this.cityCollection.length >= 2 && this.cityCollection.length < 4){
            for(var i = 0; i < this.divisionMgr.length;i++){
                if(i < this.cityCollection.length){
                    this.divisionMgr[i].opacity = 255;
                } else {
                    this.divisionMgr[i].opacity = 0;
                }
            }
        }else {
            for(var i = 0; i < this.divisionMgr.length;i++){
                this.divisionMgr[i].opacity = 255;
            }
        }
    },
    
    /**
     * This function will be called when coding like [Mediator.trigger(CommonDefines.Event.REFRESH_CITY)].
     * @description Update the data of list in this view.
     * @function cityRefresh
     * @memberof CityContentView
     * @param {Number} index - the selected province index
     * @param {Boolean} focusIndex - if city should get focus focusIndex is 2.
     * @return None
     */
    cityRefresh : function(index, focusIndex) {
        Volt.log('index - ' + index + ' oldIndex - ' + this.provinceIndex + ' focusIndex - ' + focusIndex);
        //if(this.provinceIndex !== index){
        this.provinceIndex = index;
        this.cityCollection = WeatherCityListModel.get('provinceCollection').at(index).get('cityCollection');
        Volt.log(JSON.stringify(this.cityCollection.pluck('index')));
        
        if(this.list === null)
            this.renderList(this.cityCollection);
        else
            this.updateList(this.cityCollection);
        this.updateDivison();
        this.list.widget.provinceName = WeatherCityListModel.get('provinceCollection').at(index).get('province');
        Mediator.trigger(CommonDefines.Event.SET_FOCUS_BY_INDEX, focusIndex);
        //}
    },

    /**
     * @description Release resource used in this view or re-initialize this view.
     * @function release
     * @memberof CityContentView
     * @return None
     */
    release : function() {
        this.provinceIndex = null;
        this.cityCollection = null;
		if(this.list!=null){
	        this.list.destroy();
	        this.list = null;
		}
    },


    /**
     * @description Render list in this view.
     * @function renderList
     * @memberof CityContentView
     * @return None
     */
    renderList : function(cityCollection) {
        Volt.log('cityCollection.length:'+cityCollection.length)
        Volt.log(cityCollection);
        this.list = new CityList(this.widget.getDescendant('newson-weather-setting-city-list'), cityCollection.length, this).render(cityCollection);
    },
    
    updateList : function(cityCollection)
    {
        this.list.render(cityCollection);
    }

});

/**
 * @description ProvinceList is the list of ProvinceContentView.
 * @class ProvinceList
 * 
 * @property {GridListControl} widget - Basic Widget of this view.
 * @property {Function} render - Render list.
 * @property {Function} onFocus - ProvinceList's focus callback.
 * @property {Function} onBlur - ProvinceList's blur callback.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */

var selfProvinceList = null;
var ProvinceList = BaseView.extend({
    template : WeatherSettingTemplate.provinceList,
	ProvinceData:[],
    parentView : null,
    /**
     * @description initialize list.
     * @function initialize
     * @memberof ProvinceList
     */
    initialize : function(container, length, provinceView){
    	selfProvinceList = this;
        this.parentView = provinceView;
        
        //var provinceList = new Gridlist(this.template, container).render().widget;
        var provinceList = PanelCommon.loadTemplate(this.template, null, container);
        this.setWidget(provinceList);
        var maxProvinceLen = 35;
        __initProvinceList(this.widget, maxProvinceLen);
    },

    /**
     * @description Render list.
     * @function render
     * @memberof ProvinceList
     * @return {View} return this ProvinceList
     */
    render : function(provinces) {
        Volt.log();
        __updateProvinceList(this.widget, provinces);
        return this;
    },
    
    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    /**
     * @description ProvinceList's focus callback.
     * @function onFocus
     * @memberof ProvinceList
     * @param {Widget} widget - the widget is focused
     * @return None
     */
    onFocus : function(widget) {
        Volt.log('ProvinceList');
        if(selfSetting && selfSetting.isShow) {
            if(widget) {
                widget.enableFocus();
                widget.setFocus();
                Volt.log('ProvinceList on setFocus');
                widget.showFocus("false");
            }
        }
        if(this.parentView){
            this.parentView.updateIndicator(1);
        }
    },

    /**
     * @description ProvinceList's blur callback.
     * @function onBlur
     * @memberof ProvinceList
     * @param {Widget} widget - the widget is blurred
     * @return None
     */
    onBlur : function(widget) {
        Volt.log('ProvinceList');
        if(selfSetting && selfSetting.isShow) {
            if (widget){
                widget.hideFocus("false");
                widget.killFocus();
            }
        }
        if(this.parentView){
            this.parentView.updateIndicator(2);
        }
    },
    
    destroy : function() {
        Volt.log('ProvinceList');
        this.widget.destroy();
        delete this.widget;
        this.widget = null;
    }
});

/**
 * @description CityList is the list of CityContentView.
 * @class CityList
 * 
 * @property {GridListControl} widget - Basic Widget of this view.
 * @property {Function} render - Render list.
 * @property {Function} show - Show this view. Invoked when come back from other View
 * @property {Function} onFocus - CityList's focus callback.
 * @property {Function} onBlur - CityList's blur callback.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 * @requires {@link WeatherSettingModel}
 */
var selfCityList = null; 
var CityList = BaseView.extend({
    template : WeatherSettingTemplate.cityList,
	CityData:[],
    parentView:null,
    /**
     * @description initialize list.
     * @function initialize
     * @memberof CityList
     */
    initialize : function(container, size, cityView){
    	selfCityList = this;
        this.parentView = cityView;
        var cityList = new Gridlist(this.template, container).render().widget;
        this.setWidget(cityList);
        __initCityList(this.widget, 100);
//        __initCityList(this.widget, WeatherCityListModel.get('max_cities_num'));
    },
    /**
     * @description Render list.
     * @function render
     * @memberof CityList
     * @return {View} return this CityList
     */
    render : function(cityCollection) {
        Volt.log();
        __updateCityList(this.widget, cityCollection);
        return this;
    },
    
    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    /**
     * @description CityList's focus callback.
     * @function onFocus
     * @memberof CityList
     * @param {Widget} widget - the widget is focused
     * @return None
     */
    onFocus : function(widget) {
        Volt.log('CityList');
        if(selfSetting && selfSetting.isShow) {
            if(widget) {
                widget.enableFocus();
                widget.setFocus();
                Volt.log('CityList on setFocus');
                widget.showFocus("false");
            }
        }
        this.parentView.updateIndicator(2);
    },

    /**
     * @description CityList's blur callback.
     * @function onBlur
     * @memberof CityList
     * @param {Widget} widget - the widget is blurred
     * @return None
     */
    onBlur : function(widget) {
        Volt.log('CityList');
        if(selfSetting && selfSetting.isShow) {
            if (widget){
                widget.hideFocus("false");
                widget.killFocus();
            }
        }
        this.parentView.updateIndicator(1);
    },
    
    destroy : function() {
        Volt.log('CityList');
        this.widget.destroy();
        delete this.widget;
        this.widget = null;
    }

});

/**
 * @description CityItem is the widget item used in CityList.
 * @class CityItem
 * 
 * @property {Widget} widget - Basic Widget of this view.
 * @property {Function} render - Render widget item.
 * @property {Function} setFocus - Show highlight text when the item onFocus.
 * @property {Function} killFocus - Show normal text when the item onBlur.
 * @property {Function} setCheckStatus - Update the status of this widget.
 * @property {Function} getCheckStatus - Get the status of this widget.
 * 
 * @requires {@link PanelCommon}
 * @requires {@link WeatherSettingTemplate}
 */
var CityItem = BaseView.extend({
    template : WeatherSettingTemplate.cityItem,
    
    /**
     * @description Render list.
     * @function render
     * @memberof CityItem
     * @return {View} return this CityItem
     */
    render : function(parent, cityName, isChecked, isShownDivision) {
        this.widget = PanelCommon.loadTemplate(this.template, {
            cityName : cityName
        }, parent);
        Volt.log('cityItem.cityName'+cityName);
        this.widget.onFocus = this.onFocus;
        this.widget.onBlur = this.onBlur;
        this.widget.setCheckStatus = this.setCheckStatus;
        this.widget.getCheckStatus = this.getCheckStatus;
        this.widget.updateCityItem = this.updateCityItem;
        this.widget.setIsShownDivision = this.setIsShownDivision;
        this.widget.setCheckStatus(isChecked);
        return this;
    },
    
    /**
     * @description Update the city name and status
     * @function updateCityItem
     * @memberof CityItem
     * @return None
     */
    /*
    updateCityItem : function(cityName, isChecked, isShownDivision){
        Volt.log("updateCityItem0:"+cityName);
        if(isChecked !== undefined) {
            this.setCheckStatus(isChecked);
        }
    },
    */
    /**
     * @description Show highlight text when the item onFocus.
     * @function setFocus
     * @memberof CityItem
     * @return None
     */
    onFocus : function() {
        Volt.log('city item focus');
        var thumbnail = this;
        if(!DeviceModel.getEnlarge()){
            Volt.log('not large focus');
            thumbnail.setInformationTextFont('text1','Samsung SVD_Light 38px');
        }
    },

    /**
     * @description Show normal text when the item onFocus.
     * @function killFocus
     * @memberof CityItem
     * @return None
     */
    onBlur : function() {
        Volt.log('city item onblur');
        var thumbnail = this;
        if(!DeviceModel.getEnlarge()){
            Volt.log('not large blur');
            thumbnail.setInformationTextFont('text1','Samsung SVD_Light 35px');
        }
    },

    /**
     * @description Update the status of this widget.
     * @function setCheckStatus
     * @memberof CityItem
     * @param {Boolean} isChecked - the status
     * @return None
     */
    setCheckStatus : function(isChecked) {
        this.isChecked = isChecked;
		Volt.log("setCheckStatus:"+isChecked);
        if (this.isChecked === true) {
            this.visualizeInformationIcon(true,'icon2');
        } else {
            this.visualizeInformationIcon(false,'icon2');
        }
    },

    /**
     * @description Get the status of this widget.
     * @function getCheckStatus
     * @memberof CityItem
     * @return {Boolean} the status
     */
    getCheckStatus : function() {
        return this.isChecked;
    }

});

/*
 * This function will render a province list.
 * <p>
 * @param {GridListControl} provinceList The list which need render.
 * @param {Number} size The size of provinces
 */
function __initProvinceList(provinceList, size) {
    Volt.log('provinces.length - ' + size);
	
    if(size > 1) {
        var widgetExListener = new WidgetExListener;
        widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
            Volt.log("flagHighContrast is " + flagHighContrast);
            if(flagHighContrast){
                provinceList.setTabTextColor("unselected", 255, 255, 255, 255);
                provinceList.setTabTextColor("selected", 251, 186, 45, 255);
                provinceList.setTabTextColor("highlighted", 255, 255, 255,255);
            }else{
                provinceList.setTabTextColor("unselected", 255, 255, 255, 255 * 0.8);
                provinceList.setTabTextColor("selected", 251, 186, 45, 255 * 0.8);
                provinceList.setTabTextColor("highlighted", 255, 255, 255, 255 *0.8);
            }
        };
        
        widgetExListener.onEnlargeChanged = function (widgetEx, flagEnlarge) {
            Volt.log("flagEnlarge is " + flagEnlarge);
            if(flagEnlarge){
                provinceList.setTabFontSize("unselected", 35*1.2);
                provinceList.setTabFontSize("selected", 38*1.2);
                provinceList.setTabFontSize("highlighted", 38*1.2);
            }else{
                provinceList.setTabFontSize("unselected", 35);
                provinceList.setTabFontSize("selected", 38);
                provinceList.setTabFontSize("highlighted", 38);
            }
        };

        provinceList.addWidgetExListener(widgetExListener);
        
        provinceList.onKeyEvent = function (keycode, keytype) {
            var ret = false;
            if(keytype == Volt.EVENT_KEY_PRESS){
                switch(keycode) {
                    case Volt.KEY_JOYSTICK_LEFT:
                    case Volt.KEY_JOYSTICK_RIGHT:
                        ret = true;
                        break;
                    case Volt.KEY_JOYSTICK_DOWN:
                        ret = false;
                        break;
                    default:
                        // to do
                        break;
                }
                return ret;
            }
        }
        
        //HighContrast handler
        if(!DeviceModel.getHighContrast()){
            provinceList.setTabTextColor("unselected", 255, 255, 255, 255 * 0.8);
            provinceList.setTabTextColor("selected", 251, 186, 45, 255 * 0.8);
            provinceList.setTabTextColor("highlighted", 255, 255, 255, 255 *0.8);
        }else{
            provinceList.setTabTextColor("unselected", 255, 255, 255, 255);
            provinceList.setTabTextColor("selected", 251, 186, 45, 255);
            provinceList.setTabTextColor("highlighted", 255, 255, 255, 255);
        }
        
        //Enlarge handler
        if(!DeviceModel.getEnlarge()){
            provinceList.setTabFontSize("unselected", 35);
            provinceList.setTabFontSize("selected", 38);
            provinceList.setTabFontSize("highlighted", 38);
        }else{
            provinceList.setTabFontSize("unselected", 35*1.2);
            provinceList.setTabFontSize("selected", 38*1.2);
            provinceList.setTabFontSize("highlighted", 38*1.2);
        }
        Volt.Nav.setNextItemRule(provinceList,"left",provinceList);
        Volt.Nav.setNextItemRule(provinceList,"right",provinceList);
        provinceList.setTextAnimationDuration(0,0);
        var tabListener = new CategoryTabListener;
        tabListener.onTabChanged = function (ctab, index) {
            Volt.log('[menuListView.js] onTabChanged: index is ' + index);
            //provinceList.onSelected(ctab,index);
            provinceList.index = index;
            if (1 == DeviceModel.getMenuTTS()){
                var voiceText = selfProvinceList.ProvinceData[index].provinceName;
                if (true == selfSetting.isFresh){
                    selfSetting.isFresh = false;
                    voiceText = 'Weather Settings, Select the cities you would like to follow. You can select up to 5 cities. '
                                + WeatherSettingModel.getSelectedCount()
                                + ' cities are currently selected. ' + 
                                voiceText;
                }
                Global.voiceGuide(voiceText);
            }
            Mediator.trigger(CommonDefines.Event.REFRESH_CITY, index, 1);
        };
        provinceList.addCategoryTabListener(tabListener);
        
    } else {
        provinceList.custom.focusable = false;
        Mediator.trigger(CommonDefines.Event.REFRESH_CITY, 0, 2);
    }
}

function __updateProvinceList(provinceList, provinces){
    Volt.log();
    var size = provinces.length;
	selfProvinceList.ProvinceData =[];
	selfProvinceList.ProvinceData.length =0;
    var i = 0;
    var n = provinceList.numberOfTab();
    for (i = n - 1; i >= 0; i--) {
        Volt.log('[category.js] i  ' + i);
        provinceList.removeTab(i);
    }
    
    _.each(provinces , function(provinceName, i){
        var data = new Data();
        data.index = i;
        data.provinceName = provinceName;
        if(i == 0) {
            data.isSelected = true;
			//selfProvinceList.ProvinceData[i] = {isSelected:true};
        } else {
            data.isSelected = false;			
			//selfProvinceList.ProvinceData[i] = {isSelected:false};
        }
        if(i == size - 1){
            data.isShownDivision = false;
        } else {
            data.isShownDivision = true;
        }

		selfProvinceList.ProvinceData.push(data);
		Volt.log("provinceName:"+selfProvinceList.ProvinceData[i].provinceName);
        provinceList.addTab(selfProvinceList.ProvinceData[i].provinceName, 285, -1);
    });
    provinceList.total = provinceList.numberOfTab();
    provinceList.changeTab(0);
};

/*
 * This function will render a province list.
 * <p>
 * @param {GridListControl} cityList The list which need render.
 * @param {Number} size The size of cities
 */
function __initCityList(cityList, size) {
    Volt.log('cities.length - ' + size);
    
    if(size > 0) {
        cityList.addGroup(1);
        cityList.addStyle(1);
        cityList.addDataGroup(1);
        cityList.setAnimationDuration(CommonDefines.AniTime.WEATHER_SETTING_MOVE_TIME);
        var row = 4;
        var col = Math.ceil(size/row);

        cityList.addRegularGrid({
            groupIndex : 0,
            styleIndex : 0,
            columnNumber : col,
            rowNumber : row,
            columnWidth : WeatherSettingTemplate.cityItem.width,
            rowHeight : WeatherSettingTemplate.cityItem.height
        });
        
        cityList.setBackgroundColor(0,0,0,0);
        cityList.shadowEffectFlag = false;
        cityList.autoHighContrast = false;
        cityList.show();
        if(!Volt.is720p){
            Volt.log('1080 focus grind');
            cityList.setFocusImage(ResourceMgr.FocusGrid, -5*Volt.width/1920, -5*Volt.height/1080);
        } else {
            Volt.log('720 focus grind');
            cityList.setFocusImage(ResourceMgr.FocusGrid, 0, 0);
        }
        //cityList.setFocusImage(ResourceMgr.FocusGrid, -5*Volt.width/1920, -5*Volt.height/1080);
        cityList.initRenderer = function(renderer,data, parentWidth, parentHeight){
            Volt.log('data - ' + JSON.stringify(data));
            renderer.root.color = Volt.hexToRgb('#ffff00', 0);
            new CityItem().render(renderer.root, data.cityName, data.isChecked, data.isShownDivision);
			renderer.thumbnail = renderer.root.getChild(0);
        };

        cityList.onDrawLoadData = function(renderer, data, parentWidth, parentHeight) {
            Volt.log('data - ' + JSON.stringify(data));
        };

		cityList.getUserData = function(groupIndex, itemIndex) {
            Volt.log('itemIndex:'+itemIndex);
			return selfCityList.CityData[itemIndex];			
        };
        
        cityList.onDrawUpdateData = function(widget, data, parentWidth, parentHeight) {
            Volt.log();
        };
        
        cityList.onDrawFromFocusChangeStart = function(widget, data, parentWidth, parentHeight){
            Volt.log();
        };
        
        cityList.onDrawToFocusChangeEnd = function(widget, data, parentWidth, parentHeight){
            Volt.log();
        };
        
        cityList.onFocusChanged = function(fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
            Volt.log('fromItemIndex'+fromItemIndex+'toItemIndex'+toItemIndex);
            if(fromItemIndex != -1){
                var oldItem = cityList.renderer(fromGroupIndex, fromItemIndex);
                if(oldItem && oldItem.thumbnail) {
                    oldItem.thumbnail.onBlur();
                }
            }
            if(toItemIndex != -1){
                var newItem = cityList.renderer(toGroupIndex, toItemIndex);
                if(newItem && newItem.thumbnail) {
                    newItem.thumbnail.onFocus();
                }
            }
        };
        
        cityList.onItemMouseClick = cityList.onItemPress = function(groupIndex, itemIndex) {
            Volt.log('index: ' + itemIndex);
            
            
           // var checkboxWgt = cityList.renderer(groupIndex, itemIndex).root.getChild(0);
           var checkboxWgt = cityList.renderer(groupIndex, itemIndex).thumbnail;
            var checkStatus = checkboxWgt.getCheckStatus();
            if (checkStatus) {
                if (WeatherSettingModel.getSelectedCount() <= 1) {
                    var ErrorHandler = Volt.require('app/common/errorHandler.js');
                    ErrorHandler.show(CommonDefines.PopupType.MINIMUM);
                    return;
                }
            } else {
                if (WeatherSettingModel.getSelectedCount() >= 5) {
                    var ErrorHandler = Volt.require('app/common/errorHandler.js');
                    ErrorHandler.show(CommonDefines.PopupType.MAXIMUM);
                    return;
                }
            }
            Mediator.trigger(CommonDefines.Event.UPDATE_SELECTED_CITIES_1, itemIndex);
            checkboxWgt.setCheckStatus(!checkStatus);
            //voice guide
            if (1 == DeviceModel.getMenuTTS()){
                var voiceText = (true == checkStatus) ? 'unchecked' : 'checked';
                Global.voiceGuide(voiceText);
            }
           // cityList.getData(groupIndex, itemIndex).isChecked = !checkStatus;
           cityList.getUserData(groupIndex, itemIndex).isChecked = !checkStatus;
		   
        };
        
        Volt.Nav.setNextItemRule(cityList,"left",cityList);
        Volt.Nav.setNextItemRule(cityList,"right",cityList);
    } else {
        cityList.custom.focusable = false;
    }
    
    var gridListener = new GridListControlListener;
    gridListener.onFocusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
        if (toItemIndex <  0) {
            return;
        }
        if (1 == DeviceModel.getMenuTTS()){
            //var data = gridList.getData(toGroupIndex, toItemIndex);
            var data = gridList.getUserData(toGroupIndex, toItemIndex);
            var checked = data.isChecked ? 'checked' : 'unchecked';
            var voiceText = 'checkbox, ' + checked + ', ' +data.cityName;
            if (-1 == fromItemIndex){
                var cityCount = cityList.itemCount(0);
                var item = (1 == cityCount) ? 'item' : 'items';
                voiceText = gridList.provinceName + ', ' + cityCount + ', ' + item + ', ' + voiceText;
            }
            Global.voiceGuide(voiceText);
        }
    };
    cityList.addListListener(gridListener);
    Volt.Nav.setNextItemRule(selfSetting.widget.getDescendant('provinceList'),"down",cityList);
    Volt.Nav.setNextItemRule(cityList,"up",selfSetting.widget.getDescendant('provinceList'));
    Volt.Nav.setNextItemRule(selfSetting.widget.getDescendant('newson-weather-setting-save-button'),"up",cityList);
    Volt.Nav.setNextItemRule(selfSetting.widget.getDescendant('newson-weather-setting-cancel-button'),"up",cityList);
}

function __updateCityList(cityList, cityCollection){
    Volt.log();
    Volt.log('__updateCityList---------------cityCollection.length='+cityCollection.length);
	
	var itemNum = cityList.itemCount(0);
	Volt.log("itemNum="+itemNum);
	
	if(itemNum > 0){
    	cityList.clearDataSource(0);
	}
	
    cityList.addDataGroup(1);
	selfCityList.CityData = [];
	selfCityList.length = 0;
	
    cityCollection.each(function(city, i){	
        var data = new Data();
        data.index = i;
        data.cityName = city.get('name');
		Volt.log("data.cityName="+data.cityName);
        data.isChecked = WeatherSettingModel.getSelectedCityIndex(city.get('code')) !== undefined;
		selfCityList.CityData.push(data);
        cityList.addData({groupIndex:0, data:data});
    });
    cityList.loadData();
    cityList.setFocusItemIndex(0, 0);
};

exports = WeatherSettingView;
