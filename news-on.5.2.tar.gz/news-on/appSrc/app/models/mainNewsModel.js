

var PageModel = Volt.require('app/models/pageModel.js');
var BaseModel = Volt.require('app/models/baseModel.js');
var CPAPI = Volt.require('app/common/CPAPI.js');
var localStorage = Volt.require("lib/volt-local-storage.js");
var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;

/**
 * @description MainNewsModel 
 * @class MainNewsModel
 * @property {Function} initialize - initialize the Model.
 * @property {Function} parse - parse data.
 * @requires {@link Backbone}
 * @requires {@link PanelCommon}
 */
var MainNewsModel = BaseModel.extend({

	defaults: {
		attributes: {
			status: 0,
			error_msg: ''
		},
		more_news_url: '',
		now_utc_timestamp: '',
		pageModel: null,
		tos_text: '',	
		//////flag
		ready:0,
	},
    weather_solo : false,

   /**
     * @description initialize the model.
     * @function initialize
     * @memberof MainNewsModel
     * @param {Object} options - options
     * @return None
     */
	initialize: function(options) {
		//this.yahooAPI = 'GetYTodayContent';			
        //this.url = 'https://api.digitalhomeservices.yahoo.com/V0_3/'+ this.yahooAPI +'?' + serverInfo.getQueryString();
		//this.url = 'https://api.digitalhomeservices.yahoo.com/V0_3/'+ this.yahooAPI +'?appid=com.samsung.panels.tv.ytoday&contextid=samsung.main.2014&man=SEC&model=14_X14_BT&deviceid=SHCJYGR247DHC&swversion=T-MST14DEUC-0721.0&region=BR&language=pt&res=1920x1080&ts=1398135176&format=json';
		//this.set('pageModel', new PageModel());			
		this.set('pageModel', new PageModel()); 
	},
    offline: function(){
        var deferred = Q.defer();
        var caching = localStorage.getItem('mainnews');
        if (caching && caching.length > 0) {
            data = caching;
            this.parse(data,'offline');
            deferred.resolve();
        }
        else {
            deferred.reject();
        }
        return deferred.promise;
    },
	setInitData: function(url, weather_solo) {
		//this.yahooAPI = 'GetYTodayContent';     
		//this.url = serverInfo.getDomain() + this.yahooAPI +'?' + serverInfo.getQueryString();
        this.url = url;//CPAPI.getMainNewsAPI();
        if(weather_solo !== undefined)
            this.weather_solo = weather_solo;
        else
            this.weather_solo = false;
		//this.url = CPAPI.getMainWeatherAPI();
    },

	/**
     * @description parse the data.
     * @function parse
     * @memberof MainNewsModel
     * @param {Object} data - server data
      * @param {Object} staus - data staus
      * @param {Object} response - response url
     * @return None
     */	
	parse: function(data,staus,response)
	{
		if(response !== undefined)
            Volt.log('response.uri' + response.uri);	
		if(response !== undefined && String(response.uri).indexOf(this.url) == -1)
			return;
        /*
        if(staus !== 'offline')
            localStorage.setItem('mainnews', data);*/
		data = JSON.parse(data);
		var iPageModel = this.get('pageModel');
		this.set('attributes', data.attributes);
		this.set('now_utc_timestamp', data.now_utc_timestamp);
		this.set('more_news_url', data.more_news_url);
		this.set('tos_text', data.tos_text);
        var flag = false; // for whether reset the whole pagemodel
        
        if(CPAPI.getServiceType() == 'sina_huafeng' && String(response.uri).indexOf(CPAPI.getMainWeatherAPI({cid:null})) !== -1 && !this.weather_solo)
            flag = true;
        else if(CPAPI.getServiceType() !== 'sina_huafeng')
            flag = true;
		iPageModel.set(iPageModel.parse(data, flag));
	},


})

exports = new MainNewsModel();
