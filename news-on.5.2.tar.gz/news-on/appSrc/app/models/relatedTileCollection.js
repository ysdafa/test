var Backbone = Volt.require('lib/volt-backbone.js');
var RelatedTileModel = Volt.require("app/models/relatedTileModel.js");
var RelatedTileCollection = Backbone.Collection.extend({
	model: RelatedTileModel,
    clear : function(){
        this.reset([]);
    }
});
exports = RelatedTileCollection;