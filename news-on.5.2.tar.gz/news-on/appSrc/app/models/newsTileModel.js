
var Backbone = Volt.require('lib/volt-backbone.js');
    var NewsTileModel = Backbone.Model.extend({

        defaults: {
            tile_type: "news",
            position: 0,
            id: '',
            source: '',
            title: '',
            timestamp: 0,
            img_url: '',
            detail_url: '',
            image_aspect_ratio: '',
            now_utc_timestamp: '',
            stringstamp: '',
            stringstamp_standard:'',
            blank: false
        },

        parse: function(newsTileData, options) {
            var oNewsTileData = {
                tile_type: newsTileData.tile_type,
                position: newsTileData.position,
                id: newsTileData.id,
                source: newsTileData.source,
                title: newsTileData.title,
                timestamp: newsTileData.timestamp,
                img_url: newsTileData.img_url,
                detail_url: newsTileData.detail_url,
                image_aspect_ratio: newsTileData.image_aspect_ratio,
                //now_utc_timestamp: newsTileData.now_utc_timestamp,
                now_utc_timestamp: options.now_utc_timestamp,
                stringstamp:'',
                blank: (newsTileData.blank !== undefined) ? newsTileData.blank : false
            };
			
			var temp = Math.floor((parseInt(options.now_utc_timestamp) - parseInt(oNewsTileData.timestamp)));
			var status_short = '';
            var status_standard = '';
			if(temp >= 0 && temp <= 59) {
                status_short = Volt.i18n.t('COM_SID_JUST_NOW');
                status_standard = Volt.i18n.t('COM_SID_JUST_NOW');
			} else if(temp >= 60 && temp <= 119) {
                status_short = Volt.i18n.t('TV_SID_1_MIN_AGO');
                status_standard = Volt.i18n.t('TV_SID_1_MINUTES_AGO');
			} else if(temp >= 120 && temp <= 3600 - 1) {
				var minutes = Math.floor(temp/60);
                status_short = Volt.i18n.t('COM_SID_MIX_MINS_AGO', {A : minutes});
                status_standard = Volt.i18n.t('SID_MIX_MINUTES_AGO_KR_BLANK', {A : minutes});
			} else if(temp >= 3600 && temp <= 7200 - 1) {
                status_short = Volt.i18n.t('COM_SID_1_HR_AGO');
                status_standard = Volt.i18n.t('TV_SID_1_HOUR_AGO');
			} else if(temp >= 3600 && temp <= 3600*24 - 1) {
				var hours = Math.floor(temp/3600);
                status_short = Volt.i18n.t('COM_SID_MIX_HRS_AGO', {A : hours});
                status_standard = Volt.i18n.t('SID_MIX_HOURS_AGO', {A : hours});
			} else if(temp >= 3600*24 && temp <= 3600*48 - 1) {
                status_short = Volt.i18n.t('COM_SID_1D_AGO');
                status_standard = Volt.i18n.t('TV_SID_1_DAY_AGO');
			} else {
				var days = Math.floor(temp/(3600*24));
                status_short = Volt.i18n.t('COM_SID_MIX_D_AGO', {A : days});
                status_standard = Volt.i18n.t('TV_SID_MIX_DAYS_AGO', {A : days});
			}
			oNewsTileData.stringstamp = status_short;
            oNewsTileData.stringstamp_standard = status_standard;
            return oNewsTileData;
        }
    })
	
	exports = NewsTileModel;
	