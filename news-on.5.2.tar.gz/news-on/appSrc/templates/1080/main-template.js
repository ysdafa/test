var MainTemplate = {
    container : {
        parent : Volt.WinsetRoot,
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.width,
        height : Volt.height,
        color : Volt.hexToRgb('#f2f2f2'),
        children : [
        /*            {
                        id: 'main-title-area',
                        type: 'widget',
                        x: 0, y: 0, width: 1920, height: 144,
                        color: Volt.hexToRgb('#0f1826')
                    },
        */
        {
            id : 'main-header-container',
            type : 'WinsetBackground',
            x : 0,
            y : 0,
            width : Volt.width,
            height : Volt.height * 0.133333,//144, //1080 * 0.133333
            bgHighContrastColor:Volt.hexToRgb('#000000'),
            bgColor:Volt.hexToRgb('#0f1826'),
			children : [{
				type : 'text',
				x : Volt.width * 0.018750,//36, // 1920 * 0.018750
				y : 0,
				height : Volt.height * 0.133333,//144, //1080 * 0.133333
				verticalAlignment : 'center',
				textColor : Volt.hexToRgb('#ffffff',80),
				opacity : 255,
				text : '{{title}}',
				font : '50px',
				custom : {
                    multilingual : {
                        SID : 'TV_SID_NEWS_ON'
                    },
                }
			}]
        }, {
            id : 'main-category-container',
            type : 'WinsetBackground',
            x : 0,
            y : Volt.height * 0.133333,//144, //1080 * 0.133333
            width : Volt.width,
            height : Volt.height * 0.066667,//72, // 1080 * 0.066667
            bgHighContrastColor:Volt.hexToRgb('#000000'),
            bgColor:Volt.hexToRgb('#0f1826'),
        }, {
            id : 'main-content-container',
            type : 'widget',
            x : 0,
            y : Volt.height * 0.133333 + Volt.height * 0.066667,//216, //1080 * 0.133333 + 1080 * 0.066667
            width : Volt.width,
            height : Volt.height * 0.8,//864, //1080 * 0.8
            color : Volt.hexToRgb('#dfdfdf')
        }, {
            id : 'main-dim-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : Volt.width,
            height : Volt.height,
            color : Volt.hexToRgb('#000000', 0)
        }, {
            id : 'main-popup-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : Volt.width,
            height : Volt.height,
            color : Volt.hexToRgb('#000000', 0)
        }, {
            id : 'main-popup2-container',
            type : 'widget',
            x : 0,
            y : 0,
            width : Volt.width,
            height : Volt.height,
            color : Volt.hexToRgb('#000000', 0)
        }]
    },
};

exports = MainTemplate;
