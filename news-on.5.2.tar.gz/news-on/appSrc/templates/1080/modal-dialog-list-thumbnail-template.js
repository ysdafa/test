var ModalDialogListThumbnailTemplate = {
    container : {
		parent:Volt.WinsetRoot,
        type: 'widget',
        x: 20, y: 200, width: 1880, height : 680,
        color : Volt.hexToRgb('#000000',200),
        border : {width : 10, color : {r:0,g:0,b:255,a:255}},
        children : [
            {
                type : 'widget',
                id : 'list-thumbnail-title-container',
                x : 0, y : 0, width : 1880, height : 100,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : 0, y : 200, width : 1880, height : 330,
                id : 'list-thumbnail-content-container',
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : 0, y : 530, width : 1880 , height : 150,
                id : 'list-thumbnail-button-container',
                color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    },
}

exports = ModalDialogListThumbnailTemplate;


