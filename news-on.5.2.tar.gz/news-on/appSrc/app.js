(function() {
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };

    var resolutionHeight = 1080;
    Volt.requireTemplate = function(templateName){
        return Volt.require('templates/' + resolutionHeight+'/' + templateName + '-template.js');
    };
    Volt.requireAppTemplate = function(fileName){
        return Volt.require('app/templates/' + resolutionHeight+'/' + fileName);
    };
})();

var Backbone, PanelCommon, CommonDefines, GlobalMediator = null,Global,DeviceModel,CPAPI = null,ModelController,LoadingDialog, menuController = null;
//for search city weather
Volt.width = (scene.width == 1280) ? 1920:scene.width;
Volt.height = 1080;
Volt.sourceControlWidth = 1920;
Volt.require('distribution.min.js');	
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

Volt.require('lib/volt-common.js'); // Common Functions
Volt.require('lib/volt-debug.js'); // For Debug
Volt.require('lib/volt-nav.js'); // Focus and Key Input Management

Backbone = Volt.require('lib/volt-backbone.js');
PanelCommon = Volt.require('lib/panel-common.js');
	//Require common defines
CommonDefines = Volt.require('app/common/commonDefines.js');
Global = Volt.require('app/common/Global.js');
GlobalMediator = Volt.require('app/common/GlobalMediator.js');
DeviceModel = Volt.require('app/common/deviceModel.js');
menuController = Volt.require('app/common/menu-controller.js');


//multilingual
Volt.i18n = Volt.require('lib/volt-multilingual.js');

var WinsetBackground = Volt.require('WinsetUIElement/winsetBackground.js');
//var WinsetBackground = Volt.require('$VOLT_ROOT/modules/WinsetUIElement/winsetBackground.js');
PanelCommon.mapWidget('WinsetBackground', WinsetBackground);
Volt.WinsetRoot = new WinsetBackground({
    x:0,
    y:0,
    height:Volt.height,
    width:Volt.width,
    bgHighContrastColor:Volt.hexToRgb('#000000'),
    bgColor:Volt.hexToRgb('#0f1826'),
    parent:scene});

var isMagicKeyOn = true;
var IsDeepLink = false;
var DeepLinkCityID = "";
var splashList = [];

Volt.isDeactive = false;
    
var initialize = function() {
        //startApp();
        if (!IsDeepLink){
            fetchData();
        }
        setupEnv();
        showTitle();
        //addMagicKeyListener();
		//destroySplashImage();
    //}, 100);
};

function loadModules() {
	Volt.require('app/router.js');
	//KPI start
	Volt.KPIMapper = Volt.require('app/common/kpi-mapper.js');	//KPI end

};

function setupEnv() {
    
    Volt.i18n.init({
        lng : DeviceModel.getLanguageCode(),
        resGetPath: 'lang/<<lng>>.json',
        getAsync: false,
        interpolationPrefix: '<<',
        interpolationSuffix: '>>'
    }, function(t){
        Global.DateMultiLang.init();
    });


	checkReset(); //use this api need the image after 2014 11.11

    //HALOUtil.applyOrientation();

    //HALOUtil.enlarge = true;
};


function showTitle() {
	
	if('object' == typeof Stage){
		Volt.log('Stage.show');
		Stage.show();
	}

    //LoadingDialog = Volt.require('app/views/loading-view.js');	

	Volt.log('scene width: ' + scene.width);
	Volt.log('scene height: ' + scene.height);
	Volt.is720p = false;
	if(scene.width == 1280){
		Volt.is720p = true;
	}
	

	/*var width = DeviceModel.getScreenWidth();
	Volt.log('Screen width: ' + width);
	if(width == 1280){
		Volt.log('enable720P');
	 	HALOUtil.enable720P = true;
	}*/
    if (!IsDeepLink){
    	var MainTemplate = Volt.requireTemplate('main');
    	Volt.mainViewWidget = PanelCommon.loadTemplate(MainTemplate.container, {'title':Volt.i18n.t('TV_SID_NEWS_ON')}, null, false);
    	//Volt.mainViewWidget = PanelCommon.loadTemplate(MainTemplate.container, {'title':'NewsON'}, null, false);
    	Volt.mainViewWidget.show();	
	//LoadingDialog.show(1);
	//DeviceModel.setWaitingScreenAppVisibleConf(true);

	/*Volt.setTimeout(function(){  
		//DeviceModel.setWaitingScreenAppVisibleConf(true);
		loadModules();
        startApp();		
		addMagicKeyListener();
    }, 150);*/
    	Volt.post(function(){  
    		//DeviceModel.setWaitingScreenAppVisibleConf(true);
    		loadModules();
            //setupEnv();
            startApp();		
    		addMagicKeyListener();
        });
    }else {
        loadModules();
        startApp();
        
    }
};

function fetchData(){
    //LoadingDialog.show(1);
    Volt.log('begin to fetch data');
    CPAPI = Volt.require('app/common/CPAPI.js');
    ModelController = Volt.require('app/controller/model-controller.js');
    Global.RequestMgr.reset();
    CPAPI.initialize().then(function(result){
        if (result){
            ModelController.ready().then(function(){
                LoadingDialog.hide();
                Volt.KPIMapper.init();
            });
        } else {
            GlobalMediator.trigger(CommonDefines.Event.MAINVIEW_DATA_FAILED);
            Volt.KPIMapper.init();
        }
    }).fail(function(){
        Volt.log('requst is cancelled!');
        Volt.KPIMapper.init();
    });
}

function startApp() {
    LoadingDialog = Volt.require('app/views/loading-view.js');
    
    //DeviceModel.listenNetworkStatus();

	var orientation = HALOUtil.getOrientation();
	Volt.log('orientation is :'+orientation);
	if("left-to-right" == orientation) {
		Volt.log('not ReverseOsd');
		Volt.isReverseOsd = false;
	} else {
		Volt.log('ReverseOsd now');
		Volt.isReverseOsd = true;
	}
	
    Global.APP_STATUS = Global.APP_ACTIVE;
    Backbone.history.start({minCount: 0});
    
    if (!IsDeepLink){
		//DeviceModel.setWaitingScreenAppVisibleConf(true);
        Volt.post(function(){
            Backbone.history.navigate('home', {
                trigger : true
            });
        });

        if (DeviceModel.isDeviceInfoReady()){
            if (0 == DeviceModel.getNetWorkState()){
				Volt.log('LoadingDialog.show');
			    LoadingDialog.show(1);
            } else {
                Global.RequestMgr.clear();
            }
            //Volt.KPIMapper.init();
        } else {
            GlobalMediator.on(CommonDefines.Event.ON_DEVICEINFO_READY, function(){
                if (0 == DeviceModel.getNetWorkState()){
					Volt.log('LoadingDialog.show');
				    LoadingDialog.show(1);
                } else {
                    Global.RequestMgr.clear();
                }
                
                //Volt.KPIMapper.init();
            });
        }
        GlobalMediator.on(CommonDefines.Event.NETWORK_GOOD, function(){
            Volt.log('we need to descide whether cancel network request');
            if(DeviceModel.firstTimeNetworkFailed){   //need cancel request
                Volt.log('network clear in device model');
                Global.RequestMgr.clear();
                DeviceModel.firstTimeNetworkFailed = false;
                if(DeviceModel.firstTimeNetworkTimeout){
                    Volt.log('clear firstTimeNetworkTimeout');
                    Volt.clearTimeout(DeviceModel.firstTimeNetworkTimeout);
                    DeviceModel.firstTimeNetworkTimeout = null;
                }
            }
                //Volt.KPIMapper.init();
        });
        //NETWORK_BAD_TO_GOOD
        GlobalMediator.on(CommonDefines.Event.NETWORK_BAD_TO_GOOD, function(){
            Volt.log('get NETWORK_BAD_TO_GOOD');
            if(Global && !Global.NETWORK_CONFIG_LAUNCH){
                Volt.log('set NETWORK_CONFIG_LAUNCH');
                Global.NETWORK_CONFIG_LAUNCH = true;
            }
        });
        
        GlobalMediator.on(CommonDefines.Event.NETWORK_GOOD_TO_BAD, function(){
            Volt.log('get NETWORK_GOOD_TO_BAD');
            if(Global && Global.NETWORK_CONFIG_LAUNCH){
                Volt.log('set NETWORK_CONFIG_LAUNCH');
                Global.NETWORK_CONFIG_LAUNCH = false;
            }
        });
    } else {
        Volt.log('go to weather detailview from search');
        LoadingDialog.show(1);
        //dummy China
        DeviceModel.set('countryCode', 'CN');
        CPAPI = Volt.require('app/common/CPAPI.js');
        CPAPI.initialize().then(function(){
            Backbone.history.navigate('weather/0', {
                trigger : true,
    			weatherTile : [],
    			isDeepLink : true,
    			cid : DeepLinkCityID
            });
            Volt.KPIMapper.init();
        });
    }
};


function checkReset () {
    Volt.log("[app.js] checkReset()");
    //use this api need the image after 2014 11.11
    if (SmartHubReset && SmartHubReset.needReset) {
        if (SmartHubReset.needReset()) {
			
			Volt.log("[app.js] clear cache()");
            var localStorage = Volt.require("lib/volt-local-storage.js");
            localStorage.clear();
            SmartHubReset.resetComplete();
        } else {
            Volt.log("[app.js] not need reset");
        }
    }
};

function addMagicKeyListener(){
    Global.MagicKey.addListener(CommonDefines.Magic.SHOW_SUBMIT_VERSION, function(){
        Volt.log('magic: show submit version');
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        ErrorHandler.show(CommonDefines.PopupType.VERSION,null,null);
    });

    Global.MagicKey.addListener(CommonDefines.Magic.SHOW_APP_VERSION, function(){
        Volt.log('magic: show app version');
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        ErrorHandler.show(CommonDefines.PopupType.APP_VERSION,null,null);
    });
    
    Global.MagicKey.addListener(CommonDefines.Magic.SHOW_CONFIG_VERSION, function(){
        Volt.log('magic: show config version');
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        ErrorHandler.show(CommonDefines.PopupType.CONFIG_VERSION,null,null);
    });

    Global.MagicKey.addListener(CommonDefines.Magic.SHOW_DEVICE_INFO.ALL, function(){
        Volt.log('magic: show device info');
        var ErrorHandler = Volt.require('app/common/errorHandler.js');
        ErrorHandler.show(CommonDefines.PopupType.DEVICE_INFO,null,null);
    });

    /*Global.MagicKey.addListener(CommonDefines.Magic.CHINA_BRAZIL_SWITCH, function(){
        var RouterController = Volt.require('app/controller/router-controller.js');
        if (RouterController.getCurrentView().name && 'main-view' == RouterController.getCurrentView().name){
            if(DeviceModel.get('countryCode') == 'BR'){
                DeviceModel.set('countryCode', 'CN');
            } else {
                DeviceModel.set('countryCode', 'BR');
            }
        }
    });*/

    Global.MagicKey.addListener(CommonDefines.Magic.NETWORK_CONNECTED_SWITCH, function(){
        if (0 == DeviceModel.get('networkState')){
            Volt.log('Debug: set network disconnected');
    	    DeviceModel.set('networkState', -1);
    	}
    	else {
            Volt.log('Debug: set network connected');
    	    DeviceModel.set('networkState', 0);
    	}
    });

    /*Global.MagicKey.addListener(CommonDefines.magic.SHOW_TIMESTAMP, function(){
        Volt.GlobalMediator.trigger('EVENT_HOME_TIMESTAMP');
    });

    Global.MagicKey.addListener(CommonDefines.magic.MENU_LANG_TEST, function(){
        Volt.onLanguageChanged('en');
    });*/
}

/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keyCode, keyType) {
	Volt.log('keyCode : ' + keyCode);

	if(GlobalMediator === null) {
		Volt.log('GlobalMediator is null!');

		return;
	}


	
    /*if (keyCode == Volt.KEY_3 && keyType == Volt.EVENT_KEY_PRESS){		
		    Global.MEMORY_TEST_STATUS = Global.MEMORY_TEST_ON;
			return;
    }
    if (keyCode == Volt.KEY_4 && keyType == Volt.EVENT_KEY_PRESS){		
		    Global.MEMORY_TEST_STATUS = Global.MEMORY_TEST_OFF;
			return;
    }
    
    if (keyCode == Volt.KEY_5 && keyType == Volt.EVENT_KEY_PRESS) {
        gc();
        VDUtil.heapSnapshot();
    }*/
    if(isMagicKeyOn && keyType == Volt.EVENT_KEY_PRESS){
	   Global.MagicKey.onKeyPress(keyCode);
    }
	
	if(LoadingDialog == undefined) {
		Volt.log('LoadingDialog is not ready!');
		return;
	}
	
    if(LoadingDialog.isLoading)
    {
        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {
			if (Backbone.history.location.history.length > 1) {
                print("Return loading");
                Backbone.history.back();
            } else {
				Volt.log('newson exit loading');
                //DeviceModel.destroyVoltApi();
                Volt.exit(); 
            }
        }
        return;
    }
    
    if (Volt.Nav.onKeyEvent(keyCode, keyType) === false) {
        // use key_1 and key_0 to simulate network status
    	/*if (keyCode == Volt.KEY_1 && keyType == Volt.EVENT_KEY_RELEASE){		
    	    DeviceModel.set('networkState', -1);
    		return;
    	}
    	else if(keyCode == Volt.KEY_0 && keyType == Volt.EVENT_KEY_RELEASE) {
    	    DeviceModel.set('networkState', 0);
    		return;		
    	}else *//*if(keyCode == Volt.KEY_7 && keyType == Volt.EVENT_KEY_RELEASE) {
    	    if (true == isMagicKeyOn){
                Volt.log('turn magic key off');
	            isMagicKeyOn = false;
            }else{
                Volt.log('turn magic key on');
	            isMagicKeyOn = true;
            }
            return;     
        }*/
    	/*else if(keyCode == Volt.KEY_8 && keyType == Volt.EVENT_KEY_RELEASE){
            var RouterController = Volt.require('app/controller/router-controller.js');
            if (RouterController.getCurrentView().name && 'main-view' == RouterController.getCurrentView().name){
                if(DeviceModel.get('countryCode') == 'BR'){
                    DeviceModel.set('countryCode', 'CN');
                } else {
                    DeviceModel.set('countryCode', 'BR');
                }
            }
    	    return;
    	}*/
        /*else if(keyCode == Volt.KEY_9 && keyType == Volt.EVENT_KEY_RELEASE) {
	        var ErrorHandler = Volt.require('app/common/errorHandler.js');
            ErrorHandler.show(CommonDefines.PopupType.VERSION,null,null);
            return;     
        }*/
        if (keyCode == Volt.KEY_RETURN && keyType == Volt.EVENT_KEY_PRESS) {
            Global.LeaveWayForKPILog.set('RETURN');
			if (Backbone.history.location.history.length > 1) {
                print("Return");
                Backbone.history.back();
            } else {
                Volt.log('newson exit');
                //kpi log start
                Global.LeaveByReturnForKPILog.set(true);
                Global.ExitWayForKPILog.set('RETURN');
                //kpi log end
				Volt.exit();
                /*if (mainViewShown){
                    Volt.exit();
                }else{
                    Volt.quit();
                }*/
            }
        }
    }
};

Volt.addEventListener(Volt.ON_SHOW, function(data){
	print('ON_SHOW');
		//

	//DeviceModel.setWaitingScreenAppVisibleConf(true);
	if('object' == typeof Stage){
		Volt.log('Stage.show');
		Stage.show();
	}
        if(GlobalMediator !== null) {
		GlobalMediator.trigger(CommonDefines.Event.APP_ON_SHOW);
	}

    //Volt.log("receive event ON_SHOW:"+JSON.stringify(data));
    if(data == undefined || data == null){
        Volt.log('received data is null or undefined');
        return;
    }
    
	if(data["Sub_Menu"] == "detail"){
        if (data.hasOwnProperty('cid')){
            Volt.log('received city id, prepare to show city weather');
    		IsDeepLink = true;
    		DeepLinkCityID = data["cid"];
        }
        //dummy
        //IsDeepLink = true;
        //DeepLinkCityID = '01010101';
	}


	if(menuController !== null) {
		menuController.disableMenu();
	}
});

Volt.addEventListener(Volt.ON_PAUSE, function(){
	Volt.log('Event Volt.ON_PAUSE is received');

	if(GlobalMediator !== null) {
		GlobalMediator.trigger(CommonDefines.Event.APP_ON_PAUSE);
	}

	if(menuController !== null) {
		menuController.enableMenu();
	}
});

Volt.addEventListener(Volt.ON_RESUME, function(){
	Volt.log('Event Volt.ON_RESUME is received');
	//Stage.show();


	if(GlobalMediator !== null) {
		GlobalMediator.trigger(CommonDefines.Event.APP_ON_RESUME);
	}

	if(menuController !== null) {
		menuController.disableMenu();
	}
});

Volt.addEventListener(Volt.ON_DEACTIVATE, function(){
	Volt.log('Event Volt.ON_DEACTIVATE is received');

	if(GlobalMediator !== null) {
		GlobalMediator.trigger(CommonDefines.Event.APP_ON_DEACTIVATE);

		if (typeof gc == 'function') {
            Volt.setTimeout(function () {
                Volt.log('[app.js @ON_DEACTIVATE gc()');
                gc();
            }, 800);
        }
	}
});

Volt.addEventListener(Volt.ON_ACTIVATE, function(){
	Volt.log('Event Volt.ON_ACTIVATE is received');
	//Stage.show();

	var dMode = VDUtil.get3dMode(); // <- getting 3d status
    if (dMode != 0)
    {
    	Volt.log('set 3dMode to 0');
        VDUtil.set3dMode(0); //3D effect off <- setting 3d off
    }

	if(GlobalMediator !== null) {
		GlobalMediator.trigger(CommonDefines.Event.APP_ON_ACTIVATE);
	}
});

Volt.addEventListener(Volt.ON_UNLOAD, function(){
	Volt.log('Event Volt.ON_UNLOAD is received');

	if(menuController !== null) {
		menuController.enableMenu();
	}

	if(GlobalMediator !== null) {
		//GlobalMediator.trigger(CommonDefines.Event.APP_ON_UNLOAD);
	}
});

Volt.addEventListener(Volt.ON_HIDE, function(){
    Volt.log('Event Volt.ON_HIDE is received');

	if(GlobalMediator !== null) {
        GlobalMediator.trigger(CommonDefines.Event.APP_ON_HIDE);
    }

	if(menuController !== null) {
		menuController.enableMenu();
	}
});

Volt.addEventListener(Volt.ON_RESET, function(data){
	Volt.log('Event Volt.ON_RESET is received');
	//Volt.log("before change AppVisibleConf:"+DeviceModel.getWaitingScreenAppVisibleConf());
	DeviceModel.setWaitingScreenAppVisibleConf(true);
    //for mls start
    var voltapi = Volt.require('voltapi.js');
    var eVConfPlugin = voltapi['vconf'];
    var result = eVConfPlugin.getValue('memory/mls/state');
    Volt.log(' vconf MLS_STATE : ' + result);
	if(result == 1){
		PanelCommon = Volt.require('lib/panel-common.js');
        var dimView = PanelCommon.requireView('dim');
        dimView.hide();
		print("[app.js] don't show the dim view !");
	}
    //for mls end
	if('object' == typeof Stage){
		Stage.show();
	}
	Volt.log("after change AppVisibleConf:"+DeviceModel.getWaitingScreenAppVisibleConf());


	if(menuController !== null) {
		menuController.disableMenu();
	}
    if(data == undefined || data == null){
        Volt.log('received data is null or undefined');
        return;
    }
	if(data["Sub_Menu"] == "detail"){
        if (data.hasOwnProperty('cid')){
            Volt.log('received city id, prepare to show city weather'+data["cid"]);
    		IsDeepLink = true;
    		DeepLinkCityID = data["cid"];
            Backbone.history.navigate('weatherResult/0', {
                trigger : true,
    			weatherTile : [],
    			isDeepLink : true,
    			cid : DeepLinkCityID
            });
        }
        //dummy
        //IsDeepLink = true;
        //DeepLinkCityID = '01010101';
	}
    

});
/*
Volt.addEventListener(Volt.ON_APP_LAUNCH, function(data){
    Volt.log('ON_APP_LAUNCH'+data.pkgname);
    if('org.tizen.NetworkSetting-Tizen' == data.pkgname){
        Global.NETWORK_CONFIG_LAUNCH = true;
    }
});*/

