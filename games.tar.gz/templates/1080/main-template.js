var MainTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height: 1080,
        color: Volt.hexToRgb('#000000', 100),
        children: [
            {
                id: 'main-header-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#000000',0)
            }, {
                id: 'main-category-container',
                type: 'widget',
                x: 0, y: 144, width: 1920, height: 72,
                color: Volt.hexToRgb('#f2f2f2')
            }, {
                id: 'main-content-container',
                type: 'widget',
                x: 0, y: 216, width: 1920, height: 864,
                color: Volt.hexToRgb('#dfdfdf'),
                children : [{
                    id : 'main-no-content-text',
                    type: 'text',
                    x : scene.width * 0.16875,
                    y : 864 / 2 - 70,
                    width : scene.width * (1 - 0.16875),
                    height : 100,
                    font : "SVD Light 36px",
                    textColor : Volt.hexToRgb('#000000', 60),
                    horizontalAlignment : 'center',
                    verticalAlignment : 'center',
                    text : ""
                }]
            },
            {
                id: 'multi-selection-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                color: {r:0,g:0,b:0,a:0},
            },
            {
                id: 'main-popup-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                color: Volt.hexToRgb('#000000',0),
            }
        ]
    },
    /*@20140822 added by tiansx for categorytab begin*/
   /*
    category: {
        type: 'CategoryTabs',
        x: 0,
        y: 0,
        color: {r:242, g:242, b:242},
        separatorWidth: 2,
        separatorHeight: 2,
        separatorColor: {r:0x46, g:0x46, b:0x46},
        lockDuration: 200,
        arrowWidth: 18,
        arrowHeight: 34,
        leftArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_left_n.png'),
        rightArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_right_n.png'),
        width: 1920,
        height: 72,
        custom: {focusable: true},
    },
    /*@20140822 added by tiansx for categorytab end*/
	/*
    // @20141015 by xiaojun.wang. Update for new version of CategoryTabs
    category: {
        type: 'CategoryTabs',
        x: 0, y: 0, width: 1920, height: 72,
        color: {r: 242, g: 242, b: 242},
        
        expandHeight: 108,
        lockDuration: 200,
        
        separatorWidth: 2,
        separatorHeight: 2,
        separatorColor: {r: 0x46, g: 0x46, b: 0x46},
        arrowWidth: 18,
        arrowHeight: 34,
        leftArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_left_n.png'),
        rightArrowSrc: Volt.getRemoteUrl('images/1080/arrow/comn_sub_arrow_right_n.png'),
        
        custom: {focusable: true}
    },
	*/
	// @20141015 End of update

//	category : {
//		type : 'CategoryTab',
//		x : 0,
//		y : 0,
//		width : scene.width,
//		height : 72,
//		highligthFocusAnimation : {
//			unfocus : 5,
//			focused : 108,
//			duration : 200
//		},
//		highligthMoveAnimationDuration : 200,
//		color : {
//			r : 242,
//			g : 242,
//			b : 242,
//			a : 255
//		},
//		margin : {
//			top : 0,
//			bottom : 0,
//			left : scene.width * 0.005208,
//			right : scene.width * 0.005208
//		},
//
//		spliterSize : {
//			w : 2,
//			h : 2
//		},
//		enableLooping : true,
//		tabFont : "Sans 28px",
//		arrowSize : {
//			w : scene.width * 0.035938,
//			h : 34
//		},
//		leftArrowImage : "images/1080/arrow/comn_sub_arrow_left_n.png",
//		rightArrowImage : "images/1080/arrow/comn_sub_arrow_right_n.png",
//		highlightbarColor : {
//			r : 30,
//			g : 158,
//			b : 230,
//			a : 255
//		},
//		spliterColor : {
//			r : 70,
//			g : 70,
//			b : 70,
//			a : 255
//		},
//		enableHighlightbar : true,
//		highlightbarHeight : 5,
//		textMargin : scene.width * 0.020833,
//		textLimit : 400,
//		enableAlignTabsCenter : true,
//
//		custom : {
//			focusable : true
//		},
//	},

};

exports = MainTemplate;
