var DetailTemplate = {
    container : {
        parent: scene,
        type: 'widget',
		id : 'detail-view-bg-area',
        x: 0, y: 0, width: 1920, height : 1080,
        color : Volt.hexToRgb('#3E5896'),
        children : [

            {
                type : 'widget',
                id : 'detail-view-title-area',
                x : 0, y : 0, width : 1920, height : 144,
                color : Volt.hexToRgb('#000000', 10),
            },
            {
                type : 'widget',
                id : 'detail-view-gamesthumbnail-area',
                x : 0, y : 144, width : 656, height : 369,
                color : Volt.hexToRgb('#FFFFFF', 0)
            },
            {
                type : 'widget',
                id : 'detail-view-gamesinfo-area',
                x : 710, y : 144, width : 1178, height : 241,
                color : Volt.hexToRgb('#FFFFFF', 0)
            },
            {
                type : 'widget',
                id : 'detail-view-storage-area',
                x : 26, y : 738, width : 210, height : 78,
                color : Volt.hexToRgb('#FFFFFF', 0)
            },
            {
                type : 'widget',
                id : 'detail-view-button-area',
                x : 710, y : 385, width : 1270, height : 284,
                color : Volt.hexToRgb('#FFFFFF', 0)
            },
            {
                type : 'widget',
                x : 0, y : 1080-216, width : 1920, height : 216,
                id : 'detail-view-relate-area',
                color : Volt.hexToRgb('#FFFFFF',0),
                children : [
                    {
                        type : 'text',
                        x : 24, y : 0, width : 1920, height : 52,
                        text : Volt.i18n.t('COM_SID_VIDEOS'),
                        textColor : Volt.hexToRgb('#FFFFFF'),
                        //color : Volt.hexToRgb('#FFFFFF', 10),
                        font : '26px',
                        horizontalAlignment : 'left',
                        verticalAlignment : 'center'
                    },
                    {
                        type : 'widget',
                        id : 'detail-relate-container',
                        x : 0, y : 52, width : 1920, height : 164,
						color : Volt.hexToRgb('#FFFFFF', 0),
						
                    }
                ]
            }
        ]
    },
    button_area:{
		 type: 'widget', x: 0, y: 0, width: 1270, height: 294,
		 color : Volt.hexToRgb('#FFFFFF',0),
		 children:[
			{
                    custom: { 'focusable': false },
                    type: 'text',
                    x: 0, y: 0, width: 1118, height: 114,
					horizontalAlignment:"left",
					verticalAlignment:"center",
					ellipsize:true,
                    textColor : Volt.hexToRgb('#ffffff'),
                    opacity: 153,
					id : 'games_description',
					text:"Flying hunter starting the engine to rescue kidnapped princess!!Colorful graphics and cool effect make you like watching animation Breathtaking sky chase begines!!Flying hunter staring the engine to rescue kidnap...Flying hunter starting the engine to rescue kidnapped princess!!Colorful graphics and cool effect make you like watching animation Breathtaking sky chase begines!!Flying hunter staring the engine to rescue kidnap...",
                    font : '30px',
            },
			{
					custom: { 'focusable': true },
					type : 'widget',
					id :'more_button_widget',
					x: 1146, y: 74, width : 40, height : 40,
			},
			{
					custom: { 'focusable': true },
					type : 'image',
					id :'screnshot1_btn',
					x: 0, y: 144, width : 270, height : 150,
                    src : Volt.getRemoteUrl('images/1080/games/screnshot_image3.jpg')
			},
			{
					custom: { 'focusable': true },
					type : 'image',
					id :'screnshot2_btn',
					x: 278, y: 144, width : 270, height : 150,
                    src : Volt.getRemoteUrl('images/1080/games/screnshot_image2.jpg')
			},
			{
					custom: { 'focusable': true },
					type : 'image',
					id :'screnshot3_btn',
					x: 556, y: 144, width : 270, height : 150,
                    src : Volt.getRemoteUrl('images/1080/games/screnshot_image1.jpg')
			},
			{
					custom: { 'focusable': true },
					type : 'widget',
					id :'download_button_widget',
					x: 0, y: 352, width : 275, height : 60,
			},
			{
					custom: { 'focusable': true },
					type : 'widget',
					id :'addFavorites_button_widget',
					x: 294, y: 352, width : 275, height : 60,
			},
			{
					custom: { 'focusable': true },
					type : 'widget',
					id :'share_button_widget',
					x: 588, y: 352, width : 275, height : 60,
			},
			{
					custom: { 'focusable': true },
					type : 'widget',
					id :'rating_button_widget',
					x: 882, y: 352, width : 275, height : 60,
			},
			]
			}
			
		 
	}

exports = DetailTemplate;