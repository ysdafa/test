var Backbone = Volt.require("lib/volt-backbone.js");
var GameListCollection = Volt.require("app/models/game-list-collection.js");
var ServerController = Volt.require('app/controller/server-controller.js');
var Q = Volt.require('modules/q.js');


/** @lends GamesModel.prototype */
var SpotLightModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,    //'ok'   
        'category_id' : null,
        'category_name' : null,
        'trending_title' : null,
        'trending_list_cnt' : null,  //"Merry Charistmas"     
        'trending_list' : null,
        'genre_games_title' : null,
        'genre_games_list_cnt' : null,
        'genre_games_list' : null,
        'firends_pick_list_cnt' : null,
        'friends_pick_list' : null,
    },
    
    initialize : function(models, options) {
        this.set('trending_list', new GameListCollection());
        this.set('genre_games_list', new GameListCollection());
        this.set('friends_pick_list', new GameListCollection());
    },

    fetch:function(options){
        var deferred =  Q.defer()
        , self = this;

		var _rest;
		if(options == null || options == undefined) {
			_rest = "game/recommend/v2/main/category/C0010";
        } else {
			if(options.path != undefined && options.path != null && options.path != '') {
				_rest = "game/recommend/v2/main/category/" + options.path;
			} else {
				print("[spotlight-model.js] error: lack url path param ");
				return;        
			}
           
			if(options.latest_app_id != undefined && options.latest_app_id != null && options.latest_app_id != '') {
				_rest = _rest + '?latest_app_id=' + options.latest_app_id;
			}  
       }
		print("[spotlight-model.js] process a get request:" + _rest);
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
		            print("[spotlight-model.js] success result:" + data);
		            self.parse(data,status,response);  
		            deferred.resolve();    
		        },
		        error : function(response, status, exception) {
		            print("[spotlight-model.js] error result:" + exception + JSON.stringify(response));
		        	deferred.reject(response);
		        },
		        complete: function(response, status) {   
		            print("[spotlight-model.js] " + status);	
		        }
		    }
		);
        return deferred.promise;
    },
    
    parse:function(data){
    	var parsonData = JSON.parse(data);
		if(!parsonData.rsp.hasOwnProperty('C0010')){
			return;
		}
		this.set('category_id',         parsonData.rsp.C0010.category_id);
        this.set('category_name',      parsonData.rsp.C0010.category_name);
        this.set('trending_title',     parsonData.rsp.C0010.trending_title);
		this.set('trending_list_cnt',         parsonData.rsp.C0010.trending_list_cnt);
        this.set('genre_games_list_cnt',      parsonData.rsp.C0010.genre_games_list_cnt);
        this.set('friends_pick_list_cnt',     parsonData.rsp.C0010.friends_pick_list_cnt); 
        this.set('genre_games_title',     parsonData.rsp.C0010.genre_games_title);
		
        var trending_list = this.get('trending_list');
        var genre_games_list = this.get('genre_games_list');
        var friends_pick_list = this.get('friends_pick_list');
            
        trending_list.reset(parsonData.rsp.C0010.trending_list); 
        genre_games_list.reset(parsonData.rsp.C0010.genre_games_list);               
        friends_pick_list.reset(parsonData.rsp.C0010.friends_pick_list);
    }
});

exports = new SpotLightModel();

