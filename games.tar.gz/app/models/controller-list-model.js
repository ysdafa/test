var Backbone = Volt.require("lib/volt-backbone.js");
var ControllerListModel = Backbone.Model.extend({
    defaults : {
          'controller_url' : null,
          'controller_id' : null, 
          'available' : null,
          'controller_name' : null,
          'roll_over_url' : null
    },
    initialize : function(models, options) {

    },
    parse : function(response) {

    }
});

var initialize = function() {

};
function onKeyEvent(keycode) {

}

exports = ControllerListModel; 