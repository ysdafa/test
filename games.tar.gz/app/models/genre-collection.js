var Backbone=Volt.require('lib/volt-backbone.js');
var GenreModel=Volt.require('app/models/genre-model.js');
var GenreCollection=Backbone.Collection.extend({
    model:GenreModel,

});
exports=GenreCollection;