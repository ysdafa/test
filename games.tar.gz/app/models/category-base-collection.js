var Q 				  = Volt.require('modules/q.js');
var Backbone 		  = Volt.require("lib/volt-backbone.js");
var CategoryBaseModel = Volt.require("app/models/category-base-model.js");
var ServerController  = Volt.require('app/controller/server-controller.js');
var localStorage 	  = Volt.require("lib/volt-local-storage.js");


var CategoryListCollection = Backbone.Collection.extend({
    model: CategoryBaseModel,

	offline: function(data) {
		print('[category-base-collection.js ] offline');
        var deferred = Q.defer();
        var caching = localStorage.getItem('category-base');

        print('[category-base-collection.js ] offline'+ JSON.stringify(caching));
		var strCaching = JSON.stringify(caching);
        if (caching && strCaching.length > 0) {
			data = caching;
            this.parse(data,'offline');
            deferred.resolve();
        }else {
            deferred.reject();
        }
        return deferred.promise;
    },
    
    fetch : function(options) {
        var deferred =  Q.defer()
        , self = this;
		
		var _rest = "game/recommend/v2/main/categories";
		Volt.log("[category-base-controllection.js] process a request");
		ServerController.callAPI({
	            type: 'GET',
	            url: _rest
	        },
	        {
	        	bodyValue: {},
				success : function(data, status, response) {
				    Volt.log("[category-base-controllection.js] success result:" + data);
		            self.parse(data,status,response);  
		            deferred.resolve();
	            },
	            error : function(response, status, exception) {
	                Volt.log("[category-base-controllection.js] error result:" + exception + JSON.stringify(response));
	            	deferred.reject(exception);
	            },
	            complete: function(response, status) {   
	                Volt.log("[category-base-controllection.js] " + status);	
	            }
	        }
		);
        return deferred.promise;
	},
    
	parse : function(data, status, response) {
		if('offline' != status){
			var time = new Date().getTime();
			localStorage.setItem('category-base', data);
			localStorage.setItem('category-base-caching-time', time);
        	Volt.log("[category-base-controllection.js] category-base-caching-time : "+ time);
		}
		
		var parseData = JSON.parse(data);
		this.reset(parseData.rsp.category_list);
	}    
});

exports = new CategoryListCollection;
