
var Backbone = Volt.require("lib/volt-backbone.js");


var GamesModel = Volt.require('app/models/games-model.js');

var GamesCollection = Backbone.Collection.extend({
    model: GamesModel,
        
    fetch: function(categoryId) {
        switch(categoryId){
            case 'spotlight':
                this.reset(spotlight);
                break;
            case 'most_popular':
                this.reset(mostPopular);
                break;
            case 'whats_new':
                this.reset(whatsNew);
                break;
            case 'top_grossing':
                this.reset(topGrossing);
                break;
            case 'genre':
                this.reset(genre);
                break;
            case 'brand_zone':
                this.reset(brandZone);
                break;
            case 'my_page':
                this.reset(myPage);
                break;
        }
    },
});

exports = new GamesCollection();



var spotlight = [
{
    imgUrl:"images/1080/games/1.jpg",
    rcolor:{r:82, g:72, b:36},
    title:'No Man Land',
},
{
    imgUrl:"images/1080/games/2.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
},
{
    imgUrl:"images/1080/games/3.jpg",
    rcolor:{r:51, g:97, b:255},
    title:'Tom & Jerry',
},
{
    imgUrl:"images/1080/games/4.jpg",
    rcolor:{r:108, g:233, b:133},
    title:'Reloaded'
},
{
    imgUrl:"images/1080/games/5.jpg",
    rcolor:{r:0, g:152, b:135},
    title:'Lord of the Rings'
},
{
    imgUrl:"images/1080/games/6.jpg",
    rcolor:{r:171, g:171, b:169},
    title: 'Death Race',
},
{
    imgUrl:"images/1080/games/7.jpg",
    rcolor:{r:0, g:0, b:0},
    title:'The Oxford Murders',
},
{
    imgUrl:"images/1080/games/8.jpg",
    rcolor:{r:138, g:129, b:194},
    title:'Titanic'
},
{
    imgUrl:"images/1080/games/9.jpg",
    rcolor:{r:6, g:25, b:31},
    title:'Pirates of the Caribbean',
},
{
    imgUrl:"images/1080/games/10.jpg",
    rcolor:{r:9, g:40, b:68},
    title:'Ra One',
}
];
var brandZone=[{
    thumbnail_url:"images/1080/games/6.jpg",
    rcolor:{r:171, g:171, b:169},
    game_title: 'Death Race',
},
{
    thumbnail_url:"images/1080/games/7.jpg",
    rcolor:{r:0, g:0, b:0},
    game_title:'The Oxford Murders',
},
{
    thumbnail_url:"images/1080/games/8.jpg",
    rcolor:{r:138, g:129, b:194},
    game_title:'Titanic'
}];
var mostPopular = [
{
    imgUrl:"images/1080/games/1.jpg",
    rcolor:{r:82, g:72, b:36},
    title:'No Man Land',
}]
var whatsNew = [
{
    imgUrl:"images/1080/games/2.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
}]
var topGrossing = [
{
    imgUrl:"images/1080/games/3.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
}]
var genre = [
{
    imgUrl:"images/1080/games/4.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
}]
var myPage = [
{
    imgUrl:"images/1080/games/5.jpg",
    rcolor:{r:255, g:177, b:92},
    title:'Iron Man',
}]