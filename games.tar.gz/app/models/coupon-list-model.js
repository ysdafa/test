/**
 * @author tiansx
 */
var Backbone = Volt.require("lib/volt-backbone.js");
var CouponListModel = Backbone.Model.extend({
    defaults : {
          'no' : null,
          'coupon_title' : null, 
          'coupon_no' : null, 
          'expired_date' : null,
          'expired_flag' : null,
          'used_flag' : null,
          'message' : null,
          'game_list_count' : null,
          'game_list':[],
    },
})


exports = CouponListModel; 