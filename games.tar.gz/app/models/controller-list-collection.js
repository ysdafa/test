var Backbone = Volt.require("lib/volt-backbone.js");
var ControllerListModel = Volt.require("app/models/controller-list-model.js");

var ControllerListCollection = Backbone.Collection.extend({
        model : ControllerListModel,
        
    });

exports = ControllerListCollection;
