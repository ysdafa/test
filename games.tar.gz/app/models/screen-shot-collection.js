var Backbone = Volt.require("lib/volt-backbone.js");
var ScreenShotListModel = Volt.require("app/models/screen-shot-list.js");

var ScreenShotListCollection = Backbone.Collection.extend({
        model : ScreenShotListModel,
        
    });

exports = ScreenShotListCollection;
