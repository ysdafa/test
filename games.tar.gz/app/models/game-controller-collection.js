/**
 * @author sunlj
 * @20140723
 */

var Backbone = Volt.require("modules/backbone.js");
var GameControllerModel = Volt.require('app/models/game-controller-model.js');

var GameControllerCollection = Backbone.Collection.extend({
	model : GameControllerModel,

});

exports = GameControllerCollection;
