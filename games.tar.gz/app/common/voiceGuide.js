var DeviceModel 	  = Volt.require('app/models/device-model.js');

var VoiceGuide = {
    strStaticMap : [],
    
    init :function(){
    	Volt.log('[voiceGuide.js] init .....');
        this.strStaticMap.push({key : 'cancel',					value : Volt.i18n.t('COM_SID_CANCEL')});
		this.strStaticMap.push({key : 'button',					value : Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON')});
		this.strStaticMap.push({key : 'please wait',			value : Volt.i18n.t('TV_SID_PLEASE_WAIT')});
		this.strStaticMap.push({key : 'deleting',				value : Volt.i18n.t('COM_SID_DELETING_KR_PANEL')});
		this.strStaticMap.push({key : 'expired',				value : Volt.i18n.t('TEXT_EXPIRED_P')});
		this.strStaticMap.push({key : 'ok',						value : Volt.i18n.t('COM_SID_OK')});
		this.strStaticMap.push({key : 'loading',				value : Volt.i18n.t('COM_TV_SID_LOADING')});
		this.strStaticMap.push({key : 'options',				value : Volt.i18n.t('UID_OPTIONS')});
		this.strStaticMap.push({key : 'register your coupon',	value : Volt.i18n.t('TV_SID_REGISTER_YOUR_COUPON')});
		this.strStaticMap.push({key : 'edit box',				value : Volt.i18n.t('TV_SID_TEXT_BOX')});
		this.strStaticMap.push({key : 'done',					value : Volt.i18n.t('UID_DONE')});
		this.strStaticMap.push({key : 'checkbox',				value : Volt.i18n.t('TV_SID_CHECKBOX_ACC')});
		this.strStaticMap.push({key : 'checked',					value : Volt.i18n.t('TV_SID_CHECKED')});
		this.strStaticMap.push({key : 'unchecked',				value : Volt.i18n.t('TV_SID_UNCHECKED_KR_UN')});
		this.strStaticMap.push({key : 'used',					value : Volt.i18n.t('TV_SID_USED')});
		this.strStaticMap.push({key : 'videos',					value : Volt.i18n.t('COM_SID_VIDEOS')});
		//this.strStaticMap.push({key : 'select all',				value : Volt.i18n.t('COM_SID_SELECT_ALL')});
		//this.strStaticMap.push({key : 'gamecontrollerguide',	value : Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE')});
		this.strStaticMap.push({key : 'games',					value : Volt.i18n.t('UID_PAN_GAMES')});
		this.strStaticMap.push({key : 'rating',					value :  Volt.i18n.t('UID_RATE')});
		this.strStaticMap.push({key : 'play',					value :  Volt.i18n.t('COM_SID_PLAY_KR_RUN')});
		this.strStaticMap.push({key : 'close',					value :  Volt.i18n.t('COM_SID_CLOSE')});
		this.strStaticMap.push({key : 'coupons',				value :  Volt.i18n.t('TV_SID_COUPONS')});
    },
    
    getVoiceGuide : function (voiceText, queuingFlag) {
    	Volt.log('[voiceGuide.js] getVoiceGuide text : ' + voiceText + ',,,,queuingFlag = ' + queuingFlag);
    	if (1 != DeviceModel.get('tts')) {
    		Volt.log('[voiceGuide.js] don not call TTS');
    		return;
    	}

    	var formatStr = this.formatMultiLanguage(voiceText);
    	Volt.log('[voiceGuide.js] voice guide formatStr : ' + formatStr);

		if(formatStr){
			if (queuingFlag) {
	    		TTS.queuingPlay(formatStr);
	    	} else {
	    		TTS.setText(formatStr);
	    		TTS.play();
	    	}
		}
    },

	formatMultiLanguage : function (params) {
		var language = DeviceModel.get('languageCode');
		Volt.log('[voiceGuide.js] formatMultiLanguage lauguage = ' + language + ',,,params = ' + params);
		if ('en' == language) {
			return params;
		}
		
		var formatStr = params.toLowerCase();
		for (var i = 0; i < this.strStaticMap.length; i++) {
			var obj = this.strStaticMap[i];
			if (formatStr.indexOf(obj.key) != -1) {
				formatStr = formatStr.replace(obj.key, obj.value);
			}
		}

		return formatStr;
	},

}

exports = VoiceGuide;