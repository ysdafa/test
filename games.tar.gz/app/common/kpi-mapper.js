var KPI 				= Volt.require('lib/volt-kpi.js');
var DeviceModel 		= Volt.require("app/models/device-model.js");
var RouterController 	= Volt.require('app/controller/router-controller.js');
var voltApiWrapper      = Volt.require("app/common/voltapi-wrapper.js");
function KPIMapper(){

	var CATEGORY_MAPPER = {
		'G01_MYPAGE' 		: 	'PG001',
		'G02_SLIGHT' 		: 	'PG002',
		'G03_POPULAR' 		: 	'PG003',
		'G04_WHATSNEW'  	: 	'PG004',
		'G05_TOPGROSSING' 	: 	'PG005',
		'G06_MESSAGE' 		: 	'PG006',
		'G07_COUPON' 		: 	'PG007',
		'G08_DETAIL' 		: 	'PG008',
		'G09_GENRE01' 		: 	'PG009',
		'G10_GENRE02' 		: 	'PG010',
		'G11_GENRE03' 		: 	'PG011',
		'G12_GENRE04' 		: 	'PG012',
		'G13_GENRE05' 		: 	'PG013',
		'G14_GENRE06' 		: 	'PG010',

		'EXEGAME' 			: 	'EV001',
		'JUMPSSO' 			: 	'EV002',
		'AGREETERMS' 		: 	'EV003',
		'PLAYGAME' 			: 	'EV004',
		'LPDWCLICK' 		: 	'EV005',
		'LPUPDATE' 			: 	'EV006',
		'LPDELETE' 			: 	'EV007',
		'LPVIEW' 			: 	'EV008',
		'LPPLAYCLICK' 		: 	'EV009',
		'LPCANCEL' 			: 	'EV010',
		'OPTIONCLICK' 		: 	'EV011',
		'OPTIONDELETE' 		: 	'EV012',
		'OPTIONNICK' 		: 	'EV013',
		'OPTIONNICKRQST' 	: 	'EV014',
		'OPTIONUPDATE' 		: 	'EV015',
		'OPTIONGCGUIDE' 	: 	'EV016',
		'MOVECATEG' 		: 	'EV017',
		'MOVEMSG' 			: 	'EV018',
		'MOVECOUPON' 		: 	'EV019',
		'NICKCLICK' 		: 	'EV020',
		'NICKRQST' 			: 	'EV021',
		'JUMPNOTI' 			: 	'EV022',
		'COUPONCLICK' 		: 	'EV023',
		'COUPONRQST' 		: 	'EV024',
		'COUPONERROR' 		: 	'EV025',
		'COUPONDELETE' 		: 	'EV026',
		'POPCGAMES' 		: 	'EV027',
		'VIEWGAME' 			: 	'EV028',
		'DWCLICK' 			: 	'EV029',
		'DWCANCEL' 			: 	'EV030',
		'DWFIN' 			: 	'EV031',
		'PLAYCLICK' 		: 	'EV032',
		'RATINGCLICK' 		: 	'EV033',
		'RATINGRQST' 		: 	'EV034',
		'GCGUIDECLICK' 		: 	'EV035',
		'VIDEOS' 			: 	'EV036',
		'IMAGES' 			: 	'EV037',
		'MYDELETE' 			: 	'EV038',
		'UPDATEPOP' 		: 	'EV039',
		'MYUPDATE' 			: 	'EV040',
	};
	this.init = function(){
		print('[kpe-mapper.js] init --------');
		KPI.init({
	        serviceName : '15_game',
	        modelId : DeviceModel.get('modelId'),
	        uid : ' ',
	        duid : DeviceModel.get('duid'),
	        countryCode : DeviceModel.get('countryCode'),
	        version : DeviceModel.get('firmware'),
	        configFallbackPath : 'app/common/LogPolicyConfig.xml',
	        debug : true
	    });
	};

	this.addEventLog = function(eventName, pOptions){
		var options = pOptions || {};
		
		//get c according to mapping
		options['c'] = CATEGORY_MAPPER[eventName];

		if(pOptions['d'].hasOwnProperty('cp') && '' == pOptions['d']['cp']){
			pOptions['d']['cp'] = this.getPageEvent().pageEvent;
		}
		
		if(pOptions['d'].hasOwnProperty('inputby')){
			pOptions['d']['inputby'] = DeviceModel.getInputBy();
		}
		
		Volt.log('[kpi-mapper.js]addEventLog eventName : ' + eventName + ',pOptions : ' + JSON.stringify(pOptions));
		
		KPI.add(eventName, options);
		Volt.log('[kpi-mapper.js]addEventLog eventName end ');
	};

	var lastPage = null;
    //startPage, endPage
    this.enterPage = function(eventName, pOptions,appid){
        Volt.log('[kpi-mapper.js]enterPage - eventName  = ' + eventName + ',pOptions = ' + JSON.stringify(pOptions) + ',lastPage : ' + JSON.stringify(lastPage));
        var options = pOptions ? pOptions : {};
		//get category according to eventName
        options['c'] = CATEGORY_MAPPER[eventName];
		options['d'] = options['d'] ? options['d']:{};
		options['d']['inputby'] = DeviceModel.getInputBy();
		
        if(lastPage != null){
			if (lastPage.eventName != eventName){
                this.leavePage(lastPage.eventName, lastPage.options);
            }else {
            	Volt.log('[kpi-mapper.js] This page is already entered!' + lastPage.eventName);
                return;
            }
        }
       
        if(lastPage != null){
            options['d']['pp'] = lastPage.eventName;
			Volt.log('[kpi-mapper.js] Last Page : ' + options.d.pp);
        }

		if (eventName == 'G08_DETAIL') {
            options['d']['appid'] = appid;
			if(voltApiWrapper.isWidgetInstalled(appid)){
				options['d']['appdw'] ='y';
			}else{
				options['d']['appdw'] ='n';
			}
			
        }
		
        KPI.startPage(eventName, options);
		lastPage = {eventName : eventName, options : options};
    };
	
	this.leavePage = function(eventName, pOptions){
		Volt.log('[kpi-mapper.js]leavePage - eventName = ' + eventName + ',pOptions = ' + JSON.stringify(pOptions));
		var pageName,
			cartegory,
			options;

		if(eventName){ //target Page
			pageName = eventName;
			options = pOptions || {};
			options['c'] = CATEGORY_MAPPER[eventName];
		}else{ //Last Page ps: for the time now,it will never enter into it
			if(lastPage){
				pageName = lastPage.eventName;
				options = pOptions || {};
				options['c'] = CATEGORY_MAPPER[eventName];
			}
		}

		if(pageName){
			KPI.endPage(pageName, options);
			lastPage = null;
		}else{
			Volt.log('[kpi-mapper.js] There is no page event to be leave');
		}
	};

	this.changeUID = function() {
        KPI.changeUID(KPI.getUID());
    };

    this.getCategory = function(eventName){
		return CATEGORY_MAPPER[eventName];
    };

	//some common methods
	this.getPageEvent = function () {
		Volt.log('[kpi-mapper.js]  getPageEvent....');
		var pageObj = {pageEvent : '',spStr : ''},
		pageName = '';
		if (RouterController.getCurrentView().name) {
			pageName = RouterController.getCurrentView().name;
			Volt.log('[kpi-mapper.js]  getPageEvent.... pageName = ' + pageName);
			switch (pageName) {
			case 'main-view': {
					Volt.log('[kpi-mapper.js] subName = ' + RouterController.getCurrentView().subName);
					switch (RouterController.getCurrentView().subName) {
						case 'main-mypage-view-new':
							pageObj.pageEvent = 'G01_MYPAGE';
							pageObj.spStr = 'M';
							break;
						case 'main-spotlight-view':
							pageObj.pageEvent = 'G02_SLIGHT';
							pageObj.spStr = 'S';
							break;
						case 'main-popular-view':
							pageObj.pageEvent = 'G03_POPULAR';
							pageObj.spStr = 'P';
							break;
						case 'main-whatsnew-view':
							pageObj.pageEvent = 'G04_WHATSNEW';
							pageObj.spStr = 'N';
							break;
						case 'main-grossing-view':
							pageObj.pageEvent = 'G05_TOPGROSSING';
							pageObj.spStr = 'T';
							break;
						case 'main-genre-arcade-view':
							pageObj.pageEvent = 'G09_GENRE01';
							pageObj.spStr = 'G1';
							break;
						case 'main-genre-sports-view':
							pageObj.pageEvent = 'G10_GENRE02';
							pageObj.spStr = 'G2';
							break;
						case 'main-genre-party-view':
							pageObj.pageEvent = 'G11_GENRE03';
							pageObj.spStr = 'G3';
							break;
						case 'main-genre-puzzle-view':
							pageObj.pageEvent = 'G12_GENRE04';
							pageObj.spStr = 'G4';
							break;
						case 'main-genre-shooting-view':
							pageObj.pageEvent = 'G13_GENRE05';
							pageObj.spStr = 'G5';
							break;
						default:
							Volt.log("wrong sub name");
							break;
						}
					break;
				}
			case 'message-box-view':
				pageObj.pageEvent = 'G06_MESSAGE';
				//TBD pageObj.spStr = 'M';
				break;
			case 'coupon-box-view':
				pageObj.pageEvent = 'G07_COUPON';
				pageObj.spStr = 'CC';
				break;
			case 'detail-view':
				pageObj.pageEvent = 'G08_DETAIL';
				break;
			default:
				Volt.log("wrong view name");
				break;
			}
		}
		return pageObj;
	};

	this.KPILogEnterPage = function () {
		var pageEvent = this.getPageEvent().pageEvent;
		Volt.log('[kpi-mapper.js]  KPILogEnterPage....pageEvent = ' + pageEvent);

		if (pageEvent != '') {
			this.enterPage(pageEvent);
		}
	};
	
	this.KPILogLeavePage = function () {
		var pageEvent = this.getPageEvent().pageEvent;
		Volt.log('[kpi-mapper.js] KPILogLeavePage .....pageEvent = ' + pageEvent);

		if (pageEvent != '') {
			this.leavePage(pageEvent);
		}
	};

	this.getSelectPosition = function(index){
		Volt.log('[kpi-mapper.js] getSelectPosition index = ' + index);
		var spStr = this.getPageEvent().spStr;
		spStr += this.getIndexFormat(index);

		Volt.log('[kpi-mapper.js] spStr = ' + spStr);
	    return spStr;
	};
	
	this.getIndexFormat = function(index){
		Volt.log('[kpi-mapper.js] getIndexFormat index = ' + index);
		var strIndex = '';
		if(index <= 0){
			return '';
		}
		
		if(index <=9 ){
			strIndex = '00'
		}else if(index <= 99){
			strIndex = '0'
		}else if(index <= 999){
			strIndex = '';
		}

		strIndex += index;
		Volt.log('[kpi-mapper.js] getIndexFormat strIndex = ' + strIndex);
		
	    return strIndex;
	};

}

exports = new KPIMapper();
