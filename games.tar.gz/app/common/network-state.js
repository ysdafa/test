var EventMediator  = Volt.require('app/common/event-mediator.js');
var voltapi        = Volt.require('modules/voltapi.js');
var CommonDefine   = Volt.require('app/common/common-define.js');
var _              = Volt.require("modules/underscore.js")._;

var stateNetwork  = true;
var bReady        = false;

var Network = {
    
    init : function() {
        EventMediator.on(CommonDefine.Event.NETWORK_READY, _.bind(this.onNetworkInitialized,this)); 
    },
       
    onNetworkInitialized : function(){
        Volt.log('onNetworkInitialized');
        this.listenNetwork();
		bReady = true;
    },
	
	isReady : function(){
		return bReady;
	},

    getNetWorkState : function() {
        return stateNetwork;
    },

    setNetWorkState : function(status) {
        stateNetwork = status;
    },

    listenNetwork : function() {
        Volt.log("[network-state.js] checkNetwork()");

        voltapi.network.getAvailableNetworks(function(networkList) {
            networkList[0].setWatchListener({
                onconnect : function(type) {
                    Volt.log("[app.js] wireless network onconnect");
                    stateNetwork = true;
                },
                ondisconnect : function(type) {
                    Volt.log("[app.js] wireless network ondisconnect");
                    stateNetwork = false;
                }
            }, function() {
                Volt.log("[app.js] wireless network error");
                stateNetwork = false;
            });

            networkList[1].setWatchListener({
                onconnect : function(type) {
                    Volt.log("[app.js] wired network onconnect");
                    stateNetwork = true;
                },
                ondisconnect : function(type) {
                    Volt.log("[app.js] wired network ondisconnect");
                    stateNetwork = false;
                }
            }, function() {
                Volt.log("[app.js] wired network error");
                stateNetwork = false;
            });
        }, function(errorMessage) {
            Volt.log("[app.js] network error errorMessage : " + errorMessage);
            stateNetwork = false;
        });
        }
}

exports = Network; 