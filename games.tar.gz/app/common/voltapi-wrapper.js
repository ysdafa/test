var _              = Volt.require("modules/underscore.js")._;
var voltapi        = Volt.require("modules/voltapi.js");
var CommonDefine   = Volt.require('app/common/common-define.js');
var CommonFucntion = Volt.require('app/common/common-function.js');
var EventMediator  = Volt.require('app/common/event-mediator.js');
var Utils          = Volt.require('app/common/utils.js');

var installList    = [];
var nativeGameList = [];
var needUpdateList = [];
var updatingList   = [];
var updatedList    = [];
var bWasInitStatus = false;
var wrapperSelf    = null;

var VoltApiWrapper = (function() {
    exports = {
        init : function() {
            Volt.log('[voltapi-wrapper.js] init.......');
            wrapperSelf = this;
            EventMediator.on(CommonDefine.Event.WAS_READY, _.bind(this.onWASInitialized,this)); 
        },

        onWASInitialized : function(){
            Volt.log('[voltapi-wrapper.js]receive WAS_READY:::'+bWasInitStatus);
            if(!bWasInitStatus){
                bWasInitStatus = true;
                this.registAppInstallEvent();
                this.initSSOAccountInfo();
                this.subscribeSSOStateChange();
                this.getUpdateAppList();
            }
        },

        checkInitStatus : function() {
                return bWasInitStatus;
        },
        
        onWASAppChanged: function(){
            Volt.log('receive event ==> app has been changed');
        },

        registAppInstallEvent : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            Volt.log("[VoltApiWrapper.js] registAppInstallEvent");
            //register install related event
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOADING,        
                                        _.bind(this.downloadProgressCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_COMPLETED, 
                                        _.bind(this.downloadCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALLING,         
                                        _.bind(this.installProgressCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_COMPLETED,  
                                        _.bind(this.installCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_CANCLE_COMPLETED, 
                                        _.bind(this.downloadCanceledCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALLING, 
                                        _.bind(this.unInstallingCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_COMPLETED, 
                                        _.bind(this.unInstallCallBack,this));

            //register fail event
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOSPACE, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_OTHERS, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_EXIST, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_OTHERS, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE,
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_SSO_STATE_CHANGE, 
                                        _.bind(this.ssoStateChangeCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_REQUEST_APP_LIST, 
                                        _.bind(this.saveUpdateList,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_SSO_SHOW_POPUP, 
                                        _.bind(this.showPopupCallback, this))
            
            /*vonf events*/                
            voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_WAS_APP_CHANGE,
                    _.bind(this.onWASAppChanged, this));
            
        },

        installApp : function(appID, packet_path, install_path) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            if (!wrapperSelf.isWidgetInstalling(appID)) {
                wrapperSelf.addInstallList(appID);
                var bRet = voltapi.WAS.installApp(appID, packet_path, install_path);
                Volt.log("[VoltApiWrapper.js]request installApp " + appID + " result " + bRet + " install_path = " + install_path);
                return bRet;
            } else {
                Volt.log("[VoltApiWrapper.js]don't request install this app this time " + appID);
                return false;
            }
        },

        cancelInstallApp : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            if (wrapperSelf.isWidgetInstalling(appID)) {
                Volt.log("[VoltApiWrapper.js] cancelInstallApp(" + appID +")");
                wrapperSelf.removeInstallList(appID);
                var bRet = voltapi.WAS.cancelInstallApp(appID);
                return bRet;
            }
        },

        unInstallApp : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }

            var bRet = voltapi.WAS.unInstallApp(appID);
            Volt.log("[VoltApiWrapper.js] unInstallApp() " + bRet);
            return bRet;
        },

        updateApp : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            if (!wrapperSelf.isAppUpdating(appID)) {
                wrapperSelf.addInstallList(appID);
                wrapperSelf.pushUpdatingList(appID);
                var bRet = voltapi.WAS.updateApp(appID);
                Volt.log("[VoltApiWrapper.js] updateApp() " + bRet);
            }
            return bRet;
        },

        launchApp : function(appID, payload) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            if(wrapperSelf.getGameTermStatus() == false) {
				Volt.log('[VoltApiWrapper.js] did not agree game terms');
				wrapperSelf.showGameTermsPopup();
        	} else {
	            var bRet = voltapi.WAS.launchApp(appID, payload);
	            Volt.log("[VoltApiWrapper.js] launchApp() " + bRet);
	            return bRet;
        	}
        },

        //for app install status
        isWidgetInstalled : function(appID) {//didn't implemented
            if(!bWasInitStatus){
                Volt.log('[VoltApiWrapper.js] WAS Wrapper is not initialed');
                return;
            }
            
            var bRet = wrapperSelf.getAppInfo(appID);
            if (bRet != undefined && bRet != -1 && bRet != false) {
                return true;
            }
            
            return false;
        },
        
        isWidgetInstalledInUSB : function(appID){
            if(!bWasInitStatus){
                Volt.log('[VoltApiWrapper.js] WAS Wrapper is not initialed');
                return;
            }
            
            var bRet = wrapperSelf.getAppInfo(appID);
            if(bRet != undefined && bRet != -1 && bRet != false && bRet.app_installed_path.indexOf("/opt/storage/usb/") != -1){
                return true;
            }
            return false;
        },

        getAppInfo : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var ret = voltapi.WAS.getAppInfo(appID);
            Volt.log("[VoltApiWrapper.js] getAppInfo" + appID + " " + ret);
            //Volt.log('[VoltApiWrapper.js] getAppInfo = ' + JSON.stringify(ret));
            return ret;
        },

        getWidgetInstallStatus : function(appID) {
            if(!bWasInitStatus){
                Volt.log('[VoltApiWrapper.js] WAS Wrapper is not initialed');
                return;
            }
            
            if (wrapperSelf.isWidgetInstalling(appID)) {
                var findObj = _.find(installList, function(obj) {
                    if (obj.appID === appID) {
                        return obj;
                    }
                });
                return findObj;
            }
        },

        isWidgetInstalling : function(appID) {
            Volt.log('[VoltApiWrapper.js]isWidgetInstalling: ', installList);
            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined && (findObj.status === 'downloading' || findObj.status === 'installing')) {
                Volt.log("[VoltApiWrapper.js] this widget is Installing" + appID);
                return true;
            } else {
                Volt.log("[VoltApiWrapper.js] this widget is not installing" + appID);
                return false;
            }
        },
        //Manager need update list
        getUpdateAppList : function() {//get update app list
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return;
            }
            
			//this.pushUpdateList('141399000185');
            var ret = voltapi.WAS.requestAppList(voltapi.WAS.WAS_LIST_TYPE_APP_UPDATE_LIST);
            Volt.log("[VoltApiWrapper.js] getUpdateAppList: " + JSON.stringify(ret));
            return ret;
        },

        haveNewVersion : function(appID) {
            Volt.log('[VoltApiWrapper.js]haveNewVersion: installList = ' + needUpdateList);
            var findObj = _.find(needUpdateList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[VoltApiWrapper.js] this widget has new version:" + appID);
                return true;
            } else {
                Volt.log("[VoltApiWrapper.js] this widget is already latest:" + appID);
                return false;
            }
        },

        saveUpdateList : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] saveUpdateList: data1 = " + JSON.stringify(data1));
            if (!CommonFucntion.checkValid(data1)) {
                return;
            }
            for (var i = 0; i < data1.length; i++) {
                this.pushUpdateList(data1[i].app_id);
            }
        },

        pushUpdateList : function(appID) {
            Volt.log("[VoltApiWrapper.js] pushUpdateList()");

            var findObj = _.find(needUpdateList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                needUpdateList.push(newObj);
                Volt.log("[VoltApiWrapper.js] needUpdateList:" + JSON.stringify(needUpdateList));
            }
        },

        removeUpdateGame : function(appID) {
            Volt.log("[VoltApiWrapper.js] removeUpdateGame():" + appID);

            var findObj = _.find(needUpdateList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            var findIndex = _.indexOf(needUpdateList, findObj);
			Volt.log('find index::::'+findIndex);
            needUpdateList.splice(findIndex, 1);
			Volt.log('after remove update game, length:::'+needUpdateList.length);
        },

        removeUpdateList : function() {
            needUpdateList = [];
        },

		getNeedUpdateFlag : function() {
			var nCount = needUpdateList.length;
			Volt.log("[VoltApiWrapper.js] nCount = " + nCount);
			if(nCount > 0) {
				return true;
			} else {
				return false;
			}
        },

        //Manager updating List
        pushUpdatingList : function(appID) {
            Volt.log("[VoltApiWrapper.js] pushUpdatingList()");

            var findObj = _.find(updatingList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                updatingList.push(newObj);
                Volt.log("[VoltApiWrapper.js] pushUpdatingList:" + JSON.stringify(updatingList));
            }
        },

        removeUpdatingGame : function(appID) {
            Volt.log("[VoltApiWrapper.js] removeUpdatingGame():" + appID);

            var findObj = _.find(updatingList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            var findIndex = _.indexOf(updatingList, findObj);
            updatingList.splice(findIndex, 1);
        },

        removeUpdatingList : function() {
            updatingList = [];
        },

        isAppUpdating : function(appID) {
            Volt.log('[VoltApiWrapper.js]isWidgetUpdating: updatingList = ' + updatingList);
            var findObj = _.find(updatingList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[VoltApiWrapper.js] this widget is Updating:" + appID);
                return true;
            } else {
                Volt.log("[VoltApiWrapper.js] this widget is not Updating:" + appID);
                return false;
            }
        },

        //Manager updated List
        pushUpdatedList : function(appID) {
            Volt.log("[VoltApiWrapper.js] pushUpdatedList()");

            var findObj = _.find(updatedList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                updatedList.push(newObj);
                Volt.log("[VoltApiWrapper.js] pushUpdatedList:" + JSON.stringify(updatedList));
            }
        },

        removeUpdatedGame : function(appID) {
            Volt.log("[VoltApiWrapper.js] removeUpdatedGame():" + appID);

            var findObj = _.find(updatedList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            var findIndex = _.indexOf(updatedList, findObj);
            updatedList.splice(findIndex, 1);
        },

        removeUpdatedList : function() {
            updatedList = [];
        },

        isAppUpdated : function(appID) {
            Volt.log('[VoltApiWrapper.js]removeUpdatedGame: updatedList = ' + updatedList);
            var findObj = _.find(updatedList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[VoltApiWrapper.js] this widget is Updated:" + appID);
                return true;
            } else {
                Volt.log("[VoltApiWrapper.js] this widget is not Updated:" + appID);
                return false;
            }
        },
        
        //Manager installing game list begin
        addInstallList : function(appID) {
            Volt.log("[VoltApiWrapper.js] addInstallList()");

            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                newObj.status = 'downloading';
                newObj.progress = 0;
                installList.push(newObj);
                Volt.log("[VoltApiWrapper.js] installList" + installList);
            }
        },

        removeInstallList : function(appID) {
            Volt.log("[VoltApiWrapper.js] removeInstallList()");

            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            var findIndex = _.indexOf(installList, findObj);

            installList.splice(findIndex, 1);
        },

        removeAllInstallList : function() {
            Volt.log("[VoltApiWrapper.js] removeAllInstallList()");
			var findObj = _.find(installList, function(obj) {
				Volt.log('remove appID::::'+obj.appID);
				if(wrapperSelf.isWidgetInstalling(obj.appID)){
					var bRet = wrapperSelf.cancelInstallApp(obj.appID);
					Volt.log('[VoltApiWrapper.js] cancelInstallApp bRet = '+bRet);
				}
            });
			
            installList = [];
        },

        setInstallListStatus : function(appID, status, progress) {
            Volt.log("[VoltApiWrapper.js] setInstallListStatus()");

            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            if (CommonFucntion.checkValid(findObj)) {
                findObj.status = status;
                findObj.progress = progress;

                var findIndex = _.indexOf(installList, findObj);
                installList.splice(findIndex, 1, findObj);
            }
        },

        getInstallList : function() {
            Volt.log("[VoltApiWrapper.js] getInstallList()");
            return installList;
        },

        //Manager installing game list end

        //Manager native game list begin
        getAppList : function() {//get local game widgets
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return;
            }
            
            var ret = voltapi.WAS.getAppList(voltapi.WAS.APPS_TYPE_ALL, voltapi.WAS.APPS_INFO_PREMIUM_GAME_TRUE, voltapi.WAS.APPS_INFO_FEATURED_ALL, voltapi.WAS.VIEWMODE_CUSTOM, 0, 100);
            Volt.log("[VoltApiWrapper.js] getAppList: " + JSON.stringify(ret));
            return ret;
        },

        pushNativeGame : function(appID) {
            Volt.log("[VoltApiWrapper.js] pushNativeGame()");
            
            var findObj = _.find(nativeGameList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                nativeGameList.push(newObj);
                Volt.log("[VoltApiWrapper.js] nativeGameList" + nativeGameList);
            }
        },

        removeNativeGame : function(appID) {
            Volt.log("[VoltApiWrapper.js] removeNativeGame()");

            var findObj = _.find(nativeGameList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            var findIndex = _.indexOf(nativeGameList, findObj);
            nativeGameList.splice(findIndex, 1);
        },

        getNativeGameList : function() {
            Volt.log('getNativeGameList');
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return [];
            }
            
            wrapperSelf.removeNativeGameList();
            var getApplist = wrapperSelf.getAppList();
            for (var i = 0; i < getApplist.length; i++) {
				Volt.log('==== premium game infomation ======');
				Volt.log('app_id:::'+getApplist[i].app_id);
				Volt.log('app_title:::'+getApplist[i].app_title);
				Volt.log('is_premium_game:::'+getApplist[i].is_premium_game);
				if(getApplist[i].is_premium_game == '2'){
					Volt.log('pushNativeGame........');
					wrapperSelf.pushNativeGame(getApplist[i].app_id);
				}
            }
            return nativeGameList;
        },

        removeNativeGameList : function() {
            nativeGameList = [];
        },
        //Manager native game list end

        downloadProgressCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] downloadProgressCallback()" + data1.app_id + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                this.setInstallListStatus(data1.app_id, 'downloading', data1.result);
            }

            EventMediator.trigger(CommonDefine.Event.DOWNLOAD_PROGRESS, data1);
        },

        downloadCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] downloadCallback()" + data1.app_id + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                if (data1.result === 0) {
                    this.setInstallListStatus(data1.app_id, 'downloading', 100);
                    data1.result = 100;
                } else {// download error
                    // that.removeInstallList(data1.app_id);
                }
            }

            EventMediator.trigger(CommonDefine.Event.DOWNLOAD_PROGRESS, data1);
        },

        installProgressCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] installProgressCallback()" + data1.app_id + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                this.setInstallListStatus(data1.app_id, 'installing', data1.result);
            }

            EventMediator.trigger(CommonDefine.Event.INSTALL_PROGRESS, data1);
        },

        installCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] installCallback()" + data1.app_id + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                if (this.isWidgetInstalling(data1.app_id)) {
                    Volt.log("[VoltApiWrapper.js] install success:" + data1.app_id);
					if(this.isAppUpdating(data1.app_id)) {
						this.pushUpdatedList(data1.app_id);
					}
                    this.removeInstallList(data1.app_id);
                    this.removeUpdatingGame(data1.app_id);
                    this.removeUpdateGame(data1.app_id);
                    EventMediator.trigger(CommonDefine.Event.INSTALL, data1);
                }
                //this.pushNativeGame(data1.app_id);
            }
        },

        downloadCanceledCallBack : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] downloadCanceledCallBack()" + data1.app_id + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                this.removeInstallList(data1.app_id);
				this.removeUpdatingGame(data1.app_id);
				this.removeUpdateGame(data1.app_id);
				this.removeUpdatedGame(data1.app_id);
            }

            EventMediator.trigger(CommonDefine.Event.DOWNLOAD_CANCELED, data1);
        },

        unInstallingCallBack : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                Volt.log("[VoltApiWrapper.js] unInstallingCallBack()" + data1.app_id + data1.result);
                EventMediator.trigger(CommonDefine.Event.UNINSTALL_PROGRESS, data1);
            }
        },

        unInstallCallBack : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                Volt.log("[VoltApiWrapper.js] unInstallCallBack()" + data1.app_id + data1.result);
                EventMediator.trigger(CommonDefine.Event.UNINSTALL, data1);
				this.removeUpdatingGame(data1.app_id);
				this.removeUpdateGame(data1.app_id);
				this.removeUpdatedGame(data1.app_id);
            }
        },

        installErrorCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] installErrorCallback: eventType = " + eventType + ", app_ID = " + data1.app_id + ", result = " + data1.result);
            var type;
            this.removeInstallList(data1.app_id);
			this.removeUpdatingGame(data1.app_id);
			this.removeUpdatedGame(data1.app_id);
            switch (eventType) {
                case voltapi.WAS.WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE:
                    type = CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE;
                    break;
                default:
                    type = CommonDefine.Event.INSTALL_FAIL;
					data1.errorCode = eventType;
                    //type = CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE;
                    break;
            }
            EventMediator.trigger(type, data1);
        },

        //////////////////////////////////////
        // WAS SSO Wrapper
        //////////////////////////////////////

        /*requestSSOAccessToken: function(appID, secretKey) {
         if(!bWasInitStatus)
         {
         print("[VoltApiWrapper.js] WAS Wrapper is not initialed");
         return false;
         }
         var ret = voltapi.WAS.requestSSOAccessToken(appID, secretKey);
         return ret;
         },*/

        subscribeSSOStateChange : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.subscribeSSOStateChange();
            return ret;
        },

        getSSOLoginState : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.getSSOLoginState();
            Volt.log("[VoltApiWrapper.js] getSSOLoginState = " + ret);
            if (ret == -1) {
                ret = 0;
            }
            return ret;
        },

        getSSOLoginInfo : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return null;
            }
            var ret = voltapi.WAS.getSSOLoginInfo();
            Volt.log("[VoltApiWrapper.js] login Info: " + ret);
            return ret;
        },

        /*getSSOToken: function() {
         if(!bWasInitStatus)
         {
         print("[VoltApiWrapper.js] WAS Wrapper is not initialed");
         return false;
         }
         var ret = voltapi.WAS.getSSOToken();
         print("[VoltApiWrapper.js] getSSOToken: " + ret);
         return ret;
         },*/

        startSSOPopup : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var type = (wrapperSelf.getSSOLoginState() == 0) ? 'SignIn' : 'LogOut';
            var payload = type+'&callerId=org.volt.games';
            Volt.log('startSSOPopup ====>>> payload = '+payload);
            var ret = voltapi.WAS.showSSOPopup(payload);
            return ret;
        },
        
        showPopupCallback : function(type, data){
            Volt.log('showPopupCallback');
            var json = JSON.parse(data);
            Volt.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>WAS_SSO_SHOW_POPUP result :"+ data);
        },

        showCPLinkPopup : function(payload) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.showSSOPopup(payload);
            return ret;
        },

        isLinkedApp : function(cpName) {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.isLinkedApp(cpName);
            Volt.log("[VoltApiWrapper.js]" + cpName + " link status:" + ret);
            return ret;
        },

        getGuid : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.getGuid();
            Volt.log("[VoltApiWrapper.js] getGuid = " + ret);
            return ret;
        },

        initSSOAccountInfo : function() {
            Volt.log("[VoltApiWrapper.js] initSSOAccountInfo");
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return;
            }
            
            if (wrapperSelf.getSSOLoginState() == false) {
                Volt.log("[VoltApiWrapper.js] SSO log out!!!!");
                Utils.Account.initSSOAccoutInfo(false);
            } else {
                var accountInfo = wrapperSelf.getSSOLoginInfo();
                if (CommonFucntion.checkValid(accountInfo)) {
                    Volt.log("[sso-accoutinfo.js] initSSOAccoutInfo:" + accountInfo.login_id + " " + accountInfo.user_icon);
                    Utils.Account.initSSOAccoutInfo(true, accountInfo.login_id, accountInfo.user_icon);
                }
            }
        },

        ssoStateChangeCallBack : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[VoltApiWrapper.js] ssoStateChangeCallBack()" + data1.login_state + " " + data1.account + " " + data1.user_icon);
            Utils.Account.updateAccountInfo(data1);
        },

        getGameTermStatus : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.getSSOTermStatus("user_game_tc");
            Volt.log("[VoltApiWrapper.js] getGameTermStatus, ret = " + ret);
            return ret;
        },

		showGameTermsPopup: function(){
			if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.showSSOPopup("GameTerms&callerId=org.volt.games");
            return ret;
        },
        
        //memory info
        getMemory : function() {
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return "";
            }
            var ret = voltapi.WAS.getMemory();
            Volt.log("[VoltApiWrapper.js] getMemory = " + ret);
            //need refine
            if ( typeof ret == 'string') {
                return ret;
            } else {
                return " ";
            }
        },

        getStoragePercent : function(){//temp use should refine
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var obj = wrapperSelf.getMemoryObject({
                usedUnit : 'B',
                totalUnit : 'B'
            });
            if(obj){
                var used = obj.used;
                var total = obj.total;
                Volt.log("[VoltApiWrapper.js] getStoragePercent is " + used / total);
                return used / total;
            }
            return 0;
        },

        getFreeSize : function(unit){ //return with unit: MB
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var obj = wrapperSelf.getMemoryObject({
                freeUnit : 'MB'
            });
            if(obj){
                var free = obj.free;
                Volt.log("[VoltApiWrapper.js] getFreeSize is " + free + 'MB');
                return free;
            }
            return -1;
        },

        getMemoryObject : function(unitObj){
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var memoryObject = null;
            var ret = wrapperSelf.getMemory();
            //ret is like this type : "12.01MB / 2.59GB"
            if(typeof ret == 'string'){
                var nIndex = ret.indexOf('/');
                var nlength = ret.length;
                Volt.log("[VoltApiWrapper.js] nIndex is " + nIndex + " nlength is " + nlength);
                if(nIndex != -1){
                    memoryObject = {};
                    var used = memoryObject.used = ret.substring(0, nIndex - 3);
                    var usedUnit = memoryObject.usedUnit = ret.substring(nIndex - 3, nIndex - 1);
                    var total = memoryObject.total = ret.substring(nIndex + 2, nlength - 2);
                    var totalUnit = memoryObject.totalUnit = ret.substring(nlength - 2);
                    if(usedUnit == 'MB'){
                        used = parseFloat(used) * 1024;
                    }else if(usedUnit == 'GB'){
                        used = parseFloat(used) * 1024 * 1024;
                    }
                    if(totalUnit == 'MB'){
                        total = total * 1024;
                    }else if(totalUnit == 'GB'){
                        total = total * 1024 * 1024;
                    }
                    var free = total - used;
                    if(unitObj){
                        if(unitObj.usedUnit && unitObj.usedUnit == 'B'){ // only support 'B', if not set unit or set other unit return default unit
                            memoryObject.used = used;
                            memoryObject.usedUnit = 'B';
                        }
                        if(unitObj.totalUnit && unitObj.totalUnit == 'B'){ // only support 'B', if not set unit or set other unit return default unit
                            memoryObject.total = total;
                            memoryObject.totalUnit = 'B';
                        }
                        if(unitObj.freeUnit){ // only support 'MB', 'default', if not set unit or set other unit, do not return free
                            if(unitObj.freeUnit == 'MB'){
                                memoryObject.free = free / 1024;
                                memoryObject.freeUnit = 'MB';
                            }else if(unitObj.freeUnit == 'default'){
                                var tempUnit = wrapperSelf.setSuitablyUnit(free);
                                memoryObject.free = tempUnit.size;
                                memoryObject.freeUnit = tempUnit.unit;
                            }
                        }
                    }
                }
            }
            Volt.log("[VoltApiWrapper.js] getMemoryObject = " + JSON.stringify(memoryObject));
            return memoryObject;
        },
        
        setSuitablyUnit : function(size) {//the unit of size is B
            var COUNTMB = 1024;
            var COUNTGB = 1024 * 1024;
            var unit = 'B';
            if(size >= COUNTGB){
                size /= COUNTGB;
                unit = 'GB';
            }else if(size >= COUNTMB){
                size /= COUNTMB;
                unit = 'MB';
            }
            size = parseFloat(size).toFixed(2);
            return {
                size : size,
                unit : unit
            };
        },
        
        IsStorageEnough : function(app_size) {//need refine
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var bRet = true;
			var freeSize = wrapperSelf.getFreeSize();
			
			if(freeSize != -1){
				if(parseFloat(app_size) >= freeSize) {
					bRet = false;
				}
			}
			Volt.log("[VoltApiWrapper.js] IsStorageEnough return: " + bRet);
            return bRet;
        },

        //network status
        GetDebugInfo : function() {
        	Volt.log('[VoltApiWrapper.js] GetDebugInfo .....');
            
            if (!bWasInitStatus) {
                Volt.log("[VoltApiWrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var odebugInfo = voltapi.WAS.getDebugInfo();
            return odebugInfo;
        },
  
        getUsbStorages : function() {
        	if(!voltapi.ContentsMgr.isOpened()){
            	Volt.log('voltapi.ContentsMgr is not opened');
                return;
        	}
            
            var bFlg = voltapi.ContentsMgr.connect();
            //var bFlg2 = voltapi.ContentsMgr.disconnect();
            Volt.log("[VoltApiWrapper.js] bFlg: " + bFlg);
            if (bFlg) {
                var UsbInfo = voltapi.ContentsMgr.getStorages();
                Volt.log("[VoltApiWrapper.js] getUsbStorages: " + JSON.stringify(UsbInfo));
                return UsbInfo;
            }
                
            return;
        }
    };

})();
