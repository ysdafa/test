var CommonDefine = Volt.require('app/common/common-define.js');

var CommonFucntion = {
    checkValid : function(value) {
        if (value != null && value != undefined) {
            return true;
        } else {
            return false;
        }
    },

    createProgressControl : function(widget, xValue, yValue, width, height){
        var progress = new Progress({
            parent : widget,
            width : width,
            height : height,
            x : xValue,
            y : yValue,
            direction: "horizontal",
            minValue : 0,
            value : 0,
            maxValue : width,
            color: Volt.hexToRgb('#ffffff', 20),
            progressColor: Volt.hexToRgb('#ffffff', 60)
        });
        progress.show();
        return progress;
    },

    checkMemory : function() {
        if (CommonDefine.Const.VD_MEMORY) {
            var memory = VDUtil.getProcMemory();
            print(memory);
        }
    },

    gcMemory : function() {
        if (CommonDefine.Const.VD_MEMORY) {
            var memory = VDUtil.getProcMemory();
            print(memory);
        }
    },
};

exports = CommonFucntion;