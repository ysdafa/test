
var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._;

EventMediator = _.extend({}, Backbone.Events);

exports = EventMediator;