var CommonDefine     = Volt.require('app/common/common-define.js');
var Backbone         = Volt.require('lib/volt-backbone.js');
var RouterController = Volt.require('app/controller/router-controller.js');
var Mediator         = Volt.require('app/common/event-mediator.js');
var Utils            = Volt.require('app/common/utils.js');

var ErrorHandling = {
    initialize : function() {
    },

    showMessage : function(messageId, app_id, errorCode) {
    	this.destroyWidgetPopup();
		var bNeedDelay = this.destroyNavigatePopup();
		if(bNeedDelay) {
			print('[Error-Handling.js] bNeedDelay == true');
			var ErrorSelf = this;
			Volt.setTimeout(function() {
				ErrorSelf.showMessagePopupView(messageId, app_id, errorCode);
    		}, 200);

		} else {
			print('[Error-Handling.js] bNeedDelay == false');
			this.showMessagePopupView(messageId, app_id, errorCode);
		}
    },

	showMessagePopupView : function(messageId, app_id, errorCode) {
		print('[Error-Handling.js] showMessagePopupView');
		switch(messageId) {
			case CommonDefine.MsgBoxType.MSGBOX_TYPE_REQUIRE_NETWORK:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_REQUIRE_NETWORK,
					style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK'),
					button            : true,
					button_1_Text     : Volt.i18n.t('COM_SID_OK'),
					contextLineNumber : 1,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;
			case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR,
					style             : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>',errorCode),
					button            : true,
					button_1_Text     : "Troubleshoot",
					button_2_Text     : Volt.i18n.t('COM_SID_CANCEL'),
					contextLineNumber : 1,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR:
                var param = {
                    type             : CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR,
                    style            : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle      : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle          : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText      : Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>',errorCode),
                    button           : true,
                    button_1_Text    : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber: 1,
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE:
                var param = {
                    type             : CommonDefine.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE,
                    style            : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle      : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle          : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText      : "This function is unavailable because the App failed to sync. Please try again later.",
                    button           : true,
                    button_1_Text    : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber: 1,
                    appID            : app_id,
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
               	//var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK:
                var param = {
                    type          : CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK,
                    style         : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_1LINE,
                    buttonStyle   : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle       : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_DELETE_SELECTED_ITEMS_QUES'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                 	defaultFocus  : "button_2",
                    appID         : app_id,
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
				var param = {
					type          : CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED,
					style         : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
					buttonStyle   : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle       : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText   : Volt.i18n.t('TV_SID_MUST_SIGN_SAMSUNG_ACCOUNT_SIGN_IN'),
					button        : true,
					button_1_Text : Volt.i18n.t('SID_YES'),
					button_2_Text : Volt.i18n.t('SID_NO'),
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,
					style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : Volt.i18n.t('TV_SID_DELETED_SUCCESSFULLY'),
					button            : true,
					contextLineNumber : 1,
					button_1_Text     : Volt.i18n.t('COM_SID_OK'),
					appID             : app_id,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;
			
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_FAIL:
                var param = {
                    type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_FAIL,
                    style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText       : "Delete failed.",
                    button            : true,
                    contextLineNumber : 1,
                    button_1_Text     : Volt.i18n.t('COM_SID_OK'),
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FAIL:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FAIL,
					style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : "The function is currently unavailable." + "(" + errorCode + ")",
					button            : true,
					button_1_Text     : Volt.i18n.t('COM_SID_OK'),
					contextLineNumber : 1,
					appID             : app_id,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE,
					style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : Volt.i18n.t('COM_SID_DOWNLOADGAME_BEFORE_CAN_RATE_IT'),
					button            : true,
					contextLineNumber : 1,
					button_1_Text     : Volt.i18n.t('COM_SID_OK'),
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FACEBOOK:
                var param = {
                    type          : CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FACEBOOK,
                    style         : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle   : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle       : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText   : Volt.i18n.t('TV_SID_MIX_INSTALLED_INSTALL_IT').replace('<<A>>','Facebook'),
                    button        : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                    appID         : '11091000000',
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_YOUTUBE:
                var param = {
                    type           : CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_YOUTUBE,
                    style          : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle    : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle        : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText    : Volt.i18n.t('TV_SID_VIDEO_YOUTUBE_APP_INSTALL'),
                    button         : true,
                    button_1_Text  : Volt.i18n.t('SID_YES'),
                    button_2_Text  : Volt.i18n.t('SID_NO'),
                    appID          : '111299001912',

                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_GAME_CENTER:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_GAME_CENTER,
					style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : "Game Center : 0.0.1 - 2014-0811",
					button            : true,
					button_1_Text     : Volt.i18n.t('COM_SID_OK'),
					contextLineNumber : 1,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_UPDATE_NEW_VERSION:
				var param = {
					type          : CommonDefine.MsgBoxType.MSGBOX_TYPE_UPDATE_NEW_VERSION,
					style         : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
					buttonStyle   : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle       : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText   : Volt.i18n.t('TV_SID_A_NEW_VERSION_GAME_AVAILABLE_INSTALL'),
					button        : true,
					button_1_Text : Volt.i18n.t('SID_YES'), //update to new version
					button_2_Text : Volt.i18n.t('SID_NO'), //launch the games(old version)
					appID         : app_id,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_COUPON:
                var param = {
                    type          : CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_COUPON,
                    style         : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle   : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle       : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText   : Volt.i18n.t('TV_SID_MUST_SIGN_SAMSUNG_ACCOUNT_SIGN_IN'),
                    button        : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_MESSAGE:
                var param = {
                    type          : CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_MESSAGE,
                    style         : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle   : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle       : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText   : Volt.i18n.t('TV_SID_MUST_SIGN_SAMSUNG_ACCOUNT_SIGN_IN'),
                    button        : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_EXPIRED:
                var param = {
                    type           : CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_EXPIRED,
                    style          : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle    : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle        : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText    : Volt.i18n.t('TV_SID_THIS_COUPON_HAS_EXPIRED'),
                    button         : true,
                    button_1_Text  : Volt.i18n.t('COM_SID_DELETE'),
                    button_2_Text  : Volt.i18n.t('COM_SID_CLOSE'),
                    focusIndex     : 2,
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                    trigger : true
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_USED:
				var param = {
					type           : CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_USED,
					style          : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
					buttonStyle    : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle        : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText    : Volt.i18n.t('TV_SID_THIS_COUPON_HAS_ALREADY_BEEN_USED'),
					button         : true,
					button_1_Text  : Volt.i18n.t('COM_SID_DELETE'),
					button_2_Text  : Volt.i18n.t('COM_SID_CLOSE'),
					focusIndex     : 2,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				//var fbMsg = new message_Box(param); /**** switch to halo component****/
				break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_COUPON:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_COUPON,
					style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : Volt.i18n.t('TV_SID_COUPON_REGISTRATION_FAILED_PLEASE_TRY_AGAIN_LATER'),
					button            : true,
					button_1_Text     : Volt.i18n.t('COM_SID_OK'),
					contextLineNumber : 1,
					focusIndex        : 1,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				break;

			case CommonDefine.MsgBoxType.MSGBOX_TYPE_INVALID_COUPON:
				var param = {
					type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_INVALID_COUPON,
					style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
					buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
					bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
					contentText       : Volt.i18n.t('TV_SID_INVALID_COUPON_PLEASE_CHECK_THE_COUPON_AND_TRY_AGAIN'),
					button            : true,
					button_1_Text     : Volt.i18n.t('COM_SID_OK'),
					contextLineNumber : 1,
					focusIndex        : 1,
				};
				Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
					trigger : true
				});
				break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_NICKNAME:
                var param = {
                        type              : CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_NICKNAME,
                        style             : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                        buttonStyle       : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                        bgStyle           : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                        contentText       : errorCode,
                        button            : true,
                        button_1_Text     : Volt.i18n.t('COM_SID_OK'),
                        contextLineNumber : 1,
                        focusIndex        : 1,
                };
                Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                        trigger : true
                });
                break;
            case CommonDefine.Magic.SHOW_VERSION :
                var CommonContent = Volt.require('app/common/common-content.js');
                CommonContent.getConfigXML().then(function(configXML){
                    var param = {
                        style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                        buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                        bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                        contentText : configXML.widget.ver,
                        button : true,
                        button_1_Text : Volt.i18n.t('COM_SID_OK'),
                        contextLineNumber : 1,
                        focusIndex : 1,
                    };
                    Backbone.history.navigate('msgpopup/' + JSON.stringify(param), {
                        trigger : true
                    });
                });
                break;
			default:
				print('message-id:::' + messageId);
				break;
		}
	},

	destroyWidgetPopup : function() {//destroy all widget type popups
		Mediator.trigger(CommonDefine.Event.DESTORY_OPTION_MENU);
	},

	destroyNavigatePopup : function(){
		print('[Error-Handling.js] destroyNavigatePopup' + RouterController.getCurrentView().type);
		if(RouterController.getCurrentView().type == 4) {
			print('[Error-Handling.js] destroyNavigatePopup, back first');
			Utils.Timer.clearTimeOut();
			Backbone.history.back();
			return true;
		}
		return false;
	},
};

exports = ErrorHandling;

