// Require Common Modules
var Backbone       = Volt.require('lib/volt-backbone.js');
var PanelCommon    = Volt.require('lib/panel-common.js');
var CommonDefine   = Volt.require('app/common/common-define.js');
var voltApiWrapper = Volt.require("app/common/voltapi-wrapper.js");
var Mediator       = Volt.require('app/common/event-mediator.js');
var Utils          = Volt.require('app/common/utils.js');

var CommonContent  = Volt.require('app/common/common-content.js');
var voltapi        = Volt.require('modules/voltapi.js');
var GamesMainTemplate  = Volt.require('app/templates/1080/main-template.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');
var DeviceModel = Volt.require('app/models/device-model.js');

var HeaderView = PanelCommon.BaseView.extend({
    isSigned : false,
    closeIcon : null,
    btnListener : new ButtonListener(),
    loginBtn : null,
    settingBtn :null,
    closeBtn : null,
    iconWidget : null,
    userIconImg :null,
  
	initialize : function(parent) {
		this.parent = parent;
		Mediator.on('EVENT_DESTROY_MULTI_SELECTION', this.showHeader, this);
		Mediator.on('EVENT_MAIN_CATEGORY_HIDE', this.shrinkHeader, this);
		Mediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink, this);
		Mediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand, this);
		Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE, this.updateUserIcon, this);
		Mediator.on(CommonDefine.Event.SIGN_STATE_UPDATE, this.updateUserIcon, this);
		var that = this;
		this.btnListener.onButtonClicked = function(button, type) {
		    Volt.log("[main-header-view.js] onButtonClicked = " + button.id);
			switch(button.id) {
				case 'login-icon':
					that.onSelectLogin();
					break;
				case 'main-header-icon-setting-image':
					button.setBackgroundImage({state:"all",src:""});
					that.onSelectSetting();
					break;
				case 'main-header-icon-close-image':
					Mediator.trigger(CommonDefine.Event.GAMES_EXIT);
					Volt.exit();
					break;
				default :
					break;
			}
		};
	},

    render : function() {
        print('[main-header-view.js] HeaderView.render');
        var that = this;
        this.widget = CommonContent.loadTemplateInWinsetBackgroud(GamesMainTemplate.header, null, this.parent).getChild(0);
		this.loginBtn = new Button(GamesMainTemplate.loginBtn);
		this.loginBtn.parent = this.widget.getDescendant('main-header-icon-login');
		this.settingBtn = new Button(GamesMainTemplate.settingBtn);
		this.settingBtn.parent =this.widget.getDescendant('main-header-icon-setting');
		this.closeBtn = new Button(GamesMainTemplate.closeBtn);
		this.closeBtn.parent =this.widget.getDescendant('main-header-icon-close');
		
		this.loginBtn.setBackgroundImage({state:"focused",src:"images/1080/highlight/ksc_focus.png"});
		this.settingBtn.setBackgroundImage({state:"focused",src:"images/1080/highlight/ksc_focus.png"});
		this.closeBtn.setBackgroundImage({state:"focused",src:"images/1080/highlight/ksc_focus.png"});
		
		this.loginBtn.setBackgroundImage({state:"focused-roll-over",src:"images/1080/highlight/ksc_focus.png"});
		this.settingBtn.setBackgroundImage({state:"focused-roll-over",src:"images/1080/highlight/ksc_focus.png"});
		this.closeBtn.setBackgroundImage({state:"focused-roll-over",src:"images/1080/highlight/ksc_focus.png"});
		
		this.loginBtn.setIconAlpha({state:"normal",alpha:153});
		this.settingBtn.setIconAlpha({state:"normal",alpha:153});
		this.closeBtn.setIconAlpha({state:"normal",alpha:153});
		
		this.loginBtn.setIconAlpha({state:"focused",alpha:255});
		this.settingBtn.setIconAlpha({state:"focused",alpha:255});
		this.closeBtn.setIconAlpha({state:"focused",alpha:255});
		
		this.loginBtn.setIconAlpha({state:"focused-roll-over",alpha:255});
		this.settingBtn.setIconAlpha({state:"focused-roll-over",alpha:255});
		this.closeBtn.setIconAlpha({state:"focused-roll-over",alpha:255});
		
        this.loginBtn.addListener(that.btnListener);
        this.settingBtn.addListener(that.btnListener);
        this.closeBtn.addListener(that.btnListener);
        this.updateUserIcon();
        this.setWidget(this.widget);
        this.closeIcon = this.widget.getDescendant('main-header-icon-close');
        return this;
    },
    
    updateUserIcon : function() {
        Volt.log('[main-header-view.js] updateUserIcon');
        var loginIcon = this.widget.getDescendant('login-icon');
        //var signState = voltApiWrapper.getSSOLoginState();
        var signState = Utils.Account.getSignState();
        Volt.log('[main-header-view.js] signState = ' + signState);
        
        if (signState) {
            //login in
            var accountInfo = voltApiWrapper.getSSOLoginInfo();
            var path = accountInfo.user_icon;
            Volt.log('[main-header-view.js] path.length = ' + path.length);
            if (path.length > 0) {
                var account_list = JSON.parse(path);
                Volt.log('path:::' + account_list);
                var bFound = false;
                for (var i = 0; i < account_list.length; i++) {
                    if (account_list[i].hasOwnProperty('iconPath_60')) {
                        var userThumbnail = account_list[i].iconPath_60;
                        Volt.log('iconPath_60:::' + userThumbnail);
                        if (userThumbnail && userThumbnail.length > 0) {
                            bFound = true;
                            /*
                             loginIcon.setIconImage({
                             state : "all",
                             src : Volt.getAbsolutePath(userThumbnail)
                             });
                             */
                            if (this.iconWidget && this.userIconImg) {
                                this.iconWidget.show();
                                this.userIconImg.show();
                            } else {
                                this.iconWidget = new WidgetEx({
                                    parent : loginIcon,
                                    x : 20,
                                    y : 42,
                                    width : 60,
                                    height : 60,
                                    cropOverflow : true,
                                    roundedCorners : {
                                        radius : 30.0,
                                        arcStep : 0.1
                                    },
                                });
                                this.userIconImg = new ImageWidgetEx({
                                    parent : this.iconWidget,
                                    x : 0,
                                    y : 0,
                                    width : 60,
                                    height : 60,
                                    src : Volt.getAbsolutePath(userThumbnail)
                                });
                            }
                        }
                        break;
                    }
                }

                if (!bFound) {
                    //login in but no iconPath_70 property
                    Volt.log('[main-header-view.js] no iconPath_60 property');
                    loginIcon.setIconImage({
                        state : "all",
                        src : Volt.getRemoteUrl('images/1080/dummy/id_image_01.png')
                    });
                }
            } else {
                //login in but path.length == 0
                Volt.log('[main-header-view.js] login in but path.length is 0');
                loginIcon.setIconImage({
                    state : "all",
                    src : Volt.getRemoteUrl('images/1080/dummy/id_image_01.png')
                });
            }
        } else {
            //login out
            if (this.iconWidget && this.userIconImg) {
                this.userIconImg.destroy();
                this.iconWidget.destroy();
                this.userIconImg = null;
                this.iconWidget = null;
            }

            loginIcon.setIconImage({
                state : "all",
                src : Volt.getRemoteUrl('images/1080/common/g_state_logout.png')
            });
        }

    },

    onChangeCursor : function(visible) {
        Volt.log("[main-header-view.js]visible is " + visible);
        if (this.closeIcon) {
            if (visible) {
                this.closeIcon.show();
				this.widget.getDescendant('main-header-icon-login').x = 1;
				this.widget.getDescendant('main-header-icon-setting').x = 101;
				this.widget.getDescendant('main-header-line').opacity = 25;
            } else {
                this.closeIcon.hide();
				this.widget.getDescendant('main-header-icon-login').x = 101;
				this.widget.getDescendant('main-header-icon-setting').x = 201;
				this.widget.getDescendant('main-header-line').opacity = 0;
            }
        }
    },
    	
    events : {
     //   'NAV_SELECT #main-header-icon-login' : 'onSelectLogin',
     //   'NAV_SELECT #main-header-icon-setting' : 'onSelectSetting',
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },
    
    onFocus : function(widget) {
        Volt.log('[main-header-view.js] HeaderView.focus ' + widget.id);
		
        if (widget && widget.id) {
            Volt.log("[main-header-view.js] focused :" + widget.id);
			if(widget.id == 'main-header-icon-setting') {
				this.settingBtn.setIconImage({state:"all",src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_setting_sel.png')});
				this.settingBtn.setFocus();
				var AbsolutePosition = this.settingBtn.getAbsolutePosition();
				var opt = {
					text: Volt.i18n.t('UID_OPTIONS'),
					x: AbsolutePosition.x,
					y: AbsolutePosition.y,
					height: this.settingBtn.height,
					width: this.settingBtn.width,
					direction:'up',
				};
				
				CommonContent.showToolTip(opt,GamesMainTemplate);
				VoiceGuide.getVoiceGuide('Options,button.',false);
			}
			if(widget.id == 'main-header-icon-login') {
				var AbsolutePosition = this.loginBtn.getAbsolutePosition();
				this.loginBtn.setFocus();
				var opt = {
					text: Volt.i18n.t('UID_SIGN_IN'),
					x: AbsolutePosition.x,
					y: 55,
					height: this.loginBtn.height,
					width: this.loginBtn.width,
					direction:'up',
				};

				//var signState = voltApiWrapper.getSSOLoginState();
                var signState = Utils.Account.getSignState();
				if (signState){
					opt.text = Volt.i18n.t('UID_SIGN_OUT');
				}

				CommonContent.showToolTip(opt,GamesMainTemplate);

				var voiceText = '';
				if(signState){
					voiceText = Volt.i18n.t('UID_SIGN_OUT');
				}else{
					voiceText = Volt.i18n.t('UID_SIGN_IN');
				}
				voiceText += ',button.';
				VoiceGuide.getVoiceGuide(voiceText,false);
			}
			
			if(widget.id == 'main-header-icon-close') {
				Volt.log('[main-header-view.js]main-header-icon-close button OnMouseOver');
	       //     this.onChangeCursor(true);
				var AbsolutePosition = this.closeIcon.getAbsolutePosition();
				var opt = {
						text: Volt.i18n.t('COM_SID_EXIT'),
						x: AbsolutePosition.x,
						y: AbsolutePosition.y,
						height: this.closeIcon.height,
						width: this.closeIcon.width,
						direction:'up',
					};
					
				CommonContent.showToolTip(opt,GamesMainTemplate);
				this.closeBtn.setIconImage({state:"all",src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_close_sel.png')});
				this.closeBtn.setFocus();
			}
        }
    },

    onBlur : function(widget) {
        if (widget) {
			
            print('[main-header-view.js] HeaderView.onBlur ' + widget.id);
			if(widget.id == 'main-header-icon-setting') {
				this.settingBtn.setIconImage({state:"all",src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_setting_nor.png')});
				CommonContent.hideToolTip();
			}
			if(widget.id == 'main-header-icon-login') {
				CommonContent.hideToolTip();
			}
			if(widget.id == 'main-header-icon-close') {
				Volt.log('[main-header-view.js]main-header-icon-close button OnMouseOut');
				/*
				var focusedWidget = Volt.Nav.getFocusedWidget();
				if(focusedWidget && focusedWidget.id != "main-header-icon-close"){
				    this.onChangeCursor(false);
				}
				*/
				CommonContent.hideToolTip();
				this.closeBtn.setIconImage({state:"all",src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_close_nor.png')});
			}
			//widget.opacity = 51;
			//widget.color = Volt.hexToRgb('#000000', 0);
        }
    },
    //show popup view example when click login button
    onSelectLogin : function() {
        Volt.log('[main-header-view.js] HeaderView.onSelectLogin');
        //Backbone.history.navigate('popup/list-thumbnail' , {trigger: true });
        //add event log
		this.addEventLog('JUMPSSO',{cp : '',ssoby: 'header',inputby:'',});
        voltApiWrapper.startSSOPopup();
    },

    //show msgbox example when click plus button
    onSelectSetting : function() {
        Volt.log('[main-header-view.js] HeaderView.onSelectSetting');
		CommonContent.hideToolTip();
		//add event log
		this.addEventLog('OPTIONCLICK',{cp : '',inputby:'',});
        Mediator.trigger(CommonDefine.Event.OPTION_MENU_POPUP);
    },

    expand : function() {
        Volt.log('[main-header-view.js] HeaderView.expand');
        this.widget.animate('y', 0, CommonDefine.Const.MENU_ANIM_DURATION);
    },

    shrink : function() {
        Volt.log('[main-header-view.js] HeaderView.shrink');

        this.widget.animate('y', -18, CommonDefine.Const.MENU_ANIM_DURATION);
    },
    shrinkHeader : function() {
    	Volt.log('[main-header-view.js] shrinkHeader');
        Mediator.off('EVENT_MAIN_CATEGORY_FOCUS', null, this);
        Mediator.off('EVENT_MAIN_CATEGORY_BLUR', null, this);
        Mediator.on('EVENT_MULTI_SELECTION_FOCUS', this.shrink, this);
        Mediator.on('EVENT_MULTI_SELECTION_BLUR', this.expand, this);
        this.loginBtn.enable(false);
        this.settingBtn.enable(false);
        this.closeBtn.enable(false);
        this.widget.getDescendant('main-header-icon-login').focusable = false;
        this.widget.getDescendant('main-header-icon-setting').focusable = false;
        this.widget.getDescendant('main-header-icon-close').focusable = false;
        this.widget.getDescendant('main-header-dim').color = { r: 0, g: 0, b: 0, a: 153 };
        Volt.Nav.reload();
    },
    showHeader : function() {
        this.loginBtn.enable(true);
        this.settingBtn.enable(true);
        this.closeBtn.enable(true);
        this.widget.getDescendant('main-header-icon-login').focusable = true;
        this.widget.getDescendant('main-header-icon-setting').focusable = true;
        this.widget.getDescendant('main-header-icon-close').focusable = true;
        Mediator.off('EVENT_MULTI_SELECTION_FOCUS', null, this);
        Mediator.off('EVENT_MULTI_SELECTION_BLUR', null, this);
        Mediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink, this);
        Mediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand, this);
        this.widget.getDescendant('main-header-dim').color = { r: 0, g: 0, b: 0, a: 0 };
        Volt.Nav.reload();
        Volt.Nav.focus(this.widget.getDescendant('main-header-icon-setting'));
    },

	addEventLog : function(eventName,options){
		Volt.log('[main-header-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
		Volt.KPIMapper.addEventLog(eventName, {d : options});
	},
	
	show : function() {
	    this.loginBtn.enable(true);
        this.settingBtn.enable(true);
        this.closeBtn.enable(true);
        this.onChangeCursor(DeviceModel.get('visibleCursor'));
        Mediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor, this);
	},
	
	hide : function() {
	    this.loginBtn.enable(false);
        this.settingBtn.enable(false);
        this.closeBtn.enable(false);
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, null, this);
	}
	
});

exports = HeaderView; 