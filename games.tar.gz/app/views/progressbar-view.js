var Backbone = Volt.require('lib/volt-backbone.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var BaseView = Volt.BaseView;
var Q = Volt.require('modules/q.js');
var EventMediator = Volt.require('app/common/event-mediator.js');
var CommonDefine = Volt.require('app/common/common-define.js');

var ProgressBar = Volt.require("modules/UIElement/Progress.js");

var ProgressBarView = PanelCommon.BaseView.extend({
    progressBar:null,
    options:null,
    needUpdate:false,
    timer:-1,

    show : function(params) {
        print("progressbar-view.js params =" + params);
        this.options = params;
        this.progressBar = new ProgressBar();
        this.progressBar.create({
            x: this.options.x, 
            y: this.options.y, 
            width: this.options.width, 
            height: this.options.height, 
            parent: this.options.parent,
            stepNumber:this.options.totalNum,
            currentStep : this.options.currentStep,
            processedColor : {r:255,g:255,b:255},
            unprocessColor : {r:255,g:255,b:255,a:51},
            readOnly:true,
            sliderDialWidth : 20,
            sliderDialHeight : 2,
            sliderDialSrc : "modules/UIElement/progress/popup_progress_dial_1_n.png",
            /*
            sliderDialSrc : "modules/UIElement/progress/popup_progress_dial_1_n.png",
            textBGColor:{r:0,g:0,b:0,a:0},
            textFont : "Samsung SVD_Light 24px",
            textColor : {r:255,g:255,b:255,a:255},
            balloonTailSrc : "modules/UIElement/progress/popup_balloon_tail_d.png",
            balloonWidth : 100,
            balloonHeight : 0,
            balloonGapSize : 0,
            */
        });
        this.needUpdate = this.options.needUpdate;
        var progress = 0;
        if(this.needUpdate){
            if(this.progressBar.currentStep < this.progressBar.stepNumber){
                this.timer = Volt.setInterval(function(){
                    progress += 1;
                    this.progressBar.setProgress(progress);
                    if(this.progressBar.currentStep == this.progressBar.stepNumber){
                        this.update();
                    }
                }.bind(this),1000 * 1);
            }
        }
    },
    
    update:function() {
        print("progressbar-view.js update");
        if (this.timer != -1) {
            Volt.clearInterval(this.timer);
        }
        EventMediator.trigger(CommonDefine.Event.EVENT_CLOSE_POPUP);
    },

    hide : function() {
        print("[progressbar-view.js] destroy");
        var deferred = Q.defer();
        if (this.progressBar) {
            this.progressBar.hide();
            this.progressBar.destroy();
            this.progressBar = null;
        }
        deferred.resolve();
        return deferred.promise;
    }
});
exports = new ProgressBarView();