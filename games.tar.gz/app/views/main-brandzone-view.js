var PanelCommon = Volt.require('lib/panel-common.js');
var GamesMainTemplate=Volt.require("app/templates/1080/main-template.js");
var MainCategoryModel = Volt.require("app/models/main-category-model.js");
var CommonContent = Volt.require('app/common/common-content.js');
var CommonFunction = Volt.require('app/common/common-function.js');
var Backbone    = Volt.require('lib/volt-backbone.js');
var Mediator = Volt.require('app/common/event-mediator.js');
var NoContentView = Volt.require('app/views/no-content-view.js');
var CommonDefine = Volt.require('app/common/common-define.js');
var BrandZoneView = PanelCommon.BaseView.extend({
	parent : null,
	contentWgt : null,
	viewType : 'brandzone',
	
	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur'
	},

    initialize: function() {

    },

    render: function(parentWidget) {
        print('brandzone view render');
        this.parent = parentWidget.widget.getChild('main-content-container');
        if(MainCategoryModel.isReady()){
           this.renderContent();
        }
        else{
            var brandzoneModel = MainCategoryModel.get('brandzone');
        }
        
        return this;
    },

	renderContent : function() {
		var brandzoneModel = MainCategoryModel.get('brandzone');
		if (brandzoneModel.get('brandzone_list_cnt') == '0') {
			var noContentWgtId = this.viewType;
			var textToShow = Volt.i18n.t('COM_NO_CONTENT_FOUND');
			this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;

		} else {
			/*load data*/
		}
		this.setWidget(this.contentWgt);
		this.parent.addChild(this.contentWgt);
		Volt.Nav.reload();
	},

	remove : function() {
		if (this.contentWgt) {
			this.parent.removeChild(this.contentWgt);
			this.contentWgt.destroy();
			this.contentWgt = null;
		}
	},

	onFocus : function(widget) {
		print('[main-brandzone-view.js] ContentView.onFocus');
		if (widget && widget.id) {
			print('[main-brandzone-view.js] onFocus widget.id =' + widget.id);
			Backbone.history.setCache(widget.id);
		}
	},

	onBlur : function(widget) {

	},

	show : function(param, animationType) {

		if (this.contentWgt) {
			this.contentWgt.show();
			if (!(this.widget.hasOwnProperty('id') && this.widget.id == this.viewType)) {
				this.widget.focusable = true;
			}
		}
		Volt.Nav.reload();
	},

	hide : function(animationType) {
		if (this.contentWgt) {
			this.contentWgt.hide();
			if (!(this.widget.hasOwnProperty('id') && this.widget.id == this.viewType)) {
				this.widget.focusable = false;
			}
		}
	},

	getWidget : function() {

	},
});

exports = BrandZoneView;
