// Include libraries
var Q            = Volt.require('modules/q.js');
var Backbone     = Volt.require('lib/volt-backbone.js');
var CommonDefine = Volt.require('app/common/common-define.js');
var PanelCommon  = Volt.require('lib/panel-common.js');
var Mediator     = Volt.require('app/common/event-mediator.js');
var voltapi      = Volt.require('modules/voltapi.js');
var Gridlist     = Volt.require('app/views/grid-list-view.js');
var MessageTemplate    = Volt.require('app/templates/1080/message-template.js');
var GridlistTemplate   = Volt.require('app/templates/1080/grid-list-template.js');
var messagesCollection = Volt.require('app/models/messages-collection.js');
////////////////////////////////////////////////////////////////////////////////
var MessageBoxView = PanelCommon.BaseView.extend({
    template : MessageTemplate.container,
    self : null,
    contentView : null,

    initialize : function() {
        self = this;
    },

    render : function() {
        print('[message-box-view.js] MessageBoxView.render');
    },

    renderHeader : function() {
        print('[message-box-view.js] renderHeaderIcon');
        var container = this.widget.getDescendant('message-header-container');
        this.headerView = new HeaderView().render();
        container.addChild(this.headerView.widget);
    },

    renderContent : function() {
        print('[message-box-view.js] renderContent');
        print('[coupon-box-view.js] renderContent messagesCollection.length ====' + messagesCollection.length);
        if (messagesCollection.length > 0) {
            var container = this.widget.getChild('message-content-container');
            container.addChild(new ContentView().render(container).widget, 0);
            Volt.Nav.reload();
        }
    },

    show : function(param, animationType) {
        print('[message-box-view.js] show');
        Mediator.on(CommonDefine.Event.HIDE_TITLE, this.hideTitle, this);
        Mediator.on(CommonDefine.Event.SHOW_TITLE, this.showTitle, this);

        this.setWidget(PanelCommon.loadTemplate(this.template));

        this.renderHeader();
        this.renderContent();

        Volt.Nav.setRoot(this.widget);
        Volt.Nav.focus(Volt.Nav.getItem(1));

        this.widget.show();
    },

    hide : function(animationType) {
        print('[message-box-view.js] hide');
        var deferred = Q.defer();
        deferred.resolve();
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR,null,this);
        Mediator.off(CommonDefine.Event.HIDE_TITLE);
        Mediator.off(CommonDefine.Event.SHOW_TITLE);

        Volt.Nav.focus(null);
        this.destroy();
        this.widget.hide();
        this.widget.destroy();
        this.headerView.stopListening();

        return deferred.promise;
    },

    destroy : function() {
        if (!this.widget)
            return;
        var nChildLength = this.widget.getChildCount();
        for (var i = nChildLength - 1; i >= 0; i--) {
            var temp = this.widget.getChild(i);
            temp.destroy();
        }
    },

    hideTitle : function() {
        print("hideTitle~~~~")
        var headerWgt = this.widget.getDescendant('message-header-container');
        headerWgt.getChild(0).getChild(0).text = "";
        headerWgt.getChild(0).getChild(1).getChild(2).text = "Message Box";
        Volt.Nav.reload();
    },

    showTitle : function() {
        print("showTitle~~~~")
        var headerWgt = this.widget.getDescendant('message-header-container');
        headerWgt.getChild(0).getChild(0).text = "Message Box";
        headerWgt.getChild(0).getChild(1).getChild(2).text = "";
        Volt.Nav.reload();
    },

    pause : function() {
    }
});

var HeaderView = PanelCommon.BaseView.extend({
    template : MessageTemplate.header,
    pageBackArrow : null,

    initialize : function() {
        Mediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink, this);
        Mediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand, this);
    },

    render : function() {
        print('[message-box-view.js] HeaderView.render');
        if (!voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)) {
            print("hide pageBackArrow~~~");
            this.template.children[0].text = "Message Box";
            this.template.children[1].children[2].text = "";
        } else {
            this.template.children[0].text = "";
            this.template.children[1].children[2].text = "Message Box";
        }
        this.setWidget(CommonContent.loadTemplateInWinsetBackgroud(this.template));
        this.pageBackArrow = this.widget.getDescendant('message-box-back-icon-area');

        this.pageBackArrow.addEventListener('OnMouseOver', function() {
			this.pageBackArrow.getDescendant('message-box-back-icon').src =Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_sel.png');
			this.pageBackArrow.color = Volt.hexToRgb('#ffffff');
			this.pageBackArrow.opacity = 242;
        }.bind(this));
        this.pageBackArrow.addEventListener('OnMouseOut', function() {
            this.pageBackArrow.getDescendant('message-box-back-icon').src =Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_nor.png');
			this.pageBackArrow.color = {
					r:0,
					g:0,
					b:0,
					a:0,
				};
        }.bind(this));
        this.pageBackArrow.addEventListener('OnMouseClick', function() {
            Backbone.history.back();
        }.bind(this));

        if (!voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)) {
            print("hide pageBackArrow~~~");
            this.pageBackArrow.hide();
        }
        Mediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor, this);
        return this;
    },

    events : {
        'NAV_SELECT #message-header-icon-alarm' : 'onSelectAlarm',
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    stopListening : function() {
        Mediator.off('EVENT_MAIN_CATEGORY_FOCUS', null, this);
        Mediator.off('EVENT_MAIN_CATEGORY_BLUR', null, this);
    },

    onFocus : function(widget) {
        if(widget ){
            print('[message-box-view.js] HeaderView.focus ' + widget.id);
            if(widget.id == 'message-header-icon-alarm'){
                widget.getChild(0).src = Volt.getRemoteUrl('images/1080/common/g_icon_alarm_sel.png');
            }
            widget.color = Volt.hexToRgb('#ffffff');
            widget.opacity = 242;
        }
        //widget.opacity = 255;
        
    },

    onBlur : function(widget) {
        if(widget ){
            print('[message-box-view.js] HeaderView.onBlur ' + widget.id);
            if(widget.id == 'message-header-icon-alarm'){
                widget.getChild(0).src = Volt.getRemoteUrl('images/1080/common/g_icon_alarm_nor.png');
            }
            widget.opacity = 51;
            widget.color = Volt.hexToRgb('#0f1826');
        }
    },

    onSelectAlarm : function() {
        print('[message-box-view.js] HeaderView.onSelectAlarm');
    },

    expand : function() {
        print('[message-box-view.js] HeaderView.expand');
        this.widget.animate('y', 0, CommonDefine.Const.MENU_ANIM_DURATION);
    },

    shrink : function() {
        print('[message-box-view.js] HeaderView.shrink');
        this.widget.animate('y', -18, CommonDefine.Const.MENU_ANIM_DURATION);
    },

    onChangeCursor : function(visible) {
        print("visible is ", visible);

        if (this.pageBackArrow) {
            if (visible) {
                Mediator.trigger(CommonDefine.Event.HIDE_TITLE);
                this.pageBackArrow.show();
            } else {
                Mediator.trigger(CommonDefine.Event.SHOW_TITLE);
                this.pageBackArrow.hide();
            }
        }
    }
});

var ContentView = PanelCommon.BaseView.extend({
    initialize : function() {
        self.contentView = this;
    },

    render : function(parent) {
        print('[message-box-view.js] ContentView.render');
        if (!this.widget.created) {
            //this.setWidget(PanelCommon.loadTemplate(this.template,null,parent));
            var messageData = {
                style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
                groups : [{
                    modelArr : messagesCollection
                }]
            }

            var gridView = new Gridlist(GridlistTemplate.messageBox, JSON.stringify(messageData), 540, 468);

            gridView.setItemData = function(mustache, modelData) {
                mustache.imgUrl = modelData['imgUrl'];
                mustache.title = modelData['title'];
                mustache.date = modelData['date'];
                mustache.messageInfo = modelData['message'];
            }

            gridView.setItemTemplate = function(parent, parentWidth, parentHeight, data) {
                Volt.log("gridView  setTemplate");
                curTemplate = MessageTemplate.gridItem;
                PanelCommon.loadTemplate(curTemplate, data, parent);
                parent.color = {
                    r : parseInt(Math.random() * 255 + 1),
                    g : parseInt(Math.random() * 255 + 1),
                    b : parseInt(Math.random() * 255 + 1)
                };
            }
            gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
                //CommonContent.onLaunch('', itemData.app_id);
            }

            this.grid = gridView.render().widget;
            this.grid.focusable = true;
            this.setWidget(this.grid);
            this.widget.created = true;
        }

        return this;
    },

    events : {
        //'NAV_SELECT':'onSelect',
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onSelect : function() {
    },

    onFocus : function(widget) {
        print('[message-box-view.js] ContentView.onFocus');
        widget.onFocus();
    },

    onBlur : function(widget) {
        if (widget) {
            print('[message-box-view.js] ContentView.onBlur');
            widget.onBlur();
        }
    }
});

exports = MessageBoxView;

