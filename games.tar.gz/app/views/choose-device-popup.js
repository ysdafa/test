// Include libraries
var _                 = Volt.require("modules/underscore.js")._;
var Q                = Volt.require('modules/q.js');
var Backbone         = Volt.require('lib/volt-backbone.js');
var PanelCommon      = Volt.require('lib/panel-common.js');
var Singlelist       = Volt.require('app/views/singleline-list-view.js');
var Utils            = Volt.require('app/common/utils.js');
var CommonDefine     = Volt.require('app/common/common-define.js');
var Mediator    = Volt.require('app/common/event-mediator.js');
var voltApiWrapper   = Volt.require("app/common/voltapi-wrapper.js");
var CommonContent    = Volt.require('app/common/common-content.js');
var ChooseDevicesTemplate = Volt.require('app/templates/1080/choose-devices-popup.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');

var TempUsbStorages = new Array();
var chooseDevicePopupSelf = null;
var ChooseDevicePopup = PanelCommon.BaseView.extend({
    template : ChooseDevicesTemplate.container,
    wFocused : null, //current focus widget
    popupSelectedDeviceView : null,
    popupDevicesView : null,
    popupBtnView : null,
	param : null,
    render : function() {
    },
    
    getWidget : function() {
        return this.widget;
    },

    show : function(options) {
        Volt.log('[choose-device-popup.js] show ' + options);
		this.param = JSON.parse(options);
        this.setWidget(PanelCommon.loadTemplate(this.template));
        this.widget.parent = scene;
        this.widget.show();
        
        chooseDevicePopupSelf = this;

        this.renderSelectedDevice();
        this.renderDevices();
        this.renderButton();
        this.startListening();

        Volt.Nav.setRoot(this.widget);
        Volt.Nav.focus(Volt.Nav.getItem(0));
    },

    renderSelectedDevice : function() {
        var container = this.widget.getChild('selected-device-container');
        container.addChild(new selectedDeviceView().render().widget);
    },

    renderDevices : function() {
        Volt.log('[choose-device-popup.js] renderDevices');
        var container = this.widget.getChild('devices-container');
        container.addChild(new DevicesView().render(this, this.param.app_id, this.param.app_size, this.param.app_name).widget);
    },
    
    renderButton : function() {
        Volt.log('[choose-device-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        container.addChild(new buttonView().render().widget);
    },

    hide : function() {
        Volt.log('[choose-device-popup.js] hide');
        var deferred = Q.defer();
        this.stopListening();
        TempUsbStorages.length = 0;
		Utils.Timer.clearTimeOut();
		popupDevicesView.deviceList.enable(false);
        Volt.Nav.focus(null);

        if (this.widget) {
            this.widget.hide();

            Volt.setTimeout( function() {
                this.destroy(this.widget);
                this.widget.destroy();
            }.bind(this), 1);
        }

        deferred.resolve();
        return deferred.promise;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                this.destroy(widget.getChild(i));
            }
        }
    },
    
    startListening: function(){
//        Mediator.on(CommonDefine.Event.CONNECT_USB, function(){
//            Volt.log('[choose-device-popup.js] connect ' + arguments);
//            Volt.log('[choose-device-popup.js] connect ' + JSON.stringify(arguments));
//        });
//        Mediator.on(CommonDefine.Event.DISCONNECT_USB, function(){
//            Volt.log('[choose-device-popup.js] disconnect ' + arguments);
//            Volt.log('[choose-device-popup.js] disconnect ' + JSON.stringify(arguments));
//        });
    },
    
    stopListening: function(){
//        Mediator.off(CommonDefine.Event.CONNECT_USB);
//        Mediator.off(CommonDefine.Event.DISCONNECT_USB);
    }
});

//template of description area
var selectedDeviceView = PanelCommon.BaseView.extend({
    template : ChooseDevicesTemplate.selectedDevice,
    
    render : function() {
        popupSelectedDeviceView = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));

        this.updateInfo();
        return this;
    },
    
    updateInfo : function(params) {
        Volt.log('[choose-device-popup.js] selectedDeviceView updateInfo.....');

		if(params){
		    var deviceNameWidget = this.widget.getChild("device-name");
	        var memoryInfoWidget = this.widget.getChild("device-memory");
	        
	        deviceNameWidget.text = params.name;
	        memoryInfoWidget.text = params.availableSize + "/" +params.totalSize;
		}
    },
});

var DevicesView = PanelCommon.BaseView.extend({
    template : ChooseDevicesTemplate.chooseArea,
    deviceList : null,
    parentInst : null,
    render : function(self, app_id, app_size,app_name) {
        this.parentInst = self;
        popupDevicesView = this;
        this.widget = PanelCommon.loadTemplate(this.template);
        this.renderArrow();
        this.renderDeviceList(app_id, app_size,app_name);
        this.setWidget(this.widget);
        
        return this;
    },
    
    renderArrow : function(){
        var onNormal = function(){
            this.opacity = 255 * 0.5;
        };
        var onFocus = function(){
            this.opacity = 255;
        };
        var onDim = function(){
            this.opacity = 255 * 0.3;
        };
        this.upArrow = this.widget.getChild('choose-device-up-arrow');
        this.upArrow.onNormal = _.bind(onNormal, this.upArrow);
        this.upArrow.onFocus = _.bind(onFocus, this.upArrow);
        this.upArrow.onDim = _.bind(onDim, this.upArrow);
        this.downArrow = this.widget.getChild('choose-device-down-arrow');
        this.downArrow.onNormal = _.bind(onNormal, this.downArrow);
        this.downArrow.onFocus = _.bind(onFocus, this.downArrow);
        this.downArrow.onDim = _.bind(onDim, this.downArrow);
        
        this.upArrow.hide();
        this.downArrow.hide();
        
        this.upArrow.addEventListener('OnMouseClick', function() {
            this.deviceList.moveFocus("Up");
        }.bind(this));
        
        this.upArrow.addEventListener('OnMouseOver', function() {
            Volt.Nav.focus(this.deviceList);
            this.upArrow.onFocus();
        }.bind(this));
        
        this.upArrow.addEventListener('OnMouseOut', function() {
            this.upArrow.onNormal();
        }.bind(this));
        
        this.downArrow.addEventListener('OnMouseClick', function() {
            this.deviceList.moveFocus("Down");
        }.bind(this));
        
        this.downArrow.addEventListener('OnMouseOver', function() {
            Volt.Nav.focus(this.deviceList);
            this.downArrow.onFocus();
        }.bind(this));
        
        this.downArrow.addEventListener('OnMouseOut', function() {
            this.downArrow.onNormal();
        }.bind(this));
    },
    
    renderDeviceList : function(app_id,app_size,app_name){
        this.deviceList = initList(this.widget.getChild('choose-device-chooseArea'),app_size,app_name);
        this.deviceList.app_id = app_id;
        this.deviceList.app_size = app_size;
    },
    
    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    onFocus : function(widget) {
        Volt.log('[choose-device-popup.js] DevicesView.focus ');
        if (widget) {
            this.deviceList.enableFocus();
            this.deviceList.setFocus();
            this.deviceList.showFocus("false");
        }
    },

    onBlur : function(widget) {
        if (widget) {
            Volt.log('[choose-device-popup.js] DevicesView.onBlur ');
            this.deviceList.hideFocus("false");
            this.deviceList.killFocus();
        }
    },
});

//template of button area
var buttonView = PanelCommon.BaseView.extend({
    template : ChooseDevicesTemplate.button,
    btn1 : null,
	btnListener : new ButtonListener(),
    render : function(Parent) {
        Volt.log('[choose-device-popup.js] buttonView.render');
        popupBtnView = this;
        popupBtnView.btnListener.onButtonClicked = function(button,type){
        	popupBtnView.onSelectCancelButton();
        };
        var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
			buttonType : CommonDefine.Winset.BUTTON_TEXT,
		};
        this.setWidget(PanelCommon.loadTemplate(this.template,btnStyle));
        this.btn1 = this.widget.getDescendant('cancelBtn');
        this.btn1.addListener(popupBtnView.btnListener);
        return this;
    },

    events : {
        'NAV_FOCUS #Cancel' : 'onFocusCancelButton',
        'NAV_BLUR #Cancel' : 'onBlurCancelBtn',
    },

    onSelectCancelButton : function(widget) {
       Volt.log('[choose-device-popup.js] buttonView.onSelectCancelButton');
       Backbone.history.back();
       Utils.Timer.clearTimeOut();
    },

    onFocusCancelButton : function(widget) {
        Volt.log('[choose-device-popup.js] buttonView.onFocusCancelButton');
		getVoiceGuide('Cancel button.');
        this.btn1.setFocus();
        Utils.Timer.setTimerOut();
    },

    onBlurCancelBtn : function(widget) {
        Volt.log('[choose-device-popup.js] buttonView.onBlurCancelBtn');
        this.btn1.killFocus();
    },
});

function initList(parent,app_size,app_name) {
    var list = new Singlelist({
        width : parent.width,
        height : parent.height,
        scrollType: "Vertical",
        parent : parent
    }).render().widget;
    
    list.focusable = true;
    Volt.Nav.setNextItemRule(list, 'up', list);
    Volt.Nav.setNextItemRule(list, 'down', list);
    
    var storages = voltApiWrapper.getUsbStorages().storages;
    Volt.log('[choose-device-popup.js] storages.length - ' + storages.length);
    list.addItem({itemNum: storages.length, itemSpace: scene.height * 0.066667});
    
    list.setBackgroundColor(0,0,0,0);
    //list.enlargeFocusItem(20, 0);
    list.shadowEffectFlag = false;
    list.setAnimationDuration("focusMove", 100);
    list.setAnimationDuration("loop", 100);
    list.setScrollBar(chooseDevicePopupSelf.widget.getChild('devices-container'), storages.length);
    list.show();
    
    list.initRenderer = function(renderer, data, parentWidth, parentHeight){
        Volt.log('data - ' + JSON.stringify(data));
        var device = PanelCommon.loadTemplate(ChooseDevicesTemplate.deviceInfo, null, renderer.root);
        device.getChild(2).text = data.name;
        device.getChild(3).text = data.totalSize + " " + data.fileSystem;
        
        device.onFocus = function(){
            device.color = Volt.hexToRgb('#ffffff', 100);
            device.getChild(2).font = 
                device.getChild(3).font = ChooseDevicesTemplate.deviceInfoStyle.font.focused;
            device.getChild(2).textColor = 
                device.getChild(3).textColor = ChooseDevicesTemplate.deviceInfoStyle.textColor.focused;
        };
        device.onNormal = function(){
            device.color = Volt.hexToRgb('#ffffff', 0);
            device.getChild(2).font = 
                device.getChild(3).font = ChooseDevicesTemplate.deviceInfoStyle.font.normal;
            device.getChild(2).textColor = 
                device.getChild(3).textColor = ChooseDevicesTemplate.deviceInfoStyle.textColor.normal;
        };
        device.onSelect = function(){
            device.color = Volt.hexToRgb('#ffffff', 100);
            device.getChild(2).font = 
                device.getChild(3).font = ChooseDevicesTemplate.deviceInfoStyle.font.selected;
            device.getChild(2).textColor = 
                device.getChild(3).textColor = ChooseDevicesTemplate.deviceInfoStyle.textColor.selected;
        };
        device.onDim = function(){
            device.color = Volt.hexToRgb('#ffffff', 0);
            device.getChild(2).font = 
                device.getChild(3).font = ChooseDevicesTemplate.deviceInfoStyle.font.disabled;
            device.getChild(2).textColor = 
                device.getChild(3).textColor = ChooseDevicesTemplate.deviceInfoStyle.textColor.disabled;
        };
        
        if(this.app_size + 10 > data.availableSize) {
            device.onDim();
			TempUsbStorages[data.index].isDim = true;
        }
    };
    
    list.onItemMouseClick = 
    list.onItemPress = function(index){
        Volt.log('click - ' + index);
        Utils.Timer.clearTimeOut();
        var data = TempUsbStorages[index];
        Volt.log('[choose-device-popup.js] DevicesView.onSelect, this.app_id = ' + this.app_id + ' ,path = ' + data.mountPath + ', serialNumber = ' + data.serialNumber);        
        var storagepath = data.mountPath;
        var nIndex = storagepath.indexOf('/');
        var path = '/opt/storage/usb' + storagepath.substring(nIndex);
        Volt.log('[choose-device-popup.js] path = ' + path);
        CommonContent.chooseUsbPopUpItemPress(this.app_id, path, data.serialNumber);
    };
    
    list.onFocusChangeStart = function(singleLineList, fromItemIndex, toItemIndex){
        if(fromItemIndex >= 0) {
            var device = singleLineList.renderer(fromItemIndex).root.getChild(0);
            device.onNormal();
        }
    };

    list.onFocusChanged = function(singleLineList, fromItemIndex, toItemIndex){
		Volt.log('[choose-device-popup.js] onFocusChanged fromItemIndex = ' + fromItemIndex + ',,, toItemIndex = ' + toItemIndex);
        if(toItemIndex >= 0) {
            var device = singleLineList.renderer(toItemIndex).root.getChild(0);
            device.onFocus();
            
            var data = TempUsbStorages[toItemIndex];
            var params = {
                name : data.name,
                availableSize : data.availableSize,
                totalSize : data.totalSize,
                fileSystem : data.fileSystem
            };

			var voiceGuide = '';
			if(-1 == fromItemIndex){//first time
				voiceGuide += chooseDevicePopupSelf.widget.getChild('choose-devices-title').text + app_name + ',';
				var appSize = voltApiWrapper.setSuitablyUnit(app_size);
				var unit = 'COM_SID_MIX_MB';
				if('GB' == appSize.unit){
					unit = 'COM_SID_MIX_GB';
				}
				voiceGuide += Volt.i18n.t(unit).replace('<<A>>',appSize.size) + ',';
				voiceGuide += Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',list.numOfItem()) + ',';
				
			}
			voiceGuide += params.name + ',' + params.availableSize + ',' + Volt.i18n.t('TV_SID_AVAILABLE_LOWER');
			if(TempUsbStorages[toItemIndex].isDim){
				voiceGuide += ',' + Volt.i18n.t('TV_SID_DISABLED');
			}
			voiceGuide += '.';
			getVoiceGuide(voiceGuide);
			
            popupSelectedDeviceView.updateInfo(params);
            if(list.focusItemIndex == 0) {
                popupDevicesView.upArrow.onDim();
                popupDevicesView.downArrow.onNormal();
            } else if(list.focusItemIndex == list.numOfItem() - 1){
                popupDevicesView.upArrow.onNormal();
                popupDevicesView.downArrow.onDim();
            } else {
                popupDevicesView.upArrow.onNormal();
                popupDevicesView.downArrow.onNormal();
            }
            
            Utils.Timer.setTimerOut();
        }
    };
    
    TempUsbStorages.length = 0;
    for (var i = 0; i < storages.length; i++)
    {
        var data = new Data();
		data.index = i;
        TempUsbStorages[i] = {};
        TempUsbStorages[i].name = data.name = storages[i].name;
        TempUsbStorages[i].mountPath = data.mountPath = storages[i].mountPath;
        TempUsbStorages[i].fileSystem = data.fileSystem = storages[i].fileSystem;
        TempUsbStorages[i].availableSize = data.availableSize = parseInt(storages[i].availableSize / 10485.76) / 100 + 'GB';
        TempUsbStorages[i].totalSize = data.totalSize = parseInt(storages[i].totalSize / 10485.76) / 100 + "GB";
        TempUsbStorages[i].serialNumber = storages[i].serialNumber;
		TempUsbStorages[i].isDim = false;
        list.addData(data);
    }
    list.loadData();
    
    if(storages.length > 4){
        popupDevicesView.upArrow.show();
        popupDevicesView.downArrow.show();
    } else {
        popupDevicesView.upArrow.hide();
        popupDevicesView.downArrow.hide();
    }
    
    return list;
};

function getVoiceGuide(voiceGuide){
	Volt.log('[choose-device-popup.js] getVoiceGuide voiceGuide = ' + voiceGuide);
	VoiceGuide.getVoiceGuide(voiceGuide,false);
};

exports = ChooseDevicePopup;
