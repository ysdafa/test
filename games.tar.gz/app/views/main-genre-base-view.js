var Q             = Volt.require('modules/q.js');
var Backbone      = Volt.require('lib/volt-backbone.js');
var CommonDefine  = Volt.require('app/common/common-define.js');
var PanelCommon   = Volt.require('lib/panel-common.js');
var dimView       = Volt.require('app/views/dim-view.js');
var LoadingView   = Volt.require('app/views/loading-view.js');
var CommonContent = Volt.require('app/common/common-content.js');
var CommonFunction= Volt.require('app/common/common-function.js');

var Mediator      = Volt.require('app/common/event-mediator.js');
var voltApiWrapper= Volt.require("app/common/voltapi-wrapper.js");
var Gridlist      = Volt.require('app/views/grid-list-view.js');
var Utils         = Volt.require('app/common/utils.js');
var networkStatus = Volt.require('app/common/network-state.js');
var ErrorHandling = Volt.require('app/common/error-handling.js');

var MainCategoryModel   = Volt.require("app/models/main-category-model.js");
var NoContentView       = Volt.require('app/views/no-content-view.js');
var GenreDetailTemplate = Volt.require('app/templates/1080/genre-detail-template.js');
var DeviceModel   = Volt.require('app/models/device-model.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');

var realDataStateInGenre = false;
var mainGenreSelf = null;

var MainGenreBaseView = PanelCommon.BaseView.extend({
	parentWgt      : null,
	viewIsVisible  : false,
	contentWgt     : null,
	isPause        : false,
    requestSuccess : true,
	bListenerStatus: false,
	gridView       : null,
	
	initialize : function() {
		print('[main-genre-base-view.js] initialize');
		mainGenreSelf = this;
	},

	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur'
	},

	render : function(parentWidget, viewType) {
		print('[main-genre-base-view.js] MainView.render');
        this.viewType = viewType;
		this.parent = parentWidget.widget.getChild('main-content-container');
        this.renderContent();
	},

	renderContent : function() {
	    realDataStateInGenre = MainCategoryModel.isReady();
		print('[main-genre-base-view.js] renderContent');
		var currentModel = MainCategoryModel.get(this.viewType);
		var dataList = currentModel.get('data_list');
		if (dataList.length == 0) {
			var noContentWgtId = this.viewType;
			var textToShow = Volt.i18n.t('COM_NO_CONTENT_FOUND');
			this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;
		} else {
			this.contentWgt = this.initGrid(dataList,this.viewType);
			this.contentWgt.focusable = true;
			this.setGridFocusRule();
		}
		this.setWidget(this.contentWgt);
		this.parent.addChild(this.contentWgt);
	},
	
	setGridFocusRule : function() {
        Volt.Nav.setNextItemRule(this.contentWgt, 'up', Volt.Nav.getItem(3));//categoryTab
        Volt.Nav.setNextItemRule(this.contentWgt, 'left', this.contentWgt);
        Volt.Nav.setNextItemRule(this.contentWgt, 'right', this.contentWgt);
    },

	updateContent : function() {
        realDataStateInGenre = MainCategoryModel.isReady();
        if (this.contentWgt) {
            if (this.contentWgt.id == this.viewType) {
                return;
            }

            var currentModel = MainCategoryModel.get(this.viewType);
            var dataList = currentModel.get('data_list');
            CommonContent.updateData(dataList, 0, this.contentWgt);
            this.updateItems();
        } else {
            this.renderContent();
        }
	},

	show : function() {	
		this.startListening();
		this.addEventListener();
		this.viewIsVisible = true;
	    
		if (this.widget) {
			this.widget.show();
			if (!(this.widget.hasOwnProperty('id') && this.widget.id == this.viewType)) {
				this.widget.focusable = true;
			}
			this.updateItems();
		}
		
		if(this.gridView){
			this.gridView.show();
		}

		Volt.Nav.reload();
		
        var categoryState = MainCategoryModel.isReady();
        if (categoryState && (categoryState != realDataStateInGenre)) {
            this.updateContent();
        }
	},

	hide : function(animationType) {
        print('[main-genre-base-view.js] hide' + this.viewType);
        Mediator.off(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, this.updateListenerFlag, this);
        this.removeEventListener();
        var deferred = Q.defer();
        deferred.resolve();

        this.stopListening();
        this.viewIsVisible = false;
        this.isFirst = false;

        if (this.gridView) {
            this.gridView.hide();
        }

        if (this.widget) {
            this.widget.hide();
            if (!(this.widget.hasOwnProperty('id') && this.widget.id == this.viewType)) {
                this.widget.focusable = false;
            }
        }
        return deferred.promise;
	},

    requestData : function(){
        if (!networkStatus.getNetWorkState()) {
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR,'','505');
        } else {
            var that = this;
            function onSuccess() {
                that.requestSuccess = true;
                LoadingView.hide();
                that.renderContent();
				Volt.Nav.reload();
            }
            
            function onError(msg) {
                that.requestSuccess = false;
                LoadingView.hide();
                print("[main-genre-branch-view.js]" + CommonContent.getViewType());
                var viewType = CommonContent.getViewType();
                if (viewType == '#genre') {
                    ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR,'',JSON.stringify(msg.status));
                }
            }
            
            LoadingView.show(CommonDefine.Const.VIEW_LOADING);
            var currentModel = MainCategoryModel.get(this.viewType); 
            currentModel.fetch({'path' : this.path})
            .then(onSuccess, onError);
        } 
    },

	startListening : function() {
	    Mediator.on(CommonDefine.Const.UPDATE_ITEMS,             this.updateItems, this);
		Mediator.on(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, this.updateListenerFlag, this);
		Mediator.on(CommonDefine.Event.OPTION_MENU_POPUP,        this.showOptionMenu, this);
		Mediator.on(CommonDefine.Event.MSGBOX_BUTTON,            this.processMsgBoxEvent, this);
		Mediator.on(CommonDefine.Event.EVENT_DELETE_SUCCESS, CommonContent.unInstallSuccess, this);
		Mediator.on(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, CommonContent.showAppSyncError, this);
		Mediator.on(CommonDefine.Event.INSTALL_FAIL, CommonContent.installFail, this);
		Mediator.on(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
	},

	stopListening : function() {
		Mediator.off(CommonDefine.Event.OPTION_MENU_POPUP, null, this);
		Mediator.off(CommonDefine.Event.EVENT_SORT, null, this);
		Mediator.off(CommonDefine.Event.MSGBOX_BUTTON,null, this);
		Mediator.off(CommonDefine.Event.EVENT_DELETE_SUCCESS,null, this);
		Mediator.off(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE,null,this);
		Mediator.off(CommonDefine.Event.INSTALL_FAIL,null,this);
		Mediator.off(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
	},
    
	updateListenerFlag: function(flag){
		print('[main-genre-base-view.js] updateListenerFlag,flag = ' + flag);
		if(flag == true) {
			this.addEventListener();
			this.updateItems();
		} else {
			this.removeEventListener();
		}
		this.bListenerStatus = flag;
    },

	updateItems:function() {
		print("[main-genre-base-view.js] updateAllItems~~");
		var currentModel = MainCategoryModel.get(this.viewType);
		var gridCount = currentModel.get('list_cnt');
		if (this.contentWgt.id != this.viewType && (gridCount > 0)) {
			this.contentWgt.updateAllItems(0);
		}
    },
    
	addEventListener: function(){
		print('[main-genre-base-view.js] addEventListener, that.bListenerStatus = ' + this.bListenerStatus);
		if(this.bListenerStatus == false){
			Mediator.on(CommonDefine.Event.BEGIN_DOWNLOAD,    this.updateProgressBar, this);
			Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgressBar, this);
			Mediator.on(CommonDefine.Event.DOWNLOAD_CANCELED, this.updateProgressBar, this);
			Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
			this.bListenerStatus = true;
		}
	},

	removeEventListener: function(){
		print('[main-genre-base-view.js] removeEventListener, that.bListenerStatus = ' + this.bListenerStatus);
		if(this.bListenerStatus == true){
			Mediator.off(CommonDefine.Event.DOWNLOAD_PROGRESS,null,this);
			Mediator.off(CommonDefine.Event.INSTALL,null,this);
			Mediator.off(CommonDefine.Event.BEGIN_DOWNLOAD,null, this);
			Mediator.off(CommonDefine.Event.DOWNLOAD_CANCELED,null, this);
			this.bListenerStatus = false;
		}
    },

	remove : function() {
		if (this.contentWgt) {
			this.parent.removeChild(this.contentWgt);
			this.contentWgt.destroy();
			this.contentWgt = null;
		}
	},

	updateProgressBar : function(eventInfo) {
		print('[main-genre-base-view.js] updateProgressBar, grid = ' + this.contentWgt + ', viewIsVisible = ' + this.viewIsVisible + ',viewtype = ' + this.viewType);
		if (this.viewIsVisible == false || this.contentWgt == null) {
			return;
		}
		print('[main-genre-base-view.js] updateProgressBar, ID = ' + eventInfo.app_id);
		var index;
		var currentModel = MainCategoryModel.get(this.viewType);
		//var dataList = currentModel.get('data_list');
		for ( index = 0; index < currentModel.get('list_cnt'); index++) {
		    if(this.contentWgt){
                var data = this.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
		    }
		}
		print('[main-genre-base-view.js] index = ' + index + ', list_cnt = ' + currentModel.get('list_cnt'));
		//update install icon
		//update progress bar
		if (index < currentModel.get('list_cnt') && this.contentWgt) {
			this.contentWgt.updateItem(0, index);
		}
	},

	finishInstall : function(eventInfo) {
		print('[main-genre-base-view.js] finishInstall, grid = ' + this.contentWgt + ', viewIsVisible = ' + this.viewIsVisible + ',viewtype = ' + this.viewType);
		if (this.viewIsVisible == false || this.contentWgt == null) {
			return;
		}
		print('[main-genre-base-view.js] finishInstall, ID = ' + eventInfo.app_id);
		var index;
		var currentModel = MainCategoryModel.get(this.viewType);
		for ( index = 0; index < currentModel.get('list_cnt'); index++) {
		    if(this.contentWgt){
                var data = this.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
		    }
		}
		print('[main-genre-base-view.js] index = ' + index + ', genre_group_cnt = ' + currentModel.get('list_cnt'));
		//update install icon
		//update progress bar
		if (index < currentModel.get('list_cnt') && this.contentWgt) {
			this.contentWgt.updateItem(0, index);
		}
	},

	processMsgBoxEvent : function(data) {
		print('[main-genre-base-view.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
		if (data.eventType == CommonDefine.Event.SELECT_BTN1) {
			switch(data.msgBoxtype) {
				case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
					voltApiWrapper.startSSOPopup();
					break;
				default:

					break;
			}
		} else if (data.eventType == CommonDefine.Event.SELECT_BTN2) {

		}
	},

	onFocus : function(widget) {
		print('[main-genre-base-view.js] onFocus');

		if (this.contentWgt) {
		    widget = this.contentWgt;
		    Volt.Nav.focus(this.contentWgt);
			widget.onFocus();
		}
	},

	onBlur : function(widget) {
		if (widget) {
			print('[main-genre-base-view.js] onBlur');
			if (this.contentWgt) {
			    this.contentWgt.onBlur();
			}
		}
	},

    initGrid : function(dataList,viewType) {
    	Volt.log('[main-genre-base-view.js] initGrid viewType = ' + viewType);
        var genreDetailData = {
            style : CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME,
            groups : [{
                modelArr : dataList
            }]
        };
        var GridlistTemplate = Volt.require('app/templates/1080/grid-list-template.js');
        var gridView = new Gridlist(GridlistTemplate.genreDetail, JSON.stringify(genreDetailData), parseInt(scene.width * 0.16875), parseInt(scene.height * 0.4));

        gridView.setItemData = function(mustache, modelData) {
			mustache.imgUrl = (modelData['thumbnail_url']) ? modelData['thumbnail_url'] : '';
			mustache.title = (modelData['game_title']) ? modelData['game_title'] : '';
			mustache.genre = (modelData['genre']) ? modelData['genre'] : '';
			mustache.app_id = (modelData['app_id']) ? modelData['app_id'] : '';
			mustache.rating = (modelData['rating']) ? modelData['rating'] : '';
			mustache.size = (modelData['size']) ? modelData['size'] : '';
			mustache.controller_list = (modelData['controller_list']) ? modelData['controller_list'] : '';
			mustache.downloadable    = (modelData['downloadable']) ? modelData['downloadable'] : '';
        };

        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
            CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
            CommonContent.addThumbnailListener(rendererInstance.thumbnail);
            CommonContent.setFoverFactor(rendererInstance.thumbnail,parentWidth);
            this.onItemUpdate(rendererInstance, data);
            this.onItemIconLoad(data, rendererInstance, 'NoIcon');
        };

        gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
            var Renderer = this.widget.renderer(groupIndex, itemIndex);
			var page = '';
			switch(viewType){
				case 'arcade':
					spValue = 'G1';
					page = 'G09_GENRE01';
					break;
				case 'sports':
					spValue = 'G2';
					page = 'G10_GENRE02';
					break;
				case 'party':
					spValue = 'G3';
					page = 'G11_GENRE03';
					break;
				case 'puzzle':
					spValue = 'G4';
					page = 'G12_GENRE04';
					break;
				case 'shooting':
					spValue = 'G5';
					page = 'G13_GENRE05';
					break;
			}
			
			var spValue = Volt.KPIMapper.getSelectPosition(itemIndex + 1);
            CommonContent.onLaunch(page, itemData.app_id, Renderer.thumbnail,spValue);
        };

        gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {

        };

        gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {

        };

        gridView.itemLoaded = function(gridList, groupIndex, itemIndex) {
            var data = gridList.getData(groupIndex, itemIndex);
            data.group = groupIndex;
            data.item = itemIndex;
        };

        gridView.updateElements = function(parent, data) {
            print('[main-genre-base-view.js] updateElements');
            this.onItemIconLoad(data, parent, 'NoIcon');
        };

        gridView.resetElements = function(parent, data) {
            print('[main-genre-base-view.js] resetElements');
            this.onItemIconReset(data);
        };

		gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
			print('[main-genre-base-view.js] gridView.focusChanged .....');
			
			if(toItemIndex >= 0 && toGroupIndex >= 0){	
				var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
				Volt.pageItemIndex = toItemIndex + 1;
				var voiceText = '';
				if(-1 == fromItemIndex){
					voiceText += 'Games,';
					var tempStr = '';
					if('arcade' == viewType){
						tempStr = Volt.i18n.t('TV_SID_GAMES_2');
					}else if('party' == viewType){
						tempStr = Volt.i18n.t('TV_SID_GAMES_4');
					}else if('puzzle' == viewType){
						tempStr = Volt.i18n.t('TV_SID_GAMES_5');
					}else if('sports' == viewType){
						tempStr = Volt.i18n.t('TV_SID_GAMES_3');
					}else if('shooting' == viewType){
						tempStr = Volt.i18n.t('TV_SID_SHOOTING');
					}
					voiceText += Volt.i18n.t('TV_SID_MIX_CATEGORY_END').replace('<<A>>',tempStr) + ',';
					voiceText += Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',MainCategoryModel.get(viewType).get('list_cnt')) + ',';
				}

				voiceText += data.title + '.';
				VoiceGuide.getVoiceGuide(voiceText,false);
			}
		};
		this.gridView = gridView;
		
        return gridView.render().widget;
    }
});

exports = MainGenreBaseView;
