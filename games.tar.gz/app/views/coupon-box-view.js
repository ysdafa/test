// Include libraries
var Q            = Volt.require('modules/q.js');
var Backbone     = Volt.require('lib/volt-backbone.js');
var Mediator     = Volt.require('app/common/event-mediator.js');
var LoadingView  = Volt.require('app/views/loading-view.js');
var PanelCommon  = Volt.require('lib/panel-common.js');
var DimView      = Volt.require('app/views/dim-view.js');

var CommonDefine   = Volt.require('app/common/common-define.js');
var VoltApiWrapper = Volt.require("app/common/voltapi-wrapper.js");
var CommonFucntion = Volt.require('app/common/common-function.js');
var Gridlist       = Volt.require('app/views/grid-list-view.js');
var CommonContent  = Volt.require('app/common/common-content.js');
var voltapi        = Volt.require('modules/voltapi.js');
var Utils          = Volt.require('app/common/utils.js');
var CouponBoxModel = Volt.require('app/models/coupon-box-model.js');
var CouponTemplate = Volt.require('app/templates/1080/coupon-template.js');
var ErrorHandling  = Volt.require('app/common/error-handling.js');
var NoContentView  = Volt.require('app/views/no-content-view.js');
var DeviceModel    = Volt.require('app/models/device-model.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');
////////////////////////////////////////////////////////////////////////////////

var statusCouponView = 'HIDE';
var headerViewSelf = null;
var contentViewSelf = null;
var couponViewSelf = null;

var CouponBoxView = PanelCommon.BaseView.extend({
    template : CouponTemplate.container,
    isFirst : true,
    isBackFromPopup : false,
    //gridWgt : null,
    reback : false,
    bgColor : null,
    backFromDetail : false,
    viewType : 'couponNC',
    isActive : false,
    lastFocusInCoupon : null,

    initialize : function() {
        Volt.log('[coupon-box-view.js] initialize');
        couponViewSelf = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));
    },

    render : function() {
        Volt.log('[coupon-box-view.js] CouponBoxView.render');
        this.renderHeader();
    },

    renderHeader : function() {
        var container = this.widget.getDescendant('coupon-header-container');
        this.headerView = new HeaderView().render();
        container.addChild(this.headerView.widget);
    },

    renderContent : function() {
        Volt.log('[coupon-box-view.js] renderContent');
        var container = this.widget.getChild('coupon-content-container');
        if (CouponBoxModel.get('coupon_list_cnt') != 0) {
            this.contentView = new ContentView().render(container,this);
        } else {
        	var noContentWgtId = this.viewType;
        	var textToShow = Volt.i18n.t('TV_SID_REGISTERED_COUPONS') + '\n' + Volt.i18n.t('TV_SID_PLEASE_RETURN_TO_GO_TO_THE_PREVIOUS_SCREEN');
            this.contentView = new NoContentView().render(noContentWgtId,textToShow,CommonDefine.Const.NO_CONTENT_COUPON);
        }
        container.addChild(this.contentView.widget, 0);
        this.contentContainer = container;
        Volt.Nav.reload();
    },

    show : function(param, animationType) {
        this.viewIsVisiable = true;
        statusCouponView = "SHOW";
        Volt.log('[coupon-box-view.js] bgColor =' + param.bgColor);
        if (undefined === param.bgColor) {
            this.bgColor = CommonContent.getProfileColor();
        } else {
            this.bgColor = param.bgColor;
        }

        if (this.isFirst) {
            Volt.log('[coupon-box-view.js] first show');
            if (this.reback) {
                this.setWidget(PanelCommon.loadTemplate(this.template));
                this.renderHeader();
            }
            Volt.Nav.setRoot(this.widget,{focus : null});
            //Volt.Nav.focus(null);
            LoadingView.show(CommonDefine.Const.VIEW_LOADING);

            this.requestData();
            this.isFirst = false;
        } else if (this.isBackFromPopup) {
            Volt.log('[coupon-box-view.js] back form popup');
            DimView.hide();
            Volt.Nav.setRoot(this.widget);
            var gridWgt = this.contentContainer.getChild(0);
            if (gridWgt.id == this.viewType) {
                Volt.Nav.focus(gridWgt.getChild('RETURN'));
            } else {
                Volt.Nav.setNextItemRule(gridWgt, "right", gridWgt);
                Volt.Nav.focus(gridWgt);
                gridWgt.focusable = true;
            }
            this.isBackFromPopup = false;
        } else if (this.backFromDetail) {
            Volt.Nav.setRoot(this.widget);
            Volt.Nav.focus(this.contentContainer.getChild(0));
            this.backFromDetail = false;
        }
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
        
        this.isActive = true;

        this.widget.show();
        this.startListener();
    },
    
    startListener : function (){
        Mediator.on(CommonDefine.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
        Mediator.on("ENTER_INTO_DETAIL_FROM_POPUP", this.enterIntoDetailFromPopup, this);
        Mediator.on(CommonDefine.Event.REGISTER_COUPON, this.refresh, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
        Mediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, headerViewSelf.onChangeCursor, headerViewSelf);
    }, 
    
    stopListener : function (){
        Mediator.off(CommonDefine.Event.REGISTER_COUPON, this.refresh,this);
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR,null,headerViewSelf);
        Mediator.off("ENTER_INTO_DETAIL_FROM_POPUP", null, this);
        Mediator.off(CommonDefine.Event.MSGBOX_BUTTON, null, this);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, this);
    },

    requestData : function() {
        var that = this;
        function onSuccess() {
            LoadingView.hide();
            if (that.viewIsVisiable == true) {
                that.renderContent();
                var gridWgt = that.contentContainer.getChild(0);
                if (gridWgt.id == that.viewType) {
                    Volt.Nav.focus(gridWgt.getChild('RETURN'));
                } else {
                    Volt.Nav.focus(gridWgt);
                    gridWgt.focusable = true;
                }
            }
        }

        function onError(msg) {
            LoadingView.hide();
            Volt.log("[coupon-box-view.js]" + CommonContent.getViewType());
            var viewType = CommonContent.getViewType();
            if (viewType == '#coupon') {
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR,'',msg);
            }
        }

        CouponBoxModel.fetch()
            .then(onSuccess, onError);
        /* test coupon fake data
        CouponBoxModel.fetch("fake")
            .then(onSuccess, onError);
        */
    },

    hide : function(animationType) {
        Volt.log('[coupon-box-view.js] hide');
        var deferred = Q.defer();
        deferred.resolve();
        this.stopListener();
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, this);
        Volt.Nav.focus(null);
        LoadingView.hide();
        this.viewIsVisiable = false;
        
        if (this.backFromDetail) {
            Volt.log('[coupon-box-view.js] enter to detail');
            this.widget.hide();
        } else {
            this.destroy();
            this.widget.hide();
            this.widget.destroy();
            this.widget = null;
            this.isFirst = true;
            this.reback = true;
        }
        
        statusCouponView = "HIDE";
        this.isActive = false;
        return deferred.promise;
    },

    destroy : function() {
        Volt.log('[coupon-box-view.js] destroy');
        if (!this.widget)
            return;
        this.widget.destroyChildren();
    },

    pause : function() {
        Volt.log('[coupon-box-view.js] pause');
        if ("PAUSE" == statusCouponView) {
            Volt.log('[coupon-box-view.js] This view has already paused');
            return;
        }

        statusCouponView = "PAUSE";
        this.getLastFocus();
        Volt.Nav.blur();
		var mlsMode = voltapi.vconf.getValue('memory/mls/state');
		Volt.log(' vconf MLS_STATE : ' + mlsMode);
		if(mlsMode == 1){
			Volt.log('MLS mode, do not show dim');
		} else {
			DimView.show({
				parent : this.widget.getChild('coupon-popup-container')
			});
		}
    },

    resume : function() {
        Volt.log('[coupon-box-view.js] resume');
    	if ("SHOW" == statusCouponView) {
            Volt.log('[coupon-box-view.js] This view has already showed');
            return;
        }
		
        if (this.isActive) {
            DimView.hide();
            statusCouponView = "SHOW";
            this.setLastFocus();
        }
    },
    
    deactive : function () {
        Volt.log('[coupon-box-view.js] deactive.......'); 
        if(!this.isActive){
            Volt.log('[coupon-box-view.js] already in deactive');
            return;
        }
        this.isActive = false;
        this.stopListener();
        this.pause();
    },
    
    active : function () {
        Volt.log('[coupon-box-view.js] active'); 
        if(this.isActive){
            Volt.log('[coupon-box-view.js] already in active');
            return;
        }
        this.isActive = true;
        this.startListener();
        this.resume();
    },
    
    getLastFocus : function () {
        this.lastFocusInCoupon = Volt.Nav.getFocusedWidget();
        Volt.log('[coupon-box-view.js] getLastFocus lastFocusInCoupon =' + this.lastFocusInCoupon);
        if(this.lastFocusInCoupon && this.lastFocusInCoupon.hasOwnProperty("id") && this.lastFocusInCoupon.id) {
            Volt.log('[coupon-box-view.js] getLastFocus lastFocusWgt.id =' + this.lastFocusInCoupon.id);
        }
    },
    
    setLastFocus : function() {
        Volt.log('[coupon-box-view.js] setLastFocus'); 
        if (this.lastFocusInCoupon) {
            Volt.log('[coupon-box-view.js] setLastFocus LoadingView.viewIsVisiable ='+LoadingView.viewIsVisiable);
            if(!LoadingView.viewIsVisiable){
                Volt.Nav.setRoot(this.widget, {
                    focus : this.lastFocusInCoupon
                });
            }
        } else {
            Volt.log('[coupon-box-view.js] setLastFocus while lastfocus is null'); 
            Volt.Nav.setRoot(this.widget);
        }
    },

    processMsgBoxEvent : function(data) {
        Volt.log('[coupon-box-view.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);

        if (data.eventType == CommonDefine.Event.SELECT_BTN1) {
            switch(data.msgBoxtype) {
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
                    VoltApiWrapper.startSSOPopup();
                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR:
                    Backbone.history.back();
                    break;
                default:
                    break;
            }
        } else if (data.eventType == CommonDefine.Event.SELECT_BTN2) {

        }
    },

    enterIntoDetailFromPopup : function(params, bgColor) {
        this.backFromDetail = true;
    },
    
    refresh : function(options) {
        Volt.log("[coupon-box-view.js] refresh");
        this.isFirst = false;
        
        var gridWgt = this.contentContainer.getChild(0);
        Volt.log("[coupon-box-view.js] refresh gridWgt : " + gridWgt);
        if (gridWgt) {
            if (gridWgt.hasOwnProperty('id') && gridWgt.id == this.viewType) {
                for (var index = 0; index < gridWgt.getChildCount(); index++) {
                    Volt.Nav.removeItem(gridWgt.getChild(index));
                }
                this.contentContainer.removeChild(gridWgt);
                gridWgt.destroyChildren();
            } else {
                Volt.Nav.removeItem(gridWgt);
                this.contentContainer.removeChild(gridWgt);
            }

            gridWgt.destroy();
            this.requestData();
        }

    },
});

var HeaderView = PanelCommon.BaseView.extend({
    template : CouponTemplate.header,
    pageBackArrow : null,
    registerBtn : null,
    btnListener : new ButtonListener(),
    
    initialize : function(parent) {
        Volt.log('[coupon-box-view.js] HeaderView.initialize');
        headerViewSelf = this;
        var that = this;
        this.btnListener.onButtonClicked = function(button, type) {
            switch(button.id) {
                case 'coupon-header-icon-schedule-image':
                    that.onSelectSchedule();
                    break;
                default :
                    break;
            }
        };
    },

    render : function() {
        Volt.log('[coupon-box-view.js] HeaderView.render');
        //CouponTemplate.header.children[2].children[0].children[0].src = Volt.getRemoteUrl('images/1080/common/comn_icon_topmenu_plus.png');
        this.setWidget(CommonContent.loadTemplateInWinsetBackgroud(this.template));
        
        if (!voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)) {
            this.widget.getDescendant('coupon-box-title').x = 36;
        } else {
            this.widget.getDescendant('coupon-box-title').x = 136;
        }

        this.pageBackArrow = this.widget.getDescendant('coupon-box-back-icon-area');
        this.backBtn = new Button(CouponTemplate.backBtn);
        this.backBtn.parent = this.pageBackArrow;
        this.backBtn.setBackgroundImage({
			state : "focused",
			src : "images/1080/highlight/ksc_focus.png"
		});
		this.backBtn.setBackgroundImage({
			state : "focused-roll-over",
			src : "images/1080/highlight/ksc_focus.png"
		});
		this.backBtn.setIconImage({
			state : "focused",
			src : Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_sel.png')
		});
		this.backBtn.setIconImage({
			state : "focused-roll-over",
			src : Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_sel.png')
		});
		this.backBtn.setIconImage({
			state : "normal",
			src : Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_nor.png')
		});
		this.backBtn.setIconAlpha({
			state : "focused",
			alpha : 255
		});
		this.backBtn.setIconAlpha({
			state : "normal",
			alpha : 153
		});

        this.pageBackArrow.addEventListener('OnMouseOver', function() {
			this.backBtn.setFocus();
			var AbsolutePosition = this.pageBackArrow.getAbsolutePosition();
			var opt = {
				text: Volt.i18n.t('COM_SID_RETURN'),
				x: AbsolutePosition.x,
				y: AbsolutePosition.y,
				height: this.pageBackArrow.height,
				width: this.pageBackArrow.width,
				direction:'up',
			};
				
			CommonContent.showToolTip(opt,CouponTemplate);
        }.bind(this));
        this.pageBackArrow.addEventListener('OnMouseOut', function() {
			CommonContent.hideToolTip();
        }.bind(this));
        this.pageBackArrow.addEventListener('OnMouseClick', function() {
			CommonContent.hideToolTip();
            Backbone.history.back();
        }.bind(this));

        if (!voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)) {
            Volt.log("hide pageBackArrow~~~");
            this.pageBackArrow.hide();
        }
        this.setRigisterIcon();
        return this;
    },

    events : {
        //'NAV_SELECT #coupon-header-icon-schedule' : 'onSelectSchedule',
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onFocus : function(widget) {
        Volt.log('[coupon-box-view.js] HeaderView onFocus');
        if (widget && widget.id) {
            Volt.log('[coupon-box-view.js] HeaderView.focus ' + widget.id);
            if (widget.id == 'coupon-header-icon-schedule') {
                this.registerBtn.setFocus();
                VoiceGuide.getVoiceGuide('Register,button.', false);
            }
        }
        widget.opacity = 255; 
    },

    onBlur : function(widget) {
        if (widget) {
            Volt.log('[coupon-box-view.js] HeaderView.onBlur ' + widget.id);
			if (widget.id == 'coupon-header-icon-schedule') {
				 widget.opacity = 255; 
			}
			else {
				 widget.opacity = 51;
			}
        }
    },

    onSelectSchedule : function() {
        Volt.log('[coupon-box-view.js] HeaderView.onSelectSchedule');
        addEventLog('COUPONCLICK', {cp : 'G07_COUPON',inputby:'',});

        this.isBackFromPopup = true;
        var params = {
            "event" : "coupon-regist",
            "type" : 'input-text',
            'cp' : Volt.KPIMapper.getPageEvent().pageEvent,
            'from': '',
        };
        Backbone.history.navigate('popup/' + JSON.stringify(params), {
            trigger : true
        });
    },
    
    onChangeCursor : function(visible) {
        Volt.log("[coupon-box-view.js] onChangeCursor visible is ", visible);

        if (this.pageBackArrow) {
            if (visible) {
                this.pageBackArrow.show();
                this.widget.getDescendant('coupon-box-title').x = 136;
            } else {
                this.pageBackArrow.hide();
                this.widget.getDescendant('coupon-box-title').x = 36;
            }
        }
    },
    
    setRigisterIcon : function(){
        Volt.log('[coupon-box-view.js] HeaderView.setRigisterIcon');
        //this.registerBtn = PanelCommon.loadTemplate(CouponTemplate.registerBtn, btnStyle,this.widget.getDescendant('coupon-header-icon-schedule'));
        this.registerBtn = new Button(CouponTemplate.registerBtn);
        this.registerBtn.parent =this.widget.getDescendant('coupon-header-icon-schedule');
        this.widget.getDescendant('coupon-header-icon-schedule').addEventListener('OnMouseOver',function(){
        	this.registerBtn.setFocus();
        }.bind(this));
        this.registerBtn.setBackgroundImage({state:"focused",src:"images/1080/highlight/ksc_focus.png"});
        this.registerBtn.setBackgroundImage({state:"focused-roll-over",src:"images/1080/highlight/ksc_focus.png"});
		this.registerBtn.setIconImage({
			state : "all",
			src : Volt.getRemoteUrl('images/1080/common/comn_icon_topmenu_plus.png')
		});
		
        this.registerBtn.setIconAlpha({state:"normal",alpha:255});
        this.registerBtn.setIconAlpha({state:"focused",alpha:255});
        this.registerBtn.setIconAlpha({state:"focused-roll-over",alpha:255});
        this.registerBtn.addListener(this.btnListener);
    },
});

var ContentView = PanelCommon.BaseView.extend({
    template : CouponTemplate.content,
    grid : null,

    render : function(parent, self) {
        Volt.log('[coupon-box-view.js] ContentView.render');
        contentViewSelf = this;
        if (!this.widget.created) {
            var couponList = CouponBoxModel.get("coupon_list");
            var couponData = {
                style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
                groups : [{
                    modelArr : couponList
                }]
            };

            var gridView = new Gridlist(this.template, JSON.stringify(couponData), parseInt(scene.width * 0.28125), parseInt(scene.height * 0.866667));

            gridView.setItemData = function(mustache, modelData) {
                var isExpired = modelData['expired_flag'];
                var isUsed = modelData['used_flag'];
                var gameListCnt = parseInt(modelData['game_list_count']);
                var gameList = modelData['game_list'];
                var validDate = modelData['expired_date'];

                if ('Y' === isExpired && 'Y' === isUsed) {
                    mustache.expired = 'Expired';
                    mustache.used = Volt.i18n.t('TV_SID_USED');
                } else if (isExpired == 'Y' || isUsed == 'Y') {
                    if (isExpired == 'Y')
                        mustache.expired = 'Expired';
                    if (isUsed == 'Y')
                        mustache.expired = Volt.i18n.t('TV_SID_USED');
                }
                
                var date = Utils.Date.transferNumStrToDate(validDate);
                var formatedDate = Utils.Date.getFormatedDate(date);
                Volt.log('[coupon-box-view.js] formatedDate = ' + formatedDate); 

                mustache.title = modelData['coupon_title'];
                //mustache.valid = modelData['expired_date'];
                mustache.valid = formatedDate;
                mustache.couponId = modelData['coupon_no'];
                mustache.message = modelData['message'];
                mustache.gameListCnt = gameListCnt;
                
                Volt.log("[coupon-box-view.js] onItemPress gameNum =" + gameListCnt);

                if (gameListCnt == 1) {
                    mustache.img_url1 = gameList[0].thumbnail_url;
                } else if (gameListCnt == 2) {
                    mustache.img_url1 = gameList[0].thumbnail_url;
                    mustache.img_url2 = gameList[1].thumbnail_url;
                } else if (gameListCnt == 3) {
                    mustache.img_url1 = gameList[0].thumbnail_url;
                    mustache.img_url2 = gameList[1].thumbnail_url;
                    mustache.img_url3 = gameList[2].thumbnail_url;
                }
            };

            gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
                Volt.log("[coupon-box-view.js] setItemTemplate");
                var thumbnailObj = rendererInstance.thumbnail;
                
                thumbnailObj.setFoveaImageScaleFactor(0.03);
                thumbnailObj.setFoveaImageInterpolatorType(0);

                thumbnailObj.setFoveaInfoBoxScaleFactor(0.03);
                thumbnailObj.setFoveaInfoBoxInterpolatorType(0); 
                
                if(data.title){
                    thumbnailObj.setInformationText("text1",data.title);
                } else {
                    thumbnailObj.setInformationText("text1","no title");
                }
                
                thumbnailObj.setInformationText("text2","Valid : " + data.valid);
                if(data.message){
                    thumbnailObj.setInformationText("text3",data.message);
                } else {
                    thumbnailObj.setInformationText("text3","No message info");
                }
                
                Volt.log("[coupon-box-view.js] setItemTemplate data.expired : " + data.expired);
                Volt.log("[coupon-box-view.js] setItemTemplate data.used : " + data.used);
                var isExpired = data.expired;
                var isUsed = data.used;
                
                if(isExpired != undefined && isUsed !== undefined){
                    //expired and used
                    Volt.log("[coupon-box-view.js] setItemTemplate expired and used" );
                    onColorPicker(rendererInstance, 1);
                    createExpiredTextWidget(thumbnailObj,parentWidth, parentHeight,data.expired);
                    createUsedTextWidget(thumbnailObj,parentWidth, parentHeight);
                    
                    //thumbnailObj.setInformationText("text5",data.expired);
                    //thumbnailObj.setInformationText("text6",data.used);
                } else if (isExpired != undefined || isUsed != undefined){
                    //expired or used
                    Volt.log("[coupon-box-view.js] setItemTemplate expired or used" );
                    if(isExpired == 'Expired'){
                        onColorPicker(rendererInstance, 1);
                    } else {
                        onColorPicker(rendererInstance, 2);
                    }
                    
                    //thumbnailObj.setInformationText("text5",data.expired);
                    createExpiredTextWidget(thumbnailObj,parentWidth, parentHeight,data.expired);
                    thumbnailObj.visualizeInformationIcon(false,"icon3");
                    //thumbnailObj.visualizeInformationText(false,"text6");
                } else {
                    //not expired and not used
                    Volt.log("[coupon-box-view.js] setItemTemplate not expired and not used" );
                    onColorPicker(rendererInstance, 0);
                    thumbnailObj.visualizeInformationIcon(false,"icon2");
                    //thumbnailObj.visualizeInformationText(false,"text5");
                    thumbnailObj.visualizeInformationIcon(false,"icon3");
                    //thumbnailObj.visualizeInformationText(false,"text6");
                }
                
                Volt.log("[coupon-box-view.js] setItemTemplate data.gameListCnt : " + data.gameListCnt);
                var gameCount = parseInt(data.gameListCnt);
                switch(gameCount){
                    case 1:
                        Volt.log("[coupon-box-view.js] setItemTemplate 1" );
                        thumbnailObj.setInformationIcon("icon5",data.img_url1);
                        thumbnailObj.visualizeInformationIcon(false,"icon4");
                        thumbnailObj.visualizeInformationIcon(false,"icon6");
                        break;
                    case 2:
                        Volt.log("[coupon-box-view.js] setItemTemplate 2" );
                        //adjust the x,y position for icon4 and icon5
                        thumbnailObj.setElementAllocation("information-icon4",{
                            x : scene.width * (0.028125 + 0.075/2),
                        });
                        thumbnailObj.setElementAllocation("information-icon5",{
                            x : scene.width * (0.028125 + 0.075/2 + 0.075),
                        });
                        thumbnailObj.setInformationIcon("icon4",data.img_url1);
                        thumbnailObj.setInformationIcon("icon5",data.img_url2);
                        thumbnailObj.visualizeInformationIcon(false,"icon6");
                        //adjust the x,y position for icon4 and icon5
                        break;
                    case 3:
                        Volt.log("[coupon-box-view.js] setItemTemplate 3" );
                        thumbnailObj.setInformationIcon("icon4",data.img_url1);
                        thumbnailObj.setInformationIcon("icon5",data.img_url2);
                        thumbnailObj.setInformationIcon("icon6",data.img_url3);
                        break;
                    default :
                        Volt.log("[coupon-box-view.js] setItemTemplate no game list" );
                        thumbnailObj.visualizeInformationIcon(false,"icon4");
                        thumbnailObj.visualizeInformationIcon(false,"icon5");
                        thumbnailObj.visualizeInformationIcon(false,"icon6");
                        break;
                }
            };

            gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
                Volt.log("[coupon-box-view.js] onItemPress itemIndex =" + itemIndex);
                var couponId = itemData.couponId;
                var expiredFlag = CouponBoxModel.get("coupon_list").at(itemIndex).get('expired_flag');
                var used = CouponBoxModel.get("coupon_list").at(itemIndex).get('used_flag');
                var gameNum = parseInt(CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list_count'));
                Volt.log("[coupon-box-view.js] onItemPress gameNum =" + gameNum);
				var spValue  = 'CC' + Volt.KPIMapper.getIndexFormat(itemIndex + 1);
				var eventName = '';
				
                if ('Y' == expiredFlag) {
					addEventLog('COUPONERROR',{
								cp : 'G07_COUPON',
				                sp:spValue,
				                content:'coupon' + '|' + couponId,
				                status:'expired',
				                inputby:'',
				   });
				
				   Volt.KPIParams.event = 'COUPONDELETE';
	               Volt.KPIParams.cp 	 = 'G07_COUPON';
				   Volt.KPIParams.content = 'coupon' + '|' + couponId;
				   Volt.KPIParams.status = 'expired';
                   ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_EXPIRED);
                } else if ('Y' == used) {
                	addEventLog('COUPONERROR',{
								cp : 'G07_COUPON',
				                sp:spValue,
				                content:'coupon' + '|' + couponId,
				                status:'used',
				                inputby:'',
				   });

				   Volt.KPIParams.event = 'COUPONDELETE';
	               Volt.KPIParams.cp 	 = 'G07_COUPON';
				   Volt.KPIParams.content = 'coupon' + '|' + couponId;
				   Volt.KPIParams.status = 'used';
                   ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_USED);
                } else if (1 == gameNum) {
                    //games is installed?
                    var appId = CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list')[0].app_id;
                    Volt.log("[coupon-box-view.js] onItemPress appId =" + appId);
                    var installed = VoltApiWrapper.isWidgetInstalled(appId);
                    Volt.log("[coupon-box-view.js] onItemPress installed =" + installed);
                    if (installed) {
                        //run this game
                        eventName = 'EXEGAME';
                        VoltApiWrapper.launchApp(appId);
                    } else {
                        eventName = 'VIEWGAME';
                        Volt.log("[coupon-box-view.js] onItemPress view detail -- 1");
						self.backFromDetail = true;
                        Backbone.history.navigate('detail/' + appId, {
                            trigger : true
                        });
                    }
					addEventLog(eventName,{
								cp : 'G07_COUPON',
				                appid : appId,
				                sp:spValue,
				                content:'coupon' + '|' + couponId,
				                inputby:'',
				   });
                } else if(gameNum > 1) {
                    var couponNo = CouponBoxModel.get("coupon_list").at(itemIndex).get('coupon_no');
                    var params = {
                        "couponNo" : couponNo,
                        "index" : itemIndex,
                        "type" : 'select-games'
                    };

					 addEventLog('POPCGAMES',{
								cp : 'G07_COUPON',
				                content:'coupon' + '|' + couponId,
				                inputby:'',
				    });
                    self.isBackFromPopup = true;
                    Backbone.history.navigate('popup/' + JSON.stringify(params), {
                        trigger : true
                    });
                } else {
                    Volt.log('[coupon-box-view.js] no games in this coupon');
                }
            };
            
            gridView.itemLoaded = function(gridList, groupIndex, itemIndex) {
                Volt.log("[coupon-box-view.js] itemLoaded  ");
                Volt.log("[coupon-box-view.js] itemLoaded  groupIndex: " + groupIndex + ",itemIndex: " + itemIndex);
                var data = gridList.getData(groupIndex, itemIndex);
                data.group = groupIndex;
                data.item = itemIndex;
            };
            
            function onColorPicker(parent, flag) {
                Volt.log("[coupon-box-view.js] onColorPicker");
                switch(flag){
                    case 0:
                        parent.root.color = {
                            r : self.bgColor.r,
                            g : self.bgColor.g,
                            b : self.bgColor.b
                        };
                        break;
                    case 1:
                        //expired
                        parent.root.color = Volt.hexToRgb('#52565d');
                        break;
                    case 2:
                        //used
                        parent.root.color = Volt.hexToRgb('#52565d',90);
                        break;
                    default:
                        break;
                }
                
                var fontColor = CommonContent.onColorPickerForPopupOrText(parent.root.color);

                Volt.log("[coupon-box-view.js] onColorPicker:fontColor r:" + fontColor.r + ",g:" + fontColor.g + ",b:" + fontColor.b);
                var thumbnailObj = parent.thumbnail;
                
                thumbnailObj.setInformationTextColor("text1", {
                    r : fontColor.r,
                    g : fontColor.g,
                    b : fontColor.b,
                });
                thumbnailObj.setInformationTextColor("text2", {
                    r : fontColor.r,
                    g : fontColor.g,
                    b : fontColor.b,
                });
                thumbnailObj.setInformationTextColor("text3", {
                    r : fontColor.r,
                    g : fontColor.g,
                    b : fontColor.b,
                });
                thumbnailObj.setInformationTextColor("text4", {
                    r : fontColor.r,
                    g : fontColor.g,
                    b : fontColor.b,
                }); 
            }
            
            function createExpiredTextWidget (thumbnailObj,parentWidth, parentHeight,textStr) {
                var expiredWidget = new TextWidgetEx({
                    parent : thumbnailObj,
                    x : parentWidth * 0.42963,
                    y : parentHeight * 0.219015,
                    width : parentWidth * 0.370370,
                    height : parentHeight * 0.064102,
                    font : "SVD Light 32px",
                    text : textStr,
                    singleLineMode : true,
                    horizontalAlignment : "center",
                    rotation : {
                        x : 0,
                        y : 0,
                        z : -15
                    },
                    textColor : {
                        r : 255,
                        g : 255,
                        b : 255,
                        a : 255
                    },
                }); 

            }
            
            function createUsedTextWidget (thumbnailObj,parentWidth, parentHeight) {
                var rotatedWidget = new TextWidgetEx({
                    parent : thumbnailObj,
                    x : parentWidth * 0.42963,
                    y : parentHeight * 0.336538,
                    width : parentWidth * 0.370370,
                    height : parentHeight * 0.064102,
                    font : "SVD Light 32px",
                    text : Volt.i18n.t('TV_SID_USED'),
                    singleLineMode : true,
                    horizontalAlignment : "center",
                    rotation : {
                        x : 0,
                        y : 0,
                        z : -15
                    },
                    textColor : {
                        r : 255,
                        g : 255,
                        b : 255,
                        a : 255
                    },
                }); 

            }

			gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
                Volt.log('[coupon-box-view.js] gridView.focusChanged fromItemIndex = ' + fromItemIndex + ',,,toItemIndex = ' + toItemIndex + ',,,toGroupIndex= ' + toGroupIndex);

                if (toItemIndex >= 0 && toGroupIndex >= 0) {
                    var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
                    var voiceGuide = data.title;

                    if (data.expired != undefined) {
                        voiceGuide += ',Expired';
                        VoiceGuide.getVoiceGuide(voiceGuide, false);
                        return;
                    }

                    if (data.used != undefined) {
                        voiceGuide += ',Used';
                        VoiceGuide.getVoiceGuide(voiceGuide, false);
                        return;
                    }

                    var voiceText = '';
                    if (-1 == fromItemIndex) {
                        voiceText += 'Coupons,' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', CouponBoxModel.get('coupon_list_cnt'));
                    }

                    voiceText += data.title + data.message + ',' + Volt.i18n.t('TV_SID_SELECTING_A_COUPON_WILL_TAKE_YOU_TO_THE_GAME');
                    var coupon = CouponBoxModel.get("coupon_list").at(toItemIndex);
                    var gameTitle = '';
                    for ( i = 0; i < parseInt(data.gameListCnt); i++) {
                        gameTitle += ',' + coupon.get('game_list')[i].game_title;
                    }

                    voiceText += gameTitle + '.';
                    VoiceGuide.getVoiceGuide(voiceText, false);
                }

			};
			
            gridView.disableLongPress();
            this.grid = gridView.render().widget;
            this.grid.focusable = true;
            this.setWidget(this.grid);
            this.widget.created = true;
        }
        return this;
    },

    events : {
        //'NAV_SELECT':'onSelect',
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onSelect : function() {
    },

    onFocus : function(widget) {
        Volt.log('[coupon-box-view.js] ContentView.onFocus widget ='+ widget);
        if(!widget){
            widget = this.widget;
        }
            
        if (this.grid) {
            widget = this.grid;
            Volt.Nav.focus(this.grid);
            widget.onFocus();
        }
    },

    onBlur : function(widget) {
        Volt.log('[coupon-box-view.js] ContentView.onBlur');
        if (CouponBoxModel.get('coupon_list_cnt') != 0) {
            if (widget) {
                if (this.grid) {
                    this.grid.onBlur();
                }
            }
        }
    },

    destroy : function() {
        this.grid.destroy();
    }
});

var addEventLog = function(eventName,options){
	Volt.log('[coupon-box-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
	//add Event log
	if(!eventName){
		return;
	}
    Volt.KPIMapper.addEventLog(eventName, {d : options});
};
exports = CouponBoxView; 