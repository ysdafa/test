// Include libraries

var _         = Volt.require('modules/underscore.js')._;
var Q         = Volt.require('modules/q.js');
var Backbone  = Volt.require('lib/volt-backbone.js');
var Mediator  = Volt.require('app/common/event-mediator.js');
var Utils     = Volt.require('app/common/utils.js');
var PanelCommon     = Volt.require('lib/panel-common.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');
var CommonDefine    = Volt.require('app/common/common-define.js');
var CommonFucntion  = Volt.require('app/common/common-function.js');
var MessageTemplate = Volt.require("app/templates/1080/message-popup-template.js");
var WinsetMessageBox = Volt.require("WinsetUIElement/winsetMessageBox.js");
var CommonContent     = Volt.require('app/common/common-content.js');

var messagePopup = PanelCommon.BaseView.extend({
	messageBox : null,
	msgParam   : null,
	firstTime  : false,
	initialize : function() {
		messageSelf = this;
	},

	render : function() {
	},

	show : function(param) {
		Volt.log("[message-box-view]---------------------show");
        var that = this;
		this.firstTime = true;
		this.msgParam = param = JSON.parse(param);
		this.messageBox = new WinsetMessageBox(param);
		
        if (param.hasOwnProperty("button_1_Text")) {
			this.messageBox.setButtonText("button_1", "all", param.button_1_Text);
		}
        
		if (param.hasOwnProperty("button_2_Text")) {
			this.messageBox.setButtonText("button_2", "all", param.button_2_Text);
		}
        
		if (param.hasOwnProperty("button_3_Text")) {
			this.messageBox.setButtonText("button_3", "all", param.button_3_Text);
		}
        
		var m_DefaultFocus;
		if (param.button) {
			if(param.hasOwnProperty('defaultFocus')){
				m_DefaultFocus = param.defaultFocus;
			} else {
				m_DefaultFocus= 'button_1';
			}
			this.messageBox.setButtonTextColor("button_all", "focused",70,70,70,255);
		};
		
		if(param.hasOwnProperty('showTime')){
			showTime = param.showTime;
            this.messageBox.showTime = param.showTime;
		} else {
            this.messageBox.showTime = 30000;
        }
		
		if (!(typeof param.focusIndex === 'undefined')){
		switch(param.focusIndex){
			case 1:{
					m_DefaultFocus = 'button_1';
					break;
					}
			case 2:{
					m_DefaultFocus = 'button_2';
					break;
					}
			case 3:{
					m_DefaultFocus = 'button_3';
					break;
					}
			default:
				return false;
				break;
			}
		}

		this.messageBoxListener = new MessageBoxListener;
		this.messageBoxListener.OnButtonEvent = _.bind(this.onButtonEvent, this);
		this.messageBoxListener.OnTimeOut = function(messagebox){
			Volt.setTimeout(_.bind(that.msgBoxOnTimeOut,that),1);
		};
		this.messageBox.addListener(this.messageBoxListener);
		
        this.messageBox.setDefaultFocus(m_DefaultFocus);
		this.messageBox.setButtonTextColor("button_all", "focused",70,70,70,255);
		this.messageBox.onKeyEvent = _.bind(this._onkeyEvent, this);
		
		this.messageBox.show();
        
		this.setWidget(this.messageBox);
		//Volt.Nav.beginModal(this.messageBox);
		//Volt.Nav.block();
		Volt.Nav.setRoot(this.widget);
		Volt.log("[message-box-view] show  param.type =" + param.type);
		if(CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS == param.type){
		    CommonContent.resetDeleteSuccessPopup(true);
		}
	},
	
	msgBoxOnTimeOut:function(){
		Volt.log("[message-box-view]---------------------onTimeOut callback "+this.msgParam.type);
		Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT,this.msgParam.type);
		Backbone.history.back();
	},
	
	onButtonEvent : function(messagebox, nButtonIndex, eventType) {
		if ("button_focus_in" == eventType){
			var voiceGuide = '';
			if(this.firstTime){
				voiceGuide += this.msgParam.contentText + ',';
				this.firstTime = false;
			}
			
			if('button_1' == nButtonIndex){
				voiceGuide += this.msgParam.button_1_Text;
			}else if('button_2' == nButtonIndex){
				voiceGuide += this.msgParam.button_2_Text;
			}else if('button_3' == nButtonIndex){
				voiceGuide += this.msgParam.button_3_Text;
			}
			
			voiceGuide += ',button';
			VoiceGuide.getVoiceGuide(voiceGuide,false);
		}
		
		
		if ("button_clicked" == eventType) {
			switch(nButtonIndex) {
				case "button_1":
					this.onButton1Click();
					break;
				case "button_2":
					this.onButton2Click();
					break;
				case "button_3":
					this.onButton3Click();
					break;
				default:
					break;
			}
		};
	},

	onButton1Click : function() {
		Volt.log('[message-box-popup.js] buttonView.onSelect_btn1.....');
	//	this.messageBox.setDefaultFocus('button_1');
		var that = this;
		var data = {
			msgBoxtype : that.msgParam.type,
			eventType : CommonDefine.Event.SELECT_BTN1,
			appID : that.msgParam.appID,
		};

		Volt.log('[message-box-popup.js] buttonView.onSelect_btn1 Volt.KPIParams = ' + JSON.stringify(Volt.KPIParams));
		if('JUMPSSO' ==Volt.KPIParams.event){
			that.addEventLog(Volt.KPIParams.event,{cp:Volt.KPIParams.cp,ssoby:Volt.KPIParams.ssoby,inputby:''});
		}else if('COUPONDELETE' ==Volt.KPIParams.event){
			that.addEventLog(Volt.KPIParams.event,{
								cp:Volt.KPIParams.cp,content:Volt.KPIParams.content,
								status:Volt.KPIParams.status,inputby:''});
		}else if('MYDELETE' ==Volt.KPIParams.event){
			that.addEventLog(Volt.KPIParams.event,{
								cp:Volt.KPIParams.cp,appid:Volt.KPIParams.appid,inputby:''});
		}else if('UPDATEPOP' ==Volt.KPIParams.event){
			that.addEventLog(Volt.KPIParams.event,{
								cp:Volt.KPIParams.cp,appid:Volt.KPIParams.appid,inputby:''});
		}

		Volt.log('[message-box-popup.js] send event to view');
		Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
		Backbone.history.back();
	},

	onButton2Click : function() {
		Volt.log("onButton2ClickonButton2ClickonButton2ClickonButton2ClickonButton2Click");
		var  that = this;
		var data = {
			msgBoxtype : that.msgParam.type,
			eventType : CommonDefine.Event.SELECT_BTN2,
			appID : that.msgParam.appID,
		};
		Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
		Backbone.history.back();
	},

	onButton3Click : function() {

	},
	
	_onkeyEvent : function(keycode, type) {
		var ret = false;
		var that = this;
		if (type == Volt.EVENT_KEY_RELEASE)
			return true;
		switch (keycode) {
			case Volt.KEY_RETURN: {
				var data = {
					msgBoxtype : that.msgParam.type,
					eventType : CommonDefine.Event.EVENT_CLOSE_POPUP,
				};
				print('[message-box-popup-view.js] press return key');
				Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
				break;
			}
			default:
				break;
		}
		return ret;
	},

	addEventLog : function(eventName,options){
		Volt.log('[message-box-popup-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
		Volt.KPIMapper.addEventLog(eventName, {d : options});
	},
	
	hide : function(animationType) {
	    print('[message-box-popup-view.js] hide');
		var deferred = Q.defer();
		var that = this;
		this.firstTime = false;
		//Volt.Nav.endModal();
		//Volt.Nav.unblock();
		deferred.resolve();
		if(that.messageBox) {
            that.messageBox.removeListener(that.messageBoxListener);
            that.messageBox.destroy();
            that.messageBoxListener.destroy();
        }
		return deferred.promise;
	},
});

exports = messagePopup;
