var Q              = Volt.require('modules/q.js');
var Backbone       = Volt.require('lib/volt-backbone.js');
var LoadingView    = Volt.require('app/views/loading-view.js');
var CommonDefine   = Volt.require('app/common/common-define.js');
var CommonFucntion = Volt.require('app/common/common-function.js');
var CommonContent  = Volt.require('app/common/common-content.js');
var PanelCommon    = Volt.require('lib/panel-common.js');
var EventMediator  = Volt.require('app/common/event-mediator.js');
var Utils          = Volt.require('app/common/utils.js');
var gameControllerGuideTemplate = Volt.require("app/templates/1080/game-controller-guide-template-new.js");
var GameControllerGuideModel    = Volt.require('app/models/game-controller-guide-model.js');
var Gridlist 		            = Volt.require('app/views/grid-list-view.js');
var ErrorHandling = Volt.require("app/common/error-handling.js");
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');
var DeviceModel   = Volt.require('app/models/device-model.js');

var gameControllerGuide = PanelCommon.BaseView.extend({
	initialize : function () {
		Volt.log("[game-controller-guide-popup-view.js]  initialize.....");
		this.setWidget(PanelCommon.loadTemplate(gameControllerGuideTemplate.container, null, null, false));
	},

	show : function (id, animationType) {
		Volt.log("[game-controller-guide-popup-view.js]  show.....");
		EventMediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor, this);
		this.viewIsVisible = true;
		LoadingView.show(CommonDefine.Const.POPUP_LOADING);

		if (!this.widget) {
			this.setWidget(PanelCommon.loadTemplate(gameControllerGuideTemplate.container, null, null, false));
		}

		Volt.Nav.setRoot(this.widget);
		this.requestData();
	},

	requestData : function () {
		var that = this;
		function onSuccess() {
			Volt.log('[game-controller-guide-popup-view.js] requestData onSuccess');
			LoadingView.hide();
			if (that.widget) { //To make sure the widget exists
				if (that.viewIsVisible == true) {
					that.renderContent();
				}

				Volt.Nav.reload();
				that.widget.show();
				Volt.Nav.focus(Volt.Nav.getItem(0));
			}
		}

		function onError(msg) {
			Volt.log("[game-controller-guide-popup-view.js] requestData onError error msg-----" + JSON.stringify(msg.status));
			LoadingView.hide();
			var viewType = CommonContent.getViewType();
			if (viewType == '#popup') {
				ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR,"",JSON.stringify(msg.status)); 
			}
		}

		GameControllerGuideModel.fetch().then(onSuccess, onError);
	},

	renderContent : function () {
		this.renderBody();
		this.renderButton();
	},

	onKeyEvent : function (keyCode, keyType) {
		Volt.log('[game-controller-guide-popup-view.js] GameGuidePopupsKeyHandler   keyCode is :' + keyCode);
		if (keyType == Volt.EVENT_KEY_RELEASE) {
			return false;
		}
		
		switch (keyCode) {
		case Volt.KEY_JOYSTICK_LEFT:
		case Volt.KEY_JOYSTICK_RIGHT:
				this.widget.getDescendant('game-content-container').getChild(0).onKeyEvent(keyCode, keyType);
				return ;
				break;
		default:
			return false;
			break;
		}
	},
	
	renderBody : function () {
		Volt.log('[game-controller-guide-popup-view.js] renderBody');
		var container = this.widget.getDescendant('game-content-container');
		new contentChangeView().render(container);
	},

	renderButton : function () {
		Volt.log('[game-controller-guide-popup-view.js] renderButton');
		var container = this.widget.getChild('game-button-container');
		new buttonView().render(container);
	},

	onChangeCursor : function(visible){
		Volt.log('[game-controller-guide-popup-view.js] onChangeCursor visible = ' + visible);
		if(visible){
			Utils.Timer.clearTimeOut();
		}else{
			Utils.Timer.setTimerOut();
		}
	},
	
	hide : function (animationType) {
		Volt.log("[game-controller-guide-popup-view.js] hide .....");
		EventMediator.off(CommonDefine.Event.GAME_CONTROLLER_GUIDE);
		EventMediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR,null,this);
		
		this.viewIsVisible = false;
		LoadingView.hide();

		var deferred = Q.defer();
		if (this.widget) {
			this.widget.hide();
			Volt.setTimeout(function () {
				this.destroy(this.widget);
			}.bind(this), 1);
		}
		deferred.resolve();
		return deferred.promise;
	},

	destroy : function (widget) {
		if (!widget)
			return;

		this.widget.destroyChildren();
		this.widget = null;
	},

});

var contentChangeView = PanelCommon.BaseView.extend({
	leftArrow : null,
	rightArrow : null,
	grid: null,
	
	render : function (container) {

		if (!this.widget.created) {
			var gameControllerData = {
				style :CommonDefine.Const.HALO_ITEM_ALL_SAME,
				groups : [{
					modelArr : GameControllerGuideModel.get('guide_page_list')
				}]
			}
			
			var gridView = new Gridlist(gameControllerGuideTemplate.gridList, JSON.stringify(gameControllerData), scene.width, 771);
			 
			gridView.setItemData = function(mustache, modelData) {
				mustache.page = modelData['page'];

				var culContent = modelData['controller_url_list'];
				var bestForApp = modelData['best_for_app'];

				Volt.log('[game-controller-guide-popup-view.js] dim_flag = ' + modelData['dim_flag']);
				if('Y' == modelData['dim_flag']){
					mustache.page_text1 = modelData['dim_text'];
				}else{
					if(modelData['description'].indexOf('\r\n') > 0){
						mustache.page_text1 = modelData['description'].replace('\r\n', '\\n');
					}else if(modelData['description'].indexOf('\n') > 0){
						mustache.page_text1 = modelData['description'].replace('\n', '\\n');
					}else{
						mustache.page_text1 = modelData['description'];
					}
				}
				
				
				mustache.page_text2 = modelData['page_notice'];
				
				if(culContent.length == 1){
					mustache.page_text0 = modelData['controller_name'];
					mustache.page_image0 = culContent[0]['controller_url'];
					mustache.page_image1 = modelData['controller_icon_url'];
					
					//Note:Display the default image If no best game,need to check later
					for(var i = 0; i < bestForApp.length; ++i){
						mustache['best_for_app_image' + i] = bestForApp[i]['app_icon_url'];
						mustache['page_text' + parseInt(i + 3)] = bestForApp[i]['game_title'];
					}
				}else{//make sure in pageOne
					mustache.page_text0 = Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE');
					//because the picture in server is not the current order so sort it temporarily
					//PS:DaeWon Seo said:server team should sort it ,we don't need to sort
					for (var i = 0; i < culContent.length; i++) {
						if (Volt.i18n.t('TV_SID_SMART_TOUCH_CONTROL') == culContent[i]['controller_name']) {
							mustache.page_image0 = culContent[i]['controller_url'];
						} else if (Volt.i18n.t('COM_SID_KEYBOARD_KR_KEYBOARD') == culContent[i]['controller_name']) {
							mustache.page_image1 = culContent[i]['controller_url'];
						} else if (Volt.i18n.t('COM_SID_MOBILE_APP') == culContent[i]['controller_name']) {
							mustache.page_image2 = culContent[i]['controller_url'];
						} else if (Volt.i18n.t('COM_SID_GAMEPAD') == culContent[i]['controller_name']) {
							mustache.page_image3 = culContent[i]['controller_url'];
						} else if (Volt.i18n.t('COM_SID_STANDARD_REMOTE') == culContent[i]['controller_name']) {
							mustache.page_image4 = culContent[i]['controller_url'];
						}
					}
				}			
			}
			
			gridView.setItemTemplate = function(parent, parentWidth, parentHeight, data) {
				var pageIndex = parseInt(data.page);
				Volt.log('[game-controller-guide-popup-view.js] gridView.setItemTemplate pageIndex = ' + pageIndex);
				var xAdjust = scene.width * 0.010417;
				var widget = null;
				var pageTemplate = null;
				switch (pageIndex){
					case 1:
						PanelCommon.loadTemplate(gameControllerGuideTemplate.gamePageOne, data, parent);
						break;
					case 2:
						pageTemplate = gameControllerGuideTemplate.gamePageTwo;
						break;
					case 3:
						pageTemplate = gameControllerGuideTemplate.gamePageThree;
						break;
					case 4:
						pageTemplate = gameControllerGuideTemplate.gamePageFour;
						break;
					case 5:
						pageTemplate = gameControllerGuideTemplate.gamePageFive;
						break;
					case 6:
						pageTemplate = gameControllerGuideTemplate.gamePageSix;
						break;
					default :
						break;
				}
				
				if(pageTemplate){
					widget = PanelCommon.loadTemplate(pageTemplate, data, parent);
				}
				
				if(widget) {
				    widget.getChild(1).x = widget.getChild(5).x + widget.getChild(5).width + xAdjust;
				}
			
				Volt.log('[game-controller-guide-popup-view.js] gridView.setItemTemplate  children  ~~~~~~~~~~~~ '+parent.getChildCount());
			}
			
			gridView.itemLoaded = function(gridList,groupIndex, itemIndex){
				var data = gridList.getData(groupIndex, itemIndex);
				data.group = groupIndex;
				data.item = itemIndex;
		    }

			gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
				Volt.log('[game-controller-guide-popup-view.js] gridView.focusChanged fromItemIndex = ' + fromItemIndex + ',,,toItemIndex = ' + toItemIndex);
				if(DeviceModel.get('visibleCursor')){
					Utils.Timer.clearTimeOut();
				}else{
					Utils.Timer.setTimerOut();
				}
				
				var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
				
				EventMediator.trigger(CommonDefine.Event.GAME_CONTROLLER_GUIDE, {
					"num" : parseInt(data.page)
				});
				updatePageDepth(parseInt(data.page), container.getChild('page_depth'));

				//for voice Guide
				if(toItemIndex >= 0 && toGroupIndex >= 0){
					var currentPage = toItemIndex + 1;
					var totalPage = parseInt(GameControllerGuideModel.get('guide_page_cnt'));
					var voiceGuide = Volt.i18n.t('TV_SID_MIX_TTS_PAGE_OF').replace('<<A>>',currentPage).replace('<<B>>',totalPage) + ','; 
					if(0 == toItemIndex){
						voiceGuide += Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE') + ',';
					}else{
						voiceGuide += data.page_text0 + ',';
					}
					
					voiceGuide += data.page_text1 +',Close,button.';
					VoiceGuide.getVoiceGuide(voiceGuide,false);
				}
			}

			gridView.disableScroll();
			this.grid = gridView.render().widget;
			this.grid.enlargeFocusItem(0,0);
			this.grid.onFocus();

			
			this.grid.loopLeftFlag = false;
			this.grid.loopRightFlag = false;
			this.grid.rolloverEffect = false;
			
			container.addChild(this.grid);
			this.setWidget(this.grid);
			//page_depth
			PanelCommon.loadTemplate(gameControllerGuideTemplate.gamePageDepth, null, container);
			//left-right arrow
			this.renderLeftRightArrow(container);

			EventMediator.on(CommonDefine.Event.GAME_CONTROLLER_GUIDE, function (page) {
				if(1 == page.num){
					this.leftArrow.hide();
				}else{
					this.leftArrow.show();
				}

				if(parseInt(GameControllerGuideModel.get('guide_page_cnt')) == page.num){
					this.rightArrow.hide();
				}else{
					this.rightArrow.show();
				}
			}.bind(this));
			
			}
		
		return this;
	},

	renderLeftRightArrow : function (container) {
		Volt.log('[game-controller-guide-popup-view.js] renderLeftRightArrow .....');
		this.leftArrow = PanelCommon.loadTemplate(gameControllerGuideTemplate.LeftArrorw, null, container);
		this.leftArrow.addEventListener("OnMouseOver", function () {
			this.leftArrow.opacity = 255;
		}.bind(this));

		this.leftArrow.addEventListener("OnMouseOut", function () {
			this.leftArrow.opacity = 204;
		}.bind(this));

		this.leftArrow.addEventListener('OnMouseClick', function () {
			this.widget.moveFocus("Left");
		}.bind(this));

		this.rightArrow = PanelCommon.loadTemplate(gameControllerGuideTemplate.RightArrow, null, container);
		this.rightArrow.addEventListener("OnMouseOver", function () {
			this.rightArrow.opacity = 255;
		}.bind(this));

		this.rightArrow.addEventListener("OnMouseOut", function () {
			this.rightArrow.opacity = 204;
		}.bind(this));

		this.rightArrow.addEventListener('OnMouseClick', function () {
			this.widget.moveFocus("Right");
		}.bind(this));
	},
});

var buttonView = PanelCommon.BaseView.extend({
	closeBtn : null,
	btnListener : new ButtonListener(),
	
	initialize : function(){
		this.btnListener.onButtonClicked = function(){
			this.onSelect_closeBtn();
		}.bind(this)	
	},
	
	render : function (container) {
		var btnView = this;
		var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_E,
			buttonType : CommonDefine.Winset.BUTTON_TEXT,
		}
		this.setWidget(PanelCommon.loadTemplate(gameControllerGuideTemplate.buttonArea, btnStyle, container));
		var xPosition;
		this.closeBtn = this.widget.getDescendant('ctrlClsBtn');
		this.closeBtn.setBackgroundImage({state:'all',src:''});
		this.closeBtn.addListener(btnView.btnListener);
		
		EventMediator.on(CommonDefine.Event.GAME_CONTROLLER_GUIDE, function (page) {
			//for change the position of Close button
			xPosition = changeButtonX(page.num);
			this.closeBtn.x = xPosition;
		}.bind(this));

		return this.widget;
	},

	events : {
		'NAV_FOCUS' : 'onFocus_closeBtn',
		'NAV_BLUR' : 'onBlur_closeBtn',
	},

	onSelect_closeBtn : function () {
		Volt.log('[game-controller-guide-popup-view.js] buttonView.onSelect_closeBtn');
		Utils.Timer.clearTimeOut();
		Backbone.history.back();
	},

	onFocus_closeBtn : function () {
		Volt.log('[game-controller-guide-popup-view.js] buttonView.onFocus_closeBtn');
		this.closeBtn.setFocus();
	},

	onBlur_closeBtn : function (widget) {
	},
});

function updatePageDepth(pageIndex, container) {
	Volt.log('[game-controller-guide-popup-view.js] updatePageDepth pageIndex = ' + pageIndex);

	if(!container){
		Volt.log('[game-controller-guide-popup-view.js] updatePageDepth container is null just return');
		return;
	}
	
	var pageCnt = parseInt(GameControllerGuideModel.get('guide_page_cnt')) + 1;
	for (var index = 1; index < pageCnt; index++) {
		var childWgt = container.getChild(index - 1);
		if (index == pageIndex) {
			childWgt.src = Volt.getRemoteUrl('images/1080/games/g_gcg_comon_depth_h.png');
		} else {
			childWgt.src = Volt.getRemoteUrl('images/1080/games/g_gcg_comon_depth_n.png');
		}
	}
};

function changeButtonX(pageIndex) {
	Volt.log('[game-controller-guide-popup-view.js] changeButtonX pageIndex = ' + pageIndex);

	var x = 824;
	if (pageIndex != 1) {
		x = 1302;
	}

	return x;
};

exports = gameControllerGuide;