// Include libraries
var _              		= Volt.require('modules/underscore.js')._;
var Backbone       		= Volt.require('lib/volt-backbone.js');
var Q                   = Volt.require('modules/q.js');
var CommonDefine   		= Volt.require('app/common/common-define.js');
var PanelCommon    		= Volt.require('lib/panel-common.js');
var Mediator       		= Volt.require('app/common/event-mediator.js');
var CommonFucntion 		= Volt.require('app/common/common-function.js');
var DeletePopupTemplate = Volt.require('app/templates/1080/delete-popup-template.js');
var CommonContent 		= Volt.require('app/common/common-content.js');
var voltApiWrapper      = Volt.require("app/common/voltapi-wrapper.js");
var ErrorHandling       = Volt.require('app/common/error-handling.js');
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');

var deletePopupSelf = null;
var DeletePopup = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.container,
    params : null,
    totalNum : 0,
    currentNum : 0,
    progressBar : null,
    appID : null,
    isMulti : false,
    isShow : false,
    gamesID : null,
    descView : null,
    
    render : function() {
    },

    show : function(options) {
        Volt.log('[delete-popup.js] show options =' + options);
        deletePopupSelf = this;
        this.startListening();
        this.params = JSON.parse(options);
        this.currentNum = 0;
        this.appID = this.params.app_id;
        this.gamesID = this.params.app_id;
        this.isMulti = this.params.isMulti;
        if (!this.isMulti) {
            this.totalNum = 1;
        } else {
            this.totalNum = this.appID.length;
        }
        this.setWidget(PanelCommon.loadTemplate(this.template));
        this.widget.show();
        this.renderDescrption();
        this.renderProgressBar();
        this.isShow = true;
        //Volt.Nav.beginModal(this.widget);
        Volt.Nav.setRoot(this.widget);
        //this.setTimeOut();
    },

    startListening : function() {
        Mediator.on(CommonDefine.Event.EVENT_CLOSE_POPUP, _.bind(function() {
            //this.clearTimeOut();
            this.showDeleteFailPopup();
        }), this);
        Mediator.on(CommonDefine.Event.UNINSTALL_PROGRESS, this.updateProgress, this);
        Mediator.on(CommonDefine.Event.UNINSTALL, this.finishDelete, this);
    },

    stopListening : function() {
        Mediator.off(CommonDefine.Event.EVENT_CLOSE_POPUP,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL_PROGRESS,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL, null, this);
    },

    renderDescrption : function() {
        Volt.log('[delete-popup.js] renderDescrption');
        var container = this.widget.getChild('description-container');
        var description = new descriptionView().render().widget;
        container.addChild(description);
        var isInUSB = voltApiWrapper.isWidgetInstalledInUSB(this.appID);
        if (isInUSB) {
            //description.text = "Deleting ...\nDo not remove storage device.";
            description.getChild(0).text = "Deleting ...\nDo not remove storage device.";;
            this.widget.getChild('progressbar-container').y += description.height;
            this.widget.getChild('button-container').y += description.height;
            this.widget.getChild('description-container').height += description.height;
            this.widget.height += description.height;
            description.height *= 2;
            
        } else {
            //description.text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL');
            description.getChild(0).text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL');
        }
    },

    renderProgressBar : function() {
        var container = this.widget.getChild('progressbar-container');
        Volt.log('[delete-popup.js] renderProgressBar this.progressBar =' + this.progressBar);
        if(this.progressBar) {
            //this.progressBar.show();
        } else {
            this.progressBar = CommonContent.createProgressControl(container, 0, 0, parseInt(scene.width * 0.40625), 2);
        }
            
    },

    hide : function() {
        Volt.log('[delete-popup.js] hide');
        var deferred = Q.defer();

        //this.clearTimeOut();
        this.stopListening();
        if (CommonFucntion.checkValid(this.widget)) {
            this.widget.hide();
            this.destroy(this.widget);
            this.widget.destroy();
            this.widget = null; 
        }
        this.progressBar = null;
        this.appID = null;
        this.isShow = false;
        this.params = null;
        this.totalNum = 0;
        this.currentNum = 0;
        this.isMulti = false;
        this.gamesID = null;
        this.descView = null;
        deletePopupSelf = null;

        deferred.resolve();
        return deferred.promise;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                temp = widget.getChild(i);
                this.destroy(temp);
            }
        }
    },

    updateProgress : function(eventInfo) {
        Volt.log("[delete-popup.js] updateProgress");
        if (CommonFucntion.checkValid(this) && this.isMulti == false) {
            Volt.log("[delete-popup.js] updateProgress single delete");
            if (CommonFucntion.checkValid(eventInfo)) {
                Volt.log("[delete-popup.js] updateProgress result app_id =" + eventInfo.app_id + ", " + eventInfo.result);
                if (eventInfo.app_id == this.appID) {
                    if (eventInfo.result <= 100) {
                        if (CommonFucntion.checkValid(this.progressBar)) {
							if(eventInfo.result < 100){
								var voiceGuide = 'Deleting,' + eventInfo.result + ',percent,' + 'please wait,Cancel,button.';
                            	VoiceGuide.getVoiceGuide(voiceGuide, false);
							}

                            this.progressBar.value = eventInfo.result * parseInt(scene.width * 0.40625) / 100;
                            //this.setTimeOut();
                        }
                    }
                }
            }
        } else if(CommonFucntion.checkValid(this)) {
            Volt.log("[delete-popup.js] updateProgress multi delete");
            if (CommonFucntion.checkValid(eventInfo)) {
                for(var index = 0; index < this.totalNum; index ++){
                    if(this.gamesID[index] == eventInfo.app_id){
                        Volt.log("[delete-popup.js] updateProgress this.currentNum =" + this.currentNum);
                         
                        if (eventInfo.result <= 100) {
                            if (CommonFucntion.checkValid(this.progressBar)) {
                                var progressValue = ((this.currentNum + 1)/this.totalNum) * eventInfo.result * parseInt(scene.width * 0.40625)/ 100;
								if(eventInfo.result < 100){
									var num = this.currentNum + 1;
	                        		var voiceGuide = 'Deleting,' + num + 'of ' + this.totalNum + ',please wait,Cancel,button.';
	                        		VoiceGuide.getVoiceGuide(voiceGuide, false);
								}
						
								if(progressValue > this.progressBar.value){
                                    this.progressBar.value = progressValue;
                                }
                                Volt.log("[delete-popup.js] updateProgress multi delete this.progressBar.value =" + this.progressBar.value);
                                //this.setTimeOut();
                            }
                        }
                    }
                    break;
                }
            }
        }
    },

    finishDelete : function(eventInfo) {
        if (CommonFucntion.checkValid(this)) {
            if (this.isMulti == false) {
                Volt.log("[delete-popup.js] finish single delete");
                if (CommonFucntion.checkValid(eventInfo) && eventInfo.app_id == this.appID) {
                    Volt.log("[delete-popup.js] finish delete.isMulti == false");
					
                    this.showDeleteSuccessPopup(eventInfo.app_id);
                }
            } else {
                Volt.log("[delete-popup.js] receive multi delete event");
                if (CommonFucntion.checkValid(eventInfo)) {
                    Volt.log("[delete-popup.js] eventInfo.app_id = ", eventInfo.app_id);
                    Volt.log("[delete-popup.js] before appID = " + this.appID);
                    for (var i = 0; i < this.appID.length; ++i) {
                        if (this.appID[i] == eventInfo.app_id) {
                            this.currentNum++;
                            if (this.currentNum > this.totalNum) {
                                this.currentNum = this.totalNum;
                            }
                            this.appID.splice(i, 1);//delete the specified item
                            Volt.log("[delete-popup.js] after appID = " + this.appID);
                            break;
                        }
                    }

                    if (CommonFucntion.checkValid(this.progressBar)) {
                        this.progressBar.value = this.currentNum * 780 / this.totalNum;
                        deletePopupSelf.descView.widget.getChild(1).text = Volt.i18n.t('COM_MIX_TOTAL_KR_OVERALL').replace('<<A>>',this.currentNum + 1).replace('<<B>>',this.totalNum);
                        //this.setTimeOut();
                    }

                    if (this.currentNum == this.totalNum) {
                        Volt.log("[delete-popup.js] finish delete.isMulti == true");
                        var voiceGuide = Volt.i18n.t('TV_SID_MIX_COMPLETE').replace('<<A>>','') + this.currentNum + 'of ' + this.totalNum + ',OK,button.';
                        VoiceGuide.getVoiceGuide(voiceGuide, false);
                        this.showDeleteSuccessPopup(this.appID);
                    }
                }
            }
        }
    },

    showDeleteFailPopup : function() {
        Volt.log('[delete-popup.js] showDeleteFailPopup');
        Volt.setTimeout(function() {
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_FAIL);
        }, 200);
        Backbone.history.back();
    },

    showDeleteSuccessPopup : function(appId) {
        Volt.log('[delete-popup.js] showDeleteSuccessPopup appId =' + appId);
        Volt.setTimeout(function() {
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS, appId);
        }, 200);
        Backbone.history.back();
    }
});

//template of description
var descriptionView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.description,

    render : function() {
        deletePopupSelf.descView = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));
        if(!deletePopupSelf.isMulti){
            Volt.log('[delete-popup.js] descriptionView single');
            this.widget.getChild(1).hide();
        } else {
            Volt.log('[delete-popup.js] descriptionView multi');
            this.widget.getChild(1).show();
            this.widget.getChild(1).text = Volt.i18n.t('COM_MIX_TOTAL_KR_OVERALL').replace('<<A>>',deletePopupSelf.currentNum).replace('<<B>>',deletePopupSelf.totalNum);
        }
        return this;
    }
});

//exports = new DeletePopup;
exports = DeletePopup; 