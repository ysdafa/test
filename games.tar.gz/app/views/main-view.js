/** 
 * @author Wang Xiaojun(xiaojun.wang@samsung.com)/Zha Lihao(lihao.zha@samsung.com)
 * @fileoverview An example of Games Main View.
 * @date 2014/06/28
 * 
 * @version 1.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 * 
 * @note: Volt 2.0 maybe draw children according to index sequence
 */
// Include libraries
var Q              = Volt.require('modules/q.js');
var Backbone       = Volt.require('lib/volt-backbone.js');
var CommonDefine   = Volt.require('app/common/common-define.js');
var CommonFunction = Volt.require('app/common/common-function.js');
var CommonContent  = Volt.require('app/common/common-content.js');
var PanelCommon    = Volt.require('lib/panel-common.js');
var dimView        = Volt.require('app/views/dim-view.js');
var voltapi        = Volt.require("modules/voltapi.js");

var MainCategoryModel = Volt.require("app/models/main-category-model.js");
var CategoryCollection = Volt.require('app/models/category-base-collection.js');
var Mediator       = Volt.require('app/common/event-mediator.js');
var HeaderView     = Volt.require('app/views/main-header-view.js');
var CategoryView   = Volt.require('app/views/main-category-view.js');
var LoadingView    = Volt.require('app/views/loading-view.js');
var voltApiWrapper = Volt.require("app/common/voltapi-wrapper.js");
var OptionMenu     = Volt.require('app/views/option-menu-popup.js');
var ErrorHandling  = Volt.require('app/common/error-handling.js');
var Utils          = Volt.require('app/common/utils.js');
var localStorage   = Volt.require("lib/volt-local-storage.js");
var networkStatus  = Volt.require('app/common/network-state.js');
var DeviceModel    = Volt.require('app/models/device-model.js');
var MultiSelection = Volt.require('app/views/multi-selection.js');
var MagicKey       = Volt.require('app/common/MagicKey.js');

////////////////////////////////////////////////////////////////////////////////
var statusView = 'HIDE'; //SHOW HIDE ACTIVE DEACTIVE
var lastFocusWgt = null;

var MainView = PanelCommon.BaseView.extend({
	firstFocus     : true,
	headerView     : null,
	categoryView   : null,
	offResult      : false,
	requestSuccess : true,
	appPaused      : false,
	optionMenu     : null,
	isActive       : false,
	bUsbConnect    : false,
    
	initialize : function() {
		mainViewSelf = this;
	    MagicKey.addListener(CommonDefine.Magic.SHOW_VERSION, function(){
            ErrorHandling.showMessage(CommonDefine.Magic.SHOW_VERSION);
        });
	    MagicKey.addListener(CommonDefine.Magic.SHOW_PROCMEMORY, function(){
	        Volt.log("TTTTTTTTTTTTTTTTTTTTTTTTest " + VDUtil.getProcMemory());
        });
	},

	render : function() {
		Volt.log('[main-view.js] MainView.render');
		var MainTemplate = PanelCommon.requireTemplate('main');
		this.setWidget(CommonContent.loadTemplateInWinsetBackgroud(MainTemplate.container, null, null, false).getChild(0));
		this.renderHeader();
		this.renderCategory();
	},

    renderHeader: function() {
        Volt.log('[main-view.js] renderHeaderIcon');
        var container = this.widget.getDescendant('main-header-container');
        this.headerView = new HeaderView(container).render();
    },

    renderCategory: function(model,collection,options) {
        Volt.log('[main-view.js] renderCategory');
        // Check if categoryView exists, if so, just render(), otherwise, create a new one
        var container = this.widget.getChild('main-category-container');
        this.categoryView = new CategoryView(container).render(this);
    },

    // Show this View
    show: function(options, animationType) {
        Volt.log('[main-view.js]  show');
        
        //// @xiaojun.wang|20150110: Fix [Performance Test] DF150109-01321, DF141217-02470
        var deferred = Q.defer();
        
        statusView = 'SHOW';
        this.startListening();
        this.headerView.show();
        
        if (this.firstFocus) {
            // Show loading view first
            LoadingView.show(CommonDefine.Const.VIEW_LOADING);
            this.widget.show();
            Stage.show();
            
            Volt.setTimeout(function() {
                Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
                Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE,   this.active,   this);
                Mediator.on(CommonDefine.Event.GAMES_EXIT,          this.exit,     this);
          
                //call Volt.Nav.setRoot, for reset the root when coming back to this view.
                Volt.Nav.setRoot(this.widget);
                //var deferred = Q.defer();
                
                //this.widget.show();
                this.isActive = true;
        
                if (this.firstFocus) {
                    Volt.log('first enter main view');
                    //LoadingView.show(CommonDefine.Const.VIEW_LOADING);
                    Volt.Nav.focus(null);
                    this.offline();
                    Mediator.trigger('GAMES_POST_LOAD');
                    /*if(true === voltapi.rest.isOpened()){
                        this.requestData();
                    } else {
                        Mediator.on('SERVER_API_READY', this.requestData, this);
                    }*/
                    this.firstFocus = false;
                } else {
                    Volt.log('later enter main view');
                     //Mediator.trigger(CommonDefine.Event.MAIN_CATEGORY_ON_EVENT);
                     Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, true);
                     Mediator.trigger(CommonDefine.Const.UPDATE_ITEMS);
                }
            }.bind(this), 2000);
        } else {
            Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
            Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE,   this.active,   this);
            Mediator.on(CommonDefine.Event.GAMES_EXIT,          this.exit,     this);
      
            //call Volt.Nav.setRoot, for reset the root when coming back to this view.
            Volt.Nav.setRoot(this.widget);
            //var deferred = Q.defer();
            
            this.widget.show();
            this.isActive = true;
    
            if (this.firstFocus) {
                Volt.log('first enter main view');
                LoadingView.show(CommonDefine.Const.VIEW_LOADING);
                Volt.Nav.focus(null);
                this.offline();
                Mediator.trigger('GAMES_POST_LOAD');
                /*if(true === voltapi.rest.isOpened()){
                    this.requestData();
                } else {
                    Mediator.on('SERVER_API_READY', this.requestData, this);
                }*/
                this.firstFocus = false;
            } else {
                Volt.log('later enter main view');
                 //Mediator.trigger(CommonDefine.Event.MAIN_CATEGORY_ON_EVENT);
                 Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, true);
                 Mediator.trigger(CommonDefine.Const.UPDATE_ITEMS);
            }
        }
        
        this.bUsbConnect = false;
        this.bDeleteSuccessPopup = false;
        deferred.resolve();
        return deferred.promise;
    },
    
    offline: function(){
        var that = this; 
		//step1:if caching data is more than 24h,then don't need to read cache data
		var categoryCachingTime = localStorage.getItem('category-base-caching-time');
		var mainCachingTime = localStorage.getItem('main-category-caching-time');
		var currentTime = new Date().getTime();
		Volt.log('[main-view.js]offline currentTime = ' + currentTime);
		
		//step2:cache signState is not match now state,then don't need to read cache data
		if(currentTime - categoryCachingTime > 86400000 || currentTime - mainCachingTime > 86400000){
			Volt.log('[main-view.js] cacheing data is more than 24h,or cache signState is not match now state,do not need to read cache data ');
			return;
		}
		
        function onSuccess() {
            Volt.log('off line success');
            that.offResult = true;
            LoadingView.hide();
            //need trigger this event because spotlight will be blank before change:ready at first[for time sequence]
            Mediator.trigger(CommonDefine.Event.UPDATE_FOR_CACHE_DATA);
            Volt.log('onSuccess, Stage Show.....');
            Stage.show();
        }
        
        function onFail() {
            Volt.log('off line fail');
            that.offResult = false;
        }
        
        Q.all([
            CategoryCollection.offline(),
            MainCategoryModel.offline()
        ])
        .then(onSuccess, onFail);
    },
    
    requestData:function(){
        Volt.log('[main-view.js] request for real data');
        var that = this;
        function onSuccess(){
            Volt.log('[main-view.js] requestData onSuccess');
            LoadingView.hide();
            MainCategoryModel.ready();
            Mediator.trigger(CommonDefine.Event.UPDATE_FOR_REAL_DATA);
            Volt.log('requestData, Stage Show.....');
            Stage.show();
        }
        
        function onError(msg){
            Volt.log("error msg::::"+JSON.stringify(msg));
            LoadingView.hide();
            Volt.log('off line result::::'+that.offResult);
            if(!that.offResult){
                Volt.log('[main-view.js] requestData  request fail........');
                that.requestSuccess = false;
                Mediator.trigger(CommonDefine.Event.NETWORK_ERROR,msg);
                Volt.log('onError, Stage Show.....');
                Stage.show();
            }
        }
        
		var bReady = networkStatus.isReady();
		var status = networkStatus.getNetWorkState();
		Volt.log('[main-view.js]bReady::: '+bReady +' status:::'+status);

			Q.all([
					CategoryCollection.fetch(),
					MainCategoryModel.fetch({
						path : 'ALL',
						latest_app_id : ''
					})
				])
			.then(onSuccess, onError);

    },
    
    hide: function(animationType) {
        Volt.log('[main-view.js] hide ~~~~~~');
        var deferred = Q.defer();
        if (statusView == 'HIDE') {
            Volt.log('[main-view.js] main view have already pause');
            deferred.resolve();
            return deferred.promise;
        }

        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, this);
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, this);
        Mediator.off(CommonDefine.Event.GAMES_EXIT, null, this);

        statusView = 'HIDE';
        Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, false);
        Mediator.off(CommonDefine.Event.MAIN_CATEGORY_CACHE_DATA);
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR);

        this.stopListening();
        this.headerView.hide();
        this.isActive = false;
        this.bUsbConnect = false;
        lastFocusWgt = null;
        this.isActive = false;
        this.bUsbConnect = false;
        this.bDeleteSuccessPopup = false;
        
        this.widget.hide();

        deferred.resolve();
        return deferred.promise;
    },

	pause : function() {
        Volt.log('[main-view.js] pause~~~~~');
        if (statusView == 'PAUSE') {
            Volt.log('[main-view.js] main view have already pause');
            this.bDeleteSuccessPopup = CommonContent.isDeleteSuccessPopup();
            Volt.log('[main-view.js] bDeleteSuccessPopup =' + this.bDeleteSuccessPopup);
            if(this.bDeleteSuccessPopup && !this.isActive){
                //insertUSB or press menu when delete-success popup is showing
                Volt.log('[main-view.js] insertUSB or press menu key when delete-success popup is showing');
                this.getLastFocus();
                this.bUsbConnect = true;
            }
            return;
        }

        statusView = 'PAUSE';
        MultiSelection.pause();

        this.getLastFocus();

        Volt.Nav.blur();
		var mlsMode = voltapi.vconf.getValue('memory/mls/state');
		Volt.log(' vconf MLS_STATE : ' + mlsMode);
		if(mlsMode == 1){
			Volt.log('MLS mode, do not show dim');
		} else {
			dimView.show({
				parent : this.widget
			});
		}
	},
	
    resume : function(){
        Volt.log('[main-view.js] resume .....');
        if (statusView == 'SHOW') {
            Volt.log('[main-view.js] main view have already resume');
            return;
        }

        Volt.log('[main-view.js] resume .....statusView =' + statusView);
        Volt.log('[main-view.js] resume .....isActive =' + this.isActive);
        if (this.isActive) {
            dimView.hide();
            MultiSelection.resume();
            this.setLastFocus();
            statusView = 'SHOW';
            this.isActive = true;
        }

        if (!this.requestSuccess) {
            Volt.log('request fail');
            Volt.quit();
        }
    },
    
    active : function(){
        Volt.log('main view active......');
         if(this.isActive){
            Volt.log('[main-view]main view have already active');
            return;
        }
        
        this.isActive = true;
        Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, true);
        this.resume();
        this.startListening();
        this.bUsbConnect = false;
    },
    
    deactive : function(){
        Volt.log('main view deactive.......');
        if(!this.isActive){
            Volt.log('[main-view]main view have already deactive');
            return;
        }
        
        this.isActive = false;
        this.pause();
        this.stopListening();
		Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, false);
    },
    
    exit : function(bHide){
        Volt.log('main view exit.......');
		Volt.log('[main-view.js]bHide = '+ bHide);
		Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, false);
		if(bHide){
			voltApiWrapper.removeAllInstallList();
		}
    },
    
    getLastFocus : function() {
        Volt.log('[main-view.js] getLastFocus');
        if(MultiSelection.getState()){
            Volt.log('[main-view.js] getLastFocus multi-delete');
            //lastFocusWgt = this.widget.getDescendant('main-header-icon-setting');
            var tempWgt = Volt.Nav.getFocusedWidget();
            Volt.log('[main-view.js] getLastFocus multi-delete tempWgt =' + tempWgt);
            if(this.bDeleteSuccessPopup){
                lastFocusWgt = this.widget.getDescendant('main-header-icon-setting');
            } else if(tempWgt.hasOwnProperty("id") && "myPageContent" == tempWgt.id){
                Volt.log('[main-view.js] getLastFocus when multi-delete focus is on grid');
                lastFocusWgt = tempWgt;
            } else {
                lastFocusWgt = MultiSelection.getLastFocus();
            }
        } else {
            Volt.log('[main-view.js] getLastFocus -------');
            lastFocusWgt = Volt.Nav.getFocusedWidget();
        }
        
        Volt.log('[main-view.js] getLastFocus lastFocusWgt =' + lastFocusWgt);
        if(lastFocusWgt && lastFocusWgt.hasOwnProperty("id") && lastFocusWgt.id) {
            Volt.log('[main-view.js] getLastFocus lastFocusWgt.id =' + lastFocusWgt.id);
        }
        
        if(!lastFocusWgt || !lastFocusWgt.id) {
            Volt.log('[main-view.js] getLastFocus return');
            return;
        }
        
        switch(lastFocusWgt.id) {
            case "SPOTLIGNT_CONTENT":
                var focusedItem = lastFocusWgt.getFocusItemIndex();
                Volt.log('[main-view.js] getLastFocus spotlight (' + focusedItem.groupIndex + "," + focusedItem.itemIndex + ")");
                var params = {
                    widgetType : "grid",
                    widget : lastFocusWgt,
                    groupIndex : focusedItem.groupIndex,
                    itemIndex : focusedItem.itemIndex,
                    view : "spotlight",
                    refresh : false,
                };
                CommonContent.setLastFocusForGrid(params);
                break;
             case "myPageContent":
                var focusedItem = lastFocusWgt.getFocusItemIndex();
                Volt.log('[main-view.js] getLastFocus mypage (' + focusedItem.groupIndex + "," + focusedItem.itemIndex + ")");
                var params = {
                    widgetType : "grid",
                    widget : lastFocusWgt,
                    groupIndex : focusedItem.groupIndex,
                    itemIndex : focusedItem.itemIndex,
                    view : "mypage",
                    refresh : false,
                };
                CommonContent.setLastFocusForGrid(params);
                if(this.bUsbConnect){
                    Volt.log('[main-view.js] getLastFocus, insert USB');
                    Mediator.trigger("REMOVE_WHEN_INSERT_USB");
                    this.bUsbConnect = false;
                }

                break;
            default :
                CommonContent.setLastFocusForGrid(null);
                break;
        }
    },
    
    setLastFocus : function(){
        Volt.log('[main-view.js] setLastFocus');
        if(MultiSelection.isStatus("SHOW") && MultiSelection.isLastFocus()){
            Volt.Nav.setRoot(this.widget, {
                focus : MultiSelection.getLastFocus()
            });
            return;
        }
        
        Volt.log('[main-view.js] setLastFocus lastFocusWgt =' + lastFocusWgt);
        var lastFocusInMainView = CommonContent.getLastFocusForGrid();
        if(lastFocusInMainView){
            var mainViewWgt = lastFocusInMainView.widget;
            Volt.log('[main-view.js] setLastFocus mainViewWgt =' + mainViewWgt);
            if(mainViewWgt != lastFocusWgt){
                Volt.log('[main-view.js] setLastFocus focus has been moved');
                Volt.Nav.setRoot(this.widget, {
                    focus : lastFocusWgt
                });
                
            } else {
                Volt.log('[main-view.js] setLastFocus same widget');
                this.setLastFocusForMainView(lastFocusInMainView);
            }
        } else {
            Volt.log('[main-view.js] setLastFocus, lastfocus is not on grid.');
            if(this.bDeleteSuccessPopup && this.bUsbConnect){
                Volt.Nav.setRoot(this.widget,{focus : null});
                Volt.log('[main-view.js] setLastFocus, insertUSB or press menu when delete-success popup is showing');
                Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,lastFocusWgt);
                this.bDeleteSuccessPopup = false;
                CommonContent.resetDeleteSuccessPopup(false);
            } else if(MultiSelection.isStatus("SHOW") && !MultiSelection.isLastFocus() && this.bUsbConnect){
                Volt.log('[main-view.js] setLastFocus, insert USB when delete-check popup is showing or focus is on multi-select');
                Volt.Nav.setRoot(this.widget);
            } else {
                Volt.log('[main-view.js] getLastFocus bDeleteSuccessPopup =' + CommonContent.isDeleteSuccessPopup());
                if(this.bDeleteSuccessPopup ||CommonContent.isDeleteSuccessPopup()){
                    lastFocusWgt = this.widget.getDescendant('main-header-icon-setting');
                    CommonContent.resetDeleteSuccessPopup(false);
                }
                Volt.Nav.setRoot(this.widget,{focus : lastFocusWgt});
            }
        }
    },
    
    setLastFocusForMainView : function (lastFocusInMainView) {
        Volt.log('[main-view.js] setLastFocusForMainView');
        Volt.log('[main-view.js] setLastFocusForMainView ..... view =' + lastFocusInMainView.view);
        
        switch(lastFocusInMainView.view) {
            case "spotlight" :
                Volt.Nav.setRoot(this.widget, {
                    focus : lastFocusInMainView.widget
                });
                break;
            case "mypage" :
                Volt.Nav.setRoot(this.widget,{focus:null});
                Mediator.trigger(CommonDefine.Event.SET_ROOT_COMPLETE);
                break;
            default:
                break;
        }
    },
    
	handleMenuDestroy : function (){
		dimView.hide();
		this.optionMenu = null;
		CommonContent.setOptionMenu(null);
		this.headerView.settingBtn.setBackgroundImage({state:"focused",src:"images/1080/highlight/ksc_focus.png"});
		this.headerView.settingBtn.setBackgroundImage({state:"focused-roll-over",src:"images/1080/highlight/ksc_focus.png"});
		Mediator.off(CommonDefine.Event.DESTROY_MENU,null,this);
	},

	addEventLog : function(eventName,options){
		Volt.log('[main-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
		if(!eventName){
			return;
		}

		Volt.KPIMapper.addEventLog(eventName, {d : options,});
	},
	
	onOptionMenu : function(index) {
		Volt.log('[option-menu-popup.js] onOptionMenuCB index' + index);
		if (this.optionPopup.ifDim({index:index})) {
			return;
		}
		//	this.optionPopup.clearTimeout();
		var option = this.optionPopup.text({index:index});
		Volt.log('[option-menu-popup.js] onOptionMenuCB text = ' + option);

		switch(option) {
			case Volt.i18n.t('UID_SIGN_IN'):
			case Volt.i18n.t('UID_SIGN_OUT'):
				mainViewSelf.addEventLog('JUMPSSO',{cp : '',ssoby: 'option',inputby:'',});
				voltApiWrapper.startSSOPopup();
				this.hide();
				break;
                
			case Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE'):
				mainViewSelf.addEventLog('OPTIONGCGUIDE',{cp : '',inputby:'',});
				if (!networkStatus.getNetWorkState()) {
					this.hide();
					var ErrorHandling = Volt.require('app/common/error-handling.js');
					ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR, '', '505');
				} else {
					this.hide();
					Backbone.history.navigate('popup/game-controller-guide-new', {
						trigger : true
					});
				}
				break;
                
			case Volt.i18n.t('TV_SID_GAMES_7'):
				mainViewSelf.addEventLog('OPTIONDELETE',{cp : '',inputby:'',});
				this.hide();
                Volt.log('multi selection delete..........');
                MultiSelection.setState('delete');                
				Mediator.trigger('EVENT_PRESS_DELETE_MENU');
				break;
                
			case Volt.i18n.t('TV_SID_EDIT_NICKNAME'):
				mainViewSelf.addEventLog('OPTIONNICK',{cp : '',inputby:'',});
				this.hide();
				var params = {
					"event" : "edit-name",
					"type" : 'input-text',
					'cp' : Volt.KPIMapper.getPageEvent().pageEvent,
					'from': 'click-optionMenu',
				};
				Backbone.history.navigate('popup/' + JSON.stringify(params), {
					trigger : true
				});
				break;
                
			case Volt.i18n.t('TV_SID_GAMES_6'):
				mainViewSelf.addEventLog('OPTIONUPDATE',{cp : '',inputby:'',});
				this.hide();
                MultiSelection.setState('update');
				Mediator.trigger('EVENT_PRESS_UPDATE_MENU');
				break;
                
			case Volt.i18n.t('COM_SORT_BY_COLON').replace(':',''):
				if (this.subMenuSelected != subIndex) {
					this.subMenuSelected = subIndex;
				}

				this.optionPopup.setSubSelectIndex(2, this.subMenuSelected);
				var text = this.optionPopup.getSubListText(index, subIndex);
				this.hide();
				Mediator.trigger(CommonDefine.Event.EVENT_SORT, text);
				break;

			default:
				this.hide();
				break;
		}
	},
    
	showOptionMenu : function() {
		Volt.log('[main-view.js] showOptionMenu ~~~~~');
		Mediator.on(CommonDefine.Event.DESTROY_MENU, this.handleMenuDestroy, this);
		var currentPage = MainCategoryModel.get('category');
		dimView.show({
			parent : this.widget
		});
		var that = this;
		var menuItemArr = [Volt.i18n.t('UID_SIGN_IN'), Volt.i18n.t('TV_SID_GAMES_7'), Volt.i18n.t('TV_SID_EDIT_NICKNAME'), Volt.i18n.t('TV_SID_GAMES_6'), Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE')];
		this.optionMenu = new OptionMenu({
			style : CommonDefine.Const.OPTION_MENU,
			listItems : menuItemArr,
			bgColor : {
				r : 15,
				g : 24,
				b : 38,
				a : 255
			},
			callback : that.onOptionMenu
		});
		this.optionMenu.show(currentPage);
		CommonContent.setOptionMenu(this.optionMenu);
	},
	
	updateFlag : function () {
	    Volt.log('[main-view.js] connectUSB updateFlag');
	    this.bUsbConnect = true;
	},
	
    startListening : function() {
        Mediator.on(CommonDefine.Event.OPTION_MENU_POPUP,        this.showOptionMenu,      this);
        Mediator.on(CommonDefine.Event.MSGBOX_BUTTON,            this.processMsgBoxEvent,  this);
        //Mediator.on(CommonDefine.Event.EVENT_DELETE_SUCCESS, CommonContent.unInstallSuccess, this);
        Mediator.on(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, CommonContent.showAppSyncError, this);
        Mediator.on(CommonDefine.Event.INSTALL_FAIL,             CommonContent.installFail, this);
        Mediator.on('SERVER_API_READY',                          this.requestData,          this);
        Mediator.on(CommonDefine.Event.CONNECT_USB, this.updateFlag, this);
    },
    
    stopListening: function(){
        Mediator.off(CommonDefine.Event.OPTION_MENU_POPUP, null, this);
        Mediator.off(CommonDefine.Event.MSGBOX_BUTTON, null, this);
        //Mediator.off(CommonDefine.Event.EVENT_DELETE_SUCCESS);
        Mediator.off(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, null, this);
        Mediator.off(CommonDefine.Event.INSTALL_FAIL, null, this);
        Mediator.off(CommonDefine.Event.CONNECT_USB, null, this);
        Mediator.off('SERVER_API_READY', null, this);
    },

	onKeyEvent : function (keyCode, keyType) {
		Volt.log('[main-view.js] keyCode is :' + keyCode);
		if (keyType == Volt.EVENT_KEY_RELEASE) {
			return false;
		}

		var category = MainCategoryModel.get('category');
		Volt.log('[main-view.js] category is :' + category);
		
		if (category == 'C0070') {
			if(keyCode === Volt.KEY_RETURN && LoadingView.viewIsVisiable === false) {
				Volt.log('trigger : EVENT_RETURN_EDIT_MODE');
				Mediator.trigger('EVENT_RETURN_EDIT_MODE');
			}
            
			var widget = Volt.Nav.getFocusedWidget();
			if (widget && widget.hasOwnProperty('id') && 'COUPON_BOX' == widget.id) {
				if (keyType == Volt.EVENT_KEY_PRESS) {
					if (keyCode != Volt.KEY_JOYSTICK_OK
						 && keyCode != Volt.KEY_RETURN && keyCode != Volt.KEY_EXIT
						 && keyCode != Volt.KEY_JOYSTICK_LEFT && keyCode != Volt.KEY_JOYSTICK_RIGHT
						 && keyCode != Volt.KEY_JOYSTICK_UP && keyCode != Volt.KEY_JOYSTICK_DOWN
						 && keyCode != Volt.KEY_RED && keyCode != Volt.KEY_GREEN && keyCode != Volt.KEY_YELLOW) {
                        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_GAME_CENTER);
						return true;
					}
				}
			}
		}
		return false;
	},

	processMsgBoxEvent: function(data) {
		Volt.log('[main-view.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
		if(data.eventType == CommonDefine.Event.SELECT_BTN1) {
			switch(data.msgBoxtype) {
				case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
					voltApiWrapper.startSSOPopup();
					break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                    var aulApp = new Aul();
                    aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                    break;
				default:
					break;
			}
		} else if(data.eventType == CommonDefine.Event.SELECT_BTN2) {
			
		}
	},	
});

exports=MainView;
