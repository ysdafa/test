// Include libraries
var _              = Volt.require('modules/underscore.js')._;
var Backbone       = Volt.require('lib/volt-backbone.js');
var Q              = Volt.require('modules/q.js');
var CommonDefine   = Volt.require('app/common/common-define.js');
var CommonContent  = Volt.require('app/common/common-content.js');
var PanelCommon    = Volt.require('lib/panel-common.js');
var Mediator       = Volt.require('app/common/event-mediator.js');
var CommonFucntion = Volt.require('app/common/common-function.js');
var CPInstallPopupTemplate = Volt.require('app/templates/1080/cpinstall-popup-template.js');
var voltApiWrapper    = Volt.require("app/common/voltapi-wrapper.js");

var cpInstallPopup = PanelCommon.BaseView.extend({
    template : CPInstallPopupTemplate.container,
    params : null,
    progressBar : null,
    appID : null,
    timer : null,
    isShow : false,

    initialize : function() {
        installPopupSelf = this;
    },
    
    render : function() {
    },

    show : function(options) {
        Volt.log('[cpinstall-popup.js] show options =' + options);
        this.startListening();
        this.params = JSON.parse(options);
        this.appID = this.params.app_id;
        this.setWidget(PanelCommon.loadTemplate(this.template));
        this.widget.show();
        this.isShow = true;
        this.renderDescrption();
        this.renderProgressBar();
        this.renderButton();
        Volt.Nav.setRoot(this.widget);
        //this.setTimeOut();
    },

    startListening : function() {
        Mediator.on(CommonDefine.Event.EVENT_CLOSE_POPUP, _.bind(function() {
            //this.clearTimeOut();
           Backbone.history.back();
        }), this);
        Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgress, this);
        Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
    },

    stopListening : function() {
        Mediator.off(CommonDefine.Event.EVENT_CLOSE_POPUP,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL_PROGRESS,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL, null, this);
    },

    renderDescrption : function() {
        Volt.log('[cpinstall-popup.js] renderDescrption');
        var container = this.widget.getChild('description-container');
        var description = new descriptionView().render().widget;
        container.addChild(description);
        
        var isInUSB = voltApiWrapper.isWidgetInstalledInUSB(this.appID);
        if (isInUSB) {
            description.text = "Downloading ...\nDo not remove storage device.";
            this.widget.getChild('progressbar-container').y += description.height;
            this.widget.getChild('button-container').y += description.height;
            this.widget.getChild('description-container').height += description.height;
            this.widget.height += description.height;
            description.height *= 2;
        } else {
            description.text = "Downloading ...";
        }
    },

    renderProgressBar : function() {
        var container = this.widget.getChild('progressbar-container');
        Volt.log('[cpinstall-popup.js] render single ProgressBar');
        this.progressBar = CommonContent.createProgressControl(container, 0, 0, 780, 2);
    },
    
    renderButton : function() {
        Volt.log('[cpinstall-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        container.addChild(new buttonView().render().widget);
    },

    hide : function() {
        Volt.log('[cpinstall-popup.js] hide');
        var deferred = Q.defer();
        
        //this.clearTimeOut();
        this.stopListening();
        
        Volt.log('[cpinstall-popup.js] hide this.widget =' + this.widget);
        if (CommonFucntion.checkValid(this.widget)) {
            this.widget.hide();
            this.destroy(this.widget);
            this.widget.destroy();
            this.widget = null;
        }
        this.progressBar = null;
        this.appID = null;
        this.isShow = false;
        
        deferred.resolve();
        return deferred.promise;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                temp = widget.getChild(i);
                this.destroy(temp);
            }
        }
    },

    updateProgress : function(eventInfo) {
        if (CommonFucntion.checkValid(this)) {
            Volt.log("[cpinstall-popup.js] updateProgress");
            if (CommonFucntion.checkValid(eventInfo)) {
                Volt.log("[cpinstall-popup.js] " + eventInfo.app_id + " " + eventInfo.result);
                if (eventInfo.app_id == this.appID) {
                    if (eventInfo.result <= 100) {
                        if (CommonFucntion.checkValid(this.progressBar)) {
                            this.progressBar.value = eventInfo.result * 780 / 100;
                            //this.setTimeOut();
                        }
                    }
                }
            }
        }
    },

    finishInstall : function(eventInfo) {
        if (CommonFucntion.checkValid(this)) {
            Volt.log("[cpinstall-popup.js] finishInstall");
            if (CommonFucntion.checkValid(eventInfo) && eventInfo.app_id == this.appID) {
                Volt.log("trigger CommonDefine.Event.EVENT_FINISH_CPINSTALL, finishInstall");
                //this.hide();
                Backbone.history.back();
            }
        }
    },
    
    /*
    setTimeOut : function() {
        this.clearTimeOut();
        this.timer = Volt.setTimeout(function() {
            Volt.log('[cpinstall-popup.js] time out');
           Backbone.history.back();
        }, 1000 * 10);

    },

    clearTimeOut : function() {
        if (this.timer != null && this.timer != undefined) {
            Volt.clearTimeout(this.timer);
        }
    },
    */
});

//template of description
var descriptionView = PanelCommon.BaseView.extend({
    template : CPInstallPopupTemplate.description,

    render : function() {
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

var buttonView = PanelCommon.BaseView.extend({
    template : CPInstallPopupTemplate.button,
    btn1 : null,

    render : function(Parent) {
        print('[cpinstall-popup.js] buttonView.render');
        popupBtnView = this;
        var btnListener = new ButtonListener();
        btnListener.onButtonClicked=function(btn,type){
            voltApiWrapper.cancelInstallApp(installPopupSelf.appID);
			var data = {
				info: 'cancel Install',
				app_id: installPopupSelf.appID,
			};
			Mediator.trigger(CommonDefine.Event.EVENT_FINISH_CPINSTALL, data);
        }
        
        var btnStyle = {
			style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1,
			buttonType : CommonDefine.Winset.BUTTON_TEXT,
        };
        
        this.setWidget(PanelCommon.loadTemplate(this.template,btnStyle));
        this.btn1= this.widget.getDescendant('Cancel');
        this.btn1.addListener(btnListener);
        return this;
    },
});

//exports = new cpInstallPopup;
exports = cpInstallPopup; 