var Backbone = Volt.require('lib/volt-backbone.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var NoContentTemplate = Volt.require('app/templates/1080/no-content-template.js');
var CommonFucntion = Volt.require('app/common/common-function.js');
var CommonDefine = Volt.require('app/common/common-define.js');
var _ = Volt.require('modules/underscore.js')._;
var VoiceGuide    = Volt.require('app/common/voiceGuide.js');

var NoContentView = PanelCommon.BaseView.extend({
	template : null,
	btnReturn : null,

	render : function(wgtID, txtToShow, noContentViewType) {
		print('[no-content-view.js] NoContentView.render');
		if (arguments.length != 3) {
			print("------[no-content-view.js] param number must be 3!------");
			return;
		}
		
		if(isNaN(noContentViewType)){
			print("------[no-content-view.js] third param must be number------");
			return;
		}
		switch(noContentViewType) {
			case CommonDefine.Const.NO_CONTENT_GENERAL:
				this.template = NoContentTemplate.general;
				break;
			case CommonDefine.Const.NO_CONTENT_WITH_BTN:
				this.template = NoContentTemplate.myPage;
				break;
			case CommonDefine.Const.NO_CONTENT_COUPON:
				this.template = NoContentTemplate.coupon;
				break;
			default:
				this.template = NoContentTemplate.general;
		}

		this.setWidget(PanelCommon.loadTemplate(this.template));

		if ( typeof (wgtID) === 'string') {
			this.widget.id = wgtID;
		}
		if ( typeof (txtToShow) === 'string') {
			this.widget.getChild(0).text = txtToShow;
		} else {
			this.widget.getChild(0).text = "The second param should be string type!";
		}
		if (CommonDefine.Const.NO_CONTENT_COUPON == noContentViewType||noContentViewType==CommonDefine.Const.NO_CONTENT_WITH_BTN) {
			var btnLsner = new ButtonListener();
			btnLsner.onButtonClicked = function(btn,type){
				switch(btn.id){
					case 'return':
					Backbone.history.back();
					break;
					case 'troubleshoot':
					var aulApp = new Aul();
                    aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                    break;
                    default:
                    break;
				}
				
			};
			var btnStyle = {
				style : CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_E,
				buttonType : CommonDefine.Winset.BUTTON_TEXT,
			};
			this.btnReturn = PanelCommon.loadTemplate(NoContentTemplate.button,btnStyle,this.widget.getDescendant('RETURN'));
			this.btnReturn.addListener(btnLsner);
			if(CommonDefine.Const.NO_CONTENT_COUPON == noContentViewType){
				this.btnReturn.setText({state:'all',text:Volt.i18n.t('COM_SID_RETURN')});
				this.btnReturn.id = 'return';
			}else{
				this.btnReturn.setText({state:'all',text:'Troubleshoot'});
				this.btnReturn.id = 'troubleshoot';
			}
			
			this.widget.getDescendant('RETURN').addEventListener('OnMouseOver', function() {
				Volt.log("[no-content-view.js] ------------- button setFocus");
				this.btnReturn.setFocus();
			}.bind(this));
			
			this.widget.onFocus = _.bind(this.onFocus,this);
			this.widget.onBlur = _.bind(this.onBlur,this);
		}
		return this;
	},
	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur',
	},
	onFocus : function(widget) {
		Volt.log('[no-content-view.js] onFocusReturn this.btnReturn.text() = ' + this.btnReturn.text());
		this.btnReturn.setFocus();
		var voiceGuide = '';
		if('couponNC' == this.widget.id){
			voiceGuide += 'Coupons,' + this.widget.getChild(0).text + ',' + this.btnReturn.text() + ',buttons.';
			this.getVoiceGuide(voiceGuide,false);
		}
	},

	onBlur : function(widget) {
		print('[no-content-view.js] onBlurReturn');
		//this.btnReturn.killFocus();
	},

	getVoiceGuide:function(voiceGuide,isCategory){
		Volt.log('[no-content-view.js] getVoiceGuide voiceGuide = ' + voiceGuide + ',,,isCategory= ' + isCategory);
		VoiceGuide.getVoiceGuide(voiceGuide, isCategory);
	},
});

exports = NoContentView;
