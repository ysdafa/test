// Include libraries

var _         = Volt.require('modules/underscore.js')._;
var Q         = Volt.require('modules/q.js');
var Backbone  = Volt.require('lib/volt-backbone.js');
var Mediator  = Volt.require('app/common/event-mediator.js');
var Utils     = Volt.require('app/common/utils.js');

var PanelCommon     = Volt.require('lib/panel-common.js');
var CommonDefine    = Volt.require('app/common/common-define.js');
var CommonFucntion  = Volt.require('app/common/common-function.js');
var MessageTemplate = Volt.require("app/templates/1080/message-popup-template.js");

var contentheight;
var popInfo = null;
var focusID = '';

var messagePopup = PanelCommon.BaseView.extend({
	template : MessageTemplate.container,
	buttonView: null,
    bClickButton: false,
	initialize : function(){
        that = this;
	},
    
	render: function(){
		
	},
    
    show : function(param,animationType){
    	print('[message-popup-view.js] show');
        this.setWidget(PanelCommon.loadTemplate(this.template));
        this.renderBG(param);
        Volt.Nav.setRoot(this.widget);
		//Volt.Nav.focus(Volt.Nav.getItem(0));	
		this.setCustomFocus();
		PanelCommon.doViewSwitchAni(this.widget,animationType);
    },
    
    renderBG: function(param){   
		
		popInfo =JSON.parse(param);
		var bg = this.widget.getChild('bg-container');
		bg.hide();
		if (popInfo.title == true){
			this.renderTitle();
		}
		this.renderContent();
		if (popInfo.button == true){
			this.renderButton(popInfo.prePage);
			bg.height = contentheight + 118;
		}
		else{
		bg.height = contentheight + 46;
		}
		bg.y = (1080 - bg.height)/2;
		bg.show();
    },
    
    renderTitle : function(){
        print('[message-popup-view.js] renderTitle');
		var bg = this.widget.getChild('bg-container');
        var container = bg.getChild('message-title-container');
        container.addChild(new titleView().render().widget);
    },
    
    renderContent : function(){
        print('[message-popup-view.js] renderContent');
		var bg = this.widget.getChild('bg-container');
        var container = bg.getChild('message-content-container');
		var content = new contentView().render(container).widget;
		print("content.height:"+content.height+"content.y:"+content.y);
		contentheight = content.height + content.y;
        container.addChild(content);
    },
    
    renderButton : function(prePage){
        print('[message-popup-view.js] renderContent');
		var bg = this.widget.getChild('bg-container');
        var container = bg.getChild('message-button-container');
        this.buttonView = new buttonView();
        container.addChild(this.buttonView.render(prePage).widget);
    },
    
    hide : function(animationType){
    	print("[message-popup.js] hide");
		if(that.bClickButton != true) {
			var data = {
				msgBoxtype : popInfo.type,
				eventType : CommonDefine.Event.EVENT_CLOSE_POPUP,
				appID: popInfo.appID,
			};
			print('[message-popup.js] press return or exit key');
			Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
		}

		//Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
		
		Volt.Nav.focus(null);
        var deferred = Q.defer(); 
		if (!this.widget)
			return;
		Volt.setTimeout(function(){
			this.widget.destroyChildren();
			this.widget.destroy();
			this.widget=null;
			that.bClickButton = false;
		}.bind(this),1);
		
		deferred.resolve();
        return deferred.promise;
    },
    
    showMessage: function(message){
        this.type = 'widget';
        this.render();
        this.show(message);
        Volt.Nav.beginModal(this.widget);
		this.setCustomFocus();
		this.widget.onKeyEvent = _.bind(this._onkeyEvent, this);
    },
	
    setCustomFocus: function(){
		if(CommonFucntion.checkValid(that.buttonView)) {
			if (!(typeof popInfo.focusIndex === 'undefined')){
				if 	(popInfo.focusIndex == 2){
						Volt.Nav.focus(Volt.Nav.getItem(1));
					}
				else {
					Volt.Nav.focus(Volt.Nav.getItem(0));
				}	
			}
			else{
			Volt.Nav.focus(Volt.Nav.getItem(0));
			}
		}
	},
	
    _onkeyEvent: function(keycode, type) {
		var ret = false;
		if (type == Volt.EVENT_KEY_RELEASE) 
			return true;
		switch (keycode) {
			case Volt.KEY_RETURN: {
				var data = {
					msgBoxtype : popInfo.type,
					eventType : CommonDefine.Event.EVENT_CLOSE_POPUP,
				};
				print('[message-popup-view.js] press return key');
				Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
				ret = true;
				break;
			}
			case Volt.KEY_JOYSTICK_LEFT: {
				print('[message-popup-view.js] focusID = ' + focusID);
				if(focusID == 'message_popup_2_btn2') {
					if(CommonFucntion.checkValid(that.buttonView)) {
						that.buttonView.onFocus_btn1();
						that.buttonView.onBlur_btn2();
					}
				}
				ret = true;
				break;
			}
			case Volt.KEY_JOYSTICK_RIGHT: {
				print('[message-popup-view.js] focusID = ' + focusID);
				if(focusID == 'message_popup_2_btn1') {
					if(CommonFucntion.checkValid(that.buttonView)) {
						that.buttonView.onFocus_btn2();
						that.buttonView.onBlur_btn1();
					}
				}
				ret = true;
				break;
			}
			case Volt.KEY_JOYSTICK_OK: {
				print('[message-popup-view.js] focusID = ' + focusID);
				var data = {
					msgBoxtype : popInfo.type,
					eventType : CommonDefine.Event.SELECT_BTN1,
					appID: popInfo.appID,
				};
				if(focusID == 'message_popup_2_btn2') {
					data.eventType = CommonDefine.Event.SELECT_BTN2;
				}
				print('[message-popup-view.js] send event');
				Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
				ret = true;
				break;
			}
			default:
				break;
		}
		return ret;
    },
    
    destroy: function(){
        Volt.Nav.endModal();
        this.hide();
    }
});

var titleView = PanelCommon.BaseView.extend({
    template : MessageTemplate.title,

	initialize : function(){

	},

	render : function(){
		if (!this.widget.created) {
        this.setWidget(PanelCommon.loadTemplate(this.template));
		this.widget.created = true;
		}
		var title_widget = this.widget.getChild('share_title_text');
		title_widget.text = param.titletext;
        return this;
    },
    
	destroy : function(){
		this.widget.destroy();
    },
});

var contentView = PanelCommon.BaseView.extend({
	template: MessageTemplate.content_area,
	initialize:function(){

	},
	
    render : function(bg){
		print('[message-popup-view.js] contentView.render');
        if (!this.widget.created) {
			var message_content_Text = new TextWidgetEx({
				x:399,
				y:48,
				width: 1122,
				textColor:{r:255, g:255, b:255, a:230},
				font:"SVD Medium_EU 34px",
				horizontalAlignment:"left",
				verticalAlignment:"center",
				//singleLineMode: true,
				text:popInfo.contenttext,
				parent:bg
			})
            this.setWidget(message_content_Text);
			print("message_content_Text.width:103"+message_content_Text.width);
			//message_content_Text.height = Math.ceil(message_content_Text.width/1122)*48;
			this.widget.height = message_content_Text.height;
			//message_content_Text.width = 1122;
			message_content_Text.horizontalAlignment = "center";
			//message_content_Text.singleLineMode = false;
			if (popInfo.title == true){
				this.widget.y = 108;
			};
	    	this.widget.created = true;
        }
        return this;

    },
    
    destroy : function(){
		this.widget.destroy();
    },
});

var buttonView = PanelCommon.BaseView.extend({
	template:MessageTemplate.button2,
	btnView:null,
	btn1:null,
	btn2:null,
	prePage : null,

	initialize : function(){
		
	},
	
    render : function(prePage){
		this.prePage = prePage;
		btnView = this;
		if (popInfo.buttonNum == 1){
			this.template = MessageTemplate.button1;
			this.setWidget(PanelCommon.loadTemplate(this.template));
			print ("contentheight:"+contentheight);
			this.widget.y = contentheight+22;
			var param0 = {
					x:0,
					y:0,
					width: 270,
					height: 66,
					text: popInfo.btn1Name,
					parent:this.widget.getChild('message_popup_1_btn1'),
				}
			this.btn1 = CommonFucntion.initButton(param0);
			this.btn1.setMouseClickCallback(
			function(){
				print("button post click callback");
				btnView.onSelect_btn1();
		}
            );	
		} else {
		this.setWidget(PanelCommon.loadTemplate(this.template));
		this.widget.y = contentheight+22;
            var param1 = {
			x:0,
			y:0,
			width: 270,
			height: 66,
			text: popInfo.btn1Name,
			parent:this.widget.getChild('message_popup_2_btn1'),
		}
		this.btn1 = CommonFucntion.initButton(param1);
		this.btn1.setMouseClickCallback(
            function(){
                print("button post click callback");
                btnView.onSelect_btn1();
                }
            );
            
            var param2 = {
			x:0,
			y:0,
			width: 270,
			height: 66,
			text: popInfo.btn2Name,
			parent:this.widget.getChild('message_popup_2_btn2'),
		}
		this.btn2 = CommonFucntion.initButton(param2);
		this.btn2.setMouseClickCallback(
            function(){
                print("button post click callback");
                btnView.onSelect_btn2();
                }
            );
		}
        
		if(CommonFucntion.checkValid(this.btn1)) {
			print('[message-popup.js] CommonFucntion.checkValid(this.btn1)');
			this.btn1.stateBorder[this.btn1.btnState.FOCUS] = {width:4, color:{r:255, g:255, b:255, a:255}};
			this.btn1.getFocus();
		}
		return this;
    },
    
    events: {
		NAV_SELECT:'onSelect',
		'NAV_FOCUS #message_popup_2_btn1':'onFocus_btn1',
		'NAV_FOCUS #message_popup_2_btn2':'onFocus_btn2',
		'NAV_FOCUS #message_popup_1_btn1':'onFocus_btn1',
		'NAV_SELECT #message_popup_2_btn1':'onSelect_btn1',
		'NAV_SELECT #message_popup_2_btn2':'onSelect_btn2',
		'NAV_SELECT #message_popup_1_btn1':'onSelect_btn1',
		'NAV_BLUR #message_popup_1_btn1':'onBlur_btn1',
		'NAV_BLUR #message_popup_2_btn1':'onBlur_btn1',
		'NAV_BLUR #message_popup_2_btn2':'onBlur_btn2',
		
    },

	onSelect_btn1: function(){
		print('[message-popup.js] buttonView.onSelect_btn1');
		that.bClickButton = true;
		//add EventLog  
		var eventLog ;
		if('myPage_coupon' == this.prePage){
			eventLog = 'JUMPSSOCOUPON';
		}else if('myPage_message' == this.prePage){
			eventLog = 'JUMPSSOMSG';
		};
		
		if('myPage_coupon' == this.prePage || 'myPage_message' == this.prePage ){
			//just for messageBox and couponBox
			Volt.KPIMapper.addEventLog(eventLog, {
				d : {
					cp : 'G07_MYPAGE',
				}
			});
		}else if(this.prePage != ''){
			//EV004
			Volt.KPIMapper.addEventLog('JUMPSSO', {
				d : {
					cp : this.prePage,
				}
			});
		}
	    
        Utils.Timer.clearTimeOut();
		var data = {
			msgBoxtype : popInfo.type,
			eventType : CommonDefine.Event.SELECT_BTN1,
			appID: popInfo.appID,
		};
		print('[message-popup.js] send event to view');
		Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
		if(this.type != 'widget'){
			Backbone.history.back();
		}
    },
    
	onSelect_btn2: function(){
		print('[message-popup.js] buttonView.onSelect_btn2');
		that.bClickButton = true;
        Utils.Timer.clearTimeOut();
		
		var data = {
			msgBoxtype : popInfo.type,
			eventType : CommonDefine.Event.SELECT_BTN2,
			appID: popInfo.appID,
		};
		Mediator.trigger(CommonDefine.Event.MSGBOX_BUTTON, data);
        if(this.type != 'widget'){
			Backbone.history.back();
		}
    },	
    
	onFocus_btn1: function(){
		print('[message-popup.js] buttonView.onFocus1');
		if(CommonFucntion.checkValid(this.btn1)) {
			print('[message-popup.js] CommonFucntion.checkValid(this.btn1)');
		this.btn1.stateBorder[this.btn1.btnState.FOCUS] = {width:4, color:{r:255, g:255, b:255, a:255}};
			this.btn1.getFocus();
			focusID = 'message_popup_2_btn1';
            Utils.Timer.setTimerOut();        
		}
    },
    
 	onFocus_btn2: function(){
		print('[message-popup.js] buttonView.onFocus2');
		if(CommonFucntion.checkValid(this.btn2)) {
			print('[message-popup.js] CommonFucntion.checkValid(this.btn2)');
		this.btn2.stateBorder[this.btn2.btnState.FOCUS] = {width:4, color:{r:255, g:255, b:255, a:255}};
			this.btn2.getFocus();
			focusID = 'message_popup_2_btn2';
            Utils.Timer.setTimerOut();        
		}
    },
    
    onBlur_btn1: function(widget){
    	print('------message-popup.js------onBlur_btn1,this.btn1 : ' + this.btn1);
    	if(CommonFucntion.checkValid(this.btn1)){
		this.btn1.stateBorder[this.btn1.btnState.NORMAL] = {width:1, color:{r:255, g:255, b:255, a:204}};
			this.btn1.loseFocus();
	}		
    },
    
    onBlur_btn2: function(widget){
    	print('------message-popup.js------onBlur_btn2,this.btn2 : ' + this.btn2);
    	if(CommonFucntion.checkValid(this.btn2)){
		this.btn2.stateBorder[this.btn2.btnState.NORMAL] = {width:1, color:{r:255, g:255, b:255, a:204}};
			this.btn2.loseFocus();
	}
    },
	
});

exports = messagePopup;
