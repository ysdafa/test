// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

// Require Common Modules
    PanelCommon = Require('lib/panel-common.js'),
    loadTemplate = PanelCommon.loadTemplate,
    _ = Volt.require("modules/underscore.js")._;
var CommonDefine      = Volt.require('app/common/common-define.js');

var SingleLinelistView = PanelCommon.BaseView.extend({
    singlelineParam : null,

    initialize : function(singlelineParam) {
        this.singlelineParam = singlelineParam;
    },

    render : function() {
        this.initList = _.bind(__initList, this);
        var singleLinelist = this.initList(this.singlelineParam);
        print("[singleLinelist-list-view.js] singleLinelist is  " + singleLinelist);
        this.setWidget(singleLinelist);
        return this;
    },

});

var getRenderer = function(singleList,parentWidth, parentHeight, data) {
    print("[singleLinelist-list-view.js] getRenderer parentWidth =" + parentWidth + " parentHeight = " + parentHeight);
    var renderer = new Renderer(parentWidth, parentHeight);
    renderer.root = new WidgetEx({
        x : 0,
        y : 0,
        width : parentWidth,
        height : parentHeight,
        parent : scene,
        color : {r:0,g:0,b:0,a:0}
    });
    renderer.root.show();
    singleList.initRenderer(renderer,data,parentWidth, parentHeight);

    renderer.onDraw = function(rendererInstance,drawTypeString, data, parentWidth, parentHeight) {
        if (!data) {
            return;
        }

        if ("LoadData" == drawTypeString) {
            print("[singleLinelist-list-view.js] LoadData");
            singleList.onDrawLoadData(rendererInstance,data, parentWidth, parentHeight);
        }
        else if("UpdateData" == drawTypeString)
        {
            print("[singleLinelist-list-view.js] UpdateData");
            singleList.onDrawUpdateData(rendererInstance.root,data,parentWidth,parentHeight);
        }
        else if("FromItemFocusChangeAniStart" == drawTypeString)
        {
            print("[singleLinelist-list-view.js] FromItemFocusChangeAniStart");
            singleList.onDrawFromFocusChangeStart(rendererInstance.root,data,parentWidth,parentHeight);
        }
        else if("ToItemFocusChangeAniEnd" == drawTypeString)
        {
            print("[singleLinelist-list-view.js] ToItemFocusChangeAniEnd");
            singleList.onDrawToFocusChangeEnd(rendererInstance.root,data,parentWidth,parentHeight);
        }else if("onFocusChanged" == drawTypeString){
            print("[singleLinelist-list-view.js] onFocusChanged");
            singleList.onFocusChanged(singleLineList, fromItemIndex, toItemIndex);
        }else if("onFocusChangeStart" == drawTypeString){
            print("[singleLinelist-list-view.js] onFocusChangeStart");
            singleList.onFocusChangeStart(singleLineList, fromItemIndex, toItemIndex);
        }
    };

    renderer.onResize = function(rendererInstance,data, destWidth, destHeight, flagWithAni, duration) {
        if ("withAni" == flagWithAni) {
        } else if ("noAni" == flagWithAni) {
        }

    };

    renderer.onUpdate = function(width, height) {

    };

    renderer.onRelease = function() {
        print("[singleLinelist-list-view.js] onRelease" + renderer.root.getChildCount());

        renderer.root.destroy();
        delete renderer;
    };

    return renderer;
};


var itemClicked = function(singleLineList, itemIndex) {
        print("[singleLinelist-list-view.js] itemClicked index = " + itemIndex);
        //response the callback onItemMouseClick to mouse click on listitem
        singleLineList.onItemMouseClick(itemIndex);
};

var FocusChanged = function(singleLineList, fromItemIndex, toItemIndex){
    print("[singleLinelist-list-view.js] FocusChanged fromItemIndex = " + fromItemIndex+"toItemIndex:"+toItemIndex);
    singleLineList.onFocusChanged(singleLineList, fromItemIndex, toItemIndex);
};
var FocusChangeStart = function(singleLineList, fromItemIndex, toItemIndex){
    print("[singleLinelist-list-view.js] FocusChangeStart fromItemIndex = " + fromItemIndex+"toItemIndex:"+toItemIndex);
    singleLineList.onFocusChangeStart(singleLineList, fromItemIndex, toItemIndex);
};

var __initList = function(param) {
    //create gridlist refer to param
    var singleList = new SingleLineListControl(param);

    /* *******************set render and listener of gridlistcontrol begin**************************/
    //api from native element
    var rendererProvider = new RendererProvider;
                    

    rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data) {
        return getRenderer(singleList,parentWidth, parentHeight, data);
    };

    singleList.setRendererProvider(rendererProvider);
    /* *******************set render and listener of gridlistcontrol end**************************/

    var singleLineListener = new SingleLineListControlListener;

    singleLineListener.onItemClicked = itemClicked;
    singleLineListener.onFocusChanged = FocusChanged;
    singleLineListener.onFocusChangeStart = FocusChangeStart;

    singleList.addListListener(singleLineListener);

    

    /* ******************set call back api from common-module begin******************/
    //callback to draw list item
    singleList.onDrawLoadData = function(render,data, parentWidth, parentHeight){};
    //callback to response "enter" key press
    singleList.onItemPress = function(index){};
    //callback to response update list item
    singleList.onDrawUpdateData = function(widget,data, parentWidth, parentHeight){};
    //callback to response focus change start( from item)
    singleList.onDrawFromFocusChangeStart = function(widget,data, parentWidth, parentHeight){};
    //callback to response focus change start( to item)
    singleList.onDrawToFocusChangeEnd = function(widget,data, parentWidth, parentHeight){};
    //callback to response mouse click
    singleList.onItemMouseClick = function(index){};
    singleList.onFocusChanged = function(list, fromItemIndex, toItemIndex){};
    singleList.onFocusChangeStart = function(list, fromItemIndex, toItemIndex){};
    singleList.initRenderer= function(renderer,data,parentWidth, parentHeight){};


    /* ******************set call back api from common-module  end ******************/

    
    /* ******************set onkeyevent process begin******************/
    this.onKeyEvent = function (keycode, keytype) {
        var ret = false;
        
        if(keytype == Volt.EVENT_KEY_RELEASE){
            return ret;
        }
        print("[singleLinelist-list-view.js] onKeyEvent keycode = " + keycode);
        switch(keycode) {
            case Volt.KEY_JOYSTICK_UP:
                ret =  singleList.moveFocus("Up");
                break;
            case Volt.KEY_JOYSTICK_DOWN:
                ret =  singleList.moveFocus("Down");
                break;  
            case Volt.KEY_JOYSTICK_OK:{
                //response the callback onItemPress to key press on listitem
                var index = singleList.focusItemIndex;
                print('[singleLinelist-list-view.js] focusItemIndex = ' + singleList.focusItemIndex);
                if ( index == undefined){
                    index = 0;
                }
                singleList.onItemPress(index);
                ret = true;
            }
            break;

            default:
            // to do
            break;
        }
        return ret;
    };

    singleList.onKeyEvent =  this.onKeyEvent.bind(this);
    /* ******************set onkeyevent process end******************/

    singleList.setScrollBar = function(widget, max){
        var CommonContent = Volt.require('app/common/common-content.js');
        this.scroll = CommonContent.createScroll({
        	style : CommonDefine.Winset.SCROLL_VERTICAL,
            parent : widget,
            x : widget.width,
            y : 0,
            width : 5,
            height : param.height,
            maxValue : max,
        });
        this.scroll.show();
        singleList.attachScrollBar(this.scroll);
    };
    
//    singleList.updateScrollBar = function(max, min, value){
//        this.scroll.setMaxValue(max);
//        this.scroll.setMinValue(min);
//        this.scroll.setValue(value);
//        
//        var perHeight = this.scroll.height/max;
//        this.scroll.setPointingNormalThumbSize(5, perHeight);
//        this.scroll.setPointingOverThumbSize(21, perHeight);
//        this.scroll.setPointingFocusThumbSize(29, perHeight + this.scroll.height * 0.008333);
//    };
    
    singleList.show();

    print("[singleLinelist-list-view.js] init singlelinelist ");
    return singleList;
};

exports = SingleLinelistView;