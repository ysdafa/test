var PanelCommon       = Volt.require('lib/panel-common.js');
var MainCategoryModel = Volt.require("app/models/main-category-model.js");
var GamesMainTemplate = Volt.require("app/templates/1080/main-template.js");
var Backbone          = Volt.require('lib/volt-backbone.js');
var CommonContent     = Volt.require('app/common/common-content.js');
var Gridlist          = Volt.require('app/views/grid-list-view.js');
var GridlistTemplate  = Volt.require('app/templates/1080/grid-list-template.js');
var CommonDefine      = Volt.require('app/common/common-define.js');
var CommonFunction    = Volt.require('app/common/common-function.js');
var Mediator          = Volt.require('app/common/event-mediator.js');
var TopGrossingModel  = Volt.require("app/models/top-grossing-model.js");
var NoContentView     = Volt.require('app/views/no-content-view.js');
var DeviceModel       = Volt.require('app/models/device-model.js');
var VoiceGuide        = Volt.require('app/common/voiceGuide.js');

var realDataStateInGross = false;
var topGrossSelf = null;

var TopGrossingView = PanelCommon.BaseView.extend({
	parent          : null,
	contentWgt      : null,
	viewIsVisible   : false,
	bListenerStatus : false,
	viewType        : 'grossing',
	gridView        : null,
	
	initialize : function() {
	    topGrossSelf = this;
	},

	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur'
	},

    render: function(parentWidget) {
        print('top grossing view render');
        this.parent = parentWidget.widget.getChild('main-content-container');
        this.renderContent();
        
        return this;
    },

	renderContent : function() {
	    realDataStateInGross = MainCategoryModel.isReady();
		var grossing_list = TopGrossingModel.get('grossing_list');
		if (grossing_list.length == 0) {
			var noContentWgtId = this.viewType;
			var textToShow = Volt.i18n.t('COM_NO_CONTENT_FOUND');
			this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;
		} else {
			this.contentWgt = this.initGrid(grossing_list);
			this.contentWgt.id = "GROSSING_CONTENT";
			this.contentWgt.focusable = true;
			this.setGridFocusRule();
		}
		this.parent.addChild(this.contentWgt);
		this.setWidget(this.contentWgt);
		Volt.Nav.reload();
	},
	
	setGridFocusRule : function() {
        Volt.Nav.setNextItemRule(this.contentWgt, 'up', Volt.Nav.getItem(3));//categoryTab
        Volt.Nav.setNextItemRule(this.contentWgt, 'left', this.contentWgt);
        Volt.Nav.setNextItemRule(this.contentWgt, 'right', this.contentWgt);
    },

	initGrid : function(dataList) {
		var grossingData = {
			style : CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME,
			groups : [{
			modelArr : dataList
			}]
		};
		var gridView = new Gridlist(GridlistTemplate.topGrossing, JSON.stringify(grossingData), parseInt(scene.width * 0.16875), parseInt(scene.height * 0.4));
		
		gridView.setItemData = function(mustache, modelData) {
			mustache.imgUrl = (modelData['thumbnail_url']) ? modelData['thumbnail_url'] : '';
			mustache.title  = (modelData['game_title']) ? modelData['game_title'] : '';
			mustache.genre  = (modelData['genre']) ? modelData['genre'] : '';
			mustache.app_id = (modelData['app_id']) ? modelData['app_id'] : '';
			mustache.rating = (modelData['rating']) ? modelData['rating'] : '';
			mustache.size   = (modelData['size']) ? modelData['size'] : '';
			mustache.controller_list = (modelData['controller_list']) ? modelData['controller_list'] : '';
			mustache.downloadable    = (modelData['downloadable']) ? modelData['downloadable'] : '';
		};
		
		gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
			CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
			CommonContent.addThumbnailListener(rendererInstance.thumbnail);
			CommonContent.setFoverFactor(rendererInstance.thumbnail,parentWidth);
			this.onItemUpdate(rendererInstance, data);
			this.onItemIconLoad(data, rendererInstance, 'NoIcon');
		};
		
		gridView.onItemPress= function(itemData,groupIndex, itemIndex){                 
			var Renderer = this.widget.renderer(groupIndex, itemIndex);
			var spValue = Volt.KPIMapper.getSelectPosition(itemIndex + 1);
			CommonContent.onLaunch('G05_TOPGROSSING', itemData.app_id,Renderer.thumbnail,spValue);
			//CommonContent.onLaunch('', itemData.app_id);
		};
		gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {

		};

		gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {

		};

		gridView.itemLoaded = function(gridList,groupIndex, itemIndex){
			var data = gridList.getData(groupIndex, itemIndex);
			data.group = groupIndex;
			data.item = itemIndex;
		};

		gridView.updateElements = function(parent, data){
			print('[main-grossing-view.js] updateElements');
			this.onItemIconLoad(data, parent, 'NoIcon');
		};

		gridView.resetElements = function(parent, data) {
			print('[main-grossing-view.js] resetElements');
			this.onItemIconReset(data);
		};

		gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
			print('[main-grossing-view.js] gridView.focusChanged .....');
			if(toItemIndex >= 0 && toGroupIndex >= 0){
				var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
				Volt.pageItemIndex = toItemIndex + 1;
				var voiceText = '';
				if(-1 == fromItemIndex){
					voiceText += 'Games,' + Volt.i18n.t('TV_SID_MIX_CATEGORY_END').replace('<<A>>',Volt.i18n.t('TV_SID_TOP_GROSSING')) + ','+  Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',TopGrossingModel.get('grossing_list_cnt')) + ',';
				}

				voiceText += data.title + '.';
				VoiceGuide.getVoiceGuide(voiceText,false);
			}
		};
		this.gridView = gridView;

		return gridView.render().widget;
	},

	remove : function() {
		if (this.contentWgt) {
			this.parent.removeChild(this.contentWgt);
			this.contentWgt.destroy();
			this.contentWgt = null;
		}
    },
	
    onFocus: function(widget) {
        print('[main-grossing-view.js] ContentView.onFocus');

		if (this.contentWgt) {
		    widget = this.contentWgt;
		    Volt.Nav.focus(this.contentWgt);
			widget.onFocus();
		}

		if (widget && widget.id) {
			print('[main-grossing-view.js] onFocus widget.id =' + widget.id);
			Backbone.history.setCache(widget.id);
		}
	},

	onBlur : function(widget) {
		if (widget) {
			print('[main-grossing-view.js] ContentView.onBlur');
			if (this.contentWgt) {
			    this.contentWgt.onBlur();
			}
		}
	},

	show : function(param, animationType) {
		print('[main-grossing-view.js] show');
  
		Mediator.on(CommonDefine.Const.UPDATE_ITEMS, this.updateItems, this);
		Mediator.on(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, this.updateListenerFlag, this);
		Mediator.on(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
		this.addEventListener();
		if (this.contentWgt) {
			this.contentWgt.show();
			if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'GROSSING_CONTENT') {
				this.contentWgt.focusable = true;
			}
			
			this.updateItems();
		}
		
		if(this.gridView){
			this.gridView.show();
		}
		
		this.viewIsVisible = true;
		Volt.Nav.reload();
		
        var categoryState = MainCategoryModel.isReady();
        if (categoryState && (categoryState != realDataStateInGross)) {
            this.updateContent();
        }
	},

    hide: function(animationType) {
        print('[main-grossing-view.js] hide');
		this.viewIsVisible = false;
		this.removeEventListener();
		Mediator.off(CommonDefine.Const.UPDATE_ITEMS, null, this);
		Mediator.off(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, null, this);
		Mediator.off(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
		if(this.gridView){
		    this.gridView.hide();
		}
        
		if (this.contentWgt) {
			this.contentWgt.hide();
			if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'GROSSING_CONTENT') {
				this.contentWgt.focusable = false;
			}
		}
    },
    
    updateContent : function() {
        print('[main-grossing-view.js] update content');
        realDataStateInGross = MainCategoryModel.isReady();
        if(this.contentWgt){
            if (this.contentWgt.id != "GROSSING_CONTENT") {
                return;
            }
            
            var grossing_list = TopGrossingModel.get('grossing_list');
            CommonContent.updateData(grossing_list, 0,this.contentWgt);
            this.updateItems();
        } else {
            this.renderContent();
        }
    },

	addEventListener : function() {
		print('[main-grossing-view.js] addEventListener, that.bListenerStatus = ' + this.bListenerStatus);
		if (this.bListenerStatus == false) {
			Mediator.on(CommonDefine.Event.BEGIN_DOWNLOAD, this.updateProgressBar, this);
			Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgressBar, this);
			Mediator.on(CommonDefine.Event.DOWNLOAD_CANCELED, this.updateProgressBar, this);
			Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
			this.bListenerStatus = true;
		}
	},

	removeEventListener : function() {
		print('[main-grossing-view.js] removeEventListener, that.bListenerStatus = ' + this.bListenerStatus);
		if (this.bListenerStatus == true) {
			Mediator.off(CommonDefine.Event.DOWNLOAD_PROGRESS,null,this);
			Mediator.off(CommonDefine.Event.INSTALL,null,this);
			Mediator.off(CommonDefine.Event.BEGIN_DOWNLOAD,null, this);
			Mediator.off(CommonDefine.Event.DOWNLOAD_CANCELED,null, this);
			this.bListenerStatus = false;
		}
    },

	updateListenerFlag: function(flag){
		print('[main-grossing-view.js] updateListenerFlag,flag = ' + flag);
		if (flag == true) {
			this.addEventListener();
			this.updateItems();
		} else {
			this.removeEventListener();
		}
		this.bListenerStatus = flag;
	},

	updateItems : function() {
		print("[main-grossing-view.js] updateAllItems~~");
		var gridCount = TopGrossingModel.get('grossing_list_cnt');
		if (this.contentWgt && (gridCount > 0)) {
			this.contentWgt.updateAllItems(0);
		}
	},

	getWidget : function() {
		return this.contentWgt;
	},

	updateProgressBar : function(eventInfo) {
		if (topGrossSelf.viewIsVisible == false) {
			return;
		}
		print('[main-grossing-view.js] updateProgressBar, ID = ' + eventInfo.app_id);
		var index;
		for ( index = 0; index < TopGrossingModel.get('grossing_list_cnt'); index++) {
		    if(topGrossSelf.contentWgt){
                var data = topGrossSelf.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
		    }
			
		}
		print('[main-grossing-view.js] index = ' + index + ', grossing_list_cnt = ' + TopGrossingModel.get('grossing_list_cnt'));
		//update install icon
		//update progress bar
		if (index < TopGrossingModel.get('grossing_list_cnt') && topGrossSelf.contentWgt) {
			topGrossSelf.contentWgt.updateItem(0, index);
		}
	},

	finishInstall : function(eventInfo) {
		if (topGrossSelf.viewIsVisible == false) {
			return;
		}
		print('[main-grossing-view.js] finishInstall, ID = ' + eventInfo.app_id);
		var index;
		for ( index = 0; index < TopGrossingModel.get('grossing_list_cnt'); index++) {
		    if(topGrossSelf.contentWgt){
                var data = topGrossSelf.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
		    }
		}
		print('[main-grossing-view.js] index = ' + index + ', grossing_list_cnt = ' + TopGrossingModel.get('grossing_list_cnt'));
		//update install icon
		//update progress bar
		if (index < TopGrossingModel.get('grossing_list_cnt') && topGrossSelf.contentWgt) {
			topGrossSelf.contentWgt.updateItem(0, index);
		}
    },
});

exports = TopGrossingView;
