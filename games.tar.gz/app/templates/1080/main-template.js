var GamesMainTemplate = {
    header: {
        type: 'widget', x: 0, y: 0, width: 1920, height: 144,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                type: 'text', x: 36, y: 0, width: 726, height: 144,
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                opacity: 204,
                text : Volt.i18n.t('UID_PAN_GAMES'),
                font : '50px'
            }, {
                type: 'widget', x: 1620, y: 0, width: 300, height: 144,
                color: Volt.hexToRgb('#000000', 0),
                children: [
                    {
				    	id: 'main-header-line',
				    	type: 'widget', x: 0, y: 0, width: 1, height: 144 + 18,
                        color: Volt.hexToRgb('#ffffff'), opacity: 25
                    },{
                        type: 'widget', x: 100, y: 0, width: 1, height: 144 + 18,
                        color: Volt.hexToRgb('#ffffff'), opacity: 25
                    },{
                        type: 'widget', x: 200, y: 0, width: 1, height: 144 + 18,
                        color: Volt.hexToRgb('#ffffff'), opacity: 25
                    },
                    {
                        id: 'main-header-icon-login',
                        type: 'widget', x: 1, y: 0, width: 99, height: 144, opacity: 255,
                        color: Volt.hexToRgb('#000000', 0),
                        custom: { 'focusable': true },
                        /*
                        children: [{
                        	type:'image',
                        	id: 'login-icon',
                            x: 33, y: 55, width : 33, height : 33,
                            color: Volt.hexToRgb('#ffffff',0),
                        }]
                        */
                    },{
                        id: 'main-header-icon-setting',
                        type: 'widget', x: 101, y: 0, width: 99, height: 144, opacity: 255,
                        color: Volt.hexToRgb('#000000', 0),
                        custom: { 'focusable': true },
                        /*
                        children: [{
                            type : 'image',
							id: 'main-header-icon-setting-image',
                            x: 33, y: 55, width : 33, height : 33,
                            src : Volt.getRemoteUrl('images/1080/common/comn_icon_tm_setting_nor.png')
                        }]
                        */
                    },{
                        id: 'main-header-icon-close',
                        type: 'widget', x: 201, y: 0, width: 99, height: 144, opacity: 255,
                        color: Volt.hexToRgb('#000000', 0),
                        custom: { 'focusable': true },
                        /*
                        children: [{
                            type : 'image',
							id: 'main-header-icon-close-image',
                            x: 33, y: 55, width : 33, height : 33,
                            src : Volt.getRemoteUrl('images/1080/common/comn_icon_tm_close_nor.png')
                        }]
                        */
                    }
                ]
            },
            {
                id : "main-header-dim",
                type: 'widget', x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#000000', 0),
            }
        ]
    },

	loginBtn : {
	//	type : 'WinsetBtn',
	//	style: '{{style}}',
		id : 'login-icon',
	//	buttonType: '{{buttonType}}',
		icon: {src:Volt.getRemoteUrl('images/1080/common/g_state_logout.png'),x:20,y:42,width:60,height:60},
	//	iconHeight: 60,
	//	iconWidth: 60,
		color: { r: 0, g: 0, b: 0, a: 0 },
		height: 144+8,
		width: 99+8,
		x: -4,
		y: -4
	},
	
	settingBtn:{
	//	type : 'WinsetBtn',
	//	style: '{{style}}',
		id : 'main-header-icon-setting-image',
	//	buttonType: '{{buttonType}}',
		icon: {src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_setting_nor.png'),x:33,y:55.5,width:33,height:33},
	//	iconHeight: 33,
	//	iconWidth: 33,
		color: { r: 0, g: 0, b: 0, a: 0 },
		height: 144+8,
		width: 99+8,
		x: -4,
		y: -4
	},
	
	closeBtn:{
	//	type : 'WinsetBtn',
	//	style: '{{style}}',
		id : 'main-header-icon-close-image',
	//	buttonType: '{{buttonType}}',
		icon: {src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_close_nor.png'),x:33,y:55.5,width:33,height:33},
	//	iconHeight: 33,
	//	iconWidth: 33,
		color: { r: 0, g: 0, b: 0, a: 0 },
		height: 144+8,
		width: 99+8,
		x: -4,
		y: -4
	},
	
   gamesItemSmallWithTitle: [
       {
            type:'widget',
            x : 0,
            y : 0,
            width : 323,
            height : 407,
            color:Volt.hexToRgb('#d4d4d4'),
            children:[
                {
                    type:'image',
                    x : 0,
                    y : 0,
                    width : 323,
                    height : 407,
                    src : Volt.getRemoteUrl('images/1080/icon_blank_thumbnail.png'),
                    fillMode : 'center',
                }
            ]
        },
		{
			type:'Thumbnail',
			visibleStyles: (0x01 | 0x20),
			x : 0,y : 0,width : 324,height : 324+84,
			image:{src: '{{ imgUrl }}',
				width: 324,
				height: 324},
			custom:{ID:'IMG'},
			information:{
				x: 0,
				y: 324,
				width: 324,
				height: 84,
				text1:{
					x:20,
					y:15,
					width:284,
					height: 36,
					font: 'Calibri 26px',
					text: '{{ title }}',
					singleLineMode: true},
				text2:{
					x:20,
					y:46,
					width:176,
					height: 28,
					font: 'Calibri 20px',
					text: '{{genre}}',
					singleLineMode: true},
				},
			

		},
    ],
    gamesItemSmallWithoutTitle: [
        {
            type:'widget',
            x : 0,
            y : 0,
            width : 323,
            height : 431,
            color:Volt.hexToRgb('#d4d4d4'),
            children:[
                {
                    type:'image',
                    x : 0,
                    y : 0,
                    width : 323,
                    height : 431,
                    src : Volt.getRemoteUrl('images/1080/icon_blank_thumbnail.png'),
                    fillMode : 'center',
                }
            ]
        },
		{
			type:'Thumbnail',
			visibleStyles: (0x01 | 0x20),
			x : 0,y : 0,width : 324,height : 324+108,
			image:{src: '{{ imgUrl }}',
				width: 324,
				height: 324},
			custom:{ID:'IMG'},
			information:{
				x: 0,
				y: 324,
				width: 324,
				height: 108,
				text1:{
					x:20,
					y:10,
					width:284,
					height: 36,
					font: 'Calibri 26px',
					text: '{{ title }}',
					singleLineMode: true},
				text2:{
					x:20,
					y:58,
					width:176,
					height: 28,
					font: 'Calibri 20px',
					text: '{{genre}}',
					singleLineMode: true},
				},
			

		},		
    ],
    gamesItemLargeWithTitle: [
        {
            type:'widget',
            x : 0,
            y : 0,
            width : 647,
            height : 815,
            color:Volt.hexToRgb('#d4d4d4'),
            children:[
                {
                    type:'image',
                    x : 0,
                    y : 0,
                    width : 647,
                    height : 815,
                    src : Volt.getRemoteUrl('images/1080/icon_blank_thumbnail.png'),
                    fillMode : 'center',
                }
            ]
        },
		{
			type:'Thumbnail',
			visibleStyles: (0x01 | 0x20),
			x : 0,y : 0,width : 648,height : 648+168,
			image:{src: '{{ imgUrl }}',
				width: 648,
				height: 648},
			custom:{ID:'IMG'},
			information:{
				x: 0,
				y: 648,
				width: 648,
				height: 168,
				text1:{
					x:20,
					y:14,
					width:648,
					height: 36,
					font: 'Calibri 26px',
					text: '{{ title }}',
					singleLineMode: true},
				text2:{
					x:20,
					y:130,
					width:608,
					height: 36,
					font: 'Calibri 20px',
					text: '{{genre}}',
					singleLineMode: true},
				},
			

		},	
    ],
    gamesItemLargeWithoutTitle: [
        {
            type:'widget',
            x : 0,
            y : 0,
            width : 647,
            height : 863,
            color:Volt.hexToRgb('#d4d4d4'),
            children:[
                {
                    type:'image',
                    x : 0,
                    y : 0,
                    width : 647,
                    height : 863,
                    src : Volt.getRemoteUrl('images/1080/icon_blank_thumbnail.png'),
                    fillMode : 'center',
                }
            ]
        },
		{
			type:'Thumbnail',
			visibleStyles: (0x01 | 0x20),
			x : 0,y : 0,width : 648,height : 648+216,
			image:{src: '{{ imgUrl }}',
				width: 648,
				height: 648},
			custom:{ID:'IMG'},
			information:{
				x: 0,
				y: 648,
				width: 648,
				height: 216,
				text1:{
					x:20,
					y:14,
					width:648,
					height: 36,
					font: 'Calibri 26px',
					text: '{{ title }}',
					singleLineMode: true},
				text2:{
					x:20,
					y:168,
					width:608,
					height: 36,
					font: 'Calibri 20px',
					text: '{{genre}}',
					singleLineMode: true},
				},
			

		},
    ],
    
    myPage:{
        type: 'widget',
        id:'MY_PAGE_LEFT',
        x: 0, y: 0, width: 378, height: 864,
        children:[
            {
                custom: { 'focusable': true },
                type: 'widget',
                id:'MESSAGE_BOX',
                x: 0, y: 0, width: 378, height: 216,
                color : Volt.hexToRgb('#000000',20),
                children:[
                {
                    type:'image',
                    x: 159, y: 54, width: 60, height: 60,
                    src:Volt.getRemoteUrl('images/1080/g_icon_massage.png')
                },
                /*
                {
                    type:'image',
                    x: 204, y: 51, width: 31, height: 31,
                    src:Volt.getRemoteUrl('images/1080/g_icon_massage_num.png')
                },
                {
                    type:'text',
                    id:'MESSAGE_BOX_NUM',
                    x: 204, y: 56, width: 31, height: 31,
                    horizontalAlignment : 'center',
                    text:"5",
                    textColor :{r:0,g:0,b:0},
                    font : "SVD Light 22px",
                    opacity: 204, 
                },
                */
                {
                    type:'text',
                    x: 20, y: 120, width: 338, height: 50,
                    horizontalAlignment : 'center',
                    text:Volt.i18n.t('TV_SID_MESSAGES'),
                    textColor :{r:255,g:255,b:255},
                    font : "SVD Light 28px",
                    opacity: 153, 
                }
                ]
            },
            {
                custom: { 'focusable': true },
                type: 'widget',
                id:'COUPON_BOX',
                x: 0, y: 216, width: 378, height: 216,
                color : Volt.hexToRgb('#000000',10),
                children:[
                {
                    type:'image',
                    x: 159, y: 54, width: 60, height: 60,
                    src:Volt.getRemoteUrl('images/1080/g_icon_coupon.png')
                },
                {
                    type:'image',
                    x: 204, y: 51, width: 31, height: 31,
                    src:Volt.getRemoteUrl('images/1080/g_icon_massage_num.png')
                },
                {
                    type:'text',
                    id:'COUPON_NUM',
                    x: 204, y: 56, width: 31, height: 31,
                    horizontalAlignment : 'center',
                    text:"0",
                    textColor :{r:0,g:0,b:0},
                    font : "SVD Light 22px",
                    opacity: 204, 
                },               
                {
                    type:'text',
                    x: 20, y: 120, width: 338, height: 50,
                    horizontalAlignment : 'center',
                    text:Volt.i18n.t('TV_SID_COUPONS'),
                    textColor :{r:255,g:255,b:255},
                    font : "SVD Light 28px",
                    opacity: 153, 
                }
                ]
            },
            {
                type: 'widget',
                id:'PROFILE',
                x: 0, y: 432, width: 378, height: 432,
                color : Volt.hexToRgb('#000000',0),
                custom: { 'focusable': true },
                children:[
                {                    
                    type:'image',
                    id:'LOGIN_LOGO',
                    x: 109, y: 94, width: 160, height: 160,
                    children:[
                        {
                            type : 'image',
                            x: 0, y: 0, width : 160, height : 160,
                            //color:{r:254,g:4,b:84},
                            src : Volt.getRemoteUrl('images/1080/dummy/id_image_01.png'),
                            children:[
                                {
                                    type:'image',
                                    x:0,y:0,width:160,height:160,
                                    src:Volt.getRemoteUrl('images/1080/common/g_thumb_id_stroke.png'),
                                }
                            ]
                        }
                    ]
                }, 
                {
                    type:'text',
                    id:'LOGIN_NAME',
                    x: 20, y: 280, width: 338, height: 36,
                    horizontalAlignment : 'center',
                    text:"David.kim",
                    textColor :{r:255,g:255,b:255},
                    font : "SVD Light 28px",
                    opacity: 153, 
                    ellipsize: true,
                },
                {
                    type:'text',
                    id:'LOGIN_EMAIL',
                    x: 20, y: 320, width: 338, height: 36,
                    horizontalAlignment : 'center',
                    text:"David@samsung.com",
                    textColor :{r:255,g:255,b:255},
                    font : "SVD Light 20px",
                    opacity: 102, 
                    ellipsize: true,
                },
                ]
            }
        ]
    },
    /* @20140624 added by tiansx for myPage optimization begin*/
    myPageUnsigned:{
        type: 'widget',
        id:'MY_PAGE_LEFT_UNSIGNED',
        x: 0, y: 0, width: 378, height: 864,
        //color: Volt.hexToRgb('#5266b0'),
        children:[
            {
                id:"MESSAGE_BOX", 
                custom: { 'focusable': true },
                type: 'widget',
                x: 0, y: 0, width: 378, height: 432,
                color : Volt.hexToRgb('#5266b0',90),
                children:[
                {
                    type:'image',
                    x: 159, y: 155, width: 60, height: 60,
                    src:Volt.getRemoteUrl('images/1080/g_icon_massage.png')
                },                
                {
                    type:'text',
                    x: 20, y: 227, width: 338, height: 50,
                    horizontalAlignment : 'center',
                    text:Volt.i18n.t('TV_SID_MESSAGES'),
                    textColor :{r:255,g:255,b:255},
                    font : "SVD Light 28px",
                    opacity: 153, 
                }
                ]
            },
            {
                id:"COUPON_BOX", 
                custom: { 'focusable': true },
                type: 'widget',
                x: 0, y: 432, width: 378, height: 432,
                color : Volt.hexToRgb('#5266b0',80),
                children:[
                {
                    type:'image',
                    x: 159, y: 155, width: 60, height: 60,
                    src:Volt.getRemoteUrl('images/1080/g_icon_coupon.png')
                },                
                {
                    type:'text',
                    x: 20, y: 227, width: 338, height: 50,
                    horizontalAlignment : 'center',
                    text:Volt.i18n.t('TV_SID_COUPONS'),
                    textColor :{r:255,g:255,b:255},
                    font : "SVD Light 28px",
                    opacity: 153, 
                }
                ]
            },
           
        ]
    },
    /* @20140624 added by tiansx for myPage optimization end*/

    myPageRight:{
        type: 'widget',
        id:'MY_PAGE_RIGHT',
        x: 378, 
        y: 0, 
        width: 1596, 
        height: 864        
    },
    
   	genreAll:[
   	    {
            type:'widget',
            x : 0,
            y : 0,
            width : 639,
            height : 431,
            color:Volt.hexToRgb('#d4d4d4'),
            children:[
                {
                    type:'image',
                    x : 0,
                    y : 0,
                    width : 639,
                    height : 431,
                    src : Volt.getRemoteUrl('images/1080/icon_blank_thumbnail.png'),
                    fillMode : 'center',
                }
            ]
        },
   		{
   			type: 'image',  custom:{ID:'IMG'},
	        x: 0, y: 0, width: 640, height: 432,
	        src: '{{ imgUrl }}',
	        cropMode: "cropCenter",
   		},
   		{
   			type:'text',x:10,y:166,
	   		color:{r : 0,g : 0,b : 0,a : 0},
	   		width : 620,height : 100,
	   		verticalAlignment:'center',
	   		horizontalAlignment :'center',
	   		font:'System Default 90px',
	   		textColor:{r:0,g:0,b:0},
	   		opacity:128,
	   		custom:{ID:'TXT'},
	   		text:'{{title}}',
   		}
   	],
   	genreSubCategory:[
   	    {
            type:'widget',
            x : 0,
            y : 0,
            width : 639,
            height : 431,
            color:Volt.hexToRgb('#d4d4d4'),
            children:[
                {
                    type:'image',
                    x : 0,
                    y : 0,
                    width : 639,
                    height : 431,
                    src : Volt.getRemoteUrl('images/1080/icon_blank_thumbnail.png'),
                    fillMode : 'center',
                }
            ]
        },
   		{
   			type: 'image',  custom:{ID:'IMG'},
	        x: 0, y: 0, width: 640, height: 432,
	        src: '{{ imgUrl }}',
	        cropMode: "cropCenter",
   		},
   		{
   			type:'text',x:10,y:300,
	   		color:{r:0,g:0,b:0,a:0},
	   		width:620,height:50,
	   		verticalAlignment:'center',
	   		horizontalAlignment:'center',
	   		font:'SVD Light 35px',
	   		textColor:{r:0,g:0,b:0},
	   		opacity:154,
	   		custom:{ID:'TXT'},
	   		text:'{{title}}',
   		}
   		
   ],
    
    TitleBarWidget:{
        type: 'text',
        x: 0, 
        y: -48, 
        width: 324*5*4, 
        height: 48,
        color: {r:0xf2, g:0xf2, b:0xf2},
    },
                 
    TitleWidget:{
        type: 'text',
        x: 0, 
        y: 0, 
        width: 1620, 
        height: 48,
        verticalAlignment:"center",
        textColor:{r:0, g:0, b:0},
        font:"System Default 22px",
        text:'{{ text }}',
        parent:scene,
    },
    
    imageWidget:{
        type: 'image',
        width: 17, 
        height: 17,
        src : '{{ src }}',
	asyn:true,

    },
    
  	toolTip:{
        type : 'WinsetToolTip',
        x: '{{x}}',
		y: 144,
		width: '{{w}}',
    	height: 54,
		style: '{{style}}',
		nResoultionStyle: '{{nResoultionStyle}}',
		text: '{{text}}',
		tailPostion: "center",
		parent:scene
    },
};

exports = GamesMainTemplate;
