var DeletePopupTemplate = {
    container : {
        parent:scene,
        type: 'widget',
       
        x: 0, y: 385, width: 1920, height : 310,
        color : Volt.hexToRgb('#0f1826',85),
        children : [
            {
                type : 'widget',
                id : 'description-container',
                x : 570, y : 51, width : 780, height : 70,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : 570, y : 132, width : 780, height : 2,
                id : 'progressbar-container',
                color : Volt.hexToRgb('#ffffff',0),
                horizontalAlignment : 'center',
            },
            {
                type : 'widget',
                x : 570, y : 200, width : 780 , height : 66,
                id : 'button-container',
                color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    },

    description: { type : 'widget',
        x: 0, y: 0, width: 780, height: 70,
        color : Volt.hexToRgb('#000000',0),
        children :[{
            type : 'text',
            x : 0, y : 0, width : 780, height : 39,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            color : Volt.hexToRgb('#0f1826', 0),
            textColor : Volt.hexToRgb('#ffffff', 100),
            text : '',
            font : 'Samsung SVD_Light 34px'
        }, {
            type : 'text',
            x : 0, y : 40, width : 780, height : 30,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            color : Volt.hexToRgb('#0f1826', 0),
            textColor : Volt.hexToRgb('#ffffff', 100),
            text : '',
            font : 'Samsung SVD_Light 24px'
        }]
    },
    
    progressBar: {
        type: 'widget',        
        x: 0, y: 0, width: 780, height: 2,
        color : Volt.hexToRgb('#000000',0),
        id:'progressBar',        
    },
            
    button:{
        type : 'widget',
        x : 0, y : 0, width : 780, height : 66,
        color : Volt.hexToRgb('#000000',0),
        children: [
            {
                type : 'widget',
                id : 'Cancel',
                custom : {'focusable' : true,},
                x:255,y:0,width: 270,height: 66,
                color : Volt.hexToRgb('#000000',0),
            }
        ]
    }
};

exports = DeletePopupTemplate;