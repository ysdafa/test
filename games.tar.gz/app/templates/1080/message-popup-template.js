var MessagePopupTemplate = {
    container : {
		parent:scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height : 1080,
        color : {r:0,g:0,b:0,a:125},
        children : [
            {
                type : 'widget',
                id : 'bg-container',
                x : 0, width : 1920, 
                color : {r:15,g:24,b:38,a:217},
				children:[
						   {
								type : 'widget',
								id : 'message-title-container',
								color : {r:255,g:255,b:255,a:0},
							},
						   {
								type : 'widget',
								id : 'message-content-container',
								color : {r:255,g:255,b:255,a:0},
							},
							{
								type : 'widget',
								id : 'message-button-container',
								color : {r:255,g:255,b:255,a:0},
							}
				]
            },
 
        ]
    },
	title:{
    	type : 'widget',
		x : 0, y : 0, width : 1920, height : 96,
		color : {r:255,g:255,b:255,a:0},
    	children : [
			{
		        type : 'text',
		        x : 0, y: 0, width : 1920, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
				id :"share_title_text",
		        textColor : Volt.hexToRgb('#ffffff', 255),
		        text : 'MESSAGE POPUP',
		        font : '46',
	    	},
            {
                type : 'widget',
                x : 399, y : 95, width : 1122 , height : 1,
                id : 'share_title_horizontal_line',
                color : {r:255,g:255,b:255,a:76},
            }
		]
    },
	content_area:{
		type : 'widget',
		x : 399, y : 48,
		color : {r:255,g:255,b:255,a:0},
		children : [
			{
		        type : 'text',
		        x : 0, y: 0, 
		        horizontalAlignment : 'left',
		        verticalAlignment : 'center',
				singleLineMode: true,
				id :"message_content_text",
		        textColor : Volt.hexToRgb('#ffffff', 230),
		        text : '',
		        font : '34',
	    	},
		]
	},
button2:
	{
    	type : 'widget',
		x : 0, y : 0, width : 1980, height : 66,
		color : Volt.hexToRgb('#ffffff',0),
			
		children: [
			{
				type : 'widget',
				id : 'message_popup_2_btn1',
				custom : {'focusable' : true,},
				x : 684, y : 0, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'message_popup_2_btn2',
				custom : {'focusable' : true,},
				x : 966, y : 0, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },
button1:
	{
    	type : 'widget',
		x : 0, y : 0, width : 1980, height : 66,
		color : Volt.hexToRgb('#ffffff',0),
			
		children: [
			{
				type : 'widget',
				id : 'message_popup_1_btn1',
				custom : {'focusable' : true,},
				x : 855, y : 0, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },
}
exports = MessagePopupTemplate;