var GridList = {
	GroupTitle : {
	    type : "widget",
	    x : 0,y : 0,width : 500,height : 48,
	    color : Volt.hexToRgb('#dfdfdf'),
	    children : [{
	        type : 'text',
            x : 12,
            y : 0,
            width : 500,
            height : 48,
            verticalAlignment : "center",
            textColor : Volt.hexToRgb('#666666'),
            font : "System Default 22px",
            text : '{{title}}',
	    },{
            type : "widget",
            x : 0,
            y : 0,
            width : 500,
            height : 1,
            color : Volt.hexToRgb('#dbdcdd', 0),
        }
	    
	    ]
		
	},
	
	Spotlight : {
		x : 0,
		y : 0,
		width : scene.width,
		height : 864,
		titleSpace : 48,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	Popular : {
		x : 0,
		y : 0,
		width : scene.width,
		height : 864,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	whatsNew : {
		x : 0,
		y : 0,
		width : scene.width,
		height : 864,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	topGrossing : {
		x : 0,
		y : 0,
		width : scene.width,
		height : 864,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	brandzone : {
		x : 0,
		y : 0,
		width : scene.width,
		height : 864,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	genre : {
		x : 0,
		y : 0,
		width : 1920,
		height : 864,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	myPage : {
		x : 0,
		y : 0,
		width : 1542,
		height : 864,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	genreDetail:{
		x : 0,
		y : 0,
		width : 1920,
		height : 864,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},
	messageBox:{
		x : 0,
		y : 0,
		width : 1920,
		height : 936,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
    },
	NewIcon : {
		x : 10,
		y : 10,
		width : 46,
		height : 46,
		verticalAlignment : "center",
		horizontalAlignment : 'center',
		textColor : {
			r : 255,
			g : 255,
			b : 255,
			a : 255
		},
		color : {
			r : 15,
			g : 24,
			b : 38,
			a : 179
		},
		font : "System Default 12px",
		text : 'NEW',
	},
	detailPageRelated: {
        x : 0,
		y : 0,
		width : 1920,
		height : 164,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
    },
    
    myPageNew : {
        x : 0,
        y : 0,
        width : 1920,
        height : 864,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    
    detailPageBigThumbnail : {
        x : 0,
        y : 0,
        width : scene.width * 0.341667,
        height : scene.height * 0.341667,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    

    detailPageScreenShot : {
        x : 0,
        y : 0,
        width : scene.width * 0.140625 * 3 + scene.width * 0.005208 * 2, 
        height : scene.height * 0.138889,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : scene.width * 0.005208,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },

}
exports = GridList;
