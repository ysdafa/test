var CouponTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: 1920, height: 1080,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'coupon-header-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#0f1826')
            },  {
                id: 'coupon-content-container', 
                type: 'widget',
                x: 0, y: 144, width: 1920, height: 936,
                color: Volt.hexToRgb('#ffffff'),
            },
            {
                id: 'coupon-popup-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 1080,
                color: Volt.hexToRgb('#000000',0),
            }
        ]
    },

    header: {
        type: 'widget', x: 0, y: 0, width: 1920, height: 144,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                id : "coupon-box-title",
                type: 'text', x: 36, y: 0, width: 726, height: 144,
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                opacity: 102,
                font : '50px',
                text : Volt.i18n.t('TV_SID_COUPONS'),
            },
            {
                type : 'widget',
                id : 'coupon-box-back-icon-area',
                x : 0, y : 0, width : 100, height : 144,
                color : {r:0,g:0,b:0,a:0},
                children : [
				{
					type:'widget',
					id:'coupon-back-icon-line',
					x:99,
					y:0,
					width:1,
					height:144,
					opacity: 26,
					color : Volt.hexToRgb('#ffffff'),
				},
				/*
                {
                    type:'image',
                    id:'coupon-box-back-icon',
                    x:32,
                    y:54,
                    width:36,
                    height:36,
                    src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_nor.png'),
                    fillMode:"center",
                    horizontalAlignment:"center",
                    verticalAlignment:"center",
                },
                */
                /*
                {
	                type: 'text', x: 36+100, y: 0, width: 726, height: 144,
	                verticalAlignment : 'center',
	                textColor : Volt.hexToRgb('#ffffff'),
	                opacity: 102,
	                font : '50px'
	            },
	            */
              ]
            },
            {
                type: 'widget', x: 1623, y: 0, width: 292, height: 144,
                color: Volt.hexToRgb('#000000', 0),
                id: 'coupon-header-icon-schedule',
                custom: { 'focusable': true },
            }
        ]
    },

   content:{
        x : 0,
        y : 0,
        width : 1920,
        height : 936,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    
    registerBtn : {
        id : 'coupon-header-icon-schedule-image',
        icon: {src:Volt.getRemoteUrl('images/1080/common/comn_icon_topmenu_plus.png'),x:33,y:55.5,width:33,height:33},
        color : {r : 0,g : 0,b : 0,a:0},
        width: 99+8,
        height: 144+8,
        x: 194,
        y: -4
      },
    backBtn:{
        id : 'coupon-box-back-icon',
        x : -4,
        y : -4,
        width : scene.width * 0.051563+8,
        height : scene.height * 0.133333+8,
        icon : {src:Volt.getRemoteUrl('images/1080/common/comn_icon_tm_return_nor.png'),
        x:(scene.width * 0.051563 - 36) / 2,y : (scene.height * 0.133333 - 36) / 2,
        width : 36, height : 36,},
        color: { r: 0, g: 0, b: 0, a: 0 },
   },

	toolTip : {
        type : 'WinsetToolTip',
        x : '{{x}}',
        y : '{{y}}',
        width : '{{w}}',
        height : 54,
        style : '{{style}}',
        nResoultionStyle : '{{nResoultionStyle}}',
        text : '{{text}}',
        tailPostion : "center",
        parent : scene
    }
 
};

exports = CouponTemplate;
