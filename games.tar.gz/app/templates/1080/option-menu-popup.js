/**
 * @author tiansx
 * @20140721
 */
var OptionMenuTemplate = {
    container : {
        type: 'widget',
        x: 1400, y: 111, width: 520, height : 300,
        color : Volt.hexToRgb('#000000',0),
        children : [
            {
                type : 'widget',
                id : 'main-menu-container',
                x : 220, y : 0, width : 300, height : 260,
                color : Volt.hexToRgb('#0f1826',100),
            },
            {
                type : 'widget',
                id : 'sub-menu-container',
                x : 0, y : 180, width : 220, height : 100,
                color : Volt.hexToRgb('#0f1826',0),
            },
        ]
    },
    
    //template of option menu
	optionMenuMain: {
		x: 1450, y: 100, width: 450,
		items:[]
    },
    
    longPressPopup:{
        x: 0, y: 0, width: 439, //height:200,
       	items:[]
    },
    
    /*
    longPressPopup2:{
        type: 'OptionMenu',
        x: 0, y: 0, width: 439, //height:272,
        text:['View Details',Volt.i18n.t('COM_SID_DOWNLOAD')],
        dim:true,
    },
    
	longPressPopup3:{
        type: 'OptionMenu',
        x: 0, y: 0, width: 439, //height:344,
        text:['View Details',Volt.i18n.t('COM_SID_DELETE'),Volt.i18n.t('COM_SID_UPDATE')],
        dim:true,
    },
    */
    
    contextMenuDim : {
    	type:'widget',
    	x : 0,
		y : 0,
		width : 1920,
		height : 1080,
		color : {
			r : 0,
			g : 0,
			b : 0,
			a : 102,
		},
		parent : scene
    },
};

exports = OptionMenuTemplate;
