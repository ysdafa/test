var GameControllerGuideTemplate = {
	container : {
		parent : scene,
		type : 'widget',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height,
		color : Volt.hexToRgb('#000000', 77),
		children : [{
				type : 'widget',
				id : 'game-content-container',
				x : 0,
				y : scene.height * 0.142593,
				width : scene.width,
				height : scene.height * 0.713889,
				color : Volt.hexToRgb('#f2f2f2'),
			}, {
				type : 'widget',
				id : 'game-button-container',
				color : Volt.hexToRgb('#f2f2f2'),
			}
		]
	},

	gamePageOne : {
		type : 'widget',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height * 0.713889,
		color : Volt.hexToRgb('#f2f2f2', 0),
		horizontalAlignment : 'center',
		verticalAlignment : 'center',

		children : [{
				type : 'text',
				x : scene.width * 0.24375 / 2,
				y : 140,
				width : scene.width * 0.75625,
				height : scene.height * 0.083333,
				horizontalAlignment : 'center',
				verticalAlignment : 'center',
				textColor : Volt.hexToRgb('#101010', 100),
				font : '78px',
				text : '{{page_text0}}'
			}, {
				type : 'text',
				x : 234,
				y : 246,
				width : scene.width * 0.75625,
				height : scene.height * 0.083333,
				horizontalAlignment : 'center',
				verticalAlignment : 'center',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '34px',
				text : '{{page_text1}}'
			}, {
				type : 'image',
				x : 110,
				y : 362,
				width : 219,
				height : scene.height * 0.378704,
				src : '{{page_image0}}'
			}, {
				type : 'image',
				x : 335,
				y : 362,
				width : 450,
				height : scene.height * 0.378704,
				src : '{{page_image1}}'
			}, {
				type : 'image',
				x : 884,
				y : 362,
				width : 219,
				height : scene.height * 0.378704,
				src : '{{page_image2}}'
			}, {
				type : 'image',
				x : 1120,
				y : 362,
				width : 450,
				height : scene.height * 0.378704,
				src : '{{page_image3}}'
			}, {
				type : 'image',
				x : 1591,
				y : 362,
				width : 219,
				height : scene.height * 0.378704,
				src : '{{page_image4}}'
			}, {
				type : 'text',
				x : 30,
				y : 721,
				width : 470,
				height : 30,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				textColor : Volt.hexToRgb('#000000', 40),
				font : '22px',
				text : '{{page_text2}}'
			}
		]
	},

	gamePageTwo : {
		type : 'widget',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height * 0.713889,
		color : Volt.hexToRgb('#f2f2f2', 0),
		children : [{
				type : 'image',
				x : 0,
				y : 0,
				width : 960,
				height : 771,
				src : '{{page_image0}}'
			}, {
				type : 'image',
				y : 109,
				width : 42,
				height : 89,
				fillMode:'center',
				src : '{{page_image1}}'
			}, {
				type : 'image',
				x : 1040,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image0}}'
			}, {
				type : 'image',
				x : 1300,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image1}}'
			}, {
				type : 'image',
				x : 1560,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 109,
				height : 89,
				horizontalAlignment : 'left',
				verticalAlignment: 'center',
			    textColor : Volt.hexToRgb('#000000', 100),
				font : '57px',
				text : '{{page_text0}}'
			}, {
				type : 'text',
				x : 1040,
				y : 198,
				width : 780,
				height : 96,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '27px',
				text : '{{page_text1}}'
			}, {
				type : 'text',
				x : 30,
				y : 721,
				width : 470,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 40),
				font : '22px',
				text : '{{page_text2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 366,
				width : 780,
				height : 57,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				text : Volt.i18n.t('COM_SID_BEST_FOR'),
				font : '27px',
			}, {
				type : 'text',
				x : 1040,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text3}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1300,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text4}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1560,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text5}}',
				font : '22px',
			},
		]
	},

	gamePageThree : {
		type : 'widget',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height * 0.713889,
		color : Volt.hexToRgb('#f2f2f2', 0),
		children : [{
				type : 'image',
				x : 0,
				y : 0,
				width : 960,
				height : 771,
				src : '{{page_image0}}'
			}, {
				type : 'image',
				y : 109,
				width : 42,
				height : 89,
				fillMode:'center',
				src : '{{page_image1}}'
			}, {
				type : 'image',
				x : 1040,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image0}}'
			}, {
				type : 'image',
				x : 1300,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image1}}'
			}, {
				type : 'image',
				x : 1560,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 109,
				height : 89,
				horizontalAlignment : 'left',
				verticalAlignment: 'center',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '57px',
				text : '{{page_text0}}'
			}, {
				type : 'text',
				x : 1040,
				y : 198,
				width : 780,
				height : 96,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '27px',
				text : '{{page_text1}}'
			}, {
				type : 'text',
				x : 30,
				y : 721,
				width : 470,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 40),
				font : '22px',
				text : '{{page_text2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 366,
				width : 780,
				height : 57,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				text : Volt.i18n.t('COM_SID_BEST_FOR'),
				font : '27px',
			}, {
				type : 'text',
				x : 1040,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text3}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1300,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text4}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1560,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text5}}',
				font : '22px',
			},
		]
	},

	gamePageFour : {
		type : 'widget',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height * 0.713889,
		color : Volt.hexToRgb('#f2f2f2', 0),
		children : [{
				type : 'image',
				x : 0,
				y : 0,
				width : 960,
				height : 771,
				src : '{{page_image0}}'
			}, {
				type : 'image',
				y : 109,
				width : 42,
				height : 89,
				fillMode:'center',
				src : '{{page_image1}}'
			}, {
				type : 'image',
				x : 1040,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image0}}'
			}, {
				type : 'image',
				x : 1300,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image1}}'
			}, {
				type : 'image',
				x : 1560,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 109,
				height : 89,
				horizontalAlignment : 'left',
				verticalAlignment: 'center',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '57px',
				text : '{{page_text0}}'
			}, {
				type : 'text',
				x : 1040,
				y : 198,
				width : 780,
				height : 96,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '27px',
				text : '{{page_text1}}'
			}, {
				type : 'text',
				x : 30,
				y : 721,
				width : 470,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 40),
				font : '22px',
				text : '{{page_text2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 366,
				width : 780,
				height : 57,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				text : Volt.i18n.t('COM_SID_BEST_FOR'),
				font : '27px',
			}, {
				type : 'text',
				x : 1040,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text3}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1300,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text4}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1560,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text5}}',
				font : '22px',
			},
		]
	},

	gamePageFive : {
		type : 'widget',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height * 0.713889,
		color : Volt.hexToRgb('#f2f2f2', 0),
		children : [{
				type : 'image',
				x : 0,
				y : 0,
				width : 960,
				height : 771,
				src : '{{page_image0}}'
			}, {
				type : 'image',
				y : 109,
				width : 42,
				height : 89,
				fillMode:'center',
				src : '{{page_image1}}'
			}, {
				type : 'image',
				x : 1040,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image0}}'
			}, {
				type : 'image',
				x : 1300,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image1}}'
			}, {
				type : 'image',
				x : 1560,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 109,
				height : 89,
				horizontalAlignment : 'left',
				verticalAlignment: 'center',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '57px',
				text : '{{page_text0}}'
			}, {
				type : 'text',
				x : 1040,
				y : 198,
				width : 780,
				height : 96,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '27px',
				text : '{{page_text1}}'
			}, {
				type : 'text',
				x : 30,
				y : 721,
				width : 470,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 40),
				font : '22px',
				text : '{{page_text2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 366,
				width : 780,
				height : 57,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				text : Volt.i18n.t('COM_SID_BEST_FOR'),
				font : '27px',
			}, {
				type : 'text',
				x : 1040,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text3}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1300,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text4}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1560,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text5}}',
				font : '22px',
			},
		]
	},

	gamePageSix : {
		type : 'widget',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height * 0.713889,
		color : Volt.hexToRgb('#f2f2f2', 0),
		children : [{
				type : 'image',
				x : 0,
				y : 0,
				width : 960,
				height : 771,
				src : '{{page_image0}}'
			}, {
				type : 'image',
				y : 109,
				width : 42,
				height : 89,
				fillMode:'center',
				src : '{{page_image1}}'
			}, {
				type : 'image',
				x : 1040,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image0}}'
			}, {
				type : 'image',
				x : 1300,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image1}}'
			}, {
				type : 'image',
				x : 1560,
				y : 414,
				width : 240,
				height : 150,
				src : '{{best_for_app_image2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 109,
				height : 89,
				horizontalAlignment : 'left',
				verticalAlignment: 'center',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '57px',
				text : '{{page_text0}}'
			}, {
				type : 'text',
				x : 1040,
				y : 198,
				width : 780,
				height : 96,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				font : '27px',
				text : '{{page_text1}}'
			}, {
				type : 'text',
				x : 30,
				y : 721,
				width : 470,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 40),
				font : '22px',
				text : '{{page_text2}}'
			}, {
				type : 'text',
				x : 1040,
				y : 366,
				width : 780,
				height : 57,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 100),
				text : Volt.i18n.t('COM_SID_BEST_FOR'),
				font : '27px',
			}, {
				type : 'text',
				x : 1040,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text3}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1300,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text4}}',
				font : '22px',
			}, {
				type : 'text',
				x : 1560,
				y : 564,
				width : 521,
				height : 30,
				horizontalAlignment : 'left',
				textColor : Volt.hexToRgb('#000000', 60),
				text : '{{page_text5}}',
				font : '22px',
			},
		]
	},

	gamePageDepth : {
		type : 'widget',
		x : 1720,
		y : 30,
		width : 140,
		height : 20,
		id : 'page_depth',
		color : Volt.hexToRgb('#f2f2f2', 0),
		children : [{
				type : 'image',
				x : 0,
				y : 0,
				width : 20,
				height : 20,
			}, {
				type : 'image',
				x : 30,
				y : 0,
				width : 20,
				height : 20,
			}, {
				type : 'image',
				x : 60,
				y : 0,
				width : 20,
				height : 20,
			}, {
				type : 'image',
				x : 90,
				y : 0,
				width : 20,
				height : 20,
			}, {
				type : 'image',
				x : 120,
				y : 0,
				width : 20,
				height : 20,
			}, {
				type : 'image',
				x : 150,
				y : 0,
				width : 20,
				height : 20,
			}, 
		]
	},

	LeftArrorw : {
		type : 'image',
		x : 30,
		y : 358,
		width : 32,
		height : 56,
		opacity : 204,
		src : Volt.getRemoteUrl('images/1080/games/g_gcg_comon_arrow_l.png'),
	},

	RightArrow : {
		type : 'image',
		x : 1858,
		y : 358,
		width : 32,
		height : 56,
		opacity : 204,
		src : Volt.getRemoteUrl('images/1080/games/g_gcg_comon_arrow_r.png'),
	},

	gridList : {
		id:'GameControllerGuide',
		x : 0,
		y : 0,
		width : scene.width,
		height : scene.height * 0.713889,
		titleSpace : 0,
		groupSpace : 0,
		cellSpace : 0,
		focusRangeStartOffset : 0,
		focusRangeEndOffset : 0
	},

	buttonArea : {
		type : 'widget',

		children : [{
				type : 'widget',
				id : 'game_close_btn',
				custom : {'focusable' : true,},
				color : Volt.hexToRgb('#ffffff', 100),
				children : [{
					type : 'WinsetBtn',
					style : '{{style}}',
					buttonType : '{{buttonType}}',
					id:'ctrlClsBtn',
					x : 824,
					y : 807,
					width : 272,
					height : 68,
					text : Volt.i18n.t('COM_SID_CLOSE'),
				}]
			},
		],
	},

}
exports = GameControllerGuideTemplate;
