var noContentTemplate = {
	general:{
    	type:'widget',x:0,y:0,	
    	width:scene.width,height:864,
		color:Volt.hexToRgb('#dfdfdf'),
		children:[
		{
			type:'text',x:scene.width*0.046875,y:386,
			width:scene.width-2*scene.width*0.046875,height:scene.height*0.046296,
			font:'SVD Light 35px',
			textColor:Volt.hexToRgb('#000000',60),
			verticalAlignment:'center',
			horizontalAlignment:'center',
			color:Volt.hexToRgb('#dfdfdf'),
		},
		],
    },
	
	myPage:{
		type:'widget',
		x:0,y:0,width:scene.width,height:864,
		children:[
		{
			type:'text',
	    	x:0,y:0,
	    	width:scene.width,height:864,
	    	font:'SVD Light 35px',
	    	textColor:Volt.hexToRgb('#000000',60),
	    	verticalAlignment:'center',
	    	horizontalAlignment:'center',
	    	color:Volt.hexToRgb('#dfdfdf'),
		},
		{
                type : 'widget',
                x : 825,y : 660,width : 270,height : 66,
                id:'RETURN',
                color:{r:0,g:0,b:0,a:0},
                //custom: {focusable: true,},              
        }
		]
    	
    },
	
	coupon : { 
        type:'widget',
        x:0,y:0,width:scene.width,height:936,
        color : Volt.hexToRgb('#dfdfdf'),
        children:[
            {
                type : 'text',
                x : 0,y : 0,width : scene.width,height : 760,
                font : 'SVD Light 35px',
                textColor : Volt.hexToRgb('#000000',60),
                verticalAlignment : 'center',
                horizontalAlignment : 'center',            
            },
            {
                type : 'widget',
                x : 825,y : 760,width : 270,height : 66,
                id:'RETURN',
                color:{r:0,g:0,b:0,a:0},
                custom: {focusable: true,},              
            }
        ]
    },
    
    
    button:{
    	type : 'WinsetBtn',
		style : '{{style}}',
		buttonType : '{{buttonType}}',
		x : 0,
        y : 0,
        width : 270,
        height : 66,
		text : "",
    }

}
exports = noContentTemplate;
