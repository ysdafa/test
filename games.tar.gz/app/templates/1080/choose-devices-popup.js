/**
 * @author tiansx
 * @20140703
 */
var ChooseDevicesTemplate = {
    container : {
        type: 'widget',
        custom : {
            'focusable' : true,
            'onKeyEvent' : null
        },
        x : 0,
        y : scene.height * (1 - 0.588889) / 2,
        width : scene.width,
        height : scene.height * 0.588889,
        color : Volt.hexToRgb('#0f1826',85),
        children : [
        {
            type : 'text',
            id : 'choose-devices-title',
            x : scene.width * (1 - 0.584375) / 2,
            width : scene.width * 0.584375,
            height : scene.height * 0.089815,
            textColor : Volt.hexToRgb('#ffffff'),
            font : 'Samsung SVD_Medium 46px',
            text : Volt.i18n.t('COM_SID_CHOOSE_WHERE_WANT_TO_INSTALL_GAME'),
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            color : Volt.hexToRgb('#0f1826', 0)
        }, {
            type : 'widget',
            id : 'choose-devices-line',
            x : scene.width * (1 - 0.584375) / 2,
            y : scene.height * 0.089815,
            width : scene.width * 0.584375,
            height : 1,
            color : Volt.hexToRgb('#ffffff', 30)
        }, {
            type : 'widget',
            id : 'selected-device-container',
            x : scene.width * (1 - 0.584375) / 2,
            y : scene.height * (0.089815 + 0.025926),
            width : scene.width * 0.584375,
            height : scene.height * 0.044444,
            color : Volt.hexToRgb('#0f1826', 0)
        }, {
            type : 'widget',
            id : 'devices-container',
            x : scene.width * 0.199479,
            y : scene.height * (0.089815 + 0.025926 + 0.044444 + 0.018519),
            width : scene.width * 0.423958,
            height : scene.height * (0.080556 * 2 + 0.066667 * 4),
            color : Volt.hexToRgb('#0f1826', 0)
        }, {
            type : 'widget',
            id : 'button-container',
            x : scene.width * 0.651563,
            y : scene.height * 0.170370,
            width : scene.width * 0.140625,
            height : scene.height * (0.588889 - 0.170370 - 0.079630),
            color : Volt.hexToRgb('#0f1826', 0)
        }]
    },

    selectedDevice: {
        type: 'widget',
        width : scene.width * 0.584375,
        height : scene.height * 0.044444,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
        {
            type : 'text',
            id : "device-name",
            width : scene.width * 0.198438,
            height : scene.height * 0.046296,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff', 90),
            text : 'Device name',
            font : 'Samsung SVD_Light 34px'
        }, {
            type : 'text',
            id : "device-memory",
            x : scene.width * (0.416667 - 0.207813),
            width : scene.width * 0.198438,
            height : scene.height * 0.046296,
            horizontalAlignment : 'right',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff', 90),
            text : 'Memory',
            font : 'Samsung SVD_Light 34px'
        }]
    },
    
    chooseArea:{
        type: 'widget',
        width : scene.width * 0.423958,
        height : scene.height * (0.080556 * 2 + 0.066667 * 4),
        color: Volt.hexToRgb('#0f1826',0),
        children:[{
            type : 'image',
            id : 'choose-device-up-arrow',
            x : scene.width * (0.423958 - 0.407292) / 2,
            width : scene.width * 0.407292,
            height : scene.height * 0.080556,
            src: Volt.getRemoteUrl('images/1080/popup_arrow_up.png'),
            fillMode:"stretch",
        },
        {
            type : 'widget',
            id : 'choose-device-chooseArea',
            y : scene.height * 0.080556,
            width : scene.width * 0.423958,
            height : scene.height * 0.066667 * 4,
            color : Volt.hexToRgb('#0f1826', 0),
        },{
            type : 'image',
            id : 'choose-device-down-arrow',
            x : scene.width * (0.423958 - 0.407292) / 2,
            y : scene.height * (0.080556 + 0.066667 * 4),
            width : scene.width * 0.407292,
            height : scene.height * 0.080556,
            src: Volt.getRemoteUrl('images/1080/popup_arrow_down.png'),
            fillMode:"stretch",
        }]
    },
    
    deviceInfo : {
        type : 'widget',
        width : scene.width * 0.423958,
        height : scene.height * 0.066667,
        color : Volt.hexToRgb('#0f1826', 0),
        children : [{
            type : 'widget',
            y : scene.height * 0.066667 - 1,
            width : scene.width * 0.423958,
            height : 1,
            color : Volt.hexToRgb('#ffffff', 10),
        },{
            type : 'image', 
            width :0,
            height :0,
            src:'',
            fillMode:"stretch",
        }, {
            type : 'text',
            x : scene.width * 0.008333,
            width: scene.width * (0.423958 - 0.008333 * 2 - 0.006250)/2,
            height: scene.height * 0.066667 - 1,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font : "SVD Light 34px",
            textColor : Volt.hexToRgb('#ffffff', 80)
        }, {
            type : 'text',
            x : scene.width * (0.423958 + 0.006250)/2,
            width: scene.width * (0.423958 - 0.008333 * 2 - 0.006250)/2,
            height: scene.height * 0.066667 - 1,
            horizontalAlignment : 'right',
            verticalAlignment : 'center',
            font : "SVD Light 34px",
            textColor : Volt.hexToRgb('#ffffff', 80)
        }]
    },
    
    deviceInfoStyle : {//style E
        textColor : {
            normal : Volt.hexToRgb('#ffffff', 80),
            focused : Volt.hexToRgb('#464646', 100),
            selected : Volt.hexToRgb('#ffc21f', 80),
            disabled : Volt.hexToRgb('#ffffff', 30)
        },
        font : {
            normal : "Samsung SVD_Light 34px",
            focused : "Samsung SVD_Light 40px",
            selected : "Samsung SVD_Light 40px",
            disabled : "Samsung SVD_Light 34px",
        }
    },
    
    button:{
        type : 'widget',
        width : scene.width * 0.140625,
        height : scene.height * (0.588889 - 0.170370 - 0.079630),
        color : Volt.hexToRgb('#0f1826', 0),
        children : [{
            type : 'widget',
            id : 'Cancel',
            custom : {
                'focusable' : true,
            },
            y : scene.height * (0.588889 - 0.170370 - 0.079630 - 0.061111) / 2,
            width : scene.width * 0.140625,
            height : scene.height * 0.061111,
            color : Volt.hexToRgb('#ffffff', 0),
            children : [{
                type : 'WinsetBtn',
                style : '{{style}}',
                buttonType : '{{buttonType}}',
                id : 'cancelBtn',
                x : 0,
                y : 0,
                width : scene.width * 0.140625,
                height : scene.height * 0.061111,
                text : Volt.i18n.t('COM_SID_CANCEL')
            }]
        }]
    }
};

exports = ChooseDevicesTemplate;
