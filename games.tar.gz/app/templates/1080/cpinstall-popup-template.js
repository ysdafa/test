var CPInstallPopupTemplate = {
    container : {
        parent:scene,
        type: 'widget',
       
        x: 0, y: 385, width: 1920, height : 310,
        color : Volt.hexToRgb('#0f1826',85),
        children : [
            {
                type : 'widget',
                id : 'description-container',
                x : 570, y : 51, width : 780, height : 39,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : 570, y : 132, width : 780, height : 2,
                id : 'progressbar-container',
                color : Volt.hexToRgb('#ffffff',0),
                horizontalAlignment : 'center',
            },
            {
                type : 'widget',
                x : 570, y : 200, width : 780 , height : 66,
                id : 'button-container',
                color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    },
    description: {
        type: 'widget',
        x: 0, y: 0, width: 780, height: 39,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
        {
            type: 'text',
            x: 0, y: 0, width: 780, height: 39,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff',100),
            text : 'Downloading...',
            font : 'Samsung SVD_Light 34px'
        },
        /*
        {
            type: 'text',
            id:"progress",
            x: 0, y: 39, width: 780, height: 20,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff',100),
            text : 'Total(2/10)',
            font : 'Samsung SVD_Light 34px'
        }
        */
        ]
    },
    
    progressBar: {
        type: 'widget',        
        x: 0, y: 0, width: 780, height: 2,
        color : Volt.hexToRgb('#000000',0),
        id:'progressBar',        
    },
            
    button:{
        type : 'widget',
        x : 0, y : 0, width : 780, height : 66,
        color : Volt.hexToRgb('#000000',0),
        children: [
            {
                type : 'WinsetBtn',
				style : '{{style}}',
				buttonType : '{{buttonType}}',
                id : 'Cancel',
                custom : {'focusable' : true,},
                x:255,y:0,width: 270,height: 66,
                text:Volt.i18n.t('COM_SID_CANCEL')
            }
        ]
    }
};

exports = CPInstallPopupTemplate;