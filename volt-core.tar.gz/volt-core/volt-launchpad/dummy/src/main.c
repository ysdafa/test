#include <volt/sharedvc.h>
#include <dlog.h>
#include <unistd.h>
#include <stdio.h>
//const char *lic_key="db/menu/smart_hub/homedatacontrol/defaultdisclaimeragree";
#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "DUMMY"

int main(int argc, char **argv)
{
        LOGE("In main function");      
        bundle *blaunch = bundle_create();
        blaunch=bundle_import_from_argv(argc,argv);
        startVoltContainer(argc, argv, blaunch);
        bundle_free(blaunch);
        LOGE("waiting");

	return 0;
}

