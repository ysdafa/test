#include <poll.h>
#include <stdlib.h>
#include <stdio.h>
#include <bundle.h>
 
#include <stdbool.h>
#include <unistd.h>
#include "aul.h"
#include<sys/time.h>
#include <glib.h>
#include <dbg.h>
#include <sys/types.h> /* pid_t */
#include <errno.h>   /* errno */
#include <string.h>
#include <dlog.h>

#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "org.volt.launchpad"






#define DYNAMIC_PANEL 6
#define RETURN_VALUE 10
static int resetflag=0;
static int launchpadClientPid =0;
enum status {NOT_RUNNING, RUNNING, PRELAUNCHED};

static struct appInfo
{
char panelId[50];
char appId[50];
int status;
int pid;
} vappInfo[DYNAMIC_PANEL];

extern int aul_listen_app_dead_signal(int (*func) (int, void *), void *data);

char buffer[30];
struct timeval tv;
time_t curtime;

struct gmain
{
    GMainLoop* m_pGMainLoop;
};

void BundleIterator(const char *aKey, const char *aVal, void *aData)
{
   LOGE("bundle[%s] = %s\n", aKey, aVal);
}

void update_bundle(bundle *b)
{
	const char *val=NULL;
	val = bundle_get_val(b, "__APPID");

	if(val !=NULL)
	{
		bundle_del(b, "--root");
		bundle_del(b,"--app-js");
		bundle_del(b,"--data-path");
		if(strcmp(val,"org.volt.clips")==0)
		{
			LOGE("Inside update bundle:::  %s  \n",val);
			bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
			bundle_add(b,"--app-js", "/opt/down/panels/clips/src/app.js");
			bundle_add(b,"--data-path", "/opt/down/panels/clips/data");
		}
		if(strcmp(val,"org.volt.apps")==0)
		{
			LOGE("Inside update bundle:::  %s  \n",val);
			bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
			bundle_add(b,"--app-js", "/opt/down/panels/apps/src/app.js");
			bundle_add(b,"--data-path", "/opt/down/panels/apps_temp");
		}

		if(strcmp(val,"org.volt.games")==0)
		{
			LOGE("Inside update bundle:::  %s  \n",val);
			bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
			bundle_add(b,"--app-js", "/opt/down/panels/games/src/app.js");
    			bundle_add(b,"--data-path", "/opt/down/panels/games_temp");
		}

		if(strcmp(val,"org.volt.newson")==0)
		{
			LOGE("Inside update bundle:::  %s  \n",val);
			bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
		    	bundle_add(b,"--app-js", "/opt/down/panels/newson/src/app.js");
        		bundle_add(b,"--data-path", "/opt/down/panels/newson_temp");
		}

		if(strcmp(val,"org.volt.soccer")==0)
		{
			LOGE("Inside update bundle:::  %s  \n",val);
			bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
			bundle_add(b,"--app-js", "/opt/down/panels/soccer/src/app.js");
			bundle_add(b,"--data-path", "/opt/down/panels/soccer_temp");
		}

		if(strcmp(val,"org.volt.mycontents")==0)
		{
			LOGE("Inside update bundle:::  %s  \n",val);
			bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
			bundle_add(b,"--app-js", "/opt/down/panels/mycontents/src/app.js");
    			bundle_add(b,"--data-path", "/opt/down/panels/mycontents_temp");
		}
	}

	val=NULL;

}


void launchPad(bundle *blaunch)
{
   int i=0, flag=0, ret=-1;
    char *val = NULL;
   val = bundle_get_val(blaunch, "__APPID");

// check if the same sender is already registered with a dummy app
	ret =checkAppIdExists(val);
	LOGE(" checkAppIdExists return value %d \n",ret);

	if(ret>=0 && ret<DYNAMIC_PANEL)
	{
		if (aul_app_is_running(vappInfo[ret].panelId))
		{
			flag = aul_launch_app(vappInfo[ret].panelId,blaunch);
		}
		else
		{
 
			strncpy(vappInfo[ret].appId,"NULL", sizeof("NULL"));
			vappInfo[ret].status = NOT_RUNNING;
			vappInfo[ret].pid = NOT_RUNNING;
			ret = RETURN_VALUE;
		}	
	}

	LOGE(" aul_resume_app return value %d \n",flag );

	if(ret ==RETURN_VALUE)
	{
	// find prelaunched app launch app
	flag = findStatus(PRELAUNCHED);
		if(flag >=0 && flag <DYNAMIC_PANEL)
		{
		ret =aul_launch_app(vappInfo[flag].panelId, blaunch);
		vappInfo[flag].status =RUNNING;
		vappInfo[flag].pid =ret;
		}

	strncpy(vappInfo[flag].appId,val, sizeof(vappInfo[flag].appId)-1);

	LOGE(" aul_launch_app return value  %d vappInfo[flag].status %d flag %d  vappInfo[flag].appId %s vappInfo[flag].panelId %s \n",ret,vappInfo[flag].status,flag,vappInfo[flag].appId,vappInfo[flag].panelId);

	// find 0 status app
	flag = findStatus(NOT_RUNNING);
		if(flag >=0 && flag <DYNAMIC_PANEL)
		ret = prelaunchApp(flag );
	LOGE(" prelaunchApp(flag) return value %d  flag %d\n",ret,flag );
	}
}


int findStatus(int stat)
{
	int i=0;
	for(i=0;i<DYNAMIC_PANEL;i++)
	{
		if(vappInfo[i].status == stat)
		return i;
	}
return RETURN_VALUE;
}

int checkAppIdExists(char *val)
{
int i;
	for(i=0;i<DYNAMIC_PANEL;i++)
	{
		LOGE("vappInfo[i].appId %s val %s\n",vappInfo[i].appId,val);

		//if(vappInfo[i].appId != NULL)
		//{
			if(strcmp(vappInfo[i].appId, val) == 0 )
				return i;
		//}
	}
return RETURN_VALUE;
}




// found a dummy app being terminated normally
void cleanUp(int i)
{
strncpy(vappInfo[i].appId,"NULL", sizeof("NULL"));
vappInfo[i].status = NOT_RUNNING;
vappInfo[i].pid = NOT_RUNNING;

printStructureTree();

if(findStatus(PRELAUNCHED) == RETURN_VALUE)
prelaunchApp(i);
}

void printStructureTree()
{
int i;
LOGE("printStructureTree :::\n ");
	for(i=0;i<DYNAMIC_PANEL;i++)
	{
		
		LOGE("vappInfo[i].status :: %d\t", vappInfo[i].status);
		LOGE("vappInfo[i].pid :: %d\t", vappInfo[i].pid);
		LOGE("vappInfo[i].appId :: %s\t", vappInfo[i].appId);
		LOGE("vappInfo[i].panelId :: %s\n", vappInfo[i].panelId);
	}
}


int prelaunchApp(int index)
{
	LOGE("Inside prelaunch\n");
	int ret=0;
	bundle *b;
	//fprintf(stderr,"\nIn main function\n");

		if(index<0 || index> DYNAMIC_PANEL)
		return 0;
	
	b = bundle_create();
 	bundle_add(b, "prelaunch", "1");
	LOGE("bundle added %s  %d\n",vappInfo[index].panelId,index);
	if(resetflag==0)
	{
	LOGE("Inside prelaunch and resetflag value %d\n",resetflag);
	ret =aul_launch_app(vappInfo[index].panelId,b);
	LOGE("return value %d\n",ret);
	}
	else
	{
	LOGE("Inside prelaunch and resetflag value %d\n",resetflag);
	resetflag=0;
	LOGE("Inside prelaunch and resetflag value %d\n",resetflag);
	}
	vappInfo[index].status= PRELAUNCHED;
	vappInfo[index].pid= ret;

	bundle_free(b);
	//fprintf(stderr,"\nwaiting\n");
return ret;
}

int getPidIndex(int p)
{
int i=0;
	for(i=0;i<DYNAMIC_PANEL;i++)
	{
		if(vappInfo[i].pid == p)
		return i;
	}
return RETURN_VALUE;
}

static int _reseting(bundle *b, void *data)
{
 	const char * val=NULL;
	const char * dummy_pid=NULL;
	dummy_pid=bundle_get_val(b, "dummy_pid");
	bundle_iterate(b, BundleIterator,NULL );

		update_bundle(b);
		bundle_iterate(b, BundleIterator,NULL );

	val = NULL;
	val = bundle_get_val(b, "__APPID");
        if (val!=NULL)
	{
		
	#if 0
	
	if(resetflag==0)
	{
		resetflag=1;
  		LOGE("FirReseted\n");
		return 0;
	}
	else
	
	#endif
		LOGE("\n \n  bundle_get_val - dummy_pid:: %s\n \n \n ", dummy_pid);
		val = bundle_get_val(b, "__APPID");
		LOGE("\n \n  bundle_get_val - app Id:: %s\n \n \n ", val);
		
		if(val==NULL)
		   return 0;

		if(strcmp(val,"org.volt.apps")==0 ||strcmp(val,"org.volt.clips")==0 || strcmp(val,"org.volt.games")==0||strcmp(val,"org.volt.newson")==0||strcmp(val,"org.volt.soccer")==0|| strcmp(val,"org.volt.mycontents")==0)
		launchPad(b);

		val=NULL;
		return 0;
	}
}


int do_create()
{
	/* call real create callback*/
	//printf("=================================\n");
	int ret=0,i=0;
	char *panelIdArr[] = {"org.volt.dummy", "org.volt.dummy2", "org.volt.dummy3", "org.volt.dummy4", "org.volt.dummy5","org.volt.dummy6" };
  	for(i=0;i<DYNAMIC_PANEL;i++)
	{
	strncpy(vappInfo[i].appId ,"NULL",sizeof("NULL"));
	strncpy(vappInfo[i].panelId ,panelIdArr[i],sizeof(vappInfo[i].panelId)-1);
	}
	ret = prelaunchApp(findStatus(NOT_RUNNING));
	return ret;
}



static int aul_handler(aul_type type, bundle *kb, void *data)
{
	bundle *b;

	switch (type) {
	case AUL_START:
	//Reset appcore same
		LOGE("Inside AUL_START");
		b = bundle_dup(kb);
		_reseting(kb, NULL);
		//do_start((void *)b);
		bundle_free(b);
		break;
	case AUL_RESUME:
	// Resume appcore same
		LOGE("Inside AUL_RESUME");
		//do_resume();
		break;
	case AUL_TERMINATE:
		LOGE("Inside AUL_TERMINATE");
		//exit(0);
		break;
	default:
		break;
	}
	return 0;
}

int app_dead_handler(int pid, void *data)
{
	LOGE("===> %s : %d\n", __FUNCTION__, pid);
	int ret = RETURN_VALUE;
	if(pid == launchpadClientPid)
	{
	 	LOGE("launchpadClient killed abnormally\n");
		bundle *b = bundle_create();
 		bundle_add(b, "key", "org.volt.launchpad");
		launchpadClientPid  = aul_launch_app("org.volt.launchpadClient",b);
		bundle_free(b);
	}	
	
	ret = getPidIndex(pid);
	LOGE("\n%d::::::::: getPidIndex(dummy_pid):: %d\n",__LINE__, ret);
	//printStructureTree();
	if(ret!=RETURN_VALUE)
	cleanUp(ret);

	
	LOGE("Inside  app_dead_handler\n");
	return 0;
}

int app_launch_handler(int pid, void *data)
{
	LOGE("===> %s : %d\n", __FUNCTION__, pid);
	return 0;
}


int main(int argc, char **argv)
{
	//ecore_init();
	struct gmain gm;
	bundle *bsystemd;
	bsystemd=bundle_create();
	bsystemd=bundle_import_from_argv(argc,argv);
	const char* systemdval=NULL;
	systemdval=bundle_get_val(bsystemd,"systemdlaunch");
	if(systemdval!=NULL)
	{
		resetflag=1;
	}
	systemdval=NULL;
	bundle_free(bsystemd);
	#if 1
	bundle *b = bundle_create();
 	bundle_add(b, "key", "org.volt.launchpad");
	launchpadClientPid  = aul_launch_app("org.volt.launchpadClient",b);
	bundle_free(b);
	#endif

	int ret=do_create();
	LOGE("\n the value of ret by do_create %d \n",ret);

	if (aul_launch_init(aul_handler, NULL) < 0)
		LOGE("error aul_init\n");
	if (aul_launch_argv_handler(argc, argv) < 0)
		LOGE("error argv\n");

	aul_listen_app_dead_signal(app_dead_handler, NULL);
	aul_listen_app_launch_signal(app_launch_handler, NULL);

 	memset(&gm, 0x00, sizeof(gm));
	gm.m_pGMainLoop =g_main_loop_new (NULL, TRUE);
    	g_main_loop_run (gm.m_pGMainLoop);

	return 0;
}
