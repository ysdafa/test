 #include <poll.h>
#include <stdlib.h>
#include <stdio.h>
#include <bundle.h>
 
#include <stdbool.h>
#include <unistd.h>
#include "aul.h"
#include <sys/time.h>
#include <glib.h>
#include <sys/types.h> /* pid_t */
#include <errno.h>   /* errno */
#include <string.h>
#include <dlog.h>


#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "org.volt.launchpadClient"





static int resetflag=0;
static int launchpadPid =0;
extern int aul_listen_app_dead_signal(int (*func) (int, void *), void *data);
struct gmain
{
    GMainLoop* m_pGMainLoop;
};
extern int aul_listen_app_dead_signal(int (*func) (int, void *), void *data);
static void prt_bundle(const char *key, const char *value, void *d)
{
        LOGE("bundle - key: %s, value: %s\n", key, value);
}

void clientReset(bundle *kb)
{
	const char *appid = NULL;
	const char *voltappid = NULL;
	bundle *b;
	b=bundle_dup(kb);	
	bundle_iterate(kb, prt_bundle, NULL);

	LOGE("Inside Client Reset");
	appid = bundle_get_val(b, "__AUL_PKG_NAME__");
	voltappid = bundle_get_val(b, "voltAppID");
	LOGE("\n appid requested  %s and voltappid requested %s\n",appid,voltappid);
	//LOGE(stderr,"\n appid requested %s\n",appid);
	//launchpadPid  = aul_launch_app("org.volt.launchpad",b);
	if(appid !=NULL)
	{
		LOGE("\nInside Client Reset appid %s and launched FS without systemd \n",appid);
		bundle_add(b,"__APPID",appid);
		if(strncmp(appid ,"org.volt.clips",sizeof("org.volt.clips"))==0)
		{
			aul_launch_app("org.volt.launchpad",b);
		}
		if(strncmp(appid ,"org.volt.apps",sizeof("org.volt.apps"))==0)
		{
		LOGE("\nInside Client Reset appid %s and launched FS without systemd \n",appid);
			aul_launch_app("org.volt.launchpad",b);
		LOGE("\nInside Client Reset appid %s and launched FS without systemd \n",appid);
		}

		if(strncmp(appid ,"org.volt.games",sizeof("org.volt.games"))==0)
		{
			aul_launch_app("org.volt.launchpad",b);
		}

		if(strncmp(appid ,"org.volt.newson",sizeof("org.volt.newson"))==0)
		{
			aul_launch_app("org.volt.launchpad",b);
		}

		if(strncmp(appid ,"org.volt.soccer",sizeof("org.volt.soccer"))==0)
		{
			aul_launch_app("org.volt.launchpad",b);
		}

		if(strncmp(appid ,"org.volt.mycontents",sizeof("org.volt.mycontents"))==0)
		{
			aul_launch_app("org.volt.launchpad",b);
		}
	}
	else if(voltappid !=NULL)
        {

                LOGE("\nInside Client Reset appid %s and launched FS without systemd \n",voltappid);
                bundle_add(b,"__APPID",voltappid);
                bundle_add(b,"systemdlaunch","1");
                if(strncmp(voltappid ,"org.volt.clips",sizeof("org.volt.clips"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }
                if(strncmp(voltappid ,"org.volt.apps",sizeof("org.volt.apps"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(voltappid ,"org.volt.games",sizeof("org.volt.games"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(voltappid ,"org.volt.newson",sizeof("org.volt.newson"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(voltappid ,"org.volt.soccer",sizeof("org.volt.soccer"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(voltappid ,"org.volt.mycontents",sizeof("org.volt.mycontents"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }


        }
	else
	{
		LOGE("\nInside Client Reset appid %s and launched FS without systemd \n",voltappid);
		const char * appsvcid=NULL; 
		appsvcid=bundle_get_val(b,"__APP_SVC_PKG_NAME__");
		if(appsvcid!=NULL)
		{
		bundle_add(b,"__APPID",appsvcid);
                bundle_add(b,"systemdlaunch","1");
		
                if(strncmp(appsvcid ,"org.volt.clips",sizeof("org.volt.clips"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }
                if(strncmp(appsvcid ,"org.volt.apps",sizeof("org.volt.apps"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(appsvcid ,"org.volt.games",sizeof("org.volt.games"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(appsvcid ,"org.volt.newson",sizeof("org.volt.newson"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(appsvcid ,"org.volt.soccer",sizeof("org.volt.soccer"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }

                if(strncmp(appsvcid ,"org.volt.mycontents",sizeof("org.volt.mycontents"))==0)
                {
                        aul_launch_app("org.volt.launchpad",b);
                }
		}
	}


/*
	if(resetflag==0)
	{
		resetflag=1;
  		LOGE("FirReseted\n");
		//return 0;
	}
	else
	{
	LOGE("Inside Client Reset 2nd time");
	appid = bundle_get_val(b, "__AUL_PKG_NAME__");
	bundle_add(b,"__APPID",appid);
	fprintf(stderr,"\n appid requested %s\n",appid);
	aul_launch_app("org.volt.launchpad",b);
	
 	LOGE("Sender stops \n");
	
	}
*/
appid = NULL;
voltappid = NULL;
bundle_free(b);
return 0;

}


static int aul_handler(aul_type type, bundle *kb, void *data)
{

	switch (type) {
	case AUL_START:
	//Reset appcore same
		clientReset(kb);
		//do_start((void *)b);
		break;
	case AUL_RESUME:
	// Resume appcore same
		//do_resume();
		break;
	case AUL_TERMINATE:
		//exit(0);
		break;
	default:
		break;
	}
	return 0;

}
 

int app_dead_handler(int pid, void *data)
{
	LOGE("===> %s : %d\n", __FUNCTION__, pid);
	if(pid == launchpadPid)
	{
	 	LOGE("launchpad killed abnormally\n");
	}	
	
	LOGE("Inside  app_dead_handler\n");
	return 0;
}

int app_launch_handler(int pid, void *data)
{
	LOGE("===> %s : %d\n", __FUNCTION__, pid);
	return 0;
}


int main(int argc, char **argv)
{
	//ecore_init();
	struct gmain gm;

		
	if (aul_launch_init(aul_handler, NULL) < 0)
		LOGE("error aul_init\n");
	if (aul_launch_argv_handler(argc, argv) < 0)
		LOGE("error argv\n");

	aul_listen_app_dead_signal(app_dead_handler, NULL);
	aul_listen_app_launch_signal(app_launch_handler, NULL);

 	memset(&gm, 0x00, sizeof(gm));
	gm.m_pGMainLoop =g_main_loop_new (NULL, TRUE);
    	g_main_loop_run (gm.m_pGMainLoop);

	return 0;
}
