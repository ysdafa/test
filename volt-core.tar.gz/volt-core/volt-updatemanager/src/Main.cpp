/** 
* @file	Main.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "UpdateManager.h"
#include "NetworkIORequest.h"
#include "UpdateManagerUtil.h"
#include "Define.h"
#include "AppDrm.h"
#include "UpdateManagerLog.h"

#include <unistd.h>

static Logger logger("volt.updatemanager.main");

/** 
* @fn    			  	int main(void)                
* @brief          Main function of Update Manager.
* @exception			N/A
*/
int main()
{
//	ExecShell(APPS);
//	ExecShell("sync");
	VoltPanelUpdateManager m_VoltPanelUpdateManager;
	if(m_VoltPanelUpdateManager.setEmpInfo()) // set up Pre-Install EMP Information
	{
		m_VoltPanelUpdateManager.setEmpFlag(true);
	}
	else
	{
		LOG_FATAL(logger, "EMP File is not exist!");
	}
	
	if(m_VoltPanelUpdateManager.setPanelInfo()) // set up Pre-Install AppPanel Information
	{
		if(!m_VoltPanelUpdateManager.getPanelVector().empty())
		{
			m_VoltPanelUpdateManager.comparePanelVersion(); // Update App Panel
		}
		else
		{
			LOG_FATAL(logger, "Panel Vector is empty!");
		}        
	}
	else
	{
		LOG_FATAL(logger, "Panel File is not exist!");
	}

	if(m_VoltPanelUpdateManager.getEmpFlag())
	{
		m_VoltPanelUpdateManager.compareEmpVersion(); // Update EMP
	}
	
	return 0;
}
