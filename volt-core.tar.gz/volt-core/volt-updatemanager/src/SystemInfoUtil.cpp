/** 
* @file	SystemInfoUtil.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "SystemInfoUtil.h"
#include "UpdateManagerUtil.h"
#include "UpdateManagerLog.h"

static Logger logger("volt.updatemanager.systeminfo");

/** 
* @fn    			  	bool getResolution(std::string &resolution)      
* @brief          
* @exception			N/A
*/
bool getResolution(std::string &resolution)
{
	int iResult = -1;
	int iRetValue = -1;
	
	iResult = system_info_get_value_int(SYSTEM_INFO_KEY_SCREEN_HEIGHT,  &iRetValue);
	
	if (iResult != SYSTEM_INFO_ERROR_NONE)
	{
		LOG_FATAL(logger, "Failed to get value for Resolution[" << SYSTEM_INFO_KEY_SCREEN_HEIGHT << "]" );
		iRetValue = 0;
		return false;
	}
	else if(iRetValue !=NULL)
	{
		LOG_FATAL(logger, "Return value of Resolution[" << SYSTEM_INFO_KEY_SCREEN_HEIGHT << "] is [" << iRetValue << "]!");
	}
	resolution = IntegerToString(iRetValue);
	return true;	
}

/** 
* @fn    			  	bool getLanguage(std::string &language)
* @brief          
* @exception			N/A
*/
bool getLanguage(std::string &language)
{
	char* pRetValue = NULL;
	int   iResult      = RUNTIME_INFO_ERROR_NONE;
	iResult = runtime_info_get_value_string(RUNTIME_INFO_KEY_LANGUAGE, &pRetValue);

	if(RUNTIME_INFO_ERROR_NONE != iResult)
	{
		LOG_FATAL(logger, "faied to get RUNTIME_INFO_kEY_LANGUAGE(" << RUNTIME_INFO_KEY_LANGUAGE << "),ret=" << iResult << "%d");
		return false;
	}
	else
	{
		LOG_FATAL(logger, "get RUNTIME_INFO_KEY_LANGUAGE(" << RUNTIME_INFO_KEY_LANGUAGE << "),value=" << pRetValue);
		language = pRetValue;
		int pos = language.find("_");
		language = language.substr(0,pos);
	}
	
	free(pRetValue);
	return true;	
}
