/** 
* @file	UpdateManagerUtil.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "UpdateManagerUtil.h"
#include "Define.h"

/** 
* @fn    			    int UpdateManagerUtil::ExecShell(const char* command)   
* @brief          
* @exception			N/A
*/
int ExecShell(const char* command)
{
	int status = 0;
	pid_t pid;
/*
	if ((pid = vfork()) == 0)
	{
		execl ("/bin/sh", "/bin/sh", "-c", command, NULL);
		_exit (1);
	}
	else if (pid < 0)
	{
		status = -1;
	}
	else
	{
		status = 0;
		if (waitpid (pid, &status, 0) != pid)
		{
			status = -1;
		}
	}*/
	return status;
}

/** 
* @fn    			    void UpdateManagerUtil::Snprintf(char* str, int size, const char* format, ...)     
* @brief          
* @exception			N/A
*/
void Snprintf(char* str, int size, const char* format, ...)
{
	va_list arg;
	va_start(arg, format);
	vsnprintf(str, size, format, arg);
	va_end(arg);
}

/** 
* @fn    			    std::string LLongToString(const long long num)          
* @brief          
* @exception			N/A
*/
std::string LLongToString(const long long num)
{
	char data[BUFFER_SIZE] ={0, };
	std::string strdata = "";
	Snprintf(data, sizeof(data), "%lld", num);
	strdata = data;

	return strdata;

}

/** 
* @fn    			    time_t UpdateManagerUtil::requestTime(void)   
* @brief          
* @exception			N/A
*/
time_t requestTime()
{
	time_t now;
	now = time(NULL);
	return now;
}

/** 
* @fn    			    std::string IntegerToString(const int num)           
* @brief          
* @exception			N/A
*/
std::string IntegerToString(const int num)
{
	char pszData[128] = {0,};
	std::string strData = "";

	Snprintf(pszData, sizeof(pszData), "%d", num);
	strData = pszData;

	return strData;	
}
