/** 
* @file	NetworkIORequest.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "NetworkIORequest.h"
#include "UpdateManager.h"
#include "NetworkUtil.h"
#include "Define.h"
#include "XMLParse.h"
#include "AppDrm.h"
#include "SystemInfoUtil.h"
#include "UpdateManagerLog.h"

static Logger logger("volt.updatemanager.network");

/** 
* @fn    			 size_t NetworkRequest::send_query_receiver(void* buf, size_t& size, size_t& nmemb, void* userp)           
* @brief       CURL Receive Function   
* @exception	 N/A	
*/
size_t send_query_receiver(void* buf, size_t size, size_t nmemb, void* userp) //CURL Receive Function
{
	string& s = *reinterpret_cast<std::string*>(userp);
	s.append(reinterpret_cast<char*>(buf), size * nmemb);
	LOG_DEBUG(logger, "Header Info : " << s);
	return size * nmemb;
}

/** 
* @fn    			 size_t NetworkRequest::writeData(void* ptr, const size_t size, const size_t nmemb, FILE* stream)         
* @brief       CURL File Receive Function  
* @exception	 N/A	
*/
size_t writeData(void* ptr, const size_t size, const size_t nmemb, FILE* stream) //CURL File Receive Function
{
	size_t written;
	written = fwrite(ptr, size, nmemb, stream);
	return written;
}

/** 
* @fn    			 string NetworkRequest::setXMLBody(const string appid)     
* @brief       Set up Body (for using Opne API POST Type)
* @exception	 N/A	
*/
string setXMLBody(const string appid) // set up Body (for using Opne API POST Type)
{
	string strbody ="";
	string license = "";
	generateRequestLicense(appid, license);
	strbody += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	strbody += "<drm>";
	strbody += "<licenseRequest>";
	strbody += "<![CDATA[";
	strbody += license;
	strbody += "]]>";
	strbody += "</licenseRequest>";
	strbody += "</drm>";

	return strbody;
}

/** 
* @fn    			 curl_slist* NetworkRequest::setEMPInfoHeader(void)    
* @brief       Set up EMP Header(using Open API, Type : GET)
* @exception	 N/A	
*/
curl_slist* setEMPInfoHeader() // set up EMP Header(using Open API, Type : GET)
{
	struct curl_slist *headers = NULL;
	string country_code;
	string infolink_ver;
	string model_id;
	string duid;
	string firm_code;   
	string atoken;
	string app_key;
	string mac;
	string temp;
	
/*	if(was_create_token_proxy("UpdateManager") == WAS_TRUE) // WAS Token API Open
	{
		char *apps;
		if(was_get_appkey(&apps) == WAS_TRUE)
		{
			app_key = string(APPS_APPKEY) + string(apps);
			headers = curl_slist_append(headers, app_key.c_str());
			free(apps);
			LOG_DEBUG(logger, app_key);
		}
		else
		{
			LOG_FATAL(logger, "Get AppKey fail!");
			free(apps);
			return NULL;
		}
*/
/*		char* duids = vconf_get_str("db/comss/duid");
		if(duids == 0)
		{
			LOG_FATAL(logger, "Get DUID fail!");
			free(duids);
			return NULL;
		}
		else
		{
			duid = string(REQUEST_DUID) + string(duids);
			headers = curl_slist_append(headers, duid.c_str());
			free(duids);
			LOG_DEBUG(logger, duid);
		}

		NetworkUtil EMP_Network;
		
		if(EMP_Network.getMacAddress(temp))
		{
			mac = string(EMP_MAC) + temp;
			headers = curl_slist_append(headers, mac.c_str());
			LOG_DEBUG(logger, mac);
		}
		else
		{
			return NULL;
		}

/*		char *firm;
		if(was_get_infolink_ver(&firm) == WAS_TRUE)
		{
			infolink_ver = string(REQUEST_FIRMCODE) + string(firm);
			headers = curl_slist_append(headers, infolink_ver.c_str());
			free(firm);
			LOG_DEBUG(logger, infolink_ver);
		}
		else
		{
			free(firm);
			LOG_FATAL(logger, "Get Infolink version fail!");
			return NULL;
		}
*/
/*		char* model = vconf_get_str("db/comss/modelid");
		if(model == 0)
		{
			LOG_FATAL(logger, "Get Model code fail!");
			free(model);
			return NULL;
		}
		else
		{
			model_id = string(REQUEST_MODELID) + string(model);
			headers = curl_slist_append(headers, model_id.c_str());
			free(model);
			LOG_DEBUG(logger, model_id);
		}

		char* country = vconf_get_str("db/comss/countrycode");
		if(country == 0)
		{
			LOG_FATAL(logger, "Get DUID fail!");
			free(country);
			return NULL;
		}
		else
		{
			country_code = string(REQUEST_COUNTRYCODE) + string(country);
			headers = curl_slist_append(headers, country_code.c_str());
			free(country);
			LOG_DEBUG(logger, country_code);
		}
		
		headers = curl_slist_append(headers, EMP_CATEGORY);
		LOG_DEBUG(logger, EMP_CATEGORY);
		headers = curl_slist_append(headers, EMP_PARAM);
		LOG_DEBUG(logger, EMP_PARAM);
		
//	}
*/
	return headers;
	
}

/** 
* @fn    			 bool NetworkRequest::requestServerEMPInfo(string url, string &result, vector<EmpInfo>::iterator it)    
* @brief       Get the EMP Download url 
* @exception	 N/A	
*/
bool requestServerEMPInfo(string url, string &result, vector<EmpInfo>::iterator it) // Get the EMP Download url 
{
	CURL *curl;
	CURLcode res;
	string response;
	curl = curl_easy_init();

	if(!curl)
	{
		LOG_FATAL(logger, "Failed to initialize curl!");
		return false;
	}

	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, send_query_receiver);  
	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	res = curl_easy_perform(curl);
	
	if(CURLE_OK == res)
	{
		if( !(parseEMPInstallURL(response.c_str(), result, it)))
		{
			return false;
		}
		LOG_DEBUG(logger, "EMPDownURL = [" << result << "]");
		curl_easy_cleanup(curl);
		return true;
	}

	else
	{
		LOG_FATAL(logger, "Curl Error!");
		curl_easy_cleanup(curl);
		return false;
	}



	return true;
}
/** 
* @fn    			 bool NetworkRequest::downloadEMP(string url, vector<EmpInfo>::iterator it)
* @brief       Download EMP, /opt/down/emps/empname_img/emp1 or emp2 /empname.zip
* @exception	 N/A	
*/
bool downloadEMP(string url, vector<EmpInfo>::iterator it)//Download EMP, /opt/down/emps/empname_img/emp1 or emp2 /empname.zip
{
	CURL *curl;
	CURLcode res;
	curl = curl_easy_init();

	if(!curl)
	{
		LOG_FATAL(logger, "Failed to initialize curl!");
		return false;
	}        

	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	FILE *file;

	string filename = string(EMP_PATH) + "/" + it->getEmpName()+ "_img/temp/" + it->getEmpName() + ".img";
	string path = string(EMP_PATH) + "/" + it->getEmpName() + "_img/temp/";
	string makecommand = "mkdir -p " + path;
	string deletecommand = "rm -rf " + path;

	string changeflag;
	string makeflagcommand;
	if(it->getFlag()== "emp1") //Check flag 
	{
		changeflag = "emp2";
		makeflagcommand = "mkdir -p " + string(EMP_PATH) + "/" + it->getEmpName() + "_img/" + changeflag;
		ExecShell(makeflagcommand.c_str());
		ExecShell("sync");
		
	}
	else
	{
		changeflag = "emp1";
		makeflagcommand = "mkdir -p " + string(EMP_PATH) + "/" + it->getEmpName() + "_img/" + changeflag;
		ExecShell(makeflagcommand.c_str());	
		ExecShell("sync");
	}
	string movecommand = "mv " + path + "*.* " + string(EMP_PATH) + "/" + it->getEmpName() +"_img/" + changeflag + "/";
	
	ExecShell(makecommand.c_str());
	ExecShell("sync");

/*	if((file = fopen(filename.c_str(), "w")) != NULL)
	{
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeData);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);
	}

	else
	{
		LOG_FATAL(logger, "file is not exist!");
		ExecShell(deletecommand.c_str());
		ExecShell("sync");
		return false;
	}

	res = curl_easy_perform(curl);

	if(CURLE_OK == res)        
	{
		curl_easy_cleanup(curl);
		fclose(file);
		ExecShell(movecommand.c_str());
		ExecShell("sync");
		ExecShell(deletecommand.c_str());
		ExecShell("sync");
		return true;
	}

	else
	{
		LOG_FATAL(logger, "Curl Error!");
		curl_easy_cleanup(curl);
		fclose(file);
		ExecShell(deletecommand.c_str());
		ExecShell("sync");
		return false;
	}*/
	return false;
}

/** 
* @fn    			 curl_slist* NetworkRequest::setAppInstallHeader(string appid) 
* @brief       Set up App Install Header(using Open API, Type : POST)
* @exception	 N/A	
*/
curl_slist* setAppInstallHeader(string appid) // set up App Install Header(using Open API, Type : POST)
{
	struct curl_slist *headers = NULL;
	string country_code;
	string infolink_ver;
	string client;
	string model_id;
	string duid;
	string firm_code;   
	string atoken;
	string app;
	string app_key;
	string resolution;
	string temp;
	string language;
	
	headers = curl_slist_append(headers, CACHE_CONTROL);
	LOG_DEBUG(logger, CACHE_CONTROL); 

/*	if(was_create_token_proxy("DownLoadManager") == WAS_TRUE) // WAS Token API Open
	{

		char* info;
		if(was_get_infolink_ver(&info) == WAS_TRUE)
		{
			client = string(REQUEST_CLIENT) + string(info) + string(REQUEST_SMARTHUB);
			headers = curl_slist_append(headers, client.c_str());
			free(info);
			LOG_DEBUG(logger, client);
		}
		else
		{
			free(info);
			LOG_FATAL(logger, "Get Infolink version fail!");
			return NULL;
		}  
*/
/*		char* duids = vconf_get_str("db/comss/duid");
		if(duids == 0)
		{
			LOG_FATAL(logger, "Get DUID fail!");
			free(duids);
			return NULL;
		}
		else
		{
			duid = string(REQUEST_DUID) + string(duids);
			headers = curl_slist_append(headers, duid.c_str());
			free(duids);
			LOG_DEBUG(logger, duid);
		}		

		char* country = vconf_get_str("db/comss/countrycode");
		if(country == 0)
		{
			LOG_FATAL(logger, "Get Country code  fail!");
			free(country);
			return NULL;
		}
		else
		{
			country_code = string(REQUEST_COUNTRYCODE) + string(country);
			headers = curl_slist_append(headers, country_code.c_str());
			free(country);
			LOG_DEBUG(logger, country_code);
		}

		char* model = vconf_get_str("db/comss/modelid");
		if(model == 0)
		{
			LOG_FATAL(logger, "Get Model code fail!");
			free(model);
			return NULL;
		}
		else
		{
			model_id = string(REQUEST_MODELID) + string(model);
			headers = curl_slist_append(headers, model_id.c_str());
			free(model);
			LOG_DEBUG(logger, model_id);
		}

		

/*		char *firm;
		if(was_get_infolink_ver(&firm) == WAS_TRUE)
		{
			infolink_ver = string(REQUEST_FIRMCODE) + string(firm);
			headers = curl_slist_append(headers, infolink_ver.c_str());
			free(firm);
			LOG_DEBUG(logger, infolink_ver);
		}
		else
		{
			free(firm);
			LOG_FATAL(logger, "Get Infolink version fail!");
			return NULL;
		}
*/
/*		headers = curl_slist_append(headers, APPS_RESOLUTION);
		LOG_DEBUG(logger, APPS_RESOLUTION);
		app = string(APPS_APPID_LIST) + appid;
		headers = curl_slist_append(headers, app.c_str());
		LOG_DEBUG(logger, app);

		if(getLanguage(temp))
		{
			language = APPS_LANGUAGE + temp;
			headers = curl_slist_append(headers, language.c_str());
			LOG_DEBUG(logger, language);
		}

		else
		{
			LOG_FATAL(logger, "Get Language fail!");
			return NULL;
		}

		headers = curl_slist_append(headers, APPS_VLEV);

		LOG_DEBUG(logger, APPS_VLEV);
/*
		char *apps;
		if(was_get_appkey(&apps) == WAS_TRUE)
		{
			app_key = string(APPS_APPKEY) + string(apps);
			headers = curl_slist_append(headers, app_key.c_str());
			free(apps);
			LOG_DEBUG(logger, app_key);
		}
		else
		{
			free(apps);
			LOG_FATAL(logger, "Get AppKey fail!");
			return NULL;
		}
*/
/*		char *token = vconf_get_str("db/comss/atoken");
		if(token == 0)
		{
			free(token);
			LOG_FATAL(logger, "Get AToken Fail!");
			return NULL;
		}
		else
		{
			atoken = string(REQUEST_ATOKEN) + string(token);
			headers = curl_slist_append(headers, atoken.c_str());
			free(token);
			LOG_DEBUG(logger, atoken);
		}

//	}

/*	else
	{
		LOG_FATAL(logger, "Connection is not exist, get token proxy fail!");
		return NULL;
	}*/
//	was_destroy_token_proxy();  
	return headers;

}

/** 
* @fn    			 bool NetworkRequest::downloadApp(string url, vector<PanelInfo>::iterator it)
* @brief       Download App, /opt/down/panels/appind_img/panel1 or panel2 /appid.img
* @exception	 N/A	
*/
bool downloadApp(string url, vector<PanelInfo>::iterator it) //Download App, /opt/down/panels/appind_img/panel1 or panel2 /appid.img
{
	CURL *curl;
	CURLcode res;
	curl = curl_easy_init();

	if(!curl)
	{
		LOG_FATAL(logger, "Failed to initialize curl!");
		return false;
	}        

	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	FILE *file;

	string filename = string(PANEL_PATH) + "/" + it->getAppId() + "_img/temp/" + it->getAppId() + ".img";
	string path = string(PANEL_PATH) + "/" + it->getAppId() + "_img/temp/";
	
	string makecommand = "mkdir -p " + path;
	string deletecommand = "rm -rf " + path;

	string changeflag;
	string makeflagcommand;	
	if(it->getFlag()== "panel1")
	{
		changeflag = "panel2";
		makeflagcommand = "mkdir -p " + string(PANEL_PATH) + "/" + it->getAppId() + "_img/" + changeflag;
		ExecShell(makeflagcommand.c_str());
		ExecShell("sync");
	}
	else
	{
		changeflag = "panel1";
		makeflagcommand = "mkdir -p " + string(PANEL_PATH) + "/" + it->getAppId() + "_img/" + changeflag;
		ExecShell(makeflagcommand.c_str());	
		ExecShell("sync");
	}
	string movecommand = "mv " + path + "*.* " + string(PANEL_PATH) + "/" + it->getAppId() +"_img/" + changeflag + "/";

	ExecShell(makecommand.c_str());
	ExecShell("sync");

/*	if((file = fopen(filename.c_str(), "w")) != NULL)
	{
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeData);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);
	}

	else
	{
		ExecShell(deletecommand.c_str());    
		ExecShell("sync");
		LOG_FATAL(logger, "file is not exist!");
		return false;
	}
*/
	res = curl_easy_perform(curl);
	string strLicenseFile = string(PANEL_PATH) + "/" + it->getAppId() + "_img/" + string(APPS_LICENSE_NAME);
/*	if(CURLE_OK == res)        
	{
		curl_easy_cleanup(curl);
		fclose(file);
		ExecShell(movecommand.c_str());
		ExecShell("sync");
		ExecShell(deletecommand.c_str());
		ExecShell("sync");
		if(InstallAppsLicense(strLicenseFile, it)) // install License
		{
			LOG_FATAL(logger, "AppLicense Install Success!");
			return true;
		}
		else
		{
			LOG_FATAL(logger, "AppLicense Install Fail!");	
			return false;
		}
	}

	else
	{
		LOG_FATAL(logger, "Curl Error!");
		curl_easy_cleanup(curl);
		fclose(file);
		ExecShell(deletecommand.c_str());
		ExecShell("sync");
		return false;
	}*/

	return false;
}

/** 
* @fn    			 bool NetworkRequest::requestAppInstall(vector<PanelInfo>::iterator it)
* @brief       
* @exception	 N/A	
*/
bool requestAppInstall(vector<PanelInfo>::iterator it)
{
	CURL *curl;
	CURLcode res;
	struct curl_slist *headers = NULL;
	string url;
	long long time = requestTime();
	long long timegap = time*1000;
	string strTimegap = "timestamp=" + LLongToString(timegap);
	string xmlbody = setXMLBody(it->getAppId()); //body setting
	string response;
	string downurl;
//	headers = setAppInstallHeader(it->getAppId()); //header setting
	curl = curl_easy_init();
	LOG_DEBUG(logger, "xmlbody : " << xmlbody);
/*	if(headers == NULL)
	{
		LOG_FATAL(logger, "Header is wrong!");
		return false;
	}
	
	if(!curl)
	{
		LOG_FATAL(logger, "Failed to initialize curl!");
		return false;
	}        
*/
	url = string(APPS_DOWN_URL) + strTimegap;
	LOG_DEBUG(logger, "URL : " << url);
	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	curl_easy_setopt(curl, CURLOPT_POST, 1L); //POST Method
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, xmlbody.c_str());
	curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, xmlbody.size());	
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, send_query_receiver);
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, HTTP_MAX_TIMEOUT);

	curl_easy_setopt(curl, CURLOPT_SSLCERT, NULL);
	curl_easy_setopt(curl, CURLOPT_SSLCERTTYPE, NULL);
	curl_easy_setopt(curl, CURLOPT_SSLKEY, NULL);
	curl_easy_setopt(curl, CURLOPT_SSLKEYTYPE, NULL);
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 1);
	curl_easy_setopt(curl, CURLOPT_SSL_SESSIONID_CACHE, 1);

	res = curl_easy_perform(curl);


/*	if(CURLE_OK == res)
	{   
		if(!(parseAppInstallURL(response.c_str(), downurl, it)))
		{
			return false;
		}

		curl_easy_cleanup(curl);
		if(downloadApp(downurl, it))
		{
			if(it->changeFlag())
			{
				LOG_FATAL(logger, "Flag File is Update Success!");
				return true;
			}
			
			else
			{
				LOG_FATAL(logger, "Flag File is Update Fail!");			
				return false;
			}
		}
		else
		{
			LOG_FATAL(logger, "DownLoad Fail!");
			return false;
		}
	}
	else
	{
		LOG_FATAL(logger, "Curl Error! " << curl_easy_strerror(res) );
		curl_easy_cleanup(curl);
		return false;
	}

*/
	return false;
}

/** 
* @fn    			 bool NetworkRequest::requestEMPInstall(vector<EmpInfo>::iterator it)
* @brief       
* @exception	 N/A	
*/
bool requestEMPInstall(vector<EmpInfo>::iterator it)
{
	CURL *curl;
	CURLcode res;
	struct curl_slist *headers = NULL;
	string url;
	string response;
	string infourl;
	string downurl;
	headers = setEMPInfoHeader(); //header setting
	curl = curl_easy_init();

	if(headers == NULL)
	{
		LOG_FATAL(logger, "Header is wrong!");
		return false;
	}
	
	if(!curl)
	{
		LOG_FATAL(logger, "Failed to initialize curl!");
		return false;
	}        

	url = string(EMP_DOWN_URL);
	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	curl_easy_setopt(curl, CURLOPT_HTTPGET, 1); //GET Method
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, send_query_receiver);  

	curl_easy_setopt(curl, CURLOPT_SSLCERT, NULL);
	curl_easy_setopt(curl, CURLOPT_SSLCERTTYPE, NULL);
	curl_easy_setopt(curl, CURLOPT_SSLKEY, NULL);
	curl_easy_setopt(curl, CURLOPT_SSLKEYTYPE, NULL);
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 1);
	curl_easy_setopt(curl, CURLOPT_SSL_SESSIONID_CACHE, 1);

	res = curl_easy_perform(curl);
	curl_slist_free_all(headers);
	if(CURLE_OK == res)
	{
		if((!parseEMPServerURL(response.c_str(), infourl)))
		{
			curl_easy_cleanup(curl);
			return false;
		}
		curl_easy_cleanup(curl);

		if(requestServerEMPInfo(infourl, downurl, it))
		{
			if(downloadEMP(downurl, it))
			{
				if(it->changeFlag())
				{
					LOG_FATAL(logger, "Flag File is Update Success!");
					return true;
				}
				
				else
				{
					LOG_FATAL(logger, "Flag File is Update Fail!");
					return false;
				}
			}

			else
			{
				LOG_FATAL(logger, "DownLoad Fail!");
				return false;
			}
		}

		else
		{
			LOG_FATAL(logger, "EMP Download URL is wrong!");
			return false;
		}

	}

	else
	{
		LOG_FATAL(logger, "Curl Error! " << curl_easy_strerror(res));
		curl_easy_cleanup(curl);
		return false;
	}

	return false;
}


