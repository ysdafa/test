/** 
* @file	AppDrm.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "AppDrm.h"
#include "Define.h"
#include "UpdateManagerLog.h"

static Logger logger("volt.updatemanager.appdrm");

/** 
* @fn    					bool generateRequestLicense(const std::string& appID, std::string& appLicense)                
* @brief          Request App License
* @exception			N/A
*/
bool generateRequestLicense(const std::string appID, std::string &appLicense) // Request App License
{
	if(appID.empty())
	{
		LOG_FATAL(logger, "App ID is empty!");
		return false;
	}

	char *request = NULL;
	size_t requestlen = -1;
	int license_request = appdrm_generate_license_request(appID.c_str(), &request, &requestlen);

	if(license_request != 0)
	{
		LOG_FATAL(logger, "Call appdrm_generate_license_request return error[" << license_request << "]");
		return false;
	}

	if(request == NULL)
	{
		LOG_FATAL(logger, "request is NULL!");
		return false;
	}

	char requestTemp[requestlen + 1];
	memset(requestTemp, 0, sizeof(char)*(requestlen+1));
	strncpy(requestTemp, request, requestlen);
	free(request);
	appLicense = requestTemp;

	return true;    

}

/** 
* @fn    					bool InstallAppsLicense(const string& strLicenseFile, vector<PanelInfo>::iterator& it)                
* @brief          
* @exception			N/A
*/
bool InstallAppsLicense(const string strLicenseFile, vector<PanelInfo>::iterator it)
{
/*	if (it->getAppLicense().empty() || strLicenseFile.empty())
	{
		LOG_FATAL(logger, "Input License[" << it->getAppLicense().c_str() << "] strLicenseFile[" << strLicenseFile.c_str() << "]");
		return false;
	}

	if (0 == it->getAppLicense().length())
	{
		LOG_FATAL(logger, "strLicense.length is 0");
		return false;
	}

	void *pVoid = (void *)1 ;
	int iRet = appdrm_install_license(strLicenseFile.c_str(), it->getAppLicense().c_str(), it->getAppLicense().length(), pVoid);

	if (0 != iRet)
	{
		LOG_FATAL(logger, "Call appdrm_install_license return error[" << iRet << "]");
		return false;
	}
*/
	return false;
}



bool DrmHandler::loadLicense()
{
	if (m_isLicenseLoaded)
	{
		return true;
	}

	if (0 != appdrm_load_license(m_licensePath, &m_licenseHandler)) 
	{
		LOG_FATAL(logger, "Drm license load error! Path:" << m_licensePath);
		return false;
	}
	
	m_isLicenseLoaded = true;
	return true;
}

/** 
* @fn    					bool DrmHandler::decryptFile(const char* path, std::string &file)                
* @brief          
* @exception			N/A
*/
bool DrmHandler::decryptFile(const char* path, std::string &file)
{

	int decryptedFileLength;
//	unsigned char* decryptedFile;
	
	if (!m_isLicenseLoaded)
	{	
		LOG_FATAL(logger, "License not loaded!");
		return false;
	}

	LOG_DEBUG(logger, "Decrypting resource: " << path);

//	if (0 != appdrm_decrypt_spm(&m_licenseHandler, path, &decryptedFile, &decryptedFileLength)) 
//	{
//		LOG_FATAL(logger, "File " << path << "not decrypted!");
//		return false;
//	}
//	file = reinterpret_cast<char*>(decryptedFile);
//	LOG_DEBUG(logger, "File : " << decryptedFile);
//	free(decryptedFile);
//	printf("File : [%s], Length : [%d]\n", decryptedFile, decryptedFileLength);
	return false;

}
