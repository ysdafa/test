/** 
* @file	NetworkUtil.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "NetworkUtil.h"
#include "UpdateManagerLog.h"

static Logger logger("volt.updatemanager.networkutil");

/** 
* @fn    			  	NetworkUtil::NetworkUtil()           
* @brief          Constructor of NetworkUtil class.  
* @exception			N/A
*/
NetworkUtil::NetworkUtil()
{
	networkConnection = NULL;
	if(connection_create(&networkConnection) != 0)
	{
		LOG_FATAL(logger, "Connection_create is failed!");
	}

	return;
}

/** 
* @fn    			  	NetworkUtil::~NetworkUtil()         
* @brief          Destructure of NetworkUtil class.  
* @exception			N/A
*/
NetworkUtil::~NetworkUtil()
{
	connection_destroy(networkConnection);
}

/** 
* @fn    			  	connection_type_e NetworkUtil::getConnectionType(void)      
* @brief          Check Network.
* @exception			N/A
*/
connection_type_e NetworkUtil::getConnectionType() //check Network
{
	connection_type_e connection_type = CONNECTION_TYPE_DISCONNECTED;

	int rv = connection_get_type(networkConnection, &connection_type);

	if( CONNECTION_ERROR_NONE != rv )
	{
		LOG_FATAL(logger, "Get connection type error,rv = " << rv);
	}
	
	else
	{
		LOG_FATAL(logger, "connection type: " << connection_type);
	}
	
	return connection_type;
}

/** 
* @fn    			  	bool NetworkUtil::getMacAddress(std::string& mac) 
* @brief          Get the Mac Address
* @exception			N/A
*/
bool NetworkUtil::getMacAddress(std::string& mac) //Get the Mac Address
{
	char *mac_addr = NULL;
	connection_type_e connectionType = getConnectionType();

	if(CONNECTION_TYPE_DISCONNECTED == connectionType)
	{
		LOG_FATAL(logger, "Network is Disconnected!");
		return false;
	}

	int rv = connection_get_mac_address(networkConnection, connectionType, &mac_addr);

	if(CONNECTION_ERROR_NONE != rv)
	{
		LOG_FATAL(logger, "Fail to get mac_address!");
		return false;
	}

	if(mac_addr != NULL)
	{
		mac = mac_addr;
		free(mac_addr);
		mac_addr = NULL;
		return true;
	}

	else
	{
		LOG_FATAL(logger, "MAC_addr return NULL!");
		return false;
	}
}

