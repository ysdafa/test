/** 
* @file	UpdateManagerLog.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "UpdateManagerLog.h"
#include <sys/types.h>
#include <unistd.h>
#include <strings.h>

Logger::LogLevel Logger::level_ = Logger::kFatal;

/** 
* @fn    			  	Logger::Logger(const std::string &aName) : name_(aName)
* @brief          
* @exception			N/A
*/
Logger::Logger(const std::string &aName) : name_(aName)
{
}

/** 
* @fn    			  	Logger::~Logger()
* @brief          
* @exception			N/A
*/
Logger::~Logger()
{
}

/** 
* @fn    			  	void Logger::SetLogLevel(const LogLevel aLevel)
* @brief          
* @exception			N/A
*/
void Logger::SetLogLevel(const LogLevel aLevel)
{
	level_ = aLevel;
}

/** 
* @fn    			  	const char* Logger::LevelToString(const LogLevel aLevel)
* @brief          
* @exception			N/A
*/
const char* Logger::LevelToString(const LogLevel aLevel)
{
	switch(aLevel)
	{
		case kFatal: return "Fatal";
		case kMajor: return "Major";
		case kWarn: return "Warn";
		case kDebug: return "Debug";
		case kInfo: return "Info";
		default: return "???";
	}
}

/** 
* @fn    			  	Logger::LogLevel Logger::StringToLevel(const char *aLevelStr)
* @brief          
* @exception			N/A
*/
Logger::LogLevel Logger::StringToLevel(const char *aLevelStr)
{
	if (aLevelStr == NULL) return kFatal;
	else if(strcasecmp(aLevelStr, "major") == 0) return kMajor;
	else if(strcasecmp(aLevelStr, "warn") == 0) return kWarn;
	else if(strcasecmp(aLevelStr, "debug") == 0) return kDebug;
	else if(strcasecmp(aLevelStr, "info") == 0) return kInfo;
	else return kFatal;
}

/** 
* @fn							Log
* @brief					Log
*
* @param					N/A
* @return					N/A
* @warning				N/A
* @exception			N/A
* @see						N/A
*/
void Logger::Log(const char *aFile, const char *aFunc, const unsigned int aLine, const LogLevel aLevel, const char *aDlogTag, std::string aMsg) const
{
	time_t time_stamp = time(NULL);
	struct tm tm_buf;
	localtime_r(&time_stamp, &tm_buf);
	char date_buf[20];
	if (strftime(date_buf, 20, "%Y-%m-%dT%H:%M:%S", &tm_buf) == 0)
	{
		date_buf[0] = '\0';
	}

	const char *file_name = strrchr(aFile, '/') ? strrchr(aFile, '/') + 1 : aFile;

	static const char *fmt = "[Volt|Engine|%s|%lu|%lu|%s:%s:%d] %s\n";

	log_priority prio = DLOG_VERBOSE;

	switch (aLevel)
	{
		case kFatal:
			prio = DLOG_FATAL;
			break;
		case kMajor:
			prio = DLOG_ERROR;
			break;
		case kWarn:
			prio = DLOG_WARN;
			break;
		case kDebug:
			prio = DLOG_DEBUG;
			break;
		case kInfo:
			prio = DLOG_VERBOSE;
			break;
		default:
			break;
	}
	__dlog_print(LOG_ID_MAIN, prio, aDlogTag, fmt, date_buf, getpid(), pthread_self(), file_name, aFunc, aLine, aMsg.c_str());
}