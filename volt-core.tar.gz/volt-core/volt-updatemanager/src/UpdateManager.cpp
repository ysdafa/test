/** 
* @file	UpdateManager.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "UpdateManager.h"
#include "Define.h"
#include "NetworkIORequest.h"
#include "UpdateManagerUtil.h"
#include "AppDrm.h"
#include "XMLParse.h"
#include "UpdateManagerLog.h"

static Logger logger("volt.updatemanager.manager");

/** 
* @fn    			  	bool EmpInfo::changeFlag(void)
* @brief          If changed EMP version, change flag and save flag.txt
* @exception			N/A
*/
bool EmpInfo::changeFlag() //If changed EMP version, change flag and save flag.txt
{
	FILE *file;
	string path = string(EMP_PATH) + "/" + this->getEmpName()+ "_img/" + FLAG;
	
	if(this->getFlag()== "emp1") // emp1 -> emp2
	{
		if((file = fopen(path.c_str(), "w")) != NULL)
		{
			this->setFlag("emp2");
			fprintf(file, "%s", "2");
			fclose(file);
			return true;
		}
		else
		{
			LOG_FATAL(logger, "flag  file is not open!");
			return false;
		}
	}

	else if(this->getFlag() =="emp2") //emp2 -> emp1
	{
		if((file = fopen(path.c_str(), "w")) != NULL)
		{
			this->setFlag("emp1");
			fprintf(file, "%s", "1");
			fclose(file);
			return true;
		}
		else
		{
			LOG_FATAL(logger, "flag  file is not open!");
			return false;
		}
	}
	else
	{
		LOG_FATAL(logger, "Flag file is wrong!");
		return false;
	}	
}

/** 
* @fn    			  	bool PanelInfo::changeFlag(void) 
* @brief          If changed App Panel version, change flag and save flag.txt
* @exception			N/A
*/
bool PanelInfo::changeFlag() //If changed App Panel version, change flag and save flag.txt
{
	FILE *file;
	string path = string(PANEL_PATH) + "/" + this->getAppId()+ "_img/" + FLAG;
	
	if(this->getFlag()== "panel1") // panel1 -> panel2
	{
		if((file = fopen(path.c_str(), "w")) != NULL)
		{
			this->setFlag("panel2");
			fprintf(file, "%s", "2");
			fclose(file);
			return true;
		}
		else
		{
			LOG_FATAL(logger, "flag  file is not open!");
			return false;
		}
	}

	else if(this->getFlag() == "panel2") // panel2 -> panel1
	{
		if((file = fopen(path.c_str(), "w")) != NULL)
		{
			this->setFlag("panel1");
			fprintf(file, "%s", "1");
			fclose(file);
			return true;
		}
		else
		{
			LOG_FATAL(logger, "flag  file is not open!");
			return false;
		}
	}

	else
	{
		LOG_FATAL(logger, "Flag file is wrong!");
		return false;
	}
}
/** 
* @fn    			  	bool VoltPanelUpdateManager::setEmpInfo(void)
* @brief          Set up Pre-Install EMP Information
* @exception			N/A
*/
bool VoltPanelUpdateManager::setEmpInfo() // set up Pre-Install EMP Information
{
	string name;
	string path;
	string empVersion;
	string flagName;
	string mountPath;
	string versionPath;
	FILE* flagFile;


	name = "empVolt_img";
	path = string(EMP_PATH) + "/" + name + "/" + FLAG; 
	
	if ((flagFile = fopen(path.c_str(), "r")) != NULL)
	{
		char flagVersion[BUFFER_SIZE] = {0, };
		if(fgets(flagVersion, BUFFER_SIZE, flagFile) != NULL)
		{
			path = string(EMP_PATH) + "/" + name + "/" + string(EMP_FLAG) + string(flagVersion) + "/" + EMP_VERSION; // read /opt/down/emps/empname_img/emp1/version.txt
			flagName =  string(EMP_FLAG) + string(flagVersion); // flag name : emp1 or emp2
			int pos = name.rfind("_");
			if(pos!=-1)
			{
				name = name.substr(0, pos);
				versionPath = string(EMP_PATH) + "/" + name + "/" + flagName + "/" + EMP_VERSION;
				mountPath = this->getMountEmpPath(name, flagName);
				ExecShell(mountPath.c_str()); //Mount
				LOG_FATAL(logger, "EMP Mount Success!!!");
				
				if(parseEmpVersion(versionPath.c_str(), empVersion))
				{
					EmpInfo clinetInformation(empVersion, name, flagName);
					this->emp.push_back(clinetInformation);
					LOG_DEBUG(logger, "emp name = [" <<  name << "]");
					LOG_DEBUG(logger, "emp version = [" << empVersion << "]");
					fclose(flagFile);
					return true;
				}
				else
				{
					LOG_FATAL(logger, "version file is wrong!");
					fclose(flagFile);
					return false;
				}				
			}
		}
		else
		{
			fclose(flagFile);
			LOG_FATAL(logger, "flag version is not exist!");
			return false;
		}
	}
	else
	{
		LOG_FATAL(logger, "[" << name.c_str() << "] flagFile is not exist!" );
		return false;
	}
}

/** 
* @fn    			  	bool VoltPanelUpdateManager::setPanelInfo(void)
* @brief          Set up Pre-Install AppPanel Information
* @exception			N/A
*/
bool VoltPanelUpdateManager::setPanelInfo() // set up Pre-Install AppPanel Information
{
	struct dirent *panelFolderEntry = NULL;
	struct dirent prevPanelFolderEntry;
	DIR *panelFolder;
	string name;
	string path;
	string panelVersion;
	string flagName;
	FILE* flagFile;
	string licensePath;
	string decryptedFile;
	string image;
	string mountPath;
	string versionPath;
	
	panelFolder = opendir(PANEL_PATH); //Folder Open - /opt/down/panels/
/*	if (panelFolder)
	{
		while ((readdir_r(panelFolder, &prevPanelFolderEntry, &panelFolderEntry) == 0) && (panelFolderEntry != NULL))
		{
			name = string(panelFolderEntry->d_name);
			path = string(PANEL_PATH) + "/" + name + "/" + FLAG; // read /opt/down/panels/appname_img/flag.txt
			if ((flagFile = fopen(path.c_str(), "r")) != NULL)
			{
				char flagVersion[BUFFER_SIZE] = {0, };
				if(fgets(flagVersion, BUFFER_SIZE, flagFile) != NULL)
				{
					flagName =  string(PANEL_FLAG) + string(flagVersion); // flag name : panel1 or panel2
					path = string(PANEL_PATH) + "/" + name + "/" + flagName + "/" + APP_VERSION;  // read /opt/down/panels/appname_img/panel1/config.xml.spm
					licensePath = string(PANEL_PATH) + "/" + name + "/" + LICENSE_FILE;
					image = string(PANEL_PATH) + "/" + name + "/" + flagName + "/";
					int pos = name.rfind("_");
					if(pos != -1)
					{
						name = name.substr(0, pos); 
						image = image + name + ".img";
						versionPath = string(PANEL_PATH) + "/" + name + "/" + APP_VERSION;
						
						if(access(path.c_str(), F_OK) == 0) //Pre-Install
						{
							mountPath = this->getLinkPanelPath(name, flagName);
							ExecShell(mountPath.c_str());
							LOG_FATAL(logger, "Panel App Link Success!!!");
							DrmHandler drmhandle(licensePath.c_str());
							if(drmhandle.loadLicense())
							{
								if(drmhandle.decryptFile(versionPath.c_str(), decryptedFile))
								{
									if(parseAppVersion(decryptedFile.c_str(), panelVersion))
									{
										LOG_DEBUG(logger, "panel version is = [" << panelVersion.c_str() << "]" );
										PanelInfo clientInformation(panelVersion, name, flagName);
										this->panel.push_back(clientInformation);

									}
								}
							}
						}

						else if(access(image.c_str(), F_OK) == 0)
						{
							mountPath = this->getMountPanelPath(name, flagName);
							ExecShell(mountPath.c_str());
							LOG_FATAL(logger, "App Panel Mount Success!!!");								
							DrmHandler drmhandle(licensePath.c_str());
							if(drmhandle.loadLicense())
							{
								if(drmhandle.decryptFile(versionPath.c_str(), decryptedFile))
								{
									if(parseAppVersion(decryptedFile.c_str(), panelVersion))
									{
										LOG_DEBUG(logger, "panel version is = [" << panelVersion <<"]" );
										PanelInfo clientInformation(panelVersion, name, flagName);
										this->panel.push_back(clientInformation);
									}
								}
							}							
							
						}
					}				

					fclose(flagFile);					
				}
				else
				{
					fclose(flagFile);
					LOG_FATAL(logger, "flag version is not exist!");
				}
			}
			else
			{
				LOG_FATAL(logger, "[" << name.c_str() << "] flagFile is not exist!" );
			}
		}
		closedir(panelFolder);
	}
	else
	{
		LOG_FATAL(logger, "panelFolder is not exist!!");
		return false;
	}
*/
	closedir(panelFolder);
	return true;
}

/** 
* @fn    			  	string VoltPanelUpdateManager::getMountEmpPath(string empName, string empFlag) 
* @brief          Set up Pre-Install AppPanel Information
* @exception			N/A
*/
string VoltPanelUpdateManager::getMountEmpPath(string empName, string empFlag)         //vector<EmpInfo>::iterator it) //EMP Mount command 
{

	DIR *empFolder;
	string emppath = "/opt/down/emps/" + empName;
	empFolder = opendir(emppath.c_str());
	if(empFolder == NULL)
	{
		string makecommand = "mkdir -p " + string(EMP_PATH) + "/" + empName;
		ExecShell(makecommand.c_str());
		ExecShell("sync");
	}
	else
	{
		closedir(empFolder);
	}	
	return "mount -t squashfs -r " + string(EMP_PATH) + "/"  + empName + "_img/" + empFlag +  "/" + empName + ".img" + " /opt/down/emps/" + empName;
}

// mount -t squashfs -r  --mount /opt/down/emps/empname_img/emp1 /opt/down/emps/empname
/** 
* @fn    			  	string VoltPanelUpdateManager::getMountPanelPath(string appId, string appFlag)
* @brief          
* @exception			N/A
*/
string VoltPanelUpdateManager::getMountPanelPath(string appId, string appFlag) //vector<PanelInfo>::iterator it) // Panel App Moint command
{
	DIR *panelFolder;
	string panelpath = "/opt/down/panels/" +appId;
	panelFolder = opendir(panelpath.c_str());
	if(panelFolder == NULL)
	{
		string makecommand = "mkdir -p " + string(PANEL_PATH) + "/" + appId;
		ExecShell(makecommand.c_str());
		ExecShell("sync");
	}
	else
	{
		closedir(panelFolder);
	}
	
	return "mount -t squashfs -r " + string(PANEL_PATH) + "/"  +  appId + "_img/" + appFlag + "/" + appId + ".img"  " /opt/down/panels/" + appId;
}
// mount -t squashfs -r  --mount /opt/down/panels/appname_img/panel1 /opt/down/emps/appname

/** 
* @fn    			  	string VoltPanelUpdateManager::getLinkPanelPath(string appId, string appFlag)
* @brief          
* @exception			N/A
*/
string VoltPanelUpdateManager::getLinkPanelPath(string appId, string appFlag)
{
	DIR *panelFolder;
	string panelpath = "/opt/down/panels/" +appId;
	panelFolder = opendir(panelpath.c_str());
	if(panelFolder != NULL)
	{
		string deletecommand = "rmdir -rf " + string(PANEL_PATH) + "/" + appId;
		ExecShell(deletecommand.c_str());
		ExecShell("sync");
	}
	closedir(panelFolder);
	
	return "ln -s " +  string(PANEL_PATH) + "/"  +  appId + "_img/" + appFlag + " /opt/down/panels/" + appId;
}
/** 
* @fn    			  	void VoltPanelUpdateManager::compareEmpVersion(void)
* @brief          Update EMP
* @exception			N/A
*/
void VoltPanelUpdateManager::compareEmpVersion() // Update EMP
{
	for(vector<EmpInfo>::iterator it = this->emp.begin(); it != this->emp.end(); it++)
	{
		if(requestEMPInstall(it))
		{
			LOG_FATAL(logger, "EMP Update Success!");
		}

		else
		{
			LOG_FATAL(logger, "EMP Update Fail!");
		}
	}
}

/** 
* @fn    			  	void VoltPanelUpdateManager::comparePanelVersion(void)
* @brief          Update App Panel
* @exception			N/A
*/
void VoltPanelUpdateManager::comparePanelVersion() //Update App Panel
{
	for(vector<PanelInfo>::iterator it = this->panel.begin(); it != this->panel.end(); it++)
	{
		if(requestAppInstall(it))
		{
			LOG_FATAL(logger, "Panel Update Success!");
		}
		else
		{
			LOG_FATAL(logger, "Panel Update Fail!");
		}
	}
}


