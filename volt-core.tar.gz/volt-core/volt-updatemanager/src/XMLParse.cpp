/** 
* @file	XMLParse.cpp
* @brief
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/

#include "XMLParse.h"
//#include "pugiconfig.h"
//#include "pugixml.h"
#include "UpdateManagerLog.h"

static Logger logger("volt.updatemanager.xmlparse");

/** 
* @fn    			 bool XMLParse::parseEMPServerURL(const char* xmldata, std::string &url)
* @brief       
* @exception	 N/A	
*/
bool parseEMPServerURL(const char* xmldata, std::string &url)
{
/*	pugi::xml_document doc;
	if (!doc.load(xmldata))
	{
		LOG_FATAL(logger, "doc.load strXml.c_str() error!");
		return false;
	}

	pugi::xml_node root = doc.child("rsp");

	if (std::string(root.attribute("stat").value()) != "ok")
	{
		LOG_FATAL(logger, "XML info stat is not ok!");
		return false;
	}	

	pugi::xml_node notice = root.child("rm").child("queryinfo").child("notice");	

	pugi::xml_node noticelist = notice.first_child();

	url = noticelist.attribute("url").value();*/

	return false;
}

/** 
* @fn    			 bool XMLParse::parseEMPInstallURL(const char* xmldata, std::string &url, vector<EmpInfo>::iterator& it)
* @brief       
* @exception	 N/A	
*/
bool parseEMPInstallURL(const char* xmldata, std::string &url, vector<EmpInfo>::iterator it)
{
/*	pugi::xml_document doc;
	if (!doc.load(xmldata))
	{
		LOG_FATAL(logger, "doc.load strXml.c_str() error!");
		return false;
	}

	pugi::xml_node emplist = doc.child("emplist");

	for (pugi::xml_node file = emplist.child("file"); file; file = file.next_sibling("file"))
	{
		if(std::string(file.attribute("id").value()) == "empVolt")
		{
			if(std::string(file.attribute("version").value()) != it->getClientVersion())
			{
				LOG_DEBUG(logger, "parse url =[" << file.attribute("url").value() << "]");
				it->setClientVersion(std::string(file.attribute("version").value()));
				url = file.attribute("url").value();
				return true;
			}

			else
			{
				LOG_FATAL(logger, "EMP Version is not change!");
				return false;
			}	
		}
	}
*/
	return false;
		
}

/** 
* @fn    			 bool XMLParse::parseAppInstallURL(const char* xmldata, std::string &url, vector<PanelInfo>::iterator& it)
* @brief       
* @exception	 N/A	
*/
bool parseAppInstallURL(const char* xmldata, std::string &url, vector<PanelInfo>::iterator it)
{
/*	pugi::xml_document doc;

	if (!doc.load(xmldata))
	{
		LOG_FATAL(logger, "doc.load xmldata.c_str() error!");
		return false;
	}
	pugi::xml_node root = doc.child("rsp");
	if (std::string(root.attribute("stat").value()) != "ok")
	{
		LOG_FATAL(logger, "XML info stat is not ok!");
		return false;
	}
	
	pugi::xml_node list = root.child("list");
	pugi::xml_node widget = list.child("widget");

	LOG_DEBUG(logger, "server version is = [" << widget.child_value("version") << "]");
	LOG_DEBUG(logger, "client version is = [" << it->getClientVersion().c_str() << "]");
	if(std::string(widget.child_value("version")) == it->getClientVersion())
	{
		LOG_FATAL(logger, "version is same!");
		return false;
	}

	else
	{
		it->setClientVersion(std::string(widget.child_value("version")));
		pugi::xml_node file = widget.child("file");
		url = file.child_value("url");
		it->setAppLicense(std::string(file.child_value("license")));
		return true;
	}*/
	return false;
}

/** 
* @fn    			 bool XMLParse::parseAppVersion(const char* xmldata, std::string &version)
* @brief       
* @exception	 N/A	
*/
bool parseAppVersion(const char* xmldata, std::string &version)
{
/*	pugi::xml_document doc;
	if (!doc.load(xmldata))
	{
		LOG_FATAL(logger, "doc.load strXml.c_str() error!");
		return false;
	}

	pugi::xml_node widget = doc.child("widget");
	version = std::string(widget.child_value("ver"));
	*/
	return false;
}

/** 
* @fn    			 bool XMLParse::parseEmpVersion(const char* xmldata, std::string &version)
* @brief       
* @exception	 N/A	
*/
bool parseEmpVersion(const char* xmldata, std::string &version)
{
/*	pugi::xml_document doc;
	if (!doc.load_file(xmldata))
	{
		LOG_FATAL(logger, "doc.load strXml.c_str() error!");
		return false;
	}

	pugi::xml_node emp = doc.child("Emp");
	version = std::string(emp.child_value("Version"));
	*/
	return false;
}