/** 
 * @file	NetworkIORequest.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */


#ifndef _NETWORKIOREQUEST_H_
#define _NETWORKIOREQUEST_H_

#include "UpdateManager.h"
#include "UpdateManagerUtil.h"
//#include "was-token-api.h"
#include <stdio.h>
#include <string>
#include <curl/curl.h>
#include <vconf.h>
#include <vconf-keys.h>


		/** 
		* @fn    			 size_t send_query_receiver(void*, size_t, size_t, void*) 	             
		* @brief          
		* @exception	 N/A	
		*/
size_t send_query_receiver(void* buf, size_t size, size_t nmemb, void* userp);
		/** 
		* @fn    			 size_t writeData(void*, const size_t, const size_t, FILE*)            
		* @brief          
		* @exception	 N/A	
		*/
size_t writeData(void* ptr, const size_t size, const size_t nmemb, FILE* stream);
		/** 
		* @fn    			 string setXMLBody(const string)          
		* @brief          
		* @exception	 N/A	
		*/
string setXMLBody(const string appid);
		/** 
		* @fn    			 curl_slist* setEMPInfoHeader(void)     
		* @brief          
		* @exception	 N/A	
		*/
curl_slist* setEMPInfoHeader();
		/** 
		* @fn    			 bool requestServerEMPInfo(string, string&, vector<EmpInfo>::iterator);       
		* @brief          
		* @exception	 N/A	
		*/
bool requestServerEMPInfo(string url, string &result, vector<EmpInfo>::iterator it);
		/** 
		* @fn    			 bool downloadEMP(string, vector<EmpInfo>::iterator)       
		* @brief          
		* @exception	 N/A	
		*/
bool downloadEMP(string url, vector<EmpInfo>::iterator it);
		/** 
		* @fn    			 curl_slist* setAppInstallHeader(void)        
		* @brief          
		* @exception	 N/A	
		*/
curl_slist* setAppInstallHeader();
		/** 
		* @fn    			 bool downloadApp(string, vector<PanelInfo>::iterator)         
		* @brief          
		* @exception	 N/A	
		*/
bool downloadApp(string url, vector<PanelInfo>::iterator it);
		/** 
		* @fn    			 bool requestAppInstall(vector<PanelInfo>::iterator)     
		* @brief          
		* @exception	 N/A	
		*/
bool requestAppInstall(vector<PanelInfo>::iterator it);
		/** 
		* @fn    			 bool requestEMPInstall(vector<EmpInfo>::iterator)      
		* @brief          
		* @exception	 N/A	
		*/
bool requestEMPInstall(vector<EmpInfo>::iterator it);

#endif /* _NETWORKIOREQUEST_H_ */