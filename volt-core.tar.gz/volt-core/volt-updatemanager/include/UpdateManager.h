/** 
 * @file	UpdateManager.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
 
#ifndef _UPDATEMANAGER_H_
#define _UPDATEMANAGER_H_
#include <vector>
#include <string>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
using namespace std;

/**
 * @class	EmpInfo
 * @brief	
 */
class EmpInfo
{
private :
	string clientVersion;
	string empName;
	string flag;
	string serverVersion;
public :
	/** 
	* @fn    			  	EmpInfo(string, string, string)              
	* @brief          Constructor of EmpInfo class.
	* @exception			N/A
	*/
	EmpInfo(string client, string emp, string flag) : clientVersion(client), empName(emp), flag(flag) { };
	
	/** 
	* @fn    			  	string getClientVersion(void)               
	* @brief          
	* @exception			N/A
	*/
	string getClientVersion() { return clientVersion; };
	
	/** 
	* @fn    			  	string getEmpName(void)                
	* @brief          
	* @exception			N/A
	*/
	string getEmpName() { return empName; };
	
	/** 
	* @fn    			  	string getFlag(void)                
	* @brief          
	* @exception			N/A
	*/
	string getFlag() { return flag; };
	
	/** 
	* @fn    			  	void setClientVersion(string)                
	* @brief          
	* @exception			N/A
	*/
	void setClientVersion(string updateVersion) { clientVersion = updateVersion; };
	
	/** 
	* @fn    			  	void setFlag(string)               
	* @brief          
	* @exception			N/A
	*/
	void setFlag(string changeFlag) { flag = changeFlag; };
	
	/** 
	* @fn    			  	bool changeFlag(void)                
	* @brief          
	* @exception			N/A
	*/
	bool changeFlag();
//	bool changeVersion();		
};

/**
 * @class	PanelInfo
 * @brief	
 */
class PanelInfo
{
private :
	string clientVersion;
	string appId;
	string flag;
	string serverVersion;
	string license;
public :
	/** 
	* @fn    			  	PanelInfo(string, string, string)           
	* @brief          Constructor of PanelInfo class.
	* @exception			N/A
	*/
	PanelInfo(string client, string app, string flag) : clientVersion(client), appId(app), flag(flag) { };
	/** 
	* @fn    			  	string getClientVersion(void)           
	* @brief          
	* @exception			N/A
	*/
	string getClientVersion() { return clientVersion; };
	/** 
	* @fn    			  	string getAppId(void)          
	* @brief          
	* @exception			N/A
	*/
	string getAppId() { return appId; };
	/** 
	* @fn    			  	string getFlag(void)           
	* @brief          
	* @exception			N/A
	*/
	string getFlag() { return flag; };
	/** 
	* @fn    			  	void setClientVersion(string)           
	* @brief          
	* @exception			N/A
	*/
	void setClientVersion(string updateVersion) { clientVersion = updateVersion; };
	/** 
	* @fn    			  	void setFlag(string)           
	* @brief          
	* @exception			N/A
	*/
	void setFlag(string changeFlag) { flag = changeFlag; };
	/** 
	* @fn    			  	bool changeFlag(void)           
	* @brief          
	* @exception			N/A
	*/
	bool changeFlag();
//	bool changeVersion();
	/** 
	* @fn    			  	void setAppLicense(string)           
	* @brief          
	* @exception			N/A
	*/
	void setAppLicense(string updateLicense) { license = updateLicense;};
	/** 
	* @fn    			  	string getAppLicense(void)           
	* @brief          
	* @exception			N/A
	*/
	string getAppLicense() { return license;};
};

/**
 * @class	VoltPanelUpdateManager
 * @brief	
 */
class VoltPanelUpdateManager
{
private :
	vector<EmpInfo> emp;
	vector<PanelInfo> panel;
	bool empFlag;
public :
	/** 
	* @fn    			  	VoltPanelUpdateManager()           
	* @brief          Constructor of VoltPanelUpdateManager class.
	* @exception			N/A
	*/
	VoltPanelUpdateManager() : empFlag(false) {};
	/** 
	* @fn    			  	vector<EmpInfo>& getEmpVector(void)           
	* @brief          
	* @exception			N/A
	*/
	vector<EmpInfo>& getEmpVector() { return emp; };
	/** 
	* @fn    			  	vector<PanelInfo>& getPanelVector(void)           
	* @brief          
	* @exception			N/A
	*/
	vector<PanelInfo>& getPanelVector() { return panel; };
	/** 
	* @fn    			  	bool setEmpInfo(void)           
	* @brief          
	* @exception			N/A
	*/
	bool setEmpInfo();
	/** 
	* @fn    			  	bool setPanelInfo(void)           
	* @brief          
	* @exception			N/A
	*/
	bool setPanelInfo();
	/** 
	* @fn    			  	void compareEmpVersion(void)           
	* @brief          
	* @exception			N/A
	*/
	void compareEmpVersion();
	/** 
	* @fn    			  	void comparePanelVersion(void)           
	* @brief          
	* @exception			N/A
	*/
	void comparePanelVersion();
//	string getEmpPath(vector<EmpInfo>::iterator it);
  /** 
	* @fn    			  	string getMountEmpPath(string, string)           
	* @brief          
	* @exception			N/A
	*/
	string getMountEmpPath(string empName, string empFlag);
	/** 
	* @fn    			  	string getMountPanelPath(string, string)           
	* @brief          
	* @exception			N/A
	*/
	string getMountPanelPath(string appId, string appFlag);
//	string getPanelPath(vector<PanelInfo>::iterator it);
	/** 
	* @fn    			  	void setEmpFlag(bool)           
	* @brief          
	* @exception			N/A
	*/
	void setEmpFlag(bool flag) { empFlag = flag; };
	/** 
	* @fn    			  	bool getEmpFlag(void)           
	* @brief          
	* @exception			N/A
	*/
	bool getEmpFlag() { return empFlag; };
	/** 
	* @fn    			  	string getLinkPanelPath(string, string)           
	* @brief          
	* @exception			N/A
	*/
	string getLinkPanelPath(string appId, string appFlag);


};

#endif /* _UPDATEMANAGER_H_ */