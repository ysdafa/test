/** 
 * @file	NetworkUtil.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef _NETWORKUTIL_H_
#define _NETWORKUTIL_H_
#include <network/net_connection.h>
#include <stdio.h>
#include <string>
#include <stdlib.h>

/**
 * @class	NetworkUtil
 * @brief	
 */
class NetworkUtil
{
private :
	connection_h networkConnection;
	
public :
	/** 
	* @fn   			NetworkUtil() 			  	             
	* @brief      Constructor of NetworkUtil class.  
	* @exception	N/A	
	*/
	
	NetworkUtil();
	/** 
	* @fn   			~NetworkUtil() 			  	             
	* @brief      Destructure of NetworkUtil class.  
	* @exception	N/A	
	*/
	~NetworkUtil();
	/** 
	* @fn    			connection_type_e getConnectionType(void)  	             
	* @brief     
	* @exception			
	*/
	connection_type_e getConnectionType();
	/** 
	* @fn    			bool getMacAddress(std::string&)		  	             
	* @brief     
	* @exception			
	*/
	bool getMacAddress(std::string& mac);
};

#endif /* _NETWORKUTIL_H_ */