/** 
 * @file	SystemInfoUtil.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef _SYSTEMINFOUTIL_H_
#define _SYSTEMINFOUTIL_H_

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <runtime_info.h>
#include <system_info_key.h>
#include <system_info_type.h>
#include <system_info.h>

/** 
* @fn    			  	bool getResolution(std::string&)           
* @brief          
* @exception			N/A
*/
bool getResolution(std::string &resolution);
	
/** 
* @fn    			  	bool getLanguage(std::string&)               
* @brief          
* @exception			N/A
*/
bool getLanguage(std::string &language);


#endif /* _SYSTEMINFOUTIL_H_ */