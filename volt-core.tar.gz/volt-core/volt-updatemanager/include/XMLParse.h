/** 
 * @file	XMLParse.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
 
#ifndef _XMLPARSE_H_
#define _XMLPARSE_H_

#include "UpdateManager.h"
#include <stdio.h>
#include <string>

		/** 
		* @fn    			  	bool parseEMPServerURL(const char*, string);                  
		* @brief          
		* @exception			N/A
		*/
bool parseEMPServerURL(const char* xmldata, std::string &url);
			
		/** 
		* @fn    			  	bool parseEMPInstallURL(const char*, string, vector<EmpInfo>::iterator)            
		* @brief          
		* @exception			N/A
		*/
bool parseEMPInstallURL(const char* xmldata, std::string &url, vector<EmpInfo>::iterator it);
			
		/** 
		* @fn    			  	bool parseAppInstallURL(const char*, string, vector<PanelInfo>::iterator)                  
		* @brief          
		* @exception			N/A
		*/
bool parseAppInstallURL(const char* xmldata, std::string &url, vector<PanelInfo>::iterator it);
				
		/** 
		* @fn    			  	bool parseAppVersion(const char*, string)                  
		* @brief          
		* @exception			N/A
		*/
bool parseAppVersion(const char* xmldata, std::string &version);
				
		/** 
		* @fn    			  	bool parseEmpVersion(const char*, string)                  
		* @brief          
		* @exception			N/A
		*/
bool parseEmpVersion(const char* xmldata, std::string &version);

#endif /* _XMLPARSE_H_ */