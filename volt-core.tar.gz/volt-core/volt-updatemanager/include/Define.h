/**
 * @file	Define.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef _DEFINE_H_
#define _DEFINE_H_

#define BUFFER_SIZE 256
#define APPS_LICENSE_NAME "widget.license"

#define EMP_PATH "/opt/down/emps"
#define PANEL_PATH "/opt/down/panels"
#define EMP_VERSION "empVolt.xml"
#define APP_VERSION "config.xml.spm"

#define FLAG "flag.txt"
#define LICENSE_FILE "widget.license"
#define EMP_FLAG "emp"
#define PANEL_FLAG "panel"

#define CACHE_CONTROL "Cache-Control: no-cache"
#define REQUEST_DUID "DUID: "
#define REQUEST_COUNTRYCODE "CountryCode: "
#define REQUEST_MODELID "ModelId: "
#define REQUEST_FIRMCODE "FirmCode: "
#define REQUEST_CLIENT "Client: "
#define REQUEST_SMARTHUB "+SmartHub/5.1"
#define APPS_APPKEY "AppKey: "

#define APPS_DOWN_URL "https://osbstg.samsungcloudsolution.com/openapi/apps/download/list?"
#define APPS_RESOLUTION "Resolution: 1080"
#define APPS_APPID_LIST "WidgetIDList: "
#define APPS_LANGUAGE "lang: "
#define APPS_VLEV "vlev: 0"
#define REQUEST_ATOKEN "AToken: "

#define EMP_DOWN_URL "https://test.samsungrm.net/openapi/device/auth/query"
//#define EMP_DOWN_URL "https://www.samsungrm.net/openapi/device/auth/query"
#define EMP_CATEGORY "Category: EMP"
#define EMP_PARAM "Param : GOLFP,5.000" // chip
#define EMP_MAC "MACAddr: "
#define HTTP_MAX_TIMEOUT 50L
#define APPS "launch_app org.volt.apps prelaunch 1"

#define LOG_TAG "VOLT"
#endif /* _DEFINE_H_ */
