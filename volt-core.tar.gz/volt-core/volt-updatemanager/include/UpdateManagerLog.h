/** 
 * @file	UpdateManagerLog.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
 
#ifndef _UPDATEMANAGERLOG_H_
#define _UPDATEMANAGERLOG_H_

#include <cstddef>
#include <string>
#include <sstream>
#include <dlog.h>

#include "Define.h"

#define LOG_TRACE(logger, msg) do { \
  LOG_WRITE((logger), Logger::kInfo, msg); \
} while(0)

#define LOG_DEBUG(logger, msg) do { \
  LOG_WRITE((logger), Logger::kDebug, msg); \
} while(0)

#define LOG_INFO(logger, msg) do { \
  LOG_WRITE((logger), Logger::kInfo, msg); \
} while(0)

#define LOG_WARN(logger, msg) do { \
  LOG_WRITE((logger), Logger::kWarn, msg); \
} while(0)

#define LOG_ERROR(logger, msg) do { \
  LOG_WRITE((logger), Logger::kMajor, msg); \
} while(0)

#define LOG_FATAL(logger, msg) do { \
  LOG_WRITE((logger), Logger::kFatal, msg); \
} while(0)

#define LOG_WRITE(logger, level, msg) do { \
  std::ostringstream os; \
  os << msg; \
  (logger).Log(__FILE__, __func__, __LINE__, (level), LOG_TAG, os.str()); \
} while(0)

/**
 * @class	Logger
 * @brief	
 */
class Logger
{
 public:
	enum LogLevel { kFatal, kMajor, kWarn, kDebug, kInfo };
	/** 
	* @fn    					Logger(string)                  
  * @brief          Constructor of Logger class.
  * @exception			N/A
  */
	Logger(const std::string &aName = "");
	/** 
	* @fn    					~Logger()                  
  * @brief          Destructor of Logger class.
  * @exception			N/A
  */
	virtual ~Logger();
//	static void Configure(const std::string &aConfigPath);
	/** 
	* @fn    					static void SetLogLevel(const LogLevel)                  
  * @brief          
  * @exception			N/A
  */
	static void SetLogLevel(const LogLevel aLevel);
	/** 
	* @fn    					static const char* LevelToString(const LogLevel)                  
  * @brief          
  * @exception			N/A
  */
	static const char* LevelToString(const LogLevel aLevel);
	/** 
	* @fn    				  static LogLevel StringToLevel(const char *)	                  
  * @brief          
  * @exception			N/A
  */
	static LogLevel StringToLevel(const char *aLevelStr);
	/** 
	* @fn    					void Log(const char*, const char*, const unsigned int, const LogLevel,const char*, string);                  
  * @brief          
  * @exception			N/A
  */
	void Log(const char *aFile, const char *aFunc, const unsigned int aLine, const LogLevel aLevel, const char *aDlogTag, std::string aMsg) const;

private :
	std::string name_;
	static LogLevel level_;
};
#endif /* _UPDATEMANAGERLOG_H_ */