/** 
 * @file	AppDrm.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef _APPDRM_H_
#define _APPDRM_H_

#include "UpdateManager.h"
#include <string>
#include <appdrm_api.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>

/**
 * @class	DrmHandler
 * @brief	
 */
class DrmHandler
{
private :
	int m_licenseHandler;
	bool m_isLicenseLoaded;
	const char* m_licensePath;
	
public :
	/** 
	* @fn    					DrmHandler(const char*)                          
  * @brief          Constructor of DrmHandler class.
  * @exception			N/A
  */
	explicit DrmHandler(const char* licensePath) :
		m_licenseHandler(0),
		m_isLicenseLoaded(false),
		m_licensePath(licensePath)
		{};
	/** 
	* @fn    					bool loadLicense(void)                    
  * @brief          
  * @exception			N/A
  */
	bool loadLicense();
	/** 
	* @fn    					bool decryptFile(const char*, std::string&)                         
  * @brief          
  * @exception			N/A
  */
	bool decryptFile(const char* path, std::string &file);
};

/** 
* @fn    			  	bool generateRequestLicense(string&, std::string&)                  
* @brief          
* @exception			N/A
*/
bool generateRequestLicense(const std::string appID, std::string &appLicense);
/** 
* @fn    					bool InstallAppsLicense(const string&, vector<PanelInfo>::iterator&)                         
* @brief          
* @exception			N/A
*/
bool InstallAppsLicense(const string strLicenseFile, vector<PanelInfo>::iterator it);

#endif /* _APPDRM_H_ */
