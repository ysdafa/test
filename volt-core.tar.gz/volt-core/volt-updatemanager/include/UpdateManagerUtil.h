/** 
 * @file	UpdateManagerUtil.h
 * @brief
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef _UPDATEMANAGERUTIL_H_
#define _UPDATEMANAGERUTIL_H_

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string>
#include <time.h>
#include <stdio.h>

	/** 
	* @fn    			    int ExecShell(const char*)	           
	* @brief          
	* @exception			N/A
	*/
int ExecShell(const char* command);
	/** 
	* @fn    			  	void Snprintf(char*, int, const char*, ...)           
	* @brief          
	* @exception			N/A
	*/
void Snprintf(char* str, int size, const char* format, ...);
/** 
* @fn    			  	std::string LLongToString(const long long)           
* @brief          
* @exception			N/A
*/
std::string LLongToString(const long long num);
time_t requestTime();
std::string IntegerToString(const int num);

#endif /* _UPDATEMANAGERUTIL_H_ */