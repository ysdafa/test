
var text = new TextWidget({
    parent: scene,
    x: 0,
    y: 100,
    textColor: {r: 255, g: 255, b: 255, a: 255},
    text: "[BEGIN] Samsung Electronics Poland, Poznan Office [END]"
});

var animate = function (direction) {
    text.animate("x", (direction === 1 ? 800 : 0), 2000);
    
    text.animate("scale.x", (direction === 1 ? 2 : 1), 2000);
    text.animate("scale.y", (direction === 1 ? 2 : 1), 2000, function () {
        animate(direction * -1);
    });
};

animate(1);