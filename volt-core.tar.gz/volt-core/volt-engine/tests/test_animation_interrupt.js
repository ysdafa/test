var display = new TextWidget({
    width: 300,
    height: 720,
    parent:scene,
    anchor:0.5,
    origin:{x:0.8, y:0.4}
});

log("Callbacks will be noted here. No callbacks should be invoked due to interruption");

function log(string) {
    display.text = string + "\n" + display.text;
}

function clear() {
    display.text = "";
}

var widget = new Widget({
    width: 400,
    height: 400,
    parent: scene
});

function simpleInterrupt() {
    widget.animate("x", 200, 1000, function(){ log("interrupted callback hit!"); });
    Volt.setTimeout(function(){
        widget.animate("x", 700, 1000);
    }, 500);
}

var animHandle;
function compoundInterrupt() {
    var anim = new Animation(1000);
    anim.addProperty("x", 200);
    anim.addProperty("y", 200);
    animHandle = widget.animate(anim, function(){ log("interrupted callback hit!");} )

    Volt.setTimeout(function(){
        widget.animate("x", 700, 1000);
    }, 500);
}

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event){
	if (event.type == Volt.EVENT_KEY_RELEASE) return;
    compoundInterrupt();
});