var service;

var initialize = function() 
{
    Volt.addEventListener(Volt.KEY_JOYSTICK_UP, keyHandler);
}

function keyHandler(data) 
{
	if (data.type != Volt.EVENT_KEY_PRESS)  return;

	switch (data.keycode) 
	{
	case Volt.KEY_JOYSTICK_OK:
		break;
	
	case Volt.KEY_JOYSTICK_UP:
		service = new Service();
		service.appId = "org.tizen.alert-syspopup";
		service.operation = Service.OPERATION_DEFAULT;
		service.addExtraData("type", "panel-lock");
		service.launch();
		
		break;
		
	case Volt.KEY_JOYSTICK_DOWN:
		service = new Service();
		service.appId = "org.tizen.browser";
		service.operation = Service.OPERATION_DEFAULT;
		service.addExtraData("type", "panel-lock");
		service.launch();
		break;
	
	case Volt.KEY_JOYSTICK_LEFT:
		break;
		
    default:
        print("Unhandled event: " + event);
        break;
	}
}

