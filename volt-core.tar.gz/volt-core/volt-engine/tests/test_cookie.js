var initialize = function()
{
  /* Google sends some cookies back.  Look at the debug log to verify Volt is
   * using the correct cookies for subsequent requests. */
  /*
  var sync = new ResourceRequest({ uri: "http://google.com", async: false });
  sync.process();

  var async = new ResourceRequest({ uri: "http://google.com",
                                    callback: function(result)
                                    {
                                      print("Handling async event in custom callback");
                                      Volt.setTimeout(Volt.exit, 1000);
                                    }
                                  });
  async.process();
  */

  /* Log-in to hackthissite.org. */
  var username = "volt123";
  var password = "Volt123!";

  var url = "http://www.hackthissite.org/user/login";
  var req1 = new ResourceRequest({ uri: url, async: false });
  req1.success = function(data)
  {
    print("Received: " + data);
  };
  req1.process();

  var req2 = new ResourceRequest({ uri: url, async: false });
  req2.method = "post";
  req2.data = "username=" + username + "&password=" + password;
  req2.addHeader("Referer", url);
  req2.success = function(data)
  {
    print("Received: " + data);

    var success_msg = "Hello, <a href=\"/user/view/volt123/\">volt123</a>";
    if (data.indexOf(success_msg) >= 0)
    {
      print("Successfully logged in");
    }
    else
    {
      print("Failed to logged in");

      var error_msg = "Logging in on this account requires use of a CAPTCHA.";
      if (data.indexOf(error_msg) >= 0)
      {
        print("Try again after logging in on a browser and enter image CAPTCHA");
      }
    }
  };
  req2.complete = function()
  {
    Volt.exit();
  };
  req2.process();
};
