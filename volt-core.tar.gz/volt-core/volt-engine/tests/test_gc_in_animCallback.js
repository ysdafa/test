if(typeof gc === "undefined")
{
    throw "This app must be run with --enable-gc=true option."
}

var widget = new Widget();
widget.animate("x", 100, 500, function(){
    gc();
    new TextWidget({
        text: "Test passed",
        font: "35px",
        parent: scene,
        anchor: 0.5,
        origin: 0.5
    });
});

