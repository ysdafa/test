var mainContainer;
var statusText;

var numReq = 50;
var numReqCompleted = 0;
var bytesDownloaded = 0;
var loadStartTime;

function OnAsyncEvent(result) {
  print("Handling async event");

  statusText.text = "Async download complete\n" +
    "ID: " + result.id + "\n" +
    "Source: " + result.source + "\n" +
    "URL: " + result.uri + "\n" +
    "ContentType: " + result.type + "\n" +
    "Status: " + result.status + "\n" +
    "Response Type: " + result.response_type + "\n";

  statusText.text += "Headers: \n";
  for (var propt in result.headers)
  {
    statusText.text += propt + ': ' + result.headers[propt] + "\n";
  }

  if (result.response_type == "arraybuffer")
  {
    var array = new Uint8Array(result.data);
    statusText.text += "Size: " + array.length + "\n" +
                       "Data: " + String.fromCharCode.apply(null, array);
  }
  else
  {
    statusText.text += "Size: " + result.data.length + "\n" +
                       "Data: " + result.data;
  }
}

var onLoadAsyncEvent = function(result)
{
  ++numReqCompleted;

  if (result.response_type == "arraybuffer")
  {
    var array = new Uint8Array(result.data);
    bytesDownloaded += array.length;
  }
  else
  {
    bytesDownloaded += result.data.length;
  }

  if (numReqCompleted == numReq)
  {
    var elapsed = (new Date()) - loadStartTime;
    statusText.text = numReqCompleted + " requests (" + bytesDownloaded + " bytes) completed in " + elapsed + " msec";
    print(statusText.text);
  }
};

var startLoad = function()
{
  statusText.text = "Sending " + numReq + " requests";

  numReqCompleted = 0;
  bytesDownloaded = 0;
  loadStartTime = new Date();

  for (var loop = 0; loop < numReq; ++loop)
  {
    var req = new ResourceRequest("http://105.64.202.159/volt/test.jpg");
    //var req = new ResourceRequest("http://192.168.1.112/yusuke/volt/test.jpg");
    req.callback = onLoadAsyncEvent;
    req.response_type = "arraybuffer";
    if (req.process() === false)
    {
      statusText.text = "Failed to send async";
      ++numReqCompleted;
    }
  }
};

function onKeyEvent(keycode) {
  var req;
  switch (keycode) {
    case Volt.KEY_JOYSTICK_OK:
      statusText.text = "Downloading synchronously";
      req = new ResourceRequest({
        uri: "https://www.google.com",
        async: false,
        response_type: "arraybuffer"
      });
      var result = req.process();
      if (result) {
        statusText.text = "Sync download complete\n" +
          "Source: " + result.source + "\n" +
          "ID: " + result.id + "\n" +
          "URL: " + result.uri + "\n" +
          "ContentType: " + result.type + "\n" +
          "Status: " + result.status + "\n" +
          "Response Type: " + result.response_type + "\n";

        if (result.response_type == "arraybuffer")
        {
          var array = new Uint8Array(result.data);
          statusText.text += "Size: " + array.length + "\n" +
                             "Data: " + String.fromCharCode.apply(null, array);
        }
        else
        {
          statusText.text += "Size: " + result.data.length + "\n" +
                             "Data: " + result.data;
        }
      } else {
        statusText.text = "Download failed\n";
      }
      break;

    case Volt.KEY_JOYSTICK_UP:
      statusText.text = "Downloading asynchronously";
      var req1 = new ResourceRequest("http://www.google.com");
      req1.callback = OnAsyncEvent;
      req1.response_type = "arraybuffer";
      if (req1.process() === false) statusText.text = "Failed to send async";
      var req2 = new ResourceRequest("http://www.yahoo.com");
      if (req2.process() === false) statusText.text = "Failed to send async";

      var req3 = new ResourceRequest({
        uri: "http://www.bing.com",
        callback: function(result) {
          print("Handling async event in custom callback");
          statusText.text = "Async download complete\n" +
            "Source: " + result.source + "\n" +
            "ID: " + result.id + "\n" +
            "URL: " + result.uri + "\n" +
            "ContentType: " + result.type + "\n" +
            "Status: " + result.status + "\n" +
            "Response Type: " + result.response_type + "\n";

          if (result.response_type == "arraybuffer")
          {
            var array = new Uint8Array(result.data);
            statusText.text += "Size: " + array.length + "\n" +
            "Data: " + String.fromCharCode.apply(null, array);
          }
          else
          {
            statusText.text += "Size: " + result.data.length + "\n" +
            "Data: " + result.data;
          }
        }
      });
      if (req3.process() === false) statusText.text = "Failed to send async";

      break;

    case Volt.KEY_JOYSTICK_DOWN:
      statusText.text = "Getting local file";
      req = new ResourceRequest("file://test_network.js");
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to get local file";
      break;

    case Volt.KEY_JOYSTICK_LEFT:
      statusText.text = "Downloading asynchronously\n" +
        "Invalid URL 2";
      req = new ResourceRequest("http://this.does.not/get/you/anything");
      req.callback = OnAsyncEvent;
      if (req.process() === null) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_JOYSTICK_RIGHT:
      statusText.text = "Bad API usage\n" +
        "No URL";
      req = new ResourceRequest();
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_1:
      statusText.text = "Post empty data\n";
      req = new ResourceRequest("http://105.64.202.141/cgi-bin/yusuke/test.cgi");
      req.method = "POST";
      req.callback = OnAsyncEvent;
      req.addHeader("test", "blah");
      req.addHeader("another", "header");
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_2:
      statusText.text = "Post data\n";
      req = new ResourceRequest("http://105.64.202.141/cgi-bin/yusuke/test.cgi");
      req.method = "POST";
      req.data = "fname=Test&lname=Ing";
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_3:
      statusText.text = "Put data\n";
      req = new ResourceRequest("http://105.64.202.141/cgi-bin/yusuke/test.cgi");
      req.method = "PUT";
      req.data = "file://dog.jpg";
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_4:
      statusText.text = "Put data\n";
      req = new ResourceRequest("http://105.64.202.141/cgi-bin/yusuke/test.cgi");
      req.method = "PUT";
      req.data = "invalid put data";
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_5:
      statusText.text = "Delete data\n";
      req = new ResourceRequest("http://105.64.202.141/cgi-bin/yusuke/test.cgi");
      req.method = "DELETE";
      req.data = "fname=Test&lname=Ing";
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_6:
      statusText.text = "Put data to local file\n";
      req = new ResourceRequest("file://test.txt");
      req.method = "PUT";
      req.data = "hello\nworld!!";
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_7:
      statusText.text = "Copying file";
      req = new ResourceRequest({ uri: "file://dog.jpg",
																			callback: function(result)
                                      {
                                        if (result.status != 200)
                                        {
                                          statusText.text = "Failed to get source data";
                                          return;
                                        }
                                        print("Got " + result.data.length + " bytes of data");
                                        var req = new ResourceRequest("file://test.txt");
                                        req.method = "PUT";
                                        req.data = result.data;
                                        req.callback = OnAsyncEvent;
                                        if (req.process() === false) statusText.text = "Failed to send async";
                                      }
                                    });
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_8:
      statusText.text = "Delete local file\n";
      req = new ResourceRequest("file://test.txt");
      req.method = "DELETE";
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_9:
      statusText.text = "Delete unaccessible file\n";
      req = new ResourceRequest("file://../copy.data");
      req.method = "DELETE";
      req.callback = OnAsyncEvent;
      if (req.process() === false) statusText.text = "Failed to send async";
      break;

    case Volt.KEY_0:
        req = new ResourceRequest({
        uri: "http://www.google.com",
        async: false,
        success: function(data, status, response)
        {
          print("Request success (" + data.length + " bytes, " + status + ")");
          print("Headers: ");
          for (var propt in response.headers)
          {
            print(propt + ': ' + response.headers[propt]);
          }
        },
        error: function(response, status, reason)
        {
          print("Request failed (" + reason + ")");
        },
        complete: function(response, status)
        {
          print("Request completed: " + status);
        }
      });
      req.process();
      break;

    case Volt.KEY_GREEN:
      startLoad();
      break;

    default:
      print("Unhandled event: " + keycode);
      break;
  }
}

var initialize = function() {
  print("Initializing...");

  mainContainer = new Widget(0, 0);
  mainContainer.parent = scene;
  mainContainer.width = 1920;
  mainContainer.height = 1080;
  mainContainer.color = {
    r: 0,
    g: 0,
    b: 0,
    a: 255
  };

  var statusContainer = new Widget(0, 40);
  statusContainer.parent = mainContainer;
  statusContainer.width = 1920;
  statusContainer.height = 400;
  statusContainer.color = {
    r: 22,
    g: 22,
    b: 22,
    a: 200
  };

  statusText = new TextWidget(0, 0);
  statusText.parent = statusContainer;
  statusText.width = 1920;
  statusText.height = 1080;
  statusText.font = "Helvetica 46px";
  statusText.color = {
    r: 155,
    g: 155,
    b: 155,
    a: 255
  };
  statusText.text = "Test Script\nNetwork";

  var remote_image = new ImageWidget(0, 0, "http://105.64.202.159/cars.jpg");
  remote_image.parent = mainContainer;
  remote_image.x = 250;
  remote_image.y = 500;
  remote_image.animate("rotation.y", 360 * 100, 100000); /* animate for a long long time */

  var local_image = new ImageWidget(0, 0, "file://dog.jpg");
  local_image.parent = mainContainer;
  local_image.x = 750;
  local_image.y = 500;
  local_image.animate("rotation.y", -360 * 100, 100000); /* animate for a long long time */

  var bad_remote_image = new ImageWidget(0, 0, "http://105.64.202.159/cars.jpg2");
  bad_remote_image.parent = mainContainer;
  bad_remote_image.x = 1000;
  bad_remote_image.y = 500;
  bad_remote_image.animate("rotation.y", 360 * 100, 100000); /* animate for a long long time */
};
