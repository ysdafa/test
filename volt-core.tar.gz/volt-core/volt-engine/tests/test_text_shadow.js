
var textWidget = new TextWidget({
    x: 200,
    y: 200,
    width: 800,
    height: 180,
    lineSpacing: 0,
    text: "hello, world, this is a test of the emergency broadcasting system; this is only a test.",
    textColor: {a:255},
    font: "60px",
    ellipsize: true,
    parent:scene,
    textShadow: { xOffset: 20, yOffset:20, color: {r:128,g:23,b:19,a:125} },
    });

scene.color = {r:128, g:128, b:128, a:255};

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event) {
    if (event.type == Volt.EVENT_KEY_RELEASE)
        return;
    if (textWidget.textShadow !== null)
    {
        textWidget.textShadow = null;
    }
    else
    {
        textWidget.textShadow = { xOffset: 20, yOffset:20, color: {r:128,g:23,b:19,a:125} };
        print("textShadow xoffset = " + textWidget.textShadow.xOffset);
        print("textShadow yoffset = " + textWidget.textShadow.yOffset);
        print("textShadow r color = " + textWidget.textShadow.color.r);
    }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event) {
    if (event.type == Volt.EVENT_KEY_RELEASE)
        return;

    var anim = new Animation(4000);
    anim.addKey(0.25, "textShadow.yOffset", 0);
    anim.addKey(0.25, "textShadow.xOffset", 20);
    anim.addKey(0.5, "textShadow.yOffset", 0);
    anim.addKey(0.5, "textShadow.xOffset", 0);
    anim.addKey(.75, "textShadow.yOffset", -20);
    anim.addKey(.75, "textShadow.xOffset", 0);
    anim.addKey(1, "textShadow.yOffset", -20);
    anim.addKey(1, "textShadow.xOffset", -20);
    var animHandle = textWidget.animate(anim);
});

Volt.addEventListener(Volt.KEY_RETURN, function(event) {
    if (event.type == Volt.EVENT_KEY_RELEASE)
        return;
    Volt.exit();
});
