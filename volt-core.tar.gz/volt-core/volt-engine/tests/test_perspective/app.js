var colors = require("colors");

/************Logging logic****************/

var display = new TextWidget({
    width: 300,
    height: 720,
    parent:scene,
    anchor:0.5,
    origin:{x:0.8, y:0.4},
    font: "50px"
});


function log(string) {
    display.text = string + "\n" + display.text;
}

function clear() {
    display.text = "";
}

log("testing text");


var master = new Widget({
    width: scene.width,
    height: scene.height,
    color: {r:0, g:0, b:0, a:0}
});
scene.addChild(master);
master.addChild(display);

var incY = 0;
function makePlane(originx){
    var plainWidget = new Widget({
        origin: {
            x: originx,
            y: 0.5 
        },
        y: incY,
        anchor : 0.5,
        width: 400,
        height: 400,
        parent: scene,
        color: colors.RED
    });
    plainWidget.rotation.y = 45;
    master.addChild(plainWidget);
    incY+= 100;
    print("DEPTH!! : " + plainWidget.depth);
    return plainWidget;
}

makePlane(0.1);
makePlane(0.5);
makePlane(0.9);

function makeCornerMarker(originx, originy) {
    return new Widget({
        parent:master,
        x: 1, //to compensate for the border
        y: 1,
        width: 100,
        height: 100,
        origin: {x: originx, y: originy},
        anchor: {x: originx, y: originy},
        border: {width: 1, color: colors.RED}
    });
}

makeCornerMarker(0, 0);
makeCornerMarker(1, 0);
makeCornerMarker(0, 1);
makeCornerMarker(1, 1);


Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event){
	if (event.type == Volt.EVENT_KEY_RELEASE) return;
    gc();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event){
	if (event.type == Volt.EVENT_KEY_RELEASE) return;
    master.scale.x += 0.2;
    master.scale.y += 0.2;
    scene.color = {r:0, g:0, b:0, a:0};
    //master.y += 100;
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event){
	 if (event.type == Volt.EVENT_KEY_RELEASE) return;
        master.scale = {
        x: master.scale.x - 0.2,
        y: master.scale.y - 0.2
    }; 
    //master.y -= 100;
});
