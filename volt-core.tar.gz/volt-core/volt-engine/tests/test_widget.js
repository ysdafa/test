// Test file for widget.
var colors = require("colors");
var initColor = {r:255, g:83, b:0, a: 255 };

var wid = new Widget({
    x: 100,
    y: 100,
    width: 256,
    height: 256,
    parent: scene
});

scene.addEventListener("OnMouseOver", function(widget, event) {
    if(event.origin === wid)
    {
        event.origin.color = colors.RED;
    }
});

scene.addEventListener("OnMouseOut", function(widget, event) {
    if(event.origin === wid)
    {
        event.origin.color = initColor;
        wid.border.color = colors.BLUE;
    }
});

wid.addEventListener("OnMouseMove", function(widget, event){
    widget.border.color = colors.GREEN;
});

scene.drawWithDepth = true;

wid.color = initColor;
wid.anchor = {x: 1, y: 1};
wid.origin = {x: 0.5, y:0.5};
wid.border = {
    width: 5,
    color: colors.BLUE
};

wid.rotation.z = 50;
wid.scale = 1.5;
wid.depth = -200;

var wid2 = new Widget({
    x: 400,
    y: 100,
    width: 256,
    height: 256,
    parent: scene
});

wid2.color = wid.color; 
var absSize = wid.getAbsoluteSize();
wid2.width = absSize.x;


var iwid = new ImageWidget({
    x:400,
    y:500,
    width:256,
    height:256,
    async: true,
    src: "dog.jpg",
    parent: scene,
    fillMode: "right",
    onReady: function(bool) {
        print("height is " + iwid.height + " Width is " + iwid.width);
        iwid.height = iwid.height * 1.2;
        iwid.width = iwid.width * 1.2;
        print("x = " + iwid.x);
        iwid.x = iwid.x - 20;
        print("x = " + iwid.x);
        print("fillMode = " + iwid.fillMode);
    }
});

print("async is " + iwid.async);


var img = new Image({
    async: false,
    noAtlas: false,
    noSlicing: true,
    noAutoMipmap: true,
    uri: "dog.jpg",
    success: function() { print("successfully loaded image"); },
    error: function() { print("error loading image."); },
    onGifComplete: function() { print("Gif is complete."); }
    });

var iwid2 = new ImageWidget({
    x: 800,
    y: 100,
    scale: {x:.25, y:.25, z:1.0},
    src: img,
    parent: scene
});

print("async: " + img.async);
print("noAtlas = " + img.noAtlas);
print("noSlicing = " + img.noSlicing);
print("noAutoMipmap = " + img.noAutoMipmap);



