
var text = new TextWidget({
    x: 200,
    y: 200,
    font: "smr00 32px",
    text: "Hello, World, this is a test of the emergency broadcasting system.",
    });

text.hide();
text.parent = scene;
var textIsShown = false;
print("Text width = " + text.width);
print("Text height= " + text.height);


var text2 = new TextWidget({
    x: 200,
    y: 300,
    width: 200,
    font: "smr00 32px",
    text: "Hello, World, this is a test of the emergency broadcasting system.",
    });

text2.hide();
text2.parent = scene;

print("Text2 width = " + text2.width);
print("Text2 height= " + text2.height);

var box = new Widget({
    x: text.x,
    y: text.y,
    width: text.width,
    height: text.height,
    parent: scene,
    color: {r:0,g:0,b:0,a:0},
    border: {width:2, color:{r:255,g:255,b:255,a:255} }
    });

var box2 = new Widget({
    x: text2.x,
    y: text2.y,
    width: text2.width,
    height: text2.height,
    parent: scene,
    color: {r:0,g:0,b:0,a:0},
    border: {width:2, color:{r:255,g:255,b:255,a:255} }
    });

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    if (!textIsShown)
    {
      text.show();
      text2.show();
    }
    else
    {
      text.hide();
      text2.hide();
    }
    textIsShown = !textIsShown;
});

