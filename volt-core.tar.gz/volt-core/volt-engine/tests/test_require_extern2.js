exports.moreText = "This Widget was a property in a nested module";

exports.showMoreText = function(x,y,thetext) {
	if(!thetext) thetext = "This Widget was created by an exernal module using a nested module";
	return new TextWidget({
		text: thetext,
		x: x,
		y: y,
		parent: scene
	});
};

new TextWidget({
	text: "This Widget was created directly by a nested module",
	x: 400,
	y: 500,
	parent: scene
});