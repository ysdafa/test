var redWidget;

function initialize() {
  redWidget = new Widget({
    width: 100,
    height: 100,
    x: 400,
    y: 400,
    color: {
      r: 255,
      g: 0,
      b: 0,
      a: 255
    },
    parent: scene
  });
}

function onKeyEvent(keycode) {
  switch (keycode) {
    case Volt.KEY_JOYSTICK_OK:
      runAnimations();
      break;
    case Volt.KEY_1:
      runOneLongAnimation();
      break;
    case Volt.KEY_EXIT:
      print("exit pressed");
      redWidget.destroy();
      break;
    default:
      print("Unhandled event: " + keycode);
      break;
  }
}


var runAnimations = function() {
  redWidget.animate("x", 100, 5000, function() {
    redWidget.animate("x", 400, 10000, function() {
      redWidget.animate("width", 400, 10000);
    });
  });
};


var runOneLongAnimation = function() {
  redWidget.animate("x", 700, 20000);
};