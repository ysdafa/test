var mainContainer;
var statusText;

var startLoad = function() {
	statusText.text = "STARTED....";
};

function onCustomKeyEvent(data) 
{
	if (data.type == Volt.EVENT_KEY_RELEASE)
		return;

	switch (data.keycode) 
	{
	case Volt.KEY_0:
		statusText.text = "Key 0 triggered\n";
		var model = SystemInfo.getStringValue(SystemInfo.KEY_MODEL);
		statusText.text += "\model: ";
		statusText.text += model;
		
		var platform = SystemInfo.getStringValue(SystemInfo.KEY_PLATFORM_NAME);
		statusText.text += "\nint platform: ";
		statusText.text += platform;
		
		var height = SystemInfo.getIntValue(SystemInfo.KEY_SCREEN_HEIGHT);
		statusText.text += "\nScreen height: ";
		statusText.text += height;
		
		var width = SystemInfo.getIntValue(SystemInfo.KEY_SCREEN_WIDTH);
		statusText.text += ", width: ";
		statusText.text += width;
		
		var hasDVI = SystemInfo.getBoolValue(SystemInfo.KEY_DVI_I_SUPPORTED);
		statusText.text += "\nDVI support: ";
		statusText.text += hasDVI;
		
// I do not have enough info to test the following..
//		var test1 = SystemInfo.getPlatformBoolValue("test");
//		var test2 = SystemInfo.getPlatformIntValue("test");
//		var test3 = SystemInfo.getPlatformStringValue("test");
//		var test4 = SystemInfo.getPlatformDoubleValue("test");
//		var Atest1 = SystemInfo.getCustomBoolValue("custom test");
//		var Atest2 = SystemInfo.getCustomIntValue("custom test");
//		var Atest3 = SystemInfo.getCustomStringValue("custom test");
//		var Atest4 = SystemInfo.getCustomDoubleValue("custom test");

		break;
		
	default:
		print("Unhandled event: " + data.keycode);
		break;
	}
}

var initialize = function() 
{
	print("Initializing...");

	mainContainer = new Widget(0, 0);
	mainContainer.parent = scene;
	mainContainer.width = 1920;
	mainContainer.height = 1080;
	mainContainer.color = {
		r : 0,
		g : 0,
		b : 0,
		a : 255
	};

	var statusContainer = new Widget(0, 40);
	statusContainer.parent = mainContainer;
	statusContainer.width = 1920;
	statusContainer.height = 400;
	statusContainer.color = {
		r : 22,
		g : 22,
		b : 22,
		a : 200
	};

	statusText = new TextWidget(0, 0);
	statusText.parent = statusContainer;
	statusText.width = 1920;
	statusText.height = 1080;
	statusText.font = "Helvetica 46px";
	statusText.color = {
		r : 155,
		g : 155,
		b : 155,
		a : 255
	};
	statusText.text = "Tizen System Info Test Script, press 0 to start\n";

	Volt.addEventListener(Volt.KEY_0, onCustomKeyEvent);
};
