var root = new Widget({
    x:0,
    y:0,
    width:0,
    height:0,
})

var backDropWidget = new Widget({
    color: {r:111, g:111, b:111, a:255},
    x: 0,
    y: 0,
    width:1920,
    height:1080,
    });

var showThrough = new Widget({
    x:50,
    y:50,
    width: 400,
    height: 400,
    color: {r:50, g:200, b:50, a:255},
    cutThrough: backDropWidget,
    parent: root,
    });

var widget1 = new Widget({
    color: {r:230, g:111, b:111, a:255},
    x:200,
    y:200,
    width:400,
    height:400,
    parent: backDropWidget,
    });

var widget2 = new ImageWidget({
    src: "dog.jpg",
    x:50,
    y:50,
    parent: widget1,
    });





scene.addChild(root);
root.addChild(backDropWidget);






