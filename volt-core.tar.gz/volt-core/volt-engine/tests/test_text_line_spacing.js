
var text = new TextWidget({
    x: 200,
    y: 200,
    width: 200,
    lineSpacing: 30,
    font: "smr00 32px",
    text: "Hello, World, this is a test of the emergency broadcasting system.",
    parent: scene
    });

var box = new Widget({
    x: text.x,
    y: text.y,
    width: text.width,
    height: text.height,
    parent: scene,
    color: {r:0,g:0,b:0,a:0},
    border: {width:2, color:{r:255,g:255,b:255,a:255} }
    });

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    text.animate("lineSpacing", 60, 2000);
    });

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    text.animate("lineSpacing", -10, 2000);
    });

