var modes = ["stetch",
"fit",
"top",
"top-left",
"top-right",
"left",
"right",
"center",
"bottom-left",
"bottom",
"bottom-right"];

var image = new ImageWidget({
	anchor: { x: 0.5, y: 0.5 },
	origin: { x: 0.5, y: 0.5 },
	src: "test-image.png",
	parent: scene,
	width: 1920,
	height: 1080,
	fillMode: modes[0],
	color: {r:0 , g: 0, b:255}
});



var currentModeIndex = 0;

function setMode(index)
{
	image.fillMode = modes[index];
}

function onKeyEvent(keycode)
{
	currentModeIndex = (currentModeIndex + 1) % modes.length;
	setMode(currentModeIndex);
}


