
var alternateSrc = "test-image.png";

var image = new ImageWidget({
	src: "dog.jpg",
	parent: scene,
	origin: 0.5,
	anchor: 0.5
});

function swapImage() {
	var newSrc = alternateSrc;
	alternateSrc = image.src;
	image.src = newSrc;
}

function onKeyEvent(event, type) {
	if (type != Volt.EVENT_KEY_PRESS)  return;

	swapImage();
}