var ticker_id = 0;
var tick = 0;

var textWidget = new TextWidget({ parent: scene,
                                  x: 0, y: 0,
                                  width: scene.width,
                                  height: scene.height,
                                  textColor: { r: 255, g: 255, b: 255, a: 255 },
                                  text: "hello" });

function ticker(msg) {
  textWidget.text = msg + tick;
  print(msg + tick++);

  if (tick == 10) return false; /* stop */
}

function callback(arg1, arg2) {
  print("Callback called!");
  print("arg1: " + arg1);
  print("arg2: " + arg2);
  print("Clear ticker timer!");
  Volt.clearTimer(ticker_id);
}

function another_callback(arg1, arg2, arg3, arg4) {
  print("Another callback called!");
  print("arg1: " + arg1);
  print("arg2: " + arg2);
  print("arg3: " + arg3);
  print("arg4: " + arg4);
}

var initialize = function() {
  print("Initializing...");

  ticker_id = Volt.setInterval(ticker, 1000, "ticking ");

  Volt.setTimeout(callback, 5000, "hi", ["elem1", "elem2"]);
  Volt.setTimeout(another_callback, 1000, "hello", "how", "are", "you");
};
