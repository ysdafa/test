var script_uri = "http://105.64.202.141/yusuke/Snap/app.js";

if (loadScript(script_uri) === false) {
  Volt.exit();
}

function loadScript(uri) {
  var req = new ResourceRequest(uri);
  req.async = false;
  if (req.process() === false) {
    print("Failed to load script: " + req.uri);
    return false;
  }

  if (req.status != 200) {
    print("Failed to read file: " + req.uri);
    return false;
  }

  /* Load data as JS */
  if (Volt.load(req.data) === false) {
    print("Failed to load script");
    return false;
  }

  return true;
}