/* Requires Volt 0.9 */
var colors = require("colors");

var mode = ["move", "scale", "rotate", "origin", "anchor"];
var current = 0;

var widget = new Widget(0,0, 100, 100);
widget.parent = scene;
//widget.anchor = {x: 0.5, y: 0.5};

var marker = new Widget(0,0, 20, 20);
marker.parent = scene;
marker.color = {r: 255, g: 0, b: 0, a: 50};
marker.border = { width: 2, color: colors.RED };

var display = new TextWidget({text: "Currently Editing: " + mode[current], parent: scene, origin: {x: 0.5, y: 0.9}, anchor: {x: 0.5, y: 0.5}, width: 500 });

var display2 = new TextWidget({ parent: scene, origin: {x: 0.5, y: 0.7}, anchor: {x: 0.5, y: 0.5}, width: 300 });

var top = widget;

function pushWidget() {
	var newParent = new Widget({
		width : 100, 
		height: 100,
		color: { r:0, g:255, b:255, a:50 },
		border: { width: 3, color: colors.GREEN },
		parent: scene
	});
	top.parent = newParent;
	top = newParent;
	marker.parent = marker.parent; 
}

function incrementCurrent(){
	current = (current + 1) % mode.length;
}

function updateDisplay()
{
	display.text = "Currently Editing: " + mode[current];
}

var moveStep = 10;
var scaleStep = 0.1;
var rotateStep = 5;

function onUp(){
	if(mode[current] == "move")
		top.y -= moveStep;
	else if (mode[current] == "scale")
		top.scale.y += scaleStep;
	else if (mode[current] == "rotate")
		top.rotation.y += rotateStep;
	else if (mode[current] == "origin")
		top.origin.y += scaleStep;
	else if (mode[current] == "anchor")
		top.anchor.y += scaleStep;
}

function onDown(){
	if(mode[current] == "move")
		top.y += moveStep;
	else if (mode[current] == "scale")
		top.scale.y -= scaleStep;
	else if (mode[current] == "rotate")
		top.rotation.y -= rotateStep;
	else if (mode[current] == "origin")
		top.origin.y -= scaleStep;
	else if (mode[current] == "anchor")
		top.anchor.y -= scaleStep;
}

function onLeft(){
	if(mode[current] == "move")
		top.x -= moveStep;
	else if (mode[current] == "scale")
		top.scale.x -= scaleStep;
	else if (mode[current] == "rotate")
		top.rotation.z -= rotateStep;
	else if (mode[current] == "origin")
		top.origin.x -= scaleStep;
	else if (mode[current] == "anchor")
		top.anchor.x -= scaleStep;

}

function onRight(){
	if(mode[current] == "move")
		top.x += moveStep;
	else if (mode[current] == "scale")
		top.scale.x += scaleStep;
	else if (mode[current] == "rotate")
		top.rotation.z += rotateStep;
	else if (mode[current] == "origin")
		top.origin.x += scaleStep;
	else if (mode[current] == "anchor")
		top.anchor.x += scaleStep;

}

function matchPos(widget, target) {
	var pos = target.getAbsolutePosition();
	widget.x = pos.x;
	widget.y = pos.y;
	widget.depth = pos.z;
	//display2.text = "abs pos: x:" + pos.x + ", y:" + pos.y + ", z:" + pos.z;

	var size = target.getAbsoluteSize();
	widget.width = size.x;
	widget.height = size.y;
}

var onKeyEvent = function(keycode) {
	switch(keycode)
	{
	case Volt.KEY_JOYSTICK_OK:
	case 32:
		  incrementCurrent();
		  if(current === 0)
			  pushWidget();
		 break;
	 case Volt.KEY_JOYSTICK_UP: 
		  onUp();
		 break;
	 case Volt.KEY_JOYSTICK_DOWN: 
		  onDown();
		 break;
	 case Volt.KEY_JOYSTICK_LEFT: 
		  onLeft();
		 break;
	 case Volt.KEY_JOYSTICK_RIGHT: 
		  onRight();
		 break;
	}
	matchPos(marker, widget);
	updateDisplay();

};

