// Run this test on the TV, monitor the serial output,
// and press the Exit key immediately after seeing "Test the Interval...." printed,
// then relaunch the app immediately.  Try this a few times.  The app should not crash.

var intervalID;
var CallBackFunc = function(){
     print("Test the Interval.....................");
};
var initialize = function() {
     intervalID = Volt.setInterval(CallBackFunc, 5000);    
};
function onKeyEvent(keycode) {
     switch(keycode) {
           case Volt.KEY_EXIT:
                Volt.exit();
                break;               
           default:
             print("Default Key input! Ignored~~~");
             break;
     }
}

