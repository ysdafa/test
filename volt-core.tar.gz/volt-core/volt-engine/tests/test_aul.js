var aulApp;
var ticker_id = 0;
var tick = 0;

function callback(arg1, arg2) 
{
  print("Callback called!");
  print("arg1: " + arg1);
  print("arg2: " + arg2);
  print("Clear ticker timer!");
  Volt.clearTimer(ticker_id);
  
	if(aulApp != null)
	{
		aulApp.terminate();
	}
}

function serviceCallback(result)
{
	print("serviceCallback called!");
}

function onKeyEvent(event, type) 
{
	if (type != Volt.EVENT_KEY_PRESS)  return;

	switch (event) 
	{
	case Volt.KEY_JOYSTICK_OK:
		break;
	
	case Volt.KEY_JOYSTICK_UP:
		aulApp = new Aul();
		
		var stringArray = ["B", "C", "D", "E"];
		var args1 = {input1: "A", input2: stringArray};
		
		aulApp.launchApp("org.tizen.crash-popup", args1);
		
		Volt.setTimeout(callback, 5000, "hi", ["elem1", "elem2"]);
		
		break;
		
	case Volt.KEY_JOYSTICK_DOWN:
		if(aulApp != null)
		{
			aulApp.terminate();
		}
		break;
	
	case Volt.KEY_JOYSTICK_LEFT:
		aulApp = new Aul();
		var args2 = {input3: "C", input4: "D"};
		aulApp.openService("org.tizen.service1", args2, function(result)
		{
			print("serviceCallback called!");
		});
		
		Volt.setTimeout(callback, 5000, "hi", ["elem1", "elem2"]);
		
		break;
		
    default:
        print("Unhandled event: " + event);
        break;
	}
}
