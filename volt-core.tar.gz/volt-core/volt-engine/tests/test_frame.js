var frame_ = null;
var widgets_ = [];

Volt.addEventListener(Volt.ON_SHOW, function()
{
  frame_ = new FrameWidget({
    parent: scene,
    x: 0,
    y: 0,
    width: scene.width,
    height: scene.height,
    color: { r: 255, g: 0, b: 0, a: 255 },
    orientation: "horizontal"
  });
  frame_.alignX = "right";
  frame_.alignY = "left";
});

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  widgets_.push(new Widget({ width: 100, height: 100, 
                             color: { r: Math.floor(Math.random() * 155) + 100,
                                      g: Math.floor(Math.random() * 155) + 100,
                                      b: Math.floor(Math.random() * 155) + 100,
                                      a: 255 }}));

  frame_.addChild(widgets_[widgets_.length - 1]);
});

Volt.addEventListener(Volt.KEY_RETURN, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  frame_.removeChild(widgets_.pop());
});
