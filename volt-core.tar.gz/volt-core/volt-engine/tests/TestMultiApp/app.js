var display = new TextWidget({
	width: 500, 
	height:500,
	parent:scene
});


Volt.addEventListener(Volt.ON_LOAD, function(){
  print("onLoad");
  display.text = "onLoad";
});

Volt.addEventListener(Volt.ON_SHOW, function(){
  print("onShow");
  display.text = "onShow<-" + display.text;
});

Volt.addEventListener(Volt.ON_PAUSE, function(){
  print("onPause");
  display.text = "onPause<-" + display.text;
});

Volt.addEventListener(Volt.ON_RESUME, function(){
  print("onResume");
  display.text = "onResume<-" + display.text;
});

Volt.addEventListener(Volt.ON_HIDE, function(){
  print("onHide");
  display.text = "onHide<-" + display.text;
});

Volt.addEventListener(Volt.ON_UNLOAD, function(){
  print("onUnload");
  display.text = "onUnload<-" + display.text;
});

function onKeyEvent(keyCode, type) {
  if (keyCode == Volt.KEY_RETURN) 
  {
    Volt.exit();
    return true;
  }
}
