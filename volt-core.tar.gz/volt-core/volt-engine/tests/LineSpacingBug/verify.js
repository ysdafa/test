/*
 * 
 */


var TextBG = new ListWidget({
	x:660,
	y:20,
	width:600,
	parent:scene
})

TextBG.orientation = "vertical";
var height123 = 20;
var tempWgt = null;
var tempColor = null;
for(var index = 0; index < 60; index ++) {
	tempWgt = new Widget({
		width:600,
		height:height123,
		color: index % 2 == 0 ? {r:150, g:150, b:200} : {r:10, g:10, b:30}
	})
	tempWgt.parent = TextBG;
}

var TextWgt = new TextWidget({
	x:660,
	y:20,
	font:"15px",
	width:600,
	//text:"TextWidget Volt TextWidgetVolt TextWidget Volt Text\n\n\n\nWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt Text\n\nWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt TextWidget Volt",
	text:"text",
	textColor:{g:255},
	verticalAlignment:'center',
	horizontalAlignment:'left'
})
//print(TextWgt.getLineHeight());
TextWgt.lineSpacing = height123 - TextWgt.getLineHeight();
TextWgt.parent = scene;

var File_request = new ResourceRequest({
	uri: 'Text-blankline.txt',
	success: function(data, status, response){
		print("it is ok");
		//print("Read data: " + data);
		TextWgt.text = data;
	}
});
File_request.process();


