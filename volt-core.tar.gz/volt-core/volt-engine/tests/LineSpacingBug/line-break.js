var config={width:700};
scene.color = {
    r: 255,
    g: 255,
    b: 255,
    a: 255
};
var lw = new ListWidget({
    width: 900,
    height: 900,
    spacing: 30,
    parent: scene
});
var aContainer = new Widget({
    width: config.width,
    height: 900,
    color: {
        r: 51,
        g: 51,
        b: 153,
        a: 255
    },
    parent: lw
});
var aTWContainer = new Widget({
    width: config.width,
    height: 860,
    x: 0,
    y: 20,
    cropOverflow: true,
    color: {
        r: 51,
        g: 51,
        b: 153,
        a: 255
    },
    cropOverflow: true,
    parent: aContainer
});
var a_text = new TextWidget({
    width: config.width,
    height: 2000,
    lineSpacing : 20,  
    x: 0,
    y: 0,
    font: "Samsung SVD_Light 36px",
    text: "The red lines should be drawn between lines of text\
1ABCDEFGHIJKLMNOPQRSTUVWXYZ\
2ABCDEFGHIJKLMNOPQRSTUVWXYZ\
3ABCDEFGHIJKLMNOPQRSTUVWXYZ\
4ABCDEFGHIJKLMNOPQRSTUVWXYZ\
5ABCDEFGHIJKLMNOPQRSTUVWXYZ\
6ABCDEFGHIJKLMNOPQRSTUVWXYZ\
7ABCDEFGHIJKLMNOPQRSTUVWXYZ\
8ABCDEFGHIJKLMNOPQRSTUVWXYZ\
9ABCDEFGHIJKLMNOPQRSTUVWXYZ\
0ABCDEFGHIJKLMNOPQRSTUVWXYZ\
1ABCDEFGHIJKLMNOPQRSTUVWXYZ\
2ABCDEFGHIJKLMNOPQRSTUVWXYZ\
3ABCDEFGHIJKLMNOPQRSTUVWXYZ\
4ABCDEFGHIJKLMNOPQRSTUVWXYZ\
5ABCDEFGHIJKLMNOPQRSTUVWXYZ\
6ABCDEFGHIJKLMNOPQRSTUVWXYZ\
7ABCDEFGHIJKLMNOPQRSTUVWXYZ\
8ABCDEFGHIJKLMNOPQRSTUVWXYZ\
9ABCDEFGHIJKLMNOPQRSTUVWXYZ\
0ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    parent: aTWContainer
});

for(var i = 0; i < 20; i++)
{
    aTWContainer.addChild(new Widget({x:0,y:a_text.getLineHeight() * (i+1),height:1,width:1920,color:{r:128,g:0,b:0}}));
}
var a_UpArrow = new Widget({
    width: config.width,
    height: 20,
    color: {
        r: 0,
        g: 0,
        b: 0,
        a: 255
    },
    parent: aContainer
});


var a_UpArrow_img = new TextWidget({
    width: 20,
    height: 20,
    text: "^",
    font: "Samsung SVD_Light 36px",
    textColor: {
        r: 255,
        g: 255,
        b: 255
    },
    origin: {
        x: 0.5,
        y: 0.2
    },
    parent: a_UpArrow
});

var a_DownArrow = new Widget({
    width: config.width,
    height: 20,
    x: 0,
    y: 880,
    color: {
        r: 0,
        g: 0,
        b: 0,
        a: 255
    },
    parent: aContainer
});
var a_DownArrow_img = new TextWidget({
    width: 20,
    height: 20,
    text: "v",
    font: "Samsung SVD_Light 36px",
    textColor: {
        r: 255,
        g: 255,
        b: 255
    },
    origin: {
        x: 0.5,
        y: 0.2
    },
    parent: a_DownArrow
});
a_UpArrow.addEventListener("OnMouseClick", function() {
    scrollUp(a_text)
});
a_DownArrow.addEventListener("OnMouseClick", function() {
    scrollDown(a_text)
});

var bContainer = new Widget({
    width: config.width,
    height: 900,
    cropOverflow: true,
    color: {
        r: 51,
        g: 51,
        b: 153,
        a: 255
    },
    parent: lw
});
var bTWContainer = new Widget({
    width: config.width,
    height: 860,
    x: 0,
    y: 20,
    cropOverflow: true,
    color: {
        r: 51,
        g: 51,
        b: 153,
        a: 255
    },
    cropOverflow: true,
    parent: bContainer
});
var b_text = new TextWidget({
    width: config.width,
    height: 2000,
    x: 0,
    y: 0,
    
    lineSpacing : 20,
    font: "Samsung SVD_Light 36px",
    text: "The red lines should be drawn between lines of text\n\
1ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\
2ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\
3ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\
4ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
5ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
6ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
7ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
8ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
9ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
0ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
1ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
2ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
3ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
4ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
5ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
6ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
7ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
8ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
9ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n\
0ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    parent: bTWContainer
});
for(var i = 0; i < 20; i++)
{
    bTWContainer.addChild(new Widget({x:0,y:b_text.getLineHeight() * (i+1),height:1,width:1920,color:{r:128,g:0,b:0}}));
}
var b_UpArrow = new Widget({
    width: config.width,
    height: 20,
    color: {
        r: 0,
        g: 0,
        b: 0,
        a: 255
    },
    parent: bContainer
});
var b_UpArrow_img = new TextWidget({
    width: 20,
    height: 20,
    text: "^",
    textColor: {
        r: 255,
        g: 255,
        b: 255
    },
    origin: {
        x: 0.5,
        y: 0.2
    },
    parent: b_UpArrow
});
var b_DownArrow = new Widget({
    width: config.width,
    height: 20,
    x: 0,
    y: 880,
    color: {
        r: 0,
        g: 0,
        b: 0,
        a: 255
    },
    parent: bContainer
});
var b_DownArrow_img = new TextWidget({
    width: 20,
    height: 20,
    text: "v",
    font: "Samsung SVD_Light 36px",
    textColor: {
        r: 255,
        g: 255,
        b: 255
    },
    origin: {
        x: 0.5,
        y: 0.2
    },
    parent: b_DownArrow
});
b_UpArrow.addEventListener("OnMouseClick", function() {
    scrollUp(b_text)
});
b_DownArrow.addEventListener("OnMouseClick", function() {
    scrollDown(b_text)
});

function scrollUp(target_textWidget) {
    target_textWidget.y = target_textWidget.y - target_textWidget.getLineHeight();

}

function scrollDown(target_textWidget) {
    target_textWidget.y = target_textWidget.y + target_textWidget.getLineHeight();

}
