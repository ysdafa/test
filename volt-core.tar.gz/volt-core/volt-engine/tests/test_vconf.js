var root;
var textWidget;

Volt.addEventListener(Volt.ON_SHOW, function()
{
  root = new Widget({
    x: 0, y: 0,
    width: scene.width, height: scene.height,
    rotation: { x: 0, y: 0, z: 180 },
    color: { r: 0, g: 0, b: 0 },
    parent: scene
  });

  textWidget = new TextWidget({ text: "", font: "48px", parent: root });

  reset();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) refresh();
});

Volt.addEventListener(Volt.KEY_1, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) reset();
});

Volt.addEventListener(Volt.KEY_2, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) clear();
});

Volt.addEventListener(Volt.KEY_3, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE)
  {
    /* recursive unset */
    Vconf.unsetValue("memory/volt", true);
    refresh();
  }
});

Volt.addEventListener(Volt.KEY_4, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE)
  {
    Vconf.setOnChangeHandler("memory/volt/notify", onChangeHandler1);
  }
});

Volt.addEventListener(Volt.KEY_5, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE)
  {
    Vconf.setOnChangeHandler("memory/volt/notify", onChangeHandler2);
  }
});

Volt.addEventListener(Volt.KEY_6, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE)
  {
    Vconf.unsetOnChangeHandler("memory/volt/notify", onChangeHandler1);
  }
});

Volt.addEventListener(Volt.KEY_7, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE)
  {
    Vconf.unsetOnChangeHandler("memory/volt/notify", onChangeHandler2);
  }
});

var refresh = function()
{
  var text = "Vconf.getValue(\"memory/volt/string\") = " + Vconf.getValue("memory/volt/string") + "\n" +
             "Vconf.getValue(\"memory/volt/int\") = " + Vconf.getValue("memory/volt/int") + "\n" +
             "Vconf.getValue(\"memory/volt/double\") = " + Vconf.getValue("memory/volt/double") + "\n" +
             "Vconf.getValue(\"memory/volt/bool\") = " + Vconf.getValue("memory/volt/bool") + "\n" +
             "Vconf.getValue(\"memory/volt/nested/string\") = " + Vconf.getValue("memory/volt/nested/string") + "\n" +
             "Vconf.getValue(\"memory/volt/notify\") = " + Vconf.getValue("memory/volt/notify") + "\n\n";

  var values = Vconf.getValues("memory/volt");
  for (key in values)
  {
    text += key + " = " + values[key] + "\n";
  }
  text += "\n";

  textWidget.destroy();
  textWidget = new TextWidget({ text: text, font: "48px", parent: root });
}

var reset = function()
{
  Vconf.setValue("memory/volt/string", "hi volt");
  Vconf.setValue("memory/volt/int", 0);
  Vconf.setValue("memory/volt/double", 0);
  Vconf.setValue("memory/volt/bool", false);
  Vconf.setValue("memory/volt/nested/string", "hi nested string");
  Vconf.setValue("memory/volt/notify", "no notification");

  refresh();
}

var clear = function()
{
  Vconf.unsetValue("memory/volt/string");
  Vconf.unsetValue("memory/volt/int");
  Vconf.unsetValue("memory/volt/double");
  Vconf.unsetValue("memory/volt/bool");
  Vconf.unsetValue("memory/volt/nested/string");
  Vconf.unsetValue("memory/volt/notify");

  refresh();
}

var onChangeHandler1 = function(key, value)
{
  var text = textWidget.text + "onChangeHandler1 called: " + key + " = " + value + "\n\n";
  textWidget.destroy();
  textWidget = new TextWidget({ text: text, font: "48px", parent: root });
}

var onChangeHandler2 = function(key, value)
{
  var text = textWidget.text + "onChangeHandler2 called: " + key + " = " + value + "\n\n";
  textWidget.destroy();
  textWidget = new TextWidget({ text: text, font: "48px", parent: root });
}
