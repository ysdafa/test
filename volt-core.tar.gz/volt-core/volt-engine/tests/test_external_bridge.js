var textArea;

Volt.addEventListener(Volt.ON_SHOW, function(args)
{
  var image = new ImageWithLabel({
    parent: scene,
    x: 100,
    y: 100,
    width: 200,
    height: 200,
    src: "dog.jpg",
    label: "this is a fairly long label"
  });

  textArea = new ScrollTextArea({
    parent: scene,
    x: 500,
    y: 100,
    width: 300,
    height: 300,
    roundedCorners: { radius: 10.0, arcStep: 2.0 }
  });

  textArea.text = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

  var imageAnimation = new Animation(5000, -1);
  imageAnimation.addKey(0.25, "scale", { x: 1.5, y: 1.5 });
  imageAnimation.addKey(0.75, "scale", { x: 0.5, y: 0.5 });
  imageAnimation.addKey(1.0, "scale", { x: 1.0, y: 1.0 });
  image.animate(imageAnimation);

  var textAnimation = new Animation(5000, -1);
  textAnimation.addRelativeKey(1, "rotation.y", 360);
  textArea.animate(textAnimation);
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;
  textArea.scrollUp();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;
  textArea.scrollDown();
});
