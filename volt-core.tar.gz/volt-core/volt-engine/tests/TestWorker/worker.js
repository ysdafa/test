var name_ = "worker";
var rects_ = [];
var widget_y_ = 0;
var widget_length_ = 0;

Volt.addEventListener(Volt.ON_MESSAGE, function(event)
{
  print("[" + name_ + "] received msg: " + event.data);

  var msg = JSON.parse(event.data);
  if (msg.msg == "init")
  {
    name_ = msg.data.name;
    print("My new name is " + name_);

    widget_y_ = msg.data.y;
    widget_length_ = msg.data.length;

    var rect = new Widget({
      parent: scene,
      x: 0,
      y: widget_y_,
      width: widget_length_,
      height: widget_length_,
      color: { r: Math.floor(Math.random() * 155) + 100,
               g: Math.floor(Math.random() * 155) + 100,
               b: Math.floor(Math.random() * 155) + 100,
               a: 255 }
    });

    rects_.push(rect);
  }
  else if (msg.msg == "addRect")
  {
    print("[" + name_ + "] addRect");

    var rect = new Widget({
      parent: scene,
      x: rects_.length * widget_length_,
      y: widget_y_,
      width: widget_length_,
      height: widget_length_,
      color: { r: Math.floor(Math.random() * 155) + 100,
               g: Math.floor(Math.random() * 155) + 100,
               b: Math.floor(Math.random() * 155) + 100,
               a: 255 }
    });

    rects_.push(rect);

    if (rects_.length > 5) x
  }
  else if (msg.msg == "stop")
  {
    Volt.exit();
  }
});

Volt.addEventListener(Volt.ON_LOAD, function()
{
  print("This is a worker process");

  var msg = { msg: "ready" };
  Volt.postMessage(JSON.stringify(msg));
});
