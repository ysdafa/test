var id_ = -1;
var name_ = "worker";
var echoWorker_;

Volt.addEventListener(Volt.ON_MESSAGE, function(event)
{
  print("[" + name_ + "] received msg: " + event.data);

  var msg = JSON.parse(event.data);
  if (msg.msg == "init")
  {
    id_ = msg.data.id;
    name_ = msg.data.name;
    print("My new name is " + name_);
  }
  else if (msg.msg == "addWorker")
  {
    addWorker();

    var msg = { msg: "status",
                data: "Sent addWorker msg to " + echoWorker_.name };

    Volt.postMessage(JSON.stringify(msg));
  }
  else if (msg.msg == "crash")
  {
    if (echoWorker_ && echoWorker_.running)
    {
      echoWorker_.postMessage(event.data);

      var msg = { msg: "status",
                  data: "Sent crash msg to " + echoWorker_.name };

      Volt.postMessage(JSON.stringify(msg));
    }
    else
    {
      /* Exception: Widget is not supported in a worker */
      var widget = new Widget();
    }
  }
  else if (msg.msg == "stop")
  {
    Volt.exit();
  }
});

Volt.addEventListener(Volt.ON_COMMAND, function(event)
{
  print("[" + name_ + "] received command: " + event.data);

  var msg = JSON.parse(event.data);
  if (msg.cmd == "echo")
  {
    if (echoWorker_ && echoWorker_.running)
    {
      return "[" + name_ + ": " + echoWorker_.execCommand(event.data) + "]";
    }
    else
    {
      return "[" + name_ + ": " + msg.data + "]";
    }
  }
});

Volt.addEventListener(Volt.ON_LOAD, function()
{
  print("This is a worker process");

  var msg = { msg: "ready" };
  Volt.postMessage(JSON.stringify(msg));
});

Volt.addEventListener(Volt.ON_UNLOAD, function(event)
{
  print("Stopping workers");
  if (echoWorker_) echoWorker_.terminate();
});

var addWorker = function()
{
  print("Creating a new echo worker");

  if (echoWorker_ && echoWorker_.running)
  {
    msg = { msg: "addWorker" };
    echoWorker_.postMessage(JSON.stringify(msg));
  }
  else
  {
    echoWorker_ = new VoltWorker({
      uri: "echo_worker.js",
      onMessage: function(event)
      {
        var msg = JSON.parse(event.data);
        if (msg.msg == "ready")
        {
          print("Worker " + echoWorker_.id + " is ready");

          msg = {
            msg: "init",
            data: {
              id: echoWorker_.id,
              name: echoWorker_.name,
            }
          };
          echoWorker_.postMessage(JSON.stringify(msg));
        }
        else if (msg.msg == "status")
        {
          Volt.postMessage(JSON.stringify(msg));
        }
      },
      onError: function(event)
      {
        print("Terminating worker " + echoWorker_.id);
        var msg = { msg: "status",
                    data: echoWorker_.name + " encountered an error" };

        Volt.postMessage(JSON.stringify(msg));

        echoWorker_ = null;
      }
    });

    echoWorker_.id = id_ + 1;
    echoWorker_.name = "EchoWorker-" + echoWorker_.id;
  }
}


