var _ = require("underscore")._;

var workers_ = [];
var count_ = 0;
var widget_y_ = 0;
var widget_length_ = 20;

var worker_scenes_ = [];

Volt.addEventListener(Volt.ON_SHOW, function()
{
  print("This is the main app.js");

  worker_scenes_.push(new Widget({
    parent: scene,
    x: 0,
    y: 0,
    width: scene.width / 2,
    height: scene.height / 2,
    color: { r: 155, g: 0, b: 0, a: 255 }
  }));

  worker_scenes_.push(new Widget({
    parent: scene,
    x: scene.width / 2,
    y: 0,
    width: scene.width / 2,
    height: scene.height / 2,
    color: { r: 0, g: 155, b: 0, a: 255 }
  }));

  worker_scenes_.push(new Widget({
    parent: scene,
    x: 0,
    y: scene.height / 2,
    width: scene.width / 2,
    height: scene.height / 2,
    color: { r: 0, g: 0, b: 155, a: 255 }
  }));

  worker_scenes_.push(new Widget({
    parent: scene,
    x: scene.width / 2,
    y: scene.height / 2,
    width: scene.width / 2,
    height: scene.height / 2,
    color: { r: 155, g: 155, b: 155, a: 255 }
  }));
});

Volt.addEventListener(Volt.ON_UNLOAD, function(event)
{
  print("Should stop workers");
  workers_.forEach(function(worker)
  {
    msg = { msg: "stop" };
    worker.postMessage(JSON.stringify(msg));
  }, this)
});

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  print("Should create new worker");

  var worker_scene = new Widget({
    width: worker_scenes_[count_ % worker_scenes_.length].width,
    height: worker_scenes_[count_ % worker_scenes_.length].height,
    color: { r:0, g:0, b:0, a:0 },
    parent: worker_scenes_[count_ % worker_scenes_.length]
  });

  var worker = new VoltWorker({
    uri: "worker.js",
    scene: worker_scene,
    onMessage: function(event)
    {
      var msg = JSON.parse(event.data);
      if (msg.msg == "ready")
      {
        print("Worker " + event.worker.id + " is ready");

        msg = {
          msg: "init",
          data: {
            name: "worker-" + event.worker.id,
            y: worker.y,
            length: widget_length_
          }
        };
        event.worker.postMessage(JSON.stringify(msg));
      }
    },
    onError: function(event)
    {
      print("Terminating worker " + event.worker.id);
      event.worker.terminate();

      event.worker.scene.destroy();
    }
  });

  worker.id = count_++;
  worker.y = widget_y_;

  if (count_ % worker_scenes_.length == 0)
    widget_y_ += widget_length_;

  workers_.push(worker);
});

Volt.addEventListener(Volt.KEY_JOYSTICK_RIGHT, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  print("Should create new widget");
  workers_.forEach(function(worker)
  {
    msg = { msg: "addRect" };
    worker.postMessage(JSON.stringify(msg));
  }, this)
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  worker_scenes_.forEach(function(worker_scene)
  {
    worker_scene.rotation.x += 30;
  }, this)
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  worker_scenes_.forEach(function(worker_scene)
  {
    worker_scene.rotation.x -= 30;
  }, this)
});
