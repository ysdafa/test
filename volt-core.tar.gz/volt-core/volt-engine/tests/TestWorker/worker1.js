Volt.addEventListener(Volt.ON_MESSAGE, function(event)
{
  print("worker1 received msg: " + event.data);
  Volt.postMessage("This is from worker1");
});

Volt.addEventListener(Volt.ON_SHOW, function()
{
  print("This is a worker 1");

  var rect = new Widget({
    parent: scene,
    x: 200,
    y: 0,
    width: 100,
    height: 100,
    color: { r: 0, g: 255, b: 0, a: 255 }
  });
});
