Volt.addEventListener(Volt.ON_MESSAGE, function(event)
{
  print("worker2 received msg: " + event.data);
  Volt.postMessage("This is from worker2");
});

Volt.addEventListener(Volt.ON_SHOW, function()
{
  print("This is a worker 2");

  var rect = new Widget({
    parent: scene,
    x: 400,
    y: 0,
    width: 100,
    height: 100,
    color: { r: 0, g: 0, b: 255, a: 255 }
  });
});
