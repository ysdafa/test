Volt.addEventListener(Volt.ON_LOAD, function()
{
  print("This is a time worker process");

  Volt.setInterval(function()
  {
    Volt.postMessage((new Date()).toString());
    return true; /* contineu forever */
  }, 1000);
});
