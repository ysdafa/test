	
	var AppRecommendInfo = [
	{
		info:"Youtube",
		src:"smartHub2014/AppImage/youtube_115.png"
	},
	{
		info:"Netflix",
		src:"smartHub2014/AppImage/netflix_115.png"
	},
	{
		info:"Amazon",
		src:"smartHub2014/AppImage/amazon_115.png"
	},
	{
		info:"EBS",
		src:"smartHub2014/AppImage/ebs-edu_115.png"
	},
	{
		info:"Cartoo",
		src:"smartHub2014/AppImage/cartoo_115.png"
	},
	{
		info:"Media",
		src:"smartHub2014/AppImage/media_115.png"
	},
	{
		info:"Explorer 3D",
		src:"smartHub2014/AppImage/3D_115.png"
	},
	{
		info:"CNBC",
		src:"smartHub2014/AppImage/cnbc_115.png"
	},
	{
		info:"",
		src:"smartHub2014/AppImage/ad2.png"
	}
	];
	
	var AppInfo = [
	{
		info:"Accuweather",
		src:"smartHub2014/AppImage/accuweather_115.png",
		locked:false
	},
	{
		info:"Adhub",
		src:"smartHub2014/AppImage/adhub_115.png",
		locked:false
	},
	{
		info:"Aolon",
		src:"smartHub2014/AppImage/aolon_115.png",
		locked:false
	},
	{
		info:"Apps",
		src:"smartHub2014/AppImage/apps_115.png",
		locked:false
	},
	{
		info:"Berliner",
		src:"smartHub2014/AppImage/berliner_115.png",
		locked:false
	},
	{
		info:"Bravo",
		src:"smartHub2014/AppImage/bravo_115.png",
		locked:false
	},
	{
		info:"C",
		src:"smartHub2014/AppImage/c_115.png",
		locked:false
	},
	{
		info:"Cameral",
		src:"smartHub2014/AppImage/cameral_115.png",
		locked:false
	},
	{
		info:"CNet",
		src:"smartHub2014/AppImage/cnet_115.png",
		locked:false
	},
	{
		info:"Com2",
		src:"smartHub2014/AppImage/com2_115.png",
		locked:false
	},
	{
		info:"Cyword",
		src:"smartHub2014/AppImage/cyword_115.png",
		locked:false
	},
	{
		info:"EBS-KO",
		src:"smartHub2014/AppImage/ebs_115.png",
		locked:false
	},
	{
		info:"FaceBook",
		src:"smartHub2014/AppImage/facebook_115.png",
		locked:false
	},
	{
		info:"FOX",
		src:"smartHub2014/AppImage/fox_115.png",
		locked:false
	},
	{
		info:"Home",
		src:"smartHub2014/AppImage/home_115.png",
		locked:false
	},
	{
		info:"Kids",
		src:"smartHub2014/AppImage/kids_115.png",
		locked:false
	},
	{
		info:"KY",
		src:"smartHub2014/AppImage/ky_115.png",
		locked:false
	},
	{
		info:"MBN",
		src:"smartHub2014/AppImage/mbn_115.png",
		locked:false
	},
	{
		info:"MP3",
		src:"smartHub2014/AppImage/mp3_115.png",
		locked:false
	},
	{
		info:"Naver",
		src:"smartHub2014/AppImage/naver_115.png",
		locked:false
	},
	{
		info:"Ostrich",
		src:"smartHub2014/AppImage/ostrich_115.png",
		locked:false
	},
	{
		info:"Fitness",
		src:"smartHub2014/AppImage/people_115.png",
		locked:false
	},
	{
		info:"PopStar",
		src:"smartHub2014/AppImage/popstar_115.png",
		locked:false
	},
	{
		info:"TV",
		src:"smartHub2014/AppImage/redtv_115 .png",
		locked:false
	},
	{
		info:"Skype",
		src:"smartHub2014/AppImage/skype_115.png",
		locked:false
	},
	{
		info:"Smart_tip",
		src:"smartHub2014/AppImage/smart_tip_115.png",
		locked:false
	},
	{
		info:"SocialTV",
		src:"smartHub2014/AppImage/socialtv_115.png",
		locked:false
	},
	{
		info:"Star",
		src:"smartHub2014/AppImage/star_115.png",
		locked:false
	},
	{
		info:"Tunein",
		src:"smartHub2014/AppImage/tunein.png",
		locked:false
	},
	{
		info:"TV",
		src:"smartHub2014/AppImage/tv_115.png",
		locked:false
	},
	{
		info:"TVCycle",
		src:"smartHub2014/AppImage/tvcycle_115.png",
		locked:false
	},
	{
		info:"TVing",
		src:"smartHub2014/AppImage/tving_115.png",
		locked:false
	},
	{
		info:"Twitter",
		src:"smartHub2014/AppImage/twitter_115.png",
		locked:false
	},
	{
		info:"Vimeo",
		src:"smartHub2014/AppImage/vimeo_115.png",
		locked:false
	},
	{
		info:"VOD",
		src:"smartHub2014/AppImage/vod_115.png",
		locked:false
	},
	{
		info:"X_Maswish",
		src:"smartHub2014/AppImage/x_maswish_115.png",
		locked:false
	}
	];
	
	var AppIconInfo = [
		{
			src:"smartHub2014/AppImage/apps_icon_sa.png",
		},
		{
			src:"smartHub2014/AppImage/apps_icon_ma.png",
		},
		{
			src:"smartHub2014/AppImage/apps_icon_lock.png",
		},
		{
			src:"smartHub2014/AppImage/apps_btn_refresh_d.png",
		},
		{
			src:"smartHub2014/AppImage/apps_btn_refresh_n.png",
		},
		{
			src:"smartHub2014/AppImage/apps_btn_refresh_s.png",
		},
		{
			src:"smartHub2014/AppImage/apps_check.png",
		},
		{
			src:"smartHub2014/AppImage/apps_check_box.png",
		},
		{
			src:"smartHub2014/AppImage/mm_btn_round.png",
		},
		{
			src:"smartHub2014/AppImage/mm_btn_round_high.png",
		},	
		{
			src:"smartHub2014/AppImage/apps_optbtn_n_left.png",
		},
		{
			src:"smartHub2014/AppImage/apps_optbtn_n_center.png",
		},
		{
			src:"smartHub2014/AppImage/apps_optbtn_n_right.png",
		},
		{
			src:"smartHub2014/AppImage/apps_optbtn_h_left.png",
		},
		{
			src:"smartHub2014/AppImage/apps_optbtn_h_center.png",
		},
		{
			src:"smartHub2014/AppImage/apps_optbtn_h_right.png",
		}
	];
	
	var KeyCode = {
		up:Volt.KEY_JOYSTICK_UP,
		down:Volt.KEY_JOYSTICK_DOWN,
		left:Volt.KEY_JOYSTICK_LEFT,
		right:Volt.KEY_JOYSTICK_RIGHT,
		enter:Volt.KEY_JOYSTICK_OK,
		exit:Volt.KEY_EXIT,
		returnKey:Volt.KEY_RETURN,
		red:Volt.KEY_RED,
		green:Volt.KEY_GREEN,
		yellow:Volt.KEY_YELLOW,
		blue:Volt.KEY_BLUE,
		play:Volt.KEY_PLAY,
		stop:Volt.KEY_STOP,
		pause:Volt.KEY_PAUSE,
		fastForward:72, // Jump Forward
		fastBack:69,     // Back Forward
		info:Volt.KEY_INFO
	}
	
	// Cursor images locations
    options = {
		ninePatch: {
			left: "9patch_img/list_high_mid_left.png",
			right: "9patch_img/list_high_mid_right.png",
			top: "9patch_img/list_high_upper_center.png",
			bottom: "9patch_img/list_high_lower_center.png",
			topLeft: "9patch_img/list_high_upper_left.png",
			topRight: "9patch_img/list_high_upper_right.png",
			bottomRight: "9patch_img/list_high_lower_right.png",
			bottomLeft: "9patch_img/list_high_lower_left.png"
		}
	}
	
	function setTimeout(cb, interval, param) {
		return Volt.setTimeout(cb, interval, param);
	}
	
	function clearTimeout(id){
		if (id !== undefined)  {
			Volt.clearTimeout(id);
		}
	}
	
	function setInterval(cb, interval, param){
		return Volt.setInterval(cb, interval, param);
	}
	
	function clearInterval(id){
		if (id !== undefined) {
			Volt.clearInterval(id);
		}
	}
	
	(function (){ 
		var h=/\b_super\b/,// zhengzebiaodashi
		
			i={};
		function c(l,j){
			return function (){
				var n=this._super,
					m;
				this._super=j;
				m=l.apply(this,arguments);
				if(n){
					this._super=n
				}else {
					delete this._super
				}
				return m
			}
		}
			
		function f(){
			var j=Array.prototype.slice.call(arguments,1);
			return this.extend({
				init:function (){
					var l=Array.prototype.slice.call(arguments,0);
					this._super.apply(this,j.concat(l))
				}
			})
		}
			
		function d(n){
			var m=new this(i),
				l,j,p,o;
			for(l in n){
				j=n.__lookupGetter__(l);
				p=n.__lookupSetter__(l);
				if(j||p){
					j&&m.__defineGetter__(l,j);
					p&&m.__defineSetter__(l,p)
				}else {
					o=n[l];
					if(typeof o ==="function"&&h.test(o)){
						o = c(o,this.prototype[l]||NOOP)
					}
					m[l]=o
				}
			}
			return e(m)
		}
			
		function e(l){  // create the function 
			var j=function (){
				var m=this.init;
				if(m&&arguments[0]!==i){
					m.apply(this,arguments)
				}
			};
			if(l){
				j.prototype=l
			}
			j.constructor =j;
			j.extend=d;
			j.bind=f;
			return j
		}
		
		Class = {// often used interface
			create:e
		}
	})();
	
	var Dynamic_Cursor = Class.create({
		id:"Dynamic_Cursor",
		bCreateInstance:false,
		InstanceRoot:null,
		isHidden:true,
		preStatus:{
	    	width:0,
	    	height:0
	    },
	    adjustment:-16,
		ninePatchInstance:{
			left:null,
			right:null,
			top:null,
			bottom:null,
			topLeft:null,
			topRight:null,
			bottomLeft:null,
			bottomRight:null
		},
		init:function(x, y, width, height, parent){
			
			var self = this;
			var tempCursor = new Widget(0,0);
			tempCursor.color.a = 0;
			
			this.ninePatchInstance = {
				left:null,
				right:null,
				top:null,
				bottom:null,
				topLeft:null,
				topRight:null,
				bottomLeft:null,
				bottomRight:null
			};
			this.preStatus = {width: 0, height: 0};
			
			tempCursor.opacity = 0;
			
			this.InstanceRoot = tempCursor;
			
			var tempInstance = null;
			
			for(var index in options.ninePatch) {
				
				tempInstance = new ImageWidget({src: options.ninePatch[index]});
				
				this.ninePatchInstance[index] = tempInstance;
				tempCursor.addChild(tempInstance);
				tempInstance = null;
			}	
			
			this.bCreateInstance = true;
			
			setTimeout(function(){
				self.initPrestatus(x, y, width, height);
				self.InstanceRoot.parent = parent;
			}, 500)
		},
		
		setParent:function(Parent){
			this.InstanceRoot.parent = Parent;
		},
		
		initPrestatus:function(x, y, width, height){
			this.move(x, y, width, height, 10);
		},
		move:function(x, y, width, height, duration ){
			var self = this;
			var duration = duration || 200;
			
			this.animateDimensions(width, height, duration);
			this.InstanceRoot.animate("x", x, duration);
			this.InstanceRoot.animate("y", y, duration, self.callback);
		},
		
		xPosition:function(xStep){
			this.InstanceRoot.x = xStep;
		},
		
		yPosition:function(yStep){
			this.InstanceRoot.y = yStep;
		},
		
		callback:function(){
			//print("The move action is Finished !!!@@@!!!");
		},
		
		hide:function(){
			this.InstanceRoot.animate("opacity", 0, 100);
		},
		
		show:function(){
			this.InstanceRoot.animate("opacity", 255, 100);
		},
		
		animateDimensions:function(width, height, d){	
			if (this.preStatus.width == width && this.preStatus.height == height) {
				//return;
			}

			var cornerWidth = this.ninePatchInstance.topLeft.width + this.adjustment;
			var cornerHeight = this.ninePatchInstance.topLeft.height + this.adjustment;
		
			this.ninePatchInstance.topLeft.animate("x", -cornerWidth , d); 
			this.ninePatchInstance.topLeft.animate("y", -cornerHeight , d);
		
			this.ninePatchInstance.topRight.animate("x", width + this.adjustment, d);
			this.ninePatchInstance.topRight.animate("y", -cornerHeight , d);
		
			this.ninePatchInstance.bottomRight.animate("x", width + this.adjustment, d); 
			this.ninePatchInstance.bottomRight.animate("y", height + this.adjustment, d);
		
			this.ninePatchInstance.bottomLeft.animate("x", -cornerWidth , d); 
			this.ninePatchInstance.bottomLeft.animate("y", height + this.adjustment, d);
		
			this.ninePatchInstance.left.animate("x",-this.ninePatchInstance.left.width - this.adjustment , d);
			this.ninePatchInstance.left.animate("y", - this.adjustment, d);
		
			this.ninePatchInstance.right.animate("x", width + this.adjustment, d);
			this.ninePatchInstance.right.animate("y", - this.adjustment, d);
		
			this.ninePatchInstance.top.animate("y", -this.ninePatchInstance.top.height - this.adjustment, d);
			this.ninePatchInstance.top.animate("x", -this.adjustment, d);
		
			this.ninePatchInstance.bottom.animate("y", height + this.adjustment, d);
			this.ninePatchInstance.bottom.animate("x", -this.adjustment, d);
		
			//Scale the sides
			this.ninePatchInstance.left.animate("height", height + this.adjustment*2 , d);
			this.ninePatchInstance.right.animate("height", height + this.adjustment*2, d);
			this.ninePatchInstance.top.animate("width", width + this.adjustment*2, d);
			this.ninePatchInstance.bottom.animate("width", width + this.adjustment*2, d);
			
			this.preStatus = {width: width, height: height};
		},
		
		keyHandler:function(keyCode){
			switch(keyCode) {
				
				default:
					print("Unhandler key event");
				return true;
			}
		}
	});
	
	var GridList = Class.create({
		isCreate:false,
		RootInstance:null,
		DataSource:null,
		DataSourceBak:null,
		DataSourceFlag:[],
		isChanged:false,
		ExecuteData:null,
		MoveoutFunction:null,
		CursorInstance:null,
		ItemWidth:0,
		ItemHeight:0,
		ItemSpace:0,
		RowNum:0,
		ColNum:0,
		SelectIndex:0,
		AbsoluteX:0,
		AbsoluteY:0,
		KeyVisible:false,
		ID:null,
		init:function(tmpid,tmpx,tmpy,itemwidth,itemheight,rownum,colnum,space,tmpparent,executedata){
			this.ID=tmpid;
			this.ItemWidth=itemwidth;
			this.ItemHeight=itemheight;
			this.ItemSpace=space;
			this.RowNum=rownum;
			this.ColNum=colnum;
			this.DataSourceFlag=[];
			this.DataSourceBak=[];
			this.ExecuteData=executedata;
			var tmprootwidth =itemwidth*rownum+(rownum-1)*space;
			var tmprootheight =itemheight*colnum+(colnum-1)*space;
			
			var tempRoot = new Widget({
				x:tmpx,
				y:tmpy,
				width:tmprootwidth,
				height:tmprootheight,
				color:{r:0, g:0, b:0, a:0},
				parent:tmpparent
			});
			this.RootInstance = tempRoot;
			
			var tempAbsPos= this.RootInstance.getAbsolutePosition();
			this.AbsoluteX=tempAbsPos.x;
			this.AbsoluteY=tempAbsPos.y;

			this.isCreate=true;	
		},
		active:function(activeIndex){
			var self = this;
			if(this.DataSource){
				if(activeIndex<0)
					this.SelectIndex=0;
				else if(activeIndex >= (this.RowNum*this.ColNum))
					this.SelectIndex=(this.RowNum*this.ColNum)-1;
				else 
					this.SelectIndex=activeIndex;
					
				var temprow= parseInt(this.SelectIndex/this.ColNum);
				var tempcol=this.SelectIndex%this.ColNum;
				var tempx= tempcol*(this.ItemWidth+this.ItemSpace);
				var tempy = temprow*(this.ItemHeight+this.ItemSpace);
				
				if(this.CursorInstance){
					this.CursorInstance.move(this.AbsoluteX+tempx-(this.ItemWidth*0.05/2),this.AbsoluteY+tempy-(this.ItemHeight*0.05/2),this.ItemWidth*1.05,this.ItemHeight*1.05);
					setTimeout(function(){
						if(self.CursorInstance){
							self.CursorInstance.show();
						}
					},200);
				}
				
				this.DataSource[this.SelectIndex].animate("scale",{x:1.05,y:1.05},200,"cubic");
				if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].active();
				}
					
				this.KeyVisible=true;
			}
		},
		deactive:function(){
			if(this.CursorInstance){
				this.CursorInstance.hide();
				this.CursorInstance=null;
			}
			this.KeyVisible=false;
			
			this.DataSource[this.SelectIndex].animate("scale",{x:1.0,y:1.0},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].deactive();
			}
		},
		getLock:function(){
			if(this.DataSourceFlag[this.SelectIndex]){
				return this.DataSourceBak[this.SelectIndex].getLock();
			}
			return false;
		},
		setLock:function(tmpLock){
			if(this.DataSourceFlag[this.SelectIndex]){
				this.DataSourceBak[this.SelectIndex].setLock(tmpLock);
			}
		},
		setEditMode:function(){
			for(var index=0;index<this.DataSourceBak.length;index++){
				this.DataSourceBak[index].setEditMode();
			}
		},
		cancelEditMode:function(){
			for(var index=0;index<this.DataSourceBak.length;index++){
				this.DataSourceBak[index].cancelEditMode();
			}
		},
		getEditCheckStatus:function(){
			if(this.DataSourceFlag[this.SelectIndex]){
				return this.DataSourceBak[this.SelectIndex].getEditCheckStatus();
			}
			return false;
		},
		setEditCheckStatus:function(tmpEditCheckStatus){
			if(this.DataSourceFlag[this.SelectIndex]){
				return this.DataSourceBak[this.SelectIndex].setEditCheckStatus(tmpEditCheckStatus);
			}
		},
		selectAllStatus:function(){
			for(var index=0;index<this.DataSourceBak.length;index++){
				this.DataSourceBak[index].setEditCheckStatus(true);
			}
		},
		deSelectAllStatus:function(){
			for(var index=0;index<this.DataSourceBak.length;index++){
				this.DataSourceBak[index].setEditCheckStatus(false);
			}
		},
		getCheckedIndex:function(){
			var resultArr=[];
			for(var index=0;index<this.DataSourceBak.length;index++){
				if(this.DataSourceBak[index].getEditCheckStatus()){
					resultArr.push(index);
				}
			}
			return resultArr;
		},
		IsEmpty:function(){
			return this.DataSourceFlag[this.SelectIndex];
		},
		setDataSource:function(in_datasource){
			var self = this;
			this.DataSource=in_datasource;
			this.DataSourceBak=[];
			this.DataSourceFlag=[];
			
			if(this.DataSource){	
				var temprow;
				var tempcol;
				var tempx;
				var tempy;
				
				this.RootInstance.destroyChildren();
				
				for(var index=0; index< (this.RowNum*this.ColNum); index++){
					temprow= parseInt(index/this.ColNum);
					tempcol=index%this.ColNum;
					tempx= tempcol*(this.ItemWidth+this.ItemSpace);
					tempy = temprow*(this.ItemHeight+this.ItemSpace);
					
					
					if(index< this.DataSource.length){
						var tempWidget = new Widget({
							x:tempx,
							y:tempy,
							width:(self.ItemWidth),
							height:(self.ItemHeight),
							color:{r:100, g:100, b:100, a:100},
							parent:(self.RootInstance)
						});

						/*this.DataSource[index].getRootInstance().x=tempx;
						this.DataSource[index].getRootInstance().y=tempy;
						this.DataSource[index].setParent(this.RootInstance);*/
						
						this.DataSource[index].getRootInstance().x=0;
						this.DataSource[index].getRootInstance().y=0;
						this.DataSource[index].setParent(tempWidget);
		
						this.DataSourceBak.push(this.DataSource[index]);
						
						this.DataSource[index]=tempWidget
						
						this.DataSourceFlag.push(1);
						
					}else{
						
						var tempWidget = new Widget({
							x:tempx,
							y:tempy,
							width:(self.ItemWidth),
							height:(self.ItemHeight),
							color:{r:100, g:100, b:100, a:100},
							parent:(self.RootInstance)
						});
						this.DataSource.push(tempWidget);
						
						this.DataSourceFlag.push(0);
					}
				}
			}
		},
		setMoveOutFunction:function(in_function){
			this.MoveoutFunction=in_function;
		},
		setCursorInstance:function(in_cursor){
			this.CursorInstance=in_cursor;
			if(this.CursorInstance){
				this.CursorInstance.hide();
			}
		},
		getPopupPos:function(popwidth,popheight){
			var resultPos=[];
			var temprow= parseInt(this.SelectIndex/this.ColNum);
			var tempcol=this.SelectIndex%this.ColNum;
			var tempx= tempcol*(this.ItemWidth+this.ItemSpace);
			var tempy = temprow*(this.ItemHeight+this.ItemSpace);
			
			var posX=0;
			var posY=0;
			if(tempcol<(this.ColNum-3)){
				posX=tempx+this.ItemWidth+this.ItemSpace;
			}
			else{
				posX=(tempx-this.ItemSpace-popwidth);
			}
			
			if(temprow<(this.RowNum-1)){
				posY=tempy;
			}
			else{
				posY=tempy+this.ItemHeight-popheight;
			}
			resultPos.push(posX);
			resultPos.push(posY);
			return resultPos;
		},
		LeftAction:function(){
			var temprow= parseInt(this.SelectIndex/this.ColNum);
			var tempcol=this.SelectIndex%this.ColNum;
			if((this.SelectIndex%this.ColNum)==0){//move out
				this.MoveoutFunction(this,"left",temprow,tempcol,this.ExecuteData);
				return;
			}
			
			//deactive the pre one
			this.DataSource[this.SelectIndex].animate("scale",{x:1.0,y:1.0},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].deactive();
			}
			
			//actoive the next one
			
			this.SelectIndex--;
			temprow= parseInt(this.SelectIndex/this.ColNum);
			tempcol=this.SelectIndex%this.ColNum;
			var tempx= tempcol*(this.ItemWidth+this.ItemSpace);
			var tempy = temprow*(this.ItemHeight+this.ItemSpace);
			
			if(this.CursorInstance){
					this.CursorInstance.move(this.AbsoluteX+tempx-(this.ItemWidth*0.05/2),this.AbsoluteY+tempy-(this.ItemHeight*0.05/2),this.ItemWidth*1.05,this.ItemHeight*1.05);
			}
			
			this.DataSource[this.SelectIndex].animate("scale",{x:1.05,y:1.05},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].active();
			}
		},
		RightAction:function(){
			var temprow= parseInt(this.SelectIndex/this.ColNum);
			var tempcol=this.SelectIndex%this.ColNum;
			if((this.SelectIndex%this.ColNum)==(this.ColNum-1)){//move out
				this.MoveoutFunction(this,"right",temprow,tempcol,this.ExecuteData);
				return;
			}
			
			//deactive the pre one
			this.DataSource[this.SelectIndex].animate("scale",{x:1.0,y:1.0},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].deactive();
			}
	
			//actoive the next one
			
			this.SelectIndex++;
			temprow= parseInt(this.SelectIndex/this.ColNum);
			tempcol=this.SelectIndex%this.ColNum;
			var tempx= tempcol*(this.ItemWidth+this.ItemSpace);
			var tempy = temprow*(this.ItemHeight+this.ItemSpace);
			
			if(this.CursorInstance){
					this.CursorInstance.move(this.AbsoluteX+tempx-(this.ItemWidth*0.05/2),this.AbsoluteY+tempy-(this.ItemHeight*0.05/2),this.ItemWidth*1.05,this.ItemHeight*1.05);
			}
			this.DataSource[this.SelectIndex].animate("scale",{x:1.05,y:1.05},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].active();
			}
		},
		UpAction:function(){
			var temprow= parseInt(this.SelectIndex/this.ColNum);
			var tempcol=this.SelectIndex%this.ColNum;
			if( temprow == 0 ){//move out
				this.MoveoutFunction(this,"up",temprow,tempcol,this.ExecuteData);
				return;
			}
			
			//deactive the pre one
			
			this.DataSource[this.SelectIndex].animate("scale",{x:1.0,y:1.0},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].deactive();
			}
			
			//actoive the next one
			
			this.SelectIndex=this.SelectIndex-this.ColNum;
			temprow= parseInt(this.SelectIndex/this.ColNum);
			tempcol=this.SelectIndex%this.ColNum;
			var tempx= tempcol*(this.ItemWidth+this.ItemSpace);
			var tempy = temprow*(this.ItemHeight+this.ItemSpace);
			
			if(this.CursorInstance){
					this.CursorInstance.move(this.AbsoluteX+tempx-(this.ItemWidth*0.05/2),this.AbsoluteY+tempy-(this.ItemHeight*0.05/2),this.ItemWidth*1.05,this.ItemHeight*1.05);
			}
			
			this.DataSource[this.SelectIndex].animate("scale",{x:1.05,y:1.05},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].active();
			}
		},
		DownAction:function(){
			
			var temprow= parseInt(this.SelectIndex/this.ColNum);
			var tempcol=this.SelectIndex%this.ColNum;
			if( temprow == (this.RowNum-1) ){//move out
				this.MoveoutFunction(this,"down",temprow,tempcol,this.ExecuteData);
				return;
			}
			
			//deactive the pre one
			
			this.DataSource[this.SelectIndex].animate("scale",{x:1.0,y:1.0},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].deactive();
			}
			
			//actoive the next one
			
			this.SelectIndex=this.SelectIndex+this.ColNum;
			
			temprow= parseInt(this.SelectIndex/this.ColNum);
			tempcol=this.SelectIndex%this.ColNum;
			var tempx= tempcol*(this.ItemWidth+this.ItemSpace);
			var tempy = temprow*(this.ItemHeight+this.ItemSpace);
			
			if(this.CursorInstance){
					this.CursorInstance.move(this.AbsoluteX+tempx-(this.ItemWidth*0.05/2),this.AbsoluteY+tempy-(this.ItemHeight*0.05/2),this.ItemWidth*1.05,this.ItemHeight*1.05);
			}
			
			this.DataSource[this.SelectIndex].animate("scale",{x:1.05,y:1.05},200,"cubic");
			if(this.DataSourceFlag[this.SelectIndex]){
					this.DataSourceBak[this.SelectIndex].active();
			}
		},
		keyHandler:function(keycode){
			var self=this;
			if (this.KeyVisible == false) {
				return false;
			}
			switch(keycode) {
				case KeyCode.enter:
					{
					}
					break;
				case KeyCode.returnKey:
					{	
					}
					break;
				case KeyCode.left:
					{	
						this.LeftAction();
						return true;
					}
					break;
				case KeyCode.right:
					{
						this.RightAction();
						return true;
					}
					break;
				case KeyCode.up:
					{	
						this.UpAction();
						return true;
					}
					break;
				case KeyCode.down:
					{
						this.DownAction();
						return true;
					}
					break;
				case KeyCode.exit:
					{
					}
					break;
				default:
					break;
			}
			
			return false;
		}
	});
	
	var APPItem = Class.create({
		isCreate:false,
		RootInstance:null,
		ImageInstance:null,
		TextInstance:null,
		UpInstance:null,
		EditAble:false,
		IsLocked:false,
		LockFlagInstance:null,
		EditMode:false,
		EditButtonInstance:null,
		EditCheckStatus:false,
		EditCheckInstance:null,
		init:function(tmpx,tmpy,itemwidth,itemheight,upspace,imagesrc,imagewidth,imageheight,downspace,imagetext,textfont,editable,templock){
			 
			this.EditAble=editable;
			this.IsLocked=templock;
			
			var tempRoot = new Widget({
				x:tmpx,
				y:tmpy,
				width:itemwidth,
				height:itemheight,
				color:{r:0, g:0, b:0, a:0}
			});
			this.RootInstance = tempRoot;
			
			if(this.EditAble)
			{
				var tempUpInstace = new Widget({
					x:(itemwidth-60)/2,
					y:0,
					width:60,
					height:upspace,
					color:{r:0, g:0, b:0, a:0},
					parent:tempRoot
				});
				tempUpInstace.depth=0.1
				this.UpInstance = tempUpInstace;
				this.UpInstance.hide();
				
				var tempsa = new ImageWidget({
					x:0,
					y:0,
					width:20,
					height:upspace,
					src:AppIconInfo[0].src,
					parent:tempUpInstace
				});
				
				var tempma = new ImageWidget({
					x:20,
					y:0,
					width:20,
					height:upspace,
					src:AppIconInfo[1].src,
					parent:tempUpInstace
				});
				
				var templock = new ImageWidget({
					x:40,
					y:0,
					width:20,
					height:upspace,
					src:AppIconInfo[2].src,
					parent:tempUpInstace
				});
				this.LockFlagInstance=templock;
			}
			
			var tempImageInstance =new ImageWidget({
				x:(itemwidth-imagewidth)/2,
				y:upspace,
				width:imagewidth,
				height:imageheight,
				src:imagesrc,
				parent:tempRoot
			});
			tempImageInstance.depth=0.1;
			this.ImageInstance=tempImageInstance;
			
			var tempTextInstance = new TextWidget({
				x:0,
				y:(upspace+imageheight+downspace),
				width:itemwidth,
				height:(itemheight-(upspace+imageheight+downspace)),
				parent:tempRoot
			});
			tempTextInstance.text=imagetext;
			tempTextInstance.horizontalAlignment = "center";
			tempTextInstance.verticalAlignment = "top";
			tempTextInstance.font = textfont;
			this.TextInstance=tempTextInstance;
			
			
			this.isCreate=true;
		},
		getRootInstance:function(){
			return this.RootInstance;
		},
		setParent:function(tmpParent){
			this.RootInstance.parent=tmpParent;
		},
		getLock:function(){
			return this.IsLocked;
		},
		setLock:function(tmplock){
			if(tmplock){
				if(this.EditAble){
					this.LockFlagInstance.show();
					this.IsLocked=tmplock;
				}
			}
			else{
				if(this.EditAble){
					this.LockFlagInstance.hide();
					this.IsLocked=tmplock;
				}
			}
		},
		setEditMode:function(){
			if(this.EditAble){
				this.UpInstance.hide();
			}
			this.EditMode=true;
			if(!this.IsLocked){
				if(!this.EditButtonInstance){
					var tempEditButtonInstance = new ImageWidget({
						x:5,
						y:0,
						width:30,
						height:30,
						src:AppIconInfo[7].src,
						parent:this.RootInstance
					});
					tempEditButtonInstance.depth=0.1;
					this.EditButtonInstance=tempEditButtonInstance;
				}
				else{
					this.EditButtonInstance.show();
				}
				if(this.EditCheckInstance){
					this.EditCheckInstance.hide();
				}
			}
		},
		getEditCheckStatus:function(){
			return this.EditCheckStatus;
		},
		setEditCheckStatus:function(tmpEditCheckStatus){
			if(!this.IsLocked){
				this.EditCheckStatus=tmpEditCheckStatus;
				if(!this.EditCheckInstance){
					var tempEditCheckInstance = new ImageWidget({
						x:0,
						y:0,
						width:30,
						height:30,
						src:AppIconInfo[6].src,
						parent:this.EditButtonInstance
					});
					tempEditCheckInstance.depth=0.1;
					this.EditCheckInstance=tempEditCheckInstance;
				}
				if(tmpEditCheckStatus){
					this.EditCheckInstance.show();
				}
				else{
					this.EditCheckInstance.hide();
				}
			}	
		},
		cancelEditMode:function(){
			this.EditMode=false;
			
			if(!this.IsLocked){
				this.EditButtonInstance.hide();
				this.EditCheckStatus=false;
			}
		},
		active:function(){
			if(!this.EditMode){
				if(this.EditAble){
					this.UpInstance.show();
					if(!this.IsLocked){
						this.LockFlagInstance.hide();
					}
				}
			}
			else{
				if(!this.IsLocked){
					this.EditButtonInstance.show();
					if(this.EditCheckInstance){
						if(this.EditCheckStatus){
							this.EditCheckInstance.show();
						}
						else{
							this.EditCheckInstance.hide();
						}
					}
				}
			}
			this.TextInstance.color={r:200,g:200,b:0,a:255};
		},
		deactive:function(){
			if(this.EditAble){
				this.UpInstance.hide();
			}
			this.TextInstance.color={r:255,g:255,b:255,a:255};
		}
	});
	
	var PopMsgBox = Class.create({
		isCreate:false,
		KeyVisible:false,
		RootInstance:null,
		TextCount:0,
		UpSpace:0,
		DownSpace:0,
		ChildrenInstances:[],
		CursorInstance:null,
		BoxWidth:0,
		ItemHeight:0,
		BoxX:0,
		BoxY:0,
		SelectIndex:0,
		OldSelectIndex:0,
		init:function(tmpx,tmpy,tmpwidth,upspace,downspace,itemheight,textarr,textfont,tmpParent){
			this.BoxX=tmpx;
			this.BoxY=tmpy;
			this.TextCount=textarr.length;
			this.UpSpace=upspace;
			this.DownSpace=downspace;
			this.ChildrenInstances=[];
			this.BoxWidth=tmpwidth;
			this.ItemHeight=itemheight;
			var tmpheight = upspace+(textarr.length)*itemheight+downspace;
			var temproot = new Widget({
				x:tmpx,
				y:tmpy,
				width:tmpwidth,
				height:tmpheight,
				color:{r:10,g:10,b:10,a:255},
				parent:tmpParent
			});
			temproot.depth = 0.2;
			temproot.border = {width:1,color:{r:100,g:100,b:100,a:255}};
			this.RootInstance = temproot;
			
			for(var index=0;index<textarr.length;index++){
				var childy = upspace+index*itemheight;
				var tempchild = new TextWidget({
					x:35,
					y:childy,
					width:tmpwidth-60,
					height:itemheight,
					parent:temproot
				});
				tempchild.text=textarr[index];
				tempchild.horizontalAlignment = "left";
				tempchild.verticalAlignment = "center";
				tempchild.font = textfont;
				this.ChildrenInstances.push(tempchild);
			}
			this.SelectIndex=0;
			this.OldSelectIndex=0;
			
			var tmpx=this.BoxX+25;
			var tmpy=this.BoxY+this.UpSpace+this.SelectIndex*this.ItemHeight;
			var tmpwidth=this.BoxWidth-50;
			var tmpheight=this.ItemHeight;
			this.CursorInstance=new Dynamic_Cursor(tmpx,tmpy,tmpwidth,tmpheight,scene);
			//this.CursorInstance.hide();
			
			this.isCreate=true;
		},
		active:function(){
			var self = this;
			if(this.CursorInstance){
				setTimeout(function(){
					if(self.CursorInstance){
						self.CursorInstance.show();
					}
				},500);
			}
			this.ChildrenInstances[this.SelectIndex].color={r:200,g:200,b:0,a:255};
			this.KeyVisible=true;
		},
		moveCursor:function(){
			if(this.CursorInstance){
				var tmpx=this.BoxX+25;
				var tmpy=this.BoxY+this.UpSpace+this.SelectIndex*this.ItemHeight;
				var tmpwidth=this.BoxWidth-50;
				var tmpheight=this.ItemHeight;
				this.CursorInstance.move(tmpx,tmpy,tmpwidth,tmpheight);
			}
			this.ChildrenInstances[this.OldSelectIndex].color={r:255,g:255,b:255,a:255};
			this.ChildrenInstances[this.SelectIndex].color={r:200,g:200,b:0,a:255};
		},
		destroy:function(){
			if(this.CursorInstance){
				this.CursorInstance.hide();
				this.CursorInstance.InstanceRoot.destroy();
				this.CursorInstance=null;
			}
			this.KeyVisible=false;
			
			this.RootInstance.destroy();
		},
		keyHandler:function(keycode){
			var self=this;
			if (this.KeyVisible == false) {
				return false;
			}
			switch(keycode) {
				case KeyCode.enter:
					{
					}
					break;
				case KeyCode.returnKey:
					{	
					}
					break;
				case KeyCode.up:
					{	
						if((this.SelectIndex-1)<0){
							return true;
						}
						this.OldSelectIndex = this.SelectIndex;
						this.SelectIndex--;
						this.moveCursor();
						return true;
					}
					break;
				case KeyCode.down:
					{	
						if((this.SelectIndex+1)>=this.TextCount){
							return true;
						}
						this.OldSelectIndex = this.SelectIndex;
						this.SelectIndex++;
						this.moveCursor();
						return true;
					}
					break;
				default:
					break;
			}
			return false;
		}
	});
	
	var APP_Panel = Class.create({
		isCreate:false,
		RootInstance:null,
		RecommendedList:null,
		RecommendedDataSource:[],
		MyAppsList:null,
		MyAppsDataSource:[],
		AppCursor:null,
		KeyVisible:false,
		PageCount:0,
		CurrentPageIndex:0,
		RecommendedTextInstance:null,
		MyAppsTextInstance:null,
		SmartTVInstance:null,
		UpdateAppsInstance:null,
		UpdateAppsSrc:null,
		UpdateAble:false,
		DownLineButtonsInstance:null,
		DownLineButtonsSelect:null,
		MostPopularInstance:null,
		WhatNewInstance:null,
		CategoriesInstance:null,
		HelpInstanceInstance:null,
		HelpInstanceSrc:null,
		CurrentMode:0, //0 : mostpopular  1:what's new  2: categories
		SelectIndex:0,
		PopMsgBoxInstance:null,
		PopupTextArr:null,
		EditMode:false,
		EditBodyInstance:null,
		EditDeleteInstance:null,
		EditCancelInstance:null,
		EditSelectAllInstance:null,
		EditDeSelectAllInstance:null,
		UpBodyInstance:null,
		DownBodyInstance:null,
		APPTitleTextInstance:null,
		init:function(){
			this.RecommendedDataSource=[];
			this.MyAppsDataSource=[];
			
			this.PopupTextArr=[];
			this.PopupTextArr.push("Delete");
			this.PopupTextArr.push("Multi Delete");
			this.PopupTextArr.push("Lock/Unlock");
			
			
			this.PageCount=parseInt(AppInfo.length/30);
			if((AppInfo.length%30)>0){
				this.PageCount++;
			}
			this.CurrentPageIndex=0;
			
			var tempRoot = new Widget({
				x:0,
				y:0,
				width:1920,
				height:1080,
				color:{r:0, g:0, b:0, a:0},
				drawWithDepth:true,
				parent:scene
			});
			this.RootInstance = tempRoot;
			
			var tempUpBodyInstance = new Widget({
				x:0,
				y:0,
				width:1920,
				height:1080,
				color:{r:0, g:0, b:0, a:0},
				drawWithDepth:true,
				parent:tempRoot
			});
			this.UpBodyInstance = tempUpBodyInstance;
			
			var tempDownBodyInstance = new Widget({
				x:0,
				y:0,
				width:1920,
				height:1080,
				color:{r:0, g:0, b:0, a:0},
				drawWithDepth:true,
				parent:tempRoot
			});
			this.DownBodyInstance = tempDownBodyInstance;
			
			var tempAPPTitleTextInstance = new TextWidget({
				x:40,
				y:30,
				width:150,
				height:50,
				color:{r:0, g:200, b:200, a:255},
				parent:tempUpBodyInstance
			});
			tempAPPTitleTextInstance.text="APPS";
			tempAPPTitleTextInstance.horizontalAlignment = "left";
			tempAPPTitleTextInstance.font="Helvetica 46px";
			tempAPPTitleTextInstance.verticalAlignment = "center";
			this.APPTitleTextInstance=tempAPPTitleTextInstance;
			
			
			var tempRecommendedText = new TextWidget({
				x:110,
				y:123,
				width:460,
				height:36,
				color:{r:0, g:200, b:200, a:178},
				parent:tempUpBodyInstance
			});
			tempRecommendedText.text="RECOMMENDED";
			tempRecommendedText.horizontalAlignment = "left";
			tempRecommendedText.font="Helvetica 32px";
			tempRecommendedText.verticalAlignment = "center";
			this.RecommendedTextInstance=tempRecommendedText;
			
			this.RecommendedList = new GridList("recommendedlist",110,164,160,186,1,8,10,this.UpBodyInstance,this);
			for(var index= 0; index<8;index++){
				var tempItem = new APPItem(0,0,160,186,30,AppRecommendInfo[index].src,115,95,15,AppRecommendInfo[index].info,"Helvetica 25px",false,false);
				this.RecommendedDataSource.push(tempItem);
			}
			this.RecommendedList.setDataSource(this.RecommendedDataSource);
			this.RecommendedList.setMoveOutFunction(this.MoveoutFunction);
			
			
			var tempSmartTVInstance = new ImageWidget({
				x:1470,
				y:164,
				width:330,
				height:186,
				src:AppRecommendInfo[8].src,
				parent:tempUpBodyInstance
			});
			this.SmartTVInstance=tempSmartTVInstance;
			
			var tempUpdateAppsInstance = new ImageWidget({
				x:102,
				y:351,
				width:74,
				height:74,
				parent:tempUpBodyInstance
			});
			this.UpdateAppsInstance=tempUpdateAppsInstance;
			if(this.PageCount<2){
				this.UpdateAble=false;
				this.UpdateAppsInstance.src=AppIconInfo[3].src;
				this.UpdateAppsSrc==AppIconInfo[3].src;
			}
			else{
				this.UpdateAble=true;
				this.UpdateAppsInstance.src=AppIconInfo[4].src;
				this.UpdateAppsSrc=AppIconInfo[4].src;
			}
			
			
			var tempMyAppsText = new TextWidget({
				x:176,
				y:370,
				width:460,
				height:36,
				color:{r:0, g:200, b:200, a:178},
				parent:tempUpBodyInstance
			});
			tempMyAppsText.text="MY APPS ("+(this.CurrentPageIndex+1)+"/"+this.PageCount+")";
			tempMyAppsText.horizontalAlignment = "left";
			tempMyAppsText.verticalAlignment = "center";
			tempMyAppsText.font="Helvetica 32px";
			this.MyAppsTextInstance=tempMyAppsText;
			
			this.MyAppsList = new GridList("myapplist",110,429,160,166,3,10,10,this.UpBodyInstance,this);
			this.MyAppsDataSource=this.getAppDataSource();
			this.MyAppsList.setDataSource(this.MyAppsDataSource);
			this.MyAppsList.setMoveOutFunction(this.MoveoutFunction);
			
			//init the buttons
			var tempDownLineButtons = new Widget({
				x:510,
				y:1000,
				width:900,
				height:80,
				parent:tempDownBodyInstance,
				color:{r:0, g:0, b:0, a:0}
			});
			this.DownLineButtonsInstance=tempDownLineButtons;
			
			tempDownLineButtonsSelect = new Widget({
				x:20,
				y:80,
				width:260,
				height:80,
				parent:tempDownLineButtons,
				color:{r:0, g:200, b:200, a:20}
			});
			this.DownLineButtonsSelect=tempDownLineButtonsSelect;
			this.DownLineButtonsSelect.hide();
			
			var tempMostPopular = new TextWidget({
				x:0,
				y:0,
				width:300,
				height:80,
				parent:tempDownLineButtons
			});
			tempMostPopular.text="Most Popular"
			tempMostPopular.horizontalAlignment = "center";
			tempMostPopular.verticalAlignment = "center";
			tempMostPopular.font="Helvetica 32px";
			this.MostPopularInstance=tempMostPopular;
			
			var tempLine = new Widget({
				x:300,
				y:25,
				width:1,
				height:30,
				parent:tempDownLineButtons,
				color:{r:80, g:80, b:80, a:255}
			});
			
			var tempWhatNew = new TextWidget({
				x:300,
				y:0,
				width:300,
				height:80,
				parent:tempDownLineButtons
			});
			tempWhatNew.text="What's New";
			tempWhatNew.horizontalAlignment = "center";
			tempWhatNew.verticalAlignment = "center";
			tempWhatNew.font="Helvetica 32px";
			this.WhatNewInstance=tempWhatNew;
			
			tempLine = new Widget({
				x:600,
				y:25,
				width:1,
				height:30,
				parent:tempDownLineButtons,
				color:{r:80, g:80, b:80, a:255}
			});
			
			var tempCategories = new TextWidget({
				x:600,
				y:0,
				width:300,
				height:80,
				parent:tempDownLineButtons
			});
			tempCategories.text="Categories";
			tempCategories.horizontalAlignment = "center";
			tempCategories.verticalAlignment = "center";
			tempCategories.font="Helvetica 32px";
			this.CategoriesInstance=tempCategories;
			
			
			//init the ?
			var tempHelpInstance = new ImageWidget({
				x:12,
				y:1012,
				width:54,
				height:54,
				parent:tempDownBodyInstance,
				src:AppIconInfo[8].src
			});
			this.HelpInstanceInstance=tempHelpInstance;
			this.HelpInstanceSrc=AppIconInfo[8].src;
			var tempHelpText = new TextWidget({
				x:0,
				y:0,
				width:54,
				height:54,
				parent:tempHelpInstance
			});
			tempHelpText.text="?"
			tempHelpText.horizontalAlignment = "center";
			tempHelpText.verticalAlignment = "center";
			tempHelpText.font="Helvetica 32px";
			
			
			this.AppCursor = new Dynamic_Cursor(110,164,160,186,tempUpBodyInstance);
			
			this.AppCursor.InstanceRoot.depth=0.5;
			//this.RecommendedList.setCursorInstance(this.AppCursor);
			//this.RecommendedList.active(0);
			
			this.KeyVisible=true;
			this.isCreate=true;
		},
		destroy:function(){
			this.RootInstance.destroy();
		},
		getRoot:function(){
			return this.RootInstance;
		},
		getAppDataSource:function(){
			this.PageCount=parseInt(AppInfo.length/30);
			if((AppInfo.length%30)>0){
				this.PageCount++;
			}
			
			if(this.PageCount<2){
				this.UpdateAble=false;
				this.UpdateAppsInstance.src=AppIconInfo[3].src;
				this.UpdateAppsSrc==AppIconInfo[3].src;
			}
			else{
				this.UpdateAble=true;
				this.UpdateAppsInstance.src=AppIconInfo[4].src;
				this.UpdateAppsSrc=AppIconInfo[4].src;
			}
			
			if(this.CurrentPageIndex >= (this.PageCount)){
				this.CurrentPageIndex--;
				if(this.CurrentPageIndex<0){
					this.CurrentPageIndex=0;
				}
			}
			this.MyAppsTextInstance.text="MY APPS("+(this.CurrentPageIndex+1)+"/"+this.PageCount+")";
			
			if(AppInfo.length==0){
				this.MyAppsTextInstance.text="MY APPS(0/0)";
				return [];
			}
			var tempCount=0;
			var tempArray=[];
			for(var index= this.CurrentPageIndex*30; index<AppInfo.length && tempCount<30;index++,tempCount++){
				var tempItem = new APPItem(0,0,160,166,30,AppInfo[index].src,115,95,10,AppInfo[index].info,"Helvetica 25px",true,AppInfo[index].locked);
				tempArray.push(tempItem);
			}
			return tempArray;
		},
		activePage:function(direct,index){
			this.KeyVisible=true;
			var self = this;
			if(direct=="up"){
				this.RecommendedList.setCursorInstance(this.AppCursor);
				this.RecommendedList.active(0);
				this.SelectIndex=0;
			}
			else if(direct=="left"){
				if(index==0){
					this.RecommendedList.setCursorInstance(this.AppCursor);
					this.RecommendedList.active(0);
					this.SelectIndex=0;
				}
				else if(index >0 && index < 4){
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active((index-1)*10);
					this.SelectIndex=3;
				}
				else{
					this.HelpInstanceInstance.src=AppIconInfo[9].src;
					this.SelectIndex=4;
				}
			}
			else if(direct=="right"){
				if(index==0){
					this.AppCursor.move(1462,160,347,195);
					setTimeout(function(){
						if(self.AppCursor){
							self.AppCursor.show();
						}
					},200);
					this.SmartTVInstance.animate("scale",{x:1.05,y:1.05},200,"cubic");
					this.SelectIndex=1;
				}
				else if(index >0 && index < 4){
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active((index-1)*10+9);
					this.SelectIndex=3;
				}
				else{
					this.DownLineButtonsSelect.x=620;
					this.DownLineButtonsSelect.animate("y",0,200,"cubic");
					this.DownLineButtonsSelect.show()
					this.SelectIndex=7;
				}
			}
			else{
			}
		},
		deactivePage:function(){
			this.KeyVisible=false;
		},
		MoveoutFunction:function(GridObject,direction,temprow,tempcol,ExecuteData){
			
		},
		MoveoutOfPanel:function(direction,temprow,tempcol,ExecuteData){
			//
			this.KeyVisible=false;
			var tmpapppanel=ExecuteData;
			if(tmpapppanel.CurrentMode==0){ //most popular
				tmpapppanel.SelectIndex=-1;
			}
		},
		LeftAction:function(){
			if(!this.EditMode){
				if(this.SelectIndex==1){
					this.AppCursor.hide();
					this.SmartTVInstance.animate("scale",{x:1.0,y:1.0},200,"cubic");
					this.RecommendedList.setCursorInstance(this.AppCursor);
					this.RecommendedList.active(7);
					this.SelectIndex=0;
				}
				else if(this.SelectIndex==2){
					this.UpdateAppsInstance.src=this.UpdateAppsSrc;
					this.MoveoutOfPanel("left",0,0,this);
				}
				else if(this.SelectIndex==4){
					this.HelpInstanceInstance.src=this.HelpInstanceSrc;
					this.MoveoutOfPanel("left",5,0,this);
				}
				else if(this.SelectIndex==5){
					this.DownLineButtonsSelect.animate("y",80,200,"cubic");
					this.HelpInstanceInstance.src=AppIconInfo[9].src;
					this.SelectIndex=4;
				}
				else if(this.SelectIndex==6){
					this.DownLineButtonsSelect.animate("x",20,200,"cubic");
					this.SelectIndex=5;
				}
				else if(this.SelectIndex==7){
					this.DownLineButtonsSelect.animate("x",320,200,"cubic");
					this.SelectIndex=6;
				}
			}
			else{
				if(this.SelectIndex==4){
				}
				else if(this.SelectIndex==5){
					this.EditCancelInstance.src=AppIconInfo[11].src;
					this.SelectIndex=4;
					this.EditDeleteInstance.src=AppIconInfo[13].src;
				}
				else if(this.SelectIndex==6){
					this.EditSelectAllInstance.src=AppIconInfo[11].src;
					this.SelectIndex=5;
					this.EditCancelInstance.src=AppIconInfo[14].src;
				}
				else if(this.SelectIndex==7){
					this.EditDeSelectAllInstance.src=AppIconInfo[12].src;
					this.SelectIndex=6;
					this.EditSelectAllInstance.src=AppIconInfo[14].src;
				}
				else{
				}
			}
		},
		RightAction:function(){
			if(!this.EditMode){
				if(this.SelectIndex==1){
					this.AppCursor.hide();
					this.SmartTVInstance.animate("scale",{x:1.0,y:1.0},200,"cubic");
					this.MoveoutOfPanel("right",0,8,this);
				}
				else if(this.SelectIndex==2){
				}
				else if(this.SelectIndex==4){
					this.HelpInstanceInstance.src=this.HelpInstanceSrc;
					this.DownLineButtonsSelect.x=20;
					this.DownLineButtonsSelect.animate("y",0,200,"cubic");
					this.SelectIndex=5;
				}
				else if(this.SelectIndex==5){
					this.DownLineButtonsSelect.animate("x",320,200,"cubic");
					this.SelectIndex=6;
				}
				else if(this.SelectIndex==6){
					this.DownLineButtonsSelect.animate("x",620,200,"cubic");
					this.SelectIndex=7;
				}
				else if(this.SelectIndex==7){
					this.DownLineButtonsSelect.animate("y",80,200,"cubic");
					this.MoveoutOfPanel("right",4,3,this);
				}
			}
			else{
				if(this.SelectIndex==4){
					this.EditDeleteInstance.src=AppIconInfo[10].src;
					this.SelectIndex=5;
					this.EditCancelInstance.src=AppIconInfo[14].src;
				}
				else if(this.SelectIndex==5){
					this.EditCancelInstance.src=AppIconInfo[11].src;
					this.SelectIndex=6;
					this.EditSelectAllInstance.src=AppIconInfo[14].src;
				}
				else if(this.SelectIndex==6){
					this.EditSelectAllInstance.src=AppIconInfo[11].src;
					this.SelectIndex=7;
					this.EditDeSelectAllInstance.src=AppIconInfo[15].src;
				}
				else if(this.SelectIndex==7){
				}
				else{
				}
			}
		},
		UpAction:function(){
			if(!this.EditMode){
				if(this.SelectIndex==1){
					this.AppCursor.hide();
					this.SmartTVInstance.animate("scale",{x:1.0,y:1.0},200,"cubic");
					this.MoveoutOfPanel("up",0,8,this);
				}
				else if(this.SelectIndex==2){
					this.UpdateAppsInstance.src=this.UpdateAppsSrc;
					this.RecommendedList.setCursorInstance(this.AppCursor);
					this.RecommendedList.active(0);
					this.SelectIndex=0;
				}
				else if(this.SelectIndex==4){
					this.HelpInstanceInstance.src=this.HelpInstanceSrc;
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(20);
					this.SelectIndex=3;
				}
				else if(this.SelectIndex==5){
					this.DownLineButtonsSelect.animate("y",80,200,"cubic");
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(23);
					this.SelectIndex=3;
				}
				else if(this.SelectIndex==6){
					this.DownLineButtonsSelect.animate("y",80,200,"cubic");
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(24);
					this.SelectIndex=3;
				}
				else if(this.SelectIndex==7){
					this.DownLineButtonsSelect.animate("y",80,200,"cubic");
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(26);
					this.SelectIndex=3;
				}
			}
			else{
				if(this.SelectIndex==4){
					this.EditDeleteInstance.src=AppIconInfo[10].src;
					this.SelectIndex=3;
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(22);
				}
				else if(this.SelectIndex==5){
					this.EditCancelInstance.src=AppIconInfo[11].src;
					this.SelectIndex=3;
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(24);
				}
				else if(this.SelectIndex==6){
					this.EditSelectAllInstance.src=AppIconInfo[11].src;
					this.SelectIndex=3;
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(26);
				}
				else if(this.SelectIndex==7){
					this.EditDeSelectAllInstance.src=AppIconInfo[12].src;
					this.SelectIndex=3;
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(27);
				}
				else{
				}
			}
		},
		DownAction:function(){
			if(!this.EditMode){
				if(this.SelectIndex==1){
					this.AppCursor.hide();
					this.SmartTVInstance.animate("scale",{x:1.0,y:1.0},200,"cubic");
					//this.UpdateAppsInstance.src=AppIconInfo[5].src;
					//this.SelectIndex=2;
					
					if(this.UpdateAble){
						this.UpdateAppsInstance.src=AppIconInfo[5].src;
						this.SelectIndex=2;
					}
					else{
						this.MyAppsList.setCursorInstance(this.AppCursor);
						this.MyAppsList.active(8);
						this.SelectIndex=3;
					}
				}
				else if(this.SelectIndex==2){
					this.UpdateAppsInstance.src=this.UpdateAppsSrc;
					this.MyAppsList.setCursorInstance(this.AppCursor);
					this.MyAppsList.active(0);
					this.SelectIndex=3;
				}
				else if(this.SelectIndex==4){
				}
				else if(this.SelectIndex==5){
				}
				else if(this.SelectIndex==6){
				}
				else if(this.SelectIndex==7){
				}
			}
			else{
				if(this.SelectIndex==4){
				}
				else if(this.SelectIndex==5){
				}
				else if(this.SelectIndex==6){
				}
				else if(this.SelectIndex==7){
				}
				else{
				}
			}
		},
		activeEditButton:function(){
			this.DownLineButtonsInstance.hide();
			this.HelpInstanceInstance.hide();
			if(!this.EditBodyInstance){
				var tempEditBodyInstance = new Widget({
					x:463,
					y:981,
					width:1016,
					height:86,
					color:{r:0, g:0, b:0, a:0},
					parent:this.RootInstance
				});
				this.EditBodyInstance=tempEditBodyInstance;
				//delete
				var tempEditDeleteInstance = new ImageWidget({
					x:0,
					y:0,
					width:260,
					height:86,
					src:AppIconInfo[10].src,
					parent:tempEditBodyInstance
				});
				this.EditDeleteInstance = tempEditDeleteInstance;
				
				var tempEditDeleteText = new TextWidget({
					x:0,
					y:0,
					width:260,
					height:86,
					parent:tempEditDeleteInstance
				});
				//tempEditDeleteText.depth=0.2;
				tempEditDeleteText.text="Delete";
				tempEditDeleteText.horizontalAlignment = "center";
				tempEditDeleteText.verticalAlignment = "center";
				tempEditDeleteText.font="Helvetica 32px";
				
				//cancel
				var tempEditCancelInstance = new ImageWidget({
					x:260,
					y:0,
					width:248,
					height:86,
					src:AppIconInfo[11].src,
					parent:tempEditBodyInstance
				});
				this.EditCancelInstance = tempEditCancelInstance;
				
				var tempEditCancelText = new TextWidget({
					x:0,
					y:0,
					width:248,
					height:86,
					parent:tempEditCancelInstance
				});
				//tempEditCancelText.depth=0.1;
				tempEditCancelText.text="Cancel";
				tempEditCancelText.horizontalAlignment = "center";
				tempEditCancelText.verticalAlignment = "center";
				tempEditCancelText.font="Helvetica 32px";

				//select all
				var tempEditSelectAllInstance = new ImageWidget({
					x:508,
					y:0,
					width:248,
					height:86,
					src:AppIconInfo[11].src,
					parent:tempEditBodyInstance
				});
				this.EditSelectAllInstance = tempEditSelectAllInstance;
				
				var tempEditSelectAllText = new TextWidget({
					x:0,
					y:0,
					width:248,
					height:86,
					parent:tempEditSelectAllInstance
				});
				//tempEditSelectAllText.depth=0.1;
				tempEditSelectAllText.text="Select All";
				tempEditSelectAllText.horizontalAlignment = "center";
				tempEditSelectAllText.verticalAlignment = "center";
				tempEditSelectAllText.font="Helvetica 32px";
				
				
				//deselect all
				var tempEditDeSelectAllInstance = new ImageWidget({
					x:756,
					y:0,
					width:260,
					height:86,
					src:AppIconInfo[12].src,
					parent:tempEditBodyInstance
				});
				this.EditDeSelectAllInstance = tempEditDeSelectAllInstance;
				
				var tempDeSelectAllText = new TextWidget({
					x:0,
					y:0,
					width:260,
					height:86,
					parent:tempEditDeSelectAllInstance
				});
				//tempDeSelectAllText.depth=0.1;
				tempDeSelectAllText.text="Deselect All";
				tempDeSelectAllText.horizontalAlignment = "center";
				tempDeSelectAllText.verticalAlignment = "center";
				tempDeSelectAllText.font="Helvetica 32px";
			}
			else{
				this.EditBodyInstance.show();
			}
		},
		deactiveEditButton:function(){
			this.DownLineButtonsInstance.show();
			this.HelpInstanceInstance.show();	
			this.EditBodyInstance.hide();
			this.EditDeleteInstance.src=AppIconInfo[10].src;
			this.EditCancelInstance.src=AppIconInfo[11].src;
			this.EditSelectAllInstance.src=AppIconInfo[11].src;
			this.EditDeSelectAllInstance.src=AppIconInfo[12].src;
		},
		deleteCheckedItems:function(){
			var checkedArr = this.MyAppsList.getCheckedIndex();
			if(checkedArr.length>0){
				this.EditMode=false;
				this.MyAppsList.cancelEditMode();
				this.deactiveEditButton();
				
				for(var index= (checkedArr.length-1);index >= 0 ; index--){
					var tmpDelIndex=this.CurrentPageIndex*30+checkedArr[index];
					AppInfo.splice(tmpDelIndex,1);
				}
				
				this.MyAppsDataSource=this.getAppDataSource();
				this.MyAppsList.setDataSource(this.MyAppsDataSource);
				this.MyAppsList.setCursorInstance(this.AppCursor);
				this.MyAppsList.active(checkedArr[0]);
				this.SelectIndex=3;
			}
			else{
				this.EditMode=false;
				this.MyAppsList.cancelEditMode();
				this.deactiveEditButton();
				this.MyAppsList.setCursorInstance(this.AppCursor);
				this.MyAppsList.active(this.MyAppsList.SelectIndex);
				this.SelectIndex=3;
			}
		},
		moveToNextPage:function(){
			this.UpdateAppsInstance.src=AppIconInfo[5].src;
			this.SelectIndex=2;
			if(this.UpdateAble){
				this.CurrentPageIndex++;
				this.CurrentPageIndex=this.CurrentPageIndex%this.PageCount;
				this.MyAppsDataSource=this.getAppDataSource();
				this.MyAppsList.setDataSource(this.MyAppsDataSource);
			}
		},
		keyHandler:function(keycode){
			var self=this;
			if (this.KeyVisible == false) {
				return;
			}
			if(this.RecommendedList.keyHandler(keycode)){
				return;
			}
			if(this.MyAppsList.keyHandler(keycode)){
				return;
			}
			if(this.PopMsgBoxInstance){
				if(this.PopMsgBoxInstance.keyHandler(keycode)){
					return;
				}
			}
			switch(keycode) {
				case KeyCode.enter:
					{
						if(!this.EditMode){
							if(this.SelectIndex==3){
								if(this.PopMsgBoxInstance){
									var selectOpt=this.PopMsgBoxInstance.SelectIndex;
									this.PopMsgBoxInstance.destroy();
									this.PopMsgBoxInstance=null;
									//do the select opt
									if(selectOpt==0) {//delete
										if(!this.MyAppsList.getLock()){
											var tmpDelIndex=this.CurrentPageIndex*30+this.MyAppsList.SelectIndex;
											AppInfo.splice(tmpDelIndex,1);
											this.MyAppsDataSource=this.getAppDataSource();
											this.MyAppsList.setDataSource(this.MyAppsDataSource);
											this.MyAppsList.setCursorInstance(this.AppCursor);
											this.MyAppsList.active(this.MyAppsList.SelectIndex);
										}
										else{
											this.MyAppsList.setCursorInstance(this.AppCursor);
											this.MyAppsList.active(this.MyAppsList.SelectIndex);
										}
									}
									else if(selectOpt==1){//multi delete
										this.EditMode=true;
										this.MyAppsList.setEditMode();
										//change the main view
										this.activeEditButton();
										
										this.MyAppsList.setCursorInstance(this.AppCursor);
										this.MyAppsList.active(this.MyAppsList.SelectIndex);
									}
									else if(selectOpt==2){//lock/unlock
										var tmplock=this.MyAppsList.getLock();
										this.MyAppsList.setLock(!tmplock);
										var tmpLockIndex=this.CurrentPageIndex*30+this.MyAppsList.SelectIndex;
										AppInfo[tmpLockIndex].locked=!tmplock;
										this.MyAppsList.setCursorInstance(this.AppCursor);
										this.MyAppsList.active(this.MyAppsList.SelectIndex);
										
									}
									
								}
							}
							else if(this.SelectIndex==2){//update the page
								this.moveToNextPage();
							}
							else{
							}
						}
						else{
							if(this.SelectIndex==3){
								var tempstatus = this.MyAppsList.getEditCheckStatus();
								this.MyAppsList.setEditCheckStatus(!tempstatus);
							}
							else if(this.SelectIndex==4){
								//delete the selected items
								this.deleteCheckedItems();
							}
							else if(this.SelectIndex==5){//cancel
								this.EditMode=false;
								this.MyAppsList.cancelEditMode();
								this.deactiveEditButton();
								this.MyAppsList.setCursorInstance(this.AppCursor);
								this.MyAppsList.active(this.MyAppsList.SelectIndex);
								this.SelectIndex=3;
							}
							else if(this.SelectIndex==6){
								this.MyAppsList.selectAllStatus();
							}
							else if(this.SelectIndex==7){
								this.MyAppsList.deSelectAllStatus();
							}
							else{
							}
						}
					}
					break;
				case KeyCode.returnKey:
					{
						if(!this.EditMode){
							if(this.SelectIndex==3){
								if(this.PopMsgBoxInstance){
									this.PopMsgBoxInstance.destroy();
									this.PopMsgBoxInstance=null;
									this.MyAppsList.setCursorInstance(this.AppCursor);
									this.MyAppsList.active(this.MyAppsList.SelectIndex);
								}
							}
						}
					}
					break;
				case KeyCode.left:
					{	
						this.LeftAction();
					}
					break;
				case KeyCode.right:
					{
						this.RightAction();
					}
					break;
				case KeyCode.up:
					{	
						this.UpAction();
					}
					break;
				case KeyCode.down:
					{
						this.DownAction();
					}
					break;
				case Volt.KEY_INFO:
					{
						//show the popupmenu
						if(!this.EditMode){
							if(this.SelectIndex==3){
								if(this.MyAppsList.IsEmpty()){
									var tmpPopPos=[];
									
									var tmpPopHeight=40+30+(this.PopupTextArr.length*60);
									tmpPopPos=this.MyAppsList.getPopupPos(380,tmpPopHeight);
									
									this.MyAppsList.deactive();
									
									this.PopMsgBoxInstance=new PopMsgBox(tmpPopPos[0]+110,tmpPopPos[1]+429,380,40,30,60,this.PopupTextArr,"Helvetica 32px",this.RootInstance);
									this.PopMsgBoxInstance.active();
								}
							}
						}
					}
					break;
				case KeyCode.exit:
					{
					}
					break;
				default:
					break;
			}
		}
	});