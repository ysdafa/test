var _ = require("underscore")._;

var panels = [];
var panel_width = 0;

var initialize = function()
{
  print("Loading the panel script");
  var req = new ResourceRequest({
    uri: "file://APP_Panel.js",
    async: false,
    success: function(data) { Volt.load(data); }
  });
  req.process();

  print("Creating the main panel");
  panels.push(new APP_Panel());
  panel_width = panels[0].getRoot().width;
}

var animating = false;
var onKeyEvent = function(key_code, event_type)
{
  if (event_type == Volt.EVENT_KEY_RELEASE) return;
  if (animating) return;
  animating = true;

  var num_panels = panels.length;

  /* Callback to be called after all animations complete. */
  var after_anim = function() {
    panels.push(new APP_Panel());
    animating = false;
  };
  after_anim = _.after(num_panels, after_anim);

  panels.forEach(function(panel, index)
  {
    var new_x = -1 * (num_panels * panel_width) + (index * panel_width);
    panel.getRoot().animate("x", new_x, 500, after_anim);
  });
}
