var _ = require("underscore")._;

var panels = [
  {
    src: "file://panel_js/panel_0.js",
    module: null,
    widget: null
  },
  {
    src: "file://panel_js/panel_1.js",
    module: null,
    widget: null
  },
  {
    src: "file://panel_js/panel_2.js",
    module: null,
    widget: null
  },
  {
    src: "file://panel_js/panel_3.js",
    module: null,
    widget: null
  },
  {
    src: "file://panel_js/panel_4.js",
    module: null,
    widget: null
  },
  {
    src: "file://panel_js/panel_5.js",
    module: null,
    widget: null
  }
];

var padding = 50;
var current = Math.ceil(panels.length / 2) - 1;

var initialize = function()
{
  scene.color = { r:0, g:0, b:100 };

  for (var index = 0; index < panels.length; ++index)
  {
    init_panel(index);
    panels[index].widget.hide();
  }
  init_panel(current);

  show_adjacent(current);
}

var init_panel = function(index)
{
  if (panels[index].widget == null)
  {
    print("Creating panel " + index);
    var req = new ResourceRequest({
      uri:panels[index].src,
      async:false,
      success: function(data) { Volt.load(data); }
    });
    req.process();
  }
  panels[index].widget.show();
}

var show_adjacent = function(index)
{
  init_panel(index);

  if (current < (panels.length - 1))
  {
    /* right */
    init_panel(current + 1);
    panels[current + 1].widget.x = scene.width - (padding / 2);
    panels[current + 1].widget.show();
  }

  if (current > 0)
  {
    /* left */
    init_panel(current - 1);
    panels[current - 1].widget.x = 0 - panels[current - 1].widget.width + (padding / 2);
    panels[current - 1].widget.show();
  }

  current = index;
}

var animating = false;
var animation_duration = 200;
var move_left = function()
{
  if (current < (panels.length - 1))
  {
    if (animating) return;

    animating = true;

    var after_anim = _.bind(function(index) {
      show_adjacent(index);
      animating = false;
    }, this, current + 1);
    after_anim = _.after(2 + (current > 0 ? 1 : 0), after_anim);

    var current_widget = panels[current].widget;
    current_widget.animate("x",
                           0 - current_widget.width + (padding / 2),
                           animation_duration, after_anim);

    var right_widget = panels[current + 1].widget;
    right_widget.animate("x", padding, animation_duration, after_anim);

    if (current > 0)
    {
      var left_widget = panels[current - 1].widget;
      left_widget.animate("x",
                          0 - (left_widget.width * 2) + (padding / 2),
                          animation_duration, after_anim);
    }

    current = current + 1;
  }
}

var move_right = function()
{
  if (current > 0)
  {
    if (animating) return;

    animating = true;

    var after_anim = _.bind(function(index) {
      show_adjacent(index);
      animating = false;
    }, this, current - 1);
    after_anim = _.after(2 + (current < (panels.length - 1) ? 1 : 0), after_anim);

    var current_widget = panels[current].widget;
    current_widget.animate("x",
                           scene.width - (padding / 2),
                           animation_duration, after_anim);

    var left_widget = panels[current - 1].widget;
    left_widget.animate("x", padding, animation_duration, after_anim);

    if (current < (panels.length - 1))
    {
      var right_widget = panels[current + 1].widget;
      right_widget.animate("x", 
                           scene.width - (padding / 2) + right_widget.width,
                           animation_duration, after_anim);
    }

    current = current - 1;
  }
}

var onKeyEvent = function(key_code, event_type)
{
  if (event_type == Volt.EVENT_KEY_RELEASE) return;

  switch (key_code)
  {
    case Volt.KEY_JOYSTICK_LEFT:
      move_left();
      break;
    case Volt.KEY_JOYSTICK_RIGHT:
      move_right();
      break;
    default:
      print("Unhandled event: " + key_code);
      return;
  }
}
