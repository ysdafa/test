var GridComponent = require("GridComponent");

var Panel2 = function(options)
{
	options = options || { padding:50, parent:scene };

  //var img_src = new Image({ uri:"http://105.64.202.159/volt/test_small.jpg" });
  var img_src = new Image({ uri:"file://dog.jpg" });

  var widgets = [];
  for (var loop = 0; loop < 50; ++loop)
  {
    widgets.push(new ImageWidget({
      x: 0,
      y: 0,
      width: 109,
      height: 109,
      src: img_src
    }));
  }

  var main = new GridComponent({
    parent: options.parent,
    x: options.padding,
    y: options.padding,
    width: options.parent.width - (options.padding * 2),
    height: options.parent.height - (options.padding * 2),
    color: { r:100, g:0, b:0 }
  },
  {
    maxColumns: 10,
    widgets: widgets
  });

  return main;
};

panels[2].widget = new Panel2({ padding:padding, parent:scene });
