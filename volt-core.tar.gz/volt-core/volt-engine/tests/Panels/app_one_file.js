var _ = require("underscore")._;
var GridComponent = require("GridComponent");

var panels = [
  {
    module: null,
    widget: null
  },
  {
    module: null,
    widget: null
  },
  {
    module: null,
    widget: null
  },
  {
    module: null,
    widget: null
  },
  {
    module: null,
    widget: null
  },
  {
    module: null,
    widget: null
  }
];

var padding = 50;
var current = Math.ceil(panels.length / 2) - 1;

var initialize = function()
{
  scene.color = { r:0, g:0, b:100 };

  for (var index = 0; index < panels.length; ++index)
  {
    init_panel(index);
    panels[index].widget.hide();
  }
  init_panel(current);

  show_adjacent(current);
}

var init_panel = function(index)
{
  if (panels[index].widget == null)
  {
    print("Creating panel " + index);
    panels[index].widget = panel_ctors[index]({ padding:padding, parent:scene });
  }
  panels[index].widget.show();
}

var show_adjacent = function(index)
{
  init_panel(index);

  if (current < (panels.length - 1))
  {
    /* right */
    init_panel(current + 1);
    panels[current + 1].widget.x = scene.width - (padding / 2);
    panels[current + 1].widget.show();
  }

  if (current > 0)
  {
    /* left */
    init_panel(current - 1);
    panels[current - 1].widget.x = 0 - panels[current - 1].widget.width + (padding / 2);
    panels[current - 1].widget.show();
  }

  current = index;
}

var animating = false;
var animation_duration = 200;
var move_left = function()
{
  if (current < (panels.length - 1))
  {
    if (animating) return;

    animating = true;

    var after_anim = _.bind(function(index) {
      show_adjacent(index);
      animating = false;
    }, this, current + 1);
    after_anim = _.after(2 + (current > 0 ? 1 : 0), after_anim);

    var current_widget = panels[current].widget;
    current_widget.animate("x",
                           0 - current_widget.width + (padding / 2),
                           animation_duration, after_anim);

    var right_widget = panels[current + 1].widget;
    right_widget.animate("x", padding, animation_duration, after_anim);

    if (current > 0)
    {
      var left_widget = panels[current - 1].widget;
      left_widget.animate("x",
                          0 - (left_widget.width * 2) + (padding / 2),
                          animation_duration, after_anim);
    }

    current = current + 1;
  }
}

var move_right = function()
{
  if (current > 0)
  {
    if (animating) return;

    animating = true;

    var after_anim = _.bind(function(index) {
      show_adjacent(index);
      animating = false;
    }, this, current - 1);
    after_anim = _.after(2 + (current < (panels.length - 1) ? 1 : 0), after_anim);

    var current_widget = panels[current].widget;
    current_widget.animate("x",
                           scene.width - (padding / 2),
                           animation_duration, after_anim);

    var left_widget = panels[current - 1].widget;
    left_widget.animate("x", padding, animation_duration, after_anim);

    if (current < (panels.length - 1))
    {
      var right_widget = panels[current + 1].widget;
      right_widget.animate("x", 
                           scene.width - (padding / 2) + right_widget.width,
                           animation_duration, after_anim);
    }

    current = current - 1;
  }
}

var onKeyEvent = function(key_code, event_type)
{
  if (event_type == Volt.EVENT_KEY_RELEASE) return;

  switch (key_code)
  {
    case Volt.KEY_JOYSTICK_LEFT:
      move_left();
      break;
    case Volt.KEY_JOYSTICK_RIGHT:
      move_right();
      break;
    default:
      print("Unhandled event: " + key_code);
      return;
  }
}

var Panel0 = function(options)
{
	options = options || { padding:50, parent:scene };

  //var img_src = new Image({ uri:"http://105.64.202.159/volt/test_small.jpg" });
  var img_src = new Image({ uri:"file://dog.jpg" });

  var widgets = [];
  for (var loop = 0; loop < 50; ++loop)
  {
    widgets.push(new ImageWidget({
      x: 0,
      y: 0,
      width: 109,
      height: 109,
      src: img_src
    }));
  }

  var main = new GridComponent({
    parent: options.parent,
    x: options.padding,
    y: options.padding,
    width: options.parent.width - (options.padding * 2),
    height: options.parent.height - (options.padding * 2),
    color: { r:100, g:0, b:0 }
  },
  {
    maxColumns: 10,
    widgets: widgets
  });

  return main;
};

var Panel1 = function(options)
{
	options = options || { padding:50, parent:scene };

  //var img_src = new Image({ uri:"http://105.64.202.159/volt/test_small.jpg" });
  var img_src = new Image({ uri:"file://dog.jpg" });

  var widgets = [];
  for (var loop = 0; loop < 50; ++loop)
  {
    widgets.push(new ImageWidget({
      x: 0,
      y: 0,
      width: 109,
      height: 109,
      src: img_src
    }));
  }

  var main = new GridComponent({
    parent: options.parent,
    x: options.padding,
    y: options.padding,
    width: options.parent.width - (options.padding * 2),
    height: options.parent.height - (options.padding * 2),
    color: { r:100, g:0, b:0 }
  },
  {
    maxColumns: 10,
    widgets: widgets
  });

  return main;
};

var Panel2 = function(options)
{
	options = options || { padding:50, parent:scene };

  //var img_src = new Image({ uri:"http://105.64.202.159/volt/test_small.jpg" });
  var img_src = new Image({ uri:"file://dog.jpg" });

  var widgets = [];
  for (var loop = 0; loop < 50; ++loop)
  {
    widgets.push(new ImageWidget({
      x: 0,
      y: 0,
      width: 109,
      height: 109,
      src: img_src
    }));
  }

  var main = new GridComponent({
    parent: options.parent,
    x: options.padding,
    y: options.padding,
    width: options.parent.width - (options.padding * 2),
    height: options.parent.height - (options.padding * 2),
    color: { r:100, g:0, b:0 }
  },
  {
    maxColumns: 10,
    widgets: widgets
  });

  return main;
};

var Panel3 = function(options)
{
	options = options || { padding:50, parent:scene };

  //var img_src = new Image({ uri:"http://105.64.202.159/volt/test_small.jpg" });
  var img_src = new Image({ uri:"file://dog.jpg" });

  var widgets = [];
  for (var loop = 0; loop < 50; ++loop)
  {
    widgets.push(new ImageWidget({
      x: 0,
      y: 0,
      width: 109,
      height: 109,
      src: img_src
    }));
  }

  var main = new GridComponent({
    parent: options.parent,
    x: options.padding,
    y: options.padding,
    width: options.parent.width - (options.padding * 2),
    height: options.parent.height - (options.padding * 2),
    color: { r:100, g:0, b:0 }
  },
  {
    maxColumns: 10,
    widgets: widgets
  });

  return main;
};

var Panel4 = function(options)
{
	options = options || { padding:50, parent:scene };

  //var img_src = new Image({ uri:"http://105.64.202.159/volt/test_small.jpg" });
  var img_src = new Image({ uri:"file://dog.jpg" });

  var widgets = [];
  for (var loop = 0; loop < 50; ++loop)
  {
    widgets.push(new ImageWidget({
      x: 0,
      y: 0,
      width: 109,
      height: 109,
      src: img_src
    }));
  }

  var main = new GridComponent({
    parent: options.parent,
    x: options.padding,
    y: options.padding,
    width: options.parent.width - (options.padding * 2),
    height: options.parent.height - (options.padding * 2),
    color: { r:100, g:0, b:0 }
  },
  {
    maxColumns: 10,
    widgets: widgets
  });

  return main;
};

var Panel5 = function(options)
{
	options = options || { padding:50, parent:scene };

  //var img_src = new Image({ uri:"http://105.64.202.159/volt/test_small.jpg" });
  var img_src = new Image({ uri:"file://dog.jpg" });

  var widgets = [];
  for (var loop = 0; loop < 50; ++loop)
  {
    widgets.push(new ImageWidget({
      x: 0,
      y: 0,
      width: 109,
      height: 109,
      src: img_src
    }));
  }

  var main = new GridComponent({
    parent: options.parent,
    x: options.padding,
    y: options.padding,
    width: options.parent.width - (options.padding * 2),
    height: options.parent.height - (options.padding * 2),
    color: { r:100, g:0, b:0 }
  },
  {
    maxColumns: 10,
    widgets: widgets
  });

  return main;
};

var panel_ctors = [
  Panel0, Panel1, Panel2, Panel3, Panel4, Panel5
];
