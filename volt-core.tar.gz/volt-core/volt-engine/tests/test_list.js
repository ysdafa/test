var list_ = null;

/* Flag to test a race condition when the size of a ListWidget is updated to
 * fit the containing children. */
var test_racecondition_ = false;

Volt.addEventListener(Volt.ON_SHOW, function()
{
  list_ = new ListWidget({
    parent: scene,
    x: 0,
    y: 0,
    width: 10,
    //width: scene.width,
    height: 10,
    //height: scene.height,
    color: { r: 255, g: 0, b: 0, a: 255 },
    orientation: "horizontal"
    //orientation: "vertical"
  });

  list_.spacing = 4;
});

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  var widget = new Widget({ width: 100, height: 100, 
                            color: { r: Math.floor(Math.random() * 155) + 100,
                                     g: Math.floor(Math.random() * 155) + 100,
                                     b: Math.floor(Math.random() * 155) + 100,
                                     a: 255 }});


  if (test_racecondition_)
  {
    /* The dimension of widget is changed after adding to the ListWidget (and
     * when it is actually painted/drawn).
     * The below code exposes the race condition where the logic to update the
     * width/height of the ListWidget to fit the containing children fails
     * because the dimension of the added child is already updated.
     * The race condition happens with/without the timeout with multi-process
     * but happens only with the timeout in single-process because the size is
     * updated before the drawing the next frame. */
    list_.addChild(widget);

    Volt.setTimeout(function()
    {
      if (list_.width < widget.width)
      {
        list_.width = widget.width;
      }
      if (list_.height < widget.height)
      {
        list_.height = widget.height;
      }
    }, 500);
  }
  else
  {
    if (list_.width < widget.width)
    {
      list_.width = widget.width;
    }
    if (list_.height < widget.height)
    {
      list_.height = widget.height;
    }

    /* This MUST come after checking/updating the size! */
    list_.addChild(widget);
  }
});
