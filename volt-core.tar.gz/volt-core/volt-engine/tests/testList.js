var LISTWIDTH = 1600;
var CHILDWIDTH = 400;
var BARHEIGHT = 500;
var EXTENDWIDTH = 600;
var REDUCEWIDTH = 200;
var EXTENDSCALE = 1.5;
var REDUCESCALE = 0.5;
var TIME = 2000;

var parent = new Widget( { width : scene.width, height : scene.height, parent : scene, opacity : 255 , color : { r : 0, g : 0, b : 0 } } );
var testList = new ListWidget({ x : 0, y : 0, width : LISTWIDTH, height : BARHEIGHT, parent : parent, spacing : 0, opacity : 255, color : {a : 0}});
var child1 = new Widget( { x : 0, y : 0, width : CHILDWIDTH, height : BARHEIGHT, parent : testList, opacity : 255 , color : { r : 255, g : 0, b : 0 } } );
var child2 = new Widget( { x : 0, y : 0, width : CHILDWIDTH, height : BARHEIGHT, parent : testList, opacity : 255 , color : { r : 0, g : 0, b : 255 } } );
var child3 = new Widget( { x : 0, y : 0, width : CHILDWIDTH, height : BARHEIGHT, parent : testList, opacity : 255 , color : { r : 0, g : 255, b : 0 } } );
var child4 = new Widget( { x : 0, y : 0, width : CHILDWIDTH, height : BARHEIGHT, parent : testList, opacity : 255 , color : { r : 120, g : 128, b : 0 } } );
var line = new Widget( { x : 0, y : BARHEIGHT, width : LISTWIDTH, height : 1, parent : parent, opacity : 255 , color : { r : 255, g : 255, b : 255 } } );
var testScale1 = new Widget( { x : 0, y : BARHEIGHT + 1, width : CHILDWIDTH, height : BARHEIGHT, parent : parent, opacity : 255 , color : { r : 255, g : 0, b : 0 } } );
var testScale2 = new Widget( { x : CHILDWIDTH, y : BARHEIGHT + 1, width : CHILDWIDTH, height : BARHEIGHT, parent : parent, opacity : 255 , color : { r : 0, g : 0, b : 255 } } );
var testScale3 = new Widget( { x : 2*CHILDWIDTH, y : BARHEIGHT + 1, width : CHILDWIDTH, height : BARHEIGHT, parent : parent, opacity : 255 , color : { r : 0, g : 255, b : 0 } } );
var instructions = new TextWidget({
    origin: {x:0.0, y:0.92},
    verticalOrientation: "center",
    horizontalOrientation: "center",
    font: "36px",
    text: "Press right and left arrow keys to animate. Far right edge of top row should not jitter.",
    parent:scene
}); 

function onKeyEvent(keycode, type)
{
	if(type == Volt.EVENT_KEY_PRESS)
	{
		switch(keycode)
		{
			case Volt.KEY_JOYSTICK_RIGHT :
			
				//change width 
				child1.animate("width", REDUCEWIDTH, TIME);
				child2.animate("width", REDUCEWIDTH, TIME);
        child3.animate("width", EXTENDWIDTH, TIME);
        child4.animate("width", EXTENDWIDTH, TIME);
				
				//change scale
				testScale1.animate("scale.x", REDUCESCALE, TIME);
				testScale1.animate("x", -(1 - REDUCESCALE)*CHILDWIDTH/2, TIME);
				
				testScale2.animate("scale.x", EXTENDSCALE, TIME);
				testScale2.animate("x", CHILDWIDTH + (EXTENDSCALE - 1)*CHILDWIDTH/2 - (1 - REDUCESCALE)*CHILDWIDTH, TIME);
				
				break;
			
			case Volt.KEY_JOYSTICK_LEFT :
				
				//change width 
        child1.animate("width", EXTENDWIDTH, TIME);
        child2.animate("width", EXTENDWIDTH, TIME);
        child3.animate("width", REDUCEWIDTH, TIME);
        child4.animate("width", REDUCEWIDTH, TIME);
				
				//change scale
				testScale1.animate("scale.x", EXTENDSCALE, TIME);
				testScale1.animate("x", (EXTENDSCALE - 1)*CHILDWIDTH/2, TIME);
				
				testScale2.animate("scale.x", REDUCESCALE, TIME);
				testScale2.animate("x", CHILDWIDTH -(1 - REDUCESCALE)*CHILDWIDTH/2 + (EXTENDSCALE - 1)*CHILDWIDTH, TIME);
				
				break;
		}
	}
}
