var colors = require("colors");

var center = new Widget({anchor: 0.5, origin: {x: 0.5, y: 0.4}, drawWithDepth : true});
scene.addChild(center);

function addPane(angle, color, center, radius)
{
	var localcenter = new Widget();
	localcenter.parent = center;

	var pane = new Widget({width: 200, height: 200, color: color, parent: center});
	pane.opacity = 255/3;
	localcenter.addChild(pane);
	pane.depth = radius;
	localcenter.rotation.y = angle;

}

var radius = 500;
var angleDiff = 30;
var num = 12;

for(var i = 0; i < num; i++)
{
	var color = {
		r: 255 * (1 - i/12),
		g: 255 * (i/12),
		b: 0
	}
	addPane(angleDiff * i, color, center, radius);
}



var anim = new Animation(500);
anim.addRelativeProperty("rotation.y", angleDiff);

function onKeyEvent(one, two)
{
	if(two != Volt.EVENT_KEY_PRESS)
		return;

	center.animate(anim);
}


var display = new TextWidget({
	text: "Redder Widgets are drawn earlier. Press any key to rotate counter-clockwise.",
	font: "30px",
	parent: scene,
	origin: {x:0.5, y: 0.9},
	anchor: 0.5
});
