var textWidget = new TextWidget({
  parent: scene,
  width: scene.width,
  height: scene.height,
  horizontalAlignment: "center",
  verticalAlignment: "center",
  font: "24px",
  text: ""
});

function appendText(text)
{
  textWidget.text += text;
  print(text);
}

Volt.addEventListener(Volt.ON_LOAD, function(args)
{
  appendText(" -> ON_LOAD");
});

Volt.addEventListener(Volt.ON_SHOW, function(args)
{
  appendText(" -> ON_SHOW");
});

Volt.addEventListener(Volt.ON_HIDE, function(args)
{
  appendText(" -> ON_HIDE");
});

Volt.addEventListener(Volt.ON_UNLOAD, function(args)
{
  appendText(" -> ON_UNLOAD");
});

Volt.addEventListener(Volt.ON_ACTIVATE, function(args)
{
  appendText(" -> ON_ACTIVATE"); //window moves to foreground.
});

Volt.addEventListener(Volt.ON_DEACTIVATE, function(args)
{
  appendText(" -> ON_DEACTIVATE"); //window moves to background.
});

Volt.addEventListener(Volt.ON_PAUSE, function(args)
{
  appendText(" -> ON_PAUSE");
});

Volt.addEventListener(Volt.ON_RESUME, function(args)
{
  appendText(" -> ON_RESUME");
});

Volt.addEventListener(Volt.ON_RESET, function(args)
{
  appendText(" -> ON_RESET");
});

Volt.addEventListener(Volt.ON_SUSPEND, function(args)
{
  appendText(" -> ON_SUSPEND");
});

Volt.addEventListener(Volt.ON_FACTORY_RESET, function(args)
{
  appendText(" -> ON_FACTORY_RESET");
});

Volt.addEventListener(Volt.ON_SERVICE_RESET, function(args)
{
  appendText(" -> ON_SERVICE_RESET");
});

Volt.addEventListener(Volt.ON_WAKEUP, function(args)
{
  appendText(" -> ON_WAKEUP");
});
