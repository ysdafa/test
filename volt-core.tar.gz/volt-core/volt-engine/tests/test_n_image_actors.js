var GridComponent = require("GridComponent");

var main;

var initialize = function() {
  main = new Widget({
    width: scene.width,
    height: scene.height,
    parent: scene
  });
  onKeyEvent(1);
};

var onKeyEvent = function(keycode, type) {
  if (type == Volt.EVENT_KEY_RELEASE)
    return;
  // if (keycode == Volt.KEY_EXIT) {
  //   Volt.exit();
  //   return true;
  // }
  if (keycode == Volt.KEY_JOYSTICK_OK) {
    print("deleting...");
    main.destroyChildren();
    return false;
  }

  main.destroyChildren();

  var initialWidgets = [];

  var onReady = function (){
    print("************* image loaded ****************");
  };
  var anim = new Animation(2000, -1);
  anim.addRelativeKey(1, "rotation.y", 360);
  for (var i = 0; i < 90; i++) {
    var widget = new ImageWidget({
      src: "dog.jpg",
      width: 100, height: 100,
      onReady: onReady
    });
// UNCOMMENT THIS TO ONLY ANIMATE FIRST ELEMENT
//    if(i==0)
//    {
    	widget.animate(anim);
//    }
    initialWidgets.push(widget);
  }

  var grid = new GridComponent({
    x: 0,
    y: 0,
    width: scene.width,
    height: scene.height,
    color: {
      r: 0,
      g: 0,
      b: 0,
      a: 255
    },
    parent: main
  }, {
    maxColumns: 10,
    widgets: initialWidgets
  });
};
