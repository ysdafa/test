var GridComponent = require("GridComponent");

var main;
var timeout_id = null;

var initialize = function() {
  main = new Widget({
    width: scene.width,
    height: scene.height,
    parent: scene
  });
  onKeyEvent(1, Volt.EVENT_KEY_PRESS);
};

var onKeyEvent = function(keycode, type) {
  if (type == Volt.EVENT_KEY_RELEASE) return;

  if (keycode == Volt.KEY_EXIT) {
    Volt.exit();
    return true;
  }
  if (keycode == Volt.KEY_JOYSTICK_OK) {
    print("deleting...");
    main.destroyChildren();
    return false;
  }

  /* Reload images. */

  if (timeout_id != null)
  {
    Volt.clearTimeout(timeout_id);
  }

  main.destroyChildren();

  var initialWidgets = [];

  var onReady = function (){
    print("************* image loaded ****************");
  };

  var shared_image = true;
  /* Sharing single image oject. */
  var img_src = "../widget/GOLFP/Volt/thumbnail/volt_115x95.png";

  if (shared_image)
  {
    img_src = new Image({ uri:img_src, async:true });
    for (var i = 0; i < 30; i++) {
      /* Set source in ctor */
      initialWidgets.push(new ImageWidget({
        width: 100,
        height: 100,
        src: initialWidgets.length > 0 ? initialWidgets[0].src : img_src,
        onReady: onReady
      }));
    }

    for (var i = 0; i < 30; i++) {
      initialWidgets.push(new ImageWidget({
        width: 100,
        height: 100,
        onReady: onReady
      }));
      /* Set source via the src property */
      initialWidgets[initialWidgets.length - 1].src = img_src;
    }
  }
  else
  {
    /* Each ImageWidget has its own image object. */
    for (var i = 0; i < 60; i++) {
      initialWidgets.push(new ImageWidget({
        width: 100,
        height: 100,
        src: img_src,
        onReady: onReady
      }));
    }
  }

  var grid = new GridComponent({
    x: 0,
    y: 0,
    width: scene.width,
    height: scene.height,
    color: {
      r: 0,
      g: 0,
      b: 0,
      a: 255
    },
    parent: main
  }, {
    maxColumns: 10,
    widgets: initialWidgets
  });

  timeout_id = Volt.setTimeout(function() {
    for (var i = 0; i < 10; i++) {
      grid.addWidget(new ImageWidget({
        width: 100,
        height: 100,
        src: img_src,
        onReady: onReady
      }));
    }
  }, 2000);
};
