var c = require("colors");

var nonAAWidget = new Widget({
	x: 100,
	y: 200,
	width: 500,
	height: 500,
	parent: scene,
	rotation: {
		y: 30,
		x: 0,
		z: 0
	},
	color: c.RED
});

var AAWidget = new Widget({
	x: 700,
	y: 200,
	width: 500,
	height: 500,
	parent: scene,
	rotation: {
		y: 30,
		x: 0,
		z: 0
	},
	color: c.RED
});

var AATop = new Widget({
	x: 700,
	y: 197,
	width: 500,
	height: 3,
	parent: scene,
	rotation: {
		y: 30,
		x: 0,
		z: 0
	},
	gradient: {
		tlColor: {
			r: 0,
			g: 0,
			b: 0,
			a: 0
		},
		trColor: {
			r: 0,
			g: 0,
			b: 0,
			a: 0
		},
		blColor: c.RED,
		brColor: c.RED,
	}
});

var AABottom = new Widget({
	x: 700,
	y: 700,
	width: 500,
	height: 3,
	parent: scene,
	rotation: {
		y: 30,
		x: 0,
		z: 0
	},
	gradient: {
		blColor: {
			r: 0,
			g: 0,
			b: 0,
			a: 0
		},
		brColor: {
			r: 0,
			g: 0,
			b: 0,
			a: 0
		},
		tlColor: c.RED,
		trColor: c.RED,
	}
});


// gradient: {
// 				tlColor: {
// 					r: 115,
// 					g: 38,
// 					b: 115,
// 					a: 255
// 				},
// 				trColor: {
// 					r: 115,
// 					g: 38,
// 					b: 115,
// 					a: 255
// 				},
// 				blColor: {
// 					r: 89,
// 					g: 20,
// 					b: 89,
// 					a: 255
// 				},
// 				brColor: {
// 					r: 89,
// 					g: 20,
// 					b: 89,
// 					a: 255
// 				},
// 			},