var GridComponent = require("GridComponent");

Volt.addEventListener(Volt.ON_SHOW, function() {
  var anim = new Animation({ duration: 2000, repeat: -1 });
  anim.addRelativeKey({ key: 1, property: "rotation.y", value: 360 });

  Volt.pauseGraphics();

  var widgets = [];
  for (var i = 0; i < 40; i++) {

    /* Nested pause/resume.
     * Graphics is resumed only after the outer most resume is called. */
    Volt.pauseGraphics();

    widgets.push(new ImageWidget({
      src: "dog.jpg",
      width: 100,
      height: 100
    }));
    widgets[widgets.length - 1].animate(anim);

    Volt.resumeGraphics();
  }

  Volt.resumeGraphics();

  var grid = new GridComponent({
    x: 0,
    y: 0,
    width: scene.width,
    height: scene.height,
    color: {
      r: 0,
      g: 0,
      b: 0,
      a: 255
    },
    parent: scene
  },
  {
    maxColumns: 10,
    widgets: widgets
  });
});
