var parent;
var nextTest;

function OnKeyEvent(keycode) {
	var moveDelta = 20;
	switch (keycode) {
		case 32:
			OnSpacebar();
			break;
		case 65362:
			parent.y -= moveDelta;
			break;
		case 65364:
			parent.y += moveDelta;
			break;
		case 65361:
			parent.x -= moveDelta;
			break;
		case 65363:
			parent.x += moveDelta;
			break;
	}
}

function initialize() {
	parent = new Widget(512, 512, 200, 200);
	parent.parent = scene;
	parent.color = {
		r: 255,
		g: 0,
		b: 0,
		a: 255
	};
	parent.id = "parent";

	nextTest = test1;
	print("Ready. Move with arrow keys. Press Spacebar to initiate first test.");
}

function OnSpacebar() {
	//gc();
	nextTest();
	print("");
	print("");
	print("Test completed. Move with arrow keys. Press spacebar for next test.");
}

function addChild(childParent, x, y) {
	print("Adding new child at x:" + x + ", y: " + y);
	var child = new Widget(x, y, 200, 200);
	var index = childParent.addChild(child);
	print("Index of added child: " + index);
	return child;
}

function test1() {
	print("Begin Test 1");
	var child = addChild(parent, 30, 30);
	addChild(parent, 50, 50);
	print("Verify two new widgets are added as children.");

	nextTest = test2;
}


function test2() {
	print("Begin Test 2");
	var child = parent.getChild(1);
	print("Verify not null: " + child);
	child.id = "Test id";
	print("Second child id set to Test id");
	child = parent.getChild("Test id");
	print("Verify not null: " + child + "\nVerify Test id '" + child.id + "'");

	nextTest = test3;
}

function test3() {
	print("Begin Test 3. Removing first child ");
	var child = parent.removeChild(0);
	print("Verify not null: " + child);
	print("Removing second index");
	child = parent.removeChild(1);
	print("Verify null " + child);
	child = parent.removeChild(0);
	print("Verify not null: " + child);
	nextTest = test3;

	print("Replacing children");
	addChild(parent, 30, 30);
	addChild(parent, 50, 50);

	nextTest = test4;
}

function test4() {
	print("Begin Test 4. Setting second child to Test id. Removing by id");
	parent.getChild(1).id = "test";
	var child = parent.removeChild("test");
	print("Verify not null: " + child + "\nVerify Test id '" + child.id + "'");

	nextTest = test5;
}


function test5() {
	print("Begin Test 5. Swapping child and parent");
	var child = parent.removeChild(0);
	child.id = "original-child";
	parent.id = "original-parent";

	child.addChild(parent);
	child.parent = scene;
	print("Verify swapped: \nCurrent parent: " + scene.getChild(0).id +
		"\nCurrent child: " + scene.getChild(0).getChild(0).id);

	print("Swapping back");
	parent.addChild(child);
	parent.parent = scene;
	print("Verify swapped: \nCurrent parent: " + scene.getChild(0).id +
		"\nCurrent child: " + scene.getChild(0).getChild(0).id);

	nextTest = test6;
}

function test6() {
	print("Test getWidgetById");
	var parentReturned = Volt.getWidgetById("original-parent");
	var child = Volt.getWidgetById("original-child");
	var foundParent = parentReturned == parent;

	print("Found Parent? " + foundParent);
	if (foundParent) {
		print("Found Child? " + (parentReturned.getChild(0) == child));
		child.color = {
			r: 0,
			g: 255,
			b: 0,
			a: 255
		};
		print("Verify child is green");
	}

	nextTest = test7;
}

function test7() {
	print("Begin Test 6. Removing child");
	var child = parent.getChild(0);
	parent.removeChild(child);
	print("Verify child removed.");

	print("No new tests");
}