var base_url = "http://105.64.202.141/yusuke/snap/examples";

var initialize = function()
{
  var sync = new ResourceRequest({ uri: base_url + "/dog.jpg", async: false });
  sync.process();

  var async = new ResourceRequest({ uri: base_url + "/animations.js", async: true,
                                    callback: function(result)
                                    {
                                      print("Handling async event in custom callback");
                                      Volt.setTimeout(Volt.exit, 1000);
                                    }
                                  });
  async.process();
};
