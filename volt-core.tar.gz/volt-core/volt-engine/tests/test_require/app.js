//determine which require to test by checking a file for text.
var useRequireNoContext = true; //default, if no file exists or file does not contain true/false.
(new ResourceRequest({
	uri : "useRequireNoContext.txt", //file should contain words 'true' or 'false'.
	async : false,
	success : function(data) {
		useRequireNoContext = (data && data.toLowerCase().indexOf("false") == -1);
	}
})).process();

//change require function if needed.
if(useRequireNoContext)
	require = function(arg){return Volt.requireNoContext(arg);}

new TextWidget({
	text: (useRequireNoContext) ? "Testing requireNoContext" : "Testing require",
	x: 400,
	y: 50,
	parent: scene
});

//var colors = require("colors");
var imports = require("test_require_extern.js");
var another = require("test_require_extern2.js");

var shouldNotBeTrue = false;

var IMAGE_DIR = "examples/VODAppHQ/img/home/";
var sampleBook;
var RED = {
	r: 255,
	g: 0,
	b: 0,
	a: 255
};

function initialize() {
	print("Now running script");
	print(imports.testText);
	var thetext = imports.showText();
	thetext.parent = scene;

	if (shouldNotBeTrue === true)
		new TextWidget({
			text: "Context scoping is not working.",
			color: RED,
			x: 400,
			y: 700
		});
}

another.showMoreText(400, 600, "This Widget was created using a nested module at top level");
