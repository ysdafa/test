
var exportsRef = exports;
exports.require1Text = "require1Text";
var nested = require("test_require_extern2.js");

//verify we are still using the same exports variable.
if(exportsRef !== exports)
{
	throw "error: exports reference has changed after require!";
}
//and it has not changed values.
if(exports.require1Text !== "require1Text")
{
	throw "error: exports.require1Text has changed after require!";
}
if(typeof exports.moreText !== "undefined")
{
	throw "error: exports has new property after require!";
}

var TEXT = "This Widget was created using a function in an external module!";
TEXT += ' ' + nested.getMyNum();
exports.testText = TEXT;

exports.showText = function() {
	return new TextWidget({
		text: TEXT,
		x: 400,
		y: 100
	});
};

var thing = new TextWidget({
	text: "This Widget was created directly by the external module",
	x: 400,
	y: 200,
	parent: scene
});

//Test nested requires

var thing = new TextWidget({
	text: nested.moreText,
	x: 400,
	y: 300,
	parent: scene
});
var thing2 = nested.showMoreText(400,400);

//Test scoping
shouldNotBeTrue = true; //this should not be true when accessed by a script that imports this one.