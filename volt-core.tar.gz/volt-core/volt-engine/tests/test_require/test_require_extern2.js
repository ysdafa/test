
if(typeof exports.require1Text !== "undefined")
{
	throw "error: exports has new property after require!";
}

exports.moreText = "This Widget was a property in a nested module";

exports.showMoreText = function(x,y,thetext) {
	if(!thetext) thetext = "This Widget was created by an exernal module using a nested module";
	return new TextWidget({
		text: thetext,
		x: x,
		y: y,
		parent: scene
	});
};

new TextWidget({
	text: "This Widget was created directly by a nested module",
	x: 400,
	y: 500,
	parent: scene
});

/*
Note: the following example is bad practice and normally is not allowed in CommonJS modules.
'export' should only be used for exporting module features, not to be used for module logic.
This test case was added due to the voltapi.js file defining multiple modules inside a single file, 
and not using 'require' to handle dependencies of the modules.
*/
exports.num = 7;
exports.getMyNum = function() {
	if(typeof exports === "undefined")
	{
		throw "error: exports is undefined";
	}
	
	if(typeof exports.num === "undefined")
	{
		throw "error: exports.num does not exist";
	}

	if(exports.num !== 7)
	{
		throw "error: exports.num is not 7";
	}	
	return exports.num;
} 