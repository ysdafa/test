

scene.color = {r: 255, g:255, b:255, a:255};
var RED = { r:255, g:0, b:0, a:255 };
var BLUE = { r:0, g:0, b:255, a:255 };
var MAGENTA = { r:128, g:0, b:128, a:255 };
var gradientDesc = {tlColor: RED, trColor: RED, blColor: BLUE, brColor: BLUE};

var widget = new Widget({
    x: 300,
    y: 130,
    width: 200,
    height: 250,
    //border: { width: 5, color: {r:190, g:12, b:155, a:255 } },
    color: {r: 255, g:200, b:200, a:255},
    shadow: { xOffset: 10, yOffset: 10, blur: 5, color: {r:136, g:136, b:136, a:255} },
    //roundedCorners: { radius: 20, arcStep: 2.0 },
    });

var widget2 = new ImageWidget({
    x: 700,
    y: 100,
    async: true,
    src: "dogMask.png",
    opacity: 255,
    //border: { width: 10, color: {r:100, g:80, b:200, a:255 } },
    //roundedCorners: { radius: 20, arcStep: 2.0 },
    });

var widget3 = new ImageWidget({
    x: 350,
    y: 600,
    async: true,
    src: "dogMask2.png",
    opacity: 255,
    shadow: { xOffset: 10, yOffset: -10, blur: 5, color: {r:136, g:136, b:136, a:255} },
    });

var widget4 = new TextWidget({
    x: 750,
    y: 500,
    font: "64px",
    color: {r:140,g:142,b:255,a:255},
    textColor: {r:0,g:0,b:0,a:255},
    text: "Hello, World",
    opacity: 255,
    roundedCorners: { radius: 20, arcStep: 2.0 },
    shadow: { xOffset: 10, yOffset: 10, blur: 5, color: {r:136, g:136, b:136, a:255} },
    });

var widget5 = new Widget({
    x: 50,
    y: 500,
    width: 200,
    height: 250,

    gradient: gradientDesc,
    //border: { width: 5, color: {r:190, g:12, b:155, a:255 } },
    color: {r: 255, g:200, b:200, a:255},
    shadow: { xOffset: 10, yOffset: 10, blur: 5, color: {r:136, g:136, b:136, a:255} },
    roundedCorners: { radius: 20, arcStep: 2.0 },
    });


scene.addChild(widget);
scene.addChild(widget2);
scene.addChild(widget3);
scene.addChild(widget4);
scene.addChild(widget5);

var anim = new Animation(2000, -1);
anim.addProperty("x", 700);
widget3.animate(anim);

var onKeyEvent = function(key_code, type)
{
  if (type == Volt.EVENT_KEY_RELEASE)
    return;

  var event = null;
  switch (key_code)
  {
  case Volt.KEY_PLAY:
      print("Key Play");
     break;
  case Volt.KEY_STOP:
      print("Key Stop");
    break;

  case Volt.KEY_JOYSTICK_RIGHT:
      widget.height *= 1.5;
      widget.shadow.color = {r:136,b:150,b:136,a:129};
      widget2.shadow = { xOffset: -10, yOffset: -10, blur: 5, spread:0, color: {r:180, g:136, b:136, a:255} };
      //widget2.src = "dog256.jpg";
      break;

  case Volt.KEY_JOYSTICK_LEFT:
      widget.shadow.xOffset = -10;
      break;

  case Volt.KEY_JOYSTICK_DOWN:
      widget.shadow.blur = 10;
      break;

  case Volt.KEY_JOYSTICK_UP:
    print("Key Up");
    widget.shadow = null;
    widget2.shadow = null;
    break;
  }
}

