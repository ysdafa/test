
var imageSrc = "../examples/VODApp/img/cars.jpg";
var image2Src = "../examples/VODApp/img/halo.jpg";

var carsImg = {x:200, y:200, roundedCorners:  {radius:50.0, arcStep:5.0}, src: imageSrc, parent: scene, cropOverflow:true};
var haloImg = {x:50, y:50, scale: {x:1.0, y:2.0}, src: image2Src};

var initialize = function(){
    var widget = new ImageWidget(carsImg);
    var widget2 = new ImageWidget(haloImg);
    widget2.parent = widget;
}

