var _ = require("underscore")._;

var worker_ = null;
var worker_scene_ = null;
var name_ = "worker";
var id_ = 0;

Volt.addEventListener(Volt.ON_MESSAGE, function(event)
{
  print("[" + name_ + "] received msg: " + event.data);

  var msg = JSON.parse(event.data);
  if (msg.msg == "init")
  {
    id_ = msg.id;
    name_ = "worker-" + id_;
    print("My new name is " + name_);

    new TextWidget({ parent: scene, text: name_ });
  }
  else if (msg.msg == "createWorker")
  {
    createWorker();
  }
  else if (msg.msg == "crash")
  {
    crash();
  }
});

Volt.addEventListener(Volt.ON_LOAD, function()
{
  print("[" + name_ + "] Handling ON_LOAD");

  var msg = { msg: "ready" };
  Volt.postMessage(JSON.stringify(msg));
});

Volt.addEventListener(Volt.ON_SHOW, function()
{
  print("[" + name_ + "] Handling ON_SHOW");
});

Volt.addEventListener(Volt.ON_HIDE, function()
{
  print("[" + name_ + "] Handling ON_HIDE");
});

Volt.addEventListener(Volt.ON_UNLOAD, function()
{
  print("[" + name_ + "] Handling ON_UNLOAD");

  /*
  print("[" + name_ + "] Before sleep");
  Volt.sleep(5000);
  print("[" + name_ + "] After sleep");
  */

  terminate_worker();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event)
{
  if (event.type == Volt.EVENT_KEY_PRESS) return;

  createWorker();
});

Volt.addEventListener(Volt.KEY_RETURN, function(event)
{
  if (event.type == Volt.EVENT_KEY_PRESS) return;

  crash();
});

Volt.addEventListener(Volt.KEY_1, function(event)
{
  if (event.type == Volt.EVENT_KEY_PRESS) return;

  terminate_worker();
});

var createWorker = function()
{
  if (worker_)
  {
    var msg = { msg: "createWorker" };
    worker_.postMessage(JSON.stringify(msg));
  }
  else
  {
    print("Should create new worker");

    worker_scene_ = new Widget({
      parent: scene,
      x: 24,
      y: 24,
      width: scene.width - 48,
      height: scene.height - 48,
      color: { r: Math.floor(Math.random() * 155) + 100,
               g: Math.floor(Math.random() * 155) + 100,
               b: Math.floor(Math.random() * 155) + 100,
               a: 255 }
    });

    worker_ = new VoltWorker({
      uri: "app.js",
      scene: worker_scene_,
      onMessage: function(event)
      {
        var msg = JSON.parse(event.data);
        if (msg.msg == "ready")
        {
          print("Worker " + event.worker.id + " is ready");

          msg = {
            msg: "init",
            id: id_ + 1
          };
          event.worker.postMessage(JSON.stringify(msg));
        }
      }
    });
    worker_.onError = function(event)
    {
      print("Worker " + event.worker.id + " terminated with an error: " + event.message);
      event.worker.alive = false;
    };
    worker_.id = id_ + 1;
    worker_.alive = true;

    if (worker_.running == false)
    {
      print("Failed to start a new VoltWorker: " + (id_ + 1));

      terminate_worker();
    }
  }
};

var crash = function()
{
  if (worker_)
  {
    if (worker_.alive)
    {
      var msg = { msg: "crash" };
      worker_.postMessage(JSON.stringify(msg));
    }
    else
    {
      terminate_worker();
    }
  }
  else
  {
    a /* exception! */
  }
};

var terminate_worker = function()
{
  if (worker_) worker_.terminate(2000);
  worker_ = null;
  if (worker_scene_) worker_scene_.destroy();
  worker_scene_ = null;
}
