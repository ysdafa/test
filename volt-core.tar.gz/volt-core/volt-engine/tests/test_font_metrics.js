var text1 = new TextWidget({
    x:200,
    y:200,
    width: 600,
    font: "LMSansDemiCond10 24px",
    ellipsize: true,
    text: "Press OK to get font metrics",
    parent: scene
    });

var text2 = new TextWidget({
    x:800,
    y:230,
    width: 600,
    font: "Sans 24px",
    ellipsize: true,
    text: "Press OK to get font metrics",
    parent: scene
    });


var fontMetrics = text1.getFontMetrics();
setFontMetricsText(text1, fontMetrics);
fontMetrics = text2.getFontMetrics();
setFontMetricsText(text2, fontMetrics);

function setFontMetricsText(widget, fontMetrics)
{
    widget.text = 
        "approximateCharWidth = " + fontMetrics.approximateCharWidth + "\n" +
        "approximateDigitWidth = " + fontMetrics.approximateDigitWidth + "\n" +
        "ascent = " + fontMetrics.ascent + "\n" +
        "descent = " + fontMetrics.descent + "\n" +
        "strikethroughPosition = " + fontMetrics.strikethroughPosition + "\n" +
        "strikethroughThickness = " + fontMetrics.strikethroughPosition + "\n" +
        "underlinePosition = " + fontMetrics.underlinePosition + "\n" +
        "underlineThickness = " + fontMetrics.underlineThickness;
}

