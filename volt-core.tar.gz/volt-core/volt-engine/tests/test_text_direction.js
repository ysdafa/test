﻿var text1 = new TextWidget({
    x:200,
    y:200,
    width: 250,
    height: 30,
    font: "Samsung SVD_Light_Arabic 24px",
    ellipsize: true,
    text: "1:وارد دلخواه حذف کنید؟.دیگر در دسترس نیست. می خواهید آن را از موارد دلخواه حذف کنید؟دیگر در دسترس",
    parent: scene
    });

var text2 = new TextWidget({
    x:200,
    y:230,
    width: 250,
    height: 30,
    font: "TizenSans 24px",
    ellipsize: true,
    text: "2: This is a test of the text direction function.",
    parent: scene
    });


function getTextDir(w)
{
    if (w.isRightToLeft())
        return "Right To Left";
    else
        return "Left To Right"; 
}

function getTextDirStr(string)
{
    if (Volt.isRightToLeft(string))
        return "Right To Left";
    else
        return "Left To Right"; 
}

var str1 = "hello, world";
var str2 = "می خواهید آن را از موارد د";
var textDoc = new TextWidget({
    x:200,
    y:300,
    font: "24 px",
    text: "Text direction of line 1 is " + getTextDir(text1) + 
        "\nText direction of line 2 is " + getTextDir(text2) +
        "\nText direction of \"" + str1 + "\" is " + getTextDirStr(str1) +
        "\nText direction of \"" + str2 + "\" is " + getTextDirStr(str2),
    parent:scene
    });

