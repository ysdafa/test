var colors = require("colors");

var animGroup = new AnimationGroup();;
var isSetup = false;

function setup() {
	var anim1 = new Animation(2000);
	anim1.addProperty("rotation.y", 360);

	var anim2 = new Animation(1000);
	anim2.addProperty("y", -400);
	anim2.addProperty("x", -700);

	var widget = new Widget({parent: scene, width: 200, height: 200, anchor:0.5, origin:0.5});
	var imageWidget = new ImageWidget({parent: scene, origin:0.5, src: "dog.jpg"});

	animGroup.addAnim(imageWidget, anim1);
	var handle = animGroup.addAnim(widget, anim2);
	handle.addCallback(function(){
		widget.color = colors.RED;
	});

	animGroup.addAnim(widget, "scale", {x:0.5, y:0.5}, 3000, "cubic-out",function(){
		widget.color = colors.BLUE;
	});
}


Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event){
	if (event.type == Volt.EVENT_KEY_RELEASE) return;

	if(isSetup) {
		animGroup.startAnimation();	
		gc();
	}
	else {
		setup();
		isSetup = true;
	}
})


