var mainContainer;
var statusText;
var req;

var startLoad = function() 
{
	statusText.text = "STARTED....";
};

function ParseDirectoryInfo(input, path, recursive)
{
	var newPath;
	
	statusText.text += "\n---------------\n"
	if(path != null)
	{
		statusText.text += "printing info for directory: " + path + "/" + input.name + "\n"
		newPath = path + "/" + input.name;
	}
	else
	{
		statusText.text += "printing info for path: " + input.name + "\n";
		newPath = input.name;
	}
	
	statusText.text += "directories: " + input.directories.length + ", files:" + input.files.length + "\n";
	
	if(input.directories.length > 0)
	{
		statusText.text += "directories:\n"
		// print directories
		for(var i = 0; i < input.directories.length; i++)
		{
			statusText.text += "+ " + input.directories[i].name + "\n";
		}
	}
	
	// process files
	if(input.files.length > 0)
	{
		statusText.text += "files:\n";
		for(var i = 0; i < input.files.length; i++)
		{
			statusText.text += "- " + input.files[i].name + ", size " + input.files[i].size + " bytes\n";
		}
	}
	// process sub directories
	if(recursive)
	{
		for(var i = 0; i < input.directories.length; i++)
		{
			ParseDirectoryInfo(input.directories[i], newPath, recursive);
		}
	}
}


function Callback(result) 
{
	statusText.text = "Callback triggered\n" + "Source: "
			+ result.source + "\n" + "ID: " + result.id + "\n" + "URL: "
			+ result.uri + "\n" + "ContentType: " + result.type + "\n"
			+ "Status: " + result.status + "\n" + "Response Type: "
			+ result.response_type + "\n" + "Recursive: " + result.recursive + "\n";

	if (result.response_type == "arraybuffer") 
	{
		var array = new Uint8Array(result.data);
		statusText.text += "Size: " + array.length + "\n";
	}
	else if(result.response_type == "directory")
	{
		statusText.text += "--- Printing Directory Info ---";
		ParseDirectoryInfo(result.data, null, result.recursive);
	}
	else 
	{
		statusText.text += "Size: " + result.data.length + "\n" + "Data: "
				+ result.data;
	}
}

function onCustomKeyEvent(data) {
	if (data.type == Volt.EVENT_KEY_RELEASE) {
		return;
	}

	switch (data.keycode) {
	case Volt.KEY_JOYSTICK_OK:
		statusText.text = "This does nothing. ha ha!\n";
		break;

	case Volt.KEY_JOYSTICK_UP:
		statusText.text = "Create directory\n";

		req = new ResourceRequest("dir://test_main/test_sub");
		req.method = "PUT";
		req.callback = Callback;
		req.recursive = true;
		if (req.process() == false)
			statusText.text += "Failed to make directory";
		break;

	case Volt.KEY_JOYSTICK_DOWN:
		statusText.text = "Read directory\n";

		req = new ResourceRequest("dir://test_main");
		req.recursive = true;
		req.method = "GET";
		req.callback = Callback;
		if (req.process() == false)
			statusText.text += "Failed to get read directory";
		break;

	case Volt.KEY_JOYSTICK_LEFT:
		statusText.text = "Delete directory\n";

		req = new ResourceRequest("dir://test_main/");
		req.recursive = true;
		req.method = "DELETE";
		req.callback = Callback;
		if (req.process() == false)
			statusText.text += "Failed to get delete directory";
		break;

	case Volt.KEY_JOYSTICK_RIGHT:
		statusText.text = "Write file\n";

		req = new ResourceRequest("file://test_main/test_file/file.txt");
		req.method = "PUT";
		req.callback = Callback;
		req.data = "this is a test string. the fox jumping over the.. something i dont really remember ..";
		req.recursive = true;
		if (req.process() == false)
			statusText.text += "Failed to write file";
		break;

	default:
		print("Unhandled event: " + data.keycode);
		break;
	}
}

var initialize = function() {
	print("Initializing...");

	mainContainer = new Widget(0, 0);
	mainContainer.parent = scene;
	mainContainer.width = 1920;
	mainContainer.height = 1080;
	mainContainer.color = {
		r : 0,
		g : 0,
		b : 0,
		a : 255
	};

	var statusContainer = new Widget(0, 40);
	statusContainer.parent = mainContainer;
	statusContainer.width = 1920;
	statusContainer.height = 400;
	statusContainer.color = {
		r : 22,
		g : 22,
		b : 22,
		a : 200
	};

	statusText = new TextWidget(0, 0);
	statusText.parent = statusContainer;
	statusText.width = 1920;
	statusText.height = 1080;
	statusText.font = "Helvetica 24px";
	statusText.color = {
		r : 155,
		g : 155,
		b : 155,
		a : 255
	};

	statusText.text = "Directory Read/Write/Delete Test Script\nPress Up to test create\nPress Down to test read\nPress Left to test delete\nPress Right to test writing to file";

	Volt.addEventListener(Volt.KEY_JOYSTICK_OK, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_UP, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_LEFT, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_RIGHT, onCustomKeyEvent);
};
