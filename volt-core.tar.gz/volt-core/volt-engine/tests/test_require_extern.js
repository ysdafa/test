var nested = require("test_require_extern2.js");

var TEXT = "This Widget was created using a function in an external module!";
exports.testText = TEXT;

exports.showText = function() {
	return new TextWidget({
		text: TEXT,
		x: 400,
		y: 100
	});
};

var thing = new TextWidget({
	text: "This Widget was created directly by the external module",
	x: 400,
	y: 200,
	parent: scene
});

//Test nested requires

var thing = new TextWidget({
	text: nested.moreText,
	x: 400,
	y: 300,
	parent: scene
});
var thing2 = nested.showMoreText(400,400);

//Test scoping
shouldNotBeTrue = true; //this should not be true when accessed by a script that imports this one.