
var image = new NinePatchWidget({
    x: 300, y: 300,
    src: "nine.png",
    parent: scene,
    cornerDimensions: {x: 25, y: 25 } //the corners are 25x25
});
//Note that cornerDimensions CANNOT be changed outside the original constructor.


var image2 = new ImageWidget({
    x: 900, y: 300,
    src: "nine.png",
    parent: scene,
});

image2.src = null;

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    image.height = image.height * 1.5;
    image2.height = image2.height * 1.5;
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    image.height = image.height * 0.5;
    image2.height = image2.height * 0.5;
});

Volt.addEventListener(Volt.KEY_JOYSTICK_LEFT, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    image.width = image.width * 0.5;
    image2.width = image2.width * 0.5;
});

Volt.addEventListener(Volt.KEY_JOYSTICK_RIGHT, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    image.width = image.width * 1.5;
    image2.width = image2.width * 1.5;
});