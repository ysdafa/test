var colors = require("colors");



function log(str) {
	display.text = display.text + "\n" + str;
}

var background = new Widget({
	width: 2000,
	height: 2000,
	parent: scene,
	color: colors.BLUE,
	id: "bkg"
});

var inner = new Widget({
	width: 200,
	height: 200,
	parent: background,
	color: colors.RED,
	id: "inr"
});

background.addEventListener("OnMouseClick", function(widget, eventData){
	log(widget.id);
	log("origin was: " + eventData.origin.id);
});

inner.addEventListener("OnMouseClick", function(widget, eventData) {
	log(widget.id);
	widget.destroy();
});



var display = new TextWidget({
	text: "You should see an exception, not a crash, when clicking on the red widget. Exception should say 'TypeError: Cannot read property 'id' of null' ",
	font: "25px",
	width: 350,
	maxLines: 6,
	parent: scene,
	origin: 0.5,
	anchor: 0.5
});