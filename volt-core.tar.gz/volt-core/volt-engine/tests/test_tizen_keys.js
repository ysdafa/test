var mainContainer;
var statusText;

var startLoad = function() {
	statusText.text = "STARTED....";
};

function onCustomKeyEvent2(data) 
{
	if (data.type == Volt.EVENT_KEY_RELEASE)
		return;

	switch (data.keycode) 
	{
	case Volt.KEY_9:
		statusText.text = "Key 9 triggered, start AUL TEST APP";
//		aulApp = new Aul();
//
//		var stringArray = [ "B", "C", "D", "E" ];
//		var args1 = {
//			input1 : "A",
//			input2 : stringArray
//		};
//
//		aulApp.launchApp("org.tizen.crash-popup", args1);

		aulApp = new Aul();
				var args1 = {
					"--root" : "/usr/apps/volt",
					"--app-js" : "/root/game/app/appSrc/app.js"
				};
		
				aulApp.launchApp("org.tizen.volt-container2", args1);		
		
		break;

	default:
		print("Unhandled event: " + keycode);
		break;
	}
}

function onKeyEvent(keycode,type)
{
	statusText.text = "this should not happen!!";
}
  
function onCustomKeyEvent(data) 
{
	if (data.type == Volt.EVENT_KEY_RELEASE)
		return;

	switch (data.keycode) 
	{
	case Volt.KEY_1:
		statusText.text = "Key 1 triggered, adding Key 2 and 3 handler\nPress Key 2 to add Key 9,\nPress Key 3 to remove Key 9";
		Volt.addEventListener(Volt.KEY_2, onCustomKeyEvent);
		Volt.addEventListener(Volt.KEY_3, onCustomKeyEvent);
		break;

	case Volt.KEY_2:
		statusText.text = "Key 2 triggered, adding Key 9 handler\nPress Key 9 to trigger AUL crash pop app";
		Volt.addEventListener(Volt.KEY_9, onCustomKeyEvent2);
		break;

	case Volt.KEY_3:
		statusText.text = "Key 3 triggered, removing Key 9 handler";
		Volt.removeEventListener(Volt.KEY_9, onCustomKeyEvent2);
		break;

	case Volt.KEY_JOYSTICK_OK:
		statusText.text = "OK triggered\n";
		break;
	case Volt.KEY_JOYSTICK_UP:
		statusText.text = "UP triggered\n";
		break;
	case Volt.KEY_JOYSTICK_DOWN:
		statusText.text = "DOWN triggered\n";
		break;
	case Volt.KEY_JOYSTICK_LEFT:
		statusText.text = "LEFT triggered\n";
		break;
	case Volt.KEY_JOYSTICK_RIGHT:
		statusText.text = "RIGHT triggered\n";
		break;
		
	default:
		print("Unhandled event: " + keycode);
		break;
	}
}

var initialize = function() {
	print("Initializing...");

	mainContainer = new Widget(0, 0);
	mainContainer.parent = scene;
	mainContainer.width = 1920;
	mainContainer.height = 1080;
	mainContainer.color = {
		r : 0,
		g : 0,
		b : 0,
		a : 255
	};

	var statusContainer = new Widget(0, 40);
	statusContainer.parent = mainContainer;
	statusContainer.width = 1920;
	statusContainer.height = 400;
	statusContainer.color = {
		r : 22,
		g : 22,
		b : 22,
		a : 200
	};

	statusText = new TextWidget(0, 0);
	statusText.parent = statusContainer;
	statusText.width = 1920;
	statusText.height = 1080;
	statusText.font = "Helvetica 46px";
	statusText.color = {
		r : 155,
		g : 155,
		b : 155,
		a : 255
	};
	statusText.text = "Tizen Keys Test Script\nPress 1 to start";

	Volt.addEventListener(Volt.KEY_1, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_OK, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_UP, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_LEFT, onCustomKeyEvent);
	Volt.addEventListener(Volt.KEY_JOYSTICK_RIGHT, onCustomKeyEvent);
};
