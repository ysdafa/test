var widget;
Volt.addEventListener(Volt.ON_SHOW, function(args)
{
  widget = new Widget({
    parent: scene,
    width: 100, height: 100
  })

  widget.addEventListener(Volt.KEY_EXIT, function(event)
  {
    var handle = true;
    print("Widget: " + (handle ? "" : "NOT ") + "handling EXIT key...");
    return handle;
  });
});

Volt.addEventListener(Volt.KEY_EXIT, function(event)
{
  var handle = false;
  print("Key handler: " + (handle ? "" : "NOT ") + "handling EXIT key...");
  return handle;
});

function onKeyEvent(keycode)
{
  if (keycode != Volt.KEY_EXIT) return;

  var handle = false;
  print("Global handler: " + (handle ? "" : "NOT ") + "handling EXIT key...");
  return handle;
}

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event)
{
  print("Focus widget");
  scene.setKeyFocus(widget);
});
