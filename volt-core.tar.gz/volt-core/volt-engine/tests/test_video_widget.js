// This example uses the Uni Player Emp SEF to play a video file named by variable VideoFileName 
// in a VideoWidget.  Please see SEF docs for more details on "Player".
// It also utilizes the asynchronous option for executing an SEF command by suppling a callback
// function.
// 
// To set up this app, copy a video file into the same directory as the JS file and change
// the variable VideoFileName to match the name of the video file.
// 
// To use this app, run it and press PLAY to start playing the video.
// You may press RIGHT,LEFT,UP, or DOWN to move the location of the video.
// You may press 1, 2, or 3 to change the size of the video.
// 
// Note: animation of the VideoWidget is not yet supported.
//

var VideoFileName = "combined.mp4";

var animating = false;

var onKeyEvent = function(key_code, type)
{
  if (type == Volt.EVENT_KEY_RELEASE)
    return;

  var event = null;
  switch (key_code)
  {
  case Volt.KEY_PLAY:
    print("playing video");
    startVideoPlayback.playVideo();
    break;
  case Volt.KEY_STOP:
    print("stopping video");
    startVideoPlayback.stopVideo();
    break;

  case Volt.KEY_JOYSTICK_RIGHT:
    videoWidget.x += 200;
		break;

  case Volt.KEY_JOYSTICK_LEFT:
    videoWidget.x -= 200;
    break;

  case Volt.KEY_JOYSTICK_UP:
    videoWidget.y -= 200;
    break;

  case Volt.KEY_JOYSTICK_DOWN:
    videoWidget.y += 200;
    break;

  case Volt.KEY_1:
    videoWidget.x = 200;
    videoWidget.y = 200;
    videoWidget.width = 480;
    videoWidget.height = 270;
    break;

  case Volt.KEY_2:
    videoWidget.x = 200;
    videoWidget.y = 200;
    videoWidget.width = 960;
    videoWidget.height = 540;
    break;

  case Volt.KEY_3:
    videoWidget.x = 0;
    videoWidget.y = 0;
    videoWidget.width = 1920;
    videoWidget.height = 1080;
    break;

  case Volt.KEY_FF:
    break;

  case Volt.KEY_REWIND:
    break;

// Animation not yet available
//case Volt.KEY_REC:
//  if (!animating)
//  {
//    animating = true;
//    animateFunc();
//  }
//  break;
//case Volt.KEY_TOOLS:
//  if (animating)
//  {
//    animating = false;
//    animHandle.cancel();
//  }
//  else
//  {
//    videoWidget.x = 200;
//    videoWidget.y = 200;
//  }
  }
}

var startVideoPlayback = {};
var videoFilePath = Volt.getAbsolutePath("$APP_ROOT/" + VideoFileName);
print("videoFilePath = " + videoFilePath);

startVideoPlayback.playVideo = function() {
  sef2.execute("StartPlayback", "0", startVideoPlayback.onPlayFinished);
}

startVideoPlayback.stopVideo = function() {
      sef2.execute("Stop", startVideoPlayback.onStopFinished);
    }

startVideoPlayback.OnSefEvent = function(event_type, param1, param2) {
		print("Script OnEvent(" + event_type + ", " + param1 + ", " + param2 + ")");
};

startVideoPlayback.onPlayFinished = function (result) {
	print("onPlayFinished, result = " + result);
};

startVideoPlayback.onStopFinished = function (result) {
  print("onStopFinished, result = " + result);
};

// Animation not yet implemented
//var animHandle;
//var animateFunc = function() {
//  var anim = new Animation(6000, -1);
//  anim.addKey(0.25, "x", 600);
//  anim.addKey(0.25, "y", 200);
//  anim.addKey(0.50, "x", 600);
//  anim.addKey(0.50, "y", 600);
//  anim.addKey(0.75, "x", 200);
//  anim.addKey(0.75, "y", 600);
//  anim.addKey(1.00, "x", 200);
//  anim.addKey(1.00, "y", 200);
//  animHandle = videoWidget.animate(anim, function () {
//      animating = false;
//  });
//}

 sef2 = new Sef();
 sef2.onEventCallback = startVideoPlayback.OnSefEvent ;
 result = sef2.open("Player", "1.116", "Player");
 print("Open result: " + result);
 sef2.execute("InitPlayer", videoFilePath, function () {
   print("initplayer done");
   });

 var backDropWidget = new Widget({
     color: {r:111, g:111, b:111, a:255},
     x: 0,
     y: 0,
     width:1920,
     height:1080
     });


 var videoWidget = new VideoWidget({
     x:200,
     y:200,
     width:480,
     height:270,
     cutThrough: backDropWidget,
     border: { width:5, color: {r:255,g:255,b:255,a:255}},
     videoPlayerSef: sef2
 });

 scene.addChild(backDropWidget);
 scene.addChild(videoWidget);

