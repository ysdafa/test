var display = new TextWidget({width: 200, height: 200, anchor:{x: 0.5, y:0.5}, origin:{x:0.5, y:0.8}});

var currentText = "";
function showText(text)
{
	currentText += "\n" + text;
	display.text = currentText;
}

showText("init");

var image = new ImageWidget({
	src: "fake-image",
	async: true,
	onReady : function(success) {
		if(success) 
			showText("Image Loaded!");
		else showText("Image failed to load");
		
	}
});

scene.addChild(display);
scene.addChild(image);
