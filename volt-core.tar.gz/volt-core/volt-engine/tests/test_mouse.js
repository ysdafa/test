var GridComponent = require("GridComponent");
var colors = require("colors");
var DragWidget = require("DraggableComponent");


var initialize = function() {

  var main = new Widget({
    width: scene.width,
    height: scene.height,
    parent: scene
  });

  var widget_id = 0;

  var grid = new GridComponent({
    x: 0,
    y: 0,
    width: scene.width,
    height: scene.height,
    color: {
      r: 0,
      g: 0,
      b: 0,
      a: 255
    },
    parent: main
  }, {
    maxColumns: 10
  });




//Colored Widget:
  var widget = new Widget({
    id: "widget",
    width: 100,
    height: 100,
    color: { r:255, g:0, b:0 }
  });
  widget.addEventListener("onMouseDown", function(widget, eventData)
  {
    var button = eventData.button;
    if (button == Volt.MOUSE_BUTTON_LEFT)
    {
      print("widget pressed with a left button!");
      widget.color = { r:0, g:255, b:0 };
    }
    else if (button == Volt.MOUSE_BUTTON_MIDDLE)
    {
      print("widget pressed with a middle button!");
      widget.color = { r:255, g:0, b:0 };
    }
    else if (button == Volt.MOUSE_BUTTON_RIGHT)
    {
      print("widget pressed with a right button!");
      widget.color = { r:0, g:0, b:255 };
    }
    else
    {
      print("widget pressed with an unhandled button " + button + "!");
      widget.color = { r:255, g:255, b:255 };
    }
  });
  grid.addWidget(widget);



//Image Widget 
  /*var image_widget = new ImageWidget({
    id: "image widget",
    width: 100,
    height: 100,
    src: "file://dog.jpg"
  });
  image_widget.addEventListener("onMouseDown", function()
  {
    print("image widget pressed!");
  });
  grid.addWidget(image_widget);
*/



//Text Widget
  var text_widget = new TextWidget({
    id: "text widget",
    width: 100,
    height: 100,
    text: "I'm clickable!"
  });

  text_widget.addEventListener("onmousedown", function(widget, eventData)
  {
    var button = eventData.button;

    if(widget != text_widget) return; //test that the right widget is given

    if (button == Volt.MOUSE_BUTTON_LEFT)
    {
      text_widget.text = "widget pressed with a left button!";
    }
    else if (button == Volt.MOUSE_BUTTON_MIDDLE)
    {
      text_widget.text = "widget pressed with a middle button!";
    }
    else if (button == Volt.MOUSE_BUTTON_RIGHT)
    {
      text_widget.text = "widget pressed with a right button!";
    }
    else
    {
      text_widget.text = "widget pressed with an unhandled button " + button + "!";
    }
  });

  text_widget.addEventListener("onmouseup", function(widget){
    text_widget.text = "Mouse release event";
  });

  text_widget.addEventListener("onmouseover", function(widget){
    print("Mouse over text widget");
  });

  text_widget.addEventListener("onmouseout", function(widget){
    print("Mouse no longer over text widget");
  });

  text_widget.addEventListener("onmousemove", function(widget, eventData){
    var button = eventData.button;
    var coordinates = eventData.coordinates;
    print("Mouse over text widget at absolute coordinates: (" + coordinates.x + "," + coordinates.y + ")");
  });

  text_widget.addEventListener("onmouseclick", function(widget){
      widget.text = "Mouse click event";
  });

  grid.addWidget(text_widget);


  //Display text

var display = new TextWidget({
  x: 60, y: 200,
  width: 500, height: 50,
  text: "HERE IS SOME SAMPLE TEXT",
});

scene.addChild(display);

function print(str) {
  display.text = str;
}


//Test Event Bubbling
var testEvent = "onMouseClick";
var baseWidth = 50;
var clickOrder = "";

function clickHandler(widget) {
  clickOrder += "\n" + widget.id;
}

function getClickListText(){
  var result =  "Events recieved in the order:" + clickOrder;
  clickOrder = "";
  return result;
}

var red = new Widget({
  color: colors.RED,
  x: 600,
  width: baseWidth * 3,
  height: baseWidth * 3,
  id: "red",
  parent: scene
});

var blue = new Widget({
  color: colors.BLUE,
  width: baseWidth * 2,
  height: baseWidth * 2,
  id: "blue",
  parent: red
});

var green = new Widget({
  color: colors.GREEN,
  width: baseWidth,
  height: baseWidth,
  id: "green",
  parent: blue
});

var outside = new Widget({
  color: colors.BRIGHT_ORANGE,
  x: 220,
  width: baseWidth,
  height: baseWidth,
  id: "non-blocking-orange",
  parent: green
}); 
var outsideNote = new TextWidget({
    text: "Does not block event bubbling",
    parent: outside,
    origin: {
        x: 1.1, 
        y: 0.5
    }
});

var outsideBlocking = new Widget({
  color: colors.BRIGHT_ORANGE,
  x: 220,
  y: 100,
  width: baseWidth,
  height: baseWidth,
  id: "blocking-orange",
  parent: green
}); 
var outsideBlockingNote = new TextWidget({
    text: "Block event bubbling",
    parent: outsideBlocking,
    origin: {
        x: 1.1, 
        y: 0.5
    }
});

var clickList = new TextWidget({
  width: 200, height: 500, 
  parent: red, 
  y: baseWidth * 4, 
  text: "The order of click events on the above widgets will be displayed here."
});

red.addEventListener(testEvent, clickHandler);
green.addEventListener(testEvent, clickHandler);
blue.addEventListener(testEvent, clickHandler);
outside.addEventListener(testEvent, clickHandler);
outsideBlocking.addEventListener(testEvent, function(widget) {
    clickOrder += "\n" + widget.id;
    clickList.text = getClickListText();
    return false;
});


scene.addEventListener(testEvent, function() {
  clickList.text = getClickListText();
});


//Basic drag and drop test
  var normalColor = {r: 150, g:150, b:150, a: 150}; //transparent grey
  var hoverColor = {r: 0, g: 200, b: 0};
  var dragColor = {r: 255, g:71, b:25, a: 255}; //orangish

  var dragDrop = new DragWidget({
    color: normalColor,
    border: {width: 3, color: colors.WHITE},
    width: 100, height: 100,
    anchor: {x: 0.5, y: 0.5},
    dragAnchor: {x: 0.5, y: 0.5},
    x: 400 + 50,
    y: 0 + 50,
    parent: scene
  });

  var text = new TextWidget({
    text:"This widget is draggable!",
    parent: dragDrop,
    origin: {x: 0, y:1.1}
  });

  //Change border color on hover
  dragDrop.addEventListener("onmouseover", function() {
    dragDrop.border.color = hoverColor;
  });
  dragDrop.addEventListener("onmouseout", function() {
    dragDrop.border.color = colors.WHITE;
  });

  //Change inner color on click/release
  dragDrop.addEventListener("onmousedown", function() {
    dragDrop.color = dragColor;
    dragDrop.canDrag = true;
  });
  dragDrop.addEventListener("onmouseup", function() {
    dragDrop.color = normalColor;
    dragDrop.canDrag = false;
  });


  //Test the origin property
  var parent = new Widget({y: 300, width: 600, height: 200, color: {r:0, g:0, b:0, a:0} });
  scene.addChild(parent);

  function addHighlightableWidget(index, widget) {
    var size = 200;
    widget.width = size;
    widget.height = size;
    widget.border = {width: 4, color: colors.WHITE};
    parent.addChild(widget);
    widget.addEventListener("onmousedown", function(){});//make these widgets reactive
    widget.x = size * index;
  }

  addHighlightableWidget( 0, new Widget({color: colors.RED}) );
  addHighlightableWidget( 1, new TextWidget("The borders of these widgets should change color on clicks and releases") );
  //addHighlightableWidget( 2, new ImageWidget( "http://105.64.202.159/volt/test_small.jpg!") );

  //Set the border highlighting events on the one parent widget, and get the behavior on all children
  parent.addEventListener("OnMouseDown", function(current, eventData) {
      eventData.origin.border.color = hoverColor; 
  });
  parent.addEventListener("OnMouseUp", function(current, eventData) {
      eventData.origin.border.color = colors.WHITE; 
  });


  Volt.addEventListener(Volt.MOUSE_FLICK_LEFT, function() {
    print("Flicked left");
  });

  Volt.addEventListener(Volt.MOUSE_FLICK_RIGHT, function() {
    print("Flicked right");
  });

  Volt.addEventListener(Volt.MOUSE_FLICK_UP, function() {
    print("Flicked up");
  });

  Volt.addEventListener(Volt.MOUSE_FLICK_DOWN, function() {
    print("Flicked down");
  });
};
