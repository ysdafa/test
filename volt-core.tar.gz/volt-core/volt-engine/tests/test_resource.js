var KeyboardComponent = require("KeyboardComponent");

var uriTextField_;
var dataTextField_;
var keyboard_;

var syncSwitch_;
var methodSwitch_;
var processButton_;

var outputTextWidget_;

var borderOptions_ = { color: { r: 0, g: 0, b: 255 }, width: 4 };

var selectable_ = [];

var origUri_;

var request_;

Volt.addEventListener(Volt.ON_LOAD, function(args)
{
  var widget = new Widget({
    parent: scene,
    x: scene.width - 60,
    y: 10,
    width: 50,
    height: 50,
    color: { r: 0, g: 0, b: 255 }
  });

  var anim = new Animation(1000, -1);
  anim.addRelativeKey(1, "rotation.y", 360);
  widget.animate(anim);

  outputTextWidget_ = new TextWidget({
    parent: scene,
    width: scene.width,
    height: scene.height,
    font: "24px",
    text: "Configure request options and press 'Process'"
  });

  var lineHeight = 24;
  var padding = 5;

  var inputContainer = new Widget({
    parent: scene,
    x: 0,
    y: scene.height - (2 * lineHeight + 3 * padding),
    width: scene.width,
    height: 2 * lineHeight + 2 * padding,
    color: { r: 255, g: 255, b: 255, a: 50 }
  });

  var inputBackground = new Widget({
    parent: inputContainer,
    x: padding,
    y: padding,
    width: inputContainer.width - (2 * padding),
    height: lineHeight,
    color: { r: 0, g: 0, b: 0, a: 0 }
  });

  methodSwitch_ = new TextWidget({
    parent: inputBackground,
    x: 0,
    width: inputBackground.width * 0.1 - padding,
    height: lineHeight,
    color: { r: 255, g: 255, b: 255 },
    textColor: { r: 0, g: 0, b: 0 },
    roundedCorners: { radius: 5, arcStep: 5.0 },
    font: "24px",
    text: "GET",
    horizontalAlignment: "center"
  });
  methodSwitch_.labels = [ "GET", "PUT", "POST", "DELETE" ];
  methodSwitch_.index = 0;

  uriTextField_ = new TextWidget({
    parent: inputBackground,
    x: methodSwitch_.x + methodSwitch_.width + 5,
    width: inputBackground.width * 0.70 - padding,
    height: lineHeight,
    color: { r: 255, g: 255, b: 255 },
    textColor: { r: 0, g: 0, b: 0 },
    roundedCorners: { radius: 5, arcStep: 5.0 },
    font: "24px",
    text: "http://www.google.com"
  });

  syncSwitch_ = new TextWidget({
    parent: inputBackground,
    x: uriTextField_.x + uriTextField_.width + 5,
    width: inputBackground.width * 0.1 - padding,
    height: lineHeight,
    color: { r: 255, g: 255, b: 255 },
    textColor: { r: 0, g: 0, b: 0 },
    roundedCorners: { radius: 5, arcStep: 5.0 },
    font: "24px",
    text: "Sync",
    horizontalAlignment: "center"
  });
  syncSwitch_.labels = [ "Sync", "Async" ];
  syncSwitch_.index = 0;

  processButton_ = new TextWidget({
    parent: inputBackground,
    x: syncSwitch_.x + syncSwitch_.width + 5,
    width: inputBackground.width * 0.1 - padding,
    height: lineHeight,
    color: { r: 100, g: 100, b: 255 },
    textColor: { r: 0, g: 0, b: 0 },
    roundedCorners: { radius: 5, arcStep: 5.0 },
    font: "24px",
    text: "Process",
    horizontalAlignment: "center"
  });

  dataTextField_ = new TextWidget({
    parent: inputBackground,
    x: 0,
    y: lineHeight + padding,
    width: inputBackground.width - padding,
    height: lineHeight,
    color: { r: 255, g: 255, b: 255 },
    textColor: { r: 0, g: 0, b: 0 },
    roundedCorners: { radius: 5, arcStep: 5.0 },
    font: "24px",
    text: "Data for PUT/POST methods"
  });

  keyboard_ = new KeyboardComponent();

  uriTextField_.border = borderOptions_;

  selectable_ = [
    [ methodSwitch_, uriTextField_, syncSwitch_, processButton_ ],
    [ dataTextField_ ]
  ];
  selectable_.index = { row: 0, col: 1 };

  request_ = new ResourceRequest();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_RIGHT, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  if (keyboard_.visible)
  {
    keyboard_.handleKey("right");
  }
  else
  {
    selectRight();
  }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_LEFT, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  if (keyboard_.visible)
  {
    keyboard_.handleKey("left");
  }
  else
  {
    selectLeft();
  }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  if (keyboard_.visible)
  {
    keyboard_.handleKey("up");
  }
  else
  {
    /*
    if (outputTextWidget_.height > scene.height)
    {
      var new_y = outputTextWidget_.y + 20;
      outputTextWidget_.y = new_y > 0 ? 0 : new_y;
    }
    */
    {
      selectUp();
    }
  }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  if (keyboard_.visible)
  {
    keyboard_.handleKey("down");
  }
  else
  {
    /*
    if (selectable_.index.row == selectable_.length - 1)
    {
      if (outputTextWidget_.height > scene.height)
      {
        var new_y = outputTextWidget_.y - 20;
        var min = scene.height - outputTextWidget_.height;
        outputTextWidget_.y = new_y < min ? min : new_y;
      }
    }
    else
    */
    {
      selectDown();
    }
  }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  var selected = selectable_[selectable_.index.row][selectable_.index.col];
  if (selected === uriTextField_)
  {
    if (keyboard_.visible)
    {
      keyboard_.handleKey("select");
    }
    else
    {
      origUri_ = uriTextField_.text;
      keyboard_.showKeyboard(uriTextField_);
    }
  }
  else if (selected === processButton_)
  {
    request_.method = methodSwitch_.labels[methodSwitch_.index];
    request_.uri = uriTextField_.text;
    request_.async = syncSwitch_.labels[syncSwitch_.index] == "Async";
    request_.data = dataTextField_.text;
    request_.complete = onComplete;

    outputTextWidget_.text =
      "Processing " + (request_.async ? "async" : "sync") + " " +
      request_.method + " request: " + request_.uri + "\n" +
      "==============================================================\n";
    outputTextWidget_.height += outputTextWidget_.getTextOverflow();
    request_.process();
  }
  else
  {
    selected.index += 1;
    if (selected.index >= selected.labels.length)
    {
      selected.index = 0;
    }
    selected.text = selected.labels[selected.index];
  }
});

Volt.addEventListener(Volt.KEY_RETURN, function(event)
{
  if (event.type == Volt.EVENT_KEY_RELEASE) return;

  if (keyboard_.visible)
  {
    keyboard_.hideKeyboard();
    uriTextField_.text = origUri_;
  }
});

var selectRight = function()
{
  selectable_[selectable_.index.row][selectable_.index.col].border = null;

  if (++(selectable_.index.col) >= selectable_[selectable_.index.row].length)
  {
    selectable_.index.col = 0;
  }

  selectable_[selectable_.index.row][selectable_.index.col].border = borderOptions_;
};

var selectLeft = function()
{
  selectable_[selectable_.index.row][selectable_.index.col].border = null;

  if (--(selectable_.index.col) < 0)
  {
    selectable_.index.col = selectable_[selectable_.index.row].length - 1;
  }

  selectable_[selectable_.index.row][selectable_.index.col].border = borderOptions_;
};

var selectUp = function()
{
  selectable_[selectable_.index.row][selectable_.index.col].border = null;

  if (--(selectable_.index.row) < 0)
  {
    selectable_.index.row = selectable_.length - 1;
  }
  selectable_.index.col = 0;

  selectable_[selectable_.index.row][selectable_.index.col].border = borderOptions_;
};

var selectDown = function()
{
  selectable_[selectable_.index.row][selectable_.index.col].border = null;

  if (++(selectable_.index.row) >= selectable_.length)
  {
    selectable_.index.row = 0;
  }
  selectable_.index.col = 0;

  selectable_[selectable_.index.row][selectable_.index.col].border = borderOptions_;
};

var onComplete = function(result, status)
{
  outputTextWidget_.text += "Request complete\n\n" +
    "ID: " + result.id + "\n" +
    "Source: " + result.source + "\n" +
    "URL: " + result.uri + "\n" +
    "Status: " + result.status + "\n" +
    "Reason: " + result.reason + "\n" +
    "ContentType: " + result.type + "\n" +
    "Response Type: " + result.response_type + "\n";

  outputTextWidget_.text += "Headers: \n";
  for (var propt in result.headers)
  {
    outputTextWidget_.text += propt + ': ' + result.headers[propt] + "\n";
  }

  if (result.response_type == "arraybuffer")
  {
    var array = new Uint8Array(result.data);
    outputTextWidget_.text += "Size: " + array.length + "\n\n" +
                              String.fromCharCode.apply(null, array);
  }
  else
  {
    outputTextWidget_.text += "Size: " + result.data.length + "\n\n" +
                              result.data;
  }

  outputTextWidget_.height += outputTextWidget_.getTextOverflow();
};
