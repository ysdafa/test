var colors = require("colors");

/************Logging logic****************/

var display = new TextWidget({
    width: 300,
    height: 720,
    parent:scene,
    anchor:0.5,
    origin:{x:0.8, y:0.5}
});


function log(string) {
    display.text = string + "\n" + display.text;
}

function clear() {
    display.text = "";
}


var widget = new Widget({
    x: 200,
    y: 200,
    width: 200,
    height: 200,
    parent:scene
});

function endCallback() {
    log("end");
    log("Widget.x = " + widget.x);
}

var anim = new Animation(2000,1);
anim.addProperty("x", 300);
anim.addKeyCallback(0.5, function() {
    log("50%");
});
anim.addKeyCallback(0.9, function() {
    log("90%");
});

anim.addKeyCallback(1, function(){
    log("Cycle finished");
});

anim.addCallback(function(){
    log("end 1");
});

anim.addCallback(function(){
    log("end 2");
});

var onKeyEvent = function(keycode, type) {
  if (type != Volt.EVENT_KEY_PRESS)
      return;

  var handle = widget.animate(anim, endCallback);
  handle.addKeyCallback(0.4, function(){ 
    log("40%");
  });

  handle.addKeyCallback(0.1, function(){ 
    log("10%");
  });
};

/*
scene.addEventListener("OnMouseDown", function(){
    widget.color = colors.RED;
});
*/
