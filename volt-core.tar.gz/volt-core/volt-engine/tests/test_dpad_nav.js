var _ = require("underscore")._;
var Colors = require("colors");

Volt.addEventListener(Volt.ON_SHOW, function()
{
  var grid = createGrid(5, 5);
  scene.setKeyFocus(grid[0][0]);

  new TextWidget({
    parent: scene,
    x: 0,
    y: scene.height,
    width: scene.width,
    anchor: { x: 0, y: 1 },
    textColor: Colors.WHITE,
    font: "32px",
    text: "Use arrow keys or mouse to move focus",
    horizontalAlignment: "center"
  });
});

function createGrid(numRow, numCol)
{
  var grid = [];
  for (var r = 0; r < numRow; ++r)
  {
    grid.push([]);

    for (var c = 0; c < numCol; ++c)
    {
      grid[r].push(createNavWidget({
        parent: scene,
        x: c * (100 + 20),
        y: r * (100 + 20),
        width: 100,
        height: 100
      }));
    }
  }

  for (var r = 0; r < numRow; ++r)
  {
    for (var c = 0; c < numCol; ++c)
    {
      if (c > 0)
      {
        grid[r][c].nextFocusLeft = grid[r][c - 1];
      }
      if (c != numCol - 1)
      {
        grid[r][c].nextFocusRight = grid[r][c + 1];
      }
      if (r > 0)
      {
        grid[r][c].nextFocusUp = grid[r - 1][c];
      }
      if (r != numRow - 1)
      {
        grid[r][c].nextFocusDown = grid[r + 1][c];
      }
    }
  }

  return grid;
}

function createNavWidget(options)
{
  var widget = new Widget(options);

  widget.nextFocusDown = null;
  widget.nextFocusUp = null;
  widget.nextFocusLeft = null;
  widget.nextFocusRight = null;

  widget.addEventListener("OnFocus", _.bind(function()
  {
    this.color = Colors.RED;
  }, widget));

  widget.addEventListener("OnUnFocus", _.bind(function()
  {
    this.color = Colors.WHITE;
  }, widget));

  widget.addEventListener("OnMouseClick", _.bind(function()
  {
    scene.setKeyFocus(this);
  }, widget));

  widget.addEventListener(Volt.KEY_JOYSTICK_DOWN, _.bind(function(eventData)
  {
    if (eventData.type == Volt.EVENT_KEY_RELEASE) return;

    if (this.nextFocusDown)
    {
      scene.setKeyFocus(this.nextFocusDown);
    }
  }, widget));

  widget.addEventListener(Volt.KEY_JOYSTICK_UP, _.bind(function(eventData)
  {
    if (eventData.type == Volt.EVENT_KEY_RELEASE) return;

    if (this.nextFocusUp)
    {
      scene.setKeyFocus(this.nextFocusUp);
    }
  }, widget));

  widget.addEventListener(Volt.KEY_JOYSTICK_LEFT, _.bind(function(eventData)
  {
    if (eventData.type == Volt.EVENT_KEY_RELEASE) return;

    if (this.nextFocusLeft)
    {
      scene.setKeyFocus(this.nextFocusLeft);
    }
  }, widget));

  widget.addEventListener(Volt.KEY_JOYSTICK_RIGHT, _.bind(function(eventData)
  {
    if (eventData.type == Volt.EVENT_KEY_RELEASE) return;

    if (this.nextFocusRight)
    {
      scene.setKeyFocus(this.nextFocusRight);
    }
  }, widget));

  return widget;
}
