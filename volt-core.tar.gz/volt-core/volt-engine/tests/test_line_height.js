
/*
Test: { 
    instructions : String. instructions to the user
    commands: {
            "left" : Event Handler (Function) for left arrow
            "right": Event Handler (Function)  for right arrow
            "up": Event Handler (Function)  for up arrow
            "down": Event Handler (Function)  for down arrow
    },
    run: Function. Put the test logic here.
}
*/
function main() { 

var englishText = "Lorem ipsum dolor sit amet, zril scripserit ad usu, pri porro docendi reformidans ne.";//id. Eum ea magna eligendi adipiscing. Has in audire vocibus delicata, no sed mollis aliquam civibus, id eius repudiandae qui.An solum incorrupte sit, nibh indoctum ea has. Ex sonet scribentur vix, nihil efficiendi honestatis ius id, postea everti tacimates vim ei. Vis in facete comprehensam, sed postea nonumes ei, in vix fastidii pericula vituperata. Stet brute repudiandae cum et, eam summo partiendo an, cum at erat complectitur. Volutpat imperdiet eum id. Mel constituto intellegebat cu, in vim dissentiet complectitur. Ut nec quando discere, ne modo delicata qualisque his, ea everti atomorum pri.Eum no altera commune, quem verterem est ei. In summo tation laoreet has. Ei nam duis vidisse patrioque, case veritus ex vix, qui tota postea regione eu. Eu sit rebum velit explicari. Saepe tation labore te nam, cum at harum feugait insolens. Prima tation an sea.Nisl omnis sea in, no has aliquip vivendum. An vix modo prompta, ea vel fugit viris blandit. Ut nulla albucius inimicus his. Qui dico omnes in. At docendi sententiae percipitur mei, mel in facilisis incorrupte appellantur.No tota etiam percipitur mei, qui ei nisl fierent. Ex consequat quaerendum definitionem vix, ad delenit suscipit salutatus vis. No odio nibh epicuri quo, tation appareat cum et, id mutat libris dolorum mel. Quot hendrerit vis cu, has ei perpetua philosophia. Sint delenit adipisci usu ut, est nonumy detraxit percipitur id. Mei eu impedit argumentum. No nam inermis honestatis, id officiis facilisi moderatius mei.";
var chineseText = "択物葉新掲最成滋翻掲南出賄海基。門族際室者彦孝現要係井泉。詳滋環変医訓表大教択氏止式著量需良信仮。";  
var chineseTextWithNumber = "<span font='30'>択物葉新�fdsf</span>��最成滋翻掲南出賄海基。門族際室者彦孝現要係� DEFS ��泉。2 詳滋環変医訓表大教択氏止式著量需良信仮。";

    addTest({
        instructions: "Verify Chinese characters and different font sizes are visible.",
        run: function(){
            var textWidget = makeTextWidget({
                text: englishText + chineseTextWithNumber,
                //font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
            });
        }
    });

    addTest({
        instructions: "Move selector around, selector should fit each line perfectly.",
        run: function(context){
            var textWidget = makeTextWidget({
                text: englishText + chineseTextWithNumber,
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
            });
            var currentLine = 0;
            var selector = makeWidget({
                width: 300,
                height: textWidget.getLineHeight(currentLine),
                parent: textWidget,
                color: {r: 0, b:0, g:0, a:0},
                border: {
                        width: 1,
                        color: {r: 255, b:0, g:255}
                },
            });
            context.down = function(){
                selector.y += textWidget.getLineHeight(currentLine);
                currentLine++;
                selector.height = textWidget.getLineHeight(currentLine);
            }
            context.up = function(){
                currentLine--;
                selector.y -= textWidget.getLineHeight(currentLine);               
                selector.height = textWidget.getLineHeight(currentLine);
            }
        }
    });

    addTest({
        instructions: "Move selector around, selector should fit each 3 lines perfectly.",
        run: function(context){
            var textWidget = makeTextWidget({
                text: englishText + chineseTextWithNumber + chineseText,
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
            });
            var currentLine = 0;
            var selectorLineHeight = 3;
            var selector = makeWidget({
                width: 300,
                height: textWidget.getLineHeight(currentLine, selectorLineHeight),
                parent: textWidget,
                color: {r: 0, b:0, g:0, a:0},
                border: {
                        width: 1,
                        color: {r: 255, b:0, g:255}
                },
            });
            context.down = function(){
                selector.y += textWidget.getLineHeight(currentLine, currentLine+ selectorLineHeight);
                currentLine += selectorLineHeight;
                selector.height = textWidget.getLineHeight(currentLine, currentLine+ selectorLineHeight);
            }
            context.up = function(){
                currentLine-= selectorLineHeight;
                selector.y -= textWidget.getLineHeight(currentLine, currentLine+ selectorLineHeight);               
                selector.height = textWidget.getLineHeight(currentLine, currentLine+ selectorLineHeight);
            }
        }
    });
    addTest({
        instructions: "Move selector around, selector should fit each 3 lines perfectly.",
        run: function(){
            var tw = makeTextWidget({
                width: 200,
                font: "30px",
                text: ""
            });
            log( tw.getLineHeight( -1 ) === 0 );
            log( tw.getLineHeight( 400 ) === 0 );
            log(tw.getLineHeight(0,0) === 0);
            log(tw.getLineHeight(-1,1) === 0);
            log(tw.getLineHeight(0,1) !== 0);
            log(tw.getLineHeight(1, 1) === 0);
            log(tw.getLineHeight(0, 43) === 0);
            log(tw.getLineHeight(1, 0) === 0);
            log("Poor mans unit tests. If all are true then PASS");
        }
    });

    addTest({
        instructions: "The following number should be the correct number of lines",
        run: function(){
            var tw = makeTextWidget({
                text: englishText + chineseTextWithNumber,
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
            });
            log(tw.getHeightInLines());
        }
    });
    addTest({
        instructions: "The following number should be the correct number of lines minus 1 (auto fit quirk)",
        run: function(){
            var tw = makeTextWidget({
                text: englishText + chineseTextWithNumber,
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            log(tw.getHeightInLines());
        }
    });
     addTest({
        instructions: "The following number should be the correct number of lines that could fit",
        run: function(){
            var tw = makeTextWidget({
                text: englishText + chineseTextWithNumber,
                font: "20px",
                width: 300,
                height: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
            });
            log(tw.getHeightInLines());
        }
    });
     addTest({
        instructions: "The following number should look like the correct number of lines that could fit",
        run: function(){
            var tw = makeTextWidget({
                font: "20px",
                width: 300,
                height: 100,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
            });
            log(tw.getHeightInLines());
        }
    });
     addTest({
        instructions: "The following number should be apparently be 1",
        run: function(){
            var tw = makeTextWidget({
                //font: "20px",
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
            });
            log(tw.getHeightInLines());
        }
    });

    addTest({
        instructions: "Text should have 3 visible lines. The heightInLines should be 3.",
        run: function(){
            tw = makeTextWidget({
                text: englishText + chineseTextWithNumber,
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                maxLines : 3,
                lineSpacing: 5
            });
            log("heightInLines:" + tw.getHeightInLines());
        }
    });
    addTest({
        instructions: "There should be 4 lines, and what looks like room for another line",
        run: function(){
            tw = makeTextWidget({
                text: englishText,
                font: "20px",
                width: 300,
                maxLines: 5,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
        }
    });
     addTest({
        instructions: "This should be the same size as before, with room for 5 lines",
        run: function(){
            tw = makeTextWidget({
                font: "20px",
                width: 300,
                maxLines: 5,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
        }
    });

    addTest({
        instructions: "This text widget should be height 0",
        run: function(){
            tw = makeTextWidget({
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            tw.setHeightInLines(-3);
        }
    });

    addTest({
        instructions: "This text widget should be height 0",
        run: function(){
            tw = makeTextWidget({
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            tw.setHeightInLines(0);
        }
    });

    addTest({
        instructions: "This text widget should be perfectly fit, including line spacing",
        run: function(){
            tw = makeTextWidget({
                text: chineseTextWithNumber,
                font: "20px",
                width: 300,
                height: 20,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            tw.height += tw.getTextOverflow();
        }
    });
    addTest({
        instructions: "This text widget should be perfectly fit, including line spacing",
        run: function(){
            tw = makeTextWidget({
                text: chineseTextWithNumber,
                font: "20px",
                width: 300,
                height: 6000,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            tw.height += tw.getTextOverflow();
        }
    });

    addTest({
        instructions: "This text widget should be perfectly fit, including line spacing",
        run: function(){
            tw = makeTextWidget({
                text: chineseTextWithNumber,
                font: "20px",
                width: 300,
                maxLines: 5,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            tw.height += tw.getTextOverflow();
        }
    });

    addTest({
        instructions: "Should fit the widget successfully using by adjusting overflow lines.",
        run: function(context){
            tw = makeTextWidget({
                text: chineseTextWithNumber,
                font: "20px",
                width: 300,
                height: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            log("Overflow lines: " + tw.getTextOverflowLines());
            log("Press down to start test");
            context.down = function(){
                log("Setting lines to: " + (tw.getHeightInLines() + Math.ceil(tw.getTextOverflowLines())) ); //ceil is floor when negative numbers
                tw.setHeightInLines(tw.getHeightInLines() + Math.ceil(tw.getTextOverflowLines()));
            };
        }
    });

    addTest({
        instructions: "Should report correct overflow in lines",
        run: function(){
            tw = makeTextWidget({
                text: chineseTextWithNumber,
                font: "20px",
                width: 300,
                height: 150,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            log("Overflow in Lines: " + tw.getTextOverflowLines())
        }
    });

    addTest({
        instructions: "Should report no overflow in lines",
        run: function(){
            tw = makeTextWidget({
                text: chineseTextWithNumber,
                font: "20px",
                width: 300,
                maxLines: 5,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            log("Overflow in Lines: " + tw.getTextOverflowLines())
        }
    });

    addTest({
        instructions: "Should report fractional overflow due to line spacing + auto fit quirk",
        run: function(){
            tw = makeTextWidget({
                text: chineseTextWithNumber,
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                lineSpacing: 5
            });
            log("Overflow in Lines: " + tw.getTextOverflowLines())
        }
    });

    addTest({
        instructions: "Should be able to scroll left and right between characters",
        run: function(context){
            tw = makeTextWidget({
                text: englishText + chineseText,
                font: "20px",
                width: 300,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
               lineSpacing: 5
            });
            var characterIndex = 0;
            var startingDim = tw.getCharDimensions(characterIndex);

            highlight = makeWidget({
                parent: tw,
                width: startingDim.x,
                height: startingDim.y,
                border: {
                        width: 1,
                        color: {r: 255, b:255, g:255}
                },
                color: {
                    r:0, b:0, g:0, a:0
                }
            });

            context.right = function(){
                characterIndex++;
                var coord = tw.coordinateAtCharIndex(characterIndex);
                var dims = tw.getCharDimensions(characterIndex);
                highlight.x = coord.x;
                highlight.y = coord.y;
                highlight.width = dims.x;
                highlight.height = dims.y;
                log(characterIndex);
                log(dims.x + " " + dims.y);
            }

            context.left = function(){
                characterIndex--;
                var coord = tw.coordinateAtCharIndex(characterIndex);
                var dims = tw.getCharDimensions(characterIndex);
                highlight.x = coord.x;
                highlight.y = coord.y;
                highlight.width = dims.x;
                highlight.height = dims.y;
            }
        }

    });

}

var mockFoundation = new Widget({
    width : scene.width,
    height: scene.height,
    color : {r:0, g:0, b:0, a:0}
});
scene.addChild(mockFoundation);
var currentTest;
var testNum =0;
var tests = [];

var output = new TextWidget({
    y: 50,
    x: 50,
    text: "",
    width: 400,
    parent: scene,
    font: "16px"
});

function log(txt){
    output.text += txt + "\n";
};

function clearLog(){
    output.text = "";
}

function makeTextWidget(options){
    if(! options.parent || options.parent === scene)
    {
        options.parent = mockFoundation;
        options.anchor = 0.5;
        options.origin = 0.5;
    }
    return new TextWidget(options);
}

function makeWidget(options){
    if(! options.parent || options.parent === scene)
    {
        options.parent = mockFoundation;
        options.anchor = 0.5;
        options.origin = 0.5;
    }
    return new Widget(options);
}

Volt.addEventListener(Volt.KEY_JOYSTICK_LEFT, function(event){
    if(event.type === Volt.EVENT_KEY_RELEASE) return;
    if(currentTest && currentTest.command && currentTest.command.left)
    {
        currentTest.command.left();
    }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_RIGHT, function(event){
    if(event.type === Volt.EVENT_KEY_RELEASE) return;
    if(currentTest && currentTest.command && currentTest.command.right)
    {
        currentTest.command.right();
    }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event){
    if(event.type === Volt.EVENT_KEY_RELEASE) return;
    if(currentTest && currentTest.command && currentTest.command.up)
    {
        currentTest.command.up();
    }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event){
    if(event.type === Volt.EVENT_KEY_RELEASE) return;
    if(currentTest && currentTest.command && currentTest.command.down)
    {
        currentTest.command.down();
    }
});

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event){
    if( event.type === Volt.EVENT_KEY_RELEASE ) return;
    if( currentTest ){
        tearDownTest();
    }
    if( testNum < tests.length ) {
        runTest(tests[testNum]);
        ++testNum;
    }
 });


function runTest(test){
    currentTest = test;
    log(test.instructions);
    currentTest.command = {
        up: null, down: null, right: null, left: null
    }
    test.run( currentTest.command );
}

function tearDownTest(){
    clearLog();
    mockFoundation.destroyChildren();
    currentTest = null;
}

function addTest(test) {
    tests.push(test);
}

main();


