var outer = new Widget({
	width: 500,
	height: 500,
	color: {r:255, g:0, b:0},
	parent:scene
});

var inner = new Widget({
	width: 200,
	height: 200,
	color: {r:0, g:255, b:0},
	parent: outer
});

inner.roundedCorners = {
	radius: 0,
	arcStep: 5
};

outer.border = {width: 5, color: {r:0, b:255, g:0} };

//animation to test most of keyframable properties
var anim = new Animation(3000);
anim.addKey(0.5, "rotation.y", 180);
anim.addKey(0.5, "x", 500);
anim.addKey(0.5, "y", 0);
anim.addKey(1, "x", scene.width/2);
anim.addKey(1, "y", scene.height/2);
anim.addKey(0.9, "scale.x", 0.1);
anim.addKey(0.9, "scale.y", 0.1);
anim.addKey(1,"scale", {x: 2, y: 2});
anim.addKey(0.5, "opacity", 50);
anim.addKey(1, "opacity", 255);
anim.addKey(1, "roundedCorners.radius", 100);
anim.addKey(1, "border.color",{r:255, g:255, b:255});
anim.addKey(0.1, "color.r", 255); 

function onKeyEvent(keycode)
{
   switch(keycode)
   {
   case 32: OnSpacebar(); break;
   case Volt.KEY_RETURN : OnSpacebar(); break;
   }
}

function OnSpacebar()
{
	inner.animate(anim, function() {
		outer.animate(anim);
	});
}

function OnLeftArrow()
{
}

function OnRightArrow()
{

}

function OnUpArrow()
{

}

function OnDownArrow()
{
	
}

