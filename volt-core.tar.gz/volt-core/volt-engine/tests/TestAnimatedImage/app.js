var animImage1 = new Image({
    uri:"long.gif",
    async:true
});

var animImage2 = new Image({
    uri:"Ceric2.gif",
    async:true
});

var animImage3 = new Image({
    uri:"playonce.gif",
    async:true,
    onGifComplete: function() {
        var x = new Widget({
            parent: scene,
            x:49, y:700, width:250, height: 26,
            color: {r:255, g:255, b:255, a:64},
            border: {width: 2, color: {r:255, g:255, b:255, a:255} }
        });
        }
});

var animImage4 = new Image({
    uri:"playcontinuous.gif",
    async:true,
    success: function() {
        print("loaded playcontinuous.gif");
        Volt.setTimeout(
            function() {
                animImage4.pauseGifAnimation();
                Volt.setTimeout(
                    function() {
                        animImage4.resumeGifAnimation();
                        },
                3000);
            },
            2000);
        }
    });

var animImageWidget1 = new ImageWidget({
    x:50,
    y:50,
    src: animImage1,
    parent: scene
    });

var animImageWidget2 = new ImageWidget({
    x:600,
    y:50,
    src: animImage2,
    parent: scene
    });

var animImageWidget3 = new ImageWidget({
    x:50,
    y:700,
    src: animImage3,
    parent: scene,
    });


var animImageWidget4 = new ImageWidget({
    x:600,
    y:700,
    src: animImage4,
    parent: scene
    });


var animImageWidget5 = new ImageWidget({
    x:1200,
    y:50,
    src: animImage2,
    parent: scene
    });

// This tests setting a src of an ImageWidget to a URL of an animated GIF.
// It will load and only display the first frame for backwards compatibility
//var animImageWidget6 = new ImageWidget({
//    x:50,
//    y:750,
//    src: "long.gif",
//    parent: scene
//    });


var onKeyEvent = function(key_code, type)
{
  if (type == Volt.EVENT_KEY_RELEASE)
    return;

  var event = null;
  switch (key_code)
  {
  case Volt.KEY_PLAY:
      print("Key Play");
      animImage2.resumeGifAnimation();
     break;
  case Volt.KEY_STOP:
      print("Key Stop");
      animImage2.pauseGifAnimation();
    break;

  case Volt.KEY_JOYSTICK_RIGHT:
      animImage4.rewindGifAnimation();
      break;

  case Volt.KEY_JOYSTICK_LEFT:
      animImage1.pauseGifAnimation();
      animImage1.rewindGifAnimation();
      break;

  case Volt.KEY_JOYSTICK_UP:
      animImage1.resumeGifAnimation();
    break;
  }
}

