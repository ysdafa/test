var colors = require("colors");

var TextboxCount = 1;

var width = 180;
var height = 140;

createTextWithBackground("<i>Hello</i> <b>world</b>! This text should have bold, italics, and be horizontally centered!", width , height, "center");
var top = createTextWithBackground("This text should have the same alignment as the last one.", width , height, "center", "top");
createTextWithBackground("Here is some sample text that should all be visible");
createTextWithBackground("Here is some sample text that should take up a couple lines", 100, 110);
var middle = createTextWithBackground("This texts should be horizontally and vertically centered.", width , height, "center", "center");
var bottom = createTextWithBackground("This texts should be horizontally centered and vertically at the bottom.", width , height, "center", "bottom");

var externalResizeTest = createTextWithBackground("This texts should be horizontally and vertically centered.", width , height, "center", "center");
var widget = new Widget({
	origin: {x: 0.3, y: 0.7},
	anchor: {x:0.5, y:0.5},
	width: width * 2,
	height : height * 2,
	parent: scene,
	color: colors.RED
});
externalResizeTest.parent = widget;
externalResizeTest.origin = {x:0, y:0};


function createTextWithBackground(theText, width , height, halign, valign)
{

	halign = halign || "left";
	valign = valign || "top";

	var text = new TextWidget({
		text: theText,
		parent: scene,
		anchor: {x: 0.5, y:0.5},
		origin: {x: TextboxCount * 0.1, y:TextboxCount * 0.1},
		verticalAlignment : valign
	});
	text.horizontalAlignment = halign;

	if(width)
		text.width = width;
	if(height)
		text.height = height;

	//if(valign)
	//	text.verticalAlignment = valign;

	text.border = {
		width: 2,
		color: colors.GREEN
	};

	TextboxCount++;

	return text;
}


function onKeyEvent(keycode)
{
	switch(keycode)
	{
	case Volt.KEY_JOYSTICK_DOWN:
		bottom.animate("height", bottom.height/2, 1000);
		externalResizeTest.animate("height", externalResizeTest.height/2, 1000);
		middle.height = middle.height - 5;
		widget.animate("height", widget.height/2, 1000);
		break;
	case Volt.KEY_JOYSTICK_RIGHT:
		bottom.animate("width", bottom.width/2, 1000);
		externalResizeTest.animate("width", externalResizeTest.width/2, 1000);
		middle.width = middle.width - 5;
		widget.animate("width", widget.width/2, 1000);
		break;

	case Volt.KEY_JOYSTICK_LEFT:
		bottom.animate("width", bottom.width*2, 1000);
		externalResizeTest.animate("width", externalResizeTest.width*2, 1000);
		middle.width = middle.width + 5;
		widget.animate("width", widget.width*2, 1000);
		break;

	case Volt.KEY_JOYSTICK_UP:
		bottom.animate("height", bottom.height*2, 1000);
		externalResizeTest.animate("height", externalResizeTest.height*2, 1000);
		middle.height = middle.height + 5;
		widget.animate("height", widget.height*2, 1000);
		break;


	case Volt.KEY_RETURN:
	case 32:
		bottom.text = "fsdfsdfff fdsfsdfsddsf fdsfsfd fsf fdsf sd fsdffsd fdfdf fsdfsdf fsfsd fsd ff sdfsd fsd fsfsdfsfsdfsdf sffs";
		break;
	}
}

