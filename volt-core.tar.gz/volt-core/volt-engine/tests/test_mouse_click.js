
//Logging logic
var logDisplay1 = new TextWidget({
    text: "",
    width: 400,
    height: 800,
    parent: scene,
    origin: {x: 0.1, y: 0.25},
font: "20px"
});

//Logging logic
var logDisplay2 = new TextWidget({
    text: "",
    width: 400,
    height: 800,
    parent: scene,
    origin: {x: 0.4, y: 0.25},
font: "20px"
});

//Logging logic
var logDisplay3 = new TextWidget({
    text: "",
    width: 400,
    height: 800,
    parent: scene,
    origin: {x: 0.8, y: 0.25},
font: "20px"
});

function log(widget, string) {
    widget.text = string + '\n' + widget.text;
}

var widget = new Widget({
  width: 300,
  height: 300,
  parent: scene
  });


function hookupEvents( widget, name )
{
  widget.addEventListener("OnMouseDown", function(widget, eventData)
  {
    log(logDisplay1, "MouseDown " + name);
  });

  widget.addEventListener("OnMouseUp", function(widget, eventData)
  {
    log(logDisplay2, "MouseUp " + name);

  });

  widget.addEventListener("OnMouseMove", function(widget, eventData)
  {
    log(logDisplay3, "MouseMove " + name + ": " + eventData.coordinates.x + " " + eventData.coordinates.y);
  });
}



hookupEvents( widget, "widget" );
hookupEvents( scene, "scene" );
