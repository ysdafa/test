var imagePath = "http://105.64.202.159/volt/test_small.jpg"
//var imageObj = new Image({ uri:imagePath, async:true });

var imageWidget = new ImageWidget({
	src: "dog.jpg",
	parent: scene,
	origin: 0.5,
	anchor: 0.5
});

//var imageWidget = new ImageWidget({
//	src: "http://105.64.202.159/volt/test_small.jpg",
//	parent: scene,
//	origin: 0.5,
//	anchor: 0.5
//});

//var imageWidget2= new ImageWidget({
//    width: 100,
//    height: 100,
//    src: imageObj
//});
//var imageWidget3= new ImageWidget({
//    width: 100,
//    height: 100,
//    src: imageWidget2.src
//});

function testGc()
{
//  var imageWidgetGc= new ImageWidget({
//  width: 100,
//  height: 100,
//  src: "http://105.64.202.159/volt/test_small.jpg"
//  });
	
	var imageObjGc = new Image({ uri:imagePath, async:true });

//	var imageObjGc = new Image("dog.jpg");
}

function onKeyEvent(event, type) {
	if (type != Volt.EVENT_KEY_PRESS)  return;

//	if(imageWidget1 != null)
//	{
//		imageWidget1.destroy();
//		imageWidget1 = null;
//	}
//
//	if(imageObj != null)
//	{
//	  imageObj.destroy();
//	  imageObj = null;
//	}
//
//	if(imageWidget2 != null)
//	{
//		imageWidget2.destroy();
//		imageWidget2 = null;
//	}
	
	testGc();
	gc();
}
