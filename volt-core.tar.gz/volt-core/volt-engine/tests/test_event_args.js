var textWidget;

var argsToString = function(args, indent)
{
  indent = indent || "";

  var text = "";
  for (var key in args)
  {
    if (typeof args[key] === "object")
    {
      if (args[key] instanceof ArrayBuffer)
      {
        text += indent + key + ":arraybuffer = ";

        var array = new Uint8Array(args[key]);
        if (array.length > 0)
        {
          for (var index = 0; index < array.length; ++index)
          {
            text += (array[index] < 0x10 ? "0" : "") + array[index].toString(16) + " ";
          }
        }

        text += "\n";
      }
      else
      {
        text += indent + key + ":" + (typeof args[key]) + "\n";
        text += argsToString(args[key], indent + "  ");
      }
    }
    else
    {
      text += indent + key + ":" + (typeof args[key]) + " = " + args[key] + "\n";
    }
  }

  return text;
}

var printArgs = function(args, indent)
{
  textWidget.text = argsToString(args, indent);
}

Volt.addEventListener(Volt.ON_LOAD, function(args)
{
  var widget = new Widget({
    parent: scene,
    x: 0,
    y: 0,
    width: 300,
    height: 300,
    origin: { x: 0.5, y: 0.5 },
    anchor: { x: 0.5, y: 0.5 },
    color: { r: 0, g: 0, b: 255 }
  });

  var anim = new Animation(1000, -1);
  anim.addRelativeKey(1, "rotation.y", 360);
  widget.animate(anim);

  textWidget = new TextWidget({
    parent: scene,
    font: "24px"
  });

  print("In ON_LOAD");
  printArgs(args, "  ");
});

Volt.addEventListener(Volt.ON_SHOW, function(args)
{
  print("In ON_SHOW");
  printArgs(args, "  ");
});

Volt.addEventListener(Volt.ON_PAUSE, function(args)
{
  print("In ON_PAUSE");
  printArgs(args, "  ");
});

Volt.addEventListener(Volt.ON_RESUME, function(args)
{
  print("In ON_RESUME");
  printArgs(args, "  ");
});
