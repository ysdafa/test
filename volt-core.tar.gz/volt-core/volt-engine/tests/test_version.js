Volt.addEventListener(Volt.ON_SHOW, function()
{
  var version = Volt.getVersion();

  var text = "Version: " + version.string + "\n" +
             "  Major: " + version.major + "\n" +
             "  Minor: " + version.minor + "\n" +
             "  Patch: " + version.patch;

  new TextWidget({
    parent: scene,
    font: "48px",
    text: text,
    anchor: { x: 0.5, y: 0.5 },
    origin: { x: 0.5, y: 0.5 }
  });
});
