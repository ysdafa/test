var colors = require("colors");

var max_tilt = 10;
var max_shift_percent = 10;

var zoom_anim_time = 200;
var zoom_scale = 1.15;


//Test setup
Volt.addEventListener(Volt.ON_SHOW, function()
{
  var options = {
    width: 400,
    height: 400,
    color: colors.RED,
    parent: scene
  };

  var topLeft = new Widget(options);

  var topRight = new Widget(options);
  topRight.origin.x = 0.5;

  var bottomLeft = new Widget(options);
  bottomLeft.origin.y = 0.5;

  var bottomRight = new Widget(options);
  bottomRight.origin = 0.5;

  makeMouseTiltable(topLeft);
  makeMouseTiltable(topRight);
  makeMouseTiltable(bottomLeft);
  makeMouseTiltable(bottomRight);
});


//Tilt effect implementation:

function makeMouseTiltable(widget) {

  widget.addEventListener("OnMouseMove", function(widget, event) {
    applyTilt(widget, getTilt(widget, event.coordinates))
  });

  widget.addEventListener("OnMouseOut", function(widget, event) {
    clearTilt(widget);
  });
}

function applyTilt(widget, tilt) {
  //Apply tilt and small position shift
  widget.rotation = {
    x: max_tilt * tilt.y,
    y: max_tilt * -tilt.x,
    z: 0
  }
  widget.anchor = {
    x : tilt.x * (max_shift_percent / 100),
    y : tilt.y * (max_shift_percent / 100)
  }
}

function clearTilt(widget) {
  //widget.animate("rotation", {x: 0, y:0, z:0}, zoom_anim_time);
  //widget.animate("anchor", {x: 0, y:0}, zoom_anim_time);
  widget.rotation = {x: 0, y:0, z:0};
  widget.anchor = {x: 0, y:0};
}

function getTilt(widget, mouseScreenCoords) {

  //Get the screen abs position of the widget's center
  if(!widget.originalCenter) { 
    var widgetScreenCenter = widget.getPositionOnScreen();
    var anchor = widget.anchor;
    widgetScreenCenter.x +=  widget.width/2 - (anchor.x * widget.width);
    widgetScreenCenter.y +=  widget.height/2 - (anchor.y * widget.height);
    widget.originalCenter = widgetScreenCenter; //(getPositionOnScreen is expensive, so memoize the resutls)
  }

  if(!widget.halfDim) {
    widget.halfDim = {};
    widget.halfDim.width = widget.width/2;
    widget.halfDim.height = widget.height/2;
  }

  var x = (widget.originalCenter.x - mouseScreenCoords.x) / widget.halfDim.width;
  var y = (widget.originalCenter.y - mouseScreenCoords.y) / widget.halfDim.height;

  if(x > 1 || y > 1 || y < -1 || x < -1) 
    return {
      x: 0,
      y:0
    };
  else return {
    x: x, 
    y: y
  };
}