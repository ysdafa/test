/*jshint evil: true */
var root_widget, rect_widget, text_widget;
var modes = [ "Position", "Rotation", "Pivot", "Scale", "Depth", "Opacity" ];
var mode_index = 0;

function animateRotation(keycode)
{
  switch(keycode)
  {
    case Volt.KEY_JOYSTICK_UP:
      rect_widget.animate("rotation.x", rect_widget.rotation.x + 180, 2500, updateText);
      break;
    case Volt.KEY_JOYSTICK_DOWN:
      rect_widget.animate("rotation.x", rect_widget.rotation.x - 180, 2500, updateText);
      break;
    case Volt.KEY_JOYSTICK_LEFT:
      rect_widget.animate("rotation.y", rect_widget.rotation.y - 180, 2500, updateText);
      break;
    case Volt.KEY_JOYSTICK_RIGHT:
      rect_widget.animate("rotation.y", rect_widget.rotation.y + 180, 2500, updateText);
      break;
    default:
      print("Unhandled event: " + keycode);
      break;
  }
}

function animateScale(keycode)
{
  switch(keycode)
  {
    case Volt.KEY_JOYSTICK_UP:
      rect_widget.animate("scale.y", rect_widget.scale.y + 0.1, 500, updateText);
      break;
    case Volt.KEY_JOYSTICK_DOWN:
      rect_widget.animate("scale.y", rect_widget.scale.y - 0.1, 500, updateText);
      break;
    case Volt.KEY_JOYSTICK_LEFT:
      rect_widget.animate("scale.x", rect_widget.scale.x - 0.1, 500, updateText);
      break;
    case Volt.KEY_JOYSTICK_RIGHT:
      rect_widget.animate("scale.x", rect_widget.scale.x + 0.1, 500, updateText);
      break;
    default:
      print("Unhandled event: " + keycode);
      break;
  }
}

function animatePosition(keycode)
{
  switch(keycode)
  {
    case Volt.KEY_JOYSTICK_UP:
      rect_widget.animate("y", rect_widget.y - 100, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_DOWN:
      rect_widget.animate("y", rect_widget.y + 100, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_LEFT:
      rect_widget.animate("x", rect_widget.x - 100, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_RIGHT:
      rect_widget.animate("x", rect_widget.x + 100, 1000, updateText);
      break;
    default:
      print("Unhandled event: " + keycode);
      break;
  }
}

function animateDepth(keycode)
{
  switch(keycode)
  {
    case Volt.KEY_JOYSTICK_UP:
    case Volt.KEY_JOYSTICK_RIGHT:
      rect_widget.animate("depth", rect_widget.depth + 100, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_DOWN:
    case Volt.KEY_JOYSTICK_LEFT:
      rect_widget.animate("depth", rect_widget.depth - 100, 1000, updateText);
      break;
    default:
      print("Unhandled event: " + keycode);
      break;
  }
}

function animateOpacity(keycode)
{
  switch(keycode)
  {
    case Volt.KEY_JOYSTICK_UP:
    case Volt.KEY_JOYSTICK_RIGHT:
      rect_widget.animate("opacity", rect_widget.opacity + 5, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_DOWN:
    case Volt.KEY_JOYSTICK_LEFT:
      rect_widget.animate("opacity", rect_widget.opacity - 5, 1000, updateText);
      break;
    default:
      print("Unhandled event: " + keycode);
      break;
  }
}

function animatePivot(keycode)
{
  switch(keycode)
  {
    case Volt.KEY_JOYSTICK_UP:
      rect_widget.animate("pivot.y", rect_widget.pivot.y - 0.1, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_DOWN:
      rect_widget.animate("pivot.y", rect_widget.pivot.y + 0.1, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_LEFT:
      rect_widget.animate("pivot.x", rect_widget.pivot.x - 0.1, 1000, updateText);
      break;
    case Volt.KEY_JOYSTICK_RIGHT:
      rect_widget.animate("pivot.x", rect_widget.pivot.x + 0.1, 1000, updateText);
      break;
    default:
      print("Unhandled event: " + keycode);
      break;
  }
}

function onKeyEvent(keycode,type)
{
    if (type == Volt.EVENT_KEY_RELEASE)
      return;
  switch(keycode)
  {
    case Volt.KEY_RETURN:
    case Volt.KEY_EXIT:
      print("Exiting...");
      Volt.exit();
      break;
    case Volt.KEY_JOYSTICK_OK:
      ++mode_index;
      if (mode_index >= modes.length) mode_index = 0;
      break;
    case Volt.KEY_RED:
      rect_widget.x = root_widget.width / 2;
      rect_widget.y = root_widget.height / 2;
      rect_widget.rotation.x = rect_widget.rotation.y = 1;
      rect_widget.pivot.x = rect_widget.pivot.y = 1;
      rect_widget.scale.x = rect_widget.scale.y = 1;
      rect_widget.depth = 0;
      rect_widget.opacity = 255;
      break;
    default:
      print("Calling animate" + modes[mode_index]);
      eval("animate" + modes[mode_index] + "(" + keycode + ");");
      break;
  }
  updateText();
}

function updateText()
{
  text_widget.text = "Animate: " + modes[mode_index] + "\n";
  text_widget.text += "Position: " + rect_widget.x.toFixed(2) + ", " + rect_widget.y.toFixed(2) + "\n";
  text_widget.text += "Rotation: " + rect_widget.rotation.x.toFixed(2) + ", " + rect_widget.rotation.y.toFixed(2) + "\n";
  text_widget.text += "Pivot: " + rect_widget.pivot.x.toFixed(2) + ", " + rect_widget.pivot.y.toFixed(2) + "\n";
  text_widget.text += "Scale: " + rect_widget.scale.x.toFixed(2) + ", " + rect_widget.scale.y.toFixed(2) + "\n";
  text_widget.text += "Depth: " + rect_widget.depth.toFixed(2) + "\n";
  text_widget.text += "Opacity: " + rect_widget.opacity.toFixed(2) + "\n";
}

var initialize = function()
{
  root_widget = new Widget(0, 0);
  root_widget.parent = scene;
  root_widget.width = 1920;
  root_widget.height = 1080;
  root_widget.color = { r:0, g:0, b:0, a:255 };

  rect_widget = new Widget({ x: root_widget.width / 2, y: root_widget.height / 2, width: 500, height: 500 });
  rect_widget.color = { r:255, g:0, b:0, a:255 };

  var image = new ImageWidget({ x:0, y:0, width:500, height:500, src:"dog.jpg" });

  var text_bg = new Widget({ x: 0, y: 0, width:rect_widget.width, height: 320 });
  text_bg.color = { r:22, g:22, b:22, a:200 };

  text_widget = new TextWidget({ x: 0, y: 0, width: text_bg.width, height: text_bg.height });
  text_widget.font = "Helvetica 35px";
  text_widget.color = { r:155, g:155, b:155, a:255 };
  updateText();

  root_widget.addChild(rect_widget);
  rect_widget.addChild(image);

  rect_widget.addChild(text_bg);
  text_bg.addChild(text_widget);
};
