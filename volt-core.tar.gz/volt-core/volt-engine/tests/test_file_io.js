var text;

var test_read = function(path)
{
  text.text += "Reading " + path + "... ";
  var req = new ResourceRequest({
    uri: path,
    method: "GET",
    async: false,
    //success: function (data) { text.text += "OK\n    Read: " + data + "\n"; },
    success: function () { text.text += "OK\n"; },
    error: function () { text.text += "FAIL\n"; }
  });
  req.process();
}

var test_write = function(path)
{
  text.text += "Writing to " + path + "... ";
  var req = new ResourceRequest({
    uri: path,
    method: "PUT",
    async: false,
    data: "this is a test string",
    success: function () { text.text += "OK\n"; },
    error: function () { text.text += "FAIL\n"; }
  });
  req.process();
}

var test_delete = function(path)
{
  text.text += "Deleting " + path + "... ";
  var req = new ResourceRequest({
    uri: path,
    method: "DELETE",
    async: false,
    success: function () { text.text += "OK\n"; },
    error: function () { text.text += "FAIL\n"; }
  });
  req.process();
}

var test_io = function(path)
{
  text.text += "==============================================\n";

  test_write(path);
  test_read(path);
  test_delete(path);

  text.text += "==============================================\n";
}

Volt.addEventListener(Volt.ON_SHOW, function()
{
  text = new TextWidget({ width: scene.width, height: scene.height, parent: scene });
  text.text = "Testing File IO\n";

  test_io("file://$VOLT_ROOT/test.txt");
  test_io("file://$APP_ROOT/test.txt");
  test_io("file://$APP_DATA/test.txt");

  text.text += "==============================================\n";
  test_read("file://$VOLT_ROOT/empVolt.xml");
  text.text += "==============================================\n";
  test_delete("file://$VOLT_ROOT/empVolt.xml");
  text.text += "==============================================\n";
});
