var colors = require("colors");

makeFocusTestWidget(300, 200, "test1");

makeFocusTestWidget(300, 500, "test2");

makeFocusTestWidget(300, 800, "test3");

Volt.addEventListener(Volt.KEY_9, function(eventData){
    if(eventData.type == Volt.EVENT_KEY_PRESS) return;

    var target = scene.getKeyFocus();
    target.destroy();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(eventData){
    if(eventData.type == Volt.EVENT_KEY_PRESS) return;

    var target = scene.getKeyFocus();
    target.removeFocusEvents();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(eventData){
    if(eventData.type == Volt.EVENT_KEY_PRESS) return;
    scene.setKeyFocus(scene);
});

function onKeyTest(event) {
    var targetWidget = scene.getKeyFocus();
    if(event.type === Volt.EVENT_KEY_PRESS)
        targetWidget.color = colors.RED;
    else
        targetWidget.color = colors.GREEN;
}

scene.addEventListener(Volt.KEY_JOYSTICK_OK, onKeyTest);
scene.addEventListener("OnUnFocus", function(){
    scene.color = {r:0, g:0, b:0, a:0};
});


function makeFocusTestWidget(x, y, id){

    var widget = new Widget({
        parent: scene,
        width: 200,
        height: 200,
        color : colors.BLUE,
        border: {
            width: 2,
            color: colors.WHITE
        },
        x: x, y: y,
        id: id
    });

    function onFocus(){
        widget.border = {
            width: 4,
            color: colors.BRIGHT_ORANGE
        }
    }

    function onUnfocus(){
        widget.border = { 
            width: 2,
            color: colors.WHITE
        };
        widget.color = colors.BLUE; 
    }


    widget.addEventListener("OnMouseClick", function() {
        if(widget.hasKeyFocus())
        {
            widget.border.color = colors.RED;
            Volt.setTimeout(function(){
                widget.border.color = colors.BRIGHT_ORANGE;
            }, 100);
        }
        scene.setKeyFocus(widget);
    });

    widget.addEventListener("OnFocus", onFocus);

    widget.addEventListener("OnUnFocus", onUnfocus);

    widget.addEventListener(Volt.KEY_0, function(keycode, id){
        scene.clearKeyFocus();
    });

    widget.addEventListener(Volt.KEY_JOYSTICK_OK, onKeyTest);

    widget.removeFocusEvents = function(){
        widget.removeEventListener("OnFocus", onFocus);
        widget.removeEventListener("OnUnFocus", onUnfocus);
        widget.removeEventListener(Volt.KEY_JOYSTICK_OK, onKeyTest);
    }

    return widget;
}





var instructions = new TextWidget({
    origin: {x: 0.6, y: 0.2},
    parent: scene,
    width: 500,
    maxLines: 50,
    text:   "Click a widget to set it in focus.\n" + 
            "When focused, widget borders should turn orange.\n" + 
            "Press ok to change the color of focused widgets. Color changes on both key press and release.\n" + 
            "Press 0 to clear focus.\n" + 
            "Press 9 to destroy the focused element.\n" +
            "Press Up Arrow to shift focus to the scene. Same key events should work.\n" + 
            "Press the Down arrow to remove all focus events from a widget.\n"
});
