var GridComponent = require("GridComponent");

var main;

var initialize = function() {
  main = new Widget({
    width: scene.width,
    height: scene.height,
    parent: scene
  });
  onKeyEvent(1);
};

var onKeyEvent = function(keycode) {
  if (type == Volt.EVENT_KEY_RELEASE)
    return;
  if (keycode == Volt.KEY_EXIT) {
    Volt.exit();
    return true;
  }
  if (keycode == Volt.KEY_JOYSTICK_OK) {
    print("deleting...");
    main.destroyChildren();
    return false;
  }

  main.destroyChildren();

  var initialWidgets = [];

  var onReady = function (){
    print("************* image loaded ****************");
  };
  for (var i = 0; i < 10; i++) {
    initialWidgets.push(new ImageWidget({
      src: "http://105.64.202.159/volt/test_small.jpg",
      onReady: onReady
    }));
  }

  var grid = new GridComponent({
    x: 0,
    y: 0,
    width: scene.width,
    height: scene.height,
    color: {
      r: 0,
      g: 0,
      b: 0,
      a: 255
    },
    parent: main
  }, {
    maxColumns: 10,
    widgets: initialWidgets
  });
};