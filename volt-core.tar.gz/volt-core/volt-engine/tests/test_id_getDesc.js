/*
  See API doc at KingsCanyon/trunk/Documentation/Samsung Widget API.doc
*/

//Test ID removed on deletion:
var widget = new Widget({id: "test"});
widget.destroy();
var pass1Text = "ID reuse test passed";
try {
	widget = new Widget({id: "test"});
} catch (e) {
	pass1Text = "ID reuse test failed";
}

var pass1 = new TextWidget({text: pass1Text, parent: scene, font: "Helvetica 16"});

//Test scene.getDescendent
widget = new Widget({id: "one", parent: scene});
widget2 = new Widget({id: "two", parent: widget});
widget3 = new Widget({id: "three", parent: widget2});
widgetOphan = new Widget({id: "zero"});

var pass2text = ( scene.getDescendent("one") !== null && 
	scene.getDescendent("three") !== null && 
	scene.getDescendent("zero") === null ) ? "scene.getDescendent test passed" : "scene.getDescendent test failed";
var pass2 = new TextWidget({y: 60, text: pass2text, parent: scene, font: "Helvetica 16"});


