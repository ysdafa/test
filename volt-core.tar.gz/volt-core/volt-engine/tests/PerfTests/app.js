var colors = require("colors");

/************Logging logic****************/

var display = new TextWidget({
    width: 300,
    height: 720,
    parent:scene,
    origin:{x:0.8, y:0.1}
});


function log(string) {
    display.text = string + "\n" + display.text;
}

function clear() {
    display.text = "";
}

var instruction = new TextWidget({
    anchor:0.5,
    origin: {x: 0.5, y: 0.8},
    parent:scene,
    font: "15px",
    text: "Select test and click ok to run.\nPress Play to run all tests 10 times"
});

var widget = new Widget({width: 200, y:200, parent: scene});
var widget2 = new Widget({width: 200, y:200, parent: scene});

function time(testFunction) {
    var start = new Date().getTime();
    testFunction();
    var block = widget.x; //do an execute here to block
    var end = new Date().getTime();
    return end - start;
}

var testIndex = 0;
var tests = [];
var testAvgDisplay = [];
var avgTime = [];
var testCount = [];

var currentTestDisplay = -1;

function setCurrentTest(index) {
    if(currentTestDisplay !== -1) {
        var prevTest = testAvgDisplay[currentTestDisplay];
        prevTest.textColor = colors.WHITE;
        prevTest.border = { width : 0, color: {r:0, g:0, b:0, a:0} };
    }

    currentTestDisplay = index;
    var currentTest = testAvgDisplay[currentTestDisplay];
    currentTest.textColor = colors.BRIGHT_ORANGE;
    currentTest.border = {width: 2, color: colors.BRIGHT_ORANGE};
}

function makeTest(message, test){
    tests.push({func: test, msg: message});
    testAvgDisplay.push( new TextWidget({
        origin: { x:0.1, y: 0.1},
        y: (tests.length - 1) * 100,
        font: "20px", 
        width: 700,
        height: 75,
        parent: scene
    }));
    avgTime.push([]);
    testCount.push(0);

    if(currentTestDisplay === -1)
        setCurrentTest(0);
    setTestSummary(tests.length -1, 0, 0);
}

function getAvg(textIndex, testTime) {
    var times = avgTime[testIndex];
    times.push(testTime);
    var sum = 0;
    for(var i = 0; i < times.length; ++i)
        sum += times[i];
    return (sum / times.length).toFixed(2);
}

function setTestSummary(testIndex, avg, count) {
    testAvgDisplay[testIndex].text = tests[testIndex].msg + ":\n" 
                                    + "    Average: " + avg + "\n"
                                    + "    Count: " + count;

}

function runTest(){
    var test = tests[testIndex];
    var testTime = time(test.func);
    log(test.msg + ":" + testTime);
    testCount[testIndex]++;

    setTestSummary(testIndex, getAvg(testIndex, testTime),  testCount[testIndex]);
}

function nextTest(){
    testIndex = (testIndex + 1) % tests.length;
    setCurrentTest(testIndex);
}

function prevTest(){
    testIndex = (testIndex - 1);
    if(testIndex < 0)
        testIndex = tests.length - 1;
    setCurrentTest(testIndex);
}

function runAllTestsNTimes(n){
    for(var i = 0; i < tests.length; ++i) {
        for(var j = 0; j < n; ++j) {
            runTest();
        }
        nextTest();
    }
}

function runAllTestsNTimesWithTimeout(n, timeout, onFinished) {
    var numTests = tests.length;
    var repeatsLeft = n;

    function doTest() {
        if(repeatsLeft === 0) {
            repeatsLeft = n;
            numTests--;
            nextTest();
        }
        runTest();
        repeatsLeft--;

        if(numTests > 0)
            Volt.setTimeout(doTest, timeout);
        else onFinished();
    }

    doTest();
}

Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    runTest();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    nextTest();
});

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    prevTest();
});


Volt.addEventListener(Volt.KEY_PLAY, function(event){
    if (event.type == Volt.EVENT_KEY_RELEASE) return;
    runAllTestsNTimes(10);
});

makeTest("100 x 1Post", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.x = 10; 
    }
});

makeTest("100 x 1Exec", function() {
    for(var i = 0; i < 100; ++i)
    {
        var block = widget.x; 
    }
});

makeTest("100 x 1Post 1Exec", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.x = 10;
        //widget.x = 20;
        //widget.x = 30;
        var block = widget.x; 
    }
});

makeTest("100 x 2Post 1Exec", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.x = 10;
        widget.x = 20;
        //widget.x = 30;
        var block = widget.x; 
    }
});

makeTest("100 x W1-Post W2-Post W1-Exec", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.x = 10;
        widget2.x = 10;
        var block = widget.x; 
    }
});

makeTest("100 x W1-Post W2-Post W1-Exec W2-Exec", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.x = 10;
        widget2.x = 10;
        var block = widget.x; 
        var block2 = widget2.x; 
    }
});

makeTest("300 x 1Post", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.x = 10;
        widget.x = 20;
        widget.x = 30;
    }
    var block = widget.x; 
});

makeTest("100 x 1Animate", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.animate("x", 1, 100);
    }
});

makeTest("100 x 1E-1P-1E-1P", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.animate("x", 1, 100);
    }
});

var anim = new Animation(100);
anim.addProperty("x", 1);
makeTest("100 x 1PremadeAnimates", function() {
    for(var i = 0; i < 100; ++i)
    {
        widget.animate(anim);
    }
});



