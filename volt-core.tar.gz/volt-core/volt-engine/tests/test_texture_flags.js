var animImage1 = new Image({
    uri:"TestAnimatedImage/long.gif",
    async:true,
    noAtlas: false
});

var animImageWidget1 = new ImageWidget({
    x:50,
    y:50,
    src: animImage1,
    parent: scene
    });

var animImage2 = new Image({
    uri: "../examples/dog.jpg",
    async: false,
    noAtlas: false,
    });

var animImageWidget2= new ImageWidget({
    x:50,
    y:400,
    src: animImage2,
    parent: scene
    });

var animImage3 = new Image({
    uri: "../examples/dog3.jpg",
    async: true,
    noAtlas: false
    });

var animImageWidget3= new ImageWidget({
    x:850,
    y:400,
    src: animImage3,
    parent: scene
    });

var animImage4 = new Image({
    uri: "../examples/dog3.jpg",
    async: true
    });

var animImageWidget4= new ImageWidget({
    x:850,
    y:50,
    src: animImage4,
    parent: scene
    });

var animImageWidget5 = new ImageWidget({
    x:500,
    y:50,
    src: "../examples/dog2.jpg",
    parent:scene
    })
