var initialize = function()
{
  var attr = { x: 0, y: 0, width: scene.width, height: 48 };

  var english = new TextWidget(attr);
  english.font = "Helvetica 35px";
  english.text = "Hello, world!";

  attr.y += attr.height;
  var korean = new TextWidget(attr);
  korean.font = "Helvetica 35px";
  korean.text = "안녕하세요 세계!";

  attr.y += attr.height;
  var arabic = new TextWidget(attr);
  arabic.font = "Helvetica 35px";
  arabic.text = "مرحبا، العالم!";

  attr.y += attr.height;
  var chinese_simplified = new TextWidget(attr);
  chinese_simplified.font = "Helvetica 35px";
  chinese_simplified.text = "你好，世界！";

  attr.y += attr.height;
  var chinese_traditional = new TextWidget(attr);
  chinese_traditional.font = "Helvetica 35px";
  chinese_traditional.text = "你好，世界！";

  attr.y += attr.height;
  var spanish = new TextWidget(attr);
  spanish.font = "Helvetica 35px";
  spanish.text = "Hola, mundo!";

  attr.y += attr.height;
  var french = new TextWidget(attr);
  french.font = "Helvetica 35px";
  french.text = "Bonjour tout le monde!";

  attr.y += attr.height;
  var german = new TextWidget(attr);
  german.font = "Helvetica 35px";
  german.text = "Hallo, Welt!";

  attr.y += attr.height;
  var portuguese = new TextWidget(attr);
  portuguese.font = "Helvetica 35px";
  portuguese.text = "Olá, mundo!";

  attr.y += attr.height;
  var italian = new TextWidget(attr);
  italian.font = "Helvetica 35px";
  italian.text = "Ciao, mondo!";

  attr.y += attr.height;
  var thai = new TextWidget(attr);
  thai.font = "Helvetica 35px";
  thai.text = "สวัสดีชาวโลก!";

  scene.addChild(english);
  scene.addChild(korean);
  scene.addChild(arabic);
  scene.addChild(chinese_simplified);
  scene.addChild(chinese_traditional);
  scene.addChild(spanish);
  scene.addChild(french);
  scene.addChild(german);
  scene.addChild(portuguese);
  scene.addChild(italian);
  scene.addChild(thai);
};
