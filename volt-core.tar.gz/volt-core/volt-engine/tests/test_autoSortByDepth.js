var rootWidget = new Widget({
    x:800,
    y:200,
    depth:100,
    parent:scene,
    });

var WIDGET = {
    x:0,
    y:0,
    height: 100,
    width: 100,
    color: {r: 129, g: 10, b:82, a:255},
    depth: 20,

    rotation: {x:0, y:0, z:0},
    horizontalAlignment: "right",
    verticalAlignment: "bottom",
    parent: rootWidget,
};


var helpWidget = new TextWidget({
    origin: {x: 0.0, y:0.8},
    font: "32px",
    text: "Press OK to turn ON auto sort by depth\nPress UP/DOWN to animate\nPress RIGHT to randomize depths.",
    horizontalAlignment: "center",
    parent: scene
    });

var helpWidget = new TextWidget({
    origin: {x: .4, y:0.8},
    font: "32px",
    text: "Depth is computed at center of object so some popping is correct.\nHigher depth values should always cover lower ones.",
    horizontalAlignment: "center",
    parent: scene
    });

var widgets = [];
var seed = 4;
function random() {
    var x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
}

for (i = 0; i < 10; i++)
{
    widgets[i] = new TextWidget(WIDGET);
    widgets[i].depth = 200 - ( 0.5 - random() ) * 300;
    widgets[i].x = 100 + i * 50;
    widgets[i].y = 100 + i * 50;
    if (random() > 0.5)
    {
        widgets[i].color.a = 255;
    }
    widgets[i].color.r = 129 + (0.5 - random()) * 200;
    widgets[i].color.g = 129 + (0.5 - random()) * 200;
   // widgets[i].parent = rootWidget;
    widgets[i].text = "" + widgets[i].getTransformedDepth().toPrecision(3);
    centerMark = new Widget({
      origin: {x:0.5, y:0.5},
      width: 4,
      height: 4,
      parent: widgets[i],
      });
}

scene.color = {r:100, g:100, b:100, a:255 };
//scene.drawWithDepth = true;
//rootWidget.reorderChildrenByDepth();




Volt.addEventListener(Volt.KEY_JOYSTICK_OK, function(event) {
  if(event.type != Volt.EVENT_KEY_PRESS)
    return;
  rootWidget.autoSortChildrenByDepth = !rootWidget.autoSortChildrenByDepth;
  var str;
  if (rootWidget.autoSortChildrenByDepth)
    str = "OFF";
  else
    str = "ON";
  helpWidget.text = "Press OK to turn " + str + " auto sort by depth\nPress UP/DOWN to animate\nPress RIGHT to randomize depths."
  });

Volt.addEventListener(Volt.KEY_JOYSTICK_UP, function(event) {
  if(event.type != Volt.EVENT_KEY_PRESS)
    return;
  targetAngle = rootWidget.rotation.y + 10;
  rootWidget.animate("rotation.y", targetAngle, 500, updateDepthLabels);
  });

Volt.addEventListener(Volt.KEY_JOYSTICK_DOWN, function(event) {
  if(event.type != Volt.EVENT_KEY_PRESS)
    return;
  targetAngle = rootWidget.rotation.y - 10;
  rootWidget.animate("rotation.y", targetAngle, 500, updateDepthLabels);
  });

function updateDepthLabels()
{
  for (i = 0; i < 10; i++)
  {
    widgets[i].text = "" + widgets[i].getTransformedDepth().toPrecision(3);
  }
}

Volt.addEventListener(Volt.KEY_JOYSTICK_RIGHT, function(event) {
  if(event.type != Volt.EVENT_KEY_PRESS)
    return;
  // randomize depths
  for (i = 0; i < 10; i++)
    {
      widgets[i].depth = 200 - ( 0.5 - random() ) * 300;
      widgets[i].text = "" + widgets[i].getTransformedDepth().toPrecision(3);
    }
  });


