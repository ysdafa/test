#ifndef SAMSUNG_KINGSCANYON_TIME_H
#define SAMSUNG_KINGSCANYON_TIME_H

#include <time.h>
#include <sys/time.h>
#include <functional>
#include <string>

namespace volt
{
namespace util
{

class Time
{
  public:
    /** Signature of the time function. */
    static std::function<Time ()> NowFunction;

  public:
    Time();
    Time(const time_t aSec, const suseconds_t aUsec = 0);
    Time(const Time &aSrc);
    ~Time();

    bool IsValid() const;

    time_t Sec() const;
    suseconds_t Usec() const;

    bool ParseHttpTime(const std::string &aHttpTime);
    std::string HttpTimeString() const;

    static Time Epoch();
    static Time Now();

    bool operator<(const Time &aRhs) const;
    bool operator<=(const Time &aRhs) const;
    bool operator>(const Time &aRhs) const;
    bool operator>=(const Time &aRhs) const;
    bool operator==(const Time &aRhs) const;
    bool operator!=(const Time &aRhs) const;

    Time& operator=(const Time &aRhs);
    Time& operator+=(const Time &aRhs);
    Time& operator-=(const Time &aRhs);

    const Time operator+(const Time &aRhs) const;
    const Time operator-(const Time &aRhs) const;

    friend std::ostream& operator<<(std::ostream &aStream, const Time &aTime);

    template<class Archive>
    void serialize(Archive &aArchive, const unsigned int aVersion)
    {
      aArchive & time_.tv_sec;
      aArchive & time_.tv_usec;
      aArchive & valid_;
    }

  private:
    struct timeval time_;
    bool valid_;
};

class Stopwatch
{
  public:
    Stopwatch(const bool &aStart = false):
      running_(false), elapsed_(0)
    {
      timerclear(&start_);
      timerclear(&stop_);

      if (aStart)
      {
        Start();
      }
    }
    ~Stopwatch()
    {
      running_ = false;
    }

    inline void Start()
    {
      if (running_)
      {
        return;
      }

      gettimeofday(&start_, NULL);
      running_ = true;
    }

    inline void Stop()
    {
      if (running_ == false)
      {
        return;
      }

      gettimeofday(&stop_, NULL);
      running_ = false;

      struct timeval elapsed;
      timersub(&stop_, &start_, &elapsed);
      elapsed_ +=  elapsed.tv_sec + (elapsed.tv_usec / 1000000.0);
    }

    inline void Reset()
    {
      elapsed_ = 0;
    }

    inline void Restart()
    {
      Stop();
      Reset();
      Start();
    }

    inline double Elapsed() const
    {
      if (running_)
      {
        struct timeval curr;
        gettimeofday(&curr, NULL);

        struct timeval elapsed;
        timersub(&curr, &start_, &elapsed);
        return elapsed_ + elapsed.tv_sec + (elapsed.tv_usec / 1000000.0);
      }
      else
      {
        return elapsed_;
      }
    }

    friend std::ostream& operator<<(std::ostream &aStream, const Stopwatch &aStopwatch);

  private:
    bool running_;
    double elapsed_;
    struct timeval start_;
    struct timeval stop_;
};

} /* namespace util */
} /* namespace volt */
#endif
