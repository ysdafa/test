/**
 * @file XWindowManager.h
 * @date 8/27/2014
 * @brief ABC for classes that manage the
 * life cycle of windows for Volt
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef X_WINDOW_MANAGER_H_
#define X_WINDOW_MANAGER_H_

#include <string>
#include <libxml++/libxml++.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <clutter/clutter.h>

/**
 * @class XWindowManager
 * @brief x window manager class that will
 * be implemented by subclasses depending on platform(x14,tv,linux,etc)
 * @ref
 *
 */

namespace volt
{
namespace util
{
// interface class for Xwindow manager
class IXWindowManager
{
  public:
    virtual bool Initialize(int aArgc, char **aArgv) = 0;

    virtual bool CreateDisplay() = 0;

    virtual bool CreateWindow(const int aWidth, const int aHeight) = 0;

    virtual bool CreateStage(const int aWidth, const int aHeight,
                             const int aSceneWidth, const int aSceneHeight) = 0;

    virtual bool DestroyDisplay(void) = 0;

    virtual bool DestroyWindow(void) = 0;

    virtual bool DestroyStage(void) = 0;

    virtual void ShowWindow(void) = 0;

    virtual void HideWindow(void) = 0;

    virtual void SetWindowName(const std::string& name) = 0;

    virtual Display* GetDisplay() = 0;

    virtual const Window GetWindow() const = 0;

    virtual ClutterActor *GetStage() = 0;
};

/**
 * Sets the singleton XWindowManager
 * FAILS if one was already created
 * This must be called before GetXWindowManager,
 * otherwise Volt will create one internally
 *
 * @return true on success, false otherwise.
 */
bool SetXWindowManager(IXWindowManager *aManager);

/**
 * Creates the singleton XWindowManager
 * If one has not been set, we will create one
 * based on the platform
 */
IXWindowManager *GetXWindowManager(void);

class XWindowManager : public IXWindowManager
{
  public:
    XWindowManager();

    virtual ~XWindowManager();

    virtual bool Initialize(int aArgc, char **aArgv);

    /**
     * Creates Display structure and establishes connection
     * to X server
     *
     * @return true on success, false otherwise.
     */
    virtual bool CreateDisplay() = 0;

    /**
     * Creates a window for this display
     *
     * @param[in] width Width of the window.
     * @param[in] height height of the window/stage.
     *
     * @return true on success, false otherwise.
     */
    virtual bool CreateWindow(const int width, const int height) = 0;

    virtual bool CreateStage(const int aWidth, const int aHeight,
                             const int aSceneWidth, const int aSceneHeight);

    /**
     * Closes connection to X server and destroys display structure.
     *
     * @return true on success, false otherwise.
     */
    virtual bool DestroyDisplay(void);

    /**
     * Destroys current window for this display
     *
     * @return true on success, false otherwise.
     */
    virtual bool DestroyWindow(void);

    virtual bool DestroyStage(void);

    virtual void SetWindowName(const std::string& name);

    /**
     * Shows the X Window
     */
    virtual void ShowWindow(void);

    /**
     * Hides the X Window
     */
    virtual void HideWindow(void);

    //Accessors
    virtual Display* GetDisplay()
    {
      return m_xdpy;
    }

    virtual const Window GetWindow() const
    {
      return m_xwin;
    }

    virtual ClutterActor *GetStage()
    {
      return m_stage;
    }

  protected:
    //Mutators
    void SetDisplay(Display* const display);

    void SetWindow(Window const windowId);

    /**
     * Initializes the  window attribute structure
     * for the new x window
     *
     * @param[in] visInfo XVisualInfo struct providing visual information
     * for current display
     *
     * @return newly initialized XSetWindowAttributes struct
     */
    XSetWindowAttributes GetWindowAttributes(XVisualInfo* visInfo) const;

  protected:
    Display *m_xdpy;
    Window m_xwin;
    Window m_dummy;
    ClutterActor *m_stage;
    int m_width;
    int m_height;
};
};
};
#endif /* X_WINDOW_MANAGER_H_ */
