#ifndef SAMSUNG_KINGSCANYON_DATA_BUFFER_H
#define SAMSUNG_KINGSCANYON_DATA_BUFFER_H

#include <boost/enable_shared_from_this.hpp>
#include <boost/serialization/list.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/version.hpp>
#include <boost/serialization/split_member.hpp>
#include <boost/serialization/binary_object.hpp>

#include "logger.h"
#include "macros.h"

namespace volt
{
namespace util
{

// this is a wrapper class holding a generic buffer
class DataBuffer : public boost::enable_shared_from_this<DataBuffer>
{
    friend class boost::serialization::access;

  public:
    enum Format
    {
      Unknown,
      Utf8,
      Utf16,
      Ascii,
      Binary,
    };

    static std::string LOGGER_NAME;

    // code for shared pointer
    typedef boost::shared_ptr<DataBuffer> SharedPtr;

    SharedPtr getSharedPtr()
    {
      return shared_from_this();
    }

    // construct with no buffer
    DataBuffer();

    // construct and allocate buffer with length
    DataBuffer(size_t length);

    // construct with an existing buffer to use
    DataBuffer(uint8_t *buffer, size_t length, size_t capacity);

    // construct by COPYING from existing buffer
    DataBuffer(const uint8_t *buffer, size_t length);

    // construct with an existing cstring to use
    DataBuffer(char *text);

    // construct by COPYING from existing cstring
    DataBuffer(const char *text);

    virtual ~DataBuffer();

    // returns the data pointer
    const char* c_str() const;

    // returns the data pointer
    const char* data() const;

    // returns current data length
    size_t length();

    size_t Utf8Length();

    // returns current data length
    size_t size();

    // returns current capacity length
    size_t capacity();

    Format format();

    void SetFormat(Format format);

    // causes the container to increase its capacity to n characters
    // if any buffer already exists, this buffer will be copied and freed
    bool reserve(size_t n);

    // resets the length, IMITATING clearing of buffer
    void clear();

    bool append(const uint8_t* data, size_t length);

    bool append(const char* text);

    // this function overrides existing values without regard for memory leak
    void SetProperty(uint8_t *buffer, size_t length, size_t capacity);

    template<class Archive>
    void serialize(Archive &aArchive, const unsigned int aVersion)
    {
      LOG_DEBUG(logger_, "Version: " << aVersion);

      aArchive & mLength;
      aArchive & mCapacity;
      aArchive & mFormat;

      // we are trying to deserialize
      if(not mBuffer and mCapacity)
      {
        mBuffer = (uint8_t*)malloc(mCapacity);
      }

      aArchive & boost::serialization::make_binary_object(mBuffer, mCapacity);

      LOG_DEBUG(logger_, "Length: " << mLength);
      LOG_DEBUG(logger_, "Capacity: " << mCapacity);
    }

    bool CheckIsUtf8();

  private:

    // disable copying
    DataBuffer(const DataBuffer &other) {};

    // disable copying
    DataBuffer& operator=(const DataBuffer& other)
    {
      return *this;
    };

    uint8_t *mBuffer;

    size_t mLength;

    size_t mCapacity;

    Format mFormat;

    size_t mUtf8Length;

    volt::util::Logger logger_; /**< Logger name. */
};
};
};

#endif
