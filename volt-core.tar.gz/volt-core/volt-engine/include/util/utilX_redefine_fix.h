#pragma once

/* this section MUST match utilX.h definition,
 * we need to redefine this due to the stupid name clash between
 * enum and #define
 */
#define UTILX_KEY_POWER "XF86PowerOff" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Power' key */
#define UTILX_KEY_EXTINPUT "XF86Display" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'TV/External Input Mode' key */
#define UTILX_KEY_HDMI "XF86ExtOutput1" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'HDMI' key */
#define UTILX_KEY_1 "1" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '1' key */
#define UTILX_KEY_2 "2" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '2' key */
#define UTILX_KEY_3 "3" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '3' key */
#define UTILX_KEY_4 "4" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '4' key */
#define UTILX_KEY_5 "5" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '5' key */
#define UTILX_KEY_6 "6" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '6' key */
#define UTILX_KEY_7 "7" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '7' key */
#define UTILX_KEY_8 "8" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '8' key */
#define UTILX_KEY_9 "9" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '9' key */
#define UTILX_KEY_MINUS "minus" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '-' key */
#define UTILX_KEY_0 "0" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '0' key */
#define UTILX_KEY_PREVCHANNEL "XF86PreviousChannel" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Previous Channel' key */
#define UTILX_KEY_VOLUMEUP "XF86AudioRaiseVolume" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Volume Up' key */
#define UTILX_KEY_VOLUMEDOWN "XF86AudioLowerVolume" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Volume Down' key */
#define UTILX_KEY_MUTE "XF86AudioMute" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Mute' key */
#define UTILX_KEY_CHANNELS "XF86ChannelList" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Channel List' key */
#define UTILX_KEY_CHANNELUP "XF86RaiseChannel" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Channel Up' key */
#define UTILX_KEY_CHANNELDOWN "XF86LowerChannel" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Channel Down' key */
#define UTILX_KEY_MENU "Menu" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Menu' key */
#define UTILX_KEY_HOME "XF86HomeScreen" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '(Smart) Home' key */
#define UTILX_KEY_SEARCH "XF86Search" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '(Smart) Search' key */
#define UTILX_KEY_TOOLS "XF86Tools" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Tools' key */
#define UTILX_KEY_INFO "XF86Info" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Information' key */
#define UTILX_KEY_UP "Up" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Up' key */
#define UTILX_KEY_DOWN "Down" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Down' key */
#define UTILX_KEY_LEFT "Left" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Left' key */
#define UTILX_KEY_RIGHT "Right" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Right' key */
#define UTILX_KEY_ENTER "Return" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Enter' key */
#define UTILX_KEY_BACK "XF86Back" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Back' key */
#define UTILX_KEY_EXIT "XF86Close" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Stop' key */
#define UTILX_KEY_RED "XF86Red" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'A (Red)' key */
#define UTILX_KEY_GREEN "XF86Green" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'B (Green)' key */
#define UTILX_KEY_YELLOW "XF86Yellow" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'C (Yellow)' key */
#define UTILX_KEY_BLUE "XF86Blue" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'D (Blue)' key */
#define UTILX_KEY_PIP "XF86PIP" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'PIP (Picture In Picture)' key */
#define UTILX_KEY_PROGINFO "XF86ProgInfo" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Program Info' key */
#define UTILX_KEY_PICTUREMODE "XF86PictureMode" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Picture Mode' key */
#define UTILX_KEY_USBHUB "XF86Launch0" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'USB Hub' key */
#define UTILX_KEY_PICTURESIZE "XF86PictureSize" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Picture Size' key */
#define UTILX_KEY_FAVORITESCHANNELS "XF86Favorites" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Favorite Channels' key */
#define UTILX_KEY_PREVIOUS "XF86AudioPrev" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Previous Song' key */
#define UTILX_KEY_PAUSE "XF86AudioPause" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Pause' key */
#define UTILX_KEY_NEXT "XF86AudioNext" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Next Song' key */
#define UTILX_KEY_RECORD "XF86AudioRecord" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Record' key */
#define UTILX_KEY_PLAY "XF86AudioPlay" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Play' key */
#define UTILX_KEY_STOP "XF86AudioStop" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Stop' key */

#define UTILX_KEY_WIFI_PAIRING "XF86Launch1"
#define UTILX_KEY_BT_VOICE "XF86HotLinks"
#define UTILX_KEY_RECOM_SEARCH "XF86Launch2"
#define UTILX_KEY_BT_NUMBER "XF86Phone"
#define UTILX_KEY_16_9 "XF86Launch3"
#define UTILX_KEY_MTS "XF86Launch4"
#define UTILX_KEY_FACTORY "XF86Launch5"
#define UTILX_KEY_SMODE "XF86Launch6"
#define UTILX_KEY_3SPEED "XF86Launch7"
#define UTILX_KEY_TV_SNS "XF86Launch8"
#define UTILX_KEY_3D "XF86Launch9"
#define UTILX_KEY_APP_LIST "XF86LaunchA"
#define UTILX_KEY_TTX_MIX "XF86LaunchB"
#define UTILX_KEY_DASHBOARD "XF86LaunchC"
#define UTILX_KEY_CAPTION "XF86LaunchD"
#define UTILX_KEY_SRSTSXT "XF86LaunchE"
#define UTILX_KEY_SLEEP "XF86LaunchF"
#define UTILX_KEY_ZOOM1 "XF86ZoomIn"
#define UTILX_KEY_AD "XF86AudioMedia"
#define UTILX_KEY_FF_ "XF86MonBrightnessUp"
#define UTILX_KEY_REWIND_ "XF86MonBrightnessDown"

#define UTILX_KEY_RETURN "XF86Back"
#define UTILX_KEY_PLUS100 "XF86Memo"
#define UTILX_KEY_JOYSTICK_OK "XF86Go"
#define UTILX_KEY_CYAN "XF86Blue"
#define UTILX_KEY_SOURCE "XF86Display"
#define UTILX_KEY_CH_LIST "XF86ChannelList"
#define UTILX_KEY_VOLDOWN "XF86AudioLowerVolume"
#define UTILX_KEY_VOLUP "XF86AudioRaiseVolume"
#define UTILX_KEY_CHDOWN "XF86LowerChannel"
#define UTILX_KEY_CHUP "XF86RaiseChannel"
#define UTILX_KEY_JOYSTICK_UP "Up"
#define UTILX_KEY_JOYSTICK_LEFT "Left"
#define UTILX_KEY_JOYSTICK_RIGHT "Right"
#define UTILX_KEY_JOYSTICK_DOWN "Down"
#define UTILX_KEY_REPEAT "XF86AudioRepeat"
#define UTILX_KEY_GUIDE "XF86ProgInfo"
#define UTILX_KEY_ASPECT "XF86PictureSize"
#define UTILX_KEY_PMODE "XF86PictureMode"
#define UTILX_KEY_USBHUB_SWITCH "XF86Launch0"
#define UTILX_KEY_EMANUAL "XF86Hibernate"
#define UTILX_KEY_MORE "XF86Calculator"
#define UTILX_KEY_TV "XF86Q"
#define UTILX_KEY_DTV "XF86ExtOutput2"
#define UTILX_KEY_STB_POWER "XF86PowerDown"
#define UTILX_KEY_ADDDEL "XF86AddFavorite"
#define UTILX_KEY_CONVERGENCE "XF86WWW"
#define UTILX_KEY_BT_COLOR_MECHA "XF86DOS"
#define UTILX_KEY_STILL_PICTURE "XF86ScreenSaver"
#define UTILX_KEY_BT_TRIGGER "XF86CD"
#define UTILX_KEY_BT_HOTKEY "XF86Support"
#define UTILX_KEY_BT_DEVICE "XF86MailForward"
#define UTILX_KEY_BT_CONTENTSBAR "XF86Book"
#define UTILX_KEY_GAME "XF86Game"
#define UTILX_KEY_PIP_CHUP "XF86Forward"
#define UTILX_KEY_PIP_CHDOWN "XF86RockerDown"
#define UTILX_KEY_ANTENA "XF86Eject"
#define UTILX_KEY_AUTO_PROGRAM "XF86Switch_VT_1"
#define UTILX_KEY_LINK "XF86ExtOutput3"
#define UTILX_KEY_REC "XF86AudioRecord"
#define UTILX_KEY_REWIND "XF86AudioPrev"
#define UTILX_KEY_ANGLE "XF86CycleAngle"
#define UTILX_KEY_MBR_TV "XF86RockerEnter"
#define UTILX_KEY_MBR_STB_GUIDE "XF86RockerUp"
#define UTILX_KEY_MBR_BD_POPUP "XF86ScrollUp"
#define UTILX_KEY_MBR_BDDVD_POWER "XF86ScrollDown"
#define UTILX_KEY_MBR_SETUP_FAILURE "XF86ApplicationLeft"
#define UTILX_KEY_MBR_SETUP "XF86ApplicationRight"
#define UTILX_KEY_MBR_WATCH_TV "XF86New"
#define UTILX_KEY_PRECH "XF86PreviousChannel"
#define UTILX_KEY_FAVCH "XF86Favorites"
#define UTILX_KEY_RECOMMEND_SEARCH_TOGGLE "XF86Launch2"
#define UTILX_KEY_BT_DUALVIEW "XF86Meeting"
#define UTILX_KEY_BT_SAMSUNG_APPS "XF86Switch_VT_4"
#define UTILX_KEY_ESAVING "XF86Suspend"
#define UTILX_KEY_CLEAR "XF86Clear"
#define UTILX_KEY_SUB_TITLE "XF86Subtitle"
#define UTILX_KEY_FF "XF86AudioNext"
#define UTILX_KEY_DVR "XF86LogWindowTree"
#define UTILX_KEY_CAMERA "XF86WebCam"
#define UTILX_KEY_SOCCER_MODE "XF86Standby"
#define UTILX_KEY_FUNCTIONS_AMAZON "XF86Shop"
#define UTILX_KEY_FUNCTIONS_NETFLIX "XF86MySites"
#define UTILX_KEY_PIP_ONOFF "XF86PIP"
#define UTILX_KEY_MBR_WATCH_MOVIE "XF86AudioCycleTrack"
#define UTILX_KEY_MBR_STBBD_MENU "XF86KbdBrightnessDown"
#define UTILX_KEY_MBR_SETUP_CONFIRM "XF86KbdBrightnessUp"
#define UTILX_KEY_FAMILYHUB "XF86Send"
#define UTILX_KEY_ANYVIEW "XF86Reply"
#define UTILX_KEY_PAGE_LEFT "XF86Next_VMode"
#define UTILX_KEY_PAGE_RIGHT "XF86Prev_VMode"
#define UTILX_KEY_WHEEL_LEFT "XF86MenuKB"
#define UTILX_KEY_WHEEL_RIGHT "XF86MenuPB"

#define UTILX_KEY_PANEL_DOWN "XF86Away"
#define UTILX_KEY_PANEL_UP "XF86Xfer"
#define UTILX_KEY_PANEL_PLUS "XF86OpenURL"
#define UTILX_KEY_PANEL_MINUS "XF86Excel"
#define UTILX_KEY_CONTEXT_MENU "XF86Documents"

#define UTILX_KEY_PANEL_ENTER   "XF86MyComputer"
#define UTILX_KEY_PANEL_EXIT    "XF86VendorHome"
