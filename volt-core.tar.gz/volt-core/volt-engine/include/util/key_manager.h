#ifndef VOLT_UTIL_KEY_MANAGER_H
#define VOLT_UTIL_KEY_MANAGER_H

#include "event_const.h"
#include <string>

namespace volt
{
namespace util
{

struct KeyMapping
{
  int volt;
  const char *utilX;
};

/* Key Handlers */
void InitializeKeys();
bool AddKey(int keyCode);
bool RemoveKey(int keyCode);

const char* GetTizenKeyName(int voltKeyEvent);

bool IsVoltKeyEvent(int eventId);

} /* namespace util */
} /* namespace volt */

#endif /* VOLT_UTIL_KEY_MANAGER_H */
