
#ifndef LINUX_X_WINDOW_MANAGER_H_
#define LINUX_X_WINDOW_MANAGER_H_

#include "XWindowManager.h"

namespace volt
{
namespace util
{
class LinuxXWindowManager : public XWindowManager
{
  public:
    LinuxXWindowManager();

    virtual ~LinuxXWindowManager();

    virtual bool CreateDisplay();

    virtual bool CreateWindow(const int width, const int height);

    virtual void ShowWindow(void);

    virtual void HideWindow(void);

};
};
};
#endif /* LINUX_X_WINDOW_MANAGER_H_ */
