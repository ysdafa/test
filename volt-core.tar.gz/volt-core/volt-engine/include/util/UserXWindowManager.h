#ifndef USER_X_WINDOW_MANAGER_H_
#define USER_X_WINDOW_MANAGER_H_

#include "XWindowManager.h"
#include <functional>

namespace volt
{
namespace util
{

class UserXWindowManager : public XWindowManager
{

  public:
    UserXWindowManager(Display * const disp, Window const winId);

    UserXWindowManager(void);

    virtual ~UserXWindowManager();

    virtual bool CreateDisplay();

    virtual bool CreateWindow(const int width, const int height);

    virtual bool DestroyDisplay();

    virtual bool DestroyWindow();

    virtual void ShowWindow(void);

    virtual void HideWindow(void);

    //Function handlers that may be overwritten by users.
    std::function<Display* const(void)> createDisplayPtr;
    std::function<Window const(const int, const int)> createWindowPtr;
    std::function<bool(void)> destroyDisplayPtr;
    std::function<bool(void)> destroyWindowPtr;
    std::function<void(void)> showXWindowPtr;
    std::function<void(void)> hideXWindowPtr;
};
};
};
#endif /* USER_X_WINDOW_MANAGER_H_ */
