#ifndef VOLT_UTIL_LOGGER_H
#define VOLT_UTIL_LOGGER_H

#include "VoltConfig.h"

#include <string>
#ifdef ENABLE_LOGGING

#include <cstddef>

#ifdef USE_LOG4CPLUS
#include <log4cplus/helpers/threads.h>
#include <log4cplus/logger.h>
#else
#include <sstream>

#ifdef USE_DLOG
#include <dlog.h>
#endif
#endif

namespace volt
{
namespace util
{

#ifdef ENABLE_LOGGING_FATAL_ONLY
#define LOG_TRACE(logger, msg) /* no-op */
#define LOG_DEBUG(logger, msg) /* no-op */
#define LOG_INFO(logger, msg) /* no-op */
#define LOG_WARN(logger, msg) /* no-op */
#define LOG_ERROR(logger, msg) /* no-op */
#endif

#ifdef USE_LOG4CPLUS

#ifndef ENABLE_LOGGING_FATAL_ONLY
#define LOG_TRACE(logger, msg) LOG4CPLUS_TRACE((logger).GetLogger(), msg)
#define LOG_DEBUG(logger, msg) LOG4CPLUS_DEBUG((logger).GetLogger(), msg)
#define LOG_INFO(logger, msg) LOG4CPLUS_INFO((logger).GetLogger(), msg)
#define LOG_WARN(logger, msg) LOG4CPLUS_WARN((logger).GetLogger(), msg)
#define LOG_ERROR(logger, msg) LOG4CPLUS_ERROR((logger).GetLogger(), msg)
#endif

#define LOG_FATAL(logger, msg) LOG4CPLUS_FATAL((logger).GetLogger(), msg)

#else

#ifndef ENABLE_LOGGING_FATAL_ONLY
#define LOG_TRACE(logger, msg) do { \
  LOG_WRITE((logger), volt::util::Logger::kInfo, msg); \
} while(0)
#define LOG_DEBUG(logger, msg) do { \
  LOG_WRITE((logger), volt::util::Logger::kDebug, msg); \
} while(0)
#define LOG_INFO(logger, msg) do { \
  LOG_WRITE((logger), volt::util::Logger::kInfo, msg); \
} while(0)
#define LOG_WARN(logger, msg) do { \
  LOG_WRITE((logger), volt::util::Logger::kWarn, msg); \
} while(0)
#define LOG_ERROR(logger, msg) do { \
  LOG_WRITE((logger), volt::util::Logger::kMajor, msg); \
} while(0)
#endif

#define LOG_FATAL(logger, msg) do { \
  LOG_WRITE((logger), volt::util::Logger::kFatal, msg); \
} while(0)

#define LOG_WRITE(logger, level, msg) do { \
  std::ostringstream os; \
  os << msg; \
  (logger).Log(__FILE__, __func__, __LINE__, (level), os.str()); \
} while(0)
#endif

class Logger
{
  public:
    enum LogLevel { kFatal, kMajor, kWarn, kDebug, kInfo };

  public:
    Logger(const std::string &aName = "");
    virtual ~Logger();

    static void Configure(const std::string &aConfigPath);

    static void SetLogLevel(const LogLevel aLevel);

    static const char* LevelToString(const LogLevel aLevel);

    static LogLevel StringToLevel(const char *aLevelStr);

    static Logger& DefaultLogger();

#ifdef USE_LOG4CPLUS
    log4cplus::Logger GetLogger() const
    {
      return logger_;
    }

    static log4cplus::LogLevel Log4CplusLevel(const LogLevel aLevel);
#else
    void Log(const char *aFile, const char *aFunc, const unsigned int aLine,
             const LogLevel aLevel, const std::string &aMsg) const;

    void Log(const LogLevel aLevel, const std::string &aMsg) const;
#endif

  private:
#ifdef USE_LOG4CPLUS
    log4cplus::Logger logger_;
#else
    std::string name_;
    static LogLevel level_;
#endif
};

} /* namespace util */
} /* namespace volt */

#else /* ENABLE_LOGGING */
namespace volt
{
namespace util
{

#define LOG_TRACE(logger, msg) /* no-op */
#define LOG_DEBUG(logger, msg) /* no-op */
#define LOG_INFO(logger, msg) /* no-op */
#define LOG_WARN(logger, msg) /* no-op */
#define LOG_ERROR(logger, msg) /* no-op */
#define LOG_FATAL(logger, msg) /* no-op */

class Logger
{
  public:
    enum LogLevel { kFatal, kMajor, kWarn, kDebug, kInfo };

  public:
    Logger(const std::string & = "") {}
    virtual ~Logger() {}

    static void Configure(const std::string &) {}

    static void SetLogLevel(const LogLevel) {}

    static const char* LevelToString(const LogLevel)
    {
      return "";
    }

    static LogLevel StringToLevel(const char *)
    {
      return kInfo;
    }

    static Logger& DefaultLogger()
    {
      static Logger logger("volt");
      return logger;
    }
};

} /* namespace util */
} /* namespace volt */
#endif /* ENABLE_LOGGING */

#endif /* VOLT_UTIL_LOGGER_H */
