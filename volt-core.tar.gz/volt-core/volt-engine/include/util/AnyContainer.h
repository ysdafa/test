#pragma once

#include <boost/any.hpp>

#include <map>
#include <vector>
#include <string>

class AnyList;

/**
 * This container class can store mappings of keys to arbitrary data
 * types.  It is currently implemented using std::map<std::string, boost::any>.
 */
class AnyMap
{
  public:
    AnyMap();
    AnyMap(const AnyMap &aSrc);
    virtual ~AnyMap();

    AnyMap& operator=(const AnyMap &aRhs);

    /**
     * Insert a new key-value mapping.
     * Insertion would fail if there already exists a value with the same key.
     *
     * @param[in] aKey Key.
     * @param[in] aVal Value.
     *
     * @return true on success, false otherwise.
     */
    template<typename Type>
    bool Insert(const std::string &aKey, Type aVal)
    {
      if (Has(aKey))
      {
        return false;
      }

      map_[aKey] = aVal;
      return true;
    }

    /**
     * Checks if this AnyMap contains a value with the given key.
     *
     * @param[in] aKey Key.
     *
     * @return true if the key is found, false otherwise.
     */
    bool Has(const std::string &aKey) const;

    /**
     * Get the number of mappings store in this AnyMap.
     *
     * @return Number of mappings.
     */
    size_t Size() const;

    /**
     * Check if this AnyMap is empty.
     *
     * @return true if empty, false otherwise.
     */
    bool Empty() const;

    /**
     * Get the keys store in this AnyMap.
     *
     * @param[out] aKeys Vectore where the keys are stored.
     *
     * @return Reference to aKeys.
     */
    std::vector<std::string>& GetKeys(std::vector<std::string> &aKeys) const;

    /**
     * Get the value mapped with the given key.
     * Caller must know the data type of the mapped value.
     * If the actual type is not the type given from the caller, this function
     * fails.
     *
     * @param[in] aKey Key.
     * @param[out] aVal Value for the given key.
     *
     * @return true if success, false otherwise.
     */
    template<typename Type>
    bool Get(const std::string &aKey, Type &aVal) const
    {
      auto iter = map_.find(aKey);

      if (iter == map_.end())
      {
        return false;
      }

      try
      {
        aVal = boost::any_cast<Type>(iter->second);
        return true;
      }
      catch (const boost::bad_any_cast &)
      {
        return false;
      }
    }

    /**
     * Check is the value for the given key is of the given type.
     *
     * @param[in] aKey Key.
     *
     * @return true if the data type is the same as the type given by the
     *         caller.
     */
    template<typename Type>
    bool IsType(const std::string &aKey) const
    {
      Type dummy;
      return Get<Type>(aKey, dummy);
    }

  private:
    typedef std::map<std::string, boost::any> Map;
    Map map_;
};

/**
 * This container class can store objects of arbitrary data types.
 * It is currently implemented using std::vector<boost::any>.
 */
class AnyList
{
  public:
    AnyList();
    AnyList(const AnyList &aSrc);
    virtual ~AnyList();

    AnyList& operator=(const AnyList &aRhs);

    /**
     * Add a new value to the list.
     *
     * @param[in] aVal Value.
     *
     * @return true on success, false otherwise.
     */
    template<typename Type>
    bool Add(Type aVal)
    {
      list_.push_back(aVal);
      return true;
    }

    /**
     * Get the number of mappings store in this AnyList.
     *
     * @return Number of mappings.
     */
    size_t Size() const;

    /**
     * Check if this AnyList is empty.
     *
     * @return true if empty, false otherwise.
     */
    bool Empty() const;

    /**
     * Get the value at the given index.
     * Caller must know the data type of the mapped value.
     * If the actual type is not the type given from the caller, this function
     * fails.
     *
     * @param[in] aIndex Index (0-based).
     * @param[out] aVal Value for the given key.
     *
     * @return true if success, false otherwise.
     */
    template<typename Type>
    bool Get(const size_t aIndex, Type &aVal) const
    {
      if (aIndex >= Size())
      {
        return false;
      }

      try
      {
        aVal = boost::any_cast<Type>(list_[aIndex]);
        return true;
      }
      catch (const boost::bad_any_cast &)
      {
        return false;
      }
    }

    /**
     * Check is the value at the given index is of the given type.
     *
     * @param[in] aIndex Index.
     *
     * @return true if the data type is the same as the type given by the
     *         caller.
     */
    template<typename Type>
    bool IsType(const size_t aIndex) const
    {
      Type dummy;
      return Get<Type>(aIndex, dummy);
    }

  private:
    typedef std::vector<boost::any> List;
    List list_;
};
