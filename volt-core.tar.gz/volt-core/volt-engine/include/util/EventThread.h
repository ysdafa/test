/*
 * EventThread.h
 *
 *  Created on: Nov 2, 2014
 *      Author: Joe Yee
 *
 *      This is event driven thread class based on std library
 */

#ifndef EVENTTHREAD_H_
#define EVENTTHREAD_H_

#include <string>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <queue>
#include <pthread.h>
#include <cstdint>
#include <chrono>

/* HOWTO
 *
 *  1. create event thread member variable in your object, or receive a reference of it from somewhere else
 *  2. if you are in a class, place one of the GENERATE_XXX macro below at the beginning of your member function,
 *     the body of the function will now be executed on the thread inside the EventThread object.
 *     Example:
 *
 *     class A
 *     {
 *      public:
 *        A() : mThread("thread for class A"){};
 *
 *        // only owner class may delete thread.
 *        // user need to manager owner ship of thread class on their own
 *        ~A(){ delete mThread };
 *
 *        // sync method with 0 input
 *        int sync0()
 *        {
 *          int result = 0; // this must be provided
 *          GENERATE_SYNC_EVENT(mThread, A, sync0, int, result) // caller thread is blocked here
 *
 *          // this is now executed on thread in mThread
 *          // caller thread is released at the end of this call
 *          return result;
 *        }
 *
 *        // sync method with 1 input
 *        int sync1(int a)
 *        {
 *          int result = 0; // this must be provided
 *          GENERATE_SYNC_ARGS_EVENT(mThread, A, sync0, int, result, a) // caller thread is blocked here
 *
 *          // this is now executed on thread in mThread
 *          // caller thread is released at the end of this call
 *          return result;
 *        } *
 *
 *      private:
 *        EventThread *mThread;
 *     }
 *
 *  3. THINGS TO WATCHOUT FOR:
 *    a. if pointers are passed into sync/async events, user is responsible for deallocating them
 *    b. keep in mind event maybe cancelled, so always have a way to deallocate the memory pointed
 *       by pointer arguments without having the code invoked, you can avoid this by passing in shared pointers
 *    c. user must manager ownership of the thread. i.e. who create/destroy the thread. it can only happen once
 *
 *  4. NOT support for now: DELAYED EVENT, PERIODIC EVENT
 */

// CONVENIENCE MACRO, DONT USE IF YOU NO LIKE :D

#define EVENT_THREAD_DEBUG_LOG(_args...)
//#define EVENT_THREAD_DEBUG_LOG(_args...)  printf(_args)

// marco for async event with 0 argments
#define GENERATE_ASYNC_EVENT(_threadPointer, _class, _function)	      				  if(not _threadPointer->isCurrent())	\
                                                                                {	\
                                                                                  AsyncEventMessage *msg = new AsyncEventMessage(std::bind(&_class::_function, this), (int64_t)this);	\
                                                                                  return _threadPointer->sendEvent(msg);	\
                                                                                }

// marco for async event with N argments
#define GENERATE_ASYNC_ARGS_EVENT(_threadPointer, _class, _function, _args...)	  if(not _threadPointer->isCurrent())	\
                                                                                  {	\
      	  	  	  	  	  	  	  	  	  	  	  	  	  	  		 	 	 	 	 	  	  	  AsyncEventMessage *msg = new AsyncEventMessage(std::bind(&_class::_function, this, _args), (int64_t)this);	\
      	  	  	  	  	  	  	  	  	  	  	  	  	  	  		 	 	 	 	 	  	  	  return _threadPointer->sendEvent(msg);	\
                                                                                  }

// marco for sync event with 0 argments
#define GENERATE_SYNC_EVENT(_threadPointer, _class, _function, _returnType, _returnValue)	      		  if(not _threadPointer->isCurrent())	\
                                                                                                      {	\
                                                                                                        SyncEventMessage<_returnType> msg(std::bind(&_class::_function, this), (int64_t)this);	\
                                                                                                        _threadPointer->sendEvent(&msg);	\
                                                                                                        if(msg.isProcessed())	\
                                                                                                        _returnValue = msg.getResult();	\
                                                                                                        return _returnValue;	\
                                                                                                      }

// marco for sync event with N argments
#define GENERATE_SYNC_ARGS_EVENT(_threadPointer, _class, _function, _returnType, _returnValue, _args...)	      if(not _threadPointer->isCurrent())	\
                                                                                                                {	\
                                                                                                                  SyncEventMessage<_returnType> msg(std::bind(&_class::_function, this, _args), (int64_t)this);	\
                                                                                                                  _threadPointer->sendEvent(&msg);	\
                                                                                                                  if(msg.isProcessed())	\
                                                                                                                  _returnValue = msg.getResult();	\
                                                                                                                 return _returnValue;	\
                                                                                                                }

// marco for async event with 0 argments
#define GENERATE_PERIODIC_EVENT(_threadPointer, _class, _function, _period)                 if(not _threadPointer->isCurrent()) \
                                                                                            { \
                                                                                              PeriodicEventMessage *msg = new PeriodicEventMessage(std::bind(&_class::_function, this), _period, (int64_t)this); \
                                                                                              return _threadPointer->sendEvent(msg);  \
                                                                                            }

// marco for async event with N argments
#define GENERATE_PERIODIC_ARGS_EVENT(_threadPointer, _class, _function, _period, _args...)    if(not _threadPointer->isCurrent()) \
                                                                                              { \
                                                                                                  PeriodicEventMessage *msg = new PeriodicEventMessage(std::bind(&_class::_function, this, _args), _period, (int64_t)this);  \
                                                                                                  return _threadPointer->sendEvent(msg);  \
                                                                                              }
namespace volt
{
  namespace util
  {
    class EventThread;

    class EventMessage
    {
      public:
        EventMessage(uint64_t id = 0xffffffffffffffff, bool isPeriodic = false)
        : mId(id),
          mIsSync(false),
          mIsProcessed(false),
          mCondition(),
          mIsWaiting(false),
          mIsPeriodic(isPeriodic),
          mWaitMutex()
        {
        }

        virtual ~EventMessage()
        {

        }

        virtual void execute()
        {
          mIsProcessed = true;

          // wake up caller thread
          if(mIsSync)
          {
            notify();
          }
        }

        uint64_t getId()
        {
          return mId;
        }

        bool isSync()
        {
          return mIsSync;
        }

        bool isProcessed()
        {
          return mIsProcessed;
        }

        bool isPeriodic()
        {
          return mIsPeriodic;
        }

        virtual void notify()
        {
        }

        virtual void wait()
        {
        }

      protected:

        uint64_t mId;

        bool mIsSync;

        bool mIsProcessed;

        std::condition_variable mCondition;

        bool mIsWaiting;

        bool mIsPeriodic;

        std::mutex mWaitMutex;
    };

    class AsyncEventMessage : public EventMessage
    {
      public:
        AsyncEventMessage(std::function<void(void)> function, uint64_t id = 0xffffffffffffffff, bool isPeriodic = false)
        : EventMessage(id, isPeriodic),
          mFunction(function)
        {
        }

        virtual ~AsyncEventMessage(){}

        virtual void execute()
        {
          mFunction();
          EventMessage::execute();
        }

      private:
        std::function<void(void)> mFunction;
    };

    class PeriodicEventMessage : public AsyncEventMessage
    {
      public:
        PeriodicEventMessage(std::function<void(void)> function, uint64_t periodMs, uint64_t id = 0xffffffffffffffff, uint32_t executionCount = 0xffffffff)
        : AsyncEventMessage(function, id, true),
          mPeriodMs(periodMs),
          mTimeUntilExecuteMs(periodMs),
          mExecutionCount(executionCount)
        {
        }

        virtual ~PeriodicEventMessage(){}

        virtual void updateElapsed(uint64_t timeMs)
        {
          if(not mExecutionCount)
          {
            return;
          }

          // time to execute
          if(timeMs >= mTimeUntilExecuteMs)
          {
            AsyncEventMessage::execute(); // execute the message

            uint64_t remainder = timeMs - mTimeUntilExecuteMs;

            if(mExecutionCount != 0xffffffff)
            {
              mExecutionCount --;
            }

            mTimeUntilExecuteMs = mPeriodMs;

            if(remainder >= mTimeUntilExecuteMs)
            {
              EVENT_THREAD_DEBUG_LOG("ERROR: we missed %ld number of executions, something took too long\n", remainder / mTimeUntilExecuteMs);
              if(remainder != mTimeUntilExecuteMs)
              {
                mTimeUntilExecuteMs = remainder % mTimeUntilExecuteMs;
              }
            }
            else
            {
              mTimeUntilExecuteMs -= remainder;
            }
          }
          // not time to execute yet
          else
          {
            mTimeUntilExecuteMs -= timeMs;
          }
        }

        uint32_t getExecutionCount()
        {
          return mExecutionCount;
        }

        uint64_t getTimeUtilExecute()
        {
          return mTimeUntilExecuteMs;
        }

      private:
        uint64_t mPeriodMs;
        uint64_t mTimeUntilExecuteMs;
        uint32_t mExecutionCount;

    };

    template<typename result>
    class SyncEventMessage : public EventMessage
    {
      friend class EventThread;

      public:
        SyncEventMessage(std::function<result(void)> function, uint64_t id = 0xffffffffffffffff)
        : EventMessage(id),
          mFunction(function),
          mResult()
        {
          mIsSync = true;
          mIsWaiting = false;
        }

        virtual ~SyncEventMessage()
        {
        }

        virtual void execute()
        {
          mWaitMutex.lock();

          mResult = mFunction();
          mIsProcessed = true;

          mWaitMutex.unlock();

          EventMessage::execute();
        }

        virtual void notify()
        {
          EVENT_THREAD_DEBUG_LOG("message notify\n");

          std::lock_guard<std::mutex> waitLock(mWaitMutex);
          mIsWaiting = false;
          mCondition.notify_one();
        }

        virtual void wait()
        {
          mWaitMutex.lock();
          if(not mIsProcessed)
          {
            EVENT_THREAD_DEBUG_LOG("message waiting\n");

            mIsWaiting = true;
            mWaitMutex.unlock();
            std::unique_lock<std::mutex> waitLock(mWaitMutex);
            mCondition.wait(waitLock, [this]{return (mIsWaiting == false);});

            EVENT_THREAD_DEBUG_LOG("message waiting done\n");
          }
          else
          {
            mIsWaiting = false;
            mWaitMutex.unlock();
            EVENT_THREAD_DEBUG_LOG("message no wait\n");
          }
        }

        result getResult()
        {
          return mResult;
        }

      protected:

        std::function<result(void)> mFunction;

        result mResult;
    };

    class EventThread
    {
      public:
        EventThread(std::string name = "none");

        virtual ~EventThread();

        void sendEvent(EventMessage *event);

        void removeEvents(uint64_t id);

        void run();

        bool isCurrent();

        void join();

        void start();

      private:
        EventThread(EventThread &rhs) : mIsRunning(false), mIsStarted(false) {}

        EventThread &operator=(EventThread &rhs){return *this;}

        void deleteFromEventQueue(uint64_t id);

        void deleteFromPeriodicQueue(uint64_t id);

        void processDeleteQueue();

        void processMessages();

        void processEventMessage();

        void processPeriodicMessage();

        void destroy();

        void threadSleep();

        void wakeThread();

        std::string mName;

        std::mutex mEventMutex;

        std::deque<EventMessage*> mEventQueue;

        std::mutex mPeriodicMutex;

        std::deque<PeriodicEventMessage*> mPeriodicQueue;

        std::mutex mDeleteMutex;

        std::deque<uint64_t> mDeleteQueue; // delete based on ID

        std::condition_variable mMainCondition;

        bool mIsWaiting;

        std::mutex mMainMutex;

        bool mIsRunning;

        bool mIsStarted;

        std::thread mThread;

        uint64_t mWaitTime;

        std::chrono::system_clock::time_point mLastExecuteTime;
    };
  };
};


#endif /* EVENTTHREAD_H_ */

