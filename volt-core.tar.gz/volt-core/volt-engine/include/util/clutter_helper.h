#ifndef VOLT_UTIL_CLUTTER_HELPER_H
#define VOLT_UTIL_CLUTTER_HELPER_H

#include <clutter/clutter.h>
#include <string>
#include "AppConfig.h"
#include<tv_context.h>
#include "VoltFullProcessRuntime.h"

namespace volt
{
	namespace util
	{
		//capture API 
		//bundle *caller_bundle;

		struct KeyMapping
		{
			//  KeyMapping(int aVolt, char *aXutil) : volt(aVolt), xUtil(aXutil){};
			int volt;
			const char *utilX;
		};

		/**
		* Prepares Clutter for initialization on Samsung platform.
		* This will open a new XDisplay and calls clutter_x11_set_display to
		* use the created display.
		* This must be called before clutter_init.
		*
		* @return 0 on success, -1 otherwise.
		*/
		int PrepareClutter();

		/**
		* Create a new ClutterStage instance for Samsung platform.
		* This will create/map a new X window and initializes the new ClutterStage
		* instance to use the foreign window.
		*
		* @param[in] aWidth Width of the window/stage.
		* @param[in] aHeight Height of the window/stage.
		* @return New instance of ClutterStage, NULL on error.
		*/
		static void tvContextChange(tvcontext_state state, void *data);
		ClutterActor* CreateNewStage(const int aWidth, const int aHeight, const int aSceneWidth, const int aSceneHeight);

		/**
		* Destroy the stage and also the X window created in CreateNewStage.
		* @param[in] aStage Pointer to a pointer to the stage object.
		*            *aStage will be set to nullptr after this call.
		*/
		void DestroyStage(ClutterActor **aStage);

		void ShowXWindow();

		void HideXWindow();

		/* TEMP */
		void MoveShowXWindow();

		/* TEMP */
		void MoveHideXWindow();

		void SetXWindowName(const std::string& name);

		/* Key Handlers */
		bool AddKey(int keyCode);
		bool RemoveKey(int keyCode);

		const char* GetTizenKeyName(int voltKeyEvent);

		bool IsVoltKeyEvent(int eventId);

		// raise xwindow
		void VDRaiseXWindow(void *aStage);

		void VDLowerXWindow(void *aStage);

		void VDMapXWindow(void *aStage);

		void VDUnmapXWindow(void *aStage);

		void ScreenCapture(void *aStage, const char* fileName, int height);
		void ScreenCapture(char* appId, char* json);

		std::string GetAppName();
		std::string GetAppId();
		std::string GetAppIcon();
		int Capture();
		void setCallerBundler(bundle *b);
		char* getCallerAppID();
		void setCallerAppID(bundle *b);
	} /* namespace util */
} /* namespace volt */

#endif /* VOLT_UTIL_CLUTTER_HELPER_H */
