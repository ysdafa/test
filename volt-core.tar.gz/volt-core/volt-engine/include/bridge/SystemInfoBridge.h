/*
 * SystemInfoBridge.h
 *
 *  Created on: July 30th, 2014
 *      Author: Joe Yee
 */

#ifndef SAMSUNG_KINGSCANYON_SYSTEMINFOBRIDGE_H_
#define SAMSUNG_KINGSCANYON_SYSTEMINFOBRIDGE_H_

#include "ScriptBridge.h"

#include "logger.h"

#define DEFINE_KEY_MAP_FUNCS(ns,key) int get##key() const { return ns::key; } \
                                     void set##key(int) {}

namespace Bridge
{
/* Tizen System Info Keys, must mirror system_info_key.h */
/* this is currently using capi-system-info-0.2.76+tvprd-1.1.armv7l */
// THE NUMBERING IN COMMENT IS NOT ACCURRATE
enum SYSTEM_INFO_KEY
{
  KEY_LOCAL_SET = SYSTEM_INFO_KEY_LOCAL_SET,   
  KEY_PVR_SUPPORTED = SYSTEM_INFO_KEY_PVR_SUPPORTED,    
  KEY_INFO_LINK_SERVER_TYPE = SYSTEM_INFO_KEY_INFO_LINK_SERVER_TYPE,   
  KEY_USB_COPY_FORMAT_SUPPORTED = SYSTEM_INFO_KEY_USB_COPY_FORMAT_SUPPORTED,   
  KEY_BT_PROFILE_BT_SMART_CONTROL = SYSTEM_INFO_KEY_BT_PROFILE_BT_SMART_CONTROL,   
  KEY_PANEL_RESOLUTION_HEIGHT = SYSTEM_INFO_KEY_PANEL_RESOLUTION_HEIGHT,
  KEY_MULTITASKING_SUPPORT = SYSTEM_INFO_KEY_MULTITASKING_SUPPORT,
  KEY_MLS_SUPPORT = SYSTEM_INFO_KEY_MLS_SUPPORT,
  KEY_SCREEN_WIDTH = SYSTEM_INFO_KEY_SCREEN_WIDTH,
  KEY_FREE_VIEW_HD_SUPPORTED = SYSTEM_INFO_KEY_FREE_VIEW_HD_SUPPORTED,
  KEY_CES_OPTION = SYSTEM_INFO_KEY_CES_OPTION

 // KEY_LOCAL_SET = SYSTEM_INFO_KEY_LOCAL_SET
};

class SystemInfoBridge: public ScriptInstanceBridge
{
  public:
    DEFINE_KEY_MAP_FUNCS(Bridge, KEY_LOCAL_SET)   
    DEFINE_KEY_MAP_FUNCS(Bridge, KEY_PVR_SUPPORTED)   
    DEFINE_KEY_MAP_FUNCS(Bridge, KEY_INFO_LINK_SERVER_TYPE)   
    DEFINE_KEY_MAP_FUNCS(Bridge, KEY_USB_COPY_FORMAT_SUPPORTED)   
    DEFINE_KEY_MAP_FUNCS(Bridge, KEY_BT_PROFILE_BT_SMART_CONTROL)  
	DEFINE_KEY_MAP_FUNCS(Bridge, KEY_PANEL_RESOLUTION_HEIGHT)   
    DEFINE_KEY_MAP_FUNCS(Bridge, KEY_MULTITASKING_SUPPORT)    
    DEFINE_KEY_MAP_FUNCS(Bridge, KEY_MLS_SUPPORT)    
	DEFINE_KEY_MAP_FUNCS(Bridge, KEY_SCREEN_WIDTH)
	DEFINE_KEY_MAP_FUNCS(Bridge, KEY_FREE_VIEW_HD_SUPPORTED)
	DEFINE_KEY_MAP_FUNCS(Bridge, KEY_CES_OPTION)
//	DEFINE_KEY_MAP_FUNCS(Bridge, KEY_LOCAL_SET)

    SystemInfoBridge();

    virtual ~SystemInfoBridge();

    static std::string LOGGER_NAME;

  protected:

    virtual inline const char* getScriptClassName() const
    {
      return "SystemInfo";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      // got nothing to do for now..
    }

    static ScriptObject HandleGetIntValue(SystemInfoBridge *aSelf,
                                          const ScriptArray &aArgs);

    static ScriptObject HandleGetBoolValue(SystemInfoBridge *aSelf,
                                           const ScriptArray &aArgs);

    static ScriptObject HandleGetDoubleValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetStringValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetIntArrayValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetPlatformBoolValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetPlatformIntValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetPlatformDoubleValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetPlatformStringValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetCustomBoolValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetCustomIntValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetCustomDoubleValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

    static ScriptObject HandleGetCustomStringValue(SystemInfoBridge *aSelf,
        const ScriptArray &aArgs);

  protected:
    static volt::util::Logger logger_;
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_SYSTEMINFOBRIDGE_H_ */
