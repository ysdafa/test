/*
 * ScriptTypes.h
 *
 *  Created on: May 17, 2013
 *      Author: reza
 */

#ifndef SCRIPTTYPES_H_
#define SCRIPTTYPES_H_

#include "v8/v8.h"
#include <vector>
#include <string>
#include <strings.h>
#include <string.h>
#include "logger.h"
#include "DataBuffer.h"
#include "Exception.h"

namespace Bridge
{
//Utility functions for converting between JS and native. Protected because could be useful
//to inheriting classes as well.

//These classes provide an abstraction for untyped javascript values. They wrap around the representations provided by the
//javascript interpreter.
class ScriptObject;
class ScriptArray;
class ScriptArrayBuffer;
class ScriptFunction;

class ScriptStringResourceBase
{
  public:
    enum EncodingType
    {
      Unknown,
      Ascii,
      Utf8
    };

    ScriptStringResourceBase() : mType(Unknown) {};

    ScriptStringResourceBase(volt::util::DataBuffer::SharedPtr &aBuffer, EncodingType type);

    virtual ~ScriptStringResourceBase();

    const volt::util::DataBuffer::SharedPtr GetSharedBuffer() const;

    EncodingType GetType();

  protected:
    volt::util::DataBuffer::SharedPtr mBuffer;

    EncodingType mType;

  private:
    // disabled constructors
    ScriptStringResourceBase(const ScriptStringResourceBase &other) {};

    ScriptStringResourceBase &operator=(const ScriptStringResourceBase& other)
    {
      return *this;
    };
};

// class for holding ascii string
class ScriptAsciiStringResource : public ScriptStringResourceBase, public v8::String::ExternalAsciiStringResource
{
  public:
    ScriptAsciiStringResource(volt::util::DataBuffer::SharedPtr &aBuffer);

    virtual ~ScriptAsciiStringResource();

    virtual const char* data() const;

    virtual size_t length() const;

  private:
    // disabled constructors
    ScriptAsciiStringResource() {};

    ScriptAsciiStringResource(const ScriptAsciiStringResource &other);

    ScriptAsciiStringResource &operator=(const ScriptAsciiStringResource& other)
    {
      return *this;
    };
};

// class for holding strings in the form of 2 bytes. NOT UTF8
// see https://code.google.com/p/v8/issues/detail?id=27
class ScriptStringResource : public ScriptStringResourceBase, public v8::String::ExternalStringResource
{
  public:
    ScriptStringResource(volt::util::DataBuffer::SharedPtr &aBuffer);

    virtual ~ScriptStringResource();

    virtual const uint16_t* data() const;

    virtual size_t length() const;

  private:
    // disabled constructors
    ScriptStringResource() {};

    ScriptStringResource(const ScriptStringResource &other) {};

    ScriptStringResource &operator=(const ScriptStringResource& other)
    {
      return *this;
    };
};

/**
 * Utility function to convert an a V8 Handle<String> to an std::string
 * @param[in] value V8 String object
 * @return value as an std::string
 */
inline std::string V8ToString(v8::Handle<v8::Value> value)
{
  v8::String::Utf8Value utf8Value(value);
  return std::string(*utf8Value);
}

/*
 * Shared pointer version
 */
inline volt::util::DataBuffer::SharedPtr V8ToStringDataBuffer(
  v8::Handle<v8::Value> value)
{
  v8::String::Utf8Value utf8Value(value);

  volt::util::DataBuffer::SharedPtr buffer(
    new volt::util::DataBuffer((const char*) *utf8Value));
  return buffer->getSharedPtr();
}

/**
 * Convert an std::string to a V8 String object
 * @param[in] theString std::string to convert
 * @return theString as a V8 Handle<String>
 */
inline v8::Local<v8::String> StringToV8(std::string theString)
{
  v8::Local<v8::String> v8String = v8::String::NewFromUtf8(
                                     v8::Isolate::GetCurrent(), theString.c_str(), v8::String::kNormalString,
                                     theString.length());
  return v8String;
}

// this is used exclusively for java script buffers
inline v8::Local<v8::String> JsDataBufferToV8(volt::util::DataBuffer::SharedPtr &buffer)
{
  // if we have data
  if(buffer.get() and buffer->c_str() and buffer->length())
  {
    v8::Local<v8::String> v8String;

    if(buffer->format() == volt::util::DataBuffer::Format::Utf16)
    {
      v8String = v8::String::NewExternal(v8::Isolate::GetCurrent(), new ScriptStringResource(buffer));
    }
    else if(buffer->CheckIsUtf8())
    {
      // we are making a copy here and this is time consuming. All JS should be ascii only.
      v8String = v8::String::NewFromUtf8(v8::Isolate::GetCurrent(), buffer->c_str(), v8::String::kNormalString,
                                         buffer->length());
    }
    // ascii, binary or other unknowns.. (though the other stuff should not be calling this
    else
    {
      v8String = v8::String::NewExternal(v8::Isolate::GetCurrent(), new ScriptAsciiStringResource(buffer));
    }

    return v8String;
  }

  return StringToV8("");
}

inline v8::Local<v8::String> DataBufferToV8(volt::util::DataBuffer::SharedPtr &buffer)
{
  // if we have data
  if(buffer.get() and buffer->c_str() and buffer->length())
  {
    v8::Local<v8::String> v8String;

    if(buffer->format() == volt::util::DataBuffer::Format::Utf16)
    {
      v8String = v8::String::NewExternal(v8::Isolate::GetCurrent(), new ScriptStringResource(buffer));
    }
    else if(buffer->CheckIsUtf8())
    {
      // we are making a copy here and this is time consuming. All JS should be ascii only.
      v8String = v8::String::NewFromUtf8(v8::Isolate::GetCurrent(), buffer->c_str(), v8::String::kNormalString,
                                         buffer->length());
    }
    // ascii, binary or other unknowns.. (though the other stuff should not be calling this
    else
    {
      v8String = v8::String::NewExternal(v8::Isolate::GetCurrent(), new ScriptAsciiStringResource(buffer));
    }

    return v8String;
  }

  return StringToV8("");
}

inline bool compareStrChar(std::string s1, const char* s2)
{
  return strcasecmp(s1.c_str(), s2) == 0;
}

/**
 * Wraps a JavaScript value. It could be a primitive type, an array, null, undefined, an exception,
 * and it may contain child objects mapped to keys. Use test methods (isNumber, isString) etc to test
 * for actual type. Use lookup methods to test for and access properties by key. Convert to an array
 * to use indexed lookup, but test whether object is an array first.
 */
class ScriptObject
{
    friend class ScriptArray;
    friend class ScriptArrayBuffer;
    friend bool operator==(const ScriptObject& lhs, const ScriptObject& rhs);

  protected:

    struct ScriptObjectData
    {
      v8::Persistent<v8::Value> persistentValue;
      uint refCount;
      volt::util::DataBuffer::SharedPtr buffer;

      ScriptObjectData(v8::Handle<v8::Value> val)
        : persistentValue(v8::Isolate::GetCurrent(), val), refCount(1), buffer()
      {
      }

      virtual ~ScriptObjectData()
      {
        persistentValue.Reset(); //Clear out the persistent handle, allow it to be garbage collected

        if (buffer.get() != nullptr)
        {
          v8::Isolate::GetCurrent()->AdjustAmountOfExternalAllocatedMemory(
            -1 * buffer->length());
        }
      }

      void SetExternalData(const volt::util::DataBuffer::SharedPtr &aBuffer)
      {
        if (buffer.get())
        {
          /* Hint v8 the amount of "external" memory we are using, release previously own memory */
          v8::Isolate::GetCurrent()->AdjustAmountOfExternalAllocatedMemory(
            -1 * buffer->length());
        }

        buffer = aBuffer->getSharedPtr();

        if (buffer.get())
        {
          /* Hint v8 the amount of "external" memory we are using. */
          v8::Isolate::GetCurrent()->AdjustAmountOfExternalAllocatedMemory(
            buffer->length());
        }
      }
    };

    ScriptObjectData* data;

    bool isObject() const;

    void associateExternalDataWithJSObject(
      const volt::util::DataBuffer::SharedPtr &aBuffer);

  private:
    void cleanup();
    static void weakCallback(
      const v8::WeakCallbackData<v8::Value, ScriptObjectData> &weakCallbackData);

  public:

    ScriptObject();
    ScriptObject(v8::Handle<v8::Object> obj);
    ScriptObject(v8::Handle<v8::Value> val);

    ScriptObject(bool boolType);
    ScriptObject(double numberType);
    ScriptObject(int number);
    ScriptObject(std::string stringType);
    explicit ScriptObject(const char* stringType);

    // creates a string buffer using external string resource
    ScriptObject(volt::util::DataBuffer::SharedPtr stringBuffer);

    ScriptObject(const ScriptObject& that);

    ~ScriptObject();

    ScriptObject& operator=(const ScriptObject& that);

    volt::util::DataBuffer::SharedPtr getDataBuffer() const;

    /*
     * Create a ScriptObject wrapping the value null.
     */
    static ScriptObject Null();

    bool tryReuseExistingData(v8::Handle<v8::Object>);

    v8::Handle<v8::Value> getValue() const;
    v8::Handle<v8::Object> getObjectUnsafe() const;

    //Lookup
    bool has(const std::string& key) const;
    ScriptObject get(const std::string& key) const;
    bool tryGet(const std::string& key, ScriptObject& result) const;
    void set(const std::string& key, const ScriptObject &item);

    //Type tests
    bool isArray() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsArray();
    }
    bool isArrayBuffer() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsArrayBuffer();
    }
    bool isFunction() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsFunction();
    }
    bool isBool() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsBoolean();
    }
    bool isNumber() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsNumber();
    }
    bool isString() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsString();
    }
    bool isUndefined() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsUndefined();
    }
    bool isNull() const
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      return getValue()->IsNull();
    }

    //Type cast
    ScriptArray asArray() const;
    ScriptArrayBuffer asArrayBuffer() const;
    ScriptFunction asFunction() const;
    bool asBool() const;
    double asNumber() const;
    std::string asString() const;
    const volt::util::DataBuffer::SharedPtr asStringDataBuffer() const;

    bool tryGetFunction(const std::string& key, ScriptFunction& result) const;
    bool tryGetBool(const std::string& key, bool& result) const;
    bool tryGetNumber(const std::string& key, double& result) const;
    bool tryGetString(const std::string& key, std::string& result) const;

    //Array subscription operators
    const ScriptObject operator[](std::string key) const
    {
      return get(key);
    }

    ScriptArray getKeyNames() const;

    template<typename NATIVE_TYPE, ScriptObject (*ScriptAccessorGetter)(
      NATIVE_TYPE*)>
    static void getterHelper(v8::Local<v8::String> property,
                             const v8::PropertyCallbackInfo<v8::Value>& Info)
    {
      try
      {
        void* selfUntyped = Info.Data().As<v8::External>()->Value();
        NATIVE_TYPE* self = static_cast<NATIVE_TYPE*>(selfUntyped);
        Info.GetReturnValue().Set(ScriptAccessorGetter(self).getValue());
      }
      catch (VoltJsRuntimeException &e)
      {
        Info.GetReturnValue().Set(
          v8::Isolate::GetCurrent()->ThrowException(
            v8::Exception::Error(StringToV8(e.what()))));
      }
    }

    template<typename NATIVE_TYPE, void (*ScriptAccessorSetter)(NATIVE_TYPE*,
        ScriptObject)>
    static void setterHelper(v8::Local<v8::String> property,
                             v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& Info)
    {
      try
      {
        void *selfUntyped = Info.Data().As<v8::External>()->Value();
        NATIVE_TYPE* self = static_cast<NATIVE_TYPE*>(selfUntyped);
        ScriptAccessorSetter(self, value);

      }
      catch (VoltJsRuntimeException &e)
      {
        v8::Isolate::GetCurrent()->ThrowException(
          v8::Exception::Error(StringToV8(e.what())));
      }
    }

    /**
     * Sets an accessor on a ScriptObject. This associates a name in the context of the object to a getter and setter method in C++.
     * For eg, if propertyName is "x" than object.x from JS would call ScriptAccessorGetter, and object.x = ?? from JS would call
     * ScriptAccessorSetter.
     * @tparam NATIVE_TYPE Type of object passed as selfPtr
     * @tparam ScriptAccessorGetter User defined getter function.
     * @tparam ScriptAccessorSetter User defined setter function
     * @param propertyName Name of the property that is exposed to JavaScript
     * @param selfPtr A pointer to the native object which will be passed to the user defined getter and setter.
     */
    template<typename NATIVE_TYPE, ScriptObject (*ScriptAccessorGetter)(
      NATIVE_TYPE*), void (*ScriptAccessorSetter)(NATIVE_TYPE*, ScriptObject)>
    void SetAccessor(std::string propertyName, NATIVE_TYPE* selfPtr)
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      v8::Handle<v8::External> selfWrapper = v8::External::New(
          v8::Isolate::GetCurrent(), selfPtr);

      if (!isObject())
      {
        if (data == nullptr)
        {
          data = new ScriptObjectData(
            v8::Object::New(v8::Isolate::GetCurrent()));
        }

        data->persistentValue.Reset(v8::Isolate::GetCurrent(),
                                    v8::Object::New(v8::Isolate::GetCurrent()));
      }

      getObjectUnsafe()->SetAccessor(StringToV8(propertyName),
                                     getterHelper<NATIVE_TYPE, ScriptAccessorGetter>,
                                     setterHelper<NATIVE_TYPE, ScriptAccessorSetter>, selfWrapper);
    }

  protected:
    void extractArrayBufferMemory();

};

//Comparator operator
bool operator==(const ScriptObject& lhs, const ScriptObject& rhs);

/**
 * Wraps a JavaScript function
 */
class ScriptFunction: public ScriptObject
{
    v8::Handle<v8::Function> getInternalFunction() const;

  public:
    ScriptFunction()
      : ScriptObject(ScriptObject::Null())
    {
    }
    ScriptFunction(v8::Handle<v8::Function> wrappedFunction);
    virtual ~ScriptFunction()
    {
    }

    /*
     * Invoke the JavaScript function
     * @param[in] args Array of script objects to pass as arguments to JS function
     * @return The JavaScript object returned from the function.
     */
    ScriptObject invoke(ScriptArray args) const;
};

/**
 * ScriptException can be returned in place of a ScriptObject when we want to throw an exception to JavaScript.
 * It can only be sent to JS, never received from it.
 */
class ScriptException: public ScriptObject
{
    std::string exceptionMessage;

  public:
    ScriptException(std::string message);
    virtual ~ScriptException()
    {
    }
};

/*Wrapper class for V8 function arguments. This is needed to support V8 v3.26 because the old Arguments class
 was replaced with a templated version. This interface is used to hide the template to maintain our untemplated
 ScriptArray interface. */
class Arguments
{
  public:
    virtual int Length() const = 0;
    virtual v8::Local<v8::Value> operator[](int) const = 0;
};

template<typename T>
class V8Arguments: public Arguments
{
    const v8::FunctionCallbackInfo<T>* args;
  public:
    V8Arguments(const v8::FunctionCallbackInfo<T>* args)
      : args(args)
    {
    }

    virtual int Length() const
    {
      return args->Length();
    }

    virtual v8::Local<v8::Value> operator[](int i) const
    {
      return (*args)[i];
    }
};

/**
 * Represents an indexed array of ScriptObjects. Can wrap around a regular JavaScript array, or
 * around function arguments.
 */
class ScriptArray: public ScriptObject
{
    Arguments* argsArray;
    bool useArgsArray; //flag for whether we're wrapping an Array or Arguments v8 object.

    v8::Handle<v8::Value> accessIndex(int index) const;

    v8::Handle<v8::Array> getInternalArray() const;

  public:
    ScriptArray();
    ScriptArray(v8::Handle<v8::Array> arr);
    ScriptArray(const ScriptObject &obj);
    ScriptArray(Arguments* args);
    virtual ~ScriptArray()
    {
    }

    //Lookup
    uint Length() const;
    bool has(uint index) const;
    ScriptObject get(uint index) const;
    bool tryGet(uint index, ScriptObject& result) const;
    void set(uint index, const ScriptObject &item);

    //Array subscription operators
    const ScriptObject operator[](uint index) const
    {
      return get(index);
    }

};

// allocator class thats going to be fed into the v8 for allocating ArrayBuffer memory
class ScriptArrayBufferAllocator: public v8::ArrayBuffer::Allocator
{
  public:
    ScriptArrayBufferAllocator()
    {
    }
    ;
    virtual ~ScriptArrayBufferAllocator()
    {
    }
    ;

    /**
     * Allocate |length| bytes. Return NULL if allocation is not successful.
     */
    virtual void* Allocate(size_t length);

    /**
     * Allocate |length| bytes. Return NULL if allocation is not
     * successful. Memory does not have to be initialized.
     */
    virtual void* AllocateUninitialized(size_t length);

    /**
     * Free the memory pointed to |data|. That memory is guaranteed to be
     * previously allocated by |Allocate|.
     */
    virtual void Free(void* data, size_t length);
};

/**
 * Represents an indexed array of ScriptObjects. Can wrap around a regular JavaScript array, or
 * around function arguments.
 */
class ScriptArrayBuffer: public ScriptObject
{
  public:
    ScriptArrayBuffer(size_t length);
    ScriptArrayBuffer(const void *aData, const int aLength);
    ScriptArrayBuffer(const volt::util::DataBuffer::SharedPtr &aBuffer);
    ScriptArrayBuffer(v8::Handle<v8::ArrayBuffer> arr);

    virtual ~ScriptArrayBuffer();
};

}
#endif /* SCRIPTTYPES_H_ */
