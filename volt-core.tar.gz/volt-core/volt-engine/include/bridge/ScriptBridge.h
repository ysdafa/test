/*
 * ScriptBridge.h
 *
 *  Created on: May 6, 2013
 *      Author: reza
 */

#ifndef SCRIPTBRIDGE_H_
#define SCRIPTBRIDGE_H_

#include <vector>
#include <map>
#include <set>
#include <cmath>
#include "ScriptTypes.h"
#include "Exception.h"
#include "logger.h"

namespace Bridge
{

/**
 * Abstract script bridge. Inheriting classes implement interface to map a c++ class to a JavaScript
 * Class.
 */
class ScriptBridge
{

    v8::UniquePersistent<v8::FunctionTemplate> constructorTemplate;
    v8::UniquePersistent<v8::Function> constructorInstance;

    bool blockConstructFromScript;

    static volt::util::Logger traceLogger;

  public:

    ScriptBridge();
    virtual ~ScriptBridge();

    /** Add the JavaScript object described by this bridge to the given scope
       * @param[in] classScope V8 scope to which this class should be bound, eg, the global object
       * */
    virtual void bridgeTo(v8::Handle<v8::ObjectTemplate> classScope);

    /**
     * Must be called after the v8::Context in which the class
     * should be bridged is entered and ready.
     */
    virtual void contextReady()
    {
      constructorInstance.Reset(v8::Isolate::GetCurrent(), GetConstructorTemplate()->GetFunction());
    } //used by derived class

    /** Construct an instance of this object
     */
    v8::Handle<v8::Object> instantiate(void*);

    /**Clean up any objects created by this bridge */
    void dispose();

    enum InternalField
    {
      NATIVE_POINTER = 0,
      COUNT = 1
    };

    /**
     * Declare the name of the class as is should be referred to by Javascript.
     */
    virtual const char* getScriptClassName() const = 0;

  protected:

    /*A list of pointers to objects created by this
    * ScriptBridge nstance */
    std::set<void*> instanceCreatedObjects;

    /** If true, instances will be garbage collected. If set to false, instances will persist unless deleted from C++ */
    bool allowGarbageCollection;

    /**
     * Release any script side references to a mapped object for garbage collection. This should be used when cleaning up an object
     * that has been deleted from the C++ side. There is no reason to call this if allowGarbageCollection has not been set.
     * @param[in] Pointer to the native side object. Will be used to identify the script side instance of the object.
     */
    static void releaseForGarbageCollection(ScriptBridge* bridge, void* pointerToMappedObject);

    /** A class representing the script's namespace, into which method and variable names can
     *be introduced.*/
    class ScriptContext;

    /** A mapping of all objects (void* pointers) exposed to javascript, with their memory address as keys.*/
    static std::map<void*, v8::UniquePersistent<v8::Object>* > createdObjects;
    //static std::map<ScriptObject::ExternalData_t*, int > allocatedExternalData;

    //Interface to be implemented by concrete bridges.

    /**
     * Bind callbacks to all getters, setters, and functions that should be exposed to javascript.
     * This function will be called once when the v8 binder is first initialized.
     * @param[in] context The context to which to which properties and methods of the object should be exposed. ScriptContext
     * wraps the methods that enable the mapping.
     */
    virtual void mapScriptInterface(ScriptContext&) = 0;

    /**
     * This method should construct an instance of the bridged object, and return a
     * void pointer to that instance. The pointer will be embedded in the javascript
     * object, allowing that object to be tied directly to the native instance.
     * @params[in] args A ScriptArray object, representing the arguments passed into the constructor
     */
    virtual void* constructFromScript(const ScriptArray& args) = 0;

    /**
     * Called when an object exposed to js has been garbage collected. To do anything with
     * the object, such as delete it, first reinterpret_cast pointerToDestroyedObject.
     * @param[in] pointerToDestroyedObject An untyped pointer to the native object
     */
    virtual void destroyFromScript(void* pointerToDestroyedObject) = 0;


    /**
     * This class represents the interface of the object from the JavaScript side. For eg, if this object is named "Foo" than
     * all methods and properties exposed to the context will be visible to JavaScript as Foo.methodX() or Foo.someProperty.
     */
    class ScriptContext
    {
        /** The V8 object template representing this object type */
        v8::Handle<v8::ObjectTemplate> instanceTemplate;

        /** The V8 object template representing the prototype of this object type*/
        v8::Handle<v8::ObjectTemplate> prototypeTemplate;

        /** The V8 object template representing the constructor
         *  object itself */
        v8::Handle<v8::Template> classConstructorTemplate;

      public:

        ScriptContext(v8::Handle<v8::ObjectTemplate> instance,
                      v8::Handle<v8::ObjectTemplate> prototype,
                      v8::Handle<v8::Template> constructor)
        {
          instanceTemplate = instance;
          prototypeTemplate = prototype;
          classConstructorTemplate = constructor;
        }

        void setClassConstant(std::string name, ScriptObject value)
        {
          classConstructorTemplate->Set(StringToV8(name), value.getValue());
        }

        /**
         * Capture all calls to a given method name on instances of this object in JS.
         * FUNCTION_CALL_HANDLER will be called when methodName is invoked from script. It will
         * receive arguments as a ScriptObject, and it will return a ScriptType. If no return
         * is necessary, return ScriptType.Undefined().
         * @tparam BRIDGED_OBJECT_TYPE the native type of this object
         * @tparam FUNCTION_CALL_HANDLER The function to be called on the native side when the captured function is invoked from JavaScript
         * @param methodName The name of the method on the JavaScript side.
         */
        template<typename BRIDGED_OBJECT_TYPE,
                 ScriptObject (*FUNCTION_CALL_HANDLER)(BRIDGED_OBJECT_TYPE*, const ScriptArray&)>
        void captureMethodCall(const char* methodName)
        {
          prototypeTemplate->Set(
            v8::String::NewFromUtf8(v8::Isolate::GetCurrent(),methodName),
            v8::FunctionTemplate::New(
              v8::Isolate::GetCurrent(),
              functionCallRouter<BRIDGED_OBJECT_TYPE, FUNCTION_CALL_HANDLER>)
          );
        }

        /**
         * Capture access to a given property name on instances of this object in JS.
         * ScriptGetterCallback and ScriptSetterCallback will be bound to read and write access
         * of the named property. Those callbacks can then mediate the binding of that property
         * from script to native. To make a property read only, simply do not supply a setter.
         * @tparam BRIDGED_OBJECT_TYPE the native type of this object
         * @tparam GETTER The function to be called on the native side when the captured prop name is queried from JavaScript
         * @tparam SETTER The function to be called on the native side when the captured prop name is mutated from JavaScript
         * @param methodName The name of the propert to expose to JavaScript.
         */
        template<typename BRIDGED_OBJECT_TYPE,
                 ScriptObject (*GETTER)(BRIDGED_OBJECT_TYPE*),
                 void (*SETTER)(BRIDGED_OBJECT_TYPE*, ScriptObject) = NULL>
        void capturePropertyAccess(const char* propertyName)
        {
          instanceTemplate->SetAccessor(v8::String::NewFromUtf8(v8::Isolate::GetCurrent(), propertyName),
                                        accessorRouter<BRIDGED_OBJECT_TYPE, GETTER>,
                                        mutatorRouter<BRIDGED_OBJECT_TYPE, SETTER>);
        }


        /**
         * Bind a number property on the script side directly to a getter and setter on native
         * side.
         * @tparam NATIVE_TYPE The class containing native property.
         * @tparam VALUE_TYPE The type of number eg int, double or float,
         * @tparam GETTER Pointer-to-member pointing at the getter.
         * @tparam SETTER Pointer-to-member pointing at the setter.
         * @param name The name of the property on the JavaScript side.
         */
        template
        < class NATIVE_TYPE, typename VALUE_TYPE,
        VALUE_TYPE (NATIVE_TYPE::* GETTER)(void) const,
        void (NATIVE_TYPE::* SETTER)(const VALUE_TYPE) >
        void bindNumber(const char* name)
        {
          instanceTemplate->SetAccessor(v8::String::NewFromUtf8(v8::Isolate::GetCurrent(),name),
                                        getJSNumber<NATIVE_TYPE, VALUE_TYPE, GETTER>,
                                        setJSNumber<NATIVE_TYPE, VALUE_TYPE, SETTER>);
        }


        /**
         * Bind a string property on the script side directly to a getter and setter on native
         * side.
         * @tparam NATIVE_TYPE The class containing native property.
         * @tparam GETTER Pointer-to-member pointing at the getter.
         * @tparam SETTER Pointer-to-member pointing at the setter.
         * @param name The name of the property on the JavaScript side.
         */
        template
        < class NATIVE_TYPE,
        std::string (NATIVE_TYPE::* GETTER)(void) const,
        void (NATIVE_TYPE::* SETTER)(const std::string &)
        >
        void bindString(const char* name)
        {
          instanceTemplate->SetAccessor( v8::String::NewFromUtf8(v8::Isolate::GetCurrent(),name),
                                         getJSString<NATIVE_TYPE,  GETTER>,
                                         setJSString<NATIVE_TYPE,  SETTER>) ;
        }

        /**
         * Bind a const string property on the script side directly to a getter and setter on native
         * side.
         * @tparam NATIVE_TYPE The class containing native property.
         * @tparam GETTER Pointer-to-member pointing at the getter.
         * @tparam SETTER Pointer-to-member pointing at the setter.
         * @param name The name of the property on the JavaScript side.
         */
        template
        < class NATIVE_TYPE,
        const std::string& (NATIVE_TYPE::* GETTER)(void) const,
        void (NATIVE_TYPE::* SETTER)(const std::string &)
        >
        void bindConstString(const char* name)
        {
          instanceTemplate->SetAccessor( v8::String::NewFromUtf8(v8::Isolate::GetCurrent(),name),
                                         getJSStringConst<NATIVE_TYPE,  GETTER>,
                                         setJSString<NATIVE_TYPE,  SETTER>) ;
        }

        /**
         * Bind a boolean property on the script side directly to a getter and setter on native
         * side.
         * @tparam NATIVE_TYPE The class containing native property.
         * @tparam GETTER Pointer-to-member pointing at the getter.
         * @tparam SETTER Pointer-to-member pointing at the setter.
         * @param name The name of the property on the JavaScript side.
         */
        template
        < class NATIVE_TYPE,
        bool (NATIVE_TYPE::* GETTER)(void) const,
        void (NATIVE_TYPE::* SETTER)(const bool)
        >
        void bindBoolean(const char* name)
        {
          instanceTemplate->SetAccessor( v8::String::NewFromUtf8(v8::Isolate::GetCurrent(),name),
                                         getJSBool<NATIVE_TYPE,  GETTER>,
                                         setJSBool<NATIVE_TYPE,  SETTER>) ;
        }


        template
        < class NATIVE_TYPE,
        const ScriptFunction& (NATIVE_TYPE::* GETTER)(void) const,
        void (NATIVE_TYPE::* SETTER)(const ScriptFunction&)
        >
        void bindFunction(const char* name)
        {
          instanceTemplate->SetAccessor( v8::String::NewFromUtf8(v8::Isolate::GetCurrent(),name),
                                         NULL, /* FIXME: currently getter not supported */
                                         setJSFunction<NATIVE_TYPE,  SETTER>) ;
        }


        /**
         * Bind a native property on the script side directly to a getter and setter on native
         * side. For eg, a linked list with nodes exposed to script will have as a field a pointer to
         * another node. This field on the script side should refer to the wrapper around the appropriate
         * native object.
         * @tparam NATIVE_TYPE The class containing native property.
         * @tparam FIELD_TYPE The type of the native property
         * @tparam GETTER Pointer-to-member pointing at the getter.
         * @tparam SETTER Pointer-to-member pointing at the setter.
         * @param name The name of the property on the JavaScript side.
         */
        template
        < class NATIVE_TYPE, typename FIELD_TYPE,
        FIELD_TYPE* (NATIVE_TYPE::* GETTER)(void) const,
        void (NATIVE_TYPE::* SETTER)(FIELD_TYPE*)
        >
        void bindNativeReference(const char* name)
        {
          instanceTemplate->SetAccessor( v8::String::NewFromUtf8(v8::Isolate::GetCurrent(),name),
                                         getNativeFieldFromJS<NATIVE_TYPE, FIELD_TYPE, GETTER>,
                                         setNativeFieldFromJS<NATIVE_TYPE, FIELD_TYPE, SETTER>);
        }

        /**
        * Bind a member function that takes no parameters and returns nothing.
        * @tparam NATIVE_TYPE The class containing native member.
          @tparam ACTION Pointer-to-member pointing a member function that takes no parameters and returns nothing
        * @param name The name of the property on the JavaScript side.
        */
        template
        < class NATIVE_TYPE,
        void (NATIVE_TYPE::* ACTION)(void)
        >
        void bindAction(const char* name)
        {
          prototypeTemplate->Set(
            v8::String::NewFromUtf8(v8::Isolate::GetCurrent(), name),
            v8::FunctionTemplate::New(v8::Isolate::GetCurrent(), actionCallRouter<NATIVE_TYPE, ACTION>)
          );
        }


    };

    /**
     * Gets a ScriptObject representing a pre-existing native object pointer. If the object did not already exist,
     * returns an empty (undefined) ScriptObject.
     * @tparam NATIVE_TYPE The type of native object pointer
     * @param native Pointer to the native object.
     * @returns ScriptObject representing existing native object, or an empty ScriptObject.
     */
    template<typename NATIVE_TYPE>
    static ScriptObject wrapExistingNativeObject(NATIVE_TYPE* native)
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());

      if(native == nullptr)
      {
        return ScriptObject::Null();
      }

      try
      {
        if(createdObjects.count(native) != 0)
        {
          v8::UniquePersistent<v8::Object>* createdObj =  createdObjects[native];
          v8::Local<v8::Object> existingObject = v8::Local<v8::Object>::New(v8::Isolate::GetCurrent(), *createdObj);
          return ScriptObject(existingObject);
        }
        else
        {
          return ScriptObject::Null();
        }
      }
      catch (std::out_of_range &e)
      {
        return ScriptObject::Null();
      }
    }

    /**
     * Gets a pointer to a native object given a ScriptObject known to wrap it.
     * @tparam[in] NATIVE_TYPE The type of the wrapped object.
     * @param[in] wrappedNativeObject ScriptObject known to wrap a NATIVE_TYPE
     */
    template<typename NATIVE_TYPE>
    static NATIVE_TYPE* unwrapNativeObject(ScriptObject wrappedNativeObject)
    {
      v8::HandleScope scope(v8::Isolate::GetCurrent());
      v8::Handle<v8::Value> wrapper = wrappedNativeObject.getValue();

      if(!wrapper->IsObject())
      {
        return nullptr;
      }

      v8::Handle<v8::Object> wrapperObj = wrapper.As<v8::Object>();
      return extract<NATIVE_TYPE>(wrapperObj);
    }

  private:

    //Templated helper functions:

    /**
     * Embeds a pointer to a NATIVE_TYPE instance inside a javascript object
     * @tparam[in] NATIVE_TYPE Type of the pointer to embed
     * @param nativeObject Pointer to native object to embed
     */
    template<typename NATIVE_TYPE>
    static v8::Handle<v8::Object> embed(NATIVE_TYPE* nativeObject)
    {
      v8::EscapableHandleScope handleScope(v8::Isolate::GetCurrent());

      v8::Handle<v8::ObjectTemplate> templ = v8::ObjectTemplate::New();
      templ->SetInternalFieldCount(ScriptBridge::InternalField::COUNT);

      v8::Local<v8::Object> jsObject = templ->NewInstance();
      jsObject->SetInternalField(ScriptBridge::InternalField::NATIVE_POINTER, v8::External::New(v8::Isolate::GetCurrent(), nativeObject));

      return handleScope.Escape(jsObject);
    }


    /**
     * Extracts a pointer to a NATIVE_TYPE instance from a script object
     * @tparam[in] NATIVE_TYPE Type of the pointer to extract
     * @param nativeObject Pointer to native object to extract
     */
    template<typename NATIVE_TYPE>
    static NATIVE_TYPE* extract(v8::Handle<v8::Object> jsObject)
    {
      v8::HandleScope handleScope(v8::Isolate::GetCurrent());

      if(jsObject->InternalFieldCount() < 1)
      {
        return nullptr;
      }

      v8::Handle<v8::External> field = v8::Handle<v8::External>::Cast(jsObject->GetInternalField(ScriptBridge::InternalField::NATIVE_POINTER));
      void* ptr = field->Value();

      if(ptr == nullptr)
      {
        throw VoltJsRuntimeException("Attempt to access destroyed JavaScript object.");
      }

      NATIVE_TYPE* nativeObject = static_cast<NATIVE_TYPE*>(ptr);

      return nativeObject;
    }

    /**
      * A version of extract that will never return null (but can
      * throw VoltJsRuntimeException.
     */
    template<typename NATIVE_TYPE>
    static NATIVE_TYPE* extractNoNull(v8::Handle<v8::Object> jsObject)
    {
      NATIVE_TYPE* result = extract<NATIVE_TYPE>(jsObject);

      if (result == nullptr)
      {
        throw VoltJsRuntimeException("Attempt to pass a JSObject as a native object");
      }

      return result;
    }

    //Generic getters and setters. One version for each primitive javascript type + one for pointers
    //to native types pointed to.

    //Numbers

    /**
     * Generic getter for JavaScript numbers.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam RETURN_TYPE Type of the field. Should be a number type, ie, int, double, long.
     * @tparam getter Native getter function
     * @param property Name of property. This is required to work with v8.
     * @param info V8 accessor info.
     */
    template<typename NATIVE_TYPE, typename RETURN_TYPE , RETURN_TYPE (NATIVE_TYPE::* getter)(void) const >
    static void getJSNumber(v8::Local<v8::String> property,  const v8::PropertyCallbackInfo<v8::Value>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(number) read: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());
        RETURN_TYPE value = (self->*getter)();
        info.GetReturnValue().Set( v8::Number::New(v8::Isolate::GetCurrent(), value ) );

      }
      catch (VoltJsRuntimeException &e)
      {
        info.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }

    /**
     * Generic setter for JavaScript numbers.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam VALUE_TYPE Type of the field. Should be a number type, ie, int, double, long.
     * @tparam setter Native setter function
     * @param property Name of property. This is required to work with v8.
     * @param value Value to set.
     * @param info V8 accessor info.
    */
    template<typename NATIVE_TYPE, typename VALUE_TYPE , void (NATIVE_TYPE::* setter)(const VALUE_TYPE) >
    static void setJSNumber(v8::Local<v8::String> property,
                            v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(number) write: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());

        if (!value->IsNumber() || ::isnan(value->NumberValue()))
        {
          throw VoltJsBadTypeException((std::string("Number expected for property \"") + V8ToString(property) + "\"").c_str());
        }

        VALUE_TYPE jsValue = value->NumberValue();
        VALUE_TYPE nativeValue = static_cast<VALUE_TYPE>(jsValue);
        (self->*setter)(nativeValue);
      }
      catch (VoltJsRuntimeException &e)
      {
        v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what())));
      }
    }

    //Strings

    /**
     * Generic getter for JavaScript strings.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam getter Native getter function
     * @param property Name of property. This is required to work with v8.
     * @param info V8 accessor info.
     */
    template<typename NATIVE_TYPE, std::string (NATIVE_TYPE::* STRING_GETTER)(void) const >
    static void getJSString(v8::Local<v8::String> property,  const v8::PropertyCallbackInfo<v8::Value>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(string) read: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());
        std::string inputString = (self->*STRING_GETTER)();
        info.GetReturnValue().Set( StringToV8(inputString) );
      }
      catch (VoltJsRuntimeException &e)
      {
        info.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }

    /**
     * Generic setter for JavaScript strings.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam setter Native setter function
     * @param property Name of property. This is required to work with v8.
     * @param value Value to set.
     * @param info V8 accessor info.
    */
    template<typename NATIVE_TYPE, void (NATIVE_TYPE::* STRING_SETTER)(const std::string&) >
    static void setJSString(v8::Local<v8::String> property,
                            v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(string) write: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());

        if (!value->IsString())
        {
          throw VoltJsBadTypeException( (std::string("String expected for property \"") + V8ToString(property) + "\"").c_str() );
        }

        (self->*STRING_SETTER)(V8ToString(value));
      }
      catch (VoltJsRuntimeException &e)
      {
        v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what())));
      }
    }


    /**
     * Generic getter for JavaScript strings.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam getter Native getter function
     * @param property Name of property. This is required to work with v8.
     * @param info V8 accessor info.
     */
    template<typename NATIVE_TYPE, const std::string& (NATIVE_TYPE::* STRING_GETTER)(void) const >
    static void getJSStringConst(v8::Local<v8::String> property,  const v8::PropertyCallbackInfo<v8::Value>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(string const) read: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());
        info.GetReturnValue().Set( StringToV8((self->*STRING_GETTER)()) );
      }
      catch (VoltJsRuntimeException &e)
      {
        info.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }

    //Booleans

    /**
     * Generic getter for JavaScript booleans.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam getter Native getter function
     * @param property Name of property. This is required to work with v8.
     * @param info V8 accessor info.
     */
    template<typename NATIVE_TYPE, bool (NATIVE_TYPE::* BOOL_GETTER)(void) const >
    static void getJSBool(v8::Local<v8::String> property,  const v8::PropertyCallbackInfo<v8::Value>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(boolean) read: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());
        bool result = (self->*BOOL_GETTER)();
        info.GetReturnValue().Set( v8::Boolean::New(v8::Isolate::GetCurrent(), result) );
      }
      catch (VoltJsRuntimeException &e)
      {
        info.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }

    /**
     * Generic setter for JavaScript booleans.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam setter Native setter function
     * @param property Name of property. This is required to work with v8.
     * @param value Value to set.
     * @param info V8 accessor info.
    */
    template<typename NATIVE_TYPE, void (NATIVE_TYPE::* BOOL_SETTER)(const bool) >
    static void setJSBool(v8::Local<v8::String> property,
                          v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(boolean) write: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());

        if (!value->IsBoolean())
        {
          throw VoltJsBadTypeException( (std::string("Boolean expected for property \"") + V8ToString(property) + "\"").c_str() );
        }

        (self->*BOOL_SETTER)(value->BooleanValue());
      }
      catch (VoltJsRuntimeException &e)
      {
        v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what())));
      }
    }

    //Functions

    /**
     * Generic setter for JavaScript functions.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam setter Native function
     * @param property Name of property. This is required to work with v8.
     * @param value Value to set.
     * @param info V8 accessor info.
    */
    template<typename NATIVE_TYPE, void (NATIVE_TYPE::* FUNCTION_SETTER)(const ScriptFunction&) >
    static void setJSFunction(v8::Local<v8::String> property,
                              v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(function) write: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());
        v8::Handle<v8::Function> function;
        (self->*FUNCTION_SETTER)(ScriptFunction(function.Cast(value)));
      }
      catch (VoltJsRuntimeException &e)
      {
        v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what())));
      }
    }



    //Native References

    /**
     * Generic getter for native objects that are embedded in js.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam FIELD_TYPE Type of the field.
     * @tparam getter Native getter function
     * @param property Name of property. This is required to work with v8.
     * @param info V8 accessor info.
     */
    template<typename NATIVE_TYPE, typename FIELD_TYPE, FIELD_TYPE* (NATIVE_TYPE::* fieldAccessor)(void) const >
    static void getNativeFieldFromJS(v8::Local<v8::String> property,  const v8::PropertyCallbackInfo<v8::Value>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(native object) read: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());
        FIELD_TYPE* nativeField = (self->*fieldAccessor)();

        if(nativeField == NULL)
        {
          info.GetReturnValue().Set( v8::Null(v8::Isolate::GetCurrent()) );
          return;
        }

        //If we've already wrapped this native object, send back that one
        if(createdObjects.count(nativeField))
        {
          v8::Handle<v8::Object> existingObject = v8::Local<v8::Object>::New(v8::Isolate::GetCurrent(), *createdObjects.at(nativeField));
          info.GetReturnValue().Set(  existingObject );
          return;
        }

        info.GetReturnValue().Set( embed<FIELD_TYPE>(nativeField) );
      }
      catch (VoltJsRuntimeException &e)
      {
        info.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }

    /**
     * Generic setter for native objects that are embedded in js.
     * @tparam NATIVE_TYPE Type of the native object
     * @tparam setter Native function
     * @param property Name of property. This is required to work with v8.
     * @param value Value to set.
     * @param info V8 accessor info.
    */
    template<typename NATIVE_TYPE, typename FIELD_TYPE, void (NATIVE_TYPE::* fieldSetter)(FIELD_TYPE*)>
    static void setNativeFieldFromJS(v8::Local<v8::String> property, v8::Local<v8::Value> value,
                                     const v8::PropertyCallbackInfo<void>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property(native object) write: "+ V8ToString(property));

      try
      {
        NATIVE_TYPE *self = extractNoNull<NATIVE_TYPE>(info.Holder());

        if(value->IsObject())
        {
          FIELD_TYPE* field = extract<FIELD_TYPE>(value->ToObject());

          if (field == nullptr)
          {
            throw VoltJsBadTypeException( (std::string("Invalid object assigned to property \"") + V8ToString(property) + "\"").c_str() );
          }

          (self->*fieldSetter)(field);
        }
        else
        {
          throw VoltJsBadTypeException( (std::string("Object expected for property \"") + V8ToString(property) + "\"").c_str() );
        }

      }
      catch (VoltJsRuntimeException &e)
      {
        v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what())));
      }
    }



    /**
     * Gets called when JavaScript application code tries to construct an instance of the bridged object.
     * @param[in] args The V8 arguments object
     */
    void onJSConstruct(const v8::FunctionCallbackInfo<v8::Value>& args);

    v8::Handle<v8::FunctionTemplate> GetConstructorTemplate();

    void registerConstructedObject(void* nativePtr, v8::Local<v8::Object> jsObject);



    //Router functions, to facilitate passing data through v8 and decoding it, but letting users
    //define the actual handling of javascript objects on a case by case basis.

    /**
     * This function makes it possible for an instance of the bridge to construct an object
     * even though the v8::InvocationCallback must be static. A pointer to the bridge instance
     * is embedded in the constructor template and can be accessed from the args variable
     * when the constructer is called. constuctCallRouter accepts the callback from v8 and forwards
     * it to the instance. This way bridges can use inheritence.
     * @param[in] args The V8 arguments object
     */
    static void constructCallRouter(const v8::FunctionCallbackInfo<v8::Value>& args);


    /**
     * Takes care of cleaning up the created objects map, and calls the destructor callback.
     * @param[in] isolate the V8 isolate
     * @param[in] object pointer to the persistent object that is no longer referenced from script
     * @param[in] self Ptr to the instance of ScriptBridge that allocated this object
     */
    static void OnGarbageCollect(const v8::WeakCallbackData<v8::Object, ScriptBridge >&);



    /**
     * Handles the v8 parts of calling a function with no parameters
     * that returns nothing.
     * @tparam BRIDGED_OBJECT_TYPE Type of the bridged object
     * @tparam ACTION_HANDLER User function to route to
     * @param args Arguments from JavaScript
     */
    template<typename BRIDGED_OBJECT_TYPE, void (BRIDGED_OBJECT_TYPE::* ACTION)(void) >
    static void actionCallRouter(const v8::FunctionCallbackInfo<v8::Value>& args)
    {
      v8::Handle<v8::String> funcName = args.Callee()->GetName()->ToString();
      LOG_DEBUG(traceLogger, "Trace JS Method call: " + V8ToString(funcName));

      try
      {
        BRIDGED_OBJECT_TYPE *bridgedObject = extractNoNull<BRIDGED_OBJECT_TYPE>(args.This());
        (bridgedObject->*ACTION)();
        args.GetReturnValue().Set( v8::Undefined(v8::Isolate::GetCurrent()) );
      }
      catch (VoltJsRuntimeException &e)
      {
        args.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }

    /**
     * Handles the v8 parts of getting recieving and returning a native function call from script
     * @tparam BRIDGED_OBJECT_TYPE Type of the bridged object
     * @tparam FUNCTION_CALL_HANDLER User function to route to
     * @param args Arguments from JavaScript
     * @returns Return value of invoked function
     */
    template<typename BRIDGED_OBJECT_TYPE, ScriptObject
    (*FUNCTION_CALL_HANDLER)(BRIDGED_OBJECT_TYPE*, const ScriptArray&)>
    static void functionCallRouter(const v8::FunctionCallbackInfo<v8::Value>& args)
    {
      v8::Handle<v8::String> funcName = args.Callee()->GetName()->ToString();
      LOG_DEBUG(traceLogger, "Trace JS Method call: "+ V8ToString(funcName));

      try
      {
        //Arguments are either an options object, or they are an array
        V8Arguments<v8::Value>* argumentObj = new V8Arguments<v8::Value>(&args);
        ScriptArray arguments = ScriptArray( argumentObj );

        BRIDGED_OBJECT_TYPE* bridgedObject = extract<BRIDGED_OBJECT_TYPE>(args.This());

        if (bridgedObject == nullptr)
        {
          throw VoltJsRuntimeException("Cannot call native method without object instance");
        }

        ScriptObject retval = FUNCTION_CALL_HANDLER(bridgedObject, arguments);
        args.GetReturnValue().Set(  retval.getValue() );
        delete argumentObj;

      }
      catch (VoltJsRuntimeException &e)
      {
        args.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }


    /**
     * Handles the native part of bridging a user defined getter function to a property access
     * @tparam BRIDGED_OBJECT_TYPE Type of the bridged object
     * @tparam accessorRouter User function to route to
     * @param args Arguments from JavaScript
     * @returns Return value of invoked function
     */
    template<typename BRIDGED_OBJECT_TYPE,
             ScriptObject (*GETTER)(BRIDGED_OBJECT_TYPE*)>
    static void accessorRouter(v8::Local<v8::String> property,
                               const v8::PropertyCallbackInfo<v8::Value>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property read: "+ V8ToString(property));

      try
      {
        BRIDGED_OBJECT_TYPE *bridgedObject = extractNoNull<BRIDGED_OBJECT_TYPE>(info.Holder());
        info.GetReturnValue().Set( GETTER(bridgedObject).getValue() );
      }
      catch (VoltJsRuntimeException &e)
      {
        info.GetReturnValue().Set( v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what()))) );
      }
    }


    /**
     * Handles the native part of bridging a user defined setter function to a property access
     * @tparam BRIDGED_OBJECT_TYPE Type of the bridged object
     * @tparam SETTER User function to route to
     * @param args Arguments from JavaScript
     * @returns Return value of invoked function
     */
    template<typename BRIDGED_OBJECT_TYPE,
             void (*SETTER)(BRIDGED_OBJECT_TYPE*, ScriptObject)>
    static void mutatorRouter(v8::Local<v8::String> property,
                              v8::Local<v8::Value> value,  const v8::PropertyCallbackInfo<void>& info)
    {
      LOG_DEBUG(traceLogger, "Trace JS Property write: "+ V8ToString(property));

      try
      {
        //determine the type of the incoming value and create the right ScriptValue subclass.

        BRIDGED_OBJECT_TYPE* bridgedObject = extractNoNull<BRIDGED_OBJECT_TYPE>(info.Holder());
        SETTER(bridgedObject, ScriptObject(value));
      }
      catch (VoltJsRuntimeException &e)
      {
        v8::Isolate::GetCurrent()->ThrowException(v8::Exception::Error(StringToV8(e.what())));
      }
    }

};

/*
 * A class that bridges a single instance of an object to JavaScript, rather than exposing a constructor method and acting as
 * a factory.
 */
class ScriptInstanceBridge : public ScriptBridge
{
    void* bridgedInstance;

  protected:

    ScriptInstanceBridge(void* instancePtr) : bridgedInstance(instancePtr) {}

    /** Add the JavaScript object described by this bridge to the given scope
     * @param[in] classScope V8 scope to which this object should be bound, eg, the global object*/
    virtual void bridgeTo(v8::Handle<v8::ObjectTemplate> classScope);

    virtual void* constructFromScript(const ScriptArray& args)
    {
      return bridgedInstance; //ScriptInstanceBridges never need to construct anything
    }
    virtual void destroyFromScript(void* pointerToDestroyedObject) {}   //Or destroy it.
    virtual void contextReady();

  private:
    v8::Persistent<v8::Object> scriptInstance;
    static  void instanceAccessor(v8::Local<v8::String> property,  const v8::PropertyCallbackInfo<v8::Value>& info);
};


}

#endif /* SCRIPTBRIDGE_H_ */
