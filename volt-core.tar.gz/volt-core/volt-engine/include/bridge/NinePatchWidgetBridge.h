#pragma once

#include "ImageWidgetBridge.h"
#include "NinePatchWidget.h"

namespace Bridge
{

/**
 * Bridge NinePatchWidgetBridge to JavaScript
 */
class NinePatchWidgetBridge : public ImageWidgetBridge
{

  public:

    virtual inline const char* getScriptClassName() const
    {
      return "NinePatchWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual inline void destroyFromScript(void* destroyedObject)
    {
      volt::graphics::NinePatchWidget* widget = reinterpret_cast<volt::graphics::NinePatchWidget*>(destroyedObject);
      delete widget;
    }

    virtual volt::graphics::ImageWidget* constructImageWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual volt::graphics::Color getDefaultColor()
    {
      return volt::graphics::Color(0, 0, 0, 0);
    }

};

}
