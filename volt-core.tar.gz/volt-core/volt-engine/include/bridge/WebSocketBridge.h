
#ifndef WEBSOCKETBRIDGE_H_
#define WEBSOCKETBRIDGE_H_

#include "ScriptBridge.h"
#include "ScriptTypes.h"
#include "WebSocketMessenger.h"
#include "macros.h"
#include <functional>
#include <clutter/clutter.h>

namespace Bridge
{

class WebSocketMessengerAdapter {
public:
	WebSocketMessengerAdapter();
	~WebSocketMessengerAdapter();
	WebSocketMessengerAdapter(std::string address);
	WebSocketMessengerAdapter(std::string address, std::string protocolName);


	void bind();
	void startService();
	void destroyService();
	void send(std::string message);

	void onOpen();
	void onMessage(std::string data);
	void onError();
	void onClose();
private:
	WebSocketMessenger *messenger;

	PROPERTY_CONST_REF(Bridge::ScriptFunction, onopen_callback);
	PROPERTY_CONST_REF(Bridge::ScriptFunction, onmessage_callback);
	PROPERTY_CONST_REF(Bridge::ScriptFunction, onerror_callback);
	PROPERTY_CONST_REF(Bridge::ScriptFunction, onclose_callback);
};


class WebSocketBridge : public ScriptBridge
{
public:
	WebSocketBridge();
	virtual ~WebSocketBridge();


	virtual inline const char* getScriptClassName() const
	{
		return "WebSocket";
	}

	virtual void mapScriptInterface(ScriptContext& aContext);

	virtual void* constructFromScript(const ScriptArray &aArgs);

	virtual inline void destroyFromScript(void *aDestroyedObject)
	{
		WebSocketMessengerAdapter *object =
			reinterpret_cast<WebSocketMessengerAdapter *>(aDestroyedObject);
		delete object;
	}

	static gboolean FireOnCallbacks(gpointer aData);
	static ScriptObject HandleSend(WebSocketMessengerAdapter *aSelf, const ScriptArray &aArgs);
	static ScriptObject HandleClose(WebSocketMessengerAdapter *aSelf, const ScriptArray &aArgs);
};



}
#endif 