/*
 * ScriptEngine.h
 *
 *  Created on: May 10, 2013
 *      Author: reza
 */

#ifndef SCRIPTENGINE_H_
#define SCRIPTENGINE_H_

#include <map>
#include <functional>

#include "ScriptBridge.h"
#include "logger.h"
#include "event_const.h"
#include "DataBuffer.h"

#include "VoltEventArgs.h"

// this enables the binding of global handler function
// onKeyEvent in java script, if it is defined
#define ENABLE_GLOBAL_KEY_HANDLER 1

namespace Bridge
{

typedef std::function<void(ScriptObject)> VoltKeyEventCallback;

/**
 * Loads and runs JavaScript.
 */
class ScriptEngine
{


  public:

    static volt::util::Logger LOGGER;

    ScriptEngine(bool exposeGC = false);
    virtual ~ScriptEngine();

    /**
     * Load and compile the javascript.
     * Return false if it fails.
     */
    bool loadScript(const std::string& script,
                    const bool isScriptLiteral = false,
                    const bool isMain = true,
                    const bool refreshEventCallback = false,
                    const VoltEventArgsMap &aJsData = VoltEventArgsMap());

    bool loadScript(volt::util::DataBuffer::SharedPtr script,
                    const std::string uri = "",
                    const bool isMain = true,
                    const bool refreshEventCallback = false,
                    const VoltEventArgsMap &aJsData = VoltEventArgsMap());

    bool loadScript(const std::string &aScript,
                    const VoltEventArgsMap &aJsData);

    /**
     * Trigger key event in javascript and pass keycode.
     */
    bool sendKeyEvent(const unsigned aKeyCode, const unsigned aType);

    /** Triggers flick input events in JavaScript (TV only) */
    bool sendFlickEvent(volt::util::MOUSE_FLICK);

    /** Triggers system events (anything aside from input) */
    bool sendInteruptEvent(volt::util::INTERUPT_EVENT,
                           const VoltEventArgsMap &aJsData = VoltEventArgsMap());

    /**
     * Fire listner callbacks for the ON_MESSAGE event.
     *
     * @param[in] aMsg Received message.
     *
     * @return true on success, false otherwise.
     */
    bool sendWorkerMessageEvent(const std::string &aMsg);

    /**
     * Fire listner callbacks for the ON_COMMAND event.
     *
     * @param[in] aCmd Received command.
     * @param[out] Vector of execution results.
     *
     * @return true if the command is handled, false otherwise.
     */
    bool sendWorkerCommandEvent(const std::string &aCmd,
                                std::vector<std::string> &aResults);

    bool sendEvent(const unsigned eventID,
                   const VoltEventArgsMap &aJsData = VoltEventArgsMap());

    void registerEvent(const unsigned eventID, ScriptFunction listener);

    void unregisterEvent(const unsigned eventID, ScriptFunction listener);

    void addBridge(ScriptBridge* bridge);

    void ready();

    /**
     * Implements the 'requireNoContext' JS bridge api.
     *
     * @param[in] jsModuleFileName JS filename to load/execute
     *
     * @return the exports object provided by the JS module, or false on failure
     */
    ScriptObject requireNoContext(const std::string &jsModuleFileName);

    bool dumpHeapSnapshot(const std::string &aPath);

  private:

    v8::Isolate* isolate;
    v8::UniquePersistent<v8::ObjectTemplate> globalObjectTemplate;
    v8::UniquePersistent<v8::Context> context;

#if ENABLE_GLOBAL_KEY_HANDLER
    v8::UniquePersistent<v8::Function> keyEventCallback;
#endif

    std::vector<ScriptBridge*> bridges;

    std::map<std::string, v8::UniquePersistent<v8::Value>* > modules;

    std::multimap<unsigned, ScriptFunction> eventListeners;

    unsigned int gc_threshold_;
    unsigned int gc_threshold_poll_interval_;

    static void gcCallback(v8::GCType type, v8::GCCallbackFlags flags);

    ScriptArrayBufferAllocator arrayBufferAllocator;

    v8::Handle<v8::Context> getContext() const;

    /**
     * Utility function for other load scripts
     */
    bool loadScript(v8::Handle<v8::String> &source,
                    const std::string uri,
                    const bool isMain,
                    const bool refreshEventCallback,
                    const VoltEventArgsMap &aJsData);

    /**
     * Compile JavaScript
     * @param[in] script JavaScript to compile
     * @param[out] compiledScript Contains the compiled script
     * @return True if compilation was successful
     */
    void compileScript(v8::Handle<v8::String> script, v8::Handle<v8::Script>& compiledScript,
                       const std::string &source_uri = "");

    /**
     * Run JavaScript script
     * @param[in] script JavaScript to run
     * @return True if able to run the script
     */
    void runScript(v8::Handle<v8::Script> script);

    /**
     * Add function to the global context, get a handle on it.
     * @param[in] name The name of the function
     * return Handle on the function, can be invoked.
     */
    v8::Handle<v8::Function> bindFunctionName(const char* name);

    /**
     * Creates the global object
     */
    v8::Handle<v8::ObjectTemplate> createGlobalObjectTemplate();

    /**
     * Execute a given JavaScript function with given args
     * @param[in] function the V8 handle on the function to execute
     * @param[in] object If the function is method, this is its object
     * @param[in] argc Number of arguments
     * @param[in] argv Array of arguments (V8 value handles)
     */
    void executeFunction(v8::Handle<v8::Function> function, v8::Handle<v8::Object> object = v8::Handle<v8::Object>(),
                         int argc = 0, v8::Handle<v8::Value>* argv = NULL);

    /**
     * Execute a function with the given name, in the global context.
     */
    void executeFunctionName(const char* name);



    //Callbacks for global functions:
    static void Require(const v8::FunctionCallbackInfo<v8::Value>& args);

    ScriptObject VoltEventArgsMapToScriptObject(const VoltEventArgsMap &aMap);
    ScriptArray VoltEventArgsListToScriptArray(const VoltEventArgsList &aList);

    /**
     * The implementation of require.
     * Behavior depends on whether or not we want to create v8 contexts.
     * If using requireNoContext, then 'jsModuleFileName' will be nonnull and we
     * wont create v8 contexts. Otherwise use old require.
     *
     * @param[in] args v8 function callback
     * @param[in] jsModuleFileName JS file to load without v8 contexts.
     * @return ScriptObject the exports of require
     */
    ScriptObject requireImpl(const v8::FunctionCallbackInfo<v8::Value>* const args, const std::string& jsModuleFileName = "");
};

}

#endif /* SCRIPTENGINE_H_ */
