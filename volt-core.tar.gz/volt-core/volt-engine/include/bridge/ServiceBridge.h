/*
 * ServiceBridge.h
 *
 *  Created on: July 1st, 2014
 *      Author: Joe Yee
 */

#ifndef SAMSUNG_KINGSCANYON_SERVICEBRIDGE_H_
#define SAMSUNG_KINGSCANYON_SERVICEBRIDGE_H_

#include "VoltConfig.h"

#include "ScriptBridge.h"
#include "TizenService.h"
#include <map>

#include "logger.h"

#define DEFINE_KEY_MAP_FUNCS(ns,key) int get##key() const { return ns::key; } \
                                     void set##key(int) {}

namespace Bridge
{
/* Tizen Service Operations */
enum SERVICE_OPERATION
{
  OPERATION_DEFAULT,
  OPERATION_EDIT,
  OPERATION_VIEW,
  OPERATION_PICK,
  OPERATION_CREATE_CONTENT,
  OPERATION_CALL,
  OPERATION_SEND,
  OPERATION_SEND_TEXT,
  OPERATION_SHARE,
  OPERATION_MULTI_SHARE,
  OPERATION_SHARE_TEXT,
  OPERATION_DIAL,
  OPERATION_SEARCH,
  OPERATION_DOWNLOAD,
  OPERATION_PRINT,
  OPERATION_COMPOSE,
  OPERATION_DATA_SUBJECT,
  OPERATION_DATA_TO,
  OPERATION_DATA_CC,
  OPERATION_DATA_BCC,
  OPERATION_DATA_TEXT,
  OPERATION_DATA_TITLE,
  OPERATION_DATA_SELECTED,
  OPERATION_DATA_PATH
};

class ServiceBridge : public ScriptBridge
{
  public:
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DEFAULT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_EDIT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_VIEW)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_PICK)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_CREATE_CONTENT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_CALL)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_SEND)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_SEND_TEXT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_SHARE)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_MULTI_SHARE)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_SHARE_TEXT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DIAL)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_SEARCH)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DOWNLOAD)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_PRINT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_COMPOSE)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_SUBJECT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_TO)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_CC)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_BCC)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_TEXT)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_TITLE)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_SELECTED)
    DEFINE_KEY_MAP_FUNCS(Bridge, OPERATION_DATA_PATH)

#if defined(BUILD_FOR_TV) && defined(TIZEN)
    struct CallbackMessage
    {
      TizenService *service;

      int result;
    };
#endif

    typedef std::map<TizenService*, ScriptFunction> CALLBACK_MAP;

    ServiceBridge();

    virtual ~ServiceBridge();

#if defined(BUILD_FOR_TV) && defined(TIZEN)
    static void ProxyRequestServiceCallback(TizenService *aSelf, int result);

    static void FireRequestServiceCallback(CallbackMessage *msg);
#endif

    static std::string LOGGER_NAME;

  protected:

    static ScriptObject HandleLaunch(TizenService *aSelf, const ScriptArray &aArgs);

    static ScriptObject HandleAddExtraData(TizenService *aSelf, const ScriptArray &aArgs);

    virtual inline const char* getScriptClassName() const
    {
      return "Service";
    }

    virtual void mapScriptInterface(ScriptContext& aContext);

    virtual void* constructFromScript(const ScriptArray &aArgs);

    virtual inline void destroyFromScript(void *aDestroyedObject)
    {
      TizenService *object = reinterpret_cast<TizenService *>(aDestroyedObject);
      callbackMap.erase(object);

      delete object;
    }

    static volt::util::Logger logger_;
    static CALLBACK_MAP callbackMap;
};

} /* namespace Bridge */
#endif /* SAMSUNG_KINGSCANYON_SERVICEBRIDGE_H_ */
