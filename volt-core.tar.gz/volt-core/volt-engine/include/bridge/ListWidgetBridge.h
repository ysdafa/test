/*
 * ListWidgetBridge.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef LISTWIDGETBRIDGE_H_
#define LISTWIDGETBRIDGE_H_

#include "LayoutBridge.h"
#include "ListWidget.h"

namespace Bridge
{

class ListWidgetBridge : public LayoutBridge
{
  public:
    ListWidgetBridge() {}
    virtual ~ListWidgetBridge() {}

  protected:
    virtual inline const char* getScriptClassName() const
    {
      return "ListWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

    static ScriptObject getSpacing(ListWidget* self);
    static void setSpacing(ListWidget* self, ScriptObject);

};

} /* namespace Bridge */

#endif /* LISTWIDGETBRIDGE_H_ */
