/*
 * FirstScreenListWidget.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef FIRSTSCREENLISTWIDGETBRIDGE_H_
#define FIRSTSCREENLISTWIDGETBRIDGE_H_

#include "WidgetBridge.h"
#include "FirstScreenListWidget.h"
#include <vector>

/*
 * Abstract Base class of all Widgets which impose positioning on their children
 */

namespace Bridge
{

class FirstScreenListWidgetBridge : public WidgetBridge
{
  public:

    virtual inline const char* getScriptClassName() const
    {
      return "FirstScreenListWidget";
    }

    virtual void mapScriptInterface(ScriptContext& context);

    virtual volt::graphics::Widget* constructWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual volt::graphics::Color getDefaultColor()
    {
      return volt::graphics::Color(0, 0, 0, 0);
    }


  private:

	// widget , fovea_meta
	static ScriptObject addCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject addContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject moveLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject moveRight(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject enableMoveToBegin(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject enableMoveToEnd(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setFocus(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject removeCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject removeContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject sendEnterSignal(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject riseFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject findCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject findContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject stopTransition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getPositionX(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getPositionY(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject changeIcon(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject reverseOSD(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject fallFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject off_transition_noanimaition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setFirstState(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject returnAnimation(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject addSubMain(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject changeContentLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject getCategoryIndexByID(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setProgress(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject callExtendAnimation(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject callExtendAnimationEx(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject focusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject unfocusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject enterOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject enlarge(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject highContrast(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setKeyPrevent(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setNomalTextColor(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setExtendBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setLiveImageBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setHorizontalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setVerticalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setContentLiveBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setTransitionBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);

    static ScriptObject startFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject stopFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject updateDominantColor(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject getLastMouseMovedTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);

	static ScriptObject setBarOpacityMax(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setBarOpacityZero(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setOnBackgroundClickListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	
	static ScriptObject setOnMoveFocuseListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setOnScrollLeftEndListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setOnScrollRightEndListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	
	//begin junhui.wang
	static ScriptObject changeControler(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setDim(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	//end junhui.wang

	static ScriptObject popupContextMenu(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);	
	static ScriptObject hideContextMenu(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject selectContextMenuItem(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject removeProgressAndDim(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setContextMenuFeedbackListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setContextMenuFocusListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setContextMenuUnfocusListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setContextMenuFlag(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);

    /*add by lin89.zhang for scale while reach the end of Bar begin*/
    static ScriptObject scaleLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject recoverLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args); 
    static ScriptObject scaleRight(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    static ScriptObject recoverRight(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
    /*add by lin89.zhang for scale while reach the end of Bar end*/

	//liang.wu for ad
	static ScriptObject addAdImg(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setADClickListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject setADEnterListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);

	//liang.wu for live
	static ScriptObject addHistoryLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject removeHistoryLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject addFeaturedLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject removeFeaturedLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
	static ScriptObject enableFeaturedLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args);
};

} /* namespace Bridge */

#endif /* FIRSTSCREENLISTWIDGETBRIDGE_H_ */
