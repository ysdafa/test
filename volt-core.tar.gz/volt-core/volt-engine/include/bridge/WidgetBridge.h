/*
 * WidgetBridge.h
 *
 *  Created on: May 10, 2013
 *      Author: reza
 */

#ifndef WIDGETBRIDGE_H_
#define WIDGETBRIDGE_H_

#include "ScriptBridge.h"
#include "Widget.h"
#include "event_const.h"

namespace Bridge
{
typedef std::pair<ScriptFunction, volt::graphics::Widget::EventHandle> WidgetEventCallback;
typedef std::pair<ScriptFunction, volt::graphics::Widget::FocusEventHandle> WidgetFocusEventCallback;
typedef std::pair<ScriptFunction, volt::graphics::Widget::KeyEventHandle> WidgetKeyEventCallback;

/**Data related to a particular widget that needs to be held by the WidgetBridge */
struct WidgetBridgeData
{
  /*This data structure caches, per widget, the proxy objects used for "nested properties." This is an optimization.*/
  std::map<std::string, ScriptObject> propertyProxyObjects;

  /*This maps mouse event types to the callback that should be triggered on that event*/
  std::map< volt::graphics::Widget::MouseEvent, std::vector<WidgetEventCallback> > eventCallbacks;

  /*This maps focus event types to the callback that should be triggered on that event*/
  std::map< volt::graphics::Widget::FocusEvent, std::vector<WidgetFocusEventCallback> > focusEventCallbacks;

  /*This maps key event ids to the callback that should be triggered on that event (when the widget is focused)*/
  std::map< unsigned int, std::vector<WidgetKeyEventCallback> > keyEventCallbacks;

};

// numberGetter and numberSetter templates

template<typename NATIVE_TYPE, typename NumberType, NumberType (NATIVE_TYPE::* GETTER)() const>
ScriptObject numberGetter(NATIVE_TYPE* self)
{
  return ScriptObject((self->*GETTER)());
}

template<typename NATIVE_TYPE, typename NumberType, void (NATIVE_TYPE::* SETTER)(NumberType)>
void numberSetter(NATIVE_TYPE* self, ScriptObject value)
{
  (self->*SETTER)(value.asNumber());
}


/**
 * Bridges Widget objects to JavaScript
 */
class WidgetBridge : public virtual ScriptBridge
{
    /*This data structure keeps necessary infomration about indivual widgets, such as ScriptFunctions registered
      to them as callbacks.*/
    static std::unordered_map<volt::graphics::Widget*, WidgetBridgeData> perWidgetData;

    static std::unordered_map<std::string, volt::graphics::Widget::MouseEvent> mouseEventIDMap;
    static std::unordered_map<std::string, volt::graphics::Widget::FocusEvent> focusEventIDMap;

  protected:

    virtual inline const char* getScriptClassName() const
    {
      return "Widget";
    }


    virtual void mapScriptInterface(ScriptContext& context);

    virtual void* constructFromScript(const ScriptArray& args);

    /** Widgets are never garbage collected (because they can
     *  persist unbeknownst to js runtime in the scene graph).
     *  However this method will still be invoked on program
     *  shutdown. */
    virtual inline void destroyFromScript(void* destroyedObject)
    {
      volt::graphics::Widget* widget = reinterpret_cast<volt::graphics::Widget*>(destroyedObject);
      delete widget;
    }

    /** Calls the actual constructor for widget. Inheriting widget bridges can override this if their construction logic
     * overlaps with Widget. */
    virtual volt::graphics::Widget* constructWidget(float x, float y, float width, float height, volt::graphics::Widget* parent, const ScriptArray& args);

    virtual volt::graphics::Color getDefaultColor()
    {
      return volt::graphics::Color(255, 255, 255, 255);
    }

  public:

    WidgetBridge()
    {
      allowGarbageCollection = false;
    }

    static std::vector<volt::graphics::Widget*> allWidgets;

    /**
     * Utility function to convert Widget::Color objects to the JavaScript representation: {r,g,b,a}
     * @param[in] color Widget::Color to convert
     * @return color as a JavaScript object
     */
    static ScriptObject ColorToScript(const volt::graphics::Color&);

    /**
     * Utility function to convert the JavaScript color representation to Widget::Color objects
     * @param[in] color JavaScript color object: {r,g,b,a}
     * @return color converted to Widget::Color object
     */
    static volt::graphics::Color ScriptToColor(const ScriptObject&);

    /**
     * Utility function to convert Widget::Corner objects to the JavaScript representation: {arcStep, radius}
     * @param[in] corner Widget::Corner to convert
     * @return corner as a JavaScript object
     */
    static ScriptObject CornerToScript(const volt::graphics::Corner& corner);

    /**
     * Utility function to convert the JavaScript corner representation to Widget::Corner objects
     * @param[in] corner JavaScript corner object: {arcStep, radius}
     * @return corner converted to Widget::Corner object
     */
    static volt::graphics::Corner ScriptToCorner(const ScriptObject&);

    /**
     * Utility function to convert Vector2 between native and JavaScript
     * @param[in] vector2 Vector2 object to convert
     * @return vector2 as a JavaScript object
     */
    static ScriptObject Vector2ToScript(volt::graphics::Vector2);

    /**
     * Utility function to convert Vector2 between native and JavaScript
     * @param[in] vector2 JavaScript object to convert
     * @return vector2 as a Vector2 native object
     */
    static volt::graphics::Vector2 ScriptToVector2(const ScriptObject&);

    /**
     * Utility function to convert Vector3 between native and JavaScript
     * @param[in] vector3 Vector3 object to convert
     * @return vector3 as a JavaScript object
     */
    static ScriptObject Vector3ToScript(volt::graphics::Vector3 scale);

    /**
     * Utility function to convert Vector3 between native and JavaScript
     * @param[in] vector3 JavaScript object to convert
     * @return vector3 as a Vector3 native object
     */
    static volt::graphics::Vector3 ScriptToVector3(const ScriptObject& scriptScale);

    /* Interpret string values to the appropriate Tween Mode enumeration */
    static volt::graphics::TweenMode deserializeTweenMode(std::string tweenStr);

    static volt::graphics::LayoutAlignment deserializeLayoutAlignment(std::string alignmentStr, volt::graphics::LayoutAlignment theDefault);
    static std::string serializeLayoutAlignment(volt::graphics::LayoutAlignment alignment);

    static std::string serializeScalingFilter(volt::graphics::ScalingFilter filter);
    static volt::graphics::ScalingFilter deserializeScalingFilter(std::string scalingFilterStr, volt::graphics::ScalingFilter theDefault);

    /** Function invoked when a Widget is destroyed.*/
    static void onDestruction(WidgetBridge* bridge, volt::graphics::Widget* destroyedWidget);

    /** Translate the destroyChildren function between JS and native.*/
    static ScriptObject handleDestroyChildren(volt::graphics::Widget* self, const ScriptArray& args);

    //Mouse Event stuff:
    static ScriptObject addEventListener(volt::graphics::Widget* self, const ScriptArray& args);
    static ScriptObject removeEventListener(volt::graphics::Widget* self, const ScriptArray& args);
    static ScriptObject dispatchEvent(volt::graphics::Widget* self, const ScriptArray& args);

    static ScriptObject reorderChildrenByDepth(volt::graphics::Widget* self, const ScriptArray& args);

  private:

    //Properties

    /** Translate access to the scale property between JS and native. */
    static ScriptObject getScale(volt::graphics::Widget* self);
    static void setScale(volt::graphics::Widget* self, ScriptObject);

    /** Translate access to the pivot property between JS and native. */
    static ScriptObject getPivot(volt::graphics::Widget* self);
    static void setPivot(volt::graphics::Widget* self, ScriptObject);

    /** Translate access to the origin property between JS and native. */
    static ScriptObject getOrigin(volt::graphics::Widget* self);
    static void setOrigin(volt::graphics::Widget* self, ScriptObject);

    /** Translate access to the anchor property between JS and native. */
    static ScriptObject getAnchor(volt::graphics::Widget* self);
    static void setAnchor(volt::graphics::Widget* self, ScriptObject);

    /** Translate access to the rotation property between JS and native. */
    static ScriptObject getRotation(volt::graphics::Widget* self);
    static void setRotation(volt::graphics::Widget* self, ScriptObject);

    static ScriptObject getPropertyColor(volt::graphics::Widget* self);
    static ScriptObject getPropertyTint(volt::graphics::Widget* self);

    //Methods

    /** Translate the destroy function between JS and native.*/
    static ScriptObject handleDestroy(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the show function between JS and native. */
    static ScriptObject show(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the hide function between JS and native. */
    static ScriptObject hide(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the getAbsolutePosition function between JS and
     *  native. */
    static ScriptObject getAbsolutePosition(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the getAbsolutePosition function between JS and
     *  native. */
    static ScriptObject getAbsoluteSize(volt::graphics::Widget* self, const ScriptArray& args);

    static ScriptObject getPositionOnScreen(volt::graphics::Widget* self, const ScriptArray& args);
    static ScriptObject getSizeOnScreen(volt::graphics::Widget* self, const ScriptArray& args);

    static ScriptObject getChildCount(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the addChild function between JS and native. */
    static ScriptObject addChild(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the removeChild function between JS and native. */
    static ScriptObject removeChild(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the getChild function between JS and native. */
    static ScriptObject getChild(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the getAncestor function between JS and native. */
    static ScriptObject getAncestor(volt::graphics::Widget* self, const ScriptArray& args);

    /** Translate the getDescendent function between JS and native. */
    static ScriptObject getDescendent(volt::graphics::Widget* self, const ScriptArray& args);

    /** Look up a child widget given either an index or a name
     * @param[in] self "This" widget
     * @param[in] identifier Either a integer index or a string name.
     * @return The widget referenced by identifier, or nullptr
     */
    static volt::graphics::Widget* getChildWidget(volt::graphics::Widget* self, ScriptObject identifier);

    static ScriptObject getBorder(volt::graphics::Widget* self);
    static void setBorder(volt::graphics::Widget* self, ScriptObject value);

    static ScriptObject getRoundedCorners(volt::graphics::Widget* self);
    static void setRoundedCorners(volt::graphics::Widget* self, ScriptObject value);

    static ScriptObject getGradient(volt::graphics::Widget* self);
    static void setGradient(volt::graphics::Widget* self, ScriptObject value);

    static void setMaxScalingFilter(volt::graphics::Widget* self, ScriptObject value);
    static ScriptObject getMaxScalingFilter(volt::graphics::Widget *self);
    static void setMinScalingFilter(volt::graphics::Widget *self, ScriptObject value);
    static ScriptObject getMinScalingFilter(volt::graphics::Widget* self);

    static ScriptObject getShadow(volt::graphics::Widget* self);
    static void setShadow(volt::graphics::Widget* self, ScriptObject value);

    static void setTint(volt::graphics::Widget* self, ScriptObject value);

    static ScriptObject getCurl(volt::graphics::Widget* self);
    static void setCurl(volt::graphics::Widget* self, ScriptObject value);

    static ScriptObject getCutThrough(volt::graphics::Widget* self);
    static void setCutThrough(volt::graphics::Widget* self, ScriptObject value);

    static bool invokeMouseCallback(const ScriptFunction& callback, volt::graphics::Widget* self, volt::graphics::Widget* origin,
                                    const volt::util::MOUSE_BUTTON mouseButton, volt::graphics::Vector2 coordinates);
    static void invokeFocusCallback(const ScriptFunction& callback);
    static void invokeKeyCallback(const ScriptFunction& callback, unsigned int, unsigned int);

    static ScriptObject getTransformedDepth(volt::graphics::Widget* self, const ScriptArray& args);

    static ScriptObject hasKeyFocus(volt::graphics::Widget* self, const ScriptArray& args);

  protected:

    //Methods to cache subproperty objects in order to speed up nested properties

    static inline bool hasPropertyProxy(volt::graphics::Widget* widget, const std::string name)
    {
      return perWidgetData.count(widget) > 0 && perWidgetData[widget].propertyProxyObjects.count(name) > 0;
    }

    static inline ScriptObject getPropertyProxy(volt::graphics::Widget* widget, const std::string name)
    {
      return perWidgetData[widget].propertyProxyObjects[name];
    }

    static inline void addPropertyProxy(volt::graphics::Widget* widget, std::string name, const ScriptObject& propertyProxy)
    {
      perWidgetData[widget].propertyProxyObjects[name] = propertyProxy;
    }

    //Methods to help handle colors as nested properties
    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const
    >
    static ScriptObject colorRGetter(NATIVE_TYPE* self)
    {
      return ScriptObject( static_cast<double>((self->*GETTER)().r ) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Color&)
    >
    static void colorRSetter(NATIVE_TYPE* self, ScriptObject value)
    {
      volt::graphics::Color color = (self->*GETTER)();
      (self->*SETTER)( volt::graphics::Color(value.asNumber(), color.g, color.b, color.a) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const
    >
    static ScriptObject colorGGetter(NATIVE_TYPE* self)
    {
      return ScriptObject( static_cast<double>((self->*GETTER)().g) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Color&)
    >
    static void colorGSetter(NATIVE_TYPE* self, ScriptObject value)
    {
      volt::graphics::Color color = (self->*GETTER)();
      (self->*SETTER)( volt::graphics::Color(color.r, value.asNumber(), color.b, color.a) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const
    >
    static ScriptObject colorBGetter(NATIVE_TYPE* self)
    {
      return ScriptObject( static_cast<double>((self->*GETTER)().b) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Color&)
    >
    static void colorBSetter(NATIVE_TYPE* self, ScriptObject value)
    {
      volt::graphics::Color color = (self->*GETTER)();
      (self->*SETTER)( volt::graphics::Color(color.r, color.g, value.asNumber(), color.a) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const
    >
    static ScriptObject colorAGetter(NATIVE_TYPE* self)
    {
      return ScriptObject( static_cast<double>((self->*GETTER)().a) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Color&)
    >
    static void colorASetter(NATIVE_TYPE* self, ScriptObject value)
    {
      volt::graphics::Color color = (self->*GETTER)();
      (self->*SETTER)( volt::graphics::Color(color.r, color.g, color.b, value.asNumber()) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Color (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Color&)
    >
    static ScriptObject getColor(NATIVE_TYPE* self)
    {
      ScriptObject color;
      color.SetAccessor<NATIVE_TYPE,
                        colorRGetter<NATIVE_TYPE, GETTER>,
                        colorRSetter<NATIVE_TYPE, GETTER, SETTER> >("r", self);
      color.SetAccessor<NATIVE_TYPE,
                        colorGGetter<NATIVE_TYPE, GETTER>,
                        colorGSetter<NATIVE_TYPE, GETTER, SETTER> >("g", self);
      color.SetAccessor<NATIVE_TYPE,
                        colorBGetter<NATIVE_TYPE, GETTER>,
                        colorBSetter<NATIVE_TYPE, GETTER, SETTER> >("b", self);
      color.SetAccessor<NATIVE_TYPE,
                        colorAGetter<NATIVE_TYPE, GETTER>,
                        colorASetter<NATIVE_TYPE, GETTER, SETTER> >("a", self);

      return color;
    }

    template
    < typename NATIVE_TYPE,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Color&)
    >
    static void setColor(NATIVE_TYPE* self, ScriptObject val)
    {
      volt::graphics::Color color = WidgetBridge::ScriptToColor(val);
      (self->*SETTER)(color);
    }

    ////////////
    //Methods to help handle corners as nested properties
    template
    < typename NATIVE_TYPE,
    volt::graphics::Corner (NATIVE_TYPE::* GETTER)(void) const
    >
    static ScriptObject arcStepGetter(NATIVE_TYPE* self)
    {
      return ScriptObject( static_cast<double>((self->*GETTER)().arcStep ) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Corner (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Corner&)
    >
    static void arcStepSetter(NATIVE_TYPE* self, ScriptObject value)
    {
      volt::graphics::Corner corner = (self->*GETTER)();
      (self->*SETTER)( volt::graphics::Corner(corner.radius, value.asNumber()) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Corner (NATIVE_TYPE::* GETTER)(void) const
    >
    static ScriptObject radiusGetter(NATIVE_TYPE* self)
    {
      return ScriptObject( static_cast<double>((self->*GETTER)().radius ) );
    }

    template
    < typename NATIVE_TYPE,
    volt::graphics::Corner (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Corner&)
    >
    static void radiusSetter(NATIVE_TYPE* self, ScriptObject value)
    {
      volt::graphics::Corner corner = (self->*GETTER)();
      (self->*SETTER)( volt::graphics::Corner(value.asNumber(), corner.arcStep) );
    }


    template
    < typename NATIVE_TYPE,
    volt::graphics::Corner (NATIVE_TYPE::* GETTER)(void) const,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Corner&)
    >
    static ScriptObject getCorner(NATIVE_TYPE* self)
    {
      ScriptObject corner;
      corner.SetAccessor<NATIVE_TYPE,
                         radiusGetter<NATIVE_TYPE, GETTER>,
                         radiusSetter<NATIVE_TYPE, GETTER, SETTER> >("radius", self);

      corner.SetAccessor<NATIVE_TYPE,
                         arcStepGetter<NATIVE_TYPE, GETTER>,
                         arcStepSetter<NATIVE_TYPE, GETTER, SETTER> >("arcStep", self);

      return corner;
    }

    template
    < typename NATIVE_TYPE,
    void (NATIVE_TYPE::* SETTER)(const volt::graphics::Corner&)
    >
    static void setCorner(NATIVE_TYPE* self, ScriptObject val)
    {
      volt::graphics::Corner corner= WidgetBridge::ScriptToCorner(val);
      (self->*SETTER)(corner);
    }

};

}

#endif /* WIDGETBRIDGE_H_ */
