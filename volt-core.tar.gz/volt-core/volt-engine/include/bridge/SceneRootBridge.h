/*
 * SceneRootBridge.h
 *
 *  Created on: Jun 24, 2013
 *      Author: reza
 */

#ifndef SCENEROOTBRIDGE_H_
#define SCENEROOTBRIDGE_H_

#include "ScriptBridge.h"
#include "SceneRoot.h"
#include "WidgetBridge.h"

namespace Bridge
{

class SceneRootBridge : public ScriptInstanceBridge
{
  public:

    SceneRootBridge(volt::graphics::SceneRoot* root) : ScriptInstanceBridge(root) {}

    virtual void mapScriptInterface(ScriptContext& context);
    virtual const char* getScriptClassName() const
    {
      return "scene";
    };

    static ScriptObject getSize(volt::graphics::SceneRoot* self);
    static void setSize(volt::graphics::SceneRoot* self, ScriptObject value);

    static ScriptObject getColor(volt::graphics::SceneRoot* self);
    static void setColor(volt::graphics::SceneRoot* self, ScriptObject value);

    static ScriptObject getChildCount(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject addChild(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject getChild(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject removeChild(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject getDescendent(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject getAncestor(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject handleDestroyChildren(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject getKeyFocus(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject setKeyFocus(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject clearKeyFocus(volt::graphics::SceneRoot* self, const ScriptArray& args);

    static ScriptObject show(volt::graphics::SceneRoot* self, const ScriptArray& args);
    static ScriptObject hide(volt::graphics::SceneRoot* self, const ScriptArray& args);


};

} /* namespace Bridge */
#endif /* SCENEROOTBRIDGE_H_ */
