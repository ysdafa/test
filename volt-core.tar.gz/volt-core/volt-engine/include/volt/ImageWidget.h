/*
 * ImageWidget.h
 *
 *  Created on: May 23, 2013
 *      Author: reza
 */

#ifndef IMAGEWIDGET_H_
#define IMAGEWIDGET_H_

#include "VoltImage.h"
#include "Widget.h"
#include "logger.h"
#include <memory>
#include <boost/enable_shared_from_this.hpp>
#include "DataBuffer.h"
#include <map>

namespace volt
{
namespace graphics
{

class Image;

typedef std::function<void(bool success)> ImageWidgetReadyCallback;

/**
 * A Widget that displays an Image.
 */
class ImageWidget: public Widget
{

  public:
    enum FillMode //Warning: This is one to one with ClutterContentGravity enum. Do not re-order.
    {
      Top_Left,
      Top,
      Top_Right,
      Left,
      Center,
      Right,
      Bottom_Left,
      Bottom,
      Bottom_Right,
      Stretch,
      Fit,
      // add for new requirement
  	  Vertical_Fit,
  	  Horizontal_Fit,
  	  Top_Left_Crop,
  	  Top_Crop,
  	  Top_Right_Crop,
  	  Left_Crop,
  	  Center_Crop,
  	  Right_Crop,
  	  Bottom_Left_Crop,
  	  Bottom_Crop,
  	  Bottom_Right_Crop
    };

	//TODO: these are defined in HQ's gdk modifications.
	typedef enum _Gdk_Color_Pick_Region__
	{
		GDK_COLORPICK_TOP = 0,
		GDK_COLORPICK_MIDDLE,
		GDK_COLORPICK_BOTTOM,
	}GdkColorPickRegion;

	typedef struct _Gdk_PickColor_
	{
		int perc;
		unsigned char R;
		unsigned char G;
		unsigned char B;
	    int x1;
		int y1;
	    int x2;
		int y2;
		GdkColorPickRegion region;		
	}GdkPickColor;	// TODO : GdkPickColor will be changed to GdkColorPick in future

    ImageWidget(float x, float y, Widget* parent = nullptr,
                ImageWidgetReadyCallback ready = nullptr);
    ImageWidget(float x, float y, float width, float height, Widget* parent =
                  nullptr, ImageWidgetReadyCallback ready = nullptr);
    virtual ~ImageWidget();

    /** The source URI from which to get and load the image. Can be file path or URL. */
    void setSource(const std::string&);
    void setSource(volt::util::DataBuffer::SharedPtr buffer);
    std::string getSource() const;
    void setSource(Image *aImage);
    Image* getSourceImage() const;

    bool getColorPicking(int percentage, Color* color);
    bool getColorPicking(int percentage, int x1, int x2, int y1, int y2, Color* color);

    bool getImageCroppedCoord(float* x1, float* y1, float* x2, float* y2);

    void setAsyncLoading(const bool async);
    bool getAsyncLoading() const;

    FillMode getFillMode() const
    {
      return fillMode;
    }
    void setFillMode(FillMode mode);

    /** Width in pixels. Width on ImageWidgets is determined by default by the native size of the image. Setting it will scale the image */
    virtual float getWidth() const;
    virtual void setWidth(float width);

    /** Height in pixels. Height on ImageWidgets is determined by default by the native size of the image. Setting it will scale the image */
    virtual float getHeight() const;
    virtual void setHeight(float height);

    inline ImageWidgetReadyCallback getOnReady() const
    {
      return onReady;
    }
    inline void setOnReady(const ImageWidgetReadyCallback& readyCallback)
    {
      onReady = readyCallback;
    }

    static std::string LOGGER_NAME;

    /** Callback triggered when an image is finished loading */
    void onImageLoaded(VoltImage* image, bool success);

    /** Color Pick */
    static void ConfigureColorPicking(const std::map<std::string, int> args);
    static std::vector<std::string> getColorPickOptionKeys(void);
    static std::map<std::string, int> colorPickOptions;

  protected:
    /** True if image dimensions have been scaled*/
    bool scaleImageDimensions;

    /** Attach the given volt image to this ImageWidget using
     *  clutter_content_set */
    virtual void attachVoltImage(VoltImage *image);

    virtual const std::string& getWidgetTypeString() const;
    virtual void writeSceneGraphExtraJson(std::ostream &aOut, const std::string aIndent) const;


  private:

    /** The source URI for the displayed image*/
    std::string imageSourceUri;

    /** The Image for the displayed image */
    boost::shared_ptr<Image> imageSource;

    /** Buffer holding the image data to be shared with pixbuf **/
    volt::util::DataBuffer::SharedPtr imageBuffer;

    /** Callback invoked when image is loaded */
    ImageWidgetReadyCallback onReady;

    bool isReady;

    /** What to do with the image if the widget size is greater
     *  than the image size. */
    FillMode fillMode;

    static std::unordered_map<int, ImageWidget*> loadImageReceivers;

    static int nextLoadImageReceiverID;

    int loadImageReceiverID;

    bool asyncLoad;

    volt::util::Logger logger_;

    /** Create kicks off the process of loading an image and
     *  registers for a callback on completion */
    void BeginLoadImage(std::string imageUri);

    /** Routes image loaded callbacks to ImageWidgets registered to
     *  receive them */
    static void onImageLoadedRouter(int recieverID, VoltImage* image,
                                    bool success);

    /** Cancel loading any images  */
    void CancelLoadImage();

    /**
     * This is the callback called by the Image class when it finishes loading
     * the image data.
     * @param[in] image Pointer to an Image object.
     */
    void OnImageLoadedCallback(Image *aImage);

    /* Color Pick */
    gboolean getColorPickValues(GdkPixbuf *pixbuf, GdkPickColor *pick_color) const;
    bool checkGreyScaleSimple( const int r , const int g , const int b ) const;
};
};
};

#endif /* IMAGEWIDGET_H_ */
