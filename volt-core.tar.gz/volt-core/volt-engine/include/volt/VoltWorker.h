#ifndef SAMSUNG_KINGSCANYON_VOLTWORKER_H
#define SAMSUNG_KINGSCANYON_VOLTWORKER_H

#include <string>
#include <functional>

#include "Widget.h"

class VoltWorker
{
  public:
    /**
     * Callback to handle the incoming messages.
     * @param[in] Received message.
     */
    typedef std::function<void (const std::string)> OnMessageCallback;

    /**
     * Callback to handle the incoming commands.
     * @param[in] Received message.
     * @param[in] Execution result.
     */
    typedef std::function<void (const std::string, std::string &)> OnCommandCallback;

    /**
     * Callback to handle worker errors.
     * @param[in] Error message.
     */
    typedef std::function<void (const std::string)> OnErrorCallback;

  public:
    VoltWorker();
    virtual ~VoltWorker();

    const std::string& ID() const;

    void RegisterOnMessageCallback(OnMessageCallback aCallback);

    void RegisterOnCommandCallback(OnCommandCallback aCallback);

    void RegisterOnErrorCallback(OnErrorCallback aCallback);

    bool Run(const std::string &aUri);

    bool IsRunning() const;

    void Terminate(const double aMaxWaitTime = 5000);

    bool PostMessage(const std::string &aMsg);

    bool ExecCommand(const std::string &aCmd,
                     std::vector<std::string> &aResults);

    void OnMessage(const std::string &aMsg);

    bool OnCommand(const std::string &aCmd, std::string &aResult);

    void OnError(const std::string &aMsg);

  private:
    static unsigned int WORKER_ID;

    std::string worker_id_;

    OnMessageCallback on_message_;

    OnCommandCallback on_command_;

    OnErrorCallback on_exception_;
};

#endif
