#if !defined(NDEBUG)
#define BOOST_MULTI_INDEX_ENABLE_INVARIANT_CHECKING
#define BOOST_MULTI_INDEX_ENABLE_SAFE_MODE
#endif

#include <algorithm>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/hashed_index.hpp>
#include <boost/multi_index/mem_fun.hpp>
#include <boost/multi_index/sequenced_index.hpp>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
#include <string>

#include "logger.h"

using namespace boost::multi_index;

/* An MRU (most recently used) list keeps record of the last n
 * inserted items, listing first the newer ones. Care has to be
 * taken when a duplicate item is inserted: instead of letting it
 * appear twice, the MRU list relocates it to the first position.
 */

template <typename Item>
class mru_list
{
    typedef multi_index_container<
    Item,
    indexed_by<sequenced<>,
    hashed_unique<const_mem_fun<Item,std::string,&Item::getHash> >
    >
    > item_list;

  public:
    typedef Item                         item_type;
    typedef typename item_list::iterator iterator;
    typedef typename item_list::template nth_index<1>::type item_list_by_hash;

    mru_list() : max_size(0), current_size(0) {}

    void accessed(const std::string& hash)
    {
      item_list_by_hash& hash_index = il.get<1>();
      auto iter = hash_index.find(hash);

      if (iter != hash_index.end())
      {
        iterator it2 = il.project<0>(iter);
        il.relocate(il.begin(), it2); /* put in front */
      }
    }

    bool empty() const
    {
      return il.empty();
    }

    void insert(const item_type& item)
    {
      std::pair<iterator,bool> p=il.push_front(item);

      // second will be false if item is already in list.
      if (!p.second)                       /* duplicate item */
      {
        il.relocate(il.begin(),p.first); /* put in front */
      }
      else
      {
        current_size += item.size();
      }
    }

    Item pop_back()
    {
      if (il.empty())
      {
        return Item();
      }

      Item backItem = il.back();
      il.pop_back();
      current_size -= backItem.size();

      return backItem;
    }

    Item findByHash(const std::string& hashStr) const
    {
      Item item;
      const item_list_by_hash& hash_index = il.get<1>();
      auto iter = hash_index.find(hashStr);

      if (iter != hash_index.end())
      {
        item = *iter;
      }

      return item;
    }

    void clear()
    {
      il.clear();
      current_size = 0;
    }

    iterator begin()
    {
      return il.begin();
    }
    iterator end()
    {
      return il.end();
    }

    void set_max_size(size_t max_size_in)
    {
      max_size = max_size_in;
    }
    size_t get_max_size() const
    {
      return max_size;
    }
    size_t get_current_size() const
    {
      return current_size;
    }

    /* Utilities to save and load the MRU list, internally
     * based on Boost.Serialization.
     */

    void save_to_file(const char* file_name) const
    {
      std::ofstream ofs(file_name);

      try
      {
        boost::archive::binary_oarchive oa(ofs);
        oa << boost::serialization::make_nvp("mru", *this);
      }
      catch (std::exception &e)
      {
        LOG_WARN(volt::util::Logger::DefaultLogger(),
                 "Failed to save MRU catalog to " <<
                 (file_name ? file_name : "???") << ": " << e.what());
      }
    }

    bool load_from_file(const char* file_name)
    {
      std::ifstream ifs(file_name);

      try
      {
        boost::archive::binary_iarchive ia(ifs);
        ia >> boost::serialization::make_nvp("mru", *this);
        return true;
      }
      catch (std::exception &e)
      {
        LOG_WARN(volt::util::Logger::DefaultLogger(),
                 "Failed to load MRU catalog from " <<
                 (file_name ? file_name : "???") << ": " << e.what());
        return false;
      }

      return true;
    }

  private:
    item_list   il;
    std::size_t  max_size;  // in bytes
    std::size_t  current_size; // in bytes

    /* serialization support */

    friend class boost::serialization::access;

    template<class Archive>
    void serialize(Archive& ar,const unsigned int)
    {
      ar & BOOST_SERIALIZATION_NVP(il);
      ar & BOOST_SERIALIZATION_NVP(max_size);
      ar & BOOST_SERIALIZATION_NVP(current_size);
    }
};

