#pragma once

#include "VoltConfig.h"

#include "VoltProcessManager.h"

#include <clutter/clutter.h>

#include "VoltProcessManager.h"
#include "VoltProcessRuntime.h"

#include "ScriptEngine.h"
#include "SceneRoot.h"
#include "VoltWorkerBridge.h"

class VoltFullProcessRuntime : public VoltProcessRuntime
{
  public:
    static volt::util::Logger LOGGER;

  public:
    VoltFullProcessRuntime();
    virtual ~VoltFullProcessRuntime();

    Bridge::ScriptEngine* GetScriptEngine() const;

    ClutterActor* GetMainStage() const;

    volt::graphics::SceneRoot* GetSceneRoot() const;

    void ShowUI(const VoltEventArgsMap &aArgs = VoltEventArgsMap());

    void HideUI(const VoltEventArgsMap &aArgs = VoltEventArgsMap());

    void ResetApp(const VoltEventArgsMap &aArgs = VoltEventArgsMap());

    bool ReturnToPrevApp() const;
    void SetReturnToPrevApp(const bool aFlag);

    static bool IsPathAllowed(const char *aPath);

    /* From IVoltProcessRuntime */
    virtual bool Initialize(int aArgc, char **aArgv,
                            const VoltEngine::ExternalData &aDAta);
    virtual bool Main();
    virtual void Quit();
    virtual void Cleanup();
		
		void RegisterPluginBridge(Bridge::ScriptBridge* bridge);

  protected:
    bool InitializeIPC();

    bool SetDeviceConfig();

    bool InitializeGraphics();

    bool RegisterJsBridges(const VoltEngine::BridgeList &aExternalBridges);

    bool IsQuitting() const;

    void HandleKeyEvent(const int aType, const int aKeyCode);

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
    static gboolean OnKeyEvent(void *aCallbackData);
    static gboolean OnMouseEvent(void *aCallbackData);
    static gboolean OnFlickEvent(void *aCallbackData);
    static gboolean OnShowEvent(void *aSelf);
    static gboolean OnHideEvent(void *aSelf);
#else
    static gboolean OnStageDestroy(ClutterActor * /* unused */, gpointer aSelf);
    static gboolean OnStageActivate(ClutterStage * /* unused */, gpointer aSelf);
    static gboolean OnStageDeactivate(ClutterStage * /* unused */, gpointer aSelf);
    static gboolean OnKeyEvent(ClutterActor * /* unused */,
                               ClutterEvent *aEvent, gpointer /* unused */);						   
	static gboolean OnObjectDump(ClutterActor * /* unused */,
                               ClutterEvent *aEvent, gpointer /* unused */);
#endif

#ifdef TIZEN
/*
    static void OnObjectDump(ClutterStage * ,
                             ClutterObjectDumpPrintMethod aPrintMethod,
                             gpointer aSelf);
							 */
    static void OnWakeUp(int aReason, void *aSelf);
    static int OnPowerOff(int aOption, void *aSelf);
#endif

  public:
    std::shared_ptr<Bridge::ScriptEngine> script_engine_;
    Bridge::VoltWorkerBridge *worker_bridge_;
    ClutterActor *main_stage_;
    volt::graphics::SceneRoot *scene_root_;

    bool loading_script_;
    bool clutter_running_;

    bool quitting_;

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
    bool return_to_prev_app_;
#else
    std::vector<gulong> signal_handlers_;
#endif
};
