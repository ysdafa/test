/*
 * AulApp.h
 *
 *  Created on: June 26, 2014
 *      Author: Joe Yee
 */

#ifndef SAMSUNG_KINGSCANYON_AULAPP_H_
#define SAMSUNG_KINGSCANYON_AULAPP_H_

#include "VoltConfig.h"

#include "logger.h"

#include <string>
#include <map>
#include "clutter_helper.h"
#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include <bundle.h>
#endif

class TizenAul
{
  public:
    TizenAul();

    virtual ~TizenAul();

#if defined(BUILD_FOR_TV) && defined(TIZEN)
    int LaunchApp(std::string &appId, bundle *args);
    int LaunchAppEx(std::string &appId, bundle *args);
	int LaunchAppAsync(std::string &appId, bundle *args);
	int OpenApp(std::string &appId);
	int ResumeApp(std::string &appId);
	int ResumePID(int in_pid);
	int AppIsRunning(std::string &appId);

    int OpenService(std::string &serviceId, bundle *args, bool callback);

    int Terminate();
	int TerminatePID(int in_pid);
	int TerminateApp(std::string &appId);
	int TerminatePkg(std::string &pkgName);
	std::string  GetCallerAppID();
#endif

  protected:
    static bool isAulInitialized;
    static volt::util::Logger LOGGER;

  private:

    int pid_;
};

#endif /* SAMSUNG_KINGSCANYON_AULAPP_H_ */
