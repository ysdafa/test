/*
 * VoltImage.h
 *
 *  Created on: July 29, 2013
 *      Author: jim dinunzio
 */

#ifndef VOLTIMAGE_H
#define VOLTIMAGE_H

#include <clutter/clutter.h>
#include <gdk-pixbuf/gdk-pixbuf.h>

G_BEGIN_DECLS

#define VOLT_TYPE_IMAGE              (volt_image_get_type ())
#define VOLT_IMAGE(obj)              (G_TYPE_CHECK_INSTANCE_CAST ((obj), VOLT_TYPE_IMAGE, VoltImage))
#define VOLT_IS_IMAGE(obj)           (G_TYPE_CHECK_INSTANCE_TYPE ((obj), VOLT_TYPE_IMAGE))
#define VOLT_IMAGE_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST ((klass), VOLT_TYPE_IMAGE, VoltImageClass))
#define VOLT_IS_IMAGE_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), VOLT_TYPE_IMAGE))
#define VOLT_IMAGE_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS ((obj), VOLT_TYPE_IMAGE, VoltImageClass))

/**
 * VOLT IMAGE_ERROR:
 *
 * Error domain for the #VoltImageError enumeration.
 *
 */
#define VOLT_IMAGE_ERROR             (volt_image_error_quark ())

typedef struct _VoltImage           VoltImage;
typedef struct _VoltImagePrivate    VoltImagePrivate;
typedef struct _VoltImageClass      VoltImageClass;
typedef struct _VoltImageDataInfo   VoltImageDataInfo;

/**
 * VoltImageError:
 * @VOLT_IMAGE_ERROR_INVALID_DATA: Invalid data passed to
 * the volt_image_set_data() function.
 *
 * Error enumeration for #VoltImage.
 *
 */
typedef enum
{
  VOLT_IMAGE_ERROR_INVALID_DATA
} VoltImageError;

/**
 * VoltImage:
 *
 * The <structname>VoltImage</structname> structure contains
 * private data and should only be accessed using the provided
 * API.
 *
 * Since: 1.10
 */
struct _VoltImage
{
  /*< private >*/
  GObject parent_instance;

  /* structure containing private members */
  /*<private>*/
  VoltImagePrivate *priv;
};


/**
 * VoltImageClass:
 *
 * The <structname>VoltImageClass</structname> structure contains
 * private data.
 *
 * Since: 1.10
 */
struct _VoltImageClass
{
  /*< private >*/
  GObjectClass parent_class;

  gpointer _padding[16];
};

struct _VoltImageDataInfo
{
  GBytes      *bytes;
  CoglPixelFormat   pixel_format;
  guint             width;
  guint             height;
  guint       row_stride;
  CoglTextureFlags  flags;
};

GQuark volt_image_error_quark (void);

GType volt_image_get_type (void) G_GNUC_CONST;

ClutterContent*        volt_image_new               (void);

GdkPixbufAnimation*   volt_image_get_pixbuf_anim(VoltImage *self);
void volt_image_set_pixbuf_anim(VoltImage *self, GdkPixbufAnimation* pixbufAnim);

gboolean 				volt_image_set_pixbuf_data ( VoltImage     		*image,
													 GdkPixbuf    *pixbufdata,
													 CoglTextureFlags  flags,
													 CoglPixelFormat   pixel_format,
													 guint             width,
													 guint             height,
													 guint             row_stride,
													 GError          **error );


gboolean                volt_image_set_data          (VoltImage                 *image,
    const guint8                 *data,
    CoglTextureFlags              flags,
    CoglPixelFormat               pixel_format,
    guint                         width,
    guint                         height,
    guint                         row_stride,
    GError                      **error);
gboolean                volt_image_set_area          (VoltImage                 *image,
    const guint8                 *data,
    CoglTextureFlags              flags,
    CoglPixelFormat               pixel_format,
    const cairo_rectangle_int_t  *rect,
    guint                         row_stride,
    GError                      **error);
gboolean                volt_image_set_bytes         (VoltImage                 *image,
    GBytes                       *data,
    CoglTextureFlags              flags,
    CoglPixelFormat               pixel_format,
    guint                         width,
    guint                         height,
    guint                         row_stride,
    GError                      **error);

void                    volt_image_set_texture_share       (VoltImage                 *image,
    VoltImage                 **texture_source,
    gboolean                      is_owner);

CoglTexture *           volt_image_get_texture       (VoltImage                 *image);

void                    volt_image_set_texture       (VoltImage                 *image,
    CoglTexture               *texture);

void                    volt_image_set_subtexture_rectangle  (VoltImage                 *image,
    float                      x1,
    float                      y1,
    float                      x2,
    float                      y2 );

void
                        volt_image_get_image_data(VoltImage *self, 
                                                  VoltImageDataInfo* info);

G_END_DECLS

#endif // VOLTIMAGE_H
