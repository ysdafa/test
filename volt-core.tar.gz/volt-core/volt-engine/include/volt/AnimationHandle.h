#ifndef __ANIMATION_HANLDE_H_INCL__
#define __ANIMATION_HANDLE_H_INCL__

#include <clutter/clutter.h>
#include <vector>
#include <unordered_set>
#include "Widget.h"

namespace volt
{
namespace graphics
{

typedef std::function<void()> AnimationCallback;

/** Interface for a class with which one can register for
 *  animation callbacks */
class IAnimationCallbacks
{
  public:
    virtual void addKeyCallback(double checkpoint, AnimationCallback callback) = 0;
    virtual void addCompletionCallback(AnimationCallback callback) = 0;
};

class AnimationHandle : IAnimationCallbacks
{

    std::vector<ClutterTimeline*> transitions;
    std::set<AnimatableProperty> props;

    std::vector<AnimationCallback> completionCallbacks;
    std::map<std::string, AnimationCallback> keyCallbacks;

    Widget* host;
    bool paused, isLive, isReferenced, isInCallbacks;
    float duration, repeat;

    virtual ~AnimationHandle() {} //AnimationHandles manage their own destruction

    /*Apply transformation to every transition in the transitions collection*/
    void forEachTransition( void (*transformation)(ClutterTimeline*) );

    /*Apply transformation which takes a gunit as a parameter to every transition in the transitions collection*/
    void forEachTransition( void (*transformation)(ClutterTimeline*, guint), double param );

    /*Clean up resources and delete animation if destruction conditions are met */
    void selfDestructIfAble();

    bool isActive() const;

    /*Stop and dereference a timeline*/
    static void cancelTransition(ClutterTimeline*);

    /*GCallback to any registered callbacks when an clutter progress marker is reached*/
    static void onMarkerReached(ClutterTimeline* timeline, gchar* markerName, gint msecs, gpointer callbackPtr);

    /*GCallback to destroy timeline when its finished*/
    static void onGuidelineFinished(ClutterTimeline* timeline, gboolean isFinished, gpointer callbackPtr);

  public:

    AnimationHandle(Widget* widget, float duration, float repeat, std::set<AnimatableProperty> properties);

    /**  Signals that there are no external references to
     *   AnimationHandle. It will be destroyed when possible. */
    void release();

    /** Add a transition to the animation. */
    void addTransition(ClutterTransition* transition, AnimatableProperty property, const char* name);

    /** Add a callback function which will be invoked upon
     *  completion of the animation (including all repeats). */
    void addCompletionCallback(AnimationCallback callback);

    /** Add a callback function which will be invoked upon
     *  reaching a certain percentage of the animation. Will be
     *  invoked multiple times if the animation repeats */
    void addKeyCallback(double checkpoint, AnimationCallback callback);

    /** Immediately stop and clean up the animation. */
    void cancel();

    /** Puase the animation. It can be resumed from the same
     *  frame using resume. */
    void pause();

    /** Resume the animation if it had been paused. Otherwise a
     *  no-op. */
    void resume();

    /** Jump to the given point in the animation (duration *
     *  progress seconds since the start of the animation) */
    void jump(double progress);

    /** Jump ahead a given percentage of the animation */
    void skip(double progress);

    /** Returns true if the animation is currently paused. */
    bool isPaused() const
    {
      return paused;
    }

    double getProgress() const;

    int getCurrentRepeat() const;

    bool hasProperty(AnimatableProperty) const;


    //TODO: Checkpoints
};
};
};

#endif
