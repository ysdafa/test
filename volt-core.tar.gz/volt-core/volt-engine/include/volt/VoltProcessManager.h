#ifndef VOLT_PROCESS_MANAGER_H
#define VOLT_PROCESS_MANAGER_H

#include <map>

#include "VoltEngine.h"

#include "logger.h"

/**
 * Interface for Volt process runtime.
 * Each Volt process must have its own runtime with this interface.
 */
class IVoltProcessRuntime
{
  public:
    /**
     * Initialize this runtime.
     * This method should initialize everything need to run this runtime.
     *
     * @param[in] aArgc # of arguments.
     * @param[in] aArgv Array of arguments.
     * @param[in] aData Extra data used to initialize Volt engine.
     * @param[in] aCallbacks EventCallbacks struct containing the callbacks to
     *                       be registered.
     *
     * @return true on success, false otherwise.
     */
    virtual bool Initialize(int aArgc, char **aArgv,
                            const VoltEngine::ExternalData &aData) = 0;

    /**
     * Start the main loop of this runtime.
     * This function does not return until the runtime terminates.
     *
     * @return true on success, false otherwise.
     */
    virtual bool Main() = 0;

    /**
     * This function signals to stop the runtime main loop.
     */
    virtual void Quit() = 0;

    /**
     * Cleanup this runtime.
     */
    virtual void Cleanup() = 0;
};

class VoltProcessManager
{
  public:
    static volt::util::Logger LOGGER;

    static const uint8_t APP_PROCESS = 0x1,
                         ROOT_PROCESS = 0x1,
                         WORKER_PROCESS = 0x2,
                         GFX_PROCESS = 0x4,
                         FULL_PROCESS = 0x8;

  public:
    static VoltProcessManager& Instance();

    ~VoltProcessManager();

    /**
     * Initialize internal data strucutres.
     *
     * @return true on success, false otherwise.
     */
    bool Initialize();

    /**
     * Start a new Volt graphics process.
     *
     * @return true on success, false otherwise.
     */
    bool StartGfxProcess();

    std::string GetGfxProcessCmd() const;

    /**
     * Start a new Volt worker process.
     *
     * @param[in] aAppJS Path to the application JS.
     * @param[out] aID ID assigned to the new worker.
     *
     * @return true on success, false otherwise.
     */
    bool StartWorkerProcess(const std::string aAppJS, std::string &aID);

    void StopVoltProcess(const std::string aID,
                         const unsigned int aMaxWaitTime = 5000);

    void StopWorkerProcesses();

    std::string GetWorkerProcessCmd(const std::string aAppJS,
                                    const std::string aWorkerID) const;

    /**
     * Initialize the main application runtime.
     *
     * @param[in] aArgc # of arguments.
     * @param[in] aArgv Array of arguments.
     *
     * @return true on success, false otherwise.
     */
    bool InitAppMain(int aArgc, char **aArgv);

    /**
     * Initialize the graphics runtime.
     *
     * @param[in] aArgc # of arguments.
     * @param[in] aArgv Array of arguments.
     *
     * @return true on success, false otherwise.
     */
    bool InitGfxMain(int aArgc, char **aArgv);

    /**
     * Initialize the worker runtime.
     *
     * @param[in] aArgc # of arguments.
     * @param[in] aArgv Array of arguments.
     *
     * @return true on success, false otherwise.
     */
    bool InitWorkerMain(int aArgc, char **aArgv);


    /**
     * Initialize the full application runtime.
     *
     * @param[in] aArgc # of arguments.
     * @param[in] aArgv Array of arguments.
     * @param[in] aData Extra data used to initialize Volt engine.
     * @param[in] aCallbacks EventCallbacks struct containing the callbacks to
     *                       be registered.
     *
     * @return true on success, false otherwise.
     */
    bool InitFullMain(int aArgc, char **aArgv,
                      const VoltEngine::ExternalData &aData);


    /**
     * Initialize the full worker runtime.
     *
     * @param[in] aArgc # of arguments.
     * @param[in] aArgv Array of arguments.
     * @param[in] aData Extra data used to initialize Volt engine.
     * @param[in] aCallbacks EventCallbacks struct containing the callbacks to
     *                       be registered.
     *
     * @return true on success, false otherwise.
     */
    bool InitFullWorkerMain(int aArgc, char **aArgv,
                            const VoltEngine::ExternalData &aData);

    /**
     * Start the runtime that is currently initialized.
     * This function blocks until the Volt application terminates.
     *
     * @return true on success, false otherwise.
     */
    bool Run();

    /**
     * Cleanup internal data strucutres maintained by the runtime.
     */
    void Cleanup();

    /**
     * Return a bit mask indicating the type of the current Volt process.
     *
     * @return Bitwise-or of APP_PROCESS, WORKER_PROCESS, and/or GFX_PROCESS.
     */
    uint8_t ProcessType() const;

    /**
     * Get the runtime on this process.
     *
     * @return Shared pointer to the runtime on this process.
     */
    std::shared_ptr<IVoltProcessRuntime> Runtime() const;

    /**
     * Send a signal to the Volt process with the given ID.
     *
     * @param[in] aID ID of the target Volt process.
     * @param[in] aSigNum Signal to send.
     *
     * @return true on success, false otherwise.
     */
    bool SendSignal(const std::string &aID, const int aSigNum) const;

    /**
     * Check if the Volt process with the given ID is alive/running.
     *
     * @param[in] aID ID of the target Volt process.
     *
     * @return true if alive, false otherwise.
     */
    bool IsAlive(const std::string aID);

    /**
     * Wait for all the children processes to exit.
     * This function will block until every process exits.
     */
    void Wait();

  private:
    VoltProcessManager();

    void GetGfxProcessArgs(std::vector<char *> &aArgs) const;
    void GetWorkerProcessArgs(std::vector<char *> &aArgs,
                              const std::string aAppJS,
                              const std::string aWorkerID) const;

  private:
    std::map<std::string, pid_t> pids_;

    uint8_t process_type_;

    std::shared_ptr<IVoltProcessRuntime> runtime_;

    static unsigned int WORKER_ID;
};

#endif
