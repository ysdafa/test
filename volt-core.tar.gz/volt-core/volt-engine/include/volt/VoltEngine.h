#pragma once

#include <stdint.h>
#include <functional>
#include <vector>

#include "VoltEventArgs.h"
#include "event_const.h"

/* Forward Declarations */
namespace Bridge
{
class ScriptBridge;
}

namespace volt
{
namespace graphics
{
class SceneRoot;
}
}

namespace volt
{
namespace util
{
class IXWindowManager;
}
}

/**
 * Class to be used as a handle to manage Volt engine and apps running on it.
 */
class VoltEngine
{
  public:
    /** Bit-mask of different Volt process types. */
    static const uint8_t APP_PROCESS = 0x1,    /**< Main app process */
                         ROOT_PROCESS = 0x1,   /**< Root process */
                         WORKER_PROCESS = 0x2, /**< Worker process */
                         GFX_PROCESS = 0x4,    /**< Graphics process */
                         FULL_PROCESS = 0x8;   /**< Full (v8 & graphics) */

    /**
     * Structure containing a set of callbacks to be called on Volt events.
     */
    class EventHandlers
    {
      public:
        /** Callback to be executed just before loading the JS bridges. */
        std::function<void ()> onBeforeLoadingJsBridges;
        /** Callback to be executed just after loading the JS bridges. */
        std::function<void ()> onAfterLoadingJsBridges;
        /** Callback to be executed just before running the main JS. */
        std::function<void ()> onBeforeRunningScript;
        /** Callback to be executed just after running the main JS. */
        std::function<void ()> onAfterRunningScript;
        /** Callback to be executed when Volt is terminating. */
        std::function<void ()> onTerminate;

      public:
        EventHandlers():
          onBeforeLoadingJsBridges(), onAfterLoadingJsBridges(),
          onBeforeRunningScript(), onAfterRunningScript(),
          onTerminate()
        {}
    };

    typedef std::vector<Bridge::ScriptBridge *> BridgeList;

    class ExternalData
    {
      public:
        VoltEventArgsMap eventArgs;
        EventHandlers eventHandlers;
        BridgeList bridges;
        volt::util::IXWindowManager *windowManager;

      public:
        ExternalData(): eventArgs(), eventHandlers(), bridges(), windowManager(nullptr)
        {}
    };

  public:
    /**
     * Create a new instance of VoltEngine class.
     * @return New VoltEngine instance.
     */
    static VoltEngine* New();

    virtual ~VoltEngine() {}

    /**
     * Set the license file to be used to decrypt files.
     * This API MUST be callsed before ParseOptions as it may require
     * decrpytion to read/parse configuration files.
     *
     * @param[in] aPath Path to the license file.
     */
    virtual void SetDrmLicense(const std::string &aPath) = 0;

    /**
     * Parse command line options and configuration files supported by Volt
     * (eg config.json).
     *
     * @param[in] aArgc Argument count.
     * @param[in] aArgv Argument vector.
     *
     * @return true on success, false otherwise.
     */
    virtual bool ParseOptions(int aArgc, char **aArgv) = 0;

    /**
     * Initialize Volt engine with the given arguments.
     *
     * @param[in] aArgc Argument count.
     * @param[in] aArgv Argument vector.
     *
     * @return true on success, false otherwise.
     */
    virtual bool Initialize(int aArgc, char **aArgv)
    {
      static const ExternalData empty;
      return Initialize(aArgc, aArgv, empty);
    }

    /**
     * Initialize Volt engine with the given arguments and register the event
     * callbacks.
     *
     * @param[in] aArgc Argument count.
     * @param[in] aArgv Argument vector.
     * @param[in] aData Extra data used to initialize Volt engine.
     *
     * @return true on success, false otherwise.
     */
    virtual bool Initialize(int aArgc, char **aArgv,
                            const ExternalData &aData) = 0;

    /**
     * Start Volt engine.
     * This function does not return until Volt engine terminates.
     *
     * This function should NOT be called if a GMainLoop with the global
     * default GMainContext is started/managed by the caller.
     *
     * @param[in] aArgc Argument count.
     * @param[in] aArgv Argument vector.
     *
     * @return true on success, false otherwise.
     */
    virtual bool Run() = 0;

    /**
     * Clean up internal data maintained by Volt.
     */
    virtual void Cleanup() = 0;

    /**
     * Quit/terminate Volt engine.
     */
    virtual void Quit() = 0;

    /**
     * Flag indicating if an attempt should be made to the application that
     * was running before the Volt engine is run.
     *
     * @return true if an attempt should be made, false otherwise.
     */
    virtual bool ShouldReturnToPrevAppOnExit() = 0;

    /**
     * Get the root of the Volt scene graph (which is of type SceneRoot).
     * @return The SceneRoot object at the root of the scene graph.
     */
    virtual volt::graphics::SceneRoot* GetSceneRoot() const = 0;

    /**
     * Send an arbitrary event to the JS.
     * Care should be taken when defining a custom event to not to clash the
     * event ID with the IDs predefined by Volt.
     *
     * @param[in] aEventID ID of the event to send.
     * @param[in] aJsData Data to be given to the event handlers.
     */
    virtual void SendJsEvent(const unsigned int aEventID,
                             const VoltEventArgsMap &aJsData = VoltEventArgsMap()) = 0;

    /**
     * Show the application UI.
     * Calling this function will trigger the ON_RESUME event in the JS.
     *
     * @param[in] aArgs Data to be given to the ON_RESUME event handler.
     */
    virtual void ShowUI(const VoltEventArgsMap &aArgs = VoltEventArgsMap()) = 0;

    /**
     * Hide the application UI.
     * Calling this function will trigger the ON_PAUSE event in the JS.
     *
     * @param[in] aArgs Data to be given to the ON_PAUSE event handler.
     */
    virtual void HideUI(const VoltEventArgsMap &aArgs = VoltEventArgsMap()) = 0;

    /**
     * Check if the application UI is hidden.
     * @return true if hidden, false otherwise.
     */
    virtual bool UIHidden() const = 0;

    /**
     * Signal the running app to reset itself.
     * Calling this function will trigger the ON_RESET event in the JS.
     *
     * @param[in] aArgs Data to be given to the ON_RESET event handler.
     */
    virtual void ResetApp(const VoltEventArgsMap &aArgs = VoltEventArgsMap()) = 0;

    /**
     * Get the bitmask describing the Volt engine process type.
     * @return Process type bitmask.
     */
    virtual uint8_t ProcessType() const = 0;

    /**
     * Check if this is a main application process.
     * @return true if this is a main application process, false otherwise.
     */
    virtual bool IsAppProcess() const
    {
      return ProcessType() & APP_PROCESS;
    }

    /**
     * Check if this is a worker process.
     * @return true if this is a worker process, false otherwise.
     */
    virtual bool IsWorkerProcess() const
    {
      return ProcessType() & WORKER_PROCESS;
    }

    /**
     * Check if this is a graphics process.
     * @return true if this is a graphics process, false otherwise.
     */
    virtual bool IsGfxProcess() const
    {
      return ProcessType() & GFX_PROCESS;
    }

    /**
     * Check if this is a full process.
     * @return true if this is a full process, false otherwise.
     */
    virtual bool IsFullProcess() const
    {
      return ProcessType() & FULL_PROCESS;
    }

  protected:
    VoltEngine() {}
};
