/*
 * ListWidget.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef LISTWIDGET_H_
#define LISTWIDGET_H_

#include "Widget.h"
#include "LayoutWidget.h"


class ListWidget : public LayoutWidget
{

  public:
    ListWidget(float x, float y, float width, float height, Widget* parent, Vector2 aSpacing,
               LayoutOrientation aOrientation);
    virtual ~ListWidget() {}

    /** Get the spacing this layout enforces between its children */
    Vector2 getSpacing() const
    {
      return spacing;
    }

    /** Set the spacing this layout enforces between its children */
    void setSpacing(Vector2);

    bool getUniformSpacing() const
    {
      return true;
    }//clutter_flow_layout_get_homogeneous( CLUTTER_FLOW_LAYOUT(layout) ); }

    void setUniformSpacing(bool isUniform)
    {
      /*clutter_flow_layout_set_homogeneous( CLUTTER_FLOW_LAYOUT(layout), isUniform);*/
    }



    /** Get the orientation of this Layout, either horizontal or vertical */
    LayoutOrientation getOrientation() const
    {
      return orientation;
    }

    /** Sets the orientation of this Layout to either horizontal or vertical */
    virtual void setOrientation(LayoutOrientation);

    //Override this to fix problems with flow layout resizing itself
    //virtual int addChild(Widget* child, int index = -1);


  protected:
    virtual const std::string& getWidgetTypeString() const;

  private:
    Vector2 spacing;

};

#endif /* LISTWIDGET_H_ */
