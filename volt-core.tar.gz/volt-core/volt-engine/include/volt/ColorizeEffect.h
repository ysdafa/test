/*
 * ColorizeEffect.h
 *
 *  Created on: Aug 6, 2013
 *      Author: Jim DiNunzio
 */

#ifndef COLORIZEEFFECT_H
#define COLORIZEEFFECT_H

#include "Widget.h"
#include "Effect.h"

namespace volt
{
namespace graphics
{
class ColorizeEffect : public Effect
{
  public:
    static const char* TINT_TRANSITION_NAME;
    static const char* EFFECT_NAME;

    ColorizeEffect(const volt::graphics::Color& tint);
    virtual ~ColorizeEffect();

    void setTint(const volt::graphics::Color& tint);
    volt::graphics::Color getTint() const;

};
}
}
#endif // COLORIZEEFFECT_H
