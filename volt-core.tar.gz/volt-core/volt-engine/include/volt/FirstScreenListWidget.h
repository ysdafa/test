/*
 * FirstScreenListWidget.h
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#ifndef FIRSTSCREENLISTWIDGET_H_
#define FIRSTSCREENLISTWIDGET_H_

#include "Widget.h"
#include "logger.h"
#include "ScriptBridge.h"

// shuhao.yan
#include <map>
#include <gdk-pixbuf/gdk-pixbuf.h>
#include "ResourceLoader.h"
#include "VoltText.h"
#include <fontconfig/fontconfig.h>
#include <pango/pango.h>
// shuhao.yan


using namespace Bridge;

/*
 * Abstract Base class of all Widgets which impose positioning on their children
 */

namespace volt
{
namespace graphics
{

class FirstScreenListItem 
{
public:
	ClutterActor* container;
	ClutterActor* mainImage;
	ClutterActor* titleBox;
	ClutterActor* title1;
	ClutterActor* title2;
	ClutterActor* iconBox;
	ClutterActor* icon1;
	ClutterActor* icon2;
	ClutterActor* icon3;
	ClutterActor* icon4;
	ClutterActor* icon5;
	ClutterActor* border;
};

class FirstScreenCategory 
{
public:
	std::string id;
	ScriptObject jsInstance;

	ClutterActor* categoryWrapper;
	ClutterActor* categoryTitle;
	ClutterActor* listWrapper;
	ClutterActor* color;
	ClutterActor* liveParent1;
	ClutterActor* liveParent2;
	ClutterActor* liveParent3;
	ClutterActor* liveParent4;
	ClutterActor* post1;
	ClutterActor* post2;
	ClutterActor* post3;
	ClutterActor* post4;
	ClutterActor* post5;
	ClutterActor* post6;
	ClutterActor* post7;
	ClutterActor* post8;
	ClutterActor* border;
	
	ScriptFunction onExtendCallback;
	ScriptFunction onExtendEndCallback;
};

class FirstScreenContents
{
public:
	std::string id;
	ScriptObject jsInstance;

	ClutterActor* contentsWrapper;
	ClutterActor* dominant;
	ClutterActor* titleParent;
	ClutterActor* mainWrapper;
	ClutterActor* main;
	ClutterActor* overRay;
	ClutterActor* normalTitle;
	ClutterActor* focusTitle;
	ClutterActor* border;
	ClutterActor* iconParent1;
	ClutterActor* iconParent2;
	ClutterActor* subMain;
	ClutterActor* progressP;
	Color dominantColor;
	Color normalTitleColor;
	int index;
	std::string categoryType;
	bool skipTransition;
	bool haveOptions;
	
	ScriptFunction onClickCallback;
	ScriptFunction startTransitionCallback;
	ScriptFunction stopTransitionCallback;
    ScriptFunction focusOptionsCallback;
	ScriptFunction unfocusOptionsCallback;
	ScriptFunction enterOptionsCallback;
	ScriptFunction longPressCallback;
};


enum CATEGORY_INDEX
{
	CATEGORYWRAPPER_INDEX,
	CATEGORYTITLE_INDEX,
	CATEGORY_LISTWRAPPER_INDEX
};

enum CATEGORY_WRAPPER_INDEX
{
	LIVEPARENT1_INDEX,
	LIVEPARENT2_INDEX,
	LIVEPARENT3_INDEX,
	LIVEPARENT4_INDEX
};

enum CATEGORY_LIVE_INDEX
{
	POST1_INDEX,
	POST2_INDEX,
};


enum LISTWRAPPER_INDEX
{
	CONTENTSWRAPPER_INDEX = 0,
	DOMINANT_INDEX = 0,
	TITLEPARENT_INDEX,
	CONTENT_DIM_INDEX,
	CONTENT_PROGRESS_INDEX,
	CONTENT_OPTION_INDEX
};

enum DOMINANT_WRAPPER_INDEX
{
	MAIN_INDEX,
	SUBMAIN_INDEX,
	OVERRAY_INDEX,
	ICON1_INDEX,
	ICON2_INDEX
};

enum TITLEWRAPPER_INDEX
{
	NORMALTITLE_INDEX,
	FOCUSTITLE_INDEX	
};

enum PROGRESSWRAPPER_INDEX
{
	PROGRESS_C_INDEX,
	PROGRESS_N_INDEX	
};

enum LIVECONTENTS_INDEX
{
	LIVECONTENTS1_INDEX,
	LIVECONTENTS2_INDEX,
	LIVECONTENTS3_INDEX
};

// END shuhao.yan

class FirstScreenCategoryLiveControl;

class FirstScreenListWidget : public Widget
{
public:
	static FirstScreenListWidget* Instance();
	
	FirstScreenListWidget(Widget* parent, const ScriptArray& args);
    virtual ~FirstScreenListWidget() {}


	void redefineGlobalParams(float scene_height);
	void redefineGlobalParams(const ScriptObject& params);
	//void createCategory(FirstScreenCategory* Item, ClutterActor* parent);
	void createChild(FirstScreenCategory* Item);
	void createContents(FirstScreenContents* Item);
	
	void removeCategory(int categoryIndex);
	void removeCategoryById(std::string id);
	void removeContents(int categoryIndex, int contentsIndex);
	void removeContentsById(std::string id);
	
	void setFocus(int contentsIndex);
	void setFocusById(std::string id);
	bool focusOptions();
	void unfocusOptions();
	bool enterOptions();
	
	void animateOnEnter();
	
	void callExtendAnimation();
	void callExtendAnimationEx();
	
	void moveLeft(int type);
	void moveRight(int type);

	void enableMoveToBegin();
	void enableMoveToEnd();
	
	int returnCategory();
	int returnContents();
	void riseFirstScreen();
	
	void off_transition_noanimaition();
	void stop_transition();

	float getPositionX(std::string categoryType, int contentsIndex);
	float getPositionY(std::string categoryType, int contentsIndex);
	
	void changeIcon(std::string categoryType, int contentsIndex, int number, ClutterActor *newIconParent);
	
	void addSubMain(std::string categoryType, int contentsIndex, ClutterActor* subMain);
	void changeContentLive(std::string categoryType, std::string contentsType, int contentsIndex, int num, ClutterActor* contentLive);

	int getCategoryIndexByID(std::string categoryType);
	void setProgress(std::string categoryType, int contentsIndex, gfloat progress);
	
	void setExtendBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time);
	void setLiveImageBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2);
	void setHorizontalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2);
	void setVerticalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2);
	void setContentLiveBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2);
	void setTransitionBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time);
	
	void fallFirstScreen();

	void startAnimation();
	void stopAnimation();
	void updateDominantColor(std::string categoryType, int contentsIndex, Color dominantColor);
	int getLastMouseMovedTime();

	FirstScreenCategory* findCategory(std::string tag);
	FirstScreenContents* findContents(std::string tag);

	void setOnBackgroundClickListener(ScriptFunction callback);
	void setOnMoveFocuseListener(ScriptFunction callback);
	void setOnScrollLeftEndListener(ScriptFunction callback);
	void setOnScrollRightEndListener(ScriptFunction callback);

	void setContextMenuFocusListener(ScriptFunction callback);
	void setContextMenuUnfocusListener(ScriptFunction callback);
	void setContextMenuFeedbackListener(ScriptFunction callback);
		
	void objectDump();

	//////// shuhao.yan
	void rotateWgt_Y_axis(ClutterActor* actor);
	void reverseOSD(bool reverseFlag);
	void enlarge(std::string categoryFont, std::string contentsFont);
	void highContrast(bool highContrastFlag);
	void setNomalTextColor(std::string categoryType, int contentsIndex, Color textColor);
	bool popupContextMenu(int contextType);
	void hideContextMenu();
	void selectContextMenuItem();
	void setContextMenuFlag(bool set);
	void removeProgressAndDim(std::string categoryType, int contentsIndex);

	void setKeyPrevent(bool keyPreventFlag);
	
	void setFirstState();
	void returnAnimation();

	
	void setBarOpacityZero();
	void setBarOpacityMax();

	//begin junhui.wang
	void changeControler();
	void setDim(std::string categoryType, int contentsIndex, bool flag);
	//end junhui.wang

    /*add by lin89.zhang for scale while reach the end of Bar begin*/
    void scaleLeft();
    void recoverLeft();
    void scaleRight();
    void recoverRight();
    /*add by lin89.zhang for scale while reach the end of Bar end*/

public:
	ScriptFunction onItemSelectedListener;
	ScriptFunction onItemLongPressedListener;
	ScriptFunction onItemChangedListener;
	ScriptFunction onBackgroundClickListener;
	ScriptFunction onMoveFocuseListener;
	ScriptFunction onScrollLeftEndListener;
	ScriptFunction onScrollRightEndListener;
	ScriptFunction onContextMenuFeedbackListener;
	ScriptFunction onContextMenuFocusListener;
	ScriptFunction onContextMenuUnfocusListener;

	Widget *SCENEROOT;
};


/*
ContextMenu
void setActorContent(std::string url, ClutterActor* actor);
void riseContextMenu(gfloat cur_index, bool mouseFlag);
bool fallContextMenu();
bool setFocusContextMenu(int contextType);
bool contextMenuKeyHandler(int keycode);
int  enterOption();
[shuhao.yan]
*/
enum KEYCODE
{
	LEFT_KEY,
	RIGHT_KEY
};

class ContextMenu
{
private:

	ClutterActor* m_rootActor;
	
	ClutterActor* m_removeImg;
	ClutterActor* m_favouriteImg;
	ClutterActor* m_multilinkImg;

	ClutterActor* m_arrowUPImg;
	ClutterActor* m_mousearrowUPImg;
	ClutterActor* m_selectorImg;

	std::vector<ClutterTransition*> m_optionEnterTransitions;
	std::vector<ClutterTransition*> m_optionExitTransitions;

	std::vector<ClutterTransition*> m_mouseoptionEnterTransitions;
	std::vector<ClutterTransition*> m_mouseoptionExitTransitions;

	std::vector<ClutterTransition*> m_enterContextMenuTransitions;
	std::vector<ClutterTransition*> m_exitContextMenuTransitions;

	std::vector<ClutterTransition*> m_enterContextMenuNOMLSTransitions;
	std::vector<ClutterTransition*> m_exitContextMenuNOMLSTransitions;
	
	bool M_MLS_DISABLE;
	bool M_FOCUS_FLAG;
	bool M_RISE_FLAG;
	bool M_MOUSE_RISE;
	int m_focusIndex;
	int m_preContentIndex;

	gfloat m_middle_offset;
	gfloat m_item_space;
	gfloat m_nomls_beginX;
	gfloat m_mls_beginX;
public:
	static ContextMenu& Instance();
	static ClutterTransition* createTransition(const std::string property, int begineValue, int endValue, int duration);
	static void setTimeout(int id);
	static gboolean showSelectorImg(gpointer data);
	static gboolean checkContextMenuPopCondition();
	
	ContextMenu();
	~ContextMenu()
	{
	}

	void on_ContextMenu_button_press_event(gfloat mouse_x, gfloat mouse_y);
	void on_ContextMenu_button_release_event(gfloat mouse_x, gfloat mouse_y);
	void on_ContextMenu_motion_event(gfloat mouse_x, gfloat mouse_y);

	void setActorContent(std::string url, ClutterActor* actor);
	void riseContextMenu(gfloat cur_index, bool mouseFlag);
	void fallContextMenuBY_MOUSEMOVEOUT();
	bool fallContextMenu();

	bool setFocusContextMenu(int contextType);
	bool contextMenuKeyHandler(int keycode);
	int  enterOption();
	void showSelImg();
	ClutterActor* getRootActor();
};

/*
ProgressController
[shuhao.yan]
*/
enum PROGRESS_STATUS
{
	PROGRESS_START,
	PROGRESS_PORCESSING,
	PROGRESS_COMPLETE
};

class ProgressController
{
private:
	
	ClutterActor* m_parent;
	ClutterActor* m_dim;
	ClutterActor* m_progressP;
	ClutterActor* m_progressC;
	ClutterActor* m_progressN;

	gfloat m_progress;
	bool m_progressFlag;
	
public:

	ProgressController(ClutterActor* parent);

	ClutterActor* returnProgressRootActor();
	ClutterActor* getProgressP();
	ClutterActor* getProgressC();
	ClutterActor* getProgressN();
	bool   getProgressFlag();
	void   setProgress(gfloat value);
	void   setDim(bool flag);
	gfloat returnProgress();
	ClutterActor* returnParentActor();
	
	static void insertProgressController(ClutterActor* actor, ProgressController* progressCtlInc);
	static void updateDim(ClutterActor* actor, bool flag);
	static ProgressController* findProgressController(ClutterActor* actor);
	static void eraseProgressController(ClutterActor* actor);
	static void updateProgressFoveaStatus(ClutterActor* actor, gfloat transWidth, gfloat transHeight);
	static void updateProgress(ClutterActor* actor, gfloat value);
	static gfloat getProgressStatus(ClutterActor* actor);
};



static PangoFontDescription* defaultFontDescription = NULL;
static PangoFontDescription* defaultAppFontDescription = NULL;


/*
TextScroll
TextScroll(ClutterActor* parent, const ScriptObject arg)
void scrollStart()
void scrollStop()
ClutterActor* getOperatorActor()
etTextFont(std::string fontName)
[shuhao.yan]
*/
class TextScroll
{
private:
	ClutterActor* m_parent;
	ClutterActor* textActor;
	ClutterActor* layoutActor;
	ClutterActor* moveActor;

	float textWidth;
	float textHeight;
	float layoutWidth;
	float layoutHeight;

	std::string HorizontalAlign;
	std::string VerticalAlign;
	std::string m_fontName;
	std::string m_text;

	float diffX;
	float diffY;
	float layoutX;
	float layoutY;

	ClutterTransition* transitionScroll;

	bool scrollFlag;
	bool scrollVisible;
public:

	bool normalFLAG;
	
	static void insertNormalInc(ClutterActor* actor, TextScroll* normalTitleInc);
	static void insertFocusInc(ClutterActor* actor, TextScroll* focusTitleInc);
	static void removeInc(TextScroll* TitleInc, ClutterActor* removeactor);
	static TextScroll* findNormalInc(ClutterActor* normalTitle);
	static TextScroll* findFocusInc(ClutterActor* focusTitle);
	

	TextScroll(ClutterActor* parent, const ScriptObject arg);
	~TextScroll()
	{

	}

	ClutterActor* getOperatorActor();
	void setPosition(float posX, float posY);
	float getTextAbsoluteSize(const std::string param);
	void setLayoutSize(float width, float height, bool normalFlag);
	void setTextFont(std::string fontName);
	LayoutAlignment deserializeLayoutAlignment(std::string alignmentStr);
	
	void initTextLayout(ClutterActor* textActor, ClutterActor* layoutActor, 
										std::string HorizontalLayout, std::string VerticalLayout);
	Color ScriptToColor(const ScriptObject& val);	
	static std::string& canonicalizeFont(std::string &aFont);
	void scrollStart();

	void scrollStop();
	
};

class FirstScreenCategoryLiveControl
{
public:
	typedef enum
	{
		HISTORY_LIVE,
		FEATURED_LIVE
	}LiveType;
	
public:
	static FirstScreenCategoryLiveControl* GetInstance(void);
	static void DestroyInstance(void);
	static FirstScreenCategoryLiveControl* m_Instance;

	FirstScreenCategoryLiveControl();
    virtual ~FirstScreenCategoryLiveControl();

	void SetType(ClutterActor* parent);
	void SetOpacity(ClutterActor* parent, gfloat opacity);
	void SetScale(ClutterActor* parent, gfloat scaleX, gfloat scaleY);
	void SetReverse(void);
	
	void RefreshFrame(bool force = false);
	void EnableFeaturedLive(bool set);
	void EnableFeaturedLiveReal(bool set);

	//for history
	void SetHistoryParent(ClutterActor* parent);
	void AddHistoryLive(std::string url, int index, ClutterColor& color);
	void RemoveHistoryLive(int index);
	
	//for featured
	void SetFeaturedParent(ClutterActor* parent);
	void AddFeaturedLive(std::string url, int liveIndex, int postIndex, ClutterColor& color);
	void RemoveFeaturedLive(int liveIndex, int postIndex);

private:
	void LoadImage(std::string url, int id);
	static void onImageLoadedRouter(int recieverID, VoltImage* image, bool success);

public:
	LiveType m_eType;
	ClutterActor* m_HistoryParent;
	ClutterActor* m_FeaturedParent;
	int m_nHistoryIndex;
	bool m_bFeaturedLiveEnable;
	bool m_bFeaturedLiveEnableReal;
	ClutterActor* m_pHistoryLive[4];
	ClutterActor* m_pFeaturedLive[4];
	ClutterActor* m_pFeaturedLivePost[16];
	bool m_bHistoryLoad[4];
	bool m_bFeaturedLoad[16];
};


class FirstScreenADControl
{
public:
	static FirstScreenADControl* GetInstance(void);
	static void DestroyInstance(void);
	static FirstScreenADControl* m_Instance;

	FirstScreenADControl();
    virtual ~FirstScreenADControl();

	bool IsEnable(void){return m_bEnabel;};
	void AddADContent(std::string url);
	void RemoveADContent(void);

	void SetClickCallback(ScriptFunction cb);
	void InvokeClickCallback(gfloat x);
	void SetEnterCallback(ScriptFunction cb);
	void InvokeEnterCallback(void);
	
	void SetX(gfloat x);
	void SetWidth(gfloat w);
	void SetOpacity(gfloat opacity);

	void SetReverse(void);

private:
	void LoadImage(std::string url);
	static void onImageLoadedRouter(VoltImage* image, bool success);

public:
	bool m_bEnabel;
	bool m_bLoading;
	ClutterActor* m_pAdContainer;
	ClutterActor* m_pAdContent;

	ScriptFunction onClickCallback;
	ScriptFunction onEnterCallback;
};

}
}

#endif /* FIRSTSCREENLISTWIDGET_H_ */
