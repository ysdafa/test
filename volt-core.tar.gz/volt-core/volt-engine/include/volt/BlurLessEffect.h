#ifndef __BLUR_LESS_EFFECT_H__
#define __BLUR_LESS_EFFECT_H__

#include "Widget.h"
#include "Effect.h"

G_BEGIN_DECLS

#define TYPE_BLUR_LESS_EFFECT        (blur_less_effect_get_type ())
#define BLUR_LESS_EFFECT(obj)        (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_BLUR_LESS_EFFECT, BlurLessEffect))
#define IS_BLUR_LESS_EFFECT(obj)     (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_BLUR_LESS_EFFECT))

/**
 * BlurLessEffect:
 *
 * <structname>BlurLessEffect</structname> is an opaque structure
 * whose members cannot be accessed directly
 *
 * Since: 1.4
 */
typedef struct _BlurLessEffect       BlurLessEffect;
typedef struct _BlurLessEffectClass  BlurLessEffectClass;

GType blur_less_effect_get_type (void) G_GNUC_CONST;

ClutterEffect *blur_less_effect_new (void);

G_END_DECLS


class BlurLess : public Effect
{
  public:
    static const char* EFFECT_NAME;

    BlurLess();
    virtual ~BlurLess();
};


#endif /* __BLUR_LESS_EFFECT_H__ */

