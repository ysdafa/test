/* Do NOT change the following line.  It will be overwritten during cmake. */
#define VOLT_VERSION "1.11.0"
#define VOLT_VERSION_MAJOR 1
#define VOLT_VERSION_MINOR 11
#define VOLT_VERSION_PATCH 0
