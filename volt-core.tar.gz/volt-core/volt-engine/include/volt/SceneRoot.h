/*
 * SceneRoot.h
 *
 *  Created on: Jun 21, 2013
 *      Author: reza
 */

#ifndef SCENEROOT_H_
#define SCENEROOT_H_

#include <clutter/clutter.h>
#include <unordered_map>
#include <unordered_set>
#include "Widget.h"

namespace volt
{
namespace graphics
{

typedef void (*Tick)(GObject* object, gint msecs, gpointer data);
typedef gulong TickCallbackID;

/**
 * The root element in the scene graph. SceneRoot is a widget that occupies the entire screen, and additionally
 * has a few special functions that operate on the entire screen.
 */
class SceneRoot : public volt::graphics::Widget
{
    ClutterActor* stage;

    //Timeline to use for new-frame signals
    static ClutterTimeline* tickTimeline;
    static uint tickEventCount;
    static void onChildrenDepthsChanged(GObject* object, gint msecs, gpointer data);
    
  public:
    
    SceneRoot(ClutterActor* stage, int width = 0, int height = 0, double xScale = 1, double yScale = 1);

    virtual ~SceneRoot();

    /**Switch the projection mode to orthographic */
    void useOrthographicProjection();

    /* Override width and height. Can't call VoltActor features
     *  here */
    virtual float getWidth() const;
    virtual void setWidth(float width);

    virtual float getHeight() const;
    virtual void setHeight(float height);

    virtual Vector2 getScale() const; //Always report scale as 1, so getAbsolutePosition does not clash unexpectedly with --screen-size
    virtual void setScale() {} //Disallow setting scene root scale after construction
    virtual void setScale(double) {}

    /** Background color (rgba) */
    virtual Color getColor() const;
    virtual void setColor(const Color& color);

    /** @return nullptr -- The SceneRoot has no ancestors by definition */
    virtual Widget* getAncestor(std::string id)
    {
      return nullptr;
    }

    Widget* getKeyFocus() const;
    void setKeyFocus(Widget*);
    void clearKeyFocus();

    static TickCallbackID registerTick(Tick, void*);
    static void unregisterTick(TickCallbackID);
    
  protected:

    virtual const std::string& getWidgetTypeString() const;
    virtual void writeSceneGraphExtraJson(std::ostream &aOut, const std::string aIndent) const;
};

};
};
#endif /* SCENEROOT_H_ */
