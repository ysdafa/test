/*
 * ResourceLoader.h
 *
 *  Created on: May 8, 2013
 *      Author: reza
 */

#ifndef RESOURCELOADER_H_
#define RESOURCELOADER_H_

#include <string>
#include <clutter/clutter.h>
#include <gdk-pixbuf/gdk-pixbuf.h>

#include "ImageWidget.h"
#include "VoltImage.h"
#include "logger.h"
#include "IORequest.h"

typedef std::function<void(VoltImage*,  bool success)> ImageLoadedCallback;

/**
 * ResourceLoader is a static utility class to take a resource identifier(URI) and return the
 * resource. It is meant to abstract away resource location. For example, a URL on the web
 * and a file on the local file system should both constitute valid URIs.
 */
class ResourceLoader
{
  public:
    static std::string LOGGER_NAME;

  public:
    /**
     * Get a singleton instance of ResourceLoader.
     * @return ResourceLoader singleton.
     */
    static ResourceLoader& Instance();

    /**
     * Synchronously load an image from buffer.
     *
     * @param[in] widget Pointer to calling widget.
     * @param[in] buffer Data buffer holding the image data.
     * @param[in] length of data.
     * @return true if successfully added image to aActor, false otherwise.
     */
    bool LoadImage(volt::graphics::ImageWidget *widget,
                   const volt::util::DataBuffer::SharedPtr &buffer,
                   CoglTextureFlags textureFlags = COGL_TEXTURE_NO_ATLAS);

    /**
     * Load an image from a URI and set it to the given actor.
     * The URI may be either for a local file (with "file://" prefix) or a
     * remote host (with "http://" or "https://").
     *
     * For images on a remote host, request is sent asynchronously and the
     * image may not be set to the actor immediately after the function
     * returns.
     *
     * @param[in] aUri URI of the image.
     * @param[in] aUri URI of the image.
     * @return true if successfully added image to aActor, false otherwise.
     */
    bool LoadImage(ImageLoadedCallback aCallback, const std::string &aUri,
                   const bool aAsync = true, CoglTextureFlags flags = COGL_TEXTURE_NO_ATLAS);

    /**
     * Load a content of a file.
     * @param[in] aUri URI of the resource.
     * @param[out] aData The file content would be written to this object.
     * @return true if successful, false otherwise.
     */
    bool LoadString(const std::string &aUri, volt::util::DataBuffer::SharedPtr &aData);

  private:
    ResourceLoader();
    virtual ~ResourceLoader();

  private:
    /**
     * Callback to handle asynchronous image loading event.
     *
     * @param[in] aRequest Request object for originating request.
     * @param[in] aCallback Callback function that is called when loading is complete.
     * @param[in] aTextureFlags Texture creation flags
     */
    void OnAsyncImageEvent(Resource::IORequest::SharedPtr aRequest,
                           ImageLoadedCallback aCallback,
                           CoglTextureFlags aTextureFlags);

    /**
     * Create pixbuf animation from the data received in the response of an IO request.
     * @param[in] aResponse Response of an IO request.
     * @param[out] aInput To store the input data used to create pixbuf animation.
     * @return pixbuf data, NULL on failure.
     */
    GdkPixbufAnimation* CreatePixbufAnimFromIOResponse(Resource::IOResponse::SharedPtr aResponse,
        GInputStream **aInput);

    /**
     * Create pixbuf animation from raw buffer.
     * @param[in] buffer containing the image.
     * @param[out] aInput To store the input data used to create pixbuf animation.
     * @return pixbuf data, NULL on failure.
     */
    GdkPixbufAnimation* CreatePixbufAnimFromBuffer(const volt::util::DataBuffer::SharedPtr &buffer,
        GInputStream **aInput);

    /**
     * Create a new VoltImage object and execute ImageWidget callback.
     * @param[in] aData Data encapsulating information required to update
     *                  image.  This is actually a pointer to AsyncImageInfo.
     * @return FALSE.
     */
    static gboolean UpdateWidgetImageTask(gpointer aData);

    /**
     * Report failure to load image back to to the ImageWidget that
     * requested it.
     * @param[in] aData This is actually a pointer to an
     *                  ImageLoadedCallback.
     * @return FALSE.
     */
    static gboolean NotifyFailedWidgetImageTask(gpointer aData);

    /**
     * Delete function to clean data created for input stream.
     * @param[in] aArray Data to be deleted (char *).
     */
    static void DeleteCharArray(gpointer aArray);

    /**
     * Utility function to set the content of an actor to an image created
     * from the given pixbuf animation.
     *
     * @param[in] aCallback Callback for an ImageWidget object.
     * @param[in] aPixbufAnim Pixbuf animation with image data.
     * @param[in] uri URI of image
     * @param[in] textureFlags Flags to use when creating texture
     */
    static void UpdateWidgetImage(ImageLoadedCallback aCallback,
                                  GdkPixbufAnimation *aPixbufAnim,
                                  const std::string& uri,
                                  CoglTextureFlags textureFlags);

    static bool LoadVoltImage(GdkPixbufAnimation *aPixbufAnim,
                              CoglTextureFlags textureFlags, VoltImage **image);

    /** Data to give from the Network thread to Clutter main thread. */
    class AsyncImageInfo
    {
      public:
        AsyncImageInfo(Resource::IORequest::SharedPtr aRequest,
                       GdkPixbufAnimation *aPixbufAnim,
                       GInputStream *aInput,
                       ImageLoadedCallback aCallback,
                       CoglTextureFlags aTextureFlags):
          request(aRequest), pixbufAnim(aPixbufAnim), input(aInput), callback(aCallback),
          textureFlags(aTextureFlags)
        {
        }
        ~AsyncImageInfo()
        {
          g_input_stream_close(input, NULL, NULL);
          g_object_unref(input);
        }

        Resource::IORequest::SharedPtr request;
        GdkPixbufAnimation *pixbufAnim;
        GInputStream *input;
        ImageLoadedCallback callback;
        CoglTextureFlags textureFlags;
    };

  private:
    volt::util::Logger logger_; /**< Logger name. */
};

#endif /* RESOURCELOADER_H_ */
