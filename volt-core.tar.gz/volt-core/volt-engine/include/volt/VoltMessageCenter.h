#ifndef _VOLT_MESSAGE_CENTER_H_
#define _VOLT_MESSAGE_CENTER_H_

#include <glib.h>
#include <thread>
#include <atomic>
#include <mutex>
#include <condition_variable>

#include "IVoltMessageCenter.h"

#include "logger.h"

class VoltMessageCenter : public volt::util::ipc::MessageCenter,
  public IVoltMessageCenter
{
  public:
    static volt::util::Logger LOGGER;

  public:
    /**
     * Prepare the singleton instance.
     * This MUST be called before calling any other methods.
     */
    static void PrepareInstance();

    static VoltMessageCenter& Instance();

    /* From IVoltMessageCenter */
    virtual void Initialize();

    virtual bool InitializeOnApp();

    virtual bool InitializeOnWorker();

    virtual bool PrepareWorker(const std::string &aWorkerID);

    virtual bool InitializeOnGfx();

    virtual void WaitForGfxReady();

    virtual const std::string& ID() const;

    virtual const std::string& ProcessID() const;

    virtual const std::string& AppProcessID() const;

    virtual const std::string& GfxProcessID() const;

    virtual const std::string& ParentProcessID() const;

    virtual void RegisterHandlerOnProc(const std::string &aID,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler);
    virtual void RegisterHandlerOnProc(const std::string &aID,
                                       const volt::util::ipc::MessageGroup aGroup,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler);
    virtual void RegisterHandlerOnProc(const std::string &aID,
                                       const volt::util::ipc::MessageType aType,
                                       volt::util::ipc::MessageCenter::MessageHandler aHandler);

    virtual bool PostMsgToProc(const std::string &aID,
                               volt::util::ipc::MessageType aType)
    {
      return PostMsgToProc(aID, aType, NULL, 0);
    }
    virtual bool PostMsgToProc(const std::string &aID,
                               volt::util::ipc::MessageType aType,
                               void *aData, const size_t aSize);

    virtual bool ExecuteOnProc(const std::string &aID,
                               volt::util::ipc::MessageType aType,
                               volt::util::ipc::MessageCenter::ResultHandler aHandler)
    {
      return ExecuteOnProc(aID, aType, aHandler, NULL, 0);
    }
    virtual bool ExecuteOnProc(const std::string &aID,
                               volt::util::ipc::MessageType aType,
                               volt::util::ipc::MessageCenter::ResultHandler aHandler,
                               void *aData, const size_t aSize);

    virtual void StartMainLoop();
    virtual void StartMainLoopThread();
    virtual void StopMainLoop();
    virtual void JoinMainLoopThread();

    virtual void StartGfxMainLoop();

  protected:
    struct GfxMsgData
    {
      GfxMsgData():
        self(NULL), handler(), msg(NULL)
      {}

      GfxMsgData(MessageHandler aHandler, volt::util::ipc::Message *aMsg,
                 VoltMessageCenter *aSelf = NULL):
        self(aSelf), handler(aHandler), msg(aMsg)
      {}

      VoltMessageCenter *self;
      MessageHandler handler;
      volt::util::ipc::Message *msg;
    };

    static int FireUIMessageHandler(gpointer aData);

    virtual void CallMessageHandler(volt::util::ipc::MessageCenter::MessageHandler aHandler,
                                    volt::util::ipc::Message *aMsg);

  private:
    VoltMessageCenter();

  private:
    std::string mc_name_;

    unsigned int shm_queue_size_;

    std::string queue_name_;

    std::string parent_id_;

    static const std::string MCQ_GFX;
    static const std::string MCQ_APP;

#ifdef SAMPLE_IPC
    unsigned int num_msg_;
    unsigned int num_cmd_;
    unsigned int num_sched_;
    unsigned int num_dispatch_;
    volt::util::Stopwatch idle_sample_timer_;
    volt::util::Stopwatch idle_msg_handler_timer_;
    volt::util::Stopwatch idle_cmd_handler_timer_;

    volt::util::Stopwatch idle_lag_timer_;
#endif
};

#endif
