/*
 * Exception.h
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#ifndef SAMSUNG_KINGSCANYON_EXCEPTION_H
#define SAMSUNG_KINGSCANYON_EXCEPTION_H

#include <exception>
#include <stdexcept>

/* This is specific to V8...
 * Didn't want VoltException dependent on V8 so just making a utility macro to
 * set the JS layer error information (eg stacktrace). */
#define SET_JS_ERR_INFO(e,try_catch) \
  v8::String::Utf8Value exception(try_catch.Exception()); \
  e.set_js_msg(*exception); \
  v8::Handle<v8::Message> message = try_catch.Message(); \
  if (message.IsEmpty() == false) \
  { \
    v8::String::Utf8Value file_name(message->GetScriptResourceName()); \
    e.set_file_name(*file_name); \
    e.set_line_num(message->GetLineNumber()); \
    v8::String::Utf8Value source_line(message->GetSourceLine()); \
    e.set_column_num(message->GetStartColumn()); \
    v8::String::Utf8Value stack_trace(try_catch.StackTrace()); \
    e.set_stack_trace(*stack_trace); \
  }

class VoltException : public std::exception
{
  public:
    VoltException(const char *aMsg):
      std::exception(), msg_(aMsg ? aMsg : "")
    {
    }

    virtual ~VoltException() throw() {}

    virtual const char* what() const throw()
    {
      return msg_.c_str();
    }

    virtual const char* msg() const throw()
    {
      return msg_.c_str();
    }

  private:
    std::string msg_;
};

class VoltJsException : public VoltException
{
  public:
    VoltJsException(const char *aMsg):
      VoltException(aMsg),
      js_msg_(), file_name_(), line_num_(0), column_num_(0), stack_trace_()
    {
    }

    virtual ~VoltJsException() throw() {}

    const std::string& js_msg() const throw()
    {
      return js_msg_;
    }

    void set_js_msg(const char *aJsMsg) throw()
    {
      js_msg_ = aJsMsg ? aJsMsg : "";
    }

    const std::string& file_name() const throw()
    {
      return file_name_;
    }

    void set_file_name(const char *aFileName) throw()
    {
      file_name_ = aFileName ? aFileName : "";
    }

    int line_num() const throw()
    {
      return line_num_;
    }

    void set_line_num(const int aLineNum) throw()
    {
      line_num_ = aLineNum;
    }

    int column_num() const throw()
    {
      return column_num_;
    }

    void set_column_num(const int aColNum) throw()
    {
      column_num_ = aColNum;;
    }

    const std::string& stack_trace() const throw()
    {
      return stack_trace_;
    }

    void set_stack_trace(const char *aStackTrace) throw()
    {
      stack_trace_ = aStackTrace ? aStackTrace : "";
    }

    void CopyJsErr(const VoltJsException &aExecption) throw()
    {
      js_msg_ = aExecption.js_msg_;
      file_name_ = aExecption.file_name_;
      line_num_ = aExecption.line_num_;
      column_num_ = aExecption.column_num_;
      stack_trace_ = aExecption.stack_trace_;
    }

  private:
    std::string js_msg_;
    std::string file_name_;
    int line_num_;
    int column_num_;
    std::string stack_trace_;
};

class VoltJsInitException : public VoltJsException
{
  public:
    VoltJsInitException(const char *aMsg): VoltJsException(aMsg) {}
    virtual ~VoltJsInitException() throw() {}
};

class VoltScripObjectHandlingException :  public VoltJsException
{
  public:
    VoltScripObjectHandlingException(const char *aMsg): VoltJsException(aMsg) {}
    virtual ~VoltScripObjectHandlingException() throw() {}
};

class VoltJsRuntimeException : public VoltJsException
{
  public:
    VoltJsRuntimeException(const char *aMsg): VoltJsException(aMsg) {}
    virtual ~VoltJsRuntimeException() throw() {}
};

class VoltInvalidWidgetIDException : public VoltJsRuntimeException
{
  public:
    VoltInvalidWidgetIDException(): VoltJsRuntimeException("Attempted to use invalid Widget ID") {}
    VoltInvalidWidgetIDException(const char *aMsg): VoltJsRuntimeException( aMsg ) {}

    virtual ~VoltInvalidWidgetIDException() throw() {}
};

class VoltJsBadTypeException : public VoltJsRuntimeException
{
  public:
    VoltJsBadTypeException(): VoltJsRuntimeException("Bad Type") {}
    VoltJsBadTypeException(const char *aMsg): VoltJsRuntimeException( (std::string("Bad Type: ") + aMsg).c_str() ) {}

    virtual ~VoltJsBadTypeException() throw() {}
};

#endif /* SAMSUNG_KINGSCANYON_EXCEPTION_H */
