/*
 * BackfaceCullingEffect.h
 *
 *  Created on: August 11, 2014
 *      Author: jim dinunzio
 */

#ifndef BACKFACECULLINGEFFECT_H
#define BACKFACECULLINGEFFECT_H

#include <clutter/clutter.h>

#ifndef STAND_ALONE
#include "Widget.h"
#endif

GType backface_culling_effect_get_type (void);


#define TYPE_BACKFACE_CULLING_EFFECT (backface_culling_effect_get_type ())
#define BACKFACE_CULLING_EFFECT(obj) (G_TYPE_CHECK_INSTANCE_CAST ((obj), \
                                                           TYPE_BACKFACE_CULLING_EFFECT, \
                                                           CBackfaceCullingEffect))
#define IS_BACKFACE_CULLING_EFFECT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), \
                                                                      TYPE_BACKFACE_CULLING_EFFECT))
#define BACKFACE_CULLING_EFFECT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), \
                                                                   TYPE_BACKFACE_CULLING_EFFECT, \
                                                                   CBackfaceCullingEffectClass))
#define IS_BACKFACE_CULLING_EFFECT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), \
                                                                   TYPE_BACKFACE_CULLING_EFFECT))
#define BACKFACE_CULLING_EFFECT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), \
                                                                     TYPE_BACKFACE_CULLING_EFFECT, \
                                                                     CBackfaceCullingEffectClass))

typedef struct _CBackfaceCullingEffect        CBackfaceCullingEffect;
typedef struct _CBackfaceCullingEffectClass   CBackfaceCullingEffectClass;

ClutterEffect *backface_culling_effect_new ();

/* object */
struct _CBackfaceCullingEffect
{
  ClutterEffect          parent_instance;
  CBackfaceCullingEffect          *copy_effect;
};

/* class */
struct _CBackfaceCullingEffectClass
{
  ClutterEffectClass parent_class;
};


#ifndef STAND_ALONE
class BackfaceCullingEffect : public Effect
{

  public:
    BackfaceCullingEffect();
    virtual ~BackfaceCullingEffect();
};
#endif
#endif /* BACKFACECULLINGEFFECT_H */
