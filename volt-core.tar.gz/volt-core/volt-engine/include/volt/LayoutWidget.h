/*
 * LayoutWidget.h
 *
 *  Created on: Jul 23, 2013
 *      Author: reza
 */

#ifndef LAYOUTWIDGET_H_
#define LAYOUTWIDGET_H_

#include "Widget.h"

/*
 * Abstract Base class of all Widgets which impose positioning on their children
 */
using namespace volt::graphics;

class LayoutWidget: public Widget
{
  public:

    LayoutWidget( float x, float y, float width, float height, Widget* parent,
                  LayoutOrientation aOrientation = Horizontal)
      : Widget(x, y, width, height, parent), orientation(aOrientation), layout(nullptr) {}

    virtual ~LayoutWidget() {}

    /** Get the orientation of this Layout, either horizontal or vertical */
    LayoutOrientation getOrientation() const
    {
      return orientation;
    }

    /** Sets the orientation of this Layout to either horizontal or vertical */
    virtual void setOrientation(LayoutOrientation) = 0;


  protected:
    virtual const std::string& getWidgetTypeString() const
    {
      static const std::string type("LayoutWidget");
      return type;
    }

  protected:

    LayoutOrientation orientation;
    ClutterLayoutManager* layout;

};

#endif /* LAYOUTWIDGET_H_ */
