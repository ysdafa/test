#ifndef VOLT_RUNTIME_MESSAGES_H
#define VOLT_RUNTIME_MESSAGES_H

#include "MessageTypes.h"

DEFINE_MSG_GROUP_BEGIN(VoltRuntimeGroup);
ADD_MSG_GROUP(VoltRuntimeGroup, Signal, 200);
ADD_MSG_GROUP(VoltRuntimeGroup, Command, 201);
DEFINE_MSG_GROUP_END(VoltRuntimeGroup);

DEFINE_MSG_TYPE_BEGIN(VoltRuntimeMsg);

ADD_MSG_TYPE(VoltRuntimeMsg, GfxReady, VoltRuntimeGroup::Signal(), 1);
ADD_MSG_TYPE(VoltRuntimeMsg, KeyboardEvent, VoltRuntimeGroup::Signal(), 2);
ADD_MSG_TYPE(VoltRuntimeMsg, WorkerMessage, VoltRuntimeGroup::Signal(), 3);
ADD_MSG_TYPE(VoltRuntimeMsg, AsyncResourceComplete, VoltRuntimeGroup::Signal(), 4);
ADD_MSG_TYPE(VoltRuntimeMsg, FlickEvent, VoltRuntimeGroup::Signal(), 5);
ADD_MSG_TYPE(VoltRuntimeMsg, ShowUI, VoltRuntimeGroup::Signal(), 6);
ADD_MSG_TYPE(VoltRuntimeMsg, HideUI, VoltRuntimeGroup::Signal(), 7);
ADD_MSG_TYPE(VoltRuntimeMsg, AsyncSefExeComplete, VoltRuntimeGroup::Signal(), 8);
ADD_MSG_TYPE(VoltRuntimeMsg, SefOnEvent, VoltRuntimeGroup::Signal(), 9);
ADD_MSG_TYPE(VoltRuntimeMsg, OnException, VoltRuntimeGroup::Signal(), 10);

ADD_MSG_TYPE(VoltRuntimeMsg, Quit, VoltRuntimeGroup::Command(), 1);
ADD_MSG_TYPE(VoltRuntimeMsg, GetMainStage, VoltRuntimeGroup::Command(), 2);
ADD_MSG_TYPE(VoltRuntimeMsg, HandleTimer, VoltRuntimeGroup::Command(), 3);
ADD_MSG_TYPE(VoltRuntimeMsg, PauseGfx, VoltRuntimeGroup::Command(), 4);
ADD_MSG_TYPE(VoltRuntimeMsg, ResumeGfx, VoltRuntimeGroup::Command(), 5);
ADD_MSG_TYPE(VoltRuntimeMsg, WorkerCommand, VoltRuntimeGroup::Command(), 6);

DEFINE_MSG_TYPE_END(VoltRuntimeMsg);

namespace volt
{
namespace runtime
{
namespace msg
{

struct KeyboardEventData
{
  KeyboardEventData(const int aType = 0, const int aCode = 0):
    type(aType), code(aCode)
  {}

  int type;
  int code;
};

} /* namespace msg */
} /* namespace runtime */
} /* namespace volt */

#endif

