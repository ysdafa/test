/*
 * TizenService.h
 *
 *  Created on: July 1st, 2014
 *      Author: Joe Yee
 */

#ifndef SAMSUNG_KINGSCANYON_TIZENSERVICE_H_
#define SAMSUNG_KINGSCANYON_TIZENSERVICE_H_

#include "VoltConfig.h"

#include "logger.h"

#include <string>
#include <vector>
#include <map>

#include "macros.h"
#include "event_const.h"

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include <appfw/app_service.h>
#endif

class TizenService
{
  public:
    TizenService();

    virtual ~TizenService();

    int AddExtraData(std::string &key, std::string &value);

    int AddExtraData(std::string &key, std::vector<std::string> &values);

    int Launch(bool callback = false);

    void SetAppId(const std::string & id);

    std::string GetAppId() const;

    void SetServiceOperation(int operation);

    int GetServiceOperation() const;

    void SetUri(const std::string & aUri);

    std::string GetUri() const;

    void SetPackage(const std::string & aPackage);

    std::string GetPackage() const;

  protected:

    static volt::util::Logger LOGGER;

  private:
#if defined(BUILD_FOR_TV) && defined(TIZEN)
    service_h serviceHandle_;
#endif

    int serviceOperationId;

    // disable copy constructor
    TizenService(TizenService &rhs) : serviceOperationId(0){};

    // disable copy operator
    TizenService &operator=(TizenService &rhs){return *this;}
};

#endif /* SAMSUNG_KINGSCANYON_SERVICEAPP_H_ */
