#include "gtest/gtest.h"

#include "ResourceManager.h"
#include "NetworkIORequest.h"
#include "FileIORequest.h"
#include "CacheManager.h"

#include "logger.h"

#include <pthread.h>

#include "AppConfig.h"

using namespace Resource;

#define LOCAL_PATH_TO_DOG_JPG "/data/builds/volt/single/dog.jpg"

class RequestInfo
{
  public:
    std::string uri;
    IORequest::Method method;
    std::string data;
    std::string src;
    IORequest::OnCompleteCallback async_callback;

    long int status;
    IOResponse::Source source;
    std::string type;
    std::string expected_data;
    std::string file_path;

  public:
    RequestInfo():
      uri(), method(), data(), src(), async_callback(NULL),
      status(200), source(IOResponse::SOURCE_INVALID),
      type(), expected_data(), file_path()
    {
    }

    RequestInfo(const std::string aUri,
                const IORequest::Method aMethod,
                const std::string aData,
                const std::string aSrc,
                const IORequest::OnCompleteCallback aCallback,
                const IOResponse::Source aSource,
                const std::string aType,
                const std::string aExpectedData,
                const std::string aFilePath):
      uri(aUri), method(aMethod), data(aData), src(aSrc), async_callback(aCallback),
      status(200), source(aSource), type(aType), expected_data(aExpectedData),
      file_path(aFilePath)
    {
    }
};

/******************************************************************************
 * Information used to test resource requests.
 * Modify the values according to your environment!
 *****************************************************************************/

/* For testing HTTP GET requests. */
static RequestInfo s_http_get_info("http://105.64.202.141/yusuke/volt/panel/dog.jpg",
                                   IORequest::METHOD_GET,
                                   "", /* No data */
                                   "", /* No src */
                                   NULL, /* No callback */
                                   IOResponse::SOURCE_NETWORK,
                                   "image/jpeg",
                                   "", /* No expected data, just compare with source */
                                   LOCAL_PATH_TO_DOG_JPG);

/* For testing HTTP POST requests. */
static RequestInfo s_http_post_info("http://httpbin.org/post", //"http://posttestserver.com/post.php",
                                    IORequest::METHOD_POST,
                                    "key1=val1&key2=val2",
                                    "", /* No src */
                                    NULL, /* No callback */
                                    IOResponse::SOURCE_NETWORK,
                                    "text/plain;charset=utf-8",
                                    "Received these fields\nkey2 => val2\nkey1 => val1\n",
                                    "");

/* For testing file GET/read requests. */
static RequestInfo s_file_get_info("file://dog.jpg",
                                   IORequest::METHOD_GET,
                                   "", /* No data */
                                   "", /* No src */
                                   NULL, /* No callback */
                                   IOResponse::SOURCE_FILE,
                                   "", /* No type for file requests */
                                   "", /* No expected data, just compare with source */
                                   LOCAL_PATH_TO_DOG_JPG);

/* For testing file PUT/write requests. */
static RequestInfo s_file_put_info("file://put.txt",
                                   IORequest::METHOD_PUT,
                                   "This file is created by file://put.txt request",
                                   "", /* No src */
                                   NULL, /* No callback */
                                   IOResponse::SOURCE_FILE,
                                   "", /* No type for file requests */
                                   "", /* No expected data, just compare with source */
                                   "/data/builds/volt/single/put.txt");

/* Mutex/cond var to signal async events. */
static pthread_mutex_t s_async_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_async_done_cv = PTHREAD_COND_INITIALIZER;

/* For logging. */
static volt::util::Logger LOGGER("test.ResourceManager");

/* Util function to test request creation. */
static void test_request_factory(IORequest::SharedPtr &aRequest,
                                 const RequestInfo aRequestInfo)
{
  if (aRequestInfo.async_callback)
  {
    ASSERT_TRUE(aRequest =
                  ResourceManager::CreateRequest(aRequestInfo.uri,
                      aRequestInfo.async_callback));
  }
  else
  {
    ASSERT_TRUE(aRequest = ResourceManager::CreateRequest(aRequestInfo.uri));
  }

  aRequest->set_method(aRequestInfo.method);
  aRequest->set_data(aRequestInfo.data);
  aRequest->set_src(aRequestInfo.src);

  ASSERT_EQ(aRequest->method(), aRequestInfo.method);
  ASSERT_EQ(aRequest->uri(), aRequestInfo.uri);

  if (aRequestInfo.async_callback)
  {
    ASSERT_TRUE(aRequest->async());
  }
  else
  {
    ASSERT_FALSE(aRequest->async());
  }

  ASSERT_EQ(aRequest->data(), aRequestInfo.data);
  ASSERT_EQ(aRequest->src(), aRequestInfo.src);

  if (aRequestInfo.source == IOResponse::SOURCE_NETWORK)
  {
    ASSERT_TRUE(dynamic_cast<NetworkIORequest *>(aRequest.get()));
  }
  else if (aRequestInfo.source == IOResponse::SOURCE_FILE)
  {
    ASSERT_TRUE(dynamic_cast<FileIORequest *>(aRequest.get()));
  }
}

/* Util function to test request creation. */
static void test_request_factory(const RequestInfo aRequestInfo)
{
  IORequest::SharedPtr request;
  test_request_factory(request, aRequestInfo);
}

/* Util function to test/verify response. */
static void test_response(const RequestInfo aRequestInfo,
                          const IORequest::SharedPtr aRequest)
{
  ASSERT_TRUE(aRequest->response());

  EXPECT_EQ(aRequest->response()->uri(), aRequestInfo.uri);
  EXPECT_EQ(aRequest->response()->status(), aRequestInfo.status);
  EXPECT_EQ(aRequest->response()->source(), aRequestInfo.source);

  if (aRequestInfo.type.empty() == false)
  {
    EXPECT_EQ(aRequest->response()->type(), aRequestInfo.type);
  }

  std::string received_data = aRequestInfo.expected_data;

  if (received_data.empty())
  {
    FILE *file = fopen(aRequestInfo.file_path.c_str(), "rb");

    if (file)
    {
      char chunk[8192];
      size_t num_read = 0;

      while (true)
      {
        num_read = fread(chunk, 1, sizeof(chunk) / sizeof(chunk[0]), file);

        if (num_read > 0)
        {
          received_data.append(chunk, num_read);
        }

        if (feof(file))
        {
          break;
        }

        if (ferror(file))
        {
          LOG_ERROR(LOGGER, "Error reading: " << aRequestInfo.file_path);
          break;
        }
      }

      fclose(file);
    }
  }

  if (aRequest->response()->source() == IOResponse::SOURCE_FILE &&
      aRequest->method() == IORequest::METHOD_PUT)
  {
    /* No response expected. */
    EXPECT_EQ(aRequest->response()->data().size(), (size_t) 0);
    /* Check the written file. */
    EXPECT_EQ(received_data, aRequestInfo.data);
  }
  else
  {
    EXPECT_EQ(aRequest->response()->data().size(), received_data.size());
    EXPECT_EQ(aRequest->response()->data(), received_data);
  }
}

/* Util function to process request and verify result. */
static void test_request(const RequestInfo aRequestInfo)
{
  IORequest::SharedPtr request;
  test_request_factory(request, aRequestInfo);

  ASSERT_TRUE(ResourceManager::Instance().Process(request));

  if (aRequestInfo.async_callback)
  {
    return;
  }

  test_response(aRequestInfo, request);
}

/* Callback for async requests. */
static void async_callback(IORequest::SharedPtr aRequest,
                           const RequestInfo aRequestInfo)
{
  test_response(aRequestInfo, aRequest);

  /* Signal complete. */
  pthread_mutex_lock(&s_async_mutex);
  pthread_cond_signal(&s_async_done_cv);
  pthread_mutex_unlock(&s_async_mutex);
}

class TestResourceManager : public ::testing::Test
{
  public:
    virtual void SetUp()
    {
      /* Clean cached data. */
      CacheManager::Instance().Flush();
    }

    virtual void TearDown()
    {
      /* Clean cached data. */
      CacheManager::Instance().Flush();
    }

    RequestInfo info;
};

/* Testcase for creation of synchronous requests. */
TEST_F(TestResourceManager, SyncRequestFactory)
{
  info.uri = "http://www.samsung.com";
  info.source = IOResponse::SOURCE_NETWORK;

  info.method = IORequest::METHOD_GET;
  test_request_factory(info);

  info.method = IORequest::METHOD_DELETE;
  test_request_factory(info);

  info.method = IORequest::METHOD_PUT;
  info.data = "data";
  test_request_factory(info);

  info.method = IORequest::METHOD_POST;
  test_request_factory(info);


  info.uri = "file://test.txt";
  info.source = IOResponse::SOURCE_FILE;

  info.method = IORequest::METHOD_GET;
  test_request_factory(info);

  info.method = IORequest::METHOD_DELETE;
  test_request_factory(info);

  info.method = IORequest::METHOD_PUT;
  info.data = "data";
  test_request_factory(info);

  info.method = IORequest::METHOD_POST;
  test_request_factory(info);
}

/* Testcase for creation of asynchronous requests. */
TEST_F(TestResourceManager, AsyncRequestFactory)
{
  info.uri = "http://www.samsung.com";
  info.source = IOResponse::SOURCE_NETWORK;
  info.async_callback =
    std::bind(async_callback, std::placeholders::_1, info);

  info.method = IORequest::METHOD_GET;
  test_request_factory(info);

  info.method = IORequest::METHOD_DELETE;
  test_request_factory(info);

  info.method = IORequest::METHOD_PUT;
  info.data = "data";
  test_request_factory(info);

  info.method = IORequest::METHOD_POST;
  test_request_factory(info);


  info.uri = "file://test.txt";
  info.source = IOResponse::SOURCE_FILE;
  info.async_callback =
    std::bind(async_callback, std::placeholders::_1, info);

  info.method = IORequest::METHOD_GET;
  test_request_factory(info);

  info.method = IORequest::METHOD_DELETE;
  test_request_factory(info);

  info.method = IORequest::METHOD_PUT;
  info.data = "data";
  test_request_factory(info);

  info.method = IORequest::METHOD_POST;
  test_request_factory(info);
}

/* Testcase for sending synchronous HTTP GET request. */
TEST_F(TestResourceManager, SyncHttpGet)
{
  test_request(s_http_get_info);
}

/* Testcase for sending synchronous HTTP POST request. */
TEST_F(TestResourceManager, SyncHttpPost)
{
  s_http_post_info.async_callback = NULL;
  test_request(s_http_post_info);
}

/* Testcase for sending synchronous file GET request. */
TEST_F(TestResourceManager, SyncFileGet)
{
  AppConfig::Instance().UpdateAppRootPath("/data/builds/volt/single/");
  test_request(s_file_get_info);
}

/* Testcase for sending synchronous file PUT request. */
TEST_F(TestResourceManager, SyncFilePut)
{
  AppConfig::Instance().UpdateAppRootPath("/data/builds/volt/single/");
  test_request(s_file_put_info);
}

/* Testcase for sending asynchronous HTTP GET request. */
TEST_F(TestResourceManager, AsyncHttpGet)
{
  s_http_get_info.async_callback =
    std::bind(async_callback, std::placeholders::_1, s_http_get_info);
  test_request(s_http_get_info);

  pthread_mutex_lock(&s_async_mutex);
  pthread_cond_wait(&s_async_done_cv, &s_async_mutex);
  pthread_mutex_unlock(&s_async_mutex);
}
