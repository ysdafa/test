/*
 * CutoutEffect.cpp
 *
 *  Created on: July 3, 2013
 *      Author: jim dinunzio
 */

#include "CutoutEffect.h"

/* object */
struct _CCutoutEffect
{
  /* private */
  ClutterEffect          parent_instance;

  VoltActor* cutout_actor;

  CCutoutEffect *copy_effect;
};

/* class */
struct _CCutoutEffectClass
{
  ClutterEffectClass parent_class;
};


G_DEFINE_TYPE (CCutoutEffect, cutout_effect, CLUTTER_TYPE_EFFECT);


/* enumerates property identifiers for this class;
 * note that property identifiers should be non-zero integers,
 * so we add an unused PROP_0 to occupy the 0 position in the enum
 */
enum
{
  PROP_0,

  PROP_LAST
};

//static GParamSpec *obj_props[PROP_LAST];

static void
cutout_effect_paint (ClutterEffect *effect, ClutterEffectPaintFlags flags)
{
  ClutterActor* actor_to_be_cut = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (effect));

  CCutoutEffect* cutout_effect = CUTOUT_EFFECT(effect);
  // apply the cutout clipping area before drawing the rest of effects and the actor

  // Apply the stage modelview matrix because the cutout_effect coordinates are in stage
  // coordindate space so the cutout will match position and size with the widget it is set on.

  ClutterMatrix stageTransform;
  ClutterActor* stage = clutter_actor_get_stage(actor_to_be_cut);
  clutter_actor_get_transform(stage, &stageTransform);

  cogl_push_matrix();
  cogl_set_modelview_matrix(&stageTransform);

  // start clipping path
  cogl_path_new();

  // draw the actor footprint
  volt_actor_draw_path_footprint(cutout_effect->cutout_actor);

  // Add entire stage rectangle to the path.  The even/odd rule will cause the difference in area
  // between the entire stage rectangle and the cutout area to be the active clip region, thus
  // limiting drawing to everything except the cutout area.
  cogl_path_rectangle (0, 0,
                       clutter_actor_get_width(stage), clutter_actor_get_height(stage));

  // apply the clip from the current path
  cogl_clip_push_from_path();

  // pop the custom modelview matrix
  cogl_pop_matrix();

  clutter_actor_continue_paint(actor_to_be_cut);

  // pop the clip after drawing is done.
  cogl_clip_pop();
}

/* GObject implementation */
static void
cutout_effect_dispose (GObject *gobject)
{
  G_OBJECT_CLASS (cutout_effect_parent_class)->dispose (gobject);
}

static ClutterEffect* cutout_effect_clone_for_render_thread(ClutterEffect *aSrcEffect)
{
  CCutoutEffect *src = CUTOUT_EFFECT(aSrcEffect);
  if(src->copy_effect == NULL)
  {
    src->copy_effect = CUTOUT_EFFECT(cutout_effect_new());
  }

  if (src->cutout_actor)
  {
#if 0
    /* It'd be nice if we can just copy the pointer to the copy_actor of
     * cutout_actor to avoid deep copy... */
    src->copy_effect->cutout_actor = src->cutout_actor->copy_actor;
#else
    if (src->copy_effect->cutout_actor == NULL)
    {
      src->copy_effect->cutout_actor = VOLT_ACTOR(volt_actor_new());
    }

    volt_actor_copy_new(CLUTTER_ACTOR(src->cutout_actor),
                        CLUTTER_ACTOR(src->copy_effect->cutout_actor));
#endif
  }

  return CLUTTER_EFFECT(src->copy_effect);
}

static void
cutout_effect_init (CCutoutEffect *self)
{
  self->cutout_actor = NULL;
  self->copy_effect = NULL;
}

/* GObject class and instance init */
static void
cutout_effect_class_init (CCutoutEffectClass *klass)
{
  ClutterEffectClass *effect_class = CLUTTER_EFFECT_CLASS (klass);
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  effect_class->paint = cutout_effect_paint;
  gobject_class->dispose = cutout_effect_dispose;

  effect_class->clone_for_render_thread = cutout_effect_clone_for_render_thread;
}

void
cutout_effect_set_cutout_actor(CCutoutEffect* self, VoltActor* cutout_actor)
{
  g_return_if_fail (IS_CUTOUT_EFFECT(self));

  if (self->cutout_actor != cutout_actor)
  {
    self->cutout_actor = cutout_actor;
  }
}

void cutout_effect_get_cutout_actor(CCutoutEffect* self, VoltActor* cutout_actor)
{
  g_return_if_fail (IS_CUTOUT_EFFECT(self));
  cutout_actor = self->cutout_actor;
}

/**
 * cutout_effect_new:
 *
 * Creates a new #CCutoutEffect
 */
ClutterEffect *
cutout_effect_new ()
{
  return (ClutterEffect*)g_object_new (TYPE_CUTOUT_EFFECT, NULL);
}

#ifndef STAND_ALONE
/* CutoutEffect Implementation */

CutoutEffect::CutoutEffect(VoltActor* cutoutActor)
{
  CCutoutEffect* cutoutEffect = CUTOUT_EFFECT(cutout_effect_new());
  cutout_effect_set_cutout_actor(cutoutEffect, cutoutActor);
  setEffect(CLUTTER_EFFECT(cutoutEffect));
}

CutoutEffect::~CutoutEffect()
{
}

#endif // STAND_ALONE
