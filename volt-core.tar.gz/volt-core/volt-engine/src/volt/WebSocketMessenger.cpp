#include <WebSocketMessenger.h>

static int ScoketCallback(struct libwebsocket_context *context, struct libwebsocket *wsi, enum libwebsocket_callback_reasons reason, void *user, void *in, size_t len){
	WebSocketMessenger* messenger = MessengerMap::getInstance().getMessenger(context);

	if (reason == LWS_CALLBACK_CLIENT_ESTABLISHED && messenger != NULL){
		messenger->onOpen();
		libwebsocket_callback_on_writable(context, wsi);
	}
	else if (reason == LWS_CALLBACK_CLIENT_WRITEABLE && messenger != NULL){
		unsigned char* message = messenger->getMessage();
		if (message != NULL){
			libwebsocket_write(wsi, message, std::strlen((char*)message), LWS_WRITE_TEXT);
			delete []message;
		}
		libwebsocket_callback_on_writable(context, wsi);
	}
	else if (reason == LWS_CALLBACK_CLIENT_RECEIVE && messenger != NULL){
		((char *)in)[len] = '\0';
		messenger->onMessage((char *)in);
	}
	else if (reason == LWS_CALLBACK_CLIENT_CONNECTION_ERROR){
		if (messenger != NULL){
			messenger->onError();
			messenger->onClose();
			messenger->setIsRun(false);
		}
		return -1;
	}
	else if (reason == LWS_CALLBACK_CLOSED || reason == LWS_CALLBACK_DEL_POLL_FD || reason == LWS_CALLBACK_PROTOCOL_DESTROY){
		if (messenger != NULL){
			messenger->setIsRun(false);
		}
		return -1;
	}
	return 0;
};

#ifdef _WIN32 || _WIN64
unsigned int WINAPI ThreadFunction(void *data)
#elif defined __linux__
void ThreadFunction(void *data)
#endif
{
	libwebsocket_context *context = ((libwebsocket_context*)data);
	WebSocketMessenger* messenger = MessengerMap::getInstance().getMessenger(context);

	if (messenger != NULL) {
		while (libwebsocket_service(context, 500) != -1 || messenger->isRun()); //is there a better way then the busy wait here? eg libEvent? (check ResouceManager.cpp)
	}
#ifdef _WIN32 || _WIN64
	return 0;
#endif
}

////////////////// class WebSocketMessenger
WebSocketMessenger::WebSocketMessenger(){}
WebSocketMessenger::~WebSocketMessenger(){
	destroyService();
}
WebSocketMessenger::WebSocketMessenger(std::string address){
	init(address, "");
}
WebSocketMessenger::WebSocketMessenger(std::string address, std::string protocolName){
	init(address, protocolName);
}
void WebSocketMessenger::init(std::string address, std::string protocolName){
	this->protocolName = new char[protocolName.length() + 1];
	std::copy(protocolName.begin(), protocolName.end(), this->protocolName);
	this->protocolName[protocolName.length()] = '\0';

	protocols[0].name = this->protocolName;
	protocols[0].callback = ScoketCallback;
	protocols[0].per_session_data_size = 0;
	protocols[0].rx_buffer_size = 20;

	protocols[1].name = NULL;
	protocols[1].callback = NULL;
	protocols[1].per_session_data_size = 0;
	protocols[1].rx_buffer_size = 0;


	if (address.find("ws://") == 0){
		address = address.substr(5, address.length());
		ssl = 0;
	}
	else if (address.find("wss://") == 0){
		address = address.substr(6, address.length());
		ssl = 1;
	}
	else{
		address = address.substr(0, address.length());
		ssl = 0;
	}

	if (address.find(":") != -1){
		this->port = std::atoi((address.substr(address.find(":") + 1, address.length()).c_str()));
		address = address.substr(0, address.find(":"));
	}
	else{
		if (ssl == 0){
			port = 80;
		}
		else{
			port = 443;
		}
	}

	this->address = new char[address.length() + 1];
	std::copy(address.begin(), address.end(), this->address);
	this->address[address.length()] = '\0';
	this->protocolName[protocolName.length()] = '\0';


	std::memset(&info, 0, sizeof(info));
	info.port = CONTEXT_PORT_NO_LISTEN;
	info.protocols = protocols;
	info.extensions = libwebsocket_get_internal_extensions();
	info.gid = -1;
	info.uid = -1;
	info.options = 0;

	context = libwebsocket_create_context(&info);
	if (context == NULL) {
		throw std::exception();//std::exception OR seperate init from constructor and return error code
	}
}
void WebSocketMessenger::connect(){
	wsi_dumb = libwebsocket_client_connect(context,
		address,
		port, // port
		ssl, // "ws:" (no SSL)
		"/", // path
		address, // host name
		"websocket", // Socket origin name
		protocolName, // libwebsocket protocol name
		-1
		);

}
void WebSocketMessenger::startService(){
	this->connect();
	void *arg = context;
	MessengerMap::getInstance().insertMessenger(context, this);
	//insertMessenger(context, this);
	setIsRun(true);
#ifdef _WIN32 || _WIN64
	hThread = NULL;
	DWORD dwThreadID = NULL;
	hThread = (HANDLE)_beginthreadex(NULL, 0, ThreadFunction, arg, 0, (unsigned*)&dwThreadID);
#elif defined __linux__
	serviceThread = std::thread(ThreadFunction, arg);
#endif
}
void WebSocketMessenger::destroyService(){
	if (context != NULL) libwebsocket_context_destroy(context);
	MessengerMap::getInstance().eraseMessenger(context, this);

	if (context != NULL)			delete context;
	if (address != NULL)			delete address;
	if (protocolName != NULL)	delete protocolName;
	if (wsi_dumb != NULL)		delete wsi_dumb;


	onClose();
}
void WebSocketMessenger::send(std::string message){
	lock();
	messageQueue.push(message);
	unLock();
}


void WebSocketMessenger::onOpen(){
	if (onOpenCallback != NULL){
		onOpenCallback();
	}
}

void WebSocketMessenger::onMessage(std::string data){
	if (onMessageCallback != NULL){
		onMessageCallback(data);
	}
}


void WebSocketMessenger::onError(){
	if (onErrorCallback != NULL){
		onErrorCallback();
	}
}

void WebSocketMessenger::onClose(){
	if (onCloseCallback != NULL){
		onCloseCallback();
	}
}

bool WebSocketMessenger::isRun() const{
	return this->run;
}
void WebSocketMessenger::setIsRun(bool isRun){
	this->run = isRun;
}

unsigned char* WebSocketMessenger::getMessage(){
	lock();
	if (messageQueue.empty() == false){
		unsigned char* message = new unsigned char[messageQueue.front().size() + 1]();
		std::copy(messageQueue.front().begin(), messageQueue.front().end(), message);
		messageQueue.pop();
		unLock();
		return message;
	}
	unLock();
	return NULL;
}


////////////////// class MessengerMap
MessengerMap &MessengerMap::getInstance(){
	static MessengerMap messengerMap;
	return messengerMap;
}
WebSocketMessenger* MessengerMap::getMessenger(libwebsocket_context* context){
	lock();
	WebSocketMessenger* messenger = NULL;
	std::map<int, WebSocketMessenger*>::iterator itor = map.find((int)context);
	if (itor != map.end()){
		messenger = itor->second;
	}
	unLock();
	return messenger;
}
void MessengerMap::insertMessenger(libwebsocket_context* context, WebSocketMessenger* messenger){
	lock();
	map.insert(std::pair<int, WebSocketMessenger*>((int)context, messenger));
	unLock();
}
void MessengerMap::eraseMessenger(libwebsocket_context* context, WebSocketMessenger* messenger){
	lock();
	std::map<int, WebSocketMessenger*>::iterator messengerItor = map.find((int)context);
	if (messengerItor != map.end()){
		map.erase(messengerItor);
	}
	unLock();
}


//////////////////// class Lock
void Lock::lock() {
#ifdef __linux__
	threadMutex.lock();
#endif
}

void Lock::unLock() {
#ifdef __linux__
	threadMutex.unlock();
#endif
}
