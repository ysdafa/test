#include "VoltWorker.h"

#include <sys/types.h>
#include <sys/wait.h>

#include "VoltProcessManager.h"
#include "VoltFullProcessRuntime.h"
#include "VoltMessageCenter.h"
#include "VoltRuntimeMessages.h"
#include "AppConfig.h"
#include "TaskDispatcher.h"
#include "DirIORequest.h"
#include "FileIORequest.h"
#include "logger.h"

using namespace volt::util;
using namespace volt::util::ipc;
using namespace volt::runtime::msg;

static volt::util::Logger LOGGER("volt.worker");

unsigned int VoltWorker::WORKER_ID = 0;

VoltWorker::VoltWorker():
  worker_id_(), on_message_(), on_command_(), on_exception_()
{
  LOG_DEBUG(LOGGER, "Born (" << this << ")");
}

VoltWorker::~VoltWorker()
{
  LOG_DEBUG(LOGGER, "Dead (" << this << ")");

  VoltProcessManager::Instance().StopVoltProcess(worker_id_);
}

const std::string& VoltWorker::ID() const
{
  return worker_id_;
}

void VoltWorker::RegisterOnMessageCallback(OnMessageCallback aCallback)
{
  on_message_ = aCallback;
}

void VoltWorker::RegisterOnCommandCallback(OnCommandCallback aCallback)
{
  on_command_ = aCallback;
}

void VoltWorker::RegisterOnErrorCallback(OnErrorCallback aCallback)
{
  on_exception_ = aCallback;
}

bool VoltWorker::Run(const std::string &aUri)
{
  LOG_DEBUG(LOGGER, "Running " << aUri);

  std::string js_path;
  unsigned char permission = Resource::FileIORequest::NormalizePath(aUri, js_path);

  if ((permission & Resource::PERM_R) == 0)
  {
    /* Not allowed */
    LOG_WARN(LOGGER, "Failed to run worker: " << aUri);
    return false;
  }

  if (VoltProcessManager::Instance().StartWorkerProcess(js_path, worker_id_) == false)
  {
    LOG_FATAL(LOGGER, "Failed to fork worker process");
    return false;
  }

  return true;
}

bool VoltWorker::IsRunning() const
{
  return VoltProcessManager::Instance().IsAlive(worker_id_);
}

void VoltWorker::Terminate(const double aMaxWaitTime)
{
  VoltProcessManager::Instance().StopVoltProcess(worker_id_, aMaxWaitTime);
}

bool VoltWorker::PostMessage(const std::string &aMsg)
{
  if (IsRunning() == false)
  {
    return false;
  }

  LOG_DEBUG(LOGGER, "Post message: " << aMsg);
  VoltMessageCenter::Instance().PostMsgToWorker(worker_id_,
      VoltRuntimeMsg::WorkerMessage(),
      const_cast<char *>(aMsg.c_str()), aMsg.length() + 1);
  return true;
}

bool VoltWorker::ExecCommand(const std::string &aCmd, std::vector<std::string> &aResults)
{
  if (IsRunning() == false)
  {
    return false;
  }

  LOG_DEBUG(LOGGER, "Exec command: " << aCmd);
  VoltMessageCenter::Instance().ExecuteOnWorker(worker_id_,
      VoltRuntimeMsg::WorkerCommand(),
      [&] (void *aData, const size_t aSize)
  {
    /* The result data MUST be
     * of type vector<string> */
    Unserialize(aResults,
                static_cast<char *>(aData),
                aSize);
  },
  const_cast<char *>(aCmd.c_str()), aCmd.length() + 1);

  /* The last element of the vector is a flag for execution result.
   *   "0" == success, "1" == failure */
  if (aResults.size() > 0 && aResults[aResults.size() - 1] == "0")
  {
    aResults.erase(aResults.end() - 1);
    return true;
  }
  else
  {
    aResults.erase(aResults.end() - 1);
    return false;
  }
}

void VoltWorker::OnMessage(const std::string &aMsg)
{
  LOG_DEBUG(LOGGER, "Got message: " << aMsg);

  if (on_message_)
  {
    on_message_(aMsg);
  }
}

bool VoltWorker::OnCommand(const std::string &aCmd, std::string &aResult)
{
  LOG_DEBUG(LOGGER, "Got command: " << aCmd);

  if (on_command_)
  {
    on_command_(aCmd, aResult);
    return true;
  }
  else
  {
    LOG_DEBUG(LOGGER, "Command handler not found: " << aCmd);
    return false;
  }
}

void VoltWorker::OnError(const std::string &aMsg)
{
  LOG_DEBUG(LOGGER, "Got exception: " << aMsg);

  if (on_exception_)
  {
    on_exception_(aMsg);
  }
}
