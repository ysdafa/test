/*
 * ImageWidget.cpp
 *
 *  Created on: May 23, 2013
 *      Author: reza, jim.dinunzio
 */

#include "ImageWidget.h"
#include "VoltConfig.h"
#include "Image.h"
#include "ResourceLoader.h"
#include "VoltActor.h"
#include <vector>
#include <cmath> 

#include "VoltConfig.h"
#ifdef USE_NEON_OPT
#include "arm_neon.h"
#endif

using namespace volt::graphics;
using namespace volt::util;

std::map<std::string, int> ImageWidget::colorPickOptions{	
	{"defaultRed",61},
	{"defaultGreen",77},
	{"defaultBlue",92},
	{"minRange",0},
	{"maxRange",210},
	{"greyscaleValue",5}
};

int ImageWidget::nextLoadImageReceiverID = 0;
std::unordered_map<int, ImageWidget*> ImageWidget::loadImageReceivers;
std::string ImageWidget::LOGGER_NAME = "volt.imageWidget";

ImageWidget::ImageWidget(float x, float y, Widget* aParent, ImageWidgetReadyCallback ready)
  : scaleImageDimensions(false),
    imageBuffer(new DataBuffer()),
    onReady(ready),
    isReady(false),
    fillMode(Stretch),
    loadImageReceiverID(-1),
    asyncLoad(true),
    logger_(LOGGER_NAME)
{
  LOG_DEBUG(logger_, "Born (" << this << ")");
  actor = volt_actor_new();
  init(x,y, aParent);
  setColor(Color(0,0,0,0));
}

ImageWidget::ImageWidget(float x, float y, float width, float height, Widget* aParent, ImageWidgetReadyCallback ready)
  : Widget(x, y, width, height, aParent),
    scaleImageDimensions(width >= 0 || height >= 0),
    imageBuffer(new DataBuffer()),
    onReady(ready),
    isReady(false),
    fillMode(Stretch),
    loadImageReceiverID(-1),
    asyncLoad(true),
    logger_(LOGGER_NAME)

{
  LOG_DEBUG(logger_, "Born (" << this << ")");
  setColor(Color(0,0,0,0));
}

ImageWidget::~ImageWidget()
{
  LOG_DEBUG(logger_, "Dead (" << this << ")");
  CancelLoadImage();

  if (imageSource)
  {
    imageSource->RemoveActor(actor);
    imageSource.reset();
  }
}

void ImageWidget::setSource(const std::string& imageUri)
{
  /* Added by HQ presumably to handle cases where an async loading for the
   * current source is still ongoing. */
  CancelLoadImage();

  if (imageSource.get())
  {
    imageSource->RemoveActor(actor);
    imageSource.reset();
  }

  imageSourceUri = imageUri;

  if(imageUri == "")
  {
    clutter_actor_set_content(actor, NULL);
  }
  else
  {
    BeginLoadImage(imageUri);
  }
}

void ImageWidget::setSource(DataBuffer::SharedPtr buffer)
{
  volt::util::Logger logger(ResourceLoader::LOGGER_NAME);

  if(not buffer.get() or not buffer->data() or not buffer->length())
  {
    LOG_ERROR(logger, "null buffer or length, failed to set buffer as image source");
    return;
  }

  if (imageSource.get())
  {
    imageSource->RemoveActor(actor);
    imageSource.reset();
  }

  imageBuffer = buffer->getSharedPtr();

  // load raw image buffer here..
  ResourceLoader::Instance().LoadImage(this, buffer);
}

void ImageWidget::setSource(Image *aImage)
{
  if (aImage)
  {
    imageSourceUri = aImage->uri();

    if (imageSource.get())
    {
      imageSource->RemoveActor(actor);
    }

    imageSource = aImage->getSharedPtr();
    imageSource->AddActor(actor);

    if (imageSource->image())
    {
      onImageLoaded(imageSource->image(), true);
    }
    else if (imageSource->async())
    {
      /* assuming it's still loading... */
      imageSource->RegisterOnLoadCallback(this,
                                          std::bind(&ImageWidget::OnImageLoadedCallback,
                                              this, std::placeholders::_1));
    }
  }
}

Image* ImageWidget::getSourceImage() const
{
  return imageSource.get();
}

void ImageWidget::setFillMode(FillMode mode)
{
  if (isReady)
  {
    clutter_actor_set_content_gravity(actor, ClutterContentGravity(mode));
  }

  fillMode = mode;
}

bool ImageWidget::getColorPicking(int percentage, Color* color)
{
  return getColorPicking(percentage, 0, 0, 0, 0, color);
}

bool ImageWidget::checkGreyScaleSimple( const int r , const int g , const int b ) const
{
  float mean = (float)( r + g + b)/3.0f;
  float sv = std::sqrt( std::pow(2, r - mean) + std::pow( 2, g /*not, r right?*/ - mean) + std::pow( 2,b - mean ) );
  return (sv <= ImageWidget::colorPickOptions["greyscaleValue"]); // true : grey ,  false : not-grey
}


bool ImageWidget::getColorPicking(int percentage, int x1, int x2, int y1, int y2, Color* color)
{
  if (NULL == color)
  {
    LOG_FATAL(logger_, "Color address cannot be NULL!");
    return false;
  }

  color->r = color->g = color->b = 0;

  ClutterContent* image = clutter_actor_get_content(actor);

  if (VOLT_IS_IMAGE(image) == FALSE)
  {
    return false;
  }

  GdkPixbufAnimation* pixbufAnim = volt_image_get_pixbuf_anim(VOLT_IMAGE(image));

  if (NULL == pixbufAnim)
  {
    LOG_FATAL(logger_, "Get pixbuf anim failed!");
    return false;
  }

  GdkPixbuf *pixbuf = gdk_pixbuf_animation_get_static_image(pixbufAnim);

  if (NULL == pixbuf)
  {
    LOG_FATAL(logger_, "Get pixbuf from pixbuf_anim failed!");
    return false;
  }

  gboolean retVal = false;
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  const int MIN_PIXEL_VAL = ImageWidget::colorPickOptions["minRange"];
  const int MAX_PIXEL_VAL = ImageWidget::colorPickOptions["maxRange"];
  GdkPickColor pick_color = { 0, };
  pick_color.perc = percentage;
  pick_color.x1 = x1;
  pick_color.x2 = x2;
  pick_color.y1 = y1;
  pick_color.y2 = y2;
  pick_color.R = ImageWidget::colorPickOptions["defaultRed"];
  pick_color.G = ImageWidget::colorPickOptions["defaultGreen"];
  pick_color.B = ImageWidget::colorPickOptions["defaultBlue"];
  retVal = getColorPickValues(pixbuf, &pick_color);
  LOG_DEBUG(logger_, "Get color_picking, r:" << std::dec <<
  	(int)pick_color.R << "g:" <<
  	(int)pick_color.G << "b:" <<
  	(int)pick_color.B);
  
  if( retVal )
  {
  	if( pick_color.R < MIN_PIXEL_VAL && pick_color.G < MIN_PIXEL_VAL && pick_color.B < MIN_PIXEL_VAL &&
  			checkGreyScaleSimple( pick_color.R , pick_color.G , pick_color.B ) )
  	{
  	  LOG_DEBUG(logger_, "Clamp color pick to min pixel val= " << MIN_PIXEL_VAL);
  	  pick_color.R = MIN_PIXEL_VAL;
  	  pick_color.G = MIN_PIXEL_VAL;
  	  pick_color.B = MIN_PIXEL_VAL;
  	}
  	else if( pick_color.R > MAX_PIXEL_VAL && pick_color.G > MAX_PIXEL_VAL && pick_color.B > MAX_PIXEL_VAL &&
  			checkGreyScaleSimple( pick_color.R , pick_color.G , pick_color.B ) )
  	{
  	  LOG_DEBUG(logger_, "Clamp color pick to max pixel val= " << MAX_PIXEL_VAL);
  	  pick_color.R = MAX_PIXEL_VAL;
  	  pick_color.G = MAX_PIXEL_VAL;
  	  pick_color.B = MAX_PIXEL_VAL;
  	}
  }

  color->r = pick_color.R;
  color->g = pick_color.G;
  color->b = pick_color.B;
#else
  retVal = true;
  color->r = 0;
  color->g = 0;
  color->b = 0;
#endif
  return retVal;
}

bool ImageWidget::getImageCroppedCoord(float* x1, float* y1, float* x2, float* y2)
{
  if (NULL == x1 || NULL == y1 || NULL == x2 || NULL == y2)
  {
    LOG_FATAL(logger_, "Cropped coord address cannot be NULL!");
    return false;
  }
  *x1 = *y1 = *x2 = *y2 = 0;

  ClutterContent* image = clutter_actor_get_content(actor);
  if (VOLT_IS_IMAGE(image) == FALSE)
  {
    return false;
  }

  GdkPixbufAnimation* pixbufAnim = volt_image_get_pixbuf_anim(VOLT_IMAGE(image));
  if (NULL == pixbufAnim)
  {
    LOG_FATAL(logger_, "Get pixbuf anim failed!");
    return false;
  }

  GdkPixbuf *pixbuf = gdk_pixbuf_animation_get_static_image(pixbufAnim);
  if (NULL == pixbuf)
  {
    LOG_FATAL(logger_, "Get pixbuf from pixbuf_anim failed!");
    return false;
  }

  gboolean retVal = false;
#if defined(TIZEN) || defined(LINUX)
  float image_width = gdk_pixbuf_get_width(pixbuf);
  float image_height = gdk_pixbuf_get_height(pixbuf);
  ClutterActorBox box_tex_coord;
  retVal = clutter_actor_get_image_cropped_coord(actor, getWidth(), getHeight(), image_width, image_height, &box_tex_coord);
  LOG_DEBUG(logger_, "Get image cropped coord, x1:" << box_tex_coord.x1 << "y1:" << box_tex_coord.y1 << "x2:" << box_tex_coord.x2 << "y2:" << box_tex_coord.y2);
  *x1 = box_tex_coord.x1 * image_width;
  *y1 = box_tex_coord.y1 * image_height;
  *x2 = box_tex_coord.x2 * image_width;
  *y2 = box_tex_coord.y2 * image_height;
#endif

	return retVal;
}

std::string ImageWidget::getSource() const
{
  return imageSourceUri;
}

void ImageWidget::setAsyncLoading(const bool async)
{
  asyncLoad = async;
}

bool ImageWidget::getAsyncLoading() const
{
  return asyncLoad;
}

float ImageWidget::getWidth() const
{
  return clutter_actor_get_width(actor);
}

void ImageWidget::setWidth(float width)
{
  if (width < 0)
  {
    return;
  }

  scaleImageDimensions = true;
  Widget::setWidth(width);
}

float ImageWidget::getHeight() const
{
  return clutter_actor_get_height(actor);
}

void ImageWidget::setHeight(float height)
{
  if (height < 0)
  {
    return;
  }

  scaleImageDimensions = true;
  Widget::setHeight(height);
}

void ImageWidget::BeginLoadImage(std::string imageUri)
{
  //register for callback
  loadImageReceivers[nextLoadImageReceiverID] = this;

  //Start load image
  ImageLoadedCallback callback = std::bind(ImageWidget::onImageLoadedRouter, nextLoadImageReceiverID, std::placeholders::_1, std::placeholders::_2);
  bool success = ResourceLoader::Instance().LoadImage(callback, imageUri, asyncLoad, COGL_TEXTURE_NO_ATLAS);

  if (!success) //if it fails here invoke the failure logic. If it succeeds, it may still fail later so wait for the async callback
  {
    callback(nullptr, false);
  }

  loadImageReceiverID = nextLoadImageReceiverID;
  nextLoadImageReceiverID++;
}

void ImageWidget::onImageLoadedRouter(int receiverID, VoltImage* image, bool success)
{
  if (loadImageReceivers.count(receiverID))
  {
    //Load the image
    ImageWidget* receiver = loadImageReceivers[receiverID];
    receiver->onImageLoaded(image, success);

    //Unregister for callbacks
    receiver->CancelLoadImage();
  }
}


void ImageWidget::onImageLoaded(VoltImage* image, bool success)
{
  if (success)
  {
    attachVoltImage(image);
  }

  isReady = success;

  if (onReady != nullptr)
  {
    onReady(success);
  }
}

void ImageWidget::attachVoltImage(VoltImage* image)
{
  volt::util::Logger logger(ResourceLoader::LOGGER_NAME);

  GdkPixbufAnimation *pixbufAnim = volt_image_get_pixbuf_anim(VOLT_IMAGE(image));
  gboolean isStatic = TRUE;

  if (pixbufAnim)
  {
    isStatic = gdk_pixbuf_animation_is_static_image(pixbufAnim);
  }

  if (!scaleImageDimensions)
  {
    bool size_ok = true;
    gfloat width, height;

    if (!isStatic && pixbufAnim) // Image is animated
    {
      width = gdk_pixbuf_animation_get_width(pixbufAnim);
      height = gdk_pixbuf_animation_get_height(pixbufAnim);

      // if this is an animated gif but we don't have an Image instance,
      // then display first frame for compatibility.
      if (!imageSource)
      {
        GError *error = NULL;
        GdkPixbuf *aPixbuf = gdk_pixbuf_animation_get_static_image(pixbufAnim);

        volt_image_set_data(image,
                            gdk_pixbuf_get_pixels(aPixbuf),
                            COGL_TEXTURE_NO_ATLAS,
                            gdk_pixbuf_get_has_alpha(aPixbuf)
                            ? COGL_PIXEL_FORMAT_RGBA_8888
                            : COGL_PIXEL_FORMAT_RGB_888,
                            gdk_pixbuf_get_width(aPixbuf),
                            gdk_pixbuf_get_height(aPixbuf),
                            gdk_pixbuf_get_rowstride(aPixbuf),
                            &error);
      }
    }
    else
    {
      size_ok = clutter_content_get_preferred_size(CLUTTER_CONTENT(image),
                &width, &height);
    }

    if (size_ok)
    {
      setWidth(width);
      setHeight(height);

      LOG_DEBUG(logger, "Scaled to the image size: " << width << "x" << height);
    }
  }

  clutter_actor_set_content(actor, CLUTTER_CONTENT(image));
  clutter_actor_set_content_gravity(actor, ClutterContentGravity(fillMode));
  volt_actor_shadow_update(VOLT_ACTOR(actor));
  LOG_DEBUG(logger, "Set image: " << imageSourceUri);
}

const std::string& ImageWidget::getWidgetTypeString() const
{
  static const std::string type("ImageWidget");
  return type;
}

void ImageWidget::writeSceneGraphExtraJson(std::ostream &aOut, const std::string aIndent) const
{
  if (getSource().empty() == false)
  {
    aOut << aIndent << "\"src\": \"" << getSource() << "\"," << std::endl;
  }
  else if (getSourceImage())
  {
    aOut << aIndent << "\"src\": \"<<Image>>\"," << std::endl;
  }
  else
  {
    aOut << aIndent << "\"src\": \"<<arraybuffer>>\"," << std::endl;
  }
}

void ImageWidget::CancelLoadImage()
{
  if (loadImageReceiverID != -1)
  {
    loadImageReceivers.erase(loadImageReceiverID);
    loadImageReceiverID = -1;
  }

  if (imageSource)
  {
    imageSource->UnregisterOnLoadCallback(this);
  }
}

void ImageWidget::OnImageLoadedCallback(Image *aImage)
{
  if (aImage == nullptr)
  {
    return;
  }

  volt::util::Logger logger(ResourceLoader::LOGGER_NAME);
  bool success = true;

  if (aImage->image())
  {
    LOG_DEBUG(logger, "Image content ready: " << aImage->uri());
  }
  else
  {
    LOG_WARN(logger, "Failed to load image content: " << aImage->uri());
    success = false;
  }

  onImageLoaded(aImage->image(), success);
}

#ifdef USE_NEON_OPT
gboolean ImageWidget::getColorPickValues(GdkPixbuf *pixbuf, GdkPickColor *pick_color) const
{
	int i, j;
	unsigned long long sumRGBA[4] = {0, 0, 0, 0};
	int moveColCnt = 0;
	int sumR = 0, sumG = 0, sumB = 0, nPixels = 0;
	int temp = 0;

	//get pixbuf values using public apis.
	LOG_DEBUG(logger_,"using optimized NEON color pick method");	
	guchar* temp_rgb = gdk_pixbuf_get_pixels(pixbuf);
	const int PB_WIDTH = gdk_pixbuf_get_width(pixbuf);	
	const int PB_HEIGHT = gdk_pixbuf_get_height(pixbuf);
	const int PB_ROWSTRIDE = gdk_pixbuf_get_rowstride(pixbuf);
	const int PB_N_CHANNELS = gdk_pixbuf_get_n_channels(pixbuf);

	int perc_enable_y1, perc_enable_y2;
	if(pixbuf == NULL || pick_color == NULL)
	{
		return FALSE;
	}
	if(pick_color->perc <= 0)
	{
		if(pick_color->x1 < 0)
		{
			pick_color->x1 = 0;
		}
		if(pick_color->y1 < 0)
		{
			pick_color->y1 = 0;		
		}
		if(pick_color->x2 > PB_WIDTH - 1)
		{
			pick_color->x2 = PB_WIDTH - 1;
		}
		if(pick_color->y2 > PB_HEIGHT - 1)
		{
			pick_color->y2 = PB_HEIGHT - 1;
		} 
	}
	else if(pick_color->perc >100)
	{
		pick_color->perc = 100 ;
	}
	int endY = PB_HEIGHT - 1;
	int startX = 0;
	int endX = PB_WIDTH - 1;
	int w = PB_WIDTH;
	if(pick_color->perc > 0)
	{
		if( (pick_color->region < GDK_COLORPICK_TOP) || (pick_color->region > GDK_COLORPICK_BOTTOM) )
		{
				return FALSE;
		}
		if(pick_color->region == GDK_COLORPICK_TOP)
		{
			perc_enable_y1 = 0;
			perc_enable_y2 = (pick_color->perc*PB_HEIGHT)/100 - 1;
		}
		else if(pick_color->region == GDK_COLORPICK_MIDDLE)
		{
			perc_enable_y1 = (PB_HEIGHT/2) - (((pick_color->perc/2)*PB_HEIGHT)/100);
			perc_enable_y2 = perc_enable_y1 + ((pick_color->perc*PB_HEIGHT)/100) - 1;
		}
		else
		{
			perc_enable_y1 = (PB_HEIGHT) - (pick_color->perc * PB_HEIGHT/100);
			perc_enable_y2 = PB_HEIGHT - 1;
		}
		nPixels = (pick_color->perc*PB_HEIGHT)*PB_WIDTH/100;
		i = perc_enable_y1;
		endY = perc_enable_y2;
	}
	else
	{
		nPixels = (pick_color->y2 - pick_color->y1 + 1) * (pick_color->x2 - pick_color->x1 + 1);
		endY = pick_color->y2;
		i = pick_color->y1;
		startX = pick_color->x1;
		endX = pick_color->x2;
		w = pick_color->x2 - pick_color->x1 + 1;
	}
	
	for(; i <= endY; i ++)
	{
		temp_rgb = gdk_pixbuf_get_pixels(pixbuf) + (i*PB_ROWSTRIDE) + (startX*PB_N_CHANNELS);
		memset(sumRGBA, 0, sizeof(unsigned long long) * 4);
		
		uint32x4_t sumR_32x4 = vmovq_n_u32 ( 0 );
		uint32x4_t sumG_32x4 = vmovq_n_u32 ( 0 );
		uint32x4_t sumB_32x4 = vmovq_n_u32 ( 0 );

		uint8x16_t R_8x16;
		uint8x16_t G_8x16;
		uint8x16_t B_8x16;

		uint64x1x3_t sumRGB_64x1;

		for(j = startX; j < endX-(w&0xF); j += 16)
		{
			if(PB_N_CHANNELS == 3)
			{
				uint8x16x3_t rgb = vld3q_u8 ( temp_rgb );
				R_8x16 = rgb.val[0];
				G_8x16 = rgb.val[1];
				B_8x16 = rgb.val[2];
			}
			else
			{
				uint8x16x4_t rgb = vld4q_u8 ( temp_rgb );
				R_8x16 = rgb.val[0];
				G_8x16 = rgb.val[1];
				B_8x16 = rgb.val[2];
			}
			
			uint16x8_t sumR_16x8 = vpaddlq_u8 ( R_8x16 );
			uint16x8_t sumG_16x8 = vpaddlq_u8 ( G_8x16 );
			uint16x8_t sumB_16x8 = vpaddlq_u8 ( B_8x16 );
			
			sumR_32x4 = vpadalq_u16 ( sumR_32x4, sumR_16x8 );
			sumG_32x4 = vpadalq_u16 ( sumG_32x4, sumG_16x8 );
			sumB_32x4 = vpadalq_u16 ( sumB_32x4, sumB_16x8 );
		
			temp_rgb += (PB_N_CHANNELS*16);
		}

		uint64x2_t sumR_64x2 = vpaddlq_u32 ( sumR_32x4 );
		uint64x2_t sumG_64x2 = vpaddlq_u32 ( sumG_32x4 );
		uint64x2_t sumB_64x2 = vpaddlq_u32 ( sumB_32x4 );	

		uint64x1_t sumR_Lo_64x1 = vget_low_u64 ( sumR_64x2 );
		uint64x1_t sumR_Hi_64x1 = vget_high_u64 ( sumR_64x2 );
		
		uint64x1_t sumG_Lo_64x1 = vget_low_u64 ( sumG_64x2 );
		uint64x1_t sumG_Hi_64x1 = vget_high_u64 ( sumG_64x2 );
		
		uint64x1_t sumB_Lo_64x1 = vget_low_u64 ( sumB_64x2 );
		uint64x1_t sumB_Hi_64x1 = vget_high_u64 ( sumB_64x2 );
		
		sumRGB_64x1.val[0] = vadd_u64 ( sumR_Lo_64x1, sumR_Hi_64x1 );
		sumRGB_64x1.val[1] = vadd_u64 ( sumG_Lo_64x1, sumG_Hi_64x1 );
		sumRGB_64x1.val[2] = vadd_u64 ( sumB_Lo_64x1, sumB_Hi_64x1 );
		
		vst3_u64( sumRGBA, sumRGB_64x1);
		
		for(; j <= endX; j ++)
		{
            sumRGBA[0] += temp_rgb[0];
            sumRGBA[1] += temp_rgb[1];
            sumRGBA[2] += temp_rgb[2];
            temp_rgb += PB_N_CHANNELS;
		}
		sumR += sumRGBA[0];
		sumG += sumRGBA[1];
		sumB += sumRGBA[2];
	}
	if(nPixels)
	{
		pick_color->R = sumR/nPixels;
		pick_color->G = sumG/nPixels;
		pick_color->B = sumB/nPixels;
	}
	return TRUE;
}
#else
gboolean ImageWidget::getColorPickValues(GdkPixbuf *pixbuf, GdkPickColor *pick_color) const
{
	//NOTE:currently does not work on tizen.(doesnt get used normally on tizen anyways).
	int i, j;
	int sumR = 0, sumG = 0, sumB = 0, nPixels = 0;
	
	//get pixbuf values using public apis.
	LOG_DEBUG(logger_,"using non-optimized color pick method");
	guchar* temp_rgb = gdk_pixbuf_get_pixels(pixbuf);
	const int PB_WIDTH = gdk_pixbuf_get_width(pixbuf);	
	const int PB_HEIGHT = gdk_pixbuf_get_height(pixbuf);
	const int PB_ROWSTRIDE = gdk_pixbuf_get_rowstride(pixbuf);
	const int PB_N_CHANNELS = gdk_pixbuf_get_n_channels(pixbuf);

	if(pixbuf == NULL || pick_color == NULL)
	{
		return FALSE;
	}

	nPixels = (pick_color->perc*PB_HEIGHT)*PB_WIDTH /100;
	i = (((100-pick_color->perc)*PB_HEIGHT)/100);
	temp_rgb += i*PB_ROWSTRIDE;

	for(; i < PB_HEIGHT; i ++)
	{

		for(j = 0; j < PB_WIDTH; j ++)
		{
			sumR += temp_rgb[0];
			sumG += temp_rgb[1];
			sumB += temp_rgb[+2];
			temp_rgb += PB_N_CHANNELS;
		}
		temp_rgb += (PB_ROWSTRIDE-(PB_WIDTH*PB_N_CHANNELS));
	}
	if(nPixels)
	{
		pick_color->R = sumR/nPixels;
		pick_color->G = sumG/nPixels;
		pick_color->B = sumB/nPixels;
	}
	return TRUE;
}
#endif

void ImageWidget::ConfigureColorPicking(const std::map<std::string, int> args)
{

  for(std::map<std::string,int>::const_iterator it = args.begin(); it != args.end(); ++it)
  {
    ImageWidget::colorPickOptions[it->first] = it->second;
  }
  

}

std::vector<std::string> ImageWidget::getColorPickOptionKeys(void)
{
  std::vector<std::string> keys;
  for(std::map<std::string,int>::iterator it = ImageWidget::colorPickOptions.begin(); it != ImageWidget::colorPickOptions.end(); ++it)
  {
    keys.push_back(it->first);
  }
  return keys;
}
