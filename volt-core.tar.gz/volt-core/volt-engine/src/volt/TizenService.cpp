/*
 * ServiceApp.cpp
 *
 *  Created on: June 26, 2014
 *      Author: Joe Yee
 */

#include "ServiceBridge.h"
#include "VoltConfig.h"
#include "TizenService.h"
#include <clutter/clutter.h>

volt::util::Logger TizenService::LOGGER = volt::util::Logger("volt.tizen.service");

using namespace volt::util;

#if defined(BUILD_FOR_TV) && defined(TIZEN)
static void TizenServiceLaunchCallback (service_h request, service_h reply, service_result_e result, void *user_data)
{
  if(not user_data)
  {
    return;
  }

  Bridge::ServiceBridge::ProxyRequestServiceCallback((TizenService *) user_data, (int)result);
}

TizenService::TizenService()
  : serviceHandle_(nullptr),
    serviceOperationId(-1)
{
  LOG_DEBUG(LOGGER, "TizenService born @ " << this);

  int result =  service_create(&serviceHandle_);

  if(result != SERVICE_ERROR_NONE)
  {
    LOG_ERROR(LOGGER, "failed to create service handle, error code: " << result);
    serviceHandle_ = nullptr;
  }

}

#else

TizenService::TizenService()
  : serviceOperationId(-1)
{
  LOG_DEBUG(LOGGER, "TizenService born @ " << this);
}

#endif

TizenService::~TizenService()
{
  LOG_DEBUG(LOGGER, "TizenService dead @ " << this);

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(serviceHandle_)
  {
    int result = service_destroy(serviceHandle_);

    if(result != SERVICE_ERROR_NONE)
    {
      LOG_ERROR(LOGGER, "failed to destroy service handle @ " << serviceHandle_ << ", error code: " << result);
    }
  }

#endif
}

void TizenService::SetAppId(const std::string & id)
{
  LOG_DEBUG(LOGGER, "TizenService set app id: " << id);

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(serviceHandle_)
  {
    int result = service_set_app_id(serviceHandle_, id.c_str());

    if(result != SERVICE_ERROR_NONE)
    {
      LOG_ERROR(LOGGER, "failed to set app id for service handle @ " << serviceHandle_ << ", error code: " << result);
    }
    else
    {
      result = 0;
    }
  }

#endif
}

std::string TizenService::GetAppId() const
{
  std::string appId;

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(serviceHandle_)
  {
    char *buffer = nullptr;

    int result = service_get_app_id(serviceHandle_, &buffer);

    if(result != SERVICE_ERROR_NONE)
    {
      LOG_ERROR(LOGGER, "failed to get app id for service handle @ " << serviceHandle_ << ", error code: " << result);
      appId = "";
    }
    else if(buffer)
    {
      result = 0;
      appId.assign(buffer);
      free(buffer);
    }
  }

#endif

  return appId;
}


void TizenService::SetServiceOperation(int operation)
{
  LOG_DEBUG(LOGGER, "TizenService set service operation: " << operation);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  int result = -1;

  if(not serviceHandle_)
  {
    LOG_ERROR(LOGGER, "null service handle, unable to set operation");
    return;
  }

  switch(operation)
  {
  case Bridge::OPERATION_DEFAULT:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_DEFAULT);
    break;
  case Bridge::OPERATION_EDIT:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_EDIT);
    break;
  case Bridge::OPERATION_VIEW:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_VIEW);
    break;
  case Bridge::OPERATION_PICK:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_PICK);
    break;
  case Bridge::OPERATION_CREATE_CONTENT:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_CREATE_CONTENT);
    break;
  case Bridge::OPERATION_CALL:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_CALL);
    break;
  case Bridge::OPERATION_SEND:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_SEND);
    break;
  case Bridge::OPERATION_SEND_TEXT:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_SEND_TEXT);
    break;
  case Bridge::OPERATION_SHARE:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_SHARE);
    break;
  case Bridge::OPERATION_MULTI_SHARE:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_MULTI_SHARE);
    break;
  case Bridge::OPERATION_SHARE_TEXT:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_SHARE_TEXT);
    break;
  case Bridge::OPERATION_DIAL:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_DIAL);
    break;
  case Bridge::OPERATION_SEARCH:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_SEARCH);
    break;
  case Bridge::OPERATION_DOWNLOAD:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_DOWNLOAD);
    break;
  case Bridge::OPERATION_PRINT:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_PRINT);
    break;
  case Bridge::OPERATION_COMPOSE:
    result = service_set_operation(serviceHandle_, SERVICE_OPERATION_COMPOSE);
    break;
  case Bridge::OPERATION_DATA_SUBJECT:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_SUBJECT);
    break;
  case Bridge::OPERATION_DATA_TO:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_TO);
    break;
  case Bridge::OPERATION_DATA_CC:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_CC);
    break;
  case Bridge::OPERATION_DATA_BCC:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_BCC);
    break;
  case Bridge::OPERATION_DATA_TEXT:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_TEXT);
    break;
  case Bridge::OPERATION_DATA_TITLE:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_TITLE);
    break;
  case Bridge::OPERATION_DATA_SELECTED:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_SELECTED);
    break;
  case Bridge::OPERATION_DATA_PATH:
    result = service_set_operation(serviceHandle_, SERVICE_DATA_PATH);
    break;
  default:
    LOG_ERROR(LOGGER, "invalid service type " << operation);
    break;
  }

  if(result != SERVICE_ERROR_NONE)
  {
    LOG_ERROR(LOGGER, "failed to set operation for service handle @ " << serviceHandle_ << ", error code: " << result);
  }
  else
  {
    result = 0;
  }

#endif
  serviceOperationId = operation;
}

int TizenService::GetServiceOperation() const
{
  return serviceOperationId;
}

void TizenService::SetUri(const std::string& aUri)
{
  LOG_DEBUG(LOGGER, "TizenService set uri: " << aUri);

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(serviceHandle_)
  {
    int result = service_set_uri(serviceHandle_, aUri.c_str());

    if(result != SERVICE_ERROR_NONE)
    {
      LOG_ERROR(LOGGER, "failed to set uri for service handle @ " << serviceHandle_ << ", error code: " << result);
    }
    else
    {
      result = 0;
    }
  }

#endif
}

std::string TizenService::GetUri() const
{
  std::string uri;

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(serviceHandle_)
  {
    char *buffer = nullptr;
    int result = service_get_uri(serviceHandle_, &buffer);

    if(result != SERVICE_ERROR_NONE)
    {
      LOG_ERROR(LOGGER, "failed to get uri for service handle @ " << serviceHandle_ << ", error code: " << result);
    }
    else if(buffer)
    {
      result = 0;
      uri.assign(buffer);
      free(buffer);
    }
  }

#endif

  return uri;
}


void TizenService::SetPackage(const std::string& aPackage)
{
  LOG_DEBUG(LOGGER, "TizenService set package: " << aPackage);

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(serviceHandle_)
  {
    int result = service_set_package(serviceHandle_, aPackage.c_str());

    if(result != SERVICE_ERROR_NONE)
    {
      LOG_ERROR(LOGGER, "failed to set package for service handle @ " << serviceHandle_ << ", error code: " << result);
    }
    else
    {
      result = 0;
    }
  }

#endif
}

std::string TizenService::GetPackage() const
{
  std::string package;

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(serviceHandle_)
  {
    char *buffer = nullptr;

    int result = service_get_package(serviceHandle_, &buffer);

    if(result != SERVICE_ERROR_NONE)
    {
      LOG_ERROR(LOGGER, "failed to get package for service handle @ " << serviceHandle_ << ", error code: " << result);
      package = "";
    }
    else if(buffer)
    {
      result = 0;
      package.assign(buffer);
      free(buffer);
    }
  }

#endif

  return package;
}

int TizenService::AddExtraData(std::string &key, std::string &value)
{
  LOG_DEBUG(LOGGER, "TizenService add extra data, key: " << key << ", value: " << value);

  int result = -1;

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(not serviceHandle_)
  {
    LOG_ERROR(LOGGER, "null service handle, unable to add extra data");
    return result;
  }

  result = service_add_extra_data(serviceHandle_, key.c_str(), value.c_str());

  if(result != SERVICE_ERROR_NONE)
  {
    LOG_ERROR(LOGGER, "failed to add extra data for service handle @ " << serviceHandle_
              << ", error code: " << result << " key: "<< key << ", value: " << value);
  }
  else
  {
    result = 0;
  }

#endif
  return result;
}

int TizenService::AddExtraData(std::string &key, std::vector<std::string> &values)
{
  int result = -1;
  int length = values.size();

  if(not key.length() or not length)
  {
    LOG_ERROR(LOGGER, "empty key or values");
    return result;
  }

  LOG_DEBUG(LOGGER, "TizenService add extra data array, key: " << key << ", array length: " << length);

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(not serviceHandle_)
  {
    LOG_ERROR(LOGGER, "null service handle, unable to add extra data");
    return result;
  }

  const char *valueInput[length];

  for(int i = 0; i < length; i++)
  {
    valueInput[i] = values[i].c_str();
  }

  result = service_add_extra_data_array(serviceHandle_, key.c_str(), valueInput, length);

  if(result != SERVICE_ERROR_NONE)
  {
    LOG_ERROR(LOGGER, "failed to add extra data array for service handle @ " << serviceHandle_
              << ", error code: " << result << " key: "<< key);
  }
  else
  {
    result = 0;
  }

#endif

  return result;
}

int TizenService::Launch(bool callback)
{
  LOG_DEBUG(LOGGER, "TizenService launch");

  int result = -1;

#if defined(BUILD_FOR_TV) && defined(TIZEN)

  if(not serviceHandle_)
  {
    LOG_ERROR(LOGGER, "null service handle, unable to launch");
    return result;
  }

  if(callback)
  {
    result = service_send_launch_request(serviceHandle_, TizenServiceLaunchCallback, (void *) this);
  }
  else
  {
    result = service_send_launch_request(serviceHandle_, NULL, NULL);
  }

  if(result != SERVICE_ERROR_NONE)
  {
    LOG_ERROR(LOGGER, "failed to launch for service handle @ " << serviceHandle_ << ", error code: " << result);
  }
  else
  {
    result = 0;
  }

#else
  result = 0;
#endif

  return result;
}
