#include "AnimationSpec.h"
#include "VoltConfig.h"
#include "TextWidget.h"
#include "Exception.h"
#include <cstring>

using namespace volt::graphics;

void AnimationSpec::addKey(double key, TweenMode tweenMode, const GValue& value, bool isRelative)
{

  //insertion sort to find the right index for the new key
  auto it = keys.begin();
  uint index;

  for (it = keys.begin(), index = 0; it != keys.end() && key >= keys[index]; ++it, ++index)
  {
    //If we find another identical key, replace it and return early
    if (key == keys[index])
    {
      tweenModes[index] = ClutterAnimationMode(tweenMode);
      values[index] = value;
      relativeKeyFlags[index] = isRelative;
      return;
    }
  }

  //Add the new key
  if (index >= keys.size())
  {
    keys.push_back(key);
    tweenModes.push_back(ClutterAnimationMode(tweenMode));
    values.push_back(value);
    relativeKeyFlags.push_back(isRelative);
  }
  else
  {
    keys.insert(keys.begin() + index, key);
    tweenModes.insert(tweenModes.begin() + index, ClutterAnimationMode(tweenMode));
    values.insert(values.begin() + index, value);
    relativeKeyFlags.insert(relativeKeyFlags.begin() + index, isRelative);
  }

  hasRelativeKeys = isRelative;
}

//need to take values as a parameter because in some cases we might not want to use the one stored in the values member var. See getTransition method.
ClutterTransition* AnimationSpec::createTransition(AnimatableProperty property, bool makeInt, const std::vector<GValue>& keyValues,
    ClutterActor* actor, WidgetPropertyType animType) const
{
  const char* propName = voltAnimatableToClutter(property);

  ClutterTransition* transition = clutter_keyframe_transition_new(propName);

  const GValue latestValue = keyValues.back();
  clutter_transition_set_to_value(transition, &latestValue);

  if (useKeys)
  {
    int numKeys = keyValues.size();
    clutter_keyframe_transition_set_key_frames(CLUTTER_KEYFRAME_TRANSITION(transition), numKeys, keys.data());
    clutter_keyframe_transition_set_modes(CLUTTER_KEYFRAME_TRANSITION(transition), numKeys, tweenModes.data());
    clutter_keyframe_transition_set_values(CLUTTER_KEYFRAME_TRANSITION(transition), numKeys, keyValues.data());
  }
  else
  {
    ClutterAnimationMode easingType = tweenModes.back();
    clutter_timeline_set_progress_mode(CLUTTER_TIMELINE(transition), easingType);

    if ( easingType == ClutterAnimationMode(CUBIC_BEZIER) )
    {
      //set bezier curve control points
      ClutterPoint c1;
      c1.x = customTweeningCurve.control1.x;
      c1.y = customTweeningCurve.control1.y;

      ClutterPoint c2;
      c2.x = customTweeningCurve.control2.x;
      c2.y = customTweeningCurve.control2.y;

      clutter_timeline_set_cubic_bezier_progress (CLUTTER_TIMELINE(transition), &c1, &c2);
    }
  }

  if (hasRelativeKeys)
  {
    //for each key value flagged as relative, add the current value of the relevent actor property
    int i = 0;

    for (auto it = relativeKeyFlags.begin(); it != relativeKeyFlags.end(); ++it)
    {
      if (*it)
      {
        GValue newVal = getActorRelativeValue(actor, propName, animType, keyValues[i]);

        if (useKeys)
        {
          clutter_keyframe_transition_set_key_frame(CLUTTER_KEYFRAME_TRANSITION(transition), i, keys[i], tweenModes[i], &newVal);
        }
        else
        {
          clutter_transition_set_to_value(transition, &newVal);
        }
      }

      i++;
    }
  }

  return transition;
}



GValue AnimationSpec::getActorRelativeValue(ClutterActor* actor, const char* prop, WidgetPropertyType animType, GValue offset) const
{
  GValue result;

  switch (animType)
  {
  case Byte:
  {
    guint8 value1, value2;
    g_object_get(actor, prop, &value1, NULL);
    value2 = GValueConversion::decodeGValue(offset, type);
    return GValueConversion::getGValue(type, value1 + value2);
  }
  case Scaler:
  {
    float value1, value2;

    //Rotation properties don't seem to work with g_object generic queries, so handle them explicitly
    if ( strcmp(prop, "rotation-angle-x") == 0 )
    {
      value1 = clutter_actor_get_rotation_angle(actor, CLUTTER_X_AXIS);
    }
    else if ( strcmp(prop, "rotation-angle-y") == 0)
    {
      value1 = clutter_actor_get_rotation_angle(actor, CLUTTER_Y_AXIS);
    }
    else if ( strcmp(prop, "rotation-angle-z") == 0)
    {
      value1 = clutter_actor_get_rotation_angle(actor, CLUTTER_Z_AXIS);
    }

    else
    {
      g_object_get(actor, prop, &value1, NULL);
    }

    value2 = GValueConversion::decodeGValue(offset, type);
    return GValueConversion::getGValue(type, value1 + value2);
  }
  case Vector2D:
  {
    Vector2 value1, value2;
    ClutterPoint* point;
    g_object_get(actor, prop, &point, NULL);

    if (point == nullptr) //if property was invalid substitute in a default
    {
      return GValueConversion::getGValue(Vector2(0,0));
    }

    value1 = Vector2(point->x, point->y);
    value2 = GValueConversion::decode2DGValue(offset);
    return GValueConversion::getGValue(value1 + value2);
  }
  case Vector3D:
  {
    Vector3 value1, value2;
    ClutterVertex* vertex;
    g_object_get(actor, prop, &vertex, NULL);

    if (vertex == nullptr) //if property was invalid substitute in a default
    {
      return GValueConversion::getGValue(Vector3(0,0,0));
    }

    value1 = Vector3(vertex->x, vertex->y, vertex->z);
    value2 = GValueConversion::decode3DGValue(offset);
    return GValueConversion::getGValue(value1 + value2);
  }
  case ColorValue:
  {
    Color value1, value2;
    ClutterColor* color;
    g_object_get(actor, prop, &color, NULL);

    if (color == nullptr) //if property was invalid substitute in a default
    {
      return GValueConversion::getGValue(Color::White());
    }

    value1 = Color(*color);
    value2 = GValueConversion::decodeColorGValue(offset);
    Color result = value1 + value2;
    return GValueConversion::getGValue(result);
  }
  }

  return result;
}

ClutterTransition* AnimationSpec::getTransition(Widget* widget, bool isAnimatingRoundedCorners) const
{
  const char* textColorErrorMsg = "Attempt to animate an unsupported property on widget";

  switch (property)
  {
  case BorderColorR:
  {
    Color color = widget->getBorderColor();
    return createColorTransition(BorderColor,  color, 0, widget->getAnimationActor(property));
  }

  case BorderColorG:
  {
    Color color = widget->getBorderColor();
    return createColorTransition(BorderColor,  color, 1, widget->getAnimationActor(property));
  }

  case BorderColorB:
  {
    Color color = widget->getBorderColor();
    return createColorTransition(BorderColor,  color, 2, widget->getAnimationActor(property));
  }

  case BorderColorA:
  {
    Color color = widget->getBorderColor();
    return createColorTransition(BorderColor,  color, 3, widget->getAnimationActor(property));
  }

  case TextColorR:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getTextColor();
    return createColorTransition(TextColor,  color, 0, widget->getAnimationActor(property));
  }

  case TextColorG:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getTextColor();
    return createColorTransition(TextColor,  color, 1, widget->getAnimationActor(property));
  }

  case TextColorB:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getTextColor();
    return createColorTransition(TextColor,  color, 2, widget->getAnimationActor(property));
  }

  case TextColorA:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getTextColor();
    return createColorTransition(TextColor,  color, 3, widget->getAnimationActor(property));
  }

  case TextShadowColorR:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getShadowColor();
    return createColorTransition(TextShadowColor,  color, 0, widget->getAnimationActor(property));
  }

  case TextShadowColorG:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getShadowColor();
    return createColorTransition(TextShadowColor,  color, 1, widget->getAnimationActor(property));
  }

  case TextShadowColorB:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getShadowColor();
    return createColorTransition(TextShadowColor,  color, 2, widget->getAnimationActor(property));
  }

  case TextShadowColorA:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    Color color = textWidget->getShadowColor();
    return createColorTransition(TextShadowColor,  color, 3, widget->getAnimationActor(property));
  }

  case Opacity:
  {
    return createTransition(property, true, values, widget->getAnimationActor(property), type);
  }

  case PivotX:
  {
    Vector2 pivot = widget->getPivot();
    return createVector2Transition(Pivot, pivot, 0, widget->getAnimationActor(property));
  }

  case PivotY:
  {
    Vector2 pivot = widget->getPivot();
    return createVector2Transition(Pivot, pivot, 1, widget->getAnimationActor(property));
  }

  case ColorR:
  {
    Color color = widget->getColor();
    return createColorTransition( (widget->getRoundedCorners() || isAnimatingRoundedCorners ? BackgroundColor_RC : BackgroundColor),
                                  color, 0, widget->getAnimationActor(property));
  }

  case ColorG:
  {
    Color color = widget->getColor();
    return createColorTransition( (widget->getRoundedCorners() || isAnimatingRoundedCorners ? BackgroundColor_RC : BackgroundColor),
                                  color, 1, widget->getAnimationActor(property));
  }

  case ColorB:
  {
    Color color = widget->getColor();
    return createColorTransition( (widget->getRoundedCorners() || isAnimatingRoundedCorners ? BackgroundColor_RC : BackgroundColor),
                                  color, 2, widget->getAnimationActor(property));
  }

  case ColorA:
  {
    Color color = widget->getColor();
    return createColorTransition( (widget->getRoundedCorners() || isAnimatingRoundedCorners ? BackgroundColor_RC : BackgroundColor) ,
                                  color, 3, widget->getAnimationActor(property));
  }

  case BackgroundColor:
  {
    return createTransition( (widget->getRoundedCorners() || isAnimatingRoundedCorners ? BackgroundColor_RC : BackgroundColor),
                             false, values, widget->getAnimationActor(property), type );
  }

  case TextShadowColor:
  case TextColor:
  {
    TextWidget* textWidget = dynamic_cast<TextWidget*>(widget);

    if (textWidget == nullptr)
    {
      throw VoltJsRuntimeException(textColorErrorMsg);
    }

    return createTransition(property, false, values, textWidget->getAnimationActor(property), type);
  }

  case RoundedCornersRadius:
  case RoundedCornersArcStep:
  {
    if (!widget->getRoundedCorners())
    {
      widget->setRoundedCorners(true);
    }

    return createTransition(property, false, values, widget->getAnimationActor(property), type);
  }

  default:

    if (type == Vector2D)
    {
      return createTransition(property, false, values, widget->getAnimationActor(property), type);
    }

    else
    {
      return createTransition(property, false, values, widget->getAnimationActor(property), type);
    }
  }
}

const char* AnimationSpec::voltAnimatableToClutter(AnimatableProperty voltProperty)
{
  switch (voltProperty)
  {
  case PositionX              :
    return "x";
  case PositionY              :
    return "y";
  case Width                  :
    return "volt-width";
  case Height                 :
    return "volt-height";
  case Depth                  :
    return "z-position";
  case Opacity                :
    return "opacity";
  case RotationX              :
    return "rotation-angle-x";
  case RotationY              :
    return "rotation-angle-y";
  case RotationZ              :
    return "rotation-angle-z";
  case ScaleX                 :
    return "scale-x";
  case ScaleY                 :
    return "scale-y";
  case AnchorX                :
    return "anchor-x";
  case AnchorY                :
    return "anchor-y";
  case OriginX                :
    return "origin-x";
  case OriginY                :
    return "origin-y";
  case RoundedCornersRadius   :
    return "rc-radius";
  case RoundedCornersArcStep  :
    return "rc-arc-step";
#ifdef ENABLE_EXPERIMENTAL_BUILD
  case CurlPeriod             :
    return "@effects.page-curl-effect.period";
  case CurlAngle              :
    return "@effects.page-curl-effect.angle";
  case CurlRadius             :
    return "@effects.page-curl-effect.radius";
  case Desaturate             :
    return "@effects.desaturate-effect.factor";
  case Brightness             :
    return "@effects.bright-contr-effect.brightness";
  case Contrast               :
    return "@effects.bright-contr-effect.constrast";
  case Tint                   :
    return "@effects.colorize-effect.tint";
#endif
  case PivotX:
  case PivotY:
  case Pivot                  :
    return "pivot-point";
  case BorderWidth            :
    return "border-width";
  case BackgroundColor_RC     :
    return "rc-color";
  case ColorR:
  case ColorG:
  case ColorB:
  case ColorA:
  case BackgroundColor        :
    return "background_color";
  case BorderColorR:
  case BorderColorG:
  case BorderColorB:
  case BorderColorA:
  case BorderColor            :
    return "border-color";
  case TextColorR:
  case TextColorG:
  case TextColorB:
  case TextColorA:
  case TextColor              :
    return "color";
  case LineSpacing            :
    return "line-spacing";
  case TextShadowXOffset      :
    return "shadow-x-offset";
  case TextShadowYOffset      :
    return "shadow-y-offset";
  case TextShadowColorR:
  case TextShadowColorG:
  case TextShadowColorB:
  case TextShadowColorA:
  case TextShadowColor        :
    return "text-shadow-color";
  case ShadowXOffset          :
    return "shadow-x-offset";
  case ShadowYOffset          :
    return "shadow-y-offset";
  case ShadowColorR:
  case ShadowColorG:
  case ShadowColorB:
  case ShadowColorA:
  case ShadowColor            :
    return "shadow-color";
  case ShadowBlur             :
    return "shadow-blur";
  case ShadowSpread           :
    return "shadow-spread";
  default                     :
    return "";
  }
}

//For when we are setting one component of a color. Our type will be scaler, but we will want to combine it with what we know about the widget
ClutterTransition* AnimationSpec::createColorTransition(AnimatableProperty property, Color color, int rgba, ClutterActor* actor) const
{
  std::vector<GValue> colorKeys;

  for (auto value = values.begin(); value != values.end(); value++)
  {
    const GValue val = *value;
    float knownColorComponent = g_value_get_float(&val);

    //If this is a relative transformation, make the base value zeros
    if (relativeKeyFlags[std::distance(values.begin(), value)])
    {
      color = Color(0,0,0,0);
    }

    if (rgba == 0)
    {
      color.r = knownColorComponent;
    }
    else if (rgba == 1)
    {
      color.g = knownColorComponent;
    }
    else if (rgba == 2)
    {
      color.b = knownColorComponent;
    }
    else if (rgba == 3)
    {
      color.a = knownColorComponent;
    }

    const ClutterColor* ccolor = color.toClutterColor();

    GValue fullColor = G_VALUE_INIT;

    g_value_init(&fullColor, CLUTTER_TYPE_COLOR);

    g_value_set_boxed(&fullColor, ccolor);

    colorKeys.push_back(fullColor);
  }

  return createTransition(property, false, colorKeys, actor, ColorValue);
}

ClutterTransition* AnimationSpec::createVector2Transition(AnimatableProperty property, Vector2 vec, bool isY, ClutterActor* actor) const
{
  //fill in the default everywhere but where specified by xy
  std::vector<GValue> vectorKeys;

  for (auto value = values.begin(); value != values.end(); value++)
  {
    const GValue val = *value;
    float knownComponent = g_value_get_float(&val);

    //If this is a relative transformation, make the base value zeros
    if (relativeKeyFlags[std::distance(values.begin(), value)])
    {
      vec = Vector2(0,0);
    }


    if (isY)
    {
      vec.y = knownComponent;
    }
    else
    {
      vec.x = knownComponent;
    }

    ClutterPoint point = {(float)vec.x, (float)vec.y};

    GValue fullPoint = G_VALUE_INIT;
    g_value_init(&fullPoint, CLUTTER_TYPE_POINT);
    g_value_set_boxed(&fullPoint, &point);
    vectorKeys.push_back(fullPoint);
  }

  return createTransition(property, false, vectorKeys, actor, Vector2D);
}

