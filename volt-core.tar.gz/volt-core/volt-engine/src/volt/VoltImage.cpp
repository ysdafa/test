/*
 * VoltImage.cpp
 *
 *  Created on: July 29, 2013
 *      Author: jim dinunzio
 */

#define CLUTTER_ENABLE_EXPERIMENTAL_API
#define COGL_ENABLE_EXPERIMENTAL_API

#include "VoltImage.h"
#include "VoltActor.h"
#include <cogl/cogl.h>
#include <clutter/clutter.h>
#include <glib/gi18n.h>
#include "VoltConfig.h"
 //@Render_Thread Added for memcpy 
#include <stdlib.h>
#include <cstring>
#include "logger.h"

static const char* LOGGER_NAME = "volt.image";
static volt::util::Logger logger(LOGGER_NAME);

/**
 * SECTION:volt-image
 * @Title: VoltImage
 * @Short_Description: Image data content
 *
 * #VoltImage is a #ClutterContent implementation that displays
 * image data.
 *
 */
 
 /**
 * Modified Private Structure for supporting creating cogl texture at the time 
 * of invalidate state of VoltImage.(We can't use CoglTexture function from cpu side
 * ).
 * Added cpu buffer for saving user bytes.
 */

struct _VoltImagePrivate
{
  CoglTexture       *texture;
  GdkPixbufAnimation  * pixbufAnim;
  GdkPixbuf       * pixbufData;
  ClutterContent    *copy_content;
  VoltImageDataInfo   data;
  gboolean        invalidate;
  gboolean        useSubArea;
  float         area_x;
  float         area_y;
  
  VoltImage    **texture_source;
  bool         borrow_texture;
  bool         subtexture_is_set;

  bool          useSubtexture;
  float         subtexture_x1;
  float         subtexture_y1;
  float         subtexture_x2;
  float         subtexture_y2;


};

static void volt_image_iface_init (ClutterContentIface *iface);

G_DEFINE_TYPE_WITH_CODE (VoltImage, volt_image, G_TYPE_OBJECT,
                         G_IMPLEMENT_INTERFACE(CLUTTER_TYPE_CONTENT,
                             volt_image_iface_init))


/* macro for accessing the object's private structure */
#define VOLT_IMAGE_TYPE_GET_PRIVATE(obj) \
  (G_TYPE_INSTANCE_GET_PRIVATE ((obj), VOLT_TYPE_IMAGE, VoltImagePrivate))

GQuark
volt_image_error_quark (void)
{
  return g_quark_from_static_string ("volt-image-error-quark");
}

static void
volt_image_dispose(GObject* gobject)
{
  VoltImagePrivate* priv = VOLT_IMAGE (gobject)->priv;

  //@Render_Thread if the copy_content field is NULL, then the priv is from the copied actor
  bool is_copy = priv->copy_content == NULL;

  //@Render_Thread Added for unref cpu buffer data (refs are added from both threads)
   if (priv->data.bytes != NULL)
   {
  g_bytes_unref(priv->data.bytes);
  priv->data.bytes  = NULL;
   }

  //@Render_Thread Added for unref texture if it's instance of copy content
  if (is_copy)
  {
    if (priv->texture != NULL)
    {
      LOG_DEBUG(logger,"Unref texture from copy: 0x" << std::hex << priv->texture);
      cogl_object_unref (priv->texture);  // (priv->texture is only ever allocated in render thread)
      priv->texture = NULL;
    }
  }
  //@Render_Thread Added for unref pixbuf if it's not instance of copy content
  if (!is_copy && priv->pixbufAnim != NULL)
  {
    g_clear_object(&priv->pixbufAnim);
  }
  
  if (priv->pixbufData != NULL)
  {
    g_object_unref(priv->pixbufData);
    priv->pixbufData = NULL;
  }

  /* call the parent class' dispose() method */
  G_OBJECT_CLASS (volt_image_parent_class)->dispose (gobject);
}

static void
volt_image_finalize (GObject *gobject)
{
  /* call the parent class' finalize() method */
  G_OBJECT_CLASS (volt_image_parent_class)->finalize (gobject);
}

static void
volt_image_class_init (VoltImageClass *klass)
{
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  gobject_class->dispose = volt_image_dispose;
  gobject_class->finalize = volt_image_finalize;
  g_type_class_add_private (klass, sizeof (VoltImagePrivate));
}

static void
volt_image_init (VoltImage *self)
{
  VoltImagePrivate *priv;

  priv = self->priv = VOLT_IMAGE_TYPE_GET_PRIVATE (self);
  priv->texture = NULL;
  priv->pixbufAnim = NULL;
  priv->pixbufData = NULL;
  priv->copy_content = NULL;

  priv->data.bytes = NULL;
  priv->data.pixel_format = COGL_PIXEL_FORMAT_ANY;
  priv->data.width = 0;
  priv->data.height = 0;
  priv->data.row_stride = 0;
  priv->data.flags = COGL_TEXTURE_NONE;
  priv->texture_source = NULL;
  priv->borrow_texture = FALSE;
  priv->subtexture_is_set = FALSE;
  priv->invalidate = FALSE;
  priv->useSubArea = false;
  priv->area_x = 0.0f;
  priv->area_y = 0.0f;

  priv->useSubtexture = false;
  priv->subtexture_x1 = 0;
  priv->subtexture_y1 = 0;
  priv->subtexture_x2 = 0;
  priv->subtexture_y2 = 0;
}

static ClutterPaintNode*
volt_image_new_texture_node(ClutterContent   *content,
                            ClutterActor     *actor)
{
  VoltImagePrivate *priv = VOLT_IMAGE (content)->priv;
  ClutterScalingFilter min_f, mag_f;
  ClutterPaintNode *node = NULL;

  if (priv->texture == NULL)
  {
    return NULL;
  }

  clutter_actor_get_content_scaling_filters (actor, &min_f, &mag_f);

  ClutterColor color;
  color.red = 255;
  color.green = 255;
  color.blue = 255;
  color.alpha = clutter_actor_get_paint_opacity (actor);

  node = clutter_texture_node_new (priv->texture, &color, min_f, mag_f);

  clutter_paint_node_set_name (node, "Image");

  return node;
}


static void
volt_clutter_color_premultiply(ClutterColor *color)
{
  color->red = (color->red * color->alpha + 128) / 255; 
  color->green = (color->green * color->alpha + 128) / 255;
  color->blue = (color->blue* color->alpha + 128) / 255;
}

static void
volt_image_paint_content_with_gradient(VoltActor *actor, ClutterPaintNode *node,
                                       ClutterActorBox *box, ClutterActorBox *content_coord_box)
{
  ClutterColor tlColor,trColor,blColor,brColor;
  volt_actor_get_grad_tl_color(actor, &tlColor);
  volt_actor_get_grad_tr_color(actor, &trColor);
  volt_actor_get_grad_bl_color(actor, &blColor);
  volt_actor_get_grad_br_color(actor, &brColor);

  gfloat opacity = clutter_actor_get_paint_opacity (CLUTTER_ACTOR(actor));

  tlColor.alpha = (tlColor.alpha * opacity + 128) / 255;
  trColor.alpha = (trColor.alpha * opacity + 128) / 255;
  blColor.alpha = (blColor.alpha * opacity + 128) / 255;
  brColor.alpha = (blColor.alpha * opacity + 128) / 255;

  volt_clutter_color_premultiply(&tlColor);
  volt_clutter_color_premultiply(&trColor);
  volt_clutter_color_premultiply(&blColor);
  volt_clutter_color_premultiply(&brColor);

  CoglVertexP3T2C4 vertices[4];

  /* now describe the four vertices of the quad with gradient
   */
  vertices[0].x = box->x1; vertices[0].y = box->y1; vertices[0].z = 0;
  vertices[0].s = content_coord_box->x1; vertices[0].t = content_coord_box->y1;
  vertices[0].r = tlColor.red;
  vertices[0].g = tlColor.green;
  vertices[0].b = tlColor.blue;
  vertices[0].a = tlColor.alpha;

  vertices[1].x = box->x2; vertices[1].y = box->y1; vertices[1].z = 0;
  vertices[1].s = content_coord_box->x2; vertices[1].t = content_coord_box->y1;
  vertices[1].r = trColor.red;
  vertices[1].g = trColor.green;
  vertices[1].b = trColor.blue;
  vertices[1].a = trColor.alpha;

  vertices[2].x = box->x1; vertices[2].y = box->y2; vertices[2].z = 0;
  vertices[2].s = content_coord_box->x1; vertices[2].t = content_coord_box->y2;
  vertices[2].r = blColor.red;
  vertices[2].g = blColor.green;
  vertices[2].b = blColor.blue;
  vertices[2].a = blColor.alpha;

  vertices[3].x = box->x2; vertices[3].y = box->y2; vertices[3].z = 0;
  vertices[3].s = content_coord_box->x2; vertices[3].t = content_coord_box->y2;
  vertices[3].r = brColor.red;
  vertices[3].g = brColor.green;
  vertices[3].b = brColor.blue;
  vertices[3].a = brColor.alpha;

  CoglContext *ctx =
    clutter_backend_get_cogl_context (clutter_get_default_backend ());

  CoglPrimitive* quad = cogl_primitive_new_p3t2c4(ctx,
                                                  COGL_VERTICES_MODE_TRIANGLE_STRIP,
                                                  4,
                                                  vertices);

  clutter_paint_node_add_primitive(node, quad);
  cogl_object_unref(quad);
}


// This is a copy of clutter_image_paint_content from clutter-image.c v1-14.2
static void
volt_image_paint_content_common (ClutterContent   *content,
                                 ClutterActor     *actor,
                                 ClutterPaintNode *parent)
{
  VoltImagePrivate *priv = VOLT_IMAGE (content)->priv;
  ClutterContentRepeat repeat;
  ClutterPaintNode *node = NULL;
  ClutterActorBox box,content_coord_box;
  /** @Render_Thread Added for Creating Cogl Texture from cpu data byte when state
  * is set to invalidate also added suppor for using SubArea and SubTextureing
  */
  if( priv->invalidate == TRUE )
  {
    if (priv->texture != NULL)
    {
    cogl_object_unref (priv->texture);
    priv->texture = NULL;
    }
  
    if (priv->data.bytes != NULL)
    {
      priv->texture = cogl_texture_new_from_data  (priv->data.width, priv->data.height,
                          priv->data.flags,
                          priv->data.pixel_format,
                          COGL_PIXEL_FORMAT_ANY,
                          priv->data.row_stride,
                          (guint8*)g_bytes_get_data(priv->data.bytes, NULL));
     
    }
    else if(priv->pixbufData != NULL)
    {
      guint8* data = (guint8*)gdk_pixbuf_get_pixels (priv->pixbufData);
     
      priv->texture = cogl_texture_new_from_data (priv->data.width, priv->data.height,
                                                  priv->data.flags,
                                                  priv->data.pixel_format,
                                                  COGL_PIXEL_FORMAT_ANY,
                                                  priv->data.row_stride,
                                                  (data));
                           
     
    }
  
    priv->invalidate = FALSE;
  }
 
  if (priv->useSubArea == TRUE)
  {
    if (priv->data.bytes != NULL)
    {
      if (priv->texture == NULL)
      {
        gconstpointer pixels = g_bytes_get_data(priv->data.bytes, NULL);
        priv->texture = cogl_texture_new_from_data (priv->data.width, priv->data.height,
                                           priv->data.flags,
                                           priv->data.pixel_format,
                          COGL_PIXEL_FORMAT_ANY,
                                           priv->data.row_stride,
                                           (guint8*)pixels);
        LOG_DEBUG(logger,"Created texture: 0x" << std::hex << priv->texture);
      }
      else
      {
        cogl_texture_set_region(priv->texture, 0, 0,
                          priv->area_x, priv->area_y,
                          priv->data.width,priv->data.height,
                          priv->data.width,priv->data.height,
                          priv->data.pixel_format,
                          priv->data.row_stride,
                          (guint8*)g_bytes_get_data(priv->data.bytes, NULL));
      }
      priv->useSubArea = FALSE;
    }
  }

  //If we have a texture source set, we should share that texture
  if (priv->texture_source != NULL && priv->borrow_texture)
  {
      CoglTexture *targetTexture = volt_image_get_texture( *(priv->texture_source) );
      if(priv->texture != targetTexture)
      {
        //Set to share texture, aquire a ref on it.
        if (priv->texture != NULL)
        {
          cogl_object_unref (priv->texture);
        }

        priv->texture = targetTexture;
        cogl_object_ref(targetTexture);
      }
  }

  //Set subtexture regions
  if (priv->subtexture_is_set == true && priv->texture != NULL)
  {
    float width  = cogl_texture_get_width (priv->texture);
    float height = cogl_texture_get_height (priv->texture);

    priv->subtexture_x1 /= width ;
    priv->subtexture_y1 /= height ;
    priv->subtexture_x2 /= width ;
    priv->subtexture_y2 /= height ;

    priv->subtexture_is_set = false;
  }

  // if(priv->useSubtexture == true && priv->texture != NULL)
  // {
  //   float width  = cogl_texture_get_width (priv->texture);
  //   float height = cogl_texture_get_height (priv->texture);
  //   priv->subtexture_x1 /= width ;
  //   priv->subtexture_y1 /= height ;
  //   priv->subtexture_x2  /= width ;
  //   priv->subtexture_y2 /= height ;
  //   priv->useSubtexture = false;
  // }
 

  if (priv->texture == NULL)
  {
    return;
  }

  clutter_actor_get_content_box (actor, &box);

  clutter_actor_box_init(&content_coord_box,0.0,0.0,1.0,1.0);

#if defined(TIZEN)
  ClutterActorBox allocation;
  gfloat actorWidth, actorHeight;

  clutter_actor_get_allocation_box (actor, &allocation);
  clutter_actor_box_get_size (&allocation, &actorWidth, &actorHeight);
  ClutterContentGravity content_gravity;
  content_gravity = clutter_actor_get_content_gravity(actor);
  if (content_gravity >= CLUTTER_CONTENT_GRAVITY_VERTICAL_RESIZE_ASPECT &&
      content_gravity <= CLUTTER_CONTENT_GRAVITY_BOTTOM_RIGHT_CROP)
  {
    guint texture_width = cogl_texture_get_width (priv->texture);
    guint texture_height = cogl_texture_get_height (priv->texture);
    clutter_actor_get_image_cropped_coord (actor, actorWidth, actorHeight, 
                                           texture_width, 
                                           texture_height,
                                           &content_coord_box);
  }
#endif

  node = volt_image_new_texture_node(content, actor);

  repeat = clutter_actor_get_content_repeat (actor);

  if (repeat == CLUTTER_REPEAT_NONE)
  {
    if (priv->useSubtexture)
    {
      clutter_paint_node_add_texture_rectangle (node, &box,
          priv->subtexture_x1, priv->subtexture_y1,
          priv->subtexture_x2, priv->subtexture_y2);
    }
    else
    {
      if (volt_actor_get_gradient_fill(VOLT_ACTOR(actor)))
      {
        volt_image_paint_content_with_gradient(VOLT_ACTOR(actor), node, &box, &content_coord_box);
      }
      else
      {
        clutter_paint_node_add_texture_rectangle (node, &box,
                            content_coord_box.x1,
                            content_coord_box.y1,
                            content_coord_box.x2,
                            content_coord_box.y2);
      }
    }
  }
  else
  {
    float t_w = 1.f, t_h = 1.f;

    if ((repeat & CLUTTER_REPEAT_X_AXIS) != FALSE)
    {
      t_w = (box.x2 - box.x1) / cogl_texture_get_width (priv->texture);
    }

    if ((repeat & CLUTTER_REPEAT_Y_AXIS) != FALSE)
    {
      t_h = (box.y2 - box.y1) / cogl_texture_get_height (priv->texture);
    }

    clutter_paint_node_add_texture_rectangle (node, &box,
        0.f, 0.f,
        t_w, t_h);
  }

  clutter_paint_node_add_child (parent, node);
  clutter_paint_node_unref (node);
}


static ClutterPaintNode*
volt_image_add_rounded_corners_node(ClutterActor     *actor,
                                    ClutterPaintNode *parent,
                                    gfloat x, gfloat y,
                                    gfloat width, gfloat height)
{
  VoltActor* voltActor = VOLT_ACTOR(actor);
  ClutterPaintNode *node = clutter_clip_node_new();
  clutter_paint_node_set_name(node, "RoundedCornersClip");

  CoglPath* path = NULL;
  cogl_path_new();

  if(volt_actor_has_custom_corner(voltActor))
  {
    volt_actor_custom_rounded_rect(voltActor, x, y, x + width, y + height, 0, false);
  }
  // use standard rounded corners
  else
  {
    cogl_path_round_rectangle (x, y, x + width, y + height,
                               volt_actor_get_rc_radius(voltActor, VOLT_ACTOR_PROP_RC_RADIUS),
                               volt_actor_get_rc_arc_step(voltActor, VOLT_ACTOR_PROP_RC_ARC_STEP));
  }

  path = cogl_get_path();
  clutter_paint_node_add_path(node, path);
  clutter_paint_node_add_child (parent, node);
  clutter_paint_node_unref (node);

  return node;
}

/**
 * volt_image_paint_content:
 *
 * Paints the texture of the #VoltImage
 *
 */
static void
volt_image_paint_content (ClutterContent   *content,
                          ClutterActor     *actor,
                          ClutterPaintNode *root)
{
  VoltActor* voltActor = VOLT_ACTOR(actor);
  ClutterPaintNode *node = NULL;
  gfloat width, height;
  gboolean hasRoundedCorners = voltActor && volt_actor_get_rounded_corners(voltActor);
  ClutterActorBox allocation = { 0, };

  // if the actor is a VoltActor and the rounded rect property is true, then
  // add rounded rect clipping node to render graph and the gradient as its child
  /*
  if (hasRoundedCorners)
  {
    node = clutter_clip_node_new();
    clutter_paint_node_set_name(node, "Clip");
*/
    clutter_actor_get_allocation_box (actor, &allocation);
    clutter_actor_box_get_size (&allocation, &width, &height);

  node = root;
  if (hasRoundedCorners)
  {
    node = volt_image_add_rounded_corners_node(actor, root, 0, 0, width, height);
  }

  // if the actor is a VoltActor and the rounded rect property is true, then
  // add rounded rect clipping node to render graph and the gradient as its child
  volt_image_paint_content_common(content, actor, node);
}

static gboolean
volt_image_get_preferred_size (ClutterContent *content,
                               gfloat         *width,
                               gfloat         *height)
{
  VoltImagePrivate *priv = VOLT_IMAGE (content)->priv;
    //@Render_Thread Added for Getting width and height from cpu buffer
  if(priv->data.bytes == NULL)
  {
    return FALSE;
  }

  if (width != NULL)
  {
    *width = priv->data.width;
  }

  if (height != NULL)
  {
    *height = priv->data.height;
  }

  return TRUE;
}

//@Render_Thread Added for Copying Image
void
volt_image_copy_content(ClutterContent* srcContent, ClutterContent* destContent)
{
  VoltImage * src_Image = VOLT_IMAGE(srcContent);
  VoltImage * dest_Image = VOLT_IMAGE(destContent);
  
  
  if (dest_Image->priv->data.bytes != src_Image->priv->data.bytes)
  {
    if (dest_Image->priv->data.bytes != NULL)
    {
      g_bytes_unref(dest_Image->priv->data.bytes);
    }
    if (src_Image->priv->data.bytes != NULL)
    {
      g_bytes_ref(src_Image->priv->data.bytes);
    }

    dest_Image->priv->data.bytes = src_Image->priv->data.bytes;
    
  }
  
  if (dest_Image->priv->pixbufData != src_Image->priv->pixbufData)
  {
    if (dest_Image->priv->pixbufData != NULL)
    {
      g_object_unref(dest_Image->priv->pixbufData);
    }
    
    dest_Image->priv->pixbufData = src_Image->priv->pixbufData;
    
    if (dest_Image->priv->pixbufData != NULL)
    {
      g_object_ref(dest_Image->priv->pixbufData);
    }
    
  }
  
  
  dest_Image->priv->data.height = src_Image->priv->data.height;
  dest_Image->priv->data.width = src_Image->priv->data.width;
  dest_Image->priv->data.pixel_format = src_Image->priv->data.pixel_format;
  dest_Image->priv->data.row_stride = src_Image->priv->data.row_stride;
  dest_Image->priv->data.flags         = src_Image->priv->data.flags;


  //Texture source should be null unless we are sharing textures with other
  //VoltImages (like in NinePatchWidget)
  dest_Image->priv->texture_source = src_Image->priv->texture_source;
  dest_Image->priv->borrow_texture = src_Image->priv->borrow_texture;

  //If we have a non-null texture source and are not a borrower, then we must BE the texture
  //source. Assign self pointer to texture_source.
  if(dest_Image->priv->texture_source != NULL && !dest_Image->priv->borrow_texture) 
  {
    *(dest_Image->priv->texture_source) = dest_Image;
  }


  if(!dest_Image->priv->invalidate)
  {
    dest_Image->priv->invalidate  =  src_Image->priv->invalidate;
  }
  if(!dest_Image->priv->useSubArea)
  {
    dest_Image->priv->useSubArea  =  src_Image->priv->useSubArea;
  }
  // if(!dest_Image->priv->useSubtexture)
  // {
  dest_Image->priv->useSubtexture   =  src_Image->priv->useSubtexture;
  //}
  
  //dest_Image->priv->useSubtexture   =  FALSE;
  src_Image->priv->invalidate   = FALSE;
  src_Image->priv->useSubArea   = FALSE;

  if(src_Image->priv->subtexture_is_set)
  {
    dest_Image->priv->subtexture_is_set = src_Image->priv->subtexture_is_set;
    
    dest_Image->priv->subtexture_x1 =  src_Image->priv->subtexture_x1;
    dest_Image->priv->subtexture_y1 =  src_Image->priv->subtexture_y1;
    dest_Image->priv->subtexture_x2 = src_Image->priv->subtexture_x2;
    dest_Image->priv->subtexture_y2 = src_Image->priv->subtexture_y2;

    src_Image->priv->subtexture_is_set = false;
  }
}

ClutterContent *
volt_image_clone_content(ClutterContent* src_content)
{
  VoltImage* src_image = VOLT_IMAGE(src_content);

  if(src_image->priv->copy_content == NULL)
  {
    src_image->priv->copy_content = volt_image_new();
  }
  volt_image_copy_content(src_content, src_image->priv->copy_content);

  return src_image->priv->copy_content;
}

static void
volt_image_iface_init (ClutterContentIface *iface)
{
  iface->get_preferred_size = volt_image_get_preferred_size;
  iface->paint_content = volt_image_paint_content;
  //@Render_Thread Added for using virtual clone_content function of Interface
  // ClutterContent
  iface->clone_for_render_thread = volt_image_clone_content;
}


/**
 * volt_image_new:
 *
 * Creates a new #VoltImage instance.
 *
 * Return value: (transfer full): the newly created #VoltImage instance.
 *   Use g_object_unref() when done.
 *
 */
ClutterContent*
volt_image_new (void)
{
  return CLUTTER_CONTENT(g_object_new (VOLT_TYPE_IMAGE, NULL));
}

/**
 * Returns the GdkPixbufAnimation instance which is used for animated images.
 *
 * @author jim
 *
 * @param self The VoltImage pointer
 *
 * @return GdkPixbufAnimation* the GdkPixbufAnimation valid only if image is animated.
 */
GdkPixbufAnimation*
volt_image_get_pixbuf_anim(VoltImage *self)
{
  g_return_val_if_fail (VOLT_IS_IMAGE(self), NULL);
  VoltImagePrivate *priv = VOLT_IMAGE_TYPE_GET_PRIVATE(self);
  return priv->pixbufAnim;
}

/**
 * Sets the GdkPixbufAnimation pointer which is used for animated images.
 *
 * @author jim
 *
 * @param self The VoltImage pointer
 * @param pixbufAnim The pointer to the GdkPixbufAnimation for the animated image
 */
void
volt_image_set_pixbuf_anim(VoltImage *self, GdkPixbufAnimation* pixbufAnim)
{
  g_return_if_fail (VOLT_IS_IMAGE(self));
  VoltImagePrivate *priv = VOLT_IMAGE_TYPE_GET_PRIVATE(self);

  if (priv->pixbufAnim != pixbufAnim)
  {
    if (priv->pixbufAnim)
    {
      g_object_unref(priv->pixbufAnim);
    }

    priv->pixbufAnim = pixbufAnim;

    if (priv->pixbufAnim)
    {
      g_object_ref(priv->pixbufAnim);
    }
  }
}


gboolean
volt_image_set_pixbuf_data ( VoltImage        *image,
               GdkPixbuf    *pixbufData,
               CoglTextureFlags  flags,
               CoglPixelFormat   pixel_format,
               guint             width,
               guint             height,
               guint             row_stride,
               GError          **error)
{
  g_return_val_if_fail (VOLT_IS_IMAGE (image), FALSE);
  g_return_val_if_fail (pixbufData != NULL, FALSE);
   VoltImagePrivate *priv;

  priv = image->priv;
  /**@Render_Thread Added for Supporting cpu data functionality
  *
  */  
  
 if (priv->pixbufData != pixbufData)
  {
    if(priv->pixbufData)
    {
      g_object_unref(priv->pixbufData);
    }
    priv->pixbufData       = pixbufData;
    priv->data.width = width;
    priv->data.height = height;
    priv->data.row_stride = row_stride;
    priv->data.pixel_format = pixel_format;
    priv->data.flags = flags;
   
    priv->invalidate = TRUE;
    
    g_object_ref(priv->pixbufData);
    
    clutter_content_invalidate (CLUTTER_CONTENT (image));
  }

  return TRUE;
}

/**
 * volt_image_set_data:
 * @image: a #VoltImage
 * @data: (array): the image data, as an array of bytes
 * @pixel_format: the Cogl pixel format of the image data
 * @width: the width of the image data
 * @height: the height of the image data
 * @row_stride: the length of each row inside @data
 * @error: return location for a #GError, or %NULL
 *
 * Sets the image data to be displayed by @image.
 *
 * If the image data was successfully loaded, the @image will be invalidated.
 *
 * In case of error, the @error value will be set, and this function will
 * return %FALSE.
 *
 * The image data is copied in texture memory.
 *
 * Return value: %TRUE if the image data was successfully loaded,
 *   and %FALSE otherwise.
 *
 * Since: 1.10
 */
gboolean
volt_image_set_data (VoltImage     *image,
                     const guint8     *data,
                     CoglTextureFlags  flags,
                     CoglPixelFormat   pixel_format,
                     guint             width,
                     guint             height,
                     guint             row_stride,
                     GError          **error)
{
  g_return_val_if_fail (VOLT_IS_IMAGE (image), FALSE);
  g_return_val_if_fail (data != NULL, FALSE);

  VoltImagePrivate *priv;

  priv = image->priv;
  /**@Render_Thread Added for Supporting cpu data functionality
  *
  */  
  
  if (priv->data.bytes != NULL)
  {
    g_bytes_unref(priv->data.bytes);
  }
  
  priv->data.bytes = g_bytes_new(data, height*row_stride*sizeof(guint8));
  priv->data.width = width;
  priv->data.height = height;
  priv->data.row_stride = row_stride;
  priv->data.pixel_format = pixel_format;
  priv->data.flags = flags;
 
  priv->invalidate = TRUE;

  clutter_content_invalidate (CLUTTER_CONTENT (image));

  return TRUE;
}

/**
 * volt_image_set_bytes:
 * @image: a #VoltImage
 * @data: the image data, as a #GBytes
 * @pixel_format: the Cogl pixel format of the image data
 * @width: the width of the image data
 * @height: the height of the image data
 * @row_stride: the length of each row inside @data
 * @error: return location for a #GError, or %NULL
 *
 * Sets the image data stored inside a #GBytes to be displayed by @image.
 *
 * If the image data was successfully loaded, the @image will be invalidated.
 *
 * In case of error, the @error value will be set, and this function will
 * return %FALSE.
 *
 * The image data contained inside the #GBytes is copied in texture memory,
 * and no additional reference is acquired on the @data.
 *
 * Return value: %TRUE if the image data was successfully loaded,
 *   and %FALSE otherwise.
 *
 * Since: 1.12
 */
gboolean
volt_image_set_bytes (VoltImage     *image,
                      GBytes           *data,
                      CoglTextureFlags  flags,
                      CoglPixelFormat   pixel_format,
                      guint             width,
                      guint             height,
                      guint             row_stride,
                      GError          **error)
{
  VoltImagePrivate *priv;

  g_return_val_if_fail (VOLT_IS_IMAGE (image), FALSE);
  g_return_val_if_fail (data != NULL, FALSE);

  priv = image->priv;
  
   /**@Render_Thread Added for Supporting cpu data functionality
  *
  */
  if (priv->data.bytes != NULL)
  {
    g_bytes_unref(priv->data.bytes);
  }
  
  priv->data.bytes = g_bytes_new(g_bytes_get_data (data, NULL), height*row_stride*sizeof(guint8));
  priv->data.width = width;
  priv->data.height = height;
  priv->data.row_stride = row_stride;
  priv->data.pixel_format = pixel_format;
  priv->data.flags = flags;
 
  priv->invalidate = TRUE;

  clutter_content_invalidate (CLUTTER_CONTENT (image));

  return TRUE;
}

/**
 * volt_image_set_area:
 * @image: a #VoltImage
 * @data: (array): the image data, as an array of bytes
 * @pixel_format: the Cogl pixel format of the image data
 * @rect: a rectangle indicating the area that should be set
 * @row_stride: the length of each row inside @data
 * @error: return location for a #GError, or %NULL
 *
 * Sets the image data to be display by @image, using @rect to indicate
 * the position and size of the image data to be set.
 *
 * If the @image does not have any image data set when this function is
 * called, a new texture will be created with the size of the width and
 * height of the rectangle, i.e. calling this function on a newly created
 * #VoltImage will be the equivalent of calling volt_image_set_data().
 *
 * If the image data was successfully loaded, the @image will be invalidated.
 *
 * In case of error, the @error value will be set, and this function will
 * return %FALSE.
 *
 * The image data is copied in texture memory.
 *
 * Return value: %TRUE if the image data was successfully loaded,
 *   and %FALSE otherwise.
 *
 * Since: 1.10
 */
gboolean
volt_image_set_area (VoltImage                 *image,
                     const guint8                 *data,
                     CoglTextureFlags              flags,
                     CoglPixelFormat               pixel_format,
                     const cairo_rectangle_int_t  *area,
                     guint                         row_stride,
                     GError                      **error)
{
  VoltImagePrivate *priv;

  g_return_val_if_fail (VOLT_IS_IMAGE (image), FALSE);
  g_return_val_if_fail (data != NULL, FALSE);
  g_return_val_if_fail (area != NULL, FALSE);

  priv = image->priv;

  LOG_DEBUG(logger,"creating image area from data 0x" << std::hex << (void*)data);
  if (priv->data.bytes != NULL)
  {
    g_bytes_unref(priv->data.bytes);
  }

  priv->data.bytes = g_bytes_new(data, (area->height)*row_stride*sizeof(guint8));
  priv->area_x = area->x;
  priv->area_y = area->y;
    priv->data.width = area->width;
    priv->data.height = area->height;
    priv->data.row_stride = row_stride;
    priv->data.pixel_format = pixel_format;
  priv->data.flags = flags;
    priv->useSubArea = TRUE;

  clutter_content_invalidate (CLUTTER_CONTENT (image));

  return TRUE;
}

/**
 * Sets a VoltImage to share a texture from another VoltImage.
 * If is_owner is true, must make your texture available via
 * texture_source pointer. If not owner, use the texture pointed
 * pointed to by texture_source.
 *
 * @author Reza
 *
 * @param self The VoltImage pointer
 *
 * @param texture The CoglTexture to set
 *
 * @return The texture used by this image
 */
void
volt_image_set_texture_share  (VoltImage  *self,
                                VoltImage  **texture_source,
                                gboolean       is_owner)
{
  VoltImagePrivate *priv;

  g_return_if_fail (VOLT_IS_IMAGE (self));

  priv = self->priv;

  priv->borrow_texture = !is_owner;
  priv->texture_source = texture_source;

  clutter_content_invalidate (CLUTTER_CONTENT (self));
}

void
volt_image_set_texture  (VoltImage  *self,
                         CoglTexture *texture)
{
  VoltImagePrivate *priv;

  g_return_if_fail (VOLT_IS_IMAGE (self));
  g_return_if_fail (cogl_is_texture (texture));

  priv = self->priv;

  if (priv->texture != NULL)
  {
    cogl_object_unref (priv->texture);
  }

  priv->texture = texture;
  cogl_object_ref(texture);
  clutter_content_invalidate (CLUTTER_CONTENT (self));
}


/**
 * Returns the CoglTexture instance used for this image.
 *
 * @author jim
 *
 * @param self The VoltImage pointer
 *
 * @return The texture used by this image
 */
CoglTexture *
volt_image_get_texture(VoltImage *self)
{
  g_return_val_if_fail (VOLT_IS_IMAGE (self), FALSE);

  VoltImagePrivate *priv = VOLT_IMAGE_TYPE_GET_PRIVATE(self);
  return priv->texture;
}


/**
 * Returns the CoglTexture instance used for this image.
 *
 * @author Reza
 *
 * @return Sets this VoltImage to use only a portion of the
 */
void
volt_image_set_subtexture_rectangle  (VoltImage                 *self,
                                      float                      x1,
                                      float                      y1,
                                      float                      x2,
                                      float                      y2 )
{
  g_return_if_fail (VOLT_IS_IMAGE (self));

  VoltImagePrivate *priv = self->priv;

  //flag to tell paint routine to update these vars once
  priv->subtexture_is_set = true;

  priv->useSubtexture = true;
  priv->subtexture_x1 = x1;
  priv->subtexture_y1 = y1;
  priv->subtexture_x2 =  x2;
  priv->subtexture_y2 =  y2;

  clutter_content_invalidate (CLUTTER_CONTENT (self));
}

void
volt_image_get_image_data(VoltImage *self, VoltImageDataInfo* info)
{
  g_return_if_fail (VOLT_IS_IMAGE (self));

  VoltImagePrivate *priv = self->priv;

  *info = { 0 };
  if (priv->data.bytes != NULL)
  {
    *info = priv->data;
  }
  else if (priv->pixbufData != NULL)
  {
    *info = priv->data;
    info->bytes = (GBytes*)gdk_pixbuf_get_pixels (priv->pixbufData);
  } 
}

