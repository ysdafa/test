/*
 * BrightnessContrastEffect.cpp
 *
 *  Created on: Aug 6, 2013
 *      Author: Jim DiNunzio
 */

#include "VoltActor.h"
#include "BrightnessContrastEffect.h"

namespace volt
{
namespace graphics
{
const char* BrightnessContrastEffect::BRIGHTNESS_TRANSITION_NAME = "brightContr-brightness";
const char* BrightnessContrastEffect::CONTRAST_TRANSITION_NAME = "brightContr-contrast";

#define EFFECT_NAME_DEF "bright-contr-effect"

const char* BrightnessContrastEffect::EFFECT_NAME = EFFECT_NAME_DEF;

#define GET_EFFECT (CLUTTER_BRIGHTNESS_CONTRAST_EFFECT(getEffect()))
#define CLUTTER_BRIGHTNESS_CONTRAST_EFFECT_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), CLUTTER_TYPE_BRIGHTNESS_CONTRAST_EFFECT, ClutterBrightnessContrastEffectClass))

BrightnessContrastEffect::BrightnessContrastEffect()
{
  setEffect(clutter_brightness_contrast_effect_new());
}


BrightnessContrastEffect::~BrightnessContrastEffect()
{
}

void BrightnessContrastEffect::setBrightness(float brightness)
{
  // if no animation necessary, just set value, otherwise create implicit transition.
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (getEffect()));

  if (clutter_actor_get_easing_duration(actor) == 0)
  {
    clutter_brightness_contrast_effect_set_brightness(GET_EFFECT, brightness);
    return;
  }

  const char *prop = "@effects." EFFECT_NAME_DEF ".brightness";

  GParamSpec* spec = g_object_class_find_property(
                       G_OBJECT_CLASS(CLUTTER_BRIGHTNESS_CONTRAST_EFFECT_GET_CLASS(getEffect())),
                       "brightness");

  guint8 from = (getBrightness() + 1.0f) * 127.0f;

  ClutterColor fromColor = {from, from, from, 255};

  guint8 to = (brightness + 1.0f) * 127.0f;

  ClutterColor toColor = {to ,to, to, 255};

  volt_actor_create_transition (VOLT_ACTOR(actor),
                                prop,
                                BRIGHTNESS_TRANSITION_NAME,
                                spec,
                                &fromColor,
                                &toColor);
}


float BrightnessContrastEffect::getBrightness() const
{
  float brightness;
  clutter_brightness_contrast_effect_get_brightness(GET_EFFECT, &brightness, NULL, NULL);
  return brightness;
}


void BrightnessContrastEffect::setContrast(float contrast)
{
  // if no animation necessary, just set value, otherwise create implicit transition.
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (getEffect()));

  if (clutter_actor_get_easing_duration(actor) == 0)
  {
    clutter_brightness_contrast_effect_set_contrast(GET_EFFECT, contrast);
    return;
  }

  const char *prop = "@effects." EFFECT_NAME_DEF ".contrast";

  GParamSpec* spec = g_object_class_find_property(
                       G_OBJECT_CLASS(CLUTTER_BRIGHTNESS_CONTRAST_EFFECT_GET_CLASS(getEffect())),
                       "contrast");

  guint8 from = (getContrast() + 1.0f) * 127.0f;

  ClutterColor fromColor = {from, from, from, 255};

  guint8 to = (contrast + 1.0f) * 127.0f;

  ClutterColor toColor = {to ,to, to, 255};

  volt_actor_create_transition (VOLT_ACTOR(actor),
                                prop,
                                CONTRAST_TRANSITION_NAME,
                                spec,
                                &fromColor,
                                &toColor);
}


float BrightnessContrastEffect::getContrast() const
{
  float contrast;
  clutter_brightness_contrast_effect_get_contrast(GET_EFFECT, &contrast, NULL, NULL);
  return contrast;
}
}
}
