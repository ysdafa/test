#include <stdio.h>
#include <stdlib.h>
#include <sharedvc.h>
#include <dbg.h>
#include <vconf.h>
#include <sys/prctl.h>

#ifndef PR_TASK_PERF_USER_TRACE
#define PR_TASK_PERF_USER_TRACE 666
#endif

//const char *lic_key="db/menu/smart_hub/homedatacontrol/defaultdisclaimeragree";

int main(int argc, char **argv)
{
	int i = 0;
	int autostart = 0;
	int autostartVal = 0;
	prctl(PR_TASK_PERF_USER_TRACE, "-------------------------main() start-------------------------", strlen("-------------------------main() start-------------------------"));
	
	if (argc > 0)
	{
		for (i=0;i<argc;i++)
		{
			if (strcmp(argv[i], "autostart") == 0)
			{
				autostart = 1;
				break;
			}
		}
	}
	
/*	int lic_val=0;
	LOGE("In main function");
	if(vconf_get_int(lic_key, &lic_val))
	{
        LOGE("vconf_get_int FAIL\n");
	}
	if(lic_val == 0)
	{
		LOGE("License terms not accepted.");
	}
	if (lic_val == 1)
	{*/
	
	int justReady = 0;
	
	if (autostart)
	{
		printf("autostart\n");
		if(vconf_get_int("db/menu/smart_hub/ontvsetting/auto_start", &autostartVal))
		{
			LOGE("vconf_get_int FAIL\n");
		}
		
		printf("autostartVal : %d\n", autostartVal);
		setenv("DISPLAY", ":0", 1);
		
		if (autostartVal == 0)
		{
			FILE* fp = fopen("/tmp/firstscreen_ready", "w");
			fclose(fp);
			justReady = 1;
		}
	}
	
		bundle *b = bundle_create();
		bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
		bundle_add(b,"--app-js", "/usr/apps/org.volt.firstscreen/bin/first_screen/app.js");
		bundle_add(b,"--data-path", "/opt/down/panels/firstscreen_temp/");
		bundle_add(b,"--firstscreen", "true");
		startVoltContainerFirstScreen(argc, argv, b, justReady, autostart);
		bundle_free(b);
//	}
//	LOGE("wainting");
	return 0;
}
