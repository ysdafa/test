/*
 * Widget.cpp
 *
 *  Created on: Apr 30, 2013
 *      Author: reza
 */
#define COGL_ENABLE_EXPERIMENTAL_API

#include "Widget.h"

#include "VoltConfig.h"

#include <stdlib.h>
#include <stdio.h>
#include <exception>
#include <cmath>
#include <algorithm>

#include "SceneRoot.h"
#include "Exception.h"
#include "VoltActor.h"
#include "DepthEffect.h"
#include "BackfaceCullingEffect.h"
#include "CutoutEffect.h"
#ifdef ENABLE_EXPERIMENTAL_BUILD
#include "BlurEffect.h"
#include "BlurLessEffect.h"
#include "ColorizeEffect.h"
#include "BrightnessContrastEffect.h"
#include "DesaturateEffect.h"
#include "PageCurlEffect.h"
#endif
#include "AnimationHandle.h"
#include "VoltProcessManager.h"
#include "VoltFullProcessRuntime.h"
#include "event_const.h"

#include "logger.h"

namespace volt
{
namespace graphics
{

Widget::HighContrastMode Widget::highContrastMode = HighContrastMode::OFF;
Widget* Widget::focusedWidget = nullptr;

Widget::Widget() : parent(nullptr), actor(nullptr), uniqueID(""), fill(nullptr),
  cutThrough(nullptr), cachedTransformedDepth(0.0f), childrenDepthsSignalHandlerId(0)
{
  // fix for bug https://jira.sisa.samsung.com:8443/browse/DMS13VOLT-258, Slide test fails to acknowledge some mouse events
  for(int i = 0; i < (int)MOUSE_EVENT_COUNT; ++i) // mouseEventGSignalHandlerIDs is initialized with size MOUSE_EVENT_COUNT (the number of mouse events)
  {
    mouseEventGSignalHandlerIDs[i] = 0;
  }
}

void Widget::init(float x, float y, Widget* aParent)
{
  clutter_actor_set_position(actor, x, y);
  clutter_actor_show(actor);
  g_object_set(actor, "show-on-set-parent", false, NULL);
  clutter_actor_set_pivot_point(actor, 0.5f, 0.5f); //default pivot point is the center.

  //turn the automatically created "floating" reference from clutter_actor_new into a solid reference held by widget
  g_object_ref_sink(actor);

  parent = nullptr;

  if(aParent != nullptr)
  {
    aParent->addChild(this);
  }

  uniqueID = "";

  fill = nullptr;

  for(int i = 0; i < (int)MOUSE_EVENT_COUNT; ++i) //mouseEventGSignalHandlerIDs is initialized with size MOUSE_EVENT_COUNT (the number of mouse events)
  {
    mouseEventGSignalHandlerIDs[i] = 0;
  }

  //register for key and focus events
  g_signal_connect(actor, "key-focus-out", (GCallback)onFocusOutEvent, this);
  g_signal_connect(actor, "key-focus-in", (GCallback)onFocusInEvent, this);
  g_signal_connect(actor, "key-press-event", (GCallback)onKeyEvent, this);
  g_signal_connect(actor, "key-release-event", (GCallback)onKeyEvent, this);

  volt_actor_set_user_data(VOLT_ACTOR(actor), this);
  cutThrough = nullptr;
  cachedTransformedDepth = 0.0f;
  childrenDepthsSignalHandlerId = 0;
}

Widget::Widget(float x, float y, float width, float height, Widget* aParent)
{
  actor = volt_actor_new();
  init(x, y, aParent);
  volt_actor_set_width(VOLT_ACTOR(actor), width);
  volt_actor_set_height(VOLT_ACTOR(actor), height);
  clutter_actor_set_translation(actor, 0, 0 , 0);
}

Widget::~Widget()
{
  if(uniqueID != "")
  {
    unregisterWidget(uniqueID);
  }

  if (hasKeyFocus())
  {
    VoltFullProcessRuntime *runtime =
      static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

    if(runtime && runtime->GetMainStage())
    {
      SceneRoot* theScene = runtime->GetSceneRoot();

      if (theScene)
      {
        theScene->clearKeyFocus();
      }
    }
  }

  clickedWidgets.erase(this);

  //Remove pointer in parent
  if (parent != nullptr)
  {
    parent->removeChild(this);
  }

  //Cancel every animation (or they might try to refer to their host at some point in their future
  while (animations.size() > 0)
  {
    animations.back()->cancel();
    //cancel will remove animation from its host
  }

  //Destroy all children
  destroyChildren();

  //Send destruction event
  for(auto iter = destructionCallbacks.begin(); iter != destructionCallbacks.end(); iter++)
  {
    (*iter)();
  }

  delete fill;

  // delete effects
  auto iter = effects.begin();

  while (iter != effects.end())
  {
    delete iter->second;
    iter++;
  }

  //Clean up clutter resources
  if (actor != nullptr) //just in case
  {
    clutter_actor_destroy(actor);
    g_object_unref(actor);
    actor = NULL;
  }
}

//Static Widget Dictionary Management:

std::unordered_map<std::string, Widget*> Widget::widgetDictionary;

Widget* Widget::getWidgetByID(std::string id)
{
  return (widgetDictionary.count(id)) ? widgetDictionary[id] : nullptr;
}

bool Widget::registerWidget(Widget* widget, std::string id)
{
  if(widgetDictionary.count(id) > 0)
  {
    return false;
  }

  widgetDictionary[id] = widget;
  return true;
}

void Widget::unregisterWidget(std::string id)
{
  widgetDictionary.erase(id);
}

//Getters and Setters:

//X
float Widget::getX() const
{
  return clutter_actor_get_x(actor);
}

void Widget::setX(float x)
{
  clutter_actor_set_x(actor, x);
}

//Y
float Widget::getY() const
{
  return clutter_actor_get_y(actor);

}
void Widget::setY(float y)
{
  clutter_actor_set_y(actor, y);
}

//Width
float Widget::getWidth() const
{
  return volt_actor_get_width(VOLT_ACTOR(actor));
}
void Widget::setWidth(float width)
{
  volt_actor_set_width(VOLT_ACTOR(actor),width);
}

//Height
float Widget::getHeight() const
{
  return volt_actor_get_height(VOLT_ACTOR(actor));
}
void Widget::setHeight(float height)
{
  volt_actor_set_height(VOLT_ACTOR(actor), height);
}

//Origin:

/* Helper function for origin. This will be called whenever any property on the actor has changed
 * that requires an update to the origin.
 */

Vector2 Widget::getOrigin() const
{
  return Vector2(
           volt_actor_get_origin_x(VOLT_ACTOR(actor)),
           volt_actor_get_origin_y(VOLT_ACTOR(actor))
         );
}

void Widget::setOrigin(Vector2 origin)
{
  volt_actor_set_origin_x(VOLT_ACTOR(actor), origin.x);
  volt_actor_set_origin_y(VOLT_ACTOR(actor),origin.y);
}


void Widget::updateAnchorOrigin()
{
  volt_actor_update_translation_x(VOLT_ACTOR(actor));
  volt_actor_update_translation_y(VOLT_ACTOR(actor));
}

//Anchor:

Vector2 Widget::getAnchor() const
{
  return Vector2(
           volt_actor_get_anchor_x(VOLT_ACTOR(actor)),
           volt_actor_get_anchor_y(VOLT_ACTOR(actor))
         );
}

void Widget::setAnchor(Vector2 anchor)
{
  volt_actor_set_anchor_x(VOLT_ACTOR(actor),anchor.x);
  volt_actor_set_anchor_y(VOLT_ACTOR(actor),anchor.y);
}

//Parent

Widget* Widget::getParent() const
{
  return parent;
}

void Widget::setParent(Widget* newParent)
{
  newParent->addChild(this);
}


//Color

Color Widget::getColor() const
{
  ClutterColor color;

  clutter_actor_get_background_color(actor, &color);

  // if we get transparent and has rounded corners,
  // that means we need to get override color instead
  if(IS_VOLT_ACTOR(actor) && getRoundedCorners())
  {
    if(color.red == 0 && color.green == 0 && color.blue == 0 && color.alpha == 0)
    {
      volt_actor_get_override_color(VOLT_ACTOR(actor), &color);
    }
  }

  return Color(color);
}

void Widget::setColor(const Color& color)
{
  // if WidgetGraphics has rounded corners, or if it has a gradient fill,
  // disable the background color so it won't show behind the object or z-fight respectively.

  if (IS_VOLT_ACTOR(actor))
  {
    if (getRoundedCorners() || getGradientFill())
    {
      clutter_actor_set_background_color(actor, NULL);

      if (getRoundedCorners())
      {
        volt_actor_set_override_color(VOLT_ACTOR(actor), color.toClutterColor());
      }
    }
    else
    {
      clutter_actor_set_background_color(actor, color.toClutterColor());
    }
  }
  else
  {
    clutter_actor_set_background_color(actor, color.toClutterColor());
  }
}

//Opacity
int Widget::getOpacity() const
{
  return clutter_actor_get_opacity(actor);
}

void Widget::setOpacity(int opacity)
{
  clutter_actor_set_opacity(actor, opacity);
}

const char* DEPTH_EFFECT_NAME = "depth";

/* Whether or not to render using depth testing, in order to guarantee proper draw order of 3d shapes */
bool Widget::getDepthTestEnabled() const
{
  return const_cast<Widget*>(this)->getEffect(DEPTH_EFFECT_NAME) != nullptr;
}


void Widget::setDepthTestEnabled(bool enable)
{
  removeEffect(DEPTH_EFFECT_NAME);

  if (enable)
  {
    setEffect(new DepthEffect(), DEPTH_EFFECT_NAME);
  }
}

const char* BACKFACE_CULLING_EFFECT_NAME = "backface_culling";

bool Widget::getBackfaceCullingEnabled() const
{
  return const_cast<Widget*>(this)->getEffect(BACKFACE_CULLING_EFFECT_NAME) != nullptr;
}

void Widget::setBackfaceCullingEnabled(bool enable)
{
  removeEffect(BACKFACE_CULLING_EFFECT_NAME);

  if (enable)
  {
    setEffect(new BackfaceCullingEffect(), BACKFACE_CULLING_EFFECT_NAME);
  }
}

float Widget::getDepth() const
{
  return clutter_actor_get_z_position(actor);
}

void Widget::setDepth(float depth)
{
  if (clutter_actor_get_z_position(actor) != depth)
  {
    clutter_actor_set_z_position(actor, depth);

    // Depth has changed, must reorder all siblings if auto sort by depth is enabled on parent.
    if (parent != nullptr && parent->getAutoSortChildrenByDepth())
    {
      parent->insertSortChildren();
    }
  }
}

//Visibility

void Widget::show()
{
  clutter_actor_show(actor);
}

void Widget::hide()
{
  clutter_actor_hide(actor);
}

//3D Ops:

Vector2 Widget::getPivot() const
{
  float x = 0, y = 0;
  clutter_actor_get_pivot_point(actor, &x, &y);
  return Vector2(x,y);
}

void Widget::setPivot(Vector2 newPivot)
{
  clutter_actor_set_pivot_point(actor, newPivot.x, newPivot.y);
}

Vector2 Widget::getScale() const
{
  double x = 0, y = 0;
  clutter_actor_get_scale(actor, &x, &y);
  return Vector2(x,y);
}

void Widget::setScale(Vector2 newScale)
{
  clutter_actor_set_scale(actor, newScale.x, newScale.y);
}

void Widget::setScale(double newScale)
{
  clutter_actor_set_scale(actor, newScale, newScale);
}

Vector3 Widget::getRotation() const
{
  float x = clutter_actor_get_rotation_angle(actor, CLUTTER_X_AXIS);
  float y = clutter_actor_get_rotation_angle(actor, CLUTTER_Y_AXIS);
  float z = clutter_actor_get_rotation_angle(actor, CLUTTER_Z_AXIS);
  return Vector3(x,y,z);
}

void Widget::setRotation(Vector3 anglePerAxis)
{
  clutter_actor_set_rotation_angle(actor, CLUTTER_Z_AXIS, anglePerAxis.z );
  clutter_actor_set_rotation_angle(actor, CLUTTER_Y_AXIS, anglePerAxis.y );
  clutter_actor_set_rotation_angle(actor, CLUTTER_X_AXIS, anglePerAxis.x );

  // Depth may have changed, must resort all siblings if auto sort by depth is enabled on parent.
  if (parent != nullptr && parent->getAutoSortChildrenByDepth())
  {
    parent->insertSortChildren();
  }
}


bool Widget::getCropOverflow() const
{
  return volt_actor_get_clip_to_shape(VOLT_ACTOR(actor));
}

void Widget::setCropOverflow(bool crop)
{
  volt_actor_set_clip_to_shape(VOLT_ACTOR(actor), crop);
}


#ifdef ENABLE_EXPERIMENTAL_BUILD

/* Blur Effect Stuff */
static const char* BLUR_EFFECT_NAME = "blur";

bool Widget::getBlur() const
{
  return static_cast<BlurEffect*>(const_cast<Widget*>(this)->getEffect(BLUR_EFFECT_NAME)) != nullptr;
}


void Widget::setBlur(bool enable)
{
  removeEffect(BLUR_EFFECT_NAME);

  if (enable)
  {
    setEffect(new BlurEffect, BLUR_EFFECT_NAME);
  }
}

/* BlurLess Effect Stuff */
bool Widget::getBlurLess() const
{
  return static_cast<BlurLess*>(const_cast<Widget*>(this)->getEffect(BlurLess::EFFECT_NAME)) != nullptr;
}


void Widget::setBlurLess(bool enable)
{
  removeEffect(BlurLess::EFFECT_NAME);

  if (enable)
  {
    setEffect(new BlurLess, BlurLess::EFFECT_NAME);
  }
}


/* Tint Effect Stuff */
Color Widget::getTint() const
{
  ColorizeEffect* colorize =
    static_cast<ColorizeEffect*>(const_cast<Widget*>(this)->getEffect(ColorizeEffect::EFFECT_NAME));

  if (colorize)
  {
    return colorize->getTint();
  }
  else
  {
    return Color::Transparent();
  }
}


void Widget::setTint(const Color& tint)
{
  ColorizeEffect* colorize = static_cast<ColorizeEffect*>(const_cast<Widget*>(this)->getEffect(ColorizeEffect::EFFECT_NAME));

  if (!colorize)
  {
    setEffect(new ColorizeEffect(tint), ColorizeEffect::EFFECT_NAME);
  }
  else
  {
    colorize->setTint(tint);
  }
}

void Widget::checkAddBrightCont(BrightnessContrastEffect*& brightCont, float value)
{
  if (!brightCont)
  {
    brightCont = new BrightnessContrastEffect();
    setEffect(brightCont, BrightnessContrastEffect::EFFECT_NAME);
  }
}

float Widget::getBrightness() const
{
  BrightnessContrastEffect* brightCont =
    static_cast<BrightnessContrastEffect*>(const_cast<Widget*>(this)->getEffect(BrightnessContrastEffect::EFFECT_NAME));

  if (brightCont)
  {
    return brightCont->getBrightness();
  }
  else
  {
    return 0.0;
  }
}


void Widget::setBrightness(float value)
{
  BrightnessContrastEffect* brightCont =
    static_cast<BrightnessContrastEffect*>(const_cast<Widget*>(this)->getEffect(BrightnessContrastEffect::EFFECT_NAME));

  checkAddBrightCont(brightCont, value);

  brightCont->setBrightness(value);
}

float Widget::getContrast() const
{
  BrightnessContrastEffect* brightCont =
    static_cast<BrightnessContrastEffect*>(const_cast<Widget*>(this)->getEffect(BrightnessContrastEffect::EFFECT_NAME));

  if (brightCont)
  {
    return brightCont->getContrast();
  }
  else
  {
    return 0.0;
  }

}

void Widget::setContrast(float value)
{
  BrightnessContrastEffect* brightCont =
    static_cast<BrightnessContrastEffect*>(const_cast<Widget*>(this)->getEffect(BrightnessContrastEffect::EFFECT_NAME));

  checkAddBrightCont(brightCont, value);

  brightCont->setContrast(value);
}

double Widget::getDesaturateFactor() const
{
  DesaturateEffect* desatEffect =
    static_cast<DesaturateEffect*>(const_cast<Widget*>(this)->getEffect(DesaturateEffect::EFFECT_NAME));

  if (desatEffect)
  {
    return desatEffect->getFactor();
  }
  else
  {
    return 0.0d;
  }
}

void Widget::setDesaturateFactor(double factor)
{
  DesaturateEffect* desatEffect =
    static_cast<DesaturateEffect*>(const_cast<Widget*>(this)->getEffect(DesaturateEffect::EFFECT_NAME));

  if (!desatEffect)
  {
    desatEffect = new DesaturateEffect();
    setEffect(desatEffect, DesaturateEffect::EFFECT_NAME);
  }

  desatEffect->setFactor(factor);
}

double Widget::getPageCurlPeriod() const
{
  PageCurlEffect* curlEffect = static_cast<PageCurlEffect*>(const_cast<Widget*>(this)->getEffect(PageCurlEffect::EFFECT_NAME));

  if (curlEffect)
  {
    return curlEffect->getPeriod();
  }
  else
  {
    return 0.0d;
  }
}

void Widget::setPageCurlPeriod(double period)
{
  PageCurlEffect* curlEffect = static_cast<PageCurlEffect*>(const_cast<Widget*>(this)->getEffect(PageCurlEffect::EFFECT_NAME));

  if (curlEffect)
  {
    curlEffect->setPeriod(period);
  }
}

double Widget::getPageCurlAngle() const
{
  PageCurlEffect* curlEffect = static_cast<PageCurlEffect*>(const_cast<Widget*>(this)->getEffect(PageCurlEffect::EFFECT_NAME));

  if (curlEffect)
  {
    return curlEffect->getAngle();
  }
  else
  {
    return 0.0d;
  }
}

void Widget::setPageCurlAngle(double angle)
{
  PageCurlEffect* curlEffect = static_cast<PageCurlEffect*>(const_cast<Widget*>(this)->getEffect(PageCurlEffect::EFFECT_NAME));

  if (curlEffect)
  {
    curlEffect->setAngle(angle);
  }
}

float Widget::getPageCurlRadius() const
{
  PageCurlEffect* curlEffect = static_cast<PageCurlEffect*>(const_cast<Widget*>(this)->getEffect(PageCurlEffect::EFFECT_NAME));

  if (curlEffect)
  {
    return curlEffect->getRadius();
  }
  else
  {
    return 0.0f;
  }
}

void Widget::setPageCurlRadius(float radius)
{
  PageCurlEffect* curlEffect = static_cast<PageCurlEffect*>(const_cast<Widget*>(this)->getEffect(PageCurlEffect::EFFECT_NAME));

  if (curlEffect)
  {
    curlEffect->setRadius(radius);
  }
}
#endif

std::string Widget::getID() const
{
  return uniqueID;
}

void Widget::setID(const std::string& id)
{
  if(uniqueID != "")
  {
    unregisterWidget(uniqueID);
  }

  if(id != "" && !registerWidget(this, id))
  {
    throw VoltInvalidWidgetIDException(("Widget ID \"" + id + "\" already in use").c_str());
  }

  uniqueID = id;

  // give the actor the same name for ease in debugging
  clutter_actor_set_name(actor, id.c_str());
}

CoglMatrix Widget::calculateTransform() const
{
  float x = getX();
  float y = getY();
  Vector3 rotation = getRotation();
  Vector2 scale = getScale();
  Vector2 pivot = getPivot();

  CoglMatrix transform;

  //position
  cogl_matrix_init_translation(&transform, x, y, 0);

  //anchor/origin
  if (parent != nullptr && (getAnchor() != Vector2() || getOrigin() != Vector2()))
  {
    float transX, transY, transZ;
    clutter_actor_get_translation(actor, &transX, &transY, &transZ);
    cogl_matrix_translate(&transform, transX, transY, transZ);
  }

  if (getScale() != Vector2() || getRotation() != Vector3())
  {
    //adjust by the pivot
    cogl_matrix_translate(&transform, pivot.x * getWidth(), pivot.y * getHeight(), 0);

    //scale
    cogl_matrix_scale(&transform, scale.x, scale.y, 1);

    //rotate
    cogl_matrix_rotate(&transform, rotation.z, 0, 0, 1);
    cogl_matrix_rotate(&transform, rotation.y, 0, 1, 0);
    cogl_matrix_rotate(&transform, rotation.x, 1, 0, 0);

    //undo pivot
    cogl_matrix_translate(&transform, -pivot.x * getWidth(), -pivot.y * getHeight(), 0);
  }

  return transform;
}

Vector3 Widget::getAbsolutePosition() const
{
  //Multiply together all the ancestor transforms
  Widget* current = parent;

  float absPosX = getX(), absPosY = getY(), absPosZ = getDepth(), dummyW = 1;

  if(current != nullptr)
  {
    CoglMatrix transform = parent->calculateTransform();

    cogl_matrix_transform_point(&transform, &absPosX, &absPosY, &absPosZ, &dummyW);

    while (current->parent != nullptr) //can't multiply scene pivot, breaks everything
    {
      CoglMatrix parentTransform = current->parent->calculateTransform();
      cogl_matrix_transform_point(&parentTransform, &absPosX, &absPosY, &absPosZ, &dummyW);

      current = current->parent;
    }

    if (parent != nullptr)
    {
      Vector2 origin = getOrigin();
      absPosX += origin.x * parent->getWidth();
      absPosY += origin.y * parent->getHeight();
    }
  }

  return Vector3(absPosX, absPosY, absPosZ);
}

Vector2 Widget::getAbsoluteSize() const
{
  float width = getWidth() * getScale().x;
  float height = getHeight() * getScale().y;
  const Widget* current = this;

  while (current->parent != nullptr)
  {
    current = current->parent;
    width *= current->getScale().x;
    height *= current->getScale().y;
  }

  return Vector2(width, height);
}


//Scene graph query and modification methods:

int Widget::getChildCount() const
{
  return children.size();
}

int Widget::addChild(Widget* child, int index)
{
  if(child == parent)
  {
    parent->removeChild(this);
  }

  if(child->parent != nullptr)
  {
    child->parent->removeChild(child);
  }

  if(index > (int)children.size() || index < 0) //must happen after removeChild call so children.size is gauranteed to be valid
  {
    index = children.size();
  }

  // if depth sorting set index at end for most efficient execution of insertSortChildren(),
  if (getAutoSortChildrenByDepth())
  {
    index = children.size();
  }

  clutter_actor_insert_child_at_index (actor, child->actor, index);

  if(index == 0)
  {
    children.push_front(child);
  }
  else
  {
    children.insert(children.begin() + index, child);
  }

  child->parent = this;

  child->updateAnchorOrigin();

  // Now sort children because child actor must be parented before sorting so
  // that the correct depth can be computed.
  if (getAutoSortChildrenByDepth())
  {
    insertSortChildren();
  }

  return index;
}

void Widget::removeChild(Widget* target)
{
  if(target != nullptr)
  {
    auto it = std::find(children.begin(), children.end(), target);

    if (it != children.end())
    {
      removeChildByIndex(std::distance(children.begin(), it));
    }
  }
}

Widget* Widget::removeChildByIndex(uint index)
{
  if (index >= children.size())
  {
    return nullptr;
  }

  Widget *target = children.at(index);

  if(actor != nullptr)
  {
    clutter_actor_remove_child(actor, target->actor);
  }

  children.erase(children.begin() + index);

  target->parent = nullptr;
  return target;
}

Widget* Widget::getChildByIndex(uint index)
{
  if(index >= children.size())
  {
    return nullptr;
  }

  return children.at(index);
}

Widget* Widget::getChildByName(std::string name)
{
  for(auto iter = children.begin(); iter < children.end(); iter++)
  {
    if( (*iter)->getID() == name )
    {
      return *iter;
    }
  }

  return nullptr;
}

Widget* Widget::getAncestor(std::string id)
{
  if(getID() == id)
  {
    return this;
  }

  Widget* parent = getParent();

  if(parent == nullptr)
  {
    return nullptr;
  }
  else
  {
    return parent->getAncestor(id);
  }
}

Widget* Widget::getDescendent(std::string id)
{
  Widget* widget = getWidgetByID(id);
  Widget* ancestor = widget;

  while(ancestor != this)
  {
    if(ancestor == nullptr)
    {
      return nullptr;
    }

    ancestor = ancestor->getParent();
  }

  return widget;
}

float Widget::getTransformedDepth() const
{
  return volt_actor_get_transformed_depth(VOLT_ACTOR(actor));
}

/**
 * updateChildrenCachedDepths - update the cached depths of the widget's children by
 * calling the volt_actor function to compute them.
 *
 * @author jim (8/18/2014)
 */
void Widget::updateChildrenCachedDepths()
{
  auto iter = children.begin();

  for(; iter != children.end(); ++iter)
  {
    (*iter)->cachedTransformedDepth = volt_actor_get_transformed_depth(VOLT_ACTOR((*iter)->actor));
  }
}


/** Number of elements threshold above which we use a binary search for inserting
 *  into the sorted list.  Below this we use a linear search. */
const int USE_BINARY_SEARCH_THRESHOLD = 20;

/**
 * Insertion sort for list that is mostly already sorted.
 *
 * For each element k in slots 1..n, first check whether el[k] >= el[k-1]. If so,
 * go to next element. (Obviously skip the first element.)
 * If not, use binary-search in elements 1..k-1 to determine the insertion location,
 * then scoot the elements over.
 * (You might do this only if k>T where T is some threshold value; with small k this is overkill.)
 */

void Widget::insertSortChildren()
{
  if (children.size() < 2)
  {
    return;
  }

  // update cached transformed depth for each child so we don't compute it more than once for
  // each actor while we are sorting.
  updateChildrenCachedDepths();

  // skip first element
  int index = 1;

  for (; index < static_cast<int>(children.size()); ++index)
  {
    float valueToInsert = children[index]->cachedTransformedDepth;

    if (valueToInsert >= children[index - 1]->cachedTransformedDepth)
    {
      continue;
    }

    int insertIndex = index - 2;

    if (index > USE_BINARY_SEARCH_THRESHOLD)
    {
      // use binary search into sorted array
      int highIndex = insertIndex;
      int lowIndex = 0;

      while (highIndex > lowIndex + 1)
      {
        int midPoint = lowIndex + ( highIndex - lowIndex ) / 2;

        if (valueToInsert > children[midPoint]->cachedTransformedDepth)
        {
          lowIndex = midPoint + 1;
        }
        else // valueToInsert <= children[midPoint]->cachedTransformedDepth
        {
          highIndex = midPoint;
        }
      }

      insertIndex = highIndex;
      // insert at highIndex
    }
    else
    {
      // use linear search
      for (; insertIndex >= 0; --insertIndex)
      {
        if (children[insertIndex]->cachedTransformedDepth <= valueToInsert)
        {
          break;
        }
      }

      // increment by one to get to insertion position
      ++insertIndex;
    }

    // if removing element before insertion point, then decrement insertion point
    if (index < insertIndex)
    {
      insertIndex--;
    }

    // move child to the sorted position by erasing and readding it
    Widget* child = children[index];
    children.erase(children.begin() + index);

    // must update iter to next element where to continue the insertion sort from.
    children.insert(children.begin() + insertIndex, child);

    // move the corresponding actor to the proper index
    clutter_actor_set_child_at_index(child->parent->actor, child->actor, insertIndex);
  }
}

bool Widget::compWidgetByDepth(Widget* w1, Widget* w2)
{
  return w1->cachedTransformedDepth < w2->cachedTransformedDepth;
}

/**
 * sortChildrenByDepth: reorder the children of this widget from lowest to highest
 * depth. This routine uses std::stablesort and is used when list is mostly unsorted
 *
 * @author jim (8/12/2014)
 */
void Widget::reorderChildrenByDepth()
{
  // update cached transformed depth for each child so we don't compute it more than once for
  // each actor while we are sorting.
  updateChildrenCachedDepths();

  std::stable_sort(children.begin(), children.end(), compWidgetByDepth);

  // update the clutter children to match the widget children order.
  for(auto iter = children.begin(); iter < children.end(); ++iter)
  {
    clutter_actor_set_child_at_index(actor, (*iter)->actor, std::distance(children.begin(), iter));
  }
}

#ifdef UNUSED_CODE
Widget* Widget::FindWhichChildOfAncestor(Widget* widget, Widget* ancestor)
{
  if (ancestor == nullptr || widget == nullptr || widget->parent == nullptr || widget == ancestor)
  {
    return nullptr;
  }

  while (widget->parent != nullptr && widget->parent != ancestor)
  {
    widget = widget->parent;
  }

  return widget;
}

Widget* Widget::FindFirstCommonAncestorRecurse(Widget* w1, Widget* w2, Widget* ancestor)
{
  if (w1 == ancestor || w2 == ancestor)
  {
    return ancestor;
  }

  Widget* c1 = FindWhichChildOfAncestor(w1, ancestor);
  Widget* c2 = FindWhichChildOfAncestor(w2, ancestor);

  if (c1 == nullptr || c2 == nullptr)
  {
    return nullptr;
  }

  if (c1 != c2)
  {
    return ancestor;
  }

  return FindFirstCommonAncestorRecurse(w1, w2, c1);
}

Widget* Widget::FindFirstCommonAncestor(Widget* w1, Widget* w2)
{
  if (w1 == nullptr || w2 == nullptr)
  {
    return nullptr;
  }

  Widget* root1 = w1;
  Widget* root2 = w2;

  while (root1->parent != nullptr)
  {
    root1 = root1->parent;
  }

  while (root2->parent != nullptr)
  {
    root2 = root2->parent;
  }

  if (root1 != root2)
  {
    return nullptr;
  }

  return FindFirstCommonAncestorRecurse(w1, w2, root1);
}
#endif

void Widget::destroyChildren()
{
  while (children.size() > 0)
  {
    Widget* targetChild = *(children.begin());
    removeChildByIndex(0);
    delete targetChild;
  }
}

// Rounded Corners
bool Widget::getRoundedCorners() const
{
  return volt_actor_get_rounded_corners(VOLT_ACTOR(actor));
}

void Widget::setRoundedCorners(bool setRoundedCorners)
{
  bool hasRoundedCorners = volt_actor_get_rounded_corners(VOLT_ACTOR(actor));

  if(setRoundedCorners != hasRoundedCorners)
  {
    volt_actor_set_rounded_corners(VOLT_ACTOR(actor), setRoundedCorners);
    // If rounded corners status changes, this call
    // disables/enables the correct color in the VoltActor because we needed a separate
    // color for the rounded corners feature
    setColor(getColor());
  }
}

float Widget::getRCornerRadius() const
{
  return volt_actor_get_rc_radius(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_RADIUS);
}

void Widget::setRCornerRadius(float radius)
{
  volt_actor_set_rc_radius(VOLT_ACTOR(actor), radius, VOLT_ACTOR_PROP_RC_RADIUS);
}

float Widget::getRCornerArcStep() const
{
  return volt_actor_get_rc_arc_step(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_ARC_STEP);
}

void Widget::setRCornerArcStep(float arcStep)
{
  volt_actor_set_rc_arc_step(VOLT_ACTOR(actor), arcStep, VOLT_ACTOR_PROP_RC_ARC_STEP);
}

Corner Widget::getRCornerBLeft() const
{
  return Corner(volt_actor_get_rc_radius(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_BL_RADIUS),
                volt_actor_get_rc_arc_step(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_BL_ARC_STEP));
}

void Widget::setRCornerBLeft(const Corner& corner)
{
  volt_actor_set_rc_radius(VOLT_ACTOR(actor), corner.radius, VOLT_ACTOR_PROP_RC_BL_RADIUS);
  volt_actor_set_rc_arc_step(VOLT_ACTOR(actor), corner.arcStep, VOLT_ACTOR_PROP_RC_BL_ARC_STEP);
}

Corner Widget::getRCornerBRight() const
{
  return Corner(volt_actor_get_rc_radius(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_BR_RADIUS),
                volt_actor_get_rc_arc_step(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_BR_ARC_STEP));
}

void Widget::setRCornerBRight(const Corner& corner)
{
  volt_actor_set_rc_radius(VOLT_ACTOR(actor), corner.radius, VOLT_ACTOR_PROP_RC_BR_RADIUS);
  volt_actor_set_rc_arc_step(VOLT_ACTOR(actor), corner.arcStep, VOLT_ACTOR_PROP_RC_BR_ARC_STEP);
}

Corner Widget::getRCornerTLeft() const
{
  return Corner(volt_actor_get_rc_radius(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_TL_RADIUS),
                volt_actor_get_rc_arc_step(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_TL_ARC_STEP));
}

void Widget::setRCornerTLeft(const Corner& corner)
{
  volt_actor_set_rc_radius(VOLT_ACTOR(actor), corner.radius, VOLT_ACTOR_PROP_RC_TL_RADIUS);
  volt_actor_set_rc_arc_step(VOLT_ACTOR(actor), corner.arcStep, VOLT_ACTOR_PROP_RC_TL_ARC_STEP);
}

Corner Widget::getRCornerTRight() const
{
  return Corner(volt_actor_get_rc_radius(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_TR_RADIUS),
                volt_actor_get_rc_arc_step(VOLT_ACTOR(actor), VOLT_ACTOR_PROP_RC_TR_ARC_STEP));
}

void Widget::setRCornerTRight(const Corner& corner)
{
  volt_actor_set_rc_radius(VOLT_ACTOR(actor), corner.radius, VOLT_ACTOR_PROP_RC_TR_RADIUS);
  volt_actor_set_rc_arc_step(VOLT_ACTOR(actor), corner.arcStep, VOLT_ACTOR_PROP_RC_TR_ARC_STEP);
}

Color Widget::getBorderColor() const
{
  ClutterColor color;
  volt_actor_get_border_color(VOLT_ACTOR(actor),&color);
  return Color(color);
}

void Widget::setBorderColor(const Color& color)
{
  volt_actor_set_border_color(VOLT_ACTOR(actor), color.toClutterColor());
}

float Widget::getBorderWidth() const
{
  return volt_actor_get_border_width(VOLT_ACTOR(actor));
}

void Widget::setBorderWidth(float width)
{
  volt_actor_set_border_width(VOLT_ACTOR(actor),width);
}

bool Widget::getGradientFill() const
{
  return volt_actor_get_gradient_fill(VOLT_ACTOR(actor));
}

void Widget::setGradientFill(bool gradientFill)
{
  volt_actor_set_gradient_fill(VOLT_ACTOR(actor), gradientFill);
  // If gradient fill status changes, this call
  // disables/enables the background color since it is mutually exclusive to gradient fill
  setColor(getColor());
}

void Widget::setGradTlColor(const Color& tlColor)
{
  volt_actor_set_grad_tl_color(VOLT_ACTOR(actor), tlColor.toClutterColor());
}

Color Widget::getGradTlColor() const
{
  ClutterColor color;
  volt_actor_get_grad_tl_color(VOLT_ACTOR(actor), &color);
  return Color(color);
}


void Widget::setGradTrColor(const Color& trColor)
{
  volt_actor_set_grad_tr_color(VOLT_ACTOR(actor), trColor.toClutterColor());
}

Color Widget::getGradTrColor() const
{
  ClutterColor color;
  volt_actor_get_grad_tr_color(VOLT_ACTOR(actor), &color);
  return Color(color);
}


void Widget::setGradBlColor(const Color& blColor)
{
  volt_actor_set_grad_bl_color(VOLT_ACTOR(actor), blColor.toClutterColor());
}

Color Widget::getGradBlColor() const
{
  ClutterColor color;
  volt_actor_get_grad_bl_color(VOLT_ACTOR(actor), &color);
  return Color(color);
}


void Widget::setGradBrColor(const Color& brColor)
{
  volt_actor_set_grad_br_color(VOLT_ACTOR(actor), brColor.toClutterColor());
}

Color Widget::getGradBrColor() const
{
  ClutterColor color;
  volt_actor_get_grad_br_color(VOLT_ACTOR(actor), &color);
  return Color(color);
}


//Effectscc
Effect* Widget::getEffect(std::string id)
{
  if(effects.count(id) == 0)
  {
    return nullptr;
  }

  return effects[id];
}

void Widget::removeEffect(std::string id)
{
  if(effects.count(id) > 0)
  {
    clutter_actor_remove_effect_by_name(actor, id.c_str());
    delete effects[id];
    effects.erase(id);
  }
}

void Widget::setEffect(Effect* effect, std::string id)
{
  removeEffect(id);
  effects[id] = effect;
  clutter_actor_add_effect_with_name(actor, id.c_str(), const_cast<ClutterEffect*>(effect->getEffect()));
}


// Actor's Fill

void Widget::setFill(Fill* fillIn)
{
  delete fill;
  clutter_actor_set_content(actor, fillIn ? fillIn->getContent() : nullptr);
  fill = fillIn;
}


void Widget::setMinScalingFilter( ScalingFilter minFilter )
{
  ClutterScalingFilter maxFilter;
  clutter_actor_get_content_scaling_filters(actor, NULL, &maxFilter);
  clutter_actor_set_content_scaling_filters(actor, (ClutterScalingFilter)minFilter,
      maxFilter);
}


ScalingFilter Widget::getMinScalingFilter() const
{
  ClutterScalingFilter minFilter;
  clutter_actor_get_content_scaling_filters(actor, &minFilter, NULL);
  return (ScalingFilter)minFilter;
}


void Widget::setMaxScalingFilter( ScalingFilter maxFilter )
{
  ClutterScalingFilter minFilter;
  clutter_actor_get_content_scaling_filters(actor, &minFilter, NULL);
  clutter_actor_set_content_scaling_filters(actor, minFilter, (ClutterScalingFilter)maxFilter);
}


ScalingFilter Widget::getMaxScalingFilter() const
{
  ClutterScalingFilter maxFilter;
  clutter_actor_get_content_scaling_filters(actor, NULL, &maxFilter);
  return (ScalingFilter)maxFilter;
}

// Shadows
bool Widget::getShadow() const
{
  return volt_actor_get_shadow(VOLT_ACTOR(actor));
}

void Widget::setShadow(bool hasShadowIn, float xOffset, float yOffset, int blur,
                       int spread, const Color& color)
{
  volt_actor_set_shadow(VOLT_ACTOR(actor), hasShadowIn, xOffset, yOffset, blur,
                        spread, color.toClutterColor());
}

float Widget::getShadowXOffset() const
{
  return volt_actor_get_shadow_h(VOLT_ACTOR(actor));
}

void Widget::setShadowXOffset(float shadowXOffsetIn)
{
  volt_actor_set_shadow_h(VOLT_ACTOR(actor), shadowXOffsetIn);
}

float Widget::getShadowYOffset() const
{
  return volt_actor_get_shadow_v(VOLT_ACTOR(actor));
}

void Widget::setShadowYOffset(float shadowYOffsetIn)
{
  volt_actor_set_shadow_v(VOLT_ACTOR(actor), shadowYOffsetIn);
}

int Widget::getShadowSpread() const
{
  return volt_actor_get_shadow_spread(VOLT_ACTOR(actor));
}

void Widget::setShadowSpread(int shadowSpreadIn)
{
  volt_actor_set_shadow_spread(VOLT_ACTOR(actor), shadowSpreadIn);
}

int Widget::getShadowBlur() const
{
  return volt_actor_get_shadow_blur(VOLT_ACTOR(actor));
}

void Widget::setShadowBlur(int shadowBlurIn)
{
  volt_actor_set_shadow_blur(VOLT_ACTOR(actor), shadowBlurIn);
}

Color Widget::getShadowColor() const
{
  ClutterColor color;
  volt_actor_get_shadow_color(VOLT_ACTOR(actor), &color);
  return Color(color);
}

void Widget::setShadowColor(const Color& shadowColorIn)
{
  volt_actor_set_shadow_color(VOLT_ACTOR(actor), shadowColorIn.toClutterColor());
}

// CutThrough
namespace
{
const char* CUTOUT_EFFECT_NAME = "cutout";
}

void Widget::setCutThrough(Widget* cutThroughIn)
{
  if (cutThroughIn != cutThrough)
  {
    if (cutThrough != nullptr) // remove old cutout from old cutThrough
    {
      cutThrough->removeEffect(CUTOUT_EFFECT_NAME);
    }

    // update cutThrough
    cutThrough = cutThroughIn;

    // Add the cutout effect on the new cutThrough widget
    if (cutThrough != nullptr)
    {
      Effect* cutoutEffect = new CutoutEffect(VOLT_ACTOR(actor));
      cutThrough->setEffect(cutoutEffect, CUTOUT_EFFECT_NAME);
    }
  }
}

Widget* Widget::getCutThrough() const
{
  return cutThrough;
}

bool Widget::getAutoSortChildrenByDepth() const
{
  return childrenDepthsSignalHandlerId != 0;
}

void Widget::onChildrenDepthsChanged(GObject* object, gint msecs /*unused*/, gpointer data)
{
  Widget* self = reinterpret_cast<Widget*>(data);
  self->insertSortChildren();
}


void Widget::setAutoSortChildrenByDepth(bool autoSortChildrenByDepthIn)
{

  if (getAutoSortChildrenByDepth() != autoSortChildrenByDepthIn)
  {

    if (autoSortChildrenByDepthIn)
    {

      childrenDepthsSignalHandlerId = SceneRoot::registerTick(onChildrenDepthsChanged, this);

      // turning on, must sort existing children.  Call routine optimized for sorting mostly out of order children
      reorderChildrenByDepth();
    }
    else
    {
      // disconnect signal
      if (childrenDepthsSignalHandlerId)
      {
        SceneRoot::unregisterTick(childrenDepthsSignalHandlerId);
        childrenDepthsSignalHandlerId = 0;
      }
    }
  }
}


//Events

void Widget::registerDestructionEvent(WidgetDestructionCallback callback)
{
  destructionCallbacks.push_back(callback);
}

std::set<Widget*> Widget::clickedWidgets;


Widget::MouseEvent Widget::clutterToVoltMouseEvent(ClutterEventType eventType)
{
  switch (eventType)
  {
  case CLUTTER_BUTTON_PRESS:
    return MOUSE_DOWN;
  case CLUTTER_BUTTON_RELEASE:
    return MOUSE_UP;
  case CLUTTER_ENTER:
    return MOUSE_OVER;
  case CLUTTER_LEAVE:
    return MOUSE_OUT;
  case CLUTTER_MOTION:
    return MOUSE_MOVE;
  default:
    return MOUSE_DOWN;
  }
}

const char* Widget::getClutterEventStringID(Widget::MouseEvent eventType)
{
  switch (eventType)
  {
  case MOUSE_DOWN:
    return "button-press-event";
  case MOUSE_UP:
    return "button-release-event";
  case MOUSE_OVER:
    return "enter-event";
  case MOUSE_OUT:
    return "leave-event";
  case MOUSE_MOVE:
    return "motion-event";
  default:
    return "invalid-event";
  }
}


gboolean Widget::onMouseEvent(ClutterActor * /* unused */, ClutterEvent *aEvent, gpointer aWidget)
{
  LOG_DEBUG(volt::util::Logger("volt"), "OnMouseEvent called");
  gfloat x, y;
  guint32 button = 0;
  clutter_event_get_coords(aEvent, &x, &y);

  Widget* self = reinterpret_cast<Widget *>(aWidget);

  ClutterEventType clutterType = clutter_event_type(aEvent);

  if (clutterType == CLUTTER_BUTTON_PRESS || clutterType == CLUTTER_BUTTON_RELEASE)
  {
    button = clutter_event_get_button(aEvent);
    guint click_count = clutter_event_get_click_count(aEvent);

    LOG_DEBUG(volt::util::Logger("volt"),
              "[Widget:" << self->getID() << "] Mouse button " << button << " clicked " << click_count << " times @ (" << x << ", " << y << ")");
  }

  MouseEvent eventType = clutterToVoltMouseEvent(clutterType);

  ClutterActor* originActor = clutter_event_get_source(aEvent);
  Widget* origin = static_cast<Widget*>( volt_actor_get_user_data( VOLT_ACTOR(originActor) ) );
  //Note that origin could be deallocated if it was destroyed during event propogation.

  gboolean shouldPropogate =  CLUTTER_EVENT_PROPAGATE;

  if(! self->invokeMouseEventCallbacks(eventType, origin, static_cast<volt::util::MOUSE_BUTTON>(button), Vector2(x, y)) )
  {
    shouldPropogate = CLUTTER_EVENT_STOP;  //stop propogation if a callback returned false
  }

  //If we meet the conditions to call the click event, call that as well
  if (eventType == MOUSE_UP )
  {
    if ( Widget::clickedWidgets.count(self))
    {
      if(! self->invokeMouseEventCallbacks(Widget::MOUSE_CLICK, origin,
                                           static_cast<volt::util::MOUSE_BUTTON>(button), Vector2(x, y)) )
      {
        shouldPropogate = CLUTTER_EVENT_STOP;
      }

    }

    clickedWidgets.erase(self);
  }

  return shouldPropogate; //We want events to bubble up
}

gboolean Widget::onMouseClickPress(ClutterActor* actor, ClutterEvent *aEvent, gpointer aWidget)
{
  Widget *self = reinterpret_cast<Widget *>(aWidget);
  clickedWidgets.insert(self);
  return CLUTTER_EVENT_PROPAGATE;
}


gboolean Widget::onGlobalMouseRelease(ClutterActor*, ClutterEvent *aEvent, gpointer aWidget)
{
  clickedWidgets.clear();
  return CLUTTER_EVENT_PROPAGATE;
}

bool Widget::invokeMouseEventCallbacks(MouseEvent eventType, Widget* origin,  volt::util::MOUSE_BUTTON button, Vector2 coords)
{
  //Note that origin could be deallocated if it was destroyed during event propogation. Pass it down to application, don't count on using it
  bool propogate = true;

  if (mouseCallbacks.count(eventType) > 0)
  {
    std::pair< EventHandle, EventHandle > range = mouseCallbacks.equal_range(eventType);

    /* Saving the listeners before actually invoking them in case the
     * listeners register additional listeners.
     * It is not safe to iterate ranges and insert or remove from the multimap. */
    std::vector<ButtonPressCallback> listeners;

    for (auto it = range.first; it != range.second; ++it)
    {
      listeners.push_back(it->second);
    }

    for (auto it = listeners.begin(); it != listeners.end(); ++it)
    {
      propogate = propogate &&
                  (*it)(this, origin, button, coords); //execute the callback function
    }
  }

  return propogate;
}


Widget::EventHandle Widget::registerMouseEvent(MouseEvent event, ButtonPressCallback callback)
{
  clutter_actor_set_reactive(actor, TRUE);
  const char* clutterEventID = getClutterEventStringID(event);

  //Connect the signal to receive the necessary clutter event, if it isn't already attached
  if (mouseEventGSignalHandlerIDs[event] == 0) //0 indicates no signal is connected
  {
    if (event == MOUSE_CLICK)
    {
      mouseEventGSignalHandlerIDs[event] = g_signal_connect(actor, "button-press-event", G_CALLBACK(onMouseClickPress), this);

      if (mouseCallbacks.count(MOUSE_UP) == 0) //only attach a release event if its not already attached by MOUSE_RELEASE
      {
        mouseEventGSignalHandlerIDs[MOUSE_UP] = g_signal_connect(actor, "button-release-event", G_CALLBACK(onMouseEvent), this);
      }
    }
    else if (event == MOUSE_UP && mouseCallbacks.count(MOUSE_UP) == 0)
    {
      //only attach a release event if its not already attached (might have been attached for MOUSE_CLICK)
      mouseEventGSignalHandlerIDs[event] = g_signal_connect(actor, clutterEventID, G_CALLBACK(onMouseEvent), this);
    }
    else
    {
      mouseEventGSignalHandlerIDs[event] = g_signal_connect(actor, clutterEventID, G_CALLBACK(onMouseEvent), this);
    }
  }

  //Store the mouse event callback
  return mouseCallbacks.insert( std::pair<MouseEvent, ButtonPressCallback>(event, callback) );
}

void Widget::unregisterMouseEvent(MouseEvent event, EventHandle handle)
{
  mouseCallbacks.erase(handle);

  //Disconnect clutter events if there are no callbacks attached to it that need triggering
  if (mouseCallbacks.count(event) == 0)
  {
    if (event != MOUSE_UP)
    {
      g_signal_handler_disconnect(actor, mouseEventGSignalHandlerIDs[event]);
      mouseEventGSignalHandlerIDs[event] = 0;
    }

    //Mouse_Up should only be disconnected if there are no registered events for either MouseUp, and MouseClick
    if ( (event == MOUSE_UP || event == MOUSE_CLICK)
         && mouseCallbacks.count(MOUSE_UP) == 0 && mouseCallbacks.count(MOUSE_CLICK) == 0 )
    {
      g_signal_handler_disconnect(actor, mouseEventGSignalHandlerIDs[MOUSE_UP]);
      mouseEventGSignalHandlerIDs[MOUSE_UP] = 0;
    }
  }

  //If there are no events left at all, make this actor unreactive to save performance.
  if (mouseCallbacks.size() == 0)
  {
    clutter_actor_set_reactive(actor, FALSE);
  }
}

void Widget::fireMouseEvent(MouseEvent event, volt::util::MOUSE_BUTTON button, Vector2 coords)
{
  if(event == MOUSE_CLICK)
  {
    //Click events aren't part of clutter, so don't bother simulating the clutter approach to them. Just fire the callbacks directly.
    Widget* current = this;

    while(current != nullptr)
    {
      current->invokeMouseEventCallbacks(event, this, button, coords);
      current = current->getParent();
    }

    return;
  }

  //Build clutter event for this fake mouse press
  ClutterEventType type;

  switch (event)
  {
  case MOUSE_DOWN:
    type = CLUTTER_BUTTON_PRESS;
    break;
  case MOUSE_UP:
    type = CLUTTER_BUTTON_RELEASE;
    break;
  case MOUSE_OVER:
    type = CLUTTER_ENTER;
    break;
  case MOUSE_OUT:
    type = CLUTTER_LEAVE;
    break;
  case MOUSE_MOVE:
    type = CLUTTER_MOTION;
    break;
  default:
    return;
  }

  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

  ClutterEvent* clutterEvent = clutter_event_new(type);
  clutter_event_set_source(clutterEvent, actor);
  clutter_event_set_stage(clutterEvent, (ClutterStage*) runtime->GetMainStage());
  clutter_event_set_coords(clutterEvent, coords.x, coords.y);

  if(type == CLUTTER_BUTTON_PRESS || type == CLUTTER_BUTTON_RELEASE)
  {
    clutter_event_set_button(clutterEvent, (guint32)button );
  }

  //Trigger the event on the object and bubble up till we reach the scene.
  //Clutter's real implementation of this is in clutter-actor.c -> _clutter_actor_handle_event
  ClutterActor* currentActor = actor;

  while(!clutter_actor_event(currentActor, clutterEvent, FALSE))
  {
    currentActor = clutter_actor_get_parent(currentActor);

    if(currentActor == NULL)
    {
      break;  //break out if we reach the top of the scene graph
    }
  }
}


gboolean Widget::onFocusInEvent(ClutterActor* /* unused */,  gpointer aWidget)
{
  Widget* widget = reinterpret_cast<Widget*>(aWidget);
  widget->fireFocusEvent(ON_FOCUS);
  return CLUTTER_EVENT_PROPAGATE;
}

gboolean Widget::onFocusOutEvent(ClutterActor* /* unused */, gpointer aWidget)
{
  Widget* widget = reinterpret_cast<Widget*>(aWidget);
  widget->fireFocusEvent(ON_UNFOCUS);
  return CLUTTER_EVENT_PROPAGATE;
}


gboolean Widget::onKeyEvent(ClutterActor* /* unused */, ClutterEvent *aEvent, gpointer aWidget)
{
  unsigned type = aEvent->type == CLUTTER_KEY_PRESS ? volt::util::EVENT_KEY_PRESS : volt::util::EVENT_KEY_RELEASE;

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
  guint key = aEvent->key.hardware_keycode;
#else
  guint key = clutter_event_get_key_symbol(aEvent);
#endif

  Widget* widget = reinterpret_cast<Widget*>(aWidget);

  auto range = widget->keyEventCallbacks.equal_range(key);

  /* Saving the listeners before actually invoking them in case the
   * listeners register additional listeners.
   * It is not safe to iterate ranges and inserting to the multimap. */
  std::vector<KeyEventCallback> listeners;

  for (auto it = range.first; it != range.second; ++it)
  {
    listeners.push_back(it->second);
  }

  for (auto it = listeners.begin(); it != listeners.end(); ++it)
  {
    (*it)(key, type);
  }

  return CLUTTER_EVENT_PROPAGATE;
}

Widget::FocusEventHandle Widget::registerFocusEvent(FocusEvent event, FocusEventCallback listener)
{
  return focusEventCallbacks.insert( std::make_pair(event, listener) );
}

void Widget::unregisterFocusEvent(FocusEventHandle handle)
{
  focusEventCallbacks.erase(handle);
}

Widget::KeyEventHandle Widget::registerKeyEvent(unsigned event, KeyEventCallback listener)
{
  return keyEventCallbacks.insert( std::make_pair(event, listener) );
}

void Widget::unregisterKeyEvent(Widget::KeyEventHandle handle)
{
  keyEventCallbacks.erase(handle);
}


void Widget::fireFocusEvent(FocusEvent event)
{
  auto range = focusEventCallbacks.equal_range(event);

  /* Saving the listeners before actually invoking them in case the
   * listeners register additional listeners.
   * It is not safe to iterate ranges and inserting to the multimap. */
  std::vector<FocusEventCallback> listeners;

  for (auto it = range.first; it != range.second; ++it)
  {
    listeners.push_back(it->second);
  }

  for (auto it = listeners.begin(); it != listeners.end(); ++it)
  {
    (*it)();
  }
}

bool Widget::hasAnimationProp(AnimatableProperty prop) const
{
  for (auto it = animations.begin(); it != animations.end(); ++it)
  {
    if ( (*it)->hasProperty(prop) )
    {
      return true;
    }
  }

  return false;
}

void Widget::removeAnimation(AnimatableProperty prop)
{
  std::vector<AnimationHandle*>::iterator target = animations.end();

  for (auto it = animations.begin(); it != animations.end(); ++it)
  {
    if ( (*it)->hasProperty(prop) )
    {
      target = it;
      break; //we assume there cannot be more than one animation of the same property.
    }
  }

  if (target != animations.end())
  {
    AnimationHandle* targetAnim = *target;
    animations.erase(target);
    targetAnim->cancel();
  }
}

void Widget::removeAnimationHandle(AnimationHandle* anim)
{
  std::vector<AnimationHandle*>::iterator target = animations.end();

  for (auto it = animations.begin(); it != animations.end(); ++it)
  {
    if (*it == anim)
    {
      target = it;
      break;
    }
  }

  if (target != animations.end())
  {
    animations.erase(target);
  }
}

void Widget::addAnimationHandle(AnimationHandle* handle)
{
  animations.push_back(handle);
}

bool Widget::hasKeyFocus() const
{
  return focusedWidget == this;
}

std::ostream& Widget::writeSceneGraphJson(std::ostream &aOut, const std::string aIndent) const
{
  aOut << aIndent << "{" << std::endl
       << aIndent << "  \"type\": \"" << getWidgetTypeString() << "\"," << std::endl
       << aIndent << "  \"name\": \"" << getID() << "\"," << std::endl
       << aIndent << "  \"address\": \"" << this << "\"," << std::endl
       << aIndent << "  \"coord\": { \"x\": " << getX() << ", \"y\": " << getY() << " }," << std::endl
       << aIndent << "  \"size\": { \"width\": " << getWidth() << ", \"height\": " << getHeight() << " }," << std::endl
       << aIndent << "  \"hasKeyFocus\": " << (hasKeyFocus() ? "true" : "false") << "," << std::endl;

  writeSceneGraphExtraJson(aOut, aIndent + "  ");

  aOut << aIndent << "  \"children\":" << std::endl
       << aIndent << "  [" << std::endl;

  for (auto iter = children.begin(); iter != children.end(); ++iter)
  {
    (*iter)->writeSceneGraphJson(aOut, aIndent + "    ");

    if (children.size() > 1 && (iter + 1) != children.end())
    {
      aOut << ",";
    }

    aOut << std::endl;
  }

  aOut << aIndent << "  ]" << std::endl
       << aIndent << "}";

  return aOut;
}

const std::string& Widget::getWidgetTypeString() const
{
  static const std::string type("Widget");
  return type;
}

void Widget::writeSceneGraphExtraJson(std::ostream &aOut, const std::string aIndent) const
{
}

};
};
