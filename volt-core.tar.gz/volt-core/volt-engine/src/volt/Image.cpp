/*
 * Image.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi,jim.dinunzio
 */

#include "Image.h"
#include "ResourceLoader.h"
#include "StaticUI.h"
#include "VoltImage.h"

using namespace volt::util;

namespace volt
{
namespace graphics
{
std::string Image::LOGGER_NAME = "volt.image";

Image::Image():
  anim(nullptr), logger_(LOGGER_NAME), on_load_callbacks_(),
  uri_(), async_(true), textureFlags_(COGL_TEXTURE_NO_ATLAS), image_(nullptr),
  success_callback_(), error_callback_()
{
  LOG_DEBUG(logger_, "Born (" << this << ")");
}

Image::~Image()
{
  LOG_DEBUG(logger_, "Dead (" << this << "): " << uri());
  delete anim;

  if (image())
  {
    g_object_unref(image());
  }

  image_ = nullptr;
}

void Image::set_uri(const std::string &aUri)
{
  LOG_DEBUG(logger_, "Loading image: " << aUri);

  uri_ = aUri;

  ImageLoadedCallback callback = std::bind(&Image::OnImageLoaded,
                                 this,
                                 std::placeholders::_1,
                                 std::placeholders::_2);
  bool success =
    ResourceLoader::Instance().LoadImage(callback, uri(), async(), textureFlags_);

  /* Failure callback. */
  if (success == false)
  {
    callback(nullptr, false);
  }
}

void Image::set_noAtlas(bool noAtlas)
{
  if (noAtlas)
  {
    textureFlags_ = CoglTextureFlags(textureFlags_ | COGL_TEXTURE_NO_ATLAS);
  }
  else
  {
    textureFlags_ = CoglTextureFlags(textureFlags_ & ~COGL_TEXTURE_NO_ATLAS);
  }
}

void Image::set_noSlicing(bool noSlicing)
{
  if (noSlicing)
  {
    textureFlags_ = CoglTextureFlags(textureFlags_ | COGL_TEXTURE_NO_SLICING);
  }
  else
  {
    textureFlags_ = CoglTextureFlags(textureFlags_ & ~COGL_TEXTURE_NO_SLICING);
  }
}

void Image::set_noAutoMipmap(bool noAutoMipmap)
{
  if (noAutoMipmap)
  {
    textureFlags_ = CoglTextureFlags(textureFlags_ | COGL_TEXTURE_NO_AUTO_MIPMAP);
  }
  else
  {
    textureFlags_ = CoglTextureFlags(textureFlags_ & ~COGL_TEXTURE_NO_AUTO_MIPMAP);
  }
}

bool Image::RegisterOnLoadCallback(const ImageWidget *aWidget,
                                   OnLoadCallback aCallback)
{
  if (image())
  {
    LOG_DEBUG(logger_, "Image is already loaded, fire callback now: " << uri());
    aCallback(this);
    return true;
  }

  if (aWidget == nullptr)
  {
    LOG_WARN(logger_,
             "Cannot register a callback without the target ImageWidget");
    return false;
  }

  LOG_DEBUG(logger_, "Register callback for " << aWidget);
  on_load_callbacks_[aWidget] = aCallback;
  return true;
}

bool Image::UnregisterOnLoadCallback(const ImageWidget *aWidget)
{
  return on_load_callbacks_.erase(aWidget) > 0;
}

void Image::OnImageLoaded(VoltImage *aImage, bool aSuccess)
{
  if (aSuccess && aImage)
  {
    LOG_DEBUG(logger_, "Successfully loaded image: " << uri());
    image_ = aImage;
    g_object_ref(aImage);

    GdkPixbufAnimation* pixbufAnim = volt_image_get_pixbuf_anim(VOLT_IMAGE(aImage));
    gboolean isStatic = TRUE;

    if (pixbufAnim)
    {
      isStatic = gdk_pixbuf_animation_is_static_image(pixbufAnim);
    }

    if (success_callback().isFunction())
    {
      Bridge::ScriptArray arg;

      try
      {
        LOG_DEBUG(logger_, "Calling the success callback for " << uri());
        success_callback().invoke(arg);
      }
      catch (VoltJsRuntimeException &e)
      {
        volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute success "
            "image callback", &e);
      }
    }

    // if this is an animation then create the Animation instance and
    // start the animation
    if (!isStatic && pixbufAnim)
    {
      anim = new Image::Animation(this, pixbufAnim);
      anim->Play();
    }
  }
  else
  {
    LOG_WARN(logger_, "Failed to load image: " << uri());

    if (error_callback().isFunction())
    {
      Bridge::ScriptArray arg;

      try
      {
        LOG_DEBUG(logger_, "Calling the error callback for " << uri());
        error_callback().invoke(arg);
      }
      catch (VoltJsRuntimeException &e)
      {
        volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute error "
            "image callback", &e);
      }
    }
  }

  for (auto iter = on_load_callbacks_.begin();
       iter != on_load_callbacks_.end();
       ++iter)
  {
    LOG_DEBUG(logger_, "Invoke callback for " << iter->first);
    iter->second(this);
  }

  on_load_callbacks_.clear(); /* only call once. */
}

/**
 * This GSourceFunc is used to schedule redraws of the image animation
 * and is called when a timer expires.  See RenderFrame
 *
 * @author jim (3/13/2014)
 *
 * @param ia A pointer to the ImageAnimation instance
 *
 * @return gboolean TRUE to keep function registered, FALSE to unregister
 */
gboolean Image::ScheduleRedraw(Animation* ia)
{
  if (!ia)
  {
    return FALSE;
  }

  for_each(ia->image()->actors().begin(), ia->image()->actors().end(),
           [](ClutterActor* actor)
  {
    clutter_actor_queue_redraw(actor);
  });

  ia->set_sched_redraw_func_id(0);
  return FALSE;
}


/**
 * This GSourceFunc is called when a non-repeating image animation has finished
 * and is called when a timer expires. See RenderFrame
 *
 * @author jim (3/13/2014)
 *
 * @param ia A pointer to the Animation instance
 *
 * @return gboolean TRUE to keep function registered, FALSE to unregister
 */
gboolean Image::GifComplete(Animation* ia)
{
  if (ia->image()->onGifComplete)
  {
    ia->image()->onGifComplete();
  }

  return FALSE;
}

/**
 * This function is called before each image animation frame is rendered by
 * clutter to set the texture to the latest frame.  It is registered with
 * the clutter_threads_add_repaint_func_full() interface,
 *
 * @author jim (3/13/2014)
 *
 * @param ia A pointer to the Animation instance
 *
 * @return gboolean TRUE to keep function registered, FALSE to unregister
 */
gboolean Image::RenderFrame(Animation *ia)
{
  if (!ia)
  {
    return FALSE;
  }

  bool firstRender = false;
  GTimeVal gTime;

  if (!ia->iter())
  {
    ia->set_base_time(g_get_monotonic_time());
    ia->set_last_frame_time(ia->base_time());
  }
  else
  {
    gint64 curTime = g_get_monotonic_time();
    ia->set_elapsed_time(ia->elapsed_time() + (curTime - ia->last_frame_time()));
    ia->set_last_frame_time(curTime);
  }

  gint64 curTime = ia->base_time() + ia->elapsed_time();
  gTime.tv_sec = curTime / 1000000;
  gTime.tv_usec = curTime % 1000000;

  if (!ia->iter())
  {
    firstRender = true;
    VoltImage* image = VOLT_IMAGE(ia->image()->image());
    GdkPixbufAnimation* pixbufAnim;

    if (image)
    {
      pixbufAnim = volt_image_get_pixbuf_anim(image);
    }
    else
    {
      return FALSE;
    }

    ia->set_iter(gdk_pixbuf_animation_get_iter(pixbufAnim, &gTime));
  }

  if(firstRender || gdk_pixbuf_animation_iter_advance(ia->iter(), &gTime))
  {
    GdkPixbuf *pixbuf = gdk_pixbuf_animation_iter_get_pixbuf(ia->iter());

    if (pixbuf)
    {
      cairo_rectangle_int_t rect;
      rect.x = 0;
      rect.y = 0;
      rect.width = gdk_pixbuf_get_width (pixbuf);
      rect.height = gdk_pixbuf_get_height (pixbuf);

      volt_image_set_area (ia->image()->image(),
                           gdk_pixbuf_get_pixels (pixbuf),
                           COGL_TEXTURE_NO_ATLAS,
                           gdk_pixbuf_get_has_alpha (pixbuf)
                           ? COGL_PIXEL_FORMAT_RGBA_8888
                           : COGL_PIXEL_FORMAT_RGB_888,
                           &rect,
                           gdk_pixbuf_get_rowstride (pixbuf),
                           NULL);
    }

    int delay = gdk_pixbuf_animation_iter_get_delay_time(ia->iter());

    if (delay > 0)
    {
      ia->set_sched_redraw_func_id(
        g_timeout_add(delay, reinterpret_cast<GSourceFunc>(ScheduleRedraw), ia));
    }
  }

  // if we are finished animating, don't call RenderFrame anymore.
  if (gdk_pixbuf_animation_iter_get_delay_time(ia->iter()) < 0)
  {
    ia->set_repaint_func_id(0);
    clutter_threads_add_repaint_func_full(CLUTTER_REPAINT_FLAGS_POST_PAINT,
                                          reinterpret_cast<GSourceFunc>(GifComplete),
                                          ia, NULL);
    return FALSE;
  }

  return TRUE;
}

/**
 * Cancel animation on this Image which effects all ImageWidgets using this Image
 *
 * @author jim (3/14/2014)
 */
void Image::CancelGifAnimation()
{
  LOG_DEBUG(logger_, "Cancelling Gif Animation and freeing resources");
  delete anim;
  // free pixbuf animation
  volt_image_set_pixbuf_anim(VOLT_IMAGE(image()), NULL);
}

/**
 * Pause animation on this Image (effects all actors using this Image)
 *
 * @author jim (3/14/2014)
 */
void Image::PauseGifAnimation()
{
  LOG_DEBUG(logger_, "Pausing Gif Animation");

  if (anim)
  {
    anim->Stop();
  }
}

/**
 * Resume animation on this Image from last pause point (effects all actors using this Image)
 *
 * @author jim (3/14/2014)
 */
void Image::ResumeGifAnimation()
{
  LOG_DEBUG(logger_, "Resuming Gif Animation");

  if (anim)
  {
    // check if we are already playing.
    if (anim->IsPlaying())
    {
      return;
    }

    // if this is a resume from the last pause point, otherwise somebody rewinded.
    if (anim->iter())
      anim->set_last_frame_time(g_get_monotonic_time()
                                - 1000
                                * gdk_pixbuf_animation_iter_get_delay_time(anim->iter()));

    anim->Play();
    ScheduleRedraw(anim);
  }
}

/**
 * Restart animation on this Image (effects all actors using this Image)
 *
 */
void Image::RewindGifAnimation()
{
  LOG_DEBUG(logger_, "Restarting Gif Animation");

  if (anim)
  {
    bool isPlaying = anim->IsPlaying();
    anim->Stop();
    anim->Rewind();

    if (isPlaying)
    {
      anim->Play();
    }
  }
}

void Image::HandleDestroy()
{
  LOG_DEBUG(logger_, "HandleDestroy " << this);

  // disconnect the js side..
  for(auto iter = destructionCallbacks.begin(); iter != destructionCallbacks.end(); iter++)
  {
    (*iter)();
  }
}

/**
 * Add an actor to the list of actors that are using this Image
 *
 * @author jim (3/14/2014)
 *
 * @param actor actor that uses this Image. Redraw updates will be issued to all added actors.
 */
void Image::AddActor(ClutterActor* actor)
{
  actors_.push_back(actor);
}

/**
 * Remove an actor from the list of actors that are using this Image
 *
 * @author jim (3/14/2014)
 *
 * @param actor actor that no longer uses this Image.
 */
void Image::RemoveActor(ClutterActor* actor)
{
  auto iter = find(actors_.begin(), actors_.end(), actor);

  if (iter != actors_.end())
  {
    actors_.erase(iter);
  }
}

/**
 * Animation class implementation
 *
 * @author jim (3/14/2014)
 */
Image::Animation::~Animation()
{
  Stop();
  g_clear_object(&iter_);
}

/**
 * This rewinds the animation by
 * stopping it and clearing the iterator.
 *
 * @author jim (3/14/2014)
 */
void Image::Animation::Rewind()
{
  g_clear_object(&iter_);
}

/**
 * This stops the animation by
 * canceling the redraw and repaint callbacks.
 *
 * @author jim (3/14/2014)
 */
void Image::Animation::Stop()
{
  if (sched_redraw_func_id_ > 0)
  {
    g_source_remove(sched_redraw_func_id_);
    sched_redraw_func_id_ = 0;
  }

  if (repaint_func_id_ > 0)
  {
    clutter_threads_remove_repaint_func(repaint_func_id_);
    repaint_func_id_ = 0;
  }
}

/**
 * This starts playing the animation by adding a repaint func to clutter.
 *
 * @author jim (3/14/2014)
 */
void Image::Animation::Play()
{
  set_repaint_func_id(clutter_threads_add_repaint_func_full(
                        static_cast<ClutterRepaintFlags>(CLUTTER_REPAINT_FLAGS_QUEUE_REDRAW_ON_ADD |
                            CLUTTER_REPAINT_FLAGS_PRE_PAINT),
                        reinterpret_cast<GSourceFunc>(RenderFrame),
                        this, NULL));
}

// Events
void Image::registerDestructionEvent(ImageDestructionCallback callback)
{
  LOG_DEBUG(logger_, "JWS: registered destruct");
  destructionCallbacks.push_back(callback);
}

};
};
