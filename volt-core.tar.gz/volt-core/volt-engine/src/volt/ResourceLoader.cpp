/*
 * ResourceLoader.cpp
 *
 *  Created on: May 8, 2013
 *      Author: reza
 */

#include "ResourceLoader.h"

#include <functional>
#include <cstring>

#include "ResourceManager.h"
#include "NetworkIORequest.h"
#include "FileIORequest.h"
#include "VoltImage.h"
#include "DataBuffer.h"

#include "gdk-pixbuf/gdk-pixbuf-animation.h"

using namespace Resource;
using namespace volt::util;
using namespace volt::graphics;

std::string ResourceLoader::LOGGER_NAME = "volt.resource.loader";

ResourceLoader& ResourceLoader::Instance()
{
  static ResourceLoader singleton;
  return singleton;
}

ResourceLoader::ResourceLoader(): logger_(LOGGER_NAME)
{
}

ResourceLoader::~ResourceLoader()
{
}

bool ResourceLoader::LoadImage(ImageWidget *widget,
                               const DataBuffer::SharedPtr &buffer,
                               CoglTextureFlags textureFlags)
{
  if(not widget)
  {
    LOG_ERROR(logger_, "null widget pointer");
    return false;
  }

  GInputStream *input = NULL;
  GdkPixbufAnimation* pixbufAnim = CreatePixbufAnimFromBuffer(buffer, &input);

  if(pixbufAnim == NULL)
  {
    LOG_ERROR(logger_, "Failed load image from buffer");
    return false;
  }

  VoltImage *image = nullptr;
  bool success = LoadVoltImage(pixbufAnim, textureFlags, &image);

  widget->onImageLoaded(image, success);

  g_object_unref(image);
  return success;
}

bool ResourceLoader::LoadImage(ImageLoadedCallback aCallback,
                               const std::string &aUri, const bool aAsync,
                               CoglTextureFlags textureFlags)
{
  IORequest::SharedPtr request;

  if (aAsync)
  {
    Resource::NetworkIORequest::OnCompleteCallback callback =
      std::bind(&ResourceLoader::OnAsyncImageEvent,
                this, std::placeholders::_1, aCallback, textureFlags);

    request = ResourceManager::CreateRequest(aUri, callback);
  }
  else
  {
    request = ResourceManager::CreateRequest(aUri);
  }

  bool result = ResourceManager::Instance().Process(request);

  if (result == false)
  {
    LOG_WARN(logger_, "Failed to get image: " << aUri);
    return false;
  }

  if (aAsync == false)
  {
    /* Execute callback now. */
    if (request->response()->status() / 100 != 2)
    {
      /* discard anything other than 2XX */
      LOG_DEBUG(logger_,
                "Bad response code (" << request->response()->status() << ") "
                "for remote image: " << request->uri());
      return false;
    }

    GInputStream *input = NULL;
    GdkPixbufAnimation* pixbufAnim = CreatePixbufAnimFromIOResponse(request->response(),
                                     &input);

    if (pixbufAnim == NULL)
    {
      LOG_ERROR(logger_,
                "Failed to create pixbuf for remote image: " << request->uri());
      return false;
    }

    AsyncImageInfo *data =
      new AsyncImageInfo(request, pixbufAnim, input, aCallback, textureFlags);
    UpdateWidgetImageTask(data);
  }

  return true;
}

bool ResourceLoader::LoadString(const std::string &aUri, DataBuffer::SharedPtr &aData)
{
  IORequest::SharedPtr request(ResourceManager::CreateRequest(aUri));

  if (ResourceManager::Instance().Process(request) == false)
  {
    return false;
  }

  aData = request->response()->data()->getSharedPtr();
  return true;
}

void ResourceLoader::OnAsyncImageEvent(IORequest::SharedPtr aRequest,
                                       ImageLoadedCallback aCallback,
                                       CoglTextureFlags textureFlags)
{
  if (aRequest)
  {
    if (aRequest->response()->status() / 100 != 2)
    {
      /* discard anything other than 2XX */
      LOG_DEBUG(logger_,
                "Bad response code (" << aRequest->response()->status() << ") "
                "for remote image: " << aRequest->uri());
      clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                    NotifyFailedWidgetImageTask,
                                    new ImageLoadedCallback(aCallback), NULL);
      return;
    }

    GInputStream *input = NULL;
    GdkPixbufAnimation* pixbufAnim = CreatePixbufAnimFromIOResponse(aRequest->response(), &input);

    if (pixbufAnim == NULL)
    {
      LOG_ERROR(logger_,
                "Failed to create pixbuf for remote image: " << aRequest->uri());
      clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                    NotifyFailedWidgetImageTask,
                                    new ImageLoadedCallback(aCallback), NULL);
      return;
    }

#if 0
    /* volt_image_set_data segfaults if called here.
     * Probably because it internally uses gl* API and this thread does not
     * have the GL context. */
    VoltImage* image = VOLT_IMAGE(volt_image_new());
    volt_image_set_data(image,
                        gdk_pixbuf_get_pixels (pixbuf),
                        gdk_pixbuf_get_has_alpha (pixbuf)
                        ? COGL_PIXEL_FORMAT_RGBA_8888
                        : COGL_PIXEL_FORMAT_RGB_888,
                        gdk_pixbuf_get_width (pixbuf),
                        gdk_pixbuf_get_height (pixbuf),
                        gdk_pixbuf_get_rowstride (pixbuf),
                        NULL);
    g_object_unref(pixbuf);
#endif

    /* Send it to the main clutter thread */
    AsyncImageInfo *data =
      new AsyncImageInfo(aRequest, pixbufAnim, input, aCallback, textureFlags);
    clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                  UpdateWidgetImageTask, data, NULL);

  }
  else
  {
    LOG_WARN(logger_, "Request object not given");
  }
}

GdkPixbufAnimation*
ResourceLoader::CreatePixbufAnimFromIOResponse(IOResponse::SharedPtr aResponse,
    GInputStream **aInput)
{
  GdkPixbufAnimation *pixbufAnim = CreatePixbufAnimFromBuffer(aResponse->data(), aInput);;

  if (pixbufAnim == nullptr)
  {
    LOG_ERROR(logger_,
              "Failed to create pixbuf for remote image: " << aResponse->uri());
  }

  return pixbufAnim;
}

GdkPixbufAnimation*
ResourceLoader::CreatePixbufAnimFromBuffer(const volt::util::DataBuffer::SharedPtr &buffer,
    GInputStream **aInput)
{
  if(not buffer.get() or not buffer->data() or not buffer->length())
  {
    return nullptr;
  }

  *aInput =
    g_memory_input_stream_new_from_data(buffer->data(), buffer->length(),
                                        ResourceLoader::DeleteCharArray);

#if defined(GDK_PIXBUF_MAJOR) && GDK_PIXBUF_MAJOR >= 2 && \
    defined(GDK_PIXBUF_MINOR) && GDK_PIXBUF_MINOR >= 28
  GdkPixbufAnimation* pixbufAnim = gdk_pixbuf_animation_new_from_stream(*aInput, NULL, NULL);

  if (pixbufAnim == nullptr)
  {
    LOG_ERROR(logger_, "Failed to create pixbuf");
  }

  return pixbufAnim;

#else
  /* Can't create GdkPixbufAnimation from stream...
   * Save stream to a temp file and load from file. */
  char tmp_name[] = "/tmp/volt-tmp-XXXXXX";
  int tmp_fd = mkstemp(tmp_name);

  if (tmp_fd < 0)
  {
    return nullptr;
  }

  ssize_t bytes_written = 0;
  size_t offset = 0;
  ssize_t bytes_left = buffer->length();

  while (bytes_left > 0)
  {
    bytes_written = write(tmp_fd, buffer->data() + offset, bytes_left);

    if (bytes_written < 0)
    {
      LOG_ERROR(logger_, "Failed to save image data");
      close(tmp_fd);
      return nullptr;
    }

    offset += bytes_written;
    bytes_left -= bytes_written;
  }

  close(tmp_fd);

  GError *error = nullptr;
  GdkPixbufAnimation* pixbufAnim = gdk_pixbuf_animation_new_from_file(tmp_name, &error);

  if (pixbufAnim == nullptr)
  {
    LOG_ERROR(logger_, "Failed to create pixbuf for image" << error->message);
    g_error_free(error);
  }

  unlink(tmp_name);

  return pixbufAnim;
#endif
}

gboolean ResourceLoader::UpdateWidgetImageTask(gpointer aData)
{
  Logger logger(ResourceLoader::LOGGER_NAME);

  AsyncImageInfo *async_data = reinterpret_cast<AsyncImageInfo *>(aData);

  LOG_DEBUG(logger, "Got image data: " << async_data->request->uri());

  UpdateWidgetImage(async_data->callback, async_data->pixbufAnim, async_data->request->uri(),
                    async_data->textureFlags);

  delete async_data;

  return FALSE;
}

gboolean ResourceLoader::NotifyFailedWidgetImageTask(gpointer aData)
{
  ImageLoadedCallback *callbackFunctorPtr = reinterpret_cast<ImageLoadedCallback *>(aData);
  (*callbackFunctorPtr)(nullptr, false);
  delete callbackFunctorPtr;
  return FALSE;
}

void ResourceLoader::DeleteCharArray(gpointer aArray)
{
  //  char *array = reinterpret_cast<char *>(aArray);
  //  delete [] array;
}

bool ResourceLoader::LoadVoltImage(GdkPixbufAnimation *aPixbufAnim,
                                   CoglTextureFlags textureFlags, VoltImage **image)
{
  GError* error = NULL;
  *image = VOLT_IMAGE(volt_image_new());

  if (aPixbufAnim == nullptr)
  {
    LOG_WARN(Logger::DefaultLogger(), "No pixbuf given");
    return false;
  }

  gboolean isStatic = gdk_pixbuf_animation_is_static_image(aPixbufAnim);
  bool success = true;

  if (isStatic)
  {
    GdkPixbuf *aPixbuf = gdk_pixbuf_animation_get_static_image(aPixbufAnim);

    volt_image_set_data(*image,
                        gdk_pixbuf_get_pixels (aPixbuf),
                        textureFlags,
                        gdk_pixbuf_get_has_alpha (aPixbuf)
                        ? COGL_PIXEL_FORMAT_RGBA_8888
                        : COGL_PIXEL_FORMAT_RGB_888,
                        gdk_pixbuf_get_width (aPixbuf),
                        gdk_pixbuf_get_height (aPixbuf),
                        gdk_pixbuf_get_rowstride (aPixbuf),
                        &error);

    if (error != NULL)
    {
      LOG_ERROR(Logger::DefaultLogger(), "Error loading image, error: " << error->message <<
                ". Possible causes: out of texture memory or invalid size/format of image.");
      g_error_free(error);
      success = false;
    }
    else
    {
      volt_image_set_pixbuf_anim(*image, aPixbufAnim);
    }

    g_object_unref(aPixbufAnim);
  }
  else
  {
    volt_image_set_pixbuf_anim(*image, aPixbufAnim);
    g_object_unref(aPixbufAnim);
  }

  return success;
}

void ResourceLoader::UpdateWidgetImage(ImageLoadedCallback aCallback,
                                       GdkPixbufAnimation *aPixbufAnim, const std::string& uri,
                                       CoglTextureFlags textureFlags)
{
  VoltImage *image = NULL;
  bool success = LoadVoltImage(aPixbufAnim, textureFlags, &image);

  /* Give the newly created image to the Widget callback. */
  aCallback(image, success);

  g_object_unref(image);
}
