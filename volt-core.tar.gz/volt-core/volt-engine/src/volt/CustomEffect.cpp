/*
 * CustomEffect.cpp
 *
 *  Created on: July 21, 2013
 *      Author: jim dinunzio
 */

#include "CustomEffect.h"

G_DEFINE_TYPE (CCustomEffect, custom_effect, CLUTTER_TYPE_EFFECT);

static void
custom_effect_paint (ClutterEffect *effect, ClutterEffectPaintFlags flags)
{
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (effect));
  g_return_if_fail (IS_CUSTOM_EFFECT(effect));
  CCustomEffect* customEffect = CUSTOM_EFFECT(effect);
  gboolean pre_paint_result = false;

  // Call CustomEffect pre_paint() callback for work tbd before other effects and drawing of actor
  if (customEffect->pre_paint_cb != NULL)
  {
    pre_paint_result = (*customEffect->pre_paint_cb)(customEffect);
  }

  clutter_actor_continue_paint(actor);

  // Call CustomEffect post_paint() callback for work tbd after other effects and drawing of actor
  if (customEffect->post_paint_cb != NULL && pre_paint_result)
  {
    (*customEffect->post_paint_cb)(customEffect);
  }
}

/* GObject implementation */
static void
custom_effect_dispose (GObject *gobject)
{
  G_OBJECT_CLASS (custom_effect_parent_class)->dispose (gobject);
}

static ClutterEffect* custom_effect_clone_for_render_thread(ClutterEffect   *sourceCustomEffect)
{
	CCustomEffect *dstEffect = NULL;
	CCustomEffect *srcEffect = CUSTOM_EFFECT(sourceCustomEffect);
	if(srcEffect->copy_effect == NULL)
	{
		srcEffect->copy_effect = custom_effect_new();
	}
	dstEffect = CUSTOM_EFFECT(srcEffect->copy_effect);
	dstEffect->pre_paint_cb = srcEffect->pre_paint_cb;
	dstEffect->post_paint_cb = srcEffect->post_paint_cb;
	
	return CLUTTER_EFFECT(srcEffect->copy_effect);
}
/* GObject class and instance init */
static void
custom_effect_class_init (CCustomEffectClass *klass)
{
  ClutterEffectClass *effect_class = CLUTTER_EFFECT_CLASS (klass);
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  effect_class->paint = custom_effect_paint;
  effect_class->clone_for_render_thread   = custom_effect_clone_for_render_thread;
  gobject_class->dispose = custom_effect_dispose;
}


static void
custom_effect_init (CCustomEffect *self)
{
  self->pre_paint_cb = NULL;
  self->post_paint_cb = NULL;
  self->copy_effect = NULL;
}



void custom_effect_set_pre_paint_cb (CCustomEffect* self, PrePaintCallback cb)
{
  self->pre_paint_cb = cb;
}

void custom_effect_set_post_paint_cb (CCustomEffect* self, PostPaintCallback cb)
{
  self->post_paint_cb = cb;
}


/* public API */

/**
 * custom_effect_new:
 *
 * Creates a new #CCustomEffect
 */
ClutterEffect *
custom_effect_new ()
{
  return (ClutterEffect*)g_object_new (TYPE_CUSTOM_EFFECT, NULL);
}

#ifndef STAND_ALONE
/* CustomEffect Implementation */

CustomEffect::CustomEffect()
{
  setEffect(custom_effect_new());
}

CustomEffect::~CustomEffect()
{
}

#endif // STAND_ALONE
