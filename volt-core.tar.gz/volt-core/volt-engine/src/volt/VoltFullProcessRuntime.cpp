#include "VoltFullProcessRuntime.h"

#include <app.h>
#include <Ecore.h>
#include <Ecore_X.h>
#include <Elementary.h>

#include <v8/v8.h>
#include <v8/v8-debug.h>

#include "Version.h"

#include "VoltMessageCenter.h"
#include "VoltRuntimeMessages.h"
#include "Volt.h"

#include "AppConfig.h"
#include "TaskDispatcher.h"
#include "ResourceManager.h"
#include "FileIORequest.h"
#include "StaticUI.h"
#include "CacheManager.h"
#include "Environment.h"
#include "RuntimeProfile.h"

#include "ScriptBridge.h"
#include "WidgetBridge.h"
#include "VoltDefaultBridge.h"
#include "SefBridge.h"
#include "TextWidgetBridge.h"
#include "ImageBridge.h"
#include "ImageWidgetBridge.h"
#include "ResourceBridge.h"
#include "SceneRootBridge.h"
#include "ListWidgetBridge.h"
#include "FrameBridge.h"
#include "AnimationBridge.h"

#include "NinePatchWidgetBridge.h"
#include "VoltWorkerBridge.h"
#include "VideoWidgetBridge.h"
#include "VconfBridge.h"
#include "AulBridge.h"
#include "ServiceBridge.h"
#include "SystemInfoBridge.h"
#include "VDUtilBridge.h"
#include "LogBridge.h"
#include "FirstScreenListWidgetBridge.h"
#include "VoltTTSBridge.h"
#include "WebSocketBridge.h"
#include "SmartHubResetBridge.h"

#include "event_manager.h"
#include "clutter_helper.h"
#include "logger.h"

#include <sys/prctl.h>

#ifndef PR_TASK_PERF_USER_TRACE
#define PR_TASK_PERF_USER_TRACE 666
#endif

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include "system_info.h"
#endif

#ifdef BUILD_TEST
#include "gtest/gtest.h"
#endif

using namespace volt::util;
using namespace volt::util::ipc;

extern funcP HaloInitialize;
extern funcP HaloFinalize;
Logger VoltFullProcessRuntime::LOGGER("volt.proc.worker");

VoltFullProcessRuntime::VoltFullProcessRuntime():
VoltProcessRuntime(),
	script_engine_(), worker_bridge_(NULL), main_stage_(NULL),
	scene_root_(NULL), loading_script_(false), clutter_running_(false),
	quitting_(false)
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
	, return_to_prev_app_(false)
#else
	, signal_handlers_()
#endif
{
}

VoltFullProcessRuntime::~VoltFullProcessRuntime()
{
}

Bridge::ScriptEngine* VoltFullProcessRuntime::GetScriptEngine() const
{
  return script_engine_.get();
}

ClutterActor* VoltFullProcessRuntime::GetMainStage() const
{
	return main_stage_;
}

void VoltFullProcessRuntime::RegisterPluginBridge(Bridge::ScriptBridge* bridge)
{
	script_engine_->addBridge(bridge);
}

volt::graphics::SceneRoot*  VoltFullProcessRuntime::GetSceneRoot() const
{
	return scene_root_;
}

void VoltFullProcessRuntime::ShowUI(const VoltEventArgsMap &aArgs)
{
	LOG_DEBUG(LOGGER, "Showing the app UI");

	if (GetSceneRoot())
	{
		GetSceneRoot()->show();
	}

	script_engine_->sendInteruptEvent(volt::util::ON_RESUME, aArgs);

#if defined(BUILD_FOR_TV) && defined(TIZEN)
	/* Managed by EFL */
#else
	ShowXWindow();
#endif

#if defined(BUILD_FOR_TV) && defined(BUILD_EMP) && !defined(TIZEN)
	/* Change screen resolution to the expected resolution. */

	/* TODO: Need to make sure what the current UI resolution is.  If the app
	* changed the screen resolution (using the Screen EMP), then this will
	* switch to the initial resolution (as set in config.xml).  I suppose the
	* app can set resolution on ON_RESUME handler for now... */
	int width, height, windowWidth, windowHeight;
	float dummy;
	GetScreenDimensions(width, height, windowWidth, windowHeight, dummy, dummy);

	ChangeScreenResolution(windowWidth, windowHeight);
#endif
}

void VoltFullProcessRuntime::HideUI(const VoltEventArgsMap &aArgs)
{
	LOG_DEBUG(LOGGER, "Hiding the app UI");

	if (GetSceneRoot())
	{
		GetSceneRoot()->hide();
	}

#if defined(BUILD_FOR_TV) && defined(TIZEN)
	/* Managed by EFL */
#else
	HideXWindow();
#endif

	script_engine_->sendInteruptEvent(volt::util::ON_PAUSE, aArgs);
}

void VoltFullProcessRuntime::ResetApp(const VoltEventArgsMap &aArgs)
{
	LOG_DEBUG(LOGGER, "Resetting the app");

	/* Volt engine does not support "reset"...
	* Just send the ON_RESET signal to app to let it reset itself... */
	try
	{
		script_engine_->sendInteruptEvent(volt::util::ON_RESET, aArgs);
	}

	catch(...)
	{
		LOGE("ResetApp Fail!");
	}
}

bool VoltFullProcessRuntime::ReturnToPrevApp() const
{
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
	return return_to_prev_app_;
#else
	return false;
#endif
}

void VoltFullProcessRuntime::SetReturnToPrevApp(const bool aFlag)
{
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
	return_to_prev_app_ = aFlag;
#endif
}

bool VoltFullProcessRuntime::IsPathAllowed(const char *aPath)
{
	if (aPath == NULL)
	{
		return false;
	}

	/* TODO: Don't hardcode; make me configurable... */
#ifdef BUILD_FOR_TV
#ifdef TIZEN
	/* Temporarily allow access to the entire filesystem.,
	* Let's make the list of allowed paths configrable in future... */
	return true;

	static const char *usb_dir_prefix = "/opt/storage/usb/sd";
#else
	static const char *usb_dir_prefix = "/dtv/usb/sd";
#endif
#else
	static const char *usb_dir_prefix = "/media/";
#endif

	if (strncmp(aPath, usb_dir_prefix, strlen(usb_dir_prefix)) == 0)
	{
		static Logger logger("volt.resource");
		LOG_DEBUG(logger, "Allowing access to usb/media: " << aPath);
		return true;
	}

	return false;
}

bool VoltFullProcessRuntime::Initialize(int aArgc, char **aArgv,
	const VoltEngine::ExternalData &aData)
{
	prctl(PR_TASK_PERF_USER_TRACE, "-------------------------VOLT engine start-------------------------", strlen("-------------------------VOLT engine start-------------------------"));
	
	LOG_INFO(LOGGER, "Initializing Volt full process version " << VOLT_VERSION);

	if (VoltProcessRuntime::Initialize(aArgc, aArgv, aData) == false)
	{
		LOG_FATAL(LOGGER, "Failed to initialize Volt full process version " << VOLT_VERSION);
		return false;
	}

  bool enable_voltworker = AppConfig::Instance().GetValue<std::string>("enable-voltworker") == "true";

  if(enable_voltworker)
  {
	  if (InitializeIPC() == false)
	  {
		LOG_FATAL(LOGGER, "Failed to initialize IPC");
		return false;
		}
	}

	TaskDispatcher::Instance().Initialize();

	Resource::ResourceManager::Instance().StartWorkerThread();

	Resource::FileIORequest::AllowedPathChecker = VoltFullProcessRuntime::IsPathAllowed;

	Resource::NetworkIORequest::InitSharedState();

	if (AppConfig::Instance().IsSet("run-test"))
	{
#ifdef BUILD_TEST
		::testing::InitGoogleTest(&aArgc, aArgv);
		int result = RUN_ALL_TESTS();
		return result == 0;
#else
		LOG_FATAL(LOGGER, "Unit test is not included in this build.");
		return false;
#endif
	}

	if (VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS)
	{
		if (AppConfig::Instance().GetValue<std::string>("enable-device-profile") == "true")
		{
			/* Device/platform specific config */
			SetDeviceConfig();
		}

		if (PrepareClutter() < 0)
		{
			LOG_FATAL(LOGGER, "Failed to initialize graphics backend");
			return false;
		}
	}

	/* Initialize clutter even for worker process because it's still needed for
	* handling async/timeout tasks. */
	if (clutter_init(&aArgc, &aArgv) != CLUTTER_INIT_SUCCESS)
	{
		LOG_FATAL(LOGGER, "Failed to initialize graphics backend");
		return false;
	}

	/* Create V8 instance */
	std::string enable_gc = AppConfig::Instance().GetValue<std::string>("enable-gc");
	script_engine_.reset(new Bridge::ScriptEngine(enable_gc == "true"));
	// script_engine_.reset(new Bridge::ScriptEngine(true));

	if (VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS)
	{
		InitializeGraphics();
	}

	RegisterJsBridges(aData.bridges);

	/* Finally, the script engine is ready! */
	script_engine_->ready();

	/* Enable v8 debugger? */
	if (AppConfig::Instance().GetValue<std::string>("debugger.enable") == "true")
	{
		unsigned int port = AppConfig::Instance().GetValue<unsigned int>("debugger.port");
		LOG_INFO(LOGGER, "Enabling debugger agent on port " << port);
		v8::Debug::EnableAgent("volt", port, true);
	}

  /* Start message receiving loop after the clutter's event loop starts
   * because VoltMessageCenter uses clutter_threads_add_idle_full to pass data
   * to the clutter thread. */
  if(enable_voltworker)
  {
	  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
					[](gpointer aData) -> gboolean
	  {
		VoltMessageCenter::Instance().StartMainLoopThread();
		return FALSE;
	  }, NULL, NULL);
  }

	bool retval = false;

	try
	{
		if (AppConfig::Instance().GetValue<std::string>("profiler.enable") == "true")
		{
			//v8::V8::ResumeProfiler(); //this API was removed from V8 3.26
		}

		std::string appjs = AppConfig::Instance().GetRelativeAppJsPath();

		if(appjs.empty())
		{
			volt::StaticUI::Instance().ShowExceptionPopup("No script file loaded");
			retval = true;
		}
		else
		{
			if (VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS &&
				AppConfig::Instance().GetValue<std::string>("show-splash") == "true")
			{
				/* Schedule to show the splash screen when the main loop starts.
				* It will be hidden once the JS is loaded (handled in StaticUI). */
				volt::StaticUI::Instance().ShowSplashScreen(appjs, aData.eventArgs,
					AppConfig::Instance().GetValue<std::string>("app-name"),
					AppConfig::Instance().GetValue<std::string>("app-icon"));
				retval = true;
			}
			else
			{
				/* Needed to handle the case when Volt.exit is called in
				* ON_LOAD/ON_SHOW/initialize. */

				if (script_engine_->loadScript(appjs, aData.eventArgs))
				{
					retval = true;
				}
			}
		}
	}
	catch (VoltJsInitException &e)
	{
		LOG_FATAL(LOGGER, "Exiting due to JS initialization error: " << e.what());
		/* clutter main loop not started yet */
		volt::StaticUI::Instance().ShowExceptionPopup("Encountered fatal error on "
			"initialization", &e);
		retval = true;
	}
	catch (VoltJsRuntimeException &e)
	{
		LOG_FATAL(LOGGER, "Exiting due to JS runtime error: " << e.what());
		/* clutter main loop already started; but broken out of it...
		* Can't show a popup from here... */
	}
	catch (std::exception &e)
	{
		LOG_FATAL(LOGGER, "Unhandled exception: " << e.what());
	}

	loading_script_ = false;
	return retval;
}

bool VoltFullProcessRuntime::Main()
{
	LOG_INFO(LOGGER, "Starting Volt full process version " << VOLT_VERSION);
	clutter_running_ = true;
	clutter_main();
	return true;
}

void VoltFullProcessRuntime::Quit()
{
	if (loading_script_)
	{
		/* Cannot quit just yet because the main loop hasn't started yet.
		* Schedule to quit immediately after the loop starts. */
		clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
			[](gpointer aData) -> gboolean
		{
			VoltProcessManager::Instance().Runtime()->Quit();
			return FALSE;
		}, NULL, NULL);
		return;
	}

	LOG_INFO(LOGGER, "Quitting Volt full process version " << VOLT_VERSION);

	if(not quitting_)
	{
		quitting_ = true;

		if (script_engine_)
		{
			script_engine_->sendInteruptEvent(volt::util::ON_HIDE);
			script_engine_->sendInteruptEvent(volt::util::ON_UNLOAD);
		}

		if (clutter_running_)
		{
			clutter_main_quit();
		}

		clutter_running_ = false;

    bool enable_voltworker = AppConfig::Instance().GetValue<std::string>("enable-voltworker") == "true";

    if(enable_voltworker)
    {
    	VoltMessageCenter::Instance().StopMainLoop();
    }

		if (event_handlers_.onTerminate)
		{
			event_handlers_.onTerminate();
		}

		elm_exit();
	}
}

void VoltFullProcessRuntime::Cleanup()
{
	LOG_INFO(LOGGER, "Cleaning up Volt full process version " << VOLT_VERSION);

	if (AppConfig::Instance().GetValue<std::string>("profiler.enable") == "true")
	{
		//v8::V8::PauseProfiler(); ////this API was removed from V8 3.26
	}

	VoltProcessManager::Instance().StopWorkerProcesses();

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
#else
	/* Handlers may have been disconnected already in OnStageDestroy */
#ifdef BOOST_NO_CXX11_RANGE_BASED_FOR

	for (auto iter = signal_handlers_.begin();
		iter != signal_handlers_.end(); ++iter)
	{
		LOG_DEBUG(LOGGER, "Disconnecting signal: " << *iter);
		g_signal_handler_disconnect(main_stage_, *iter);
	}

#else

	for (auto handler: signal_handlers_)
	{
		LOG_DEBUG(LOGGER, "Disconnecting signal: " << handler);
		g_signal_handler_disconnect(main_stage_, handler);
	}

#endif
	signal_handlers_.clear();
#endif

	Resource::CacheManager::Instance().SaveCatalog();

	volt::StaticUI::Instance().Detach();

	/* main_stage_ may have been reset already in OnStageDestroy */
	if (main_stage_)
	{
		DestroyStage(&main_stage_);
	}

	main_stage_ = NULL;

	script_engine_.reset();

	Resource::ResourceManager::Instance().StopWorkerThread();
	Resource::ResourceManager::Instance().JoinWorkerThread();

	Resource::NetworkIORequest::CleanSharedState();
}

bool VoltFullProcessRuntime::InitializeIPC()
{
	VoltMessageCenter::Instance().PrepareInstance();
	VoltMessageCenter::Instance().Initialize();

	if (VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS)
	{
		if (VoltMessageCenter::Instance().InitializeOnApp() == false)
		{
			LOG_FATAL(LOGGER, "Failed to initialize VoltMessageCenter");
			return false;
		}
	}
	else
	{
		if (VoltMessageCenter::Instance().InitializeOnWorker() == false)
		{
			LOG_FATAL(LOGGER, "Failed to initialize VoltMessageCenter");
			return false;
		}
	}

  VoltMessageCenter::Instance().RegisterHandlerOnSelf(VoltRuntimeMsg::Quit(),
      [this] (volt::util::ipc::Message *aMsg)
  {
    LOG_DEBUG(LOGGER, "Got Quit msg");
    Quit();
  });

  VoltMessageCenter::Instance().RegisterHandlerOnSelf(VoltRuntimeMsg::WorkerMessage(),
      [this] (volt::util::ipc::Message *aMsg)
  {
    char *msg = static_cast<char *>(aMsg->GetData());
    LOG_INFO(LOGGER, "Got WorkerMessage: " << msg);

    /* Check if the msg is from a worker. */
    if (worker_bridge_ and worker_bridge_->FindWorker(aMsg->ReplyTo()))
    {
      worker_bridge_->HandleWorkerMessage(aMsg->ReplyTo(), msg);
    }
    else
    {
      script_engine_->sendWorkerMessageEvent(msg);
    }
  }); 

  VoltMessageCenter::Instance().RegisterHandlerOnSelf(VoltRuntimeMsg::WorkerCommand(),
      [this] (volt::util::ipc::Message *aMsg)
  { 
    Command *cmd = reinterpret_cast<Command *>(aMsg);

    char *msg = static_cast<char *>(cmd->GetData());
    LOG_INFO(LOGGER, "Got WorkerCommand: " << msg);

    /* Result of the command execution.
     * This is a vector because a worker could possibly have multiple
     * listeners for ON_COMMAND event.
     * The last element of this vector will have either 0 or 1 for
     * successful and erroneous execution, respectively. */
    std::vector<std::string> results;

    std::string result;

    if (worker_bridge_ and worker_bridge_->FindWorker(cmd->ReplyTo()))
    {
      /* Executing a command from a worker process. */
      if (worker_bridge_->HandleWorkerCommand(cmd->ReplyTo(), msg, result))
      {
        /* Put a marker char at the end to indicate success/failure of
         * handling worker command in JS... */
        results.push_back(result);
        results.push_back("0"); /* Success */
      }
      else
      {
        results.push_back("1"); /* Fail */
      }
    }
    else
    {
      /* Executing a command from the parent. */
      if (script_engine_->sendWorkerCommandEvent(msg, results))
      {
        results.push_back("0"); /* Success */
      }
      else
      {
        results.push_back("1"); /* Fail */
      }
    }

    volt::util::ipc::BufferType buffer;

    if (volt::util::ipc::Serialize(results, buffer))
    {
      cmd->SetResult(&buffer[0], buffer.size());
    }
    else
    {
      LOG_ERROR(LOGGER, "Failed to serialize WorkerCommand result");
      cmd->SetResult(NULL, 0);
    }
  });

  VoltMessageCenter::Instance().RegisterHandlerOnSelf(VoltRuntimeMsg::OnException(),
      [this] (volt::util::ipc::Message *aMsg)
  {
    if(worker_bridge_)
    {
        char *msg = static_cast<char *>(aMsg->GetData());
        LOG_TRACE(LOGGER, "Got OnException from worker " << aMsg->ReplyTo() << ": " << msg);
    	worker_bridge_->HandleWorkerError(aMsg->ReplyTo(), msg);
    }
  });

	return true;
}

bool VoltFullProcessRuntime::SetDeviceConfig()
{
	/* Volt environment info */
	volt::Environment env;

	/* Runtime profile for dynamic performance adaptation */
	volt::RuntimeProfile profile;

	if (AppConfig::Instance().GetValue<std::string>("enable-device-profile") == "true")
	{
		/* Get info of the device VOLT is running on. */
		env.UpdateDeviceInfo();
	}

	/* Set performance profile for this device. */
	profile.SetDeviceProfile(env.device_type(), env.device_code());

	if (AppConfig::Instance().GetValue<int>("target-fps") <= 0 &&
		profile.target_fps() > 0)
	{
		LOG_DEBUG(LOGGER, "Setting target FPS to " << profile.target_fps());
		char fps_buf[16];
		snprintf(fps_buf, sizeof(fps_buf), "%d", profile.target_fps());
		setenv("CLUTTER_DEFAULT_FPS", fps_buf, 1);
	}

	LOG_DEBUG(LOGGER, "max-cache-size: " << profile.max_cache_size());

	if (profile.max_cache_size() > 0)
	{
		Resource::CacheManager::Instance().SetMaxSize(profile.max_cache_size());
	}

	return true;
}

bool VoltFullProcessRuntime::InitializeGraphics()
{
	/* Initialize for the graphics components. */

	/* Font anti-aliasing */
	int font_aa = AppConfig::Instance().GetValue<int>("font-aa");

	if (font_aa < -1 || font_aa > 1)
	{
		font_aa = -1;  // default
	}

	LOG_INFO(LOGGER, "Setting font anti-aliasing to " <<
		(font_aa == 1 ? "ON" : (font_aa == 0 ? "OFF" : "DEFAULT")));
	GValue val = G_VALUE_INIT;
	g_value_init(&val, G_TYPE_INT);
	g_value_set_int(&val, font_aa);
	g_object_set_property(G_OBJECT(clutter_settings_get_default()),
		"font-antialias", &val);
	g_value_unset (&val);

	/* Get screen/window info */
	int sceneWidth = 0, sceneHeight = 0, windowWidth = 0, windowHeight = 0;
	float scaleX = 1, scaleY = 1;
	GetScreenDimensions(sceneWidth, sceneHeight, windowWidth, windowHeight, scaleX, scaleY);

#if defined(BUILD_FOR_TV) && defined(BUILD_EMP)
	ChangeScreenResolution(windowWidth, windowHeight);
#endif
//	if (AppConfig::Instance().IsFirstScreen() || AppConfig::Instance().IsTutorial())
//	{
		int value = 0;
		int systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT, &value);

		if(systemResult != SYSTEM_INFO_ERROR_NONE)
		{
			LOG_FATAL(LOGGER, "Failed to get value for Resolution[" << SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT << "]" );
		}
		else if(value == 720)
		{
			LOG_FATAL(LOGGER, "SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT = [" << value << "]");
			sceneWidth = 1920;
			sceneHeight = 1080;
			windowWidth = 1280;
			windowHeight = 720;
			scaleX = 1280.0f / 1920.0f;
			scaleY = 720.0f / 1080.0f;
			LOG_FATAL(LOGGER, "sceneWidth = [" << sceneWidth << "] " << "sceneHeight" << "[" << sceneHeight << "]");
			LOG_FATAL(LOGGER, "windowWidth = [" << windowWidth << "] " << "windowHeight" << "[" << windowHeight << "]");
		}
		else
		{
			LOG_FATAL(LOGGER, "SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT = [" << value << "]");
			LOG_FATAL(LOGGER, "sceneWidth = [" << sceneWidth << "] " << "sceneHeight" << "[" << sceneHeight << "]");
			LOG_FATAL(LOGGER, "windowWidth = [" << windowWidth << "] " << "windowHeight" << "[" << windowHeight << "]");		
		}
//	}

	/* Create a new clutter main stage */
	main_stage_ = CreateNewStage(windowWidth, windowHeight, windowWidth, windowHeight);

	if (main_stage_ == NULL)
	{
		LOG_FATAL(LOGGER, "Failed to create main stage.");
		return false;
	}

	/* Name the X window we are using. */
	SetXWindowName("VOLT - " + AppConfig::Instance().GetValue<std::string>("app-name"));

	if (AppConfig::Instance().GetValue<std::string>("clutter.stage_clear") != "true")
	{
		clutter_stage_set_no_clear_hint(CLUTTER_STAGE(main_stage_), TRUE);
	}

	/* Create a new SceneRoot object */
	scene_root_ = new SceneRoot(main_stage_, sceneWidth, sceneHeight, scaleX, scaleY);
	scene_root_->setColor(Color(0, 0, 0, 0));

	if(!AppConfig::Instance().GetValue<bool>("use-perspective"))
	{
		scene_root_->useOrthographicProjection();
	}

	/* Supply info needed to construct UI */
	volt::StaticUI::Instance().Attach(script_engine_.get());

	/* Connect input event handlers. */
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
	EventManager::Instance().SetStage(CLUTTER_STAGE(GetMainStage()));
	EventManager::Instance().SetRemoteControlEventCallback(OnKeyEvent, this);
	EventManager::Instance().SetMouseEventCallback(OnMouseEvent);
	EventManager::Instance().SetFlickEventCallback(OnFlickEvent, this);
	EventManager::Instance().SetShowHideEventHandlers(OnShowEvent, this,
		OnHideEvent, this);
#else
	gulong handler =
		g_signal_connect(main_stage_, "destroy", G_CALLBACK(OnStageDestroy), this);
	signal_handlers_.push_back(handler);

	handler =
		g_signal_connect(main_stage_, "activate", G_CALLBACK(OnStageActivate), this);
	signal_handlers_.push_back(handler);

	handler =
		g_signal_connect(main_stage_, "deactivate", G_CALLBACK(OnStageDeactivate), this);
	signal_handlers_.push_back(handler);

	handler =
		g_signal_connect(main_stage_, "key-press-event", G_CALLBACK(OnKeyEvent), this);
	signal_handlers_.push_back(handler);

	handler =
		g_signal_connect(main_stage_, "key-release-event", G_CALLBACK(OnKeyEvent), this);
	signal_handlers_.push_back(handler);
	
	if(AppConfig::Instance().IsFirstScreen())
	{
		LOG_INFO(LOGGER, "FirstScreen is conneted to objectdump");
		
	handler =
		g_signal_connect(main_stage_, "objectdump", G_CALLBACK(OnObjectDump), this);
	}
	signal_handlers_.push_back(handler);
#endif

	return true;
}

bool VoltFullProcessRuntime::RegisterJsBridges(const VoltEngine::BridgeList &aExternalBridges)
{
	/* Register Volt built-in bridges */
	if (VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS)
	{
		/* UI related bridges */
		script_engine_->addBridge(new Bridge::WidgetBridge());
		script_engine_->addBridge(new Bridge::TextWidgetBridge());
		script_engine_->addBridge(new Bridge::ImageBridge());
		script_engine_->addBridge(new Bridge::ImageWidgetBridge());
		script_engine_->addBridge(new Bridge::FrameBridge());
		script_engine_->addBridge(new Bridge::ListWidgetBridge());
		script_engine_->addBridge(new Bridge::AnimationBridge());
		script_engine_->addBridge(new Bridge::SceneRootBridge(scene_root_));
		script_engine_->addBridge(new Bridge::NinePatchWidgetBridge());
		script_engine_->addBridge(new Bridge::VideoWidgetBridge());
	}

	script_engine_->addBridge(new Bridge::SefBridge());
	script_engine_->addBridge(new Bridge::ResourceBridge());
	script_engine_->addBridge(new Bridge::VoltDefaultBridge(script_engine_.get()));
	script_engine_->addBridge(new Bridge::VconfBridge());
	script_engine_->addBridge(new Bridge::ServiceBridge());
	script_engine_->addBridge(new Bridge::AulBridge());
	script_engine_->addBridge(new Bridge::SystemInfoBridge());
	//  script_engine_->addBridge(new Bridge::UiGadgetBridge());

	worker_bridge_ = new Bridge::VoltWorkerBridge();
	script_engine_->addBridge(worker_bridge_);

	script_engine_->addBridge(new Bridge::VDUtilBridge());
	script_engine_->addBridge(new Bridge::LogBridge());
	script_engine_->addBridge(new Bridge::FirstScreenListWidgetBridge());
	script_engine_->addBridge(new Bridge::WebSocketBridge());
	script_engine_->addBridge(new Bridge::SmartHubResetBridge());
	script_engine_->addBridge(new Bridge::TTSBridge());

  bool enable_voltworker = AppConfig::Instance().GetValue<std::string>("enable-voltworker") == "true";
  if(enable_voltworker)
  {	
	worker_bridge_ = new Bridge::VoltWorkerBridge();
	script_engine_->addBridge(worker_bridge_);
	}


		
	LOG_INFO(LOGGER, "HaloInitialize");

if (HaloInitialize && AppConfig::Instance().IsFirstScreen() == false)
	{
		HaloInitialize();
		LOG_INFO(LOGGER, "HaloInitialize Complete");
	}

	/* Add extra bridges created externally. */
	for (auto iter = aExternalBridges.begin();
		iter != aExternalBridges.end(); ++iter)
	{
		LOG_INFO(LOGGER, "Adding an external bridge: " << *iter);
		script_engine_->addBridge(*iter);
	}

	return true;
}

bool VoltFullProcessRuntime::IsQuitting() const
{
	return quitting_;
}

void VoltFullProcessRuntime::HandleKeyEvent(const int aType, const int aKeyCode)
{
	LOGE("[VOLT] Handling event: %d, %d", aType, aKeyCode);
  
	if (aType == CLUTTER_KEY_PRESS || aType == CLUTTER_KEY_RELEASE)
	{
		LOGE("[VOLT] CLUTTER_KEY_PRESS / CLUTTER_KEY_RELEASE");
		if (IsQuitting() && (!AppConfig::Instance().IsFirstScreen()))
		{
			LOGE("[VOLT] In middle of termination; not handling key event");
			return;
		}

		if (aKeyCode == KEY_EXIT)
		{
			/* EXIT key always exits; no need to give to the app. */

			LOG_ERROR(LOGGER, "EXIT key pressed; force exit...");
			if (AppConfig::Instance().IsFirstScreen())
			{
				try
				{
					int type = aType == CLUTTER_KEY_PRESS ? EVENT_KEY_PRESS : EVENT_KEY_RELEASE;
					const int aReturnKeyCode = KEY_RETURN;
					script_engine_->sendKeyEvent(aReturnKeyCode, type);
					return; 
				}

				catch(VoltJsRuntimeException &e)
				{
					LOG_ERROR(LOGGER, "Exiting due to JS runtime error: " << e.what());
					return;
				}
			}
			else
			{
				try
				{
					printf("[lyj] capture(); \n");
					volt::util::Capture();
					printf("[lyj] capture(); end(); \n");
				}
				catch (...)
				{
					printf("[lyj] terminate cpture error! \n");
				}
				printf("[lyj] Quit(); \n");
				Quit();
				printf("[lyj] Quit(); end\n");
				return;	
			}
		}

		if (volt::StaticUI::Instance().ExceptionPopupVisible())
		{
			LOGE("[VOLT] ExceptionPopupVisible");
			if (aKeyCode == KEY_RETURN && aType == CLUTTER_KEY_RELEASE)
			{
				SetReturnToPrevApp(true);
				Quit();
			}

			return;
		}

		try
		{
			int type = aType == CLUTTER_KEY_PRESS ? EVENT_KEY_PRESS : EVENT_KEY_RELEASE;
			LOGE("[VOLT] Sending a %s event to V8: %d", (type == EVENT_KEY_PRESS ? "press" : "release"), aKeyCode);
			script_engine_->sendKeyEvent(aKeyCode, type);
		}
		catch (VoltJsRuntimeException &e)
		{
			LOGE("[VOLT] Exiting due to JS runtime error: %s", e.what());

			volt::StaticUI::Instance().ShowExceptionPopup("Encountered fatal error "
				"when handling a key event",
				&e);
		}
	}
}

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
gboolean VoltFullProcessRuntime::OnKeyEvent(void *aCallbackData)
{
	LOGE("[VOLT] OnKeyEvent Callback");
	EventManager::CallbackData *data =
		reinterpret_cast<EventManager::CallbackData *>(aCallbackData);

	ClutterEvent *event = data->event;

	VoltFullProcessRuntime *self =
		reinterpret_cast<VoltFullProcessRuntime *>(data->user_data);

	self->HandleKeyEvent(event->type, event->key.hardware_keycode);

	delete data; /* this will clean the event too */

	return FALSE;
}

gboolean VoltFullProcessRuntime::OnMouseEvent(void *aCallbackData)
{
	EventManager::CallbackData *data =
		reinterpret_cast<EventManager::CallbackData *>(aCallbackData);

	ClutterEvent *event = data->event;

	gfloat x, y;
	clutter_event_get_coords(event, &x, &y);
	LOG_DEBUG(LOGGER, "Queueing mouse event type " << clutter_event_type(event) <<
		" with button " << clutter_event_get_button(event) << " @ (" << x << ", " << y << ")");
	clutter_event_put(event);

	delete data; /* this will clean the event too */

	return FALSE;
}

gboolean VoltFullProcessRuntime::OnFlickEvent(void *aCallbackData)
{
	EventManager::CallbackData *data =
		reinterpret_cast<EventManager::CallbackData *>(aCallbackData);

	ClutterEvent *event = data->event;

	VoltFullProcessRuntime *self =
		reinterpret_cast<VoltFullProcessRuntime *>(data->user_data);
	/* The key code is actually the MOUSE_FLICK enum */
	volt::util::MOUSE_FLICK flick =
		static_cast<volt::util::MOUSE_FLICK>(clutter_event_get_key_code(event));

	LOG_DEBUG(LOGGER, "Sending flick event to v8: " << flick);
	self->script_engine_->sendFlickEvent(flick);

	delete data; /* this will clean the event too */

	return FALSE;
}

gboolean VoltFullProcessRuntime::OnShowEvent(void *aSelf)
{
	LOGE("[VOLT] OnShowEvent");
	LOG_DEBUG(LOGGER, "Showing the app UI");

	VoltFullProcessRuntime *self = reinterpret_cast<VoltFullProcessRuntime *>(aSelf);

	self->ShowUI(VoltEventArgsMap());

	return FALSE;
}

gboolean VoltFullProcessRuntime::OnHideEvent(void *aSelf)
{
	LOGE("[VOLT] OnHideEvent");
	LOG_DEBUG(LOGGER, "Hiding the app UI"); 
	int key;
  system_info_get_value_int(SYSTEM_INFO_KEY_ERROR_POPUP_ON_OFF, &key);
	LOG_FATAL(LOGGER,"[SYSTEM_INFO_KEY_ERROR_POPUP_ON_OFF] " << key);
	LOG_WARN(LOGGER,"[SYSTEM_INFO_KEY_ERROR_POPUP_ON_OFF] " << key);


	VoltFullProcessRuntime *self = reinterpret_cast<VoltFullProcessRuntime *>(aSelf);

	self->HideUI(VoltEventArgsMap());

	return FALSE;
}
#else
gboolean VoltFullProcessRuntime::OnStageDestroy(ClutterActor * /* unused */, gpointer aSelf)
{
	LOG_DEBUG(LOGGER, "quitting...");

	VoltFullProcessRuntime *self = reinterpret_cast<VoltFullProcessRuntime *>(aSelf);

	self->Quit();

#ifdef BOOST_NO_CXX11_RANGE_BASED_FOR

	for (auto iter = self->signal_handlers_.begin();
		iter != self->signal_handlers_.end(); ++iter)
	{
		LOG_DEBUG(LOGGER, "Disconnecting signal: " << *iter);
		g_signal_handler_disconnect(self->main_stage_, *iter);
	}

#else

	for (auto handler: self->signal_handlers_)
	{
		LOG_DEBUG(LOGGER, "Disconnecting signal: " << handler);
		g_signal_handler_disconnect(self->main_stage_, handler);
	}

#endif
	self->signal_handlers_.clear();

	self->main_stage_ = nullptr;

	return true;
}

gboolean VoltFullProcessRuntime::OnStageActivate(ClutterStage * /* unused */, gpointer aSelf)
{
	LOGE("[VOLT] Stage activated...");
	VoltFullProcessRuntime *self = reinterpret_cast<VoltFullProcessRuntime *>(aSelf);
	self->script_engine_->sendInteruptEvent(volt::util::ON_ACTIVATE);
	return true;
}

gboolean VoltFullProcessRuntime::OnStageDeactivate(ClutterStage * /* unused */, gpointer aSelf)
{
	LOGE("[VOLT] Stage deactivated...");
	VoltFullProcessRuntime *self = reinterpret_cast<VoltFullProcessRuntime *>(aSelf);
	self->script_engine_->sendInteruptEvent(volt::util::ON_DEACTIVATE);
	return true;
}

gboolean VoltFullProcessRuntime::OnKeyEvent(ClutterActor * /* unused */,
	ClutterEvent *aEvent, gpointer aRuntime)
{
	guint key_code = clutter_event_get_key_symbol(aEvent);

	VoltFullProcessRuntime *runtime =
		reinterpret_cast<VoltFullProcessRuntime *>(aRuntime);

	runtime->HandleKeyEvent(aEvent->type, key_code);

	return true;
}

gboolean VoltFullProcessRuntime::OnObjectDump(ClutterActor * /* unused */,
	ClutterEvent *aEvent, gpointer aRuntime)
{
	LOG_DEBUG(LOGGER, "OnObjectDump");
	
	if (!AppConfig::Instance().IsFirstScreen())
	{
		return true;
	}
	
	if (FirstScreenListWidget::Instance() != NULL)
	{
		FirstScreenListWidget::Instance()->objectDump();
	}
	
	return true;
}

#endif
