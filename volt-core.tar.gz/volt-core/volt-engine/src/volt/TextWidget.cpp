/*
 * TextWidget.cpp
 *
 *  Created on: May 21, 2013
 *      Author: reza
 */
#include "TextWidget.h"
#include <string.h>
#include <clutter/clutter.h>
#include <fontconfig/fontconfig.h>
#include <cmath>
#include "VoltActor.h"
#include "logger.h"
#include "VoltText.h"

namespace volt
{
namespace graphics
{
PangoFontDescription* TextWidget::defaultFontDescription = NULL;
PangoFontDescription* TextWidget::defaultAppFontDescription = NULL;

TextWidget::TextWidget(float x, float y, std::string text, std::string fontName, Widget* aParent, Color textColor)
  : valign(Top)
{
  actor = volt_actor_new();

  const char* specificFontName;
  if (!fontName.length())
  {
    specificFontName = NULL;
  }
  else
  {
    specificFontName = canonicalizeFont(fontName).c_str(); 
  }
  textActor = volt_text_new_full(specificFontName, text.c_str(),
                                 textColor.toClutterColor());
  clutter_actor_add_child(actor, textActor);
  init(x, y, aParent);
  this->text = text;

  clutter_text_set_line_wrap(CLUTTER_TEXT(textActor), true);
  clutter_text_set_line_wrap_mode(CLUTTER_TEXT(textActor), PANGO_WRAP_WORD_CHAR);
  clutter_text_set_use_markup(CLUTTER_TEXT(textActor), true);

  //whenever the width and height of actor are changed, call onResize, which will set the dimensions of textActor to match
  g_signal_connect(actor, "notify::size", (GCallback)onResize, this);

}

//Override
ClutterActor* TextWidget::getAnimationActor(AnimatableProperty property)
{
  if(property == TextColor || property == TextColorR || property == TextColorB ||
     property == TextColorG || property == TextColorA || property == LineSpacing ||
     property == TextShadowColor ||
     property == TextShadowColorR || property == TextShadowColorG || property == TextShadowColorB ||
     property == TextShadowColorA || property == TextShadowXOffset || property == TextShadowYOffset)
  {
    return textActor;
  }
  else
  {
    return actor;
  }
}

std::string TextWidget::getText() const
{
  return clutter_text_get_text( CLUTTER_TEXT(textActor) );
}

void TextWidget::setText(const std::string& text)
{
  clutter_text_set_text (CLUTTER_TEXT(textActor), text.c_str());

  if (valign != Top)
  {
    recalculateVerticalOffset();
  }

  clutter_text_set_use_markup(CLUTTER_TEXT(textActor), true);
}


//Font
std::string TextWidget::getFontName() const
{
  return clutter_text_get_font_name(CLUTTER_TEXT(textActor));
}


void TextWidget::setFontName(const std::string& fontName)
{
  clutter_text_set_font_name(CLUTTER_TEXT(textActor), fontName.c_str());
}

Color TextWidget::getTextColor() const
{
  ClutterColor clutterColor;
  clutter_text_get_color(CLUTTER_TEXT(textActor), &clutterColor);
  return Color(clutterColor);
}

void TextWidget::setColor(const Color& color)
{
  // For high contrast mode, alter background color as follows:
  //   Widgets: if computed luminance is > 50%, then set to white, otherwise set to black
  //   TextWidgets: Set to black (text color will be set to white)
  Color adjColor = color;
  HighContrastMode mode = getHighContrastMode();

  switch (mode)
  {
  case HighContrastMode::BLACK_ON_WHITE:
    adjColor = Color(255,255,255,255);
    break;
  case HighContrastMode::WHITE_ON_BLACK:
    adjColor = Color(0,0,0,255);
    break;
  default:
    break;
  }

  Widget::setColor(adjColor);
}

void TextWidget::setTextColor(const Color& newColor)
{
  Color adjColor(newColor);
  HighContrastMode mode = getHighContrastMode();

  switch (mode)
  {
  case HighContrastMode::BLACK_ON_WHITE:
    adjColor = Color(0,0,0,255);
    break;
  case HighContrastMode::WHITE_ON_BLACK:
    adjColor = Color(255,255,255,255);
    break;
  default:
    break;
  }

  clutter_text_set_color(CLUTTER_TEXT(textActor), adjColor.toClutterColor());
}

LayoutAlignment TextWidget::getHorizontalAlignment() const
{
  PangoAlignment alignment = clutter_text_get_line_alignment(CLUTTER_TEXT(textActor));

  switch(alignment)
  {
  case PANGO_ALIGN_RIGHT:
    return LayoutAlignment::Right;
  case PANGO_ALIGN_CENTER:
    return LayoutAlignment::Center;
  default:
    return LayoutAlignment::Left;
  }
}

void TextWidget::setHorizontalAlignment(LayoutAlignment alignment)
{
  PangoAlignment pangoAlignment;

  switch(alignment)
  {
  case LayoutAlignment::Right:
    pangoAlignment = PANGO_ALIGN_RIGHT;
    break;
  case LayoutAlignment::Center:
    pangoAlignment = PANGO_ALIGN_CENTER;
    break;
  default:
    pangoAlignment = PANGO_ALIGN_LEFT;
    break;
  }

  clutter_text_set_line_alignment(CLUTTER_TEXT(textActor), pangoAlignment);
}

void TextWidget::setVerticalAlignment(VerticalLayoutAlignment vertAlign)
{
  valign = vertAlign;

  if (vertAlign != Top)
  {
    recalculateVerticalOffset();
  }
}

bool TextWidget::getUseEllipses() const
{
  PangoEllipsizeMode mode = clutter_text_get_ellipsize(CLUTTER_TEXT(textActor));
  return mode != PANGO_ELLIPSIZE_NONE;
}

void TextWidget::setUseEllipses(bool useEllipses)
{
  if(useEllipses)
  {
    clutter_text_set_ellipsize(CLUTTER_TEXT(textActor), PANGO_ELLIPSIZE_END);
  }
  else
  {
    clutter_text_set_ellipsize(CLUTTER_TEXT(textActor), PANGO_ELLIPSIZE_NONE);
  }
}

void TextWidget::setSingleLineMode(bool useSingleLineMode)
{
  if(useSingleLineMode)
  {
    clutter_text_set_editable(CLUTTER_TEXT(textActor), true);
    clutter_text_set_single_line_mode(CLUTTER_TEXT(textActor), true);
  }
  else
  {
    clutter_text_set_single_line_mode(CLUTTER_TEXT(textActor), false);
    clutter_text_set_editable(CLUTTER_TEXT(textActor), false);
  }
}

bool TextWidget::getSingleLineMode() const
{
  return clutter_text_get_single_line_mode(CLUTTER_TEXT(textActor));
}

int TextWidget::getLineSpacing() const
{
  return volt_text_get_line_spacing(VOLT_TEXT(textActor));
}

void TextWidget::setLineSpacing(int spacing)
{
  volt_text_set_line_spacing(VOLT_TEXT(textActor), spacing);
}

int TextWidget::getHeightInLines() const
{
  float height = getHeight();
  float width = getWidth();
  if (height <= 0 || width <= 0)
  {
    return 0;
  }

  //No text is set, go by the current font instead.
  if (getText() == "" ) 
  {
    return height / (float)(getFontHeight() + getLineSpacing());
  }

  //We cannot assume all lines are the same height due to different language characters and markup. 
  //So we sum them up manually.
  float heightAccumulator = 0;
  uint currentLine = 0;
  while ( heightAccumulator < height )
  {
    uint currentLineHeight = getLineHeight(currentLine);
    if (currentLineHeight == 0) //no lines of text, but still not reached height so estimate remaining space
    {
      float estimatedRemainingHeight = (height - heightAccumulator);
      float divider = (float)(getFontHeight() + getLineSpacing());
      int estimatedRemainingLines = 0;
      if(divider != 0.0)
      {
      	estimatedRemainingLines = estimatedRemainingHeight / divider;
      }
      heightAccumulator += estimatedRemainingHeight;
      currentLine += estimatedRemainingLines;
      break;
    }
    else //use actual height of text 
    {
      heightAccumulator += currentLineHeight; 
    }
    ++currentLine;
  }
  float heightInLines = currentLine;
  if ( (heightAccumulator - height) > 0)
  {
    heightInLines -= 1; //casting to int in the next step so we don't need to be precise here.
  } 
  return (int)heightInLines;
}

void TextWidget::setHeightInLines(int lines)
{
  if (lines <= 0) 
  {
    setHeight(0);
    return;
  }

  //if no text has been set yet, we can assume the font size of the current font
  int estimatedLineSize = getFontHeight() + getLineSpacing();
  if(getText() == "")
  {
    setHeight( estimatedLineSize  * lines ); 
    return;
  }

  //Otherwise we can base it on the current height and width and text
  uint currentLine = 0;
  float heightAccumulator = 0;
  while (currentLine < (uint)lines)
  {
    uint currentLineHeight = getLineHeight(currentLine);
    if (currentLineHeight == 0) //no text here so estimate line size with font
    {
      currentLineHeight = estimatedLineSize;
    }
    heightAccumulator += currentLineHeight; 
    ++currentLine;
  }
  setHeight(heightAccumulator); 
}

int TextWidget::charIndexAtCoordinate(Vector2 coord) const
{
  return clutter_text_coords_to_position(CLUTTER_TEXT(textActor), coord.x, coord.y);
}

Vector2 TextWidget::coordinateAtCharIndex(int charIndex) const
{
  float x;
  float y;
  float lineHeight;

  //With ellipses off text_position_to_coords returns the y coordinate where
  //overflowing text would be. With it on, it always returns the coord of the
  //last ellipse. So make sure ellispses is off for consistency.
  //A const_cast is used because we know the state of useElipses will not change after this call.
  bool elipsisOn = getUseEllipses();

  if (elipsisOn)
  {
    const_cast<TextWidget*>(this)->setUseEllipses(false);
  }

  bool success = clutter_text_position_to_coords(CLUTTER_TEXT(textActor), charIndex, &x, &y, &lineHeight);

  if (elipsisOn)
  {
    const_cast<TextWidget*>(this)->setUseEllipses(elipsisOn);
  }

  if (!success)
  {
    return Vector2(-1, -1);
  }

  return Vector2(x, y);
}

uint TextWidget::getLineHeight(uint lineNumber) const
{
  uint lineCount = volt_text_get_layout_line_count(VOLT_TEXT(textActor));
  if (lineNumber >= lineCount)
  {
    return 0;
  }

  PangoRectangle inkRect; 
  PangoRectangle logicalRect;
  volt_text_get_layout_line_pixel_extents(VOLT_TEXT(textActor), lineNumber, &inkRect, &logicalRect);
  return logicalRect.height + getLineSpacing();
}

uint TextWidget::getLineRangeHeight(uint lineIndexStart, uint lineIndexEnd) const
{
  uint lineCount = volt_text_get_layout_line_count(VOLT_TEXT(textActor));
  if (lineIndexStart >= lineCount || lineIndexEnd > lineCount || lineIndexStart >= lineIndexEnd)
  {
    return 0;
  }

  return volt_text_get_layout_lines_pixel_height(VOLT_TEXT(textActor), lineIndexStart, lineIndexEnd - 1);
}

float TextWidget::getTextOverflow() const
{
  uint lineCount = getFullTextLineCount();
  float fullLineSize = (float)getLineRangeHeight(0, lineCount); //TODO Jim fix
  return fullLineSize - getHeight();
}


float TextWidget::getTextOverflowLines() const
{
  if (getText() == "") return 0;

  float textOverflow = getTextOverflow();
  if (textOverflow == 0) 
  {
    return 0;
  }

  float height = getHeight();
  uint lineCount = getFullTextLineCount();
  float heightAccumulator = 0;
  uint currentLine = 0;
  while ( heightAccumulator < height && currentLine < lineCount )
  {
    heightAccumulator += getLineHeight(currentLine);
    ++currentLine;
  }
  float heightInLines = currentLine;
  if (heightInLines > height)
  {
    return heightInLines - ( textOverflow / (float)getLineHeight(lineCount - 1) );
  }
  //underflow has to be estimated since we can't know how large its lines will be.
  //Use the lineHeight of the first line to estimate underflow
  return textOverflow / (float)(getFontHeight() + getLineSpacing());
}

Vector2 TextWidget::getCharDimensions(int charIndex) const
{
  if (charIndex < 0 ) return Vector2(0,0);
  PangoRectangle logicalRect; 
  volt_text_get_char_pixel_extents(VOLT_TEXT(textActor), charIndex, &logicalRect);
  return Vector2(logicalRect.width, logicalRect.height);
}

void TextWidget::insertText(std::string text, int charIndex)
{
  clutter_text_insert_text(CLUTTER_TEXT(textActor), text.c_str(), charIndex);
}

void TextWidget::removeText(int charIndex, int length)
{
  clutter_text_delete_text(CLUTTER_TEXT(textActor), charIndex, charIndex + length);
}

void TextWidget::removeText(int charIndex)
{
  clutter_text_delete_text(CLUTTER_TEXT(textActor), charIndex, getText().length());
}


Vector2 TextWidget::getTextSize() const
{
  PangoLayout* layout = clutter_text_get_layout(CLUTTER_TEXT(textActor));
  int pixelWidth, pixelHeight;
  pango_layout_get_pixel_size(layout, &pixelWidth, &pixelHeight );
  return Vector2(pixelWidth, pixelHeight);
}

void TextWidget::onResize(GObject* object, GParamSpec* paramSpec, gpointer data)
{
  TextWidget* self = reinterpret_cast<TextWidget*>(data);

  // make sure we dont re-apply changes unless they are greater than 0.0005
  bool change = false;
  float threshold = 0.0005;
  float diffWidth = clutter_actor_get_width(self->textActor) - self->getWidth();
  float diffHeight = clutter_actor_get_height(self->textActor) - self->getHeight();

  if(diffWidth < 0)
  {
    diffWidth *= -1;
  }

  if(diffHeight < 0)
  {
    diffHeight *= -1;
  }

  if(diffWidth >= threshold)
  {
    clutter_actor_set_width(self->textActor, self->getWidth());
    change = true;
  }

  if(diffHeight >= threshold)
  {
    clutter_actor_set_height(self->textActor, self->getHeight());
    change = true;
  }

  if(change)
  {
    self->recalculateVerticalOffset();
  }
}


void TextWidget::recalculateVerticalOffset()
{
  if (valign != Top)
  {
    Vector2 textSize = getTextSize();
    float actorHeight = getHeight();

    if (textSize.y < actorHeight) //Otherwise we will offset outside the bounds of actor
    {
      float yPos = (valign == Middle)
                   ? actorHeight/2 - textSize.y/2
                   : actorHeight - textSize.y; //must be valign == Bottom

      clutter_actor_set_y(textActor, yPos);
      return;
      //Otherwise just don't have an offset
    }
  }

  clutter_actor_set_y(textActor, 0);
}

void TextWidget::setDefaultFont(const std::string aFont)
{
  defaultFontDescription = NULL;

  if (aFont.length() > 0)
  {
    defaultFontDescription = pango_font_description_from_string(aFont.c_str());
  }
}

void TextWidget::setDefaultAppFont(const std::string aFont)
{
  defaultAppFontDescription = NULL;

  if (aFont.length() > 0)
  {
    defaultAppFontDescription = pango_font_description_from_string(aFont.c_str());
  }
}


void TextWidget::setHasShadow(bool hasShadow)
{
  volt_text_set_has_shadow(VOLT_TEXT(textActor), hasShadow);
}

bool TextWidget::getHasShadow() const
{
  return volt_text_get_has_shadow(VOLT_TEXT(textActor));
}

void TextWidget::setShadowXOffset(float xOffset)
{
  volt_text_set_shadow_x_offset(VOLT_TEXT(textActor), xOffset);
}

float TextWidget::getShadowXOffset() const
{
  return volt_text_get_shadow_x_offset(VOLT_TEXT(textActor));
}

void TextWidget::setShadowYOffset(float yOffset)
{
  volt_text_set_shadow_y_offset(VOLT_TEXT(textActor), yOffset);
}

float TextWidget::getShadowYOffset() const
{
  return volt_text_get_shadow_y_offset(VOLT_TEXT(textActor));
}

void TextWidget::setShadowColor(const Color& color)
{
  volt_text_set_shadow_color(VOLT_TEXT(textActor), color.toClutterColor());
}

Color TextWidget::getShadowColor() const
{
  ClutterColor color;
  volt_text_get_shadow_color(VOLT_TEXT(textActor), &color);
  return color;
}

bool TextWidget::isRightToLeft() const
{
  return volt_text_get_is_right_to_left(VOLT_TEXT(textActor));
}

void TextWidget::getFontMetrics(FontMetrics *fMetrics) const
{
  if (fMetrics != NULL)
  {
    PangoFontMetrics* metrics = volt_text_get_font_metrics(VOLT_TEXT(textActor));
    fMetrics->approximateCharWidth = 
      PANGO_PIXELS(pango_font_metrics_get_approximate_char_width(metrics));
    fMetrics->approximateDigitWidth = 
      PANGO_PIXELS(pango_font_metrics_get_approximate_digit_width(metrics));
    fMetrics->ascent = 
      PANGO_PIXELS(pango_font_metrics_get_ascent(metrics));
    fMetrics->descent = 
      PANGO_PIXELS(pango_font_metrics_get_descent(metrics));
    fMetrics->strikethroughPosition = 
      PANGO_PIXELS(pango_font_metrics_get_strikethrough_position(metrics));
    fMetrics->strikethroughThickness = 
      PANGO_PIXELS(pango_font_metrics_get_strikethrough_thickness(metrics));
    fMetrics->underlinePosition = 
      PANGO_PIXELS(pango_font_metrics_get_underline_position(metrics));
    fMetrics->underlineThickness = 
      PANGO_PIXELS(pango_font_metrics_get_underline_thickness(metrics));
    volt_text_release_font_metrics(metrics);
  }
}

int TextWidget::getFontHeight() const
{
  FontMetrics metrics;
  getFontMetrics(&metrics);
  int fontLineHeight = metrics.ascent + metrics.descent;
  if (fontLineHeight <= 0) return 0; //divide by 0 guard
  return fontLineHeight;
}

int TextWidget::getFullTextLineCount() const
{
  return volt_text_get_layout_line_count(VOLT_TEXT(textActor));
}

std::string& TextWidget::canonicalizeFont(std::string &aFont)
{
  static volt::util::Logger logger("volt.widget.text");

  /* Get font description for the requested font. */
  PangoFontDescription *desc =
    pango_font_description_from_string(aFont.c_str());
  char *desc_str = pango_font_description_to_string(desc);

  if (defaultFontDescription || defaultAppFontDescription)
  {
    /* Get the default font family. */
    const char *default_family = NULL;

    if (defaultFontDescription)
    {
      default_family =
        pango_font_description_get_family(defaultFontDescription);
    }

    const char *default_app_family = NULL;

    if (defaultAppFontDescription)
    {
      default_app_family =
        pango_font_description_get_family(defaultAppFontDescription);
    }

    bool use_default = true;

    /* Get the requested font family. */
    const char *req_family = pango_font_description_get_family(desc);

    if (req_family)
    {
      /* Perform FontConfig font matching for the requested family. */
      FcPattern *pattern = FcPatternCreate();
      FcPatternAddString(pattern, FC_FAMILY,
                         reinterpret_cast<const FcChar8 *>(req_family));

      /* Apply substitutions defined in config. */
      if (FcConfigSubstitute(NULL, pattern, FcMatchPattern) == FcFalse)
      {
        LOG_WARN(logger, "Failed to perform FcConfigSubstitute");
      }

      /* Apply the default substitution. */
      FcDefaultSubstitute(pattern);

      /* Finally, try matching it. */
      FcResult result;
      FcPattern *match = FcFontMatch(NULL, pattern, &result);

      if (match == NULL)
      {
        LOG_DEBUG(logger, "Could not match font family: " << req_family);
      }
      else
      {
        FcValue value;
        result = FcPatternGet(match, FC_FAMILY, 0, &value);

        if (result != FcResultMatch)
        {
          LOG_DEBUG(logger, "Could not match font family: " << req_family);
        }
        else
        {
          LOG_DEBUG(logger, "Matched font family: " << req_family << " == " << value.u.s);

          if (strcmp(req_family, reinterpret_cast<const char *>(value.u.s)) == 0)
          {
            use_default = false;
          }

          /* else use the default if the famly was changed during font
           * matching. */
        }
      }

    }

    if (use_default)
    {
      g_free(desc_str);

      const char *the_default =
        default_app_family ? default_app_family : default_family;
      /* Updated to use the default font family and regenrate font
       * description. */
      LOG_DEBUG(logger,
                "Using default: " << (the_default ? the_default : "???") <<
                " (given " << (req_family ? req_family : "???") << ")");
      pango_font_description_set_family(desc, the_default);
      desc_str = pango_font_description_to_string(desc);
    }
  }

  aFont = desc_str;

  g_free(desc_str);

  return aFont;
}

const std::string& TextWidget::getWidgetTypeString() const
{
  static const std::string type("TextWidget");
  return type;
}

void TextWidget::writeSceneGraphExtraJson(std::ostream &aOut, const std::string aIndent) const
{
  aOut << aIndent << "\"text\": \"" << getText() << "\"," << std::endl;
}

};
};
