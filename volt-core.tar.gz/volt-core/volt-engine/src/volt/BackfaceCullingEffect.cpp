/*
 * BackfaceCullingEffect.cpp
 *
 *  Created on: August 11, 2014
 *      Author: jim dinunzio
 */

#include "BackfaceCullingEffect.h"

G_DEFINE_TYPE (CBackfaceCullingEffect, backface_culling_effect, CLUTTER_TYPE_EFFECT);

static void
backface_culling_effect_paint (ClutterEffect *effect, ClutterEffectPaintFlags flags)
{
  ClutterActor* actor = clutter_actor_meta_get_actor (CLUTTER_ACTOR_META (effect));

  bool backfaceTest = cogl_get_backface_culling_enabled();

  if(!backfaceTest)
  {
    cogl_set_backface_culling_enabled(true);
  }

  clutter_actor_continue_paint(actor);

  if (!backfaceTest)
  {
    cogl_set_backface_culling_enabled(backfaceTest);
  }
}

/* GObject implementation */
static void
backface_culling_effect_dispose (GObject *gobject)
{
  G_OBJECT_CLASS (backface_culling_effect_parent_class)->dispose (gobject);
}

static ClutterEffect* backward_culling_effect_clone_for_render_thread(ClutterEffect   *sourceBackfaceCullingEffect)
{
	CBackfaceCullingEffect *srcEffect = BACKFACE_CULLING_EFFECT(sourceBackfaceCullingEffect);
	if(srcEffect->copy_effect == NULL)
	{
		srcEffect->copy_effect = BACKFACE_CULLING_EFFECT(backface_culling_effect_new());
	}

	return CLUTTER_EFFECT(srcEffect->copy_effect);
}
/* GObject class and instance init */
static void
backface_culling_effect_class_init (CBackfaceCullingEffectClass *klass)
{
  ClutterEffectClass *effect_class = CLUTTER_EFFECT_CLASS (klass);
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  effect_class->paint = backface_culling_effect_paint;
  gobject_class->dispose = backface_culling_effect_dispose;
  effect_class->clone_for_render_thread   = backward_culling_effect_clone_for_render_thread;
}


static void
backface_culling_effect_init (CBackfaceCullingEffect *self)
{
  self->copy_effect = NULL;
}

/* public API */

/**
 * backface_culling_effect_new:
 *
 * Creates a new #CBackfaceCullingEffect
 */
ClutterEffect *
backface_culling_effect_new ()
{
  return (ClutterEffect*)g_object_new (TYPE_BACKFACE_CULLING_EFFECT, NULL);
}

#ifndef STAND_ALONE
/* BackfaceCullingEffect Implementation */

BackfaceCullingEffect::BackfaceCullingEffect()
{
  setEffect(backface_culling_effect_new());
}

BackfaceCullingEffect::~BackfaceCullingEffect()
{
}

#endif // STAND_ALONE
