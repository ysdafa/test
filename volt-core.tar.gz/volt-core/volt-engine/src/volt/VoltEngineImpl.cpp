#include "VoltEngineImpl.h"

#include <v8/v8.h>

#include "AppConfig.h"
#include "VoltProcessManager.h"
#include "VoltFullProcessRuntime.h"
#include "FileIORequest.h"

#include "TextWidget.h"

using namespace volt::util;
using namespace volt::graphics;

Logger VoltEngineImpl::LOGGER("volt.engine");

VoltEngineImpl::VoltEngineImpl():
  VoltEngine(), process_type_(0), hidden_(false)
{
}

VoltEngineImpl::~VoltEngineImpl()
{
}

void VoltEngineImpl::SetDrmLicense(const std::string &aPath)
{
  Resource::FileIORequest::SetLicensePath(aPath);
}

bool VoltEngineImpl::ParseOptions(int aArgc, char **aArgv)
{
  ApplyConfig(aArgc, aArgv);

  if (AppConfig::Instance().GetValue<std::string>("worker").empty() == false)
  {
    LOG_DEBUG(LOGGER, "Worker Application Process");
    process_type_ = FULL_PROCESS | WORKER_PROCESS;
  }
  else
  {
    LOG_DEBUG(LOGGER, "Root Application Process");
    process_type_ = FULL_PROCESS | ROOT_PROCESS;
  }

  return true;
}

bool VoltEngineImpl::Initialize(int aArgc, char **aArgv,
                                const ExternalData &aData)
{
  VoltProcessManager::Instance().Initialize();

  if (AppConfig::Instance().IsSet("help"))
  {
    AppConfig::Instance().PrintUsage();
    return false;
  }

  bool retval = false;

  if (process_type_ & ROOT_PROCESS)
  {
    LOG_WARN(LOGGER, "Root Process");
    retval =
      VoltProcessManager::Instance().InitFullMain(aArgc, aArgv, aData);
  }
  else if (process_type_ & WORKER_PROCESS)
  {
    LOG_WARN(LOGGER, "VoltWorker Process");
    retval =
      VoltProcessManager::Instance().InitFullWorkerMain(aArgc, aArgv, aData);
  }

  return retval;
}

bool VoltEngineImpl::Run()
{
  bool retval = false;

  retval = VoltProcessManager::Instance().Run();

  VoltProcessManager::Instance().Wait();

  return retval;
}

void VoltEngineImpl::Cleanup()
{
  VoltProcessManager::Instance().Cleanup();
}

void VoltEngineImpl::Quit()
{
  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

  if (runtime)
  {
    runtime->Quit();
  }
}

bool VoltEngineImpl::ShouldReturnToPrevAppOnExit()
{
  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
  return runtime ? runtime->ReturnToPrevApp() : false;
}

volt::graphics::SceneRoot* VoltEngineImpl::GetSceneRoot() const
{
  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
  return runtime ? runtime->GetSceneRoot() : NULL;
}

void VoltEngineImpl::SendJsEvent(const unsigned int aEventID,
                                 const VoltEventArgsMap &aJsData)
{
  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

  if (runtime && runtime->GetScriptEngine())
  {
    runtime->GetScriptEngine()->sendEvent(aEventID, aJsData);
  }
}

void VoltEngineImpl::ShowUI(const VoltEventArgsMap &aArgs)
{
  InterthreadData *data = new InterthreadData(this, aArgs);
  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
                                DoShowUI, data, NULL);
}

void VoltEngineImpl::HideUI(const VoltEventArgsMap &aArgs)
{
  InterthreadData *data = new InterthreadData(this, aArgs);
  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
                                DoHideUI, data, NULL);
}

void VoltEngineImpl::ResetApp(const VoltEventArgsMap &aArgs)
{
  InterthreadData *data = new InterthreadData(this, aArgs);
  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
                                DoResetApp, data, NULL);
}

bool VoltEngineImpl::UIHidden() const
{
  return hidden_;
}

uint8_t VoltEngineImpl::ProcessType() const
{
  return process_type_;
}

void VoltEngineImpl::ParseConfig(int aArgc, char **aArgv)
{
  AppConfig::Instance().Clear();
  AppConfig::Instance().ParseCommandLineArgs(aArgc, aArgv);

#if 0
  std::string xml_path =
    AppConfig::Instance().GetAppRootPath() + "/config.xml";
  AppConfig::Instance().ParseConfigXml(xml_path);
#else
  std::string json_path =
    AppConfig::Instance().GetAppRootPath() + "/config.json";
  AppConfig::Instance().ParseConfigJson(json_path);
#endif

  std::string config_path =
    AppConfig::Instance().GetVoltConfigPath() + "/volt.conf";
  AppConfig::Instance().ParseVoltConf(config_path);

  AppConfig::Instance().PrintValues();
}

void VoltEngineImpl::ApplyConfig(int aArgc, char **aArgv)
{
  ParseConfig(aArgc, aArgv);

  std::string log_level = AppConfig::Instance().GetValue<std::string>("log-level");

  if (log_level.empty() == false)
  {
    Logger::SetLogLevel(Logger::StringToLevel(log_level.c_str()));
    LOG_FATAL(LOGGER, "Log level: " << log_level);
  }

  int fps = AppConfig::Instance().GetValue<int>("target-fps");

  if (fps > 0)
  {
    LOG_DEBUG(LOGGER, "Setting target FPS to " << fps);
    char fps_buf[16];
    snprintf(fps_buf, sizeof(fps_buf), "%d", fps);
    setenv("CLUTTER_DEFAULT_FPS", fps_buf, 1);
  }

  int msaa_samples = AppConfig::Instance().GetValue<int>("msaa-samples");

  if (msaa_samples > 0)
  {
    LOG_INFO(LOGGER, "Setting MSAA samples per pixel to " << msaa_samples);
    char msaa_samples_buf[16];
    snprintf(msaa_samples_buf, sizeof(msaa_samples_buf), "%d", msaa_samples);
    setenv("CLUTTER_MSAA_SAMPLES", msaa_samples_buf, 1);
  }
  else
  {
    unsetenv("CLUTTER_MSAA_SAMPLES");
  }

  std::string backend_opts = AppConfig::Instance().GetValue<std::string>("clutter.debug");

  if (backend_opts.length() > 0)
  {
    LOG_INFO(LOGGER, "Setting CLUTTER_DEBUG to " << backend_opts);
    setenv("CLUTTER_DEBUG", backend_opts.c_str(), 1);
  }
  else
  {
    unsetenv("CLUTTER_DEBUG");
  }

  backend_opts = AppConfig::Instance().GetValue<std::string>("clutter.paint");

  if (backend_opts.length() > 0)
  {
    LOG_INFO(LOGGER, "Setting CLUTTER_PAINT to " << backend_opts);
    setenv("CLUTTER_PAINT", backend_opts.c_str(), 1);
  }
  else
  {
    unsetenv("CLUTTER_PAINT");
  }

  backend_opts = AppConfig::Instance().GetValue<std::string>("cogl.debug");

  if (backend_opts.length() > 0)
  {
    LOG_INFO(LOGGER, "Setting COGL_DEBUG to " << backend_opts);
    setenv("COGL_DEBUG", backend_opts.c_str(), 1);
    unsetenv("COGL_NO_DEBUG");
  }
  else
  {
    unsetenv("COGL_DEBUG");
    setenv("COGL_NO_DEBUG", "all", 1);
  }

  if (AppConfig::Instance().GetValue<std::string>("profiler.enable") == "true")
  {
    LOG_INFO(LOGGER, "Enabling profiler");

    bool with_timer_events = false;

    if (AppConfig::Instance().GetValue<std::string>("profiler.timer-events") == "true")
    {
      with_timer_events = true;
    }

    char config[1024];
    snprintf(config, sizeof(config), "--prof --logfile %s %s",
             AppConfig::Instance().GetValue<std::string>("profiler.out").c_str(),
             with_timer_events ? "--log-timer-events" : "");

    LOG_DEBUG(LOGGER, "profile config: " << config);
    v8::V8::SetFlagsFromString(config, strlen(config));
  }

  std::string text_dir = AppConfig::Instance().GetValue<std::string>("text-direction");

  if (text_dir.length() > 0)
  {
    LOG_INFO(LOGGER, "Setting CLUTTER_TEXT_DIRECTION to " << text_dir);
    setenv("CLUTTER_TEXT_DIRECTION", text_dir.c_str(), 1);
  }
  else
  {
    unsetenv("CLUTTER_TEXT_DIRECTION");
  }

  TextWidget::setDefaultFont(AppConfig::Instance().GetValue<std::string>("default-font"));

  std::string highContrastMode = AppConfig::Instance().GetValue<std::string>("high-contrast-mode");
  if (highContrastMode == "black-on-white")
  {
    Widget::setHighContrastMode(Widget::HighContrastMode::BLACK_ON_WHITE);
  }
  else if (highContrastMode == "white-on-black")
  {
    Widget::setHighContrastMode(Widget::HighContrastMode::WHITE_ON_BLACK);
  }
  else
  {
    Widget::setHighContrastMode(Widget::HighContrastMode::OFF);
  }
}

gboolean VoltEngineImpl::DoShowUI(gpointer aData)
{
  InterthreadData *data = reinterpret_cast<InterthreadData *>(aData);

  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

  if (runtime)
  {
    runtime->ShowUI(data->second);
  }

  data->first->hidden_ = false;

  delete data;

  return FALSE;
}

gboolean VoltEngineImpl::DoHideUI(gpointer aData)
{
  InterthreadData *data = reinterpret_cast<InterthreadData *>(aData);

  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

  if (runtime)
  {
    runtime->HideUI(data->second);
  }

  data->first->hidden_ = true;

  delete data;

  return FALSE;
}

gboolean VoltEngineImpl::DoResetApp(gpointer aData)
{
  InterthreadData *data = reinterpret_cast<InterthreadData *>(aData);

  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

  if (runtime)
  {
    runtime->ResetApp(data->second);
  }

  delete data;

  return FALSE;
}
