/*
 * FrameWidget.cpp
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#include "FrameWidget.h"

using namespace volt::graphics;

FrameWidget::FrameWidget(float x, float y, float width, float height, Widget* parent,
                         LayoutOrientation aOrientation, LayoutAlignment aAlignX, LayoutAlignment aAlignY)
  : LayoutWidget(x, y, width, height, parent, aOrientation), alignX(aAlignX), alignY(aAlignY)
{
  layout = clutter_box_layout_new (); //Defaults to horizontal

  if (orientation == Vertical)
  {
    clutter_box_layout_set_orientation (CLUTTER_BOX_LAYOUT (layout), CLUTTER_ORIENTATION_VERTICAL);
  }

  clutter_actor_set_layout_manager (actor, layout);
}

/**
 * Helper method for setting the alignment on a ClutterActor.
 */
void FrameWidget::setAlignment(ClutterActor* actor, LayoutAlignment alignmentX, LayoutAlignment alignmentY)
{
  g_object_set(actor, "x-expand", true, "y-expand", true, NULL);

  switch(alignmentX)
  {
  case LayoutAlignment::Left:
    clutter_actor_set_x_align(actor, CLUTTER_ACTOR_ALIGN_START);
    break;
  case LayoutAlignment::Right:
    clutter_actor_set_x_align(actor, CLUTTER_ACTOR_ALIGN_END);
    break;
  case LayoutAlignment::Center:
    clutter_actor_set_x_align(actor, CLUTTER_ACTOR_ALIGN_CENTER);
    break;
  default:
    break;
  }

  switch(alignmentY)
  {
  case LayoutAlignment::Left:
    clutter_actor_set_y_align(actor, CLUTTER_ACTOR_ALIGN_START);
    break;
  case LayoutAlignment::Right:
    clutter_actor_set_y_align(actor, CLUTTER_ACTOR_ALIGN_END);
    break;
  case LayoutAlignment::Center:
    clutter_actor_set_y_align(actor, CLUTTER_ACTOR_ALIGN_CENTER);
    break;
  default:
    break;
  }
}


void FrameWidget::setOrientation(LayoutOrientation orientation)
{
  this->orientation = orientation;

  switch(orientation)
  {
  case Horizontal:
    clutter_box_layout_set_orientation (CLUTTER_BOX_LAYOUT (layout), CLUTTER_ORIENTATION_HORIZONTAL);
    break;
  case Vertical:
    clutter_box_layout_set_orientation (CLUTTER_BOX_LAYOUT (layout), CLUTTER_ORIENTATION_VERTICAL);
    break;
  default:
    break;
  }
}


void FrameWidget::setAlignX(LayoutAlignment newAlignX)
{
  alignX = newAlignX;

  for(auto iter = children.begin(); iter != children.end(); iter++)
  {
    setAlignment((*iter)->actor, newAlignX, alignY);
  }
}


void FrameWidget::setAlignY(LayoutAlignment newAlignY)
{
  alignY = newAlignY;

  for(auto iter = children.begin(); iter != children.end(); iter++)
  {
    setAlignment((*iter)->actor, alignX, newAlignY);
  }
}

int FrameWidget::addChild(Widget* child, int index)
{
  int result = Widget::addChild(child, index);
  setAlignment(child->actor, alignX, alignY);
  return result;
}

void FrameWidget::removeChild(Widget* target)
{
  g_object_set(target->actor, "x-expand", false, "y-expand", false, NULL);
  //alignment will have no effect if expand is set to false
  Widget::removeChild(target);
}

const std::string& FrameWidget::getWidgetTypeString() const
{
  static const std::string type("FrameWidget");
  return type;
}
