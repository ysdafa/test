#include "SefClient.h"

#include "VoltConfig.h"

#include <clutter/clutter.h>
#include "TaskDispatcher.h"

#include "SefBridge.h"

volt::util::Logger SefClient::LOGGER = volt::util::Logger("volt.sef.client");
SefClient::CALLBACK_MAP SefClient::callbackMap;

SefClient::SefClient()
#ifdef BUILD_FOR_TV
  : CSefPluginWrapper(sef::CClientAppFactory::SEF_CLIENT_WEBKIT)
#endif
{
  LOG_DEBUG(LOGGER, "SefClient created");
}

SefClient::~SefClient()
{
  LOG_DEBUG(LOGGER, "SefClient destroyed");
}

bool SefClient::Open(std::string aName,
                     std::string aVersion, std::string aCredential)
{
  LOG_DEBUG(LOGGER,
            "Open(" << aName << ", " << aVersion << ", " << aCredential << ")");

#ifdef BUILD_FOR_TV
  return CSefPluginWrapper::Open(aName, aVersion, aCredential);
#else
  return true;
#endif
}

bool SefClient::Close()
{
  LOG_DEBUG(LOGGER, "Close");

#ifdef BUILD_FOR_TV
  return CSefPluginWrapper::Close();
#else
  return true;
#endif
}

gboolean SefClient::HandleExecuteResponse(gpointer aResponseData)
{
  ExecuteResponse* exeData = reinterpret_cast<ExecuteResponse*>(aResponseData);

  CALLBACK_MAP::iterator callbackIt = callbackMap.find(exeData->client);

  if (callbackIt == callbackMap.end() || !callbackIt->second.onExecutedCB)
  {
    // executed callback is not defined
    LOG_DEBUG(LOGGER, "onExecutedCB function not set.");
    delete exeData;
    return false;
  }

  OnExecuteCallbackType func = callbackIt->second.onExecutedCB;
  callbackIt->second.onExecutedCB = nullptr;

  // call callback
  func(exeData->response);

  delete exeData;
  return false;
}

static void SefExecuteTask(SefClient *aSelf, std::string cmd_str, std::vector<std::string> args)
{
  LOG_DEBUG(SefClient::LOGGER, "Starting SefExecuteTask.");

  /* HACK HACK HACK */
  /* Register an idle callback to be executed on the main thread.
   * HandleExecuteResponse MUST be run on the main thread (or the same thread as v8)
   * since v8 is not thread-safe (by design?)!  */
  SefClient::ExecuteResponse* responseData = new SefClient::ExecuteResponse();
  responseData->client = aSelf;
  responseData->response = aSelf->Execute(cmd_str, args);
  clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                SefClient::HandleExecuteResponse, responseData, NULL);
}

void SefClient::ExecuteAsync(std::string aCmd, std::vector<std::string> &aArgs,
                             OnExecuteCallbackType callback)
{
  setLastCmd(aCmd);
  LOG_DEBUG(SefClient::LOGGER, "Running execute command \"" << getLastCmd() <<
            "\" on Sef, \"" << getName() << "\"");

  if (getExeThread().joinable())
  {
    LOG_ERROR(SefClient::LOGGER, "Unable to execute command, \"" + getLastCmd() +
              "\" on Sef, \"" + getName() +
              "\" while open or another execute is still running.");
    return;
  }

  LOG_DEBUG(SefClient::LOGGER, "Setting onExecutedCB.");
  callbackMap[this].onExecutedCB = callback;

  // Add SefExecuteTask to run the SefClient execute command. When its finished
  // it will call the onExcectedCB supplied.
  volt::util::TaskDispatcher::Instance().AddTask(std::bind(SefExecuteTask, this, aCmd, aArgs));
}

std::string SefClient::Execute(std::string aCmd, std::vector<std::string> &aArgs)
{
  LOG_DEBUG(LOGGER, "Command: " << aCmd);

  for (std::vector<std::string>::iterator iter = aArgs.begin();
       iter != aArgs.end(); ++iter)
  {
    LOG_DEBUG(LOGGER, "    Param: " << *iter);
  }

#ifdef BUILD_FOR_TV
  std::string p1 = aArgs.size() > 0 ? aArgs[0] : "";
  std::string p2 = aArgs.size() > 1 ? aArgs[1] : "";
  std::string p3 = aArgs.size() > 2 ? aArgs[2] : "";
  std::string p4 = aArgs.size() > 3 ? aArgs[3] : "";

  if (aArgs.size() < 5)
  {
    return CSefPluginWrapper::Execute(aCmd, p1, p2, p3, p4);
  }
  else
  {
    std::string p5 = aArgs.size() > 4 ? aArgs[4] : "";
    std::string p6 = aArgs.size() > 5 ? aArgs[5] : "";
    std::string p7 = aArgs.size() > 6 ? aArgs[6] : "";
    std::string p8 = aArgs.size() > 7 ? aArgs[7] : "";
    std::string p9 = aArgs.size() > 8 ? aArgs[8] : "";
    std::string p10 = aArgs.size() > 9 ? aArgs[9] : "";

    if (aArgs.size() > 10)
    {
      LOG_WARN(LOGGER, "Too many arguments (" << aArgs.size() << " given)...");
    }

    return CSefPluginWrapper::Execute(aCmd, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
  }

#else
  return "Adummy";
#endif
}

bool SefClient::OnEvent(int aEventType, std::string aParam1, std::string aParam2)
{
  LOG_DEBUG(LOGGER,
            "OnEvent(" << aEventType << ", " << aParam1 << ", " << aParam2 << ")");

  /* HACK HACK HACK */
  /* Register an idle callback to be executed on the main thread.
   * FireSefOnEvent MUST be run on the main thread (or the same thread as v8)
   * since v8 is not thread-safe (by design?)!  */
  Bridge::SefBridge::SefEventData *data = new Bridge::SefBridge::SefEventData();
  data->client = this;
  data->type = aEventType;
  data->param1 = aParam1;
  data->param2 = aParam2;
  clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW,
                                Bridge::SefBridge::FireSefOnEvent, data, NULL);
  return true;
}
