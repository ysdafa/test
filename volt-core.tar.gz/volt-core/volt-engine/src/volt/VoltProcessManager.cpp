#include "VoltProcessManager.h"

#include <sys/types.h>
#include <sys/wait.h>

#include "VoltMessageCenter.h"

#include "AppConfig.h"
#include "TaskDispatcher.h"

#ifdef ENABLE_MULTI_PROCESS
#include "VoltAppProcessRuntime.h"
#include "VoltGfxProcessRuntime.h"
#include "VoltWorkerProcessRuntime.h"
#endif

#include "VoltRuntimeMessages.h"
#include "VoltFullProcessRuntime.h"

using namespace volt::util;

Logger VoltProcessManager::LOGGER("volt.proc");

unsigned int VoltProcessManager::WORKER_ID = 0;

VoltProcessManager& VoltProcessManager::Instance()
{
  static VoltProcessManager singleton;
  return singleton;
}

VoltProcessManager::VoltProcessManager():
  pids_(), process_type_(0), runtime_()
{
}

VoltProcessManager::~VoltProcessManager()
{
}

bool VoltProcessManager::Initialize()
{
  LOG_DEBUG(LOGGER, "Initializing");

  return true;
}

bool VoltProcessManager::StartGfxProcess()
{
  LOG_DEBUG(LOGGER, "Starting the graphics process");

  if (AppConfig::Instance().IsSet("headless"))
  {
    LOG_FATAL(LOGGER, "Start graphics process as follows: " << GetGfxProcessCmd());
    return true;
  }

  bool retval = false;
  pid_t pid = fork();

  if (pid > 0)
  {
    /* parent */
    pids_[VoltMessageCenter::Instance().GfxProcessID()] = pid;
    retval = true;
  }
  else if (pid == 0)
  {
    /* child */
    LOG_DEBUG(LOGGER, "Gfx Process");

    std::vector<char *> args;
    GetGfxProcessArgs(args);

    execv(args[0], args.data());

    /* Shouldn't be here! */
    LOG_FATAL(LOGGER, "Failed to exec " << args[0]);

    _exit(EXIT_FAILURE);
  }
  else
  {
    /* error */
    LOG_FATAL(LOGGER, "Failed to fork");
  }

  return retval;
}

std::string VoltProcessManager::GetGfxProcessCmd() const
{
  std::vector<char *> args;
  GetGfxProcessArgs(args);

  std::ostringstream buf;

  for (unsigned int index = 0; index < args.size() - 1; ++index)
  {
    buf << args[index] << " ";
  }

  return buf.str();
}

bool VoltProcessManager::StartWorkerProcess(const std::string aAppJS,
    std::string &aID)
{
  LOG_DEBUG(LOGGER, "Starting a worker process");

  TaskDispatcher::Instance().PrepFork();

  std::ostringstream buf;
  buf << getpid() << "-" << WORKER_ID++;
  aID = buf.str();

  if (VoltMessageCenter::Instance().PrepareWorker(aID) == false)
  {
    LOG_WARN(LOGGER, "Failed to prep worker: " << aID);
    return false;
  }

  if (AppConfig::Instance().IsSet("headless"))
  {
    LOG_FATAL(LOGGER, "Start worker process as follows: " <<
              GetWorkerProcessCmd(aAppJS, aID));
    return true;
  }

  pid_t pid = fork();

  if (pid > 0)
  {
    /* parent */
    LOG_DEBUG(LOGGER, "Forked worker " << aID << ": " << pid);
    TaskDispatcher::Instance().AfterForkParent();

    pids_[aID] = pid;

    return true;
  }
  else if (pid == 0)
  {
    /* child */
    TaskDispatcher::Instance().AfterForkChild();
    //TaskDispatcher::Instance().Finish();
    LOG_DEBUG(LOGGER, "In worker process");

    std::vector<char *> args;
    GetWorkerProcessArgs(args, aAppJS, aID);

    execv(args[0], args.data());

    /* Shouldn't be here! */
    LOG_FATAL(LOGGER, "Failed to exec " << args[0]);

    _exit(EXIT_FAILURE);
  }
  else
  {
    /* error */
    LOG_FATAL(LOGGER, "Failed to fork worker process");
    TaskDispatcher::Instance().AfterForkParent();

    return false;
  }
}

void VoltProcessManager::StopVoltProcess(const std::string aID,
    const unsigned int aMaxWaitTime)
{
  if (IsAlive(aID))
  {
    if (aMaxWaitTime == 0)
    {
      LOG_WARN(LOGGER, "Force killing " << aID << " with SIGKILL");
      SendSignal(aID, SIGKILL);
      return;
    }

    LOG_DEBUG(LOGGER, "Stopping volt process " << aID << " with the Quit msg");
    VoltMessageCenter::Instance().PostMsgToProc(aID, VoltRuntimeMsg::Quit());

    static const unsigned int wait_increment = 10000; /* in usec */
    unsigned int max_wait = aMaxWaitTime * 1000; /* to usec */
    unsigned int waited = 0;

    if (max_wait > 0)
    {
      /* Let's wait some time to see if it terminates gracefully */
      do
      {
        usleep(wait_increment);
        waited += wait_increment;
      }
      while (waited < max_wait && IsAlive(aID));
    }

    if (IsAlive(aID))
    {
      LOG_WARN(LOGGER, "Force killing " << aID << " with SIGKILL");
      SendSignal(aID, SIGKILL);
    }

    /* Destroy the shared queue. */
    VoltMessageCenter::Instance().DestroyNamedQueue(aID);
  }
}

void VoltProcessManager::StopWorkerProcesses()
{
  for (auto iter = pids_.begin(); iter != pids_.end(); ++iter)
  {
    if (iter->first == VoltMessageCenter::Instance().GfxProcessID())
    {
      continue;
    }

    StopVoltProcess(iter->first);
  }
}

std::string VoltProcessManager::GetWorkerProcessCmd(const std::string aAppJS,
    const std::string aWorkerID) const
{
  std::vector<char *> args;
  GetWorkerProcessArgs(args, aAppJS, aWorkerID);

  std::ostringstream buf;

  for (unsigned int index = 0; index < args.size() - 1; ++index)
  {
    buf << args[index] << " ";
  }

  return buf.str();
}

bool VoltProcessManager::InitAppMain(int aArgc, char **aArgv)
{
  if (runtime_)
  {
    LOG_WARN(LOGGER, "Only 1 runtime can be started on a process");
    return false;
  }

  process_type_ = APP_PROCESS | WORKER_PROCESS;

#ifdef ENABLE_MULTI_PROCESS
  runtime_.reset(new VoltAppProcessRuntime());
  return runtime_->Initialize(aArgc, aArgv);
#else
  LOG_FATAL(LOGGER, "Running the main app process without gfx is not supported");
  return false;
#endif
}

bool VoltProcessManager::InitGfxMain(int aArgc, char **aArgv)
{
  if (runtime_)
  {
    LOG_WARN(LOGGER, "Only 1 runtime can be started on a process");
    return false;
  }

  process_type_ = GFX_PROCESS;

#ifdef ENABLE_MULTI_PROCESS
  runtime_.reset(new VoltGfxProcessRuntime());
  return runtime_->Initialize(aArgc, aArgv);
#else
  LOG_FATAL(LOGGER, "Running the gfx process is not supported");
  return false;
#endif
}

bool VoltProcessManager::InitWorkerMain(int aArgc, char **aArgv)
{
  if (runtime_)
  {
    LOG_WARN(LOGGER, "Only 1 runtime can be started on a process");
    return false;
  }

  process_type_ = WORKER_PROCESS;

#ifdef ENABLE_MULTI_PROCESS
  runtime_.reset(new VoltWorkerProcessRuntime());
  return runtime_->Initialize(aArgc, aArgv);
#else
  LOG_FATAL(LOGGER, "Running a worker process is not supported");
  return false;
#endif
}

bool VoltProcessManager::InitFullMain(int aArgc, char **aArgv,
                                      const VoltEngine::ExternalData &aData)
{
  if (runtime_)
  {
    LOG_WARN(LOGGER, "Only 1 runtime can be started on a process");
    return false;
  }

  process_type_ = FULL_PROCESS | ROOT_PROCESS;

  runtime_.reset(new VoltFullProcessRuntime());

  return runtime_->Initialize(aArgc, aArgv, aData);
}

bool VoltProcessManager::InitFullWorkerMain(int aArgc, char **aArgv,
    const VoltEngine::ExternalData &aData)
{
  if (runtime_)
  {
    LOG_WARN(LOGGER, "Only 1 runtime can be started on a process");
    return false;
  }

  process_type_ = FULL_PROCESS | WORKER_PROCESS;

  runtime_.reset(new VoltFullProcessRuntime());

  return runtime_->Initialize(aArgc, aArgv, aData);
}

bool VoltProcessManager::Run()
{
  if (!runtime_)
  {
    LOG_WARN(LOGGER, "Process runtime not initialized yet");
    return false;
  }

  return runtime_->Main();
}

void VoltProcessManager::Cleanup()
{
  if (!runtime_)
  {
    LOG_WARN(LOGGER, "Process runtime not initialized yet");
    return;
  }

  runtime_->Cleanup();
}

uint8_t VoltProcessManager::ProcessType() const
{
  return process_type_;
}

std::shared_ptr<IVoltProcessRuntime> VoltProcessManager::Runtime() const
{
  return runtime_;
}

bool VoltProcessManager::SendSignal(const std::string &aID, const int aSigNum) const
{
  auto iter = pids_.find(aID);

  if (iter == pids_.end())
  {
    return false;
  }

  pid_t pid = iter->second;

  if (pid > 0)
  {
    LOG_DEBUG(LOGGER, "Sending signal " << aSigNum << " to " << aID << ": " << pid);

    if (kill(pid, aSigNum) < 0)
    {
      LOG_WARN(LOGGER, "Failed to send " << aSigNum << " to " << aID << ": " << pid);
      return false;
    }
  }

  return true;
}

bool VoltProcessManager::IsAlive(const std::string aID)
{
  auto iter = pids_.find(aID);

  if (iter == pids_.end())
  {
    LOG_DEBUG(LOGGER, "Failed to find the PID of worker " << aID);
    return false;
  }

  pid_t pid = iter->second;

  if (pid == 0)
  {
    LOG_DEBUG(LOGGER, aID << " (" << pid << ") already exited");
    return false;
  }

  int status = 0;
  int result = waitpid(pid, &status, WNOHANG);

  if (result < 0)
  {
    LOG_WARN(LOGGER, "Failed to wait for " << aID << ": " << pid);
    return true;
  }
  else if (result == 0)
  {
    LOG_DEBUG(LOGGER, "No change in " << aID << ": " << pid);
    return true;
  }
  else if (WIFEXITED(status) || WIFSIGNALED(status))
  {
    LOG_DEBUG(LOGGER, aID << " exited: " << pid);
    iter->second = 0;
    return false;
  }
  else
  {
    LOG_DEBUG(LOGGER, aID << " not exited yet: " << pid);
    return true;
  }
}

void VoltProcessManager::Wait()
{
  auto iter = pids_.begin();

  while (iter != pids_.end())
  {
    LOG_WARN(LOGGER, "Wait for " << iter->first << ": " << iter->second);

    if (iter->second == 0)
    {
      LOG_DEBUG(LOGGER, iter->first << " (" << iter->second << ") already exited");
      ++iter;
      continue;
    }

    int status = 0;
    int result = waitpid(iter->second, &status, 0);

    if (result < 0)
    {
      LOG_WARN(LOGGER, "Failed to wait for " << iter->first << ": " << iter->second);
      ++iter;
      continue;
    }
    else if (result == 0)
    {
      LOG_WARN(LOGGER, "No change in " << iter->first << ": " << iter->second);
      ++iter;
      continue;
    }
    else if (WIFEXITED(status) || WIFSIGNALED(status))
    {
      LOG_DEBUG(LOGGER, iter->first << " (" << iter->second << ") exited");
      iter = pids_.erase(iter);
      continue;
    }
    else
    {
      LOG_DEBUG(LOGGER, iter->first << " (" << iter->second << ") not exited yet");
      ++iter;
      continue;
    }
  }
}

void VoltProcessManager::GetGfxProcessArgs(std::vector<char *> &aArgs) const
{
  aArgs = AppConfig::Instance().OriginalArgs();
  aArgs[aArgs.size() - 1] = strdup("--gfx");
  aArgs.push_back(strdup(VoltMessageCenter::Instance().ID().c_str()));

  aArgs.push_back(static_cast<char *>(NULL));

  for (unsigned int index = 0; index < aArgs.size() - 1; ++index)
  {
    LOG_DEBUG(LOGGER, "Arg[" << index << "]: " << aArgs[index]);
  }
}

void VoltProcessManager::GetWorkerProcessArgs(std::vector<char *> &aArgs,
    const std::string aAppJS,
    const std::string aWorkerID) const
{
  aArgs = AppConfig::Instance().OriginalArgs();
  aArgs[aArgs.size() - 1] = strdup(aAppJS.c_str());
  aArgs.push_back(strdup("--worker"));
  aArgs.push_back(strdup(VoltMessageCenter::Instance().ID().c_str()));
  aArgs.push_back(strdup("--worker-id"));
  aArgs.push_back(strdup(aWorkerID.c_str()));
  aArgs.push_back(strdup("--parent-id"));
  aArgs.push_back(strdup(VoltMessageCenter::Instance().ProcessID().c_str()));
  aArgs.push_back(strdup("--app-root"));
  aArgs.push_back(strdup(AppConfig::Instance().GetAppRootPath().c_str()));

  aArgs.push_back(static_cast<char *>(NULL));

  for (unsigned int index = 0; index < aArgs.size() - 1; ++index)
  {
    LOG_DEBUG(LOGGER, "Arg[" << index << "]: " << aArgs[index]);
  }
}
