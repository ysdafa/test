#include "VoltFullProcessRuntime.h"
#include "Volt.h"
#include "appcore-volt.h"

#include "logger.h"
#include <power_tv.h>
#include <dd-power.h>

static volt::util::Logger LOGGER("volt.main");

#define TEST_EXTERNAL_GMAINLOOP

#ifdef TEST_EXTERNAL_GMAINLOOP
#include <glib.h>
#endif

#include "volt/Volt.h"

#include <sys/types.h>
#include <unistd.h>
#include <thread>
#include <vector>
#include <string>

#include <aul.h>
#include <dlog.h>
#include "clutter_helper.h"
#include <streamline/streamline_annotate.h>

#include <boost/algorithm/string/predicate.hpp>
#include <boost/lexical_cast.hpp>
#include <time.h>

#include <avoc_3d.h>

#ifdef HAS_VCONF
#include "vconf.h"
#define VCONF_KEY_CURSOR_VISIBLE "memory/window_system/input/cursor_visible"
#define VCONF_KEY_WIZARD "db/boot/need_setup_wizard"
#endif
#include "system_info.h"
#include <aul.h>

//#define TEST_RESET_APP
//#define TEST_SCENE_ROOT

#ifdef TEST_SCENE_ROOT
#include "SceneRoot.h"
#endif

#ifdef LOG_TAG
#undef LOG_TAG
#endif

#define LOG_TAG "VOLT_CONTAINER"

/* Utility macros to log timestamp */
#define LOG_TAG_TS LOG_TAG "_TS"
#define LOG_TS(msg) do \
{ \
struct timeval tv; \
	gettimeofday(&tv, NULL); \
	__dlog_print(LOG_ID_MAIN, DLOG_DEBUG, LOG_TAG_TS, "[%lu.%06lu|%s] %s\n", tv.tv_sec, tv.tv_usec, __func__, (msg) ? (msg) : ""); \
} while (0)

ANNOTATE_DEFINE;

int globalargc;
char **globalargv;

bundle *b_dup_deeplink;

funcP HaloInitialize = NULL;
funcP HaloFinalize = NULL;
funcP2 SetupVDDisplayFn = NULL;
funcP2 XRaiseWindowFn = NULL;

int justReady = 0;
int autoStart = 0;

#define JSON_LENGTH 2048
//#define SCREEN_CAPTURE_LENGTH 1024

static VoltFullProcessRuntime* GetVoltFullProcessRuntime()
{
	VoltFullProcessRuntime *runtime =
		static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

	return runtime;
}

static void vconf_key_change_cb(keynode_t *key_node, void *dt)
{

	char *keyname = vconf_keynode_get_name(key_node);
	if(keyname != NULL)
	{
		if(!strncmp(keyname, VCONF_KEY_CURSOR_VISIBLE, strlen(keyname)))
		{
			int val;
			vconf_get_int(VCONF_KEY_CURSOR_VISIBLE, &val);
			if(!val)
			{
				if(GetVoltFullProcessRuntime() != NULL)
				{
				 	if(GetVoltFullProcessRuntime()->script_engine_ != NULL)
				 	{
						GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_CURSOR_HIDE);
						LOG_FATAL(LOGGER, "Cursor is Hidden");
				 	}
				}
			}
		}
	}

}

int app_launch_handler(int pid, void *data)
{
	LOGE("[Volt] app_launch_handler: %d\n", pid);
	VoltEventArgsMap mval;
	char pkgname[255] = { 0, };
	char appid[255] = { 0, };
	
	aul_app_get_appid_bypid(pid, appid, sizeof(appid));
	aul_app_get_pkgname_bypid(pid, pkgname, sizeof(pkgname));
	mval.InsertString("appid", std::string(appid));
	mval.InsertString("pkgname", std::string(pkgname));
	if(GetVoltFullProcessRuntime() != NULL)
	{
	 	if(GetVoltFullProcessRuntime()->script_engine_ != NULL)
	 	{
			GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_APP_LAUNCH, mval);
			LOG_FATAL(LOGGER, "Cursor is Hidden");
	 	}
	}	
	return 0;
}

using namespace volt::util;

namespace
{
	VoltEngine *engine_ = NULL;

	std::string prog_name_;
	std::vector<char *> args_;
	bool launched_via_aul_ = false;
	bool firstReset = true;

	int OnCreate(void *data)
	{
		LOGE("[VOLT] >>>>>>>>>>>>>>>> OnCreate");
		
		printf("[LYJ] OnCreate! %d\n", justReady);
		LOG_TS("");
		LOGD("Doing nothing here\n");
		if (justReady == 1)
		{
			printf("-------------------- justReady\n");
			return 0;
		}
		avoc_set_3d_mode_async(0, AVOC_3D_EFFECT_OFF, AVOC_NO_SAVE);

		return 0;
	}


	int OnTerminate(void *data)
	{
		LOGE("[VOLT] >>>>>>>>>>>>>>>> OnTerminate");
		LOGD("Received terminate.. \n");
		engine_->Quit();
		engine_->Cleanup();
		return 0;
	}

	int OnPause(void *data)
	{
		LOGE("[VOLT] >>>>>>>>>>>>>>>> OnPause");
		volt::util::Capture();
		LOGD("Hiding Volt UI...\n");

		VoltFullProcessRuntime *runtime =
			static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
		runtime->script_engine_->sendInteruptEvent(volt::util::ON_PAUSE);
		return 0;
	}

	int OnResume(void *data)
	{
		LOGE("[VOLT] >>>>>>>>>>>>>>>> OnResume");
		LOGD("Showing Volt UI...\n");

		avoc_set_3d_mode_async(0, AVOC_3D_EFFECT_OFF, AVOC_NO_SAVE);
    
    if(AppConfig::Instance().IsFirstScreen())
		{
			volt::util::VDRaiseXWindow(GetMainStage()); 
		}

		VoltFullProcessRuntime *runtime =
			static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
		runtime->script_engine_->sendInteruptEvent(volt::util::ON_RESUME);

		return 0;
	}

	void BundleIterator(const char *aKey, const char *aVal, void *aData)
	{
		LOGD("bundle[%s] = %s\n", aKey, aVal);
		printf("bundle[%s] = %s\n", aKey, aVal);

		if (strncmp(aKey, "__AUL_", 6) == 0)
		{
			/* Assume launched by AUL if the bundle contains AUL keys. */
			launched_via_aul_ = true;
		}
		else if (strncmp(aKey, "--", 2) == 0)
		{
			/* Only using the keys with "--" prefix.
			* This is a work around for the bug in aul_test where it adds extra data
			* to the bundle.  For example, if volt-container is launched like this:
			*   aul_test launch volt-container key1 val1 key2 val2
			* aul_test will put the following key-val pair into the bundle:
			*   key1=>val1, val1=>key2, key2=>val2
			*/
			args_.push_back(strdup(aKey));
			args_.push_back(strdup(aVal));
		}
	}

	void bundleIteratorReset(const char *aKey, const char *aVal, void *aData)
	{
		if (strncmp(aKey, "__", 2) == 0)
		{
			//do Nothing it's AUL key
		}
		else
		{
			VoltEngine::ExternalData* external = (VoltEngine::ExternalData*) aData;
			external->eventArgs.InsertString(aKey, aVal);
		}
	}

	int OnReset(bundle *b, void *data)
	{
		LOGE("[VOLT] >>>>>>>>>>>>>>>> OnReset");
		LOG_TS("");
		LOGD("Initializing VoltEngine...\n");
		
		if(AppConfig::Instance().IsFirstScreen())
		{
			int value = 0;
			int systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_CERT_OPTION, &value);
			int vconfResult =0;
			
			LOGE("[Volt] Cert Option is %d\n", value);
			
			if(value == 1)
			{
				LOGE("[Volt] Cert Option is HIDE\n");
				return 0;
			}
			
			else if(systemResult)
			{
				LOGE("[Volt] Get SYSTEM_INFO_KEY_CERT_OPTION Fail!\n");
			}

			vconf_get_int(VCONF_KEY_WIZARD, &vconfResult);

			if(vconfResult == 1)
			{
				LOGE("[Volt] Setup_Wizard Value = 1 / FirstScreen Return!\n");
				return 0;
			}
			
		}
		
		if (justReady == 1)
		{
			printf("-------------------- skipped\n");
			justReady = 0;
			LOGE("[Volt] jsutReady == 1\n");
			return 0;
		}
		
		LOG_DEBUG(LOGGER, "[LYJ]-------------------- autostart " << autoStart << endl);

		avoc_set_3d_mode_async(0, AVOC_3D_EFFECT_OFF, AVOC_NO_SAVE);

		/* Clear args_ (populated with command line args) and re-populate with the
		* options given via the bundle. */
		args_.clear();
		/* First arg is always the prog name. */
		args_.push_back(strdup(prog_name_.c_str()));

		/* Populate with bundle data. */
		bundle_iterate(b, BundleIterator, NULL);


		VoltEngine::ExternalData external;
		bundle_iterate(b, bundleIteratorReset, (void*)&external);

		if (firstReset)
		{
			firstReset = false;

			bundle_iterate(b_dup_deeplink, bundleIteratorReset, (void*)&external);
			LOG_TS("Before Initialize");
			if (engine_->Initialize(args_.size(), args_.data(), external) == false)
			{
				LOGE("Failed to initialize/run VoltEngine...\n");
			}
			vconf_notify_key_changed(VCONF_KEY_CURSOR_VISIBLE, vconf_key_change_cb, NULL);
			aul_listen_app_launch_signal(app_launch_handler, NULL);
			LOG_TS("After Initialize");
			LOGE("[Volt] firstReset!\n");
		}
		else
		{
			LOG_DEBUG(LOGGER, "[LYJ]-------------------- OnReset setCallerAppID");
			volt::util::setCallerAppID(bundle_dup(b));
			volt::util::VDRaiseXWindow(GetMainStage());
			engine_->ResetApp(external.eventArgs);
			LOGE("[Volt] engine_ -> ResetApp!\n");
		}
		LOGE("[Volt] OnReset Call Complete!\n");
		return 0;
	}

} /* namespace */

static int onSuspend(int option, void *data)
{
	LOG_FATAL(LOGGER, "[Volt] Engine On_Suspend Call! [%d] \n" << option);
	
	if (GetVoltFullProcessRuntime() == NULL)
	{
		return 0;
	}
	
	try
	{
		if (option & POWER_OFF_TO_SUSPEND)
		{
			GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_SUSPEND);
		}
		else if (option == POWER_OFF_REASON_FACTORY_RESET)
		{
			GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_FACTORY_RESET);
		}
		else if (option == POWER_OFF_REASON_SERVICE_RESET)
		{
			GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_SERVICE_RESET);
		}
	}
	catch(...)
	{
	}

	return 0;
}

static void onWakeup(int option, void *data)
{
	
	if(GetVoltFullProcessRuntime() != NULL)
	{
		try
		{
			LOG_FATAL(LOGGER, "[Volt] Engine On_Wake_Up Call!\n");
			GetVoltFullProcessRuntime()->script_engine_->sendInteruptEvent(volt::util::ON_WAKEUP);
			int result = -1;
			result = power_subscribe_poweroff(onSuspend, (void *)GetVoltFullProcessRuntime());
			LOG_FATAL(LOGGER, "[Volt] Engine On_Suspend Callback Register!\n");
			if (result < 0)
			{
				LOG_FATAL(LOGGER, "Failed to Unsubscribe Poweroff\n");
			}
		}
		catch(...)
		{
		}
	}
}

extern "C" void setAutoStart(int start)
{
	printf("setAutoStart: %d\n", start);
	autoStart = start;
}

extern "C" void setJustReady(int ready)
{
	printf("setJustReady: %d\n", ready);
	justReady = ready;
}

extern "C" void register_halo_init_func(funcP p1, funcP p2, funcP2 p3, funcP2 p4)
{
	HaloInitialize = p1;
	HaloFinalize = p2;
	SetupVDDisplayFn = p3;
	XRaiseWindowFn = p4;
}

extern "C" int startvolt(int aArgc, char **aArgv, int gargc, char *gargv[], bundle *deep_link)
{
	LOG_TS("");
	
	globalargc = gargc;
	globalargv = gargv;
	b_dup_deeplink = bundle_dup(deep_link); // duplicate deeplink 
	volt::util::setCallerBundler(b_dup_deeplink);	// capture api
	LOG_DEBUG(LOGGER, "[LYJ]-------------------- startvolt setCallerAppID");
	volt::util::setCallerAppID(b_dup_deeplink);

	int result = -1;
	result = power_subscribe_poweroff(onSuspend, (void *)GetVoltFullProcessRuntime());
	if (result < 0)
	{
		LOG_FATAL(LOGGER, "Failed to Unsubscribe Poweroff\n");
	}

	result = power_subscribe_wakeup(onWakeup, (void *)GetVoltFullProcessRuntime());
	if (result < 0)
	{
		LOG_FATAL(LOGGER, "Failed to Unsubscribe Wakeup\n");
	}
	engine_ = VoltEngine::New();

	LOGD("Initializing VoltEngine %s...\n", VOLT_VERSION);

	prog_name_ = aArgv[0];
	args_.push_back(strdup(prog_name_.c_str()));

	/* Get data from the bundle.
	* args_ will be populated in BundleIterator */
	bundle *b = bundle_import_from_argv(aArgc, aArgv);
	bundle_iterate(b, BundleIterator, NULL);
	bundle_free(b);

	for (int i = 0; i < aArgc; i++) {
		args_.push_back(aArgv[i]);
	}

	if (launched_via_aul_ == false)
	{
		/* Use the original args if not launched via AUL... */
		args_.assign(aArgv, aArgv + aArgc);
	}

	for (unsigned int index = 0; index < args_.size(); ++index)
	{
		printf("args_[%d] = %s\n", index, args_[index]);
	}

	LOG_TS("Before ParseOptions...");
	if (engine_->ParseOptions(args_.size(), args_.data()))
	{
		LOG_TS("After ParseOptions...");
		if (engine_->IsAppProcess())
		{
			/* This is the main app process; register appcore event handlers */

			struct appcore_ops ops;
			ops.create = OnCreate;
			ops.terminate = OnTerminate;
			ops.pause = OnPause;
			ops.resume = OnResume;
			ops.reset = OnReset;

			LOG_TS("");
			LOGD("Starting appcore_efl_main\n");
//			appcore_efl_main("volt-container", &aArgc, &aArgv, &ops);
			appcore_volt_main("volt-container", &aArgc, &aArgv, &ops);
		}
		else
		{
			if (engine_->Initialize(args_.size(), args_.data()))
			{
				/* Child Volt processes do not need to handle appcore events... */
				if (engine_->Run() == false)
				{
					LOGE("Failed to run VoltEngine...\n");
				}
			}
			else
			{
				LOGE("Failed to initialize/run VoltEngine...\n");
			}
		}
	}
/*
	if (HaloFinalize && AppConfig::Instance().IsFirstScreen() == false)
	{
		HaloFinalize();
		LOG_INFO(LOGGER, "HaloFinalize Complete");
	}
*/	
	LOGD("Cleaning up VoltEngine...\n");
	bundle_free(b_dup_deeplink);
	engine_->Cleanup();

	delete engine_;
	
	return 0;
}

void* GetMainStage()
{
	VoltFullProcessRuntime *runtime =
		static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());

	return runtime->GetMainStage();
}

void RegisterPluginBridge(Bridge::ScriptBridge* bridge)
{
	VoltFullProcessRuntime *runtime =
		static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
	runtime->RegisterPluginBridge(bridge);
}
