#include "VoltEngine.h"
#include "VoltEngineImpl.h"

VoltEngine* VoltEngine::New()
{
  return new VoltEngineImpl();
}
