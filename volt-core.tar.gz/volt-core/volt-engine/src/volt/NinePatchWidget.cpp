#include "NinePatchWidget.h"
#include "VoltImage.h"

using namespace volt::graphics;

NinePatchWidget::NinePatchWidget(float x, float y, Widget* parent, Vector2 cornerDimension)
  : ImageWidget(x, y, parent), corner(cornerDimension), renderThreadSourceImagePointer(nullptr)
{
  for (int i = 0; i < 9; ++i)
  {
    patches[i] = volt_actor_new();
    clutter_actor_add_child(actor, patches[i]);
  }
}

NinePatchWidget::~NinePatchWidget()
{
  for (int i = 0; i < 9; ++i)
  {
    clutter_actor_remove_child(actor, patches[i]);
    //clutter_actor_destroy(patches[i]); //apparently remove_child is enough to unref it
  }
}

void NinePatchWidget::attachVoltImage(VoltImage* image)
{
  //Set correct image dimensions
  float width, height, nativeWidth, nativeHeight;
  clutter_content_get_preferred_size(CLUTTER_CONTENT(image),
                                     &nativeWidth, &nativeHeight);

  if (scaleImageDimensions)
  {
    width = getWidth();
    height = getHeight();
  }
  else
  {
    width = nativeWidth;
    height = nativeHeight;
    setWidth(width);
    setHeight(height);
  }

  for (int i = 0; i < 9; ++i)
  {
    VoltImage* patchImage = image;

    //Make new volt images with references to the same texture for each patch
    if (i > 0)
    {
      patchImage = VOLT_IMAGE(volt_image_new());
      volt_image_set_texture_share(patchImage, &renderThreadSourceImagePointer, false);
    }
    else 
    { //this code gets run on the "owner" image
      volt_image_set_texture_share(patchImage, &renderThreadSourceImagePointer, true);
    }

    setPatchImageTextureCoords(patchImage, (PatchDirection)i, nativeWidth, nativeHeight);

    clutter_actor_set_content(patches[i], CLUTTER_CONTENT(patchImage));

    volt_actor_set_width(VOLT_ACTOR(patches[i]), width);
    volt_actor_set_height(VOLT_ACTOR(patches[i]), height);
  }

  initializePatches();

  //whenever the width and height of actor are changed, call onResize, which will set the dimensions of the patches to match
  g_signal_connect(actor, "notify::size", (GCallback)onResize, this);
}

void NinePatchWidget::setPatchImageTextureCoords(VoltImage* image, PatchDirection dir, float nativeWidth, float nativeHeight)
{
  switch (dir)
  {
  case UpperLeft:
    volt_image_set_subtexture_rectangle(image, 0, 0, corner.x, corner.y);
    break;

  case UpperRight:
    volt_image_set_subtexture_rectangle(image, nativeWidth - corner.x, 0, nativeWidth, corner.y);
    break;

  case LowerLeft:
    volt_image_set_subtexture_rectangle(image, 0, nativeHeight - corner.y, corner.x, nativeHeight);
    break;

  case LowerRight:
    volt_image_set_subtexture_rectangle(image, nativeWidth - corner.x, nativeHeight - corner.y, nativeWidth, nativeHeight);
    break;

  case Up:
    volt_image_set_subtexture_rectangle(image, corner.x, 0, nativeWidth - corner.x, corner.y);
    break;

  case Down:
    volt_image_set_subtexture_rectangle(image, corner.x, nativeHeight - corner.x, nativeWidth - corner.x, nativeHeight);
    break;

  case Left:
    volt_image_set_subtexture_rectangle(image, 0, corner.y, corner.x, nativeHeight - corner.y);
    break;

  case Right:
    volt_image_set_subtexture_rectangle(image, nativeWidth - corner.x, corner.y, nativeWidth, nativeHeight - corner.y);
    break;

  case Center:
    volt_image_set_subtexture_rectangle(image, corner.x, corner.y, nativeWidth - corner.x, nativeHeight - corner.y);
    break;
  }
}

void NinePatchWidget::onResize(GObject* object, GParamSpec* paramSpec, gpointer data)
{
  NinePatchWidget* self = reinterpret_cast<NinePatchWidget*>(data);
  self->updatePatches();
}

//helper function for updating patch actors
namespace
{

void setPosition(VoltActor* actor, float x, float y)
{
  clutter_actor_set_x(CLUTTER_ACTOR(actor), x);
  clutter_actor_set_y(CLUTTER_ACTOR(actor), y);
}

void setDimensions(VoltActor* actor, float width, float height)
{
  volt_actor_set_width(actor, width);
  volt_actor_set_height(actor, height);
}

void setPositionAndDimensions(VoltActor* actor, float x, float y, float width, float height)
{
  setPosition(actor, x, y);
  setDimensions(actor, width, height);
}

void setAnchorAndOriginX(VoltActor* actor, float val)
{
  volt_actor_set_anchor_x(actor, val);
  volt_actor_set_origin_x(actor, val);
}

void setAnchorAndOriginY(VoltActor* actor, float val)
{
  volt_actor_set_anchor_y(actor, val);
  volt_actor_set_origin_y(actor, val);
}
}

void NinePatchWidget::initializePatches()
{
  setAnchorAndOriginX(getPatch(UpperRight), 1);

  setAnchorAndOriginY(getPatch(LowerLeft), 1);

  setAnchorAndOriginX(getPatch(LowerRight), 1);
  setAnchorAndOriginY(getPatch(LowerRight), 1);

  setPositionAndDimensions(getPatch(UpperLeft), 0,0, corner.x, corner.y);
  setPositionAndDimensions(getPatch(UpperRight), 0,0, corner.x, corner.y);
  setPositionAndDimensions(getPatch(LowerLeft), 0,0, corner.x, corner.y);
  setPositionAndDimensions(getPatch(LowerRight), 0,0, corner.x, corner.y);


  setPosition(getPatch(Left),  0, corner.y);

  setAnchorAndOriginX(getPatch(Right), 1);
  setPosition(getPatch(Right), 0, corner.y);

  setPosition(getPatch(Up), corner.x, 0);

  setAnchorAndOriginY(getPatch(Down), 1);
  setPosition(getPatch(Down), corner.x, 0);

  setPosition(getPatch(Center), corner.x, corner.y);

  updatePatches();
}

void NinePatchWidget::updatePatches()
{
  float width = getWidth();
  float height = getHeight();

  setDimensions(getPatch(Left),  corner.x, height - corner.y*2);
  setDimensions(getPatch(Right), corner.x, height - corner.y*2);
  setDimensions(getPatch(Up),   width - corner.x*2, corner.y);
  setDimensions(getPatch(Down), width - corner.x*2, corner.y);
  setDimensions(getPatch(Center), width - corner.x*2, height - corner.y*2);
}

VoltActor* NinePatchWidget::getPatch(PatchDirection patchDir)
{
  return VOLT_ACTOR(patches[(int)patchDir]);
}

const std::string& NinePatchWidget::getWidgetTypeString() const
{
  static const std::string type("NinePatchWidget");
  return type;
}
