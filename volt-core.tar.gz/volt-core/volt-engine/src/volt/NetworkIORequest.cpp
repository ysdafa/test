/*
 * IOManager.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "NetworkIORequest.h"

#include <string.h>
#include <cstring>
#include <iomanip>
#include <pthread.h>

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

#include <boost/serialization/export.hpp>
/* These MUST be included for the BOOST_CLASS_EXPORT to work! */
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>

#include <boost/config.hpp>

#include "DirIORequest.h"
#include "FileIORequest.h"

#include "string_util.h"

BOOST_CLASS_EXPORT(Resource::NetworkIOResponse)

/* Volt configuration options. */
#include "AppConfig.h"

using namespace volt::util;

namespace Resource
{

/******************************************************************************
 * NetworkIOResponse
 *****************************************************************************/

Logger NetworkIOResponse::LOGGER("volt.network.response");

static std::string CacheableFilePattern = "image/";

static Logger RES_LOGGER("volt.network.response");

/** Pointer to the CURL shared state. */
static CURLSH *s_curl_share = NULL;
/** Mutex to use to protect access to shared state. */
static pthread_mutex_t s_curl_mutex = PTHREAD_MUTEX_INITIALIZER;
/** Path to the persistent cookie state. */
static std::string s_cookiejar_path = "./data";

NetworkIOResponse::NetworkIOResponse():
  IOResponse(), is_cacheable_(true), date_(), max_age_(), expires_(),
  last_modified_(), etag_()
{
  LOG_DEBUG(RES_LOGGER, "Born: " << uri());

  set_source(SOURCE_NETWORK);
}

NetworkIOResponse::NetworkIOResponse(const NetworkIORequest &aRequest):
  IOResponse(aRequest), is_cacheable_(true), date_(), max_age_(), expires_(),
  last_modified_(), etag_()
{
  LOG_DEBUG(RES_LOGGER, "Born: " << uri());

  set_source(SOURCE_NETWORK);
}

NetworkIOResponse::~NetworkIOResponse()
{
  LOG_DEBUG(RES_LOGGER, "Dead: " << uri());
}

size_t NetworkIOResponse::ParseHeader(const char *aBuffer, size_t aSize,
                                      NetworkIOResponse::SharedPtr response)
{
  const char *colon = strchr(aBuffer, ':');

  if (colon)
  {
    std::string key(aBuffer, colon - aBuffer);
    std::string val(colon + 1);
    boost::trim(key);
    boost::trim(val);

    response->SetHeader(key, val);

    LOG_DEBUG(RES_LOGGER, "key: " << key);
    LOG_DEBUG(RES_LOGGER, "val: " << val);

    if (boost::iequals(key, "Date"))
    {
      date_.ParseHttpTime(val);
    }
    else if (boost::iequals(key, "Expires"))
    {
      expires_.ParseHttpTime(val);
    }
    else if(boost::iequals(key, "Content-Type"))
    {
      std::transform(val.begin(), val.end(), val.begin(), ::tolower);

      if(val.find("charset=utf-8") != std::string::npos)
      {
        data()->SetFormat(DataBuffer::Format::Utf8);
      }
      else if(val.find("charset=utf-16") != std::string::npos)
      {
        data()->SetFormat(DataBuffer::Format::Utf16);
      }
    }
    else if(boost::iequals(key, "Content-Length"))
    {
      size_t size = atoi(val.c_str());
      // we will assign 1 extra byte here and 1 extra byte internally
      // in case we get UTF16 encoding and end up with an odd byte count
      data()->reserve(size + 1);
    }
    else if (boost::iequals(key, "Cache-Control"))
    {
      std::vector<std::string> controls;
      boost::split(controls, val, boost::is_any_of(","));
#ifdef BOOST_NO_CXX11_RANGE_BASED_FOR

      for (auto iter = controls.begin(); iter != controls.end(); ++iter)
      {
        boost::trim(*iter);

        LOG_DEBUG(RES_LOGGER, "control: " << *iter);

        if (boost::istarts_with(*iter, "max-age="))
        {
          int max_age = boost::lexical_cast<int>(iter->substr(8));
          max_age_ = volt::util::Time(max_age);
          LOG_DEBUG(RES_LOGGER, "max_age_ = " << max_age_);
        }
        else if (boost::iequals(*iter, "private"))
        {
          /* Don't cache private data. */
          is_cacheable_ = false;
          LOG_DEBUG(RES_LOGGER, "Private data: " << uri());
        }
      }

#else

for (std::string &control: controls)
      {
        boost::trim(control);

        LOG_DEBUG(RES_LOGGER, "control: " << control);

        if (boost::istarts_with(control, "max-age="))
        {
          int max_age = boost::lexical_cast<int>(control.substr(8));
          max_age_ = volt::util::Time(max_age);
          LOG_DEBUG(RES_LOGGER, "max_age_ = " << max_age_);
        }
        else if (boost::iequals(control, "private"))
        {
          /* Don't cache private data. */
          is_cacheable_ = false;
          LOG_DEBUG(RES_LOGGER, "Private data: " << uri());
        }
      }

#endif
    }
    else if (boost::iequals(key, "ETag"))
    {
      etag_ = val;
    }
    else if (boost::iequals(key, "Last-Modified"))
    {
      last_modified_.ParseHttpTime(val);
    }
  }
  else
  {
    char version[2];
    char code[4];

    if (sscanf(aBuffer, "HTTP/1.%1[01] %3[0-9] ", version, code) == 2)
    {
      /* strlen("HTTP/1.0 200 ") == 13 " */
      std::string reason(aBuffer + 13);
      boost::trim(reason);
      set_reason_string(reason);

      LOG_DEBUG(RES_LOGGER, "HTTP version: 1." << version);
      LOG_DEBUG(RES_LOGGER, "HTTP code: " << code);
      LOG_DEBUG(RES_LOGGER, "Reason string: " << reason_string());
    }
    else
    {
      LOG_DEBUG(RES_LOGGER, "Invalid header: " << aBuffer);
    }
  }

  return aSize;
}

bool NetworkIOResponse::IsCacheable() const
{
  return is_cacheable_ && type().compare(0, CacheableFilePattern.length(),
                                         CacheableFilePattern) == 0;
}

bool NetworkIOResponse::IsExpired() const
{
  volt::util::Time freshness_lifetime;
  volt::util::Time current_age = volt::util::Time::Now() - date_;
  LOG_DEBUG(RES_LOGGER, "now: " << volt::util::Time::Now());
  LOG_DEBUG(RES_LOGGER, "current-age: " << current_age);
  LOG_DEBUG(RES_LOGGER, "max-age: " << max_age_);
  LOG_DEBUG(RES_LOGGER, "expires: " << expires_);

  if (max_age_.IsValid())
  {
    freshness_lifetime = max_age_;
    LOG_DEBUG(RES_LOGGER, "Using max-age: " << freshness_lifetime);
  }
  else if (expires_.IsValid())
  {
    freshness_lifetime = expires_ - date_;
    LOG_DEBUG(RES_LOGGER, "Using Expires: " << freshness_lifetime);
  }
  else
  {
    /* In minutes */
    unsigned int freshness_lifetime_min =
      AppConfig::Instance().GetValue<unsigned int>("default-cache-lifetime");

    /* In seconds */
    freshness_lifetime = volt::util::Time(freshness_lifetime_min * 60);
    LOG_DEBUG(RES_LOGGER, "Using default: " << freshness_lifetime);
  }

  bool expired = (freshness_lifetime <= current_age);
  LOG_DEBUG(RES_LOGGER,
            "Response is " << (expired ? "EXPIRED" : "FRESH") <<" (" <<
            freshness_lifetime << ", " << current_age << "): " << uri());
  return expired;
}


/******************************************************************************
 * NetworkIORequest
 *****************************************************************************/

static Logger REQ_LOGGER("volt.network.request");

NetworkIORequest::NetworkIORequest(const std::string &aUrl):
  IORequest(aUrl), curl_handle_(curl_easy_init()),
  headers_(NULL), file_(NULL)
{
  LOG_DEBUG(REQ_LOGGER, "Born: " << uri());
}

NetworkIORequest::~NetworkIORequest()
{
  LOG_DEBUG(REQ_LOGGER, "Dead(" << id() << "): " << uri());

  if (async() == false)
  {
    /* Handle is cleaned up by the ResourceManager for async request. */
    curl_easy_cleanup(curl_handle_);
  }

  if (headers_)
  {
    curl_slist_free_all(headers_);
    headers_ = NULL;
  }

  if (file_)
  {
    fclose(file_);
    file_ = NULL;
  }
}

CURL* NetworkIORequest::curl_handle() const
{
  return curl_handle_;
}

bool NetworkIORequest::Execute()
{
  CURLcode result = curl_easy_perform(curl_handle_);

  if (result != 0)
  {
    LOG_WARN(REQ_LOGGER, "Failed to perform IO request: " << error_buf_);
    response()->set_reason_string(error_buf_);
    return false;
  }

  return true;
}

size_t NetworkIORequest::HeaderCallback(void *aBuffer,
                                        size_t aSize, size_t aNumMemb,
                                        void *aSelf)
{
  if (aSelf)
  {
    NetworkIORequest *self = reinterpret_cast<NetworkIORequest *>(aSelf);
    NetworkIOResponse::SharedPtr response =
      boost::static_pointer_cast<NetworkIOResponse>(self->response());

    return response->ParseHeader(reinterpret_cast<const char *>(aBuffer),
                                 aSize * aNumMemb, response);
  }

  return 0;
}

size_t NetworkIORequest::DataCallback(void *aBuffer,
                                      size_t aSize, size_t aNumMemb,
                                      void *aSelf)
{
  if (aSelf)
  {
    NetworkIORequest *self = reinterpret_cast<NetworkIORequest *>(aSelf);
    NetworkIOResponse::SharedPtr response =
      boost::static_pointer_cast<NetworkIOResponse>(self->response());

    size_t size = aSize * aNumMemb;
    response->AppendData(reinterpret_cast<const char *>(aBuffer), size);

    return size;
  }

  return 0;
}

/**
 * Utility function to print request stats.
 * @param[in] aHandle CURL handle of a completed transfer.
 */
void NetworkIORequest::PrintStats() const
{
  char *url = NULL;
  curl_easy_getinfo(curl_handle_, CURLINFO_EFFECTIVE_URL, &url);

  double total_time = 0, dns_time = 0, conn_time = 0, ssl_time = 0,
         pre_time = 0, first_time = 0, redirect_time = 0;
  curl_easy_getinfo(curl_handle_, CURLINFO_TOTAL_TIME, &total_time);
  curl_easy_getinfo(curl_handle_, CURLINFO_NAMELOOKUP_TIME, &dns_time);
  curl_easy_getinfo(curl_handle_, CURLINFO_CONNECT_TIME, &conn_time);
  curl_easy_getinfo(curl_handle_, CURLINFO_APPCONNECT_TIME, &ssl_time);
  curl_easy_getinfo(curl_handle_, CURLINFO_PRETRANSFER_TIME, &pre_time);
  curl_easy_getinfo(curl_handle_, CURLINFO_STARTTRANSFER_TIME, &first_time);
  curl_easy_getinfo(curl_handle_, CURLINFO_REDIRECT_TIME, &redirect_time);

  LOG_DEBUG(REQ_LOGGER,
            "url:" << url <<
            " total:" << std::setiosflags(std::ios::fixed) << std::setprecision(2) << total_time <<
            " dns:" << std::setiosflags(std::ios::fixed) << std::setprecision(2) << dns_time <<
            " connect:" << std::setiosflags(std::ios::fixed) << std::setprecision(2) << conn_time <<
            " ssl:" << std::setiosflags(std::ios::fixed) << std::setprecision(2) << ssl_time <<
            " pretransf:" << std::setiosflags(std::ios::fixed) << std::setprecision(2) << pre_time <<
            " 1st-byte:" << std::setiosflags(std::ios::fixed) << std::setprecision(2) << first_time <<
            " redirect:" << std::setiosflags(std::ios::fixed) << std::setprecision(2) << redirect_time);
}

void NetworkIORequest::InitResponse()
{
  IOResponse::SharedPtr response(new NetworkIOResponse(*this));
  set_response(response);

  if (cached_response())
  {
    std::string header;

    NetworkIOResponse::SharedPtr cached_nw_response =
      boost::static_pointer_cast<NetworkIOResponse>(cached_response());

    if (cached_nw_response->last_modified().IsValid())
    {
      LOG_DEBUG(REQ_LOGGER, "Add If-Modified-Since header");
      header = std::string("If-Modified-Since: ") +
               cached_nw_response->last_modified().HttpTimeString();
      headers_ = curl_slist_append(headers_, header.c_str());
    }

    if (cached_nw_response->etag().empty() == false)
    {
      LOG_DEBUG(REQ_LOGGER, "Add If-None-Match header");
      header = std::string("If-None-Match: ") + cached_nw_response->etag();
      headers_ = curl_slist_append(headers_, header.c_str());
    }

    if (headers_)
    {
      curl_easy_setopt(curl_handle_, CURLOPT_HTTPHEADER, headers_);
    }
  }
}

bool NetworkIORequest::ValidateCachedResponseBeforeRequest()
{
  /* Can't validate response without sending another request...
   * Let's save the cached response. */
  set_cached_response(response());

  return false;
}

void NetworkIORequest::SetHeaders(const ResourceRequest::HeaderList &aHeaders)
{
  if (headers_)
  {
    curl_slist_free_all(headers_);
  }
  /* Send the Accept-Encoding header with what CURL can handle. */
  curl_easy_setopt(curl_handle_, CURLOPT_ACCEPT_ENCODING, "");

  headers_ = NULL;

#ifdef BOOST_NO_CXX11_RANGE_BASED_FOR

  for (auto iter = aHeaders.begin(); iter != aHeaders.end(); ++iter)
  {
    SetHeader(iter->name, iter->value);
  }

#else

  for (const ResourceRequest::HeaderInfo &header_info: aHeaders)
  {
    SetHeader(header_info.name, header_info.value);
  }

#endif
}

void NetworkIORequest::Finalize()
{
  /* Initialize handle */
  curl_easy_setopt(curl_handle_, CURLOPT_VERBOSE,
                   AppConfig::Instance().IsSet("nw.verbose") ? 1 : 0);
  curl_easy_setopt(curl_handle_, CURLOPT_URL, uri().c_str());
  curl_easy_setopt(curl_handle_, CURLOPT_HEADERFUNCTION,
                   NetworkIORequest::HeaderCallback);
  curl_easy_setopt(curl_handle_, CURLOPT_HEADERDATA, this);
  curl_easy_setopt(curl_handle_, CURLOPT_WRITEFUNCTION,
                   NetworkIORequest::DataCallback);
  curl_easy_setopt(curl_handle_, CURLOPT_WRITEDATA, this);

  /* Follow redirects. */
  curl_easy_setopt(curl_handle_, CURLOPT_FOLLOWLOCATION, 1);

  /* To share session info. */
  curl_easy_setopt(curl_handle_, CURLOPT_SHARE, s_curl_share);
  curl_easy_setopt(curl_handle_, CURLOPT_COOKIEFILE, s_cookiejar_path.c_str());
  curl_easy_setopt(curl_handle_, CURLOPT_COOKIEJAR, s_cookiejar_path.c_str());

  /* FIXME: Better have verifications enabled... */
  /* Disabling for now as setting CURLOPT_CAPATH/INFO didn't work well... */
  curl_easy_setopt(curl_handle_, CURLOPT_SSL_VERIFYHOST, 0);
  curl_easy_setopt(curl_handle_, CURLOPT_SSL_VERIFYPEER, 0);

  curl_easy_setopt(curl_handle_, CURLOPT_ERRORBUFFER, error_buf_);

  if (method() == METHOD_POST or method() == METHOD_PUT or method() == METHOD_DELETE)
  {
    LOG_DEBUG(REQ_LOGGER, "Setting POSTFIELDS, length " << data()->length());

    if (src().length())
    {
      std::string file_path;

      if (FileIORequest::NormalizePath(src(), file_path) & PERM_R)
      {
        LOG_DEBUG(REQ_LOGGER, "Opening file: " << file_path);
        file_ = fopen(file_path.c_str(), "r");

        curl_easy_setopt(curl_handle_, CURLOPT_UPLOAD, 1L);
        curl_easy_setopt(curl_handle_, CURLOPT_READDATA, file_);
      }
      else
      {
        LOG_ERROR(REQ_LOGGER, "no permission to open file at path " << src());
      }
    }
    else
    {
      // if there is data to send..
      if(not data()->length())
      {
        LOG_ERROR(REQ_LOGGER, "warning, empty put/post/delete body");
      }

      curl_easy_setopt(curl_handle_, CURLOPT_POSTFIELDSIZE, data()->length());

      // this does NOT copy the original data, saves us some speed..
      curl_easy_setopt(curl_handle_, CURLOPT_POSTFIELDS, data()->c_str());
      //    curl_easy_setopt(curl_handle_, CURLOPT_COPYPOSTFIELDS, data_->.c_str());
    }

    // override method field
    if (method() == METHOD_PUT)
    {
      curl_easy_setopt(curl_handle_, CURLOPT_CUSTOMREQUEST, "PUT");
    }
    else if (method() == METHOD_POST)
    {
      curl_easy_setopt(curl_handle_, CURLOPT_CUSTOMREQUEST, "POST");
    }
    else if (method() == METHOD_DELETE)
    {
      curl_easy_setopt(curl_handle_, CURLOPT_CUSTOMREQUEST, "DELETE");
    }
  }

  if (headers_)
  {
    curl_easy_setopt(curl_handle_, CURLOPT_HTTPHEADER, headers_);
  }
}

void NetworkIORequest::FinalizeResponse()
{
  long int code = 0;
  curl_easy_getinfo(curl_handle_, CURLINFO_RESPONSE_CODE, &code);
  response()->set_status(code);

  char *ctype = NULL;
  curl_easy_getinfo(curl_handle_, CURLINFO_CONTENT_TYPE, &ctype);

  if (ctype)
  {
    response()->set_type(ctype);
  }

  PrintStats();
}

bool NetworkIORequest::IsValid() const
{
  return true;
}

bool NetworkIORequest::ShouldCacheResponse() const
{
  return true;
}

bool NetworkIORequest::ValidateCachedResponseAfterRequest()
{
  NetworkIOResponse::SharedPtr nw_response =
    boost::static_pointer_cast<NetworkIOResponse>(response());

  bool retval = false;

  if (cached_response() &&
      response()->status() == 304) /* Not Modified */
  {
    /* Cache is still valid, use it. */
    LOG_DEBUG(REQ_LOGGER, "Cache is still valid: " << uri());

    NetworkIOResponse::SharedPtr cached_nw_response =
      boost::static_pointer_cast<NetworkIOResponse>(cached_response());

    if (nw_response->date().IsValid())
    {
      cached_nw_response->set_date(nw_response->date());
    }

    if (nw_response->max_age().IsValid())
    {
      cached_nw_response->set_max_age(nw_response->max_age());
    }

    if (nw_response->expires().IsValid())
    {
      cached_nw_response->set_expires(nw_response->expires());
    }

    if (nw_response->last_modified().IsValid())
    {
      cached_nw_response->set_last_modified(nw_response->last_modified());
    }

    if (nw_response->etag().empty() == false)
    {
      cached_nw_response->set_etag(nw_response->etag());
    }

    set_response(cached_nw_response);

    retval = true;
  }

  /* Cache only 2XX response */
  nw_response->set_is_cacheable((nw_response->status() / 100) == 2);

  return retval;
}

/**
 * This is a helper function to lock when CURL is accessing shared data.
 */
static void CurlLock(CURL *aHandle, curl_lock_data aData,
                     curl_lock_access aAccess, void *aUserPtr)
{
  switch (aData)
  {
  case CURL_LOCK_DATA_COOKIE:
    LOG_DEBUG(REQ_LOGGER, "Should lock for cookie");
    break;
  case CURL_LOCK_DATA_SHARE:
    LOG_DEBUG(REQ_LOGGER, "Should lock for share");
    break;
  case CURL_LOCK_DATA_DNS:
    LOG_DEBUG(REQ_LOGGER, "Should lock for dns");
    break;
  default:
    LOG_DEBUG(REQ_LOGGER, "Unknown lock data");
    break;
  }

  LOG_DEBUG(REQ_LOGGER, "Before lock");
  /* Is locking for CURL_LOCK_DATA_COOKIE enough? */
  pthread_mutex_lock(&s_curl_mutex);
  LOG_DEBUG(REQ_LOGGER, "After lock");
}

/**
 * This is a helper function to unlock when CURL is accessing shared data.
 */
static void CurlUnlock(CURL *aHandle, curl_lock_data aData,
                       void *aUserPtr)
{
  switch (aData)
  {
  case CURL_LOCK_DATA_COOKIE:
    LOG_DEBUG(REQ_LOGGER, "Should unlock for cookie");
    break;
  case CURL_LOCK_DATA_SHARE:
    LOG_DEBUG(REQ_LOGGER, "Should unlock for share");
    break;
  case CURL_LOCK_DATA_DNS:
    LOG_DEBUG(REQ_LOGGER, "Should unlock for dns");
    break;
  default:
    LOG_DEBUG(REQ_LOGGER, "Unknown unlock data");
    break;
  }

  LOG_DEBUG(REQ_LOGGER, "Before unlock");
  /* Is locking for CURL_LOCK_DATA_COOKIE enough? */
  pthread_mutex_unlock(&s_curl_mutex);
  LOG_DEBUG(REQ_LOGGER, "After unlock");
}

void NetworkIORequest::InitSharedState()
{
  s_cookiejar_path = AppConfig::Instance().GetVoltDataPath() + "/cookie.jar";

  s_curl_share = curl_share_init();

  if (s_curl_share == NULL)
  {
    LOG_WARN(REQ_LOGGER, "Failed to create CURL share");
    return;
  }

  /* Register lock callback. */
  if (curl_share_setopt(s_curl_share,
                        CURLSHOPT_LOCKFUNC, CurlLock) != CURLSHE_OK)
  {
    LOG_WARN(REQ_LOGGER, "Failed to set CURL lock function");
    return;
  }

  /* Register unlock callback. */
  if (curl_share_setopt(s_curl_share,
                        CURLSHOPT_UNLOCKFUNC, CurlUnlock) != CURLSHE_OK)
  {
    LOG_WARN(REQ_LOGGER, "Failed to set CURL unlock function");
    return;
  }

  /* Share cookie info among different CURL handles. */
  if (curl_share_setopt(s_curl_share,
                        CURLSHOPT_SHARE, CURL_LOCK_DATA_COOKIE) != CURLSHE_OK)
  {
    LOG_WARN(REQ_LOGGER, "Failed to configure to share cookie");
    return;
  }
}

void NetworkIORequest::CleanSharedState()
{
  if (s_curl_share)
  {
    curl_share_cleanup(s_curl_share);
    s_curl_share = NULL;
  }
}

void NetworkIORequest::SetHeader(const std::string &aKey, const std::string &aVal)
{
  if (volt::util::CompareIC(aKey, "Accept-Encoding"))
  {
    LOG_DEBUG(REQ_LOGGER,
              "Special handling for Accept-Encoding: " << aVal);

    /* Note: Curl only supports deflate and gzip! */
    curl_easy_setopt(curl_handle_,
                     CURLOPT_ACCEPT_ENCODING, aVal.c_str());
  }
  else
  {
    std::string header = aKey + ": " + aVal;
    LOG_DEBUG(REQ_LOGGER, "Adding header: " << header);
    headers_ = curl_slist_append(headers_, header.c_str());
  }
}

} /* namespace Resource */
