#include "VoltMessageCenter.h"

#include <clutter/clutter.h>

#include "VoltProcessManager.h"

#include <iostream>
#include <iomanip>

#include "AppConfig.h"
#include "time_util.h"

using namespace volt::util;
using namespace volt::util::ipc;

Logger VoltMessageCenter::LOGGER("volt.ipc");

const std::string VoltMessageCenter::MCQ_GFX = "VoltGfx";
const std::string VoltMessageCenter::MCQ_APP = "VoltApp";

#ifdef DEBUG
static void printSerializedData(const unsigned char* data, size_t aSize)
{
  std::cout << "size of data = " << std::dec << aSize << std::endl;
  std::cout << "data = { ";
  size_t i;

  for (i = 0; i < aSize; ++i)
  {
    std::cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(data[i]);

    if ((i+1)%4 == 0)
    {
      std::cout << ' ';
    }
  }

  std::cout << "}" << std::endl;

  // print it in ascii

  std::cout << "data = { ";

  for (i = 0; i < aSize; ++i)
  {
    if (data[i] > 31)
    {
      std::cout << std::setw(2) << std::setfill(' ') << (data[i]);
    }
    else
    {
      std::cout << "  ";
    }

    if ((i+1)%4 == 0)
    {
      std::cout << ' ';
    }
  }

  std::cout << "}" << std::endl;
}
#else
#define printSerializedData(a,b)
#endif

void VoltMessageCenter::PrepareInstance()
{
  if (singleton_)
  {
    delete singleton_;
  }

  singleton_ = new VoltMessageCenter();
}

VoltMessageCenter& VoltMessageCenter::Instance()
{
  return *static_cast<VoltMessageCenter *>(singleton_);
}

VoltMessageCenter::VoltMessageCenter():
  MessageCenter(), mc_name_(), queue_name_(), parent_id_()
#ifdef SAMPLE_IPC
  , num_msg_(0), num_cmd_(0), num_sched_(0), num_dispatch_(0),
  idle_sample_timer_(), idle_msg_handler_timer_(),
  idle_cmd_handler_timer_(), idle_lag_timer_()
#endif
{
#ifdef SAMPLE_IPC
  idle_sample_timer_.Start();
#endif
}

void VoltMessageCenter::Initialize()
{
  std::ostringstream buf;
  buf << "VoltMC-" << getpid();
  mc_name_ = buf.str();
  LOG_DEBUG(LOGGER, "MessageCenter: " << mc_name_);

  shm_queue_size_ =
    AppConfig::Instance().GetValue<unsigned int>("shm-queue-size");
}

bool VoltMessageCenter::InitializeOnApp()
{
  MessageCenter::Initialize(mc_name_,
                            AppConfig::Instance().GetValue<unsigned int>("shm-size"));

  if (CreateNamedQueue(MCQ_APP, shm_queue_size_) == false)
  {
    return false;
  }

  queue_name_ = MCQ_APP;

  return true;
}

bool VoltMessageCenter::InitializeOnWorker()
{
  std::string name = AppConfig::Instance().GetValue<std::string>("worker");
  std::string id = AppConfig::Instance().GetValue<std::string>("worker-id");
  std::string parent_id = AppConfig::Instance().GetValue<std::string>("parent-id");

  if (name.empty() || id.empty() || parent_id.empty())
  {
    LOG_FATAL(LOGGER, "Failed to initialize worker");
    return false;
  }

  while (Attach(name) == false)
  {
    LOG_WARN(LOGGER, "Failed to attach; retry in a sec");
    usleep(1000000);
  }

  mc_name_ = name;
  queue_name_ = id;
  parent_id_ = parent_id;

  if (CreateNamedQueue(parent_id, shm_queue_size_) == false ||
      CreateNamedQueue(queue_name_, shm_queue_size_) == false)
  {
    return false;
  }

  return true;
}

bool VoltMessageCenter::PrepareWorker(const std::string &aWorkerID)
{
  return CreateNamedQueue(aWorkerID, shm_queue_size_);
}

bool VoltMessageCenter::InitializeOnGfx()
{
  return false;
}

const std::string& VoltMessageCenter::ID() const
{
  return mc_name_;
}

const std::string& VoltMessageCenter::ProcessID() const
{
  return queue_name_;
}

const std::string& VoltMessageCenter::AppProcessID() const
{
  return MCQ_APP;
}

const std::string& VoltMessageCenter::GfxProcessID() const
{
  return MCQ_GFX;
}

const std::string& VoltMessageCenter::ParentProcessID() const
{
  return parent_id_;
}

void VoltMessageCenter::WaitForGfxReady()
{
}

void VoltMessageCenter::RegisterHandlerOnProc(const std::string &aID,
    MessageHandler aHandler)
{
  MessageCenter::RegisterHandler(aID, aHandler);
}

void VoltMessageCenter::RegisterHandlerOnProc(const std::string &aID,
    const MessageGroup aGroup,
    MessageHandler aHandler)
{
  MessageCenter::RegisterHandler(aID, aGroup, aHandler);
}

void VoltMessageCenter::RegisterHandlerOnProc(const std::string &aID,
    const MessageType aType,
    MessageHandler aHandler)
{
  MessageCenter::RegisterHandler(aID, aType, aHandler);
}

bool VoltMessageCenter::PostMsgToProc(const std::string &aID,
                                      MessageType aType,
                                      void *aData, const size_t aSize)
{
  printSerializedData(reinterpret_cast<const unsigned char*>(aData), aSize);
  return PostMessage(aID, -1, queue_name_, aType, aData, aSize);
}

bool VoltMessageCenter::ExecuteOnProc(const std::string &aID,
                                      MessageType aType,
                                      ResultHandler aHandler, void *aData,
                                      const size_t aSize)
{
  printSerializedData(reinterpret_cast<const unsigned char*>(aData), aSize);
  return ExecuteCommand(aID, -1, queue_name_, aType, aHandler, aData, aSize);
}

void VoltMessageCenter::StartMainLoop()
{
  LOG_DEBUG(LOGGER, "Starting main loop: " << ProcessID());
  MessageCenter::StartMainLoop(ProcessID());
}

void VoltMessageCenter::StartMainLoopThread()
{
  LOG_DEBUG(LOGGER, "Starting main loop thread: " << ProcessID());
  MessageCenter::StartMainLoopThread(ProcessID());
}

void VoltMessageCenter::StopMainLoop()
{
  /* Stop the event checking thread. */
  LOG_DEBUG(LOGGER, "Stopping main loop: " << ProcessID());
  MessageCenter::StopMainLoop(ProcessID());
}

void VoltMessageCenter::JoinMainLoopThread()
{
  /* Stop the event checking thread. */
  LOG_DEBUG(LOGGER, "Joining main loop: " << ProcessID());
  MessageCenter::JoinMainLoopThread(ProcessID());
}

void VoltMessageCenter::StartGfxMainLoop()
{
  VoltMessageCenter::StartMainLoopThread();
}

gboolean VoltMessageCenter::FireUIMessageHandler(gpointer aData)
{
  GfxMsgData *data = static_cast<GfxMsgData *>(aData);

#ifdef SAMPLE_IPC
  data->self->idle_lag_timer_.Stop();
  ++data->self->num_dispatch_;
#endif

  /* Gotta check the flag before calling the handler to avoid potential race
   * condition where the handler destroys the msg object and leads to an
   * unpredictable return value of msg->IsCommand. */
  bool is_command = data->msg->IsCommand();


  if (data->handler)
  {
    data->handler(data->msg);
  }

  if (is_command == false)
  {
    VoltMessageCenter::Instance().DestroyMessage(data->msg);
  }

  delete data;

  return 0;
}

void VoltMessageCenter::CallMessageHandler(MessageHandler aHandler, Message *aMsg)
{
  /* Need to run the handler in Clutter thread. */
  GfxMsgData *data = new GfxMsgData(aHandler, aMsg, this);

#ifdef SAMPLE_IPC
  idle_lag_timer_.Start();
  ++num_sched_;
#endif

  clutter_threads_add_idle_full(G_PRIORITY_HIGH_IDLE,
                                FireUIMessageHandler, data, NULL);
}
