#include <math.h>
#include <map>
#include <string>
#include "FirstScreenListWidget.h"
#include "VoltActor.h"
#include "event_manager.h"
#include "clutter_helper.h"

#if defined(BUILD_FOR_TV) && defined(TIZEN) // It's better to separate .h file [shuhao.yan]
#include "system_info.h"
#endif

#include <time.h>
#include <thread>
#include <gdk-pixbuf/gdk-pixbuf.h>

using namespace std;
using namespace volt::util;
using namespace volt::graphics;

static volt::util::Logger logger;
static volt::util::Logger objectDumpLogger("FS_OBJECTDUMP");

//#define _OBJECTDUMP_

//#define TIME_TYPE_TEST
#ifdef TIME_TYPE_TEST
#include <sys/timeb.h>

typedef enum
{
	time_type_none = 0,
	time_type_reduce_effect,
	time_type_recover_effect,
	time_type_exchange_effect,
	time_type_extend_effect,
	time_type_scroll_area,
	time_type_scale_area,
	time_type_move_to,
	time_type_key_move,
	time_type_move_rect,
	time_type_move_rect_IN_Contents,
	time_type_move_rect_FIRST_GAP,
	time_type_move_rect_LEFT_END,
	time_type_move_rect_Featured_Open,
	time_type_move_rect_EMPTY
}TIME_TYPE_E;

time_t timelineSecond = 0;
unsigned short timelineMsecond = 0;

time_t startSecond = 0;
unsigned short startMsecond = 0;
TIME_TYPE_E startType = time_type_none;

static void beginTimelineCB()
{
	struct timeb tp;
	ftime(&tp);

	LOG_DEBUG(logger, "Timeline CB begin ... last gap time is "
						<< (tp.time - timelineSecond)*1000 + (tp.millitm - timelineMsecond)
						<< " ms");
	
	timelineSecond = tp.time;
	timelineMsecond = tp.millitm;
}

static void endTimelineCB()
{
	struct timeb tp;
	ftime(&tp);

	LOG_DEBUG(logger, "Timeline CB end ... current execute time is "
						<< (tp.time - timelineSecond)*1000 + (tp.millitm - timelineMsecond)
						<< " ms");
	
	timelineSecond = tp.time;
	timelineMsecond = tp.millitm;
}

static void startTime(TIME_TYPE_E type)
{
	struct timeb tp;
	ftime(&tp);
	startType = type;
	startSecond = tp.time;
	startMsecond = tp.millitm;
}

static void recordTime(TIME_TYPE_E type)
{
	if(type != startType || type == time_type_none)
	{
		return;
	}

	struct timeb tp;
	ftime(&tp);
	
	std::string typeName;
	switch(type)
	{
/*
		case time_type_reduce_effect:
			typeName = "time_type_reduce_effect";
			break;
		case time_type_recover_effect:
			typeName = "time_type_recover_effect";
			break;
		case time_type_exchange_effect:
			typeName = "time_type_exchange_effect";
			break;
		case time_type_extend_effect:
			typeName = "time_type_extend_effect";
			break;
		case time_type_scroll_area:
			typeName = "time_type_scroll_area";
			break;
		case time_type_scale_area:
			typeName = "time_type_scale_area";
			break;
		case time_type_move_to:
			typeName = "time_type_move_to";
			break;
		case time_type_key_move:
			typeName = "time_type_key_move";
			break;
		case time_type_move_rect:
			typeName = "time_type_move_rect";
			break;
*/
		case time_type_move_rect_IN_Contents:
			typeName = "time_type_move_rect_IN_Contents";
			break;
		case time_type_move_rect_FIRST_GAP:
			typeName = "time_type_move_rect_FIRST_GAP";
			break;
		case time_type_move_rect_LEFT_END:
			typeName = "time_type_move_rect_LEFT_END";
			break;
		case time_type_move_rect_Featured_Open:
			typeName = "time_type_move_rect_Featured_Open";
			break;
		case time_type_move_rect_EMPTY:
			typeName = "time_type_move_rect_EMPTY";
			break;
		default:
			break;
	}

	if(!typeName.empty())
	{
		LOG_DEBUG(logger, "[liang.wu] Time " 
							<< typeName.c_str() 
							<< " cost is : "
							<< (tp.time - startSecond)*1000 + (tp.millitm - startMsecond)
							<< " ms");
	}
}
#endif

ClutterActor *contentsList = NULL;
std::map<ClutterActor*, FirstScreenContents*> itemMap;
std::map<std::string, FirstScreenContents*> contentsTagMap;
std::map<ClutterActor*, FirstScreenCategory*> categoryActorMap;
std::map<std::string, FirstScreenCategory*> categoryTagMap;

// begin shuhao.yan
typedef std::map<ClutterActor*, TextScroll*> TITLELMAP;
static TITLELMAP normalTitleScrollMap;
static TITLELMAP focusTitleScrollMap;

typedef std::map<ClutterActor*, ProgressController*> PROGRESS_MAP;
static PROGRESS_MAP progressMap;

guint timeID = 0;
int scrollCheckTick = 0;

int preContents = -1;
TextScroll* preTextInc = NULL;
static void startNormalTitleScroll(int index);
static void startFocusTitleScroll(int index);
static void checkTitleScroll();

bool FOCUS_CONTEXTMENU = false;

bool CONTEXTMENU_ENABLE = false;
// end shuhao.yan


ClutterTimeline *timeline = NULL;

#define EMPTY -10
#define FEATURED_OPEN -11
#define HISTORY_OPEN -12
#define IN_CONTENTS -13
#define FIRST_GAP -14
#define SECOND_GAP -15
#define LEFT_END -16

static FirstScreenListWidget* instance;
//define the static function
static void reduceCategory(int index);
static void reduceEffect();
static void recoverCategory();
static void recoverEffect();
static void exchangeCategory();
static void exchangeEffect();
static void extendCategory(int index);
static void extendEffect();

static ClutterActor* getListWrapper(int categoryIndex);
static int get_extend_itemCount();
static void loadImageToContentAndGetSize(ClutterContent *&content, 
                                         const std::string &url, 
                                         gfloat *retWidth = NULL,
                                         gfloat *retHeight = NULL);
static void contentLiveImage();
static void reverseChildIndex(ClutterActor* parent);



//end define

gfloat Rounding( gfloat x, int digit ) 
{
    return (floor((x) * pow(float(10), digit) + 0.5f ) / pow(float(10), digit) );
}

static bool floatClose(gfloat f1, gfloat f2, gfloat deviation)
{
    return abs(f1-f2) < deviation ? true : false;
}

ClutterActor *mouseArea = NULL;
ClutterActor *bar = NULL;
ClutterActor *check = NULL;
ClutterActor *extend = NULL;

ClutterActor *appLive[3] = {NULL, NULL, NULL};
ClutterActor *gameLive[3] = {NULL, NULL, NULL};

//ClutterTimeline *timeline = clutter_timeline_new(16);

gfloat SCENE_WIDTH = 1920;
gfloat SCENE_HEIGHT = 1080;

//gfloat ROOT_WIDTH = 1920;
//gfloat ROOT_HEIGHT = 1080;


gfloat   HD_PROPORTION = SCENE_HEIGHT / 1080;
gboolean   REVERSE_OSD = false;
gboolean   HIGH_CONTRAST_FLAG = false;
gboolean   KEY_PREVENT_FLAG = false;

//gfloat WIDGET_HEIGHT = 251;
gfloat WIDGET_HEIGHT = SCENE_WIDTH * 0.130729;
gfloat BOTTOM_HEIGHT = Rounding(SCENE_HEIGHT * 0.064814, 1);
gfloat CONTENTS_IMAGE_HEIGHT = Rounding(SCENE_HEIGHT * 0.160185, 1);

gfloat SIDECATEGORY_GAP = Rounding(SCENE_WIDTH * 0.015625, 1);
gfloat CATEGORY_GAP =  SIDECATEGORY_GAP; //SIDECATEGORY_GAP * 2 + Rounding(SCENE_WIDTH * 0.090104, 1);
gfloat OVERLAP_SHADOW_WIDTH = Rounding(SCENE_WIDTH * 0.0489583, 1); // add by lin89.zhang for setting the width of shadow
gfloat SCROLL_AREA = 30;//liang.wu

/*add by lin89.zhang for adding option indicator icon begin*/
std::string IMAGE_URL_PREFIX = "/usr/apps/org.volt.firstscreen/bin/first_screen/resource/";
ClutterContent *optionUpNormalIco = NULL;
ClutterContent *optionDownNormalIco = NULL;
ClutterContent *optionUpFocusIco = NULL;
ClutterContent *optionDownFocusIco = NULL;
gfloat optionIcoHeight = 0.0;
gfloat optionIcoWidth = 0.0;
gfloat OPTION_GAP = Rounding(SCENE_HEIGHT * 0.016667, 1); 
const std::string OPTION_UP_NORMAL_ICO_URL = "icon/fs_contextual_btn_up_normal.PNG";
const std::string OPTION_DOWN_NORMAL_ICO_URL = "icon/fs_contextual_btn_down_normal.PNG";
const std::string OPTION_UP_FOCUS_ICO_URL = "icon/fs_contextual_btn_up_focus.PNG";
const std::string OPTION_DOWN_FOCUS_ICO_URL = "icon/fs_contextual_btn_down_focus.png";
const std::string GLOBAL_CURSOR_ICO_URL = "icon/ksc_focus_252x252.png"; //"icon/fs_thumb_high.PNG"; 
enum OPTION_STATUS
{
    FOCUS,
    UNFOCUS,
    ENTER,
};
OPTION_STATUS optionStaus = UNFOCUS;
/*add by lin89.zhang for adding option indicator icon end*/

/*add by lin89.zhang for SCALE while mouse reach the edge of the screen begin */
gfloat SCALE_AREA = 30;
bool SCALE_LEFT = false;
bool SCALE_RIGHT = false;
bool IsOutScaleArea = true;
int ScaleTicker = 0;
int SCALE_MAX_FRAME = 120;
const int SCALE_KEY_EVENT_FRAME = 20;
const int SCALE_MOUSE_EVENT_FRAME = 120;
int RECOVER_JUMP_FRAME = 1;
const int RECOVER_JUMP_KEY_EVENT_FRAME = 1;
const int RECOVER_JUMP_MOUSE_EVENT_FRAME = 20;
gfloat prePivotX = 0, prePivotY = 0;
gfloat firstPrePivotX = 0, firstPrePivotY = 0;
gfloat secondPrePivotX = 0, secondPrePivotY = 0;
gfloat pre_cur_x = 0.0;
bool preIsKeyControl = false;
static void scaleRight();
static void scaleLeft();
static void recoverRight();
static void recoverLeft();
const int MOVE_TO_BEGIN_END_FRAME = 35;
int MovingTicker = 0;
bool MOVE_TO_BEGIN = false;
bool MOVE_TO_END = false;
gfloat MoveOriginPosition = 0.0;
gfloat vMoveing[4] = {0.134, 0.746, 0.44, 1.0};
int MoveCursorTicker = 0;
int MOVE_CURSOR_FRAME = 15;
gfloat CursorOriginPosition = 0.0;
gfloat CursorDestPosition = 0.0;
gfloat CursorOriginWidth = 0.0;
gfloat CursorDestWidth = 0.0;
bool MOVE_CURSOR = false;
bool CURSOR_SHOW_FLAG  = false;

bool AD_CURSOR_FLAG = false; 
//gfloat vBounce[4] = {0.694, -1.291, 0.0635, 1.0};
/*add by lin89.zhang for SCALE while mouse reach the edge of the screen end */

gfloat NORMAL_CATEGORY_WIDTH = Rounding(SCENE_WIDTH * 0.139583, 1);
//gfloat FOCUS_CATEGORY_WIDTH = NORMAL_CATEGORY_WIDTH * 1.5;
//liang.wu
gfloat FOCUS_CATEGORY_WIDTH = NORMAL_CATEGORY_WIDTH * 1.0;
gfloat OVER_CATEGORY_WIDTH = 0;//NORMAL_CATEGORY_WIDTH * 0.3;

gfloat NORMAL_CATEGORY_TITLE_WIDTH = NORMAL_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;
gfloat FOCUS_CATEGORY_TITLE_WIDTH = FOCUS_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;

gfloat CATEGORY_TITLE_X = SCENE_WIDTH * 0.006250;
gfloat CATEGORY_TITLE_Y = SCENE_HEIGHT * 0.004630;
gfloat EXTEND_CATEGORY_TITLE_X = 30;
gfloat EXTEND_CATEGORY_TITLE_Y = -50;

//gfloat CATEGORY_COLOR_HEIGHT = SCENE_HEIGHT * 0.130556;
gfloat CATEGORY_COLOR_HEIGHT = WIDGET_HEIGHT * 0.500000;//liang.wu
gfloat CATEGORY_LIVE_HEIGHT = WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT;

gfloat NORMAL_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.090104, 1);
gfloat FOCUS_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.131250, 1);

gfloat NORMAL_CONTENTS_TITLE_WIDTH = NORMAL_CONTENTS_WIDTH - 2 * SCENE_WIDTH * 0.003535;
gfloat FOCUS_CONTENTS_TITLE_WIDTH = FOCUS_CONTENTS_WIDTH;

gfloat CONTENTS_TITLE_X = SCENE_WIDTH * 0.003535;
gfloat CONTENTS_TITLE_Y = SCENE_HEIGHT * 0.016667;
//add by junhui.wang [add the vertical gap of focus tile of content item]
gfloat FOCUS_CONTENTS_TITLE_Y = SCENE_HEIGHT * 0.014814;

gfloat PROGRESS_HEIGHT = 2;

gfloat ICON_GAP = SCENE_WIDTH * 0.003125;
gfloat ICON_BOTTOM_GAP = SCENE_HEIGHT * 0.007407;
gfloat ICON_RIGHT_GAP = SCENE_HEIGHT * 0.006250;
gfloat OPACITY_100 = 255;
gfloat OPACITY_90 = 230;
gfloat OPACITY_80 = 204;
gfloat OPACITY_70 = 179;
gfloat OPACITY_60 = 153;
gfloat OPACITY_40 = 102;
gfloat OPACITY_20 = 51;
gfloat OPACITY_15 = 38;
gfloat OPACITY_10 = 25;
gfloat OPACITY_8 = 20;

//ClutterColor CATEGOTY_COLOR = {0xC2, 0xC4, 0xC5, 0xFF};
ClutterColor CATEGOTY_COLOR = {255, 255, 255, 51};
ClutterColor whiteColor = {255, 255, 255, 255};
ClutterColor blackColor = {0, 0, 0, 255};

// 1211
gfloat cur_x = SIDECATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2, 
	   cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;
gfloat cur_x_pre = 0.0;
gfloat cur_y_pre = 0.0;
// 1211
gfloat goal_x = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2,
	   goal_y;
 
gfloat goal_position = SIDECATEGORY_GAP;
gfloat ratio_point;
gfloat ratio_position;
gfloat velocity = 0;

gfloat verticalDiff = 0.0f;
gfloat liveDiff = 0.0;
gfloat contentLiveDiff = 0.0;

gfloat scaleFactor[2] = {0, 0};
gfloat curListWidth[2]= {0, 0};
gfloat curCategoryWidth[2] = {0, 0};
gfloat curCategoryTitleX[2] = {0, 0};

//gfloat contentLiveScaleX = (WIDGET_HEIGHT-CONTENTS_IMAGE_HEIGHT)/WIDGET_HEIGHT; //0.43;
//gfloat contentLiveScaleY = contentLiveScaleX; //0.43;
gfloat contentLiveScaleX = 0.46;
gfloat contentLiveScaleY = 0.46;


int currentIndex = 0;
gfloat livetick = 0;
gfloat tick = 0;
gfloat contentLiveTick = 0.0;
int extendList = 0;
int currentCategory = 0;
int currentContents = 0;
int reduceIndex = 0;
int extendIndex = 1;
int adIndex = 2;//liang.wu
int foveaState = IN_CONTENTS;
int foveaStatePre = IN_CONTENTS;
bool isOpen[2] = {false, false};

gfloat skipLiveTick;
gfloat skipContentLiveTick;
gfloat skipTick;
gfloat skipPoint;
gfloat skipPosition;
gfloat tempPosition;
gfloat skipScroll;
gfloat tempStopPosition;

bool KEY_RIGHT = false;
bool KEY_LEFT = false;
bool ALLOW_MOVE_TO_BEGIN = false;
bool ALLOW_MOVE_TO_END = false;
bool SCROLL_RIGHT = false;
bool SCROLL_LEFT = false;
bool EVENT_FLAG = true;
bool EXTEND_FLAG = false;
bool REDUCE_FLAG = false;	//liangwu
bool RECOVER_FLAG = false;	//liang.wu
bool NO_CONTENTS_FLAG = true;	//liang.wu

std::string NO_CONTENTS_1ST_Category_Name = ""; //liang.wu
std::string NO_CONTENTS_2ND_Category_Name = ""; //liang.wu

bool KEY_SELECT = false;
bool ON_TRANSITION = false;
bool STOP_FLAG = false;
bool FOCUS_OPTIONS = false;
bool WHITE_BACKGROUND[2] = {true, false};
bool CONTENT_LIVE_FLAG = false;
bool APPS_FOCUSED = false;
bool GAMES_FOCUSED = false;
bool TICK_TO_ZERO = false;

int tempcount = 0;
gfloat t_delta_x = 0;
gfloat t_delta_y = 0;
gfloat t_delta_width = 0;
gfloat t_delta_height = 0;
gfloat t_delta_scala_width = 0;
gfloat t_delta_scala_height = 0;
gfloat p_x_title_start = 0;
gfloat p_y_title_start = 0;
gfloat p_y_bar_start = 0;
gfloat p_x_bar_start = 0;

gfloat p_x_start = 0;
gfloat p_y_start = 0;
int count_transition =  0;
int COUNT_TRANSITION_FRAME = 30;
gfloat Diff_transition = 0.0;

gfloat INIT_SPEED = 0;
gfloat INIT_MINSPEED = 5.0;
gfloat INIT_MAXSPEED = 120.0;

gfloat SCALE_SPEED = 0;
gfloat SCALE_MINSPEED = 5.0;
gfloat SCALE_MAXSPEED = 120.0;

gfloat LIMIT_SPEED = 0;
gfloat LIMIT_MINSPEED = 5.0;
gfloat LIMIT_MAXSPEED = 120.0;

gfloat V_t = 0;
gfloat t_t = 0;
gfloat t_scrollout = 0;
gfloat DELAY_TIME = 0.15;
gfloat AUTOSCROLL_TIME = 5.0;
//add by junhui.wang 
gfloat MAX_ACCELERATE_TIME = 10.0;

gfloat STOP_LIMITSPEED = 120;
gfloat STOPSCROLL_TIME = 2.0;

bool isOutScroll = false;
time_t mouseMoved = 0;

//[Begin]add new curve[liang.wu]
gfloat extendCurve[4] = {0.115, 0.448, 0.436, 0.9};
gfloat exchangeCurveToLeft[4] = {0.591, 0.128, 0.8, 0.728};
gfloat exchangeCurveToRight[4] = {0.555, 0.144, 0.8, 0.5};
gfloat reduceCurve[4] = {0.492, 0.168, 0.651, 0.948};
gfloat recoverCurve[4] = {0.492, 0.168, 0.651, 0.948};

//[End]add new curve[liang.wu]
gfloat live[4] = {0.3373, 0.0, 0.0, 1.0};
gfloat hFovea[4] = {0.9, 0.3, 0.1, 0.7};
gfloat vFovea[4] = {0.8, 0.2, 0.2, 0.8};
gfloat contentLive[4] = {0.3373, 0.0, 0.0, 1.0};
gfloat transition[4] = {0.3373, 0.0, 0.0, 1.0};
//[liang.wu]add new aniTime items
gfloat aniTime[8] = { //for animation steps
	24, 	//extend 0.38
	60,		//live_excute
	60,		//live_term
	60,		//content_live_excute
	120,	//content_live_term
	24,		//exchange 0.38s
	17,		//reduce 0.27s
	17		//recover
};

long pressTime = 0;
long releaseTime = 0;
bool isPressHold = false;
bool isLongPress = false;
std::thread pressThread;

//[liang.wu]add new index
enum {EXTEND, LIVE_EXCUTE, LIVE_TERM, CONTENT_LIVE_EXCUTE, CONTENT_LIVE_TERM, EXCHANGE, REDUCE, RECOVER};

bool isKeyControl = true;//add by junhui.wang -- flag for distinguish that is  key event or mouse event
bool SCALE_ITEM_FLAG = false; // flag to scale the item animation
gfloat scaleItemTick = 0;
int scaleItemTime = 10;
int scaleItemIndex = -1;
gfloat scaleItemCurDiff = -1;
gfloat scaleItemDesDiff = -1;
gfloat scaleItemDiff = -1;
gfloat scaleItemCurVerticalDiff = -1;
gfloat scaleItemDesVerticalDiff = -1;
gfloat scaleItemVerticalDiff = -1;
gfloat scaleItemLeftTransWidth = -1;
gfloat scaleItemRightTransWidth = -1;
gfloat scaleItemAllOriginWidth = -1;
bool scaleItemFeatureOpen = false;
bool scaleItemInLastSpace = false;
gfloat scaleItem[4] = {0.3373, 0.0, 0.0, 1.0};
//reduce item
bool REDUCE_ITEM_FLAG = false; // flag to scale the item animation
gfloat reduceItemTick = 0;
int reduceItemTime = 10;
gfloat reduceItem[4] = {1.0, 0.0, 0.7166, 1.0};
gfloat reduceItemDiff;
gfloat reduceItemDesWidth;
int reduceItemIndex;
//record current normal title opacity
int CONTENT_NORMAL_TITLE_OPACITY = OPACITY_90;
//define the index of each content item for manifest

//add for the global cursor
ClutterActor* globalCursor = NULL;
gfloat globalCursorWidth = -1;
gfloat GLOBAL_CURSOR_XY_DIFF = 4;
gfloat GLOBAL_CURSOR_WH_DIFF = 8;

static gfloat getGlobalCursorWidth(void)
{
	if(globalCursor == NULL)
	{
		return -1.0;
	}
	
	gfloat val = clutter_actor_get_width(globalCursor);
	return val - GLOBAL_CURSOR_WH_DIFF;
}

static void setGlobalCursorWidth(gfloat w)
{
	if(globalCursor == NULL)
	{
		return;
	}

	gfloat val = w + GLOBAL_CURSOR_WH_DIFF;
	clutter_actor_set_width(globalCursor, val);
}

static gfloat getGlobalCursorHeight(void)
{
	if(globalCursor == NULL)
	{
		return -1.0;
	}

	gfloat val = clutter_actor_get_height(globalCursor);
	return val - GLOBAL_CURSOR_WH_DIFF;
}

static void setGlobalCursorHeight(gfloat h)
{
	if(globalCursor == NULL)
	{
		return;
	}

	gfloat val = h + GLOBAL_CURSOR_WH_DIFF;
	clutter_actor_set_height(globalCursor, val);
}

static gfloat getGlobalCursorX(void)
{
	if(globalCursor == NULL)
	{
		return -1.0;
	}

	gfloat val = clutter_actor_get_x(globalCursor);
	return val + GLOBAL_CURSOR_XY_DIFF;
}

static void setGlobalCursorX(gfloat x)
{
	if(globalCursor == NULL)
	{
		return;
	}

	gfloat val = x - GLOBAL_CURSOR_XY_DIFF;
	clutter_actor_set_x(globalCursor, val);
}

static gfloat getGlobalCursorY(void)
{
	if(globalCursor == NULL)
	{
		return -1.0;
	}

	gfloat val = clutter_actor_get_y(globalCursor);
	return val + GLOBAL_CURSOR_XY_DIFF;
}

static void setGlobalCursorY(gfloat y)
{
	if(globalCursor == NULL)
	{
		return;
	}

	gfloat val = y - GLOBAL_CURSOR_XY_DIFF;
	clutter_actor_set_y(globalCursor, val);
}

static void setGlobalCursorPosition(gfloat x, gfloat y)
{
	if(globalCursor == NULL)
	{
		return;
	}

	gfloat val_x = x - GLOBAL_CURSOR_XY_DIFF;
	gfloat val_y = y - GLOBAL_CURSOR_XY_DIFF;
	clutter_actor_set_position(globalCursor, val_x, val_y);
}

static void setGlobalCursorSize(gfloat w, gfloat h)
{
	if(globalCursor == NULL)
	{
		return;
	}

	gfloat val_w = w + GLOBAL_CURSOR_WH_DIFF;
	gfloat val_h = h + GLOBAL_CURSOR_WH_DIFF;
	clutter_actor_set_size(globalCursor, val_w, val_h);
}


//scale category
bool SCALE_CATEGORY_FLAG = false;
gfloat scaleCategoryTick = 0;
gfloat scaleCategoryTime = 10;
//reduce category
bool REDUCE_CATEGORY_FLAG = false;
gfloat reduceCategoryTick = 0;
gfloat reduceCategoryTime = 10;
//end junhui.wang

//[Begin]exchange animation params[liang.wu]
int exchangeControlStep = 0;				//step index: 0-empty 1-reduce 2-exchange 3-extend
bool EXCHANGE_FLAG = false;				//flag to really start exchange animation
int exchangeTick = 0;					//self clock
gfloat exchangeDiffToLeft = 0.0;		//step-by-step
gfloat exchangeDiffToRight = 0.0;		//step-by-step
gfloat exchangeStartRatio = 0.6;		//overlap for reduce and exchange
gfloat exchangeBindRatio = 0.8;			//overlap for exchange and extend
gfloat exchangeDistanceToLeft = 0.0;	//distance of category 0 move to left
gfloat exchangeDistanceToRight = 0.0;	//distance of category 1 move to right
gfloat recoverDistanceToBar = 0.0;		//distance of bar move
gfloat recoverDistanceToBegin = 0.0;	//during reduce, recover category 1 to begin
gfloat recoverDistanceToEnd = 0.0;		//during reduce, recover category 0 to end
gfloat recoverDistanceToTitle = 0.0;	//distance of title move

gfloat recoverDiff = 0.0;
gfloat recoverTick = 0;
gfloat reduceDiff = 0.0;
gfloat reduceTick = 0;
gfloat extendDiff = 0.0;
int extendTick = 0;

bool scrollRightFlag = false;
gfloat scrollRightTick = 0.0;//do not fovea during scroll right
gfloat scrollRightTickMax = 30.0;//do not fovea during scroll right
gfloat scrollVerticalDiffRatio = 1.0; //to adjust foveaContents verticalDiff

//[End]exchange animation params[liang.wu]

//ClutterContent *categoryBack = NULL;
//const std::string CATEGORY_BACK_URL = "icon/img_category.png";

// shuhao.yan
bool CLIPFLAG = false;
gfloat preDiff = 0;
gfloat EXTENDGAP = 30;

//liang.wu
gfloat adMoveOriginX_scaleRight = 0.0;
gfloat adCutXDiff_scaleRight = 0.0;
gfloat extendCutXDiff_scaleRight = 0.0;
gfloat extendCutXRatio_scaleRight = 1.0;
gfloat reduceCutXDiff_scaleRight = 0.0;


FirstScreenListWidget* FirstScreenListWidget::Instance()
{
	return instance;
}

//add by junhui.wang 
static void setGlobalCursor(){
	ClutterColor zeroColor = {0, 0, 0, 0};
	ClutterColor fullColor = {255, 255, 255, 255};
	//globalCursor = clutter_rectangle_new_with_color (&zeroColor);
	globalCursor = clutter_actor_new();
	ClutterContent* cursorContent = NULL;
	
	loadImageToContentAndGetSize(cursorContent,IMAGE_URL_PREFIX+GLOBAL_CURSOR_ICO_URL);
	clutter_actor_set_content(globalCursor,cursorContent);
	//clutter_actor_set_size(globalCursor, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	setGlobalCursorSize(FOCUS_CATEGORY_WIDTH, WIDGET_HEIGHT);
	//clutter_actor_set_position(globalCursor,
	//							clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH+CATEGORY_GAP, 
	//							SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
	setGlobalCursorPosition(SIDECATEGORY_GAP , SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
	//clutter_rectangle_set_border_width(CLUTTER_RECTANGLE(globalCursor), 2);
	//clutter_rectangle_set_border_color(CLUTTER_RECTANGLE(globalCursor), &fullColor);
	clutter_actor_set_opacity(globalCursor, 255);
	clutter_actor_add_child(instance->SCENEROOT->getActor(),globalCursor);
}
//end add by junhui.wang

/* add by lin89.zhang 2014/11/20 for add overlapShadow of first catefory begin */
ClutterActor *overlapShadow = NULL;//lin89.zhang

static void setOverlapShadow(void)
{
    ClutterColor lColor = {0, 0, 0, 255};
    ClutterColor rColor = {0, 0, 0, 2};
    //ClutterColor lColor = {0, 100, 0, 255};
    //ClutterColor rColor = {2000, 0, 0, 2};
	overlapShadow = volt_actor_new();
	volt_actor_set_grad_tl_color(VOLT_ACTOR(overlapShadow), &lColor);
	volt_actor_set_grad_tr_color(VOLT_ACTOR(overlapShadow), &rColor);
	volt_actor_set_grad_bl_color(VOLT_ACTOR(overlapShadow), &lColor);
	volt_actor_set_grad_br_color(VOLT_ACTOR(overlapShadow), &rColor);
	volt_actor_set_width(VOLT_ACTOR(overlapShadow), OVERLAP_SHADOW_WIDTH);
	volt_actor_set_height(VOLT_ACTOR(overlapShadow), WIDGET_HEIGHT);
	clutter_actor_set_x(overlapShadow, SIDECATEGORY_GAP+NORMAL_CATEGORY_WIDTH);
	clutter_actor_set_y(overlapShadow, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
	clutter_actor_add_child(instance->SCENEROOT->getActor(), overlapShadow);
}

static void fixOverlapShadow(void)
{
	if(overlapShadow)
	{
		ClutterActor *firstChild = clutter_actor_get_child_at_index(bar, reduceIndex);
	    gfloat x = clutter_actor_get_x(bar)+clutter_actor_get_x(firstChild) + reduceCutXDiff_scaleRight;//liang.wu fix scale x
	    gfloat w = clutter_actor_get_width(firstChild);
	    clutter_actor_set_x(overlapShadow, x+w);
	}
}

/*add by lin89.zhang for adding option indicator icon begin*/
static void loadImageToContentAndGetSize(ClutterContent *&content, 
                                         const std::string &url, 
                                         gfloat *retWidth,
                                         gfloat *retHeight)
{
    if (content == NULL)
    {
        content = clutter_image_new();
    }
    GError *error = NULL;
    GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file (url.c_str(), NULL);
    clutter_image_set_data (CLUTTER_IMAGE(content),
                        gdk_pixbuf_get_pixels (pixbuf),
                        gdk_pixbuf_get_has_alpha (pixbuf)
                          ? COGL_PIXEL_FORMAT_RGBA_8888
                          : COGL_PIXEL_FORMAT_RGB_888,
                        gdk_pixbuf_get_width (pixbuf),
                        gdk_pixbuf_get_height (pixbuf),
                        gdk_pixbuf_get_rowstride (pixbuf),
                        &error);
    if (retWidth != NULL)
    {
        *retWidth = gdk_pixbuf_get_width (pixbuf);
    }
    if (retHeight != NULL)
    {
        *retHeight = gdk_pixbuf_get_height (pixbuf);
    }
    g_object_unref (pixbuf);
}
/*add by lin89.zhang for adding option indicator icon end*/

FirstScreenListWidget::FirstScreenListWidget(Widget* aParent, const ScriptArray& args)
{
	instance = this;
	IMAGE_URL_PREFIX = IMAGE_URL_PREFIX+ "1920"+"/";

	if (aParent->getHeight() != 1080 || aParent->getWidth() != 1920)
	{
		// Need to redefine the values  of global params[shuhao.yan]
		redefineGlobalParams(aParent->getHeight());
	}
	// To define the SCENE WIDTH AGAIN  For 21:9 Feature[shuhao.yan]
	SCENE_WIDTH  = aParent->getWidth();

	// If JS layer want to redefine Global Params -->>>To parse the args[shuhao.yan]
	ScriptObject options;
    int argsLen = args.Length();

    if(argsLen > 1)
    {
		options = args[1];
		redefineGlobalParams(options);
	}

	// Add a level between scene and Bar widget, To implement the reverse OSD [shuhao.yan]
	SCENEROOT = new  Widget(0, 0, SCENE_WIDTH, SCENE_HEIGHT, aParent);
	SCENEROOT->setPivot(Vector2(0.5, 0.5));
	//SCENEROOT->setDepth(-1000.0);

	actor = volt_actor_new();
	init(SIDECATEGORY_GAP, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT, SCENEROOT);
	//volt_actor_set_width(VOLT_ACTOR(actor), SCENE_WIDTH - 2 * CATEGORY_GAP); // [shuhao.yan]
	volt_actor_set_height(VOLT_ACTOR(actor), WIDGET_HEIGHT);
	clutter_actor_set_translation(actor, 0, 0 , 0);

	//clutter_actor_set_reactive(actor, TRUE);
	
	bar = actor;

	/* add by lin89.zhang 2014/11/20 for add overlapShadow of first catefory begin */
    setOverlapShadow();
	//clutter_actor_hide(overlapShadow);
	/* add by lin89.zhang 2014/11/20 for add overlapShadow of first catefory end */
	/* add by lin89.zhang 2014/11/20 for adding background image of first catefory begin */
    //loadImageToContentAndGetSize(categoryBack, 
    //    IMAGE_URL_PREFIX+CATEGORY_BACK_URL);
	/* add by lin89.zhang 2014/11/20 for adding background image of first catefory end */

	/*add by lin89.zhang for adding option indicator icon begin*/
#if 0
	loadImageToContentAndGetSize(optionUpNormalIco, 
	                             IMAGE_URL_PREFIX+OPTION_UP_NORMAL_ICO_URL);
	loadImageToContentAndGetSize(optionDownNormalIco, 
	                             IMAGE_URL_PREFIX+OPTION_DOWN_NORMAL_ICO_URL, 
	                             &optionIcoWidth, 
	                             &optionIcoHeight);
    loadImageToContentAndGetSize(optionUpFocusIco, 
	                             IMAGE_URL_PREFIX+OPTION_UP_FOCUS_ICO_URL);
	loadImageToContentAndGetSize(optionDownFocusIco, 
	                             IMAGE_URL_PREFIX+OPTION_DOWN_FOCUS_ICO_URL);
#endif
	/*add by lin89.zhang for adding option indicator icon end*/

	//add the global cursor by junhui.wang
	setGlobalCursor();

	ClutterColor color = { 0, 0, 0, 0 };
	
	mouseArea = clutter_rectangle_new_with_color(&color);

    clutter_actor_set_size(mouseArea, SCENE_WIDTH, SCENE_HEIGHT);	
    clutter_actor_set_position(mouseArea, 0, 0);
	clutter_actor_set_reactive (mouseArea, TRUE);
    clutter_actor_add_child(SCENEROOT->getActor(), mouseArea);
}


/*
Need to redefine the global parameters 
To separate FHD ,HD and 21:9 resolution also
[shuhao.yan]
*/
void FirstScreenListWidget::redefineGlobalParams(float scene_height)
{
	SCENE_HEIGHT = scene_height;

	int switchHeight = (int)SCENE_HEIGHT;
	// for 21:9 feature [shuhao.yan] Must use const number
	switch(switchHeight)
	{
		case 720:
			SCENE_WIDTH  = 1280;
			break;
		case 1080:
			SCENE_WIDTH  = 1920;
			break;
		case 2160:
			SCENE_WIDTH  = 3840;
			break;
		default:
			SCENE_WIDTH  = 1920;
	}

	HD_PROPORTION = SCENE_HEIGHT / 1080;

    SCALE_AREA = 30 * HD_PROPORTION;
	SCROLL_AREA = 30 * HD_PROPORTION;
	PROGRESS_HEIGHT =  2 * HD_PROPORTION;
	SIDECATEGORY_GAP *= HD_PROPORTION;

	WIDGET_HEIGHT = SCENE_WIDTH * 0.130729;
	BOTTOM_HEIGHT = Rounding(SCENE_HEIGHT * 0.046296, 1);
	CONTENTS_IMAGE_HEIGHT = Rounding(SCENE_HEIGHT * 0.160185, 1);
	CATEGORY_GAP =  Rounding(SCENE_WIDTH * 0.015625, 1);
	OVERLAP_SHADOW_WIDTH = Rounding(SCENE_WIDTH * 0.0489583, 1);

	OPTION_GAP = Rounding(SCENE_HEIGHT * 0.016667, 1); 

	NORMAL_CATEGORY_WIDTH = Rounding(SCENE_WIDTH * 0.139583, 1);
	FOCUS_CATEGORY_WIDTH = NORMAL_CATEGORY_WIDTH * 1.0;
	OVER_CATEGORY_WIDTH = NORMAL_CATEGORY_WIDTH * 0.3;

	NORMAL_CATEGORY_TITLE_WIDTH = NORMAL_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;
	FOCUS_CATEGORY_TITLE_WIDTH = FOCUS_CATEGORY_WIDTH - 2 * SCENE_WIDTH * 0.015625;

	CATEGORY_TITLE_Y = SCENE_HEIGHT * 0.004630;
	EXTEND_CATEGORY_TITLE_X = 30 * HD_PROPORTION;
	EXTEND_CATEGORY_TITLE_Y = -50 * HD_PROPORTION;
	CATEGORY_COLOR_HEIGHT = WIDGET_HEIGHT * 0.500000;
	CATEGORY_LIVE_HEIGHT = WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT;

	NORMAL_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.090104, 1);
	FOCUS_CONTENTS_WIDTH = Rounding(SCENE_WIDTH * 0.131250, 1);

	NORMAL_CONTENTS_TITLE_WIDTH = NORMAL_CONTENTS_WIDTH - 2 * SCENE_WIDTH * 0.003535;
	FOCUS_CONTENTS_TITLE_WIDTH = FOCUS_CONTENTS_WIDTH;

    CONTENTS_TITLE_X = SCENE_WIDTH * 0.003535;
	CONTENTS_TITLE_Y = SCENE_HEIGHT * 0.016667;
	FOCUS_CONTENTS_TITLE_Y = SCENE_HEIGHT * 0.014814;

	ICON_GAP = SCENE_WIDTH * 0.003125;
	ICON_BOTTOM_GAP = SCENE_HEIGHT * 0.007407;
	ICON_RIGHT_GAP = SCENE_HEIGHT * 0.006250;

	cur_x = CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2, 
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;
	goal_x = NORMAL_CATEGORY_WIDTH + 2*CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
	goal_position = CATEGORY_GAP;

    IMAGE_URL_PREFIX = IMAGE_URL_PREFIX+ "1920"+"/"; //TODO: 
}


/*
Need to redefine the global parameters  in JS layer
To separate FHD ,HD and 21:9 resolution also
[shuhao.yan]
*/

void FirstScreenListWidget::redefineGlobalParams(const ScriptObject& params)
{
	if (params.has("SCENE_WIDTH"))
	{
		SCENE_WIDTH = params.get("SCENE_WIDTH").asNumber();
	}

	if (params.has("SCENE_HEIGHT"))
	{
		SCENE_HEIGHT = params.get("SCENE_HEIGHT").asNumber();
	}

	if (params.has("WIDGET_HEIGHT"))
	{
		WIDGET_HEIGHT = params.get("WIDGET_HEIGHT").asNumber();
	}

	if (params.has("BOTTOM_HEIGHT"))
	{
		BOTTOM_HEIGHT = params.get("BOTTOM_HEIGHT").asNumber();
	}

	if (params.has("CONTENTS_IMAGE_HEIGHT"))
	{
		CONTENTS_IMAGE_HEIGHT = params.get("CONTENTS_IMAGE_HEIGHT").asNumber();
	}

	if (params.has("CATEGORY_GAP"))
	{
		CATEGORY_GAP = params.get("CATEGORY_GAP").asNumber();
	}

	if (params.has("SCROLL_AREA"))
	{
		SCROLL_AREA = params.get("SCROLL_AREA").asNumber();
	}

	if (params.has("NORMAL_CATEGORY_WIDTH"))
	{
		NORMAL_CATEGORY_WIDTH = params.get("NORMAL_CATEGORY_WIDTH").asNumber();
	}

	if (params.has("FOCUS_CATEGORY_WIDTH"))
	{
		FOCUS_CATEGORY_WIDTH = params.get("FOCUS_CATEGORY_WIDTH").asNumber();
	}

	if (params.has("NORMAL_CATEGORY_TITLE_WIDTH"))
	{
		NORMAL_CATEGORY_TITLE_WIDTH = params.get("NORMAL_CATEGORY_TITLE_WIDTH").asNumber();
	}

	if (params.has("FOCUS_CATEGORY_TITLE_WIDTH"))
	{
		FOCUS_CATEGORY_TITLE_WIDTH = params.get("FOCUS_CATEGORY_TITLE_WIDTH").asNumber();
	}

	if (params.has("CATEGORY_TITLE_X"))
	{
		CATEGORY_TITLE_X = params.get("CATEGORY_TITLE_X").asNumber();
	}

	if (params.has("CATEGORY_TITLE_Y"))
	{
		CATEGORY_TITLE_Y = params.get("CATEGORY_TITLE_Y").asNumber();
	}

	if (params.has("EXTEND_CATEGORY_TITLE_Y"))
	{
		EXTEND_CATEGORY_TITLE_Y = params.get("EXTEND_CATEGORY_TITLE_Y").asNumber();
	}

	if (params.has("CATEGORY_COLOR_HEIGHT"))
	{
		CATEGORY_COLOR_HEIGHT = params.get("CATEGORY_COLOR_HEIGHT").asNumber();
	}

	if (params.has("CATEGORY_LIVE_HEIGHT"))
	{
		CATEGORY_LIVE_HEIGHT = params.get("CATEGORY_LIVE_HEIGHT").asNumber();
	}

	if (params.has("NORMAL_CONTENTS_WIDTH"))
	{
		NORMAL_CONTENTS_WIDTH = params.get("NORMAL_CONTENTS_WIDTH").asNumber();
	}

	if (params.has("FOCUS_CONTENTS_WIDTH"))
	{
		FOCUS_CONTENTS_WIDTH = params.get("FOCUS_CONTENTS_WIDTH").asNumber();
	}

	if (params.has("NORMAL_CONTENTS_TITLE_WIDTH"))
	{
		NORMAL_CONTENTS_TITLE_WIDTH = params.get("NORMAL_CONTENTS_TITLE_WIDTH").asNumber();
	}
	
	if (params.has("FOCUS_CONTENTS_TITLE_WIDTH"))
	{
		FOCUS_CONTENTS_TITLE_WIDTH = params.get("FOCUS_CONTENTS_TITLE_WIDTH").asNumber();
	}
	
	if (params.has("CONTENTS_TITLE_X"))
	{
		CONTENTS_TITLE_X = params.get("CONTENTS_TITLE_X").asNumber();
	}
	
	if (params.has("CONTENTS_TITLE_Y"))
	{
		CONTENTS_TITLE_Y = params.get("CONTENTS_TITLE_Y").asNumber();
	}
	
	if (params.has("PROGRESS_HEIGHT"))
	{
		PROGRESS_HEIGHT = params.get("PROGRESS_HEIGHT").asNumber();
	}

	if (params.has("ICON_GAP"))
	{
		ICON_GAP = params.get("ICON_GAP").asNumber();
	}

	if (params.has("ICON_BOTTOM_GAP"))
	{
		ICON_BOTTOM_GAP = params.get("ICON_BOTTOM_GAP").asNumber();
	}

	if (params.has("PROGRESS_HEIGHT"))
	{
		PROGRESS_HEIGHT = params.get("PROGRESS_HEIGHT").asNumber();
	}

	if (params.has("cur_x"))
	{
		cur_x = params.get("cur_x").asNumber();
	}

	if (params.has("cur_y"))
	{
		cur_y = params.get("cur_y").asNumber();
	}

	if (params.has("goal_x"))
	{
		goal_x = params.get("goal_x").asNumber();
	}

	if (params.has("goal_y"))
	{
		goal_y = params.get("goal_y").asNumber();
	}

	if (params.has("goal_position"))
	{
		goal_position = params.get("goal_position").asNumber();
	}
	

    IMAGE_URL_PREFIX = IMAGE_URL_PREFIX+ "1920"+"/"; //TODO: 
}


static gfloat x_for_t(gfloat t, gfloat x_1, gfloat x_2)
{
  gfloat omt = 1.0 - t;

  return 3.0 * omt * omt * t * x_1
       + 3.0 * omt * t * t * x_2
       + t * t * t;
}

static gfloat y_for_t(gfloat t, gfloat y_1, gfloat y_2)
{
  gfloat omt = 1.0 - t;

  return 3.0 * omt * omt * t * y_1
       + 3.0 * omt * t * t * y_2
       + t * t * t;
}

static gfloat t_for_x(gfloat x, gfloat x_1, gfloat x_2) 
{
  gfloat min_t = 0, max_t = 1;
  gfloat guess_t, guess_x;
  int i;

  for(i = 0; i < 30; ++i) 
  {
      guess_t = (min_t + max_t) / 2.0;
      guess_x = x_for_t (guess_t, x_1, x_2);

      if (x < guess_x)
        max_t = guess_t;
      else
        min_t = guess_t;
    }

  return (min_t + max_t) / 2.0;
}

static gfloat bezier(gfloat t, gfloat d, gfloat x_1, gfloat y_1, gfloat x_2, gfloat y_2) 
{
  gfloat p = t / d;

  if (p == 0.0)
    return 0.0;

  if (p == 1.0)
    return 1.0;

  return y_for_t (t_for_x (p, x_1, x_2), y_1, y_2);
}

static gfloat easeOutCirc(gfloat input)
{
    return sqrt(1.f-(input-1.f)*(input-1.f));
}

void FirstScreenListWidget::setExtendBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time)
{
	extendCurve[0]=x1;	extendCurve[1]=y1;	extendCurve[2]=x2;	extendCurve[3]=y2;	aniTime[EXTEND]=time*0.06f;
	
	tick = 0;
}

void FirstScreenListWidget::setLiveImageBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2)
{
	live[0]=x1;	live[1]=y1;	live[2]=x2;	live[3]=y2;	aniTime[LIVE_EXCUTE]=time1*0.06f;	aniTime[LIVE_TERM]=time2*0.06f;
	
	//livetick = 0;
	FirstScreenCategoryLiveControl::GetInstance()->RefreshFrame(true);
}

void FirstScreenListWidget::setHorizontalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2)
{
	hFovea[0]=x1;	hFovea[1]=y1;	hFovea[2]=x2;	hFovea[3]=y2;
}

void FirstScreenListWidget::setVerticalFoveaBezier(gfloat x1, gfloat y1, gfloat x2, gfloat y2)
{
	vFovea[0]=x1;	vFovea[1]=y1;	vFovea[2]=x2;	vFovea[3]=y2;	
}

void FirstScreenListWidget::setContentLiveBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time1, gfloat time2)
{
	contentLive[0]=x1;	contentLive[1]=y1;	contentLive[2]=x2;	contentLive[3]=y2;	aniTime[CONTENT_LIVE_EXCUTE]=time1*0.06f;	aniTime[CONTENT_LIVE_TERM]=time2*0.06f;

	contentLiveTick = 0;
}

void FirstScreenListWidget::setTransitionBezierAndTime(gfloat x1, gfloat y1, gfloat x2, gfloat y2, gfloat time)
{
	transition[0]=x1;	transition[1]=y1;	transition[2]=x2;	transition[3]=y2;	COUNT_TRANSITION_FRAME=time*0.06f;	
}

int FirstScreenListWidget::returnCategory()
{
	return currentCategory;
}

int FirstScreenListWidget::returnContents()
{
	return currentContents;
}

void FirstScreenListWidget::enableMoveToBegin()
{
	ALLOW_MOVE_TO_BEGIN = true;
}

void FirstScreenListWidget::enableMoveToEnd()
{
	ALLOW_MOVE_TO_END = true;
}

void FirstScreenListWidget::setFocusById(std::string id)
{
	// do nothing
}

static void createCategory(FirstScreenCategory* Item, ClutterActor* parent)
{
	ClutterColor zeroColor = {0, 0, 0, 0};
	ClutterColor fullColor = {255, 255, 255, 255};
	ClutterColor categoryColor = CATEGOTY_COLOR;

	ClutterActor *current = NULL;
	
	//categoryWrapper
	current = Item->categoryWrapper;
	
	//lin89.zhang
	clutter_actor_set_size(current, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	//clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_background_color(current, &categoryColor);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_set_clip_to_allocation(current, TRUE);

	//categoryTitle
	current = Item->categoryTitle;
	clutter_actor_set_position(current, CATEGORY_TITLE_X, - (clutter_actor_get_height(current) + CATEGORY_TITLE_Y));
	clutter_actor_set_opacity(current, OPACITY_70);

	// [shuhao.yan]
	if (REVERSE_OSD) // To rotate the latest careated category title
	{
		clutter_actor_set_rotation_angle(current, CLUTTER_Y_AXIS, 180);
	}

	//build category live
	if(Item->id.compare("featured") == 0)
	{
		FirstScreenCategoryLiveControl::GetInstance()->SetFeaturedParent(Item->categoryWrapper);
	}
	else if(Item->id.compare("history") == 0)
	{
		FirstScreenCategoryLiveControl::GetInstance()->SetHistoryParent(Item->categoryWrapper);
	}

	clutter_actor_add_child(parent, Item->categoryWrapper);
	clutter_actor_add_child(parent, Item->categoryTitle);
}

void FirstScreenListWidget::createChild(FirstScreenCategory* Item)
{
	reduceIndex = 0;
	extendIndex = 1;
	
	ClutterActor *child = clutter_actor_new();
	ClutterColor zeroColor = {0, 0, 0, 0};
	clutter_actor_set_size(child, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT);
    clutter_actor_set_position(child, 0, 0);
	clutter_actor_set_background_color(child, &zeroColor);
	clutter_actor_set_opacity(child, 255);
	
	if(clutter_actor_get_n_children(bar) == 0)
	{
		isOpen[0] = true;
		isOpen[1] = false;
		clutter_actor_insert_child_at_index(bar, child, reduceIndex);
	}
	else
	{
		clutter_actor_set_position(child, NORMAL_CATEGORY_WIDTH + CATEGORY_GAP, 0);
		clutter_actor_insert_child_at_index(bar, child, extendIndex);

		isOpen[0] = false;
		isOpen[1] = true;
	}

	createCategory(Item, child); 

	ClutterActor *current = Item->listWrapper;

	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
    clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 0);
	clutter_actor_set_pivot_point(current, 0.0, 0.0);

	clutter_actor_add_child(child, current);

	clutter_actor_set_name(child, const_cast<gchar*>(Item->id.c_str()));

	// insert map
	categoryActorMap.insert(pair<ClutterActor*, FirstScreenCategory*>(Item->categoryWrapper, Item));

	if (!Item->id.empty())
	{
		categoryTagMap.insert(pair<std::string, FirstScreenCategory*>(Item->id, Item));
		if(NO_CONTENTS_1ST_Category_Name.empty())
		{
			NO_CONTENTS_1ST_Category_Name = Item->id;
		}
		else if(NO_CONTENTS_2ND_Category_Name.empty())
		{
			NO_CONTENTS_2ND_Category_Name = Item->id;
		}
	}
}

static void toNormalContents(int category, int contents, gfloat init_x)
{
	ClutterActor *temp = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	gfloat normalOverlapOpcity;
	if(HIGH_CONTRAST_FLAG)
		normalOverlapOpcity = OPACITY_100;
	else
		normalOverlapOpcity = OPACITY_8;

	//barChild
	temp = clutter_actor_get_child_at_index(bar, category);

	//contentsWrapper
	temp = clutter_actor_get_child_at_index(temp, CATEGORY_LISTWRAPPER_INDEX);
	temp = clutter_actor_get_child_at_index(temp, contents);

	clutter_actor_set_x(temp, init_x + NORMAL_CONTENTS_WIDTH*contents);
	clutter_actor_set_width(temp, NORMAL_CONTENTS_WIDTH);

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp, DOMINANT_INDEX);

	clutter_actor_set_width(temp2, NORMAL_CONTENTS_WIDTH);
	clutter_actor_set_opacity(temp2, OPACITY_100);
	clutter_actor_set_clip(temp2,0,0,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);
	clutter_actor_set_height(temp2,WIDGET_HEIGHT);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);

	//clutter_actor_set_size(temp3, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_scale(temp3, 1, 1);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);

	clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
	clutter_actor_set_y(temp3, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_opacity(temp3,normalOverlapOpcity);
	
	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);

	clutter_actor_set_x(temp3, NORMAL_CONTENTS_WIDTH - ICON_RIGHT_GAP - clutter_actor_get_width(temp3));

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);

	clutter_actor_set_opacity(temp3, 0);

	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, 1, 1);
		clutter_actor_set_opacity(temp3, 0);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100);
	}
	
	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp, TITLEPARENT_INDEX);

	clutter_actor_set_y(temp2, CONTENTS_IMAGE_HEIGHT);

	//title1
	temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);

	//clutter_actor_set_x(temp3, CONTENTS_TITLE_X);
	clutter_actor_set_opacity(temp3, CONTENT_NORMAL_TITLE_OPACITY);

	//title2
	temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
	
	//clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
	//clutter_actor_set_x(temp3, (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2);
	clutter_actor_set_opacity(temp3, 0);

	//progressN & Dim
	if (clutter_actor_get_n_children(temp) == CONTENT_DIM_INDEX + 1)
	{
		temp2 = clutter_actor_get_child_at_index(temp, CONTENT_DIM_INDEX);
		ProgressController::updateProgressFoveaStatus(temp2, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	}
	
#if 0
	//dim
	temp2 = clutter_actor_get_child_at_index(temp, CONTENT_DIM_INDEX);
	clutter_actor_set_width(temp2,NORMAL_CONTENTS_WIDTH);

	temp2 = clutter_actor_get_child_at_index(temp, CONTENT_PROGRESS_INDEX);
	temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);
	gfloat progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_y(temp2, CONTENTS_IMAGE_HEIGHT - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
	
		clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_x(temp3, NORMAL_CONTENTS_WIDTH * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}
	// options
	int itemCounts = clutter_actor_get_n_children(temp);
	if (itemCounts > CONTENT_OPTION_INDEX) 
	{
		ClutterActor *tempOption = clutter_actor_get_child_at_index(temp, CONTENT_OPTION_INDEX);
		clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp)-optionIcoWidth)/2);
        clutter_actor_set_opacity(tempOption, 0);
	}
#endif
}

void FirstScreenListWidget::createContents(FirstScreenContents* Item) 
{
	ClutterActor *current = NULL;
	
	int index = Item->index;
	
	ClutterColor zeroColor = {0, 0, 0, 0};
	ClutterColor fullColor = {255, 255, 255, 255};
	ClutterColor overRayColor = {0, 0, 0, 255};
	ClutterColor progressColor = {255, 255, 255, 25};
	ClutterColor dimColor = {0, 0, 0, 255};
	
	gfloat iconParentWidth1 = 0.0f;
	gfloat iconParentWidth2 = 0.0f;
	gfloat iconParentHeight = 0.0f;

	//contentsWrapper
	current = Item->contentsWrapper;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	//clutter_actor_set_position(current, NORMAL_CONTENTS_WIDTH*index, 0);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 255);
	
	// [shuhao.yan]
	if (REVERSE_OSD) // To rotate the latest careated content
	{
		clutter_actor_set_rotation_angle(current, CLUTTER_Y_AXIS, 180);
	}

	//dominant
	current = Item->dominant;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_background_color(current, Item->dominantColor.toClutterColor());
	clutter_actor_set_opacity(current, OPACITY_100);
	clutter_actor_set_clip(current,0,0,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);

	//titleParent
	current = Item->titleParent;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT - CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 255);

#if 0
	//dim
	ClutterActor *dim = clutter_actor_new();
	clutter_actor_set_size(dim, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(dim, 0, 0);
	clutter_actor_set_opacity(dim, 0);
	clutter_actor_set_background_color(dim, &dimColor);

	//progressP
	current = Item->progressP;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, PROGRESS_HEIGHT);
	clutter_actor_set_position(current, 0, CONTENTS_IMAGE_HEIGHT - PROGRESS_HEIGHT);
	clutter_actor_set_background_color(current, &progressColor);
	clutter_actor_set_opacity(current, 0);
	clutter_actor_set_clip_to_allocation(current, TRUE);

	//progressC
	ClutterActor *progressC = clutter_actor_new();
	
	clutter_actor_set_size(progressC, NORMAL_CONTENTS_WIDTH, PROGRESS_HEIGHT);
	clutter_actor_set_position(progressC, -NORMAL_CONTENTS_WIDTH, 0);
	clutter_actor_set_background_color(progressC, &fullColor);
	clutter_actor_set_opacity(progressC, OPACITY_100);
	clutter_actor_add_child(current, progressC);
	
	//progressN
	ClutterActor *progressN = clutter_actor_new();
	
	clutter_actor_set_x(progressN, 0);
	clutter_actor_set_opacity(progressN, 0);
	clutter_actor_add_child(current, progressN);
#endif

	//main
	current = Item->mainWrapper;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_pivot_point(current, 0.0, 0.0);
	clutter_actor_add_child(Item->dominant, current);

	//subMain
	current = Item->subMain;
	
	clutter_actor_set_width(current, 10.0f);
	clutter_actor_add_child(Item->dominant, current);

	//overRay
	current = Item->overRay;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT - CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_background_color(current, &blackColor);
	clutter_actor_set_opacity(current, OPACITY_40);
	clutter_actor_add_child(Item->dominant, current);

	//iconParent1
	current = Item->iconParent1;
	
	clutter_actor_get_size(current, &iconParentWidth1, &iconParentHeight);
	clutter_actor_set_position(current, NORMAL_CONTENTS_WIDTH - iconParentWidth1 - ICON_RIGHT_GAP, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_add_child(Item->dominant, current);

	//iconParent2
	current = Item->iconParent2;
	
	clutter_actor_get_size(current, &iconParentWidth2, &iconParentHeight);
	clutter_actor_set_position(current, FOCUS_CONTENTS_WIDTH - ICON_GAP - iconParentWidth1- iconParentWidth2 - ICON_RIGHT_GAP, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
	clutter_actor_set_background_color(current, &zeroColor);
	clutter_actor_set_opacity(current, 0);
	clutter_actor_add_child(Item->dominant, current);

	//normalTitle
	//current = Item->normalTitle;
	TextScroll* normalTitle = new TextScroll(Item->titleParent, Item->jsInstance.get("normalTitle"));
	current = normalTitle->getOperatorActor();
	normalTitle->setPosition(CONTENTS_TITLE_X, CONTENTS_TITLE_Y);
	TextScroll::insertNormalInc(current, normalTitle);
	
	//clutter_actor_set_position(current, CONTENTS_TITLE_X, CONTENTS_TITLE_Y);
	//clutter_actor_set_opacity(current, OPACITY_70);
	//clutter_actor_add_child(Item->titleParent, current);
	CONTENT_NORMAL_TITLE_OPACITY = OPACITY_90;

	//focusTitle
	//current = Item->focusTitle;
	//add by junhui.wang [add the vertical gap of focus tile of content item]
	TextScroll* focusTitle = new TextScroll(Item->titleParent, Item->jsInstance.get("focusTitle"));
	focusTitle->setPosition(0, FOCUS_CONTENTS_TITLE_Y);
	focusTitle->setLayoutSize(FOCUS_CONTENTS_WIDTH, -1, false);
	//clutter_actor_set_position(current, (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(current))/2, FOCUS_CONTENTS_TITLE_Y);
	current = focusTitle->getOperatorActor();
	clutter_actor_set_opacity(current, 0);
	TextScroll::insertFocusInc(current, focusTitle);
	//clutter_actor_add_child(Item->titleParent, current);

	//main
	current = Item->main;
	
	clutter_actor_set_size(current, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(current, 0, 0);
	clutter_actor_set_opacity(current, 255);
	clutter_actor_set_pivot_point(current, -0.1, 1.9);
	clutter_actor_insert_child_at_index(Item->mainWrapper, current, 2);// ??? shuhao.yan 
	
	clutter_actor_add_child(Item->contentsWrapper, Item->dominant);
	clutter_actor_add_child(Item->contentsWrapper, Item->titleParent);
#if 0
	//clutter_actor_add_child(Item->contentsWrapper, dim);
	//clutter_actor_set_child_at_index(Item->contentsWrapper,dim,CONTENT_DIM_INDEX);
	//clutter_actor_add_child(Item->contentsWrapper, Item->progressP);
	//clutter_actor_set_child_at_index(Item->contentsWrapper,Item->progressP,CONTENT_PROGRESS_INDEX);

	if (Item->haveOptions)
	{
    	/*add by lin89.zhang for adding option indicator icon begin*/
    	ClutterActor *optionIndicatorIco = clutter_actor_new();
    	clutter_actor_set_size(optionIndicatorIco, optionIcoWidth, optionIcoHeight);
    	clutter_actor_set_position(optionIndicatorIco, 
    	                           (clutter_actor_get_width(Item->contentsWrapper)-optionIcoWidth)/2, 
    	                           -optionIcoHeight-OPTION_GAP);
    	clutter_actor_set_content(optionIndicatorIco, optionUpNormalIco);
    	clutter_actor_set_opacity(optionIndicatorIco, 0);
	    clutter_actor_add_child(Item->contentsWrapper, optionIndicatorIco);
	    clutter_actor_set_child_at_index(Item->contentsWrapper, optionIndicatorIco, CONTENT_OPTION_INDEX);
    	/*add by lin89.zhang for adding option indicator icon end*/
	}
#endif
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *tempContents = NULL;

	gfloat prev_x = 0.0f;
	gfloat prev_width = NORMAL_CONTENTS_WIDTH;
	gint count = 0;
	gint currentCategory = 0;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");

		return;
	}
	else if(clutter_actor_get_n_children(bar) == 1)
	{
		currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
		childName = clutter_actor_get_name(currentChild);

		currentCategory = 0;

		if(Item->categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");

			return;
		}

		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);

		count = clutter_actor_get_n_children(currentList);

		tempContents = clutter_actor_get_child_at_index(currentList, index - 1);

		if(tempContents != NULL)
		{
			prev_x = clutter_actor_get_x(tempContents);
			prev_width = clutter_actor_get_width(tempContents);
		}

		if(index == 0 && count != 0)
		{
			prev_x = 0.0f;
			prev_width = 0.0f;

			toNormalContents(currentCategory, 0, 0);
		}

		for(int i = index; i < count; i++)
		{
			tempContents = clutter_actor_get_child_at_index(currentList, i);

			clutter_actor_set_x(tempContents, prev_x + prev_width + NORMAL_CONTENTS_WIDTH + NORMAL_CONTENTS_WIDTH*(i - index));	
		}
		
		clutter_actor_set_position(Item->contentsWrapper, prev_x + prev_width, 0);

		clutter_actor_insert_child_at_index(currentList, Item->contentsWrapper, index);

		clutter_actor_set_width(currentList, NORMAL_CONTENTS_WIDTH*(count + 1) + FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH);
	}
	else
	{
		currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);

		childName = clutter_actor_get_name(currentChild);

		currentCategory = 0;

		if(Item->categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			currentCategory = 1;

			if(Item->categoryType.compare(childName) != 0)
			{
				//printf("There is no such category!!! Check id!!!\n");

				return;
			}			
		}

		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);

		count = clutter_actor_get_n_children(currentList);

		tempContents = clutter_actor_get_child_at_index(currentList, index - 1);

		if(tempContents != NULL)
		{
			prev_x = clutter_actor_get_x(tempContents);
			prev_width = clutter_actor_get_width(tempContents);
		}

		if(index == 0 && count != 0)
		{
			prev_x = 0.0f;
			prev_width = 0.0f;

			toNormalContents(currentCategory, 0, 0);
		}

		for(int i = index; i < count; i++)
		{
			tempContents = clutter_actor_get_child_at_index(currentList, i);

			clutter_actor_set_x(tempContents, prev_x + prev_width + NORMAL_CONTENTS_WIDTH + NORMAL_CONTENTS_WIDTH*(i - index));	
		}
		
		clutter_actor_set_position(Item->contentsWrapper, prev_x + prev_width, 0);

		clutter_actor_insert_child_at_index(currentList, Item->contentsWrapper, index);

		clutter_actor_set_width(currentList, NORMAL_CONTENTS_WIDTH*(count + 1) + FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH);
	}

	itemMap.insert(pair<ClutterActor*, FirstScreenContents*>(Item->contentsWrapper, Item));

	if (!Item->id.empty())
	{
		contentsTagMap.insert(pair<std::string, FirstScreenContents*>(Item->id, Item));
#if 0
		//liang.wu if there is content in history, begin to work [maybe need to be re-designed]
		if(false == NO_CONTENTS_2ND_Category_Name.empty() 
			&& Item->categoryType.compare(NO_CONTENTS_2ND_Category_Name.c_str()) == 0)//it is the second category
		{
			NO_CONTENTS_FLAG = false;
			STOP_FLAG = false;
		}
#endif
		//liang.wu consider clear all and then re-add contents
		if(clutter_actor_get_n_children(bar) >= 2)
		{
			std::string tempName;
			tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, extendIndex));	
			if(Item->categoryType.compare(tempName.c_str()) == 0)
			{
				NO_CONTENTS_FLAG = false;
				STOP_FLAG = false;
			}
		}
	}
}

void FirstScreenListWidget::fallFirstScreen()
{
	//fix the index change over 
	if(REDUCE_FLAG || RECOVER_FLAG || EXCHANGE_FLAG || EXTEND_FLAG){
		if(REDUCE_FLAG){
			reduceDiff = 1.0;
			reduceEffect();
			REDUCE_FLAG = false;
			reduceTick = 0;
		}
		if(RECOVER_FLAG){
			recoverDiff = 1.0;
			recoverEffect();
			RECOVER_FLAG = false;
			recoverTick = 0;
		}
		gfloat leftChildX = clutter_actor_get_x(clutter_actor_get_child_at_index(bar, extendIndex));
		if(!EXCHANGE_FLAG //&& leftChildX == 0){
			&& floatClose(leftChildX, 0.0, 1.0)){
			ClutterActor *child = clutter_actor_get_child_at_index(bar, extendIndex);
			exchangeDistanceToLeft = clutter_actor_get_width(child) + CATEGORY_GAP;
			exchangeDistanceToRight = NORMAL_CATEGORY_WIDTH + CATEGORY_GAP;
			EXCHANGE_FLAG = true;
		}
		if(EXCHANGE_FLAG){
			exchangeDiffToLeft = 1.0;
			exchangeDiffToRight = 1.0;
			exchangeEffect();
			EXCHANGE_FLAG = false;
			exchangeTick = 0;
		}
		extendDiff = 1.0;
		extendEffect();
		EXTEND_FLAG = false;
		extendTick = 0;
		exchangeControlStep = 0;

		std::string tempName;
		tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, reduceIndex));	
		if(tempName.compare("featured") == 0)
		{
			CONTENT_LIVE_FLAG = false;
		}
		else
		{
			CONTENT_LIVE_FLAG = true;
		}

		if(isKeyControl){
			if(clutter_actor_get_n_children(bar) == 1)
			{
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
			}
			else if(clutter_actor_get_n_children(bar) >= 2)
			{
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
			}
		}else{
			if(clutter_actor_get_n_children(bar) == 1)
			{
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
			}
			else if(clutter_actor_get_n_children(bar) >= 2)
			{
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH/2;
			}
		}
		cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;
	}
	
	STOP_FLAG = true;	
	EVENT_FLAG = false;

	// FallContextMenu
	ContextMenu::Instance().fallContextMenu();

	clutter_actor_animate(bar, CLUTTER_EASE_IN_OUT_QUINT, 700, "y", SCENE_HEIGHT + 100, NULL);
	clutter_actor_animate(overlapShadow, CLUTTER_EASE_IN_OUT_QUINT, 700, "y", SCENE_HEIGHT + 100, NULL);
	clutter_actor_animate(globalCursor, CLUTTER_EASE_IN_OUT_QUINT, 700, "y", SCENE_HEIGHT + 100 - GLOBAL_CURSOR_XY_DIFF, NULL);
	clutter_timeline_stop(timeline); 
}

void FirstScreenListWidget::changeIcon(std::string categoryType, int contentsIndex, int number, ClutterActor *newIconParent)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDominant = NULL;
	ClutterActor *iconParent = NULL;
	
	ClutterColor zeroColor = {0, 0, 0, 0};
	
	gfloat iconParentWidth = 0.0f;
	gfloat iconParentHeight = 0.0f;
	
	std::string childName;
	
	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");
		
		return;
	}
	else if(clutter_actor_get_n_children(bar) == 1)
	{
		currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
		childName = clutter_actor_get_name(currentChild);
		
		if(categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");
			
			return;
		}
		
		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
		
		currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
		
		currentDominant = clutter_actor_get_child_at_index(currentDominant, DOMINANT_INDEX);
		
		if(number == 1)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, ICON1_INDEX);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, NORMAL_CONTENTS_WIDTH - ICON_RIGHT_GAP - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 255);
		}
		else if(number == 2)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, ICON2_INDEX);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, FOCUS_CONTENTS_WIDTH - ICON_GAP - ICON_RIGHT_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(newIconParent)) - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 0);
		}
		else
		{
			//printf("There is no such iconParent!!! Check number!!!");
		}
	}
	else
	{
		currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
		childName = clutter_actor_get_name(currentChild);
		
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);
			
			childName = clutter_actor_get_name(currentChild);
			
			if(categoryType.compare(childName) != 0)
			{
				//printf("There is no such category!!! Check id!!!\n");
				
				return;
			}			
		}
		
		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
		
		currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
		
		currentDominant = clutter_actor_get_child_at_index(currentDominant, DOMINANT_INDEX);
		
		if(number == 1)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, ICON1_INDEX);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, NORMAL_CONTENTS_WIDTH - ICON_RIGHT_GAP - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 255);
		}
		else if(number == 2)
		{
			iconParent = clutter_actor_get_child_at_index(currentDominant, ICON2_INDEX);
			
			clutter_actor_replace_child(currentDominant, iconParent, newIconParent);
			
			clutter_actor_get_size(newIconParent, &iconParentWidth, &iconParentHeight);
			clutter_actor_set_position(newIconParent, FOCUS_CONTENTS_WIDTH - ICON_GAP - ICON_RIGHT_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(newIconParent)) - iconParentWidth, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
			clutter_actor_set_background_color(newIconParent, &zeroColor);
			clutter_actor_set_opacity(newIconParent, 0);
		}
		else
		{
			//printf("There is no such iconParent!!! Check number!!!");
		}
	}
}

void FirstScreenListWidget::removeCategoryById(std::string id)
{
	FirstScreenCategory* category = NULL;

	map<std::string, FirstScreenCategory*>::iterator tagIt = categoryTagMap.find(id);
	if (tagIt == categoryTagMap.end())
	{
		return;
	}

	category = tagIt->second;
	categoryTagMap.erase(tagIt);

	ClutterActor *removeCategory = category->categoryWrapper;

	// remove from map
	map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(removeCategory);
	if (it != categoryActorMap.end())
	{
		categoryActorMap.erase(it);
	}

	clutter_actor_destroy_all_children(removeCategory);

	clutter_actor_remove_child(bar, removeCategory); 
	
	isOpen[0] = true;
	isOpen[1] = false;
}

void FirstScreenListWidget::removeContentsById(std::string id)
{
	ClutterActor *removeParent = NULL;
	ClutterActor *removeChild = NULL;
	ClutterActor *temp = NULL;
	
	map<std::string, FirstScreenContents*>::iterator it = contentsTagMap.find(id);
	if (it == contentsTagMap.end())
	{
		return;
	}

	FirstScreenContents* ctr = it->second;

	removeChild = ctr->contentsWrapper;
	removeParent = clutter_actor_get_parent(removeChild);

	contentsTagMap.erase(it);
	
	// remove from map
	map<ClutterActor*, FirstScreenContents*>::iterator actIt = itemMap.find(removeChild);
	if (actIt != itemMap.end())
	{
		itemMap.erase(actIt);
	}

	clutter_actor_remove_child(removeParent, removeChild);

	//if no contents, stop loop
	temp = clutter_actor_get_child_at_index(bar, extendIndex);
	temp = clutter_actor_get_child_at_index(temp, CATEGORY_LISTWRAPPER_INDEX);
	if(clutter_actor_get_n_children(removeParent) == 0
		&& removeParent == temp) //must be the extend category then stop the loop
	{
		NO_CONTENTS_FLAG = true;
	}
	else if(clutter_actor_get_n_children(removeParent) == 1
		&& removeParent == temp) //consider clear all case
	{
		cur_x = goal_x = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
		goal_position = SIDECATEGORY_GAP;
		setGlobalCursorPosition(SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP, 
				SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		setGlobalCursorSize(FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	}
}

static void toNomralCategory(int index, gfloat init_x)
{
	ClutterActor *temp = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	//barChild
	temp = clutter_actor_get_child_at_index(bar, index);

	clutter_actor_set_width(temp, NORMAL_CATEGORY_WIDTH);
	//lin89.zhang fix bug of category 0 float
	//clutter_actor_set_x(temp, init_x);

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp, CATEGORYTITLE_INDEX);

	clutter_actor_set_opacity(temp2, OPACITY_70);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp, CATEGORYWRAPPER_INDEX);

	clutter_actor_set_width(temp2, NORMAL_CATEGORY_WIDTH);

	//category live
	FirstScreenCategoryLiveControl::GetInstance()->SetOpacity(temp2, OPACITY_70);

	//lin89.zhang
	if (!SCALE_LEFT && !SCALE_RIGHT)
	    fixOverlapShadow();
}

static void toFocusContents(int categoryIndex, int contentsIndex, gfloat init_x,bool keyControlFlag = isKeyControl)
{
	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	gfloat normalOverlapOpcity;
	if(HIGH_CONTRAST_FLAG)
		normalOverlapOpcity = OPACITY_100;
	else
		normalOverlapOpcity = OPACITY_8;

	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, categoryIndex);

	//clutter_actor_set_x(temp, init_x);

	//global cursor
	//clutter_actor_set_opacity(globalCursor,0);
	if(isKeyControl){
		//clutter_actor_set_position(globalCursor,clutter_actor_get_x(bar) + clutter_actor_get_x(temp1)+init_x + NORMAL_CONTENTS_WIDTH*contentsIndex,SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		setGlobalCursorPosition(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1)+init_x + NORMAL_CONTENTS_WIDTH*contentsIndex,
								SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		//clutter_actor_set_size(globalCursor,FOCUS_CONTENTS_WIDTH,WIDGET_HEIGHT);
		setGlobalCursorSize(FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	}
	//clutter_actor_set_opacity(globalCursor,255);

	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
	temp1 = clutter_actor_get_child_at_index(temp1, contentsIndex);
    //begin junhui.wang
	if(keyControlFlag){
		clutter_actor_set_width(temp1, FOCUS_CONTENTS_WIDTH);
		clutter_actor_set_x(temp1, init_x + NORMAL_CONTENTS_WIDTH*contentsIndex);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);

		clutter_actor_set_width(temp2, FOCUS_CONTENTS_WIDTH);
		clutter_actor_set_opacity(temp2, OPACITY_100);
		clutter_actor_set_clip(temp2,0,0,FOCUS_CONTENTS_WIDTH,WIDGET_HEIGHT);
		clutter_actor_set_height(temp2,WIDGET_HEIGHT);

		//main
		temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);

		//clutter_actor_set_size(temp3, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		clutter_actor_set_scale(temp3, FOCUS_CONTENTS_WIDTH / NORMAL_CONTENTS_WIDTH, FOCUS_CONTENTS_WIDTH / NORMAL_CONTENTS_WIDTH);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);

		clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
		clutter_actor_set_y(temp3, WIDGET_HEIGHT);
		clutter_actor_set_opacity(temp3,0);
		
		//iconParent1
		temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);

		clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH - ICON_RIGHT_GAP - clutter_actor_get_width(temp3));

		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);

		clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH - ICON_GAP - ICON_RIGHT_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(temp3)) - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_scale(temp3, FOCUS_CONTENTS_WIDTH / NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT / CONTENTS_IMAGE_HEIGHT);
			clutter_actor_set_opacity(temp3, OPACITY_100);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, MAIN_INDEX), 0);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, FOCUSTITLE_INDEX);

		clutter_actor_set_y(temp2, WIDGET_HEIGHT);

		//title1
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);

		//clutter_actor_set_x(temp3, (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2);
		clutter_actor_set_opacity(temp3, 0);

		//title2
		temp3 = clutter_actor_get_child_at_index(temp2, 1);

		//clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
		//clutter_actor_set_x(temp3, (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2);
		clutter_actor_set_opacity(temp3, OPACITY_100);

		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		}
#if 0
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,FOCUS_CONTENTS_WIDTH);
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_width(temp2, FOCUS_CONTENTS_WIDTH);
			clutter_actor_set_y(temp2, WIDGET_HEIGHT - PROGRESS_HEIGHT);
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//progressC
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
	
			clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
			clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
		}
#endif
	}else{
		clutter_actor_set_width(temp1, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_x(temp1, init_x + NORMAL_CONTENTS_WIDTH*contentsIndex+(FOCUS_CONTENTS_WIDTH-NORMAL_CONTENTS_WIDTH)/2);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
		clutter_actor_set_width(temp2, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_opacity(temp2, OPACITY_100);
		clutter_actor_set_clip(temp2,0,0,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);
		clutter_actor_set_height(temp2,CONTENTS_IMAGE_HEIGHT);

		//main
		temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);
		clutter_actor_set_scale(temp3, 1.0, 1.0);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
		//clutter_actor_set_opacity(temp3,0);
		clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_y(temp3,CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_opacity(temp3,normalOverlapOpcity);

		//iconParent1
		temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);
		clutter_actor_set_x(temp3, NORMAL_CONTENTS_WIDTH - ICON_RIGHT_GAP - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
		
		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
		clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH - ICON_GAP - ICON_RIGHT_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(temp3)) - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 0);

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_scale(temp3, 1.0, 1.0);
			clutter_actor_set_opacity(temp3, OPACITY_100);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, MAIN_INDEX), 0);
		}

		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);
		clutter_actor_set_y(temp2, CONTENTS_IMAGE_HEIGHT);

		//title1
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		//clutter_actor_set_x(temp3, 0);
		clutter_actor_set_opacity(temp3, CONTENT_NORMAL_TITLE_OPACITY);

		//title2
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		//clutter_actor_set_x(temp3, (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2);
		clutter_actor_set_opacity(temp3, 0);

		//progressN
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
		}
#if 0
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,NORMAL_CONTENTS_WIDTH);
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_width(temp2, NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_y(temp2, WIDGET_HEIGHT - PROGRESS_HEIGHT);
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//progressC
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
	
			clutter_actor_set_width(temp3, NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(temp3, NORMAL_CONTENTS_WIDTH * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
		}
#endif
	}
	//end junhui.wang
}

static void foveaFeaturedOpen(gfloat diff)
{
	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transCategoryTitleWidth;
	gfloat transCategoryTitleX;
	gfloat transCategoryTitleOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;

	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalCategoryTitleWidth;
	gfloat transVerticalCategoryTitleX;
	gfloat transVerticalCategoryTitleOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;

	//begin junhui.wang
	gfloat transOverlapOpacity;
	gfloat transVerticalOverlapOpacity;
	//end junhui.wang

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	ClutterActor *showTemp = NULL;
	ClutterActor *hideTemp = NULL;

	int rightLimit = 0;
	int itemCount = 0;
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;
	
	if(CONTENT_LIVE_FLAG)
	{
		if(TICK_TO_ZERO)
		{
			contentLiveTick = 0;

			TICK_TO_ZERO = false;
		}

		APPS_FOCUSED = false;
		GAMES_FOCUSED = false;
		CONTENT_LIVE_FLAG = true;
	}

	////////////////////////////////category fovea//////////////////////////////////
	
	transVerticalWidth = NORMAL_CATEGORY_WIDTH - (NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalCategoryTitleOpacity = OPACITY_15 - (OPACITY_15 - OPACITY_70)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CATEGORY_WIDTH - 4) - ((NORMAL_CATEGORY_WIDTH - 4) - (FOCUS_CATEGORY_WIDTH - 4))*verticalDiff;

	transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CATEGORY_WIDTH)*diff;
	transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
	transCategoryTitleOpacity = transVerticalCategoryTitleOpacity - (transVerticalCategoryTitleOpacity - OPACITY_15)*diff;
	transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CATEGORY_WIDTH - 4))*diff;
	
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);
	clutter_actor_set_width(temp1, transWidth);

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);
	clutter_actor_set_opacity(temp2, transOpacity);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, CONTENTSWRAPPER_INDEX);
	clutter_actor_set_width(temp2, transWidth);

	//category live
	FirstScreenCategoryLiveControl::GetInstance()->SetOpacity(temp2, transOpacity);

	//global cursor
	if(isKeyControl)
	{
		gfloat cursorLeftPos = 0;
		gfloat cursorRightPos = NORMAL_CATEGORY_WIDTH + CATEGORY_GAP;
		gfloat cursorPos = cursorLeftPos - (cursorLeftPos - cursorRightPos)*diff;
		gfloat cursorWidth = FOCUS_CATEGORY_WIDTH - (FOCUS_CATEGORY_WIDTH - FOCUS_CONTENTS_WIDTH)* diff;

		if(AD_CURSOR_FLAG)
		{
			//clutter_actor_set_x(globalCursor,SIDECATEGORY_GAP*2+NORMAL_CATEGORY_WIDTH);
			//setGlobalCursorX(SIDECATEGORY_GAP*2+NORMAL_CATEGORY_WIDTH);
			//clutter_actor_set_width(globalCursor,NORMAL_CONTENTS_WIDTH);
			//setGlobalCursorWidth(NORMAL_CONTENTS_WIDTH);
		}
		else
		{
			//clutter_actor_set_x(globalCursor,clutter_actor_get_x(bar) + cursorPos);
			//setGlobalCursorX(clutter_actor_get_x(bar) + cursorPos);
			//clutter_actor_set_width(globalCursor,cursorWidth);
			//setGlobalCursorWidth(cursorWidth);
		}
	}
	//end junhui.wang

	////////////////////////////////contents fovea//////////////////////////////////
		
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, extendIndex);


	// shuhao.yan 1212
	if (FirstScreenADControl::GetInstance()->IsEnable() && CLIPFLAG)
	{
		
		gfloat ad_diff = 0;
		if (diff <=  0.5)
		{
			ad_diff = 2 * diff;
		}
		else
		{
			ad_diff = 2 * (1 - diff);
		}
		
		gfloat transVerticalPosition = (NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - (NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP + EXTENDGAP)) * verticalDiff;
		gfloat transVerticalPositionCate = (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + EXTENDGAP * 2)) * verticalDiff;
		
		gfloat transPosition = (NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - transVerticalPosition) * ad_diff;
		gfloat transPositionCate = (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - transVerticalPositionCate) * ad_diff;
		
		//ClutterActor* ADActor = clutter_actor_get_child_at_index(bar, 2);
		//clutter_actor_set_x(ADActor, transPosition);
		FirstScreenADControl::GetInstance()->SetX(transPosition);
		clutter_actor_set_x(temp1, transPositionCate);
		
		
		if (diff < 0.5)
		{
			diff = 0;
		}
		else
		{
			diff = 1 - ad_diff;
		}
	}
	else
	{
		clutter_actor_set_x(temp1, transWidth + CATEGORY_GAP);
	}
	

	transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
	transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

	transWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - transVerticalWidth)*diff;
	transHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - transVerticalHeight)*diff;
	transHeight = Rounding(transHeight,0);
	transOpacity = OPACITY_70 - (OPACITY_70 - transVerticalOpacity)*diff;
	transContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - transVerticalContentsTitleWidth)*diff;
	transBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - transVerticalBorderWidth)*diff;
	transNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - transVerticalNormalTitlePos)*diff;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;

	//begin junhui.wang	
	gfloat normalOverlapOpcity;
	if(HIGH_CONTRAST_FLAG)
		normalOverlapOpcity = OPACITY_100;
	else
		normalOverlapOpcity = OPACITY_8;
	transVerticalOverlapOpacity = normalOverlapOpcity - (normalOverlapOpcity - 0)*verticalDiff;	
	transOverlapOpacity = transVerticalOverlapOpacity - (transVerticalOverlapOpacity - normalOverlapOpcity)*(1-diff);	
	//end junhui.wang
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*(1 - 2*diff))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*2*(diff - 0.5)*transVerticalDiff;
		}
	}

	itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX));

	clutter_actor_set_width(temp1, transWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);
	
	/*startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + clutter_actor_get_width(temp1);
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
	
	clutter_actor_set_x(temp2, title_x);
	
	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);

	if(startPoint < EXTEND_CATEGORY_TITLE_X)
	{
		startPoint = EXTEND_CATEGORY_TITLE_X;
	}

	title_x = startPoint - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);

	clutter_actor_set_x(temp2, title_x);
	*/
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
	temp1 = clutter_actor_get_child_at_index(temp1, 0);
	
	//clutter_actor_show_all(temp1);

	//begin junhui.wang
	if(isKeyControl){
		clutter_actor_set_width(temp1, transWidth);
		clutter_actor_set_x(temp1, 0);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);

		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_clip(temp2,0,0,transWidth,WIDGET_HEIGHT);
		//clutter_actor_set_height(temp2,transHeight);

		//main
		temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);

		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_y(temp3, transHeight);
		if(diff == 1.0)
			clutter_actor_set_opacity(temp3,0);
		else
			clutter_actor_set_opacity(temp3,normalOverlapOpcity);

		//iconParent1
		temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);
		transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);
		clutter_actor_set_x(temp3, transIconPosition);

		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
		if(diff == 1.0f)
		{
			clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
			clutter_actor_set_opacity(temp3, 255);
		}
		else
		{
			clutter_actor_set_opacity(temp3, 0);
		}

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_scale(temp3, transScaleX, transScaleY);
			clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

		clutter_actor_set_y(temp2, transHeight);

		//title1 (normal)
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		//clutter_actor_set_x(temp3, transNormalTitlePos);
		clutter_actor_set_opacity(temp3, transNormalTitleOpt);

		//title2 (focus)
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
		transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
		transFocusTitlePos = contentsTitle_x - (contentsTitle_x - transVerticalFocusTitlePos)*diff;
		//clutter_actor_set_x(temp3, transFocusTitlePos);
		clutter_actor_set_opacity(temp3, transFocusTitleOpt);
		
		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, transWidth, transHeight);
		}
#if 0
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,transWidth);
		
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_width(temp2, transWidth);
			clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//progressC
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
		
			clutter_actor_set_width(temp3, transWidth);
			clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
		}

		// options
		int itemCounts = clutter_actor_get_n_children(temp1);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
		}
#endif
		////////////////////////////////right contents//////////////////////////////////
		temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);

		for(int i = 0; i < itemCount; i++)
		{
			temp3 = clutter_actor_get_child_at_index(temp2, i);

			if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
			{
				rightLimit = i;
			
				break;
			}

			if(i == itemCount - 1)
			{
				rightLimit = itemCount - 1;
			}
		}

		temp3 = clutter_actor_get_child_at_index(temp2, 0);

		for(int i = 1; i <= rightLimit + 1; i++)
		{
			if(i > itemCount - 1) 
			{
				return;
			}

			showTemp = clutter_actor_get_child_at_index(temp2, i);
			
			//clutter_actor_show_all(showTemp);

			toNormalContents(1, i, clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) - NORMAL_CONTENTS_WIDTH);
		}
		
		for(int i = rightLimit + 1; i < itemCount; i++)
		{
			if(i >= itemCount) 
			{
				return;
			}
			
			hideTemp = clutter_actor_get_child_at_index(temp2, i);
			
			//clutter_actor_hide_all(hideTemp);
		}
	
	}else{
		clutter_actor_set_width(temp1,NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_x(temp1,(transWidth-NORMAL_CONTENTS_WIDTH)/2);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
		clutter_actor_set_clip(temp2,0,0,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);
		clutter_actor_set_height(temp2,WIDGET_HEIGHT);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
		clutter_actor_set_y(temp3,CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_opacity(temp3,normalOverlapOpcity);

		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
		if(diff == 1.0f)
		{
			clutter_actor_set_opacity(temp3, 255);
		}
		else
		{
			clutter_actor_set_opacity(temp3, 0);
		}

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

		//title1 (normal)
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		clutter_actor_set_opacity(temp3, 255);

		//title2 (focus)
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		clutter_actor_set_opacity(temp3, 0);
		
		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, NORMAL_CONTENTS_WIDTH, transHeight);
		}
#if 0	
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,NORMAL_CONTENTS_WIDTH);
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_opacity(temp2, OPACITY_100);
		}

		// options
		int itemCounts = clutter_actor_get_n_children(temp1);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
		}
#endif

		////////////////////////////////right contents//////////////////////////////////
		temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		for(int i = 0; i < itemCount; i++)
		{
			temp3 = clutter_actor_get_child_at_index(temp2, i);

			if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
			{
				rightLimit = i;		
				break;
			}

			if(i == itemCount - 1)
			{
				rightLimit = itemCount - 1;
			}
		}
		temp3 = clutter_actor_get_child_at_index(temp2, CONTENTSWRAPPER_INDEX);
		for(int i = 1; i <= rightLimit + 1; i++)
		{
			if(i > itemCount - 1) 
			{
				return;
			}
			
			showTemp = clutter_actor_get_child_at_index(temp2, i);
			
			//clutter_actor_show_all(showTemp);
			
			toNormalContents(1, i, clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) + ((transWidth-NORMAL_CONTENTS_WIDTH)/2) - NORMAL_CONTENTS_WIDTH);
		}
		
		for(int i = rightLimit + 1; i < itemCount; i++)
		{
			if(i >= itemCount) 
			{
				return;
			}

			hideTemp = clutter_actor_get_child_at_index(temp2, i);
			
			//clutter_actor_hide_all(hideTemp);
		}
	}
	//end junhui.wang

	
}


static void foveaFeaturedOpenEx(gfloat diff, int contentIndex = 0)
{
	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transCategoryTitleWidth;
	gfloat transCategoryTitleX;
	gfloat transCategoryTitleOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;

	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalCategoryTitleWidth;
	gfloat transVerticalCategoryTitleX;
	gfloat transVerticalCategoryTitleOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;

	//begin junhui.wang
	gfloat transOverlapOpacity;
	gfloat transVerticalOverlapOpacity;
	//end junhui.wang

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	ClutterActor *showTemp = NULL;
	ClutterActor *hideTemp = NULL;

	int rightLimit = 0;
	int itemCount = 0;
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;
	
	if(CONTENT_LIVE_FLAG)
	{
		if(TICK_TO_ZERO)
		{
			contentLiveTick = 0;

			TICK_TO_ZERO = false;
		}

		APPS_FOCUSED = false;
		GAMES_FOCUSED = false;
		CONTENT_LIVE_FLAG = true;
	}

	////////////////////////////////category fovea//////////////////////////////////
	
	transVerticalWidth = NORMAL_CATEGORY_WIDTH - (NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalCategoryTitleOpacity = OPACITY_15 - (OPACITY_15 - OPACITY_70)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CATEGORY_WIDTH - 4) - ((NORMAL_CATEGORY_WIDTH - 4) - (FOCUS_CATEGORY_WIDTH - 4))*verticalDiff;

	transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CATEGORY_WIDTH)*diff;
	transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
	transCategoryTitleOpacity = transVerticalCategoryTitleOpacity - (transVerticalCategoryTitleOpacity - OPACITY_15)*diff;
	transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CATEGORY_WIDTH - 4))*diff;
	
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);
	clutter_actor_set_width(temp1, transWidth);

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);
	clutter_actor_set_opacity(temp2, transOpacity);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, CONTENTSWRAPPER_INDEX);
	clutter_actor_set_width(temp2, transWidth);

	//category live
	FirstScreenCategoryLiveControl::GetInstance()->SetOpacity(temp2, transOpacity);

	////////////////////////////////contents fovea//////////////////////////////////
		
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, extendIndex);


	// shuhao.yan 1212
	if (FirstScreenADControl::GetInstance()->IsEnable() && CLIPFLAG)
	{
		
		gfloat ad_diff = 0;
		if (diff <=  0.5)
		{
			ad_diff = 2 * diff;
		}
		else
		{
			ad_diff = 2 * (1 - diff);
		}
		
		gfloat transVerticalPosition = (NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - (NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP + EXTENDGAP)) * verticalDiff;
		gfloat transVerticalPositionCate = (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + EXTENDGAP * 2)) * verticalDiff;
		
		gfloat transPosition = (NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP) - transVerticalPosition) * ad_diff;
		gfloat transPositionCate = (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - ((NORMAL_CATEGORY_WIDTH + CATEGORY_GAP) - transVerticalPositionCate) * ad_diff;
		
		//ClutterActor* ADActor = clutter_actor_get_child_at_index(bar, 2);
		//clutter_actor_set_x(ADActor, transPosition);
		FirstScreenADControl::GetInstance()->SetX(transPosition);
		clutter_actor_set_x(temp1, transPositionCate);
		
		if (diff < 0.5)
		{
			diff = 0;
		}
		else
		{
			diff = 1 - ad_diff;
		}
	}
	else
	{
		clutter_actor_set_x(temp1, transWidth + CATEGORY_GAP);
	}
	

	transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
	transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

	transWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - transVerticalWidth)*diff;
	transHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - transVerticalHeight)*diff;
	transHeight = Rounding(transHeight,0);
	transOpacity = OPACITY_70 - (OPACITY_70 - transVerticalOpacity)*diff;
	transContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - transVerticalContentsTitleWidth)*diff;
	transBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - transVerticalBorderWidth)*diff;
	transNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - transVerticalNormalTitlePos)*diff;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;

	//begin junhui.wang	
	gfloat normalOverlapOpcity;
	if(HIGH_CONTRAST_FLAG)
		normalOverlapOpcity = OPACITY_100;
	else
		normalOverlapOpcity = OPACITY_8;
	transVerticalOverlapOpacity = normalOverlapOpcity - (normalOverlapOpcity - 0)*verticalDiff;	
	transOverlapOpacity = transVerticalOverlapOpacity - (transVerticalOverlapOpacity - normalOverlapOpcity)*(1-diff);	
	//end junhui.wang
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*(1 - 2*diff))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*2*(diff - 0.5)*transVerticalDiff;
		}
	}

	itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX));

	clutter_actor_set_width(temp1, transWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
	temp1 = clutter_actor_get_child_at_index(temp1, contentIndex);
	
	//clutter_actor_show_all(temp1);

	//begin junhui.wang
	if(isKeyControl){
		clutter_actor_set_width(temp1, transWidth);
		clutter_actor_set_x(temp1, 0);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);

		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_clip(temp2,0,0,transWidth,WIDGET_HEIGHT);
		//clutter_actor_set_height(temp2,transHeight);

		//main
		temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);

		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_y(temp3, transHeight);
		if(diff == 1.0)
			clutter_actor_set_opacity(temp3,0);
		else
			clutter_actor_set_opacity(temp3,normalOverlapOpcity);

		//iconParent1
		temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);
		transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);
		clutter_actor_set_x(temp3, transIconPosition);

		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
		if(diff == 1.0f)
		{
			clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
			clutter_actor_set_opacity(temp3, 255);
		}
		else
		{
			clutter_actor_set_opacity(temp3, 0);
		}

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_scale(temp3, transScaleX, transScaleY);
			clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

		clutter_actor_set_y(temp2, transHeight);

		//title1 (normal)
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		//clutter_actor_set_x(temp3, transNormalTitlePos);
		clutter_actor_set_opacity(temp3, transNormalTitleOpt);

		//title2 (focus)
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
		transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
		transFocusTitlePos = contentsTitle_x - (contentsTitle_x - transVerticalFocusTitlePos)*diff;
		//clutter_actor_set_x(temp3, transFocusTitlePos);
		clutter_actor_set_opacity(temp3, transFocusTitleOpt);
		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, transWidth, transHeight);
		}
#if 0		
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,transWidth);
		
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_width(temp2, transWidth);
			clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//progressC
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
		
			clutter_actor_set_width(temp3, transWidth);
			clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
		}

		// options
		int itemCounts = clutter_actor_get_n_children(temp1);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
		}
#endif

#if 0
		////////////////////////////////right contents//////////////////////////////////
		temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);

		for(int i = 0; i < itemCount; i++)
		{
			temp3 = clutter_actor_get_child_at_index(temp2, i);

			if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
			{
				rightLimit = i;
			
				break;
			}

			if(i == itemCount - 1)
			{
				rightLimit = itemCount - 1;
			}
		}

		temp3 = clutter_actor_get_child_at_index(temp2, 0);

		for(int i = 1; i <= rightLimit + 1; i++)
		{
			if(i > itemCount - 1) 
			{
				return;
			}

			showTemp = clutter_actor_get_child_at_index(temp2, i);
			
			clutter_actor_show_all(showTemp);

			toNormalContents(1, i, clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) - NORMAL_CONTENTS_WIDTH);
		}
		
		for(int i = rightLimit + 1; i < itemCount; i++)
		{
			if(i >= itemCount) 
			{
				return;
			}
			
			hideTemp = clutter_actor_get_child_at_index(temp2, i);
			
			clutter_actor_hide_all(hideTemp);
		}
#endif
	}
	else
	{
		clutter_actor_set_width(temp1,NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_x(temp1,(transWidth-NORMAL_CONTENTS_WIDTH)/2);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
		clutter_actor_set_clip(temp2,0,0,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);
		clutter_actor_set_height(temp2,WIDGET_HEIGHT);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
		clutter_actor_set_y(temp3,CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_opacity(temp3,normalOverlapOpcity);

		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
		if(diff == 1.0f)
		{
			clutter_actor_set_opacity(temp3, 255);
		}
		else
		{
			clutter_actor_set_opacity(temp3, 0);
		}

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

		//title1 (normal)
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		clutter_actor_set_opacity(temp3, 255);

		//title2 (focus)
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		clutter_actor_set_opacity(temp3, 0);

		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, NORMAL_CONTENTS_WIDTH, transHeight);
		}
#if 0
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,NORMAL_CONTENTS_WIDTH);

		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_opacity(temp2, OPACITY_100);
		}

		// options
		int itemCounts = clutter_actor_get_n_children(temp1);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
		}
#endif

#if 0
		////////////////////////////////right contents//////////////////////////////////
		temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		for(int i = 0; i < itemCount; i++)
		{
			temp3 = clutter_actor_get_child_at_index(temp2, i);

			if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
			{
				rightLimit = i;		
				break;
			}

			if(i == itemCount - 1)
			{
				rightLimit = itemCount - 1;
			}
		}
		temp3 = clutter_actor_get_child_at_index(temp2, CONTENTSWRAPPER_INDEX);
		for(int i = 1; i <= rightLimit + 1; i++)
		{
			if(i > itemCount - 1) 
			{
				return;
			}
			
			showTemp = clutter_actor_get_child_at_index(temp2, i);
			
			clutter_actor_show_all(showTemp);
			
			toNormalContents(1, i, clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) + ((transWidth-NORMAL_CONTENTS_WIDTH)/2) - NORMAL_CONTENTS_WIDTH);
		}
		
		for(int i = rightLimit + 1; i < itemCount; i++)
		{
			if(i >= itemCount) 
			{
				return;
			}

			hideTemp = clutter_actor_get_child_at_index(temp2, i);
			
			clutter_actor_hide_all(hideTemp);
		}
#endif
	}
}


static void foveaHistoryOpen(gfloat diff)
{
#if 0
	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transCategoryTitleWidth;
	gfloat transCategoryTitleX;
	gfloat transCategoryTitleOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;

	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalCategoryTitleWidth;
	gfloat transVerticalCategoryTitleX;
	gfloat transVerticalCategoryTitleOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;

	int leftLimit = 0;
	int itemCount = 0;
	
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;
	
	if(CONTENT_LIVE_FLAG)
	{
		if(TICK_TO_ZERO)
		{
			contentLiveTick = 0;

			TICK_TO_ZERO = false;
		}

		APPS_FOCUSED = false;
		GAMES_FOCUSED = false;
		CONTENT_LIVE_FLAG = true;
	}
	
	////////////////////////////////contents fovea//////////////////////////////////

	transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
	transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

	transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CONTENTS_WIDTH)*diff;
	transHeight = transVerticalHeight - (transVerticalHeight - CONTENTS_IMAGE_HEIGHT)*diff;
	transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
	transContentsTitleWidth = transVerticalContentsTitleWidth - (transVerticalContentsTitleWidth - NORMAL_CONTENTS_TITLE_WIDTH)*diff;
	transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CONTENTS_WIDTH - 4))*diff;
	transNormalTitlePos = transVerticalNormalTitlePos - (transVerticalNormalTitlePos - CONTENTS_TITLE_X)*diff;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*(1 - 2*diff)*transVerticalDiff;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*2*(diff - 0.5))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);

	itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(temp1, 2));

	//[Begin]fixed scroll debug[lin89.zhang]
	//clutter_actor_set_x(temp1, 0);
	//[End]fixed scroll debug[lin89.zhang]
	clutter_actor_set_width(temp1, transWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));
	
	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	
	/*startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + clutter_actor_get_width(temp1);
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
	
	clutter_actor_set_x(temp2, title_x);*/
	
	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);

	if(startPoint < EXTEND_CATEGORY_TITLE_X)
	{
		startPoint = EXTEND_CATEGORY_TITLE_X;
	}

	title_x = startPoint - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);

	clutter_actor_set_x(temp2, title_x);
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, 2);
	temp1 = clutter_actor_get_child_at_index(temp1, itemCount - 1);

	clutter_actor_set_width(temp1, transWidth);
	clutter_actor_set_x(temp1, NORMAL_CONTENTS_WIDTH*(itemCount - 1));

	//dominant
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);
	//clutter_actor_set_opacity(temp2, transOpacity);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_size(temp3, transWidth, transHeight);
	clutter_actor_set_scale(temp3, transScaleX, transScaleY);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_width(temp3, transWidth);
	//clutter_actor_set_y(temp3, transHeight);
	
	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 3);

	transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);

	clutter_actor_set_x(temp3, transIconPosition);

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 4);

	if(diff == 0.0f)
	{
		clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
	}
	else
	{
		clutter_actor_set_opacity(temp3, 0);
	}
	
	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);
		clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*verticalDiff);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*diff)*verticalDiff);
	}

	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp1, 1);

	clutter_actor_set_y(temp2, transHeight);

	//title1 (normal)
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	//clutter_actor_set_width(temp3, transContentsTitleWidth);
	clutter_actor_set_x(temp3, transNormalTitlePos);
	clutter_actor_set_opacity(temp3, transNormalTitleOpt);

	//title2 (focus)
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
	
	transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
	transFocusTitlePos = transVerticalFocusTitlePos - (transVerticalFocusTitlePos - contentsTitle_x)*diff;
	
	//clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_x(temp3, transFocusTitlePos);
	clutter_actor_set_opacity(temp3, transFocusTitleOpt);

	/*
	//border
	temp2 = clutter_actor_get_child_at_index(temp1, 2);
	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_opacity(temp2, OPACITY_100*(1 - diff)*verticalDiff);
	*/
	
	//progressN
	temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	gfloat progress = clutter_actor_get_x(temp3);

	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, 0);
	
		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}

	// options
	int itemCounts = clutter_actor_get_n_children(temp1);
	if (itemCounts > CONTENT_OPTION_INDEX)
	{
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_opacity(temp2, transFocusTitleOpt);
	}

	////////////////////////////////left contents//////////////////////////////////

	for(int i = itemCount - 2; i >= 0; i--)
	{
		if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) - NORMAL_CONTENTS_WIDTH*(itemCount - 1 - i) <= 0 )
		{
			leftLimit = i;

			break;
		}

		if(i == 0)
		{
			leftLimit = 0;
		}
	}

	for(int i = leftLimit; i < itemCount - 1; i++)
	{
		toNormalContents(0, i, 0);
	}

	////////////////////////////////category fovea//////////////////////////////////
	
	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, extendIndex);

	clutter_actor_set_x(temp1, clutter_actor_get_width(clutter_actor_get_child_at_index(bar, reduceIndex)) + CATEGORY_GAP);

	transVerticalWidth = NORMAL_CATEGORY_WIDTH - (NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	//transVerticalCategoryTitleWidth = NORMAL_CATEGORY_TITLE_WIDTH - (NORMAL_CATEGORY_TITLE_WIDTH - FOCUS_CATEGORY_TITLE_WIDTH)*verticalDiff;
	transVerticalCategoryTitleOpacity = OPACITY_15 - (OPACITY_15 - OPACITY_70)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CATEGORY_WIDTH - 4) - ((NORMAL_CATEGORY_WIDTH - 4) - (FOCUS_CATEGORY_WIDTH - 4))*verticalDiff;

	transWidth = NORMAL_CATEGORY_WIDTH - (NORMAL_CATEGORY_WIDTH - transVerticalWidth)*diff;
	transOpacity = OPACITY_70 - (OPACITY_70 - transVerticalOpacity)*diff;
	//transCategoryTitleWidth = NORMAL_CATEGORY_TITLE_WIDTH - (NORMAL_CATEGORY_TITLE_WIDTH - transVerticalCategoryTitleWidth)*diff;
	transCategoryTitleOpacity = OPACITY_15 - (OPACITY_15 - transVerticalCategoryTitleOpacity)*diff;
	transBorderWidth = (NORMAL_CATEGORY_WIDTH - 4) - ((NORMAL_CATEGORY_WIDTH - 4) - transVerticalBorderWidth)*diff;

	clutter_actor_set_width(temp1, transWidth);

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	
	/*gfloat normalX = (NORMAL_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2;
	gfloat focusX = (FOCUS_CATEGORY_WIDTH - clutter_actor_get_width(temp2))/2;

	transVerticalCategoryTitleX = normalX - (normalX - focusX)*verticalDiff;
	transCategoryTitleX = normalX - (normalX - transVerticalCategoryTitleX)*diff;
	
	clutter_actor_set_x(temp2, transCategoryTitleX);*/
	clutter_actor_set_opacity(temp2, transOpacity);

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, 0);

	clutter_actor_set_width(temp2, transWidth);

	//color
	temp3 = clutter_actor_get_child_at_index(temp2, 0);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_opacity(temp3, transCategoryTitleOpacity);

	//liveParent1
	temp3 = clutter_actor_get_child_at_index(temp2, 1);

	clutter_actor_set_opacity(temp3, transOpacity);

	//liveParent2
	temp3 = clutter_actor_get_child_at_index(temp2, 2);

	clutter_actor_set_opacity(temp3, transOpacity);
#endif
}

static void cal_display_performance()
{
	int leftLimit = 0;
	int rightLimit = 0;
	ClutterActor* extendCat = clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor* extendList = clutter_actor_get_child_at_index(extendCat, CATEGORY_LISTWRAPPER_INDEX);
	int itemCount = clutter_actor_get_n_children(extendList);
	ClutterActor* content = NULL;
	gfloat bar_x = clutter_actor_get_x(bar);
	gfloat extendCat_x_real = clutter_actor_get_x(extendCat) + bar_x;
	gfloat extendCat_w_real = clutter_actor_get_width(extendCat) + extendCat_x_real;
	
	//find left limit
	for(int i = 0; i < itemCount; i++)
	{
		content = clutter_actor_get_child_at_index(extendList, i);
		if(extendCat_x_real + i*NORMAL_CONTENTS_WIDTH > FOCUS_CATEGORY_WIDTH)
		{
			break;
		}
		leftLimit = i;
	}

	//find right limit
	for(int i = itemCount - 1; i >= 0; i--)
	{
		rightLimit = i;
		content = clutter_actor_get_child_at_index(extendList, i);
		if(extendCat_w_real - (itemCount-i)*NORMAL_CONTENTS_WIDTH < SCENE_WIDTH)
		{
			break;
		}
	}
	//printf("leftLimit = %d\n", leftLimit);

	//hide
	if(leftLimit > 0)
	{
		for(int i = 0; i < leftLimit; i++)
		{
			content = clutter_actor_get_child_at_index(extendList, i);
			clutter_actor_hide_all(content);
		}
	}

	if(rightLimit < itemCount - 1)
	{
		for(int i = itemCount - 1; i > rightLimit; i--)
		{
			content = clutter_actor_get_child_at_index(extendList, i);
			clutter_actor_hide_all(content);
		}
	}

	//show
	for(int i = leftLimit; i <= rightLimit; i++)
	{
		content = clutter_actor_get_child_at_index(extendList, i);
		clutter_actor_show_all(content);
	}
}

gfloat preVerticalDiff = 0.0;

static void foveaContents(gfloat diff, int index)
{		
	//adjust for scroll right
	verticalDiff = verticalDiff * scrollVerticalDiffRatio;


	//performance test for scroll
#if 0
	if(preVerticalDiff == 0.0 && verticalDiff == 0.0 && (SCROLL_RIGHT))
	{
		cal_scroll_performance(index);
		return;
	}
	preVerticalDiff = verticalDiff;
#endif

	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;
	
	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;

	//begin junhui.wang
	gfloat transOverlapOpacity;
	gfloat transVerticalOverlapOpacity;
	//end junhui.wang
	
	gfloat x, y;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	ClutterActor *tempChild = NULL;
	ClutterActor *tempList = NULL;
	ClutterActor *showTemp = NULL;
	ClutterActor *hideTemp = NULL;

	int leftLimit = 0;
	int rightLimit = 0;
	int itemCount = 0;
	int tempIndex = 0;
	
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;
	
	if(CONTENT_LIVE_FLAG)
	{
		if(index == 1)
		{
			if(!APPS_FOCUSED && contentLiveTick < 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
			{
				contentLiveTick = 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]);

				TICK_TO_ZERO = true;
			}

			APPS_FOCUSED = true;
			GAMES_FOCUSED = false;
			CONTENT_LIVE_FLAG = true;

			if(appLive[2] != NULL)
			{
				clutter_actor_set_scale(appLive[0], 1.0, 1.0);
				clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH);
				clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);	
			}
		}
		else if(index == 2)
		{
			if(APPS_FOCUSED)
			{
				contentLiveTick = 0;
			}

			APPS_FOCUSED = false;
			GAMES_FOCUSED = true;
			CONTENT_LIVE_FLAG = true;
#if 0
			if(appLive[2] != NULL)
			{
				clutter_actor_set_scale(appLive[0], 1.0, 1.0);
				clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH);
				clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);	
			}
#endif
			if(gameLive[2] != NULL)
			{
				clutter_actor_set_scale(gameLive[0], 1.0, 1.0);
				clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH);
				clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);
			}
		}
#if 0
		else if(index == 3)
		{
			if(!GAMES_FOCUSED && contentLiveTick >= 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
			{
				contentLiveTick = 0;
			}

			APPS_FOCUSED = false;
			GAMES_FOCUSED = false;
			CONTENT_LIVE_FLAG = true;

			if(gameLive[2] != NULL)
			{
				clutter_actor_set_scale(gameLive[0], 1.0, 1.0);
				clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH);
				clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);	
			}
		}
#endif
		else
		{
			APPS_FOCUSED = false;
			GAMES_FOCUSED = false;
			CONTENT_LIVE_FLAG = true;
		}
	}

	////////////////////////////////left contents fovea//////////////////////////////////

	//barChild
		
	if(currentCategory == 1)	//���ʿ� ī�װ����� �ִ� ���
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		tempIndex = 1;
	
		itemCount = clutter_actor_get_n_children(temp2);

		clutter_actor_set_x(temp1, NORMAL_CATEGORY_WIDTH + CATEGORY_GAP);

		//[Begin]fixed scroll debug[lin89.zhang]
		//if(isMOVE_TO_END)
		//{
			toNomralCategory(0, 0);
		//	isMOVE_TO_END = false;
		//}
		//[End]fixed scroll debug[lin89.zhang]
	}
	else	//�����ʿ� ī�װ����� �ְų� ī�װ����� �ϳ��� ���
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		tempIndex = 0;
	
		itemCount = clutter_actor_get_n_children(temp2);

		//[Begin]fixed scroll debug[lin89.zhang]
		//clutter_actor_set_x(temp1, 0);
		//[End]fixed scroll debug[lin89.zhang]

		if(clutter_actor_get_n_children(bar) >= 2)
		{
			toNomralCategory(1, clutter_actor_get_width(temp1) + CATEGORY_GAP);
		}
	}
#if 0
	if(REMOVE_CONTENTS_FLAG)
	{
		//global cursor
		gfloat cursorLeftPos = clutter_actor_get_x(tempChild) + NORMAL_CONTENTS_WIDTH*(index -1);
		gfloat cursorRightPos = clutter_actor_get_x(tempChild) + NORMAL_CONTENTS_WIDTH*index;
		gfloat cursorPos = cursorLeftPos - (cursorLeftPos - cursorRightPos)*diff;
		gfloat cursorWidth = 0.0;
		if(currentContents == 0)
		{	
			//junhui.wang caodan fix bug
			cursorWidth = globalCursorWidth - (globalCursorWidth - FOCUS_CONTENTS_WIDTH)*(1-diff);
		}
		else
		{
			cursorWidth = globalCursorWidth - (globalCursorWidth - FOCUS_CONTENTS_WIDTH)*diff;
		}
		
		if(isKeyControl){
			if(index >= itemCount){
				//clutter_actor_set_x(globalCursor,clutter_actor_get_x(bar)+cursorLeftPos);
				setGlobalCursorX(clutter_actor_get_x(bar)+cursorLeftPos);
				//clutter_actor_set_width(globalCursor,FOCUS_CONTENTS_WIDTH);
				setGlobalCursorWidth(FOCUS_CONTENTS_WIDTH);
			}
			else{
				//clutter_actor_set_x(globalCursor,clutter_actor_get_x(bar)+cursorPos);
				setGlobalCursorX(clutter_actor_get_x(bar)+cursorPos);
				//clutter_actor_set_width(globalCursor,cursorWidth);
				//printf("foveaContents cursorWidth = %f\n", cursorWidth);
				setGlobalCursorWidth(cursorWidth);
			}
		}
		REMOVE_CONTENTS_FLAG = false;
	}
#endif
	////////////////////////////////left contents//////////////////////////////////
	
	temp3 = clutter_actor_get_child_at_index(temp2, index - 1);

	//for(int i = index - 2; i >= 0; i--)
	for(int i = index - 1; i >= 0; i--)
	{
		//if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) - NORMAL_CONTENTS_WIDTH*(index - 1 - i) <= 0)
		if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) - NORMAL_CONTENTS_WIDTH*(index - 1 - i) <= FOCUS_CATEGORY_WIDTH)
		{
			leftLimit = i;

			break;
		}

		if(i == 0)
		{
			leftLimit = 0;
		}
	}

	for(int i = leftLimit; i <= index - 1; i++)
	{
		showTemp = clutter_actor_get_child_at_index(tempList, i);
		
		//clutter_actor_show_all(showTemp);
		
		toNormalContents(tempIndex, i, 0);
	}
	
	for(int i = 0; i < leftLimit; i++)
	{
		hideTemp = clutter_actor_get_child_at_index(tempList, i);
		
		//clutter_actor_hide_all(hideTemp);
	}

	transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
	transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
	transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
	transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
	transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

	transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CONTENTS_WIDTH)*diff;
	transHeight = transVerticalHeight - (transVerticalHeight - CONTENTS_IMAGE_HEIGHT)*diff;
	transHeight = Rounding(transHeight,0);
	transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
	transContentsTitleWidth = transVerticalContentsTitleWidth - (transVerticalContentsTitleWidth - NORMAL_CONTENTS_TITLE_WIDTH)*diff;
	transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CONTENTS_WIDTH - 4))*diff;
	transNormalTitlePos = transVerticalNormalTitlePos - (transVerticalNormalTitlePos - CONTENTS_TITLE_X)*diff;
	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;

	//begin junhui.wang	
	gfloat normalOverlapOpcity;
	if(HIGH_CONTRAST_FLAG)
		normalOverlapOpcity = OPACITY_100;
	else
		normalOverlapOpcity = OPACITY_8;
	//if(verticalDiff < 1.0){
	transVerticalOverlapOpacity = normalOverlapOpcity - (normalOverlapOpcity - 0)*verticalDiff;	
	transOverlapOpacity = transVerticalOverlapOpacity - (transVerticalOverlapOpacity - normalOverlapOpcity)*diff;	
	//}
	//end junhui.wang
	
	if(verticalDiff <= 0.5)
	{
		transVerticalDiff = 1 - 2*verticalDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(verticalDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*(1 - 2*diff)*transVerticalDiff;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*2*(diff - 0.5))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	
	clutter_actor_set_width(temp1, transVerticalWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));

#if 0
	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	
	/*startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
	endPoint = startPoint + clutter_actor_get_width(temp1);
	
	if(startPoint < 0.0f)
	{
		startPoint = 0.0f;
	}
	
	if(endPoint > SCENE_WIDTH)
	{
		endPoint = SCENE_WIDTH;
	}
	
	title_x = (startPoint + endPoint - clutter_actor_get_width(temp2))/2 - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
	
	clutter_actor_set_x(temp2, title_x);*/
	
	startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);

	if(startPoint < EXTEND_CATEGORY_TITLE_X)
	{
		startPoint = EXTEND_CATEGORY_TITLE_X;
	}

	title_x = startPoint - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);

	clutter_actor_set_x(temp2, title_x);
#endif
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
	temp1 = clutter_actor_get_child_at_index(temp1, index - 1);
	
	//clutter_actor_show_all(temp1);

	//begin junhui.wang
	if(isKeyControl){
		clutter_actor_set_width(temp1, transWidth);
		clutter_actor_set_x(temp1, NORMAL_CONTENTS_WIDTH*(index - 1));
		
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);

		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_clip(temp2,0,0,transWidth,WIDGET_HEIGHT);
		//clutter_actor_set_height(temp2,transHeight);

		//main
		temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);

		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_y(temp3, transHeight);
		if(diff == 0.0)
			clutter_actor_set_opacity(temp3,0);
		else
			clutter_actor_set_opacity(temp3,normalOverlapOpcity);
		
		//iconParent1
		temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);

		transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);

		clutter_actor_set_x(temp3, transIconPosition);

		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);

		if(diff == 0.0f)
		{
			clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
			clutter_actor_set_opacity(temp3, 255);
		}
		else
		{
			clutter_actor_set_opacity(temp3, 0);
		}

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_scale(temp3, transScaleX, transScaleY);
			clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*verticalDiff);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*diff)*verticalDiff);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

		clutter_actor_set_y(temp2, transHeight);

		//title1 (normal)
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		//clutter_actor_set_x(temp3, transNormalTitlePos);
		clutter_actor_set_opacity(temp3, transNormalTitleOpt);

		//title2 (focus)
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		
		contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
	
		transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
		transFocusTitlePos = transVerticalFocusTitlePos - (transVerticalFocusTitlePos - contentsTitle_x)*diff;
		//clutter_actor_set_x(temp3, transFocusTitlePos);
		clutter_actor_set_opacity(temp3, transFocusTitleOpt);

		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, transWidth, transHeight);
		}
#if 0
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,transWidth);

		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_width(temp2, transWidth);
			clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//progressC
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
		
			clutter_actor_set_width(temp3, transWidth);
			clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
		}

		// options
		int itemCounts = clutter_actor_get_n_children(temp1);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
		}
#endif
	}else{
		clutter_actor_set_width(temp1, NORMAL_CONTENTS_WIDTH);
		clutter_actor_set_x(temp1, NORMAL_CONTENTS_WIDTH*(index - 1)+(transWidth-NORMAL_CONTENTS_WIDTH)/2);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
		clutter_actor_set_clip(temp2,0,0,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);
		//clutter_actor_set_height(temp2,CONTENTS_IMAGE_HEIGHT);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
		clutter_actor_set_opacity(temp3,normalOverlapOpcity);
		
		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);

		if(diff == 0.0f)
		{
			clutter_actor_set_opacity(temp3, 255);
		}
		else
		{
			clutter_actor_set_opacity(temp3, 0);
		}

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*verticalDiff);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*diff)*verticalDiff);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

		//title1 (normal)
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		clutter_actor_set_opacity(temp3, 255);

		//title2 (focus)
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		
		contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
		
		transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
		transFocusTitlePos = transVerticalFocusTitlePos - (transVerticalFocusTitlePos - contentsTitle_x)*diff;
		clutter_actor_set_opacity(temp3, 0);

		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
		}
		
#if 0
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,NORMAL_CONTENTS_WIDTH);
		
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//progressC
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
		}

		// options
		int itemCounts = clutter_actor_get_n_children(temp1);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
		}
#endif
	}

	//end junhui.wang
	//fix the when reach the last item ,clutter will pop many error[by junhui.wang]
	if(itemCount > index){
		////////////////////////////////right contents fovea//////////////////////////////////

		clutter_actor_get_position(temp1, &x, &y);

		//contentsWrapper
		temp1 = clutter_actor_get_next_sibling(temp1); 

		//clutter_actor_show_all(temp1);
		
		//junhui.wang
		//clutter_actor_set_x(temp1, x + transWidth);
		gfloat t_RightConX_Mouse = x + transWidth;
		gfloat t_RightConX = x + NORMAL_CONTENTS_WIDTH + (transWidth-NORMAL_CONTENTS_WIDTH)/2;

		transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
		transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
		transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;

		transWidth = (transVerticalWidth + NORMAL_CONTENTS_WIDTH) - transWidth;
		transHeight = (transVerticalHeight + CONTENTS_IMAGE_HEIGHT) - transHeight;
		transHeight = Rounding(transHeight,0);
		transOpacity = (transVerticalOpacity + OPACITY_70) - transOpacity;       
		transContentsTitleWidth = (transVerticalContentsTitleWidth + NORMAL_CONTENTS_TITLE_WIDTH) - transContentsTitleWidth;
		transBorderWidth = (transVerticalBorderWidth + (NORMAL_CONTENTS_WIDTH - 4)) - transBorderWidth;
		transNormalTitlePos = (transVerticalNormalTitlePos + CONTENTS_TITLE_X) - transNormalTitlePos;
		transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
		transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;

		//begin junhui.wang	
		transOverlapOpacity = (transVerticalOverlapOpacity + normalOverlapOpcity) - transOverlapOpacity;	
		//end junhui.wang
		
		if(verticalDiff <= 0.5)
		{
			transVerticalDiff = 1 - 2*verticalDiff;

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
				transFocusTitleOpt = 0;
			}
			else
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
		}
		else
		{
			transVerticalDiff = 2*(verticalDiff - 0.5);

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*(1 - 2*diff))*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
			else
			{
				transNormalTitleOpt = 0;
				transFocusTitleOpt = OPACITY_100*2*(diff - 0.5)*transVerticalDiff;
			}
		}

		
		//begin junhui.wang
		if(isKeyControl){
			clutter_actor_set_x(temp1,t_RightConX_Mouse);
			clutter_actor_set_width(temp1, transWidth);

			//dominant
			temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);

			clutter_actor_set_width(temp2, transWidth);
			//clutter_actor_set_opacity(temp2, transOpacity);
			clutter_actor_set_clip(temp2,0,0,transWidth,WIDGET_HEIGHT);
			//clutter_actor_set_height(temp2,transHeight);

			//main
			temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);

			//clutter_actor_set_size(temp3, transWidth, transHeight);
			clutter_actor_set_scale(temp3, transScaleX, transScaleY);

			//overRay
			temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);

			clutter_actor_set_width(temp3, transWidth);
			clutter_actor_set_y(temp3, transHeight);
			//clutter_actor_set_opacity(temp3,transOverlapOpacity);
			if(diff == 1.0)
				clutter_actor_set_opacity(temp3,0);
			else
				clutter_actor_set_opacity(temp3,normalOverlapOpcity);
			
			//iconParent1
			temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);

			transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);

			clutter_actor_set_x(temp3, transIconPosition);

			//iconParent2
			temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);

			if(diff == 1.0f)
			{
				clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
				clutter_actor_set_opacity(temp3, 255);
			}
			else
			{
				clutter_actor_set_opacity(temp3, 0);
			}

			//subMain
			temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

			if(clutter_actor_get_width(temp3) != 10.0f)
			{
				clutter_actor_set_scale(temp3, transScaleX, transScaleY);
				clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
				clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
			}
			
			//titleParent
			temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

			clutter_actor_set_y(temp2, transHeight);

			//title1 (normal)
			temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
			//clutter_actor_set_x(temp3, transNormalTitlePos);
			clutter_actor_set_opacity(temp3, transNormalTitleOpt);

			//title2 (focus)
			temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
			
			contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
			
			transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
			transFocusTitlePos = contentsTitle_x - (contentsTitle_x - transVerticalFocusTitlePos)*diff;
			//clutter_actor_set_x(temp3, transFocusTitlePos);
			clutter_actor_set_opacity(temp3, transFocusTitleOpt);

			//progressN & Dim
			if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
			{
				temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
				ProgressController::updateProgressFoveaStatus(temp2, transWidth, transHeight);
			}
#if 0
			//dim
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			clutter_actor_set_width(temp2,transWidth);

			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

			gfloat progress = clutter_actor_get_x(temp3);

			if(progress <= 0 || progress >= 100)
			{
				//progressP
				clutter_actor_set_opacity(temp2, 0);
			}
			else
			{
				//progressP
				clutter_actor_set_width(temp2, transWidth);
				clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
				clutter_actor_set_opacity(temp2, OPACITY_100);

				//progressC
				temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
			
				clutter_actor_set_width(temp3, transWidth);
				clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
			}

			// options
			int itemCounts = clutter_actor_get_n_children(temp1);
			if (itemCounts > CONTENT_OPTION_INDEX)
			{
				ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
				clutter_actor_set_x(tempOption, 
		    					(clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            	clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
			}
#endif
		}else{
			clutter_actor_set_x(temp1,t_RightConX+((transWidth-NORMAL_CONTENTS_WIDTH)/2));
			clutter_actor_set_width(temp1, NORMAL_CONTENTS_WIDTH);
			//dominant
			temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
			clutter_actor_set_clip(temp2,0,0,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);
			//clutter_actor_set_height(temp2,CONTENTS_IMAGE_HEIGHT);

			//main
			temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);

			//overRay
			temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
			clutter_actor_set_opacity(temp3,normalOverlapOpcity);

			//iconParent2
			temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);

			if(diff == 1.0f)
			{
				clutter_actor_set_opacity(temp3, 255);
			}
			else
			{
				clutter_actor_set_opacity(temp3, 0);
			}

			//subMain
			temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);
			if(clutter_actor_get_width(temp3) != 10.0f)
			{
				clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
				clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
			}

			//titleParent
			temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);
			//title1 (normal)
			temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
			clutter_actor_set_opacity(temp3, 255);

			//title2 (focus)
			temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);	
			contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
			transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
			transFocusTitlePos = contentsTitle_x - (contentsTitle_x - transVerticalFocusTitlePos)*diff;
			clutter_actor_set_opacity(temp3, 0);

			//progressN & Dim
			if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
			{
				temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
				ProgressController::updateProgressFoveaStatus(temp2, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
			}
#if 0	
			//dim
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			clutter_actor_set_width(temp2,NORMAL_CONTENTS_WIDTH);
			
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

			gfloat progress = clutter_actor_get_x(temp3);

			if(progress <= 0 || progress >= 100)
			{
				//progressP
				clutter_actor_set_opacity(temp2, 0);
			}
			else
			{
				//progressP
				clutter_actor_set_opacity(temp2, OPACITY_100);

				//progressC
				temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
			}

			// options
			int itemCounts = clutter_actor_get_n_children(temp1);
			if (itemCounts > CONTENT_OPTION_INDEX)
			{
				ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
				clutter_actor_set_x(tempOption, 
			                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
	            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
			}
#endif
		}

		//end junhui.wang

		////////////////////////////////right contents//////////////////////////////////
		
		for(int i = index; i < itemCount; i++)
		{
			temp3 = clutter_actor_get_child_at_index(tempList, i);

			if(clutter_actor_get_x(bar) + clutter_actor_get_x(tempChild) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
			{
				rightLimit = i;
			
				break;
			}

			if(i == itemCount - 1)
			{
				rightLimit = itemCount - 1;
			}
		}

		if(index == itemCount - 1) 
		{
			return;
		}

		for(int i = index + 1; i <= rightLimit + 1; i++)
		{
			if(i > itemCount - 1) 
			{
				return;
			}

			showTemp = clutter_actor_get_child_at_index(tempList, i);
			
			//clutter_actor_show_all(showTemp);
			
			toNormalContents(tempIndex, i, transVerticalWidth - NORMAL_CONTENTS_WIDTH);
		}
		
		for(int i = rightLimit + 1; i < itemCount; i++)
		{
			if(i >= itemCount) 
			{
				return;
			}
			
			hideTemp = clutter_actor_get_child_at_index(tempList, i);
			
			//clutter_actor_hide_all(hideTemp);
		}
	}
}

void FirstScreenListWidget::addSubMain(std::string categoryType, int contentsIndex, ClutterActor* subMain)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDominant = NULL;
	ClutterActor *currentSubMain = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");

		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");

			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);

	currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
	currentDominant = clutter_actor_get_child_at_index(currentDominant, DOMINANT_INDEX);
	
	currentSubMain = clutter_actor_get_child_at_index(currentDominant, SUBMAIN_INDEX);

	clutter_actor_set_size(subMain, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(subMain, 0, 0);
	clutter_actor_set_opacity(subMain, 0);
	clutter_actor_set_pivot_point(subMain, 0.0, 0.0);

	clutter_actor_replace_child(currentDominant, currentSubMain, subMain);
}

void FirstScreenListWidget::changeContentLive(std::string categoryType, std::string contentsType, int contentsIndex, int num, ClutterActor* contentLive)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDominant = NULL;
	ClutterActor *currentMain = NULL;

	std::string childName;
	std::string contentName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);

	currentDominant = clutter_actor_get_child_at_index(currentList, contentsIndex);
	currentDominant = clutter_actor_get_child_at_index(currentDominant, DOMINANT_INDEX);

	currentMain = clutter_actor_get_child_at_index(currentDominant, MAIN_INDEX);

	clutter_actor_set_size(contentLive, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_position(contentLive, NORMAL_CONTENTS_WIDTH, 0);
	clutter_actor_set_opacity(contentLive, 255);

	contentName = "apps";

	if(contentsType.compare(contentName) == 0)
	{
		if(num == 1)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, LIVECONTENTS1_INDEX);
			appLive[1] = contentLive;
		}
		else if(num == 2)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, LIVECONTENTS2_INDEX);
			appLive[2] = contentLive;
		}
		
		appLive[0] = clutter_actor_get_child_at_index(currentMain, LIVECONTENTS3_INDEX);
	}
	
	contentName = "games";

	if(contentsType.compare(contentName) == 0)
	{
		if(num == 1)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, LIVECONTENTS1_INDEX);
			gameLive[1] = contentLive;
		}
		else if(num == 2)
		{
			clutter_actor_insert_child_at_index(currentMain, contentLive, LIVECONTENTS2_INDEX);
			gameLive[2] = contentLive;
		}

		gameLive[0] = clutter_actor_get_child_at_index(currentMain, LIVECONTENTS3_INDEX);
	}
}

void FirstScreenListWidget::setProgress(std::string categoryType, int contentsIndex, gfloat progress)
{

	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentProgressN = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");

		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");

			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
	currentProgressN = clutter_actor_get_child_at_index(currentList, contentsIndex);

	int childrenCounts = clutter_actor_get_n_children(currentProgressN);
	if ( childrenCounts == CONTENT_DIM_INDEX)
	{
		ProgressController* pCtr = new ProgressController(currentProgressN);
		ClutterActor* pActor = pCtr->returnProgressRootActor();
		ProgressController::insertProgressController(pActor, pCtr);
		pCtr->setProgress(progress);
		return;
	}

	if ( childrenCounts == CONTENT_DIM_INDEX + 1)
	{
		currentProgressN = clutter_actor_get_child_at_index(currentProgressN, CONTENT_DIM_INDEX);
		ProgressController::updateProgress(currentProgressN, progress);
	}
	
#if 0
	
	currentProgressN = clutter_actor_get_child_at_index(currentProgressN, CONTENT_PROGRESS_INDEX);
	currentProgressN = clutter_actor_get_child_at_index(currentProgressN, PROGRESS_N_INDEX);
	clutter_actor_set_x(currentProgressN, progress);
#endif
}

int FirstScreenListWidget::getCategoryIndexByID(std::string categoryType)
{
	ClutterActor *currentChild = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");

		return EMPTY;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");

			return EMPTY;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				//printf("There is no such category!!! Check id!!!\n");
				
				return EMPTY;
			}		
			else
			{
				return 1;
			}
		}
		else
		{
			return 0;
		}
	}
}

static void cal_mouse_over()
{
	int categoryCount = clutter_actor_get_n_children(bar);
	int over_x = cur_x - clutter_actor_get_x(bar);
	int over_y = cur_y - (SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2);	
	int over_category = 0;
	int over_contents = 0;
	gfloat inputPosition = 0;

	ClutterActor *barTemp = NULL;

	for(int i = 0; i < categoryCount; i++)
	{
		barTemp = clutter_actor_get_child_at_index(bar, i);
			
		if(over_x <= clutter_actor_get_x(barTemp) + clutter_actor_get_width(barTemp))
		{
			over_category = i;

			break;
		}

		//liang.wu AD index has 3 count
		int cal_count = 1;
		if(FirstScreenADControl::GetInstance()->IsEnable())
		{
			cal_count = 2;
		}

		if(i == categoryCount - cal_count)
		{
			//[Begin]fix bug of EMPTY state[liang.wu]
			//if(categoryCount >= 2 && SCENE_WIDTH - SCROLL_AREA < cur_x)
			{
				foveaState = IN_CONTENTS;
				ClutterActor *listWrapper = clutter_actor_get_child_at_index(barTemp, CATEGORY_LISTWRAPPER_INDEX);
				int itemCount = clutter_actor_get_n_children(listWrapper);
				currentIndex = itemCount;
				currentContents = itemCount - 1;
				currentCategory = i;

				return;
			}
			//[End]fix bug of EMPTY state[liang.wu]
		
			//foveaState = EMPTY;

			//currentCategory = EMPTY;
			//currentContents = EMPTY;
			//return;
		}
	}

	if(over_y < 0)
	{
		verticalDiff = 0.0f;
	}
	else if(over_y <= CATEGORY_COLOR_HEIGHT/2)
	{	
		inputPosition = over_y / (CATEGORY_COLOR_HEIGHT/2);

		verticalDiff = bezier(inputPosition, 1.0f, vFovea[0], vFovea[1], vFovea[2], vFovea[3]);
	}
	else if(over_y <= WIDGET_HEIGHT + CATEGORY_COLOR_HEIGHT/2)
	{
		verticalDiff = 1.0f;
	}
	else
	{
		over_y -= (WIDGET_HEIGHT+ CATEGORY_COLOR_HEIGHT/2);

		inputPosition = 1 - (over_y / BOTTOM_HEIGHT);

		verticalDiff = bezier(inputPosition, 1.0f, vFovea[0], vFovea[1], vFovea[2], vFovea[3]);
	}

	if(isOpen[over_category])	//���� ī�װ����� �����ִ� ���
	{
		barTemp = clutter_actor_get_child_at_index(bar, over_category);	//���� ������ ���ϵ�

		ClutterActor *listWrapper = clutter_actor_get_child_at_index(barTemp, CATEGORY_LISTWRAPPER_INDEX);
		
		int itemCount = clutter_actor_get_n_children(listWrapper);	//���� ������ �������� ���ϵ� ��

		if(over_x < clutter_actor_get_x(barTemp) + FOCUS_CONTENTS_WIDTH/2)	//���� �� �κ�
		{
			foveaState = EMPTY;

			if(over_x >= clutter_actor_get_x(barTemp))	//�����Ͱ� ������ ���ο� �ִ� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = FEATURED_OPEN;
				}
				else
				{
					foveaState = LEFT_END;
				}
				
				currentCategory = over_category;
				currentContents = 0;
			}
			else	//�����Ͱ� ������ ���ο� ���� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = FIRST_GAP;
				}

				currentCategory = EMPTY;
				currentContents = EMPTY;
			}
		}
		else if(over_x > clutter_actor_get_x(barTemp) + FOCUS_CONTENTS_WIDTH/2 + NORMAL_CONTENTS_WIDTH*(itemCount-1))	//������ �� �κ�
		{
			foveaState = EMPTY;

			currentCategory = over_category;
			currentContents = itemCount - 1;

			if(over_category == 0 && categoryCount >= 2)	//�����ʿ� ī�װ��� ����
			{
				foveaState = HISTORY_OPEN;
			}

			//modify by junhui.wang [fix the scale item error]
			if(categoryCount >= 2){
				foveaState = IN_CONTENTS;
				currentCategory = over_category;
				currentContents = itemCount - 1;
				currentIndex = itemCount;
			}
		}
		else	//������ ����
		{
			ClutterActor *sibling = NULL;

			foveaState = IN_CONTENTS;

			currentIndex = (int)((over_x - clutter_actor_get_x(barTemp) - FOCUS_CONTENTS_WIDTH/2)/NORMAL_CONTENTS_WIDTH) + 1; 
			currentCategory = over_category;

			//junhui.wang fix focus jump
			currentContents = 0;
			for(int i = 1; i <= currentIndex; i++)
			{
				sibling = clutter_actor_get_child_at_index(listWrapper, i - 1);
				//modify by junhui.wang [fix the cal item pos error]
				if(isKeyControl){
					if(over_x - clutter_actor_get_x(barTemp) > NORMAL_CONTENTS_WIDTH*(i - 1) + clutter_actor_get_width(sibling))
					{
						currentContents = i;
					}
				}else{
					if(over_x - clutter_actor_get_x(barTemp) > (NORMAL_CONTENTS_WIDTH*(i - 1) + clutter_actor_get_width(sibling) + 2*(clutter_actor_get_x(sibling)-NORMAL_CONTENTS_WIDTH*(i - 1))))
					{
						currentContents = i;
					}
				}
			}
		}
	}
	else	//���� ī�װ����� �����ִ� ���
	{
		if(over_x <= clutter_actor_get_x(barTemp) + FOCUS_CATEGORY_WIDTH/2)	//������ ���
		{
			foveaState = EMPTY;

			if(over_x >= clutter_actor_get_x(barTemp))	//�����Ͱ� ī�װ��� ���ο� �ִ� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = HISTORY_OPEN;
				}
				else
				{
					foveaState = LEFT_END;
				}
				
				currentCategory = over_category;
				currentContents = EMPTY;
			}
			else	//�����Ͱ� ī�װ��� ���ο� ���� ���
			{
				if(over_category == 1)	//���ʿ� ī�װ��� ����
				{
					foveaState = SECOND_GAP;
				}

				//liang.wu fix bug about left side EMPTY
				if(foveaStatePre == IN_CONTENTS || foveaStatePre == LEFT_END || foveaStatePre == FEATURED_OPEN || foveaStatePre == FIRST_GAP)
				{
					foveaFeaturedOpen(0);
				}
				
				currentCategory = EMPTY;
				currentContents = EMPTY;
			}
		}
		else	//�������� ���
		{
			foveaState = EMPTY;

			currentCategory = over_category;
			currentContents = EMPTY;

			if(over_category == 0)	//�����ʿ� ī�װ��� ����
			{
				foveaState = FEATURED_OPEN;
			}
		}
	}
}

static void move_rect() 
{	
	ClutterActor *barTemp = NULL;
	gfloat center = 0;
	gfloat inputPosition;
	gfloat diff;
	gfloat move_x = cur_x - clutter_actor_get_x(bar);
	gfloat check_pre_cur_x = cur_x_pre;
	gfloat check_pre_cur_y = cur_y_pre;
	cur_x_pre = cur_x;
	cur_y_pre = cur_y;
	if(check_pre_cur_x == cur_x && check_pre_cur_y == cur_y)
	{
		//return;
	}
	
	cal_mouse_over();
	foveaStatePre = foveaState;//liang.wu

	if(foveaState == IN_CONTENTS)
	{
		#ifdef TIME_TYPE_TEST
		startTime(time_type_move_rect_IN_Contents);
		#endif
	
	    if (SCALE_RIGHT && preIsKeyControl)
	    {
	        return;
	    }
		barTemp = clutter_actor_get_child_at_index(bar, currentCategory);

		center = clutter_actor_get_x(barTemp) + FOCUS_CONTENTS_WIDTH/2 + NORMAL_CONTENTS_WIDTH*(currentIndex-1);
		
		inputPosition = abs(move_x - center) / NORMAL_CONTENTS_WIDTH;

		if(inputPosition > 1.0)//liang.wu fix bug
		{
			inputPosition = 1.0;
		}

		diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);
		
		//globalCursorWidth = clutter_actor_get_width(globalCursor);
		globalCursorWidth = getGlobalCursorWidth();

		foveaContents(diff, currentIndex);

		#ifdef TIME_TYPE_TEST
		recordTime(time_type_move_rect_IN_Contents);
		#endif
	}
	else if(foveaState == EMPTY)
	{
	    if (SCALE_LEFT)
	    {   
	        toNomralCategory(0, 0);
	    }
		return;
	}
	else if(foveaState == FEATURED_OPEN)
	{
		#ifdef TIME_TYPE_TEST
		startTime(time_type_move_rect_Featured_Open);
		#endif
		
	    if (SCALE_LEFT)
	    {
	        return;
	    }
		barTemp = clutter_actor_get_child_at_index(bar, reduceIndex);

		center = FOCUS_CATEGORY_WIDTH/2;

		//liang.wu fix bug begin
		//shuhao.yan
		gfloat range = NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH/2 + FOCUS_CONTENTS_WIDTH/2 + CATEGORY_GAP + preDiff * EXTENDGAP * 2;
		gfloat cur_move = move_x;
		
		if(clutter_actor_get_x(bar) < SIDECATEGORY_GAP)
		{
			range = FOCUS_CATEGORY_WIDTH/2 * 1.5f;
			cur_move = cur_x - (clutter_actor_get_x(barTemp) + clutter_actor_get_x(bar));
		}
	
		inputPosition = abs(cur_move - center) / range;
		//liang.wu fix bug end

		diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

		// shuhao.yan
		if (diff <= 0.5)
		{
			preDiff = 2 * diff;
		}
		else
		{
			preDiff = 2 *(1 - diff);
		}
		
		foveaFeaturedOpen(diff);

		#ifdef TIME_TYPE_TEST
		recordTime(time_type_move_rect_Featured_Open);
		#endif
	}
	else if(foveaState == FIRST_GAP)
	{
		#ifdef TIME_TYPE_TEST
		startTime(time_type_move_rect_FIRST_GAP);
		#endif
		
	    if (SCALE_LEFT)
	    {
	        return;
	    }
		barTemp = clutter_actor_get_child_at_index(bar, reduceIndex);

		center = FOCUS_CATEGORY_WIDTH/2; 

		// shuhao.yan
		gfloat range = NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH/2 + FOCUS_CONTENTS_WIDTH/2 + CATEGORY_GAP + EXTENDGAP * preDiff * 2; 
		inputPosition = abs(move_x - center) / range;

		diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

		// shuhao.yan
		if (diff <= 0.5)
		{
			preDiff = 2 * diff;
		}
		else
		{
			preDiff = 2 *(1 - diff);
		}
		
		foveaFeaturedOpen(diff);

		#ifdef TIME_TYPE_TEST
		recordTime(time_type_move_rect_FIRST_GAP);
		#endif
		
		//return;
	}
	else if(foveaState == LEFT_END)
	{
		#ifdef TIME_TYPE_TEST
		startTime(time_type_move_rect_LEFT_END);
		#endif
		
	    if (SCALE_LEFT)
	    {
	        return;
	    }
		if(isOpen[currentCategory])
		{
			diff = bezier(0.0f, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

			foveaContents(diff, 1);
		}
		else
		{
			diff = bezier(0.0f, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);

			foveaFeaturedOpen(diff);
		}

		#ifdef TIME_TYPE_TEST
		recordTime(time_type_move_rect_LEFT_END);
		#endif
	}
	else
	{
		return;
	}
}

void FirstScreenListWidget::removeContents(int categoryIndex, int contentsIndex)
{

	ClutterActor *removeParent = clutter_actor_get_child_at_index(bar, categoryIndex);
	ClutterActor *removeList = clutter_actor_get_child_at_index(removeParent, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor *removeChild = NULL;

	removeChild = clutter_actor_get_child_at_index(removeList, contentsIndex);
	
	// remove from map
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(removeChild);
	if (it != itemMap.end())
	{
		FirstScreenContents* ctr = it->second;
		itemMap.erase(it);

		if (ctr != NULL && !ctr->id.empty())
		{
			map<std::string, FirstScreenContents*>::iterator tagIt = contentsTagMap.find(ctr->id);
			if (tagIt != contentsTagMap.end())
			{
				contentsTagMap.erase(tagIt);
			}
		}
	}

	clutter_actor_remove_child(removeList, removeChild); 

	clutter_actor_set_width(removeList, clutter_actor_get_width(removeList) - NORMAL_CONTENTS_WIDTH);
	
	cal_mouse_over();
	foveaStatePre = foveaState;//liang.wu
	
	if((categoryIndex == 0 && isOpen[0]) || (categoryIndex == 1 && isOpen[1]))
	{
		if(cur_x >= clutter_actor_get_x(bar) + clutter_actor_get_x(removeParent) + (clutter_actor_get_n_children(removeList) - 1)*NORMAL_CONTENTS_WIDTH + FOCUS_CONTENTS_WIDTH/2)
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + clutter_actor_get_x(removeParent) + (clutter_actor_get_n_children(removeList) - 1)*NORMAL_CONTENTS_WIDTH + FOCUS_CONTENTS_WIDTH/2;
		}
	}
	
	move_rect();
}

void FirstScreenListWidget::setFocus(int contentsIndex)
{
	if(KEY_SELECT) {
		return;
	}

	if(exchangeControlStep >= 1)
	{
		return;
	}
	
	EVENT_FLAG = false;

	//fix the bug for set the error index 
	int itemCount = get_extend_itemCount();
	if(contentsIndex < 0)
		contentsIndex = 0;
	if(contentsIndex >= itemCount)
		contentsIndex = itemCount - 1;

	gfloat posLeft = 0.0f;
	gfloat posRight = 0.0f;
	//begin junhui.wang-- modify
	{
		gfloat leftLimitX = clutter_actor_get_x(bar) + clutter_actor_get_x(clutter_actor_get_child_at_index(bar, reduceIndex))
													 + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP;
		
		int itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(bar, extendIndex));
		
		posLeft = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex;
		posRight = posLeft + FOCUS_CONTENTS_WIDTH;
		if(posLeft < leftLimitX)
		{
			goal_position = leftLimitX - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex);
			clutter_actor_set_x(bar, goal_position);
		}	
		if(posRight >= SCENE_WIDTH)
		{
			if(contentsIndex == (itemCount-1))
				goal_position = SCENE_WIDTH -(NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex) - FOCUS_CONTENTS_WIDTH - SIDECATEGORY_GAP;
			else
				goal_position = SCENE_WIDTH -(NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex) - FOCUS_CONTENTS_WIDTH;
			clutter_actor_set_x(bar, goal_position);
		}	
		cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex + FOCUS_CONTENTS_WIDTH/2;
	}
	//end junhui.wang
	isKeyControl = true;
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;

	//global cursor
	posLeft = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*contentsIndex;
	posRight = posLeft + FOCUS_CONTENTS_WIDTH;
	setGlobalCursorPosition(posLeft, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
	setGlobalCursorSize(FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_opacity(globalCursor, 255);

	move_rect();
	
	EVENT_FLAG = true;
}

static bool setenterOptions()
{
#if 1
	if (!FOCUS_OPTIONS)
	{
		return false;
	}

	bool haveOptions = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * options = NULL;
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		haveOptions = ctr->haveOptions; 
	}
	else
	{
		return false;
	}
	
	if (haveOptions)
	{	
	    ClutterActor *optionIndicatorIco = clutter_actor_get_child_at_index(contentWrapper, CONTENT_OPTION_INDEX);
	    clutter_actor_set_content(optionIndicatorIco, optionDownNormalIco);
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->enterOptionsCallback.invoke(arr);
		
		optionStaus = ENTER;
	}
	else
	{
		return false;
	}

	STOP_FLAG = true;
	FOCUS_OPTIONS = false;
#endif
	return true;
}

static bool setfocusOptions()
{
#if 1
	if (FOCUS_OPTIONS)
	{
		return false;
	}

	bool haveOptions = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * options = NULL;
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		haveOptions = ctr->haveOptions; 
	}

	if (STOP_FLAG)
	{
		STOP_FLAG = false;
	}
	
	if (haveOptions)
	{	
	    ClutterActor *optionIndicatorIco = clutter_actor_get_child_at_index(contentWrapper, CONTENT_OPTION_INDEX);
        if (optionStaus == ENTER) 
        {
            clutter_actor_set_content(optionIndicatorIco, optionDownFocusIco);
        }
        else
        {
	        clutter_actor_set_content(optionIndicatorIco, optionUpFocusIco);
        }
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->focusOptionsCallback.invoke(arr);
		
		FOCUS_OPTIONS = true;

		optionStaus = FOCUS;

		return true;
	}
	else
	{	
		return false;
	}
#endif
	return true;
}

static void setunfocusOptions()
{
#if 1
	if (!FOCUS_OPTIONS)
	{
		return;
	}

	bool haveOptions = false;
	FirstScreenContents* ctr = NULL;
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * options = NULL;
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		haveOptions = ctr->haveOptions; 
	}
	
	if (haveOptions)
	{	
	    ClutterActor *optionIndicatorIco = clutter_actor_get_child_at_index(contentWrapper, CONTENT_OPTION_INDEX);
	    clutter_actor_set_content(optionIndicatorIco, optionUpNormalIco);
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->unfocusOptionsCallback.invoke(arr);

		optionStaus = UNFOCUS;
	}
	
	
	FOCUS_OPTIONS = false;	
#endif
}

bool FirstScreenListWidget::focusOptions()
{
#if 1
	return setfocusOptions();
#endif
	return true;
}

void FirstScreenListWidget::unfocusOptions()
{
#if 1
	setunfocusOptions();
#endif
}

bool FirstScreenListWidget::enterOptions()
{
	return setenterOptions();
}


bool FirstScreenListWidget::popupContextMenu(int contextType)
{
	if (!CONTEXTMENU_ENABLE)
	{
		return false;
	}

	
	if (FOCUS_CONTEXTMENU)
	{
		return false;
	}
	
	if (ContextMenu::Instance().setFocusContextMenu(contextType))
	{
		FOCUS_CONTEXTMENU = true;
		return true;
	}
	else
	{
		return false;
	}
}

void FirstScreenListWidget::hideContextMenu()
{
	if (!CONTEXTMENU_ENABLE)
	{
		return;
	}

	if (!FOCUS_CONTEXTMENU)
	{
		return;
	}

	ContextMenu::Instance().fallContextMenu();
	FOCUS_CONTEXTMENU = false;
	timeID++;
	ContextMenu::setTimeout(timeID);
}

void FirstScreenListWidget::selectContextMenuItem()
{
	if (!CONTEXTMENU_ENABLE)
	{
		return;
	}

	if (!FOCUS_CONTEXTMENU)
	{
		return;
	}

	int optionIndex = 0;
	optionIndex = ContextMenu::Instance().enterOption();

	if (instance != NULL && instance->onContextMenuFeedbackListener.isFunction()) 
	{	
		// feedback this index to JS layer [shuhao.yan]
		ScriptArray arr;
		arr.set(0, optionIndex);
		instance->onContextMenuFeedbackListener.invoke(arr);
	}
}


//begin junhui.wang
static void ScaleContentItem(int index){
	scaleItemTick = 0;
	scaleItemIndex = index;	
	SCALE_ITEM_FLAG = true;
}

static void ScaleContentItemAnimation(gfloat diff, int index)
{
	gfloat transWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;
	
	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;

	//begin junhui.wang
	gfloat transOverlapOpacity;
	gfloat transVerticalOverlapOpacity;
	ClutterActor * leftChild;
	gfloat leftEnd;
	gfloat leftWidth;
	//end junhui.wang
	
	gfloat x, y;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	ClutterActor *tempChild = NULL;
	ClutterActor *tempList = NULL;

	int leftLimit = 0;
	int rightLimit = 0;
	int itemCount = 0;
	int tempIndex = 0;
	
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;
	
	////////////////////////////////left contents fovea//////////////////////////////////
	//barChild		
	if(currentCategory == 1)
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		tempIndex = 1;
		itemCount = clutter_actor_get_n_children(temp2);		
	}
	else
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		tempIndex = 0;
		itemCount = clutter_actor_get_n_children(temp2);
	}

	//begin junhui.wang	
	gfloat normalOverlapOpcity;
	if(HIGH_CONTRAST_FLAG)
		normalOverlapOpcity = OPACITY_100;
	else
		normalOverlapOpcity = OPACITY_8;
	transVerticalOverlapOpacity = normalOverlapOpcity - (normalOverlapOpcity - 0)*verticalDiff;	
	transOverlapOpacity = transVerticalOverlapOpacity - (transVerticalOverlapOpacity - normalOverlapOpcity)*diff;	
	//end junhui.wang

	////////////////////////////////left contents//////////////////////////////////
	if(!scaleItemFeatureOpen){
		temp3 = clutter_actor_get_child_at_index(temp2, index - 1);

		for(int i = index - 1; i >= 0; i--)
		{
			if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) - NORMAL_CONTENTS_WIDTH*(index - 1 - i) <= FOCUS_CATEGORY_WIDTH)
			{
				leftLimit = i;

				break;
			}

			if(i == 0)
			{
				leftLimit = 0;
			}
		}

		for(int i = leftLimit; i <= index - 1; i++)
		{
			toNormalContents(tempIndex, i, 0);
		}

		transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
		transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
		transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
		transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
		transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
		transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

		transWidth = transVerticalWidth - (transVerticalWidth - NORMAL_CONTENTS_WIDTH)*diff;
		transHeight = transVerticalHeight - (transVerticalHeight - CONTENTS_IMAGE_HEIGHT)*diff;
		transOpacity = transVerticalOpacity - (transVerticalOpacity - OPACITY_70)*diff;
		transContentsTitleWidth = transVerticalContentsTitleWidth - (transVerticalContentsTitleWidth - NORMAL_CONTENTS_TITLE_WIDTH)*diff;
		transBorderWidth = transVerticalBorderWidth - (transVerticalBorderWidth - (NORMAL_CONTENTS_WIDTH - 4))*diff;
		transNormalTitlePos = transVerticalNormalTitlePos - (transVerticalNormalTitlePos - CONTENTS_TITLE_X)*diff;
		transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
		transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
		
		if(verticalDiff <= 0.5)
		{
			transVerticalDiff = 1 - 2*verticalDiff;

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
			else
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
				transFocusTitleOpt = 0;
			}
		}
		else
		{
			transVerticalDiff = 2*(verticalDiff - 0.5);

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = 0;
				transFocusTitleOpt = OPACITY_100*(1 - 2*diff)*transVerticalDiff;
			}
			else
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*2*(diff - 0.5))*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
		}
		
		clutter_actor_set_width(temp1, transVerticalWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));
		//categoryTitle
		temp2 = clutter_actor_get_child_at_index(temp1, 1);
		startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);
		if(startPoint < EXTEND_CATEGORY_TITLE_X)
		{
			startPoint = EXTEND_CATEGORY_TITLE_X;
		}
		title_x = startPoint - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);
		//clutter_actor_set_x(temp2, title_x);//junhui.wang
		
		//contentsWrapper
		temp1 = clutter_actor_get_child_at_index(temp1, 2);
		temp1 = clutter_actor_get_child_at_index(temp1, index - 1);
		leftChild = temp1;
		if(NORMAL_CONTENTS_WIDTH*(index - 1) < (clutter_actor_get_x(temp1)-abs(transWidth - scaleItemLeftTransWidth)/2))
			clutter_actor_set_x(temp1,clutter_actor_get_x(temp1)-abs(transWidth-scaleItemLeftTransWidth)/2);
		else
			clutter_actor_set_x(temp1, NORMAL_CONTENTS_WIDTH*(index - 1));
	}else{
		temp1 = clutter_actor_get_child_at_index(bar, extendIndex);	
		clutter_actor_set_x(temp1, NORMAL_CATEGORY_WIDTH + CATEGORY_GAP);

		transVerticalWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
		transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
		transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
		transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;
		transVerticalBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - (FOCUS_CONTENTS_WIDTH - 4))*verticalDiff;
		transVerticalNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2)*verticalDiff;

		transWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - transVerticalWidth)*diff;
		transHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - transVerticalHeight)*diff;
		transHeight = Rounding(transHeight,0);
		transOpacity = OPACITY_70 - (OPACITY_70 - transVerticalOpacity)*diff;
		transContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - transVerticalContentsTitleWidth)*diff;
		transBorderWidth = (NORMAL_CONTENTS_WIDTH - 4) - ((NORMAL_CONTENTS_WIDTH - 4) - transVerticalBorderWidth)*diff;
		transNormalTitlePos = CONTENTS_TITLE_X - (CONTENTS_TITLE_X - transVerticalNormalTitlePos)*diff;
		transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
		transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
		
		if(verticalDiff <= 0.5)
		{
			transVerticalDiff = 1 - 2*verticalDiff;

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
				transFocusTitleOpt = 0;
			}
			else
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
		}
		else
		{
			transVerticalDiff = 2*(verticalDiff - 0.5);

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*(1 - 2*diff))*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
			else
			{
				transNormalTitleOpt = 0;
				transFocusTitleOpt = OPACITY_100*2*(diff - 0.5)*transVerticalDiff;
			}
		}

		itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(temp1, 2));
		clutter_actor_set_width(temp1, transWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));
		//categoryTitle
		temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);		
		startPoint = clutter_actor_get_x(bar) + clutter_actor_get_x(temp1);

		if(startPoint < EXTEND_CATEGORY_TITLE_X)
		{
			startPoint = EXTEND_CATEGORY_TITLE_X;
		}

		title_x = startPoint - clutter_actor_get_x(bar) - clutter_actor_get_x(temp1);

		//clutter_actor_set_x(temp2, title_x);
		
		//contentsWrapper
		temp1 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		temp1 = clutter_actor_get_child_at_index(temp1, CONTENTSWRAPPER_INDEX);
		leftChild = temp1;
		clutter_actor_set_x(temp1,0);
	}

	scaleItemLeftTransWidth = transWidth;

	if(scaleItemDesDiff == 0.0f || scaleItemFeatureOpen){
		clutter_actor_set_width(temp1, transWidth);
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);

		clutter_actor_set_width(temp2, transWidth);
		//clutter_actor_set_opacity(temp2, transOpacity);
		clutter_actor_set_clip(temp2,0,0,transWidth,WIDGET_HEIGHT);
		clutter_actor_set_height(temp2,transHeight);

		//main
		temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);

		//clutter_actor_set_size(temp3, transWidth, transHeight);
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);

		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);

		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_y(temp3, transHeight);
		clutter_actor_set_opacity(temp3,transOverlapOpacity);

		//iconParent1
		temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);
		transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);
		clutter_actor_set_x(temp3, transIconPosition);

		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);

		if(diff == 0.0f)
		{
			clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
			clutter_actor_set_opacity(temp3, 255);
		}
		else
		{
			clutter_actor_set_opacity(temp3, 0);
		}

		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);

		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_scale(temp3, transScaleX, transScaleY);
			clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*verticalDiff);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*diff)*verticalDiff);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);

		clutter_actor_set_y(temp2, transHeight);


		//title1 (normal)
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		//clutter_actor_set_x(temp3, transNormalTitlePos);
		clutter_actor_set_opacity(temp3, transNormalTitleOpt);

		//title2 (focus)
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		
		contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;

		transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
		transFocusTitlePos = transVerticalFocusTitlePos - (transVerticalFocusTitlePos - contentsTitle_x)*diff;
		//clutter_actor_set_x(temp3, transFocusTitlePos);
		clutter_actor_set_opacity(temp3, transFocusTitleOpt);
	
		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, transWidth, transHeight);
		}
#if 0
		//dim
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		clutter_actor_set_width(temp2,transWidth);
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);

		gfloat progress = clutter_actor_get_x(temp3);

		if(progress <= 0 || progress >= 100)
		{
			//progressP
			clutter_actor_set_opacity(temp2, 0);
		}
		else
		{
			//progressP
			clutter_actor_set_width(temp2, transWidth);
			clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//progressC
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
		
			clutter_actor_set_width(temp3, transWidth);
			clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
		}

		// options
		int itemCounts = clutter_actor_get_n_children(temp1);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
		}
#endif
	}

	leftEnd = clutter_actor_get_x(leftChild) + clutter_actor_get_width(leftChild);
	leftWidth = clutter_actor_get_width(leftChild);
	
	if(!scaleItemFeatureOpen){
		////////////////////////////////right contents fovea//////////////////////////////////
		clutter_actor_get_position(temp1, &x, &y);
		//contentsWrapper
		temp1 = clutter_actor_get_next_sibling(temp1); 

		//liang.wu fix sb issue 
		if(temp1)
		{
		
		gfloat t_RightConX_Mouse = x + transWidth;
		gfloat t_RightConX = x + NORMAL_CONTENTS_WIDTH + (transWidth-NORMAL_CONTENTS_WIDTH)/2;

		transVerticalHeight = CONTENTS_IMAGE_HEIGHT - (CONTENTS_IMAGE_HEIGHT - WIDGET_HEIGHT)*verticalDiff;
		transVerticalOpacity = OPACITY_70 - (OPACITY_70 - OPACITY_100)*verticalDiff;
		transVerticalContentsTitleWidth = NORMAL_CONTENTS_TITLE_WIDTH - (NORMAL_CONTENTS_TITLE_WIDTH - FOCUS_CONTENTS_TITLE_WIDTH)*verticalDiff;

		transWidth = (transVerticalWidth + NORMAL_CONTENTS_WIDTH) - transWidth;
		transHeight = (transVerticalHeight + CONTENTS_IMAGE_HEIGHT) - transHeight;
		transHeight = Rounding(transHeight,0);
		transOpacity = (transVerticalOpacity + OPACITY_70) - transOpacity;       
		transContentsTitleWidth = (transVerticalContentsTitleWidth + NORMAL_CONTENTS_TITLE_WIDTH) - transContentsTitleWidth;
		transBorderWidth = (transVerticalBorderWidth + (NORMAL_CONTENTS_WIDTH - 4)) - transBorderWidth;
		transNormalTitlePos = (transVerticalNormalTitlePos + CONTENTS_TITLE_X) - transNormalTitlePos;
		transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
		transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;

		//begin junhui.wang	
		transOverlapOpacity = (transVerticalOverlapOpacity + normalOverlapOpcity) - transOverlapOpacity;	
		//end junhui.wang
		
		
		if(verticalDiff <= 0.5)
		{
			transVerticalDiff = 1 - 2*verticalDiff;

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
				transFocusTitleOpt = 0;
			}
			else
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
		}
		else
		{
			transVerticalDiff = 2*(verticalDiff - 0.5);

			if(diff <= 0.5f)
			{
				transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*(1 - 2*diff))*transVerticalDiff;
				transFocusTitleOpt = 0;
			}
			else
			{
				transNormalTitleOpt = 0;
				transFocusTitleOpt = OPACITY_100*2*(diff - 0.5)*transVerticalDiff;
			}
		}

		if(scaleItemDesDiff == 0.0f){

			gfloat rightEnd;
			if(scaleItemAllOriginWidth > transVerticalWidth)
				rightEnd = NORMAL_CONTENTS_WIDTH*(index - 1)+scaleItemAllOriginWidth+NORMAL_CONTENTS_WIDTH;
			else
				rightEnd = NORMAL_CONTENTS_WIDTH*(index - 1)+transVerticalWidth+NORMAL_CONTENTS_WIDTH;
			
			gfloat toSetX = clutter_actor_get_x(temp1)+abs(transWidth-scaleItemRightTransWidth)/2;
#if 1			
			if((toSetX+NORMAL_CONTENTS_WIDTH) < rightEnd){
				if(toSetX >= leftEnd)
					clutter_actor_set_x(temp1,toSetX);
				else if ((leftEnd+NORMAL_CONTENTS_WIDTH) <= rightEnd)
					clutter_actor_set_x(temp1,(rightEnd-leftEnd-NORMAL_CONTENTS_WIDTH)/2+leftEnd);
				else{
					clutter_actor_set_x(leftChild,NORMAL_CONTENTS_WIDTH*(index - 1));
					clutter_actor_set_x(temp1,(rightEnd-NORMAL_CONTENTS_WIDTH*(index-1)-leftWidth-NORMAL_CONTENTS_WIDTH)/2+NORMAL_CONTENTS_WIDTH*(index-1)+leftWidth);
				}
			}
			else{
				if((rightEnd-NORMAL_CONTENTS_WIDTH) >= leftEnd)
					clutter_actor_set_x(temp1,rightEnd-NORMAL_CONTENTS_WIDTH);	
				else if ((leftEnd+NORMAL_CONTENTS_WIDTH) <= rightEnd)
					clutter_actor_set_x(temp1,(rightEnd-leftEnd-NORMAL_CONTENTS_WIDTH)/2+leftEnd);
				else{
					clutter_actor_set_x(leftChild,NORMAL_CONTENTS_WIDTH*(index - 1));
					clutter_actor_set_x(temp1,(rightEnd-NORMAL_CONTENTS_WIDTH*(index-1)-leftWidth-NORMAL_CONTENTS_WIDTH)/2+NORMAL_CONTENTS_WIDTH*(index-1)+leftWidth);
				}
			}
#endif
		}
		else{
			gfloat rightEnd;
			if(scaleItemAllOriginWidth > transVerticalWidth)
				rightEnd = NORMAL_CONTENTS_WIDTH*(index - 1)+scaleItemAllOriginWidth+NORMAL_CONTENTS_WIDTH;
			else
				rightEnd = NORMAL_CONTENTS_WIDTH*(index - 1)+transVerticalWidth+NORMAL_CONTENTS_WIDTH;
			
			gfloat toSetX = clutter_actor_get_x(temp1)-abs(transWidth-scaleItemRightTransWidth)/2;

			if((toSetX+transWidth) < rightEnd){
				if(toSetX >= leftEnd)
					clutter_actor_set_x(temp1,toSetX);
				else if ((leftEnd+transWidth) <= rightEnd)
					clutter_actor_set_x(temp1,(rightEnd-leftEnd-transWidth)/2+leftEnd);
				else{
					clutter_actor_set_x(leftChild,NORMAL_CONTENTS_WIDTH*(index - 1));
					clutter_actor_set_x(temp1,(rightEnd-NORMAL_CONTENTS_WIDTH*index-transWidth)/2+NORMAL_CONTENTS_WIDTH*index);
				}			
			}
			else{
				if((rightEnd-transWidth) >= leftEnd)
					clutter_actor_set_x(temp1,rightEnd-transWidth);	
				else if ((leftEnd+transWidth) <= rightEnd)
					clutter_actor_set_x(temp1,(rightEnd-leftEnd-transWidth)/2+leftEnd);
				else{
					clutter_actor_set_x(leftChild,NORMAL_CONTENTS_WIDTH*(index - 1));
					clutter_actor_set_x(temp1,(rightEnd-NORMAL_CONTENTS_WIDTH*index-transWidth)/2+NORMAL_CONTENTS_WIDTH*index);
				}
			}
		}

		scaleItemRightTransWidth = transWidth;
			
		if(scaleItemDesDiff != 0.0f){
			clutter_actor_set_width(temp1, transWidth);
			//dominant
			temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
			clutter_actor_set_width(temp2, transWidth);
			clutter_actor_set_clip(temp2,0,0,transWidth,WIDGET_HEIGHT);
			//clutter_actor_set_opacity(temp2, transOpacity);
			clutter_actor_set_height(temp2,transHeight);

			//main
			temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);
			clutter_actor_set_scale(temp3, transScaleX, transScaleY);

			//overRay
			temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
			clutter_actor_set_width(temp3, transWidth);
			clutter_actor_set_y(temp3, transHeight);
			clutter_actor_set_opacity(temp3,transOverlapOpacity);
			
			//iconParent1
			temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);
			transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);
			clutter_actor_set_x(temp3, transIconPosition);

			//iconParent2
			temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
			if(diff == 1.0f)
			{
				clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
				clutter_actor_set_opacity(temp3, 255);
			}
			else
			{
				clutter_actor_set_opacity(temp3, 0);
			}

			//subMain
			temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);
			if(clutter_actor_get_width(temp3) != 10.0f)
			{
				clutter_actor_set_scale(temp3, transScaleX, transScaleY);
				clutter_actor_set_opacity(temp3, OPACITY_100*diff*verticalDiff);
				clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*(1 - diff))*verticalDiff);
			}
			
			//titleParent
			temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);
			clutter_actor_set_y(temp2, transHeight);

			//title1 (normal)
			temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
			//clutter_actor_set_x(temp3, transNormalTitlePos);
			clutter_actor_set_opacity(temp3, transNormalTitleOpt);

			//title2 (focus)
			temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);	
			contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
			transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*verticalDiff;
			transFocusTitlePos = contentsTitle_x - (contentsTitle_x - transVerticalFocusTitlePos)*diff;

			//clutter_actor_set_width(temp3, transWidth);
			//clutter_actor_set_x(temp3, transFocusTitlePos);
			clutter_actor_set_opacity(temp3, transFocusTitleOpt);

			//progressN & Dim
			if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
			{
				temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
				ProgressController::updateProgressFoveaStatus(temp2, transWidth, transHeight);
			}
#if 0
			//dim
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			clutter_actor_set_width(temp2,transWidth);
			
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
			temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);
			gfloat progress = clutter_actor_get_x(temp3);
			if(progress <= 0 || progress >= 100)
			{
				//progressP
				clutter_actor_set_opacity(temp2, 0);
			}
			else
			{
				//progressP
				clutter_actor_set_width(temp2, transWidth);
				clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
				clutter_actor_set_opacity(temp2, OPACITY_100);

				//progressC
				temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
			
				clutter_actor_set_width(temp3, transWidth);
				clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
			}

			// options
			int itemCounts = clutter_actor_get_n_children(temp1);
			if (itemCounts > CONTENT_OPTION_INDEX)
			{
				ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
    			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
                clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
			}
#endif
		}
		}

		////////////////////////////////right contents//////////////////////////////////
		if(scaleItemAllOriginWidth < transVerticalWidth){
			for(int i = index; i < itemCount; i++)
			{
				temp3 = clutter_actor_get_child_at_index(tempList, i);

				if(clutter_actor_get_x(bar) + clutter_actor_get_x(tempChild) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
				{
					rightLimit = i;
				
					break;
				}

				if(i == itemCount - 1)
				{
					rightLimit = itemCount - 1;
				}
			}

			if(index == itemCount - 1) 
			{
				//return;
			}

			//fix right limit defect
			if(rightLimit == itemCount - 1)
			{
				rightLimit -= 1;
			}

			for(int i = index + 1; i <= rightLimit + 1; i++)
			{
				if(i > itemCount - 1) 
				{
					//return;
				}
				toNormalContents(tempIndex, i, FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH);
			}
		}
	}else{
		////////////////////////////////right contents//////////////////////////////////
#if 1
		temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);

		for(int i = 0; i < itemCount; i++)
		{
			temp3 = clutter_actor_get_child_at_index(temp2, i);

			if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
			{
				rightLimit = i;
			
				break;
			}

			if(i == itemCount - 1)
			{
				rightLimit = itemCount - 1;
			}
		}

		temp3 = clutter_actor_get_child_at_index(temp2, CONTENTSWRAPPER_INDEX);

		//fix right limit defect
		if(rightLimit == itemCount - 1)
		{
			rightLimit -= 1;
		}
			
		for(int i = 1; i <= rightLimit + 1; i++)
		{
			if(i > itemCount - 1) 
			{
				//return;
			}

			toNormalContents(1, i, clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) - NORMAL_CONTENTS_WIDTH);
		}
#endif
	}
	
#if 1


	//global cursor
	gfloat transCursorWidth = 2 - (2 - FOCUS_CONTENTS_WIDTH)*verticalDiff;
	gfloat transCursorHeight = 2 - (2 - WIDGET_HEIGHT)*verticalDiff;
	//gfloat transCursorOpacity = 0 - (0 - 255)*verticalDiff;
	gfloat transCursorX;
	gfloat transCursorY;
	if(scaleItemDesDiff == 0.0){
		int cursorActorIndex;
		if( (index-1) >= 0)
			cursorActorIndex = index-1;
		else
			cursorActorIndex = 0;		
		ClutterActor* haveCursorActor = clutter_actor_get_child_at_index(tempList,cursorActorIndex);
		//clutter_actor_set_size(globalCursor,transCursorWidth,transCursorHeight);
		setGlobalCursorSize(transCursorWidth, transCursorHeight);
		clutter_actor_set_opacity(globalCursor,255);
		
		transCursorX = clutter_actor_get_x(tempChild)+clutter_actor_get_x(haveCursorActor)+(clutter_actor_get_width(haveCursorActor)-transCursorWidth)/2;
		transCursorY = (WIDGET_HEIGHT - transCursorHeight)/2;
		//clutter_actor_set_position(globalCursor,clutter_actor_get_x(bar)+transCursorX,SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
		setGlobalCursorPosition(clutter_actor_get_x(bar)+transCursorX, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
	}else{	
		ClutterActor* haveCursorActor = clutter_actor_get_child_at_index(tempList,index);
		//clutter_actor_set_size(globalCursor,transCursorWidth,transCursorHeight);
		setGlobalCursorSize(transCursorWidth, transCursorHeight);
		clutter_actor_set_opacity(globalCursor,255);
		
		transCursorX = clutter_actor_get_x(tempChild)+clutter_actor_get_x(haveCursorActor)+(clutter_actor_get_width(haveCursorActor)-transCursorWidth)/2;
		transCursorY = (WIDGET_HEIGHT - transCursorHeight)/2;
		//clutter_actor_set_position(globalCursor,clutter_actor_get_x(bar)+transCursorX,SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
		setGlobalCursorPosition(clutter_actor_get_x(bar)+transCursorX, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
	}
#endif
}

static void reverseChildIndex(ClutterActor* parent){
	int itemCount = clutter_actor_get_n_children(parent);
	if(itemCount > 1){
		for(int index = 0 ; index < (int)(itemCount/2) ; index ++){
			ClutterActor* leftChild = clutter_actor_get_child_at_index(parent,index);
			ClutterActor* rightChild = clutter_actor_get_child_at_index(parent,itemCount-1-index);
			clutter_actor_set_child_at_index(parent, leftChild, itemCount-1-index);
			clutter_actor_set_child_at_index(parent, rightChild, index);
		}
	}
}

static void cardReduceEffect(ClutterActor* parent){
	int itemCount = clutter_actor_get_n_children(parent);
	gfloat initX = clutter_actor_get_x(clutter_actor_get_child_at_index(parent,itemCount-1));//- NORMAL_CONTENTS_WIDTH;
	if(itemCount > 1){
		for(int index = (itemCount-2) ; index >= 0 ; index --){
			ClutterActor* child = clutter_actor_get_child_at_index(parent,index);
			int transX = NORMAL_CONTENTS_WIDTH*(itemCount-1-index)+initX -(NORMAL_CONTENTS_WIDTH*(itemCount-1-index)+initX - initX)*reduceDiff;
			clutter_actor_set_x(child,transX);
		}
	}
}

static void cardExtendEffect(ClutterActor* parent){
	int itemCount = clutter_actor_get_n_children(parent);
	if(isKeyControl){
		if(itemCount > 1){
			for(int index = (itemCount-2) ; index >= 0 ; index --){
				ClutterActor* child = clutter_actor_get_child_at_index(parent,index);
				int transX = (FOCUS_CONTENTS_WIDTH-NORMAL_CONTENTS_WIDTH) -((FOCUS_CONTENTS_WIDTH-NORMAL_CONTENTS_WIDTH) - (NORMAL_CONTENTS_WIDTH*(itemCount-1-index)+(FOCUS_CONTENTS_WIDTH-NORMAL_CONTENTS_WIDTH)))*extendDiff;
				clutter_actor_set_x(child,transX);
			}
		}
	}else{
		if(itemCount > 1){
			for(int index = (itemCount-2) ; index >= 0 ; index --){
				ClutterActor* child = clutter_actor_get_child_at_index(parent,index);
				int transX = 0 -(0 - (NORMAL_CONTENTS_WIDTH*(itemCount-1-index)))*extendDiff;
				clutter_actor_set_x(child,transX);
			}
		}
	}
}

//end junhui.wang

//[Begin]category move and clip[liang.wu]
static void fixCategory(void)
{
	gfloat bar_x = clutter_actor_get_x(bar);
	gfloat rightLimitX = SIDECATEGORY_GAP;
	gfloat leftLimitX = 0 - OVER_CATEGORY_WIDTH;

	//category 0 x
	ClutterActor *fixedCategory = clutter_actor_get_child_at_index(bar, reduceIndex);
	gfloat category_x = 0.0;//when (bar_x >= leftLimitX && bar_x <= rightLimitX)
	if(bar_x < leftLimitX)
	{
		category_x = CATEGORY_GAP - clutter_actor_get_x(bar) - OVER_CATEGORY_WIDTH - CATEGORY_GAP;
		//if(!KEY_SELECT)
		//	clutter_actor_set_opacity(overlapShadow,255);
	}else{
		//if(!KEY_SELECT)
		//	clutter_actor_set_opacity(overlapShadow,0);
	}
	clutter_actor_set_x(fixedCategory, category_x);
}



static void cutCategory(void)
{
    //category 1 clip
	ClutterActor *movedCategory = clutter_actor_get_child_at_index(bar, extendIndex);
	gfloat bar_x = clutter_actor_get_x(bar);
	gfloat rightLimitX = SIDECATEGORY_GAP;
	gfloat leftLimitX = 0 - OVER_CATEGORY_WIDTH;

#if 0
    if (SCALE_RIGHT) {  // modify by lin89.zhang
        ClutterActor *categoryTitle = clutter_actor_get_child_at_index(movedCategory, 1);
    	gfloat titleOffset = 0.0;//when (bar_x >= leftLimitX && bar_x <= rightLimitX)
    	if(bar_x < leftLimitX)
    	{
    		titleOffset = 0 - clutter_actor_get_x(bar) - (SIDECATEGORY_GAP + OVER_CATEGORY_WIDTH);
    	}
    	clutter_actor_set_x(categoryTitle, titleOffset);
        //return;
    }
#endif
	
	gfloat diff = 0.0;//when (bar_x >= leftLimitX && bar_x <= rightLimitX)
	//if(bar_x < leftLimitX)
	{
		ClutterActor *cat0 = clutter_actor_get_child_at_index(bar, reduceIndex);
		ClutterActor *cat1 = clutter_actor_get_child_at_index(bar, extendIndex);
		//liang.wu consider scale right x diff
		//diff = 0 - clutter_actor_get_x(bar) - 
		//		(CATEGORY_GAP + OVER_CATEGORY_WIDTH) + extendCutXDiff_scaleRight + reduceCutXDiff_scaleRight;
		diff = (clutter_actor_get_x(cat0) + NORMAL_CATEGORY_WIDTH + reduceCutXDiff_scaleRight)
				- (clutter_actor_get_x(cat1)- extendCutXDiff_scaleRight);
		if(diff < 0)
		{
			diff = 0;
		}
		else
		{
			diff = diff * clutter_actor_get_width(cat1) / (clutter_actor_get_width(cat1) + extendCutXDiff_scaleRight);
		}
		if(diff < 0)
		{
			diff = 0;
		}
	}
	
	clutter_actor_set_clip(movedCategory, diff, 0-CATEGORY_COLOR_HEIGHT, SCENE_WIDTH*1000 - diff, 
							clutter_actor_get_height(movedCategory)+CATEGORY_COLOR_HEIGHT+BOTTOM_HEIGHT);

	// [shuhao.yan] need to kown the CLIP feature open status
	if (diff > 0.1)
	{
		CLIPFLAG = false;
	}
	else
	{
		CLIPFLAG = true;
	}

	//category 1 title adjust
	ClutterActor *categoryTitle = clutter_actor_get_child_at_index(movedCategory, CATEGORYTITLE_INDEX);
	gfloat titleOffset = 0.0;//when (bar_x >= leftLimitX && bar_x <= rightLimitX)
	//if(bar_x < leftLimitX)
	//{
		ClutterActor *cat0 = clutter_actor_get_child_at_index(bar, reduceIndex);
		ClutterActor *cat1 = clutter_actor_get_child_at_index(bar, extendIndex);
		//titleOffset = 0 - clutter_actor_get_x(bar) - (SIDECATEGORY_GAP + OVER_CATEGORY_WIDTH);
		titleOffset = (clutter_actor_get_x(cat0) + NORMAL_CATEGORY_WIDTH + reduceCutXDiff_scaleRight)
				- (clutter_actor_get_x(cat1) - extendCutXDiff_scaleRight);
		if(titleOffset < CATEGORY_TITLE_X)
		{
			titleOffset = CATEGORY_TITLE_X;
		}
		else
		{
			titleOffset = titleOffset * clutter_actor_get_width(cat1) / (clutter_actor_get_width(cat1) + extendCutXDiff_scaleRight);
		}

		if(titleOffset < CATEGORY_TITLE_X)
		{
			titleOffset = CATEGORY_TITLE_X;
		}
	//}
	clutter_actor_set_x(categoryTitle, titleOffset);

	//ad clip
	gfloat adDiff = 0.0;
	if(FirstScreenADControl::GetInstance()->IsEnable())
	{
		ClutterActor *cat0 = clutter_actor_get_child_at_index(bar, reduceIndex);
		ClutterActor *cat1 = clutter_actor_get_child_at_index(bar, extendIndex);
		ClutterActor *cat2 = clutter_actor_get_child_at_index(bar, adIndex);

		adDiff = (clutter_actor_get_x(cat0) + clutter_actor_get_width(cat0) + reduceCutXDiff_scaleRight)
					- (clutter_actor_get_x(cat2) - adCutXDiff_scaleRight);
		clutter_actor_set_clip(cat2, adDiff, 0-CATEGORY_COLOR_HEIGHT, SCENE_WIDTH*1000 - adDiff, 
								clutter_actor_get_height(cat2)+CATEGORY_COLOR_HEIGHT+BOTTOM_HEIGHT);

		// [shuhao.yan] need to kown the CLIP feature open status
		if (adDiff > 0.1)
		{
			CLIPFLAG = false;
		}
		else
		{
			CLIPFLAG = true;
		}
	}

	if(diff > 0 || adDiff > 0)
	{
		if(!KEY_SELECT)
		{
			clutter_actor_set_opacity(overlapShadow, 255);
		}
	}
	else
	{
		if(!KEY_SELECT)
		{
			clutter_actor_set_opacity(overlapShadow, 0);
		}
	}
}
//[End]category move and clip[liang.wu]

static void extendCallback(int seqIndex, int categoryIndex)
{
	if(seqIndex == 0)
	{
		// before extend cb
		{
			ClutterActor *temp = clutter_actor_get_child_at_index(bar, categoryIndex);
			ClutterActor *categoryWrapper = clutter_actor_get_child_at_index(temp, CATEGORYWRAPPER_INDEX);
			map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(categoryWrapper);
			FirstScreenCategory* ctr = NULL;
			if (it != categoryActorMap.end())
			{
				ctr = it->second;
			}
			if (ctr != NULL && ctr->onExtendCallback.isFunction())
			{
				ScriptArray arr;
				arr.set(0, ctr->jsInstance);

				ctr->onExtendCallback.invoke(arr);
			}
		}
	}
	else if(seqIndex == 1)
	{
		// after extend cb
		{
			ClutterActor *temp = clutter_actor_get_child_at_index(bar, categoryIndex);
			ClutterActor *categoryWrapper = clutter_actor_get_child_at_index(temp, CATEGORYWRAPPER_INDEX);
			map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(categoryWrapper);
			FirstScreenCategory* ctr = NULL;
			if (it != categoryActorMap.end())
			{
				ctr = it->second;
			}
			if (ctr != NULL && ctr->onExtendEndCallback.isFunction())
			{
				ScriptArray arr;
				arr.set(0, ctr->jsInstance);
				ctr->onExtendEndCallback.invoke(arr);
			}
		}
	}
}

static void extendCategory(int index)
{
	extendIndex = index;

	int itemCount = 0;

	ClutterActor *temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
	curCategoryWidth[extendIndex] = clutter_actor_get_width(temp1);
	ClutterActor *categoryWrapper = clutter_actor_get_child_at_index(temp1, CATEGORYWRAPPER_INDEX);

	ClutterActor *temp = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);

	itemCount = clutter_actor_get_n_children(temp);
	if(itemCount == 0)
	{
		return;
	}

	//fix the exchange hide item problem
#if 1
	int rightLimit = 0;
	int i = 0;
	for (i = 0; i < itemCount; i++)
	{
		if(SIDECATEGORY_GAP+NORMAL_CATEGORY_WIDTH+CATEGORY_GAP+(i+1)*NORMAL_CONTENTS_WIDTH > SCENE_WIDTH) 
		{
			rightLimit = i;
			break;
		}

		if(i == itemCount - 1)
		{
			rightLimit = itemCount - 1;
		}
	}
	for(i = 0; i < itemCount; i++)
	{		
		ClutterActor *temp3 = clutter_actor_get_child_at_index(temp, i);

		if(i < rightLimit + 1)
		{
			clutter_actor_show_all(temp3);
		}
		else
		{
			clutter_actor_hide_all(temp3);
		}
	}
#else
/*
	clutter_actor_show_all(temp);
	ClutterActor *list = getListWrapper(index);
	for (int i = 0; i < clutter_actor_get_n_children(list); ++i)
	{
	    clutter_actor_show_all(clutter_actor_get_child_at_index(list, i));
	}
*/
#endif

	if(exchangeControlStep >= 1)
	{
#if 1
		if(isKeyControl)
		{
			toFocusContents(extendIndex, 0, 0);
		}

		if(isKeyControl)
		{
			for(int i = 1; i< itemCount; i++)
			{
				ClutterActor* prepareChild = clutter_actor_get_child_at_index(temp,i);
				clutter_actor_set_x(prepareChild,FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH);
			}
		}
#endif

		if(!isKeyControl)
		{
			for(int i = 0; i< itemCount; i++)
			{
				ClutterActor* prepareChild = clutter_actor_get_child_at_index(temp,i);
				clutter_actor_set_x(prepareChild,0);
			}
		}

	}
	else
	{
		toFocusContents(extendIndex, 0, 0);
		for(int i = 1; i< itemCount; i++)
		{
			toNormalContents(extendIndex, i, FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH); 
		}
	}

	curListWidth[extendIndex] = clutter_actor_get_width(temp);

	scaleFactor[extendIndex] = curCategoryWidth[extendIndex] / curListWidth[extendIndex];

	clutter_actor_set_scale(temp, scaleFactor[extendIndex], 1);

	//cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 200;

	EXTEND_FLAG = true;

	//add by junhui.wang [add the card effect]
	if(exchangeControlStep >= 1)
	{
		reverseChildIndex(temp);
	}
}

static void extendEffect()
{
	gfloat transWidth;
	gfloat transOpacity;
	gfloat transScale;
	gfloat transPosition;
	gfloat transTitlePosition;
	gfloat transBorderWidth;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;

	///////////////////////////////////////////////category//////////////////////////////////////////////////////

	transWidth = curCategoryWidth[extendIndex] - (curCategoryWidth[extendIndex] - curListWidth[extendIndex])*extendDiff;
	transOpacity = OPACITY_100*(1 - extendDiff);
	transScale = 1 - (1 - curListWidth[extendIndex]/curCategoryWidth[extendIndex])*extendDiff;
	transPosition = CATEGORY_TITLE_Y - (CATEGORY_TITLE_Y - EXTEND_CATEGORY_TITLE_Y)*extendDiff;
	transBorderWidth = (curCategoryWidth[extendIndex] - 4) - ((curCategoryWidth[extendIndex] - 4) - (curListWidth[extendIndex] - 4))*extendDiff;

	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, extendIndex);

	clutter_actor_set_width(temp1, transWidth);

	if(extendIndex == 0 && clutter_actor_get_next_sibling(temp1) != NULL)
	{
		clutter_actor_set_x(clutter_actor_get_next_sibling(temp1), transWidth + CATEGORY_GAP);
	}

	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, 1);
	//[liang.wu]category title effect
	/*
	gfloat titleTransOpacity = OPACITY_70 * extendDiff;
	if(extendDiff < exchangeBindRatio)
	{
		titleTransOpacity = OPACITY_70 * 0.0;
		clutter_actor_set_opacity(temp2, titleTransOpacity);
	}
	else
	{
		clutter_actor_set_opacity(temp2, titleTransOpacity);

		//position
		clutter_actor_set_x(temp2, CATEGORY_TITLE_X);
		clutter_actor_set_y(temp2, - (clutter_actor_get_height(temp2) + CATEGORY_TITLE_Y));
	}
	*/

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYWRAPPER_INDEX);

	clutter_actor_set_width(temp2, transWidth);
	gfloat opacity_set = OPACITY_100*(1 - extendDiff*10);//more quickly disappear
	if(opacity_set < 0)
	{
		opacity_set = 0;
	}
	clutter_actor_set_opacity(temp2, opacity_set);

	//category live
	FirstScreenCategoryLiveControl::GetInstance()->SetScale(temp2, transScale, 1);

	///////////////////////////////////////////////contents//////////////////////////////////////////////////////

	transScale = scaleFactor[extendIndex] - (scaleFactor[extendIndex] - 1)*extendDiff;
	transOpacity = OPACITY_100*extendDiff;

	//listWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);

	clutter_actor_set_scale(temp2, transScale, 1);
	clutter_actor_set_opacity(temp2, transOpacity);

	//add by junhui.wang [add the card effect]
	if(exchangeControlStep >= 1)
	{
		cardExtendEffect(temp2);

		if(isKeyControl)
		{
			//4 do fovea featured when isKeyControl == true
			ClutterActor* listWrapper = getListWrapper(extendIndex);
			int itemCount = clutter_actor_get_n_children(listWrapper);
			if(itemCount == 0)
			{
				return;
			}
			verticalDiff = extendDiff;
			foveaFeaturedOpenEx(extendDiff, itemCount-1);
		}
	}
}

static void reduceCategory(int index)
{	
	reduceIndex = index;

	ClutterActor *temp = clutter_actor_get_child_at_index(bar, reduceIndex);
	ClutterActor *categorywrapper = clutter_actor_get_child_at_index(temp, CATEGORYWRAPPER_INDEX);
	ClutterActor * listWrapper;
	
	curListWidth[reduceIndex] = clutter_actor_get_width(temp);

	scaleFactor[reduceIndex] = NORMAL_CATEGORY_WIDTH / curListWidth[reduceIndex];
	
	curCategoryTitleX[reduceIndex] = clutter_actor_get_x(clutter_actor_get_child_at_index(temp, CATEGORYTITLE_INDEX));
	
	//clutter_actor_set_x(liveP1, 0);
	//clutter_actor_set_x(liveP3, 0);

	ClutterActor *tempChild = NULL;
	ClutterActor *tempcategorywrapper = NULL;
	
	if(clutter_actor_get_n_children(bar) >= 2)
	{
		// reduce define process shuhao.yan
		tempChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		tempcategorywrapper = clutter_actor_get_child_at_index(tempChild, CATEGORYWRAPPER_INDEX);
		FirstScreenCategoryLiveControl::GetInstance()->SetType(tempcategorywrapper);
		FirstScreenCategoryLiveControl::GetInstance()->RefreshFrame(true);
	}
	
	//modify by junhui.wang
	listWrapper = temp = clutter_actor_get_child_at_index(temp, CATEGORY_LISTWRAPPER_INDEX);

	int itemCount = clutter_actor_get_n_children(temp);
	if(itemCount == 0)
	{
		return;
	}

	//reset contents fovea
	contentLiveTick = 0;
	contentLiveImage();

	temp = clutter_actor_get_child_at_index(temp, CONTENTSWRAPPER_INDEX);

	for(int i = 1; i< itemCount; i++)
	{
		toNormalContents(reduceIndex, i, clutter_actor_get_width(temp) - NORMAL_CONTENTS_WIDTH);
	}

	//add by junhui.wang [add the card effect]
	if(exchangeControlStep >= 1)
	{
		reverseChildIndex(listWrapper);
	}
	REDUCE_FLAG = true;
}

static void reduceEffect()
{
	gfloat transWidth;
	gfloat transOpacity;
	gfloat transScale;
	gfloat transPosition;
	gfloat transTitlePosition;
	gfloat transBorderWidth;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;

	///////////////////////////////////////////////category//////////////////////////////////////////////////////

	transWidth = curListWidth[reduceIndex] - (curListWidth[reduceIndex] - NORMAL_CATEGORY_WIDTH)*reduceDiff;
	transOpacity = OPACITY_100*reduceDiff;
	transScale = curListWidth[reduceIndex]/NORMAL_CATEGORY_WIDTH - (curListWidth[reduceIndex]/NORMAL_CATEGORY_WIDTH - 1)*reduceDiff;
	transPosition = EXTEND_CATEGORY_TITLE_Y - (EXTEND_CATEGORY_TITLE_Y - CATEGORY_TITLE_Y)*reduceDiff;
	transBorderWidth = (curListWidth[reduceIndex] - 4) - ((curListWidth[reduceIndex] - 4) - (NORMAL_CATEGORY_WIDTH - 4))*reduceDiff;

	//barChild
	temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);
	clutter_actor_set_width(temp1, transWidth);
	
	//categoryTitle
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);
	//[liang.wu]category title effect
	if(exchangeControlStep >= 1)
	{
		gfloat titleTransOpacity = OPACITY_70 * (1.0 - reduceDiff * 1.5);
		if(titleTransOpacity < 0.0)
		{
			titleTransOpacity = 0.0;
		}
		clutter_actor_set_opacity(temp2, titleTransOpacity);
	}

	//categoryWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYWRAPPER_INDEX);

	clutter_actor_set_width(temp2, transWidth);
	if(reduceDiff == 1.0)
		clutter_actor_set_opacity(temp2, transOpacity);
	else
		clutter_actor_set_opacity(temp2, 0);

	//category live
	FirstScreenCategoryLiveControl::GetInstance()->SetScale(temp2, transScale, 1);
	FirstScreenCategoryLiveControl::GetInstance()->SetOpacity(temp2, OPACITY_70*reduceDiff);

	///////////////////////////////////////////////contents//////////////////////////////////////////////////////

	transScale = 1 - (1 - scaleFactor[reduceIndex])*reduceDiff;
	transOpacity = OPACITY_100*(1 - reduceDiff);

	//listWrapper
	temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);

	clutter_actor_set_scale(temp2, transScale, 1);
	clutter_actor_set_opacity(temp2, transOpacity);

	//[liang.wu]overlapShadow effect
	//gfloat shadowTransOpacity = OPACITY_100 * (1.0 - reduceDiff);
	clutter_actor_set_opacity(overlapShadow, 0.0);

	//add by junhui.wang [add the card effect]
	if(exchangeControlStep >= 1)
	{
		cardReduceEffect(temp2);
	}
}

//[Begin]exchange animation functions[liang.wu]
static void recoverCategory(void)
{
	//bar need to x=0
	recoverDistanceToBar = SIDECATEGORY_GAP - clutter_actor_get_x(bar);

	//category 1 need to be extend
	ClutterActor *categoryBegin = clutter_actor_get_child_at_index(bar, extendIndex);
	recoverDistanceToBegin = 0 - clutter_actor_get_x(categoryBegin);

	//category 0 need to be reduce
	ClutterActor *categoryEnd = clutter_actor_get_child_at_index(bar, reduceIndex);
	recoverDistanceToEnd = NORMAL_CATEGORY_WIDTH + CATEGORY_GAP - clutter_actor_get_x(categoryEnd);

	//category 0 title need to move
	ClutterActor *categoryTitle = clutter_actor_get_child_at_index(categoryEnd, CATEGORYTITLE_INDEX);
	recoverDistanceToTitle = CATEGORY_TITLE_X - clutter_actor_get_x(categoryTitle);

	RECOVER_FLAG = true;
}

static void recoverEffect(void)
{
	//move bar x
	gfloat bar_x = SIDECATEGORY_GAP - recoverDistanceToBar * (1.0 - recoverDiff);
	clutter_actor_set_x(bar, bar_x);

	//move extend category x
	gfloat category1_x = 0 - recoverDistanceToBegin * (1.0 - recoverDiff);
	ClutterActor *category1 = clutter_actor_get_child_at_index(bar, extendIndex);
	clutter_actor_set_x(category1, category1_x);

	//move reduce category x
	gfloat category2_x = NORMAL_CATEGORY_WIDTH + CATEGORY_GAP - recoverDistanceToEnd * (1.0 - recoverDiff);
	ClutterActor *category2 = clutter_actor_get_child_at_index(bar, reduceIndex);
	clutter_actor_set_x(category2, category2_x);

	//move reduce category
	gfloat category2_title_x = CATEGORY_TITLE_X - recoverDistanceToTitle * (1.0 - recoverDiff);
	ClutterActor *categoryTitle = clutter_actor_get_child_at_index(category2, CATEGORYTITLE_INDEX);
	clutter_actor_set_x(categoryTitle, category2_title_x);
}

static void exchangeCategory(void)
{
	ClutterActor *child = clutter_actor_get_child_at_index(bar, extendIndex);
	exchangeDistanceToLeft = clutter_actor_get_width(child) + CATEGORY_GAP;
	exchangeDistanceToRight = NORMAL_CATEGORY_WIDTH + CATEGORY_GAP;

	//animation start
	EXCHANGE_FLAG = true;
}

static void exchangeEffect()
{
	//4 turn left
	ClutterActor *child1 = clutter_actor_get_child_at_index(bar, reduceIndex);//for reduce to left
	clutter_actor_set_x(child1, exchangeDistanceToLeft - exchangeDistanceToLeft * exchangeDiffToLeft);

	//category title
	ClutterActor *child1Title = clutter_actor_get_child_at_index(child1, 1);

	//category title opacty
	if(!REDUCE_FLAG)
	{
		gfloat titleTransOpacity1 = OPACITY_70 * exchangeDiffToLeft;
		clutter_actor_set_opacity(child1Title, titleTransOpacity1);
		//LOG_DEBUG(logger, "[liang.wu] exchange 0 title opacity = " << titleTransOpacity1);
	}

	//4 turn right
	ClutterActor *child2 = clutter_actor_get_child_at_index(bar, extendIndex);//for extend to right
	clutter_actor_set_x(child2, exchangeDistanceToRight * exchangeDiffToRight);

	//category title
	//ClutterActor *child2Title = clutter_actor_get_child_at_index(child2, 1);

	//category title opacty
	/*
	if(!EXTEND_FLAG)
	{
		gfloat titleTransOpacity2 = OPACITY_70 * (1.0-exchangeDiffToRight);
		clutter_actor_set_opacity(child2Title, titleTransOpacity2);
		//LOG_DEBUG(logger, "[liang.wu] exchange 1 title opacity = " << titleTransOpacity2);
	}
	*/

	//category wrapper
	ClutterActor *child2Wrapper = clutter_actor_get_child_at_index(child2, 0);
	FirstScreenCategoryLiveControl::GetInstance()->SetOpacity(child2Wrapper, OPACITY_70*(1.0-exchangeDiffToRight));
}

static void exchangeControler()
{
	exchangeControlStep++;

	//steps
	if(exchangeControlStep == 1)
	{
		if(FirstScreenADControl::GetInstance()->IsEnable())
		{
			ClutterActor *child1 = clutter_actor_get_child_at_index(bar, reduceIndex);
			ClutterActor *child2 = clutter_actor_get_child_at_index(bar, extendIndex);
			ClutterActor *child3 = clutter_actor_get_child_at_index(bar, adIndex);
			
			clutter_actor_remove_clip(child1);//to extend
			clutter_actor_remove_clip(child2);//to reduce
			clutter_actor_remove_clip(child3);//to AD

			reduceIndex = 0;
			adIndex = 1;
			extendIndex = 2;
			
			clutter_actor_set_child_at_index(bar, child2, reduceIndex);//reduce
			clutter_actor_set_child_at_index(bar, child3, adIndex);//AD
			clutter_actor_set_child_at_index(bar, child1, extendIndex);//extend
		}
		else
		{
			ClutterActor *child1 = clutter_actor_get_child_at_index(bar, reduceIndex);//extend
			ClutterActor *child2 = clutter_actor_get_child_at_index(bar, extendIndex);//reduce
			
			clutter_actor_remove_clip(child1);//extend
			clutter_actor_remove_clip(child2);//reduce
			
			clutter_actor_set_child_at_index(bar, child2, reduceIndex);//reduce
			clutter_actor_set_child_at_index(bar, child1, extendIndex);//extend

			reduceIndex = 0;
			extendIndex = 1;
		}

		// before extend cb
		extendCallback(0, extendIndex);

		//global cursor		
		clutter_actor_set_opacity(globalCursor,0);

		reduceCategory(reduceIndex);
		recoverCategory();//must behind reduce
		exchangeCategory();

		EVENT_FLAG = false;
	}
	else if(exchangeControlStep == 2)
	{
		extendCategory(extendIndex);
	}
	else
	{
		// after extend cb
		extendCallback(1, extendIndex);

		if(FirstScreenADControl::GetInstance()->IsEnable())
		{
			ClutterActor *child1 = clutter_actor_get_child_at_index(bar, reduceIndex);//reduced
			ClutterActor *child2 = clutter_actor_get_child_at_index(bar, adIndex);//ad
			ClutterActor *child3 = clutter_actor_get_child_at_index(bar, extendIndex);//extended

			reduceIndex = 0;
			extendIndex = 1;
			adIndex = 2;

			clutter_actor_set_child_at_index(bar, child1, reduceIndex);//reduce
			clutter_actor_set_child_at_index(bar, child3, extendIndex);//extend
			clutter_actor_set_child_at_index(bar, child2, adIndex);//AD
		}
		reduceIndex = 0;
		extendIndex = 1;
		exchangeControlStep = 0;//reset

		isOpen[0] = false;
		isOpen[1] = true;

		if(isKeyControl)
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
			timeID++;
			ContextMenu::setTimeout(timeID);
		}
		else
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH/2;
		}
		EVENT_FLAG = true;
	}
}
//[End]exchange animation functions[liang.wu]

void FirstScreenListWidget::removeCategory(int categoryIndex)
{
	EVENT_FLAG = false;

	ClutterActor *removeCategory = clutter_actor_get_child_at_index(bar, categoryIndex);

	// remove from map
	map<ClutterActor*, FirstScreenCategory*>::iterator it = categoryActorMap.find(removeCategory);
	if (it != categoryActorMap.end())
	{
		std::string id = it->second->id;
		categoryActorMap.erase(it);

		if (!id.empty())
		{
			map<std::string, FirstScreenCategory*>::iterator tagIt = categoryTagMap.find(id);
			if (tagIt != categoryTagMap.end())
			{
				categoryTagMap.erase(tagIt);
			}
		}
	}

	clutter_actor_destroy_all_children(removeCategory);

	clutter_actor_remove_child(bar, removeCategory); 
	
	extendCategory(0);	
	
	isOpen[0] = true;
	isOpen[1] = false;

}


static void extendAnimation()
{
	if(clutter_actor_get_n_children(getListWrapper(reduceIndex)) == 0)
	{
		return;
	}
	
	EVENT_FLAG = false;

	//reset the flag
	exchangeControlStep = 0;
	REDUCE_FLAG = false;
	reduceTick = 0;
	RECOVER_FLAG = false;
	recoverTick = 0;
	EXCHANGE_FLAG = false;
	exchangeTick = 0;
	EXTEND_FLAG = false;
	extendTick = 0;

	exchangeControler();	//ready for exchange
}

void FirstScreenListWidget::callExtendAnimationEx()
{
	if(clutter_actor_get_n_children(bar) <= 1)
	{
		return;//error
	}
	
	extendAnimation();
}

void FirstScreenListWidget::callExtendAnimation()
{
	if(clutter_actor_get_n_children(bar) <= 1)
	{
		return;//error
	}
	
	if(clutter_actor_get_n_children(getListWrapper(reduceIndex)) == 0)
	{
		return;
	}
	
	EVENT_FLAG = false;
	
	if(clutter_actor_get_n_children(bar) >= 2)
	{
		// shuhao.yan 1211
		clutter_actor_set_x(bar, SIDECATEGORY_GAP);
		goal_position = SIDECATEGORY_GAP;
		
		clutter_actor_set_y(bar, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		exchangeControlStep = 0;

		KEY_LEFT = false;
		KEY_RIGHT = false;

		//global cursor
		clutter_actor_set_opacity(globalCursor,0);

		ClutterActor *child1 = clutter_actor_get_child_at_index(bar, reduceIndex);
		ClutterActor *child2 = clutter_actor_get_child_at_index(bar, extendIndex);

		clutter_actor_remove_clip(child1);
		clutter_actor_remove_clip(child2);

		clutter_actor_set_x(child2, 0);
		clutter_actor_set_x(child1, NORMAL_CATEGORY_WIDTH + CATEGORY_GAP);

		clutter_actor_set_child_at_index(bar, child2, reduceIndex);
		clutter_actor_set_child_at_index(bar, child1, extendIndex);

		// before extend cb
		extendCallback(0, extendIndex);

		extendDiff = 1.0;
		reduceDiff = 1.0;
		recoverDiff = 1.0;
		exchangeDiffToLeft = 1.0;
		exchangeDiffToRight = 1.0;
		
		reduceCategory(reduceIndex);
		recoverCategory();
		exchangeCategory();
		
		reduceEffect();
		recoverEffect();
		exchangeEffect();
		
		extendCategory(extendIndex);
		extendEffect();

		REDUCE_FLAG = false;
		RECOVER_FLAG = false;
		EXCHANGE_FLAG = false;
		EXTEND_FLAG = false;

		// after extend cb
		extendCallback(1, extendIndex);

		if(NO_CONTENTS_FLAG)
		{
			setGlobalCursorX(SIDECATEGORY_GAP);
			setGlobalCursorWidth(FOCUS_CATEGORY_WIDTH);
		}
		else
		{
			setGlobalCursorX(SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP);
		}
		
		//lin89.zhang set shadow effect
		fixOverlapShadow();

		isOpen[0] = false;
		isOpen[1] = true;
		
		REDUCE_FLAG = false;
		EXTEND_FLAG = false;
	}

	tick = 0;
	//livetick = 0;
	FirstScreenCategoryLiveControl::GetInstance()->RefreshFrame(true);
	contentLiveTick = 0;	
	std::string tempName;
	tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, reduceIndex));		
	if(tempName.compare("featured") == 0)
	{
		CONTENT_LIVE_FLAG = false;
		FirstScreenCategoryLiveControl::GetInstance()->EnableFeaturedLiveReal(true);
	}
	else
	{
		CONTENT_LIVE_FLAG = true;
		FirstScreenCategoryLiveControl::GetInstance()->EnableFeaturedLiveReal(false);
	}

	if(isKeyControl){
		if(clutter_actor_get_n_children(bar) == 1)
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
		}
		else if(clutter_actor_get_n_children(bar) >= 2)
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
		}
	}else{
		if(clutter_actor_get_n_children(bar) == 1)
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
		}
		else if(clutter_actor_get_n_children(bar) >= 2)
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH/2;
		}
	}

	move_rect();
	EVENT_FLAG = true;
}

static void call_startTransitionCallback(ClutterActor * contentWrapper) 
{
	FirstScreenContents* ctr = NULL;
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
	}

	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->startTransitionCallback.invoke(arr);
	}
}

static void call_stopTransitionCallback(ClutterActor * contentWrapper) 
{
	FirstScreenContents* ctr = NULL;
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
	}

	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->stopTransitionCallback.invoke(arr);
	}
}

static void on_transition3() 
{
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, DOMINANT_INDEX);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, MAIN_INDEX);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, OVERRAY_INDEX);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, TITLEPARENT_INDEX);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, CATEGORYTITLE_INDEX);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, SUBMAIN_INDEX);
	ClutterActor * icon1 =  clutter_actor_get_child_at_index(dominant, ICON1_INDEX);
	ClutterActor * icon2 =  clutter_actor_get_child_at_index(dominant, ICON2_INDEX);
	
	Diff_transition = bezier(count_transition,COUNT_TRANSITION_FRAME, transition[0], transition[1], transition[2], transition[3]);



	gfloat Delta_width	= FOCUS_CONTENTS_WIDTH + (t_delta_width * Diff_transition);
	gfloat Delta_height = WIDGET_HEIGHT + (t_delta_height * Diff_transition);

	gfloat Scala_width =  FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH * (1 - (1 - t_delta_scala_width) * Diff_transition);
	gfloat Scala_height = WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT * (1 - (1 - t_delta_scala_height) * Diff_transition);
	
	clutter_actor_set_x(bar, p_x_bar_start - (t_delta_width * Diff_transition) / 2 );
	clutter_actor_set_y(contentWrapper, p_y_start - (t_delta_height * Diff_transition));
	clutter_actor_set_position(titleParent, p_x_title_start + (t_delta_width * Diff_transition) / 2, p_y_title_start + (t_delta_height * Diff_transition));	

	//other item
	int count  = clutter_actor_get_n_children(listWrapper);

	gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
	int startindex = (currentContents - 10 < 0) ? 0 : currentContents - 10;
	int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;

	for(int i = startindex; i < Maxcount; i++) 
	{
		if(i ==  currentContents) {
			continue;
		}

		ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
		clutter_actor_set_opacity(temp, 255 * (1 - Diff_transition));

		if(currentContents < i) {
			clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (Delta_width - contentWrapper_width));
		}
	}
	
	if(extendIndex == 1) {
		ClutterActor * otherCategoryItem = clutter_actor_get_child_at_index(bar, reduceIndex);
		clutter_actor_set_opacity(otherCategoryItem, 255 * (1 - Diff_transition));
		clutter_actor_set_opacity(overlapShadow, 255 * (1 - Diff_transition));
		//clutter_actor_set_opacity(overlapShadow,0);
		if(FirstScreenADControl::GetInstance()->IsEnable())
		{
			//ClutterActor * adCategoryItem = clutter_actor_get_child_at_index(bar, adIndex);
			//clutter_actor_set_opacity(adCategoryItem, 255 * (1 - Diff_transition));
			FirstScreenADControl::GetInstance()->SetOpacity(255*(1-Diff_transition));
		}
	}
	clutter_actor_set_opacity(categoryTitle, 255 * (1 - Diff_transition));
	clutter_actor_set_opacity(titleParent, 255 * (1 - Diff_transition));

	clutter_actor_set_size(contentWrapper, Delta_width, Delta_height);
	clutter_actor_set_size(dominant, Delta_width, Delta_height);
	clutter_actor_set_clip(dominant,0,0,Delta_width,Delta_height);
	clutter_actor_set_scale(image, Scala_width, Scala_height);

	//set the icon's postion
	ClutterActor * current;
	gfloat iconParentWidth1,iconParentWidth2,iconParentHeight;
	//iconParent1
	current = icon1;	
	clutter_actor_get_size(current, &iconParentWidth1, &iconParentHeight);
	clutter_actor_set_position(current, Delta_width - ICON_RIGHT_GAP - iconParentWidth1, Delta_height - ICON_BOTTOM_GAP - iconParentHeight);
	//iconParent2
	current = icon2;
	clutter_actor_get_size(current, &iconParentWidth2, &iconParentHeight);
	clutter_actor_set_position(current, Delta_width - ICON_GAP - ICON_RIGHT_GAP - iconParentWidth1- iconParentWidth2, Delta_height - ICON_BOTTOM_GAP - iconParentHeight);
	
	if(clutter_actor_get_width(subMain) != 10) {
		clutter_actor_set_scale(subMain, Scala_width, Scala_height);
	}

	clutter_actor_set_opacity(overray, 0);

	if (clutter_actor_get_n_children(contentWrapper) > CONTENT_OPTION_INDEX)
	{
		ClutterActor * temp2 = clutter_actor_get_child_at_index(contentWrapper, CONTENT_OPTION_INDEX);
		clutter_actor_set_opacity(temp2, 0);
	}
	

	if(!ON_TRANSITION) 
	{				
		count_transition++;

		if(count_transition > COUNT_TRANSITION_FRAME) 
		{
			KEY_SELECT = false;
			ON_TRANSITION = true;
			STOP_FLAG = true;
			clutter_timeline_stop(timeline);
			
			call_startTransitionCallback(contentWrapper);
		}
	}
	else 
	{
		count_transition--;

		if(count_transition < 0) 
		{
			
			KEY_SELECT = false;
			ON_TRANSITION = false;
			
			ClutterActor * liveImg1			= clutter_actor_get_child_at_index(image, LIVECONTENTS1_INDEX);
			ClutterActor * liveImg2			= clutter_actor_get_child_at_index(image, LIVECONTENTS2_INDEX);
			ClutterActor * liveIcon			= clutter_actor_get_child_at_index(image, LIVECONTENTS3_INDEX);

			if(liveImg1 != NULL && liveImg2 != NULL ) {
				CONTENT_LIVE_FLAG = true;
				contentLiveTick =  0;
			}
			
			call_stopTransitionCallback(contentWrapper);
		}
	}
}

static void set_startapp_animation3() 
{
	bool skipTransition = false;
	FirstScreenContents* ctr = NULL;
	//begin junhui.wang
	bool isKeyControl_bak;
	//end junhui.wang
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, DOMINANT_INDEX);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, MAIN_INDEX);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, TITLEPARENT_INDEX);

	ClutterActor * liveImg1			= clutter_actor_get_child_at_index(image, LIVECONTENTS1_INDEX);
	ClutterActor * liveImg2			= clutter_actor_get_child_at_index(image, LIVECONTENTS2_INDEX);
	ClutterActor * liveIcon			= clutter_actor_get_child_at_index(image, LIVECONTENTS3_INDEX);

	//begin junhui.wang
	if(!isKeyControl){
		isKeyControl_bak = isKeyControl;
		isKeyControl = true;
		//toFocusContents(currentCategory,currentContents,clutter_actor_get_x(categoryItem));	
		ClutterActor *temp1 = NULL;
		ClutterActor *temp2 = NULL;
		ClutterActor *temp3 = NULL;
		//barChild
		temp1 = clutter_actor_get_child_at_index(bar, currentCategory);
		//contentsWrapper
		temp1 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		temp1 = clutter_actor_get_child_at_index(temp1, currentContents);
		clutter_actor_set_width(temp1, FOCUS_CONTENTS_WIDTH);
		//modify by junhui.wang[fix the x error]
		//clutter_actor_set_x(temp1, clutter_actor_get_x(categoryItem)+(NORMAL_CONTENTS_WIDTH*currentContents));
		clutter_actor_set_x(temp1,(NORMAL_CONTENTS_WIDTH*currentContents));
		//dominant
		temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
		clutter_actor_set_width(temp2, FOCUS_CONTENTS_WIDTH);
		clutter_actor_set_opacity(temp2, OPACITY_100);
		clutter_actor_set_clip(temp2,0,0,FOCUS_CONTENTS_WIDTH,WIDGET_HEIGHT);
		clutter_actor_set_height(temp2,WIDGET_HEIGHT);
		//main
		temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);
		clutter_actor_set_scale(temp3, FOCUS_CONTENTS_WIDTH / NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT / WIDGET_HEIGHT);
		//overRay
		temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
		clutter_actor_set_width(temp3, FOCUS_CONTENTS_WIDTH);
		clutter_actor_set_y(temp3, WIDGET_HEIGHT);
		clutter_actor_set_opacity(temp3,0);
		//iconParent1
		temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);
		clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH - ICON_RIGHT_GAP - clutter_actor_get_width(temp3));
		//iconParent2
		temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
		clutter_actor_set_x(temp3, FOCUS_CONTENTS_WIDTH - ICON_GAP - ICON_RIGHT_GAP - clutter_actor_get_width(clutter_actor_get_previous_sibling(temp3)) - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
		//subMain
		temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);
		if(clutter_actor_get_width(temp3) != 10.0f)
		{
			clutter_actor_set_scale(temp3, FOCUS_CONTENTS_WIDTH / NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT / CONTENTS_IMAGE_HEIGHT);
			clutter_actor_set_opacity(temp3, OPACITY_100);
			clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), 0);
		}
		
		//titleParent
		temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);
		clutter_actor_set_y(temp2, WIDGET_HEIGHT);
		//title1
		temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
		//clutter_actor_set_x(temp3, (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2);
		clutter_actor_set_opacity(temp3, 0);
		//title2
		temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
		//clutter_actor_set_x(temp3, (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2);
		clutter_actor_set_opacity(temp3, OPACITY_100);
	
		//progressN & Dim
		if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
		{
			temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
			ProgressController::updateProgressFoveaStatus(temp2, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		}
	}else{
		isKeyControl_bak = isKeyControl;
	}
	//end junhui.wang
		
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		skipTransition = ctr->skipTransition; 
	}

	
	if (ctr != NULL && skipTransition && !ON_TRANSITION)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);

		ctr->onClickCallback.invoke(arr);

		return;
	}

	KEY_RIGHT = false;
	KEY_LEFT = false;
	
	if(!ON_TRANSITION) 
	{
		count_transition = 0;

		if(extendIndex == 0) {
			cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2 + (currentContents) * NORMAL_CONTENTS_WIDTH;
		}
		else {
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2 + (currentContents) * NORMAL_CONTENTS_WIDTH;
		}

		move_rect();

		if(liveImg1 != NULL && liveImg2 != NULL ) {
			CONTENT_LIVE_FLAG = false;
			clutter_actor_set_scale(liveIcon, 1, 1);
			clutter_actor_set_x(liveImg1, NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(liveImg2, NORMAL_CONTENTS_WIDTH);
			contentLiveTick =  0;
		}
		
		int ohtreCagtegoryIndex = (currentCategory == 0) ? 1 : 0;
		ClutterActor * otherCategory	= clutter_actor_get_child_at_index(bar, ohtreCagtegoryIndex);
		ClutterActor * otherCateWrapper	= clutter_actor_get_child_at_index(otherCategory, 0);

		t_delta_width	= FOCUS_CONTENTS_WIDTH * 0.3;
		t_delta_height	= WIDGET_HEIGHT * 0.3;

		t_delta_scala_width = FOCUS_CONTENTS_WIDTH * (1.3) / FOCUS_CONTENTS_WIDTH;
		t_delta_scala_height = WIDGET_HEIGHT * (1.3) / WIDGET_HEIGHT;

		p_x_bar_start = clutter_actor_get_x(bar);
		p_x_start = clutter_actor_get_x(contentWrapper);
		p_y_start = clutter_actor_get_y(contentWrapper);
		p_x_title_start = clutter_actor_get_x(titleParent);
		p_y_title_start = clutter_actor_get_y(titleParent);

		//global cursor
		clutter_actor_set_opacity(globalCursor,0);

		KEY_SELECT = true;

		//begin junhui.wang
		isKeyControl = isKeyControl_bak;
		//end junhui.wang

		if (ctr != NULL)
		{
			ScriptArray arr;
			arr.set(0, ctr->jsInstance);

			ctr->onClickCallback.invoke(arr);
		}
	}
	else
	{
		KEY_RIGHT = false;
		KEY_LEFT = false;
	
		count_transition = COUNT_TRANSITION_FRAME;

		KEY_SELECT = true;
	}
}

static void set_startapp_animation4(){
	bool skipTransition = false;
	FirstScreenContents* ctr = NULL;	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, currentCategory);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
		skipTransition = ctr->skipTransition; 
	}
	if (ctr != NULL && skipTransition)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);

		ctr->onClickCallback.invoke(arr);

		return;
	}

	//if skipTransition, do not need to fall
	instance->fallFirstScreen();

	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);

		ctr->onClickCallback.invoke(arr);
	}
}

static int get_extend_itemCount() {
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	int t_count = clutter_actor_get_n_children(listWrapper);
	return t_count;
}

void FirstScreenListWidget::off_transition_noanimaition() {
	riseFirstScreen();
	return;
	//fix the bug for enter in app ,call off_transition_noanimaition multi times--junhui.wang
	if(!ON_TRANSITION && !KEY_SELECT)
		return;
	KEY_SELECT = false;
	ON_TRANSITION = false;
	count_transition = -1;
		
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, DOMINANT_INDEX);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, MAIN_INDEX);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, OVERRAY_INDEX);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, TITLEPARENT_INDEX);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, CATEGORYTITLE_INDEX);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, SUBMAIN_INDEX);
	
	ClutterActor * liveImg1			= clutter_actor_get_child_at_index(image, LIVECONTENTS1_INDEX);
	ClutterActor * liveImg2			= clutter_actor_get_child_at_index(image, LIVECONTENTS2_INDEX);
	ClutterActor * liveIcon			= clutter_actor_get_child_at_index(image, LIVECONTENTS3_INDEX);

	ClutterActor * icon1 			= clutter_actor_get_child_at_index(dominant, ICON1_INDEX);
	ClutterActor * icon2 			= clutter_actor_get_child_at_index(dominant, ICON2_INDEX);

	//begin junhui.wang
	if(isKeyControl){
		clutter_actor_set_x(bar, p_x_bar_start);
		clutter_actor_set_position(contentWrapper, p_x_start, p_y_start);
		clutter_actor_set_position(titleParent, p_x_title_start, p_y_title_start);	
		
		int count  = clutter_actor_get_n_children(listWrapper);

		gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
		int startindex = (currentContents - 10 < 0) ? 0 : currentContents - 10;
		int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;
		for(int i = startindex; i < Maxcount; i++) 
		{
			if(i ==  currentContents) {
				continue;
			}

			ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
			clutter_actor_set_opacity(temp, 255 );

			if(currentContents < i) {
				clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (FOCUS_CONTENTS_WIDTH - contentWrapper_width));
			}
		}

		clutter_actor_set_size(contentWrapper, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		clutter_actor_set_size(dominant, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		clutter_actor_set_clip(dominant,0,0,FOCUS_CONTENTS_WIDTH,WIDGET_HEIGHT);
		clutter_actor_set_scale(image, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_scale(subMain, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);

		//set the icon's postion
		ClutterActor * current;
		gfloat iconParentWidth1,iconParentWidth2,iconParentHeight;
		//iconParent1
		current = icon1;	
		clutter_actor_get_size(current, &iconParentWidth1, &iconParentHeight);
		clutter_actor_set_position(current, FOCUS_CONTENTS_WIDTH - ICON_RIGHT_GAP - iconParentWidth1, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
		clutter_actor_set_opacity(current, 255);
		//iconParent2
		current = icon2;
		clutter_actor_get_size(current, &iconParentWidth2, &iconParentHeight);
		clutter_actor_set_position(current, FOCUS_CONTENTS_WIDTH - ICON_GAP - ICON_RIGHT_GAP - iconParentWidth1- iconParentWidth2, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
		clutter_actor_set_opacity(current, 255);
		
	}else{
		clutter_actor_set_x(bar, p_x_bar_start);
		clutter_actor_set_position(contentWrapper, p_x_start+(FOCUS_CONTENTS_WIDTH-NORMAL_CONTENTS_WIDTH)/2, p_y_start);
		//clutter_actor_set_size(contentWrapper,NORMAL_CONTENTS_WIDTH,WIDGET_HEIGHT);
		
		clutter_actor_set_size(titleParent, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT - CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_position(titleParent, 0, CONTENTS_IMAGE_HEIGHT);
		//title1
		ClutterActor* titleChild = clutter_actor_get_child_at_index(titleParent, NORMALTITLE_INDEX);
		//clutter_actor_set_x(titleChild,0);
		clutter_actor_set_opacity(titleChild, 255);
		//title2
		titleChild = clutter_actor_get_child_at_index(titleParent, FOCUSTITLE_INDEX);
		//clutter_actor_set_x(titleChild,(FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2);
		clutter_actor_set_opacity(titleChild,0);
		
		int count  = clutter_actor_get_n_children(listWrapper);

		gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
		int startindex = (currentContents - 10 < 0) ? 0 : currentContents - 10;
		int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;
		for(int i = startindex; i < Maxcount; i++) 
		{
			if(i ==  currentContents) {
				continue;
			}

			ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
			clutter_actor_set_opacity(temp, 255 );

			if(currentContents < i) {
				clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (FOCUS_CONTENTS_WIDTH - contentWrapper_width));
			}
		}

		clutter_actor_set_size(contentWrapper, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
		clutter_actor_set_size(dominant, NORMAL_CONTENTS_WIDTH, CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_clip(dominant,0,0,NORMAL_CONTENTS_WIDTH,CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_scale(image, 1.0, 1.0);
		clutter_actor_set_scale(subMain, 1.0, 1.0);

		//set the icon's postion
		ClutterActor * current;
		gfloat iconParentWidth1,iconParentWidth2,iconParentHeight;
		//iconParent1
		current = icon1;	
		clutter_actor_get_size(current, &iconParentWidth1, &iconParentHeight);
		clutter_actor_set_position(current, NORMAL_CONTENTS_WIDTH - ICON_RIGHT_GAP - iconParentWidth1, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
		clutter_actor_set_opacity(current, 255);
		//iconParent2
		current = icon2;
		clutter_actor_get_size(current, &iconParentWidth2, &iconParentHeight);
		clutter_actor_set_position(current, FOCUS_CONTENTS_WIDTH - ICON_GAP - ICON_RIGHT_GAP - iconParentWidth1- iconParentWidth2, WIDGET_HEIGHT - ICON_BOTTOM_GAP - iconParentHeight);
		clutter_actor_set_opacity(current, 0);
	}
	//end junhui.wang
	
	if(extendIndex == 1) {
		ClutterActor * otherCategoryItem = clutter_actor_get_child_at_index(bar, reduceIndex);
		clutter_actor_set_opacity(otherCategoryItem, 255);
		//clutter_actor_set_opacity(overlapShadow, 255);
		{
			gfloat bar_x = clutter_actor_get_x(bar);
			gfloat leftLimitX = 0 - OVER_CATEGORY_WIDTH;
			if(bar_x < leftLimitX)
			{
				clutter_actor_set_opacity(overlapShadow,255);
			}else{
				clutter_actor_set_opacity(overlapShadow,0);
			}
		}

		//liang.wu
		if(FirstScreenADControl::GetInstance()->IsEnable())
		{
			//ClutterActor * adCategoryItem = clutter_actor_get_child_at_index(bar, adIndex);
			//clutter_actor_set_opacity(adCategoryItem, 255);
			FirstScreenADControl::GetInstance()->SetOpacity(255);
		}

        // add by lin89.zhang for show option
		int itemCounts = clutter_actor_get_n_children(contentWrapper);
		if (itemCounts > CONTENT_OPTION_INDEX)
		{
			ClutterActor *tempOption = clutter_actor_get_child_at_index(contentWrapper, CONTENT_OPTION_INDEX);
			clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(contentWrapper)-optionIcoWidth)/2);
            clutter_actor_set_opacity(tempOption, 255);
		}
	}

	clutter_actor_set_opacity(titleParent, 255);
	if(!HIGH_CONTRAST_FLAG)
		clutter_actor_set_opacity(overray, OPACITY_8);
	else
		clutter_actor_set_opacity(overray, OPACITY_100);

	if(isKeyControl){
		clutter_actor_set_y(overray,WIDGET_HEIGHT);
		clutter_actor_set_width(overray,FOCUS_CONTENTS_WIDTH);
	}else{
		clutter_actor_set_y(overray,CONTENTS_IMAGE_HEIGHT);
		clutter_actor_set_width(overray,NORMAL_CONTENTS_WIDTH);
	}
	
	clutter_actor_set_opacity(categoryTitle, 255);

	//global cursor
	if(isKeyControl)
		clutter_actor_set_opacity(globalCursor,255);

	if(liveImg1 != NULL && liveImg2 != NULL ) {
		CONTENT_LIVE_FLAG = true;
		contentLiveTick =  0;
	}
	
	clutter_timeline_stop(timeline); 
	STOP_FLAG = false;
	clutter_timeline_start(timeline);
}
/*back up
void FirstScreenListWidget::off_transition_noanimaition() {
	
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, 2);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);
	ClutterActor * dominant			= clutter_actor_get_child_at_index(contentWrapper, 0);
	ClutterActor * image			= clutter_actor_get_child_at_index(dominant, 0);
	ClutterActor * overray			= clutter_actor_get_child_at_index(dominant, 1);
	ClutterActor * titleParent		= clutter_actor_get_child_at_index(contentWrapper, 1);
	ClutterActor * border			= clutter_actor_get_child_at_index(contentWrapper, 2);
	ClutterActor * categoryTitle	= clutter_actor_get_child_at_index(categoryItem, 1);
	ClutterActor * subMain			= clutter_actor_get_child_at_index(dominant, 4);
	
	clutter_actor_set_x(bar, p_x_start);
	clutter_actor_set_y(contentWrapper, p_y_start);

	int count  = clutter_actor_get_n_children(listWrapper);

	gfloat contentWrapper_width = clutter_actor_get_width(contentWrapper);
	int Maxcount = (currentContents + 10 > count) ? count : currentContents + 10;

	for(int i = currentContents + 1; i < Maxcount; i++) 
	{
		ClutterActor * temp = clutter_actor_get_child_at_index(listWrapper, i);
		clutter_actor_set_x(temp, clutter_actor_get_x(temp) + (FOCUS_CONTENTS_WIDTH - contentWrapper_width));
	}
	
	clutter_actor_set_size(contentWrapper, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_size(dominant, FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_scale(image, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
	clutter_actor_set_scale(subMain, FOCUS_CONTENTS_WIDTH/NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT/CONTENTS_IMAGE_HEIGHT);
	
	count_transition = -1;
	clutter_actor_set_opacity(titleParent, 255);
	clutter_actor_set_opacity(overray, OPACITY_80);
	clutter_actor_set_opacity(categoryTitle, 255);
	KEY_SELECT = false;
	ON_TRANSITION = false;
}
*/

void FirstScreenListWidget::stop_transition() {
	ON_TRANSITION = true;
	KEY_SELECT = true;
	//set_startapp_animation3();
	set_startapp_animation4();
}

void FirstScreenListWidget::animateOnEnter()
{
	if(KEY_SELECT || REDUCE_FLAG || EXTEND_FLAG || STOP_FLAG || foveaState == FIRST_GAP)	
	{
		return;
	}

	//liang.wu
	if(!EVENT_FLAG)
	{
		return;
	}

	//liang.wu
	if(AD_CURSOR_FLAG)
	{
		//instance->adContents->onEnterCallback.invoke(ScriptObject(true));
		FirstScreenADControl::GetInstance()->InvokeEnterCallback();
		return;
	}

	if(!isOpen[currentCategory]) 
	{
		extendAnimation();
	}
	else 
	{
		//set_startapp_animation3();
		set_startapp_animation4();
	}
}

static void moveToEnd() // always false
{
    MOVE_TO_END = true;
    MoveOriginPosition = clutter_actor_get_x(bar);
	ClutterActor *list = getListWrapper(1);
	for (int i = 0; i < clutter_actor_get_n_children(list); ++i)
	{
		toNormalContents(1,i,0);
	    //clutter_actor_show_all(clutter_actor_get_child_at_index(list, i));
	}
}

static void moveToBegin()
{	
	MOVE_TO_BEGIN = true;
	MoveOriginPosition = clutter_actor_get_x(bar);
	ClutterActor *list = getListWrapper(1);
	for (int i = 0; i < clutter_actor_get_n_children(list); ++i)
	{
	    //clutter_actor_show_all(clutter_actor_get_child_at_index(list, i));
	}
}

static void moveToEndImmd(bool fromContents)
{
	STOP_FLAG = true;

	if (fromContents)
	{
		// 1: normal contents	
		goal_position = SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP);
	}
	else
	{
		goal_position = SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP);
	}
	
	if (goal_position >= SIDECATEGORY_GAP)
	{
		goal_position = SIDECATEGORY_GAP;
	}
	clutter_actor_set_x(bar, goal_position);

	if (fromContents)
	{
		// 1: normal contents	
		cur_x = goal_x	= goal_position + (NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH / 2);
	}
	else
	{
		cur_x = goal_x	= goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH / 2 );
	}
	
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;

	//fixOverlapShadow();
	//move_rect();
	STOP_FLAG = false;

	if (instance != NULL) 
	{
		ScriptArray arr;
		instance->onMoveFocuseListener.invoke(arr);

		#ifdef _OBJECTDUMP_
		FirstScreenListWidget::Instance()->objectDumpCallback();
		#endif
	}
}


static void moveToBeginImmd()
{	
	STOP_FLAG = true;
	 
	clutter_actor_set_x(bar, SIDECATEGORY_GAP);
	goal_position = SIDECATEGORY_GAP;

	cur_x = goal_x = SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH / 2;
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;

	//fixOverlapShadow();
	//move_rect();
	STOP_FLAG = false;

	if (instance != NULL) 
	{
		ScriptArray arr;
		instance->onMoveFocuseListener.invoke(arr);
		#ifdef _OBJECTDUMP_
		FirstScreenListWidget::Instance()->objectDumpCallback();
		#endif
	}
}

#if 1
void FirstScreenListWidget::moveRight(int type)
{
	if(ON_TRANSITION || STOP_FLAG || KEY_SELECT 
	|| MOVE_TO_BEGIN || MOVE_TO_END || SCALE_LEFT || SCALE_RIGHT)
	{
		return;
	}

	//liang.wu
	if(!EVENT_FLAG)
	{
		return;
	}
	if (ContextMenu::Instance().contextMenuKeyHandler(RIGHT_KEY))
	{
		return;
	}
	timeID++;
	ContextMenu::setTimeout(timeID);

	//begin junhui.wang
	changeControler();
	//end junhui.wang

	//liang.wu
	gfloat real_bar_x = clutter_actor_get_x(bar);
	ClutterActor* category1 = clutter_actor_get_child_at_index(bar, extendIndex);
	gfloat real_cat1_x = clutter_actor_get_x(category1) + goal_position;
	gfloat cat1_width = clutter_actor_get_width(category1);

	//avoid circular issue
	if(goal_x >= real_cat1_x + cat1_width - FOCUS_CONTENTS_WIDTH 
		&& goal_x <= real_cat1_x + cat1_width)
	{
		if(!floatClose(real_bar_x, goal_position, 1.0) || !floatClose(cur_x, goal_x, 1.0) || MOVE_CURSOR)
		{
			return;
		}
	}
	else if(FirstScreenADControl::GetInstance()->IsEnable() 
			&& floatClose(cur_x, SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2, 1.0)
			&& floatClose(goal_x, SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH + NORMAL_CONTENTS_WIDTH/2, 1.0))
	{
		if(!floatClose(real_bar_x, goal_position, 1.0) || MOVE_CURSOR)
		{
			return;
		}
		AD_CURSOR_FLAG = false;
	}

	if(KEY_LEFT) //press Key_Right during Key Left is working
	{
		KEY_LEFT = false; //stop Key Left and start to Key Right handle
		goal_position = clutter_actor_get_x(bar);
		if(currentContents > 0) 
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
		}
	}

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;
	KEY_RIGHT = true;

	t_delta_x = NORMAL_CONTENTS_WIDTH;
	gfloat goal_x_post = goal_x + t_delta_x;

	if(floatClose(cur_x, SIDECATEGORY_GAP+FOCUS_CATEGORY_WIDTH/2, 1.0) 
		&& floatClose(goal_x, SIDECATEGORY_GAP+FOCUS_CATEGORY_WIDTH/2, 1.0))
	{
		if(FirstScreenADControl::GetInstance()->IsEnable())
		{
			cur_x = SIDECATEGORY_GAP+FOCUS_CATEGORY_WIDTH/2;
			goal_x = SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH + NORMAL_CONTENTS_WIDTH/2;
			AD_CURSOR_FLAG = true;

			//move cursor
			CursorOriginPosition = getGlobalCursorX();
			CursorDestPosition = SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH;
			CursorOriginWidth = getGlobalCursorWidth();
			CursorDestWidth = NORMAL_CONTENTS_WIDTH;
			
			MOVE_CURSOR = true;
			CURSOR_SHOW_FLAG = true;
		}
		else
		{
			cur_x = goal_x = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;

			//move cursor
			CursorOriginPosition = getGlobalCursorX();
			CursorDestPosition = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP;
			CursorOriginWidth = getGlobalCursorWidth();
			CursorDestWidth = FOCUS_CONTENTS_WIDTH;
			
			MOVE_CURSOR = true;
			CURSOR_SHOW_FLAG = true;
		}
	}
	else if(FirstScreenADControl::GetInstance()->IsEnable()
			&& floatClose(goal_x, SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH + NORMAL_CONTENTS_WIDTH/2, 1.0)
			&& floatClose(cur_x, SIDECATEGORY_GAP+FOCUS_CATEGORY_WIDTH/2, 1.0))
	{
		cur_x = goal_x = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;

		//move cursor
		CursorOriginPosition = getGlobalCursorX();
		CursorDestPosition = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP;
		CursorOriginWidth = getGlobalCursorWidth();
		CursorDestWidth = FOCUS_CONTENTS_WIDTH;
		
		MOVE_CURSOR = true;
		CURSOR_SHOW_FLAG = true;
	}
	else
	{
		if(goal_x_post >= real_cat1_x + cat1_width - FOCUS_CONTENTS_WIDTH 
			&& goal_x_post <= real_cat1_x + cat1_width)
		{
			ALLOW_MOVE_TO_BEGIN = false;
		}
		
		if(goal_x >= real_cat1_x + cat1_width - FOCUS_CONTENTS_WIDTH 
			&& goal_x <= real_cat1_x + cat1_width) //move to begin
		{
			KEY_RIGHT = false;
			if(ALLOW_MOVE_TO_BEGIN)
			{
				::scaleRight();
			}
			return;
		}
		else if(SCENE_WIDTH - goal_x_post < FOCUS_CONTENTS_WIDTH/2 + SIDECATEGORY_GAP)//move bar, maybe move focus
		{
			goal_position -= t_delta_x;

			gfloat diff = (goal_position + clutter_actor_get_x(category1) + cat1_width) - (SCENE_WIDTH - SIDECATEGORY_GAP);
			if(diff < 0)
			{
				goal_x += -diff;
				goal_position += -diff;
			}
		}
		else//move in contents list
		{
			goal_x = goal_x_post;
		}
	}

	if(MOVE_CURSOR)
	{
		if(type == 0)
		{
			MOVE_CURSOR_FRAME = 8;
		}
		else if(type == 1)
		{
			MOVE_CURSOR_FRAME = 15;
		}
	}

	if(AD_CURSOR_FLAG)
	{
		if(type == 0)
		{
			ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
		}
		else if(type == 1)
		{
			ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
		}

		return;
	}

	if(type == 0)
	{
		ratio_point = (goal_x - cur_x) / (16 * 1);
		ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
	}
	else if(type == 1)
	{
		ratio_point = (goal_x - cur_x) / (16 * 1);
		ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
	}
}

#else
void FirstScreenListWidget::moveRight()
{
	if(ON_TRANSITION || STOP_FLAG || KEY_SELECT 
	|| MOVE_TO_BEGIN || MOVE_TO_END || SCALE_LEFT || SCALE_RIGHT)
	{
		return;
	}

	//liang.wu
	if(!EVENT_FLAG)
	{
		return;
	}

	//begin junhui.wang
	changeControler();
	//end junhui.wang

	int t_count = get_extend_itemCount();

	if(extendIndex == 0) {
		if(goal_x <= goal_position + NORMAL_CONTENTS_WIDTH * (t_count -1) + FOCUS_CONTENTS_WIDTH
					&& goal_x >= goal_position + NORMAL_CONTENTS_WIDTH * (t_count -1) )
		{
			if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				//moveToBegin();
			    ::scaleRight(); // modify by lin89.zhang				
			}
			return ;
		}	
	}
	else {
		if(goal_x <= goal_position + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count -1) + FOCUS_CONTENTS_WIDTH
					&& goal_x >= goal_position + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count -1) )
		{
			if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				//moveToBegin();
			    ::scaleRight(); // modify by lin89.zhang
			}
			return ;
		}	
	}
	
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;

	if(KEY_LEFT) {
		KEY_LEFT = false;
		goal_position = clutter_actor_get_x(bar);
		if(currentContents < 0) {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2;
			}
		}
		else {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
		}
	}
	KEY_RIGHT = true;

	t_delta_x = NORMAL_CONTENTS_WIDTH;
	goal_x += t_delta_x;

	//junhui.wang - fix the defect of content scale after equal size of category focus and normal
	//if(extendIndex == 1 && goal_position <= goal_x && (goal_position + FOCUS_CATEGORY_WIDTH >=  goal_x))
	if(extendIndex == 1 && goal_position <= goal_x && (goal_position + NORMAL_CATEGORY_WIDTH*1.5 >=  goal_x))
	{
		//t_delta_x = NORMAL_CONTENTS_WIDTH + (FOCUS_CATEGORY_WIDTH - FOCUS_CONTENTS_WIDTH ) / 2 + CATEGORY_GAP;
		goal_x = goal_position + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2;
	}
	
	if(extendIndex == 1) {
		if(goal_x >= goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 - 1 ))
		{
			goal_x = goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2);		
		}			
	}
	else {
		
		if(goal_x >= goal_position + (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 - 1)) 
		{
			goal_x = goal_position + (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2);
		}
	}
			
	if(goal_x + FOCUS_CONTENTS_WIDTH / 2 >= SCENE_WIDTH) 
	{
		goal_position -= t_delta_x;
		goal_x -= t_delta_x;

		if(extendIndex == 0) {
			if(goal_position < SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP)) {
				goal_position = SCENE_WIDTH - (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP);
				goal_x = goal_position + (NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 );
			}
		}
		else {
			if(goal_position < SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP)) {
				goal_position = SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP);
				goal_x = goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH / 2 ) ;
			}
		}

		if(cur_x > goal_x) {
			cur_x = goal_x;
		}
	}

	ratio_point = (goal_x - cur_x) / (4 * 1);
	ratio_position = (goal_position - clutter_actor_get_x(bar)) / (4 * 1);
}
#endif

#if 1
void FirstScreenListWidget::moveLeft(int type)
{
	if(ON_TRANSITION || STOP_FLAG || KEY_SELECT 
	|| MOVE_TO_BEGIN || MOVE_TO_END || SCALE_LEFT || SCALE_RIGHT)
	{
		return;
	}

	//liang.wu
	if(!EVENT_FLAG)
	{
		return;
	}

	if (ContextMenu::Instance().contextMenuKeyHandler(LEFT_KEY))
	{
		return;
	}

	timeID++;
	ContextMenu::setTimeout(timeID);

	//begin junhui.wang
	changeControler();
	//end junhui.wang

	//liang.wu
	gfloat real_bar_x = clutter_actor_get_x(bar);
	ClutterActor* category1 = clutter_actor_get_child_at_index(bar, extendIndex);
	gfloat real_cat1_x = clutter_actor_get_x(category1) + goal_position;

	//avoid circular issue
	if(goal_x >= real_cat1_x && goal_x <= real_cat1_x + FOCUS_CONTENTS_WIDTH)
	{
		if(!floatClose(real_bar_x, goal_position, 1.0) || !floatClose(cur_x, goal_x, 1.0))
		{
			return;
		}
	}
	else if(FirstScreenADControl::GetInstance()->IsEnable()
			&& floatClose(goal_x, SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH + NORMAL_CONTENTS_WIDTH/2, 1.0)
			&& floatClose(cur_x, SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2, 1.0))
	{
		if(!floatClose(real_bar_x, goal_position, 1.0) || MOVE_CURSOR)
		{
			return;
		}
		AD_CURSOR_FLAG = false;
	}
	else if(floatClose(goal_x, SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2, 1.0)
			&& floatClose(cur_x, SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2, 1.0))
	{
		if(!floatClose(real_bar_x, goal_position, 1.0) || MOVE_CURSOR)
		{
			return;
		}
	}
	
	if(KEY_RIGHT) //press Key_Left during Key Right is working
	{
		KEY_RIGHT = false; //stop Key Right and start to Key Left handle
		goal_position = clutter_actor_get_x(bar);

		if(currentContents > 0) 
		{
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
		}
	}

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;
	KEY_LEFT = true;
	
	t_delta_x = NORMAL_CONTENTS_WIDTH;
	gfloat goal_x_post = goal_x - t_delta_x;

	if(goal_x_post >= SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2)//only move in contents
	{
		goal_x = goal_x_post;
	}
	else if(floatClose(cur_x, SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2, 1.0)
			&& floatClose(goal_x, SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2, 1.0))
	{
		KEY_LEFT = false;
		if(ALLOW_MOVE_TO_END)
		{
			::scaleLeft();
		}
		return;
	}
	else if(FirstScreenADControl::GetInstance()->IsEnable()
			&& floatClose(goal_x, SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH + NORMAL_CONTENTS_WIDTH/2, 1.0)
			&& floatClose(cur_x, SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2, 1.0))
	{
		cur_x = goal_x = SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2;

		//move cursor
		CursorOriginPosition = getGlobalCursorX();
		CursorDestPosition = SIDECATEGORY_GAP;
		CursorOriginWidth = getGlobalCursorWidth();
		CursorDestWidth = FOCUS_CATEGORY_WIDTH;
		
		MOVE_CURSOR = true;
		CURSOR_SHOW_FLAG = true;
		ALLOW_MOVE_TO_END = false;
	}
	else
	{
		if(goal_x >= real_cat1_x && goal_x <= real_cat1_x + FOCUS_CONTENTS_WIDTH)
		{
			if(FirstScreenADControl::GetInstance()->IsEnable())
			{
				goal_x = SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH + NORMAL_CONTENTS_WIDTH/2;
				cur_x = SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2;
				goal_position = SIDECATEGORY_GAP;
				AD_CURSOR_FLAG = true;

				//move cursor
				CursorOriginPosition = getGlobalCursorX();
				CursorDestPosition = SIDECATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH;
				CursorOriginWidth = getGlobalCursorWidth();
				CursorDestWidth = NORMAL_CONTENTS_WIDTH;
				
				MOVE_CURSOR = true;
				CURSOR_SHOW_FLAG = true;
			}
			else
			{
				cur_x = goal_x = SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2;
				goal_position = SIDECATEGORY_GAP;

				//move cursor
				CursorOriginPosition = getGlobalCursorX();
				CursorDestPosition = SIDECATEGORY_GAP;
				CursorOriginWidth = getGlobalCursorWidth();
				CursorDestWidth = FOCUS_CATEGORY_WIDTH;
				
				MOVE_CURSOR = true;
				CURSOR_SHOW_FLAG = true;
				ALLOW_MOVE_TO_END = false;
			}
		}
		else
		{
			if(goal_x_post <= SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + FOCUS_CONTENTS_WIDTH/2)//move in contents but need to move bar
			{
				goal_position += t_delta_x;

				if(goal_position >= SIDECATEGORY_GAP)
				{
					gfloat diff = goal_position - SIDECATEGORY_GAP;
					goal_position = SIDECATEGORY_GAP;
					goal_x -= diff;
				}
			}
			else//only move in contents
			{
				goal_x = goal_x_post;
			}
		}
	}

	if(MOVE_CURSOR)
	{
		if(type == 0)
		{
			MOVE_CURSOR_FRAME = 8;
		}
		else if(type == 1)
		{
			MOVE_CURSOR_FRAME = 15;
		}
	}

	if(AD_CURSOR_FLAG)
	{
		if(type == 0)
		{
			ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
		}
		else if(type == 1)
		{
			ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
		}
		
		return;
	}
	
	if(type == 0)
	{
		ratio_point = (goal_x - cur_x) / (16 * 1);
		ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
	}
	else if(type == 1)
	{
		ratio_point = (goal_x - cur_x) / (16 * 1);
		ratio_position = (goal_position - clutter_actor_get_x(bar)) / (16 * 1);
	}
}

#else
void FirstScreenListWidget::moveLeft()
{
	if(ON_TRANSITION || STOP_FLAG || KEY_SELECT 
	|| MOVE_TO_BEGIN || MOVE_TO_END || SCALE_LEFT || SCALE_RIGHT)
	{
		return;
	}

	//liang.wu
	if(!EVENT_FLAG)
	{
		return;
	}

	//begin junhui.wang
	changeControler();
	//end junhui.wang

	if(extendIndex == 0 )
	{
		if(goal_position <= goal_x && (goal_position + FOCUS_CONTENTS_WIDTH >=  goal_x))// || currentCategory == 1) 
		{
			if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				moveToEndImmd(true);
			}
			return;
		}
	}
	else if(goal_position <= goal_x && (goal_position + FOCUS_CATEGORY_WIDTH >=  goal_x))// || currentCategory == 1) 
	{
		if(clutter_actor_get_x(bar) == goal_position && cur_x == goal_x) {
				//moveToEnd(false);
			::scaleLeft();
		}
		return;
	}

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;


	if(KEY_RIGHT) {
		KEY_RIGHT = false;
		goal_position = clutter_actor_get_x(bar);
		if(currentContents < 0) {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2;
			}
			
		}
		else {
			if(extendIndex == 1) {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
			else {
				cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			}
		}
	}
	KEY_LEFT = true;
				
	t_delta_x = NORMAL_CONTENTS_WIDTH;
	goal_x -= t_delta_x;

	if(extendIndex == 1 && goal_position <= goal_x && (goal_position + FOCUS_CATEGORY_WIDTH >=  goal_x)) 
	{
		t_delta_x = NORMAL_CONTENTS_WIDTH + (FOCUS_CATEGORY_WIDTH - FOCUS_CONTENTS_WIDTH ) / 2 + SIDECATEGORY_GAP + CATEGORY_GAP;
		goal_x = goal_position + FOCUS_CATEGORY_WIDTH / 2; 
	}
	
	if(goal_x <= goal_position) 
	{
		goal_x += t_delta_x;
		goal_x += SIDECATEGORY_GAP;

		return;
	}			
	
	if(goal_x - FOCUS_CONTENTS_WIDTH / 2 <= 0) 
	{
		goal_position += t_delta_x;
		goal_x += t_delta_x;

		if(goal_position >= 0 ) {
			goal_position = SIDECATEGORY_GAP;
			if(extendIndex == 0) {
				goal_x = SIDECATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2;
			}
			else {
				goal_x = SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH / 2;
			}
			
			if(cur_x < goal_x) {
				cur_x = goal_x;
			}
		}

	} 

	//lin89.zhang
	gfloat tempGoal = goal_position;
	gfloat tempDiff = 0.0;
	//if(goal_x < CATEGORY_GAP*2 + NORMAL_CATEGORY_WIDTH + FOCUS_CONTENTS_WIDTH/2)
	if(goal_x > SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH/2 &&
		goal_x < SIDECATEGORY_GAP + CATEGORY_GAP + NORMAL_CATEGORY_WIDTH + FOCUS_CONTENTS_WIDTH/2)
	{
		goal_position += NORMAL_CONTENTS_WIDTH;
		if(goal_position >= SIDECATEGORY_GAP)
		{
			goal_position = SIDECATEGORY_GAP;
		}
		tempDiff = goal_position - tempGoal;
		goal_x += tempDiff;
	}

	ratio_point = (goal_x - cur_x) / (4 * 1);
	ratio_position = (goal_position - clutter_actor_get_x(bar)) / (4 * 1);
}
#endif

/*
static void scrollLeft()
{
	if(clutter_actor_get_x(bar) >= 0) 
	{
		SCROLL_LEFT = false;
	}
	else 
	{
		velocity += 0.7;

		if(velocity > 60) 
		{
			velocity = 60;
		}

		clutter_actor_set_x(bar, clutter_actor_get_x(bar) + velocity);
	}
}

static void scrollRight() 
{
	int t_count = get_extend_itemCount();
	if(clutter_actor_get_x(bar) <= SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH) )
	{
		SCROLL_RIGHT = false;
	}
	else 
	{
		velocity += 0.7;

		if(velocity > 60)
		{
			velocity = 60;
		}

		clutter_actor_set_x(bar, clutter_actor_get_x(bar) - velocity);
	}
}
*/
static void scrollLeft_Rollover() 
{
	//modify by junhui.wang 
	/*gfloat temp = min((t_t - DELAY_TIME)/AUTOSCROLL_TIME, (gfloat)1);

	V_t = min(INIT_SPEED + temp * temp  * SCALE_SPEED, LIMIT_SPEED);*/
	t_t += 0.16;
	float e= min(t_t,MAX_ACCELERATE_TIME);
	float k = bezier(e,MAX_ACCELERATE_TIME,0.0,0.0,1.0,1.0);
	V_t = min((k*(SCALE_MAXSPEED - SCALE_MINSPEED) + SCALE_MINSPEED),SCALE_MAXSPEED);

	 
	if(clutter_actor_get_x(bar) >= SIDECATEGORY_GAP) 
	{
		SCROLL_LEFT = false;
		V_t = 0;
		t_t = 0;
		if (instance != NULL && instance->onScrollLeftEndListener.isFunction()) 
		{
			ScriptArray arr;
			instance->onScrollLeftEndListener.invoke(arr);
		}
	}
	else 
	{	 
		if(clutter_actor_get_x(bar) + V_t > SIDECATEGORY_GAP) {
			clutter_actor_set_x(bar, SIDECATEGORY_GAP);
		}
		else {
			clutter_actor_set_x(bar, clutter_actor_get_x(bar) + V_t);
		}
	}

	goal_position = clutter_actor_get_x(bar);
}

static void scrollRight_Rollover() 
{
	//modify by junhui.wang
	/*gfloat temp = min((t_t - DELAY_TIME)/AUTOSCROLL_TIME, (gfloat)1);

	V_t = min(INIT_SPEED + temp * temp * SCALE_SPEED, LIMIT_SPEED);*/
	t_t += 0.16;
	float e= min(t_t,MAX_ACCELERATE_TIME);
	float k = bezier(e,MAX_ACCELERATE_TIME,0.0,0.0,1.0,1.0);
	V_t = min((k*(SCALE_MAXSPEED - SCALE_MINSPEED) + SCALE_MINSPEED),SCALE_MAXSPEED);
	

	int t_count = get_extend_itemCount();

	if(clutter_actor_get_x(bar) <= SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP))
	{
		//out of right scroll area, restart fovea contents
		scrollRightFlag = false;
		scrollRightTick = 0;
		scrollVerticalDiffRatio = 1.0;
		verticalDiff = 1.0;//recover verticalDiff, but just temparory method
	
		SCROLL_RIGHT = false;
		V_t = 0;
		t_t = 0;
		if (instance != NULL && instance->onScrollRightEndListener.isFunction()) 
		{	
			ScriptArray arr;
			instance->onScrollRightEndListener.invoke(arr);
		}
	}
	else 
	{
		scrollRightFlag = true;
		if(clutter_actor_get_x(bar) - V_t < SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP)) {
			clutter_actor_set_x(bar, SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP));
		}
		else {
			clutter_actor_set_x(bar, clutter_actor_get_x(bar) - V_t);
		}
	}

	goal_position = clutter_actor_get_x(bar);
}

static long getCurrentTime(){
	time_t curTime;
	time(&curTime);
	return curTime;
}

static gboolean FireOnCallbacks(gpointer aData)
{

	FirstScreenContents* ctr = NULL;
	ClutterActor * categoryItem		= clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor * listWrapper		= clutter_actor_get_child_at_index(categoryItem, CATEGORY_LISTWRAPPER_INDEX);
	ClutterActor * contentWrapper	= clutter_actor_get_child_at_index(listWrapper, currentContents);

	clutter_actor_get_child_at_index(listWrapper, currentContents);
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(contentWrapper);
	if (it != itemMap.end())
	{
		ctr = it->second;
	}

	//FirstScreenContents* ctr = reinterpret_cast<FirstScreenContents *>(aData);
	if (ctr != NULL)
	{
		ScriptArray arr;
		arr.set(0, ctr->jsInstance);
		ctr->longPressCallback.invoke(arr);
	}
	return FALSE;
};

static gboolean FireOnContextMenuCallbacks(gpointer aData)
{
	if (instance != NULL && instance->onContextMenuFocusListener.isFunction()) 
	{	
		// feedback  to JS layer [shuhao.yan]
		ScriptArray arr;
		instance->onContextMenuFocusListener.invoke(arr);
	}
	return FALSE;
};
void longPressCheckThread() 
{
	while(true){
		releaseTime = getCurrentTime();
		
		if(getCurrentTime() - pressTime >= 5 && isPressHold == true){
			isLongPress = true;
			std::string tempName;
			tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, extendIndex));	
			if (compareStrChar(tempName, "featured"))
			{
				clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW, FireOnCallbacks, NULL, NULL);
			}
			else
			{
				clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW, FireOnContextMenuCallbacks, NULL, NULL);
			}
			
			break;
		}else if(isPressHold == false){
			break;
		}
	}
}

static void on_stage_button_press_event(ClutterStage *stage, ClutterEvent *event, gpointer data) 
{
	if(KEY_PREVENT_FLAG) {
		return;
	}

	pressTime = getCurrentTime();
	isPressHold = true;
	isLongPress = false;
	pressThread = std::thread(longPressCheckThread);
	pressThread.detach();
}

int osdResolution = -1;

static void on_stage_button_release_event(ClutterStage *stage, ClutterEvent *event, gpointer data) 
{
	if(KEY_PREVENT_FLAG) {
		return;
	}
	//LYJ
	isPressHold = false;
	if(isLongPress == false)
	{
		if(STOP_FLAG)
		{
			return;
		}
		gfloat x;
		gfloat y;

		clutter_event_get_coords(event, &x, &y);

		x = REVERSE_OSD ? SCENE_WIDTH - x : x; // [shuhao.yan]
		// to check the context Menu click feature
		if ( y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - 100)
		{
			ContextMenu::Instance().on_ContextMenu_button_release_event(x, y);
		}
		
		#if defined(BUILD_FOR_TV) && defined(TIZEN)
		if (osdResolution < 0) 
		{
			int systemResult = 0;
			systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT, &osdResolution);
		
			if(systemResult != SYSTEM_INFO_ERROR_NONE)
			{
				LOG_FATAL(logger, "Failed to get value for Resolution[" << SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT << "]" );
			}
		}
	
		if (osdResolution == 720) 
		{
			y = y * 1.5f;
		}
		#endif

		if(FirstScreenADControl::GetInstance()->IsEnable() && (foveaState == FIRST_GAP))
		{
			if (x > SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH &&
				x < SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP && CLIPFLAG)
			{
				//on_AD_check_ClickEvent(x);
				FirstScreenADControl::GetInstance()->InvokeClickCallback(x);
			}
		}
		
		if(KEY_SELECT || REDUCE_FLAG || EXTEND_FLAG || foveaState == FIRST_GAP)
		{
			return;
		}

		if(y < SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT)	
		{

			if (y < SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2)
			{
				if (instance != NULL) 
				{
					ScriptArray arr;
					instance->onBackgroundClickListener.invoke(arr);
				}
			}
			else
			{
				if (isOpen[currentCategory])
				{
					setenterOptions();
				}
			}
			
		}
		else
		{	
			gfloat real_bar_x = clutter_actor_get_x(bar);
			ClutterActor* category0 = clutter_actor_get_child_at_index(bar, reduceIndex);
			ClutterActor* category1 = clutter_actor_get_child_at_index(bar, extendIndex);
			gfloat real_cat0_x = clutter_actor_get_x(category0) + real_bar_x;
			gfloat real_cat1_x = clutter_actor_get_x(category1) + real_bar_x;
			gfloat real_cat1_wx = clutter_actor_get_width(category1) + real_cat1_x;
			
			if((currentCategory == reduceIndex && cur_x >= real_cat0_x)
				|| (currentCategory == extendIndex && cur_x >= real_cat1_x && cur_x <= real_cat1_wx))
			{
				if(!isOpen[currentCategory]) 
				{
					extendAnimation();
				}
				else 
				{
					set_startapp_animation4();
				}
			}
		}	
	}
	isLongPress = false;
}

void FirstScreenListWidget::riseFirstScreen()
{
	clutter_actor_set_y(bar, SCENE_HEIGHT + 100);
	clutter_actor_animate(bar, CLUTTER_EASE_IN_OUT_QUINT, 1000, "y", SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT, NULL);
	clutter_actor_animate(overlapShadow, CLUTTER_EASE_IN_OUT_QUINT, 1000, "y", SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT, NULL);//lin89.zhang
	clutter_actor_animate(globalCursor, CLUTTER_EASE_IN_OUT_QUINT, 1000, "y", SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT - GLOBAL_CURSOR_XY_DIFF, NULL);
	clutter_timeline_start(timeline); 
	EVENT_FLAG = true;
	STOP_FLAG = false;
	optionStaus = UNFOCUS;
}

void FirstScreenListWidget::setBarOpacityZero()
{
	clutter_actor_set_opacity(bar, 0);
	clutter_actor_set_opacity(overlapShadow, 0);
	clutter_actor_set_opacity(globalCursor,0);
}

void FirstScreenListWidget::setBarOpacityMax()
{
	clutter_actor_set_opacity(bar, 255);
	//clutter_actor_set_opacity(overlapShadow, 255);
	{
		gfloat bar_x = clutter_actor_get_x(bar);
		gfloat leftLimitX = 0 - OVER_CATEGORY_WIDTH;
		if(bar_x < leftLimitX)
		{
			clutter_actor_set_opacity(overlapShadow,255);
		}else{
			clutter_actor_set_opacity(overlapShadow,0);
		}
	}
	if(isKeyControl)
		clutter_actor_set_opacity(globalCursor,255);
}
//begin junhui.wang
static void ScaleCategoryCursor(){
	SCALE_CATEGORY_FLAG = true;
	scaleCategoryTick = 0;
}
static void ScaleCategoryAnimation(gfloat diff){
	//global cursor
	gfloat transCursorWidth = 2 - (2 - FOCUS_CATEGORY_WIDTH)*diff;
	gfloat transCursorHeight = 2 - (2 - WIDGET_HEIGHT)*diff;
	gfloat transCursorX;
	gfloat transCursorY;

	ClutterActor * tempChild = clutter_actor_get_child_at_index(bar, 0);
	
	//clutter_actor_set_size(globalCursor,transCursorWidth,transCursorHeight);
	setGlobalCursorSize(transCursorWidth, transCursorHeight);
	clutter_actor_set_opacity(globalCursor,255);		
	transCursorX = clutter_actor_get_x(tempChild)+(clutter_actor_get_width(tempChild)-transCursorWidth)/2;
	transCursorY = (WIDGET_HEIGHT - transCursorHeight)/2;
	//clutter_actor_set_position(globalCursor,clutter_actor_get_x(bar)+transCursorX,SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
	setGlobalCursorPosition(clutter_actor_get_x(bar)+transCursorX, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
}

static void ReduceCategoryCursor(){
	REDUCE_CATEGORY_FLAG = true;
	reduceCategoryTick = 0;
}
static void ReduceCategoryAnimation(gfloat diff){
	//global cursor
	gfloat transCursorWidth = FOCUS_CATEGORY_WIDTH - (FOCUS_CATEGORY_WIDTH - 2)*diff;
	gfloat transCursorHeight = WIDGET_HEIGHT - (WIDGET_HEIGHT - 2)*diff;
	gfloat transCursorX;
	gfloat transCursorY;

	ClutterActor * tempChild = clutter_actor_get_child_at_index(bar, 0);
	//clutter_actor_set_size(globalCursor,transCursorWidth,transCursorHeight);
	setGlobalCursorSize(transCursorWidth, transCursorHeight);
	if(diff == 1.0)
		clutter_actor_set_opacity(globalCursor,0);
	else
		clutter_actor_set_opacity(globalCursor,255);		
	transCursorX = clutter_actor_get_x(tempChild)+(clutter_actor_get_width(tempChild)-transCursorWidth)/2;
	transCursorY = (WIDGET_HEIGHT - transCursorHeight)/2;
	//clutter_actor_set_position(globalCursor,clutter_actor_get_x(bar)+transCursorX,SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
	setGlobalCursorPosition(clutter_actor_get_x(bar)+transCursorX, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
}
//end junhui.wang

//begin junhui.wang
static void ReduceContentItemAnimation(int index)
{
	gfloat transX;
	gfloat transWidth;
	gfloat transAllWidth;
	gfloat transHeight;
	gfloat transOpacity;
	gfloat transContentsTitleWidth;
	gfloat transNormalTitlePos;
	gfloat transFocusTitlePos;
	gfloat transBorderWidth;
	gfloat transScaleX;
	gfloat transScaleY;
	gfloat transIconPosition;
	gfloat transNormalTitleOpt;
	gfloat transFocusTitleOpt;
	
	gfloat transVerticalX;
	gfloat transVerticalWidth;
	gfloat transVerticalHeight;
	gfloat transVerticalOpacity;
	gfloat transVerticalContentsTitleWidth;
	gfloat transVerticalNormalTitlePos;
	gfloat transVerticalFocusTitlePos;
	gfloat transVerticalBorderWidth;
	gfloat transVerticalDiff;
	gfloat diff;

	//begin junhui.wang
	gfloat transOverlapOpacity;
	gfloat transVerticalOverlapOpacity;
	ClutterActor * leftChild;
	gfloat leftEnd;
	gfloat leftWidth;
	//end junhui.wang
	
	gfloat x, y;

	ClutterActor *temp1 = NULL;
	ClutterActor *temp2 = NULL;
	ClutterActor *temp3 = NULL;
	ClutterActor *tempChild = NULL;
	ClutterActor *tempList = NULL;

	int leftLimit = 0;
	int rightLimit = 0;
	int itemCount = 0;
	int tempIndex = 0;
	
	gfloat startPoint = 0.0f;
	gfloat endPoint = 0.0f;
	gfloat title_x = 0.0f;
	gfloat contentsTitle_x = 0.0f;
	
	////////////////////////////////left contents fovea//////////////////////////////////
	//barChild		
	if(currentCategory == 1)
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		tempIndex = 1;
		itemCount = clutter_actor_get_n_children(temp2);		
	}
	else
	{
		tempChild = temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);
		tempList = temp2 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		tempIndex = 0;
		itemCount = clutter_actor_get_n_children(temp2);
	}

	////////////////////////////////left contents//////////////////////////////////
	temp3 = clutter_actor_get_child_at_index(temp2, index);

	for(int i = index - 1; i >= 0; i--)
	{
		if(clutter_actor_get_x(bar) + clutter_actor_get_x(temp1) + clutter_actor_get_x(temp3) - NORMAL_CONTENTS_WIDTH*(index - 1 - i) <= FOCUS_CATEGORY_WIDTH)
		{
			leftLimit = i;

			break;
		}

		if(i == 0)
		{
			leftLimit = 0;
		}
	}

	for(int i = leftLimit; i <= index - 1; i++)
	{
		toNormalContents(tempIndex, i, 0);
	}

	diff = 1.0 - (1.0 - 0)*reduceItemDiff;
	transVerticalX = NORMAL_CONTENTS_WIDTH*index - (NORMAL_CONTENTS_WIDTH*index-(NORMAL_CONTENTS_WIDTH*index+(reduceItemDesWidth-NORMAL_CONTENTS_WIDTH)/2))*reduceItemDiff;
	transVerticalWidth = FOCUS_CONTENTS_WIDTH - (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_WIDTH)*reduceItemDiff;
	transVerticalHeight = WIDGET_HEIGHT - (WIDGET_HEIGHT - CONTENTS_IMAGE_HEIGHT)*reduceItemDiff;
	transVerticalOpacity = OPACITY_100 - (OPACITY_100 - OPACITY_70)*reduceItemDiff;
	transVerticalContentsTitleWidth = FOCUS_CONTENTS_TITLE_WIDTH - (FOCUS_CONTENTS_TITLE_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)*reduceItemDiff;
	transVerticalBorderWidth = (FOCUS_CONTENTS_WIDTH - 4) - ((FOCUS_CONTENTS_WIDTH - 4) - (NORMAL_CONTENTS_WIDTH - 4))*reduceItemDiff;
	transVerticalNormalTitlePos = (FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2 - ((FOCUS_CONTENTS_WIDTH - NORMAL_CONTENTS_TITLE_WIDTH)/2 - CONTENTS_TITLE_X)*reduceItemDiff;

	transAllWidth = FOCUS_CONTENTS_WIDTH - (FOCUS_CONTENTS_WIDTH - reduceItemDesWidth)*reduceItemDiff;
	transX = transVerticalX;
	transWidth = transVerticalWidth;
	transHeight = transVerticalHeight;
	transHeight = Rounding(transHeight,0);
	transOpacity = transVerticalOpacity;
	transContentsTitleWidth = transVerticalContentsTitleWidth;
	transBorderWidth = transVerticalBorderWidth;
	transNormalTitlePos = transVerticalNormalTitlePos;

	transScaleX = transWidth / NORMAL_CONTENTS_WIDTH;
	//transScaleY = transHeight / CONTENTS_IMAGE_HEIGHT;
	transScaleY = transScaleX;

	//begin junhui.wang	
	gfloat normalOverlapOpcity;
	if(HIGH_CONTRAST_FLAG)
		normalOverlapOpcity = OPACITY_100;
	else
		normalOverlapOpcity = OPACITY_8;
	transVerticalOverlapOpacity = 0 - (0 - normalOverlapOpcity)*verticalDiff;	
	transOverlapOpacity = transVerticalOverlapOpacity;	
	//end junhui.wang
	
	if(reduceItemDiff >= 0.5)
	{
		transVerticalDiff = 1 - 2*reduceItemDiff;

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY;
			transFocusTitleOpt = 0;
		}
	}
	else
	{
		transVerticalDiff = 2*(reduceItemDiff - 0.5);

		if(diff <= 0.5f)
		{
			transNormalTitleOpt = 0;
			transFocusTitleOpt = OPACITY_100*(1 - 2*diff)*transVerticalDiff;
		}
		else
		{
			transNormalTitleOpt = CONTENT_NORMAL_TITLE_OPACITY - (CONTENT_NORMAL_TITLE_OPACITY - CONTENT_NORMAL_TITLE_OPACITY*2*(diff - 0.5))*transVerticalDiff;
			transFocusTitleOpt = 0;
		}
	}
	
	clutter_actor_set_width(temp1, transAllWidth + NORMAL_CONTENTS_WIDTH*(itemCount - 1));
	
	//contentsWrapper
	temp1 = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
	temp1 = clutter_actor_get_child_at_index(temp1, index);
	
	clutter_actor_set_x(temp1, transX);

	clutter_actor_set_width(temp1, transWidth);
	//dominant
	temp2 = clutter_actor_get_child_at_index(temp1, DOMINANT_INDEX);
	clutter_actor_set_width(temp2, transWidth);
	//clutter_actor_set_opacity(temp2, transOpacity);
	clutter_actor_set_clip(temp2,0,0,transWidth,WIDGET_HEIGHT);
	//clutter_actor_set_height(temp2,transHeight);

	//main
	temp3 = clutter_actor_get_child_at_index(temp2, MAIN_INDEX);
	clutter_actor_set_scale(temp3, transScaleX, transScaleY);

	//overRay
	temp3 = clutter_actor_get_child_at_index(temp2, OVERRAY_INDEX);
	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_y(temp3, transHeight);
	clutter_actor_set_opacity(temp3,transOverlapOpacity);

	//iconParent1
	temp3 = clutter_actor_get_child_at_index(temp2, ICON1_INDEX);
	transIconPosition = transWidth - ICON_RIGHT_GAP - clutter_actor_get_width(temp3);
	clutter_actor_set_x(temp3, transIconPosition);

	//iconParent2
	temp3 = clutter_actor_get_child_at_index(temp2, ICON2_INDEX);
	if(diff == 0.0f)
	{
		clutter_actor_set_x(temp3, transIconPosition - ICON_GAP - clutter_actor_get_width(temp3));
		clutter_actor_set_opacity(temp3, 255);
	}
	else
	{
		clutter_actor_set_opacity(temp3, 0);
	}

	//subMain
	temp3 = clutter_actor_get_child_at_index(temp2, SUBMAIN_INDEX);
	if(clutter_actor_get_width(temp3) != 10.0f)
	{
		clutter_actor_set_scale(temp3, transScaleX, transScaleY);
		clutter_actor_set_opacity(temp3, OPACITY_100*(1 - diff)*reduceItemDiff);
		clutter_actor_set_opacity(clutter_actor_get_child_at_index(temp2, 0), OPACITY_100 - (OPACITY_100 - OPACITY_100*diff)*reduceItemDiff);
	}
	
	//titleParent
	temp2 = clutter_actor_get_child_at_index(temp1, TITLEPARENT_INDEX);
	clutter_actor_set_y(temp2, transHeight);

	//title1 (normal)
	temp3 = clutter_actor_get_child_at_index(temp2, NORMALTITLE_INDEX);
	//clutter_actor_set_x(temp3, transNormalTitlePos);
	clutter_actor_set_opacity(temp3, transNormalTitleOpt);

	//title2 (focus)
	temp3 = clutter_actor_get_child_at_index(temp2, FOCUSTITLE_INDEX);
	contentsTitle_x = (NORMAL_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2;
	transVerticalFocusTitlePos = contentsTitle_x - (contentsTitle_x - (FOCUS_CONTENTS_WIDTH - clutter_actor_get_width(temp3))/2)*reduceItemDiff;
	transFocusTitlePos = transVerticalFocusTitlePos - (transVerticalFocusTitlePos - contentsTitle_x)*diff;
	//clutter_actor_set_x(temp3, transFocusTitlePos);
	clutter_actor_set_opacity(temp3, transFocusTitleOpt);
	
	//progressN & Dim
	if (clutter_actor_get_n_children(temp1) == CONTENT_DIM_INDEX + 1)
	{
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
		ProgressController::updateProgressFoveaStatus(temp2, transWidth, transHeight);
	}
#if 0
	//dim
	temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_DIM_INDEX);
	clutter_actor_set_width(temp2,transWidth);
	temp2 = clutter_actor_get_child_at_index(temp1, CONTENT_PROGRESS_INDEX);
	temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_N_INDEX);
	gfloat progress = clutter_actor_get_x(temp3);
	if(progress <= 0 || progress >= 100)
	{
		//progressP
		clutter_actor_set_opacity(temp2, 0);
	}
	else
	{
		//progressP
		clutter_actor_set_width(temp2, transWidth);
		clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
		clutter_actor_set_opacity(temp2, OPACITY_100);
		//progressC
		temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);
		clutter_actor_set_width(temp3, transWidth);
		clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
	}

	// options
	int itemCounts = clutter_actor_get_n_children(temp1);
	if (itemCounts > CONTENT_OPTION_INDEX)
	{
		ClutterActor *tempOption = clutter_actor_get_child_at_index(temp1, CONTENT_OPTION_INDEX);
		clutter_actor_set_x(tempOption, 
		                    (clutter_actor_get_width(temp1)-optionIcoWidth)/2);
        clutter_actor_set_opacity(tempOption, transFocusTitleOpt);
	}
#endif

	//global cursor
	gfloat transCursorWidth = FOCUS_CONTENTS_WIDTH - (FOCUS_CONTENTS_WIDTH - 2)*reduceItemDiff;
	gfloat transCursorHeight = WIDGET_HEIGHT - (WIDGET_HEIGHT - 2)*reduceItemDiff;
	gfloat transCursorOpacity = 255 - (255 - 0)*verticalDiff;
	gfloat transCursorX;
	gfloat transCursorY;
	
	ClutterActor* haveCursorActor = clutter_actor_get_child_at_index(tempList,index);
	//clutter_actor_set_size(globalCursor,transCursorWidth,transCursorHeight);
	setGlobalCursorSize(transCursorWidth, transCursorHeight);
	if(reduceItemDiff == 1.0)
		clutter_actor_set_opacity(globalCursor,0);
	else
		clutter_actor_set_opacity(globalCursor,255);
	
	transCursorX = clutter_actor_get_x(tempChild)+clutter_actor_get_x(haveCursorActor)+(clutter_actor_get_width(haveCursorActor)-transCursorWidth)/2;
	transCursorY = (WIDGET_HEIGHT - transCursorHeight)/2;
	//clutter_actor_set_position(globalCursor,clutter_actor_get_x(bar) + transCursorX,SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);
	setGlobalCursorPosition(clutter_actor_get_x(bar) + transCursorX, SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT+transCursorY);

	//right content
	for(int i = index; i < itemCount; i++)
	{
		temp3 = clutter_actor_get_child_at_index(tempList, i);

		if(clutter_actor_get_x(bar) + clutter_actor_get_x(tempChild) + clutter_actor_get_x(temp3) + clutter_actor_get_width(temp3) > SCENE_WIDTH) 
		{
			rightLimit = i;
		
			break;
		}

		if(i == itemCount - 1)
		{
			rightLimit = itemCount - 1;
		}
	}

	if(index == itemCount - 1) 
	{
		return;
	}

	for(int i = index + 1; i <= rightLimit + 1; i++)
	{
		if(i > itemCount - 1) 
		{
			return;
		}
		toNormalContents(tempIndex, i, transAllWidth - NORMAL_CONTENTS_WIDTH);
	}
}

static void changeControlerToMouse(gfloat yPos){
	EVENT_FLAG = false;
	int tAllCategoryCount = clutter_actor_get_n_children(bar);
	if(currentCategory == 1 || (currentCategory == 0 && tAllCategoryCount ==1 )){

		if (preTextInc != NULL)
		{
			preTextInc->scrollStop();
			preTextInc = NULL;
		}
		startNormalTitleScroll(currentContents);

		ContextMenu::Instance().fallContextMenu();
		
		isKeyControl = false;
		gfloat over_y = yPos - (SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - CATEGORY_COLOR_HEIGHT/2);
		gfloat inputPosition;
		if(over_y < 0)
		{
			verticalDiff = 0.0f;
		}
		else if(over_y <= CATEGORY_COLOR_HEIGHT/2)
		{	
			inputPosition = over_y / (CATEGORY_COLOR_HEIGHT/2);
			verticalDiff = bezier(inputPosition, 1.0f, vFovea[0], vFovea[1], vFovea[2], vFovea[3]);
		}
		else if(over_y <= WIDGET_HEIGHT + CATEGORY_COLOR_HEIGHT/2)
		{
			verticalDiff = 1.0f;
		}
		else
		{
			over_y -= (WIDGET_HEIGHT+ CATEGORY_COLOR_HEIGHT/2);
			inputPosition = 1 - (over_y / BOTTOM_HEIGHT);
			verticalDiff = bezier(inputPosition, 1.0f, vFovea[0], vFovea[1], vFovea[2], vFovea[3]);
		}
		reduceItemDesWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH-FOCUS_CONTENTS_WIDTH)*verticalDiff;
		reduceItemIndex = currentContents;
		reduceItemTick = 0;
		REDUCE_ITEM_FLAG = true;
		//toFocusContents(currentCategory,currentContents,0,false);
	}else{
		//barChild
		ClutterActor* temp1 = clutter_actor_get_child_at_index(bar, currentCategory);
		clutter_actor_set_width(temp1, FOCUS_CATEGORY_WIDTH);

		//categoryTitle
		ClutterActor* temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);
		clutter_actor_set_opacity(temp2, OPACITY_100);

		//categoryWrapper
		temp2 = clutter_actor_get_child_at_index(temp1, CONTENTSWRAPPER_INDEX);
		clutter_actor_set_width(temp2, FOCUS_CATEGORY_WIDTH);

		//category live
		FirstScreenCategoryLiveControl::GetInstance()->SetOpacity(temp2, OPACITY_100);

		//reset the cur pos
		cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;
		goal_position = SIDECATEGORY_GAP;
		clutter_actor_set_x(bar, goal_position);
		cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH/2;
		isKeyControl = false;
		
		ReduceCategoryCursor();
	}
}
//end junhui.wang

static void on_stage_motion_event(ClutterStage *stage, ClutterEvent *event, gpointer data)
{
	if(ON_TRANSITION || KEY_SELECT || STOP_FLAG || KEY_PREVENT_FLAG) 
	{
		return;
	}

	//liang.wu
	if(REDUCE_FLAG || RECOVER_FLAG || EXCHANGE_FLAG || EXTEND_FLAG || REDUCE_ITEM_FLAG)
	{
		return;
	}
	
	if(FOCUS_OPTIONS)
	{
		//setunfocusOptions();
	}

	time(&mouseMoved);
	gfloat x = 0;
    gfloat y = 0;

	clutter_event_get_coords(event, &x, &y);

	#if defined(BUILD_FOR_TV) && defined(TIZEN)
	if (osdResolution < 0) 
	{
		int systemResult = 0;
		systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT, &osdResolution);
		
		if(systemResult != SYSTEM_INFO_ERROR_NONE)
		{
			LOG_FATAL(logger, "Failed to get value for Resolution[" << SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT << "]" );
		}
	}
	
	if (osdResolution == 720) 
	{
		x = x * 1.5f;
		y = y * 1.5f;
	}
	#endif

	x = REVERSE_OSD ? SCENE_WIDTH - x : x; // [shuhao.yan]

	if ( y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - 100)
	{
		ContextMenu::Instance().on_ContextMenu_motion_event(x, y);
	}

	//begin junhui.wang -- for change key modle to mouse module
	if(isKeyControl && !SCALE_ITEM_FLAG && EVENT_FLAG && !MOVE_TO_END 
					&& !MOVE_TO_BEGIN && !SCALE_LEFT && !SCALE_RIGHT){
		changeControlerToMouse(y);
	}
	//end junhui.wang

	KEY_LEFT = false;
	KEY_RIGHT = false;
	
	if(x < SCROLL_AREA && y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT)	
	{
		t_scrollout = 0;
		isOutScroll = false;
		SCROLL_LEFT = true;
		SCROLL_RIGHT = false;
		
		if(INIT_SPEED == 0) 
		{
			INIT_SPEED = ((INIT_MAXSPEED - INIT_MINSPEED )/SCROLL_AREA) * (SCROLL_AREA - x) + INIT_MINSPEED;
		}

		SCALE_SPEED = ((SCALE_MAXSPEED - SCALE_MINSPEED)/SCROLL_AREA) * (SCROLL_AREA - x) + SCALE_MINSPEED;
		LIMIT_SPEED = ((LIMIT_MAXSPEED - LIMIT_MINSPEED)/SCROLL_AREA) * (SCROLL_AREA - x) + LIMIT_MINSPEED;

		//liang.wu fix bug
		//cur_x = SCROLL_AREA;
		cur_x = x;
		
		return;
	}
	else if(SCENE_WIDTH - SCROLL_AREA < x && y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT)	
	{
		t_scrollout = 0;
		isOutScroll = false;
		SCROLL_LEFT = false;
		SCROLL_RIGHT = true;

		if(INIT_SPEED == 0) 
		{
			INIT_SPEED = ((INIT_MAXSPEED - INIT_MINSPEED )/SCROLL_AREA) * (x - (SCENE_WIDTH - SCROLL_AREA)) + INIT_MINSPEED;
		}
		
		SCALE_SPEED = ((SCALE_MAXSPEED - SCALE_MINSPEED)/SCROLL_AREA) * (x - (SCENE_WIDTH - SCROLL_AREA)) + SCALE_MINSPEED;
		LIMIT_SPEED = ((LIMIT_MAXSPEED - LIMIT_MINSPEED)/SCROLL_AREA) * (x - (SCENE_WIDTH - SCROLL_AREA)) + LIMIT_MINSPEED;

		//liang.wu fix bug
		//cur_x = SCENE_WIDTH - SCROLL_AREA;
		cur_x = x;
		
		return;
	}
	else 
	{
		if(SCROLL_LEFT == true || SCROLL_RIGHT == true) {

			//out of right scroll area, restart fovea contents
			scrollRightFlag = false;
			scrollRightTick = 0;
			scrollVerticalDiffRatio = 1.0;
			
			velocity = 0;
			INIT_SPEED = 0;
			SCALE_SPEED = 0;
			LIMIT_SPEED = 0;
			t_t = 0;
			t_scrollout = 0;
			if(y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT) {
				V_t = 0;
				SCROLL_LEFT = false;
				SCROLL_RIGHT = false;
			}
			else {
				V_t = min(V_t, STOP_LIMITSPEED);
		
				isOutScroll = true;
			}
		}
	}

#if 0
	if (y < SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT && y > SCENE_HEIGHT - BOTTOM_HEIGHT - WIDGET_HEIGHT - 50)
	{
		setfocusOptions();
	}
	else
	{
		setunfocusOptions();
	}
#endif
	
	
	cur_x = x;
	cur_y = y;
	
	if(clutter_actor_get_n_children(bar) == 1)
	{
		goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH / 2 + (currentIndex - 1) * NORMAL_CONTENTS_WIDTH;
	}
	else
	{
		goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2 + (currentIndex - 1) * NORMAL_CONTENTS_WIDTH;
	}
	
	goal_position = clutter_actor_get_x(bar);
}

float FirstScreenListWidget::getPositionX(std::string categoryType, int contentsIndex)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentContents = NULL;

	float position = 0.0f;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");

		return -10.0f;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");

			return -10.0f;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				//printf("There is no such category!!! Check id!!!\n");

				return -10.0f;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);

	currentContents = clutter_actor_get_child_at_index(currentList, contentsIndex);

	position = clutter_actor_get_x(bar) + clutter_actor_get_x(currentChild) + clutter_actor_get_x(currentContents);
	
	if (REVERSE_OSD)
	{
		return SCENE_WIDTH - position - FOCUS_CONTENTS_WIDTH;
	}

	return position;
}

float FirstScreenListWidget::getPositionY(std::string categoryType, int contentsIndex)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentContents = NULL;

	float position = 0.0f;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");

		return -10.0f;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");

			return -10.0f;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				//printf("There is no such category!!! Check id!!!\n");

				return -10.0f;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);

	currentContents = clutter_actor_get_child_at_index(currentList, contentsIndex);

	position = clutter_actor_get_y(bar) + clutter_actor_get_y(currentContents);

	return position;
}

static void contentLiveImage()
{
	if(contentLiveTick < aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE])
	{
		if(contentLiveTick == 0)
		{
			clutter_actor_set_scale(appLive[0], 1, 1);
			clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);

			clutter_actor_set_scale(gameLive[0], 1, 1);
			clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - aniTime[CONTENT_LIVE_TERM], aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_scale(appLive[0], 1 - (1 - contentLiveScaleX)*contentLiveDiff, 1 - (1 - contentLiveScaleY)*contentLiveDiff);
		clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));
	}
	else if(contentLiveTick < 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	{
		if(contentLiveTick >= aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE])
		{
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - (2*aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_x(appLive[1], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);
		clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));	
	}
	else if(contentLiveTick < 3*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	{
		if(contentLiveTick >= 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - (3*aniTime[CONTENT_LIVE_TERM] + 2*aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		if(!APPS_FOCUSED)
		{
			clutter_actor_set_scale(appLive[0], contentLiveScaleX - (contentLiveScaleX - 1)*contentLiveDiff, contentLiveScaleY - (contentLiveScaleY - 1)*contentLiveDiff);
			clutter_actor_set_x(appLive[2], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);
		}
		
		if(!GAMES_FOCUSED)
		{
			clutter_actor_set_scale(gameLive[0], 1 - (1 - contentLiveScaleX)*contentLiveDiff, 1 - (1 - contentLiveScaleY)*contentLiveDiff);
			clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));
		}
	}
	else if(contentLiveTick < 4*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	{
		if(contentLiveTick >= 3*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);
			
			if(GAMES_FOCUSED)
			{
				contentLiveTick = 0;

				return;
			}
		}

		contentLiveDiff = bezier(contentLiveTick - (4*aniTime[CONTENT_LIVE_TERM] + 3*aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_x(gameLive[1], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);
		clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));
	}
	//else if(contentLiveTick <= 5*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
	else
	{
		if(contentLiveTick >= 4*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(gameLive[1], NORMAL_CONTENTS_WIDTH);
		}

		contentLiveDiff = bezier(contentLiveTick - (5*aniTime[CONTENT_LIVE_TERM] + 4*aniTime[CONTENT_LIVE_EXCUTE]), aniTime[CONTENT_LIVE_EXCUTE], contentLive[0], contentLive[1], contentLive[2], contentLive[3]);

		clutter_actor_set_scale(gameLive[0], contentLiveScaleX - (contentLiveScaleX - 1)*contentLiveDiff, contentLiveScaleY - (contentLiveScaleY - 1)*contentLiveDiff);
		clutter_actor_set_x(gameLive[2], -NORMAL_CONTENTS_WIDTH*contentLiveDiff);

		if(!APPS_FOCUSED)
		{
			clutter_actor_set_scale(appLive[0], 1 - (1 - contentLiveScaleX)*contentLiveDiff, 1 - (1 - contentLiveScaleY)*contentLiveDiff);
			clutter_actor_set_x(appLive[1], NORMAL_CONTENTS_WIDTH*(1 - contentLiveDiff));
		}

		if(contentLiveTick >= 5*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]))
		{
			clutter_actor_set_x(appLive[2], NORMAL_CONTENTS_WIDTH);
			clutter_actor_set_x(gameLive[2], NORMAL_CONTENTS_WIDTH);

			if(APPS_FOCUSED)
			{
				contentLiveTick = 2*(aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE]);
			}
			else
			{
				contentLiveTick = aniTime[CONTENT_LIVE_TERM] + aniTime[CONTENT_LIVE_EXCUTE];
			}
		}
	}
}

static ClutterActor* getListWrapper(int categoryIndex)
{
    ClutterActor *child = clutter_actor_get_child_at_index(bar, categoryIndex);
    return clutter_actor_get_child_at_index(child, CATEGORY_LISTWRAPPER_INDEX);
}

static ClutterActor* getCategoryWrapper(int categoryIndex)
{
    ClutterActor *child = clutter_actor_get_child_at_index(bar, categoryIndex);
    return clutter_actor_get_child_at_index(child, CATEGORYWRAPPER_INDEX);
}

static void cal_mouse_over_scale()
{
    if (cur_x > SCALE_AREA && cur_x < SCENE_WIDTH - SCALE_AREA)
    {
        IsOutScaleArea = true; 
        return;
    }
    
    ClutterActor *secondChild = clutter_actor_get_child_at_index(bar, extendIndex);
    ClutterActor *firstChild = clutter_actor_get_child_at_index(bar, reduceIndex);
    if (!SCALE_RIGHT 
      && cur_x > SCENE_WIDTH - SCALE_AREA
      //&& ((int)(clutter_actor_get_x(bar)+clutter_actor_get_x(secondChild)+clutter_actor_get_width(secondChild)+SIDECATEGORY_GAP) == (int)SCENE_WIDTH
		&& (floatClose((clutter_actor_get_x(bar)+clutter_actor_get_x(secondChild)+clutter_actor_get_width(secondChild)+SIDECATEGORY_GAP), SCENE_WIDTH, 1.0)
		|| (int)(clutter_actor_get_x(bar)+clutter_actor_get_width(firstChild)+CATEGORY_GAP+clutter_actor_get_width(secondChild)) <= (int)(SCENE_WIDTH-SIDECATEGORY_GAP)))
    {
        IsOutScaleArea = false;
        SCALE_LEFT = false;
        SCALE_RIGHT = true;
        if (ScaleTicker == 0)
        {
            preIsKeyControl = isKeyControl;
            ClutterActor *firstChild = clutter_actor_get_child_at_index(bar, reduceIndex);
            ClutterActor *secondChild = clutter_actor_get_child_at_index(bar, extendIndex); //getListWrapper(1);
            clutter_actor_get_pivot_point(firstChild, &firstPrePivotX, &firstPrePivotY);
            clutter_actor_get_pivot_point(secondChild, &secondPrePivotX, &secondPrePivotY);
            clutter_actor_set_pivot_point(firstChild, 0, 0.5);
            clutter_actor_set_pivot_point(secondChild, 1, 0.5);

			//liang.wu
			if(FirstScreenADControl::GetInstance()->IsEnable())
			{
				ClutterActor *adChild = clutter_actor_get_child_at_index(bar, adIndex);
				clutter_actor_set_pivot_point(adChild, 1, 0.5);
				adMoveOriginX_scaleRight = clutter_actor_get_x(adChild);
			}

            if (isKeyControl)
            {
                SCALE_MAX_FRAME = SCALE_KEY_EVENT_FRAME;
                RECOVER_JUMP_FRAME = RECOVER_JUMP_KEY_EVENT_FRAME;
            }
            else
            {
                SCALE_MAX_FRAME = SCALE_MOUSE_EVENT_FRAME;
                RECOVER_JUMP_FRAME = RECOVER_JUMP_MOUSE_EVENT_FRAME;
            }
        }
    }
    else if (!SCALE_LEFT  
           && cur_x < SCALE_AREA
           && floatClose(clutter_actor_get_x(bar), SIDECATEGORY_GAP, 1.0))
           //&& (int)clutter_actor_get_x(bar) == (int)SIDECATEGORY_GAP)
    {
        IsOutScaleArea = false;
        SCALE_LEFT = true;
        SCALE_RIGHT = false;
        if (ScaleTicker == 0)
        {
            preIsKeyControl = isKeyControl;
            clutter_actor_get_pivot_point(bar, &prePivotX, &prePivotY);
            clutter_actor_set_pivot_point(bar, 0, 0.5);

			//liang.wu
			if(FirstScreenADControl::GetInstance()->IsEnable())
			{
				ClutterActor *adChild = clutter_actor_get_child_at_index(bar, adIndex);
				clutter_actor_set_pivot_point(adChild, 0, 0.5);
			}
			
            if (isKeyControl)
            {
                SCALE_MAX_FRAME = SCALE_KEY_EVENT_FRAME;
                RECOVER_JUMP_FRAME = RECOVER_JUMP_KEY_EVENT_FRAME;
            }
            else
            {
                SCALE_MAX_FRAME = SCALE_MOUSE_EVENT_FRAME;
                RECOVER_JUMP_FRAME = RECOVER_JUMP_MOUSE_EVENT_FRAME;
            }
        }
    }
}

static void onMoveCursor()
{
	gfloat distance_x = CursorDestPosition - CursorOriginPosition;
	gfloat distance_w = CursorDestWidth - CursorOriginWidth;

	setGlobalCursorX(CursorOriginPosition+distance_x*MoveCursorTicker/MOVE_CURSOR_FRAME);
	setGlobalCursorWidth(CursorOriginWidth+distance_w*MoveCursorTicker/MOVE_CURSOR_FRAME);
	if (CURSOR_SHOW_FLAG)
	{
		clutter_actor_set_opacity(globalCursor, MoveCursorTicker*1.f/MOVE_CURSOR_FRAME*255);
	}
	else
	{
		clutter_actor_set_opacity(globalCursor, 255-MoveCursorTicker*1.f/MOVE_CURSOR_FRAME*255);
	}
}

static void onScaleLeft()
{
    gfloat differ = easeOutCirc(ScaleTicker*1.f/SCALE_MAX_FRAME);
    clutter_actor_set_scale(bar, 
                            1.f+1.f/15.f*differ, 
                            1.f-1.f/15.f*differ);
}

static void onScaleRight()
{
    gfloat differ = easeOutCirc(ScaleTicker*1.f/SCALE_MAX_FRAME);
    ClutterActor *firstChild = clutter_actor_get_child_at_index(bar, reduceIndex);
    ClutterActor *secondChild = clutter_actor_get_child_at_index(bar, extendIndex);// getListWrapper(1);
    gfloat firstChildScaleX = 1.0+1.f/15.f*differ;
    gfloat secondChildScaleX = 1.0+1.f/15.f*differ;
    clutter_actor_set_scale(firstChild, 
                            firstChildScaleX, 
                            1.0-1.f/15.f*differ);
    clutter_actor_set_scale(secondChild, 
                            secondChildScaleX, 
                            1.0-1.f/15.f*differ);

	//liang.wu for scale cut origin
	reduceCutXDiff_scaleRight = clutter_actor_get_width(firstChild)*(firstChildScaleX-1.0);
	extendCutXDiff_scaleRight = clutter_actor_get_width(secondChild)*(secondChildScaleX-1.0);
	extendCutXRatio_scaleRight = (secondChildScaleX-1.0);
		
	if(FirstScreenADControl::GetInstance()->IsEnable())
	{
		ClutterActor *adChild = clutter_actor_get_child_at_index(bar, adIndex);
		gfloat adChildScaleX = 1.0+1.f/15.f*differ;
		gfloat adChildScaleY = 1.0-1.f/15.f*differ;
		clutter_actor_set_scale(adChild, adChildScaleX, adChildScaleY);
		adCutXDiff_scaleRight = clutter_actor_get_width(adChild)*(adChildScaleX-1.0);
		clutter_actor_set_x(adChild, adMoveOriginX_scaleRight - adCutXDiff_scaleRight - extendCutXDiff_scaleRight);
	}
}

static void scaleRight()
{
    ClutterActor *secondChild = clutter_actor_get_child_at_index(bar, extendIndex);
    ClutterActor *firstChild = clutter_actor_get_child_at_index(bar, reduceIndex);
    if (!SCALE_RIGHT
			&& (floatClose((clutter_actor_get_x(bar)+clutter_actor_get_x(secondChild)+clutter_actor_get_width(secondChild)+SIDECATEGORY_GAP), SCENE_WIDTH, 1.0)
			|| (int)(clutter_actor_get_x(bar)+clutter_actor_get_width(firstChild)+CATEGORY_GAP+clutter_actor_get_width(secondChild)) <= (int)(SCENE_WIDTH-SIDECATEGORY_GAP)))
    {
        pre_cur_x = cur_x;
        cur_x = SCENE_WIDTH;
		gfloat dest = SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP);
	    if (dest >= SIDECATEGORY_GAP)
		{
			dest = SIDECATEGORY_GAP;
		}
		CursorDestPosition = dest+clutter_actor_get_x(clutter_actor_get_child_at_index(bar, 1))
							+NORMAL_CONTENTS_WIDTH*(get_extend_itemCount()-1)+FOCUS_CONTENTS_WIDTH+clutter_actor_get_width(globalCursor);
		CursorOriginPosition = getGlobalCursorX();
		CursorOriginWidth = getGlobalCursorWidth();
		CursorDestWidth = CursorOriginWidth;
		MOVE_CURSOR = true;
		CURSOR_SHOW_FLAG = false;
    }
}

static void scaleLeft()
{
    if (!SCALE_LEFT && floatClose(clutter_actor_get_x(bar), SIDECATEGORY_GAP, 1.0))
    {
        pre_cur_x = cur_x;
        cur_x = 0;
		CursorDestPosition = 0-getGlobalCursorWidth();
		CursorOriginPosition = getGlobalCursorX();
		CursorOriginWidth = getGlobalCursorWidth();
		CursorDestWidth = CursorOriginWidth;
		MOVE_CURSOR = true;
		CURSOR_SHOW_FLAG = false;
    }
}

static void recoverLeft()
{
    if (SCALE_LEFT)
    {
        cur_x = pre_cur_x;
    }
}

static void recoverRight()
{
    if (SCALE_RIGHT)
    {
        cur_x = pre_cur_x;
    }
}

static void onMoveToBegin()
{
    gfloat differ = bezier(MovingTicker,
                           MOVE_TO_BEGIN_END_FRAME,
                           vMoveing[0],
                           vMoveing[1],
                           vMoveing[2],
                           vMoveing[3]);
    gfloat nextPostion = MoveOriginPosition-(MoveOriginPosition-SIDECATEGORY_GAP)*differ;
    clutter_actor_set_x(bar, nextPostion);


	if (MOVE_TO_BEGIN_END_FRAME - MovingTicker == MOVE_CURSOR_FRAME)
	{	
		setGlobalCursorHeight(WIDGET_HEIGHT);
		setGlobalCursorY(SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		CursorOriginPosition = 0-getGlobalCursorWidth();
		CursorDestPosition = SIDECATEGORY_GAP;
		CursorOriginWidth = getGlobalCursorWidth();
		CursorDestWidth = NORMAL_CATEGORY_WIDTH;
		MOVE_CURSOR = true;
		CURSOR_SHOW_FLAG = true;
	}
}

static void onMoveToEnd()
{
    gfloat differ = bezier(MovingTicker,
                           MOVE_TO_BEGIN_END_FRAME,
                           vMoveing[0],
                           vMoveing[1],
                           vMoveing[2],
                           vMoveing[3]);
    gfloat dest = SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP);
    if (dest >= SIDECATEGORY_GAP)
	{
		dest = SIDECATEGORY_GAP;
	}
	gfloat nextPosition = MoveOriginPosition-(MoveOriginPosition-dest)*differ;
	clutter_actor_set_x(bar, nextPosition); 

	if (MOVE_TO_BEGIN_END_FRAME - MovingTicker == MOVE_CURSOR_FRAME)
	{	
		setGlobalCursorHeight(WIDGET_HEIGHT);
		setGlobalCursorY(SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		CursorOriginPosition = dest+clutter_actor_get_x(clutter_actor_get_child_at_index(bar, 1))
							+NORMAL_CONTENTS_WIDTH*(get_extend_itemCount()-1)+FOCUS_CONTENTS_WIDTH;
		CursorDestPosition = dest+clutter_actor_get_x(clutter_actor_get_child_at_index(bar, 1))
							+NORMAL_CONTENTS_WIDTH*(get_extend_itemCount()-1);
		CursorOriginWidth = getGlobalCursorWidth();
		CursorDestWidth = FOCUS_CONTENTS_WIDTH;
		MOVE_CURSOR = true;
		CURSOR_SHOW_FLAG = true;
	}
}

static void afterMoveToEnd()
{
    MovingTicker = 0;
    MOVE_TO_END = false;
	goal_position = SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH + SIDECATEGORY_GAP);
	
	if (goal_position >= SIDECATEGORY_GAP)
	{
		goal_position = SIDECATEGORY_GAP;
	}
	
	cur_x = goal_x	= goal_position + (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (get_extend_itemCount() - 1) + FOCUS_CONTENTS_WIDTH / 2 );
	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;
	
	//move_rect();
	if (instance != NULL) 
	{
		ScriptArray arr;
		instance->onMoveFocuseListener.invoke(arr);
		#ifdef _OBJECTDUMP_
		FirstScreenListWidget::Instance()->objectDumpCallback();
		#endif
	}
}

static void afterMoveToBegin()
{
    MovingTicker = 0;
    MOVE_TO_BEGIN = false;
    goal_position = SIDECATEGORY_GAP;

	if (extendIndex == 0)
	{
		cur_x = goal_x = SIDECATEGORY_GAP + FOCUS_CONTENTS_WIDTH / 2;
	}
	else
	{
		cur_x = goal_x = SIDECATEGORY_GAP + FOCUS_CATEGORY_WIDTH / 2;
	}

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100;

	//move_rect();
	int lastContent = get_extend_itemCount()-1;
	toNormalContents(1, lastContent, 0);

	if (instance != NULL) 
	{
		ScriptArray arr;
		instance->onMoveFocuseListener.invoke(arr);
	}
}

static void on_timeline_new_frame(ClutterTimeline *timeline, gint frame_num, gpointer data)
{	
	if(STOP_FLAG)
	{
		return;
	}

	//before init ok, do not action
	if(NO_CONTENTS_FLAG)
	{
		STOP_FLAG = true;
		return;
	}
	
	if (scrollCheckTick ++ % 10 == 0)
	{
		checkTitleScroll();
	}

	#ifdef TIME_TYPE_TEST
	beginTimelineCB();
	#endif
	
	if(EVENT_FLAG)
	{
		if(clutter_actor_get_n_children(bar) >= 2)
		{
			//categoryLiveImage();
			FirstScreenCategoryLiveControl::GetInstance()->RefreshFrame();
		}

		if(CONTENT_LIVE_FLAG && appLive[2] != NULL && gameLive[2] != NULL)
		{
			contentLiveImage();
			
			contentLiveTick++;
			
			//skipContentLiveTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
		
			//contentLiveTick += skipContentLiveTick;
		}

		if (MOVE_CURSOR)
		{
			onMoveCursor();
			MoveCursorTicker++;
			if (MoveCursorTicker > MOVE_CURSOR_FRAME)
			{
				MoveCursorTicker = 0;
				MOVE_CURSOR = false;
				CURSOR_SHOW_FLAG = false;

				MOVE_CURSOR_FRAME = 15;
				//CursorOriginPosition = 0.0;
				//CursorDestPosition = 0.0;
				//CursorOriginWidth = 0.0;
				//CursorDestWidth = 0.0;
			}
		}

		if (MOVE_TO_BEGIN)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_move_to);
			#endif
			
		    if (MovingTicker > MOVE_TO_BEGIN_END_FRAME)
		    {
		        afterMoveToBegin();
		    }
		    else 
		    {
		        onMoveToBegin();
		        ++MovingTicker;
		    }
    		fixCategory();
    		cutCategory();
	        fixOverlapShadow();

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_move_to);
			#endif
		}
		
		if (MOVE_TO_END)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_move_to);
			#endif
			
		    if (MovingTicker > MOVE_TO_BEGIN_END_FRAME)
		    {
		        afterMoveToEnd();
		    }
		    else 
		    {
		        onMoveToEnd();
		        ++MovingTicker;
		    }
    		fixCategory();
    		cutCategory();
	        fixOverlapShadow();

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_move_to);
			#endif
		}
		
        /*add by lin89.zhang for SCALE while mouse reach the edge of the screen begin */
		cal_mouse_over_scale();
        if (SCALE_LEFT)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_scale_area);
			#endif
			
		    if (!IsOutScaleArea)
		    {
		        ScaleTicker = ScaleTicker>SCALE_MAX_FRAME?ScaleTicker:1+ScaleTicker;
		        onScaleLeft();
		        if (isKeyControl && ScaleTicker>SCALE_MAX_FRAME)
		        {
					::recoverLeft();
					ClutterActor* secondChild = clutter_actor_get_child_at_index(bar, extendIndex);
	                ClutterActor* secondList = clutter_actor_get_child_at_index(secondChild, CATEGORYWRAPPER_INDEX);
					if(clutter_actor_get_x(bar)
                            +clutter_actor_get_x(secondChild)
                            +clutter_actor_get_width(secondList) < SCENE_WIDTH)
					{
						if (clutter_actor_get_x(bar)
	                            +clutter_actor_get_x(secondChild)
	                            +clutter_actor_get_width(secondList) < SCENE_WIDTH) 
	                    {
							CursorOriginPosition = SIDECATEGORY_GAP+clutter_actor_get_x(secondChild)
												+NORMAL_CONTENTS_WIDTH*(get_extend_itemCount()-1)+FOCUS_CONTENTS_WIDTH;
							CursorDestPosition = SIDECATEGORY_GAP+clutter_actor_get_x(secondChild)
												+NORMAL_CONTENTS_WIDTH*(get_extend_itemCount()-1);
							CursorOriginWidth = getGlobalCursorWidth();
							CursorDestWidth = FOCUS_CONTENTS_WIDTH;
							MOVE_CURSOR = true;
							CURSOR_SHOW_FLAG = true;
	                    }
					}
		        }
		    }
		    else 
		    {
		        if (ScaleTicker <= 0)
		        {
		            ScaleTicker=0;
		            onScaleLeft();
                    SCALE_LEFT=false;
                    clutter_actor_set_pivot_point(bar, prePivotX, prePivotY);
                    if (preIsKeyControl)
                    {
                        ClutterActor* secondChild = clutter_actor_get_child_at_index(bar, extendIndex);
                        ClutterActor* secondList = clutter_actor_get_child_at_index(secondChild, CATEGORYWRAPPER_INDEX);
                        if (clutter_actor_get_x(bar)
                            +clutter_actor_get_x(secondChild)
                            +clutter_actor_get_width(secondList) < SCENE_WIDTH) 
                        {
                            moveToEndImmd(false);
                        }
                        else
                        {
                            moveToEnd();
                        }
                    }
		        }
		        else
		        {
		            ScaleTicker = ScaleTicker-RECOVER_JUMP_FRAME<0?0:ScaleTicker-RECOVER_JUMP_FRAME;
		            onScaleLeft();
		        }
		    }

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_scale_area);
			#endif
		}
		if (SCALE_RIGHT)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_scale_area);
			#endif
			
		    if (!IsOutScaleArea)
		    {
		        ScaleTicker>SCALE_MAX_FRAME?ScaleTicker:++ScaleTicker;
		        onScaleRight();
		        if (isKeyControl && ScaleTicker>SCALE_MAX_FRAME)
		        {
		            ::recoverRight();
		            if(floatClose(clutter_actor_get_x(bar), SIDECATEGORY_GAP, 1.0))
		            {
		            	CursorOriginPosition = 0-getGlobalCursorWidth();
		            	CursorDestPosition = SIDECATEGORY_GAP;
						CursorOriginWidth = getGlobalCursorWidth();
						CursorDestWidth = FOCUS_CATEGORY_WIDTH;
						MOVE_CURSOR = true;
						CURSOR_SHOW_FLAG = true;
		            }
		        }
		    }
		    else 
		    {
		        if (ScaleTicker<=0)
		        {
		            ScaleTicker = 0;
		            onScaleRight();
		            SCALE_RIGHT=false;
		            ClutterActor *firstChild = clutter_actor_get_child_at_index(bar, reduceIndex);
                    ClutterActor *secondChild = clutter_actor_get_child_at_index(bar, extendIndex); //getListWrapper(1);
                    clutter_actor_set_pivot_point(firstChild, firstPrePivotX, firstPrePivotY);
                    clutter_actor_set_pivot_point(secondChild, secondPrePivotX, secondPrePivotY);
                    clutter_actor_remove_clip(secondChild);

					if(FirstScreenADControl::GetInstance()->IsEnable())
					{
						//liang.wu recover ad attributes
						adCutXDiff_scaleRight = 0.0;
						extendCutXDiff_scaleRight = 0.0;
						extendCutXRatio_scaleRight = 1.0;
						reduceCutXDiff_scaleRight = 0.0;
						ClutterActor *adChild = clutter_actor_get_child_at_index(bar, adIndex);
						clutter_actor_set_pivot_point(adChild, 0, 0.5);
					}
					
                    if (preIsKeyControl)
                    {
                        //if (clutter_actor_get_x(bar) == SIDECATEGORY_GAP)
                        if(floatClose(clutter_actor_get_x(bar), SIDECATEGORY_GAP, 1.0))
                            moveToBeginImmd();
                        else
                            moveToBegin();
                    }
		        }
		        else
		        {
		            ScaleTicker = ScaleTicker-RECOVER_JUMP_FRAME<0?0:ScaleTicker-RECOVER_JUMP_FRAME;
		            onScaleRight();
		        }
		    }

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_scale_area);
			#endif
		}
		/*add by lin89.zhang for SCALE while mouse reach the edge of the screen end */

		if(KEY_RIGHT && !ON_TRANSITION) 
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_key_move);
			#endif
			
			gfloat bar_x = clutter_actor_get_x(bar);
			if(bar_x + ratio_position <= goal_position)
			{
				clutter_actor_set_x(bar, goal_position);
			}
			else
			{
				clutter_actor_set_x(bar, bar_x + ratio_position);
			}
			
			if(!AD_CURSOR_FLAG)
			{
				if(cur_x + ratio_point >= goal_x)
				{
					cur_x = goal_x;
				}
				else
				{
					cur_x += ratio_point;
				}
			}

			//adjust global cursor position to stable when bar scroll
			if(!AD_CURSOR_FLAG)
			{
				clutter_actor_set_x(globalCursor, cur_x - clutter_actor_get_width(globalCursor)/2);
			}

			if(AD_CURSOR_FLAG)
			{
				if(floatClose(clutter_actor_get_x(bar), goal_position, 1.0))
				{
					KEY_RIGHT = false;
					if (instance) 
					{
						ScriptArray arr;
						instance->onMoveFocuseListener.invoke(arr);

						#ifdef _OBJECTDUMP_
						FirstScreenListWidget::Instance()->objectDumpCallback();
						#endif
					}
				}
			}
			else
			{
				int t_count = get_extend_itemCount();
				if(floatClose(clutter_actor_get_x(bar), goal_position, 1.0) 
					&& floatClose(cur_x, goal_x, 1.0))
				{
					KEY_RIGHT = false;
					if (instance != NULL) 
					{
						ScriptArray arr;
						instance->onMoveFocuseListener.invoke(arr);
						#ifdef _OBJECTDUMP_
						FirstScreenListWidget::Instance()->objectDumpCallback();
						#endif
					}
				}
			}

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_key_move);
			#endif
		}

		if(KEY_LEFT && !ON_TRANSITION) 
		{	
			#ifdef TIME_TYPE_TEST
			startTime(time_type_key_move);
			#endif

			gfloat bar_x = clutter_actor_get_x(bar);
			if(bar_x + ratio_position >= goal_position) 
			{
				clutter_actor_set_x(bar, goal_position);
			}
			else 
			{
				clutter_actor_set_x(bar, bar_x + ratio_position);
			}
			
			if(!AD_CURSOR_FLAG)
			{
				if(cur_x + ratio_point <= goal_x) 
				{
					cur_x = goal_x;
				}
				else {
					cur_x += ratio_point;
				}
			}

			//adjust global cursor position to stable when bar scroll
			if(!AD_CURSOR_FLAG)
			{
				clutter_actor_set_x(globalCursor, cur_x - clutter_actor_get_width(globalCursor)/2);
			}

			if(AD_CURSOR_FLAG)
			{
				if(floatClose(clutter_actor_get_x(bar), goal_position, 1.0))
				{
					KEY_LEFT = false;
					if (instance != NULL) 
					{
						ScriptArray arr;
						instance->onMoveFocuseListener.invoke(arr);

						#ifdef _OBJECTDUMP_
						FirstScreenListWidget::Instance()->objectDumpCallback();
						#endif
					}
				}
			}
			else
			{
				if(floatClose(clutter_actor_get_x(bar), goal_position, 1.0) 
					&& floatClose(cur_x, goal_x, 1.0))
				{
					KEY_LEFT = false;
					if (instance) 
					{
						ScriptArray arr;
						instance->onMoveFocuseListener.invoke(arr);
						#ifdef _OBJECTDUMP_
						FirstScreenListWidget::Instance()->objectDumpCallback();
						#endif
					}
				}
			}

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_key_move);
			#endif
		}

		if(SCROLL_LEFT)  
		{
			//scrollLeft();
			#ifdef TIME_TYPE_TEST
			startTime(time_type_scroll_area);
			#endif

			if(isOutScroll) 
			{
				if(clutter_actor_get_x(bar) >= 0 || V_t < 0)
				{
					SCROLL_LEFT = false;
					SCROLL_RIGHT = false;
					V_t = 0;
					t_t = 0;
					t_scrollout = 0;
					isOutScroll = false;
				}
				else 
				{
					//modify by junhui.wang
					clutter_actor_set_x(bar, clutter_actor_get_x(bar) + V_t);
					t_scrollout += 0.16;
					//gfloat temp = (t_scrollout / STOPSCROLL_TIME);
					gfloat e = min(t_scrollout,STOPSCROLL_TIME);
					gfloat k = bezier(e,STOPSCROLL_TIME,0.0,0.0,1.0,1.0);
					//V_t = V_t + (-V_t * temp * temp);	
					V_t = V_t * (1-k);
				}
			}
			else 
			{
				scrollLeft_Rollover();
			}

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_scroll_area);
			#endif
		}

		if(SCROLL_RIGHT)  
		{
			//scrollRight();
			#ifdef TIME_TYPE_TEST
			startTime(time_type_scroll_area);
			#endif
			
			int t_count = get_extend_itemCount();
			if(isOutScroll)
			{
				if( V_t < 0 || clutter_actor_get_x(bar) <= SCENE_WIDTH - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * (t_count-1) + FOCUS_CONTENTS_WIDTH) )
				{
					SCROLL_RIGHT = false;
					SCROLL_LEFT = false;
					V_t = 0;
					t_t = 0;
					t_scrollout = 0;
					isOutScroll = false;
				}
				else 
				{
					//modify by junhui.wang
					clutter_actor_set_x(bar, clutter_actor_get_x(bar) - V_t);
					t_scrollout += 0.16;
					//gfloat temp = (t_scrollout / STOPSCROLL_TIME);
					gfloat e = min(t_scrollout,STOPSCROLL_TIME);
					gfloat k = bezier(e,STOPSCROLL_TIME,0.0,0.0,1.0,1.0);
					//V_t = V_t + (-V_t * temp * temp);	
					V_t = V_t * (1-k);
				}
			}
			else 
			{
				scrollRight_Rollover();

				//calculate scroll right time
				if(scrollRightFlag)
				{
					if(scrollRightTick < scrollRightTickMax)
					{
						scrollRightTick++;
					}
					scrollVerticalDiffRatio = 1.0 - scrollRightTick / scrollRightTickMax;
				}
			}

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_scroll_area);
			#endif
		}
#if 0
		if(KEY_SELECT) 
		{
			//on_transition3();
			
			if(!KEY_SELECT)
				return;
			
			//[liang.wu]fixed scroll action
			fixCategory();
			cutCategory();

			//lin89.zhang
			fixOverlapShadow();

			#ifdef TIME_TYPE_TEST
			endTimelineCB();
			#endif
			
			return;
		}
#endif
		if(!ON_TRANSITION && !KEY_SELECT && !MOVE_TO_BEGIN && !MOVE_TO_END && !MOVE_CURSOR) 
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_move_rect);
			#endif
			
			move_rect();

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_move_rect);
			#endif
		}

		//[liang.wu]fixed scroll action
		fixCategory();
		cutCategory();

		//liang.wu
		fixOverlapShadow();
		cal_display_performance();
	}
	else
	{
		//reduce animation
		if(REDUCE_FLAG)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_reduce_effect);
			#endif
			
			reduceTick++;
			//gfloat skipTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
			//reduceTick += skipTick;
			
			reduceDiff = bezier(reduceTick, aniTime[REDUCE], reduceCurve[0], reduceCurve[1], reduceCurve[2], reduceCurve[3]);
			reduceEffect();

			if(reduceTick >= aniTime[REDUCE])
			{
				REDUCE_FLAG = false;//stop reduce
				reduceTick = 0;
				//add by junhui.wang for card effect
				reverseChildIndex(clutter_actor_get_child_at_index(clutter_actor_get_child_at_index(bar, reduceIndex),CATEGORY_LISTWRAPPER_INDEX));
			}

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_reduce_effect);
			#endif
		}

		//recover animation
		if(RECOVER_FLAG)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_recover_effect);
			#endif
			
			recoverTick++;
			//gfloat skipTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
			//recoverTick += skipTick;
			
			recoverDiff = bezier(recoverTick, aniTime[RECOVER], recoverCurve[0], recoverCurve[1], recoverCurve[2], recoverCurve[3]);
			recoverEffect();

			if(recoverTick >= aniTime[RECOVER])
			{
				RECOVER_FLAG = false;
				recoverTick = 0;
			}

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_recover_effect);
			#endif
		}

		//exchange animation
		if(EXCHANGE_FLAG)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_exchange_effect);
			#endif
			
			exchangeTick++;
			//gfloat skipTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
			//exchangeTick += skipTick;
			
			exchangeDiffToLeft = bezier(exchangeTick, aniTime[EXCHANGE], exchangeCurveToLeft[0], exchangeCurveToLeft[1], exchangeCurveToLeft[2], exchangeCurveToLeft[3]);
			exchangeDiffToRight = bezier(exchangeTick, aniTime[EXCHANGE], exchangeCurveToRight[0], exchangeCurveToRight[1], exchangeCurveToRight[2], exchangeCurveToRight[3]);
			exchangeEffect();

			if(exchangeTick >= aniTime[EXCHANGE])
			{
				EXCHANGE_FLAG = false;
				exchangeTick = 0;
				exchangeControler();//start extend
			}

			#ifdef TIME_TYPE_TEST
			recordTime(time_type_exchange_effect);
			#endif
		}

		//extend animation
		if(EXTEND_FLAG)
		{
			#ifdef TIME_TYPE_TEST
			startTime(time_type_extend_effect);
			#endif
			
			extendTick++;
			//gfloat skipTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
			//extendTick += skipTick;
			
			extendDiff = bezier(extendTick, aniTime[EXTEND], extendCurve[0], extendCurve[1], extendCurve[2], extendCurve[3]);
			extendEffect();

			if(extendTick >= aniTime[EXTEND])
			{
				EXTEND_FLAG = false;
				extendTick = 0;
				//add by junhui.wang for card effect
				reverseChildIndex(clutter_actor_get_child_at_index(clutter_actor_get_child_at_index(bar, extendIndex),CATEGORY_LISTWRAPPER_INDEX));
				exchangeControler();//reset status must behind reverseChildIndex, because of extendIndex will be disabled here
			}

			//animation over
	 		if(!REDUCE_FLAG && !RECOVER_FLAG && !EXCHANGE_FLAG && !EXTEND_FLAG)
	 		{
	 			tick = 0;
	 			//livetick = 0;
	 			//FirstScreenCategoryLiveControl::GetInstance()->RefreshFrame(true);
	 			contentLiveTick = 0;

				//live setting
				std::string tempName;
				tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, reduceIndex));
				if(tempName.compare("featured") == 0)
				{
					CONTENT_LIVE_FLAG = false;
					FirstScreenCategoryLiveControl::GetInstance()->EnableFeaturedLiveReal(true);
				}
				else
				{
					CONTENT_LIVE_FLAG = true;
					FirstScreenCategoryLiveControl::GetInstance()->EnableFeaturedLiveReal(false);
				}

				//cursor control
				if(isKeyControl){
					if(clutter_actor_get_n_children(bar) == 1)
					{
						cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
						//global cursor
						clutter_actor_set_opacity(globalCursor,255);
						//clutter_actor_set_x(globalCursor,clutter_actor_get_x(bar));
						setGlobalCursorX(clutter_actor_get_x(bar));
					}
					else if(clutter_actor_get_n_children(bar) >= 2)
					{
						cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
						//global cursor
						clutter_actor_set_opacity(globalCursor,255);
						//clutter_actor_set_x(globalCursor,clutter_actor_get_x(bar)+NORMAL_CATEGORY_WIDTH+CATEGORY_GAP);
						setGlobalCursorX(clutter_actor_get_x(bar)+NORMAL_CATEGORY_WIDTH+CATEGORY_GAP);
					}
				}else{
					if(clutter_actor_get_n_children(bar) == 1)
					{
						cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CONTENTS_WIDTH/2;
					}
					else if(clutter_actor_get_n_children(bar) >= 2)
					{
						cur_x = goal_x = clutter_actor_get_x(bar) + FOCUS_CATEGORY_WIDTH/2;
					}
				}
				cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;

				move_rect();
			}
			#ifdef TIME_TYPE_TEST
			recordTime(time_type_extend_effect);
			#endif
		}

		//begin junhui.wang 
		if(SCALE_ITEM_FLAG)
		{
			scaleItemTick++;
			//gfloat skipTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
			//scaleItemTick += skipTick;

			//if((scaleItemTick-skipTick) < scaleItemTime && scaleItemTick > scaleItemTime){
				//scaleItemTick= scaleItemTime;
			//}
			
			if(scaleItemTick > scaleItemTime)
			{
				scaleItemTick = 0;
				//reset the state
				int tAllCategoryCount = clutter_actor_get_n_children(bar);
				gfloat posLeft = 0.0f;
				gfloat posRight = 0.0f;
				if(currentCategory == 0 && tAllCategoryCount ==1){
					posLeft = clutter_actor_get_x(bar) + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents;
					posRight = posLeft + FOCUS_CONTENTS_WIDTH;
					if(posLeft <= 0)
					{
						goal_position = -(CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents) + CATEGORY_GAP;
						clutter_actor_set_x(bar, goal_position);
					}	
					if(posRight >= SCENE_WIDTH)
					{
						goal_position = SCENE_WIDTH -(CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents) + CATEGORY_GAP;
						clutter_actor_set_x(bar, goal_position);
					}	
					cur_x = goal_x = clutter_actor_get_x(bar) + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents + FOCUS_CONTENTS_WIDTH/2;
				}
				else{
					gfloat leftLimitX = clutter_actor_get_x(bar) + clutter_actor_get_x(clutter_actor_get_child_at_index(bar, reduceIndex))+ clutter_actor_get_width(clutter_actor_get_child_at_index(bar, reduceIndex))+ CATEGORY_GAP;		

					int itemCount = clutter_actor_get_n_children(clutter_actor_get_child_at_index(bar, extendIndex));
					
					posLeft = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents;
					posRight = posLeft + FOCUS_CONTENTS_WIDTH;
					if(posLeft <= leftLimitX)
					{
						goal_position = leftLimitX - (NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents);
						clutter_actor_set_x(bar, goal_position);
					}	
					if(posRight >= SCENE_WIDTH)
					{
						if(currentContents == (itemCount-1))
							goal_position = SCENE_WIDTH -(NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents) - FOCUS_CONTENTS_WIDTH - CATEGORY_GAP;
						else
							goal_position = SCENE_WIDTH -(NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents) - FOCUS_CONTENTS_WIDTH;
						clutter_actor_set_x(bar, goal_position);
					}	
					cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH*currentContents + FOCUS_CONTENTS_WIDTH/2;
				}

				cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;
				
				move_rect();
				SCALE_ITEM_FLAG = false;
				EVENT_FLAG = true;
			}
			else
			{
				gfloat changediff = bezier(scaleItemTick, scaleItemTime, scaleItem[0], scaleItem[1], scaleItem[2], scaleItem[3]);
				scaleItemVerticalDiff  = scaleItemCurVerticalDiff + (scaleItemDesVerticalDiff-scaleItemCurVerticalDiff)*changediff;
				scaleItemDiff = scaleItemCurDiff + (scaleItemDesDiff - scaleItemCurDiff)*changediff;
				verticalDiff = scaleItemVerticalDiff;
				ScaleContentItemAnimation(scaleItemDiff,scaleItemIndex);
			}
		}

		if(SCALE_CATEGORY_FLAG){
			scaleCategoryTick++;
			if(scaleCategoryTick > scaleCategoryTime){
				scaleCategoryTick = 0;
				SCALE_CATEGORY_FLAG = false;
				EVENT_FLAG = true;
			}else{
				gfloat changediff = bezier(scaleCategoryTick, scaleCategoryTime, scaleItem[0], scaleItem[1], scaleItem[2], scaleItem[3]);
				ScaleCategoryAnimation(changediff);
			}
		}

		if(REDUCE_CATEGORY_FLAG){
			reduceCategoryTick++;
			if(reduceCategoryTick > reduceCategoryTime){
				reduceCategoryTick = 0;
				REDUCE_CATEGORY_FLAG = false;
				EVENT_FLAG = true;
			}else{
				gfloat changediff = bezier(reduceCategoryTick, reduceCategoryTime, reduceItem[0], reduceItem[1], reduceItem[2], reduceItem[3]);
				ReduceCategoryAnimation(changediff);
			}
		}

		if(REDUCE_ITEM_FLAG)
		{
			reduceItemTick++;
			//gfloat skipTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
			//reduceItemTick += skipTick;
			
			//if((reduceItemTick-skipTick) < reduceItemTime && reduceItemTick > reduceItemTime){
				//reduceItemTick= reduceItemTime;
			//}
			
			if(reduceItemTick > reduceItemTime){				
				reduceItemTick = 0;
				REDUCE_ITEM_FLAG = false;
				EVENT_FLAG = true;
			}else{
				reduceItemDiff = bezier(reduceItemTick, reduceItemTime, reduceItem[0], reduceItem[1], reduceItem[2], reduceItem[3]);
				ReduceContentItemAnimation(reduceItemIndex);
			}
		}
		//end junhui.wang
	}
	//lin89.zhang
	//if (!SCALE_LEFT && !SCALE_RIGHT) { //modify by lin89.zhang
	    //fixOverlapShadow();
	//}

	#ifdef TIME_TYPE_TEST
	endTimelineCB();
	#endif
}


int nActor = 0;

static void printDump(ClutterActor* current, ClutterActor* testList, int prevIndent)
{
	nActor++;
	
	int indent = prevIndent + 1;

	ClutterActor *child = NULL;
	
	gfloat x, y, actorWidth, actorHeight;
	guint32 ID = NULL;
	gint count = clutter_actor_get_n_children(current);

	clutter_actor_get_position(current, &x, &y);
	clutter_actor_get_size(current, &actorWidth, &actorHeight);
	ID = clutter_actor_get_gid(current);

	if(G_TYPE_CHECK_INSTANCE_TYPE(current, CLUTTER_TYPE_ACTOR))
	{
		ostringstream oss;
		string out;
		
		for(int j=0; j < indent; j++)
		{
			oss<<"- ";
		}
	
		if(G_TYPE_CHECK_INSTANCE_TYPE(current, CLUTTER_TYPE_TEXT))
		{
			oss<<"[TextWidget, 0x"<< hex << ID << dec;
			oss<<", \""<< clutter_text_get_text(CLUTTER_TEXT(current)) << "\", FA, (";
			oss<< (int)x << ", " << (int)y << ", " << (int)actorWidth << ", " << (int)actorHeight << ")]";
		}
		else if(G_TYPE_CHECK_INSTANCE_TYPE(current, CLUTTER_TYPE_TEXTURE))
		{
			oss<<"[ImageWidget, 0x"<< hex << ID << dec;
			oss<<", FA, (";
			oss<< (int)x << ", " << (int)y << ", " << (int)actorWidth << ", " << (int)actorHeight << ")]";
		}
		else
		{
			oss<<"[Widget, 0x"<< hex << ID << dec;
			oss<<", FA, (";
			oss<< (int)x << ", " << (int)y << ", " << (int)actorWidth << ", " << (int)actorHeight << ")]";
		}

		out = oss.str();
		
		LOG_DEBUG(objectDumpLogger, out);

		for(int i = 0; i < count ; i++)
		{
			child = clutter_actor_get_child_at_index(current, i);
			clutter_actor_get_position(child, &x, &y);
			clutter_actor_get_size(child, &actorWidth, &actorHeight);
			ID = clutter_actor_get_gid(child);

			printDump(child, testList, indent);
		}
	}
	else
	{
		return;
	}
}

void FirstScreenListWidget::objectDump()
{
	if(currentCategory == EMPTY)
	{
		return;
	}
	else
	{
		nActor = 0;
		
		LOG_DEBUG(logger, "--------------------------------------------------FirstScreen ObectDump Begin--------------------------------------------------");

		printDump(bar, NULL, -1);	
	
		LOG_DEBUG(logger, "Actor number is : " << nActor);
		LOG_DEBUG(logger, "---------------------------------------------------FirstScreen ObectDump End---------------------------------------------------");
	}
}

void FirstScreenListWidget::startAnimation()
{
	if(timeline && clutter_timeline_is_playing(timeline) && !STOP_FLAG)
	{
		return;
	}
		
	LOG_DEBUG(logger, "FirstScreenListWidget::startAnimation()");

	if(NULL == timeline)
	{
		g_signal_connect(mouseArea, "button-press-event", G_CALLBACK(on_stage_button_press_event), this);
		g_signal_connect(mouseArea, "button-release-event", G_CALLBACK(on_stage_button_release_event), this);
		g_signal_connect(mouseArea, "motion-event", G_CALLBACK(on_stage_motion_event), this);

		timeline = clutter_timeline_new(16);
		g_signal_connect(timeline, "new-frame", G_CALLBACK(on_timeline_new_frame), this);
	}
	
	if(clutter_actor_get_n_children(bar) == 1)
	{
		return;//error
	}
	else if(clutter_actor_get_n_children(bar) >= 2)
	{
		reduceIndex = 0;
		extendIndex = 1;

		//recoverCategory();
		//recoverDiff = 1.0;
		//recoverEffect();

		reduceCategory(reduceIndex);
		reduceDiff = 1.0;
		reduceEffect();
		
		extendCategory(extendIndex);
		extendDiff = 1.0;
		extendEffect();

		isKeyControl = true;
		if(NO_CONTENTS_FLAG)
		{
			//setGlobalCursorX(SIDECATEGORY_GAP);
			setGlobalCursorPosition(SIDECATEGORY_GAP , SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
			//setGlobalCursorWidth(FOCUS_CATEGORY_WIDTH);
			setGlobalCursorSize(FOCUS_CATEGORY_WIDTH, WIDGET_HEIGHT);
		}
		else
		{
			setGlobalCursorPosition(SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP, 
				SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
			//setGlobalCursorX(SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP);
			//setGlobalCursorWidth(FOCUS_CONTENTS_WIDTH);
			setGlobalCursorSize(FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
		}
		clutter_actor_set_opacity(globalCursor, 255);

		//lin89.zhang set shadow effect
		fixOverlapShadow();

		isOpen[0] = false;
		isOpen[1] = true;

		cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;//must set it
		cur_x = goal_x = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
		goal_position = SIDECATEGORY_GAP;
		clutter_actor_set_x(bar, goal_position);
		
		REDUCE_FLAG = false;
		RECOVER_FLAG = false;
		EXCHANGE_FLAG = false;
		EXTEND_FLAG = false;
		SCALE_ITEM_FLAG = false;
		REDUCE_ITEM_FLAG = false;
		SCALE_CATEGORY_FLAG = false;
		REDUCE_CATEGORY_FLAG = false;
	
		CONTENT_LIVE_FLAG = false;
	}

	STOP_FLAG = false;
	EVENT_FLAG = true;
    optionStaus = UNFOCUS;
    
	clutter_timeline_set_loop(timeline, TRUE);
	clutter_timeline_start(timeline);
}

void FirstScreenListWidget::stopAnimation()
{
	STOP_FLAG = true;	
	EVENT_FLAG = false;
	//clutter_timeline_stop(timeline);
}

void FirstScreenListWidget::updateDominantColor(std::string categoryType, int contentsIndex, Color dominantColor)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *dominant = NULL;
	ClutterActor *overRay = NULL;
	ClutterColor overRayColor = {0, 0, 0, 255};

	std::string childName;
	if(clutter_actor_get_n_children(bar) == 0)
	{
		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);	
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}
	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
	currentChild = clutter_actor_get_child_at_index(currentList, contentsIndex);
	dominant = clutter_actor_get_child_at_index(currentChild, DOMINANT_INDEX);
	overRay = clutter_actor_get_child_at_index(dominant, OVERRAY_INDEX);
	
	map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(currentChild);
	if (it != itemMap.end())
	{
		it->second->dominantColor = dominantColor;
	}
	
	clutter_actor_set_background_color(dominant, dominantColor.toClutterColor());
	
	if(HIGH_CONTRAST_FLAG){
		clutter_actor_set_opacity(overRay, OPACITY_100);
	}else{
		clutter_actor_set_opacity(overRay, OPACITY_8);
	}
}

void FirstScreenListWidget::setOnBackgroundClickListener(ScriptFunction callback)
{
	this->onBackgroundClickListener = callback;
}

void FirstScreenListWidget::setOnMoveFocuseListener(ScriptFunction callback)
{
	this->onMoveFocuseListener = callback;
}

void FirstScreenListWidget::setOnScrollLeftEndListener(ScriptFunction callback)
{
	this->onScrollLeftEndListener = callback;
}

void FirstScreenListWidget::setOnScrollRightEndListener(ScriptFunction callback)
{
	this->onScrollRightEndListener = callback;
}


void FirstScreenListWidget::setContextMenuFeedbackListener(ScriptFunction callback)
{
	this->onContextMenuFeedbackListener = callback;
}

void FirstScreenListWidget::setContextMenuFocusListener(ScriptFunction callback)
{
	this->onContextMenuFocusListener = callback;
}

void FirstScreenListWidget::setContextMenuUnfocusListener(ScriptFunction callback)
{
	this->onContextMenuUnfocusListener = callback;
}

FirstScreenCategory* FirstScreenListWidget::findCategory(std::string id)
{
	map<std::string, FirstScreenCategory*>::iterator it = categoryTagMap.find(id);
	if (it != categoryTagMap.end())
	{
		return it->second;
	}

	return NULL;
}

FirstScreenContents* FirstScreenListWidget::findContents(std::string id)
{
	map<std::string, FirstScreenContents*>::iterator it = contentsTagMap.find(id);
	if (it != contentsTagMap.end())
	{
		return it->second;
	}

	return NULL;
}

int FirstScreenListWidget::getLastMouseMovedTime()
{
	return (int)mouseMoved;
}

void FirstScreenListWidget:: setFirstState() 
{	
	EVENT_FLAG = false;

	if(exchangeControlStep == 1 && REDUCE_FLAG)
	{
		ClutterActor *temp1 = clutter_actor_get_child_at_index(bar, reduceIndex);
		ClutterActor *categoryWrapper = clutter_actor_get_child_at_index(temp1, CATEGORYWRAPPER_INDEX);
		ClutterActor *temp = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		reverseChildIndex(temp);
	}
	else if(exchangeControlStep == 2 && EXTEND_FLAG)
	{
		ClutterActor *temp1 = clutter_actor_get_child_at_index(bar, extendIndex);
		ClutterActor *categoryWrapper = clutter_actor_get_child_at_index(temp1, CATEGORYWRAPPER_INDEX);
		ClutterActor *temp = clutter_actor_get_child_at_index(temp1, CATEGORY_LISTWRAPPER_INDEX);
		reverseChildIndex(temp);
	}
	exchangeControlStep = 0;

	reduceIndex = 0;
	extendIndex = 1;

	//recoverCategory();
	//recoverDiff = 1.0;
	//recoverEffect();
	
	reduceCategory(reduceIndex);
	reduceDiff = 1.0;
	reduceEffect();
	
	extendCategory(extendIndex);
	extendDiff = 1.0;
	extendEffect();

	isKeyControl = true;
	if(NO_CONTENTS_FLAG)
	{
		setGlobalCursorPosition(SIDECATEGORY_GAP , SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		setGlobalCursorSize(FOCUS_CATEGORY_WIDTH, WIDGET_HEIGHT);
	}
	else
	{
		setGlobalCursorPosition(SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP, 
			SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT);
		setGlobalCursorSize(FOCUS_CONTENTS_WIDTH, WIDGET_HEIGHT);
	}
	clutter_actor_set_opacity(globalCursor, 255);

	fixOverlapShadow();

	isOpen[0] = false;
	isOpen[1] = true;

	cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;
	cur_x = goal_x = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + FOCUS_CONTENTS_WIDTH/2;
	goal_position = SIDECATEGORY_GAP;
	clutter_actor_set_x(bar, goal_position);
	
	REDUCE_FLAG = false;
	RECOVER_FLAG = false;
	EXCHANGE_FLAG = false;
	EXTEND_FLAG = false;
	SCALE_ITEM_FLAG = false;
	REDUCE_ITEM_FLAG = false;
	SCALE_CATEGORY_FLAG = false;
	REDUCE_CATEGORY_FLAG = false;
	
	CONTENT_LIVE_FLAG = false;
	move_rect();

	STOP_FLAG = false;
	EVENT_FLAG = true;
}

void FirstScreenListWidget:: returnAnimation() 
{
	extendAnimation();
}

/*
rotateWgt_Y_axis[shuhao.yan]
rotate the actor by the Y axis(based on the value of REVERSE_OSD)
*/
void FirstScreenListWidget::rotateWgt_Y_axis(ClutterActor* actor)
{
	if (REVERSE_OSD)
	{
		clutter_actor_set_rotation_angle(actor, CLUTTER_Y_AXIS, 180);
	}
	else
	{
		clutter_actor_set_rotation_angle(actor, CLUTTER_Y_AXIS, 0);
	}
}

/*
reverseOSD[shuhao.yan]
reverse the FirstScreenList Widget
Param: bool reverseFlag
true to reverse List
false to recover the original layout
*/
void FirstScreenListWidget::reverseOSD(bool reverseFlag)
{
	//avoid crash if reverse during animation
	if(exchangeControlStep >= 1)
	{
		return;
	}

	// set the reverse OSD Flag and rotate the root Scene[shuhao.yan]
	if (false == reverseFlag)
	{
		if (!REVERSE_OSD)
		{
			return;
		}
		SCENEROOT->setRotation(Vector3(0, 0, 0));
		REVERSE_OSD = false;
	}
	else
	{
		if (REVERSE_OSD)
		{
			return;
		}
		SCENEROOT->setRotation(Vector3(0, 180, 0));
		REVERSE_OSD = true;
	}

	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *categoryTitle = NULL;
	
	std::string childName;
	int contentsCounts = 0;

	// 2> rotate the category items
	int categoriesCounts = clutter_actor_get_n_children(bar);
	
	int i, j;
	if(FirstScreenADControl::GetInstance()->IsEnable())
	{
		FirstScreenADControl::GetInstance()->SetReverse();
		categoriesCounts = categoriesCounts - 1;
	}
	for( i = 0; i < categoriesCounts; i++ )
	{
		currentChild = clutter_actor_get_child_at_index(bar, i);

		childName = clutter_actor_get_name(currentChild);
		LOG_DEBUG(logger, "[shuhao.yan]FirstScreen The Category NAME::" << childName);

		categoryTitle = clutter_actor_get_child_at_index(currentChild, CATEGORYTITLE_INDEX);
		rotateWgt_Y_axis(categoryTitle);
		FirstScreenCategoryLiveControl::GetInstance()->SetReverse();

		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
		contentsCounts = clutter_actor_get_n_children(currentList);

		// 3> rotate each contents in the categories
		for( j = 0; j < contentsCounts; j++ )
		{
			currentChild = clutter_actor_get_child_at_index(currentList, j);
			rotateWgt_Y_axis(currentChild);
		}
		
		LOG_DEBUG(logger, "[shuhao.yan]The counts of the Contents is ::" << contentsCounts);
	}

}

/*
Enlarge the Category Title and Contents Title[ysh]
*/
void FirstScreenListWidget::enlarge(std::string categoryFont, std::string contentsFont)
{
	//avoid crash if reverse during animation
	if(exchangeControlStep >= 1)
	{
		return;
	}
	
	ClutterActor *currentChild  = NULL;
	ClutterActor *categoryTitle = NULL;
	ClutterActor *currentList   = NULL;
	ClutterActor *titleParent   = NULL;
	ClutterActor *dominant      = NULL;

	ClutterActor *normaltitle = NULL;
	ClutterActor *focustitle = NULL;
	ClutterActor *temp = NULL;
	ClutterActor *temp2 = NULL;
	
	int contentsCounts = 0;
	int categoriesCounts = clutter_actor_get_n_children(bar);
	
	int i, j;
	if(FirstScreenADControl::GetInstance()->IsEnable())
	{
		FirstScreenADControl::GetInstance()->SetReverse();
		categoriesCounts = categoriesCounts - 1;
	}
	for( i = 0; i < categoriesCounts; i++ )
	{
		currentChild = clutter_actor_get_child_at_index(bar, i);
		categoryTitle = clutter_actor_get_child_at_index(currentChild, CATEGORYTITLE_INDEX);
		temp = clutter_actor_get_child_at_index(categoryTitle, 0);
		clutter_text_set_font_name(CLUTTER_TEXT(temp), categoryFont.c_str());

		if(i==0){
			//position
			/*
			gfloat pixelWidth = clutter_actor_get_width(categoryTitle);
			gfloat pixelHeight = clutter_actor_get_height(categoryTitle);
			clutter_actor_set_x(categoryTitle, (NORMAL_CATEGORY_WIDTH-pixelWidth)/2);
			clutter_actor_set_y(categoryTitle, (CATEGORY_COLOR_HEIGHT-pixelHeight)/2);
			*/
		}
		else
			clutter_actor_set_position(categoryTitle, CATEGORY_TITLE_X, - (clutter_actor_get_height(categoryTitle) + CATEGORY_TITLE_Y));

		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
		contentsCounts = clutter_actor_get_n_children(currentList);

		STOP_FLAG = true;
		for( j = 0; j < contentsCounts; j++ )
		{
			currentChild = clutter_actor_get_child_at_index(currentList, j);
			titleParent  = clutter_actor_get_child_at_index(currentChild, CATEGORYTITLE_INDEX);

			
			normaltitle = clutter_actor_get_child_at_index(titleParent, NORMALTITLE_INDEX);
			TextScroll* normalInc = TextScroll::findNormalInc(normaltitle);
			normalInc->setTextFont(contentsFont);
			//temp = clutter_actor_get_child_at_index(normaltitle, 0);
			//clutter_text_set_font_name(CLUTTER_TEXT(temp), contentsFont.c_str());

			//focustitle = clutter_actor_get_child_at_index(titleParent, FOCUSTITLE_INDEX);
			//TextScroll* focusInc = TextScroll::findFocusInc(focustitle);
			//focustitle->setTextFont(contentsFont);
			//temp2 = clutter_actor_get_child_at_index(focustitle, 0);
			//clutter_text_set_font_name(CLUTTER_TEXT(temp2), contentsFont.c_str());
		}
		STOP_FLAG = false;
		
	}

}

/*
HighContrast for the accessbility feature[ysh]
1> Border need to more wider
2> Normal Title need to more highlight and its background need to more darker
*/
void FirstScreenListWidget::highContrast(bool highContrastFlag)
{
	//avoid crash if set high during animation
	if(exchangeControlStep >= 1)
	{
		return;
	}

	if (highContrastFlag)
	{
		HIGH_CONTRAST_FLAG = true;
	}
	else
	{
		HIGH_CONTRAST_FLAG = false;
	}
	ClutterColor overRayColor1 = {13, 13, 13, 255};
	ClutterColor overRayColor2 = {37, 37, 37, 255};
	
	ClutterActor *currentChild    = NULL;
	ClutterActor *categoryWrapper = NULL;
	ClutterActor *currentList     = NULL;
	ClutterActor *dominant        = NULL;
	ClutterActor *overRay         = NULL;

	ClutterActor *titleParent     = NULL;
	ClutterActor *normaltitle     = NULL;
	ClutterActor *temp = NULL;

	FirstScreenContents* ctr = NULL;

	int contentsCounts = 0;
	int categoriesCounts = clutter_actor_get_n_children(bar);
	int i, j;

	if(FirstScreenADControl::GetInstance()->IsEnable())
	{
		categoriesCounts = categoriesCounts -1;
	}
	for( i = 0; i < categoriesCounts; i++ )
	{
		currentChild = clutter_actor_get_child_at_index(bar, i);
		categoryWrapper = clutter_actor_get_child_at_index(currentChild, CATEGORYWRAPPER_INDEX);
		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
		contentsCounts = clutter_actor_get_n_children(currentList);
		
		for( j = 0; j < contentsCounts; j++ )
		{
			currentChild = clutter_actor_get_child_at_index(currentList, j);
			dominant = clutter_actor_get_child_at_index(currentChild, 0);
			overRay  = clutter_actor_get_child_at_index(dominant, 2);

			titleParent = clutter_actor_get_child_at_index(currentChild, 1);
			normaltitle = clutter_actor_get_child_at_index(titleParent, 0);
			//temp = clutter_actor_get_child_at_index(normaltitle, 0);
			
			if (highContrastFlag)
			{
				clutter_actor_set_opacity(dominant, OPACITY_100); // need to check with the requirement again
				clutter_actor_set_opacity(overRay, OPACITY_100);
				if (j % 2 == 0)
				{
					clutter_actor_set_background_color(overRay, &overRayColor1);
				}
				else
				{
					clutter_actor_set_background_color(overRay, &overRayColor2);
				}
				
				clutter_actor_set_opacity(normaltitle, OPACITY_100);

				clutter_text_set_color(CLUTTER_TEXT(normaltitle), &whiteColor);
				CONTENT_NORMAL_TITLE_OPACITY = OPACITY_100;
			}
			else
			{
				map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(currentChild);
				if (it != itemMap.end())
				{
					ctr = it->second;
					clutter_text_set_color(CLUTTER_TEXT(normaltitle), ctr->normalTitleColor.toClutterColor());
				}
			
				clutter_actor_set_opacity(dominant, OPACITY_100);
				clutter_actor_set_opacity(overRay, OPACITY_8);
				//clutter_actor_set_background_color(overRay, &overRayColor);
				clutter_actor_set_opacity(normaltitle, OPACITY_90);
				CONTENT_NORMAL_TITLE_OPACITY = OPACITY_90;
			}
		}
	}
		
}

void FirstScreenListWidget::removeProgressAndDim(std::string categoryType, int contentsIndex)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDim = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);	
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
	currentDim = clutter_actor_get_child_at_index(currentList, contentsIndex);

	int childrenCounts = clutter_actor_get_n_children(currentDim);
	if (childrenCounts == CONTENT_DIM_INDEX + 1)
	{
		currentDim = clutter_actor_get_child_at_index(currentDim, CONTENT_DIM_INDEX);
		ProgressController::eraseProgressController(currentDim);
	}


}

void FirstScreenListWidget::setKeyPrevent(bool keyPreventFlag)
{
	if (keyPreventFlag)
	{
		KEY_PREVENT_FLAG = true;
	}
	else
	{
		KEY_PREVENT_FLAG = false;
	}
}


void FirstScreenListWidget::setNomalTextColor(std::string categoryType, int contentsIndex, Color textColor)
{
	ClutterActor * currentChild = NULL;
	ClutterActor * currentList = NULL;
	ClutterActor * currentDominant = NULL;
	
	ClutterActor * titleParent     = NULL;
	ClutterActor * normaltitle     = NULL;

	FirstScreenContents* ctr = NULL;
	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		return;
	}
	else if(clutter_actor_get_n_children(bar) == 1)
	{
		currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		childName = clutter_actor_get_name(currentChild);
		
		if(categoryType.compare(childName) != 0)
		{	
			return;
		}

		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
		currentChild = clutter_actor_get_child_at_index(currentList, contentsIndex);

		titleParent = clutter_actor_get_child_at_index(currentChild, CATEGORYTITLE_INDEX);
		normaltitle = clutter_actor_get_child_at_index(titleParent, NORMALTITLE_INDEX);

		if (clutter_actor_get_n_children(normaltitle) == 2)
		{
			// To get the TextActor from the layoutWidget
			normaltitle = clutter_actor_get_child_at_index(normaltitle, 1);
		}
		
		map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(currentChild);
		if (it != itemMap.end())
		{
			ctr = it->second;
			ctr->normalTitleColor = textColor;
		}

		if (HIGH_CONTRAST_FLAG)
		{
			clutter_actor_set_opacity(normaltitle, OPACITY_100);	
			clutter_text_set_color(CLUTTER_TEXT(normaltitle), &whiteColor);
		}
		else
		{
			clutter_actor_set_opacity(normaltitle, OPACITY_90);
			if (ctr != NULL)
			{
				clutter_text_set_color(CLUTTER_TEXT(normaltitle), ctr->normalTitleColor.toClutterColor());
			}
		}

	}
	else
	{
		currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		childName = clutter_actor_get_name(currentChild);
		
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);
			childName = clutter_actor_get_name(currentChild);
			
			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
		
		currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
		currentChild = clutter_actor_get_child_at_index(currentList, contentsIndex);

		titleParent = clutter_actor_get_child_at_index(currentChild, TITLEPARENT_INDEX);
		normaltitle = clutter_actor_get_child_at_index(titleParent, NORMALTITLE_INDEX);

		if (clutter_actor_get_n_children(normaltitle) == 2)
		{
			// To get the TextActor from the layoutWidget
			normaltitle = clutter_actor_get_child_at_index(normaltitle, 1);
		}
		
		map<ClutterActor*, FirstScreenContents*>::iterator it = itemMap.find(currentChild);
		if (it != itemMap.end())
		{
			ctr = it->second;
			ctr->normalTitleColor = textColor;
		}

		if (HIGH_CONTRAST_FLAG)
		{
			clutter_actor_set_opacity(normaltitle, OPACITY_100);
			clutter_text_set_color(CLUTTER_TEXT(normaltitle), &whiteColor);
		}
		else
		{
			clutter_actor_set_opacity(normaltitle, OPACITY_90);
			if (ctr != NULL)
			{
				clutter_text_set_color(CLUTTER_TEXT(normaltitle), ctr->normalTitleColor.toClutterColor());
			}
			
		}
	}
	
}

//begin junhui.wang
void FirstScreenListWidget::changeControler()
{
	if(!isKeyControl && EVENT_FLAG && !REDUCE_ITEM_FLAG && !KEY_SELECT 
					&& !ON_TRANSITION && !STOP_FLAG  && !MOVE_TO_END 
					&& !MOVE_TO_BEGIN && !SCALE_LEFT && !SCALE_RIGHT)
	{
		EVENT_FLAG = false;
		int tAllCategoryCount = clutter_actor_get_n_children(bar);
		ClutterActor *barTemp = NULL;
		gfloat center = 0;
		gfloat inputPosition;
		gfloat diff;
		gfloat move_x = cur_x - clutter_actor_get_x(bar);
		cal_mouse_over();
		foveaStatePre = foveaState;//liang.wu
		if(currentCategory == 1 || (currentCategory == 0 && tAllCategoryCount ==1) || scaleItemInLastSpace)
		{
			isKeyControl = true;
			LOG_FATAL(logger,"changeControler currentCategory : " << currentCategory
											    << " foveaState : " << foveaState
												<< " currentIndex : " << currentIndex
												<< " currentContents : " << currentContents
												<< " cur_x : " << cur_x
												<< " bar_x : " << clutter_actor_get_x(bar)
												<< " move_x : " << move_x
												);
			if(foveaState == IN_CONTENTS)
			{
				if (preTextInc != NULL)
				{
					preTextInc->scrollStop();
					preTextInc = NULL;
				}
				startFocusTitleScroll(currentContents);

				// add the timeout to check the contextMenu popup 
				timeID++;
				ContextMenu::setTimeout(timeID);
			
				barTemp = clutter_actor_get_child_at_index(bar, currentCategory);
				//modify by junhui.wang
				ClutterActor * contentWrapper = clutter_actor_get_child_at_index(barTemp, CATEGORY_LISTWRAPPER_INDEX);
				ClutterActor * firstCategory = clutter_actor_get_child_at_index(bar, reduceIndex);
				ClutterActor * secondCategory = clutter_actor_get_child_at_index(bar, extendIndex);
				gfloat leftLimitX = clutter_actor_get_x(firstCategory) + clutter_actor_get_width(firstCategory) + CATEGORY_GAP;
				int i;
				for(i = currentContents; i < clutter_actor_get_n_children(contentWrapper); i++){
					ClutterActor * tmpChild = clutter_actor_get_child_at_index(contentWrapper,i);
					if((clutter_actor_get_x(barTemp)+clutter_actor_get_x(tmpChild)) > leftLimitX){
						if(currentContents != i){
							currentContents = i;
							currentIndex = i+1;
							cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + currentContents*NORMAL_CONTENTS_WIDTH + FOCUS_CONTENTS_WIDTH/2;
							move_x = cur_x - clutter_actor_get_x(bar);
						}
						break;
					}
				}
				if(i == clutter_actor_get_n_children(contentWrapper)){
					currentContents = clutter_actor_get_n_children(contentWrapper) - 1;
					currentIndex = clutter_actor_get_n_children(contentWrapper);
					cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + currentContents*NORMAL_CONTENTS_WIDTH + FOCUS_CONTENTS_WIDTH/2;
					move_x = cur_x - clutter_actor_get_x(bar);
				}

				//check the rightlimit
				for(i = currentContents; i >= 0 ; i--){
					ClutterActor * tmpChild = clutter_actor_get_child_at_index(contentWrapper,i);
					gfloat rightItemEndX = clutter_actor_get_x(bar) + clutter_actor_get_x(secondCategory) + i*NORMAL_CONTENTS_WIDTH + FOCUS_CONTENTS_WIDTH;
					if(rightItemEndX < SCENE_WIDTH){
						if(currentContents != i){
							currentContents = i;
							currentIndex = i+1;
							cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + currentContents*NORMAL_CONTENTS_WIDTH + FOCUS_CONTENTS_WIDTH/2;
							move_x = cur_x - clutter_actor_get_x(bar);
						}
						break;
					}
				}

				
				center = clutter_actor_get_x(barTemp) + FOCUS_CONTENTS_WIDTH/2 + NORMAL_CONTENTS_WIDTH*(currentIndex-1);		
				inputPosition = abs(move_x - center) / NORMAL_CONTENTS_WIDTH;
				diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);
				if(currentIndex ==  currentContents){
					scaleItemDesDiff = 1.0f;
				}else{
					scaleItemDesDiff = 0.0f;
				}
				scaleItemCurDiff = diff;
				scaleItemFeatureOpen = false;
			}
			else if(foveaState == FEATURED_OPEN)
			{
				toNomralCategory(0,0);
				barTemp = clutter_actor_get_child_at_index(bar, reduceIndex);
				center = FOCUS_CATEGORY_WIDTH/2;
				gfloat range = NORMAL_CATEGORY_WIDTH - FOCUS_CATEGORY_WIDTH/2 + FOCUS_CONTENTS_WIDTH/2 + SIDECATEGORY_GAP; 	
				inputPosition = abs(move_x - center) / range;
				diff = bezier(inputPosition, 1.0f, hFovea[0], hFovea[1], hFovea[2], hFovea[3]);
				scaleItemDesDiff = 1.0f;
				scaleItemCurDiff = diff;
				scaleItemFeatureOpen = true;
				currentContents = 0;
				currentIndex = 0;
			}
			else if(scaleItemInLastSpace)
			{
				barTemp = clutter_actor_get_child_at_index(bar, extendIndex);
				barTemp = clutter_actor_get_child_at_index(barTemp,CATEGORY_LISTWRAPPER_INDEX);
				scaleItemFeatureOpen = false;
				currentIndex = clutter_actor_get_n_children(barTemp) - 1;
				currentContents = clutter_actor_get_n_children(barTemp) - 1;
				scaleItemDesDiff = 1.0f;
				scaleItemCurDiff = 1.0f;
			}
			else
			{
				EVENT_FLAG = true;
				return;
			}
			scaleItemAllOriginWidth = NORMAL_CONTENTS_WIDTH - (NORMAL_CONTENTS_WIDTH - FOCUS_CONTENTS_WIDTH)*verticalDiff;
			scaleItemLeftTransWidth = NORMAL_CONTENTS_WIDTH;
			scaleItemRightTransWidth = NORMAL_CONTENTS_WIDTH;
			scaleItemCurVerticalDiff = 0;
			scaleItemDesVerticalDiff = 1.0;
			ScaleContentItem(currentIndex);
		}
		else
		{	
			ClutterActor * wang = clutter_actor_get_child_at_index(bar, extendIndex);
			wang = clutter_actor_get_child_at_index(wang, CATEGORY_LISTWRAPPER_INDEX);
			int count = clutter_actor_get_n_children(wang);
			for(int i = 0; i < count; i++)
			{
				toNormalContents(1, i, 0);
			}
			
			//barChild
			ClutterActor * temp1 = clutter_actor_get_child_at_index(bar, currentCategory);
			clutter_actor_set_x(temp1, 0);
			clutter_actor_set_width(temp1,FOCUS_CATEGORY_WIDTH);

			//categoryTitle
			ClutterActor * temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYTITLE_INDEX);
			clutter_actor_set_opacity(temp2, OPACITY_100);

			//categoryWrapper
			temp2 = clutter_actor_get_child_at_index(temp1, CATEGORYWRAPPER_INDEX);
			clutter_actor_set_width(temp2, FOCUS_CATEGORY_WIDTH);

			//category live
			FirstScreenCategoryLiveControl::GetInstance()->SetOpacity(temp2, OPACITY_100);

			//reset the cur pos
			cur_y = SCENE_HEIGHT - BOTTOM_HEIGHT - 100 * HD_PROPORTION;
			goal_position = SIDECATEGORY_GAP;
			clutter_actor_set_x(bar, goal_position);
			cur_x = goal_x = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH/2;
			
			isKeyControl = true;
			
			ScaleCategoryCursor();
		}
	}
}

void FirstScreenListWidget::setDim(std::string categoryType, int contentsIndex, bool flag)
{
	ClutterActor *currentChild = NULL;
	ClutterActor *currentList = NULL;
	ClutterActor *currentDim = NULL;

	std::string childName;

	if(clutter_actor_get_n_children(bar) == 0)
	{
		//printf("There is no category!!!\n");
		return;
	}

	currentChild = clutter_actor_get_child_at_index(bar, reduceIndex);
		
	childName = clutter_actor_get_name(currentChild);

	if(clutter_actor_get_n_children(bar) == 1)
	{
		if(categoryType.compare(childName) != 0)
		{
			//printf("There is no such category!!! Check id!!!\n");
			return;
		}
	}
	else
	{
		if(categoryType.compare(childName) != 0)
		{
			currentChild = clutter_actor_get_child_at_index(bar, extendIndex);

			childName = clutter_actor_get_name(currentChild);

			if(categoryType.compare(childName) != 0)
			{
				return;
			}			
		}
	}

	currentList = clutter_actor_get_child_at_index(currentChild, CATEGORY_LISTWRAPPER_INDEX);
	currentDim = clutter_actor_get_child_at_index(currentList, contentsIndex);

	int childrenCounts = clutter_actor_get_n_children(currentDim);
	if ( childrenCounts == CONTENT_DIM_INDEX)
	{
		ProgressController* pCtr = new ProgressController(currentDim);
		ClutterActor* pActor = pCtr->returnProgressRootActor();
		ProgressController::insertProgressController(pActor, pCtr);
		pCtr->setDim(flag);
	}

	if ( childrenCounts == CONTENT_DIM_INDEX + 1)
	{
		currentDim = clutter_actor_get_child_at_index(currentDim, CONTENT_DIM_INDEX);
		ProgressController::updateDim(currentDim, flag);
	}

#if 0
	currentDim = clutter_actor_get_child_at_index(currentDim, CONTENT_DIM_INDEX);

	if(flag){
		clutter_actor_set_opacity(currentDim,OPACITY_60);
	}else{
		clutter_actor_set_opacity(currentDim,0);
	}	
#endif 
}

//end junhui.wang

void FirstScreenListWidget::scaleLeft()
{
    ::scaleLeft();
}

void FirstScreenListWidget::recoverLeft()
{
    ::recoverLeft();
}

void FirstScreenListWidget::scaleRight()
{
    ::scaleRight();
}

void FirstScreenListWidget::recoverRight()
{
    ::recoverRight();
}


FirstScreenCategoryLiveControl* FirstScreenCategoryLiveControl::m_Instance = NULL;

FirstScreenCategoryLiveControl* FirstScreenCategoryLiveControl::GetInstance(void)
{
	if(m_Instance == NULL)
	{
		m_Instance = new FirstScreenCategoryLiveControl();
	}

	return m_Instance;
}

void FirstScreenCategoryLiveControl::DestroyInstance(void)
{
	if(m_Instance)
	{
		delete m_Instance;
	}

	m_Instance = NULL;
}

FirstScreenCategoryLiveControl::FirstScreenCategoryLiveControl()
{
	m_nHistoryIndex = 0;
	m_bFeaturedLiveEnable = false;
	m_bFeaturedLiveEnableReal = false;
	for(int i = 0; i < 4; i++)
	{
		m_pFeaturedLive[i] = NULL;
		m_pHistoryLive[i] = NULL;
		m_bHistoryLoad[i] = false;
	}
	for(int i = 0; i < 16; i++)
	{
		m_pFeaturedLivePost[i] = NULL;
		m_bFeaturedLoad[i] = false;
	}
}

FirstScreenCategoryLiveControl::~FirstScreenCategoryLiveControl()
{
	
}

void FirstScreenCategoryLiveControl::SetType(ClutterActor* parent)
{
	if(parent == m_FeaturedParent)
	{
		m_eType = FEATURED_LIVE;
	}
	else if(parent == m_HistoryParent)
	{
		m_eType = HISTORY_LIVE;
	}
}

void FirstScreenCategoryLiveControl::EnableFeaturedLive(bool set)
{
	m_bFeaturedLiveEnable = set;
}

void FirstScreenCategoryLiveControl::EnableFeaturedLiveReal(bool set)
{
	m_bFeaturedLiveEnableReal = set;
}

void FirstScreenCategoryLiveControl::SetOpacity(ClutterActor* parent, gfloat opacity)
{
	if(parent == m_FeaturedParent)
	{
		clutter_actor_set_opacity(m_pFeaturedLive[LIVEPARENT1_INDEX], opacity);
		clutter_actor_set_opacity(m_pFeaturedLive[LIVEPARENT2_INDEX], opacity);
		clutter_actor_set_opacity(m_pFeaturedLive[LIVEPARENT3_INDEX], opacity);
		clutter_actor_set_opacity(m_pFeaturedLive[LIVEPARENT4_INDEX], opacity);
	}
	else if(parent == m_HistoryParent)
	{
		if(m_pHistoryLive[LIVEPARENT1_INDEX])clutter_actor_set_opacity(m_pHistoryLive[LIVEPARENT1_INDEX], opacity);
		if(m_pHistoryLive[LIVEPARENT2_INDEX])clutter_actor_set_opacity(m_pHistoryLive[LIVEPARENT2_INDEX], opacity);
		if(m_pHistoryLive[LIVEPARENT3_INDEX])clutter_actor_set_opacity(m_pHistoryLive[LIVEPARENT3_INDEX], opacity);
		if(m_pHistoryLive[LIVEPARENT4_INDEX])clutter_actor_set_opacity(m_pHistoryLive[LIVEPARENT4_INDEX], opacity);
	}
}

void FirstScreenCategoryLiveControl::SetScale(ClutterActor* parent, gfloat scaleX, gfloat scaleY)
{
	if(parent == m_FeaturedParent)
	{
#if 1
		clutter_actor_set_scale(m_pFeaturedLive[LIVEPARENT1_INDEX], scaleX, scaleY);
		clutter_actor_set_scale(m_pFeaturedLive[LIVEPARENT2_INDEX], scaleX, scaleY);
		clutter_actor_set_scale(m_pFeaturedLive[LIVEPARENT3_INDEX], scaleX, scaleY);
		clutter_actor_set_scale(m_pFeaturedLive[LIVEPARENT4_INDEX], scaleX, scaleY);
		
		clutter_actor_set_x(m_pFeaturedLive[LIVEPARENT2_INDEX], NORMAL_CATEGORY_WIDTH * scaleX);
		clutter_actor_set_x(m_pFeaturedLive[LIVEPARENT4_INDEX], NORMAL_CATEGORY_WIDTH * scaleX);
#endif
	}
	else if(parent == m_HistoryParent)
	{
#if 1
		if(m_pHistoryLive[LIVEPARENT1_INDEX])clutter_actor_set_scale(m_pHistoryLive[LIVEPARENT1_INDEX], scaleX, scaleY);
		if(m_pHistoryLive[LIVEPARENT2_INDEX])clutter_actor_set_scale(m_pHistoryLive[LIVEPARENT2_INDEX], scaleX, scaleY);
		if(m_pHistoryLive[LIVEPARENT3_INDEX])clutter_actor_set_scale(m_pHistoryLive[LIVEPARENT3_INDEX], scaleX, scaleY);
		if(m_pHistoryLive[LIVEPARENT4_INDEX])clutter_actor_set_scale(m_pHistoryLive[LIVEPARENT4_INDEX], scaleX, scaleY);

		if(m_pHistoryLive[LIVEPARENT2_INDEX])clutter_actor_set_x(m_pHistoryLive[LIVEPARENT2_INDEX], NORMAL_CATEGORY_WIDTH/2 * scaleX);
		if(m_pHistoryLive[LIVEPARENT4_INDEX])clutter_actor_set_x(m_pHistoryLive[LIVEPARENT4_INDEX], NORMAL_CATEGORY_WIDTH/2 * scaleX);
#endif
	}
}

void FirstScreenCategoryLiveControl::SetReverse(void)
{
	ClutterActor* temp = NULL;
	
	if(m_FeaturedParent)
	{
		if(REVERSE_OSD)
		{
			for(int i = 0; i < 4; i++)
			{
				if(clutter_actor_get_n_children(m_pFeaturedLive[i]) == 1)
				{
					temp = clutter_actor_get_child_at_index(m_pFeaturedLive[i], 0);
					clutter_actor_set_rotation_angle(temp, CLUTTER_Y_AXIS, 180);
				}
				else if(clutter_actor_get_n_children(m_pFeaturedLive[i]) == 2)
				{
					temp = clutter_actor_get_child_at_index(m_pFeaturedLive[i], 0);
					clutter_actor_set_rotation_angle(temp, CLUTTER_Y_AXIS, 180);
					temp = clutter_actor_get_child_at_index(m_pFeaturedLive[i], 1);
					clutter_actor_set_rotation_angle(temp, CLUTTER_Y_AXIS, 180);
				}
			}
		}
		else
		{
			for(int i = 0; i < 4; i++)
			{
				if(clutter_actor_get_n_children(m_pFeaturedLive[i]) == 1)
				{
					temp = clutter_actor_get_child_at_index(m_pFeaturedLive[i], 0);
					clutter_actor_set_rotation_angle(temp, CLUTTER_Y_AXIS, 0);
				}
				else if(clutter_actor_get_n_children(m_pFeaturedLive[i]) == 2)
				{
					temp = clutter_actor_get_child_at_index(m_pFeaturedLive[i], 0);
					clutter_actor_set_rotation_angle(temp, CLUTTER_Y_AXIS, 0);
					temp = clutter_actor_get_child_at_index(m_pFeaturedLive[i], 1);
					clutter_actor_set_rotation_angle(temp, CLUTTER_Y_AXIS, 0);
				}
			}
		}
	}
	if(m_HistoryParent)
	{
		if(REVERSE_OSD)
		{
			if(m_pHistoryLive[LIVEPARENT1_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT1_INDEX], CLUTTER_Y_AXIS, 180);
			if(m_pHistoryLive[LIVEPARENT2_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT2_INDEX], CLUTTER_Y_AXIS, 180);
			if(m_pHistoryLive[LIVEPARENT3_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT3_INDEX], CLUTTER_Y_AXIS, 180);
			if(m_pHistoryLive[LIVEPARENT4_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT4_INDEX], CLUTTER_Y_AXIS, 180);
		}
		else
		{
			if(m_pHistoryLive[LIVEPARENT1_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT1_INDEX], CLUTTER_Y_AXIS, 0);
			if(m_pHistoryLive[LIVEPARENT2_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT2_INDEX], CLUTTER_Y_AXIS, 0);
			if(m_pHistoryLive[LIVEPARENT3_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT3_INDEX], CLUTTER_Y_AXIS, 0);
			if(m_pHistoryLive[LIVEPARENT4_INDEX])clutter_actor_set_rotation_angle(m_pHistoryLive[LIVEPARENT4_INDEX], CLUTTER_Y_AXIS, 0);
		}
	}
}

void FirstScreenCategoryLiveControl::RefreshFrame(bool force)
{
	if(FEATURED_LIVE == m_eType)
	{
		if(NULL == m_FeaturedParent)
		{
			return;
		}

		if(force)
		{
			livetick = 0;
			clutter_actor_set_x(m_pFeaturedLive[0], 0);
			clutter_actor_set_x(m_pFeaturedLive[1], NORMAL_CATEGORY_WIDTH);
			clutter_actor_set_x(m_pFeaturedLive[2], 0);
			clutter_actor_set_x(m_pFeaturedLive[3], NORMAL_CATEGORY_WIDTH);
			return;
		}

		if(false == m_bFeaturedLiveEnable || false == m_bFeaturedLiveEnableReal)
		{
			return;
		}
		
		if(livetick <= (aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
		{
			liveDiff = bezier(livetick - aniTime[LIVE_TERM], aniTime[LIVE_EXCUTE], live[0], live[1], live[2], live[3]);

			clutter_actor_set_x(m_pFeaturedLive[0], -FOCUS_CATEGORY_WIDTH*liveDiff);
			clutter_actor_set_x(m_pFeaturedLive[1], FOCUS_CATEGORY_WIDTH*(1 - liveDiff));

			if(livetick >= (aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
			{
				clutter_actor_set_x(m_pFeaturedLive[0], FOCUS_CATEGORY_WIDTH);
				clutter_actor_set_x(m_pFeaturedLive[1], 0);
			}
		}
		else if(livetick <= 2*(aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
		{
			liveDiff = bezier(livetick - (2*aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]), aniTime[LIVE_EXCUTE], live[0], live[1], live[2], live[3]);

			clutter_actor_set_x(m_pFeaturedLive[2], -NORMAL_CATEGORY_WIDTH*liveDiff);
			clutter_actor_set_x(m_pFeaturedLive[3], NORMAL_CATEGORY_WIDTH*(1 - liveDiff));

			if(livetick >= 2*(aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
			{
				clutter_actor_set_x(m_pFeaturedLive[2], NORMAL_CATEGORY_WIDTH);
				clutter_actor_set_x(m_pFeaturedLive[3], 0);
			}
		}
		else if(livetick <= 3*(aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
		{
			liveDiff = bezier(livetick - (3*aniTime[LIVE_TERM] + 2*aniTime[LIVE_EXCUTE]), aniTime[LIVE_EXCUTE], live[0], live[1], live[2], live[3]);

			clutter_actor_set_x(m_pFeaturedLive[1], -NORMAL_CATEGORY_WIDTH*liveDiff);
			clutter_actor_set_x(m_pFeaturedLive[0], NORMAL_CATEGORY_WIDTH*(1 - liveDiff));

			if(livetick >= 3*(aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
			{
				clutter_actor_set_x(m_pFeaturedLive[0], 0);
				clutter_actor_set_x(m_pFeaturedLive[1], NORMAL_CATEGORY_WIDTH);
			}
		}
		else
		{
			liveDiff = bezier(livetick - (4*aniTime[LIVE_TERM] + 3*aniTime[LIVE_EXCUTE]), aniTime[LIVE_EXCUTE], live[0], live[1], live[2], live[3]);

			clutter_actor_set_x(m_pFeaturedLive[3], -NORMAL_CATEGORY_WIDTH*liveDiff);
			clutter_actor_set_x(m_pFeaturedLive[2], NORMAL_CATEGORY_WIDTH*(1 - liveDiff));

			if(livetick >= 4 * (aniTime[LIVE_TERM] + aniTime[LIVE_EXCUTE]))
			{
				clutter_actor_set_x(m_pFeaturedLive[2], 0);
				clutter_actor_set_x(m_pFeaturedLive[3], NORMAL_CATEGORY_WIDTH);
				livetick = 0;
			}
		}

		livetick++;
		//skipLiveTick = (gfloat)clutter_timeline_get_delta(timeline) / 16.f;
		//livetick += skipLiveTick;
	}
	else if(HISTORY_LIVE == m_eType)
	{
		//nothing
	}
}

//for history
void FirstScreenCategoryLiveControl::SetHistoryParent(ClutterActor* parent)
{
	if(NULL == parent)
	{
		return;
	}

	m_HistoryParent = parent;
	
#if 0
	ClutterColor zeroColor = {0, 0, 0, 0};

	//3 fix1
	ClutterActor* fix1 = clutter_actor_new();
	clutter_actor_set_size(fix1, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(fix1, 0, WIDGET_HEIGHT/2);
	clutter_actor_set_background_color(fix1, &zeroColor);
	clutter_actor_set_opacity(fix1, OPACITY_70);
	clutter_actor_set_pivot_point(fix1, 0.0, 0.0);

	//3 fix2
	ClutterActor* fix2 = clutter_actor_new();
	clutter_actor_set_size(fix2, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(fix2, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_background_color(fix2, &zeroColor);
	clutter_actor_set_opacity(fix2, OPACITY_70);
	clutter_actor_set_pivot_point(fix2, 0.0, 0.0);

	//3 fix3
	ClutterActor* fix3 = clutter_actor_new();
	clutter_actor_set_size(fix3, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(fix3, 0, 0);
	clutter_actor_set_background_color(fix3, &zeroColor);
	clutter_actor_set_opacity(fix3, OPACITY_70);
	clutter_actor_set_pivot_point(fix3, 0.0, 0.0);

	//3 fix4
	ClutterActor* fix4 = clutter_actor_new();
	clutter_actor_set_size(fix4, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(fix4, NORMAL_CATEGORY_WIDTH/2, 0);
	clutter_actor_set_background_color(fix4, &zeroColor);
	clutter_actor_set_opacity(fix4, OPACITY_70);
	clutter_actor_set_pivot_point(fix4, 0.0, 0.0);

	//3 set child
	clutter_actor_insert_child_at_index(m_HistoryParent, fix1, LIVEPARENT1_INDEX);
	clutter_actor_insert_child_at_index(m_HistoryParent, fix2, LIVEPARENT2_INDEX);
	clutter_actor_insert_child_at_index(m_HistoryParent, fix3, LIVEPARENT3_INDEX);
	clutter_actor_insert_child_at_index(m_HistoryParent, fix4, LIVEPARENT4_INDEX);

	m_pHistoryLive[LIVEPARENT1_INDEX] = fix1;
	m_pHistoryLive[LIVEPARENT2_INDEX] = fix2;
	m_pHistoryLive[LIVEPARENT3_INDEX] = fix3;
	m_pHistoryLive[LIVEPARENT4_INDEX] = fix4;
#endif
}

void FirstScreenCategoryLiveControl::AddHistoryLive(std::string url, int index, ClutterColor& color)
{
	if(NULL == m_HistoryParent || url.empty())
	{
		return;
	}
	
	if(index < -1 || index > 3)
	{
		return;
	}

	int itemIndex = index == -1 ? m_nHistoryIndex++ : index;
	if(m_nHistoryIndex > 3)
	{
		m_nHistoryIndex = 3;
	}
	
	if(NULL == m_pHistoryLive[itemIndex])
	{
		//clutter_actor_destroy(m_pHistoryLive[itemIndex]);
		//m_pHistoryLive[itemIndex] = NULL;
		m_pHistoryLive[itemIndex] = volt_actor_new();//clutter_actor_new();
		clutter_actor_add_child(m_HistoryParent, m_pHistoryLive[itemIndex]);
		
		switch(itemIndex)//adjust attribute when new added according to index
		{
			case LIVEPARENT1_INDEX:
			{
				//3 fix1
				ClutterActor* fix1 = m_pHistoryLive[itemIndex];
				clutter_actor_set_size(fix1, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
				clutter_actor_set_position(fix1, 0, WIDGET_HEIGHT/2);
				clutter_actor_set_background_color(fix1, &color);
				clutter_actor_set_opacity(fix1, OPACITY_70);
				clutter_actor_set_pivot_point(fix1, 0.5, 0.0);
				break;
			}
			case LIVEPARENT2_INDEX:
			{
				//3 fix2
				ClutterActor* fix2 = m_pHistoryLive[itemIndex];
				clutter_actor_set_size(fix2, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
				clutter_actor_set_position(fix2, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
				clutter_actor_set_background_color(fix2, &color);
				clutter_actor_set_opacity(fix2, OPACITY_70);
				clutter_actor_set_pivot_point(fix2, 0.5, 0.0);
				break;
			}
			case LIVEPARENT3_INDEX:
			{
				//3 fix3
				ClutterActor* fix3 = m_pHistoryLive[itemIndex];
				clutter_actor_set_size(fix3, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
				clutter_actor_set_position(fix3, 0, 0);
				clutter_actor_set_background_color(fix3, &color);
				clutter_actor_set_opacity(fix3, OPACITY_70);
				clutter_actor_set_pivot_point(fix3, 0.5, 0.0);
				break;
			}
			case LIVEPARENT4_INDEX:
			{
				//3 fix4
				ClutterActor* fix4 = m_pHistoryLive[itemIndex];
				clutter_actor_set_size(fix4, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
				clutter_actor_set_position(fix4, NORMAL_CATEGORY_WIDTH/2, 0);
				clutter_actor_set_background_color(fix4, &color);
				clutter_actor_set_opacity(fix4, OPACITY_70);
				clutter_actor_set_pivot_point(fix4, 0.5, 0.0);
				break;
			}
			default:
				break;
		}
		
		if(REVERSE_OSD)
		{
			clutter_actor_set_rotation_angle(m_pHistoryLive[itemIndex], CLUTTER_Y_AXIS, 180);
		}
	}

	//request url
	if(m_bHistoryLoad[itemIndex])
	{
		return;
	}
	m_bHistoryLoad[itemIndex] = true;
	LoadImage(url, itemIndex);
}

void FirstScreenCategoryLiveControl::RemoveHistoryLive(int index)
{
	if(index < -1 || index > 3)
	{
		return;
	}

	int itemIndex = index == -1 ? m_nHistoryIndex-- : index;
	if(m_nHistoryIndex < 0)
	{
		m_nHistoryIndex = 0;
	}

#if 1
	if(m_pHistoryLive[itemIndex])
	{
		clutter_actor_destroy(m_pHistoryLive[itemIndex]);
		m_pHistoryLive[itemIndex] = NULL;
	}
#else
	ClutterActor* currentFix = clutter_actor_get_child_at_index(m_HistoryParent, itemIndex);
	clutter_actor_set_content(currentFix, NULL);
#endif
}

//for featured
void FirstScreenCategoryLiveControl::SetFeaturedParent(ClutterActor* parent)
{
	if(NULL == parent)
	{
		return;
	}

	m_FeaturedParent = parent;
	ClutterColor zeroColor = {0, 0, 0, 0};
	
	//3 liveParent1
	ClutterActor* liveParent1 = clutter_actor_new();
	clutter_actor_set_size(liveParent1, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT/2);
	clutter_actor_set_position(liveParent1, 0, WIDGET_HEIGHT/2);
	clutter_actor_set_background_color(liveParent1, &zeroColor);
	clutter_actor_set_opacity(liveParent1, OPACITY_70);
	clutter_actor_set_pivot_point(liveParent1, 0.5, 0.0);
	
	//if (REVERSE_OSD) // To rotate the latest careated category Live One
	//{
	//	clutter_actor_set_rotation_angle(liveParent1, CLUTTER_Y_AXIS, 180);
	//}
#if 0
	//4 >post 1
	ClutterActor* post1 = clutter_actor_new();
	clutter_actor_set_size(post1, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post1, 0, 0);
	clutter_actor_add_child(liveParent1, post1);

	//4 >post 2
	ClutterActor* post2 = clutter_actor_new();
	clutter_actor_set_size(post2, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post2, NORMAL_CATEGORY_WIDTH/2, 0);
	clutter_actor_add_child(liveParent1, post2);
#endif
	//3 liveParent2
	ClutterActor* liveParent2 = clutter_actor_new();
	clutter_actor_set_size(liveParent2, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT/2);
	clutter_actor_set_position(liveParent2, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT/2);
	clutter_actor_set_background_color(liveParent2, &zeroColor);
	clutter_actor_set_opacity(liveParent2, OPACITY_70);
	clutter_actor_set_pivot_point(liveParent2, 0.5, 0.0);
	
	//if (REVERSE_OSD) // To rotate the latest careated category Live TWO
	//{
	//	clutter_actor_set_rotation_angle(liveParent2, CLUTTER_Y_AXIS, 180);
	//}
#if 0
	//4 >post3
	ClutterActor* post3 = clutter_actor_new();
	clutter_actor_set_size(post3, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post3, 0, 0);
	clutter_actor_add_child(liveParent2, post3);

	//4 >post4
	ClutterActor* post4 = clutter_actor_new();
	clutter_actor_set_size(post4, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post4, NORMAL_CATEGORY_WIDTH/2, 0);
	clutter_actor_add_child(liveParent2, post4);
#endif
	
	//3 liveParent3
	ClutterActor* liveParent3 = clutter_actor_new();
	clutter_actor_set_size(liveParent3, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT/2);
	clutter_actor_set_position(liveParent3, 0, 0);
	clutter_actor_set_background_color(liveParent3, &zeroColor);
	clutter_actor_set_opacity(liveParent3, OPACITY_70);
	clutter_actor_set_pivot_point(liveParent3, 0.5, 0.0);

	//if (REVERSE_OSD) // To rotate the latest careated category Live One
	//{
	//	clutter_actor_set_rotation_angle(liveParent3, CLUTTER_Y_AXIS, 180);
	//}
#if 0
	//4 >post5
	ClutterActor* post5 = clutter_actor_new();
	clutter_actor_set_size(post5, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post5, 0, 0);
	clutter_actor_add_child(liveParent3, post5);

	//4 >post6
	ClutterActor* post6 = clutter_actor_new();
	clutter_actor_set_size(post6, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post6, NORMAL_CATEGORY_WIDTH/2, 0);
	clutter_actor_add_child(liveParent3, post6);
#endif
	//3 liveParent4
	ClutterActor* liveParent4 = clutter_actor_new();
	clutter_actor_set_size(liveParent4, NORMAL_CATEGORY_WIDTH, WIDGET_HEIGHT/2);
	clutter_actor_set_position(liveParent4, NORMAL_CATEGORY_WIDTH, 0);
	clutter_actor_set_background_color(liveParent4, &zeroColor);
	clutter_actor_set_opacity(liveParent4, OPACITY_70);
	clutter_actor_set_pivot_point(liveParent4, 0.5, 0.0);

	//if (REVERSE_OSD) // To rotate the latest careated category Live TWO
	//{
	//	clutter_actor_set_rotation_angle(liveParent4, CLUTTER_Y_AXIS, 180);
	//}
#if 0
	//4 >post7
	ClutterActor* post7 = clutter_actor_new();
	clutter_actor_set_size(post7, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post7, 0, 0);
	clutter_actor_add_child(liveParent4, post7);

	//4 >post8
	ClutterActor* post8 = clutter_actor_new();
	clutter_actor_set_size(post8, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
	clutter_actor_set_position(post8, NORMAL_CATEGORY_WIDTH/2, 0);
	clutter_actor_add_child(liveParent4, post8);
#endif

	//3 set child
	clutter_actor_insert_child_at_index(m_FeaturedParent, liveParent1, LIVEPARENT1_INDEX);
	clutter_actor_insert_child_at_index(m_FeaturedParent, liveParent2, LIVEPARENT2_INDEX);
	clutter_actor_insert_child_at_index(m_FeaturedParent, liveParent3, LIVEPARENT3_INDEX);
	clutter_actor_insert_child_at_index(m_FeaturedParent, liveParent4, LIVEPARENT4_INDEX);

	m_pFeaturedLive[LIVEPARENT1_INDEX] = liveParent1;
	m_pFeaturedLive[LIVEPARENT2_INDEX] = liveParent2;
	m_pFeaturedLive[LIVEPARENT3_INDEX] = liveParent3;
	m_pFeaturedLive[LIVEPARENT4_INDEX] = liveParent4;
}

void FirstScreenCategoryLiveControl::AddFeaturedLive(std::string url, int liveIndex, int postIndex, ClutterColor& color)
{
	if(NULL == m_FeaturedParent || url.empty())
	{
		return;
	}
	
	if(liveIndex < 0 || liveIndex > 3 || postIndex < 0 || postIndex > 1)
	{
		return;
	}

	if(NULL == m_pFeaturedLive[liveIndex])
	{
		return;
	}

	int totalIndex = liveIndex * 2 + postIndex;
	if(NULL == m_pFeaturedLivePost[totalIndex])
	{
		//clutter_actor_destroy(m_pFeaturedLivePost[totalIndex]);
		//m_pFeaturedLivePost[totalIndex] = NULL;
		m_pFeaturedLivePost[totalIndex] = volt_actor_new();//clutter_actor_new();
		clutter_actor_add_child(m_pFeaturedLive[liveIndex], m_pFeaturedLivePost[totalIndex]);
	}

	if(POST1_INDEX == postIndex)
	{
		ClutterActor* post0 = m_pFeaturedLivePost[totalIndex];
		clutter_actor_set_size(post0, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
		clutter_actor_set_position(post0, 0, 0);
		clutter_actor_set_pivot_point(post0, 0.5, 0.0);
		clutter_actor_set_background_color(post0, &color);

		if(REVERSE_OSD)
		{
			clutter_actor_set_rotation_angle(post0, CLUTTER_Y_AXIS, 180);
		}
	}
	else if(POST2_INDEX == postIndex)
	{
		ClutterActor* post1 = m_pFeaturedLivePost[totalIndex];
		clutter_actor_set_size(post1, NORMAL_CATEGORY_WIDTH/2, WIDGET_HEIGHT/2);
		clutter_actor_set_position(post1, NORMAL_CATEGORY_WIDTH/2, 0);
		clutter_actor_set_pivot_point(post1, 0.5, 0.0);
		clutter_actor_set_background_color(post1, &color);

		if(REVERSE_OSD)
		{
			clutter_actor_set_rotation_angle(post1, CLUTTER_Y_AXIS, 180);
		}
	}

	//request url
	if(m_bFeaturedLoad[totalIndex])
	{
		return;
	}
	m_bFeaturedLoad[totalIndex] = true;
	LoadImage(url, totalIndex+100);
}

void FirstScreenCategoryLiveControl::RemoveFeaturedLive(int liveIndex, int postIndex)
{
	if(NULL == m_FeaturedParent)
	{
		return;
	}
	
	if(liveIndex < 0 || liveIndex > 3)
	{
		return;
	}

	if(NULL == m_pFeaturedLive[liveIndex])
	{
		return;
	}

	if(postIndex < 0 || postIndex > 1)
	{
		return;
	}

#if 1
	int totalIndex = liveIndex * 2 + postIndex;
	if(m_pFeaturedLivePost[totalIndex])
	{
		clutter_actor_destroy(m_pFeaturedLivePost[totalIndex]);
		m_pFeaturedLivePost[totalIndex] = NULL;
		m_bFeaturedLoad[totalIndex] = false;
	}
#else
	ClutterActor* currentPost = clutter_actor_get_child_at_index(m_FeaturedParent, liveIndex);
	currentPost = clutter_actor_get_child_at_index(currentPost, postIndex);
	clutter_actor_set_content(currentPost, NULL);
#endif
}

void FirstScreenCategoryLiveControl::LoadImage(std::string url, int id)
{
	ImageLoadedCallback callback = std::bind(FirstScreenCategoryLiveControl::onImageLoadedRouter, id, std::placeholders::_1, std::placeholders::_2);
    bool success = ResourceLoader::Instance().LoadImage(callback, url, true, COGL_TEXTURE_NO_ATLAS);
    if (!success)
    {
        callback(NULL, false);
    }
}

void FirstScreenCategoryLiveControl::onImageLoadedRouter(int recieverID, VoltImage* image, bool success)
{
	if(NULL == image || !success)
	{
		return;
	}

	FirstScreenCategoryLiveControl* classInstance = FirstScreenCategoryLiveControl::GetInstance();
	
	ClutterActor* actor = NULL;
	if(recieverID >= 100)
	{
		if(recieverID - 100 >= 0 &&  recieverID - 100 < 16)
		{
			actor = classInstance->m_pFeaturedLivePost[recieverID-100];
			if(false == classInstance->m_bFeaturedLoad[recieverID-100])
			{
				return;
			}
			classInstance->m_bFeaturedLoad[recieverID-100] = false;
		}
	}
	else
	{
		if(recieverID >= 0 && recieverID < 4)
		{
			actor = classInstance->m_pHistoryLive[recieverID];
			classInstance->m_bHistoryLoad[recieverID] = false;
		}
	}
	
	if(NULL == actor)
	{
		return;
	}

	clutter_actor_set_content(actor, CLUTTER_CONTENT(image));
	//clutter_actor_set_content_gravity(actor, ClutterContentGravity(ImageWidget::Fit));
}

FirstScreenADControl* FirstScreenADControl::m_Instance = NULL;

FirstScreenADControl* FirstScreenADControl::GetInstance(void)
{
	if(m_Instance == NULL)
	{
		m_Instance = new FirstScreenADControl();
	}

	return m_Instance;
}

void FirstScreenADControl::DestroyInstance(void)
{
	if(m_Instance)
	{
		delete m_Instance;
	}

	m_Instance = NULL;
}

FirstScreenADControl::FirstScreenADControl()
{
	m_bEnabel = false;
	m_bLoading = false;
	m_pAdContainer = NULL;
	m_pAdContent = NULL;
}

FirstScreenADControl::~FirstScreenADControl()
{
	if(m_pAdContainer)
	{
		clutter_actor_destroy(m_pAdContainer);
	}
}

void FirstScreenADControl::AddADContent(std::string url)
{
	if(NULL == bar || url.empty())	
	{
		return;
	}

	if(m_bLoading)
	{
		return;
	}

	if(NULL == m_pAdContainer)
	{
		m_pAdContainer = clutter_actor_new();
		clutter_actor_set_size(m_pAdContainer, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);	    
		clutter_actor_set_position(m_pAdContainer, NORMAL_CATEGORY_WIDTH + SIDECATEGORY_GAP, 0);
		clutter_actor_set_pivot_point(m_pAdContainer, 0.0, 0.5);
		clutter_actor_add_child(bar, m_pAdContainer);
		clutter_actor_set_child_at_index(bar, m_pAdContainer, adIndex);
	}

	if(NULL == m_pAdContent)
	{
		m_pAdContent = volt_actor_new();
		clutter_actor_set_size(m_pAdContent, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);	    
		clutter_actor_set_position(m_pAdContent, 0, 0);
		clutter_actor_set_pivot_point(m_pAdContent, 0.5, 0.5);
		clutter_actor_add_child(m_pAdContainer, m_pAdContent);
	}

	m_bLoading = true;
	m_bEnabel = true;
	LoadImage(url);

	//re-set global attributes
	switch((int)SCENE_WIDTH){
		case 1920:
		case 2520:
			CATEGORY_GAP =  SIDECATEGORY_GAP * 2 + Rounding(1920 * 0.090104, 1);
			break;
		case 1280:
		case 1680:
			CATEGORY_GAP =  SIDECATEGORY_GAP * 2 + Rounding(1280 * 0.090104, 1);
			break;
		default:
			break;
	}
}

void FirstScreenADControl::RemoveADContent(void)
{
	if(NULL == m_pAdContent)
	{
		return;
	}

	//clutter_actor_remove_child(bar, m_pAdContent); 
	//clutter_actor_destroy(m_pAdContent);
	clutter_actor_destroy(m_pAdContainer);

	//reset attributes
	m_bEnabel = false;
	m_bLoading = false;
	m_pAdContent = NULL;

	//recover global attributes
	CATEGORY_GAP =  SIDECATEGORY_GAP;
}

void FirstScreenADControl::SetClickCallback(ScriptFunction cb)
{
	if(cb.isFunction())
	{
		onClickCallback = cb;
	}
}

void FirstScreenADControl::InvokeClickCallback(gfloat x)
{
	if(onClickCallback.isFunction())
	{
		gfloat leftLimit = SIDECATEGORY_GAP + NORMAL_CATEGORY_WIDTH + preDiff * EXTENDGAP;
		gfloat rightLimit = leftLimit + NORMAL_CONTENTS_WIDTH;

		if (x > leftLimit && x < rightLimit)
		{
			ScriptArray args;
			onClickCallback.invoke(args);
		}	
	}
}

void FirstScreenADControl::SetEnterCallback(ScriptFunction cb)
{
	if(cb.isFunction())
	{
		onEnterCallback = cb;
	}
}

void FirstScreenADControl::InvokeEnterCallback(void)
{
	if(onEnterCallback.isFunction())
	{
		ScriptArray args;
		onEnterCallback.invoke(args);
	}
}

void FirstScreenADControl::SetX(gfloat x)
{
	if(NULL == m_pAdContent)
	{
		return;
	}
	
	clutter_actor_set_x(m_pAdContainer, x);
}

void FirstScreenADControl::SetWidth(gfloat w)
{
	if(NULL == m_pAdContent)
	{
		return;
	}
	
	clutter_actor_set_width(m_pAdContainer, w);
}

void FirstScreenADControl::SetOpacity(gfloat opacity)
{
	if(NULL == m_pAdContent)
	{
		return;
	}
	
	clutter_actor_set_opacity(m_pAdContainer, opacity);
}

void FirstScreenADControl::SetReverse(void)
{
	if(REVERSE_OSD)
	{
		clutter_actor_set_rotation_angle(m_pAdContent, CLUTTER_Y_AXIS, 180);
	}
	else
	{
		clutter_actor_set_rotation_angle(m_pAdContent, CLUTTER_Y_AXIS, 0);
	}
}

void FirstScreenADControl::LoadImage(std::string url)
{
	ImageLoadedCallback callback = std::bind(FirstScreenADControl::onImageLoadedRouter, std::placeholders::_1, std::placeholders::_2);
    bool success = ResourceLoader::Instance().LoadImage(callback, url, true, COGL_TEXTURE_NO_ATLAS);
    if (!success)
    {
        callback(NULL, false);
    }
}

void FirstScreenADControl::onImageLoadedRouter(VoltImage* image, bool success)
{
	if(NULL == image || !success)
	{
		return;
	}

	FirstScreenADControl* classInstance = FirstScreenADControl::GetInstance();
	if(false == classInstance->IsEnable())
	{
		return;
	}
	
	clutter_actor_set_content(classInstance->m_pAdContent, CLUTTER_CONTENT(image));
	//clutter_actor_set_content_gravity(actor, ClutterContentGravity(ImageWidget::Fit));

	classInstance->m_bLoading = false;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// begin shuhao.yan

ContextMenu& ContextMenu::Instance()
{
	static ContextMenu singleton;
	return singleton;
}

static gboolean riseContextMenuGlobal(gpointer data)
{
	if (!isKeyControl )
	{
		return FALSE;
	}
	int checkID = GPOINTER_TO_INT(data);
	
	if (timeID != checkID) 
	{
		return FALSE;
	}
	else
	{
		if (currentContents == EMPTY)
		{
			LOG_DEBUG(logger, "[shuhao.yan] The focus is not in the Contents");
			return FALSE;
		}

		if (!ContextMenu::checkContextMenuPopCondition())
		{
			LOG_DEBUG(logger, "[shuhao.yan] Now the condition is not correct");
			return FALSE;
		}
		
		ContextMenu::Instance().riseContextMenu(currentContents, false);
	}
	
	return FALSE;
}

void FirstScreenListWidget::setContextMenuFlag(bool set)
{
	CONTEXTMENU_ENABLE = set;
}

void ContextMenu::setTimeout(int id)
{
	if (!CONTEXTMENU_ENABLE)
	{
		return;
	}

	std::string tempName;
	tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, extendIndex));	
	if (compareStrChar(tempName, "featured"))
	{
		timeID++;
		return;
	}
	
	FOCUS_CONTEXTMENU = false;
	ContextMenu::Instance().fallContextMenu();
	clutter_threads_add_timeout (2000, riseContextMenuGlobal, GINT_TO_POINTER(id));
}

gboolean  ContextMenu::checkContextMenuPopCondition()
{
	std::string tempName;
	tempName = clutter_actor_get_name(clutter_actor_get_child_at_index(bar, extendIndex));	
	if (compareStrChar(tempName, "featured"))
	{
		timeID++;
		return FALSE;
	}
	ClutterActor* currentCategory =  clutter_actor_get_child_at_index(bar, extendIndex);
	ClutterActor* currentList = clutter_actor_get_child_at_index(currentCategory, CATEGORY_LISTWRAPPER_INDEX);

	int count = clutter_actor_get_n_children(currentList);
	if (currentContents == count - 1 || count == 0)
	{
		LOG_DEBUG(logger, "[shuhao.yan] The focus is in the end of the Recent cate");
		return FALSE;
	}

	return TRUE;
}

void ContextMenu::on_ContextMenu_button_press_event(gfloat mouse_x, gfloat mouse_y) 
{

	
}

void ContextMenu::on_ContextMenu_button_release_event(gfloat mouse_x, gfloat mouse_y) 
{	
	// get the root position
	gfloat rootX = clutter_actor_get_x(m_rootActor);
	gfloat rootY = clutter_actor_get_y(m_rootActor);
	gfloat rootWidth = clutter_actor_get_width(m_rootActor);
	gfloat rootHeight = clutter_actor_get_height(m_rootActor);


	if (mouse_x < rootX  || mouse_x > rootX  + rootWidth)
	{
		fallContextMenuBY_MOUSEMOVEOUT();
	}

	if ((mouse_x > rootX + rootWidth || mouse_x < rootX) || (mouse_y > rootY + rootHeight || mouse_y < rootY))
	{
		return;
	}

	if (!M_FOCUS_FLAG)
	{
		return;
	}
	gfloat posX = mouse_x - rootX;
	int focusIndex = 0;

	if (!M_MLS_DISABLE)
	{
		focusIndex = (int)(posX / m_item_space);
	}
	else
	{
		focusIndex = (int)((posX - m_nomls_beginX)/ m_item_space);
	}

	ContextMenu::Instance().enterOption();

	if (instance != NULL && instance->onContextMenuFeedbackListener.isFunction()) 
	{	
		// feedback this index to JS layer [shuhao.yan]
		ScriptArray arr;
		arr.set(0, focusIndex);
		instance->onContextMenuFeedbackListener.invoke(arr);
	}
	
}

void ContextMenu::on_ContextMenu_motion_event(gfloat mouse_x, gfloat mouse_y) 
{
	// get the root position
	gfloat rootX = clutter_actor_get_x(m_rootActor);
	gfloat rootY = clutter_actor_get_y(m_rootActor);
	gfloat rootWidth = clutter_actor_get_width(m_rootActor);
	gfloat rootHeight = clutter_actor_get_height(m_rootActor);


	if (mouse_x < rootX  || mouse_x > rootX  + rootWidth)
	{
		fallContextMenuBY_MOUSEMOVEOUT();
	}

	if ((mouse_x > rootX + rootWidth || mouse_x < rootX) || (mouse_y > rootY + rootHeight || mouse_y < rootY))
	{
		return;
	}

	if (!M_FOCUS_FLAG)
	{
		return;
	}

	gfloat posX = mouse_x - rootX;
	gfloat x_offset = 0;
	int focusIndex = 0;

	if (!M_MLS_DISABLE)
	{
		focusIndex = (int)(posX / m_item_space);
		m_focusIndex = focusIndex;
		x_offset = m_item_space * m_focusIndex;
		clutter_actor_set_x(m_selectorImg, x_offset);
	}
	else
	{
		focusIndex = (int)((posX - m_nomls_beginX)/ m_item_space);
		m_focusIndex = focusIndex;
		x_offset = m_nomls_beginX + m_item_space * m_focusIndex;
		clutter_actor_set_x(m_selectorImg, x_offset);
	}

}


ContextMenu::ContextMenu()
{
	m_rootActor = clutter_actor_new();
	
	m_removeImg = clutter_actor_new();
	m_favouriteImg = clutter_actor_new();
	m_multilinkImg = clutter_actor_new();
	
	m_arrowUPImg = clutter_actor_new();
	m_selectorImg = clutter_actor_new();

	m_mousearrowUPImg = clutter_actor_new();

	std::string rootPath = IMAGE_URL_PREFIX + "icon/";

	std::string removePng = rootPath + "fs_btn_ct_delete.png";
	std::string favouritePng = rootPath + "fs_btn_ct_favorites_2.png";
	std::string multilinkPng = rootPath + "fs_btn_ct_favorites_2.png";
	
	std::string bgPng = rootPath + "fs_btn_ct_bg.png";
	std::string arrowPng = rootPath + "fs_btn_ct_arrow_4way.png";
	std::string selectorPng = rootPath + "fs_btn_ct_foucs.png"; 
	std::string mousearrowPng = rootPath + "fs_btn_ct_arrow_pointer.png";

	setActorContent(removePng, m_removeImg);
	setActorContent(favouritePng, m_favouriteImg);
	setActorContent(multilinkPng, m_multilinkImg);
	
	setActorContent(arrowPng, m_arrowUPImg);
	setActorContent(mousearrowPng, m_mousearrowUPImg);
	setActorContent(selectorPng, m_selectorImg);
	
	clutter_actor_add_child(m_rootActor, m_removeImg);
	clutter_actor_add_child(m_rootActor, m_favouriteImg);
	clutter_actor_add_child(m_rootActor, m_multilinkImg);

	clutter_actor_add_child(m_rootActor, m_arrowUPImg);
	clutter_actor_add_child(m_rootActor, m_selectorImg);
	clutter_actor_add_child(m_rootActor, m_mousearrowUPImg);

	gfloat CONTENTS_EDGES_Y = SCENE_HEIGHT - WIDGET_HEIGHT - BOTTOM_HEIGHT;
	gfloat CONTEXT_MENU_EDGES_Y = CONTENTS_EDGES_Y - SCENE_HEIGHT * 0.008333;

	gfloat TMP_H = SCENE_HEIGHT == 1080 ? 82 : 54;
	gfloat ROOT_BEGIN_Y = CONTEXT_MENU_EDGES_Y - TMP_H;

	std::string optionTextFont = "";
	gfloat optionLayoutWidth  = 0;
	gfloat ITEM_SPACE = 0;
	if (SCENE_HEIGHT == 720)
	{
		ITEM_SPACE = 1280 * 0.046354;
		optionTextFont = "17px";
		optionLayoutWidth = 1280 * 0.042708;
	}
	else
	{
		ITEM_SPACE = 1920 * 0.046354;
		optionTextFont = "26px";
		optionLayoutWidth = 1920 * 0.042708;
	}

	std::string optionTxt = "Option";
	ClutterColor textColor = {255, 255, 255, 204};
	ClutterActor* optionText = clutter_text_new_full(TextScroll::canonicalizeFont(optionTextFont).c_str(), optionTxt.c_str(), &textColor);
	gfloat textWidth = clutter_actor_get_width(optionText);
	gfloat textHeight = clutter_actor_get_height(optionText);
	gfloat optionLayoutHeight = SCENE_HEIGHT * 0.027778;

	gfloat diffX = (optionLayoutWidth - textWidth) / 2;
	gfloat diffY = (optionLayoutHeight - textHeight) / 2;

	diffY += SCENE_HEIGHT * 0.009259;
	clutter_actor_set_position(optionText, diffX, diffY);
	clutter_actor_add_child(m_arrowUPImg, optionText);

	
	gfloat ROOT_WIDTH = ITEM_SPACE * 2 + TMP_H;
	gfloat ROOT_HEIGHT = SCENE_HEIGHT * 0.008333 + TMP_H;
	m_item_space = ITEM_SPACE;

	// offset
	m_middle_offset = ROOT_WIDTH / 2;

	// Option X Y
	gfloat TMP_H_O = SCENE_HEIGHT == 1080 ? 66 : 44;
	gfloat OPTION_Y = CONTENTS_EDGES_Y - SCENE_HEIGHT * 0.011111 - TMP_H_O;
	OPTION_Y = OPTION_Y - ROOT_BEGIN_Y;
	gfloat OPTION_X = ROOT_WIDTH - TMP_H_O;

	ClutterColor zeroColor = {0, 0, 0, 0};

	m_nomls_beginX = ITEM_SPACE / 2;

	clutter_actor_set_size(m_rootActor, ROOT_WIDTH, ROOT_HEIGHT);
	clutter_actor_set_size(m_removeImg, TMP_H, TMP_H);
	clutter_actor_set_size(m_favouriteImg, TMP_H, TMP_H);
	clutter_actor_set_size(m_multilinkImg, TMP_H, TMP_H);

	clutter_actor_set_size(m_arrowUPImg, TMP_H_O, TMP_H_O);//m_mousearrowUPImg
	clutter_actor_set_size(m_mousearrowUPImg, TMP_H_O, TMP_H_O);
	clutter_actor_set_size(m_selectorImg, TMP_H, TMP_H);

	clutter_actor_set_position(m_rootActor, 0, ROOT_BEGIN_Y);
	clutter_actor_set_background_color(m_rootActor, &zeroColor);

	gfloat OPTION_BEGIN_X = ROOT_WIDTH - TMP_H;
	m_mls_beginX = OPTION_BEGIN_X;
	clutter_actor_set_position(m_removeImg, OPTION_BEGIN_X - ITEM_SPACE * 2, 0);
	clutter_actor_set_position(m_favouriteImg, OPTION_BEGIN_X - ITEM_SPACE, 0);
	clutter_actor_set_position(m_multilinkImg, OPTION_BEGIN_X, 0);
	clutter_actor_set_position(m_selectorImg, OPTION_BEGIN_X - ITEM_SPACE * 2, 0);

	clutter_actor_set_position(m_arrowUPImg, OPTION_X, OPTION_Y);
	clutter_actor_set_position(m_mousearrowUPImg, OPTION_X, OPTION_Y);

	
	clutter_actor_add_child(instance->SCENEROOT->getActor(), m_rootActor);
	clutter_actor_set_opacity(m_rootActor, 0);

	int OPTION_DURATION = 300;
	int CONTEXTM_DURATION = 600;

	//clutter_actor_animate this api is not safe. some times the application coredump[shuhao.yan]

	// rise option animation
	ClutterTransition* transitionY = createTransition("y", OPTION_Y + 100, OPTION_Y, OPTION_DURATION);
	ClutterTransition* transitionOpacity = createTransition("opacity", 0, 255, OPTION_DURATION);
	clutter_actor_add_transition (m_arrowUPImg, "animateYUP", transitionY);
	clutter_actor_add_transition (m_arrowUPImg, "animateOpacitySHOW", transitionOpacity); 
	m_optionEnterTransitions.push_back(transitionY);
	m_optionEnterTransitions.push_back(transitionOpacity);

	// hide option animation
	transitionY = createTransition("y", OPTION_Y, OPTION_Y + 100, OPTION_DURATION);
	transitionOpacity = createTransition("opacity", 255, 0, OPTION_DURATION);
	clutter_actor_add_transition (m_arrowUPImg, "animateYDOWN", transitionY);
	clutter_actor_add_transition (m_arrowUPImg, "animateOpacityHIDE", transitionOpacity); 
	m_optionExitTransitions.push_back(transitionY);
	m_optionExitTransitions.push_back(transitionOpacity);

	//rise mouse poiter animation 
	transitionY = createTransition("y", OPTION_Y + 100, OPTION_Y, OPTION_DURATION);
	transitionOpacity = createTransition("opacity", 0, 255, OPTION_DURATION);
	clutter_actor_add_transition (m_mousearrowUPImg, "animateMouseYDOWN", transitionY);
	clutter_actor_add_transition (m_mousearrowUPImg, "animateMouseOpacityHIDE", transitionOpacity); 
	m_mouseoptionEnterTransitions.push_back(transitionY);
	m_mouseoptionEnterTransitions.push_back(transitionOpacity);

	// hide mouse poiter animation 
	transitionY = createTransition("y", OPTION_Y, OPTION_Y + 100, OPTION_DURATION);
	transitionOpacity = createTransition("opacity", 255, 0, OPTION_DURATION);
	clutter_actor_add_transition (m_mousearrowUPImg, "animateMouseYDOWN", transitionY);
	clutter_actor_add_transition (m_mousearrowUPImg, "animateMouseOpacityHIDE", transitionOpacity); 
	m_mouseoptionExitTransitions.push_back(transitionY);
	m_mouseoptionExitTransitions.push_back(transitionOpacity);


	// show Context menu
	ClutterTransition* transitionX = createTransition("x", OPTION_BEGIN_X, OPTION_BEGIN_X - ITEM_SPACE * 2, CONTEXTM_DURATION);
	transitionOpacity = createTransition("opacity", 0, 255, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_removeImg, "animateXR", transitionX);
	clutter_actor_add_transition (m_removeImg, "animateOpacityRSHOW", transitionOpacity);
	m_enterContextMenuTransitions.push_back(transitionX);
	m_enterContextMenuTransitions.push_back(transitionOpacity);

	transitionX = createTransition("x", OPTION_BEGIN_X, OPTION_BEGIN_X - ITEM_SPACE, CONTEXTM_DURATION);
	transitionOpacity = createTransition("opacity", 0, 255, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_favouriteImg, "animateFX", transitionX);
	clutter_actor_add_transition (m_favouriteImg, "animateOpacityFSHOW", transitionOpacity);
	m_enterContextMenuTransitions.push_back(transitionX);
	m_enterContextMenuTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 0, 255, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_multilinkImg, "animateOpacityMSHOW", transitionOpacity);
	m_enterContextMenuTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 0, 255, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_selectorImg, "animateOpacitySMSHOW", transitionOpacity);
	m_enterContextMenuTransitions.push_back(transitionOpacity);


	// hide Context Menu
	transitionX = createTransition("x", OPTION_BEGIN_X - ITEM_SPACE * 2, OPTION_BEGIN_X, CONTEXTM_DURATION);
	transitionOpacity = createTransition("opacity", 255, 0, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_removeImg, "animateXRR", transitionX);
	clutter_actor_add_transition (m_removeImg, "animateOpacityRHIDE", transitionOpacity);
	m_exitContextMenuTransitions.push_back(transitionX);
	m_exitContextMenuTransitions.push_back(transitionOpacity);

	transitionX = createTransition("x", OPTION_BEGIN_X - ITEM_SPACE, OPTION_BEGIN_X, CONTEXTM_DURATION);
	transitionOpacity = createTransition("opacity", 255, 0, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_favouriteImg, "animateXFR", transitionX);
	clutter_actor_add_transition (m_favouriteImg, "animateOpacityFHIDE", transitionOpacity);
	m_exitContextMenuTransitions.push_back(transitionX);
	m_exitContextMenuTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 255, 0, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_multilinkImg, "animateOpacityMHIDE", transitionOpacity);
	m_exitContextMenuTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 255, 0, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_selectorImg, "animateOpacitySMHIDE", transitionOpacity);
	m_exitContextMenuTransitions.push_back(transitionOpacity);


	// show ContextMenu No MLS
	transitionX = createTransition("x", m_nomls_beginX + m_item_space, m_nomls_beginX, CONTEXTM_DURATION);
	transitionOpacity = createTransition("opacity", 0, 255, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_removeImg, "animateXRRNOMLS", transitionX);
	clutter_actor_add_transition (m_removeImg, "animateOpacityRSHOWNOMLS", transitionOpacity);
	m_enterContextMenuNOMLSTransitions.push_back(transitionX);
	m_enterContextMenuNOMLSTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 0, 255, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_favouriteImg, "animateOpacityFSHOWNOMLS", transitionOpacity);
	m_enterContextMenuNOMLSTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 0, 255, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_selectorImg, "animateOpacitySMSHOWNOMLS", transitionOpacity);
	m_enterContextMenuNOMLSTransitions.push_back(transitionOpacity);

	// hide ContextMenu No MLS
	transitionX = createTransition("x", m_nomls_beginX, m_nomls_beginX + m_item_space, CONTEXTM_DURATION);
	transitionOpacity = createTransition("opacity", 255, 0, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_removeImg, "animateXRRNOMLS", transitionX);
	clutter_actor_add_transition (m_removeImg, "animateOpacityRHIDENOMLS", transitionOpacity);
	m_exitContextMenuNOMLSTransitions.push_back(transitionX);
	m_exitContextMenuNOMLSTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 255, 0, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_favouriteImg, "animateOpacityFHIDENOMLS", transitionOpacity);
	m_exitContextMenuNOMLSTransitions.push_back(transitionOpacity);

	transitionOpacity = createTransition("opacity", 255, 0, CONTEXTM_DURATION);
	clutter_actor_add_transition (m_selectorImg, "animateOpacitySMHIDENOMLS", transitionOpacity);
	m_exitContextMenuNOMLSTransitions.push_back(transitionOpacity);

	for (auto it = m_optionEnterTransitions.begin(); it != m_optionEnterTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	for (auto it = m_mouseoptionEnterTransitions.begin(); it != m_mouseoptionEnterTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	for (auto it = m_mouseoptionExitTransitions.begin(); it != m_mouseoptionExitTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	for (auto it = m_optionExitTransitions.begin(); it != m_optionExitTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	for (auto it = m_enterContextMenuTransitions.begin(); it != m_enterContextMenuTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	for (auto it = m_exitContextMenuTransitions.begin(); it != m_exitContextMenuTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	for (auto it = m_enterContextMenuNOMLSTransitions.begin(); it != m_enterContextMenuNOMLSTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	for (auto it = m_exitContextMenuNOMLSTransitions.begin(); it != m_exitContextMenuNOMLSTransitions.end(); ++it)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(*it));
	}

	clutter_actor_set_opacity(m_removeImg, 0);
	clutter_actor_set_opacity(m_favouriteImg, 0);
	clutter_actor_set_opacity(m_multilinkImg, 0);
	clutter_actor_set_opacity(m_selectorImg, 0);
	clutter_actor_set_opacity(m_arrowUPImg, 0);
	clutter_actor_set_opacity(m_mousearrowUPImg, 0);
	
	M_FOCUS_FLAG = false;
	M_RISE_FLAG	 = false;
	m_focusIndex = 0;
	
}

ClutterActor*  ContextMenu::getRootActor()
{
	return m_rootActor;
}

void ContextMenu::setActorContent(std::string url, ClutterActor* actor)
{
	ClutterContent *content = clutter_image_new();
	GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file (url.c_str(), NULL);
	clutter_image_set_data (CLUTTER_IMAGE(content),
						gdk_pixbuf_get_pixels (pixbuf),
						gdk_pixbuf_get_has_alpha (pixbuf)
						  ? COGL_PIXEL_FORMAT_RGBA_8888
						  : COGL_PIXEL_FORMAT_RGB_888,
						gdk_pixbuf_get_width (pixbuf),
						gdk_pixbuf_get_height (pixbuf),
						gdk_pixbuf_get_rowstride (pixbuf),
						NULL);
	g_object_unref (pixbuf);
	clutter_actor_set_content(actor, CLUTTER_CONTENT(content));
	g_object_unref (content);
}

ClutterTransition* ContextMenu::createTransition(const std::string property, int begineValue, int endValue, int duration)
{
	ClutterTransition* transition = clutter_property_transition_new (property.c_str());
	clutter_timeline_set_duration (CLUTTER_TIMELINE (transition), duration);

	clutter_transition_set_from (transition, G_TYPE_UINT, begineValue);
	clutter_transition_set_to (transition, G_TYPE_UINT, endValue);
	return transition;
}

void ContextMenu::riseContextMenu(gfloat cur_index, bool mouseFlag)
{

	if (!CONTEXTMENU_ENABLE)
	{
		return;
	}
	
	//printf("##########riseContextMenu   ####  BEGIN  \n");
	clutter_actor_set_opacity(m_rootActor, 255);

	if (M_RISE_FLAG || M_FOCUS_FLAG)
	{
		return;
	}

	M_RISE_FLAG = true;

	gfloat currentFousX  = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * cur_index+ FOCUS_CONTENTS_WIDTH / 2;

	clutter_actor_set_x(m_rootActor, currentFousX - m_middle_offset);

	if (mouseFlag)
	{
		//printf("##########riseContextMenu   ####  MOUSE  \n");
		M_MOUSE_RISE = true;
		for (auto it = m_mouseoptionEnterTransitions.begin(); it != m_mouseoptionEnterTransitions.end(); ++it)
		{
			clutter_timeline_start(CLUTTER_TIMELINE(*it));
		}
		m_preContentIndex = cur_index;
	}
	else
	{
		printf("##########riseContextMenu   ####  KEY  \n");
		M_MOUSE_RISE = false;
		for (auto it = m_optionEnterTransitions.begin(); it != m_optionEnterTransitions.end(); ++it)
		{
			clutter_timeline_start(CLUTTER_TIMELINE(*it));
		}
	}
	
	
}

bool ContextMenu::fallContextMenu()
{
	if (!CONTEXTMENU_ENABLE)
	{
		return false;
	}
	
	
	//printf("##########fallContextMenu   ####   \n");
	if (M_FOCUS_FLAG)
	{
		M_FOCUS_FLAG = false;


		if (M_MLS_DISABLE)
		{
			for (auto it = m_exitContextMenuNOMLSTransitions.begin(); it != m_exitContextMenuNOMLSTransitions.end(); ++it)
			{
				clutter_timeline_start(CLUTTER_TIMELINE(*it));
			} 
		} 
		else
		{
			
			for (auto it = m_exitContextMenuTransitions.begin(); it != m_exitContextMenuTransitions.end(); ++it)
			{
				clutter_timeline_start(CLUTTER_TIMELINE(*it));
			}
		}

		// to show the global cursor
		clutter_actor_set_opacity(globalCursor, 255);
		
	}

	if (M_RISE_FLAG)
	{
		M_RISE_FLAG = false;
		if (M_MOUSE_RISE)
		{
			//printf("##########fallContextMenu   ####  MOUSE \n");
			for (auto it = m_mouseoptionExitTransitions.begin(); it != m_mouseoptionExitTransitions.end(); ++it)
			{
				clutter_timeline_start(CLUTTER_TIMELINE(*it));
			}
		}
		else
		{
			//printf("##########fallContextMenu   ####  KEY \n");
			for (auto it = m_optionExitTransitions.begin(); it != m_optionExitTransitions.end(); ++it)
			{
				clutter_timeline_start(CLUTTER_TIMELINE(*it));
			}
		}
	}

	return true;
}

void ContextMenu::fallContextMenuBY_MOUSEMOVEOUT()
{
	if (M_FOCUS_FLAG)
	{
		if (m_preContentIndex != currentContents)
		{
			fallContextMenu();
		}

		if (instance != NULL && instance->onContextMenuUnfocusListener.isFunction()) 
		{	
			// feedback  to JS layer [shuhao.yan]
			ScriptArray arr;
			instance->onContextMenuUnfocusListener.invoke(arr);
		}
	}
}

bool ContextMenu::setFocusContextMenu(int contextType)
{
	if (!CONTEXTMENU_ENABLE)
	{
		return false;
	}
	

	//printf("##########setFocusContextMenu   ####   \n");
	if (!ContextMenu::checkContextMenuPopCondition())
	{
		LOG_DEBUG(logger, "[shuhao.yan] Now the condition is not correct");
		return false;
	}
	
	if (M_FOCUS_FLAG)
	{
		return false;
	}

	m_focusIndex = 0;
	clutter_actor_set_x(m_selectorImg, 0);

	M_FOCUS_FLAG = true;

	gfloat currentFousX  = clutter_actor_get_x(bar) + NORMAL_CATEGORY_WIDTH + CATEGORY_GAP + NORMAL_CONTENTS_WIDTH * currentContents + FOCUS_CONTENTS_WIDTH / 2;
			
	clutter_actor_set_x(m_rootActor, currentFousX - m_middle_offset);
	clutter_actor_set_opacity(m_rootActor, 255);

	m_preContentIndex = currentContents;

	if (contextType)
	{
		M_MLS_DISABLE = true;
		// set the option pre position
		clutter_actor_set_x(m_removeImg, m_nomls_beginX + m_item_space);
		clutter_actor_set_x(m_favouriteImg, m_nomls_beginX + m_item_space);
		clutter_actor_set_x(m_selectorImg, m_nomls_beginX);

		for (auto it = m_enterContextMenuNOMLSTransitions.begin(); it != m_enterContextMenuNOMLSTransitions.end(); ++it)
		{
			clutter_timeline_start(CLUTTER_TIMELINE(*it));
		}
		 
	} 
	else
	{
		M_MLS_DISABLE = false;
		clutter_actor_set_x(m_removeImg, m_mls_beginX );
		clutter_actor_set_x(m_favouriteImg, m_mls_beginX);
		clutter_actor_set_x(m_multilinkImg, m_mls_beginX);
		clutter_actor_set_x(m_selectorImg, m_mls_beginX - m_item_space * 2);
		
		for (auto it = m_enterContextMenuTransitions.begin(); it != m_enterContextMenuTransitions.end(); ++it)
		{
			clutter_timeline_start(CLUTTER_TIMELINE(*it));
		}
	}

	// to hide the global cursor
	clutter_actor_set_opacity(globalCursor, 0);


	if (M_RISE_FLAG)
	{
		M_RISE_FLAG = false;
		for (auto it = m_optionExitTransitions.begin(); it != m_optionExitTransitions.end(); ++it)
		{
			clutter_timeline_start(CLUTTER_TIMELINE(*it));
		}
	}
	
	return true;
	
}

bool ContextMenu::contextMenuKeyHandler(int keycode)
{
	if (!CONTEXTMENU_ENABLE)
	{
		return false;
	}
	
	int RIGHLIMIT = 2;
	if (M_MLS_DISABLE)
	{
		RIGHLIMIT = 1;
	}

	if (!M_FOCUS_FLAG)
	{
		return false;
	}
	else
	{
		switch(keycode)
		{
			case LEFT_KEY:
				if (m_focusIndex == 0)
				{
					return true;
				}
				else
				{
					m_focusIndex--;
					
				}
				break;
			case RIGHT_KEY:
				if (m_focusIndex == RIGHLIMIT)
				{
					return true;
				}
				else
				{
					m_focusIndex++;
					
				}
				break;
			default:
				return false;
		}
	}


	gfloat x_offset = 0;
	if (M_MLS_DISABLE)
	{
	    x_offset = m_nomls_beginX + m_item_space * m_focusIndex;
		clutter_actor_animate(m_selectorImg, CLUTTER_LINEAR, 300, "x", x_offset, NULL);
	}
	else
	{
	    x_offset = m_item_space * m_focusIndex;
		clutter_actor_animate(m_selectorImg, CLUTTER_LINEAR, 300, "x", x_offset, NULL);
	}
	return true;
}


gboolean ContextMenu::showSelectorImg(gpointer data)
{
	ContextMenu* ctxHandle = static_cast<ContextMenu*>(data);
	ctxHandle->showSelImg();
	return FALSE;
}

void ContextMenu::showSelImg()
{
	clutter_actor_animate(m_selectorImg, CLUTTER_LINEAR, 150, "opacity", 255, NULL);
}

int ContextMenu::enterOption()
{
	clutter_actor_animate(m_selectorImg, CLUTTER_LINEAR, 150, "opacity", 0, NULL);
	
	clutter_threads_add_timeout (150, showSelectorImg , this);
	return m_focusIndex;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////


static void startNormalTitleScroll(int index)
{
	ClutterActor* wrapper = getListWrapper(extendIndex);
	ClutterActor* contentWrapper = clutter_actor_get_child_at_index(wrapper, index);

	ClutterActor* titleParent = clutter_actor_get_child_at_index(contentWrapper, TITLEPARENT_INDEX);
	ClutterActor* normalTitle = clutter_actor_get_child_at_index(titleParent, NORMALTITLE_INDEX);

	TextScroll* ctr = TextScroll::findNormalInc(normalTitle);

	if (ctr != NULL)
	{
		preTextInc = ctr;
		ctr->scrollStart();
	}
}

static void startFocusTitleScroll(int index)
{
	ClutterActor* wrapper = getListWrapper(extendIndex);
	ClutterActor* contentWrapper = clutter_actor_get_child_at_index(wrapper, index);

	ClutterActor* titleParent = clutter_actor_get_child_at_index(contentWrapper, TITLEPARENT_INDEX);
	ClutterActor* focusTitle = clutter_actor_get_child_at_index(titleParent, FOCUSTITLE_INDEX);

	TextScroll* ctr = TextScroll::findFocusInc(focusTitle);
	if (ctr != NULL)
	{
		preTextInc = ctr;
		ctr->scrollStart();
	}

}

static void checkTitleScroll()
{
	if (currentContents == preContents)	
	{
		if (currentContents < 0)
		{
			if (preTextInc != NULL)
			{
				preTextInc->scrollStop();
				preTextInc = NULL;
			}
			return;
		}
		
		if (preTextInc == NULL)
		{
			if (isKeyControl)
			{
				startFocusTitleScroll(currentContents);
			}
			else
			{
				startNormalTitleScroll(currentContents);
			}
		}
		
		return;
	}
	else
	{
		if (foveaState == EMPTY)
		{
			if (preTextInc != NULL)
			{
				preTextInc->scrollStop();
				preTextInc = NULL;
			}
			return;
		}
	
		if (isKeyControl)
		{
			if (preTextInc != NULL)
			{
				preTextInc->scrollStop();
				preTextInc = NULL;
			}

			startFocusTitleScroll(currentContents);

			preContents = currentContents;
		}
		else
		{
			if (preTextInc != NULL)
			{
				preTextInc->scrollStop();
				preTextInc = NULL;
			}

			startNormalTitleScroll(currentContents);

			preContents = currentContents;

		}
	}

}

void TextScroll::insertNormalInc(ClutterActor* actor, TextScroll* normalTitleInc)
{
	normalTitleInc->normalFLAG = true;
	normalTitleScrollMap.insert(std::pair<ClutterActor*, TextScroll*>(actor, normalTitleInc));

}

void TextScroll::insertFocusInc(ClutterActor* actor, TextScroll* focusTitleInc)
{
	focusTitleInc->normalFLAG = false;
	focusTitleScrollMap.insert(std::pair<ClutterActor*, TextScroll*>(actor, focusTitleInc));
}

void TextScroll::removeInc(TextScroll* TitleInc, ClutterActor* removeactor)
{
	if (TitleInc->normalFLAG)
	{
		std::map<ClutterActor*, TextScroll*>::iterator it = normalTitleScrollMap.find(removeactor);
		if (it != normalTitleScrollMap.end())
		{
			normalTitleScrollMap.erase(it);
		}

	}
	else
	{
		std::map<ClutterActor*, TextScroll*>::iterator itf = focusTitleScrollMap.find(removeactor);
		if (itf != focusTitleScrollMap.end())
		{
			focusTitleScrollMap.erase(itf);
		}
	}
	
}

TextScroll* TextScroll::findNormalInc(ClutterActor* normalTitle)
{
	TextScroll* ctr = NULL;
	std::map<ClutterActor*, TextScroll*>::iterator it = normalTitleScrollMap.find(normalTitle);
	if (it != normalTitleScrollMap.end())
	{
		ctr = it->second;
	}

	return ctr;
}


TextScroll* TextScroll::findFocusInc(ClutterActor* focusTitle)
{
	TextScroll* ctr = NULL;
	std::map<ClutterActor*, TextScroll*>::iterator it = focusTitleScrollMap.find(focusTitle);
	if (it != focusTitleScrollMap.end())
	{
		ctr = it->second;
	}

	return ctr;
}


TextScroll::TextScroll(ClutterActor* parent, const ScriptObject arg)
{
	float x = 0, y = 0;
	m_fontName = "";
	m_text = "";
	HorizontalAlign = "left";
	VerticalAlign = "top";
	Color textColor = Color( 255, 255, 255, 255); 

	diffX = 0;
	diffY = 0;
	layoutX = 0;
	layoutY = 0;

	m_parent = parent;
	layoutActor = clutter_actor_new();
	
	if (arg.has("text"))
	{
		m_text = arg.get("text").asString();
	}

	if (arg.has("font"))
	{
		m_fontName = arg.get("font").asString();
	}

	if (arg.has("horizontalAlignment"))
	{
		HorizontalAlign = arg.get("horizontalAlignment").asString();
	}

	if (arg.has("verticalAlignment"))
	{
		VerticalAlign = arg.get("verticalAlignment").asString();
	}

	if (arg.has("textColor"))
	{
		textColor = ScriptToColor(arg.get("textColor"));
	}

	layoutWidth = -1;
	layoutHeight = -1;
	if (arg.has("width") || arg.has("height") || arg.has("x") || arg.has("y"))
	{
		layoutX = arg.has("x") ? arg.get("x").asNumber() : 0;
		layoutY = arg.has("y") ? arg.get("y").asNumber() : 0;
		layoutWidth = arg.has("width") ? arg.get("width").asNumber() : -1;
		layoutHeight = arg.has("height") ? arg.get("height").asNumber() : -1;
	}	
	ClutterColor zeroColor = {0, 0, 0, 0};
	textActor = clutter_text_new_full(canonicalizeFont(m_fontName).c_str(), m_text.c_str(), textColor.toClutterColor());

	//pango_layout_get_size(clutter_text_get_layout(CLUTTER_TEXT(textActor)), &textWidth, &textHeight);
	textWidth = clutter_actor_get_width(textActor);
	textHeight = clutter_actor_get_height(textActor);

	clutter_actor_set_position(layoutActor, layoutX, layoutY);
	if (layoutWidth == -1)
	{
		layoutWidth = textWidth;
	}

	if (layoutHeight == -1)
	{
		layoutHeight = textHeight;
	}
	
	clutter_actor_set_size(layoutActor, layoutWidth, layoutHeight);
	clutter_actor_set_background_color(layoutActor, &zeroColor);
	clutter_actor_set_clip_to_allocation(layoutActor, TRUE);

	clutter_text_set_ellipsize(CLUTTER_TEXT(textActor), PANGO_ELLIPSIZE_END);
	clutter_text_set_single_line_mode(CLUTTER_TEXT(textActor), true);
	initTextLayout(textActor, layoutActor, HorizontalAlign, VerticalAlign);

	if (textWidth <= layoutWidth && textWidth < clutter_actor_get_width(parent))
	{
		scrollVisible = false;
		clutter_actor_add_child(parent, textActor);
		clutter_actor_destroy(layoutActor); 
		return;
	}
	scrollVisible = true;
	scrollFlag = false;
	
	moveActor = clutter_actor_new();
	clutter_actor_set_position(moveActor, textWidth, 0);

	clutter_actor_add_child(layoutActor, moveActor);
	clutter_actor_add_child(parent, layoutActor);
	clutter_actor_add_child(layoutActor, textActor);
	clutter_actor_set_size(textActor, layoutWidth, layoutHeight);

	transitionScroll = ContextMenu::Instance().createTransition("x", 0, textWidth, 6000);
	clutter_timeline_set_repeat_count (CLUTTER_TIMELINE (transitionScroll), -1); 
	clutter_timeline_set_delay(CLUTTER_TIMELINE (transitionScroll), 1000);
	clutter_timeline_set_direction(CLUTTER_TIMELINE (transitionScroll), CLUTTER_TIMELINE_BACKWARD);//CLUTTER_TIMELINE_FORWARD
	clutter_actor_add_transition (moveActor, "Text_Scroll", transitionScroll);
	clutter_timeline_stop(CLUTTER_TIMELINE(transitionScroll));
	
}


ClutterActor* TextScroll::getOperatorActor()
{
	if (scrollVisible)
	{
		return layoutActor;
	}
	else
	{
		return textActor;
	}
}

void TextScroll::setPosition(float posX, float posY)
{
	layoutX = posX;
	layoutY = posY;
	if (scrollVisible)
	{
		clutter_actor_set_position(layoutActor, posX, posY);
	}
	else
	{
		float setX = posX + diffX;
		float setY = posY + diffY;
		clutter_actor_set_position(textActor, setX, setY);
	}
}

float TextScroll::getTextAbsoluteSize(const std::string param)
{

	gfloat retalue = -1;
	ClutterColor zeroColor = {0, 0, 0, 0};
	ClutterActor* tmptext = clutter_text_new_full(canonicalizeFont(m_fontName).c_str(), m_text.c_str(), &zeroColor);
	if (compareStrChar(param, "width"))
	{
		retalue =  clutter_actor_get_width(tmptext);
	}
	else if ((compareStrChar(param, "height")))
	{
		retalue =  clutter_actor_get_height(tmptext);
	}

	clutter_actor_destroy(tmptext); 
	return retalue;

}

void TextScroll::setLayoutSize(float width, float height, bool normalFlag)
{
	// now just comfirm the width working [shuhao.yan]
	textWidth = getTextAbsoluteSize("width");
	textHeight = getTextAbsoluteSize("height");
	if (textWidth > width)
	{
		if (scrollVisible)
		{
			if (width != -1)
			{
				layoutWidth = width;
				clutter_actor_set_width(layoutActor, layoutWidth);
			}

			if (height != -1)
			{
				layoutHeight = height;
				clutter_actor_set_height(layoutActor, layoutHeight);
			}

			clutter_actor_set_clip(layoutActor, 0, 0, layoutWidth, layoutHeight);
			
		}
		else
		{

		}
	}
	else
	{
		if (scrollVisible)
		{
			scrollVisible = false;
			clutter_timeline_stop(CLUTTER_TIMELINE(transitionScroll));
			g_object_unref(transitionScroll); 

			if (width != -1)
			{
				layoutWidth = width;
				clutter_actor_set_width(layoutActor, layoutWidth);
			}

			if (height != -1)
			{
				layoutHeight = height;
				clutter_actor_set_height(layoutActor, layoutHeight);
			}

			clutter_actor_set_clip(layoutActor, 0, 0, layoutWidth, layoutHeight);
			
			clutter_actor_set_size(textActor, textWidth, textHeight);
			initTextLayout(textActor, layoutActor, HorizontalAlign, VerticalAlign);
			
			clutter_actor_reparent (textActor, m_parent);
			
			clutter_actor_remove_child(m_parent, layoutActor);
			
			if (normalFlag)
			{
				printf("This is the normale title setting \n");
				clutter_actor_set_child_at_index(m_parent, textActor, 0);
			}
			else
			{
				printf("This is the focus title setting \n");
				clutter_actor_set_child_at_index(m_parent, textActor, 1);
			}
			setPosition(layoutX, layoutY);
			
		}
		else
		{
			if (compareStrChar(HorizontalAlign, "center"))
			{
				if (textWidth <= width)
				{
					layoutWidth = width;
					diffX = (layoutWidth - textWidth) / 2;
				}
				clutter_actor_set_x(textActor, diffX);
			}
		}
	}
	
}


void TextScroll::setTextFont(std::string fontName)
{
	clutter_text_set_font_name(CLUTTER_TEXT(textActor), fontName.c_str());

#if 0
	int w,h;
	pango_layout_get_pixel_size(clutter_text_get_layout(CLUTTER_TEXT(textActor)), &w, &h);
	textWidth = w / 1000;
	textHeight = h / 1000;
#endif

	ClutterColor zeroColor = {0, 0, 0, 0};

	ClutterActor* tmptext = clutter_text_new_full(canonicalizeFont(fontName).c_str(),  m_text.c_str(), &zeroColor);
	textWidth = clutter_actor_get_width(tmptext);
	textHeight = clutter_actor_get_height(tmptext);
	clutter_actor_destroy(tmptext); 

	if (scrollVisible)
	{	
		clutter_timeline_stop(CLUTTER_TIMELINE(transitionScroll));
		g_object_unref(transitionScroll); 

		if (textWidth > layoutWidth)
		{
			clutter_actor_set_position(moveActor, textWidth, 0);
			transitionScroll = ContextMenu::Instance().createTransition("x", 0, textWidth, 6000);
			clutter_timeline_set_repeat_count (CLUTTER_TIMELINE (transitionScroll), -1); 
			clutter_timeline_set_delay(CLUTTER_TIMELINE (transitionScroll), 1000);
			clutter_timeline_set_direction(CLUTTER_TIMELINE (transitionScroll), CLUTTER_TIMELINE_BACKWARD);//CLUTTER_TIMELINE_FORWARD
			clutter_actor_add_transition (moveActor, "Text_Scroll_2", transitionScroll);
			clutter_timeline_stop(CLUTTER_TIMELINE(transitionScroll));
			scrollFlag = false;
		}
		else
		{
			removeInc(this, layoutActor);
			scrollVisible = false;
			if (!scrollFlag)
			{
				clutter_actor_reparent (textActor, m_parent);
				
			}
			else
			{
				clutter_actor_set_size(textActor, layoutWidth, layoutHeight);
				clutter_actor_reparent (textActor, layoutActor);
				clutter_actor_set_x(textActor, 0);

				clutter_actor_reparent (textActor, m_parent);
				
			}
			setLayoutSize(layoutWidth, layoutHeight, normalFLAG);
			setPosition(layoutX, layoutY);

			clutter_actor_remove_child(m_parent, layoutActor);
			scrollFlag = false;

			if (this->normalFLAG)
			{
				clutter_actor_set_child_at_index(m_parent, textActor, 0);
				insertNormalInc(textActor, this);
			}
			else
			{
				insertFocusInc(textActor, this);
			}
			
		}

	}
	else
	{
		layoutActor = clutter_actor_new();
		clutter_actor_set_size(layoutActor, layoutWidth, layoutHeight);
		clutter_actor_set_background_color(layoutActor, &zeroColor);
		clutter_actor_set_clip_to_allocation(layoutActor, TRUE);
		initTextLayout(textActor, layoutActor, HorizontalAlign, VerticalAlign);
		
		if (textWidth <= layoutWidth)
		{
			setPosition(layoutX, layoutY);
			clutter_actor_destroy(layoutActor); 
			return;
		}
		
		scrollVisible = true;
		scrollFlag = false;
		
		
		moveActor = clutter_actor_new();
		clutter_actor_set_position(moveActor, textWidth, 0);

		removeInc(this, textActor);

		g_object_ref_sink(textActor); 
		clutter_actor_replace_child(m_parent, textActor, layoutActor); 
	
		clutter_actor_add_child(layoutActor, moveActor);
		clutter_actor_add_child (layoutActor, textActor);
		
		clutter_actor_set_size(textActor, layoutWidth, layoutHeight);
		clutter_actor_set_position(layoutActor, layoutX, layoutY);

		if (this->normalFLAG)
		{
			insertNormalInc(layoutActor, this);
		}
		else
		{
			insertFocusInc(layoutActor, this);
		}

		transitionScroll = ContextMenu::Instance().createTransition("x", 0, textWidth, 6000);
		clutter_timeline_set_repeat_count (CLUTTER_TIMELINE (transitionScroll), -1); 
		clutter_timeline_set_delay(CLUTTER_TIMELINE (transitionScroll), 1000);
		clutter_timeline_set_direction(CLUTTER_TIMELINE (transitionScroll), CLUTTER_TIMELINE_BACKWARD);//CLUTTER_TIMELINE_FORWARD
		clutter_actor_add_transition (moveActor, "Text_Scroll_1", transitionScroll);
		clutter_timeline_stop(CLUTTER_TIMELINE(transitionScroll));
	}
}


LayoutAlignment TextScroll::deserializeLayoutAlignment(std::string alignmentStr)
{
  if(compareStrChar(alignmentStr, "right") || compareStrChar(alignmentStr, "bottom"))
  {
	return LayoutAlignment::Right;
  }

  if(compareStrChar(alignmentStr, "center"))
  {
	return LayoutAlignment::Center;
  }

  if(compareStrChar(alignmentStr, "left")|| compareStrChar(alignmentStr, "top"))
  {
	return LayoutAlignment::Left;
  }
  else
  {
	return LayoutAlignment::Left;
  }
}


void TextScroll::initTextLayout(ClutterActor* textActor, ClutterActor* layoutActor, 
									std::string HorizontalLayout, std::string VerticalLayout)
{
	layoutWidth = clutter_actor_get_width(layoutActor);
	layoutHeight = clutter_actor_get_height(layoutActor);

	do {
		if (compareStrChar(HorizontalLayout, ""))
		{
			break;
		}
		// Horizontal
		switch(deserializeLayoutAlignment(HorizontalLayout))
		{
			case LayoutAlignment::Right:
				if (textWidth <= layoutWidth)
				{
					diffX = layoutWidth - textWidth;
				}
				break;
			case LayoutAlignment::Center:
				if (textWidth <= layoutWidth)
				{
					diffX = (layoutWidth - textWidth) / 2;
				}
				break;
			case LayoutAlignment::Left:
				// do nothing
				break;
			default:
				break;
		}
		
	} while(0);


	do {
		if (compareStrChar(VerticalLayout, ""))
		{
			break;
		}

		// Vertical
		switch(deserializeLayoutAlignment(VerticalLayout))
		{
			case LayoutAlignment::Right:
				if (textHeight <= layoutHeight)
				{
					diffY = layoutHeight - textHeight;
				}
				break;
			case LayoutAlignment::Center:
				if (textHeight <= layoutHeight)
				{
					diffY = (layoutHeight - textHeight) / 2;
				}
				break;
			case LayoutAlignment::Left:
				// do nothing
				break;
			default:
				break;
		}

	} while(0);

	// default is (0,0)
	clutter_actor_set_position(textActor, diffX, diffY);
}


Color TextScroll::ScriptToColor(const ScriptObject& val)
{
  Color retval;
  ScriptObject r,g,b,a;

  if( val.has("r") || val.has("g") || val.has("b") || val.has("a") )
  {
    retval.r = (val.has("r")) ? val["r"].asNumber() : 0;
    retval.g = (val.has("g")) ? val["g"].asNumber() : 0;
    retval.b = (val.has("b")) ? val["b"].asNumber() : 0;
    retval.a = (val.has("a")) ? val["a"].asNumber() : 255;
    return retval;
  }

  throw VoltJsRuntimeException("Bad Type: Color object expected for color value.");
}
	
std::string& TextScroll::canonicalizeFont(std::string &aFont)
{

  PangoFontDescription *desc =
	pango_font_description_from_string(aFont.c_str());
  char *desc_str = pango_font_description_to_string(desc);

  if (defaultFontDescription || defaultAppFontDescription)
  {
	const char *default_family = NULL;

	if (defaultFontDescription)
	{
	  default_family =
		pango_font_description_get_family(defaultFontDescription);
	}

	const char *default_app_family = NULL;

	if (defaultAppFontDescription)
	{
	  default_app_family =
		pango_font_description_get_family(defaultAppFontDescription);
	}

	bool use_default = true;
	const char *req_family = pango_font_description_get_family(desc);

	if (req_family)
	{
	  FcPattern *pattern = FcPatternCreate();
	  FcPatternAddString(pattern, FC_FAMILY,
						 reinterpret_cast<const FcChar8 *>(req_family));
	  if (FcConfigSubstitute(NULL, pattern, FcMatchPattern) == FcFalse)
	  {
		//LOG_WARN(logger, "Failed to perform FcConfigSubstitute");
	  }

	  FcDefaultSubstitute(pattern);
	  FcResult result;
	  FcPattern *match = FcFontMatch(NULL, pattern, &result);

	  if (match != NULL)
	  {
		FcValue value;
		result = FcPatternGet(match, FC_FAMILY, 0, &value);

		if (result == FcResultMatch)
		{
		  //LOG_DEBUG(logger, "Matched font family: " << req_family << " == " << value.u.s);

		  if (strcmp(req_family, reinterpret_cast<const char *>(value.u.s)) == 0)
		  {
			use_default = false;
		  }
		}
	  }

	}

	if (use_default)
	{
	  g_free(desc_str);

	  const char *the_default =
		default_app_family ? default_app_family : default_family;
	  pango_font_description_set_family(desc, the_default);
	  desc_str = pango_font_description_to_string(desc);
	}
  }

  aFont = desc_str;

  g_free(desc_str);

  return aFont;
}


void TextScroll::scrollStart()
{
	if (scrollVisible && !scrollFlag)
	{
		clutter_actor_set_position(moveActor, textWidth, 0);
		
		clutter_actor_set_size(textActor, textWidth, textHeight);
		clutter_actor_reparent (textActor, moveActor);
		clutter_actor_set_x(textActor, -textWidth);
		
		clutter_timeline_start(CLUTTER_TIMELINE(transitionScroll));
		scrollFlag = true;
	}
}

void TextScroll::scrollStop()
{
	if (scrollVisible && scrollFlag)
	{
		clutter_timeline_stop(CLUTTER_TIMELINE(transitionScroll));
		clutter_actor_set_size(textActor, layoutWidth, layoutHeight);
		clutter_actor_reparent (textActor, layoutActor);
		clutter_actor_set_x(textActor, 0);
		scrollFlag = false;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ProgressController::ProgressController(ClutterActor* parent)
{
	
	ClutterColor progressColor = {255, 255, 255, 25};
	ClutterColor fullColor = {255, 255, 255, 255};
	ClutterColor zeroColor = {0, 0, 0, 0};

	m_dim = clutter_actor_new();
	clutter_actor_set_size(m_dim, NORMAL_CONTENTS_WIDTH, WIDGET_HEIGHT);
	clutter_actor_set_position(m_dim, 0, 0);
	clutter_actor_set_opacity(m_dim, 255);
	clutter_actor_set_background_color(m_dim, &zeroColor);

	m_progressP = clutter_actor_new();
	clutter_actor_set_size(m_progressP, NORMAL_CONTENTS_WIDTH, PROGRESS_HEIGHT);
	clutter_actor_set_position(m_progressP, 0, CONTENTS_IMAGE_HEIGHT - PROGRESS_HEIGHT);
	clutter_actor_set_background_color(m_progressP, &progressColor);
	clutter_actor_set_opacity(m_progressP, 0);
	clutter_actor_set_clip_to_allocation(m_progressP, TRUE);

	m_progressC = clutter_actor_new();
	clutter_actor_set_size(m_progressC, NORMAL_CONTENTS_WIDTH, PROGRESS_HEIGHT);
	clutter_actor_set_position(m_progressC, -NORMAL_CONTENTS_WIDTH, 0);
	clutter_actor_set_background_color(m_progressC, &fullColor);
	clutter_actor_set_opacity(m_progressC, OPACITY_100);
	clutter_actor_add_child(m_progressP, m_progressC);
	
	m_progressN = clutter_actor_new();
	clutter_actor_set_x(m_progressN, 0);
	clutter_actor_set_opacity(m_progressN, 0);
	clutter_actor_add_child(m_progressP, m_progressN);

	m_parent = parent;
	clutter_actor_add_child(parent, m_dim);
	clutter_actor_set_child_at_index(parent, m_dim, CONTENT_DIM_INDEX);
	
	clutter_actor_add_child(m_dim, m_progressP);
	clutter_actor_set_child_at_index(m_dim, m_progressP, 0);
	m_progress = 0;
	
}

ClutterActor* ProgressController::returnParentActor()
{
	return m_parent;
}

ClutterActor* ProgressController::returnProgressRootActor()
{
	return m_dim;
}

ClutterActor* ProgressController::getProgressP()
{
	return m_progressP;
}

ClutterActor* ProgressController::getProgressC()
{
	return m_progressC;
}


ClutterActor* ProgressController::getProgressN()
{
	return m_progressN;
}

void ProgressController::setProgress(gfloat value)
{
	clutter_actor_set_x(m_progressN, value);
	m_progress = value;
}

void ProgressController::setDim(bool flag)
{
	ClutterColor dimColor = {0, 0, 0, 153};
	ClutterColor zeroColor = {0, 0, 0, 0};

	if(flag){
		clutter_actor_set_background_color(m_dim, &dimColor);
	}else{
		clutter_actor_set_background_color(m_dim, &zeroColor);
	}
}

gfloat ProgressController::returnProgress()
{
	return m_progress;
}

void ProgressController::insertProgressController(ClutterActor* actor, ProgressController* progressCtlInc)
{
	progressMap.insert(std::pair<ClutterActor*, ProgressController*>(actor, progressCtlInc));	
}

ProgressController* ProgressController::findProgressController(ClutterActor* actor)
{
	ProgressController* ctr = NULL;
	std::map<ClutterActor*, ProgressController*>::iterator it = progressMap.find(actor);
	if (it != progressMap.end())
	{
		ctr = it->second;
	}

	return ctr;
}

void ProgressController::eraseProgressController(ClutterActor* actor)
{
	ProgressController* ctr = NULL;
	std::map<ClutterActor*, ProgressController*>::iterator it = progressMap.find(actor);
	if (it != progressMap.end())
	{
		ctr = it->second;
		clutter_actor_remove_child(ctr->returnParentActor(), actor);
		clutter_actor_destroy(actor); 
		progressMap.erase(it);
	}
	
	delete ctr;
	ctr = NULL;
}


void ProgressController::updateProgressFoveaStatus(ClutterActor* actor, gfloat transWidth, gfloat transHeight)
{

	ProgressController* ctr = findProgressController(actor);
	if (ctr == NULL)
	{
		return;
	}	

	ClutterActor* temp1 = ctr->returnProgressRootActor();
	clutter_actor_set_width(temp1, transWidth);

	ClutterActor* temp2 =  ctr->getProgressP();

	clutter_actor_set_width(temp2, transWidth);
	clutter_actor_set_y(temp2, transHeight - PROGRESS_HEIGHT);
	clutter_actor_set_opacity(temp2, OPACITY_100);

	ClutterActor* temp3 = clutter_actor_get_child_at_index(temp2, PROGRESS_C_INDEX);

	clutter_actor_set_width(temp3, transWidth);
	clutter_actor_set_x(temp3, transWidth * (clutter_actor_get_x(clutter_actor_get_next_sibling(temp3)) / 100 - 1));
}

void ProgressController::updateDim(ClutterActor* actor, bool flag)
{
	ProgressController* ctr = findProgressController(actor);
	if (ctr == NULL)
	{
		return;
	}	
	
	ClutterColor dimColor = {0, 0, 0, 60};
	ClutterColor zeroColor = {0, 0, 0, 60};

	if(flag){
		clutter_actor_set_background_color(ctr->returnProgressRootActor(), &dimColor);
	}else{
		clutter_actor_set_background_color(ctr->returnProgressRootActor(), &zeroColor);
	}	
}


void ProgressController::updateProgress(ClutterActor* actor, gfloat value)
{
	ProgressController* ctr = findProgressController(actor);
	if (ctr == NULL)
	{
		return;
	}

	ctr->setProgress(value);

#if 0	
	if (ctr->returnProgress() == 100)
	{
		eraseProgressController(actor);
		return;
	}
#endif
}

gfloat ProgressController::getProgressStatus(ClutterActor* actor)
{
	ProgressController* ctr = findProgressController(actor);
	if (ctr == NULL)
	{
		return -1;
	}

	return ctr->returnProgress();
}

// end shuhao.yan




