/*
 * DirIORequest.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "DirIORequest.h"
#include "FileIORequest.h"

#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

using namespace volt::util;

namespace Resource
{

FileInfo::FileInfo(std::string aName, int aSize)
  : name(aName),
    size(aSize)
{
};

DirInfo::DirInfo(std::string aName)
  : name(aName)
{
};

/******************************************************************************
 * DirIORequest
 *****************************************************************************/

const std::string DirIORequest::LOGGER_NAME = "volt.resource.directory";

// utility function used by DirIORequest::Delete().
// this is not part of DirIORequest because
// it would look dumb to have
// a static member function that shouldnt be used...

static bool DeleteInternal(std::string &path)
{
  volt::util::Logger logger("volt.resource.directory");

  DIR *dp = opendir(path.c_str());
  struct dirent *dirp = nullptr;
  struct dirent entry;

  bool result = false;
  bool isEmpty = true;

  if(dp == nullptr)
  {
    LOG_WARN(logger, "error reading directory " << path);
    return result;
  }

  while(readdir_r(dp, &entry, &dirp) == 0 and dirp != NULL)
  {
    struct stat statInfo;
    std::string name(dirp->d_name);
    std::string currentPath = path + name;

    // skip the . and .. directories
    if(name == "." or name == "..")
    {
      continue;
    }

    isEmpty = false;

    // read item information
    if(stat(currentPath.c_str(), &statInfo) == 0)
    {
      if(S_ISDIR(statInfo.st_mode))
      {
        LOG_DEBUG(logger, "deleting directory " << name);

        currentPath += "/";
        result = DeleteInternal(currentPath); // empty out the folder

        if(result)
        {
          // delete the folder
          if (rmdir(currentPath.c_str()) == -1)
          {
            LOG_DEBUG(logger, "failed to delete " << name);
            result = false;
          }
        }
      }
      else
      {
        if (unlink(currentPath.c_str()) == -1)
        {
          LOG_DEBUG(logger, "deleting file " << currentPath << " failed");
          result = false;
        }
        else
        {
          LOG_DEBUG(logger, "deleting file " << currentPath << " success");
          result = true;
        }
      }
    }

    if(not result)
    {
      LOG_DEBUG(logger, "failed to delete " << currentPath << " skipping..");
      break;
    }
  }

  // in case we have empty folder..
  if(isEmpty)
  {
    result = true;
  }

  closedir(dp);
  return result;
}

bool DirIORequest::Create(const std::string &aPath, bool recursive)
{
  std::string path = aPath;
  bool result = false;

  /* Create data directory. */
  if(recursive)
  {
    // create parent directories
    for (auto iter = path.begin(); iter != path.end(); ++iter)
    {
      /* don't care about the root (/) dir. */
      if (iter == path.begin())
      {
        continue;
      }

      if (*iter == '/')
      {
        *iter = '\0';

        // if path dont exist, create it
        if(access(path.c_str(), F_OK) != 0)
        {
          /* Log path.c_str() instead of just path since it
           * seems like using path makes it intelligently skip over null
           * character in mid-string. */
          mkdir(path.c_str(), 0777);
          result = true;
        }
        // if path do exist, check if its file or directory
        // if its file,
        else
        {
          result = IsDirectory(path);

          if(not result)
          {
            break;
          }
        }

        *iter = '/';
      }
    }

    if(result)
    {
      if(access(path.c_str(), F_OK) != 0)
      {
        result = mkdir(path.c_str(), 0777) == 0  ? true : false;
      }
      else
      {
        result = IsDirectory(path);
      }
    }
  }
  else
  {
    // try to access the parent
    std::string parent = GetParentPath(path);

    if(access(parent.c_str(), F_OK) == 0)
    {
      if(access(path.c_str(), F_OK) != 0)
      {
        result = mkdir(path.c_str(), 0777) == 0  ? true : false;
      }
      else
      {
        result = IsDirectory(path);
      }
    }
  }

  return result;
}

bool ReadInternal(DirInfo &info, const std::string &parentPath, bool recursive)
{
  volt::util::Logger logger("volt.resource.directory");

  DIR *dp = opendir(parentPath.c_str());
  struct dirent *dirp = nullptr;
  struct dirent entry;

  if(dp == nullptr)
  {
    LOG_WARN(logger, "error opening directory " << parentPath);
    return false;
  }

  while(readdir_r(dp, &entry, &dirp) == 0 and dirp != NULL)
  {
    struct stat statInfo;
    std::string name(dirp->d_name);
    std::string target = parentPath + "/" + name;

    // skip the . and .. directories
    if(name == "." or name == "..")
    {
      continue;
    }

    // read item information
    if(stat(target.c_str(), &statInfo) == 0)
    {
      if(S_ISDIR(statInfo.st_mode))
      {
        LOG_DEBUG(logger, "reading directory " << target);
        info.directories.push_back(DirInfo(name));

        if(recursive)
        {
          size_t size = info.directories.size();
          bool result = ReadInternal(info.directories[size - 1], target, recursive);

          if(not result)
          {
            closedir(dp);
            return false;
          }
        }
      }
      else
      {
        LOG_DEBUG(logger, "reading file " << name);
        info.files.push_back(FileInfo(name, (int)statInfo.st_size));
      }
    }
    else
    {
      LOG_DEBUG(logger, "failed to stat " << name << " skipping..");
    }
  }

  closedir(dp);
  return true;
}

DirIORequest::DirIORequest(const std::string &aUri)
  : IORequest(aUri), logger_(LOGGER_NAME),
    is_valid_path_(false),
    path_(),
    permission_(PERM_NO_ACCESS), info_("")
{
  LOG_DEBUG(logger_, "Born: " << uri());

  if (uri().compare(0, 6, "dir://") != 0)
  {
    set_uri(std::string("dir://") + uri());
  }

  if ((permission_ = FileIORequest::VoltPath(uri(), path_)) != PERM_NO_ACCESS)
  {
    is_valid_path_ = IsDirectory(path_);
  }

  // append a "/" so we dont need to do it elsewhere..
  size_t length = path_.length();
  size_t slash = path_.find_last_of('/');

  if(length > 0
     and slash != length - 1)
  {
    path_ += "/";
  }
}

DirIORequest::~DirIORequest()
{
  LOG_DEBUG(logger_, "Dead(" << id() << "): " << uri());
}


void DirIORequest::InitResponse()
{
  IORequest::InitResponse();
  response()->set_source(IOResponse::SOURCE_DIRECTORY);
}

bool DirIORequest::Execute()
{
  response()->set_status(400);
  response()->set_reason_string("Bad request");
  set_response_type(RESPONSE_STRING);

  // failed right away if path contains ".."
  if(uri().find("..") != std::string::npos)
  {
    LOG_ERROR(logger_, "uri contains \"..\", please dont try to be fancy :) ");
    return false;
  }

  switch (method())
  {
  case METHOD_GET:

    if(not is_valid_path_)
    {
      return false;
    }

    return ExecuteRead();

  case METHOD_PUT: /* fallthru */
  case METHOD_POST:
    return ExecuteCreate();

  case METHOD_DELETE:

    if(not is_valid_path_)
    {
      return false;
    }

    return ExecuteDelete();

  default:
    return false;
  }

  return false;
}

bool DirIORequest::ExecuteCreate()
{
  bool result = false;

  result = Create(path(), recursive());

  if(result)
  {
    response()->set_status(200);
    response()->set_reason_string("OK");
  }

  return result;
}

bool DirIORequest::ExecuteDelete()
{
  LOG_DEBUG(logger_, "Deleting directory: " << path());

  response()->set_status(403);
  response()->set_reason_string("Forbidden");

  bool result = false;

  if ((permission_ & PERM_W) == 0)
  {
    LOG_WARN(logger_, "Not permitted to delete " << path());
    return result;
  }

  result = Delete(path(), recursive());

  if(result)
  {
    response()->set_status(200);
    response()->set_reason_string("OK");
  }
  else
  {
    response()->set_status(404);
    response()->set_reason_string("Failed to delete directory");
  }

  return result;
}

bool DirIORequest::IsValid() const
{
  // this need to be always true
  // if we return the valid flag here
  // we will run into issue where the path does not
  // exist and we are trying to create..
  return true;
}

const DirInfo *DirIORequest::GetDirectoryInfo() const
{
  return &info_;
}

bool DirIORequest::IsDirectory(std::string &path)
{
  volt::util::Logger logger(LOGGER_NAME);

  DIR *dp = opendir(path.c_str());
  struct dirent *dirp = nullptr;
  struct dirent entry;
  bool result = false;
  struct stat statInfo;

  if(dp == nullptr)
  {
    LOG_WARN(logger, "error opening directory " << path);
    return result;
  }

  if(readdir_r(dp, &entry, &dirp) == 0 and dirp != nullptr
     and stat(path.c_str(), &statInfo) == 0
     and S_ISDIR(statInfo.st_mode))
  {
    result = true;
  }
  else
  {
    LOG_DEBUG(logger, path << " does not exist");
  }

  closedir (dp);
  return result;
}

std::string DirIORequest::GetParentPath(std::string &path)
{
  volt::util::Logger logger(LOGGER_NAME);

  std::string parent = "";
  size_t length = path.length();
  size_t last_slash = path.find_last_of("/");

  if(length <= 1  // path too short
     or last_slash == std::string::npos // when not found
     or last_slash == 0) // exclude "/" case
  {
    LOG_DEBUG(logger, "unable to resolve parent for " << path);
    return parent;
  }

  // if last slash occurred at last character, trim it and find another
  if(last_slash == length - 1)
  {
    parent = path.substr(0, length - 2);
    last_slash = parent.find_last_of("/");
  }
  else
  {
    parent = path;
  }

  parent.erase(last_slash);

  LOG_DEBUG(logger, "path: " << path << ", parent: " << parent);

  return parent;
}

bool DirIORequest::ExecuteRead()
{
  LOG_DEBUG(logger_, "Reading directory: " << path());
  response()->set_status(403);
  response()->set_reason_string("Forbidden");
  response()->set_type("directory");
  set_response_type(RESPONSE_DIRECTORY);

  bool result = false;

  if ((permission_ & PERM_R) == 0)
  {
    LOG_WARN(logger_, "Not permitted to read " << path());
    return result;
  }

  result = Read(info_, path(), recursive());

  if(result)
  {
    response()->set_status(200);
    response()->set_reason_string("OK");
  }

  return result;
}

bool DirIORequest::Read(DirInfo &info, const std::string &path, bool recursive)
{
  volt::util::Logger logger("volt.resource.directory");

  // extract primary directory name before we proceed..
  std::string dirPath = path;
  size_t pathLength = dirPath.length();
  size_t position = dirPath.find_last_of("/");
  bool result = false;

  if(position != std::string::npos)
  {
    if(position == pathLength - 1)
    {
      size_t position2 = dirPath.find_last_of("/", pathLength- 2);

      if(position2 != std::string::npos)
      {
        info.name  = dirPath.substr(position2 + 1, position - 1 - position2);
        dirPath.erase(dirPath.end() - 1);
        result = true;
      }
      else
      {
        LOG_ERROR(logger, "Why is there are only one slash in this path? " << dirPath);
        result = false;
      }
    }
    else
    {
      info.name  = dirPath.substr(position + 1);
      result = true;
    }
  }

  if(result and info.name.length() == 0)
  {
    LOG_ERROR(logger, "can not extract directory name from " << dirPath);
    result = false;
  }

  if(result)
  {
    LOG_DEBUG(logger, "directory name set to " << info.name);
    result = ReadInternal(info, dirPath, recursive);
  }

  return result;
}

bool DirIORequest::Delete(const std::string &aPath, bool recursive)
{
  volt::util::Logger logger(LOGGER_NAME);

  int status = 0;
  std::string path = aPath;

  // delete all sub directories and files
  if(recursive)
  {
    if(not DeleteInternal(path))
    {
      LOG_ERROR(logger, "Failed to delete directory recursively: " << path);
      return false;
    }
  }

  // delete directory defined by path
  if ((status = rmdir(path.c_str())) == -1)
  {
    if (access(path.c_str(), F_OK) != 0)
    {
      LOG_ERROR(logger, "Directory not found, failed delete: " << path);
    }
    else
    {
      LOG_ERROR(logger, "Directory not empty, failed delete: " << path);
    }

    return false;
  }

  return true;
}

} /* namespace Resource */
