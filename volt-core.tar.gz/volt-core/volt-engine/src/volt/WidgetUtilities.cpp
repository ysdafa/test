#include "WidgetUtilities.h"

namespace volt
{
namespace graphics
{

GValue GValueConversion::getGValue(WidgetPropertyType type, float theValue)
{
  GValue value = G_VALUE_INIT;

  switch (type)
  {
  case Byte:
    g_value_init(&value, G_TYPE_UINT);
    g_value_set_uint(&value, (int)(theValue));
    break;
  case Scaler:
    g_value_init(&value, G_TYPE_FLOAT);
    g_value_set_float(&value, theValue);
    break;
  default:
    break;
  }

  return value;
}

GValue GValueConversion::getGValue(Vector2 theValue)
{
  GValue value = G_VALUE_INIT;
  g_value_init(&value, CLUTTER_TYPE_POINT);
  ClutterPoint point = {(float)theValue.x, (float)theValue.y};
  g_value_set_boxed(&value, &point);
  return value;
}

GValue GValueConversion::getGValue(Vector3 theValue)
{
  GValue value = G_VALUE_INIT;
  g_value_init(&value, CLUTTER_TYPE_VERTEX);
  ClutterVertex point = {(float)theValue.x, (float)theValue.y, (float)theValue.z};
  g_value_set_boxed(&value, &point);
  return value;
}

GValue GValueConversion::getGValue(Color color)
{
  GValue value = G_VALUE_INIT;
  g_value_init(&value, CLUTTER_TYPE_COLOR);
  ClutterColor ccolor = {color.r, color.g, color.b, color.a};
  g_value_set_boxed(&value, &ccolor);
  return value;
}

double GValueConversion::decodeGValue(GValue value, WidgetPropertyType type)
{
  switch (type)
  {
  case Byte:
    return g_value_get_uint(&value);
  case Scaler:
    return g_value_get_float(&value);
  default:
    return 0;
  }
}

Vector2 GValueConversion::decode2DGValue(GValue value)
{
  ClutterPoint* point = (ClutterPoint*)g_value_get_boxed(&value);
  return Vector2(point->x, point->y);
}

Vector3 GValueConversion::decode3DGValue(GValue value)
{
  ClutterVertex* point = (ClutterVertex*)g_value_get_boxed(&value);
  return Vector3(point->x, point->y, point->z);
}

Color GValueConversion::decodeColorGValue(GValue value)
{
  ClutterColor* color = (ClutterColor*)g_value_get_boxed(&value);
  return Color(*color);
}

};
};
