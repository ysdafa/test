/*
 * SceneRoot.cpp
 *
 *  Created on: Jun 21, 2013
 *      Author: reza
 */

#include "SceneRoot.h"
#include "VoltActor.h"

namespace volt
{
namespace graphics
{

ClutterTimeline* SceneRoot::tickTimeline = nullptr;
uint SceneRoot::tickEventCount = 0;

SceneRoot::SceneRoot(ClutterActor* stage, int width, int height, double xScale, double yScale) :stage(stage)
{
  actor = volt_actor_new();
  g_object_ref(actor);

  clutter_actor_set_position(actor, 0, 0);

  if (width <= 0)
  {
    width = clutter_actor_get_width(stage);
  }

  if (height <= 0)
  {
    height = clutter_actor_get_height(stage);
  }

  volt_actor_set_width(VOLT_ACTOR(actor), width);
  volt_actor_set_height(VOLT_ACTOR(actor), height);

  clutter_actor_set_scale(actor, xScale, yScale);

  clutter_actor_queue_redraw(actor);

  clutter_actor_add_child(stage, actor);

  //register global listener for mouse release events. These events will handle clearing the last clicked flag.
  g_signal_connect(stage, "button-release-event", G_CALLBACK(onGlobalMouseRelease), this);

  //register for key and focus events
  g_signal_connect(actor, "key-focus-out", (GCallback)onFocusOutEvent, this);
  g_signal_connect(actor, "key-focus-in", (GCallback)onFocusInEvent, this);
  g_signal_connect(actor, "key-press-event", (GCallback)onKeyEvent, this);
  g_signal_connect(actor, "key-release-event", (GCallback)onKeyEvent, this);

  clutter_actor_show(actor);

  //Setup an indefinitely repeating timeline with which to receive frame update events.
  if (!tickTimeline)
  {
    tickTimeline = clutter_timeline_new(1000);
    clutter_timeline_set_repeat_count(tickTimeline, -1);
  }
}


SceneRoot::~SceneRoot()
{
  if (tickTimeline)
  {
    clutter_timeline_stop(tickTimeline);
    g_object_unref(tickTimeline);
  }

}


float SceneRoot::getWidth() const
{
  return clutter_actor_get_width(actor);
}

void SceneRoot::setWidth(float width)
{
  return clutter_actor_set_width(actor, width);
}

float SceneRoot::getHeight() const
{
  return clutter_actor_get_height(actor);
}

void SceneRoot::setHeight(float height)
{
  return clutter_actor_set_height(actor, height);
}

Vector2 SceneRoot::getScale() const
{
  return Vector2(1,1);
}

Color SceneRoot::getColor() const
{
  ClutterColor color;
  clutter_actor_get_background_color(stage, &color);
  return Color(color);
}

void SceneRoot::setColor(const Color& color)
{
  clutter_actor_set_background_color(stage, color.toClutterColor());
}

namespace
{
gboolean setOrtho(gpointer stage)
{
  //Convert to orthographic projection
  ClutterPerspective perspective;
  clutter_stage_get_perspective(CLUTTER_STAGE(stage), &perspective);
  clutter_stage_set_perspective(CLUTTER_STAGE(stage), &perspective); //turn off clutter auto adjusting projection

  //This hardcoded value works to compensate for the transformation used by clutter to "position" the scene.
  //Clutter does this to give the illusion of a 2D surface with screen width and height dimensions within the
  //perspective projection. This works for all tested varients in volt, but it would be better to calculate the
  //right value directly from the current projection
  float wHeight = 2.9;

  float wWidth = wHeight * perspective.aspect;
  cogl_ortho(-wWidth, wWidth, -wHeight, wHeight, perspective.z_near, perspective.z_far);
  clutter_actor_queue_redraw(CLUTTER_ACTOR(stage));
  return false;
}
}

void SceneRoot::useOrthographicProjection()
{
  //Force setOrtho to be called after the first draw. Not sure why this was necessary,
  //we should investigate this when there is time.
  clutter_threads_add_idle(setOrtho, stage);
}

//Focus system

Widget* SceneRoot::getKeyFocus() const
{
  return focusedWidget;
}

void SceneRoot::setKeyFocus(Widget* newFocus)
{
  if (!newFocus)
  {
    clearKeyFocus();
    return;
  }

  focusedWidget = newFocus;
  clutter_stage_set_key_focus(CLUTTER_STAGE(stage), newFocus->getAnimationActor());
}

void SceneRoot::clearKeyFocus()
{
  focusedWidget = nullptr;
  clutter_stage_set_key_focus(CLUTTER_STAGE(stage), nullptr);
}

const std::string& SceneRoot::getWidgetTypeString() const
{
  static const std::string type("SceneRoot");
  return type;
}

void SceneRoot::writeSceneGraphExtraJson(std::ostream &aOut, const std::string aIndent) const
{
  auto stage_width = clutter_actor_get_width(stage);
  auto stage_height = clutter_actor_get_height(stage);

  aOut << aIndent << "\"stage\":" << std::endl
       << aIndent << "{" << std::endl
       << aIndent << "  \"address\": \"" << stage << "\"," << std::endl
       << aIndent << "  \"size\": { \"width\": " << stage_width << ", \"height\": " << stage_height << " }" << std::endl
       << aIndent << "}," << std::endl;
}

TickCallbackID SceneRoot::registerTick(Tick tickCallback, void* userData)
{
  TickCallbackID id = g_signal_connect(tickTimeline, "new-frame",
                                    (GCallback)tickCallback, userData);
  if (tickEventCount == 0)
  {
    clutter_timeline_start(tickTimeline);
  }
  ++tickEventCount; 
  return id;
}

void SceneRoot::unregisterTick(TickCallbackID id)
{
  g_signal_handler_disconnect(tickTimeline, id);
  --tickEventCount;
  if (tickEventCount == 0)
  {
    clutter_timeline_stop(tickTimeline);
  }
}

};
};
