/*
* VoltActor.cpp
*
*  Created on: July 17, 2013
*      Author: jim dinunzio
*/

#define CLUTTER_ENABLE_EXPERIMENTAL_API
#define COGL_ENABLE_EXPERIMENTAL_API

#include <stdlib.h>
#include <math.h>
#include <gobject/gvaluecollector.h>

#include "VoltActor.h"
#include "VoltImage.h"
#include "st-shadow.h"
#include "clutter/clutter-marshal.h"

#ifdef CLUTTER_ENABLE_DEBUG
#include "clutter-debug.h"
#endif

#ifdef ENABLE_ARM_STREAMLINE
#include "streamline_annotate.h"
#endif

//@Render_Thread Added for memcpy by devraj.singh
#include<cstring>
/**
 * SECTION:VoltActor
 * @short_description: Volt libray clutter actor
 *
 * A clutter actor with modifications for Volt.
 *
 * 1) allows prevention of painting of the root actor (i.e.
 * itself but not its children) that would be done through the
 * paint_node routine.
 */

G_DEFINE_TYPE (VoltActor, volt_actor, CLUTTER_TYPE_ACTOR);

/* enumerates property identifiers for this class;
 * note that property identifiers should be non-zero integers,
 * so we add an unused PROP_0 to occupy the 0 position in the enum
 */
enum
{
  PROP_0,

  // continue with the private PROP enums
  PROP_ROUNDED_CORNERS = VOLT_ACTOR_PROP_LAST_PUBLIC,
  PROP_RC_COLOR,
  PROP_BORDER_COLOR,
  PROP_BORDER_WIDTH,
  PROP_ANCHOR_X,
  PROP_ANCHOR_Y,
  PROP_ORIGIN_X,
  PROP_ORIGIN_Y,
  PROP_VOLT_WIDTH,
  PROP_VOLT_HEIGHT,
  PROP_GRADIENT_FILL,
  PROP_GRAD_TL_COLOR,
  PROP_GRAD_TR_COLOR,
  PROP_GRAD_BR_COLOR,
  PROP_GRAD_BL_COLOR,
  PROP_SHADOW_X_OFFSET,
  PROP_SHADOW_Y_OFFSET,
  PROP_SHADOW_BLUR,
  PROP_SHADOW_SPREAD,
  PROP_SHADOW_COLOR,
  PROP_TRANSFORMED_DEPTH,
  PROP_LAST
};


/* enumerates signal identifiers for this class;
 * LAST_SIGNAL is not used as a signal identifier, but is instead
 * used to delineate the size of the cache array for signals (see below)
 */
enum
{
  CHILDREN_DEPTHS_CHANGED,

  LAST_SIGNAL
};

static guint volt_actor_signals[LAST_SIGNAL] = { 0, };

static const ClutterColor grey = { 0xaa, 0xaa, 0xaa, 0xff };

/* macro for accessing the object's private structure */
#define VOLT_ACTOR_TYPE_GET_PRIVATE(obj) \
  (G_TYPE_INSTANCE_GET_PRIVATE ((obj), VOLT_ACTOR_TYPE, VoltActorPrivate))

/* private structure - should only be accessed through the public API;
 * this is used to store member variables whose properties
 * need to be accessible from the implementation; for example, if we
 * intend to create wrapper functions which modify properties on the
 * actors composing an object, we should keep a reference to the actors
 * here
 *
 * this is also the place where other state variables go:
 * for example, you might record the current state of the button
 * (toggled on or off) or a background image
 */
struct _VoltActorPrivate
{
  gboolean rounded_corners;
  ClutterColor override_color;
  gfloat rc_radius;
  gfloat rc_bl_radius, rc_br_radius, rc_tl_radius, rc_tr_radius;
  gfloat rc_arc_step;
  gfloat rc_bl_arc_step, rc_br_arc_step, rc_tl_arc_step, rc_tr_arc_step;

  bool default_corner, custom_corner_bl, custom_corner_br, custom_corner_tl, custom_corner_tr;

  gboolean    border_set;
  CoglMaterial *border_material;
  ClutterColor  border_color;
  gfloat        border_width;

  gfloat anchor_x;
  gfloat anchor_y;

  gfloat origin_x;
  gfloat origin_y;

  gboolean gradient_fill;
  ClutterColor grad_tl_color, grad_tr_color, grad_br_color, grad_bl_color;

  void* user_data;

  CoglHandle    shadow_material;
  float         shadow_width;
  float         shadow_height;
  StShadow     *shadow_spec;
  gboolean      shadow_needs_update;

  gboolean      clip_to_shape;
  gulong        clip_to_shape_handler_id;

  gboolean      auto_sort_children_by_depth;
};

static GParamSpec *obj_props[PROP_LAST];

static void
volt_actor_dispose(GObject* gobject)
{
  VoltActorPrivate* priv = VOLT_ACTOR (gobject)->priv;
//@Render_Thread border_material is only created on copy
  if (CLUTTER_ACTOR(gobject)->is_copy && priv->border_material != COGL_INVALID_HANDLE)
  {
    cogl_handle_unref(priv->border_material);
    priv->border_material = COGL_INVALID_HANDLE;
  }
//@Render_Thread shadow_material is only created on copy
  if (CLUTTER_ACTOR(gobject)->is_copy && priv->shadow_material != COGL_INVALID_HANDLE)
  {
    cogl_handle_unref(priv->shadow_material);
    priv->shadow_material = COGL_INVALID_HANDLE;
  }

  //@Render_Thread The shadow_spec is created for both original and copy
  if (priv->shadow_spec)
  {
    st_shadow_unref(priv->shadow_spec);
    priv->shadow_spec = NULL;
  }

  /* call the parent class' dispose() method */
  G_OBJECT_CLASS (volt_actor_parent_class)->dispose (gobject);
}

/* from http://mail.gnome.org/archives/gtk-devel-list/2004-July/msg00158.html:
 *
 * "The finalize method finishes releasing the remaining
 * resources just before the object itself will be freed from memory, and
 * therefore it will only be called once. The two step process helps break
 * cyclic references. Both dispose and finalize must chain up to their
 * parent objects by calling their parent's respective methods *after* they
 * have disposed or finalized their own members."
 */
static void
volt_actor_finalize (GObject *gobject)
{
  /* call the parent class' finalize() method */
  G_OBJECT_CLASS (volt_actor_parent_class)->finalize (gobject);
}

/* enables objects to be uniformly treated as GObjects;
 * also exposes properties so they become scriptable, e.g.
 * through ClutterScript
 */
static void
volt_actor_set_property (GObject      *gobject,
                         guint         prop_id,
                         const GValue *value,
                         GParamSpec   *pspec)
{
  VoltActor *voltActor = VOLT_ACTOR (gobject);

  switch (prop_id)
  {
  case PROP_ROUNDED_CORNERS:
    volt_actor_set_rounded_corners(voltActor, g_value_get_boolean (value));
    break;

  case VOLT_ACTOR_PROP_RC_RADIUS:     /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_BL_RADIUS:  /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_BR_RADIUS:  /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_TL_RADIUS:  /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_TR_RADIUS:
    volt_actor_set_rc_radius(voltActor, g_value_get_float(value), prop_id);
    break;

  case VOLT_ACTOR_PROP_RC_ARC_STEP:     /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_BL_ARC_STEP:  /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_BR_ARC_STEP:  /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_TL_ARC_STEP:  /* FALL THROUGH */
  case VOLT_ACTOR_PROP_RC_TR_ARC_STEP:
    volt_actor_set_rc_arc_step(voltActor, g_value_get_float(value), prop_id);
    break;

  case PROP_RC_COLOR:
    volt_actor_set_override_color(voltActor, clutter_value_get_color(value));
    break;

  case PROP_BORDER_COLOR:
    volt_actor_set_border_color (voltActor, clutter_value_get_color (value));
    break;

  case PROP_BORDER_WIDTH:
    volt_actor_set_border_width (voltActor, g_value_get_float (value));
    break;

  case PROP_ANCHOR_X:
    volt_actor_set_anchor_x(voltActor, g_value_get_float (value));
    break;

  case PROP_ANCHOR_Y:
    volt_actor_set_anchor_y(voltActor, g_value_get_float (value));
    break;

  case PROP_ORIGIN_X:
    volt_actor_set_origin_x(voltActor, g_value_get_float (value));
    break;

  case PROP_ORIGIN_Y:
    volt_actor_set_origin_y(voltActor, g_value_get_float (value));
    break;

  case PROP_VOLT_WIDTH:
    volt_actor_set_width(voltActor, g_value_get_float (value));
    break;

  case PROP_VOLT_HEIGHT:
    volt_actor_set_height(voltActor, g_value_get_float (value));
    break;

  case PROP_GRADIENT_FILL:
    volt_actor_set_gradient_fill(voltActor, g_value_get_boolean (value));
    break;

  case PROP_GRAD_TL_COLOR:
    volt_actor_set_grad_tl_color(voltActor, clutter_value_get_color (value));
    break;

  case PROP_GRAD_TR_COLOR:
    volt_actor_set_grad_tr_color(voltActor, clutter_value_get_color (value));
    break;

  case PROP_GRAD_BL_COLOR:
    volt_actor_set_grad_bl_color(voltActor, clutter_value_get_color (value));
    break;

  case PROP_GRAD_BR_COLOR:
    volt_actor_set_grad_br_color(voltActor, clutter_value_get_color (value));
    break;

  case PROP_SHADOW_X_OFFSET:
    volt_actor_set_shadow_h(voltActor, g_value_get_float (value));
    break;

  case PROP_SHADOW_Y_OFFSET:
    volt_actor_set_shadow_v(voltActor, g_value_get_float (value));
    break;

  case PROP_SHADOW_BLUR:
    volt_actor_set_shadow_blur(voltActor, g_value_get_float(value));
    break;

  case PROP_SHADOW_SPREAD:
    volt_actor_set_shadow_spread(voltActor, g_value_get_float(value));
    break;

  case PROP_SHADOW_COLOR:
    volt_actor_set_shadow_color(voltActor, clutter_value_get_color (value));
    break;

  default:
    G_OBJECT_WARN_INVALID_PROPERTY_ID (gobject, prop_id, pspec);
    break;
  }
}

/* enables objects to be uniformly treated as GObjects */
static void
volt_actor_get_property (GObject    *gobject,
                         guint       prop_id,
                         GValue     *value,
                         GParamSpec *pspec)
{
  VoltActorPrivate *priv = VOLT_ACTOR (gobject)->priv;

  switch (prop_id)
  {
  case PROP_ROUNDED_CORNERS:
    g_value_set_boolean(value, priv->rounded_corners);
    break;

  case VOLT_ACTOR_PROP_RC_RADIUS:
    g_value_set_float(value, priv->rc_radius);
    break;

  case VOLT_ACTOR_PROP_RC_BL_RADIUS:
    g_value_set_float(value, priv->rc_bl_radius);
    break;

  case VOLT_ACTOR_PROP_RC_BR_RADIUS:
    g_value_set_float(value, priv->rc_br_radius);
    break;

  case VOLT_ACTOR_PROP_RC_TL_RADIUS:
    g_value_set_float(value, priv->rc_tl_radius);
    break;

  case VOLT_ACTOR_PROP_RC_TR_RADIUS:
    g_value_set_float(value, priv->rc_tr_radius);
    break;

  case VOLT_ACTOR_PROP_RC_ARC_STEP:
    g_value_set_float(value, priv->rc_arc_step);
    break;

  case VOLT_ACTOR_PROP_RC_BL_ARC_STEP:
    g_value_set_float(value, priv->rc_bl_arc_step);
    break;

  case VOLT_ACTOR_PROP_RC_BR_ARC_STEP:
    g_value_set_float(value, priv->rc_br_arc_step);
    break;

  case VOLT_ACTOR_PROP_RC_TL_ARC_STEP:
    g_value_set_float(value, priv->rc_tl_arc_step);
    break;

  case VOLT_ACTOR_PROP_RC_TR_ARC_STEP:
    g_value_set_float(value, priv->rc_tr_arc_step);
    break;

  case PROP_RC_COLOR:
    clutter_value_set_color(value, &priv->override_color);
    break;

  case PROP_BORDER_COLOR:
    clutter_value_set_color(value, &priv->border_color);
    break;

  case PROP_BORDER_WIDTH:
    g_value_set_float(value, priv->border_width);
    break;

  case PROP_ANCHOR_X:
    g_value_set_float(value, priv->anchor_x);
    break;

  case PROP_ANCHOR_Y:
    g_value_set_float(value, priv->anchor_y);
    break;

  case PROP_ORIGIN_X:
    g_value_set_float(value, priv->origin_x);
    break;

  case PROP_ORIGIN_Y:
    g_value_set_float(value, priv->origin_y);
    break;

  case PROP_VOLT_WIDTH:
    g_value_set_float(value, volt_actor_get_width(VOLT_ACTOR(gobject)));
    break;

  case PROP_VOLT_HEIGHT:
    g_value_set_float(value, volt_actor_get_height(VOLT_ACTOR(gobject)));
    break;

  case PROP_GRADIENT_FILL:
    g_value_set_boolean(value, priv->gradient_fill);
    break;

  case PROP_GRAD_TL_COLOR:
    clutter_value_set_color(value, &priv->grad_tl_color);
    break;

  case PROP_GRAD_TR_COLOR:
    clutter_value_set_color(value, &priv->grad_tr_color);
    break;

  case PROP_GRAD_BL_COLOR:
    clutter_value_set_color(value, &priv->grad_bl_color);
    break;

  case PROP_GRAD_BR_COLOR:
    clutter_value_set_color(value, &priv->grad_br_color);
    break;

  case PROP_SHADOW_X_OFFSET:
    g_value_set_float(value, volt_actor_get_shadow_h(VOLT_ACTOR(gobject)));
    break;

  case PROP_SHADOW_Y_OFFSET:
    g_value_set_float(value, volt_actor_get_shadow_v(VOLT_ACTOR(gobject)));
    break;

  case PROP_SHADOW_BLUR:
    g_value_set_float(value, volt_actor_get_shadow_blur(VOLT_ACTOR(gobject)));
    break;

  case PROP_SHADOW_SPREAD:
    g_value_set_float(value, volt_actor_get_shadow_spread(VOLT_ACTOR(gobject)));
    break;

  case PROP_SHADOW_COLOR:
  {
    ClutterColor color;
    volt_actor_get_shadow_color(VOLT_ACTOR(gobject), &color);
    clutter_value_set_color(value, &color);
  }
  break;

  case PROP_TRANSFORMED_DEPTH:
    g_value_set_float(value, volt_actor_get_transformed_depth(VOLT_ACTOR(gobject)));
    break;

  default:
    G_OBJECT_WARN_INVALID_PROPERTY_ID(gobject, prop_id, pspec);
    break;
  }
}

/* ClutterActor implementation
 *
 */

// The borders and shadows are drawn outside the actor's area.  Thus it is necessary to enlarge the actor's
// size and change the position (to change its allocation).
static gboolean
volt_actor_get_paint_volume(ClutterActor *actor,
                            ClutterPaintVolume *volume)
{
  gfloat width, height;
  ClutterVertex origin;

  VoltActorPrivate *priv = VOLT_ACTOR(actor)->priv;
  gboolean result = CLUTTER_ACTOR_CLASS(volt_actor_parent_class)->get_paint_volume(actor, volume);

  clutter_paint_volume_get_origin(volume, &origin);
  width = clutter_paint_volume_get_width(volume);
  height = clutter_paint_volume_get_height(volume);

  if (priv->border_set &&
      !clutter_color_equal(&priv->border_color, CLUTTER_COLOR_Transparent))
  {
    width += 2 * priv->border_width;
    height += 2 * priv->border_width;
    origin.x -= priv->border_width;
    origin.y -= priv->border_width;
    result = TRUE;
  }

  // enlarge for shadows if not transparent
  if (priv->shadow_spec &&
      !clutter_color_equal(&priv->shadow_spec->color, CLUTTER_COLOR_Transparent))
  {
    width += fabs(priv->shadow_spec->xoffset) + priv->shadow_spec->spread;
    height += fabs(priv->shadow_spec->yoffset) + priv->shadow_spec->spread;

    if (priv->shadow_spec->xoffset < 0)
    {
      origin.x += priv->shadow_spec->xoffset - priv->shadow_spec->spread;
    }

    if (priv->shadow_spec->yoffset < 0)
    {
      origin.y += priv->shadow_spec->yoffset - priv->shadow_spec->spread;
    }

    result = TRUE;
  }

  clutter_paint_volume_set_width(volume, width);
  clutter_paint_volume_set_height(volume, height);
  clutter_paint_volume_set_origin(volume, &origin);

  return result;
}

// Note this routine paints directly on the screen as opposed to creating
// a render node and adding it to the render tree because a previous attempt
// to do so did not work with depth testing.
static void
gradient_fill_paint_gradient(VoltActor *voltActor)
{
  ClutterActorBox box;
  guint8 paint_opacity;
  VoltActorPrivate *priv = voltActor->priv;
  ClutterActor *actor = CLUTTER_ACTOR(voltActor);

  paint_opacity = clutter_actor_get_paint_opacity (actor);

  clutter_actor_get_content_box (actor, &box);

  if (priv->rounded_corners)
  {
    gfloat width, height;
    ClutterActorBox allocation = { 0, };

    clutter_actor_get_allocation_box(actor, &allocation);
    clutter_actor_box_get_size(&allocation, &width, &height);

    cogl_path_new();

    // build custom rounded corner if any corner has been set before
    if (volt_actor_has_custom_corner(voltActor))
    {
      volt_actor_custom_rounded_rect(voltActor, 0, 0, width, height, 0, false);
    }
    // use standard rounded corners
    else
    {
      cogl_path_round_rectangle(0, 0, width, height,
                                volt_actor_get_rc_radius(voltActor, VOLT_ACTOR_PROP_RC_RADIUS),
                                volt_actor_get_rc_arc_step(voltActor, VOLT_ACTOR_PROP_RC_ARC_STEP));
    }

    cogl_clip_push_from_path();
  }

  // set up the quad (a two triangle strip)
  CoglTextureVertex quad[4];
  quad[0].x = box.x1;
  quad[0].y = box.y1;
  quad[0].z = 0;
  quad[0].tx = 0;
  quad[0].ty = 0;
  cogl_color_init_from_4ub(&quad[0].color, priv->grad_tl_color.red, priv->grad_tl_color.green,
                           priv->grad_tl_color.blue, priv->grad_tl_color.alpha * paint_opacity / 255);
  quad[1].x = box.x2;
  quad[1].y = box.y1;
  quad[1].z = 0;
  quad[1].tx = 1.0;
  quad[1].ty = 0;
  cogl_color_init_from_4ub(&quad[1].color, priv->grad_tr_color.red, priv->grad_tr_color.green,
                           priv->grad_tr_color.blue, priv->grad_tr_color.alpha * paint_opacity / 255);

  quad[2].x = box.x2;
  quad[2].y = box.y2;
  quad[2].z = 0;
  quad[2].tx = 1.0;
  quad[2].ty = 1.0;
  cogl_color_init_from_4ub(&quad[2].color, priv->grad_br_color.red, priv->grad_br_color.green,
                           priv->grad_br_color.blue, priv->grad_br_color.alpha * paint_opacity / 255);

  quad[3].x = box.x1;
  quad[3].y = box.y2;
  quad[3].z = 0;
  quad[3].tx = 0;
  quad[3].ty = 1.0;
  cogl_color_init_from_4ub(&quad[3].color, priv->grad_bl_color.red, priv->grad_bl_color.green,
                           priv->grad_bl_color.blue, priv->grad_bl_color.alpha * paint_opacity / 255);

  cogl_polygon(quad, 4, TRUE);

  if (priv->rounded_corners)
  {
    cogl_clip_pop();
  }
}

static void
volt_actor_paint_borders(VoltActor *voltActor, int width, int height, bool useBorderMat = true)
{
  VoltActorPrivate *priv = voltActor->priv;
  ClutterActor *actor = CLUTTER_ACTOR(voltActor);

  // Border drawing code
  if (priv->border_set &&
      !clutter_color_equal(&priv->border_color, CLUTTER_COLOR_Transparent))
  {
    guint8 paint_opacity;

		// set the opacity of the border based on the actor's opacity.
		// tbd: should this be an optional feature?
		if (useBorderMat)
		{
			paint_opacity = clutter_actor_get_paint_opacity(actor);
			paint_opacity = clutter_actor_get_paint_opacity(actor);

      CoglColor pre_multiplied_color = {
        (guint8)((priv->border_color.red    * paint_opacity + 128)/255),
        (guint8)((priv->border_color.green  * paint_opacity + 128)/255),
        (guint8)((priv->border_color.blue   * paint_opacity + 128)/255),
        (guint8)((priv->border_color.alpha  * paint_opacity + 128)/255)
      };

      cogl_color_premultiply(&pre_multiplied_color);

      cogl_material_set_color(priv->border_material, &pre_multiplied_color);

      cogl_push_source(priv->border_material);
    }

    // Does Actor have rounded corners.  if so use a border with rounded corners.
    cogl_path_new();

    // we need to know the radius of the rounded rectangle to make the border match the actor's
    // rounded corners shape.  The border's outer edge must have a radius = the actor's corner arcs
    // radius + the width of the border.
    if (priv->rounded_corners)
    {
      // build custom rounded corner if any corner has been set before
      if(volt_actor_has_custom_corner(voltActor))
      {
        volt_actor_custom_rounded_rect(voltActor, 0, 0, width, height, priv->border_width, false);
      }
      // use standard rounded corners
      else
      {
        // draw inner rounded rect edge of border (will not fill due to even/odd rule after next line)
        cogl_path_round_rectangle(0, 0,
                                  width,
                                  height,
                                  volt_actor_get_rc_radius(voltActor, VOLT_ACTOR_PROP_RC_RADIUS),
                                  volt_actor_get_rc_arc_step(voltActor, VOLT_ACTOR_PROP_RC_ARC_STEP));

        // draw outer rounded corners edge of border (will fill between two rounded rects)
        cogl_path_round_rectangle(-priv->border_width, -priv->border_width,
                                  width + priv->border_width,
                                  height + priv->border_width,
                                  volt_actor_get_rc_radius(voltActor, VOLT_ACTOR_PROP_RC_RADIUS) + priv->border_width,
                                  volt_actor_get_rc_arc_step(voltActor, VOLT_ACTOR_PROP_RC_ARC_STEP));
      }
    }
    else // not rounded, use the normal rectangular borders.
    {
      /* draw Cogl rectangles on top */

      /* left rectangle */
      cogl_path_rectangle(-priv->border_width, -priv->border_width, 0, height + priv->border_width);

      /* top rectangle */
      cogl_path_rectangle(0, -priv->border_width, width + priv->border_width, 0);

      /* right rectangle */
      cogl_path_rectangle(width, 0, width + priv->border_width, height + priv->border_width);

      /* bottom rectangle */
      cogl_path_rectangle(0,
                          height,
                          width,
                          height + priv->border_width);

    }

    cogl_path_fill();

    if (useBorderMat)
    {
      cogl_pop_source();
    }
  }
}

void
volt_actor_draw_path_footprint(VoltActor *voltActor)
{
  VoltActorPrivate *priv = voltActor->priv;
  ClutterActorBox allocation;

  clutter_actor_get_allocation_box(CLUTTER_ACTOR(voltActor), &allocation);

  ClutterVertex localPos;
  localPos.x = -priv->border_width;
  localPos.y = -priv->border_width;
  localPos.z = 0;
  ClutterVertex stagePos, stageBR;
  ClutterActor* stage = clutter_actor_get_stage(CLUTTER_ACTOR(voltActor));
  clutter_actor_apply_relative_transform_to_point(CLUTTER_ACTOR(voltActor), stage, &localPos,
      &stagePos);
  localPos.x = clutter_actor_box_get_width (&allocation) + priv->border_width;
  localPos.y = clutter_actor_box_get_height (&allocation) + priv->border_width;
  clutter_actor_apply_relative_transform_to_point(CLUTTER_ACTOR(voltActor), stage,
      &localPos, &stageBR);
  gfloat width = stageBR.x - stagePos.x;
  gfloat height = stageBR.y - stagePos.y;

  if (priv->rounded_corners)
  {
    // add the round rectangle path
    // build custom rounded corner if any corner has been set before
    if(volt_actor_has_custom_corner(voltActor))
    {
      volt_actor_custom_rounded_rect(voltActor, stagePos.x, stagePos.y, width, height,
                                     priv->border_width, true);
    }
    // use standard rounded corners
    else
    {
      cogl_path_round_rectangle(stagePos.x, stagePos.y,
                                stageBR.x,
                                stageBR.y,
                                priv->rc_radius + priv->border_width,
                                priv->rc_arc_step);
    }
  }
  else
  {
    cogl_path_rectangle(stagePos.x, stagePos.y, stageBR.x, stageBR.y);
  }
}

/**
 * volt_actor_paint_footprint - Paints the footprint (shape) of the actor with color and current
 * opacity in actor modelview coordinates. This is used primarily to paint the shadow into an
 * offscreen buffer
 *
 * @author jim (8/4/2014)
 *
 * @param voltActor the actor instance
 */
static void
volt_actor_paint_footprint(VoltActor *voltActor)
{
  CoglMaterial *material;
  ClutterColor bg_color = *CLUTTER_COLOR_Black;
  float width, height;
  VoltActorPrivate *priv = voltActor->priv;

  clutter_actor_get_size(CLUTTER_ACTOR(voltActor), &width, &height);

  if (!VOLT_IS_IMAGE(clutter_actor_get_content(CLUTTER_ACTOR(voltActor))))
  {
    // if this is not an image, then use the background color for the shadow (mainly the alpha)
    // and there will be no shadow if the color is transparent.
    clutter_actor_get_background_color(CLUTTER_ACTOR(voltActor), &bg_color);

    if (clutter_color_equal(&bg_color, CLUTTER_COLOR_Transparent))
    {
      return;
    }
  }

  material = cogl_material_new();
  cogl_material_set_color4ub(material,
                             bg_color.red,
                             bg_color.green,
                             bg_color.blue,
                             bg_color.alpha *
                             clutter_actor_get_paint_opacity(CLUTTER_ACTOR(voltActor)) / 255);
  cogl_push_source(material);

  width += 2 * priv->border_width;
  height += 2 * priv->border_width;

  if (priv->rounded_corners)
  {
    cogl_path_new();

    // add the round rectangle path
    // build custom rounded corner if any corner has been set before
    if(volt_actor_has_custom_corner(voltActor))
    {
      volt_actor_custom_rounded_rect(voltActor, 0, 0, width, height, priv->border_width, true);
    }
    // use standard rounded corners
    else
    {
      cogl_path_round_rectangle(0, 0,
                                width,
                                height,
                                priv->rc_radius + priv->border_width,
                                priv->rc_arc_step);
    }

    // and fill it with the current color
    cogl_path_fill();
  }
  else
  {
    cogl_rectangle(0, 0, width, height);
  }

  cogl_pop_source();
  cogl_handle_unref(material);
}

static void volt_actor_push_clip_to_shape(VoltActor* self);

static void
volt_actor_paint_node (ClutterActor *actor, ClutterPaintNode *root)
{
#ifdef ENABLE_ARM_STREAMLINE
  ANNOTATE_LINE("Painting a node...");
#endif

  VoltActor* voltActor = VOLT_ACTOR (actor);
  VoltActorPrivate *priv = voltActor->priv;
  gfloat width, height;
  ClutterActorBox allocation;

  if (priv->auto_sort_children_by_depth)
  {
    // If auto sort children by depth enabled, send signal that children's depths have changed.
    // Rather than caching depths and checking whether they changed or not, which is a non
    // trivial # of cycles, we send this signal every paint cycle and rely on the higher level
    // signal handler code for caching and optimization.
    g_signal_emit(actor, volt_actor_signals[CHILDREN_DEPTHS_CHANGED], 0);
  }

  ClutterContent* content = clutter_actor_get_content(actor);

  clutter_actor_get_size (actor, &width, &height);

  //@Render_Thread update the shadow material here if shadow needs update
  if (priv->shadow_needs_update)
  {
    volt_actor_shadow_update_render_thread(voltActor);
    priv->shadow_needs_update = FALSE;
  }

	// If there is a drop shadow, draw it taking into account borders
	if (priv->shadow_spec && priv->shadow_material)
	{
		// To make the shadow stay behind the object when depth testing is enabled,
		// translate it a smidge into the screen.
		cogl_push_matrix();
		cogl_translate(0.0, 0.0, -0.01);
		allocation.x1 = priv->border_set ? -priv->border_width : 0;
		allocation.y1 = allocation.x1;
		allocation.x2 = allocation.x1 + priv->shadow_width;
		allocation.y2 = allocation.y1 + priv->shadow_height;

    st_paint_shadow_with_opacity(priv->shadow_spec,
                                 priv->shadow_material,
                                 &allocation,
                                 clutter_actor_get_paint_opacity(actor));
    cogl_pop_matrix();
  }

  // Solid fill code for Rounded Corners option
  // Because the parent class' clutter_actor_paint_node() routine paints the background
  // color (if set) before calling the actor's content paint and the actor's paint_node()
  // routine we must use our own color for an actor with rounded corners, rc_color and
  // ClutterActor's background_color must be set to NULL or transparent.
  // Otherwise the corners of the rectangular color fill show up.

  if (content == NULL
      && not priv->gradient_fill
      && (priv->rounded_corners)
      && (not clutter_color_equal (&priv->override_color, CLUTTER_COLOR_Transparent)))
  {
    ClutterPaintNode *node;
    ClutterColor color;

    color = priv->override_color;
    color.alpha = clutter_actor_get_paint_opacity (actor)
                  * priv->override_color.alpha
                  / 255;

    node = clutter_color_node_new (&color);
    clutter_paint_node_set_name (node, "solidColor");
    cogl_path_new();

    if(priv->rounded_corners)
    {
      // build custom rounded corner if any corner has been set before
      if(volt_actor_has_custom_corner(voltActor))
      {
        volt_actor_custom_rounded_rect(voltActor, 0, 0, width, height, 0, false);
      }
      // use standard rounded corners
      else
      {

        cogl_path_round_rectangle (0, 0,
                                   width,
                                   height,
                                   volt_actor_get_rc_radius(voltActor, VOLT_ACTOR_PROP_RC_RADIUS),
                                   volt_actor_get_rc_arc_step(voltActor, VOLT_ACTOR_PROP_RC_ARC_STEP));
      }
    }
    else
    {
      cogl_path_rectangle(0, 0, width, height);
    }

    CoglPath* path = cogl_get_path();
    clutter_paint_node_add_path(node, path);
    clutter_paint_node_add_child (root, node);
    clutter_paint_node_unref (node);
  }

  // Gradient fill code
  if (content == NULL && priv->gradient_fill)
  {
    gradient_fill_paint_gradient(voltActor);
  }

  volt_actor_paint_borders(voltActor, width, height);

  if (priv->clip_to_shape)
  {
    volt_actor_push_clip_to_shape(voltActor);
  }

#ifdef ENABLE_ARM_STREAMLINE
  ANNOTATE_END();
#endif
}

/* automagic interning of a static string */
#define I_(str)  (g_intern_static_string ((str)))
/**
 * volt_actor_pop_clip_to_shape: pops the clip region pushed with volt_actor_push_clip_to_shape
 *
 * @author jim (7/29/2014)
 *
 * @param self the volt actor instance
 */
static void volt_actor_pop_clip_to_shape(VoltActor* self)
{
  cogl_clip_pop();
}

/**
 * on_paint_after_clip_to_shape: used as a signal callback function for after the
 * "paint" signal to pop the clip_to_shape region after the actor's descendants are painted.
 *
 * @author jim (7/29/2014)
 *
 * @param actor the actor instance
 * @param user_data
 */
static void on_paint_after_clip_to_shape (ClutterActor *actor, gpointer user_data)
{
  g_return_if_fail(IS_VOLT_ACTOR(actor));
  volt_actor_pop_clip_to_shape(VOLT_ACTOR(actor));
}



/* GObject class and instance initialization functions; note that
 * these have been placed after the Clutter implementation, as
 * they refer to the static function implementations above
 */

/* class init: attach functions to superclasses, define properties
 * and signals
 */
 
 //@Render_Thread Added for Copying attrib from Cpu Actor to copy Actor 
 void
 volt_actor_copy_new(ClutterActor* source, ClutterActor* dest)
 {
	VoltActor* ssource	=	NULL;
	VoltActor* sdest		=	NULL;
		
	ssource = VOLT_ACTOR(source);
	sdest = VOLT_ACTOR(dest);
	
	{
    sdest->priv->rounded_corners = ssource->priv->rounded_corners;
    sdest->priv->override_color = ssource->priv->override_color;
    sdest->priv->rc_radius = ssource->priv->rc_radius;
    sdest->priv->rc_bl_radius = ssource->priv->rc_bl_radius;
    sdest->priv->rc_br_radius = ssource->priv->rc_br_radius;
    sdest->priv->rc_tl_radius = ssource->priv->rc_tl_radius;
    sdest->priv->rc_tr_radius = ssource->priv->rc_tr_radius;
    sdest->priv->rc_arc_step = ssource->priv->rc_arc_step;
    sdest->priv->rc_bl_arc_step = ssource->priv->rc_bl_arc_step;
    sdest->priv->rc_br_arc_step = ssource->priv->rc_bl_arc_step;
    sdest->priv->rc_tl_arc_step = ssource->priv->rc_tl_arc_step;
    sdest->priv->rc_tr_arc_step = ssource->priv->rc_tr_arc_step;
    sdest->priv->default_corner = ssource->priv->default_corner;
    sdest->priv->custom_corner_bl = ssource->priv->custom_corner_bl;
    sdest->priv->custom_corner_br = ssource->priv->custom_corner_br;
    sdest->priv->custom_corner_tl = ssource->priv->custom_corner_tl;
    sdest->priv->custom_corner_tr = ssource->priv->custom_corner_tr;
    sdest->priv->border_set = ssource->priv->border_set;
    //sdest->priv->border_material - this is maintained by the render thread copy only and is created below
    sdest->priv->border_color = ssource->priv->border_color;
    sdest->priv->border_width = ssource->priv->border_width;
    sdest->priv->anchor_x = ssource->priv->anchor_x;
    sdest->priv->anchor_y = ssource->priv->anchor_y;
    sdest->priv->origin_x = ssource->priv->origin_x;
    sdest->priv->origin_y = ssource->priv->origin_y;
    sdest->priv->gradient_fill = ssource->priv->gradient_fill;
    sdest->priv->grad_tl_color = ssource->priv->grad_tl_color;
    sdest->priv->grad_tr_color = ssource->priv->grad_tr_color;
    sdest->priv->grad_bl_color = ssource->priv->grad_bl_color;
    sdest->priv->grad_br_color = ssource->priv->grad_br_color;
    //sdest->priv->user_data - this is only used by update thread
    //sdest->priv->shadow_material - this is maintained by the render thread copy only 
    //sdest->priv->shadow_width - this is maintained by the render thread copy only
    //sdest->priv->shadow_height - this is maintained by the render thread copy only
    //sdest->priv->shadow_spec - a deep copy of this is done below
    sdest->priv->shadow_needs_update = ssource->priv->shadow_needs_update;
    //sdest->priv->clip_to_shape - changes to this are handled below
    //sdest->priv->clip_to_shape_handler_id - this is maintained by the render thread copy only
    //sdest->priv->auto_sort_children_by_depth - no longer used

    // Handle copying, duplicating or removing the copy of the shadow structure
    if (ssource->priv->shadow_needs_update)
    {
      if (ssource->priv->shadow_spec && sdest->priv->shadow_spec) 
      {
        st_shadow_copy_data(sdest->priv->shadow_spec, ssource->priv->shadow_spec);
      }
      else if (ssource->priv->shadow_spec && !sdest->priv->shadow_spec)
      {
        sdest->priv->shadow_spec = st_shadow_dup(ssource->priv->shadow_spec);
      }
      else if (!ssource->priv->shadow_spec && sdest->priv->shadow_spec)
      {
        st_shadow_unref(sdest->priv->shadow_spec);
        sdest->priv->shadow_spec = NULL;
        if (sdest->priv->shadow_material != COGL_INVALID_HANDLE)
        {
          cogl_handle_unref(sdest->priv->shadow_material);
          sdest->priv->shadow_material = COGL_INVALID_HANDLE;
        }
      }
      ssource->priv->shadow_needs_update = FALSE;
    }

		if (sdest->priv->clip_to_shape != ssource->priv->clip_to_shape)
	   {
		 sdest->priv->clip_to_shape = ssource->priv->clip_to_shape;
		 if ( sdest->priv->clip_to_shape  )
			{
			  // install signal handler for after the actor and its descendants are painted
			  sdest->priv->clip_to_shape_handler_id = g_signal_connect_after (sdest, "paint",
													  G_CALLBACK (on_paint_after_clip_to_shape), NULL);
			}
			else if ( sdest->priv->clip_to_shape_handler_id != 0)
			{
			  // uninstall signal handler
			  g_signal_handler_disconnect(sdest,  sdest->priv->clip_to_shape_handler_id);
			  sdest->priv->clip_to_shape_handler_id = 0;
			}
			
		}

    if (!sdest->priv->border_material)
    {
      sdest->priv->border_material = cogl_material_new();
    }
  }
	// We know group has base class cluttor Actor  // Need to copy its data also
	clutter_actor_copy_attributes_for_render_thread(source, dest);
 }
static void
volt_actor_clone_new(ClutterActor  *self)
{
	if(self->copy_actor == NULL)
	{
		self->copy_actor = volt_actor_new();
	//	printf("Creating Volt Actor\n");
	}

	volt_actor_copy_new(self, self->copy_actor);
}

static void
volt_actor_class_init (VoltActorClass *klass)
{
  ClutterActorClass *actor_class = CLUTTER_ACTOR_CLASS (klass);
  actor_class->paint_node = volt_actor_paint_node;
  actor_class->get_paint_volume = volt_actor_get_paint_volume;

  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  gobject_class->dispose = volt_actor_dispose;
  gobject_class->finalize = volt_actor_finalize;
  gobject_class->set_property = volt_actor_set_property;
  gobject_class->get_property = volt_actor_get_property;
   //@Render_Thread Added for Creating Copy
   //Actor  and Copying  attrib from Cpu Actor to copy Actor 
  actor_class->clone_for_render_thread = volt_actor_clone_new;

  g_type_class_add_private (klass, sizeof (VoltActorPrivate));

  /**
   * VoltActor
   *
   * The text shown on the #VoltActor
   */
  obj_props[PROP_ROUNDED_CORNERS] = g_param_spec_boolean ("rounded-corners",
                                    "RoundedCorners",
                                    "Whether the actor's has rounded corners",
                                    FALSE,
                                    (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_RADIUS] = g_param_spec_float("rc-radius",
                                         "RCRadius",
                                         "Corner radius for rounded corners.",
                                         0, 1000, 10.0,
                                         (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_BL_RADIUS] = g_param_spec_float("rc-bl-radius",
      "RCBLRadius",
      "Bottom Left Corner radius for rounded corners.",
      0, 1000, 10.0,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_BR_RADIUS] = g_param_spec_float("rc-br-radius",
      "RCBRRadius",
      "Bottom Right Corner radius for rounded corners.",
      0, 1000, 10.0,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_TL_RADIUS] = g_param_spec_float("rc-tl-radius",
      "RCTLRadius",
      "Top Left Corner radius for rounded corners.",
      0, 1000, 10.0,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_TR_RADIUS] = g_param_spec_float("rc-tr-radius",
      "RCTRRadius",
      "Top Right Corner radius for rounded corners.",
      0, 1000, 10.0,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_ARC_STEP] = g_param_spec_float ("rc-arc-step",
      "RCArcStep",
      "Arc step for rounded corners.",
      0, 1000, 10,
      (GParamFlags)(G_PARAM_READWRITE));


  obj_props[VOLT_ACTOR_PROP_RC_BL_ARC_STEP] = g_param_spec_float ("rc-bl-arc-step",
      "RCBLArcStep",
      "Bottom Left Arc step for rounded corners.",
      0, 1000, 10,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_BR_ARC_STEP] = g_param_spec_float ("rc-br-arc-step",
      "RCBRArcStep",
      "Bottom Right Arc step for rounded corners.",
      0, 1000, 10,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_TL_ARC_STEP] = g_param_spec_float ("rc-tl-arc-step",
      "RCTLArcStep",
      "Top Left Arc step for rounded corners.",
      0, 1000, 10,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[VOLT_ACTOR_PROP_RC_TR_ARC_STEP] = g_param_spec_float ("rc-tr-arc-step",
      "RCTRArcStep",
      "Top Right Arc step for rounded corners.",
      0, 1000, 10,
      (GParamFlags)(G_PARAM_READWRITE));

  obj_props[PROP_RC_COLOR] = clutter_param_spec_color ("rc-color",
                             "RCColor",
                             "The color for actor with rounded corners.",
                             CLUTTER_COLOR_Transparent,
                             (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_BORDER_COLOR] = clutter_param_spec_color ("border-color",
                                 "BorderColor",
                                 "The actor's border color",
                                 &grey,
                                 (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_BORDER_WIDTH] = g_param_spec_float ("border-width",
                                 "BorderWidth",
                                 "The width of the actor's border (in pixels)",
                                 0.0, 100.0,
                                 0.0,
                                 (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_ANCHOR_X] = g_param_spec_float ("anchor-x",
                             "Anchor",
                             "Negative offset from the left in normalized coordinates",
                             -G_MAXFLOAT, G_MAXFLOAT,
                             0.0f,
                             (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_ANCHOR_Y] = g_param_spec_float ("anchor-y",
                             "Anchor",
                             "Negative offset from the top in normalized coordinates",
                             -G_MAXFLOAT, G_MAXFLOAT,
                             0.0f,
                             (GParamFlags)G_PARAM_READWRITE);


  obj_props[PROP_ORIGIN_X] = g_param_spec_float ("origin-x",
                             "Origin",
                             "Offset from parent in normalized coordinates",
                             -G_MAXFLOAT, G_MAXFLOAT,
                             0.0f,
                             (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_ORIGIN_Y] = g_param_spec_float ("origin-y",
                             "Origin",
                             "Offset from parent in normalized coordinates",
                             -G_MAXFLOAT, G_MAXFLOAT,
                             0.0f,
                             (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_VOLT_WIDTH] = g_param_spec_float ("volt-width",
                               "Width",
                               "Replacement for width that respects the anchor property",
                               -G_MAXFLOAT, G_MAXFLOAT,
                               0.0f,
                               (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_VOLT_HEIGHT] = g_param_spec_float ("volt-height",
                                "Height",
                                "Replacement for height that respects the anchor property",
                                -G_MAXFLOAT, G_MAXFLOAT,
                                0.0f,
                                (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_GRADIENT_FILL] = g_param_spec_boolean ("gradient-fill",
                                  "GradientFill",
                                  "Whether the actor has a gradient fill",
                                  FALSE,
                                  (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_GRAD_TL_COLOR] = clutter_param_spec_color ("grad-tl-color",
                                  "GradTlColor",
                                  "The top left gradient color.",
                                  CLUTTER_COLOR_Transparent,
                                  (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_GRAD_TR_COLOR] = clutter_param_spec_color ("grad-tr-color",
                                  "GradTrColor",
                                  "The top right gradient color.",
                                  CLUTTER_COLOR_Transparent,
                                  (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_GRAD_BL_COLOR] = clutter_param_spec_color ("grad-bl-color",
                                  "GradBlColor",
                                  "The bottom left gradient color.",
                                  CLUTTER_COLOR_Transparent,
                                  (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_GRAD_BR_COLOR] = clutter_param_spec_color ("grad-br-color",
                                  "GradBrColor",
                                  "The bottom right gradient color.",
                                  CLUTTER_COLOR_Transparent,
                                  (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_SHADOW_X_OFFSET] =  g_param_spec_float ("shadow-x-offset",
                                     "ShadowXOffset",
                                     "Horizontal offset of shadow",
                                     -G_MAXFLOAT, G_MAXFLOAT,
                                     0.0f,
                                     (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_SHADOW_Y_OFFSET] =  g_param_spec_float ("shadow-y-offset",
                                     "ShadowYOffset",
                                     "Vertical offset of shadow",
                                     -G_MAXFLOAT, G_MAXFLOAT,
                                     0.0f,
                                     (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_SHADOW_BLUR] =  g_param_spec_float("shadow-blur",
                                 "ShadowBlur",
                                 "Shadow Blur Size",
                                 0, G_MAXUINT8,
                                 0,
                                 (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_SHADOW_SPREAD] =  g_param_spec_float("shadow-spread",
                                   "ShadowSpread",
                                   "Shadow Spread Size",
                                   0, G_MAXUINT8,
                                   0,
                                   (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_SHADOW_COLOR] = clutter_param_spec_color ("shadow-color",
                                 "ShadowColor",
                                 "The color of the shadow.",
                                 CLUTTER_COLOR_Black,
                                 (GParamFlags)G_PARAM_READWRITE);

  obj_props[PROP_TRANSFORMED_DEPTH] = g_param_spec_float ("transformed-depth",
                                      "TransformedDepth",
                                      "The transformed depth in stage coordinates",
                                      -G_MAXFLOAT, G_MAXFLOAT,
                                      0.0f,
                                      (GParamFlags)G_PARAM_READABLE);

  g_object_class_install_properties (gobject_class, PROP_LAST, obj_props);

  /**
   * VoltActor::children-depths-changed
   * @actor: the object which received the signal
   *
   * The ::children-depths-changed signal is emitted at the beginning
   * of the paint cycle to indicate that depth values of the actor's
   * children may have changed.
   */
  volt_actor_signals[CHILDREN_DEPTHS_CHANGED] =
    g_signal_new (I_("children-depths-changed"),
                  G_TYPE_FROM_CLASS (gobject_class),
                  G_SIGNAL_RUN_FIRST,
                  0,
                  NULL, NULL,
                  _clutter_marshal_VOID__VOID,
                  G_TYPE_NONE, 0);
}


/* object init: create a private structure and pack
 * composed ClutterActors into it
 */
static void
volt_actor_init (VoltActor *self)
{
  VoltActorPrivate *priv;

  priv = self->priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);
  priv->rounded_corners = FALSE;
  priv->rc_radius = 10.0;
  priv->rc_bl_radius = 10.0;
  priv->rc_br_radius = 10.0;
  priv->rc_tl_radius = 10.0;
  priv->rc_tr_radius = 10.0;

  priv->default_corner = FALSE;
  priv->custom_corner_bl = FALSE;
  priv->custom_corner_br = FALSE;
  priv->custom_corner_tl = FALSE;
  priv->custom_corner_tr = FALSE;
  priv->rc_arc_step = 10.0;
  priv->rc_bl_arc_step = 10.0;
  priv->rc_br_arc_step = 10.0;
  priv->rc_tl_arc_step = 10.0;
  priv->rc_tr_arc_step = 10.0;

  priv->override_color = *CLUTTER_COLOR_Transparent;

  priv->border_material = NULL;
  priv->border_color = grey;
  priv->border_width = 0;
  priv->border_set = FALSE;
  priv->anchor_x = 0.0;
  priv->anchor_y = 0.0;
  priv->origin_x = 0.0;
  priv->origin_y = 0.0;
  priv->gradient_fill = FALSE;
  priv->grad_tl_color = {0};
  priv->grad_tr_color = {0};
  priv->grad_bl_color = {0};
  priv->grad_br_color = {0};

  priv->user_data = NULL;

  priv->shadow_material = COGL_INVALID_HANDLE;
  priv->shadow_width = -1;
  priv->shadow_height = -1;
  priv->shadow_spec = NULL;
  priv->shadow_needs_update = FALSE;

  priv->clip_to_shape = FALSE;
  priv->clip_to_shape_handler_id = 0;

  priv->auto_sort_children_by_depth = FALSE;
}

/* called each time a property is set on the effect */
static void
volt_actor_update (VoltActor *self)
{
  clutter_actor_queue_redraw (CLUTTER_ACTOR(self));
}

/** Update the volt actor's horizontal translation, taking into
 *  account the origin, anchor, size, and parent's size */
void volt_actor_update_translation_x(VoltActor *self)
{
  if (IS_VOLT_ACTOR(self))
  {
    VoltActorPrivate *priv;
    priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

    ClutterActor *actor = CLUTTER_ACTOR(self);

    float translationY, dummy;
    clutter_actor_get_translation(actor, &dummy, &translationY, &dummy);
    float width = clutter_actor_get_width(actor);
    ClutterActor *parent = clutter_actor_get_parent(actor);

    if (parent != NULL)
    {
      float parentWidth = clutter_actor_get_width(clutter_actor_get_parent(actor));
      clutter_actor_set_translation(actor,
                                    (priv->origin_x * parentWidth) - (priv->anchor_x * width),
                                    translationY, 0);
    }
  }
}

/** Update the volt actor's vertical translation, taking into
 *  account the origin, anchor, size, and parent's size */
void volt_actor_update_translation_y(VoltActor *self)
{
  if (IS_VOLT_ACTOR(self))
  {
    VoltActorPrivate *priv;
    priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

    ClutterActor *actor = CLUTTER_ACTOR(self);

    float translationX, dummy;
    clutter_actor_get_translation(actor, &translationX, &dummy, &dummy);
    float height = clutter_actor_get_height(actor);
    ClutterActor *parent = clutter_actor_get_parent(actor);

    if (parent != NULL)
    {
      float parentHeight = clutter_actor_get_height(parent);
      clutter_actor_set_translation(actor, translationX,
                                    (priv->origin_y * parentHeight) - (priv->anchor_y * height), 0);
    }
  }
}


/* public API */
/* examples of public API functions which wrap functions
 * on internal actors
 */

/**
 * volt_actor_set_user_data:
 * @self: a #VoltActor
 * @user_data: opaque pointer to user data
 **/
void
volt_actor_set_user_data(VoltActor    *self,
                         void* user_data)
{
  g_return_if_fail (IS_VOLT_ACTOR (self));
  self->priv->user_data = user_data;
}

void*
volt_actor_get_user_data (VoltActor *self)
{
  g_return_val_if_fail (IS_VOLT_ACTOR (self), FALSE);

  return self->priv->user_data;
}


/**
 * volt_actor_set_rounded_corners:
 * @self: a #VoltActor
 * @user_data: Untyped pointer to store with volt_actor
 *
 * Set user data.
 **/
void
volt_actor_set_rounded_corners(VoltActor    *self,
                               gboolean rounded_corners)
{
  VoltActorPrivate *priv;

  /* public API should check its arguments;
   * see also g_return_val_if_fail for functions which
   * return a value
   */
  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = self->priv;

  if (priv->rounded_corners != rounded_corners)
  {
    priv->rounded_corners = rounded_corners;

    // NOTE: we have to turn off the actor's background color so that
    // the background fill which is drawn first doesn't show in the
    // corners of the actor.
    if (rounded_corners)
    {
      clutter_actor_set_background_color(CLUTTER_ACTOR(self),NULL);
    }

    volt_actor_shadow_update(self);
    volt_actor_update(self);
  }
}

/**
 * volt_actor_get_rounded_corners:
 * @self: a #VoltActor
 *
 * Get boolean indicating whether the actor is to be drawn
 * rounded corners.
 *
 * Returns: boolean indicating whether the actor is to be drawn
 * rounded corners.
 */
gboolean
volt_actor_get_rounded_corners (VoltActor *self)
{
  g_return_val_if_fail (IS_VOLT_ACTOR (self), FALSE);

  return self->priv->rounded_corners;
}


/**
 * volt_actor_set_rc_radius:
 * @self: a #VoltActor
 * @rc_radius: a #gFloat
 *
 * Sets the radius of the corner arcs provided by the effect
 * @self.
 **/
void
volt_actor_set_rc_radius(VoltActor    *self,
                         gfloat rc_radius, int property_id)
{
  /* public API should check its arguments;
  * see also g_return_val_if_fail for functions which
  * return a value
  */
  g_return_if_fail (IS_VOLT_ACTOR (self));

  VoltActorPrivate *priv = self->priv;
  gfloat *radius = NULL;

  switch(property_id)
  {
  case VOLT_ACTOR_PROP_RC_RADIUS:
    radius = &(priv->rc_radius);
    priv->default_corner = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_BL_RADIUS:
    radius = &(priv->rc_bl_radius);
    priv->custom_corner_bl = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_BR_RADIUS:
    radius = &(priv->rc_br_radius);
    priv->custom_corner_br = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_TL_RADIUS:
    radius = &(priv->rc_tl_radius);
    priv->custom_corner_tl = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_TR_RADIUS:
    radius = &(priv->rc_tr_radius);
    priv->custom_corner_tr = TRUE;
    break;

    // unhandled property id
  default:
    return;
  }

  if (*radius != rc_radius)
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      *radius = rc_radius;
      volt_actor_shadow_update(self);
      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[property_id],
                                   *radius, rc_radius);
    }
  }
}

/**
 * volt_actor_get_rc_radius:
 * @self: a #VoltActor
 *
 * Gets the radius of the corner arcs of the actor.
 *
 * Returns value: the radius of the corner arcs of the actor or
 * 0.0 if @self is not an #VoltActor
 */
gfloat
volt_actor_get_rc_radius (VoltActor *self, int property_id)
{
  g_return_val_if_fail (IS_VOLT_ACTOR (self), FALSE);

  switch(property_id)
  {
  case VOLT_ACTOR_PROP_RC_RADIUS:
    return self->priv->rc_radius;

  case VOLT_ACTOR_PROP_RC_BL_RADIUS:
    return self->priv->rc_bl_radius;

  case VOLT_ACTOR_PROP_RC_BR_RADIUS:
    return self->priv->rc_br_radius;

  case VOLT_ACTOR_PROP_RC_TL_RADIUS:
    return self->priv->rc_tl_radius;

  case VOLT_ACTOR_PROP_RC_TR_RADIUS:
    return self->priv->rc_tr_radius;

    // unhandled property id
  default:
    return 0;
  }

  return 0;
}


/**
 * volt_actor_set_rc_arc_step:
 * @self: a #VoltActor
 * @rc_arc_step: the angle increment resolution for subdivision of the
 *       corner arcs
 *
 * Sets the angle increment resolution for subdivision of the
 * corner arcs of the actor.
 **/
void
volt_actor_set_rc_arc_step(VoltActor    *self,
                           gfloat rc_arc_step,
                           int property_id)
{
  VoltActorPrivate *priv;

  /* public API should check its arguments;
   * see also g_return_val_if_fail for functions which
   * return a value
   */
  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = self->priv;
  gfloat *arc_step = NULL;

  switch(property_id)
  {
  case VOLT_ACTOR_PROP_RC_ARC_STEP:
    arc_step = &(priv->rc_arc_step);
    priv->default_corner = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_BL_ARC_STEP:
    arc_step = &(priv->rc_bl_arc_step);
    priv->custom_corner_bl = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_BR_ARC_STEP:
    arc_step = &(priv->rc_br_arc_step);
    priv->custom_corner_br = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_TL_ARC_STEP:
    arc_step = &(priv->rc_tl_arc_step);
    priv->custom_corner_tl = TRUE;
    break;

  case VOLT_ACTOR_PROP_RC_TR_ARC_STEP:
    arc_step = &(priv->rc_tr_arc_step);
    priv->custom_corner_tr = TRUE;
    break;

    // unhandled property id
  default:
    return;
  }

  if (*arc_step != rc_arc_step)
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      *arc_step = rc_arc_step;
      volt_actor_shadow_update(self);
      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[property_id],
                                   *arc_step, rc_arc_step);
    }
  }
}

/**
 * volt_actor_get_rc_arc_step:
 * @self: a #VoltActor
 *
 * Gets the angle increment resolution for subdivision of the
 *       corner arcs of the rounded corners.
 *
 * Return value: the the angle increment, or 0.0 if
 * @self is not a #VoltActor
 */
gfloat
volt_actor_get_rc_arc_step (VoltActor *self, int property_id)
{
  g_return_val_if_fail (IS_VOLT_ACTOR (self), FALSE);

  switch(property_id)
  {
  case VOLT_ACTOR_PROP_RC_ARC_STEP:
    return self->priv->rc_arc_step;
  case VOLT_ACTOR_PROP_RC_BL_ARC_STEP:
    return self->priv->rc_bl_arc_step;

  case VOLT_ACTOR_PROP_RC_BR_ARC_STEP:
    return self->priv->rc_br_arc_step;

  case VOLT_ACTOR_PROP_RC_TL_ARC_STEP:
    return self->priv->rc_tl_arc_step;

  case VOLT_ACTOR_PROP_RC_TR_ARC_STEP:
    return self->priv->rc_tr_arc_step;

    // unhandled property id
  default:
    return 0;
  }


  return 0;
}

/**
 * volt_actor_set_rc_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Sets the fill color for the actor for
 *       when it has rounded corners.
 *
 */
void
volt_actor_set_override_color(VoltActor *self, const ClutterColor* color)
{
  g_return_if_fail (IS_VOLT_ACTOR (self));

  if (color == NULL)
  {
    self->priv->override_color = *CLUTTER_COLOR_Transparent;
  }
  else if (clutter_color_equal(color, &self->priv->override_color))
  {
    return;
  }
  else
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      self->priv->override_color = *color;
      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[PROP_RC_COLOR],
                                   &self->priv->override_color, color);
    }
  }
}

/**
 * volt_actor_get_rc_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Gets the fill color for the actor for
 *       when it has rounded corners.
 *
 */
void
volt_actor_get_override_color(VoltActor *self, ClutterColor* color)
{
  g_return_if_fail (IS_VOLT_ACTOR (self));

  *color = self->priv->override_color;
}


/**
 * volt_actor_set_border_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Sets the color of the actor @self's border.
 */
void
volt_actor_set_border_color (VoltActor     *self,
                             const ClutterColor  *color)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  if (color == NULL)
  {
    priv->border_set = FALSE;
  }
  else if (priv->border_set && clutter_color_equal(color, &priv->border_color))
  {
    return;
  }
  else
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      priv->border_set = TRUE;
      priv->border_color.red = color->red;
      priv->border_color.green = color->green;
      priv->border_color.blue = color->blue;
      priv->border_color.alpha = color->alpha;

      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[PROP_BORDER_COLOR],
                                   &priv->border_color, color);
    }
  }

}


/**
 * volt_actor_get_border_color:
 * @self: a #VoltActor
 * @color: return location for a #ClutterColor
 *
 * Retrieves the color of the border on the actor @self.
 */
void
volt_actor_get_border_color(VoltActor *self, ClutterColor* color)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  color->red = priv->border_color.red;
  color->green = priv->border_color.green;
  color->blue = priv->border_color.blue;
  color->alpha = priv->border_color.alpha;
}


/**
 * volt_actor_set_border_width:
 * @self: a #VoltActor
 * @width: the width of the border
 *
 * Sets the width (in pixels) of the border on the actor
 * @self.
 */
void
volt_actor_set_border_width (VoltActor     *self,
                             gfloat        width)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  priv->border_set = width != 0;

  if (width != priv->border_width)
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      priv->border_width = width;
      volt_actor_shadow_update(self);
      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[PROP_BORDER_WIDTH],
                                   priv->border_width, width);
    }
  }
}

/**
 * volt_actor_get_border_width:
 * @self: a #VoltActor
 *
 * Gets the width (in pixels) of the border on the actor @self.
 *
 * Return value: the border's width, or 0.0 if @self is not
 * a #VoltActor
 */
gfloat
volt_actor_get_border_width(VoltActor *self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail (IS_VOLT_ACTOR (self), 0.0);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  return priv->border_width;
}


/**
 * volt_actor_get_anchor_x:
 * @self: a #VoltActor
 *
 * Gets the horizontal offset from left of the actor @self.
 *
 * Return value: the anchor x in normalized coordinates
 */
gfloat volt_actor_get_anchor_x(VoltActor* self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail (IS_VOLT_ACTOR (self), 0.0);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  return priv->anchor_x;
}

/**
 * volt_actor_set_anchor_x:
 * @self: a #VoltActor
 * @width: horizontal offset from left of the actor
 *
 * Sets the horizontal offset from left of the actor
 * @self.
 */
void volt_actor_set_anchor_x (VoltActor *self, gfloat value)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  priv->anchor_x = value;

  volt_actor_update_translation_x(self);
  volt_actor_update (self);
}



/**
 * volt_actor_get_anchor_y:
 * @self: a #VoltActor
 *
 * Gets the vertical offset from left of the actor @self.
 *
 * Return value: the anchor y in normalized coordinates
 */
gfloat volt_actor_get_anchor_y(VoltActor* self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail (IS_VOLT_ACTOR (self), 0.0);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  return priv->anchor_y;
}

/**
 * volt_actor_set_anchor_y:
 * @self: a #VoltActor
 * @width: vertical offset from left of the actor
 *
 * Sets the vertical offset from left of the actor
 * @self.
 */
void volt_actor_set_anchor_y (VoltActor *self, gfloat value)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  priv->anchor_y = value;

  volt_actor_update_translation_y(self);
  volt_actor_update (self);
}



/**
 * volt_actor_get_origin_x:
 * @self: a #VoltActor
 *
 * Gets the horizontal offset from the parent of actor @self.
 *
 * Return value: the origin x in normalized coordinates
 */
gfloat volt_actor_get_origin_x(VoltActor* self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail (IS_VOLT_ACTOR (self), 0.0);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  return priv->origin_x;
}

/**
 * volt_actor_set_origin_x:
 * @self: a #VoltActor
 * @width: horizontal offset from the parent of actor
 *
 * Sets the horizontal offset from the parent of actor
 * @self.
 */
void volt_actor_set_origin_x (VoltActor *self, gfloat value)
{
  VoltActorPrivate *priv;
  g_return_if_fail (IS_VOLT_ACTOR (self));
  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  priv->origin_x = value;

  volt_actor_update_translation_x(self);
  volt_actor_update (self);
}


/**
 * volt_actor_get_origin_x:
 * @self: a #VoltActor
 *
 * Gets the horizontal offset from the parent of actor @self.
 *
 * Return value: the origin x in normalized coordinates
 */
gfloat volt_actor_get_origin_y(VoltActor* self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail (IS_VOLT_ACTOR (self), 0.0);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  return priv->origin_y;
}

/**
 * volt_actor_set_origin_y:
 * @self: a #VoltActor
 * @width: horizontal offset from the parent of actor
 *
 * Sets the horizontal offset from the parent of actor
 * @self.
 */
void volt_actor_set_origin_y (VoltActor *self, gfloat value)
{
  VoltActorPrivate *priv;
  g_return_if_fail (IS_VOLT_ACTOR (self));
  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  priv->origin_y = value;

  volt_actor_update_translation_y(self);
  volt_actor_update (self);
}

/**
 * volt_actor_get_width:
 * @self: a #VoltActor
 *
 * Gets the width of actor @self.
 *
 * Return value: the width
 */
gfloat volt_actor_get_width(VoltActor* self)
{
  g_return_val_if_fail (IS_VOLT_ACTOR (self), 0.0);
  return (gfloat)clutter_actor_get_width(CLUTTER_ACTOR(self));
}

/**
 * volt_actor_set_width:
 * @self: a #VoltActor
 * @width: width of actor @self
 *
 * Sets the width of actor
 * @self.
 */
void volt_actor_set_width (VoltActor *self, gfloat value)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  ClutterActor* actor = CLUTTER_ACTOR(self);

  clutter_actor_set_width(actor, value);

  if ( priv->anchor_x != 0 || priv->origin_x != 0 )
  {
    //update translaton x and tell children to do the same
    volt_actor_update_translation_x(self);
  }

  GList* children = clutter_actor_get_children(actor);
  g_list_foreach(children, (GFunc)volt_actor_update_translation_x, NULL );
  g_list_free(children);

  volt_actor_shadow_update(self);
  volt_actor_update (self);
}


/**
 * volt_actor_get_height:
 * @self: a #VoltActor
 *
 * Gets the height of actor @self.
 *
 * Return value: the height
 */
gfloat volt_actor_get_height(VoltActor* self)
{
  g_return_val_if_fail (IS_VOLT_ACTOR (self), 0.0);
  return (gfloat)clutter_actor_get_height(CLUTTER_ACTOR(self));
}

/**
 * volt_actor_set_height:
 * @self: a #VoltActor
 * @height: height of actor @self
 *
 * Sets the height of actor
 * @self.
 */
void volt_actor_set_height (VoltActor *self, gfloat value)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  ClutterActor* actor = CLUTTER_ACTOR(self);

  clutter_actor_set_height(actor, value);

  if ( priv->anchor_y != 0 || priv->origin_y != 0 )
  {
    //update translaton x and tell children to do the same
    volt_actor_update_translation_y(self);
  }

  GList* children = clutter_actor_get_children(CLUTTER_ACTOR(self));
  g_list_foreach(children, (GFunc)volt_actor_update_translation_y, NULL );
  g_list_free(children);

  volt_actor_shadow_update(self);
  volt_actor_update (self);
}


/**
 * volt_actor_set_gradient_fill:
 * @self: a #VoltActor
 * @gradient_fill: TRUE if actor should be drawn with a gradient fill.
 *
 * Set boolean indicating whether the actor is to be drawn with a
 * gradient fill
 **/
void
volt_actor_set_gradient_fill(VoltActor    *self,
                             gboolean gradient_fill)
{
  VoltActorPrivate *priv;

  /* public API should check its arguments;
   * see also g_return_val_if_fail for functions which
   * return a value
   */
  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = self->priv;

  if (priv->gradient_fill != gradient_fill)
  {
    priv->gradient_fill = gradient_fill;

    // Optimization: turn off the actor's background color
    if (gradient_fill)
    {
      clutter_actor_set_background_color(CLUTTER_ACTOR(self),NULL);
    }

    volt_actor_update(self);
  }
}

/**
 * volt_actor_get_gradient_fill:
 * @self: a #VoltActor
 *
 * Get boolean indicating whether the actor is to be drawn
 * with a gradient fill.
 *
 * Returns: boolean indicating whether the actor is to be drawn
 * with a gradient fill.
 */
gboolean
volt_actor_get_gradient_fill (VoltActor *self)
{
  g_return_val_if_fail (IS_VOLT_ACTOR (self), FALSE);

  return self->priv->gradient_fill;
}


/**
 * volt_actor_get_grad_tl_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Gets the top left color for the optional gradient fill
 *
 */
void
volt_actor_get_grad_tl_color(VoltActor *self, ClutterColor* color)
{
  g_return_if_fail (IS_VOLT_ACTOR (self));

  *color = self->priv->grad_tl_color;
}


/**
 * volt_actor_set_grad_tl_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Sets the top left color of the actor @self's gradient fill.
 */
void
volt_actor_set_grad_tl_color (VoltActor     *self,
                              const ClutterColor  *color)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  if (color == NULL)
  {
    priv->gradient_fill = FALSE;
  }
  else if (priv->gradient_fill && clutter_color_equal(color, &priv->grad_tl_color))
  {
    return;
  }
  else
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      priv->gradient_fill = TRUE;
      priv->grad_tl_color.red = color->red;
      priv->grad_tl_color.green = color->green;
      priv->grad_tl_color.blue = color->blue;
      priv->grad_tl_color.alpha = color->alpha;

      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[PROP_GRAD_TL_COLOR],
                                   &priv->grad_tl_color, color);
    }
  }
}


/**
 * volt_actor_get_grad_tr_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Gets the top right color for the optional gradient fill
 *
 */
void
volt_actor_get_grad_tr_color(VoltActor *self, ClutterColor* color)
{
  g_return_if_fail (IS_VOLT_ACTOR (self));

  *color = self->priv->grad_tr_color;
}


/**
 * volt_actor_set_grad_tr_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Sets the top right color of the actor @self's gradient fill.
 */
void
volt_actor_set_grad_tr_color (VoltActor     *self,
                              const ClutterColor  *color)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  if (color == NULL)
  {
    priv->gradient_fill = FALSE;
  }
  else if (priv->gradient_fill && clutter_color_equal(color, &priv->grad_tr_color))
  {
    return;
  }
  else
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      priv->gradient_fill = TRUE;
      priv->grad_tr_color.red = color->red;
      priv->grad_tr_color.green = color->green;
      priv->grad_tr_color.blue = color->blue;
      priv->grad_tr_color.alpha = color->alpha;

      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[PROP_GRAD_TR_COLOR],
                                   &priv->grad_tr_color, color);
    }
  }
}


/**
 * volt_actor_get_grad_bl_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Gets the bottom right color for the optional gradient fill
 *
 */
void
volt_actor_get_grad_bl_color(VoltActor *self, ClutterColor* color)
{
  g_return_if_fail (IS_VOLT_ACTOR (self));

  *color = self->priv->grad_bl_color;
}


/**
 * volt_actor_set_grad_bl_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Sets the bottom right color of the actor @self's gradient fill.
 */
void
volt_actor_set_grad_bl_color (VoltActor     *self,
                              const ClutterColor  *color)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  if (color == NULL)
  {
    priv->gradient_fill = FALSE;
  }
  else if (priv->gradient_fill && clutter_color_equal(color, &priv->grad_bl_color))
  {
    return;
  }
  else
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      priv->gradient_fill = TRUE;
      priv->grad_bl_color.red = color->red;
      priv->grad_bl_color.green = color->green;
      priv->grad_bl_color.blue = color->blue;
      priv->grad_bl_color.alpha = color->alpha;

      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[PROP_GRAD_BL_COLOR],
                                   &priv->grad_bl_color, color);
    }
  }
}


/**
 * volt_actor_get_grad_br_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Gets the bottom right color for the optional gradient fill
 *
 */
void
volt_actor_get_grad_br_color(VoltActor *self, ClutterColor* color)
{
  g_return_if_fail (IS_VOLT_ACTOR (self));

  *color = self->priv->grad_br_color;
}


/**
 * volt_actor_set_grad_br_color:
 * @self: a #VoltActor
 * @color: a #ClutterColor
 *
 * Sets the bottom right color of the actor @self's gradient fill.
 */
void
volt_actor_set_grad_br_color (VoltActor     *self,
                              const ClutterColor  *color)
{
  VoltActorPrivate *priv;

  g_return_if_fail (IS_VOLT_ACTOR (self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE (self);

  if (color == NULL)
  {
    priv->gradient_fill = FALSE;
  }
  else if (priv->gradient_fill && clutter_color_equal(color, &priv->grad_br_color))
  {
    return;
  }
  else
  {
    // if no animation necessary, just set value, otherwise create implicit transition.
    if (clutter_actor_get_easing_duration(CLUTTER_ACTOR(self)) == 0)
    {
      priv->gradient_fill = TRUE;
      priv->grad_br_color.red = color->red;
      priv->grad_br_color.green = color->green;
      priv->grad_br_color.blue = color->blue;
      priv->grad_br_color.alpha = color->alpha;

      volt_actor_update (self);
    }
    else
    {
      volt_actor_create_transition(self, NULL, NULL, obj_props[PROP_GRAD_BR_COLOR],
                                   &priv->grad_br_color, color);
    }
  }
}


// Shadows
/**
 * volt_actor_shadow_update: Routine to update the shadow when something has changed that
 *   affects it.
 *
 * @author jim
 *
 * @param self The actor instance
 */
void volt_actor_shadow_update(VoltActor *self)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec)
  {
    priv->shadow_needs_update = TRUE; 
    volt_actor_update(self);
  }
}

void volt_actor_shadow_update_render_thread(VoltActor *self)
{
  VoltActorPrivate *priv;

	g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  // unref old shadow material
  if (priv->shadow_material != COGL_INVALID_HANDLE)
  {
    cogl_handle_unref(priv->shadow_material);
    priv->shadow_material = COGL_INVALID_HANDLE;
  }

  if (priv->shadow_spec)
  {
    CoglHandle material;
    gfloat width, height;

    clutter_actor_get_size(CLUTTER_ACTOR(self), &width, &height);
    priv->shadow_width = width;
    priv->shadow_height = height;

    if (priv->border_set)
    {
      priv->shadow_width += 2 * priv->border_width;
      priv->shadow_height += 2 * priv->border_width;
    }

		material = st_create_shadow_material_from_actor(priv->shadow_spec,
			CLUTTER_ACTOR(self),
			volt_actor_paint_footprint,
			priv->shadow_width, priv->shadow_height,
			!priv->rounded_corners);
		priv->shadow_material = material;
	}
}

/**
 * volt_actor_set_shadow: Sets whether the shadow should be drawn and its parameters.
 *
 * @author jim
 *
 * @param self The actor instance
 * @param hasShadow TRUE to enable shadow
 * @param xOffset relative horizontal offset from actor to draw shadow.
 * @param yOffset relative vertical offset from actor to draw shadow.
 * @param blur size in pixels of blur
 * @param spread size in pixels to enlarge/reduce shadow
 * @param color color tint of shadow
 */
void volt_actor_set_shadow(VoltActor *self, gboolean hasShadow, gfloat xOffset, gfloat yOffset,
                           gfloat blur, gfloat spread, const ClutterColor* color)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  // create shadow if it doesn't exist
  if (hasShadow)
  {
    if (!priv->shadow_spec)
    {
      priv->shadow_spec = st_shadow_new(color, xOffset, yOffset, blur, spread, FALSE);
      volt_actor_shadow_update(self);
    }
    else if (xOffset != priv->shadow_spec->xoffset || yOffset != priv->shadow_spec->yoffset ||
             blur != priv->shadow_spec->blur || spread != priv->shadow_spec->spread ||
             !clutter_color_equal(color, &priv->shadow_spec->color) )
    {
      priv->shadow_spec->xoffset = xOffset;
      priv->shadow_spec->yoffset = yOffset;
      priv->shadow_spec->blur = blur;
      priv->shadow_spec->spread = spread;
      priv->shadow_spec->color = *color;
      volt_actor_shadow_update(self);
    }
  }
  else // !hasShadow
  {
    // unreference shadow resources
    if (priv->shadow_spec)
    {
      st_shadow_unref(priv->shadow_spec);
      priv->shadow_spec = NULL;
      priv->shadow_needs_update = TRUE; 
      volt_actor_update(self);
    }
  }
}

/**
 * volt_actor_set_shadow_h: sets the horizontal offset from actor to draw shadow.
 *
 * @author jim
 *
 * @param self the actor instance
 * @param hShadow the horizontal offset in pixels
 */
void volt_actor_set_shadow_h(VoltActor *self, gfloat hShadow)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec && priv->shadow_spec->xoffset != hShadow)
  {
    priv->shadow_spec->xoffset = hShadow;
    volt_actor_shadow_update(self);
  }
}

/**
 * volt_actor_set_shadow_v: sets the vertical offset from actor to draw shadow.
 *
 * @author jim
 *
 * @param self the actor instance
 * @param hShadow the vertical offset in pixels
 */
void volt_actor_set_shadow_v(VoltActor *self, gfloat vShadow)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec && priv->shadow_spec->yoffset != vShadow)
  {
    priv->shadow_spec->yoffset = vShadow;
    volt_actor_shadow_update(self);
  }
}

/**
 * volt_actor_set_shadow_blur: Sets the shadow blur size.
 *
 * @author jim
 *
 * @param self the actor instance
 * @param blur size in pixels of blur
 */
void volt_actor_set_shadow_blur(VoltActor *self, gfloat blur)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  // Changing the blur requires updating the shadow material
  if (priv->shadow_spec && priv->shadow_spec->blur != blur)
  {
    priv->shadow_spec->blur = blur;
    volt_actor_shadow_update(self);
  }
}

/**
 * volt_actor_set_shadow_spread: Sets the size to enlarge the shadow
 *
 * @author jim (7/22/2014)
 *
 * @param self the actor instance
 * @param spread the size in pixels to enlarge/reduce the shadow
 */
void volt_actor_set_shadow_spread(VoltActor *self, gfloat spread)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec && priv->shadow_spec->spread != spread)
  {
    priv->shadow_spec->spread = spread;
    volt_actor_shadow_update(self);
  }
}

/**
 * volt_actor_set_shadow_color
 *
 * @author jim (7/22/2014)
 *
 * @param self the actor instance
 * @param color the color tint of the shadow
 */
void volt_actor_set_shadow_color(VoltActor *self, const ClutterColor *color)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec && !clutter_color_equal(&priv->shadow_spec->color, color))
  {
    priv->shadow_spec->color = *color;
    volt_actor_shadow_update(self);
  }
}


// shadow getters
/**
 * volt_actor_get_shadow: returns TRUE if shadow is enabled
 *
 * @author jim
 *
 * @param self the actor instance
 *
 * @return gboolean TRUE if shadow is enabled.
 */
gboolean volt_actor_get_shadow(VoltActor *self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail(IS_VOLT_ACTOR(self), FALSE);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);
  return priv->shadow_spec != NULL;
}

/**
 * volt_actor_get_shadow_h: returns relative horizontal offset from actor to draw shadow
 *
 * @author jim
 *
 * @param self the actor instance
 *
 * @return gfloat relative horizontal offset from actor to draw shadow
 */
gfloat volt_actor_get_shadow_h(VoltActor *self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail(IS_VOLT_ACTOR(self), 0.0f);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec)
  {
    return priv->shadow_spec->xoffset;
  }
  else
  {
    return 0.0f;
  }
}

/**
 * volt_actor_get_shadow_v: relative vertical offset from actor to draw shadow
 *
 * @author jim
 *
 * @param self the actor instance
 *
 * @return gfloat relative vertical offset from actor to draw shadow
 */
gfloat volt_actor_get_shadow_v(VoltActor *self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail(IS_VOLT_ACTOR(self), 0.0f);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec)
  {
    return priv->shadow_spec->yoffset;
  }
  else
  {
    return 0.0f;
  }
}

/**
 * volt_actor_get_shadow_blur: returns the size in pixels of blur
 *
 * @author jim
 *
 * @param self the actor instance
 *
 * @return int size in pixels of blur
 */
gfloat volt_actor_get_shadow_blur(VoltActor *self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail(IS_VOLT_ACTOR(self), 0.0f);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec)
  {
    return priv->shadow_spec->blur;
  }
  else
  {
    return 0.0f;
  }
}

/**
 * volt_actor_get_shadow_spread: returns size in pixels to enlarge/reduce shadow
 *
 * @author jim
 *
 * @param self the actor instance
 *
 * @return int size in pixels to enlarge/reduce shadow
 */
gfloat volt_actor_get_shadow_spread(VoltActor *self)
{
  VoltActorPrivate *priv;

  g_return_val_if_fail(IS_VOLT_ACTOR(self), 0.0f);

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec)
  {
    return priv->shadow_spec->spread;
  }
  else
  {
    return 0.0f;
  }
}

/**
 * volt_actor_get_shadow_color: returns the shadow color tint
 *
 * @author jim
 *
 * @param self the actor instance
 * @param color color tint of shadow
 */
void volt_actor_get_shadow_color(VoltActor *self, ClutterColor *color)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (priv->shadow_spec)
  {
    *color = priv->shadow_spec->color;
  }
  else
  {
    *color = *CLUTTER_COLOR_Transparent;
  }
}

/**
 * volt_actor_push_clip_to_shape: pushes a clip region of the shape of the actor so any drawing
 *   that occurs subsequently until volt_actor_pop_clip_to_shape() is called will be cropped to
 *   this shape
 *
 * @author jim (7/29/2014)
 *
 * @param self the volt actor instance
 */
void volt_actor_push_clip_to_shape(VoltActor* self)
{
  VoltActorPrivate *priv;
  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  gfloat width, height;
  clutter_actor_get_size (CLUTTER_ACTOR(self), &width, &height);

  if (priv->rounded_corners)
  {
    cogl_path_new();

    // build custom rounded corner if any corner has been set before
    if(volt_actor_has_custom_corner(self))
    {
      volt_actor_custom_rounded_rect(self, 0, 0, width, height, 0, false);
    }
    // use standard rounded corners
    else
    {
      cogl_path_round_rectangle(0, 0,
                                width,
                                height,
                                volt_actor_get_rc_radius(self, VOLT_ACTOR_PROP_RC_RADIUS),
                                volt_actor_get_rc_arc_step(self, VOLT_ACTOR_PROP_RC_ARC_STEP));
    }

    cogl_clip_push_from_path();
  }
  else
  {
    cogl_clip_push_rectangle (0, 0, width, height);
  }
}

/**
 * volt_actor_set_clip_to_shape: Sets whether the actor's children will be clipped to its
 *   shape.  Used instead of clutter_actor_set_clip_to_alloction() for cropOverflow
 *   so we can handle an actor with rounded corners and avoid clipping decorations such as
 *   the borders and shadows.
 *
 * @author jim (7/22/2014)
 *
 * @param self The actor instance
 * @param clip_set TRUE if clip to shape (cropOverflow) is to be enabled.
 */
void volt_actor_set_clip_to_shape(VoltActor *self, gboolean clip_set)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (clip_set != priv->clip_to_shape)
  {
    priv->clip_to_shape = clip_set;
    volt_actor_update(self);
  }
}

/**
 * volt_actor_get_clip_to_shape: Returns TRUE if clipping to shape is enabled.
 *
 * @author jim (7/22/2014)
 *
 * @param self The actor instance
 *
 * @return gboolean TRUE if clipping to shape (cropOverflow) is enabled.
 */
gboolean volt_actor_get_clip_to_shape(VoltActor *self)
{
  g_return_val_if_fail(IS_VOLT_ACTOR(self), FALSE);

  VoltActorPrivate* priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);
  return priv->clip_to_shape;
}

/**
 * _volt_actor_calculate_transformed_depth - calculate the actor's depth transformed
 * to stage coordinates based on the geometric center of the actor.
 *
 * @author jim (8/18/2014)
 *
 * @param self the actor instance
 *
 * @return gfloat the depth (z) of the actor in stage coordinates.
 */
static gfloat _volt_actor_calculate_transformed_depth(VoltActor *self)
{
  g_return_val_if_fail(IS_VOLT_ACTOR(self), 0.0f);

  gfloat width, height;
  clutter_actor_get_size (CLUTTER_ACTOR(self), &width, &height);

  ClutterVertex localCenter;
  localCenter.x = width / 2;
  localCenter.y = height / 2;
  localCenter.z = 0;

  ClutterVertex stageCenter;
  ClutterActor* stage = clutter_actor_get_stage(CLUTTER_ACTOR(self));
  clutter_actor_apply_relative_transform_to_point(CLUTTER_ACTOR(self), stage, &localCenter,
      &stageCenter);
  return stageCenter.z;
}

/**
 * volt_actor_set_auto_sort_children_by_depth - set the auto sort children by depth flag
 *
 * @author jim (8/18/2014)
 *
 * @param self the actor instance
 * @param auto_sort_children_by_depth the desired state of the auto sort children by depth feature
 */
void volt_actor_set_auto_sort_children_by_depth(VoltActor *self, gboolean auto_sort_children_by_depth)
{
  VoltActorPrivate *priv;

  g_return_if_fail(IS_VOLT_ACTOR(self));

  priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);

  if (auto_sort_children_by_depth != priv->auto_sort_children_by_depth)
  {
    priv->auto_sort_children_by_depth = auto_sort_children_by_depth;
  }

  volt_actor_update(self);
}

/**
 * volt_actor_get_auto_sort_children_by_depth - return the auto sort children by depth flag
 *
 * @author jim (8/18/2014)
 *
 * @param self the actor instance
 *
 * @return gboolean the value of the auto sort children by depth flag.
 */
gboolean volt_actor_get_auto_sort_children_by_depth(VoltActor *self)
{
  g_return_val_if_fail(IS_VOLT_ACTOR(self), FALSE);

  VoltActorPrivate* priv = VOLT_ACTOR_TYPE_GET_PRIVATE(self);
  return priv->auto_sort_children_by_depth;
}

/**
 * volt_actor_get_transformed_depth - returns the transfomed depth in stage coordinates
 * of the center point of the actor
 *
 * @author jim (8/12/2014)
 *
 * @param self the actor instance
 *
 * @return gfloat the transformed depth in stage coordinates of the center point of the actor.
 */
gfloat volt_actor_get_transformed_depth(VoltActor *self)
{
  g_return_val_if_fail(IS_VOLT_ACTOR(self), 0.0f);
  return _volt_actor_calculate_transformed_depth(self);
}

/**
 * volt_actor_create_transition:
 * @actor: a #VoltActor
 * @propNameOverride: If not NULL, a char string with the
 *                  property name to override the default name
 *                  taken from the pspec, used for effects
 *                  properties and others with name in the form
 *                  of
 *                  "@<section>.<meta-name>.<property-name>"
 * @actorTransitionName: If not NULL, a char string with the
 *                name to use instead of pspec->name when adding
 *                the transition to the actor and must be unique
 *                for the actor.
 *
 * @pspec: A #GParamSpec containing the parameter to be
 * animated.
 *
 * @...: must contain two arguments, initial and final values,
 * and can be of any type convertable to GValue (both of the
 * same one)
 *
 * Creates a transition for implicit animation of properties on
 * actors and meta actors.
 *
 * Return value: a #ClutterTransition created for the animation.
 */

ClutterTransition *
volt_actor_create_transition (VoltActor *sActor,
                              const char *propNameOverride,
                              const char *actorTransitionName,
                              GParamSpec   *pspec,
                              ...)
{
  ClutterActor *actor = CLUTTER_ACTOR(sActor);
  g_assert(clutter_actor_get_easing_duration(actor) != 0);

  ClutterTimeline *timeline;
  ClutterInterval *interval;
  ClutterTransition *transition = NULL;
  va_list var_args;
  GValue initial = G_VALUE_INIT;
  GValue final = G_VALUE_INIT;
  GType ptype;
  char *error;

  g_assert (pspec != NULL);

  va_start (var_args, pspec);

  ptype = G_PARAM_SPEC_VALUE_TYPE (pspec);

  G_VALUE_COLLECT_INIT (&initial, ptype,
                        var_args, 0,
                        &error);

  if (error != NULL)
  {
    g_critical ("%s: %s", G_STRLOC, error);
    g_free (error);
    goto out;
  }

  G_VALUE_COLLECT_INIT (&final, ptype,
                        var_args, 0,
                        &error);

  if (error != NULL)
  {
    g_critical ("%s: %s", G_STRLOC, error);
    g_value_unset (&initial);
    g_free (error);
    goto out;
  }

  transition = clutter_actor_get_transition(actor, actorTransitionName ? actorTransitionName : pspec->name);

  if (transition == NULL)
  {
    interval = clutter_interval_new_with_values (ptype, &initial, &final);

    transition = clutter_property_transition_new (propNameOverride ?
                 propNameOverride : pspec->name);

    clutter_transition_set_interval (transition, interval);
    clutter_transition_set_remove_on_complete (transition, TRUE);

    timeline = CLUTTER_TIMELINE (transition);
    clutter_timeline_set_delay (timeline, clutter_actor_get_easing_delay(actor));
    clutter_timeline_set_duration (timeline, clutter_actor_get_easing_duration(actor));
    clutter_timeline_set_progress_mode (timeline, clutter_actor_get_easing_mode(actor));

#ifdef CLUTTER_ENABLE_DEBUG
    {
      gchar *initial_v, *final_v;

      initial_v = g_strdup_value_contents (&initial);
      final_v = g_strdup_value_contents (&final);

      CLUTTER_NOTE (ANIMATION,
                    "Created transition for %s:%s "
                    "(len:%u, mode:%d, delay:%u) "
                    "initial:%s, final:%s",
                    clutter_actor_get_name (actor),
                    pspec->name,
                    clutter_actor_get_easing_duration(actor),
                    clutter_actor_get_easing_mode(actor),
                    clutter_actor_get_easing_delay(actor),
                    initial_v, final_v);

      g_free (initial_v);
      g_free (final_v);
    }
#endif /* CLUTTER_ENABLE_DEBUG */

    /* this will start the transition as well */
    clutter_actor_add_transition (actor, actorTransitionName ?
                                  actorTransitionName : pspec->name, transition);

    /* the actor now owns the transition */
    g_object_unref (transition);

    g_value_unset (&initial);
    g_value_unset (&final);
  }
  else // transition != NULL
  {
    ClutterAnimationMode cur_mode;
    guint cur_duration;

#ifdef CLUTTER_ENABLE_DEBUG
    CLUTTER_NOTE (ANIMATION, "Existing transition for %s:%s",
                  clutter_actor_get_name (actor),
                  pspec->name);
#endif
    timeline = CLUTTER_TIMELINE (transition);

    guint new_duration = clutter_actor_get_easing_duration(actor);
    cur_duration = clutter_timeline_get_duration (timeline);

    if (cur_duration != new_duration)
    {
      clutter_timeline_set_duration (timeline, new_duration);
    }

    ClutterAnimationMode new_mode = clutter_actor_get_easing_mode(actor);
    cur_mode = clutter_timeline_get_progress_mode (timeline);

    if (cur_mode != new_mode)
    {
      clutter_timeline_set_progress_mode (timeline, new_mode);
    }

    clutter_timeline_rewind (timeline);

    interval = clutter_transition_get_interval (transition);
    clutter_interval_set_initial_value (interval, &initial);
    clutter_interval_set_final_value (interval, &final);
  }

out:
  va_end (var_args);

  return transition;
}


/**
 * volt_actor_new:
 *
 * Creates a new #VoltActor instance
 *
 * Returns: a new #VoltActor
 */
ClutterActor *
volt_actor_new (void)
{
  return CLUTTER_ACTOR(g_object_new (VOLT_ACTOR_TYPE, NULL));
}

gboolean volt_actor_has_custom_corner(VoltActor *voltActor)
{
  VoltActorPrivate* priv = VOLT_ACTOR_TYPE_GET_PRIVATE(voltActor);

  if (priv->custom_corner_tl || priv->custom_corner_tr ||
      priv->custom_corner_bl || priv->custom_corner_br)
  {
    return TRUE;
  }

  return FALSE;
}

void volt_actor_custom_rounded_rect(VoltActor *voltActor, float origin_x, float origin_y,
                                    float width, float height,
                                    float border_width, gboolean draw_footprint)
{
  // tLeft
  float radius_1 = 0;
  float arc_step_1 = 0;

  // tRight
  float radius_2 = 0;
  float arc_step_2 = 0;

  // bLeft
  float radius_3 = 0;
  float arc_step_3 = 0;

  // bRight
  float radius_4 = 0;
  float arc_step_4 = 0;

  VoltActorPrivate* priv = VOLT_ACTOR_TYPE_GET_PRIVATE(voltActor);

  // we will determine if a corner has been set
  // if it is, we will us custom values, otherwise
  // we use the default, and if default has not been set
  // we will draw 90 angle corners

  // top left
  if(priv->custom_corner_tl)
  {
    radius_1 = priv->rc_tl_radius;
    arc_step_1 = priv->rc_tl_arc_step;
  }
  else if(priv->default_corner)
  {
    radius_1 = priv->rc_radius;
    arc_step_1 = priv->rc_arc_step;
  }

  // top right
  if(priv->custom_corner_tr)
  {
    radius_2 = priv->rc_tr_radius;
    arc_step_2 = priv->rc_tr_arc_step;
  }
  else if(priv->default_corner)
  {
    radius_2 = priv->rc_radius;
    arc_step_2 = priv->rc_arc_step;
  }

  // bottom left;
  if(priv->custom_corner_bl)
  {
    radius_3 = priv->rc_bl_radius;
    arc_step_3 = priv->rc_bl_arc_step;
  }
  else if(priv->default_corner)
  {
    radius_3 = priv->rc_radius;
    arc_step_3 = priv->rc_arc_step;
  }

  // bottom right;
  if(priv->custom_corner_br)
  {
    radius_4 = priv->rc_br_radius;
    arc_step_4 = priv->rc_br_arc_step;
  }
  else if(priv->default_corner)
  {
    radius_4 = priv->rc_radius;
    arc_step_4 = priv->rc_arc_step;
  }

  if(draw_footprint)
  {
    // paint the entire footprint of the object which includes the border width
    volt_actor_custom_rounded_rect_draw(origin_x,  origin_y,
                                        width,     height,
                                        radius_1 + border_width,  arc_step_1, // tLeft
                                        radius_2 + border_width,  arc_step_2, // tRight
                                        radius_3 + border_width,  arc_step_3, // bLeft
                                        radius_4 + border_width,  arc_step_4); // bRight
  }
  else
  {
    // normal path, without border
    volt_actor_custom_rounded_rect_draw(origin_x,  origin_y,
                                        width,     height,
                                        radius_1,  arc_step_1, // tLeft
                                        radius_2,  arc_step_2, // tRight
                                        radius_3,  arc_step_3, // bLeft
                                        radius_4,  arc_step_4); // bRight

    // paint the outer path when border is present and only space between the inner and outer will be painted
    if(border_width > 0)
    {
      volt_actor_custom_rounded_rect_draw(origin_x - border_width,  origin_y - border_width,
                                          width + border_width * 2, height + border_width * 2,
                                          radius_1 + border_width,  arc_step_1, // tLeft
                                          radius_2 + border_width,  arc_step_2, // tRight
                                          radius_3 + border_width,  arc_step_3, // bLeft
                                          radius_4 + border_width,  arc_step_4); // bRight
    }
  }
}

void volt_actor_custom_rounded_rect_draw(float origin_x, float origin_y,
    float width,    float height,
    float radius_1, float arc_step_1, // tLeft
    float radius_2, float arc_step_2, // tRight
    float radius_3, float arc_step_3, // bLeft
    float radius_4, float arc_step_4) // bRight
{
  // if arc_step is 0 then radius is meaningless
  if (arc_step_1 == 0)
  {
    radius_1 = 0;
  }

  if (arc_step_2 == 0)
  {
    radius_2 = 0;
  }

  if (arc_step_3 == 0)
  {
    radius_3 = 0;
  }

  if (arc_step_4 == 0)
  {
    radius_4 = 0;
  }

  float top_width = width - radius_1 - radius_2;
  float bottom_width = width - radius_3 - radius_4;
  float right_height = height - radius_2 - radius_4;

  float arc_x = origin_x;
  float arc_y = origin_y;

  cogl_path_move_to(origin_x, origin_y + radius_1);

  // top left
  if(radius_1 != 0)
  {
    volt_actor_arc_path (origin_x + radius_1, origin_y + radius_1,
                         radius_1, radius_1,
                         180, 270,
                         arc_step_1,
                         &arc_x, &arc_y);
  }

  cogl_path_rel_line_to (top_width, 0);
  arc_x += top_width;

  // top right
  if(radius_2 != 0)
  {
    volt_actor_arc_path (arc_x, arc_y + radius_2,
                         radius_2, radius_2,
                         -90, 0,
                         arc_step_2,
                         &arc_x, &arc_y);
  }

  cogl_path_rel_line_to (0, right_height);
  arc_y += right_height;

  // bottom right
  if(radius_4 != 0)
  {
    volt_actor_arc_path (arc_x - radius_4, arc_y,
                         radius_4, radius_4,
                         0, 90,
                         arc_step_4,
                         &arc_x, &arc_y);
  }

  cogl_path_rel_line_to(-bottom_width, 0);
  arc_x -= bottom_width;

  // bottom left
  if(radius_3 != 0)
  {
    volt_actor_arc_path (arc_x, arc_y - radius_3,
                         radius_3, radius_3,
                         90, 180,
                         arc_step_3,
                         &arc_x, &arc_y);
  }

  cogl_path_close();
}

void volt_actor_arc_path(float center_x, float center_y,
                         float radius_x, float radius_y,
                         float angle_1, float angle_2,
                         float angle_step,
                         float *final_x, float *final_y)
{
  float a = 0x0;
  float cosa = 0x0;
  float sina = 0x0;
  float px = 0x0;
  float py = 0x0;

  /* Fix invalid angles */

  if (angle_1 == angle_2 || angle_step == 0x0)
  {
    return;
  }

  if (angle_step < 0x0)
  {
    angle_step = -angle_step;
  }

  /* Walk the arc by given step */

  a = angle_1;

  while (a != angle_2)
  {
    cosa = cosf (a * (G_PI/180.0));
    sina = sinf (a * (G_PI/180.0));

    px = center_x + (cosa * radius_x);
    py = center_y + (sina * radius_y);

    cogl_path_line_to (px, py);

    if (G_LIKELY (angle_2 > angle_1))
    {
      a += angle_step;

      if (a > angle_2)
      {
        a = angle_2;
      }
    }
    else
    {
      a -= angle_step;

      if (a < angle_2)
      {
        a = angle_2;
      }
    }
  }

  /* Make sure the final point is drawn */
  cosa = cosf (angle_2 * (G_PI/180.0));
  sina = sinf (angle_2 * (G_PI/180.0));

  px = center_x + (cosa * radius_x);
  py = center_y + (sina * radius_y);

  cogl_path_line_to(px, py);

  if(final_x)
  {
    *final_x = px;
  }

  if(final_y)
  {
    *final_y = py;
  }
}
