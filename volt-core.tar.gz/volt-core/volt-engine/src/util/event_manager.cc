#include "event_manager.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <glib.h>

#include "logger.h"

namespace volt
{
namespace util
{

/******************************************************************************
 * EventManager
 *****************************************************************************/

std::string EventManager::LOGGER_NAME = "volt.util.event";

EventManager& EventManager::Instance()
{
  static EventManager singleton;
  return singleton;
}

EventManager::EventManager():
  logger_(LOGGER_NAME), thread_(), event_checker_(), stage_(NULL),
  remote_control_callback_(NULL), remote_control_user_data_(NULL),
  mouse_callback_(NULL), mouse_user_data_(NULL),
  flick_callback_(NULL), flick_user_data_(NULL),
  show_event_handler_(NULL), hide_event_handler_(NULL)
{
}

EventManager::~EventManager()
{
  if (thread_.joinable())
  {
    thread_.join();
  }
}

void EventManager::SetStage(ClutterStage *aStage)
{
  stage_ = aStage;
}

void EventManager::SetRemoteControlEventCallback(GSourceFunc aCallback,
    void *aUserData)
{
  remote_control_callback_ = aCallback;
  remote_control_user_data_ = aUserData;
}

void EventManager::SetMouseEventCallback(GSourceFunc aCallback,
    void *aUserData)
{
  mouse_callback_ = aCallback;
  mouse_user_data_ = aUserData;
}

void EventManager::SetFlickEventCallback(GSourceFunc aCallback,
    void *aUserData)
{
  flick_callback_ = aCallback;
  flick_user_data_ = aUserData;
}

void EventManager::SetShowHideEventHandlers(GSourceFunc aShowHandler,
    void *aShowHandlerArg,
    GSourceFunc aHideHandler,
    void *aHideHandlerArg)
{
  show_event_handler_ = aShowHandler;
  show_event_handler_arg_ = aShowHandlerArg;
  hide_event_handler_ = aHideHandler;
  hide_event_handler_arg_ = aHideHandlerArg;
}

void EventManager::StartEventCheckThread(ClutterStage *aStage,
    GSourceFunc aCallback,
    void *aUserData)
{
  /* Start the event checking thread */
  event_checker_.set_stage(aStage);

  if (aCallback == DefaultRemoteControlCallback)
  {
    aUserData = this;
  }

  event_checker_.set_callback(aCallback, aUserData);
  thread_ = std::thread(std::ref(event_checker_));

  stage_ = aStage;
  remote_control_callback_ = aCallback;
  remote_control_user_data_ = aUserData;
}

void EventManager::StopEventCheckThread()
{
  /* Stop the event checking thread. */
  LOG_DEBUG(logger_, "Stopping worker thread");
  event_checker_.Stop();
}

void EventManager::JoinEventCheckThread()
{
  if (thread_.joinable())
  {
    LOG_DEBUG(logger_, "Joining worker thread");
    thread_.join();
  }
}

void EventManager::HandleEvent(const int aType, const int aCode)
{
  if (remote_control_callback_ == NULL)
  {
    LOG_DEBUG(logger_, "No callback registered; ignoring event type " << aType);
    return;
  }

  if (aType == EVENT_KEY_PRESS || aType == EVENT_KEY_RELEASE)
  {
    ClutterEvent *event = clutter_event_new(CLUTTER_NOTHING);

    if (aType == EVENT_KEY_PRESS)
    {
      event->key.type = CLUTTER_KEY_PRESS;
    }
    else
    {
      event->key.type = CLUTTER_KEY_RELEASE;
    }

    event->key.hardware_keycode = aCode;
    event->key.stage = stage_;
    event->key.time = time(NULL);

    CallbackData *data = new CallbackData();
    data->event = event;
    data->user_data = remote_control_user_data_;

    clutter_threads_add_idle_full(G_PRIORITY_HIGH_IDLE,
                                  remote_control_callback_, data, NULL);
  }
  else
  {
    LOG_DEBUG(logger_, "Ignoring event type " << aType);
  }
}

void EventManager::HandleMouseEvent(const EVENT_TYPE aType,
                                    const MOUSE_BUTTON aButton,
                                    const unsigned int aX,
                                    const unsigned int aY)
{
  if (mouse_callback_ == NULL)
  {
    LOG_DEBUG(logger_, "No callback registered; ignoring event type " << aType);
    return;
  }

  ClutterEvent *event = NULL;

  if (aType == EVENT_MOUSE_PRESS)
  {
    event = clutter_event_new(CLUTTER_BUTTON_PRESS);
  }
  else if (aType == EVENT_MOUSE_RELEASE)
  {
    event = clutter_event_new(CLUTTER_BUTTON_RELEASE);
  }

#if 1
  else if (aType == EVENT_MOUSE_MOVE)
  {
    event = clutter_event_new(CLUTTER_MOTION);
  }

#endif
  else
  {
    LOG_WARN(logger_, "Unsupported mouse event type " << aType);
    return;
  }

  LOG_WARN(logger_, "Creating mouse event type " << aType <<
           "with button " << aButton << " @ (" << aX << ", " << aY << ")");
  clutter_event_set_stage(event, CLUTTER_STAGE(stage_));
  clutter_event_set_time(event, time(NULL));
  clutter_event_set_button(event, aButton);
  clutter_event_set_coords(event, aX, aY);
#if 0
  clutter_event_put(event); /* is this thread safe? */
  clutter_event_free(event);
#else
  CallbackData *data = new CallbackData();
  data->event = event;
  data->user_data = mouse_user_data_;

  clutter_threads_add_idle_full(G_PRIORITY_HIGH_IDLE,
                                mouse_callback_, data, NULL);
#endif
}

void EventManager::HandleFlickEvent(const MOUSE_FLICK aFlick)
{
  if (flick_callback_ == NULL)
  {
    LOG_DEBUG(logger_, "No callback registered; ignoring event type " << aFlick);
    return;
  }

  ClutterEvent *event = clutter_event_new(CLUTTER_KEY_PRESS);
  clutter_event_set_key_code(event, aFlick);

  CallbackData *data = new CallbackData();
  data->event = event;
  data->user_data = flick_user_data_;

  clutter_threads_add_idle_full(G_PRIORITY_HIGH_IDLE,
                                flick_callback_, data, NULL);
}

void EventManager::HandleShow()
{
  if (show_event_handler_ == NULL)
  {
    LOG_DEBUG(logger_, "No show handler registered");
    return;
  }

  clutter_threads_add_idle_full(G_PRIORITY_HIGH_IDLE,
                                show_event_handler_, show_event_handler_arg_,
                                NULL);
}

void EventManager::HandleHide()
{
  if (hide_event_handler_ == NULL)
  {
    LOG_DEBUG(logger_, "No hide handler registered");
    return;
  }

  clutter_threads_add_idle_full(G_PRIORITY_HIGH_IDLE,
                                hide_event_handler_, hide_event_handler_arg_,
                                NULL);
}

int EventManager::DefaultRemoteControlCallback(void *aCallbackData)
{
  Logger logger(EventManager::LOGGER_NAME);

  CallbackData *data = reinterpret_cast<CallbackData *>(aCallbackData);
  ClutterEvent *event = data->event;

  event->key.keyval = event->key.hardware_keycode;

  LOG_DEBUG(logger, "put event " << event->key.keyval);
  clutter_event_put(event);

  delete data; /* this will clean the event too */

  return 0;
}

MOUSE_FLICK EventManager::VoltFlickEvent(const int aTvFlick)
{
  switch (aTvFlick)
  {
  case 1:
    return MOUSE_FLICK_UP;
  case 2:
    return MOUSE_FLICK_DOWN;
  case 3:
    return MOUSE_FLICK_LEFT;
  case 4:
    return MOUSE_FLICK_RIGHT;
  default:
    return MOUSE_FLICK_INVALID;
  }
}

/******************************************************************************
 * EventManager::EventChecker
 *****************************************************************************/

EventManager::EventChecker::EventChecker():
  running_(0), stage_(NULL), remote_control_callback_(NULL),
  remote_control_user_data_(NULL)
{
}

void EventManager::EventChecker::Stop()
{
  /* This should be an atomic operation. */
  running_ = 0;
}

void EventManager::EventChecker::set_stage(ClutterStage *aStage)
{
  stage_ = aStage;
}

void EventManager::EventChecker::set_callback(GSourceFunc aCallback,
    void *aUserData)
{
  remote_control_callback_ = aCallback;
  remote_control_user_data_ = aUserData;
}

void EventManager::EventChecker::operator()()
{
  Logger logger(EventManager::LOGGER_NAME);

  /* TODO: Just include LauncherAppCommon.h! */
  struct
  {
    unsigned long type;
    int key_code;
  } ir_event;

  char fifo_path[PATH_MAX];
  /* Parent PID assuming executed from a wrapper script. */
  snprintf(fifo_path, PATH_MAX, "/mtd_down/launcher/fifo_%d", getppid());
  LOG_DEBUG(logger, "Opening pipe: " << fifo_path);

  int fifo_fd = open(fifo_path, O_RDONLY);

  for (int retry = 0; fifo_fd < 0 && retry < 10; ++retry)
  {
    usleep(10 * 1000); /* 10 ms */
    fifo_fd = open(fifo_path, O_RDONLY);
  }

  if (fifo_fd < 0)
  {
    LOG_ERROR(logger, "Failed to open pipe: " << fifo_path);
    return;
  }

  LOG_DEBUG(logger, "Opened pipe: " << fifo_path);

  int num_read = 0;

  /*
   * Currently timing out every 1 sec to check for the running_ flag.
   * Ideally it should also be signaled thru a socket/fd that can be
   * caught by select/epoll.
   */
  int mseconds = 1000;
  struct timeval timeout = { 0, 0 };
  struct timeval *timeout_ptr = NULL;

  if (mseconds >= 0)
  {
    timeout_ptr = &timeout;
  }

  fd_set readset;

  int max_fd = fifo_fd;

  running_ = 1;

  while (running_) /* the main loop. */
  {
    LOG_DEBUG(logger, "Waiting for data");

    timeout.tv_sec = mseconds / 1000;
    timeout.tv_usec = (mseconds % 1000) * 1000;
    FD_ZERO(&readset);
    FD_SET(fifo_fd, &readset);

    int retval = select(max_fd + 1,
                        &readset, NULL, NULL, timeout_ptr);

    if (retval > 0)
    {
      if (fifo_fd >= 0 && FD_ISSET(fifo_fd, &readset))
      {
        LOG_DEBUG(logger, "Data ready");

        if ((num_read = read(fifo_fd, &ir_event, sizeof(ir_event))) == -1)
        {
          perror("read");
        }
        else if (num_read == 0)
        {
          LOG_DEBUG(logger, "No data; EOF");
        }
        else if (num_read != sizeof(ir_event))
        {
          LOG_WARN(logger, "Unexpected size: " <<
                   num_read << " != " << sizeof(ir_event));
        }
        else if (remote_control_callback_ == NULL)
        {
          LOG_DEBUG(logger, "No callback registered; ignoring event");
        }
        else
        {
          EventManager::Instance().HandleEvent(ir_event.type,
                                               ir_event.key_code);
        }
      }
      else
      {
        LOG_WARN(logger, "Shouldn't be here");
      }
    }
    else if (retval == 0)
    {
      LOG_DEBUG(logger, "Timed out waiting for data");
    }
    else
    {
      LOG_ERROR(logger, "Error waiting for data");
    }
  }

  close(fifo_fd);

  LOG_INFO(logger, "Event check thread done");
}

} /* namespace util */
} /* namespace volt */
