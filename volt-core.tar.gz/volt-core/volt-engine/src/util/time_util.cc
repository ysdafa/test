#include "time_util.h"

#include <iostream>
#include <iomanip>
#include "logger.h"

#include <boost/algorithm/string/replace.hpp>

namespace volt
{
namespace util
{
static Logger LOGGER("volt.util.time");
static const int NUM_OF_DAYS = 7;
static const int NUM_OF_MONTHS = 12;
static const char* DAYS[NUM_OF_DAYS] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
static const char* MONTHS[NUM_OF_MONTHS] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul",
       				"Aug", "Sep", "Oct", "Nov", "Dec" };

//Note: strftime is locale dependent and therefore we need
//to add the months/days ourselves.
static void UpdateDayMonthOfHttpTimeString(std::string& date, const struct tm& tm)
{ 
  boost::replace_first(date, "[DAY]", DAYS[tm.tm_wday]); 
  boost::replace_first(date, "[MONTH]", MONTHS[tm.tm_mon]);
  LOG_DEBUG(LOGGER, "Updated HttpTimeString = " << date); 
}

static int containsDay(const std::string& date)
{
  for (int i = 0; i < NUM_OF_DAYS; ++i)
  {
    if (strstr(date.c_str(), DAYS[i]) != NULL)
    {
	return i;
    } 
  }

  return -1;
}

static int containsMonth(const std::string& date)
{
  for (int i = 0; i < NUM_OF_MONTHS; ++i)
  {
    if (strstr(date.c_str(), MONTHS[i]) != NULL)
    {
	return i;
    } 
  }

  return -1;
}

static std::string removeDayMonth(std::string date, const int dayIndex, const int monthIndex)
{
  const std::string DAY_TO_REMOVE(DAYS[dayIndex]);
  const std::string MONTH_TO_REMOVE(MONTHS[monthIndex]);

  boost::replace_first(date, DAY_TO_REMOVE, "[DAY]");
  boost::replace_first(date, MONTH_TO_REMOVE, "[MONTH]");

  return date;

}

static Time DefaultNowFunction()
{
#if 0
  struct timeval tv;
  if (gettimeofday(&tv, nullptr) == 0)
  {
    return Time(tv.tv_sec, tv.tv_usec);
  }
  else
  {
    return Time(0, 0);
  }
#else
  struct tm tm;
  time_t curr_ts = time(NULL);

  static uint8_t dst_flag = 0;
  static uint8_t mask_dst_true = 0x01;
  static uint8_t mask_dst_checked = 0x80;
  static uint8_t mask_is_dst = mask_dst_true | mask_dst_checked;

  if ((mask_dst_checked & dst_flag) == 0)
  {
    /* Check for DST by getting the local time. */
    if (localtime_r(&curr_ts, &tm))
    {
      if (tm.tm_isdst)
      {
        LOG_DEBUG(LOGGER, "DST!");
        dst_flag |= mask_dst_true;
      }
    }
    dst_flag |= mask_dst_checked;
  }

  struct timeval tv;
  gettimeofday(&tv, NULL);

  if (gmtime_r(&curr_ts, &tm))
  {
    /* Get UTC/GMT. */
    if ((dst_flag & mask_is_dst) == mask_is_dst)
    {
      /* Adjust for DST. */
      return Time(mktime(&tm) - (60 * 60), tv.tv_usec);
    }
    else
    {
      return Time(mktime(&tm), tv.tv_usec);
    }
  }
  else
  {
    return Time::Epoch();
  }
#endif
}

static Time LocalNowFunction()
{

	time_t curTime = time(NULL);
	struct tm tm;
	memset(&tm, 0, sizeof(struct tm));
	localtime_r(&curTime, &tm);
	return Time(mktime(&tm));

}
std::function<Time ()> Time::NowFunction = LocalNowFunction;

Time::Time():
  time_{0, 0}, valid_(false)
{
}

Time::Time(const time_t aSec, const suseconds_t aUsec):
  time_{aSec, aUsec}, valid_(true)
{
}

Time::Time(const Time &aSrc):
  time_{aSrc.Sec(), aSrc.Usec()}, valid_(aSrc.valid_)
{
}

Time::~Time()
{
}

bool Time::IsValid() const
{
  return valid_;
}

time_t Time::Sec() const
{
  return time_.tv_sec;
}

suseconds_t Time::Usec() const
{
  return time_.tv_usec;
}

bool Time::ParseHttpTime(const std::string &aHttpTime)
{
  /* As per RFC 2616 */
  static const char *rfc1123_format = "[DAY], %d [MONTH] %Y %H:%M:%S GMT";
  static const char *rfc1036_format = "[DAY], %d-[MONTH]-%y %H:%M:%S GMT";
  static const char *asctime_format = "[DAY] [MONTH] %d %H:%M:%S %Y";

  valid_ = false;

  struct tm tm;
  memset(&tm, 0, sizeof(struct tm));

  //verify day exists
  const int dayIndex = containsDay(aHttpTime);
  if (dayIndex == -1)
  {
    LOG_ERROR(LOGGER, "Failed to parse date, missing 'Day': " << aHttpTime);
    return false;
  }

  //verify month exists
  const int monthIndex = containsMonth(aHttpTime);
  if (monthIndex == -1)
  {
    LOG_ERROR(LOGGER, "Failed to parse date, missing 'Month': " << aHttpTime);
    return false;
  }

  //remove day+month from aHttpTime for locale-indepedent strptime
  const std::string aHttpTimeMod = removeDayMonth(aHttpTime, dayIndex, monthIndex);

  LOG_DEBUG(LOGGER, "original date = " << aHttpTime);
  LOG_DEBUG(LOGGER, "date with day+month removed = " << aHttpTimeMod);

  if (strptime(aHttpTimeMod.c_str(), rfc1123_format, &tm) == NULL)
  {
    if (strptime(aHttpTimeMod.c_str(), rfc1036_format, &tm) == NULL)
    {
      if (strptime(aHttpTimeMod.c_str(), asctime_format, &tm) == NULL)
      {
        LOG_ERROR(LOGGER, "Failed to parse date: " << aHttpTimeMod);
        return false;
      }
    }
  }

  tm.tm_mon = monthIndex; //update month manually.
  time_.tv_sec = (int)timegm(&tm);//process time in UTC
  time_.tv_usec = 0;

  valid_ = true;

  LOG_DEBUG(LOGGER, "Parsed " << aHttpTime << ": " << time_.tv_sec << ":" << time_.tv_usec);

  return true;
}

std::string Time::HttpTimeString() const
{
  /* As per RFC 2616 */
  static const char *rfc1123_format = "[DAY], %d [MONTH] %Y %H:%M:%S GMT";

  std::string result;

  time_t sec = time_.tv_sec;
  struct tm tm;
  memset(&tm, 0, sizeof(struct tm));
  char buf[64];
  if (gmtime_r(&sec, &tm) &&
      strftime(buf, sizeof(buf), rfc1123_format, &tm) != 0)
  {
    result = buf;
    UpdateDayMonthOfHttpTimeString(result,tm);//replace fillers with actual text
  }
  else
  {
    LOG_WARN(LOGGER, "Failed to generated HTTP time string from " << *this);
  }
  return result;
}

Time Time::Epoch()
{
  static Time epoch(0, 0);
  return epoch;
}

Time Time::Now()
{
  return NowFunction();
}

bool Time::operator<(const Time &aRhs) const
{
  return timercmp(&time_, &(aRhs.time_), <);
}

bool Time::operator<=(const Time &aRhs) const
{
  return (*this > aRhs) == false;
}

bool Time::operator>(const Time &aRhs) const
{
  return timercmp(&time_, &(aRhs.time_), >);
}

bool Time::operator>=(const Time &aRhs) const
{
  return (*this < aRhs) == false;
}

bool Time::operator==(const Time &aRhs) const
{
  return (*this != aRhs) == false;
}

bool Time::operator!=(const Time &aRhs) const
{
  return timercmp(&time_, &(aRhs.time_), !=);
}

Time& Time::operator=(const Time &aRhs)
{
  if (this != &aRhs)
  {
    time_ = aRhs.time_;
    valid_ = aRhs.valid_;
  }
  return *this;
}

Time& Time::operator+=(const Time &aRhs)
{
  if (this != &aRhs)
  {
    struct timeval result;
    timeradd(&time_, &(aRhs.time_), &result);
    time_ = result;
  }
  return *this;
}

Time& Time::operator-=(const Time &aRhs)
{
  if (this != &aRhs)
  {
    if (*this < aRhs)
    {
      LOG_WARN(LOGGER, "Reset to epoch since " << *this << " < " << aRhs);
      *this = Epoch();
    }
    else
    {
      struct timeval result;
      timersub(&time_, &(aRhs.time_), &result);
      time_ = result;
    }
  }
  return *this;
}

const Time Time::operator+(const Time &aRhs) const
{
  return (Time(*this) += aRhs);
}

const Time Time::operator-(const Time &aRhs) const
{
  return (Time(*this) -= aRhs);
}

std::ostream& operator<<(std::ostream &aStream, const Time &aTime)
{
  return aStream << aTime.Sec() << "." << std::setprecision(6) << std::fixed << aTime.Usec();
}

std::ostream& operator<<(std::ostream &aStream, const Stopwatch &aStopwatch)
{
  return aStream << std::setprecision(6) << std::fixed << aStopwatch.Elapsed();
}

} /* namespace util */
} /* namespace volt */
