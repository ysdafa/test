/*
 * EventThread.cpp
 *
 *  Created on: Nov 5, 2014
 *      Author: wyee
 */
#include "EventThread.h"

using namespace volt::util;

#define INFINITY 0xFFFFFFFFFFFFF

EventThread::EventThread(std::string name)
: mName(name),
  mEventMutex(),
  mEventQueue(),
  mDeleteMutex(),
  mDeleteQueue(),
  mMainCondition(),
  mIsWaiting(false),
  mMainMutex(),
  mIsRunning(false),
  mIsStarted(false),
  mThread(),
  mWaitTime(INFINITY)
{
}

EventThread::~EventThread()
{
  destroy();
}

void EventThread::start()
{
  mIsStarted = true;
  mThread = std::thread(std::bind(&EventThread::run, this));
}

void EventThread::sendEvent(EventMessage *event)
{
  if(event and (mIsStarted or mIsRunning))
  {
    // add message to queue
    if(event->isPeriodic())
    {
      PeriodicEventMessage *periodic = (PeriodicEventMessage *)event;
      mPeriodicMutex.lock();
      mPeriodicQueue.push_back((PeriodicEventMessage *)event);
      if(mWaitTime > periodic->getTimeUtilExecute())
      {
        mWaitTime = periodic->getTimeUtilExecute();
      }
      mPeriodicMutex.unlock();
    }
    else
    {
      mEventMutex.lock();
      mEventQueue.push_back(event);
      mEventMutex.unlock();
    }
    // let the thread know something happened
    wakeThread();

    // block caller thread if its sync event
    if(event->isSync())
    {
      event->wait();
    }
  }
}

void EventThread::removeEvents(uint64_t id)
{
  EVENT_THREAD_DEBUG_LOG("add to delete queue\n");

  // add delete event to queue
  mDeleteMutex.lock();
  mDeleteQueue.push_back(id);
  mDeleteMutex.unlock();

  wakeThread();
}

void EventThread::destroy()
{
  EVENT_THREAD_DEBUG_LOG("-- destroy\n");
  mIsRunning = false;	// block all new events from comming in
  mIsStarted = false;

  mEventMutex.lock();

  int count = 0;

  // clear out event queue
  for(auto itr = mEventQueue.begin(); itr != mEventQueue.end(); itr++)
  {
    EventMessage *message = *itr;

    if(message)
    {
      count ++;

      // sync message, broadcast its done, caller will perform delete and clean up
      if(message->isSync())
      {
        mEventMutex.unlock();

        message->notify();

    	  mEventMutex.lock();
      }
      // this is async, just delete
      else
      {
        delete message;
      }
    }
  }

  mEventQueue.clear();

  mEventMutex.unlock();

  // clear out periodic queue
  mPeriodicMutex.lock();

  for(auto itr = mPeriodicQueue.begin(); itr != mPeriodicQueue.end(); itr++)
  {
    PeriodicEventMessage *message = *itr;

    if(message)
    {
      count ++;
      delete message;
    }
  }

  mPeriodicMutex.unlock();

  mDeleteMutex.lock();

  mDeleteQueue.clear();

  mDeleteMutex.unlock();

  wakeThread();

  EVENT_THREAD_DEBUG_LOG("destroy complete\n");

  join();
}

bool EventThread::isCurrent()
{
  pthread_t current = pthread_self();
  return (current == mThread.native_handle());
}

void EventThread::join()
{
  if(isCurrent())
  {
    EVENT_THREAD_DEBUG_LOG("ERROR: thread can not join itself! skipping..\n");
    return;
  }

  mThread.join();
}

void EventThread::wakeThread()
{
  // let the thread know something happened
    EVENT_THREAD_DEBUG_LOG("trying to wake thread....\n");

    mIsWaiting = false;

    std::lock_guard<std::mutex> waitLock(mMainMutex);

    mMainCondition.notify_one();
}

void EventThread::threadSleep()
{
  // go to sleep
  mIsWaiting = true;

  std::unique_lock<std::mutex> waitLock(mMainMutex);

  // sleep until we get wake up
  if(mWaitTime == INFINITY)
  {
    EVENT_THREAD_DEBUG_LOG("thread sleep infinity\n");
    mMainCondition.wait(waitLock, [this]{return (mIsWaiting == false);});

  }
  // sleep until time to process the next periodic item
  else
  {
    EVENT_THREAD_DEBUG_LOG("thread going to sleep for %ld\n", mWaitTime);
    mMainCondition.wait_for(waitLock, std::chrono::milliseconds(mWaitTime),
                            [this]
                            {
                              return (mIsWaiting == false);
                            });
  }

  EVENT_THREAD_DEBUG_LOG("thread woke up\n");

  mIsWaiting = false;
}

void EventThread::run()
{
//  pthread_setname_np(pthread_self(), mName.cstr());

  mIsRunning = true;
  EVENT_THREAD_DEBUG_LOG("main thread started\n");

  mLastExecuteTime = std::chrono::system_clock::now();

  while(mIsRunning)
  {
    processMessages();

    threadSleep();
  }
}

void EventThread::processMessages()
{
  // process all of the deletes
  processDeleteQueue();

  // block thread trying to delete current message
  // so we dont seg fault
  mDeleteMutex.lock();

  processPeriodicMessage();

  processEventMessage();

  mDeleteMutex.unlock();
}

void EventThread::processEventMessage()
{
  EventMessage *message = nullptr;
  unsigned queueSize = 0;

  do
  {
    // take message off queue
    mEventMutex.lock();
    queueSize = mEventQueue.size();
    if(queueSize)
    {
      message = mEventQueue.front();
      mEventQueue.pop_front();
    }
    else
    {
      message = nullptr;
    }
    mEventMutex.unlock();

    //process the message
    if(message)
    {
      message->execute();

      // if async, we need to clean up the message
      if(not message->isSync())
      {
        EVENT_THREAD_DEBUG_LOG("processed async message!!\n");
        delete message;
      }
      else
      {
        EVENT_THREAD_DEBUG_LOG("processed sync message!!\n");
      }
    }
    else
    {
      return;
    }
  } while(queueSize);
}

void EventThread::processPeriodicMessage()
{
  PeriodicEventMessage *message = nullptr;

  std::chrono::system_clock::time_point now = std::chrono::system_clock::now();

  // take message off queue
  mPeriodicMutex.lock();

  uint64_t timeSinceLast = std::chrono::duration_cast<std::chrono::milliseconds>(now - mLastExecuteTime).count();
  uint64_t minWaitTime = INFINITY;

  if(not timeSinceLast)
  {
    mPeriodicMutex.unlock();
    return;
  }

  EVENT_THREAD_DEBUG_LOG("%ld has elapsed \n", timeSinceLast);

  // process all periodic events
  for(auto itor = mPeriodicQueue.begin(); itor != mPeriodicQueue.end();)
  {
    message = *itor;
    if(message)
    {
      message->updateElapsed(timeSinceLast);

      // there are still execution,
      if(message->getExecutionCount())
      {
        // update minimum wait time
        if(message->getTimeUtilExecute() < minWaitTime)
        {
          minWaitTime = message->getTimeUtilExecute();
        }

        // move to next one normally
        itor ++;
      }
      // no more execution remaining
      // erase current message
      else
      {
        delete message;
        itor = mPeriodicQueue.erase(itor);
      }
    }
  }

  // save the current minimal wait time
  if(minWaitTime < mWaitTime)
  {
    mWaitTime = minWaitTime;
  }

  mLastExecuteTime = now;

  mPeriodicMutex.unlock();
}

void EventThread::processDeleteQueue()
{
  // clear delete queue
  while(mIsRunning)
  {
    uint64_t deleteId = 0;

    mDeleteMutex.lock();

    if(mDeleteQueue.size())
    {
      deleteId = mDeleteQueue.front();
      mDeleteQueue.pop_front();
    }
    else
    {
      // we are done.
      mDeleteMutex.unlock();
      return;
    }
    mDeleteMutex.unlock();

    // remove all messages with the id
    if(deleteId)
    {
      deleteFromEventQueue(deleteId);

      deleteFromPeriodicQueue(deleteId);
    }
  }
}

void EventThread::deleteFromEventQueue(uint64_t id)
{
  mEventMutex.lock();

  if(mEventQueue.size() == 0)
  {
    return;
  }

  int deleteCount = 0;

  for(auto itr = mEventQueue.begin(); itr != mEventQueue.end();)
  {
    EventMessage *message = *itr;
    if(message and message->getId() == id)
    {
      deleteCount ++;

      // sync message, broadcast its done,
      // release the caller thread, caller will perform delete
      if(message->isSync())
      {
        message->notify();
      }
      // this is async, just delete
      else
      {
        delete message;
      }

      // get the next element
      itr = mEventQueue.erase(itr);
    }
    else
    {
      itr++;
    }
  }
  mEventMutex.unlock();

  EVENT_THREAD_DEBUG_LOG("-- deleted %d messages\n", deleteCount);
}

void EventThread::deleteFromPeriodicQueue(uint64_t id)
{
  mPeriodicMutex.lock();

  if(mPeriodicQueue.size() == 0)
  {
    return;
  }

  int deleteCount = 0;

  for(auto itr = mPeriodicQueue.begin(); itr != mPeriodicQueue.end();)
  {
    PeriodicEventMessage *message = *itr;

    if(message and message->getId() == id)
    {
      deleteCount ++;

      delete message;

      // get the next element
      itr = mPeriodicQueue.erase(itr);
    }
    else
    {
      itr++;
    }
  }
  mPeriodicMutex.unlock();

  EVENT_THREAD_DEBUG_LOG("-- deleted %d periodic messages\n", deleteCount);
}


