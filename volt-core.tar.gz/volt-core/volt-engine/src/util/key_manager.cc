#include "key_manager.h"
#include <string.h>
#include "logger.h"

#include "XWindowManager.h"

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include "utilX_redefine_fix.h"

// NOT ALL OF THESE ARE TESTED, ENABLE ONLY THE ONES
// WE NEED
static volt::util::KeyMapping keyMap[] =
{
  //TODO VOLT JOYSTICK OK KEY IS TEMPORARILY MAPPED TO UTILX ENTER KEY because UTILX JOYSTICK OK does not work
  // LISA KIM will fix this and VOLT team need to restore to correct mapping
  {volt::util::KEY_JOYSTICK_OK, UTILX_KEY_ENTER},
  //    {volt::util::KEY_JOYSTICK_OK, UTILX_KEY_JOYSTICK_OK}, // temporarily use the one above

  //    {volt::util::KEY_MENU, UTILX_KEY_MENU},
  {volt::util::KEY_JOYSTICK_UP, UTILX_KEY_JOYSTICK_UP},
  {volt::util::KEY_JOYSTICK_DOWN, UTILX_KEY_JOYSTICK_DOWN},
  {volt::util::KEY_JOYSTICK_LEFT, UTILX_KEY_JOYSTICK_LEFT},
  {volt::util::KEY_JOYSTICK_RIGHT, UTILX_KEY_JOYSTICK_RIGHT},
  {volt::util::KEY_3, UTILX_KEY_3},
  {volt::util::KEY_VOLUP, UTILX_KEY_VOLUP},
  {volt::util::KEY_4, UTILX_KEY_4},
  {volt::util::KEY_5, UTILX_KEY_5},
  {volt::util::KEY_6, UTILX_KEY_6},
  {volt::util::KEY_VOLDOWN, UTILX_KEY_VOLDOWN},
  {volt::util::KEY_7, UTILX_KEY_7},
  {volt::util::KEY_8, UTILX_KEY_8},
  {volt::util::KEY_9, UTILX_KEY_9},
  {volt::util::KEY_MUTE, UTILX_KEY_MUTE},
  //    {volt::util::KEY_CHDOWN, UTILX_KEY_CHDOWN},
  {volt::util::KEY_0, UTILX_KEY_0},
  //    {volt::util::KEY_CHUP, UTILX_KEY_CHUP},
  //    {volt::util::KEY_PRECH , UTILX_KEY_PRECH},
  {volt::util::KEY_GREEN, UTILX_KEY_GREEN},
  {volt::util::KEY_YELLOW, UTILX_KEY_YELLOW},
  {volt::util::KEY_CYAN, UTILX_KEY_CYAN},
  //    {volt::util::KEY_BLUE, UTILX_KEY_BLUE},
  //    {volt::util::KEY_STEP, nullptr},  // TVDP
  //    {volt::util::KEY_DEL, nullptr},
  //    {volt::util::KEY_ADDDEL , UTILX_KEY_ADDDEL},  // ADD/DEL
  //    {volt::util::KEY_SOURCE , UTILX_KEY_SOURCE},  // wayforu - convert  // (TV/VIDEO)
  //    {volt::util::KEY_TV , UTILX_KEY_TV},  // wayforu11
  //    {volt::util::KEY_AUTO , nullptr},
  //    {volt::util::KEY_MOIP , nullptr},
  //    {volt::util::KEY_PMENU , nullptr},
  {volt::util::KEY_INFO , UTILX_KEY_INFO},  // INFO
  //    {volt::util::KEY_PIP_ONOFF , UTILX_KEY_PIP_ONOFF},
  //    {volt::util::KEY_PIP_SWAP , nullptr},
  //    {volt::util::KEY_PIP_ROTATE , nullptr},
  //    {volt::util::KEY_PLUS100 , UTILX_KEY_PLUS100},
  //    {volt::util::KEY_PIP_INPUT , nullptr},
  //    {volt::util::KEY_CAPTION , UTILX_KEY_CAPTION},
  //    {volt::util::KEY_PIP_STILL , nullptr},
  //    {volt::util::KEY_AD , UTILX_KEY_AD},
  //    {volt::util::KEY_PMODE , UTILX_KEY_PMODE},
  //    {volt::util::KEY_SOUND_MODE , nullptr},
  //    {volt::util::KEY_NR , nullptr},  // N/R
  //    {volt::util::KEY_SMODE , UTILX_KEY_SMODE},
  //    {volt::util::KEY_TTX_MIX , UTILX_KEY_TTX_MIX},  // TTX/MIX
  {volt::util::KEY_EXIT , UTILX_KEY_EXIT},
  //    {volt::util::KEY_ENTER , UTILX_KEY_ENTER},
  //    {volt::util::KEY_PIP_SIZE , nullptr},
  //    {volt::util::KEY_MAGIC_CHANNEL , nullptr},
  //    {volt::util::KEY_PIP_SCAN , nullptr},  // SEARCH
  //    {volt::util::KEY_PIP_CHUP , UTILX_KEY_PIP_CHUP},
  //    {volt::util::KEY_PIP_CHDOWN , UTILX_KEY_PIP_CHDOWN},
  //    {volt::util::KEY_DEVICE_CONNECT , nullptr},
  //    {volt::util::KEY_HELP , nullptr},  // CH INFO
  //    {volt::util::KEY_ANTENA , UTILX_KEY_ANTENA},
  //    {volt::util::KEY_CONVERGENCE , UTILX_KEY_CONVERGENCE},
  //    {volt::util::KEY_11 , nullptr},
  //    {volt::util::KEY_12 , nullptr},
  //    {volt::util::KEY_AUTO_PROGRAM , UTILX_KEY_AUTO_PROGRAM},
  //    {volt::util::KEY_FACTORY , UTILX_KEY_FACTORY},
  //    {volt::util::KEY_3SPEED , UTILX_KEY_3SPEED},
  //    {volt::util::KEY_SCROLL_UP , nullptr},
  //    {volt::util::KEY_ASPECT , UTILX_KEY_ASPECT},  // P.SIZE
  //    {volt::util::KEY_EMANUAL , UTILX_KEY_EMANUAL},
  //    {volt::util::KEY_GAME , UTILX_KEY_GAME},
  //    {volt::util::KEY_SCROLL_RIGHT , nullptr},
  //    {volt::util::KEY_STILL_PICTURE , UTILX_KEY_STILL_PICTURE},  // FREEZE
  //    {volt::util::KEY_DTV , UTILX_KEY_DTV},
  //    {volt::util::KEY_FAVCH , UTILX_KEY_FAVCH},  // CH.LIST
  {volt::util::KEY_REWIND , UTILX_KEY_REWIND},
  {volt::util::KEY_STOP , UTILX_KEY_STOP},
  {volt::util::KEY_PLAY , UTILX_KEY_PLAY},
  {volt::util::KEY_FF , UTILX_KEY_FF},
  {volt::util::KEY_REC , UTILX_KEY_REC},
  {volt::util::KEY_PAUSE , UTILX_KEY_PAUSE},
  {volt::util::KEY_TOOLS , UTILX_KEY_TOOLS},
  //    {volt::util::KEY_SCROLL_LEFT , nullptr},
  //    {volt::util::KEY_LINK , UTILX_KEY_LINK},  // MSG, nullptr}, IEEE-1394 D.NET
  {volt::util::KEY_FF_ , UTILX_KEY_FF_},  // ¢º¢º|(TVDP)
  //    {volt::util::KEY_GUIDE , UTILX_KEY_GUIDE},
  {volt::util::KEY_REWIND_ , UTILX_KEY_REWIND_},  // |¢¸¢¸(TVDP)
  //    {volt::util::KEY_ANGLE , UTILX_KEY_ANGLE},  // MULTI SCREEN
  //    {volt::util::KEY_RESERVED1 , nullptr},
  //    {volt::util::KEY_ZOOM1 , UTILX_KEY_ZOOM1},  // wayforu11
  //    {volt::util::KEY_PROGRAM , nullptr},  // INSTALL, nullptr},
  //    {volt::util::KEY_BOOKMARK , nullptr},
  //    {volt::util::KEY_DISC_MENU , nullptr},
  //    {volt::util::KEY_SCROLL_DOWN , nullptr},  // QUICK
  {volt::util::KEY_RETURN , UTILX_KEY_RETURN},
  //    {volt::util::KEY_SUB_TITLE , UTILX_KEY_SUB_TITLE},
  //    {volt::util::KEY_CLEAR , UTILX_KEY_CLEAR},
  //    {volt::util::KEY_VCHIP , nullptr},
  {volt::util::KEY_REPEAT , UTILX_KEY_REPEAT},
  //    {volt::util::KEY_DOOR , nullptr},
  //    {volt::util::KEY_OPEN , nullptr},  // CLOSE
  //    {volt::util::KEY_WHEEL_LEFT , UTILX_KEY_WHEEL_LEFT},
  //    {volt::util::KEY_POWER , UTILX_KEY_POWER},  // wayforu - convert
  //    {volt::util::KEY_SLEEP , UTILX_KEY_SLEEP},  // wayforu - convert
  {volt::util::KEY_2 , UTILX_KEY_2},
  //    {volt::util::KEY_DMA , nullptr},
  //    {volt::util::KEY_TURBO , nullptr},
  {volt::util::KEY_1 , UTILX_KEY_1},
  //    {volt::util::KEY_FM_RADIO , nullptr},
  //    {volt::util::KEY_DVR_MENU , nullptr},
  //    {volt::util::KEY_MTS , UTILX_KEY_MTS},   // wayforu - convert // À½¼º ´ÙÁß
  //    {volt::util::KEY_PCMODE , nullptr},  // TV DVD
  //    {volt::util::KEY_TTX_SUBFACE , nullptr},
  //    {volt::util::KEY_CH_LIST , UTILX_KEY_CH_LIST},  // CH LIST
  {volt::util::KEY_RED , UTILX_KEY_RED},
  //    {volt::util::KEY_DNIe , nullptr},
  //    {volt::util::KEY_SRS , nullptr},  // SRS
  //    {volt::util::KEY_CONVERT_AUDIO_MAINSUB , nullptr}, // À½ÇâÁÖºÎÀüÈ¯
  //    {volt::util::KEY_MDC , nullptr},
  //    {volt::util::KEY_SEFFECT , nullptr},
  //    {volt::util::KEY_DVR , UTILX_KEY_DVR},
  //    {volt::util::KEY_DTV_SIGNAL , nullptr},  // ½ÅÈ£¼¼±â
  //    {volt::util::KEY_LIVE , nullptr},  // EQ
  //    {volt::util::KEY_PERPECT_FOCUS , nullptr},  // ÀÚµ¿Á¶Á¤(AUTO), nullptr}, RESOLUTION
  //    {volt::util::KEY_HOME , UTILX_KEY_HOME},
  //    {volt::util::KEY_ESAVING , UTILX_KEY_ESAVING},  // PWR.SAVE
  //    {volt::util::KEY_WHEEL_RIGHT , UTILX_KEY_WHEEL_RIGHT},
  //    {volt::util::KEY_CONTENTS , nullptr},
  //    {volt::util::KEY_VCR_MODE , nullptr},
  //    {volt::util::KEY_CATV_MODE , nullptr},
  //    {volt::util::KEY_DSS_MODE , nullptr},
  //    {volt::util::KEY_TV_MODE , nullptr},
  //    {volt::util::KEY_DVD_MODE , nullptr},
  //    {volt::util::KEY_STB_MODE , nullptr},
  //    {volt::util::KEY_CALLER_ID , nullptr},
  //    {volt::util::KEY_SCALE , nullptr},  // V.KEYSTONE
  //    {volt::util::KEY_ZOOM_MOVE , nullptr},  // È­¸éÈ®´ë/ÀÌµ¿
  //    {volt::util::KEY_CLOCK_DISPLAY , nullptr},
  //    {volt::util::KEY_AV1 , nullptr},  // wayforu11
  //    {volt::util::KEY_SVIDEO1 , nullptr},  // wayforu11
  //    {volt::util::KEY_COMPONENT1 , nullptr},  // wayforu11
  //    {volt::util::KEY_SETUP_CLOCK_TIMER , nullptr},
  //    {volt::util::KEY_COMPONENT2 , nullptr},  // wayforu11
  //    {volt::util::KEY_MAGIC_BRIGHT , nullptr},
  //    {volt::util::KEY_DVI , nullptr},
  //    {volt::util::KEY_HDMI , UTILX_KEY_HDMI},  // wayforu11
  //    {volt::util::KEY_W_LINK , nullptr},  // MEMORY CARD
  //    {volt::util::KEY_DTV_LINK , nullptr},
  //    {volt::util::KEY_RESERVED5 , nullptr},
  //    {volt::util::KEY_APP_LIST , UTILX_KEY_APP_LIST},  // MHP
  //    {volt::util::KEY_BACK_MHP , nullptr},  // MHP
  //    {volt::util::KEY_ALT_MHP , nullptr},  // MHP
  //    {volt::util::KEY_DNSe , nullptr},  // DNSE
  //    {volt::util::KEY_RSS , nullptr},
  //    {volt::util::KEY_ENTERTAINMENT , nullptr},
  //    {volt::util::KEY_ID_INPUT , nullptr},
  //    {volt::util::KEY_ID_SETUP , nullptr},
  //    {volt::util::KEY_ANYNET , nullptr},
  //    {volt::util::KEY_POWEROFF , nullptr},
  //    {volt::util::KEY_POWERON , nullptr},
  //    {volt::util::KEY_ANYVIEW , UTILX_KEY_ANYVIEW},
  //    {volt::util::KEY_MS , nullptr},
  //    {volt::util::KEY_MORE , UTILX_KEY_MORE},
  //    {volt::util::KEY_PANNEL_POWER , nullptr},
  //    {volt::util::KEY_PANNEL_CHUP , nullptr},
  //    {volt::util::KEY_PANNEL_CHDOWN , nullptr},
  //    {volt::util::KEY_PANNEL_VOLUP , nullptr},
  //    {volt::util::KEY_PANNEL_VOLDOWN , nullptr},
  //    {volt::util::KEY_PANNEL_ENTER , nullptr},
  //    {volt::util::KEY_PANNEL_MENU , nullptr},
  //    {volt::util::KEY_PANNEL_SOURCE , nullptr},
  //    {volt::util::KEY_AV2 , nullptr},
  //    {volt::util::KEY_AV3 , nullptr},
  //    {volt::util::KEY_SVIDEO2 , nullptr},
  //    {volt::util::KEY_SVIDEO3 , nullptr},
  //    {volt::util::KEY_ZOOM2 , nullptr},
  //    {volt::util::KEY_PANORAMA , nullptr},
  //    {volt::util::KEY_4_3 , nullptr},
  //    {volt::util::KEY_16_9 , UTILX_KEY_16_9},
  //    {volt::util::KEY_DYNAMIC , nullptr},
  //    {volt::util::KEY_STANDARD , nullptr},
  //    {volt::util::KEY_MOVIE1 , nullptr},
  //    {volt::util::KEY_CUSTOM , nullptr},
  //    {volt::util::KEY_TILT , nullptr},
  //    {volt::util::KEY_EZ_VIEW , nullptr},
  //    {volt::util::KEY_3D , UTILX_KEY_3D},
  //    {volt::util::KEY_AUTO_ARC_RESET , nullptr},
  //    {volt::util::KEY_AUTO_ARC_LNA_ON , nullptr},
  //    {volt::util::KEY_AUTO_ARC_LNA_OFF , nullptr},
  //    {volt::util::KEY_AUTO_ARC_ANYNET_MODE_OK , nullptr},
  //    {volt::util::KEY_AUTO_ARC_ANYNET_AUTO_START , nullptr},
  //    {volt::util::KEY_AUTO_FORMAT , nullptr},
  //    {volt::util::KEY_DNET , nullptr},
  //    {volt::util::KEY_HDMI1 , nullptr},
  //    {volt::util::KEY_AUTO_ARC_CAPTION_ON , nullptr},
  //    {volt::util::KEY_AUTO_ARC_CAPTION_OFF , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_DOUBLE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_LARGE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_SMALL , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_WIDE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_LEFT_TOP , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_RIGHT_TOP , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_LEFT_BOTTOM , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_RIGHT_BOTTOM , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_CH_CHANGE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_AUTOCOLOR_SUCCESS , nullptr},
  //    {volt::util::KEY_AUTO_ARC_AUTOCOLOR_FAIL , nullptr},
  //    {volt::util::KEY_AUTO_ARC_C_FORCE_AGING , nullptr},
  //    {volt::util::KEY_AUTO_ARC_USBJACK_INSPECT , nullptr},
  //    {volt::util::KEY_AUTO_ARC_JACK_IDENT , nullptr},
  //    {volt::util::KEY_NINE_SEPERATE , nullptr},
  //    {volt::util::KEY_ZOOM_IN , nullptr},
  //    {volt::util::KEY_ZOOM_OUT , nullptr},
  //    {volt::util::KEY_MIC , nullptr},
  //    {volt::util::KEY_HDMI2 , nullptr},  // discrete key
  //    {volt::util::KEY_HDMI3 , nullptr},  // discrete key
  //    {volt::util::KEY_AUTO_ARC_CAPTION_KOR , nullptr},
  //    {volt::util::KEY_AUTO_ARC_CAPTION_ENG , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_SOURCE_CHANGE , nullptr},
  //    {volt::util::KEY_HDMI4 , nullptr},  // discrete key
  //    {volt::util::KEY_AUTO_ARC_ANTENNA_AIR , nullptr},
  //    {volt::util::KEY_AUTO_ARC_ANTENNA_CABLE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_ANTENNA_SATELLITE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_CIP_TEST , nullptr},
  //    {volt::util::KEY_AUTO_ARC_CH_CHANGE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_START_MBR_TEST , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PVR_RECORDING_TEST , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PVR_PLAY_TEST , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PVR_DELETE_ALL , nullptr},
  //    {volt::util::KEY_AUTO_ARC_HOTEL_INTERACTIVE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIC_SND_TEST_START , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIC_SND_TEST_END , nullptr},
  //    {volt::util::KEY_PICTURE_HIDE , nullptr},
  //    {volt::util::KEY_AUTO_ARC_CH_CHANGE_2ND_TUNER , nullptr},
  //    {volt::util::KEY_PANNEL_FUNCTION , nullptr},
  //    {volt::util::KEY_PANNEL_REMOTE_POWER , nullptr},
  //    {volt::util::KEY_PANNEL_MUTE , nullptr},
  //    {volt::util::KEY_PANNEL_HOLD , nullptr},
  //    {volt::util::KEY_PANNEL_MUTE, nullptr},
  //    {volt::util::KEY_PANNEL_PIP , nullptr},
  //    {volt::util::KEY_AUTO_ARC_AUTOCOLOR_VIDEO , nullptr},
  //    {volt::util::KEY_AUTO_ARC_AUTOCOLOR_PC , nullptr},
  //    {volt::util::KEY_AUTO_ARC_AUTOCOLOR_COMP , nullptr},
  //    {volt::util::KEY_AUTO_ARC_COLOR_WHEEL_INDEX , nullptr},
  //    {volt::util::KEY_AUTO_ARC_EEPROM_COPY , nullptr},
  //    {volt::util::KEY_AUTO_ARC_TIME_CLEAR , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PLAY_INTERNAL_TEST_PATTERN , nullptr},
  //    {volt::util::KEY_TV_SNS , UTILX_KEY_TV_SNS},
  //    {volt::util::KEY_SEARCH , UTILX_KEY_SEARCH},
  //    {volt::util::KEY_DOTCOM , nullptr},
  //    {volt::util::KEY_BS , nullptr},
  //    {volt::util::KEY_CS , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_SOUND_CHANGE_MAIN , nullptr},
  //    {volt::util::KEY_AUTO_ARC_PIP_SOUND_CHANGE_SUB , nullptr},
  //    {volt::util::KEY_BT_CONTENTSBAR , UTILX_KEY_BT_CONTENTSBAR},
  //    {volt::util::KEY_BT_NUMBER , UTILX_KEY_BT_NUMBER},
  //    {volt::util::KEY_BT_HOTKEY , UTILX_KEY_BT_HOTKEY},
  //    {volt::util::KEY_BT_DEVICE , UTILX_KEY_BT_DEVICE},
  //    {volt::util::KEY_BT_TRIGGER , UTILX_KEY_BT_TRIGGER},
  //    {volt::util::KEY_BT_VOICE , UTILX_KEY_BT_VOICE},
  //    {volt::util::KEY_FAMILYHUB , UTILX_KEY_FAMILYHUB},
  //    {volt::util::KEY_CAMERA , UTILX_KEY_CAMERA},
  //    {volt::util::KEY_BT_COLOR_MECHA , UTILX_KEY_BT_COLOR_MECHA},
  //    {volt::util::KEY_MBR_SETUP , UTILX_KEY_MBR_SETUP},
  //    {volt::util::KEY_MBR_WATCH_TV , UTILX_KEY_MBR_WATCH_TV},
  //    {volt::util::KEY_MBR_WATCH_MOVIE , UTILX_KEY_MBR_WATCH_MOVIE},
  //    {volt::util::KEY_MBR_SETUP_CONFIRM , UTILX_KEY_MBR_SETUP_CONFIRM},
  //    {volt::util::KEY_USBHUB_SWITCH , UTILX_KEY_USBHUB_SWITCH},
  //    {volt::util::KEY_MBR_SETUP_FAILURE , UTILX_KEY_MBR_SETUP_FAILURE},
  //    {volt::util::KEY_BT_ALLSHARE , nullptr},
  //    {volt::util::KEY_BT_SAMSUNG_APPS , UTILX_KEY_BT_SAMSUNG_APPS},
  //    {volt::util::KEY_HOTEL_ROOMCONTROL , nullptr},
  //    {volt::util::KEY_HOTEL_TVGUIDE , nullptr},
  //    {volt::util::KEY_HOTEL_MOVIES , nullptr},
  //    {volt::util::KEY_BT_DUALVIEW , UTILX_KEY_BT_DUALVIEW},
  //    {volt::util::KEY_PAGE_LEFT , UTILX_KEY_PAGE_LEFT},
  //    {volt::util::KEY_PAGE_RIGHT , UTILX_KEY_PAGE_RIGHT},
  //    {volt::util::KEY_SOCCER_MODE , UTILX_KEY_SOCCER_MODE},
  //    {volt::util::KEY_STB_POWER , UTILX_KEY_STB_POWER},
  //    {volt::util::KEY_WIFI_PAIRING , UTILX_KEY_WIFI_PAIRING},
  //    {volt::util::KEY_MBR_BDDVD_POWER , UTILX_KEY_MBR_BDDVD_POWER},
  //    {volt::util::KEY_MBR_STBBD_MENU , UTILX_KEY_MBR_STBBD_MENU},
  //    {volt::util::KEY_MBR_BD_POPUP , UTILX_KEY_MBR_BD_POPUP},
  //    {volt::util::KEY_MBR_TV , UTILX_KEY_MBR_TV},
  //    {volt::util::KEY_MBR_STB_GUIDE , UTILX_KEY_MBR_STB_GUIDE},
  //    {volt::util::KEY_RECOMMEND_SEARCH_TOGGLE , UTILX_KEY_RECOMMEND_SEARCH_TOGGLE},
  //    {volt::util::KEY_FUNCTIONS_NETFLIX , UTILX_KEY_FUNCTIONS_NETFLIX},
  //    {volt::util::KEY_FUNCTIONS_AMAZON , UTILX_KEY_FUNCTIONS_AMAZON},
  //    {volt::util::KEY_FUNCTIONS_SCHEDULEMANAGER , nullptr},
  //    {volt::util::KEY_FUNCTIONS_4DIVISION_VIEW, nullptr},
  //    {volt::util::KEY_TURN, nullptr}
};


// this must be placed here to avoid compilation error due to
// key enum and #define clash in event_const.h and utilX.h
#include <KeyEventRepository.h>
#include <utilX.h>
#endif

namespace volt
{
namespace util
{

static Logger LOGGER("volt.util");

void InitializeKeys()
{
  // clear all keys and enable EXIT key only
  // use the key repository api here to clear keys
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  KeyEventRepository keyrepo;
  KeyRepository_RemoveAllKeys(&keyrepo);
  KeyRepository_AddKey(&keyrepo, R_KEY_EXIT);
  KeyRepository_Register(GetXWindowManager()->GetDisplay(), GetXWindowManager()->GetWindow(), &keyrepo);
#endif
}

bool AddKey(int keyCode)
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  Logger logger("volt.util.clutter");
  const char *key = GetTizenKeyName(keyCode);

  if(key)
  {
    LOG_ERROR(logger, "adding key code : " << keyCode << " key string " << std::string(key));
    utilx_grab_key(GetXWindowManager()->GetDisplay(),
                   GetXWindowManager()->GetWindow(), key, TOP_POSITION_GRAB);
    return true;
  }

  LOG_ERROR(logger, "unable to map key " << keyCode << " for adding");
  return false;
#endif
  return true;
}

bool RemoveKey(int keyCode)
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  Logger logger("volt.util.clutter");
  const char *key = GetTizenKeyName(keyCode);

  if(key)
  {
    LOG_ERROR(logger, "removing key code : " << keyCode << " key string " << std::string(key));
    utilx_ungrab_key(GetXWindowManager()->GetDisplay(),
                     GetXWindowManager()->GetWindow(), key);
    return true;
  }

  LOG_ERROR(logger, "unable to map key " << keyCode << " for removal");
  return false;
#endif
  return true;
}

const char* GetTizenKeyName(int voltKeyEvent)
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  Logger logger("volt.util.clutter");
  unsigned int arraySize = sizeof(keyMap)/sizeof(KeyMapping);

  for(unsigned i = 0; i < arraySize; i++)
  {
    if(keyMap[i].volt == voltKeyEvent)
    {
      // TODO DUE TO OVERLAPPING VOLT KEY VALUES,
      // we should keep looking until we find some thing..
      // but in the long run we should REALLY use a separate mapping..
      if(keyMap[i].utilX)
      {
        return keyMap[i].utilX;
      }
    }
  }

#endif
  return nullptr;
}

bool IsVoltKeyEvent(int eventId)
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  unsigned int arraySize = sizeof(keyMap)/sizeof(KeyMapping);

  for(unsigned i = 0; i < arraySize; i++)
  {
    if(keyMap[i].volt == eventId)
    {
      return true;
    }
  }

  return false;
#else
  return true;  // always return true since there is no actual key registration needed
#endif
}

} /* namespace util */
} /* namespace volt */
