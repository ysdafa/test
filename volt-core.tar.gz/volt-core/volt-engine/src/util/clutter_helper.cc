#include <png.h>
#include "clutter_helper.h"
#include <clutter/x11/clutter-x11.h>
#include <string.h>
#include "logger.h"
//#include "event_const.h"
#include <X11/Xlib.h>
#include <stdlib.h>
#include "uifw_misc.h"
#include <KeyEvent.h>


#include "display_capture_api.h" 
#include <boost/algorithm/string/predicate.hpp> 
#include <boost/lexical_cast.hpp> 
#include <aul.h>
#include "system_info.h"
#ifdef HAS_VCONF
#include "vconf.h"
#endif


#define TIZEN_KEY_CONTROL 0	// disabled for now until API issue with Tizen is sorted out

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
#include "XMultiView.h"
#include "XEGLImageWrapper.h"
#endif

#if defined(BUILD_FOR_TV) && defined(TIZEN)
/* this section MUST match utilX.h definition,
* we need to redefine this due to the stupid name clash between
* enum and #define
*/
#define UTILX_KEY_POWER "XF86PowerOff" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Power' key */
#define UTILX_KEY_EXTINPUT "XF86Display" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'TV/External Input Mode' key */
#define UTILX_KEY_HDMI "XF86ExtOutput1" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'HDMI' key */
#define UTILX_KEY_1 "1" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '1' key */
#define UTILX_KEY_2 "2" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '2' key */
#define UTILX_KEY_3 "3" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '3' key */
#define UTILX_KEY_4 "4" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '4' key */
#define UTILX_KEY_5 "5" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '5' key */
#define UTILX_KEY_6 "6" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '6' key */
#define UTILX_KEY_7 "7" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '7' key */
#define UTILX_KEY_8 "8" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '8' key */
#define UTILX_KEY_9 "9" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '9' key */
#define UTILX_KEY_MINUS "minus" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '-' key */
#define UTILX_KEY_0 "0" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '0' key */
#define UTILX_KEY_PREVCHANNEL "XF86PreviousChannel" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Previous Channel' key */
#define UTILX_KEY_VOLUMEUP "XF86AudioRaiseVolume" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Volume Up' key */
#define UTILX_KEY_VOLUMEDOWN "XF86AudioLowerVolume" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Volume Down' key */
#define UTILX_KEY_MUTE "XF86AudioMute" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Mute' key */
#define UTILX_KEY_CHANNELS "XF86ChannelList" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Channel List' key */
#define UTILX_KEY_CHANNELUP "XF86RaiseChannel" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Channel Up' key */
#define UTILX_KEY_CHANNELDOWN "XF86LowerChannel" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Channel Down' key */
#define UTILX_KEY_MENU "Menu" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Menu' key */
#define UTILX_KEY_HOME "XF86HomeScreen" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '(Smart) Home' key */
#define UTILX_KEY_SEARCH "XF86Search" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to '(Smart) Search' key */
#define UTILX_KEY_TOOLS "XF86Tools" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Tools' key */
#define UTILX_KEY_INFO "XF86Info" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Information' key */
#define UTILX_KEY_UP "Up" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Up' key */
#define UTILX_KEY_DOWN "Down" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Down' key */
#define UTILX_KEY_LEFT "Left" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Left' key */
#define UTILX_KEY_RIGHT "Right" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Right' key */
#define UTILX_KEY_ENTER "Return" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Enter' key */
#define UTILX_KEY_BACK "XF86Back" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Back' key */
#define UTILX_KEY_EXIT "XF86Close" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Stop' key */
#define UTILX_KEY_RED "XF86Red" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'A (Red)' key */
#define UTILX_KEY_GREEN "XF86Green" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'B (Green)' key */
#define UTILX_KEY_YELLOW "XF86Yellow" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'C (Yellow)' key */
#define UTILX_KEY_BLUE "XF86Blue" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'D (Blue)' key */
#define UTILX_KEY_PIP "XF86PIP" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'PIP (Picture In Picture)' key */
#define UTILX_KEY_PROGINFO "XF86ProgInfo" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Program Info' key */
#define UTILX_KEY_PICTUREMODE "XF86PictureMode" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Picture Mode' key */
#define UTILX_KEY_USBHUB "XF86Launch0" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'USB Hub' key */
#define UTILX_KEY_PICTURESIZE "XF86PictureSize" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Picture Size' key */
#define UTILX_KEY_FAVORITESCHANNELS "XF86Favorites" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Favorite Channels' key */
#define UTILX_KEY_PREVIOUS "XF86AudioPrev" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Previous Song' key */
#define UTILX_KEY_PAUSE "XF86AudioPause" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Pause' key */
#define UTILX_KEY_NEXT "XF86AudioNext" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Next Song' key */
#define UTILX_KEY_RECORD "XF86AudioRecord" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Record' key */
#define UTILX_KEY_PLAY "XF86AudioPlay" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Play' key */
#define UTILX_KEY_STOP "XF86AudioStop" /**< this macro means the XKeySym (XServer Key Symbol) corresponds to 'Audio Stop' key */

#define UTILX_KEY_WIFI_PAIRING "XF86Launch1"
#define UTILX_KEY_BT_VOICE "XF86HotLinks"
#define UTILX_KEY_RECOM_SEARCH "XF86Launch2"
#define UTILX_KEY_BT_NUMBER "XF86Phone"
#define UTILX_KEY_16_9 "XF86Launch3"
#define UTILX_KEY_MTS "XF86Launch4"
#define UTILX_KEY_FACTORY "XF86Launch5"
#define UTILX_KEY_SMODE "XF86Launch6"
#define UTILX_KEY_3SPEED "XF86Launch7"
#define UTILX_KEY_TV_SNS "XF86Launch8"
#define UTILX_KEY_3D "XF86Launch9"
#define UTILX_KEY_APP_LIST "XF86LaunchA"
#define UTILX_KEY_TTX_MIX "XF86LaunchB"
#define UTILX_KEY_DASHBOARD "XF86LaunchC"
#define UTILX_KEY_CAPTION "XF86LaunchD"
#define UTILX_KEY_SRSTSXT "XF86LaunchE"
#define UTILX_KEY_SLEEP "XF86LaunchF"
#define UTILX_KEY_ZOOM1 "XF86ZoomIn"
#define UTILX_KEY_AD "XF86AudioMedia"
#define UTILX_KEY_FF_ "XF86MonBrightnessUp"
#define UTILX_KEY_REWIND_ "XF86MonBrightnessDown"

#define UTILX_KEY_RETURN "XF86Back"
#define UTILX_KEY_PLUS100 "XF86Memo"
#define UTILX_KEY_JOYSTICK_OK "XF86Go"
#define UTILX_KEY_CYAN "XF86Blue"
#define UTILX_KEY_SOURCE "XF86Display"
#define UTILX_KEY_CH_LIST "XF86ChannelList"
#define UTILX_KEY_VOLDOWN "XF86AudioLowerVolume"
#define UTILX_KEY_VOLUP "XF86AudioRaiseVolume"
#define UTILX_KEY_CHDOWN "XF86LowerChannel"
#define UTILX_KEY_CHUP "XF86RaiseChannel"
#define UTILX_KEY_JOYSTICK_UP "Up"
#define UTILX_KEY_JOYSTICK_LEFT "Left"
#define UTILX_KEY_JOYSTICK_RIGHT "Right"
#define UTILX_KEY_JOYSTICK_DOWN "Down"
#define UTILX_KEY_REPEAT "XF86AudioRepeat"
#define UTILX_KEY_GUIDE "XF86ProgInfo"
#define UTILX_KEY_ASPECT "XF86PictureSize"
#define UTILX_KEY_PMODE "XF86PictureMode"
#define UTILX_KEY_USBHUB_SWITCH "XF86Launch0"
#define UTILX_KEY_EMANUAL "XF86Hibernate"
#define UTILX_KEY_MORE "XF86Calculator"
#define UTILX_KEY_TV "XF86Q"
#define UTILX_KEY_DTV "XF86ExtOutput2"
#define UTILX_KEY_STB_POWER "XF86PowerDown"
#define UTILX_KEY_ADDDEL "XF86AddFavorite"
#define UTILX_KEY_CONVERGENCE "XF86WWW"
#define UTILX_KEY_BT_COLOR_MECHA "XF86DOS"
#define UTILX_KEY_STILL_PICTURE "XF86ScreenSaver"
#define UTILX_KEY_BT_TRIGGER "XF86CD"
#define UTILX_KEY_BT_HOTKEY "XF86Support"
#define UTILX_KEY_BT_DEVICE "XF86MailForward"
#define UTILX_KEY_BT_CONTENTSBAR "XF86Book"
#define UTILX_KEY_GAME "XF86Game"
#define UTILX_KEY_PIP_CHUP "XF86Forward"
#define UTILX_KEY_PIP_CHDOWN "XF86RockerDown"
#define UTILX_KEY_ANTENA "XF86Eject"
#define UTILX_KEY_AUTO_PROGRAM "XF86Switch_VT_1"
#define UTILX_KEY_LINK "XF86ExtOutput3"
#define UTILX_KEY_REC "XF86AudioRecord"
#define UTILX_KEY_REWIND "XF86AudioPrev"
#define UTILX_KEY_ANGLE "XF86CycleAngle"
#define UTILX_KEY_MBR_TV "XF86RockerEnter"
#define UTILX_KEY_MBR_STB_GUIDE "XF86RockerUp"
#define UTILX_KEY_MBR_BD_POPUP "XF86ScrollUp"
#define UTILX_KEY_MBR_BDDVD_POWER "XF86ScrollDown"
#define UTILX_KEY_MBR_SETUP_FAILURE "XF86ApplicationLeft"
#define UTILX_KEY_MBR_SETUP "XF86ApplicationRight"
#define UTILX_KEY_MBR_WATCH_TV "XF86New"
#define UTILX_KEY_PRECH "XF86PreviousChannel"
#define UTILX_KEY_FAVCH "XF86Favorites"
#define UTILX_KEY_RECOMMEND_SEARCH_TOGGLE "XF86Launch2"
#define UTILX_KEY_BT_DUALVIEW "XF86Meeting"
#define UTILX_KEY_BT_SAMSUNG_APPS "XF86Switch_VT_4"
#define UTILX_KEY_ESAVING "XF86Suspend"
#define UTILX_KEY_CLEAR "XF86Clear"
#define UTILX_KEY_SUB_TITLE "XF86Subtitle"
#define UTILX_KEY_FF "XF86AudioNext"
#define UTILX_KEY_DVR "XF86LogWindowTree"
#define UTILX_KEY_CAMERA "XF86WebCam"
#define UTILX_KEY_SOCCER_MODE "XF86Standby"
#define UTILX_KEY_FUNCTIONS_AMAZON "XF86Shop"
#define UTILX_KEY_FUNCTIONS_NETFLIX "XF86MySites"
#define UTILX_KEY_PIP_ONOFF "XF86PIP"
#define UTILX_KEY_MBR_WATCH_MOVIE "XF86AudioCycleTrack"
#define UTILX_KEY_MBR_STBBD_MENU "XF86KbdBrightnessDown"
#define UTILX_KEY_MBR_SETUP_CONFIRM "XF86KbdBrightnessUp"
#define UTILX_KEY_FAMILYHUB "XF86Send"
#define UTILX_KEY_ANYVIEW "XF86Reply"
#define UTILX_KEY_PAGE_LEFT "XF86Next_VMode"
#define UTILX_KEY_PAGE_RIGHT "XF86Prev_VMode"
#define UTILX_KEY_WHEEL_LEFT "XF86MenuKB"
#define UTILX_KEY_WHEEL_RIGHT "XF86MenuPB"

#define UTILX_KEY_PANEL_DOWN "XF86Away"
#define UTILX_KEY_PANEL_UP "XF86Xfer"
#define UTILX_KEY_PANEL_PLUS "XF86OpenURL"
#define UTILX_KEY_PANEL_MINUS "XF86Excel"
#define UTILX_KEY_CONTEXT_MENU "XF86Documents"

#define UTILX_KEY_PANEL_ENTER		"XF86MyComputer"
#define UTILX_KEY_PANEL_EXIT		"XF86VendorHome"

#define JSON_LENGTH 2048


extern "C" { void dc_request_capture(dc_app_type_e app_type, dc_mode_e capture_mode, int width, int height, const char* app_id, const char* app_info); }

static volt::util::KeyMapping keyMap[] =
{
	{ volt::util::KEY_JOYSTICK_OK, UTILX_KEY_JOYSTICK_OK },
	//		{volt::util::KEY_MENU, UTILX_KEY_MENU},
	{ volt::util::KEY_JOYSTICK_UP, UTILX_KEY_JOYSTICK_UP },
	{ volt::util::KEY_JOYSTICK_DOWN, UTILX_KEY_JOYSTICK_DOWN },
	{ volt::util::KEY_JOYSTICK_LEFT, UTILX_KEY_JOYSTICK_LEFT },
	{ volt::util::KEY_JOYSTICK_RIGHT, UTILX_KEY_JOYSTICK_RIGHT },
	{ volt::util::KEY_3, UTILX_KEY_3 },
	{ volt::util::KEY_VOLUP, UTILX_KEY_VOLUP },
	{ volt::util::KEY_4, UTILX_KEY_4 },
	{ volt::util::KEY_5, UTILX_KEY_5 },
	{ volt::util::KEY_6, UTILX_KEY_6 },
	{ volt::util::KEY_VOLDOWN, UTILX_KEY_VOLDOWN },
	{ volt::util::KEY_7, UTILX_KEY_7 },
	{ volt::util::KEY_8, UTILX_KEY_8 },
	{ volt::util::KEY_9, UTILX_KEY_9 },
	{ volt::util::KEY_MUTE, UTILX_KEY_MUTE },
	//		{volt::util::KEY_CHDOWN, UTILX_KEY_CHDOWN},
	{ volt::util::KEY_0, UTILX_KEY_0 },
	//		{volt::util::KEY_CHUP, UTILX_KEY_CHUP},
	//		{volt::util::KEY_PRECH , UTILX_KEY_PRECH},
	{ volt::util::KEY_GREEN, UTILX_KEY_GREEN },
	{ volt::util::KEY_YELLOW, UTILX_KEY_YELLOW },
	{ volt::util::KEY_CYAN, UTILX_KEY_CYAN },
	//		{volt::util::KEY_BLUE, UTILX_KEY_BLUE},
	//		{volt::util::KEY_STEP, nullptr},  // TVDP
	//		{volt::util::KEY_DEL, nullptr},
	//		{volt::util::KEY_ADDDEL , UTILX_KEY_ADDDEL},  // ADD/DEL
	//		{volt::util::KEY_SOURCE , UTILX_KEY_SOURCE},  // wayforu - convert  // (TV/VIDEO)
	//		{volt::util::KEY_TV , UTILX_KEY_TV},  // wayforu11
	//		{volt::util::KEY_AUTO , nullptr},
	//		{volt::util::KEY_MOIP , nullptr},
	//		{volt::util::KEY_PMENU , nullptr},
	{ volt::util::KEY_INFO, UTILX_KEY_INFO },  // INFO
	//		{volt::util::KEY_PIP_ONOFF , UTILX_KEY_PIP_ONOFF},
	//		{volt::util::KEY_PIP_SWAP , nullptr},
	//		{volt::util::KEY_PIP_ROTATE , nullptr},
	//		{volt::util::KEY_PLUS100 , UTILX_KEY_PLUS100},
	//		{volt::util::KEY_PIP_INPUT , nullptr},
	//		{volt::util::KEY_CAPTION , UTILX_KEY_CAPTION},
	//		{volt::util::KEY_PIP_STILL , nullptr},
	//		{volt::util::KEY_AD , UTILX_KEY_AD},
	//		{volt::util::KEY_PMODE , UTILX_KEY_PMODE},
	//		{volt::util::KEY_SOUND_MODE , nullptr},
	//		{volt::util::KEY_NR , nullptr},  // N/R
	//		{volt::util::KEY_SMODE , UTILX_KEY_SMODE},
	//		{volt::util::KEY_TTX_MIX , UTILX_KEY_TTX_MIX},  // TTX/MIX
	{ volt::util::KEY_EXIT, UTILX_KEY_EXIT },
	//		{volt::util::KEY_ENTER , UTILX_KEY_ENTER},
	//		{volt::util::KEY_PIP_SIZE , nullptr},
	//		{volt::util::KEY_MAGIC_CHANNEL , nullptr},
	//		{volt::util::KEY_PIP_SCAN , nullptr},  // SEARCH
	//		{volt::util::KEY_PIP_CHUP , UTILX_KEY_PIP_CHUP},
	//		{volt::util::KEY_PIP_CHDOWN , UTILX_KEY_PIP_CHDOWN},
	//		{volt::util::KEY_DEVICE_CONNECT , nullptr},
	//		{volt::util::KEY_HELP , nullptr},  // CH INFO
	//		{volt::util::KEY_ANTENA , UTILX_KEY_ANTENA},
	//		{volt::util::KEY_CONVERGENCE , UTILX_KEY_CONVERGENCE},
	//		{volt::util::KEY_11 , nullptr},
	//		{volt::util::KEY_12 , nullptr},
	//		{volt::util::KEY_AUTO_PROGRAM , UTILX_KEY_AUTO_PROGRAM},
	//		{volt::util::KEY_FACTORY , UTILX_KEY_FACTORY},
	//		{volt::util::KEY_3SPEED , UTILX_KEY_3SPEED},
	//		{volt::util::KEY_SCROLL_UP , nullptr},
	//		{volt::util::KEY_ASPECT , UTILX_KEY_ASPECT},  // P.SIZE
	//		{volt::util::KEY_EMANUAL , UTILX_KEY_EMANUAL},
	//		{volt::util::KEY_GAME , UTILX_KEY_GAME},
	//		{volt::util::KEY_SCROLL_RIGHT , nullptr},
	//		{volt::util::KEY_STILL_PICTURE , UTILX_KEY_STILL_PICTURE},  // FREEZE
	//		{volt::util::KEY_DTV , UTILX_KEY_DTV},
	//		{volt::util::KEY_FAVCH , UTILX_KEY_FAVCH},  // CH.LIST
	{ volt::util::KEY_REWIND, UTILX_KEY_REWIND },
	{ volt::util::KEY_STOP, UTILX_KEY_STOP },
	{ volt::util::KEY_PLAY, UTILX_KEY_PLAY },
	{ volt::util::KEY_FF, UTILX_KEY_FF },
	{ volt::util::KEY_REC, UTILX_KEY_REC },
	{ volt::util::KEY_PAUSE, UTILX_KEY_PAUSE },
	{ volt::util::KEY_TOOLS, UTILX_KEY_TOOLS },
	//		{volt::util::KEY_SCROLL_LEFT , nullptr},
	//		{volt::util::KEY_LINK , UTILX_KEY_LINK},  // MSG, nullptr}, IEEE-1394 D.NET
	//		{volt::util::KEY_FF_ , UTILX_KEY_FF_},  // ¢º¢º|(TVDP)
	//		{volt::util::KEY_GUIDE , UTILX_KEY_GUIDE},
	//		{volt::util::KEY_REWIND_ , UTILX_KEY_REWIND_},  // |¢¸¢¸(TVDP)
	//		{volt::util::KEY_ANGLE , UTILX_KEY_ANGLE},  // MULTI SCREEN
	//		{volt::util::KEY_RESERVED1 , nullptr},
	//		{volt::util::KEY_ZOOM1 , UTILX_KEY_ZOOM1},  // wayforu11
	//		{volt::util::KEY_PROGRAM , nullptr},  // INSTALL, nullptr},
	//		{volt::util::KEY_BOOKMARK , nullptr},
	//		{volt::util::KEY_DISC_MENU , nullptr},
	//		{volt::util::KEY_SCROLL_DOWN , nullptr},  // QUICK
	{ volt::util::KEY_RETURN, UTILX_KEY_RETURN },
	//		{volt::util::KEY_SUB_TITLE , UTILX_KEY_SUB_TITLE},
	//		{volt::util::KEY_CLEAR , UTILX_KEY_CLEAR},
	//		{volt::util::KEY_VCHIP , nullptr},
	//		{volt::util::KEY_REPEAT , UTILX_KEY_REPEAT},
	//		{volt::util::KEY_DOOR , nullptr},
	//		{volt::util::KEY_OPEN , nullptr},  // CLOSE
	//		{volt::util::KEY_WHEEL_LEFT , UTILX_KEY_WHEEL_LEFT},
	//		{volt::util::KEY_POWER , UTILX_KEY_POWER},  // wayforu - convert
	//		{volt::util::KEY_SLEEP , UTILX_KEY_SLEEP},  // wayforu - convert
	{ volt::util::KEY_2, UTILX_KEY_2 },
	//		{volt::util::KEY_DMA , nullptr},
	//		{volt::util::KEY_TURBO , nullptr},
	{ volt::util::KEY_1, UTILX_KEY_1 },
	//		{volt::util::KEY_FM_RADIO , nullptr},
	//		{volt::util::KEY_DVR_MENU , nullptr},
	//		{volt::util::KEY_MTS , UTILX_KEY_MTS},   // wayforu - convert // À½¼º ´ÙÁß
	//		{volt::util::KEY_PCMODE , nullptr},  // TV DVD
	//		{volt::util::KEY_TTX_SUBFACE , nullptr},
	//		{volt::util::KEY_CH_LIST , UTILX_KEY_CH_LIST},  // CH LIST
	{ volt::util::KEY_RED, UTILX_KEY_RED },
	//		{volt::util::KEY_DNIe , nullptr},
	//		{volt::util::KEY_SRS , nullptr},  // SRS
	//		{volt::util::KEY_CONVERT_AUDIO_MAINSUB , nullptr}, // À½ÇâÁÖºÎÀüÈ¯
	//		{volt::util::KEY_MDC , nullptr},
	//		{volt::util::KEY_SEFFECT , nullptr},
	//		{volt::util::KEY_DVR , UTILX_KEY_DVR},
	//		{volt::util::KEY_DTV_SIGNAL , nullptr},  // ½ÅÈ£¼¼±â
	//		{volt::util::KEY_LIVE , nullptr},  // EQ
	//		{volt::util::KEY_PERPECT_FOCUS , nullptr},  // ÀÚµ¿Á¶Á¤(AUTO), nullptr}, RESOLUTION
	//		{volt::util::KEY_HOME , UTILX_KEY_HOME},
	//		{volt::util::KEY_ESAVING , UTILX_KEY_ESAVING},  // PWR.SAVE
	//		{volt::util::KEY_WHEEL_RIGHT , UTILX_KEY_WHEEL_RIGHT},
	//		{volt::util::KEY_CONTENTS , nullptr},
	//		{volt::util::KEY_VCR_MODE , nullptr},
	//		{volt::util::KEY_CATV_MODE , nullptr},
	//		{volt::util::KEY_DSS_MODE , nullptr},
	//		{volt::util::KEY_TV_MODE , nullptr},
	//		{volt::util::KEY_DVD_MODE , nullptr},
	//		{volt::util::KEY_STB_MODE , nullptr},
	//		{volt::util::KEY_CALLER_ID , nullptr},
	//		{volt::util::KEY_SCALE , nullptr},  // V.KEYSTONE
	//		{volt::util::KEY_ZOOM_MOVE , nullptr},  // È­¸éÈ®´ë/ÀÌµ¿
	//		{volt::util::KEY_CLOCK_DISPLAY , nullptr},
	//		{volt::util::KEY_AV1 , nullptr},  // wayforu11
	//		{volt::util::KEY_SVIDEO1 , nullptr},  // wayforu11
	//		{volt::util::KEY_COMPONENT1 , nullptr},  // wayforu11
	//		{volt::util::KEY_SETUP_CLOCK_TIMER , nullptr},
	//		{volt::util::KEY_COMPONENT2 , nullptr},  // wayforu11
	//		{volt::util::KEY_MAGIC_BRIGHT , nullptr},
	//		{volt::util::KEY_DVI , nullptr},
	//		{volt::util::KEY_HDMI , UTILX_KEY_HDMI},  // wayforu11
	//		{volt::util::KEY_W_LINK , nullptr},  // MEMORY CARD
	//		{volt::util::KEY_DTV_LINK , nullptr},
	//		{volt::util::KEY_RESERVED5 , nullptr},
	//		{volt::util::KEY_APP_LIST , UTILX_KEY_APP_LIST},  // MHP
	//		{volt::util::KEY_BACK_MHP , nullptr},  // MHP
	//		{volt::util::KEY_ALT_MHP , nullptr},  // MHP
	//		{volt::util::KEY_DNSe , nullptr},  // DNSE
	//		{volt::util::KEY_RSS , nullptr},
	//		{volt::util::KEY_ENTERTAINMENT , nullptr},
	//		{volt::util::KEY_ID_INPUT , nullptr},
	//		{volt::util::KEY_ID_SETUP , nullptr},
	//		{volt::util::KEY_ANYNET , nullptr},
	//		{volt::util::KEY_POWEROFF , nullptr},
	//		{volt::util::KEY_POWERON , nullptr},
	//		{volt::util::KEY_ANYVIEW , UTILX_KEY_ANYVIEW},
	//		{volt::util::KEY_MS , nullptr},
	//		{volt::util::KEY_MORE , UTILX_KEY_MORE},
	//		{volt::util::KEY_PANNEL_POWER , nullptr},
	//		{volt::util::KEY_PANNEL_CHUP , nullptr},
	//		{volt::util::KEY_PANNEL_CHDOWN , nullptr},
	//		{volt::util::KEY_PANNEL_VOLUP , nullptr},
	//		{volt::util::KEY_PANNEL_VOLDOWN , nullptr},
	//		{volt::util::KEY_PANNEL_ENTER , nullptr},
	//		{volt::util::KEY_PANNEL_MENU , nullptr},
	//		{volt::util::KEY_PANNEL_SOURCE , nullptr},
	//		{volt::util::KEY_AV2 , nullptr},
	//		{volt::util::KEY_AV3 , nullptr},
	//		{volt::util::KEY_SVIDEO2 , nullptr},
	//		{volt::util::KEY_SVIDEO3 , nullptr},
	//		{volt::util::KEY_ZOOM2 , nullptr},
	//		{volt::util::KEY_PANORAMA , nullptr},
	//		{volt::util::KEY_4_3 , nullptr},
	//		{volt::util::KEY_16_9 , UTILX_KEY_16_9},
	//		{volt::util::KEY_DYNAMIC , nullptr},
	//		{volt::util::KEY_STANDARD , nullptr},
	//		{volt::util::KEY_MOVIE1 , nullptr},
	//		{volt::util::KEY_CUSTOM , nullptr},
	//		{volt::util::KEY_TILT , nullptr},
	//		{volt::util::KEY_EZ_VIEW , nullptr},
	//		{volt::util::KEY_3D , UTILX_KEY_3D},
	//		{volt::util::KEY_AUTO_ARC_RESET , nullptr},
	//		{volt::util::KEY_AUTO_ARC_LNA_ON , nullptr},
	//		{volt::util::KEY_AUTO_ARC_LNA_OFF , nullptr},
	//		{volt::util::KEY_AUTO_ARC_ANYNET_MODE_OK , nullptr},
	//		{volt::util::KEY_AUTO_ARC_ANYNET_AUTO_START , nullptr},
	//		{volt::util::KEY_AUTO_FORMAT , nullptr},
	//		{volt::util::KEY_DNET , nullptr},
	//		{volt::util::KEY_HDMI1 , nullptr},
	//		{volt::util::KEY_AUTO_ARC_CAPTION_ON , nullptr},
	//		{volt::util::KEY_AUTO_ARC_CAPTION_OFF , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_DOUBLE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_LARGE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_SMALL , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_WIDE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_LEFT_TOP , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_RIGHT_TOP , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_LEFT_BOTTOM , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_RIGHT_BOTTOM , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_CH_CHANGE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_AUTOCOLOR_SUCCESS , nullptr},
	//		{volt::util::KEY_AUTO_ARC_AUTOCOLOR_FAIL , nullptr},
	//		{volt::util::KEY_AUTO_ARC_C_FORCE_AGING , nullptr},
	//		{volt::util::KEY_AUTO_ARC_USBJACK_INSPECT , nullptr},
	//		{volt::util::KEY_AUTO_ARC_JACK_IDENT , nullptr},
	//		{volt::util::KEY_NINE_SEPERATE , nullptr},
	//		{volt::util::KEY_ZOOM_IN , nullptr},
	//		{volt::util::KEY_ZOOM_OUT , nullptr},
	//		{volt::util::KEY_MIC , nullptr},
	//		{volt::util::KEY_HDMI2 , nullptr},  // discrete key
	//		{volt::util::KEY_HDMI3 , nullptr},  // discrete key
	//		{volt::util::KEY_AUTO_ARC_CAPTION_KOR , nullptr},
	//		{volt::util::KEY_AUTO_ARC_CAPTION_ENG , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_SOURCE_CHANGE , nullptr},
	//		{volt::util::KEY_HDMI4 , nullptr},  // discrete key
	//		{volt::util::KEY_AUTO_ARC_ANTENNA_AIR , nullptr},
	//		{volt::util::KEY_AUTO_ARC_ANTENNA_CABLE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_ANTENNA_SATELLITE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_CIP_TEST , nullptr},
	//		{volt::util::KEY_AUTO_ARC_CH_CHANGE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_START_MBR_TEST , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PVR_RECORDING_TEST , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PVR_PLAY_TEST , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PVR_DELETE_ALL , nullptr},
	//		{volt::util::KEY_AUTO_ARC_HOTEL_INTERACTIVE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIC_SND_TEST_START , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIC_SND_TEST_END , nullptr},
	//		{volt::util::KEY_PICTURE_HIDE , nullptr},
	//		{volt::util::KEY_AUTO_ARC_CH_CHANGE_2ND_TUNER , nullptr},
	//		{volt::util::KEY_PANNEL_FUNCTION , nullptr},
	//		{volt::util::KEY_PANNEL_REMOTE_POWER , nullptr},
	//		{volt::util::KEY_PANNEL_MUTE , nullptr},
	//		{volt::util::KEY_PANNEL_HOLD , nullptr},
	//		{volt::util::KEY_PANNEL_MUTE, nullptr},
	//		{volt::util::KEY_PANNEL_PIP , nullptr},
	//		{volt::util::KEY_AUTO_ARC_AUTOCOLOR_VIDEO , nullptr},
	//		{volt::util::KEY_AUTO_ARC_AUTOCOLOR_PC , nullptr},
	//		{volt::util::KEY_AUTO_ARC_AUTOCOLOR_COMP , nullptr},
	//		{volt::util::KEY_AUTO_ARC_COLOR_WHEEL_INDEX , nullptr},
	//		{volt::util::KEY_AUTO_ARC_EEPROM_COPY , nullptr},
	//		{volt::util::KEY_AUTO_ARC_TIME_CLEAR , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PLAY_INTERNAL_TEST_PATTERN , nullptr},
	//		{volt::util::KEY_TV_SNS , UTILX_KEY_TV_SNS},
	//		{volt::util::KEY_SEARCH , UTILX_KEY_SEARCH},
	//		{volt::util::KEY_DOTCOM , nullptr},
	//		{volt::util::KEY_BS , nullptr},
	//		{volt::util::KEY_CS , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_SOUND_CHANGE_MAIN , nullptr},
	//		{volt::util::KEY_AUTO_ARC_PIP_SOUND_CHANGE_SUB , nullptr},
	//		{volt::util::KEY_BT_CONTENTSBAR , UTILX_KEY_BT_CONTENTSBAR},
	//		{volt::util::KEY_BT_NUMBER , UTILX_KEY_BT_NUMBER},
	//		{volt::util::KEY_BT_HOTKEY , UTILX_KEY_BT_HOTKEY},
	//		{volt::util::KEY_BT_DEVICE , UTILX_KEY_BT_DEVICE},
	//		{volt::util::KEY_BT_TRIGGER , UTILX_KEY_BT_TRIGGER},
	//		{volt::util::KEY_BT_VOICE , UTILX_KEY_BT_VOICE},
	//		{volt::util::KEY_FAMILYHUB , UTILX_KEY_FAMILYHUB},
	//		{volt::util::KEY_CAMERA , UTILX_KEY_CAMERA},
	//		{volt::util::KEY_BT_COLOR_MECHA , UTILX_KEY_BT_COLOR_MECHA},
	//		{volt::util::KEY_MBR_SETUP , UTILX_KEY_MBR_SETUP},
	//		{volt::util::KEY_MBR_WATCH_TV , UTILX_KEY_MBR_WATCH_TV},
	//		{volt::util::KEY_MBR_WATCH_MOVIE , UTILX_KEY_MBR_WATCH_MOVIE},
	//		{volt::util::KEY_MBR_SETUP_CONFIRM , UTILX_KEY_MBR_SETUP_CONFIRM},
	//		{volt::util::KEY_USBHUB_SWITCH , UTILX_KEY_USBHUB_SWITCH},
	//		{volt::util::KEY_MBR_SETUP_FAILURE , UTILX_KEY_MBR_SETUP_FAILURE},
	//		{volt::util::KEY_BT_ALLSHARE , nullptr},
	//		{volt::util::KEY_BT_SAMSUNG_APPS , UTILX_KEY_BT_SAMSUNG_APPS},
	//		{volt::util::KEY_HOTEL_ROOMCONTROL , nullptr},
	//		{volt::util::KEY_HOTEL_TVGUIDE , nullptr},
	//		{volt::util::KEY_HOTEL_MOVIES , nullptr},
	//		{volt::util::KEY_BT_DUALVIEW , UTILX_KEY_BT_DUALVIEW},
	//		{volt::util::KEY_PAGE_LEFT , UTILX_KEY_PAGE_LEFT},
	//		{volt::util::KEY_PAGE_RIGHT , UTILX_KEY_PAGE_RIGHT},
	//		{volt::util::KEY_SOCCER_MODE , UTILX_KEY_SOCCER_MODE},
	//		{volt::util::KEY_STB_POWER , UTILX_KEY_STB_POWER},
	//		{volt::util::KEY_WIFI_PAIRING , UTILX_KEY_WIFI_PAIRING},
	//		{volt::util::KEY_MBR_BDDVD_POWER , UTILX_KEY_MBR_BDDVD_POWER},
	//		{volt::util::KEY_MBR_STBBD_MENU , UTILX_KEY_MBR_STBBD_MENU},
	//		{volt::util::KEY_MBR_BD_POPUP , UTILX_KEY_MBR_BD_POPUP},
	//		{volt::util::KEY_MBR_TV , UTILX_KEY_MBR_TV},
	//		{volt::util::KEY_MBR_STB_GUIDE , UTILX_KEY_MBR_STB_GUIDE},
	//		{volt::util::KEY_RECOMMEND_SEARCH_TOGGLE , UTILX_KEY_RECOMMEND_SEARCH_TOGGLE},
	//		{volt::util::KEY_FUNCTIONS_NETFLIX , UTILX_KEY_FUNCTIONS_NETFLIX},
	//		{volt::util::KEY_FUNCTIONS_AMAZON , UTILX_KEY_FUNCTIONS_AMAZON},
	//		{volt::util::KEY_FUNCTIONS_SCHEDULEMANAGER , nullptr},
	//		{volt::util::KEY_FUNCTIONS_4DIVISION_VIEW, nullptr},
	//		{volt::util::KEY_TURN, nullptr}
};

// this must be placed here to avoid compilation error due to
// key enum and #define clash in event_const.h and utilX.h
#if TIZEN_KEY_CONTROL
#include <KeyEventRepository.h>
#include <utilX.h>
#endif

#include <Ecore.h>
#include <Ecore_X.h>
#endif

namespace volt
{
	namespace util
	{
		bundle *caller_bundle;
		char *call_app_id;
		static Display *XDPY = NULL; /* Singleton display. */
		static Window XWIN = 0;

#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
		static Window DUMMY_XWIN = 0;
#endif

#if TIZEN_KEY_CONTROL
#if defined(BUILD_FOR_TV) && defined(TIZEN)
		static KeyEventRepository KEYREPO;
#endif
#endif

		static int WIDTH = 0;
		static int HEIGHT = 0;

		static Logger LOGGER("volt.util");

#if defined(BUILD_FOR_TV) && defined(TIZEN)
		void SetupVDDisplay()
		{
		}
#endif

#if defined(BUILD_FOR_TV) && defined(TIZEN)
		/**
		* A proxy function to forward EFL events to Clutter.
		*/
		static Eina_Bool OnEcoreXEvents(void *aData, int aEventType, void *aEvent)
		{
			XEvent *event = static_cast<XEvent *>(aEvent);

			if (event->type == ConfigureNotify)
			{
				if (VoltProcessManager::Instance().Runtime() == NULL)
				{
					return EINA_TRUE;
				}

				if (VoltProcessManager::Instance().Runtime().get() == NULL)
				{
					return EINA_TRUE;
				}

				VoltFullProcessRuntime *runtime = static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
				if (runtime->GetMainStage() != NULL)
				{
					XConfigureEvent xce = event->xconfigure;

					if (xce.height >= 10)
					{
						xce.width = 1920;
						xce.height = 1080;
					}

					clutter_actor_set_size((ClutterActor*)runtime->GetMainStage(), xce.width, xce.height);
				}
			}
			else
			{
				clutter_x11_handle_event(event);
			}

			return EINA_TRUE; /* Keep this handler registered. */
		}

#endif

		int PrepareClutter()
		{
			Logger logger("volt.util.clutter");
			int retval = -1;
			do
			{
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
				/* Init and connect to X manually. */
				if (XEGLInit() != 0)
				{
					LOG_ERROR(logger, "XEGLInit failed");
					break;
				}
#endif

				if (XInitThreads() == 0)
				{
					LOG_ERROR(logger, "XInitThreads failed");
					break;
				}

#if defined(BUILD_FOR_TV) && defined(TIZEN)
				if (ecore_x_init(NULL) == 0)
				{
					LOG_ERROR(logger, "Failed to initialize Ecore X with the default dispaly");
					if (ecore_x_init(":0") == 0)
					{
						LOG_ERROR(logger, "Failed to initialize Ecore X with :0");
						break;
					}
				}

				XDPY = static_cast<Display *>(ecore_x_display_get());
				if (!XDPY)
				{
					LOG_ERROR(logger, "Failed to open display");
					break;
				}

				/* Disable X11 event polling by Clutter; let EFL handle it. */
				clutter_x11_disable_event_retrieval();
				/* Intercept X-events so that we can send it to Clutter */
				ecore_event_handler_add(ECORE_X_EVENT_ANY, OnEcoreXEvents, NULL);
#else
				/* Check if already opened? */
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
#else
				XDPY = XOpenDisplay(NULL);
#endif
				if (!XDPY)
				{
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
					char *display_name = NULL;
					XGetDisplayString(XMV_VIEW_FIRST, &display_name);
					LOG_WARN(logger, "The display string is " << display_name);

					setenv("DISPLAY", display_name, 1);
					XDPY = XOpenDisplay(display_name);
					XFreeDisplayString(display_name);
#else
					LOG_WARN(logger, "Failed to open display; trying :0...");
					setenv("DISPLAY", ":0", 1);
					XDPY = XOpenDisplay(NULL);
#endif

					if (!XDPY)
					{
						LOG_ERROR(logger, "Failed to open display");
						break;
					}
				}
#endif
				LOG_DEBUG(logger, "Opened X display: " << XDPY);

				/* Using our own display. */
				clutter_x11_set_display(XDPY);

				retval = 0;
			} while (0);

			return retval;
		}
		static void tvContextChange(tvcontext_state state, void *data)
		{
			ClutterStage* mainStage = (ClutterStage*)data;
			if (TVCONTEXT_CHECK_STATE(state, TVCONTEXT_STATE_TV))
			{
				LOG_DEBUG(LOGGER, "Change _NET_WM_STATE(ATOM) -> _NET_WM_STATE_NORMAL!");
				Display* dpy = clutter_x11_get_default_display();
				Window w = (Window)clutter_x11_get_stage_window(mainStage);

				Atom type = XInternAtom(dpy, "_NET_WM_STATE_NORMAL", False);

				XChangeProperty(dpy, w, XInternAtom(dpy, "_NET_WM_STATE", False), XInternAtom(dpy, "ATOM", False), 32, PropModeReplace, (unsigned char *)&type, 1);
			}
		}

		ClutterActor* CreateNewStage(const int aWidth, const int aHeight, const int aSceneWidth, const int aSceneHeight)
		{
			Logger logger("volt.util.clutter");

			if (XDPY == NULL)
			{
				LOG_FATAL(logger, "XDisplay is not initialized yet");
				return NULL;
			}

			WIDTH = aWidth;
			HEIGHT = aHeight;

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
			XWIN = static_cast<Window>(ecore_x_window_new(0, 0, 0, aWidth, aHeight));
#else
			/* We want to test that Cogl can handle foreign X windows... */
			XVisualInfo *xvisinfo = clutter_x11_get_visual_info();
			fprintf(stderr, "\n the value of visual depth %d \n", xvisinfo->depth);
			/* window attributes */
			XSetWindowAttributes xattr;
			// must initialize this structure because it is used as an input variable below.
			memset(&xattr, 0, sizeof(XSetWindowAttributes));
			xattr.background_pixel = WhitePixel(XDPY, DefaultScreen(XDPY));
			xattr.border_pixel = 0;
			xattr.colormap = XCreateColormap(XDPY,
				DefaultRootWindow(XDPY),
				xvisinfo->visual,
				AllocNone);
			xattr.event_mask = StructureNotifyMask;

			unsigned long mask = CWBorderPixel | CWColormap | CWEventMask;

#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
			/* A dummy off-screen window.
			* For some reason on the X12, X14, NT14U, and GOLFS possibly due to Mali driver
			* differences, you must create a dummy window underneath your main window.
			* Otherwise the app will hang waiting for a reply from the X server that
			* never comes. */
			DUMMY_XWIN = XCreateWindow(XDPY,
				DefaultRootWindow(XDPY),
				-200, -200,
				1, 1,
				0,
				xvisinfo->depth,
				InputOutput,
				xvisinfo->visual,
				mask, &xattr);
#endif

			if (xvisinfo->depth == 24)
			{
				XWIN = XCreateWindow(XDPY,
					DefaultRootWindow(XDPY),
					0, 0,
					aWidth, aHeight,
					0,
					xvisinfo->depth,
					InputOutput,
					xvisinfo->visual,
					mask,
					&xattr);

				XFree(xvisinfo);
			}
			else
			{
				XVisualInfo vinfo;
				memset(&vinfo, 0x0, sizeof(XVisualInfo));
				XMatchVisualInfo(XDPY, DefaultScreen(XDPY), 32, TrueColor, &vinfo);
				XSetWindowAttributes attr;
				memset(&attr, 0x0, sizeof(XSetWindowAttributes));
				attr.colormap = XCreateColormap(XDPY, DefaultRootWindow(XDPY), vinfo.visual, AllocNone);
				attr.border_pixel = 0;
				attr.background_pixel = 0;
				attr.event_mask = StructureNotifyMask;
				XWIN = XCreateWindow(XDPY, DefaultRootWindow(XDPY), 0, 0, aWidth, aHeight, 0, vinfo.depth, InputOutput, vinfo.visual, CWColormap | CWBorderPixel | CWBackPixel | CWEventMask, &attr);
			}

#if defined(BUILD_FOR_TV) && defined(TIZEN)
			SetupVDDisplay();
#endif

#if 0
			XIEventMask mask[2];
			XIEventMask *m;
			m = &mask[0];
			int deviceid = -1;
			m->deviceid = (deviceid == -1) ? XIAllDevices : deviceid;
			m->mask_len = XIMaskLen(XI_LASTEVENT);
			m->mask = (unsigned char *)calloc(m->mask_len, sizeof(char));
			XISetMask(m->mask, XI_Motion);
			XISetMask(m->mask, XI_ButtonPress);
			XISetMask(m->mask, XI_ButtonRelease);
			XISetMask(m->mask, XI_KeyPress);
			XISetMask(m->mask, XI_KeyRelease);

			XISetMask(m->mask, XI_TouchBegin);
			XISetMask(m->mask, XI_TouchUpdate);
			XISetMask(m->mask, XI_TouchEnd);
			XISetMask(m->mask, XI_RemKeyPress);
			XISetMask(m->mask, XI_RemKeyRelease);
			XISetMask(m->mask, XI_SensorStart);
			XISetMask(m->mask, XI_SensorEnd);
			XISetMask(m->mask, XI_Sensor);
			/* Register events on the window */
			XISelectEvents(display, win, &mask[0], 1);

			//XMapWindow(display, win);
			XSetInputFocus(display, win, RevertToParent, 0);
			free(mask[0].mask);
#endif
#endif


			ClutterActor *stage = clutter_stage_new();
			if (stage == NULL)
			{
				LOG_FATAL(logger, "Failed to create stage");
				return NULL;
			}

			if (clutter_x11_set_stage_foreign(CLUTTER_STAGE(stage), XWIN) == FALSE)
			{
				LOG_WARN(logger, "Failed to set foreign X window.");
				return NULL;
			}

			ClutterColor color({ 0, 0, 0, 0 });

			clutter_actor_set_size(stage, aSceneWidth, aSceneHeight);
			clutter_stage_set_use_alpha(CLUTTER_STAGE(stage), true);
			clutter_actor_set_background_color(stage, &color);
			clutter_actor_queue_redraw(stage);
			clutter_actor_set_size(stage, aSceneWidth, aSceneHeight);
			clutter_actor_hide(stage);
			if (AppConfig::Instance().IsFirstScreen() || AppConfig::Instance().IsLWFramework())
			{
				clutter_stage_aux_hint_add((ClutterStage*)stage, "wm.policy.win.zone.desk.layout.mode", "fullscreen");

				Display* dpy = clutter_x11_get_default_display();
				Window w = (Window)clutter_x11_get_stage_window((ClutterStage*)stage);
				tvcontext_state tv_state;
				tvcontext_init();
				tvcontext_query_state(&tv_state);
				if (!(TVCONTEXT_CHECK_STATE(tv_state, TVCONTEXT_STATE_TV)))
				{
					LOG_DEBUG(LOGGER, "TV Viewer is not generate!");
					Atom type = XInternAtom(dpy, "_NET_WM_STATE_ABOVE", False);
					XChangeProperty(dpy, w, XInternAtom(dpy, "_NET_WM_STATE", False), XInternAtom(dpy, "ATOM", False), 32, PropModeReplace, (unsigned char *)&type, 1);
				}
				int result = tvcontext_listen_context_change(tvContextChange, (void *)stage);
				if (result < 0)
				{
					//		LOGI("Failed to Tvcontext_Change");
				}
			}

			else
			{
				Atom _atom_support_hint = XInternAtom(XDPY, "_E_WINDOW_AUX_HINT_SUPPORT", False);   // You should set the property (make _E_WINDOW_AUX_HINT_SUPPORT  Atom)

				unsigned int data[1];

				data[0] = 1;

				int result_support = XChangeProperty(XDPY, XWIN, _atom_support_hint, XA_CARDINAL, 32, PropModeReplace, (unsigned char *)data, 1);

				Atom _atom_hint = XInternAtom(XDPY, "_E_WINDOW_AUX_HINT", False); // You should set the property (make _E_WINDOW_AUX_HINT Atom);

				char *hints = (char*)malloc(sizeof(char)* 100);
				strncpy(hints, "0:wm.policy.win.use.capture:enable", 100);
				int length_hints = strlen(hints) + 1;
				int result = XChangeProperty(XDPY, XWIN, _atom_hint, XA_STRING, 8, PropModeReplace, (unsigned char *)hints, length_hints);

				free(hints);
			}

			Atom _atom_wm_pid;
			_atom_wm_pid = XInternAtom(XDPY, "_NET_WM_PID", False);
			long pid = getpid();
			XChangeProperty(XDPY, XWIN, _atom_wm_pid, XA_CARDINAL, 32, PropModeReplace, (unsigned char*)&pid, 1);

			ShowXWindow();

			return stage;
		}

		void DestroyStage(ClutterActor **aStage)
		{
			if (aStage && *aStage)
			{
				clutter_actor_destroy(*aStage);
				*aStage = nullptr;
			}

			/* X windows clean up */
#if defined(BUILD_FOR_TV) && defined(TIZEN)
			ecore_x_window_free(XWIN);
#else
			XDestroyWindow(XDPY, XWIN);
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
			XDestroyWindow(XDPY, DUMMY_XWIN);
#endif
#endif
			//XCloseDisplay(XDPY);
		}

		void ShowXWindow()
		{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
			//ecore_x_window_show(XWIN);
			//ecore_x_window_move_resize(XWIN, 0, 0, WIDTH, HEIGHT);
			XMapWindow(XDPY, XWIN);
			//XMoveResizeWindow(XDPY, XWIN, 0, 0, WIDTH, HEIGHT);

#if TIZEN_KEY_CONTROL
			// clear all keys and enable EXIT key only
			KeyRepository_RemoveAllKeys(&KEYREPO);
			KeyRepository_AddKey(&KEYREPO, R_KEY_EXIT);
			KeyRepository_Register(XDPY, XWIN, &KEYREPO);

			//  utilx_grab_key(XDPY, XWIN, "1", TOP_POSITION_GRAB);
			//  utilx_grab_key(XDPY, XWIN, "3", TOP_POSITION_GRAB);
			//  utilx_grab_key(XDPY, XWIN, "9", TOP_POSITION_GRAB);
#endif
#else
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
			XMapWindow(XDPY, DUMMY_XWIN);
#endif
			XMapWindow(XDPY, XWIN);
			XMoveResizeWindow(XDPY, XWIN, 0, 0, WIDTH, HEIGHT);
#endif
		}

		void HideXWindow()
		{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
			ecore_x_window_hide(XWIN);
#else
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
			XUnmapWindow(XDPY, DUMMY_XWIN);
#endif
			XUnmapWindow(XDPY, XWIN);
#endif
		}

		/* TEMP */
		void MoveShowXWindow()
		{
			XMoveWindow(XDPY, XWIN, 0, 0);
		}

		/* TEMP */
		void MoveHideXWindow()
		{
			XMoveWindow(XDPY, XWIN, -2 * WIDTH, -2 * HEIGHT);
		}

		void SetXWindowName(const std::string& name)
		{
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
			if (XDPY && DUMMY_XWIN)
			{
				std::string dummy_name("Dummy - ");
				dummy_name += name;
				XStoreName(XDPY, DUMMY_XWIN, dummy_name.c_str());
			}
#endif

			if (XDPY && XWIN)
			{
				XStoreName(XDPY, XWIN, name.c_str());
			}
		}

		bool AddKey(int keyCode)
		{
#if TIZEN_KEY_CONTROL
#if defined(BUILD_FOR_TV) && defined(TIZEN)
			Logger logger("volt.util.clutter");
			const char *key = GetTizenKeyName(keyCode);
			if (key)
			{
				LOG_ERROR(logger, "adding key code : " << keyCode << " key string " << std::string(key));
				utilx_grab_key(XDPY, XWIN, key, TOP_POSITION_GRAB);
				return true;
			}

			LOG_ERROR(logger, "unable to map key " << keyCode << " for adding");
			return false;
#endif
#endif
			return true;
		}

		bool RemoveKey(int keyCode)
		{
#if TIZEN_KEY_CONTROL
#if defined(BUILD_FOR_TV) && defined(TIZEN)
			Logger logger("volt.util.clutter");
			const char *key = GetTizenKeyName(keyCode);
			if (key)
			{
				LOG_ERROR(logger, "removing key code : " << keyCode << " key string " << std::string(key));
				utilx_ungrab_key(XDPY, XWIN, key);
				return true;
			}

			LOG_ERROR(logger, "unable to map key " << keyCode << " for removal");
			return false;
#endif
#endif
			return true;
		}

		const char* GetTizenKeyName(int voltKeyEvent)
		{
#if TIZEN_KEY_CONTROL
#if defined(BUILD_FOR_TV) && defined(TIZEN)
			Logger logger("volt.util.clutter");
			unsigned int arraySize = sizeof(keyMap) / sizeof(KeyMapping);
			for (unsigned i = 0; i < arraySize; i++)
			{
				if (keyMap[i].volt == voltKeyEvent)
				{
					// TODO DUE TO OVERLAPPING VOLT KEY VALUES,
					// we should keep looking until we find some thing..
					// but in the long run we should REALLY use a separate mapping..
					if (keyMap[i].utilX)
					{
						return keyMap[i].utilX;
					}
				}
			}
#endif
#endif
			return nullptr;
		}

		bool IsVoltKeyEvent(int eventId)
		{
#if TIZEN_KEY_CONTROL
#if defined(BUILD_FOR_TV) && defined(TIZEN)
			unsigned int arraySize = sizeof(keyMap) / sizeof(KeyMapping);
			for (unsigned i = 0; i < arraySize; i++)
			{
				if (keyMap[i].volt == eventId)
				{
					return true;
				}
			}
			return false;
#else
			return true;	// always return true since there is no actual key registration needed
#endif
#else
			return false; // for now we are not going to do ANY key handling..
#endif
		}


		// raise xwindow
		void VDRaiseXWindow(void *aStage)
		{
			Logger logger("volt.util.clutter");

			LOG_DEBUG(logger, "VDRaiseXWindow");

			Window window = (Window)clutter_x11_get_stage_window((ClutterStage*)aStage);
			Display* display = clutter_x11_get_default_display();

			Atom a_active;

			if (display != NULL)
			{
				a_active = XInternAtom(display, "_NET_ACTIVE_WINDOW", False);

				XEvent xev;

				Window root;
				root = XDefaultRootWindow(display);

				xev.xclient.type = ClientMessage;
				xev.xclient.display = display;
				xev.xclient.window = window;
				xev.xclient.message_type = a_active;
				xev.xclient.format = 32;
				xev.xclient.data.l[0] = 1; // active
				xev.xclient.data.l[1] = CurrentTime;
				xev.xclient.data.l[2] = 0;
				xev.xclient.data.l[3] = 0;
				xev.xclient.data.l[4] = 0;

				XSendEvent(display, root, False, SubstructureRedirectMask | SubstructureNotifyMask, &xev);
			}
			else
			{
				LOG_ERROR(logger, "VDRaiseXWindow display is NULL");
			}
			//	XRaiseWindow(display, window);
		}

		void VDLowerXWindow(void *aStage)
		{
			Logger logger("volt.util.clutter");

			LOG_DEBUG(logger, "VDLowerXWindow");

			Window window = (Window)clutter_x11_get_stage_window((ClutterStage*)aStage);
			Display* display = clutter_x11_get_default_display();

			XLowerWindow(display, window);
		}

		void VDMapXWindow(void *aStage)
		{
			Logger logger("volt.util.clutter");

			LOG_DEBUG(logger, "VDMapXWindow");

			Window window = (Window)clutter_x11_get_stage_window((ClutterStage*)aStage);
			Display* display = clutter_x11_get_default_display();

			XMapWindow(display, window);
		}

		void VDUnmapXWindow(void *aStage)
		{
			Logger logger("volt.util.clutter");

			LOG_DEBUG(logger, "VDUnmapXWindow");

			Window window = (Window)clutter_x11_get_stage_window((ClutterStage*)aStage);
			Display* display = clutter_x11_get_default_display();

			XUnmapWindow(display, window);
		}


		typedef struct {
			uint8_t blue;
			uint8_t green;
			uint8_t red;
			uint8_t alpha;
		} pixel_t;

		/* A picture. */

		typedef struct  {
			pixel_t *pixels;
			size_t width;
			size_t height;
		} bitmap_t;

		/* Given "bitmap", this returns the pixel of bitmap at the point
		("x", "y"). */

		static pixel_t * pixel_at(bitmap_t * bitmap, int x, int y)
		{
			return bitmap->pixels + bitmap->width * y + x;
		}

		/* Write "bitmap" to a PNG file specified by "path"; returns 0 on
		success, non-zero on error. */
		static int save_png_to_file(bitmap_t *bitmap, const char *path)
		{
			FILE * fp;
			png_structp png_ptr = NULL;
			png_infop info_ptr = NULL;
			size_t x, y;
			png_byte ** row_pointers = NULL;
			/* "status" contains the return value of this function. At first
			it is set to a value which means 'failure'. When the routine
			has finished its work, it is set to a value which means
			'success'. */
			int status = -1;
			/* The following number is set by trial and error only. I cannot
			see where it it is documented in the libpng manual.
			*/
			int pixel_size = 3;
			int depth = 8;

			fp = fopen(path, "wb");
			if (!fp) {
				goto fopen_failed;
			}

			png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
			if (png_ptr == NULL) {
				goto png_create_write_struct_failed;
			}

			info_ptr = png_create_info_struct(png_ptr);
			if (info_ptr == NULL) {
				goto png_create_info_struct_failed;
			}

			/* Set up error handling. */

			if (setjmp(png_jmpbuf(png_ptr))) {
				goto png_failure;
			}

			/* Set image attributes. */

			png_set_IHDR(png_ptr,
				info_ptr,
				bitmap->width,
				bitmap->height,
				depth,
				PNG_COLOR_TYPE_RGB,
				PNG_INTERLACE_NONE,
				PNG_COMPRESSION_TYPE_DEFAULT,
				PNG_FILTER_TYPE_DEFAULT);

			/* Initialize rows of PNG. */

			row_pointers = (png_byte **)png_malloc(png_ptr, bitmap->height * sizeof (png_byte *));
			for (y = 0; y < bitmap->height; ++y) {
				png_byte *row = (png_byte *)
					png_malloc(png_ptr, sizeof (uint8_t)* bitmap->width * pixel_size);
				row_pointers[y] = row;
				for (x = 0; x < bitmap->width; ++x) {
					pixel_t * pixel = pixel_at(bitmap, x, y);
					*row++ = pixel->red;
					*row++ = pixel->green;
					*row++ = pixel->blue;
				}
			}

			/* Write the image data to "fp". */

			png_init_io(png_ptr, fp);
			png_set_rows(png_ptr, info_ptr, row_pointers);
			png_write_png(png_ptr, info_ptr, PNG_TRANSFORM_IDENTITY, NULL);

			/* The routine has successfully written the file, so we set
			"status" to a value which indicates success. */

			status = 0;

			for (y = 0; y < bitmap->height; y++) {
				png_free(png_ptr, row_pointers[y]);
			}
			png_free(png_ptr, row_pointers);

		png_failure:
		png_create_info_struct_failed :
			png_destroy_write_struct(&png_ptr, &info_ptr);
								  png_create_write_struct_failed:
									  fclose(fp);
								  fopen_failed:
									  return status;
		}

		/* Given "value" and "max", the maximum value which we expect "value"
		to take, this returns an integer between 0 and 255 proportional to
		"value" divided by "max". */

		static int pix(int value, int max)
		{
			if (value < 0)
				return 0;
			return (int)(256.0 *((double)(value) / (double)max));
		}


		void ScreenCapture(void *aStage, const char* fileName, int height)
		{
			Window window = (Window)clutter_x11_get_stage_window((ClutterStage*)aStage);
			Display* display = clutter_x11_get_default_display();

			int width = (int)(height / 3.0f * 4.0f);

			XImage *image = XGetImage(display, window, 0, 0, width, height, XAllPlanes(), ZPixmap);

			bitmap_t bitmap;
			bitmap.width = width;
			bitmap.height = height;
			bitmap.pixels = (pixel_t*)image->data;

			save_png_to_file(&bitmap, fileName);

			XDestroyImage(image);
		}

		void ScreenCapture(char* appId, char* json)
		{
			printf("-------------> dc_request_capture\n");
			if (XDPY != NULL)
			{
				dc_complete_xwd_capture(DC_APP_TYPE_VOLT_APP, DC_MODE_SCREEN, appId, json, XWIN);
			}

		}

		std::string GetAppName()	//TODO LYJ temp for capture API
		{
			std::string appName = AppConfig::Instance().GetValue<std::string>("app-name");
			LOG_FATAL(LOGGER, "[LYJ] ---- appName [" << appName << "]");
			if (appName.empty())
			{
				try
				{
					//std::string appjs = AppConfig::Instance().GetRelativeAppJsPath();
					std::string appjs = AppConfig::Instance().GetAppRootPath();
					LOG_FATAL(LOGGER, "[LYJ] ---- appjs [" << appjs << "]");
					if (boost::starts_with(appjs, "/opt/down/panels/apps"))
					{
						return std::string("Apps");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/clips"))
					{
						return std::string("Clips");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/games"))
					{
						return std::string("Games");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/mycontents"))
					{
						return std::string("My Contents");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/newson"))
					{
						return std::string("NewsOn");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/soccer"))
					{
						return std::string("Soccer");
					}

					if (boost::starts_with(appjs, "/usr/apps/org.volt.smarthub-tutorial"))
					{
						return std::string("smarthub-tutorial");
					}

				}
				catch (boost::bad_any_cast)
				{
				}
			}

			return appName;
		}

		std::string GetAppId()	//TODO LYJ temp for capture API
		{
			printf("[lyj] GetAppId() 1 \n");
			AppConfig::Instance();
			printf("[lyj] GetAppId() 1-1 \n");
			std::string appId = AppConfig::Instance().GetValue<std::string>("app-id");
			LOG_FATAL(LOGGER, "[LYJ] ---- appId [" << appId << "]");
			printf("[lyj] GetAppId() 2 \n");
			if (appId.empty())
			{
				printf("[lyj] GetAppId() 3 \n");
				try
				{
					printf("[lyj] GetAppId() 4 \n");
					std::string appjs = AppConfig::Instance().GetAppRootPath();
					std::string relativeappjs = AppConfig::Instance().GetRelativeAppJsPath();
					std::string appdata = AppConfig::Instance().GetAppDataPath();

					printf("[lyj] GetAppId() appjs [%s] \n", appjs.c_str());
					printf("[lyj] GetAppId() appjs [%s] \n", relativeappjs.c_str());
					printf("[lyj] GetAppId() appjs [%s] \n", appdata.c_str());

					LOG_FATAL(LOGGER, "[LYJ] ---- appjs [" << appjs << "]");
					LOG_FATAL(LOGGER, "[LYJ] ---- relativeappjs [" << relativeappjs << "]");
					LOG_FATAL(LOGGER, "[LYJ] ---- appdata [" << appdata << "]");

					printf("[lyj] GetAppId() 5 \n");

					if (boost::starts_with(appjs, "/opt/down/panels/apps"))
					{
						return std::string("org.volt.apps");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/clips"))
					{
						return std::string("org.volt.clips");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/games"))
					{
						return std::string("org.volt.games");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/mycontents"))
					{
						return std::string("org.volt.mycontents");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/newson"))
					{
						return std::string("org.volt.newson");
					}

					if (boost::starts_with(appjs, "/opt/down/panels/soccer"))
					{
						return std::string("org.volt.soccer");
					}

					if (boost::starts_with(appjs, "/usr/apps/org.volt.smarthub-tutorial"))
					{
						return std::string("org.volt.smarthub-tutorial");
					}


				}
				catch (boost::bad_any_cast)
				{
					printf("[lyj] catch (boost::bad_any_cast)\n");
				}
			}
			printf("[lyj] GetAppId() end \n");
			return appId;
		}

		std::string GetAppIcon()	//TODO LYJ temp for capture API
		{
			std::string appIcon = AppConfig::Instance().GetValue<std::string>("app-icon");
			if (appIcon.empty())
			{
				return std::string("");
			}

			return appIcon;
		}


		int Capture()	//TODO LYJ temp for capture API
		{
			LOG_ERROR(LOGGER, "[LYJ] -------Capture");
			std::string appId = GetAppId();
			LOG_ERROR(LOGGER, "[LYJ] ---- 1 appId [" << appId << "]");
			std::string appName = GetAppName();
			LOG_ERROR(LOGGER, "[LYJ] ---- 1 appName [" << appName << "]");
			std::string appIcon = GetAppIcon();
			LOG_ERROR(LOGGER, "[LYJ] ---- 1 appIcon [" << appIcon << "]");

			if (appId.empty() || appId == "org.volt.firstscreen" || appId == "org.volt.games" || appId == "org.volt.apps")
			{
				return 0;
			}

			int value = 1080;
			int systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT, &value);

			if (systemResult != SYSTEM_INFO_ERROR_NONE)
			{
				LOG_FATAL(LOGGER, "Failed to get value for Resolution[" << SYSTEM_INFO_KEY_OSD_RESOLUTION_HEIGHT << "]");
			}

			time_t curTime;
			time(&curTime);

			LOG_ERROR(LOGGER, "[lyj] Capture Screenshot-----------------------------------------------\n");

			int caller_pid;
			//char caller_appid[255] = { 0, };
			char *caller_appid = NULL;

			/*
			bundle_get_str(caller_bundle, "caller_id", &caller_appid);
			printf("[lyj] ----------------------------> caller_appid : %s \n", caller_appid);
			LOG_FATAL(LOGGER, "Failed to get value for Resolution[" << caller_appid << "]");
			*/
			/*
			//resolution
			caller_pid = atoi(bundle_get_val(caller_bundle, AUL_K_CALLER_PID));
			aul_app_get_appid_bypid(caller_pid, caller_appid, sizeof(caller_appid));
			//caller_app_id
			printf("[lyj] ----------------------------> caller_appid : %s \n", caller_appid);
			*/

			char json[JSON_LENGTH] = { 0, };
			snprintf(json, JSON_LENGTH, "'app_title': '%s', 'cur_time': %ld, 'caller_app_id': '%s'", const_cast<char*>(appName.c_str()), curTime, call_app_id);


			ScreenCapture(const_cast<char*>(appId.c_str()), json);
			LOG_ERROR(LOGGER, "[LYJ] ---- app_info [" << json << "]");
			char *history_event = vconf_get_str("memory/volt/history_event");
			LOG_ERROR(LOGGER, "[LYJ] ---- memory/volt/history_event: [" << history_event << "]");
			delete []history_event;

			return 0;
		}

		void setCallerBundler(bundle *b){
			caller_bundle = b;
		}

		char* getCallerAppID(){
			return call_app_id;
		}

		void setCallerAppID(bundle *b){
			call_app_id = NULL;
			bundle_get_str(b, "caller_id", &call_app_id);
			if (call_app_id == NULL){
				call_app_id = "";
			}
		}

	} /* namespace util */
} /* namespace volt */
