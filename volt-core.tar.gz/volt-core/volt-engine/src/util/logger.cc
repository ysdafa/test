#include "logger.h"

#include "VoltConfig.h"

#include <sys/types.h>
#include <unistd.h>
#include <strings.h>
#include <iostream>

#ifdef USE_LOG4CPLUS
#include <log4cplus/configurator.h>
#else
#include <boost/algorithm/string.hpp>
#endif

namespace volt
{
namespace util
{

#ifdef USE_LOG4CPLUS
#else
Logger::LogLevel Logger::level_ = Logger::kFatal;
#endif

Logger::Logger(const std::string &aName):
#ifdef USE_LOG4CPLUS
  logger_(log4cplus::Logger::getInstance(aName))
#else
  name_(aName)
#endif
{
#if !defined(USE_LOG4CPLUS) && defined(USE_DLOG)

  if (name_.empty())
  {
    name_ = "VOLT";
  }
  else
  {
    /* Make the string to the first dot the tag to be used for dlog. */
    size_t dot = name_.find('.');

    if (dot != std::string::npos)
    {
      name_.erase(dot);
    }

    boost::to_upper(name_);

    /* Temp: just to make sure we don't have any unwanted non-volt tags */
    if (name_.find("VOLT", 0) != 0)
    {
      fprintf(stderr, "\n\n[%s:%d] Weird name: %s\n\n", __FILE__, __LINE__, name_.c_str());
    }
  }

#endif
}

Logger::~Logger()
{
}

void Logger::Configure(const std::string &aConfigPath)
{
#ifdef USE_LOG4CPLUS
  log4cplus::PropertyConfigurator config(aConfigPath);
  config.configure();
#endif
}

void Logger::SetLogLevel(const LogLevel aLevel)
{
#ifdef USE_LOG4CPLUS
  log4cplus::Logger::getRoot().setLogLevel(Log4CplusLevel(aLevel));
#else
  level_ = aLevel;
#endif
}

const char* Logger::LevelToString(const LogLevel aLevel)
{
  switch(aLevel)
  {
  case kFatal:
    return "Fatal";
  case kMajor:
    return "Major";
  case kWarn:
    return "Warn";
  case kDebug:
    return "Debug";
  case kInfo:
    return "Info";
  default:
    return "???";
  }
}

Logger::LogLevel Logger::StringToLevel(const char *aLevelStr)
{
  if (aLevelStr == NULL)
  {
    return kFatal;
  }
  else if(strcasecmp(aLevelStr, "major") == 0)
  {
    return kMajor;
  }
  else if(strcasecmp(aLevelStr, "warn") == 0)
  {
    return kWarn;
  }
  else if(strcasecmp(aLevelStr, "debug") == 0)
  {
    return kDebug;
  }
  else if(strcasecmp(aLevelStr, "info") == 0)
  {
    return kInfo;
  }
  else
  {
    return kFatal;
  }
}

Logger& Logger::DefaultLogger()
{
  static Logger logger("volt");
  return logger;
}

#ifdef USE_LOG4CPLUS
log4cplus::LogLevel Logger::Log4CplusLevel(const LogLevel aLevel)
{
  switch (aLevel)
  {
  case kMajor:
    return log4cplus::ERROR_LOG_LEVEL;
  case kWarn:
    return log4cplus::WARN_LOG_LEVEL;
  case kDebug:
    return log4cplus::DEBUG_LOG_LEVEL;
  case kInfo:
    return log4cplus::TRACE_LOG_LEVEL;
  case kFatal:
  default:
    return log4cplus::FATAL_LOG_LEVEL;
  }
}
#else
void Logger::Log(const char *aFile, const char *aFunc, const unsigned int aLine,
                 const LogLevel aLevel, const std::string &aMsg) const
{
  time_t time_stamp = time(NULL);
  struct tm tm_buf;
  localtime_r(&time_stamp, &tm_buf);
  char date_buf[20];

  if (strftime(date_buf, 20, "%Y-%m-%dT%H:%M:%S", &tm_buf) == 0)
  {
    date_buf[0] = '\0';
  }

  const char *file_name = strrchr(aFile, '/') ? strrchr(aFile, '/') + 1 : aFile;

  std::ostringstream the_msg;

  the_msg << "[Volt|Engine|" << date_buf << "|" << getpid() << "|"
          << pthread_self() << "|" << file_name << "|" << aFunc << "|" << aLine
          << "] " << aMsg;

  Log(aLevel, the_msg.str());
}

void Logger::Log(const LogLevel aLevel, const std::string &aMsg) const
{
  std::ostringstream the_msg;
  the_msg << aMsg << std::endl;

#ifdef USE_DLOG
  log_priority prio = DLOG_VERBOSE;

  switch (aLevel)
  {
  case kFatal:
    prio = DLOG_FATAL;
    break;
  case kMajor:
    prio = DLOG_ERROR;
    break;
  case kWarn:
    prio = DLOG_WARN;
    break;
  case kDebug:
    prio = DLOG_DEBUG;
    break;
  case kInfo:
    prio = DLOG_VERBOSE;
    break;
  default:
    break;
  }

  /* Argh, i don't like this code...
   * Splitting the message to be < 1024 characters long because dlog truncates
   * messages that are longer...
   * Attempt to split on a new-line if possible... */

  static const int DLOG_BUF_SIZE = 1024;

  if (the_msg.str().length() < DLOG_BUF_SIZE)
  {
    /* Whew, no need to split... */
    __dlog_print(LOG_ID_MAIN, prio, name_.c_str(), "%s", the_msg.str().c_str());
  }
  else
  {
    char *msg = new char[the_msg.str().length() + 1];
    memmove(msg, the_msg.str().c_str(), the_msg.str().length() + 1);

    char *head = msg;
    char *tail = NULL;
    char tail_bak = '\0';
    char *new_line = NULL;
    char new_line_bak = '\0';

    do
    {
      /* End of this DLOG_BUF_SIZE chunk */
      tail = &(head[DLOG_BUF_SIZE - 1]);
      tail_bak = *tail; /* Save the original tail char */
      *tail = '\0'; /* Split, null-terminate here */

      new_line = strrchr(head, '\n');

      if (new_line)
      {
        /* Let's try to split at a new line */
        new_line_bak = *(new_line + 1); /* Save orig char */
        *(new_line + 1) = '\0'; /* Null terminate here */

        __dlog_print(LOG_ID_MAIN, prio, name_.c_str(), "%s", head);

        *(new_line + 1) = new_line_bak; /* Revert */
        head = new_line + 1; /* Start from 1 char after the new-line */
      }
      else
      {
        /* No new line in this chunk, let's just print the whole thing... */
        __dlog_print(LOG_ID_MAIN, prio, name_.c_str(), "%s", head);

        head = tail;
      }

      *tail = tail_bak; /* Revert the original tail char */
    }
    while(strlen(head) >= DLOG_BUF_SIZE);

    if (*head != '\0')
    {
      __dlog_print(LOG_ID_MAIN, prio, name_.c_str(), "%s", head);
    }

    delete [] msg;
  }

#else

  if (aLevel > level_)
  {
    return;
  }

  printf("%s", the_msg.str().c_str());
#endif
}
#endif

} /* namespace util */
} /* namespace snap */
