#include "LinuxXWindowManager.h"
#include "VoltConfig.h"
#include <clutter/x11/clutter-x11.h>
#include "logger.h"
#include <string.h>

using volt::util::Logger;
using namespace volt::util;

namespace
{
Logger logger("volt.util.linuxxwindowmanager");
}

LinuxXWindowManager::LinuxXWindowManager()
{
}

LinuxXWindowManager::~LinuxXWindowManager()
{
}


bool LinuxXWindowManager::CreateDisplay()
{
  int retval = -1;

  do
  {

    if (XInitThreads() == 0)
    {
      LOG_ERROR(logger, "XInitThreads failed");
      break;
    }

    /* Check if already opened? */
    m_xdpy = XOpenDisplay(NULL);

    if (!m_xdpy)
    {

      LOG_WARN(logger, "Failed to open display; trying :0...");
      setenv("DISPLAY", ":0", 1);
      m_xdpy = XOpenDisplay(NULL);

      if (!m_xdpy)
      {
        LOG_ERROR(logger, "Failed to open display");
        break;
      }
    }

    LOG_DEBUG(logger, "Opened X display: " << m_xdpy);

    clutter_x11_set_display(m_xdpy);

    retval = 0;
  }
  while (0);

  return retval == 0;
}

bool LinuxXWindowManager::CreateWindow(const int width, const int height)
{
  if (m_xdpy == NULL)
  {
    LOG_FATAL(logger, "XDisplay is not initialized yet");
    return false;
  }

  m_width = width;
  m_height = height;

  /* We want to test that Cogl can handle foreign X windows... */
  XVisualInfo *xvisinfo = clutter_x11_get_visual_info();

  /* window attributes */
  XSetWindowAttributes xattr = GetWindowAttributes(xvisinfo);

  unsigned long mask = CWBorderPixel | CWColormap | CWEventMask;

#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
  /* A dummy off-screen window.
   * For some reason on the X12, X14, NT14U, and GOLFS possibly due to Mali driver
   * differences, you must create a dummy window underneath your main window.
   * Otherwise the app will hang waiting for a reply from the X server that
   * never comes. */
  m_dummy = XCreateWindow(XDPY,
                          DefaultRootWindow(XDPY),
                          -200, -200,
                          1, 1,
                          0,
                          xvisinfo->depth,
                          InputOutput,
                          xvisinfo->visual,
                          mask, &xattr);
#endif

  m_xwin = XCreateWindow(m_xdpy,
                         DefaultRootWindow(m_xdpy),
                         0, 0,
                         width, height,
                         0,
                         xvisinfo->depth,
                         InputOutput,
                         xvisinfo->visual,
                         mask,
                         &xattr);

  XFree(xvisinfo);

  return true;

}

void LinuxXWindowManager::ShowWindow()
{

#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
  XMapWindow(m_xdpy, m_dummy);
#endif
  XMapWindow(m_xdpy, m_xwin);

  XMoveResizeWindow(m_xdpy, m_xwin, 0, 0, m_width, m_height);
}

void LinuxXWindowManager::HideWindow()
{

#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
  XUnmapWindow(XDPY, DUMMY_XWIN);
#endif
  XUnmapWindow(m_xdpy, m_xwin);
}
