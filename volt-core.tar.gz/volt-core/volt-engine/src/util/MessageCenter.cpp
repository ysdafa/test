#include "MessageCenter.h"

#include <boost/interprocess/sync/scoped_lock.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

using namespace boost::interprocess;

namespace volt
{
namespace util
{
namespace ipc
{

volt::util::Logger MessageCenter::LOGGER("volt.ipc");

MessageCenter* MessageCenter::singleton_ = NULL;


void MessageCenter::PrepareInstance()
{
  if (singleton_)
  {
    delete singleton_;
  }

  singleton_ = new MessageCenter();
}

MessageCenter& MessageCenter::Instance()
{
  return *singleton_;
}

MessageCenter::MessageCenter():
  shm_name_(), segment_mutex_(), segment_(), msg_handle_alloc_(),
  remove_shm_(false), queues_(), main_loop_threads_(), dealloc_signal_(NULL)
#ifdef SAMPLE_IPC
  , post_samples_(0), post_samples_timer_(),
  exec_samples_(0), exec_samples_timer_(), result_handler_timer_()
#endif
{
#ifdef SAMPLE_IPC
  post_samples_timer_.Start();
  exec_samples_timer_.Start();
#endif
}

MessageCenter::~MessageCenter()
{
  Destroy();
}

bool MessageCenter::Initialize(const std::string aName,
                               const size_t aSize)
{
  shm_name_ = aName;
  shared_memory_object::remove(shm_name_.c_str());

  try
  {
    size_t the_size = PageSize();

    if (the_size > 0)
    {
      /* align to page size */
      size_t mod = aSize % PageSize();
      the_size = aSize + (PageSize() - mod);
    }

    LOG_DEBUG(LOGGER, "aSize:" << aSize << " the_size:" << the_size);
    segment_ = managed_shared_memory(create_only, shm_name_.c_str(), the_size);
  }
  catch (interprocess_exception &e)
  {
    LOG_WARN(LOGGER, "Failed to create shared memory: " << e.what());
    return false;
  }

  remove_shm_ = true;

  msg_handle_alloc_.reset(new MessageHandleAlloc(segment_.get_segment_manager()));

  dealloc_signal_ = segment_.find_or_construct<DeallocSignal>("_dealloc_signal_")();

  LOG_FATAL(LOGGER, "Initialized MessageCenter: " << shm_name_);

  LOG_WARN(LOGGER, "After initialize: " <<
           segment_.get_free_memory() << "/" <<
           segment_.get_size() << " free");

  return true;
}

bool MessageCenter::Attach(const std::string aName)
{
  shm_name_ = aName;

  try
  {
    segment_ = managed_shared_memory(open_only, shm_name_.c_str());
  }
  catch (interprocess_exception &e)
  {
    LOG_WARN(LOGGER,
             "Failed to attach to shared memory " << aName << ": " << e.what());
    return false;
  }

  remove_shm_ = false;

  msg_handle_alloc_.reset(new MessageHandleAlloc(segment_.get_segment_manager()));

  dealloc_signal_ = segment_.find_or_construct<DeallocSignal>("_dealloc_signal_")();

  LOG_WARN(LOGGER, "After attach: " <<
           segment_.get_free_memory() << "/" <<
           segment_.get_size() << " free");

  return true;
}

void MessageCenter::Destroy(const bool aForce)
{
  LOG_WARN(LOGGER, "Destroying resources: " <<
           segment_.get_free_memory() << "/" <<
           segment_.get_size() << " free");

  for (auto qiter = queues_.begin(); qiter != queues_.end(); ++qiter)
  {
    auto iter = main_loop_threads_.find(qiter->first);

    if (iter != main_loop_threads_.end() &&
        iter->second.joinable()
       )
    {
      LOG_DEBUG(LOGGER, "Joining the main loop thread on " << qiter->first);
      iter->second.join();
    }

    LOG_DEBUG(LOGGER, "Destroying queues on " << qiter->first);

    if (remove_shm_ || aForce)
    {
      qiter->second->shared->Clear();
    }

    qiter->second->shared.reset();
  }

  queues_.clear();

  msg_handle_alloc_.reset();

  LOG_WARN(LOGGER, "Destroyed resources: " <<
           segment_.get_free_memory() << "/" <<
           segment_.get_size() << " free");

  if ((remove_shm_ || aForce) && shm_name_.empty() == false)
  {
    shared_memory_object::remove(shm_name_.c_str());
  }

  remove_shm_ = false;

  shm_name_.clear();
}

size_t MessageCenter::PageSize() const
{
  return mapped_region::get_page_size();
}

bool MessageCenter::CreateNamedQueue(const std::string aQueueName,
                                     const size_t aSize)
{
  if (aQueueName.empty() == false && queues_.count(aQueueName) == 0)
  {
    SharedQueuePtr queue = CreateQueue(aQueueName.c_str(), aSize);

    if (queue)
    {
      QueueSetPtr tmp(new QueueSet(queue));
      tmp->name = aQueueName;
      queues_.insert(std::make_pair(aQueueName, tmp));
      return true;
    }
  }

  return false;
}

bool MessageCenter::DestroyNamedQueue(const std::string aQueueName)
{
  auto iter = queues_.find(aQueueName);

  if (iter != queues_.end())
  {
    iter->second->shared->Destroy();
    queues_.erase(iter);

    return true;
  }

  return false;
}

void* MessageCenter::CreateSharedData(const void *aData, const size_t aSize,
                                      const int aMaxWaitTime)
{
  //std::lock_guard<std::mutex> lock(segment_mutex_);
  while (true)
  {
    try
    {
      void *ptr = segment_.allocate(aSize);
      memcpy(ptr, aData, aSize);
      return ptr;
    }
    catch (boost::interprocess::bad_alloc &e)
    {
      LOG_WARN(LOGGER, "Failed to allocate data of size " << aSize);

      if (aSize > segment_.get_size() * 0.7)
      {
        /* No retry for allocation > 70% of total size. */
        return NULL;
      }

      if (WaitForFreeMemory(aSize, aMaxWaitTime) == false)
      {
        return NULL;
      }
    }
  }
}

void MessageCenter::DestroyPtr(void *aPtr)
{
  LOG_TRACE(LOGGER, "Deallocating ptr: " << aPtr);
  //std::lock_guard<std::mutex> lock(segment_mutex_);
  segment_.deallocate(aPtr);
  dealloc_signal_->cond_deallocd.notify_one();
}

MessageCenter::SharedHandle MessageCenter::GetSharedHandle(void *aLocalAddr)
{
  //std::lock_guard<std::mutex> lock(segment_mutex_);
  return segment_.get_handle_from_address(aLocalAddr);
}

void* MessageCenter::GetLocalAddr(const SharedHandle aHandle)
{
  //std::lock_guard<std::mutex> lock(segment_mutex_);
  return segment_.get_address_from_handle(aHandle);
}

bool MessageCenter::PostMessage(const std::string aQueueName,
                                MessageType aType)
{
  return PostMessage(aQueueName, -1, aType, NULL, 0);
}

bool MessageCenter::PostMessage(const std::string aQueueName,
                                MessageType aType,
                                void *aData, const size_t aSize)
{
  return PostMessage(aQueueName, -1, aType, aData, aSize);
}

bool MessageCenter::PostMessage(const std::string aQueueName,
                                const int aMaxWaitTime,
                                MessageType aType)
{
  return PostMessage(aQueueName, aMaxWaitTime, aType, NULL, 0);
}

bool MessageCenter::PostMessage(const std::string aQueueName,
                                const int aMaxWaitTime,
                                MessageType aType,
                                void *aData, const size_t aSize)
{
  return PostMessage(aQueueName, aMaxWaitTime, "", aType, aData, aSize);
}

bool MessageCenter::PostMessage(const std::string aQueueName,
                                const int aMaxWaitTime,
                                const std::string aReplyTo,
                                MessageType aType,
                                void *aData, const size_t aSize)
{
  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return false;
  }

  Message *msg = CreateMessage();

  if (msg == NULL)
  {
    return false;
  }

  msg->Type(aType);
  msg->SetReplyTo(aReplyTo);

  if (aData)
  {
    if (msg->SetData(aData, aSize) == false)
    {
      LOG_WARN(LOGGER, "Failed to set data to msg: " << *msg);
      DestroyMessage(msg);
      return false;
    }
  }

  bool result = PostMessageWithTimeout(queue, msg, aMaxWaitTime);

#ifdef SAMPLE_IPC
  ++post_samples_;

  if (post_samples_timer_.Elapsed() >= 5)
  {
    LOG_WARN(LOGGER, "[SEND] msg:" << post_samples_ <<
             " elapsed:" << std::fixed << std::setprecision(3) << post_samples_timer_.Elapsed());
    post_samples_ = 0;
    post_samples_timer_.Restart();
  }

#endif

  return result;
}

bool MessageCenter::ExecuteCommand(const std::string aQueueName,
                                   MessageType aType, ResultHandler aHandler)
{
  return ExecuteCommand(aQueueName, -1, aType, aHandler, NULL, 0);
}

bool MessageCenter::ExecuteCommand(const std::string aQueueName,
                                   MessageType aType, ResultHandler aHandler,
                                   void *aData, const size_t aSize)
{
  return ExecuteCommand(aQueueName, -1, aType, aHandler, aData, aSize);
}

bool MessageCenter::ExecuteCommand(const std::string aQueueName,
                                   const int aMaxWaitTime,
                                   MessageType aType,
                                   ResultHandler aHandler)
{
  return ExecuteCommand(aQueueName, aMaxWaitTime, aType, aHandler, NULL, 0);
}

bool MessageCenter::ExecuteCommand(const std::string aQueueName,
                                   const int aMaxWaitTime,
                                   MessageType aType,
                                   ResultHandler aHandler,
                                   void *aData, const size_t aSize)
{
  return ExecuteCommand(aQueueName, aMaxWaitTime, "", aType, aHandler, aData, aSize);
}

bool MessageCenter::ExecuteCommand(const std::string aQueueName,
                                   const int aMaxWaitTime,
                                   const std::string aReplyTo,
                                   MessageType aType,
                                   ResultHandler aHandler,
                                   void *aData, const size_t aSize)
{
  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return false;
  }

  Command *cmd = CreateCommand();

  if (cmd == NULL)
  {
    return false;
  }

  cmd->Type(aType);
  cmd->SetReplyTo(aReplyTo);

  if (aData)
  {
    if (cmd->SetData(aData, aSize) == false)
    {
      LOG_WARN(LOGGER, "Failed to set data to msg: " << *cmd);
      DestroyMessage(cmd);
      return false;
    }
  }

  if (PostMessageWithTimeout(queue, cmd, aMaxWaitTime) == false)
  {
    return false;
  }

  LOG_TRACE(LOGGER, "Waiting for result for cmd: " << *cmd);
  Command::ResultPair result = cmd->GetResult(aMaxWaitTime);
  LOG_TRACE(LOGGER, "Got result for cmd: " << *cmd);

  if (result.first)
  {
    if (aHandler)
    {
      LOG_TRACE(LOGGER, "Executing result handler for " << *cmd);
#ifdef SAMPLE_IPC
      result_handler_timer_.Start();
#endif
      aHandler(result.first, result.second);
#ifdef SAMPLE_IPC
      result_handler_timer_.Stop();
#endif
    }

    DestroyPtr(result.first);
  }

  DestroyMessage(cmd);

#ifdef SAMPLE_IPC
  ++exec_samples_;

  if (exec_samples_timer_.Elapsed() >= 5)
  {
    LOG_WARN(LOGGER, "[SEND] cmd:(" << exec_samples_ << ", " <<
             std::fixed << std::setprecision(3) << result_handler_timer_.Elapsed() <<
             ") elapsed:" << std::setprecision(3) << exec_samples_timer_.Elapsed());
    exec_samples_ = 0;
    exec_samples_timer_.Restart();
    result_handler_timer_.Reset();
  }

#endif

  return true;
}

bool MessageCenter::GetMessages(std::vector<Message *> &aMessages,
                                const std::string aQueueName)
{
  return GetMessages(aMessages, aQueueName, -1); /* blocking */
}

bool MessageCenter::GetMessages(std::vector<Message *> &aMessages,
                                const std::string aQueueName,
                                const int aMaxWaitTime)
{
  aMessages.clear();

  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return NULL;
  }

  LOG_TRACE(LOGGER, "Reading msg on " << aQueueName);

  if (queue->shared->Pop(aMessages, aMaxWaitTime))
  {
    return true;
  }
  else
  {
    LOG_DEBUG(LOGGER, "Failed to get messages from " << aQueueName);

    return false;
  }
}

Message* MessageCenter::GetMessage(const std::string aQueueName)
{
  return GetMessage(aQueueName, -1); /* blocking */
}

Message* MessageCenter::GetMessage(const std::string aQueueName,
                                   const int aMaxWaitTime)
{
  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return NULL;
  }

  LOG_TRACE(LOGGER, "Reading msg on " << aQueueName);
  Message *msg = NULL;

  if (queue->shared->Pop(msg, aMaxWaitTime))
  {
    LOG_TRACE(LOGGER, "Got msg: " << *msg);

    return msg;
  }
  else
  {
    LOG_WARN(LOGGER, "Failed to get message from " << aQueueName);

    return NULL;
  }
}

bool MessageCenter::FlushMessages(const std::string aQueueName,
                                  const int aMaxWaitTime)
{
  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return false;
  }

  return queue->shared->Flush(aMaxWaitTime);
}

void MessageCenter::RegisterHandler(const std::string aQueueName,
                                    MessageHandler aHandler)
{
  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return;
  }

  queue->default_handler = aHandler;
}

void MessageCenter::RegisterHandler(const std::string aQueueName,
                                    const MessageGroup aGroup,
                                    MessageHandler aHandler)
{
  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return;
  }

  queue->group_handlers[aGroup] = aHandler;
}

void MessageCenter::RegisterHandler(const std::string aQueueName,
                                    const MessageType aType,
                                    MessageHandler aHandler)
{
  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    return;
  }

  queue->message_handlers[aType] = aHandler;
}

void MessageCenter::StartMainLoop(const std::string aQueueName)
{
  LOG_INFO(LOGGER, "Starting main loop on " << aQueueName);

  QueueSetPtr queue = GetQueue(aQueueName);

  if (!queue)
  {
    LOG_FATAL(LOGGER, "Failed to start main loop on " << aQueueName << " done");
    return;
  }

  bool keep_going = true;
  Message *msg = NULL;
  std::vector<Message *> msgs;

#ifdef SAMPLE_IPC
  unsigned int num_msg = 0;
  unsigned int num_cmd = 0;
  volt::util::Stopwatch sample_timer;
  sample_timer.Start();

  volt::util::Stopwatch msg_handler_timer;
  volt::util::Stopwatch cmd_handler_timer;
#endif

  while (keep_going)
  {
    if (GetMessages(msgs, aQueueName))
    {
      for (auto miter = msgs.begin(); miter != msgs.end(); ++miter)
      {
        msg = *miter;

        LOG_TRACE(LOGGER, "Received a message on " << aQueueName);

        if (msg->Type() == MessageType::BreakMainLoop())
        {
          LOG_DEBUG(LOGGER, "Received BreakMainLoop on " << aQueueName);
          DestroyMessage(msg);
          keep_going = false;
          break;
        }
        else
        {
          MessageHandler handler = queue->default_handler;

          auto iter = queue->message_handlers.find(msg->Type());

          if (iter != queue->message_handlers.end())
          {
            handler = iter->second;
          }
          else
          {
            auto group_iter = queue->group_handlers.find(msg->Type().Group());

            if (group_iter != queue->group_handlers.end())
            {
              handler = group_iter->second;
            }
          }

#ifdef SAMPLE_IPC

          if (msg->IsCommand())
          {
            cmd_handler_timer.Start();
          }
          else
          {
            msg_handler_timer.Start();
          }

#endif

          CallMessageHandler(handler, msg);

#ifdef SAMPLE_IPC

          if (msg->IsCommand())
          {
            cmd_handler_timer.Stop();
          }
          else
          {
            msg_handler_timer.Stop();
          }

#endif
        }

#ifdef SAMPLE_IPC

        if (msg->IsCommand())
        {
          ++num_cmd;
        }
        else
        {
          ++num_msg;
        }

        if (sample_timer.Elapsed() >= 5)
        {
          LOG_WARN(LOGGER, "[RECV] msg:(" << num_msg << std::fixed <<
                   ", " << std::setprecision(3) << msg_handler_timer.Elapsed() <<
                   ") cmd:(" << num_cmd <<
                   ", " << std::setprecision(3) << cmd_handler_timer.Elapsed() <<
                   ") elapsed:" << std::setprecision(3) << sample_timer.Elapsed());
          num_msg = 0;
          num_cmd = 0;
          msg_handler_timer.Reset();
          cmd_handler_timer.Reset();

          sample_timer.Restart();
        }

#endif
      }
    }
  }

  LOG_DEBUG(LOGGER, "Main loop on " << aQueueName << " done");
}

void MessageCenter::StopMainLoop(const std::string aQueueName)
{
  /* Stop the event checking thread. */
  LOG_DEBUG(LOGGER, "Stopping the main loop on " << aQueueName);
  PostMessage(aQueueName, MessageType::BreakMainLoop());
}

void MessageCenter::StopMainLoops()
{
  for (auto iter = queues_.begin(); iter != queues_.end(); ++iter)
  {
    StopMainLoop(iter->first);
  }
}

void MessageCenter::StartMainLoopThread(const std::string aQueueName)
{
  auto iter = main_loop_threads_.find(aQueueName);

  if (iter != main_loop_threads_.end())
  {
    if (iter->second.joinable())
    {
      LOG_WARN(LOGGER, "Main loop thread for " << aQueueName << " already running");
      return;
    }
  }

  main_loop_threads_[aQueueName] =
    std::thread(std::bind(&MessageCenter::StartMainLoop, this, aQueueName));
}

void MessageCenter::JoinMainLoopThread(const std::string aQueueName)
{
  auto iter = main_loop_threads_.find(aQueueName);

  if (iter != main_loop_threads_.end() &&
      iter->second.joinable()
     )
  {
    LOG_DEBUG(LOGGER, "Joining the main loop thread on " << aQueueName);
    iter->second.join();
  }
}

void MessageCenter::JoinMainLoopThreads()
{
  for (auto iter = main_loop_threads_.begin();
       iter != main_loop_threads_.end();
       ++iter)
  {
    JoinMainLoopThread(iter->first);
  }
}

Message* MessageCenter::CreateMessage(const int aMaxWaitTime)
{
  //std::lock_guard<std::mutex> lock(segment_mutex_);
  while (true)
  {
    try
    {
      size_t before = segment_.get_free_memory();

      Message *ret =
        segment_.construct<Message>(boost::interprocess::anonymous_instance)();

      size_t after = segment_.get_free_memory();
      LOG_TRACE(LOGGER, "Created Message of " << sizeof(Message) <<
                " bytes (actually used " << (before - after) << "); " <<
                segment_.get_free_memory() << "/" <<
                segment_.get_size() << " free");
      return ret;
    }
    catch (boost::interprocess::bad_alloc &e)
    {
      LOG_WARN(LOGGER, "Failed to create Message of " << sizeof(Message) <<
               " bytes; " << segment_.get_free_memory() << "/" <<
               segment_.get_size() << " free");

      if (WaitForFreeMemory(sizeof(Message), aMaxWaitTime) == false)
      {
        return NULL;
      }
    }
  }
}

Command* MessageCenter::CreateCommand(const int aMaxWaitTime)
{
  //std::lock_guard<std::mutex> lock(segment_mutex_);
  while (true)
  {
    try
    {
      size_t before = segment_.get_free_memory();

      Command *ret =
        segment_.construct<Command>(boost::interprocess::anonymous_instance)();

      size_t after = segment_.get_free_memory();
      LOG_TRACE(LOGGER, "Created Command of " << sizeof(Command) <<
                " bytes (actually used " << (before - after) << "); " <<
                segment_.get_free_memory() << "/" <<
                segment_.get_size() << " free");
      return ret;
    }
    catch (boost::interprocess::bad_alloc &e)
    {
      LOG_WARN(LOGGER, "Failed to create Command of " << sizeof(Command) <<
               " bytes; " << segment_.get_free_memory() << "/" <<
               segment_.get_size() << " free");

      if (WaitForFreeMemory(sizeof(Command), aMaxWaitTime) == false)
      {
        return NULL;
      }
    }
  }
}

void MessageCenter::DestroyMessage(Message *aMsg)
{
  if (aMsg->GetData())
  {
    LOG_TRACE(LOGGER, "Deallocating data for msg: " << *aMsg);
    //std::lock_guard<std::mutex> lock(segment_mutex_);
    segment_.deallocate(aMsg->GetData());
  }

  if (aMsg->IsCommand())
  {
    LOG_TRACE(LOGGER, "Destroying command: " << *aMsg);
    DestroyObject<Command>(static_cast<Command *>(aMsg));
  }
  else
  {
    LOG_TRACE(LOGGER, "Destroying message: " << *aMsg);
    DestroyObject<Message>(aMsg);
  }

  dealloc_signal_->cond_deallocd.notify_one();
}

MessageCenter::SharedQueuePtr MessageCenter::CreateQueue(const std::string aQueueName,
    const size_t aSize)
{
  //std::lock_guard<std::mutex> lock(segment_mutex_);
  try
  {
    /* The second arg is the deleter to be used.
     * It should probably be using destroy or destroy_ptr but it'd crash if the
     * queue is used by another process.
     * Not destroying the pointer as its lifetime is the same as that of the
     * shared memory. */

    return SharedQueuePtr(new SharedQueue(aQueueName, *this, aSize),
                          SharedQueueDeleter);
  }
  catch (boost::interprocess::bad_alloc &e)
  {
    LOG_WARN(LOGGER, "Failed to create SharedQueue (" << aQueueName << ") of "
             << sizeof(SharedQueue) << " bytes; " <<
             segment_.get_free_memory() << "/" << segment_.get_size() <<
             " free");
    return SharedQueuePtr();
  }
}

MessageCenter::QueueSetPtr MessageCenter::GetQueue(const std::string &aQueueName)
{
  QueueSetPtr queue;
  auto tmp = queues_.find(aQueueName);

  if (tmp == queues_.end())
  {
    LOG_WARN(LOGGER, "Queue not found locally; check on shm: " << aQueueName);

    /* Check if it's created by another processs. */
    SharedQueue *existing = SharedQueue::FindQueue(aQueueName, *this);

    if (existing)
    {
      LOG_DEBUG(LOGGER, "Found queue on shm: " << aQueueName);
      /* Found on the shared mem. */
      queue.reset(new QueueSet(SharedQueuePtr(existing,
                                              SharedQueueDeleter)));
      queue->name = aQueueName;
      queues_.insert(std::make_pair(aQueueName, queue));

      return queue;
    }

    LOG_WARN(LOGGER, "Queue not found: " << aQueueName);
    return queue;
  }

  queue = tmp->second;
  LOG_TRACE(LOGGER, "Using queue: " << aQueueName);

  return queue;
}

bool MessageCenter::PostMessageWithTimeout(QueueSetPtr aQueueSet,
    Message *aMsg,
    const int aMaxWaitTime)
{
  if (aQueueSet->shared->Push(aMsg, aMaxWaitTime) == false)
  {
    LOG_WARN(LOGGER, "Failed to push msg (" << *aMsg << ") to " <<
             aQueueSet->name << " in " << aMaxWaitTime << " msec");
    DestroyMessage(aMsg);
    return false;
  }
  else
  {
    return true;
  }
}

void MessageCenter::CallMessageHandler(MessageHandler aHandler, Message *aMsg)
{
  /* Gotta check the flag before calling the handler to avoid potential race
   * condition where the handler destroys the aMsg object and leads to an
   * unpredictable return value of msg->IsCommand. */
  bool is_command = aMsg->IsCommand();

  if (aHandler)
  {
    aHandler(aMsg);
  }

  if (is_command == false)
  {
    DestroyMessage(aMsg);
  }
}

bool MessageCenter::WaitForFreeMemory(const size_t aSize, const int aMaxWaitTime)
{
  LOG_WARN(LOGGER, "Wait for " << aSize << " bytes to free up: "  <<
           segment_.get_free_memory() << "/" <<
           segment_.get_size() << " free");

  if (aMaxWaitTime >= 0)
  {
    boost::posix_time::ptime current = boost::posix_time::microsec_clock::universal_time();
    boost::posix_time::ptime deadline = current + boost::posix_time::milliseconds(aMaxWaitTime);
    LOG_DEBUG(LOGGER, "Current: " << boost::posix_time::to_simple_string(current));
    LOG_DEBUG(LOGGER, "Deadline: " << boost::posix_time::to_simple_string(deadline));
    scoped_lock<interprocess_mutex> lock(dealloc_signal_->mutex, deadline);

    bool ready =
      dealloc_signal_->cond_deallocd.timed_wait(lock, deadline,
          [&] { return segment_.get_free_memory() >= aSize; });

    if (ready == false)
    {
      LOG_DEBUG(LOGGER, "Failed to get condition in " << aMaxWaitTime << " msec");
      return false;
    }
  }
  else
  {
    scoped_lock<interprocess_mutex> lock(dealloc_signal_->mutex);
    dealloc_signal_->cond_deallocd.wait(lock,
                                        [&] { return segment_.get_free_memory() >= aSize; });
  }

  LOG_WARN(LOGGER, "Waited for " << aSize << " bytes to free up: "  <<
           segment_.get_free_memory() << "/" <<
           segment_.get_size() << " free");

  return true;
}

const MessageCenter::MessageHandleAlloc& MessageCenter::GetMessageHandleAlloc() const
{
  return *msg_handle_alloc_;
}

MessageCenter::ManagedSharedMemory& MessageCenter::GetManagedSharedMemory()
{
  return segment_;
}

MessageCenter::SharedQueue::SharedQueue(const std::string aName,
                                        MessageCenter &aMC, const size_t aSize):
  name_(aName), mc_(aMC), shared_(NULL)
{
  size_t before = mc_.GetManagedSharedMemory().get_free_memory();
  shared_ =
    mc_.GetManagedSharedMemory().find_or_construct<SharedQueuePrivate>(aName.c_str())(mc_, aSize);
  size_t after = mc_.GetManagedSharedMemory().get_free_memory();
  LOG_WARN(LOGGER, "Created SharedQueuePrivate (" << aName << ") of " <<
           sizeof(SharedQueuePrivate) << " bytes (actually used " <<
           (before - after) << "); " << mc_.GetManagedSharedMemory().get_free_memory() << "/" <<
           mc_.GetManagedSharedMemory().get_size() << " free");
}

MessageCenter::SharedQueue::SharedQueue(const std::string aName,
                                        MessageCenter &aMC, SharedQueuePrivate *aPrivateQueue):
  name_(aName), mc_(aMC), shared_(aPrivateQueue)
{
}

MessageCenter::SharedQueue::~SharedQueue()
{
}

bool MessageCenter::SharedQueue::Push(Message *aMsg,
                                      const int aMaxWaitTime)
{
  if (shared_ == NULL)
  {
    LOG_FATAL(LOGGER, "Shared queue is not initialized: " << name_);
    return false;
  }

  LOG_TRACE(LOGGER, "Pushing a msg: " << *aMsg);

  bool pushed = false;
  bool was_empty = false;

  MessageHandle handle = mc_.GetSharedHandle(aMsg);

  if (aMaxWaitTime > 0)
  {
    /* Timed lock */
    try
    {
      boost::posix_time::ptime current = boost::posix_time::microsec_clock::universal_time();
      boost::posix_time::ptime deadline = current + boost::posix_time::milliseconds(aMaxWaitTime);
      scoped_lock<interprocess_mutex> lock(shared_->mutex_, deadline);

      if (Empty())
      {
        was_empty = true;
      }

      pushed = DoPush(handle);
    }
    catch (lock_exception &e)
    {
      /* Failed to acquire lock */
      LOG_WARN(LOGGER, "Failed to acquire lock in " << aMaxWaitTime << " msec");
    }
  }
  else if (aMaxWaitTime == 0)
  {
    /* Try lock */
    try
    {
      scoped_lock<interprocess_mutex> lock(shared_->mutex_, try_to_lock_type());

      if (Empty())
      {
        was_empty = true;
      }

      pushed = DoPush(handle);
    }
    catch (lock_exception &e)
    {
      /* Failed to acquire lock */
      LOG_WARN(LOGGER, "Failed to acquire lock");
    }
  }
  else
  {
    while (true)
    {
      {
        scoped_lock<interprocess_mutex> lock(shared_->mutex_);

        if (Empty())
        {
          was_empty = true;
        }

        /* max_num_msg_ == 0 if the queue has been cleared. */
        if ((pushed = DoPush(handle)) || shared_->max_num_msg_ == 0)
        {
          break;
        }
      }

      {
        LOG_WARN(LOGGER, "Wait for a msg to be consumed: " <<
                 Size() << "/" << MaxSize() << " filled");

        scoped_lock<interprocess_mutex> lock(shared_->mutex_);
        shared_->cond_consumed_.wait(lock, [this] { return Full() == false; });

        LOG_WARN(LOGGER, "Waited for a msg to be consumed: " <<
                 Size() << "/" << MaxSize() << " filled");
      }
    }
  }

  if (pushed && was_empty)
  {
    shared_->cond_produced_.notify_one();
  }

  return pushed;
}

bool MessageCenter::SharedQueue::Pop(Message *&aMsg,
                                     const int aMaxWaitTime)
{
  if (shared_ == NULL)
  {
    LOG_FATAL(LOGGER, "Shared queue is not initialized: " << name_);
    return false;
  }

  bool popped = false;
  bool was_full = false;
  MessageHandle handle;

  if (aMaxWaitTime >= 0)
  {
    /* Timed lock/wait */
    try
    {
      boost::posix_time::ptime current = boost::posix_time::microsec_clock::universal_time();
      boost::posix_time::ptime deadline = current + boost::posix_time::milliseconds(aMaxWaitTime);
      LOG_DEBUG(LOGGER, "Current: " << boost::posix_time::to_simple_string(current));
      LOG_DEBUG(LOGGER, "Deadline: " << boost::posix_time::to_simple_string(deadline));
      scoped_lock<interprocess_mutex> lock(shared_->mutex_, deadline);

      bool ready =
        shared_->cond_produced_.timed_wait(lock, deadline,
                                           [this] { return Empty() == false; });

      if (ready)
      {
        if (Full())
        {
          was_full = true;
        }

        popped = DoPop(handle);
      }
      else
      {
        LOG_DEBUG(LOGGER, "Failed to get condition in " << aMaxWaitTime << " msec");
      }
    }
    catch (lock_exception &e)
    {
      /* Failed to acquire lock */
      LOG_WARN(LOGGER, "Failed to acquire lock in " << aMaxWaitTime << " msec");
    }
  }
  else
  {
    scoped_lock<interprocess_mutex> lock(shared_->mutex_);

    shared_->cond_produced_.wait(lock, [this] { return Empty() == false; });

    if (Full())
    {
      was_full = true;
    }

    popped = DoPop(handle);
  }

  if (popped)
  {
    aMsg = static_cast<Message *>(mc_.GetLocalAddr(handle));
    LOG_TRACE(LOGGER, "Popped a msg: " << *aMsg);

    if (was_full)
    {
      shared_->cond_consumed_.notify_one();
    }
  }

  return popped;
}

bool MessageCenter::SharedQueue::Pop(std::vector<Message *> &aHandles,
                                     const int aMaxWaitTime)
{
  if (shared_ == NULL)
  {
    LOG_FATAL(LOGGER, "Shared queue is not initialized: " << name_);
    return false;
  }

  bool popped = false;
  bool was_full = false;

  if (aMaxWaitTime >= 0)
  {
    /* Timed lock/wait */
    try
    {
      boost::posix_time::ptime current = boost::posix_time::microsec_clock::universal_time();
      boost::posix_time::ptime deadline = current + boost::posix_time::milliseconds(aMaxWaitTime);
      LOG_DEBUG(LOGGER, "Current: " << boost::posix_time::to_simple_string(current));
      LOG_DEBUG(LOGGER, "Deadline: " << boost::posix_time::to_simple_string(deadline));
      scoped_lock<interprocess_mutex> lock(shared_->mutex_, deadline);

      bool ready =
        shared_->cond_produced_.timed_wait(lock, deadline,
                                           [this] { return Empty() == false; });

      if (ready)
      {
        if (Full())
        {
          was_full = true;
        }

        popped = DoPop(aHandles);
      }
      else
      {
        LOG_DEBUG(LOGGER, "Failed to get condition in " << aMaxWaitTime << " msec");
      }
    }
    catch (lock_exception &e)
    {
      /* Failed to acquire lock */
      LOG_WARN(LOGGER, "Failed to acquire lock in " << aMaxWaitTime << " msec");
    }
  }
  else
  {
    {
      scoped_lock<interprocess_mutex> lock(shared_->mutex_);

      shared_->cond_produced_.wait(lock, [this] { return Empty() == false; });

      if (Full())
      {
        was_full = true;
      }

      popped = DoPop(aHandles);
    }
  }

  if (popped && was_full)
  {
    shared_->cond_consumed_.notify_one();
  }

  return popped;
}

size_t MessageCenter::SharedQueue::Size() const
{
  /* shared_->mutex_ MUST be locked before calling this function! */
  return shared_ ? shared_->num_msg_ : 0;
}

size_t MessageCenter::SharedQueue::MaxSize() const
{
  /* shared_->mutex_ MUST be locked before calling this function! */
  return shared_ ? shared_->max_num_msg_ : 0;
}

bool MessageCenter::SharedQueue::Empty() const
{
  /* shared_->mutex_ MUST be locked before calling this function! */
  return shared_ ? shared_->num_msg_ == 0 : true;
}

bool MessageCenter::SharedQueue::Full() const
{
  /* shared_->mutex_ MUST be locked before calling this function! */
  return shared_ ? shared_->num_msg_ == shared_->max_num_msg_ : true;
}

bool MessageCenter::SharedQueue::Flush(const int aMaxWaitTime)
{
  if (shared_ == NULL)
  {
    return true;
  }

  if (aMaxWaitTime >= 0)
  {
    /* Timed lock/wait */
    boost::posix_time::ptime current = boost::posix_time::microsec_clock::universal_time();
    boost::posix_time::ptime deadline = current + boost::posix_time::milliseconds(aMaxWaitTime);
    LOG_DEBUG(LOGGER, "Current: " << boost::posix_time::to_simple_string(current));
    LOG_DEBUG(LOGGER, "Deadline: " << boost::posix_time::to_simple_string(deadline));
    scoped_lock<interprocess_mutex> lock(shared_->mutex_, deadline);

    bool ready =
      shared_->cond_consumed_.timed_wait(lock, deadline,
                                         [this] { return Empty(); });

    if (ready)
    {
      return true;
    }
    else
    {
      LOG_DEBUG(LOGGER, "Failed to get condition in " << aMaxWaitTime << " msec");
      return false;
    }
  }
  else
  {
    scoped_lock<interprocess_mutex> lock(shared_->mutex_);
    shared_->cond_consumed_.wait(lock, [this] { return Empty(); });
    return true;
  }
}

void MessageCenter::SharedQueue::Clear()
{
  if (shared_ == NULL)
  {
    return;
  }

  LOG_WARN(LOGGER, "Clearing SharedQueuePrivate " << name_ << ": " <<
           mc_.GetManagedSharedMemory().get_free_memory() << "/" <<
           mc_.GetManagedSharedMemory().get_size() << " free");

  {
    scoped_lock<interprocess_mutex> lock(shared_->mutex_);

    shared_->queue_.clear();
    shared_->queue_.shrink_to_fit();

    shared_->head_ = shared_->num_msg_ = shared_->max_num_msg_ = 0;
  }

  LOG_WARN(LOGGER, "Cleared SharedQueuePrivate " << name_ << ": " <<
           mc_.GetManagedSharedMemory().get_free_memory() << "/" <<
           mc_.GetManagedSharedMemory().get_size() << " free");
}

void MessageCenter::SharedQueue::Destroy()
{
#if 0

  if (shared_ == NULL)
  {
    return;
  }

  LOG_WARN(LOGGER, "Destroying SharedQueuePrivate " << name_ << ": " <<
           mc_.GetManagedSharedMemory().get_free_memory() << "/" <<
           mc_.GetManagedSharedMemory().get_size() << " free");

  mc_.DestroyNamedObject<SharedQueuePrivate>(name_);
  shared_ = NULL;

  LOG_WARN(LOGGER, "Destroyed SharedQueuePrivate " << name_ << ": " <<
           mc_.GetManagedSharedMemory().get_free_memory() << "/" <<
           mc_.GetManagedSharedMemory().get_size() << " free");
#else
  /* Not actually destroying the queue due to possible race conditions with
   * other processes using the queue.
   * TODO: May be ok if mc_.GetManagedSharedMemory().find<SharedQueuePrivate> is
   * called before every use (and not have shared_ as a member variable)...
   * Let's explore this option and see if the performance penalty of
   * additional lookup is negligible...
   */
  Clear();
#endif
}

MessageCenter::SharedQueue* MessageCenter::SharedQueue::FindQueue(const std::string &aName,
    MessageCenter &aMC)
{
  SharedQueue *existing = NULL;

  std::pair<SharedQueuePrivate *, std::size_t> on_shm =
    aMC.GetManagedSharedMemory().find<SharedQueuePrivate>(aName.c_str());

  if (on_shm.first && on_shm.second > 0)
  {
    existing = new SharedQueue(aName, aMC, on_shm.first);
  }

  return existing;
}

bool MessageCenter::SharedQueue::DoPush(MessageHandle aHandle)
{
  /* shared_->mutex_ MUST be locked before calling this function! */

  if (Full())
  {
    return false;
  }

  size_t index = (shared_->head_ + shared_->num_msg_) % shared_->max_num_msg_;
  shared_->queue_[index] = aHandle;

  ++shared_->num_msg_;

  return true;
}

bool MessageCenter::SharedQueue::DoPop(MessageHandle &aHandle)
{
  /* shared_->mutex_ MUST be locked before calling this function! */

  if (Empty())
  {
    return false;
  }

  aHandle = shared_->queue_[shared_->head_];

  shared_->head_ = (shared_->head_ + 1) % shared_->max_num_msg_;

  --shared_->num_msg_;

  return true;
}

bool MessageCenter::SharedQueue::DoPop(std::vector<Message *> &aMsgs)
{
  /* shared_->mutex_ MUST be locked before calling this function! */

  Message *msg = NULL;

  while (Empty() == false)
  {
    msg = static_cast<Message *>(mc_.GetLocalAddr(shared_->queue_[shared_->head_]));
    aMsgs.push_back(msg);

    LOG_TRACE(LOGGER, "Popped a msg: " << *msg);

    shared_->head_ = (shared_->head_ + 1) % shared_->max_num_msg_;

    --shared_->num_msg_;
  }

  return true;
}

}; /* namespace ipc */
}; /* namespace util */
}; /* namespace volt */
