#include "logger.h"
#include "TaskDispatcher.h"

using namespace volt::util;

Logger LOGGER("test");

void Test()
{
  LOG_DEBUG(LOGGER, "Running a simple task");
}

void TestSleep()
{
  LOG_DEBUG(LOGGER, "Sleep for 5 sec");
  usleep(5000000);
  LOG_DEBUG(LOGGER, "Slept for 5 sec");
}

void TestArg(const char *aMsg)
{
  LOG_DEBUG(LOGGER, "Running a simple task with arg: " << aMsg);
}

void TestAsync()
{
  LOG_DEBUG(LOGGER, "Running a simple async task");
}

void TestAsyncArg(const char *aMsg)
{
  LOG_DEBUG(LOGGER, "Running a simple async task with arg: " << aMsg);
}

void TestChain(int &aCount)
{
  LOG_DEBUG(LOGGER, "Count is " << aCount);

  if (--aCount >= 0)
  {
    TaskDispatcher::Instance().AddDelayedTask(1000, std::bind(TestChain, aCount));
  }

  /* Else no more chaining */
}

void TestToBeCancelled()
{
  LOG_FATAL(LOGGER, "SHOULD NOT BE HERE!!!");
}

void TestCancel(TaskDispatcher::DelayedTaskHandler::SharedPtr aHandler)
{
  LOG_DEBUG(LOGGER, "Cancelling task " << aHandler->id());
  aHandler->Cancel();
}

int main(int argc, char **argv)
{
  Logger::Configure("../log4cplus.conf");

  TaskDispatcher::Instance().Initialize();

  for (unsigned int num = 0; num < 10; ++num)
  {
    TaskDispatcher::Instance().AddTask(Test);
    TaskDispatcher::Instance().AddDelayedTask(5000, TestAsync);
    TaskDispatcher::Instance().AddDelayedTask(10000, std::bind(TestAsyncArg, "hello"));
  }

  int count = 15;
  TaskDispatcher::Instance().AddDelayedTask(1000, std::bind(TestChain, count));

  TaskDispatcher::DelayedTaskHandler::SharedPtr handler = TaskDispatcher::Instance().CreateDelayedTask(20000, TestToBeCancelled);
  TaskDispatcher::Instance().AddDelayedTask(12000, std::bind(TestCancel, handler));

  TaskDispatcher::Instance().Finish();
  return 0;
}
