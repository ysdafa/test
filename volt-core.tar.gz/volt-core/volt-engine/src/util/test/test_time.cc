#include "time_util.h"
#include "logger.h"

static snap::util::Logger LOGGER("snap.test");

bool test_valid(const std::string &aHttpDate)
{
  snap::util::Time time;

  if (time.ParseHttpTime(aHttpDate) == false)
  {
    LOG_ERROR(LOGGER, aHttpDate << ": FAIL");
    return false;
  }

  LOG_INFO(LOGGER, aHttpDate << ": PASS");
  return true;
}

bool test_invalid(const std::string &aHttpDate)
{
  snap::util::Time time;

  if (time.ParseHttpTime(aHttpDate))
  {
    LOG_ERROR(LOGGER, aHttpDate << ": FAIL");
    return false;
  }

  LOG_INFO(LOGGER, aHttpDate << ": PASS");
  return true;
}

bool test_rfc1123()
{

  LOG_INFO(LOGGER, "Testing RFC 1123 date format");

  bool result = false;
  result |= test_valid("Sun, 06 Nov 1994 08:49:37 GMT");
  result |= test_valid("Sun, 6 Nov 1994 08:49:37 GMT");

  /* Timezone MUST be GMT */
  result |= test_invalid("Sun, 06 Nov 1994 08:49:37 UTC");

  return result;
}

bool test_rfc1036()
{
  LOG_INFO(LOGGER, "Testing RFC 1036 date format");

  bool result = false;
  result |= test_valid("Sunday, 06-Nov-94 08:49:37 GMT");
  result |= test_valid("Sunday, 6-Nov-94 08:49:37 GMT");

  /* Timezone MUST be GMT */
  result |= test_invalid("Sunday, 06-Nov-94 08:49:37 UTC");

  return result;
}

bool test_ansi()
{
  LOG_INFO(LOGGER, "Testing asctime date format");

  bool result = false;
  result |= test_valid("Sun Nov 06 08:49:37 1994");
  result |= test_valid("Sun Nov 6 08:49:37 1994");

  return result;
}

bool test()
{
  bool result = false;
  result |= test_rfc1123();
  result |= test_rfc1036();
  result |= test_ansi();
  return result;
}

int main(int argc, char **argv)
{
  snap::util::Logger::Configure("log4cplus.config");
  return test() ? 0 : 1;
}
