#include "DrmManager.h"

void PrintData(const unsigned char *aData, const int aSize,
               const std::string aMode = "hex")
{
  enum Mode { HEX, ASCII };
  Mode mode = aMode == "ascii" ? ASCII : HEX;

  for (int index = 0; index < aSize; ++index)
  {
    if (index > 0)
    {
      if (index % 16 == 0)
      {
        printf( "\n");
      }
      else if (index % 2 == 0)
      {
        printf(" ");
      }
    }

    if (index % 16 == 0)
    {
      printf("0x%08x ", index);
    }

    printf(mode == HEX ? "%02x" : "%c", aData[index]);
  }

  if (aSize > 0)
  {
    printf("\n");
  }
}

int main(int argc, char **argv)
{
  if (argc < 2)
  {
    printf("Usage: %s <license file> <encrypted file>\n", argv[0]);
    return 0;
  }

  if (DrmManager::Instance().LoadLicense(argv[1]) == false)
  {
    printf("Failed to load license: %s\n", argv[1]);
    return 1;
  }

  unsigned char *data = NULL;
  int size = 0;

  if (DrmManager::Instance().DecryptFile(argv[2], data, size) == false)
  {
    printf("Failed to read file: %s\n", argv[2]);
    return 1;
  }

  printf("Decrypted %d bytes of data: %s\n", size, argv[2]);
  PrintData(data, size, argc > 3 ? argv[3] : "hex");

  return 0;
}
