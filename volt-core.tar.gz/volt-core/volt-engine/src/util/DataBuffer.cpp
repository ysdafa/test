#include "DataBuffer.h"

#include <stdio.h>
#include <string.h>

using namespace volt::util;

std::string DataBuffer::LOGGER_NAME = "volt.util.DataBuffer";

static size_t count_utf8_chars(char *data, size_t limit)
{
  size_t index = 0;
  size_t utf8Count = 0;

  while (data[index] and index < limit)
  {
    if ((data[index] & 0xC0) != 0x80)
    {
      utf8Count++;
    }

    index++;
  }

  return utf8Count;
}

static size_t has_utf8_chars(char *data, size_t limit)
{
  size_t index = 0;
  size_t utf8Count = 0;

  while (data[index] and index < limit)
  {
    if ((data[index] & 0xC0) != 0x80)
    {
      utf8Count++;
    }
    else
    {
      return true;
    }

    index++;
  }

  return false;
}

DataBuffer::DataBuffer()
  : mBuffer(nullptr),
    mLength(0),
    mCapacity(0),
    mFormat(Unknown),
    mUtf8Length(0),
    logger_(LOGGER_NAME)
{

}

DataBuffer::DataBuffer(size_t length)
  : mBuffer(nullptr),
    mLength(0),
    mCapacity(0),
    mFormat(Unknown),
    mUtf8Length(0),
    logger_(LOGGER_NAME)
{
  if(length)
  {
    mBuffer = (uint8_t*) malloc(length);
    mLength = 0;
    mCapacity = length;

    // we are lazy, lets just do this for now
    // since this is fast..
    mBuffer[0] = 0;
    mBuffer[mCapacity -1] = 0;
  }
}

DataBuffer::DataBuffer(uint8_t *buffer, size_t length, size_t capacity)
  : mBuffer(buffer),
    mLength(length),
    mCapacity(capacity),
    mFormat(Unknown),
    mUtf8Length(0),
    logger_(LOGGER_NAME)
{
}

DataBuffer::DataBuffer(const uint8_t *buffer, size_t length)
  : mBuffer(nullptr),
    mLength(0),
    mCapacity(0),
    mFormat(Unknown),
    mUtf8Length(0),
    logger_(LOGGER_NAME)
{
  if(buffer and length)
  {
    mBuffer = (uint8_t*) malloc(length);
    mLength = length;
    mCapacity = length;

    memmove(mBuffer, buffer, length); // perform copy
  }
}

DataBuffer::DataBuffer(char *text)
  : mBuffer((uint8_t*)text),
    mLength(0),
    mCapacity(0),
    mFormat(Ascii),
    mUtf8Length(0),
    logger_(LOGGER_NAME)
{
  if(text)
  {
    mLength = strlen(text);
    mCapacity = mLength;  // we are just assuming here..
  }
}

DataBuffer::DataBuffer(const char *text)
  : mBuffer(nullptr),
    mLength(0),
    mCapacity(0),
    mFormat(Ascii),
    mUtf8Length(0),
    logger_(LOGGER_NAME)
{
  if(text)
  {
    size_t length = strlen(text);

    if(length)
    {
      mBuffer = (uint8_t*) malloc(length + 1);

      if(mBuffer)
      {
        mLength = length;
        mCapacity = mLength + 1;
        strncpy((char*)mBuffer, text, mCapacity); // perform copy
      }
    }
  }
}

DataBuffer::~DataBuffer()
{
  if(mBuffer)
  {
    free(mBuffer);
    mBuffer = nullptr;
  }
}

const char* DataBuffer::c_str() const
{
  return (const char*) mBuffer;
}

const char* DataBuffer::data() const
{
  return (const char*) mBuffer;
}

size_t DataBuffer::length()
{
  return mLength;
}

size_t DataBuffer::Utf8Length()
{
  if(not mUtf8Length)
  {
    mUtf8Length = count_utf8_chars((char*) mBuffer, mCapacity);
  }

  return mUtf8Length;
}

size_t DataBuffer::size()
{
  return mLength;
}

size_t DataBuffer::capacity()
{
  return mCapacity;
}

DataBuffer::Format DataBuffer::format()
{
  return mFormat;
}

void DataBuffer::SetFormat(DataBuffer::Format format)
{
  mFormat= format;
}

bool DataBuffer::reserve(size_t n)
{
  // always reserve 1 byte more than requested, in case data is cstring and we need to null terminate
  n++;

  // determine if we need to increase capacity
  if(n > mCapacity)
  {
    // determine if we need to realloc just malloc
    uint8_t *newBuffer = nullptr;

    if(mLength)
    {
      newBuffer = (uint8_t*)realloc(mBuffer, n);
    }
    else
    {
      newBuffer = (uint8_t*)malloc(n);

      if(newBuffer and mBuffer)
      {
        free(mBuffer);
        mBuffer = nullptr;
      }
    }

    if(newBuffer != nullptr)
    {
      mBuffer = newBuffer;  // successfully allocated
      mCapacity = n;

      mBuffer[0] = 0;
      mBuffer[mCapacity - 1] = 0;
      return true;
    }
    else
    {
      return false;
    }
  }

  return true;
}

void DataBuffer::clear()
{
  if(mBuffer)
  {
    // we are lazy, just clear 1st byte..
    // this is enough if its cstring..
    mBuffer[0] = 0;
    mBuffer[mCapacity - 1] = 0;

    // this is too slow, lets not do this now
    // memset(mBuffer, 0, mLength);
  }

  mLength = 0;
}

bool DataBuffer::append(const uint8_t* data, size_t length)
{
  // do nothing if no input
  if(not data or not length)
  {
    return true;
  }

  // allocate memory if non exists
  if(mBuffer == nullptr)
  {
    mBuffer = (uint8_t*) malloc(length + 1);

    if(mBuffer)
    {
      mLength = length;
      mCapacity = length + 1;

      mBuffer[mCapacity - 1] = 0;

      memmove(mBuffer, data, length);

      return true;
    }

    return false;
  }

  // not enough capacity
  if(mCapacity - mLength < length)
  {
    size_t newCapacity = mLength + length + 1;
    uint8_t *newBuffer = nullptr;

    if(mLength)
    {
      newBuffer = (uint8_t*) realloc(mBuffer, newCapacity);
    }
    else
    {
      newBuffer = (uint8_t*) malloc(newCapacity);

      if(mBuffer)
      {
        free(mBuffer);
        mBuffer = nullptr;
      }
    }

    if(newBuffer)
    {
      newBuffer[newCapacity - 1] = 0;
      mBuffer = newBuffer;
      mCapacity = newCapacity;
    }
    else
    {
      // failed
      return false;
    }
  }

  // copy the new data over
  memcpy(mBuffer + mLength, data, length);
  mLength += length;

  // add null terminate in case this is a cstring..
  if(mCapacity > mLength)
  {
    mBuffer[mCapacity - 1] = 0;
  }

  return true;
}

bool DataBuffer::append(const char* text)
{
  // empty string
  if(not text)
  {
    return false;
  }

  size_t length = strlen(text);

  if(not length)
  {
    return false;
  }

  // allocate memory if non exists
  if(mBuffer == nullptr)
  {
    mBuffer = (uint8_t*) malloc(length + 1);

    if(mBuffer)
    {
      mLength = length;
      mCapacity = length + 1;

      mBuffer[mCapacity - 1] = 0;
      mBuffer[length] = 0;
      memmove(mBuffer, text, length);

      return true;
    }

    return false;
  }

  // not enough capacity
  if(mCapacity - mLength < length)
  {
    size_t newCapacity = mLength + length + 1;
    uint8_t *newBuffer = nullptr;

    if(mLength)
    {
      newBuffer = (uint8_t*) realloc(mBuffer, newCapacity);
    }
    else
    {
      newBuffer = (uint8_t*) malloc(newCapacity);

      if(mBuffer)
      {
        free(mBuffer);
        mBuffer = nullptr;
      }
    }

    if(newBuffer)
    {
      newBuffer[newCapacity - 1] = 0;
      mBuffer = newBuffer;
      mCapacity = newCapacity;
    }
    else
    {
      // failed
      return false;
    }
  }

  strncat((char*)mBuffer, text, length);
  mLength += length;

  return true;
}

// this function overrides existing values without regard for memory leak
void DataBuffer::SetProperty(uint8_t *buffer, size_t length, size_t capacity)
{
  if(mBuffer)
  {
    LOG_WARN(logger_, "WARNING: overriding existing buffer information");
  }

  mBuffer = buffer;
  mLength = length;
  mCapacity = capacity;
}

bool DataBuffer::CheckIsUtf8()
{
  if (not mBuffer or mLength == 0 or mCapacity == 0)
  {
    return false;
  }

  // no op, we already know we are utf8
  if(mFormat == Utf8)
  {
    return true;
  }

  // update format
  if(has_utf8_chars((char*) mBuffer, mCapacity))
  {
    mFormat = Utf8;
    LOG_WARN(logger_, "found UTF character in buffer size " << mLength);
  }

  return (mFormat == Utf8);
}
