#include "AnyContainer.h"

/******************************************************************************
 * AnyMap
 *****************************************************************************/

AnyMap::AnyMap(): map_()
{
}

AnyMap::AnyMap(const AnyMap &aSrc): map_()
{
  *this = aSrc;
}

AnyMap::~AnyMap()
{
}

AnyMap& AnyMap::operator=(const AnyMap &aRhs)
{
  if (this != &aRhs)
  {
    map_ = aRhs.map_;
  }

  return *this;
}

bool AnyMap::Has(const std::string &aKey) const
{
  return map_.count(aKey) > 0;
}

size_t AnyMap::Size() const
{
  return map_.size();
}

bool AnyMap::Empty() const
{
  return map_.empty();
}

std::vector<std::string>& AnyMap::GetKeys(std::vector<std::string> &aKeys) const
{
  aKeys.clear();

for (auto kv: map_)
  {
    aKeys.push_back(kv.first);
  }

  return aKeys;
}


/******************************************************************************
 * AnyList
 *****************************************************************************/

AnyList::AnyList(): list_()
{
}

AnyList::AnyList(const AnyList &aSrc): list_()
{
  *this = aSrc;
}

AnyList::~AnyList()
{
}

AnyList& AnyList::operator=(const AnyList &aRhs)
{
  if (this != &aRhs)
  {
    list_ = aRhs.list_;
  }

  return *this;
}

size_t AnyList::Size() const
{
  return list_.size();
}

bool AnyList::Empty() const
{
  return list_.empty();
}
