#include "XWindowManager.h"

#include "VoltConfig.h"

#include "logger.h"
#include <string.h>

///TODO: add conditional inclusion here and in CMakeLists.
#if defined(BUILD_FOR_TV)
#include "TvXWindowManager.h"
#else
#include "LinuxXWindowManager.h"
#endif

#include <clutter/x11/clutter-x11.h>

using volt::util::Logger;

namespace
{
Logger logger("volt.util.xwindowmanager");
}

static volt::util::IXWindowManager* manager = nullptr;

namespace volt
{
namespace util
{

bool SetXWindowManager(IXWindowManager *aManager)
{
  if(manager or aManager == nullptr)
  {
    return false;
  }

  manager = aManager;
  return true;
}

IXWindowManager* GetXWindowManager(void)
{
  if(manager)
  {
    return manager;
  }

#if defined(BUILD_FOR_TV)
  manager = new TvXWindowManager();
#else
  manager = new LinuxXWindowManager();
#endif

  return manager;
}

XWindowManager::XWindowManager()
  :m_xdpy(nullptr),
   m_xwin(0),
   m_dummy(0),
   m_stage(nullptr),
   m_width(0),
   m_height(0)
{
}

XWindowManager::~XWindowManager()
{
  DestroyStage();
  DestroyWindow();
  DestroyDisplay();
}

bool XWindowManager::Initialize(int aArgc, char **aArgv)
{
  /* Initialize clutter even for worker process because it's still needed for
   * handling async/timeout tasks. */
  if (clutter_init(&aArgc, &aArgv) != CLUTTER_INIT_SUCCESS)
  {
    LOG_FATAL(logger, "Failed to initialize graphics backend");
    return false;
  }

  return true;
}

bool XWindowManager::CreateStage(const int aWidth, const int aHeight,
                                 const int aSceneWidth,
                                 const int aSceneHeight)
{
  if(GetWindow() == 0)
  {
    if(not CreateWindow(aWidth,aHeight))
    {
      LOG_FATAL(logger, "failed to create window, unable to create stage");
    }
  }

  ShowWindow();

  ClutterActor *stage = clutter_stage_new();

  if (stage == NULL)
  {
    LOG_FATAL(logger, "Failed to create stage");
    return false;
  }

  if (clutter_x11_set_stage_foreign(CLUTTER_STAGE(stage), GetWindow()) == FALSE)
  {
    LOG_WARN(logger, "Failed to set foreign X window.");
    return false;
  }

  ClutterColor color( {0, 0, 0, 0});

  clutter_actor_set_size(stage, aSceneWidth, aSceneHeight);
  clutter_stage_set_use_alpha(CLUTTER_STAGE(stage), true);
  clutter_actor_set_background_color(stage, &color);
  clutter_actor_queue_redraw(stage);
  clutter_actor_set_size(stage, aSceneWidth, aSceneHeight);
  clutter_actor_show(stage);

  m_stage = stage;

  return true;
}

bool XWindowManager::DestroyDisplay()
{
  if(m_xdpy)
  {
    XCloseDisplay(m_xdpy);
    m_xdpy = nullptr;
    LOG_DEBUG(logger,"DestroyDisplay()");
  }

  return true;
}

bool XWindowManager::DestroyWindow()
{
  if(m_xwin)
  {
    XDestroyWindow(m_xdpy, m_xwin);
    m_xwin = 0;
  }

  if(m_dummy)
  {
    XDestroyWindow(m_xdpy, m_dummy);
    m_dummy = 0;
  }

  LOG_DEBUG(logger,"DestroyWindow()");
  return true;
}

bool XWindowManager::DestroyStage(void)
{
  if(m_stage)
  {
    clutter_actor_destroy(m_stage);
    m_stage = nullptr;
  }

  return true;
}

void XWindowManager::SetWindowName(const std::string& name)
{
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)

  if (m_xdpy and m_dummy)
  {
    std::string dummy_name("Dummy - ");
    dummy_name += name;
    XStoreName(m_xdpy, m_dummy, dummy_name.c_str());
  }

#endif

  if (m_xdpy and m_xwin)
  {
    XStoreName(m_xdpy, m_xwin, name.c_str());
  }
}

void XWindowManager::ShowWindow()
{
  XMapWindow(m_xdpy, m_xwin);
  XMoveResizeWindow(m_xdpy, m_xwin, 0, 0, m_width, m_height);
}

void XWindowManager::HideWindow()
{
  XUnmapWindow(m_xdpy, m_xwin);
}

void XWindowManager::SetDisplay(Display* const display)
{
  m_xdpy = display;
}

void XWindowManager::SetWindow(Window const windowId)
{
  m_xwin = windowId;

  //save width/height
  if(m_xdpy and m_xwin)
  {
    XWindowAttributes attr;
    XGetWindowAttributes(m_xdpy,m_xwin,&attr);
    m_width = attr.width;
    m_height = attr.height;
  }
}

XSetWindowAttributes XWindowManager::GetWindowAttributes(XVisualInfo* visInfo) const
{
  XSetWindowAttributes xattr;
  // must initialize this structure because it is used as an input variable below.
  memset(&xattr, 0, sizeof(XSetWindowAttributes));
  xattr.background_pixel = WhitePixel(m_xdpy, DefaultScreen(m_xdpy));
  xattr.border_pixel = 0;
  xattr.colormap = XCreateColormap(m_xdpy, DefaultRootWindow(m_xdpy),
                                   visInfo->visual,
                                   AllocNone);
  xattr.event_mask = StructureNotifyMask;
  return xattr;
}
};
};
