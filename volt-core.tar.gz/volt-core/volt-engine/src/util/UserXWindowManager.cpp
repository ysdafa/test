#include "UserXWindowManager.h"

using namespace volt::util;

UserXWindowManager::UserXWindowManager(Display * const disp, Window const winId)
{
  SetDisplay(disp);
  SetWindow(winId);
  //  manager = this; // JOE: I dont think we should do this..
}

UserXWindowManager::UserXWindowManager(void)
{
  //  manager = this; // JOE: I dont think we should do this..
}

UserXWindowManager::~UserXWindowManager()
{
}

bool UserXWindowManager::CreateDisplay()
{
  if(m_xdpy) //user already created display
  {
    return true;
  }
  else if(createDisplayPtr) //user provided callback to create display
  {
    Display* disp = createDisplayPtr();

    if(disp)
    {
      SetDisplay(disp);
      return true;
    }
    else
    {
      return false;
    }
  }
  else
  {
    return false; //must be implemented by user.
  }
}

bool UserXWindowManager::CreateWindow(const int width, const int height)
{
  if(m_xwin) //user already created window
  {
    return true;
  }
  else if(createWindowPtr) //user provided callback to create window
  {
    Window winId = createWindowPtr(width,height);

    if(winId)
    {
      SetWindow(winId);
      m_width = width;
      m_height = height;
      return true;
    }
    else
    {
      return false;
    }
  }
  else
  {
    return false; //must be implemented by user.
  }
}

bool UserXWindowManager::DestroyDisplay()
{
  if(createDisplayPtr)
  {
    return createDisplayPtr();
  }
  else
  {
    return XWindowManager::DestroyDisplay();
  }
}

bool UserXWindowManager::DestroyWindow()
{
  if(destroyWindowPtr)
  {
    return destroyWindowPtr();
  }
  else
  {
    return XWindowManager::DestroyWindow();
  }
}

void UserXWindowManager::ShowWindow(void)
{
  if(showXWindowPtr)
  {
    showXWindowPtr();
  }
  else
  {
    XWindowManager::ShowWindow();
  }
}

void UserXWindowManager::HideWindow(void)
{
  if(hideXWindowPtr)
  {
    hideXWindowPtr();
  }
  else
  {
    XWindowManager::HideWindow();
  }
}
