#include "TvXWindowManager.h"
#include "VoltConfig.h"
#include <clutter/x11/clutter-x11.h>
#include "logger.h"
#include <string.h>

#if defined(BUILD_FOR_TV) && !defined(TIZEN)
#include "XMultiView.h"
#include "XEGLImageWrapper.h"
#endif

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include <Ecore.h>
#include <Ecore_X.h>

/**
 * A proxy function to forward EFL events to Clutter.
 */
static Eina_Bool OnEcoreXEvents(void *aData, int aEventType, void *aEvent)
{
  static volt::util::Logger logger("volt.util.clutter");
  XEvent *event = static_cast<XEvent *>(aEvent);
  LOG_DEBUG(logger, "Got Ecore X event: " << event->type);
  clutter_x11_handle_event(event);
  return EINA_TRUE; /* Keep this handler registered. */
}

#endif

using volt::util::Logger;

using namespace volt::util;

namespace
{
Logger logger("volt.util.tvxwindowmanager");
}

TvXWindowManager::TvXWindowManager()
{
}

TvXWindowManager::~TvXWindowManager()
{
}

bool TvXWindowManager::CreateDisplay()
{
  int retval = -1;

  do
  {
#if defined(BUILD_FOR_TV) && !defined(TIZEN)

    /* Init and connect to X manually. */
    if (XEGLInit() != 0)
    {
      LOG_ERROR(logger, "XEGLInit failed");
      break;
    }

#endif

    if (XInitThreads() == 0)
    {
      LOG_ERROR(logger, "XInitThreads failed");
      break;
    }

#if defined(BUILD_FOR_TV) && defined(TIZEN)

    if (ecore_x_init(NULL) == 0)
    {
      LOG_ERROR(logger, "Failed to initialize Ecore X with the default dispaly");

      if (ecore_x_init(":0") == 0)
      {
        LOG_ERROR(logger, "Failed to initialize Ecore X with :0");
        break;
      }
    }

    m_xdpy = static_cast<Display *>(ecore_x_display_get());

    if (!m_xdpy)
    {
      LOG_ERROR(logger, "Failed to open display");
      break;
    }

    /* Disable X11 event polling by Clutter; let EFL handle it. */
    clutter_x11_disable_event_retrieval();
    /* Intercept X-events so that we can send it to Clutter */
    ecore_event_handler_add(ECORE_X_EVENT_ANY, OnEcoreXEvents, NULL);

    clutter_x11_set_use_argb_visual(TRUE);
#else
    /* Check if already opened? */
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
#else
    m_xdpy = XOpenDisplay(NULL);
#endif

    if (!m_xdpy)
    {
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
      char *display_name = NULL;
      XGetDisplayString(XMV_VIEW_FIRST, &display_name);
      LOG_WARN(logger, "The display string is " << display_name);

      setenv("DISPLAY", display_name, 1);
      m_xdpy = XOpenDisplay(display_name);
      XFreeDisplayString(display_name);
#else
      LOG_WARN(logger, "Failed to open display; trying :0...");
      setenv("DISPLAY", ":0", 1);
      m_xdpy = XOpenDisplay(NULL);
#endif

      if (!m_xdpy)
      {
        LOG_ERROR(logger, "Failed to open display");
        break;
      }
    }

#endif
    LOG_DEBUG(logger, "Opened X display: " << m_xdpy);

    clutter_x11_set_display(m_xdpy);

    retval = 0;
  }
  while (0);

  return retval == 0;
}

bool TvXWindowManager::CreateWindow(const int width, const int height)
{
  if (m_xdpy == NULL)
  {
    LOG_FATAL(logger, "XDisplay is not initialized yet");
    return NULL;
  }

  m_width = width;
  m_height = height;

#if defined(BUILD_FOR_TV) && defined(TIZEN)
  m_xwin = static_cast<Window>(ecore_x_window_argb_new(0, 0, 0, width, height));
#else
  /* We want to test that Cogl can handle foreign X windows... */
  XVisualInfo *xvisinfo = clutter_x11_get_visual_info();

  /* window attributes */
  XSetWindowAttributes xattr = GetWindowAttributes(xvisinfo);

  unsigned long mask = CWBorderPixel | CWColormap | CWEventMask;

#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
  /* A dummy off-screen window.
   * For some reason on the X12, X14, NT14U, and GOLFS possibly due to Mali driver
   * differences, you must create a dummy window underneath your main window.
   * Otherwise the app will hang waiting for a reply from the X server that
   * never comes. */
  DUMMY_m_xwin = XCreateWindow(m_xdpy,
                               DefaultRootWindow(m_xdpy),
                               -200, -200,
                               1, 1,
                               0,
                               xvisinfo->depth,
                               InputOutput,
                               xvisinfo->visual,
                               mask, &xattr);
#endif

  m_xwin = XCreateWindow(m_xdpy, DefaultRootWindow(m_xdpy), 0, 0, width, height,
                         0,
#if defined(BUILD_FOR_TV) && !defined(TIZEN)
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
                         xvisinfo->depth,
                         InputOutput,
                         xvisinfo->visual,
#else
                         CopyFromParent,
                         InputOutput,
                         CopyFromParent,
#endif
#else
                         xvisinfo->depth,
                         InputOutput, xvisinfo->visual,
#endif
                         mask, &xattr);

  XFree(xvisinfo);

#endif

  return true;
}

bool TvXWindowManager::DestroyWindow()
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  ecore_x_window_free(m_xwin);
#else
  XDestroyWindow(m_xdpy, m_xwin);
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
  XDestroyWindow(m_xdpy, m_dummy);
#endif
#endif
  return true;
}

void TvXWindowManager::ShowWindow()
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  ecore_x_window_show(m_xwin);
  ecore_x_window_move_resize(m_xwin, 0, 0, m_width, m_height);
#else
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
  XMapWindow(m_xdpy, m_dummy);
#endif
  XMapWindow(m_xdpy, m_xwin);
  XMoveResizeWindow(m_xdpy, m_xwin, 0, 0, m_width, m_height);
#endif
}

void TvXWindowManager::HideWindow()
{
#if defined(BUILD_FOR_TV) && defined(TIZEN)
  ecore_x_window_hide(m_xwin);
#else
#if defined(X14) || defined(X12) || defined(GOLFS) || defined(NT14U)
  XUnmapWindow(m_xdpy, m_dummy);
#endif
  XUnmapWindow(m_xdpy, m_xwin);
#endif
}
