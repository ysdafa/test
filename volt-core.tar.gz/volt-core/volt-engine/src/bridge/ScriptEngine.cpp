/*
 * ScriptEngine.cpp
 *
 *  Created on: May 10, 2013
 *      Author: reza
 */

#include "ScriptEngine.h"

#include "v8/v8-profiler.h"

#include "VoltConfig.h"
#include "ResourceLoader.h"
#include "ScriptTypes.h"
#include <string.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <iomanip>

#include "AppConfig.h"
#include "Exception.h"
#include "DataBuffer.h"
#include "FileIORequest.h"

const std::string DEBUGGER_FILENAME_PREFIX = "VOLT/";

static volt::util::Logger LOGGER("volt.script.engine");

/* Loggers for performance measurements. */
static volt::util::Logger s_logger_perf_load("volt_perf.script.load");
static volt::util::Logger s_logger_perf_compile("volt_perf.script.compile");
static volt::util::Logger s_logger_perf_run("volt_perf.script.run");
static volt::util::Logger s_logger_perf_init("volt_perf.script.initialize");
static volt::util::Logger s_logger_perf_precompile("volt_perf.script.precompile");

namespace
{

/**
 * This class is used to dump v8's heap snapshot to file.
 * The snapshot can then be loaded by Chrome's dev tool for analysis.
 */
class FileOutputStream : public v8::OutputStream
{
  public:
    FileOutputStream(const std::string &aPath):
      v8::OutputStream(), out_()
    {
      out_.open(aPath, std::ofstream::binary);
      if (out_.is_open() == false)
      {
        LOG_WARN(volt::util::Logger::DefaultLogger(),
                 "Failed to open: " << aPath);
      }
    }

    ~FileOutputStream()
    {
      EndOfStream();
    }

    bool IsOpen() const
    {
      return out_.is_open();
    }

    virtual void EndOfStream()
    {
      out_.close();
    }

    virtual WriteResult WriteAsciiChunk(char *aData, int aSize)
    {
      if (out_.is_open())
      {
        out_.write(aData, aSize);
      }

      return v8::OutputStream::kContinue;
    }

  private:
    std::ofstream out_;
};

} /*  anonymous namespace */ 

using namespace v8;
using namespace Bridge;
using namespace volt::util;

volt::util::Logger ScriptEngine::LOGGER("volt.bridge.scriptEngine");

ScriptEngine::ScriptEngine(bool exposeGC):
  gc_threshold_(0), gc_threshold_poll_interval_(0)
{
  // This code would make the GC accessible from JavaScript for testing purposes. To invoke use gc().
  if (exposeGC)
  {
    const char *flags = "--expose-gc";
    V8::SetFlagsFromString(flags, strlen(flags));
    V8::AddGCEpilogueCallback(gcCallback);
  }

  {
    /* To enable typed arrays. */
    const char *flags = "--harmony-typed-arrays";
    V8::SetFlagsFromString(flags, strlen(flags));
  }

  if (AppConfig::Instance().GetValue<std::string>("v8.gc.debug") == "true")
  {
    {
      const char *flags = "--trace-gc";
      V8::SetFlagsFromString(flags, strlen(flags));
    }

    {
      const char *flags = "--trace-gc-nvp";
      V8::SetFlagsFromString(flags, strlen(flags));
    }

    {
      const char *flags = "--trace-gc-verbose";
      V8::SetFlagsFromString(flags, strlen(flags));
    }

    {
      const char *flags = "--trace-external-memory";
      V8::SetFlagsFromString(flags, strlen(flags));
    }

    {
      const char *flags = "--print-cumulative-gc-stat";
      V8::SetFlagsFromString(flags, strlen(flags));
    }
  }

  //Initialize v8 stuff
#ifdef BUILD_FOR_TV
  isolate = Isolate::New();
  isolate->Enter();
#else
  isolate = Isolate::GetCurrent();
#endif

  HandleScope handle_scope(isolate);
  globalObjectTemplate.Reset(isolate, createGlobalObjectTemplate());

  // this enables v8 engine to allocate memory for array buffer internall
  v8::V8::SetArrayBufferAllocator(&arrayBufferAllocator);

  gc_threshold_poll_interval_ =
    AppConfig::Instance().GetValue<unsigned int>("v8.gc.threshold-poll-interval");

  if (gc_threshold_poll_interval_ > 0)
  {
    gc_threshold_poll_interval_ *= 1000; /* to ms */

    gc_threshold_ =
      AppConfig::Instance().GetValue<unsigned int>("v8.gc.threshold");

    clutter_threads_add_timeout_full(G_PRIORITY_DEFAULT_IDLE,
                                     gc_threshold_poll_interval_,
                                     [](gpointer aSelf) -> gboolean
    {
      ScriptEngine *self = reinterpret_cast<ScriptEngine *>(aSelf);
      HeapStatistics stat;
      Isolate::GetCurrent()->GetHeapStatistics(&stat);
      LOG_DEBUG(LOGGER, "heap_size_limit: " << stat.heap_size_limit());
      LOG_DEBUG(LOGGER, "total_heap_size: " << stat.total_heap_size());
      LOG_DEBUG(LOGGER, "total_heap_size_executable: " <<
      stat.total_heap_size_executable());
      LOG_DEBUG(LOGGER, "used_heap_size: " << stat.used_heap_size());

      if (self->gc_threshold_ > 0 &&
      stat.used_heap_size() > self->gc_threshold_)
      {
        LOG_FATAL(LOGGER, "V8 heap usage too high (" <<
        stat.used_heap_size() << " > " <<
        self->gc_threshold_ <<
        "); calling LowMemoryNotification");
        V8::LowMemoryNotification();
      }

      return TRUE; /* continue forever */
    }, this, NULL);
  }
}

void ScriptEngine::gcCallback(GCType type, GCCallbackFlags flags)
{
  LOG_DEBUG(LOGGER, "GC Invoked!");
}


ScriptEngine::~ScriptEngine()
{
  HandleScope scope(Isolate::GetCurrent());

  //clean up bridges
  for(auto it = bridges.begin(); it != bridges.end(); it++)
  {
    (*it)->dispose();
  }

  //Clean up modules
  for(auto it = modules.begin(); it != modules.end(); it++)
  {
    delete it->second;
  }

  // clean up v8 stuff
  Handle<Context> theContext = getContext();
  theContext->Exit();
  context.Reset();

#if ENABLE_GLOBAL_KEY_HANDLER
  //Wipe out persistents
  keyEventCallback.Reset();
#endif

  //delete bridge instances
  for(auto it = bridges.begin(); it != bridges.end(); it++)
  {
    delete (*it);
  }

#ifdef BUILD_FOR_TV
  //isolate->Dispose(); /* crashes... why?? */
#endif
}

void ScriptEngine::addBridge(ScriptBridge* bridge)
{
  HandleScope handle_scope(isolate);
  bridges.push_back(bridge);

  auto globalObjTemplateHandle = Local<ObjectTemplate>::New(Isolate::GetCurrent(), globalObjectTemplate);
  bridge->bridgeTo(globalObjTemplateHandle);
}


void ScriptEngine::ready()
{
  HandleScope handle_scope(isolate);
  auto globalObjTemplateHandle = Local<ObjectTemplate>::New(Isolate::GetCurrent(), globalObjectTemplate);
  Local<Context> localContext = Context::New(isolate, NULL, globalObjTemplateHandle);
  context.Reset(isolate, localContext);
  localContext->Enter(); //

  for (auto it = bridges.begin(); it != bridges.end(); ++it)
  {
    (*it)->contextReady();
  }
}

bool ScriptEngine::loadScript(const std::string &aScript,
                              const VoltEventArgsMap &aJsData)
{
  return loadScript(aScript, false, true, false, aJsData);
}

bool ScriptEngine::loadScript(const std::string& script, const bool isScriptLiteral,
                              const bool isMain, const bool refreshEventCallback,
                              const VoltEventArgsMap &aJsData)
{
  HandleScope handleScope(isolate);

  volt::util::Stopwatch prof_timer(true);
  volt::util::Stopwatch prof_timer_total(true);

  DataBuffer::SharedPtr script_data(new DataBuffer());

  Handle<String> source;

  std::string uri;

  // decide where the script data come from..
  if(isScriptLiteral)
  {
    source = StringToV8(script.c_str());
    uri = "";
  }
  else
  {
    uri = script;

    if(ResourceLoader::Instance().LoadString(script, script_data))
    {
      source = JsDataBufferToV8(script_data);
    }
    else
    {
      /* This is really a initialization error... */
      char msg[512];
      snprintf(msg, sizeof(msg), "Failed to open/read script: %s", script.c_str());
      throw VoltJsInitException(msg);
    }
  }

  LOG_INFO(s_logger_perf_load,
           "Took " << prof_timer << " sec to load "
           << script_data->length() << " bytes of JS (" <<
           (isScriptLiteral ? "script literal" : script) << ")");

  bool result = loadScript(source, uri, isMain, refreshEventCallback, aJsData);

  if(isMain)
  {
    LOG_INFO(s_logger_perf_init, "Took " << prof_timer_total <<
             " sec to load/compile/run/initialize " <<
             (isScriptLiteral ? "script literal" : script));

    LOG_INFO(s_logger_perf_init, "Current time: " << volt::util::Time::Now());
  }

  return result;
}

bool ScriptEngine::loadScript(DataBuffer::SharedPtr script, const std::string uri,
                              const bool isMain, const bool refreshEventCallback,
                              const VoltEventArgsMap &aJsData)
{
  HandleScope handleScope(isolate);

  volt::util::Stopwatch prof_timer_total(true);

  Handle<String> source = JsDataBufferToV8(script);

  bool result = loadScript(source, uri, isMain, refreshEventCallback, aJsData);

  if(isMain)
  {
    LOG_INFO(s_logger_perf_init, "Took " << prof_timer_total <<
             " sec to load/compile/run/initialize ");

    LOG_INFO(s_logger_perf_init, "Current time: " << volt::util::Time::Now());
  }

  return result;
}

bool ScriptEngine::loadScript(Handle<String> &source, const std::string uri,
                              const bool isMain, const bool refreshEventCallback,
                              const VoltEventArgsMap &aJsData)
{
  Handle<Script> compiledScript;

  //both compileScript and runScript throw a VoltJsInitException if they fail
  compileScript(source, compiledScript, uri);

  runScript(compiledScript);

  if(isMain or refreshEventCallback)
  {
    //Bind events to function names:
    // Store the functions in Persistent  handles, since we want
    // that to remain after this call returns
#if ENABLE_GLOBAL_KEY_HANDLER
    keyEventCallback.Reset( Isolate::GetCurrent(), bindFunctionName("onKeyEvent") );
#endif
  }

  if(isMain)
  {
    //Call the initialize function on the JavaScript side
    try
    {
      volt::util::Stopwatch prof_timer(true);

      sendInteruptEvent(volt::util::ON_LOAD, aJsData);
      sendInteruptEvent(volt::util::ON_SHOW, aJsData);
      executeFunctionName("initialize");

      LOG_INFO(s_logger_perf_init, "Took " << prof_timer <<
               " sec to execute ON_LOAD/ON_SHOW/initialize");
    }
    catch (VoltJsRuntimeException &e)
    {
      /* This is really a initialization error... */
      VoltJsInitException new_e("Failed to initialize UI");
      new_e.CopyJsErr(e);
      throw new_e;
    }
  }

  return true;
}


bool ScriptEngine::sendKeyEvent(const unsigned aKeyCode, const unsigned aType)
{
  HandleScope handleScope(isolate);
  auto range = eventListeners.equal_range(aKeyCode);

  /* Saving the listeners before actually invoking them in case the
   * listeners register additional listeners.
   * It is not safe to iterate ranges and inserting to the multimap. */
  std::vector<ScriptFunction> listeners;

  for (auto it = range.first; it != range.second; ++it)
  {
    listeners.push_back(it->second);
  }

  ScriptObject eventData;
  ScriptArray listenerArgs;

  bool handled = false;
  ScriptObject result;

  for (auto it = listeners.begin(); it != listeners.end(); ++it)
  {
    eventData.set("keycode", ScriptObject((int)aKeyCode));
    eventData.set("type", ScriptObject((int)aType));
    listenerArgs.set(0, eventData);

    result = it->invoke(listenerArgs);

    if (result.isBool())
    {
      handled |= result.asBool();
    }
  }

#if ENABLE_GLOBAL_KEY_HANDLER

  if (keyEventCallback.IsEmpty())
  {
    /* No handler found. */
    return handled;
  }

  TryCatch try_catch;

  Handle<Value> args[2] = { Number::New(Isolate::GetCurrent(), aKeyCode), Number::New(Isolate::GetCurrent(), aType) };
  auto localKeyCallback = Local<Function>::New(Isolate::GetCurrent(), keyEventCallback);
  Handle<Value> val = localKeyCallback->Call(getContext()->Global(), 2, args);

  if (val.IsEmpty())
  {
    VoltJsRuntimeException e("Failed to execute event callback");
    SET_JS_ERR_INFO(e, try_catch);
    throw e;
  }

  return handled | val->IsTrue();
#endif

  return handled;
}


bool ScriptEngine::sendFlickEvent(volt::util::MOUSE_FLICK flickType)
{
  unsigned eventID = (unsigned)flickType;
  return sendEvent(eventID);
}


bool ScriptEngine::sendInteruptEvent(volt::util::INTERUPT_EVENT interupt,
                                     const VoltEventArgsMap &aJsData)
{
  HandleScope scope(Isolate::GetCurrent());
  unsigned eventID = (unsigned)interupt;
  return sendEvent(eventID, aJsData);
}

bool ScriptEngine::sendWorkerMessageEvent(const std::string &aMsg)
{
  auto range = eventListeners.equal_range(volt::util::ON_MESSAGE);

  /* Saving the listeners before actually invoking them in case the
   * listeners register additional listeners.
   * It is not safe to iterate ranges and inserting to the multimap. */
  std::vector<ScriptFunction> listeners;

  for (auto it = range.first; it != range.second; ++it)
  {
    listeners.push_back(it->second);
  }

  ScriptObject eventData;
  ScriptArray args;

  for (auto it = listeners.begin(); it != listeners.end(); ++it)
  {
    eventData.set("data", ScriptObject(aMsg));
    args.set(0, eventData);

    it->invoke(args);
  }

  return true;
}

bool ScriptEngine::sendWorkerCommandEvent(const std::string &aCmd,
    std::vector<std::string> &aResults)
{
  auto range = eventListeners.equal_range(volt::util::ON_COMMAND);

  /* Saving the listeners before actually invoking them in case the
   * listeners register additional listeners.
   * It is not safe to iterate ranges and inserting to the multimap. */
  std::vector<ScriptFunction> listeners;

  for (auto it = range.first; it != range.second; ++it)
  {
    listeners.push_back(it->second);
  }

  bool handled = false;

  ScriptObject eventData;
  ScriptArray args;

  for (auto it = listeners.begin(); it != listeners.end(); ++it)
  {
    eventData.set("data", ScriptObject(aCmd));
    args.set(0, eventData);

    ScriptObject result = it->invoke(args);

    if (result.isString())
    {
      aResults.push_back(result.asString());
      handled = true;
    }
  }

  return handled;
}

bool ScriptEngine::sendEvent(const unsigned eventID, const VoltEventArgsMap &aJsData)
{
  bool invokedSomething = false;
  auto range = eventListeners.equal_range(eventID);

  /* Saving the listeners before actually invoking them in case the
   * listeners register additional listeners.
   * It is not safe to iterate ranges and inserting to the multimap. */
  std::vector<ScriptFunction> listeners;

  for (auto it = range.first; it != range.second; ++it)
  {
    listeners.push_back(it->second);
  }

  ScriptArray args;
  args.set(0, VoltEventArgsMapToScriptObject(aJsData));

  for (auto it = listeners.begin(); it != listeners.end(); ++it)
  {
    it->invoke(args);
    invokedSomething = true;
  }

  return invokedSomething;
}

void ScriptEngine::registerEvent(const unsigned eventID, ScriptFunction listener)
{
  //Have to check to ensure the same event is not registered twice. If a duplicate is detected, do nothing.
  auto range = eventListeners.equal_range(eventID);

  for (auto it = range.first; it != range.second; ++it)
  {
    if (it->second == listener)
    {
      return;
    }
  }

  eventListeners.insert( std::make_pair(eventID, listener) );
}

void ScriptEngine::unregisterEvent(const unsigned eventID, ScriptFunction listener)
{
  if (eventListeners.count(eventID) <= 1) //if there is only one with this key, erase it
  {
    eventListeners.erase(eventID);
  }
  else
  {
    auto range = eventListeners.equal_range(eventID);
    auto target = eventListeners.end();

    for (auto it = range.first; it != range.second; ++it) //Get an iterator to the specific entry we want to delete
    {
      if (it->second == listener)
      {
        target = it;
      }
    }

    //If the listener was found, remove it.
    if (target != eventListeners.end())
    {
      eventListeners.erase(target);
    }
  }
}


void Log(const char* event) //TODO: Put this in some sort of utilities header
{
  LOG_DEBUG(ScriptEngine::LOGGER, "Logged: " << std::string(event));
}

Handle<Context> ScriptEngine::getContext() const
{
  return Local<Context>::New(Isolate::GetCurrent(), context);
}

//#define VOLT_PRECOMPILE_JS
#ifdef VOLT_PRECOMPILE_JS
#include "ResourceLoader.h"
#include "ResourceManager.h"
#endif
void ScriptEngine::compileScript(Handle<String> source, Handle<Script>& compiledScript,
                                 const std::string &source_uri)
{
  volt::util::Stopwatch prof_timer(true);

  Handle<String> srcUriV8 = StringToV8( (DEBUGGER_FILENAME_PREFIX + source_uri).c_str() );

  //HandleScope handleScope(isolate);
  TryCatch try_catch;
#ifdef VOLT_PRECOMPILE_JS
  // Compile the script and check for errors.
  ScriptData *pre_data = NULL;

  if (source_uri.empty() == false)
  {
    gint64 precomp_prof_start = g_get_monotonic_time();
    DataBuffer::SharedPtr pre_data_serialized;

    if (ResourceLoader::Instance().LoadString(source_uri + ".pc", pre_data_serialized))
    {
      LOG_INFO(s_logger_perf_precompile,
               "Took " << (g_get_monotonic_time() - precomp_prof_start) <<
               " usec to load precompiled data (" <<
               pre_data_serialized->length() << " bytes)");

      LOG_DEBUG(volt::util::Logger("volt.core"), "Using precompiled data");
      precomp_prof_start = g_get_monotonic_time();
      pre_data = ScriptData::New(pre_data_serialized->c_str(),
                                 pre_data_serialized->length());
      LOG_INFO(s_logger_perf_precompile,
               "Took " << (g_get_monotonic_time() - precomp_prof_start) <<
               " usec to create new ScriptData");

      if (pre_data->HasError())
      {
        LOG_DEBUG(volt::util::Logger("volt.core"), "Precompile data has errors");
        pre_data = NULL;
      }
    }
    else
    {
      /* No pre-precompiled data */
      pre_data = ScriptData::PreCompile(source);
      LOG_INFO(s_logger_perf_precompile,
               "Took " << (g_get_monotonic_time() - precomp_prof_start) <<
               " usec to precompile JS (" + source_uri + ")");

      if (pre_data->HasError())
      {
        LOG_DEBUG(volt::util::Logger("volt.core"), "Failed precompile data");
      }
      else
      {
        volt::util::Logger logger("volt.script");
        precomp_prof_start = g_get_monotonic_time();
        Resource::IORequest::SharedPtr request(Resource::ResourceManager::CreateRequest(source_uri + ".pc"));
        request->set_method(Resource::IORequest::METHOD_PUT);
        request->set_data(std::string(pre_data->Data(), pre_data->Length()));

        if (Resource::ResourceManager::Instance().Process(request) == false)
        {
          LOG_DEBUG(logger, "Failed to dump precompiled data");
        }
        else
        {
          LOG_DEBUG(logger, "Dumped precompiled data (" <<
                    pre_data->Length() << " bytes)");
        }

        LOG_INFO(s_logger_perf_precompile,
                 "Took " << (g_get_monotonic_time() - precomp_prof_start) <<
                 " usec to dump precompiled data");
      }
    }
  }

  compiledScript = Script::Compile(source, srcUriV8, pre_data);
#else
  compiledScript = Script::Compile(source, srcUriV8);
#endif

  if (compiledScript.IsEmpty())
  {
    VoltJsInitException e("Failed to compile script");
    SET_JS_ERR_INFO(e, try_catch);
    throw e;
  }

  LOG_INFO(s_logger_perf_compile,
           "Took " << prof_timer << " sec to compile " <<
           source->Length() << " bytes of JS (" << source_uri << ")");
}

void ScriptEngine::runScript(v8::Handle<v8::Script> compiledScript)
{
  volt::util::Stopwatch prof_timer(true);

  HandleScope handleScope(Isolate::GetCurrent());
  TryCatch try_catch;

  // Run the script!
  Handle<Value> result = compiledScript->Run();

  if (result.IsEmpty())
  {
    VoltJsInitException e("Failed to execute script");
    SET_JS_ERR_INFO(e, try_catch);
    throw e;
  }

  LOG_INFO(s_logger_perf_run, "Took " << prof_timer << " sec to run script");
}

void ScriptEngine::executeFunction(v8::Handle<v8::Function> function, v8::Handle<Object> object,
                                   int argc, v8::Handle<v8::Value>* argv)
{
  v8::TryCatch try_catch;

  if(object.IsEmpty())
  {
    object = getContext()->Global();
  }

  Handle<Value> val = function->Call(object, argc, argv);

  if (val.IsEmpty())
  {
    VoltJsRuntimeException e("Failed to execute function");
    SET_JS_ERR_INFO(e, try_catch);
    throw e;
  }
}

void ScriptEngine::executeFunctionName(const char* name)
{
  HandleScope handle_scope(isolate);

  Handle<Value> valHandle = getContext()->Global()->Get(StringToV8(name));

  if (!valHandle->IsFunction())
  {
    return;
  }

  executeFunction(Handle<Function>::Cast(valHandle));
}

Handle<Function> ScriptEngine::bindFunctionName(const char* name)
{
  //Find the OnSpacebar function in the js
  Handle<String> nameHandle = StringToV8(name);
  Handle<Value> valHandle = getContext()->Global()->Get(nameHandle);

  // If there is no OnSpacebar function, or if it is not a function,
  // bail out
  if (!valHandle->IsFunction())
  {
    return Handle<Function>();  //empty
  }

  // It is a function; cast it to a Function
  Handle<Function> functionHandle = Handle<Function>::Cast(valHandle);

  // Store the function in a Persistent  handle, since we also want
  // that to remain after this call returns
  return functionHandle;
}


/* Forward decl. global JS functions */
static void Print(const v8::FunctionCallbackInfo<v8::Value>& args);

Handle<ObjectTemplate> ScriptEngine::createGlobalObjectTemplate()
{
  //EscapableHandleScope scope(Isolate::GetCurrent());

  Local<ObjectTemplate> global = ObjectTemplate::New();

  /* Bind the global 'print' function to the C++ Print callback.
  * It may make more sense to move this to something like DefaultBridge? */
  global->Set(StringToV8("print"), FunctionTemplate::New(Isolate::GetCurrent(), Print));

  /* Bind in require function. This function does some unusual, probably interpreter specific stuff. Best to keep it here.*/
  global->Set(StringToV8("require"), FunctionTemplate::New(Isolate::GetCurrent(), Require, External::New(Isolate::GetCurrent(), this)));

  return global;//scope.Escape(global);
}

/* Global JS function definitions. */

/* Require handles module inclusion*/
void ScriptEngine::Require(const v8::FunctionCallbackInfo<v8::Value>& args)
{
  void* data = Handle<External>::Cast(args.Data())->Value();
  ScriptEngine* self = reinterpret_cast<ScriptEngine*>(data);
  self->requireImpl(&args);
}

ScriptObject ScriptEngine::requireNoContext(const std::string &jsModuleFileName)
{
  const v8::FunctionCallbackInfo<v8::Value>* const args = nullptr;
  return requireImpl(args,jsModuleFileName);
}

bool ScriptEngine::dumpHeapSnapshot(const std::string &aPath)
{
  LOG_DEBUG(LOGGER, "Dumping heapsnapshot to " << aPath);

  if (v8::Isolate::GetCurrent()->GetHeapProfiler() == NULL)
  {
    LOG_DEBUG(LOGGER, "Failed to get heap profiler");
    return false;
  }

  std::string normalized;
  unsigned char perm = Resource::FileIORequest::NormalizePath(aPath, normalized);
  if ((perm & Resource::PERM_W) == 0)
  {
    LOG_DEBUG(LOGGER, "Cannot dump heap snapshot to " << aPath);
    return false;
  }

  const v8::HeapSnapshot *snapshot =
    v8::Isolate::GetCurrent()->GetHeapProfiler()->TakeHeapSnapshot(StringToV8("test"));

  FileOutputStream stream(normalized);
  if (stream.IsOpen())
  {
    snapshot->Serialize(&stream, v8::HeapSnapshot::kJSON);
    return true;
  }
  else
  {
    LOG_WARN(LOGGER, "Failed to write to " << aPath);
    return false;
  }
}

ScriptObject ScriptEngine::requireImpl(const v8::FunctionCallbackInfo<v8::Value>* const args, const std::string& jsModuleFileName)
{
  //In order to have access to the 'exports' object inside the IIFE when using requireNoContext
  //we use this global js variable.
  static const char* PRIVATE_EXPORTS_NAME = "_____private_volt_exports_____";
  const bool useContext = (jsModuleFileName == "") && args; //determines whether we create v8 contexts or not.
  EscapableHandleScope scope(Isolate::GetCurrent());
  ScriptEngine* self = useContext ? reinterpret_cast<ScriptEngine*>(Handle<External>::Cast(args->Data())->Value()) : this;


  Local<Value> result;
  DataBuffer::SharedPtr source;
  Handle<String> js;

  const bool argValid = useContext ? (args->Length() > 0 && (*args)[0]->IsString()) : (jsModuleFileName.length() > 0);

  if(argValid)
  {

    std::string filename = useContext ? V8ToString( (*args)[0]->ToString() ) : jsModuleFileName;
    Handle<String> fileNameV8 = StringToV8(DEBUGGER_FILENAME_PREFIX+filename);

    //reuse if module is already loaded
    if(self->modules.count(filename) > 0)
    {
      if(self->modules[filename]->IsEmpty())
      {
        std::string errMsg = "Circular dependency detected in " + filename +".";
        LOG_ERROR(LOGGER, errMsg);
        v8::Local<Value> val = Isolate::GetCurrent()->ThrowException(StringToV8(errMsg+" Check require statements."));

        if (useContext)
        {
          args->GetReturnValue().Set(val);
        }

        return ScriptObject(val);
      }

      auto result = Local<Value>::New(Isolate::GetCurrent(), *(self->modules[filename]));

      if(useContext)
      {
        args->GetReturnValue().Set( result );
      }

      return ScriptObject(result);
    }

    self->modules[filename] = new UniquePersistent<Value>(); //put a placeholder in the modules map, to foil circular requires

    volt::util::Stopwatch prof_timer(true);

    //If the module name doesn't have a .js suffix
    std::string suffix = filename.length() >= 3 ? filename.substr( filename.length() - 3 ) : "";
    std::string filenameFull = (suffix != ".js") ? "file://$VOLT_ROOT/modules/" + filename + ".js" : filename;

    if(ResourceLoader::Instance().LoadString(filenameFull , source))
    {
      if(useContext)
      {
        js = JsDataBufferToV8(source);
      }
      else
      {
        //wrap module in IIFE, saving a private exports object.
        const std::string file = std::string("(function () { var exports = {};") +
        		source->c_str() + "\n" + PRIVATE_EXPORTS_NAME + "= exports;})();";
        js = StringToV8(file);
      }
    }
    else
    {
      std::string errorMsg = "Unable to load '" + filename + "'. Source file either does not exist or is inaccesable." ;
      LOG_ERROR(LOGGER, errorMsg);
      v8::Local<Value> val = Isolate::GetCurrent()->ThrowException(StringToV8(errorMsg));

      if(useContext)
      {
        args->GetReturnValue().Set(val);
      }

      return ScriptObject(val);
    }

    LOG_INFO(s_logger_perf_load,
             "Took " << prof_timer << " sec to load " << source->length() <<
             " bytes of JS (" << filenameFull << ")");

    Handle<Context> currentContext = Isolate::GetCurrent()->GetCurrentContext();
    Handle<Context> moduleContext;
    Handle<Object> exports;
    Handle<Value> savedExports; //for saving/restoring our special global after requireNoContext calls.

    if(useContext)
    {
      auto localGlobalObjectTemplate = Local<ObjectTemplate>::New(Isolate::GetCurrent(), self->globalObjectTemplate);
      moduleContext = Context::New(Isolate::GetCurrent(), nullptr, localGlobalObjectTemplate);
      moduleContext->SetSecurityToken(currentContext->GetSecurityToken());
      moduleContext->Enter(); //push new module context to stack
      exports = Object::New(Isolate::GetCurrent());
      moduleContext->Global()->Set(StringToV8("exports"), exports);
    }
    else
    {
      savedExports = currentContext->Global()->Get(StringToV8(PRIVATE_EXPORTS_NAME));
      exports = Object::New(Isolate::GetCurrent());
      currentContext->Global()->Set(StringToV8(PRIVATE_EXPORTS_NAME), exports);
    }

    Handle<Script> script;
    {
      //scope the v8::TryCatch object
      TryCatch tryCatch;
      script = Script::Compile(js, fileNameV8);

      if (script.IsEmpty()) //or could use tryCatch.HasCaught()?
      {
        std::string errMsg = "Error compiling required script: \n";
        errMsg += "  File: " + filename + "\n" +
                  "  Line Number: " + std::to_string(tryCatch.Message()->GetLineNumber());
        LOG_ERROR(LOGGER, errMsg);
        auto v8Val = tryCatch.ReThrow();

        if(useContext)
        {
          args->GetReturnValue().Set( v8Val );
          moduleContext->Exit(); //abandon error context
        }

        return ScriptObject(v8Val);
      }
    }

    LOG_INFO(s_logger_perf_compile,
             "Took " << prof_timer << " sec to compile " << source->length() <<
             " bytes of JS (" << filenameFull << ")");

    {
      //Run the script
      TryCatch tryCatch; //catch script runtime errors

      prof_timer.Restart();

      script->Run();

      LOG_INFO(s_logger_perf_run,
               "Took " << prof_timer << " sec to run script (" <<
               filenameFull << ")");

      if(useContext)
      {
        moduleContext->Exit(); //pop module context off stack
      }

      if (tryCatch.HasCaught())
      {
        std::string errMsg = "Error compiling required script: \n";
        errMsg += "  File: " + filename + "\n" +
                  "  Line Number: " + std::to_string(tryCatch.Message()->GetLineNumber());
        LOG_ERROR(LOGGER, errMsg);
        auto v8Val = tryCatch.ReThrow();

        if(useContext)
        {
          args->GetReturnValue().Set(v8Val);
        }

        return ScriptObject(v8Val);
      }
    }

    Handle<Value> moduleObject = useContext ? moduleContext->Global()->Get(StringToV8("exports")) :
                                 currentContext->Global()->Get(StringToV8(PRIVATE_EXPORTS_NAME));;
    //in case the user defined a new "exports" for a constructor function or something
    result = moduleObject;
    self->modules[filename]->Reset(Isolate::GetCurrent(), moduleObject); //an empty handle was inserted earlier

    if(!useContext)
    {
      //restore old value of our PRIVATE_EXPORTS_NAME var in case someone actually uses the same var name
      currentContext->Global()->Set(StringToV8(PRIVATE_EXPORTS_NAME), savedExports);
    }
  }
  else
  {
    result = Undefined(Isolate::GetCurrent());
  }

  auto returnVal = scope.Escape(result);

  if(useContext)
  {
    args->GetReturnValue().Set(returnVal);
  }

  return ScriptObject(returnVal);

}
ScriptObject ScriptEngine::VoltEventArgsMapToScriptObject(const VoltEventArgsMap &aMap)
{
  ScriptObject obj;

  if (aMap.Empty())
  {
    return obj;
  }

  std::vector<std::string> keys;

  std::string sval;
  const uint8_t *bval = NULL;
  size_t bsize = 0;
  VoltEventArgsList lval;
  VoltEventArgsMap mval;

for (auto key: aMap.GetKeys(keys))
  {
    if (aMap.GetString(key, sval))
    {
      obj.set(key, ScriptObject(sval));
    }
    else if (aMap.GetByteArray(key, bval, bsize))
    {
      obj.set(key, ScriptArrayBuffer(bval, bsize));
    }
    else if (aMap.GetMap(key, mval))
    {
      obj.set(key, VoltEventArgsMapToScriptObject(mval));
    }
    else if (aMap.GetList(key, lval))
    {
      obj.set(key, VoltEventArgsListToScriptArray(lval));
    }
    else
    {
      LOG_WARN(LOGGER, "Unknown Volt data type: " << key);
    }
  }

  return obj;
}

ScriptArray ScriptEngine::VoltEventArgsListToScriptArray(const VoltEventArgsList &aList)
{
  ScriptArray array;

  if (aList.Empty())
  {
    return array;
  }

  std::string sval;
  const uint8_t *bval = NULL;
  size_t bsize = 0;
  VoltEventArgsList lval;
  VoltEventArgsMap mval;

  for (size_t index = 0; index < aList.Size(); ++index)
  {
    if (aList.GetString(index, sval))
    {
      array.set(index, ScriptObject(sval));
    }
    else if (aList.GetByteArray(index, bval, bsize))
    {
      array.set(index, ScriptArrayBuffer(bval, bsize));
    }
    else if (aList.GetMap(index, mval))
    {
      array.set(index, VoltEventArgsMapToScriptObject(mval));
    }
    else if (aList.GetList(index, lval))
    {
      array.set(index, VoltEventArgsListToScriptArray(lval));
    }
    else
    {
      LOG_WARN(LOGGER, "Unknown Volt data type at index " << index);
    }
  }

  return array;
}

/* This is called when the global print function is called. */
static void Print(const v8::FunctionCallbackInfo<Value>& args)
{
  static volt::util::Logger logger("volt_js");

  std::string msg = "";
  bool first = true;

  for (int i = 0; i < args.Length(); i++)
  {
    v8::HandleScope handle_scope(args.GetIsolate());

    if (first)
    {
      first = false;
    }
    else
    {
      msg += " ";
    }

    v8::String::Utf8Value str(args[i]);
    msg += *str ? *str : "";
  }

  LOG_INFO(logger, msg);
}
