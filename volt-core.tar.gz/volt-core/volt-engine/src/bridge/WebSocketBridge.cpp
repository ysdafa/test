#include "WebSocketBridge.h"


namespace Bridge
{


	class OnCallbackData{
	public:
		OnCallbackData(const Bridge::ScriptFunction &aJsCallback) :
			js_callback(aJsCallback)
		{
		}
		OnCallbackData(const Bridge::ScriptFunction &aJsCallback, std::string aData) :
			js_callback(aJsCallback),
			data(aData)
		{
		}
		std::string data;
		const Bridge::ScriptFunction &js_callback;
	};

	WebSocketBridge::WebSocketBridge() : ScriptBridge(){}
	WebSocketBridge::~WebSocketBridge(){}

	void WebSocketBridge::mapScriptInterface(ScriptContext& aContext)
	{
		aContext.captureMethodCall<WebSocketMessengerAdapter, &HandleSend>("send");
		aContext.captureMethodCall<WebSocketMessengerAdapter, &HandleClose>("close");

		aContext.bindFunction<WebSocketMessengerAdapter, &WebSocketMessengerAdapter::onopen_callback, &WebSocketMessengerAdapter::set_onopen_callback>("onopen");
		aContext.bindFunction<WebSocketMessengerAdapter, &WebSocketMessengerAdapter::onmessage_callback, &WebSocketMessengerAdapter::set_onmessage_callback>("onmessage");
		aContext.bindFunction<WebSocketMessengerAdapter, &WebSocketMessengerAdapter::onerror_callback, &WebSocketMessengerAdapter::set_onerror_callback>("onerror");
		aContext.bindFunction<WebSocketMessengerAdapter, &WebSocketMessengerAdapter::onclose_callback, &WebSocketMessengerAdapter::set_onclose_callback>("onclose");
	}


	void* WebSocketBridge::constructFromScript(const ScriptArray &aArgs)
	{
		try{
			if (aArgs.Length() == 0){
				return new WebSocketMessengerAdapter();
			}
			else if (aArgs.Length() == 1){
				WebSocketMessengerAdapter *websocket = new WebSocketMessengerAdapter(aArgs[0].asString());
				websocket->startService();
				return websocket;
			}
			else if (aArgs.Length() == 2){
				WebSocketMessengerAdapter *websocket = new WebSocketMessengerAdapter(aArgs[0].asString(), aArgs[1].asString());
				websocket->startService();
				return websocket;
			}
		}
		catch (std::string exception){}
		throw VoltJsRuntimeException("websocket create exception.");
	}

	ScriptObject WebSocketBridge::HandleSend(WebSocketMessengerAdapter *aSelf, const ScriptArray &aArgs)
	{
		aSelf->send(aArgs[0].asString());
		return ScriptObject(true);
	}

	ScriptObject WebSocketBridge::HandleClose(WebSocketMessengerAdapter *aSelf, const ScriptArray &aArgs)
	{
		aSelf->destroyService();
		return ScriptObject(true);
	}

	gboolean WebSocketBridge::FireOnCallbacks(gpointer aData){
		OnCallbackData *callbackData = reinterpret_cast<OnCallbackData *>(aData);
		if (callbackData->js_callback.isFunction()){
			Bridge::ScriptArray arg;

			if (callbackData->data.empty() == false){
				Bridge::ScriptObject js_response;
				js_response.set("data", Bridge::ScriptObject(callbackData->data));
				arg.set(0, js_response);
			}

			callbackData->js_callback.invoke(arg);
		}


		delete callbackData;
		return FALSE;
	}



	WebSocketMessengerAdapter::WebSocketMessengerAdapter(){
		messenger = new WebSocketMessenger();
		bind();
	}
	WebSocketMessengerAdapter::~WebSocketMessengerAdapter(){
		delete messenger;
	}
	WebSocketMessengerAdapter::WebSocketMessengerAdapter(std::string address){
		messenger = new WebSocketMessenger(address);
		bind();
	}
	WebSocketMessengerAdapter::WebSocketMessengerAdapter(std::string address, std::string protocolName){
		messenger = new WebSocketMessenger(address, protocolName);
		bind();
	}


	void WebSocketMessengerAdapter::bind(){
		messenger->onOpenCallback = std::bind(&WebSocketMessengerAdapter::onOpen, this);
		messenger->onMessageCallback = std::bind(&WebSocketMessengerAdapter::onMessage, this, std::placeholders::_1);
		messenger->onErrorCallback = std::bind(&WebSocketMessengerAdapter::onError, this);
		messenger->onCloseCallback = std::bind(&WebSocketMessengerAdapter::onClose, this);
	}
	void WebSocketMessengerAdapter::startService(){
		messenger->startService();
	}
	void WebSocketMessengerAdapter::destroyService(){
		messenger->destroyService();
	}
	void WebSocketMessengerAdapter::send(std::string message){
		messenger->send(message);
	}


	void WebSocketMessengerAdapter::onOpen(){
		clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW, WebSocketBridge::FireOnCallbacks, new OnCallbackData(onopen_callback()), NULL);
	}

	void WebSocketMessengerAdapter::onMessage(std::string data){
		clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW, WebSocketBridge::FireOnCallbacks, new OnCallbackData(onmessage_callback(), data), NULL);
	}


	void WebSocketMessengerAdapter::onError(){
		clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW, WebSocketBridge::FireOnCallbacks, new OnCallbackData(onerror_callback()), NULL);
	}

	void WebSocketMessengerAdapter::onClose(){
		clutter_threads_add_idle_full(CLUTTER_PRIORITY_REDRAW, WebSocketBridge::FireOnCallbacks, new OnCallbackData(onclose_callback()), NULL);
	}


}
