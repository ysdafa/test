/*
 * FrameBridge.cpp
 *
 *  Created on: Jul 29, 2013
 *      Author: reza
 */

#include "FrameBridge.h"

namespace Bridge
{

void Bridge::FrameBridge::mapScriptInterface(ScriptContext& context)
{
  LayoutBridge::mapScriptInterface(context);

  //Spacing doesn't work well with alignment. Most likely should seperate to different layout
  context.capturePropertyAccess<FrameWidget, &getAlignX, &setAlignX>("alignX");
  context.capturePropertyAccess<FrameWidget, &getAlignY, &setAlignY>("alignY");
}

Widget* Bridge::FrameBridge::constructWidget(float x, float y, float width, float height,
    Widget* parent, const ScriptArray& args)
{
  LayoutAlignment alignX, alignY;
  alignX = alignY = LayoutAlignment::Center;

  LayoutOrientation orientation = LayoutOrientation::Horizontal;

  if(args.Length() > 0)
  {
    if( args[0].has("orientation") && args[0]["orientation"].isString() )
    {
      orientation = deserializeLayoutOrientation(args[0]["orientation"].asString());
    }

    if( args[0].has("alignX") && args[0]["alignX"].isString() )
    {
      alignX = deserializeLayoutAlignment( args[0]["alignX"].asString(), Center );
    }

    if( args[0].has("alignY") && args[0]["alignY"].isString() )
    {
      alignY = deserializeLayoutAlignment(args[0]["alignY"].asString(), Center);
    }

  }

  if(width == -1)
  {
    width = 0;
  }

  if(height == -1)
  {
    height = 0;
  }

  return new FrameWidget(x, y, width, height, parent, orientation, alignX, alignY);
}


ScriptObject FrameBridge::getAlignX(FrameWidget* self)
{
  return ScriptObject( serializeLayoutAlignment( self->getAlignX() ) );
}

void FrameBridge::setAlignX(FrameWidget* self, ScriptObject value)
{
  if(value.isString())
  {
    self->setAlignX(deserializeLayoutAlignment(value.asString(), Center));
  }
}

ScriptObject FrameBridge::getAlignY(FrameWidget* self)
{
  return ScriptObject( serializeLayoutAlignment( self->getAlignY() ) );
}

void FrameBridge::setAlignY(FrameWidget* self, ScriptObject value)
{
  if(value.isString())
  {
    self->setAlignY(deserializeLayoutAlignment(value.asString(), Center));
  }
}




} /* namespace Bridge */
