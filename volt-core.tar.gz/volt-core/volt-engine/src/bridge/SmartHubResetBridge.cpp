/*
* TTSBridge
*
*  Created on: 2014-10-14
*      Author: backki.kim
*/

#include "SmartHubResetBridge.h"
#include <stdio.h>
#include <stdlib.h>
#include "vconf.h"
#include <unistd.h>

#include "AppConfig.h"
#include <boost/algorithm/string/predicate.hpp>
#include <boost/lexical_cast.hpp>

using namespace v8;
using namespace Bridge;
using namespace volt::util;
using namespace std;

std::string SmartHubResetBridge::LOGGER_NAME = "volt.smarthubreset.bridge";
volt::util::Logger SmartHubResetBridge::logger_(LOGGER_NAME);

SmartHubResetBridge::SmartHubResetBridge(): ScriptInstanceBridge(this)
{
}

SmartHubResetBridge::~SmartHubResetBridge()
{
}

void SmartHubResetBridge::mapScriptInterface(ScriptContext& aContext)
{
	aContext.captureMethodCall<SmartHubResetBridge, &HandleNeedReset>("needReset");
	aContext.captureMethodCall<SmartHubResetBridge, &HandleResetCompleted>("resetComplete");
	aContext.captureMethodCall<SmartHubResetBridge, &HandleClearCacheFolder>("clearCacheFolder");
}

void* SmartHubResetBridge::constructFromScript(const ScriptArray &aArgs)
{
	return this;
}

std::string SmartHubResetBridge::GetVconfKey()
{
		try
		{
			std::string appjs = AppConfig::Instance().GetAppRootPath();

			if (boost::starts_with(appjs, "/usr/apps/org.volt.firstscreen"))
			{
				return std::string("db/smarthub/reset/firstscreen");
			}
				
			if (boost::starts_with(appjs, "/opt/down/panels/apps"))
			{
				return std::string("db/smarthub/reset/apps");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/clips"))
			{
				return std::string("db/smarthub/reset/clips");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/games"))
			{
				return std::string("db/smarthub/reset/games");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/mycontents"))
			{
				return std::string("db/smarthub/reset/mycontents");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/newson"))
			{
				return std::string("db/smarthub/reset/newson");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/soccer"))
			{
				return std::string("db/smarthub/reset/soccer");
			}
		}
    catch (boost::bad_any_cast)
    {
    }
	
	return std::string("");
}

std::string SmartHubResetBridge::GetTempFolder()
{
	
		try
		{
			std::string appjs = AppConfig::Instance().GetAppRootPath();

			if (boost::starts_with(appjs, "/usr/apps/org.volt.firstscreen"))
			{
				return std::string("/opt/down/panels/firstscreen_temp");
			}
				
			if (boost::starts_with(appjs, "/opt/down/panels/apps"))
			{
				return std::string("/opt/down/panels/apps_temp");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/clips"))
			{
				return std::string("/opt/down/panels/clips_temp");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/games"))
			{
				return std::string("/opt/down/panels/games_temp");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/mycontents"))
			{
				return std::string("/opt/down/panels/mycontents_temp");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/newson"))
			{
				return std::string("/opt/down/panels/newson_temp");
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/soccer"))
			{
				return std::string("/opt/down/panels/soccer_temp");
			}
		}
    catch (boost::bad_any_cast)
    {
    }
      
	return std::string("");
}

ScriptObject SmartHubResetBridge::HandleNeedReset(SmartHubResetBridge *aSelf, const ScriptArray &aArgs)
{
	std::string key = GetVconfKey();
    LOG_DEBUG(logger_, "HandleNeedReset: " << key);

	if (key.empty() == false)
	{
		int result = -1;
		vconf_get_int(key.c_str(), &result);
		LOG_DEBUG(logger_, "value: " << result);

		if (result == 0) {
			return ScriptObject(true);
		}
	}

	return ScriptObject(false);
}

ScriptObject SmartHubResetBridge::HandleResetCompleted(SmartHubResetBridge *aSelf, const ScriptArray &aArgs)
{
	printf("resetCompleted\n");
	
	std::string key = GetVconfKey();
    LOG_DEBUG(logger_, "HandleResetCompleted: " << key);

	if (key.empty() == false)
	{
		vconf_set_int(key.c_str(), 1);
	}

	return ScriptObject(true);
}

ScriptObject SmartHubResetBridge::HandleClearCacheFolder(SmartHubResetBridge *aSelf, const ScriptArray &aArgs)
{
	std::string cacheFolder = GetTempFolder();
    
	printf("clearCacheFolder: %s\n", cacheFolder.c_str());

	if (cacheFolder.empty() == false)
	{
		char buffer[1024];
		snprintf(buffer, 1023, "rm -rf %s", cacheFolder.c_str());
		system(buffer);
	}

	return ScriptObject(true);
}
