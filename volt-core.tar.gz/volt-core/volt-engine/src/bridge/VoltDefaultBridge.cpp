/*
 * VoltDefaultBridge.cpp
 *
 *  Created on: May 20, 2013
 *      Author: ytakebuchi
 */

#include "VoltDefaultBridge.h"
#include "Widget.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <clutter/clutter.h>
#include <fontconfig/fontconfig.h>

#include <clutter_helper.h>

#include "Version.h"
#include "Exception.h"
#include "StaticUI.h"
#include "ResourceLoader.h"
#include "ResourceManager.h"
#include "DirIORequest.h"
#include "FileIORequest.h"
#include "TextWidget.h"

#include "VoltProcessManager.h"
#include "VoltFullProcessRuntime.h"
#include "VoltMessageCenter.h"
#include "VoltRuntimeMessages.h"
#include "VoltText.h"

#include "AppConfig.h"
#include "XWindowManager.h"

//#include "key_manager.h"

using namespace Bridge;
using namespace Resource;
using namespace volt::util;
using namespace volt::util::ipc;
using namespace volt::graphics;

#define DEFINE_KEY_MAP(context,key) (context).bindNumber<VoltDefaultBridge, int, \
                                                         &VoltDefaultBridge::get##key, \
                                                         &VoltDefaultBridge::set##key>(#key)

volt::util::Logger VoltDefaultBridge::LOGGER("volt.default.bridge");

VoltDefaultBridge::VoltDefaultBridge(ScriptEngine *aJsEngine):
  ScriptInstanceBridge(this), js_engine_(aJsEngine), timers_()
{
}

VoltDefaultBridge::~VoltDefaultBridge()
{
}

void VoltDefaultBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(LOGGER, "Mapping script interfaces");

  aContext.captureMethodCall<VoltDefaultBridge, &HandleExit>("exit");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleHide>("hide");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleQuit>("quit");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleLoad>("load");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleLoadFile>("loadFile");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleRequireNoContext>("requireNoContext");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleLoadApp>("loadApp");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleSetTimeout>("setTimeout");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleClearTimeout>("clearTimeout");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleSetInterval>("setInterval");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleClearInterval>("clearInterval");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleClearTimer>("clearTimer");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleGetWidgetById>("getWidgetById");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleSetDefaultFont>("setDefaultFont");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleGetAbsolutePath>("getAbsolutePath");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleConfigureColorPicking>("configureColorPicking");

  //Event handling functions
  aContext.captureMethodCall<VoltDefaultBridge, &HandleAddEventListener>("addEventListener");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleRemoveEventListener>("removeEventListener");

  aContext.captureMethodCall<VoltDefaultBridge, &HandleDispatchEvent>("dispatchEvent");

  aContext.captureMethodCall<VoltDefaultBridge, &HandlePostMessage>("postMessage");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleExecCommand>("execCommand");

  aContext.captureMethodCall<VoltDefaultBridge, &HandleGetVersion>("getVersion");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleIsRightToLeft>("isRightToLeft");
  aContext.captureMethodCall<VoltDefaultBridge, &HandleGetHighContrastMode>("getHighContrastMode");

  aContext.captureMethodCall<VoltDefaultBridge,
                             &HandleDumpJavaScriptHeapSnapshot>("dumpJavaScriptHeapSnapshot");

  DEFINE_KEY_MAP(aContext, EVENT_KEY_PRESS);
  DEFINE_KEY_MAP(aContext, EVENT_KEY_RELEASE);

  DEFINE_KEY_MAP(aContext, MOUSE_BUTTON_LEFT);
  DEFINE_KEY_MAP(aContext, MOUSE_BUTTON_MIDDLE);
  DEFINE_KEY_MAP(aContext, MOUSE_BUTTON_RIGHT);
  DEFINE_KEY_MAP(aContext, MOUSE_BUTTON_SIDE_LEFT);
  DEFINE_KEY_MAP(aContext, MOUSE_BUTTON_SIDE_RIGHT);

  DEFINE_KEY_MAP(aContext, KEY_JOYSTICK_OK);
  DEFINE_KEY_MAP(aContext, KEY_MENU);
  DEFINE_KEY_MAP(aContext, KEY_JOYSTICK_UP);
  DEFINE_KEY_MAP(aContext, KEY_JOYSTICK_DOWN);
  DEFINE_KEY_MAP(aContext, KEY_JOYSTICK_LEFT);
  DEFINE_KEY_MAP(aContext, KEY_JOYSTICK_RIGHT);
  DEFINE_KEY_MAP(aContext, KEY_3);
  DEFINE_KEY_MAP(aContext, KEY_VOLUP);
  DEFINE_KEY_MAP(aContext, KEY_4);
  DEFINE_KEY_MAP(aContext, KEY_5);
  DEFINE_KEY_MAP(aContext, KEY_6);
  DEFINE_KEY_MAP(aContext, KEY_VOLDOWN);
  DEFINE_KEY_MAP(aContext, KEY_7);
  DEFINE_KEY_MAP(aContext, KEY_8);
  DEFINE_KEY_MAP(aContext, KEY_9);
  DEFINE_KEY_MAP(aContext, KEY_MUTE);
  DEFINE_KEY_MAP(aContext, KEY_CHDOWN);
  DEFINE_KEY_MAP(aContext, KEY_0);
  DEFINE_KEY_MAP(aContext, KEY_CHUP);
  DEFINE_KEY_MAP(aContext, KEY_PRECH);
  DEFINE_KEY_MAP(aContext, KEY_GREEN);
  DEFINE_KEY_MAP(aContext, KEY_YELLOW);
  DEFINE_KEY_MAP(aContext, KEY_CYAN);
  DEFINE_KEY_MAP(aContext, KEY_BLUE);
  DEFINE_KEY_MAP(aContext, KEY_STEP);
  DEFINE_KEY_MAP(aContext, KEY_DEL);
  DEFINE_KEY_MAP(aContext, KEY_ADDDEL);
  DEFINE_KEY_MAP(aContext, KEY_SOURCE);
  DEFINE_KEY_MAP(aContext, KEY_TV);
  DEFINE_KEY_MAP(aContext, KEY_AUTO);
  DEFINE_KEY_MAP(aContext, KEY_MOIP);
  DEFINE_KEY_MAP(aContext, KEY_PMENU);
  DEFINE_KEY_MAP(aContext, KEY_INFO);
  DEFINE_KEY_MAP(aContext, KEY_PIP_ONOFF);
  DEFINE_KEY_MAP(aContext, KEY_PIP_SWAP);
  DEFINE_KEY_MAP(aContext, KEY_PIP_ROTATE);
  DEFINE_KEY_MAP(aContext, KEY_PLUS100);
  DEFINE_KEY_MAP(aContext, KEY_PIP_INPUT);
  DEFINE_KEY_MAP(aContext, KEY_CAPTION);
  DEFINE_KEY_MAP(aContext, KEY_PIP_STILL);
  DEFINE_KEY_MAP(aContext, KEY_AD);
  DEFINE_KEY_MAP(aContext, KEY_PMODE);
  DEFINE_KEY_MAP(aContext, KEY_SOUND_MODE);
  DEFINE_KEY_MAP(aContext, KEY_NR);
  DEFINE_KEY_MAP(aContext, KEY_SMODE);
  DEFINE_KEY_MAP(aContext, KEY_TTX_MIX);
  DEFINE_KEY_MAP(aContext, KEY_EXIT); /* Should exit be exposed?? */
  DEFINE_KEY_MAP(aContext, KEY_ENTER);
  DEFINE_KEY_MAP(aContext, KEY_PIP_SIZE);
  DEFINE_KEY_MAP(aContext, KEY_MAGIC_CHANNEL);
  DEFINE_KEY_MAP(aContext, KEY_PIP_SCAN);
  DEFINE_KEY_MAP(aContext, KEY_PIP_CHUP);
  DEFINE_KEY_MAP(aContext, KEY_PIP_CHDOWN);
  DEFINE_KEY_MAP(aContext, KEY_DEVICE_CONNECT);
  DEFINE_KEY_MAP(aContext, KEY_HELP);
  DEFINE_KEY_MAP(aContext, KEY_ANTENA);
  DEFINE_KEY_MAP(aContext, KEY_CONVERGENCE);
  DEFINE_KEY_MAP(aContext, KEY_11);
  DEFINE_KEY_MAP(aContext, KEY_12);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_PROGRAM);
  DEFINE_KEY_MAP(aContext, KEY_FACTORY);
  DEFINE_KEY_MAP(aContext, KEY_3SPEED);
  DEFINE_KEY_MAP(aContext, KEY_SCROLL_UP);
  DEFINE_KEY_MAP(aContext, KEY_ASPECT);
  DEFINE_KEY_MAP(aContext, KEY_EMANUAL);
  DEFINE_KEY_MAP(aContext, KEY_GAME);
  DEFINE_KEY_MAP(aContext, KEY_SCROLL_RIGHT);
  DEFINE_KEY_MAP(aContext, KEY_STILL_PICTURE);
  DEFINE_KEY_MAP(aContext, KEY_DTV);
  DEFINE_KEY_MAP(aContext, KEY_FAVCH);
  DEFINE_KEY_MAP(aContext, KEY_REWIND);
  DEFINE_KEY_MAP(aContext, KEY_STOP);
  DEFINE_KEY_MAP(aContext, KEY_PLAY);
  DEFINE_KEY_MAP(aContext, KEY_FF);
  DEFINE_KEY_MAP(aContext, KEY_REC);
  DEFINE_KEY_MAP(aContext, KEY_PAUSE);
  DEFINE_KEY_MAP(aContext, KEY_TOOLS);
  DEFINE_KEY_MAP(aContext, KEY_SCROLL_LEFT);
  DEFINE_KEY_MAP(aContext, KEY_LINK);
  DEFINE_KEY_MAP(aContext, KEY_FF_);
  DEFINE_KEY_MAP(aContext, KEY_GUIDE);
  DEFINE_KEY_MAP(aContext, KEY_REWIND_);
  DEFINE_KEY_MAP(aContext, KEY_ANGLE);
  DEFINE_KEY_MAP(aContext, KEY_RESERVED1);
  DEFINE_KEY_MAP(aContext, KEY_ZOOM1);
  DEFINE_KEY_MAP(aContext, KEY_PROGRAM);
  DEFINE_KEY_MAP(aContext, KEY_BOOKMARK);
  DEFINE_KEY_MAP(aContext, KEY_DISC_MENU);
  DEFINE_KEY_MAP(aContext, KEY_SCROLL_DOWN);
  DEFINE_KEY_MAP(aContext, KEY_RETURN);
  DEFINE_KEY_MAP(aContext, KEY_SUB_TITLE);
  DEFINE_KEY_MAP(aContext, KEY_CLEAR);
  DEFINE_KEY_MAP(aContext, KEY_VCHIP);
  DEFINE_KEY_MAP(aContext, KEY_REPEAT);
  DEFINE_KEY_MAP(aContext, KEY_DOOR);
  DEFINE_KEY_MAP(aContext, KEY_OPEN);
  DEFINE_KEY_MAP(aContext, KEY_WHEEL_LEFT);
  DEFINE_KEY_MAP(aContext, KEY_POWER);
  DEFINE_KEY_MAP(aContext, KEY_SLEEP);
  DEFINE_KEY_MAP(aContext, KEY_2);
  DEFINE_KEY_MAP(aContext, KEY_DMA);
  DEFINE_KEY_MAP(aContext, KEY_TURBO);
  DEFINE_KEY_MAP(aContext, KEY_1);
  DEFINE_KEY_MAP(aContext, KEY_FM_RADIO);
  DEFINE_KEY_MAP(aContext, KEY_DVR_MENU);
  DEFINE_KEY_MAP(aContext, KEY_MTS);
  DEFINE_KEY_MAP(aContext, KEY_PCMODE);
  DEFINE_KEY_MAP(aContext, KEY_TTX_SUBFACE);
  DEFINE_KEY_MAP(aContext, KEY_CH_LIST);
  DEFINE_KEY_MAP(aContext, KEY_RED);
  DEFINE_KEY_MAP(aContext, KEY_DNIe);
  DEFINE_KEY_MAP(aContext, KEY_SRS);
  DEFINE_KEY_MAP(aContext, KEY_CONVERT_AUDIO_MAINSUB);
  DEFINE_KEY_MAP(aContext, KEY_MDC);
  DEFINE_KEY_MAP(aContext, KEY_SEFFECT);
  DEFINE_KEY_MAP(aContext, KEY_DVR);
  DEFINE_KEY_MAP(aContext, KEY_DTV_SIGNAL);
  DEFINE_KEY_MAP(aContext, KEY_LIVE);
  DEFINE_KEY_MAP(aContext, KEY_PERPECT_FOCUS);
  DEFINE_KEY_MAP(aContext, KEY_HOME);
  DEFINE_KEY_MAP(aContext, KEY_ESAVING);
  DEFINE_KEY_MAP(aContext, KEY_WHEEL_RIGHT);
  DEFINE_KEY_MAP(aContext, KEY_CONTENTS);
  DEFINE_KEY_MAP(aContext, KEY_VCR_MODE);
  DEFINE_KEY_MAP(aContext, KEY_CATV_MODE);
  DEFINE_KEY_MAP(aContext, KEY_DSS_MODE);
  DEFINE_KEY_MAP(aContext, KEY_TV_MODE);
  DEFINE_KEY_MAP(aContext, KEY_DVD_MODE);
  DEFINE_KEY_MAP(aContext, KEY_STB_MODE);
  DEFINE_KEY_MAP(aContext, KEY_CALLER_ID);
  DEFINE_KEY_MAP(aContext, KEY_SCALE);
  DEFINE_KEY_MAP(aContext, KEY_ZOOM_MOVE);
  DEFINE_KEY_MAP(aContext, KEY_CLOCK_DISPLAY);
  DEFINE_KEY_MAP(aContext, KEY_AV1);
  DEFINE_KEY_MAP(aContext, KEY_SVIDEO1);
  DEFINE_KEY_MAP(aContext, KEY_COMPONENT1);
  DEFINE_KEY_MAP(aContext, KEY_SETUP_CLOCK_TIMER);
  DEFINE_KEY_MAP(aContext, KEY_COMPONENT2);
  DEFINE_KEY_MAP(aContext, KEY_MAGIC_BRIGHT);
  DEFINE_KEY_MAP(aContext, KEY_DVI);
  DEFINE_KEY_MAP(aContext, KEY_HDMI);
  DEFINE_KEY_MAP(aContext, KEY_W_LINK);
  DEFINE_KEY_MAP(aContext, KEY_DTV_LINK);
  DEFINE_KEY_MAP(aContext, KEY_RESERVED5);
  DEFINE_KEY_MAP(aContext, KEY_APP_LIST);
  DEFINE_KEY_MAP(aContext, KEY_BACK_MHP);
  DEFINE_KEY_MAP(aContext, KEY_ALT_MHP);
  DEFINE_KEY_MAP(aContext, KEY_DNSe);
  DEFINE_KEY_MAP(aContext, KEY_RSS);
  DEFINE_KEY_MAP(aContext, KEY_ENTERTAINMENT);
  DEFINE_KEY_MAP(aContext, KEY_ID_INPUT);
  DEFINE_KEY_MAP(aContext, KEY_ID_SETUP);
  DEFINE_KEY_MAP(aContext, KEY_ANYNET);
  DEFINE_KEY_MAP(aContext, KEY_POWEROFF);
  DEFINE_KEY_MAP(aContext, KEY_POWERON);
  DEFINE_KEY_MAP(aContext, KEY_ANYVIEW);
  DEFINE_KEY_MAP(aContext, KEY_MS);
  DEFINE_KEY_MAP(aContext, KEY_MORE);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_POWER);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_CHUP);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_CHDOWN);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_VOLUP);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_VOLDOWN);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_ENTER);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_MENU);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_SOURCE);
  DEFINE_KEY_MAP(aContext, KEY_AV2);
  DEFINE_KEY_MAP(aContext, KEY_AV3);
  DEFINE_KEY_MAP(aContext, KEY_SVIDEO2);
  DEFINE_KEY_MAP(aContext, KEY_SVIDEO3);
  DEFINE_KEY_MAP(aContext, KEY_ZOOM2);
  DEFINE_KEY_MAP(aContext, KEY_PANORAMA);
  DEFINE_KEY_MAP(aContext, KEY_4_3);
  DEFINE_KEY_MAP(aContext, KEY_16_9);
  DEFINE_KEY_MAP(aContext, KEY_DYNAMIC);
  DEFINE_KEY_MAP(aContext, KEY_STANDARD);
  DEFINE_KEY_MAP(aContext, KEY_MOVIE1);
  DEFINE_KEY_MAP(aContext, KEY_CUSTOM);
  DEFINE_KEY_MAP(aContext, KEY_TILT);
  DEFINE_KEY_MAP(aContext, KEY_EZ_VIEW);
  DEFINE_KEY_MAP(aContext, KEY_3D);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_RESET);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_LNA_ON);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_LNA_OFF);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_ANYNET_MODE_OK);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_ANYNET_AUTO_START);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_FORMAT);
  DEFINE_KEY_MAP(aContext, KEY_DNET);
  DEFINE_KEY_MAP(aContext, KEY_HDMI1);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_CAPTION_ON);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_CAPTION_OFF);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_DOUBLE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_LARGE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_SMALL);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_WIDE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_LEFT_TOP);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_RIGHT_TOP);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_LEFT_BOTTOM);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_RIGHT_BOTTOM);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_CH_CHANGE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_AUTOCOLOR_SUCCESS);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_AUTOCOLOR_FAIL);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_C_FORCE_AGING);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_USBJACK_INSPECT);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_JACK_IDENT);

  DEFINE_KEY_MAP(aContext, KEY_NINE_SEPERATE);
  DEFINE_KEY_MAP(aContext, KEY_ZOOM_IN);
  DEFINE_KEY_MAP(aContext, KEY_ZOOM_OUT);
  DEFINE_KEY_MAP(aContext, KEY_MIC);

  DEFINE_KEY_MAP(aContext, KEY_HDMI2);
  DEFINE_KEY_MAP(aContext, KEY_HDMI3);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_CAPTION_KOR);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_CAPTION_ENG);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_SOURCE_CHANGE);

  DEFINE_KEY_MAP(aContext, KEY_HDMI4);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_ANTENNA_AIR);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_ANTENNA_CABLE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_ANTENNA_SATELLITE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_CIP_TEST);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_CH_CHANGE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_START_MBR_TEST);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PVR_RECORDING_TEST);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PVR_PLAY_TEST);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PVR_DELETE_ALL);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_HOTEL_INTERACTIVE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIC_SND_TEST_START);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIC_SND_TEST_END);

  DEFINE_KEY_MAP(aContext, KEY_PICTURE_HIDE);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_CH_CHANGE_2ND_TUNER);

  DEFINE_KEY_MAP(aContext, KEY_PANNEL_FUNCTION);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_REMOTE_POWER);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_MUTE);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_HOLD);
  DEFINE_KEY_MAP(aContext, KEY_PANNEL_PIP);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_AUTOCOLOR_VIDEO);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_AUTOCOLOR_PC);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_AUTOCOLOR_COMP);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_COLOR_WHEEL_INDEX);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_EEPROM_COPY);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_TIME_CLEAR);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PLAY_INTERNAL_TEST_PATTERN);

  DEFINE_KEY_MAP(aContext, KEY_TV_SNS);
  DEFINE_KEY_MAP(aContext, KEY_SEARCH);

  DEFINE_KEY_MAP(aContext, KEY_DOTCOM);

  DEFINE_KEY_MAP(aContext, KEY_BS);
  DEFINE_KEY_MAP(aContext, KEY_CS);

  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_SOUND_CHANGE_MAIN);
  DEFINE_KEY_MAP(aContext, KEY_AUTO_ARC_PIP_SOUND_CHANGE_SUB);

  DEFINE_KEY_MAP(aContext, KEY_BT_CONTENTSBAR);
  DEFINE_KEY_MAP(aContext, KEY_BT_NUMBER);
  DEFINE_KEY_MAP(aContext, KEY_BT_HOTKEY);
  DEFINE_KEY_MAP(aContext, KEY_BT_DEVICE);
  DEFINE_KEY_MAP(aContext, KEY_BT_TRIGGER);
  DEFINE_KEY_MAP(aContext, KEY_BT_VOICE);
  DEFINE_KEY_MAP(aContext, KEY_FAMILYHUB);
  DEFINE_KEY_MAP(aContext, KEY_CAMERA);
  DEFINE_KEY_MAP(aContext, KEY_BT_COLOR_MECHA);

  DEFINE_KEY_MAP(aContext, KEY_MBR_SETUP);
  DEFINE_KEY_MAP(aContext, KEY_MBR_WATCH_TV);
  DEFINE_KEY_MAP(aContext, KEY_MBR_WATCH_MOVIE);
  DEFINE_KEY_MAP(aContext, KEY_MBR_SETUP_CONFIRM);

  DEFINE_KEY_MAP(aContext, KEY_USBHUB_SWITCH);
  DEFINE_KEY_MAP(aContext, KEY_MBR_SETUP_FAILURE);

  DEFINE_KEY_MAP(aContext, KEY_BT_ALLSHARE);
  DEFINE_KEY_MAP(aContext, KEY_BT_SAMSUNG_APPS);

  DEFINE_KEY_MAP(aContext, KEY_HOTEL_LANGUAGE);
  DEFINE_KEY_MAP(aContext, KEY_HOTEL_ROOMCONTROL);
  DEFINE_KEY_MAP(aContext, KEY_HOTEL_TVGUIDE);
  DEFINE_KEY_MAP(aContext, KEY_HOTEL_MOVIES);

  DEFINE_KEY_MAP(aContext, KEY_BT_DUALVIEW);

  DEFINE_KEY_MAP(aContext, KEY_PAGE_LEFT);
  DEFINE_KEY_MAP(aContext, KEY_PAGE_RIGHT);
  DEFINE_KEY_MAP(aContext, KEY_SOCCER_MODE);
  DEFINE_KEY_MAP(aContext, KEY_STB_POWER);
  DEFINE_KEY_MAP(aContext, KEY_WIFI_PAIRING);

  DEFINE_KEY_MAP(aContext, KEY_MBR_BDDVD_POWER);
  DEFINE_KEY_MAP(aContext, KEY_MBR_STBBD_MENU);
  DEFINE_KEY_MAP(aContext, KEY_MBR_BD_POPUP);
  DEFINE_KEY_MAP(aContext, KEY_MBR_TV);
  DEFINE_KEY_MAP(aContext, KEY_MBR_STB_GUIDE);
  DEFINE_KEY_MAP(aContext, KEY_RECOMMEND_SEARCH_TOGGLE);
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_NETFLIX);
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_AMAZON);
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_SCHEDULEMANAGER);
  DEFINE_KEY_MAP(aContext, KEY_FUNCTIONS_4DIVISION_VIEW);
  DEFINE_KEY_MAP(aContext, KEY_TURN);

  DEFINE_KEY_MAP(aContext, MOUSE_FLICK_LEFT);
  DEFINE_KEY_MAP(aContext, MOUSE_FLICK_RIGHT);
  DEFINE_KEY_MAP(aContext, MOUSE_FLICK_UP);
  DEFINE_KEY_MAP(aContext, MOUSE_FLICK_DOWN);

  DEFINE_KEY_MAP(aContext, ON_LOAD);
  DEFINE_KEY_MAP(aContext, ON_SHOW);
  DEFINE_KEY_MAP(aContext, ON_PAUSE);
  DEFINE_KEY_MAP(aContext, ON_RESUME);
  DEFINE_KEY_MAP(aContext, ON_HIDE);
  DEFINE_KEY_MAP(aContext, ON_UNLOAD);
  DEFINE_KEY_MAP(aContext, ON_RESET);
  DEFINE_KEY_MAP(aContext, ON_ACTIVATE);
  DEFINE_KEY_MAP(aContext, ON_DEACTIVATE);
  DEFINE_KEY_MAP(aContext, ON_SUSPEND);
  DEFINE_KEY_MAP(aContext, ON_FACTORY_RESET);
  DEFINE_KEY_MAP(aContext, ON_SERVICE_RESET);
  DEFINE_KEY_MAP(aContext, ON_WAKEUP);
  DEFINE_KEY_MAP(aContext, ON_RESIZE);
  DEFINE_KEY_MAP(aContext, ON_CURSOR_HIDE);
  DEFINE_KEY_MAP(aContext, ON_APP_LAUNCH);  

  DEFINE_KEY_MAP(aContext, ON_MESSAGE);
  DEFINE_KEY_MAP(aContext, ON_COMMAND);
}

void* VoltDefaultBridge::constructFromScript(const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Just using self...");

  return this;
}

ScriptObject VoltDefaultBridge::HandleExit(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
	VDLowerXWindow(runtime->GetMainStage());

  return ScriptObject(true);
}


ScriptObject VoltDefaultBridge::HandleQuit(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  VoltFullProcessRuntime *runtime =
    static_cast<VoltFullProcessRuntime *>(VoltProcessManager::Instance().Runtime().get());
  runtime->SetReturnToPrevApp(true);
  runtime->Quit();
  volt::util::Capture();
  return ScriptObject(true);
}

ScriptObject VoltDefaultBridge::HandleHide(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  GetXWindowManager()->HideWindow();
  return ScriptObject(true);
}

ScriptObject VoltDefaultBridge::HandleLoad(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  bool retval = false;

  do
  {
    std::string source = aArgs[0].asString();
    LOG_DEBUG(LOGGER, "Run script source: " << source);

    try
    {
      static const bool is_script_literal = true;
      static const bool is_main = false;
      static const bool refresh_event_callback = true;
      aSelf->js_engine_->loadScript(source, is_script_literal, is_main,
                                    refresh_event_callback);
    }
    catch(VoltJsInitException& e)
    {
      LOG_WARN(LOGGER, e.what());
      break;
    }

    retval = true;

  }
  while(0);

  return ScriptObject(retval);
}


ScriptObject VoltDefaultBridge::HandleRequireNoContext(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  bool retval = false;
  ScriptObject retObj;

  do
  {
    std::string source = aArgs[0].asString();
    LOG_DEBUG(LOGGER, "Run requireNoContext with js file source: " << source);

    try
    {
      retObj = aSelf->js_engine_->requireNoContext(source);
    }
    catch(VoltJsInitException& e)
    {
      LOG_WARN(LOGGER, e.what());
      break;
    }

    retval = true;

  }
  while(0);

  if(retval)
  {
    return retObj;
  }
  else
  {
    return ScriptObject(retval);
  }
}
ScriptObject VoltDefaultBridge::HandleLoadFile(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  bool retval = false;

  do
  {
    std::string source = aArgs[0].asString();
    LOG_DEBUG(LOGGER, "Run script source: " << source);

    try
    {
      static const bool is_script_literal = false;
      static const bool is_main = false;
      static const bool refresh_event_callback = true;
      aSelf->js_engine_->loadScript(source, is_script_literal, is_main,
                                    refresh_event_callback);
    }
    catch(VoltJsInitException& e)
    {
      LOG_WARN(LOGGER, e.what());
      break;
    }

    retval = true;

  }
  while(0);

  return ScriptObject(retval);
}

ScriptObject VoltDefaultBridge::HandleLoadApp(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  bool retval = false;

  do
  {
    LOG_DEBUG(LOGGER, "Loading app: " << aArgs[0].asString());

    std::string app_js = aArgs[0].asString();

    IORequest::SharedPtr request(ResourceManager::CreateRequest(app_js));

    if (ResourceManager::Instance().Process(request) == false)
    {
      /* Probably a directory; retry with app.js */
      app_js += "/" + AppConfig::Instance().GetValue<std::string>("default-app-js");
      request->set_uri(app_js);

      if (ResourceManager::Instance().Process(request) == false)
      {
        LOG_WARN(LOGGER, "Failed to read app: " << app_js);
        break;
      }
    }

    if (request->response()->source() == Resource::IOResponse::SOURCE_FILE)
    {
      const Resource::FileIORequest::SharedPtr file_request =
        boost::static_pointer_cast<Resource::FileIORequest>(request);

      /* Update the "app root path" for local apps so the ResourceRequest can
       * find files relative to it.
       * Apps hosted remote must fetch its resource using HTTP! */

      /* Directly get the path instead of using request->uri().
       * If the request was successful, then the path must be
       * accessible/valid (eg in the app root path). */
      std::string new_root = file_request->path();

      size_t slash = new_root.find_last_of("/");

      if (slash != std::string::npos)
      {
        new_root = new_root.substr(0, slash);
      }

      /* else what to do? */

      LOG_DEBUG(LOGGER, "Updating the app root path to " << new_root);
      AppConfig::Instance().UpdateAppRootPath(new_root);
    }

    TextWidget::setDefaultAppFont(""); /* reset */

    try
    {
      static const bool is_main = true;
      static const bool refresh_event_callback = true;

      aSelf->js_engine_->loadScript(request->response()->data(),
                                    "", is_main,
                                    refresh_event_callback);
    }
    catch(VoltJsInitException& e)
    {
      LOG_WARN(LOGGER, e.what());
      break;
    }

    retval = true;

  }
  while(0);

  return ScriptObject(retval);
}

ScriptObject VoltDefaultBridge::HandleGetWidgetById(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  ScriptObject idObj;
  return wrapExistingNativeObject(Widget::getWidgetByID(aArgs.get(0).asString()));
}

ScriptObject VoltDefaultBridge::HandleSetTimeout(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Setting a timeout");
  return aSelf->SetTimer(aArgs, false); /* no repeat */
}

ScriptObject VoltDefaultBridge::HandleClearTimeout(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  return HandleClearTimer(aSelf, aArgs);
}

ScriptObject VoltDefaultBridge::HandleSetInterval(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Setting an interval");
  return aSelf->SetTimer(aArgs, true); /* repeat */
}

ScriptObject VoltDefaultBridge::HandleClearInterval(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  return HandleClearTimer(aSelf, aArgs);
}

ScriptObject VoltDefaultBridge::HandleClearTimer(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Clearing a timer");

  do
  {
    if (aArgs.Length() != 1)
    {
      LOG_WARN(LOGGER,
               "Expected at exactly 1 argument; " <<
               aArgs.Length() << " given...");
      break;
    }

    unsigned int id = static_cast<unsigned int>(aArgs[0].asNumber());

    auto iter = aSelf->timers_.find(id);

    if (iter == aSelf->timers_.end())
    {
      LOG_WARN(LOGGER, "Failed to find timer: " << id);
      break;
    }

    LOG_DEBUG(LOGGER, "Clearing timer: " << id);
    iter->second->set_valid(false);

    return ScriptObject(true);
  }
  while(0);

  LOG_WARN(LOGGER, "Failed to clear a timer");
  return ScriptObject(false);
}

ScriptObject VoltDefaultBridge::HandleSetDefaultFont(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  bool retval = false;

  do
  {
    TextWidget::setDefaultAppFont(aArgs[0].asString());

    retval = true;

  }
  while(0);

  return ScriptObject(retval);
}

ScriptObject VoltDefaultBridge::HandleGetAbsolutePath(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  std::string retval;

  do
  {
    if (FileIORequest::NormalizePath(aArgs[0].asString(),
                                     retval) == PERM_NO_ACCESS)
    {
      retval.clear();
    }

  }
  while(0);

  return ScriptObject(retval);
}

ScriptObject VoltDefaultBridge::SetTimer(const ScriptArray &aArgs,
    const bool aRepeat)
{
  LOG_DEBUG(LOGGER, "Setting a timer");

  do
  {
    if (aArgs.Length() < 2 || !aArgs[0].isFunction() || !aArgs[1].isNumber())
    {
      LOG_WARN(LOGGER,
               "Expected at least 2 arguments; " <<
               aArgs.Length() << " given...");
      break;
    }

    TimerInfo::SharedPtr timer_info(new TimerInfo(this));

    double delay = aArgs[1].asNumber();
    unsigned int id = clutter_threads_add_timeout_full(G_PRIORITY_HIGH, delay,
                      HandleTimer, timer_info.get(),
                      NULL);
    timer_info->set_id(id);
    timer_info->set_repeat(aRepeat);
    timer_info->set_callback(aArgs[0].asFunction());

    for (unsigned int index = 2; index < aArgs.Length(); ++index)
    {
      timer_info->callback_args().set(index - 2, aArgs[index]);
    }

    timers_.insert(std::pair<unsigned int, TimerInfo::SharedPtr>(id, timer_info));

    return ScriptObject((int) id);
  }
  while(0);

  LOG_WARN(LOGGER, "Failed to set a timer");
  return ScriptObject(-1);
}

gboolean VoltDefaultBridge::HandleTimer(gpointer aData)
{
  VoltDefaultBridge *bridge = reinterpret_cast<TimerInfo *>(aData)->bridge();
  unsigned int id = reinterpret_cast<TimerInfo *>(aData)->id();

  return bridge->HandleTimer(id) ? TRUE : FALSE;
}

bool VoltDefaultBridge::HandleTimer(const unsigned int aId)
{
  auto iter = timers_.find(aId);

  if (iter == timers_.end())
  {
    LOG_WARN(LOGGER, "Failed to find timer: " << aId);
    return false;
  }

  bool repeat = iter->second->repeat();

  if (iter->second->valid())
  {
    LOG_DEBUG(LOGGER, "Handling timer: " << aId);

    ScriptObject retval;

    try
    {
      retval = iter->second->callback().invoke(iter->second->callback_args());
    }
    catch (VoltJsRuntimeException &e)
    {
      volt::StaticUI::Instance().ShowExceptionPopup("Failed to execute timer "
          "callback", &e);
    }

    if (retval.isBool())
    {
      repeat = retval.asBool();
    }
  }
  else
  {
    LOG_DEBUG(LOGGER, "Invalid timer (most likely cleared): " << aId);
    repeat = false;
  }

  if (repeat == false)
  {
    LOG_DEBUG(LOGGER, "Non-repeating/invalid timer: " << aId);
    timers_.erase(iter);
  }

  return repeat;
}


ScriptObject VoltDefaultBridge::HandleConfigureColorPicking(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  static const std::vector<std::string> CP_KEYS = ImageWidget::getColorPickOptionKeys();
 
  ScriptObject ret;
  std::map<std::string,int> argMap; //to pass to ImageWidget
  if(aArgs.Length())
  {
    ScriptObject options = aArgs[0];

    for(auto i : CP_KEYS)
    {
      if(options.has(i) and options.get(i).isNumber())
      {
	argMap[i] = options.get(i).asNumber();
      }
    }
  }

  ImageWidget::ConfigureColorPicking(argMap);
  std::map<std::string,int> currentOptions =  ImageWidget::colorPickOptions;

  //get current values for return val.
  for(auto i : CP_KEYS)
  {
    ret.set(i,currentOptions[i]);
  }
 
  return ScriptObject(ret);
}

ScriptObject VoltDefaultBridge::HandleAddEventListener(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  unsigned int eventID = aArgs[0].asNumber();
  uint length = aArgs.Length();
  bool hasCallback = false;
  ScriptFunction listener;

  if(length >= 2)
  {
    if(not aArgs[1].isUndefined() and not aArgs[1].isNull())
    {
      listener = aArgs[1].asFunction();
      hasCallback = true;
    }
  }

  LOG_DEBUG(LOGGER, "adding event handler for ID " << eventID);

  // register key
  if(IsVoltKeyEvent(eventID))
  {
    // check if the key is supported be proceeding
    if(not AddKey(eventID))
    {
      LOG_DEBUG(LOGGER, "key is not mapped to a supported key, skipping");
      return ScriptObject();
    }
  }

  if(hasCallback)
  {
    aSelf->js_engine_->registerEvent(eventID, listener);
  }

  return ScriptObject();
}


ScriptObject VoltDefaultBridge::HandleRemoveEventListener(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  unsigned int eventID = aArgs[0].asNumber();
  uint length = aArgs.Length();
  bool hasCallback = false;
  ScriptFunction listener;

  if(length >= 2)
  {
    if(not aArgs[1].isUndefined() and not aArgs[1].isNull())
    {
      listener = aArgs[1].asFunction();
      hasCallback = true;
    }
  }

  // register key
  if(IsVoltKeyEvent(eventID))
  {
    LOG_DEBUG(LOGGER, "removing key handler" << eventID);

    if(not RemoveKey(eventID))
    {
      LOG_DEBUG(LOGGER, "key is not mapped to a supported key, skipping");
      return ScriptObject();
    }
  }

  if(hasCallback)
  {
    aSelf->js_engine_->unregisterEvent(eventID, listener);
  }

  return ScriptObject();
}

ScriptObject VoltDefaultBridge::HandleDispatchEvent(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  unsigned int eventID = aArgs[0].asNumber();

  volt::util::EVENT_TYPE buttonPressType = volt::util::EVENT_KEY_PRESS;

  if (aArgs.has(1))
  {
    if (aArgs[1].has("type"))
    {
      buttonPressType = (volt::util::EVENT_TYPE) aArgs[1]["type"].asNumber();
    }
  }

  aSelf->js_engine_->sendKeyEvent(eventID, buttonPressType);
  return ScriptObject();
}

ScriptObject VoltDefaultBridge::HandlePostMessage(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  if ((VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS) == 0)
  {
    std::string msg = aArgs[0].asString();

    std::string parent_id = VoltMessageCenter::Instance().ParentProcessID();
    VoltMessageCenter::Instance().PostMsgToWorker(parent_id,
        VoltRuntimeMsg::WorkerMessage(),
        const_cast<char *>(msg.c_str()), msg.length() + 1);
  }

  return ScriptObject();
}

ScriptObject VoltDefaultBridge::HandleExecCommand(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  if ((VoltProcessManager::Instance().ProcessType() & VoltProcessManager::ROOT_PROCESS) == 0)
  {
    std::string cmd = aArgs[0].asString();

    std::vector<std::string> results;

    std::string parent_id = VoltMessageCenter::Instance().ParentProcessID();
    VoltMessageCenter::Instance().ExecuteOnWorker(parent_id,
        VoltRuntimeMsg::WorkerCommand(),
        [&] (void *aData, const size_t aSize)
    {
      /* The result data MUST be
       * of type vector<string> */
      Unserialize(results,
                  static_cast<char *>(aData),
                  aSize);
    },
    const_cast<char *>(cmd.c_str()), cmd.length() + 1);

    /* The last element of the vector is a flag for execution result.
     *   "0" == success, "1" == failure */
    if (results.size() > 0 && results[results.size() - 1] == "0")
    {
      LOG_DEBUG(LOGGER, "Got result from worker: " + results.front());
      return ScriptObject(results.front());
    }
  }

  return ScriptObject::Null();
}

ScriptObject VoltDefaultBridge::HandleGetVersion(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  ScriptObject obj;
  obj.set("string", ScriptObject(std::string(VOLT_VERSION)));
  obj.set("major", ScriptObject(VOLT_VERSION_MAJOR));
  obj.set("minor", ScriptObject(VOLT_VERSION_MINOR));
  obj.set("patch", ScriptObject(VOLT_VERSION_PATCH));
  return obj;
}

ScriptObject VoltDefaultBridge::HandleIsRightToLeft(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  return ScriptObject(volt_get_is_right_to_left(aArgs[0].asString().c_str()));
}

ScriptObject VoltDefaultBridge::HandleGetHighContrastMode(VoltDefaultBridge *aSelf,
    const ScriptArray &aArgs)
{
  Widget::HighContrastMode mode = Widget::getHighContrastMode();

  switch (mode)
  {
  default:
  case Widget::HighContrastMode::OFF:
    return ScriptObject("off");
    break;
  case Widget::HighContrastMode::BLACK_ON_WHITE:
    return ScriptObject("black-on-white");
    break;
  case Widget::HighContrastMode::WHITE_ON_BLACK:
    return ScriptObject("white-on-black");
    break;
  }

  return ScriptObject("off");
}

ScriptObject VoltDefaultBridge::HandleDumpJavaScriptHeapSnapshot(VoltDefaultBridge *aSelf,
                                                                 const ScriptArray &aArgs)
{
  std::ostringstream path_stream;
  if (aArgs.Length() > 0)
  {
    /* Dump to the path supplied by the JavaScript. */
    path_stream << aArgs[0].asString();
  }
  else
  {
    /* Dump to default path. */

    struct timeval tv;
    gettimeofday(&tv, NULL);

    char path[1024];
    snprintf(path, sizeof(path) / sizeof(path[0]),
             "%s/%ld-%ld.heapsnapshot",
             AppConfig::Instance().GetAppDataPath().c_str(),
             tv.tv_sec, tv.tv_usec);

    path_stream << AppConfig::Instance().GetAppDataPath() << "/"
                << tv.tv_sec << "." << tv.tv_usec << ".heapsnapshot";
  }

  LOG_DEBUG(LOGGER, "Dumping heapsnapshot to " << path_stream.str());
  return ScriptObject(aSelf->js_engine_->dumpHeapSnapshot(path_stream.str()));
}

/******************************************************************************
 * VoltDefaultBridge::TimerInfo
 *****************************************************************************/

VoltDefaultBridge::TimerInfo::TimerInfo(VoltDefaultBridge *aBridge):
  bridge_(aBridge), id_(0), valid_(true), callback_(), repeat_(false)
{
  LOG_DEBUG(LOGGER, "Born...");
}

VoltDefaultBridge::TimerInfo::~TimerInfo()
{
  // When timer is destroyed we must remove this source from the callback list in
  // glib.  This fixes a crash discovered by china lab when volt is quit with
  // a timeout in progress and then relaunched.
  if (id_)
  {
    g_source_remove(id_);
    id_ = 0;
  }

  LOG_DEBUG(LOGGER, "Dead " << id());
}


