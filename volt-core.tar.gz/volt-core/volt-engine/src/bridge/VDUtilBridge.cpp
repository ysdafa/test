/*
* VconfBridge.cpp
*
*  Created on: May 20, 2013
*      Author: ytakebuchi
*/

#include "VDUtilBridge.h"

#include <v8/v8.h>
#include <v8/v8-profiler.h>
#include <boost/config.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/lexical_cast.hpp>
#include <clutter/clutter.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <stdlib.h>

#include "AppConfig.h"
#include "Exception.h"
#include "vconf.h"
#include "clutter_helper.h"
#include "system_info.h"
#include <clutter/x11/clutter-x11.h>
#include <streamline/streamline_annotate.h>
#include <KeyEvent.h>
#include <fcntl.h> 
#include <TVServiceAPI.h>
#include <tv_context.h>
#include <sys/prctl.h>
#include <haptic.h>
#include <AppControlAPI.h>

#ifndef PR_TASK_PERF_USER_TRACE
#define PR_TASK_PERF_USER_TRACE 666
#endif
extern void* GetMainStage();

using namespace v8;
using namespace Bridge;
using namespace volt::util;
using namespace std;

KeyEventRepository repository;

class FileOutputStream : public OutputStream {
 public:
  FileOutputStream(FILE* stream) : stream_(stream) {}

  virtual int GetChunkSize() {
    return 65536;  // big chunks == faster
  }

  virtual void EndOfStream() {}

  virtual WriteResult WriteAsciiChunk(char* data, int size) {
    const size_t len = static_cast<size_t>(size);
    size_t off = 0;

    while (off < len && !feof(stream_) && !ferror(stream_))
      off += fwrite(data + off, 1, len - off, stream_);

    return off == len ? kContinue : kAbort;
  }

 private:
  FILE* stream_;
};

std::string VDUtilBridge::LOGGER_NAME = "volt.vdutil.bridge";
volt::util::Logger VDUtilBridge::logger_(LOGGER_NAME);

VDUtilBridge::VDUtilBridge(): ScriptInstanceBridge(this)
{
}

VDUtilBridge::~VDUtilBridge()
{
}

void VDUtilBridge::mapScriptInterface(ScriptContext& aContext)
{
	LOG_DEBUG(logger_, "Mapping VoltUtil script interfaces");

	aContext.captureMethodCall<VDUtilBridge, &HandleVDSetTimeOfDay>("vd_settimeofday");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDGetTimeOfDay>("vd_gettimeofday");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDLocalTime>("vd_localtime");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDGetTimeZone>("vd_gettimezone");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetProcMemory>("getProcMemory");
	aContext.captureMethodCall<VDUtilBridge, &HandleFirstScreenReady>("firstScreenReady");
	aContext.captureMethodCall<VDUtilBridge, &HandleIsExistWASTempFile>("isExistWASTempFile");
	aContext.captureMethodCall<VDUtilBridge, &HandleHeapSnapShot>("heapSnapshot");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetXWindowID>("getXWindowID");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDAnnotate>("vd_annotate");
	aContext.captureMethodCall<VDUtilBridge, &HandleVDRaiseXWindow>("vd_raiseXWindow");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetMLSstate>("getMLSstate");
	aContext.captureMethodCall<VDUtilBridge, &HandleGetResolution>("getResolution");	
	aContext.captureMethodCall<VDUtilBridge, &HandleScreenCapture>("screenCapture");
	aContext.captureMethodCall<VDUtilBridge, &HandleChangeXPropertyNormal>("changeXPropertynormal");
	aContext.captureMethodCall<VDUtilBridge, &HandleRegisterKey>("registerKey");
	aContext.captureMethodCall<VDUtilBridge, &HandleUnRegisterKey>("unregisterKey");	
	//aContext.captureMethodCall<VDUtilBridge, &HandleIsDebugMode>("isDebugMode");	
	aContext.captureMethodCall<VDUtilBridge, &HandleGetAppId>("getAppId");	
	aContext.captureMethodCall<VDUtilBridge, &HandleGetWidgetId>("getWidgetId");	
	aContext.captureMethodCall<VDUtilBridge, &HandleExtractForegroundColor>("ExtractForegroundColor");	
	aContext.captureMethodCall<VDUtilBridge, &HandleGetMemfree>("GetMemfree");	
	aContext.captureMethodCall<VDUtilBridge, &HandleGetSourceInfo>("getSourceInfo");	
	aContext.captureMethodCall<VDUtilBridge, &HandleTvContextState>("tvContextState");
	aContext.captureMethodCall<VDUtilBridge, &HandleHapticInit>("hapticInit");
	aContext.captureMethodCall<VDUtilBridge, &HandleHapticSend>("hapticSend");	
	aContext.captureMethodCall<VDUtilBridge, &HandleAppControlInitDbusConnection>("AppControl_InitDbusConnection");	
	aContext.captureMethodCall<VDUtilBridge, &HandleAppControlDisableItem>("AppControl_DisableItem");	
	aContext.captureMethodCall<VDUtilBridge, &HandleAppControlRemoveDisabledItemsByAppname>("AppControl_RemoveDisabledItemsByAppname");	
	aContext.captureMethodCall<VDUtilBridge, &HandleAppControlFiniDbusConnection>("AppControl_FiniDbusConnection");	

}

void* VDUtilBridge::constructFromScript(const ScriptArray &aArgs)
{
	return this;
}

// int vd_settimeofday(long long utctime, int otcoff, int dstoff)
ScriptObject VDUtilBridge::HandleVDSetTimeOfDay(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	if (aArgs.Length() < 3)
	{
		LOG_WARN(logger_, "Argument Error");
		return ScriptObject(-1);
	}

	int utctime = aArgs[0].asNumber();
	int otcoff = aArgs[1].asNumber();
	int dstoff = aArgs[2].asNumber();

	LOG_WARN(logger_, "HandleVDSetTimeOfDay: " << utctime << " " << otcoff << " " << dstoff);

	int ret = vd_settimeofday(utctime, otcoff, dstoff);

	LOG_WARN(logger_, "ret: " << ret);

	return ScriptObject(ret);
}

ScriptObject VDUtilBridge::HandleVDGetTimeOfDay(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	struct timeval tv;
	int ret;

	ret = gettimeofday(&tv, NULL);
	if (ret == -1)
	{
		LOG_ERROR(logger_, "Get Time Of Day Fail!");
		return ScriptObject(ret);
	}
	
	return ScriptObject((int)tv.tv_sec);
}

ScriptObject VDUtilBridge::HandleVDLocalTime(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	time_t sec;
	struct tm *p;

	sec = time(NULL);
	p = localtime(&sec);
	if(p == NULL)
	{
		LOG_ERROR(logger_, "Get Local Time Fail!");
		return ScriptObject(0);
	}

	sec = mktime(p);
	
	return ScriptObject((int)sec);
}

ScriptObject VDUtilBridge::HandleVDGetTimeZone(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int utcoff = 0;
	int dstoff = 0;
	ScriptObject ret;
	
	time_t cur, local, gmt;
	struct tm *q;
	struct tm mytime;
	long diff;

	tzset();
	utcoff = timezone / 60;
	
	time(&cur);
	q = localtime_r(&cur, &mytime);
	if(q == NULL)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;
	}
	

	local = mktime(q);
	if(local == -1)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;		
	}

	q = gmtime_r(&cur, &mytime);
	if(q == NULL)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;		
	}
	
	gmt = mktime(q);
	if(gmt == -1)
	{
		LOG_ERROR(logger_, "Get Time Zone Fail!");
		ret.set("utcoff", utcoff);
		ret.set("dstoff", dstoff);

		return ret;		
	}

	diff = local - gmt;

	dstoff = (q->tm_gmtoff - diff) /60;

	ret.set("utcoff", utcoff);
	ret.set("dstoff", dstoff);

	return ret;
}

ScriptObject VDUtilBridge::HandleGetProcMemory(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	pid_t pid = getpid();
	std::string line;
	std::string data;
	std::ostringstream s;
	s << "/proc/" << (int)pid << "/vd_memstat";
	std::string fileName(s.str());

	LOG_WARN(logger_, "fileName: " << fileName);
	std::ifstream  memfile(fileName);

	if (memfile.is_open())
	{
		while(getline(memfile, line))
		{
			data = data + line + "\n";
		}

		memfile.close();
	}

	return ScriptObject(data);
}

ScriptObject VDUtilBridge::HandleFirstScreenReady(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	prctl(PR_TASK_PERF_USER_TRACE, "-------------------------FirstScreen display-------------------------", strlen("-------------------------FirstScreen display-------------------------"));

	FILE* fp = NULL;

	if(fp = fopen("/tmp/firstscreen_ready", "wb"))
	{
		fclose(fp);
		return ScriptObject(true);
	}

	else

	{
		return ScriptObject(false);
	}
	
}

ScriptObject VDUtilBridge::HandleIsExistWASTempFile(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	FILE* fp = NULL;

	fp = fopen("/tmp/sef_ready", "rb");
	if (fp == NULL)
	{
		return ScriptObject(false);
	}
	fclose(fp);

	fp = fopen("/tmp/was_ready", "rb");
	if (fp == NULL)
	{
		return ScriptObject(false);
	}
	fclose(fp);

	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleHeapSnapShot(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	v8::Isolate* isolate = v8::Isolate::GetCurrent();
	
	const HeapSnapshot* const snapshot = isolate->GetHeapProfiler()->TakeHeapSnapshot(v8::String::Empty(isolate));

	FILE* fp = NULL;
	if (aArgs.Length() > 0)
	{
		LOG_WARN(logger_, "Saving HeapSnapShot to " << aArgs[0].asString());
		fp = fopen(aArgs[0].asString().c_str(), "w");
	}
	else
	{
		char scratch[1024];
		
		struct timeval mytime;
		gettimeofday(&mytime, NULL);

		snprintf(scratch, sizeof(scratch), "%s/heapdump-%ld-%ld.heapsnapshot", AppConfig::Instance().GetAppDataPath().c_str(), mytime.tv_sec, mytime.tv_usec);
		LOG_WARN(logger_, "Saving HeapSnapShot to " << scratch);

		fp = fopen(scratch, "w");
	}

	if (fp == NULL) {
		return false;
	}

	FileOutputStream stream(fp);
	snapshot->Serialize(&stream, HeapSnapshot::kJSON);
	fclose(fp);

	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleGetXWindowID(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Window window = (Window)clutter_x11_get_stage_window ((ClutterStage*) GetMainStage());
	printf("[WindowID] %d\n", window);
	return ScriptObject((int) window);
}

ScriptObject VDUtilBridge::HandleVDAnnotate(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	
	std::string log;
	if( aArgs.Length() > 0)
	{
		ANNOTATE_SETUP;
		log = aArgs[0].asString();
		char* pLog = (char *)log.c_str();
		ANNOTATE_CHANNEL_COLOR(2, ANNOTATE_BLUE, pLog);
		ANNOTATE_CHANNEL_END(2);
	}
	
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleVDRaiseXWindow(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	VDRaiseXWindow((ClutterActor*) GetMainStage());
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleGetMLSstate(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int status = 0;

	vconf_get_int("db/mls/mls_state", &status);

	if(status == 1)
	{
		return ScriptObject(true);
	}

	else
	{
		return ScriptObject(false);
	}

	return ScriptObject(false);
}

ScriptObject VDUtilBridge::HandleGetResolution(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int value = 0;
	int systemResult = system_info_get_value_int(SYSTEM_INFO_KEY_OSD_RESOLUTION_WIDTH, &value);

	return ScriptObject(value);
}

ScriptObject VDUtilBridge::HandleScreenCapture(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	ScreenCapture((ClutterActor*) GetMainStage(), aArgs[0].asString().c_str(), 720);
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleChangeXPropertyNormal(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Display* dpy = clutter_x11_get_default_display();
	Window w = (Window)clutter_x11_get_stage_window ((ClutterStage*)GetMainStage());
	Atom type = XInternAtom(dpy, "_NET_WM_STATE_NORMAL", False);
	XChangeProperty(dpy, w, XInternAtom(dpy, "_NET_WM_STATE", False), XInternAtom(dpy, "ATOM", False), 32, PropModeReplace, (unsigned char *)&type, 1);
	LOG_DEBUG(logger_, "Change _NET_WM_STATE(ATOM) -> _NET_WM_STATE_NORMAL!");

	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleRegisterKey(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Display* dpy = clutter_x11_get_default_display();
	Window w = (Window)clutter_x11_get_stage_window ((ClutterStage*)GetMainStage());
	KeyRepository_RemoveAllKeys(&repository);
//	KeyRepository_AddKey(&repository,R_KEY_HOME);
	KeyRepository_AddKey(&repository,R_KEY_UP);
	KeyRepository_AddKey(&repository,R_KEY_DOWN);
	KeyRepository_AddKey(&repository,R_KEY_LEFT);
	KeyRepository_AddKey(&repository,R_KEY_RIGHT);
	KeyRepository_AddKey(&repository,R_KEY_ENTER);
	KeyRepository_AddKey(&repository,R_KEY_BACK);
	KeyRepository_AddKey(&repository,R_KEY_EXIT);	
//	KeyRepository_AddKey(&repository, R_KEY_VOLUMEUP);
//	KeyRepository_AddKey(&repository, R_KEY_VOLUMEDOWN);
//	KeyRepository_AddKey(&repository, R_KEY_MUTE);
	KeyRepository_AddKey(&repository,R_KEY_0);
	KeyRepository_AddKey(&repository,R_KEY_1);
	KeyRepository_AddKey(&repository,R_KEY_2);
	KeyRepository_AddKey(&repository,R_KEY_3);
	KeyRepository_AddKey(&repository,R_KEY_4);
	KeyRepository_AddKey(&repository,R_KEY_5);
	KeyRepository_AddKey(&repository,R_KEY_6);
	KeyRepository_AddKey(&repository,R_KEY_7);
	KeyRepository_AddKey(&repository,R_KEY_8);
	KeyRepository_AddKey(&repository,R_KEY_9);
	LOG_FATAL(logger_, "[First Screen] Register Key !");
	KeyRepository_Register(dpy, w, &repository);
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleUnRegisterKey(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	Display* dpy = clutter_x11_get_default_display();
	Window w = (Window)clutter_x11_get_stage_window ((ClutterStage*)GetMainStage());
	KeyRepository_RemoveAllKeys(&repository);
	LOG_FATAL(logger_, "[First Screen] UnRegister VolumeKey !");
	KeyRepository_Register(dpy, w, &repository);
	return ScriptObject(true);
}

/*
ScriptObject VDUtilBridge::HandleIsDebugMode(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int value = 0;
	system_info_get_value_int(SYSTEM_INFO_KEY_ERROR_POPUP_ON_OFF, &value);

	return ScriptObject(value);
}
*/

ScriptObject VDUtilBridge::HandleGetAppId(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	std::string ret;
	
	try
		{
			std::string appjs = AppConfig::Instance().GetAppRootPath();

			if (boost::starts_with(appjs, "/usr/apps/org.volt.firstscreen"))
			{
				ret = "org.volt.firstscreen";
			}
				
			if (boost::starts_with(appjs, "/opt/down/panels/apps"))
			{
				ret = "org.volt.apps";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/clips"))
			{
				ret = "org.volt.clips";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/games"))
			{
				ret = "org.volt.games";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/mycontents"))
			{
				ret = "org.volt.mycontents";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/newson"))
			{
				ret = "org.volt.newson";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/soccer"))
			{
				ret = "org.volt.soccer";
			}
		}
    catch (boost::bad_any_cast)
    {
    }

	return ScriptObject(ret);
}

ScriptObject VDUtilBridge::HandleGetWidgetId(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	std::string ret;
	
		try
		{
			std::string appjs = AppConfig::Instance().GetAppRootPath();

			if (boost::starts_with(appjs, "/usr/apps/org.volt.firstscreen"))
			{
				ret = "111477001200";
			}
				
			if (boost::starts_with(appjs, "/opt/down/panels/apps"))
			{
				ret = "111477001206";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/clips"))
			{
				ret = "111477001207";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/games"))
			{
				ret = "111477001202";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/mycontents"))
			{
				ret = "111477001204";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/newson"))
			{
				ret = "111477001203";
			}
			
			if (boost::starts_with(appjs, "/opt/down/panels/soccer"))
			{
				ret = "111477001205";
			}
		}
    catch (boost::bad_any_cast)
    {
    }

	return ScriptObject(ret);
}

static bool ExtractForegroundColor(unsigned int from_r, unsigned int from_g, unsigned int from_b, unsigned int *to_r, unsigned int * to_g, unsigned int* to_b)
{
	if(to_r == NULL || to_g == NULL || to_b == NULL)
	{
//		err_log("RGB cannot be NULL\n");
		return false;
	}

	unsigned int r  = (from_r & 0xFF);
	unsigned int g  = (from_g & 0xFF);
	unsigned int b  = (from_b & 0xFF);
	unsigned int gb = (r + g + b)/3;
	
	unsigned int g1=0, g2=153, g3=255, g4=40, g5=106;
	
	float d;
	
	unsigned int tb;

	if(gb >= g1 && gb <= g2)
	{
		d = (float)(gb - g1)/(g2 - g1);
		tb = int(g2 + (g3 - g2)*d + 0.5f);
	}
	else
	{
		d = (float)(gb - g2)/(g3 - g2);
		tb = int(g4 + (g5 - g4)*d + 0.5f);
	}
	*to_r = tb;
	*to_g = tb;
	*to_b = tb;
	
	return true;
} 

ScriptObject VDUtilBridge::HandleExtractForegroundColor(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	int from_r = 0, from_g = 0, from_b = 0;
	if (aArgs.has(0) && aArgs[0].isNumber()) { from_r = aArgs[0].asNumber(); }
	if (aArgs.has(1) && aArgs[1].isNumber()) { from_g = aArgs[1].asNumber(); }
	if (aArgs.has(2) && aArgs[2].isNumber()) { from_b = aArgs[2].asNumber(); }

	int to_r = 0, to_g = 0, to_b = 0;
	ScriptObject retval = ScriptObject();
	retval.set("success", ScriptObject(ExtractForegroundColor(from_r, from_g, from_b, (uint*)&to_r, (uint*)&to_g, (uint*)&to_b)));
	ScriptObject colval = ScriptObject();
	colval.set("r", ScriptObject(to_r));
	colval.set("g", ScriptObject(to_g));
	colval.set("b", ScriptObject(to_b));
	retval.set("color", colval);

	return retval;
}

ScriptObject VDUtilBridge::HandleGetMemfree(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	const int maxDataLength = 20;
	char buff[maxDataLength] = {0,};
	int readLength;
	int fd = -1;
	int memorySize = 0;
	
	fd = open("/proc/vd_memfree",O_RDONLY);
	if(fd == -1)
	{
		LOG_WARN(logger_, "Cannot open /proc/memfree. Try again later");
  }
  else
  {
  	LOG_WARN(logger_, "File name: /proc/memfree");
  	readLength = read(fd, buff, maxDataLength);
  	buff[readLength] = NULL;
  	memorySize = atoi(buff);
  	
  	close(fd);
  }
  return ScriptObject(memorySize);
}

ScriptObject VDUtilBridge::HandleGetSourceInfo(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	bool isSource = true;
	
	ISourceControl* sourceCtrl = NULL;
	TVServiceAPI::CreateSourceControl( PROFILE_TYPE_MAIN, 1, &sourceCtrl ); // 1 -> sub source
  LOG_WARN(logger_, "Create source control context");
  
	if(sourceCtrl != NULL)
	{
    ESource source;
    if(sourceCtrl -> GetCurrentSourceInfo(source) > 0)
    {
    	LOG_WARN(logger_, "Success to get current source info");
    	if(source != SOURCE_TYPE_TV)
      {
      	LOG_WARN(logger_, "Source type is not TV");
    		isSource = false;
      }
    }
	}
  return ScriptObject(isSource);
}

ScriptObject VDUtilBridge::HandleTvContextState(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	bool isSource;
	tvcontext_state state = NULL;
	LOG_WARN(logger_, "tvcontext_query_state call!");
  tvcontext_init();
  tvcontext_query_state(&state);
  LOG_WARN(logger_, "tvcontext_state =" << state);
  
  if(TVCONTEXT_CHECK_STATE(state, TVCONTEXT_STATE_TV))
  {
  	isSource = true;
  	LOG_WARN(logger_, "TV is shown");
  }
  else
  {
    isSource = false;
    LOG_WARN(logger_, "TV is not shown");
  }
  tvcontext_fini();
  
  return ScriptObject(isSource);
}

ScriptObject VDUtilBridge::HandleHapticInit(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
    // initialize_haptic_feedback();
    return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleHapticSend(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	if (aArgs.Length() < 1)
	{
		LOG_FATAL(logger_, "Argument is wrong");
		return ScriptObject(false);
	}
	else
	{
		std::string arg;
		arg = aArgs[0].asString();
		if(arg == "HAPTIC_LONGPRESS")
		{
			execute_haptic_feedback(HAPTIC_LONGPRESS);
		}

		else if(arg == "HAPTIC_INITIALENTRY")
		{
			execute_haptic_feedback(HAPTIC_INITIALENTRY);
		}

		else if(arg == "HAPTIC_TRANSITION")
		{
			execute_haptic_feedback(HAPTIC_TRANSITION);
		}

		else if(arg == "HAPTIC_BUTTONSCROLL")
		{
			execute_haptic_feedback(HAPTIC_BUTTONSCROLL);
		}

		else if(arg == "HAPTIC_MOUSEIN")
		{
			execute_haptic_feedback(HAPTIC_MOUSEIN);
		}

		else if(arg == "HAPTIC_CURSORSCROLL")
		{
			execute_haptic_feedback(HAPTIC_CURSORSCROLL);
		}

		else if(arg == "HAPTIC_DRAGSTART")
		{
			execute_haptic_feedback(HAPTIC_DRAGSTART);
		}

		else if(arg == "HAPTIC_DRAGEND")
		{
			execute_haptic_feedback(HAPTIC_DRAGEND);
		}	

		else if(arg == "HAPTIC_STOP")
		{
			execute_haptic_feedback(HAPTIC_STOP);
		}	

	}
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleAppControlInitDbusConnection(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	LOG_WARN(logger_, "HandleAppControlInitDbusConnection");
	
	AppControlAPI::InitDbusConnection();
	
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleAppControlDisableItem(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	LOG_WARN(logger_, "HandleAppControlDisableItem");
	
	string menuId = aArgs[0].asString();
	string appName = aArgs[0].asString();
	
	LOG_WARN(logger_, "menuId " << menuId << " appName " << appName);
	
	AppControlAPI::DisableItem(menuId.c_str(), appName.c_str());
		
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleAppControlRemoveDisabledItemsByAppname(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	LOG_WARN(logger_, "HandleAppControlRemoveDisabledItemsByAppname");
	
	string appName = aArgs[0].asString();
	
	LOG_WARN(logger_," appName " << appName);
	
	AppControlAPI::RemoveDisabledItemsByAppname(appName.c_str());
	
	return ScriptObject(true);
}

ScriptObject VDUtilBridge::HandleAppControlFiniDbusConnection(VDUtilBridge *aSelf, const ScriptArray &aArgs)
{
	LOG_WARN(logger_, "HandleAppControlFiniDbusConnection");
	
	AppControlAPI::FiniDbusConnection();
		
	return ScriptObject(true);
}