/*
 * ScriptBridge.cpp
 *
 *  Created on: May 6, 2013
 *      Author: reza
 */

#include "ScriptBridge.h"
#include <functional>
#include "Widget.h"

using namespace v8;
using namespace Bridge;

std::map<void*, v8::UniquePersistent<v8::Object>* > ScriptBridge::createdObjects;
//std::map<ScriptObject::ExternalData_t*, int > ScriptBridge::allocatedExternalData;

volt::util::Logger ScriptBridge::traceLogger("volt.bridge.trace");

ScriptBridge::ScriptBridge()
  : blockConstructFromScript(false), allowGarbageCollection(true)
{
}

ScriptBridge::~ScriptBridge() {}

void ScriptBridge::dispose()
{
  //delete all created objects. Do not use a normal iterator because it is possible that one created
  //object might destroy another in its destructor, removing its entry from this set and invalidating
  //the iterator
  while (instanceCreatedObjects.size() > 0)
  {
    auto first = instanceCreatedObjects.begin();
    void* removeMe = *first;
    instanceCreatedObjects.erase(first);
    destroyFromScript(removeMe);
  }
}
/*
int ScriptBridge::registerExternalData(ScriptObject::ExternalData_t *pointer)
{
  if(allocatedExternalData.count(pointer))
  {
    allocatedExternalData[pointer]++;
  }
  else
  {
    allocatedExternalData[pointer] = 1;
  }

  return allocatedExternalData[pointer];
}

int ScriptBridge::unregisterExternalData(ScriptObject::ExternalData_t *pointer)
{
  if(allocatedExternalData.count(pointer))
  {
    // deallocate memory if you are last guy to use it
    if(allocatedExternalData[pointer] == 1)
    {
      allocatedExternalData.erase(pointer);
      return 0;
    }
    else
    {
      allocatedExternalData[pointer] --;
      return allocatedExternalData[pointer];
    }
  }

  return -1;
}
*/


void ScriptBridge::bridgeTo(v8::Handle<v8::ObjectTemplate> classScope)
{
  v8::Handle<v8::FunctionTemplate> constructorTempl = GetConstructorTemplate();
  classScope->Set(StringToV8(getScriptClassName()), constructorTempl);
}

void ScriptInstanceBridge::bridgeTo(v8::Handle<v8::ObjectTemplate> classScope)
{
  classScope->SetAccessor(StringToV8(getScriptClassName()), &ScriptInstanceBridge::instanceAccessor, nullptr,
                          External::New(Isolate::GetCurrent(), this));
}

void ScriptInstanceBridge::contextReady()
{
  ScriptBridge::contextReady();
  scriptInstance.Reset(Isolate::GetCurrent(), instantiate(bridgedInstance));
}


void ScriptInstanceBridge::instanceAccessor(Local<String> property,  const PropertyCallbackInfo<Value>& info)
{
  EscapableHandleScope handle_scope(Isolate::GetCurrent());
  void* data = Handle<External>::Cast(info.Data())->Value();
  ScriptInstanceBridge* self = reinterpret_cast<ScriptInstanceBridge*>(data);

  if(self->scriptInstance.IsEmpty())
  {
    info.GetReturnValue().Set( Undefined(Isolate::GetCurrent()) );
  }

  info.GetReturnValue().Set( self->scriptInstance );
}

Handle<Object> ScriptBridge::instantiate(void* nativePtr)
{
  EscapableHandleScope scope(Isolate::GetCurrent());

  Local<Function> ctorTemplateHandle = Local<Function>::New(Isolate::GetCurrent(), constructorInstance);
  blockConstructFromScript = true; //don't attempt to run the native constructor, instead make a shell object with the correct interface.
  Local<Object> instance = ctorTemplateHandle->NewInstance();
  blockConstructFromScript = false;

  registerConstructedObject(nativePtr, instance);

  return scope.Escape(instance);
}

Handle<FunctionTemplate> ScriptBridge::GetConstructorTemplate()
{
  if(constructorTemplate.IsEmpty())
  {
    HandleScope scope(Isolate::GetCurrent());

    Handle<FunctionTemplate> constructor =
      FunctionTemplate::New( Isolate::GetCurrent(), constructCallRouter, External::New( Isolate::GetCurrent(), this ));
    //Attach a pointer to this object. v8 needs to call a static method, so the static
    //constructCallRouter function will receive that call and route it back to the instance
    //that first registered it.

    Handle<ObjectTemplate> instance = constructor->InstanceTemplate();
    Handle<ObjectTemplate> prototype = constructor->PrototypeTemplate();

    instance->SetInternalFieldCount(1);
    constructor->SetClassName(StringToV8(getScriptClassName()));
    ScriptContext context = ScriptContext(instance, prototype, constructor);
    mapScriptInterface(context);

    constructorTemplate.Reset(Isolate::GetCurrent(), constructor);
  }

  return Local<FunctionTemplate>::New(Isolate::GetCurrent(), constructorTemplate);
}


void ScriptBridge::constructCallRouter(const FunctionCallbackInfo<Value>& args)
{
  HandleScope scope(Isolate::GetCurrent());

  v8::Handle<v8::String> funcName = args.Callee()->GetName()->ToString();
  LOG_DEBUG(traceLogger, "Trace JS Constructor call: " + V8ToString(funcName));

  Handle<Value> ptrToBridgeInstance = args.Data();

  Handle<External> field = Handle<External>::Cast(ptrToBridgeInstance);
  void* ptr = field->Value();
  ScriptBridge* bridgeInstance = static_cast<ScriptBridge*>(ptr);
  bridgeInstance->onJSConstruct(args);
  return;
}

void ScriptBridge::onJSConstruct(const FunctionCallbackInfo<Value>& args)
{
  //This flag means to just return the object with no native pointer.
  //It is used by instantiate to skip this step, because instantiate will
  //handle inserting the native pointer later.
  if (blockConstructFromScript)
  {
    args.GetReturnValue().Set(  args.This() );
    return;
  }

  try
  {
    if (!args.IsConstructCall())
    {
      args.GetReturnValue().Set( Isolate::GetCurrent()->ThrowException(StringToV8("Cannot call constructor without new")) );
      return;
    }

    HandleScope scope(Isolate::GetCurrent());

    V8Arguments<v8::Value>* argumentObj = new V8Arguments<v8::Value>(&args);
    void* nativeInstancePtr = constructFromScript(argumentObj);
    registerConstructedObject(nativeInstancePtr, args.This());

    args.GetReturnValue().Set(  args.This() );
    delete argumentObj;
  }
  catch (VoltJsRuntimeException &e)
  {
    args.GetReturnValue().Set(  Isolate::GetCurrent()->ThrowException(v8::Exception::Error( StringToV8( e.what() ) )));
  }
}

void ScriptBridge::registerConstructedObject(void* nativePtr, Local<Object> wrapperObject)
{
  wrapperObject->SetInternalField(0, External::New( Isolate::GetCurrent(), nativePtr ));

  //Local<Object> createdObjectHandle = Local<Object>::New(Isolate::GetCurrent(), args.This());
  UniquePersistent<Object>* createdObject = new UniquePersistent<Object>(Isolate::GetCurrent(), wrapperObject);

  if(allowGarbageCollection)
  {
    createdObject->SetWeak(this, OnGarbageCollect);
  }

  createdObjects[nativePtr] = createdObject;

  instanceCreatedObjects.insert(nativePtr); //objects in this set will be destroyed when this bridge is
}

void ScriptBridge::OnGarbageCollect(const WeakCallbackData<Object, ScriptBridge >& weakCallbackData)
{
  //Get refs to the persistent handle, the native data, and its ScriptBridge
  //extract without casting because we don't know the type here.
  HandleScope scope(Isolate::GetCurrent());
  Local<Object> jsObjectHandle = weakCallbackData.GetValue();
  void* gcedObject = extract<void*>(jsObjectHandle);
  UniquePersistent<Object>* persistentHandle = createdObjects[gcedObject];
  ScriptBridge* self = weakCallbackData.GetParameter();

  //Remove this map entry
  createdObjects.erase(gcedObject);
  self->instanceCreatedObjects.erase(gcedObject);

  //Send the object to the bridge, which knows the type, to destroy the object
  self->destroyFromScript(gcedObject);

  //Clean up the persistent handle
  jsObjectHandle->SetInternalField( 0, External::New(Isolate::GetCurrent(), nullptr) );
  persistentHandle->Reset();
  delete persistentHandle;
}

void ScriptBridge::releaseForGarbageCollection(ScriptBridge* bridge, void* pointerToMappedObject)
{
  if(createdObjects.count(pointerToMappedObject) > 0)
  {
    HandleScope scope(Isolate::GetCurrent());
    UniquePersistent<Object>* createdObj = createdObjects[pointerToMappedObject];
    Local<Object> jsObjectHandle = Local<Object>::New(Isolate::GetCurrent(), *createdObj);

    createdObjects.erase(pointerToMappedObject);
    if (bridge->instanceCreatedObjects.count(pointerToMappedObject) > 0)
    {
        bridge->instanceCreatedObjects.erase(pointerToMappedObject);
    }
	
    jsObjectHandle->SetInternalField( 0, External::New(Isolate::GetCurrent(), nullptr) );
    createdObj->Reset();
    delete createdObj;
  }

  if (bridge->instanceCreatedObjects.count(pointerToMappedObject) > 0)
  {
    bridge->instanceCreatedObjects.erase(pointerToMappedObject);
  }
}



