/*
 * ServiceBridge.cpp
 *
 *  Created on: June 26th, 2014
 *      Author: Joe Yee
 */

#include "ServiceBridge.h"
#include "VoltConfig.h"
#include "Exception.h"

#if defined(BUILD_FOR_TV) && defined(TIZEN)
#include <boost/config.hpp>
#include <clutter/clutter.h>
#endif

#define DEFINE_KEY_MAP(context,key) (context).bindNumber<ServiceBridge, int, \
                                                         &ServiceBridge::get##key, \
                                                         &ServiceBridge::set##key>(#key)

namespace Bridge
{
std::string ServiceBridge::LOGGER_NAME = "volt.service.bridge";
volt::util::Logger ServiceBridge::logger_(LOGGER_NAME);
ServiceBridge::CALLBACK_MAP ServiceBridge::callbackMap;

ServiceBridge::ServiceBridge()
  : ScriptBridge()
{
}

ServiceBridge::~ServiceBridge()
{
}

void ServiceBridge::mapScriptInterface(ScriptContext& aContext)
{
  LOG_DEBUG(logger_, "Mapping Service script interfaces");

  aContext.bindString<TizenService,
                      &TizenService::GetAppId,
                      &TizenService::SetAppId>("appId");

  aContext.bindNumber<TizenService,
                      int,
                      &TizenService::GetServiceOperation,
                      &TizenService::SetServiceOperation>("operation");

  aContext.bindString<TizenService,
                      &TizenService::GetUri,
                      &TizenService::SetUri>("uri");

  aContext.bindString<TizenService,
                      &TizenService::GetPackage,
                      &TizenService::SetPackage>("package");

  aContext.captureMethodCall<TizenService, &HandleAddExtraData>("addExtraData");
  aContext.captureMethodCall<TizenService, &HandleLaunch>("launch");

  aContext.setClassConstant("OPERATION_DEFAULT", ScriptObject((int)OPERATION_DEFAULT));
  aContext.setClassConstant("OPERATION_EDIT", ScriptObject((int)OPERATION_EDIT));
  aContext.setClassConstant("OPERATION_VIEW", ScriptObject((int)OPERATION_VIEW));
  aContext.setClassConstant("OPERATION_PICK", ScriptObject((int)OPERATION_PICK));
  aContext.setClassConstant("OPERATION_CREATE_CONTENT", ScriptObject((int)OPERATION_CREATE_CONTENT));
  aContext.setClassConstant("OPERATION_CALL", ScriptObject((int)OPERATION_CALL));
  aContext.setClassConstant("OPERATION_SEND", ScriptObject((int)OPERATION_SEND));
  aContext.setClassConstant("OPERATION_SEND_TEXT", ScriptObject((int)OPERATION_SEND_TEXT));
  aContext.setClassConstant("OPERATION_SHARE", ScriptObject((int)OPERATION_SHARE));
  aContext.setClassConstant("OPERATION_MULTI_SHARE", ScriptObject((int)OPERATION_MULTI_SHARE));
  aContext.setClassConstant("OPERATION_SHARE_TEXT", ScriptObject((int)OPERATION_SHARE_TEXT));
  aContext.setClassConstant("OPERATION_DIAL", ScriptObject((int)OPERATION_DIAL));
  aContext.setClassConstant("OPERATION_SEARCH", ScriptObject((int)OPERATION_SEARCH));
  aContext.setClassConstant("OPERATION_DOWNLOAD", ScriptObject((int)OPERATION_DOWNLOAD));
  aContext.setClassConstant("OPERATION_PRINT", ScriptObject((int)OPERATION_PRINT));
  aContext.setClassConstant("OPERATION_COMPOSE", ScriptObject((int)OPERATION_COMPOSE));
  aContext.setClassConstant("OPERATION_DATA_SUBJECT", ScriptObject((int)OPERATION_DATA_SUBJECT));
  aContext.setClassConstant("OPERATION_DATA_TO", ScriptObject((int)OPERATION_DATA_TO));
  aContext.setClassConstant("OPERATION_DATA_CC", ScriptObject((int)OPERATION_DATA_CC));
  aContext.setClassConstant("OPERATION_DATA_BCC", ScriptObject((int)OPERATION_DATA_BCC));
  aContext.setClassConstant("OPERATION_DATA_TEXT", ScriptObject((int)OPERATION_DATA_TEXT));
  aContext.setClassConstant("OPERATION_DATA_TITLE", ScriptObject((int)OPERATION_DATA_TITLE));
  aContext.setClassConstant("OPERATION_DATA_SELECTED", ScriptObject((int)OPERATION_DATA_SELECTED));
  aContext.setClassConstant("OPERATION_DATA_PATH", ScriptObject((int)OPERATION_DATA_PATH));
}

void* ServiceBridge::constructFromScript(const ScriptArray &aArgs)
{
  LOG_DEBUG(logger_, "Creating a new instance");

  TizenService* client = new TizenService();

  return client;
}

ScriptObject ServiceBridge::HandleLaunch(TizenService *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null tizen service pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  bool hasCallback = false;

  if(argsLen)
  {
    if(aArgs[0].isFunction())
    {
      if(callbackMap.count(aSelf) == 0)
      {
        callbackMap[aSelf] = aArgs[0].asFunction();
        hasCallback = true;
      }
      else
      {
        LOG_ERROR(logger_, "callback already registered for " << aSelf);
      }
    }
    else
    {
      LOG_ERROR(logger_, "1st parameter is not passed in as a function");
    }
  }

  if(aSelf->Launch(hasCallback) == 0)
  {
    result = true;
  }

  return ScriptObject(result);
}

ScriptObject ServiceBridge::HandleAddExtraData(TizenService *aSelf, const ScriptArray &aArgs)
{
  bool result = false;

  if(not aSelf)
  {
    LOG_ERROR(logger_, "null tizen service pointer");
    return ScriptObject(result);
  }

  int argsLen = aArgs.Length();

  if (argsLen == 2)
  {
    std::string key = aArgs[0].asString();

    // handle 1 value
    if(aArgs[1].isString())
    {
      std::string value = aArgs[1].asString();

      if(aSelf->AddExtraData(key, value) == 0)
      {
        result = true;
      }
    }

    // handle value array
    else if(aArgs[1].isArray())
    {
      ScriptArray valueArray = aArgs[1].asArray();
      int valueLength = valueArray.Length();

      if(valueLength)
      {
        std::vector<std::string> values;

        for(int i = 0; i < valueLength; i++)
        {
          ScriptObject object = valueArray[i];
          values.push_back(object.asString());

          if(aSelf->AddExtraData(key, values) == 0)
          {
            result = true;
          }
        }
      }
      else
      {
        LOG_ERROR(logger_, "got zero length array");
      }
    }
    else
    {
      LOG_ERROR(logger_, "unhandled value data type");
    }
  }
  else
  {
    LOG_ERROR(logger_, "invalid argument length");
  }

  return ScriptObject(result);
}

#if defined(BUILD_FOR_TV) && defined(TIZEN)
void ServiceBridge::ProxyRequestServiceCallback(TizenService *aSelf, int result)
{
  CallbackMessage *msg = new CallbackMessage();
  msg->service = aSelf;
  msg->result = result;

  /* Gotta invoke the js handlers in the v8/clutter thread */
  clutter_threads_add_idle_full(G_PRIORITY_DEFAULT_IDLE,
                                [](gpointer aData) -> gboolean
  {
    CallbackMessage *data = reinterpret_cast<CallbackMessage *>(aData);
    ServiceBridge::FireRequestServiceCallback(data);
    return FALSE; // required by clutter to return false
  }, msg, NULL);
}

void ServiceBridge::FireRequestServiceCallback(CallbackMessage *msg)
{
  TizenService *aSelf = msg->service;

  if(aSelf == nullptr)
  {
    LOG_ERROR(logger_, "null TizenService, failed to fire request service callback");
    delete msg;
    return;
  }

  // this takes care of the case of the object being remove before callback occur
  if(callbackMap.count(aSelf) == 0)
  {
    LOG_ERROR(logger_, "no callback registered, failed to fire request service callback");
    delete msg;
    return;
  }

  ScriptArray result;
  ScriptObject output(msg->result);

  result.set(0, output);

  callbackMap[aSelf].invoke(result);

  callbackMap.erase(aSelf); // clear callback, this is one time only

  delete msg;
}
#endif
};

