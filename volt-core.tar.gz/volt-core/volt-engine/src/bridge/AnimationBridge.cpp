#include "AnimationBridge.h"
#include "AnimationSpec.h"
#include "Animation.h"
#include "WidgetBridge.h"

using namespace Bridge;
using namespace volt::graphics;

AnimationHandleBridge AnimationBridge::handleBridge;

void AnimationBridge::mapScriptInterface(ScriptContext& context)
{
  context.bindNumber<Animation, float, &Animation::getDuration, &Animation::setDuration>("duration");
  context.bindNumber<Animation, float, &Animation::getRepeat, &Animation::setRepeat>("repeat");

  context.captureMethodCall<Animation, &addProperty>("addProperty");
  context.captureMethodCall<Animation, &addPropertyRelative>("addRelativeProperty");
  context.captureMethodCall<Animation, &addPropertyWithBezier>("addPropertyWithBezier");
  context.captureMethodCall<Animation, &addPropertyRelativeWithBezier>("addRelativePropertyWithBezier");

  context.captureMethodCall<Animation, &addKey>("addKey");
  context.captureMethodCall<Animation, &addRelativeKey>("addRelativeKey");

  context.captureMethodCall<IAnimationCallbacks, addCompleteCallback>("addCallback");
  context.captureMethodCall<IAnimationCallbacks, addKeyCallback>("addKeyCallback");

}

void* AnimationBridge::constructFromScript(const ScriptArray& args)
{
  double duration = 200;
  double repeat = 0;
  const std::string durationKey = "duration";
  const std::string repeatKey = "repeat";

  if (args.Length() > 0 )
  {
    if (args[0].has(durationKey))
    {
      duration = args[0][durationKey].asNumber();
    }

    if (args[0].has(repeatKey))
    {
      repeat = args[0][repeatKey].asNumber();
    }
    else if (args[0].isNumber())
    {
      duration = args[0].asNumber();

      if (args.Length()> 1 && args[1].isNumber())
      {
        repeat = args[1].asNumber();
      }
    }
  }

  return new Animation(duration, repeat);
}

inline void AnimationBridge::destroyFromScript(void* destroyedObject)
{
  /* If an animation object becomes inaccessable, destroy it. The actual animation group still attached to the widget will still
     exist until its duration is up.*/
  Animation* inaccessableTimeline = reinterpret_cast<Animation*>(destroyedObject);
  delete inaccessableTimeline;
}


ScriptObject AnimationBridge::addProperty(Animation* self, const ScriptArray& args)
{
  return addKeyframe(self, args, false, false, false);
}

ScriptObject AnimationBridge::addPropertyRelative(Animation* self, const ScriptArray& args)
{
  return addKeyframe(self, args, false, true, false);
}

ScriptObject AnimationBridge::addPropertyWithBezier(Animation* self, const ScriptArray& args)
{
  return addKeyframe(self, args, false, false, true);
}

ScriptObject AnimationBridge::addPropertyRelativeWithBezier(Animation* self, const ScriptArray& args)
{
  return addKeyframe(self, args, false, true, true);
}

ScriptObject AnimationBridge::addKey(Animation* self, const ScriptArray& args)
{
  return addKeyframe(self, args, true, false, false);
}

ScriptObject AnimationBridge::addRelativeKey(Animation* self, const ScriptArray& args)
{
  return addKeyframe(self, args, true, true, false);
}

ScriptObject AnimationBridge::addKeyframe(Animation* self, const ScriptArray& args, bool hasKey, bool isRelative, bool hasBezier)
{
  double key = 1;

  if (hasKey && args.Length() > 0)
  {
    ScriptObject options = args[0];

    if (options.has("key"))
    {
      key = options["key"].asNumber();
    }
    else
    {
      key = args[0].asNumber();
    }
  }

  parseAnimationParams(args, *self, (float)key, isRelative, (hasKey) ? 1 : 0, hasBezier);
  return ScriptObject();
}

void AnimationBridge::onAnimationFinished(const ScriptFunction& callback)
{
  callback.invoke(ScriptArray());
}

ScriptObject AnimationBridge::addCompleteCallback(IAnimationCallbacks* self, const ScriptArray& args)
{
  ScriptFunction callbackObj = args[0].asFunction();
  AnimationCallback callbackFunctor = std::bind(onAnimationFinished, callbackObj.asFunction());
  self->addCompletionCallback(callbackFunctor);
  return ScriptObject();
}

ScriptObject AnimationBridge::addKeyCallback(IAnimationCallbacks* self, const ScriptArray& args)
{
  double key = args[0].asNumber();
  ScriptFunction callbackObj = args[1].asFunction();
  AnimationCallback callbackFunctor = std::bind(&AnimationBridge::onAnimationFinished, callbackObj.asFunction());
  self->addKeyCallback(key, callbackFunctor);
  return ScriptObject();
}


bool AnimationBridge::parseAnimationParams(const ScriptArray& args, Animation& result, float key, bool isRelative, int argsOffset, bool useBezier)
{
  if(args.Length() < 1)
  {
    throw VoltJsRuntimeException("Must provide target property and value for animation.");
  }

  //Get the arguments as ScriptObjects
  ScriptObject propObj, valueObj, tweenObj;
  bool hasTween = false;
  ScriptObject options = args[0];

  if( options.tryGet("property", propObj) && options.tryGet("value", valueObj) ) //using an options argument
  {
    hasTween = options.tryGet("tweenMode", tweenObj);
  }
  else if( args.tryGet(argsOffset + 0, propObj) && args.tryGet(argsOffset + 1, valueObj) )
  {
    hasTween = args.tryGet(argsOffset + 2, tweenObj);
  }
  else
  {
    throw VoltJsRuntimeException("Must provide target property and value for animation.");
  }


  //Extract the values or set to default
  std::string propString = propObj.asString();


  TweenMode tweenMode;
  BezierCurve customEasing;

  if (useBezier)
  {
    customEasing = getBezierControlPoints(tweenObj); //will throw exception if wrong object type
    tweenMode = TweenMode::CUBIC_BEZIER;
  }
  else if (hasTween)
  {
    tweenMode = deserializeTweenMode(tweenObj.asString());
  }
  else
  {
    tweenMode = TweenMode::LINEAR;
  }

  parseAnimationValueObject(valueObj, propString, tweenMode, result, key, isRelative, customEasing);

  return true;
}

ScriptObject AnimationBridge::parseAnimateFunctionParams(Widget* widget, const ScriptArray& args)
{
  std::string ERROR_MSG = "Must provide target property and value for animation.";

  if(args.Length() < 1)
  {
    return ScriptException(ERROR_MSG);
  }

  //If we have an animation object as the first param, easy, just apply it.
  Animation* animation = unwrapNativeObject<Animation>(args[0]);

  if (animation != nullptr)
  {
    AnimationCallback callbackFunctor = nullptr;

    if (args.has(1))
    {
      callbackFunctor = std::bind(onAnimationFinished, args[1].asFunction());
    }

    return handleBridge.instantiate(animation->apply(widget, callbackFunctor));
    //return ScriptObject();
  }

  //Otherwise we need to extract the args and create one

  //Get the arguments as ScriptObjects
  ScriptObject propObj, valueObj, durationObj, callbackObj, tweenObj;
  bool hasDuration = false, hasCallback = false, hasTween = false, repeat = false;

  ScriptObject options = args[0];

  if( options.tryGet("property", propObj) && options.tryGet("value", valueObj) ) //using an options argument
  {
    hasDuration = options.tryGet("duration", durationObj);
    hasTween = options.tryGet("tweenMode", tweenObj);
    hasCallback = options.tryGet("callback", callbackObj);

    if(options.has("loop") )
    {
      repeat = options["loop"].asBool();
    }
  }
  else if( args.tryGet(0, propObj) && args.tryGet(1, valueObj) )
  {
    hasDuration = args.tryGet(2, durationObj);

    //Let callback and tween come in any order (backwards compatibility)
    if(args.has(3))
    {
      if(args[3].isString())
      {
        tweenObj = args[3].asString();
        hasTween = true;

        if(args.has(4) && args[4].isFunction())
        {
          callbackObj = args[4].asFunction();
          hasCallback = true;
        }
      }
      else if(args[3].isFunction())
      {
        callbackObj = args[3].asFunction();
        hasCallback = true;

        if(args.has(4) && args[4].isString())
        {
          tweenObj = args[4].asString();
          hasTween = true;
        }
      }
    }
  }
  else
  {
    return ScriptException(ERROR_MSG);
  }

  if( ! propObj.isString()  )
  {
    return ScriptException(ERROR_MSG);
  }

  std::string propString = propObj.asString();
  double duration = (hasDuration) ? durationObj.asNumber() : 0;

  TweenMode tweenMode =  (hasTween) ? AnimationBridge::deserializeTweenMode(tweenObj.asString())
                         : TweenMode::LINEAR;

  AnimationCallback callbackFunctor = nullptr;

  if(hasCallback)
  {
    callbackFunctor = std::bind(onAnimationFinished, callbackObj.asFunction());
  }

  Animation anim = Animation(duration, (repeat ? -1 : 0));

  std::vector<AnimationSpec> specs;
  parseAnimationValueObject(valueObj, propString, tweenMode, anim, 1, false, BezierCurve());
  return handleBridge.instantiate( anim.apply(widget, callbackFunctor) );
}

ScriptObject AnimationBridge::parseCancelAnimateFunction(Widget* widget, const ScriptArray& args)
{
  std::vector<AnimatableProperty> propertiesToCancel;

  for (uint i = 0; i < args.Length(); ++i)
  {
    std::string property = args[i].asString();
    propertiesToCancel.push_back(parseProperty(property));
  }

  Animation::cancelAnimation(widget, propertiesToCancel);
  return ScriptObject();
}

void AnimationBridge::parseAnimationValueObject(ScriptObject valueObj, std::string propString, TweenMode tweenMode, Animation& result,
    float key, bool isRelative, BezierCurve customEasingCurve)
{
  AnimatableProperty property = parseProperty(propString);

  //Need to seperate aggregate properties, eg, "scale" is both scale.x and scale.y.

  //Rounded Corners
  if (property == RoundedCorners && valueObj.has("radius") && valueObj.has("arcStep"))
  {
    double r = valueObj.get("radius").asNumber();
    double a = valueObj.get("arcStep").asNumber();

    result.addKey(RoundedCornersRadius, r, false, tweenMode, key, isRelative, customEasingCurve);
    result.addKey(RoundedCornersArcStep, a, false, tweenMode, key, isRelative, customEasingCurve);
  }
  //Borders
  else if (property == Border && valueObj.has("width") && valueObj.has("color"))
  {
    double width = valueObj.get("width").asNumber();
    Color color = WidgetBridge::ScriptToColor(valueObj.get("color"));

    result.addKey(BorderWidth, width, false, tweenMode, key, isRelative, customEasingCurve);
    result.addKey(BorderColor, color, tweenMode, key, isRelative, customEasingCurve);
  }
  //handle vector types
  else if(valueObj.has("x") && valueObj.has("y"))
  {
    double x = valueObj.get("x").asNumber();
    double y = valueObj.get("y").asNumber();

    if(!valueObj.has("z")) //<-------2D vector
    {
      if (property == Scale)
      {
        result.addKey(ScaleX, x, false, tweenMode, key, isRelative, customEasingCurve);
        result.addKey(ScaleY, y, false, tweenMode, key, isRelative, customEasingCurve);
      }
      else if (property == Anchor)
      {
        result.addKey(AnchorX, x, false, tweenMode, key, isRelative, customEasingCurve);
        result.addKey(AnchorY, y, false, tweenMode, key, isRelative, customEasingCurve);
      }
      else if (property == Origin)
      {
        result.addKey(OriginX, x, false, tweenMode, key, isRelative, customEasingCurve);
        result.addKey(OriginY, y, false, tweenMode, key, isRelative, customEasingCurve);
      }
      else
      {
        if (property != InvalidAnimation)
        {
          result.addKey(property, Vector2(x, y), tweenMode, key, isRelative, customEasingCurve);
        }
      }

    }
    else // <------------3D vector
    {
      double z = valueObj.get("z").asNumber();

      if (property == Rotation)
      {
        result.addKey(RotationX, x, false, tweenMode, key, isRelative, customEasingCurve);
        result.addKey(RotationY, y, false, tweenMode, key, isRelative, customEasingCurve);
        result.addKey(RotationZ, z, false, tweenMode, key, isRelative, customEasingCurve);
      }
      else
      {
        if (property != InvalidAnimation)
        {
          result.addKey(property, Vector3(x, y, z), tweenMode, key, isRelative, customEasingCurve);
        }
      }
    }
  }//handle color type
  else if(property == BackgroundColor || property == BackgroundColor_RC ||
          property == BorderColor || property == TextColor || property == TextShadowColor ||
          property == ShadowColor)
  {
    Color color = WidgetBridge::ScriptToColor(valueObj);
    result.addKey(property, color, tweenMode, key, isRelative, customEasingCurve);
  }
  else //otherwise its a single property, so send it on through
  {
    if (property != InvalidAnimation)
    {
      double value =  valueObj.asNumber();
      bool isByte = (property == Opacity); //opacity needs to be special handled
      result.addKey(property, value, isByte, tweenMode, key, isRelative, customEasingCurve);
    }
    else
    {
      throw VoltJsRuntimeException("Invalid widget property name given to Animation.");
    }
  }

}


TweenMode AnimationBridge::deserializeTweenMode(std::string tweenStr)
{

  if( compareStrChar(tweenStr, "QUADRATIC") )
  {
    return TweenMode::QUADRATIC;
  }

  if( compareStrChar(tweenStr, "QUADRATIC-in") )
  {
    return TweenMode::QUADRATIC_IN;
  }

  if( compareStrChar(tweenStr, "QUADRATIC-out") )
  {
    return TweenMode::QUADRATIC_OUT;
  }

  if( compareStrChar(tweenStr, "CUBIC") )
  {
    return TweenMode::CUBIC;
  }

  if( compareStrChar(tweenStr, "CUBIC-in") )
  {
    return TweenMode::CUBIC_IN;
  }

  if( compareStrChar(tweenStr, "CUBIC-out") )
  {
    return TweenMode::CUBIC_OUT;
  }

  if( compareStrChar(tweenStr, "") )
  {
    return TweenMode::QUARTIC;
  }

  if( compareStrChar(tweenStr, "QUARTIC-in") )
  {
    return TweenMode::QUARTIC_IN;
  }

  if( compareStrChar(tweenStr, "QUARTIC-out") )
  {
    return TweenMode::QUARTIC_OUT;
  }

  if( compareStrChar(tweenStr, "QUINTIC") )
  {
    return TweenMode::QUINTIC;
  }

  if( compareStrChar(tweenStr, "QUINTIC-in") )
  {
    return TweenMode::QUINTIC_IN;
  }

  if( compareStrChar(tweenStr, "QUINTIC-out") )
  {
    return TweenMode::QUINTIC_OUT;
  }

  if( compareStrChar(tweenStr, "SINE") )
  {
    return TweenMode::SINE;
  }

  if( compareStrChar(tweenStr, "SINE-in") )
  {
    return TweenMode::SINE_IN;
  }

  if( compareStrChar(tweenStr, "SINE-out") )
  {
    return TweenMode::SINE_OUT;
  }

  if( compareStrChar(tweenStr, "EXPONENTIAL") )
  {
    return TweenMode::EXPONENTIAL;
  }

  if( compareStrChar(tweenStr, "EXPONENTIAL-in") )
  {
    return TweenMode::EXPONENTIAL_IN;
  }

  if( compareStrChar(tweenStr, "EXPONENTIAL-out") )
  {
    return TweenMode::EXPONENTIAL_OUT;
  }

  if( compareStrChar(tweenStr, "CIRCULAR") )
  {
    return TweenMode::CIRCULAR;
  }

  if( compareStrChar(tweenStr, "CIRCULAR-in") )
  {
    return TweenMode::CIRCULAR_IN;
  }

  if( compareStrChar(tweenStr, "CIRCULAR-out") )
  {
    return TweenMode::CIRCULAR_OUT;
  }

  if( compareStrChar(tweenStr, "ELASTIC") )
  {
    return TweenMode::ELASTIC;
  }

  if( compareStrChar(tweenStr, "ELASTIC-in") )
  {
    return TweenMode::ELASTIC_IN;
  }

  if( compareStrChar(tweenStr, "ELASTIC-out") )
  {
    return TweenMode::ELASTIC_OUT;
  }

  if( compareStrChar(tweenStr, "OVERSHOOT") )
  {
    return TweenMode::OVERSHOOT;
  }

  if( compareStrChar(tweenStr, "OVERSHOOT-in") )
  {
    return TweenMode::OVERSHOOT_IN;
  }

  if( compareStrChar(tweenStr, "OVERSHOOT-out") )
  {
    return TweenMode::OVERSHOOT_OUT;
  }

  if( compareStrChar(tweenStr, "BOUNCE") )
  {
    return TweenMode::BOUNCE;
  }

  if( compareStrChar(tweenStr, "BOUNCE-in") )
  {
    return TweenMode::BOUNCE_IN;
  }

  if( compareStrChar(tweenStr, "BOUNCE-out") )
  {
    return TweenMode::BOUNCE_OUT;
  }

  return TweenMode::LINEAR;
}

BezierCurve AnimationBridge::getBezierControlPoints(const ScriptObject& obj)
{
  BezierCurve curve;
  curve.control1 = WidgetBridge::ScriptToVector2(obj.get("control1"));
  curve.control2 = WidgetBridge::ScriptToVector2(obj.get("control2"));
  return curve;
}


AnimatableProperty AnimationBridge::parseProperty(std::string property)
{
  auto it = propMap.find(property);

  if (it == propMap.end())
  {
    return InvalidAnimation;
  }
  else
  {
    return it->second;
  }
}

std::unordered_map<std::string, AnimatableProperty> AnimationBridge::propMap =
{
  { "x",PositionX },
  { "y",PositionY },
  { "width",Width },
  { "height",Height },
  { "depth",Depth },
  { "opacity",Opacity },
  { "rotation.x",RotationX },
  { "rotation.y",RotationY },
  { "rotation.z",RotationZ },
  { "scale.x",ScaleX },
  { "scale.y",ScaleY },
  { "pivot.x",PivotX },
  { "pivot.y",PivotY },
  { "anchor.x",AnchorX },
  { "anchor.y",AnchorY },
  { "origin.x",OriginX },
  { "origin.y",OriginY },
  { "color.r",ColorR },
  { "color.g",ColorG },
  { "color.b",ColorB },
  { "color.a",ColorA },
  { "border.width", BorderWidth },
  { "border.color.r",BorderColorR },
  { "border.color.g",BorderColorG },
  { "border.color.b",BorderColorB },
  { "border.color.a",BorderColorA },
  { "textColor.r",TextColorR },
  { "textColor.g",TextColorG },
  { "textColor.b",TextColorB },
  { "textColor.a",TextColorA },
  { "textShadowColor.r",TextShadowColorR },
  { "textShadowColor.g",TextShadowColorG },
  { "textShadowColor.b",TextShadowColorB },
  { "textShadowColor.a",TextShadowColorA },
  { "shadowColor.r",ShadowColorR },
  { "shadowColor.g",ShadowColorG },
  { "shadowColor.b",ShadowColorB },
  { "shadowColor.a",ShadowColorA },
  { "roundedCorners.radius",RoundedCornersRadius },
  { "roundedCorners.arcStep",RoundedCornersArcStep },
  { "curl.period",CurlPeriod },
  { "curl.angle",CurlAngle },
  { "curl.radius",CurlRadius },
  { "desaturate",Desaturate },
  { "brightness",Brightness },
  { "contrast",Contrast },
  { "lineSpacing", LineSpacing },
  { "textShadow.xOffset", TextShadowXOffset },
  { "textShadow.yOffset", TextShadowYOffset },
  { "shadow.xOffset", ShadowXOffset },
  { "shadow.yOffset", ShadowYOffset },
  { "shadow.blur", ShadowBlur },
  { "shadow.spread", ShadowSpread },

  //2D
  { "roundedCorners",RoundedCorners },
  { "border",Border },
  { "pivot",Pivot },
  { "scale",Scale },
  { "anchor",Anchor },
  { "origin", Origin },

  //3D
  { "rotation", Rotation },

  //Color
  { "color",BackgroundColor },
  { "border.color",BorderColor },
  { "tint",Tint },
  { "textColor",TextColor },
  { "textShadow.color", TextShadowColor },
  { "shadow.color", ShadowColor }
};

/* *************************************/
//AnimationHandleBridge stuff
/* *************************************/

namespace //Helper functions for AnimationHandleBridge
{
ScriptObject isPaused(AnimationHandle* self, const ScriptArray& args)
{
  return ScriptObject( self->isPaused() );
}

ScriptObject getProgress(AnimationHandle* self, const ScriptArray& args)
{
  return ScriptObject( self->getProgress() );
}

ScriptObject getCurrentRepeat(AnimationHandle* self, const ScriptArray& args)
{
  return ScriptObject( self->getCurrentRepeat() );
}

ScriptObject jump(AnimationHandle* self, const ScriptArray& args)
{
  double time = args[0].asNumber();
  self->jump(time);
  return ScriptObject();
}

ScriptObject skip(AnimationHandle* self, const ScriptArray& args)
{
  double time = args[0].asNumber();
  self->skip(time);
  return ScriptObject();
}
}

void Bridge::AnimationHandleBridge::mapScriptInterface(ScriptContext& context)
{
  context.bindAction<AnimationHandle, &AnimationHandle::cancel>("cancel");
  context.bindAction<AnimationHandle, &AnimationHandle::pause>("pause");
  context.bindAction<AnimationHandle, &AnimationHandle::resume>("resume");

  context.captureMethodCall<AnimationHandle, &jump>("jump");
  context.captureMethodCall<AnimationHandle, &skip>("skip");

  context.captureMethodCall<AnimationHandle, &isPaused>("isPaused");
  context.captureMethodCall<AnimationHandle, &getProgress>("getProgress");
  context.captureMethodCall<AnimationHandle, &getCurrentRepeat>("getCurrentRepeat");

  context.captureMethodCall<IAnimationCallbacks, &AnimationBridge::addCompleteCallback>("addCallback");
  context.captureMethodCall<IAnimationCallbacks, &AnimationBridge::addKeyCallback>("addKeyCallback");
}
