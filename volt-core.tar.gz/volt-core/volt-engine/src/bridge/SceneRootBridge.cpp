/*
 * SceneRootBridge.cpp
 *
 *  Created on: Jun 24, 2013
 *      Author: reza
 */

#include "SceneRootBridge.h"

using namespace volt::graphics;

namespace Bridge
{

void SceneRootBridge::mapScriptInterface(ScriptContext& context)
{
  //Properties
  context.bindBoolean<Widget, &Widget::getDepthTestEnabled, &Widget::setDepthTestEnabled>("drawWithDepth");
  context.bindNumber<Widget, float, &Widget::getWidth, &Widget::setWidth>("width");
  context.bindNumber<Widget, float, &Widget::getHeight, &Widget::setHeight>("height");

  context.capturePropertyAccess<SceneRoot, getSize, setSize>("size");
  context.capturePropertyAccess<SceneRoot, getColor, setColor>("color");
  context.bindBoolean<Widget, &Widget::getAutoSortChildrenByDepth, &Widget::setAutoSortChildrenByDepth>("autoSortChildrenByDepth");

  //Methods
  context.captureMethodCall<SceneRoot, &addChild>("addChild");
  context.captureMethodCall<SceneRoot, &removeChild>("removeChild");
  context.captureMethodCall<SceneRoot, &getChildCount>("getChildCount");
  context.captureMethodCall<SceneRoot, &getChild>("getChild");
  context.captureMethodCall<SceneRoot, &getDescendent>("getDescendant");
  context.captureMethodCall<SceneRoot, &getDescendent>("getDescendent"); //TODO: Deprecate this, -ant is correct spelling
  context.captureMethodCall<SceneRoot, &handleDestroyChildren>("destroyChildren");

  context.captureMethodCall<SceneRoot, &getAncestor>("getAncestor");
  context.captureMethodCall<SceneRoot, &show>("show");
  context.captureMethodCall<SceneRoot, &hide>("hide");

  context.captureMethodCall<SceneRoot, &getKeyFocus>("getKeyFocus");
  context.captureMethodCall<SceneRoot, &setKeyFocus>("setKeyFocus");
  context.captureMethodCall<SceneRoot, &clearKeyFocus>("clearKeyFocus");

  //Event handling functions
  context.captureMethodCall<Widget, &WidgetBridge::addEventListener>("addEventListener");
  context.captureMethodCall<Widget, &WidgetBridge::removeEventListener>("removeEventListener");
  context.captureMethodCall<Widget, &WidgetBridge::dispatchEvent>("dispatchEvent");
  context.captureMethodCall<Widget, &WidgetBridge::reorderChildrenByDepth>("reorderChildrenByDepth");
}


ScriptObject SceneRootBridge::handleDestroyChildren(SceneRoot* self, const ScriptArray& args)
{
  self->destroyChildren();
  return ScriptObject();
}

ScriptObject SceneRootBridge::show(SceneRoot* self, const ScriptArray& args)
{
  self->show();
  return ScriptObject();
}

ScriptObject SceneRootBridge::hide(SceneRoot* self, const ScriptArray& args)
{
  self->hide();
  return ScriptObject();
}

ScriptObject SceneRootBridge::getSize(SceneRoot* self)
{
  float width = self->getWidth();
  float height = self->getHeight();
  ScriptObject result;
  result.set("width", width);
  result.set("height", height);
  return result;
}

void SceneRootBridge::setSize(SceneRoot* self, ScriptObject value)
{
  float width = (value.has("width")) ? value["width"].asNumber() : 0;
  float height = (value.has("height")) ? value["height"].asNumber() : 0;
  self->setWidth(width);
  self->setHeight(height);
}

ScriptObject SceneRootBridge::getColor(SceneRoot* self)
{
  return WidgetBridge::ColorToScript( self->getColor() );
}

void SceneRootBridge::setColor(SceneRoot* self, ScriptObject value)
{
  self->setColor( WidgetBridge::ScriptToColor(value) );
}

ScriptObject Bridge::SceneRootBridge::getChildCount(SceneRoot* self,
    const ScriptArray& args)
{
  return ScriptObject((double)self->getChildCount());
}

Widget* getChildWidget(SceneRoot* self, ScriptObject identifier)
{
  Widget* target = nullptr;

  if(identifier.isNumber())
  {
    target = self->getChildByIndex(identifier.asNumber());
  }
  else if (identifier.isString())
  {
    target = self->getChildByName(identifier.asString());
  }

  return target;
}

ScriptObject Bridge::SceneRootBridge::addChild(SceneRoot* self,
    const ScriptArray& args)
{
  int index = -1;

  if(args.Length() > 0)
  {
    if(args.Length() == 2 && args[1].isNumber())
    {
      index = args[1].asNumber();
    }

    Widget* child = unwrapNativeObject<Widget>(args[0]);

    if (child != nullptr)
    {
      index = self->addChild(child, index);
      return ScriptObject(index);
    }
    else
    {
      return ScriptException("Non-widget passed as argument to Widget.addChild");
    }
  }

  return ScriptException("Widget.addChild expects a Widget object as first parameter");
}


ScriptObject Bridge::SceneRootBridge::removeChild(SceneRoot* self,
    const ScriptArray& args)
{
  if(args.Length() > 0)
  {
    Widget* orphan = unwrapNativeObject<Widget>(args[0]);

    if(orphan == nullptr && args[0].isNumber())
    {
      orphan = self->removeChildByIndex(args[0].asNumber());
    }
    else if (orphan == nullptr && args[0].isString())
    {
      orphan = self->getChildByName(args[0].asString());
      self->removeChild( orphan );
    }
    else if (orphan != nullptr)
    {
      self->removeChild(orphan);
    }

    if (orphan != nullptr) //if we ended up finding a widget
    {
      //If called with an index it may be useful to return the widget that we looked up.
      return wrapExistingNativeObject(orphan);
    }
    else
    {
      return ScriptException("Non-widget or valid index passed as argument to Widget.removeChild");
    }
  }

  return ScriptException("Widget.removeChild expects a Widget object or valid index as first parameter");
}


ScriptObject Bridge::SceneRootBridge::getChild(SceneRoot* self,
    const ScriptArray& args)
{
  if(args.Length() > 0)
  {
    return wrapExistingNativeObject( getChildWidget(self, args[0]) );
  }

  return ScriptObject();
}

ScriptObject Bridge::SceneRootBridge::getDescendent(SceneRoot* self,
    const ScriptArray& args)
{
  if(args.Length() > 0 && args[0].isString())
  {
    return wrapExistingNativeObject( self->getDescendent( args[0].asString()) );
  }

  return ScriptObject();
}

ScriptObject Bridge::SceneRootBridge::getAncestor(SceneRoot* self,
    const ScriptArray& args)
{
  if(args.Length() > 0 && args[0].isString())
  {
    return wrapExistingNativeObject( self->getAncestor( args[0].asString()) );
  }

  return ScriptObject();
}

ScriptObject Bridge::SceneRootBridge::getKeyFocus(SceneRoot* self,
    const ScriptArray& args)
{
  return wrapExistingNativeObject(self->getKeyFocus());
}

ScriptObject Bridge::SceneRootBridge::setKeyFocus(SceneRoot* self,
    const ScriptArray& args)
{
  Widget* newFocus = unwrapNativeObject<Widget>(args[0]);

  if (args[0] == nullptr)
  {
    return ScriptException("Non-widget passed as parameter to scene.setKeyFocus");
  }
  else
  {
    self->setKeyFocus(newFocus);
  }

  return ScriptObject();
}

ScriptObject Bridge::SceneRootBridge::clearKeyFocus(SceneRoot* self,
    const ScriptArray& args)
{
  self->clearKeyFocus();
  return ScriptObject();
}

} /* namespace Bridge */
