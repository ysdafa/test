#include "VoltWorkerBridge.h"

#include "logger.h"

using namespace Bridge;

static volt::util::Logger LOGGER("volt.worker.bridge");

std::map<std::string, VoltWorker *> VoltWorkerBridge::workers_;

VoltWorkerBridge::VoltWorkerBridge(): ScriptBridge()
{
}

VoltWorkerBridge::~VoltWorkerBridge()
{
}

bool VoltWorkerBridge::HandleWorkerMessage(const std::string &aID,
    const std::string &aMsg)
{
  LOG_DEBUG(LOGGER, "Handling a msg from " << aID << ": " << aMsg);
  auto iter = workers_.find(aID);

  if (iter == workers_.end())
  {
    LOG_DEBUG(LOGGER, "Failed to find worker: " << aID);
    return false;
  }

  iter->second->OnMessage(aMsg);
  return true;
}

bool VoltWorkerBridge::HandleWorkerCommand(const std::string &aID,
    const std::string &aCmd,
    std::string &aResult)
{
  LOG_DEBUG(LOGGER, "Handling a cmd from " << aID << ": " << aCmd);
  auto iter = workers_.find(aID);

  if (iter == workers_.end())
  {
    LOG_DEBUG(LOGGER, "Failed to find worker: " << aID);
    return false;
  }

  return iter->second->OnCommand(aCmd, aResult);
}

bool VoltWorkerBridge::HandleWorkerError(const std::string &aID,
    const std::string &aMsg)
{
  LOG_TRACE(LOGGER, "Handling an error from " << aID << ": " << aMsg);
  auto iter = workers_.find(aID);

  if (iter == workers_.end())
  {
    LOG_DEBUG(LOGGER, "Failed to find worker: " << aID);
    return false;
  }

  iter->second->OnError(aMsg);
  return true;
}

VoltWorker* VoltWorkerBridge::FindWorker(const std::string &aID)
{
  auto iter = workers_.find(aID);

  if (iter == workers_.end())
  {
    return NULL;
  }

  return iter->second;
}

void VoltWorkerBridge::mapScriptInterface(ScriptContext& aContext)
{
  aContext.captureMethodCall<VoltWorker, &HandlePostMessage>("postMessage");
  aContext.captureMethodCall<VoltWorker, &HandleExecCommand>("execCommand");

  aContext.capturePropertyAccess<VoltWorker,
                                 &GetOnMessage,
                                 &SetOnMessage>("onMessage");

  aContext.capturePropertyAccess<VoltWorker,
                                 &GetOnError,
                                 &SetOnError>("onError");

  aContext.capturePropertyAccess<VoltWorker,
                                 &GetIsRunning,
                                 &SetIsRunning>("running");

  aContext.captureMethodCall<VoltWorker, &HandleTerminate>("terminate");
}

void* VoltWorkerBridge::constructFromScript(const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Creating a new VoltWorker instance.");

  VoltWorker *worker = new VoltWorker();

  if (aArgs.Length() == 0)
  {
    return worker;
  }

  std::string uri;

  ScriptObject obj;

  if (aArgs.Length() == 1 && aArgs[0].tryGet("uri", obj))
  {
    uri = obj.asString();

    if (aArgs[0].tryGet("onMessage", obj))
    {
      AssignOnMessageCallback(worker, obj.asFunction());
    }

    if (aArgs[0].tryGet("onCommand", obj))
    {
      AssignOnCommandCallback(worker, obj.asFunction());
    }

    if (aArgs[0].tryGet("onError", obj))
    {
      AssignOnErrorCallback(worker, obj.asFunction());
    }
  }
  else
  {
    /* positional */
    uri = aArgs[0].asString();

    if (aArgs.Length() > 1)
    {
      AssignOnMessageCallback(worker, aArgs[2].asFunction());
    }

    if (aArgs.Length() > 2)
    {
      AssignOnCommandCallback(worker, aArgs[3].asFunction());
    }

    if (aArgs.Length() > 3)
    {
      AssignOnErrorCallback(worker, aArgs[4].asFunction());
    }
  }

  LOG_DEBUG(LOGGER, "Running " << uri << " in a worker.");
  worker->Run(uri);

  workers_.insert(std::make_pair(worker->ID(), worker));

  return worker;
}

void VoltWorkerBridge::AssignOnMessageCallback(VoltWorker *aWorker,
    ScriptFunction aJsCallback)
{
  /* lambda function! */
  VoltWorker::OnMessageCallback callback =
    std::bind([](ScriptFunction aJsCallback, VoltWorker *aWorker, const std::string aMsg)
  {
    LOG_DEBUG(LOGGER, "Execute JS callback with msg: " << aMsg);

    ScriptObject eventData;
    eventData.set("data", ScriptObject(aMsg));
    eventData.set("worker", wrapExistingNativeObject(aWorker));

    ScriptArray args;
    args.set(0, eventData);
    aJsCallback.invoke(args);
  },
  aJsCallback, aWorker, std::placeholders::_1);

  aWorker->RegisterOnMessageCallback(callback);
}

void VoltWorkerBridge::AssignOnCommandCallback(VoltWorker *aWorker,
    ScriptFunction aJsCallback)
{
  /* lambda function! */
  VoltWorker::OnCommandCallback callback =
    std::bind([](ScriptFunction aJsCallback, VoltWorker *aWorker,
                 const std::string aCmd, std::string &aResult)
  {
    LOG_DEBUG(LOGGER, "Execute JS callback for cmd: " << aCmd);

    ScriptObject eventData;
    eventData.set("data", ScriptObject(aCmd));
    eventData.set("worker", wrapExistingNativeObject(aWorker));

    ScriptArray args;
    args.set(0, eventData);
    ScriptObject result = aJsCallback.invoke(args);

    if (result.isString())
    {
      aResult = result.asString();
      return true;
    }
    else
    {
      return false;
    }
  },
  aJsCallback, aWorker, std::placeholders::_1, std::placeholders::_2);

  aWorker->RegisterOnCommandCallback(callback);
}

void VoltWorkerBridge::AssignOnErrorCallback(VoltWorker *aWorker,
    ScriptFunction aJsCallback)
{
  /* lambda function! */
  VoltWorker::OnErrorCallback callback =
    std::bind([](ScriptFunction aJsCallback, VoltWorker *aWorker, const std::string aMsg)
  {
    LOG_DEBUG(LOGGER, "Execute JS callback with msg: " << aMsg);

    ScriptObject eventData;
    eventData.set("message", ScriptObject(aMsg));
    eventData.set("worker", wrapExistingNativeObject(aWorker));

    ScriptArray args;
    args.set(0, eventData);
    aJsCallback.invoke(args);
  },
  aJsCallback, aWorker, std::placeholders::_1);

  aWorker->RegisterOnErrorCallback(callback);
}

ScriptObject VoltWorkerBridge::HandlePostMessage(VoltWorker *aWorker,
    const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Handle postMessage on worker " << aWorker);

  bool retval = false;

  do
  {
    if (aArgs.Length() < 1)
    {
      LOG_DEBUG(LOGGER, "No message to send");
      break;
    }

    retval = aWorker->PostMessage(aArgs[0].asString());
  }
  while(0);

  return ScriptObject(retval);
}

ScriptObject VoltWorkerBridge::HandleExecCommand(VoltWorker *aWorker,
    const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Handle execCommand on worker " << aWorker);

  ScriptArray js_results;

  if (aArgs.Length() < 1)
  {
    LOG_DEBUG(LOGGER, "No command to execute");
    return js_results;
  }

  bool getAll = false;

  if (aArgs.Length() > 1 && aArgs[1].isBool())
  {
    getAll = aArgs[1].asBool();
  }

  std::vector<std::string> results;

  if (aWorker->ExecCommand(aArgs[0].asString(), results))
  {
    /* Get result from every registered ON_COMMAND listeners. */
    for (unsigned index = 0; index < results.size(); ++index)
    {
      LOG_DEBUG(LOGGER, "results[" << index << "]: " << results[index]);
      js_results.set(index, results[index]);

      if (getAll == false)
      {
        /* Just return the first result. */
        break;
      }
    }
  }

  return js_results;
}

ScriptObject VoltWorkerBridge::GetOnMessage(VoltWorker *aWorker)
{
  return ScriptObject();
}

void VoltWorkerBridge::SetOnMessage(VoltWorker *aWorker, ScriptObject aObj)
{
  LOG_DEBUG(LOGGER, "Set onMessage on worker " << aWorker);

  if (aObj.isFunction() == false)
  {
    LOG_DEBUG(LOGGER, "The arg is not a function");
    return;
  }

  AssignOnMessageCallback(aWorker, aObj.asFunction());
}

ScriptObject VoltWorkerBridge::GetOnError(VoltWorker *aWorker)
{
  return ScriptObject();
}

void VoltWorkerBridge::SetOnError(VoltWorker *aWorker, ScriptObject aObj)
{
  LOG_DEBUG(LOGGER, "Set onError on worker " << aWorker);

  if (aObj.isFunction() == false)
  {
    LOG_DEBUG(LOGGER, "The arg is not a function");
    return;
  }

  AssignOnErrorCallback(aWorker, aObj.asFunction());
}

ScriptObject VoltWorkerBridge::GetIsRunning(VoltWorker *aWorker)
{
  return ScriptObject(aWorker->IsRunning());
}

void VoltWorkerBridge::SetIsRunning(VoltWorker *aWorker, ScriptObject aObj)
{
}

ScriptObject VoltWorkerBridge::HandleTerminate(VoltWorker *aWorker,
    const ScriptArray &aArgs)
{
  LOG_DEBUG(LOGGER, "Handle terminate on worker " << aWorker);

  double maxWait = 5000;
  ScriptObject obj;

  if (aArgs.Length() == 1 && aArgs[0].tryGet("maxWait", obj))
  {
    maxWait = obj.asNumber();
  }
  else if (aArgs.Length() >= 1)
  {
    /* positional */
    maxWait = aArgs[0].asNumber();
  }

  aWorker->Terminate(maxWait);

  /* Worker should not be running at this point. */

  /* this must be called via the worker handle. */
  return ScriptObject(true);
}
