/*
 * ImageWidgetBridge.cpp
 *
 *  Created on: May 23, 2013
 *      Author: reza
 */

#include "ImageWidgetBridge.h"
#include "ImageWidget.h"

#include <boost/program_options.hpp>

/* Volt configuration options. */
#include "AppConfig.h"

#include "DataBuffer.h"

using namespace volt::graphics;
using namespace volt::util;

namespace Bridge
{

std::map<Widget*, ScriptFunction> Bridge::ImageWidgetBridge::readyCallbacks;

void Bridge::ImageWidgetBridge::mapScriptInterface(ScriptContext& context)
{
  WidgetBridge::mapScriptInterface(context);

  context.capturePropertyAccess<ImageWidget, getSource, setSource>("src");
  context.capturePropertyAccess<ImageWidget, getOnReady, setOnReady>("onReady");
  context.capturePropertyAccess<ImageWidget, getFillMode, setFillMode>("fillMode");
  context.bindBoolean<ImageWidget, &ImageWidget::getAsyncLoading, &ImageWidget::setAsyncLoading>("async");

  context.captureMethodCall<ImageWidget, &getColorPicking>("getColorPicking");
  context.captureMethodCall<ImageWidget, &getImageCroppedCoord>("getImageCroppedCoord");
}


Widget* Bridge::ImageWidgetBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
  std::string src = "", fill = "";
  DataBuffer::SharedPtr buffer;
  Image *src_image = nullptr;
  ScriptFunction onReady;
  bool isOnReadySet = false;
  bool async = AppConfig::Instance().IsSet("sync-img-load") ? false : true;

  if(args.Length() > 0)
  {
    ScriptObject options = args[0];

    if(options.has("src"))
    {
      if(options["src"].isString())
      {
        src = options["src"].asString();
      }
      else if(options["src"].isArrayBuffer())
      {
        buffer = options["src"].getDataBuffer();
      }
      else
      {
        src_image = unwrapNativeObject<Image>(options["src"]);
      }

      if(options.has("fillMode") )
      {
        fill = options["fillMode"].asString();
      }

      if(options.has("onReady") )
      {
        onReady = options["onReady"].asFunction();
        isOnReadySet = true;
      }

      if (options.has("async") )
      {
        async = options["async"].asBool();
      }
    }
    else
    {
      if(args.has(0))
      {
        if(args[0].isString())
        {
          src = args[0].asString();
        }
        else if(args[0].isArrayBuffer())
        {
          buffer = args[0].getDataBuffer();
        }
        else if(args.has(2))
        {
          if(args[2].isString())
          {
            src = args[2].asString();
          }
          else if(args[2].isArrayBuffer())
          {
            buffer = args[2].getDataBuffer();
          }
        }
      }

      if(args.has(1) && args[1].isFunction())
      {
        onReady = args[1].asFunction();
        isOnReadySet = true;
      }
      else if(args.has(3) && args[3].isFunction())
      {
        onReady = args[3].asFunction();
        isOnReadySet = true;
      }
    }
  }

  ImageWidget* cIWidget = constructImageWidget(x, y, width, height, parent, args);

  if (isOnReadySet)
  {
    cIWidget->setOnReady(registerReadyCallback(cIWidget, onReady));
  }

  if (fill != "")
  {
    cIWidget->setFillMode(deserializeFillMode(fill));
  }

  cIWidget->setAsyncLoading(async);

  if (src_image)
  {
    cIWidget->setSource(src_image);
  }
  else if(buffer.get() and buffer->data() and buffer->length())
  {
    cIWidget->setSource(buffer);
  }
  else
  {
    cIWidget->setSource(src);
  }

  //Register for destruction event. Need to cleanup
  WidgetDestructionCallback destructionCallback = std::bind( onDestruction, cIWidget);
  cIWidget->registerDestructionEvent(destructionCallback);

  return cIWidget;
}

ImageWidget* ImageWidgetBridge::constructImageWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
  if(width == -1 && height == -1)
  {
    return new ImageWidget(x, y, parent);
  }
  else
  {
    return new ImageWidget(x, y, (width == -1) ? 0 : width, (height == -1) ? 0 : height, parent);
  }
}

void ImageWidgetBridge::onDestruction(ImageWidget* self)
{
  unregisterReadyCallback(self);
}

ScriptObject ImageWidgetBridge::getImageColor(ImageWidget* self)
{
  Color color = self->getColor();
  return ColorToScript(color);
}

void ImageWidgetBridge::setImageColor(ImageWidget* self,
                                      ScriptObject scriptObject)
{
}


ScriptObject ImageWidgetBridge::getFillMode(ImageWidget* self)
{
  return ScriptObject(serializeFillMode(self->getFillMode()));
}

void ImageWidgetBridge::setFillMode(ImageWidget* self, ScriptObject value)
{
  ImageWidget::FillMode mode = deserializeFillMode(value.asString());
  self->setFillMode(mode);
}

ScriptObject ImageWidgetBridge::getSource(ImageWidget* self)
{
  if (self->getSourceImage())
  {
    return wrapExistingNativeObject(self->getSourceImage());
  }
  else
  {
    return self->getSource();
  }
}

void ImageWidgetBridge::setSource(ImageWidget* self, ScriptObject value)
{
  // load via URI
  if (value.isString())
  {
    self->setSource(value.asString());
  }
  // load via buffer
  else if (value.isArrayBuffer())
  {
    self->setSource(value.getDataBuffer());
  }
  // load via existing image object
  else
  {
    self->setSource(unwrapNativeObject<Image>(value));
  }
}

ScriptObject ImageWidgetBridge::getOnReady(ImageWidget* self)
{
  if (readyCallbacks.count(self))
  {
    return readyCallbacks[self];
  }
  else
  {
    return ScriptObject::Null();
  }
}


void ImageWidgetBridge::setOnReady(ImageWidget* self, ScriptObject value)
{
  ScriptFunction callback = value.asFunction();
  self->setOnReady(registerReadyCallback(self, callback));
}

ImageWidgetReadyCallback ImageWidgetBridge::registerReadyCallback(ImageWidget* self, ScriptFunction onReady)
{
  ImageWidgetReadyCallback readyCallback = std::bind(invokeReadyCallback, self, onReady, std::placeholders::_1);
  readyCallbacks[self] = onReady;
  return readyCallback;
}

void ImageWidgetBridge::unregisterReadyCallback(ImageWidget* self)
{
  if (readyCallbacks.count(self))
  {
    readyCallbacks.erase(self);
  }
}

void ImageWidgetBridge::invokeReadyCallback(ImageWidget* self, const ScriptFunction& callback, bool success)
{
  ScriptArray args;
  args.set(0, ScriptObject(success));
  callback.invoke(args);

  //once invoked, it need not be invoked again, so unregister it
  unregisterReadyCallback(self);
}

ImageWidget::FillMode ImageWidgetBridge::deserializeFillMode(const std::string& alignment)
{
  if (compareStrChar(alignment, "stretch"))
  {
    return ImageWidget::FillMode::Stretch;
  }
  else if (compareStrChar(alignment, "fit"))
  {
    return ImageWidget::FillMode::Fit;
  }
  else if (compareStrChar(alignment, "top"))
  {
    return ImageWidget::FillMode::Top;
  }
  else if (compareStrChar(alignment, "top-left"))
  {
    return ImageWidget::FillMode::Top_Left;
  }
  else if (compareStrChar(alignment, "top-right"))
  {
    return ImageWidget::FillMode::Top_Right;
  }
  else if (compareStrChar(alignment, "left"))
  {
    return ImageWidget::FillMode::Left;
  }
  else if (compareStrChar(alignment, "right"))
  {
    return ImageWidget::FillMode::Right;
  }
  else if (compareStrChar(alignment, "center"))
  {
    return ImageWidget::FillMode::Center;
  }
  else if (compareStrChar(alignment, "bottom-left"))
  {
    return ImageWidget::FillMode::Bottom_Left;
  }
  else if (compareStrChar(alignment, "bottom"))
  {
    return ImageWidget::FillMode::Bottom;
  }
  else if (compareStrChar(alignment, "bottom-right"))
  {
    return ImageWidget::FillMode::Bottom_Right;
  }
  else if (compareStrChar(alignment, "vertical-fit"))
  {
	  return ImageWidget::FillMode::Vertical_Fit;
  }
  else if (compareStrChar(alignment, "horizontal-fit"))
  {
	  return ImageWidget::FillMode::Horizontal_Fit;
  }
  else if (compareStrChar(alignment, "top-crop")) 
  {
  	return ImageWidget::FillMode::Top_Crop;
  }
  else if (compareStrChar(alignment, "top-left-crop")) 
  {
  	return ImageWidget::FillMode::Top_Left_Crop;
  }
  else if (compareStrChar(alignment, "top-right-crop")) 
  {
  	return ImageWidget::FillMode::Top_Right_Crop;
  }
  else if (compareStrChar(alignment, "left-crop")) 
  {
  	return ImageWidget::FillMode::Left_Crop;
  }
  else if (compareStrChar(alignment, "right-crop"))
  {
  	return ImageWidget::FillMode::Right_Crop;
  }
  else if (compareStrChar(alignment, "center-crop"))
  {
  	return ImageWidget::FillMode::Center_Crop;
  }
  else if (compareStrChar(alignment, "bottom-left-crop")) 
  {
  	return ImageWidget::FillMode::Bottom_Left_Crop;
  }
  else if (compareStrChar(alignment, "bottom-crop")) 
  {
  	return ImageWidget::FillMode::Bottom_Crop;
  }
  else if (compareStrChar(alignment, "bottom-right-crop")) 
  {
  	return ImageWidget::FillMode::Bottom_Right_Crop;
  }
  else
  {
    return ImageWidget::FillMode::Stretch;
  }
}

std::string ImageWidgetBridge::serializeFillMode(const ImageWidget::FillMode alignment)
{
  switch (alignment)
  {
  case ImageWidget::FillMode::Stretch:
    return "stretch";
  case ImageWidget::FillMode::Fit:
    return "fit";
  case ImageWidget::FillMode::Top:
    return "top";
  case ImageWidget::FillMode::Top_Left:
    return "top-left";
  case ImageWidget::FillMode::Top_Right:
    return "top-right";
  case ImageWidget::FillMode::Left:
    return "left";
  case ImageWidget::FillMode::Right:
    return "right";
  case ImageWidget::FillMode::Center:
    return "center";
  case ImageWidget::FillMode::Bottom_Left:
    return "bottom-left";
  case ImageWidget::FillMode::Bottom:
    return "bottom";
  case ImageWidget::FillMode::Bottom_Right:
    return "bottom-right";
  case ImageWidget::FillMode::Vertical_Fit:
	  return "vertical-fit";
  case ImageWidget::FillMode::Horizontal_Fit:
	  return "horizontal-fit";
  case ImageWidget::FillMode::Top_Crop:		   
		return "top-crop";
  case ImageWidget::FillMode::Top_Left_Crop:	   
		return "top-left-crop";
	case ImageWidget::FillMode::Top_Right_Crop:
	  return "top-right-crop";
	  case ImageWidget::FillMode::Left_Crop:
		return "left-crop";
case ImageWidget::FillMode::Center_Crop:	 
	  return "center-crop";
	  case ImageWidget::FillMode::Right_Crop:
		return "right-crop";
  case ImageWidget::FillMode::Bottom_Left_Crop:  
		return "bottom-left-crop";
	case ImageWidget::FillMode::Bottom_Crop:	   
		return "bottom-crop";
	case ImageWidget::FillMode::Bottom_Right_Crop: 
		return "bottom-right-crop";

  default:
    return "stretch";
  }
}

ScriptObject ImageWidgetBridge::getColorPicking(ImageWidget* self, const ScriptArray& args)
{
  int percentage = 10;
	int x1 = 0, x2= 0, y1 = 0, y2 = 0;

  if (args.has(0) && args[0].isNumber())
  {
		if (args.Length() == 1)
		{
			percentage = args[0].asNumber();
		}
		else
		{
			percentage = 0;
			x1 = args[0].asNumber();
		}
  }
  if (args.has(1) && args[1].isNumber())
  {
    y1 = args[1].asNumber();
  }
  if (args.has(2) && args[2].isNumber())
  {
	  x2 = args[2].asNumber();
  }
  if (args.has(3) && args[3].isNumber())
  {
    y2 = args[3].asNumber();
  }

  Color color;
  ScriptObject retval = ScriptObject();
  retval.set("success", ScriptObject(self->getColorPicking(percentage, x1, x2, y1, y2, &color)));
  ScriptObject colval = ScriptObject();
  colval.set("r", ScriptObject((double)color.r));
  colval.set("g", ScriptObject((double)color.g));
  colval.set("b", ScriptObject((double)color.b));
  colval.set("a", ScriptObject((double)color.a));
  retval.set("color", colval);

  return retval;
}

ScriptObject ImageWidgetBridge::getImageCroppedCoord(ImageWidget* self, const ScriptArray& args)
{
	float x1 = 0, y1 = 0, x2 = 0, y2= 0;

	ScriptObject retval = ScriptObject();
	retval.set("success", ScriptObject(self->getImageCroppedCoord(&x1, &y1, &x2, &y2)));
	ScriptObject coordVal = ScriptObject();
	coordVal.set("x1", ScriptObject(x1));
	coordVal.set("y1", ScriptObject(y1));
	coordVal.set("x2", ScriptObject(x2));
	coordVal.set("y2", ScriptObject(y2));
	retval.set("coord", coordVal);

return retval;
}

} /* namespace Bridge */


