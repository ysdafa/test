/*
 * ScriptTypes.cpp
 *
 *  Created on: May 17, 2013
 *      Author: reza
 */

#include "ScriptTypes.h"
#include "Exception.h"
#include "StaticUI.h"
#include <cmath>
#ifdef BLOCK_GFX_ON_JS_FUNC
#include "VoltMessageCenter.h"
#include "VoltRuntimeMessages.h"
#endif

#ifdef BLOCK_GFX_ON_JS_FUNC
#include "VoltMessageCenter.h"
#include "VoltRuntimeMessages.h"
#endif

//Script wrapper definitions:

using namespace v8;
using namespace Bridge;
using namespace volt::util;

void ScriptObject::weakCallback(const WeakCallbackData<Value, ScriptObjectData > &weakCallbackData)
{
  ScriptObjectData* scriptObjectData = weakCallbackData.GetParameter();
  delete scriptObjectData;
}

//ScriptObject:

//Just value empty.
ScriptObject::ScriptObject()
  : data(nullptr)
{
}

ScriptObject::ScriptObject(Handle<Object> obj)
  : data(nullptr)
{
  if(not tryReuseExistingData(obj)) //if there's external data reuse the existing ScriptObjectData
  {
    data = new ScriptObjectData( obj );
  }

  if(obj->IsArrayBuffer())
  {
    extractArrayBufferMemory();
  }
}

ScriptObject::ScriptObject(v8::Handle<v8::Value> val)
  : data(nullptr)
{
  //If the value is an object, it might have external data
  if(val->IsObject())
  {
    if(tryReuseExistingData(val->ToObject()))
    {
      return;
    }
  }

  // allocate new ScriptObjectData
  data = new ScriptObjectData( val );

  if(not val.IsEmpty() and val->IsArrayBuffer())
  {
    extractArrayBufferMemory();
  }
}

ScriptObject::ScriptObject(bool boolType)
  : data(nullptr)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData( Boolean::New(Isolate::GetCurrent(), boolType) );
}

ScriptObject::ScriptObject(double numberType)
  : data(nullptr)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData( Number::New(Isolate::GetCurrent(), numberType) );
}

ScriptObject::ScriptObject(int numberType)
  : data(nullptr)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData( Number::New(Isolate::GetCurrent(), (double)numberType) );
}


ScriptObject::ScriptObject(std::string stringType)
  : data(nullptr)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData(StringToV8(stringType));
}

ScriptObject::ScriptObject(DataBuffer::SharedPtr stringBuffer)
  : data(nullptr)
{
  HandleScope scope(Isolate::GetCurrent());

  data = new ScriptObjectData(DataBufferToV8(stringBuffer));
}

ScriptObject::ScriptObject(const char* stringType)
  : data(nullptr)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData(String::NewFromUtf8(Isolate::GetCurrent(), stringType));
}

ScriptObject ScriptObject::Null()
{
  HandleScope scope(Isolate::GetCurrent());
  Handle<Value> v8Null = v8::Null(Isolate::GetCurrent());
  return ScriptObject(v8Null);
}

ScriptObject::~ScriptObject()
{
  cleanup();
}

/* Copy Constructor */
ScriptObject::ScriptObject(const ScriptObject& that): data(that.data)
{
  if(data)
  {
    ++(data->refCount);
  }
}

ScriptObject& ScriptObject::operator=(const ScriptObject& that)
{
  if(this != &that)
  {
    cleanup();
    data = that.data;

    if (data)
    {
      ++(data->refCount);
    }
  }

  return *this;
}

void ScriptObject::cleanup()
{
  if (!data)
  {
    return;
  }

  --(data->refCount);

  if((data->refCount) == 0)
  {
    /*If there is external data attached to this object, then we only mark weak
    so that it will be cleaned up later by the V8 garbage collector. If no external data,
    then it should be safe to destroy our internal data (which is just a persistent handle.*/
    if(data->buffer.get() and data->buffer->data() != nullptr)
    {
      data->persistentValue.SetWeak(data, weakCallback);
    }
    else
    {
      delete data;
    }
  }
}

bool ScriptObject::tryReuseExistingData(v8::Handle<Object> obj)
{
  Local<Value> externalOrEmpty = obj->GetHiddenValue(StringToV8("ExternalData"));

  if( !externalOrEmpty.IsEmpty() && externalOrEmpty->IsExternal())
  {
    //If the object had external data attached, then there is already an existing
    //ScriptObjectData for it. Take ownership of that instead instead of creating a new one
    Local<External> external = Local<External>::Cast(externalOrEmpty);
    data = reinterpret_cast<ScriptObjectData*>( external->Value() );

    if(data->persistentValue.IsWeak())
    {
      data->persistentValue.ClearWeak();
    }

    ++(data->refCount);
    return true;
  }

  return false;
}

Handle<Value> ScriptObject::getValue() const
{
  EscapableHandleScope scope(Isolate::GetCurrent());

  if( data == nullptr || data->persistentValue.IsEmpty())
  {
    return Undefined(Isolate::GetCurrent());
  }
  else
  {
    return scope.Escape( Local<Value>::New(Isolate::GetCurrent(), data->persistentValue ));
  }
}

bool ScriptObject::isObject() const
{
  HandleScope scope(Isolate::GetCurrent());
  return getValue()->IsObject();
}


Handle<Object> ScriptObject::getObjectUnsafe() const
{
  return getValue()->ToObject();
}

//Lookup
bool ScriptObject::has(const std::string& key) const
{
  HandleScope scope(Isolate::GetCurrent());

  if(isObject())
  {
    return getObjectUnsafe()->Has(StringToV8(key));
  }
  else
  {
    return false;
  }
}

ScriptObject ScriptObject::get(const std::string& key) const
{
  HandleScope scope(Isolate::GetCurrent());

  if(has(key))
  {
    return ScriptObject(getObjectUnsafe()->Get(StringToV8(key)));
  }
  else
  {
    throw VoltJsRuntimeException( (std::string("Object does not contain expected key \"") + key + std::string("\"")).c_str() );
  }
}

bool ScriptObject::tryGet(const std::string& key, ScriptObject& result) const
{
  HandleScope scope(Isolate::GetCurrent());
  bool hasKey = has(key);

  if(hasKey)
  {
    result = ScriptObject(getObjectUnsafe()->Get(StringToV8(key)));
  }

  return hasKey;
}

void ScriptObject::set(const std::string& key, const ScriptObject &item)
{
  v8::TryCatch try_catch;
  HandleScope scope(Isolate::GetCurrent());

  if (data == nullptr)
  {
    //It becomes a real object when it has a property set. If it was empty before it would just be undefined
    data = new ScriptObjectData(Object::New(Isolate::GetCurrent()));
  }
  else
  {
    Handle<Value> value = getValue();

    if(value.IsEmpty() || value->IsUndefined())
    {
      if(isObject())
      {
        throw VoltScripObjectHandlingException("Failed to execute function");
      }

      //It becomes a real object when it has a property set. If it was empty before it would just be undefined
      data->persistentValue.Reset(Isolate::GetCurrent(), Object::New(Isolate::GetCurrent()));
    }
  }

  getObjectUnsafe()->Set( StringToV8(key), item.getValue() );
}

bool ScriptObject::asBool() const
{
  HandleScope scope(Isolate::GetCurrent());

  if (isBool())
  {
    return getValue()->IsTrue();
  }
  else
  {
    throw VoltJsBadTypeException("Boolean expected");
  }
}

double ScriptObject::asNumber() const
{
  HandleScope scope(Isolate::GetCurrent());

  if(isNumber())
  {
    double numberValue = getValue()->ToNumber()->Value();

    if (!isnan(numberValue))
    {
      return numberValue;
    }
  }

  throw VoltJsBadTypeException("Number expected");
}

std::string ScriptObject::asString() const
{
  HandleScope scope(Isolate::GetCurrent());

  if(isString())
  {
    return V8ToString(getValue()->ToString());
  }

  throw VoltJsBadTypeException("String expected");
}

const DataBuffer::SharedPtr ScriptObject::asStringDataBuffer() const
{
  HandleScope scope(Isolate::GetCurrent());

  if(not isString())
  {
    throw VoltJsBadTypeException("String expected");
  }

  Handle<String> stringValue = getValue()->ToString();

  if(stringValue->IsExternalAscii())
  {
    // try extract ascii
    const String::ExternalAsciiStringResource *ascii = stringValue->GetExternalAsciiStringResource();

    if(ascii)
    {
      // direct cast to our type since we are the only one using this..
      // this is messy though..
      const ScriptStringResourceBase *scriptResource = (const ScriptStringResourceBase *) ascii;
      return scriptResource->GetSharedBuffer();
    }
  }
  // try extract utf8 string
  else if(stringValue->IsExternal())
  {
    const String::ExternalStringResource *string = stringValue->GetExternalStringResource();

    if(string)
    {
      const ScriptStringResourceBase *scriptResource = (const ScriptStringResourceBase *) string;
      return scriptResource->GetSharedBuffer();
    }
  }

  return V8ToStringDataBuffer(getValue()->ToString());
}

ScriptArray ScriptObject::asArray() const
{
  HandleScope scope(Isolate::GetCurrent());

  if (isArray())
  {
    Handle<Array> array;
    return ScriptArray(array.Cast(getValue()));
  }
  else
  {
    throw VoltJsBadTypeException("Array expected");
  }
}

ScriptArrayBuffer ScriptObject::asArrayBuffer() const
{
  HandleScope scope(Isolate::GetCurrent());

  if (isArrayBuffer())
  {
    Handle<ArrayBuffer> arrayBuffer;
    return ScriptArrayBuffer(arrayBuffer.Cast(getValue()));
  }
  else
  {
    throw VoltJsBadTypeException("Array Buffer expected");
  }
}

ScriptFunction ScriptObject::asFunction() const
{
  HandleScope scope(Isolate::GetCurrent());

  if (isFunction())
  {
    Handle<Function> funct;
    return ScriptFunction(funct.Cast(getValue()));
  }
  else
  {
    throw VoltJsBadTypeException("Function expected");
  }
}

bool ScriptObject::tryGetBool(const std::string& key, bool& result) const
{
  HandleScope scope(Isolate::GetCurrent());

  if(has(key))
  {
    ScriptObject obj(getObjectUnsafe()->Get(StringToV8(key)));

    if (obj.isBool())
    {
      result = obj.getValue()->IsTrue();
      return true;
    }
  }

  return false;
}

bool ScriptObject::tryGetNumber(const std::string& key, double& result) const
{
  HandleScope scope(Isolate::GetCurrent());

  if(has(key))
  {
    ScriptObject obj(getObjectUnsafe()->Get(StringToV8(key)));

    if (obj.isNumber())
    {
      result = obj.getValue()->ToNumber()->Value();
      return !isnan(result);
    }
  }

  return false;
}

bool ScriptObject::tryGetString(const std::string& key, std::string& result) const
{
  HandleScope scope(Isolate::GetCurrent());

  if(has(key))
  {
    ScriptObject obj(getObjectUnsafe()->Get(StringToV8(key)));

    if (obj.isString())
    {
      result = V8ToString(obj.getValue()->ToString());
      return true;
    }
  }

  return false;
}

ScriptArray ScriptObject::getKeyNames() const
{
  HandleScope scope(Isolate::GetCurrent());
  Handle<Value> value = getValue();

  if(value.IsEmpty() || value->IsUndefined() || !isObject())
  {
    return ScriptArray();
  }

  return ScriptArray(getObjectUnsafe()->GetOwnPropertyNames());
}

void ScriptObject::associateExternalDataWithJSObject(const DataBuffer::SharedPtr &aBuffer)
{
  if(data)
  {
    Local<External> external = External::New(Isolate::GetCurrent(), reinterpret_cast<void*>(data) );
    getObjectUnsafe()->SetHiddenValue( StringToV8("ExternalData"), external);
    data->SetExternalData(aBuffer);
  }
}

void ScriptObject::extractArrayBufferMemory()
{
  // we are done already
  if(data and data->buffer.get() and data->buffer->data() != nullptr)
  {
    return;
  }

  Handle<ArrayBuffer> tempArrayBuffer;
  Handle<ArrayBuffer> arrayBuffer = tempArrayBuffer.Cast(getValue());

  // memory has not been externalized, we need to extract it
  if(not arrayBuffer->IsExternal())
  {
    // LOG_DEBUG(logger_, "taking array buffer memory ownership from V8");

    v8::ArrayBuffer::Contents contents = arrayBuffer->Externalize();

    DataBuffer::SharedPtr buffer(new DataBuffer(reinterpret_cast<uint8_t *>(contents.Data()), contents.ByteLength()));
    associateExternalDataWithJSObject(buffer);
  }
}

DataBuffer::SharedPtr ScriptObject::getDataBuffer() const
{
  if(not data or (not data->buffer.get()))
  {
    throw VoltJsRuntimeException( (std::string("null data or shared buffer\"")).c_str() );
  }

  return data->buffer->getSharedPtr();
}

bool Bridge::operator==(const ScriptObject& lhs, const ScriptObject& rhs)
{
  return lhs.data->persistentValue == rhs.data->persistentValue; //should we use lhs.value->StrictEquals(rhs) instead? This should be like calling js ===
}


//Functions
ScriptFunction::ScriptFunction(v8::Handle<v8::Function> wrappedFunction)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData( wrappedFunction );
}


Handle<Function> ScriptFunction::getInternalFunction() const
{
  //HandleScope scope(Isolate::GetCurrent());
  return Handle<Function>::Cast(getValue());
}

ScriptObject ScriptFunction::invoke(ScriptArray args) const
{
  TryCatch try_catch;
  HandleScope scope(Isolate::GetCurrent());
  uint size = args.Length();
  Handle<Value> parameters[size];

  for(uint i = 0; i < size; i++)
  {
    parameters[i] = args[i].getValue();
  }

  Handle<Function> function =  getInternalFunction();
#ifdef BLOCK_GFX_ON_JS_FUNC
  VoltMessageCenter::Instance().PostMsgToGfx(VoltRuntimeMsg::PauseGfx());
#endif
  Handle<Value> result = function->Call(function, size, parameters);
#ifdef BLOCK_GFX_ON_JS_FUNC
  VoltMessageCenter::Instance().PostMsgToGfx(VoltRuntimeMsg::ResumeGfx());
#endif

  if (result.IsEmpty())
  {
    std::string msg("Failed to execute a JS function: ");
    msg += V8ToString(function->GetName()->ToString());
    VoltJsRuntimeException e(msg.c_str());
    SET_JS_ERR_INFO(e, try_catch);
    volt::StaticUI::Instance().ShowExceptionPopup("Encountered fatal error", &e);
    return ScriptObject(); //return undefined
  }

  return ScriptObject(result);
}


ScriptException::ScriptException(std::string message)
  : exceptionMessage(message)
{
  HandleScope scope(Isolate::GetCurrent());
  Handle<Value> exceptionValue = Isolate::GetCurrent()->ThrowException(StringToV8(exceptionMessage));
  data = new ScriptObjectData( exceptionValue );
}

//Script Array
ScriptArray::ScriptArray(): argsArray(nullptr), useArgsArray(false)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData(Array::New(Isolate::GetCurrent()));
}

ScriptArray::ScriptArray(Arguments* args): argsArray(args), useArgsArray(true)
{
  HandleScope scope(Isolate::GetCurrent());
  //still intialialize the internal array...
  data = new ScriptObjectData(Array::New(Isolate::GetCurrent()));
}

ScriptArray::ScriptArray(Handle<Array> arr): argsArray(nullptr), useArgsArray(false)
{
  HandleScope scope(Isolate::GetCurrent());
  data = new ScriptObjectData(arr);
}

ScriptArray::ScriptArray(const ScriptObject &obj) : argsArray(nullptr), useArgsArray(false)
{
  HandleScope scope(Isolate::GetCurrent());

  if(obj.isArray())
  {
    data = new ScriptObjectData(obj.getValue());
  }
  else
  {
    data = new ScriptObjectData(Array::New(Isolate::GetCurrent()));
  }
}

Handle<Array> ScriptArray::getInternalArray() const
{
  Handle<Array> array;
  return array.Cast(getValue());
}

Handle<Value> ScriptArray::accessIndex(int index) const
{
  EscapableHandleScope scope(Isolate::GetCurrent());
  Local<Value> requestedValue;

  if(useArgsArray)
  {
    if(argsArray->Length() > index)
    {
      requestedValue = (*argsArray)[index];
    }
  }
  else
  {
    Handle<Array> array = getInternalArray();

    if(array->Has(index))
    {
      requestedValue = array->Get(index);
    }
  }

  return scope.Escape(requestedValue);
}

//Lookup
uint ScriptArray::Length() const
{
  HandleScope scope(Isolate::GetCurrent());

  if(useArgsArray)
  {
    return argsArray->Length();
  }
  else
  {
    return getInternalArray()->Length();
  }
}

bool ScriptArray::has(uint index) const
{
  HandleScope scope(Isolate::GetCurrent());

  if(useArgsArray)
  {
    return (Length() > index);
  }
  else
  {
    return getInternalArray()->Has(index);
  }
}

ScriptObject ScriptArray::get(uint index) const
{
  HandleScope scope(Isolate::GetCurrent());

  if (has(index))
  {
    return ScriptObject(accessIndex(index));
  }
  else
  {
    std::string error = (useArgsArray) ? "Argument expected at index " : "Attempt to access array at index ";
    error = error + std::to_string(index) + " failed";
    throw VoltJsRuntimeException( error.c_str() );
  }
}

bool ScriptArray::tryGet(uint index, ScriptObject& result) const
{
  HandleScope scope(Isolate::GetCurrent());

  if(has(index))
  {
    result = ScriptObject(accessIndex(index));
    return true;
  }

  return false;
}

void ScriptArray::set(uint index, const ScriptObject &item)
{
  HandleScope scope(Isolate::GetCurrent());
  getInternalArray()->Set(index, item.getValue());
  //argsArray would never be used here because function arguments are read only as far as
  //we're concerned.
}

void* ScriptArrayBufferAllocator::Allocate(size_t length)
{
  return new uint8_t[length];
}

void* ScriptArrayBufferAllocator::AllocateUninitialized(size_t length)
{
  return new uint8_t[length];
}

void ScriptArrayBufferAllocator::Free(void* data, size_t length)
{
  if(data)
  {
    delete[] (uint8_t*)data;
  }
}

//Script Array Buffer
ScriptArrayBuffer::ScriptArrayBuffer(size_t length)
{
  HandleScope scope(Isolate::GetCurrent());

  data = new ScriptObjectData( ArrayBuffer::New( Isolate::GetCurrent(), length) );
  extractArrayBufferMemory();
}

ScriptArrayBuffer::ScriptArrayBuffer(const void *aData, const int aLength)
{
  HandleScope scope(Isolate::GetCurrent());

  //LOG_DEBUG(logger_, "construct array buffer, length " << aLength);

  /* The data allocated here will be deleted in
  * DisposeScriptObjectPersistentHandle.
  * we are making a copy of aData inside external_data */
  DataBuffer::SharedPtr buffer(new DataBuffer(reinterpret_cast<const uint8_t *>(aData), aLength));

  data = new ScriptObjectData( ArrayBuffer::New(Isolate::GetCurrent(), (void*)buffer->data(), buffer->length()));

  associateExternalDataWithJSObject(buffer);
}

ScriptArrayBuffer::ScriptArrayBuffer(const DataBuffer::SharedPtr &aBuffer)
{
  HandleScope scope(Isolate::GetCurrent());

  //LOG_DEBUG(logger_, "construct array buffer, length " << aLength);

  data = new ScriptObjectData( ArrayBuffer::New(Isolate::GetCurrent(), (void*)aBuffer->data(), aBuffer->length()));

  associateExternalDataWithJSObject(aBuffer);
}

ScriptArrayBuffer::ScriptArrayBuffer(Handle<ArrayBuffer> arr)
{
  HandleScope scope(Isolate::GetCurrent());

  data = new ScriptObjectData( arr );
  extractArrayBufferMemory();
}

ScriptArrayBuffer::~ScriptArrayBuffer()
{
}

// ScriptStringResourceBase base class
ScriptStringResourceBase::ScriptStringResourceBase(volt::util::DataBuffer::SharedPtr &aBuffer, EncodingType type)
  : mType(type)
{
  if(aBuffer.get())
  {
    mBuffer = aBuffer->shared_from_this();
  }
  else
  {
    mBuffer = DataBuffer::SharedPtr(new DataBuffer());
  }
}

ScriptStringResourceBase::~ScriptStringResourceBase()
{
}

const volt::util::DataBuffer::SharedPtr ScriptStringResourceBase::GetSharedBuffer() const
{
  return mBuffer->getSharedPtr();
}

ScriptStringResourceBase::EncodingType ScriptStringResourceBase::GetType()
{
  return mType;
}

// ascii resource class
ScriptAsciiStringResource::ScriptAsciiStringResource(volt::util::DataBuffer::SharedPtr &aBuffer)
  : ScriptStringResourceBase(aBuffer, Ascii)
{
}

ScriptAsciiStringResource::~ScriptAsciiStringResource()
{
}

const char* ScriptAsciiStringResource::data() const
{
  return mBuffer->c_str();
}

size_t ScriptAsciiStringResource::length() const
{
  return mBuffer->length();
}

// string resource class
ScriptStringResource::ScriptStringResource(volt::util::DataBuffer::SharedPtr &aBuffer)
  : ScriptStringResourceBase(aBuffer, Utf8)
{
}

ScriptStringResource::~ScriptStringResource()
{
}

const uint16_t* ScriptStringResource::data() const
{
  return (const uint16_t*)mBuffer->c_str();
}

size_t ScriptStringResource::length() const
{
  if(mBuffer->length() & 0x01)
  {
    return (mBuffer->length() << 1) + 1;
  }

  return mBuffer->length() << 1;
}
