/*
 * FirstScreenListWidgetBridge.cpp
 *
 *  Created on: Oct 1, 2014
 *      Author: backki.kim
 */

#include "FirstScreenListWidgetBridge.h"
#include "event_manager.h"

using namespace volt::util;
using namespace volt::graphics;

namespace Bridge
{

static volt::util::Logger logger;
	
void FirstScreenListWidgetBridge::mapScriptInterface(ScriptContext& aContext)
{
	aContext.captureMethodCall<FirstScreenListWidget, &addCategory>("addCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &addContents>("addContents");
	aContext.captureMethodCall<FirstScreenListWidget, &moveLeft>("moveLeft");
	aContext.captureMethodCall<FirstScreenListWidget, &moveRight>("moveRight");
	aContext.captureMethodCall<FirstScreenListWidget, &enableMoveToBegin>("enableMoveToBegin");
	aContext.captureMethodCall<FirstScreenListWidget, &enableMoveToEnd>("enableMoveToEnd");
	aContext.captureMethodCall<FirstScreenListWidget, &setFocus>("setFocus");
	aContext.captureMethodCall<FirstScreenListWidget, &removeCategory>("removeCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &removeContents>("removeContents");
	aContext.captureMethodCall<FirstScreenListWidget, &sendEnterSignal>("sendEnterSignal");
	aContext.captureMethodCall<FirstScreenListWidget, &getCategory>("getCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &getContents>("getContents");
	aContext.captureMethodCall<FirstScreenListWidget, &findContents>("findContents");
	aContext.captureMethodCall<FirstScreenListWidget, &findCategory>("findCategory");
	aContext.captureMethodCall<FirstScreenListWidget, &riseFirstScreen>("riseFirstScreen");
	aContext.captureMethodCall<FirstScreenListWidget, &stopTransition>("stopTransition");
	aContext.captureMethodCall<FirstScreenListWidget, &getPositionX>("getPositionX");
	aContext.captureMethodCall<FirstScreenListWidget, &getPositionY>("getPositionY");
	aContext.captureMethodCall<FirstScreenListWidget, &changeIcon>("changeIcon");
	aContext.captureMethodCall<FirstScreenListWidget, &reverseOSD>("reverseOSD");
	aContext.captureMethodCall<FirstScreenListWidget, &fallFirstScreen>("fallFirstScreen");
	aContext.captureMethodCall<FirstScreenListWidget, &off_transition_noanimaition>("off_transition_noanimaition");
	aContext.captureMethodCall<FirstScreenListWidget, &setFirstState>("setFirstState");
	aContext.captureMethodCall<FirstScreenListWidget, &returnAnimation>("returnAnimation");
	aContext.captureMethodCall<FirstScreenListWidget, &addSubMain>("addSubMain");
	aContext.captureMethodCall<FirstScreenListWidget, &changeContentLive>("changeContentLive");
	aContext.captureMethodCall<FirstScreenListWidget, &getCategoryIndexByID>("getCategoryIndexByID");
	aContext.captureMethodCall<FirstScreenListWidget, &setProgress>("setProgress");
	aContext.captureMethodCall<FirstScreenListWidget, &callExtendAnimation>("callExtendAnimation");
	aContext.captureMethodCall<FirstScreenListWidget, &callExtendAnimationEx>("callExtendAnimationEx");
	aContext.captureMethodCall<FirstScreenListWidget, &focusOptions>("focusOptions");
	aContext.captureMethodCall<FirstScreenListWidget, &unfocusOptions>("unfocusOptions");
	aContext.captureMethodCall<FirstScreenListWidget, &enterOptions>("enterOptions");
	aContext.captureMethodCall<FirstScreenListWidget, &setExtendBezierAndTime>("setExtendBezierAndTime");
	aContext.captureMethodCall<FirstScreenListWidget, &setLiveImageBezierAndTime>("setLiveImageBezierAndTime");
	aContext.captureMethodCall<FirstScreenListWidget, &setHorizontalFoveaBezier>("setHorizontalFoveaBezier");
	aContext.captureMethodCall<FirstScreenListWidget, &setVerticalFoveaBezier>("setVerticalFoveaBezier");
	aContext.captureMethodCall<FirstScreenListWidget, &setContentLiveBezierAndTime>("setContentLiveBezierAndTime");
	aContext.captureMethodCall<FirstScreenListWidget, &setTransitionBezierAndTime>("setTransitionBezierAndTime");
	aContext.captureMethodCall<FirstScreenListWidget, &enlarge>("enlarge");
	aContext.captureMethodCall<FirstScreenListWidget, &highContrast>("highContrast");
	aContext.captureMethodCall<FirstScreenListWidget, &setKeyPrevent>("setKeyPrevent");
	aContext.captureMethodCall<FirstScreenListWidget, &setNomalTextColor>("setNomalTextColor");

	aContext.captureMethodCall<FirstScreenListWidget, &updateDominantColor>("updateDominantColor");
	aContext.captureMethodCall<FirstScreenListWidget, &startFovea>("startFovea");
	aContext.captureMethodCall<FirstScreenListWidget, &stopFovea>("stopFovea");
	aContext.captureMethodCall<FirstScreenListWidget, &getLastMouseMovedTime>("getLastMouseMovedTime");

	aContext.captureMethodCall<FirstScreenListWidget, &setBarOpacityMax>("setBarOpacityMax");
	aContext.captureMethodCall<FirstScreenListWidget, &setBarOpacityZero>("setBarOpacityZero");
	aContext.captureMethodCall<FirstScreenListWidget, &setOnBackgroundClickListener>("setOnBackgroundClickListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setOnMoveFocuseListener>("setOnMoveFocuseListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setOnScrollLeftEndListener>("setOnScrollLeftEndListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setOnScrollRightEndListener>("setOnScrollRightEndListener");
	//begin junhui.wang
	aContext.captureMethodCall<FirstScreenListWidget, &changeControler>("changeControler");
	aContext.captureMethodCall<FirstScreenListWidget, &setDim>("setDim");
	//end junhui.wang


	aContext.captureMethodCall<FirstScreenListWidget, &popupContextMenu>("popupContextMenu");
	aContext.captureMethodCall<FirstScreenListWidget, &hideContextMenu>("hideContextMenu");
	aContext.captureMethodCall<FirstScreenListWidget, &selectContextMenuItem>("selectContextMenuItem");
	aContext.captureMethodCall<FirstScreenListWidget, &removeProgressAndDim>("removeProgressAndDim");
	aContext.captureMethodCall<FirstScreenListWidget, &setContextMenuFeedbackListener>("setContextMenuFeedbackListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setContextMenuFocusListener>("setContextMenuFocusListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setContextMenuUnfocusListener>("setContextMenuUnfocusListener");
	aContext.captureMethodCall<FirstScreenListWidget, &setContextMenuFlag>("setContextMenuFlag");

	aContext.captureMethodCall<FirstScreenListWidget, &scaleLeft>("scaleLeft");
	aContext.captureMethodCall<FirstScreenListWidget, &recoverLeft>("recoverLeft");
    aContext.captureMethodCall<FirstScreenListWidget, &scaleRight>("scaleRight");
    aContext.captureMethodCall<FirstScreenListWidget, &recoverRight>("recoverRight");
	// shuhao.yan
	aContext.captureMethodCall<FirstScreenListWidget, &setADClickListener>("setADClickListener");
    aContext.captureMethodCall<FirstScreenListWidget, &setADEnterListener>("setADEnterListener");
	//liang.wu
	aContext.captureMethodCall<FirstScreenListWidget, &addAdImg>("addAdImg");
	aContext.captureMethodCall<FirstScreenListWidget, &addHistoryLive>("addHistoryLive");
	aContext.captureMethodCall<FirstScreenListWidget, &removeHistoryLive>("removeHistoryLive");
	aContext.captureMethodCall<FirstScreenListWidget, &addFeaturedLive>("addFeaturedLive");
	aContext.captureMethodCall<FirstScreenListWidget, &removeFeaturedLive>("removeFeaturedLive");
	aContext.captureMethodCall<FirstScreenListWidget, &enableFeaturedLive>("enableFeaturedLive");
}

Widget* FirstScreenListWidgetBridge::constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args)
{
	LOG_DEBUG(logger, "FirstScreenListWidgetBridge::constructWidget");
	FirstScreenListWidget* listWidget = new FirstScreenListWidget(parent, args);
	
	return listWidget;
}

ScriptObject FirstScreenListWidgetBridge::addCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	LOG_DEBUG(logger, "FirstScreenListWidgetBridge::addCategory");
	
	FirstScreenCategory* item = new FirstScreenCategory();
	
	ScriptObject options = args[0];
	item->jsInstance = options;
	
	if(options.has("categoryWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("categoryWrapper"));
		item->categoryWrapper = wzd->getActor();
    }
	
	if(options.has("categoryTitle"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("categoryTitle"));
		item->categoryTitle = wzd->getActor();
    }
	
	if(options.has("listWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("listWrapper"));
		item->listWrapper = wzd->getActor();
    }
	
	if(options.has("color"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("color"));
		item->color = wzd->getActor();
    }
	
	if(options.has("liveParent1"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("liveParent1"));
		item->liveParent1 = wzd->getActor();
    }
	
	if(options.has("liveParent2"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("liveParent2"));
		item->liveParent2 = wzd->getActor();
    }
	
	if(options.has("liveParent3"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("liveParent3"));
		item->liveParent3 = wzd->getActor();
    }
	
	if(options.has("liveParent4"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("liveParent4"));
		item->liveParent4 = wzd->getActor();
    }
	
	if(options.has("post1"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post1"));
		item->post1 = wzd->getActor();
    }
	
	if(options.has("post2"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post2"));
		item->post2 = wzd->getActor();
    }
	
	if(options.has("post3"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post3"));
		item->post3 = wzd->getActor();
    }
	
	if(options.has("post4"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post4"));
		item->post4 = wzd->getActor();
    }
	
	if(options.has("post5"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post5"));
		item->post5 = wzd->getActor();
    }
	
	if(options.has("post6"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post6"));
		item->post6 = wzd->getActor();
    }
	
	if(options.has("post7"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post7"));
		item->post7 = wzd->getActor();
    }
	
	if(options.has("post8"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("post8"));
		item->post8 = wzd->getActor();
    }
	
	if(options.has("border"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("border"));
		item->border = wzd->getActor();
    }

	if(options.has("id"))
	{
		item->id = options.get("id").asString();
	}
	
	if(options.has("onExtend"))
    {
		item->onExtendCallback = options.get("onExtend").asFunction();
	}

	if(options.has("onExtendEnd"))
    {
		item->onExtendEndCallback = options.get("onExtendEnd").asFunction();
	}
	
	self->createChild(item);
	
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::addContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	LOG_DEBUG(logger, "FirstScreenListWidgetBridge::addContents");
	
	FirstScreenContents* item = new FirstScreenContents();
	
	ScriptObject options = args[0];
	item->jsInstance = options;

	if(options.has("contentsWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("contentsWrapper"));
		item->contentsWrapper = wzd->getActor();
    }
	
	if(options.has("dominant"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("dominant"));
		item->dominant = wzd->getActor();
    }
	
	if(options.has("titleParent"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("titleParent"));
		item->titleParent = wzd->getActor();
    }
	
	if(options.has("mainWrapper"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("mainWrapper"));
		item->mainWrapper = wzd->getActor();
    }
	
	if(options.has("main"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("main"));
		item->main = wzd->getActor();
    }
	
	if(options.has("overRay"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("overRay"));
		item->overRay = wzd->getActor();
    }
	
	if(options.has("normalTitle"))
    {
		//Widget* wzd = unwrapNativeObject<Widget>(options.get("normalTitle"));
		//item->normalTitle = wzd->getActor();
    }
	
	if(options.has("focusTitle"))
    {
		//Widget* wzd = unwrapNativeObject<Widget>(options.get("focusTitle"));
		//item->focusTitle = wzd->getActor();
    }
	
	if(options.has("border"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("border"));
		item->border = wzd->getActor();
    }
	
	if(options.has("iconParent1"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("iconParent1"));
		item->iconParent1 = wzd->getActor();
    }
	
	if(options.has("iconParent2"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("iconParent2"));
		item->iconParent2 = wzd->getActor();
    }
	
	if(options.has("subMain"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("subMain"));
		item->subMain = wzd->getActor();
    }
	
	if(options.has("progress"))
    {
		Widget* wzd = unwrapNativeObject<Widget>(options.get("progress"));
		item->progressP = wzd->getActor();
    }

	if (options.has("haveOptions"))
	{
		item->haveOptions = options.get("haveOptions").asBool();
	}
	else
	{
		item->haveOptions = false;
	}
	
	if(options.has("dominantColor"))
    {
		item->dominantColor = ScriptToColor(options.get("dominantColor"));
	}
	
	if(options.has("normalTitleColor"))
    {
		item->normalTitleColor = ScriptToColor(options.get("normalTitleColor"));
	}
	
	if(options.has("index"))
    {
		item->index = options.get("index").asNumber();
	}
	
	if(options.has("categoryType"))
    {
		item->categoryType = options.get("categoryType").asString();
	}
	
	if(options.has("onClick"))
    {
		item->onClickCallback = options.get("onClick").asFunction();
	}

	if(options.has("startTransitionCallback"))
    {
		item->startTransitionCallback = options.get("startTransitionCallback").asFunction();
	}

	if(options.has("stopTransitionCallback"))
    {
		item->stopTransitionCallback = options.get("stopTransitionCallback").asFunction();
	}

	if (options.has("focusOptionsCallback"))
	{
		item->focusOptionsCallback = options.get("focusOptionsCallback").asFunction();
	}
	
	if (options.has("unfocusOptionsCallback"))
	{
		item->unfocusOptionsCallback = options.get("unfocusOptionsCallback").asFunction();
	}

	if (options.has("enterOptionsCallback"))
	{
		item->enterOptionsCallback = options.get("enterOptionsCallback").asFunction();
	}
	
	if(options.has("id"))
	{
		item->id = options.get("id").asString();
	}
	
	if(options.has("skipTransition"))
	{
		item->skipTransition = options.get("skipTransition").asBool();
	}
	else
	{
		item->skipTransition = false;
	}
	

	if(options.has("longPressCallback"))
    {
		item->longPressCallback = options.get("longPressCallback").asFunction();
	}


	self->createContents(item);
	
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::off_transition_noanimaition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->off_transition_noanimaition();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::moveLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	int type = (int) args[0].asNumber();
	
	self->moveLeft(type);
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::moveRight(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	int type = (int) args[0].asNumber();
	
	self->moveRight(type);
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::enableMoveToBegin(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->enableMoveToBegin();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::enableMoveToEnd(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->enableMoveToEnd();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setFocus(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	int contentsIndex = (int) args[0].asNumber();
	
	self->setFocus(contentsIndex);
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::removeCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	
	int categoryIndex = (int) args[0].asNumber();
	
	self->removeCategory(categoryIndex);
	
	//self->removeCategoryById(args[0].asString());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::removeContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	/*
	int categoryIndex = (int) args[0].asNumber();
	int contentsIndex = (int) args[1].asNumber();
	
	self->removeContents(categoryIndex, contentsIndex);
	*/
	self->removeContentsById(args[0].asString());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::enlarge(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if (args.Length() < 2)
	{
		return ScriptObject(false);
	}
	else
	{
		if (args[0].isString() && args[1].isString())
		{
			self->enlarge(args[0].asString(), args[1].asString());
		}
		else
		{
			return ScriptObject(false);
		}
	}

	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::highContrast(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	
	if (args.Length() != 0 && args[0].isBool())
	{
		self->highContrast(args[0].asBool());
	}
	else
	{
		self->highContrast(false);
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setKeyPrevent(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	
	if (args.Length() != 0 && args[0].isBool())
	{
		self->setKeyPrevent(args[0].asBool());
	}
	else
	{
		self->setKeyPrevent(false);
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setNomalTextColor(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	
	if (args.Length() < 3)
	{
		return ScriptObject(false);
	}
	else
	{
		LOG_FATAL(logger, "LOG_FATAL [test]Seungmin categoryType " << args[0].asString());
		LOG_FATAL(logger, "LOG_FATAL [test]Seungmin contentsIndex " << (int)args[1].asNumber());
		
		Color dominantColor = ScriptToColor(args[2]);
		self->setNomalTextColor(args[0].asString(), (int)args[1].asNumber(), dominantColor);

		/*
		if (args[0].isString() && args[1].isString() && args[2].isString())
		{
			Color dominantColor = ScriptToColor(args[2]);
			self->setNomalTextColor(args[0].asString(), (int)args[1].asNumber(), dominantColor);
		}
		else
		{
			return ScriptObject(false);
		}
		*/
	}

	return ScriptObject();
}



ScriptObject FirstScreenListWidgetBridge::sendEnterSignal(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->animateOnEnter();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::getCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->returnCategory());
}

ScriptObject FirstScreenListWidgetBridge::getContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->returnContents());
}

ScriptObject FirstScreenListWidgetBridge::riseFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->riseFirstScreen();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::startFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->startAnimation();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::stopFovea(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->stopAnimation();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::stopTransition(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->stop_transition();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::getPositionX(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getPositionX(args[0].asString(), (int)args[1].asNumber()));
}

ScriptObject FirstScreenListWidgetBridge::getPositionY(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getPositionY(args[0].asString(), (int)args[1].asNumber()));
}

ScriptObject FirstScreenListWidgetBridge::changeIcon(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	Widget* wzd = unwrapNativeObject<Widget>(args[3]);
	ClutterActor* newIconParent = wzd->getActor();
	
	self->changeIcon(args[0].asString(), (int)args[1].asNumber(), (int)args[2].asNumber(), newIconParent);
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::reverseOSD(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if (args.Length() != 0 && args[0].isBool())
	{
		self->reverseOSD(args[0].asBool());
	}
	else
	{
		self->reverseOSD(false); // default do not reverse OSD
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::addSubMain(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	try
	{
		Widget* wzd = unwrapNativeObject<Widget>(args[2]);
		ClutterActor* newSubMain = wzd->getActor();
	
		self->addSubMain(args[0].asString(), (int)args[1].asNumber(), newSubMain);
	}
	catch (VoltJsRuntimeException &e)
	{
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::changeContentLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	try
	{
		Widget* wzd = unwrapNativeObject<Widget>(args[4]);
		ClutterActor* contentLive = wzd->getActor();
	
		self->changeContentLive(args[0].asString(), args[1].asString(), (int)args[2].asNumber(), (int)args[3].asNumber(), contentLive);
	}
	catch (VoltJsRuntimeException &e)
	{
	}
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setProgress(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setProgress(args[0].asString(), (int)args[1].asNumber(), (gfloat)args[2].asNumber());
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::callExtendAnimation(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->callExtendAnimation();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::callExtendAnimationEx(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->callExtendAnimationEx();
	
	return ScriptObject();
}


ScriptObject FirstScreenListWidgetBridge::focusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if (self->focusOptions())
	{
		return ScriptObject(true);
	}
	else
	{
		return ScriptObject(false);
	}
}

ScriptObject FirstScreenListWidgetBridge::unfocusOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->unfocusOptions();

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::enterOptions(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if (self->enterOptions())
	{
		return ScriptObject(true);
	}
	else
	{
		return ScriptObject(false);
	}
}

ScriptObject FirstScreenListWidgetBridge::setExtendBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setExtendBezierAndTime((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber(), (gfloat)args[4].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setLiveImageBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setLiveImageBezierAndTime((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber(), (gfloat)args[4].asNumber(), (gfloat)args[5].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setHorizontalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setHorizontalFoveaBezier((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setVerticalFoveaBezier(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setVerticalFoveaBezier((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setContentLiveBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setContentLiveBezierAndTime((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber(), (gfloat)args[4].asNumber(), (gfloat)args[5].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setTransitionBezierAndTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setTransitionBezierAndTime((gfloat)args[0].asNumber(), (gfloat)args[1].asNumber(), (gfloat)args[2].asNumber(), (gfloat)args[3].asNumber(), (gfloat)args[4].asNumber());

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::getCategoryIndexByID(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getCategoryIndexByID(args[0].asString()));
}

ScriptObject FirstScreenListWidgetBridge::fallFirstScreen(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->fallFirstScreen();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::updateDominantColor(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{	
	Color dominantColor = ScriptToColor(args[2]);
	
	self->updateDominantColor(args[0].asString(), (int)args[1].asNumber(),dominantColor);

	return ScriptObject(true);
}


ScriptObject FirstScreenListWidgetBridge::findCategory(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	FirstScreenCategory* category = self->findCategory(args[0].asString());

	if (category != NULL)
	{
		return category->jsInstance;
	}

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::findContents(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	std::string id = args[0].asString();
	FirstScreenContents* contents = self->findContents(id);
	printf("id: %s data: %d\n", id.c_str(), contents);

	if (contents != NULL)
	{
		return contents->jsInstance;
	}

	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setOnBackgroundClickListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setOnBackgroundClickListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setOnMoveFocuseListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setOnMoveFocuseListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setOnScrollLeftEndListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setOnScrollLeftEndListener(args[0].asFunction());
	return ScriptObject(true);
}


ScriptObject FirstScreenListWidgetBridge::setOnScrollRightEndListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setOnScrollRightEndListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setContextMenuFeedbackListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setContextMenuFeedbackListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setContextMenuFocusListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setContextMenuFocusListener(args[0].asFunction());
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setContextMenuUnfocusListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setContextMenuUnfocusListener(args[0].asFunction());
	return ScriptObject(true);
}
ScriptObject FirstScreenListWidgetBridge::setContextMenuFlag(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	bool set = args.Length() >= 1 && args[0].isBool() ? args[0].asBool() : false;
	self->setContextMenuFlag(set);
	return ScriptObject(true);
}
ScriptObject FirstScreenListWidgetBridge::getLastMouseMovedTime(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	return ScriptObject(self->getLastMouseMovedTime());
}


ScriptObject FirstScreenListWidgetBridge::setFirstState(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setFirstState();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::returnAnimation(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->returnAnimation();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setBarOpacityZero(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setBarOpacityZero();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setBarOpacityMax(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->setBarOpacityMax();
	
	return ScriptObject();
}

//begin junhui.wang
ScriptObject FirstScreenListWidgetBridge::changeControler(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->changeControler();
	
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::setDim(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args){
	self->setDim(args[0].asString(), (int)args[1].asNumber(), args[2].asBool());
	return ScriptObject();
}

//end junhui.wang
/*add by lin89.zhang for scale while reach the end of Bar begin*/


ScriptObject FirstScreenListWidgetBridge::popupContextMenu(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	int contextType = 0;
	if (args.Length() == 1 && args[0].isNumber())
	{
		if (args[0].asNumber() == 1)
		{
			contextType = 1;
		}
	}

	if (self->popupContextMenu(contextType))
	{
		return ScriptObject(true);
	}
	else
	{
		return ScriptObject(false);
	}

}

ScriptObject FirstScreenListWidgetBridge::hideContextMenu(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->hideContextMenu();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::selectContextMenuItem(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	self->selectContextMenuItem();
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::removeProgressAndDim(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args){
	self->removeProgressAndDim(args[0].asString(), (int)args[1].asNumber());
	return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::scaleRight(FirstScreenListWidget* self, const ScriptArray& args)
{
    self->scaleRight();
    return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::recoverRight(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
    self->recoverRight();
    return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::scaleLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
    self->scaleLeft();
    return ScriptObject();
}

ScriptObject FirstScreenListWidgetBridge::recoverLeft(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
    self->recoverLeft();
    return ScriptObject();
}
/*add by lin89.zhang for scale while reach the end of Bar end*/

//liang.wu
ScriptObject FirstScreenListWidgetBridge::addAdImg(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if(args[0].isString())
	{
		FirstScreenADControl::GetInstance()->AddADContent(args[0].asString());
	}
    return ScriptObject();
}


ScriptObject FirstScreenListWidgetBridge::setADClickListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if(args[0].isFunction())
	{
		FirstScreenADControl::GetInstance()->SetClickCallback(args[0].asFunction());
	}
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::setADEnterListener(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if(args[0].isFunction())
	{
		FirstScreenADControl::GetInstance()->SetEnterCallback(args[0].asFunction());
	}
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::addHistoryLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if(args.Length() >= 1 && args[0].isString())
	{
		int index = (args.Length() >= 2 && args[1].isNumber()) ? args[1].asNumber() : -1;
		ClutterColor color = {0, 0, 0, 0};
		if(args.Length() >= 3)
		{
			if(args[2].has("r"))color.red = args[2].get("r").asNumber();
			if(args[2].has("g"))color.green = args[2].get("g").asNumber();
			if(args[2].has("b"))color.blue = args[2].get("b").asNumber();
			if(args[2].has("a"))color.alpha = args[2].get("a").asNumber();
		}
		FirstScreenCategoryLiveControl::GetInstance()->AddHistoryLive(args[0].asString(), index, color);
	}
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::removeHistoryLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	int index = (args.Length() >= 1 && args[0].isNumber()) ? args[0].asNumber() : -1;
	FirstScreenCategoryLiveControl::GetInstance()->RemoveHistoryLive(index);
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::addFeaturedLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	if(args.Length() >= 1 && args[0].isString())
	{
		int liveIndex = (args.Length() >= 2 && args[1].isNumber()) ? args[1].asNumber() : -1;
		int postIndex = (args.Length() >= 3 && args[2].isNumber()) ? args[2].asNumber() : -1;
		ClutterColor color = {0, 0, 0, 0};
		if(args.Length() >= 4)
		{
			if(args[3].has("r"))color.red = args[3].get("r").asNumber();
			if(args[3].has("g"))color.green = args[3].get("g").asNumber();
			if(args[3].has("b"))color.blue = args[3].get("b").asNumber();
			if(args[3].has("a"))color.alpha = args[3].get("a").asNumber();
		}
		FirstScreenCategoryLiveControl::GetInstance()->AddFeaturedLive(args[0].asString(), liveIndex, postIndex, color);
	}
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::removeFeaturedLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	int liveIndex = (args.Length() >= 1 && args[0].isNumber()) ? args[0].asNumber() : -1;
	int postIndex = (args.Length() >= 2 && args[1].isNumber()) ? args[1].asNumber() : -1;
	FirstScreenCategoryLiveControl::GetInstance()->RemoveFeaturedLive(liveIndex, postIndex);
	return ScriptObject(true);
}

ScriptObject FirstScreenListWidgetBridge::enableFeaturedLive(volt::graphics::FirstScreenListWidget* self, const ScriptArray& args)
{
	bool set = (args.Length() >= 1 && args[0].isBool()) ? args[0].asBool() : false;
	FirstScreenCategoryLiveControl::GetInstance()->EnableFeaturedLive(set);
	return ScriptObject(true);
}

} /* namespace Bridge */
