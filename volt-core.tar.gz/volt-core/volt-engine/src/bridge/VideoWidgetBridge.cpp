/*
 * VideoWidgetBridge.cpp
 *
 *  Created on: June 18, 2014
 *      Author: jim dinunzio
 */

#include "VideoWidgetBridge.h"

using namespace volt::graphics;

namespace Bridge
{

void VideoWidgetBridge::mapScriptInterface(ScriptContext& context)
{
  WidgetBridge::mapScriptInterface(context);

  context.bindNativeReference<VideoWidget, SefClient,
                              &VideoWidget::getPlayerSef,
                              &VideoWidget::setPlayerSef>("videoPlayerSef");
}


Widget* VideoWidgetBridge::constructWidget(float x, float y, float width, float height,
    Widget* parent, const ScriptArray& args)
{
  ScriptObject obj;
  SefClient* videoPlayerSef = nullptr;

  if(args.Length() > 0)
  {
    obj = args[0].get("videoPlayerSef");
    videoPlayerSef = unwrapNativeObject<SefClient>(obj);
  }

  if(width == -1)
  {
    width = 0;
  }

  if(height == -1)
  {
    height = 0;
  }

  return new VideoWidget(x, y, width, height, parent, videoPlayerSef);
}

}
