# this is a crappy python script to parse system_info_key.h and map the enums
# into VOLT. it is highly risky to use this due to the fact any change in system_info_key.h
# might break this and cause compile to fail!

import sys
import getopt
import os

outputEnums = [];
outputDeclares = [];
outputContext = [];
values = [];	

def insertCode():
	if len(outputEnums) == 0 or len(outputDeclares) == 0 or len(outputContext) == 0:
		return;

	if os.path.isfile(destHeaderFile):
        	os.remove(destHeaderFile)
	
	if os.path.isfile(destCppFile):
        	os.remove(destCppFile)

	srcHeader = open(sourceHeaderFile, "rw");
	srcCpp = open(sourceCppFile, "rw");

	dstHeader = open(destHeaderFile, "w+");
	dstCpp = open(destCppFile, "w+");
	done = 0;	

	#insert into header	
	for line in srcHeader:
		dstHeader.write(line);
		if done == 0 and '//<<START_ENUM>>//' in line:
			for enum in outputEnums:
				write = enum;
				if not 'KEY_PRIVATE_LAST' in enum:
					write = '  ' + write + ',\n'
				else:
					write = '  ' + write + '\n'
				dstHeader.write(write);
			done = 1;
		elif done == 1 and '//<<START_DECLARE>>//' in line:
			for declare in outputDeclares:
				declare = '    ' + declare + '\n'
				dstHeader.write(declare);
			done = 2;
		
	#insert into src
	done = 0;
	for line in srcCpp:
		dstCpp.write(line);
		if done == 0 and '//<<START_CONTEXT>>//' in line:
			for context in outputContext:
				context = '  ' + context + '\n'
				dstCpp.write(context);
			done = 1;

	srcHeader.close();
	srcCpp.close();
	dstHeader.close();
	dstCpp.close();

def processEnum(text):
	preprocess = text.replace(',','');
	tokenized = preprocess.split( );
	for word in tokenized:
		if "SYSTEM_INFO" in word:
			current = word;
			if "=" in current:
				equals = current.split('=');
				for number in values:
					if equals[1] in number[0]:	
						current = current.replace(equals[1], number[1]);
			current = current.replace("SYSTEM_INFO_", '')
			outputEnums.append(current);
	return;

def processDeclares():
	for enum in outputEnums:
		processed = enum;
		if "=" in enum:
			equals = enum.split('=');
			processed = equals[0];
		declare = 'DEFINE_KEY_MAP_FUNCS(Bridge, ' + processed + ')'
		outputDeclares.append(declare);
	#print outputDeclares;

def processContext():
	for enum in outputEnums:
		processed = enum;
		if "=" in enum:
			equals = enum.split('=');
			processed = equals[0];
		context = 'DEFINE_KEY_MAP(aContext, ' + processed + ');'
		outputContext.append(context);
	#print outputContext;

def main(argv):
	print argv[0];
	
	global sourceKeyFile
	sourceKeyFile = '/usr/include/capi-system-info/system_info_key.h'

	global sourceHeaderFile
	sourceHeaderFile = argv[0] +  "/include/bridge/SystemInfoBridge.h.tizen"

	global sourceCppFile
	sourceCppFile = argv[0] + "/src/bridge/SystemInfoBridge.cpp.tizen"

	global destHeaderFile
	destHeaderFile = argv[0] + "/include/bridge/SystemInfoBridge.h"
	
	global destCppFile
	destCppFile = argv[0] + "/src/bridge/SystemInfoBridge.cpp"

	f = open(sourceKeyFile, "r");
	mode = 0;
	for line in f:
		# check if we are continuing.. 
		if mode == 2:
			break;

		# load up the defined values..
		elif  mode == 0 and "#define" in line:
			line2 = line.replace('#define', '')
			array = line2.split( )
			if len(array) == 2:
				values.append(array)

		# check for the start of enums	
		elif mode != 1 and "typedef enum{" in line:
			mode = 1;
			print "start of enum found"
	
		# check for the end of enums
		elif mode == 1:
			if "}system_info_key_e;" in line:
				mode = 2;
				print "end of enum"		
			else: 
				processEnum(line);
	#print outputEnums
	processDeclares();
	processContext();
	insertCode();
	f.close()

if __name__ == "__main__":
    main(sys.argv[1:])
