 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of ScrollBar
 * @date    2014/07/30
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

ControlBase = require("UIElement/ControlBase");

/**
 * Class ScrollBar.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
ScrollBar = function() {
    this.track = null;
    this.bar = null;
    this.isVertical = true;
    this.num = 1;
    this.curIndex = 0;
    this.isMouseDown = false;
    this.MouseDownPosX = 0;
    this.MouseDownPosY = 0;
    this.DragStartBarPosX = 0;
    this.DragStartBarPosY = 0;
    this.barNormalColor = {r:100, g:100, b:100, a:255};
    this.barOnMoveColor = {r:50, g:50, b:50, a:255};
    this.trackColor = {r:200, g:200, b:200, a:255};
    this.cbMove = null;
    this.trackPosX = 0;
    this.trackPosY = 0;

	this.t_create = function(obj) {
        /*
        this.debugText = new TextWidget({
            x:0,
            y:0,
            width:400,
            height:50,
            text:"debugText",
            textColor:{r:255, g:255, b:255, a:150},
            parent:scene,
        });
        this.debugText.hide();
        */
        var height = 1;
        var width = 1;
        if (obj.hasOwnProperty("height") && "number" == typeof obj.height
            && obj.height>=1) {
            height = obj.height;
        }
        if (obj.hasOwnProperty("width") && "number" == typeof obj.width
            && obj.width>=1) {
            width = obj.width;
        }
        if (obj.hasOwnProperty("isVertical") && "boolean" == typeof obj.isVertical) {
            this.isVertical = obj.isVertical;
        }
        if (obj.hasOwnProperty("number") && "number" == typeof obj.number
            && obj.number>=1) {
            this.num = obj.number;
        }
        this.track= new Widget({
            x: 0,
            y: 0,
            width: width,
            height: height,
            color: this.trackColor,
            parent: obj.parent,
        });
        this.bar= new Widget({
            x: 0,
            y: 0,
            width: width,
            height: height,
            color: this.barNormalColor,
            parent: obj.parent,
        });
        if(true == this.isVertical) {
            this.bar.height = this.track.height/this.num;
        }
        else {
            this.bar.width = this.track.width/this.num;
        }        
        this.trackPosX = (this.track.getAbsolutePosition()).x;
        this.trackPosY = (this.track.getAbsolutePosition()).y;
        
        this.bar.addEventListener("OnMouseDown", this.barMouseDownBind);
        this.bar.addEventListener("OnMouseUp", this.barMouseUpBind);
        this.bar.addEventListener("OnMouseOut", this.barMouseOutBind);
        this.bar.addEventListener("OnMouseMove", this.barMouseMoveBind);
        this.track.addEventListener("OnMouseClick", this.trackMouseClickBind);
    };

    this.barMouseDown =function(targetWidget, eventData) {
        if(!this.isFocused || this.isDimed || eventData.button != Volt.MOUSE_BUTTON_LEFT) {
            return false;
        }
        //this.debugText.text = "OnMouseDown at: " + eventData.coordinates.x.toString() + ", " + eventData.coordinates.y.toString();
        this.bar.color = this.barOnMoveColor;
        this.MouseDownPosX = eventData.coordinates.x;
        this.MouseDownPosY = eventData.coordinates.y;
        this.DragStartBarPosX = this.bar.x;
        this.DragStartBarPosY = this.bar.y;	
        this.isMouseDown = true;
        return false;
    };
    this.barMouseDownBind = this.barMouseDown.bind(this);
    
    this.barMouseUp = function(targetWidget, eventData) {
        if(!this.isFocused || this.isDimed || eventData.button != Volt.MOUSE_BUTTON_LEFT) {
            return false;
        }
        //this.debugText.text = "OnMouseUp at: " + eventData.coordinates.x.toString() + ", " + eventData.coordinates.y.toString();
        if(true == this.isVertical) {
            this.bar.y = this.curIndex*this.bar.height;
        }
        else {
            this.bar.x = this.curIndex*this.bar.width;
        }
        this.isMouseDown = false;
        this.bar.color = this.barNormalColor;
        return false;
    };
    this.barMouseUpBind = this.barMouseUp.bind(this);
    
    //We cannot receive mouse event out of widget now, so release it when mouse leave.
    this.barMouseOut = function(targetWidget, eventData) {
        if(!this.isFocused || this.isDimed) {
            return false;
        }
        //this.debugText.text = "OnMouseUp at: " + eventData.coordinates.x.toString() + ", " + eventData.coordinates.y.toString();
        if(true == this.isVertical) {
            this.bar.y = this.curIndex*this.bar.height;
        }
        else {
            this.bar.x = this.curIndex*this.bar.width;
        }
        this.isMouseDown = false;
        this.bar.color = this.barNormalColor;
        return false;
    };
    this.barMouseOutBind = this.barMouseOut.bind(this);
    
    this.barMouseMove = function(targetWidget, eventData) {
        //this.debugText.text = "OnMouseMove at: " + eventData.coordinates.x.toString() + ", " + eventData.coordinates.y.toString();
        if(!this.isFocused || this.isDimed || false == this.isMouseDown) {
            //this.debugText.text = "OnMouseMove return for this.isMouseDown! ";
            return false;
        }
        var step = 0;
        //Move bar smoothly during dragging
        if(true == this.isVertical) {
            this.bar.y = this.DragStartBarPosY + (eventData.coordinates.y-this.MouseDownPosY);
            if(this.bar.y < 0) {
                this.bar.y = 0;
            }
            if(this.bar.y+this.bar.height > this.track.height) {
                this.bar.y = this.track.height - this.bar.height;
            }
            
            step = Math.floor((eventData.coordinates.y-this.trackPosY)/this.bar.height);
        }
        else {
            this.bar.x = this.DragStartBarPosX + (eventData.coordinates.x-this.MouseDownPosX);
            if(this.bar.x < 0) {
                this.bar.x = 0;
            }
            if(this.bar.x+this.bar.width > this.track.width) {
                this.bar.x = this.track.width - this.bar.width;
            }
            
            step = Math.floor((eventData.coordinates.x-this.trackPosX)/this.bar.width);
        }
        if(step != this.curIndex && step >=0 && step < this.num){
            this.curIndex = step;
            if(null != this.cbMove){
                this.cbMove(this.curIndex);
            }
        }
        return false;
    };
    this.barMouseMoveBind = this.barMouseMove.bind(this);
    
    this.trackMouseClick = function(targetWidget, eventData) {
        if(!this.isFocused || this.isDimed || eventData.button != Volt.MOUSE_BUTTON_LEFT) {
            return false;
        }
        //this.debugText.text = "OnMouseClick at: " + eventData.coordinates.x.toString() + ", " + eventData.coordinates.y.toString();
        var step = 0;
        if(true == this.isVertical) {
            step = Math.floor((eventData.coordinates.y-this.trackPosY)/this.bar.height);
        }
        else {
            step = Math.floor((eventData.coordinates.x-this.trackPosX)/this.bar.width);
        }
        if(step != this.curIndex && step >=0 && step < this.num){
            this.curIndex = step;
            if(true == this.isVertical) {
                this.bar.y = this.curIndex*this.bar.height;
            }
            else {
                this.bar.x = this.curIndex*this.bar.width;
            }
            if(null != this.cbMove){
                this.cbMove(this.curIndex);
            }
        }
        return false;
    };	
    this.trackMouseClickBind = this.trackMouseClick.bind(this);
    
    this.moveBarToIndex = function(index){
        if(this.isCreated == true && index != this.curIndex
            && index >=0 && index < this.num){
            this.curIndex = index;
            if(true == this.isVertical) {
                this.bar.y = this.curIndex*this.bar.height;
            }
            else {
                this.bar.x = this.curIndex*this.bar.width;
            }
        }
        return true;
    };
    
    this.setBarNormalColor = function(color){
        if (this.isCreated == true && typeof color == 'object') {
            this.barNormalColor = color;
            this.bar.color = this.barNormalColor;
            return true;
        }
        return false;
    };
    
    this.setBarOnMoveColor = function(color){
        if (this.isCreated == true && typeof color == 'object') {
            this.barOnMoveColor = color;
            return true;
        }
        return false;
    };
    
    this.setTrackColor = function(color){
        if (this.isCreated == true && typeof color == 'object') {
            this.trackColor = color;
            this.track.color = this.trackColor;
            return true;
        }
        return false;
    };
    
    this.setCallBack = function(moveContent){
        if(typeof moveContent == 'function'){
            this.cbMove = moveContent;
        }
    };
    
    this.setNumber = function(number){
        if(typeof number == 'number' && number >= 1){
            this.num = number;
            this.curIndex = 0;
            if(true == this.isVertical) {
                this.bar.height = this.track.height/this.num;
                this.bar.y = 0;
            }
            else {
                this.bar.width = this.track.width/this.num;
                this.bar.x = 0;
            }
        }
    };
    
	this.t_getFocus = function() {
	};

	this.t_loseFocus = function() {
	};

	this.t_destroy = function() {
        if(null != this.bar) {
            this.bar.destroy();
            this.bar = null;
        }
        if(null != this.track) {
            this.track.destroy();
            this.track = null;
        }
        delete this.barMouseDownBind;
        delete this.barMouseUpBind;
        delete this.barMouseMoveBind;
        delete this.trackMouseClickBind;
	};

	this.t_show = function() {
	};

	this.t_hide = function() {
	};

	this.t_keyHandler = function(keycode, keytype) {
        if (keytype == Volt.EVENT_KEY_RELEASE) {
            return false;
        }	

        var ret = false;
        return ret;
	};	
}

ScrollBar.prototype = new ControlBase();
exports = ScrollBar;
