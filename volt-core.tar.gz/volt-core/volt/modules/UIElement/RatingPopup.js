/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of RatingPopup
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

const ControlBase = require("UIElement/ControlBase");
const Button_Generic = require("UIElement/Button_Generic");
const PopupRating = require("UIElement/Rating");

var setTimeout=function(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
};

var clearTimeout=function (id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
};

/**
 * Class RatingPopup.
class
 * @constructor
 * @extends UIElement/ControlBase UIElement/Button_Generic UIElement/Rating
 */
RatingPopup = function() {
	//variable
	var sceWidth = scene.width;
	var sceHeight = scene.height;
	
	this.PopupBGWidget = null;
	this.focusIndex = 0;
	this.buttonCount = 0;
	this.buttonList = [];
	this.bgWidth=sceWidth;
	this.bgHeight=sceHeight*0.217708*2;
	this.bgColor={r:10,g:93,b:136,a:0.85*255};//0a5d88
	this.bgOpacity=0.85*255;
	this.messageWidth=sceWidth*0.407292;
	this.messageHeight=sceHeight*0.044444;
	this.messageFont="34px";
	this.messageOpacity=0.9*255;
	this.messageText="";
	this.messageTextColor={r:255,g:255,b:255,a:0.9*255};//ffffffff
	this.messageBgColor={r:69,g:187,b:163,a:0.9*255};//45bba3
	this.messagePositionX=sceWidth*(1-0.407292)*0.5;
	this.messagePositionY=sceHeight*(0.088889+0.011111);
	this.messageVerticalAlignment="center";
	this.messageHorizontalAlignment="left";
	this.messageInstance=null;
	this.focus=false;
	
	this.isCreate=false;
	this.titleFont="46px";
	this.title="";
	this.titleTextColor={r:255,g:255,b:255,a:255};//ffffffff
	this.titleWidth=sceWidth*0.407292;
	this.titleHeight=sceHeight*0.088889;
	this.titlePositionX=sceWidth*(1-0.407292)*0.5;
	this.titlePositionY=0;
	this.titleVerticalAlignment="center";
	this.titleHorizontalAlignment="center";
	this.buttonPositionXList=[825,684,543,402];
	this.buttonPositionY=sceHeight*(0.032407+0.044444*2+0.088889+0.018519)+62;
	this.buttonWidth=270;
	this.buttonHeight=66;
	this.buttonCallbackList=[];
	
	this.ratingPositionX=750;
	this.ratingPositionY=sceHeight*(0.044444*2+0.088889+0.018519);
	this.ratingWidth=416;
	this.ratingHeight=62;
	this.ratingBgColor={r:122,g:122,b:122,a:0};
	this.starSrc="";
	this.starAreaPositionX=71;
	this.starAreaPositionY=0;
	this.starAreaWidth=296;
	this.starAreaHeight=62;
	this.starWidth=46;
	this.starHeight=46;
	this.starGap=11;
	this.starNum=5;
	this.fontArrowX=0;
	this.fontArrowY=0;
	this.fontArrowWidth=60;
	this.fontArrowHeight=62;
	this.backArrowX=367;
	this.backArrowY=0;
	this.backArrowWidth=60;
	this.backArrowHeight=60;
	this.fontArrowSrc={};
	this.backArrowSrc={};
	this.cursorImages=null;
	this.starY=0;
	this.starX=0;
	this.Rating=null;
	this.titleInstance=null;
	this.returnKeyCallback=null;
	this.messageInstance=null;
	this.timer=null;
	this.timeOutCallBack=null;
	this.timeOutTime=10000;
	this.mouseOverCallBack=null;
	this.mouseOutCallBack=null;
	this.openOverout=false;
	this.openClick=false;
	this.openUpdown=false;
	
	/**
	* This function will create a RatingPopup<p>
	* This function will create a RatingPopup,You can use this function when you want to create an RatingPopup Object.
	* @param {Object} param of the new RatingPopup you want to create.
	* @return {Object} return the new RatingPopup object you want to create.
	* @example //This example create a new RatingPopup.
	* const script_AID = "UIElement/RatingPopup";
	* const RatingPopup = require(script_AID);
	* PopupIns = new RatingPopup(); 
	* PopupIns.create({x:0, y:200, height:410, bgsrc:"button/btn_focused.png", parent:scene});
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("width")){
			this.bgWidth=obj.width;
		}
		if(obj.hasOwnProperty("color")){
			this.bgColor=obj.color;
		}
		
		if(obj.hasOwnProperty("opacity")){
			this.bgOpacity=obj.opacity;
		}
		if(obj.hasOwnProperty("height")){
			this.bgHeight=obj.height;
		}
		this.PopupBGWidget = new ImageWidget({
			width : this.bgWidth,
			height : this.bgHeight,
			color :{r:10,g:93,b:136,a:0},
			parent : obj.parent
		});
		if(obj.hasOwnProperty("bgsrc")){
			this.PopupBGWidget.src=obj.bgsrc;
		}
		else{
			this.PopupBGWidget.color=this.bgColor;
		}
		this.PopupBGWidget.opacity=this.bgOpacity;
		this.PopupBGWidget.hide();
		this.initx=this.rootWidget.getAbsolutePosition().x;
		this.inity=this.rootWidget.getAbsolutePosition().y;
		this.isCreate=true;
		return true;
	};
	
	this.t_destroy = function() {
		this.focusIndex = 0;
		if(this.timer!=null){
			clearTimeout(this.timer);
		}
		var num1=this.buttonList.length;
		if(num1!=0){
			for(var i=num1-1;i>=0;i--){
				this.buttonList[i].destroy();
			}
			this.buttonList.splice(0, this.buttonList.length);
			this.buttonList = null;
		}
		delete this.t_buttonClickCallbackBind;
		delete this.m_buttonMouseOverCallBackBind;			
		delete this.m_buttonMouseOutCallBackBind;
		delete this.t_ratingPopupMouseOverBind;
		delete this.t_ratingPopupMouseOutBind;
		this.buttonCallbackList.splice(0, this.buttonCallbackList.length);
		this.buttonCallbackList = null;
		if(this.Rating != null){
			this.Rating.destroy();
			this.Rating = null;
		}
		if(this.titleInstance != null){
			this.titleInstance.destroy();
			this.titleInstance = null;
			this.lineInstance.destroy();
			this.lineInstance = null;
		}
		if(this.messageInstance != null){
			this.messageInstance.destroy();
			this.messageInstance = null;
		}
		if(this.PopupBGWidget != null){
			this.PopupBGWidget.destroy();
			this.PopupBGWidget = null;
		}
	};
	
	this.t_show = function() {
		this.PopupBGWidget.show();
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	this.t_hide = function() {
		this.PopupBGWidget.hide();
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		if(this.isCreated == false) {
			return false;
		}
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}			
				
		var bRet = false;
		switch(keycode) {
			case Volt.KEY_JOYSTICK_RIGHT:
				if(this.focusIndex < this.buttonCount-1) {
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex++;
					this.buttonList[this.focusIndex].getFocus();
					bRet = true;
				}
				else{
					bRet = this.Rating.keyHandler(keycode);
				}
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				if(this.focusIndex > 0&&this.focusIndex <this.buttonCount) {
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex--;
					this.buttonList[this.focusIndex].getFocus();
					bRet = true;
				}
				else if(this.focusIndex=this.buttonCount){
					bRet = this.Rating.keyHandler(keycode);
				}
				else{
					
				}
				break;
			case Volt.KEY_JOYSTICK_OK:
					if(this.focusIndex >= 0&&this.focusIndex < this.buttonCount){
						this.buttonList[this.focusIndex].keyHandler(keycode,keytype);
						bRet = true;
					}
					else if(this.focusIndex=this.buttonCount){
						bRet = this.Rating.keyHandler(keycode);
					}
					else{
						
					}
					//to do				
				break;
			case Volt.KEY_JOYSTICK_UP:
			case Volt.KEY_JOYSTICK_DOWN:
				if(this.focusIndex==this.buttonCount){
					this.focusIndex=0;
					this.buttonList[this.focusIndex].getFocus();
					this.Rating.loseFocus();
					bRet = true;
				}
				else if(this.focusIndex >= 0&&this.focusIndex < this.buttonCount){
					this.buttonList[this.focusIndex].loseFocus();
					this.focusIndex=this.buttonCount;
					this.Rating.getFocus();
					bRet = true;
				}
				else{
				}
				break;
			case Volt.KEY_RETURN:
				if(this.returnKeyCallback!=null){
					this.returnKeyCallback();
				}
				bRet = true;			
			break;
			default:
				break;
		}
		if(bRet == true){
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
		return bRet;
	};
	
	 /**
	* This function will set return key callback function of RatingPopup created<p>
	* This function will set return key callback function of RatingPopup created,You can use this function when you want to set return key callback.
	* @param {Function} callback function called when press return key.
	* @return {Void}
	* @example //This example set return key callback.
	* var okcallback=function(){
		  textwidget.text="ok";
	  };
	* PopupIns.setReturnKeyCallBack(okcallback);
	* @since The version 1.0 this function is added.
	*/
	this.setReturnKeyCallBack=function(callback){
		if(true == this.isCreate){
			this.returnKeyCallback=callback;
		}
	};
	
	/**
	* This function will set time out property of RatingPopup created<p>
	* This function will set time out property of RatingPopup created,You can use this function when you want to use time out.
	* @param {Object} param of time out you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set time out property.
	* var outcallback=function(){
		PopupIns.hide();
	  };
	* PopupIns.startTimeOut({callback:outcallback});
	* @since The version 1.0 this function is added.
	*/
	this.startTimeOut=function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("time")){
			this.timeOutTime=obj.time;
		}
		if(obj.hasOwnProperty("callback")){
			this.timeOutCallBack=obj.callback;
		}
		if(this.timeOutCallBack!=null){
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	 /**
	* This function will set title property of RatingPopup created<p>
	* This function will set title property of RatingPopup created,You can use this function when you want to set title.
	* @param {Object} param of title property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set title property.
	* PPopupIns.setTitle({x:700, 
					   y:10,
					   width:300, 
					   height:100, 
					   textcolor:color1, 
					   font:"45px", 
					   VerticalAlignment:"top", 
					   HorizontalAlignment:"center", 
					   bgcolor:color2,
					   titleopacity:25, 
					   title:" Rating Popup"});
	* @since The version 1.0 this function is added.
	*/
	this.setTitle=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(this.titleInstance==null){		
			this.titleInstance = new TextWidget({
				parent : this.PopupBGWidget
			});
			this.lineInstance = new Widget({
				height : 1,
				parent : this.PopupBGWidget
			});
			this.titleInstance.x=this.titlePositionX;
			this.titleInstance.y=this.titlePositionY;
			this.titleInstance.width=this.titleWidth;
			this.titleInstance.height=this.titleHeight;
			this.titleInstance.font=this.titleFont;
			this.titleInstance.horizontalAlignment=this.titleHorizontalAlignment;
			this.titleInstance.verticalAlignment=this.titleVerticalAlignment;
			this.titleInstance.text=this.title;
			this.titleInstance.textColor=this.titleTextColor;
			this.lineInstance.x=this.titlePositionX;
			this.lineInstance.width=this.titleWidth;
			this.lineInstance.color=this.titleTextColor;
		}
		if(obj.hasOwnProperty("x")){
			if("number" == typeof(obj.x) && obj.x != this.titlePositionX){
				this.titlePositionX=obj.x;
				this.titleInstance.x=this.titlePositionX;
				this.lineInstance.x=this.titlePositionX;
			}
		}
		if(obj.hasOwnProperty("y")){
			if("number" == typeof(obj.y) && obj.y != this.titlePositionY){
				this.titlePositionY=obj.y;
				this.titleInstance.y=this.titlePositionY;
			}
		}
		if(obj.hasOwnProperty("width")){
			if("number" == typeof(obj.width) && obj.width != this.titleWidth){
				this.titleWidth=obj.width;
				this.titleInstance.width=this.titleWidth;
				this.lineInstance.width=this.titleWidth
			}
		}
		if(obj.hasOwnProperty("height")){
			if("number" == typeof(obj.height) && obj.height != this.titleHeight){
				this.titleHeight=obj.height;
				this.titleInstance.height=this.titleHeight;
			}
		}
		if(obj.hasOwnProperty("textcolor")){
			this.titleTextColor=obj.textcolor;
			this.titleInstance.textColor=this.titleTextColor;
			this.lineInstance.color=this.titleTextColor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.titleFont=obj.font;
				this.titleInstance.font=this.titleFont;
			}	
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			this.titleVerticalAlignment=obj.VerticalAlignment;
			this.titleInstance.verticalAlignment=this.titleVerticalAlignment;
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			this.titleHorizontalAlignment=obj.HorizontalAlignment;
			this.titleInstance.horizontalAlignment=this.titleHorizontalAlignment;
		}
		if(obj.hasOwnProperty("title")){
			if ("string" == typeof(obj.title)){
				this.title=obj.title;
				this.titleInstance.text=this.title;
			}
		}
		this.lineInstance.y=this.titlePositionY+this.titleHeight;
		if(obj.hasOwnProperty("titleopacity")){
			this.titleInstance.opacity=obj.titleopacity;
		}
		if(obj.hasOwnProperty("bgColor")){
			this.titleInstance.color=obj.bgColor;
		}
		this.lineInstance.opacity=0.2*255;
		return true;
	};
	
	 /**
	* This function will set message property of RatingPopup created<p>
	* This function will set message property of RatingPopup created,You can use this function when you want to set message.
	* @param {Object} param of message property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set message property.
	* PopupIns.setMessage({x:100, 
					     y:100,
					     width:1000,
					     height:200, 
					     textcolor:color1, 
					     font:"20px", 
					     VerticalAlignment:"top", 
					     HorizontalAlignment:"center", 
					     bgcolor:color2, 
					     opacity:22, 
					     message:tmpStr});
	* @since The version 1.0 this function is added.
	*/
	this.setMessage=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(this.messageInstance==null){
			this.messageInstance = new TextWidget({
				x : this.messagePositionX,
				y : this.messagePositionY,
				width :this.messageWidth,
				height : this.messageHeight,
				parent : this.PopupBGWidget
			});
			this.messageInstance.font=this.messageFont;
			this.messageInstance.horizontalAlignment=this.messageHorizontalAlignment;
			this.messageInstance.verticalAlignment=this.messageVerticalAlignment;
			this.messageInstance.text=this.messageText;
			this.messageInstance.textColor=this.messageTextColor;
			this.messageInstance.opacity=this.messageOpacity;	
		}
		if(obj.hasOwnProperty("x")){
			if("number" == typeof(obj.x) && obj.x != this.messagePositionX){
				this.messagePositionX=obj.x;
				this.messageInstance.x=this.messagePositionX;
			}
		}
		if(obj.hasOwnProperty("y")){
			if("number" == typeof(obj.y) && obj.y != this.messagePositionY){
				this.messagePositionY=obj.y;
				this.messageInstance.y=this.messagePositionY;
			}
		}
		if(obj.hasOwnProperty("width")){
			if("number" == typeof(obj.width) && obj.width != this.messageWidth){
				this.messageWidth=obj.width;
				this.messageInstance.width=this.messageWidth;
			}
		}
		if(obj.hasOwnProperty("height")){
			if("number" == typeof(obj.height) && obj.height != this.messageHeight){
				this.messageHeight=obj.height;
				this.messageInstance.height=this.messageHeight;
			}
		}
		if(obj.hasOwnProperty("textcolor")){
			this.messageTextColor=obj.textcolor;
			this.messageInstance.textColor=this.messageTextColor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.messageFont=obj.font;
				this.messageInstance.font=this.messageFont;
			}
		}
		if(obj.hasOwnProperty("VerticalAlignment")){
			this.messageVerticalAlignment=obj.VerticalAlignment;
			this.messageInstance.verticalAlignment=this.messageVerticalAlignment;
		}
		if(obj.hasOwnProperty("HorizontalAlignment")){
			this.messageHorizontalAlignment=obj.HorizontalAlignment;
			this.messageInstance.horizontalAlignment=this.messageHorizontalAlignment;
		}
		
		if(obj.hasOwnProperty("opacity")){
			if("number" == typeof(obj.opacity) && obj.opacity != this.messageOpacity){
				this.messageOpacity=obj.opacity;
				this.messageInstance.opacity=this.messageOpacity;
			}
		}
		if(obj.hasOwnProperty("message")){
			if ("string"== typeof(obj.message) && obj.message != this.messageText){
				this.messageText=obj.message;
				this.messageInstance.text=this.messageText;
			}
		}
		if(obj.hasOwnProperty("bgcolor")){
			this.messageBgColor=obj.bgcolor;
			this.messageInstance.color=this.messageBgColor;
		}
		return true;
	};
	
	this.getRatingnum=function(){
		return this.Rating.getStarNum();
	};
	
	 /**
	* This function will set rating property of RatingPopup created<p>
	* This function will set rating property of RatingPopup created,You can use this function when you want to set rating.
	* @param {Object} param of rating property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set rating property.
	* PopupIns.setRating({cursorimages:options,		
						x:800,
						y:240,
						width:600,
						height:100,
						ratingbgcolor:{r:122,g:122,b:192,a:255},
						stararea:{x:100,y:10,width:400,height:80},
						star:{x:10,y:5,width:80,height:80,gap:20,num:4,imagesrc:{normal:"Rating/popup_rating_off.png", selected:"Rating/popup_rating_on.png"},},
						fontarrow:{x:0,y:10,width:80,height:80,
						imagesrc:{normal:"Rating/popup_rating_arrow_l_n.png", focus:"Rating/popup_rating_arrow_l_f.png", dim:"Rating/popup_rating_arrow_l_d.png"}},
						backarrow:{x:510,y:10,width:80,height:80,imagesrc:{normal:"Rating/popup_rating_arrow_r_n.png", focus:"Rating/popup_rating_arrow_r_f.png", dim:"Rating/popup_rating_arrow_r_d.png"}},
						});
	* @since The version 1.0 this function is added.
	*/
	this.setRating=function(obj) {
		var isnew=false;
		var israting=false;
		var isfont=false;
		var isback=false;
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			if("number" == typeof(obj.x) && obj.x != this.ratingPositionX){
				this.ratingPositionX=obj.x;
				isnew=true;
			}
		}
		if(obj.hasOwnProperty("y")){
			if("number" == typeof(obj.y) && obj.y != this.ratingPositionY){
				this.ratingPositionY=obj.y;
				isnew=true;
			}
		}
		if(obj.hasOwnProperty("width")){
			if("number" == typeof(obj.width) && obj.width != this.ratingWidth){
				this.ratingWidth=obj.width;
				isnew=true;
			}
		}
		if(obj.hasOwnProperty("height")){
			if("number" == typeof(obj.height) && obj.height != this.ratingHeight){
				this.ratingHeight=obj.height;
				isnew=true;
			}
		}
		if(obj.hasOwnProperty("cursorimages")){
			this.cursorImages=obj.cursorimages;
			isnew=true;
		}
		if(obj.hasOwnProperty("ratingbgcolor")){
			this.ratingBgColor=obj.ratingbgcolor;
			isnew=true;
		}
		if(obj.hasOwnProperty("stararea")){
			if(obj.stararea.hasOwnProperty("x")){
				this.starAreaPositionX=obj.stararea.x;
			}
			if(obj.stararea.hasOwnProperty("y")){
				this.starAreaPositionY=obj.stararea.y;
			}
			if(obj.stararea.hasOwnProperty("width")){
				this.starAreaWidth=obj.stararea.width;
			}
			if(obj.stararea.hasOwnProperty("height")){
				this.starAreaHeight=obj.stararea.height;
			}
			israting=true;
		}
		if(obj.hasOwnProperty("star")){
			if(obj.star.hasOwnProperty("x")){
				this.starX=obj.star.x;
			}
			if(obj.star.hasOwnProperty("y")){
				this.starY=obj.star.y;
			}
			if(obj.star.hasOwnProperty("width")){
				this.starWidth=obj.star.width;
			}
			if(obj.star.hasOwnProperty("height")){
				this.starHeight=obj.star.height;
			}
			if(obj.star.hasOwnProperty("gap")){
				this.starGap=obj.star.gap;
			}
			if(obj.star.hasOwnProperty("num")){
				this.starNum=obj.star.num;
			}
			if(obj.star.hasOwnProperty("imagesrc")){
				this.starSrc = obj.star.imagesrc;
			}
			israting=true;
		}
		if(obj.hasOwnProperty("fontarrow")){
			if(obj.fontarrow.hasOwnProperty("x")){
				this.fontArrowX=obj.fontarrow.x;
			}
			if(obj.fontarrow.hasOwnProperty("y")){
				this.fontArrowY=obj.fontarrow.y;
			}
			if(obj.fontarrow.hasOwnProperty("width")){
				this.fontArrowWidth=obj.fontarrow.width;
			}
			if(obj.fontarrow.hasOwnProperty("height")){
				this.fontArrowHeight=obj.fontarrow.height;
			}
			if(obj.fontarrow.hasOwnProperty("imagesrc")){
				this.fontArrowSrc = obj.fontarrow.imagesrc;
			}
			isfont=true;
		}
		if(obj.hasOwnProperty("backarrow")){
			if(obj.backarrow.hasOwnProperty("x")){
				this.backArrowX=obj.backarrow.x;
			}
			if(obj.backarrow.hasOwnProperty("y")){
				this.backArrowY=obj.backarrow.y;
			}
			if(obj.backarrow.hasOwnProperty("width")){
				this.backArrowWidth=obj.backarrow.width;
			}
			if(obj.backarrow.hasOwnProperty("height")){
				this.backArrowHeight=obj.backarrow.height;
			}
			if(obj.backarrow.hasOwnProperty("imagesrc")){
				this.backArrowSrc = obj.backarrow.imagesrc;
			}
			isback=true;
		}
		if(this.Rating!=null){
			if(isnew==true){
				this.Rating.destroy();
				this.Rating=null;
			}
		}
		if(this.Rating==null){
			this.Rating = new PopupRating();
			this.Rating.create({x:this.ratingPositionX, 
								y:this.ratingPositionY,
								width:this.ratingWidth,
								height:this.ratingHeight, 
								color:this.ratingBgColor,
								cursorImages:this.cursorImages,
								parent:this.PopupBGWidget});
		}
		if(israting==true){
			this.Rating.setRatingContent({ratingx:this.starAreaPositionX,
										  ratingy:this.starAreaPositionY,
										  ratingwidth:this.starAreaWidth,
										  ratingheight:this.starAreaHeight,
										  starwidth:this.starWidth,
										  starheight:this.starHeight,
										  starimage:this.starSrc,
										 // selectstarsrc:this.selectStarSrc,
										  starnum:this.starNum,
										  stargap:this.starGap,
										  stary:this.starY,
										  starx:this.starX});
		}	
		if(isfont==true){
			this.Rating.setFontArrow({x:this.fontArrowX,
									  y:this.fontArrowY,
									  width:this.fontArrowWidth,
									  height:this.fontArrowHeight,
									  imagesrc:this.fontArrowSrc});
		}
		if(isback==true){
			this.Rating.setBackArrow({x:this.backArrowX,
									  y:this.backArrowY,
								      width:this.backArrowWidth,
								      height:this.backArrowHeight,
									  imagesrc:this.backArrowSrc});
		}
		this.Rating.setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind, outCallback:this.m_buttonMouseOutCallBackBind});
		this.Rating.show();
	};
	
	 /**
	* This function will set button property of RatingPopup created<p>
	* This function will set button property of RatingPopup created,You can use this function when you want to set button.
	* @param {Object} param of button property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set button property.
	* var okcallback=function(){
		textwidget.text="ok";
	 };
	* var cancelcallback=function(){
		textwidget.text="cancel";
	  };
	* var buttonProperty =[{x:100, 
						y:300, 
						width:100,
						height:100,
						buttonborder:{normal:{width:1, color:{r:255, g:25, b:25, a:52}},
									  focus:{width:5, color:{r:15, g:255, b:25, a:52}},
									  selected:{width:10, color:{r:55, g:255, b:255, a:52}}},
						buttontextfont:{normal:"20px",focus:"30px", selected:"35px"},
						buttontextcolor:{normal:color1,focus:color2, selected:color3}, 
						buttontextVerticalAlignment:"center", 
						buttontextHorizontalAlignment:"center", 
						buttontext:{normal:"ok",focus:"ok111", selected:"ok222"}, 
						buttonimage:{normal:"button/btn_dim.png",focus:"button/btn_focused.png", selected:"button/wizard_btn_sel.png"}, 
						callbackfunction:okcallback},
					   {x:1000, 
						y:300 , 
						width:200, 
						height:100,
						buttonborder:{normal:{width:1, color:{r:255, g:25, b:25, a:52}},
									  focus:{width:5, color:{r:15, g:255, b:25, a:52}},
									  selected:{width:10, color:{r:55, g:255, b:255, a:52}}},
						buttontextfont:{normal:"20px",focus:"30px", selected:"35px"},
						buttontextcolor:{normal:color1,focus:color2, selected:color3}, 
						buttontextVerticalAlignment:"center", 
						buttontextHorizontalAlignment:"center", 
						buttontext:{normal:"cancel",focus:"cancel111", selected:"cancel222"}, 
						buttonimage:{normal:"button/btn_dim.png",focus:"button/btn_focused.png", selected:"button/wizard_btn_sel.png"},
						callbackfunction:cancelcallback}];	 
	* PopupIns.setButton(buttonProperty);
	* @since The version 1.0 this function is added.
	*/
	this.setButton = function(buttonPropertyobj) {
		if(false == this.isCreate){
			return false;
		}
		if(buttonPropertyobj == null||typeof(buttonPropertyobj) == "undefined"){
			return false;
		}
		var buttonCount=buttonPropertyobj.length;
		if(buttonCount > 0) {
			var firstset=true;
			this.buttonCount = buttonCount;
			this.buttonPositionX = this.buttonPositionXList[buttonCount-1];
			var buttonpositionx = 0;
			var num=this.buttonList.length;
			if(num!=0){
				for(var i=num-1;i>=0;i--){
					this.buttonList[i].destroy();
				}
				this.buttonList.splice(0, this.buttonList.length);
			}
			for(var index = 0; index < buttonCount; index++) {
				var tempButton = new Button_Generic();
				this.buttonList.push(tempButton);
				if(buttonPropertyobj[index].hasOwnProperty("x")){
					buttonpositionx=buttonPropertyobj[index].x;
				}
				else {
					buttonpositionx=this.buttonPositionX+282*index;
				}
				if(buttonPropertyobj[index].hasOwnProperty("y")){
					this.buttonPositionY=buttonPropertyobj[index].y;
				}
				if(buttonPropertyobj[index].hasOwnProperty("width")){
					this.buttonWidth=buttonPropertyobj[index].width;
				}
				if(buttonPropertyobj[index].hasOwnProperty("height")){
					this.buttonHeight=buttonPropertyobj[index].height;
				}
				
				this.buttonList[index].create({
					x : buttonpositionx,
					y : this.buttonPositionY,
					width : this.buttonWidth,
					height : this.buttonHeight,
					parent:this.PopupBGWidget
				});
				if(buttonPropertyobj[index].hasOwnProperty("buttonborder")){
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("normal")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonborder.normal);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("focus")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonborder.focus);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("selected")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonborder.selected);
					}
					if(buttonPropertyobj[index].buttonborder.hasOwnProperty("dim")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonborder.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextcolor")){
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("normal")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontextcolor.normal);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("focus")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontextcolor.focus);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("selected")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontextcolor.selected);
					}
					if(buttonPropertyobj[index].buttontextcolor.hasOwnProperty("dim")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontextcolor.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextfont")){
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.normal)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontextfont.normal);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.focus)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontextfont.focus);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.selected)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontextfont.selected);
						}
					}
					if(buttonPropertyobj[index].buttontextfont.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttontextfont.dim)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontextfont.dim);
						}
					}
				}
				
				if(buttonPropertyobj[index].hasOwnProperty("buttontextVerticalAlignment")){
					this.buttonList[index].setTextVerticalAlignment(buttonPropertyobj[index].buttontextVerticalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontextHorizontalAlignment")){
					this.buttonList[index].setTextHorizontalAlignment(buttonPropertyobj[index].buttontextHorizontalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttontext")){
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.normal)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttontext.normal);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.focus)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttontext.focus);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.selected)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttontext.selected);
						}
					}
					if(buttonPropertyobj[index].buttontext.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttontext.dim)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttontext.dim);
						}
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonimage")){
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("normal")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonimage.normal);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("focus")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonimage.focus);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("selected")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonimage.selected);
					}
					if(buttonPropertyobj[index].buttonimage.hasOwnProperty("dim")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonimage.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("callbackfunction")){
					if(firstset == true){
						this.buttonCallbackList.splice(0, this.buttonCallbackList.length);
						firstset=false;
					}
					this.buttonCallbackList[index]=buttonPropertyobj[index].callbackfunction;
					this.buttonList[index].setMouseClickCallback(this.t_buttonClickCallbackBind);
				}
				this.buttonList[index].index=index;
				this.buttonList[index].setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind, 
																outCallback:this.m_buttonMouseOutCallBackBind});
				this.buttonList[index].show();			
			}
			if(this.focus==true){
				if(this.focusIndex<buttonCount)
				{
					this.buttonList[this.focusIndex].getFocus();
				}
				
			}
			return true;
		}
		return false;
	};
	
	this.t_buttonClickCallback=function(widget){
		var index=widget.index;
		if(typeof(this.buttonCallbackList[index]) != "undefined"||this.buttonCallbackList[index]!=null){
			this.buttonCallbackList[index]();
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	this.t_buttonClickCallbackBind=this.t_buttonClickCallback.bind(this);
	
	this.t_setMouseOverOutCallback = function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("overCallback")){
			this.mouseOverCallBack=obj.overCallback;
		}
		if(obj.hasOwnProperty("outCallback")){
			this.mouseOutCallBack=obj.outCallback;
		}
		return true;
	};
	
	this.t_MouseOverOut = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openOverout==false){
					this.PopupBGWidget.addEventListener("OnMouseOver",this.t_ratingPopupMouseOverBind);										
					this.PopupBGWidget.addEventListener("OnMouseOut",this.t_ratingPopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseOverOut(true);
						}							
					}
					if(this.Rating!=null){
						this.Rating.index=this.buttonCount;
						this.Rating.enableMouseOverOut(true);
					}
					this.openOverout=true;
				}
			}
			else{
				if(this.openOverout==true){
					this.PopupBGWidget.removeEventListener("OnMouseOver",this.t_ratingPopupMouseOverBind);										
					this.PopupBGWidget.removeEventListener("OnMouseOut",this.t_ratingPopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseOverOut(false);
						}							
					}
					if(this.Rating!=null){
						this.Rating.enableMouseOverOut(false);
					}
					this.openOverout=false;
				}
			}
		}
	};
	
	this.t_MouseUpDown = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openUpdown==false){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(true);
						}						
					}
					this.openUpdown=true;
				}	
			}
			else{
				if(this.openUpdown==true){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(false);
						}					
							
					}
					this.openUpdown=false;
				}	
			}
		}
	};
	
	this.t_MouseClick = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openClick==false){
					if(this.Rating!=null){
						this.Rating.enableMouseClick(true);
					}
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseClick(true);
						}					
							
					}
					this.openClick=true;
				}	
			}
			else{
				if(this.openClick==true){
					if(this.Rating!=null){
						this.Rating.enableMouseClick(false);
					}
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseClick(false);
						}					
							
					}
					this.openClick=false;
				}	
			}
		}
	};
	
	this.m_buttonMouseOverCallBack = function(widget){
		var index=widget.index;
		if(this.focus == true && this.focusIndex!=index){
			if(this.focusIndex == this.buttonCount){
				this.Rating.loseFocus();
			}
			else if((this.focusIndex>=0)&&(this.focusIndex<this.buttonCount)){
				this.buttonList[this.focusIndex].loseFocus();
			}
			else{
			}
			this.focusIndex=index;
			if(this.focusIndex == this.buttonCount){
				this.Rating.getFocus();
			}
			else if((this.focusIndex>=0)&&(this.focusIndex<this.buttonCount)){
				this.buttonList[this.focusIndex].getFocus();
			}
			else{
			}
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
	
	};
	this.m_buttonMouseOverCallBackBind=this.m_buttonMouseOverCallBack.bind(this);
	
	this.m_buttonMouseOutCallBack = function(widget){

	};
	this.m_buttonMouseOutCallBackBind=this.m_buttonMouseOutCallBack.bind(this);
	
	this.t_ratingPopupMouseOver = function(targetWidget, eventData) {
		//this.getFocus();
		if(null!=this.mouseOverCallBack){
			this.mouseOverCallBack(this);
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_ratingPopupMouseOverBind=this.t_ratingPopupMouseOver.bind(this);

	this.t_ratingPopupMouseOut = function(targetWidget, eventData) {
		var x=eventData.coordinates.x;
		var y=eventData.coordinates.y;
		var abx=x-this.initx;
		var aby=y-this.inity;
		if(abx<=this.bgWidth&&abx>=0&&aby<=this.bgHeight&&aby>=0){
			return false;
		}
		else{
		//	this.loseFocus();
		}
		if(null!=this.mouseOutCallBack){
			this.mouseOutCallBack(this);
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_ratingPopupMouseOutBind=this.t_ratingPopupMouseOut.bind(this);
	
	this.t_getFocus = function() {
		if(true == this.focus){
			return false;
		}
		else{
			if(this.focusIndex==this.buttonCount){
				this.Rating.getFocus();
			}
			else{
				this.buttonList[this.focusIndex].getFocus();
			}
			this.focus=true;
			return true;
		}
	    	
	};
	
	this.t_loseFocus = function() {
		if(false == this.focus){
			return false;
		}
		else{
			if(this.focusIndex==this.buttonCount){
				this.Rating.getFocus();
			}
			else{
				this.buttonList[this.focusIndex].loseFocus();
			}
			this.focus=false;
			return true;
		}
	};
	
	/**
	* This function will set the focus position in RatingPopup created,it will work after getFocus.<p>
	* This function will set the focus position in RatingPopup created,You can use this function when you want to set the focus position.
	* @param {Number} the index of object you want to focus,in this RatingPopup,the rating index is rating index add button count.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set focus position.
	* PopupIns.setFocusIndex(0);
	* @since The version 1.0 this function is added.
	*/
	this.setFocusIndex = function(focusIdx) {	
		if(focusIdx >= 0 && focusIdx <= this.buttonCount) {
			this.focusIndex = focusIdx;
			return true;
		}
		return false;
	};
}

RatingPopup.prototype = new ControlBase();
exports = RatingPopup;
