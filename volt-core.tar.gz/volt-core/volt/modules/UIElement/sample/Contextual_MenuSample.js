Contextual_Menu = require("UIElement/Contextual_Menu");
Contextual_MenuRenderBase = require("UIElement/Contextual_MenuRenderBase");

logArea = new TextWidget({
	x: 0,
	y: 0,
	width: 1920,
	height: 1080,
	textColor: {r: 255, g: 255, b: 255, a: 255},
	text: "logArea",
	parent: scene,
});

function log(text, append) {
	if (append) {
		logArea.text += "\n"+text.toString();
	} else {
		logArea.text = text.toString();
	}
}

BothListCheckRender = function() {
	this.m_CheckBoxBG = null;
	this.m_CheckBox = null;
	this.m_MenuText = null;
	this.m_MenuBottomLine = null;
	this.m_NumberText = null;
	this.m_MenuBottomLine = null;
	this.m_ChildParent = null;
	this.m_EnlargeHeight = 0;
	this.m_EnlargeWidth = 0;
	this.mouseOverCallback = null;
	this.mouseOutCallback = null;
	this.mouseClickCallback = null;
	
	
	//four status text color
	this.HIGHCOLOR = {r: 255, g: 255, b: 255, a:204};
	this.UNHIGHCOLOR = {r: 150, g: 150, b: 150, a:255};
	this.SELECTEDCOLOR = {r: 255, g: 248, b: 38, a:255};
	this.DIMCOLOR = {r: 255, g: 255, b: 255, a:25.5};
	
	//four status Check box resource
	this.CheckBoxSrc = {normal:"CheckBox/popup_check_box_n.png", focus:"CheckBox/popup_check_box_f.png",
						dim:"CheckBox/popup_check_box_d.png", selected:"CheckBox/popup_check_box_s.png"};
	
	//four status check icon resource
	this.CheckIconSrc = {normal:"CheckBox/popup_check_icon_n.png", focus:"CheckBox/popup_check_icon_f.png", 
						 dim:"CheckBox/popup_check_icon_d.png", selected:"CheckBox/popup_check_icon_s.png"};

	this.t_create = function(param) {
		this.color = {r: 125, g: 125, b: 125};
		this.m_ChildParent = param.parent;
		this.m_EnlargeHeight = param.enlargeHeight;
		this.m_EnlargeWidth = param.enlargeWidth;
	
		this.m_CheckBoxBG = new ImageWidget({
			x: 0,
			y: 0,
			src: this.CheckBoxSrc.normal,
			parent: param.parent,
		});
		this.m_CheckBoxBG.anchor.y = 0.5;
		this.m_CheckBoxBG.origin.y = 0.5;
		
		this.m_CheckBox = new ImageWidget({
			x: 0,
			y: 0,
			src: this.CheckIconSrc.normal,
			opacity: 0,
			parent: this.m_CheckBoxBG,
		});
	};
	
	this.t_destroy = function(){
		delete this.BothListMouseClickBind;
		delete this.BothListMouseOverBind;
		delete this.BothListMouseOutBind;	
	};
	
	this.t_getFocus = function() {
		this.m_CheckBoxBG.src = this.CheckBoxSrc.focus;
		this.m_CheckBox.src = this.CheckIconSrc.focus;
		
		if (this.m_MenuText){
			this.m_MenuText.textColor = this.HIGHCOLOR;
		}
		if (this.m_NumberBottomLine) {
			this.m_NumberText.textColor = this.HIGHCOLOR;
		}
		if (this.m_MenuBottomLine){
			this.m_MenuBottomLine.opacity = 255;
		}
		
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.opacity = 255;
		}
		this.animate("height", this.m_EnlargeHeight, 100);
		if (this.m_MenuText){
			this.m_MenuText.animate("height", this.m_EnlargeHeight, 100);
		}
		if (this.m_NumberText) {
			this.m_NumberText.animate("height", this.m_EnlargeHeight, 100);
		}
	};
	
	this.t_loseFocus = function() {		
		this.m_CheckBoxBG.src = this.CheckBoxSrc.normal;
		this.m_CheckBox.src = this.CheckIconSrc.normal;
		
		if (this.m_MenuText){
			this.m_MenuText.textColor = this.UNHIGHCOLOR;
		}
		if (this.m_NumberBottomLine) {
			this.m_NumberText.textColor = this.UNHIGHCOLOR;
		}
		this.m_MenuBottomLine.opacity = 0;
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.opacity = 0;
		}
		this.animate("height", 80, 100);
		if (this.m_MenuText){
			this.m_MenuText.animate("height", 80, 100);
		}
		if (this.m_NumberText) {
			this.m_NumberText.animate("height", 80, 100);
		}
	};
	
	this.t_getDim = function() {
		this.m_CheckBoxBG.src = this.CheckBoxSrc.dim;
		this.m_CheckBox.src = this.CheckIconSrc.dim;
	
		if (this.m_MenuText){
			this.m_MenuText.textColor = this.DIMCOLOR;
		}
		
		if (this.m_NumberBottomLine) {
			this.m_NumberText.textColor = this.DIMCOLOR;
		}
		
		if (this.m_MenuBottomLine){
			this.m_MenuBottomLine.color = this.DIMCOLOR;
		}
		
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.color = this.DIMCOLOR;
		}
	};
	
	this.t_loseDim = function() {
		if (this.isFocused){
			this.m_CheckBoxBG.src = this.CheckBoxSrc.focus;
			this.m_CheckBox.src = this.CheckIconSrc.focus;
			
			if (this.m_MenuText){
				this.m_MenuText.textColor = this.HIGHCOLOR;
			}
			
			if (this.m_MenuBottomLine){
				this.m_MenuBottomLine.textColor = this.HIGHCOLOR;
			}
			
			if (this.m_NumberText){
				this.m_NumberText.textColor = this.HIGHCOLOR;
			}
			
			if (this.m_NumberBottomLine){
				this.m_NumberBottomLine.color = this.HIGHCOLOR;
			}
			
		}
		else{
			this.m_CheckBoxBG.src = this.CheckBoxSrc.normal;
			this.m_CheckBox.src = this.CheckIconSrc.normal;
			
			if (this.m_MenuText){
				this.m_MenuText.textColor = this.UNHIGHCOLOR;
			}
			
			if (this.m_MenuBottomLine){
				this.m_MenuBottomLine.textColor = this.UNHIGHCOLOR;
			}
			
			if (this.m_NumberText){
				this.m_NumberText.textColor = this.UNHIGHCOLOR;
			}
			
			if (this.m_NumberBottomLine){
				this.m_NumberBottomLine.color = this.UNHIGHCOLOR;
			}
		}
	};
	
	this.t_selected = function() {
		if (this.m_MenuText){
			this.m_MenuText.textColor = this.SELECTEDCOLOR;
		}
		
		if (this.m_NumberBottomLine) {
			this.m_NumberText.textColor = this.SELECTEDCOLOR;
		}
		
		if (this.m_MenuBottomLine){
			this.m_MenuBottomLine.color = this.SELECTEDCOLOR;
		}
		
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.color = this.SELECTEDCOLOR;
		}
	};
	
	this.t_setMouseOverOutCallback = function(obj){
		if (obj.hasOwnProperty("overCallback")){
			this.mouseOverCallback = obj.overCallback;
		}
		
		if (obj.hasOwnProperty("outCallback")){
			this.mouseOutCallback = obj.outCallback
		}
	};

	this.t_setMouseClickCallback = function(callback){
		if (typeof(callback) == "function") {
			this.mouseClickCallback = callback;
		}
	};
	
	this.t_MouseOverOut = function(isOnFlag){
		if (isOnFlag){
			this.rootWidget.addEventListener('OnMouseOut', this.BothListMouseOutBind);
			this.rootWidget.addEventListener('OnMouseOver', this.BothListMouseOverBind);
		}
		else{
			this.rootWidget.removeEventListener('OnMouseOut', this.BothListMouseOutBind);
			this.rootWidget.removeEventListener('OnMouseOver', this.BothListMouseOverBind);
		}
	};
	
	this.t_MouseClick = function(isOnFlag){
		if (isOnFlag){
			this.rootWidget.addEventListener('OnMouseClick', this.BothListMouseClickBind);
		}
		else{
			this.rootWidget.removeEventListener('OnMouseClick', this.BothListMouseClickBind);
		}
	};
	
	this.t_DealMouseOver = function(targetWidget, eventData) {
		//this.getFocus();
		
		if (this.mouseOverCallback) {
			this.mouseOverCallback(this);
		}
		return false;
	};
	this.BothListMouseOverBind = this.t_DealMouseOver.bind(this);
	
	this.t_DealMouseOut = function(targetWidget, eventData) {
		//this.loseFocus();
	
		if (this.mouseOutCallback) {
			this.mouseOutCallback(this);
		}
		return false;
	};
	this.BothListMouseOutBind = this.t_DealMouseOut.bind(this);
	
	this.t_DealMouseClick = function(targetWidget, eventData) {
		
		if (this.mouseClickCallback) {
			this.mouseClickCallback(this);
		}
		return false;
	};
	this.BothListMouseClickBind = this.t_DealMouseClick.bind(this);
	
	this.t_itemUpdate = function(itemData) {
		if (itemData.selected) {
			this.m_CheckBox.opacity = 255;
		} else {
			this.m_CheckBox.opacity = 0;
		}
		
		if (this.m_MenuBottomLine) {
			this.m_MenuBottomLine.destroy();
			this.m_MenuBottomLine = null;
		}
		if (this.m_MenuBottomLine) {
			this.m_MenuBottomLine.destroy();
			this.m_MenuBottomLine = null;
		}
		if (this.m_MenuText) {
			this.m_MenuText.destroy();
			this.m_MenuText = null;
		}
		if (this.m_NumberText) {
			this.m_NumberText.destroy();
			this.m_NumberText = null;
		}
		this.m_MenuText = new TextWidget({
			x: 50,
			y: 0,
			width:this.width*0.7,
			height: this.height,
			parent: this.m_ChildParent,
			textColor: this.UNHIGHCOLOR,
			text: itemData.menu,
			ellipsize : true,
			font: "Samsung SVD_Medium 46px",
		});
		this.m_MenuText.horizontalAlignment = "left";
		this.m_MenuText.verticalAlignment = "center";
		
		this.m_MenuBottomLine = new Widget({
			x: 0,
			y: -2,
			height: 2,
			width: 0,
			parent: this.m_MenuText,
			color: this.HIGHCOLOR,
			opacity: 0,
		});
		this.m_MenuBottomLine.origin.y = 1.0;
		this.m_MenuBottomLine.anchor.y = 1.0;
		this.m_MenuBottomLine.width = this.m_MenuText.getAbsoluteSize().x;
		
		if (typeof(itemData.number)!="undefined") {
			this.m_NumberText = new TextWidget({
				x: 0,
				y: 0,
				height: this.height,
				parent: this.m_ChildParent,
				textColor: this.UNHIGHCOLOR,
				font: "Samsung SVD_Medium 46px",
				text: itemData.number,
			});
			this.m_NumberText.origin.x = 1.0;
			this.m_NumberText.anchor.x = 1.0;
			this.m_NumberText.horizontalAlignment = "right";
			this.m_NumberText.verticalAlignment = "center";
			
			this.m_NumberBottomLine = new Widget({
				x: 0,
				y: -2,
				height: 2,
				width: 0,
				parent: this.m_NumberText,
				color: this.HIGHCOLOR,
				opacity: 0,
			});
			this.m_NumberBottomLine.origin = {x: 1.0, y: 1.0};
			this.m_NumberBottomLine.anchor = {x: 1.0, y: 1.0};
			this.m_NumberBottomLine.width = this.m_NumberText.getAbsoluteSize().x;
		} else {
			this.m_NumberText = null;
			this.m_NumberBottomLine = null;
		}
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		switch (keycode) {
			case Volt.KEY_JOYSTICK_UP:
			case Volt.KEY_JOYSTICK_DOWN:
			case Volt.KEY_JOYSTICK_LEFT:
			case Volt.KEY_JOYSTICK_RIGHT:
				return false;
			case Volt.KEY_JOYSTICK_OK:
				this.m_DataItem.selected = !this.m_DataItem.selected;
				this.DataChanged();
				if (this.m_DataItem.selected) {
					this.m_CheckBox.opacity = 255;
				} else {
					this.m_CheckBox.opacity = 0;
				}
				break;
		}
		return true;
	}
};
BothListCheckRender.prototype = new Contextual_MenuRenderBase();

BothListRender = function() {
	this.m_MenuText = null;
	
	this.HIGHCOLOR = {r: 255, g: 255, b: 255, a:255};
	this.UNHIGHCOLOR = {r: 150, g: 150, b: 150, a:204};
	this.SELECTEDCOLOR = {r: 255, g: 248, b: 38, a:255};
	this.DIMCOLOR = {r: 255, g: 255, b: 255, a:25.5};
	
	this.t_create = function(param) {
		this.color = {r: 255, g: 0, b: 0, a: 255};
		this.m_MenuText = new TextWidget({
			x: 0,
			y: 0,
			height: this.height,
			width: this.width*0.7,
			parent: param.parent,
			textColor: this.UNHIGHCOLOR,
			ellipsize : true,
			font: "Samsung SVD_Medium 46px",
		});
		this.m_MenuText.horizontalAlignment = "center";
		this.m_MenuText.verticalAlignment = "center";
	};
	this.t_destroy = function(){
	};
	
	this.t_getFocus = function() {
		this.m_MenuText.textColor = this.HIGHCOLOR;
	};
	
	this.t_loseFocus = function() {
		this.m_MenuText.textColor = this.UNHIGHCOLOR;
	};
	
	this.t_getDim = function() {
		this.m_MenuText.textColor = this.DIMCOLOR;
	};
	
	this.t_loseDim = function() {
		if (this.isFocused){
			this.m_MenuText.textColor = this.HIGHCOLOR;
		}
		else{
			this.m_MenuText.textColor = this.UNHIGHCOLOR;
		}
	};
	
	this.t_selected = function() {
		this.m_MenuText.textColor = this.SELECTEDCOLOR;
	};
	
	this.t_itemUpdate = function(itemData) {
		this.m_MenuText.text = itemData.menu;
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		switch (keycode) {
			case Volt.KEY_JOYSTICK_UP:
			case Volt.KEY_JOYSTICK_DOWN:
			case Volt.KEY_JOYSTICK_LEFT:
			case Volt.KEY_JOYSTICK_RIGHT:
				return false;
			case Volt.KEY_JOYSTICK_OK:
				break;
		}
		return true;
	}
};
BothListRender.prototype = new Contextual_MenuRenderBase();

Renders = {
	BothListCheckRender: BothListCheckRender,
	BothListRender: BothListRender,
	ListCheckRender: BothListCheckRender,
	ListRender: BothListRender,
};

testText = [{selected: true, menu:"menuokokokokokkokokkkkkkokokokkkkokkoookkkkookkkk0", number: "0"},
			{selected: false, menu:"menu1", number: "1"},
            {selected: false, menu:"menu2", number: "2"},
			{selected: true, menu:"menu3", number: "3"},
			{selected: false, menu:"menu4", number: "4"},
			{selected: true, menu:"menu5", number: "5"},
			{selected: false, menu:"menu6", number: "6"},
			{selected: true, menu:"menu7", number: "7"},
			{selected: false, menu:"menu8", number: "8"},
			{selected: true, menu:"menu9", number: "9"},
			{selected: false, menu:"menu10", number: "10"},
			{selected: false, menu:"menu11", number: "11"},
			{selected: false, menu:"menu12", number: "12"},
			{selected: true, menu:"menu13", number: "13"},
			{selected: true, menu:"menu14", number: "14"},
			{selected: false, menu:"menu15", number: "15"},
			{selected: true, menu:"menu16", number: "16"},
			{selected: false, menu:"menu17", number: "17"},
			{selected: false, menu:"menu18", number: "18"},
			{selected: true, menu:"menu19", number: "19"}];
	
options = {
	ninePatch : {
		left : "9patch_img/list_high_mid_left.png",
		right : "9patch_img/list_high_mid_right.png",
		top : "9patch_img/list_high_upper_center.png",
		bottom : "9patch_img/list_high_lower_center.png",
		topLeft : "9patch_img/list_high_upper_left.png",
		topRight : "9patch_img/list_high_upper_right.png",
		bottomRight : "9patch_img/list_high_lower_right.png",
		bottomLeft : "9patch_img/list_high_lower_left.png"
	}
}

var test = new Contextual_Menu();
log("create");

test.create({
	x: 500,
	y: 100,
	width: 782,
	height: 600,
	parent: scene,
	color: {r: 0, g: 255, b: 255},
	itemWidth: 782,
	itemHeight: 80,
	itemSpace: 20,
	firstItemOffset: 50,
	topMargin: 40,
	bottomMargin: 40,
	totalDataNumber: 4,
	renderType: Renders.BothListCheckRender,
	upArrow: {highlightSrc:"Arrow/popup_arrow_up_f.png", unHighlightSrc:"Arrow/popup_arrow_up_n.png", 
				dimSrc:"Arrow/popup_arrow_up_d.png", x: 30, y: 0},
	downArrow: {highlightSrc: "Arrow/popup_arrow_down_f.png", unHighlightSrc: "Arrow/popup_arrow_down_n.png", 
				dimSrc:"Arrow/popup_arrow_down_d.png", x: 30, y: 560},	
	looping: true,
	style: Contextual_Menu.Style.VERTICAL,
	
});

/*
test.create({
	x: 500,
	y: 100,
	renderType: Renders.BothListRender,
	//upArrow: {highlightSrc: "img/1920/popup_arrow_up_f.png", unHighlightSrc: "img/1920/popup_arrow_up_n.png", x: 50, y: 0},
	//downArrow: {highlightSrc: "img/1920/popup_arrow_down_f.png", unHighlightSrc: "img/1920/popup_arrow_down_n.png", x: 50, y: 100},
	itemHeight: 782,
	itemWidth: 80,
	height: 782,
	width: 790,
	firstItemOffset: 50,
	cursorImageSrc: options,
	enlargeWidth: 200,
	itemSpace: 20,
	totalDataNumber: 20,
	topMargin: 0,
	bottomMargin: 0,
	parent: scene,
	looping: true,
	style: Contextual_Menu.Style.HORIZONTAL,
	color: {r: 255, g: 0, b: 255},
});
*/


test.setItemLoadCB(function(index) {
	test.itemUpdate(index, testText[index]);
});

test.setFocusIndexChangedCB(function(oldIndex, newIndex) {
	log("oldIndex: "+oldIndex+"newIndex:"+newIndex);
});

test.setReachBoundaryCB(function(keycode) {
	switch (keycode) {
		case Volt.KEY_JOYSTICK_UP:
			log("UP");
			break;
		case Volt.KEY_JOYSTICK_DOWN:
			log("DOWN");
			break;
		case Volt.KEY_JOYSTICK_LEFT:
			log("LEFT");
			break;
		case Volt.KEY_JOYSTICK_RIGHT:
			log("RIGHT");
			break;
		default:
			log("ERROR");
	}
});

test.setDataChangedCB(function(index, dataItem) {
	log("dataChanged"+index+"  After Selected:"+dataItem.selected +"  Before Selected:"+testText[index].selected);
	testText[index].selected = dataItem.selected;
});


test.update();
test.getFocus();
//test.getFocus();

test.enableMouseOverOut(true);
test.enableMouseClick(true);

onKeyEvent = function(keycode, keytype){
	test.keyHandler(keycode, keytype);
	log(keycode);
	if (keycode.toString() == "269025187") {
		test.changeItemNumber(4);
		test.currentIndex = 0;
		test.getFocus();
		
	} else if (keycode.toString() == "269025188") {
		test.pageUp();
		//test.loseDim();
	} else if (keycode.toString() == "269025189") {
		test.pageDown();
		//test.getDim();
	}
	
	switch(keycode) {
		case Volt.KEY_1:
			test.destroy();
			break;
	}
}