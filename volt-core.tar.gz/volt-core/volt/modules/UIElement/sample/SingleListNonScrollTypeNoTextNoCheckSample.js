const SimpleLineListForPopupRenderBase = require("UIElement/SimpleLineListForPopupRenderBase");

testText = [{selected: true, menu:"menu0"},
			{selected: false, menu:"menu1"},
            {selected: false, menu:"menu2"},
			{selected: true, menu:"menu3"},
			{selected: false, menu:"menu4"},
			{selected: true, menu:"menu5"},
			{selected: false, menu:"menu6"},
			{selected: true, menu:"menu7"},
			{selected: false, menu:"menu8"},
			{selected: true, menu:"menu9"},
			{selected: false, menu:"menu10"},
			{selected: false, menu:"menu11"},
			{selected: false, menu:"menu12"},
			{selected: true, menu:"menu13"},
			{selected: true, menu:"menu14"},
			{selected: false, menu:"menu15"},
			{selected: true, menu:"menu16"},
			{selected: false, menu:"menu17"},
			{selected: false, menu:"menu18"},
			{selected: true, menu:"menu19"}];
BothListCheckRender = function() {
	this.m_CheckBoxBG = null;
	this.m_CheckBox = null;
	this.m_MenuText = null;
	this.m_MenuBottomLine = null;
	this.m_NumberText = null;
	this.m_MenuBottomLine = null;
	this.m_ChildParent = null;
	
	this.HIGHCOLOR = {r: 255, g: 255, b: 255};
	this.UNHIGHCOLOR = {r: 150, g: 150, b: 150};

	this.t_create = function(param) {
		this.m_ChildParent = param.parent;
	
		this.m_CheckBoxBG = new ImageWidget({
			x: 0,
			y: 0,
			src: "actionWindowImg/popup_check_box.png",
			parent: param.parent,
		});
		this.m_CheckBoxBG.anchor.y = 0.5;
		this.m_CheckBoxBG.origin.y = 0.5;
		
		this.m_CheckBox = new ImageWidget({
			x: 0,
			y: 0,
			src: "actionWindowImg/popup_check_icon.png",
			opacity: 0,
			parent: this.m_CheckBoxBG,
		});
	};
	
	this.t_getFocus = function() {
		this.m_MenuText.textColor = this.HIGHCOLOR;
		if (this.m_NumberBottomLine) {
			this.m_NumberText.textColor = this.HIGHCOLOR;
		}
		this.m_MenuBottomLine.opacity = 255;
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.opacity = 255;
		}
	};
	
	this.t_loseFocus = function() {
		this.m_MenuText.textColor = this.UNHIGHCOLOR;
		if (this.m_NumberBottomLine) {
			this.m_NumberText.textColor = this.UNHIGHCOLOR;
		}
		this.m_MenuBottomLine.opacity = 0;
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.opacity = 0;
		}
	};
	
	this.t_itemUpdate = function(itemData) {
		if (itemData.selected) {
			this.m_CheckBox.opacity = 255;
		} else {
			this.m_CheckBox.opacity = 0;
		}
		
		if (this.m_MenuBottomLine) {
			this.m_MenuBottomLine.destroy();
			this.m_MenuBottomLine = null;
		}
		if (this.m_MenuBottomLine) {
			this.m_MenuBottomLine.destroy();
			this.m_MenuBottomLine = null;
		}
		if (this.m_MenuText) {
			this.m_MenuText.destroy();
			this.m_MenuText = null;
		}
		if (this.m_NumberText) {
			this.m_NumberText.destroy();
			this.m_NumberText = null;
		}
		this.m_MenuText = new TextWidget({
			x: 50,
			y: 0,
			height: this.height,
			parent: this.m_ChildParent,
			textColor: this.UNHIGHCOLOR,
			text: itemData.menu,
			font: "Samsung SVD_Medium 46px",
		});
		this.m_MenuText.horizontalAlignment = "left";
		this.m_MenuText.verticalAlignment = "center";
		
		this.m_MenuBottomLine = new Widget({
			x: 0,
			y: -2,
			height: 2,
			width: 0,
			parent: this.m_MenuText,
			color: this.HIGHCOLOR,
			opacity: 0,
		});
		this.m_MenuBottomLine.origin.y = 1.0;
		this.m_MenuBottomLine.anchor.y = 1.0;
		this.m_MenuBottomLine.width = this.m_MenuText.getAbsoluteSize().x;
		
		if (typeof(itemData.number)!="undefined") {
			this.m_NumberText = new TextWidget({
				x: 0,
				y: 0,
				height: this.height,
				parent: this.m_ChildParent,
				textColor: this.UNHIGHCOLOR,
				font: "Samsung SVD_Medium 46px",
				text: itemData.number,
			});
			this.m_NumberText.origin.x = 1.0;
			this.m_NumberText.anchor.x = 1.0;
			this.m_NumberText.horizontalAlignment = "right";
			this.m_NumberText.verticalAlignment = "center";
			
			this.m_NumberBottomLine = new Widget({
				x: 0,
				y: -2,
				height: 2,
				width: 0,
				parent: this.m_NumberText,
				color: this.HIGHCOLOR,
				opacity: 0,
			});
			this.m_NumberBottomLine.origin = {x: 1.0, y: 1.0};
			this.m_NumberBottomLine.anchor = {x: 1.0, y: 1.0};
			this.m_NumberBottomLine.width = this.m_NumberText.getAbsoluteSize().x;
		} else {
			this.m_NumberText = null;
			this.m_NumberBottomLine = null;
		}
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		switch (keycode) {
			case Volt.KEY_JOYSTICK_UP:
			case Volt.KEY_JOYSTICK_DOWN:
			case Volt.KEY_JOYSTICK_LEFT:
			case Volt.KEY_JOYSTICK_RIGHT:
				return false;
			case Volt.KEY_JOYSTICK_OK:
				this.m_DataItem.selected = !this.m_DataItem.selected;
				this.DataChanged();
				if (this.m_DataItem.selected) {
					this.m_CheckBox.opacity = 255;
				} else {
					this.m_CheckBox.opacity = 0;
				}
				break;
		}
		return true;
	}
};
BothListCheckRender.prototype = new SimpleLineListForPopupRenderBase();

BothListRender = function() {
	this.m_MenuText = null;
	this.m_NumberText = null;
	this.m_MenuBottomLine = null;
	this.m_NumberBottomLine = null;
	
	this.HIGHCOLOR = {r: 255, g: 255, b: 255};
	this.UNHIGHCOLOR = {r: 150, g: 150, b: 150};
	
	this.m_ChildParent = null;
	
	this.t_create = function(param) {
		this.m_ChildParent = param.parent;
	};
	
	this.t_getFocus = function() {
		this.m_MenuText.textColor = this.HIGHCOLOR;
		if (this.m_NumberText) {
			this.m_NumberText.textColor = this.HIGHCOLOR;
		}
		this.m_MenuBottomLine.opacity = 255;
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.opacity = 255;
		}
	};
	
	this.t_loseFocus = function() {
		this.m_MenuText.textColor = this.UNHIGHCOLOR;
		if (this.m_NumberText) {
			this.m_NumberText.textColor = this.UNHIGHCOLOR;
		}
		this.m_MenuBottomLine.opacity = 0;
		if (this.m_NumberBottomLine) {
			this.m_NumberBottomLine.opacity = 0;
		}
	};
	
	this.t_itemUpdate = function(itemData) {
		if (this.m_MenuBottomLine) {
			this.m_MenuBottomLine.destroy();
			this.m_MenuBottomLine = null;
		}
		if (this.m_MenuBottomLine) {
			this.m_MenuBottomLine.destroy();
			this.m_MenuBottomLine = null;
		}
		if (this.m_MenuText) {
			this.m_MenuText.destroy();
			this.m_MenuText = null;
		}
		if (this.m_NumberText) {
			this.m_NumberText.destroy();
			this.m_NumberText = null;
		}
		this.m_MenuText = new TextWidget({
			x: 0,
			y: 0,
			height: this.height,
			parent: this.m_ChildParent,
			textColor: this.UNHIGHCOLOR,
			text: itemData.menu,
			font: "Samsung SVD_Medium 46px",
		});
		this.m_MenuText.horizontalAlignment = "left";
		this.m_MenuText.verticalAlignment = "center";
		
		this.m_MenuBottomLine = new Widget({
			x: 0,
			y: -2,
			height: 2,
			width: 0,
			parent: this.m_MenuText,
			color: this.HIGHCOLOR,
			opacity: 0,
		});
		this.m_MenuBottomLine.origin.y = 1.0;
		this.m_MenuBottomLine.anchor.y = 1.0;
		this.m_MenuBottomLine.width = this.m_MenuText.getAbsoluteSize().x;
		
		if (typeof(itemData.number)!="undefined") {
			this.m_NumberText = new TextWidget({
				x: 0,
				y: 0,
				height: this.height,
				parent: this.m_ChildParent,
				textColor: this.UNHIGHCOLOR,
				font: "Samsung SVD_Medium 46px",
				text: itemData.number,
			});
			this.m_NumberText.origin.x = 1.0;
			this.m_NumberText.anchor.x = 1.0;
			this.m_NumberText.horizontalAlignment = "right";
			this.m_NumberText.verticalAlignment = "center";
			
			this.m_NumberBottomLine = new Widget({
				x: 0,
				y: -2,
				height: 2,
				width: 0,
				parent: this.m_NumberText,
				color: this.HIGHCOLOR,
				opacity: 0,
			});
			this.m_NumberBottomLine.origin = {x: 1.0, y: 1.0};
			this.m_NumberBottomLine.anchor = {x: 1.0, y: 1.0};
			this.m_NumberBottomLine.width = this.m_NumberText.getAbsoluteSize().x;
		} else {
			this.m_NumberText = null;
			this.m_NumberBottomLine = null;
		}
	};
	
	this.t_keyHandler = function(keycode, keytype) {
		switch (keycode) {
			case Volt.KEY_JOYSTICK_UP:
			case Volt.KEY_JOYSTICK_DOWN:
			case Volt.KEY_JOYSTICK_LEFT:
			case Volt.KEY_JOYSTICK_RIGHT:
				return false;
			case Volt.KEY_JOYSTICK_OK:
				break;
		}
		return true;
	}
};
BothListRender.prototype = new SimpleLineListForPopupRenderBase();

SimpleLineListForPopupRenders = {
	BothListCheckRender: BothListCheckRender,
	BothListRender: BothListRender,
	ListCheckRender: BothListCheckRender,
	ListRender: BothListRender,
};				
			
var initialize = function() {
	
	var TOP_ = {
		r : 82,
		g : 82,
		b : 82,
		a : 255
	};
	var BOTTOM_ = {
		r : 12,
		g : 12,
		b : 12,
		a : 255
	};
	tempBG = new Widget({
		x : 0,
		y : 0,
		width : 1920,
		height : 1080,
		parent : scene
	});
	tempBG.gradient = {
		tlColor : TOP_,
		trColor : TOP_,
		blColor : BOTTOM_,
		brColor : BOTTOM_
	};
	
	var script_AID = "UIElement/ActionWindow";
	 ActionWindow = require(script_AID);
	 
	 sampleActionWindow = new ActionWindow();
	 sampleActionWindow.create({x:0, 
								y:212, 
								width:1920, 
								height:656,
								color:{r: 10, g: 93, b: 136, a: 217},
								parent:scene,
								scrollTypeFlag:false,
								withContentFlag:false
							});
	sampleActionWindow.setTitleAtrr({ x:399, 
									  y:5, 
								      width:1122, 
								      height:90,
									  text:"Action Window",
									  textColor:{r:255, g:255, b:255},
									  textFont:"Samsung SVD_Medium 46px"});
	sampleActionWindow.setSplitLineAtrr({x:399, 
										 y:95, 
										 width:1122, 
								         height:1,
									     color:{r:255, g:255, b:255, a:51}
										});
	sampleActionWindow.setBothListAtrr({x:568,
										y:97,
										itemWidth:782,
										itemHeight:72,
										listNum:6,
										topMargin:0,
										bottomMargin:0,	
										listRenderType:SimpleLineListForPopupRenders.ListRender
	});	
	sampleActionWindow.setBothListItemLoadCB(function(index) {
			sampleActionWindow.itemUpdate(index, testText[index]);
	});	
	sampleActionWindow.setBothListCheckStatusChangedCB(function(index, dataItem) {
			//log("dataChanged"+index+"  After Selected:"+dataItem.selected +"  Before Selected:"+testText[index].selected);
			testText[index].selected = dataItem.selected;
		}	
	);
	sampleActionWindow.setBothListItemFocusChangedCB(function(oldIndex, newIndex){
		//log("oldIndex: "+oldIndex+"newIndex:"+newIndex);
	});
	sampleActionWindow.bothListUpdate();
										
	sampleActionWindow.setOKButtonAtrr({x:684,
										y:560,
										width:270,
										height:66,
										textFont:"Samsung SVD_Light 32px"
									});
	
	sampleActionWindow.setOKButtonStatusSrc({text:"OK",
											 textColor:{r:255, g:255, b:255},
											 imageSrc:"button/popup_btn_d.png",
											 status:sampleActionWindow.OKButton.buttonState.STATE_UNFOCUSED
											});	
	sampleActionWindow.setOKButtonStatusSrc({text:"OK",
											 textColor:{r:255, g:255, b:255},
											 imageSrc:"button/popup_btn_f.png",
											 status:sampleActionWindow.OKButton.buttonState.STATE_FOCUSED
											});
	sampleActionWindow.setOKButtonStatusSrc({text:"OK",
											 textColor:{r:255, g:255, b:255},
											 imageSrc:"button/popup_btn_s.png",
											 status:sampleActionWindow.OKButton.buttonState.STATE_PRESSED
											});		
	sampleActionWindow.setOKButtonStatusSrc({text:"OK",
											 textColor:{r:255, g:255, b:255},
											 imageSrc:"button/popup_btn_n.png",
											 status:sampleActionWindow.OKButton.buttonState.STATE_DISABLED
											});										
	sampleActionWindow.OKButton.show();											
																						
	sampleActionWindow.setCancelButtonAttr({x:966,
											y:560,
											width:270,
											height:66,
											textFont:"Samsung SVD_Light 32px"
										});
								
	sampleActionWindow.setCancelButtonStatusSrc({text:"Cancel",
												 textColor:{r:255, g:255, b:255},
												 imageSrc:"button/popup_btn_d.png",
												 status:sampleActionWindow.cancelButton.buttonState.STATE_UNFOCUSED
												});	
	sampleActionWindow.setCancelButtonStatusSrc({text:"Cancel",
												 textColor:{r:255, g:255, b:255},
												 imageSrc:"button/popup_btn_f.png",
												 status:sampleActionWindow.cancelButton.buttonState.STATE_FOCUSED
												});
	sampleActionWindow.setCancelButtonStatusSrc({text:"Cancel",
												 textColor:{r:255, g:255, b:255},
												 imageSrc:"button/popup_btn_s.png",
												 status:sampleActionWindow.cancelButton.buttonState.STATE_PRESSED
												});		
	sampleActionWindow.setCancelButtonStatusSrc({text:"Cancel",
												 textColor:{r:255, g:255, b:255},
												 imageSrc:"button/popup_btn_n.png",
												 status:sampleActionWindow.cancelButton.buttonState.STATE_DISABLED
												});	
	sampleActionWindow.cancelButton.show();	

	sampleActionWindow.getFocus();	

}

function onKeyEvent(keycode, keytype) {
		sampleActionWindow.keyHandler(keycode, keytype);
		
		switch(keycode) {
			case Volt.KEY_JOYSTICK_LEFT:
				
				break;
			case Volt.KEY_JOYSTICK_RIGHT:
		
				break;
		}
		
}