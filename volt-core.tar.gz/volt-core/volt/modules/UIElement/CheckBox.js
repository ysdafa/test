 /** 
 * @author  
 * @fileoverview Definition of CheckBox
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
 
 
ControlBase = require("UIElement/ControlBase");
function setTimeout(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
}

    
CheckBox = function() {     
    this.Status = {
        NORMAL:0,
        FOCUS:1,
        SELECTED:2,
		DIM:3,
		
        MAX_STATUS:4//dont add status after this!
    };

    this.CheckStatus = {
        UNCHECKED:0,
        CHECKED:1
    };
              
    this.status = this.Status.NORMAL;
    this.checkStatus = this.CheckStatus.UNCHECKED;
    this.stateTextColor = [];
    this.stateIconBGURL = [];
	this.stateIconURL = [];
    this.CursorInstance = null;
    this.checkBoxBGWidget = null;
	this.mouseOverCallback = null;
	this.mouseOutCallback = null;
	this.mouseClickCallback = null;
	this.index = -1;
        
    /**
		* This function creates a CheckBox object. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example create a checkBox object.
		*var tempCheckBox = new CheckBox();
        *tempCheckBox.create({x:100, y:100 + 55 * i, width:200, height:50, focusImages:options, parent:tempBG,
        *                   color:{r:166, g:166, b:166, a:166},
        *                    IconBG:{x:10, y:0, width:50, height:50},
        *                    IconBGSrc:{normal:"CheckBox/popup_check_box_n.png", focus:"CheckBox/popup_check_box_f.png",
        *                                dim:"CheckBox/popup_check_box_d.png", selected:"CheckBox/popup_check_box_s.png"},
        *                    IconSrc:{normal:"CheckBox/popup_check_icon_n.png", focus:"CheckBox/popup_check_icon_f.png", 
        *                                dim:"CheckBox/popup_check_icon_d.png", selected:"CheckBox/popup_check_icon_s.png"},
        *                    TextAttr:{x:65, y:0, width:135, height:50, text:CheckText[i], font:"Helvetica 20px", 
        *                              horizontalAlignment:"left", verticalAlignment:"center"},
        *                    TextColor:{normal:{r: 150, g: 150, b: 150, a:204}, focus:{r:255, g:255, b:255, a:255},
        *                                dim:{r: 255, g: 255, b: 255, a:25.5}, selected:{r: 255, g: 248, b: 38, a:255}},
        *                    index:i});
		* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
		var IconBG_x = 10;		
		var IconBG_y = 0;
		var IconBG_width = 50;
		var IconBG_height = 50;
		
		if (obj.hasOwnProperty("IconBG")){
			if (obj.IconBG.hasOwnProperty("x")){
				IconBG_x = obj.IconBG.x;
			}
			
			if (obj.IconBG.hasOwnProperty("y")){
				IconBG_y = obj.IconBG.y;
			}
			
			if (obj.IconBG.hasOwnProperty("width")){
				IconBG_width = obj.IconBG.width;
			}
			
			if (obj.IconBG.hasOwnProperty("height")){
				IconBG_height = obj.IconBG.height;
			}	
		}
		
        this.stateTextColor[this.Status.NORMAL] = {r: 150, g: 150, b: 150, a:204};
        this.stateIconBGURL[this.Status.NORMAL] = "CheckBox/popup_check_box_n.png";
		this.stateIconURL[this.Status.NORMAL] = "CheckBox/popup_check_icon_n.png";
		
		this.stateTextColor[this.Status.FOCUS] = {r:255, g:255, b:255, a:255};
        this.stateIconBGURL[this.Status.FOCUS] = "CheckBox/popup_check_box_f.png";
		this.stateIconURL[this.Status.FOCUS] = "CheckBox/popup_check_icon_f.png";
		
		this.stateTextColor[this.Status.DIM] = {r: 255, g: 255, b: 255, a:25.5};
        this.stateIconBGURL[this.Status.DIM] = "CheckBox/popup_check_box_d.png";
		this.stateIconURL[this.Status.DIM] = "CheckBox/popup_check_icon_d.png";
		
		this.stateTextColor[this.Status.SELECTED] = {r: 255, g: 248, b: 38, a:255};
        this.stateIconBGURL[this.Status.SELECTED] = "CheckBox/popup_check_box_s.png";
		this.stateIconURL[this.Status.SELECTED] = "CheckBox/popup_check_icon_s.png";
		
		
		if (obj.hasOwnProperty("IconBGSrc")){
			if (obj.IconBGSrc.hasOwnProperty("normal")){
				this.stateIconBGURL[this.Status.NORMAL] = obj.IconBGSrc.normal;
			}
			
			if (obj.IconBGSrc.hasOwnProperty("focus")){
				this.stateIconBGURL[this.Status.FOCUS] = obj.IconBGSrc.focus;
			}
			
			if (obj.IconBGSrc.hasOwnProperty("dim")){
				this.stateIconBGURL[this.Status.DIM] = obj.IconBGSrc.dim;
			}
			
			if (obj.IconBGSrc.hasOwnProperty("selected")){
				this.stateIconBGURL[this.Status.SELECTED] = obj.IconBGSrc.selected;
			}	
		}
    
        this.IconBGInstance = new ImageWidget({
            x : IconBG_x,
            y : IconBG_y,
            width : IconBG_width,
            height : IconBG_height,
            parent : obj.parent,
			src:this.stateIconBGURL[this.Status.NORMAL],
        });
		this.IconBGInstance.origin.y = 0.5;
		this.IconBGInstance.anchor.y = 0.5;	
		
		if (obj.hasOwnProperty("IconSrc")){
			if (obj.IconSrc.hasOwnProperty("normal")){
				this.stateIconURL[this.Status.NORMAL] = obj.IconSrc.normal;
			}
			
			if (obj.IconSrc.hasOwnProperty("focus")){
				this.stateIconURL[this.Status.FOCUS] = obj.IconSrc.focus;
			}
			
			if (obj.IconSrc.hasOwnProperty("dim")){
				this.stateIconURL[this.Status.DIM] = obj.IconSrc.dim;
			}
			
			if (obj.IconSrc.hasOwnProperty("selected")){
				this.stateIconURL[this.Status.SELECTED] = obj.IconSrc.selected;
			}	
		}
		
        this.IconInstance = new ImageWidget({
            x : 0,
            y : 0,
            width : IconBG_width,
            height : IconBG_height,
            parent : this.IconBGInstance,
			src:this.stateIconURL[this.Status.NORMAL],
        });
        this.IconInstance.hide();
    
        var Text_x = 65;		
		var Text_y = 0;
		var Text_width = 100;
		var Text_height = 50;
		var Text_font = "Helvetica 20px";
		var Text_horizontalAlignment = "left";
		var Text_verticalAlignment = "center";
		var Text_content = "";
		
		if (obj.hasOwnProperty("TextAttr")){
			if (obj.TextAttr.hasOwnProperty("x")){
				Text_x = obj.TextAttr.x;
			}
			
			if (obj.TextAttr.hasOwnProperty("y")){
				Text_y = obj.TextAttr.y;
			}
			
			if (obj.TextAttr.hasOwnProperty("width")){
				Text_width = obj.TextAttr.width;
			}
			
			if (obj.TextAttr.hasOwnProperty("height")){
				Text_height = obj.TextAttr.height;
			}
			
			if (obj.TextAttr.hasOwnProperty("text")){
				Text_content = obj.TextAttr.text;
			}

			if (obj.TextAttr.hasOwnProperty("font")){
				Text_font = obj.TextAttr.font;
			}

			if (obj.TextAttr.hasOwnProperty("horizontalAlignment")){
				Text_horizontalAlignment = obj.TextAttr.horizontalAlignment;
			}

			if (obj.TextAttr.hasOwnProperty("verticalAlignment")){
				Text_verticalAlignment = obj.TextAttr.verticalAlignment;
			}			
		}
		
		if (obj.hasOwnProperty("TextColor")){
			if (obj.TextColor.hasOwnProperty("normal")){
				this.stateTextColor[this.Status.NORMAL] = obj.TextColor.normal;
			}
			
			if (obj.TextColor.hasOwnProperty("focus")){
				this.stateTextColor[this.Status.FOCUS] = obj.TextColor.focus;
			}
			
			if (obj.TextColor.hasOwnProperty("dim")){
				this.stateTextColor[this.Status.DIM] = obj.TextColor.dim;
			}
			
			if (obj.TextColor.hasOwnProperty("selected")){
				this.stateTextColor[this.Status.SELECTED] = obj.TextColor.selected;
			}	
		}
		
		this.TextInstance = new TextWidget({
            x : Text_x,
            y : Text_y,
            width : Text_width,
            height : Text_height,
			text : Text_content,
            font : Text_font,
            horizontalAlignment : Text_horizontalAlignment,
            verticalAlignment : Text_verticalAlignment,
            textColor : this.stateTextColor[this.Status.NORMAL],
			ellipsize : true,
            parent : obj.parent,
        });    
        
        //cursor
        cursorClass	= require("CursorComponent");
        this.CursorInstance = new cursorClass(obj.focusImages);
        this.CursorInstance.x = 0;
        this.CursorInstance.y = 0;
        this.CursorInstance.parent = obj.parent;
        this.CursorInstance.move(0, 0, obj.width, obj.height);
        this.CursorInstance.hide();
		
        this.index = obj.index;
		this.checkBoxBGWidget = obj.parent;
    };
	
	this.t_destroy = function() {
		if (this.IconInstance != null){
			this.IconInstance.destroy();
			this.IconInstance = null;
		}
		
		if (this.IconBGInstance != null){
			this.IconBGInstance.destroy();
			this.IconBGInstance = null;
		}
		
		if (this.TextInstance != null){
			this.TextInstance.destroy();
			this.TextInstance = null;
		}
		
		if (this.CursorInstance != null){
			this.CursorInstance.destroy();
			this.CursorInstance = null;
		}
		
		this.stateTextColor.splice(0, this.stateTextColor.length);
		this.stateTextColor = null;
		this.stateIconBGURL.splice(0, this.stateIconBGURL.length);
		this.stateIconBGURL = null;
		this.stateIconURL.splice(0, this.stateIconURL.length);
		this.stateIconURL = null;
		
		delete this.checkboxMouseOutBind;
		delete this.checkboxMouseOverBind;
		delete this.checkboxMouseClickBind;
    };
	
	/**
		* This function sets checkBox mouse over and out event callback. 
		* @param {Object} param for this function.
		* @return void
		* @example //This function sets checkBox mouse over and out event callback. 
		*tempCheckBox.setMouseOverOutCallback({overCallback:checkListMouseOverCallback, outCallback: checkListMouseOutCallback});
		* @since The version 1.0 this function is added.
	*/	
	this.t_setMouseOverOutCallback = function(obj){	
		if (obj.hasOwnProperty("overCallback") && (null != obj.overCallback)){
			this.mouseOverCallback = obj.overCallback;
		}
		
		if (obj.hasOwnProperty("outCallback") && (null != obj.outCallback)){
			this.mouseOutCallback = obj.outCallback
		}
	};
    
	this.checkboxMouseOver =function(targetWidget, eventData) {
		
		if(null != this.mouseOverCallback){
            this.mouseOverCallback(this);
        }
		
		return false;
    };
    this.checkboxMouseOverBind = this.checkboxMouseOver.bind(this);
    
    this.checkboxMouseOut = function(targetWidget, eventData) {
 	
		if(null != this.mouseOutCallback){
            this.mouseOutCallback(this);
        }
		
		return false;
    };
    this.checkboxMouseOutBind = this.checkboxMouseOut.bind(this);
    
	this.t_setMouseClickCallback = function(callback){
		this.mouseClickCallback = callback;
	};
	
    this.checkboxMouseClick = function(targetWidget, eventData) {
        if(this.status == this.Status.DIM)
        {
            return false;
        }
        if(this.checkStatus == this.CheckStatus.UNCHECKED)
        {
            this.setCheckBoxCheckStatus(this.CheckStatus.CHECKED);
        }
        else if(this.checkStatus == this.CheckStatus.CHECKED)
        {
            this.setCheckBoxCheckStatus(this.CheckStatus.UNCHECKED);
        }
       
	   if(null != this.mouseClickCallback){
            this.mouseClickCallback(this);
       }
		
		return false;
    };	
    this.checkboxMouseClickBind = this.checkboxMouseClick.bind(this);
	
	/**
		* This function creates a CheckBox object. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example create a checkBox object.
		*var tempCheckBox = new CheckBox();
        *tempCheckBox.create({x:100, y:100 + 55 * i, width:200, height:50, focusImages:options, parent:tempBG,
        *                   color:{r:166, g:166, b:166, a:166},
        *                    IconBG:{x:10, y:0, width:50, height:50},
        *                    IconBGSrc:{normal:"CheckBox/popup_check_box_n.png", focus:"CheckBox/popup_check_box_f.png",
        *                                dim:"CheckBox/popup_check_box_d.png", selected:"CheckBox/popup_check_box_s.png"},
        *                    IconSrc:{normal:"CheckBox/popup_check_icon_n.png", focus:"CheckBox/popup_check_icon_f.png", 
        *                                dim:"CheckBox/popup_check_icon_d.png", selected:"CheckBox/popup_check_icon_s.png"},
        *                    TextAttr:{x:65, y:0, width:135, height:50, text:CheckText[i], font:"Helvetica 20px", 
        *                              horizontalAlignment:"left", verticalAlignment:"center"},
        *                    TextColor:{normal:{r: 150, g: 150, b: 150, a:204}, focus:{r:255, g:255, b:255, a:255},
        *                                dim:{r: 255, g: 255, b: 255, a:25.5}, selected:{r: 255, g: 248, b: 38, a:255}},
        *                    index:i});
		* @since The version 1.0 this function is added.
	*/	
	this.t_MouseOverOut = function(isOnFlag){
		if (isOnFlag){
			this.checkBoxBGWidget.addEventListener("OnMouseOver", this.checkboxMouseOverBind);
			this.checkBoxBGWidget.addEventListener("OnMouseOut", this.checkboxMouseOutBind);
		
		}
		else{
			this.checkBoxBGWidget.removeEventListener("OnMouseOver", this.checkboxMouseOverBind);
			this.checkBoxBGWidget.removeEventListener("OnMouseOut", this.checkboxMouseOutBind);
		}
	};
	
	this.t_MouseClick = function(isOnFlag){
		if (isOnFlag){
		  this.checkBoxBGWidget.addEventListener("OnMouseClick", this.checkboxMouseClickBind);
		}
		else{
			this.checkBoxBGWidget.removeEventListener("OnMouseClick", this.checkboxMouseClickBind);
		}
	};

    this.t_getFocus = function() {
		this.status = this.Status.FOCUS;
		
		this.TextInstance.textColor = this.stateTextColor[this.status];
		this.IconBGInstance.src = this.stateIconBGURL[this.status];
		this.IconInstance.src = this.stateIconURL[this.status];
		this.CursorInstance.show();		
    };

    this.t_loseFocus = function() {		
		this.status = this.Status.NORMAL;

		this.TextInstance.textColor = this.stateTextColor[this.status];
		this.IconBGInstance.src = this.stateIconBGURL[this.status];
		this.IconInstance.src = this.stateIconURL[this.status];
		this.CursorInstance.hide();
    };
	
	this.t_getDim = function() {		
		this.status = this.Status.DIM;

		this.TextInstance.textColor = this.stateTextColor[this.status];
		this.IconBGInstance.src = this.stateIconBGURL[this.status];
		this.IconInstance.src = this.stateIconURL[this.status];
		this.CursorInstance.hide();
	};
	
	this.t_loseDim = function() {
		if(this.isFocused){
			this.status = this.Status.FOCUS;
			this.CursorInstance.show();
		}
		else{
			this.status = this.Status.NORMAL;
		}
		
		this.TextInstance.textColor = this.stateTextColor[this.status];
		this.IconBGInstance.src = this.stateIconBGURL[this.status];
		this.IconInstance.src = this.stateIconURL[this.status];
	};
	
	this.t_selected = function(){
		this.status = this.Status.SELECTED;

		this.TextInstance.textColor = this.stateTextColor[this.status];
		this.IconBGInstance.src = this.stateIconBGURL[this.status];
		this.IconInstance.src = this.stateIconURL[this.status];
	};

    this.t_show = function() {
    };

    this.t_hide = function() {
    };

    this.t_keyHandler = function(keycode, keytype){
		if (keytype == Volt.EVENT_KEY_RELEASE) 
		{
			return false;
		}
		
        var ret = false;
        switch(keycode) {
            case Volt.KEY_JOYSTICK_OK:
                if (this.checkStatus == this.CheckStatus.CHECKED){											
                    this.setCheckBoxCheckStatus(this.CheckStatus.UNCHECKED);							
                }
                else{							
                    this.setCheckBoxCheckStatus(this.CheckStatus.CHECKED);
                }	
                ret = true;
                break;
            default:
                // to do
                break;
		}	
        return ret;
    };
       
    this.setText = function(text) {
        if(this.isCreated == false){
			return false;
	    }
		
		if(("string" == typeof text) && (0 != text.length)) {
			this.TextInstance.text = text;
			return true;
		}
    
        return false;
    };
    
	this.setTextHorizontalAlignment= function(horizontalAlignment){
		if(this.isCreated == false){
			return false;
	    }
		
		if ("string" == typeof horizontalAlignment){
			this.TextInstance.horizontalAlignment = horizontalAlignment;
			return true;
		}
		
		return false;
	};
	
	this.setTextVerticalAlignment= function(verticalAlignment){
		if(this.isCreated == false){
			return false;
	    }
		
		if ("string" == typeof verticalAlignment){
			this.TextInstance.verticalAlignment = verticalAlignment;
			return true;
		}
		
		return false;
	};
    
    this.setTextFont = function(font) {
		if(this.isCreated == false){
			return false;
		}
	
		if(("string" == font) && (0 != font.length)) {
			this.TextInstance.font = font;
			return true;
		}
         
        return false;
    };
    
	this.setSpace = function(spacewidth) {
        if(this.isCreated == false){
			return false;
	    }
		
	   this.TextInstance.x = this.IconBGInstance.x + this.IconBGInstance.width + spacewidth;
	   return true; 
	};
	
    this.setTextColor = function(state, color) {
        if(this.isCreated == false){
			return false;
		}
		
		if ("object" == typeof color){
			if ((0 <= state) && (this.Status.MAX_STATUS > state)) {
				this.stateTextColor[state] = color;
				return true;
			}
		}
			
        return false;
    };
	
    this.setIconBG = function(state, imgSrc) {
        if(this.isCreated == false){
			return false;
		}
		
		if ("string" == typeof imgSrc){		
			if ((0 <= state) && (this.Status.MAX_STATUS > state)){            
				//this.IconBGInstance.src = imgSrc;
				this.stateIconBGURL[state] = imgSrc;
				return true;
			}  
		}  
        return false;
    };
	
	this.setSelectedIcon = function(state, imgSrc) {
        if(this.isCreated == false){
			return false;
		}
		
        if (("string" == typeof imgSrc) && (0 != imgSrc.length)) {
			this.stateIconURL[state].src = imgSrc;
			return true;
        }
    
        return false;
    };
    
   this.setIconSize = function(width, height) {      
	  if(this.isCreated == false){
			return false;
	  }
	  
	  this.IconInstance.width = width;
	  this.IconInstance.height = height;
	  this.IconBGInstance.width = width;
	  this.IconBGInstance.height = height;
	  //this.IconBGInstance.y = (this.checkBoxBGWidget.height-height)/2;   
	  return true;	  
   };
    
    this.setCheckBoxStatus = function(status){ 
        if(this.isCreated == false){
			return false;
		}
		
		if((status < 0) || (status > this.Status.MAX_STATUS)){
            return false;
        }
        
        if (status == this.Status.DIM){
			this.t_getDim();
        }
        else if (status == this.Status.NORMAL){
			this.t_loseFocus();
        }
        else if(status == this.Status.FOCUS){
			this.t_getFocus();
        }
        else if(status == this.Status.SELECTED){
			this.t_selected();
        }
		else{
		
		}
        
        return true;		      
    };
    
    this.setCheckBoxCheckStatus = function(checkStatus) {		
        if(this.isCreated == false){
			return false;
	    }
		
		if (this.status != this.Status.DIM){
            if(this.checkStatus != checkStatus) {
                this.checkStatus = checkStatus;
        
                if(this.checkStatus == this.CheckStatus.UNCHECKED) {
                    this.IconInstance.hide();                    
                }
                else if(this.checkStatus == this.CheckStatus.CHECKED) {			
                    this.IconInstance.show();				
                }
                else{
                    
                }
                return true;
            }
        }
    
        return false;
    }; 
	
	this.getCheckBoxCheckStatus = function(){
		if (this.isCreated){
			return this.checkStatus;
		}
		
		return null;	
	};
};

CheckBox.prototype = new ControlBase();
exports = CheckBox;
