/** 
 * @author  Lei Wang (l0506.wang@samsung.com)
 * @fileoverview Definition of LockUnlockPinPopup
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
const ControlBase = require("UIElement/ControlBase");
const Button_Generic = require("UIElement/Button_Generic");
const InputBox = require("UIElement/InputBox");
var setTimeout=function(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
};

var clearTimeout=function (id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
};
/**
 * Class LockUnlockPinPopup.
class
 * @constructor
 * @extends UIElement/ControlBase UIElement/Button_Generic UIElement/InputBox
 */
 
LockUnlockPinPopup = function() {
	//variable
	var sceWidth = scene.width;
	var sceHeight = scene.height;
	this.PopupBGWidget = null;
	this.focusIndex=0;
	this.pinCount=4;
	this.buttonCount = 0;
	this.buttonList = [];
	this.pinBoxList=[];
	this.bgWidth=sceWidth;
	this.bgColor={r:10,g:93,b:136,a:255};//0a5d88
	this.bgOpacity=0.85*255;
	this.pinMessage="";
	this.pinTitle="";
	this.inputDoneCallback=null;
	
	this.messageWidth=0;
	this.messageFont="Samsung SVD_Light 34px";
	this.messageHeight=0;
	this.messageOpacity=0.9*255;
	this.messageTextColor={r:255,g:255,b:255,a:255*0.9};//ffffffff
	this.messageBgColor={r:69,g:187,b:163,a:255};//45bba3
	this.messagePositionX=0;
	this.messagePositionY=50;
	this.messageVerticalAlignment="center";
	this.messageHorizontalAlignment="center";
	this.messageInstance = null;
	this.pinTitleInstance = null;
	this.focus=false;
	this.isCreate=false;
	this.pinTitleFont="Samsung SVD_Light 46px";
	this.pinTitleTextColor={r:255,g:255,b:255,a:255};//ffffffff
	this.pinTitleHeight=0;
	this.pinTitlePositionX=0;
	this.pinTitlePositionY=0;
	this.pinTitleVerticalAlignment="center";
	this.pinTitleHorizontalAlignment="center";
	
	this.buttonPositionX=0;
	this.pinBoxPositionX=0;
	this.pinBoxGap=0;
	this.pinTextHeight=0;
	this.pinBoxWidth=0;
	this.pinBoxHeight=0;
	this.pinBoxPositionY=0;
	this.inputMaxLength=1;
	this.pinDotGap=0;
	this.pinBoxText=[];
	this.pinBoxTextFont="Samsung SVD_Light 30px";
	this.pinBoxTextVerticalAlignment="center";
	this.pinBoxTextHorizontalAlignment="center";
	this.pinBoxStyle=InputBox.Style.PIN;
	this.pinBoxBgSrc={};
	this.pinImgSrc={};
	this.pinBoxTextTextColor={};
	this.pinImgWidth={};
	this.pinImgHeight={};
	this.buttonCallbackList=[];
	this.mouseOverCallBack=null;
	this.mouseOutCallBack=null;
	this.buttonWidth = 270;
	this.buttonHeight = 66;
	this.returnKeyCallback=null;
	this.timer=null;
	this.timeOutCallBack=null;
	this.timeOutTime=10000;
	
	this.buttonPositionY=0;
	this.openOverout=false;
	this.openClick=false;
	this.openUpdown=false;
	this.isReverse=false;
	
	this.m_hasTitle = false;
	this.m_hasMessage = false;
	this.m_hasButton = false;
	this.m_hasPin = false;
	/**
	* This function will create a LockUnlockPinPopup<p>
	* This function will create a LockUnlockPinPopup,You can use this function when you want to create an LockUnlockPinPopup Object.
	* @param {Object} param of the new LockUnlockPinPopup you want to create.
	* @return {Object} return the new LockUnlockPinPopup object you want to create.
	* @example //This example create a new LockUnlockPinPopup.
	* const script_AID = "UIElement/LockUnlockPinPopup";
	* const LockUnlockPinPopup = require(script_AID);
	* PopupIns = new LockUnlockPinPopup(); 
	* PopupIns.create({x:500, y:200, height:300, width:500,parent:scene});
	* @since The version 1.0 this function is added.
	*/
	this.t_create = function(obj) {
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("width")){
			this.bgWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.bgHeight=obj.height;
		}
		if(obj.hasOwnProperty("color")){
			this.bgColor=obj.color;
		}
		
		if(obj.hasOwnProperty("opacity")){
			this.bgOpacity=obj.opacity;
		}
		this.PopupBGWidget = new ImageWidget({
			width : this.bgWidth,
			height : this.bgHeight,
			color : {r:10,g:93,b:136,a:0},
			parent : obj.parent
		});
		if(obj.hasOwnProperty("bgSrc")){
			if ("string"== typeof(obj.bgSrc)){
				this.PopupBGWidget.src=obj.bgSrc;
			}
		}
		if(obj.hasOwnProperty("isReverse")){
			this.isReverse=obj.isReverse;
		}
		else{
			this.PopupBGWidget.color=this.bgColor;
		}
		this.PopupBGWidget.opacity=this.bgOpacity;
		this.PopupBGWidget.hide();
		this.initx=this.rootWidget.getAbsolutePosition().x;
		this.inity=this.rootWidget.getAbsolutePosition().y;
		this.isCreate=true;
	};
	
	this.t_destroy = function() {
		this.focusIndex = 0;
		if(this.timer!=null){
			clearTimeout(this.timer);
		}
		delete this.t_buttonClickCallbackBind;
		delete this.m_buttonMouseOverCallBackBind;			
		delete this.m_buttonMouseOutCallBackBind;
		delete this.t_LockUnlockPinPopupMouseOverBind;
		delete this.t_LockUnlockPinPopupMouseOutBind;	
		delete this.t_inputDoneCallbackBind;
		if(this.pinBoxList != null){
			var num=this.pinBoxList.length;
			if(num!=0){
				for(var i=num-1;i>=0;i--){
					this.pinBoxList[i].destroy();
				}
				this.pinBoxList.splice(0, this.pinBoxList.length);
				this.pinBoxList = null;
			}
        }
		if(this.buttonList != null){		
			var num1=this.buttonList.length;
			if(num1!=0){
				for(var i=num1-1;i>=0;i--){
					this.buttonList[i].destroy();
				}
				this.buttonList.splice(0, this.buttonList.length);
				this.buttonList = null;
			}	
        }
		if(this.pinBoxText != null){		
			this.pinBoxText.splice(0, this.pinBoxText.length);
			this.pinBoxText = null;
		}
		if(this.buttonCallbackList != null){
			this.buttonCallbackList.splice(0, this.buttonCallbackList.length);
			this.buttonCallbackList = null;
		}
		if(this.pinTitleInstance != null){
			this.pinTitleInstance.destroy();
			this.pinTitleInstance = null;
			this.lineInstance.destroy();
			this.lineInstance = null;
		}
		if(this.messageInstance != null){
			this.messageInstance.destroy();
			this.messageInstance = null;
		}
		if(this.PopupBGWidget != null){
			this.PopupBGWidget.destroy();
			this.PopupBGWidget = null;
		}
	};
	
	this.t_show = function() {
		this.PopupBGWidget.show();
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	this.t_hide = function() {
		this.PopupBGWidget.hide();
	};
	this.reset=false;
	this.t_keyHandler = function(keycode, keytype) {
		if(this.isCreated == false) {
			return false;
		}
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}	
		var	count=this.pinCount+this.buttonCount;
		var bRet = false;
		switch(keycode) {
			case Volt.KEY_JOYSTICK_RIGHT:
				if(true == this.isReverse){
					if(this.focusIndex > 0&&this.focusIndex < this.pinCount) {
						this.pinBoxList[this.focusIndex].loseFocus();
						this.focusIndex--;
						this.pinBoxList[this.focusIndex].getFocus();
						this.reset=true;
						bRet = true;
					}
					else if((this.focusIndex > this.pinCount) && (this.focusIndex < this.pinCount+this.buttonCount)) {
						this.buttonList[this.focusIndex - this.pinCount].loseFocus();
						this.focusIndex--;
						this.buttonList[this.focusIndex - this.pinCount].getFocus();
						bRet = true;
					}
					else{
					}
				}
				else{
					if(this.focusIndex >= 0&&this.focusIndex < this.pinCount-1) {
						this.pinBoxList[this.focusIndex].loseFocus();
						this.focusIndex++;
						this.pinBoxList[this.focusIndex].getFocus();
						this.reset=true;
						bRet = true;
					}
					else if((this.focusIndex >= this.pinCount) && (this.focusIndex < this.pinCount+this.buttonCount-1)) {
						this.buttonList[this.focusIndex - this.pinCount].loseFocus();
						this.focusIndex++;
						this.buttonList[this.focusIndex - this.pinCount].getFocus();
						bRet = true;
					}
					else{
					}
				}
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				if(true == this.isReverse){
					if(this.focusIndex >= 0&&this.focusIndex < this.pinCount-1) {
						this.pinBoxList[this.focusIndex].loseFocus();
						this.focusIndex++;
						this.pinBoxList[this.focusIndex].getFocus();
						this.reset=true;
						bRet = true;
					}
					else if((this.focusIndex >= this.pinCount) && (this.focusIndex < this.pinCount+this.buttonCount-1)) {
						this.buttonList[this.focusIndex - this.pinCount].loseFocus();
						this.focusIndex++;
						this.buttonList[this.focusIndex - this.pinCount].getFocus();
						bRet = true;
					}
					else{
					}
				}
				else{
					if(this.focusIndex > 0&&this.focusIndex < this.pinCount) {
						this.pinBoxList[this.focusIndex].loseFocus();
						this.focusIndex--;
						this.pinBoxList[this.focusIndex].getFocus();
						this.reset=true;
						bRet = true;
					}
					else if((this.focusIndex > this.pinCount) && (this.focusIndex < this.pinCount+this.buttonCount)) {
						this.buttonList[this.focusIndex - this.pinCount].loseFocus();
						this.focusIndex--;
						this.buttonList[this.focusIndex - this.pinCount].getFocus();
						bRet = true;
					}
					else{
					}
				}
				break;
			case Volt.KEY_JOYSTICK_OK:
				if((this.focusIndex >= this.pinCount) && (this.focusIndex < this.pinCount+this.buttonCount)) {
					this.buttonList[this.focusIndex - this.pinCount].keyHandler(keycode,keytype);
					bRet = true;
				}				
				break;
			case Volt.KEY_RETURN:
				if(this.returnKeyCallback!=null){
					this.returnKeyCallback();
				}
				bRet = true;			
			break;
			case Volt.KEY_JOYSTICK_UP:
				if((this.focusIndex >= this.pinCount) && (this.focusIndex < this.pinCount+this.buttonCount)) {
					this.buttonList[this.focusIndex - this.pinCount].loseFocus();
					this.focusIndex=0;
					this.pinBoxList[this.focusIndex].getFocus();
					this.reset=true;
					bRet = true;
				}
				else{
				
				}
			break;
			case Volt.KEY_JOYSTICK_DOWN:
				if(this.focusIndex >= 0 && this.focusIndex < this.pinCount) {
					this.pinBoxList[this.focusIndex].loseFocus();
					this.focusIndex = this.pinCount;
					this.buttonList[this.focusIndex-this.pinCount].getFocus();
					this.reset=false;
					bRet = true;
				}
				else{
				}
			break;
			case Volt.KEY_0:
			case Volt.KEY_1:
			case Volt.KEY_2:
			case Volt.KEY_3:
			case Volt.KEY_4:
			case Volt.KEY_5:
			case Volt.KEY_6:
			case Volt.KEY_7:
			case Volt.KEY_8:
			case Volt.KEY_9:
				if(this.focusIndex >= 0 && this.focusIndex < this.pinCount) {
					if(this.reset==true){
						this.pinBoxList[this.focusIndex].clearOutInputBox();
						this.reset=false;
					}
					bRet = this.pinBoxList[this.focusIndex].keyHandler(keycode,keytype);
				}
			break;	
			default:
				break;
		}
		if(bRet == true){
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
		return bRet;
	};
	
	 /**
	* This function will set return key callback function of LockUnlockPinPopup created<p>
	* This function will set return key callback function of LockUnlockPinPopup created,You can use this function when you want to set return key callback.
	* @param {Function} callback function called when press return key.
	* @return {Void}
	* @example //This example set return key callback.
	* var okcallback=function(){
		  textwidget.text="ok";
	  };
	* PopupIns.setReturnKeyCallBack(okcallback);
	* @since The version 1.0 this function is added.
	*/
	this.setReturnKeyCallBack=function(callback){
		if(true == this.isCreate){
			this.returnKeyCallback=callback;
		}
	};
	
	 /**
	* This function will set time out property of LockUnlockPinPopup created<p>
	* This function will set time out property of LockUnlockPinPopup created,You can use this function when you want to use time out.
	* @param {Object} param of time out you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set time out property.
	* var outcallback=function(){
		PopupIns.hide();
	  };
	* PopupIns.startTimeOut({callback:outcallback});
	* @since The version 1.0 this function is added.
	*/
	this.startTimeOut=function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("time")){
			this.timeOutTime=obj.time;
		}
		if(obj.hasOwnProperty("callback")){
			this.timeOutCallBack=obj.callback;
		}
		if(this.timeOutCallBack!=null){
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	
	this.setReverse=function(isReverse){
		if(isReverse == null||typeof(isReverse) != "boolean"){
			return false;
		}
		if(true == isReverse  && false == this.isReverse){
			if(true == this.m_hasTitle){
				this.pinTitleInstance.x = this.bgWidth-this.pinTitlePositionX-this.pinTitleWidth;
				this.lineInstance.x=this.pinTitleInstance.x;
			}
			if(true == this.m_hasMessage){
				this.messageInstance.x = this.bgWidth-this.messagePositionX-this.messageWidth;
			}
			if(true == this.m_hasButton){
				for(var index = 0; index < this.buttonCount; index++){
					this.buttonList[index].x = this.bgWidth-this.buttonPositionX-this.buttonWidth;
				}
			}
			if(true == this.m_hasPin){
				for(var index = 0; index < this.pinCount; index++){
					this.pinBoxList[index].x = this.bgWidth-this.pinBoxPositionX-index*(this.pinBoxWidth+this.pinBoxGap)-this.pinBoxWidth;
					this.pinBoxList[index].setReverse(isReverse);
				}
			}
		}
		else if(false == isReverse  && true == this.isReverse){
			if(true == this.m_hasTitle){
				this.pinTitleInstance.x=this.pinTitlePositionX;
				this.lineInstance.x=this.pinTitleInstance.x;
			}
			if(true == this.m_hasMessage){
				this.messageInstance.x=this.messagePositionX;
			}
			if(true == this.m_hasButton){
				for(var index = 0; index < this.buttonCount; index++){
					this.buttonList[index].x = this.buttonPositionX;
				}
			}
			if(true == this.m_hasPin){
				for(var index = 0; index < this.pinCount; index++){
					this.pinBoxList[index].x = this.pinBoxPositionX+index*(this.pinBoxWidth+this.pinBoxGap);
					this.pinBoxList[index].setReverse(isReverse);
				}
			}
		}
		else{
		
		}
		this.isReverse = isReverse;
	};
	 /**
	* This function will set title property of LockUnlockPinPopup created<p>
	* This function will set title property of LockUnlockPinPopup created,You can use this function when you want to set title.
	* @param {Object} param of title property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set title property.
	* PopupIns.setTitle({x:0, 
						y:0,
						 width:500, 
						 height:50, 
						 textColor:color1, 
						 font:"35px", 
						 verticalAlignment:"center", 
						 horizontalAlignment:"left", 
						 titleOpacity:255, 
						 title:"Unlock/Lock"});	
	* @since The version 1.0 this function is added.
	*/
	this.setTitle=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.pinTitlePositionX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.pinTitlePositionY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.pinTitleWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.pinTitleHeight=obj.height;
		}
		if(obj.hasOwnProperty("textColor")){
			this.pinTitleTextColor=obj.textColor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.pinTitleFont=obj.font;
			}	
		}
		if(obj.hasOwnProperty("verticalAlignment")){
			this.pinTitleVerticalAlignment=obj.verticalAlignment;
		}
		if(obj.hasOwnProperty("horizontalAlignment")){
			this.pinTitleHorizontalAlignment=obj.horizontalAlignment;
		}
		if(obj.hasOwnProperty("title")){
			if ("string" == typeof(obj.title)){
				this.pinTitle=obj.title;
			}
		}
		if(this.pinTitleInstance==null){		
			this.pinTitleInstance = new TextWidget({
				parent : this.PopupBGWidget
			});
			this.lineInstance = new Widget({
				height : 1,
				parent : this.PopupBGWidget
			});
		}
		this.pinTitleInstance.x=this.pinTitlePositionX;
		this.pinTitleInstance.y=this.pinTitlePositionY;
		this.pinTitleInstance.width=this.pinTitleWidth;
		this.pinTitleInstance.height=this.pinTitleHeight;
		this.pinTitleInstance.font=this.pinTitleFont;
		this.pinTitleInstance.horizontalAlignment=this.pinTitleHorizontalAlignment;
		this.pinTitleInstance.verticalAlignment=this.pinTitleVerticalAlignment;
		this.pinTitleInstance.text=this.pinTitle;
		this.pinTitleInstance.textColor=this.pinTitleTextColor;
		this.lineInstance.x=this.pinTitlePositionX;
		this.lineInstance.y=this.pinTitlePositionY+this.pinTitleHeight;
		this.lineInstance.width=this.pinTitleWidth;
		this.lineInstance.color=this.pinTitleTextColor;
		if(obj.hasOwnProperty("titleOpacity")){
			this.pinTitleInstance.opacity=obj.titleOpacity;
		}
		if(obj.hasOwnProperty("bgColor")){
			this.pinTitleInstance.color=obj.bgColor;
		}
		if(true == this.isReverse){
			//this.pinTitleInstance.rotation.y=180;
			this.pinTitleInstance.x = this.bgWidth-this.pinTitlePositionX-this.pinTitleWidth;
			this.lineInstance.x=this.pinTitleInstance.x;
		}
		this.lineInstance.opacity = 255;
		this.m_hasTitle = true;
		return true;
	};
	
	 /**
	* This function will set message property of LockUnlockPinPopup created<p>
	* This function will set message property of LockUnlockPinPopup created,You can use this function when you want to set message.
	* @param {Object} param of message property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set message property.
	* PopupIns.setMessage({x:0, 
						   y:60,
						   width:500,
						   height:60, 
						   textColor:color1, 
						   font:"25px", 
						   verticalAlignment:"center", 
						   horizontalAlignment:"left", 
						   bgColor:color2, 
						   opacity:220, 
						   message:"Input Your Pin.(0000)"});
	* @since The version 1.0 this function is added.
	*/
	this.setMessage=function(obj) {
		if(false == this.isCreate){
			return false;
		}
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("x")){
			this.messagePositionX=obj.x;
		}
		if(obj.hasOwnProperty("y")){
			this.messagePositionY=obj.y;
		}
		if(obj.hasOwnProperty("width")){
			this.messageWidth=obj.width;
		}
		if(obj.hasOwnProperty("height")){
			this.messageHeight=obj.height;
		}
		if(obj.hasOwnProperty("textColor")){
			this.messageTextColor=obj.textColor;
		}
		if(obj.hasOwnProperty("font")){
			if ("string"== typeof(obj.font)){
				this.messageFont=obj.font;
			}
		}
		if(obj.hasOwnProperty("verticalAlignment")){
			this.messageVerticalAlignment=obj.verticalAlignment;
		}
		if(obj.hasOwnProperty("horizontalAlignment")){
			this.messageHorizontalAlignment=obj.horizontalAlignment;
		}
		if(obj.hasOwnProperty("bgColor")){
			this.messageBgColor=obj.bgColor;
		}
		if(obj.hasOwnProperty("opacity")){
			this.messageOpacity=obj.opacity;
		}
		if(obj.hasOwnProperty("message")){
			if ("string"== typeof(obj.message)){
				this.pinMessage=obj.message;
			}
		}
		if(this.messageInstance==null){
			this.messageInstance = new TextWidget({
				parent : this.PopupBGWidget
			});
		}
		this.messageInstance.x=this.messagePositionX;
		this.messageInstance.y=this.messagePositionY;
		this.messageInstance.width=this.messageWidth;
		this.messageInstance.height=this.messageHeight;
		this.messageInstance.font=this.messageFont;
		this.messageInstance.horizontalAlignment=this.messageHorizontalAlignment;
		this.messageInstance.verticalAlignment=this.messageVerticalAlignment;
		this.messageInstance.text=this.pinMessage;
		this.messageInstance.textColor=this.messageTextColor;
		this.messageInstance.opacity=this.messageOpacity;
		if(true == this.isReverse){
			//this.messageInstance.rotation.y=180;
			this.messageInstance.x = this.bgWidth-this.messagePositionX-this.messageWidth;
		}	
		this.m_hasMessage = true;		
		return true;
	};
	
	 /**
	* This function will set button property of LockUnlockPinPopup created<p>
	* This function will set button property of LockUnlockPinPopup created,You can use this function when you want to set button.
	* @param {Object} param of button property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set button property.
	* var buttonProperty =[{x:200, 
							y:230, 
							width:100,
							height:40,
							buttonText:{normal:"Ok"},
							callbackFunction:okcallback}
						   ];				 
	* PopupIns.setButton(buttonProperty);
	* @since The version 1.0 this function is added.
	*/
	this.setButton = function(buttonPropertyobj) {
		if(false == this.isCreate){
			return false;
		}
		if(buttonPropertyobj==null||typeof(buttonPropertyobj) == "undefined"){
			return false;
		}
		var buttonCount=buttonPropertyobj.length;
		if(buttonCount > 0) {
			var firstset=true;
			this.buttonCount = buttonCount;
			var num=this.buttonList.length;
			if(num!=0){
				for(var i=num-1;i>=0;i--){
					this.buttonList[i].destroy();
				}
				this.buttonList.splice(0, this.buttonList.length);
			}
			for(var index = 0; index < buttonCount; index++) {
				var tempButton = new Button_Generic();
				this.buttonList.push(tempButton);
				if(buttonPropertyobj[index].hasOwnProperty("x")){
					this.buttonPositionX=buttonPropertyobj[index].x;
				}
				if(buttonPropertyobj[index].hasOwnProperty("y")){
					this.buttonPositionY=buttonPropertyobj[index].y;
				}
				if(buttonPropertyobj[index].hasOwnProperty("width")){
					this.buttonWidth=buttonPropertyobj[index].width;
				}
				if(buttonPropertyobj[index].hasOwnProperty("height")){
					this.buttonHeight=buttonPropertyobj[index].height;
				}
				if(true == this.isReverse){
					this.buttonList[index].create({
						x : this.bgWidth-this.buttonPositionX-this.buttonWidth,
						y : this.buttonPositionY,
						width : this.buttonWidth,
						height : this.buttonHeight,
						parent:this.PopupBGWidget
					});
				}
				else{
					this.buttonList[index].create({
						x : this.buttonPositionX,
						y : this.buttonPositionY,
						width : this.buttonWidth,
						height : this.buttonHeight,
						parent:this.PopupBGWidget
					});
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonBorder")){
					if(buttonPropertyobj[index].buttonBorder.hasOwnProperty("normal")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonBorder.normal);
					}
					if(buttonPropertyobj[index].buttonBorder.hasOwnProperty("focus")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonBorder.focus);
					}
					if(buttonPropertyobj[index].buttonBorder.hasOwnProperty("selected")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonBorder.selected);
					}
					if(buttonPropertyobj[index].buttonBorder.hasOwnProperty("dim")){
						this.buttonList[index].setBorder(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonBorder.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonTextColor")){
					if(buttonPropertyobj[index].buttonTextColor.hasOwnProperty("normal")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonTextColor.normal);
					}
					if(buttonPropertyobj[index].buttonTextColor.hasOwnProperty("focus")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonTextColor.focus);
					}
					if(buttonPropertyobj[index].buttonTextColor.hasOwnProperty("selected")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonTextColor.selected);
					}
					if(buttonPropertyobj[index].buttonTextColor.hasOwnProperty("dim")){
						this.buttonList[index].setTextColor(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonTextColor.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonTextFont")){
					if(buttonPropertyobj[index].buttonTextFont.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttonTextFont.normal)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonTextFont.normal);
						}
					}
					if(buttonPropertyobj[index].buttonTextFont.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttonTextFont.focus)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonTextFont.focus);
						}
					}
					if(buttonPropertyobj[index].buttonTextFont.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttonTextFont.selected)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonTextFont.selected);
						}
					}
					if(buttonPropertyobj[index].buttonTextFont.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttonTextFont.dim)){
							this.buttonList[index].setTextFont(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonTextFont.dim);
						}
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonTextVerticalAlignment")){
					this.buttonList[index].setTextVerticalAlignment(buttonPropertyobj[index].buttonTextVerticalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonTextHorizontalAlignment")){
					this.buttonList[index].setTextHorizontalAlignment(buttonPropertyobj[index].buttonTextHorizontalAlignment);
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonText")){
					if(buttonPropertyobj[index].buttonText.hasOwnProperty("normal")){
						if ("string" == typeof(buttonPropertyobj[index].buttonText.normal)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonText.normal);
						}
					}
					if(buttonPropertyobj[index].buttonText.hasOwnProperty("focus")){
						if ("string" == typeof(buttonPropertyobj[index].buttonText.focus)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonText.focus);
						}
					}
					if(buttonPropertyobj[index].buttonText.hasOwnProperty("selected")){
						if ("string" == typeof(buttonPropertyobj[index].buttonText.selected)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonText.selected);
						}
					}
					if(buttonPropertyobj[index].buttonText.hasOwnProperty("dim")){
						if ("string" == typeof(buttonPropertyobj[index].buttonText.dim)){
							this.buttonList[index].setText(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonText.dim);
						}
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("buttonImage")){
					if(buttonPropertyobj[index].buttonImage.hasOwnProperty("normal")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_UNFOCUSED, buttonPropertyobj[index].buttonImage.normal);
					}
					if(buttonPropertyobj[index].buttonImage.hasOwnProperty("focus")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_FOCUSED, buttonPropertyobj[index].buttonImage.focus);
					}
					if(buttonPropertyobj[index].buttonImage.hasOwnProperty("selected")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_PRESSED, buttonPropertyobj[index].buttonImage.selected);
					}
					if(buttonPropertyobj[index].buttonImage.hasOwnProperty("dim")){
						this.buttonList[index].setImage(this.buttonList[index].buttonState.STATE_DISABLE, buttonPropertyobj[index].buttonImage.dim);
					}
				}
				if(buttonPropertyobj[index].hasOwnProperty("callbackFunction")){
					if(firstset == true){
						this.buttonCallbackList.splice(0, this.buttonCallbackList.length);
						firstset=false;
					}
					this.buttonCallbackList[index]=buttonPropertyobj[index].callbackFunction;
					this.buttonList[index].setMouseClickCallback(this.t_buttonClickCallbackBind);
				}
				this.buttonList[index].setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind,outCallback:this.m_buttonMouseOutCallBack});
				this.buttonList[index].show();			
			}
			if(this.focus==true){
				if(this.focusIndex<buttonCount)
				{
					this.buttonList[this.focusIndex].getFocus();
				}
				
			}
			this.m_hasButton = true;
		}
		
		return false;
	};
	
	 /**
	* This function will set input box property of LockUnlockPinPopup created<p>
	* This function will set input box property of LockUnlockPinPopup created,You can use this function when you want to set input box.
	* @param {Object} param of input box property you want to set.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This set input box property.
	* var pinobj={PINBoxX:20,
				  PINBoxY:130,
				  PINBoxWidth:100,
				  PINBoxHeight:70,
				  PINBoxGap:10,
				  bgSrc:{normal:"inputBox/input_box_n.png", focus:"inputBox/input_box_style_c_f.png"},
				  PINImgSrc:{normal:"inputBox/obe_pin_n.png", focus:"inputBox/obe_pin_f.png"},
				  PINImgX:50,
				  inputDoneCallback:donecallback
				  };					 
	* PopupIns.setPin(pinobj);
	* @since The version 1.0 this function is added.
	*/
	this.setPin=function(pinobj) {
		if(false == this.isCreate){
			return false;
		}
		if(pinobj == null||typeof(pinobj) == "undefined"){
			return false;
		}
		if(pinobj.hasOwnProperty("PINBoxX")){
			this.pinBoxPositionX=pinobj.PINBoxX;
		}
		if(pinobj.hasOwnProperty("PINBoxY")){
			this.pinBoxPositionY=pinobj.PINBoxY;
		}
		if(pinobj.hasOwnProperty("PINBoxWidth")){
			this.pinBoxWidth=pinobj.PINBoxWidth;
		}
		if(pinobj.hasOwnProperty("PINBoxHeight")){
			this.pinBoxHeight=pinobj.PINBoxHeight;
		}
		if(pinobj.hasOwnProperty("PINBoxGap")){
			this.pinBoxGap=pinobj.PINBoxGap;
		}
		if(pinobj.hasOwnProperty("PINBoxNum")){
			if(pinobj.PINBoxNum>0){
				this.pinCount=pinobj.PINBoxNum;
			}
		}
		if(pinobj.hasOwnProperty("textColor")){
			//var text = JSON.stringify(pinobj.textColor);   // deep copy
			this.pinBoxTextTextColor = pinobj.textColor;
		}
		if(pinobj.hasOwnProperty("font")){
			if ("string"== typeof(pinobj.font)){
				this.pinBoxTextFont=pinobj.font;
			}
		}
		if(pinobj.hasOwnProperty("verticalAlignment")){
			this.pinBoxTextVerticalAlignment=pinobj.verticalAlignment;
		}
		if(pinobj.hasOwnProperty("horizontalAlignment")){
			this.pinTextHorizontalAlignment=pinobj.horizontalAlignment;
		}
		if(pinobj.hasOwnProperty("bgSrc")){
			this.pinBoxBgSrc = pinobj.bgSrc;
		}
		if(pinobj.hasOwnProperty("PINImgSrc")){
			//var text = JSON.stringify(pinobj.PINImgSrc);   // deep copy
			this.pinImgSrc = pinobj.PINImgSrc;
		}
		if(pinobj.hasOwnProperty("style")){
			this.pinBoxStyle=pinobj.style;

		}
		if (pinobj.hasOwnProperty("inputMaxLength")){
			if(pinobj.inputMaxLength>0){
				this.inputMaxLength = pinobj.inputMaxLength;
			}
		}
		if (pinobj.hasOwnProperty("PINDotGap")) {
			this.pinDotGap = pinobj.PINDotGap;
		}	
		if (pinobj.hasOwnProperty("PINImgX")){
			this.pinImg_x = pinobj.PINImgX			
		}
		if (pinobj.hasOwnProperty("PINImgWidth")){
			this.pinImgWidth = pinobj.PINImgWidth;						
		}
				
		if (pinobj.hasOwnProperty("PINImgHeight")){
			this.pinImgHeight = pinobj.PINImgHeight;		
		}
		if (pinobj.hasOwnProperty("textX")){
			this.pinBoxTextX= pinobj.textX;			
		}
		if (pinobj.hasOwnProperty("textY")){
			this.pinBoxTextY = pinobj.textY;			
		}
		if (pinobj.hasOwnProperty("textWidth")){
			this.pinBoxTextWidth = pinobj.textWidth;			
		}
		if (pinobj.hasOwnProperty("textHeight")){
			this.pinBoxTextHeight = pinobj.textHeight;		
		}
		if(pinobj.hasOwnProperty("textList")){
			var num=pinobj.textList.length;
			for(var i=0;i<num;i++){
				if ("string"!= typeof(pinobj.textList[i]))
					break;
			}
			if ( i==num ){
				this.pinBoxText.splice(0, this.pinBoxText.length);
				this.pinBoxText=pinobj.textList;
			}
		}
		if (pinobj.hasOwnProperty("inputDoneCallback")){
			this.inputDoneCallback = pinobj.inputDoneCallback;
		}
		var num=this.pinBoxList.length;
		if(num!=0){
			for(var i=num-1;i>=0;i--){
				this.pinBoxList[i].destroy();
			}
			this.pinBoxList.splice(0, this.pinBoxList.length);
		}
		for(var index = 0; index < this.pinCount; index++){
			var tempPin = new InputBox();
			this.pinBoxList.push(tempPin);
			if(true == this.isReverse){
				this.pinBoxList[index].create({x:this.bgWidth-this.pinBoxPositionX-index*(this.pinBoxWidth+this.pinBoxGap)-this.pinBoxWidth,
										   y:this.pinBoxPositionY,
										   width:this.pinBoxWidth,
										   height:this.pinBoxHeight,
										   parent:this.PopupBGWidget,
										   bgSrc:this.pinBoxBgSrc,
										   text:this.pinBoxText[index],
										   textColor:this.pinBoxTextTextColor,
										   font:this.pinBoxTextFont,
										   horizontalAlignment:this.pinTextHorizontalAlignment,
										   verticalAlignment:this.pinBoxTextVerticalAlignment,
										   textX:this.pinBoxTextX,
										   textY:this.pinBoxTextY,
										   textWidth:this.pinBoxTextWidth,
										   textHeight:this.pinBoxTextHeight,
										   inputMaxLength:this.inputMaxLength,
										   PINDotGap:this.pinDotGap,
										   PINImgX:this.pinImg_x,
										   PINImgWidth:this.pinImgWidth,
										   PINImgHeight:this.pinImgHeight,
										   PINImgSrc:this.pinImgSrc,
										   Style:this.pinBoxStyle,
										   inputDoneCallback:this.t_inputDoneCallbackBind
										});
			
			}
			else{
				this.pinBoxList[index].create({x:this.pinBoxPositionX+index*(this.pinBoxWidth+this.pinBoxGap),
										   y:this.pinBoxPositionY,
										   width:this.pinBoxWidth,
										   height:this.pinBoxHeight,
										   parent:this.PopupBGWidget,
										   bgSrc:this.pinBoxBgSrc,
										   text:this.pinBoxText[index],
										   textColor:this.pinBoxTextTextColor,
										   font:this.pinBoxTextFont,
										   horizontalAlignment:this.pinTextHorizontalAlignment,
										   verticalAlignment:this.pinBoxTextVerticalAlignment,
										   textX:this.pinBoxTextX,
										   textY:this.pinBoxTextY,
										   textWidth:this.pinBoxTextWidth,
										   textHeight:this.pinBoxTextHeight,
										   inputMaxLength:this.inputMaxLength,
										   PINDotGap:this.pinDotGap,
										   PINImgX:this.pinImg_x,
										   PINImgWidth:this.pinImgWidth,
										   PINImgHeight:this.pinImgHeight,
										   PINImgSrc:this.pinImgSrc,
										   Style:this.pinBoxStyle,
										   inputDoneCallback:this.t_inputDoneCallbackBind
										});
			}
			this.pinBoxList[index].index=index;
			this.pinBoxList[index].setMouseOverOutCallback({overCallback:this.m_buttonMouseOverCallBackBind,outCallback:this.m_buttonMouseOutCallBack});
		}
		this.m_hasPin = true;
		return true;
	};

	this.t_buttonClickCallback=function(widget){
		var index=widget.index;
		if(typeof(this.buttonCallbackList[index-this.pinCount]) != "undefined"||this.buttonCallbackList[index-this.pinCount]!=null){
			this.buttonCallbackList[index-this.pinCount]();
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	};
	this.t_buttonClickCallbackBind=this.t_buttonClickCallback.bind(this);
	
	this.t_inputDoneCallback = function(widget){
		var index=widget.index;
		if(index >= 0 && index< this.pinCount-1){
			this.pinBoxList[this.focusIndex].loseFocus();
			this.focusIndex++;
			this.pinBoxList[this.focusIndex].getFocus();
			this.reset=true;
		}
		else if(index == this.pinCount-1){
			if(null != this.inputDoneCallback){
				this.inputDoneCallback();
			}
		}
		else{
		
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
	}
	this.t_inputDoneCallbackBind = this.t_inputDoneCallback.bind(this);
	
	 /**
	* This function will set input done callback function of LockUnlockPinPopup created<p>
	* This function will set input done callback function of LockUnlockPinPopup created,You can use this function when you want to set input done callback.
	* @param {Function} callback function called when input the last input box.
	* @return {Void}
	* @example //This set input done callback.
	* var donecallback1=function(){
		  PopupIns.setMessage({message:"ffffffffff"});
	  };
	* PopupIns.setInputDoneCallback(donecallback1);
	* @since The version 1.0 this function is added.
	*/
	this.setInputDoneCallback = function(callback){
		if (typeof callback == "function"){
			this.inputDoneCallback = callback;
		}
	};
	
	this.setPinText=function(index,textobj) {
		if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
			this.pinBoxList[index].setTextAttr(textobj);
		}
	};
	
	 /**
	* This function will get input string of every input box in LockUnlockPinPopup created<p>
	* This function will get input string of every input box in LockUnlockPinPopup created,You can use this function when you want to get input string of every input box.
	* @param {None}.
	* @return {String} return input string of every input box.
	* @example //This example get input string of every input box.
	* var txt=PopupIns.getInputPinString();
	* textwidget.text=txt;
	* @since The version 1.0 this function is added.
	*/
	this.getInputPinString = function(){
		var txt="";
		for(var index = 0; index < this.pinCount; index++){
			if(typeof(this.pinBoxList[index]) != "undefined" || this.pinBoxList[index] != null){
				txt+=this.pinBoxList[index].getInputString();
			}
		}
		return txt;
	};
	
	 /**
	* This function will clear every input box in LockUnlockPinPopup created<p>
	* This function will clear every input box in LockUnlockPinPopup created,You can use this function when you want to clear every input box.
	* @param {None}.
	* @return {Void}.
	* @example //This example clear every input box.
	* PopupIns.clearOutAllInputBox();
	* @since The version 1.0 this function is added.
	*/
	this.clearOutAllInputBox = function(){
		for(var index = 0; index < this.pinCount; index++){
			if(typeof(this.pinBoxList[index]) != "undefined" || this.pinBoxList[index] != null){
				this.pinBoxList[index].clearOutInputBox();
			}
		}
	};
	
	 /**
	* This function will clear one input box selected in LockUnlockPinPopup created<p>
	* This function will clear one input box selected in LockUnlockPinPopup created,You can use this function when you want to clear one input box selected.
	* @param {Number} the index of input box selected.
	* @return {Void}.
	* @example //This example clear one input box selected.
	* PopupIns.clearOutAllInputBox(0);
	* @since The version 1.0 this function is added.
	*/
	this.clearOutInputBox = function(index){
		if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
			this.pinBoxList[index].clearOutInputBox();
		}
	};
	
	this.m_buttonMouseOverCallBack = function(widget){
		var index=widget.index;
		if(this.focus == true && this.focusIndex != index){
			if(this.focusIndex>=0 && this.focusIndex < this.pinCount){
				this.pinBoxList[this.focusIndex].loseFocus();
			}
			else if((this.focusIndex >= this.pinCount) && this.focusIndex < (this.buttonCount+this.pinCount)){
				this.buttonList[this.focusIndex-this.pinCount].loseFocus();
			}
			else{
			
			}
			this.focusIndex=index;
			if(this.focusIndex>=0 && this.focusIndex < this.pinCount){
				this.pinBoxList[this.focusIndex].getFocus();
				this.reset=true;
				
			}
			else if((this.focusIndex>= this.pinCount) && this.focusIndex< (this.buttonCount+this.pinCount)){
				this.buttonList[this.focusIndex-this.pinCount].getFocus();
				this.reset=false;
			}
			if(this.timer!=null){
				clearTimeout(this.timer);
				var self=this;
				self.timer=setTimeout(function(){
					self.timeOutCallBack();
				},self.timeOutTime);
			}
		}
	};
	this.m_buttonMouseOverCallBackBind=this.m_buttonMouseOverCallBack.bind(this);
	
	this.m_buttonMouseOutCallBack = function(widget){

	};
	this.m_buttonMouseOverCallBackBind=this.m_buttonMouseOverCallBack.bind(this);
	
	this.t_LockUnlockPinPopupMouseOver = function(targetWidget, eventData) {
	//	this.getFocus();
		if(null!=this.mouseOverCallBack){
			this.mouseOverCallBack(this);
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_LockUnlockPinPopupMouseOverBind=this.t_LockUnlockPinPopupMouseOver.bind(this);

	this.t_LockUnlockPinPopupMouseOut = function(targetWidget, eventData) {
		var x=eventData.coordinates.x;
		var y=eventData.coordinates.y;
		var abx=x-this.initx;
		var aby=y-this.inity;
		if(abx<=this.bgWidth&&abx>=0&&aby<=this.bgHeight&&aby>=0){
			return false;
		}
		else{
			//this.loseFocus();
			if(null!=this.mouseOutCallBack){
				this.mouseOutCallBack(this);
			}
		}
		if(this.timer!=null){
			clearTimeout(this.timer);
			var self=this;
			self.timer=setTimeout(function(){
				self.timeOutCallBack();
			},self.timeOutTime);
		}
		return false;
	};
	this.t_LockUnlockPinPopupMouseOutBind=this.t_LockUnlockPinPopupMouseOut.bind(this);
	
	this.t_setMouseOverOutCallback = function(obj){
		if(obj == null||typeof(obj) == "undefined"){
			return false;
		}
		if(obj.hasOwnProperty("overCallback")){
			this.mouseOverCallBack=obj.overCallback;
		}
		if(obj.hasOwnProperty("outCallback")){
			this.mouseOutCallBack=obj.outCallback;
		}
	}
	
	this.t_MouseOverOut = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openOverout==false){
					this.PopupBGWidget.addEventListener("OnMouseOver",this.t_LockUnlockPinPopupMouseOverBind);										
					this.PopupBGWidget.addEventListener("OnMouseOut",this.t_LockUnlockPinPopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].index=index+this.pinCount;
							this.buttonList[index].enableMouseOverOut(true);
						}			
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							//this.pinBoxList[index].index=index;
							this.pinBoxList[index].enableMouseOverOut(true);
						}			
					}	
					this.openOverout=true;
				}
			}
			else{
				if(this.openOverout==true){
					this.PopupBGWidget.removeEventListener("OnMouseOver",this.t_LockUnlockPinPopupMouseOverBind);										
					this.PopupBGWidget.removeEventListener("OnMouseOut",this.t_LockUnlockPinPopupMouseOutBind);
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseOverOut(false);
						}			
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseOverOut(false);
						}			
					}
					this.openOverout=false;					
				}
			}
		}
	};
	
	this.t_MouseUpDown = function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openUpdown==false){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(true);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseUpDown(true);
						}		
					}
					this.openUpdown=true;
				}	
			}
			else{
				if(this.openUpdown==true){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseUpDown(false);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseUpDown(false);
						}		
					}
					this.openUpdown=false;
				}	
			}
		}
	};
	
	this.t_MouseClick= function(isOnFlag){
		if(this.isCreated == true){
			if(isOnFlag==true){
				if(this.openClick==false){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].index=index+this.pinCount;
							this.buttonList[index].enableMouseClick(true);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseClick(true);
						}		
					}
					this.openClick=true;
				}	
			}
			else{
				if(this.openClick==true){
					for(var index = 0; index < this.buttonCount; index++){
						if(this.buttonList[index] != null||typeof(this.buttonList[index]) != "undefined"){
							this.buttonList[index].enableMouseClick(false);
						}					
					}
					for(var index = 0; index < this.pinCount; index++){
						if(this.pinBoxList[index] != null||typeof(this.pinBoxList[index]) != "undefined"){
							this.pinBoxList[index].enableMouseClick(false);
						}		
					}
					this.openClick=false;
				}	
			}
		}
	};
	
	this.t_getFocus = function() {
		if(true == this.focus){
			return false;
		}
		else{
			if(this.focusIndex >= 0&&this.focusIndex < this.pinCount){
				this.pinBoxList[this.focusIndex].getFocus();				
			}
			if(this.focusIndex >= this.pinCount&&this.focusIndex < this.buttonCount+this.pinCount){
					this.buttonList[this.focusIndex-this.pinCount].getFocus();	
			}
			this.focus=true;
			return true;
		}
	    	
	};
	
	this.t_loseFocus = function() {
		if(false == this.focus){
			return false;
		}
		else{
			
			if(this.focusIndex >= 0&&this.focusIndex < this.pinCount){
				this.pinBoxList[this.focusIndex].loseFocus();
			}
			if(this.focusIndex >= this.pinCount&&this.focusIndex < this.buttonCount+this.pinCount){
					this.buttonList[this.focusIndex-this.pinCount].loseFocus();	
			}
			this.focus=false;
			return true;
		}
	};
	
	 /**
	* This function will set the focus position in LockUnlockPinPopup created,it will work after getFocus.<p>
	* This function will set the focus position in LockUnlockPinPopup created,You can use this function when you want to set the focus position.
	* @param {Number} the index of object you want to focus,in this LockUnlockPinPopup,the button index is input box number add button index.
	* @return {Boolean} return true if set succeed,else return false.
	* @example //This example set focus position.
	* PopupIns.setFocusIndex(0);
	* @since The version 1.0 this function is added.
	*/
	this.setFocusIndex = function(focusIdx) {	
		if(focusIdx >= 0 && focusIdx < this.buttonCount+this.pinCount) {
			this.focusIndex = focusIdx;
			return true;
		}
		return false;
	};
}

LockUnlockPinPopup.prototype = new ControlBase();
exports = LockUnlockPinPopup;
