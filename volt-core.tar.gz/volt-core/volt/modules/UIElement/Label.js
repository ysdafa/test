 /** 
 * @author  
 * @fileoverview Definition of Label
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var script_AID = "UIElement/ControlBase";
ControlBase = require(script_AID);

Label = function() {
	this.bgView = null;
	this.textView = null;
	
	this.isHighlighted = false;

	/**
	* This function creates a label object. 
	* @param {Object} param for this function.
	* @return void
	* @example //This example create a label object.
	*var labelView = new Label();
	*labelView.create({x: 200, y: 150,width:250,height:100,parent:BgView});
	* @since The version 1.0 this function is added.
	*/	
	this.t_create = function(obj) {
		this.bgView = new ImageWidget({
			width: obj.width,
			height: obj.height,
			parent: obj.parent,
		});

		this.textView = new TextWidget({
			width: obj.width,
			height: obj.height,
			parent: obj.parent,
			ellipsize : true,
		});

	};

	this.t_getFocus = function() {
	};

	this.t_loseFocus = function() {
	};

	this.t_show = function() {
		this.bgView.show();
		this.textView.show();
	};

	this.t_hide = function() {
		this.bgView.hide();
		this.textView.hide();
	};
	
	this.t_destroy = function() {
		if (this.bgView != null){
			this.bgView.destroy();
			this.bgView = null;
		}
		
		if (this.textView != null){
			this.textView.destroy();
			this.textView = null;
		}
		
	};
	
	this.t_keyHandler = function(KeyCode, keytype){
		if (keytype == Volt.EVENT_KEY_RELEASE) {
			return false;
		}	
		return false;
	}; 

	/**
	* This function sets the label text horizontal alignment property. 
	* @param {String} param for this function.
	* @return void
	* @example //This example sets the label text horizontal alignment property.
	*labelView.setHorizontalAlignment ("center");
	* @since The version 1.0 this function is added.
	*/
	this.setHorizontalAlignment = function(alignment) {
		if("string" != typeof(alignment)){
			return;
		}
		this.textView.horizontalAlignment = alignment;
	}
	
	/**
	* This function sets the label text vertical alignment property. 
	* @param {String} param for this function.
	* @return void
	* @example //This example sets the label text vertical alignment property.
	*labelView.setVerticalAlignment ("center");
	* @since The version 1.0 this function is added.
	*/
	this.setVerticalAlignment = function(alignment) {
		if("string" != typeof(alignment)){
			return;
		}
		
		this.textView.verticalAlignment = alignment;
	}
	
	/**
	* This function sets the label text color. 
	* @param {Object} param for this function.
	* @return void
	* @example //This example sets the label text color.
	*labelView.setTextColor({r:111, g:199, b: 0, a: 255});
	* @since The version 1.0 this function is added.
	*/
	this.setBackgroundColor = function(color) {
		if("object" != typeof(color)){
			return;
		}
		this.bgView.color = color;
	}
	
	this.setBackgroundImage = function(image) {
		if("string" != typeof(image)){
			return;
		}
		this.bgView.src = image;
	}
	
	this.setText = function(text) {
		if("string" != typeof(text)){
			return;
		}
		this.textView.text = text;
	}
	
	this.setFont = function(font) {
		if("string" != typeof(font)){
			return;
		}
		this.textView.font = font;
	}
	
	this.setTextColor = function(color) {
		if("object" != typeof(color)){
			return;
		}
		this.textView.textColor = color;
	}
	
	this.setHighlightedColor = function(highlightColor) {
		if("object" != typeof(highlightColor)){
			return;
		}
		if(this.isHighlighted == false) {
			return;
		}
		this.bgView.color = highlightColor;
	}
	
	/**
	* This function sets the label text single line or not. 
	* @param {Boolean} param for this function.
	* @return void
	* @example //This example sets the label text single line or not.
	*labelView.setTextColor({r:111, g:199, b: 0, a: 255});
	* @since The version 1.0 this function is added.
	*/
	this.setSinglelineMode = function(boolMode) {
		if("boolean" != typeof(boolMode)){
			return;
		}
		this.textView.singleLineMode = boolMode;
	}
}
Label.prototype = new ControlBase();
exports = Label;
