 /** 
 * @author  
 * @fileoverview Definition of CropImageWidgetEx
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

ControlBase = require("UIElement/ControlBase");

CropImageWidgetEx = function(){
	this.t_create = function(params) {
		this.cropOverflow = true;
		this.color = {r:0, g:0, b:0, a: 128};	

		this.imageSrc = params.src;
		this.cropMode = params.cropMode;
		this.imageWidth = params.width;
		this.imageHeight = params.height;
		
		this.hiddenImage = new ImageWidget({x: -99999, 
											y: -999999, 
											src: this.imageSrc, 
											parent: this.m_RootWidgetObject, 
											onReady:this.m_OnReadyLoadCBBind
											});		
		
	}
	
	this.m_OnReadyLoadCB = function(){
		this.onImageReady();
	}
	this.m_OnReadyLoadCBBind = this.m_OnReadyLoadCB.bind(this);
		
	this.t_destroy = function(){
		if(this.hiddenImage != null){		
			this.hiddenImage.destroy();
			this.hiddenImage = null;
		}		
	}

	this.t_getFocus = function(){
	}
	
	this.t_loseFocus = function(){	
	}
	
	this.t_show = function(){
	
	}
	
	this.t_hide = function(){
	
	}
	
	this.t_keyHandler = function(keycode, keytype){	
	
	}

	this.onImageReady = function() {
		this.imageWidth = parseInt(this.hiddenImage.width);
		this.imageHeight = parseInt(this.hiddenImage.height);
		this.updateCropMode();
	}

	this.updateCropMode = function() {
		switch (this.cropMode) {
		case "cropCenterMiddle":
			this.cropCenterMiddle();
			break;
		case "cropCenterTop":
			this.cropCenterTop();
			break;
		case "cropCenterBottom":
			this.cropCenterBottom();
			break;
		case "cropLeftMiddle":
			this.cropLeftMiddle();
			break;
		case "cropLeftTop":
			this.cropLeftTop();
			break;
		case "cropLeftBottom":
			this.cropLeftBottom();
			break;
		case "cropRightMiddle":
			this.cropRightMiddle();
			break;
		case "cropRightTop":
			this.cropRightTop();
			break;
		case "cropRightBottom":
			this.cropRightBottom();
			break;
		case "cropCenter":
			this.cropCenter();
			break;
		case "cropLeft":
			this.cropLeft();
			break;
		case "cropRight":
			this.cropRight();
			break;
		case "cropTop":
			this.cropTop();
			break;
		case "cropBottom":
			this.cropBottom();
			break;
		}
	}

	this.cropCenterMiddle = function() {
		var x = (this.width - this.imageWidth) / 2;
		var y = (this.height - this.imageHeight) / 2;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}

	this.cropCenterTop = function() {
		var x = (this.width - this.imageWidth) / 2;
		var y = 0;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}

	this.cropCenterBottom = function() {
		var x = (this.width - this.imageWidth) / 2;
		var y = this.height - this.imageHeight;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}

	this.cropLeftMiddle = function() {
		var x = 0;
		var y = (this.height - this.imageHeight) / 2;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}

	this.cropLeftTop = function() {
		var x = 0;
		var y = 0;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}
	this.cropLeftBottom = function() {
		var x = 0;
		var y = this.height - this.imageHeight;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}

	this.cropRightMiddle = function() {
		var x = this.width - this.imageWidth;
		var y = (this.height - this.imageHeight) / 2;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}

	this.cropRightTop = function() {
		var x = this.width - this.imageWidth;
		var y = 0;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}
	this.cropRightBottom = function() {
		var x = this.width - this.imageWidth;
		var y = this.height - this.imageHeight;

		this.hiddenImage.x = x;
		this.hiddenImage.y = y;
	}

	this.cropCenter = function() {
		var x = 0;
		var y = 0;
		
		if (this.imageWidth < this.imageHeight) {	
			var targetWidth = this.width;
			var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
		} else {
			var targetHeight = this.height;
			var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
		}
		
		this.hiddenImage.width = targetWidth;
		this.hiddenImage.height = targetHeight;
		this.hiddenImage.x = (this.width - targetWidth) / 2;
		this.hiddenImage.y = (this.height - targetHeight) / 2;
	}

	this.cropLeft = function() {
		var x = 0;
		var y = 0;
		
		if (this.imageWidth < this.imageHeight) {	
			var targetWidth = this.width;
			var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
		} else {
			var targetHeight = this.height;
			var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
		}
		
		this.hiddenImage.width = targetWidth;
		this.hiddenImage.height = targetHeight;
		this.hiddenImage.x = 0;
		this.hiddenImage.y = (this.height - targetHeight) / 2;
	}

	this.cropRight = function() {
		var x = 0;
		var y = 0;
		
		if (this.imageWidth < this.imageHeight) {	
			var targetWidth = this.width;
			var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
		} else {
			var targetHeight = this.height;
			var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
		}
		
		this.hiddenImage.width = targetWidth;
		this.hiddenImage.height = targetHeight;
		this.hiddenImage.x = this.width - targetWidth;
		this.hiddenImage.y = (this.height - targetHeight) / 2;
	}

	this.cropTop = function() {
		var x = 0;
		var y = 0;
		
		if (this.imageWidth < this.imageHeight) {	
			var targetWidth = this.width;
			var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
		} else {
			var targetHeight = this.height;
			var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
		}
		
		this.hiddenImage.width = targetWidth;
		this.hiddenImage.height = targetHeight;
		this.hiddenImage.x = (this.width - targetWidth) / 2;
		this.hiddenImage.y = 0;
	}

	this.cropBottom = function() {
		var x = 0;
		var y = 0;
		
		if (this.imageWidth < this.imageHeight) {	
			var targetWidth = this.width;
			var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
		} else {
			var targetHeight = this.height;
			var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
		}
		
		this.hiddenImage.width = targetWidth;
		this.hiddenImage.height = targetHeight;
		this.hiddenImage.x = (this.width - targetWidth) / 2;
		this.hiddenImage.y = this.height - targetHeight;
	}

}
CropImageWidgetEx.prototype = new ControlBase();
exports = CropImageWidgetEx;


