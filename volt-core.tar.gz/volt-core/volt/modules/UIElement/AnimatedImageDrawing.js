 /** 
 * @author  
 * @fileoverview Definition of AnimatedImageDrawing
 * @date    2014/08/07
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
 
ControlBase = require("UIElement/ControlBase");

function setInterval(cb, interval, param){
	return Volt.setInterval(cb, interval, param);
}

function clearInterval(id){
	if (id !== undefined) {
		Volt.clearInterval(id);
	}
}

AnimatedImageDrawing = function() {       
        this.AnimateState = {
						STATE_PLAY:0,
						STATE_STOP:1,
						STATE_PAUSE:2,
						STATE_IDLE:3
					 };
	
		//variable
		this.currentFrameIdx = 0;
		this.animateDuration = 0;
		this.currentState = this.AnimateState.STATE_IDLE;
		this.isLoopFlag = true;
		this.animateTimer = null;
		this.stopTimer = null;
		this.ImgSrc = [];

		/**
		* This function creates an AniamtedImageDrawing object. 
		* @param {Object} param for this function.
		* @return void
		* @example //This example create an instance.
		*loadingIns = new AnimatedImageDrawing();
		*loadingIns.create({x:10, y:105, width:80, height:80, parent: popupBG});
		* @since The version 1.0 this function is added.
		*/
        this.t_create = function(obj) {
			this.ImgInstance = new ImageWidget({
				x : 0,
				y : 0,
				width : obj.width,
				height : obj.height,
				parent : obj.parent
			});
        };
        
        this.t_destroy = function() {
			var self = this;
		
        	if(this.currentState == this.AnimateState.STATE_PLAY) {
				this.pause();
			}
			else if (this.currentState == this.AnimateState.STATE_STOP){
				if (self.stopTimer != null){
					clearInterval(self.stopTimer);
				}
				
				if(self.animateTimer != null) {
					clearInterval(self.animateTimer);
				} 
			}
			
        	if (this.ImgInstance != null){
				this.ImgInstance.destroy();
				this.ImgInstance = null;
			}
			
			this.ImgSrc.splice(0, this.ImgSrc.length);
			this.ImgSrc = null;
			this.currentFrameIdx = -1;
			this.animateDuration = -1;
			this.currentState = null;		       	
        };

        this.t_getFocus = function() {
        	
        };

        this.t_loseFocus = function() {
        	
        };

        this.t_keyHandler = function(keycode, keytype){
			if (keytype == Volt.EVENT_KEY_RELEASE) 
			{
				return false;
			}				
			return false;
        };
        
		/**
		* This function sets image resource of the animatedImageDrawing object. 
		* @param {imageUrl} param1 for this function.
		* @param {Number} param2 for this function.
		* @return void
		* @example //This example sets image resource of the animatedImageDrawing object.
		*for(var i = 0; i < 18; i++) {
		*loadingIns.setFrames(ImageUrl[i], i);
		*}
		* @since The version 1.0 this function is added.
		*/	
		this.setFrames = function(frames, index) {	
			if(this.isCreated == true) {
				
				if(index < 0) {
					return false;
				}
				
				if(index == 0){
					this.ImgSrc.splice(0, this.ImgSrc.length);
				}
	
				if(this.currentState == this.AnimateState.STATE_PLAY) {					
					this.pause();
				}
	
				if (typeof frames == "string"){
					this.ImgSrc.push(frames);
				}
				
				if(index == 0) {
					this.ImgInstance.src = this.ImgSrc[0];
					this.show();
				}				
				return true;
			}
			
			return false;	
		};
		
		this.deleteAllFrames = function() {
			if(this.isCreated == true) {
				if(this.currentState == this.AnimateState.STATE_PLAY) {
					this.pause();
					this.ImgInstance.src = "";
					this.ImgSrc.splice(0, this.ImgSrc.length);
	
				} else {
					this.ImgInstance.src = "";
					this.ImgSrc.splice(0, this.ImgSrc.length);
				}
				return true;
			}
			
			return false;
		};
		
		this.setPosition = function(xPos, yPos) {
			if(this.isCreated == true) {
				this.x = xPos;
				this.y = yPos;
				return true;
			}
			
			return false;
		};
		
		this.setSize = function(Width, Height) {
			if(this.isCreated == true) {
				if(Width < 0 || Height < 0) {
					return false;
				}	
				
				this.width = Width;
				this.height = Height;
				this.ImgInstance.width = Width;
				this.ImgInstance.height = Height;
				
				return true;
				
			}
			
			return false;
		};
		
		/**
		* This function sets image frames start to animate. 
		* @param {Number} param1 for this function.
		* @param {Number} param2 for this function.
		* @return void
		* @example //This example sets image frames start to animate.
		*loadingIns.play(0, 100);
		* @since The version 1.0 this function is added.
		*/	
		this.play = function(frameIdx, interval) {
			var self = this;
	
			if((this.ImgSrc.length < 1) || (frameIdx < 0) || (interval <= 0)) {
				return false;
			}
	
			if(this.currentState != this.AnimateState.STATE_PLAY) {
				this.animateDuration = interval;
				this.currentState = this.AnimateState.STATE_PLAY;
	
				this.animateTimer = setInterval(function() {
					if(frameIdx < (self.ImgSrc.length - 1)) {
						frameIdx++;
						self.ImgInstance.src = self.ImgSrc[frameIdx];
						self.currentFrameIdx = frameIdx;
					} else {
						if(self.isLoopFlag == true) {
							frameIdx = 0;
							self.ImgInstance.src = self.ImgSrc[frameIdx];
							self.currentFrameIdx = frameIdx;
						} else {
							result = clearInterval(self.animateTimer);
							self.currentFrameIdx = 0;
							self.currentState = self.AnimateState.STATE_STOP;
						}
					}
	
				}, interval);
				
				return true;
			}
			
			return false;
	
		};
		
		this.pause = function() {
			var self = this;
			var result;
	
			if(this.currentState == this.AnimateState.STATE_PLAY) {
				result = clearInterval(self.animateTimer);
				this.currentState = this.AnimateState.STATE_PAUSE;
				return true;
			}
			
			return false;
		};
		
		this.resume = function() {
			var self = this;
			var result;
	
			if(this.ImgSrc.length < 1) {
				return false;
			}
	
			if(this.currentState == this.AnimateState.STATE_PAUSE) {
				this.currentState = this.AnimateState.STATE_PLAY;
	
				this.animateTimer = setInterval(function() {
					if(self.currentFrameIdx < (self.ImgSrc.length - 1)) {
						self.currentFrameIdx++;
						self.ImgInstance.src = self.ImgSrc[self.currentFrameIdx];
					} else {
						if(self.isLoopFlag == true) {
							self.currentFrameIdx = 0;
							self.ImgInstance.src = self.ImgSrc[self.currentFrameIdx];
						} else {
							result = clearInterval(self.animateTimer);
							self.currentFrameIdx = 0;
							self.currentState = self.AnimateState.STATE_STOP;
						}
					}
	
				}, self.animateDuration);
				return true;
			}
			
			return false;
		};
		
		/**
		* This function sets image frames stop animating at the last frame. 
		* @param void
		* @return void
		* @example //This example sets image frames stop animating at the last frame.
		*loadingIns.stop();
		* @since The version 1.0 this function is added.
		*/	
		this.stop = function() {
			var self = this;
			var result;
	
			if(this.currentState == this.AnimateState.STATE_PLAY) {
				if(this.currentFrameIdx == (this.ImgSrc.length - 1)) {
					result = clearInterval(self.animateTimer);
					this.currentFrameIdx = 0;
				} else {
					self.stopTimer = setInterval(function() {
						if(self.currentFrameIdx == (self.ImgSrc.length - 1)) {
							result = clearInterval(self.animateTimer);
							reuslt = clearInterval(self.stopTimer);
							self.currentFrameIdx = 0;
						}
					}, self.animateDuration);
				}
				this.currentState = this.AnimateState.STATE_STOP;
				return true;
			}
			
			return false;
		};
		
		this.setLoop = function(bLoopFlag) {
			this.isLoopFlag = bLoopFlag;
			return true;
		};
		
		this.getLoop = function() {
			return this.isLoopFlag;
		};
		
		this.getState = function() {
			return this.currentState;
		};        
}

AnimatedImageDrawing.prototype = new ControlBase();
exports = AnimatedImageDrawing;