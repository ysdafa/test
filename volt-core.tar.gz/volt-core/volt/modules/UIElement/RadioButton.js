 /** 
 * @author  Daoli Dong (d.dong@samsung.com)
 * @fileoverview Definition of RadioButton
 * @date    2014/08/01
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
ControlBase = require("UIElement/ControlBase");

/**
 * Class RadioButton.
class
 * @constructor
 * @extends UIElement/ControlBase
 */
RadioButton = function() {
	this.radioItemStatus = {
		STATE_UNFOCUS : 0,
		STATE_FOCUS : 1,
		STATE_DISABLE : 2,
		STATE_HIGHTDIM : 3,
       STATE_MAX : 4
	};
    //Inner data
    this.itemList = [];
    this.itemStatusList = [];
    this.radioIconList = [];
    this.radioLabelList = [];
    this.radioCoverList = [];
    this.focusIndex = 0;
    this.selectedIndex = 0;//When move focus to disabled item, this value does not change.
    this.callback = null;
    this.mouseOutCallback = null;
    //Recommended property
    this.itemNumber = 1;
    this.textList = [];
    this.iconSelectedSrc = "";
    this.iconUnselectedSrc = "";
    this.itemHeight = 50;
    this.itemFocusBorder = {width:3, color:{r:0, g:0, b:200, a:255}};
    this.iconWidth = 30;
    this.iconHeight = 30;
    this.textFont = "Helvetica 20px";
    this.textWidth = 0;//set default for no text case.
    this.textHeight = 0;
    //Optional property
    this.isHorizontal = false;
    this.itemSpace = 5;
    this.itemInnerGap = 0;
    this.textColor = {r:0,g:0,b:0,a:255};
    this.itemBGColor = {r:255,g:255,b:255,a:0};
	
    this.t_create = function(obj) {
        //recommended property
        if (obj.hasOwnProperty("itemNumber") && "number" == typeof obj.itemNumber
            && obj.itemNumber>=1) {
            this.itemNumber = obj.itemNumber;
        }
        if (obj.hasOwnProperty("textList") && null != typeof obj.textList
             && "object" == typeof obj.textList) {
            this.textList = obj.textList;
        }
        if (obj.hasOwnProperty("iconSelectedSrc") && "string" == typeof obj.iconSelectedSrc) {
            this.iconSelectedSrc = obj.iconSelectedSrc;
        }
        if (obj.hasOwnProperty("iconUnselectedSrc") && "string" == typeof obj.iconUnselectedSrc) {
            this.iconUnselectedSrc = obj.iconUnselectedSrc;
        }
        if (obj.hasOwnProperty("itemHeight") && "number" == typeof obj.itemHeight
            && obj.itemHeight>=1) {
            this.itemHeight = obj.itemHeight;
        }
        if (obj.hasOwnProperty("focusBorder") && null != typeof obj.focusBorder
             && "object" == typeof obj.focusBorder) {
            this.itemFocusBorder = obj.focusBorder;
        }
        if (obj.hasOwnProperty("iconWidth") && "number" == typeof obj.iconWidth
            && obj.iconWidth>=1) {
            this.iconWidth = obj.iconWidth;
        }
        if (obj.hasOwnProperty("iconHeight") && "number" == typeof obj.iconHeight
            && obj.iconHeight>=1) {
            this.iconHeight = obj.iconHeight;
        }
        if (obj.hasOwnProperty("textWidth") && "number" == typeof obj.textWidth
            && obj.textWidth>=1) {
            this.textWidth = obj.textWidth;
        }
        if (obj.hasOwnProperty("textHeight") && "number" == typeof obj.textHeight
            && obj.textHeight>=1) {
            this.textHeight = obj.textHeight;
        }
        if (obj.hasOwnProperty("textFont") && "string" == typeof obj.textFont) {
            this.textFont = obj.textFont;
        }
        
        //Optional property
        if (obj.hasOwnProperty("isHorizontal") && "boolean" == typeof obj.isHorizontal) {
            this.isHorizontal = obj.isHorizontal;
        }
        if (obj.hasOwnProperty("itemSpace") && "number" == typeof obj.itemSpace) {
            this.itemSpace = obj.itemSpace;
        }
        if (obj.hasOwnProperty("itemInnerGap") && "number" == typeof obj.itemInnerGap) {
            this.itemInnerGap = obj.itemInnerGap;
        }
        if (obj.hasOwnProperty("textColor") && null != typeof obj.textColor
             && "object" == typeof obj.textColor) {
            this.textColor = obj.textColor;
        }
        if (obj.hasOwnProperty("itemBGColor") && null != typeof obj.itemBGColor
             && "object" == typeof obj.itemBGColor) {
            this.itemBGColor = obj.itemBGColor;
        }
        if (obj.hasOwnProperty("selectedIndex") && "number" == typeof obj.selectedIndex
             && obj.selectedIndex >= 0 && obj.selectedIndex < this.itemNumber) {
            this.selectedIndex = obj.selectedIndex;
            this.focusIndex = this.selectedIndex;
        }
        
        //create items
        for(var i = 0; i < this.itemNumber; i++) {
            //Item background
            this.itemList[i] = new Widget({
                x: 0,
                y: (this.itemHeight+this.itemSpace)*i,
                width: this.iconWidth+this.itemInnerGap+this.textWidth,
                height: this.itemHeight,
                color: this.itemBGColor,
                border: {width:0, color:{r:0, g:0, b:0, a:0}},
                parent: obj.parent,
            });
            if(this.isHorizontal){
                this.itemList[i].x = (this.iconWidth+this.itemInnerGap+this.textWidth+this.itemSpace)*i;
                this.itemList[i].y = 0;
            }
            this.itemStatusList[i] = this.radioItemStatus.STATE_UNFOCUS;
            //Icon
            this.radioIconList[i] = new ImageWidget({
                x: 0,
                y: 0,
                width: this.iconWidth,
                height: this.iconHeight,
                src: this.iconUnselectedSrc,
                origin: {x:0,y:0.5},
                anchor: {x:0,y:0.5},
                parent: this.itemList[i],
            });
            //Label is optional
            if(this.textList.length == this.itemNumber){
                this.radioLabelList[i] = new TextWidget({
                    x: this.iconWidth+this.itemInnerGap,
                    y: 0,
                    width: this.textWidth,
                    height: this.textHeight,
                    text: this.textList[i],
                    font: this.textFont,
                    textColor: this.textColor,
                    color: {r:255,g:255,b:255,a:0},
                    origin: {x:0,y:0.5},
                    anchor: {x:0,y:0.5},
                    horizontalAlignment: "center",
                    verticalAlignment: "center",
                    parent: this.itemList[i],
                });
            }
            //Disable cover
            this.radioCoverList[i] = new Widget({
                x: 0,
                y: 0,
                width: this.itemList[i].width,
                height: this.itemList[i].height,
                color: {r:217,g:217,b:217,a:150},
                parent: this.itemList[i],
            });
            this.radioCoverList[i].hide();
        }
        this.m_updateSize();
        //set initial focus item
        this.itemStatusList[this.focusIndex] = this.radioItemStatus.STATE_FOCUS;
        this.itemList[this.focusIndex].border = this.itemFocusBorder;
        this.radioIconList[this.selectedIndex].src = this.iconSelectedSrc;
	};
    this.m_updateSize = function(){
        //update root widget size
        if(this.isHorizontal){
            this.width = (this.radioIconList[0].x+this.iconWidth+this.itemInnerGap+this.textWidth+this.itemSpace)*this.itemNumber;
            this.height = this.itemHeight;
        }
        else{
            this.width = this.radioIconList[0].x+this.iconWidth+this.itemInnerGap+this.textWidth;
            this.height = (this.itemHeight+this.itemSpace)*this.itemNumber;
        }
        //update item size
        for(var i = 0; i < this.itemNumber; i++) {
            this.itemList[i].width = this.radioIconList[0].x+this.iconWidth+this.itemInnerGap+this.textWidth;
        }
    };
    this.m_changeFocusStatus = function(focus, index){
        if(typeof focus != 'boolean' || typeof index != 'number'){
            return;
        }
        if(true == focus){
            //get focus
            this.focusIndex = index;
            this.itemList[index].border = this.itemFocusBorder;
            if(this.radioItemStatus.STATE_UNFOCUS == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_FOCUS;
                if(this.selectedIndex != index){
                    this.radioIconList[this.selectedIndex].src = this.iconUnselectedSrc;
                    this.selectedIndex = index;
                    //does not work for set src twice!
                    this.radioIconList[this.selectedIndex].src = this.iconSelectedSrc;
                }
                this.focusIndex = this.selectedIndex;
                //notify user here!
                if(null != this.callback){
                    this.callback(this.selectedIndex);
                }
                return;
            }
            if(this.radioItemStatus.STATE_DISABLE == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_HIGHTDIM;
                this.focusIndex = index;
                return;
            }
        }
        else{
            //lose focus
            this.itemList[index].border = {width:0, color:{r:0, g:0, b:0, a:0}};
            if(this.radioItemStatus.STATE_FOCUS == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_UNFOCUS;
                //this.radioIconList[index].src = this.iconUnselectedSrc;
                return;
            }
            if(this.radioItemStatus.STATE_HIGHTDIM == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_DISABLE;
                return;
            }
        }
    };
    this.enableMouseEvent = function(enable){
        if(this.isCreated == true && "boolean" == typeof enable){
            if(enable){
                this.rootWidget.addEventListener("OnMouseOut",this.radioMouseOutBind);
                for(var i = 0; i < this.itemNumber; i++) {
                    this.itemList[i].SN = i;
                    this.itemList[i].addEventListener("OnMouseOver",this.radioItemMouseOverBind);
                    //this.itemList[i].addEventListener("OnMouseOut",this.radioItemMouseOutBind);
                }
            }
            else{
                this.rootWidget.removeEventListener("OnMouseOut",this.radioMouseOutBind);
                for(var i = 0; i < this.itemNumber; i++) {
                    this.itemList[i].removeEventListener("OnMouseOver",this.radioItemMouseOverBind);
                    //this.itemList[i].removeEventListener("OnMouseOut",this.radioItemMouseOutBind);
                }
            }
        }
    };
    
    this.radioMouseOut = function(targetWidget, eventData){
        if(this.isFocused && !this.isDimed){
            //notify user here!
            if(null != this.mouseOutCallback){
                this.mouseOutCallback(this.selectedIndex);
            }
        }
        return false;
    };
    this.radioMouseOutBind = this.radioMouseOut.bind(this);
    
    this.radioItemMouseOver = function(targetWidget, eventData){
        if(this.isFocused && !this.isDimed){
            //unfocus
            this.m_changeFocusStatus(false, this.focusIndex);
            //focus
            this.m_changeFocusStatus(true, targetWidget.SN);
        }
        return false;
    };
    this.radioItemMouseOverBind = this.radioItemMouseOver.bind(this);
    /*
    this.radioItemMouseOut = function(targetWidget, eventData){
        if(this.isFocused){
            if(this.itemNumber > 1){
                //unfocus
                //this.m_changeFocusStatus(false, targetWidget.SN);
            }
        }
    };
    this.radioItemMouseOutBind = this.radioItemMouseOut.bind(this);
    */
    this.t_destroy = function() {
        for(var i = 0; i < this.itemNumber; i++) {
            this.radioIconList[i].destroy();
            this.radioLabelList[i].destroy();
            this.radioCoverList[i].destroy();
            this.itemList[i].destroy();
        }
        this.itemList.length = 0;
        this.itemStatusList.length = 0;
        this.radioIconList.length = 0;
        this.radioLabelList.length = 0;
        this.radioCoverList.length = 0;
        this.textList.length = 0;
        this.itemList = null;
        this.itemStatusList = null;
        this.radioIconList = null;
        this.radioLabelList = null;
        this.radioCoverList = null;
        this.textList = null;
        
        delete this.radioMouseOutBind;
        delete this.radioItemMouseOverBind;
    };
    this.t_getFocus = function() {
    };
    this.t_loseFocus = function() {
    };
    this.t_show = function() {
    };
    this.t_hide = function() {
    };

	this.t_keyHandler = function(keycode, keytype) {	
        if (keytype == Volt.EVENT_KEY_RELEASE) 
        {
            return false;
        }		

        var ret = false;
        switch(keycode) {
            case Volt.KEY_JOYSTICK_UP:
                if(!this.isHorizontal){
                    if(this.focusIndex > 0) {
                        this.m_changeFocusStatus(false,this.focusIndex);
                        this.m_changeFocusStatus(true,this.focusIndex-1);
                        ret = true;
                    }
                }
                break;
            case Volt.KEY_JOYSTICK_DOWN:
                if(!this.isHorizontal){
                    if(this.focusIndex < this.itemNumber - 1) {
                        this.m_changeFocusStatus(false,this.focusIndex);
                        this.m_changeFocusStatus(true,this.focusIndex+1);
                        ret = true;
                    }
                }
                break;
            case Volt.KEY_JOYSTICK_RIGHT:
                if(this.isHorizontal){
                    if(this.focusIndex < this.itemNumber - 1) {
                        this.m_changeFocusStatus(false,this.focusIndex);
                        this.m_changeFocusStatus(true,this.focusIndex+1);
                        ret = true;
                    }
                }
                break;
            case Volt.KEY_JOYSTICK_LEFT:
                if(this.isHorizontal){
                    if(this.focusIndex > 0) {
                        this.m_changeFocusStatus(false,this.focusIndex);
                        this.m_changeFocusStatus(true,this.focusIndex-1);
                        ret = true;
                    }
                }
                break;
            case Volt.KEY_JOYSTICK_OK:
                //todo
                break;

            default:
                //todo
                break;
        }
        return ret;
	};
	
	//set ItemWidget properties
	this.setItemBGColor = function(color){
		if(this.isCreated == true && typeof color == 'object') {
          this.itemBGColor = color;
			for(var i = 0; i < this.itemNumber; i++) {
				this.itemList[i].color= color;
			}
			return true;
		}
		return false;
	};
    this.setItemFocusBorder = function(border) {
        if (this.isCreated == true && typeof border == 'object') {
            this.itemFocusBorder = border;
            this.itemList[this.focusIndex].border = border;
            return true;
        }
        return false;
    };
	//set RadioIcon properties
	this.setRadioIconPosition = function(posX,posY){
		if(this.isCreated == true && typeof posX == 'number' && typeof posY == 'number') {
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioIconList[i].x= posX;
				this.radioIconList[i].y= posY;
			}
			return true;
		}
		return false;
	};
	this.setRadioIconSize = function(width,height){
		if(this.isCreated == true && typeof width == 'number' && typeof height == 'number') {
           this.iconWidth = width;
           this.iconHeight = height;
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioIconList[i].width= width;
				this.radioIconList[i].height= height;
			}
           this.m_updateSize();
			return true;
		}
		return false;
	};
	this.setUnSelectedIcon = function(imgSrc) {
		if(this.isCreated == true && typeof imgSrc == 'string') {
           this.iconUnselectedSrc = imgSrc;
			for(var i = 0; i < this.itemNumber; i++) {
              if(i == this.selectedIndex)
                  continue;
				this.radioIconList[i].src = imgSrc;
			}
			return true;
		}
		return false;
	};	
	this.setSelectedIcon = function(imgSrc) {
		if(this.isCreated == true && typeof imgSrc == 'string') {
           this.iconSelectedSrc = imgSrc;
			this.radioIconList[this.selectedIndex].src = imgSrc;
			return true;
		}
		return false;
	};	
	//set ItemText properties
	this.setItemTextContent = function(textList) {
        if(this.isCreated == true && "object" == typeof textList && null != textList && textList.length == this.itemNumber){
            this.textList = textList;
            for(var i = 0; i < this.itemNumber; i++) {
                this.radioLabelList[i] = new TextWidget({
                    x: this.iconWidth+this.itemInnerGap,
                    y: 0,
                    width: this.textWidth,
                    height: this.textHeight,
                    text: this.textList[i],
                    font: this.textFont,
                    textColor: this.textColor,
                    color: {r:255,g:255,b:255,a:0},
                    origin: {x:0,y:0.5},
                    anchor: {x:0,y:0.5},
                    horizontalAlignment: "center",
                    verticalAlignment: "center",
                    parent: this.itemList[i],
                });
            }
            return true;
        }
        return false;
	};	
	this.setItemTextPosition = function(posX,posY){
		if(this.isCreated == true && typeof posX == 'number' && typeof posY == 'number'
            && this.radioLabelList.length == this.itemNumber) {
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioLabelList[i].x= posX;
				this.radioLabelList[i].y= posY;
			}
			return true;
		}
		return false;
	};
	this.setItemTextSize = function(width,height){
		if(this.isCreated == true && typeof width == 'number' && typeof height == 'number'
            && this.radioLabelList.length == this.itemNumber) {
           this.textWidth = width;
           this.textHeight = height;
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioLabelList[i].width= width;
				this.radioLabelList[i].height= height;
			}
           this.m_updateSize();
			return true;
		}
		return false;
	};
	this.setItemTextBGColor = function(color) {
		if(this.isCreated == true && "object" == typeof color
            && this.radioLabelList.length == this.itemNumber){
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioLabelList[i].color= color;
			}
			return true;
		}
		return false;
	};
	this.setItemTextFont = function(font){
		if(this.isCreated == true && "string" == typeof font && font.length>0
            && this.radioLabelList.length == this.itemNumber) {
           this.textFont = font;
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioLabelList[i].font= font;
			}
			return true;
		}
		return false;
	};
    this.setItemTextColor = function(color){
		if(this.isCreated == true && "object" == typeof color
            && this.radioLabelList.length == this.itemNumber) {
           this.textColor = color;
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioLabelList[i].textColor= color;
			}
			return true;
		}
		return false;
	};
	this.setItemTextHorizontalAlignment= function(horizontalAlignment){
		if(this.isCreated == true && "string" == typeof horizontalAlignment
            &&("left" == horizontalAlignment||"center" == horizontalAlignment||"right" == horizontalAlignment)
            && this.radioLabelList.length == this.itemNumber) {
            for(var i = 0; i < this.itemNumber; i++) {
                this.radioLabelList[i].horizontalAlignment= horizontalAlignment;
            }
            return true;
		}
		return false;
	};
	this.setItemTextVerticalAlignment= function(verticalAlignment){
		if(this.isCreated == true && "string" == typeof verticalAlignment
            &&("top" == verticalAlignment||"center" == verticalAlignment||"bottom" == verticalAlignment)
            && this.radioLabelList.length == this.itemNumber) {
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioLabelList[i].verticalAlignment= verticalAlignment;
			}
			return true;
		}
		return false;
	};
	//set disableCover properties
	this.setDisableCoverColor = function(color) {
		if(this.isCreated == true && "object" == typeof color){
			for(var i = 0; i < this.itemNumber; i++) {
				this.radioCoverList[i].color= color;
			}
			return true;
		}
	};
    this.disableItem = function(index){
		 if(this.isCreated == true && "number" == typeof index
            && index>=0 && index<this.itemNumber){
            //Cannot disable selected item because we donnot know which else to select
            if(index == this.selectedIndex){
                return false;
            }
            this.radioCoverList[index].show();
            if(this.radioItemStatus.STATE_UNFOCUS == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_DISABLE;
            }
            else if(this.radioItemStatus.STATE_FOCUS == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_HIGHTDIM;
            }
            return true;
        }
        return false;
    };
    this.enableItem = function(index){
		 if(this.isCreated == true && "number" == typeof index
            && index>=0 && index<this.itemNumber){
            this.radioCoverList[index].hide();
            if(this.radioItemStatus.STATE_DISABLE == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_UNFOCUS;
            }
            else if(this.radioItemStatus.STATE_HIGHTDIM == this.itemStatusList[index]){
                this.itemStatusList[index] = this.radioItemStatus.STATE_FOCUS;
                if(this.selectedIndex != index){
                    this.radioIconList[this.selectedIndex].src = this.iconUnselectedSrc;
                    this.selectedIndex = index;
                    //does not work for set src twice!
                    this.radioIconList[this.selectedIndex].src = this.iconSelectedSrc;
                }
                this.focusIndex = this.selectedIndex;
                //notify user here!
                if(null != this.callback){
                    this.callback(this.selectedIndex);
                }
            }
            return true;
        }
        return false;
    };
    this.setCallback = function(callback){
		 if(this.isCreated == true && "function" == typeof callback){
            this.callback = callback;
        }
    };
    this.setMouseOutCallback = function(mouseOutCallback){
		 if(this.isCreated == true && "function" == typeof mouseOutCallback){
            this.mouseOutCallback = mouseOutCallback;
        }
    };
}

RadioButton.prototype = new ControlBase();
exports = RadioButton;
