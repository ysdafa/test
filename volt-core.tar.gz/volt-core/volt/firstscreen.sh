#!/bin/sh
DISPLAY=:0

while [ ! -e /tmp ] || [ ! -e /run/smack_apply_done ]
do
	sleep 0.1
done

chmod 666 /dev/bptime

chsmack -a '*' /dev/bptime

chmod 666 /dev/zero

chsmack -a '*' /dev/zero

touch /tmp/firstscreen_start

if [ -r /tmp/firstscreen_start ]; then
	echo "[VOLT] /tmp mounted"
else
    echo "[VOLT] /tmp is not ready"
fi

echo "[VOLT] alaunch smack labeling"

/bin/mkdir -m 1777 /tmp/alaunch
echo "[VOLT] /bin/mkdir -m 1777 /tmp/alaunch"

/usr/bin/chsmack -a '*' /tmp/alaunch
echo "[VOLT] /usr/bin/chsmack -a '*' /tmp/alaunch"

chmod 660 /dev/dlog_mgr
chown :app_logging /dev/dlog_mgr
chsmack -a '*' /dev/dlog_mgr

chmod 660 /dev/log_system
chown :sys_logging /dev/log_system
chsmack -a 'device::sys_logging' /dev/log_system

chmod 660 /dev/log_main /dev/log_radio /dev/log_events
chown :app_logging /dev/log_main /dev/log_radio /dev/log_events
chsmack -a 'device::app_logging' /dev/log_main /dev/log_radio /dev/log_events

chmod 666 /dev/kdbus/0-kdbus-system/bus
chsmack -a 'dbus' /dev/kdbus/0-kdbus-system/bus

chmod 666 /dev/kdbus/5000-kdbus/bus
chsmack -a 'dbus' /dev/kdbus/5000-kdbus/bus

chmod 660 /dev/snd/controlC0
chown :audio /dev/snd/controlC0
chsmack -a 'device::audio' /dev/snd/controlC0

/sbin/insmod /lib/modules/3.10.30/kernel/drivers/misc/tzdev/tzdev.ko
/sbin/insmod /lib/modules/3.10.30/kernel/drivers/misc/ssdev/ssdev.ko

chmod 666 /dev/tzmem
chsmack -a 'dtv-trustzone-nwd' /dev/tzmem

if [ -e /opt/var/kdb/db/boot_by_factory_reset ] || [ -e /opt/var/kdb/db/boot_by_service_reset ]; then
    echo "[VOLT] Factory / Service Reset!, First Screen Launch Skip!"
    exit 0
fi

bin/bash -c '/usr/bin/sqlite3 /opt/dbspace/.rules-db.db3 < /usr/share/privilege-control/db/load-rules-db-volt.sql | smackload'
echo "[VOLT] '/usr/bin/sqlite3 /opt/dbspace/.rules-db.db3 < /usr/share/privilege-control/db/load-rules-db-volt.sql | smackload'"
setsid /usr/bin/firstscreen-launcher



