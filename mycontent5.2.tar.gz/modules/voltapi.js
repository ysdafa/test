/**
 * Title: voltapi.js 
 * Version: 0.927
 * Date: 2014-11-27
 */
exports.volt_api_version = "0.928";
exports.volt_api_version_date = "2014-12-11";


var self = this;

var isArray = function(Obj){
	return Object.prototype.toString.call(Obj) == '[object Array]';
}

ResourceRequest.prototype.setHeader = function(key, value) {
	this.removeHeader(key);
	this.addHeader(key, value);
}

exports.util = {

		isReadyWAS:function(successCallback, errorCallback, interval, retry)
		{
			if('function' !== typeof(successCallback) && 'function' !== typeof(errorCallback))
			{
				return false;
			}
			
			if(undefined === interval)
			{
				interval = 1000;
			}
			else if('number' !== typeof(interval) && 0 > interval)
			{
				return false;
			}
			
			if(undefined === retry)
			{
				retry = 30;
			}
			else if('number' !== typeof(retry) && 0 > retry)
			{
				return false;
			}
			
			Log.e("[util]interval:"+interval+", retry:"+retry);
			var wasIntervalId = Volt.setInterval(function(){
				var ret = VDUtil.isExistWASTempFile();
				if (ret)
				{
					Log.e("[util]exist WAS ready file!!");
					Volt.clearInterval(wasIntervalId);
					successCallback();
				}
				
				retry--;
				if(retry === 0)
				{
					Log.e("[util]NOT exist WAS ready file!!");
					Volt.clearInterval(wasIntervalId);
					errorCallback();
				}
			}, interval);
			Log.e("[util]wasIntervalId:"+wasIntervalId);
			return true;
		}
		
};

exports.rest = {
		m_requestMap:{},
		m_bOpened:false,
		m_uri:'',
		m_body:'',
		m_responseType:'string',
		m_headerMap:{},
		m_smartTVServer:false,
		m_interval:10000,
		m_retry:3,
		m_smartTVClientHeader:'',
		m_noCache:false,
		HEADER_STATUS:{
			PARAMETER_ERROR:0,
			SUCCESS:1,
			FAIL_A_TOKEN:2,
			FAIL_USER_TOKEN:3,
			FAIL_DUID:4,
			FAIL_SW_VERSION:5,
			FAIL_INFOLINK_VERSION:6,
			FAIL_GPM_URL:7,
			UNKNOWN:999
		},
		/*restError:{
			httpStatus:0,
			errorCode:0,
			message:'',
			description:''
		},*/

		init:function()
		{
			Log.e("[rest]init start");
			this.m_headerMap['Content-Type'] = 'application/json; charset=utf-8';
			this.m_headerMap['Accept'] = 'application/json';

			var check_was = exports.WAS.isOpened();
			var check_device = exports.device.isOpened();
			Log.e("[rest]init start check_was:"+check_was+", check_device:"+check_device);
			if (false === check_was)
			{
				check_was = exports.WAS.init();
			}
			if (false === check_device)
			{
				check_device = exports.device.init();
			}
			Log.e("[rest]init end check_was:"+check_was+", check_device:"+check_device);
			
			if(true === check_was && true === check_device)
			{
				this.m_bOpened = true;
				return this.m_bOpened;
			}
			
			return this.m_bOpened;
		},
		initAsync:function(OpenCallback)
		{
			Log.e("[rest]initAsync start");
			this.m_headerMap['Content-Type'] = 'application/json; charset=utf-8';
			this.m_headerMap['Accept'] = 'application/json';
			
			var completed_cb = 0;
			var check_was = exports.WAS.isOpened();
			var check_device = exports.device.isOpened();
			Log.e("[rest]initAsync check_was:"+check_was+", check_device:"+check_device);
			if (false === check_was)
			{
				exports.WAS.initAsync(function(is_success){
					Log.e("[rest]WAS is_success:"+is_success);
					check_was = is_success;
					completed_cb++;
					Log.e("[rest]WAS completed_cb:"+completed_cb);
					if(2 === completed_cb)
					{
						if(true === check_was && true === check_device)
						{
							exports.rest.m_bOpened = true;
						}
						else
						{
							exports.rest.m_bOpened = false;
						}
						OpenCallback(exports.rest.m_bOpened);
					}
				});
			}
			else
			{
				completed_cb++;
			}
			if (false === check_device)
			{
				exports.device.initAsync(function(is_success){
					Log.e("[rest]device is_success:"+is_success);
					check_device = is_success;
					completed_cb++;
					Log.e("[rest]device completed_cb:"+completed_cb);
					if(2 === completed_cb)
					{
						if(true === check_was && true === check_device)
						{
							exports.rest.m_bOpened = true;
						}
						else
						{
							exports.rest.m_bOpened = false;
						}
						OpenCallback(exports.rest.m_bOpened);
					}
				});
			}
			else
			{
				completed_cb++;
			}
			
			if(2 === completed_cb)
			{
				if(true === check_was && true === check_device)
				{
					exports.rest.m_bOpened = true;
				}
				else
				{
					exports.rest.m_bOpened = false;
				}
				OpenCallback(exports.rest.m_bOpened);
			}
		},
		isOpened:function()
		{
			Log.e("[rest]isOpened");
			return this.m_bOpened;
		},
		setParam:function(key, value)
		{
			Log.e("[rest]setParam["+key+"]("+typeof(key)+")["+value+"]("+typeof(value)+")");
			if('string' === typeof(key) && 'string' === typeof(value))
			{
				value = encodeURIComponent(value);
				this.m_uri += key + '=' + value + '&';
				return true;
			}
			return false;
		},
		clearParam:function()
		{
			Log.e("[rest]clearParam");
			this.m_uri = '';
			return true;
		},
		setBody:function(value)
		{
			Log.e("[rest]setBody["+value+"]("+typeof(value)+")");
			if('string' === typeof(value))
			{
				this.m_body = value;
				this.m_headerMap['Content-Length'] = value.length.toString();
				return true;
			}
			return false;
		},
		clearBody:function()
		{
			Log.e("[rest]clearBody");
			this.m_body = '';
			this.m_headerMap['Content-Length'] = '0';
			return true;
		},
		sendAsync:function(r_method, resourcePath, successCallback, errorCallback, completeCallback, readyCallback)
		{
			Log.e("[rest]sendAsync["+r_method+"]("+typeof(r_method)+")["+resourcePath+"]("+typeof(resourcePath)+")");
			var request_id = new Date().getTime();
			Log.e("[rest]async request_id:"+request_id);
			this.m_requestMap[request_id] = {intervalId:-1, resourceRequest:{}, isCancel:false};
			
			var request_uri = '';
			if(this.m_smartTVServer)
			{
				try
				{
					request_uri = this.getRequestUri(resourcePath);
					Log.e("[rest]async request_uri:"+request_uri);
				}
				catch(e)
				{
					return e;
				}
			}
			else
			{
				request_uri = resourcePath;
			}
			
			if(this.m_uri !== '')
			{
				this.m_uri = this.m_uri.slice(0,-1);
				request_uri += '?'+this.m_uri;
			}
			
			Log.e("[rest]async full request_uri:"+request_uri);
			this.m_requestMap[request_id].resourceRequest = new ResourceRequest({
				uri: request_uri,
				async: true,
				method: r_method,
				data: this.m_body,
				response_type: this.m_responseType,
				noCache: this.m_noCache
			});
			
			for(var header in this.m_headerMap)
			{
				this.m_requestMap[request_id].resourceRequest.addHeader(header, this.m_headerMap[header]);
			}
			
			var retry_num = this.m_retry;
			var interval_num = this.m_interval;
			
			this.m_requestMap[request_id].resourceRequest.success = function(data, status, response)
			{
				Log.e("[rest]success callback interval_id:"+exports.rest.m_requestMap[request_id].intervalId+", retry_num:"+retry_num+", status:"+response.status+", reason:"+response.reason+", request_id:"+request_id);
				retry_num = 0;
				successCallback(data, status, response);
			};
			
			this.m_requestMap[request_id].resourceRequest.error = function(response, status, exception)
			{
				Log.e("[rest]error callback retry_num:"+retry_num+", status:"+response.status+", reason:"+response.reason+", request_id:"+request_id);
				if(retry_num <= 0)
				{
					errorCallback(response, status, exception);
				}
			};
			
			this.m_requestMap[request_id].resourceRequest.complete = function(response, status)
			{
				Log.e("[rest]complete callback retry_num:"+retry_num+", status:"+response.status+", reason:"+response.reason+", request_id:"+request_id);
				if(retry_num <= 0)
				{
					completeCallback(response, status);
					Volt.clearInterval(exports.rest.m_requestMap[request_id].intervalId);
					//delete exports.rest.m_requestMap[request_id];
				}
			};
			
			var ret = this.m_requestMap[request_id].resourceRequest.process();
			Log.e("[rest]is process success:"+ret+", request_id:"+request_id);
			readyCallback(request_id);
			
			this.m_requestMap[request_id].intervalId = Volt.setInterval(function(){
				Log.e("[rest]setInterval interval_id:"+exports.rest.m_requestMap[request_id].intervalId+", retry_num:"+retry_num);
				Log.e("[rest]setInterval isCancel:"+exports.rest.m_requestMap[request_id].isCancel+", request_id:"+request_id);
				if(retry_num > 0 && false === exports.rest.m_requestMap[request_id].isCancel)
				{
					exports.rest.m_requestMap[request_id].resourceRequest.process();
					retry_num--;
				}
				else
				{
					Volt.clearInterval(exports.rest.m_requestMap[request_id].intervalId);
					retry_num = 0;
					//delete exports.rest.m_requestMap[request_id];
				}
			},interval_num);

			return this.HEADER_STATUS.SUCCESS;
		},
		sendSync:function(r_method, resourcePath)
		{
			Log.e("[rest]sendSync["+r_method+"]("+typeof(r_method)+")["+resourcePath+"]("+typeof(resourcePath)+")");

			var request_uri = '';
			if(this.m_smartTVServer)
			{
				try
				{
					request_uri = this.getRequestUri(resourcePath);
					Log.e("[rest]sync request_uri:"+request_uri);
				}
				catch(e)
				{
					return e;
				}
			}
			else
			{
				request_uri = resourcePath;
			}
			
			if(this.m_uri !== '')
			{
				this.m_uri = this.m_uri.slice(0,-1);
				request_uri += '?'+this.m_uri;
			}
			
			Log.e("[rest]sync full request_uri:"+request_uri);
			var resource_request = new ResourceRequest({
				uri: request_uri,
				async: false,
				method: r_method,
				data: this.m_body,
				response_type: this.m_responseType,
				noCache: this.m_noCache
			});

			resource_request.error = function(response, status, exception)
			{
				Log.e("[rest]error callback status:"+status+", exception:"+exception);
				exports.rest.sleep(exports.rest.m_interval);
			};

			var result;
			for(var n = 0; n < this.m_retry; n++)
			{
				result = resource_request.process();
				if(result === null)
				{
					Log.e("[rest]sync result:"+result);
					continue;
				}
				var error = parseInt(result['status']);
				if(error >= 400 || error >= 500)
				{
					Log.e("[rest]sync error:"+error);
				}
				else
				{
					Log.e("[rest]sync no error:"+error);
					break;
				}
			}

			return result;
		},
		setHeader:function(key, value)
		{
			Log.e("[rest]setHeader["+key+"]("+typeof(key)+")["+value+"]("+typeof(value)+")");
			if('string' === typeof(key) && 'string' === typeof(value))
			{
				if('SmartTVClient' === key)
				{
					value = this.m_smartTVClientHeader+'+'+value;
				}
				
				this.m_headerMap[key] = value;
				
				return true;
			}
			return false;
		},
		clearHeader:function(key)
		{
			Log.e("[rest]clearHeader["+key+"]("+typeof(key)+")");
			if('string' === typeof(key))
			{
				if(this.m_headerMap[key])
				{
					delete this.m_headerMap[key];
					return true;
				}
				else
				{
					return false;
				}
			}
			else if(undefined === typeof(key))
			{
				for(var n in this.m_headerMap)
				{
					delete this.m_headerMap[n];
				}
				return true;
			}
			return false;
		},
		setContentType:function(type)
		{
			Log.e("[rest]setContentType["+type+"]("+typeof(type)+")");
			if(type === 'xml')
			{
				this.m_headerMap['Content-Type'] = 'application/xml; charset=utf-8';
				this.m_headerMap['Accept'] = 'application/xml';
				return true;
			}
			else if (type === 'json')
			{
				this.m_headerMap['Content-Type'] = 'application/json; charset=utf-8';
				this.m_headerMap['Accept'] = 'application/json';
				return true;
			}
			return false;
		},
		setResponseType:function(type)
		{
			Log.e("[rest]setResponseType["+type+"]("+typeof(type)+")");
			if('arraybuffer' === type || 'string' === type)
			{
				this.m_responseType = type;
			}
			else
			{
				return false;
			}
			return true;
		},
		setSmartTVHeader:function(isUse, clientVersion)
		{
			Log.e("[rest]setSmartTVHeader["+isUse+"]("+typeof(isUse)+")["+clientVersion+"]("+typeof(clientVersion)+")");
			if('boolean' !== typeof(isUse))
			{
				return this.HEADER_STATUS.PARAMETER_ERROR;
			}

			this.m_smartTVServer = isUse;
			if(true === isUse)
			{
				this.m_headerMap['Cache-Control'] = 'no-cache';
				this.m_headerMap['Accept-Encoding'] = 'gzip, deflate';
				
				var aToken = Vconf.getString('db/comss/atoken');
				Log.e("[rest]getAToken:"+aToken+", type is "+typeof(aToken));
				Vconf.setOnChangeHandler('db/comss/atoken', function(key, val)
				{
					Log.e("[rest]getAToken, key:"+key+", val:"+val);
				});
				if('' === aToken)
				{
					return this.HEADER_STATUS.FAIL_A_TOKEN;
				}
				this.m_headerMap['AToken'] = aToken;
				
				var userToken = '';
				var ssso_state = exports.WAS.getSSOLoginState();
				Log.e("[rest]getSSOLoginState:"+ssso_state);
				if(1 === ssso_state)
				{
					userToken = exports.WAS.getSSOToken();
					Log.e("[rest]getSSOToken:"+userToken);
					if('' === userToken)
					{
						return this.HEADER_STATUS.FAIL_USER_TOKEN;
					}
					this.m_headerMap['UserToken'] = userToken;
				}
				
				var duid = Vconf.getString('db/comss/duid');
				Log.e("[rest]getDuid:"+duid+", type is "+typeof(duid));
				Vconf.setOnChangeHandler('db/comss/duid', function(key, val)
				{
					Log.e("[rest]getDuid, key:"+key+", val:"+val);
				});
				if('' === duid)
				{
					return this.HEADER_STATUS.FAIL_DUID;
				}
				this.m_headerMap['DUID'] = duid;
				
				//param1:DEVICE_MAIN_TV[0],DEVICE_SBB[1], param2:VERSION_SWVERSION[1]
				var swVersion = exports.device.getSWVersion(0, 1);
				Log.e("[rest]getSWVersion:"+swVersion+", type is "+typeof(swVersion));
				if('' === swVersion)
				{
					return this.HEADER_STATUS.FAIL_SW_VERSION;
				}
				
				var infolinkVersion = exports.WAS.getInfolinkVer();
				Log.e("[rest]getInfolinkVer:"+infolinkVersion+", type is "+typeof(infolinkVersion));
				if('' === infolinkVersion)
				{
					return this.HEADER_STATUS.FAIL_INFOLINK_VERSION;
				}
				
				var voltVersion = Volt.getVersion();
				for(var key in voltVersion)
				{
					Log.e("[rest]Volt.getVersion["+key+"]"+voltVersion[key]+", type is "+typeof(voltVersion[key]));
				}
				
				this.m_smartTVClientHeader = 
					'OTN-FW/' + swVersion + 
					'+T-INFOLINK/' + infolinkVersion +
					'+Volt/' + voltVersion['string'];
				
				if('string' === typeof(clientVersion))
				{
					this.m_smartTVClientHeader += '+' + clientVersion;
				}
				this.m_headerMap['SmartTVClient'] = this.m_smartTVClientHeader;
			}
			else
			{
				delete this.m_headerMap['Cache-Control'];
				delete this.m_headerMap['Accept-Encoding'];
				delete this.m_headerMap['Host'];
				delete this.m_headerMap['LocalTime'];
				delete this.m_headerMap['AToken'];
				delete this.m_headerMap['UserToken'];
				delete this.m_headerMap['DUID'];
				delete this.m_headerMap['SmartTVClient'];
			}
			return this.HEADER_STATUS.SUCCESS;
		},
		setTimeout:function(interval, retry)
		{
			Log.e("[rest]setTimeout["+interval+"]("+typeof(interval)+")["+retry+"]("+typeof(retry)+")");
			if('number' === typeof(interval) && 'number' === typeof(retry))
			{
				this.m_interval = interval;
				this.m_retry = retry;
				return true;
			}
			return false;
		},
		setCache:function(isUse)
		{
			Log.e("[rest]setCache["+isUse+"]("+typeof(isUse)+")");
			this.m_noCache = isUse;
			return true;
		},
		cancel:function(id)
		{
			Log.e("[rest]cancel id["+id+"]("+typeof(id)+")");
			var ret = false;
			if(undefined === id)
			{
				return ret;
			}
			if(undefined === this.m_requestMap[id].resourceRequest)
			{
				return ret;
			}
			ret = this.m_requestMap[id].resourceRequest.cancel();
			Log.e("[rest]cancel ret["+ret+"]("+typeof(ret)+")");
			if(ret)
			{
				this.m_requestMap[id].isCancel = true;
			}
			return ret;
		},
		getRequestUri:function(resourcePath)
		{
			var key;
			var tmp = resourcePath.split('/');
			if(resourcePath[0] === '/')
			{
				key = tmp[1];
			}
			else
			{
				key = tmp[0];
			}
			Log.e("[rest]vconf gpmurl key:"+key);
			var domain = Vconf.getString('db/comss/gpmurl/'+key);
			Log.e("[rest]request domain:"+domain);
			if(domain === undefined || domain === '')
			{
				throw this.HEADER_STATUS.FAIL_GPM_URL;
			}
			
			var begine_str = '://';
			var begin = domain.indexOf(begine_str);
			var end = domain.lastIndexOf(':');
			var host = "";
			Log.e("[rest]begin["+begin+"]end["+end+"]");
			if(-1 === begin || -1 === end)
			{
				host = domain;
			}
			else if(begin === end)
			{
				host = domain.substring(begin+begine_str.length, domain.length);
			}
			else
			{
				host = domain.substring(begin+begine_str.length, end);
			}
			Log.e("[rest]host:"+host);
			this.m_headerMap['Host'] = host;
			
			var localtime = this.getLocalTime();
			Log.e("[rest]localtime:"+localtime);
			this.m_headerMap['LocalTime'] = localtime;
			
			requset_uri = domain+'/'+resourcePath;
			
			return requset_uri;
		},
		getLocalTime:function()
		{
			var curDateTime = new Date();
			var localDateTime = curDateTime.getFullYear() + '-';
			var month = (curDateTime.getMonth()+1);
			if(month < 10)
			{
				localDateTime += '0';
			}
			localDateTime += month + '-';
			
			var day = curDateTime.getDate();
			if(day < 10)
			{
				localDateTime += '0';
			}
			localDateTime += day + 'T';
			
			var hour = curDateTime.getHours();
			if(hour < 10)
			{
				localDateTime += '0';
			}
			localDateTime += hour + ':';
			
			var min = curDateTime.getMinutes();
			if(min < 10)
			{
				localDateTime += '0';
			}
			localDateTime += min + ':';
			
			var sec = curDateTime.getSeconds();
			if(sec < 10)
			{
				localDateTime += '0';
			}
			localDateTime += sec;
			
			var timezoneOffset = curDateTime.getTimezoneOffset();
			var gmtOffsetHour;
			if(timezoneOffset > 0)
			{
				gmtOffsetHour = Math.ceil(-(timezoneOffset/60));
				localDateTime += '-';
			}
			else
			{
				gmtOffsetHour = Math.floor(-(timezoneOffset/60));
				localDateTime += '+';
			}
			gmtOffsetHour = Math.abs(gmtOffsetHour);
			
			if(gmtOffsetHour < 10)
			{
				localDateTime += '0';
			}
			localDateTime += gmtOffsetHour + ':';
			
			var gmtOffsetMin = (-(timezoneOffset%60));
			gmtOffsetMin = Math.abs(gmtOffsetMin);
			
			if(gmtOffsetMin < 10)
			{
				localDateTime += '0';
			}
			localDateTime += gmtOffsetMin;
			
			return localDateTime;
		},
		sleep:function(ms)
		{
			var curTime = new Date();
			var exitTime = curTime.getTime() + (ms);
			while(true)
			{
				curTime = new Date();
				if (curTime.getTime() > exitTime) return;
			}
		}
};

var sefFactory = new SefFactory();

Volt.addEventListener(Volt.ON_UNLOAD, function() {
	sefFactory.allReleaseSEF();
	Log.e("--------------------------------------->>[VOLT ON_UNLOAD] SEF ALL Release!!!!!!!!!!!!!!!!");
 });


function SefFactory() {
	sefMap = {};
	/**
	 * @ignore
	 */
	this.init = function(name) {
		if (sefMap[name] == null) {
			sefMap[name] = new Sef();
			return sefMap[name].open(name, "1.00", name);
		}
			Log.e("AlreadyInitializedException : " + name);
		// throw "AlreadyInitializedException : " + name;
	};
	this.initAsync = function(name, onOpenCallback) {
		if (sefMap[name] == null) {
			sefMap[name] = new Sef();
			return sefMap[name].openAsync(name, "1.00", name, function(is_success) {
				onOpenCallback(is_success);
			});
			
			Log.e("AlreadyInitializedException : " + name);
		}	
	};	
	this.getSEF = function(name) {
		if (sefMap[name] == null) {
			throw "NoInitializationException : " + name;
		}
		return sefMap[name];
	};
	this.releaseSEF = function(name) {
		if (sefMap[name] != null) {
			sefMap[name].close();
			delete sefMap[name];
		}
	};
	this.allReleaseSEF = function(){
		for(var p in aPlayerInstance){
			if (p != null) {				
				aPlayerInstance[p].close();
				delete aPlayerInstance[p];
			}
		}
		for(var idx in sefMap){			
			if (idx != null) {				
				sefMap[idx].close();
				delete sefMap[idx];
				
			}
		}
	};

}




var CSFLocalAPI = {};
//var CSFeventList = {};
var CSFcbList = {};
var CSFState = {

	SEF_CSF_EVENT_REQUEST_LIST_SUCCESS : 0,
	SEF_CSF_EVENT_REQUEST_LIST_FAIL : 1,
	SEF_CSF_EVENT_REQUEST_DETAIL_SUCCESS : 2,
	SEF_CSF_EVENT_REQUEST_DETAIL_FAIL : 3,
	SEF_CSF_EVENT_ACT_SUCCESS : 4,
	SEF_CSF_EVENT_ACT_FAIL : 5,
	SEF_CSF_EVENT_DISCONNECT_SUCCESS : 6,
	SEF_CSF_EVENT_DISCONNECT_FAIL : 7,
	SEF_CSF_EVENT_REQUEST_LIST_EMPTY : 8,
	SEF_CSF_EVENT_REQUEST_DETAIL_EMPTY : 9,
	SEF_CSF_EVENT_ACT_PROGRESS_UPDATE : 10,
	
	//share
	SEF_CSF_EVENT_SHARE_DONE : 11,
	SEF_CSF_EVENT_SHARE_COMPLETE : 12,
	SEF_CSF_EVENT_SHARE_FAIL : 13,
	SEF_CSF_EVENT_SHARE_SOURCE_DEVICE_DISCONNECT : 14,
	SEF_CSF_EVENT_SHARE_DEST_DEVICE_DISCONNECT : 15,
	SEF_CSF_EVENT_SHARE_PVR_IS_RECORDING : 16,
	SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED : 17,
	SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED : 18,
	SEF_CSF_EVENT_SHARE_FILE_UPDATE : 19,
	
	//RA
	SEF_CSF_EVENT_RA_DEVICE_CONNECTED : 20,
	SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED : 21,
	
	//DLNA
	SEF_CSF_EVENT_DLNA_DEVICE_CONNECTED : 22,
	SEF_CSF_EVENT_DLNA_DEVICE_DISCONNECTED : 23,
	SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED : 24,
	SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED_ALL : 25,
	SEF_CSF_EVENT_PARTIAL_LIST_UPDATE : 26,
	
	CSF_EVENT_THUMBNAIL_FINISHED : 100,
	CSF_EVENT_THUMBNAIL_FAIL : 101,
	CSF_EVENT_THUMBNAIL_UNKNOW : 102
	
};

/**
 * @author sunjung.yoo@samsung.com
 * @fn _onCSFCallBackEvent
 * @description CSF Event Callback
 * @param          
 * @returns 
 */
 
function _onCSFCallBackEvent(eventType, param1, param2){
	Log.e("EVENT:[" + eventType + "].param1[" + param1 + "].param2[" + param2 + "] ") ;
	if (typeof CSFcbList[String(eventType)] == 'undefined') {
		return;
	}	
	var callbackFunc = null;
	
	if(isArray(CSFcbList[String(eventType)])){
		var callbacks = CSFcbList[String(eventType)];
		for(var i = 0; i < callbacks.length; i++){
			callbackFunc = callbacks[i];
			callbackFunc(param1, param2);	
		}
	}else{
		CSFcbList[String(eventType)](param1, param2);
	}
};

/**
 * @namespace CSF
 */
exports.CSF = {  
	m_bOpened : false,

	FOLDER_VIEW_FILE_TYPE_IMAGE : 0,
	FOLDER_VIEW_FILE_TYPE_VIDEO : 1,
	FOLDER_VIEW_FILE_TYPE_SOUND : 2,
	FOLDER_VIEW_FILE_TYPE_MUSIC : 3,
	FOLDER_VIEW_FILE_TYPE_FOLDER : 4,
	FOLDER_VIEW_FILE_TYPE_RECORDTV : 5,
	FOLDER_VIEW_FILE_TYPE_M3U : 6,
	FOLDER_VIEW_FILE_TYPE_AUDIO : 7,
	FOLDER_VIEW_FILE_TYPE_GROUP : 8,
	FOLDER_VIEW_FILE_TYPE_UHD : 9,
	FOLDER_VIEW_FILE_TYPE_SCSA : 10,

	init : function() {
		Log.e("[CSF]init start");
		this.csfLocalApiListInit();
		var check_local = sefFactory.init("Local");
		var check_csf = sefFactory.init("CsfThumbnail");
		Log.e("[CSF]check_local:"+check_local);
		Log.e("[CSF]check_csf:"+check_csf);
		
		sefFactory.getSEF("Local").onEventCallback = _onCSFCallBackEvent;
		sefFactory.getSEF("CsfThumbnail").onEventCallback = _onCSFCallBackEvent;
		
		if(true === check_local && true === check_csf)
		{
			this.m_bOpened = true;
			return this.m_bOpened;
		}
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[CSF]initAsync start");
		var completed_cb = 0;
		var check_local = false;
		var check_csf = false;
		this.csfLocalApiListInit();
		sefFactory.initAsync("Local", function(is_success){
			Log.e("[CSF]Local is_success:"+is_success);
			check_local = is_success;
			completed_cb++;
			Log.e("[CSF]Local completed_cb:"+completed_cb);
			if(2 === completed_cb)
			{
				if(true === check_local && true === check_csf)
				{
					exports.CSF.m_bOpened = true;
				}
				else
				{
					exports.CSF.m_bOpened = false;
				}
				OpenCallback(exports.CSF.m_bOpened);
			}
		});
		sefFactory.initAsync("CsfThumbnail", function(is_success){
			Log.e("[CSF]CsfThumbnail is_success:"+is_success);
			check_csf = is_success;
			completed_cb++;
			Log.e("[CSF]CsfThumbnail completed_cb:"+completed_cb);
			if(2 === completed_cb)
			{
				if(true === check_local && true === check_csf)
				{
					exports.CSF.m_bOpened = true;
				}
				else
				{
					exports.CSF.m_bOpened = false;
				}
				OpenCallback(exports.CSF.m_bOpened);
			}
		});
		
		sefFactory.getSEF("Local").onEventCallback = _onCSFCallBackEvent;
		sefFactory.getSEF("CsfThumbnail").onEventCallback = _onCSFCallBackEvent;
	},	
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("Local");
		sefFactory.releaseSEF("CsfThumbnail");
	},
	csfLocalApiListInit : function(){
		CSFLocalAPI["csfCancelRequestList"]="csf_cancel_request_list";
		CSFLocalAPI["csfSetNavigation"]="csf_set_navigation";
		CSFLocalAPI["csfMoveToIndex"]="csf_move_to_index";
		CSFLocalAPI["csfGetItemCount"]="csf_get_item_count";
		CSFLocalAPI["csfGetItemValueTime"]="csf_get_item_value_time";
		CSFLocalAPI["csfGetItemValueLint"]="csf_get_item_value_lint";
		CSFLocalAPI["csfGetItemValueChar"]="csf_get_item_value_char";
		CSFLocalAPI["csfGetItemValueInt"]="csf_get_item_value_int";
		CSFLocalAPI["csfGetItemValueBool"]="csf_get_item_value_bool";
		CSFLocalAPI["csfGetItemValueDouble"]="csf_get_item_value_double";
		CSFLocalAPI["csfSetItemValueTime"]="csf_set_item_value_time";
		CSFLocalAPI["csfSetItemValueInt"]="csf_set_item_value_int";
		CSFLocalAPI["csfSetItemValueChar"]="csf_set_item_value_char";
		CSFLocalAPI["csfGetPlayerIndex"]="csf_get_player_index";
		CSFLocalAPI["csfGetBrowseIndex"]="csf_get_browse_index";
		CSFLocalAPI["csfGetItemCountOfGroup"]="csf_get_item_count_of_group";
		CSFLocalAPI["csfAddFile"]="csf_add_file";
		CSFLocalAPI["csfDeleteFile"]="csf_delete_file";
		CSFLocalAPI["csfSelectAll"]="csf_select_all";
		CSFLocalAPI["csfDeselectAll"]="csf_deselect_all";
		CSFLocalAPI["csfDisconnect"]="csf_disconnect";
		CSFLocalAPI["csfGetSelectedState"]="csf_get_selected_state";
		CSFLocalAPI["csfGetSelectionCount"]="csf_get_selection_count";
		CSFLocalAPI["csfToggleSelect"]="csf_toggle_select";
		CSFLocalAPI["csfSetPageStyle"]="csf_set_page_style";
		CSFLocalAPI["csfPreparePlayData"]="csf_prepare_play_data";
		CSFLocalAPI["csfPlayListAddPlaylist"]="csf_playlist_add_playlist";
		CSFLocalAPI["csfPlaylistAddItem"]="csf_playlist_add_item";
		CSFLocalAPI["csfPlaylistRename"]="csf_playlist_rename";
		CSFLocalAPI["csfPlaylistDelete"]="csf_playlist_delete";
		CSFLocalAPI["csfPlaylistDeleteItem"]="csf_playlist_delete_item";
		CSFLocalAPI["csfGetVideoCodec"]="csf_get_video_codec";
		CSFLocalAPI["csfGetAudioCodec"]="csf_get_audio_codec";
		CSFLocalAPI["csfRequestList"]="csf_request_list";
		CSFLocalAPI["csfRequestPlayList"]="csf_request_play_list";
		CSFLocalAPI["csfRequestDetail"]="csf_request_detail";
		CSFLocalAPI["csfSetLike"]="csf_set_like";
		CSFLocalAPI["csfUploadComment"]="csf_upload_comment";
		CSFLocalAPI["csfCreateAlbum"]="csf_create_album";
		CSFLocalAPI["csfSend"]="csf_send";
		CSFLocalAPI["csfStopSend"]="csf_stop_send";
		CSFLocalAPI["csfCancelDetail"]="csf_cancel_detail";
		CSFLocalAPI["csfGetGroupCount"]="csf_get_group_count";
		CSFLocalAPI["csfGetDetailItemValueChar"]="csf_get_detail_item_value_char";
		CSFLocalAPI["csfGetDetailItemValueInt"]="csf_get_detail_item_value_int";
		CSFLocalAPI["csfGetDetailItemValueBool"]="csf_get_detail_item_value_bool";
		CSFLocalAPI["csfGetItem"]="csf_get_item";
		CSFLocalAPI["csfRaGetDeviceList"]="csf_ra_get_device_list";
		CSFLocalAPI["csfGetDlnaList"]="csf_get_dlna_list";
		CSFLocalAPI["csfSelectGroup"]="csf_select_group";
		CSFLocalAPI["csfSetExpandMode"]="csf_set_expand_mode";
		CSFLocalAPI["csfPlaylistGetPlaylistCount"]="csf_playlist_get_playlist_count";
		CSFLocalAPI["csfPlaylistGetPlaylist"]="csf_playlist_get_playlist";
		CSFLocalAPI["csfPlaylistGetItemCount"]="csf_playlist_get_item_count";
		CSFLocalAPI["csfPlaylistGetItem"]="csf_playlist_get_item";
		CSFLocalAPI["csfGetNavigation"]="csf_get_navigation";
		CSFLocalAPI["csfGetPageIndex"]="csf_get_page_index";
		CSFLocalAPI["csfGetItemList"]="csf_get_item_list";
		CSFLocalAPI["csfSetItemValue"]="csf_set_item_value";
		CSFLocalAPI["csfDeselectGroup"]="csf_deselect_group";
		CSFLocalAPI["csfGetRatingInfo"]="csf_get_rating_info";

	},
	// plug-in name : Local]
	csfLocalFunction : function(functionName, isReturnJson, option){		
		if(!this.m_bOpened) return false;
		if (typeof functionName != "string" || functionName == "undefined"){	           
			Log.e("--->> Player Open TYPE_MISMATCH_ERR");
			return false;
		}
		if(isReturnJson == "undefined"){
			Log.e("--->> isReturnJson undefined");
			isReturnJson = false;
		}
		if(option.param_input =="undefined"){
			if(isReturnJson)
				return JSON.parse(sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName]));
			else 
				return sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName]);
		}
		else{
			if(isReturnJson)
				return JSON.parse(sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName], JSON.stringify(optionparam_input)));
			else 
				return sefFactory.getSEF("Local").execute(CSFLocalAPI[functionName], JSON.stringify(option.param_input));
		}		
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfCancelRequestList
	 * @description Cancel the data request.
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfCancelRequestList : function(param_input) {
		Log.e(" --->> csfCancelRequestList();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_cancel_request_list", JSON.stringify(param_input));;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSetNavigation
	 * @description In player side, when in player view mode or going on
	 *              selected play, after request list, should called this
	 *              interface.
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfSetNavigation : function(param_input) {
		Log.e(" --->> csfSetNavigation();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_set_navigation", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfMoveToIndex
	 * @description Move focus to the assigned item
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfMoveToIndex : function(param_input) {
		Log.e(" --->> csfMoveToIndex();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_move_to_index", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetItemCount
	 * @description Get items� count when date request finished
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfGetItemCount : function(param_input) {
		Log.e(" --->> csfGetItemCount();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_item_count", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetItemCountOfGroup
	 * @description Get the items� cout of one group
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfGetItemCountOfGroup : function(param_input) {
		Log.e(" --->> csfGetItemCountOfGroup();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_item_count_of_group", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSelectAll
	 * @description Select all one type of media files in browser.
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfSelectAll : function(param_input) {
		Log.e(" --->> csfSelectAll();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_select_all", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfDeselectAll
	 * @description Deselected all items which were selected just now
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfDeselectAll : function(param_input) {
		Log.e(" --->> csfDeselectAll();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_deselect_all", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfDisconnect
	 * @description When the data requested was not used from now on, should
	 *              call this interface to release related recources
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfDisconnect : function(param_input) {
		Log.e(" --->> csfDisconnect();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_disconnect", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetSelectedState
	 * @description Decide if the item was selected
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfGetSelectedState : function(param_input) {
		Log.e(" --->> csfGetSelectedState();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_selected_state", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetSelectionCount
	 * @description Get the count how many items were selected
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	csfGetSelectionCount : function(param_input) {
		Log.e(" --->> csfGetSelectionCount();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_selection_count", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfToggleSelect
	 * @description Call this interface to select one item or unselect one item
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfToggleSelect : function(param_input) {
		Log.e(" --->> csfToggleSelect();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_toggle_select", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSetPageStyle
	 * @description This interface should be called first when request over, and
	 *              receive the message from csf
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfSetPageStyle : function(param_input) {
		Log.e(" --->> csfSetPageStyle();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_set_page_style", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPreparePlayData
	 * @description When you want to launch a player, you should call this
	 *              interface first
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	csfPreparePlayData : function(param_input) {
		Log.e(" --->> csfPreparePlayData();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_prepare_play_data", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlayListAddPlaylist
	 * @description Create a new playlist file.
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlayListAddPlaylist : function(param_input) {
		Log.e(" --->> csfPlayListAddPlaylist();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_add_playlist", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistAddItem
	 * @description Add one item to the exiting playlist file.
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistAddItem : function(param_input) {
		Log.e(" --->> csfPlaylistAddItem();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_add_item", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistRename
	 * @description Modify the name of playlist file.
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistRename : function(param_input) {
		Log.e(" --->> csfPlaylistRename();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_rename", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistDelete
	 * @description Delete a playlist file from usb disk
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistDelete : function(param_input) {
		Log.e(" --->> csfPlaylistDelete();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_delete", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistDeleteItem
	 * @description Delete one item from the existing playlist file.
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistDeleteItem : function(param_input) {
		Log.e(" --->> csfPlaylistDeleteItem();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_delete_item", JSON.stringify(param_input));
	},

	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfRequestList
	 * @description To set like/unlike to a specific item on web
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	csfRequestList : function(param_input) {
		//CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_LIST_SUCCESS] = successCallback;
		//CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_LIST_FAIL] = errorCallback;
		//CSFeventList[CSFState.CSF_EVENT_REQUEST_LIST_EMPTY] = errorCallback;
		Log.e(" --->> csfRequestList();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_request_list", JSON.stringify(param_input))); ;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfRequestDetail
	 * @description Request a specific item from web .
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	csfRequestDetail : function(param_input) {

		Log.e(" --->> csfRequestDetail();"+ param_input);
		//CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_DETAIL_SUCCESS] = successCallback;
		//CSFeventList[CSFState.SEF_CSF_EVENT_REQUEST_DETAIL_FAIL] = errorCallback;
		//CSFeventList[CSFState.CSF_EVENT_REQUEST_LIST_EMPTY] = errorCallback;
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_request_detail", JSON.stringify(param_input)));;
		
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSetLike
	 * @description To set like/unlike to a specific item on web
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	csfSetLike : function(param_input) {
		Log.e(" --->> csfSetLike();"+ param_input);
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;		
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_set_like", JSON.stringify(param_input)));;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfUploadComment
	 * @description To add comment to a specific item on web
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	csfUploadComment : function(param_input) {
		Log.e(" --->> csfUploadComment();"+ param_input);
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;	
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_upload_comment", JSON.stringify(param_input)));; 
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfCreateAlbum
	 * @description To create an album in facebook account
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfCreateAlbum : function(param_input) {
		Log.e(" --->> csfCreateAlbum();"+ param_input);
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;	
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_create_album", JSON.stringify(param_input));;
		
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSend
	 * @description To send file between usb & web<ra, webstorage, sns>,
	 *              lock/unlock pvr file, delete pvr file
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfSend : function(param_input) {
		Log.e(" --->> csfSend();"+ param_input);
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_SUCCESS] = successCallback;
		//CSFeventList[CSFState.SEF_CSF_EVENT_ACT_FAIL] = errorCallback;	
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_send", JSON.stringify(param_input));;
		
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfStopSend
	 * @description To stop send operation
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfStopSend : function(param_input) {
		Log.e(" --->> csfStopSend();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_stop_send", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfCancelDetail
	 * @description To cancel request detail operation
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfCancelDetail : function(param_input) {
		Log.e(" --->> csfCancelDetail();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_cancel_detail", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetGroupCount
	 * @description To get group count
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfGetGroupCount : function(param_input) {
		Log.e(" --->> csfGetGroupCount();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_group_count", JSON.stringify(param_input)));
	},

	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetItem
	 * @description Get item info which was focused
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfGetItem : function(param_input) {

		Log.e(" --->> csfGetItem();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_item", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfRaGetDeviceList
	 * @description get RA device list.
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfRaGetDeviceList : function() {

		Log.e(" --->> csfRaGetDeviceList();");
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_ra_get_device_list"));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetDlnaList
	 * @description Get dlan item list
	 * @param Json
	 *            String
	 * @returns Json Object
	 */
	csfGetDlnaList : function() {
		Log.e(" --->> csfGetDlnaList();");
		return JSON.parse(sefFactory.getSEF("Local").execute("csf_get_dlna_list"));;		
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSelectGroup
	 * @description Select all items of one group
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfSelectGroup : function(param_input) {

		Log.e(" --->> csfSelectGroup();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_select_group", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSetExpandMode
	 * @description Decide expand or pack up a group
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfSetExpandMode : function(param_input) {

		Log.e(" --->> csfSetExpandMode();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_set_expand_mode", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistGetPlaylistCount
	 * @description Get playlist count of a usb device
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistGetPlaylistCount : function(param_input) {

		Log.e(" --->> csfPlaylistGetPlaylistCount();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_get_playlist_count", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistGetPlaylist
	 * @description Get properties of a playlist file in a usb device
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistGetPlaylist : function(param_input) {

		Log.e(" --->> csfPlaylistGetPlaylist();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_get_playlist", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistGetItemCount
	 * @description Get count of songs in a playlist file
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistGetItemCount : function(param_input) {

		Log.e(" --->> csfPlaylistGetItemCount();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_get_item_count", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfPlaylistGetItem
	 * @description Get properties of a song in a playlist file
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfPlaylistGetItem : function(param_input) {

		Log.e(" --->> csfPlaylistGetItem();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_playlist_get_item", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetNavigation
	 * @description App can call this interface to know the state of navigation
	 * @param Json
	 *            String
	 * @returns Boolean
	 */
	csfGetNavigation : function(param_input) {

		Log.e(" --->> csfGetNavigation();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_get_navigation", JSON.stringify(param_input));
	},
	//2014/07/18? ??
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetPageIndex
	 * @description Get start index in player or focues index in browser
	 * @param Json String
	 * @returns 
	 */
	csfGetPageIndex : function(param_input) {

		Log.e(" --->> csfGetPageIndex();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_get_page_index", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetItemList
	 * @description Get all items� properties
	 * @param Json String
	 * @returns 
	 */
	csfGetItemList : function(param_input) {

		Log.e(" --->> csfGetItemList();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_get_item_list", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfSetItemValue
	 * @description Set item value in db
	 * @param Json String
	 * @returns 
	 */
	csfSetItemValue : function(param_input) {

		Log.e(" --->> csfSetItemValue();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_set_item_value", JSON.stringify(param_input));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfDeselectGroup
	 * @description Deselect all items of a group
	 * @param Json String
	 * @returns 
	 */
	csfDeselectGroup : function(param_input) {

		Log.e(" --->> csfDeselectGroup();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_deselect_group", JSON.stringify(param_input));
	},
	
	/**
	 * @author sumin_.park@samsung.com
	 * @fn csfGetItemValue
	 * @description Get item value in db
	 * @param Json String
	 * @returns 
	 */
	csfGetItemValue : function(param_input) {
		Log.e(" --->> csfGetItemValue();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_get_item_value", JSON.stringify(param_input));
	},

	/**
	 * @author jieun24.lee@samsung.com
	 * @fn csfGetRatingInfo
	 * @description Get rating information about UHD file
	 * @param Json String
	 * @returns 
	 */
	csfGetRatingInfo : function(param_input) {
		Log.e(" --->> csfGetRatingInfo();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_get_rating_info", JSON.stringify(param_input));
	},
	/**
	 * @author jieun24.lee@samsung.com
	 * @fn csfGetRatingInfo
	 * @description you can call this api before csf-request_list to do media file filter in showing
	 * @param Json String
	 * @returns 
	 */
	csfSetMediaExtensionFilter : function(param_input) {
		Log.e(" --->> csfSetMediaExtensionFilter();"+ param_input);
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return sefFactory.getSEF("Local").execute("csf_set_media_extension_filter", JSON.stringify(param_input));
	},
	
	// thumbnail
	/**
	 * @author sumin_.park@samsung.com
	 * @fn thumbnailRequestAsync
	 * @description
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	thumbnailRequestAsync : function(param_input) {
		//CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FINISHED] = successCallback;
		//CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FAIL] = errorCallback;		
		Log.e(" --->> thumbnailRequestAsync();");
//		try {
//			
//			result = JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_async", JSON.stringify(param_input)));
//		} catch (e) {
//			return 'Failed to handle the Execute call.';
//		}
		return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_async", JSON.stringify(param_input)));;	
		
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn thumbnailRequestHttpBufferAsync
	 * @description
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	thumbnailRequestHttpBufferAsync : function(param_input) {
		Log.e(" --->> thumbnailRequestHttpBufferAsync();");
		//CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FINISHED] = successCallback;
		//CSFeventList[CSFState.CSF_EVENT_THUMBNAIL_FAIL] = errorCallback;		
//		try {
//			
//			result = JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_http_buffer_async", JSON.stringify(param_input)));
//		} catch (e) {
//			return 'Failed to handle the Execute call.';
//		}
		return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_http_buffer_async", JSON.stringify(param_input)));	
	
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn thumbnailRequestCancelAll
	 * @description
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	thumbnailRequestCancelAll : function(param_input) {
		Log.e(" --->> thumbnailRequestCancelAll();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_request_cancel_all", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn thumbnailStopPtpDecodeSync
	 * @description
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	thumbnailStopPtpDecodeSync : function(param_input) {
		Log.e(" --->> thumbnailStopPtpDecodeSync();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_stop_ptp_decode_sync", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn thumbnailStopRaDecodeSync
	 * @description
	 * @param Json
	 *            String
	 * @returns Json Obejct
	 */
	thumbnailStopRaDecodeSync : function(param_input) {
		Log.e(" --->> thumbnailStopRaDecodeSync();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		return JSON.parse(sefFactory.getSEF("CsfThumbnail").execute("thumbnail_stop_ra_decode_sync", JSON.stringify(param_input)));
	},
	/**
	 * @author sunjung.yoo@samsung.com
	 * @fn addEventListener
	 * @description
	 * @param 
	 * @returns 
	 */
	addEventListener:function(eventType, cb){
		Log.e("---------------------------------------->> addEventListener");
		if (typeof CSFcbList[String(eventType)] == 'undefined') {
			CSFcbList[String(eventType)] = cb;
			return;
		}
		if (typeof CSFcbList[String(eventType)] == 'function' && !isArray(CSFcbList[String(eventType)])) {
			var tempCB = CSFcbList[String(eventType)];
			CSFcbList[String(eventType)] = [];
			CSFcbList[String(eventType)].push(tempCB);
			CSFcbList[String(eventType)].push(cb);
			return;
		}		
		if (isArray(CSFcbList[String(eventType)])) {
			CSFcbList[String(eventType)].push(cb);
		}
	} 
};

/**
 * @namespace audio
 */
exports.audio = {
	/** ** sound */
	SOUND_MUTE_ON : "1",
	/** ** sound */
	SOUND_MUTE_OFF : "0",
	/** ** sound */
	SOUND_USER_MUTE_ON : 1,
	/** ** sound */
	SOUND_USER_MUTE_OFF : 0,
	/** ** sound */
	SOUND_DOWN : "1",
	/** ** sound */
	SOUND_UP : "0",

	/** ** outmode */
	PL_AUDIO_AUDIO_OUT_MODE_PCM : 0,
	/** ** outmode */
	PL_AUDIO_AUDIO_OUT_MODE_DOLBY : 1,
	/** ** outmode */
	PL_AUDIO_AUDIO_OUT_MODE_DTS : 2,
	/** ** outmode */
	PL_AUDIO_OUTPUT_DEVICE_MAIN_SPEAKER : 0,
	/** ** outmode */
	PL_AUDIO_OUTPUT_DEVICE_EARPHONE : 1,
	/** ** outmode */
	PL_AUDIO_OUTPUT_DEVICE_SUBWOOFER : 2,
	/** ** outmode */
	PL_AUDIO_OUTPUT_DEVICE_EXTERNAL : 3,
	/** ** outmode */
	PL_AUDIO_OUTPUT_DEVICE_RECEIVER : 4,

	m_SEFAudio : null,
	m_bOpened : false,

	/**
	 * @fn Boolean init()
	 * @description Audio EMP ??? ??
	 * @returns {Boolean}
	 */
	init : function() {
		Log.e("[audio]init start");
		this.m_bOpened = sefFactory.init("Audio");
		Log.e("[audio]m_bOpened:"+this.m_bOpened);
		return this.m_bOpened;
	},
	/**
	 * @fn Boolean initAsync()
	 * @description Audio EMP ??? ??
	 * @returns {Boolean}
	 */	
	initAsync : function(OpenCallback) {
		Log.e("[audio]initAsync start");
		sefFactory.initAsync("Audio", function(is_success){
			Log.e("[audio]Audio is_success:"+is_success);
			exports.audio.m_bOpened = is_success;
			OpenCallback(exports.audio.m_bOpened);
		});
	},	
	/**
	 * @fn Boolean isOpened()
	 * @description Audio EMP? ??
	 * @returns {Boolean}
	 */
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("Audio");
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? ????? ????.
	 * @param enum
	 * @return String
	 */
	checkExternalOutMode : function() {
		Log.e(" --->> checkExternalOutMode();");
		return sefFactory.getSEF("Audio").execute("CheckExternalOutMode");
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? ????? ????.
	 * @return String
	 */
	getExternalOutMode : function() {
		Log.e(" --->> GetExternalOutMode();");
		return sefFactory.getSEF("Audio").execute("GetExternalOutMode");
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? ??? ??? ???.
	 * @return enum
	 */
	getMute : function() {
		Log.e(" --->> GetMute();");
		return sefFactory.getSEF("Audio").execute("GetMute");
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? ?? ????? ???.
	 * @return enum
	 */
	getOutputDevice : function() {
		Log.e(" --->> GetOutputDevice();");
		return sefFactory.getSEF("Audio").execute("GetOutputDevice");
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? ??? ??? ???.
	 * @return enum
	 */
	getUserMute : function() {
		Log.e(" --->> GetUserMute();");
		return sefFactory.getSEF("Audio").execute("GetUserMute");
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? ??? ???.
	 * @return number
	 */
	getVolume : function() {
		Log.e(" --->> GetVolume();");
		return sefFactory.getSEF("Audio").execute("GetVolume");
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? ??? ???? ?? ????.
	 * @param String
	 * @return enum
	 */
	setRelativeVolume : function(volume) {
		Log.e(" --->> SetRelativeVolume();");
		return sefFactory.getSEF("Audio").execute("SetRelativeVolume", String(volume));
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ??? ??? ????.
	 * @param enum
	 * @return boolean
	 */
	setUserMute : function(mute) {
		Log.e(" --->> SetUserMute();");
		return sefFactory.getSEF("Audio").execute("SetUserMute", String(mute));
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ??? ????.
	 * @param String
	 * @return enum
	 */
	setVolume : function(volume) {
		Log.e(" --->> SetVolume();");
		sefFactory.getSEF("Audio").execute("SetVolume", String(volume)); 
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? 1? ?? ???.
	 */
	volumeUp : function() {
		Log.e(" --->> volumeUp();");
		sefFactory.getSEF("Audio").execute("SetVolumeWithKey", this.SOUND_UP);
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ?? 1? ?? ???.
	 */
	volumeDown : function() {
		Log.e(" --->> volumeDown();");
		sefFactory.getSEF("Audio").execute("SetVolumeWithKey", this.SOUND_DOWN);
	},

	/**
	 * @author yj14.lee@samsung.com
	 * @description ??? ????.
	 * @return String
	 */
	getVersion : function() {
		Log.e(" --->> getVersion();");
		return sefFactory.getSEF("Audio").execute("GetVersion");
	}
};

/**
 * @namespace WAS
 */
exports.AUI = {
		/** ** sound_type */
		AUDIO_SOUND_TYPE_UP : 1,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_DOWN : 2,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_LEFT : 3,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_RIGHT : 4,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_PAGE_LEFT : 5,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_PAGE_RIGHT : 6,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_BACK : 7,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_SELECT : 8,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_CANCEL : 9,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_WARNING : 10,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_KEYPAD : 11,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_KEYPAD_ENTER : 12,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_KEYPAD_DEL : 13,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_SMARTCONTROL_MOVE : 14,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_SMARTCONTROL_SELECT : 15,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_MOVE : 16,
		/** ** sound_type */
		AUDIO_SOUND_TYPE_PREPARING : 17,

		m_SEFAudio : null,
		m_bOpened : false,

		/**
		 * @fn Boolean init()
		 * @description AUI EMP ??? ??
		 * @returns {Boolean}
		 */
		init : function() {
			Log.e("[AUI]init start");
			this.m_bOpened = sefFactory.init("AUI");
			Log.e("[AUI]m_bOpened:"+this.m_bOpened);
			return this.m_bOpened;
		},
		/**
		 * @fn Boolean initAsync()
		 * @description AUI EMP ??? ??
		 * @returns {Boolean}
		 */
		initAsync : function(OpenCallback) {
			Log.e("[AUI]initAsync start");
			sefFactory.initAsync("AUI", function(is_success){
				Log.e("[AUI]AUI is_success:"+is_success);
				exports.AUI.m_bOpened = is_success;
				OpenCallback(exports.AUI.m_bOpened);
			});
		},		
		/**
		 * @fn Boolean isOpened()
		 * @description AUI EMP? open?? ??
		 * @returns {Boolean}
		 */
		isOpened : function() {
			return this.m_bOpened;
		},
		destroy : function() {
			Log.e(" --->> destroy();");
			sefFactory.releaseSEF("Audio");
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? ???? play??.
		 * @param enum
		 */
		playAudio : function(soundType) {
			Log.e(" --->> playSound();");
			sefFactory.getSEF("AUI").execute("PlayAudio", String(soundType));
		}
}

/**
 * @namespace WAS
 */
exports.WAS = {

		WAS_EVENT_DOWNLOADING :	100,
		WAS_EVENT_DOWNLOAD_COMPLETED : 	101,
		WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST : 	102,
		WAS_EVENT_DOWNLOAD_FAIL_NOSPACE : 	103,
		WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR : 	104,
		WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR : 	105,
		WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR : 	106,
		WAS_EVENT_DOWNLOAD_FAIL_OTHERS : 	107,
		//install		
		WAS_EVENT_INSTALLING :  	200,
		WAS_EVENT_INSTALL_CANCLE_COMPLETED : 	201,
		WAS_EVENT_INSTALL_CANCLE_FAILED : 	202,
		WAS_EVENT_INSTALL_COMPLETED : 	203,
		WAS_EVENT_INSTALL_FAIL_EXIST : 	204,
		WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR : 	205,
		WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR : 	206,
		WAS_EVENT_INSTALL_FAIL_OTHERS : 	207,
		WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE : 208,
		//uninstall		
		WAS_EVENT_UNINSTALLING : 	300,
		WAS_EVENT_UNINSTALL_COMPLETED : 	301,
		WAS_EVENT_UNINSTALL_FAIL_NOT_EXIST : 	302,
		WAS_EVENT_UNINSTALL_FAIL_PKGMGR_ERROR : 	303,
		WAS_EVENT_UNINSTALL_FAIL_NOT_REMOVABLE : 	304,
		WAS_EVENT_UNINSTALL_FAIL_OTHERS : 	305,
		//apps sync		
		WAS_EVENT_APPS_SYNC_COMPLETED :  	400,
		WAS_EVENT_APPS_SYNC_FAIL_NETWORK_ERROR : 	401,
		WAS_EVNET_APPS_SYNC_FAIL_OTHERS : 	402,
		//emp monitor		
		WAS_EVENT_EMP_MONITOR_INSTALL :  	500,
		WAS_EVENT_EMP_MONITOR_UNINSTALL : 	501,
		WAS_EVENT_EMP_MONITOR_UPDATE : 	502,
		// launcher		
		WAS_EVENT_LAUNCHER_LAUNCH_START		: 600,
		WAS_EVENT_LAUNCHER_LAUNCH 			: 601,
		WAS_EVENT_LAUNCHER_SHOW 			: 602,
		WAS_EVENT_LAUNCHER_TERMINATE 		: 603,
		WAS_EVENT_LAUNCHER_FAIL_NOT_EXIST 	: 604,
		WAS_EVENT_LAUNCHER_FAIL_TIMEOUT 	: 605,
		WAS_EVENT_LAUNCHER_FAIL_EMP 		: 606,
		WAS_EVENT_LAUNCHER_FAIL_SMARTHUB 	: 607,
		WAS_EVENT_LAUNCHER_FAIL_CAPH_APP 	: 608,
		WAS_EVENT_LAUNCHER_FAIL_NETWORK 	: 609,
		WAS_EVENT_LAUNCHER_FAIL_OTHERS 		: 610,
		WAS_EVENT_LAUNCHER_FAIL_MLS 		: 611,

		WAS_DEFAULT       	: 1000,

		WAS_APPS_SYNC       : 2000,	//TODO deprecated.
		WAS_APPS_LIST       : 2000,
		WAS_REQUEST_APP_LIST: 2001,
		
		
		WAS_SSO_REQUEST_ACCESS_TOKEN  : 3000,
		WAS_SSO_STATE_CHANGE : 3001,
		WAS_SSO_SHOW_POPUP : 3002,

		WAS_AD_START       : 4000,
		WAS_AD_PLAY   : 4001,

////////////////////////////////////////////////////// Delete
		WAS_RETURN_FALSE : -1,
		WAS_CALLBACK_ERROR :-2,
		WAS_INVALID_ARG  :-3,
		WAS_DISCONNECT  : -4,
//////////////////////////////////////////////////////
		WAS_TRUE                    :    0,
		WAS_FALSE                   :   -1,
		WAS_FALSE_DBUS_CREATE_ERROR :   -2,
		WAS_RESULT_IPC_DISCONNECTED :   -1,
		
		WAS_APPS_PANEL : 0,
		WAS_ONTV : 1,
		WAS_MT : 2,
		

		APPS_TYPE_WIDGET 				: 1,
		APPS_TYPE_TIZEN_WEB_APP 		: 2,
		APPS_TYPE_TIZEN_NATIVE_APP 		: 4,
		APPS_TYPE_TIZEN_NETFLIX_APP 	: 8,
		APPS_TYPE_TIZEN_GPLAYER_APP	 	: 16,
		APPS_TYPE_TIZEN_RACH_APP 		: 32,
		APPS_TYPE_TIZEN_SDK_APP 		: 64,
		APPS_TYPE_ALL 					: 65535,
		APPS_INFO_PREMIUM_GAME_FALSE 	: 1,
		APPS_INFO_PREMIUM_GAME_TRUE 	: 2,
		APPS_INFO_PREMIUM_GAME_ALL 		: 65535,
		APPS_INFO_FEATURED_MYAPP 		: 1,
		APPS_INFO_FEATURED_RECOMMONDED 	: 2,
		APPS_INFO_FEATURED_ALL 			: 65535,
		
		
		VIEWMODE_MOSTLYPLAYED	:	0,
		VIEWMODE_CUSTOM	:	1,

		SSO_LOGIN_POPUP_E	:	0	,
		SSO_LINK_POPUP_E	:	1	,
		SSO_CREATEACCOUNT_POPUP_E	:	2	,
		SSO_LOGOUT_POPUP_E	:	3	,
		SSO_SETTING_POPUP_E	:	4	,
		SSO_REMOVE_POPUP_E	:	5	,
		SSO_SERVICE_PART_POPUP_E	:	6	,
		SSO_CREATEACCOUNT_FACEBOOK_POPUP_E	:	7	,
		SSO_ITEM_POPUP_E	:	8	,
		SSO_PRIVACY_POPUP_E	:	9	,

		
		WAS_LIST_TYPE_APP_UPDATE_LIST : 0,

		WAS_APPS_SYNC_STATE_INIT : 10,
		WAS_APPS_SYNC_STATE_START : 11,
        WAS_APPS_SYNC_STATE_UNINSTALL_COMPLETED : 12,
        WAS_APPS_SYNC_INSTALL_COMPLETED : 13,
        WAS_APPS_SYNC_COMPLETED : 14,

		
		m_bOpened: false,
		/**
		 * @fn Boolean init()
		 * @description WAS EMP ??? ??
		 * @returns {Boolean}
		 */
		init:function(reopenCallback){
			Log.e("[WAS]init start");
			this.m_bOpened = sefFactory.init("WAS");
			Log.e("[WAS]m_bOpened:"+this.m_bOpened);
			sefFactory.getSEF("WAS").onEventCallback = WASCallback;
			empReopenCallback = reopenCallback;
			return this.m_bOpened;
		},
		/**
		 * @fn Boolean initAsync()
		 * @description WAS EMP ??? ??
		 * @returns {Boolean}
		 */
		initAsync:function(OpenCallback, reopenCallback){
			Log.e("[WAS]initAsync start");
			sefFactory.initAsync("WAS", function(is_success){
				Log.e("[WAS]WAS is_success:"+is_success);
				exports.WAS.m_bOpened = is_success;
				OpenCallback(exports.WAS.m_bOpened);
			});
			sefFactory.getSEF("WAS").onEventCallback = WASCallback;
			empReopenCallback = reopenCallback;
		},		
		isOpened:function(){
			return this.m_bOpened;
		},
		destroy:function(){
			Log.e(" ------------------------->> destroy();");
			sefFactory.releaseSEF("WAS");
			this.m_bOpened = false;
		},
		
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App Info? ????.
		 * @param app_id -
		 *            String
		 * @returns Json Object
		 */
		getAppInfo:function(app_id){	
			Log.e(" ------------------------->> GetAppInfo();"+ String(app_id));
			return retryWASFunction(function(){return JSON.parse(sefFactory.getSEF("WAS").execute("GetAppInfo", String(app_id)))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ????.
		 * @param app_id -
		 *            String
		 * @returns boolean
		 */
		installApp:function(app_id, packet_path, install_path){
			Log.e(" ------------------------->> installApp();"+ String(app_id));
			var path = String(install_path).replace("$USB_DIR", "/opt/storage/usb/");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("InstallApp", String(app_id), String(packet_path), path)});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App ??? ????.
		 * @param app_id -
		 *            String
		 * @returns boolean
		 */
		cancelInstallApp:function(app_id){
			Log.e(" ------------------------->> CancelInstallApp();"+ app_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("CancelInstallApp", String(app_id))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App? ????.
		 * @param app_id -
		 *            String
		 * @returns boolean
		 */
		unInstallApp:function(app_id){
			Log.e(" ------------------------->> UnInstallApp();"+ app_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("UnInstallApp", String(app_id))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App? ??????.
		 * @param app_id -
		 *            String
		 * @returns boolean
		 */
		updateApp:function(app_id){
			Log.e(" ------------------------->> UpdateApp();"+ app_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("UpdateApp", String(app_id))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description APP? ????.
		 * @param app_id -
		 *            String
		 * @param payload -
		 *            String
		 * @param caller_id -
		 *            String
		 * @returns json
		 */
		launchApp:function(app_id, payload, caller_id){
			Log.e(" ------------------------->> LaunchApp();"+app_id+","+payload+","+caller_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("LaunchApp", String(app_id), String(payload), String(caller_id))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description APP? ????.
		 * @param app_id -
		 *            String
		 * @param payload -
		 *            String
		 * @returns json
		 */
		forceLaunchApp:function(app_id, payload){
			Log.e(" ------------------------->> ForceLaunchApp();"+app_id+","+payload);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("ForceLaunchApp", String(app_id), String(payload))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App? ????.
		 * @param app_id -
		 *            String
		 * @returns boolean
		 */
		terminateApp:function(app_id){
			Log.e(" ------------------------->> TerminateApp();"+ app_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("TerminateApp", String(app_id))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App Sync ??? ????.
		 * @returns boolean
		 */
		checkListSyncStatus:function(){
			Log.e(" ------------------------->> CheckListSyncStatus();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("CheckListSyncStatus")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App? ????.
		 * @param type -
		 *            enum
		 * @param state -
		 *            enum
		 * @param category -
		 *            enum
		 * @returns number
		 */
		getAppCount:function(app_type, state, category){
			Log.e(" ------------------------->> GetAppCount();"+ app_type+","+state+","+category);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetAppCount", String(app_type), String(state), String(category))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App List? ????.
		 * @param type -
		 *            enum,
		 * @param state -
		 *            enum,
		 * @param category -
		 *            enum,
		 * @param viewMode -
		 *            enum,
		 * @param index -
		 *            number,
		 * @param count -
		 *            number
		 * @returns number
		 */
		getAppList:function(appType, state, category, viewMode, index, count){	
			Log.e(" ------------------------->> GetAppList();"+ String(appType)+","+String(state)+","+String(category)+","+String(viewMode)+","+String(index)+","+String(count));
			return retryWASFunction(function(){return JSON.parse(sefFactory.getSEF("WAS").execute("GetAppList", String(appType), String(state), String(category), String(viewMode), String(index), String(count)))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App Sync ??? ????.
		 * @param enum
		 * @returns number
		 */
		setListSyncStatus:function(status){
			Log.e(" ------------------------->> SetListSyncStatus();"+ String(status));
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("SetListSyncStatus", String(status))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App? ????.
		 * @param app_id -
		 *            String
		 * @returns boolean
		 */
		showApp:function(app_id){
			Log.e(" ------------------------->> ShowApp();"+ app_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("ShowApp", String(app_id))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App Info? was_app_info_item_e ??? ????.
		 * @param app_id -
		 *            String,
		 * @param app_item -
		 *            enum
		 * @returns number
		 */
		getAppInfoIntParameter:function(app_id, app_item){
			Log.e(" ------------------------->> GetAppInfoIntParameter();"+ app_id+","+app_item);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetAppInfoIntParameter", String(app_id), String(app_item))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description App Info? was_app_info_item_e ??? ????.
		 * @param app_id -
		 *            String
		 * @param app_item -
		 *            enum
		 * @param value -
		 *            number
		 * @returns boolean
		 */
		setAppInfoIntParameter:function(app_id, app_item, value){
			Log.e(" ------------------------->> SetAppInfoIntParameter();"+ app_id+","+app_item+","+value);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("SetAppInfoIntParameter", String(app_id), String(app_item), String(value))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? was_app_type_s? App ??? ????.
		 * @param app_type -
		 *            enum
		 * @param state -
		 *            enum
		 * @param category -
		 *            number
		 * @returns boolean
		 */
		requestAppCount:function(app_type, state, category){
			Log.e(" ------------------------->> RequestAppCount();"+ app_type+","+state+","+category);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("RequestAppCount", String(app_type), String(state), String(category))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Debug Info? ????.
		 * @returns Json Object
		 */
		getDebugInfo:function(){
			Log.e(" ------------------------->> GetDebugInfo();");
			return retryWASFunction(function(){return JSON.parse(sefFactory.getSEF("WAS").execute("GetDebugInfo"))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description app_id, packet_path, type? ??? App? ????.
		 * @param app_id -
		 *            String
		 * @param app_type -
		 *            enum
		 * @returns boolean
		 */
		installAppWithType:function(app_id, app_type){
			Log.e(" ------------------------->> InstallAppWithType();"+ String(app_id)+","+String(app_type));
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("InstallAppWithType", String(app_id), String(app_type))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description My Apps? ?? app_id? ??? ????.
		 * @param app_id -
		 *            String
		 * @param distance -
		 *            String
		 * @returns boolean
		 */
		moveApp:function(app_id, distance){
			Log.e(" ------------------------->> MoveApp();"+ app_id+","+distance);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("MoveApp", String(app_id), String(distance))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ???? ?? ??? ???.
		 * @returns 0 = AUTO_UPDATED, 1 = NOT_AUTO_UPDATED
		 */
		checkAutoUpdateState:function(){
			Log.e(" ------------------------->> checkAutoUpdateState();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("CheckAutoUpdateState")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? hide??.
		 * @param app_id -
		 *            String
		 * @returns boolean
		 */
		hideApp:function(app_id){
			Log.e(" ------------------------->> HideApp();"+ app_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("HideApp", String(app_id))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ?? ??? ???.
		 * @param app_id -
		 *            String
		 * @returns 0 = STOPPED, 1 = RUNNING
		 */
		getAppStatus:function(app_id){
			Log.e(" ------------------------->> getAppStatus();"+ app_id);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetAppStatus", String(app_id))});
		},
		
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description DUID? ????.
		 * @returns String
		 */
		getDuid:function(){
			Log.e(" ------------------------->> getDuid();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetDuid")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Token? ????.
		 * @returns String
		 */
		getToken:function(){
			Log.e(" ------------------------->> getToken();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetToken")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Infolink Version? ????.
		 * @returns String
		 */
		getInfolinkVer:function(){
			Log.e(" ------------------------->> getInfolinkVer();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetInfolinkVer")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Country Code? ????.
		 * @returns String
		 */
		getCountryCode:function(){
			Log.e(" ------------------------->> getCountryCode();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetCountryCode")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description AToken? ????.
		 * @returns Json Object
		 */
		getAToken:function(){
			Log.e(" ------------------------->> getAToken();");
			return retryWASFunction(function(){return JSON.parse(sefFactory.getSEF("WAS").execute("GetAtoken"))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Model Code? ????.
		 * @returns String
		 */
		getModelCode:function(){
			Log.e(" ------------------------->> getModelCode();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetModelCode")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description
		 * @returns String
		 */
		registerAtokenChangedCallback:function(){
			Log.e(" ------------------------->> registerAtokenChangedCallback();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("RegisterAtokenChangedCallback")});
		},
		
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description SSO AccessToken? ????.
		 * @param app_id -
		 *            String
		 * @param secret_key -
		 *            String
		 * @returns boolean
		 */
		requestSSOAccessToken:function(app_id, secret_key){
			Log.e(" ------------------------->> RequestSSOAccessToken();"+ app_id+","+secret_key);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("RequestSSOAccessToken", String(app_id), String(secret_key))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description SSO ?? ??? ????? ??? cb? ????.
		 * @returns boolean
		 */
		subscribeSSOStateChange:function(){
			Log.e(" ------------------------->> SubscribeSSOStateChange();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("SubscribeSSOStateChange")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description SSO login state? ????.
		 * @returns 0 = NOT_LOGIN_SSO = 0, 1 = LOGIN_SSO
		 */
		getSSOLoginState:function(){
			Log.e(" ------------------------->> GetSSOLoginState();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOLoginState")});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description SSO login info? ????.
		 * @returns Json Object
		 */
		getSSOLoginInfo:function(){
			Log.e(" ------------------------->> GetSSOLoginInfo();");
			return retryWASFunction(function(){return JSON.parse(sefFactory.getSEF("WAS").execute("GetSSOLoginInfo"))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description SSO ??? ???? cb? ?? caller?? ?? ??? nodify ??.
		 * @param type -
		 *            enum
		 * @param payload -
		 *            String
		 * @returns boolean
		 */
		startSSOPopup:function(type, payload){
			Log.e(" ------------------------->> StartSSOPopup();"+ type+","+payload);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("StartSSOPopup", String(type), String(payload))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description SSO? app account? link ?? ??? ????.
		 * @param cp_name -
		 *            String
		 * @returns boolean
		 */
		isLinkedApp:function(cp_name){
			Log.e(" ------------------------->> IsLinkedApp();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("IsLinkedApp", String(cp_name))});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description SSO GUID? ????.
		 * @returns String
		 */
		getGuid:function(){
			Log.e(" ------------------------->> GetGuid();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetGuid")});
		},
		
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description AD ??? ?? ???? ???? cb? ?? ?? ???? ?? ???.
		 * @param enum
		 * @returns boolean
		 */
		startAD:function(paneltype){
			Log.e(" ------------------------->> StartAD();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("StartAD", paneltype)});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description AD ??? ?? ??? ??? stop??.
		 * @param enum
		 * @returns boolean
		 */
		stopAD:function(paneltype){
			Log.e(" ------------------------->> StopAD();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("StopAD", paneltype)});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ??? ?? AdHub? Call??.
		 * @returns boolean
		 */
		playAD:function(paneltype, filename){
			Log.e(" ------------------------->> PlayAD();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("PlayAD", paneltype, filename)});
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? ?? ??? ?????? AD ??? notify??.
		 * @param filename -
		 *            enum
		 * @returns boolean
		 */
		notifyADServer:function(paneltype, filename){
			Log.e(" ------------------------->> NotifyADServer();"+  filename);
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("NotifyADServer", paneltype, filename)});
		},
		
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description This is a Sync interface. This function is provided for
		 *              all modules to get the information of Memory usage.
		 * @returns string
		 */
		getMemory:function(){
			Log.e(" ------------------------->> GetMemory();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetMemory")});
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description 
		 * @param void
		 * @returns string
		 */
		coMSSGetInfo:function(strKey){
			Log.e(" ------------------------->> CoMSSGetInfo();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("CoMSSGetInfo", String(strKey))});
		},

		appsSync : function(){
			Log.e(" ------------------------->> appsSync();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("AppsSync")});
		},
		getSSOAppAccountInfoList : function(){
			Log.e(" ------------------------->> GetSSOAppAccountInfoList();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOAppAccountInfoList")});
		},
		getSSOLoginInfoString : function(){
			Log.e(" ------------------------->> GetSSOLoginInfoString();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOLoginInfoString")});
		},
		getSSOToken : function(){
			Log.e(" ------------------------->> GetSSOToken();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOToken")});
		},
		getSSOAccountInfo : function(cp_name){
			Log.e(" ------------------------->> GetSSOAccountInfo();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOAccountInfo", cp_name)});
		},
		getSSOAccountInfoWithoutLogin : function(cp_name){
			Log.e(" ------------------------->> GetSSOAccountInfoWithoutLogin();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOAccountInfoWithoutLogin", cp_name)});
		},
		stopSSOPopup : function(){
			Log.e(" ------------------------->> StopSSOPopup();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("StopSSOPopup")});
		},
		readSSOAccountInfo : function(){
			Log.e(" ------------------------->> ReadSSOAccountInfo();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("ReadSSOAccountInfo")});
		},
		getSSOCPInfo : function(cp_name){
			Log.e(" ------------------------->> GetSSOCPInfo();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOCPInfo", cp_name)});
		},
		getSSOUnboundAppList : function(){
			Log.e(" ------------------------->> GetSSOUnboundAppList();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOUnboundAppList")});
		},
		setAppRating : function(app_id, ratng){
			Log.e(" ------------------------->> SetAppRating();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("SetAppRating", String(app_id), String(ratng))});
		},
		getAppRating : function(app_id){
			Log.e(" ------------------------->> GetAppRating();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetAppRating", String(app_id))});
		},
		getHistoryAppList : function(count){
			Log.e(" ------------------------->> GetHistoryAppList();");
			return retryWASFunction(function(){return JSON.parse(sefFactory.getSEF("WAS").execute("GetHistoryAppList", String(count)))});
		},
		removeAppHistory : function(app_id){
			Log.e(" ------------------------->> RemoveAppHistory();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("RemoveAppHistory", String(app_id))});
		},
		removeAllAppHistory : function(){
			Log.e(" ------------------------->> RemoveAllAppHistory();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("RemoveAllAppHistory")});
		},
		getAppMultiList:function(appType, premium, count){	
			Log.e(" ------------------------->> GetAppMultiList();"+ String(appType)+","+String(premium)+","+String(count));
			return retryWASFunction(function(){return JSON.parse(sefFactory.getSEF("WAS").execute("GetAppMultiList", String(appType), String(premium), String(count)))});
		},
		requestAppList : function(list_type){
			Log.e(" ------------------------->> RequestAppList();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("RequestAppList", String(list_type))});
		},
		setAppLock : function(appid, p){
			Log.e(" ------------------------->> SetAppLock();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("SetAppLock", String(appid), String(p))});
		},
		getSSOTermStatus : function(term_id){
			Log.e(" ------------------------->> GetSSOTermStatus();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOTermStatus", term_id)});
		},
		showSSOPopup : function(payload){
			Log.e("------------------------->> ShowSSOPopup();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("ShowSSOPopup", String(payload))});		
		},

		getAppsSyncState : function(){
			Log.e(" ------------------------->> GetAppsSyncState();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetAppsSyncState")});
		},
		
		moveAppInfo : function(caller_id, callee_id){
			Log.e(" ------------------------->> MoveAppInfo();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("MoveAppInfo", String(caller_id), String(callee_id))});
		},
		
		activateWithData : function(nType, strData, fromApp, strFromWidget, strWidgetData){
			Log.e(" ------------------------->> ActivateWithData();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("ActivateWithData",  String(nType), String(strData), String(fromApp), String(strFromWidget), String(strWidgetData))});
		},
		
		getRecentlyUsedAppList : function(count){
			Log.e(" ------------------------->> GetRecentlyUsedAppList();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetRecentlyUsedAppList", String(count))});
		},
		
		checkUsbApp : function(appID){
			Log.e(" ------------------------->> CheckUsbApp();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("CheckUsbApp", String(appID))});
		},
		
		getTickerAppList : function(nCunt){
			Log.e(" ------------------------->> GetTickerAppList();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetTickerAppList", String(nCunt))});
		},
		
		getSSOPopupState : function(){
			Log.e(" ------------------------->> GetSSOPopupState();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetSSOPopupState")});
		},
		
		getLoginUID : function(){
			Log.e(" ------------------------->> GetLoginUID();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetLoginUID")});
		},
		
		getLoginStatus : function(){
			Log.e(" ------------------------->> GetLoginStatus();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("GetLoginStatus")});
		},
		
		mutilUnInstallApps : function(appids){
			Log.e(" ------------------------->> MutilUnInstallApps();");
			return retryWASFunction(function(){return sefFactory.getSEF("WAS").execute("MutilUnInstallApps", JSON.stringify(appids))});
		},
		
		addEventListener:function(eventType, cb){
			Log.e("---------------------------------------->> addEventListener");
			WAScbList[String(eventType)] = cb;
		},
		
		setAllEventListener:function(cb){
			WASAllcb = cb;
		}
};

var WAScbList = {};
var WASAllcb;
var D_BUS_ERROR = "-4";
var empReopenCallback ;

function WASException(message) {
	this.message = message;
	this.name = "WASException";
}

WASException.prototype.toString = function() {
	var name = this.name || 'unknown';
	var message = this.message || 'no description';
	return '[' + name + '] ' + message;
};

function WASCallback(eventType, param1, param2)
{
	Log.e("EVENT:[" + eventType + "].param1[" + param1 + "].param2[" + param2 + "] ") ;
	if (typeof WAScbList[String(eventType)] == "function")
		WAScbList[String(eventType)](eventType, param1, param2);
	if (typeof WASAllcb == "function")
		WASAllcb(eventType, param1, param2);
}

function retryWASFunction(retryFunction){
	var result = retryFunction();
	if(result == D_BUS_ERROR){	
		Log.e(" ------------------------->> [[ D_BUS_ERROR ]]");
		retryWASinit();
		result = retryFunction();
		if(result == D_BUS_ERROR){
			Volt.setTimeout(function() {
				retryWASinit();
			}, 10*1000);
		}
	}
	return result;
}

function retryWASinit(){
	exports.WAS.destroy();
	var opened = exports.WAS.init();
	if(typeof empReopenCallback == "function")
		empReopenCallback(opened);
}

exports.onTV = {
		m_bOpened: false,
		
		/**
		 * @author yj14.lee@samsung.com
		 * @fn Boolean init()
		 * @description Slive EMP ??? ??
		 * @returns {Boolean}
		 */
		init:function(){
			Log.e("[onTV]init start");
			var check_slive = sefFactory.init("Slive");
			Log.e("[onTV]check_slive:"+check_slive);
			
			if(true === check_slive)
			{
				this.m_bOpened = true;
				return this.m_bOpened;
			}
			return this.m_bOpened;
		},
		/**
		 * @author sunjung.yoo@samsung.com
		 * @fn Boolean initAsync()
		 * @description Slive EMP ??? ??
		 * @returns {Boolean}
		 */
		initAsync:function(OpenCallback){
			Log.e("[onTV]initAsync start");
			var check_slive = false;
			sefFactory.initAsync("Slive", function(is_success){
				Log.e("[onTV]Slive is_success:"+is_success);
				check_slive = is_success;
				if(true === check_slive)
				{
					exports.onTV.m_bOpened = true;
				}
				else
				{
					exports.onTV.m_bOpened = false;
				}
				OpenCallback(exports.onTV.m_bOpened);
			});
		},
		isOpened:function(){
			return this.m_bOpened;
		},
		destroy:function(){
			Log.e(" ------------------------->> destroy();");
			sefFactory.releaseSEF("Slive");
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description OnTV ???? ?? Rating protection rule? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getCertRule:function(input_param){
			Log.e(" ------------------------->> GetCertRule();");
			var result = sefFactory.getSEF("Slive").execute("GetCertRule", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? ??? ??? ??? ??.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getRemoteContentEnv:function(input_param){
			Log.e(" ------------------------->> GetRemoteContentEnv();");
			var result = sefFactory.getSEF("Slive").execute("GetRemoteContentEnv", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? ??? ????.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		setRemoteContentEnv:function(input_param){
			Log.e(" ------------------------->> SetRemoteContentEnv();");
			var result = sefFactory.getSEF("Slive").execute("SetRemoteContentEnv", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? MSO ??? ??? ??.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getRemoteContentConfig:function(input_param){
			Log.e(" ------------------------->> GetRemoteContentConfig();");	
			var result = sefFactory.getSEF("Slive").execute("GetRemoteContentConfig", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description MSO? ?? ??.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		setRemoteContentConfig:function(input_param){
			Log.e(" ------------------------->> SetRemoteContentConfig();");
			var result = sefFactory.getSEF("Slive").execute("SetRemoteContentConfig", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Activity ID? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getRemoteContentActivityByTVSourceAndTVMode:function(input_param){
			Log.e(" ------------------------->> GetRemoteContentActivityByTVSourceAndTVMode();");
			var result = sefFactory.getSEF("Slive").execute("GetRemoteContentActivityByTVSourceAndTVMode", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ??? ?? ??? ????.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		setRecommendTypeOption:function(in_recommend_type){
			Log.e(" ------------------------->> SetRecommendTypeOption();");
			var result = sefFactory.getSEF("Slive").execute("SetRecommendTypeOption", JSON.stringify(in_recommend_type));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? ???? ?? ??.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		activateSmartPersonal:function(input_param){
			Log.e(" ------------------------->> ActivateSmartPersonal();");
			var result = sefFactory.getSEF("Slive").execute("ActivateSmartPersonal", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description VOD Provider List? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getVODProviders:function(activityID){
			Log.e(" ------------------------->> GetVODProviders();");
			var result = sefFactory.getSEF("Slive").execute("GetVODProviders", JSON.stringify(activityID));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ???? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getGenreList:function(activityID){
			Log.e(" ------------------------->> GetGenreList();");
			var result = sefFactory.getSEF("Slive").execute("GetGenreList", JSON.stringify(activityID));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description RecGroup? ????.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getRecGroupMap:function(activityID){
			Log.e(" ------------------------->> GetRecGroupMap();");
			var result = sefFactory.getSEF("Slive").execute("GetRecGroupMap", JSON.stringify(activityID));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Rep Genre List? ????.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getRepGenreList:function(activityID){
			Log.e(" ------------------------->> GetRepGenreList();");
			var result = sefFactory.getSEF("Slive").execute("GetRepGenreList", JSON.stringify(activityID));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description OnNow???? ????.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getRecommendationOnNow:function(input_param){
			Log.e(" ------------------------->> GetRecommendationOnNow();");
			var result = sefFactory.getSEF("Slive").execute("GetRecommendationOnNow", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Upcomming???? ????.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getRecommendationUpcomming:function(input_param){
			Log.e(" ------------------------->> GetRecommendationUpcomming();");
			var result = sefFactory.getSEF("Slive").execute("GetRecommendationUpcomming", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description 48?? ?? EPG ???? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		activateProgramGuide:function(activityID){
			Log.e(" ------------------------->> ActivateProgramGuide();");
			var result = sefFactory.getSEF("Slive").execute("ActivateProgramGuide", JSON.stringify(activityID));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description 48?? ?? EPG? Program map? Load??.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		loadAdditionalProgramMapFromServer:function(input_param){
			Log.e(" ------------------------->> LoadAdditionalProgramMapFromServer();");
			var result = sefFactory.getSEF("Slive").execute("LoadAdditionalProgramMapFromServer", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description EPG? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getProgramMap:function(input_param){
			Log.e(" ------------------------->> GetProgramMap();");
			var result = sefFactory.getSEF("Slive").execute("GetProgramMap", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description 12?? ??? ??? ????? ?? ??.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		deactivateProgramGuide:function(activityID){
			Log.e(" ------------------------->> DeactivateProgramGuide();");
			var result = sefFactory.getSEF("Slive").execute("DeactivateProgramGuide", JSON.stringify(activityID));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ChannelList? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getFullChannelList:function(activityID){
			Log.e(" ------------------------->> GetFullChannelList();");
			var result = sefFactory.getSEF("Slive").execute("GetFullChannelList", JSON.stringify(activityID));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ChannelList? Tune? ??? Channel List? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getTunableChannelList:function(activityID){
			Log.e(" ------------------------->> GetTunableChannelList();");
			var result = sefFactory.getSEF("Slive").execute("GetTunableChannelList", JSON.stringify(activityID));
			return JSON.parse(result);
		},

		/**
		 * @author yj14.lee@samsung.com
		 * @description TCChannel??? ?? FCRemoteChannel ??? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getFCRemoteChannelByTCServiceID:function(input_param){
			Log.e(" ------------------------->> GetFCRemoteChannelByTCChannel();");
			var result = sefFactory.getSEF("Slive").execute("GetFCRemoteChannelByTCServiceId", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		/**
		 * @author yj14.lee@samsung.com
		 * @description FCRemoteChannel ??? ?? TCChannel ??? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getTCServiceIdByFCRemoteChannel:function(input_param){
			Log.e(" ------------------------->> GetTCServiceIdByFCRemoteChannel();");
			var result = sefFactory.getSEF("Slive").execute("GetTCServiceIdByFCRemoteChannel", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Program source id? ?? TCChannel??? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getTCServiceIdByProgramSourceID:function(input_param){
			Log.e(" ------------------------->> GetTCServiceIdByProgramSourceID();");
			var result = sefFactory.getSEF("Slive").execute("GetTCServiceIdByProgramSourceID", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Program source id? ?? FCRemoteChannel??? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getFCRemoteChannelByProgramSourceID:function(input_param){
			Log.e(" ------------------------->> GetFCRemoteChannelByProgramSourceID();");
			var result = sefFactory.getSEF("Slive").execute("GetFCRemoteChannelByProgramSourceID", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Program source id? ?? FCRemoteProgram??? ???.
		 * @param Json
		 *            Object
		 * @returns Json Object
		 */
		getFCRemoteProgramByProgramSourceID:function(input_param){
			Log.e(" ------------------------->> GetFCRemoteProgramByProgramSourceID();");
			var result = sefFactory.getSEF("Slive").execute("GetFCRemoteProgramByProgramSourceID", JSON.stringify(input_param));
			return JSON.parse(result);
		},
		
		getTvMode:function(){
			Log.e(" ------------------------->> GetTvMode();");
			return sefFactory.getSEF("Slive").execute("GetTvMode");
		},
		setTvMode:function(nTvMode){
			Log.e(" ------------------------->> SetTvMode();");
			return sefFactory.getSEF("Slive").execute("SetTvMode", nTvMode);
		},
		getSource:function(){
			Log.e(" ------------------------->> GetSource();");
			return sefFactory.getSEF("Slive").execute("GetSource");
		},
		setSource:function(nSource, nSeek){
			Log.e(" ------------------------->> SetSource();");
			return sefFactory.getSEF("Slive").execute("SetSource", nSource, nSeek);
		},
		getCurrentChannel_Major:function(){
			Log.e(" ------------------------->> GetCurrentChannel_Major();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Major");
		},
		getCurrentChannel_Minor:function(){
			Log.e(" ------------------------->> GetCurrentChannel_Minor();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Minor");
		},
		getCurrentChannel_Name:function(){
			Log.e(" ------------------------->> GetCurrentChannel_Name();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Name");
		},
		getCurrentChannel_OriginNetID:function(){
			Log.e(" ------------------------->> GetCurrentChannel_OriginNetID();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_OriginNetID");
		},
		getCurrentChannel_ProgramNumber:function(){
			Log.e(" ------------------------->> GetCurrentChannel_ProgramNumber();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_ProgramNumber");
		},
		getCurrentChannel_PTC:function(){
			Log.e(" ------------------------->> GetCurrentChannel_PTC();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_PTC");
		},
		getCurrentChannel_ServiceName:function(){
			Log.e(" ------------------------->> GetCurrentChannel_ServiceName();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_ServiceName");
		},
		getCurrentChannel_TransportStreamID:function(){
			Log.e(" ------------------------->> GetCurrentChannel_TransportStreamID();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_TransportStreamID");
		},
		getCurrentChannel_Type:function(){
			Log.e(" ------------------------->> GetCurrentChannel_Type();");
			return sefFactory.getSEF("Slive").execute("GetCurrentChannel_Type");
		},
		getChannel_Major:function(){
			Log.e(" ------------------------->> GetChannel_Major();");
			return sefFactory.getSEF("Slive").execute("GetChannel_Major");
		},
		getChannel_Minor:function(){
			Log.e(" ------------------------->> GetChannel_Minor();");
			return sefFactory.getSEF("Slive").execute("GetChannel_Minor");
		},
		getChannel_Name:function(){
			Log.e(" ------------------------->> GetChannel_Name();");
			return sefFactory.getSEF("Slive").execute("GetChannel_Name");
		},
		getChannel_OriginNetID:function(){
			Log.e(" ------------------------->> GetChannel_OriginNetID();");
			return sefFactory.getSEF("Slive").execute("GetChannel_OriginNetID");
		},
		getChannel_ProgramNumber:function(){
			Log.e(" ------------------------->> GetChannel_ProgramNumber();");
			return sefFactory.getSEF("Slive").execute("GetChannel_ProgramNumber");
		},
		getChannel_PTC:function(){
			Log.e(" ------------------------->> GetChannel_PTC();");
			return sefFactory.getSEF("Slive").execute("GetChannel_PTC");
		},
		getChannel_ServiceName:function(){
			Log.e(" ------------------------->> GetChannel_ServiceName();");
			return sefFactory.getSEF("Slive").execute("GetChannel_ServiceName");
		},
		getChannel_TransportStreamID:function(){
			Log.e(" ------------------------->> GetChannel_TransportStreamID();");
			return sefFactory.getSEF("Slive").execute("GetChannel_TransportStreamID");
		},
		getChannel_Type:function(){
			Log.e(" ------------------------->> GetChannel_Type();");
			return sefFactory.getSEF("Slive").execute("GetChannel_Type");
		},
		setChannel:function(nMajor, nMinor){
			Log.e(" ------------------------->> SetChannel();");
			return sefFactory.getSEF("Slive").execute("SetChannel", nMajor, nMinor);
		},
		setChannelNumberInfo:function(major, minor){
			Log.e(" ------------------------->> SetChannelNumberInfo();");
			return sefFactory.getSEF("Slive").execute("SetChannelNumberInfo", major, minor);
		},
		getChannelNumberInfo:function(){
			Log.e(" ------------------------->> GetChannelNumberInfo();");
			return sefFactory.getSEF("Slive").execute("GetChannelNumberInfo");
		},
		getProgram:function(param){
			Log.e(" ------------------------->> GetProgram();");
			var result = sefFactory.getSEF("Slive").execute("GetProgram", JSON.stringify(param));
			return JSON.parse(result);
		},
		getProgramList:function(param){
			Log.e(" ------------------------->> GetProgramList();");
			var result = sefFactory.getSEF("Slive").execute("GetProgramList", JSON.stringify(param));
			return JSON.parse(result);
		},
		getPresentProgram:function(param){
			Log.e(" ------------------------->> GetPresentProgram();");
			var result = sefFactory.getSEF("Slive").execute("GetPresentProgram", JSON.stringify(param));
			return JSON.parse(result);
		},
		flagMBRMode:function(){
			Log.e(" ------------------------->> FlagMBRMode();");
			return sefFactory.getSEF("Slive").execute("FlagMBRMode");
		},
		getChannelLogo:function(param){
			Log.e(" ------------------------->> GetChannelLogo();");
			var result = sefFactory.getSEF("Slive").execute("GetChannelLogo", JSON.stringify(param));
			return JSON.parse(result);
		},
		setOnDemandProgram:function(param){
			Log.e(" ------------------------->> SetOnDemandProgram();");
			var result = sefFactory.getSEF("Slive").execute("SetOnDemandProgram", JSON.stringify(param));
			return JSON.parse(result);
		},
		unsetOnDemandProgram:function(param){
			Log.e(" ------------------------->> UnsetOnDemandProgram();");
			var result = sefFactory.getSEF("Slive").execute("UnsetOnDemandProgram", JSON.stringify(param));
			return JSON.parse(result);
		}
};

/**
 * @namespace network
 */
exports.network = {	
		/** ** network_type */
		NETWORK_TYPE_WIRELESS	: 0,
		/** ** network_type */
		NETWORK_TYPE_WIRED		: 1,
		m_SEFNetwork: null,
		m_bOpened: false,
		/**
		 * @author yj14.lee@samsung.com
		 * @fn Boolean init()
		 * @description Network EMP ??? ??
		 * @returns {Boolean}
		 */
		init:function(){
			Log.e("[network]init start");
			this.m_bOpened = sefFactory.init("Network");
			Log.e("[network]m_bOpened:"+this.m_bOpened);
			this.m_SEFNetwork = sefFactory.getSEF("Network"); //used _Network function
			return this.m_bOpened;
		},
		/**
		 * @author sunjung.yoo@samsung.com
		 * @fn Boolean initAsync()
		 * @description Network EMP ??? ??
		 * @returns {Boolean}
		 */
		initAsync:function(OpenCallback){
			Log.e("[network]initAsync start");
			sefFactory.initAsync("Network", function(is_success){
				Log.e("[network]Network is_success:"+is_success);
				exports.network.m_bOpened = is_success;
				OpenCallback(exports.network.m_bOpened);
			});
			this.m_SEFNetwork = sefFactory.getSEF("Network"); //used _Network function
		},
		isOpened:function(){
			return this.m_bOpened;
		},
		destroy:function(){
			Log.e(" ------------------------->> destroy();");
			sefFactory.releaseSEF("Network");
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description available? ????? ???.
		 * @param successCallback -
		 *            function, errorCalback - function
		 */
		getAvailableNetworks:function(successCallback, errorCallback){	
			Log.e(" ------------------------->> getAvailableNetworks();");
			var networkListLength = [this.NETWORK_TYPE_WIRELESS, this.NETWORK_TYPE_WIRED];
			var networkList = [];
			
			networkList[0] = new _Network(0, this);
			networkList[1] = new _Network(1, this);
			if(networkList[1].isActive())
			{
				if(typeof successCallback == 'function') {
					successCallback(networkList);
					return;
				}
			}
			
			if(networkList[0].isActive())
			{
				if(typeof successCallback == 'function') {
					successCallback(networkList);
					return;
				}
			}
			
			if(typeof errorCallback == 'function') {
				errorCallback(networkList);
				return;
			}
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description DNS? ???.
		 * @param enum
		 * @return String
		 */
		getDNS:function(interfaceType){
			Log.e(" ------------------------->> getDNS("+ interfaceType +")");
			return sefFactory.getSEF("Network").execute("GetDNS", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description DNS Mode? ???.
		 * @param enum
		 * @return String
		 */
		getDNSMode:function(interfaceType){
			Log.e(" ------------------------->> getDNSMode();");
			return sefFactory.getSEF("Network").execute("GetDNSMode", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?????? ???.
		 * @param enum
		 * @return String
		 */
		getGateway:function(interfaceType){
			Log.e(" ------------------------->> getGateway();");
			return sefFactory.getSEF("Network").execute("GetGateway", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??????? ???.
		 * @param enum
		 * @return String
		 */
		getNetMask:function(interfaceType){
			Log.e(" ------------------------->> getNetMask();");
			return sefFactory.getSEF("Network").execute("GetNetMask", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description IP? ???.
		 * @param enum
		 * @return String
		 */
		getIP:function(interfaceType){
			Log.e(" ------------------------->> getIP();");
			return sefFactory.getSEF("Network").execute("GetIP", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description IP Mode? ???.
		 * @param enum
		 * @return String
		 */
		getIPMode:function(interfaceType){
			Log.e(" ------------------------->> getIPMode();");
			return sefFactory.getSEF("Network").execute("GetIPMode", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description MAC? ???.
		 * @param enum
		 * @return String
		 */
		getMAC:function(interfaceType){
			Log.e(" ------------------------->> getMAC();");
			return sefFactory.getSEF("Network").execute("GetMAC", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description DNS? ????.
		 * @param enum
		 * @return String
		 */
		checkDNS:function(interfaceType){
			Log.e(" ------------------------->> checkDNS();"+ interfaceType);
			var result = 0;
			try{
				result = sefFactory.getSEF("Network").execute("CheckDNS", String(interfaceType));
			}catch(e){
				Log.e(" ------------------------->> checkDNS() emp error "+ interfaceType);
			}
			return result;
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?????? ????.
		 * @param enum
		 * @return String
		 */
		checkGateway:function(interfaceType){
			Log.e(" ------------------------->> checkGateway();"+ interfaceType);
			var result = 0;
			try{
				result = sefFactory.getSEF("Network").execute("CheckGateway", String(interfaceType));
			}catch(e){
				Log.e(" ------------------------->> checkDNS() emp error "+ interfaceType);
			}
			return result;
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description HTTP? ????.
		 * @param enum
		 * @return String
		 */
		checkHTTP:function(interfaceType){
			Log.e(" ------------------------->> checkHTTP();"+ interfaceType);
			return sefFactory.getSEF("Network").execute("CheckHTTP", String(interfaceType));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ??? ??? ????.
		 * @param enum
		 * @return String
		 */
		checkPhysicalConnection:function(interfaceType){
			Log.e(" ------------------------->> checkPhysicalConnection();"+ interfaceType);
			return sefFactory.getSEF("Network").execute("CheckPhysicalConnection", String(interfaceType));
		}
};

function NetworkCallbackInfo(){
	this.NetworkConnectionStatusChnageCallback = null;
	this._networkID = null;
}
var networkCallbackInfos = [new NetworkCallbackInfo(), new NetworkCallbackInfo()];

var NETWORK_TYPE_WIRELESS = 0;
var NETWORK_TYPE_WIRED = 1;
var NETWORK_DISCONNECTED = 0;
var NETWORK_CONNECTED = 1;

function _onNetworkPluginEvent(event, data1, data2) {

	Log.e("callback data ------------------------->> "+ event+","+data1+","+data2);
	var status = null;
	switch (event) {
	case 0:
			if (data1 == NETWORK_DISCONNECTED) {
				status = new ConnectonStatus(ConnectonStatus.DISCONNECT, 'disconnected');
				networkCallbackInfos[NETWORK_TYPE_WIRED].NetworkConnectionStatusChnageCallback.ondisconnect(status);
			} else if (data1 == NETWORK_CONNECTED) {
				status = new ConnectonStatus(ConnectonStatus.CONNECT, 'connected');
				networkCallbackInfos[NETWORK_TYPE_WIRED].NetworkConnectionStatusChnageCallback.onconnect(status);
			}
		break;
	case 1:
			if (data1 == NETWORK_DISCONNECTED) {
				status = new ConnectonStatus(ConnectonStatus.DISCONNECT, 'disconnected');
				networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.ondisconnect(status);
			} else if (data1 == NETWORK_CONNECTED) {
				status = new ConnectonStatus(ConnectonStatus.CONNECT, 'connected');
				networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.onconnect(status);
			}
		break;
	case 2:
		if (data1 == NETWORK_DISCONNECTED) {
			status = new ConnectonStatus(ConnectonStatus.DISCONNECT, 'disconnected');
			networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.ondisconnect(status);
		} else if (data1 == NETWORK_CONNECTED) {
			status = new ConnectonStatus(ConnectonStatus.CONNECT, 'connected');
			networkCallbackInfos[NETWORK_TYPE_WIRELESS].NetworkConnectionStatusChnageCallback.onconnect(status);
		}
		break;

	default:
		break;
	}
}

function ConnectonStatus(code, message) {
	this.code = function() {
		return code;
	};
	this.message = function() {
		return message;
	};
}

ConnectonStatus.prototype.toString = function() {
	return '(' + this.code + ') ' + this.message;
};

ConnectonStatus.DISCONNECT = 0;
ConnectonStatus.CONNECT = 1;

function _Network(pInterfaceType, network) {
	// 0 - wireless, 1 - wired
	this.interfaceType = pInterfaceType;
	this.dns = function() {
		return network.getDNS(this.interfaceType);
	};
	// this.secondaryDns = function () {
	// return network.getSecondaryDNS(this.interfaceType);
	// };
	this.dnsMode = function() {
		var nDnsMode = network.getDNSMode(this.interfaceType);
		var sDnsMode = this.toString(nDnsMode);
		return sDnsMode;
	};
	this.gateway = function() {
		return network.getGateway(this.interfaceType);
	};
	this.subnetMask = function() {
		return network.getNetMask(this.interfaceType);
	};
	this.ip = function() {
		return network.getIP(this.interfaceType);
	};
	this.ipMode = function() {
		var nIpMode = network.getIPMode(this.interfaceType);
		var sIpMode = this.toString(nIpMode);
		return sIpMode;
	};
	this.mac = function() {
		return network.getMAC(this.interfaceType);
	};

	this.isActive = function () {
		var checkTarget = {
				"checkGateway" : network.checkGateway(String(this.interfaceType))
				};
				//"checkDNS" : network.checkDNS(String(this.interfaceType)), 
				//"checkHttp" : network.checkHTTP(String(this.interfaceType)),
				//"checkPhysicalConnection" : network.checkPhysicalConnection(String(this.interfaceType))};
		
		if( checkTarget["checkGateway"] === 1 ) {
		//&& checkTarget["checkDNS"] == 1 
		//&& checkTarget["checkHttp"] == 1 
		//&& checkTarget["checkPhysicalConnection"] == 1 ) {
			return true;
		}
		else {
			var errorMessage =  " >>>>>>>>>>>>>>>>>>>>>>>>> " + (this.interfaceType ? "WIRED : " : "WIRELESS : ") + " Not available List [";
			//var index = 0;
			for (key in checkTarget){
				//index++;
				if(checkTarget[key] !== 1){
					errorMessage += key + ", ";
					//if(index>1 && index < 4) errorMessage += ", ";
				}
			}
			errorMessage += "]";
			Log.e(errorMessage);
			return false;
		}
	};

	this.setWatchListener = function(successCallback, errorCallback) {
		Log.e(" ------------------------->> setWatchListener();");
		
		networkPlugin = network.m_SEFNetwork;
		networkPlugin.onEventCallback = _onNetworkPluginEvent;
		
		
		networkCallbackInfos[this.interfaceType].NetworkConnectionStatusChnageCallback = successCallback;
		networkCallbackInfos[this.interfaceType]._networkID = this.interfaceType;
		
	};

	this.unsetWatchListener = function() {
		
		networkCallbackInfos[this.interfaceType].NetworkConnectionStatusChnageCallback  = null;
		networkCallbackInfos[this.interfaceType]._networkID  = null;
	};

	this.toString = function(num) {
		// 0 if Auto, 1 if Manual, -1 if error
		var str = null;
		if (num === 0) {
			str = 'Auto';
		} else if (num == 1) {
			str = 'Manual';
		} else {
			str = 'NotSupported';
		}
		return str;
	};
};

exports.ASF = {
	ASF_EMP_DEVICE_ADDED : 3,
	ASF_EMP_DEVICE_REMOVED : 4,
	m_SEFASF : null,
	m_bOpened : false,
	init : function() {
		Log.e("[ASF]init start");
		this.m_bOpened = sefFactory.init("ASF");
		Log.e("[ASF]m_bOpened:"+this.m_bOpened);
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[ASF]initAsync start");
		sefFactory.initAsync("ASF", function(is_success){
			Log.e("[ASF]ASF is_success:"+is_success);
			exports.ASF.m_bOpened = is_success;
			OpenCallback(exports.ASF.m_bOpened);
		});
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("ASF");
		this.m_bOpened = false;
	},
	setOnEvent : function(OnEvent) {
		this.m_SEFASF.OnEvent = OnEvent;
	},
	// connectServiceconnector
	connectServiceconnector : function() {
		Log.e(" ------------------------->> connectServiceconnector();");
		return sefFactory.getSEF("ASF").execute("asf_serviceconnector_connect");
	},
	// disconnectServiceconnector
	disconnectServiceconnector : function() {
		Log.e(" ------------------------->> disconnectServiceconnector();");
		return sefFactory.getSEF("ASF").execute("asf_serviceconnector_disconnect");
	},
	// setDevicefinderEventCallback
	setDevicefinderEventCallback : function(deviceType) {
		Log.e(" ------------------------->> setDevicefinderEventCallback()");
		return sefFactory.getSEF("ASF").execute("asf_devicefinder_set_event_callback", deviceType);
	},
	// refreshDeviceFinder
	refreshDeviceFinder : function() {
		Log.e(" ------------------------->> refreshDeviceFinder()");
		return sefFactory.getSEF("ASF").execute("asf_devicefinder_refresh");
	},
	// getDevicefinderDeviceList
	getDevicefinderDeviceList : function(deviceType) {
		Log.e(" ------------------------->> getDevicefinderDeviceList()");
		return sefFactory.getSEF("ASF").execute("asf_devicefinder_get_device_list", deviceType);
	}
};

/**
 * @namespace remider
 */
exports.reminder = {
		REMINDER_REPEAT_ONCE 		: 0,
		REMINDER_REPEAT_EVERYDAY	: 1,
		REMINDER_REPEAT_MON_FRI		: 2,
		REMINDER_REPEAT_SAT_SUN		: 3,
		REMINDER_REPEAT_MANUAL		: 4,
		REMINDER_REPEAT_MAX			: 5,
		
		RESERVE_WATCH				: 0,
		RESERVE_RECORD				: 1,
		RESERVE_EVENT_RECORD		: 2,
		RESERVE_ACT					: 3,
		RESERVE_FAIL				: 4,
		RESERVE_NOTHING				: 5,
		RESERVE_INSTANT_ACT			: 6,
		RESERVE_RECORD_READY		: 7,
		RESERVE_SERIES_BOOKING		: 8,
		RESERVE_JAPAN_SERIES_RECORD	: 9,
		RESERVE_PROGRAM_CRID		: 10,
		RESERVE_RECORDLIST_GROUP	: 11,
		RESERVE_COMPELETE			: 12,
	
		RESERVE_EPG		: 0,
		RESERVE_MANUA	: 1,
		
		m_SEFReminder: null,
		m_bOpened: false,
		init:function(){
			Log.e("[reminder]init start");
			this.m_bOpened = sefFactory.init("Reminder");
			Log.e("[reminder]m_bOpened:"+this.m_bOpened);
			return this.m_bOpened;
		},
		initAsync:function(OpenCallback){
			Log.e("[reminder]initAsync start");
			sefFactory.initAsync("Reminder", function(is_success){
				Log.e("[reminder]Reminder is_success:"+is_success);
				exports.reminder.m_bOpened = is_success;
				OpenCallback(exports.reminder.m_bOpened);
			});
		},
		isOpened:function(){
			return this.m_bOpened;
		},
		destroy:function(){
			Log.e(" ------------------------->> destroy();");
			sefFactory.releaseSEF("Reminder");
			this.m_bOpened = false;
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description Reminder Item? Data? ????.
		 * @param channelType,
		 *            major, minor, ptc, programNumber
		 * @return Json Object
		 */
		setRemindInfo:function(input_param){
			Log.e(" ------------------------->> reminder_info_set();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_info_set", JSON.stringify(input_param)));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ??? ???? ???? ???.
		 * @param Json
		 *            Object
		 * @return Json Object
		 */
		getOverlappingRemindItems:function(input_param){
			Log.e(" ------------------------->> �reminder_get_overlapping_remind_item();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return  JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_overlapping_remind_items", JSON.stringify(input_param)));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ????? MaxCount? ???.
		 * @return Number
		 */
		getMaxItemCnt:function(){
			Log.e(" ------------------------->> GetMaxItemCnt();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return  JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_max_item_cnt"));	
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ?? ???? ?? ???? ???.
		 * @return Number
		 */
		getReminderListSize:function(){
			Log.e(" ------------------------->> GetReminderListSize();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return  JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_reminder_list_size"));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ???? ????.
		 * @param String
		 * @return boolean
		 */
		addRemindItem:function(input_param){
			Log.e(" ------------------------->> AddRemindItem();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_add_remind_item", JSON.stringify(input_param)));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ???? ????.
		 * @param String
		 * @return boolean
		 */
		deleteRemindItemByUid:function(input_param){
			Log.e(" ------------------------->> DeleteRemindItemByUid();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_delete_remind_item_by_uid", JSON.stringify(input_param)));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ???? ????.
		 * @param String
		 * @return Json Object
		 */
		getRemindInfoByUid:function(input_param){
			Log.e(" ------------------------->> getRemindInfoByUid();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_remind_item_by_uid", JSON.stringify(input_param)));
		},
		
		/**
		 * @author yj14.lee@samsung.com
		 * @description ???? ????.
		 * @param String
		 * @return Json Object
		 */
		getRemindItemByType:function(input_param){
			Log.e(" ------------------------->> getRemindItemByType();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_get_remind_item_by_type", '{"str_reserveType":"' + input_param + '"}'));
		},
		
		/**
		 * @author hello.jeong@samsung.com
		 * @description ServiceID ? ?? reminderInfo? ??? ??? ??.
		 * @param String
		 * @return Json Object
		 */
		getRemindInfoByServiceid:function(input_param){
			Log.e(" ------------------------->> getRemindInfoByServiceid();");
			if(this.m_bOpened == false)return 'Failed to handle the Execute call.';
			return JSON.parse(sefFactory.getSEF("Reminder").execute("reminder_info_set_serviceid", JSON.stringify(input_param)));
		}
};

/**
 * @namespace PVR
 */
exports.PVR = {
	PVR_RECORD_STATR : 0,
	PVR_RECORD_STOP : 1,
	PVR_SEND_THUMBNAIL_REQUEST : 2,

	PVR_NO_AVAIL_DEV : 0,
	PVR_EXIST_DEV : 1,
	PVR_EXIST_REC_DEV : 2,

	m_PVR : null,
	m_bOpened : false,

	
	/**
	 * @author sumin_.park@samsung.com
	 * @fn init
	 * @description The first step to use PVR-related functions.
	 * @param
	 * @returns bool
	 */
	init : function() {
		Log.e("[PVR]init start");
		this.m_bOpened = sefFactory.init("PVR");
		Log.e("[PVR]m_bOpened:"+this.m_bOpened);

		sefFactory.getSEF("PVR").onEventCallback = PVRCallback;

		return this.m_bOpened;
	},
	/**
	 * @author sunjung.yoo@samsung.com
	 * @fn initAsync
	 * @description The first step to use PVR-related functions.
	 * @param
	 * @returns bool
	 */
	initAsync : function(OpenCallback) {
		Log.e("[PVR]initAsync start");
		sefFactory.initAsync("PVR", function(is_success){
			Log.e("[PVR]PVR is_success:"+is_success);
			exports.PVR.m_bOpened = is_success;
			OpenCallback(exports.PVR.m_bOpened);
		});

		sefFactory.getSEF("PVR").onEventCallback = PVRCallback;
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("PVR");
		this.m_bOpened = false;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn recordStart
	 * @description serviceId,uri,recordType and channelType are needed to start
	 *              record.After record started,you will get handle to operate
	 *              this record. And you will receive event PVR_RECORD_STATR
	 *              which is the truly result.
	 * @param Json
	 * @returns Json
	 */
	recordStart : function(param_input) {
		Log.e(" --->> recordStart();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").executeAsync("RecordStart", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn recordStop
	 * @description You can use "handle" to stop record,"duration" is used to
	 *              create thumbnail. And you will receive event PVR_RECORD_STOP
	 *              which is the truly result.
	 * @param Json
	 * @returns Json
	 */
	recordStop : function(param_input) {
		Log.e(" --->> recordStop();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").executeAsync("RecordStop", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn isRecordingAvailable
	 * @description str_result will return true or false.
	 * @param
	 * @returns bool
	 */
	isRecordingAvailable : function() {
		Log.e(" --->> isRecordingAvailable();");
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").execute("IsRecordingAvailable"));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn isRecordingDeviceAttached
	 * @description str_result will return true or false.
	 * @param
	 * @returns bool
	 */
	isRecordingDeviceAttached : function() {
		Log.e(" --->> isRecordingDeviceAttached();");
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").execute("IsRecordingDeviceAttached"));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn sendThumbnailRequest
	 * @description uri is the path of file which need to get thumbnail.
	 * @param Json
	 * @returns Json
	 */
	sendThumbnailRequest : function(param_input) {
		Log.e(" --->> sendThumbnailRequest();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").executeAsync("SendThumbnailRequest", JSON.stringify(param_input)));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn launchDeviceManager
	 * @description calledApp is the name of the user app name like "org.tizen.XXX"
	 * @param Json
	 * @returns Json
	 */
	launchDeviceManager : function(param_input) {
		Log.e(" --->> launchDeviceManager();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").execute("LaunchDeviceManager", JSON.stringify(param_input)));
	},
	/**
	 * @author hello.jeong@samsung.com
	 * @fn getCIThumbType
	 * @description This function will return what kind of thumbnail have to be shown.
	 * @param Json
	 * @returns Json
	 */
	getCIThumbType : function(param_input) {
		Log.e(" --->> getCIThumbType();");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").execute("GetCIThumbType", JSON.stringify(param_input)));
	},
	isRecordingFile:function(param_input){
		Log.e("------------------------>> isRecordingFile ");
		try {
			IsJson(param_input);
		} catch (e) {
			return 'Failed to handle the Execute call.';
		}
		if(this.m_bOpened == false) return 'Failed to handle the Execute call.';
		return JSON.parse(sefFactory.getSEF("PVR").execute("IsRecordingFile", JSON.stringify(param_input)));
		
	},

	addEventListener:function(eventType, cb){
		Log.e("---------------------------------------->> PVR addEventListener");
		PVRcbList[String(eventType)] = cb;
	}
};


var PVRcbList = {};

function PVRCallback(eventType, param1, param2)
{
	Log.e("-----------------------> PVR EVENT:[] " + eventType +","+ param1) ;
	if (typeof PVRcbList[String(param1)] == "function")
		PVRcbList[String(param1)](eventType, param1, param2);
}


var ContentsMgrState = {
	E_CM_EVENT_DEFAULT : 0,
	E_CM_EVENT_USB_CONNECTED : "USB_CONNECTED",
	E_CM_EVENT_USB_DISCONNECTED : "USB_DISCONNECTED",
	E_CM_EVENT_QUERY_COMPLETED : 3,
	E_CM_EVENT_FETCH_COMPLETED : 4,
	E_CM_EVENT_CONTENTS_REGISTER_COMPLETED : 5,
	E_CM_EVENT_CONTENTS_UNREGISTER_COMPLETED : 6,

	E_CM_EVENT_SYNC_COMPLETED : 7,
	E_CM_EVENT_SYNC_FAILED : 8,

	E_CM_EVENT_DB_UPDATED : 9,
	usbconnect : null,
	usbdisconnect : null
};
function _onContentMgrPluginEvent(category, event, data1, data2) {
	Log.e(" --->> _onContentMgrPluginEvent"+category+","+event+","+data1+","+data2);
	try{
		data1 = JSON.parse(data1);
	}catch(e){}
	switch (event) {
	case ContentsMgrState.E_CM_EVENT_USB_CONNECTED:
		if(typeof ContentsMgrState.usbconnect == "function"){
			ContentsMgrState.usbconnect(data1, data2);
		}
		break;

	case ContentsMgrState.E_CM_EVENT_USB_DISCONNECTED:
		if(typeof ContentsMgrState.usbdisconnect == "function"){
			ContentsMgrState.usbdisconnect(data1, data2);
		}
		break;
	}
};
/**
 * @author sunjung.yoo@samsung.com
 * @fn retryContentsMgrOpen
 * @description ContentsMgr EMP open resutl check
 * @param
 * @returns
 */

function retryContentsMgrOpen(openResult){
	var result = openResult;
	if(result == false){	
		Log.e(" ------------------------->> [[ ContentsMgrOpen fail!! ]]");
		openResult = retryContentsMgrinit();
	}
	else{
		Log.e("------------------------->> [[ ContentsMgrOpen success!! ]]");
	}
	Log.e(" --->>ContentsMgr Opened();"+ openResult);
	return openResult;
}

function retryContentsMgrinit(){
	Log.e("------------------->> [[retryContentsMgrinit]]");
	var result = exports.ContentsMgr.init();
	retryContentsMgrOpen(result);			
}

/**
 * @namespace ContentsMgr
 */
exports.ContentsMgr = {

	m_ContentsMgr : null,
	m_bOpened : false,
		
	/**
	 * @author sumin_.park@samsung.com
	 * @fn init
	 * @description
	 * @param
	 * @returns
	 */
	init : function(_usbconnect , _usbdisconnect) {
		Log.e("[ContentsMgr]init start");
		this.m_bOpened = sefFactory.init("ContentsMgr");
		var retryResult = retryContentsMgrOpen(this.m_bOpened);
		Log.e("[ContentsMgr]retryResult:"+retryResult);
		ContentsMgrState.usbconnect = _usbconnect;
		ContentsMgrState.usbdisconnect = _usbdisconnect;
		sefFactory.getSEF("ContentsMgr").onEventCallback = _onContentMgrPluginEvent;
		return retryResult;
	},
	/**
	 * @author sunjung.yoo@samsung.com
	 * @fn initAsync
	 * @description
	 * @param
	 * @returns
	 */
	initAsync : function(OpenCallback, _usbconnect , _usbdisconnect) {
		Log.e("[ContentsMgr]initAsync start");
		sefFactory.initAsync("ContentsMgr", function(is_success){
			Log.e("[ContentsMgr]ContentsMgr is_success:"+is_success);
			exports.ContentsMgr.m_bOpened = is_success;
			OpenCallback(exports.ContentsMgr.m_bOpened);
		});
		
		ContentsMgrState.usbconnect = _usbconnect;
		ContentsMgrState.usbdisconnect = _usbdisconnect;
		sefFactory.getSEF("ContentsMgr").onEventCallback = _onContentMgrPluginEvent;
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("ContentsMgr");
		this.m_bOpened = false;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn connect
	 * @description
	 * @param
	 * @returns
	 */
	connect : function() {
		Log.e(" --->> connect();");
		return sefFactory.getSEF("ContentsMgr").execute("Connect");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn disconnect
	 * @description
	 * @param
	 * @returns
	 */
	disconnect : function() {
		Log.e(" --->> disconnect();");
		return sefFactory.getSEF("ContentsMgr").execute("Disconnect");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getStorages
	 * @description
	 * @param
	 * @returns
	 */
	getStorages : function() {
		Log.e(" --->> getStorages();");
		return JSON.parse(sefFactory.getSEF("ContentsMgr").execute("GetStorages"));
	},

};

/**
 * @namespace AppCommon
 */
exports.AppCommon = {
	m_AppCommon : null,
	m_bOpened : false,
	init : function() {
		Log.e("[AppCommon]init start");
		this.m_bOpened = sefFactory.init("AppCommon");
		Log.e("[AppCommon]m_bOpened:"+this.m_bOpened);
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[AppCommon]initAsync start");
		sefFactory.initAsync("AppCommon", function(is_success){
			Log.e("[AppCommon]AppCommon is_success:"+is_success);
			exports.AppCommon.m_bOpened = is_success;
			OpenCallback(exports.AppCommon.m_bOpened);
		});
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("AppCommon");
		this.m_bOpened = false;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn registerKey
	 * @description
	 * @param
	 * @returns
	 */
	registerKey : function(key) {
		if (this.m_AppCommon) {
			Log.e(" --->> TVMW Not Init;");
			// return;
		}
		Log.e(" --->> registerKey();"+ String(key));
		return sefFactory.getSEF("AppCommon").execute("RegisterKey", String(key));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn unRegisterKey
	 * @description
	 * @param
	 * @returns
	 */
	unRegisterKey : function(key) {
		if (this.m_AppCommon) {
			Log.e(" --->> TVMW Not Init;");
			// return;
		}
		Log.e(" --->> unRegisterKey();"+ String(key));
		return sefFactory.getSEF("AppCommon").execute("UnregisterKey", String(key));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn registerAllKey
	 * @description
	 * @param
	 * @returns
	 */
	registerAllKey: function() {
		if (this.m_AppCommon) {
			Log.e(" --->> TVMW Not Init;");
			// return;
		}
		Log.e(" --->>registerAllKey();)");
		return sefFactory.getSEF("AppCommon").execute("RegisterAllKey");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn unregisterAllKey
	 * @description
	 * @param
	 * @returns
	 */
	unregisterAllKey : function() {
		if (this.m_AppCommon) {
			Log.e(" --->> TVMW Not Init;");
			// return;
		}
		Log.e(" --->>unregisterAllKeyy();)");
		return sefFactory.getSEF("AppCommon").execute("UnregisterAllKey");
	}
};
/**
 * @namespace TVMW
 */
exports.TVMW = {
	m_AppCommon : null,
	m_bOpened : false,
	init : function() {
		Log.e("[TVMW]init start");
		this.m_bOpened = sefFactory.init("TVMW");
		Log.e("[TVMW]m_bOpened:"+this.m_bOpened);
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[TVMW]initAsync start");
		sefFactory.initAsync("TVMW", function(is_success){
			Log.e("[TVMW]TVMW is_success:"+is_success);
			exports.TVMW.m_bOpened = is_success;
			OpenCallback(exports.TVMW.m_bOpened);
		});
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("TVMW");
		this.m_bOpened = false;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getProfile
	 * @description
	 * @param
	 * @returns
	 */
	getProfile : function() {
		Log.e(" --->> getProfile();");
		return sefFactory.getSEF("TVMW").execute("GetProfile");
	}
};
/**
 * @namespace device
 */
exports.device = {
	PL_TVMW_PRFID_TICKER_ID : 0,
	PL_TVMW_PRFID_CHILDLOCK_PIN : 1,
	PL_TVMW_PRFID_HUB_TVID : 2,
	PL_TVMW_PRFID_TICKER_AUTOBOOT : 3,
	PL_TVMW_PRFID_TICKER_DURATION : 4,
	PL_TVMW_PRFID_WIDGET_DPTIME : 5,
	PL_TVMW_PRFID_CONTRACT : 6,
	PL_TVMW_PRFID_TICKER_SAFE : 7,
	PL_TVMW_PRFID_RESET : 8,
	PL_TVMW_PRFID_PASSWD_RESET : 9,
	PL_TVMW_PRFID_GEOIP_STATUS : 10,
	PL_TVMW_PRFID_COUNTRY_CODE : 11,
	PL_TVMW_PRFID_WLAN_DEFAULT_NETWORK : 12,
	PL_TVMW_PRFID_AUTO_PROTECTION_TIME : 13,
	PL_TVMW_PRFID_CHANNEL_BOUND_EXECUTE : 14,
	PL_TVMW_PRFID_PASSWORD : 15,
	PL_TVMW_PRFID_SOURCE_BOUND_WIDGET_ID : 16,
	PL_TVMW_PRFID_SOURCE_BOUND_SOURCE_ID : 17,
	PL_TVMW_PRFID_AUTOBOOT : 18,
	PL_TVMW_PRFID_ACRAD_MENU : 19,
	PL_TVMW_PRFID_MEDIA_PLAY_BLOCK : 20,
	PL_TVMW_PRFID_SOURCE_ISP_APP_ID : 21,
	m_SEFDevice : null,
	m_bOpened : false,

	init : function() {
		Log.e("[device]init start");
		this.m_bOpened = sefFactory.init("Device");
		Log.e("[device]m_bOpened:"+this.m_bOpened);
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[device]initAsync start");
		sefFactory.initAsync("Device", function(is_success){
			Log.e("[device]Device is_success:"+is_success);
			exports.device.m_bOpened = is_success;
			OpenCallback(exports.device.m_bOpened);
		});
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("Device");
		this.m_bOpened = false;
	},
	getModel : function(param_model) {// ???
		Log.e(" --->> getModel();");
		return sefFactory.getSEF("Device").execute("GetModel", String(param_model));
	},

	getSWVersion : function(param_device_type, param_product_version_type) {// ???
		Log.e(" --->> getSWVersion();"+ param_device_type+","+param_product_version_type);
		return sefFactory.getSEF("Device").execute("GetVersionString", String(param_device_type), String(param_product_version_type));
	}
};

/**
 * @namespace TUNE
 */
exports.TUNE = {
	m_bOpened : false,
	
	PL_TV_EVENT_NO_SIGNAL : "101",
	PL_TV_EVENT_TUNE_CHANNEL : "102",
	PL_TV_EVENT_TUNE_SUCCESS : "103",
	PL_TV_EVENT_BACKGROUND_SIGNAL_OK : "104",
	PL_TV_EVENT_SEARCH_CHANNEL : "105",
	PL_TV_EVENT_CHANNEL_FOUND : "106",

	PL_TV_EVENT_SEARCH_CHANNEL_DONE : "108",
	PL_TV_EVENT_SEARCH_CHANNEL_MAP_FULL : "109",
	PL_TV_EVENT_NOT_SUPPORTED : "110",
	PL_TV_EVENT_MTS_CHANGED : "111",
	PL_TV_EVENT_CHANNEL_MAP_CHANGED : "112",
	PL_TV_EVENT_CHANNEL_CHANGED : "113",
	PL_TV_EVENT_SOURCE_CHANGED : "114",
	PL_TV_EVENT_CHANGE_TV_MODE : "115",
	PL_TV_EVENT_SETCHANNEL_TUNED : "116",
	PL_TV_EVENT_RESOLUTION_CHANGED : "117",
	PL_TV_EVENT_RESOLUTION_DETECTED : "118",

	PL_TV_EVENT_EXTSOURCE_SCART : "121",
	PL_TV_EVENT_UPDATE_DYNAMICSI : "122",
	PL_TV_EVENT_SEARCH_GET_NETWORK_DONE : "123",
	PL_TV_EVENT_HD_NOT_SUPPORT : "124",
	PL_TV_EVENT_SHOW_START : "125",

	PL_TV_EVENT_SOURCE_CONNECTED : "126",

	PL_TV_EVENT_EPG_COMPLETED : "201",
	PL_TV_EVENT_EPG_CHANGED : "202",
	PL_TV_EVENT_CAPTION_DESCRIPTOR : "203",
	PL_TV_EVENT_PROGRAM_CHANGED : "204",
	PL_TV_EVENT_STREAM_CLOCK_CHANGED : "205",

	PL_TV_EVENT_SW_UPGRADE : "206",
	PL_TV_EVENT_PMT_ARRIVED : "207",
	PL_TV_EVENT_DSIDII_ARRIVED : "208",
	PL_TV_EVENT_DDB_ARRIVED : "209",
	PL_TV_EVENT_TSD_ARRIVED : "210",
	PL_TV_EVENT_CHANGE_POWER_STATE : "211",
	PL_TV_EVENT_RECV_CURRENT_EVENT : "212",
	PL_TV_EVENT_STT_CHANGED : "213",
	PL_TV_EVENT_CAPTION_MODE_CHANGED : "214",
	PL_TV_EVENT_PROGRAM_CHANGED_MULTIPLEX : "215",
	PL_TV_EVENT_DVBSI_STARTED : "216",
	PL_TV_EVENT_PRESENT_EIT_CHANGED : "21",

	PL_TV_EVENT_MMI_START : "301",
	PL_TV_EVENT_MMI_END : "302",
	PL_TV_EVENT_INBAND_EAS : "303",
	PL_TV_EVENT_OOB_EAS : "304",
	PL_TV_EVENT_CABLECARD_ENABLE : "305",
	PL_TV_EVENT_CABLECARD_DISABLE : "306",
	PL_TV_EVENT_CABLECARD_CHLIST_UPDATE : "307",
	PL_TV_EVENT_CABLECARD_CHLIST_COMPLETE : "308",
	PL_TV_EVENT_CABLECARD_CP_TECHNICAL_P_START : "309",
	PL_TV_EVENT_CABLECARD_CP_TECHNICAL_H_START : "310",
	PL_TV_EVENT_CABLECARD_CP_TIMEERROR_START : "311",
	PL_TV_EVENT_CABLECARD_HOMING_START : "312",
	PL_TV_EVENT_CABLECARD_HOMING_TUNE : "313",
	PL_TV_EVENT_CABLECARD_HOMING_FINISH : "314",
	PL_TV_EVENT_CABLECARD_HOMING_TIMEOUT : "315",
	PL_TV_EVENT_CABLECARD_CARD_ERROR : "316",
	PL_TV_EVENT_CABLECARD_CA_REPLY : "317",
	PL_TV_EVENT_CABLECARD_CA_UPDATE : "318",
	PL_TV_EVENT_CABLECARD_AI_MMI_READY : "319",
	PL_TV_EVENT_CABLECARD_AI_SERVER_REPLY : "320",

	PL_TV_EVENT_EXTSOURCE_CHECKCABLE : "401",
	PL_TV_EVENT_EXTSOURCE_NOTSUPPORT : "402",
	PL_TV_EVENT_EXTSOURCE_NOSIGNAL : "403",
	PL_TV_EVENT_EXTSOURCE_SIGNAL_OK : "404",

	PL_TV_EVENT_DIGITAL_CAPTION_DATA : "501",
	PL_TV_EVENT_ANALOG_CAPTION_DATA : "502",
	PL_TV_EVENT_GEMSTAR_CAPTION_DATA : "503",
	PL_TV_EVENT_EXIST_CC : "504",

	PL_TV_EVENT_ANALOG_TTX_DATA : "504",
	PL_TV_EVENT_DTV_TTX_DATA : "505",
	PL_TV_EVENT_DTV_SBT_DATA : "506",
	PL_TV_EVENT_DTV_ISDBCAPTION_DATA : "507",
	PL_TV_EVENT_DTV_SUPERIMPOSE_DATA : "508",
	PL_TV_EVENT_PES_CHANGED : "509",
	PL_TV_EVENT_DELIVERY_SYSTEM_CHANGED : "510",
	PL_TV_EVENT_SEARCH_OPTION_CHANGE : "511",
	PL_TV_EVENT_MTS_PREFER_LAN_CHANGED : "512",
	PL_TV_EVENT_NETWORK_CHANGE_INFO_DESC : "513",
	PL_TV_EVENT_TIME_CHILD_LOCK : "514",

	PL_TV_EVENT_SOURCE_CONTROL_CHANGE : "601",
	PL_TV_EVENT_SOURCE_ERROR : "602",
	PL_TV_EVENT_EXTERNALOUT_RECORD_CONTROL_CHANGE : "603",
	PL_TV_EVENT_EXTERNALOUT_ERROR : "604",
	PL_TV_EVENT_MEDIA_COPYPROTECTION_INFO : "605",

	PL_TV_EVENT_SET_MEDIA : "606",
	PL_TV_EVENT_SET_MEDIA_ONTIME : "60",

	PL_TV_EVENT_MEDIA_CHANNEL_FOUND : "608",
	PL_TV_EVENT_CHANNEL_SCRAMBLED : "609",
	PL_TV_EVENT_SERVICE_NOT_AVAILABLE : "610",
	PL_TV_EVENT_DATA_SERVICE : "611",
	PL_TV_EVENT_CAPTION_CHANGED : "6",

	PL_TV_EVENT_MAX : "6",

	PL_WINDOW_SHOW_STATE_OFF : "0",
	PL_WINDOW_SHOW_STATE_NO_SIGNAL : "1",
	PL_WINDOW_SHOW_STATE_VCHIP : "2",
	PL_WINDOW_SHOW_STATE_START : "3",
	PL_WINDOW_SHOW_STATE_STOP : "4",
	PL_WINDOW_SHOW_STATE_MAX : "5",
	
	PL_WINDOW_SHOW_TYPE_OFF : "0",
	PL_WINDOW_SHOW_TYPE_ON : "1",
	PL_WINDOW_SHOW_TYPE_STOP : "2",
	PL_WINDOW_SHOW_TYPE_START : "3",
	PL_WINDOW_SHOW_TYPE_NO_SIGNAL : "4",
	PL_WINDOW_SHOW_TYPE_VCHIP_ON : "5",
	PL_WINDOW_SHOW_TYPE_VCHIP_OFF : "6",
	
	PL_WINDOW_SOURCE_TV : "0",
	PL_WINDOW_SOURCE_MEDIA : "43",
	PL_WINDOW_SOURCE_HOMING : "44",
	PL_WINDOW_SOURCE_IPTV : "45",
	PL_WINDOW_SOURCE_RVU : "46",
	PL_WINDOW_SOURCE_RUI : "47",
	PL_WINDOW_SOURCE_ISP : "48",
	PL_WINDOW_SOURCE_NETWORKSTREAM : "49",
	PL_WINDOW_SOURCE_MAGICINFO : "50",
	PL_WINDOW_SOURCE_OPS : "51",
	PL_WINDOW_SOURCE_DIIVA : "52",
	PL_WINDOW_SOURCE_HYBRIDTV : "53",

	init : function() {
		Log.e("[TUNE]init start");
		var check_window = sefFactory.init("Window");
		var check_tv = sefFactory.init("TV");
		var check_mbr = sefFactory.init("MBR");
		var check_screen = sefFactory.init("Screen");
		Log.e("[TUNE]check_window:"+check_window);
		Log.e("[TUNE]check_tv:"+check_tv);
		Log.e("[TUNE]check_mbr:"+check_mbr);
		Log.e("[TUNE]check_screen:"+check_screen);
		
		sefFactory.getSEF("Window").onEventCallback = TVCallback;
		sefFactory.getSEF("TV").onEventCallback = TVCallback;
		sefFactory.getSEF("MBR").onEventCallback = TVCallback;
		sefFactory.getSEF("Screen").onEventCallback = TVCallback;
		
		if(true === check_window && true === check_tv && true === check_mbr && true === check_screen)
		{
			this.m_bOpened = true;
			return this.m_bOpened;
		}
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[TUNE]initAsync start");
		var check_window = false;
		var check_tv = false;
		var check_mbr = false;
		var check_screen = false;
		var completed_cb = 0;
		sefFactory.initAsync("Window", function(is_success){
			Log.e("[TUNE]Window is_success:"+is_success);
			check_window = is_success;
			completed_cb++;
			Log.e("[TUNE]Window completed_cb:"+completed_cb);
			if(4 === completed_cb)
			{
				if(true === check_window && true === check_tv && true === check_mbr && true === check_screen)
				{
					exports.TUNE.m_bOpened = true;
				}
				else
				{
					exports.TUNE.m_bOpened = false;
				}
				OpenCallback(exports.TUNE.m_bOpened);
			}
		});
		sefFactory.initAsync("TV", function(is_success){
			Log.e("[TUNE]TV is_success:"+is_success);
			check_tv = is_success;
			completed_cb++;
			Log.e("[TUNE]TV completed_cb:"+completed_cb);
			if(4 === completed_cb)
			{
				if(true === check_window && true === check_tv && true === check_mbr && true === check_screen)
				{
					exports.TUNE.m_bOpened = true;
				}
				else
				{
					exports.TUNE.m_bOpened = false;
				}
				OpenCallback(exports.TUNE.m_bOpened);
			}
		});
		sefFactory.initAsync("MBR", function(is_success){
			Log.e("[TUNE]MBR is_success:"+is_success);
			check_mbr = is_success;
			completed_cb++;
			Log.e("[TUNE]MBR completed_cb:"+completed_cb);
			if(4 === completed_cb)
			{
				if(true === check_window && true === check_tv && true === check_mbr && true === check_screen)
				{
					exports.TUNE.m_bOpened = true;
				}
				else
				{
					exports.TUNE.m_bOpened = false;
				}
				OpenCallback(exports.TUNE.m_bOpened);
			}
		});
		sefFactory.initAsync("Screen", function(is_success){
			Log.e("[TUNE]Screen is_success:"+is_success);
			check_screen = is_success;
			completed_cb++;
			Log.e("[TUNE]Screen completed_cb:"+completed_cb);
			if(4 === completed_cb)
			{
				if(true === check_window && true === check_tv && true === check_mbr && true === check_screen)
				{
					exports.TUNE.m_bOpened = true;
				}
				else
				{
					exports.TUNE.m_bOpened = false;
				}
				OpenCallback(exports.TUNE.m_bOpened);
			}
		});
		
		sefFactory.getSEF("Window").onEventCallback = TVCallback;
		sefFactory.getSEF("TV").onEventCallback = TVCallback;
		sefFactory.getSEF("MBR").onEventCallback = TVCallback;
		sefFactory.getSEF("Screen").onEventCallback = TVCallback;
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("Window");
		sefFactory.releaseSEF("TV");
		sefFactory.releaseSEF("MBR");
		sefFactory.releaseSEF("Screen");
		this.m_bOpened = false;
	},
	/**
	 * @author jieun24.lee@samsung.com
	 * @fn  setPictureOff 
	 * @description ?? ?? ??
	 * @param "0"
	 * @returns String
	 */
	 setPictureOff : function(){
		if (!sefFactory.getSEF("Screen")) {
			Log.e(" --->> Screen Not Init;");
			// return;
		}
		Log.e(" --->> setPictureOff();");
		return sefFactory.getSEF("Screen").execute("SetPictureOff", "0");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelNumberInfo
	 * @description mbr_get_send_channel_number_info()??? nMajor, nMinor ? ????
	 *              ????.
	 * @param string
	 * @returns Json
	 */
	getChannelNumberInfo : function(size){
		if (!sefFactory.getSEF("MBR")) {
			Log.e(" --->> MBR Not Init;");
			// return;
		}
		Log.e(" --->> getChannelNumberInfo();");
		return sefFactory.getSEF("MBR").execute("GetChannelNumberInfo",size);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn setChannelNumberInfo
	 * @description mbr_send_channel_number()??? nMajor, nMinor ?? ?? ???
	 *              Set???.
	 * @param int,
	 *            int
	 * @returns Json
	 */
	setChannelNumberInfo : function(major, minor){
		if (!sefFactory.getSEF("MBR")) {
			Log.e(" --->> MBR Not Init;");
			// return;
		}
		Log.e(" --->> setChannelNumberInfo();");
		return sefFactory.getSEF("MBR").execute("SetChannelNumberInfo", String(major), String(minor));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn flagMBRMode
	 * @description mbr_mode()? ??? ?? mode? MBR???? ????.
	 * @param
	 * @returns Json
	 */
	flagMBRMode : function(){
		if (!sefFactory.getSEF("MBR")) {
			Log.e(" --->> MBR Not Init;");
			// return;
		}
		Log.e(" --->> flagMBRMode();");
		return sefFactory.getSEF("MBR").execute("FlagMBRMode");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getTvMode
	 * @description ?? ??? Tv Mode?? ????.
	 * @param
	 * @returns Json
	 */
	getTvMode : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getTvMode();");
		return sefFactory.getSEF("Window").execute("GetTvMode");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn setTvMode
	 * @description Tv Mode? ????.
	 * @param string
	 * @returns bool
	 */
	setTvMode : function(tvMode) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> setTvMode();"+ tvMode);
		return sefFactory.getSEF("Window").execute("SetTvMode", tvMode);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getSource
	 * @description ?? ??? ?? ??? ????.
	 * @param string
	 * @returns string
	 */
	getSource : function(windowSeek) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getSource();"+ windowSeek);
		return sefFactory.getSEF("Window").execute("GetSource", windowSeek);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn setSource
	 * @description ??? ????.
	 * @param string
	 * @returns bool
	 */
	setSource : function(windowSeek) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> setSource();"+ windowSeek);
		return sefFactory.getSEF("Window").execute("SetSource", windowSeek);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelMajor
	 * @description ?? Channel? Major ??? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelMajor : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelMajor();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_Major");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelMinor
	 * @description ?? Channel? Minor ??? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelMinor : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelMinor();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_Minor");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelName
	 * @description ?? Channel? Name? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelName : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelName();");
		var ch_name = sefFactory.getSEF("Window").execute("GetCurrentChannel_Name");
		if(ch_name.charCodeAt(1) === 0)
		{
			return "";
		}
		
		var n, begin_idx = 0, end_idx = ch_name.length-1;
		if(ch_name[0] === "U")
		{
			begin_idx = 1;
		}
		
		for(n = ch_name.length-1; n > 0; n--)
		{
			if(ch_name.charCodeAt(n) !== 0)
			{
				end_idx = n;
				break;
			}
		}
		Log.e("[TUNE]begin_idx:"+begin_idx+", end_idx:"+end_idx);
		ch_name = ch_name.substring(begin_idx, end_idx+1);
		ch_name = ch_name.trim();
		Log.e("[TUNE]Channel Name["+ch_name+"]");
		return ch_name;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelOriginNetID
	 * @description ?? Channel? Original Net ID? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelOriginNetID : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelOriginNetID();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_OriginNetID");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelProgramNumber
	 * @description ?? Channel? Program number ? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelProgramNumber : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelProgramNumber();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_ProgramNumber");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelPTC
	 * @description ?? Channel? PTC ? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelPTC : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelPTC();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_PTC");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelServiceName
	 * @description ?? Channel? service name ? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelServiceName : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelServiceName();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_ServiceName");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelTransportStreamID
	 * @description ?? Channel? Transport Stream ID ? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelTransportStreamID : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelTransportStreamID();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_TransportStreamID");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getCurrentChannelType
	 * @description ?? Channel? Type? ????.
	 * @param
	 * @returns string
	 */
	getCurrentChannelType : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelType();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannel_Type");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn setChannel
	 * @description Channel? ????.
	 * @param string
	 * @returns bool
	 */
	setChannel : function(majorChannel, minorChannel) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> setChannel();");
		return sefFactory.getSEF("Window").execute("SetChannel", String(majorChannel), String(minorChannel));
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn findChannel
	 * @description ?? ??? ?? ??? ???.
	 * @param string
	 * @returns string
	 */
	findChannel : function(channelType, windowType) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> findChannel();");
		return sefFactory.getSEF("Window").execute("FindChannel", channelType, windowType);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelMajor
	 * @description ?? ??? Major? ???.
	 * @param number
	 * @returns object
	 */
	getChannelMajor : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelMajor();");
		return sefFactory.getSEF("Window").execute("GetChannel_Major", channelIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelMinor
	 * @description ?? ??? Minor? ???.
	 * @param number
	 * @returns object
	 */
	getChannelMinor : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelMinor();");
		return sefFactory.getSEF("Window").execute("GetChannel_Minor", channelIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelName
	 * @description ?? ??? name? ???.
	 * @param number
	 * @returns string
	 */
	getChannelName : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelName();");
		return sefFactory.getSEF("Window").execute("GetChannel_Name", channelIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelOriginNetID
	 * @description ?? ??? OriginNetID? ???.
	 * @param number
	 * @returns string
	 */
	getChannelOriginNetID : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelOriginNetID();");
		return sefFactory.getSEF("Window").execute("GetChannel_OriginNetID", channelIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelProgramNumber
	 * @description ?? ??? ProgramNumber? ???.
	 * @param number
	 * @returns string
	 */
	getChannelProgramNumber : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelProgramNumber();");
		return sefFactory.getSEF("Window").execute("GetChannel_ProgramNumber", channelIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelPTC
	 * @description ?? ??? PTC? ???.
	 * @param number
	 * @returns string
	 */
	getChannelPTC : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelPTC();");
		return sefFactory.getSEF("Window").execute("GetChannel_PTC", channelIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelServiceName
	 * @description ?? ??? service name? ???.
	 * @param number
	 * @returns string
	 */
	getChannelServiceName : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelServiceName();");
		return sefFactory.getSEF("Window").execute("GetChannel_ServiceName", channelIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelSize
	 * @description ??? ??? ???.
	 * @param string
	 * @returns string
	 */
	getChannelSize : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelSize();");
		return sefFactory.getSEF("Window").execute("GetChannel_Size");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelTransportStreamID
	 * @description ??? TransportStreamID? ???.
	 * @param number
	 * @returns string
	 */
	getChannelTransportStreamID : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelTransportStreamID();");
		return sefFactory.getSEF("Window").execute("GetChannel_TransportStreamID", channelIndex);
	},
	/**
	 * @author hello.jeong
	 * @fn getChannelServiceId
	 * @description ??? service id? ???.
	 * @param number
	 * @returns string
	 */
	getChannelServiceId : function(major, minor, ch_type) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelServiceId();");
		return sefFactory.getSEF("Window").execute("GetChannel_ServiceId", major, minor, ch_type);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getChannelType
	 * @description ?? ??? type? ???.
	 * @param number
	 * @returns string
	 */
	getChannelType : function(channelIndex) {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getChannelType();");
		return sefFactory.getSEF("Window").execute("GetChannel_Type", String(channelIndex));
	},
	
	
	setWindow : function(window) {
		Log.e(" --->> SetWindow();");
		return sefFactory.getSEF("Window").execute("SetWindow", window);
	},
	getStateShow : function() {
		Log.e(" --->> getStateShow();");
		return sefFactory.getSEF("Window").execute("GetState_Show");
	},
	
	setChannelPTC : function(PTC) {
		Log.e(" --->> setChannelPTC();");
		return sefFactory.getSEF("Window").execute("SetChannel_PTC", PTC);
	},
	show : function(showType) {
		Log.e(" --->> Show();");
		return sefFactory.getSEF("Window").execute("Show", showType);
	},
	setPreviousSource : function() {
		Log.e(" --->> Show();");
		return sefFactory.getSEF("Window").execute("SetPreviousSource");
	},
	
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getPresentProgramDuration
	 * @description ?? ????? duration? ???.
	 * @param string
	 * @returns string
	 */
	getPresentProgramDuration : function() {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getPresentProgramDuration();");
		return sefFactory.getSEF("TV").execute("GetPresentProgram_Duration");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getPresentProgramEndTime
	 * @description ?? ????? end time? ???.
	 * @param string
	 * @returns string
	 */
	getPresentProgramEndTime : function() {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getPresentProgramEndTime();");
		return sefFactory.getSEF("TV").execute("GetPresentProgram_EndTime");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getPresentProgramStartTime
	 * @description ?? ????? start time? ???.
	 * @param string
	 * @returns string
	 */
	getPresentProgramStartTime : function() {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getPresentProgramStartTime();");
		return sefFactory.getSEF("TV").execute("GetPresentProgram_StartTime");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getPresentProgramTitle
	 * @description ?? ????? title? ???.
	 * @param string
	 * @returns string
	 */
	getPresentProgramTitle : function() {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getPresentProgramTitle();");
		return sefFactory.getSEF("TV").execute("GetPresentProgram_Title");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getProgramDuration
	 * @description ?? ????? duration? ???.
	 * @param number
	 * @returns string
	 */
	getProgramDuration : function(programIndex) {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getProgramDuration();"+ programIndex);
		return sefFactory.getSEF("TV").execute("GetProgram_Duration", programIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getProgramEndTime
	 * @description ?? ????? end time? ???.
	 * @param number
	 * @returns string
	 */
	getProgramEndTime : function(programIndex) {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getProgramEndTime();"+ programIndex);
		return sefFactory.getSEF("TV").execute("GetProgram_EndTime", programIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getProgramStartTime
	 * @description ?? ????? start time? ???.
	 * @param number
	 * @returns string
	 */
	getProgramStartTime : function(programIndex) {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getProgramStartTime();"+ programIndex);
		return sefFactory.getSEF("TV").execute("GetProgram_StartTime", programIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getProgramTitle
	 * @description ?? ????? title? ???.
	 * @param number
	 * @returns string
	 */
	getProgramTitle : function(programIndex) {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getProgramTitle();"+ programIndex);
		return sefFactory.getSEF("TV").execute("GetProgram_Title", programIndex);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getProgramList
	 * @description start time, duration?? ???? ???? ???.
	 * @param string,
	 *            string
	 * @returns string
	 */
	getProgramList : function(startTime, duration) {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getProgramList();"+ startTime+","+duration);
		return sefFactory.getSEF("TV").execute("GetProgramList", startTime, duration);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getProgramListSize
	 * @description ???? ??? ??? ???.
	 * @param string
	 * @returns string
	 */
	getProgramListSize : function() {
		if (!sefFactory.getSEF("TV")) {
			Log.e(" --->> TV Not Init;");
			// return;
		}
		Log.e(" --->> getProgramListSize();");
		return sefFactory.getSEF("TV").execute("GetProgramList_Size");
	},
	
	getPresentProgramTitle : function() {
		Log.e(" --->> getPresentProgramTitle();");
		return sefFactory.getSEF("TV").execute("GetPresentProgram_Title");
	},
	/**
	 * @author jieun24.lee@samsung.com
	 * @fn getCurrentChannelInfo
	 * @description Gets current channel information(as JSON)
	 * @param N/A
	 * @returns Json
	 */
	getCurrentChannelInfo : function() {
		if (!sefFactory.getSEF("Window")) {
			Log.e(" --->> Window Not Init;");
			// return;
		}
		Log.e(" --->> getCurrentChannelInfo();");
		return sefFactory.getSEF("Window").execute("GetCurrentChannelInfo");
	},
	getFavorites:function(serviceId, ret){
		Log.e(" ------------------------->> getFavorites();");
		var result = sefFactory.getSEF("Window").execute("GetFavorites", String(serviceId), ret);
		return JSON.parse(result);
	},
	updateFavorites:function(serviceId, ret, favoriteGroup){
		Log.e(" ------------------------->> updateFavorites();");
		var result = sefFactory.getSEF("Window").execute("UpdateFavorites", String(serviceId), ret, String(favoriteGroup));
		return result;
	},
	setChannelByServiceid:function(serviceId){
		Log.e(" ------------------------->> setChannelByServiceid();");
		var result = sefFactory.getSEF("Window").execute("SetChannelByServiceid", String(serviceId));
		return result;
	},
	getChannelServiceIdByIndex:function(index){
		Log.e(" ------------------------->> getChannelServiceIdByIndex();");
		var result = sefFactory.getSEF("Window").execute("GetChannel_ServiceId", String(index));
		return result;
	},
	getProgramListByServicid:function(startTime, duration, serviceId){
		Log.e(" ------------------------->> getProgramListByServicid();");
		var result = sefFactory.getSEF("TV").execute("GetProgramList", String(startTime), String(duration), String(serviceId));
		return result;
	},
	disconnectSource:function(){
		Log.e(" ------------------------->> disconnectSource();");
		var result = sefFactory.getSEF("Window").execute("DisconnectSource");
		return result;
	},
	setEvent : function(event, cb) {
		Log.e(" --->> SetEvent();");
		TVcbList[String(event)] = cb;
		return sefFactory.getSEF("TV").execute("SetEvent", String(event));
	},
	unsetEvent : function(event) {
		Log.e(" --->> unsetEvent();");
		delete TVcbList[String(event)];
		return sefFactory.getSEF("TV").execute("UnsetEvent", String(event));
	},
	addEventListener:function(eventType, cb){
		Log.e("---------------------------------------->> addEventListener");
		TVcbList[String(eventType)] = cb;
	}
};

var TVcbList = {};

function TVCallback(eventType, param1, param2)
{
	Log.e("-----------------------> EVENT:[] " + eventType +","+ param1) ;
	if (typeof TVcbList[String(param1)] == "function")
		TVcbList[String(param1)](eventType, param1, param2);
}

/**
 * @author sunjung.yoo@samsung.com
 * @fn retryLoggingOpen
 * @description Logging EMP open resutl check
 * @param
 * @returns
 */

function retryLoggingOpen(openResult){
	//var result = openResult;
	if(openResult == false){	
		Log.e(" ------------------------->> [[ LoggingOpen fail!! ]]");
		openResult = retryLogginginit();
	}
	else{
		Log.e("------------------------->> [[ LoggingOpen success!! ]]");
	}
	Log.e(" --->>Logging Opened();"+ openResult);
	return openResult;
}

function retryLogginginit(){
	Log.e("------------------->> [[retryLogginginit]]");
	var result = exports.Logging.init();
	retryLoggingOpen(result);	
}

/**
 * @namespace Logging
 */
exports.Logging = {
	m_bOpened : false,
	
	init : function() {
		Log.e("[Logging]init start");
		this.m_bOpened = sefFactory.init("Logging");
		var retryResult = retryLoggingOpen(this.m_bOpened);
		Log.e("[Logging]retryResult:"+retryResult);
		return retryResult;
	},
	initAsync : function(OpenCallback) {
		Log.e("[Logging]initAsync start");
		sefFactory.initAsync("Logging", function(is_success){
			Log.e("[Logging]Logging is_success:"+is_success);
			exports.Logging.m_bOpened = is_success;
			OpenCallback(exports.Logging.m_bOpened);
		});
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("Logging");
		this.m_bOpened = false;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn flushLog
	 * @description This functions prepares the message and sends it to server
	 *              specified in SetServiceConfInfo call.
	 * @param
	 * @returns bool
	 */
	flushLog : function() {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> flushLog();");
		return sefFactory.getSEF("Logging").execute("FlushLog");
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn addEventFullLog
	 * @description This function Adds a full constructed message string to the
	 *              queue. Applications can use it for their own format for logs
	 * @param string,
	 *            string
	 * @returns bool
	 */
	addEventFullLog : function(eventName, log) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> addEventFullLog();");
		return sefFactory.getSEF("Logging").execute("AddEventFullLog", eventName, log);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn setEventHeader
	 * @description This function sets the event header that will be sent in the
	 *              message
	 * @param string,
	 *            string, string, string, string
	 * @returns bool
	 */
	setEventHeader : function(modelName, userId, DUID, country) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> setEventHeader();");
		return sefFactory.getSEF("Logging").execute("SetEventHeader", modelName, userId, DUID, country);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn addEventConfInfo
	 * @description This function adds a new type of Event
	 * @param string,
	 *            string, string, string, string
	 * @returns bool
	 */
	addEventConfInfo : function(eventName, queueMax, expiration, threshold, logLevel) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> addEventConfInfo();");
		return sefFactory.getSEF("Logging").execute("AddEventConfInfo", eventName, queueMax, expiration, threshold, logLevel);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn setServiceConfInfo
	 * @description This function sets service configuration and check its state
	 * @param string,
	 *            string, string, string, string, string
	 * @returns bool
	 */
	setServiceConfInfo : function(serviceName, queueMax, expiration, threshold, logLevel, serverURL) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> setServiceConfInfo();");
		return sefFactory.getSEF("Logging").execute("SetServiceConfInfo", serviceName, queueMax, expiration, threshold, logLevel, serverURL);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn addEventLog
	 * @description This function adds a log message.
	 * @param string,
	 *            string, string, string, string
	 * @returns bool
	 */
	addEventLog : function(eventName, time, category, value, desc) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> addEventLog();");
		return sefFactory.getSEF("Logging").execute("AddEventLog", eventName, time, category, value, desc);

	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn isAgreedWith
	 * @description User can call this API with the Aggrement Name (string Type)
	 *              for which he wants to get the information.
	 * @param string
	 * @returns bool
	 */
	isAgreedWith : function(aggrementName) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> isAgreedWith();");
		return sefFactory.getSEF("Logging").execute("IsAgreedWith", aggrementName);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getGUID
	 * @description This will return Globally Unique ID
	 * @param
	 * @returns string
	 */
	getGUID : function(p1,p2,p3,p4,p5,p6,p7,p8) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			// return;
		}
		Log.e(" --->> getGUID();");
		return sefFactory.getSEF("Logging").execute("GetGUID",p1,p2,p3,p4,p5,p6,p7,p8);
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getUID
	 * @description This will return User ID.
	 * @param
	 * @returns string
	 */
	getUID : function(p1,p2,p3,p4,p5,p6,p7,p8) {
		if (!sefFactory.getSEF("Logging")) {
			Log.e(" --->> Logging Not Init;");
			return;
		}
		Log.e(" --->> getUID();");
		return sefFactory.getSEF("Logging").execute("GetUID",p1,p2,p3,p4,p5,p6,p7,p8);
	}
};

function IsJson(str) {		
	try {
		if(typeof str ==="object"){
			return true;
		}
		else{
			Log.e(" ------------------------->> parameter is not Json;"+ typeof str); 
			throw typeof str;
		}
	} catch (e) {
		Log.e(" ------------------------->> error;"+ e);
		throw e;
	}
}
exports.vconf = {
	MEMORY_VOLT_STRING	: "memory/volt/string",
	MEMORY_VOLT_INT		: "memory/volt/int",
	MEMORY_VOLT_DOUBLE	: "memory/volt/double",
	MEMORY_VOLT_BOOL	: "memory/volt/bool",
	MEMORY_VOLT_ROOT_PATH : "memory/volt",
	
	MEMORY_VOLT_NOTIFY : "memory/volt/notify",
	DB_MENE_NETWORK_DEVICENAME_TV_NAME : "db/menu/network/devicename/tv_name",
	DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST : "db/menu/system/accessibility/highcontrast",
	DB_MENU_SYSTEM_ACCESSIBILITY_FOCUSZOOM : "db/menu/system/accessibility/focuszoom",
	DB_MENU_SYSTEM_MENU_LANGUAGE : "db/menu/system/menu_language",
	MEMORY_HOMEPANEL_COACHMARK_SHOW_FLAG : "memory/homepanel/coachmark_show_flag",
	MEMORY_WINDOW_SYSTEM_INPUT_CURSOR_VISIBLE : "memory/window_system/input/cursor_visible",
	DB_MENU_SYSTEM_GENERAL_MENU_TRANSPARENCY : "db/menu/system/general/menu_transparency",

	
	getValue:function(key){
		return Vconf.getValue(key);
	},
	getValues:function(){
		return Vconf.getValues(this.MEMORY_VOLT_ROOT_PATH);
	},
	setValue:function(key, value){
		return Vconf.setValue(key, value);
	},
	unsetValue:function(key, bool){
		if(bool == null){
			return Vconf.unsetValue(key);
		}else{
			return Vconf.unsetValue(key, bool);
		}
	},
	setOnChangeHandler:function(key, callbackfunction){
		return Vconf.setOnChangeHandler(key, callbackfunction);

	},
	unsetOnChangeHandler:function(key, callbackfunction){
		return Vconf.unsetOnChangeHandler(key, callbackfunction);
	}
}


// Player
nId = 0;
aPlayerInstance = [];

PlayerState = {
		// Player Plugin Event Enum 
		CONNECTION_FAILED: 1,
		AUTHENTICATION_FAILED: 2,
		STREAM_NOT_FOUND: 3,
		NETWORK_DISCONNECTED: 4,
		NETWORK_SLOW: 5,
		RENDER_ERROR: 6,
		RENDERING_START: 7,	//Movie and Music only
		RENDERING_COMPLETE: 8,
		STREAM_INFO_READY: 9,
		DECODING_COMPLETE: 10,	//Picture only
		BUFFERING_START: 11,
		BUFFERING_COMPLETE: 12,
		BUFFERING_PROGRESS: 13,
		CURRENT_DISPLAY_TIME: 14,
		CURRENT_PLAYBACK_TIME: 14,
		AD_START: 15,
		AD_END: 16,
		RESOLUTION_CHANGED: 17,
		BITRATE_CHANGED: 18,
		SUBTITLE: 19,
		CUSTOM: 20,
		SEEK_COMPLETED: 30,
		ASM_TO_PAUSE : 150,
		ASM_READY_TO_RESUME : 151,
		
		// RENDER_ERROR Detail
		UNKNOWN_ERROR: 0,
		UNSUPPORTED_CONTAINER: 1,
		UNSUPPORTED_VIDEO_CODEC: 2,
		UNSUPPORTED_AUDIO_CODEC: 3,
		UNSUPPORTED_VIDEO_RESOLUTION: 4,
		UNSUPPORTED_VIDEO_FRAMERATE: 5,
		CURRUPTED_STREAM: 6,
		UNSUPPORTED_VIDEO_PROFILE: 7,
		PLAY_FAILED: 8, // MediaCommon::MEDIA_ERROR_STATE
		INVALID_URI: 9, //  MEDIA_ERROR_NO_EXIST_FILE
		
		//custom error 20121101
		CUSTOM_ERROR:100,
		
		//custom error 20121207
		RTSP_STATE : 95,
		// Player State Enum
		PLAY_STATE_IDLE: 0,
		PLAY_STATE_INITIALIZED: 1,
		PLAY_STATE_STOPPED: 2,
		PLAY_STATE_PREPARED: 3,
		PLAY_STATE_STARTED: 4,
		PLAY_STATE_PAUSED: 5,
		//Sound Type
		SOUND_TYPE_SYSTEM  : 1,		 
		SOUND_TYPE_NOTIFICATION : 2,
		SOUND_TYPE_ALARM  :3,
		SOUND_TYPE_RINGTONE  :4,
		SOUND_TYPE_MEDIA  :5,
		SOUND_TYPE_CALL  :6,
		SOUND_TYPE_VOIP  :7,
		SOUND_TYPE_FIXED  :8,
		SOUND_TYPE_FIXED_AF  :9,
		SOUND_TYPE_FIXED_SHUTTER1:10,  
		SOUND_TYPE_FIXED_SHUTTER2  :11,
		SOUND_TYPE_FIXED_CAMCORDING  :12,
		
		//Audio Latency
		AUDIO_LATENCY_MODE_LOW  : 1,
		AUDIO_LATENCY_MODE_MID  : 2,
		AUDIO_LATENCY_MODE_HIGH : 3,

		// setPlayerProperty
		PROPERTY_LIVE_STREAM : 5,
		PROPERTY_HD_AUDIO : 16
};

/**
 * @namespace player
 */
exports.player = {
	/**
	 * 
	 * @author sumin_.park@samsung.com
	 * @description Get Player instance
	 * @returns Object
	 */
	getPlayer : function() {
		var iPlayer = new _Player(nId);
		aPlayerInstance[nId] = iPlayer;
		nId++;
		return iPlayer;
	},	

	_getAllInstance : function() {
		return aPlayerInstance;
	},

	_destroyAll : function() {
		var aInstance = player._getAllInstance();
		Log.e('--->> [Player] _destroyAll() with ' + aInstance.length + ' instances.');
		for (var i = 0; i < _getAllInstance.length; i++) {
			aInstance[i].destroy();
		}

	}

};
function PlayTime(ms) {
	this.millisecond = ms;

	var hour = parseInt(ms / (3600 * 1000), 10);
	ms -= hour * (3600 * 1000);
	var min = parseInt(ms / (60 * 1000), 10);
	ms -= min * (60 * 1000);
	var sec = parseInt(ms / (1000), 10);
	this.timeString = (hour > 9 ? hour : '0' + hour) + ':' + (min > 9 ? min : '0' + min) + ':' + (sec > 9 ? sec : '0' + sec);
}

PlayTime.prototype.toString = function() {
	return this.timeString;
};
function _isType(value, types){
	var sValueType = '';
	if (value === null) {
		sValueType = 'null';
	}
	else {
		sValueType = typeof value;
	}
    return types.indexOf(sValueType) != -1;
}
function _checkNumberType (num){
	var nNum = Number(num);
  
  if(!isFinite(nNum)){
		nNum = 0;  		
		return nNum;
  } else {
  	return nNum;
  }
}
function _Player(id) {
	var sName = "Player" + id;
	var self = this;
	var ID = id;
	var bOpened = false;
	var bInitialize = false;
	var loopCount = 3;
	var bAutoRatio = true;
	var videoWidget = null;

	var oInitOption = {}; // AVPlayInitialOption -> init()?? ??
	var oPlayOption = {}; // AVPlayOption -> open()?? ??

//	var cbOnSubtitle = null;

	ePlayerPlugin = null;
	
	this.status = PlayerState.PLAY_STATE_IDLE;
	this.Event2String = {};	// serial log ? ???? ?? string
	this.Event2String[PlayerState.CONNECTION_FAILED] = "CONNECTION_FAILED";
	this.Event2String[PlayerState.AUTHENTICATION_FAILED] = "AUTHENTICATION_FAILED";
	this.Event2String[PlayerState.STREAM_NOT_FOUND] = "STREAM_NOT_FOUND";
	this.Event2String[PlayerState.NETWORK_DISCONNECTED] = "NETWORK_DISCONNECTED";
	this.Event2String[PlayerState.NETWORK_SLOW] = "NETWORK_SLOW";
	this.Event2String[PlayerState.RENDER_ERROR] = "RENDER_ERROR";
	this.Event2String[PlayerState.RENDERING_START] = "RENDERING_START";
	this.Event2String[PlayerState.RENDERING_COMPLETE] = "RENDERING_COMPLETE";
	this.Event2String[PlayerState.STREAM_INFO_READY] = "STREAM_INFO_READY";
	this.Event2String[PlayerState.DECODING_COMPLETE] = "DECODING_COMPLETE";
	this.Event2String[PlayerState.BUFFERING_START] = "BUFFERING_START";
	this.Event2String[PlayerState.BUFFERING_COMPLETE] = "BUFFERING_COMPLETE";
	this.Event2String[PlayerState.BUFFERING_PROGRESS] = "BUFFERING_PROGRESS";
	this.Event2String[PlayerState.CURRENT_PLAYBACK_TIME] = "CURRENT_PLAYBACK_TIME";
	this.Event2String[PlayerState.AD_START] = "AD_START";
	this.Event2String[PlayerState.AD_END] = "AD_END";
	this.Event2String[PlayerState.RESOLUTION_CHANGED] = "RESOLUTION_CHANGED";
	this.Event2String[PlayerState.BITRATE_CHANGED] = "BITRATE_CHANGED";
	this.Event2String[PlayerState.SUBTITLE] = "SUBTITLE";
	this.Event2String[PlayerState.CUSTOM] = "CUSTOM";
	this.Event2String[PlayerState.ASM_TO_PAUSE] = "ASM_TO_PAUSE";
	this.Event2String[PlayerState.ASM_READY_TO_RESUME] = "ASM_READY_TO_RESUME";	
	
	this.State2String = {};
	this.State2String[PlayerState.PLAY_STATE_IDLE] = "PLAY_STATE_IDLE";
	this.State2String[PlayerState.PLAY_STATE_INITIALIZED] = "PLAY_STATE_INITIALIZED";
	this.State2String[PlayerState.PLAY_STATE_STOPPED] = "PLAY_STATE_STOPPED";
	this.State2String[PlayerState.PLAY_STATE_PREPARED] = "PLAY_STATE_PREPARED";
	this.State2String[PlayerState.PLAY_STATE_STARTED] = "PLAY_STATE_STARTED";
	this.State2String[PlayerState.PLAY_STATE_PAUSED] = "PLAY_STATE_PAUSED";

	this.getID = function() {
		return ID;
	}, this.getName = function() {
		return sName;
	}, this.destroy = function() {
		Log.e("--->> [Player" + id + "] stop(" + ")");
		this.close();
	},
	this.close = function(){
		if(bOpened){
			bInitialize = false;
			ePlayerPlugin.close();
		}
	}
	
	this.getSEFObj = function(){
		return ePlayerPlugin;
	}
	this.getVideoWidget = function () {
		return videoWidget;
	}
	this.createVideoWidget = function(args){
		if(videoWidget == null){
			videoWidget = new VideoWidget(args);
			videoWidget.videoPlayerSef = ePlayerPlugin;
		}
		return videoWidget;
	}
	
	
	/**
	 * @memberof exports.player
	 * @author sumin_.park@samsung.com
	 * @fn init
	 * @description Player init
	 * @param Json Object
	 * @returns
	 */
	this.init = function(option) {
		Log.e("[player]init start");
		/*
	     option = {
		     containerID: id,	// [init()]
		     zIndex: 0,	// [init()]
		     bufferingCallback: {
			     onbufferingstart : onBufferingStart,
			     onbufferingprogress : onBufferingProgress,
			     onbufferingcomplete : onBufferingComplete,
			     onstreaminfoready : onStreamInfoReady,
			     onrenderingstart : onRenderingStart
		     },
		     playCallback: {
			     oncurrentplaytime : onCurrentPlayTime,
			     onresolutionchanged : onResolutionChange,
			     onstreamcompleted : onStreamComplete,
			     onseekcompleted : onSeekComplete,
			     onerror : onRederingError,
			     onasmpause : onAsmPause,
			     onasmresume : onAsmResume,
		     },
		     displayRect: {	// SRect instance [init()]
			     top: 100,
			     left : 100,
			     width : 200,
			     height : 200
		     },
		     autoRatio: true,	// [STREAM_INFO_READY]
		     frontPanelLock: false // Front panel ?? ??. MP3 ??? ???? ??? ?? ??
	     }
	     */
		
		// Parameter Type Checking
		if (_isType(option, 'object')) {				
			if (_isType(option.bufferingCallback, 'object')) {
				if (
					!_isType(option.bufferingCallback.onbufferingstart, 'undefined|function') ||
					!_isType(option.bufferingCallback.onbufferingprogress, 'undefined|function') ||
					!_isType(option.bufferingCallback.onbufferingcomplete, 'undefined|function') ||
					!_isType(option.bufferingCallback.onstreaminfoready, 'undefined|function') ||
					!_isType(option.bufferingCallback.onrenderingstart, 'undefined|function')
				) {
					Log.e("--->> Player init bufferingCallback InvalidValuesError");
				}
			}
			
			if (_isType(option.playCallback, 'object')) {
				if (
					!_isType(option.playCallback.oncurrentplaytime, 'undefined|function') ||
					!_isType(option.playCallback.onresolutionchanged, 'undefined|function') ||
					!_isType(option.playCallback.onstreamcompleted, 'undefined|function') ||
					!_isType(option.playCallback.onseekcompleted, 'undefined|function') ||
					!_isType(option.playCallback.onerror, 'undefined|function') || 
					!_isType(option.playCallback.onasmpause, 'undefined|function') || 
					!_isType(option.playCallback.onasmresume, 'undefined|function')
				) {
					Log.e("--->> Player init playCallback InvalidValuesError");
				}
			}
		}
		else {
			if (!_isType(option, 'undefined|null')) {
				Log.e("--->> Player init InvalidValuesError");
			}
		}
		// Parameter Type Checking End
		oInitOption = option || {};
		try{
			Log.e("--->> [Player" + id + "] init( option : " + String(option) + ")");

			if (ePlayerPlugin) { // ?? Player Object? ??
				Log.e("--->> [Player" + id + "] Destroy ePlayerPlugin( option : " + String(option) + ")");
				this.close(); // Play() ???? DOM? ??? ???.				
				ePlayerPlugin = null;
			}
			ePlayerPlugin = new Sef();
			
			if (ePlayerPlugin) {
			
				ret = ePlayerPlugin.open("Player", "1.120", "Player" + id);
				Log.e("--->> [Player" + id + "] open():"+ ret);
				bOpened = true;
			}
			else
			{
				return false;
			}
			
			if (oInitOption.displayRect) {
				this.setDisplayArea(oInitOption.displayRect.top, oInitOption.displayRect.left, oInitOption.displayRect.width, oInitOption.displayRect.height, 1080);
			}
			else {				
				Log.e('[Player'+id+'] !WARNNING! > You did Not set displayRect.');
				return false;
			}
			
			
			if (oInitOption.autoRatio !== undefined) {
				bAutoRatio = oInitOption.autoRatio;
			}
			if (this.status == PlayerState.PLAY_STATE_IDLE) {
				this.status = PlayerState.PLAY_STATE_INITIALIZED;
			}
			//this.setDisplayArea(0, 0, 1920, 1080, 1080);
			var evtListener = new _onPlayerPluginEvent(id, this);
			ePlayerPlugin.onEventCallback = function () {        
                evtListener.onEvent.apply(evtListener, arguments);
            };
		
		} catch(e) {
			Log.e("--->> [Player" + id + "] Error init( " + e + ")");
			return false;
		}
		return true;
	},
	this.initAsync = function(option, OpenCallback) {
		Log.e("[player]initAsync start");
		// Parameter Type Checking
		if (_isType(option, 'object')) {				
			if (_isType(option.bufferingCallback, 'object')) {
				if (
					!_isType(option.bufferingCallback.onbufferingstart, 'undefined|function') ||
					!_isType(option.bufferingCallback.onbufferingprogress, 'undefined|function') ||
					!_isType(option.bufferingCallback.onbufferingcomplete, 'undefined|function') ||
					!_isType(option.bufferingCallback.onstreaminfoready, 'undefined|function') ||
					!_isType(option.bufferingCallback.onrenderingstart, 'undefined|function')
				) {
					Log.e("--->> Player init bufferingCallback InvalidValuesError");
				}
			}
			
			if (_isType(option.playCallback, 'object')) {
				if (
					!_isType(option.playCallback.oncurrentplaytime, 'undefined|function') ||
					!_isType(option.playCallback.onresolutionchanged, 'undefined|function') ||
					!_isType(option.playCallback.onstreamcompleted, 'undefined|function') ||
					!_isType(option.playCallback.onseekcompleted, 'undefined|function') ||
					!_isType(option.playCallback.onerror, 'undefined|function')
				) {
					Log.e("--->> Player init playCallback InvalidValuesError");
				}
			}
		}
		else {
			if (!_isType(option, 'undefined|null')) {
				Log.e("--->> Player init InvalidValuesError");
			}
		}
		// Parameter Type Checking End
		oInitOption = option || {};
		try{
			Log.e("--->> [Player" + id + "] init( option : " + String(option) + ")");
			
			if (ePlayerPlugin) { // ?? Player Object? ??
				Log.e("--->> [Player" + id + "] Destroy ePlayerPlugin( option : " + String(option) + ")");
				this.close(); // Play() ???? DOM? ??? ???.				
				ePlayerPlugin = null;
			}
			
			ePlayerPlugin = new Sef();
			if (ePlayerPlugin)
			{
				ePlayerPlugin.openAsync("Player", "1.120", "Player" + id, function(is_success){
					Log.e("[player]Player is_success:"+is_success);
					exports.player.bOpened = is_success;
					OpenCallback(exports.player.bOpened);
				});
			}
			else
			{
				return false;
			}
			
			if (oInitOption.displayRect) {
				this.setDisplayArea(oInitOption.displayRect.top, oInitOption.displayRect.left, oInitOption.displayRect.width, oInitOption.displayRect.height, 1080);
			}
			else {				
				Log.e('[Player'+id+'] !WARNNING! > You did Not set displayRect.');
				return false;
			}
			
			
			if (oInitOption.autoRatio !== undefined) {
				bAutoRatio = oInitOption.autoRatio;
			}
			if (this.status == PlayerState.PLAY_STATE_IDLE) {
				this.status = PlayerState.PLAY_STATE_INITIALIZED;
			}
			//this.setDisplayArea(0, 0, 1920, 1080, 1080);
			var evtListener = new _onPlayerPluginEvent(id, this);
			ePlayerPlugin.onEventCallback = function () {        
                evtListener.onEvent.apply(evtListener, arguments);
            };
			
		} catch(e) {
			Log.e("--->> [Player" + id + "] Error init( " + e + ")");
			return false;
		}
		return true;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn open
	 * @description Player open
	 * @param Json Object
	 * @returns
	 */
	this.open = function(url, option) {
		/*
         * option = {
             totalBufferSize: 10240000, // [play()]
             pendingBufferSize: 10240000,   // [play()]
             initialBufferSize: 10240000,   // [play()]
             adaptive: {
                 type: ,
                 bitrates: ,
                 upTimer: ,
                 startBitrate: ,
                 startTime: ,
                 admode: ,
             },
             drm: {
                 type: ,
                 company: ,
                 deviceID: ,
                 deviceType: ,
                 streamID: ,
                 drmURL: ,
                 ackURL: ,
                 heartbeatPeriod: ,
                 portal: ,
                 userData: ,
                 cookie: 
             },
             macrovision: {
                 type: webapis.avplay.APS_ALL_OFF, // macrovision? ???? ?? macrovisionType, ict, vbi ?? ?? ??? ?. [STREAM_INFO_READY]
                 ict: webapis.avplay.ICT_ON, // [STREAM_INFO_READY]
                 dot: ,
                 vbi: webapis.avplay.CGMS_COPY_FREE, // CGMS type ? ???? ???? [STREAM_INFO_READY]
             },
             subtitle: {
                 path: ,
                 streamID: ,
                 sync: ,
                 callback: 
             }
             
             // ??
             mode3D: webapis.displaycontrol.MODE_3D_EFFECT_SIDE_BY_SIDE, [play()] // [120406] IDL? ?? ??
             authHeader: // 'basic' or 'none' (Default: 'basic')
         * }
         */
		 var iurl = String(url);
		 
		 if (
		            !_isType(iurl, 'string') ||
		            !_isType(option, 'undefined|object|null')
		        ) {	       
				Log.e("--->> Player Open TYPE_MISMATCH_ERR");
		        }
				
				if (_isType(option, 'object')) {				
		            if (
		                !_isType(option.totalBufferSize, 'undefined|number') ||
		                !_isType(option.pendingBufferSize, 'undefined|number') ||
		                !_isType(option.initialBufferSize, 'undefined|number') ||
		                !_isType(option.adaptive, 'undefined|object') ||
		                !_isType(option.drm, 'undefined|object') ||
		                !_isType(option.macrovision, 'undefined|object') ||
		                !_isType(option.subtitle, 'undefined|object') ||
		                !_isType(option.mode3D, 'undefined|number') ||
		                !_isType(option.authHeader, 'undefined|string') 
		            ) {	           
		           Log.e("--->> Player Open TYPE_MISMATCH_ERR");
		            }
					
					if (_isType(option.adaptive, 'object')) {
						if (
							!_isType(option.adaptive.type, 'string') ||
							!_isType(option.adaptive.bitrates, 'undefined|string') ||
							!_isType(option.adaptive.upTimer, 'undefined|string') ||
							!_isType(option.adaptive.startBitrate, 'undefined|string') ||
							!_isType(option.adaptive.startTime, 'undefined|string') ||
							!_isType(option.adaptive.admode, 'undefined|string')
						) {						
							Log.e("--->> Player Open TYPE_MISMATCH_ERR");
						}
					}
					
					if (_isType(option.drm, 'object')) {
						if (
							!_isType(option.drm.type, 'string') ||
							!_isType(option.drm.company, 'undefined|string') ||
							!_isType(option.drm.deviceID, 'undefined|string') ||
							!_isType(option.drm.deviceType, 'undefined|string') ||
							!_isType(option.drm.streamID, 'undefined|string') ||
							!_isType(option.drm.drmURL, 'undefined|string') ||
							!_isType(option.drm.ackURL, 'undefined|string') ||
							!_isType(option.drm.heartbeatPeriod, 'undefined|string') ||
							!_isType(option.drm.portal, 'undefined|string') ||
							!_isType(option.drm.userData, 'undefined|string') ||
							!_isType(option.drm.cookie, 'undefined|string')
						) {						
							Log.e("--->> Player Open TYPE_MISMATCH_ERR");
						}
					}
					
					if (_isType(option.macrovision, 'object')) {
						if (
							!_isType(option.macrovision.type, 'undefined|number') ||
							!_isType(option.macrovision.ict, 'undefined|number') ||
							!_isType(option.macrovision.dot, 'undefined|number') ||
							!_isType(option.macrovision.vbi, 'undefined|number')
						) {						
							Log.e("--->> Player Open TYPE_MISMATCH_ERR");
						}
					}
					
					if (_isType(option.subtitle, 'object')) {
						if (
							!_isType(option.subtitle.path, 'string') ||
							!_isType(option.subtitle.streamID, 'number') ||
							!_isType(option.subtitle.sync, 'undefined|number') ||
							!_isType(option.subtitle.callback, 'function')
						) {
							Log.e("--->> Player Open TYPE_MISMATCH_ERR");
						}
					}
		        }
	
		if (!bOpened) {				
			Log.e('[AVPlay'+id+'] Do init() first..');
			return false;
		};
		if (this.status == PlayerState.PLAY_STATE_STOPPED || 
				this.status == PlayerState.PLAY_STATE_INITIALIZED) {
		
			Log.e("--->> [Player" + id + "] open(" + url + ")");
			Log.e("--->> [Player" + id + "] ePlayerPlugin(" + ePlayerPlugin + ")");
			var result = ePlayerPlugin.execute("InitPlayer", iurl);
			this.status = PlayerState.PLAY_STATE_PREPARED;
			
			if(result){
				Log.e("--->> Open complete");
				return result; 
			}
		}else{
			Log.e("--->> Player Open INVALID_STATE_ERR"+ this.State2String[this.status] );
			return 'Failed to handle the Execute call.';
		}
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn play
	 * @description Player play
	 * @param number
	 * @returns
	 */
	this.play = function(sec) {
		var isec = _checkNumberType(sec);
		Log.e("--->> [Player" + id + "] play(" + isec + ")");
		if(isec < 0) {
			Log.e("--->> Player play InvalidValuesError");
			this.status = PlayerState.PLAY_STATE_STOPPED;
			return;					
		} 
		
		if (!bOpened) {				
			Log.e('-->[Player'+id+'] Do init() first..');
			return false;
		};
		if (this.status != PlayerState.PLAY_STATE_PREPARED) {
			Log.e('-->[Player'+id+'] !THROW ERROR! INVALID_STATE_ERR'); 
            return;
        }
		
		if (oPlayOption.totalBufferSize) { // oInitOption -> totalBufferSize ??
			this.setTotalBufferSize(oPlayOption.totalBufferSize);
		}
		if (oPlayOption.pendingBufferSize) {
			this.setPendingBufferSize(oPlayOption.pendingBufferSize);
		}
		if (oPlayOption.initialBufferSize) {
			this.setInitialBufferSize(oPlayOption.initialBufferSize);
		}
		       
		
        var retValue = ePlayerPlugin.execute("StartPlayback", String(isec));
        
        if (retValue == -1) {
      	Log.e("--->> Player play UnknownError");
     	this.status = PlayerState.PLAY_STATE_STOPPED;
      	return;
		}
			
		
		this.status = PlayerState.PLAY_STATE_STARTED;
		return retValue;
		
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn stop
	 * @description Player stop
	 * @param
	 * @returns
	 */
	this.stop = function() {
		if (bOpened) {
			
			Log.e("--->> [Player" + id + "] stop()");
			if (self.macrovision) {	// widget has to clear to level 0 before widget calls 'Stop', if widget set macrovision level.
				self.setMacrovision(self.APS_ALL_OFF);	// 0: APS_ALL_OFF, 
			}
			this.status = PlayerState.PLAY_STATE_STOPPED;
			return ePlayerPlugin.execute("Stop"); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn pause
	 * @description Player pause
	 * @param
	 * @returns
	 */
	this.pause = function() {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] Pause()");
		this.status = PlayerState.PLAY_STATE_PAUSED;
		return ePlayerPlugin.execute("Pause"); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn resume
	 * @description Player resume
	 * @param
	 * @returns
	 */
	this.resume = function() {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] Resume()");
		this.status = PlayerState.PLAY_STATE_STARTED;
		return ePlayerPlugin.execute("Resume"); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn seek
	 * @description Player seek
	 * @param sec
	 * @returns
	 */
	this.seek = function(sec) {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] Seek()");
		return ePlayerPlugin.execute("Seek",sec); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn jumpForward
	 * @description Player jumpForward
	 * @param offset
	 * @returns
	 */
	this.jumpForward = function(sec) {
		var isec = _checkNumberType(sec);
        if(isec < 0) {
       Log.e("--->> Player play InvalidValuesError");
			return;					
		} 
		if (bOpened) {
		Log.e("--->> [Player" + id + "] JumpForward()");
		return ePlayerPlugin.execute("JumpForward", String(isec)); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn jumpBackward
	 * @description Player jumpBackward
	 * @param offset
	 * @returns
	 */
	this.jumpBackward = function(sec) {
		var isec = _checkNumberType(sec);
        if(isec < 0) {
       Log.e("--->> Player play InvalidValuesError");
			return;					
		} 
		if (bOpened) {
		Log.e("--->> [Player" + id + "] JumpBackward()");
		return ePlayerPlugin.execute("JumpBackward",String(isec)); // 1: success,
																// -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn setPlaybackSpeed
	 * @description Player setPlaybackSpeed
	 * @param speed
	 * @returns
	 */
	this.setPlaybackSpeed = function(speed) {
		var ispeed = _checkNumberType(speed);
		if (bOpened) {
		Log.e("--->> [Player" + id + "] SetPlaybackSpeed()");
		this.status = PlayerState.PLAY_STATE_STARTED;
		return ePlayerPlugin.execute("SetPlaybackSpeed",String(speed)); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn getDuration
	 * @description Player getDuration
	 * @param duration
	 * @returns
	 */
	this.getDuration = function() {
		if (bOpened) {
			Log.e("--->> [Player" + id + "] GetDuration()");
			var result = ePlayerPlugin.execute("GetDuration");
			Log.e("-------------------------------------- typeof >>>>>"+ typeof result);
			return ePlayerPlugin.execute("GetDuration"); // 1: success,
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn setVolume
	 * @description Player setVolume
	 * @param level
	 * @returns
	 */
	this.setVolume = function(level) {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] SetVolume()");
		return ePlayerPlugin.execute("SetVolume", level); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn getState
	 * @description Player getState
	 * @param 
	 * @returns
	 */
	this.getState = function() {
		if(ePlayerPlugin){
			try{
				Log.e("--->> [Player" + id + "] GetState()");
				return ePlayerPlugin.execute("GetState"); // 1: success, -1:
			}catch(e){
				Log.e("--->> [Player" + id + "] GetState Error():"+e);
			}
		
		}
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn setSoundType
	 * @description Player setSoundType
	 * @param
	 * @returns
	 */
	this.setSoundType = function(soundType) {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] SetSoundType()");
		return ePlayerPlugin.execute("SetSoundType", soundType); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn setAudioLatencyMode
	 * @description Player setAudioLatencyMode
	 * @param audioLatencyMode
	 * @returns
	 */
	this.setAudioLatencyMode = function(audioLatencyMode) {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] SetAudioLatencyMode()");
		return ePlayerPlugin.execute("SetAudioLatencyMode", audioLatencyMode); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn getPlayingTime
	 * @description Player getPlayingTime
	 * @param
	 * @returns
	 */
	this.getPlayingTime = function() {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] GetPlayingTime()");
		return ePlayerPlugin.execute("GetPlayingTime"); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},

	/** 
	 * @author jieun24@samsung.com
	 * @description ??? ????? ?????? ????.
	 * @params Type(Number), StrParam(String), NumParam(Number)
	 * @returns true/false(Boolean)
	 */
	this.setPlayerProperty = function(type, strParam, numParam) {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] SetPlayerProperty()");
		return ePlayerPlugin.execute("SetPlayerProperty", String(type), String(strParam), String(numParam));
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn setLooping
	 * @description Player setLooping
	 * @param isLooping
	 * @returns
	 */
	this.setLooping = function(isLooping) {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] SetLooping()");
		return ePlayerPlugin.execute("SetLooping", isLooping); // 1: success, -1:
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author .jieun24.lee@samsung.com
	 * @memberof exports.player
	 * @fn setAppID
	 * @description PlayerEMP? ???? App ID ? Widget ID? ????.
	 * @param string appID, string strWidgetID
	 * @returns boolean
	 */
	this.setAppID = function(appID, strWidgetID) {
		if (bOpened) {
		Log.e("--->> [Player" + id + "] setAppID()");
		var result = ePlayerPlugin.execute("SetAppID",appID,strWidgetID);
		Log.e("--->> [Player" + id + "] setAppID() result :"+result);
		return result;
		}
		return 'Failed to handle the Execute call.';
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @memberof exports.player
	 * @fn setDisplayArea
	 * @description Player setDisplayArea
	 * @param x, y, width, height
	 * @returns
	 */
	//int x, int y, int width, int height, int baseRes, bool bAutoResume
	this.setDisplayArea = function(x, y, width, height, baseRes) {
		if (bOpened) {
			 var set = ePlayerPlugin.execute("SetDisplayArea", String(x), String(y), String(width), String(height),String(baseRes||1080));
			 Log.e("--->> [Player" + id + "] setDisplayArea(" + set + ")");
			 return set;
		}
		return 'Failed to handle the Execute call.';

	},	
	this.getVideoResolution = function () {
		var retValue = null;
		if (ePlayerPlugin) {
			retValue = ePlayerPlugin.execute("GetVideoResolution");	// x: success, -1: fail
		}
		else {
			//retValue = ePlayerPlugin.GetVideoWidth() + '|' + ePlayerPlugin.GetVideoHeight();	// EMP Player ??? ??
		}
		Log.e('--->>[Player'+id+'] getVideoResolution() returns ' + retValue);
		return retValue;
	},	
	this.onEvent = function (type, param, param2){
		Log.e("mycallback-----------------------------------------------------------------------------------------------------------!!")
		Log.e('[Player'+id+'] onEvent('+type+','+param+','+param2+') -> ' + this.Event2String[type]);
		switch(type){
		case PlayerState.STREAM_INFO_READY:
			var resolution = this.getVideoResolution();	
			if (typeof resolution == 'string') {
				resolution = resolution.split('|');	// '1280|720'
				
				// oPlayOption.displayArea ? ??? ??, autoRatio flag ??
				if (oInitOption.displayRect) {	// oPlayOption -> displayArea ??
					this.setDisplayArea(oInitOption.displayRect.top, oInitOption.displayRect.left, oInitOption.displayRect.width, oInitOption.displayRect.height, 1080);
				}
				else if (bAutoRatio) {// fullscreen
					this.setDisplayArea(0,0,scene.width,scene.height);
				}
			}
			else {
			}
			if (oInitOption.bufferingCallback) {	// oInitOption -> onstreaminfoready ??
				if (typeof oInitOption.bufferingCallback.onstreaminfoready == 'function') {
					oInitOption.bufferingCallback.onstreaminfoready(param);
				}
			}
			break;
		case PlayerState.BUFFERING_START:
			if (this.status == PlayerState.PLAY_STATE_STOPPED) {
				Log.e('[player'+id+'] This BUFFERING_START event occured after stop() call. skip.');
				return;
			}
			if (oInitOption.bufferingCallback) {	// oInitOption -> onbufferingstart ??
				if (typeof oInitOption.bufferingCallback.onbufferingstart == 'function') {
					oInitOption.bufferingCallback.onbufferingstart(param);
				}
			}
			
			break;
		case PlayerState.BUFFERING_PROGRESS:
			if (this.status == PlayerState.PLAY_STATE_STOPPED) {
				Log.e('[player'+id+'] This BUFFERING_PROGRESS event occured after stop() call. skip.');
				return;
			}
			if (oInitOption.bufferingCallback) {	// oInitOption -> onbufferingstart ??
				if (typeof oInitOption.bufferingCallback.onbufferingprogress == 'function') {
					oInitOption.bufferingCallback.onbufferingprogress(param);
				}
			}
			break;
		case PlayerState.BUFFERING_COMPLETE:
			if (oInitOption.bufferingCallback) {	// oInitOption -> onbufferingcomplete ??
				if (typeof oInitOption.bufferingCallback.onbufferingcomplete == 'function') {
					oInitOption.bufferingCallback.onbufferingcomplete(param);
				}
			}
			break;
		case PlayerState.RENDERING_START:
			if (this.status == PlayerState.PLAY_STATE_STOPPED) {
				Log.e('[player'+id+'] This RENDERING_START event occured after stop() call. skip.');
				return;
			}
			if (oInitOption.bufferingCallback) {	// oInitOption -> onstreaminfoready
				if (typeof oInitOption.bufferingCallback.onrenderingstart == 'function') {
					oInitOption.bufferingCallback.onrenderingstart(param);
				}
			}			
			break;
		case PlayerState.CURRENT_PLAYBACK_TIME:	
			if (this.status == PlayerState.PLAY_STATE_STOPPED) {
				Log.e('[player'+id+'] This CURRENT_PLAYBACK_TIME event is not occured on "PLAY_STATE_STARTED". skip..');
				return;
			}
			if (oInitOption.playCallback) {	// oInitOption -> oncurrentplaytime ??
				if (typeof oInitOption.playCallback.oncurrentplaytime == 'function') {
					oInitOption.playCallback.oncurrentplaytime(param);
				}
			}
			break;
		case PlayerState.RENDERING_COMPLETE:
			//Volt.setTimeout(function(){ 
				this.stop();
				if (oInitOption.playCallback) {	// oInitOption -> onstreamcompleted ??
					if (typeof oInitOption.playCallback.onstreamcompleted == 'function') {
						oInitOption.playCallback.onstreamcompleted(param);
					}
				}
			//}, 0);
			break;
		case PlayerState.ASM_TO_PAUSE:
				if (oInitOption.playCallback) {	// oInitOption -> onasmpause ??
					if (typeof oInitOption.playCallback.onasmpause == 'function') {
						oInitOption.playCallback.onasmpause(param);
					}
				}		
			break;
		case PlayerState.ASM_READY_TO_RESUME:
				if (oInitOption.playCallback) {	// oInitOption -> onasmresume ??
					if (typeof oInitOption.playCallback.onasmresume == 'function') {
						oInitOption.playCallback.onasmresume(param);
					}
				}		
			break;			
		case PlayerState.CONNECTION_FAILED:
		case PlayerState.STREAM_NOT_FOUND:
			this.stop();
			if (typeof oInitOption.playCallback.onerror == 'function') {
				oInitOption.playCallback.onerror("NOT_FOUND_ERR");
			}
			break;
		case PlayerState.AUTHENTICATION_FAILED:
			this.stop();
			if (typeof oInitOption.playCallback.onerror == 'function') {
				oInitOption.playCallback.onerror("SECURITY_ERR");
			}
			break;
		case PlayerState.NETWORK_DISCONNECTED:
			this.stop();
			if (typeof oInitOption.playCallback.onerror == 'function') {
				oInitOption.playCallback.onerror("NETWORK_ERR");
			}
			break;
		case PlayerState.NETWORK_SLOW:
			this.stop();
			if (typeof oInitOption.playCallback.onerror == 'function') {
				oInitOption.playCallback.onerror("NetworkSlowError");
			}
			break;
		case PlayerState.RENDER_ERROR:
			this.stop();
			if (oInitOption.playCallback) {
				if (typeof oInitOption.playCallback.onerror == 'function') {
					oInitOption.playCallback.onerror(param);
					/*
					switch (Number(data)) {
						case PlayerState.UNKNOWN_ERROR:
							oInitOption.playCallback.onerror("UnknownError");
							break;
						case PlayerState.UNSUPPORTED_CONTAINER:
							oInitOption.playCallback.onerror("PlayerUnsupportedContainerError");
							break;
						case PlayerState.UNSUPPORTED_VIDEO_CODEC:
							oInitOption.playCallback.onerror("PlayerUnsupportedVideoFormatError");
							break;
						case PlayerState.UNSUPPORTED_AUDIO_CODEC:
							oInitOption.playCallback.onerror("PlayerUnsupportedAudioFormatError");
							break;
						case PlayerState.UNSUPPORTED_VIDEO_RESOLUTION:
							oInitOption.playCallback.onerror("PlayerUnsupportedVideoResolutionError");
							break;
						case PlayerState.UNSUPPORTED_VIDEO_FRAMERATE:
							oInitOption.playCallback.onerror("PlayerUnsupportedVideoFramerateError");
							break;
						case PlayerState.CURRUPTED_STREAM:
							oInitOption.playCallback.onerror("PlayerCurruptedStreamError");
							break;
						default:
							Log.e('[Player'+id+'] !ERROR! No detail category..');
							oInitOption.playCallback.onerror("UnknownError");
							break;
					}
					*/
				}
			}
			break;
		case PlayerState.CUSTOM_ERROR:
			this.stop();
			if (typeof oInitOption.playCallback.onerror == 'function') {
				oInitOption.playCallback.onerror({"CustomError":param});
			}
			break;
		case PlayerState.RTSP_STATE:
			if (typeof oInitOption.playCallback.onerror == 'function') {
				oInitOption.playCallback.onerror({"RTSPState":param});
			}
			break;	
		case PlayerState.AD_START:
		case PlayerState.AD_END:
			break;
		case PlayerState.RESOLUTION_CHANGED:
			if (oInitOption.playCallback) {	// oInitOption -> onresolutionchanged ??
				if (typeof oInitOption.playCallback.onresolutionchanged == 'function') {
					var resolution = this.getVideoResolution().split('|');	// '1280|720'
					oInitOption.playCallback.onresolutionchanged(resolution[0], resolution[1]);
				}
			}
			break;
		case PlayerState.BITRATE_CHANGED:
		case PlayerState.CUSTOM:
			break;
		case PlayerState.SUBTITLE:
			break;
		case PlayerState.SEEK_COMPLETED:
			if (oInitOption.playCallback) {	// oInitOption -> onstreamcompleted ??
				if (typeof oInitOption.playCallback.onseekcompleted == 'function') {
					oInitOption.playCallback.onseekcompleted(param);
				}
			}
			break;
		default:
			break; 
		}
	}

	this.setTotalBufferSize = function (bytes) {
		var retValue = null;
		if (ePlayerPlugin) {
			retValue = ePlayerPlugin.execute("SetTotalBufferSize", bytes);	// 1: success, -1: fail
			Log.e('[AVPlay'+id+'] setTotalBufferSize('+bytes+') returns ' + (retValue == 1));
		}
		return retValue == 1;
	}
	this.setInitialBufferSize = function (bytes) {
		var retValue = null;
		if (ePlayerPlugin) {
			retValue = ePlayerPlugin.execute("SetInitialBufferSize", bytes);	// 1: success, -1: fail
		}
		else {
			retValue = ePlayerPlugin.execute("SetInitialBuffer", bytes);	// 1: success, -1: fail
		}
		Log.e('[AVPlay'+id+'] setInitialBufferSize('+bytes+') returns ' + (retValue == 1));
		return retValue == 1;
	}
	this.setPendingBufferSize = function (bytes) {
		var retValue = null;
		if (ePlayerPlugin) {
			retValue = ePlayerPlugin.execute("SetPendingBufferSize", bytes);	// 1: success, -1: fail
		}
		else {
			retValue = ePlayerPlugin.execute("SetPendingBuffer", bytes);	// 1: success, -1: fail
		}
		Log.e('[AVPlay'+id+'] setPendingBufferSize('+bytes+') returns ' + (retValue == 1));
		return retValue == 1;
	}
}
function _onPlayerPluginEvent(id, player) {
	var sName = 'Player' + id;	// Instance name
	this.iPlayer = player;
	this.setMasterObject = function(player){
		this.iPlayer = player;
	}
	this.onEvent = function(type, param, param2){
		Log.e('--->> [Player'+id+'] _onPlayerPluginEvent('+type+','+param+','+param2+') -> '
				+ this.iPlayer.Event2String[type]);
		 this.iPlayer.onEvent(type, param, param2);
	}
}


/**
 * @namespace Time
 */
exports.Time = {	
	m_bOpened : false,
	init : function() {
		Log.e("[Time]init start");
		this.m_bOpened = sefFactory.init("Time");
		Log.e("[Time]m_bOpened:"+this.m_bOpened);
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[Time]initAsync start");
		sefFactory.initAsync("Time", function(is_success){
			Log.e("[Time]Time is_success:"+is_success);
			exports.Time.m_bOpened = is_success;
			OpenCallback(exports.Time.m_bOpened);
		});
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("Time");
		this.m_bOpened = false;
	},
	/**
	 * @author sumin_.park@samsung.com
	 * @fn getEpochTime
	 * @description
	 * @param
	 * @returns
	 */
	getEpochTime : function() {		
		Log.e(" --->> getEpochTime();");
		return sefFactory.getSEF("Time").execute("GetEpochTime");
	}
};



/**
 * @namespace DMRAudioPlayer
 */
exports.DMRAudioPlayer = {	
	
	STATE_STOPPED : "0",
	STATE_TRANSITIONING : "1",
	STATE_PLAYING : "2",
	STATE_PAUSED : "3",
	
	STOPPED_REASON_END_OF_PLAYING : "0",
	STOPPED_REASON_USER_INTERRUPT : "1",
	STOPPED_REASON_ERROR : "2",
	STOPPED_REASON_EXTERNAL_REQUEST : "3",
	STOPPED_REASON_UNKNOWN : "4",
	
	DMR_AUDIO_PLAYER_EMP_ATTACH_SUCCESS: "1",
    	DMR_AUDIO_PLAYER_EMP_ATTACH_FAIL: "2",
    	DMR_AUDIO_PLAYER_EMP_PAUSE: "3",
   	DMR_AUDIO_PLAYER_EMP_PLAY: "4",
   	DMR_AUDIO_PLAYER_EMP_STOP: "5",
   	DMR_AUDIO_PLAYER_EMP_SEEK_TIME: "6",
    	DMR_AUDIO_PLAYER_EMP_GET_ITEM_DURATION: "7",
    	DMR_AUDIO_PLAYER_EMP_GET_ITEM_PLAYING_POSITION: "8",
   	DMR_AUDIO_PLAYER_EMP_GET_PLAYING_STATE: "9",
	
	
	m_bOpened : false,
	init : function() {
		Log.e("[DMRAudioPlayer]init start");
		this.m_bOpened = sefFactory.init("DmrAudio");
		Log.e("[DMRAudioPlayer]m_bOpened:"+this.m_bOpened);
		sefFactory.getSEF("DmrAudio").onEventCallback = DmrAudioCallback;
		return this.m_bOpened;
	},
	initAsync : function(OpenCallback) {
		Log.e("[DMRAudioPlayer]initAsync start");
		sefFactory.initAsync("DmrAudio", function(is_success){
			Log.e("[DMRAudioPlayer]DmrAudio is_success:"+is_success);
			exports.DMRAudioPlayer.m_bOpened = is_success;
			OpenCallback(exports.DMRAudioPlayer.m_bOpened);
		});
		
		sefFactory.getSEF("DmrAudio").onEventCallback = DmrAudioCallback;
	},
	isOpened : function() {
		return this.m_bOpened;
	},
	destroy : function() {
		Log.e(" --->> destroy();");
		sefFactory.releaseSEF("DmrAudio");
		this.m_bOpened = false;
	},
	/**
	 * @author yj14.lee@samsung.com
	 * @fn attachAudioPlayer
	 * @description Provide information of DLNA/UPnP devices in the network.
	 * @param void
	 * @returns bool
	 */
	attachAudioPlayer : function(playerInstanceId) {		
		Log.e(" --->> attachAudioPlayer();");
		try{
			return sefFactory.getSEF("DmrAudio").execute("dmr_attach_audio_player", playerInstanceId);
		}catch(e){
			return "failed emp execute";
		}
	},
	/**
	 * @author yj14.lee@samsung.com
	 * @fn detachAudioPlayer
	 * @description Unbinding audio player from DMR.
	 * @param void
	 * @returns bool
	 */
	detachAudioPlayer : function() {		
		Log.e(" --->> detachAudioPlayer();");
		return sefFactory.getSEF("DmrAudio").execute("dmr_detach_audio_player");
	},
	/**
	 * @author yj14.lee@samsung.com
	 * @fn setEventCallback
	 * @description Set a callback with DMR service which will notify when DMR received new request from network.
	 * @param void
	 * @returns bool
	 */
	setEventCallback : function() {		
		Log.e(" --->> set_event_callback();");
		return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_set_event_callback");
	},
	/**
	 * @author yj14.lee@samsung.com
	 * @fn notifyItemDuration
	 * @description Notify DMR about duration of current audio item when this information became available.
	 * @param milliseconds - number
	 * @returns bool
	 */
	notifyItemDuration : function(milliseconds) {		
		Log.e(" --->> notify_item_duration();");
		return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_item_duration", String(milliseconds));
	},
	/**
	 * @author yj14.lee@samsung.com
	 * @fn notifyItemPlayingPosition
	 * @description Notify DMR about playing position of current audio item.
	 * @param milliseconds - number
	 * @returns bool
	 */
	notifyItemPlayingPosition : function(milliseconds) {		
		Log.e(" --->> notify_item_playing_position();");
		return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_item_playing_position", String(milliseconds));
	},
	/**
	 * @author yj14.lee@samsung.com
	 * @fn notifyPlayingState
	 * @description Inform DMR service about player�s state.
	 * @param state - enum
	 * @returns bool
	 */
	notifyPlayingState : function(state) {		
		Log.e(" --->> notify_playing_state();");
		return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_playing_state", String(state));
	},
	/**
	 * @author yj14.lee@samsung.com
	 * @fn notifyStoppedReason
	 * @description Inform DMR service about players stopped reason.
	 *				Player should use this API if stopped no by DMR�s request e.g. user termination, errors, end of playing activation of other apps.
	 *
	 * @param reason - enum , details - string
	 * @returns bool
	 */
	notifyStoppedReason : function(reason, details) {		
		Log.e(" --->> notify_stopped_reason();");
		return sefFactory.getSEF("DmrAudio").execute("dmr_audio_player_notify_stopped_reason", String(reason), details);
	},
	
	addEventListener:function(eventType, cb){
		Log.e("---------------------------------------->> addEventListener");
		DmrAudiocbList[String(eventType)] = cb;
	}	
};

var DmrAudiocbList = {};

function DmrAudioCallback(eventType, param1, param2)
{
	Log.e("-----------------------> EVENT:[] " + eventType + param1) ;
	if (typeof DmrAudiocbList[String(eventType)] == "function")
		DmrAudiocbList[String(eventType)](eventType, param1, param2);
}

/**
 * @namespace convertFHD
 */
exports.convertFHD = {	

	/**
	 * @author sunjung.yoo@samsung.com
	 * @fn convertFHD
	 * @description Convert resolution 1080p to 720p
	 * @param 
	 * @returns 
	 */
	 
	convertFHD :function(template) {
	 if (true) {
		  return;
		}
		
	 var scaleFactor = 720.0 / 1080;
	 var convert1080to720 = function(data) {
	   
	   if (data.__is_converted__){
		return;
	   }
		
	   function convertInner(child) {
		if (child == null) {
		 return;
		}
		
		if (typeof child !== "object") {
		 return;
		}
		
		if (typeof child.length !== "undefined" && child.length > 0) {
		 for (var i=0;i<child.length;i++) {
		  var data = child[i];
		  if (typeof data === "object") {
		   convertInner(data);
		   }
		 }
		 return;
		}
		
	   for (var prof in child) {
		 var obj = child[prof];
		 if (prof == "x" || prof == "y" || prof == "width" || prof == "height") {
		  child[prof] = parseFloat(child[prof]) * scaleFactor;
		  Log.d("Converted! " + child[prof]);
		  } 
		 else if (prof == "font") {  
		  var temp = "" + child[prof];
		  var startIndex;
		  var number = ""; 
		  
		  for(var i = 0; i < temp.length; i++){
		   if(temp[i] != ' ' && temp[i] >= 0 && temp[i] <= 9){
			if(startIndex == undefined){
			 startIndex = i;
			 }
			number = number + temp[i] + "";
			}
		  }
		  temp = temp.substring(0, startIndex) +  (number * scaleFactor) + temp.substring(temp.length - number.length ,temp.length);

		  child[prof] = temp;
		  Log.d("Converted! test::" + child[prof]);
		  } 
		 else {
		  if (typeof obj === "object") {
		   // object
		   convertInner(obj);
		   }
		  }
		 }
		} 
	   
	   convertInner(data);
	   data.__is_converted__ = true;
	   }
	   
	   convert1080to720(template);
	}
};
