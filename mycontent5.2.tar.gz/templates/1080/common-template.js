/**
 * @author common module group
 * @fileoverview Common Template for Panel Dev.
 * @date 2014/10/31
 *
 * @version 1.8.5
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var SCREEN_WIDTH = scene.width;
var SCREEN_HEIGHT = scene.height;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var CommonTemplate = {
    // Constants
    TOPMENU_OPACITY_NORMAL: 102,
    TOPMENU_OPACITY_SELECT: 255,

    //
    CATEGORY_ANIM_DURATION: 200,
    CONTENT_ANIM_DURATION: 300,

    //
    HEADER_Y_NORMAL: 0,
    HEADER_Y_SHRINK: -18,

    CATEGORY_Y_NORMAL: 144,
    CATEGORY_HEIGHT_NORMAL: 72,
    CATEGORY_CHILD_Y_NORMAL: 0,

    CATEGORY_Y_EXPAND: 108,
    CATEGORY_HEIGHT_EXPAND: 108,
    CATEGORY_CHILD_Y_EXPAND: 18,

    // for dim
    OPACITY_TRANSPARENCY: 0,
    OPACITY_OPAQUE: 255,
    OPACITY_DIM: 102,

    SCREEN_WIDTH: SCREEN_WIDTH,
    SCREEN_HEIGHT: SCREEN_HEIGHT,

    // Template for DimView
    dim: {
        type: 'DimWindow',
        x: 0,
        y: 0,
        width: mycontentWidth,
        height: 1080,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 153,
        },
    },


}

exports = CommonTemplate;




////////////////////////////////////////////////////////////////////////////////
// DO NOT CROSS
// DEPRECATED CODE STARTS FROM HERE
////////////////////////////////////////////////////////////////////////////////
/*
    dim: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 1920,
        height: 1080,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        opacity: 102,
        children: [
            {
                type: 'widget',
                x: 0,
                y: 0,
                width: 1920,
                height: 1080,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 255
                },
            }, {
                type: 'widget',
                x: 0,
                y: 0,
                width: 1920,
                height: 0,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 255
                },
            }, {
                type: 'widget',
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 255
                },
            }, {
                type: 'widget',
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 255
                },
            }
        ]
    },
*/