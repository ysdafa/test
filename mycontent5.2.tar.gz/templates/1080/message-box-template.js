var MessageBoxTemplate = {
	container : {
	    type: 'widget',
		custom : {
			'focusable' : true,
			'onKeyEvent' : null
		},
	    x: 0, y: 0, width: 1920, height : 1080,
	    color : Volt.hexToRgb('#ffffff',0),
	},
	
	msgbox_template_no_title_one_button:
	{
		type: 'widget',
	    x: 0, y: (1080 - 550) / 2, width: 1920, height : 550,
	    color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type: 'widget',
				id: 'common-message-box-bg',
		    	x: 0, y: 0, width: 1920, height : 550,
		    	color : Volt.hexToRgb('#0a5d88',255),
		    	opacity: 255 * 0.85,
			},
	    	{
		        type : 'text',
				id : 'common-message-box-message',
		        x : 399, y: 48, width : 1122, height : 48*8,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff', 255),
		        text : '{{ message }}',
		        font : '30',
	    	},
			{
				type : 'widget',
				id : 'common-message-box-btn1',
				custom:{'btntext': '{{ btntext1 }}'},
				x : 825, y : 48*8+70, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },
			
	msgbox_template_no_title_two_button:
	{
		type: 'widget',
	    x: 0, y: (1080 - 550) / 2, width: 1920, height : 550,
	    color : Volt.hexToRgb('#ffffff',0),
	    
		children: [
			{
				type: 'widget',
				id: 'common-message-box-bg',
		    	x: 0, y: 0, width: 1920, height : 550,
		    	color : Volt.hexToRgb('#0a5d88',255),
		    	opacity: 255*0.85,
			},
	    	{
		        type : 'text',
				id : 'common-message-box-message',
		        x : 399, y: 48, width : 1122, height : 48*8,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff', 255),
		        text : '{{ message }}',
		        font : '30',
	    	},
			{
				type : 'widget',
				id : 'common-message-box-btn1',
				custom:{'btntext': '{{ btntext1 }}'},
				x : 690, y : 48*8+70, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'common-message-box-btn2',
				custom:{'btntext': '{{ btntext2 }}'},
				x : 980, y : 48*8+70, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },

	msgbox_template_no_title_three_button:
	{
		type: 'widget',
	    x: 0, y: (1080 - 550) / 2, width: 1920, height : 550,
	    color : Volt.hexToRgb('#ffffff',0),
	    
		children: [
			{
				type: 'widget',
				id: 'common-message-box-bg',
		    	x: 0, y: 0, width: 1920, height : 550,
		    	color : Volt.hexToRgb('#0a5d88',255),
		    	opacity: 255*0.85,
			},
	    	{
		        type : 'text',
				id : 'message',
		        x : 399, y: 48, width : 1122, height : 48*8,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff', 255),
		        text : '{{ message }}',
		        font : '30',
	    	},
			{
				type : 'widget',
				id : 'common-message-box-btn1',
				custom:{'btntext': '{{ btntext1 }}'},
				x : 535, y : 48*8+70, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'common-message-box-btn2',
				custom:{'btntext': '{{ btntext2 }}'},
				x : 825, y : 48*8+70, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'common-message-box-btn3',
				custom:{'btntext': '{{ btntext3 }}'},
				x : 1115, y : 48*8+70, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    },
};

exports = MessageBoxTemplate;


