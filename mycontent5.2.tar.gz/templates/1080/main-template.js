var resMgr = Volt.require('app/controller/resource-controller.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
print("mycontentWidth:",mycontentWidth);
var MainTemplate = {
    container: {
        parent: scene,
		id: 'mycontent',
        type: 'widget',
        x: 0, y: 0, width: mycontentWidth, height: 1080,
        color:{r:0, g:0, b:0},
        children: [
            {
                id: 'main-header-container',
                type: 'widget',
                x: 0, y: 0, width: mycontentWidth, height: 1080*0.133333,
                color: Volt.hexToRgb('#0f1826')
            }, {
                id: 'main-category-container',
                type: 'widget',
                x: 0, y: 1080*0.133333, width: mycontentWidth, height: 1080*0.066667,
                color: {r:0, g:0, b:0, a:0}
               // color: Volt.hexToRgb('#0f1826')
            },
            {			
            	id: 'main-category-underbar-container',			
				type: 'widget',			
				x: 0, y: 1080*0.133333, width: mycontentWidth, 
				height: 1,			
				color: Volt.hexToRgb('#ffffff'),
				opacity: 25,
				
			},
            {
                id: 'main-content-container',
                type: 'widget',
                x: 0, y: 1080*0.2, width: mycontentWidth, height: 1080*0.8,
                color: Volt.hexToRgb('#dfdfdf')
	      	},{
                id: 'main-dim-container',
                type: 'widget',
                x: 0, y: 0, width: mycontentWidth, height: 1080,
                color: {r:0, g:0, b:0, a:0}
            }, {
                id: 'main-popup-container',
                type: 'widget',
                x: 0, y: 0, width: mycontentWidth, height: 1080,
                color: {r:0, g:0, b:0, a:0}
            }, {
                id: 'main-popup2-container',
                type: 'widget',
                x: 0, y: 0, width: mycontentWidth, height: 1080,
                color: {r:0, g:0, b:0, a:0}
            }
        ]
    },

	defMainContent: {
        type: 'widget',
        x: 0, y: 0, width: mycontentWidth, height: 864,
        color: Volt.hexToRgb('#e1e1e1'),
        children: [
			{
		        type : 'text',
		        x : mycontentWidth*0.28542, y: 378, width : mycontentWidth-mycontentWidth*0.28542*2, height : 108,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#999999'),
		        text : '{{ message1 }}',
		        font : 'SamsungSmart_Light 34px',
		        ellipsize: true,
		        lineSpacing: 12,
		        custom : {
					multilingual : {
						SID : '',
					}
				},
	    	},
	    	{
		        type : 'text',
		        x : mycontentWidth*0.28542, y: 474, width : mycontentWidth-mycontentWidth*0.28542*2, height : 84,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#999999'),
		        text : '{{ message2 }}',
		        font : 'SamsungSmart_Light 34px',
		        ellipsize: true,
	    	},
		]
  	},

	allDefMainContent: {
	        type: 'widget',
	        x: 0, y: 0, width: mycontentWidth, height: 864,
	        color: Volt.hexToRgb('#e1e1e1'),
	        children: [
				{
			        type : 'text',
			        x : mycontentWidth*0.28542, y: 390, width : mycontentWidth-mycontentWidth*0.28542*2, height : 84,
			        horizontalAlignment : 'center',
			        verticalAlignment : 'center',
			        textColor : Volt.hexToRgb('#999999'),
			        text : '{{ message }}',
			        font : 'SamsungSmart_Light 34px',
			        ellipsize: true,
		    		},
			]
  	},
	category:{
		id: 'CategoryList',
		type: 'cmCategoryTab',
		style: 1,
		x: 0,
        y: 0,
        width: mycontentWidth,
        height: 72,
        color: { r: 242, g: 242, b: 242, a: 0 },
        tabTargetHeightMax:108,
        unFocusHighlightbarHeight: 108,
		focusHighlightbarHeight: 108,
		highlightFocusAnimation: { unfocus: 108, focused: 108, duration: 200 },
		custom: {
            focusable: true
        }
    },
    /*
    category: {
    	id: 'CategoryList',
        type: 'cmCategoryTab',
        custom: {focusable: true},
	    x: 0,
	    y:0,
	    width: 1920,
	    height: 72,
	    color: { r: 242, g: 242, b: 242, a: 0 },
	    
	    margin: { top: 0, bottom: 0, left: 1920 * 0.005208, right: 1920 * 0.005208 },
	    spliterSize: { w: 2, h: 2 },
	    enableLooping: true,
	    tabFont: "Sans 28px",
	    arrowSize: { w: 1920 * 0.035938, h: 34 },
	    leftArrowImage: 'images/1080/Arrow/comn_sub_arrow_left_n.png',
	    rightArrowImage: 'images/1080/Arrow/comn_sub_arrow_right_n.png',
	    highlightbarColor: { r: 30, g: 158, b: 230, a: 255 },
	    spliterColor: { r: 70, g: 70, b: 70, a: 255 },
	//    enableHighlightbar: false,
	//    highlightbarHeight: 1,
	    textMargin: 1920 * 0.020833,
	    textLimit: 280,
	    enableAlignTabsCenter: true,
	    tabTargetHeightMax:108,
	//    highligthFocusAnimation: { unfocus: 5, focused: 90, duration: 200 },
		highligthMoveAnimationDuration : 200,
	  //  highlightbarFocusedColor: { r: 255, g: 255, b: 255, a: 255 },
	  //  highlightbarUnfocusedColor: { r: 30, g: 158, b: 230, a: 255 },
	    focusFrameImagePath: resMgr.getImgPath()+'/common/ksc_focus.png',
      //  highlightFocusAnimation: { unfocus: 1, focused: 0, duration: 0 },
		focusFrameMoveAnimationDuration: 200,
    	enableFocusFrame: true,
    	enableHintBar: true,
	    hintBarColor: { r: 30, g: 158, b: 230, a: 255 },
	    hintBarHeight: 1,
    },
	/*
    category: {
        type: 'text',
        x: 0,
        y: 0,
        width: 1920,
        height: 72,
        children: [
			{
	            id: 'CategoryList',
	            type: 'CategoryTabs',
	            x: 0, y: 0, width: 1920, height: 72,
	             color: {r: 242, g: 242, b: 242},
        
		        expandHeight: 108,
		        lockDuration: 200,
		        
		        separatorWidth: 2,
		        separatorHeight: 2,
		        separatorColor: {r: 0x46, g: 0x46, b: 0x46},
		        arrowWidth: 18,
		        arrowHeight: 34,
		        leftArrowSrc: Volt.getRemoteUrl(resMgr.getImgPath()+'/Arrow/comn_sub_arrow_left_n.png'),
		        rightArrowSrc: Volt.getRemoteUrl(resMgr.getImgPath()+'/Arrow/comn_sub_arrow_right_n.png'),
		        custom: {focusable: true},
	        }
		]
    },*/
   
    plus: {
    	parent: scene,
		//id: 'main-plus-popup',
        type: 'widget',
        x: 0,
        y: 0,
        width: mycontentWidth,
        height: 1080,
        color: Volt.hexToRgb('#000000',0),
        custom: {focusable: true},
        cropOverflow: true,
    },
};

exports = MainTemplate;
