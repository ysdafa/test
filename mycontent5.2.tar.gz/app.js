scene.color = {r: 0, g:0, b:0};

//loadFakeUI();

(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();

var PanelCommon , Backbone, RunTimeInfo, EventMediator, CommonInfo, EventType, launchParams, LaunchedByAppID, 
	AppLauncher, LaunchAppID, EViewType, EViewSwitchAniType, inputController, myContensKey, myConfig,DimType, ViewGlobalData;
var paramData = {};
var FirstActive = true;
var dimType;
var voltapi;

var VCONF_FOCUS_ROOM = 'db/menu/system/accessibility/focuszoom';
var VCONF_HIGH_CONTRACT = 'db/menu/system/accessibility/highcontrast';

/*require modules*/
requireModules();

/**
 * Entry point for Volt application
 */
var initialize = function(){
		Log.e("mycontents initialize performance >>");
		try{
			Log.e('add Memory GC');
			Memory.init(3,102400);	
		}catch(e){
			Log.e('Can not operate Memory.init : ' +e);
		}

		/*after 4 seconds preload photo/video player*/
		//Volt.setTimeout(function(){		
			//print('[app.js]initialize, preload photo player');
	    	//preloadPhotoPlayer();
		//},4000);
		
		//Volt.setTimeout(function(){		
			//print('[app.js]initialize, preload photo player');
	    	//preloadVideoPlayer();
		//},4000);
		
		/*initialize KPI*/
		/*
		Log.e("[app.js]initialize, initialize KPI performance");
		Volt.KPIMapper.init();
		Log.e("[app.js]initialize, initialize KPI finish performance");
		*/
		/*set enlarge/highcontrast/720p*/
		setEnv();

		//print('VDUtil.registerKey()');
		//VDUtil.registerKey();
		setPanelWIdth();
		/*loading the mainview frame*/
		Log.e("mycontents, load Router and mainview frame");
		var Router = Volt.require('app/router.js');
		
		/*add app event listener*/
		Log.e("mycontents, add app event listener list");
		setEventListener();
		
		print('mycontents, Launched by ',launchParams.getLauncherAppName(),'DeviceType : ',launchParams.getDeviceType());
		Backbone.history.start();
		
		/*prepare the first page*/
		print('mycontents, prepare page');
		RunTimeInfo.launchMusicReturnContentOrNot = false;
		AppLauncher.launchedBy(launchParams);
		Volt.log('[app.js]---initial----launchParams is ' + launchParams);
		try 
		{
			Volt.log('[app.js]---initial----launchParams is ' + JSON.stringify(launchParams));
		}
		catch(e)
		{
			Volt.log('[app.js]---initial----launchParams is e ' +e);
		}	


		try 
		{
			Volt.log('[app.js]---initial----launchParams is ' + toJSON(launchParams));
		}
		catch(e)
		{
			Volt.log('[app.js]---initial----launchParams is e ' +e);
		}
		//winset comment
	    Volt.Nav.onKeyEvent = function (keyCode, keyType) {
	        print('mycontents, keyCode: ' + keyCode + ', keyType: ' + keyType);
	        Log.e("mycontents app.js onKeyEvent, keyCode: " + keyCode + ", keyType: " + keyType);
	        if(keyType != Volt.EVENT_KEY_RELEASE){
	        	return ;
	        }
	        
	        if(RunTimeInfo == null || RunTimeInfo == undefined || 
    		   RunTimeInfo.router == null || RunTimeInfo.router == undefined){
    			return ;   	
    		}
	        
	        switch(keyCode){
				case Volt.KEY_PLAY_BACK:			//temp for Volt.KEY_PLAY_BACK
	        	case Volt.KEY_PLAY:
//	        	case Volt.KEY_INFO:
	        	case Volt.KEY_RETURN:{       		
	        		var currView = RunTimeInfo.router.getCurrentView();
					var isDim = RunTimeInfo.router.mainView.isMainViewDim;
					if(currView != null && !isDim){
						Log.e("mycontent app.js call curren view onKeyEvent");
						currView.onKeyEvent(keyCode, keyType);
					}
	        		break;
	        	}
	        	default:{
	        		break;
	        	}
	        }
	    };
	//},300);
//	print('[app]initialize----------------------network wired state : ' + netController.getWiredState() + ', wirelss state : ' + netController.getWirelessState());
	addMagicKeyListener();
	RunTimeInfo.appState = true;
};

function setPanelWIdth(){
	try {
		RunTimeInfo.SceneResolution = HALOUtil.screenWidth;
		if ( RunTimeInfo.SceneResolution == undefined || RunTimeInfo.SceneResolution < 1920 ){
			RunTimeInfo.SceneResolution = 1920;
		}
		RunTimeInfo.offSet = (RunTimeInfo.SceneResolution-1920)/2;
		RunTimeInfo.bFlagFor2560 = (RunTimeInfo.SceneResolution==2560)?true:false;
		print('[setPanelWIdth] RunTimeInfo.bFlagFor2560 is ' + RunTimeInfo.bFlagFor2560);
		if (RunTimeInfo.bFlagFor2560 == true)
		{
			RunTimeInfo.offsetFor2560 = (RunTimeInfo.SceneResolution*(1-0.572917)-820)/2;
			RunTimeInfo.offsetForMusicControl = 100;
			RunTimeInfo.offsetForProgressBar = 20 +10;
			RunTimeInfo.offsetForPrePauseNext = 10 +5;
			RunTimeInfo.offsetForRepeartShuffle = 20+20;
		}
		Log.e("[mycontents RunTimeInfo.SceneResolution:"+RunTimeInfo.SceneResolution + " RunTimeInfo.bFlagFor2560 is " +RunTimeInfo.bFlagFor2560);
		print("[mycontents RunTimeInfo.SceneResolution:"+RunTimeInfo.SceneResolution + " RunTimeInfo.bFlagFor2560 is " +RunTimeInfo.bFlagFor2560);
	}catch(e){
		Log.e("[mycontents setPanelWIdth]  e:");
	}
};

function addMagicKeyListener(){
    RunTimeInfo.magicKey.addListener(myContensKey.SHOW_APP_VERSION, function(){
        print('mycontents addMagicKeyListener SHOW_APP_VERSION');
		EventMediator.trigger(EventType.EVENT_TYPE_SHOW_APP_VERSION);
    });
    RunTimeInfo.magicKey.addListener(myContensKey.SHOW_DEVICE_INFO.ALL, function(){
        print('mycontents magic: SHOW_DEVICE_INFO.ALL');
		EventMediator.trigger(EventType.EVENT_TYPE_SHOW_DEVICE_INFO);
    });
};

/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keycode, type) {
	print("mycontents onKeyEvent - keycode : " + keycode + ', type:' + type );
    if( type == Volt.EVENT_KEY_RELEASE){
	   RunTimeInfo.magicKey.onKeyPress(keycode);
    }
	if(RunTimeInfo != null && RunTimeInfo != undefined && RunTimeInfo.router != null){
		RunTimeInfo.router.onKeyEvent(keycode, type);
	}
};

/*load fake UI after launch*/
function loadFakeUI(){
	Volt.header = new WidgetEx({
	    width: scene.width,
	    height: 144,
	    parent: scene,
	    color: {r: 15, g:24, b:38}
	});
	Volt.headerLine= new WidgetEx({
				x: 0, 
				y: 144, 
				width: 1920, 
				height: 1,				
		        color: {r: 255, g:255, b:255,a:25.5},
        	});
	Volt.category = new WidgetEx({
	    x:0,
	    y:144,
	    width: scene.width,
	    height: 72,
	    parent: scene,
	    color:{r: 242, g:242, b:242,a:255}
	});
	
	Volt.mycontents = new TextWidgetEx({
		x: 36, 
		y: 0, 
		width: 726, 
		height: 144,
		verticalAlignment : 'center',
	    textColor : {r: 255, g:255, b:255},
	    opacity: 102,
	    ellipsize : true,
	    text : 'My Content',
	    parent: scene,
	    font : 'SVD Light 50px'
	});
	
	Volt.dimScreen = new WidgetEx({
		x: 0, 
		y: 0, 
		width: 1920, 
		height: 1080,
		parent: scene,
	    color: {r:0, g:0, b:0, a:180}
	});
}

function getLanguageCode() {

    var languageCode = '';

    var preDefine = {
        'fr_CA' : 'fr-US',
        'es_MX' : 'es-US',
        'pt_BR' : 'pt-US',
        'en_GB' : 'en-GB',
        'zh_CN' : 'zh-CN',
        'zh_HK' : 'zh-HK',
        'zh_TW' : 'zh-TW'
    }

    var vconfMenuLang = Vconf.getValue('db/menu_widget/language'); //retur string
    print('mycontents vconf MENU_LANGUAGE : ' + vconfMenuLang);
	
    var lang = vconfMenuLang.split('.')[0];

    if(preDefine[lang]){
        languageCode = preDefine[lang];
    }else{
        languageCode = lang.split('_')[0];
    }

	print('mycontents languageCode = ', languageCode);
   
   return languageCode;
}

/*set event listener*/
function setEventListener(){
	Volt.addEventListener(Volt.ON_PAUSE, onPause);
	Volt.addEventListener(Volt.ON_RESUME, onResume);
	Volt.addEventListener(Volt.ON_RESET, onReset);
	Volt.addEventListener(Volt.ON_ACTIVATE, onActive);
	Volt.addEventListener(Volt.ON_DEACTIVATE, onDeActive);		
	Volt.addEventListener(Volt.ON_HIDE, onHide);
	
	Vconf.setOnChangeHandler('memory/mycontents/status',onMyContentStatusChange);

	Vconf.setOnChangeHandler('memory/volt/panel_hide',onCECModeChange);
    Vconf.setOnChangeHandler('db/menu_widget/language', function(){
         print("mycontents setOnChangeHandler: MENU_LANGUAGE ");
         print(arguments);
		 Log.e("mycontents OnChangeHandler: MENU_LANGUAGE  quit mycontent");
		 print("mycontents OnChangeHandler: MENU_LANGUAGE  quit mycontent");
		 
		 Volt.quit();
		 
      //   Volt.onLanguageChanged(getLanguageCode());

		// EventMediator.trigger(EventType.EVENT_TYPE_LANGUAGE_CHANGED);
    });	
	
	var cursorVisibale = Vconf.getInteger('memory/window_system/input/cursor_visible');
	print("mycontent [app.js] cursorVisibale " + cursorVisibale);
	if(cursorVisibale == 1){
		RunTimeInfo.visibleCursor = true;
	}
	
	voltapi.vconf.setOnChangeHandler('memory/window_system/input/cursor_visible', onChangeVisibleCursor);


} 

/*terminate volume app*/
function terminateVolumeApp(){
	var aulApp = new Aul();	//add by pual.hu for DF141203-02428
	aulApp.terminateApp(LaunchAppID.APP_ID_VOLUME);
	aulApp.terminate();
	aulApp = null;
}

function requireModules(){
	print("mycontents load distribution");
	Log.e("mycontents load distribution");
	Volt.require('distribution.min.js');
	Log.e("mycontents load distribution finish");
	print("mycontents load distribution finish");
	Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');
	voltapi =  Volt.require('voltapi.js');

		/*Reverse ODS   : MUST call this before require volt-nav*/
	HALOUtil.applyOrientation();
		
	Volt.require('lib/volt-debug.js');
	Volt.require('lib/volt-common.js');
	Volt.require('lib/volt-global.js');
	Volt.require('lib/volt-nav.js');
	Volt.require('lib/panel-common.js');
	
	Volt.DeviceInfoModel = Volt.require('app/models/device-info-model.js');
    	Volt.i18n = Volt.require('lib/volt-multilingual.js');
    	Volt.i18n.init({
        lng : Volt.DeviceInfoModel.getLanguageCode(),
            resGetPath: 'lang/<<lng>>.json',
            getAsync: false,
            interpolationPrefix: '<<',
            interpolationSuffix: '>>'
       }, function(t){
	});
	
	Backbone = Volt.require('modules/backbone.js');
	RunTimeInfo = Volt.require("app/common/run-time-info.js");
	CommonInfo = Volt.require("app/common/define.js");
	launchParams = Volt.require("app/common/launch-params.js");
	Volt.KPIMapper = Volt.require('app/common/kpi-mapper.js');
	AppLauncher = Volt.require("app/controller/app-launch.js");
    inputController = Volt.require('app/controller/input-controller.js');
	menuController = Volt.require('app/controller/menu-controller.js');
    EventMediator = RunTimeInfo.EventMediator;
	EventType = CommonInfo.EventType;
	EViewType = CommonInfo.EViewType;
	DimType = CommonInfo.DimType;
	LaunchAppID = CommonInfo.LaunchAppID;
	LaunchedByAppID = CommonInfo.LaunchedByAppID;
	EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
	myContensKey = CommonInfo.MyMagicKey;
	myConfig = CommonInfo.Config;
	dimType = DimType.NONE_DIM;
	ViewGlobalData = Volt.require("app/views/view-global-data.js");
};

function read3DMode(){

	print("mycontents read3DMode  current3DMode:");
	var current3DMode = false;
	try{
		current3DMode = VDUtil.get3dMode();
	}
	catch (ex){
		Log.f("[app.js][read3DMode] Error:" + ex);
	}
	print("mycontents read3DMode  current3DMode:"+current3DMode);
	Log.e("mycontents read3DMode  current3DMode:"+current3DMode);

	return current3DMode;

};

function set3DMode(mode){
	Log.e("mycontents set3DMode  mode:"+mode);
	print("mycontents set3DMode  mode:"+mode);
	try{
		VDUtil.set3dMode(mode);
	}
	catch (ex){
		Log.f("[app.js][read3DMode] Error:" + ex);
	}
};
function preloadVideoPlayer(){
	var isPreloading = Vconf.getValue('memory/video-player/player_need_preloading');
	if(isPreloading == 1 && (!launchParams.isLaunchForMusicPlayer())){
		print('mycontents preloadVideoPlayer .... ');
		Log.e("mycontents preloadVideoPlayer .... ");
	    var args = {
			"init" : 'background',
	    };	
		AppLauncher.launch(LaunchAppID.APP_ID_VIDEO_PLAYER, args);	
		inputController.unblockInput();
	}else{
		Log.e("mycontents preloadVideoPlayer .... isPreloading:"+isPreloading);
		print("mycontents preloadVideoPlayer .... isPreloading:"+isPreloading);
	}
};

function preloadPhotoPlayer(){
	var isPreloading = Vconf.getValue('memory/photo-player/player_need_preloading');
	if(isPreloading == 1 && (!launchParams.isLaunchForMusicPlayer())){
		print('mycontents preloadPhotoPlayer .... ');
		Log.e("mycontents preloadPhotoPlayer .... ");
	    var args = {
			"init" : 'background',
	    };	
		AppLauncher.launch(LaunchAppID.APP_ID_PHOTO_PLAYER, args);	
		inputController.unblockInput();
	}else{
		Log.e("mycontents preloadPhotoPlayer isPreloading: "+isPreloading);
		print("mycontents preloadPhotoPlayer isPreloading: "+isPreloading);
	}
};

function terminatePhotoPlayer(){
	print('mycontents terminatePhotoPlayer~~~~~~~~');
	Log.e("mycontents terminatePhotoPlayer~~~~~~~~");
	AppLauncher.terminateApp(LaunchAppID.APP_ID_PHOTO_PLAYER); 
};

function terminateVideoPlayer(){
	print('mycontents terminateVideoPlayer~~~');
	Log.e("mycontents terminateVideoPlayer~~~");
	AppLauncher.terminateApp(LaunchAppID.APP_ID_VIDEO_PLAYER);
};

function getLaunchParams(data){
	if(data == null || data == undefined){
		return ;
	}

	paramData = {};
	
	for ( var key in data ){
		print(' paramData[' + key + '], result =', data[key]);
		Log.f(' paramData[' + key + '], result ='+ data[key]);
		paramData[key] = data[key];			
	}
	
	launchParams.resetParams();
	if(paramData != null){
		launchParams.setParams(paramData);
		launchParams.printParam();	
	}		
}

function sendAppStartLog(){
	if(false === voltapi.Logging.isOpened()){
		voltapi.Logging.initAsync(function(ret){
			if(!ret){
				print('Failed to open Logging:'+ret);
				return;
			}
			var isSend = voltapi.Logging.sendVoltLog("APPSTART");
			print('APPSTART1 sendVoltLog():'+isSend);
		});
	}
	else{
		var isSend = voltapi.Logging.sendVoltLog("APPSTART");
		print('APPSTART2 sendVoltLog():'+isSend);
	}
	
	//Volt.KPIMapper.sendVoltLog("APPSTART");

	//var isSendStart = voltapi.Logging.sendVoltLog("APPSTART");
	//print('APPSTART1 sendVoltLog():'+isSendStart);
}

function sendAppStopLog(){
	if(false === voltapi.Logging.isOpened()){
		voltapi.Logging.initAsync(function(ret){
			if(!ret)
			{
				print('Failed to open Logging:'+ret);
				return;
			}
			var isSend = voltapi.Logging.sendVoltLog("APPSTOP");
			print('APPSTOP1 sendVoltLog():'+isSend);
		});
	}
	else{
		var isSend = voltapi.Logging.sendVoltLog("APPSTOP");
		print('APPSTOP2 sendVoltLog():'+isSend);
	}
	
	//Volt.KPIMapper.sendVoltLog("APPSTOP");

	//var isSendStop = voltapi.Logging.sendVoltLog("APPSTOP");
	//print('APPSTOP1 sendVoltLog():'+isSendStop);
}

/*when fisrt launch*/
var onShow = function(data){
	Log.e("[MyContent] Code Version: 2015-04-30 / 21:30");
	Log.e("mycontents onShow begin~~~performance");
	print("[MyContent] Code Version: 2015-04-30 / 21:30");
	
	//disable 3D mode	
	RunTimeInfo.threeDMode = read3DMode();
	set3DMode(0);
	
	sendAppStartLog();
	
	getLaunchParams(data);
	RunTimeInfo.isFirstLanch = true;
	
	//add stage
	Stage.show();

	//menuController.disableMenu();


	RunTimeInfo.appState = true;

	try{
		VDUtil.setTVSourceType();
	}
	catch(e){
	    Log.f("[MyContents]onShow setTVSourceType Error: " + e);
	}
};

/*when terminate*/
var onHide = function(){
	print("[app.js]---onHide--mycontents is terminated~~~~~~~~~~~~~~~~~~~~");
	Log.e("[app.js]---onHide--mycontents is terminated~~~~~~~~~~~~~~~~~~~~");
	
	Log.e("mycontents is terminated  enableMenu ~~~~~~~~~~~~~~~~~~~~");
	print("mycontents is terminated  enableMenu ~~~~~~~~~~~~~~~~~~~~");

	menuController.enableMenu();
	Log.e("mycontents is terminated  enableMenu end ~~~~~~~~~~~~~~~~~~~~");
	try{
		sendAppStopLog();
		print(" mycontents is terminated  send EVENT_TYPE_EXIT");
		EventMediator.trigger(EventType.EVENT_TYPE_EXIT);
		
		/*reset music player state*/
		if(RunTimeInfo.playState == 1){
			var playerController = Volt.require('app/controller/play-controller.js');
			playerController.reset();
			if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR){
				if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ){
					var currView = RunTimeInfo.router.getCurrentView();
					if( typeof currView.dmrExitNotify == 'function')
					currView.dmrExitNotify();
				}
			}
			RunTimeInfo.playState = 0;
		}
		
		/*close csf*/
		Log.e("mycontents [onHide] require csf-manager.js  ~~~~~~~~~~~~~~~~~~");
		var CsfMgr = Volt.require('app/models/csf-manager.js');
		CsfMgr.close();

		var deviceProvider =  Volt.require('app/models/device-provider.js');
		deviceProvider.destroy();
		
		/*close network and clear network listener list*/
		var netController = Volt.require('app/controller/net-controller.js');
		netController.close();
	}catch(e){
		Log.e("mycontents is terminated, e:" + e);
	}
	
	Vconf.setValue('memory/mycontents/status', 'off');
	Volt.removeEventListener(Volt.ON_HIDE, onHide);
	Volt.removeEventListener(Volt.ON_SHOW, onShow);

	RunTimeInfo.appState = false;
};

/*when the process is alive and relaunch*/
var onReset = function(data){
	Log.e("mycontents app reset~~~~");
	print("mycontents app reset~~~~RunTimeInfo.bFlagForInforBox is " + RunTimeInfo.bFlagForInforBox);
	
		//disable 3D mode	
	RunTimeInfo.threeDMode = read3DMode();
	set3DMode(0);
	
	var mlsState = Vconf.getValue('memory/mls/state');
	
	sendAppStartLog();
	
	if (RunTimeInfo.bFlagForInforBox)
	{
		EventMediator.trigger(EventType.EVENT_HIDE_INFORMATION);
		RunTimeInfo.bFlagForInforBox = false;	
	}	
	
	if(RunTimeInfo.isSendPopupShow == true){
		print("content-base-collection.js  isSendPopupShow is true");
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SENDING_POPUP);
	}
	print("mycontents app reset dimType "+dimType + " mlsState is " + mlsState);// 1 refers mls is launched
	Log.e("mycontents app reset dimType "+dimType);
	if(dimType == DimType.PAUSE_DIM){
		//if onPause dim view, undim view here
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		dimType = DimType.NONE_DIM;
	}	
	
	/*stop screen app loading*/
	//fix::: My Contents Loading animation didn't disappear when Play movie	
	var bIsWaitingScreenVisible = Vconf.setValue("db/WaitingScreenApp/Visible", true);
	print('mycontents [onReset]-bIsWaitingScreenVisible:' + bIsWaitingScreenVisible);  

	/*get launch params*/
	getLaunchParams(data);

	if( RunTimeInfo.appState == true){
		if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ){
			RunTimeInfo.launchMusicReturnContentOrNot = false;
		}
		else{
			RunTimeInfo.launchMusicReturnContentOrNot = true;
		}
	}
	else{
		RunTimeInfo.launchMusicReturnContentOrNot = false;
	}
	print('RunTimeInfo.appState='+RunTimeInfo.appState+'RunTimeInfo.launchMusicReturnContentOrNot='+RunTimeInfo.launchMusicReturnContentOrNot);
	
	/*prepare page by params*/
	AppLauncher.launchedBy(launchParams);

	
	print('mycontents onReset >>>>>>>>>>>>>> SuspendFlag:',RunTimeInfo.SuspendFlag);
	/* if none-firstscreen launch mycontents, need to terminate photo/video player */
	if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_USB_LAUNCHER ||
		launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_PVR_RECORDER ||
		launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_SOURCE_LIST ||
		launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_MLS
		||launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_SEARCH_ALL ){
			terminatePhotoPlayer();
			terminateVideoPlayer();
	}
	
	//print('VDUtil.registerKey()');
	//VDUtil.registerKey();
	RunTimeInfo.bFlagForDMRandSearchCaseBallon = true;// temperoray solutio, test  for balloon
	if(!launchParams.isLaunchForMusicPlayer()){
	print('[app.js]---onRest----launchParams.getLauncherAppName() is ' + launchParams.getLauncherAppName());

		Volt.log('[app.js]--onReset----RunTimeInfo.bFlagForDMRandSearchCaseBallon is ' + RunTimeInfo.bFlagForDMRandSearchCaseBallon);
		
		/*resume music player playing*/
		if(RunTimeInfo.playState == 1 && 
		   launchParams.getLauncherAppName() != LaunchedByAppID.APP_ID_SOURCE_LIST && 
		   launchParams.getLauncherAppName() != LaunchedByAppID.APP_ID_USB_LAUNCHER){
			print('mycontents RunTimeInfo.playState == 1, try to resume the music playing');		
			var playerController = Volt.require('app/controller/play-controller.js');
			try
			{
				playerController.resume('appResume');//need to input a vara...appResume
			}
			catch(e)
			{
		   		Log.e('[app.js]--onReset----e is ' + e);
				playerController.resume(null);//need to input a vara...appResume
			}
			
			print("[app.js]---onReset--mlsState is 1~~~~appResume~~");

			
			
		}
		else{

			print("[app.js]---onReset--mycontents reset by firstscreen~~~~~~");

			Log.e("[app.js]---onReset--mycontents reset by firstscreen~~~~~~");
			RunTimeInfo.isResetByFirstScreen = true;
		
			/*if instant on power off and power on, launch mycontents again, update device list*/
		
			if(RunTimeInfo.playState == 1){
				var playerController = Volt.require('app/controller/play-controller.js');
				playerController.stop();
			}
			EventMediator.trigger(EventType.EVENT_TYPE_RESET, RunTimeInfo.SuspendFlag);
			if(RunTimeInfo.SuspendFlag){
				RunTimeInfo.SuspendFlag = false;
				EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_DEVICE_LIST);		
			}
		}
		//menuController.disableMenu();
	}
	
	/*preload photo/video player*/
    preloadPhotoPlayer();	
	preloadVideoPlayer();

	Log.e("mycontents onreset ~~~~~~~~  stage show");
	Stage.show(); 
	
	inputController.unblockInput();
	EventMediator.trigger(EventType.EVENT_TYPE_SHOW_FILTER_ANIMATION);
	RunTimeInfo.appState = true;
};

/*when put to background by non-full screen app, such as menu, usb-launcher...*/
var onDeActive = function(){
	Log.e("mycontents app deactive~~~");
	print("mycontents app deactive~~~");
	var currView = RunTimeInfo.router.getCurrentView();
	if(currView != null && typeof currView.hideFocus == 'function' ){
		currView.isGridListFocus = ViewGlobalData.isGridListFocus;
		Log.e('mycontents app hideFocus isGridListFocus:'+currView.isGridListFocus);
		print('mycontents app hideFocus isGridListFocus:',currView.isGridListFocus);
		currView.hideFocus();
	}
	if (RunTimeInfo.bFlagForNAMsgBoxShow)
	{
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ALL_POPUP);
	}
	//Disable disconnect popup
	RunTimeInfo.isShowDisconnectPop = false;	
	
	EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ALL_POPUP);

	if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ){
		Volt.log('RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView then return, why?---nt comment return first');
		return;
	}
	
	var mlsState = Vconf.getValue('memory/mls/state');
	print("mycontents onDeActive mlsState:" + mlsState);
	Log.e("mycontents onDeActive mlsState:" + mlsState);
	
	if(mlsState != 1){
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
	}
	
	if(dimType == DimType.NONE_DIM){
		dimType = DimType.DEACTIVE_DIM;// deactive Dim
	}
	
	Vconf.setValue('memory/mycontents/status', 'off');
};

/*when put to front by non-full screen app, such as menu, usb-launcher...*/
var onActive = function(){
	Log.e("mycontents app active~~~");
	print("mycontents app active~~~");
	
	//enable disconnect popup
	RunTimeInfo.isShowDisconnectPop = true;
	EventMediator.trigger(EventType.EVENT_TYPE_ON_ACTIVE_DELE_DEVICE, null);
	
	var currView = RunTimeInfo.router.getCurrentView();
	print("mycontents app active dimType "+dimType);
	Log.e("mycontents app active dimType "+dimType);
	
	if(dimType == DimType.DEACTIVE_DIM){
		//if deactive dim,  undim view here
		if(RunTimeInfo.isSendPopupShow != true){
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		}
		dimType = DimType.NONE_DIM;
	}
		
	
	if( currView != null && typeof currView.showFocus == 'function' ){
		Log.e("mycontents app currView.showFocus:"+ currView.isGridListFocus);
		print("mycontents app currView.showFocus:", currView.isGridListFocus);
		Log.e("mycontents app onActive RunTimeInfo.isLaunchTerm:"+ RunTimeInfo.isLaunchTerm);
			
		if(RunTimeInfo.isLaunchTerm != true)
		{
			Volt.log('[app.js]----to showFocus in onActive');
			Log.e('[app.js]----to showFocus in onActive');
			currView.showFocus();		
		}
	}	
	
	EventMediator.trigger(EventType.EVENT_TYPE_ON_ACTIVE, null);
	Vconf.setValue('memory/mycontents/status', 'on');
	menuController.disableMenu();
	inputController.unblockInput();

	
};

/*when put to background by full screen app, such as video/photo player*/
var onPause = function(data){
	Log.e("mycontents app pause~~~");
	print("mycontents app pause~~~");
	var mlsState = Vconf.getValue('memory/mls/state');

	sendAppStopLog();
	
	//Disable disconnect popup
	RunTimeInfo.isShowDisconnectPop = false;
	try{
		Volt.log('[app.js]---onPause---RunTimeInfo.playState is ' + RunTimeInfo.playState);
		if(RunTimeInfo.playState == 1){
			print('mycontents RunTimeInfo.playState == 1, try to pause the music playing');
			var playerController = Volt.require('app/controller/play-controller.js');
			if(!launchParams.isLaunchForMusicPlayer()){
				try
				{
					playerController.pause('appPause');
				}
				catch(e)
				{
					Log.e('[app.sj]----onPause---e is ' + e);
					playerController.pause(null);
				}
			}
			else
			{
				try// to quit mycontents when it is launched by dmr or search
				{
					Volt.log('[app.js]---to exit music-player when it is luanched bysearch');
					var mainView = Volt.require('app/views/main-view.js');
					mainView.widget.hide();
					Volt.exitKey();
				}
				catch(e)
				{
					Log.e("music-player-view.js]  Volt.exitKey() "+e);
					Volt.exit();
				}	
			/*	
				if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR)
				{
					playerController.reset();
					if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ){
						var currView = RunTimeInfo.router.getCurrentView();
						if( typeof currView.dmrExitNotify == 'function')
						currView.dmrExitNotify();
					}
					RunTimeInfo.playState = 0;
					Volt.log('[app.js]---onPause---RunTimeInfo.playState change to 0');
				}
			*/	
			}
		}
		if( RunTimeInfo.playerPause == true ){
			
			RunTimeInfo.router.pauseView();
		}
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		
		if(dimType == DimType.NONE_DIM){
			dimType = DimType.PAUSE_DIM;// onPause  Dim 
		}
		
		Backbone.history.stop();
		Vconf.setValue('memory/mycontents/status', 'off');
	}catch(e){
		Log.e("pause~~~ enableMenu"+e);
	}
	Log.e("pause~~~ enableMenu");	
	print("pause~~~ enableMenu");	
	menuController.enableMenu();

	//set3DMode(RunTimeInfo.threeDMode);

	RunTimeInfo.appState = false;
};

/*when put to front by full screen app, such as video/photo player*/
var onResume = function(data){
	Log.e("mycontents app resum~~~ RunTimeInfo.playerPause = " + RunTimeInfo.playerPause );
	print("mycontents app resum~~~ RunTimeInfo.playerPause = " + RunTimeInfo.playerPause );
	
	RunTimeInfo.threeDMode = read3DMode();
	//close 3d mode
	set3DMode(0);
	
	sendAppStartLog();
	
	//enable disconnect popup
	RunTimeInfo.isShowDisconnectPop = true;
	EventMediator.trigger(EventType.EVENT_TYPE_ON_ACTIVE_DELE_DEVICE, null);
	
	print("mycontents app onResume dimType "+dimType);
	Log.e("mycontents app onResume dimType "+dimType);
	if(dimType == DimType.PAUSE_DIM){
		//if onPause dim view, undim view here
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		dimType = DimType.NONE_DIM;
	}
	
	if( RunTimeInfo.playerPause == true ){
		EventMediator.trigger(EventType.EVENT_TYPE_RESUM_FROM_PLAYER);
 		/*preload photo player*/
		print('mycontents [app.js]onResume, preload photo player');
	    preloadPhotoPlayer();	

		preloadVideoPlayer();
	}
	RunTimeInfo.playerPause = false;

	if(RunTimeInfo.playState == 1){
		print('mycontents RunTimeInfo.playState == 1, try to resume the music playing');		
		var playerController = Volt.require('app/controller/play-controller.js');
		try
		{
			playerController.resume('appResume');
		}
		catch(e)
		{
			Log.e('[app.sj]----onResume---e is ' + e);
			playerController.resume(null);	
		}
		menuController.disableMusicMenu();
	}	
	EventMediator.trigger(EventType.EVENT_TYPE_SHOW_FILTER_ANIMATION);
	inputController.unblockInput();

	//menuController.disableMenu();

	RunTimeInfo.appState = true;
};

/*when instant on, power off*/
var onSuspend = function(data){
	Log.e("mycontents [app.js]  onSuspend ~~~~~~~~~~~~~~~~~~ data:" + data);
	print("mycontents [app.js]  onSuspend ~~~~~~~~~~~~~~~~~~ data:" + data);
	
			//Disable disconnect popup
	RunTimeInfo.isShowDisconnectPop = false;
	Volt.quit();
	RunTimeInfo.SuspendFlag = true;
	EventMediator.trigger(EventType.EVENT_TYPE_SUSPEND);

};

/*when instant on, power on*/
var onWakeup = function(data){
	Log.e("mycontents [app.js]  onWakeup ~~~~~~~~~~~~~~~~~~ data " + data);
	print("mycontents [app.js]  onWakeup ~~~~~~~~~~~~~~~~~~ data " + data);
	
	//enable disconnect popup
	RunTimeInfo.isShowDisconnectPop = true;
			
	EventMediator.trigger(EventType.EVENT_TYPE_WAKEUP);

};

var onChangeVisibleCursor = function(key, value){
	Log.e("mycontents [app.js] onChangeVisibleCursor [key "+ key + "] value change to " + value);
	print("mycontents [app.js] onChangeVisibleCursor [key "+ key + "] value change to " + value);
	if(value == 1 ){
		if(RunTimeInfo.visibleCursor == false){
			RunTimeInfo.visibleCursor = true;
			Log.e("mycontents [app.js] onChangeVisibleCursor send EVENT_TYPE_CURSOR_SHOW ");
			print("mycontents [app.js] onChangeVisibleCursor send EVENT_TYPE_CURSOR_SHOW ");
			EventMediator.trigger(EventType.EVENT_TYPE_CURSOR_SHOW);
		}
	}else {
		if(RunTimeInfo.visibleCursor == true){
			RunTimeInfo.visibleCursor = false;
			Log.e("mycontents [app.js] onChangeVisibleCursor send EVENT_TYPE_CURSOR_HIDE ");
			print("mycontents [app.js] onChangeVisibleCursor send EVENT_TYPE_CURSOR_HIDE ");
			EventMediator.trigger(EventType.EVENT_TYPE_CURSOR_HIDE);
		}
	}
	
};
/*when cec mode value has been changed*/
var onCECModeChange = function(key, value){
	Log.e("mycontents [app.js] [key "+ key + "] value change to " + value);
	print("mycontents [app.js] [key "+ key + "] value change to " + value);
	
	if(value == 1){
		Volt.quit();
	}
};

/*set env for displaying*/
var setEnv = function(){
	/*enable 720P*/
	var width = 1920;
	try{
		width =  VDUtil.getResolution();
	}
	catch (ex){
		Log.f("[app.js][getResolution] Error:" + ex);
	}	
	Log.e("mycontents [app.js] Resolution: " + width );
	if(width == 1280){
		print('mycontents setEnv,width:', width);
		HALOUtil.enable720P = true;
	}
	
	/*Reverse ODS*/
	HALOUtil.applyOrientation();
	
	/*Enlarge*/
	var enlarge = Vconf.getValue(VCONF_FOCUS_ROOM);
	print('mycontents enlarge :', enlarge);
	if(enlarge != '0'){
		print('mycontents setEnv,enlarge:', enlarge);
		HALOUtil.enlarge = true;
	}
	Vconf.setOnChangeHandler(VCONF_FOCUS_ROOM,onEnlargeChange);
		
	/*Highcontrast*/
	var highContrast = Vconf.getValue(VCONF_HIGH_CONTRACT);
	if(highContrast != '0'){
		print('mycontents setEnv,highContrast:', highContrast);
		HALOUtil.highContrast = true;			
	}
	Vconf.setOnChangeHandler(VCONF_HIGH_CONTRACT,onHighContrastChange);
	
	print('mycontents highContrast :', highContrast);
};

var onHighContrastChange = function(key, value){
	Log.e("mycontents onHighContrastChange [key "+ key + "] value change to " + value);
	print("mycontents onHighContrastChange [key "+ key + "] value change to " + value);
	
	if(value != '0'){
		print("mycontents Set highContrast = true");
		Log.e("mycontents Set highContrast = true");
		HALOUtil.highContrast = true;	
	}else{
		print("mycontents Set highContrast = false");
		Log.e("mycontents Set highContrast = false");
		HALOUtil.highContrast = false;	
	}	
	EventMediator.trigger(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE);
};

var onEnlargeChange = function(key, value){
	Log.e("mycontents onEnlargeChange [key "+ key + "] value change to " + value);
	print("mycontents onEnlargeChange [key "+ key + "] value change to " + value);
	
	if(value != '0'){
		print("mycontents Set enlarge = true");
		Log.e("mycontents Set enlarge = true");
		HALOUtil.enlarge = true;	
	}else{
		print("mycontents Set enlarge = false");
		Log.e("mycontents Set enlarge = false");
		HALOUtil.enlarge = false;	
	}	
	EventMediator.trigger(EventType.EVENT_TYPE_ENLARGE_CHANGE);
};


var onMyContentStatusChange = function(key, value){
	Log.e("mycontents onMyContentStatusChange [key "+ key + "] value change to " + value);
	print("mycontents onMyContentStatusChange [key "+ key + "] value change to " + value);
	
	if(value == 'on'){
		print("mycontents Set Status = on");
		Log.e("mycontents Set Status = on");
		print("onMyContentStatusChange FirstActive :"+FirstActive);
		if(FirstActive == false){
			var playerController = Volt.require('app/controller/play-controller.js');
			if(playerController.getInitTUNEStatus() == true){ 
				if(playerController.getTUNEStatus() == false){
					print("onMyContentStatusChange  setTUNESource ");
					Log.e("onMyContentStatusChange  setTUNESource ");
			        try{
			            voltapi.TUNE.setAppInfo("org.volt.mycontents");
			        }
			        catch (ex){
			            Log.f("[play-controller.js][init] setAppInfo Error: " + ex);        // added by dy0518.kim
			        }
					
			        voltapi.TUNE.disconnectSource();
			        voltapi.TUNE.setSource(voltapi.TUNE.PL_WINDOW_SOURCE_MEDIA);
					playerController.setTUNEStatus(true);
					
				}else{
					print("onMyContentStatusChange setTUNESource = true");
				}
			}else{
				print("onMyContentStatusChange wait  voltapi.TUNE init ");
			}	
		}
		print("onMyContentStatusChange set FirstActive = false");
		FirstActive = false;
		
	}else{
		print("mycontents Set Status = off");
		Log.e("mycontents Set Status = off");

	}	
	
};

/*add app event listener*/
Volt.addEventListener(Volt.ON_SHOW, onShow);
Volt.addEventListener(Volt.ON_SUSPEND, onSuspend);
Volt.addEventListener(Volt.ON_WAKEUP, onWakeup);


