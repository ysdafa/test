 /** 
 * @author  Li Hailong (hailong08.li@samsung.com)
 * 			
 * @fileoverview  Provider device list for views 
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');
var DeviceModel = Volt.require('app/models/device-model.js');
var DeviceCollection = Volt.require('app/models/device-collection.js');

//var VoltApi = require("voltapi");
var VoltApi = Volt.require('voltapi.js');
//var VoltApi = Volt.require('modules/voltapi.js');
var CommonInfo = Volt.require('app/common/define.js');
var RunTimeInfo = Volt.require('app/common/run-time-info.js');
var EventMediator = RunTimeInfo.EventMediator;
var self = null;
var EventType = CommonInfo.EventType;
var DeviceType = CommonInfo.DeviceType;

var DeviceProvider = function() {
	this.collection = new DeviceCollection;
	this.currentDeviceId = null;
	
	this.create = function () {
	};
	
	this.setCurrentDeviceId = function(type, devItem){
		print('[device-provider] [setCurrentDeviceId] type:',type,', devItem :', devItem);
		
		if(devItem != null && devItem != undefined){
			this.currentDeviceId = devItem.get('id');
		}else {
			this.currentDeviceId = null;
		}

		print('[device-provider] [setCurrentDeviceId] currentDeviceId:',this.currentDeviceId);
		
	};
	
	this.getCurrentDeviceId = function(){
		
		return this.currentDeviceId;
	};
	
	this.destroy = function(){
		print('device provider destroy~~~~~~~~~~~~~~');
		if(this.collection != null){
			this.collection.destroy();
		}		
//		EventMediator.off(EventType.EVENT_TYPE_CATEGORY_CHANGE, this.onCategoryCallback, this);
	};
	/** Resiter device event listener 	 
	* @name resiterListener	 
	* @memberOf DeviceProvider
	* @param {object} receive event object
	* @param {connect} device connect callback 
	* @param {disconnect} device disconnect callback 
	* @method 	 
	* */	
	this.regsiterListener = function(object, connect, disconnect, update) {
		if(connect != null && connect != undefined){
		    EventMediator.on(EventType.EVENT_TYPE_ADD_DEVICE, connect, object);
		}
		if(disconnect != null && disconnect != undefined){
	        EventMediator.on(EventType.EVENT_TYPE_DEL_DEVICE, disconnect, object);
		}
		
		if(update != null && update != undefined){
			EventMediator.on(EventType.EVENT_TYPE_UPDATE_DEVICE, update, object);
		}
	};
	
	/** Unresiter device event listener 	 
	* @name unresiterListener	 
	* @memberOf DeviceProvider
	* @param {object} receive event object
	* @param {connect} device connect callback 
	* @param {disconnect} device disconnect callback 
	* @method 	 
	* */	
	this.unregsiterListener = function (object, connect, disconnect, update) {

		if(connect != null && connect != undefined){
			EventMediator.off(EventType.EVENT_TYPE_ADD_DEVICE, connect, object);
		}
		
		if(disconnect != null && disconnect != undefined){
	        EventMediator.off(EventType.EVENT_TYPE_DEL_DEVICE, disconnect, object);
		}
		
		if(update != null && update != undefined){
			EventMediator.off(EventType.EVENT_TYPE_UPDATE_DEVICE, update, object);
		}
	};
	
	/** Get all device list 	 
	* @name getDeviceList	 
	* @memberOf DeviceProvider	 
	* @method 	 
	* */
	this.getDeviceList = function () {
	  return this.collection;
	};
	
	/** Get device info by device key 	 
	* @name getDeviceInfoByKey	 
	* @memberOf DeviceProvider
	* @param {deviceKey} device key value
	* @method 	 
	* */
	this.getDeviceInfoByKey = function (deviceKey) {
	  var deviceInfo = this.collection.searchDevice(deviceKey);
	  return deviceInfo;
	};	
	
	/** Get device id by bus and address	 
	* @name getIdByBusAddress	 
	* @memberOf DeviceProvider
	* @param {bus} device bus number
	* @param {address} device address number
	* @method 	 
	* */
	this.getIdByBusAddress = function(bus,address){
		print('[device-provider][getIdByBusAddress] bus : '  + bus +'address : '+address);
		var deviceItems = this.collection.where({address: address});
		for(var i =0; i < deviceItems.length; i++){
			if( deviceItems[i]==null||deviceItems[i]==undefined ){
				continue;
			}
			if(deviceItems[i].get('bus') == bus){
				break;
			}
		}

		if( i == deviceItems.length ){
			return -1;
		}
		
		var deviceId = deviceItems[i].get('id');
		print('deviceId :',deviceId);
		return deviceId;
	};
	
	/** Get device id by mount path 	 
	* @name getIdByMountPath	 
	* @memberOf DeviceProvider
	* @param {deviceMountPath} device mount path
	* @method 	 
	* */
	this.getIdByMountPath = function(deviceMountPath) {
		print('[device-provider][getIdByMountPath] deviceMountPath:',deviceMountPath);
		return this.collection.getDeviceIdByMountPath(deviceMountPath);
	};
	/** Get device info by index 	 
	* @name getDeviceByIndex	 
	* @memberOf DeviceProvider
	* @param {index} 0 ~ device count
	* @method 	 
	* */
	this.getDeviceByIndex = function (index) {
	  var deviceInfo = this.collection.at(index);
	  return deviceInfo;
	};	
	/** Get device info by device id 	 
	* @name getDeviceInfo	 
	* @memberOf DeviceProvider
	* @param {id} device id value
	* @method 	 
	* */
	this.getDeviceInfo = function (id) {
	  var deviceInfo =null;
	  print('id------',id);
	  deviceInfo = this.collection.searchDevice(id);
	  return deviceInfo;
	};
	
	/** Get device mount path by device id 	 
	* @name getUsbDeviceMounthPath	 
	* @memberOf DeviceProvider
	* @param {id} device id value
	* @method 	 
	* */	
	this.getUsbDeviceMounthPath = function (id) {
	  var deviceInfo =null;
	  deviceInfo = this.collection.searchDevice(id);
	  if(deviceInfo != null){
	  		  return deviceInfo.get('mountPath');
	  }
	  return null;
	};	
	/** Get DLNA device ip by device id 	 
	* @name getUsbDeviceMounthPath	 
	* @memberOf DeviceProvider
	* @param {id} device id value
	* @method 	 
	* */
	this.getDLNADeviceIp = function (id) {
	  var deviceInfo =null;
	  deviceInfo = this.collection.searchDevice(id);
	  if(deviceInfo != null){
	  	return deviceInfo.get('ip');
	  }
	  return null;
	};	
	
	/** Get device samsung flag 	 
	* @name isSamsungDevice	 
	* @memberOf DeviceProvider
	* @param {id} device id
	* @method 	 
	* */	
	this.isSamsungDevice = function (id) {
	  var deviceInfo =null;
	  var bSamsungDevice = false;
	  deviceInfo = this.collection.searchDevice(id);
	  if(deviceInfo != null){
	  	bSamsungDevice = deviceInfo.get('bSamsungDevice');
	  }
	  return bSamsungDevice;
	};

	/**return uhd flag	 
	* @name isUHDDevice	 
	* @memberOf DeviceProvider
	* @method 	 
	* */	
	this.isUHDDevice = function(id){
	  var deviceInfo =null;
	  var bUhd = false;
	  print(" isUHDDevice id: "+ id);
	  if(id == null || id == undefined){
		return bUhd;
	  }
	  
	  deviceInfo = this.collection.searchDevice(id);
	  if(deviceInfo != null){
	  	bUhd = deviceInfo.get('uhd');
	  }
	  print('isUHDDevice: '+ bUhd);
	  return bUhd;
	};
	/** Get all device count 	 
	* @name getDeviceCount	 
	* @memberOf DeviceProvider
	* @method 	 
	* */	
	this.getDeviceCount = function(){
		
		return this.collection.length;
	};
	
	/** Get usb device count 	 
	* @name getUsbDeviceCount	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getUsbDeviceCount = function(){
		
		//return this.collection.usbDeviceCount;
		var usbDevList = this.getUSBDeviceList();
		var usbLength =  0;
		if(usbDevList != null){
			usbLength = usbDevList.length;
		}
		Log.f("getUsbDeviceCount count: " + usbLength);
		print("getUsbDeviceCount count: " + usbLength);
		return usbLength;
	};
	
	/** Get DLNA device count 	 
	* @name getDLNADeviceCount	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getDLNADeviceCount = function(){
		var deviceList = null;
		var dlanDeviceCount = 0;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_DLNA});
		}
		if(deviceList != null){
			dlanDeviceCount = deviceList.length;
		}
		print(" getDLNADeviceCount dlanDeviceCount:"+dlanDeviceCount);
		
		return dlanDeviceCount;
		
	};
	
	/** Get RA device count 	 
	* @name getRaDeviceCount	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getRaDeviceCount = function(){
		
		return this.collection.raDeviceCount;
	};
	
	/** Get USB device list 	 
	* @name getUSBDeviceList	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getUSBDeviceList = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_USB});
		}
		return deviceList;
	};
	/** Get DLNA device list 	 
	* @name getDLNADeviceList	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getDLNADeviceList = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_DLNA});
		}
		return deviceList;
	};
	/** Get RA device list 	 
	* @name getRADeviceList	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getRADeviceList = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_RA});
		}
		return deviceList;
	};
	/** Get PTP device list 	 
	* @name getPTPDeviceList	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getPTPDeviceList = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_PTP});
		}
		return deviceList;
	};

	
	/** Get lastest usb device 	 
	* @name getLastestUsbDevice	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getLastestUSBDevice = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_USB});
		}

		if(deviceList != null && deviceList.length > 0){
			return deviceList[deviceList.length-1];
		}

		return null;
	};

	/** Get lastest ptp device 	 
	* @name getLastestUsbDevice	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getLastestPTPDevice = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_PTP});
		}
		if(deviceList != null && deviceList.length > 0){
			return deviceList[deviceList.length-1];
		}

		return null;
	};
		
	/** Get lastest dlna device 	 
	* @name getLastestUsbDevice	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getLastestDLNADevice = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_DLNA});
		}

		if(deviceList != null && deviceList.length > 0){
			return deviceList[deviceList.length-1];
		}

		return null;
	};
	/** Get lastest ra device 	 
	* @name getLastestUsbDevice	 
	* @memberOf DeviceProvider
	* @method 	 
	* */
	this.getLastestRADevice = function(){
		var deviceList = null;
		if(this.collection != null){
			deviceList = this.collection.where({'type': DeviceType.DEVICE_TYPE_RA});
		}

		if(deviceList != null && deviceList.length > 0){
			return deviceList[deviceList.length-1];
		}

		return null;
	};
	
	this.getCurrentDevice = function(){
		var device = null;
		print("getCurrentDevice this.currentDeviceId :"+this.currentDeviceId);
		if(this.currentDeviceId != null){
			device = this.collection.findWhere({'id':this.currentDeviceId});
		}
		return device;
	}	
	
};

var deviceprovider = new DeviceProvider();

//MUST regsiter EventType.EVENT_TYPE_CATEGORY_CHANGE here, otherwise  CAN NOT receive event callback
//EventMediator.on(EventType.EVENT_TYPE_CATEGORY_CHANGE, deviceprovider.onCategoryCallback, deviceprovider);

exports = deviceprovider;
