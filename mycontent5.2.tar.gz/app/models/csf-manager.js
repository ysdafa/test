var CommonInfo = Volt.require("app/common/define.js");
var CSFSefType = CommonInfo.CSFSefType;
var ViewGlobalData = Volt.require("app/views/view-global-data.js");
//var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var voltapi = Volt.require('modules/voltapi.js');
var RunTimeInfo = Volt.require('app/common/run-time-info.js');
var EventMediator = RunTimeInfo.EventMediator;
var EventType = CommonInfo.EventType;
var CIThumbType = CommonInfo.CIThumbType;

var CsfManager = function() {
	print("csf-manager.js construct -------");
	//this.csfsef = null;
	//this.thumbsef = null;
	this.contentListResponseListener = null;
	this.thumbnailResponseListener = null;
	this.dlnaResponseListener = null;
	this.raResponseListener = null;
	this.csfSendDataResponseListener = null;
	this.pvrInit = false;

	this.raDeviceConnectCb = function(param1,param2){
		if(csfMgr.raResponseListener){
			csfMgr.raResponseListener(CSFSefType.SEF_CSF_EVENT_RA_DEVICE_CONNECTED, param1,param2);		
		}
		
	};
	this.raDeviceDisConnectCb = function(param1, param2){		
		if(csfMgr.raResponseListener){
			csfMgr.raResponseListener(CSFSefType.SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED, param1,param2);		
		}
	};

	this.raDeviceDisConnectallCb = function(param1, param2){		
		if(csfMgr.raResponseListener){
			csfMgr.raResponseListener(CSFSefType.SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED_ALL, param1,param2);		
		}
	};

	this.requestListSuccessCb = function(param1, param2){
		if(csfMgr.contentListResponseListener){	
			csfMgr.contentListResponseListener(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_SUCCESS, param1, param2);
		}
	};

	this.requestListFailCb = function(param1, param2){
		if(csfMgr.contentListResponseListener){	
			csfMgr.contentListResponseListener(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_FAIL, param1, param2);
		}
	};

	this.requestListEmptyCb = function(param1, param2){
		if(csfMgr.contentListResponseListener){	
			csfMgr.contentListResponseListener(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_EMPTY, param1, param2);
		}
	};

	this.dlnaDeviceConnectCb = function(param1, param2){
		if(csfMgr.dlnaResponseListener){
			csfMgr.dlnaResponseListener(CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_CONNECTED, param1, param2);
		}
	};

	this.dlnaDeviceDisconnectCb = function(param1, param2){
		if(csfMgr.dlnaResponseListener){
			csfMgr.dlnaResponseListener(CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_DISCONNECTED, param1, param2);
		}
	};

	this.dlnaDeviceFinishedCb = function(param1, param2){
		if(csfMgr.dlnaResponseListener){
			csfMgr.dlnaResponseListener(CSFSefType.SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED, param1, param2);
		}
	};

	this.shareOneFileFinishedCb = function(param1, param2){
		if(csfMgr.csfSendDataResponseListener){
			csfMgr.csfSendDataResponseListener(CSFSefType.SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED, param1, param2);
		}
	};

	this.shareAllFileFinishedCb = function(param1, param2){
		if(csfMgr.csfSendDataResponseListener){
			csfMgr.csfSendDataResponseListener(CSFSefType.SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED, param1, param2);
		}
	};
	
	this.shareFileUpdateCb = function(param1, param2){
		if(csfMgr.csfSendDataResponseListener){
			csfMgr.csfSendDataResponseListener(CSFSefType.SEF_CSF_EVENT_SHARE_FILE_UPDATE, param1, param2);
		}
	};
	
	this.shareFailCb = function(param1, param2){
		if(csfMgr.csfSendDataResponseListener){
			csfMgr.csfSendDataResponseListener(CSFSefType.SEF_CSF_EVENT_SHARE_FAIL, param1, param2);
		}
	};

	this.thumbnailFinishedCb = function(param1, param2){
		print("thumbnailFinishedCb param1:"+param1);
	//	print("thumbnailFinishedCb csfMgr.thumbnailResponseListener:"+csfMgr.thumbnailResponseListener);
		if(csfMgr.thumbnailResponseListener){
			csfMgr.thumbnailResponseListener(CSFSefType.CSF_EVENT_THUMBNAIL_FINISHED, param1, param2);
		}
	};

	this.thumbnailFailCb = function(param1, param2){
		print("thumbnailFailCb param1:"+param1);
	//	print("thumbnailFailCb csfMgr.thumbnailResponseListener:"+csfMgr.thumbnailResponseListener);
		if(csfMgr.thumbnailResponseListener){
			csfMgr.thumbnailResponseListener(CSFSefType.CSF_EVENT_THUMBNAIL_FAIL, param1, param2);
		}
	};
	
	this.name = "CsfManager";

	
	this.onEventCallback = function(eventType, param1, param2){
		print('[csf-manager.js] [onEventCallback] eventType : ',eventType);
		switch(eventType){
			case CSFSefType.SEF_CSF_EVENT_RA_DEVICE_CONNECTED:
			case CSFSefType.SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED:
			case CSFSefType.SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED_ALL:
			{
				if(csfMgr.raResponseListener){
					csfMgr.raResponseListener(eventType, param1, param2);
				}
				break;
			}
			case CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_SUCCESS:
			case CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_FAIL:
			case CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_EMPTY:
				{
					csfMgr.contentListResponseListener(eventType, param1, param2);
				}
				break;
			case CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_CONNECTED:
			case CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_DISCONNECTED:
			case CSFSefType.SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED:
				{
					csfMgr.dlnaResponseListener(eventType, param1, param2);
				}
				break;
			case CSFSefType.SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED:
			case CSFSefType.SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED:
			case CSFSefType.SEF_CSF_EVENT_SHARE_FILE_UPDATE:
			case CSFSefType.SEF_CSF_EVENT_SHARE_FAIL:
				{
					csfMgr.csfSendDataResponseListener(eventType, param1, param2);
				}
				break;
			default:
				break;
		}
	};
	
	this.onThumbCallback = function(eventType, param1, param2){
		csfMgr.thumbnailResponseListener(eventType, param1, param2);
	};

	this.registerContentListCallback = function(cb){
		this.contentListResponseListener = cb;		
	};

	this.registerCsfSendDataCallback = function(cb){
		this.csfSendDataResponseListener = cb;
	};
	
	this.registerThumbnailCallback = function(cb){
		this.thumbnailResponseListener = cb;
	};

	this.registerDlnaCallback = function(cb){
		this.dlnaResponseListener = cb;
	};	


	this.registerRaCallback = function(cb){
		this.raResponseListener = cb;
	};
	
	this.CSFAsyncOpenCallback = function(){
		print("csf-manager >>>>>>>>>>>>>>>>>> CSFAsyncOpenCallback!!!!");
		csfMgr.setMediaExtensionFilter();		
		EventMediator.trigger(EventType.EVENT_TYPE_CSF_INIT);
	};
	
	this.open = function(){
		print("csf-manager.js csf sef open");
		
		/*this.csfsef = new Sef();
		this.csfsef.onEventCallback = this.onEventCallback;  //this.onRequestResult;
		var ret= this.csfsef.open("Local", "1.0", "None");
		print("csf-manager.js open local sef :", ret);


		this.thumbsef = new Sef();
		this.thumbsef.onEventCallback = this.onThumbCallback; //this.onThumbResult;
		var ret2= this.thumbsef.open("CsfThumbnail", "1.0", "None");
		print("csf-manager.js open thumbnail sef :", ret2);
		*/
	//	voltapi.CSF.init();
		var pvrOpen = voltapi.PVR.initAsync(function(){
			csfMgr.pvrInit = true;
			print('PVR init Async success call back');
		});
		print('pvr open return :' + pvrOpen);
		

		var CSFAsyncOpen = voltapi.CSF.initAsync(this.CSFAsyncOpenCallback);
		print(">>>>>>>>>>>>>>>>>>CSFAsyncOpen result : " + CSFAsyncOpen); 
		
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_EMPTY, this.requestListEmptyCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_SUCCESS, this.requestListSuccessCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_FAIL, this.requestListFailCb);

		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED, this.shareOneFileFinishedCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED, this.shareAllFileFinishedCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_SHARE_FILE_UPDATE, this.shareFileUpdateCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_SHARE_FAIL, this.shareFailCb);

		voltapi.CSF.addEventListener(CSFSefType.CSF_EVENT_THUMBNAIL_FINISHED, this.thumbnailFinishedCb);
		voltapi.CSF.addEventListener(CSFSefType.CSF_EVENT_THUMBNAIL_FAIL, this.thumbnailFailCb);
		
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_CONNECTED, this.dlnaDeviceConnectCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_DISCONNECTED,  this.dlnaDeviceDisconnectCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED,this.dlnaDeviceFinishedCb);

		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_RA_DEVICE_CONNECTED, this.raDeviceConnectCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED, this.raDeviceDisConnectallCb);
		voltapi.CSF.addEventListener(CSFSefType.SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED_ALL, this.raDeviceDisConnectallCb);

		
	};		
	
	this.addEventCallback = function( eType, cb ){
		voltapi.CSF.addEventListener(eType, cb);
	};

	this.requestList = function(para){
		print("csf-manager requestList");	
				//this.csfsef.execute("csf_request_list",JSON.stringify(para));
		print('requestList >>>>>>>>>>>>>>>>>>>>> para: ',JSON.stringify(para));
		Log.e("requestList >>>>>>>>>>>>>>>>>>>>> para: " + JSON.stringify(para));
			
		if(para.param_requester_id != 'music-player'){
			this.disconnectCsf();	
		}else{
			print(" music player request, do not disconenct content view csf agent.");
			Log.e(" music player request, do not disconenct content view csf agent.");

		}
	var result = voltapi.CSF.csfRequestList(para);
		print('csf sef request list end:'+JSON.stringify(result));
		Log.e("csf sef request list end"+JSON.stringify(result));
		if(result != null){
			print(" csf sef request list end agent:");
			var agent = JSON.parse(JSON.stringify(result)).return_data;
			print(" csf sef request list end agent:"+agent);
			ViewGlobalData.agent = agent;
		}else{
			Log.e(" csf sef request list end result == null");
		}
	};

	
	this.requestThumbnail  = function(para){
	
		print('[CSFJSAPI.js] requestThumbnail');
		//var value= this.thumbsef.execute("thumbnail_request_async", JSON.stringify(para));
		var value = voltapi.CSF.thumbnailRequestAsync(para);
		print('[CSFJSAPI.js] requestThumbnail end:',value );
		
	};
	
	this.cancelAllThumbnailRequest = function(){
		print('[CSFJSAPI.js] cancel requestThumbnail');
		para = {
			param_cancel: 1,
		};
		//this.thumbsef.execute("thumbnail_request_cancel_all",JSON.stringify(para));
		voltapi.CSF.thumbnailRequestCancelAll(para);
		print('[CSFJSAPI.js] cancel requestThumbnail end' );
		
	};

	this.cancelPtpThumbnailRequest = function(){
		print('[CSFJSAPI.js] cancel ptp requestThumbnail');
		para = {
			param_cancel: 1,
		};
		//this.thumbsef.execute("thumbnail_stop_ptp_decode_sync",JSON.stringify(para));
		voltapi.CSF.thumbnailStopPtpDecodeSync(para);
		print('[CSFJSAPI.js] cancel ptp requestThumbnail end' );
		
	};
	
	this.disconnectCsf = function(){
		print('[disconnectCsf] Csf_agent : ',ViewGlobalData.agent);
		Log.e("[disconnectCsf] Csf_agent : "+ViewGlobalData.agent);
		if(ViewGlobalData.agent != null){			
			
			var disconnectcsfpara ={
				"param_agent":ViewGlobalData.agent
			}
			
			print('csf-manager clase diconnectcsfpara :',JSON.stringify(disconnectcsfpara));
			Log.e("csf-manager clase diconnectcsfpara :"+JSON.stringify(disconnectcsfpara));
			//this.csfsef.execute("csf_disconnect", JSON.stringify(disconnectcsfpara));
			voltapi.CSF.csfDisconnect(disconnectcsfpara);
			
			
		}
		ViewGlobalData.agent = null;
	};
	
	this.close = function(){
		print("Close csf function~~~~~~~~~~~");
		this.disconnectCsf();
		
		//this.csfsef.close();
		//this.thumbsef.close();
		
		voltapi.CSF.destroy();
		voltapi.PVR.destroy();
	};

	this.isPVRRecordingFile = function(para){
		if(this.pvrInit){
			var returnData =  voltapi.PVR.isRecordingFile(para);
			print('returnData:' + returnData);
			if(returnData != undefined && typeof(returnData) != "string"){
				print('returnData.str_result: ' + returnData.str_result);
				return returnData.str_result;
			}
		}
		return false;
	};
	
	this.isCIThumb = function(para){
	    if(this.pvrInit){
            var returnData =  voltapi.PVR.getCIThumbType(para);
            Log.e('returnData:' + returnData);
            if(returnData != undefined && typeof(returnData) != "string"){
                Log.e('returnData.str_result: ' + returnData.str_result + 'returnData.str_thumbType: ' + returnData.str_thumbType);
                if(returnData.str_result && (returnData.str_thumbType == CIThumbType.E_THUMB_PARTIAL_RETENTION || 
                    returnData.str_thumbType == CIThumbType.E_THUMB_INVALID)) {
                        return returnData.str_thumbType;
                    }
            }
            
        }
        return -1;
	};
	this.setNavigation = function(para) {
		print(" ------------------------->> csf_set_navigation();", para);
		//return this.csfsef.execute("csf_set_navigation", JSON.stringify(para));
		return voltapi.CSF.csfSetNavigation(para);
	};
	this.setPageStyle = function(para){
		print("setPagestyle");
		//return this.csfsef.execute("csf_set_page_style", JSON.stringify(para));
		return voltapi.CSF.csfSetPageStyle(para);
	};

	this.setSelectAllItems = function(para){
		print("[csf-manager.js]setSelectAllItems");
		//return this.csfsef.execute("csf_select_all", JSON.stringify(para));
		return voltapi.CSF.csfSelectAll(para);
	};

	this.setSelectItem = function(para){
		print("[csf-manager.js]setSelectItem()");
		//return this.csfsef.execute("csf_toggle_select", JSON.stringify(para));
		return voltapi.CSF.csfToggleSelect(para);
	};

	this.desSelectItem = function(para){
		print("[csf-manager.js]setSelectItem()");
		//return this.csfsef.execute("csf_toggle_select", JSON.stringify(para));
		return voltapi.CSF.csfToggleSelect(para);

	};
	
	this.disSelectAllItems = function(para){
		print("[csf-manager.js]disSelectAllItems");
		//return this.csfsef.execute("csf_deselect_all", JSON.stringify(para));
		return voltapi.CSF.csfDeselectAll(para);
	};
	this.send = function(para){
		print("[csf-manager.js]send");
		return voltapi.CSF.csfSend(para);
		//return this.csfsef.execute("csf_send", JSON.stringify(para));
	};
	this.stopSend = function(para){
		print("[csf-manager.js]stopSend");
		return voltapi.CSF.csfStopSend(para);
		//return this.csfsef.execute("csf_stop_send", JSON.stringify(para));
	};
	this.getSelectStatus = function(para){
		print(" ------------------------->> getSelectStatus();", para);
		//return JSON.parse(this.csfsef.execute("csf_get_selected_state", JSON.stringify(para)));
		return voltapi.CSF.csfGetSelectedState(para);
	};
	this.getSelectCount = function(para){
		print(" ------------------------->> getSelectCount();", para);
		//return JSON.parse(this.csfsef.execute("csf_get_selection_count", JSON.stringify(para)));
		return voltapi.CSF.csfGetSelectionCount(para);
	};
	this.getItemCount = function(para){
		print(" ------------------------->> csf_get_item_count();", para);
		//return JSON.parse(this.csfsef.execute("csf_get_item_count", JSON.stringify(para)));
		return voltapi.CSF.csfGetItemCount(para);
	};
	this.moveToIndex = function(para){
		//print(" ------------------------->> csf_move_to_index();", para);
		//return JSON.parse(this.csfsef.execute("csf_move_to_index", JSON.stringify(para)));
		return voltapi.CSF.csfMoveToIndex(para);
	};
	this.getItemValueChar = function(para){
		//print(" ------------------------->> csf_get_item_value_char();", para);
		//return JSON.parse(this.csfsef.execute("csf_get_item_value_char", JSON.stringify(para)));
	};
	this.getItem = function(para){
		//return JSON.parse(this.csfsef.execute("csf_get_item", JSON.stringify(para)));
		return voltapi.CSF.csfGetItem(para);
	};

	this.getItemList = function(para){
		//return JSON.parse(this.csfsef.execute("csf_get_item_list", JSON.stringify(para)));
		return JSON.parse(voltapi.CSF.csfGetItemList(para));
	};
	this.getItemValue = function(para){
		//return JSON.parse(this.csfsef.execute("csf_get_item_value", JSON.stringify(para)));
		return JSON.parse(voltapi.CSF.csfGetItemValue(para));
	};

	this.setItemValue = function(para){
		//return JSON.parse(this.csfsef.execute("csf_set_item_value", JSON.stringify(para)));
		return voltapi.CSF.csfSetItemValue(para);
	};
	
	this.getDLNAList = function(){
		print("[getDLNAList] : get dlna device list");
		//return JSON.parse(this.csfsef.execute("csf_get_dlna_list"));
		return voltapi.CSF.csfGetDlnaList();
	};
	this.getRaList = function(){
		print("[getRaList] : get ra device list");
		//return JSON.parse(this.csfsef.execute("csf_ra_get_device_list"));
		return voltapi.CSF.csfRaGetDeviceList();
	};
	print('csf-manager.js end--------------');
	
	this.getPreparePlayData = function(para){
		//return JSON.parse(this.csfsef.execute("csf_prepare_play_data", JSON.stringify(para)));
		return voltapi.CSF.csfPreparePlayData(para);
	};

	this.getPageIndex = function(para){
		//return JSON.parse(this.csfsef.execute("csf_get_page_index", JSON.stringify(para)));
		return JSON.parse(voltapi.CSF.csfGetPageIndex(para));
	};
	this.getRatingInfo = function(){
		
		var csfpara ={
				"param_agent":ViewGlobalData.agent
		};
		return voltapi.CSF.csfGetRatingInfo(csfpara);
	};
	this.setMediaExtensionFilter = function(){
		var MimeTypeFilter = Volt.require('app/models/mime-type-filter.js');
		var videoExtention = MimeTypeFilter.VideoFilter;//JSON.stringify(MimeTypeFilter.VideoFilter); 
		var photoExtention = MimeTypeFilter.PhotoFilter;//JSON.stringify(MimeTypeFilter.PhotoFilter);
		var musicExtention = MimeTypeFilter.MusicFilter;//JSON.stringify(MimeTypeFilter.MusicFilter); 
		var pvrExtention = MimeTypeFilter.PvrFilter;//JSON.stringify(MimeTypeFilter.PvrFilter);
		var uhdExtention = MimeTypeFilter.UhdFilter;//JSON.stringify(MimeTypeFilter.UhdFilter);
		var scsaExtention = MimeTypeFilter.ScsaFilter;//JSON.stringify(MimeTypeFilter.ScsaFilter);
		var checkResolution =  VDUtil.getResolution();
		print("setMediaExtensionFilter checkResolution:"+checkResolution);
		Log.e("setMediaExtensionFilter checkResolution:"+checkResolution);
		if(1280 == checkResolution){
		var extention = {
							param_media_extension_image : photoExtention,
							param_media_extension_video: videoExtention,
							param_media_extension_music: musicExtention,
							param_media_extension_pvr: pvrExtention,
					//		param_media_extension_uhd: uhdExtention,
							param_media_extension_scsa: scsaExtention,
						};

		}else{
		var extention = {
							param_media_extension_image : photoExtention,
							param_media_extension_video: videoExtention,
							param_media_extension_music: musicExtention,
							param_media_extension_pvr: pvrExtention,
							param_media_extension_uhd: uhdExtention,
							param_media_extension_scsa: scsaExtention,
						};
		}
		return voltapi.CSF.csfSetMediaExtensionFilter(extention);
	};
	
};
var csfMgr = new CsfManager();

csfMgr.open();

exports = csfMgr;
