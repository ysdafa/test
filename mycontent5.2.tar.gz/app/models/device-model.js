 /** 
 * @author  Li Hailong (hailong08.li@samsung.com)
 * 			
 * @fileoverview  Manage device 
 * @date    2014/07/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');
var CommonInfo = Volt.require("app/common/define.js");

var EItemType = CommonInfo.EItemType;

var DeviceModel = Backbone.Model.extend({
    defaults: {
    	index:1,
    	availableSize : 0,
    	totalSize: 0,
    	id: '',
    	mountPath: '',
    	virtualPath:'',
        name: '',
        modelName:'',
        displayName:'',
        partitionLabel:'',
        fileSystem:'',
        serialNumber:'',
    	type: '',
    	venderId: 0, 
    	venderName:'',     	
 		address: 0,
 		bus:0,
 		uhd:false,

 		//DLNA device
 		ip:'',
 		bSamsungDevice: false,

		//RA
		groupID:null,
		instanceID:null,
 		
    },
});


exports = DeviceModel;
