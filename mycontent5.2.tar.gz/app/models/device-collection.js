 /**
 * @author  Li Hailong (hailong08.li@samsung.com)
 *
 * @fileoverview  Manage device
 * @date    2014/07/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

	var Backbone = Volt.require('modules/backbone.js');
	var DeviceModel = Volt.require('app/models/device-model.js');

//	var VoltApi = require("voltapi");
	var VoltApi = Volt.require('voltapi.js');
	//var VoltApi = Volt.require('modules/voltapi.js');
	var launchParams = Volt.require("app/common/launch-params.js");
	var CommonInfo = Volt.require('app/common/define.js');
	var RunTimeInfo = Volt.require('app/common/run-time-info.js');
	var EventMediator = RunTimeInfo.EventMediator;
	var EventType = CommonInfo.EventType;
	var CSFSefType = CommonInfo.CSFSefType;
	var LaunchedByAppID = CommonInfo.LaunchedByAppID;
	var self  = null;
	
	var DeviceType = CommonInfo.DeviceType;
	var UHD_DEVICE = 'UHD Video Pack';
	var DeviceCollection = Backbone.Collection.extend({
		model : DeviceModel,
		itemCount: 0,
		usbDeviceCount:0,
		dlnaDeviceCount:0,
		raDeviceCount:0,
		contentMgrInit:false,
		csfInit:false,
		timeOut:null,
		
		_printDeviceInfo:function(deviceInfo){
				print("***************************************");
				print("device availableSize: ", deviceInfo.availableSize);
				print("device totalSize: ", deviceInfo.totalSize);
				print("device id: ", deviceInfo.id);
				print("device name: ", deviceInfo.name);
				print("device modelName: ", deviceInfo.modelName);
				print("device mountPath: ", deviceInfo.mountPath);
				print("device virtualPath: ", deviceInfo.virtualPath);
				print("device type: ", deviceInfo.type);
				print("device vender: ", deviceInfo.vender);
				print("device venderName: ", deviceInfo.venderName);
				print("device fileSystem: ", deviceInfo.fileSystem);
				print("device serialNumber: ", deviceInfo.serialNumber);
				print("device partitionLabel: ", deviceInfo.partitionLabel);
				print("device deviceAddress: ", deviceInfo.deviceAddress);
				print("device deviceBus: ", deviceInfo.deviceBus);
				print("device deviceClass: ", deviceInfo.deviceClass);
				print("***************************************");

		},
		/** Search device by id
		* @name searchDevice
		* @memberOf DeviceCollection
		* @param {id} Device Id
		* @method
		* */
		searchDevice: function(id){
			print('[searchDevice] id : ',id);
			var deviceItem = self.where({'id': id});
			if(deviceItem != null && deviceItem != undefined && deviceItem.length > 0) {
				
				if(deviceItem[0].id == id){
					print("searchDevice  >>>>>>>>>>>>>>>>>>>>> Finde device");
					return deviceItem[0];
				}
			}
			return null;
		},
		/** Get device id by  MountPath
		* @name getDeviceIdByMountPath	 
		* @memberOf DeviceCollection
		* @method 	 
		* */
		getDeviceIdByMountPath:function(deviceMountPath){
			var collectionSize = self.length;
			print("[getDeviceIdByMountPath]   deviceMountPath :",deviceMountPath,collectionSize);
			
			if((deviceMountPath == null) || (deviceMountPath == undefined)){
				return null;
			}

			var deviceItems = this.where({'mountPath': deviceMountPath});

			if(deviceItems != null && deviceItems != undefined && deviceItems.length > 0) {				
				print("[getDeviceIdByMountPath]  Finde device mountpath:",deviceItems[0].get('mountPath'));		
				if(deviceItems[0].get('mountPath') != null && deviceItems[0].get('mountPath') != undefined && (deviceItems[0].get('mountPath') == deviceMountPath)){
					return deviceItems[0].get('id');
				}
			}
			return null;
		},
		/** Get device list from CM 	 
		* @name _getDeviceList	 
		* @memberOf DeviceCollection
		* @method
		* */
		_getDeviceList : function() {
			var resultGetStorages;
			print('_getDeviceList >>>>>  getStorages from ContentsMgr start');
 			resultGetStorages = VoltApi.ContentsMgr.getStorages();
 		//	print("Func-- _getDeviceList : ",resultGetStorages);
	 		print('_getDeviceList >>>>>  getStorages from ContentsMgr finish');
 			var deviceInfo = JSON.stringify(resultGetStorages);

			print("device-collection.js _getDeviceList deviceInfo : ",deviceInfo);
			Log.e("device-collection.js _getDeviceList deviceInfo : " + deviceInfo);
			
 			if(deviceInfo == null){
 				return [];
 			}
			var storagesList = null;
			storagesList = JSON.parse(deviceInfo);
			if(storagesList != undefined && storagesList.storages != undefined){
				
				return storagesList.storages;
			}
			else
			{
				return [];
			}
		},
		/** Get valid index of same partition label
		* @name _GetValidIndex
		* @memberOf DeviceCollection
		* @param {IndexVector} Used index vector of same partition label
		* @param {MaxIndex}    Max index of same partition label
		* @method
		* */
		_GetValidIndex:function(usedIndexVector,MaxIndex){
			var ValidIndex = 1;
			var isValid = 1;
			if (usedIndexVector.length > 0){
				//find min unused index, 
				for (var nIdex = 1; nIdex <= MaxIndex; nIdex++){
					isValid = 1;
					
					for(var j = 0; j < usedIndexVector.length; j++){
						if (nIdex == usedIndexVector[j]){

							isValid = 0;
							break;
						}
					}
					if(isValid == 1){
						ValidIndex = nIdex
						break;
					}
				}
			}
			//if there is no valid index between 1 and MaxIndex, ValidIndex = MaxIndex + 1
			if(isValid == 0){
				ValidIndex = MaxIndex + 1;
			}

			print('ValidIndex:',ValidIndex);
			return ValidIndex;
		},

		/** Get device partition label, when there are more device has the same partition label
		* @name _getPartitionLabelIndex
		* @memberOf DeviceCollection
		* @param {newDeviceInfo}  Device information
		* @method 	 
		* */
		_getPartitionLabelIndex:function(newDeviceInfo){
			var dispalyName;
			var index = [];
			var maxIndex = 1;
			var deviceInfo = null;
			print("_getPartitionLabelIndex!!!!");
			print('_getPartitionLabelIndex new device  ~~~~~~~~~');
			
			//var deviceItems = self.where({'name': newDeviceInfo.name});
			
			//find same device
			var deviceItems = self.where({'serialNumber': newDeviceInfo.serialNumber});
			
			if(deviceItems == null || deviceItems == undefined || deviceItems.length == 0){
				Log.e("There is no same HDD partition");
				print("There is no same HDD partition");
				return 1;
			}
			print("deviceItems.length : "+deviceItems.length);

			/*
			if(deviceItems.length == 1){
				Log.e("The first same name device");
				print("The first same name device");
				deviceInfo = deviceItems[0];	
				var displayName = deviceInfo.get('displayName') +' 1';
				
				Log.e("set displayName device:"+displayName);
				print("set displayName device:"+displayName);
				
				deviceInfo.set('displayName', displayName);				
				
				EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_DEVICE, deviceInfo);
			}
			*/
			
			for(var i = 0; i < deviceItems.length; i++){
				
				 deviceInfo = deviceItems[i];		
				 print("deviceInfo.name :"+deviceInfo.get('name')+'F');
				 print("newDeviceInfo.name :"+newDeviceInfo.name+'F');
				if(newDeviceInfo.id == deviceInfo.get('id') || deviceInfo.get('name') != newDeviceInfo.name){
					print('_getPartitionLabelIndex return -1');
					Log.e('_getPartitionLabelIndex return -1');
					return -1;
				}
				
				print('partitionLabel is same');	
				print('index  : ',deviceInfo.get('index'));		
				index.push(deviceInfo.get('index'));
				
				if(maxIndex < deviceInfo.get('index')){
					maxIndex = deviceInfo.get('index');
				}						
				
			
			}
			
			print("[_getPartitionLabelIndex] maxIndex : ",maxIndex);
			
			var ValidIndex = self._GetValidIndex(index,maxIndex);
			
			return ValidIndex;
		},
		
		getUHDVideoPackFlag:function(deviceinfo){
			var uhd = false;
			print("getUHDVideoPackFlag");
			
			if((deviceinfo.vendor == UHD_DEVICE && deviceinfo.name == 'UHD Video Pack')
			||(deviceinfo.vendor == 'Samsung' && deviceinfo.name == 'Samsung STORY Station')
			||(deviceinfo.vendor == 'Samsung' && deviceinfo.name == 'UHD Video Pack')){
				
				uhd = true;
			}

			return uhd;
		},
		/** New device item use device information	 
		* @name _newDeviceItem	 
		* @memberOf DeviceCollection
		* @param {deviceinfo}  Device information
		* @param {displayName}  Device displayName
		* @param {type}  Device type, such as: USB/DLAN/RA/PTP
		* @param {mountPath}  Device mountPath
		* @method
		* */
		_newDeviceItem:function(deviceinfo, displayName, type, mountPath){
			var deviceid = deviceinfo.id;
			print("_newDeviceItem deviceid :" + deviceid);
			print("_newDeviceItem type :" + type);
			var uhd = false;
			
			uhd = self.getUHDVideoPackFlag(deviceinfo);
			
			print("_newDeviceItem uhd:" + uhd);
			
			print('_newDeviceItem type : '+ type + ',deviceid : '+ deviceid);
			return new DeviceModel({
							index:1,
							availableSize : deviceinfo.availableSize,
		   					totalSize : deviceinfo.totalSize,
		   					id : deviceid,
		   					mountPath: mountPath,
		   					virtualPath:deviceinfo.virtualPath,
		   					name : deviceinfo.name,
		   					modelName:deviceinfo.modelName,
		   					displayName:displayName,
		   					partitionLabel:deviceinfo.partitionLabel,
		   					fileSystem:deviceinfo.fileSystem,
		   					serialNumber:deviceinfo.serialNumber,		   					
		   					type :type,
		   					venderId:deviceinfo.venderId,
		   					venderName:deviceinfo.vendor,
		   					address:deviceinfo.deviceAddress,
		   					bus:deviceinfo.deviceBus,
		   					uhd:uhd
		   					});
		},
		/** Get all connected device on apps run
		* @name _getConnectedUsbDevice
		* @memberOf DeviceCollection
		* @method
		* */
		_getConnectedUsbDevice:function(notifyAddFlag){
			var deviceList = [];
			deviceList = self._getDeviceList();
			print("device-collection.js _getConnectedUsbDevice lenght:", deviceList.length);
			Log.e("device-collection.js _getConnectedUsbDevice lenght:" + deviceList.length);
			for(var i = 0; i < deviceList.length; i++) {
				var deviceItem = null;
			//	self._printDeviceInfo(deviceList[i]);
				if(deviceList[i].type == 'msc' && 
					(deviceList[i].mountPath == null || deviceList[i].mountPath == 'n/a')){
					print("New device deviceList.mountPath == null");
					Log.e("New device deviceList.mountPath == null");
					continue;
				}
				if(deviceList[i].type == 'ptp'){
					deviceList[i].id = deviceList[i].serialNumber;

				}else if(deviceList[i].type == 'msc'){
					deviceList[i].id = deviceList[i].mountPath;
				}
							
				deviceList[i].name = deviceList[i].name.trim();

				print('after  trim deviceList[i].name:',deviceList[i].name);
				Log.e("after  trim deviceList[i].name:" +deviceList[i].name);
							
				var mountPath =deviceList[i].mountPath;
				mountPath = mountPath.replace('$USB_DIR', '/opt/storage/usb');
				print('Mount path',mountPath);
				Log.e("Mount path" + mountPath);
				
				print('~~~~~~~~~~~~~~!!!!!!!!!!!!!!!!!!!!!!',deviceList[i].name);
				var deviceType = deviceList[i].type;
				var type;
				if(deviceType == 'ptp'){
					type = DeviceType.DEVICE_TYPE_PTP;
				} else if(deviceType == 'msc'){
					type = DeviceType.DEVICE_TYPE_USB;
				}else{
					type = DeviceType.DEVICE_TYPE_USB;
				}

				deviceItem = self.searchDevice(deviceList[i].id);

				var partitionLabelIndex =self._getPartitionLabelIndex(deviceList[i]);
				print('partitionLabelIndex : ',partitionLabelIndex);
				var displayName = deviceList[i].name;
				//if partitionLabelIndex = -1,  
				if(partitionLabelIndex > 1){
					displayName = deviceList[i].name +' ('+ partitionLabelIndex.toString()+')';
				}else{
					if(deviceItem != null){
						displayName = deviceItem.get('displayName');
					}
				}
				
				if(deviceItem == null) {
					Log.e(" _getConnectedUsbDevice  new DeviceItem");
					print(" _getConnectedUsbDevice  new DeviceItem");
					
					deviceItem = self._newDeviceItem(deviceList[i],displayName,type,mountPath);

	   				print('partitionLabel::', deviceItem.get('partitionLabel'));
	   				print('displayName::', deviceItem.get('displayName'));

	   				if(partitionLabelIndex > 1) {
	   					deviceItem.set('index',partitionLabelIndex);
	   				}
	   				self.usbDeviceCount++;
	   				self.add(deviceItem);
					
					if(notifyAddFlag == true){
						print(" _getConnectedUsbDevice  add  ");
						EventMediator.trigger(EventType.EVENT_TYPE_ADD_DEVICE, deviceItem);
					}
					
				} else{			
					Log.e(" _getConnectedUsbDevice  updateDeviceInfo");
					print(" _getConnectedUsbDevice  updateDeviceInfo");
					if(partitionLabelIndex > 1) {
	   					deviceItem.set('index',partitionLabelIndex);
	   				}
					self.updateDeviceInfo(deviceList[i].id,deviceList[i],displayName,type,mountPath);
					
					EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_DEVICE, deviceItem);
				}
			}
		},
		
		updateDeviceInfo : function(deviceid, newInfo,displayName,type,mountPath){
			print("update device info~~~~ id :" + deviceid);
			
			var deviceItem = self.searchDevice(deviceid);			
			
			deviceItem.set('id', deviceid);
			deviceItem.set('displayName', displayName);
			deviceItem.set('mountPath', mountPath);
			deviceItem.set('type', type);
			deviceItem.set('totalSize', newInfo.totalSize);
			deviceItem.set('availableSize', newInfo.availableSize);
			deviceItem.set('name', newInfo.name);
			deviceItem.set('modelName', newInfo.modelName);

			deviceItem.set('partitionLabel', newInfo.partitionLabel);
			deviceItem.set('fileSystem', newInfo.fileSystem);

			deviceItem.set('serialNumber', newInfo.serialNumber);
			deviceItem.set('venderId', newInfo.venderId);
			deviceItem.set('venderName', newInfo.venderName);
			deviceItem.set('address', newInfo.address);

			deviceItem.set('bus', newInfo.bus);
			deviceItem.set('ip', newInfo.ip);
			deviceItem.set('bSamsungDevice', newInfo.bSamsungDevice);
			deviceItem.set('address', newInfo.address);
			
		},
		onTimeOut:function(){
			print(" onTimeOut  get device list ");
			Log.e(" onTimeOut  get device list ");
			self._getConnectedUsbDevice(true);	
		},
		/** usb device connect callback
		* @name onUsbDeviceConnect
		* @memberOf DeviceCollection
		* @method
		* */
		 onUsbDeviceConnect : function(deviceInfo, agr2) {		
		 	
			print('[onUsbDeviceConnect]======deviceInfo ',deviceInfo);		
			
	 		var newDeviceInfo = JSON.stringify(deviceInfo);

			print("newDeviceInfo : ",newDeviceInfo);
			Log.e("[ onUsbDeviceConnect ] newDeviceInfo : " + newDeviceInfo);

			if( self.timeOut!= null ){
				print("onUsbDeviceConnect clear time");
				Volt.clearTimeout(self.timeOut);
				self.timeOut = null;
			}
			self.timeOut =  Volt.setTimeout(self.onTimeOut, 1000);	

			print(" After connect event, get list again ");
			return;
			var storagesList = null;
			storagesList = JSON.parse(newDeviceInfo);
			print("~~~~~~~~~~~~~~~~~~storagesList : ",storagesList);
			var storages = storagesList["storage"];
			print("storages : ",storages);
			//	self._printDeviceInfo(deviceList[i]);
			if(storages != null && storages != undefined){	
				//if exist same device, ignore
				
				
				if(storages.type == 'ptp'){
					print("This is PTP device, no id,  use serial NO:"+storages.serialNumber);
					Log.e("This is PTP device, no id,  use serial NO:"+storages.serialNumber);
				
					storages.id = storages.serialNumber;
					
					
				}else if(storages.type == 'msc'){
				
					storages.id = storages.mountPath;
				}	
				var deviceid = storages.id;
				
				storages.name = storages.name.trim();
				
				var partitionLabelIndex =self._getPartitionLabelIndex(storages);
				var displayName = storages.name;
				
				if(partitionLabelIndex > 1){
					displayName = storages.name +' ('+ partitionLabelIndex.toString()+')';
				} 
				
				var mountPath = storages.mountPath;
				print('mountPath ====== : ',mountPath);
				mountPath = mountPath.replace('$USB_DIR', '/opt/storage/usb');
				var deviceClass = storages.type;
				var type;
				if(deviceClass == 'ptp'){
					type = DeviceType.DEVICE_TYPE_PTP;
				} else {
					type = DeviceType.DEVICE_TYPE_USB;
				}
				
				print('Mount path',mountPath);
				Log.e("onUsbDeviceConnect Mount path:"+mountPath);
				
				var deviceItem = null;
				deviceItem = self.searchDevice(deviceid);	
				if(deviceItem != null && deviceItem != undefined){
	
					print('onUsbDeviceConnect Same device updateDeviceInfo>>>>>>>>>>>>>>>>>>>>>>>>  id: ',deviceid);
					Log.e("onUsbDeviceConnect Same device updateDeviceInfo>>>>>>>>>>>>>>>>>>>>>>>>  id: "+ deviceid);
					
	   				if(partitionLabelIndex > 1) {
   						deviceItem.set('index',partitionLabelIndex);
	   				}
					
					self.updateDeviceInfo(deviceid,storages,displayName,type,mountPath);
					
					EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_DEVICE, deviceItem);
					
				}else{
					print('onUsbDeviceConnect _newDeviceItem >>>>>>>>>>>>>>>>>>>>>>>>  id: ',deviceid);
					Log.e("onUsbDeviceConnect _newDeviceItem >>>>>>>>>>>>>>>>>>>>>>>>  id: " + deviceid);
					
					deviceItem = self._newDeviceItem(storages,displayName,type,mountPath);
					
	   				if(partitionLabelIndex > 1) {
	   						deviceItem.set('index',partitionLabelIndex);
	   				}
	   				self.usbDeviceCount++;
	   				self.add(deviceItem);
	   				EventMediator.trigger(EventType.EVENT_TYPE_ADD_DEVICE, deviceItem);
				}
   					   				
			}		
		},
		/** usb device disconnect callback
		* @name onUsbDeviceDisconnect	 
		* @memberOf DeviceCollection
		* @method 	 
		* */
		 onUsbDeviceDisconnect : function(deviceInfo, agr2) {
		 	var deviceItem = null;
			var newDeviceInfo = JSON.stringify(deviceInfo);
			print("onUsbDeviceDisconnect DeviceInfo"+newDeviceInfo);
			var storagesList = null;
			storagesList = JSON.parse(newDeviceInfo);
			print("onUsbDeviceDisconnect~~~~~~~~~~~~~~~~~~storagesList : ",storagesList);
			Log.e("onUsbDeviceDisconnect~~~~~~~~~~~~~~~~~~storagesList : ");
			
			var storages = storagesList["storage"];
			
			var deviceId = storages.mountPath;
			
			if(storages.type == 'ptp'){
				print("This is PTP device, no id,  use serial NO:"+storages.serialNumber);
				Log.e("This is PTP device, no id,  use serial NO:"+storages.serialNumber);
				deviceId = storages.serialNumber;
			}
			
		 	print('[onUsbDeviceDisconnect]======deviceId ',deviceId);	
		 	Log.e("[onUsbDeviceDisconnect]======deviceId "  + deviceId);	

			deviceItem = self.searchDevice(deviceId);
			if(deviceItem != null){
				var devType = deviceItem.get('type');
				self.usbDeviceCount--;
				self.remove(deviceItem);		
				EventMediator.trigger(EventType.EVENT_TYPE_DEL_DEVICE, deviceId,devType);	
			}
		},
		/** add DLNA device
		* @name addDLNADevice	 
		* @memberOf DeviceCollection
		* @param {deviceList} add DLNA Device list
		* @method 	 
		* */
		addDLNADevice : function(deviceList){
			print("[addDLNADevice] deviceList ",deviceList);
			for(var i = 0; i < deviceList.length; i ++){
				deviceList[i].deviceName = deviceList[i].deviceName.trim();
				print("********************************");
				print("deviceList ",i,':name ', deviceList[i].deviceName);
				print("deviceList ",i,':id ', deviceList[i].deviceID);
				print("deviceList ",i,':bSamsungDevice ', deviceList[i].bSamsungDevice);
				print("deviceList ",i,':deviceIP ', deviceList[i].deviceIP);
				print("********************************");
				
				Log.e("addDLNADevice deviceList "+ i + ":name " + deviceList[i].deviceName);
				Log.e("addDLNADevice deviceList "+ i + ":deviceIP " + deviceList[i].deviceIP);
				Log.e("addDLNADevice deviceList " + i+ ":id " + deviceList[i].deviceID);
				//if there is same ip dlna device, only display first one.				
				//var dlnaDeviceList = self.where({'ip': deviceList[i].deviceIP});
				//if(dlnaDeviceList != null && dlnaDeviceList != undefined && dlnaDeviceList.length != 0){
				//	print('Same dlna device');
				//	continue;
				//}
				
				var partitionLabelIndex =self._getPartitionLabelIndex(deviceList[i]);
				var displayName = deviceList[i].deviceName;
				
				if(partitionLabelIndex != 0){
					displayName = displayName +' ('+ partitionLabelIndex.toString()+')';
				} 
				
				deviceItem = new DeviceModel({
		   					id : deviceList[i].deviceID,
		   					name : deviceList[i].deviceName,
		   					displayName:deviceList[i].deviceName,
		   					type :DeviceType.DEVICE_TYPE_DLNA,
		   					ip:deviceList[i].deviceIP,
		   					bSamsungDevice:deviceList[i].bSamsungDevice
		   					});
		   					
		   					self.dlnaDeviceCount++;
		   				self.add(deviceItem);		 
				print('fist get dlna device is ',RunTimeInfo.firstGetDlna);		
			
		   		if(RunTimeInfo.firstGetDlna == true){	
					print('fist get dlna device is ',RunTimeInfo.firstGetDlna);
					EventMediator.trigger(EventType.EVENT_TYPE_ADD_FIRST_DLNA_DEVICE, deviceItem);  				
				}
	   			else {
			   		EventMediator.trigger(EventType.EVENT_TYPE_ADD_DEVICE, deviceItem);
   				}
			
			}
		},
		/** Remove DLNA device
		* @name removeDLNADevice	 
		* @memberOf DeviceCollection
		* @param {deviceList} remove DLNA Device list
		* @method 	 
		* */
		removeDLNADevice : function(deviceList){
			print("[removeDLNADevice] deviceList ",deviceList);
			for(var i = 0; i < deviceList.length; i ++){
				print("deviceList ",i,':name ', deviceList[i].deviceName);
				print("deviceList ",i,':id ', deviceList[i].deviceID);
				print("deviceList ",i,':bSamsungDevice ', deviceList[i].bSamsungDevice);
				print("deviceList ",i,':deviceIP ', deviceList[i].deviceIP);

				Log.e("removeDLNADevice deviceList "+ i + ":name " + deviceList[i].deviceName);
				Log.e("removeDLNADevice deviceList "+ i + ":deviceIP " + deviceList[i].deviceIP);
				Log.e("removeDLNADevice deviceList " + i+ ":id " + deviceList[i].deviceID);
				
				var removeDevice = self.searchDevice(deviceList[i].deviceID);

				if(removeDevice != null){
					self.dlnaDeviceCount--;
					self.remove(removeDevice);
					EventMediator.trigger(EventType.EVENT_TYPE_DEL_DEVICE, deviceList[i].deviceID,DeviceType.DEVICE_TYPE_DLNA);
				}	
			}
		},
		/** Pars DLNA device from json
		* @name getDLNADeviceList	 
		* @memberOf DeviceCollection
		* @param {json}  DLNA Device list JSon object
		* @method 	 
		* */
		getDLNADeviceList : function(json) {
			var dlnaList = null;
		//	print("DLNA device list ",json);
			if(json == null){
				return [];
			}
			dlnaList = JSON.parse(json);
			if(dlnaList != undefined){
				print("[getDLNADeviceList] get lenght:", dlnaList.devices.length);
				return dlnaList.devices;
			}
			else
			{
				return [];
			}
		},
		
		/** DLNA device handle 
		* @name onDLNAEvent	 
		* @memberOf DeviceCollection
		* @param {eventType}  DLNA device event type
		* @param {param1}  DLNA device list json
		* @method 	 
		* */
		onDLNAEvent :function(eventType, deviceInfo, param2){
			print('[onDLNAEvent]--parse start !!!  deviceInfo:',deviceInfo);
			print('[onDLNAEvent]--eventType', eventType);
			
			//print('[onDLNAEvent]--param1', param1);
			//print('[onDLNAEvent]--param2', param2);
			if(deviceInfo == null || deviceInfo == ''){
				print('[onDLNAEvent] deviceInfo = null');
				Log.e("[onDLNAEvent] deviceInfo = null");
				RunTimeInfo.firstGetDlna = false;
				return;
			}
			
			switch(eventType){
				case CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_CONNECTED:
					{
						var deviceList = self.getDLNADeviceList(deviceInfo);
						self.addDLNADevice(deviceList);
						break;
					}
					
					case CSFSefType.SEF_CSF_EVENT_DLNA_DEVICE_DISCONNECTED:
					{
						var deviceList = self.getDLNADeviceList(deviceInfo);
						self.removeDLNADevice(deviceList);
						break;
					}
				case CSFSefType.SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED:
					{
						print('[onDLNAEvent] Get dlna device list return : ',RunTimeInfo.firstGetDlna);
						var deviceList = self.getDLNADeviceList(deviceInfo);
						
						self.addDLNADevice(deviceList);
						RunTimeInfo.firstGetDlna = false;
					
						break;
					}
				
				default:
					break;
			}
			
		},	
		
		
		notifyInitFinish:function(){
			print("notifyInitFinish self.contentMgrInit:"+self.contentMgrInit);
			print("notifyInitFinish self.csfInit:"+self.csfInit);
			Log.e("notifyInitFinish ");
			
			if(self.contentMgrInit && self.csfInit){
				print('notifyInitFinish >>>>>>>>>>>>>>>>>>> ');
				EventMediator.trigger(EventType.EVENT_TYPE_CONTENT_MGR_INIT);
			}

		},
		onContentMgrInitCb:function(){
			Log.e("Device-collection.js onContentMgrInitCb performance");
			print("Device-collection.js onContentMgrInitCb performance");
			try{
				VoltApi.ContentsMgr.connect();		  
				self._getConnectedUsbDevice();	

				print("onContentMgrInitCb set contentMgrInit to true");
				self.contentMgrInit = true;
				
				self.notifyInitFinish();
			}catch(e){
				print("onContentMgrInitCb e:"+e);
			}
			Log.e("Device-collection.js onContentMgrInitCb finish performance");
		},
		
		onCsfInit:function(){
		/*
			if(launchParams.getLauncherAppName() == LaunchedByAppID.APP_ID_DMR || launchParams.getLauncherAppName() == LaunchedByAppID.APP_ID_SEARCH_ALL){
				Log.e('dmr or search, don\'t need registerDlnaCallback');
				return;
			}		
			*/
			Log.e("OnCsf Init finsh");
			print("OnCsf Init finsh");
		    var CsfMgr = Volt.require('app/models/csf-manager.js');

		    CsfMgr.registerDlnaCallback(self.onDLNAEvent);

			self.csfInit = true;
			self.notifyInitFinish();

			CsfMgr.getDLNAList();
			RunTimeInfo.firstGetDlna = true;
		},
		
		onUpdateDeviceList:function(){
			self._getConnectedUsbDevice();	
		//	CsfMgr.getDLNAList();
		},
		/**  Device collection initialize
		* @name initialize	 
		* @memberOf DeviceCollection
		* @method 	 
		* */
		initialize : function() {
			print('device-collection.js initialize begin~~~');
			self = this;
			var result;
			result = VoltApi.ContentsMgr.initAsync(self.onContentMgrInitCb,self.onUsbDeviceConnect, self.onUsbDeviceDisconnect);

			print("device-collection.js initialize Usb result:", result);	
			Log.e("device-collection.js initialize Usb result:");	
    
		   
			EventMediator.on(EventType.EVENT_TYPE_CSF_INIT, self.onCsfInit, this);
			EventMediator.on(EventType.EVENT_TYPE_UPDATE_DEVICE_LIST, self.onUpdateDeviceList, this);
			Log.e("device collection Init csf ");
			print("device collection Init csf ");
			var CsfMgr = Volt.require('app/models/csf-manager.js');
			
			EventMediator.on(EventType.EVENT_TYPE_UPDATE_DEVICE_AVAILABLE_SIZE, self.onUpdateDeviceSize, this);
			
		  	print('device-collection.js initialize end~~~');
		},
		
		onUpdateDeviceSize:function(){
			print("device collection onUpdateDeviceSize ");
			Log.e("device collection onUpdateDeviceSize ");
			self._getConnectedUsbDevice();
		},
		/**  Device collection destory
		* @name destory	 
		* @memberOf DeviceCollection
		* @method 	 
		* */
		destroy : function(){
			print("[device-collection.js] Destroy device collection");
			VoltApi.ContentsMgr.disconnect();
	
		},
	});
	
exports = DeviceCollection;
