 /** 
 * @author  Chen Xuemei (xnicole.chen@samsung.com)
 * 			
 * @fileoverview  Base collection class
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var Backbone = Volt.require('modules/backbone.js');
	var BaseModel = Volt.require("app/models/base-model.js");
	var PhotoModel = Volt.require("app/models/photo-model.js");
	var VideoModel = Volt.require("app/models/video-model.js");
	var MusicModel = Volt.require("app/models/music-model.js");
	var PvrModel = Volt.require("app/models/pvr-model.js")
	var voltapi = Volt.require('voltapi.js');
	var ViewGlobalData = Volt.require("app/views/view-global-data.js");


	var CommonInfo = Volt.require("app/common/define.js");
	var RunTimeInfo = Volt.require("app/common/run-time-info.js");
	var resMgr = Volt.require('app/controller/resource-controller.js');
	var EItemType = CommonInfo.EItemType;
	var EViewType = CommonInfo.EViewType;
	var MediaType = CommonInfo.MediaType;
	var PageStyle = CommonInfo.PageStyle;
	var CSFSefType = CommonInfo.CSFSefType;
	var EventType = CommonInfo.EventType;
	var EventMediator = RunTimeInfo.EventMediator;
	var CSFSourceType = CommonInfo.CSFSourceType;
	var csfReturnCode = CommonInfo.csfReturnCode;

	//var THUMB_BASE_PATH = '/usr/apps/mycontents/thumb/';
	var RATING_LOCK_KEY = 'db/menu/broadcasting/program-rating-lock-dvb';
	var THUMB_BASE_PATH = resMgr.getThumbPath();
	var self  = null;
	var THUMB_ARRAY_COUNT = 5;
	

	var ContentBaseCollection = Backbone.Collection.extend({
	
		model : BaseModel,
		agent : '',
		delAgent: '',
		row:	3,
		col:	9,
		sorttype: 'CATEGORY_NONE',
		sourceType: '',
		groupIndex: -1,
		csfApi : null,
		itemCount: 0,
		rootGroupFlag: true,
		addUpperFolderItemFlag : false,
		contentData: false,
		ratingLock: 255,
		

		/** Initialize ContentBaseCollection  	 
		* @name initialize	 
		* @memberOf ContentBaseCollection
		* @method 	 
		* */	
		initialize : function(){	
			print("content-base-collection.js initialize");
			self = this;
			//open csf sef
			self.csfApi = Volt.require('app/models/csf-manager.js'); //new CsfApi();
			self.csfApi.registerContentListCallback(self.parse);
			self.csfApi.registerThumbnailCallback(self.updateThumbnail);
			self.csfApi.registerCsfSendDataCallback(self.updateCsfSendData);
			
			print("content-base-collection.js initialize csfApi.name: " + self.csfApi.name);

		},
		
		updateContentViewThumbnailCb: function(){
			print("content base collection  updateContentViewThumbnailCb ");
			Log.e("content base collection  updateContentViewThumbnailCb ");
			self.csfApi.registerThumbnailCallback(self.updateThumbnail);

		},
		
		getRatingInfo: function(){
			var ratingInfo = self.csfApi.getRatingInfo();				
			
			if(ratingInfo == null || ratingInfo == undefined){
				Log.e(" ratingInfo is null ");
				print(" ratingInfo is null ");

				return;
			}
			var returnData = JSON.parse(ratingInfo);			
			print(' ratingInfo.return_data ---------------------- ',returnData.return_data);
			if(returnData.return_ecode !== 14 || returnData.return_data == undefined){
				Log.e(" returnData.return_ecode !== 14 || returnData.return_data ");
				print(" returnData.return_ecode !== 14 || returnData.return_data ");
				return;
			}
			var reting = JSON.parse(returnData.return_data);			
		
			print("reting.RATING_INFO:",reting.RATING_INFO);
			Log.e("reting.RATING_INFO:" + reting.RATING_INFO);
			
			print('reting.RATING_INFO.length :', reting.RATING_INFO.length);
			var retingLevelList = reting.RATING_INFO;
		
			if(retingLevelList != null){
				RunTimeInfo.uhdValidRateCount = 0;
				RunTimeInfo.uhdRateLevel = [];
				for(var i = 0; i < retingLevelList.length; i++){
					var ratinginfo = JSON.parse(retingLevelList[i]);
					
					print("ratinginfo.RATING_INFO_RATE:",ratinginfo.RATING_INFO_RATE);
					print("ratinginfo.RATING_INFO_CHILD_LOCK:",ratinginfo.RATING_INFO_CHILD_LOCK);
					
					RunTimeInfo.uhdRateLevel.push(ratinginfo);
					RunTimeInfo.uhdValidRateCount++;					
				}
			}
		},
		setGroupIndex : function(gIndex){
		
			self.groupIndex = gIndex;
		},

		setRootGroup : function(groupFlag){
		    return self.rootGroupFlag = groupFlag;
		},

		getRequestAgent : function(){
		    return self.agent;
		},

		getShareHandle : function(){
		    return self.delAgent;
		},

		/** Get Prepare Play Data 	 
		* @name getPreparePlayData	 
		* @memberOf ContentBaseCollection
		* @method 	 
		* */	
		getPreparePlayData : function(){
		    var param = {
						    "param_agent": self.agent,
						};
			var playData = self.csfApi.getPreparePlayData(param);
			print('playData.return_data'+playData.return_data);
			if(playData.return_ecode == '14'){
				return playData.return_data;
			}
			else{
                return '';
			}
		},
		
		getRatingLock : function(){
		   
		    var lockValue = Vconf.getValue(RATING_LOCK_KEY);
		    if(lockValue != undefined && typeof(lockValue) == 'number'){
		        self.ratingLock = lockValue;
		    }
		    Log.e('self.ratingLock: '+ self.ratingLock);
		},
		
		/** Request List 	 
		* @name requestList	 
		* @memberOf ContentBaseCollection
		* @param {options} content options
		* @method 	 
		* */	
		requestList : function(options){
			
			//if scan path is null or '' or undefined,  do not request data from csf, jus show no data
			print('content base collection [requestList] param_scan_path :',options.param_scan_path);
			Log.e("content base collection [requestList] param_scan_path :" + options.param_scan_path);
			if(options.param_scan_path == '' || options.param_scan_path == null || options.param_scan_path == undefined){
	   			print('Path is null,  display no data');	 	   			  			
	   			EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);	   	
	   			EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
				EventMediator.trigger(EventType.EVENT_TYPE_EDIT_MODE_BTN_FOCUS);
				//EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);	
	   		}
	   		else{ 
				//EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
				//EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);	
				self.sorttype = options.param_sort_category;
				self.sourceType = options.param_source_name;
				print('[ContentBaseCollection.js]request list : scanPath:',options.param_scan_path,'contentType: ', options.param_content_type,'sortType:', options.param_sort_category);
				self.contentData = true;
				self.csfApi.requestList(options);
			}
		},
		
		/** Request Thumbnail 	 
		* @name requestThumbnail	 
		* @memberOf ContentBaseCollection
		* @param {String} source type 
		* @param {int} item index
		* @param {int} image width
		* @param {int} image height
		* @method 	 
		* */	
		requestThumbnail: function(source, index, width, height){		
			print('Request Thumbnail-------------source:',source);
		
			print('[content-base-collection]requestThumbnail--------------index = ' + index);
			Log.e("[content-base-collection]requestThumbnail--------------index = " + index);

			if(index < 0 || index >= self.size()){
				print('[content-base-collection]requestThumbnail--------------index out of scope');
				Log.e("[content-base-collection]requestThumbnail--------------index out of scope");

				return ;
			}
		
			var savePath = self.getThumbnailSavePath(index);
			var savePaths = [savePath];	
			var filePath = self.getItem(index).get('filePath');
			if(self.getItem(index).get('ItemType') == EItemType.eItemVideo){
			    filePath = 	self.getItem(index).get('ptpThumbPath');		    
			}

			print('[content-base-collection]requestThumbnail--------------filePath = ' + filePath);
			Log.e("[content-base-collection]requestThumbnail--------------filePath = " + filePath);

			if(!filePath || filePath === ''){
				print('[content-base-collection]requestThumbnail ---------- filePath is empty');
				Log.e("[content-base-collection]requestThumbnail ---------- filePath is empty");

				return;
			}
			
			//csf thumbnail request
			var options = {
				param_origin_path: filePath,
				param_save_path: savePaths,
				param_media_type: 1,
				param_source_type: source,
				param_thumb_width: width,
				param_thumb_height: height, 
				param_orientation: 0,
				param_used_cache: 1,
				param_video_frame_count: 1,
				param_thumb_user_data: index,
			};

			//mediatype setting
			var itemType = self.getItem(index).get('ItemType');
			if(itemType == EItemType.eItemVideo){
				options.param_media_type  = MediaType.MEDIA_VIDEO;
				
			}
			else if(itemType == EItemType.eItemPhoto ){
				options.param_media_type = MediaType.MEDIA_PHOTO;
				options.param_orientation = parseInt(self.getItemValue(index,'ORIENTATION'));
				
			}
			else if(itemType == EItemType.eItemMusic){
				options.param_media_type = MediaType.MEDIA_MUSIC;
				
			}
			else if(itemType == EItemType.eItemPvr){
				options.param_media_type = MediaType.MEDIA_PVR;
			}
			else if(itemType == EItemType.eItemUHDVideo){
				options.param_media_type = MediaType.MEDIA_VIDEO;
			}else if(itemType == EItemType.eItemSCSA){
				options.param_media_type = MediaType.MEDIA_SCSA;
			}
			else{
				return;
			}

			if(source === CSFSourceType.CSF_EX_PTP_ID){
				options.param_origin_path = self.getItem(index).get('ptpThumbPath');
			}
					
			print('[content-base-collection]requestThumbnail ---------- begin request thumbnail');
			self.csfApi.requestThumbnail(options);
			
			print('Request Thumbnail end');			
		},

		/** Request Multi Thumbnail of Video
		* @name requestMultiThumbnail	 
		* @memberOf ContentBaseCollection
		* @param {String} source type 
		* @param {int} item index
		* @param {int} image width
		* @param {int} image height
		* @method 	 
		* */	
		requestMultiThumbnail : function(source, index, width, height){
			print('Request Multi Thumbnail ');
			var savePaths = self.getThumbnailSavePathArray(index);	
			var filePath = self.getItem(index).get('filePath');
						//csf thumbnail request
			var options = {
				param_origin_path: filePath,
				param_save_path: savePaths,
				param_media_type: MediaType.MEDIA_VIDEO,
				param_source_type: source,
				param_thumb_width: width,
				param_thumb_height: height, 
				param_orientation: 0,
				param_used_cache: 1,
				param_video_frame_count: THUMB_ARRAY_COUNT,
				param_thumb_user_data: index,
			};
			print('[content-base-collection]requestThumbnail ---------- begin request thumbnail');
			self.csfApi.requestThumbnail(options);
		},

		/** Update Csf Send Data
		* @name updateCsfSendData	 
		* @memberOf ContentBaseCollection
		* @param {enum} eventType, sendData,  shareHandler
		* @param {Object} sendData
		* @param {Object} shareHandler
		* @method 	 
		* */	
		updateCsfSendData: function(eventType, param1, param2){
			print('[content-base-collection.js] eventType = ',eventType);
			print('[content-base-collection.js] param1 = ',param1);
			print('[content-base-collection.js] param2 = ',param2);
			var sendData = JSON.parse(param1);
			var hadleData = JSON.parse(param2);
			self.delAgent = hadleData.param_share_handle;
			print('[content-base-collection.js] delAgent = ',self.delAgent);
			var total_file_count = sendData.param_share_total_file_count;
			var done_file_count = sendData.param_share_done_file_count;
			//EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_PROGRESS_BAR_INFO,eventType,total_file_count,done_file_count);
			EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_PROGRESS_BAR_INFO,eventType,sendData);
		},

		/** Update Thumbnail
		* @name updateThumbnail	 
		* @memberOf ContentBaseCollection
		* @param {enum} eventType, sendData,  shareHandler
		* @param {Object} sendData
		* @param {Object} shareHandler 
		* @method 	 
		* */	
		updateThumbnail: function(eventType, param1, param2){
			print("content base collection updateThumbnail eventType:"+eventType);
			print("content base collection updateThumbnail param1:"+param1);
			Log.e("content base collection updateThumbnail param1:"+param1);

			if(eventType == CSFSefType.CSF_EVENT_THUMBNAIL_FINISHED){
				print('success Get Thumbnail: ',param1);
				print("success Get Thumbnail: ");
				if(param1 === '' ){
					Log.e("updateThumbnail param1 === null ");
					print("updateThumbnail param1 === null ");
					return false;
				}

				var thumbItem = JSON.parse(param1);
				var savePath = thumbItem.save_path;
				var filePath = thumbItem.origin_path;
				var index = parseInt(thumbItem.user_data);
				print('save_path',savePath);
				Log.e("updateThumbnail save_path:" + savePath);

				if(index < 0 || index > self.length ){
					//find source item
					for(var idx = 0; idx < self.length ; idx++){
						if(self.getItem(idx).get('filePath') == filePath){
							index = idx;
							break;
						}				
					}
				}
				if(index < 0 || index > self.length ){
					return false;
				}
				var itemModel = self.getItem(index);
				print("updateThumbnail itemModel: "+itemModel);
				Log.e("updateThumbnail itemModel: "+itemModel);
				if(itemModel !== null){
					itemModel.set('isThumbDone',true);
					if(savePath != undefined){
						if(savePath.length > 1){
							itemModel.set('thumbPathArray',savePath);
						}
						else{
							Log.e("updateThumbnail change ThumbPath: "+savePath[0]+ " index:"+index);
							print("updateThumbnail change ThumbPath: "+savePath[0]+ " index:"+index);
							itemModel.set('ThumbPath',savePath[0]);
						}
						print('trigger thumbnail change');
						self.trigger('thumbnail', index , true);
					}
				}
			}
			else if(eventType == CSFSefType.CSF_EVENT_THUMBNAIL_FAIL){
				print("get thumnail fail");
				Log.e("get thumnail fail");
				if(param1 === '' ){
					Log.e("updateThumbnail fail param1 ===null");
					print("updateThumbnail fail param1 ===null");
					return false;
				}

				var thumbItem = JSON.parse(param1);
				var index = parseInt(thumbItem.user_data);
				if(index < 0 || index > self.length ){
					Log.e(" updateThumbnail fail index < 0  index > self.length ");
					print(" updateThumbnail fail index < 0  index > self.length ");
		
					return false;
				}
				self.trigger('thumbnail', index , false);

			}
		
			return true;
		},

		
		/** Get Tumbnail Save Path
		* @name getThumbnailSavePath	 
		* @memberOf ContentBaseCollection
		* @param {index} item index
		* @method 	 
		* */	
		getThumbnailSavePath : function(index){
          var savePath = '';
		  var ViewType = RunTimeInfo.router.getCurrentViewType();

		  switch(ViewType){
				case EViewType.eAllContentView:
					savePath =THUMB_BASE_PATH + 'All' + index+'.jpg';
					break;
					
			    case EViewType.eVideoContentView:
					savePath =THUMB_BASE_PATH + 'Video' + index+'.jpg';
					break;

				case EViewType.ePhotoContentView:
					savePath =THUMB_BASE_PATH + 'Photo' + index+'.jpg';
					break;
					
			    case EViewType.eMusicContentView:
					print('getThumbnailSavePath');
					savePath =THUMB_BASE_PATH + 'Music' + index+'.jpg';
					break;

				case EViewType.eRecordContentView:
					savePath =THUMB_BASE_PATH + 'Record' + index+'.jpg';
					break;

				default:
					savePath =THUMB_BASE_PATH + index + '.jpg';
					break;
		  	}				 
            return savePath;
		},

		/** Get Tumbnail Save Path Array for Video
		* @name getThumbnailSavePathArray	 
		* @memberOf ContentBaseCollection
		* @param {index} item index
		* @method 	 
		* */	
		getThumbnailSavePathArray : function(index){
			var savePaths = [];
			var ViewType = RunTimeInfo.router.getCurrentViewType();
			switch(ViewType){				
			    case EViewType.eVideoContentView:
			    	{
			    		for(var pic = 0; pic < THUMB_ARRAY_COUNT; pic++){
			    			savePaths[pic] = THUMB_BASE_PATH + 'Video' + index+ '_' + pic +'.jpg';	
			    		}
					}
					break;
				default:
					break;
		  	}				 
            return savePaths;
			
		},
		
		/** Add UpFolder Item
		* @name addUpFolderItem	 
		* @memberOf ContentBaseCollection
		* @method 	 
		* */	
		addUpFolderItem: function(){
			var itemModel = new BaseModel({
					dataFlag : 1,
					index  : -1,
					title1 : resMgr.getText('SID_UPPER_FOLDER'),
					filePath : '',
					ItemType : EItemType.eItemUpFolder,
				});

			self.unshift(itemModel);
			self.addUpperFolderItemFlag = true;
		},


		/** Add Empty Item
		* @name addEmptyItem	 
		* @memberOf ContentBaseCollection
		* @method 	 
		* */	
		addEmptyItem:function(){
			var emptyCount =0;
			if(self.itemCount < self.row * self.col){
				 emptyCount = self.row * self.col - self.itemCount;			
			}
			else if(self.itemCount % self.row != 0 ){
				emptyCount = self.itemCount % self.row;
			}
			for(var idx = 0 ; idx < emptyCount; idx++ ){
				var itemModel = new BaseModel;
				itemModel.dataFlag = 1,
				itemModel.ItemType = EItemType.eItemPhoto;
				itemModel.title1 = 'empty';
				itemModel.isThumbDone = true;
				self.add(itemModel);			
			}			
		},


		/** Parese Content Data
		* @name parse	 
		* @memberOf ContentBaseCollection
		* @param {enum} eventType, sendData,  shareHandler
		* @param {Object} sendData
		* @param {Object} shareHandler event type, data, agent
		* @method 	 
		* */	
		parse:function(eventType, param1, param2){
			print('content base collection parse start !!!, eventType', eventType);
			Log.e("content base collection parse start !!!, eventType:"+eventType);
			//if current view is connection guide or connection guide detail page, return.
			if(RunTimeInfo.router && 
				(RunTimeInfo.router.currentViewType == EViewType.eConnectPcGuideView 
				|| RunTimeInfo.router.currentViewType == EViewType.eConnectUsbGuideView
				|| RunTimeInfo.router.currentViewType == EViewType.eConnectMobileGuideView
				||RunTimeInfo.router.currentViewType == EViewType.eConnectionGuideView)){
				Log.e(" Current view is connection guide ");
				
				print(" Current view is connection guide ");
				return;

			}
			if( self.contentData == false){
				print("content base collection parse self.contentData == false");
				Log.e("content base collection parse self.contentData == false");
				return;
			}
			self.contentData = false;
			switch(eventType){
				case CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_SUCCESS:
				{
						EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
						self.getItems(param1, param2);						
				}
				break;
				case CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_FAIL:
				{
					//EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);	   	
	   				EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
					EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);
					EventMediator.trigger(EventType.EVENT_TYPE_EDIT_MODE_BTN_FOCUS);
					break;
				}
				case CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_EMPTY:
					{
						//EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);	
						EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
						EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);
						EventMediator.trigger(EventType.EVENT_TYPE_EDIT_MODE_BTN_FOCUS);
					}
					break;
				default:
					break;
			}		
		},

		
		/** Get Content Items
		* @name getItems	 
		* @memberOf ContentBaseCollection
		* @param {String} 
		* @param {Object} json Object
		* @method 	 
		* */	
		getItems:function(param1,param2){
			Log.e("getItems start");
			print("content base collection getItems start", JSON.stringify(param2));
			self.agent =  JSON.parse(param2).param_agent;
			ViewGlobalData.agent = self.agent;
			Log.e('--111[content-base-collection.js] agent = ' + ViewGlobalData.agent);
			print('--111[content-base-collection.js] agent = ',ViewGlobalData.agent);

			//set page style
			var pageStyle ={
				param_agent: self.agent,
				param_page_style: self.getPageStylebyCategory(self.sorttype),
				param_page_order: 1,
				param_group_index: self.groupIndex,
				param_row: 3,
				param_column: 9,
				param_need_padding: 0,
			};
			self.csfApi.setPageStyle(pageStyle);
		
			//getItemCount
			var totalCount = self.csfApi.getItemCount({
				param_agent : self.agent,			
			});
			self.itemCount = totalCount.return_data;
			Log.e('total item count:' + totalCount.return_data);
			
			self.getRatingLock();
			//performance test
			var startTime = new Date();
			print ("Get Value startTime: ", startTime.getTime());
			self.addUpperFolderItemFlag = false;
			for(var idx = 0;idx < totalCount.return_data; idx++){		
				var itemModel = new BaseModel({dataFlag : 0});
				self.add(itemModel);
			}
			print("getItems totalCount.return_data:",totalCount.return_data);
			
			self.getItemList(0,60);
			if( self.itemCount >= 90 ){
				self.getItemList(self.itemCount-30,self.itemCount);
			}

			//performance test
			var endTime = new Date();
			print ("Get Value End Time: ", endTime.getTime());
			
			self.trigger('adddata');
		//	EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
			EventMediator.trigger(EventType.EVENT_TYPE_EDIT_MODE_BTN_FOCUS);
			Log.e("getItems start finish");
			return true;
		},

		/** Get Content Item
		* @name getItem
		* @memberOf ContentBaseCollection
		* @param {idx} item index
		* @method 	 
		* */	
		getItem : function(idx){
			var itemModel = self.at(idx);
			if(!itemModel){
				return null;
			}
			
			if(itemModel.get('dataFlag') == 1){
				return itemModel;
			}
			
			/* convert from gridlist index to csf datasource index */
			if(self.addUpperFolderItemFlag){
				idx -= 1; 
			}
			
			var dataItem = self.csfApi.getItem({
				param_agent: self.agent,
				param_index: idx	
			});	
			
			if(dataItem == null || dataItem == undefined){
				print("dataItem == null || dataItem == undefined");
				Log.e("dataItem == null || dataItem == undefined");
			}else{
				
				print("dataItem.return_data"+dataItem.return_data);
				Log.e("dataItem.return_data"+dataItem.return_data);

			}	
			
			
	    		if(self.sourceType === 'csf_local_source_dlna'){
	    			itemModel = self.getDlnaItem(dataItem.return_data, idx);						
	    		}
	    		else if(self.sourceType === 'csf_ra_source'){
	    			itemModel = self.getRAItem(dataItem.return_data, index+id);
	    		}
	    		else{
	    			itemModel = self.getUsbItem(dataItem.return_data, idx);
	    		}	
    		
	    		return itemModel;
		},

		/** Get Usb Item
		* @name getUsbItem	 
		* @memberOf ContentBaseCollection
		* @param {Object} item data
		* @param {int} index
		* @method 	 
		* */	
		getUsbItem : function(jsonItem, idx){
			//print('[getUsbItem] jsonItem : ',jsonItem);
			try{
				var returnData = JSON.parse(jsonItem);
			}
			catch(e){
				print('JSON parase error');
				var itemModel = self.at(idx);
				if(!itemModel){
					itemModel = new BaseModel({
						dataFlag : 1,
						index : idx,
						title1 : title,
						filePath : strfilePath,
						ItemType : itemType,
						isWatched : bwatched,
						size : itemSize,
						ptpThumbPath : ptpThumbPath,
					});
				}
				return itemModel;
			}
			
			var title = (returnData.DISPLAY_NAME != undefined ) ? returnData.DISPLAY_NAME : 'notitle';
			var mediaType = (returnData.MEDIA_TYPE != undefined) ?(parseInt(returnData.MEDIA_TYPE)): -1 ;
			var strfilePath = (returnData.FILE_PATH != undefined) ? returnData.FILE_PATH : '' ;
			var bwatched = false;
			var itemSize = (returnData.SIZE != undefined) ? returnData.SIZE : '';
			var ptpThumbPath = (returnData.THUMBNAIL_PATH != undefined) ? returnData.THUMBNAIL_PATH : '';
			print("getUsbItem  ptpThumbPath:"+ ptpThumbPath);
			Log.e("getUsbItem  ptpThumbPath:"+ ptpThumbPath);
			
			var playAvail = (returnData.PLAYED_COUNT == '-1') ? false: true;
			var bDrm = (returnData.IS_DRM != undefined) ? returnData.IS_DRM : false;
			
			var itemType = self.getItemTypeFromMedia(mediaType);
			var isAudioOnly = false;
			var isLocked = false;
			var sportsType = 0;
			var isGuidance = false;
			var isRecording = false;
			var ciThumbType = -1;
			var recordingDate = '';
			var chanelName = '';
		
			if(itemType === EItemType.eItemPvr){
				if(	returnData.PROGRAM_TITLE != undefined ){
					title = returnData.PROGRAM_TITLE;
				}
				if( returnData.FILE_PATH != undefined ){
					strfilePath = returnData.FILE_PATH;
				}
				if(returnData.CONTENT_WATCH != undefined){
					bwatched = returnData.CONTENT_WATCH;
				}
				if(	returnData.HAS_AUDIO_ONLY != undefined){
					isAudioOnly = returnData.HAS_AUDIO_ONLY;
				}
				if(returnData.GUIDANCE != undefined && returnData.GUIDANCE !== ''){
					isGuidance = true;
				}
				if(returnData.SPORTS_TYPE != undefined){
					sportsType = returnData.SPORTS_TYPE;
				}
				var fileUrl = {str_uri : strfilePath};
				isRecording = self.csfApi.isPVRRecordingFile(fileUrl);
			 	ciThumbType = self.csfApi.isCIThumb(fileUrl);
				if(returnData.PARENTAL_RATING != undefined){
					var rating = returnData.PARENTAL_RATING;
					Log.e("rating:"+rating+", self.ratingLock:"+self.ratingLock);
					if(rating == 0){
						isLocked = false;
					}
					else if(rating == 255){
						isLocked = false;
					}
					else if(rating >= self.ratingLock){
					 	isLocked = true;
					}
					else{
					}
				}
				if(returnData.CONTENT_LOCK != undefined ){
					Log.e("CONTENT_LOCK:"+returnData.CONTENT_LOCK);
					if(returnData.CONTENT_LOCK == true){
						isLocked = true;
					}
				}

				if(returnData.CHANNEL_NAME != undefined){
					chanelName = returnData.CHANNEL_NAME;
				}
				if(returnData.START_TIME != undefined){
					recordingDate = self.getDateString(returnData.START_TIME);

				}
				if(returnData.IS_LOCAL_RECORD != undefined && returnData.IS_LOCAL_RECORD == false) {
					bDrm = true;
				}
				else{
					bDrm = false;
				}
				
			}
			else if(itemType === EItemType.eItemGroup){
				if(returnData.DISPLAY_NAME != undefined){
					title = returnData.DISPLAY_NAME;
				}else
				{
					title = '';
				}
				strfilePath = '';
			}
			else if(itemType === EItemType.eItemUHDVideo){
				var rating = returnData.RATING;
				Log.e("eItemUHDVideo returnData.RATING: "+returnData.RATING);
				if(title == null || title == undefined){
					title = returnData.DISPLAY_NAME;
				}
				var uhdContentId = '';
				
				if(returnData.CONTENTID != null){
					
					uhdContentId = returnData.CONTENTID;
				}	
				var uhdVideoGenre = '';
				print("UHD Video genre:"+returnData.GENRE);
				uhdVideoGenre = returnData.GENRE;
				//update rating info
				if(RunTimeInfo.uhdValidRateCount == 0){
					self.getRatingInfo();
				}
			}
			else if(itemType === EItemType.eItemSCSA){
				if(returnData.TITLE_19 != undefined){
					title = returnData.TITLE_19;
				}
				print("title "+ title);
			}
			/* convert from csf datasource index to gridlist index */
			if(self.addUpperFolderItemFlag){
				idx += 1;
			}
			
			var itemModel = self.at(idx);
			
			if(!itemModel){
				itemModel = new BaseModel({
					dataFlag : 1,
					index : idx,
					title1 : title,
					filePath : strfilePath,
					ItemType : itemType,
					isWatched : bwatched,
					size : itemSize,
					ptpThumbPath : ptpThumbPath,
					isAudioOnly : isAudioOnly,
					isGuidance: isGuidance,
					sportsType: sportsType,	
					isLocked: isLocked,
					isRecording: isRecording,
					ciThumbType: ciThumbType,
					isDrm: bDrm,
					date: recordingDate,
					chanelName: chanelName,
					
				});				
				Log.e("itemModel == null  add Item :" + idx);	
				print("itemModel == null  add Item :" + idx);	

			}
			else{
				itemModel.set('dataFlag', 1);
				itemModel.set('index', idx);
				itemModel.set('title1', title);
				itemModel.set('filePath', strfilePath);
				itemModel.set('ItemType', itemType);
				itemModel.set('isWatched', bwatched);
				itemModel.set('size', itemSize);
				print("getUsbItem change ThumbPath: "+ptpThumbPath + ' idx:'+idx);
				Log.e("getUsbItem change ThumbPath: "+ptpThumbPath+ " idx:"+idx);
				itemModel.set('ThumbPath', ptpThumbPath);
				itemModel.set('ptpThumbPath', ptpThumbPath);
				itemModel.set('isPlayAvailable',playAvail );
				itemModel.set('isAudioOnly', isAudioOnly);
				itemModel.set('rateLevel',rating);
				itemModel.set('isGuidance',isGuidance);
				itemModel.set('sportsType', sportsType);
				itemModel.set('isLocked',isLocked);
				itemModel.set('isRecording',isRecording);
				itemModel.set('uhdContentId',uhdContentId);
				itemModel.set('ciThumbType', ciThumbType);
				itemModel.set('isDrm', bDrm);
				itemModel.set('date', recordingDate);
				itemModel.set('chanelName', chanelName);
				itemModel.set('isThumbDone', false);
				itemModel.set('uhdVideoGenre', uhdVideoGenre);

				//debug code
				/*
				if(idx % 4 == 0){
					itemModel.set('rateLevel','G');
				} else if(idx % 4 == 1){
					itemModel.set('rateLevel','R');
				} else if(idx % 4 == 2){
					itemModel.set('rateLevel','PG');
				} else if(idx % 4 == 3){
					itemModel.set('rateLevel','PG-13');
				}
				*/
				Log.e("itemModel != null update Item :" + idx);
				print("itemModel != null update Item :" + idx);
			}
			
			return itemModel;
		},

		/** Get Dlna Item
		* @name getDlnaItem	 
		* @memberOf ContentBaseCollection
		* @param {Object} item data
		* @param {int} index
		* @method 	 
		* */	
		getDlnaItem : function(jsonItem, idx){
			//var returnData = JSON.parse(jsonItem);
			try{
				var returnData = JSON.parse(jsonItem);
			}
			catch(e){
				print('JSON parase error');
				var itemModel = self.at(idx);
				if(!itemModel){
					itemModel = new BaseModel({
						dataFlag : 1,
						index : idx,
						title1 : title,
						filePath : strfilePath,
						ItemType : itemType,
						isWatched : bwatched,
						size : itemSize,
						ptpThumbPath : ptpThumbPath,
					});
				}
				return itemModel;
			}
			var title = returnData.DISPLAY_NAME;
			var mediaType = parseInt(returnData.MEDIA_TYPE) ;
			var strfilePath =  returnData.THUMBNAIL_PATH;
			var itemSize = returnData.SIZE;
			var itemType = self.getItemTypeFromMedia(mediaType);
			var ptpThumbPath = (returnData.THUMBNAIL_PATH != undefined) ? returnData.THUMBNAIL_PATH : '';
			
			if(itemType === EItemType.eItemGroup){
				title = returnData.DISPLAY_NAME;
				strfilePath = '';
			}
			
			/* convert from csf datasource index to gridlist index */
			if(self.addUpperFolderItemFlag){
				idx += 1;
			}
			
			var itemModel = self.at(idx);
			
			if(!itemModel){
				itemModel = new BaseModel({
					dataFlag : 1,
					index : idx,
					title1 : title,
					filePath : strfilePath,
					ItemType : itemType,	
					size : itemSize,
				});
				
			}
			else{
				itemModel.set('dataFlag', 1);
				itemModel.set('index', idx);
				itemModel.set('title1', title);
				itemModel.set('filePath', strfilePath);
				itemModel.set('ptpThumbPath', ptpThumbPath);
				itemModel.set('ItemType', itemType);
				itemModel.set('size', itemSize);
			}
			return itemModel;				
		},

		/** Get RA Item
		* @name geRAItem	 
		* @memberOf ContentBaseCollection
		* @param {Object} item data
		* @param {int} index
		* @method 	 
		* */	
		getRAItem : function(jsonItem, idx){
			try{
				var returnData = JSON.parse(jsonItem);
			}
			catch(e){
				print('JSON parase error');
				var itemModel = self.at(idx);
				if(!itemModel){
					itemModel = new BaseModel({
						dataFlag : 1,
						index : idx,
						title1 : title,
						filePath : strfilePath,
						ItemType : itemType,
						isWatched : bwatched,
						size : itemSize,
						ptpThumbPath : ptpThumbPath,
					});
				}
				return itemModel;
			}
			var title = returnData.TITLE;
			var mediaType = parseInt(returnData.MEDIA_TYPE) ;
			var strfilePath =  returnData.THUMBNAIL_PATH;
			var itemSize = returnData.SIZE;
			var itemType = self.getItemTypeFromMedia(mediaType);
			
			/* convert from csf datasource index to gridlist index */
			if(self.addUpperFolderItemFlag){
				idx += 1;
			}
			
			var itemModel = self.at(idx);
			
			if(!itemModel){
				itemModel = new BaseModel({
					dataFlag : 1,
					index : idx,
					title1 : title,
					filePath : strfilePath,
					ItemType : itemType,	
					size : itemSize,
				});
				
			}
			else{
				itemModel.set('dataFlag', 1);
				itemModel.set('index', idx);
				itemModel.set('title1', title);
				itemModel.set('filePath', strfilePath);
				itemModel.set('ItemType', itemType);
				itemModel.set('size', itemSize);
			}
			return itemModel;				
		},


		/** Get Item Type from Media Type
		* @name getItemTypeFromMedia	 
		* @memberOf ContentBaseCollection
		* @param {mediaType} media type
		* @method 	 
		* */	
		getItemTypeFromMedia : function(mediaType){
			var itemType  = EItemType.eItemNone;
			switch(mediaType){
					//image
					case 0: 
						itemType = EItemType.eItemPhoto;
						break;
					//video
					case 1:
						itemType = EItemType.eItemVideo;
						break;
					//sound
					case 2:
						itemType = EItemType.eItemNone;
						break;
					//music
					case 3:
						itemType = EItemType.eItemMusic;
						break;
					//folder 
					case 4:
						itemType = EItemType.eItemFolder;
						break;
					//PVR
					case 5:
						itemType = EItemType.eItemPvr;
						break;		
					//playlist
					case 6:
						itemType = EItemType.eItemPlaylist;
						break;
					//audio
					case 7:
						itemType = EItemType.eItemNone;
						break;
					//group
					case 8:						
						itemType = EItemType.eItemGroup;					
						break;
					//UHD Video
					case 9:						
						itemType = EItemType.eItemUHDVideo;					
						break;
					//SCSA
					case 10:
						itemType = EItemType.eItemSCSA;
						break;
						
					default:
						itemType = EItemType.eItemNone;
						break;
			}
			return itemType;
		},		
	
		
		/** Get photo detail info
		* @name getPhotoDetail	 
		* @memberOf ContentBaseCollection
		* @param {index} index
		* @method 	 
		* */	
		getPhotoDetail: function(index){
			var dataIndex = self.addUpperFolderItemFlag ? (index-1) : index;
			var dataItem = self.csfApi.getItem({
					param_agent: self.agent,
					param_index: dataIndex,	
				});	

			print('[getPhotoDetail] Item : ',dataItem.return_data);
			var returnData = JSON.parse(dataItem.return_data);
			
			var pmodel = new PhotoModel;
			pmodel.set('title', returnData.TITLE);
			pmodel.set('displayName', returnData.DISPLAY_NAME);
			pmodel.set('creatTime', returnData.MODIFIED_TIME);
			if(self.sourceType === 'csf_local_source_dlna'){
				pmodel.set('creatTime', returnData.DATE_TAKEN);			
			}
			if(returnData.FORMAT != undefined){
				pmodel.set('format', returnData.FORMAT);
			}
			else{
				pmodel.set('format', returnData.MIME_TYPE);
			}
			pmodel.set('size', returnData.SIZE);
			pmodel.set('width', returnData.WIDTH);
			pmodel.set('height', returnData.HEIGHT);
			//pmodel.set('filepath',returnData.FILE_PATH);
			pmodel.set('location',self.getItemLocation(returnData.FILE_PATH, returnData.DISPLAY_NAME));
			return pmodel;
		},

		/** Get music detail info
		* @name getMusicDetail	 
		* @memberOf ContentBaseCollection
		* @param {index} index
		* @method 	 
		* */	
		getMusicDetail: function(index){
			var dataIndex = self.addUpperFolderItemFlag ? (index-1) : index;	
			var dataItem = self.csfApi.getItem({
				param_agent: self.agent,
				param_index: dataIndex,	
			});	

			print('[getMusicDetail] Item : ',dataItem.return_data);
			var returnData = JSON.parse(dataItem.return_data);
			
			var mmodel = new MusicModel;
			mmodel.set('title', returnData.TITLE);
			mmodel.set('displayName', returnData.DISPLAY_NAME);
			mmodel.set('duration', returnData.DURATION);
			mmodel.set('lastSaveDate', returnData.MODIFIED_TIME);
			if(self.sourceType === 'csf_local_source_dlna'){
				mmodel.set('lastSaveDate', returnData.DATE_TAKEN);			
			}
			mmodel.set('size', returnData.SIZE);
			//mmodel.set('filepath',returnData.FILE_PATH);
			mmodel.set('location',self.getItemLocation(returnData.FILE_PATH, returnData.DISPLAY_NAME));
			mmodel.set('genre', returnData.GENRE);
			mmodel.set('artist', returnData.ARTIST);
			mmodel.set('album', returnData.ALBUM);
			if(returnData.FORMAT != undefined){
                mmodel.set('format', returnData.FORMAT);
            }
            else{
                mmodel.set('format', returnData.MIME_TYPE);
            }
			return mmodel;
			
		},

		/** check whether should show a HD Audio icon
		* @name getHDAudioType	 
		* @memberOf ContentBaseCollection
		* @param {idx} index
		* @method 	 
		* */
		getHDAudioType: function(idx) {
			print('get in getHDAudioType');
			var dataIndex = self.addUpperFolderItemFlag ? (idx-1) : idx;
			var itemType = self.getItem(idx).get('ItemType');

			if( itemType != EItemType.eItemMusic){
				return false;
			}
			var returnValue = Vconf.getValue('db/sound/hd-audio');		//check Menu/Sound/Additional Settings/HD Audio at first
			var JsonData = null;
			print('Vconf.getValue(db/sound/hd-audio) return value: ' + returnValue);
			try{
				JsonData = JSON.parse(returnValue);		
			} catch (e) {
				print('**************-------------Vconf exception------------*********');
				return false;
			}
			if(JsonData !== undefined && JsonData !== null){
				print('JsonData = ',JsonData);
			}
			else{
				return false;
			}

			if( JsonData == '0' ){
				return false;
			}
			
			var sampleRate = this.getItemValue( idx, 'SAMPLERATE' );
			var bitRes = this.getItemValue( idx, 'BIT_RESOLUTION' );

			print('sampleRate for idx: ', idx , ' is ', sampleRate);
			print('bitRes for idx: ', idx , ' is ', bitRes);

			if( sampleRate==null || bitRes==null){
				return false;
			}

			if( sampleRate>48000 && bitRes>16 ){
				return true;
			}
			return false;			
		},
		/** Get UHD video detail info
		* @name getVideoDetail	 
		* @memberOf ContentBaseCollection
		* @param {index} index
		* @method 	 
		* */	
		getUHDVideoDetail: function(index){
			var dataIndex = self.addUpperFolderItemFlag ? (index-1) : index;	
			var dataItem = self.csfApi.getItem({
				param_agent: self.agent,
				param_index: dataIndex,	
			});	

			print('[getVideoDetail] Item : ',dataItem.return_data);
			var returnData = JSON.parse(dataItem.return_data);
			
			var resolution = ''+returnData.WIDTH + 'x' + returnData.HEIGHT;
			var vmodel = new VideoModel;
			vmodel.set('title', returnData.TITLE);
			vmodel.set('displayName', returnData.DISPLAY_NAME);
			vmodel.set('duration', returnData.DURATION);
			vmodel.set('genre',returnData.GENRE);
			vmodel.set('lastSaveDate', returnData.MODIFIED_TIME);
			if(self.sourceType === 'csf_local_source_dlna'){
				vmodel.set('lastSaveDate', returnData.DATE_TAKEN);			
			}
			if(returnData.FORMAT != undefined){
				vmodel.set('format', returnData.FORMAT);
			}
			else{
				vmodel.set('format', returnData.MIME_TYPE);
			}
			vmodel.set('size', returnData.SIZE);
			vmodel.set('resolution', '3840x2160');
			returnData.DISPLAY_NAME = returnData.DISPLAY_NAME+'.'+returnData.FORMAT;
			vmodel.set('location',self.getItemLocation(returnData.FILE_PATH, returnData.DISPLAY_NAME));
			return vmodel;
			
		},
		/** Get video detail info
		* @name getVideoDetail	 
		* @memberOf ContentBaseCollection
		* @param {index} index
		* @method 	 
		* */	
		getVideoDetail: function(index){
			var dataIndex = self.addUpperFolderItemFlag ? (index-1) : index;	
			var dataItem = self.csfApi.getItem({
				param_agent: self.agent,
				param_index: dataIndex,	
			});	

			print('[getVideoDetail] Item : ',dataItem.return_data);
			var returnData = JSON.parse(dataItem.return_data);
			
			var resolution = ''+returnData.WIDTH + 'x' + returnData.HEIGHT;
			var vmodel = new VideoModel;
			vmodel.set('title', returnData.TITLE);
			vmodel.set('displayName', returnData.DISPLAY_NAME);
			vmodel.set('duration', returnData.DURATION);
			vmodel.set('genre',returnData.GENRE);
			vmodel.set('lastSaveDate', returnData.MODIFIED_TIME);
			if(self.sourceType === 'csf_local_source_dlna'){
				vmodel.set('lastSaveDate', returnData.DATE_TAKEN);			
			}
			if(returnData.FORMAT != undefined){
				vmodel.set('format', returnData.FORMAT);
			}
			else{
				vmodel.set('format', returnData.MIME_TYPE);
			}
			vmodel.set('size', returnData.SIZE);
			vmodel.set('resolution', resolution);
			vmodel.set('location',self.getItemLocation(returnData.FILE_PATH, returnData.DISPLAY_NAME));
			return vmodel;
			
		},
		
		/** Get record detail info
		* @name getRecordDetail	 
		* @memberOf ContentBaseCollection
		* @param {index} index
		* @method 	 
		* */	
		getRecordDetail: function(index){
			var dataIndex = self.addUpperFolderItemFlag ? (index-1) : index;	
			var dataItem = self.csfApi.getItem({
				param_agent: self.agent,
				param_index: dataIndex,	
			});	

			print('[getRecordDetail] Item : ',dataItem.return_data);
			var returnData = JSON.parse(dataItem.return_data);	
			print(typeof(returnData.HD));
			var rmodel = new PvrModel;
			rmodel.set('title', returnData.PROGRAM_TITLE);
			rmodel.set('channel', returnData.CHANNEL_NAME);
			if(returnData.START_TIME != undefined){
				rmodel.set('date', returnData.START_TIME);

			}
			else{
				rmodel.set('date', returnData.PROGRAM_START_TIME);
			}
			
			rmodel.set('hd', returnData.HD);
			rmodel.set('size', returnData.SIZE);
			rmodel.set('location',self.getPvrItemLocation(returnData.FILE_PATH));
			rmodel.set('chanelType', returnData.CHANNEL_TYPE);
			rmodel.set('chanelNum', returnData.CHANNEL_NUM);
			rmodel.set('chanelName', returnData.CHANNEL_NAME);
			rmodel.set('synopsis', returnData.SYNOPSIS);
			rmodel.set('guidance', returnData.GUIDANCE);
			
			return rmodel;
			
		},
		/** Get item location
		* @name getItemLocation	 
		* @memberOf ContentBaseCollection
		* @param {filepath} filepath
		* @method 	 
		* */	
		getItemLocation: function(filePath, fileName){
			
			print('getItemLocation filePath:' + filePath + ' fileName:'+ fileName);
			
			var mainView = Volt.require('app/views/main-view.js');
			var DeviceProvider = Volt.require("app/models/device-provider.js");
			var devItem = DeviceProvider.getDeviceInfo(mainView.categoryView.currentID);
			if( devItem.get('displayName') != null ){
				if(filePath == null || devItem.get('mountPath') == null){
					filePath = devItem.get('displayName');
				}
				else if(filePath.search(devItem.get('mountPath'))>=0){	
					filePath = filePath.replace(devItem.get('mountPath'), devItem.get('displayName'));					
				}
				
				filePath = filePath.replace(fileName,''); 
				//print('[getItemLocation] filePath :',filePath);
				filePath = filePath.substring(0, filePath.length - 1); 
				
				print('[getItemLocation] filePath :',filePath);
			
			}else{
				print("getItemLocation displayName is null");
				Log.e("getItemLocation displayName is null");
			}
			
			return filePath;
		},
		getPvrItemLocation: function(filePath){
			var strPath = [];
			strPath = filePath.split('/');
			var strName = strPath[strPath.length -1];
			return self.getItemLocation(filePath, strName);
		
		},
		

		/** Get Item Value
		* @name getItemValue	 
		* @memberOf ContentBaseCollection
		* @param {int} item index
		* @param {enum} field
		* @method 	 
		* */	
		getItemValue: function(index, field){

			if(self.addUpperFolderItemFlag){
				index--;
			}
			print("getItemValue self.agent:"+self.agent);
			
			var ret = self.csfApi.getItemValue({
				param_agent : self.agent,
				param_index : index,
				param_field : field,
			})
			print("getItemValue ret:"+JSON.stringify(ret))
			return ret.return_data;
			
		},

		/** Set Item Value
		* @name setItemValue	 
		* @memberOf ContentBaseCollection
		* @param {int} item index
		* @param {enum} field
		* @param {String} value
		* @method 	 
		* */		
		setItemValue: function(index, field, value){
			if(self.addUpperFolderItemFlag){
				index--;
			}
			self.csfApi.setItemValue({
				param_agent : self.agent,
				param_index : index,
				param_field : field,
				param_value : value,
			})
		},

		/** Cancel All Thumbnail Request
		* @name cancelAllThumbnailRequest	 
		* @memberOf ContentBaseCollection
		* @method 	 
		* */	
		cancelAllThumbnailRequest : function(){
			self.csfApi.cancelAllThumbnailRequest();
		},

		/** Cancel Ptp Thumbnail Request
		* @name cancelPtpThumbnailRequest	 
		* @memberOf ContentBaseCollection
		* @method 	 
		* */	
		cancelPtpThumbnailRequest : function(){
			self.csfApi.cancelPtpThumbnailRequest();
		},

		/* performance test  get value*/
		test1: function(index){

			self.csfApi.moveToIndex({
					param_agent : self.agent,
					param_index : index
			});
			var title1 = self.csfApi.getItemValueChar({
					param_agent: self.agent,
					param_field: 'TITLE'
			}).return_data;
			var size = self.csfApi.getItemValueChar({
				param_agent: self.agent,
				param_field: 'FILE_PATH'
			}).return_data;
		},

		/* performance test  get Item*/
		test2: function(index){
			var dataItem = self.csfApi.getItem({
				param_agent: self.agent,
				param_index: index	
			});
			print(dataItem.return_data);
		},

		/** Get Page Style By Category
		* @name getPageStylebyCategory	 
		* @memberOf ContentBaseCollection
		* @param {sortType} category type
		* @method 	 
		* */	
		getPageStylebyCategory: function(sortType){
		
			var pageStyle = 0x0;

			print('sortType-----'+sortType);

			switch(sortType){
				case 'CATEGORY-TITLE': 
				case 'CATEGORY-TRACK':
				case 'CATEGORY-DATE':
					pageStyle = 0x4;
					break;		
				case 'CATEGORY-ARTIST':
				case 'CATEGORY-ALBUM':
				case 'CATEGORY-GENRE':
				case 'CATEGORY-CHANNEL_NAME':
					{  
						print('self.rootGroupFlag:'+self.rootGroupFlag);
						if(self.rootGroupFlag){
							pageStyle = 0x8;		
						}
						else{
							pageStyle = 0x4;
						}
					}
					break;
				case 'CATEGORY-FOLDER':
					{
						pageStyle = 0x2 | 0x4;
	
					}				
					break;
				default: 
					break;	
					
			}

			return pageStyle;
		
		},
	
		getPageIndex: function(filePath){

			var JsonIdx = self.csfApi.getPageIndex({
				param_agent: self.agent,
				param_media: '' + filePath,
			});		
			var lastPlayIndex = parseInt(JsonIdx.return_data);
			if(self.addUpperFolderItemFlag){
				return lastPlayIndex+1;
			}
			else{
				return lastPlayIndex;
			}
		},

		getItemList: function(index,count){
			Log.e("getItemList begin ");
			var startTime = new Date();
			print("[getItemList]Get Value startTime: ", startTime.getTime());
			var JsonItems = self.csfApi.getItemList({
				param_agent: self.agent,
				param_index: index,
				param_count: count,
			
			});
			
			var parseTime = new Date();
			print("[getItemList]Get Value startTime: ", parseTime.getTime());
			if(JsonItems.return_ecode == csfReturnCode.CSF_OK && JsonItems.return_data != undefined ){
				var itemData = JSON.parse(JsonItems.return_data);
				var itemList = itemData.param_item_list;
				var itemCount = itemData.param_count;
				for(var id = 0; id < itemCount; id++){
					Log.e('id : ' +id + 'itemList[id]' + itemList[id]);
					print('id : ' +id + 'itemList[id]' + itemList[id]);
					var itemModel = null;
					if(self.sourceType === 'csf_local_source_dlna'){					
						self.getDlnaItem(itemList[id], index+id);						
					}
					else if(self.sourceType === 'csf_ra_source'){
						self.getRAItem(itemList[id], index+id);
					}
					else{
						self.getUsbItem(itemList[id], index+id);
					}	
				}
			}
			var endTime = new Date();
			print("[getItemList]Get Value endTime: ", endTime.getTime());
			Log.e("getItemList finish ");
		},
		
		getDateString: function (date) {
			print('[content-information-box.js] getDateString():'+ date);
			if(date == null){
				return '';
			}
			var newDate = new Date(date*1000);

			var option = {
		        weekday : 'long',
		        month : 'long',
		        day : 'numeric',
				}
			var locale = self.getLocalValue();
			return newDate.toLocaleDateString(locale,option).replace('(','').replace(')','');

		},

		getLocalValue:  function(){
			var DeviceModel = Volt.require("app/models/device-model-kpi.js"); 
	        var countrycode = Vconf.getValue('db/comss/countrycode');
	        print(' [content-base-collection.js]----countrycode  = ' + countrycode);
	        if(countrycode == 'undefined' || countrycode =='' || countrycode == null || countrycode == undefined){
	        	countrycode = 'US';
	        }
        	return countrycode;
		},
		
	});

	exports = ContentBaseCollection;
