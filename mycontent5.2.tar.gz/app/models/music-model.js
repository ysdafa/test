 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Manage music item data
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');
var BaseModel = Volt.require("app/models/base-model.js");
	
var MusicModel = BaseModel.extend({

	defaults: {
		filename: 'null',
		filetitle: 'null',
		url:'',
		artist:'NoSinger',
		album:'null',
		genre:'null',
		filesize:'null',
		playavail:'true',
	},

	parse: function(musicItem){

		var oMusicFile = {
			filename : musicItem.filename,
			filetitle : musicItem.filetitle,
			url : musicItem.url,
			artist : musicItem.artist,
			album : musicItem.album,
			genre : musicItem.genre,
			filesize : musicItem.filesize,
			playavail : musicItem.playavail,
		};

		return oMusicFile;
	},

})

exports = MusicModel;
