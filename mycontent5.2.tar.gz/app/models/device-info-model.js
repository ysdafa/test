 /** 
 * @author dohyoung Kim (dohyoung7.kim@samsung.com)
 * @fileoverview This module get device information form WAS.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js');
    //EventMediator = Volt.require('app/common/eventMediator.js'),
    //CommonDefines = Volt.require('app/common/commonDefines.js'),
// var   voltapi = require('voltapi');
var voltapi = Volt.require('voltapi.js');

var self;

/**
 * @name DeviceInfoModel
 */
var DeviceInfoModel = Backbone.Model.extend({
    /** @lends DeviceInfoModel.prototype */
    defaults: {
        
        // START WAS "GetDebugInfo"
        appsDbStatus: '',
        categoryType: '',
        chipInfo: '',
        country: '',
        duid: '',
        firmwareVersion: '',
        hubsiteStatus: '',        
        lineupModel: '',
        localSet: '',
        localTime: '',
        macAddr: '',
        managerStatus: '',
        modelId: '',
        networksStatus: '',
        productType: '',
        sefVersion: '',
        serverType: '',
        syncStatus: '',
        wpBaseline: '',
        countryCode: '',
        language: '',
        resolution: '',
        audioDescription: '',
        highContrast: '',
        tts: '',
        visibleCursor: '',
        // END WAS "GetDebugInfo"
    },

    /**
     * Initialize DeviceInfoModel
     * @name DeviceInfoModel
     * @constructs
     */
    initialize: function() {
        self = this;
        //this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, this.onWASInitialized);
        //this.listenTo(EventMediator, CommonDefines.Event.CONNECT_NETWORK, this.onConnectNetwork);
        //this.listenTo(EventMediator, CommonDefines.Event.DISCONNECT_NETWORK, this.onDisConnectNetwork);
    },

    /**
     * Initialize when WAS is ready.
     * @method
     */
    /*onWASInitialized: function() {
        this.updateInfoFromWAS();
        EventMediator.trigger(CommonDefines.Event.DEVICE_INFO_READY);
    },*/

    /**
     * Connect network.
     * @method
     */
    /*onConnectNetwork: function() {
        Volt.log("[deviceInfoModel.js] onConnectNetwork()");
        this.set('networksStatus', 'OK');
        EventMediator.trigger(CommonDefines.Event.CHANGE_NETWORK_STATUS, {
            "networksStatus": "OK"
        });
    },*/

    /**
     * Disconnect network.
     * @method
     */
    /*onDisConnectNetwork: function() {
        Volt.log("[deviceInfoModel.js] onDisConnectNetwork()");
        this.set('networksStatus', 'NG');
        EventMediator.trigger(CommonDefines.Event.CHANGE_NETWORK_STATUS, {
            "networksStatus": "NG"
        });
    },*/

    /**
     * Update the device info from WAS.
     * @method
     */
    /*updateInfoFromWAS: function() {

        var oDebugInfo = voltapi.WAS.getDebugInfo();

        if(oDebugInfo === -1) {
            Volt.log("[deviceInfoModel.js] getDebugInfo() ret : " + oDebugInfo);
            
            oDebugInfo = {};

            oDebugInfo.firmware_version = voltapi.WAS.getInfolinkVer();
            oDebugInfo.model_id = voltapi.vconf.getValue(CommonDefines.Vconf.DB_COMSS_MODELID);
            oDebugInfo.duid = voltapi.vconf.getValue(CommonDefines.Vconf.DB_COMSS_DUID);
            oDebugInfo.networks_status = 'NG';
        }

        oDebugInfo.country_code = voltapi.vconf.getValue(CommonDefines.Vconf.DB_COMSS_COUNTRYCODE);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_COMSS_COUNTRYCODE, self.onChangeCountryCode);
        oDebugInfo.language = self.getLanguageCode();
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_MENU_LANGUAGE, self.onChangeLanguage);
        oDebugInfo.resolution = String(scene.height);

        // Accessibility
        oDebugInfo.audioDescription = voltapi.vconf.getValue(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_AUDIO_DESCRIPTION);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_AUDIO_DESCRIPTION, this.onChangeAudioDescription);
        oDebugInfo.highContrast = voltapi.vconf.getValue(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_SYSTEM_ACCESSIBILITY_HIGHCONTRAST, this.onChangeHighContrast);
        oDebugInfo.tts = voltapi.vconf.getValue(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.DB_MENU_ACCESSIBILITY_TTS, this.onChangeTTS);
        oDebugInfo.visibleCursor = voltapi.vconf.getValue(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE);
        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE, this.onChangeVisibleCursor);

        this.set('appsDbStatus', oDebugInfo.apps_db_status || '');
        this.set('categoryType', oDebugInfo.category_type || '');
        this.set('chipInfo', oDebugInfo.chip_info || '');
        this.set('country', oDebugInfo.country || 'US');
        this.set('duid', oDebugInfo.duid || '');
        this.set('firmwareVersion', oDebugInfo.firmware_version || 'T-INFOLINK2014-1002');
        this.set('hubsiteStatus', oDebugInfo.hubsite_status || '');
        this.set('lineupModel', oDebugInfo.lineup_model || '');
        this.set('localSet', oDebugInfo.local_set || '');        
        this.set('localTime', oDebugInfo.local_time || '');
        this.set('macAddr', oDebugInfo.mac_addr || '');
        this.set('managerStatus', oDebugInfo.manager_status || '');
        this.set('modelId', oDebugInfo.model_id || '14_GOLFP_TIZEN');
        this.set('networksStatus', oDebugInfo.networks_status || this.get('networksStatus'));
        this.set('productType', oDebugInfo.product_type || '');
        this.set('sefVersion', oDebugInfo.sef_version || '');
        this.set('serverType', oDebugInfo.server_type || '');
        this.set('syncStatus', oDebugInfo.sync_status || '');
        this.set('wpBaseline', oDebugInfo.wp_baseline || '');
        this.set('countryCode', oDebugInfo.country_code || '');
        this.set('language', oDebugInfo.language || 'en');
        this.set('resolution', oDebugInfo.resolution || '1080');
        this.set('audioDescription', oDebugInfo.audioDescription || '');
        this.set('highContrast', oDebugInfo.highContrast || '');
        this.set('tts', oDebugInfo.tts || '');
        this.set('visibleCursor', oDebugInfo.visibleCursor || '');

        Volt.log("[deviceInfoModel.js] updateInfoFromWAS() deviceInfo : " + JSON.stringify(oDebugInfo));
    },*/

    /**
     * onChangeCountryCode Callback.
     * @method
     */
    /*onChangeCountryCode: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeCountryCode() : " + value);
        self.set('countryCode', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_COUNTRY_CODE);
    },*/

    /**
     * onChangeLanguage Callback.
     * @method
     */
    /*onChangeLanguage: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeLanguage() : " + value);
        self.set('language', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_LANGUAGE);
    },*/

    /**
     * onChangeAudioDescription Callback.
     * @method
     */
    /*onChangeAudioDescription: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeAudioDescription() : " + value);
        self.set('audioDescription', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_AUDIO_DESCRIPTION);
    },*/

    /**
     * onChangeHighContrast Callback.
     * @method
     */
    /*onChangeHighContrast: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeHighContrast() : " + value);
        self.set('highContrast', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_HIGH_CONTRAST);
    },*/

    /**
     * onChangeTTS Callback.
     * @method
     */
    /*onChangeTTS: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeTTS() : " + value);
        self.set('tts', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_TTS);
    },

    onChangeVisibleCursor: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeVisibleCursor() : " + value);
        self.set('visibleCursor', value || '');
        EventMediator.trigger(CommonDefines.Event.CHANGE_VISIBLE_CURSOR, value);
    },*/

    getLanguageCode: function(){
        Volt.log("[deviceInfoModel.js] getLanguageCode()");
        var languageCode = '';

        var preDefine = {
            'fr_CA' : 'fr-US',
            'es_MX' : 'es-US',
            'pt_BR' : 'pt-US',
            'en_GB' : 'en-GB',
            'zh_CN' : 'zh-CN',
            'zh_HK' : 'zh-HK',
            'zh_TW' : 'zh-TW',
	    'nn_NO' : 'no'
        }

        var vconfMenuLang = voltapi.vconf.getValue('db/menu_widget/language');
        var lang = vconfMenuLang.split('.')[0];
		Volt.log("[deviceInfoModel.js] getLanguageCode(), Lang: "+vconfMenuLang);
        Log.f("[deviceInfoModel.js] getLanguageCode(), Lang: "+vconfMenuLang);
        
        if(preDefine[lang]){
            languageCode = preDefine[lang];
        }else{
            languageCode = lang.split('_')[0];
        }
        
       return languageCode;
       
    }
});

exports = new DeviceInfoModel();