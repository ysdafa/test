 /** 
 * @author  Hu Po (pual.hu@samsung.com)
 * 			
 * @fileoverview  Manager the music player index change
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var PlayerIndexMgr = function() {
	
	this.nCurIndex = -1,
	this.nPreIndex = -1,
	this.nTotalCount = -1,
	this.nTotalPlayableCount = -1,
	
	this.playListLog = [],
	
	this.getRepeat = null,
	this.getShuffle = null,
	
	this.enumState = 
    {
		MP_ITEM_UNPLAYED : 0,
		MP_ITEM_PLAYED : 1,		
		MP_ITEM_FAILED_TO_PLAY : 2,
		MP_ITEM_MAX : 3,
    };

	/**init the play index manager 	 
	* @name create	 
	* @memberOf PlayerIndexMgr	 
	* @param {opt} create parameter		
	* @method 	 */		
    this.create = function(opt) {
    	this.nCurIndex = opt.curIdx;
		this.nPreIndex = this.nCurIndex;
    	this.nTotalCount = opt.totalCount;
    	this.nTotalPlayableCount = this.nTotalCount;
    	this.getRepeat = opt.repeatCB;
    	this.getShuffle = opt.shuffleCB;
    	
		for( var i =0; i < this.nTotalCount;i ++ )
		{
			this.playListLog.push(this.enumState.MP_ITEM_UNPLAYED);
		}
//		this.playListLog[this.nCurIndex] = this.enumState.MP_ITEM_PLAYED;
    };

	this.setCurrentIndex = function( idx ) {
		this.nCurIndex = idx;
		this.playListLog[this.nCurIndex] = this.enumState.MP_ITEM_PLAYED;
	};

	/**get the current focus index  	 
	* @name getCurrentIndex	 
	* @memberOf PlayerIndexMgr	 
	* @method 	 */		
    this.getCurrentIndex = function() {
    	return this.nCurIndex;
    };

	this.getPreIndex = function() {
		return this.nPreIndex;
	};

	/**get the playable item count  	 
	* @name getPlayAbleCount	 
	* @memberOf PlayerIndexMgr	 
	* @method 	 */	
	this.getPlayAbleCount = function() {
		return this.nTotalPlayableCount;
	};

	/**move current indx 	 
	* @name moveToIndex	 
	* @memberOf PlayerIndexMgr	 
	* @param {idx} move current index to idx		
	* @method 	 */			
    this.moveToIndex = function(idx) {
    	this.nPreIndex = this.nCurIndex;
    	this.nCurIndex = idx;
    	print("set current index = ", this.nCurIndex);
    	return true;
    };

	/**move to next one	 
	* @name moveNext	 
	* @memberOf PlayerIndexMgr	 
	* @param {ignoreRepeat} ignore the repeat mode setting or not		
	* @method 	 */		
    this.moveNext = function(ignoreRepeat) {
		if( this.nCurIndex < 0 || this.nTotalCount <= 0)
		{
			return false;
		}
		
		var options = this._GetCurrentPlayOption();
		
		if( options.sRepeat=="one" && ignoreRepeat == false ){
			print("repeat one mode");
			return true;
		}
		
		if( options.bShuffle == "true" ){
			if(this.playListLog[this.nCurIndex] == this.enumState.MP_ITEM_UNPLAYED)
			{
				this.playListLog[this.nCurIndex] = this.enumState.MP_ITEM_PLAYED;
			}
			return this._MoveShuffle( options.sRepeat, ignoreRepeat );
		}
		
		var nNextIndex = this.nCurIndex;
		var exist = false;
		
		while (!exist)
		{
			if ( nNextIndex >= this.nTotalCount -1 )
			{
				if(options.sRepeat == "all" || options.sRepeat == "one" || ignoreRepeat == true )	
				{
					nNextIndex = -1;
				}
				else
				{
					return false;
				}
			}
			nNextIndex ++;
	
			if (this.playListLog[nNextIndex] != this.enumState.MP_ITEM_FAILED_TO_PLAY )
			{
				exist = true;
			}
			else 
			{
				if (nNextIndex == this.nCurIndex)
				{
					return false;
				}
			}
		}
		this.nPreIndex = this.nCurIndex;
		this.nCurIndex = nNextIndex;
		this.playListLog[this.nCurIndex] = this.enumState.MP_ITEM_PLAYED;
		
		return true;
    };

	/**move to pre one	 
	* @name movePre	 
	* @memberOf PlayerIndexMgr	 
	* @param {ignoreRepeat} ignore the repeat mode setting or not		
	* @method 	 */		
    this.movePre = function(ignoreRepeat) {
		if( this.nCurIndex < 0 || this.nTotalCount <= 0)
		{
			return false;
		}
		
		var options = this._GetCurrentPlayOption();
		if( options.sRepeat=="one" && ignoreRepeat == false ){
			print("repeat one mode");
			return true;
		}	
		
		if( options.bShuffle == "true" ){
			return this._MoveShuffle( options.sRepeat, ignoreRepeat );
		}
		
		var nPrevIndex = this.nCurIndex;
		var exist = false;
		
		while(!exist)
		{
			if( nPrevIndex == 0 )
			{
				if(options.sRepeat == "all" || options.sRepeat == "one" || ignoreRepeat == true )	
				{
					nPrevIndex = this.nTotalCount;
				}
				else
				{
					return false;
				}
			}
	
			nPrevIndex --;
	
			if(this.playListLog[nPrevIndex] != this.enumState.MP_ITEM_FAILED_TO_PLAY )
			{
				exist = true;
			}
			else 
			{
				if(nPrevIndex == this.nCurIndex)
				{
					return false;
				}
			}
		}
		this.nPreIndex = this.nCurIndex;
		this.nCurIndex = nPrevIndex;
		this.playListLog[this.nCurIndex] = this.enumState.MP_ITEM_PLAYED;	
		
		return true;				
    };

	/**move the index under shuffle mode	 
	* @name _MoveShuffle	 
	* @memberOf PlayerIndexMgr	 
	* @param {sRepeat} repeat mode		
	* @method 	 */		
    this._MoveShuffle = function( sRepeat, ignoreRepeat ) {
		var nCountPlayed = 0;
		var nCountUnPlayed = 0;
		var nCountFailed = 0;
		
		for( var i=0; i < this.nTotalCount; i++)
		{
			if( this.playListLog[i] == this.enumState.MP_ITEM_UNPLAYED)
			{
				nCountUnPlayed++;
			}
			else if( this.playListLog[i] == this.enumState.MP_ITEM_PLAYED)
			{
				nCountPlayed++;
			}
			else if( this.playListLog[i] == this.enumState.MP_ITEM_FAILED_TO_PLAY)
			{
				nCountFailed++;
			}
		} 
		
		if( nCountUnPlayed ==0 && nCountFailed == this.nTotalCount)
		{
			return false;
		}
	
		if( nCountUnPlayed ==0 && nCountPlayed > 0 )
		{
			if( sRepeat == "all" || sRepeat == "one" || ignoreRepeat == true)
			{
				this.resetManager();
				nCountUnPlayed = nCountPlayed;
				nCountPlayed = 0;
			}
			else if( ignoreRepeat==false ){
				return false;
			}
		}
		
		var nRandNum = 0;
		if(nCountUnPlayed > 0)
		{
			nRandNum = Math.floor(Math.random() * ( nCountUnPlayed));
		}
		
		var nIndex = 0;
		for(nIndex=0;nIndex<this.nTotalCount;nIndex++)
		{
			if(this.playListLog[nIndex] == this.enumState.MP_ITEM_UNPLAYED)
			{
				if(nRandNum==0)
				{
					break;
				}
				else
				{
					nRandNum--;
				}
			}
		}
		this.nPreIndex = this.nCurIndex;
		this.nCurIndex = nIndex;
		this.playListLog[this.nCurIndex] = this.enumState.MP_ITEM_PLAYED;
		return true;
    };

	/**set Current Item None Playable
	* @name setCurrentItemNonePlayable	 
	* @memberOf PlayerIndexMgr	 	
	* @method 	 */	
    this.setCurrentItemNonePlayable = function() {
		if(this.playListLog.length <= 0)
		{
			return false;
		}
	
		if (this.playListLog[this.nCurIndex] == this.enumState.MP_ITEM_FAILED_TO_PLAY)
		{
			//for W0000178934
		}
		else
		{
			this.nTotalPlayableCount--;
			this.playListLog[this.nCurIndex] = this.enumState.MP_ITEM_FAILED_TO_PLAY;
		}    	
    };

	/**reset Manager
	* @name resetManager	 
	* @memberOf PlayerIndexMgr	 	
	* @method 	 */		
    this.resetManager = function() {
		for( var i=0; i<this.nTotalCount; i++)
		{
			if( this.playListLog[i] == this.enumState.MP_ITEM_PLAYED )
			{
				this.playListLog[i] = this.enumState.MP_ITEM_UNPLAYED;
			}
		}    	
    };

	/**reset Current Item Playable
	* @name resetCurrentItemPlayable	 
	* @memberOf PlayerIndexMgr	 	
	* @method 	 */		
    this.resetCurrentItemPlayable = function() {
		if(this.playListLog.size() <= 0)
		{
			return;
		}
	
		if(this.playListLog[this.nCurIndex] == this.enumState.MP_ITEM_FAILED_TO_PLAY)
		{
			playListLog[this.nCurIndex] = this.enumState.MP_ITEM_PLAYED;
			this.nTotalPlayableCount++;
		}    	
    };

	/**get repeat/shuffle mode
	* @name _GetCurrentPlayOption	 
	* @memberOf PlayerIndexMgr	 	
	* @method 	 */	
    this._GetCurrentPlayOption = function() {
    	var res = {
    		sRepeat : "off",
    		bShuffle : "true",
    	};
    	
    	res.sRepeat = this.getRepeat();
    	res.bShuffle = this.getShuffle();
    	return res;
    };
    
}

exports = PlayerIndexMgr;
