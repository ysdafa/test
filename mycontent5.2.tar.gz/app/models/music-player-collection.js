 /** 
 * @author  Hu Po (pual.hu@samsung.com)
 * 			
 * @fileoverview  Base collection class
 * @date    2014/10/11 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var Backbone = Volt.require('modules/backbone.js');
var MusicModel = Volt.require("app/models/music-model.js");

//var LoadingView = Volt.require('app/views/loading-view.js');
var CommonInfo = Volt.require("app/common/define.js");
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EItemType = CommonInfo.EItemType;
var EViewType = CommonInfo.EViewType;
var MediaType = CommonInfo.MediaType;
var PageStyle = CommonInfo.PageStyle;
var CSFSefType = CommonInfo.CSFSefType;
var EventType = CommonInfo.EventType;
var EventMediator = RunTimeInfo.EventMediator;
var CSFSourceType = CommonInfo.CSFSourceType;
var CSFSefType = CommonInfo.CSFSefType;
var resMgr = Volt.require('app/controller/resource-controller.js');

var self  = null;

var MusicPlayerCollection = Backbone.Collection.extend({
	model : MusicModel,
	agent : null,
	delAgent: '',
	sorttype: 'CATEGORY_NONE',
	sourceType: '',
	groupIndex: -1,
	csfApi : null,
	itemCount: 0,
	rootGroupFlag: true,
	musicData: false,

	/** Initialize MusicPlayerCollection  	 
	* @name initialize	 
	* @memberOf MusicPlayerCollection
	* @method 	 
	* */	
	initialize : function(){	
		self = this;
		//open csf sef
		self.csfApi = Volt.require('app/models/csf-manager.js'); //new CsfApi();
				
		self.csfApi.addEventCallback(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_EMPTY, self._getDataFailed);
		self.csfApi.addEventCallback(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_SUCCESS, self._getDataSuccessful);
		self.csfApi.addEventCallback(CSFSefType.SEF_CSF_EVENT_REQUEST_LIST_FAIL, self._getDataFailed);
	
	},

	setGroupIndex : function(gIndex){
		self.groupIndex = gIndex;
	},

	/** Request List 	 
	* @name requestList	 
	* @memberOf MusicPlayerCollection
	* @param {options} content options
	* @method 	 
	* */	
	requestList : function(options){
		print('music player collection [requestList] param_scan_path :',options.param_scan_path);
		Log.e("music player collection [requestList] param_scan_path :" + options.param_scan_path);

		EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
//		LoadingView.show();
		self.sorttype = options.param_sort_category;
		self.sourceType = options.param_source_name;
		print('[MusicPlayerCollection.js]request list : scanPath:',options.param_scan_path,'contentType: ', options.param_content_type,'sortType:', options.param_sort_category);
		self.musicData = true;
		self.csfApi.requestList(options);
	},	

	_getDataSuccessful : function(param1, param2){
		Log.f('[MusicPlayerCollection.js] _getDataSuccessful');
		if( self.musicData == false ){
			return;
		}
		self.getItems(param1, param2);	
		print('getItems done, try to send message EVENT_TYPE_MUSICPLAYER_DATA_DONE');
		EventMediator.trigger(EventType.EVENT_TYPE_MUSICPLAYER_DATA_DONE);
//		LoadingView.hide();
		self.musicData = false;
	},

	_getDataFailed : function(param1, param2){
		Log.f('[MusicPlayerCollection.js] _getDataFailed');
		if( self.musicData == false ){
			return;
		}	
		EventMediator.trigger(EventType.EVENT_TYPE_MUSICPLAYER_DATA_FAILED);
//		LoadingView.hide();
		self.musicData = false;
	},

	/** Get Page Style By Category
	* @name getPageStylebyCategory	 
	* @memberOf MusicPlayerCollection
	* @param {sortType} category type
	* @method 	 
	* */	
	getPageStylebyCategory: function(sortType){
	
		var pageStyle = 0x0;

		print('sortType-----'+sortType);

		switch(sortType){
			case 'CATEGORY-TITLE': 
			case 'CATEGORY-TRACK':
				pageStyle = 0x4;
				break;
		
			case 'CATEGORY-TRACK':
			case 'CATEGORY-ARTIST':
			case 'CATEGORY-ALBUM':
			case 'CATEGORY-GENRE':
			case 'CATEGORY-DATE':
			case 'CATEGORY-CHANNEL_NAME':
				{   
					pageStyle = 0x4;
				}
				break;
			case 'CATEGORY-FOLDER':
				{
					pageStyle = 0x4;
				}				
				break;
			default: 
				break;	
				
		}

		return pageStyle;
	
	},	

	/** Get Content Items
	* @name getItems	 
	* @memberOf MusicPlayerCollection
	* @param {String} data
	* @param {Object} Json file
	* @method 	 
	* */	
	getItems:function(param1,param2){
		print('[MusicPlayerCollection.js] getItems');
		self.agent =  JSON.parse(param2).param_agent;

		//set page style
		var pageStyle ={
			param_agent: self.agent,
			param_page_style: self.getPageStylebyCategory(self.sorttype),
			param_page_order: 1,
			param_group_index: self.groupIndex,
			param_row: 3,
			param_column: 9,
			param_need_padding: 0,
		};
		self.csfApi.setPageStyle(pageStyle);
	
		//getItemCount
		var totalCount = self.csfApi.getItemCount({
			param_agent : self.agent,			
		});
		self.itemCount = totalCount.return_data;
		print('total item count:', totalCount.return_data);
		
		//performance test
		var startTime = new Date();
		print ("music time: Get Value startTime: ", startTime.getTime());
		for(var idx = 0;idx < totalCount.return_data; idx++){					
			var itemModel = new MusicModel({dataFlag : 0});
			self.add(itemModel);
		}

		var playerController = Volt.require('app/controller/play-controller.js');
		var currIdx = playerController.getCurrentIdx();
		var startIdx = currIdx-12<0 ? 0:currIdx-12;
		var endIdx = currIdx+12 >= self.itemCount ? self.itemCount-1 : startIdx+13;
		print(' get data from ', startIdx, ' to the ', endIdx);
		self.getItemList(startIdx,endIdx-startIdx+1);

		//performance test
		var endTime = new Date();
		print ("music time: Get Value End Time: ", endTime.getTime());

		return true;
	},	

	getItemList: function(index,count){
		var startTime = new Date();
		print("[getItemList]Get Value startTime: ", startTime.getTime());
		var JsonItems = self.csfApi.getItemList({
			param_agent: self.agent,
			param_index: index,
			param_count: count,
		
		});
		var JsonTemp = JsonItems;
		print('JsonItems is: ', JsonItems);
		var parseTime = new Date();
		print("[getItemList]Get Value startTime: ", parseTime.getTime());
		var itemData = JSON.parse(JsonTemp.return_data);
		var itemList = itemData.param_item_list;
		var itemCount = itemData.param_count;
		//print('typeof(index) :' + typeof(index));
		for(var id = 0; id < itemCount; id++){
			print('id : ' +id + 'itemList[id]' + itemList[id]);
		//	print(typeof(id));		
			var itemModel = null;
			if(self.sourceType === 'csf_local_source_dlna'){					
				self.getDlnaItem(itemList[id], index+id);						
			}
			/*
			else if(self.sourceType === 'csf_ra_source'){
				self.getRAItem(itemList[id], index+id);
			}
			*/
			else{
				self.getUsbItem(itemList[id], index+id);
			}	
		}
		var endTime = new Date();
		print("[getItemList]Get Value endTime: ", endTime.getTime());
	},

	/** Get Usb Item
	* @name getUsbItem	 
	* @memberOf MusicPlayerCollection
	* @param {Object} json object
	* @param {int} index
	* @method 	 
	* */	
	getUsbItem : function(jsonItem, idx){
		print('[getUsbItem] jsonItem : ',jsonItem);
		try{
			var returnData = JSON.parse(jsonItem);
		}
		catch(e){
			print('JSON parase error');
			var itemModel = self.at(idx);
			if(!itemModel){
				itemModel = new MusicModel({
					dataFlag : 1,
					index : idx,
					title1 : title,
					filePath : strfilePath,
					ThumbPath : strThumbPath,
					ItemType : itemType,
					isWatched : bwatched,
					size : itemSize,
					artist: resMgr.getText('COM_SID_UNKNOWN'),
					album: resMgr.getText('COM_SID_UNKNOWN'),	
					playavail: 0,
				});
			}
			return itemModel;
		}
		
		var title = returnData.TITLE;
		var mediaType = parseInt(returnData.MEDIA_TYPE) ;
		var strfilePath =  returnData.FILE_PATH;
		var strThumbPath = returnData.THUMBNAIL_PATH;
		var bwatched = false;
		var itemSize = returnData.SIZE;
		var ptpThumbPath = returnData.THUMBNAIL_PATH;
		var playAvail = (returnData.PLAYED_COUNT == '-1') ? false: true;
		var musicArtist = returnData.ARTIST;
		var musicAlbum = returnData.ALBUM;
		var playCount = returnData.PLAYED_COUNT;
		
		var itemType = EItemType.eItemMusic;
		
		var itemModel = self.at(idx);
		
		if(!itemModel){
			itemModel = new MusicModel({
				dataFlag : 1,
				index : idx,
				title1 : title,
				filePath : strfilePath,
				ItemType : itemType,
				isWatched : bwatched,
				size : itemSize,
				artist : musicArtist,
				album : musicAlbum,
				ThumbPath : strThumbPath,
				playavail: playCount,
			});
			print('add Item :' + idx);	
		}
		else{
			itemModel.set('dataFlag', 1);
			itemModel.set('index', idx);
			itemModel.set('title1', title);
			itemModel.set('filePath', strfilePath);
			itemModel.set('ItemType', itemType);
			itemModel.set('isWatched', bwatched);
			itemModel.set('size', itemSize);
			itemModel.set('ptpThumbPath', ptpThumbPath);
			itemModel.set('isPlayAvailable',playAvail );
			itemModel.set('artist', musicArtist);
			itemModel.set('album', musicAlbum);
			itemModel.set('ThumbPath', strThumbPath);
			itemModel.set('playavail', playCount);
			print('update Item :' + idx);
		}
		
		return itemModel;
	},

	/** Get Dlna Item
	* @name getDlnaItem	 
	* @memberOf MusicPlayerCollection
	* @param {Object} json object
	* @param {int} index
	* @method 	 
	* */	
	getDlnaItem : function(jsonItem, idx){
		//var returnData = JSON.parse(jsonItem);
		try{
			var returnData = JSON.parse(jsonItem);
		}
		catch(e){
			print('JSON parase error');
			var itemModel = self.at(idx);
			if(!itemModel){
				itemModel = new MusicModel({
					dataFlag : 1,
					index : idx,
					title1 : title,
					filePath : strfilePath,
					ThumbPath : strThumbPath,					
					ItemType : itemType,
					isWatched : bwatched,
					size : itemSize,
					artist: resMgr.getText('COM_SID_UNKNOWN'),
					album: resMgr.getText('COM_SID_UNKNOWN'),	
					playavail: 0,
				});
			}
			return itemModel;
		}
		var title = returnData.TITLE;
		var mediaType = parseInt(returnData.MEDIA_TYPE) ;
		var strfilePath =  returnData.URL;
		var itemSize = returnData.SIZE;
		var itemType = EItemType.eItemMusic;
		var musicArtist = returnData.ARTIST;
		var musicAlbum = returnData.ALBUM;
		var strThumbPath = returnData.THUMBNAIL_PATH;
		var playCount = returnData.PLAYED_COUNT;
		
		var itemModel = self.at(idx);
		
		if(!itemModel){
			itemModel = new MusicModel({
				dataFlag : 1,
				index : idx,
				title1 : title,
				filePath : strfilePath,
				ThumbPath : strThumbPath,				
				ItemType : itemType,	
				size : itemSize,
				artist : musicArtist,
				album : musicAlbum,
				playavail : playCount,
			});
		}
		else{
			itemModel.set('dataFlag', 1);
			itemModel.set('index', idx);
			itemModel.set('title1', title);
			itemModel.set('filePath', strfilePath);
			itemModel.set('ItemType', itemType);
			itemModel.set('size', itemSize);
			itemModel.set('artist', musicArtist);
			itemModel.set('album', musicAlbum);
			itemModel.set('ThumbPath', strThumbPath);
			itemModel.set('playavail', playCount);
		}
		return itemModel;				
	},	

	/** Get RA Item
	* @name geRAItem	 
	* @memberOf MusicPlayerCollection
	* @param {Object} json object
	* @param {int} index
	* @method 	 
	* 	
	getRAItem : function(jsonItem, idx){
		try{
			var returnData = JSON.parse(jsonItem);
		}
		catch(e){
			print('JSON parase error');
			var itemModel = self.at(idx);
			if(!itemModel){
				itemModel = new MusicModel({
					dataFlag : 1,
					index : idx,
					title1 : title,
					filePath : strfilePath,
					ItemType : itemType,
					isWatched : bwatched,
					size : itemSize,
					ptpThumbPath : ptpThumbPath,
					artist:'Unknown',
					album:'Unknown',						
				});
			}
			return itemModel;
		}
		var title = returnData.TITLE;
		var mediaType = parseInt(returnData.MEDIA_TYPE) ;
		var strfilePath =  returnData.THUMBNAIL_PATH;
		var itemSize = returnData.SIZE;
		var itemType = EItemType.eItemMusic;
		var musicArtist = returnData.ARTIST;
		var musicAlbum = returnData.ALBUM;			
		
		var itemModel = self.at(idx);
		
		if(!itemModel){
			itemModel = new MusicModel({
				dataFlag : 1,
				index : idx,
				title1 : title,
				filePath : strfilePath,
				ItemType : itemType,	
				size : itemSize,
				artist : musicArtist,
				album : musicAlbum				
			});
		}
		else{
			itemModel.set('dataFlag', 1);
			itemModel.set('index', idx);
			itemModel.set('title1', title);
			itemModel.set('filePath', strfilePath);
			itemModel.set('ItemType', itemType);
			itemModel.set('size', itemSize);
			itemModel.set('artist', musicArtist);
			itemModel.set('album', musicAlbum);				
		}
		return itemModel;				
	},	
	*/

	/** Get Item Value
	* @name getItemValue	 
	* @memberOf MusicPlayerCollection
	* @param {int} index, field
	* @param {enum} index, field
	* @method 	 
	* */	
	getItemValue: function(index, field){
		var ret = self.csfApi.getItemValue({
			param_agent : self.agent,
			param_index : index,
			param_field : field,
		})

//		var jsonData = JSON.parse(ret);
		return ret.return_data;
		
	},

	/** Set Item Value
	* @name setItemValue	 
	* @memberOf MusicPlayerCollection
	* @param {int} index
	* @param {enum} field
	* @param {String} value
	* @method 	 
	* */		
	setItemValue: function(index, field, value){
		if(self.agent!=null){
			self.csfApi.setItemValue({
				param_agent : self.agent,
				param_index : index,
				param_field : field,
				param_value : value,
			})
		}
	},

	disConnect: function(){
		if(self.agent != null){			
			var disconnectcsfpara ={
				"param_agent":self.agent
			}	
			self.csfApi.disconnectCsf(disconnectcsfpara);
			self.agent = null;
		}
	},

	/** Get music detail info
	* @name getMusicDetail	 
	* @memberOf MusicPlayerCollection
	* @param {index} index
	* @method 	 
	* */	
	getMusicDetail: function(index){
		var dataItem = self.csfApi.getItem({
			param_agent: self.agent,
			param_index: index,	
		});	

		print('[getMusicDetail] Item : ',dataItem.return_data);

		if(dataItem.return_data == undefined || dataItem.return_data == null){
			print('[music-player-collection.js]getMusicDetail------dataItem.return_data is ' + dataItem.return_data);
			Log.e('[music-player-collection.js]getMusicDetail------dataItem.return_data is ' + dataItem.return_data);
			return;
		}

		
		var returnData = {};
		print('[getMusicDetail] ------ create empty object');
		try{
			returnData = JSON.parse(dataItem.return_data);
		}
		catch(e){
			print('[music-player-collection.js]getMusicDetail------dataItem.return_data get failed : ' + dataItem.return_data);
			Log.e('[music-player-collection.js]getMusicDetail------dataItem.return_data get failed : ' + dataItem.return_data);
		}
		
		var mmodel = new MusicModel;
		mmodel.set('title', returnData.TITLE);
		mmodel.set('displayName', returnData.DISPLAY_NAME);
		mmodel.set('genre', returnData.GENRE);
		mmodel.set('artist', returnData.ARTIST);
		mmodel.set('album', returnData.ALBUM);
		mmodel.set('duration', returnData.DURATION);
		mmodel.set('lastSaveDate', returnData.MODIFIED_TIME);
		if(self.sourceType === 'csf_local_source_dlna'){
			mmodel.set('lastSaveDate', returnData.DATE_TAKEN);			
		}
		mmodel.set('size', returnData.SIZE);
		//mmodel.set('filepath',returnData.FILE_PATH);
		mmodel.set('location',self.getItemLocation(returnData.FILE_PATH, returnData.DISPLAY_NAME));
		mmodel.set('genre', returnData.GENRE);
		if(returnData.FORMAT != undefined){
	         mmodel.set('format', returnData.FORMAT);
	     }
	     else{
	         mmodel.set('format', returnData.MIME_TYPE);
	     }
		return mmodel;
	},

	/** Get item location
	* @name getItemLocation	 
	* @memberOf MusicPlayerCollection
	* @param {filepath} filepath
	* @method 	 
	* */	
	getItemLocation: function(filePath, fileName){
		
		print('getItemLocation filePath:' + filePath + ' fileName:'+ fileName);
		
		var mainView = Volt.require('app/views/main-view.js');
		var DeviceProvider = Volt.require("app/models/device-provider.js");
		var devItem = DeviceProvider.getDeviceInfo(mainView.categoryView.currentID);
		if( devItem.get('displayName') != null ){
			if(filePath == null || devItem.get('mountPath') == null){
				filePath = devItem.get('displayName');
			}
			else if(filePath.search(devItem.get('mountPath'))>=0){	
				filePath = filePath.replace(devItem.get('mountPath'), devItem.get('displayName'));					
			}
			
			filePath = filePath.replace(fileName,''); 
			//print('[getItemLocation] filePath :',filePath);
			filePath = filePath.substring(0, filePath.length - 1); 
			
			print('[getItemLocation] filePath :',filePath);
		}
		
		return filePath;
	},	

	getPageIndex: function(filePath){
		print(" getPageIndex  filePath:"+filePath);
		var JsonIdx = self.csfApi.getPageIndex({
			param_agent: self.agent,
			param_media: '' + filePath,
		});		
		var lastPlayIndex = parseInt(JsonIdx.return_data);
		print(" getPageIndex  lastPlayIndex:"+lastPlayIndex);
		return lastPlayIndex;
	},
});

exports = MusicPlayerCollection;

