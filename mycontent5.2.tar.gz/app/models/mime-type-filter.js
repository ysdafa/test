var VideoFilter = ['avi', 'mpg','mpeg','mp4', 'vob', 'vro','ts', 'trp', 'tp', 'svi', 'mkv', 
					'wmv', 'asf', '3gp', 'divx', 'flv', 'm2ts','mov','mts','webm','s4ud'];
var CNVideoFilter = ['avi', 'mpg','mpeg','mp4', 'vob', 'vro','ts', 'trp', 'tp', 'svi', 'mkv', 
					'wmv', 'asf', '3gp', 'divx', 'flv', 'm2ts','mov','mts','webm','s4ud', 'rmvb', 'rm'];
					
var PhotoFilter = ['jpg','jpeg', 'mpo', 'bmp', 'png'];

var MusicFilter= ['m4a', 'aac', 'mpa', 'flac', 'ogg', 'mid', 'midi', 'ape', 'aif', "aiff",'mp3', 'wma', 'wav'];

var AtscMusicFilter= ['aac', 'aif', 'aiff', 'ape', 'flac', 'm4a', 'mid', 'midi', 'mp3', 'mpa', 'ogg','wav', 'wma'];
var PvrFilter = ['srf'];
var UhdFilter = ['um4'];
var KorUhdFilter = ['um4', 'km4'];

var ScsaFilter = ['scsa', 'uvu', 'uva', 'uvp', 'smp', 'svp', 'dmp'];

//exports.VideoFilter = VideoFilter;
exports.PhotoFilter = PhotoFilter;
exports.PvrFilter = PvrFilter;
exports.ScsaFilter = ScsaFilter;

//var VCONF_COUNTRYCODE   = 'db/comss/countrycode';
//var countrycode = Vconf.getValue(VCONF_COUNTRYCODE);
//Log.f('countrycode>>>>>>>>>>>>>>>>>>>>> contrycode ID:'+countrycode);


var localSet = SystemInfo.getStringValue(SystemInfo.KEY_LOCAL_SET);
Log.f('localSet>>>>>>>>>>>>>>>>>>>>> localSet:'+localSet);
if( localSet === 'KOR' ){
	exports.UhdFilter = KorUhdFilter;
}
else{
	exports.UhdFilter = UhdFilter;
}

if( localSet === 'CHI_DTV' || localSet === 'HKG_DTV' ){
	exports.VideoFilter = CNVideoFilter;
}
else{
	exports.VideoFilter = VideoFilter;
}

var appConfig = Volt.require("app/common/app-config.js");
var board = appConfig.getSWVersion();
if(board == 'HKPAKUC' || board == 'HKMFAKUC' || board == 'HKMAKUC'){
	exports.MusicFilter = AtscMusicFilter;
}
else{
	exports.MusicFilter = MusicFilter;	
}



/////change list as belowing
//remove gif DF141215-02015
//add rmvb DF141223-02207
//DF141223-01438
//jpeg error DF141229-00190
// remove mid DF141229-00191
//add mid DF150123-02406
//add local setting for DF150122-02648
//add 'ac3', 'adts', 'lpcm', 'mp2', 'pcm', 'rmj', 'vqf', 'mka', 'ra'  DF150127-02303
//add mid DF150114-01467
//add rmvb, rm for China, DF150127-02303
//add atsc music filter, DF150203-01756
//remove  'ac3', 'adts', 'lpcm', 'mp2', 'pcm', 'rmj', 'vqf', 'mka', 'ra'  DF150205-00452
//DF150204-00777 add 'rmvb', 'rm' for CN video 
//use local set to determin  CN product DF150211-01607