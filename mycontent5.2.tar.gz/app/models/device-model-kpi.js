/*
 * @module DeviceModel
 */

var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require('modules/underscore.js')._;
var CommonPopupView = Volt.require('app/views/common-popup-view.js');

// if(Volt.browser){
//     var voltAPI = Volt.require("modules/voltapi.js");
// }else{
//     var voltAPI = require("$VOLT_ROOT/modules/voltapi.js");
// }

//var voltAPI = Volt.require("modules/voltapi.js");
//var voltAPI = require('voltapi.js');
//var voltAPI = require("voltapi");
var voltAPI = Volt.require('voltapi.js');
// Save JSAPI Init open status
var mapJSAPI = {};

function getJSAPI(name, options) {
    function initJSAPI(name) {
        var nOpenResult = voltAPI[name].init();
        if (nOpenResult) {
            Volt.log('[device-model.js] getJSAPI Open(' + name + ') Sucecss');
            mapJSAPI[name] = true;
        } else {
            Volt.log('[device-model.js] getJSAPI Open(' + name + ') Failed');
            mapJSAPI[name] = false;
        }
    }

    if(name == 'vconf'){
        //don't need to init
        return voltAPI[name];
    }

    var ePlugin = voltAPI[name];
    if(!mapJSAPI[name]) {
        // Plugin element is loaded, but Open failed
        initJSAPI(name);
    }

    return ePlugin;
    
}

function getDebugInfo(){
    var eWASPlugin = getJSAPI('WAS'),
        oResult = eWASPlugin.getDebugInfo();
    return oResult || {};
}

function createTokenProxy(){
    var eWASPlugin = getJSAPI('WAS');
    eWASPlugin.createTokenProxy();
}

function createManagerProxy(){
    var eWASPlugin = getJSAPI('WAS');
    eWASPlugin.createManagerProxy();
}

function getCountryCode() {
    // return 'BR';
    var eWASPlugin = getJSAPI('WAS'),
        sResult = eWASPlugin.getCountryCode(),
        sCountryCode = sResult || 'US';

    switch(sCountryCode) {
        case 'XI' :
            sCountryCode = 'MX';
            break;
        case 'XJ' :
            sCountryCode = 'BR';
            break;
        case 'AA' :
            sCountryCode = 'BR';
            break;
    }

    Volt.log('[device-model.js] CountryCode ::::::::  Result : ' + sResult + ' Return : ' + sCountryCode);

    return sCountryCode;
}

var VCONF = {
    DEVICE_ATOKEN : 'db/comss/atoken',
    DEVICE_DUID : 'db/comss/duid',
    DEVICE_MODEL_ID : 'db/comss/modelid',
    DEVICE_COUNTRY_CODE : 'db/comss/countrycode',
    DEVICE_TV_NAME : 'db/menu/network/devicename/tv_name',
    HIGHCONTRAST : 'db/menu/system/accessibility/highcontrast',
    FOCUSZOOM : 'db/menu/system/accessibility/focuszoom',
    MENU_LANGUAGE : 'db/menu/system/menu_language',
    COACHMARK_SHOW_FLAG : 'memory/homepanel/coachmark_show_flag', //0 : coachmark is hidden, 1 : coachmark is shown
    CURSOR_VISIBLE : 'memory/window_system/input/cursor_visible',
    MENU_TRANSPARENCY : 'db/menu/system/general/menu_transparency',
    AUDIO_DESCRIPTION : 'db/menu/system/accessibility/audio_description'
};

function getVconfValues(){
    var eVConfPlugin = getJSAPI('vconf');

    Volt.err('[vconf] DEVICE_TV_NAME : ' + eVConfPlugin.getValue(VCONF.DEVICE_TV_NAME));
    Volt.err('[vconf] HIGHCONTRAST : ' + eVConfPlugin.getValue(VCONF.HIGHCONTRAST));
    Volt.err('[vconf] FOCUSZOOM : ' + eVConfPlugin.getValue(VCONF.FOCUSZOOM));
    Volt.err('[vconf] MENU_LANGUAGE : ' + eVConfPlugin.getValue(VCONF.MENU_LANGUAGE));
    Volt.err('[vconf] COACHMARK_SHOW_FLAG : ' + eVConfPlugin.getValue(VCONF.COACHMARK_SHOW_FLAG));
}

function getCountryCode(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.DEVICE_COUNTRY_CODE); //retur string
    Volt.log('[device-model.js] vconf DEVICE_COUNTRY_CODE : ' + result);
    return result;
}

function getModelId(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.DEVICE_MODEL_ID); //retur string
    Volt.log('[device-model.js] vconf DEVICE_MODEL_ID : ' + result);
    return result;
}

function getDuid(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.DEVICE_DUID); //retur string
    Volt.log('[device-model.js] vconf DEVICE_DUID : ' + result);
    return result;
}

function getAToken(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.DEVICE_ATOKEN); //retur string
    Volt.log('[device-model.js] vconf DEVICE_ATOKEN : ' + result);
    return result;
}

function getHighContrast(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.HIGHCONTRAST); //return int 0 , 1 : off /on
    Volt.log('[device-model.js] vconf HIGHCONTRAST : ' + result);
    return !!(result);
}

function getFocusZoom(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.FOCUSZOOM); //return int 0 , 1 : off /on
    Volt.log('[device-model.js] vconf FOCUSZOOM : ' + result);
    return !!(result);
}

function getCoachmark(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.COACHMARK_SHOW_FLAG); //return int 0 , 1 : off /on
    Volt.log('[device-model.js] vconf COACHMARK_SHOW_FLAG : ' + result);
    return !!(result);
}

function getMenuLanguage(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.MENU_LANGUAGE); //retur string
    Volt.log('[device-model.js] vconf MENU_LANGUAGE : ' + result);
    return result;
}

function getAudioDesc(){
    var eVConfPlugin = getJSAPI('vconf');
    var result = eVConfPlugin.getValue(VCONF.AUDIO_DESCRIPTION); //retur string
    Volt.log('[device-model.js] vconf AUDIO_DESCRIPTION : ' + result);
    return !!(result);
}


function getTargetLocation() { // private
    var eDevicePlugin = getJSAPI('device'),
        nTargetLocation = eDevicePlugin.getTargetLocation(); //return JSON
        Volt.log('[device-model.js] LocationCode :::::::: ' + nTargetLocation);
    return nTargetLocation || 2; //US
}

function getAgreedTNC() {
    var eLoggingPlugin = getJSAPI('Logging'),
        sAgreedTNC = eLoggingPlugin.isAgreedWith('tnc');

    Volt.log('[device-model.js]  Terms and Condition :::::::: ' + sAgreedTNC);

    return sAgreedTNC == '1' ? true : false;
}

function getAgreedPP() {
    var eLoggingPlugin = getJSAPI('Logging'),
        sAgreedPP = eLoggingPlugin.isAgreedWith('pp');

    Volt.log('[device-model.js]  Privacy policy :::::::: ' + sAgreedPP);

    return sAgreedPP == '1' ? true : false;
}

function agreeSmartHub() {
    var tnc = getAgreedTNC();
    var pp = getAgreedPP();
    if (tnc && pp) {
        return true;
    }
    return false;
}

function checkNetwork(){
    var eNetworkPlugin = getJSAPI('network');
    var stateNetwork = true;

    eNetworkPlugin.getAvailableNetworks(function(networkList) {
        Volt.err(networkList)
        var interfaceType = networkList[0].interfaceType;

        networkList[0].setWatchListener({
            onconnect : function(type) {
                Volt.log("[device-model.js] wireless network onconnect");
                Volt.GlobalMediator.trigger('EVENT_NETWORK_CONNECTED');
            },
            ondisconnect : function(type) {
                Volt.log("[device-model.js] wireless network ondisconnect");
                Volt.GlobalMediator.trigger('EVENT_NETWORK_DISCONNECTED');
            }
        }, function() {
            Volt.log("[device-model.js] wireless network error");
            Volt.GlobalMediator.trigger('EVENT_NETWORK_ERROR');
            stateNetwork = false;
        });

        networkList[1].setWatchListener({
            onconnect : function(type) {
                Volt.log("[device-model.js] wired network onconnect");
                Volt.GlobalMediator.trigger('EVENT_NETWORK_CONNECTED');
            },
            ondisconnect : function(type) {
                Volt.log("[device-model.js] wired network ondisconnect");
                Volt.GlobalMediator.trigger('EVENT_NETWORK_DISCONNECTED');

            }
        }, function() {
            Volt.log("[device-model.js] wired network error");
            Volt.GlobalMediator.trigger('EVENT_NETWORK_ERROR');
            stateNetwork = false;
        });
    }, function(errorMessage) {
        Volt.log("[device-model.js] network error errorMessage : " + errorMessage);
        stateNetwork = false;
    });

    return stateNetwork;
}

function getLanguageCode() {

    var languageCode = '';

    var preDefine = {
        'fr_CA' : 'fr-US',
        'es_MX' : 'es-US',
        'pt_BR' : 'pt-US',
        'en_GB' : 'en-GB',
        'zh_CN' : 'zh-CN',
        'zh_HK' : 'zh-HK',
        'zh_TW' : 'zh-TW'
    }

    var vconfMenuLang = getMenuLanguage();
    var lang = vconfMenuLang.split('.')[0];

    if(preDefine[lang]){
        languageCode = preDefine[lang];
    }else{
        languageCode = lang.split('_')[0];
    }
   
   return languageCode;
}


/**
 * @constructor
 * @alias module:DeviceModel
 */
var DeviceModel = Backbone.Model.extend({

    /** Default properties of DeviceModel */
    defaults: {
        duid: '7XCA3K5OC4PRQ',
        modelId: '15_TIZEN',
        countryCode: 'BR',
        languageCode: 'en',
        serverType: 'development',
        firmware: 'T-INFOLINK2014-1002',
        guid : '',
        serviceLanguage : 'en',
        aToken : '',
        coachmark : false,
        highcontrast : false,
        focuszoom : false,
        audio_description : false,
        agreePolicy : false,
        network_status : true
    },

    /** 
     * Initialize DeviceModel
     * @augments Backbone.Model      
     */
    initialize: function() {
        // this.init();

        //this.listenTo(Volt.GlobalMediator,'EVENT_NETWORK_CONNECTED', this.onNetworkConnected);
        //this.listenTo(Volt.GlobalMediator, 'EVENT_NETWORK_DISCONNECTED', this.onNetworkDisConnected);
        //this.listenTo(Volt.GlobalMediator, 'EVENT_NETWORK_ERROR', this.onNetworkError);
    },

    /** 
     * Set all property
     * @method         
     */ 
    init : function(){
        Volt.log('[device-model.js] init');
        if(Volt.browser){
            Volt.log('[device-model.js] browser base - use default Value');
            return;
        }
       
        
        // createManagerProxy();
        // createTokenProxy();
        this.setInfoFromWAS();
        this.setInfoFromVCONF();
        this.set('agreePolicy', agreeSmartHub());

//        comment out for Product Release
//        this.set('network_status', checkNetwork());

        _.each(this.attributes, function(value, key){
             Volt.log('[device-model.js] set : ' + key + ' : ' + value);
        });

        this.setChangeHandlerVconf();

        return this;
    },

    onNetworkConnected : function(){
        this.set('network_status', true);
    },

    onNetworkDisConnected : function(){
        this.set('network_status', false);

        var iPopupView = new CommonPopupView({
            type : 'TITLE_BUTTON',
            timeout : false,
            fade : false,
            title : 'Network Error',
            message : "You're not connected to the Internet. This feature requires network access.",
            buttons : ['Troubleshoot', 'Cancel'],
            callback : function(index){
                if(index == 0){
                    var aulApp = new Aul();
                    var ret = aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                }else{

                }
            }
        }).show();

    },

    onNetworkError : function(){
        this.set('network_status', false);
    },

    /**
     * Get information from WAS
     * @method
        */
    setInfoFromWAS : function(){
        var dedugInfo = getDebugInfo();
        Volt.err(dedugInfo)
        this.set('duid', dedugInfo.duid);
        this.set('modelId', dedugInfo.model_id);
        this.set('countryCode', dedugInfo.country);
        this.set('firmware', dedugInfo.firmware_version);
        this.set('localSet', dedugInfo.local_set);
        this.set('macAddr', dedugInfo.mac_addr);
        this.set('serverType', dedugInfo.server_type);
    },

    setInfoFromVCONF : function(){

        getDuid();
        getModelId();
        getCountryCode();

        this.set('aToken', getAToken());
        // this.set('duid', getDuid());
        // this.set('modelId', getModelId());
        // this.set('countryCode', getCountryCode());
        this.set('highcontrast', getHighContrast());
        this.set('focuszoom', getFocusZoom());
        this.set('coachmark', getCoachmark());
        this.set('menu_lang', getMenuLanguage());
        this.set('audio_description', getAudioDesc());
        this.set('languageCode', getLanguageCode());
    },

    setChangeHandlerVconf : function(){
        var eVConfPlugin = getJSAPI('vconf');
        Vconf.setOnChangeHandler(VCONF.HIGHCONTRAST, function(key, value){
             Volt.err("######### setOnChangeHandler: HIGHCONTRAST ");
             this.set('highcontrast', getHighContrast());
        });
        
        Vconf.setOnChangeHandler(VCONF.MENU_LANGUAGE, function(){
             Volt.err("######### setOnChangeHandler: MENU_LANGUAGE ");
             Volt.err(arguments);
        });

        Vconf.setOnChangeHandler(VCONF.CURSOR_VISIBLE, function(){
             Volt.err("######### setOnChangeHandler: CURSOR_VISIBLE ");
             Volt.err(arguments);
        });

        Vconf.setOnChangeHandler(VCONF.COACHMARK_SHOW_FLAG, function(){
             Volt.err("######### setOnChangeHandler: COACHMARK_SHOW_FLAG ");
             Volt.err(arguments);
        });

        Vconf.setOnChangeHandler(VCONF.AUDIO_DESCRIPTION, function(){
             Volt.err("######### setOnChangeHandler: AUDIO_DESCRIPTION ");
             Volt.err(arguments);
        });
    }
});

exports = new DeviceModel();
