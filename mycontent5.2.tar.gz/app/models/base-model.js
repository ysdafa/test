 /** 
 * @author  Chen Xuemei (xnicole.chen@samsung.com)
 * 			
 * @fileoverview  Base model class
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');
var CommonInfo = Volt.require("app/common/define.js");
var EItemType = CommonInfo.EItemType;

var BaseViewModel = Backbone.Model.extend({
    defaults: {
    	index : -1,
    	dataFlag : 0,
    	ItemType: EItemType.eItemNone,
    	isSelected: false,
        title1: '',
    	title2: '',
    	isThumbDone: false,
        ThumbPath: '',
        thumbPathArray: [],
        conIconPath: '',
        checkBoxPath: '',
       	filePath: '',
       	size: 0,
       	modifyTime:  '',  
       	isWatched: false,
		isPlayAvailable: true,
		ptpThumbPath: '',
		rateLevel:'',
		isAudioOnly: false,
		isGuidance: false,
		sportsType: 0,	
		isLocked: false,
		isRecording : false,
		uhdContentId:'', //only for UHD Video
		ciThumbType: -1,
		isDrm: false,
		date: '',
		chanelName: '',
		uhdVideoGenre:'',
    },
});


exports = BaseViewModel;
















































////////////////////////////////////////////////////////////////////////////////
// DO NOT ACROSS
////////////////////////////////////////////////////////////////////////////////
/*
    initialize: function() {
    	self = this;
    },

    fetch: function(index) {
    	if (index >= 0 && index < 5) {
			self.set('sectionName', sectionNameList[index]);
			self.set('sectionIndex', index);
		}
    },
*/