 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			He Wenge (wenge.he@samsung.com)
 * @fileoverview  Define global constanst varibale
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var PanelCommon = Volt.require('lib/panel-common.js');

var MagicKey = function() {
    var timerInstance = null;
    var listeners = [];
    var buffers = '';

    function onKeyPress(keycode) {
		print('MagicKey onKeyPress');
        if (timerInstance)
            Volt.clearTimeout(timerInstance);
        switch(keycode) {
            case Volt.KEY_0: buffers += '0'; break;
            case Volt.KEY_1: buffers += '1'; break;
            case Volt.KEY_2: buffers += '2'; break;
            case Volt.KEY_3: buffers += '3'; break;
            case Volt.KEY_4: buffers += '4'; break;
            case Volt.KEY_5: buffers += '5'; break;
            case Volt.KEY_6: buffers += '6'; break;
            case Volt.KEY_7: buffers += '7'; break;
            case Volt.KEY_8: buffers += '8'; break;
            case Volt.KEY_9: buffers += '9'; break;
        }
        if (executeListener()) {
            clearBuffer();
        }
        timerInstance = Volt.setTimeout(clearBuffer, 3000);
    }

    function executeListener() {
        var execute = false;
		print('listeners.length:', listeners.length);
        for (var idx=0; idx<listeners.length; idx++) {
            if (listeners[idx].key == buffers) {
                listeners[idx].listener();
                execute = true;
            }
        }
        return execute;
    }

    function clearBuffer() {
        Volt.log('clear buffer : '+buffers);
        buffers = '';
    }

    function addListener(keyword, callback) {
        listeners.push({
            key: keyword,
            listener: callback
        });
    }

    function removeListener() {
        listeners = [];
    }

    return {
        'onKeyPress': onKeyPress,
        'addListener': addListener,
        'removeListener': removeListener
    }
};

var RunTimeInfo = {
	router : {},
	EventMediator : new PanelCommon.Mediator(),
	playState: 0,
	appState: false,
	launchMusicReturnContentOrNot: false,
	categoryCollect : null,
	playerPause : false,
	uhdRateStatus:-1,
	firstUHDVide:true,
	isSendPopupShow: false,
	firstGetDlna:false,
	CategoryFocus:false,
	isLongPopupShow:false,
	isFirstLanch: false,
	isFilterChange: false,
	SuspendFlag : false,
	isEditMode: false,
	magicKey: new MagicKey(),
	isResetByFirstScreen: false,
	uhdRateLevel:[],
	uhdValidRateCount:0,
	isShowDisconnectPop:true,
	isLoadingShown:false,
	isOptionShowFlag:false,
	isSetroot:false,
	visibleCursor:false,
	threeDMode:0,
	SceneResolution: 1920,
	offSet: 0,
	bFlagFor2560:false,
	offsetFor2560:0,
	offsetForMusicControl:0,
	offsetForProgressBar:0,
	offsetForPrePauseNext:0,
	offsetForRepeartShuffle:0,

	disconnectCurrentDevice:false,

	operationBtnDim:false,
	isNoContent: false,
	bFlagForClickNextAndPrev: false,
	bFlagForPrev:false,
	bFlagForNotSupportPopup:false,
	CurrentPlayLoading:null,
	bFlagForDMRCLickPlaying:false,
	msgType:null,
	isLaunchTerm:false,
	bFlagForDMRandSearchCaseBallon:false,
	notSupportSong:false,
	isReturnFromMusicPlayer:false,
	UHDContentFolder:false,
	bFlagForInforBox:false,	
	bFlagForNAMsgBoxShow:false,
};

exports = RunTimeInfo;