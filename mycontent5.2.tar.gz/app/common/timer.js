 var timer = {
	preValue : 0,
	tick : function(tag){
		if(!tag || tag == undefined){
			tag = 'current';
		}
		
		tag = '[TIMER]'+ tag +' time is ------';
		var time = new Date().valueOf();
		print(tag + time + 'ms, time gap is ' + (time - this.preValue) + 'ms');
		this.preValue = time;
	},
};

exports = timer;