 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * @fileoverview  Define global constanst varibale
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');

var PKGNAME = "org.tizen.mycontents";
var resMgr = Volt.require('app/controller/resource-controller.js');
var EViewType = {
	eNoneView : -1,
	eAllContentView : 0,
	eVideoContentView : 1,
	ePhotoContentView : 2,
	eMusicContentView : 3,
	eRecordContentView : 4,
	eMobilePhoneView : 5,
	eCloudServiceView : 6,
	eMusicPlayerView : 7,
	eConnectionGuideView : 8,
	eConnectUsbGuideView : 9,
	eConnectPcGuideView : 10,
	eConnectMobileGuideView : 11,
	eWelcomePageView : 12,
	eViewMax : 13,
};

var EItemType = {
	eItemNone : -1,
	eItemVideo : 0,
	eItemPhoto : 1,
	eItemMusic : 2,
	eItemPvr : 3,
	eItemUHDVideo:4,
	eItemSCSA: 5,
	eItemFolder : 6,
	eItemGroup : 7,
	eItemUpFolder : 8,
	eItemPlaylist: 9,
	eItemEmpty: 10,	
	eItemTypeMax : 11,
};

var EOptType = {
	eNoneType : -1,
	eDeleteType : 0,
	eSendType : 1,
	ePlaySelType : 2,
};

var PopupType = {
	eNonePopup: -1,
	eDevicePopup: 0,
	eProgressPopup: 1,
	eMsgBoxPopup: 2,
};

var ProgressPopupType = {
	eNoneProgrePopup: -1,
	eOneProgrePopup: 0,
	eTwoProgrePopup: 1,
};

var MessageType = {
	eDeleteItem: 0,
	eStorageFull: 1,
	eDisconnectUsb: 2,
	eNotAvailable: 3,
	eNotSupportFile: 4,
	eUnableToSortBy: 5,
	eUnableSelectCopy: 6,
	eUnableSelectPlay: 7,
	eUnableSelectDel:8,
	eNetworkError:9,
	eUHDTwoButton:10,
	eMessageBox:11,
	eNotSupportFormat:12,
	eAppVersion:13,
	eDeviceInfo:14,
	eUnAvailable:15,
	NotPlayThisTrack:16,
	eNoRecordContent:17,
};

var EViewSwitchAniType = {
	eNoneAni : -1,
	eSlideShowAni : 0,
	eFadeInOutAni : 1,
};

var KeyCode = {
	up : Volt.KEY_JOYSTICK_UP,
	down : Volt.KEY_JOYSTICK_DOWN,
	left : Volt.KEY_JOYSTICK_LEFT,
	right : Volt.KEY_JOYSTICK_RIGHT,
	enter : Volt.KEY_JOYSTICK_OK,
	exit : Volt.KEY_EXIT,
	returnKey : Volt.KEY_RETURN,
	red : Volt.KEY_RED,
	green : Volt.KEY_GREEN,
	yellow : Volt.KEY_YELLOW,
	blue : Volt.KEY_BLUE,
	one : Volt.KEY_1,
	two : Volt.KEY_2,
	three : Volt.KEY_3,
	four : Volt.KEY_4,
	five : Volt.KEY_5,
	six : Volt.KEY_6,
	seven : Volt.KEY_7,
	eight : Volt.KEY_8,
	nine : Volt.KEY_9,
	zero : Volt.KEY_0,
	prepage : Volt.KEY_1,
	nextpage : Volt.KEY_2,
	pause: Volt.KEY_PAUSE,
	play: Volt.KEY_PLAY,
	stop: Volt.KEY_STOP,
	info: Volt.KEY_INFO,
	fastforward: Volt.KEY_FF,
	backforward: Volt.KEY_REWIND,
	next: Volt.KEY_FF_,
	pre: Volt.KEY_REWIND_,
	repeat: Volt.KEY_REPEAT,
};

var BlackClear = {
	r : 0,
	g : 0,
	b : 0,
	a : 0
};

var WhiteColorOpacity = {
	r : 255,
	g : 255,
	b : 255,
	a : 255
};

var WhiteColorClear = {
	r : 255,
	g : 255,
	b : 255,
	a : 0
};

var MyContentAppNameColor = {
	r:102, 
	g:102, 
	b:102, 
	a:102
};

var IconTitleBarColor = {
	r:50, 
	g:50, 
	b:50, 
	a:50
};

var SubcategoryTextColor = {
	r:20, 
	g:20, 
	b:20, 
	a:50
};

var SubcategoryFocusTextColor = {
	r:0, 
	g:0, 
	b:255, 
	a:255
};

var PlusItemBGColor ={r:0, g:0, b:0, a:0};

var TopIconNum = {
	eTopMin : -1,
	eTopGameNum : 0,
	eTopAppsNum : 1,
	eTopOnTVNum : 2,
	eTopMoiveNum : 3,
	eTopMyContentNum : 4,
	eTopClearNum : 5,
	eTopScheduleNum : 6,
	eTopSearchNum : 7,
	eTopPlusNum : 8,
	eTopMoiveNum : 9,
	eTopsubCategoryParentHeight : 70,
	eToptitleImageWidth : 120,
	eTopIconIntervalX : 122,
	eToptitleImageHeight : 126,
	eTopIconTitleBar : 144,
	eTopSubcategoryNameTxetWidth:160,
	eTopSubcategoryBeginX : 610,
	eTopIconOriginX : 650,
	eTopIconScheduleX : 1554,
};

var colorList = {
	mBlackClear: BlackClear,
	mTopIconNum: TopIconNum,
	mIconTitleBarColor: IconTitleBarColor,
	mWhiteColorOpacity: WhiteColorOpacity,
	mPlusItemBGColor: PlusItemBGColor,
};

var MediaType ={
	MEDIA_VIDEO: 0,
	MEDIA_PHOTO: 1,
	MEDIA_MUSIC: 2,	
	MEDIA_PVR: 3,
	MEDIA_SCSA: 5,
};

var PageStyle = {
	PAGE_STYLE_NONE: 0,
	PAGE_STYLE_ALL_GROUPS: 1,
	PAGE_STYLE_ALL_ITEMS: 2,
	PAGE_STYLE_ALL_ITEMS_NOUPFOLDER: 3,
	PAGE_STYLE_ITEMS_IN_GROUP: 4,
	PAGE_STYLE_ALL: 5,
	PAGE_STYLE_ONE_GROUP_ITS_ITEMS: 6,
	PAGE_STYLE_SEARCH_ITEMS: 7,    
	PAGE_STYLE_ALL_ITEMS_WITH_PLAYLIST: 8, 
	PAGE_STYLE_ALL_ITEMS_NOUPFOLDER_WITH_PLAYLIST: 9,
	PAGE_STYLE_ITEMS_IN_GROUP_WITH_PLAYLIST: 10,
	PAGE_STYLE_ALL_GROUPS_WITH_PLAYLIST: 11,
	PAGE_STYLE_ALL_PLAYLISTS: 12,
	PAGE_STYLE_ALL_GROUPS_AND_ITEMS: 13,
	PAGE_STYLE_MAX : 14,	
};

var CSFSefType = {
	SEF_CSF_EVENT_REQUEST_LIST_SUCCESS: 0,
	SEF_CSF_EVENT_REQUEST_LIST_FAIL: 1,
	SEF_CSF_EVENT_REQUEST_DETAIL_SUCCESS: 2,
	SEF_CSF_EVENT_REQUEST_DETAIL_FAIL: 3,
	SEF_CSF_EVENT_ACT_SUCCESS: 4,
	SEF_CSF_EVENT_ACT_FAIL:  5,
	SEF_CSF_EVENT_DISCONNECT_SUCCESS: 6,
	SEF_CSF_EVENT_DISCONNECT_FAIL: 7,
	SEF_CSF_EVENT_REQUEST_LIST_EMPTY: 8,
	SEF_CSF_EVENT_REQUEST_DETAIL_EMPTY: 9,
	SEF_CSF_EVENT_ACT_PROGRESS_UPDATE: 10,
	SEF_CSF_EVENT_SHARE_DONE: 11,
	SEF_CSF_EVENT_SHARE_COMPLETE: 12,
	SEF_CSF_EVENT_SHARE_FAIL: 13,
	SEF_CSF_EVENT_SHARE_SOURCE_DEVICE_DISCONNECT: 14,
	SEF_CSF_EVENT_SHARE_DEST_DEVICE_DISCONNECT: 15,
	SEF_CSF_EVENT_SHARE_PVR_IS_RECORDING: 16,
	SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED: 17,
	SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED: 18,
	SEF_CSF_EVENT_SHARE_FILE_UPDATE: 19,	
	SEF_CSF_EVENT_RA_DEVICE_CONNECTED: 20,
	SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED: 21,
	SEF_CSF_EVENT_DLNA_DEVICE_CONNECTED: 22,
	SEF_CSF_EVENT_DLNA_DEVICE_DISCONNECTED: 23,
	SEF_CSF_EVENT_DLNA_GET_DEVICE_FINISHED:  24,
	SEF_CSF_EVENT_RA_DEVICE_DISCONNECTED_ALL:25,
	CSF_EVENT_THUMBNAIL_FINISHED : 100,
	CSF_EVENT_THUMBNAIL_FAIL : 101,
	CSF_EVENT_THUMBNAIL_UNKNOW : 102
};
var CSFSourceType = {
	CSF_EX_NONE_ID : 0,
	CSF_EX_PVRUSB_ID : 100,
	CSF_EX_HDD_ID : 101, 
	CSF_EX_USB_ID : 102,
	CSF_EX_PTP_ID : 103,
	CSF_EX_DLNA_ID : 104,
	CSF_EX_SCONNECT_ID : 105,
	CSF_EX_ODD_ID : 106,
	CSF_EX_ODD_CDDA_ID : 107, 
	CSF_EX_ODD_VCD_ID : 108, 
	CSF_EX_ODD_DVD_VIDEO_ID : 109, 
	CSF_EX_ODD_BDROM_ID : 110,
	CSF_EX_ODD_BDRE_ID : 111, 
	CSF_EX_ODD_DATA_ID : 112,
	CSF_EX_IPOD_ID : 113, 
	CSF_EX_PICASA_ID : 114,
	CSF_EX_FACEBOOK_ID : 115,
	CSF_EX_FAMILYSTORY_ID : 116,
	CSF_EX_CLOUDSTORAGE_ID : 117, 
	CSF_EX_NDRIVE_ID : 118,
	CSF_EX_MAX_ID : 119,
};

var csfReturnCode ={
	CSF_ERROR_UNKNOWN : 0,
	CSF_ERROR_INVALID_HANDLE :1,
	CSF_ERROR_INVALID_PARAM : 2,
	CSF_ERROR_INVALID_CURSOR : 3,
	CSF_ERROR_DB_FAIL : 4,
	CSF_ERROR_CACHE_FAIL : 5,
	CSF_ERROR_SERVER : 6,
	CSF_ERROR_NETWORK : 7,
	CSF_ERROR_UNREGISTERED : 8,
	CSF_ERROR_NO_SPACE : 9,
	CSF_ERROR_LIMITED_SIZE : 10,
	CSF_ERROR_DBUS : 11,
	CSF_ERROR_MEM_OVERFLOW : 12,
	CSF_ERROR_ENGINE : 13,
	CSF_OK  : 14,
	CSF_ERROR_DATA_NOT_COMING : 15,
	CSF_ERROR_DATA_EMPTY : 16,
	CSF_ERROR_INVALID_SOURCE_NAME : 17,
	CSF_ERROR_UNEXIST : 18,
	CSF_ERROR_ALREADY_EXIST : 19,
	CSF_ERROR_FAIL_CREATE_THREAD : 20,
};


var EventType ={
	EVENT_TYPE_CATEGORY_CHANGE : 'category-change',
	EVENT_TYPE_VIEW_SELECT_ALL : 'view-select-all',
	EVENT_TYPE_VIEW_DESELECT_ALL : 'view-deselect-all',
	EVENT_TYPE_VIEW_CANCEL_SELECT : 'view-cancel-select',
	EVENT_TYPE_VIEW_PLAY_SELECT : 'view-play-select',
	EVENT_TYPE_VIEW_DELETE_SELECT : 'view-delete-select',
	EVENT_TYPE_VIEW_SEND_SELECT : 'view-send-select',
	EVENT_TYPE_MAIN_VIEW_DIM : 'main-view-dim',
	EVENT_TYPE_MAIN_VIEW_UNDIM : 'main-view-undim',
	EVENT_TYPE_MAIN_VIEW_DIM_OPTION_MENU_1 : 'main-view-dim-option-menu-1',
	EVENT_TYPE_MAIN_VIEW_UNDIM_OPTION_MENU_1 : 'main-view-undim-option-menu-1',
	EVENT_TYPE_SELECT_OPTION_MENU_1 : 'select-option-menu-1',
	EVENT_TYPE_SELECT_OPTION_PLUS : 'select-option-plus',
	EVENT_TYPE_MESSAGE_BOX : 'message-box',
	EVENT_TYPE_BEGIN_REQUEST_DATA : 'begin-request-data',
	EVENT_TYPE_END_REQUEST_DATA : 'end-request-data',
	EVENT_TYPE_FINISH_UPDATE_VIEW_DATA : 'finish-update-view-data',
	EVENT_TYPE_SELECT_HEADER_RETURN: 'select-header-return',
	EVENT_TYPE_FAILE_REQUEST_DATA : 'fail-request-data',
	EVENT_TYPE_HIDE_NO_DATA : 'hide-no-data-text',
	EVENT_TYPE_FOCUS_CHANGE : 'focus-change',
	EVENT_TYPE_SHOW_ROOT_ARROW : 'show-root-arrow',
	EVENT_TYPE_HIDE_ROOT_ARROW : 'hide-root-arrow',
	EVENT_TYPE_SHOW_EXIT_ARROW : 'show-exit-arrow',
	EVENT_TYPE_HIDE_EXIT_ARROW : 'hide-exit-arrow',
	EVENT_TYPE_SHOW_DEVIDE_LINE: 'show-divide-line',
	EVENT_TYPE_HIDE_DEVIDE_LINE: 'hide-divide-line',
	EVENT_TYPE_UPDATE_PROGRESS_BAR_INFO : 'update-progress-bar-info',
	EVENT_TYPE_LONG_PRESS_SHOW_MSG_BOX : 'long-press-show-msg-box',
	EVENT_TYPE_UPDATE_SELECT_LIST_ITEM : 'update-select-list-item',
	EVENT_TYPE_SHOW_MINIBAR : 'show-mini-bar',
	EVENT_TYPE_HIDE_MINIBAR : 'hide-mini-bar',
	EVENT_TYPE_SELECT_MOBILE_PHONE_VIEW: 'select-mobile-phone-view',		
	EVENT_TYPE_CREATE_FOLDER_PATH : 'create-folder-path',	
	EVENT_TYPE_DESTROY_FOLDER_PATH : 'destroy-folder-path',
	EVENT_TYPE_ADD_FOLDER_PATH : 'add-folder-path',	
	EVENT_TYPE_DEL_FOLDER_PATH : 'delete-folder-path',	
	EVENT_TYPE_SHOW_FOLDER_PATH : 'show-folder-path',	
	EVENT_TYPE_HIDE_FOLDER_PATH : 'hide-folder-path',
	EVENT_TYPE_PLAYER_ALL_FILEDONE : 'all-file-done',
	EVENT_TYPE_NOT_AVAILIABLE: 'not-available',
	EVENT_TYPE_DIM_SETTING : 'dim-setting-btn',
	EVENT_TYPE_UNDIM_SETTING: 'undim-setting-btn',
	//EVENT_TYPE_PRESS_RETURN_KEY : 'press-return-key',
	EVENT_TYPE_RETURN_TO_OPTION : 'return-to-option',
	EVENT_TYPE_RESUM_FROM_PLAYER: 'resum-from-player',
	EVENT_TYPE_UNSUPPORT_FILE : 'unsupport-file',	
	EVENT_TYPE_UNFOUND_FILE : 'unfound-file',
	EVENT_TYPE_UPDATE_TOTALTIME: 'update-total-time',
	EVENT_TYPE_UPDATE_CURRENTTIME: 'update-current-time',
	EVENT_TYPE_UPDATE_MUSICINFO: 'update-music-info',
	EVENT_TYPE_EXIT_EDIT_MODE_VIEW: 'exit-edit-mode-view',
	EVENT_TYPE_DES_SELECT_ITEM: 'des_select_item',
	EVENT_TYPE_UPDATE_DEVICE_LIST: 'update_device-list',
	EVENT_TYPE_PLAYER_GETTHUMBNAIL_DONE: 'player-thumbnail-done',
	EVENT_TYPE_PLAYER_GETTHUMBNAIL_FAILD: 'player-thumbnail-failed',
	EVENT_TYPE_PLAY_STATE_CHANGED: 'player-state-changed',
	EVENT_TYPE_ADD_DEVICE: 'add-device',
	EVENT_TYPE_ADD_FIRST_DLNA_DEVICE: 'add-first-dlna-device',
	EVENT_TYPE_UPDATE_DEVICE: 'update-device',
	EVENT_TYPE_DEL_DEVICE: 'delete-device',
	EVENT_TYPE_EDIT_MODE_BTN_FOCUS: 'edit-mode-btn-focus',
	EVENT_TYPE_LOAD_COMMON_CONTROL: 'load-common-control-file',
	EVENT_TYPE_SHOW_SETTING : 'show-setting-btn',
	EVENT_TYPE_HIDE_SETTING: 'hide-setting-btn',
	EVENT_TYPE_MUSICPLAYER_DATA_DONE: 'musicplayer-data-done',
	EVENT_TYPE_MUSICPLAYER_DATA_FAILED: 'musicplayer-data-failed',
	EVENT_TYPE_PLAYBACK_KEY_PRESS: 'playback-key-pressed',
	EVENT_TYPE_RESET:'on-rest',	
	EVENT_TYPE_ON_ACTIVE_DELE_DEVICE:'on-active-delete-device',	
	EVENT_TYPE_MYCONTENT_HALO_CATEGORY_PRESS: 'mycontent-halo-category-press',
	EVENT_TYPE_PRESS_GRIDLIST_ITEM : 'press-gridlist-item',
	EVENT_TYPE_SUSPEND:'on-suspend',	
	EVENT_TYPE_WAKEUP:'on-wakeup',	
	EVENT_TYPE_DISCONNECT_CURRENT_DEVICE:'disconnect-current-device',
	EVENT_TYPE_HIDE_ALL_POPUP:'hide-all-popup',	
	EVENT_TYPE_CONTENT_MGR_INIT:'contentmgr-init',
	EVENT_TYPE_CSF_INIT:'csf-init',
	EVENT_TYPE_SHOW_DEL_PROGRESS_POPUP:'show-del-progress-popup',
	EVENT_TYPE_HIDE_SENDING_POPUP:'hide-sending-popup',
	EVENT_TYPE_UPDATE_DEVICE_LIST:'update-device-list',
	EVENT_TYPE_BACK_TO_MOBIE_VIEW:'back-to-mobile',
	EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE:'set-categoryview-focusable-false',
	EVENT_TYPE_HIDE_MSG_BOX:'hide-message-box',
	EVENT_TYPE_PROGRESS_PRESS:'press-button-progress',
	EVENT_TYPE_EXIT_LONG_PRESS_POPUP:'exit-long-press-popup',
	EVENT_TYPE_KILL_FOCUS:'kill-focus',
	EVENT_TYPE_SHOW_FOCUS:'show-focus',
	EVENT_TYPE_EDIT_DEVICE_CHANGE: 'edit-device-change',
	EVENT_TYPE_SHOW_FILTER_ANIMATION: 'show-filter-animation',
	EVENT_TYPE_SHOW_UNSUPPORT_FORMAT_MSG_BOX: 'show-unsupport-format-msgBox',
	EVENT_TYPE_SHOW_APP_VERSION: 'mycontent-show-app-version',
	EVENT_TYPE_SHOW_DEVICE_INFO: 'mycontent-show-device-info',
	EVENT_TYPE_DIM_MUSICPLAYER: 'mycontent-dim-musicplayer',
	EVENT_TYPE_UNDIM_MUSICPLAYER: 'mycontent-undim-musicplayer',
	EVENT_TYPE_LANGUAGE_CHANGED: 'Language-changed',
	EVENT_TYPE_DIM_HEADVIEW: 'dim-headview',
	EVENT_TYPE_UNDIM_HEADVIEW: 'undim-headview',
	EVENT_TYPE_HIDE_DEVSELECTOR_POPUP: 'hide-devselector-popup',
	EVENT_TYPE_HIDE_INFOWND: 'hide-info-popup',
	EVENT_TYPE_MYCONTENT_KEY_PRESS: 'mycontents-key-press',
	EVENT_TYPE_HIGHCONTRAST_CHANGE: 'highcontrast-change',
	EVENT_TYPE_ENLARGE_CHANGE: 'enlarge-change',
	EVENT_TYPE_CURSOR_SHOW :'cursor-show',
	EVENT_TYPE_CURSOR_HIDE:'cursor-hide',
	EVENT_TYPE_MUSICPLAY_RENDERING: 'music-play-rendering',
	EVENT_TYPE_UPDATE_DEVICE_AVAILABLE_SIZE: 'update-available-size',
	EVENT_TYPE_UPDATE_CUREENT_DEVICE_AVAILABLE_SIZE: 'update-current-available-size',
	EVENT_TYPE_NETWORK_NOT_STABLE:'network-not-stable',
	EVENT_TYPE_CAN_NOT_PLAY:'unknown-error-play-failed-invalid-url',
	EVENT_TYPE_ON_ACTIVE:'on-active',
	EVENT_TYPE_EXIT:'on-exit',	

};

var MyContentOptionType = {
	MYCONTENT_OPTION_TYPE_FILTER: 'COM_SID_FILTER_BY',
	MYCONTENT_OPTION_TYPE_SORT: 'TV_SID_SORT_BY',
	MYCONTENT_OPTION_TYPE_COPY: 'TV_SID_SEND_TO_USB_DRIVE',
	MYCONTENT_OPTION_TYPE_PLAY: 'COM_BDP_SID_TOOL_CDDA_PLAY_SELECTED_TEXT',
	MYCONTENT_OPTION_TYPE_DEL: 'COM_SID_DELETE',
};

var CategoryBannerType = {
	CATEGORY_BANNER_TYPE_DEVICE_LIST : 0,
	CATEGORY_BANNER_TYPE_EDIT_MODE : 1,
};

var CONST={
	MY_CONTENT_APP_COLUMN_NUM: 3,
	MENU_ANIM_DURATION : 200,
	MY_CONTENTS_APP_SUPPORT_COPY : 1214,
	MY_CONTENT_UHD_VIDEO_COLUMN_NUM:2,
};

var LaunchAppID = {	
	APP_ID_PHOTO_PLAYER : 'org.tizen.mycontent-photo-player-tv',
	APP_ID_VIDEO_PLAYER : 'org.tizen.mycontent-video-player-tv',
	APP_ID_PVR_PLAYER 	: 'org.tizen.pvrplayer',
	APP_ID_NETWORK_SETTINGS : 'org.tizen.NetworkSetting-Tizen',
	APP_ID_SPEAKER_SETTING: 'org.tizen.volume-setting',
	APP_ID_HOME_SETTING: 'org.tizen.homesetting',
	APP_ID_VOLUME: 'org.tizen.volume',
	APP_ID_WEBAPP_SERVICE : 'org.tizen.webappservice',
	APP_ID_MLS : 'org.tizen.mls',
};

var LaunchedByAppID = {	
	APP_ID_USB_LAUNCHER : 'org.tizen.usb-launcher-tv',
	APP_ID_SEARCH_ALL: 'org.tizen.search-all',
	APP_ID_SOURCE_LIST: 'org.tizen.source-list',
	APP_ID_PVR_RECORDER: 'org.tizen.pvrrecorder',
	APP_ID_DMR: 'dmr_service_app',
	APP_ID_MLS: 'org.tizen.mls',
	APP_ID_BROWSER: 'org.tizen.browser',
};

var MsgBoxTemplateType = {
	NO_TITLE_ONE_BTN : 0,
	NO_TITLE_TWO_BTN : 1,
	NO_TITLE_THREE_BTN : 2,
	ONE_TITLE_ONE_BTN : 3,
	ONE_TITLE_TWO_BTN : 4,
	ONE_TITLE_THREE_BTN : 5,
	NO_TITLE_NO_BTN : 6,
	NO_TITLE_ONE_BTN_MULTI_MSG: 7,
	NO_TITLE_ONE_BTN_MAGIC : 8,
};

var gridlistID = {
	FOLDERID   : 'FolderItem',
	NOFOLDERID : 'NOFolderItem',
};

var nativeGridlistFocus = {
	NATIVEGRIDMOVEFROM   : 'FromItemFocusChangeAniStart',
	NATIVEGRIDMOVETO : 'ToItemFocusChangeAniStart',
};

var FocusPos = {
	FOCUS_NONE : -1,
	FOCUS_HEADER : 0,
	FOCUS_CATEGORY : 1,
	FOCUS_CONTENT : 2,
};

var CategoryName = {
	CATEGORY_DEVICE : 'Device',
	CATEGORY_DROP_BOX : 'Drop Box',	
	CATEGORY_CONTECT_GUIDE : 'Contect Guide',
	CATEGORY_CLOUD : 'Cloud',
};

var CategoryType = {
	CATEGORY_VIEW : 0,
	EDITMODE_VIEW : 1,
	FOLDER_PATH_VIEW: 2,
};	

var NetworkType = {
	WIRELESS : 0,
	WIRED : 1,
};

var CGFocusPos = {
	FOCUS_NONE : -1,
	FOCUS_MOBILE : 0,
	FOCUS_PC : 1,
	FOCUS_USB : 2, 
};

var DeviceType = {
	DEVICE_TYPE_USB : 'USB',
	DEVICE_TYPE_PTP : 'PTP',	
	DEVICE_TYPE_DLNA : 'DLNA',
	DEVICE_TYPE_RA : 'RA',
};

var SortType = {
	SORT_TYPE_FOLDER :'COM_SID_FOLDER',
	SORT_TYPE_TITLE : 'COM_SID_TITLE',	
	SORT_TYPE_DATE : 'COM_SID_DATE',
	SORT_TYPE_CHANNEL : 'UID_M_M_CHANNEL',
	SORT_TYPE_TRACK : 'COM_BDP_STR_MODE_REPEAT_TRACK_ONE',
	SORT_TYPE_ALBUM : 'COM_SID_ALBUM',
	SORT_TYPE_ARTIST : 'COM_SID_ARTIST',
	SORT_TYPE_GENRE : 'COM_SID_GENRE',
	
};

var UHDRatedStatus = {
	NO_CHECKED:-1,
	FIRST_CHECKED:0,
};

var RatedLevel = {
	R_LEVEL : 'R',
	G_LEVEL : 'G',
	PG_LEVEL : 'PG',
	PG13_LEVEL : 'PG-13',
};
var TTSEventType = {
	FIRST_FOCUS_FOLDER:0,
	MOVE_FOCUS_TO_CONTENT_FOLDER:1,
	MOVE_FOCUS_IN_GRID:2,
};

var UHDTumbnail = {
	Tumbnail : [
	'secuhd10001','secuhd10002','secuhd10003','secuhd10004','secuhd10005',
	'secuhd10006','secuhd10007','secuhd10008','secuhd10009','secuhd10010',
	'secuhd10011','secuhd10012','secuhd10013','secuhd10014','secuhd10015',
	'secuhd10016','secuhd10017','secuhd10018','secuhd10019','secuhd10020',
	'secuhd10021','secuhd10022','secuhd10023','secuhd10024','secuhd10025',
	'secuhd10026','secuhd10027','secuhd10028','secuhd10029','secuhd10030',
	'secuhd10031','secuhd10032','secuhd10033','secuhd10034','secuhd10035',
	'secuhd10036','secuhd10037','secuhd10038','secuhd10039','secuhd10040',
	'secuhd10041','secuhd10042','secuhd10045','secuhd10046','secuhd10047',
	'secuhd10048','secuhd10049','secuhd10050','secuhd10053','secuhd10054',
	'secuhd10055','secuhd10056','secuhd10059',
]};
var CIThumbType = {
    E_THUMB_OK : 0,             /// thumb not influenced by CI+
    E_THUMB_PARTIAL_RETENTION :1,  /// part of content has CI+ retention limit exceeded
    E_THUMB_INVALID : 2,            /// content not valid due to CI+   
};

var MyMagicKey = {
		SHOW_APP_VERSION: '12321',
        REMOVE_THUMBNAIL: '12322',
        SHOW_TIMESTAMP: '12323',
        SHOW_DEVICE_INFO: {
            ALL : '20000',
            DUID : '20001',
            COUNTRY_CODE : '20002',
            SERVER : '20003',
            AGREEPOLICY : '20004'
        }
};

var Config = {
    app_id : '3201412000671',
    app_version : '0.1502022 - 201504302130',
    offical_version : '0.1502022',
};
var DimType = {
	NONE_DIM : 0,
	DEACTIVE_DIM : 1,
	PAUSE_DIM : 2,
	
};
var PvrQuality = {
	DEFINITION_INFO_UNKNOWN : -1,
	DEFINITION_INFO_HD : 0,
	DEFINITION_INFO_SD : 1,
	DEFINITION_INFO_UHD: 2,
};

var ChanelType= {
	CHANNEL_TYPE_UNKNOWN : -1,
	CHANNEL_TYPE_ATV : 1,
	CHANNEL_TYPE_DTV : 2,
	CHANNEL_TYPE_CATV : 3,
	CHANNEL_TYPE_CDTV : 4,
	CHANNEL_TYPE_SDTV : 7,
	CHANNEL_TYPE_MEDIA : 8,
	CHANNEL_TYPE_VIRTUAL : 9,
	CHANNEL_TYPE_MAX : 10,
};
exports.PKGNAME = PKGNAME;
exports.EViewType = EViewType;
exports.EViewSwitchAniType = EViewSwitchAniType;
exports.KeyCode = KeyCode;
exports.EItemType = EItemType;
exports.BlackClear = BlackClear;
exports.MyContentAppNameColor = MyContentAppNameColor;
exports.TopIconNum = TopIconNum;
exports.IconTitleBarColor = IconTitleBarColor;
exports.WhiteColorOpacity = WhiteColorOpacity;
exports.SubcategoryTextColor = SubcategoryTextColor;
exports.WhiteColorClear = WhiteColorClear;
exports.SubcategoryFocusTextColor = SubcategoryFocusTextColor;
exports.colorList = colorList;
exports.MediaType = MediaType;
exports.PageStyle = PageStyle;
exports.CSFSefType = CSFSefType;
exports.EventType = EventType;
exports.CONST = CONST;
exports.CategoryBannerType = CategoryBannerType;
exports.EOptType = EOptType;
exports.PopupType =PopupType;
exports.LaunchAppID =LaunchAppID;
exports.LaunchedByAppID =LaunchedByAppID;
exports.gridlistID =gridlistID;
exports.ProgressPopupType = ProgressPopupType;
exports.CSFSourceType = CSFSourceType;
exports.MsgBoxTemplateType = MsgBoxTemplateType;
exports.FocusPos = FocusPos;
exports.CategoryType = CategoryType;
exports.NetworkType = NetworkType;
exports.MyContentOptionType = MyContentOptionType;
exports.CGFocusPos = CGFocusPos;
exports.nativeGridlistFocus = nativeGridlistFocus;
exports.DeviceType = DeviceType;
exports.SortType = SortType;
exports.CategoryName = CategoryName;
exports.RatedLevel = RatedLevel;
exports.TTSEventType = TTSEventType;
exports.MessageType = MessageType;
exports.csfReturnCode = csfReturnCode;
exports.UHDTumbnail = UHDTumbnail;
exports.CIThumbType = CIThumbType;
exports.MyMagicKey = MyMagicKey;
exports.Config = Config;
exports.DimType = DimType;
exports.PvrQuality = PvrQuality;
exports.ChanelType = ChanelType;