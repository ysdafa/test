var KPI = Volt.require('lib/volt-kpi.js');
var CommonInfo = Volt.require('app/common/define.js');
var EItemType = CommonInfo.EItemType;
var Config = CommonInfo.Config;

function KPIMapper() {

    var flagKPI = false;

    //mapper event name and category,
    //left value is a custom name to enhance readability
    //e is event name
    //c is category name
    var CATEGORY_MAPPER = {

		'MY_CONNECTION_GUIDE_PG': {e:'CG_HOME',c:'PG001'},
		'MY_DEVICE_PG': {e:'B_HOME',c:'PG002'},
		'MY_MUSIC_PG': {e:'MP_HOME',c:'PG003'},
		'MY_UHD_HOME_PG': {e:'UHD_HOME',c:'PG004'},

		'MY_SELECT_GUIDE_MOBILE': {e:'SELECT',c:'EV001'},
		//'MY_SELECT_GUIDE_PC': {e:'SELECT',c:'EV002'},
		'MY_SELECT_GUIDE_USB': {e:'SELECT',c:'EV003'},
		'MY_EXIT_GUIDE_MOBILE': {e:'EXIT',c:'EV004'},
		//'MY_EXIT_GUIDE_PC': {e:'EXIT',c:'EV005'},
		'MY_EXIT_GUIDE_USB': {e:'EXIT',c:'EV006'},
		'MY_ENTER_GUIDE_PG': {e:'ENTER',c:'EV007'},
		'MY_CONNECT_DEVICE': {e:'CONNECTDEVICE',c:'EV008'},
		'MY_SELECT_OPTIONS': {e:'SELECTOPTIONS',c:'EV009'},
		'MY_CONTENTS_DLNA': {e:'SELECTCONTENTS',c:'EV010'},
		//'MY_CONTENTS_MOBILE': {e:'SELECTCONTENTS',c:'EV011'},
		//'MY_CONTENTS_PC': {e:'SELECTCONTENTS',c:'EV012'},
		'MY_CONTENTS_USB': {e:'SELECTCONTENTS',c:'EV013'},
		'MY_OPTION_FILTER': {e:'FILTER',c:'EV014'},
		'MY_OPTION_SORT_IN_PV': {e:'SORT',c:'EV015'},//onSelectOptionPlus
		'MY_OPTION_SORT_IN_MUSIC': {e:'SORT',c:'EV016'},
		'MY_OPTION_SORT_IN_PVR': {e:'SORT',c:'EV017'},
		'MY_OPTION_SELECT_PLAY': {e:'PLAYSELECTED',c:'EV018'},
		'MY_OPTION_DELETE_IN_PVR': {e:'DELETE',c:'EV019'},
		//'MY_OPTION_DS': {e:'DEVICESETTING',c:'EV020'},
		//'MY_OPTION_TUTORIAL': {e:'TUTORIAL',c:'EV021'},
		//'MY_OPTION_DS_DCM': {e:'DEVICESETTING',c:'EV022'},
		//'MY_OPTION_TUTORIAL_DCM': {e:'TUTORIAL',c:'EV023'},
		'MY_OPTION_FILTER_DCM': {e:'FILTER',c:'EV024'},
		//'MY_OPTION_SORT_IN_PV_DCM': {e:'SORT',c:'EV025'},
		//'MY_OPTION_SORT_IN_MUSIC_DCM': {e:'SORT',c:'EV026'},
		'MY_OPTION_SELECT_PLAY_IN_DCM': {e:'SORT',c:'EV027'},
		
		'MY_MUSIC_PLAYER_SPEAKER': {e:'SELECT',c:'EV028'},
		//'MY_MUSIC_PLAYER_SHUFFLE': {e:'',c:'EV029'},
		'MY_MUSIC_PLAYER_SHUFFLE': {e:'SELECT',c:'EV030'},
		'MY_MUSIC_PLAYER_REPEAT': {e:'SELECT',c:'EV031'},
		'MY_VIDEO_PG_ENTER': {e:'H13_VIDEOPLAYER',c:'EV032'},//
		'MY_VIDEO_PG_EXIT': {e:'VIDEOPLAYEREXIT',c:'EV033'},//resetFocusFromPlayer
		'MY_VIDEO_PG_OPTIONT': {e:'OPTIONVP',c:'EV034'},
		'MY_PHOTO_PG_ENTER': {e:'H14_PHOTOPLAYER',c:'EV035'},
		'MY_PHOTO_PG_EXIT': {e:'PHOTOPLAYEREXIT',c:'EV036'},
		'MY_PHOTO_PG_OPTIONT': {e:'OPTIONPP',c:'EV037'},

		//'MY_OPTION_RESET': {e:'RESET',c:'EV040'},//new Browser Home(Record log when you select 'Reset Rating' option after filtering by Photo, Video)
		'MY_SELECT_GUIDE_SHOWFILES': {e:'SELECT',c:'EV043'},
		'MY_MUSIC_OFF': {e:'SELECT',c:'EV044'},
		'MY_MUSIC_PREVIOUS': {e:'SELECT',c:'EV045'},
		'MY_MUSIC_PLAY_PAUSE': {e:'SELECT',c:'EV046'},
		'MY_MUSIC_NEXT': {e:'SELECT',c:'EV047'},
		'MY_CONTENT_UPPERFORDER': {e:'SELECT',c:'EV048'},
		'MY_CONTENT_DELETE': {e:'SELECT',c:'EV049'},
		'MY_CONTENT_INFO_POPUP': {e:'SELECT',c:'EV050'},
		
		'MY_OPTION_SELECT': {e:'SELECT',c:'EV051'},
		'MY_OPTION_DELETE': {e:'SELECT',c:'EV052'},
		'MY_OPTION_SENDUSB': {e:'SELECT',c:'EV053'},
    };

    /**init kpi function 	 
    * @name init	 
    * @memberOf KPIMapper
    * @method 	 
    * */
    this.init = function () {
    	var DeviceModel = Volt.require("app/models/device-model-kpi.js");
        KPI.init({
            serviceName: 'mycontent',
            modelId: DeviceModel.get('modelId'),
            uid: ' ',
            duid: DeviceModel.get('duid'),
            countryCode: DeviceModel.get('countryCode'),
            version: CommonInfo.Config.app_version,
            configFallbackPath: 'app/common/LogPolicyConfig.xml',
            debug: true
        });
        flagKPI = true;      
    };

    /**add event log to kpi server	 
    * @name addEventLog	 
    * @memberOf KPIMapper
    * @method 	 
    * */
    this.addEventLog = function (customName, pOptions) {
        print('[kpi-mapper-mycontents.js]addEventLog - ' + customName);
        if(flagKPI == false){
            this.init();
        }
        var options = pOptions || {};
        options['c'] = CATEGORY_MAPPER[customName].c;
        
        options['d'] = pOptions ? pOptions['d'] :{};
		options['d']['sappid'] = 'org.volt.mycontents';		
		options['d']['sappver'] = Config.offical_version;	
		
        KPI.add(CATEGORY_MAPPER[customName].e, options);
    };

	
	var selectDeviceType =  null;
	var startVideoTime =  null;
	var startPhotoTime =  null;
	var endTime =  null;

	/**add enter log to kpi server	 
    * @name addEnterLog	 
    * @memberOf KPIMapper
    * @method 	 
    * */
	this.addEnterLog = function (customName, deviceType) {
	 	print('[kpi-mapper-mycontents.js]addEnterLog - ' + customName + ' deviceType'+deviceType);
        if(flagKPI == false){
            this.init();
        }
		if(customName =='MY_PHOTO_PG_ENTER'){
			startPhotoTime = VDUtil.getSessionTime(); //new Date();
			print(' startPhotoTime:' + startPhotoTime);
		}
		else if(customName =='MY_VIDEO_PG_ENTER'){
			startVideoTime = VDUtil.getSessionTime(); //new Date();
			print(' startPhotoTime:' + startPhotoTime);
		}
		
        var options = {
			d: {
                pp : 'MyContent',
				device : deviceType,
            }
		};
        options['c'] = CATEGORY_MAPPER[customName].c;
        KPI.add(CATEGORY_MAPPER[customName].e,options);
		selectDeviceType = deviceType;
		
    };

	/**add exit log to kpi server	 
    * @name addExitLog	 
    * @memberOf KPIMapper
    * @method 	 
    * */
	this.addExitLog = function (customName) {
        if(flagKPI == false){
            this.init();
        }
		endTime = VDUtil.getSessionTime(); //new Date();
        print('[kpi-mapper-mycontents.js]addExitVideoLog - ' + customName + ' endTime:' + endTime);
		var pgType = '';
		var duration = 0;
		
		if(customName == 'MY_PHOTO_PG_EXIT'){
			if(startPhotoTime == null){
				 print('it not enter photo player before, return ');
				 return;
			}
			duration = parseInt((endTime - startPhotoTime) / 1000, 10);
			pgType = 'photo';
			startPhotoTime = null;
		}
		else if(customName == 'MY_VIDEO_PG_EXIT'){
			if(startVideoTime == null){
				 print('it not enter video player before, return ');
				 return;
			}
			duration = parseInt((endTime - startVideoTime) / 1000, 10);
			pgType = 'video';
			startVideoTime = null;
		}
        var options = {
			d: {
                pp : 'MyContent',
				type: pgType,
				device: selectDeviceType,
				du: duration,
            }
		};
        options['c'] = CATEGORY_MAPPER[customName].c;		
        KPI.add(CATEGORY_MAPPER[customName].e,options);
    };

    var PreviousApp = null;
    
    /**set previous app when app initial	 
    * @name addEventLog	 
    * @memberOf KPIMapper
    * @method 	 
    * */
    this.setPreviousApp = function (onPreviousApp) {
        print('[kpi-mapper-mycontents.js]setPreviousApp - ' + onPreviousApp);
        PreviousApp = onPreviousApp;
    };
    
    /**get previous app 	 
    * @name getPreviousApp	 
    * @memberOf KPIMapper
    * @method 	 
    * */
    this.getPreviousApp = function () {
        print('[kpi-mapper-mycontents.js]getPreviousApp - ' + PreviousApp);
        return PreviousApp ;
    }; 

	/**get device type for KPI	 
    * @name getDeviceType	 
    * @memberOf KPIMapper
    * @method 	 
    * */
	this.getDeviceType = function (eDeviceType){
	
		var CommonInfo = Volt.require("app/common/define.js");
		var DeviceType = CommonInfo.DeviceType;
		var detail = '';

		if(eDeviceType === DeviceType.DEVICE_TYPE_DLNA){
			detail = 'MY_CONTENTS_DLNA';
			
		}
		/*
		else if(eDeviceType === DeviceType.DEVICE_TYPE_RA){
			detail = 'MY_CONTENTS_MOBILE';
		}
		*/
		/*
		else if(eDeviceType === DeviceType.DEVICE_TYPE_RA){
			detail = 'MY_CONTENTS_PC';
		}  */	
		
		else if(eDeviceType === DeviceType.DEVICE_TYPE_USB){
			detail = 'MY_CONTENTS_USB';
		}
		else {
			detail = 'MY_CONTENTS_USB';
		}
        print('[kpi-mapper-mycontents.js]getDeviceType - ' + detail);
        return detail ;
    };

    var lastPage = null;
    
    /** send event when enter a page	 
    * @name enterPage	 
    * @memberOf KPIMapper
    * @method 	 
    * */
    //startPage, endPage
    this.enterPage = function (customName, pOptions) {
        if(flagKPI == false){
            this.init();
        }
        var options = pOptions || {};
        var pageName = CATEGORY_MAPPER[customName].e;
        var category = CATEGORY_MAPPER[customName].c;
        options['c'] = category;

        if (lastPage != null) {
            if (lastPage.customName != customName) {
                this.leavePage(lastPage.customName, lastPage.options);
            } else {
                print('[kpi-mapper-mycontents.js] This page is already entered!' + CATEGORY_MAPPER[lastPage.customName].e);
                return;
            }
        }

		options['d'] = {};
        if (lastPage != null) {
            options['d']['pp'] = CATEGORY_MAPPER[lastPage.customName].e;
            print('[kpi-mapper-mycontents.js] Last Page : ' + options.d.pp);
        }
		options['d']['sappid'] = 'org.volt.mycontents';
		options['d']['sappver'] = Config.offical_version;	
	
        KPI.startPage(pageName, options);
        lastPage = {
            customName: customName,
            options: options
        };
    };

     /** send event when leave a page	 
    * @name leavePage	 
    * @memberOf KPIMapper
    * @method 	 
    * */
    this.leavePage = function (customName, pOptions) {
        if(flagKPI == false){
            this.init();
        }
        var pageName,
            cartegory,
            options;

        if (customName && CATEGORY_MAPPER[customName]) { //target Page
            pageName = CATEGORY_MAPPER[customName].e;
            options = pOptions || {};
            options['c'] = CATEGORY_MAPPER[customName].c;
        } else { //Last Page
            if (lastPage) {
                pageName = CATEGORY_MAPPER[lastPage.customName].e;
                options = pOptions || {};
                options['c'] = CATEGORY_MAPPER[customName].c;
            }
        }

        if (pageName) {
            KPI.endPage(pageName, options);
            lastPage = null;
        } else {
            print('[kpi-mapper-mycontents.js] There is no page event to be leave');
        }
    };

    this.changeUID = function () {
        if(flagKPI == false){
            this.init();
        }
        KPI.changeUID(KPI.getUID());
    };

    this.getEvent = function (customName) {
        return CATEGORY_MAPPER[customName].e;
    };
    
    this.getCategory = function (customName) {
        return CATEGORY_MAPPER[customName].c;
    };

	this.getItemType = function(itemType){
		var type = 'CT01';
		switch(itemType){
			case EItemType.eItemPhoto:
				type = 'CT01';
				break;
			case EItemType.eItemMusic:
				type = 'CT02';
				break;
			case EItemType.eItemVideo:
				type = 'CT03';
				break;
			case EItemType.eItemUHDVideo:
				type = 'CT04';
				break;
			case EItemType.eItemPvr:
				type = 'CT05';
				break;
			default:
				break;
		}
		return type;
	}
}

exports = new KPIMapper();

