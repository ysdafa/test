/*device name*/
var CategoriesName = ['Device', 'Drop Box','Contect Guide','Cloud'];
var resMgr = Volt.require('app/controller/resource-controller.js');
/*All/Video/Photo/Music View Filter text list
because the All/Photo/Music view Filter text is same as Video*/
var VideoFilterTextList = {
	"DeviceTypeTextList":[],
	"DropBoxTypeTextList":[],
	"ContectGuideTextTypeList":[],
	"CloudTypeTextList":[],
	"DeviceDLNATextList":[],
	"DeviceTypeNoRecordTextList":[],
	"DropBoxTypeNoRecordTextList":[],
	"CloudTypeNoRecordTextList":[],
};

/*USB Device Filter text*/
VideoFilterTextList.DeviceTypeTextList = [
								'UID_FILTER_ALL',
								'COM_SID_PHOTOS',
								'COM_SID_VIDEOS',
								'COM_TV_SID_MUSIC',
								'COM_RECORDED_KR_CONTENT',
							 ];
/*USB Device No Record Filter text*/
VideoFilterTextList.DeviceTypeNoRecordTextList = [
								'UID_FILTER_ALL',
								'COM_SID_PHOTOS',
								'COM_SID_VIDEOS',
								'COM_TV_SID_MUSIC',
							 ];
/*DropBox Filter text*/
VideoFilterTextList.DropBoxTypeTextList = [
								'UID_FILTER_ALL',
								'COM_SID_PHOTOS',
								'COM_SID_VIDEOS',
								'COM_TV_SID_MUSIC',
								'COM_RECORDED_KR_CONTENT',
							 ];
/*DropBox No Record Filter text*/
VideoFilterTextList.DropBoxTypeNoRecordTextList = [
								'UID_FILTER_ALL',
								'COM_SID_PHOTOS',
								'COM_SID_VIDEOS',
								'COM_TV_SID_MUSIC',
							 ];

/*DLNA Filter text*/
VideoFilterTextList.DeviceDLNATextList = [
								'UID_FILTER_ALL',
								'COM_SID_PHOTOS',
								'COM_SID_VIDEOS',
								'COM_TV_SID_MUSIC',
								'COM_RECORDED_KR_CONTENT'
							 ];

VideoFilterTextList.ContectGuideTextTypeList = VideoFilterTextList.DeviceTypeTextList;
VideoFilterTextList.CloudTypeTextList = VideoFilterTextList.DeviceTypeTextList;
VideoFilterTextList.CloudTypeNoRecordTextList = VideoFilterTextList.DeviceTypeNoRecordTextList;

/*Video/Photo View Sort text list*/
var VideoSortByTextList = {
	"DeviceTypeTextList":[],
	"DropBoxTypeTextList":[],
	"ContectGuideTypeTextList":[],
	"CloudTypeTextList":[],
};

VideoSortByTextList.DeviceTypeTextList = [
								'COM_SID_DATE',
								'COM_SID_TITLE',
								'COM_SID_FOLDER',
							 ];
VideoSortByTextList.DropBoxTypeTextList = VideoSortByTextList.DeviceTypeTextList;
VideoSortByTextList.ContectGuideTypeTextList = VideoSortByTextList.DeviceTypeTextList;
VideoSortByTextList.CloudTypeTextList = VideoSortByTextList.DeviceTypeTextList;

/*Music and All view sort text is different the Video/Photo text*/
var AllSortByTextList = {
	"DeviceTypeTextList":[],
	"DropBoxTypeTextList":[],
	"ContectGuideTypeTextList":[],
	"CloudTypeTextList":[],
};
AllSortByTextList.DeviceTypeTextList = [
                                 'COM_SID_FOLDER',
							 ];
AllSortByTextList.DropBoxTypeTextList = AllSortByTextList.DeviceTypeTextList;
AllSortByTextList.ContectGuideTypeTextList = AllSortByTextList.DeviceTypeTextList;
AllSortByTextList.CloudTypeTextList = AllSortByTextList.DeviceTypeTextList;

/*Music View Sort text list*/
var MusicSortByTextList = {
	"DeviceTypeTextList":[],
	"DropBoxTypeTextList":[],
	"ContectGuideTypeTextList":[],
	"CloudTypeTextList":[],
};
MusicSortByTextList.DeviceTypeTextList = [
								'COM_SID_DATE',
								'COM_BDP_STR_MODE_REPEAT_TRACK_ONE',
								'COM_SID_ALBUM',
								'COM_SID_ARTIST',
                                'COM_SID_GENRE',
								'COM_SID_FOLDER',
							 ];
MusicSortByTextList.DropBoxTypeTextList = MusicSortByTextList.DeviceTypeTextList;
MusicSortByTextList.ContectGuideTypeTextList = MusicSortByTextList.DeviceTypeTextList;
MusicSortByTextList.CloudTypeTextList = MusicSortByTextList.DeviceTypeTextList;


/*Record View Sort text list*/
var RecordSortByTextList = {
	"DeviceTypeTextList":[],
	"DropBoxTypeTextList":[],
	"ContectGuideTypeTextList":[],
	"CloudTypeTextList":[],
};
RecordSortByTextList.DeviceTypeTextList = [
								'COM_SID_DATE',
								'COM_SID_TITLE',
								'UID_M_M_CHANNEL',
								'COM_SID_FOLDER',
							 ];
RecordSortByTextList.DropBoxTypeTextList = RecordSortByTextList.DeviceTypeTextList;
RecordSortByTextList.ContectGuideTypeTextList = RecordSortByTextList.DeviceTypeTextList;
RecordSortByTextList.CloudTypeTextList = RecordSortByTextList.DeviceTypeTextList;

exports.CategoriesName = CategoriesName;
exports.VideoFilterTextList = VideoFilterTextList;
exports.VideoSortByTextList = VideoSortByTextList;
exports.AllSortByTextList   = AllSortByTextList;
exports.MusicSortByTextList = MusicSortByTextList;
exports.RecordSortByTextList = RecordSortByTextList;
