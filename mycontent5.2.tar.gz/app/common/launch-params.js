 /** 
 * @author  Li Hailong (hailong08.li@samsung.com)
 * 			
 * @fileoverview  launcher params object
 * @date    2014/08/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var CommonInfo = Volt.require("app/common/define.js");
var LaunchedByAppID = CommonInfo.LaunchedByAppID;
var DeviceType = CommonInfo.DeviceType;

var LaunchParams = function() {
	print('[LaunchParams]--------------------initlize ');
	this.calledAppName = '';
	this.firstUsed = true;
	this.specificPathUseStatus = false;
	//usb-launcher-tv pass params
	this.deviceMountPath = null;
	this.specificPath = null;
	this.deviceName = '';
	this.contentType = '';
	this.device_busnumber = '';
	this.device_addressnumber = '';
	this.deviceType = '';
	this.dlnaDevieId = '';
	
	//search all pass params
	this.music_url ='';
	this.music_title = '';
	this.music_artist='';
	this.music_album = '';
	this.music_thumb = '';
	this.music_genre = '';
	this.music_filesize = '';

	//dmr pass params
	this.dmrDbusChannel = '';
	this.playerInstanceId = '';
	this.dmrStartPos = 0;
	this.music_format = '';
	
	//souce list pass params
	this.getLauncherAppName = function(){
		return this.calledAppName;
	};
	this.getDLNADeviceId = function(){
		return this.dlnaDevieId;
	};
	this.getFirstUsedStatus= function(){
		return this.firstUsed;
	};	

	this.setFirstUsedStatus = function(status){
		this.firstUsed = status;
	};
	this.getDeviceMountPath = function(){
		print('[launcher-params] [getDeviceMountPath] MountPath ',this.deviceMountPath);
		return this.deviceMountPath;
	};
	this.getDeviceType = function(){
		return this.deviceType;
	}
	
	this.getDeviceAddress = function(){
		return this.device_addressnumber;
	}

	this.getThumbnailUrl = function(){
		return this.music_thumb;
	}

	this.getDmrStartPos = function(){
		return this.dmrStartPos;
	}

	this.isLaunchForMusicPlayer = function(){
		Log.f("isLaunchForMusicPlayer launchParams.getLauncherAppName()="+ launchParams.getLauncherAppName() + " this.music_url= "+ this.music_url);
		if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR || launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_SEARCH_ALL){
			return true;
		}
		if( launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_USB_LAUNCHER ){
			//need add more for play usb media file directly
			if( this.music_url == '' || this.music_url == undefined ){
				return false;
			}
			return true;
		}
		if( launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_BROWSER ){
			//need add more for play usb media file directly
			if( this.music_url == '' || this.music_url == undefined ){
				return false;
			}
			return true;
		}	
		Log.f('[launch-params.js]---this.isLaunchForMusicPlayer---- to return false---');
		return false;
	};
	this.getSubFolderUseStatus = function(){
		return this.specificPathUseStatus;
	};
	this.setSubFolderUseStatus = function(useStatus){
		this.specificPathUseStatus = useStatus;
	};
	
	this.getLastSepcialFolder = function(){
		print("getLastSepcialFolder  lastFolder:");
		var lastFolder = '';
		if(this.specificPath == null || this.specificPath == undefined){
			return null;
		}
		var index = this.specificPath.lastIndexOf('/');
		if(index == -1){
			lastFolder = this.specificPath;
			this.specificPath = '';
		}else{
			lastFolder = this.specificPath.substring(index+1,this.specificPath.length);
			print("getLastSepcialFolder  lastFolder:"+ lastFolder);
		
			this.specificPath = this.specificPath.substring(0,index);
			print("getLastSepcialFolder  this.specificPath:" + this.specificPath);
		}
		return lastFolder;
	};
	
	this.getSubFolder = function(){
		return this.specificPath;
	};
	this.resetSubFolder = function(){
		this.specificPath = '';
	};
	this.getDeviceBus = function(){
		return this.device_busnumber;
	};
	
	this.getDLNADeviceId = function(){
		return this.dlnaDevieId;
	};
	
	this.setParams = function(params){
		
		print('[launcher-params] [setParams]  params.device_path ',params.device_path);

		
		this.calledAppName = params.called_app;
		
		//usb-launcher-tv pass params
		this.deviceMountPath =  params.device_path;
		this.specificPath = params.specific_path;		
	//	this.specificPath = 'download/music/1/browser';
		if(this.specificPath != null && this.specificPath != ''){
			this.specificPathUseStatus = false;
		}
		this.deviceName = params.device_name;
		this.contentType = params.content_type;
		this.device_busnumber = params.device_busnumber;
		this.device_addressnumber = params.device_addressnumber;
		print('[launcher-params] [setParams]  this.deviceMountPath ',this.deviceMountPath);
		//search all pass params
		this.music_url = params.music_url;
		this.music_title = params.music_title; 
		
		this.music_artist = params.music_artist;
		this.music_album = params.music_album;
		this.dlnaDevieId = params.device_id;
		this.deviceType = params.device_type;
		this.music_thumb = params.music_thumbnail;
		Volt.log('[launch-params.js]---setParams---params.genre is ' + params.genre + ' params.fileSize is ' + params.fileSize);
		this.music_genre = params.genre;
		this.music_filesize =  params.fileSize;

		if( this.music_thumb=='' || this.music_thumb==undefined ){
			this.music_thumb = params.music_url;
		}
		if( this.music_genre=='' || this.music_genre==undefined ){
			this.music_genre = '-';
		}
				
		
		if( this.calledAppName=='dmr_service_app' ){
			this.music_url = params.uri;
			this.music_title = params.title;
			
			this.music_artist = params.artist;
			this.music_album = params.album;	

			this.deviceType = DeviceType.DEVICE_TYPE_DLNA;

			this.dmrDbusChannel = params.dmrDbusChannel;
			this.playerInstanceId = params.playerInstanceId;
			this.music_thumb = params.thumbnailUri;
			this.dmrStartPos = params.startingTimePosition / 1000;
		}
		var musicFormat = '-';

	    if(this.music_url != ''
	   	&& this.music_url != null 
	   	&& this.music_url != undefined)
	   	{
		    if(this.calledAppName == LaunchedByAppID.APP_ID_DMR 
				|| (this.calledAppName == LaunchedByAppID.APP_ID_SEARCH_ALL && this.deviceType == 'DLNA')){
		    	
				var wholeIndex = this.music_url.length;
				var AfterFormat = -9;
				AfterFormat = this.music_url.indexOf('/I');
				var index = this.music_url.indexOf('P$');
				if (index+2 < wholeIndex)
				{
					musicFormat = this.music_url.substring(index+2,AfterFormat)!=''?this.music_url.substring(index+2,AfterFormat):'-';
				}
	    	}else if(this.calledAppName == LaunchedByAppID.APP_ID_USB_LAUNCHER
	    	      ||(this.calledAppName == LaunchedByAppID.APP_ID_SEARCH_ALL && this.deviceType == 'USB')){

				  var index = this.music_url.lastIndexOf('.');
				  musicFormat = this.music_url.substring(index+1, this.music_url.length);
	    	}
	   	}
	
		this.music_format  = musicFormat
		
	};
	
	this.resetParams = function(){
		this.calledAppName = '';
		
		//usb-launcher-tv pass params
		this.deviceMountPath = '';
		this.specificPath = '';
		this.deviceName = '';
		this.contentType = '';
		this.device_busnumber = '';
		this.device_addressnumber = '';
	
		//search all pass params
		this.music_url ='';
		this.music_title = '';
		this.music_artist='';
		this.music_album = '';
		this.deviceType = '';
		this.music_thumb = '';
		//dmr pass params
		this.dmrDbusChannel = '';
		this.playerInstanceId = '';		
		this.dmrStartPos = 0;
		this.music_format = '';
		this.music_genre = '';
		this.music_filesize =  '';
	};
	
	this.printParam = function(){
		print('*************** params start ******************');
		print('***************called_app :',this.calledAppName);
		print('***************device_path :',this.deviceMountPath);
		print('***************specificPath :',this.specificPath);
		print('***************device_name :',this.deviceName);
		print('***************content_type :',this.contentType);		
		print('***************device_busnumber :', this.device_busnumber);
		print('***************device_addressnumber :',this.device_addressnumber);
		print('***************dlnaDevieID :',this.dlnaDevieId);	
		print('***************deviceType :',this.deviceType);	

		print('***************music_url :',this.music_url);
		print('***************music_title :',this.music_title);
		print('***************music_artist :',this.music_artist);
		print('***************music_album :',this.music_album);			
		print('***************music_thumb :',this.music_thumb);

		print('***************dmrDbusChannel :', this.dmrDbusChannel);
		print('***************playerInstanceId :', this.playerInstanceId);		
		print('***************dmrStartPos:', this.dmrStartPos);
		print('***************genre:', this.dmrStartPos);
		print('***************music_filesize:', this.music_filesize);
		print('***************music_format:',this.music_format);
		print('***************params end******************');
	}
};

var launchParams = new LaunchParams();
exports = launchParams;