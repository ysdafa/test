 /** 
 * @author  Li Hailong (hailong08.li@samsung.com)		
 * 			
 * @fileoverview  
 * @date    2014/10/22 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var voiceGuide = {
	play: function(text){
		print('TTS  play >>>>>>>  text: ', text);
		Log.e("TTS  play >>>>>>>  text: "+text);
		//add voice guide
		TTS.setText(text);
		TTS.play();
	},
	
	
	queuingPlay:function(text){
		print('TTS  queuingPlay >>>>>>>  text: ', text);
		Log.e("TTS  queuingPlay >>>>>>>  text: " + text);
		TTS.queuingPlay(text);
	}
};

exports = voiceGuide;