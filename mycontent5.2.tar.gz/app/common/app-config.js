var voltApi = Volt.require('voltapi.js');

var AppConfig = function(){
	this.key = 'db/mycontents/playerInfo';
	this.value = '';
	this.valueObj = null;
	this.shuffleMode = 'false';
	this.repeatMode = 'off';
	this.filterType = '';
	this.videoSortType = '';
	this.musicSortType = '';
	this.photoSortType = '';
	this.pvrSortType = '';
	this.uhdTerm = 'true';
	this.uhdUnblockRate = 'G';
	this.pinFirstShow = 'true';
	this.updateContent = 'false';
	voltApi.device.init();

	this.getSWVersion = function(){
		print('getSWVersion');	
		var chipset = voltApi.device.getSWVersion();
		print('chipset version:' + chipset);
		Log.e('chipset version:' + chipset);
		var tempVer = [];
		var board = '';
		if(chipset != undefined ){
			tempVer = chipset.split('-')
		}
		if(tempVer[1] != undefined){
			board = tempVer[1].toUpperCase();
		}
		print('board kind: '+ board);
		return board;
	};

	
	this.parse = function(){
		try{
			this.value = Vconf.getValue(this.key);
			valueObj = JSON.parse(this.value);
			print("vconf value is ", valueObj);
			this.shuffleMode = valueObj.shuffleMode;
			this.repeatMode = valueObj.repeatMode;
			this.filterType = valueObj.filterType;
			this.videoSortType = valueObj.videoSortType;
			this.musicSortType = valueObj.musicSortType;
			this.photoSortType = valueObj.photoSortType;
			this.pvrSortType = valueObj.pvrSortType;
			this.uhdTerm = valueObj.uhdTerm;
			this.uhdUnblockRate = valueObj.uhdUnblockRate;
			this.pinFirstShow = valueObj.pinFirstShow;
			this.updateContent = valueObj.updateContent;
			return true;
		}
		catch(e){
			print("false to parse");
			return false;
		}
	};
	
	this.save = function(){
		try{
			var obj = {
				shuffleMode : this.shuffleMode,
				repeatMode : this.repeatMode,
				filterType : this.filterType,
				videoSortType : this.videoSortType,
				musicSortType : this.musicSortType,
				photoSortType : this.photoSortType,
				pvrSortType : this.pvrSortType,
				uhdTerm     : this.uhdTerm,
				uhdUnblockRate : this.uhdUnblockRate,
				pinFirstShow : this.pinFirstShow,
				updateContent: this.updateContent,
			};
			var strValue = JSON.stringify(obj);
			Vconf.setValue(this.key, strValue);
			return true;
		}
		catch(e){
			return false;
		}
	};
	
	this.getMusicShuffleMode = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.shuffleMode;
	};
	
	this.setMusicShuffleMode = function(shuffleMode){
		var preValue = this.shuffleMode;
		this.shuffleMode = shuffleMode;
		if(!this.save()){
			this.shuffleMode = preValue;
			return false;
		}
		return true;
	};
	
	this.getMusicRepeatMode = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.repeatMode;
	};
	
	this.setMusicRepeatMode = function(repeatMode){
		var preValue = this.repeatMode;
		this.repeatMode = repeatMode;
		if(!this.save()){
			this.repeatMode = preValue;
			return false;
		}
		return true;
	};
	
	this.getFilterType = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.filterType;
	};
	
	this.setFilterType = function(filterType){
		var preValue = this.filterType;
		this.filterType = filterType;
		if(!this.save()){
			this.filterType = preValue;
			return false;
		}
		return true;
	};
	
	this.getVideoSortType = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.videoSortType;
	};
	
	this.setVideoSortType = function(videoSortType){
		var preValue = this.videoSortType;
		this.videoSortType = videoSortType;
		if(!this.save()){
			this.videoSortType = preValue;
			return false;
		}
		return true;
	};
	
	this.getMusicSortType = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.musicSortType;
	};
	
	this.setMusicSortType = function(musicSortType){
		var preValue = this.musicSortType;
		this.musicSortType = musicSortType;
		if(!this.save()){
			this.musicSortType = preValue;
			return false;
		}
		return true;
	};
	
	this.getPhotoSortType = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.photoSortType;
	};
	
	this.setPhotoSortType = function(photoSortType){
		var preValue = this.photoSortType;
		this.photoSortType = photoSortType;
		if(!this.save()){
			this.photoSortType = preValue;
			return false;
		}
		return true;
	};
	this.getUhdTerm = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.uhdTerm;
	};
	this.setUhdTerm = function(uhdTerm){
		var preValue = this.uhdTerm;
		this.uhdTerm = uhdTerm;
		if(!this.save()){
			this.uhdTerm = preValue;
			return false;
		}
		return true;
	};
	this.getUhdUnblockRate = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.uhdUnblockRate;
	};

	this.setUhdUnblockRate = function(uhdUnblockRate){
		var preValue = this.uhdUnblockRate;
		this.uhdUnblockRate = uhdUnblockRate;
		if(!this.save()){
			this.uhdUnblockRate = preValue;
			return false;
		}
		return true;
	};
	this.getPinFirstShowFlag = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.pinFirstShow;
	};
	this.setPinFirstShowFlag = function(pinFirstFlag){
		var preValue = this.pinFirstShow;
		this.pinFirstShow = pinFirstFlag;
		if(!this.save()){
			this.pinFirstShow = preValue;
			return false;
		}
		return true;
	};
	this.getUpdateContentFlag = function(forceParse){
		if(forceParse){
			this.parse();
		}
		
		return this.updateContent;
	};
	this.setUpdateContentFlag = function(updateContentFlag){
		print(" setUpdateContentFlag updateContentFlag:"+updateContentFlag);
		var preValue = this.updateContent;
		this.updateContent = updateContentFlag;
		if(!this.save()){
			this.updateContent = preValue;
			return false;
		}
		return true;
	};
};

var appConfig = new AppConfig();

exports = appConfig;
