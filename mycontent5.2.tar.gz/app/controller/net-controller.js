 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Connect mobile device guide view
 * @date    2014/08/17 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

//var voltapi = require("voltapi");
var voltapi = Volt.require('voltapi.js');
//var voltapi = Volt.require("modules/voltapi.js");
var CommonInfo = Volt.require("app/common/define.js");
var NetworkType = CommonInfo.NetworkType;
var self = null;
var that = null;

var NetController = function(){
	that = this;
	this.wiredState = false;
	this.wirelessState = false;
	this.networkListeners = [];
	this.listenerContexts = [];
	
	print('[net-controller]onGetNetworkInfo-------init');
	voltapi.network.init();
	print('[net-controller]onGetNetworkInfo-------getAvailableNetworks');
	voltapi.network.getAvailableNetworks(onGetNetworkInfo, onGetNetworkFailed);

	this.getCurrentWiredState = function(){
		print(" net-controller  getCurrentWiredState  ");
		var result = voltapi.network.checkGateway(1);
		print("net-controller  getCurrentWiredState result:" + result);
		Log.e("net-controller  getCurrentWiredState result:" + result);

		if(result == 1){
			return true;
		}
		
		return false;	
	};

	this.getCurrentWirelessState = function(){
		print(" net-controller  getCurrentWirelessState  ");
		var result = voltapi.network.checkGateway(0);
		
		print("net-controller  getCurrentWirelessState result:"+result);
		Log.e("net-controller  getCurrentWirelessState result:"+result);
		
		if(result == 1){
			return true;
		}
		
		return false;	
	};
	/**  get network WiredState
	* @name getWiredState	 
	* @memberOf NetController		
	* @method */
	this.getWiredState = function(){
		// hijack : voltapi.network.checkPhysicalConnection(1)
//		this.wiredState = (voltapi.network.checkPhysicalConnection(1) <= 0) ? false : true;	
		print("getWiredState : "+  this.wiredState);
		Log.e("getWiredState : "+  this.wiredState);
		return this.wiredState;
	};
	/**  get network getWirelessState
	* @name getWirelessState	 
	* @memberOf NetController		
	* @method */
	this.getWirelessState = function(){
		// hijack : voltapi.network.checkPhysicalConnection(0)
//		this.wirelessState = (voltapi.network.checkPhysicalConnection(0) <= 0) ? false : true;		
		print("getWirelessState : " +  this.wirelessState);
		Log.e("getWirelessState : " +  this.wirelessState);
		
		return this.wirelessState;
	};
	/**  get network registerListener
	* @name registerListener	 
	* @memberOf NetController
	*@param {listener} listener
	* @parm {context} context		
	* @method */
	this.registerListener = function(listener, context){
		this.networkListeners.push(listener);
		this.listenerContexts.push(context);
		return ;
	};
	/**  get network unregisterListener
	* @name unregisterListener	 
	* @memberOf NetController
	* @param {listener} listener
	* @parm {context} context		
	* @method */
	 this.unregisterListener = function(listener, context) {
	 	print('[net-controller.js]----unregisterListener');
		for (var i = 0; i < this.networkListeners.length; i++){
			if(this.networkListeners[i] === listener){
				print('[net-controller.js]----this.networkListeners[i] === listener');
				this.networkListeners.splice(i,1);
				this.listenerContexts.splice(i,1);
			
			}

		}
	};
	

	/**  get network notifyListener
	* @name notifyListener	 
	* @memberOf NetController
	* @param {networkType} networkType
	* @parm {connectFlag} connectFlag		
	* @method */
	
	this.notifyListener = function(networkType, connectFlag){
		print('[net-controller]notifyListener-------------network listener number : ' + this.networkListeners.length);
		for(var i = 0; i < this.networkListeners.length; i++){
			this.networkListeners[i].call(this.listenerContexts[i], networkType, connectFlag);
		}
	};
	
	this.onWatchListenerError = function(error){
		print("[net-controller]Error occured while watching network : " + error);
	}
	
	this.close = function(){
		print("Close network function~~~~~~~~~~~");
		voltapi.network.destroy();
		
	};	
};

var onGetNetworkInfo = function(networks){
	Log.e("onGetNetworkInfo >>> networks.length:"+networks.length);
	
	if(networks.length < 2){
		print('[net-controller]onGetNetworkInfo-------networks length < 2');
		Log.e("[net-controller]onGetNetworkInfo-------networks length < 2");
		return ;
	}
	
	/* 0 - wireless, 1 - wired */
	if(networks[0].isActive()){
		print('[net-controller]onGetNetworkInfo-------networks[0].isActive() == true');
		Log.e("[net-controller]onGetNetworkInfo-------networks[0].isActive() == true");
		that.wirelessState = true;
	}
	else{
		print('[net-controller]onGetNetworkInfo-------networks[0].isActive() == false');
		Log.e("[net-controller]onGetNetworkInfo-------networks[0].isActive() == false");
		that.wirelessState = false;
	}
	
	if(networks[1].isActive()){
		print('[net-controller]onGetNetworkInfo-------networks[1].isActive() == true');
		Log.e("[net-controller]onGetNetworkInfo-------networks[1].isActive() == true");
		that.wiredState = true;
	}
	else{
		print('[net-controller]onGetNetworkInfo-------networks[1].isActive() == false');
		Log.e("[net-controller]onGetNetworkInfo-------networks[1].isActive() == false");
		that.wiredState = false;
	}
	
	/* set network watch */
	networks[0].setWatchListener(new WirelessNetworkWatch(that), that.onWatchListenerError);
	networks[1].setWatchListener(new WiredNetworkWatch(that), that.onWatchListenerError);
};
	
var onGetNetworkFailed = function(networks){
	Log.e("onGetNetworkFailed >>> networks:" + networks);
	Log.e("[net-controller]onGetNetworkFailed-------get network information failed");

	/* set network watch */
	networks[0].setWatchListener(new WirelessNetworkWatch(that), that.onWatchListenerError);
	networks[1].setWatchListener(new WiredNetworkWatch(that), that.onWatchListenerError);
};

	/**  get network notifyListener
	* @name WiredNetworkWatch	 
	* @memberOf NetController
	* @param {watchHost} watchHost		
	* @method */

function WiredNetworkWatch(watchHost) {
	this.host = watchHost; 
	Log.e("Register WiredNetworkWatch");
	this.onconnect= function (status) {
		print('[WiredNetworkWatch]onconnect--------------wired network connect');
		Log.e("[WiredNetworkWatch]onconnect--------------wired network connect");
		this.host.wiredState = true;
		this.host.notifyListener(NetworkType.WIRED, true);
		
	};

	this.ondisconnect = function (status) {
		print('[WiredNetworkWatch]ondisconnect--------------wired network disconnect');
		Log.e("[WiredNetworkWatch]ondisconnect--------------wired network disconnect");
		this.host.notifyListener(NetworkType.WIRED, false);
		this.host.wiredState = false;
	};
};
	/**  get network notifyListener
	* @name WirelessNetworkWatch	 
	* @memberOf NetController
	* @param {watchHost} watchHost		
	* @method */
function WirelessNetworkWatch(watchHost) {
	this.host = watchHost; 
	Log.e("Register WirelessNetworkWatch");
	this.onconnect= function (status) {
		print('[WirelessNetworkWatch]onconnect-------------- network connect');
		Log.e("[WirelessNetworkWatch]onconnect-------------- network connect");
		this.host.wirelessState = true;
		this.host.notifyListener(NetworkType.WIRELESS, true);
		
	};

	this.ondisconnect = function (status) {
		print('[WirelessNetworkWatch]ondisconnect-------------- network disconnect');
		Log.e('[WirelessNetworkWatch]ondisconnect-------------- network disconnect');
		this.host.notifyListener(NetworkType.WIRELESS, false);
		this.host.wirelessState = false;
	};
};

var netController = new NetController();

exports = netController;


