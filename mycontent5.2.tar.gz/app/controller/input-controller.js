/**
 * @author guanhao
 */

var InputController = function(){
	
	this.blockFlag = false;
	
	this.blockInput = function(){
		this.blockFlag = true;
	};
	
	this.unblockInput = function(){
		this.blockFlag = false;
	};
	
	this.getBlockFlag = function(){
		return this.blockFlag;
	};
};

var inputController = new InputController();
exports = inputController;
