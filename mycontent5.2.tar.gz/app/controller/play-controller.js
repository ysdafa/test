 /** 
 * @author  Hu Po (pual.hu@samsung.com)
 * 			 
 * @fileoverview  Model controller
 * @date    2014/07/22 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

//var voltapi = Volt.require('modules/voltapi.js');
var voltapi = Volt.require('voltapi.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var ContentBaseCollection = Volt.require("app/models/content-base-collection.js");
var MusicPlayerCollection = Volt.require("app/models/music-player-collection.js");
var MusicModel = Volt.require('app/models/music-model.js');
var PlayerIndexMgr = Volt.require('app/models/player-index-manager.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var CommonInfo = Volt.require("app/common/define.js");
var EItemType = CommonInfo.EItemType;
var EventType = CommonInfo.EventType;
var MediaType = CommonInfo.MediaType;
var CSFSourceType = CommonInfo.CSFSourceType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var EViewType = CommonInfo.EViewType;
var launchParams = Volt.require("app/common/launch-params.js");
var LaunchedByAppID = CommonInfo.LaunchedByAppID;
var appLaunch = Volt.require('app/controller/app-launch.js');
var DeviceType = CommonInfo.DeviceType;
var resMgr = Volt.require('app/controller/resource-controller.js');
var appConfig = Volt.require("app/common/app-config.js");
var self = null;
var THUMB_BASE_PATH = resMgr.getThumbPath();

var playController = function() {
	this.instance = null;
	this.uriSet = false;
//	this.dataBuf = null;
	this.idxGetter = null;
	this.isPlaying = false; 
	this.totalTime = 0;
	this.currTime = 0,
	this.collection = null,
	this.idxMap = [],
	this.thumbState = [],
	this.deviceID = -1,
	this.deviceType = -1,
	this.contentIdx = -1,
	this.startIdx = -1,
	this.startId = "";
	this.csfApi = null,
	this.source = -1,
	this.volumeValue = 0,
	this.musicPlayerFocus = false;
	this.dataCollection = null;
	this.contentAgent = null;
	this.csfInitOk = false;
	this.storeThumbList = -1;
	this.seekEnable = true;
	this.initOk = false;
	this.storePlayData = [];
	this.unSupportNum = [];
	this.setTUNESource = false;
	this.initTUNEStatus = false;
	self = this;

    this.repeatMode = 'off';
    this.shuffleMode = 'false';
	
	this.getTUNEStatus = function(){
		print("getTUNEInitStatus this.setTUNESource:"+this.setTUNESource);
		Log.e("getTUNEInitStatus this.setTUNESource:"+this.setTUNESource);
		return this.setTUNESource;
	},
	this.setTUNEStatus = function(flag){
		print("getTUNEInitStatus flag:"+flag);
		Log.e("getTUNEInitStatus flag:"+flag);
		this.setTUNESource = flag;
	},
	this.getInitTUNEStatus = function(){
		print("getTUNEInitStatus this.getInitTUNEStatus:"+this.initTUNEStatus);
		Log.e("getTUNEInitStatus this.getInitTUNEStatus:"+this.initTUNEStatus);
		return this.initTUNEStatus;
	},
	/**init the play controller 	 
	* @name init	 
	* @memberOf playController	 	
	* @method 	 */	
	this.init = function() {
		Log.e("[play-controller.js] init player performance");
		Volt.log("[play-controller.js] init player performance");
		
		
		voltapi.TUNE.initAsync(function () {
	        print("[play-controller.js] init player voltapi.TUNE.init OK");
			Log.e("[play-controller.js] init player voltapi.TUNE.init OK");
			self.initTUNEStatus = true;
			
			if(Vconf.getValue('memory/mycontents/status') == 'on'){
				print("[play-controller.js] 'memory/mycontents/status' is on ");	
				if(self.setTUNESource == false){
					print("[play-controller.js] init setTUNESource ");
					Log.e("[play-controller.js] init setTUNESource ");
			        try{
			            voltapi.TUNE.setAppInfo("org.volt.mycontents");
			        }
			        catch (ex){
			            Log.f("[play-controller.js][init] setAppInfo Error: " + ex);        // added by dy0518.kim
			        }
					
			        voltapi.TUNE.disconnectSource();
			        voltapi.TUNE.setSource(voltapi.TUNE.PL_WINDOW_SOURCE_MEDIA);
					self.setTUNESource = true;
				}
			}else{
				print("[play-controller.js] init mycontent is deactive do not call setTUNESource");
				Log.e("[play-controller.js] init mycontent is deactive do not call setTUNESource");
			}
       });

		this.instance = voltapi.player.getPlayer();
//		voltapi.audio.init();
		this.instance.initAsync({
			bufferingCallback: {
				onbufferingstart : function(){
					Log.f("[play-controller.js]-----------------> onBufferingStart");
					print("[play-controller.js]-----------------> onBufferingStart");
				},
		    	onbufferingcomplete : function(){
		    		Log.f("[play-controller.js]-----------------> onbufferingCallback");
					print("[play-controller.js]-----------------> onbufferingCallback");
		     	},
		     	onbufferingprogress : function(){
		     		Log.f("-----------------> onBufferingProgress");
					print("[play-controller.js]-----------------> onBufferingProgress");
		     	},
		     	onstreaminfoready : function(){
					Log.f("[play-controller.js]-----------------> onstreaminfoready");
					Volt.log('-----------------> onstreaminfoready');
					self.asyncPlay();
		     	},
		     	onrenderingstart : function(){
			     	var playTime = new Date();
					Log.f("[play-controller.js]--------onrenderingstart---------> onrenderingstart: " + playTime.getTime());
					Volt.log("[play-controller.js]--------onrenderingstart---------> onrenderingstart: " + playTime.getTime());
						
					//if the song is unsupport before, bt it is okay current now, need to set PLAYED_COUNT status
					var idx = self.getCurrentIdx();
					var item = self.dataCollection.at(idx);
					if(!launchParams.isLaunchForMusicPlayer()){
						if( self.getValue( idx, 'PLAYED_COUNT' ) == -1 )
						{
							Volt.log('[play-controller.js]---onrenderingstart---getValue is -1---and need to set 0--');
							self.setValue( idx, 'PLAYED_COUNT', 0 );
							item.set('playavail', 0);
						}
					}

					
					//EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);

					
					self.isPlaying = true;
					self.seekEnable = true;
					self.playBegin();	
					self.updateListThumbnail();
		     	},		     	
		    },
		    playCallback: {
		    	oncurrentplaytime : function( param ){
					Log.f("[play-controller.js]--------oncurrentplaytime--------param  is " + param);
					//Volt.log("[play-controller.js]--------oncurrentplaytime--------param  is " + param);
					self.timeEventFn(param);
					//EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
		    	},
		    	onstreamcompleted : function(){
		    		Log.f("[play-controller.js]-----------------> onStreamComplete");
					Volt.log("[play-controller.js]-----------------> onStreamComplete");
					if (RunTimeInfo.bFlagForInforBox)
					{
						EventMediator.trigger(EventType.EVENT_HIDE_INFORMATION);
						RunTimeInfo.bFlagForInforBox = false;	
					}
					
					if( self.idxGetter==null ){
						return;
					}
					self.isPlaying = false;
					if(self.idxGetter.moveNext(false) == true){
        				self.play(0);				
					}
					else{
						Log.f('all file done!');
						RunTimeInfo.playState = 0;
						EventMediator.trigger(EventType.EVENT_TYPE_PLAYER_ALL_FILEDONE, 3);
					}					
		    	},
		    	onseekcompleted : function(){
		    		Log.f("-----------------> onSeekComplete");
		    		self.seekComplete();
		    	},
		    	onRederingError : function(){
		    		Log.f("-----------------> onRederingError");
		    	},
		    	onerror : function( para ) {
					Log.f('-----------------> onerror: ' + para);
			//		Volt.log('[play-controller.js]------onerror-- and will trigger to update the list----para is ' + para);
			/*		
					EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_MUSICINFO, self.getCurrentIdx());
			*/		
					if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
					{
						Volt.log('[play-controller.js]-----onerror---CurrentPlayLoading is not null, to stop----');
						Volt.require("app/common/run-time-info.js").CurrentPlayLoading.stop();				
					}		
					
					self.updateListThumbnail();
					
					if (para == "UNKNOWN_ERROR"  || para == "PLAY_FAILED" || para == "INVALID_URI")
					{
						RunTimeInfo.msgType = 'CANNOT_PLAY';
						EventMediator.trigger(EventType.EVENT_TYPE_CAN_NOT_PLAY);//
						return;
					}
					else if( para == "NOT_FOUND_ERR"){
						RunTimeInfo.msgType = 'NOT_FOUND';
						EventMediator.trigger(EventType.EVENT_TYPE_UNFOUND_FILE);			
						return;
					}
					else if (para == "NOT_STABLE")
					{
						RunTimeInfo.msgType = 'NOT_STABLE';
						EventMediator.trigger(EventType.EVENT_TYPE_NETWORK_NOT_STABLE);			
						return;
					}
					
					var idx = self.getCurrentIdx();
					//Volt.log('[play-controller.js]---onerror---idx is ' + idx);
					self.setValue( idx, 'PLAYED_COUNT', -1 );
					self.idxGetter.setCurrentItemNonePlayable();
					Volt.log('[play-controller.js]-----to trigger the EventType.EVENT_TYPE_UNSUPPORT_FILE and idx is ' + idx);
					RunTimeInfo.notSupportSong = true;
					EventMediator.trigger(EventType.EVENT_TYPE_UNSUPPORT_FILE, idx);					
		    	},
		    	onasmpause : function() {
		    		Log.f('-----------------> onasmpause');
					if(RunTimeInfo.playState == 1){
						print('RunTimeInfo.playState == 1, try to pause the music playing');	
						EventMediator.trigger(EventType.EVENT_TYPE_DIM_MUSICPLAYER);
						self.pause(null);
					}					
		    	},
		    	onasmresume : function() {
		    		Log.f('-----------------> onasmresume');
					if(RunTimeInfo.playState == 1){
						print('RunTimeInfo.playState == 1, try to resume the music playing');		
						EventMediator.trigger(EventType.EVENT_TYPE_UNDIM_MUSICPLAYER);
						try
						{
							self.resume(null);
						}
						catch(e)
						{
							self.resume('appResume');
						}
						
					}					
		    	},
		    	onsoundanalysis : function(para) {
					Log.f('-----------------> onsoundanalysis' + para);
		    	},
		    },
			displayRect: {	// SRect instance [init()]
			     top: 100,
			     left : 100,
			     width : 200,
			     height : 200
		     },
		     autoRatio: true,
		}, self.onPlayerInit);

		var DeviceProvider = Volt.require("app/models/device-provider.js");
		if( DeviceProvider.getDeviceList() != null && DeviceProvider.getDeviceList().csfInit == true ){
			self.csfInitOk = true;
		}

//		this.instance.setAppID('org.volt.mycontents','111477001204');
		this.dataCollection = new MusicPlayerCollection();
		EventMediator.on(EventType.EVENT_TYPE_CSF_INIT, this.onCsfInit, this);	
		this.getRepeatMode(true);
		this.getShuffleMode(true);
		Log.e("[play-controller.js] init player finish performance");
	},

	this.onCsfInit = function() {
		Log.f("receive the EVENT_TYPE_CSF_INIT event");
		self.csfInitOk = true;
		if( self.storeThumbList!= -1 ){
			self.askThumbnail(self.storeThumbList);
		}
	},
	
	this.onPlayerInit = function( res ) {
        Log.f("onPlayerInit "+ res + "!!");
		Volt.log('[play-controller.js]----this onPlayerInit---res is ' + res);
        if( res == true ){
            try{
               		self.instance.setAppInfo("org.volt.mycontents");  
               }
               catch (ex){
                    Log.f("[play-controller.js][onPlayerInit] setAppInfo Error: " + ex); 
					Volt.log("[play-controller.js][onPlayerInit] setAppInfo Error: " + ex);
               }

			   try
			   	{
			   		self.instance.initPlayer("preloading");
			   	}
			   catch(ex)
			   	{
                    Log.f("[play-controller.js][onPlayerInit] initPlayer Error: " + ex); 
					Volt.log("[play-controller.js][onPlayerInit] initPlayer Error: " + ex);			   	
			   	}

               self.initOk = true;
               voltapi.player.setPlayerType(voltapi.player.PLAYER_TYPE_MUSIC);
               if(self.storePlayData.length != 0 ){
                   self.realPlay(self.storePlayData[0], self.storePlayData[1]);
                   self.storePlayData = [];
               }
         }
    },

	/**reset the play controller 	 
	* @name reset	 
	* @memberOf playController	 	
	* @method 	 */		
	this.reset = function() {

		if( this.isPlaying == true ){
			this.stop();
		}

		RunTimeInfo.playState = 0;
		
		this.dataCollection.reset();
//		this.dataCollection.disConnect();
		this.contentAgent = null;
		this.storeThumbList = -1;
		this.idxMap = [];		
		this.thumbState = [];
		this.startIdx = -1;
		if( this.idxGetter!= null ){
			this.idxGetter.resetManager();
		}
	};

	/**reset the play index manager 	 
	* @name indexReset	 
	* @param {currentIdx} current play index		
	* @memberOf playController	 	
	* @method 	 */	
	this.indexReset = function() {
		var opt = {
			curIdx: this.startIdx,
			totalCount: this.dataCollection.size(), 
			repeatCB: this.getRepeatMode,
			shuffleCB: this.getShuffleMode,			
		};

		for( i = 0; i < this.dataCollection.size(); ++i ){
			this.thumbState[i] = -1;
		}

		this.idxGetter = new PlayerIndexMgr();
		this.idxGetter.create( opt );	

	};

	this.requestData = function( args ){
		if( this.dataCollection != null ){
			this.dataCollection.requestList(args);
		}
	};

	/**set the current playing device id 	 
	* @name setDeviceID	 
	* @param {id} current play device id	
	* @memberOf playController	 	
	* @method 	 */	
	this.setDeviceID =  function( id ) {
		this.deviceID = id;
		Log.f("this.deviceID = " + id);
		
		var DeviceProvider = Volt.require("app/models/device-provider.js");
		var deviceInfo = DeviceProvider.getDeviceInfo(this.deviceID);
		if( deviceInfo == null ){
			Log.f("can\'t get the device for id= " + id);
			this.deviceType = launchParams.getDeviceType();
		}
		else{
			this.deviceType = deviceInfo.get('type');
		}

		switch(this.deviceType){
			case DeviceType.DEVICE_TYPE_USB:
				this.source = CSFSourceType.CSF_EX_USB_ID;
				break;			
			case DeviceType.DEVICE_TYPE_DLNA:
				this.source = CSFSourceType.CSF_EX_FACEBOOK_ID;
				break;
			case DeviceType.DEVICE_TYPE_PTP:
				this.source = CSFSourceType.CSF_EX_PTP_ID;
				break;	
			default:
				break;
		}	
	};

	/**get the current playing device id 	 
	* @name getDeviceID	 
	* @memberOf playController	 	
	* @method 	 */	
	this.getDeviceID =  function() {
		return this.deviceID;
	};

	/**set the flag of content view set focus by music player	 
	* @name setMusicPlayerFocus	 
	* @param {arg} the value of flag		
	* @memberOf playController	 	
	* @method 	 */	
	this.setMusicPlayerFocus = function( arg ) {
		this.musicPlayerFocus = arg;
	};

	/**get the flag of content view set focus by music player	 
	* @name getMusicPlayerFocus	 	
	* @memberOf playController	 	
	* @method 	 */	
	this.getMusicPlayerFocus = function() {
		return this.musicPlayerFocus;
	};

	this.setStartIdx = function( idx ){
		this.startIdx = idx;
	};

	this.setStartContentID = function( id ) {
		print("setStartContentID id:"+id);
		this.startId = id;
	};

	/**insert the music model into playController's collection
	* @name insertModel	 
	* @param {model} music model	
	* @param {idx} map index
	* @memberOf playController	 	
	* @method 	 */		
	this.insertModel = function(model, idx) {
		if( this.dataCollection != null ){
			this.dataCollection.push(model);
			this.idxMap[this.dataCollection.size()-1] = idx;
		}
	};

	this.insertMap = function(musicIdx,contIdx) {
		this.idxMap[musicIdx] = contIdx;
	};

	/**insert the music data into playController's collection
	* @name insertData	 
	* @param {opt} music model	
	* @param {idx} map index
	* @memberOf playController	 	
	* @method 	 */	
	this.insertData = function(opt) {
		var musicModel = new MusicModel();
		musicModel.parse(opt);

		if( this.dataCollection != null ){
			this.dataCollection.push(musicModel);
		}		
	};

	/**get the music model
	* @name getData	 
	* @param {idx} music file index
	* @memberOf playController	 	
	* @method 	 */
	this.getData = function( idx ){
	   	var itemModel = this.dataCollection.at(idx);
    	if( itemModel == null ){
    		Log.f("self.collection.at(idx)==null");
    		return null;
    	}	
		return itemModel;
	};

	this.setAgent = function( agent ){
		self.contentAgent = agent;
	};

	/**get the music field from CSF
	* @name getValue	 
	* @param {idx} music file index
	* @param {eType} field type	
	* @memberOf playController	 	
	* @method 	 */
	this.getValue = function( idx, eType ){
		var reqIdx = idx;
		if( self.idxMap.length != 0 )
		{
			reqIdx = self.idxMap[idx];
			if( self.contentAgent!= null ){
				return self.contentAgent.getItemValue(reqIdx,eType);
			}
			return null;
		}
		if( this.dataCollection != null ){
			if( eType=='ARTIST' ){
				print('Artist of idx = ', reqIdx, 'from csf is ', this.dataCollection.getItemValue(reqIdx, eType));
			}
			return this.dataCollection.getItemValue(reqIdx, eType);
		}	
		return null;
	};

	this.getRealValue = function( idx, eType ){
		var reqIdx = idx;
		if( this.dataCollection != null ){
			if( eType=='ARTIST' ){
				print('Artist of idx = ', reqIdx, 'from csf is ', this.dataCollection.getItemValue(reqIdx, eType));
			}
			return this.dataCollection.getItemValue(reqIdx, eType);
		}	
		return null;
	};	

	/**set the music field from CSF
	* @name setValue	 
	* @param {idx} music file index
	* @param {eType} field type	
	* @param {value} field value		
	* @memberOf playController	 	
	* @method 	 */
	this.setValue = function( idx, eType, value ){
		if( this.dataCollection != null ){
			return this.dataCollection.setItemValue(idx, eType, value);
		}	
		return null;
	};
	
	/**get collection size
	* @name getSize	 	
	* @memberOf playController	 	
	* @method 	 */
	this.getSize = function() {
		return self.dataCollection.size();
	};

	/**get current playing index
	* @name getCurrentIdx	 	
	* @memberOf playController	 	
	* @method 	 */
	this.getCurrentIdx = function() {
		print("play control getCurrentIdx  ");
		if( this.instance == null || this.idxGetter == null ){
			Log.f("this.instance== null || this.idxGetter == null");
			return -1;
		}

		var retIdx = this.idxGetter.getCurrentIndex();
		if( retIdx == -1 ){
			var index = self.dataCollection.getPageIndex(self.startId);
			Log.f("self.dataCollection.getPageIndex is "+index+ "for content id is " + self.startId);
			this.idxGetter.setCurrentIndex(index);
			retIdx = index;
		}
		
		return retIdx;
	},

	this.getCurrentContentId = function() {
		var idx = this.idxGetter.getCurrentIndex();
		var id = self.dataCollection.getItemValue(idx, 'CSF_MEDIA_FOCUS_ID');	
		return id;
	},

	this.getPreIdx = function() {
		if( this.instance == null || this.idxGetter == null ){
			Log.f("this.instance== null || this.idxGetter == null");
			return -1;
		}
		
		return this.idxGetter.getPreIndex();
	},

	/**get current playing index in content view
	* @name getMapCurrentIdx	 	
	* @memberOf playController	 	
	* @method 	 */
	this.getMapCurrentIdx = function() {
		var currIdx = this.getCurrentIdx();
		return this.idxMap[currIdx];
	}

	/**get the music file info, like title/artist/album/thumbnail
	* @name getItemData
	* @param {idx} music file index		
	* @memberOf playController	 	
	* @method 	 */
	this.getItemData = function(idx, askThumbFlag) {
		Volt.log('[play-controller.js]----getItemData---idx is ' + idx);
		var requestIdx = idx;

		if( requestIdx==undefined){
			requestIdx = self.getCurrentIdx();
		}
	
	   	var itemModel = this.dataCollection.at(requestIdx);
    	if( itemModel == null ){
    		Log.f("self.collection.at(idx)==null, idx ="+requestIdx+" size is "+self.dataCollection.size() );
    		return null;
    	}

		if( itemModel.get('title1')=='' || itemModel.get('title1')==undefined){
			Log.f("have not get this data, try to get it from csf");
			self.dataCollection.getItemList(idx,1);
		}		

		var thumbPath = resMgr.getImgPath() + '/default_thumb/mc_playlist_thumbnail_album_default.PNG';
	    if( self.thumbState[requestIdx] == 1 ){
			thumbPath = THUMB_BASE_PATH + 'Player' + requestIdx + '.jpg';
	    }
		else if( self.thumbState[requestIdx] == 0 ){
			thumbPath = resMgr.getImgPath() + '/default_thumb/mc_playlist_thumbnail_album_default.PNG';
		}
		else{
			if( askThumbFlag != false ){
				self.askThumbnail(requestIdx);
			}
		}

		var titleStr = itemModel.get('title1');
		if( titleStr==null || titleStr==''){
			Log.f("get title from csf error!!");
			titleStr = resMgr.getText('COM_SID_UNKNOWN');
		}

		var artistStr = '';
		var albumStr = '';	
		var itemAvail = true;

		artistStr = itemModel.get('artist');
		if(artistStr == '' || artistStr == 'Unknown') {
			artistStr = resMgr.getText('COM_SID_UNKNOWN');
		}
		albumStr  = itemModel.get('album');
		if(albumStr == '' || albumStr == 'Unknown'){
			albumStr = resMgr.getText('COM_SID_UNKNOWN');
		}
		
		if( self.idxMap.length != 0 ) {
			itemAvail = self.getValue( idx, 'PLAYED_COUNT' ) == -1 ? false: true;
		}
		else{
			itemAvail = itemModel.get('playavail')==0 ? true:false;  
		}
		var data = {
			title: titleStr,
			artist: String(artistStr),
			album: String(albumStr),
			thumb: thumbPath,
			avail: itemAvail,
		};		

		return data;
	},

	this.checkHDAudioSupport = function( idx ){
		if( launchParams.isLaunchForMusicPlayer()){
			return false;
		}

		var returnValue = Vconf.getValue('db/sound/hd-audio');		//check Menu/Sound/Additional Settings/HD Audio at first
		var JsonData = null;
		Log.f("Vconf.getValue(db/sound/hd-audio) return value: " + returnValue);
		try{
			JsonData = JSON.parse(returnValue);		
		} catch (e) {
			Log.f("**************-------------Vconf exception------------*********");
			return false;
		}
		if(JsonData !== undefined && JsonData !== null){
			Log.f("JsonData = " + JsonData);
		}
		else{
			return false;
		}

		if( JsonData == '0' ){
			return false;
		}
		
		var sampleRate = this.getRealValue( idx, 'SAMPLERATE' );
		var bitRes = this.getRealValue( idx, 'BIT_RESOLUTION' );

		Log.f("sampleRate for idx: " + idx + " is " + sampleRate);
		Log.f("bitRes for idx: " + idx + " is " + bitRes);

		if( sampleRate==null || bitRes==null){
			return false;
		}

		if( sampleRate>48000 && bitRes>16 ){
			return true;
		}
		return false;
	},

	this.getMusicDetail = function( index ){
		var musicDetail = {
			title: '',
			duration: '',
			lastSaveDate: '',
			size: '',
			filepath: '',
			genre: '',
			format: '',
			artist:'',
			album:'',
			location: '',
		};
		if(launchParams.isLaunchForMusicPlayer()){
			musicDetail.title = launchParams.music_title;
			musicDetail.duration = this.getDuration();
			musicDetail.filepath = launchParams.music_url;
			musicDetail.artist = launchParams.music_artist;
			musicDetail.album = launchParams.music_album;
			musicDetail.genre = launchParams.music_genre;
			musicDetail.lastSaveDate = null;
			musicDetail.format = launchParams.music_format;///????
			musicDetail.size = launchParams.music_filesize;
			var posFlag = musicDetail.filepath.substring(0,4);
			Log.f('the posFlag is' + posFlag)
			if( posFlag == '/opt' ){
				musicDetail.location = 'USB';
			}
			else if( posFlag == 'http' ){
				musicDetail.location = resMgr.getText('SID_UNKNOWN_DEVICE'); //'DLNA';
			}
			else{
				musicDetail.location = '-';
			}
		}
		else{
			var musicData = self.dataCollection.getMusicDetail(index);
			musicDetail.title = musicData.get('title');
			musicDetail.displayName = musicData.get('displayName');
			musicDetail.duration = musicData.get('duration');
			musicDetail.lastSaveDate = musicData.get('lastSaveDate');
			musicDetail.size = musicData.get('size');
			musicDetail.filepath = musicData.get('filepath');
			musicDetail.artist = musicData.get('artist');
			musicDetail.album =  musicData.get('album');

			musicDetail.genre = musicData.get('genre');
			musicDetail.format = musicData.get('format');
			if( musicDetail.genre == null || musicDetail.genre == '' || musicDetail.genre == undefined){
			//	musicDetail.genre = resMgr.getText('COM_SID_UNKNOWN');
				musicDetail.genre = '-';
			}
			if( musicDetail.artist == null || musicDetail.artist == '' || musicDetail.artist == undefined){
			//	musicDetail.genre = resMgr.getText('COM_SID_UNKNOWN');
				musicDetail.artist = '-';
			}
			if( musicDetail.album == null || musicDetail.album == '' || musicDetail.album == undefined){
			//	musicDetail.genre = resMgr.getText('COM_SID_UNKNOWN');
				musicDetail.album = '-';
			}
			musicDetail.location = musicData.get('location')
		}
		return musicDetail;
	},

	/**request thumbnail for music index
	* @name askThumbnail
	* @param {index} music file index		
	* @memberOf playController	 	
	* @method 	 */
	this.askThumbnail = function( index ){
		print("music play control askThumbnail ");
		if( launchParams.isLaunchForMusicPlayer()){
			if( self.csfInitOk == false ){
				Log.f('self.csfInitOk == false');
				self.storeThumbList = index;
				return;
			}
		}
	
		self.csfApi = Volt.require('app/models/csf-manager.js'); //new CsfApi();
		self.csfApi.registerThumbnailCallback(self.updateThumbnail);

		if(index < 0 || index >= self.dataCollection.size()){
			Log.f("[play-collection]askThumbnail--------------index out of scope");
			return;
		}

		var thumbPath = THUMB_BASE_PATH + 'Player' + index + '.jpg';
				
		var savePaths = [thumbPath];	
		var item = this.dataCollection.at(index);
    	if( item == null ){
    		Log.f("this.collection.at(index)" + index + "==null");
    		return;
    	}

		var filePath = '';
		if( self.contentAgent!= null ){
			filePath = item.get('filePath');
		}
		else{	
	    	filePath = item.get('ThumbPath');
		}

		if(launchParams.isLaunchForMusicPlayer()){
			filePath = launchParams.getThumbnailUrl();
		}

		index = index + 100000;

		var options = {
			param_origin_path: filePath,
			param_save_path: savePaths,
			param_media_type: MediaType.MEDIA_MUSIC,
			param_source_type: this.source,
			param_thumb_width: 418,
			param_thumb_height: 418, 
			param_orientation: 0,
			param_used_cache: 0,
			param_video_frame_count: 1,
			param_thumb_user_data: index,
		};
		Log.f("Try to Ask Thumbnail: " + filePath + thumbPath + this.source + index );
		self.csfApi.requestThumbnail(options);
	},

	/**the callback function for get thumbnail
	* @name updateThumbnail
	* @param {eventType} event type	
	* @param {param1} parameter for thumbnail info
	* @param {param2} param2	
	* @memberOf playController	 	
	* @method 	 */
	this.updateThumbnail = function(eventType, param1, param2){
		Log.f("Get Thumbnail for music player: " + param1);
		print("Get Thumbnail for music player: " + param1);
		if(param1 === '' ){
			return false;
		}
		var thumbItem = JSON.parse(param1);
		var savePath = thumbItem.save_path;
		var index = parseInt(thumbItem.user_data);
		Log.f("save_path" + savePath + "index = " + index);
		var filePath = thumbItem.origin_path;

		if( index < 100000 ){
			return false;
		}

		index = index-100000;
		if(index < 0 || index >= self.length ){
			return false;
		}

		if(savePath == undefined){
			self.thumbState[index] = 0;
			EventMediator.trigger(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_FAILD, filePath);
			return;
		}
		self.thumbState[index] = 1;
		EventMediator.trigger(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_DONE, index);
	},
	
	this.play = function( pos, param ) {
		Volt.log('[play-control]---this.play--self.initOk = ', self.initOk);
		Log.f("play-control---this.play--self.initOk = "+ self.initOk);
		if( self.initOk == true ){
			self.realPlay(pos, param);
		}
		else{
			self.storePlayData.push(pos);
			self.storePlayData.push(param);
		}
	},

	/**to open a music file	 
	* @name play	 
	* @memberOf playController	 
	* @param {param} play index	
	* @method 	 */		
	this.realPlay = function( pos, param ) {	
		print('[play-controller.js]---------this.realPlay----pos is ' + pos);
		if( this.instance == null ){
			Log.f("this.instance== null in open");
			return;
		}

		Log.f("[play-controller.js]---------------------------------------------setAppID");
		this.instance.setAppID('org.volt.mycontents','111477001204');
		
		if( this.isPlaying == true ){
			print('[play-controller.js]----this.realPlay----this.isPlaying is true, and to stop the play---');
			RunTimeInfo.bFlagForPrev = true;
			this.stop();
		}
		
		var idx = 0;
		self.currTime = 0;
		
		if( param == undefined ){
			idx = this.getCurrentIdx();		
			Log.f("this.getCurrentIdx() = "+idx);
		}
		else{
			idx = param;
			this.idxGetter.moveToIndex(param);
		}
		
		var item = this.dataCollection.at(idx);
    	if( item == null ){
    		Log.f("this.collection.at(idx)" + idx + "==null");
    		return;
    	}		
    	
		if( item.get('title1')=='' || item.get('title1')==undefined){
			Log.f("have not get this data, try to get it from csf");
			self.dataCollection.getItemList(idx,1);
		}

    	var uri = item.get('filePath');

		if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR){
			var strUri = String(uri);
			var tempUri = '';
			if ( strUri ){
				tempUri = strUri.replace("http","dlna");
			}
			uri = tempUri;
		}
		else
		{
			var DeviceProvider = Volt.require("app/models/device-provider.js");
			var deviceInfo = DeviceProvider.getDeviceInfo(this.deviceID);
			if( deviceInfo != null ){
				var deviceType = deviceInfo.get('type');
				Log.f( " device Type is " + deviceType );

				if( deviceType==DeviceType.DEVICE_TYPE_DLNA ){
					print('try to replace the uri');
					var tempUri = uri;
					if ( tempUri ){
						uri = tempUri.replace("http","dlna");
					}
					
				}
			}
		}

    	Log.f("the play file url is " + uri);	
		print("[play-controller.js]----realPlay---the play file url is " + uri);
		
		var startTime = new Date();
		Log.f ("[music-time]open music file startTime: " + startTime.getTime());
		
		var res = this.instance.open(uri);
		
		var endTime = new Date();
		Log.f ("[music-time]open music file endTime: " + endTime.getTime());
		
		Log.f("open " + uri + " return " + res + "!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		Volt.log("[play-controller.js]----open " + uri + " return " + res + "!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		if ( res == -1)
		{
			EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_MUSICINFO, self.getCurrentIdx());
			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
			{
				Volt.log('[play-controller.js]-----onerror---CurrentPlayLoading is not null, to stop----');
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.stop();				
			}	
					
			Log.f("play " + uri + "Failed!!!!!!");
			this.stop();
			this.setValue( idx, 'PLAYED_COUNT', -1 );
			item.set('playavail', -1);
			Volt.log('[play-controller.js]----res = -1 and it will go to triggule unsupport file box ');
			EventMediator.trigger(EventType.EVENT_TYPE_UNSUPPORT_FILE);
			return -1;
		}

//		var partyRes = this.instance.SetPartyMode(1);
//		print("this.instance.SetPartyMode() = " + partyRes);

		if( this.checkHDAudioSupport(idx) == true ){
			Log.f("It is a HD Audio file, try to setPlayerProperty ");
			appLaunch.terminateMls();
			var speakerID = Vconf.getValue('file/private/sound/feature/SpeakerSelection');
			Log.f('speakerID is '+ speakerID);
			if(Vconf.getValue('file/private/sound/feature/SpeakerSelection') < 2){
				this.instance.setPlayerProperty(18, "", "");
			}
		}
		
		Log.e("Ready to play the "+ uri + " at " + pos);
		var startPlayTime = new Date();
		Log.f ("[music-time]play music file startTime: " + startPlayTime.getTime());
		var playRet = self.instance.play(pos);
		var endPlayTime = new Date();
		Log.f ("[music-time]play music file endTime: " + endPlayTime.getTime());
		
		Log.f("playRet is " + playRet);
		Volt.log("[play-controller.js]-----playRet is " + playRet + " this.getCurrentIdx() is " + this.getCurrentIdx());

//		if(self.thumbState[idx]==-1){
//			this.askThumbnail(idx);
//		}
		
		if( playRet ){
			Volt.log('[play-controller.js]----realPlay---to set the playavail again to avoid the case: it is availabe but first not avaible');
			this.setValue( idx, 'PLAYED_COUNT', 0 );
			item.set('playavail', 0);			
			EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_MUSICINFO, this.getCurrentIdx() );//to update list
			RunTimeInfo.playState = 1;
			Log.f("EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED)!!!!");
			print("[play-controller.js]----this.realPlay----EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED)!!!!");
			

			EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED);	
/*
			var idx = this.getCurrentIdx();

			if(!launchParams.isLaunchForMusicPlayer()){
				if( this.getValue( idx, 'PLAYED_COUNT' ) == -1 ){
					this.setValue( idx, 'PLAYED_COUNT', 0 );
					item.set('playavail', 0);
				}
			}
*/			
			return 1;
		}
		return -1;		
	};

	this.asyncPlay = function() {
		self.getDuration();
	};

	this.playBegin = function() {
		Volt.log('[play-controller.js]-------this.playBegin------');
		EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED);	
	};

	/**to pause a music file playing	 
	* @name pause	 
	* @memberOf playController	 
	* @method 	 */		
	this.pause = function(param) {
		if( this.instance != null ){
			print('[play-controller.js]-----state before pause is ', this.getState());
			Log.e('[play-controller.js]-----state before pause is '+ this.getState());
			var res = -9;
			if (param == 'appPause')
			{
				try
				{
					res = this.instance.pause('appPause');
				}
				catch(e)
				{
					res = this.instance.pause();
					Log.e('[play-controller.js]----	this.pause----e is ' + e);
				}
				
				print('[play-controller.js]-----state before pause is ' + this.getState() + ' res is ' + res);
			}
			else 
			{
				try
				{
					res = this.instance.pause();
				}
				catch(e)
				{
					Log.e('[play-controller.js]----common pause case ---e is ' + e);
				}
				
			}

			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
			{
				Volt.log('[play-controller.js]-----this.pause---CurrentPlayLoading is not null and to pause----');
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.pause();
			}			
			print('[play-controller.js]-----state after pause is ', this.getState());
			Log.e('[play-controller.js]-----state after pause is ' + this.getState());
			EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED);
			return res;
		}
	};

	/**to stop a music file	playing
	* @name stop	 
	* @memberOf playController	 
	* @method 	 */	
	this.stop = function() {
		if( this.instance != null ){
			print('[play-controller.js]---this.stop--state before stop is ', this.getState());
			this.isPlaying = false;
			RunTimeInfo.playState = 0;	
			Log.e("[play-controller.js]---stop in music player!!");
			var res = this.instance.stop();
			print('[play-controller.js]---this.stop is called ');
			EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED);	
			return res;
		}
	};

	/**to resume a music file	playing
	* @name resume	 
	* @memberOf playController	 
	* @method 	 */		
	this.resume = function(para) {
		Log.e('[play-controller.js]------this.resume------para is ' + para);
		print('[play-controller.js]------this.resume------para is ' + para);
		if( this.instance != null ){	
			var res = -9;
			if (para == 'appResume')//appResume
			{
				try
				{
						res = this.instance.resume(para);
				}
				catch(e)
				{
						res = this.instance.resume();
						Log.e('[play-controller.js]---this.resume---e is ' + e);
				}
			
				print('[play-controller.js]------this.resume------res is ' + res);
				Log.e('[play-controller.js]------this.resume------res is ' + res);
			}
			else
			{
				try
				{
					res = this.instance.resume();
				}
				catch(e)
				{
					Log.e('[play-controller.js]---resume---e is ' + e)
				}				
				
			}
			
			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
			{
				Volt.log('[play-controller.js]-----this.resume---CurrentPlayLoading is not null, and resume to play----');
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
			}				
			EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED);	
			return res;
		}
	};	

	/**seek the current playing to designated spot
	* @name seek	 
	* @memberOf playController	 
	* @param {pos} seek to  position	
	* @method 	 */		
	this.seek = function( pos ) {
		Log.f("this.seekEnable =" + this.seekEnable);
		Volt.log('[play-controller.js]---this.seek  is called, this.seekEnable = '+ this.seekEnable + ' this.instance is ' +this.instance + ' self.totalTime is ' + self.totalTime + ' self.currTime is ' + self.currTime )
		if( this.instance != null && this.seekEnable == true){
			this.seekEnable = false;
			var res = -2;
			
			//if (self.totalTime - self.currTime > 10*1000 || )
			{
				res = this.instance.seek(String(pos));
				Volt.log('-----this.instance.seek(String(pos)) is ' + res)
				print('seek res = ' + res);
				if( res == -1 )
				{
					this.seekEnable = true;
					EventMediator.trigger(EventType.EVENT_TYPE_NOT_AVAILIABLE);
				}	
			}
			//else
			{
				Log.e('[player-controller.js]--seek----total - currentTime is less 10 seconds');
				print('[player-controller.js]--seek----total - currentTime is less 10 seconds');
			}
			return res;
		}
	};	

	this.seekComplete = function() {
		//Volt.log('----seekComplete');
		Log.e('[play-controller.js]---seekComplete, this.getState() is ' + this.getState());
		this.seekEnable = true;
		print('[play-controller.js]---state after seek complete is ', this.getState());
		if( this.getState() == 4 ){
			try
			{
				this.resume(null);
			}
			catch(e)
			{
				Log.e("play-controller.js---seekComplete-- e:"+e);
			}
			
		}
		else{
			EventMediator.trigger(EventType.EVENT_TYPE_PLAY_STATE_CHANGED);	
		}
	};

	/**jump farward of the current playing
	* @name jumpForward	 
	* @memberOf playController	 
	* @param {pos} jump step	
	* @method 	 */	
	this.jumpForward = function( pos ){
		Volt.log('------------this.jumpForward-----------this.jumpForward, self.totalTime is ' + self.totalTime + ' self.currTime is ' + self.currTime);
		if( self.totalTime - self.currTime < 10000 ){
			Log.f('self.totalTime = ' + self.totalTime + ' self.currTime = ' + self.currTime );
			return true;
		}
		Log.f("this.seekEnable =" + this.seekEnable);	
		Volt.log("this.seekEnable =" + this.seekEnable + ' this.instance is ' + this.instance);
		if( this.instance != null && this.seekEnable == true)
		{
			this.seekEnable = false;
			Log.f("set seekEnable = false");
			Volt.log('------------this.jumpForward---set seekEnable = false');
			var res = -2;
			if (self.totalTime - self.currTime > 10*1000)
			{
				res = this.instance.jumpForward(pos);
				Volt.log('----this.instance.jumpForward(pos) is ' + res)
				if( res == -1 ){//the return value is not false but -1,or it is 1 not true DF150304-00648
					this.seekEnable = true;
					EventMediator.trigger(EventType.EVENT_TYPE_NOT_AVAILIABLE);
				}		
				
			}
			

			return res;
		}		
	};

	/**jump backward of the current playing
	* @name jumpBackward	 
	* @memberOf playController	 
	* @param {pos} jump step	
	* @method 	 */		
	this.jumpBackward = function( pos ){
		Log.f("this.seekEnable =" + this.seekEnable);
		Volt.log("-----this.jumpBackward----this.seekEnable =" + this.seekEnable + ' this.instance is '+ this.instance);
		if( this.instance != null && this.seekEnable == true){
			this.seekEnable = false;
			Log.f("set seekEnable = false");
			var res = -2;
			if (self.currTime > 10*1000)
			{
				res = this.instance.jumpBackward(pos);
			Volt.log('-----this.jumpBackward-------this.instance.jumpBackward(pos) is '+ res + ' this.seekEnable is ' + this.seekEnable);
				if( res == -1 ){//the return value is not false but -1,or it is 1 not true DF150304-00648
					this.seekEnable = true;
					EventMediator.trigger(EventType.EVENT_TYPE_NOT_AVAILIABLE);
				}		
				
			}
			//var res = this.instance.jumpBackward(pos);

			return res;
		}			
	};

	/**get the standard time string
	* @name getTimeString	 
	* @memberOf playController	 
	* @param {hh} hour value	
	* @param {mm} minute value		
	* @param {ss} second value		
	* @method 	 */
	this.getTimeString = function(hh, mm, ss) {
		var sec = ss > 9 ? ss : '0'+ss;
		var min = mm > 9 ? mm : '0'+mm;

		var res = hh == 0 ? min+':'+sec : hh+':'+min+':'+sec;
		return res;
	};

	/**get the current item's total time
	* @name getDuration	 
	* @memberOf playController	 	
	* @method 	 */		
	this.getDuration = function() {
		if( this.instance != null ){
			this.totalTime = this.instance.getDuration();
			print( 'total Time is ', this.totalTime);

			var secondStyle = this.totalTime / 1000;
			var hour = parseInt(secondStyle/3600);
			var minute = parseInt(secondStyle%3600 / 60);
			var second = parseInt(secondStyle%60);
			var totalTime = this.getTimeString(hour, minute, second);
			Log.f( 'secondStyle is ' + secondStyle, 'hour is ' + hour + 'minute is ' + minute + 'second is ' + second + 'totalTime is ' + totalTime);
			EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_TOTALTIME, totalTime, this.totalTime);

			return this.totalTime;
		}
	};

	/**get the current item's current time
	* @name getPlayingTime	 
	* @memberOf playController	 	
	* @method 	 */		
	this.getPlayingTime = function() {
		if( this.instance != null || this.isPlaying==true){
			return this.instance.getPlayingTime();
		}		
	};

	/**get the state of current playing process
	* @name getState	 
	* @memberOf playController	 	
	* @method 	 */		
	this.getState = function() {
		if( this.instance != null ){
			return this.instance.getState();
		}		
	};

	/**play next one
	* @name playNext	 
	* @param {na} show N/A or not	
	* @memberOf playController	 	
	* @method 	 */		
	this.playNext = function(ignoreRepeat) {
		print("[player-controller.js]--- playNext >>");
		if( this.getState() == 1 ){
			Log.f("Loading process, igrone!!");
			return true;
		}
		var tempAll = 0;
		var tempI = 0;
		while( this.idxGetter.getPlayAbleCount() > 0 ){
			print("playNext loop getPlayAbleCount:",this.idxGetter.getPlayAbleCount());
			if(this.idxGetter.moveNext(ignoreRepeat) == false){
				return false;
			}
			if(!launchParams.isLaunchForMusicPlayer()){
				var unPlayable = self.getValue(this.getCurrentIdx(), 'PLAYED_COUNT') == -1 ? true : false;
				print("[play-controller.js]---playNext this.getCurrentIdx():"+this.getCurrentIdx()+", unPlayable:"+unPlayable);
				if(unPlayable==false){
		    		print('[play-controller.js]---move next true    ', this.getCurrentIdx()); 	
					for(var i = 0; i < this.idxGetter.nTotalCount; i++)
					{
						this.unSupportNum[i] = false;
					}
		        	this.play(0);
					return true;
				}
				else{
					if(this.getCurrentIdx()-1>=0){
						var tempPlayable = self.getValue(this.getCurrentIdx()-1, 'PLAYED_COUNT') == -1 ? true : false;
						this.unSupportNum[this.getCurrentIdx()-1] = tempPlayable;
					}
					this.unSupportNum[this.getCurrentIdx()] = true;
				}
			}
			else{
				print("playNext ~~~");
				for(var i = 0; i < this.idxGetter.nTotalCount; i++)
				{
					this.unSupportNum[i] = false;
				}
		        this.play(0);
				return true;				
			}
			print("player-controller.js this.idxGetter.nTotalCount >>",this.idxGetter.nTotalCount);
			while(tempI<this.idxGetter.nTotalCount){
				if(this.unSupportNum[tempI]==true){
					tempAll++;
				}
				
				if(tempAll==this.idxGetter.nTotalCount){
					for(var i = 0; i < this.idxGetter.nTotalCount; i++)
					{
						this.unSupportNum[i] = false;
					}
					return false;
				}
				tempI++;
			}
			print("player-controller.js tempAll >>",tempAll);
			tempAll = 0;
			tempI = 0;
		}
		EventMediator.trigger(EventType.EVENT_TYPE_PLAYER_ALL_FILEDONE, 3);
		return false;
	};

	/**play pre one
	* @name playPre	 
	* @memberOf playController	 	
	* @method 	 */		
	this.playPre = function() {
		Volt.log('[play-controller.js]----PlayPre----');
		if( this.getState() == 1 ){
			Log.f("Loading process, igrone!!");	
			print('[play-controller.js]---Loading process, igrone!!----');
			return true;
		}
    	if(this.idxGetter.movePre(true) == true){
    		print('[play-controller.js]----move pre true    ', this.getCurrentIdx()); 	
        	this.play(0);
			return true;
    	}
		else{
			EventMediator.trigger(EventType.EVENT_TYPE_NOT_AVAILIABLE);
			print('[play-controller.js]----can\'t move ');
			return false;
		}
	};

	/**timer function to update the current time
	* @name timeOutFn	 
	* @memberOf playController	
	* @method 	 */		
	this.timeEventFn = function( timeInt ) {
		print(" timeEventFn timeInt: "+timeInt);
		if( self.isPlaying == false ){
			Log.e("timeEventFn self.isPlaying == false retrun ");
			return;
		}
		self.currTime = timeInt;
		var percentage = 0;
		if( self.totalTime != 0 ){
			percentage = self.currTime / self.totalTime;
		}

		if( self.currTime > 800 && self.currTime < 1001 ){			//just patch help playerEMP
			self.currTime = 1002;
		}

		if( timeInt<2500){
			var playTime = new Date();
			Log.f("[music-time]----------------->the first second: " + playTime.getTime());
		}
		
//		print('--------------Current percentage is <<<<<<<<<<<<<<<', percentage);
		
		var secondStyle = self.currTime / 1000;
		var hour = parseInt(secondStyle/3600);
		var minute = parseInt(secondStyle%3600 / 60);
		var second = parseInt(secondStyle%60);
		var timeStr = self.getTimeString(hour, minute,second);
		print( 'secondStyle is ',  secondStyle, 'hour is ', hour, 'minute is ', minute, 'second is ', second, 'timeStr is ', timeStr, 'timeInt is ', timeInt, ' percentage is ', percentage);		
		Log.f("[play-controller.js] percentage is "+ percentage);
		EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_CURRENTTIME, percentage, timeStr, self.currTime);
	};

	/**return the repeat mode
	* @name getRepeatMode	 
	* @memberOf playController	
	* @method 	 */		
	this.getRepeatMode = function( flag ) {
		if( flag == true ){
			var repeatFlag = appConfig.getMusicRepeatMode(true);
			self.repeatMode = repeatFlag;
		}
		return self.repeatMode;
	};

	/**return the shuffle mode
	* @name getShuffleMode	 
	* @memberOf playController	
	* @method 	 */		
	this.getShuffleMode = function( flag ) {
		if( flag == true ){
			var shuffleFlag = appConfig.getMusicShuffleMode(true);
			self.shuffleMode = shuffleFlag;
		}
		return self.shuffleMode;
	};	
	/**return the repeat mode
	* @name getRepeatMode	 
	* @memberOf playController	
	* @method 	 */		
	this.setRepeatMode = function( argus ) {
		if ( appConfig.setMusicRepeatMode(argus) == true ){
			self.repeatMode = argus;
		}
    	return;
	};

	/**return the shuffle mode
	* @name getShuffleMode	 
	* @memberOf playController	
	* @method 	 */		
	this.setShuffleMode = function( argus ) {
		if ( appConfig.setMusicShuffleMode(argus) == true ){
			self.shuffleMode = argus;
		}
	};	

	this.updateListThumbnail = function() {
		var currIdx = this.getCurrentIdx();
		var itemCount = this.dataCollection.size();
		var startIdx = currIdx-12<0 ? 0:currIdx-12;
		var endIdx = currIdx+12 >= itemCount ? itemCount-1 : startIdx+13;	

		for( i = startIdx; i <= endIdx; i++ ){
		    if( self.thumbState[i] == -1 ){
				self.askThumbnail(i);
			}
		}
	};

	this.dataAskProcess = function() {
		if( this.dataCollection!= null ){
			return this.dataCollection.musicData;
		}
		return false;
	};
};

var playCtrl = new playController();

playCtrl.init();

exports = playCtrl;

