 /** 
 * @author  Hu Po (pual.hu@samsung.com)
 * 			 
 * @fileoverview  Model controller
 * @date    2014/08/22 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

//var voltapi = require("voltapi");
var voltapi = Volt.require('voltapi.js');
var CommonInfo = Volt.require("app/common/define.js");
var EventType = CommonInfo.EventType;
var launchParams = Volt.require("app/common/launch-params.js");
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var playerController = Volt.require('app/controller/play-controller.js');
var self = null;

var dmrController = function() {
	this.playIns = null;
	this.dBusConnected = false;
	self = this;
	
	this.DmrEvent = {
		DMR_AUDIO_PLAYER_EMP_ATTACH_SUCCESS: 1,
		DMR_AUDIO_PLAYER_EMP_ATTACH_FAIL: 2,
		DMR_AUDIO_PLAYER_EMP_PAUSE: 3,
		DMR_AUDIO_PLAYER_EMP_PLAY: 4,
		DMR_AUDIO_PLAYER_EMP_STOP: 5,
		DMR_AUDIO_PLAYER_EMP_SEEK_TIME: 6,
		DMR_AUDIO_PLAYER_EMP_GET_ITEM_DURATION: 7,
		DMR_AUDIO_PLAYER_EMP_GET_ITEM_PLAYING_POSITION: 8,
		DMR_AUDIO_PLAYER_EMP_GET_PLAYING_STATE: 9,
	};
		
	this.create = function() {
		var initRes = voltapi.DMRAudioPlayer.init();
		Log.f("initRes for DMR is " + initRes);
		this.playIns = playerController;

		var para = String(launchParams.playerInstanceId);
		Log.f("para for dmr_attach_audio_player is" + para);

		var res = true;
		res = voltapi.DMRAudioPlayer.attachAudioPlayer(para);
//		res = this.dmrIns.execute("dmr_attach_audio_player");
		Log.f("HandShake result is " + res);

		self.setEventCallback();
		
		EventMediator.on(EventType.EVENT_TYPE_PLAY_STATE_CHANGED, this.updatePlayState, this);	
		EventMediator.on(EventType.EVENT_TYPE_UPDATE_TOTALTIME, this.updateDuration, this);	
		EventMediator.on(EventType.EVENT_TYPE_UPDATE_CURRENTTIME, this.updateCurrentTime, this);	
		
		return res;
	};

	this.attachDMR = function() {
		var res = true;
		
		var para = String(launchParams.playerInstanceId);
		Log.f("para for dmr_attach_audio_player is" + para);		
		res = voltapi.DMRAudioPlayer.attachAudioPlayer(para);
//		res = this.dmrIns.execute("dmr_attach_audio_player");
		Log.f("HandShake result is " + res);
	};

	this.destroy = function() {
		Log.f("dmr controller destroy!!!");
		Volt.log('dmr controller destroy!!!');
		voltapi.DMRAudioPlayer.detachAudioPlayer();
		this.dBusConnected = false;

		EventMediator.off(EventType.EVENT_TYPE_PLAY_STATE_CHANGED, this.updatePlayState, this);	
		EventMediator.off(EventType.EVENT_TYPE_UPDATE_TOTALTIME, this.updateDuration, this);
		EventMediator.off(EventType.EVENT_TYPE_UPDATE_CURRENTTIME, this.updateCurrentTime, this);	

		voltapi.DMRAudioPlayer.destroy();
	};

	this.updateDuration = function( StrTotalTime, IntTotalTime ) {
		var timeInt = 0;
		if( self.playIns != null ){
			timeInt = self.playIns.totalTime;
		}		
		Log.f("dmr_audio_player_notify_item_duration " + String(IntTotalTime));			
		voltapi.DMRAudioPlayer.notifyItemDuration(String(IntTotalTime));
	};

	this.updatePlayState = function() {
		var currState = self.playIns.getState();
		Log.f("current state is " + currState);
		var dmrState = -1;
		if( currState == undefined ){
			dmrState = 0;
		}
		else{
			switch( currState ){
				case 3:
					dmrState = 2;
					break;
				case 4:
					dmrState = 3;
					break;
				default:
					return;
					break;
			}
		}
		
		Log.f("dmr_audio_player_notify_playing_state " + String(dmrState));
		voltapi.DMRAudioPlayer.notifyPlayingState( String(dmrState) );
	};

	this.updateCurrentTime = function() {
		Volt.log('[DMR-controller.js]-----updateCurrentTime');
		var timeInt = 0;
		if( self.playIns != null ){
			timeInt = self.playIns.getPlayingTime();
		}
//		Log.f("dmr_audio_player_notify_item_playing_position " + String(timeInt));
		voltapi.DMRAudioPlayer.notifyItemPlayingPosition(String(timeInt));
	};

	this.sendStopReason = function( stopReason ) {
		var argu = voltapi.DMRAudioPlayer.STOPPED_REASON_UNKNOWN;
		var details = "";
		switch( stopReason ){
			case 0:
				argu = voltapi.DMRAudioPlayer.STOPPED_REASON_END_OF_PLAYING;
				break;
			case 1:
				argu = voltapi.DMRAudioPlayer.STOPPED_REASON_USER_INTERRUPT;
				break;
			case 2:
				argu = voltapi.DMRAudioPlayer.STOPPED_REASON_ERROR;
				break;
			case 3:
				argu = voltapi.DMRAudioPlayer.STOPPED_REASON_EXTERNAL_REQUEST;
				break;
			default:
				argu = voltapi.DMRAudioPlayer.STOPPED_REASON_UNKNOWN;
				break;				
		}
		
		Log.f("[dmr-controller.js]--sendStopReason--DMRAudioPlayer.notifyStoppedReason " + argu);
		Volt.log("[dmr-controller.js]--sendStopReason--DMRAudioPlayer.notifyStoppedReason " + argu);
		voltapi.DMRAudioPlayer.notifyStoppedReason(argu,details);
	};

	this.setEventCallback = function() {
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_ATTACH_SUCCESS,this.attachSuccessCB);
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_ATTACH_FAIL,this.attachFailedCB);
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_PAUSE,this.pauseEventCB);
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_PLAY,this.resumeEventCB);
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_STOP,this.stopEventCB);
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_SEEK_TIME,this.seekEventCB);
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_GET_ITEM_DURATION,this.durationEventCB);
		voltapi.DMRAudioPlayer.addEventListener(voltapi.DMRAudioPlayer.DMR_AUDIO_PLAYER_EMP_GET_PLAYING_STATE,this.getStateEventCB);		
	};

	this.attachSuccessCB = function() {
		Log.f("attachSuccessCB");
		Volt.log('[dmr-controller.js]---attachSuccessCB---');
		self.dBusConnected = true; 
	};

	this.attachFailedCB = function() {
		Volt.log('[dmr-controller.js]---attachFailedCB---');
		Log.f("attachFailedCB");
		self.dBusConnected = false; 
	};	

	this.pauseEventCB = function() {
		Log.f("DMR_AUDIO_PLAYER_EMP_PAUSE Received!");
		Volt.log('[dmr-controller.js]---pauseEventCB---');	
		{

			self.playIns.pause(null);
		}
		
	};

	this.resumeEventCB = function() {
		Log.f("DMR_AUDIO_PLAYER_EMP_RESUME Received!");
		Volt.log('[dmr-controller.js]---resumeEventCB---');
		{
			//Volt.log("dmr-controller.js---resumeEventCB-- e:"+e);
			self.playIns.resume(null);
		}		
		
	};

	this.stopEventCB = function() {
		Log.f("stopEventCB-------------------");
		Volt.log('[dmr-controller.js]---stopEventCB---');
		EventMediator.trigger(EventType.EVENT_TYPE_PLAYER_ALL_FILEDONE, 4);
	};

	this.seekEventCB = function(param1,param2) {
		Log.f("seekEventCB-------------------param1=" + param1 + "param2=" + param2);
		Volt.log('[dmr-controller.js]---seekEventCB---');
		self.playIns.seek(param2);
	};

	this.durationEventCB = function() {
		Log.f("durationEventCB-------------------");
		Volt.log('[dmr-controller.js]---durationEventCB---');
		self.updateDuration();
	};

	this.getTimeEventCB = function() {
		Log.f("getTimeEventCB-------------------");
		Volt.log('[dmr-controller.js]---getTimeEventCB---');
		if( self.playIns.getState() != undefined ){
			self.updateCurrentTime();
		}
	};

	this.getStateEventCB = function() {
		Volt.log('[dmr-controller.js]---getStateEventCB---');
		Log.f("getStateEventCB-------------------");
		self.updatePlayState();
	};	
};

exports = dmrController;
