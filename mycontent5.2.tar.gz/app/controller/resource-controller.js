/**
 * @author guanhao
 */
var ResMgr = function(){
	var checkResolution =  VDUtil.getResolution();
	this.screenWidth = scene.width;
	this.screenHeight = scene.height;
	print('resource-controller.js, resloution : '+ checkResolution);
	switch(checkResolution)
	{
	case 1920:
		this.imgPath = 'images/1080';
		this.templatePath = 'app/templates/1080';
		break;
	case 1280:
		this.imgPath = 'images/720';
		this.templatePath = 'app/templates/1080';
		break;
	default:
		this.imgPath = 'images/1080';
		this.templatePath = 'app/templates/1080';
		break;
	}
	
	this.getText = function(txtId){
		return Volt.i18n.t(txtId);
	}
	
	this.getImgPath = function(){
		return this.imgPath;
	}
	
	this.getTemplatePath = function(){
		return this.templatePath;
	}
	
	this.getThumbPath = function(){
		//return '/opt/down/panels/mycontents/src/thumb/';
		return '/opt/down/panels/mycontents_temp/app/';
	}
};

var resMgr = new ResMgr();

exports = resMgr;
