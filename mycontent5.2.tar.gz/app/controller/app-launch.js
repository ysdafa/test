 /** 
 * @author  Li Hailong (hailong08.li@samsung.com)
 * 			
 * @fileoverview  app luancher
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var LaunchAppID = CommonInfo.LaunchAppID;
var LaunchedByAppID = CommonInfo.LaunchedByAppID;
var inputController = Volt.require('app/controller/input-controller.js');

var AppLaunch = function(){
	this.aulApp = null;
	this.timer = null;
	this.launch = function(appid, args){
		if(this.aulApp != null){
			print('[launch] Terminate aul....');
		//	this.aulApp.terminate();
		}
		this.aulApp = new Aul();
		print("launchinfo ====== ",JSON.stringify(args));
		
		inputController.blockInput();
		
		if(this.timer){
			Volt.clearTimeout(this.timer);
			this.timer = null;
		}
		this.timer = Volt.setTimeout(function(){inputController.unblockInput();}, 6000,this.timer);
	
		var	result = this.aulApp.launchAppAsync(appid,args);
		
	},
	
	this.launchedBy = function(launchParams) {
		if(launchParams == null || launchParams ==undefined){
			return ;
		}
		var appid = launchParams.getLauncherAppName();
		
		switch(appid){
			case LaunchedByAppID.APP_ID_USB_LAUNCHER : 
			case LaunchedByAppID.APP_ID_PVR_RECORDER :
			case LaunchedByAppID.APP_ID_SOURCE_LIST : {

				if( launchParams.isLaunchForMusicPlayer() == true ){
					this.launchMusicPlayer(launchParams);
					break;
				}

				if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ){
//					RunTimeInfo.router.destroyView(EViewType.eMusicPlayerView);
					Log.f("RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView");
					print("RunTimeInfo.router.currentViewType not switch view");
					//RunTimeInfo.router.switchView(EViewType.eAllContentView, EViewSwitchAniType.eNoneAni);
				}
				
				if(launchParams.getDeviceType() != 'DLNA'){
					Backbone.history.navigate('main-view', { trigger: true});
				}else{
					print('DLNA device===========================');
				}
				
				if(appid === LaunchedByAppID.APP_ID_USB_LAUNCHER){
					Volt.KPIMapper.setPreviousApp('PA02');	
				}
				else if(appid === LaunchedByAppID.APP_ID_SOURCE_LIST){
					Volt.KPIMapper.setPreviousApp('PA03');
				}
				else if(appid === LaunchedByAppID.APP_ID_PVR_RECORDER){
					Volt.KPIMapper.setPreviousApp('PA04');
				}
				break;
			}
			case LaunchedByAppID.APP_ID_SEARCH_ALL : {
				this.launchMusicPlayer(launchParams);
				break;
			}
			case LaunchedByAppID.APP_ID_DMR : {
				this.launchMusicPlayer(launchParams);
				break;
			}
			default:{
				if( launchParams.isLaunchForMusicPlayer == true ){
					this.launchMusicPlayer(launchParams);
					break;
				}
				
				print('open my contents app by first screen~~~');
				Backbone.history.navigate('main-view', { trigger: true});
				Volt.KPIMapper.setPreviousApp('PA01');	
				break;	
			}
		}		
	},

	this.launchMusicPlayer = function(launchParams){
	Volt.log('[app-launch.js]----this.launchMusicPlayer----launchParams is ' + launchParams);
		EventMediator = RunTimeInfo.EventMediator;
		EventType = CommonInfo.EventType;
//		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ALL_POPUP);
		var playerController = Volt.require('app/controller/play-controller.js');
		Volt.require('app/models/csf-manager.js');
		playerController.reset();
		
		var MusicModel = Volt.require("app/models/music-model.js");
		var musicItem = new MusicModel( {
			filePath:launchParams.music_url,
			title1: launchParams.music_title,
			artist:launchParams.music_artist,
			album:launchParams.music_album,
			filesize:launchParams.music_fileSize,
			genre: launchParams.music_genre == '' ?'-':launchParams.genre,
			playavail:0,
		});
		
		Log.f('musicItem for dmr music playing is ' + musicItem.title1);
		playerController.insertModel(musicItem, 0);
		playerController.setStartIdx(0);
		playerController.indexReset();

		if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ){
			var currView = RunTimeInfo.router.getCurrentView();
			if( currView != null ){
				if( launchParams.getLauncherAppName() == LaunchedByAppID.APP_ID_DMR ){
					if( typeof currView.updateDMRMusicData == 'function'){
						currView.updateDMRMusicData();	
						//currView.updateForDMRorSearch();
					}
				}
				else{
					if( typeof currView.updateSearchMusicData == 'function'){
						currView.updateSearchMusicData();	
					}
				}
				currView.show();
			}
		}
		else{
			print("launchMusicPlayer switchView to:"+EViewType.eMusicPlayerView);
			Log.e("launchMusicPlayer switchView to:"+EViewType.eMusicPlayerView);
			RunTimeInfo.router.switchToMusicPlayer(EViewType.eMusicPlayerView, EViewSwitchAniType.eNoneAni);
		}
		return;
	},

	this.preloadVideoPlayer = function(){
		var isPreloading = Vconf.getValue('memory/video-player/player_need_preloading');
		if(isPreloading == 1){
			print("preloadVideoPlayer .... ");
			Log.f("preloadVideoPlayer .... ");
		    var args = {
				"init" : 'background',
		    };	
			this.launch(LaunchAppID.APP_ID_VIDEO_PLAYER, args);	
			inputController.unblockInput();
		}else{
			Log.e("preloadVideoPlayer isPreloading :" + isPreloading);
			print("preloadVideoPlayer isPreloading :" + isPreloading);
		}
	},

	this.preloadPhotoPlayer = function(){
		var isPreloading = Vconf.getValue('memory/photo-player/player_need_preloading');
		if(isPreloading == 1){
			Log.f("preloadPhotoPlayer .... ");
		    var args = {
				"init" : 'background',
		    };	
			this.launch(LaunchAppID.APP_ID_PHOTO_PLAYER, args);	
			inputController.unblockInput();
		}else{
			Log.e("preloadPhotoPlayer isPreloading:"+isPreloading);
			print("preloadPhotoPlayer isPreloading:"+isPreloading);
		}
		
	},
	
	this.terminateMls = function(){
		var service = new Service();
		service.appId = LaunchAppID.APP_ID_MLS;
		service.operation = Service.OPERATION_DEFAULT;
		service.addExtraData("exit", "function");
		service.launch();
	}
	
	this.terminateApp = function(appid){
		print('terminateApp >>>>>>>>>>>>>>>>>> appid:',appid);
		if( this.aulApp!=null ){
			this.aulApp.terminateApp(appid);
		}
	},
	
	this.destroy = function(){
		if(this.aulApp != null){
			this.aulApp.terminate();
		}
	}
};

var appLaunch = new AppLaunch();

exports = appLaunch;

