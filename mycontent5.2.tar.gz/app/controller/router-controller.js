 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Mycontent view manager 
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var CommonInfo = Volt.require("app/common/define.js");
var MycontentsShare = Volt.require('app/templates/1080/mycontents-share.js');
var homepanelInfo = MycontentsShare.homepanelInfo;

var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var KeyCode = CommonInfo.KeyCode;
var EventType = CommonInfo.EventType;
var EOptType = CommonInfo.EOptType;
var PopupType = CommonInfo.PopupType;
var ProgressPopupType = CommonInfo.ProgressPopupType;
var EventMediator = RunTimeInfo.EventMediator; //ContentViewBase.ViewEvent;
var LoadingView = Volt.require('app/views/loading-view.js');
var ViewGlobalData = Volt.require('app/views/view-global-data.js');
var Q = Volt.require('modules/q.js');
var self = null;
var DeviceType = CommonInfo.DeviceType;
var voiceGuide = Volt.require('app/common/voice-guide.js');
var launchParams = Volt.require("app/common/launch-params.js");
var inputController = Volt.require('app/controller/input-controller.js');
var appConfig = Volt.require("app/common/app-config.js");
var RouterController = Backbone.Router.extend({
	mainView : null,
	currentView : null,	
	currentViewType : EViewType.eNoneView,
	viewList : [],
	loadingBG : null,
	loadingIns : null,
	preViewType : null,
	popupFlag : false,
	loadControlFlag : false,
	initViewType: EViewType.eNoneView,
	categoryKeyFlag: true,
	/**
	 * initialization
	*/
	initViewList : function(){
		for(var i = 0; i < EViewType.eViewMax; i++)
		{
			this.viewList[i] = null;
		}
	},
	
	createView : function(viewType){
		print('[router-controller.js] createView viewType: '+viewType);
		Log.e("[router-controller.js] createView viewType:"+viewType);
		if(self.viewList[viewType])
		{
			Log.e(" createView  viewType "+viewType);
			Log.e("   viewType is exist");
			print(" createView  viewType "+viewType);
			print("   viewType is exist");
			return self.viewList[viewType];	
		}
		
		switch(viewType)
		{
		case EViewType.eAllContentView:
			print('[router-controller.js] create allcontentview');
			var AllContentView = Volt.require("app/views/all-content-view.js");
			self.viewList[viewType] = new AllContentView();
			break;
		case EViewType.eVideoContentView:
			print('[router-controller.js] create videocontentview');
			var VideoContentView = Volt.require("app/views/video-content-view.js");
			self.viewList[viewType] = new VideoContentView();
			break;
		case EViewType.ePhotoContentView:
			print('[router-controller.js] create photocontentview');
			var PhotoContentView = Volt.require("app/views/photo-content-view.js");
			self.viewList[viewType] = new PhotoContentView();
			break;
		case EViewType.eMusicContentView:
			print('[router-controller.js] create musiccontentview');
			var MusicContentView = Volt.require("app/views/music-content-view.js");
			self.viewList[viewType] = new MusicContentView();		
			break;
		case EViewType.eRecordContentView:
			print('[router-controller.js] create eRecordContentView');
			var RecordContentView = Volt.require("app/views/record-content-view.js");
		    self.viewList[viewType] = new RecordContentView();		
			break;
		case EViewType.eMobilePhoneView:
			print('[router-controller.js] create mobilephoneview');
			var MobilePhoneView = Volt.require('app/views/mobile-phone-view.js');
			self.viewList[viewType] = new MobilePhoneView(); 	
			break;
		case EViewType.eCloudServiceView:
			break;
		case EViewType.eMusicPlayerView:
			print('[router-controller.js] create musicplayer');	
			var MusicPlayerView = Volt.require("app/views/music-player-view.js");
			var ContentBaseCollection = Volt.require("app/models/content-base-collection.js");
			self.viewList[viewType] = new MusicPlayerView({
		            collection: ContentBaseCollection
		    });				
			break;			
		case EViewType.eConnectionGuideView:
			print('[router-controller.js] create ConnectionGuideView');
			var ConnGuidesView = Volt.require("app/views/connection-guide-view.js");
			self.viewList[viewType] = new ConnGuidesView();						
			break;
		case EViewType.eConnectUsbGuideView:
			print('[router-controller.js] create eConnectUsbGuideView');
			var ConUsbGuidePage =  Volt.require("app/views/connectusb-guide-view.js");
			self.viewList[viewType] = new ConUsbGuidePage();
			break;
		case EViewType.eConnectMobileGuideView:
			print('[router-controller.js] create ConnectionGuideView');
			var ConMobileGuidePage = Volt.require("app/views/connectmobile-guide-view.js");
			self.viewList[viewType] = new ConMobileGuidePage();
			break;
		case EViewType.eConnectPcGuideView:
			print('[router-controller.js] create eConnectPcGuideView');
			var ConPcGuidePage = Volt.require("app/views/connectpc-guide-view.js");
			self.viewList[viewType] = new ConPcGuidePage();
			break;
		case EViewType.eWelcomePageView:
			var WelcomePageView = Volt.require('app/views/welcome-page-view.js');
			self.viewList[viewType] = new WelcomePageView();
		default:
			break;
		}
		
		return self.viewList[viewType];
	},
	
	destroyView : function(viewType){
		Log.e("[router-controller.js] destroyView- viewType:"+viewType);
		
		if(!self.viewList[viewType])
		{
			print('[router-controller.js]destroyView---------view is null');
			Log.e("[router-controller.js]destroyView---------view is null  return");
			return ;
		}
		
		var viewContainer = self.mainView.getViewContainer();
		if(viewContainer && viewContainer.getChildCount() > 0)
		{
			for( var i = viewContainer.getChildCount(); i > 0; i-- ){
				viewContainer.removeChild( i-1 );	
			}
		}
		print('rounter-controller.js viewContainer.getChildCount():',viewContainer.getChildCount());
		self.viewList[viewType].destroy();
		
		self.viewList[viewType] = null;
		
		//Volt.Nav.reload();
	},
	
	embedView : function(view){
		Log.e("[router-controller.js] embedView  ");
		print("[router-controller.js] embedView  ");
		
		if(!self.mainView ){
			print('[router-controller.js]embedView------mainView  is null');
			Log.e("[router-controller.js]embedView------mainView  is null");
			return ;
		}
		if(!view){
			print('[router-controller.js]embedView------ view is null');
			Log.e("[router-controller.js]embedView------ view is null");
			return ;
		}
		
		var viewContainer = self.mainView.getViewContainer();
		
		if(!viewContainer){
			print('[router-controller.js]embedView------viewContainer is null');
			Log.e("[router-controller.js]embedView------viewContainer is null");
			return ;
		}
		
		if(view.widget&&view.widget.parent == viewContainer){
			print('[router-controller.js]embedView------view.widget.parent == viewContainer');
			Log.e("[router-controller.js]embedView------view.widget.parent == viewContainer");
			return ;
		}
		print("[router-controller.js] embedView  render view");
		Log.e("[router-controller.js] embedView  render view");

		var viewObject = view.render();
		if(viewObject){		
			viewContainer.addChild(viewObject.widget); 
		}else{
			Log.e("[router-controller.js] viewObject is null");
			print("[router-controller.js] viewObject is null");
		}
		print("[router-controller.js] embedView ");
		self.mainView.show();							//add by pual.hu for call Volt.Nav.setRoot in self.mainView.show
		
		//Volt.Nav.reload();
	},
	
	hideView : function(view, aniType) {
		print('[router-controller.js] hideView() begin');
	    var deferred = Q.defer();
	
	    if (!view) {
	        deferred.resolve();
	        return deferred.promise;
	    }
	
	    view.hide(aniType).then(function(){
	    	deferred.resolve();
	    });
	
	    // deferred.resolve();
	    return deferred.promise;
	},

	showView : function(view, aniType) {
		print('[router-controller.js] showView() begin');
		var deferred = Q.defer();
		
		if (!view) {
	    	print('[router-controller.js] showView() view is null');
	    	deferred.resolve();
	    	return deferred.promise;
	    }
	    print('[router-controller.js] view.show(aniType)');
	    view.show(aniType).then(function(){
	    	deferred.resolve();
	    });
	    
	    return deferred.promise;
	},
	
	initMainView : function(){
		if(this.mainView)
		{
			return ;
		}
		//var DeviceProvider = Volt.require("app/models/device-provider.js");
		this.mainView = Volt.require('app/views/main-view.js');
		this.mainView.setRouter(this);
		this.mainView.render();
		if( launchParams.isLaunchForMusicPlayer()==false){
			this.showView(this.mainView, EViewSwitchAniType.eNoneAni);	
		}
		else{
			this.mainView.hide();
		}
	},

	onCategoryCallback : function(type, devItem){
		Log.e("onCategoryCallback  type:" + type);
		
		print('[router-control][onCategoryCallback]---type :'+ type + ',devItem:'+devItem+', currentViewType:'+this.currentViewType);
		if ( this.currentViewType != EViewType.eConnectionGuideView 
			&& this.currentViewType != EViewType.eMobilePhoneView ){
			print(" RunTimeInfo.router.mainView: "+RunTimeInfo.router.mainView);
			if(RunTimeInfo.router != null 
				&& RunTimeInfo.router.mainView != null
				&& RunTimeInfo.router.mainView.popupView != null){
				
				RunTimeInfo.router.mainView.popupView.clearOption();
			}
		}
		// disconnect current device, destory folder path and root arrow
		// if current view is connection guide, need not destory folder path
		print('onCategoryCallback >>>>>>>>>>>>  this.currentViewType:',this.currentViewType);
		if(this.currentViewType != EViewType.eNoneView 
			&& this.currentViewType != EViewType.eConnectionGuideView 
			&& this.currentViewType != EViewType.eConnectPcGuideView 
			&& this.currentViewType != EViewType.eConnectUsbGuideView
			&& this.currentViewType != EViewType.eConnectMobileGuideView){
			print(' onCategoryCallback >>>>  destroy folder path ');
				EventMediator.trigger(EventType.EVENT_TYPE_DESTROY_FOLDER_PATH);
				EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ROOT_ARROW);
		}
		if(type != 'Connection Guide' && !devItem){
			print('[router-controller] onCategoryCallback-------- devItem is null');
			Log.e("[router-controller] onCategoryCallback-------- devItem is null");
			return ;
		}

		if ( launchParams.isLaunchForMusicPlayer() == true ){
			if( this.currentViewType == EViewType.eMusicPlayerView ){
				Log.f("launchParams.isLaunchForMusicPlayer() == true");
				return;
			}
		}

		if(RunTimeInfo.isEditMode){
			//this.currentView.exitEditMode();
			this.currentView.resetSelectStatus();
			//Volt.Nav.reload();
		}
		
		if( this.currentViewType == EViewType.eMusicPlayerView ){
			Log.f("this.currentViewType == EViewType.eMusicPlayerView "+self.preViewType);
			print("destroy music player view self.preViewType:"+self.preViewType);
			/* destroy music player first */
			try{
			self.viewList[EViewType.eMusicPlayerView].hide();
			self.viewList[EViewType.eMusicPlayerView].destroy();
		
			self.viewList[EViewType.eMusicPlayerView] = null;
			
			/*  enter music player , content thumbnail callback is replace by music player's   */
			if(self.viewList[self.preViewType] != null 
				&& self.preViewType != EViewType.eMusicPlayerView
				&& self.preViewType != EViewType.eConnectionGuideView
				&& self.preViewType != EViewType.eConnectUsbGuideView 
				&& self.preViewType != EViewType.eConnectMobileGuideView ){
				self.viewList[self.preViewType].updateThumbnailCb();
			}
				}catch(e){

					print(" onCategoryCallback destroy music player e:"+e)
				}
			self.currentViewType = self.preViewType;
		//	this.returnFromMusicPlayer(self.preViewType, EViewSwitchAniType.eNoneAni, false);
		}
		
		Log.e("onCategoryCallback begain switch view ");
		if (type == DeviceType.DEVICE_TYPE_USB){
			print('[router-controller] onCategoryCallback, usb path:', devItem.get('mountPath'));
			this.mainView.headerView.optionParam.secondSelectedIndex[0] = -1;
			ViewGlobalData.deviceChange();
			this.switchView(ViewGlobalData.getViewType('USB'), EViewSwitchAniType.eNoneAni);
		}
		else if (type == DeviceType.DEVICE_TYPE_DLNA ){
			print('[router-controller] onCategoryCallback, DLNA');
			ViewGlobalData.deviceChange();
			this.switchView(ViewGlobalData.getViewType('DLNA'),EViewSwitchAniType.eNoneAni);	
		}
		else if( type == DeviceType.DEVICE_TYPE_PTP ){
			print('[router-controller] onCategoryCallback, PTP');
 			this.switchView(ViewGlobalData.getViewType('PTP'),EViewSwitchAniType.eNoneAni);
		}
		else if (type == 'Connection Guide' ){
			print("[router-controller] t_categoryCallback eConnectionGuideView!\n");
            this.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
		}
		else if(type == 'RA'){
			print('[router-controller] onCategoryCallback, RA');
			this.switchView(EViewType.ePhotoContentView,EViewSwitchAniType.eNoneAni);
		}
	},
	
	onViewSelectAll : function(){
		print('[router-controller.js] ------ onViewSelectAll');
		
		if(this.currentView){
			this.currentView.updateSelAllItem();
		}
	},
	
	onViewDeselectAll : function(){
		print('[router-controller.js] ------ onViewDeselectAll');
		if(this.currentView){
			this.currentView.DisSelectAllItem();
		}
	},
	
	onViewCancelSelect : function(){
		print('[router-controller.js] ------ onViewCancelSelect');
		self.currentView.exitEditMode();
		Volt.Nav.focus(Volt.Nav.getItem(0));
	
	},

	onViewPlaySelect : function(){
		print('[router-controller.js] ------ onViewPlaySelect');
		if(self.currentView.startPlaySelItem != null){
			print('[router-controller.js] ------ setSelectItemToCsf');
			//self.currentView.setDesSelectItemToCsf();  //before set select item to csf, init csf select status is false
			//self.currentView.setSelectItemToCsf();
			print('[router-startPlaySelItem.js] ------ startPlaySelItem');
			self.currentView.startPlaySelItem();
		}	
	},
	
	onViewSendSelect : function(){
		print('[router-controller.js] ------ onViewSendSelect');
		this.mainView.showDevPopup();
	},

	onExitEditModeView: function(){
		print('[router-controller.js] ------ onExitEditModeView');
		self.currentView.exitEditMode();
	},

	hideMessageBoxCallback: function(){
		self.mainView.messagePopup.message.hide();
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		Volt.Nav.endModal();
	},

	onViewDeleteSelect : function(){
		print('[router-controller.js] ------ onViewDeleteSelect');
		self.mainView.showDeleteItemPopup();
	},

	onGetSelectItemNum : function(){
		var num = self.currentView.getSelectionCount();
		return num;
	},

	setEditModeOptBtnFocus : function(){
		print('[router-controller.js] ------ setEditModeOptFocus');
		if(RunTimeInfo.isEditMode == true){
			print('-----setEditModeOptFocus() edit mode is true!');
			if(self.currentView.checkAllItemIsFolder() == true){
				print('-----setEditModeOptFocus() item type is folder!');
				self.mainView.editModeView.setOptionNoFocus();
				if(self.currentView.nativeGridList == null){
					print('setEditModeOptBtnFocus');
					var selectorBtn = self.mainView.editModeView.deviceBtn;
					Volt.Nav.focus(selectorBtn);
				}
			}
			else{
				self.mainView.editModeView.setOptionHasFocus();
			}
			Volt.Nav.reload();
		}
	},
	
	onBlockViewInput : function(){
		print('[router-controller.js] ------ onBlockViewInput');
		Log.f('[router-controller.js] ------ onBlockViewInput');
		Volt.Nav.block();
		var date = new Date();
		var time = date.getTime();
		print('onBlockViewInput time = ',time);
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		
		if(RunTimeInfo.isLoadingShown == false){
			print("onBlockViewInput show loading ");
			LoadingView.show();	
			RunTimeInfo.isLoadingShown = true;
		}
	//	LoadingView.show();
		//disable cateory view key event
		if(self.mainView.categoryView != null 
			&& self.mainView.categoryView.categoryList != null){
			//self.mainView.categoryView.categoryList.setEnableChangeTab(false);
		}
		var resMgr = Volt.require('app/controller/resource-controller.js');
		var txt = resMgr.getText('COM_TV_SID_LOADING')+resMgr.getText('COM_SID_PLEASE_WAIT_UPPER');
		voiceGuide.queuingPlay(txt);
		//voiceGuide.play(txt);
	},
	
	onUnBlockViewInput : function(){
		print('[router-controller.js] ------ onUnBlockViewInput');
		Log.f('[router-controller.js] ------ onUnBlockViewInput');
		Volt.Nav.unblock();
		var date = new Date();
		var time = date.getTime();
		print('1111111onBlockViewInput time = ',time);
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		print("onBlockViewInput hide loading ");
		LoadingView.hide();
		RunTimeInfo.isLoadingShown = false;

		//enable cateory view key event
		if(self.mainView.categoryView != null 
			&& self.mainView.categoryView.categoryList != null){
			self.mainView.categoryView.categoryList.setEnableChangeTab(true);
		}
	},
	onHeaderReturnSelect : function(){		
		//ViewGlobalData.reset();
		ViewGlobalData.deviceChange();
		//ViewGlobalData.viewTypeIndex = 0;
				
		if(RunTimeInfo.isEditMode == true){
			self.onExitEditModeView();
		}
		self.switchView(self.getCurrentViewType(),EViewSwitchAniType.eNoneAni);
		//self.mainView.renderHeader(true);
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ROOT_ARROW);
		//if press header return arrow, view will return to root path, folder path need destroy
		EventMediator.trigger(EventType.EVENT_TYPE_DESTROY_FOLDER_PATH);

	},

	setDefaultContents : function(){
		print('[Router-controller.js]setDefaultContents()');
		self.mainView.renderDefContent(self.currentViewType == EViewType.eAllContentView);
		RunTimeInfo.isNoContent = true;
	},

	removeDefaultContents : function(){
		print('[Router-controller.js]removeDefaultContents()');
		self.mainView.hideDefContent();
		RunTimeInfo.isNoContent = false;
	},
	/* public */
	/**
	 * initialization
	*/
	initialize : function () {
		print('router-controller.js initialize begin~~~');
		self = this;
		RunTimeInfo.router = this;
		this.initViewList();
		this.initMainView();
		EventMediator.on(EventType.EVENT_TYPE_CATEGORY_CHANGE, this.onCategoryCallback, this);
		EventMediator.on(EventType.EVENT_TYPE_VIEW_SELECT_ALL, this.onViewSelectAll, this);
		EventMediator.on(EventType.EVENT_TYPE_VIEW_DESELECT_ALL, this.onViewDeselectAll, this);
		EventMediator.on(EventType.EVENT_TYPE_VIEW_CANCEL_SELECT, this.onViewCancelSelect, this);
		EventMediator.on(EventType.EVENT_TYPE_VIEW_PLAY_SELECT, this.onViewPlaySelect, this);
		EventMediator.on(EventType.EVENT_TYPE_VIEW_SEND_SELECT, this.onViewSendSelect, this);
		EventMediator.on(EventType.EVENT_TYPE_VIEW_DELETE_SELECT, this.onViewDeleteSelect, this);
		EventMediator.on(EventType.EVENT_TYPE_EXIT_EDIT_MODE_VIEW, this.onExitEditModeView, this);
		
		EventMediator.on(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA, this.onBlockViewInput, this);
		EventMediator.on(EventType.EVENT_TYPE_END_REQUEST_DATA, this.onUnBlockViewInput, this);
		EventMediator.on(EventType.EVENT_TYPE_SELECT_HEADER_RETURN, this.onHeaderReturnSelect, this);
		EventMediator.on(EventType.EVENT_TYPE_FAILE_REQUEST_DATA, this.setDefaultContents, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_NO_DATA, this.removeDefaultContents, this);
		//EventMediator.on(EventType.EVENT_TYPE_PRESS_RETURN_KEY, this.onHandleReturnKey, this);
		
		EventMediator.on(EventType.EVENT_TYPE_MAIN_VIEW_DIM, this.onDim, this);
		EventMediator.on(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM, this.onUnDim, this);
		EventMediator.on(EventType.EVENT_TYPE_EDIT_MODE_BTN_FOCUS, this.setEditModeOptBtnFocus, this);
		EventMediator.on(EventType.EVENT_TYPE_LOAD_COMMON_CONTROL, this.loadCommonControl, this);
	},
	
	destroy : function(){
		print('router-controller.js, destroy');
		self.destroyAllView();
	},
	
	getViewContainer : function(){
		if(!this.mainView)
		{
			return null;
		}
		
		return this.mainView.getViewContainer();
	},

	createLoading : function(){
		if ( !this.loadingBG ){
			print('[router-controller.js] loading begin');
			var AnimatedImageDrawing = Volt.require('lib/custom-widgets/AnimatedImageDrawing.js');
			var PanelCommon = Volt.require('lib/panel-common.js');
			var loadTemplate = PanelCommon.loadTemplate;
			var MyContentsMainTemplate = Volt.require('app/templates/1080/mycontents-main-template.js');

			this.loadingBG = loadTemplate(MyContentsMainTemplate.loadingWidget);
			
			var winsetLoading = Volt.require('WinsetUIElement/winsetLoading.js');
			this.loadingIns = new winsetLoading({
				 x: this.loadingBG.width/2-loadingSize/2,		
				 y: this.loadingBG.height/2-loadingSize/2,		
				 parent: this.loadingBG,
				 style: 4,
				 text: Volt.i18n.t('COM_TV_SID_LOADING'),
				 custom : {
						    multilingual : {
				             SID : 'COM_TV_SID_LOADING'
							}
				 		}
			});
			this.loadingIns.play();
			print('[router-controller.js] loading finish');
		}
		else{
			this.loadingIns.play();
			this.loadingBG.show();
		}
	},

	hideLoading : function(){
		this.loadingBG.hide();
		this.loadingIns.stop();
	},

	loadCommonControl : function(){
		Volt.setTimeout(function(){
			print(' router-controller.js loadCommonControl');
			var PanelCommon = Volt.require('lib/panel-common.js');
		},100);
	},
	returnFromMusicPlayer:function(viewTo, aniType){
		print('[router-controller.js] enter into returnFromMusicPlayer() viewTo:'+viewTo);
		Log.e("[router-controller.js] enter into returnFromMusicPlayer() ");
		
		try{
			Log.e(" returnFromMusicPlayer blockInput ");
			print(" returnFromMusicPlayer blockInput ");
			inputController.blockInput();
			var deferred = Q.defer(); 
			var timeBegin = new Date();
			
			print('[router-controller.js] returnFromMusicPlayer self.currentViewType : ',self.currentViewType);
			Log.e("[router-controller.js] returnFromMusicPlayer self.currentViewType : "+self.currentViewType);
	        self.preViewType = self.currentViewType;

			print("[router-controller.js]    returnFromMusicPlayer self.preViewType : "+self.preViewType);
			Log.e("[router-controller.js]    returnFromMusicPlayer self.preViewType : "+self.preViewType);
					
			self.hideView(self.viewList[EViewType.eMusicPlayerView], aniType)
				.then(function(){
					print(" destroyView view returnFromMusicPlayer");
					
					self.viewList[EViewType.eMusicPlayerView].destroy();
		
					self.viewList[EViewType.eMusicPlayerView] = null;
					
					/* MUST do  self.currentViewType = viewTo here, otherwise, all content can not be destoryed.*/
					self.currentViewType = viewTo;
	            	//self.currentView = self.viewList[viewTo];
						
					var freshData = appConfig.getUpdateContentFlag(true);
					print("returnFromMusicPlayer freshData:"+freshData);
					if(freshData == 'true' 
						&& (viewTo == EViewType.eAllContentView || viewTo == EViewType.eMusicContentView)){
						appConfig.setUpdateContentFlag('false');
						print(" switchView viewTo:"+viewTo);
						try{
							/*  */		
							RunTimeInfo.isReturnFromMusicPlayer = true;
							self.switchView(viewTo, EViewSwitchAniType.eNoneAni);
							//self.preViewType = EViewType.eMusicPlayerView;
						}catch(e){
							print(" switchView viewTo e: "+e);
							Log.e(" switchView viewTo e: "+e);
						}
					}else{			
						
						print('[router-controller.js] begin to returnFromMusicPlayer');
						Log.e("[router-controller.js] begin to returnFromMusicPlayer");
						self.currentView = self.viewList[viewTo];
						self.showView(self.viewList[viewTo], aniType).then(function(){
							RunTimeInfo.router.categoryKeyFlag = true;
							deferred.resolve();
							
							self.viewList[viewTo].setFocusReturnFromMusicPlayer();							
							
							self.viewList[viewTo].showFocus();
							
							inputController.unblockInput();
						});
					}
				});
							
			var DeviceProvider = Volt.require("app/models/device-provider.js");
			var devItem = DeviceProvider.getCurrentDevice();
			if(devItem){
				if(devItem.get('uhd')){
					Volt.KPIMapper.enterPage('MY_UHD_HOME_PG');
				}else{
					Volt.KPIMapper.enterPage('MY_DEVICE_PG');
				}
			}
		}catch(e){
			print("router-controller  returnFromMusicPlayer e:"+e);
			Log.e("router-controller  returnFromMusicPlayer e:"+e);
				
		}

		return deferred.promise;
	},
	switchToMusicPlayer:function(viewTo, aniType){
		print('[router-controller.js] enter into switchToMusicPlayer() ');
		Log.e("[router-controller.js] enter into switchToMusicPlayer() ");
		
		try{
			Log.e(" switchToMusicPlayer blockInput ");
			print(" switchToMusicPlayer blockInput ");
			inputController.blockInput();
			var deferred = Q.defer(); 
			var timeBegin = new Date();
			print('[router-controller.js] switchToMusicPlayer self.currentViewType : ',self.currentViewType);
			Log.e("[router-controller.js] switchToMusicPlayer self.currentViewType : "+self.currentViewType);
	        self.preViewType = self.currentViewType;
	
			Log.e("[router-controller.js] switchToMusicPlayer self.preViewType : "+self.preViewType);
			print('[router-controller.js] switchToMusicPlayer self.preViewType : ',self.preViewType);
			{	

					//self.destroyView(self.preViewType);
					print(" create view eMusicPlayerView");
					try{
						self.createView(viewTo);	
					}catch(e){
						print("switchView createView eMusicPlayerView e:"+e);
						Log.e("switchView createView eMusicPlayerView e:"+e);
					}
					
					self.currentViewType = viewTo;
	            	self.currentView = self.viewList[viewTo];
					
				//	self.embedView(self.viewList[viewTo]);
					print("render music player view:");
					try{
						var viewObject = self.viewList[viewTo].render();
					}catch(e){

						print(" music player render exception:  "+e);
						Log.e(" music player render exception:  "+e);
					}
					var viewContainer = self.mainView.getViewContainer();
					
					if(viewObject){		
					//	self.mainView.widget.addChild(viewObject.widget); 
					//	scene.addChild(viewObject.widget); 
						viewContainer.addChild(viewObject.widget);
						self.mainView.show();	
					}else{
						Log.e("[router-controller.js] viewObject is null");
						print("[router-controller.js] viewObject is null");
					}
					
					if(self.viewList[viewTo].makeDataSource != undefined){
						print("switchView make data source view ");
					    self.viewList[viewTo].makeDataSource(self.mainView.categoryView.currentMountPath);
					}
					
					print('[router-controller.js] begin to show view');
					Log.e("[router-controller.js] begin to show view");

					self.showView(self.viewList[viewTo], aniType).then(function(){
						RunTimeInfo.router.categoryKeyFlag = true;
						deferred.resolve();
						inputController.unblockInput();
					});
				}
			/*
			self.hideView(self.viewList[self.preViewType], aniType)
				.then(function(){

					//self.destroyView(self.preViewType);
					print(" create view eMusicPlayerView");
					try{
						self.createView(viewTo);	
					}catch(e){
						print("switchView createView eMusicPlayerView e:"+e);
						Log.e("switchView createView eMusicPlayerView e:"+e);
					}
					
					self.currentViewType = viewTo;
	            	self.currentView = self.viewList[viewTo];
					
				//	self.embedView(self.viewList[viewTo]);
					print("render music player view:");
					try{
						var viewObject = self.viewList[viewTo].render();
					}catch(e){

						print(" music player render exception:  "+e);
					}
					if(viewObject){		
						scene.addChild(viewObject.widget); 
					}else{
						Log.e("[router-controller.js] viewObject is null");
						print("[router-controller.js] viewObject is null");
					}
					
					if(self.viewList[viewTo].makeDataSource != undefined){
						print("switchView make data source view ");
					    self.viewList[viewTo].makeDataSource(self.mainView.categoryView.currentMountPath);
					}
					
					print('[router-controller.js] begin to show view');
					Log.e("[router-controller.js] begin to show view");

					self.showView(self.viewList[viewTo], aniType).then(function(){
						RunTimeInfo.router.categoryKeyFlag = true;
						deferred.resolve();
						inputController.unblockInput();
					});
				});
				*/	
			var DeviceProvider = Volt.require("app/models/device-provider.js");
			var devItem = DeviceProvider.getCurrentDevice();
			if(devItem){
				if(devItem.get('uhd')){
					Volt.KPIMapper.enterPage('MY_UHD_HOME_PG');
				}else{
					Volt.KPIMapper.enterPage('MY_DEVICE_PG');
				}
			}
		}catch(e){

			print("router-controller  switchView e:"+e);
			Log.e("router-controller  switchView e:"+e);
				
		}
	
		return deferred.promise;
		
	},
	/**
	 * bottom area will show viewto type view
	*/
	switchView : function(viewTo, aniType){
		print('[router-controller.js] enter into switchView() ');
		Log.e("[router-controller.js] enter into switchView() ");
		try{
		Log.e(" switchView blockInput ");
		print(" switchView blockInput ");
		inputController.blockInput();
		var deferred = Q.defer(); 
		var timeBegin = new Date();
		print('[router-controller.js] switchView self.currentViewType : ',self.currentViewType);
		Log.e("[router-controller.js] switchView self.currentViewType : "+self.currentViewType);
        self.preViewType = self.currentViewType;
		Log.e("[router-controller.js]  after  switchView self.preViewType : "+self.preViewType);
		print("[router-controller.js]  after  switchView self.preViewType : "+self.preViewType);
		self.hideView(self.viewList[self.preViewType], aniType)
			.then(function(){

				self.destroyView(self.preViewType);
				print(" create view ");
				try{
					self.createView(viewTo);	
				}catch(e){
					print("switchView createView e:"+e);
					Log.e("switchView createView e:"+e);
				}
				print(" embedView view ");

				self.currentViewType = viewTo;
            	self.currentView = self.viewList[viewTo];
				
				self.embedView(self.viewList[viewTo]);
				print(" make data source view ");
			
				if(self.viewList[viewTo].makeDataSource != undefined){
					print(" make data source view ");
				    self.viewList[viewTo].makeDataSource(self.mainView.categoryView.currentMountPath);
				}
				
				print('[router-controller.js] begin to show view');
				Log.e("[router-controller.js] begin to show view");

				self.showView(self.viewList[viewTo], aniType).then(function(){
					RunTimeInfo.router.categoryKeyFlag = true;
					deferred.resolve();
					inputController.unblockInput();
				});
			/*set the main template widiget for root */
			
            //self.currentViewType = viewTo;
            //self.currentView = self.viewList[viewTo];
		});
		
		
		var DeviceProvider = Volt.require("app/models/device-provider.js");
		var devItem = DeviceProvider.getCurrentDevice();
		if(devItem){
			print("switchView uhd : ",devItem.get('uhd'));
			if(devItem.get('uhd') == true){
				Volt.KPIMapper.enterPage('MY_UHD_HOME_PG');
			}else{
				Volt.KPIMapper.enterPage('MY_DEVICE_PG');
			}
		}
			}catch(e){

				print("router-controller  switchView e:"+e);
				Log.e("router-controller  switchView e:"+e);
				
			}
		return deferred.promise;
		
	},
	
	destroyAllView : function(){
		for(var i = 0; i < EViewType.eViewMax; i++)
		{
			print('router-controller.js, destroyAllView:',i);
			if( self.viewList[i] ){
				print('router-controller.js, i',i);
				self.viewList[i].destroy();
				self.viewList[i] = null;
			}
		}
	},
	
	getCurrentView : function(){
		return self.currentView;
	},

	getCurrentViewType : function(){
		return self.currentViewType;
	},
	
	/*handle none-halo control key event*/
	onKeyEvent : function(keycode, keytype){
		print("[router-controller]--- router controller  onKeyEvent ");
		if(keytype != Volt.EVENT_KEY_RELEASE){
			return ;
		}
		
		if(keycode == Volt.KEY_RETURN){
			if(RunTimeInfo.isLongPopupShow){
				EventMediator.trigger(EventType.EVENT_TYPE_EXIT_LONG_PRESS_POPUP);
			}
		}
	},
	
	onDim : function(){
		this.popupFlag = true;
	},
	
	onUnDim : function(){
		this.popupFlag = false;
	},

	pauseView: function(){
		this.hideView(this.getCurrentView(),EViewSwitchAniType.eNoneAni );
	}
	
})

exports = RouterController;

