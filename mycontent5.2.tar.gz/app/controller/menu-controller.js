 /** 
 * @author  Chen Xiaoming (xiaom.chen@samsung.com)
 * 			 
 * @fileoverview  Model controller
 * @date    2014/08/22 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var MenuController = function() {

	this.enableMenu = function(){
		print('menu-controller.js enableMenu()');
		
		VDUtil.AppControl_InitDbusConnection();
		Log.e("MenuController enableMenu  ");	
		VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.mycontents");
		VDUtil.AppControl_FiniDbusConnection(); 
		Vconf.setValue('db/menu/refresh_menu', 'on');
	};

	this.disableMenu = function(){
		print('menu-controller.js disableMenu()--- for vconfig---5');
		Log.e("menu-controller.js disableMenu()--- for vconfig");
		VDUtil.AppControl_InitDbusConnection();
//		VDUtil.AppControl_DisableItem("picture", "org.volt.mycontents"); DF150407-00901
		VDUtil.AppControl_DisableItem("broadcasting", "org.volt.mycontents");		
		VDUtil.AppControl_DisableItem("3d", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("energy-saving", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("rgb-onlymode", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("game-mode", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("pip", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("picturesize", "org.volt.mycontents");
		VDUtil.AppControl_FiniDbusConnection();
		Log.e("menu-controller.js disableMenu db/menu/refresh_menu to on");
		Vconf.setValue('db/menu/refresh_menu', 'on');
		
		
	};
	this.enableMusicMenu = function(){
		print('menu-controller.js enableMusicMenu()--- for vconfig---5');
		Log.e("menu-controller.js enableMusicMenu()--- for vconfig");
		VDUtil.AppControl_InitDbusConnection();
		VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.mycontents");
		VDUtil.AppControl_FiniDbusConnection();  
		Log.e("menu-controller.js enableMusicMenu db/menu/refresh_menu to on");
		Vconf.setValue('db/menu/refresh_menu', 'on');
	};

	this.disableMusicMenu = function(){
		print('menu-controller.js disableMenuItem()--- for vconfig---5');
		Log.e("menu-controller.js disableMenuItem()--- for vconfig---5");
		VDUtil.AppControl_InitDbusConnection();
		VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.mycontents");
//		VDUtil.AppControl_DisableItem("picture", "org.volt.mycontents");				//for DF150113-02664 //DF150407-00901
		VDUtil.AppControl_DisableItem("broadcasting", "org.volt.mycontents");		
		VDUtil.AppControl_DisableItem("sound-customizer", "org.volt.mycontents");	
		VDUtil.AppControl_DisableItem("3d", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("energy-saving", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("setup", "org.volt.mycontents");		
		VDUtil.AppControl_DisableItem("self-diagnosis", "org.volt.mycontents");	
		VDUtil.AppControl_DisableItem("softwareupdate", "org.volt.mycontents");	
		VDUtil.AppControl_DisableItem("rgb-onlymode", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("voice_tutorial", "org.volt.mycontents");	
		VDUtil.AppControl_DisableItem("motion_tutorial", "org.volt.mycontents");	
		VDUtil.AppControl_DisableItem("smart-control-tutorial", "org.volt.mycontents");		
		VDUtil.AppControl_DisableItem("game-mode", "org.volt.mycontents");	
		VDUtil.AppControl_DisableItem("pip", "org.volt.mycontents");
		VDUtil.AppControl_DisableItem("picturesize", "org.volt.mycontents");
		VDUtil.AppControl_FiniDbusConnection();

		Log.e("menu-controller.js disableMusicMenu db/menu/refresh_menu to on");
		Vconf.setValue('db/menu/refresh_menu', 'on');
		
	};	
};

var menuController = new MenuController();
exports = menuController;
