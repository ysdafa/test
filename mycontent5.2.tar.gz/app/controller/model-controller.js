 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			 
 * @fileoverview  Model controller
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var LocalDB = Volt.require('app/controller/local-db.js');
var homeNewsCollection = Volt.require('app/models/home-news-collection.js');
var gamesCollection = Volt.require('app/models/games-collection.js');
var bAPIReady = false;

function isReady() {
    return bAPIReady;
}

function ready() {
    homeNewsCollection.dummy();
    gamesCollection.fetch(gamesCollection.mode.MODE_TEST);
    return;
    if (bAPIReady) {
        print('[model-controller.js] model-controller had been ready.');
        return;
    }
    LocalDB.ready()
        .then(onAPIReady);
}

function onAPIReady(result) {
    if (result) {
        print('[model-controller.js] API is ready - ' + result);
        bAPIReady = true;
        initialize();
    }
}

function initialize() {
    print('[model-controller.js] initialize');
    LocalDB.setResource()
        .then(function(){
            // Request team data
            homeNewsCollection.fetch({reset: true});
        }).fail(function(){});
}

exports = {
    ready: ready,
    isReady: isReady
}