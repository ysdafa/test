 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  View mgr, manage switching view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('modules/backbone.js');
var RouterController = Volt.require("app/controller/router-controller.js");
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var CommonInfo = Volt.require("app/common/define.js");

var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
//

var Router = Backbone.Router.extend({
	router : null,

    initialize: function() {
        this.on('route', function() {
            print('[router.js] URL : ' + Backbone.history.location.hash);
        });

        this.router = new RouterController();
        RunTimeInfo.router = this.router;
    },

    routes: {
        "main-view" : "mainview",
        "video-view" : "videoview",
        "photo-view" : "photoview",
        "music-view" : "musicview",
        "music-player" : "musicplayer",
        "conguides-view" : "conguidesview",
        "guide-usb" : "guideusb",
        "guide-pc" : "guidepc",
        "guide-mobile" : "guidemobile",
        "all-contentview" : "allcontentview",
        "welcome-page" : "welcomepage",
    },

    mainview: function() { 
    	print('[mainview]  enter main view ');
	// !!!!!!  Main view is same to allcontent view, when device add , onCategoryCallback will be called,
	// , switch view to all contents, so, just return .
    	return;
	/*
    	var DeviceProvider = Volt.require("app/models/device-provider.js");
    	if(DeviceProvider.getDeviceCount() < 1){
    		print('No device find,  create connection guide');
    		this.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
    	} else {
    		if(this.router.initViewType !== EViewType.eNoneView ){
    			print('[Router.js]  Content default: ', this.router.initViewType);
	    		this.router.switchView(this.router.initViewType, EViewSwitchAniType.eNoneAni);
    		}
    		else{
	    		print('[Router.js] All Content default');
	    		this.router.switchView(EViewType.eAllContentView, EViewSwitchAniType.eNoneAni);
    		}
    	}
    	*/
    },
    
	videoview : function(){
		this.router.switchView(EViewType.eVideoContentView, EViewSwitchAniType.eNoneAni);
	},
	
	photoview : function(){
		this.router.switchView(EViewType.ePhotoContentView, EViewSwitchAniType.eNoneAni);
	},

	conguidesview : function(){
		this.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
	},
	
	musicview : function(){
		this.router.switchView(EViewType.eMusicContentView, EViewSwitchAniType.eNoneAni);		
	},
	
	musicplayer : function(){
		this.router.switchToMusicPlayer(EViewType.eMusicPlayerView, EViewSwitchAniType.eNoneAni);			
	},

	recordview : function(){
	    this.router.switchView(EViewType.eRecordContentView, EViewSwitchAniType.eNoneAni);
	},

	guideusb : function(){
	    this.router.switchView(EViewType.eConnectUsbGuideView, EViewSwitchAniType.eNoneAni);
	},
	
	guidepc : function(){
	    this.router.switchView(EViewType.eConnectPcGuideView, EViewSwitchAniType.eNoneAni);
	},
	
	guidemobile : function(){
	    this.router.switchView(EViewType.eConnectMobileGuideView, EViewSwitchAniType.eNoneAni);
	},
	allcontentview : function(){
	    this.router.switchView(EViewType.eAllContentView, EViewSwitchAniType.eNoneAni);
	},
	welcomepage : function(){
	    this.router.switchView(EViewType.eWelcomePageView, EViewSwitchAniType.eNoneAni);
	},
});


exports = new Router();