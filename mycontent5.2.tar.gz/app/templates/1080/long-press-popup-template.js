/** 
 * @author clips engineer
 * @fileoverview Template for long press popup View
 * @date 2014/06/20
 * 
 * @version 0.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var LongPressPopupTemplate = {
	//template of option menu
	optionMenu: {
        type: 'cmOptionMenu',
		x: 0, y: 0, width: 414,
		text:[resMgr.getText('COM_SID_DELETE')],       
		custom: { //'focusable': true,
				longpress: true,},
    },
};



exports = LongPressPopupTemplate;
