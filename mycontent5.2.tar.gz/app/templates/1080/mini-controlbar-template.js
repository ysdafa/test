 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  mini music control bar template
 * @date    2014/08/08 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var MiniControlBarTemplate = {
    controlBar: {
    	type: 'widget',
    	x:860, y:0, width:802, height:144,
    	color: Volt.hexToRgb('#0f1826',100),
    	children: [
    		{
        		type: 'widget',
				x: 0, y: 21, width: 102, height: 102,
				cropOverflow: true,
				roundedCorners : {radius: 51.0, arcStep:1},  
				color: Volt.hexToRgb('#1F2B3D','100'),
				children:[
		    		{
		    			type: 'image',
		    			x:0,y:0,width:102,height:102,
		    			src: resMgr.getImgPath()+'/default_thumb/mc_music_thumbnail_play_default.png',
		    		},    	
		    		{
		    			id: 'thumb',
		    			type: 'image',
		    			x:0,y:0,width:102,height:102,
		    			src: '{{ thumbUrl }}',
		    		},
	    		]
    		},  		
    		{
    			id: 'infoArea',
				type: 'widget',
				x: 122, y: 36, width: 494, height: 70,
				color: Volt.hexToRgb('#FFFFFF',0),
    			opacity: 153,
    			custom: {focusable: true},				
				children: [
		    		{
		    			id: 'title',
		    			type: 'AutoScrollTextWidget',
		    			x:0,y:0,width:494,height:34,
		    		},
		        	{
		        		id: 'separator',
						type: 'widget',
						x:116, y:41, width:1, height:20,
						color: Volt.hexToRgb('#FFFFFF', '51'),
		        	},
		    		{
		    			id: 'artist',
		    			type: 'AutoScrollTextWidget',
		    			x:0,y:34,width:110,height:34,  			
		    		}, 		        	
		    		{
		    			id: 'album',
		    			type: 'AutoScrollTextWidget',
		    			x:125,y:34,width:277,height:34,
		    		},					
				],
    		},
    		{
    			id: 'preBtn',
    			type: 'image',
    			x:619,y:21,width:80,height:80,
    			src: resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev.png',
    			opacity: 153,
    			custom: {focusable: true},
    		},
    		{
    			id: 'pauseBtn',
    			type: 'image',
    			x:719,y:21,width:80,height:80,
    			src: resMgr.getImgPath()+'/music_player_icon/mc_play_icon_pause.png',
    			opacity: 153,
    			custom: {focusable: true},
    		},
    		{
    			id: 'nextBtn',
    			type: 'image',
    			x:819,y:21,width:80,height:80,
    			src: resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next.png',
    			opacity: 153,
    			custom: {focusable: true},
    		}, 
        	{
        		id: 'timeCurr',
        		type: 'text',
        		x: 122, y:104, width:100, height:24,
        		textColor: Volt.hexToRgb('#6E89B3', '60'),
        		text: '00:00',
        		font: '20px', 
        		verticalAlignment : 'center',
        		horizontalAlignment : 'left', 				
        	}, 
        	{
        		id: 'timeTotal',
        		type: 'text',
        		x: 840, y:104, width:100, height:24,
        		textColor: Volt.hexToRgb('#6E89B3', '60'),
        		text: '00:00',
        		font: '20px', 
        		verticalAlignment : 'center',
        		horizontalAlignment : 'left', 				
        	},        	
        	{
        		id: 'Proline',
        		type: 'Progress',
        		x: 178, y: 115, width:630, height:2,
        		unprocessColor: Volt.hexToRgb('#FFFFFF','100'),
        		processedColor: Volt.hexToRgb('#6E89B3','100'),        		
        		stepNumber: 1000,
        		currentStep: 0,
        		readOnly : false,        		
        		sliderDialSrc: resMgr.getImgPath()+'/progress/progress_active_a_n.png',
        		sliderDialFocusSrc: resMgr.getImgPath()+'/progress/progress_active_a_f.png',
        		sliderDialWidth : 20,
        		sliderDialHeight : 20,         		
        		custom: {focusable: true},
        	},        	
    	],
    	
    },
};

exports = MiniControlBarTemplate;
