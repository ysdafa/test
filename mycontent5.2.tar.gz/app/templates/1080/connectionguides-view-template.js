 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Device connection guide view template
 * @date    2014/07/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var guideTitle = resMgr.getText('COM_SID_CONNECT_YOUR_DEVICE');
var guideText = resMgr.getText('TV_SID_GUIDE_USE_SMARTHUB_PERSONAL_MULTIMEDIA');
var phoneText = resMgr.getText('COM_IDWS_MOIP_MOBILE_KR_MO');
var phoneDetailText = resMgr.getText('COM_SID_HOW_TO_CONNECT_MOBILE_DEVICE');
var pcText = resMgr.getText('COM_SID_PC');
var pcDetailText = resMgr.getText('COM_SID_HOW_TO_CONNECT_PC');
var usbText = resMgr.getText('COM_SID_USB');
var usbDetailText = resMgr.getText('COM_SID_HOW_TO_CONNECT_USB_DRIVE');

var connText = resMgr.getText('TV_SID_EMANUAL_SMART_FEATURES') +" > " + resMgr.getText('TV_SID_EMANUAL_USING_MY_CONTENTS_PANELS');
var downText = resMgr.getText('TV_SID_MIX_CHECK_OUT_MANUAL_TOPIC_MORE_WAY_CONNECT_DEVICE').replace('<<A>>',connText);
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;

var ConnectionGuidesViewTemplate = {
    container: {
		id: 'conGuidesBg',
        type: 'widget',
        x: 0, y: 0, width: mycontentWidth, height: 864,
        color: Volt.hexToRgb('#e3e3e6'),
        opacity: 255,
        children: [        
        		{
        			id:'connectGuideTitle',
					type: 'text',
					x: 100+(mycontentWidth-1920)/2, y: 75, width: 1720, height: 79,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 66px',
					textColor: {r:0x0f, g:0x18, b:0x26},
					opacity: 255,					
					text: guideTitle,
					custom : {
						multilingual : {
							SID : 'COM_SID_CONNECT_YOUR_DEVICE'
						}
					}
				},
        
				{
					id:'connectGuideText',
					type: 'text',
					x: 485+(mycontentWidth-1920)/2, y: 149, width: 950, height: 120,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 30px',
					textColor: {r:0x37, g:0x3c, b:0x42},
					opacity: 255,
					lineSpacing:5,
					text: guideText,
					custom : {
						multilingual : {
							SID : 'TV_SID_GUIDE_USE_SMARTHUB_PERSONAL_MULTIMEDIA'
							}
						}
				},
				
				{
					id: 'guide_mobile',
            		type: 'widget',
            		x:340+(mycontentWidth-1920)/2, y:274, width:606, height:146,
            		color: {r:0xe3, g:0xe3, b:0xe6},
            		opacity: 255,
            		children: [ 
                    {
            			id:'guide_mobile_btn',
            			type: 'cmNormalButton',
            			x:0,y:0,width:606,height:146,
            			color: {r:0xe3, g:0xe3, b:0xe6},
            			custom: {focusable: true},							            			
            		},
            		{
            			id: 'guide_mobile_icon',
            			type: 'image',
            			x: 220, y: 29, width: 23, height: 50,
            			fillMode:'fit',
            			src: resMgr.getImgPath()+'/Connection/home/home_conn_phone_n.png',
            			opacity: 179,

            		},
            		{				
						type: 'text',
						id: 'guide_mobile_text',
						x: 264, y: 29, width: 373, height: 60,
						horizontalAlignment : 'left',
						verticalAlignment : 'center',
						font: 'SamsungSmart_Light 42px',
						textColor: {r:0x78, g:0x78, b:0x78},
						opacity: 255,
						text: phoneText,
						custom : {
						multilingual : {
							SID : 'COM_IDWS_MOIP_MOBILE_KR_MO'
							}
						}
					},

					{
						type: 'text',
						id: 'guide_mobile_descrip',
						x: 0, y: 79, width: 606, height: 56,
						horizontalAlignment : 'center',
						verticalAlignment : 'center',
						font: 'SamsungSmart_Light 26px',
						textColor: {r:0x78, g:0x78, b:0x78},
						opacity: 255,
						text: phoneDetailText,
						custom : {
						multilingual : {
							SID : 'COM_SID_HOW_TO_CONNECT_MOBILE_DEVICE'
							}
						}
					},
					{
		    			type: 'widget',
						id:'guide_mobile_top_line',
		                x: 0, y: 0, width: 606, height: 1,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
		    		},
		    		{
		    			type: 'widget',
						id:'guide_mobile_left_line',
		                x: 0, y: 1, width: 1, height: 144,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
		    		},
		    		{
		    			type: 'widget',
						id:'guide_mobile_right_line',
		                x: 605, y: 1, width: 1, height: 144,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
		    		},
		    		{
		    			type: 'widget',
						id:'guide_mobile_bottom_line',
		                x: 0, y: 145, width: 606, height: 1,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
    				}
				
            		]	
				},
				{
					id: 'guide_usb',
            		type: 'widget',
            		x:974+(mycontentWidth-1920)/2,y:274,width:606,height:146,
            		color: {r:0xe3, g:0xe3, b:0xe6},
            		opacity: 255,           		
            		children: [
          
            		{
            			id:'guide_usb_btn',
            			type: 'cmNormalButton',
            			x:0,y:0,width:606,height:146,
            			color: {r:0xe3, g:0xe3, b:0xe6},
               			custom: {focusable: true},	            			
            		},
            		{
						id: 'guide_usb_icon',
            			type: 'image',
            			x: 220 , y: 29, width: 50, height: 50,
            			fillMode:'fit',
            			src: resMgr.getImgPath()+'/Connection/home/home_conn_usb_n.png',
            			opacity: 179,
            			
            		},
            		{	
            			id: 'guide_usb_text',
						type: 'text',
						x: 293, y: 29, width: 373, height: 60,
						horizontalAlignment : 'left',
						verticalAlignment : 'center',
						font: 'SamsungSmart_Light 42px',
						textColor: {r:0x37, g:0x3c, b:0x42},
						opacity: 255,
						text: usbText,
						custom : {
						multilingual : {
							SID : 'COM_SID_USB'
							}
						}
					},

					{
						type: 'text',
						id: 'guide_usb_descrip',
						x: 0, y: 79, width: 606, height: 56,
						horizontalAlignment : 'center',
						verticalAlignment : 'center',
						font: 'SamsungSmart_Light 26px',
						textColor: {r:0x37, g:0x3c, b:0x42},
						opacity: 255,
						text: usbDetailText,
						custom : {
						multilingual : {
							SID : 'COM_SID_HOW_TO_CONNECT_USB_DRIVE'
							}
						}
					},				
					{
		    			type: 'widget',
						id:'guide_usb_top_line',
		                x: 0, y: 0, width: 606, height: 1,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
		    		},
		    		{
		    			type: 'widget',
						id:'guide_usb_left_line',
		                x: 0, y: 1, width: 1, height: 144,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
		    		},
		    		{
		    			type: 'widget',
						id:'guide_usb_right_line',
		                x: 605, y: 1, width: 1, height: 144,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
		    		},
		    		{
		    			type: 'widget',
						id:'guide_usb_bottom_line',
		                x: 0, y: 145, width: 606, height: 1,
		                color: Volt.hexToRgb('#000000'),
		                opacity: 50,
    				}
				
            		]
					
				},
				{
					type: 'image',
					x: 340+(mycontentWidth-1920)/2, y: 445, width: 1240, height: 294,
					src: resMgr.getImgPath()+'/Connection/home/home_conn_image_01.png',
				},
				{
					id : 'connectDownText',
					type: 'text',
					x: 360+(mycontentWidth-1920)/2, y: 749, width: 1200, height: 115,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 22px',
					textColor: {r:0x78, g:0x78, b:0x78},
					lineSpacing:5,
					opacity: 255,
					text: downText,
				},				
			]
    },
};

exports = ConnectionGuidesViewTemplate;
