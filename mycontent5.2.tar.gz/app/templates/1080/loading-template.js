var resMgr = Volt.require('app/controller/resource-controller.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var LoadingTemplate = {
	dimWgt : {
		type:'widget',
		id:'loadDim',
		x:0,y:0,
		parent:scene,
		width:mycontentWidth,
		height:1080,
		color:{r:0,g:0,b:0,a:255*0.6}
	},
	/*
	viewLoading : {
		type: 'winsetLoading',
		x: 810,
		y: 476,
		//width:scene.width,
		//height:128,
		style: 4,
		text: resMgr.getText('COM_TV_SID_LOADING'),
		custom : {
			multilingual : {
				SID : 'COM_TV_SID_LOADING'
			}
		}
	}*/
	viewLoading : {
		imageNum : 63,
		x : (mycontentWidth - 301) / 2,      //810
		y : (1080 - 58 - 60 - 10) / 2,   //476
		imageWidth : 301,
		imageHeight : 58,
		gap : -(1080 * 0.009259),    //-10
		imageFPS : 15,
		textWidth: mycontentWidth,
		textHeight: 60,
		fontSize : 40,
		text : resMgr.getText('COM_TV_SID_LOADING'),
		textColor : {
			r : 255,
			g : 255,
			b : 255,
			a : 0.85*255
		}
	}
}
exports = LoadingTemplate;