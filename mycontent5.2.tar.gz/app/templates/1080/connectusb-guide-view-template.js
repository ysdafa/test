 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Device connection guide view template
 * @date    2014/07/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var connText = resMgr.getText('COM_TV_SID_CONNECT');
var plugText = resMgr.getText('COM_SID_PLUG_AND_PLAY_KR_YEONGEOL');	
var upDetailText = resMgr.getText('COM_SID_TV_DISPLAY_PHOTOS_VIDEOS_MUSIC_DRIVE');
var downDetailText = resMgr.getText('COM_SID_CONNECT_FLASH_HARD_USB_TV');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var offSet = RunTimeInfo.offSet;

var ConnectionusbGuidesViewTemplate = {
    container: {
		id: 'conusbGuidesBg',
        type: 'widget',
        x: 0, y: -216, width: mycontentWidth, height: 1080,
        color: Volt.hexToRgb('#eff1f1'),
        opacity: 255,
        children: [
				{
					id:'usb_page_title',
					type: 'text',
					x: 0, y: 145, width: mycontentWidth, height: 130,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 85px',
					textColor: {r:0x0f, g:0x18, b:0x27},
					opacity: 229,
					text: plugText,
					custom : {
						multilingual : {
							SID : 'COM_SID_PLUG_AND_PLAY_KR_YEONGEOL'
							}
						}
				},
				
				{
					id:'usb_page_uptext',
					type: 'text',
					x: 0, y: 290, width: mycontentWidth, height: 86,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 36px',
					textColor: {r:0x37, g:0x3c, b:0x42},
					opacity: 204,
					text: upDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_TV_DISPLAY_PHOTOS_VIDEOS_MUSIC_DRIVE'
							}
						}
				},
				
				{
					id: 'usb_icon',
            		type: 'image',
            		x:0,y:376,width:mycontentWidth,height:390,
            		src: '',
            		opacity: 255, 
            		fillMode: 'center',
				},
				
				{
					id:'usb_page_downtext',
					type: 'text',
					x: 0, y: 804, width: mycontentWidth, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: downDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_CONNECT_FLASH_HARD_USB_TV'
							}
						}
				},

				{
					id:'usb_closeBtn',
            		type: 'cmNormalButton',
             		x:799+offSet,y:923,width: 324,height:76, 
             		//custom: {focusable: true},
             		color: {r:0xef, g:0xf1, b:0xf1,a: 0},
             		custom : {
             			focusable: true,
						multilingual : {
							SID : 'COM_SID_CLOSE'
							}
						}       
				},
				{
				id:'return-arrow',
				type: 'cmHeaderButton',
				x:0,y:0,width:73,height:99,
                opacity : 0,
                color: Volt.hexToRgb('#000000',20),
                custom: { focusable: false },
				async: true,
				iconX: 18.5, 
				iconY: 31.5,
				iconWidth: 36,
                iconHeight: 36,
                iconImageSrcNormal: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_return.png'),
                iconImageSrcFocused: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_return.png'),

			},			        
			{
            	id: 'exit-arrow',
                type: 'cmHeaderButton', 
                color: Volt.hexToRgb('#000000',20),
                x: mycontentWidth-73, y: 0, width: 73, height: 99, opacity: 0,
                custom: { focusable: false },
				async: true,             
                iconImageSrcNormal: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_close.png'),
                iconImageSrcFocused: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_close.png'),
				iconX: 18.5, 
				iconY: 31.5,
				iconWidth: 36,
                iconHeight: 36
		           	
            },
				
			]
    }
};

exports = ConnectionusbGuidesViewTemplate;
