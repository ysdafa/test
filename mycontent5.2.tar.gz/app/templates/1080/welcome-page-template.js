 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  welcome page template
 * @date    2014/12/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var welcomeText = "Welcome to MY CONTENT";
var upDetailText1 = "Enjoy your personal photos, videos and music by connecting your Smart TV to your devices.";
var upDetailText2 = "MY CONTENT is all about you.";
var upDetailText3 = "Watch your videos. Listen to your music. Enjoy your photographs.";
var downDetailText1 = "You can connect USB and mobile devices and PCs. Select a <<A>> to learn how.";
var downDetailText2 = "Once you connect a device, a device icon, name and type will be shown.";

var WelcomePageTemplate = {
    container: {
		id: 'WelcomeBG',
		type: 'widget',
		x: 0, y: 0, width: 1920, height: 864,
		color: Volt.hexToRgb('#e3e3e6'),
		children: [        
				{
					id : 'title',
					type: 'text',
					x: 0, y: 40, width: 1920, height: 112,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SVD Light 66px',
					textColor: {r:0x0f, g:0x18, b:0x26},
					opacity: 255,
					text: welcomeText,
				},

				{
					id : 'upText1',
					type: 'text',
					x: 0, y: 100, width: 1920, height: 112,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SVD Light 28px',
					textColor: {r:0x37, g:0x3c, b:0x42},
					opacity: 255,
					text: upDetailText1,
				},
				
				{
					id : 'upText2',
					type: 'text',
					x: 0, y: 135, width: 1920, height: 112,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SVD Light 28px',
					textColor: {r:0x37, g:0x3c, b:0x42},
					opacity: 255,
					text: upDetailText2,
				},

				{
					id : 'upText3',
					type: 'text',
					x: 0, y: 169, width: 1920, height: 112,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SVD Light 28px',
					textColor: {r:0x37, g:0x3c, b:0x42},
					opacity: 255,
					text: upDetailText3,
				},
				
				{
					id : 'mainImage',
            		type: 'image',
            		x : 401, y:236, width:1118, height:270,
            		src: resMgr.getImgPath()+'/mc_image_welcome.png',
            		opacity: 255, 
				},
				
				{
					id : 'downText1',
					type: 'text',
					x: 0, y: 516, width: 1920, height: 112,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SVD Light 28px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 204,
					text: downDetailText1,
				},
				{
					id : 'downText2',
					type: 'text',
					x: 0, y: 550, width: 1920, height: 112,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SVD Light 28px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 204,
					text: downDetailText2,
				},
				
				{
					id:'connectDeviceButton',
            		type: 'cmNormalButton',
             		x : 760, y : 680, width : 400, height : 76, 
             		custom: {focusable: true},    
				}, 
		]
	},
};

exports = WelcomePageTemplate;