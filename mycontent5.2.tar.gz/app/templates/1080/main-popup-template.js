 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Main template
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */


var CommonInfo = Volt.require('app/common/define.js');
var colorList = CommonInfo.colorList;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mainView = Volt.require('app/views/main-view.js');

var MainPopupTemplate = {
	
	optionMenu: {
        type: 'cmOptionMenu',
		x: 1380, y: 100, width: 520,
		loop:false,
		renderNum: '{{ renderNum }}',
		//text: mainView.headerView.optionParam.firstOptionText,
		itemNum: '{{ textLength }}',
        subText: [{index:0,text:['a','b'],width:300,loop:false},
        		  {index:1,text:[' '],width:300,loop:false},],

      	custom:{
	        longpress: false,
	    },
    },
	/*
    optionMenu: {
        type: 'cmOptionMenu',
        x: 1380,
        y: 100,
        width: 520,
        renderNum: 4,
        text: [Volt.i18n.t('TV_SID_LANGUAGE'), Volt.i18n.t('TV_SID_SORT_BY_NAME'), Volt.i18n.t('TV_SID_SORY_BY_ID'), Volt.i18n.t('TV_SID_VIEW_DETAIL'), Volt.i18n.t('UID_FAVORITES'), Volt.i18n.t('TV_RECOMMENDATION_TYPE'), Volt.i18n.t('TV_SID_BLOCK_ADULT_CONTENT'), Volt.i18n.t('TV_SID_TUTORIAL')],
        subText: [
            {
                index: 0,
                text: [Volt.i18n.t('TV_SID_ENGLISH'), Volt.i18n.t('TV_SID_WAVE_ENGLISH')],
                width: 300,
                loop: true
            },
            {
                index: 3,
                text: [Volt.i18n.t('TV_SID_POPULAR'), Volt.i18n.t('TV_SID_PREFERENCE')],
                width: 300,
                loop: false
            },
            {
                index: 4,
                text: [Volt.i18n.t('COM_SID_OFF'), Volt.i18n.t('COM_SID_ON')],
                width: 300,
                loop: false
            },
		  ],
      	custom:{
	        longpress: false,
	    },

    },*/
		
    optionMenuIndices: {
        language: 0,
        sortByName: 1,
        sortById: 2,
        signIn: 5
    },

};

exports = MainPopupTemplate;
