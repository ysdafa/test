 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Main template
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var resMgr = Volt.require('app/controller/resource-controller.js');
var CommonInfo = Volt.require('app/common/define.js');
var colorList = CommonInfo.colorList;
var MycontentsShare = Volt.require('app/templates/1080/mycontents-share.js');
var homepanelInfo = MycontentsShare.homepanelInfo;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var MyContentsMainTemplate = {   
          
    header:{
    	id : 'header-container',
    	type: 'widget', x: 0, y: 0, width: mycontentWidth, height: 144,
        color: Volt.hexToRgb('#0f1826',0),
        children: [
			{
            	id: 'main-header-filter-option',
           		type: 'widget', x: mycontentWidth-100, y: 0, width: 245, height: 143, opacity: 0,
           		color: Volt.hexToRgb('#0f1826',0),
				children:[{
					id: 'main-head-filter-text',
	        		type: 'text', x:30 , y: 5, width: 215, height: 143,
	        		text: 'Filer by Photo',
	        		verticalAlignment : 'center',
	        		horizontalAlignment : 'right',
	                textColor : Volt.hexToRgb('#ffffff'),
	                opacity: 255*0.6,
	                ellipsize: true,
	                font : 'SamsungSmart_Light 30px'
	        		
	        	}]
	        },	
	        {
		                type: 'cmHeaderButton', 
						id: 'main-header-return-arrow',
		                x: 0, y: 0, width: 100, height: 144, 
		                opacity : 0,
		                custom: { focusable: false },
						async: true,
						iconX: 32, 
						iconY: 54,
						iconWidth: 36,
		                iconHeight: 36,
		                iconImageSrcNormal: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_return.png'),
		                iconImageSrcFocused: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_return.png'),
		            	
		            },
            {
                id: 'main-header-text',
                type: 'text',
				x: 36, y: 45, width: 1265, height: 55,
				//horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font:'50px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 204,
				text: resMgr.getText('TV_SID_MY_CONTENT_NAME'),				
				ellipsize: true,			
				custom : {
					multilingual : {
						DISABLE:'false',
						SID : 'TV_SID_MY_CONTENT_NAME'
					}
				},

            },           
            {					 
	        	type: 'widget', x: 100, y: 0, width: 1, height: 143,
				id: 'left-head-line',
				opacity : 0,
		        color: Volt.hexToRgb('#ffffff'),
	        },{					 
	        	type: 'widget', x: mycontentWidth-100, y: 0, width: 1, height: 143,
				id: 'right-head-line',
				opacity : 0,
		        color: Volt.hexToRgb('#ffffff'),
        	},{
                type: 'cmHeaderButton',
                id: 'main-header-icon-plus-sec',
                custom: {
                    focusable: true
                },
                x: mycontentWidth-99,
                y: 0,
                width: 100,
                height: 144,
                async: true,
                iconImageSrcNormal: '',//Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_setting_nor.png'),
                iconImageSrcFocused: '',//Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_setting_nor.png'),
				iconX: 33, 
				iconY: 55,
				iconWidth: 36,
                iconHeight: 36
            },  
            
			        {
		            	id: 'main-header-exit-arrow',
		                type: 'cmHeaderButton', 
		                x: mycontentWidth-99, y: 0, width: 100, height: 144, opacity: 0,
		                custom: { focusable: false },
						async: true,             
		                iconImageSrcNormal: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_close.png'),
		                iconImageSrcFocused: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_close.png'),
						iconX: 33, 
						iconY: 55,
						iconWidth: 36,
		                iconHeight: 36
		           	
		            },
	        {		
	        	id:'close-button-line',
	        	type: 'widget', x: mycontentWidth-100, y: 0, width: 1, height: 144,
				
				opacity : 0,
		        color: Volt.hexToRgb('#ffffff'),
        	},
	        
	        {	
        		id: 'device-mem-info', // + 123
        		type: 'widget', 
        		x: mycontentWidth-607-47 , y: 0, width: 324, height: 143,opacity: 0,
        		color: Volt.hexToRgb('#0f1826',0),
		        children:[{
	        		id: 'device-mem-progress',
	        		type: 'cmProgress',
	        		x: 0, y: 44, width:324, height:2,
	    			minValue: 0,
	    			value: 0,
	    			maxValue: 1000,
					reverse: false,
					active: true,
					custom: {focusable: false},
				},{
	        		id: 'device-mem-info-used',
	        		type: 'text', 
	        		x:0 , y: 56, width: 153, height: 28,opacity: 153,
	        		text: resMgr.getText('COM_SID_USED'),
	        		verticalAlignment : 'center',
	        		horizontalAlignment : 'left',
	                textColor : Volt.hexToRgb('#ffffff'),
	                //opacity: 0,	              
	                font : 'SamsungSmart_Light 23px',
					custom : {
						multilingual : {
							DISABLE : 'false',
							SID: 'COM_SID_USED',
						},
					},
				},
				{
	        		id: 'device-mem-info-used-text',
	        		type: 'text', 
	        		x:0 , y: 79, width: 153, height: 28,opacity: 153,
	        		text: '',
	        		verticalAlignment : 'center',
	        		horizontalAlignment : 'left',
	                textColor : Volt.hexToRgb('#ffffff'),
	                //opacity: 0,	              
	                font : 'SamsungSmart_Light 23px',
				
				},
				{
	        		id: 'device-mem-info-available',
	        		type: 'text', 
	        		x:126 , y: 56, width: 200, height: 28,opacity: 153,
	        		text: resMgr.getText('COM_AVAILABLE'),
	        		verticalAlignment : 'center',
	        		horizontalAlignment : 'right',
	                textColor : Volt.hexToRgb('#ffffff'),
	                //opacity: 0,	              
	                font : 'SamsungSmart_Light 23px',
	                custom : {
						multilingual : {
							DISABLE : 'false',
							SID: 'COM_AVAILABLE',
						},
					},
	              
				},
				{
	        		id: 'device-mem-info-available-text',
	        		type: 'text', 
	        		x:146, y: 79, width: 180, height: 28,opacity: 153,
	        		text: '',
	        		verticalAlignment : 'center',
	        		horizontalAlignment : 'right',
	                textColor : Volt.hexToRgb('#ffffff'),
	                //opacity: 0,	              
	                font : 'SamsungSmart_Light 23px',
	              
				}]
        	},
			{
				id: 'main-header-icon-filter-setting',
				type: 'image',
				opacity: 153,
				x: mycontentWidth-67, y: 54, width: 36, height: 36,
				src: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_setting.png'),
				
			},
        	]	        
    },
    
    dimWidget: {
        type: 'widget',
        x: mycontentWidth-320, y: 100, width: 254, height: 0,
        color: Volt.hexToRgb('#000000',0),
        cropOverflow : true,
        parent: scene,
    },

    loadingWidget: {
        type: 'widget',
        x: 0, y: 216, width: mycontentWidth, height: 1080-216,
        color: Volt.hexToRgb('#000000',0),
        parent: scene,
    },
		
    renderWidget: {
        type: 'widget',
        x: 0, y: 0, width: 0, height: 0,
        color: Volt.hexToRgb('#000000',0),
    },

    renderImageWidget: {
        type: 'image',
        x: 0, y: 0, width: 38, height: 38,
		color: CommonInfo.colorList.mPlusItemBGColor,
		src: homepanelInfo.selectArrowImage,

    },
    
    renderTextWidget: {
        type: 'text',
        x: 0, y: 0, width: 0, height: 0,
		textColor: CommonInfo.colorList.mWhiteColorOpacity,
		font:"SamsungSmart_Light 26px",
		horizontalAlignment : "left",
		verticalAlignment : "center",
    },
};

exports = MyContentsMainTemplate;
