 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Device connection guide view template
 * @date    2014/07/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var startText = resMgr.getText('COM_SID_LETS_GET_STARTED');	
var prepareUpText = resMgr.getText('COM_SID_ENJOY_PHOTOS_VIDEOS_MUSIC_MOBILE_TV');
var prepareDownText = resMgr.getText('COM_SID_WHAT_YOU_NEED_KR_DEVICE');
var prepareDownText2 = resMgr.getText('COM_SID_WIRELESS_ROUTHER_MOBILE_DEVICE');

var connectjoinText = resMgr.getText('COM_SID_JOIN_WIRELESS_NETWORK');
var connectUpText = resMgr.getText('COM_SID_TV_MOBILE_ON_SAMSE_WIRELESS_NETWORK');
var connectDownRouterText = resMgr.getText('COM_SID_A_WIRELESS_ROUTER');
var disconDownText = resMgr.getText('COM_SID_TV_NOT_CONNECTED_WIRELESS_NETWORK_NETWORK_SETTING');
var networkSetting = resMgr.getText('COM_TV_SID_NETWORK_SETTINGS');
var connectDownText = resMgr.getText('COM_SID_SET_MOBILE_CONNECT_SAME_NETWORK_TV');

var installDetailText = resMgr.getText('COM_SID_INSTALL_SMART_VIEW');
var installUpText = resMgr.getText('COM_SID_DOWNLOAD_FEE_MOBILE_APP_SMART_VIEW');
var intallDownText1 = resMgr.getText('COM_SID_SEARTCH_SMART_VIEW_APP_STORE');
var intallDownText2 = resMgr.getText('COM_SID_TAP_INSTALL_BUTTON');

var linkDetailText = resMgr.getText('COM_SID_MOBIEL_DEVICE_AND_TV');
var linkUpText = resMgr.getText('COM_SID_SMART_VIEW_LINK_PHONE_TABLET');
var conntoTV = resMgr.getText('MAPP_SID_CONNECT_TO_TV');
var linkDownText1 = resMgr.getText('COM_SID_OPEN_SMART_VIEW');
var linkDownText2 = resMgr.getText('COM_SID_TAP_CONNECTE_TO_TV');
var linkDownText3 = resMgr.getText('COM_SID_CHOOSE_TV_FROM_LIST');
var linkDownText4 = resMgr.getText('COM_SID_ENTER_PIN_SHOWN_TV');

var browserDetailText = resMgr.getText('COM_SID_START_EXPLORING');
var browserUpText = resMgr.getText('COM_SID_ENJOY_CONTENT_MOBILE_DEVICE_TV');
var browserDownText1 = resMgr.getText('COM_SID_TRANSAFER_SIMPLE_PUSH');
var browserDownText2 = resMgr.getText('TV_SID_ACEESS_MULTIMEDIA_MOBILE_SMARTHUB_UPPER');

var wirelessName = Vconf.getValue('db/menu/network/ap_name');
var downWirelessName = resMgr.getText('COM_SID_TV_CONNECTED_TO_COLON') + wirelessName;
var resolution = 1920;
try{
	resolution =  VDUtil.getResolution();
}
catch (ex){
	Log.f("[app.js][getResolution] Error:" + ex);
}	
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var offSet = RunTimeInfo.offSet;
var MobileGuidesViewTemplate = {
    Container: {   
		id: 'conmobileGuidesBg',
        type: 'widget',
        x: 0, y: -216, width: mycontentWidth, height: 1080,
        color: Volt.hexToRgb('#eff1f1'),
        opacity: 255,      
                
        children: [     
             			     
    		{
				id: 'mobile_prepare_page',
        		type: 'widget',
        		x:0,y:0,width: mycontentWidth,height:1080,
        		color: Volt.hexToRgb('#eff1f1'),
        		opacity: 255,             		         		
        		children: [
        		{
            		type: 'image',
            		x:728+offSet,y:15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_1_prepare_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_2_connect_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				},
        		         		          						
				{
					id:'mobile_prepare_page_title',
					type: 'text',
					x: 0, y: 145, width: mycontentWidth, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 85px',
					textColor: {r:0x0f, g:0x18, b:0x27,a: 255},
					//opacity: 229,
					text: startText,
					custom : {
						multilingual : {
							SID : 'COM_SID_LETS_GET_STARTED'
							}
						}				              
				},
				
				{
					id:'mobile_prepare_page_uptext',
					type: 'text',
					x: 0, y: 261, width: mycontentWidth, height: 88,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 36px',
					textColor: {r:0x37, g:0x3c, b:0x42, a: 255},
					//opacity: 204,
					text: prepareUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_ENJOY_PHOTOS_VIDEOS_MUSIC_MOBILE_TV'
							}
						}

				},
				
				{
            		type: 'image',
            		x:230+offSet,y:340,width: 1460,height:430,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_01.png',
            		opacity: 255, 
            		fillMode: 'center', 
				},
				
				{
					id:'mobile_prepare_page_downtext',
					type: 'text',					
					x: 0, y: 832, width: mycontentWidth, height: 50,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 42px',
					textColor: {r:0x18, g:0x18, b:0x18,a: 255},
					//opacity: 255,
					text: prepareDownText,
					custom : {
						multilingual : {
							SID : 'COM_SID_WHAT_YOU_NEED_KR_DEVICE',
							}
						}					
				}, 
				{
					id:'mobile_prepare_page_downtext2',
					type: 'text',					
					x: 0, y: 894, width: mycontentWidth, height: 46,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: prepareDownText2,
					custom : {
						multilingual : {
							SID : 'COM_SID_WIRELESS_ROUTHER_MOBILE_DEVICE',
							}
						}					
				},  				      		
        		]
			},
			
			{
				id: 'mobile_connect_page',
        		type: 'widget',
        		x:0,y:0,width: mycontentWidth,height:1080,
        		color: Volt.hexToRgb('#eff1f1'),
        		opacity: 255,             		         		
        		children: [
        		{
            		type: 'image',
            		x:728+offSet,y:15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_2_connect_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				},         		          						
				{
					id:'mobile_connect_page_title',
					type: 'text',
					x: 0, y: 145, width: mycontentWidth, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 85px',
					textColor: {r:0x0f, g:0x18, b:0x27},
					opacity: 229,
					text: connectjoinText,
					custom : {
						multilingual : {
							SID : 'COM_SID_JOIN_WIRELESS_NETWORK'
							}
						}
				},
				
				{
					id:'mobile_connect_page_uptext',
					type: 'text',
					x: 0, y: 261, width: mycontentWidth, height: 44,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 36px',
					textColor: {r:0x37, g:0x3c, b:0x42, a: 255},
					//opacity: 204,
					text: connectUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_TV_MOBILE_ON_SAMSE_WIRELESS_NETWORK'
							}
						}
				},
				
				{
            		type: 'image',
            		x:230+offSet,y:340,width: 1460,height:430,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_02.png',
            		opacity: 255, 
            		fillMode: 'center',             		
				},

				{
					id : 'mobile_wireless_name',
					type: 'text',
					x: 0, y: 724, width: mycontentWidth, height: 51,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 32px',
					textColor: {r:0x00, g:0x88, b:0xcc, a: 255},
					//opacity: 255,
					text: downWirelessName,
					custom : {
						multilingual : {
							SID : 'COM_SID_TV_CONNECTED_TO_COLON'
							}
						}
				},
				
				{
					id: 'mobile_connect_page_downtext',
					type: 'text',					
					x: 0, y: 822, width: mycontentWidth, height: 94,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 34px',
					textColor: {r:0x78, g:0x78, b:0x78, a: 255},
					//opacity: 255,
					lineSpacing:5,
					text: connectDownText,

				}, 
				      		
        		]
			},
			
			{
				id: 'mobile_disconnect_page',
        		type: 'widget',
        		x:0,y:0,width: mycontentWidth,height:1080,
        		color: Volt.hexToRgb('#eff1f1'),
        		opacity: 255,             		         		
        		children: [
        		{
            		type: 'image',
            		x:728+offSet,y:15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_2_connect_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				},   
 
				{
					id:'mobile_disconnect_page_title',
					type: 'text',
					x: 0, y: 145, width: mycontentWidth, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 85px',
					textColor: {r:0x0f, g:0x18, b:0x27, a: 255},
					//opacity: 229,
					text: connectjoinText,
					custom : {
						multilingual : {
							SID : 'COM_SID_JOIN_WIRELESS_NETWORK'
							}
						}		
				},
				
				{
					id:'mobile_disconnect_page_uptext',
					type: 'text',
					x: 0, y: 261, width: mycontentWidth, height: 44,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 36px',
					textColor: {r:0x37, g:0x3c, b:0x42, a: 255},
					//opacity: 204,
					text: connectUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_TV_MOBILE_ON_SAMSE_WIRELESS_NETWORK'
							}
						}			
				},
				
				{
            		type: 'image',
            		x:230+offSet,y:340,width: 1460,height:430,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_02_01.png',
            		opacity: 255,
            		fillMode: 'center',             		
				},
		
				{
					id : 'mobile_disconnect_page_DownRouterText',
					type: 'text',
					x: 0, y: 724, width: mycontentWidth, height: 36,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 32px',
					textColor: {r:0x00, g:0x88, b:0xcc, a: 255},
					//opacity: 255,
					text: connectDownRouterText,
					custom : {
						multilingual : {
							SID : 'COM_SID_A_WIRELESS_ROUTER'
							}
						}
				},
				
				{
					id: 'mobile_disconnect_page_downtext',
					type: 'text',
					x: 0, y: 832, width: mycontentWidth, height: 88,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					lineSpacing:5,
					font: 'SamsungSmart_Light 34px',
					textColor: {r:0x78, g:0x78, b:0x78,a: 255},
					//opacity: 255,
					text: disconDownText,
					custom : {
						multilingual : {
							SID : 'COM_SID_TV_NOT_CONNECTED_WIRELESS_NETWORK_NETWORK_SETTING'
							}
						}
				},
				
				{
					id:'mobile_networkSettingBtn',
            		type: 'cmNormalButton',
             		x:790+offSet,y:958,width: 340,height:76, 
             		color: {r:0xef, g:0xf1, b:0xf1, a: 0},
             		custom : {
             			focusable: true,
						multilingual : {
							SID : 'COM_TV_SID_NETWORK_SETTINGS'
							}
						}      
				},   				      		
        		]
			},
			
			{
				id: 'mobile_install_page',
        		type: 'widget',
        		x:0,y:0,width: mycontentWidth,height:1080,
        		color: Volt.hexToRgb('#eff1f1'),
        		opacity: 255,             		         		
        		children: [ 
        		{
            		type: 'image',
            		x:728+offSet,y:15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				},           		          		
				{
					id: 'mobile_install_page_title',
					type: 'text',
					x: 0, y: 145, width: mycontentWidth, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 85px',
					textColor: {r:0x0f, g:0x18, b:0x27,a: 255},
					//opacity: 229,
					text: installDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_INSTALL_SMART_VIEW'
							}
						}
				},
				
				{
					id: 'mobile_install_page_uptext',
					type: 'text',
					x: 0, y: 261, width: mycontentWidth, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 36px',
					lineSpacing: 3,
					textColor: {r:0x37, g:0x3c, b:0x42, a: 255},
					//opacity: 204,
					text: installUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_DOWNLOAD_FEE_MOBILE_APP_SMART_VIEW'
							}
						}
				},
				
				{
					id: 'mobile_install_img',
            		type: 'image',
            		x:230+offSet,y:340,width: 1460,height:430,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_03.png',
            		opacity: 255, 
            		fillMode: 'center', 
				},
				
				{
            		type: 'image',
            		x:630+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_1.png',
            		opacity: 255, 
            		
				},
				
				{
					id: 'mobile_install_page_downtext1',
					type: 'text',
					x: 332+offSet, y: 778, width: 620, height: 200,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					lineSpacing: 4,
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: intallDownText1,
					custom : {
						multilingual : {
							SID : 'COM_SID_SEARTCH_SMART_VIEW_APP_STORE'
							}
						}
				},
				
				{
            		type: 'image',
            		x:1260+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_2.png',
            		opacity: 255, 
            		
				},
				
				{
					id: 'mobile_install_page_downtext2',
					type: 'text',
					x: 965+offSet, y: 778, width: 620, height: 200,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					lineSpacing: 4,
					font: 'SamsungSmart_Light 34px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: intallDownText2,
					custom : {
						multilingual : {
							SID : 'COM_SID_TAP_INSTALL_BUTTON'
							}
						}
				},
				
        		]
			},
			
			{
				id: 'mobile_link_page',
        		type: 'widget',
        		x:0,y:0,width: mycontentWidth,height:1080,
        		color: Volt.hexToRgb('#eff1f1'),
        		opacity: 255,             		         		
        		children: [
        		
        		{
            		type: 'image',
            		x:728+offSet,y:15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				},    
        		          		          						
				{
					id: 'mobile_link_page_title',
					type: 'text',
					x: 0, y: 145, width: mycontentWidth, height: 100,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 85px',
					textColor: {r:0x0f, g:0x18, b:0x27,a :255},
					//opacity: 229,
					lineSpacing: 1,
					text: linkDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_MOBIEL_DEVICE_AND_TV'
							}
						}
				},
				
				{
					id: 'mobile_link_page_uptext',
					type: 'text',
					x: 0, y: 276, width: mycontentWidth, height: 44,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 36px',
					textColor: {r:0x37, g:0x3c, b:0x42,a: 255},
					//opacity: 204,
					text: linkUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_SMART_VIEW_LINK_PHONE_TABLET'
							}
						}
				},
				
				{
					id: 'mobile_link_img',
            		type: 'image',
            		x:230+offSet,y:340,width: 1460,height:430,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_04.png',
            		opacity: 255, 
            		fillMode: 'center', 
				},
				
				{
					id:'mobile_link_conntoTV',
					type: 'text',
//					x : (resolution == 1280 ? 780 : 720), y: (resolution==1280? 603 : 626), width: 127, height: 24,
					x : 665+offSet, y: 586, width: 220, height: 24,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 21px',
					textColor: {r:0x01, g:0x01, b:0x01},
					opacity: 230,
					text: conntoTV,
				},
				
				{
					id:'mobile_link_Devicename',
					type: 'text',
//					x : (resolution == 1280 ? 960 : 1010), y: (resolution==1280? 566 : 569), width: 202, height: 35, 
					x : 1027+offSet, y: 554, width: 235, height: 25, 
					horizontalAlignment : 'left',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 21px',
					textColor: {r:0x01, g:0x01, b:0x01},
					ellipsize : true,
					opacity: 230,
					text: '',
				},
				
	
				
				{
            		type: 'image',
            		x:387+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_1.png',
            		opacity: 255, 
            		
				},
				
				{
					id: 'mobile_link_page_downtext1',
					type: 'text',
					x: 232+offSet, y: 778, width: 340, height: 173,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					lineSpacing: 4,
					textColor: {r:0x78, g:0x78, b:0x78,a: 255},
					//opacity: 255,
					text: linkDownText1,
					custom : {
						multilingual : {
							SID : 'COM_SID_OPEN_SMART_VIEW'
							}
						}
				},
				
				{
            		type: 'image',
            		x:759+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_2.png',
            		opacity: 255, 
            		
				},
				
				{
					id: 'mobile_link_page_downtext2',
					type: 'text',
					x: 604+offSet, y: 778, width: 340, height: 173,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					lineSpacing: 4,
					textColor: {r:0x78, g:0x78, b:0x78,a: 255},
					//opacity: 255,
					text: linkDownText2,
					custom : {
						multilingual : {
							SID : 'COM_SID_TAP_CONNECTE_TO_TV'
							}
						}
				},
				
				
				{
            		type: 'image',
            		x:1131+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_3.png',
            		opacity: 255, 
            		
				},
				
				{
					id: 'mobile_link_page_downtext3',
					type: 'text',
					x: 976+offSet, y: 778, width: 340, height: 173,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					lineSpacing: 4,
					textColor: {r:0x78, g:0x78, b:0x78, a: 255},
					//opacity: 255,
					text: linkDownText3,
					custom : {
						multilingual : {
							SID : 'COM_SID_CHOOSE_TV_FROM_LIST'
							}
						}
				},
				
				
				{
            		type: 'image',
            		x:1500+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_4.png',
            		opacity: 255, 
            		
				},
				
				{
					id: 'mobile_link_page_downtext4',
					type: 'text',
					x: 1350+offSet, y: 778, width: 340, height: 173,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					lineSpacing: 4,
					textColor: {r:0x78, g:0x78, b:0x78, a: 255},
					//opacity: 255,
					text: linkDownText4,
					custom : {
						multilingual : {
							SID : 'COM_SID_ENTER_PIN_SHOWN_TV'
							}
						}

				}, 	
        		]
			},
			
			{
				id: 'mobile_browser_page',
        		type: 'widget',
        		x:0,y:0,width: mycontentWidth,height:1080,
        		color: Volt.hexToRgb('#eff1f1'),
        		opacity: 255,             		         		
        		children: [
        		{
            		type: 'image',
            		x:728+offSet,y:15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113+offSet, y: 0, width: 1, height: 55,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136+offSet,y: 15,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_s.png',
            		opacity: 255, 
				},             		          		
				
				{
					id: 'mobile_browser_page_title',
					type: 'text',
					x: 0, y: 135, width: mycontentWidth, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 85px',
					textColor: {r:0x0f, g:0x18, b:0x27,a: 255},
					//opacity: 229,
					text: browserDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_START_EXPLORING'
							}
						}
				},
				
				{
					id:'mobile_browser_list',
					type: 'text',
					x: 0, y: 235, width: 1920, height: 44,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 36px',
					textColor: {r:0x21, g:0x9e, b:0xe6},
					opacity: 255,
					//ellipsize: true,
					text: '',
				},
				
				{
					id: 'mobile_browser_page_uptext',
					type: 'text',
					x: 0, y: 261, width: mycontentWidth, height: 44,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'SamsungSmart_Light 36px',
					textColor: {r:0x37, g:0x3c, b:0x42, a: 255},
					//opacity: 204,
					text: browserUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_ENJOY_CONTENT_MOBILE_DEVICE_TV'
							}
						}
				},
				
				{
					id: 'mobile_browser_img',
            		type: 'image',
            		x:230+offSet,y:340,width: 1460,height:430,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_05.png',
            		opacity: 255, 
            		fillMode: 'center', 
				},
				/*
				{
            		type: 'image',
            		x:552+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_1.png',
            		opacity: 255, 
            		
				},*/
				
				{
					id: 'mobile_browser_page_downtext1',
					type: 'text',
					x: 188+offSet, y: 778, width: 757, height: 168,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					lineSpacing: 4,
					textColor: {r:0x78, g:0x78, b:0x78,a: 255},
					//opacity: 255,
					text: browserDownText1,
					custom : {
						multilingual : {
							SID : 'COM_SID_TRANSAFER_SIMPLE_PUSH'
							}
						}
				},
				/*
				{
            		type: 'image',
            		x:1340+offSet,y:730,width:30,height:30,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_2.png',
            		opacity: 255, 
            		
				},*/
				
				{
					id: 'mobile_browser_page_downtext2',
					type: 'text',
					x: 976+offSet, y: 778, width: 757, height: 168,
					horizontalAlignment : 'center',
					verticalAlignment : 'top',
					font: 'SamsungSmart_Light 34px',
					lineSpacing: 4,
					textColor: {r:0x78, g:0x78, b:0x78, a: 255},
					//opacity: 255,
					text: browserDownText2,
					custom : {
						multilingual : {
							SID : 'TV_SID_ACEESS_MULTIMEDIA_MOBILE_SMARTHUB_UPPER'
							}
						}
				},
				
				{
					id:'mobile_browser_showFilesBtn',
            		type: 'cmNormalButton',
             		x:595+offSet,y:945,width: 332,height:76, 
             		color: {r:0xef, g:0xf1, b:0xf1, a: 0},
             		custom : {
             			focusable: true,
						multilingual : {
							SID : 'COM_SID_WHOW_MY_FILES'
							}
						}     
				},
				
				{
					id:'mobile_browser_closeBtn',
            		type: 'cmNormalButton',
             		x:941+offSet,y:945,width: 332,height:76,
             		color: {r:0xef, g:0xf1, b:0xf1, a: 0}, 
             		custom : {
             			focusable: true,
						multilingual : {
							SID : 'COM_SID_CLOSE'
							}
						}      
				},							      		
        		]
			},
			
			
			{
				id:'mobile_navi_l',
        		type: 'image',
        		x:88+offSet,y:515,width:134,height:134,
        		src: resMgr.getImgPath()+'/Connection/navi/connect_navi_l_n.png',
        		opacity: 255, 
			},
			
			{
				id:'mobile_navi_r',
        		type: 'image',
        		x:1698+offSet,y:515,width:134,height:134,
        		src: resMgr.getImgPath()+'/Connection/navi/connect_navi_r_n.png',
        		opacity: 255, 
			}, 
			
			{
				id : 'mute_focus',
				type : 'cmNormalButton',
				x : 0, y :0, width : 1, height : 1,
				color: { r: 255, g: 255, b: 255, a: 255 },
				custom : {focusable : true},
			},

			{
				id:'return-arrow',
				type: 'cmHeaderButton',
				x:0,y:0,width:73,height:99,
                opacity : 0,
                color: Volt.hexToRgb('#000000',20),
                custom: { focusable: false },
				async: true,
				iconX: 18.5, 
				iconY: 31.5,
				iconWidth: 36,
                iconHeight: 36,
                iconImageSrcNormal: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_return.png'),
                iconImageSrcFocused: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_return.png'),

			},			        
			{
            	id: 'exit-arrow',
                type: 'cmHeaderButton', 
                color: Volt.hexToRgb('#000000',20),
                x: mycontentWidth-73, y: 0, width: 73, height: 99, opacity: 0,
                custom: { focusable: false },
				async: true,             
                iconImageSrcNormal: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_close.png'),
                iconImageSrcFocused: Volt.getRemoteUrl(resMgr.getImgPath()+'/common/comn_icon_tm_close.png'),
				iconX: 18.5, 
				iconY: 31.5,
				iconWidth: 36,
                iconHeight: 36
		           	
            },
             	

		]
	},
        

};

exports = MobileGuidesViewTemplate;
