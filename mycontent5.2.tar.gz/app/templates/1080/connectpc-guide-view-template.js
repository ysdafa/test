 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Device connection guide view template
 * @date    2014/07/22 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var startText = resMgr.getText('COM_SID_LETS_GET_STARTED');		
var prepareUpText = resMgr.getText('COM_SID_ENJOJY_CONTEST_PC_TV_BIG_SCREEN');
var prepareDownText = resMgr.getText('COM_SID_WHAT_YOU_NEED_KR_DEVICE') + resMgr.getText('COM_SID_PC_RUNNING_WINDOWS78_WIRELESS_ROUTER');

var connectjoinText = resMgr.getText('COM_SID_JOIN_WIRELESS_NETWORK');
var connectUpText = resMgr.getText('COM_SID_MAKE_SURE_TV_PC_SAME_WIRELESS');
var connectDownBlueText = resMgr.getText('COM_SID_TV_CONNECTED_TO_COLON');
var connectDownText = resMgr.getText('COM_SID_SET_PC_WIFI_CONNECT_SAME_NETWORK_TV');
var connectDownRouterText = resMgr.getText('COM_SID_A_WIRELESS_ROUTER');
var disconDownText = resMgr.getText('COM_SID_TV_NOT_CONNECTED_WIRELESS_NETWORK_NETWORK_SETTING');
var networkSetting = resMgr.getText('COM_TV_SID_NETWORK_SETTINGS');

var installDetailText = resMgr.getText('COM_SID_INSTALL_SMART_VIEW');
var installUpText = resMgr.getText('COM_SID_DOWNLAOD_FREE_PC_SW_SMART_VIEW');
var intallDownText1 = resMgr.getText('COM_SID_MIX_YOUR_WEB_BROWSER').replace('<<A>>','http://www.samsung.com/smartview2');
var intallDownText2 = resMgr.getText('COM_SID_CLICK_DOWNLOAD');

var linkDetailText = resMgr.getText('COM_SID_PC_AND_TV');
var linkUpText = resMgr.getText('COM_SID_USE_SMART_VIEW_PC_TV');
var conntoTV = resMgr.getText('MAPP_SID_CONNECT_TO_TV');
var linkDownText1 = resMgr.getText('COM_SID_OPEN_SMART_VIEW_2'); 
var linkDownText2 = resMgr.getText('COM_SID_CLICK_CONNECT_TV');
var linkDownText3 = resMgr.getText('COM_SID_CHOOSE_TV_FROM_LIST');
var linkDownText4 = resMgr.getText('COM_SID_ENTER_PIN_SHOWN_TV_KR_PC');

var browserDetailText = resMgr.getText('COM_SID_START_EXPLORING');
var browserUpText = resMgr.getText('COM_SID_ENJOJY_CONTEST_PC_TV_BIG_SCREEN');
var browserDownText1 = resMgr.getText('COM_SID_SEND_MULTIMEDIA_FROM_PC_TV');
var browserDownText2 = resMgr.getText('TV_SID_ACEESS_MULTIMEDIA_PC_SMARTHUB_UPPER');



var PcGuidesViewTemplate = {
    Container: {
		id: 'conpcGuidesBg',
        type: 'widget',
        x: 0, y: -216, width: 1920, height: 1080,
        color: Volt.hexToRgb('#f2f2f4'),
        opacity: 255,
        
        children: [
        	{
        		id: 'pc_prepare_page',
	    		type: 'widget',
	    		x:0,y:0,width:1920,height:1080,
	    		color: Volt.hexToRgb('#f2f2f4'),
	    		opacity: 255, 
	    		children: [
	    		{
            		type: 'image',
            		x:728,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_1_prepare_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_2_connect_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				},
				{
					type: 'text',
					x: 0, y: 145, width: 1920, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 70px',
					textColor: {r:0, g:0, b:0},
					opacity: 229,
					text: startText,
					custom : {
						multilingual : {
							SID : 'COM_SID_LETS_GET_STARTED'
							}
						}
				},
				
				{
					type: 'text',
					x: 0, y: 259, width: 1920, height: 40,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 30px',
					textColor: {r:0x66, g:0x66, b:0x69},
					opacity: 204,
					text: prepareUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_ENJOY_PHOTOS_VIDEOS_MUSIC_MOBILE_TV'
							}
						}
				},
				
				{
            		type: 'image',
            		x:0,y:376,width:1920,height:356,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_pc_01.png',
            		opacity: 255,
            		fillMode: 'center', 
            		
				},
				
				{
					type: 'text',
					x: 0, y: 804, width: 1920, height: 72,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: prepareDownText,
					custom : {
						multilingual : {
							SID : 'COM_SID_WHAT_YOU_NEED_KR_DEVICE' + 'COM_SID_WIRELESS_ROUTHER_MOBILE_DEVICE'
							}
						}

				},
				    		
	    		] 	
        	},
        	
        	{
        		id: 'pc_connect_page',
	    		type: 'widget',
	    		x:0,y:0,width:1920,height:1080,
	    		color: Volt.hexToRgb('#f2f2f4'),
	    		opacity: 255, 
	    		children: [
	    		{
            		type: 'image',
            		x:728,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
	
				{
            		type: 'image',
            		x:830,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_2_connect_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				}, 
	    						
				{
					type: 'text',
					x: 0, y: 145, width: 1920, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 70px',
					textColor: {r:0, g:0, b:0},
					opacity: 229,
					text: connectjoinText,
					custom : {
						multilingual : {
							SID : 'COM_SID_JOIN_WIRELESS_NETWORK'
							}
						}
				},
				
				{
					type: 'text',
					x: 0, y: 259, width: 1920, height: 40,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 30px',
					textColor: {r:0x66, g:0x66, b:0x69},
					opacity: 204,
					text: connectUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_MAKE_SURE_TV_PC_SAME_WIRELESS'
							}
						}
				},
				
				{
            		type: 'image',
            		x:0,y:376,width:1920,height:390,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_pc_02.png',
            		opacity: 255, 
            		fillMode: 'center', 
				},
				
				{
            		type: 'image',
            		x:683,y:463,width:87,height:70,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_02_wifi.png',
            		opacity: 255, 
				},
				
				{
					id:'pc_conn_list',
					type: 'text',
					x: 0, y: 804, width: 1920, height: 36,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 26px',
					textColor: {r:0x00, g:0x88, b:0xcc},
					opacity: 255,
					text: '',
					
				},
				
				{
					type: 'text',
					x: 0, y: 850, width: 1920, height: 36,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: connectDownText,
					custom : {
						multilingual : {
							SID : 'COM_SID_SET_PC_WIFI_CONNECT_SAME_NETWORK_TV'
							}
						}
					
				},
					    		
	    		] 	
        	},
        	
        	{
        		id: 'pc_disconnect_page',
	    		type: 'widget',
	    		x:0,y:0,width:1920,height:1080,
	    		color: Volt.hexToRgb('#f2f2f4'),
	    		opacity: 255, 
	    		children: [
	    		
	    		{
            		type: 'image',
            		x:728,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},

				{
					type: 'widget',
                	x: 807, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_2_connect_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				}, 

				{
					type: 'text',
					x: 0, y: 145, width: 1920, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 70px',
					textColor: {r:0, g:0, b:0},
					opacity: 229,
					text: connectjoinText,
					custom : {
						multilingual : {
							SID : 'COM_SID_SET_PC_WIFI_CONNECT_SAME_NETWORK_TV'
							}
						}
				},
				
				{
					type: 'text',
					x: 0, y: 259, width: 1920, height: 40,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 30px',
					textColor: {r:0x66, g:0x66, b:0x69},
					opacity: 204,
					text: connectUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_SET_PC_WIFI_CONNECT_SAME_NETWORK_TV'
							}
						}
				},
				
				{
            		type: 'image',
            		x:0,y:376,width:1920,height:390,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_pc_02.png',
            		opacity: 255, 
            		fillMode: 'center', 
				},
				
				{
            		type: 'image',
            		x:683,y:463,width:87,height:70,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_02_wifi.png',
            		opacity: 255, 
				},
				
				{
            		type: 'image',
            		x:803,y:664,width:24,height:24,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_02_not_network.png',
            		opacity: 255, 
				},
				{
            		type: 'image',
            		x:1099,y:664,width:24,height:24,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_02_not_network.png',
            		opacity: 255, 
				},
				{
					type: 'text',
					x: 0, y: 724, width: 1920, height: 36,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 26px',
					textColor: {r:0x00, g:0x88, b:0xcc},
					opacity: 255,
					text: connectDownRouterText,
					custom : {
						multilingual : {
							SID : 'COM_SID_A_WIRELESS_ROUTER'
							}
						}
				},
				
				{
					type: 'text',
					x: 0, y: 838, width: 1920, height: 72,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: disconDownText,
					custom : {
						multilingual : {
							SID : 'COM_SID_TV_NOT_CONNECTED_WIRELESS_NETWORK_NETWORK_SETTING'
							}
						}
				},
				
				{
					id:'pc_networkSettingBtn',
            		type: 'cmNormalButton',
             		x:798,y:958,width: 324,height:76, 
             		custom : {
             			focusable: true,
						multilingual : {
							SID : 'COM_TV_SID_NETWORK_SETTINGS'
							}
						}      
				},
      	    		
	    		] 	
        	},
        	
        	{
        		id: 'pc_install_page',
	    		type: 'widget',
	    		x:0,y:0,width:1920,height:1080,
	    		color: Volt.hexToRgb('#f2f2f4'),
	    		opacity: 255, 
	    		children: [
	    		{
            		type: 'image',
            		x:728,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_3_install_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_n.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				}, 				
				{
					type: 'text',
					x: 0, y: 145, width: 1920, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 70px',
					textColor: {r:0, g:0, b:0},
					opacity: 229,
					text: installDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_INSTALL_SMART_VIEW'
							}
						}
				},
				
				{
					type: 'text',
					x: 0, y: 259, width: 1920, height: 40,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 30px',
					textColor: {r:0x66, g:0x66, b:0x69},
					opacity: 204,
					text: installUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_DOWNLAOD_FREE_PC_SW_SMART_VIEW'
							}
						}
				},
				
				{
					id: 'pc_install_img',
            		type: 'image',
            		x:0,y:376,width:1920,height:390,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_pc_03.png',
            		opacity: 255, 
            		fillMode: 'center',
				},
				
				{
            		type: 'image',
            		x:378,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_1.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 406, y: 804, width: 560, height: 108,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: intallDownText1,
					custom : {
						multilingual : {
							SID : 'COM_SID_MIX_YOUR_WEB_BROWSER'
							}
						}
				},
				
				{
            		type: 'image',
            		x:990,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_2.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 1018, y: 804, width: 560, height: 36,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0, g:0, b:0},
					opacity: 255,
					text: intallDownText2,
					custom : {
						multilingual : {
							SID : 'COM_SID_CLICK_DOWNLOAD'
							}
						}

				},
	    		
	    		] 	
        	},
        	
        	{
        		id: 'pc_link_page',
	    		type: 'widget',
	    		x:0,y:0,width:1920,height:1080,
	    		color: Volt.hexToRgb('#f2f2f4'),
	    		opacity: 255, 
	    		children: [
	    		{
            		type: 'image',
            		x:728,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_4_link_s.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_n.png',
            		opacity: 255, 
				}, 
	    		
				{
					type: 'text',
					x: 0, y: 145, width: 1920, height: 90,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 70px',
					textColor: {r:0, g:0, b:0},
					opacity: 229,
					text: linkDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_PC_AND_TV'
							}
						}
				},
				
				{
					type: 'text',
					x: 0, y: 259, width: 1920, height: 40,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 30px',
					textColor: {r:0x66, g:0x66, b:0x69},
					opacity: 204,
					text: linkUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_USE_SMART_VIEW_PC_TV'
							}
						}
				},
				
				{
					id: 'pc_link_img',
            		type: 'image',
            		x:0,y:376,width:1920,height:390,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_pc_04.png',
            		opacity: 255, 
            		fillMode: 'center',
				},
				
				{
					type: 'text',
					x: 752, y: 625, width: 127, height: 24,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 17px',
					textColor: {r:0xFF, g:0xFF, b:0xFF},
					opacity: 255,
					text: conntoTV,
				},
				
				{
					id:'pc_link_Devicename',
					type: 'text',
					x: 1034, y: 590, width: 240, height: 28,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 17px',
					textColor: {r:0xFF, g:0xFF, b:0xFF},
					opacity: 255,
					text: '',
				},
				
				{
            		type: 'image',
            		x:310,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_1.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 340, y: 804, width: 290, height: 72,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: linkDownText1,
					custom : {
						multilingual : {
							SID : 'COM_SID_OPEN_SMART_VIEW_2'
							}
						}
				},
				
				{
            		type: 'image',
            		x:644,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_2.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 674, y: 804, width: 290, height: 72,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: linkDownText2,
					custom : {
						multilingual : {
							SID : 'COM_SID_CLICK_CONNECT_TV'
							}
						}
				},
				
				
				{
            		type: 'image',
            		x:978,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_3.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 1008, y: 804, width: 290, height: 72,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: linkDownText3,
					custom : {
						multilingual : {
							SID : 'COM_SID_CHOOSE_TV_FROM_LIST'
							}
						}
				},
				
				
				{
            		type: 'image',
            		x:1312,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_4.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 1342, y: 804, width: 290, height: 72,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: linkDownText4,
					custom : {
						multilingual : {
							SID : 'COM_SID_ENTER_PIN_SHOWN_TV_KR_PC'
							}
						}

				}, 
	    		
	    		] 	
        	},
        	
        	{
        		id: 'pc_browser_page',
	    		type: 'widget',
	    		x:0,y:0,width:1920,height:1080,
	    		color: Volt.hexToRgb('#f2f2f4'),
	    		opacity: 255, 
	    		children: [
	    		{
            		type: 'image',
            		x:728,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 807, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:830,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 909, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:932,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1011, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1034,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/obe_step_comp.png',
            		opacity: 255, 
				},
				{
					type: 'widget',
                	x: 1113, y:0, width: 1, height: 40,
                	color: Volt.hexToRgb('#000000'),
                	opacity: 255*0.1,
    		    },
				{
            		type: 'image',
            		x:1136,y: 0,width:55,height:40,
            		src: resMgr.getImgPath()+'/Connection/step/connect_step_5_brower_s.png',
            		opacity: 255, 
				},
	    		
				{
					type: 'text',
					x: 0, y: 168, width: 1920, height: 80,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 70px',
					textColor: {r:0, g:0, b:0},
					opacity: 229,
					text: browserDetailText,
					custom : {
						multilingual : {
							SID : 'COM_SID_START_EXPLORING'
							}
						}
				},
				{
					id:'pc_browser_list',
					type: 'text',
					x: 0, y: 250, width: 1920, height: 40,
					horizontalAlignment : 'center',
					verticalAlignment : 'bottom',
					font: 'Helvetica 30px',
					textColor: {r:0x35, g:0x9e, b:0xd9},
					opacity: 204,
					text: '',
				},
				{
					type: 'text',
					x: 0, y: 295, width: 1920, height: 40,
					horizontalAlignment : 'center',
					verticalAlignment : 'center',
					font: 'Helvetica 30px',
					textColor: {r:0x66, g:0x66, b:0x69},
					opacity: 204,
					text: browserUpText,
					custom : {
						multilingual : {
							SID : 'COM_SID_ENJOJY_CONTEST_PC_TV_BIG_SCREEN'
							}
						}
				},
				
				{
					id: 'pc_browser_img',
            		type: 'image',
            		x:0,y:376,width:1920,height:390,
            		src: resMgr.getImgPath()+'/Connection/img/rc_cg_pc_05.png',
            		opacity: 255, 
            		fillMode: 'center',
				},
				
				{
            		type: 'image',
            		x:381,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_1.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 411, y: 804, width: 440, height: 108,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: browserDownText1,
					custom : {
						multilingual : {
							SID : 'COM_SID_SEND_MULTIMEDIA_FROM_PC_TV'
							}
						}
				},
				
				{
            		type: 'image',
            		x:949,y:804,width:22,height:36,
            		src: resMgr.getImgPath()+'/Connection/number/connect_num_2.png',
            		opacity: 255, 
            		
				},
				
				{
					type: 'text',
					x: 979, y: 804, width: 440, height: 108,
					horizontalAlignment : 'left',
					verticalAlignment : 'top',
					font: 'Helvetica 26px',
					textColor: {r:0x78, g:0x78, b:0x78},
					opacity: 255,
					text: browserDownText2,
					custom : {
						multilingual : {
							SID : 'TV_SID_ACEESS_MULTIMEDIA_PC_SMARTHUB_UPPER'
							}
						}
				},
				
				{
					id:'pc_browser_showFilesBtn',
            		type: 'cmNormalButton',
            		x:611,y:923,width: 362,height:76,
             		custom : {
             			focusable: true,
						multilingual : {
							SID : 'COM_SID_WHOW_MY_FILES'
							}
						}     
				},
				
				{
					id:'pc_browser_closeBtn',
            		type: 'cmNormalButton',
            		x:987,y:923,width: 322,height:76,
             		custom : {
             			focusable: true,
						multilingual : {
							SID : 'COM_SID_CLOSE'
							}
						}       
				},				 
	    		] 	
        	},
       	
   	
       		{
				id:'pc_navi_l',
        		type: 'image',
        		x:88,y:515,width:134,height:134,
        		src: resMgr.getImgPath()+'/Connection/navi/connect_navi_l_n.png',
        		opacity: 255, 
			},
			
			{
				id:'pc_navi_r',
        		type: 'image',
        		x:1698,y:515,width:134,height:134,
        		src: resMgr.getImgPath()+'/Connection/navi/connect_navi_r_n.png',
        		opacity: 255, 
			},
						
			{
				id : 'mute_focus',
				type : 'cmNormalButton',
				x : 0, y :0, width : 1, height : 1,
				color: { r: 255, g: 255, b: 255, a: 255 },
				custom : {focusable : true},
			}
        ]
            
       
    },
  
};

exports = PcGuidesViewTemplate;
