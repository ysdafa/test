var resMgr = Volt.require('app/controller/resource-controller.js');
var infotmationText = resMgr.getText('COM_TEXT_INFORMATION_P')//"Information"
var titleText = resMgr.getText('COM_SID_TITLE')	//"Title"	
var createdText = resMgr.getText('TV_SID_CREATED_COLON').replace(':', '')	//"Created"	
var formatText = resMgr.getText('TV_SID_FORMAT_COLON').replace(':', '')	//"Format"	
var sizeText = resMgr.getText('TV_SID_SIZE_COLON').replace(':', '')	//"Size"	
var resolutionText = resMgr.getText('TV_SID_RESOLUTION').replace(':', '')	//"Resolution"	
var locationText = resMgr.getText('TV_SID_LOCATION').replace(':', '')	//"Location"	
var genreText = resMgr.getText('COM_SID_GENRE')  //"Genre"
var channelText = resMgr.getText('UID_M_M_CHANNEL')  //"Channel",
var dateText = resMgr.getText('COM_SID_DATE')  //"Date",
var durationText = resMgr.getText('IDWS_MOIP_DURATION_KR_BLANK').replace(':', '')  //"Duration"
var lastsavedText = resMgr.getText('COM_SID_LAST_SAVED_DATE') //"Last saved date "
//HD/SD 
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;


var InfoWindowTemplate = {

	info_window_template_photo:
	{
		/*
		Title : I love you
		Created: 2015.01.01
		Format : JPEG
		Size : 132 KB
		Resolution : 1920X1280
		Location : Dix USB > Folder 1
		*/
		type: 'widget',
	    x: 0, y: (1080 - 579) / 2, width: mycontentWidth, height : 579,
	    color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type: 'widget',//BG
		    	x: 0, y: 1, width: mycontentWidth, height : 570,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
				type: 'widget',
				x : 0, y: 0, width: mycontentWidth, height: 1,
				color: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.05,
				
			},
			{
				type: 'widget',
				x : 0, y: 571, width: mycontentWidth, height: 2,
				color: Volt.hexToRgb('#000000'),
				opacity: 255*0.15,
				
			},
			{
	    		type: 'image',
	    		x : 0, y: 573, width: mycontentWidth, height: 6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			},
			{
		        type : 'text',//Information
		        x : 460+(mycontentWidth-1920)/2, y: 0, width : 1122, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255,		        
		        font : 'SamsungSmart_Light 46px',
		        text : resMgr.getText('COM_TEXT_INFORMATION_P'),
		        custom: {
					multilingual : {
						SID : 'COM_TEXT_INFORMATION_P'
					}
					
				}
	    	},
	    	{
				type: 'widget',//line
                x: 460+(mycontentWidth-1920)/2, y: 97, width: 1002, height: 1,
                color: Volt.hexToRgb('#f2f2f2'),
                opacity: 255*0.6,
			},
			{
				type: 'text',//title
				x: 460+(mycontentWidth-1920)/2, y: 117, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_TITLE') +':',
				custom: {
					multilingual : {
						SID : 'TV_SID_TITLE_COLON'
					}
					
				}
				
			},
	
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117, width: 538, height: 48,
    			id: 'content-title-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ title }}'
    		},
    		
			{
				type: 'text',
				x: 460+(mycontentWidth-1920)/2, y: 117+48, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('TV_SID_CREATED_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_CREATED_COLON'
					}
					
				}

			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ created }}'
    		},
    		
			{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*2, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_FORMAT_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_FORMAT_COLON'
					}
				}
    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*2, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ format }}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*3, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_SIZE_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_SIZE_COLON'
					}
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*3, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ size }}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*4, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_RESOLUTION'),
				custom: {
					multilingual : {
						SID : 'TV_SID_RESOLUTION'
					}
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*4, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ resolution}}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*5, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_LOCATION'),

    		},
    		{
    			type: 'text',
				id: 'content-location-id',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*5, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ location}}'

    		},
    		
    		{
				type : 'cmNormalButton',
				id : 'common-message-box-btn1',
				x : 825+(mycontentWidth-1920)/2, y : 550-30-66, width : 270, height : 66,
				custom: {focusable: true},  
	    	},
			
		],
    },	

	info_window_template_music:
	{
		/*
		Title : I love you
		Duration : 03:11
		Last saved date : 2012.09.23
		Size : 3.5MB
		Genre : 
		Location : Dix USB > Folder 2
		*/
		type: 'widget',
	    x: 0, y: (1080 - 723)/ 2, width: mycontentWidth, height : 723,
	    color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type: 'widget',//BG
		    	x: 0, y: 1, width: mycontentWidth, height : 714,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
				type: 'widget',
				x : 0, y: 0, width: mycontentWidth, height: 1,
				color: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.05,
				
			},
			{
				type: 'widget',
				x : 0, y: 715, width: mycontentWidth, height: 2,
				color: Volt.hexToRgb('#000000'),
				opacity: 255*0.15,
				
			},
			{
	    		type: 'image',
	    		x : 0, y: 717, width: mycontentWidth, height: 6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			},
			{
		        type : 'text',//Information
		        x : 460+(mycontentWidth-1920)/2, y: 0, width : 1122, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255,		        
		        font : 'SamsungSmart_Light 46px',
		        text : resMgr.getText('COM_TEXT_INFORMATION_P'),
		        custom: {
					multilingual : {
						SID : 'COM_TEXT_INFORMATION_P'
					}
					
				}
	    	},
	    	{
				type: 'widget',//line
                x: 460+(mycontentWidth-1920)/2, y: 97, width: 1002, height: 1,
                color: Volt.hexToRgb('#f2f2f2'),
                opacity: 255*0.6,
			},
			{
				type: 'text',//title
				x: 460+(mycontentWidth-1920)/2, y: 117, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_TITLE') +':',
				custom: {
					multilingual : {
						SID : 'TV_SID_TITLE_COLON'
					}
					
				}

			},

			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117, width: 538, height: 48,
    			id: 'content-title-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ title }}'
    		},
			
    		{
				type: 'text',//artist 
				x: 460+(mycontentWidth-1920)/2, y: 117+48, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_ARTIST') +':',
				custom: {
					multilingual : {
						SID : 'COM_SID_ARTIST'
					}
					
				}

			},

			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48, width: 538, height: 48,
    			id: 'content-artist-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ artist }}'
    		},
			{
				type: 'text',//album 
				x: 460+(mycontentWidth-1920)/2, y: 117+48*2, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_ALBUM') +':',
				custom: {
					multilingual : {
						SID : 'COM_SID_ALBUM'
					}
					
				}

			},

			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*2, width: 538, height: 48,
    			id: 'content-album-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ album }}'
    		},
    		{
				type: 'text',//GENRE 
				x: 460+(mycontentWidth-1920)/2, y: 117+48*3, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_GENRE') +':',
				custom: {
					multilingual : {
						SID : 'COM_SID_GENRE'
					}
					
				}

			},

			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*3, width: 538, height: 48,
    			id: 'content-genre-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ genre }}'
    		},
			{
				type: 'text', //DURATION
				x: 460+(mycontentWidth-1920)/2, y: 117+48*4, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('IDWS_MOIP_DURATION_KR_BLANK'),
				custom: {
					multilingual : {
						SID : 'IDWS_MOIP_DURATION_KR_BLANK'
					}
					
				}

			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*4, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ duration }}'
    		},
    		
			{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*5, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: resMgr.getText('TV_SID_LAST_SAVED'),
				custom: {
					multilingual : {
						SID : 'TV_SID_LAST_SAVED'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*5, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ savedData }}'
    		},

			{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*6, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_FORMAT_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_FORMAT_COLON'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*6, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ format }}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*7, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_SIZE_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_SIZE_COLON'
					}
					
				}

    		},
    		{
    			type: 'text',
    			id: 'content-size-id',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*7, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ size }}'
    		},
    		
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*8, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_LOCATION'),
			
    		},

    		{
    			type: 'text',
				id: 'content-location-id',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*8, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ location}}'

    		},
    		{
				type : 'cmNormalButton',
				id : 'common-message-box-btn1',
				x : 825+(mycontentWidth-1920)/2, y : 550-30-66+48*3, width : 270, height : 66,
				custom: {focusable: true},  
	    	},
			
		],
    },
			
	info_window_template_video:
	{
		/*
		Title : I love you
		Duration : 03:11
		Last saved date : 2012.09.23
		Format : AVI
		Size : 3.5MB
		Resolution : 1080i
		Location : Dix USB > Folder 2
		*/
		type: 'widget',
	    x: 0, y: (1080 - 579) / 2, width: mycontentWidth, height : 579,
	    color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type: 'widget',//BG
		    	x: 0, y: 1, width: mycontentWidth, height : 570,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
				type: 'widget',
				x : 0, y: 0, width: mycontentWidth, height: 1,
				color: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.05,
				
			},
			{
				type: 'widget',
				x : 0, y: 571, width: mycontentWidth, height: 2,
				color: Volt.hexToRgb('#000000'),
				opacity: 255*0.15,
				
			},
			{
	    		type: 'image',
	    		x : 0, y: 573, width: mycontentWidth, height: 6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			},
			{
		        type : 'text',//Information
		        x : 460+(mycontentWidth-1920)/2, y: 0, width : 1122, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255,		        
		        font : 'SamsungSmart_Light 46px',
		        text : resMgr.getText('COM_TEXT_INFORMATION_P'),
		        custom: {
					multilingual : {
						SID : 'COM_TEXT_INFORMATION_P'
					}
					
				}
	    	},
	    	{
				type: 'widget',//line
                x: 460+(mycontentWidth-1920)/2, y: 97, width: 1002, height: 1,
                color: Volt.hexToRgb('#f2f2f2'),
                opacity: 255*0.6,
			},
			{
				type: 'text',//title
				x: 460+(mycontentWidth-1920)/2, y: 117, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_TITLE') +':',
				custom: {
					multilingual : {
						SID : 'TV_SID_TITLE_COLON'
					}
					
				}

			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117, width: 538, height: 48,
    			id: 'content-title-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ title }}'
    		},
			
    		
			{
				type: 'text',
				x: 460+(mycontentWidth-1920)/2, y: 117+48, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('IDWS_MOIP_DURATION_KR_BLANK'),
				custom: {
					multilingual : {
						SID : 'IDWS_MOIP_DURATION_KR_BLANK'
					}
					
				}

			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ duration }}'
    		},
    		
			{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*2, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_LAST_SAVED'),
    			ellipsize: true,
				custom: {
					multilingual : {
						SID : 'TV_SID_LAST_SAVED'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*2, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ savedData }}'
    		},

			{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*3, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_FORMAT_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_FORMAT_COLON'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*3, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ format }}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*4, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_SIZE_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_SIZE_COLON'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*4, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ size }}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*5, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_RESOLUTION'),
				custom: {
					multilingual : {
						SID : 'TV_SID_RESOLUTION'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*5, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ resolution}}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*6, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_LOCATION'),
    		},
    		{
    			type: 'text',
				id: 'content-location-id',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*6, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ location}}'

    		},
    		
    		{
				type : 'cmNormalButton',
				id : 'common-message-box-btn1',
				x : 825+(mycontentWidth-1920)/2, y : 590-30-66, width : 270, height : 66,
				custom: {focusable: true},  
	    	},
			
		],
    },
    
	info_window_template_record:
    {
		/*
		Title : I love you
		Channel: Cannel name
		Date : 2012.09.23
		HD/SD : HD
		Size : 3.5MB
		Location : Dix USB > Folder 2
		*/
		type: 'widget',
	    x: 0, y: (1080 - 579) / 2, width: mycontentWidth, height : 579,
	    color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type: 'widget',//BG
		    	x: 0, y: 1, width: mycontentWidth, height : 570,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
				type: 'widget',
				x : 0, y: 0, width: mycontentWidth, height: 1,
				color: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.05,
				
			},
			{
				type: 'widget',
				x : 0, y: 571, width: mycontentWidth, height: 2,
				color: Volt.hexToRgb('#000000'),
				opacity: 255*0.15,
				
			},
			{
	    		type: 'image',
	    		x : 0, y: 573, width: mycontentWidth, height: 6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			},
			{
		        type : 'text',//Information
		        x : 460+(mycontentWidth-1920)/2, y: 0, width : 1122, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255,		        
		        font : 'SamsungSmart_Light 46px',
		        text : resMgr.getText('COM_TEXT_INFORMATION_P'),
		        custom: {
					multilingual : {
						SID : 'COM_TEXT_INFORMATION_P'
					}
					
				}
	    	},
	    	{
				type: 'widget',//line
                x: 460+(mycontentWidth-1920)/2, y: 97, width: 1002, height: 1,
                color: Volt.hexToRgb('#f2f2f2'),
                opacity: 255*0.6,
			},
			{
				type: 'text',//title
				x: 460+(mycontentWidth-1920)/2, y: 117, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_TITLE') +':',
				custom: {
					multilingual : {
						SID : 'TV_SID_TITLE_COLON'
					}
					
				}

			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117, width: 538, height: 48,
    			id: 'content-title-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ title }}'
    		},
			
    		
			{
				type: 'text',
				x: 460+(mycontentWidth-1920)/2, y: 117+48, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('TV_SID_CHANNEL_COLON_BLANK'),
				custom: {
					multilingual : {
						SID : 'TV_SID_CHANNEL_COLON_BLANK'
					}
					
				}
				
			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ channel }}'
    		},
    		
			{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*2, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_DATE_CONLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_DATE_CONLON'
					}
					
				}
				
    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*2, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ savedData }}'
    		},

			{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*3, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_QUALITY'),
				custom: {
					multilingual : {
						SID : 'TV_SID_QUALITY'
					}
					
				}
    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*3, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ HDSD }}'
    		},
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*4, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_SIZE_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_SIZE_COLON'
					}
					
				}
				
    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*4, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ size }}'
    		}, 		
    		
    		{
    			type: 'text',
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*5, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text:resMgr.getText('TV_SID_LOCATION') ,
				
    		},
    		{
    			type: 'text',
				id: 'content-location-id',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*5, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ location}}'

    		},
    		
    		{
				type : 'cmNormalButton',
				id : 'common-message-box-btn1',
				x : 825+(mycontentWidth-1920)/2, y : 550-30-66, width : 270, height : 66,
				custom: {focusable: true},  
	    	},
			
		],
    },
    info_window_template_uhd_video:
    {
		/*
		Title : I love you
		Duration : 03:11
		Last saved date : 2012.09.23
		Format : AVI
		Size : 3.5MB
		Resolution : 1080i
		Location : Dix USB > Folder 2
		*/
		type: 'widget',
	    x: 0, y: (1080 - 579) / 2, width: mycontentWidth, height : 579,
	    color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type: 'widget',//BG
		    	x: 0, y: 1, width: mycontentWidth, height : 570,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
				type: 'widget',
				x : 0, y: 0, width: mycontentWidth, height: 1,
				color: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.05,
				
			},
			{
				type: 'widget',
				x : 0, y: 571, width: mycontentWidth, height: 2,
				color: Volt.hexToRgb('#000000'),
				opacity: 255*0.15,
				
			},
			{
	    		type: 'image',
	    		x : 0, y: 573, width: mycontentWidth, height: 6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			},
			{
		        type : 'text',//Information
		        x : 460+(mycontentWidth-1920)/2, y: 0, width : 1122, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255,		        
		        font : 'SamsungSmart_Light 46px',
		        text : resMgr.getText('COM_TEXT_INFORMATION_P'),
		        custom: {
					multilingual : {
						SID : 'COM_TEXT_INFORMATION_P'
					}
					
				}
	    	},
	    	{
				type: 'widget',//line
                x: 460+(mycontentWidth-1920)/2, y: 97, width: 1002, height: 1,
                color: Volt.hexToRgb('#f2f2f2'),
                opacity: 255*0.6,
			},
			{
				type: 'text',//title
				x: 460+(mycontentWidth-1920)/2, y: 117, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('COM_SID_TITLE') +':',
				custom: {
					multilingual : {
						SID : 'TV_SID_TITLE_COLON'
					}
					
				}

			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117, width: 538, height: 48,
    			id: 'content-title-id',
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ title }}'
    		},
			
    		
			{
				type: 'text', //duration
				x: 460+(mycontentWidth-1920)/2, y: 117+48, width: 434, height: 48,
				horizontalAlignment : 'left',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: resMgr.getText('IDWS_MOIP_DURATION_KR_BLANK'),
				custom: {
					multilingual : {
						SID : 'IDWS_MOIP_DURATION_KR_BLANK'
					}
					
				}

			},
			{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ duration }}'
    		},
    		
			{
    			type: 'text', //genre
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*2, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('COM_SID_GENRE')+':',
    			ellipsize: true,
				custom: {
					multilingual : {
						SID : 'COM_SID_GENRE'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*2, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			ellipsize: true,
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ genre }}'
    		},

			{
    			type: 'text',//format
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*3, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_FORMAT_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_FORMAT_COLON'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*3, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ format }}'
    		},
    		
    		{
    			type: 'text', //size
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*4, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_SIZE_COLON'),
				custom: {
					multilingual : {
						SID : 'TV_SID_SIZE_COLON'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*4, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ size }}'
    		},
    		
    		{
    			type: 'text', //resolution
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*5, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_RESOLUTION'),
				custom: {
					multilingual : {
						SID : 'TV_SID_RESOLUTION'
					}
					
				}

    		},
    		{
    			type: 'text',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*5, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ resolution}}'
    		},
    		
    		{
    			type: 'text', //location
    			x: 460+(mycontentWidth-1920)/2, y: 117+48*6, width: 434, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: resMgr.getText('TV_SID_LOCATION'),
    		},
    		{
    			type: 'text',
				id: 'content-location-id',
    			x: 924+(mycontentWidth-1920)/2, y: 117+48*6, width: 538, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ location}}'

    		},
    		
    		{
				type : 'cmNormalButton',
				id : 'common-message-box-btn1',
				x : 825+(mycontentWidth-1920)/2, y : 590-30-66, width : 270, height : 66,
				custom: {focusable: true},  
	    	},
			
		],
    }
};

exports = InfoWindowTemplate;


