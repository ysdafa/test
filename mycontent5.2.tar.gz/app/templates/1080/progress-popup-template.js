var resMgr = Volt.require('app/controller/resource-controller.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var ProgressPopupTemplate = {
    oneProgressBarContainer: {
		type: 'widget',
	    x: 0, y: (1080 - 319) / 2, width: mycontentWidth, height : 319,
	    color : Volt.hexToRgb('#ffffff', 0),
		children: [
			{
				type: 'widget',
				//id: 'one-progress-bar-bg',0
		    	x: 0, y: 1, width: mycontentWidth, height : 310,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
		        type : 'text',
				//id : 'one-progress-bar-title',1
		        x : 510+(mycontentWidth-1920)/2, y: 16, width : 900, height : 72,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff', 100),
		        text : '{{ title }}',
		        font : 'SamsungSmart_Light 28px',
	    	},
	    	{
		        type : 'text',
				//id : 'one-progress-bar-message',2
		        x : 510+(mycontentWidth-1920)/2, y: 90, width : 900, height : 68,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'top',
		        textColor : Volt.hexToRgb('#ffffff', 100),
		        text : '{{ message }}',
		        font : 'SamsungSmart_Light 28px',
	    	},
	    	{
		        type : 'text',
				//id : 'one-progress-bar-percent',3
		        x : 1420+(mycontentWidth-1920)/2, y: 152, width : 510, height : 40,
		        horizontalAlignment : 'left',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff', 60),
		        text : '0%',
		        font : 'SamsungSmart_Light 22px',
	    	},
	    	{
        		type: 'Progress',
        		//id: 'one-progress',4
        		x: 510+(mycontentWidth-1920)/2, y: 172, width:900, height:2,
//        		unprocessColor: Volt.hexToRgb('#ffffff','10'),
//        		processedColor: Volt.hexToRgb('#ffffff','100'),        		
//        		stepNumber: 1,
//        		currentStep: 0,
//        		readOnly : true,        		
    			minValue: 0,
    			value: 0,
    			maxValue: 100,
        		custom: {focusable: false},
        	},
			{
				type : 'cmNormalButton',
				id : 'one-progress-bar-btn1',
				x : 825+(mycontentWidth-1920)/2, y : 220, width : 270, height : 66,
				custom: {focusable: true},  
			},
			{
				type: 'widget',
		    	x: 0, y: 0, width: mycontentWidth, height : 1,
		    	color : Volt.hexToRgb('#ffffff'), 
		    	opacity: 255 * 0.05,
			},
			{
				type: 'widget',
		    	x: 0, y: 311, width: mycontentWidth, height : 2,
		    	color : Volt.hexToRgb('#000000'), 
		    	opacity: 255 * 0.15,
			},
			{
	    		type: 'image',
	    		x:0,y:313,width:1920,height:6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			}
		],
    },
    twoProgBarContainer:{
		type: 'widget',
	    x: 0, y: (1080 - 428-9) / 2, width: mycontentWidth, height : 428+9,
	    color : Volt.hexToRgb('#ffffff', 0),
		children: [
			{
				type: 'widget',
				//id: 'two-progress-bar-bg',
		    	x: 0, y: 1, width: mycontentWidth, height : 428,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
		        type : 'text',
				//id : 'two-progress-bar-title',1
		        x : 510+(mycontentWidth-1920)/2, y: 20, width : 900, height : 68,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255*0.9,
		        text : '{{ title }}',
		        font : 'SamsungSmart_Light 26px',
	    	},
	    	{
		        type : 'text',
				//id : 'first-progress-bar-message',2
		        x : 510+(mycontentWidth-1920)/2, y: 90, width : 900, height : 58,
		        horizontalAlignment : 'left',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255*0.6,
		        text : '{{ message1 }}',
		        font : 'SamsungSmart_Light 26px',
	    	},
	    	{
		        type : 'text',
				//id : 'first-progress-bar-percent',3
		        x : 1420+(mycontentWidth-1920)/2, y: 132, width : 510, height : 40,
		        horizontalAlignment : 'left',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255*0.6,
		        text : '0%',
		        font : 'SamsungSmart_Light 22px',
	    	},
	    	{
        		//id: 'first-progress',4
        		type: 'Progress',
        		x: 510+(mycontentWidth-1920)/2, y: 152, width:900, height:2,
//        		unprocessColor: Volt.hexToRgb('#ffffff','10'),
//       		processedColor: Volt.hexToRgb('#ffffff','100'),        		
//        		stepNumber: 1,
//        		currentStep: 0,
//        		readOnly : true,        		
    			minValue: 0,
    			value: 0,
    			maxValue: 100,
        		custom: {focusable: false},
        	},    	
        	{
		        type : 'text',
				//id : 'second-progress-bar-message',5
		        x : 510+(mycontentWidth-1920)/2, y: 192, width : 900, height : 68,
		        horizontalAlignment : 'left',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255*0.6,
		        text : '{{ message2 }}',
		        font : 'SamsungSmart_Light 26px',
	    	},
	    	{
		        type : 'text',
				//id : 'second-progress-bar-percent',6
		        x : 1420+(mycontentWidth-1920)/2, y: 244, width : 510, height : 40,
		        horizontalAlignment : 'left',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff'),
		        opacity: 255*0.6,
		        text : '0%',
		        font : 'SamsungSmart_Light 22px',
	    	},
	    	{
        		type: 'Progress',
        		//id: 'second-progress',7
        		x: 510+(mycontentWidth-1920)/2, y: 264, width:900, height:2,
//        		unprocessColor: Volt.hexToRgb('#ffffff','10'),
//        		processedColor: Volt.hexToRgb('#ffffff','100'),        		
//        		stepNumber: 1,
//        		currentStep: 0,
//        		readOnly : true, 
    			minValue: 0,
    			value: 0,
    			maxValue: 100,
        		custom: {focusable: false},	
        	},
			{
				type : 'cmNormalButton',
				id : 'two-progress-bar-btn1',
				x : 825+(mycontentWidth-1920)/2, y : 338, width : 270, height : 66,
				custom: {focusable: true},  
			},
			{
				type: 'widget',
		    	x: 0, y: 0, width: mycontentWidth, height : 1,
		    	color : Volt.hexToRgb('#ffffff'), 
		    	opacity: 255 * 0.05,
			},
			{
				type: 'widget',
		    	x: 0, y: 429, width: mycontentWidth, height : 2,
		    	color : Volt.hexToRgb('#000000'), 
		    	opacity: 255 * 0.15,
			},
			{
	    		type: 'image',
	    		x:0,y:431,width:mycontentWidth,height:6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			}
		],
    },
    
};

exports = ProgressPopupTemplate;


