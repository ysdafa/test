 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Mobile device view template
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var MyContentMobileViewTemplate = {
    ContentCateList: {
        
        type: 'ResizeableGrid', 
        x:0, y: 0, rows : 1,
        width : 1920,
        height: 864,
        itemWidth : 640,
        itemHeight :864,
        parent: scene,
		fillMode:'fit',
		custom: {focusable: true,},
  
    },
    
    ContentCateItem: [
        {
            type: 'image',
            src: '{{iconPath}}',
            x: 0, y:0 , width: 640, height: 864,
            
        },{
            type: 'text',
            x: 25, y:534 , width: 590, height: 64,
            font: 'SamsungSmart_Light 60px',
            textcolor: Volt.hexToRgb('#FFFFFF'),
            opacity: 255*0.6,
            verticalAlignment : 'center',
            horizontalAlignment : 'center',
            text: '{{title}}',
            
        },{
            type: 'text',
            x: 40, y:770 , width: 560, height: 38,
            font: 'SamsungSmart_Light 34px',
            textcolor: Volt.hexToRgb('#FFFFFF'),
            opacity: 0,
            verticalAlignment : 'center',
            horizontalAlignment : 'center',
            text:'{{subtitle}}',
        },
  ]
        
};

exports = MyContentMobileViewTemplate;
