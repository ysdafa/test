 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Share information
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Coords = {
	ROOTVIEW_X : 0,
	ROOTVIEW_Y : 0,
	ROOTVIEW_W : 1920,
	ROOTVIEW_H : 1080,
	BASEVIEW_X : 0,
	BASEVIEW_Y : 216,
	BASEVIEW_W : 1920,
	BASEVIEW_H : 864,
	TOPBANNERTEXT_X : 25,
	TOPBANNERTEXT_Y : 47,
	TOPBANNERTEXT_W : 600,
	TOPBANNERTEXT_H : 50,
};

var TitleImageDatas = [
{
	Path:resMgr.getImgPath()+"/titleImage/comn_icon_title_game.png"
},
{
	Path:resMgr.getImgPath()+"/titleImage/comn_icon_title_apps.png"
},
{
	Path:resMgr.getImgPath()+"/titleImage/comn_icon_title_ontv.png"
},
{
	Path:resMgr.getImgPath()+"/titleImage/comn_icon_title_mt.png"
},
{
	Path:resMgr.getImgPath()+"/titleImage/comn_icon_title_mm.png"
},
{
	Path:" "
},
{
	Path:resMgr.getImgPath()+"/titleImage/comn_icon_topmenu_schedule.png"
},
{
	Path:resMgr.getImgPath()+"/titleImage/comn_icon_topmenu_search.png"
},
{
	Path:resMgr.getImgPath()+"/common/comn_icon_topmenu_setting.png"
}
];

var upArrowImage = new Image({
			uri:resMgr.getImgPath()+"/Arrow/02_popup_arrow_up_n.png",
		});	
		
var downArrowImage = new Image({
			uri:resMgr.getImgPath()+"/Arrow/02_popup_arrow_down_n.png",
		});
var selectArrowImage = new Image({
			uri:resMgr.getImgPath()+'/Arrow/00_check_Activatedback.png',
		});

options = {
	ninePatch : {
		left : resMgr.getImgPath()+"/9patch_img/list_high_mid_left.png",
		right : resMgr.getImgPath()+"/9patch_img/list_high_mid_right.png",
		top : resMgr.getImgPath()+"/9patch_img/list_high_upper_center.png",
		bottom : resMgr.getImgPath()+"/9patch_img/list_high_lower_center.png",
		topLeft : resMgr.getImgPath()+"/9patch_img/list_high_upper_left.png",
		topRight : resMgr.getImgPath()+"/9patch_img/list_high_upper_right.png",
		bottomRight : resMgr.getImgPath()+"/9patch_img/list_high_lower_right.png",
		bottomLeft : resMgr.getImgPath()+"/9patch_img/list_high_lower_left.png"
	}
};

var loadingImageUrl = [resMgr.getImgPath()+"/AnimateImg/loading_96_01.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_02.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_03.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_04.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_05.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_06.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_07.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_08.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_09.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_10.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_11.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_12.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_13.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_14.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_15.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_16.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_17.png",
			resMgr.getImgPath()+"/AnimateImg/loading_96_18.png"
		   ];

var homepanelInfo = {
	mTitleImageDatas: TitleImageDatas,
	mUpArrowImage: upArrowImage,
	mDownArrowImage: downArrowImage,
	mSelectArrowImage: selectArrowImage,
	mCoords: Coords,
	mOptions: options,
	mLoadingImageUrl : loadingImageUrl
	
};


exports.Coords = Coords;
exports.TitleImageDatas = TitleImageDatas;
exports.upArrowImage = upArrowImage;
exports.downArrowImage = downArrowImage;
exports.selectArrowImage = selectArrowImage;
exports.options = options;
exports.homepanelInfo = homepanelInfo;
