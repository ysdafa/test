var resMgr = Volt.require('app/controller/resource-controller.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var offSet = RunTimeInfo.offSet;

var MessageBoxTemplate = {

	msgbox_template_no_title_no_button:
	{
		type: 'MessageBox',
        width: mycontentWidth, height:1080,
        color: Volt.hexToRgb('#0a233d',0),
        contentType: 'multi_line_content_type',
        contentTextFont: 'SamsungSmart_Light 34px',
        bTitle: false,
        titleText: '',
        buttonType: 'no_button',
        //buttonTextNormalSize: 32,
        //buttonTextFocusSize: 32,
        //normalButtonImagePath: 'images/1080/button/btn_style_c_n.png',
        //focusButtonImagePath: 'images/1080/button/btn_style_c_f.png',
    },	
	msgbox_template_no_title_one_button:
	{
		type: 'MessageBox',
        x: 0, y: (1080-310)/2,
        width: mycontentWidth, height:310,
        bAutoFlag: false,
        color: Volt.hexToRgb('#0a233d',0),
        contentType: 'multi_line_content_type',
        contentTextFont: 'SamsungSmart_Light 34px',
        bTitle: false,
        titleText: '',
        buttonType: 'button_1',
        buttonTextNormalSize: 32,
        buttonTextFocusSize: 32,
        buttonNormalBorderColor: Volt.hexToRgb('#ffffff',80),
        buttonNormalBorderWidth: 1,
        //normalButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_n.png',
        //focusButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_f.png',
    },

	msgbox_template_magic_no_title_one_button:
	{
		type: 'MessageBox',
        x: 0, y: (1080-480)/2,
        width: mycontentWidth, height:480,
        bAutoFlag: false,
        color: Volt.hexToRgb('#0a233d',0),
        contentType: 'multi_line_content_type',
        contentTextFont: 'SamsungSmart_Light 34px',
        bTitle: false,
        titleText: '',
        buttonType: 'button_1',
        buttonTextNormalSize: 32,
        buttonTextFocusSize: 32,
        buttonNormalBorderColor: Volt.hexToRgb('#ffffff',80),
        buttonNormalBorderWidth: 1,
        //normalButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_n.png',
        //focusButtonImagePath: resMgr.getImgPath()+'/btn_style_c_f.png',
    },

	msgbox_template_multi_msg_one_button:
	{
		type: 'MessageBox',
		x: 0, y: (1080-310)/2,
        width: mycontentWidth, height:310,
        bAutoFlag: false,
        color: Volt.hexToRgb('#0a233d',0),
        titleTextFont: 'SamsungSmart_Light 32px',
        contentType: 'multi_line_with_single_line_content_type',
        contentTextFont: 'SamsungSmart_Light 28px',
        contentText2Font: 'SamsungSmart_Light 28px',
        bTitle: true,
        //titleText: 'AAAAAAAA',
        buttonType: 'button_1',
        buttonTextNormalSize: 32,
        buttonTextFocusSize: 32,
        buttonNormalBorderColor: Volt.hexToRgb('#ffffff',80),
        buttonNormalBorderWidth: 1,
        //normalButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_n.png',
        //focusButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_f.png',
    },
			
	msgbox_template_no_title_two_button:
	{
		type: 'MessageBox',
        x: 0, y: (1080-310)/2,
        width: mycontentWidth, height:310,
        bAutoFlag: false,
        color: Volt.hexToRgb('#0a233d',0),
        contentType: 'multi_line_content_type',
        contentTextFont: 'SamsungSmart_Light 34px',
        bTitle: false,
        titleText: '',
        buttonType: 'button_2',
        buttonTextNormalSize: 32,
        buttonTextFocusSize: 32,
        buttonNormalBorderColor: Volt.hexToRgb('#ffffff',80),
        buttonNormalBorderWidth: 1,
        //normalButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_n.png',
        //focusButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_f.png'
    },

	msgbox_template_no_title_three_button:
	{
		type: 'widget',
	    x: 0, y: (1080 - 550) / 2, width: mycontentWidth, height : 550,
	    color : Volt.hexToRgb('#ffffff',0),
	    
		children: [
			{
				type: 'widget',
				id: 'common-message-box-bg',
		    	x: 0, y: 0, width: mycontentWidth, height : 550,
		    	color : Volt.hexToRgb('#0a5d88',255),
		    	opacity: 255*0.85,
			},
	    	{
		        type : 'text',
				id : 'message',
		        x : 399+offSet, y: 48, width : 1122, height : 48*8,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff', 255),
		        text : '{{ message }}',
		        font : '30',
	    	},
			{
				type : 'cmNormalButton',
				id : 'common-message-box-btn1',
				x : 535+offSet, y : 48*8+70, width : 270, height : 66,
				custom: {focusable: true},
	    	},
	    	{
				type : 'cmNormalButton',
				id : 'common-message-box-btn2',
				x : 825+offSet, y : 48*8+70, width : 270, height : 66,
				custom: {focusable: true},
	    	},
	    	{
				type : 'cmNormalButton',
				id : 'common-message-box-btn3',
				x : 1115+offSet, y : 48*8+70, width : 270, height : 66,
				custom: {focusable: true},
	    	},
		],
    },
};

exports = MessageBoxTemplate;


