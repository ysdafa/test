var informationText = Volt.i18n.t('COM_TEXT_INFORMATION_P');
var antennaText = "Air";
var cableText = "DTV";
var resMgr = Volt.require('app/controller/resource-controller.js');
print('require content-information-box-template-pvr.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;

var PVRInfoWindowTemplate  = {
	info_window_pvr:
	{
		type: 'widget',
	    x: 0, y: (1080 - 1080*0.7) / 2, width: mycontentWidth, height : 1080*0.7,
	    color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type: 'widget',//BG
		    	x: 0, y: 1, width: mycontentWidth, height : 747,
		    	color : Volt.hexToRgb('#0a233d'),
			},
			{
				type: 'widget',
				x : 0, y: 0, width: mycontentWidth, height: 1,
				color: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.05,
				
			},
			{
				type: 'widget',
				x : 0, y: 748, width: mycontentWidth, height: 2,
				color: Volt.hexToRgb('#000000'),
				opacity: 255*0.15,
				
			},
			{
	    		type: 'image',
	    		x : 0, y: 750, width: mycontentWidth, height: 6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			},
			{
		        type : 'text',//Information
		        x : 399+(mycontentWidth-1920)/2, y: 0, width : 1122, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'center',
		        textColor : Volt.hexToRgb('#ffffff', 255),
		        opacity: 255*0.9,		        
		        font : '44px',
		        text : informationText,
			},
			{
				type: 'widget',//line
		        x: 399+(mycontentWidth-1920)/2, y: 97, width: 1122, height: 1,
		        color: Volt.hexToRgb('#f2f2f2'),
		        opacity: 255*0.6,
			},
	
			{
				id: 'pvr-info-ci-ok-button', //ok button
				type: 'cmNormalButton',
         		x:1372+(mycontentWidth-1920)/2,y:500,width: 270,height:66, 
         		custom: {focusable: true},					
			},
			{
				id: 'pvr-info-ci-scroll-up-button',// scroll up 
				type: 'cmNormalButton',
         		x:383+(mycontentWidth-1920)/2,y:313,width: 782,height:87, 
         		custom: {focusable: true},
			},
			{
				id: 'pvr-info-ci-scroll-down-button',//scroll down
				type: 'cmNormalButton',
         		x:383+(mycontentWidth-1920)/2,y:669,width: 782,height:87, 
         		custom: {focusable: true},
			},
			{
				id: 'pvr-info-ci-synopsis', //synopsis
				type: 'widget',
				color : Volt.hexToRgb('#FF0000', 0),
				x: 1920*0.207292+(mycontentWidth-1920)/2, y: 400, width: 1920* 0.407183,height: 1080*0.266664,
				cropOverflow : true,
			}
		]
	},

	ci_common_info:{
		type: 'widget',
		x: 1920 * 0.207292+(mycontentWidth-1920)/2, y: 1080* 0.104630, width: 1920* 611458 , height: 1080*0.185185,
		color : Volt.hexToRgb('#FF0000', 0),
		children: [
			{
				type: 'widget',//chanel info
				x: 0, y: 0, width: 1920*0.611458, height: 1080*0.043519,
				color: Volt.hexToRgb('#ffffff',0),
				children:  [
					{
						type: 'image',
						x : 0, y: 0, width: 37, height: 1080*0.043519,
						src: resMgr.getImgPath()+'/popup/mc_popup_icon_lock_n.png',
						
					},
					{
						type: 'text',
						textColor: Volt.hexToRgb('#ffffff'),
						x: 37, y: 0,width: 200, height: 1080*0.043519,
						opacity: 255* 0.9,
						font: '34px',
						text: '{{programTitle}}',
						
					},
					{
						type: 'image',
						x: 249, y:10, width: 1, height: 	 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},///1
					{
						type:'text',
						x: 262, y: 0, width: 80,height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: cableText,
					},
					{
						type: 'image',
						x: 354, y:10, width: 1, height: 	 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},
					{
						type:'text',
						x: 367, y: 0, width: 80,height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: antennaText,
					},
					{
						type: 'image',
						x: 460, y:10, width: 1, height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},///2
					{
						type : 'text',
						x: 473, y: 0, width: 100, height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: '{{chanelNumber}}',
					},
					{
						type: 'image',
						x: 585, y:10, width: 1, height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},{
						type: 'text',
						x: 598, y:0 , width: 100, height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: '{{chanelTitle}}',
					},{
						type: 'image',
						x: 710, y:10, width: 1, height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},{
						type: 'text',
						x: 723, y: 0 , width: 295, height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: '{{recordTime}}',
					},
				]
			},
			{
				type: 'widget', //program info
				x: 1920* 0.207292, y: 1080* 0.148149  , width: 1920*0.611458 , height: 1080* 0.050000,
				color: Volt.hexToRgb('#ffffff',0),				
				children: [
					{
						type: 'text',
						x: 0, y: 0, width: 150, height: 1080* 0.050000,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: '{{genre}}',
					},
					{
						type: 'image',
						x: 162, y:10, width: 1, height: 	 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},
					{
						type: 'text',
						x: 175, y: 0, width: 200, height: 1080* 0.050000,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: '{{programLength}}',
					},
					{
						type: 'image',
						x: 387, y:10, width: 1, height: 	 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},
					{
						type: 'text',
						x: 400, y: 0, width: 100, height: 1080* 0.050000,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: '{{programSize}}',
					},
					{
						type: 'image',
						x: 512, y:10, width: 1, height: 	 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},
					{
						type: 'text',
						x: 525, y: 0, width: 200, height: 1080* 0.050000,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: '34px',
						text: '{{playCount}}',
					},
				]
		
			},
		]
	},

	record_common_info:{
		type: 'widget',
		x: 1920 * 0.207292+(mycontentWidth-1920)/2, 
		y: 1080* 0.104630, 
		width: 1174 , 
		height: 1080*0.185185,
		color : Volt.hexToRgb('#FF0000', 0),
		children: [
			{
				type: 'widget',//chanel info
				x: 0, y: 0, width: 1174, height: 1080*0.043519,
				color: Volt.hexToRgb('#ffffff',0),
				children:  [
					{
						id: 'pvr-info-program-title',
						type: 'text',
						textColor: Volt.hexToRgb('#ffffff'),
						x: 0, 
						y: 0,
						height: 1080*0.043519,
						opacity: 255* 0.9,
						font: 'SamsungSmart_Light 34px',	
						horizontalAlignment : 'left',
    					verticalAlignment : 'center',
						ellipsize: true,
						text: '{{programTitle}}',	
						singleLineMode: true,
					
					},
					{
						id: 'pvr-info-first-line-bar1',
						type: 'image',
						//x: 249, 
						y:10, 
						width: 1, 
						height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},
					{
						id: 'pvr-info-tv-mode',
						type:'text',
					//	x: 262, 
						y: 0, 
					//	width: 80,
						height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: 'SamsungSmart_Light 34px',
						text: '{{tvmode}}',
						singleLineMode: true,
						horizontalAlignment : 'left',
    					verticalAlignment : 'center',
					},
					{
						id: 'pvr-info-first-line-bar2',
						type: 'image',
					//	x: 354, 
						y:10, 
						width: 1, 
						height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},
					{
						id: 'pvr-info-cable',
						type:'text',
						//x: 367,
						y: 0,
						//width: 80,
						height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: 'SamsungSmart_Light 34px',
						text: '{{cable}}',
						singleLineMode: true,
						horizontalAlignment : 'left',
    					verticalAlignment : 'center',
					},
					{
						id: 'pvr-info-first-line-bar3',
						type: 'image',
						//x: 460, 
						y:10, 
						width: 1, 
						height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},///2
					{
						id: 'pvr-info-chanel-num',
						type : 'text',
						//x: 473, 
						y: 0, 
						//width: 100, 
						height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: 'SamsungSmart_Light 34px',
						text: '{{chanelNumber}}',
						singleLineMode: true,
						horizontalAlignment : 'left',
    					verticalAlignment : 'center',
					},
					{
						id: 'pvr-info-first-line-bar4',
						type: 'image',
					//	x: 585, 
						y:10, 
						width: 1, 
						height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},{
						id: 'pvr-info-chanel-title',
						type: 'text',
					//	x: 598, 
						y:0 , 
					//	width: 100, 
						height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: 'SamsungSmart_Light 34px',
						text: '{{chanelTitle}}',
						singleLineMode: true,
						horizontalAlignment : 'left',
    					verticalAlignment : 'center',
					},{
						id: 'pvr-info-first-line-bar5',
						type: 'image',
						//x: 710,
						y:10, 
						width: 1, 
						height: 1080*0.025000,
						color: Volt.hexToRgb('#ffffff'),
						opacity: 255*0.2,
					},{
						id: 'pvr-info-record-time',
						type: 'text',
						//x: 723, 
						y: 0 , 
						//width: 295, 
						height: 1080*0.043519,
						textColor: Volt.hexToRgb('#ffffff'),
						opacity: 255* 0.9,
						font: 'SamsungSmart_Light 34px',
						text: '{{recordTime}}',
						singleLineMode: true,
						horizontalAlignment : 'left',
    					verticalAlignment : 'center',
					}
				]
			},
    		{
    			id: 'pvr-info-quality',
    			type: 'text',
    			x: 0, y: 1080*0.043519, width: 1174, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ HDSD }}'
    		},
    		{
    			id: 'pvr-info-size',
    			type: 'text',
    			x: 0, y: 1080*0.043519+48, width: 1174, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
    			text: '{{ programSize }}'
    		}, 		  		
    		{
    			id: 'pvr-info-location',
    			type: 'text',
    			x: 0, y: 1080*0.043519+48*2, width: 1174, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 34px',
    			textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				ellipsize: true,
    			text: '{{ location}}'

    		},
		]
		
	}
};
exports = PVRInfoWindowTemplate;
