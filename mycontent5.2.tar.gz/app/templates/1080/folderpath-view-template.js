 /** 
 * @author  Li Hailong (hailong08.li@samsung.com)
 * 			
 * @fileoverview  Enter sub-folder, folder path will be shown
 * @date    2014/08/05 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var FolderPathViewTemplate = {
    folderpath: {
    	id:'folder-path',
  
        type: 'widget',
        x: 0, y: 0, 
		width: mycontentWidth, height: 72,
        color: Volt.hexToRgb('#192334',0),   
      /*
        children : [
    		{
    			id:'folder-path-txt',
    			type: 'CategoryList',
                x: 0, y: 0, 
                width: 1500, height: 72,
                color: Volt.hexToRgb('#fff450'),  
              
    		}
    	]
    	*/
    }
};

exports = FolderPathViewTemplate;
