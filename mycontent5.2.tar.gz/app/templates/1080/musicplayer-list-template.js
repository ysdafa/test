 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Music player view template
 * @date    2014/11/04 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var ToGetResolution = Volt.require("app/common/run-time-info.js");
var MusicPlayerListTemplate = {
	list:{
		type: 'widget',
		x: ToGetResolution.SceneResolution - 820, y: 0, width: 820, height: 1080,
		color: Volt.hexToRgb('#000000','10'),	
		children:[
			{
		    	id: 'playList',
			    type: 'cmNormalSingleList',
			    width: 820, height: 1080,
				opacity: 255,
				scrollType: "Vertical",
			    custom: {focusable: true}, 
			}
		]
	},
	
    listItem:{
        type: 'Thumbnail',//parent??????
        visibleStyles: ( 0x20 | 0x02 ),
        x : 0,y : 0,width : 820,height : 86,        
        custom: { 'focusable': true },

	    icon1:{		//thumbnail
	        async : false,
	        unpressSrc: '',
	        pressedSrc : '', 
	        x:0,
	        y:0,
	        width: 86,
	        height: 86
	    },				
	    icon2:{		//currIcon
	        async : false,
	        unpressSrc: '',//'images/1080/play List icon/mc_icon_playlist_equalizer.png',
	        pressedSrc : '',//'images/1080/play List icon/mc_icon_playlist_equalizer.png', 
	        x:54,
	        y:32,
	        width: 22,
	        height: 22,
	        async: true,
	    },

	    icon3:{		//unsupportIcon
	        async : false,
	        unpressSrc: '',//'images/1080/play List icon/mc_icon_playlist_notsupport.PNG',
	        pressedSrc : '',//'images/1080/play List icon/mc_icon_playlist_notsupport.PNG', 
	        x:54,
	        y:30,
	        width: 26,
	        height: 26
	    },

	    icon4:{		//default-album
	        async : false,
	        unpressSrc: '',
	        pressedSrc : '', 
	        x:0,
	        y:0,
	        width: 86,
	        height: 86
	    },		
         
        information:{
            x: 0,
            y: 0,
            width: 820,
            height: 86,
            color: {r: 0, g: 0, b: 0, a: 1},
			highContrast: {
				color: {r:37,g:37,b:37,a:0},
				textColor: { r:255, g:255, b:255, a:204 },
				highlightTextColor: { r:255, g:255, b:255, a:204 }
			},            
            enlarge: {
                factor: 1.2,
                anchorPoint: 'center'
            },

            text1:{		//title
                x:54,
                y:23,
                width:428,
                height: 40,
                font: 'SamsungSmart_Light 30px',
                text: '',
                singleLineMode: true
            },
            text2:{		//artist
                x: 536,
                y: 23,
                width:230,
                height: 40,
                font: 'SamsungSmart_Light 26px',
                text: '',
                singleLineMode: true
            }     
        }       
    },
};

exports = MusicPlayerListTemplate;
