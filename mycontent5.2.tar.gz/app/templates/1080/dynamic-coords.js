var Coords = {
	HEADER_TITLE_ORIGIN_X : 20,
	HEADER_TITLE_X : 136, 
};

exports = Coords;