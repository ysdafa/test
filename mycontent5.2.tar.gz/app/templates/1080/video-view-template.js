 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Video view template
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var VideoContentViewTemplate = {
    container: {
        type: 'widget',
        x: 0, y: 0, width: mycontentWidth, height: 864,
        color: Volt.hexToRgb('#dfdfdf',255),
        custom: {focusable: true},
    },

    list: {
        type: 'cmGridList',
		parent:null, 
		width: mycontentWidth, 
		height: 864, 
		titleSpace: 0, 
		groupSpace: 30, 
		cellSpace: 0, 
		focusRangeStartOffset: 0, 
		focusRangeEndOffset: 0,
		renderWidth: 324, 
		renderHeight: 288,
		listItemNum: 18,
		renderColumn: 6,
		textIndex: 1,
        custom: {focusable: true},
    },
	uhd_content_list: {
        type: 'cmGridList',
		parent:null, 
		width: mycontentWidth, 
		height: 864, 
		titleSpace: 0, 
		groupSpace: 30, 
		cellSpace: 0, 
		focusRangeStartOffset: 0, 
		focusRangeEndOffset: 0,
		renderWidth: 226, 
		renderHeight: 432,
		listItemNum: 18,
		renderColumn: 6,
		textIndex: 1,
        custom: {focusable: true},
    },
	listItemFolder:[
		{
			type: 'image',
			x: 0, y: 0, width: 324, height: 288,
			src: '{{ imgUrl }}',
		},
		{
			type: 'AutoScrollTextWidget',
			x: 20, y: 186, width: 284, height: 58,
			//x: 1920*0.010417, y: 288-1080*(0.026852*2+0.040741), width: 324-2*1920*0.010417, height: 1080*0.026852*2,
			font: 'SamsungSmart_Light 24px',
			color: {r:255, g:255, b:255, a:0},
			opacity: 153,
			ellipsize: true,
			text: '{{ title1 }}'
		},
		{
			type: 'image',
			x: 89, y: 55, width: 146, height: 121,
			src: '{{ imgUrlFolder }}',
		},
	 ],
	uhd_content_listItemFolder:[
		{
			type: 'image',
			x: 0, y: 0, width: 226, height: 432,
			src: '{{ imgUrl }}',
		},
		{
			type: 'AutoScrollTextWidget',
			x: 20, y: 236, width: 180, height: 58,
			//x: 1920*0.010417, y: 288-1080*(0.026852*2+0.040741), width: 220-2*1920*0.010417, height: 1080*0.026852*2,
			font: 'Calibri 24px',
			color: {r:255, g:255, b:255, a:0},
			opacity: 153,
			ellipsize: true,
		//	horizontalAlignment : "center",
			text: '{{ title1 }}'
		},
		{
			type: 'image',
			x: 37, y: 130, width: 146, height: 121,
			src: '{{ imgUrlFolder }}',
		},
	 ],
	listItemNoFolder:[
		{
			type: 'image',
			async: false,
			x: 0, y: 0, width: 324, height: 192,
			color: {r:25, g:46, b:70,a :255},
			fillMode: 'center',			
			src: '{{ imgUrl }}',
		},
		{
			type: 'widget',
			x: 0, y: 192, width: 324, height: 96,
			color: {r:24, g:41, b:61, a:255},
			children: [
				{
					type: 'AutoScrollTextWidget',
					x: 18, y: 26, width: 288, height: 30,
					//x: 1080*0.009375, y: 19, width: 324-1080*0.009375*2, height: 58,
					font: 'SamsungSmart_Light 26px',
					color: {r:255, g:255, b:255, a:0},
					opacity: 153,
					ellipsize: true,
					text: '{{ title1 }}'
				},
				{
					type: 'text',
					x: 18, y: 56, width: 288, height: 30,
					verticalAlignment : "center",
					horizontalAlignment : "left",
					font: 'SamsungSmart_Light 26px',
					textColor: {r:0, g:0, b:0},
					opacity: 255,
					ellipsize: true,
					text: '{{ title2 }}'
				}
			],
		},
		{
			type: 'AnimatedImageDrawing',
			x: 0, y: 0, width: 324, height: 192,
		},
		{
			type: 'widget',
			x: 0, y: 0, width: 324, height: 288,
			color : Volt.hexToRgb('#0f1826'),
			opacity: 0,
		},
		{
			type: 'image',
			x: (324-138)/2, y: (288-138)/2, width: 138, height: 138,
			opacity: 0,
			src: '{{ checkUrl }}',
		},
		{
			type: 'image',
			x: 324-32-10, y: 18, width: 32, height: 32,
			src: '{{unvailableIcon}}'
		},
		{
			type: 'image',
			x: 280, y: 5, width: 31, height: 16,
			src: '{{uhdicon}}'
		},{
			type: 'image',
			x: 141, y: 139, width: 42, height: 9,
		},{
			type: 'image',
			x: 323, y: 0, width: 1, height: 288,
		},{
			type: 'image',
			x: 0, y: 287, width: 324, height: 1,
		}
	],
	uhd_video_listItemNoFolder:[
		{
			type: 'image',
			async: false,
			x: 0, y: 0, width: 226, height: 338,
			color: {r:25, g:46, b:70,a :255},
			fillMode: 'center',			
			src: '{{ imgUrl }}',
		},
		{
			type: 'widget',
			x: 0, y: 192, width: 226, height: 96,
			color: {r:24, g:41, b:61, a:255},
			children: [
				{
					type: 'AutoScrollTextWidget',
					x: 18, y: 26, width: 220, height: 30,
					//x: 1080*0.009375, y: 19, width: 324-1080*0.009375*2, height: 58,
					font: 'SamsungSmart_Light 26px',
					color: {r:255, g:255, b:255, a:0},
					opacity: 153,
					ellipsize: true,
					text: '{{ title1 }}'
				},
				{
					type: 'text',
					x: 18, y: 56, width: 220, height: 30,
					verticalAlignment : "center",
					horizontalAlignment : "left",
					font: 'SamsungSmart_Light 26px',
					textColor: {r:0, g:0, b:0},
					opacity: 255,
					ellipsize: true,
					text: '{{ title2 }}'
				}
			],
		},
		{
			type: 'AnimatedImageDrawing',
			x: 0, y: 0, width: 226, height: 192,
		},
		{
			type: 'widget',
			x: 0, y: 0, width: 226, height: 288,
			color : Volt.hexToRgb('#0f1826'),
			opacity: 0,
		},
		{
			type: 'image',
			x: (226-138)/2, y: (432-138)/2, width: 138, height: 138,
			opacity: 0,
			src: '{{ checkUrl }}',
		},
		{
			type: 'image',
			x: 324-32-10, y: 18, width: 32, height: 32,
			src: '{{unvailableIcon}}'
		},
		{
			type: 'image',
			x: 182, y: 12, width: 32, height: 16,
			src: '{{uhdicon}}'
		},{
			type: 'image',
			x: 141, y: 139, width: 42, height: 9,
		},{
			type: 'image',
			x: 323, y: 0, width: 1, height: 288,
		},{
			type: 'image',
			x: 0, y: 287, width: 324, height: 1,
		}
	],
};

exports = VideoContentViewTemplate;