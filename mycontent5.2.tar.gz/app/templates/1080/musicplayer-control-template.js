/** 
* @author  Hu Po (paul.hu@samsung.com)
* 			
* @fileoverview  Music player view template
* @date    2014/09/24 (last modified date)
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/
var resMgr = Volt.require('app/controller/resource-controller.js');
var ToGetResolution = Volt.require("app/common/run-time-info.js");
var MusicPlayerCtrlBarTemplate = {
	ctrlBar: {
        type: 'widget',
        x: 0, y: 850, width:(ToGetResolution.SceneResolution*0.572917- 100  +ToGetResolution.offsetFor2560*2), height: 230,
        color: Volt.hexToRgb('#1F2B3D','0'),	

		children: [
        {
        	id: 'speaker',
			type: 'widget',
        	x:40,y:67,width:80,height:80,	
        	color: Volt.hexToRgb('#FFFFFF','0'),        	
        	children: [
        		{
        			type: 'widget',
					x:0,y:0,width:80,height:80,
					color: Volt.hexToRgb('#FFFFFF','0'),
        		},  
        		{
        			type: 'cmNormalButton',
					id: 'speaker_btn',
					x:0,y:0,width:80,height:80,
					color: {r:255,g:255,b:255,a:0},
					//async: false,
					icon: {
						x:0,y:0,width:80,height:80,	
		    			src: resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist.png',
        			},
					custom: {focusable: true},  
        		},
        		
        	],
        	
        }, 
        {
        	id: 'screenOff',
			type: 'widget',
        	x:146,y:67,width:80,height:80,	
        	color: Volt.hexToRgb('#FFFFFF','0'),
        	children: [
        		{
        			type: 'widget',
					x:0,y:0,width:80,height:80,
					color: Volt.hexToRgb('#FFFFFF','0'),
        		},  
        		{
        			type: 'cmNormalButton',
					id: 'screen_btn',
					x:0,y:0,width:80,height:80,
					color: {r:255,g:255,b:255,a:0},
					//async: false,
					icon: {
						x:0,y:0,width:80,height:80,	
		    			src: resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off.PNG',
        			},
					custom: {focusable: true},  
        		},			
        	],
        },        
        {
        	id: 'pre',
			type: 'widget',
        	x:((ToGetResolution.SceneResolution*0.572917 + ToGetResolution.offsetFor2560*2)/2 - 80/2 -ToGetResolution.SceneResolution*0.011979-80),y:67,width:80,height:80,	//405 is (0.020833 + 0.013542 +0.093229)*1920+80+80  ((0.020833 + 0.013542 +0.093229)*ToGetResolution.SceneResolution + 2*80/1920*ToGetResolution.SceneResolution +ToGetResolution.offsetFor2560 + ToGetResolution.offsetForPrePauseNext)
        	color: Volt.hexToRgb('#FFFFFF','0'),
        	children: [
        		{
        			type: 'widget',
					x:0,y:0,width:80,height:80,
					color: Volt.hexToRgb('#FFFFFF','0'),
        		},  
        		{
        			type: 'cmNormalButton',
					id: 'pre_btn',
					x:0,y:0,width:80,height:80,
					color: {r:255,g:255,b:255,a:0},
					//async: false,
					icon: {
						x:0,y:0,width:80,height:80,	
		    			src: resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev.png',
        			},
					custom: {focusable: true},  
        		},
        	],        		
        },
        {
        	id: 'pause',
			type: 'widget',
        	x:((ToGetResolution.SceneResolution*0.572917 + ToGetResolution.offsetFor2560*2)/2 - 80/2),y:67,width:80,height:80,	//508((0.020833 + 0.013542 +0.093229 + 0.011979)*ToGetResolution.SceneResolution + 3*80/1920*ToGetResolution.SceneResolution  +ToGetResolution.offsetFor2560 + ToGetResolution.offsetForPrePauseNext)
        	color: Volt.hexToRgb('#FFFFFF','0'),
        	children: [
        		{
        			type: 'widget',
					x:0,y:0,width:80,height:80,
					color: Volt.hexToRgb('#FFFFFF','0'),
        		},  
        		{
        			type: 'cmNormalButton',
					id: 'pause_btn',
					x:0,y:0,width:80,height:80,
					color: {r:255,g:255,b:255,a:0},
					//async: false,
					icon: {
						x:0,y:0,width:80,height:80,	
		    			src: resMgr.getImgPath()+'/music_player_icon/mc_play_icon_pause_f.png',
        			},
					custom: {focusable: true},  
        		},
        	],           		
        },    
        {	
        	id: 'next',
			type: 'widget',
        	x:((ToGetResolution.SceneResolution*0.572917 + ToGetResolution.offsetFor2560*2)/2 + 80/2 + ToGetResolution.SceneResolution*0.011979),y:67,width:80,height:80,//611	 ((0.020833 + 0.013542 +0.093229 + 0.011979 + 0.011979)*ToGetResolution.SceneResolution + 4*80/1920*ToGetResolution.SceneResolution +ToGetResolution.offsetFor2560 +ToGetResolution.offsetForPrePauseNext)
        	color: Volt.hexToRgb('#FFFFFF','0'),
        	children: [
        		{
        			type: 'widget',
					x:0,y:0,width:80,height:80,
					color: Volt.hexToRgb('#FFFFFF','0'),
        		},  
        		{
        			type: 'cmNormalButton',
					id: 'next_btn',
					x:0,y:0,width:80,height:80,
					color: {r:255,g:255,b:255,a:0},
					//async: false,
					icon: {
						x:0,y:0,width:80,height:80,	
		    			src: resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next.png',
        			},
					custom: {focusable: true},  
        		},
        	],            		
        }, 
        {
        	id: 'repeat',
			type: 'widget',
        	x:(ToGetResolution.SceneResolution*0.572917 + ToGetResolution.offsetFor2560*2 -40 -80- ToGetResolution.SceneResolution*0.010938 -80),y:67,width:80,height:80,	//877 //((0.020833 + 0.013542 +0.093229 + 0.011979 + 0.011979 + 0.096875)*ToGetResolution.SceneResolution + 5*80/1920*ToGetResolution.SceneResolution  +ToGetResolution.offsetFor2560 +ToGetResolution.offsetForMusicControl + ToGetResolution.offsetForRepeartShuffle)
        	color: Volt.hexToRgb('#FFFFFF','0'),
        	children: [
        		{
        			type: 'widget',
					x:0,y:0,width:80,height:80,
					color: Volt.hexToRgb('#FFFFFF','0'),
        		},  
        		{
        			type: 'cmNormalButton',
					id: 'repeat_btn',
					x:0,y:0,width:80,height:80,
					color: {r:255,g:255,b:255,a:0},
					//async: false,
					icon: {
						x:0,y:0,width:80,height:80,	
		    			src: '{{ repeatIcon }}',
        			},
					custom: {focusable: true},  
        		},
        	],        		
        },        	
        {
        	id: 'shuffle',
			type: 'widget',
        	x:(ToGetResolution.SceneResolution*0.572917 + ToGetResolution.offsetFor2560*2 -40 -80),y:67,width:80,height:80,	//978  (0.020833 + 0.013542 +0.093229 + 0.011979 + 0.011979 + 0.096875 + 0.010938)*ToGetResolution.SceneResolution + 6*80/1920*ToGetResolution.SceneResolution  +ToGetResolution.offsetFor2560 +ToGetResolution.offsetForMusicControl + ToGetResolution.offsetForRepeartShuffle
        	color: Volt.hexToRgb('#FFFFFF','0'),
        	children: [
        		{
        			type: 'widget',
					x:0,y:0,width:80,height:80,
					color: Volt.hexToRgb('#FFFFFF','0'),
        		},  
        		{
        			type: 'cmNormalButton',
					id: 'shuffle_btn',
					x:0,y:0,width:80,height:80,
					color: {r:255,g:255,b:255,a:0},
					//async: false,
					icon: {
						x:0,y:0,width:80,height:80,	
		    			src: '{{ shuffleIcon }}',
        			},
					custom: {focusable: true},  
        		},
        	],          		
        },   
        ],
        
	},
};
 
exports = MusicPlayerCtrlBarTemplate;

