 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Music player view template
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var ToGetResolution = Volt.require("app/common/run-time-info.js");
var resMgr = Volt.require('app/controller/resource-controller.js');
var MusicPlayerViewTemplate = {
    container: {
		id:'music_player_view',
        type: 'widget',
        x: 0, y: -216, width: ToGetResolution.SceneResolution, height: 1080, 
        color: Volt.hexToRgb('#60748b','100'),

        children: [
        	{
        		type: 'widget',
        		x: 0 , y:0, width:ToGetResolution.SceneResolution, height: 1080,
        		color: Volt.hexToRgb('#000000','25'),
        	},
        	/*
        	{
        		id: 'thumbnailArea',
        		type: 'widget',
				x: (ToGetResolution.SceneResolution*0.572917/2 -418/2  + ToGetResolution.offsetFor2560), y: 137, width: 418, height: 418, 
	cropOverflow: true,
				color: Volt.hexToRgb('#000000','0'),
//				color: { r: 0, g: 0, b: 0, a:0 }, //SRA change here
				children: [
		        	{
		        		type: 'image',
		        		x:0, y:0, width:418, height:418,
		        		async: true,
		        		src: '',
		        	},
		        	{
		        		id: 'musicThumb',
		        		type: 'image',
		        		x:0, y:0, width:418, height:418,
		        		src: '{{ thumbUrl }}',
		        	},
				],
   			},
   			*/
        	{
         		id: 'thumbnailArea',     
				type: 'image',
				color: { r: 0, g: 0, b: 0, a:0 }, //SRA change here
				x: (ToGetResolution.SceneResolution*0.572917/2 -418/2  + ToGetResolution.offsetFor2560), y: 137, width: 418, height: 418, 
				fillMode: 'center',
				src:'',				
   			},
		    {
		    	id: 'HDIcon',
		    	type: 'image',
		    	async: true,	        		
		    	x:(ToGetResolution.SceneResolution*0.572917/2 - 70/2 +ToGetResolution.offsetFor2560), y:497, width:70, height:38,//x  515
		    	src: '',
		    	opacity:0,
		    },   			
	        {
		        id: 'musicTitle',
	        	type: 'Text', // need to check the requirement later and check whether the TextWidgetEx is Okay for it to avoid other defects--- chaoming.li
        		x: 200, y:587, width:ToGetResolution.SceneResolution*0.572917 + ToGetResolution.offsetFor2560*2 - 400, height:-1, //width is 700, -1 is the solution for the defect DF150224-01658 by sp001.mao
        		textColor: Volt.hexToRgb('#FFFFFF'),
        		text: '{{ title }}',
        		ellipsize: true,
        		font: 'SamsungSmart_Light 46px', 
        		verticalAlignment : 'center',
        		horizontalAlignment : 'center', 
	        },	  
	        {
		        id: 'musicArtist',
	        	type: 'text',
        		x: 200 , y:649, width:ToGetResolution.SceneResolution*0.572917+ToGetResolution.offsetFor2560*2 - 400, height:34, //width is 700 
        		textColor: Volt.hexToRgb('#FFFFFF'),
        		text: '{{ artist }}',
        		ellipsize: true,
        		font: 'SamsungSmart_Light 30px', 
        		verticalAlignment : 'center',
        		horizontalAlignment : 'center',         		
	        },		        
        	{
        		id: 'currTime',
        		type: 'text',
        		x: 40, y:797, width:200, height:30, 
        		textColor: Volt.hexToRgb('#FFFFFF'),
        		opacity:153,
        		text: '00:00',
        		font: 'SamsungSmart_Light 24px', 
        		verticalAlignment : 'center',
        		horizontalAlignment : 'left', 				
        	}, 
        	{
        		id: 'totalTime',
        		type: 'text',
        		x: (ToGetResolution.SceneResolution*0.572917 -200 -40 + ToGetResolution.offsetFor2560*2 ), y:797, width:200, height:30, 
        		textColor: Volt.hexToRgb('#FFFFFF'),
        		opacity:153,
        		text: '00:00',
        		font: 'SamsungSmart_Light 24px', 
        		verticalAlignment : 'center',
        		horizontalAlignment : 'right', 				
        	},   
        	{
        		id: 'stepWidget',
        		type: 'cmProgress',
        		x: 40 , y: 839, width:(ToGetResolution.SceneResolution*0.572917 -80  +ToGetResolution.offsetFor2560*2 ), height:2,
    			minValue: 0,
    			value: 0,
    			maxValue: 1000,
				active: true,
				responserBarWidth: 1040,
				responserBarHeight: 36,
				custom: {focusable: true},
        	}, 
        ],
    },  
    //template of native msgBox 1 btn
    msgBox_1: {
        type: 'MessageBox',
        width: ToGetResolution.SceneResolution, height:1080,
        color: Volt.hexToRgb('#0f1826',85),
        contentType: 'multi_line_content_type',
        contentTextFont: 'SamsungSmart_Light 34px',
        bTitle: false,
        titleText: '',
        buttonType: 'button_1',
        buttonTextNormalSize: 32,
        buttonTextFocusSize: 32,
        buttonNormalBorderColor: Volt.hexToRgb('#ffffff',80),
        buttonNormalBorderWidth: 1,        
//        normalButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_n.png',
//        focusButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_f.png'
    },	    
    //template of native msgBox 2 btn
    msgBox_2: {
        type: 'MessageBox',
        width: ToGetResolution.SceneResolution, height:1080,
        color: Volt.hexToRgb('#0f1826',85),
        contentType: 'multi_line_content_type',
        contentTextFont: 'SamsungSmart_Light 34px',
        bTitle: false,
        titleText: '',
        buttonType: 'button_2',
        buttonTextNormalSize: 32,
        buttonTextFocusSize: 32,
        buttonNormalBorderColor: Volt.hexToRgb('#ffffff',80),
        buttonNormalBorderWidth: 1,        
//        normalButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_n.png',
//        focusButtonImagePath: resMgr.getImgPath()+'/button/btn_style_c_f.png'
    },	
    
	msgBox_0:
	{
		type: 'MessageBox',
        width: ToGetResolution.SceneResolution, height:1080,
        color: Volt.hexToRgb('#0f1826',85),
        contentType: 'multi_line_content_type',
        contentTextFont: 'SamsungSmart_Light 34px',
        bTitle: false,
        titleText: '',
        buttonType: 'no_button',
        buttonNormalBorderColor: Volt.hexToRgb('#ffffff',80),
        buttonNormalBorderWidth: 1,         
        //buttonTextNormalSize: 32,
        //buttonTextFocusSize: 32,
        //normalButtonImagePath: 'images/1080/button/btn_style_c_n.png',
        //focusButtonImagePath: 'images/1080/button/btn_style_c_f.png',
    },
};

exports = MusicPlayerViewTemplate;
