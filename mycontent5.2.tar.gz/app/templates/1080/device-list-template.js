var resMgr = Volt.require('app/controller/resource-controller.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var DevPopupTemplate = {
    container : {
        type: 'widget',
        x: 0, y: 189, width: mycontentWidth, height : 704,
	    color : Volt.hexToRgb('#ffffff', 0),
        children : [
        	{
				type: 'widget',
				id: 'device-list-bg',
		    	x: 0, y: 1, width: mycontentWidth, height : 695,
		    	color : Volt.hexToRgb('#0a233d'), 
			},
            {
				type: 'widget',
                x: 399+(mycontentWidth-1920)/2, y: 97, width: 1122, height: 1,
                color: Volt.hexToRgb('#f2f2f2'),
                opacity: 255*0.6,
			},
			{
				type: 'text',
				x: 399+(mycontentWidth-1920)/2, y: 0, width: 1122, height: 96,
				horizontalAlignment : 'center',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 34px',
				textColor: Volt.hexToRgb('#f2f2f2'),
				opacity: 255,
				text: '{{ title }}'
			},
			{
				type: 'text',
				x: 399+(mycontentWidth-1920)/2, y: 128, width: 1122, height: 48,
				horizontalAlignment : 'center',
				verticalAlignment : 'center',
				font: 'SamsungSmart_Light 26px',
				textColor: Volt.hexToRgb('#ffffff'),
				opacity: 255*0.9,
				text: '{{ devDesc }}'
			},
			{
    			type: 'text',
				id: 'selected-items-id',
    			x: 399+(mycontentWidth-1920)/2, y: 176, width: 560, height: 48,
    			horizontalAlignment : 'right',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 26px',
    			textColor: Volt.hexToRgb('#ffffff'),
    			opacity: 255*0.6,
    			text: '{{ itemText }}'
    		},
    		{
    			type: 'text',
				id: 'total-size-id',
    			x: 997+(mycontentWidth-1920)/2, y: 176, width: 524, height: 48,
    			horizontalAlignment : 'left',
    			verticalAlignment : 'center',
    			font: 'SamsungSmart_Light 26px',
    			textColor: Volt.hexToRgb('#ffffff'),
    			opacity: 255*0.6,
    			text: '{{ sizeText }}'
    		},
    		{
	    		type: 'image',
	    		x:395+(mycontentWidth-1920)/2,y:228,width:782,height:87,
	    		fillMode: 'center',
	    		src: '{{ upArrowImg }}',
			},
			{
	    		type: 'image',
	    		x:395+(mycontentWidth-1920)/2,y:604,width:782,height:87,
	    		fillMode: 'center',
	    		src: '{{ downArrowImg }}',
			},
			{
				type: 'widget',
		    	x: 0, y: 0, width: mycontentWidth, height : 1,
		    	color : Volt.hexToRgb('#ffffff'), 
		    	opacity: 255 * 0.05,
			},
			{
				type: 'widget',
		    	x: 0, y: 696, width: mycontentWidth, height : 2,
		    	color : Volt.hexToRgb('#000000'), 
		    	opacity: 255 * 0.15,
			},
			{
	    		type: 'image',
	    		x:0,y:698,width:mycontentWidth,height:6,
	    		src: resMgr.getImgPath()+'/popup/popup_shadow.png',
			}
        ]
    },

	button : {
    	type: 'cmNormalButton',
		id: 'dev-cancel_id',
        x: 1261+(mycontentWidth-1920)/2, y: 415, width: 270+10, height: 66,
        //color: Volt.hexToRgb('#f2f2f2',0),
        custom: {focusable: true},
    },
/*    
    list : {
    	type: 'ResizeableGrid',
        x: 395, y: 315, width: 814, height: 288,
        //rows:4,
        rows:9999,
        itemWidth: 814,
        itemHeight: 72,
        //color : Volt.hexToRgb('#0f1826',255),
		//opacity: 255*0.85,
        parent: scene,
        custom: {focusable: true},
    },
*/
	defContent:{
		type: 'text',
    	x: 395+(mycontentWidth-1920)/2, y: 315, width: 814, height: 288,
		textColor: Volt.hexToRgb('#ffffff'),
		opacity: 255,
		text: 'No storage devices found.',
		font: 'SamsungSmart_Light 34px', 
		verticalAlignment : 'center',
		horizontalAlignment : 'center', 	        
	},
    
	list:{
		    id: 'deviceList',
		    type: 'cmNormalSingleList',
		    x: 395+(mycontentWidth-1920)/2, y: 315, width: 814, height: 288,
			opacity: 255,
			scrollType: "Vertical",
		    custom: {focusable: true}, 
	},

	devListItem:{
		type: 'widget',
		x: 0, y: 0, width:814, height: 72,
		color: Volt.hexToRgb('#000000','1'),
		children:[
			{
	    		type: 'image',
	    		x:20,y:21,width:30,height:30,
	    		src: '{{ imgUrl }}',
			},
	        {
	        	type: 'text',
	        	x: 70, y:0, width:300, height:72,
	    		textColor: Volt.hexToRgb('#ffffff'),
	    		opacity: 255*0.6,
	    		text: '{{ title1 }}',
	    		font: 'SamsungSmart_Light 26px', 
	    		verticalAlignment : 'center',
	    		horizontalAlignment : 'left', 	        	
	        },
	        {
	        	type: 'text',
	        	x: 380, y:0, width:420, height:72,
	    		textColor: Volt.hexToRgb('#ffffff'),
	    		opacity: 255*0.6,
	    		text: '{{ devSize }}',
	    		font: 'SamsungSmart_Light 26px', 
	    		verticalAlignment : 'center',
	    		horizontalAlignment : 'right', 	        	
	        },
	        {
	        	type: 'widget',
	            x: 0, y: 70, width: 814, height: 1,
	            color: Volt.hexToRgb('#f2f2f2'),
	            opacity: 255*0.6,
	 //           custom: {focusable: true},
	        },
	        {
	        	type: 'widget',
	            x: 0, y: 0, width: 814, height: 2,
	            color: Volt.hexToRgb('#f2f2f2'),
	            opacity: 0,
	//            custom: {focusable: true},
	        },
	        {
	        	type: 'widget',
	            x: 0, y: 0, width: 2, height: 72,
	            color: Volt.hexToRgb('#f2f2f2'),
	            opacity: 0,
	//            custom: {focusable: true},
	        },
	        {
	        	type: 'widget',
	            x: 0, y: 69, width: 814, height: 2,
	            color: Volt.hexToRgb('#f2f2f2'),
	            opacity: 0,
	//            custom: {focusable: true},
	        },
	        {
	        	type: 'widget',
	            x: 811, y: 0, width: 3, height: 72,
	            color: Volt.hexToRgb('#f2f2f2'),
	            opacity: 0,
	 //           custom: {focusable: true},
	        },
		] 
	},

};

exports = DevPopupTemplate;


