 /** 
 * @author  Chen Xuemei (xnicole.chen@samsung.com)
 * 			
 * @fileoverview  Edit model view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var resMgr = Volt.require('app/controller/resource-controller.js');
var EditModeViewTemplate = {
    container: {
        type: 'widget',
        x: 0, y: 0, width: mycontentWidth, height: 72,
        color: Volt.hexToRgb('#0f1826'),
        children:[
        	{
                type: 'text', x: 418, y: 0, width: 180, height: 72,
                verticalAlignment : 'center',
                horizontalAlignment: 'left',
                textColor : Volt.hexToRgb('#ffffff'),
                opacity: 255,
                font : 'SamsungSmart_Light 28px',
                text : '{{ itemText }}',
                custom : {
					multilingual : {
						SID : '',
						PLUS: '',
					}
				},
            },
            {
                type: 'text', x: 600, y: 0, width: 100, height: 72,
                verticalAlignment : 'center',
                horizontalAlignment: 'left',
                textColor : Volt.hexToRgb('#24b6f4'),
                opacity: 255,
                font : 'SamsungSmart_Light 31px',
                text : '{{ numText }}'
            },
            {
	        	type: 'widget',
				id: 'select_all_id',
				color: Volt.hexToRgb('#f2f2f2',0),
	            x: mycontentWidth-900, y: 0, width: 300, height: 72,
	            children:[
	            	/*
	            			{
						type: 'image',
						x: 60, y: 17, width: 38, height: 38,
						src: resMgr.getImgPath()+'/CheckBox/btn_icon_ms_selectall_nor_box.png',
					},*/
	            	{
		                type: 'cmNormalButton',
						id: 'select_all_btn',
						x: 0, y: 0, width: 300, height: 72,
		                color: { r: 0xf2, g: 0xf2, b: 0xf2, a: 0 },
		                text: {
		                	x: 0, y: 0, width: 300, height: 72,
							color: { r: 0xff, g: 0xff, b: 0xff, a: 255 },
		                	font : 'SamsungSmart_Light 28px',
		                	text : '{{ selectText }}',
		                },
		                custom: {focusable: true},  
		            }
	            ]
	        },
	        {
	        	type: 'widget',
				id: 'operation_id',
				color: Volt.hexToRgb('#f2f2f2',0),
	            x: mycontentWidth-599, y: 0, width: 300, height: 72,
	            children:[
	            	{
		                type: 'cmNormalButton',
						id: 'operation_btn',
						x: 0, y: 0, width: 300, height: 72,
		                color: { r: 0xf2, g: 0xf2, b: 0xf2, a: 0 },
		                text: {
		                	x: 0, y: 0, width: 300, height: 72,
							color: { r: 0xff, g: 0xff, b: 0xff, a: 255 },
		                	font : 'SamsungSmart_Light 28px',
		                	text : '{{ delText }}',
		                },
		                custom: {focusable: true},  
		            }
	            ]
	        },
	        {
	        	type: 'widget',
				id: 'cancel_id',
				color: Volt.hexToRgb('#f2f2f2',0),
	            x: mycontentWidth-299, y: 0, width: 300, height: 72,
	            children:[
	            	{
		                type: 'cmNormalButton',
						id: 'cancel_btn',
						x: 0, y: 0, width: 300, height: 72,
		                color: { r: 0xf2, g: 0xf2, b: 0xf2, a: 0 },
		                text: {
		                	x: 0, y: 0, width: 300, height: 72,
							color: { r: 0xff, g: 0xff, b: 0xff, a: 255 },
		                	font : 'SamsungSmart_Light 28px',
		                	text : '{{ cancelText }}',
		                },
		                custom: {focusable: true},  
		            }
	            ]
	        },
	        {
                type: 'widget',
				id: 'cur_dev_name_id',
				color: Volt.hexToRgb('#f2f2f2',0),
				x: 0, y: 0, width: 383, height: 72,
                children:[                	
                	{
                		type: 'cmNormalButton',
						id: 'selector_btn',
						x: 0, y: 0, width: 383, height: 72,
		                color: { r: 0xf2, g: 0xf2, b: 0xf2, a: 0 },
						text:{
							x: 0, y: 0, width: 300, height: 72,
							color: { r: 0xff, g: 0xff, b: 0xff, a: 255 },
							verticalAlignment : 'center',
                			horizontalAlignment: 'left',
							font : 'SamsungSmart_Light 28px',
	                		text : '{{ devName }}'
                		},
                		icon: {
						    x: 339, y: 25, width: 30, height: 22,
						    src: resMgr.getImgPath()+'/Arrow/popup_dropdown_arrow_n.png',
						},
                		custom: {focusable: true},  
               		}
                ]
            },
            /*
            {
				type: 'image',
				id: 'arrow_image',
				x: 339, y: 25, width: 30, height: 22,
				src: resMgr.getImgPath()+'/Arrow/popup_dropdown_arrow_n.png',
			},*/
			{
    			type: 'widget',
                x: 383, y: 0, width: 1, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255*0.1,
    		},
    		{
    			type: 'widget',
                x: 1019, y: 0, width: 1, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255*0.1,
    		},
    		{
    			type: 'widget',
                x: 1320, y: 0, width: 1, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255*0.1,
    		},
    		{
    			type: 'widget',
                x: 1620, y: 0, width: 1, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255*0.1,
    		},
        ]
    },
    focusDevSelector: {
    	type: 'widget',
		id: 'edit-devselector-id',
        x: 0, y: 0, width: 383, height: 72,
        color: Volt.hexToRgb('#3d7fc9',0),
        children: [
    		{
    			type: 'widget',
                x: 0, y: 0, width: 383, height: 3,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 69, width: 383, height: 3,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 0, width: 3, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 380, y: 0, width: 3, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		}
        ]
    },
    focusSelAll: {
    	type: 'widget',
		id: 'edit-select-id',
        x: 1020, y: 0, width: 300, height: 72,
        color: Volt.hexToRgb('#ffffff',0),
        children: [
    		{
    			type: 'widget',
                x: 0, y: 0, width: 300, height: 4,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 68, width: 300, height: 4,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 0, width: 4, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 296, y: 0, width: 4, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		}
        ]
    },
    focusOption: {
    	type: 'widget',
		id: 'edit-option-id',
        x: 1321, y: 0, width: 300, height: 72,
        color: Volt.hexToRgb('#ffffff',0),
        children: [
    		{
    			type: 'widget',
                x: 0, y: 0, width: 300, height: 4,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 68, width: 300, height: 4,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 0, width: 4, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 296, y: 0, width: 4, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		}
        ]
    },
    focusCancel: {
    	type: 'widget',
		id: 'edit-cancel-id',
        x: 1620, y: 0, width: 300, height: 72,
        color: Volt.hexToRgb('#3d7fc9',0),
        children: [
    		{
    			type: 'widget',
                x: 0, y: 0, width: 300, height: 4,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 68, width: 300, height: 4,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 0, y: 0, width: 4, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		},
    		{
    			type: 'widget',
                x: 296, y: 0, width: 4, height: 72,
                color: Volt.hexToRgb('#ffffff'),
                opacity: 255,
    		}
        ]
    },
};

exports = EditModeViewTemplate;
