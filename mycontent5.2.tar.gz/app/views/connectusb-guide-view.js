 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Connect USB device guide view
 * @date    2014/07/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Backbone = Volt.require('modules/backbone.js');
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var connecusbGuidesViewTemplate = Volt.require('app/templates/1080/connectusb-guide-view-template.js');
var Q = Volt.require('modules/q.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var self = null;
var KeyCode = CommonInfo.KeyCode;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");	
var voiceGuide = Volt.require('app/common/voice-guide.js');	
var EventMediator = RunTimeInfo.EventMediator;	
var EventType = CommonInfo.EventType;
var connText = resMgr.getText('COM_TV_SID_CONNECT')+',';
var plugText = resMgr.getText('COM_SID_PLUG_AND_PLAY_KR_YEONGEOL')+',';	
var upDetailText = resMgr.getText('COM_SID_TV_DISPLAY_PHOTOS_VIDEOS_MUSIC_DRIVE')+',';
var downDetailText = resMgr.getText('COM_SID_CONNECT_FLASH_HARD_USB_TV')+',';
var BalloonTips = Volt.require('app/views/balloon-tips.js');
var offSet = RunTimeInfo.offSet;

/**
 * Display usb page  
 * @param {Object} usb page properties
 * @param 
 * @constructor
 * @extends {BaseView}
 */
var ConUsbGuidePage= PanelCommon.BaseView.extend({
	template: connecusbGuidesViewTemplate.container,
	btnClose : null,	
	btnListener: null,
	focusListener:null,
	returnBtn:null,
	exitBtn:null,
	balloon:null,
	
	/** Render and run the usb page
	* @name render	 
	* @memberOf ConUsbGuidePage
	* @method
	* @return {Object} 	 
	* */
    render : function(){
		print('mcConnectionGuideView.js : render()');
		var mainView = Volt.require('app/views/main-view.js');
		var usbGuideWidget = loadTemplate(this.template, null, mainView.getViewContainer(), false);
		self.setWidget(usbGuideWidget);
		EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);
		

		//self.widget.onKeyEvent = self.onKeyEvent;
		self.setUsbGuideImage();
		self.createButton();
		self.renderButton();
				
		self.setAccessilibity();	
		
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '1');
		stepText = stepText.replace('<<B>>', '1');
		
		var txt = stepText+ ', ' + connText +', '+ plugText +', '
			+ upDetailText +', '+ downDetailText +', '+ resMgr.getText('COM_SID_CLOSE')+ ', '+resMgr.getText('TV_SID_BUTTON');
		
		voiceGuide.play(txt);
		
		self.returnBtn = self.widget.getDescendant('return-arrow');    	
		self.exitBtn = self.widget.getDescendant('exit-arrow');
						
		self.focusListener = new FocusListener;
		self.focusListener.onFocusIn = self.onFocusIn;
		self.focusListener.onFocusOut = self.onFocusOut;
		
		if(self.returnBtn){
			self.returnBtn.addListener(self.btnListener);
			self.returnBtn.addFocusListener(self.focusListener);
			self.returnBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000',20),});
			self.returnBtn.setIconImage({state: "all",
										  src: resMgr.getImgPath()+'/common/comn_icon_tm_return.png',});
			//self.exitBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.returnBtn.setIconAlpha({state: "all", alpha: 153,});
			self.returnBtn.setIconAlpha({state: "focused",alpha: 255,});
			self.returnBtn.setIconAlpha({state: "focused-roll-over",alpha: 255,});

			self.returnBtn.setIconScaleFactor({state: "all", scaleX: 1.0, scaleY: 1.0});
			self.returnBtn.setIconScaleFactor({state: "focused-roll-over", scaleX: 1.1, scaleY: 1.1});

		}
		if(self.exitBtn){
			self.exitBtn.addListener(self.btnListener);
			self.exitBtn.addFocusListener(self.focusListener);
			self.exitBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000',20),});
			self.exitBtn.setIconImage({state: "all",
										  src: resMgr.getImgPath()+'/common/comn_icon_tm_close.png',});
			//self.exitBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.exitBtn.setIconAlpha({state: "all", alpha: 153,});
			self.exitBtn.setIconAlpha({state: "focused",alpha: 255,});
			self.exitBtn.setIconAlpha({state: "focused-roll-over",alpha: 255,});

			self.exitBtn.setIconScaleFactor({state: "all", scaleX: 1.0, scaleY: 1.0});
			self.exitBtn.setIconScaleFactor({state: "focused-roll-over", scaleX: 1.1, scaleY: 1.1});
		}	

		if(RunTimeInfo.visibleCursor == true){
			self.onUsbGuideCursorShow();
		}

		
		return self;
	},
	/** onFocusIn 	 
	* @name onFocusIn	 
	* @memberOf ConMobileGuidePage
	* @param {Object}button
	* @method
	* @return {} 	 
	* */

	onFocusIn: function(button){
		print("connection usb onFocusIn id:",button.id);
		Log.e("connection usb onFocusIn id:" + button.id);
		
		 if(button.id == 'exit-arrow'){		
			
			var txt = resMgr.getText('COM_SID_EXIT') + ', ' + resMgr.getText('TV_SID_BUTTON');

			voiceGuide.play(txt);
			
		}else if(button.id == 'return-arrow'){
			
			var txt = resMgr.getText('COM_SID_RETURN') + ', ' + resMgr.getText('TV_SID_BUTTON');

			voiceGuide.play(txt);
		}		
	
    },
    
	onFocusOut: function(button){
		print('connection usb view onFocusOut >>> Destroy balloon.....');
		Log.e('connection usb view onFocusOut >>> Destroy balloon.....');
		
		self.hideTooltips();		
	
    },

	/** get one connect MINI support flag 
	* @name setUsbGuideImage	 
	* @memberOf ConUsbGuidePage
	* @method 
	* @return {void} 	 
	* */
	getOneConMiniSupportFlag : function(){
		var ret = SystemInfo.getBoolValue(SystemInfo.KEY_ONE_CONNECT_MINI_SUPPORTED);
		print('main-view.js, SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED = ',SystemInfo.KEY_ONE_CONNECT_MINI_SUPPORTED);
		print('main-view.js, SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED ret = ',ret);
		Log.f("main-view.js, SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED ret = " + ret);
		//ret = 1;
		return ret;
    },
    
	/** set usb guide image 
	* @name setUsbGuideImage	 
	* @memberOf ConUsbGuidePage
	* @method 
	* @return {void} 	 
	* */
	setUsbGuideImage: function(){
		print('connectusb-guide-view.js setUsbGuideImage()');
		var usbImage = self.widget.getDescendant('usb_icon');
		if(usbImage == null){
			return;
		}
		var appConfig = Volt.require("app/common/app-config.js");
		var boardType = appConfig.getSWVersion();
		print('connectusb-guide-view.js setUsbGuideImage bordType:',boardType);
		Log.e("connectusb-guide-view.js setUsbGuideImage bordType:" + boardType);
		if(boardType == 'HKPDEUC' || boardType == 'HKPAKUC' 
			|| boardType == 'HKPUABC' || boardType == 'HKPDCNC'){
			usbImage.src = resMgr.getImgPath()+'/Connection/img/rc_cg_usb_02.png';
		}
		else{
			if(boardType == 'HKMAKUC' || boardType == 'HKMDEUC' 
				|| boardType == 'HKMUABC' || boardType == 'HKMDCNC'){
				if(self.getOneConMiniSupportFlag() == true){
					usbImage.src = resMgr.getImgPath()+'/Connection/img/rc_cg_usb_03.png';
				}
				else{
					usbImage.src = resMgr.getImgPath()+'/Connection/img/rc_cg_usb_01.png';
				}
			}
			else{
				usbImage.src = resMgr.getImgPath()+'/Connection/img/rc_cg_usb_01.png';
			}
		}
    },
    
	/** render the  button to the view 
	* @name renderButton	 
	* @memberOf ConUsbGuidePage
	* @method 
	* @return {void} 	 
	* */
	renderButton: function(){
		print('connectusb-guide-view.js renderButton()');		
		self.btnClose = self.widget.getDescendant('usb_closeBtn');
		var buttonListener = new ButtonListener;
		self.btnListener = buttonListener;
		
		buttonListener.onButtonStateChanged = self.onButtonStateChange;
		
		buttonListener.onButtonClicked = function (button, type){
			print('----connectusb-guide-view.js buttonListener type = ',type);			
			if(button.id == 'usb_closeBtn'){
				//Backbone.history.navigate('conguides-view', {trigger: true});
				EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
				var steps = 1;
				Volt.KPIMapper.addEventLog('MY_EXIT_GUIDE_USB', {
		             d: {
		                detail : steps
		            }
		        });
					if(RunTimeInfo.visibleCursor == true){
				
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
				}
				return;				
			} else if(button.id == 'return-arrow'){
				print(" connection mobile return button click ");
				
				self.hideTooltips();
				                //Backbone.history.navigate('conguides-view', {trigger: true});
	            EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
	            RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);

				if(RunTimeInfo.visibleCursor == true){
				
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
				}
			}else if(button.id == 'exit-arrow'){
				print(" connection mobile exit button click ");
				
				self.hideTooltips();
				
				try{
					print(" Exit mycontents  Volt.exitKey() ");
					var mainView = Volt.require('app/views/main-view.js');
					mainView.widget.hide();
					Volt.exitKey();
				}
				catch(e){
					Log.e(" usb Exit mycontents  Volt.exitKey() "+e);
					Volt.exit();
				}
			}
		};

		var naviMouseListener = new MouseListener();
		self.mouseListener = naviMouseListener;
		
		self.mouseListener.onMousePointerIn = function(actor, event){
			print('mouseListener----------------------------mouse pointer in : ' + actor);
			print('mouseListener----------------------------mouse pointer in : ' + actor.id);
			if(actor==self.btnClose){
				self.btnClose.setTextColor({state: "all", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
    			self.btnClose.setFontSize({state: "all", size: 36,});
			}		
		};
		
		self.mouseListener.onMousePointerOut = function(actor, event){
			print('mouseListener----------------------------mouse pointer out : ' + actor);
			if(actor==self.btnClose){
				self.btnClose.setTextColor({state: "all", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
    			self.btnClose.setFontSize({state: "all",size: 32,});	
			}
		};
		
		if(self.btnClose != null){
			self.btnClose.addListener(buttonListener);
			self.btnClose.addMouseListener(naviMouseListener);
			self.btnClose.show();
		}

	},
	onButtonStateChange : function(button, toState){
    	print('connection usb view onButtonStateChanged button.id: '+ button.id + ' type: ' + typeof(button.id));
		print('connection usb view onButtonStateChanged toState: '+ toState + ' type: ' + typeof(toState));
		if(button.id == 'exit-arrow'){
			if(toState == 'focused'){
				self.hideTooltips();
			}else if(toState == 'focused-roll-over') {
				self.hideTooltips();
				var optionTxt = resMgr.getText('COM_SID_EXIT');
				self.showTooltips(button,optionTxt);
			}else if(toState == 'normal'){
				self.hideTooltips();
	
			}
		}else if(button.id == 'return-arrow'){
			if(toState == 'focused'){				
				self.hideTooltips();
				
			}else if(toState == 'focused-roll-over') {
				self.hideTooltips();
				var optionTxt = resMgr.getText('COM_SID_RETURN');
				self.showTooltips(button,optionTxt);
			}else if(toState == 'normal'){
				self.hideTooltips();
			}
		}    	
    },
	/** show the view
	* @name show	 
	* @memberOf ConUsbGuidePage
	* @param {boolean} aniType
	* @return deferred.promise  	 
	* */	
	show: function(aniType) {
		print('usbConnectionGuideView.js : show()');        		
		var deferred = Q.defer(); 
		self.widget.show();
		Volt.Nav.setRoot(self.widget);
		//Volt.Nav.reload();	
		//self.btnClose.setFocus();
		//Volt.Nav.focus(self.btnClose);
		deferred.resolve();
		return deferred.promise;        
    },
    
    events: {
    	//'NAV_SELECT': 'onSelect', 
	    'NAV_FOCUS':'onFocus',
	    'NAV_BLUR':'onBlur'
	},
    /** hide PC page 	 
	* @name hide	 
	* @memberOf ConUsbGuidePage
	* @param {aniType} aniType  	 
	* */
    hide: function(aniType) {
        print("------usbGuidesView hide()!");        
        var deferred = Q.defer(); 
        print("usb guide----------------1");
		self.widget.hide();
		print("usb guide----------------2");
    	deferred.resolve();
    	print("usb guide----------------3");
		return deferred.promise;
    },
	
	
	giveFocus: function(){
		this.focusWidget = null;       
	},
	/** Initialize usb view  	 
	* @name initialize	 
	* @memberOf ConUsbGuidePage
	* @method 
	* @return {Object}	 
	* */
	initialize: function(options){
	   print('ConUsbGuidePage.js : initialize()');
	   self = this;
	   EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SETTING,null);
   	   EventMediator.on(EventType.EVENT_TYPE_CURSOR_HIDE, this.onUsbGuideCursorHide, this);	
	   EventMediator.on(EventType.EVENT_TYPE_CURSOR_SHOW, this.onUsbGuideCursorShow, this);
	   EventMediator.on(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
       EventMediator.on(EventType.EVENT_TYPE_ENLARGE_CHANGE, this.onEnlargeChange, this);	
	EventMediator.trigger(EventType.EVENT_TYPE_HIDE_EXIT_ARROW);
	},
	
	onHighcontrastChange:function(){
		print('connectusb-guide-view.js:----------- onHighcontrastChange()');		
		self.setAccessilibity();	  	
	},
	
	onEnlargeChange:function(){
		print('connectusb-guide-view.js:------- onEnlargeChange()');
		self.setAccessilibity();			
	},
	
	onUsbGuideCursorHide:function(){
		print("usb guide onUsbGuideCursorHide ");

		self.hideTooltips();
		
		if(self.returnBtn != null){
			self.returnBtn.hide();
			self.returnBtn.opacity = 0;
			self.returnBtn.custom.focusable = false;
		}

		if(self.exitBtn != null){
			self.exitBtn.hide();
			self.exitBtn.opacity = 0;
			self.exitBtn.custom.focusable = false;
		}

		if(self.btnClose != null){
			self.btnClose.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
			self.btnClose.setFontSize({state: "normal",size: 32,});	
			self.btnClose.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnClose.setFontSize({state: "focused", size: 36,});		
			self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
			self.btnClose.setFontSize({state: "focused-roll-over", size: 36,});
			self.btnClose.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnClose.setFontSize({state: "selected", size: 36,});
		}
		
		Volt.Nav.reload();
	},
	
	onUsbGuideCursorShow:function(){
		print("usb guide onUsbGuideCursorShow ");


		if(self.returnBtn != null){
			self.returnBtn.show();
			self.returnBtn.opacity = 255;
			self.returnBtn.custom.focusable = true;
		}

		if(self.exitBtn != null){
			self.exitBtn.show();
			self.exitBtn.opacity = 255;
			self.exitBtn.custom.focusable = true;
		}

		if(self.btnClose != null){
			self.btnClose.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
			self.btnClose.setFontSize({state: "focused", size: 32,});		
			self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
			self.btnClose.setFontSize({state: "focused-roll-over", size: 32,});
		}

		Volt.Nav.reload();

	},
	/** destroy usb view  	 
	* @name destroy	 
	* @memberOf ConUsbGuidePage
	* @method
	* @return {void} 	 
	* */
	destroy : function(){
		print("Destroy connection mobile guide");
		if(RunTimeInfo.visibleCursor == true){
			EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
		}
		EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
		var DeviceProvider = Volt.require("app/models/device-provider.js");
		if ( DeviceProvider.getDeviceCount() > 0 ){
			Log.e("connection usb guide destroy device count > 0, show setting button");
			EventMediator.trigger(EventType.EVENT_TYPE_SHOW_SETTING,null);
		}
		if(self.btnClose){
			self.btnClose.removeListener(self.btnListener);
		}
		
		if(self.exitBtn){
			self.exitBtn.removeListener(self.btnListener);	
			self.exitBtn.removeFocusListener(self.focusListener);
		}

		if(self.returnBtn){
			self.returnBtn.removeListener(self.btnListener);
			self.returnBtn.removeFocusListener(self.focusListener);
		}

		//EventMediator.trigger(EventType.EVENT_TYPE_SHOW_SETTING,null);
		this.widget.hide();
		this.widget.destroy();
		this.widget = null;
		
		self.hideTooltips();
		
   		EventMediator.off(EventType.EVENT_TYPE_CURSOR_HIDE, this.onUsbGuideCursorHide, this);	
		EventMediator.off(EventType.EVENT_TYPE_CURSOR_SHOW, this.onUsbGuideCursorShow, this);
		
		EventMediator.off(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
        EventMediator.off(EventType.EVENT_TYPE_ENLARGE_CHANGE, this.onEnlargeChange, this);		

	},
	/** setDefaultFocus for usb view  	 
	* @name setDefaultFocus	 
	* @memberOf ConUsbGuidePage
	* @method
	* @return {void} 	 
	* */
	setDefaultFocus: function(){
		print('------------connectusb-guide-view.js, setDefaultFocus()');
	    //Volt.Nav.focus(self.btnClose);
	    //self.btnClose.setFocus();
   	},
	
	onFocus: function(widget){

    },

    onBlur: function(widget){

    },
	/** the click event
	* @name onKeyEvent	 
	* @memberOf ConUsbGuidePage	
	* @param {enum} the key id
	* @param {boolean} the key type	
	* @method
	* @return {boolean} */
	onKeyEvent : function(key, type){
		print('usb guide ------ onKeyEvent key:', key, ',type :',type);
		if (type != Volt.EVENT_KEY_RELEASE)
		{
			return false;
		}		
		
		var ret = true;
		
		switch(key)
		{
			case KeyCode.returnKey:{	
				print('usb guide ------------------ return key');
				
				self.hideTooltips();
				
                EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);		
				var steps = 1;
				Volt.KPIMapper.addEventLog('MY_EXIT_GUIDE_USB', {
		             d: {
		                detail : steps
		            }
		        });
				if(RunTimeInfo.visibleCursor == true){
			
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
				}
                break;		
			}
			default:
				ret = false;
	    	    break;
		}
		return ret;
	},

	showFocus: function(){
    	print('connectusb-guide-view.js');
    },


	/** createButton for usb view  	 
	* @name createButton	 
	* @memberOf ConUsbGuidePage
	* @method
	* @return {void} 	 
	* */
	createButton: function(){			
		var btnwidgetClose = self.widget.getDescendant('usb_closeBtn');
		self.btnClose = btnwidgetClose;
    	self.btnClose.setText ({state: "all",text: resMgr.getText('COM_SID_CLOSE'),});   
    	
    	self.btnClose.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },});    	    	 		
    	self.btnClose.setFontSize({state: "normal",size: 32,}); 
    	self.btnClose.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
    	self.btnClose.setBorder({state: "normal",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
    	self.btnClose.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnClose.setFontSize({state: "focused", size: 36,});
		self.btnClose.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a:0 },});
		self.btnClose.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});	
		self.btnClose.setBorder({state: "focused",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
		self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnClose.setFontSize({state: "focused-roll-over",size: 36,});					    
		self.btnClose.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a:0 },});
		self.btnClose.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
    	self.btnClose.setBorder({state: "focused-roll-over",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
    	self.btnClose.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnClose.setFontSize({state: "selected",size: 36,});					    
		self.btnClose.setBackgroundColor({state: "selected", color: { r:255, g:255, b:255, a:0 },});
		self.btnClose.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		//self.btnClose.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
    	
    	self.btnClose.Show();			   
    },
    
    setAccessilibity: function(){
		if(HALOUtil.highContrast==false && HALOUtil.enlarge==false){
				self.setTextStyle(1);
	    }else if(HALOUtil.highContrast==false && HALOUtil.enlarge==true){			   
			self.setTextStyle(2);		    	
	    }else if(HALOUtil.highContrast==true && HALOUtil.enlarge==false){	    	 
	    	self.setTextStyle(3);		    	
	    }else {
	    	self.setTextStyle(4);		    	
	    }
		
	},
    
     setTextEnlarge: function(){
    	self.widget.getDescendant('usb_page_title').font='SamsungSmart_Light 127px';
    	self.widget.getDescendant('usb_page_uptext').font='SamsungSmart_Light 43px';
    	self.widget.getDescendant('usb_page_downtext').font='SamsungSmart_Light 40px';
    	
    },
    restoreTextEnlarge: function(){
    	self.widget.getDescendant('usb_page_title').font='SamsungSmart_Light 85px';
    	self.widget.getDescendant('usb_page_uptext').font='SamsungSmart_Light 36px';
    	self.widget.getDescendant('usb_page_downtext').font='SamsungSmart_Light 34px';
    	
    },
    setTextHighContrast: function(){
    	self.widget.getDescendant('usb_page_title').textColor = {r:0x00, g:0x00, b:0x00};
    	self.widget.getDescendant('usb_page_uptext').textColor = {r:0x00, g:0x00, b:0x00};
    	self.widget.getDescendant('usb_page_downtext').textColor = {r:0x00, g:0x00, b:0x00};    	
    },
    restoreTextHighContrast: function(){
    	self.widget.getDescendant('usb_page_title').textColor = {r:0x0f, g:0x18, b:0x27};
    	self.widget.getDescendant('usb_page_uptext').textColor = {r:0x37, g:0x3c, b:0x42};
    	self.widget.getDescendant('usb_page_downtext').textColor = {r:0x78, g:0x78, b:0x78};   	
    },
    
    setBtnEnlarge: function(){
    		self.btnClose.setFontSize({state: "normal",size: 43,});
    		self.btnClose.setFontSize({state: "focused",size: 43,});
    		self.btnClose.setFontSize({state: "focused-roll-over",size: 43,});
    		self.btnClose.setFontSize({state: "selected",size: 43,});  		   		
    		self.btnClose.setSize(382, 76);
    		self.btnClose.x=769+offSet;     	
    },
    restoreBtnEnlarge: function(){
    		self.btnClose.setFontSize({state: "normal",size: 32,});
    		self.btnClose.setFontSize({state: "focused",size: 36,});
    		self.btnClose.setFontSize({state: "focused-roll-over",size: 36,});
    		self.btnClose.setFontSize({state: "selected",size: 36,});
    		self.btnClose.setSize(324, 76);
    		self.btnClose.x=799+offSet;	
    },
    
    setBtnHighContrast: function(){
    	//button high contrast
    		self.btnClose.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
			self.btnClose.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});	
			self.btnClose.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
			self.btnClose.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
			/*
			self.btnClose.setBorder({state: "normal",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
			self.btnClose.setBorder({state: "focused",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
			self.btnClose.setBorder({state: "focused-roll-over",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
			self.btnClose.setBorder({state: "selected",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});	
			*/
			self.btnClose.setTextColor({state: "normal", color: { r:00, g:00, b:00, a:255 },}); 
			self.btnClose.setTextColor({state: "focused", color: { r:00, g:00, b:00, a:255 },}); 
			self.btnClose.setTextColor({state: "focused-roll-over", color: { r:00, g:00, b:00, a:255 },}); 
			self.btnClose.setTextColor({state: "selected", color: { r:00, g:00, b:00, a:255 },});     	
    },
    
    
    restoreBtnHighContrast: function(){    	
    	    self.btnClose.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
			self.btnClose.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});	
			self.btnClose.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
			self.btnClose.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
			/*
			self.btnClose.setBorder({state: "normal",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnClose.setBorder({state: "focused",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnClose.setBorder({state: "focused-roll-over",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnClose.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			*/
			self.btnClose.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
			self.btnClose.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
			self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
			self.btnClose.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});   	
    },
     
     setTextStyle: function(style){
    	if(style==1){
    		self.restoreTextEnlarge();
    		self.restoreBtnEnlarge();
    		self.restoreTextHighContrast();
    		self.restoreBtnHighContrast();  				  				
    	}else if(style==2){
    		self.setTextEnlarge();
    		self.setBtnEnlarge();
    		self.restoreTextHighContrast();
    		self.restoreBtnHighContrast();  		 		   		
    	}else if(style==3){
    		self.restoreTextEnlarge();
    		self.restoreBtnEnlarge();
    		self.setTextHighContrast();
    		self.setBtnHighContrast();    		 		
    	}else{
    		self.setTextEnlarge();
    		self.setBtnEnlarge();
    		self.setTextHighContrast();
    		self.setBtnHighContrast();		 			
    	}
    },
    
	isInRootPath:function(){
		return true;
	},
	
	showTooltips :function(button, text){
		Log.e("showTooltips >>> Destroy balloon.....text:"+text);
		print("showTooltips >>> Destroy balloon.....text:"+text);
		
		if(button == null || text == null){			
			Log.e("button == null || text == nul");
			return;
		}
		
    	var opt = {
	    		text: text,
	    		x: button.x,
	    		y: 6,
				wdgHeight: button.height,
				wdgWidth : button.width,
	    		fontsize: 30,
	    		font: '30px',
	    		tailType: 'up',
    	};

    	self.balloon = new BalloonTips();
    	self.balloon.show(opt);	

	},
	
	hideTooltips:function(){
		print('hideTooltips >>> .....');
		if(self.balloon != null){
			print('hideTooltips >>> Destroy balloon.....');
			Log.e("hideTooltips >>> Destroy balloon.....");
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
	},
	setFocusReturnFromMusicPlayer:function(){
		print("connection usb guide view setFocusReturnFromMusicPlayer set root to self.widget");
		Log.e("connection usb guide view setFocusReturnFromMusicPlayer set root to self.widget");

		Volt.Nav.setRoot(self.widget);
	},
    
});

	

exports = ConUsbGuidePage;