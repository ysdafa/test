 /** 
 * @author  zhao rui (rui9527.zhao@samsung.com)		
 * 			
 * @fileoverview  filter view 
 * @date    2015/01/14 (last modified date)
 *
 * Copyright 2015 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var MyContentOptionType = CommonInfo.MyContentOptionType;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var OptionText = Volt.require("app/common/option-text.js");
var VideoFilterTextList = OptionText.VideoFilterTextList;
var VideoSortByTextList = OptionText.VideoSortByTextList;
var MusicSortByTextList = OptionText.MusicSortByTextList;
var RecordSortByTextList = OptionText.RecordSortByTextList;
var PanelCommon = Volt.require('lib/panel-common.js');
var self;

var Filter_View = PanelCommon.BaseView.extend({
	mainView: null,
	isDimFirstPlus: [],
	isShowSecPlus: [],
	currentViewSortText: "",
	lastViewSortText: "",
    optionMenuIndex : -1, //save option menu selected index
    optionMenuSubIndex : [], //save option menu first selected index

	initialize: function() {
		print("Filter_View initialize");
		self = this;
		self.mainView = Volt.require('app/views/main-view.js');
		self.optionMenuSubIndex[0] = 0;
		self.optionMenuSubIndex[1] = -1;
	},
	
	getFirstText : function(viewType){
		print("Filter_View getFirstText");
		getFirstSublistText(viewType);
	},
	
	getSecondOptionText : function( nListIndex ){
		print("Filter_View getSecondText");
		var tempT;
		var tempViewType = this.optionMenuSubIndex[0];
		tempT = getSecondSublistText( nListIndex, tempViewType );
		return tempT;
	},

	getSortLength : function( viewType ){
		var tempLength = 0;
		tempLength = getSortLen( viewType );
		return tempLength;
	},

	getSortTextByViewIndex : function( viewindex ){
		var text = getSortText(viewindex);
		return text;
	},
	
});


function getFirstSublistText( viewType ){
	print("filter-View.js, getFirstSublistText");
	var optionText = [];
	optionText = [
		        	getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
	            	getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
	            	getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
		    	];
	if ( self.mainView.getCopySupportFlag() ){
		var tempLen = optionText.length;
		optionText[tempLen] = getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_COPY);
	}
	self.mainView.headerView.optionParam.firstOptionText = optionText;
	
	for (var index = 0; index < optionText.length; index++){
		self.isDimFirstPlus[index] = false;
		self.isShowSecPlus[index] = false;
	}
	if ( viewType == EViewType.eAllContentView ){
		self.isDimFirstPlus[1] = true;
		self.isDimFirstPlus[2] = true;
		self.isDimFirstPlus[3] = true;
		self.isDimFirstPlus[4] = true;
		self.isShowSecPlus[0] = true;
	}
	else{
		self.isDimFirstPlus[2] = true;
		self.isDimFirstPlus[3] = true;
		self.isDimFirstPlus[4] = true;
		self.isShowSecPlus[0] = true;
		self.isShowSecPlus[1] = true;
	}

};

function getSecondSublistText( nListIndex, viewType ){
	var Text;
	switch(nListIndex){
		case 0:
			Text = getFilterText();
			break;
		case 1:
			Text = getSortText(viewType);
			break;
		default:
			break;
	}
	print("filter-View.js, getSecondSublistText length:",Text.length);
	return Text;
};

function getFilterText(){
	var options;
	if(self.mainView.getRecordSupportFlag() == 1){
		options = getSourceText(VideoFilterTextList.DeviceTypeTextList);
	}
	else{
		options = getSourceText(VideoFilterTextList.DeviceTypeNoRecordTextList);
	}
	print("filter-View.js, getFilterText length:",options.length);
	return options;
};

function getSortText( viewType ){
	print("filter-View.js, getSortText:", viewType);
	var Text;
	switch(viewType)
	{
		case 1:
			Text = getSourceText(VideoSortByTextList.DeviceTypeTextList);
			break;
		case 2:
			Text = getSourceText(VideoSortByTextList.DeviceTypeTextList);
			break;
		case 3:
			Text = getSourceText(MusicSortByTextList.DeviceTypeTextList);
			break;
		case 4:	
			Text = getSourceText(RecordSortByTextList.DeviceTypeTextList);
			break;
		default:
			Text = getSourceText(VideoSortByTextList.DeviceTypeTextList);
			break;
	}
	return Text;
};

function getSortLen( viewType ){
	print("filter-View.js, getSortLen:", viewType);
	var Text;
	switch(viewType)
	{
		case 1:
			Text = getSourceText(VideoSortByTextList.DeviceTypeTextList);
			break;
		case 2:
			Text = getSourceText(VideoSortByTextList.DeviceTypeTextList);
			break;
		case 3:
			Text = getSourceText(MusicSortByTextList.DeviceTypeTextList);
			break;
		case 4:	
			Text = getSourceText(RecordSortByTextList.DeviceTypeTextList);
			break;
		default:
			Text = getSourceText(VideoSortByTextList.DeviceTypeTextList);
			break;
	}
	return Text.length;
};

function getSourceText( optionSids ){
	var options = [];
	var index = 0;
	while(index < optionSids.length ){
		options[index] = getText(optionSids[index]);
		index ++;
	}
	print("filter-View.js, getSourceText length:",options.length);
	return options;
};

function getText(txtId){
	return Volt.i18n.t(txtId);
};

var filterView = new Filter_View();
exports = filterView;
