 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Connect pc device guide view
 * @date    2014/07/17 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Backbone = Volt.require('modules/backbone.js');
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var connectpcGuidesViewTemplate = Volt.require('app/templates/1080/connectpc-guide-view-template.js');
var Q = Volt.require('modules/q.js');
var CommonInfo = Volt.require("app/common/define.js");
var KeyCode = CommonInfo.KeyCode;
var self = null;
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var AppLauncher = Volt.require("app/controller/app-launch.js");
var LaunchAppID = CommonInfo.LaunchAppID;
var netController = null;
var mainView = Volt.require('app/views/main-view.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");	
var EventMediator = RunTimeInfo.EventMediator;	
var EventType = CommonInfo.EventType;
var voiceGuide = Volt.require('app/common/voice-guide.js');
var deviceProvider = Volt.require("app/models/device-provider.js");
var DeviceType = CommonInfo.DeviceType;
/**
 * Display PC page  
 * @param {Object} PC page properties
 * @param 
 * @constructor
 * @extends {BaseView}
 */
var ConPCGuidePage= PanelCommon.BaseView.extend({
	template: connectpcGuidesViewTemplate.Container,	
	index:1,
	
	preparePage: null,
	connectPage: null,
	disconnectPage: null,
	installPage: null,
	linkPage: null,
	browserPage: null,
	btnNet: null,
	btnShowFiles: null,
	btnClose: null,
	btnNaviLeft:null,
	btnNaviRight:null,
	btnListener: null,
	mouseListener: null,
	latestDevice: null,
	isConnected: true,
	lastestDLNADevice:'',
	muteFocus : null,
	/** the network listener
	* @name onKeyEvent	 
	* @memberOf ConPCGuidePage	
	* @param {networkType} networkType
	* @parm {connectFlag} connectFlag	
	* @method */
	onNetworkListener : function(networkType, connectFlag){
		print('[connectpc-guide-view]onNetworkListener-----------networkType = ' + networkType + ', connectFlag = ' + connectFlag);
		if(networkType == 1){
			if(connectFlag==false){
				self.connectPage.hide();
				self.disconnectPage.show();				
			}else{
				self.connectPage.show();
				self.disconnectPage.hide();				
			}			
			 			
		} else if(networkType == 0){
			if(connectFlag==false){
				self.connectPage.hide();
				self.disconnectPage.show();				
			}else{
				self.connectPage.show();
				self.disconnectPage.hide();				
			}							
		} 	
	},
	
	onDeviceConnect: function(deviceInfo){
        print('[connectpc-guide-view.js] onDeviceConnect :',deviceInfo );
		if(deviceInfo.get('type') != DeviceType.DEVICE_TYPE_DLNA){
       		return ;
		}
		
		if(self == null || self == undefined || 
		   self.btnShowFiles == null || self.btnShowFiles == undefined ||
		   self.btnClose == null || self.btnClose == undefined){
			print('[connectpc-guide-view.js]onDeviceConnect, self == null || self == undefined || self.btnShowFiles == null || self.btnShowFiles == undefined');
			return ;
		}
		
		
		self.btnShowFiles.show();
		self.browserPage.getChild('pc_browser_list').show();	
 		self.btnShowFiles.x = 600;
 		self.btnClose.x = 996; 
 		self.btnShowFiles.setFocus();
 		//self.btnClose.killFocus();	 					 				 		       	
   },
   
   onDeviceDisconnect: function(deviceID,deviceType){
   		print("[connectpc-guide-view.js] Remove device id:",deviceID, 'deviceType :',deviceType);
		if(deviceType != DeviceType.DEVICE_TYPE_DLNA){
			return ;
		}		
		
		if(self == null || self == undefined || 
		   self.btnShowFiles == null || self.btnShowFiles == undefined ||
		   self.btnClose == null || self.btnClose == undefined){
			print('[connectpc-guide-view.js]onDeviceDisconnect, self == null || self == undefined || self.btnShowFiles == null || self.btnShowFiles == undefined');
			return ;
		}
		
		self.btnShowFiles.hide();
		self.browserPage.getChild('pc_browser_list').hide();
 		self.btnClose.x = 798;
 		self.btnClose.setFocus(); 
 		//self.btnShowFiles.killFocus();	
    },

	/** Render
	* @name render	 
	* @memberOf ConPCGuidePage
	* @method 	 
	* */
	render : function(){			
		netController = Volt.require('app/controller/net-controller.js');
		netController.registerListener(this.onNetworkListener, this);
		deviceProvider.regsiterListener(this, this.onDeviceConnect, this.onDeviceDisconnect);
		EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);
		print('[Connectpc-guide-view.js] : render()---------------------------------------------');
		var mainView = Volt.require('app/views/main-view.js');
		var pcGuideWidget = loadTemplate(this.template, null, mainView.getViewContainer(), false);
		print('[Connectpc-guide-view.js] : sucess-------------------------------------------------');
		self.setWidget(pcGuideWidget);
		//self.widget.onKeyEvent = self.onKeyEvent;
	
		self.muteFocus = self.widget.getChild('mute_focus');
		self.muteFocus.show();
	
		self.preparePage = 	self.widget.getChild('pc_prepare_page');
		self.preparePage.show();

		self.playPrepareGuide();		
		
		self.connectPage = 	self.widget.getChild('pc_connect_page');
		self.connectPage.hide();
		
		self.disconnectPage = self.widget.getChild('pc_disconnect_page');
		self.disconnectPage.hide();	
	

		self.installPage = 	self.widget.getChild('pc_install_page');
		self.installPage.hide();	
		
		self.linkPage = self.widget.getChild('pc_link_page');	
		self.linkPage.hide();
		
		self.browserPage = 	self.widget.getChild('pc_browser_page');	
		self.browserPage.hide();
		
		self.createButton();
		self.renderButton();
		
		self.ControlNavi();
		self.btnNaviLeft.hide();
		
		self.linkPage.getChild('pc_link_Devicename').text = Vconf.getValue('db/menu/network/devicename/tv_name');
		if (netController.getWiredState() || netController.getWirelessState()) {
			if(deviceProvider.getDLNADeviceCount() > 0){
				self.lastestDLNADevice = self.getLastestDLNADevice();
				//self.connectPage.getChild(13).text = resMgr.getText('COM_SID_TV_CONNECTED_TO_COLON').replace('<<A>>',lastestDLNADevice);
				self.connectPage.getChild('pc_conn_list').text = resMgr.getText('COM_SID_TV_CONNECTED_TO_COLON')+self.lastestDLNADevice;				
				self.browserPage.getChild('pc_browser_list').text = resMgr.getText('COM_IDS_MSG_BT_CONNECTED_KR_YEONGEOL').replace('<<A>>',self.lastestDLNADevice);
			}
			
		}else{
//			self.connectPage.getChild('pc_conn_list').hide();
			self.browserPage.getChild('pc_browser_list').hide();
		}		
		return self;
	},
	
	renderButton: function(){
		print('connectpc-guide-view.js renderButton()');
		self.btnNet = self.disconnectPage.getDescendant('pc_networkSettingBtn');
		self.btnShowFiles = self.browserPage.getDescendant('pc_browser_showFilesBtn');
		self.btnClose = self.browserPage.getDescendant('pc_browser_closeBtn');
		var buttonListener = new ButtonListener;
		self.btnListener = buttonListener;
		buttonListener.onButtonClicked = function (button, type){
			print('----connectpc-guide-view.js buttonListener type = ',type);
			if(button.id == 'pc_networkSettingBtn'){
				AppLauncher.launch(LaunchAppID.APP_ID_NETWORK_SETTINGS, {key1 : 'value1'});					
			}
			else if(button.id == 'pc_browser_showFilesBtn'){
				print('[connectpc-guide-view.js]--------switchView');
					if (self.isConnected == true) {
						print('[connectpc-guide-view.js]--------switchView---self.isConnected==',self.isConnected);
						var DeviceProvider = Volt.require("app/models/device-provider.js");
						if (DeviceProvider.getDeviceCount() == 0 ){
							return;
						}else{																	
							mainView.categoryView.selectLastestDLNADevice();							
							//Backbone.history.navigate('all-contentview', {trigger: true});
							EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
							RunTimeInfo.router.switchView(EViewType.eAllContentView, EViewSwitchAniType.eNoneAni);
							return;
						}																	
					} 				
			}
			else if(button.id == 'pc_browser_closeBtn'){
				//Backbone.history.navigate('conguides-view', {trigger: true});
				EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
				return;				
			}
		};
		if(self.btnNet != null){
			self.btnNet.addListener(buttonListener);
			self.btnNet.show();
		}
		if(self.btnShowFiles != null){
			self.btnShowFiles.addListener(buttonListener);
			self.btnShowFiles.show();
		}
		if(self.btnClose != null){
			self.btnClose.addListener(buttonListener);
			self.btnClose.show();
		}
	},
	
	ControlNavi: function(){
		var btnLeft = self.widget.getDescendant('pc_navi_l'); 
		var btnRight = self.widget.getDescendant('pc_navi_r'); 
		
		self.btnNaviLeft = btnLeft;
		self.btnNaviRight = btnRight;
		   
		var naviMouseListener = new MouseListener();
		self.mouseListener = naviMouseListener;
		
		self.mouseListener.onMousePointerIn = function(actor, event){
			print('mouseListener----------------------------mouse pointer in : ' + actor);
			if(actor==btnLeft){
				self.btnNaviLeft.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_l_f.png';
			}else if(actor==btnRight){
				self.btnNaviRight.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_r_f.png';
			}
					

		};
		
		self.mouseListener.onMousePointerOut = function(actor, event){
			print('mouseListener----------------------------mouse pointer out : ' + actor);
			if(actor==btnLeft){
				self.btnNaviLeft.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_l_n.png';
			}else if(actor==btnRight){
				self.btnNaviRight.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_r_n.png';
			}

		};
		
		self.mouseListener.onMouseButtonReleased = function(actor, event){
			print('mouseListener----------------------------mouse button released : ' + actor);
			if(actor==btnLeft){
				self.switchToLeft();
				
			}else if(actor==btnRight) {
				self.switchToRight();
				
			}
			
		};
		
		self.btnNaviLeft.addMouseListener(naviMouseListener);
		self.btnNaviRight.addMouseListener(naviMouseListener);
		
	},

	getLastestDLNADevice: function(){		
		var DeviceProvider = Volt.require("app/models/device-provider.js");		
		var item = DeviceProvider.getLastestDLNADevice();
		if(item == null){
			return;
		} else {
			return item.get('name');			
		}			
	},
	
	/** show
	* @name show	 
	* @memberOf ConPCGuidePage
	* @param {aniType} aniType  	 
	* */
	show: function(aniType) {
		print('Connectpc-guide-view.js : show()');		
		var deferred = Q.defer(); 
		self.widget.show();
		Volt.Nav.setRoot(self.widget);
		Volt.Nav.reload();	
		self.muteFocus.setFocus();
		deferred.resolve();
		return deferred.promise;
    },
    
     events: {
    	//'NAV_SELECT': 'onSelect', 
	    'NAV_FOCUS':'onFocus',
	    'NAV_BLUR':'onBlur'
	},
	
	/** hide PC page 	 
	* @name hide	 
	* @memberOf ConPCGuidePage
	* @param {aniType} aniType  	 
	* */
    hide: function(aniType) {
        print("[Connectpc-guide-view.js]------ConnGuidesView hide()!");
        var deferred = Q.defer();       
		self.widget.hide();	
    	deferred.resolve();    	
		return deferred.promise;
    },
	
	/** the click event
	* @name onKeyEvent	 
	* @memberOf ConPCGuidePage	
	* @param {key} the key id
	* @parm {type} the key type	
	* @method */
	onKeyEvent : function(key, type){
		print('pc guide ------ onKeyEvent');
		
		if (type != Volt.EVENT_KEY_RELEASE)
		{
			return false;
		}		
		
		var ret = true;
		switch(key){
        	case KeyCode.left:{        	
				print('[Connectpc-guide-view.js] ------ switch left self.index==', self.index);
				if ((self.index == 5) && !self.isConnected){
					print('[Connectpc-guide-view.js]------ switch right self.isConnected == false');                		
					self.btnShowFiles.setFocus();
					var txt = resMgr.getText('COM_SID_WHOW_MY_FILES')+ ', '+resMgr.getText('TV_SID_BUTTON');
					voiceGuide.queuingPlay(txt);						
					self.btnClose.killFocus(); 			    	     
					self.isConnected = true; 
					break;         
				}                  	
				self.switchToLeft();               
            }
        	break;
			case KeyCode.right:{                
                if ((self.index == 5) && self.isConnected){                	
            		print('[Connectpc-guide-view.js] ------ switch right self.isConnected == true'); 
            		self.btnShowFiles.killFocus();
		    	    self.btnClose.setFocus();  
					
					var txt = resMgr.getText('COM_SID_CLOSE')+ ', '+resMgr.getText('TV_SID_BUTTON');
					voiceGuide.play(txt);
					
            		self.isConnected = false; 
            		break;        	
                }                  
                print('[Connectpc-guide-view.js] ------ switch right');
                self.switchToRight();    
                break;	             
            }
			case KeyCode.returnKey:{		
                EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);			
                //Backbone.history.navigate('conguides-view', {trigger: true});
                /*   
				Volt.KPIMapper.addEventLog('MY_EXIT_GUIDE_PC', {
		            d: {
		                detail : self.index
		            }
		        });	
		        */					
			}
			break;			     
    	default:
    		ret = false;
    	    break;
		}
		return ret;
	},
	
	/** called while click Left key	 
	* @name switchToLeft	 
	* @memberOf ConPCGuidePage
	* @method 	 
	* */
	switchToLeft:function(){
		 print("self.index ==",self.index);
		 if (self.index == 5) {		 	
		 	self.browserPage.hide();
		 	self.linkPage.show();
			self.btnNaviRight.show();
			
			self.playLinkGuide();
			
		 	self.index--;
		 	self.muteFocus.setFocus();
		 } else if (self.index == 4) {
		 	self.installPage.show();
			self.btnNaviRight.show();
			
			self.playInstallGuide();

		 	self.linkPage.hide();
		 	self.index--;
		 	self.muteFocus.setFocus();
		 } else if (self.index == 3) {
		 	//Get the network status and judge which page will be called
		 	self.btnNaviRight.show();
		 	if (netController.getWiredState() || netController.getWirelessState()) {
		 		print("[Connectpc-guide-view.js]--------getWiredState= " + netController.getWiredState());
		 		self.connectPage.show();

				self.playNetworkConnectGuide();
				
				self.muteFocus.setFocus();
		 	} else {
		 		self.disconnectPage.show(); 
				self.btnNet.setFocus();
				self.playNoNetworkConnectGuide();
				
		 	}
 	
		 	self.installPage.hide();
		 	self.index--;
		 } else if (self.index == 2) {
		 	self.preparePage.show();
		 	self.btnNaviLeft.hide();	
			self.btnNaviRight.show();
			
			self.playPrepareGuide();

		
		 	//Get the network status and judge which page will be called
		 	if (netController.getWiredState() || netController.getWirelessState()) {		 		
		 		self.connectPage.hide();
		 		print("[Connectpc-guide-view.js]--------self.connectPage.hide()");
		 	} else {
		 		print("[Connectpc-guide-view.js]--------self.disconnectPage.hide()");
		 		self.disconnectPage.hide(); 
		 	} 	 	
		 	self.index--;
		 	self.muteFocus.setFocus();
		 } else if (self.index == 1) {
		 	self.muteFocus.setFocus();
		 	return;
		 }
		
	},
	/** called while click right key	 
	* @name switchToRight	 
	* @memberOf ConMobileGuidePage
	* @method 	 
	* */
	switchToRight:function(){
		 print("self.index ==",self.index);
		 if (self.index == 1) {	
		 	self.preparePage.hide();
		 	self.btnNaviLeft.show();		 	
		 	print("[Connectpc-guide-view.js]--------getWiredState= " + netController.getWiredState());
		 	//Get the network status and judge which page will be called
		 	if (netController.getWiredState() || netController.getWirelessState()) {		 		
		 		self.connectPage.show();
				
				self.playNetworkConnectGuide();
				
				self.muteFocus.setFocus();
		 		print("[Connectpc-guide-view.js]--------self.connectPage.show()");
		 	} else {
		 		print("[Connectpc-guide-view.js]--------self.disconnectPage.show()");
		 		self.disconnectPage.show(); 
		 		self.btnNet.setFocus();
				
				self.playNoNetworkConnectGuide();
		 	}
		 	
		 	 	
		 	self.index++;
		 	self.muteFocus.setFocus();
		 } else if (self.index == 2) {
		 	//Get the network status and judge which page will be called
		 	if (netController.getWiredState() || netController.getWirelessState()) {		 		
		 		self.connectPage.hide();
		 		print("[Connectpc-guide-view.js]--------self.connectPage.hide()");
		 	} else {
		 		print("[Connectpc-guide-view.js]--------self.disconnectPage.hide()");
		 		self.disconnectPage.hide(); 
		 	}

		 	self.installPage.show();
			self.btnNaviLeft.show();
			self.playInstallGuide();
			
		 	self.index++;
		 	self.muteFocus.setFocus();
		 } else if (self.index == 3) {	 	
		 	self.installPage.hide();
		 	self.linkPage.show();
			self.btnNaviLeft.show();
			
			self.playLinkGuide();
			
		 	self.index++;
		 	self.muteFocus.setFocus();
		 } else if (self.index == 4) {	
		 	self.browserPage.show();	 	
		 	self.linkPage.hide();
		 	self.btnNaviLeft.show();
		 	self.btnNaviRight.hide();
		 	if(deviceProvider.getDLNADeviceCount() > 0){
			 	self.btnShowFiles.show();	
		 		self.btnShowFiles.x = 611;
		 		self.btnClose.x = 987; 
		 		self.btnShowFiles.setFocus();
			 	self.playConnectBrowserGuide();		 	
		 	}else {
				self.browserPage.getChild('pc_browser_list').hide();
						
		 		self.btnShowFiles.hide();
		 		self.btnClose.x = 798;
		 		self.btnClose.setFocus(); 
				
		 		self.playNoConnectBrowserGuide(); 
		 	}	 	
		 	self.index++;
		 } else if (self.index == 5) {
		 	return;
		 }	
	},

	/** Initialize pc view  	 
	* @name initialize	 
	* @memberOf ConPCGuidePage
	* @method 	 
	* */
	initialize: function(options){
	   print('[Connectpc-guide-view.js] : initialize()');
	   self = this;
	},
	/** destroy pc view  	 
	* @name destroy	 
	* @memberOf ConPCGuidePage
	* @method 	 
	* */
	destroy : function(){
		if(self.btnNet){
			self.btnNet.removeListener(self.btnListener);
		}
		if(self.btnShowFiles){
			self.btnShowFiles.removeListener(self.btnListener);
		}
		if(self.btnClose){
			self.btnClose.removeListener(self.btnListener);
		}
		this.widget.hide();
		this.widget.destroy();
		netController.unregisterListener(this.onNetworkListener, this); 
		deviceProvider.unregsiterListener(this, this.onDeviceConnect, this.onDeviceDisconnect);
	},
	
	/** setDefaultFocus for PC view  	 
	* @name setDefaultFocus	 
	* @memberOf ConPCGuidePage
	* @method 	 
	* */
	setDefaultFocus: function(){
	    Volt.Nav.focus(self.widget);
   	},
	
	onFocus: function(widget){

    },
    
     onBlur: function(widget){

    },
    
    showFocus: function(){
    	if (self.index == 2){
    		if(!netController.getWiredState() && !netController.getWirelessState()){
    			self.btnNet.setFocus();	    			
    		}
    	}else if(self.index == 4){
    		if(netController.getWiredState() || netController.getWirelessState()){
    			self.btnShowFiles.setFocus();	    			
    		}else{
    			self.btnClose.setFocus();
    		}
    		
    	}
    },
    
    
    /** createButton for PC view  	 
	* @name createButton	 
	* @memberOf ConPCGuidePage
	* @method 	 
	* */
     createButton: function(){	
		var btnwidgetNet = self.disconnectPage.getDescendant('pc_networkSettingBtn');    	
    	//self.btnNet = btnwidgetNet.getUIElement();
    	self.btnNet = btnwidgetNet;
    	self.btnNet.setText ({state: "all", 
							  text: resMgr.getText('COM_TV_SID_NETWORK_SETTINGS'),
					});    	
    	self.btnNet.setTextColor({state: "normal", 
			                     color: { r:64, g:64, b:64, a:204 },
			        }); 
		self.btnNet.setFontSize({state: "normal",
								size: 32,
					});  
    	self.btnNet.setBackgroundImage({state: "normal", 
								       src: resMgr.getImgPath()+'/button/btn_style_b_n.png',
					});
		self.btnNet.setTextColor({state: "focused", 
			                      color: { r:255, g:255, b:255, a:255 },
			        });       	      	    	
    	self.btnNet.setFontSize({state: "focused",
								size: 36,
					});	
		self.btnNet.setBackgroundColor({state: "focused", 
			                      		color: { r:33, g:158, b:230, a:255 },}); 
			                      		
		self.btnNet.setTextColor({state: "focused-roll-over", 
			                      color: { r:255, g:255, b:255, a:255 },
			        });       	      	    	
    	self.btnNet.setFontSize({state: "focused-roll-over",
								size: 36,
					});	
		self.btnNet.setBackgroundColor({state: "focused-roll-over", 
			                      		color: { r:33, g:158, b:230, a:255 },}); 	                      			
    	self.btnNet.setFocus();
		/*
    	self.btnNet.setBackgroundImage({state: "focused",
								       src: resMgr.getImgPath()+'/button/btn_style_b_f.png',
					});*/


    	self.btnNet.show();
    	print('[connectpc-guide-view.js]-------createButton networkSetting'); 
    	
    	var btnwidgetCheck = self.browserPage.getDescendant('pc_browser_showFilesBtn');    	
    	//self.btnShowFiles = btnwidgetCheck.getUIElement();
    	self.btnShowFiles = btnwidgetCheck;
    	self.btnShowFiles.setText ({state: "all",
									text: resMgr.getText('COM_SID_WHOW_MY_FILES'),
						   });     	
    	self.btnShowFiles.setTextColor({state: "focused", 
										color: { r:255, g:255, b:255, a:255 },
						   }); 
    	self.btnShowFiles.setFontSize({state: "focused",
									   size: 36,
						   });
		self.btnShowFiles.setBackgroundColor({state: "focused", 
			                      		color: { r:33, g:158, b:230, a:255 },});
			                      		
		self.btnShowFiles.setTextColor({state: "focused-roll-over", 
										color: { r:255, g:255, b:255, a:255 },
						   }); 
    	self.btnShowFiles.setFontSize({state: "focused-roll-over",
									   size: 36,
						   });
		self.btnShowFiles.setBackgroundColor({state: "focused-roll-over", 
			                      		color: { r:33, g:158, b:230, a:255 },});	                      		
		/*
    	self.btnShowFiles.setBackgroundImage({state: "focused", 
											  src: 'images/1080/button/btn_style_b_f.png',
						   });  	*/	 		
    	
    	//self.btnShowFiles.setText (self.btnShowFiles.btnState.NORMAL,resMgr.getText('COM_SID_WHOW_MY_FILES'));
		self.btnShowFiles.setTextColor({state: "normal", 
    								    color: { r:64, g:64, b:64, a:255 },
    					   });  	    	   		
    	self.btnShowFiles.setFontSize({state: "normal",
									   size: 32,
						   });
    	self.btnShowFiles.setBackgroundImage({state: "normal", 
											  src: resMgr.getImgPath()+'/button/btn_style_b_n.png',
						   });
    	print('~~~~~~~~~~~~self.btnShowFiles.x : ',self.btnShowFiles.x);
		print('~~~~~~~~~~~~self.btnShowFiles.y : ',self.btnShowFiles.y); 
	    
    	self.btnShowFiles.show();
    	print('[connectpc-guide-view.js]-------createButton checkContentBtn'); 
		
    	
    	var btnwidgetClose = self.browserPage.getDescendant('pc_browser_closeBtn');    	
    	//self.btnClose = btnwidgetClose.getUIElement();
    	self.btnClose = btnwidgetClose;
    	self.btnClose.setText ({state: "all",
								text: resMgr.getText('COM_SID_CLOSE'),
					   });    	
    	self.btnClose.setTextColor({state: "focused", 
									color: { r:255, g:255, b:255, a:255 },
					   }); 
    	self.btnClose.setFontSize({state: "focused",
								   size: 36,
					    });
		self.btnClose.setBackgroundColor({state: "focused", 
			                      		color: { r:33, g:158, b:230, a:255 },});
			                      		
		self.btnClose.setTextColor({state: "focused-roll-over", 
									color: { r:255, g:255, b:255, a:255 },
					   }); 
    	self.btnClose.setFontSize({state: "focused-roll-over",
								   size: 36,
					    });
		self.btnClose.setBackgroundColor({state: "focused-roll-over", 
			                      		color: { r:33, g:158, b:230, a:255 },});	                      		
		/*
    	self.btnClose.setBackgroundImage({state: "focused", 
										 src: 'images/1080/button/btn_style_b_f.png',
						});*/
    	   		
    	//self.btnClose.setText (self.btnClose.btnState.NORMAL, resMgr.getText('COM_SID_CLOSE'));
    	self.btnClose.setTextColor({state: "normal", 
    								color: { r:64, g:64, b:64, a:255 },
    					});    	    	 		
    	self.btnClose.setFontSize({state: "normal",
								  size: 32,
						}); 
    	self.btnClose.setBackgroundImage({state: "normal", 
										  src: resMgr.getImgPath()+'/button/btn_style_b_n.png',
						});
    	print('~~~~~~~~~~~~self.btnClose.x : ',self.btnClose.x);
		print('~~~~~~~~~~~~self.btnClose.y : ',self.btnClose.y);

    	self.btnClose.show();
    	print('[connectpc-guide-view.js]-------createButton closeBtn');    	   		
    
    },
    
	isInRootPath:function(){
		return true;
	},
	
	playPrepareGuide:function(){

		var prepareText = resMgr.getText('COM_SID_STEP')+' 1 of 5, ' 
			+ resMgr.getText('COM_SID_PREPRARE') 
			+ resMgr.getText('COM_SID_LETS_GET_STARTED')
			+ resMgr.getText('COM_SID_ENJOJY_CONTEST_PC_TV_BIG_SCREEN')
			+ resMgr.getText('COM_SID_WHAT_YOU_NEED_KR_DEVICE') 
			+ resMgr.getText('COM_SID_PC_RUNNING_WINDOWS78_WIRELESS_ROUTER');
		voiceGuide.play(prepareText);

	},
	
	playNetworkConnectGuide:function(){
	
		var networkConnectText = resMgr.getText('COM_SID_STEP')+' 2 of 5, ' 
			+ resMgr.getText('COM_TV_SID_CONNECT') +', ' 
			+ resMgr.getText('COM_SID_JOIN_WIRELESS_NETWORK')
			+ resMgr.getText('COM_SID_MAKE_SURE_TV_PC_SAME_WIRELESS')
			+ (self.lastestDLNADevice == '' ? '': (resMgr.getText('COM_SID_TV_CONNECTED_TO_COLON')+ self.lastestDLNADevice+',')) 
			+ resMgr.getText('COM_SID_SET_PC_WIFI_CONNECT_SAME_NETWORK_TV');
		voiceGuide.play(networkConnectText);
	},
	
	playNoNetworkConnectGuide:function(){		
		var noNetworkConnectText = resMgr.getText('COM_SID_STEP')+' 2 of 5, ' 
			+ resMgr.getText('COM_TV_SID_CONNECT') +', ' 
			+ resMgr.getText('COM_SID_JOIN_WIRELESS_NETWORK')
			+ resMgr.getText('COM_SID_MAKE_SURE_TV_PC_SAME_WIRELESS')
			+ resMgr.getText('COM_SID_TV_NOT_CONNECTED_WIRELESS_NETWORK_NETWORK_SETTING') 
			+ resMgr.getText('COM_TV_SID_NETWORK_SETTINGS')
			+', ' + resMgr.getText('TV_SID_BUTTON');
		voiceGuide.play(noNetworkConnectText);
	},
	playInstallGuide:function(){

		var installText = resMgr.getText('COM_SID_STEP')+' 3 of 5, '
			+ resMgr.getText('COM_SID_INSTALL')+','
			+ resMgr.getText('COM_SID_INSTALL_SMART_VIEW')
			+ resMgr.getText('COM_SID_DOWNLAOD_FREE_PC_SW_SMART_VIEW')
			+ resMgr.getText('COM_SID_MIX_YOUR_WEB_BROWSER').replace('<<A>>','http://www.samsung.com/smartview2')+', '
			+ resMgr.getText('COM_SID_CLICK_DOWNLOAD');
		voiceGuide.play(installText);
	},
	
	playLinkGuide:function(){
		var tvName = resMgr.getText('TV_SID_MIX_TV_NAME_IS');
		tvName = tvName.replace('<<A>>', Vconf.getValue('db/menu/network/devicename/tv_name'));
		var linkText = resMgr.getText('COM_SID_STEP')+' 4 of 5, '
			+ resMgr.getText('COM_LINK_KR_LINK')+','
			+ resMgr.getText('COM_SID_PC_AND_TV')
			+ resMgr.getText('COM_SID_USE_SMART_VIEW_PC_TV')
			+ resMgr.getText('COM_SID_OPEN_SMART_VIEW')
			+ resMgr.getText('COM_SID_TAP_CONNECTE_TO_TV')
			+ resMgr.getText('COM_SID_CHOOSE_TV_FROM_LIST')
			+ tvName
			+ resMgr.getText('COM_SID_ENTER_PIN_SHOWN_TV');

		voiceGuide.play(linkText);
	},
	playConnectBrowserGuide:function(){
	
		var connectDeviceName = resMgr.getText('COM_IDS_MSG_BT_CONNECTED_KR_YEONGEOL');
		if(self.lastestDLNADevice != ''){
			connectDeviceName = connectDeviceName.replace('<<A>>',self.lastestDLNADevice);
		}else{
			connectDeviceName = '';
		}
		var browserText =resMgr.getText('COM_SID_STEP')+ ' 5 of 5, '
			+ resMgr.getText('COM_FBID_BROWSE_KR_WANRYO')
			+ resMgr.getText('COM_SID_START_EXPLORING')
			+ connectDeviceName
			+ resMgr.getText('COM_SID_ENJOJY_CONTEST_PC_TV_BIG_SCREEN')
			+ resMgr.getText('COM_SID_SEND_MULTIMEDIA_FROM_PC_TV')
			+ resMgr.getText('TV_SID_ACEESS_MULTIMEDIA_PC_SMARTHUB_UPPER')
			+ resMgr.getText('COM_SID_CLOSE') + ' button';

		voiceGuide.play(browserText);
	},
	
	playConnectBrowserFileGuide:function(){
	
		var connectDeviceName = resMgr.getText('COM_IDS_MSG_BT_CONNECTED_KR_YEONGEOL');
		if(self.lastestDLNADevice != ''){
			connectDeviceName = connectDeviceName.replace('<<A>>',self.lastestDLNADevice);
		}else{
			connectDeviceName = '';
		}
		var browserText = resMgr.getText('COM_SID_STEP')+' 5 of 5, '
			+ resMgr.getText('COM_FBID_BROWSE_KR_WANRYO')
			+ resMgr.getText('COM_SID_START_EXPLORING')
			+ connectDeviceName
			+ resMgr.getText('COM_SID_ENJOJY_CONTEST_PC_TV_BIG_SCREEN')
			+ resMgr.getText('COM_SID_SEND_MULTIMEDIA_FROM_PC_TV')
			+ resMgr.getText('TV_SID_ACEESS_MULTIMEDIA_PC_SMARTHUB_UPPER')
			+ resMgr.getText('COM_SID_WHOW_MY_FILES') + ' button';

		voiceGuide.play(browserText);
	},
	playNoConnectBrowserGuide:function(){	
		var browserText = resMgr.getText('COM_SID_STEP')+' 5 of 5, '
			+ resMgr.getText('COM_FBID_BROWSE_KR_WANRYO')
			+ resMgr.getText('COM_SID_START_EXPLORING')
			+ resMgr.getText('COM_SID_ENJOJY_CONTEST_PC_TV_BIG_SCREEN')
			+ resMgr.getText('COM_SID_SEND_MULTIMEDIA_FROM_PC_TV')
			+ resMgr.getText('TV_SID_ACEESS_MULTIMEDIA_PC_SMARTHUB_UPPER')+','
			+ resMgr.getText('COM_SID_CLOSE') + ' button';

		voiceGuide.play(browserText);
	},
	setFocusReturnFromMusicPlayer:function(){
		print("connection mobile guide view setFocusReturnFromMusicPlayer set root to self.widget");
		Log.e("connection mobile guide view setFocusReturnFromMusicPlayer set root to self.widget");

		Volt.Nav.setRoot(self.widget);
	},
});


exports = ConPCGuidePage;

