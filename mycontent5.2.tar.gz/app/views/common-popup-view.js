 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Common popup view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var CommonInfo = Volt.require('app/common/define.js');
var colorList = CommonInfo.colorList;
var EventType = CommonInfo.EventType;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator; 
var KeyCode = CommonInfo.KeyCode;
var MycontentsShare = Volt.require('app/templates/1080/mycontents-share.js');
var homepanelInfo = MycontentsShare.homepanelInfo;
var SingleLineList = Volt.require('lib/custom-widgets/singleline-list.js');
var SinglelineListItemView = Volt.require('app/views/singlelinelist-item-view.js');
//var MessagePopup  = Volt.require('modules/UIElement/MessagePopup.js');

/* template */
var PanelCommon = Volt.require('lib/panel-common.js');
var MainTemplate = PanelCommon.requireTemplate('main');
var MyContentsMainTemplate = Volt.require('app/templates/1080/mycontents-main-template.js');
var loadTemplate = PanelCommon.loadTemplate;

var self = null;
var CommonPopupView = PanelCommon.BaseView.extend({
    template: MainTemplate.plus,
    parentView : null,
	message: null,
    initialize: function() {
		self = this;
		var mainView = Volt.require('app/views/main-view.js');
		this.parentView = mainView.headerView;
    },

    render: function() {
        this.setWidget(loadTemplate(this.template));
        return this;
    },

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    onFocus: function(widget) {
        //print('[common-popup-view.js] PlusView.focus ' + widget.id);
		//if(widget && typeof widget.onFocus != 'function'){
        	//return ;
        //}
		//widget.onFocus();   //todo : review
    },

    onBlur: function(widget) {
        //print('[common-popup-view.js] PlusView.onBlur ' + widget.id);
        //if(widget && typeof widget.onBlur != 'function'){
        	//return ;
        //}
		//print('[common-popup-view.js] PlusView.onBlur22 ' + widget.id);
		//widget.onBlur();   //todo : review
    },
    
    /** showPlusPopup
	* @name showPlusPopup 
	* @memberOf CommonPopupView
	* @param {Object}plusObj 	
	* @method
	* @return {}  	 
	* */

	showPlusPopup: function(plusObj){
		print('[CommonPopupView.js] showPlusPopup');
		var headerView = this.parentView;
		headerView.homePlus.currentPlusPopup = null;
		headerView.homePlus.firstPlusPopup = null;
		headerView.homePlus.firstPlusContainer = null;
		
		headerView.homePlus.firstPlusContainer = this.widget;
		var container = headerView.homePlus.firstPlusContainer;
		//headerView.homePlus.firstPlusContainer = container;
		
        headerView.homePlus.firstPlusPopup = new SingleLineList();
		var popup = headerView.homePlus.firstPlusPopup;
		headerView.homePlus.currentPlusPopup = popup;
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		
		popup.create({
						x:1920-330-20,  
						y:120, 
						width:330,//265,//274+10+10,//  
						height:plusObj.height,//375,//52*(7+2),
						parent:container,
						color:{r:0, g:0, b:45, a:255},
						itemWidth:330-28,//220,//274
						itemHeight:72,//50,//52,
						itemSpace:0,
						itemMargin:120,//25				
						dataSource: plusObj.text,
						focusImages: homepanelInfo.mOptions,
						isVerticalFlag:true,
						isLoopShowingFlag:false,
						renderType: SinglelineListItemView,
						//renderType:SinglelineListRender,
						upDownIconFlag:true,
						selectIconFlag:true,
						firstPlusFlag:true,
						plusIndex: -1,
		});
		container.custom.focusable = true;
		container.onKeyEvent = __PlusHandleKey;
		container.onFocus = __PlusOnFocus;
		container.onBlur = __PlusOnBlur;
		
		popup.setListClickCallback(__PlusCallBack);
		popup.setUpArrowData({x:310/2-60/2, y:20, width:60, height:30, src: homepanelInfo.mUpArrowImage});
		popup.setDownArrowData({x:310/2-60/2, y: plusObj.height-50, width:60, height:30, src: homepanelInfo.mDownArrowImage});
		popup.setArrowShowingFlag(true);
		popup.m_ItemRenderArray[popup.m_currRenderIndex].getFocus();
		popup.listCursor.hide();
		popup.plusFocus = true;
		Volt.Nav.beginModal(container);
		Volt.Nav.focus(container);
	},
	/** showSecondPlusPopup
	* @name showSecondPlusPopup 
	* @memberOf CommonPopupView
	* @param {Object}plusObj 	
	* @method
	* @return {}  	 
	* */
	showSecondPlusPopup: function(plusObj){
		var headerView = this.parentView;
		headerView.homePlus.secondPlusPopup = null;
		headerView.homePlus.secondPlusContainer = null;
		
		headerView.homePlus.secondPlusContainer = this.widget;
		var container = headerView.homePlus.secondPlusContainer;
        headerView.homePlus.secondPlusPopup = new SingleLineList();
		var popup = headerView.homePlus.secondPlusPopup;
		headerView.homePlus.currentPlusPopup = popup;
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM_OPTION_MENU_1);

		popup.create({
						x:1920-330-20-310-10,  
						y:100+(headerView.homePlus.firstPlusPopup.m_currDataIndex+1)*52, 
						width:310,//265,//274+10+10,//  
						height:plusObj.height,//375,//52*(7+2),
						parent:container,
						color:{r:0, g:0, b:45, a:255},
						itemWidth:310-28,//220,//274
						itemHeight:71,//50,//52,
						itemSpace:0,
						itemMargin:120,				
						dataSource:plusObj.text,
						focusImages: homepanelInfo.mOptions,
						isVerticalFlag:true,
						isLoopShowingFlag:false,
						renderType: SinglelineListItemView,
						//renderType: SinglelineListRender,
						upDownIconFlag:true,
						selectIconFlag:true,
						firstPlusFlag:true,
						plusIndex: plusObj.index,
		});
		container.custom.focusable = true;
		container.onKeyEvent = __PlusHandleKey;
		container.onFocus = __PlusOnFocus;
		container.onBlur = __PlusOnBlur;
		
		popup.setListClickCallback(__PlusCallBack);
		popup.setUpArrowData({x:310/2-60/2, y:20, width:60, height:30, src: homepanelInfo.mUpArrowImage});
		popup.setDownArrowData({x:310/2-60/2, y:plusObj.height-50, width:60, height:30, src: homepanelInfo.mDownArrowImage});
		popup.setArrowShowingFlag(true);
		for (var index = 0; index < popup.m_ItemRenderArray.length; index++) {
			popup.m_ItemRenderArray[index].ListIconWidget.hide();	
		}
		if ( plusObj.index > -1 ){
			popup.m_ItemRenderArray[plusObj.index+2].ListIconWidget.src = 'images/Arrow/00_check_Activatedback.png';
			popup.m_ItemRenderArray[plusObj.index+2].ListIconWidget.show();	
		}
		else{
			popup.m_ItemRenderArray[2].ListIconWidget.src = 'images/Arrow/00_check_Activatedback.png';
			popup.m_ItemRenderArray[2].ListIconWidget.show();	
		}
		print('secondPlus m_currRenderIndex: ', popup.m_currRenderIndex );
		popup.m_ItemRenderArray[popup.m_currRenderIndex].getFocus();
		popup.listCursor.hide();
		popup.plusFocus = true;
		Volt.Nav.beginModal(container);		
		Volt.Nav.focus(container);
	},

	showMessageBox: function(msgObj){
		/*EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		var container = this.widget;
		container.custom.focusable = true;
		container.onKeyEvent = __MessageHandleKey;
		container.onFocus = __MessageBoxOnFocus;
		container.onBlur = __MessageBoxOnBlur;
		this.message = new MessagePopup();
		PopupIns = this.message;
		PopupIns.create({x:0, y:msgObj.y, height:410, parent:container});
				
		PopupIns.setMessage({height:200, message: msgObj.text});
		PopupIns.setTitle({title: msgObj.title});
		PopupIns.setButton( msgObj.buttonGroup);
		PopupIns.getFocus();
		PopupIns.show(); 
		Volt.Nav.beginModal(container);		
		Volt.Nav.focus(container);*/
	},
	
	
});

	function __MessageBoxOnFocus(widget){
	    print('__MessageBoxOnFocus ');
	}
	function __MessageBoxOnBlur(widget){
	    print('__MessageBoxOnBlur ');
	}
	function __MessageCallBack(widget){
	    print('__MessageCallBack ');
	}
	function __MessageHandleKey(keycode, keytype){
	    print('__MessageHandleKey ');
		if (keytype == Volt.EVENT_KEY_RELEASE) 
		{
			return;
		}	

		if(PopupIns != null) {
			PopupIns.keyHandler(keycode,keytype);
		}
	}	
	/** __PlusHandleKey
	* @name __PlusHandleKey 
	* @memberOf CommonPopupView
	* @param {enum}keycode
	* @param {enum}keytype 	
	* @method
	* @return {}  	 
	* */
	function __PlusHandleKey (keycode, keytype) {
		
		var mainView = Volt.require('app/views/main-view.js');
	    var headerView = mainView.headerView;
		
	    if (keytype == Volt.EVENT_KEY_RELEASE) {
	        switch(keycode) {
	            case KeyCode.returnKey:
					if ( headerView.homePlus.secondPlusContainer ){
						Volt.Nav.endModal();
						headerView.homePlus.currentPlusPopup = headerView.homePlus.firstPlusPopup;
						headerView.homePlus.secondPlusContainer.destroyChildren();
						headerView.homePlus.secondPlusContainer.color.a = 0;
						headerView.homePlus.secondPlusContainer.destroy();
						headerView.homePlus.secondPlusContainer = null;
						headerView.homePlus.secondPlusPopup = null;
						headerView.homePlus.firstPlusPopup.m_ItemRenderArray[headerView.homePlus.firstPlusPopup.m_currRenderIndex].getFocus();
						Volt.Nav.focus(headerView.homePlus.firstPlusContainer);
						EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM_OPTION_MENU_1);
						
					}
					else if ( headerView.homePlus.firstPlusContainer ){
						headerView.homePlus.firstPlusContainer.destroyChildren();
						headerView.homePlus.firstPlusContainer.color.a = 0;
						headerView.homePlus.firstPlusContainer.destroy();
						headerView.homePlus.firstPlusContainer = null;
						headerView.homePlus.firstPlusPopup = null;	
						headerView.homePlus.currentPlusPopup = null;
						Volt.Nav.focus(Volt.Nav.getItem(0));	
						Volt.Nav.endModal();
					}				
					return;
	
	            default:
					if ( headerView.homePlus.currentPlusPopup ){
						headerView.homePlus.currentPlusPopup.t_keyHandler(keycode, keytype);
					}
	                break;
	        }    
		}
	}
	/** __PlusOnFocus
	* @name __PlusOnFocus 
	* @memberOf CommonPopupView
	* @param {Object}keycode	
	* @method
	* @return {}  	 
	* */
	function __PlusOnFocus(widget){
	    print('[common-popup-view.js] __PlusOnFocus');
	    var mainView = Volt.require('app/views/main-view.js');
	    var headerView = mainView.headerView;
		headerView.homePlus.firstPlusPopup.getFocus();
	}
	
	function __PlusOnBlur(widget){
	    print('__PlusOnBlur ');
	}
	/** __PlusCallBack
	* @name __PlusCallBack 
	* @memberOf CommonPopupView
	* @param {int}nListIndex	
	* @method
	* @return {}  	 
	* */
	function __PlusCallBack(nListIndex) {
	    print('__PlusCallBack: ',nListIndex);
	    var mainView = Volt.require('app/views/main-view.js');
	    var headerView = mainView.headerView;
		if ( headerView.homePlus.currentPlusPopup == headerView.homePlus.firstPlusPopup ){
			Volt.Nav.endModal();
			if(RunTimeInfo.router.currentView.isShowSecPlus[nListIndex] == true){ //------------------------------temp
			   
				headerView.homePlus.firstPlusPopup.m_ItemRenderArray[headerView.homePlus.firstPlusPopup.m_currRenderIndex].loseFocus();
				var view1 = new CommonPopupView();
	        	headerView.secondView = view1;
	        	view1.render();
	        	
	        	headerView.optionParam.secondOptionText = RunTimeInfo.router.getCurrentView().getSecondOptionText(nListIndex);
	        	if ( headerView.optionParam.secondOptionText.length < 5 ){
	        		headerView.optionParam.secondHeight = 72*(headerView.optionParam.secondOptionText.length);
	        	}
	        	else
	        	{
	        		headerView.optionParam.secondHeight = 72*5;
	        	}
	        
	        	var tempIndex = -1;
	        	tempIndex = headerView.optionParam.secondSelectedIndex[nListIndex];
	        	print('secondSelectedIndex'+tempIndex);
	        	var tepObj = { text: headerView.optionParam.secondOptionText,
	        				   height: headerView.optionParam.secondHeight+120,
	        				   index: tempIndex,
	        				 };
	        	view1.showSecondPlusPopup(tepObj);
			}
			else{
				
				if ( headerView.homePlus.firstPlusContainer ){
					headerView.homePlus.firstPlusContainer.destroyChildren();
					headerView.homePlus.firstPlusContainer.color.a = 0;
					headerView.homePlus.firstPlusContainer.destroy();
					headerView.homePlus.firstPlusContainer = null;
					headerView.homePlus.firstPlusPopup = null;	
					headerView.homePlus.currentPlusPopup = null;
				}
				headerView.homePlus.currentPlusPopup = null;
				
				EventMediator.trigger(EventType.EVENT_TYPE_SELECT_OPTION_MENU_1, nListIndex);
			}
			headerView.optionParam.firstSelectedIndex = nListIndex;
		}
		else if ( headerView.homePlus.currentPlusPopup == headerView.homePlus.secondPlusPopup ){
			if ( headerView.homePlus.secondPlusContainer ){
				Volt.Nav.focus(headerView.homePlus.firstPlusContainer);
				
				EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM_OPTION_MENU_1);
				
				Volt.Nav.endModal();
				Volt.Nav.focus(Volt.Nav.getItem(0));
				
				if (headerView.homePlus.firstPlusContainer ){
					headerView.homePlus.firstPlusContainer.destroyChildren();
					headerView.homePlus.firstPlusContainer.color.a = 0;
					headerView.homePlus.firstPlusContainer.destroy();
					headerView.homePlus.firstPlusContainer = null;
					headerView.homePlus.firstPlusPopup = null;	
					headerView.homePlus.currentPlusPopup = null;
				}                
	
				if (headerView.homePlus.secondPlusContainer ){
					headerView.homePlus.secondPlusContainer.destroyChildren();
					headerView.homePlus.secondPlusContainer.color.a = 0;
					headerView.homePlus.secondPlusContainer.destroy();
					headerView.homePlus.secondPlusContainer = null;
					headerView.homePlus.secondPlusPopup = null;
				}
				headerView.homePlus.currentPlusPopup = null;
				headerView.optionParam.secondSelectedIndex[headerView.optionParam.firstSelectedIndex] = nListIndex;
				
				EventMediator.trigger(EventType.EVENT_TYPE_SELECT_OPTION_PLUS, nListIndex);
			}
		}
	}

exports = CommonPopupView;
