 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  MyContent main view 
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Include libraries
var resMgr = Volt.require('app/controller/resource-controller.js');
var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('modules/backbone.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator; 
var CommonInfo = Volt.require('app/common/define.js');
var KeyCode = CommonInfo.KeyCode;
var PopupType = CommonInfo.PopupType;
var EventType = CommonInfo.EventType;
var EOptType = CommonInfo.EOptType;
var EViewType = CommonInfo.EViewType;
var MsgBoxType = CommonInfo.MsgBoxTemplateType;
var MessageType = CommonInfo.MessageType;
var ProgressPopupType = CommonInfo.ProgressPopupType;
var CategoryBannerType = CommonInfo.CategoryBannerType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var FocusPos = CommonInfo.FocusPos;
var CategoryType = CommonInfo.CategoryType;
var MyContentOptionType = CommonInfo.MyContentOptionType;
var CONST = CommonInfo.CONST;
var CategoryView = Volt.require('app/views/category-view.js');
var HeaderView = Volt.require('app/views/header-view.js');
var ViewGlobalData = Volt.require("app/views/view-global-data.js");
var DeviceType = CommonInfo.DeviceType;
var SortType = CommonInfo.SortType;
var CommMessageBox = Volt.require('app/views/comm-message-box.js');

/* template */
var MainTemplate = PanelCommon.requireTemplate('main');
var MyContentsMainTemplate = Volt.require('app/templates/1080/mycontents-main-template.js');
var DeviceProvider = Volt.require("app/models/device-provider.js");
var dimView = PanelCommon.requireView('dim');
var MM_PLAYER_SHAREINFO = "db/player/shareinfo";


var self = null;
/**
 * Mycontent main view class, it will create 
 * @param {Object} Main view calss proterties
 * @param 
 * @constructor
 * @extends {BaseView}
 */
var MainView = PanelCommon.BaseView.extend({
    template: MainTemplate.container,       // Template of Main View is a container framework
    headerView: null,
    categoryView: null,
    editModeView: null,
    router : null,
    curCategoryType: CategoryType.CATEGORY_VIEW,
    messagePopup: null,
    popupView: null,
    focusPos : FocusPos.FOCUS_NONE,
    folderPathView:null,
    folderPathViewFlag:false,
    defContentWidget: null,
    lastFocusDevInfo: null,
    //msgBoxView: null,
    devPopup: null,
    gridIndex: 0,
    isMainViewDim: false,

    msgbox : null,
    popup : null,
	isOptionPopupShown : false,
    /** Initialize main view  	 
	* @name initialize	 
	* @memberOf MainView
	* @method 	 
	* */	
	initialize: function() {
		//this.router = viewRouter;
		this.focusPos = FocusPos.FOCUS_HEADER;
        EventMediator.on(EventType.EVENT_TYPE_MAIN_VIEW_DIM, this.dim, this);
        EventMediator.on(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM, this.unDim, this);
        EventMediator.on(EventType.EVENT_TYPE_MAIN_VIEW_DIM_OPTION_MENU_1, this.dimFirstPlus, this);
        EventMediator.on(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM_OPTION_MENU_1, this.unDimFirstPlus, this);
        EventMediator.on(EventType.EVENT_TYPE_SELECT_OPTION_MENU_1, this.onSelectFirstLevelMenu, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_APP_VERSION, this.magicVersionPopup, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_DEVICE_INFO, this.magicDevicePopup, this);
        EventMediator.on(EventType.EVENT_TYPE_SELECT_OPTION_PLUS, this.onSelectOptionPlus, this);
        EventMediator.on(EventType.EVENT_TYPE_MESSAGE_BOX, this.handleMessageBox, this);
		EventMediator.on(EventType.EVENT_TYPE_LONG_PRESS_SHOW_MSG_BOX, this.longPressShowMsgBox, this);
		EventMediator.on(EventType.EVENT_TYPE_FOCUS_CHANGE, this.onFocusChange, this);
		EventMediator.on(EventType.EVENT_TYPE_SELECT_MOBILE_PHONE_VIEW, this.onSelectMobileSource, this);
		EventMediator.on(EventType.EVENT_TYPE_CREATE_FOLDER_PATH, this.onCreateFolderPath, this);
		EventMediator.on(EventType.EVENT_TYPE_DESTROY_FOLDER_PATH, this.onDestroyFolderPath, this);
		EventMediator.on(EventType.EVENT_TYPE_ADD_FOLDER_PATH, this.onAddFolderPath, this);
		EventMediator.on(EventType.EVENT_TYPE_DEL_FOLDER_PATH, this.onDeleteFolderPath, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_FOLDER_PATH, this.onShowFolderPath, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_FOLDER_PATH, this.onHideFolderPath, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_ALL_POPUP, this.onHideAllPopup, this);
		EventMediator.on(EventType.EVENT_TYPE_CONTENT_MGR_INIT, this.onContentMgrInit, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_DEL_PROGRESS_POPUP, this.showDelProgressPopup, this);
		EventMediator.on(EventType.EVENT_TYPE_BACK_TO_MOBIE_VIEW, this.onBackMobileView, this);
		EventMediator.on(EventType.EVENT_TYPE_RESUM_FROM_PLAYER, this.resumeFromPlayer, this);
		EventMediator.on(EventType.EVENT_TYPE_EDIT_DEVICE_CHANGE, this.editDeviceChange, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_FILTER_ANIMATION, this.showFilterAnimation, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_UNSUPPORT_FORMAT_MSG_BOX, this.showUnSupportFormatMsgBox, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_DEVIDE_LINE, this.onShowDivideLine, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_DEVIDE_LINE, this.onHideDivideLine, this);

		self = this;
    },
    
    onKeyEvent:function(keycode, keytype){
    	print(" main view  onKeyEvent");
		return false;
  	},
    
    setRouter : function(_router){
    	this.router = _router;
    },
    
    onContentMgrInit:function(){
    	print('contentMgrInit >>>>>>>>>>>>>>>>>  render category view');

		print(" contentMgrInit >>> set timer to renderMainView ");
		Log.e(" contentMgrInit >>> set timer to renderMainView ");

		Volt.setTimeout(self.renderMainView, 20);

	},
	
	renderMainView:function(){
	
		//var systemEventListener = new SystemEventListener();
		//print('add mouse listener....')
		//systemEventListener.onCursorVisible = self.onCursorVisible;
		//systemEventListener.onCursorHidden = self.onCursorHidden;
		//self.widget.addEventListener('OnMouseOver', self.onCursorVisible,this);
		//self.widget.addEventListener('OnMouseOut',  self.onCursorHidden,this);
		//eventManager.addSystemEventListener(systemEventListener);

		
        // Render everything
        print("renderMainView  render header ");
		Log.e("renderMainView  render header ");
		
        self.renderHeader();
		self.renderPopup();				
		print(" renderMainView  render category ");
		Log.e(" renderMainView  render category ");
		self.renderCategory(CategoryBannerType.CATEGORY_BANNER_TYPE_DEVICE_LIST);
		
		EventMediator.on(EventType.EVENT_TYPE_CURSOR_SHOW, self.onCursorVisible, self);
		EventMediator.on(EventType.EVENT_TYPE_CURSOR_HIDE, self.onCursorHidden, self);
	},
    /** render main view  	 
	* @name render	 
	* @memberOf MainView
	* @method 	 
	* */	
    render: function() {
        print('[main-view.js],render begin~~~');
			 // Parse the template
		print("render  Load main view template ");
			 //Must load main template first, otherwise, loading view can not be show correctly.
        self.setWidget(loadTemplate(self.template));

		var launchParams = Volt.require("app/common/launch-params.js");
		if(launchParams.isLaunchForMusicPlayer()){
			Log.f("music playing directly, don\'t need show loading bar");
			return;
		}
			 
        var LoadingView = Volt.require('app/views/loading-view.js');
		print('main view render Show loading....');
		
		if(RunTimeInfo.isLoadingShown == false){
			LoadingView.show();	
			RunTimeInfo.isLoadingShown = true;
			var voiceGuide = Volt.require('app/common/voice-guide.js');
			
			var text = resMgr.getText('COM_TV_SID_LOADING')+resMgr.getText('COM_SID_PLEASE_WAIT_UPPER');
			print("main-view.js load~~~~");
			voiceGuide.queuingPlay(text);
			//voiceGuide.play(text);
		}

		//set timer to wait loading show
	//	Volt.setTimeout(self.renderMainView, 10);	
		
       
    },
	onCursorVisible:function(){
		print('>>>>>>>>>>>>>>>>>>>>>> onCursorVisible');
		
		if(RunTimeInfo.router && 
		(RunTimeInfo.router.currentViewType == EViewType.eConnectPcGuideView 
		|| RunTimeInfo.router.currentViewType == EViewType.eConnectUsbGuideView
		|| RunTimeInfo.router.currentViewType == EViewType.eConnectMobileGuideView
		||RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView)){
			print('Connection guide view or music player view , need not to show return & close button');
			Log.e('Connection guide view or music player view , need not to show return & close button');

			return;
		}			

		EventMediator.trigger(EventType.EVENT_TYPE_SHOW_ROOT_ARROW);			
		EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
	
	},
	
	onCursorHidden:function(){
		print('>>>>>>>>>>>>>>>>>>>>>> onCursorHidden');
		
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ROOT_ARROW);
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_EXIT_ARROW);	
	
	},
	/** when no data,render default view  	 
	* @name renderDefContent	 
	* @memberOf MainView
	* @method 	 
	* */	
	renderDefContent: function(isInMainPage){
		print('[main-view.js]renderDefContent()!');
		if(this.defContentWidget != null){
			this.defContentWidget.hide();
			this.defContentWidget.destroy();
			this.defContentWidget = null;
		}
		if(isInMainPage){
			var mustache = {
				message1: resMgr.getText('TV_SID_NO_CONTENT_FOUND') ,
			};
		}
		else{
			var mustache = {
				//message1: resMgr.getText('TV_SID_NO_CONTENT_FOUND'),
				message1: resMgr.getText('TV_SID_NO_CONTENT_SELECT_DIFFERENT_FILTER'),
			};
		}
		var contentWidget = loadTemplate(MainTemplate.defMainContent,mustache);
		this.defContentWidget = contentWidget;
		//this.widget.addChild(contentWidget);
		contentWidget.parent = this.widget.getChild('main-content-container');
		var textWidget = contentWidget.getChild(0);
		if(textWidget != null){
			if(isInMainPage){
				textWidget.custom.multilingual.SID = 'TV_SID_NO_CONTENT_FOUND';
			}
			else{
				textWidget.custom.multilingual.SID = 'TV_SID_NO_CONTENT_SELECT_DIFFERENT_FILTER';
			}
		}
		/*
		if(RunTimeInfo.isEditMode != true){
			if(self.categoryView != null){
				Volt.Nav.focus(self.categoryView.widget);
			}
			else{
				Volt.Nav.focus(Volt.Nav.getItem(0));
			}
		}
		else{
			if(this.editModeView != null && this.editModeView.deviceBtn != null){
				var btnWidget = this.editModeView.deviceBtn;
				Volt.Nav.focus(btnWidget);
			}
		}*/
    },

    
	/** when no data,hide default view  	 
	* @name hideDefContent	 
	* @memberOf MainView
	* @method 	 
	* */	

	hideDefContent: function(){
		print('[main-view.js]hideDefContent()!');
		if(this.defContentWidget != null){
			this.defContentWidget.hide();
			this.defContentWidget.destroy();
			this.defContentWidget = null;
		}
	},
    

	/** render header view 	 
	* @name renderHeader	 
	* @memberOf MainView
	* @method 	 
	* */	
    renderHeader: function() {
        print('[main-view.js] renderHeaderIcon');
        var container = this.widget.getDescendant('main-header-container');
		if(this.headerView !== null){
			print('destroy head view');
			container.removeChild(this.headerView.widget);
			this.headerView.widget.destroy();
		}
		this.headerView = new HeaderView();
		this.headerView.render();
        //container.addChild(new HeaderView().render().widget);
    },

	/** render category view 	 
	* @name renderCategory	 
	* @memberOf MainView
	* @method 	 
	* */	
    renderCategory: function(type) {
        print('[main-view.js] renderCategory');
		Log.e("[main-view.js] renderCategory");
        var container = this.widget.getDescendant('main-category-container');
		if( container==null ){
			print("this.widget.getDescendant main-category-container is null");
			Log.e("this.widget.getDescendant main-category-container is null");
			return;
		}
		if(type == CategoryBannerType.CATEGORY_BANNER_TYPE_DEVICE_LIST){
        	container.addChild(new CategoryView(this).render().widget);
			this.curCategoryType = CategoryType.CATEGORY_VIEW;
		}
		else if(type == CategoryBannerType.CATEGORY_BANNER_TYPE_EDIT_MODE){
			var EditModeView = Volt.require('app/views/edit-mode-view.js');
			container.addChild(new EditModeView(this).render().widget);
		}
    },

    renderPopup: function () {
        
        if (!this.popupView) {
			var PopupView = Volt.require('app/views/main-popup-view.js');

            this.popupView = new PopupView({
                widget: this.widget.getChild('main-popup-container'),
                mediator: EventMediator
            });
        }
    },
    
    
    /** show main view 	 
	* @name show	 
	* @memberOf MainView
	* @method 	 
	* */	
    show: function(param, aniType) {
    	print('main-view.js show flag:', ViewGlobalData.isCategoryFocus);
		print('main-view.js show currentViewType = ',this.router.currentViewType);
        var deferred =  Q.defer();
        deferred.resolve();
        this.widget.show();
		if ( ViewGlobalData.isCategoryFocus && this.categoryView.categoryList ){
			ViewGlobalData.isCategoryFocus = false;
			Volt.Nav.setRoot(this.widget,{focus:this.categoryView.categoryList});
		}
		else{
			
			if(this.router.currentViewType == EViewType.eConnectionGuideView){
				Volt.Nav.setRoot(this.widget);
			}
			/*
			if(this.router.currentViewType != EViewType.eConnectMobileGuideView &&
				this.router.currentViewType != EViewType.eConnectUsbGuideView){
				//Volt.Nav.setRoot(this.widget);
			}*/
		}
        
        return deferred.promise;
    },

	/** hide main view 	 
	* @name hide	 
	* @memberOf MainView
	* @method 	 
	* */	
    hide: function(aniType) {
        var deferred =  Q.defer();
        deferred.resolve();
        this.widget.hide();
        return deferred.promise;
    },

	/** dim main view 	 
	* @name dim	 
	* @memberOf MainView
	* @method 	 
	* */	
    dim: function(){
    	print('main-view.js dim');
		if ( this.headerView && this.headerView.homePlus && this.headerView.homePlus.firstPlusContainer ){
			print("dim 1");
			dimView.show({
	            parent: this.headerView.homePlus.firstPlusContainer
	        });
		}
		else{
			print("dim 2");
			dimView.show({
	            parent: this.widget.getChild('main-dim-container')
	        });
		}
		
		self.isMainViewDim = true;

	//	EventMediator.trigger(EventType.EVENT_TYPE_DIM_MUSICPLAYER);
		
    },
	
	/** undim main view 	 
	* @name unDim	 
	* @memberOf MainView
	* @method 	 
	* */	
    unDim: function(){
    	print('main-view.js unDim');
		Log.e("main-view.js unDim");
		dimView.hide();
		self.isMainViewDim = false;
		if ( RunTimeInfo.isSetroot == true ){
			RunTimeInfo.isSetroot = false;
			Volt.Nav.setRoot(self.widget);
			print('main-view.js unDim setRoot');
		}
	//	EventMediator.trigger(EventType.EVENT_TYPE_UNDIM_MUSICPLAYER);
    },
    
    getFocusPos : function(){
    	return this.focusPos;
    },

    getCopySupportFlag : function(){
		//var ret = SystemInfo.getBoolValue(CONST.MY_CONTENTS_APP_SUPPORT_COPY);
		var ret = SystemInfo.getBoolValue(SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED);
    	print('main-view.js, getCopySupportFlag:'+ret+', CONST.MY_CONTENTS_APP_SUPPORT_COPY='+CONST.MY_CONTENTS_APP_SUPPORT_COPY);
		print('main-view.js, SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED = ',SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED);
		Log.f("main-view.js, getCopySupportFlag:"+ret+", CONST.MY_CONTENTS_APP_SUPPORT_COPY=" + CONST.MY_CONTENTS_APP_SUPPORT_COPY);
		Log.f("main-view.js, SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED = " + SystemInfo.KEY_USB_COPY_FORMAT_SUPPORTED);
		//ret = 1;
		return ret;
    },

    getRecordSupportFlag : function(){
		var ret = SystemInfo.getIntValue(SystemInfo.KEY_PVR_SUPPORTED);
    	print('main-view.js, getRecordSupportFlag: ret = ',ret);
		//ret = 1;
		return ret;
    },

	getLastFocusDevName: function(){
		print('[main-view.js] getLastFocusDevName()');
		var devDisplayName = '';
		if(self.lastFocusDevInfo != null){
			devDisplayName = self.lastFocusDevInfo.get('displayName');
		}
		print('[main-view.js] last focus devname = ',devDisplayName);
		return devDisplayName;
    },

	//handle message box
    handleMessageBox: function(index){
    	print('---handleMessageBox index = ', index);
	    //var mainView = Volt.require('app/views/main-view.js');
	    //var headerView = mainView.headerView;
	    if(RunTimeInfo.isEditMode == false){
			this.messagePopup.message.hide();
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
			Volt.Nav.endModal();
			Volt.Nav.focus(Volt.Nav.getItem(0));
	    }
		else{
		
		}
    },
	
	dimFirstPlus: function(){
    	print('main-view.js dimFirstPlus');

	},

	unDimFirstPlus: function(){
		print('main-view.js unDimFirstPlus');
		
		if ( this.headerView && this.headerView.homePlus && this.headerView.homePlus.dimWidgetFirst ){
			this.headerView.homePlus.dimWidgetFirst.color.a = 0;
			this.headerView.homePlus.dimWidgetFirst.destroy();
			this.headerView.homePlus.dimWidgetFirst = null;
			
		}		
	},

	longPressShowMsgBox: function(){
		self.showDeleteItemPopup();
    },

	showDeleteItemPopup: function(){
		print('[main-view.js] MainView.showDeleteItemPopup');
		var deferred =  Q.defer();
        	deferred.resolve();
		EventMediator.trigger('EVENT_MAIN_POPUP_HIDE');
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		var CommMessageBox = Volt.require('app/views/comm-message-box.js');
		var popup = new CommMessageBox();
		popup.render(MessageType.eDeleteItem);
		return deferred.promise;
    },

	showDelProgressPopup: function(){
		print('Message box call back!showDelProgressPopup');
		//EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		//var item = {};
		self.showProgressPopup(ProgressPopupType.eOneProgrePopup,null);
		self.router.currentView.setSelectItemToCsf();
		self.router.currentView.DelSelectItem();
		Volt.KPIMapper.addEventLog('MY_OPTION_DELETE_IN_PVR');
		
		//EventMediator.trigger(EventType.EVENT_TYPE_EXIT_EDIT_MODE_VIEW);
    },

	showOptionSelectNotifyMsgBox: function(msgType){
		print('[main-view.js] MainView.showOptionSelectNotifyMsgBox');
		var deferred =  Q.defer();
        	deferred.resolve();
		//EventMediator.trigger('EVENT_MAIN_POPUP_HIDE');
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		var CommMessageBox = Volt.require('app/views/comm-message-box.js');
		var popup = new CommMessageBox();
		//self.msgBoxView = popup;
		popup.render(msgType);
		//popup.setOkCallBack(this.sendMenuCB);
		//popup.setReturnCallBack(this.sendMenuCB);
		return deferred.promise;
    },

	showUnSupportFormatMsgBox: function(){
		print('[main-view.js] MainView.showUnSupportFormatMsgBox');
		var deferred =  Q.defer();
        	deferred.resolve();
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		var CommMessageBox = Volt.require('app/views/comm-message-box.js');
		var popup = new CommMessageBox();
		//self.msgBoxView = popup;
		popup.render(MessageType.eNotSupportFormat);
		return deferred.promise;
    },

	showStorageFullMsgBox: function(availSizeText){
		print('[main-view.js] MainView.showStorageFullMsgBox()');
		var deferred =  Q.defer();
        	deferred.resolve();
			
		var descrText = 'Insufficient storage capacity to copy';//Volt.LANG.TV_SID_MIX_INSUFFICIENT_STORAGE_SPACE_NEED_AVAIL	
		var count = RunTimeInfo.router.onGetSelectItemNum();
		var selItemText = 'Selected items: ' + count.toString();
		var sizeText = 'Available storage: ' + availSizeText;
		var param = {
			 	title: descrText,
				text1: selItemText,
				text2: sizeText,
			};
		var CommMessageBox = Volt.require('app/views/comm-message-box.js');
		var popup = new CommMessageBox();
		popup.render(MessageType.eStorageFull,param);
		return deferred.promise;
    },

	sendMenuCB : function(){
		print('[main-view.js] enter optionMenuCB');
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		EventMediator.trigger(EventType.EVENT_TYPE_RETURN_TO_OPTION);
    },
    
	showDevPopup : function(){
		print('[main-view.js] MainView.showPopup');
		var deferred =  Q.defer();
        deferred.resolve();
		var DevListView = Volt.require('app/views/device-list-popup.js');
		var popup = new DevListView();
		self.devPopup = popup;
		var container = this.widget.getChild('main-popup-container');
		//this.dim();
		popup.setParent(container);
		var selNum = RunTimeInfo.router.onGetSelectItemNum();
		popup.setSelectItemNum(selNum);
		var totalSize = RunTimeInfo.router.currentView.getSelItemTitalSize();
		popup.setTotalSize(totalSize);
		popup.show();
		
        this.listenTo(popup, 'hide', this.hidePopup);			//listen to popup's hide event
        return deferred.promise;
    },

	showProgressPopup : function(progressType,parm){
		print('[main-view.js] MainView.showProgressPopup');
		var deferred =  Q.defer();
        deferred.resolve();
		var ProgressPopup = Volt.require('app/views/progress-popup.js');
		self.popup = new ProgressPopup();
		self.popup.setProgressType(progressType);
		var selNum = RunTimeInfo.router.onGetSelectItemNum();
		self.popup.setSelectItemNum(selNum);
		self.popup.setDeviceInfo(parm);
		self.popup.render();
		
		return deferred.promise;
    },

	hidePopup : function(){
		print('[main-view.js] MainView.hidePopup');
		this.unDim();						
    },
	
    pause: function() {},
    
    getViewContainer : function(){
    	var container = this.widget.getChild('main-content-container');
    	return container;
    	//return container.getChild('view-container');
    },
    getHeaderContainer : function(){
    	var container = this.widget.getChild('main-header-container');
    	return container;  	
    },
    getCategoryContainer : function(){
    	var container = this.widget.getDescendant('main-category-container');
    	return container;
    },

	getPopUpContainer : function(){
		var container = this.widget.getChild('main-popup-container');
		return container;
    },
    //Select first level menu
    onSelectFirstLevelMenu : function(index){
		print('[main-view.js] onSelectFirstLevelMenu, index:'+index+', text:'+this.headerView.optionParam.firstOptionText[index]+', current view: '+ this.router.currentViewType);

		var selText = this.headerView.optionParam.firstOptionText[index];
		//if ( this.router.currentView.collection.length != 0 ){
			if ( selText == resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT) ){
				if ( this.router.currentViewType == EViewType.eAllContentView ){
					this.showOptionSelectNotifyMsgBox(MessageType.eUnableToSortBy);
				}		
			}
			else if ( selText == resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_COPY) ){
				if ( this.router.currentViewType == EViewType.eRecordContentView ){
					this.showOptionSelectNotifyMsgBox(MessageType.eUnAvailable);
					return;
				}	
				var id = self.categoryView.currentID;
				if(DeviceProvider.getUsbDeviceCount() <= 1  || DeviceProvider.isUHDDevice(id)){
					var text1 =  Volt.i18n.t('TV_SID_USB_STORASGE_DRIVE_REQUIRED_FEATURE');//"Unable to select the Copy to USB option with one USB storage.\nPlease connect additional USB storage.";
					this.showOptionSelectNotifyMsgBox(MessageType.eUnableSelectCopy);
					return;
				}
				this.router.currentView.enterEditMode(EOptType.eSendType);
				//this.editModeView.widget.getChild('operation_id').text = selText;
				var optText = resMgr.getText('COM_SID_SEND');
				this.editModeView.optionBtn.setText({state: "all", text: optText});
				this.editModeView.optType = EOptType.eSendType;
				//if (this.router.currentViewType == EViewType.eAllContentView){
					//this.router.currentView.dimPvrItem();
				//}
				if(RunTimeInfo.isEditMode == true){
					this.router.currentView.resetSelectStatus();
					Volt.Nav.reload();
				}
			
			}
			else if ( selText == resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY)){
				
				print('[main-view.js] onSelectFirstLevelMenu enterEditMode, index: '+index);
				if(this.router.currentViewType == EViewType.eAllContentView){
					this.showOptionSelectNotifyMsgBox(MessageType.eUnableSelectPlay);
					return;
				}
				this.router.currentView.enterEditMode(EOptType.ePlaySelType);
				//this.editModeView.widget.getChild('operation_id').text = selText;
				this.editModeView.optionBtn.setText({state: "all", text: selText});
				this.editModeView.optType = EOptType.ePlaySelType;
				if(RunTimeInfo.isEditMode == true){
					this.router.currentView.resetSelectStatus();
					Volt.Nav.reload();
				}
			
				print('MYCONTENT_OPTION_TYPE_PLAY currentViewType: '+this.router.currentViewType);
				print('MYCONTENT_OPTION_TYPE_PLAY  sortType'+ViewGlobalData.viewSortText[this.router.currentViewType]);

				var devItem = DeviceProvider.getCurrentDevice();
				if(!devItem){
					return ;
				}
				var devType = devItem.get('type');
				var CurrentFilter = this.router.currentView.getKPIFilter(this.router.currentViewType);
				if(devType == DeviceType.DEVICE_TYPE_USB){
					Volt.KPIMapper.addEventLog('MY_OPTION_SELECT_PLAY', {
			             d: {
			                cf: CurrentFilter,
			            }
			        });
			    }
			    else if(devType == DeviceType.DEVICE_TYPE_DLNA){
			    	Volt.KPIMapper.addEventLog('MY_OPTION_SELECT_PLAY_IN_DCM', {
			             d: {
			                cf: CurrentFilter,
			            }
			        });
			    }
			}
			else if ( selText == resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_DEL) ){
				if(this.router.currentViewType != EViewType.eRecordContentView){
					this.showOptionSelectNotifyMsgBox(MessageType.eUnableSelectDel);
					return;
				}
				else{
					if(this.router.currentView.isDimRecord == true){
						this.showOptionSelectNotifyMsgBox(MessageType.eNoRecordContent);
						return;
					}
				}
				this.router.currentView.enterEditMode(EOptType.eDeleteType);
				//this.editModeView.widget.getChild('operation_id').text = selText;
				this.editModeView.optionBtn.setText({state: "all", text: selText});
				this.editModeView.optType = EOptType.eDeleteType;
				if(RunTimeInfo.isEditMode == true){
					this.router.currentView.resetSelectStatus();
					Volt.Nav.reload();
				}
				
			}
		//}
	},

    magicVersionPopup : function(){
    	EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ALL_POPUP);
		this.showOptionSelectNotifyMsgBox(MessageType.eAppVersion);
	},

    magicDevicePopup : function(){
    	EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ALL_POPUP);
		this.showOptionSelectNotifyMsgBox(MessageType.eDeviceInfo);
	},
	
	onSelectOptionPlus : function(index){	
		
		var firstIndex = this.headerView.optionParam.firstSelectedIndex;
		print('[content-view-base.js]onSelectOptionPlus index =',index);
		print('mainView.headerView.optionParam.secondOptionText[index]'+this.headerView.optionParam.secondOptionText[index]);

		switch(firstIndex){
			/*switch the view*/
			case 0:
				/*abtain the switch rule*/
				var viewTo = this.router.currentView.getSwitchToView(this.headerView.optionParam.secondOptionText[index]);
				if(ViewGlobalData.viewSortText[this.router.currentViewType] == resMgr.getText(SortType.SORT_TYPE_FOLDER) ){
					ViewGlobalData.resetViewSortText();
				}
				else{
					ViewGlobalData.reset();
					//Destroy folder path 	
					this.onDestroyFolderPath();
				}
			//	RunTimeInfo.isFilterChange =true;				
		
				if(RunTimeInfo.isEditMode == true){
					this.router.currentView.exitEditMode();
				}
				ViewGlobalData.viewTypeIndex = index;

				print("main-view.js onSelectOptionPlus switchView to:"+viewTo);
				Log.e("main-view.js onSelectOptionPlus switchView to:"+viewTo);

				this.router.switchView(viewTo, EViewSwitchAniType.eNoneAni);
				var CurrentFilter = this.router.currentView.getKPIFilter(this.router.currentViewType);
				var SelectFilter = this.router.currentView.getKPIFilter(viewTo);
				if(this.router.currentView.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB){
					Volt.KPIMapper.addEventLog('MY_OPTION_FILTER', {
					             d: {
					                cf: CurrentFilter,
									sf: SelectFilter,
					            }
					        });
				} else if (this.router.currentView.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA){
					Volt.KPIMapper.addEventLog('MY_OPTION_FILTER_DCM', {
					             d: {
					                cf: CurrentFilter,
									sf: SelectFilter,
					            }
					        });
				}
				
					
				break;
				
            /*sort the view*/
			case 1:
				this.router.currentView.destoryList();
				var sortType = this.headerView.optionParam.secondOptionText[index];
				print('[content-view-base.js]onSelectOptionPlus sortType = ',sortType);
				if(RunTimeInfo.isEditMode == true){
					this.router.currentView.resetSelectStatus();
					Volt.Nav.reload();
				}
				
				
				if(sortType != SortType.SORT_TYPE_FOLDER){
					/*ViewGlobalData.gridlistIndex.length  = 0;
					ViewGlobalData.parentFielPathStack.length = 0;
					ViewGlobalData.isRootGroup = true;
					ViewGlobalData.GroupIndex = -1;*/
					//if sortType != 'Folder' , need destroy folder path
					EventMediator.trigger(EventType.EVENT_TYPE_DESTROY_FOLDER_PATH);
					EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ROOT_ARROW);
					ViewGlobalData.reset();
				}
				ViewGlobalData.viewSortText[this.router.currentViewType] = sortType;
				this.router.currentView.makeDataSource(this.categoryView.currentMountPath);

				var SelectSort = this.router.currentView.getKPISort(sortType);
				var DeviceProvider = Volt.require("app/models/device-provider.js");
				var devItem = DeviceProvider.getCurrentDevice();
				if(!devItem){
					break;
				}
				var devType = devItem.get('type');
				
				if(devType ==  DeviceType.DEVICE_TYPE_USB){
					if(this.router.currentViewType == EViewType.ePhotoContentView){
						Volt.KPIMapper.addEventLog('MY_OPTION_SORT_IN_PV', {
					             d: {
					                ss: SelectSort,
					                ct: 'SID_PHOTO',
					            }
					        });	
					}
					else if(this.router.currentViewType == EViewType.eVideoContentView){
						Volt.KPIMapper.addEventLog('MY_OPTION_SORT_IN_PV', {
					             d: {
					                ss: SelectSort,
					                ct: 'SID_VIDEO',
					            }
					        });	
					}
					else if(this.router.currentViewType == EViewType.eMusicContentView ){
						Volt.KPIMapper.addEventLog('MY_OPTION_SORT_IN_MUSIC', {
				             d: {
				                ss: SelectSort,				           
				            }
				        });	
					}
					else if(this.router.currentViewType == EViewType.eRecordContentView ){
						Volt.KPIMapper.addEventLog('MY_OPTION_SORT_IN_PVR', {
				             d: {
				                ss: SelectSort,
				            }
				        });	
					}
				}
				/*
				else if(devType == DeviceType.DEVICE_TYPE_DLNA){
					if(this.router.currentViewType == EViewType.ePhotoContentView){
						Volt.KPIMapper.addEventLog('MY_OPTION_SORT_IN_PV_DCM', {
					             d: {
					                ss: SelectSort,
					                ct: 'SID_PHOTO',
					            }
					        });	
					        
					}
					else if(this.router.currentViewType == EViewType.eVideoContentView){
						Volt.KPIMapper.addEventLog('MY_OPTION_SORT_IN_PV_DCM', {
					             d: {
					                ss: SelectSort,
					                ct: 'SID_VIDEO',
					            }
					        });	
					        
					}
					else if(this.router.currentViewType == EViewType.eMusicContentView ){
						Volt.KPIMapper.addEventLog('MY_OPTION_SORT_IN_MUSIC_DCM', {
				             d: {
				                ss: SelectSort,				           
				            }
				        });	
					}

				}
				*/				
				break;
			default:
				break;
			}	
	},
	
	onFocusChange : function(pos){
		this.focusPos = pos;
	},
	
	onSelectMobileSource : function(index){
		var viewTo = EViewType.ePhotoContentView;
		switch(index){
			case 0: 
				viewTo = EViewType.ePhotoContentView;
				break;
			case 1: 
				viewTo = EViewType.eMusicContentView;
				break;
			case 2:
				viewTo = EViewType.eVideoContentView;
				break;
			default:
				break;
		}
		print("mobile phone view select view :", viewTo);
				
		Log.e("main-view.js onSelectMobileSource switchView to:"+viewTo);
		this.router.switchView(viewTo, EViewSwitchAniType.eNoneAni);
	},


	onBackMobileView: function(){
		print("main-view.js onBackMobileView switchView to:"+EViewType.eMobilePhoneView);
		Log.e("main-view.js onBackMobileView switchView to:"+EViewType.eMobilePhoneView);
		this.router.switchView(EViewType.eMobilePhoneView, EViewSwitchAniType.eNoneAni);
	},

	/** hide all popup
	* @name onHideAllPopUP	 
	* @memberOf MainView	
	* @param {folder}  folder name
	* @method 	 
	* */
	onHideAllPopup: function(){
		print('main-view.js onHideAllPopUP()');
		EventMediator.trigger('EVENT_MAIN_POPUP_HIDE', 'OPTION_MENU');
		//if(RunTimeInfo.isSendPopupShow == true){
			//EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SENDING_POPUP);
		//}
		//if(self.devPopup != null){
			//self.devPopup.undimHide();
		//}
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_MSG_BOX);
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_INFOWND);
		if(RunTimeInfo.isEditMode == true && self.devPopup == null){
			print('main-view.js onHideAllPopup, set focus to null!');
			EventMediator.trigger(EventType.EVENT_TYPE_HIDE_DEVSELECTOR_POPUP);
			Volt.Nav.focus(null);
		}
	},
	
	hideSendPopup : function(){
		//EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SENDING_POPUP);
		self.popup.hide();
		self.popup.cancelProcess();
		self.popup.destroy();
	},
	
	setRoot : function(){
    	if(self.msgbox){
			self.msgbox.setRoot();
			self.msgbox.setFocus();
		}else{
			Volt.Nav.setRoot(self.widget);
			Volt.Nav.focus(Volt.Nav.getItem(0));
		}
    },
	
	/** Create folder path view
	* @name onCreateFolderPath	 
	* @memberOf MainView	
	* @param {folder}  folder name
	* @method 	 
	* */
	onCreateFolderPath:function(folder){
    	print('**********************Create folder path...', folder);
		var FolderPathView = Volt.require("app/views/folder-path-view.js");

    	self.folderPathView = new FolderPathView(this);
    	var container = this.widget.getDescendant('main-category-container');	
		if( container==null ){
			print("this.widget.getDescendant main-category-container is null");
			return;
		}
       	container.addChild(self.folderPathView.render().widget);
       	
		var index = this.categoryView.categoryList.currentTabIndex();
		
		print('---------------------Selete device index:',index);
		var deviceName = this.categoryView.getDeviceNameByCategoryIndex(index);		
		self.folderPathView.addSubFolder(deviceName);
		
   	  	var title = this.headerView.widget.getChild('main-header-text');
    	title.text = folder;
		title.custom.multilingual.DISABLE = 'true';
		
		if(RunTimeInfo.isEditMode == true){
			print('onAddFolderPath editmode is true!');
		}
		else{
			self.onHideDivideLine();
		//	EventMediator.trigger(EventType.EVENT_TYPE_HIDE_DEVIDE_LINE);
		}

		self.folderPathView.addSubFolder(folder);
		
		if(this.categoryView != null)
		{
			this.categoryView.widget.hide();

		}
		
    },
    
    /** Destroy folder path view
	* @name onDestroyFolderPath	 
	* @memberOf MainView	
	* @method 	 
	* */
    onDestroyFolderPath:function(){
    	print('*********************Destroy folder path...');
		
		self.folderPathViewFlag = false;
		if(self.folderPathView != null){
    		self.folderPathView.hide();
    		self.folderPathView.clearAllPath();
		}
		print('onDestroyFolderPath >>>> this.router.currentView.isEditMode :', RunTimeInfo.isEditMode);
    	if(this.categoryView != null && this.router.currentView != null 
			&& (RunTimeInfo.isEditMode == false || RunTimeInfo.isEditMode == undefined))
		{
			print('onDestroyFolderPath >>>>  show category ');
		    this.categoryView.widget.show();
		    this.categoryView.widget.custom.focusable = true;
		}
		
		this.curCategoryType = CategoryType.CATEGORY_VIEW;
    	var title = this.headerView.widget.getChild('main-header-text');
		title.custom.multilingual.DISABLE = 'false';
		
    	title.text = resMgr.getText('TV_SID_MY_CONTENT_NAME');		
		
		self.onShowDivideLine();
		//EventMediator.trigger(EventType.EVENT_TYPE_SHOW_DEVIDE_LINE);	

    },
    /** Create folder path view
	* @name onAddFolderPath	 
	* @memberOf MainView	
	* @param {folder}  folder name
	* @method 	 
	* */
    onAddFolderPath:function(folder){
    	print('[onAddFolderPath] ********************* folder path...',folder);
  		
		self.folderPathViewFlag = true;
    	if(self.folderPathView == null){
    		self.onCreateFolderPath(folder);
    	} else {

			if(self.folderPathView.isDeleteAllPath() == true ) {
				var index = this.categoryView.categoryList.currentTabIndex();				
				print('---------------------Selete device index:',index);
				var deviceName = this.categoryView.getDeviceNameByCategoryIndex(index);				
	    		self.folderPathView.addSubFolder(deviceName);    
    		}
			
	   	  	var title = this.headerView.widget.getChild('main-header-text');
	    	title.text = folder;
			title.custom.multilingual.DISABLE = 'true';	
			
			self.folderPathView.addSubFolder(folder);
			
			if(RunTimeInfo.isEditMode == true){
				print('onAddFolderPath editmode is true!');
			}
			else{
				self.onHideDivideLine();
				//EventMediator.trigger(EventType.EVENT_TYPE_HIDE_DEVIDE_LINE);
				self.folderPathView.show();
			}
    		
    	}
    	
    },
    /** Delete folder path
	* @name onDeleteFolderPath	 
	* @memberOf MainView
	* @method 	 
	* */
    onDeleteFolderPath:function(){
    	print('[onDeleteFolderPath]********************Delete folder path...');
    	self.folderPathView.deleteSubFolder();
    	var folder = self.folderPathView.getTopFolder();
    	print('[onDeleteFolderPath]********************Delete folder path..:',folder);
    	var title = this.headerView.widget.getChild('main-header-text');
    	title.text = folder;		
    },
    /** Create folder path view
	* @name onShowFolderPath	 
	* @memberOf MainView	
	* @param {folder}  folder name
	* @method 	 
	* */
    onShowFolderPath:function(){
    	print('************************Show folder path...');
    	self.folderPathView.show();
    },
    /** Hide folder path view
	* @name onHideFolderPath	 
	* @memberOf MainView	
	* @param {folder}  folder name
	* @method 	 
	* */
    onHideFolderPath:function(){
    	print('***********************Hide folder path...');
    	self.folderPathView.hide();    	
    },
    resumeFromPlayer:function(){
    	Log.e('return from player');
    	print('return from player');
		var returnValue = Vconf.getValue(MM_PLAYER_SHAREINFO);
		if(returnValue == undefined){
			Log.e('return value: = undefined');
			var curView = this.router.getCurrentView();
			if(curView != undefined && curView != null){
				this.router.showView(curView, EViewSwitchAniType.eNoneAni);
			}
			return;
		}
		var JsonData = null;			
		Log.e('return value: ' + returnValue);
		print('return value: ' + returnValue);
		try{
			JsonData = JSON.parse(returnValue);		
		} catch (e) {
			print('**************-------------Vconf exception------------*********');
			return;
		}
		if(JsonData !== undefined && JsonData !== null){
			print('return from player--JsonData:'+JsonData);

			var mediaId = JsonData.media_id;
			var disconnect = JsonData.device_disconnect;
			var mediaid = JsonData.media_id;					
			var appName = JsonData.app_name;
			var unsupport = JsonData.unsupport_value;
			if(appName == 'video-player'){
				Volt.KPIMapper.addExitLog('MY_VIDEO_PG_EXIT');
			}
			else if(appName == 'photo-player'){
				Volt.KPIMapper.addExitLog('MY_PHOTO_PG_EXIT');
			}
			print("resumeFromPlayer RunTimeInfo.disconnectCurrentDevice:"+RunTimeInfo.disconnectCurrentDevice);
			Log.e("resumeFromPlayer RunTimeInfo.disconnectCurrentDevice:"+RunTimeInfo.disconnectCurrentDevice);
			if(RunTimeInfo.disconnectCurrentDevice == false){
			
				print('device is still plugin in ');
				Log.e("device is still plugin in ");
				var curView = this.router.getCurrentView();
				if(curView != undefined && curView != null && curView.resetFocusFromPlayer != undefined){
					curView.resetFocusFromPlayer(mediaid);
				}
				if((unsupport != undefined && unsupport == true) || appName == 'pvr-player'){
					EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
					print("main-view.js resumeFromPlayer switchView to:"+this.router.currentViewType);
					Log.e("main-view.js resumeFromPlayer switchView to:"+this.router.currentViewType);
					this.router.switchView(this.router.currentViewType, EViewSwitchAniType.eNoneAni);
				}
				else{
					if(curView != undefined && curView != null && curView.showLastPlayIndex != undefined){
						this.router.showView(curView, EViewSwitchAniType.eNoneAni);
						curView.showLastPlayIndex();
					}
				}
			}else{
				//this var is once used. must set false here
				RunTimeInfo.disconnectCurrentDevice = false;
			}
			
		}
		else{
			print('device is disconnect ');
			Log.e("device is disconnect ");
			var curView = this.router.getCurrentView();
			if(curView != undefined && curView != null){
				this.router.showView(curView, EViewSwitchAniType.eNoneAni);
			}
		}
    },
    editDeviceChange: function(devId){
    	print('enter Edit Device Change');
    	var pos=0;
    	for( ; pos < self.categoryView.categoriesID.length; pos++){
			if(devId == self.categoryView.categoriesID[pos]){
				break;
			}
    	}
		if(pos < 0 || pos >= self.categoryView.categoryList.numberOfTab()){
			print("main-view.js editDeviceChange pos is out of range!");
			Log.f("main-view.js editDeviceChange pos : " + pos);
			self.editModeView.hideDeviceSelector();
			Volt.Nav.setRoot(self.widget);
		}
		else{
			self.categoryView.categoryList.changeTab(pos);	
			self.editModeView.hideDeviceSelector();
			Volt.Nav.setRoot(self.widget);
		}
		//ViewGlobalData.rootPath = 
		//self.router.swithView()
    },
    
    showFilterAnimation : function(){
    	if(self.router.currentViewType == EViewType.eAllContentView ||
		self.router.currentViewType == EViewType.eVideoContentView ||
		self.router.currentViewType == EViewType.ePhotoContentView ||
		self.router.currentViewType == EViewType.eMusicContentView ||
		self.router.currentViewType == EViewType.eRecordContentView)
		{
			Volt.log('[main-view.js]----showFilterAnimation---111');
			if (self.headerView != null)
			{
				Volt.log('[main-view.js]----showFilterAnimation---self.headerView not null');
				if (typeof self.headerView.animateViewSwitch == 'function')
				{
					Volt.log('[main-view.js]----showFilterAnimation---self.headerView.animateViewSwitch is function');
					self.headerView.animateViewSwitch();
				}			
			}
    	}
	},

	onHideDivideLine:function(){
		//main template 'main-category-underbar-container'
		var headerLine = self.widget.getChild('main-category-underbar-container');
		if(headerLine){
			headerLine.opacity = 0;
		}		
	},
	
	onShowDivideLine:function(){
		//main template 'main-category-underbar-container'
		var headerLine = self.widget.getChild('main-category-underbar-container');
		if(headerLine){
			headerLine.opacity = 25;
		}		
	},
});

var mainView = new MainView();

exports = mainView;

