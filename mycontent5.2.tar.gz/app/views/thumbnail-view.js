 /** 
 * @author  zhao rui (rui9527.zhao@samsung.com)		
 * 			
 * @fileoverview  All content view 
 * @date    2014/10/22 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var resMgr = Volt.require('app/controller/resource-controller.js');
	var BaseModel = Volt.require("app/models/base-model.js");
	var CommonInfo = Volt.require("app/common/define.js");
	var EItemType = CommonInfo.EItemType;
	var AllContentViewTemplate = Volt.require('app/templates/1080/all-view-template.js');
	var RunTimeInfo = Volt.require("app/common/run-time-info.js");
	var PanelCommon = Volt.require('lib/panel-common.js');
	var loadTemplate = PanelCommon.loadTemplate;
	var ViewGlobalData = Volt.require("app/views/view-global-data.js");
	var EventMediator = RunTimeInfo.EventMediator;
	var EventType = CommonInfo.EventType;
	var nativeGridlistFocus = CommonInfo.nativeGridlistFocus;
	var CONST = CommonInfo.CONST;
	var TTSEventType = CommonInfo.TTSEventType;
	var self = null;
	var UHDTumbnail = CommonInfo.UHDTumbnail;
	var EOptType = CommonInfo.EOptType;
	var mainView = Volt.require('app/views/main-view.js');
	var CIThumbType = CommonInfo.CIThumbType;

	var actorMap = {
	    '1': 'icon1',
	    '2': 'icon2',
	    '3': 'icon3',
	    '4': 'icon4',
	    '5': 'icon5',
	    '6': 'icon6',
	    '7': 'icon7',
	    '8': 'icon8',
	    '9': 'icon9',
	    '10': 'icon10',	    
	};
	
/**
 * Thumbnail_View 
 * @param {int} parentWidth
 * @param {int} parentHeight
 * @param {Object} viewPointer  
 * @constructor
 * @extends {null}
 */
Thumbnail_View = function(parentWidth, parentHeight, viewPointer ) {
	self = viewPointer;
    var renderer = new Renderer(parentWidth, parentHeight);

	/** createRoot
	* @name createRoot	 
	* @memberOf Thumbnail_View
	* @param {Object} renderer
	* @param {int} parentWidth
	* @param {int} parentHeight 
	* @param {boolean} dummyFlag 
	* @method 	 
	* */	
	renderer.createRoot = function( renderer, parentWidth, parentHeight, dummyFlag ){
		renderer.unique = null;
	};
	
	/** createChild
	* @name createChild	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data
	* @method 	 
	* */	
	renderer.createChild = function( renderer, data ){
		if(data.dataFlag == false){
			createFakeThumbnail(renderer, data);
			return;
		}
		if( data.ItemType == EItemType.eItemFolder ){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
		          	x: 0,
		        	y: 0,
		            width: self.params.renderWidth,
			        height: self.params.renderHeight,
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
	                    x: self.params.textX,
			            y: self.params.textY,
		                width: self.params.textWidth,
		                height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
             			textColor: { r: 255, g: 255, b: 255, a: 153 },
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: self.folderNoamalImage,
					pressedSrc: self.folderNoamalImage,
					clickable: false,
					opacity: 128,
				}
			});

			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_m_upper.png",
			    width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
		           x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,
		           
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
		                 x: self.params.textX,
			            y: self.params.textY,
			            width: self.params.textWidth,
			            height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
					clickable: false,
					opacity:255*0.5
				}
			});


			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
			
	    }
		else if ( data.ItemType < EItemType.eItemFolder){
			if ( !data.title1 ){
				data.title1 = '';
			}
			if ( !data.title2 ){
				data.title2 = '';
			}
			
			var uhdFlagText = '';
			var uhdicon = '';
			var contenticon = '';
			var ratinginfoLine = '';
			var ratinginfoLineX = 0;
			var ratinginfoIcon = '';
			var ratingLeve = '';
			var ratingInfoX = 0;
			var ratingInfoW = 0;
			
			if( data.ItemType == EItemType.eItemVideo || data.ItemType == EItemType.eItemUHDVideo || data.ItemType == EItemType.eItemSCSA){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
				contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_play.png';
				if(data.ItemType == EItemType.eItemUHDVideo){
					uhdicon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_uhd.png';
				}
			}
			else if( data.ItemType == EItemType.eItemPhoto){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_photo_n.png';
				contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_camera.png';	
			}
			else if( data.ItemType == EItemType.eItemMusic){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_music_n.png';
				if( self.collection.getHDAudioType(data.index)==true){
					contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_music_hd.png';	
				}
				else{
					contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_music.png';	
				}
			}
			else if(data.ItemType == EItemType.eItemPvr){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
				if(data.isLocked){
					data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_adult_n.png';
				}
				if(data.isAudioOnly){
					data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_audio_n.PNG';
				}
				contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_play.png'
			}
			
					
			var infomationTextX = self.params.text1X;
			var infomationTextW = self.params.text1Width;
			var watchedIconSrc = '';
			var sportsIcoSrc = '';
			var fillModeType = '';
			var recordingIconSrc = '';
			var UHDVideoFlag = false;
			if(data.ItemType == EItemType.eItemPvr){
				if(data.sportsType == 2){
					sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_soccer.png";
				}
				else if(data.sportsType == 3){				
					sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_rugby.png";
				}
				else if(data.sportsType == 4){
					sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_hockey.png";
				}
				/*
				if(data.isWatched){
					watchedIconSrc  = Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_recorded_watched.PNG"
					infomationTextX += 20;
					infomationTextW -= 20;
				}*/
				if(data.isGuidance){
					infomationTextW -= 26;
				}
				
				 
               
                if(data.isLocked || data.isAudioOnly){
                   self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );                   
                }
                else if(self.collection.getItem(data.index).get('ciThumbType') > CIThumbType.E_THUMB_OK || self.collection.getItem(data.index).get('isDrm') == true){
                    data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
                    self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );
                }
                else if( self.collection.getItem(data.index).get('isThumbDone')){
                    data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
                } 
                else{
                    self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
                }
           
			}
    		else if(data.ItemType == EItemType.eItemUHDVideo){
				UHDVideoFlag = true;
				
				var uhdContentId = self.collection.getItem(data.index).get('uhdContentId');
				var uhdThumb = getUhdThumb(uhdContentId); 
				var uhdGenre = self.collection.getItem(data.index).get('uhdVideoGenre');
			
				ratingLeve = self.collection.getItem(data.index).get('rateLevel');
					
				if(RunTimeInfo.UHDContentFolder == true){
					infomationTextX = 18;
					infomationTextW = 190;
					ratingInfoW = 90;
					print('ratinginfoW :',ratingInfoW);							
					
					ratingInfoX = infomationTextX;

					if(uhdGenre == undefined || uhdGenre == null){
						uhdGenre = '';
					} 
					if(ratingLeve == undefined || ratingLeve == null){
						ratingLeve = '';
					}
				
				}else{
				
					ratingInfoW = (self.params.renderWidth - 10)/2;
					print('ratinginfoW :',ratingInfoW);
					infomationTextW = infomationTextW - ratingInfoW;
					infomationTextX += 0;
					ratingInfoX = infomationTextX + infomationTextW;
					if(ratingLeve == undefined || ratingLeve == null){
						ratingLeve = '';
					}else{
						ratingLeve = '|' + ratingLeve;
					}
				}
				
				if(uhdThumb != null){
					//if network is connect , display uhd thumbnail
				   	data.ThumbPath = uhdThumb;
					print('Thumbnail-view.js createChild >>>>>>>>>>>>>  UHD Video ThumbPath:',data.ThumbPath);
					fillModeType = 'fit';
				}else{
						// else, display default thumb
					data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
					
				}				
				
			}else{
		        if( data.isThumbDone ){
		        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
					Log.e("thumbnail view ThumbDone  data.ThumbPath:",data.ThumbPath);
			    }
				else if(!self.collection.getItem(data.index).get('isPlayAvailable') || self.collection.getItem(data.index).get('isDrm')){
					self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath);		    	
				}		         
		        else{
		       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
		       	}
			}
			
			if(data.ItemType == EItemType.eItemPvr){
				if(data.isRecording){					
					recordingIconSrc = Volt.BASE_PATH + resMgr.getImgPath()+ "/Contents_icon/recorded_rec_icon.png";
				}
				if(self.collection.getItem(data.index).get('ciThumbType') === CIThumbType.E_THUMB_INVALID){
					data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
					contenticon = '';
				}
				if(self.collection.getItem(data.index).get('isDrm') == true){
					data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
					contenticon = '';
				}
			}
			else{
				if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
					if(data.ItemType == EItemType.eItemPhoto){
						data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_camera.png';
						contenticon = '';
					}
					else if(data.ItemType == EItemType.eItemMusic){
						data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_music.png';
						contenticon = '';
					}
					else{
						data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
						contenticon = '';
					}
				}
			}
			
			if (self.thumbnailColorFlag == false){
				self.thumbnailColorNumber = data.index%2;
				self.thumbnailColorFlag = true;
			}
			var tempIndex = data.index%2;
			var tempColorPickingOpacity = 255-240;
			if ( tempIndex == self.thumbnailColorNumber ){
				tempColorPickingOpacity = 255-225;
			}
			print("title infomationTextX:"+infomationTextX);
			print("title infomationTextW:"+infomationTextW);
			
			print("title ratingInfoX:"+ratingInfoX);
			print("title ratingInfoW:"+ratingInfoW);
			
			print('create thumbnail begin 2-27');
			var input = {
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
		        image: {
		            src: data.ThumbPath,
		            width: self.params.imageWidth,
		            height: self.params.imageHeight,
		            fillMode: fillModeType, //default fillmode is stretch 
		        },
		        information: {
					x: 0, 
					y: self.params.imageHeight, 
					width: self.params.renderWidth, 
					height: self.params.infoHeight,
					//colorPickingOpacity: tempColorPickingOpacity,
					
					colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
					setAsBackground: UHDVideoFlag,
					highContrast: {
						color: { r: 13, g: 13, b: 13, a: 255 },
			            textColor: { r: 255, g: 255, b: 255, a: 255 },
			            highlightTextColor: {r:0xfb, g:0xba, b:0x2d, a:255}

			        },
						enlarge:{
                             factor: 1.5,
                             anchorPoint: "bottom",
             		},
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
						x: infomationTextX, 
						y: self.params.text1Y, 
						width: infomationTextW, 
						height: self.params.text1Height,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                extractColorOpacity: 153,
		            },
		        },
				icon1: {
					x: self.params.connectX, 
					y: self.params.connectY, 
					width: self.params.connectWidth, 
					height: self.params.connectHeight,
					async: true,
					unpressSrc: contenticon,
					pressedSrc: contenticon,
					clickable: false,
				},
			};
			
			renderer.iconNumber = 1;
			renderer.editNum = 0;
			
			if(data.ItemType == EItemType.eItemUHDVideo){
				if(RunTimeInfo.UHDContentFolder == true){
					setInfoTextInfo(input,2,{
			            	text: uhdGenre,
			                font: 'SVD Light 20px',
	                		x: ratingInfoX,
							y: self.params.text1Y+self.params.text1Height+4,				
							width: ratingInfoW, 
							height: self.params.text1Height,		                
							horizontalAlignment: 'left',
			                verticalAlignment: 'center',
			                singleLineMode: true,
			                opacity : 128,
			            });
						setInfoTextInfo(input,3,{
			            	text: ratingLeve,
			                font: 'SVD Light 20px',
	                		x: ratingInfoX+ratingInfoW + 10,
							y: self.params.text1Y+self.params.text1Height+4,				
							width: ratingInfoW, 
							height: self.params.text1Height,		                
							horizontalAlignment: 'right',
			                verticalAlignment: 'center',
			                singleLineMode: true,
			                opacity : 128,
			            });
					} else { 
						setInfoTextInfo(input,2,{
			            	text: ratingLeve,
			                font: 'SVD Light 20px',
	                		x: ratingInfoX+16,
							y: self.params.text1Y+2,				
							width: ratingInfoW-16, 
							height: self.params.text1Height,		                
							horizontalAlignment: 'right',
			                verticalAlignment: 'center',
			                singleLineMode: true,
			                opacity : 128,
			            });				
					}
			}
			print(" ratingLeve  ratingInfoX +16 ...1");
			if ( data.ItemType == EItemType.eItemPvr && data.isGuidance ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
						x: 176,
						y: 241,
						width: 26,
						height: 25,
						async: true,
						unpressSrc: '',
						pressedSrc: '',
						clickable:false,
				});
			}
			
			var showCheck =  false;
			if ( RunTimeInfo.isEditMode ){
				var dataIndex = data.index;
				if(self.collection.addUpperFolderItemFlag == true){
					dataIndex = dataIndex -1;
				}
				if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
					showCheck = true;
				}
			}
			if ( showCheck == true ){
				renderer.iconNumber++;
				renderer.editNum = renderer.iconNumber;
				setIconInfo(input, renderer.iconNumber, {
					x: self.params.icon1X, 
					y: self.params.icon1Y, 
					width: self.params.icon1Width, 
					height: self.params.icon1Height,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					opacity: 255*0.5,
					clickable: false
				});
			}
			
			if ( uhdicon != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: self.params.uhdX, 
					y: self.params.uhdY, 
					width: self.params.uhdWidth, 
					height: self.params.uhdHeight,
					async: true,
					unpressSrc: uhdicon,
					pressedSrc: uhdicon,
					clickable: false
				});
			}
			
			if ( sportsIcoSrc != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: self.params.connectX - 35, 
					y: self.params.connectY, 
					width: self.params.connectWidth, 
					height: self.params.connectHeight,
					async: true,
					unpressSrc: sportsIcoSrc,
					pressedSrc: sportsIcoSrc,
					clickable: false
				});
			}
			if ( data.unsupportIcon != '' ){
				renderer.iconNumber++;
				renderer.unSupportNum = renderer.iconNumber;
				setIconInfo(input, renderer.iconNumber, {
					x: self.params.icon2X, 
					y: self.params.icon2Y, 
					width: self.params.icon2Width, 
					height: self.params.icon2Height,
					async: true,
					unpressSrc: data.unsupportIcon,
					pressedSrc: data.unsupportIcon,
					clickable: false
				});
			}
			if ( watchedIconSrc != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: 18,
					y: 249,
					width: 17,
					height: 17,
					async: true,
					unpressSrc: watchedIconSrc,
					pressedSrc: watchedIconSrc,
					clickable:false,
				});
			}
			if ( recordingIconSrc != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: 66, 
					y: 66, 
					width: 88, 
					height: 88,
					async: true,
					unpressSrc: recordingIconSrc,
					pressedSrc: recordingIconSrc,
					clickable: false,
				});
			}
			
			renderer.thumbnail = new Thumbnail(input);
			print('create thumbnail successfully 2-27');
			var editModeView = mainView.editModeView;
			if (RunTimeInfo.isEditMode){
				var dataIndex = data.index;
				if(self.collection.addUpperFolderItemFlag == true){
					dataIndex = dataIndex -1;
				}
				if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
					if ( renderer.thumbnail ){
						renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
						dimIconInfo(renderer, renderer.editNum);
					}
				}
				else{
					if(data.ItemType == EItemType.eItemPvr && editModeView.optType == EOptType.eSendType){
						renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
						renderer.thumbnail.dim(true);
					}
				}
			}
			else{
				var isDrm = self.collection.getItem(data.index).get('isDrm');
				var isPlayAvailable = self.collection.getItem(data.index).get('isPlayAvailable');
				if(isPlayAvailable == false || isDrm == true){
					renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
					//renderer.thumbnail.dim(true);
					dimIconInfo(renderer, renderer.unSupportNum);
				}
			}
			renderer.thumbnail.show();
			
		}

		if(data.ItemType == EItemType.eItemPvr && data.isGuidance){
			renderer.thumbnail.addThumbnailListener(self.thumbListener);
		} 

	};


	/** createChildofPhotoView
	* @name createChildofPhotoView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data
	* @method 	 
	* */	
	renderer.createChildofPhotoView = function( renderer, data ){
		if(data.dataFlag == false){
			createFakeThumbnail(renderer, data);
			return;
		}
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,
		            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
	                    x: self.params.textX,
			            y: self.params.textY,
		                width: self.params.textWidth,
		                height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
             			textColor: { r: 255, g: 255, b: 255, a: 153 },
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: self.folderNoamalImage,
					pressedSrc: self.folderNoamalImage,
					clickable: false,
					opacity: 128,
				}
			});

			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
			
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_m_upper.png",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
		                 x: self.params.textX,
			            y: self.params.textY,
			            width: self.params.textWidth,
			            height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
					opacity:255*0.5,
					clickable: false
				}
			});

			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
	    }
		else{
			if ( !data.title1 ){
				data.title1 = '';
			}
			if ( !data.title2 ){
				data.title2 = '';
			}

		    data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_photo_n.png';
	        if( data.isThumbDone ){
	        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
		    }
	        else if(!self.collection.getItem(data.index).get('isPlayAvailable') || self.collection.getItem(data.index).get('isDrm')){
				self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath);		    	
		    }
	        else{
	       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
	       	}

			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_camera.png';
			}

			if (self.thumbnailColorFlag == false){
				self.thumbnailColorNumber = data.index%2;
				self.thumbnailColorFlag = true;
			}
			var tempIndex = data.index%2;
			var tempColorPickingOpacity = 255-240;
			if ( tempIndex == self.thumbnailColorNumber ){
				tempColorPickingOpacity = 255-225;
			}
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
		        image: {
		            src: data.ThumbPath,
		            width: self.params.imageWidth,
		            height: self.params.imageHeight
		        },
		        information: {
					x: 0, 
					y: self.params.imageHeight, 
					width: self.params.renderWidth, 
					height: self.params.infoHeight,
					//colorPickingOpacity: tempColorPickingOpacity,
					//coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
					colorPickingRange: {l:0, r: 100, t: 80, b: 100},
					enlarge:{
                             factor: 1.5,
                             anchorPoint: "bottom",
             		},
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
						x: self.params.text1X, 
						y: self.params.text1Y, 
						width: self.params.text1Width, 
						height: self.params.text1Height,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                extractColorOpacity: 153,
		            },
		        },
				icon1: {
					x: self.params.icon1X, 
					y: self.params.icon1Y, 
					width: self.params.icon1Width, 
					height: self.params.icon1Height,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					opacity: 255*0.5,
					clickable: false
				},
				icon2: {
					x: self.params.icon2X, 
					y: self.params.icon2Y, 
					width: self.params.icon2Width, 
					height: self.params.icon2Height,
					async: true,
					unpressSrc: data.unsupportIcon,
					pressedSrc: data.unsupportIcon,
					clickable: false
				},
			});
			renderer.iconNumber = 2;
			renderer.editNum = 1;
			var showCheck =  false;
			if( RunTimeInfo.isEditMode ){
				var dataIndex = data.index;
				if(self.collection.addUpperFolderItemFlag == true){
					dataIndex = dataIndex -1;
				}
				if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
					showCheck = true;
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
					renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
					dimIconInfo(renderer, renderer.editNum);
				}
				else{
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				}
			}
			else{
				renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
					renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
					//renderer.thumbnail.dim(true);
					dimIconInfo(renderer, renderer.iconNumber);
				}
				
			}
			renderer.thumbnail.show();
		}

	};

	/** createChildofVideoView
	* @name createChildofVideoView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data
	* @method 	 
	* */	
	renderer.createChildofVideoView = function( renderer, data ){
		print(" createChildofVideoView ");
		if(data.dataFlag == false){
			createFakeThumbnail(renderer, data);
			Log.e(" crate  createFakeThumbnail and return");
			return;
		}
		
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup ){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_video_0"+(data.index%4+1)+".PNG",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,
		            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
	                   x: self.params.textX,
			            y: self.params.textY,
		                width: self.params.textWidth,
		                height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
             			textColor: { r: 255, g: 255, b: 255, a: 153 },

		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: self.folderNoamalImage,
					pressedSrc: self.folderNoamalImage,
					clickable: false,
					opacity: 128,
				}
			});

			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
			
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_video_upper.PNG",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,

		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
		                x: self.params.textX,
			            y: self.params.textY,
			            width: self.params.textWidth,
			            height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
					clickable: false
				}
			});
			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			
			if (RunTimeInfo.isEditMode){
				var dataIndex = data.index;
				if(self.collection.addUpperFolderItemFlag == true){
					dataIndex = dataIndex -1;
				}
				if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
					if ( renderer.thumbnail ){
						renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
						dimIconInfo(renderer, renderer.editNum);
					}
				}
			}
			renderer.thumbnail.show();
			
	    }
		else{
			if ( !data.title1 ){
				data.title1 = '';
			}
			if ( !data.title2 ){
				data.title2 = '';
			}
			var uhdicon = '';
			var contenticon = '';
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
			var fillModeType = '';
			var uhdGenre = '';
			var ratingLeve = '';
			var ratingInfoX = 0;
			var ratingInfoW = 0;
			var infomationTextX = self.params.text1X;
			var infomationTextW = self.params.text1Width;
			var UHDVideoFlag = false;
			if( data.ItemType == EItemType.eItemUHDVideo){
					UHDVideoFlag = true;
					uhdicon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_uhd.png';	
					
					var uhdContentId = self.collection.getItem(data.index).get('uhdContentId');
					var uhdThumb = getUhdThumb(uhdContentId); 
					
					if(uhdThumb != null){
						//if network is connect , display uhd thumbnail
					   	data.ThumbPath = uhdThumb;
						print('Thumbnail-view.js createChild >>>>>>>>>>>>>  UHD Video ThumbPath:',data.ThumbPath);
						fillModeType = 'fit';
					}else{
							// else, display default thumb
						data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
						
					}
					
					uhdGenre = self.collection.getItem(data.index).get('uhdVideoGenre');		
					
					ratingLeve = self.collection.getItem(data.index).get('rateLevel');
							
					if(RunTimeInfo.UHDContentFolder	== true){			
						infomationTextX = 18;
						infomationTextW = 190;
						ratingInfoW = 90;
						print('ratinginfoW :',ratingInfoW);
						
						if(uhdGenre == undefined || uhdGenre == null){
							uhdGenre = '';				
						} 
						if(ratingLeve == undefined || ratingLeve == null){
							ratingLeve = '';
						} 
						
						ratingInfoX = infomationTextX;
					}else{
						ratingInfoW = (self.params.renderWidth - 16)/2;
						print('ratinginfoW :',ratingInfoW);
						infomationTextW -= ratingInfoW;
						infomationTextX += 4;
						
						if(ratingLeve == undefined || ratingLeve == null){
							ratingLeve = '';
						} else{
							ratingLeve = '|' + ratingLeve;
						}
					
						ratingInfoX = infomationTextX + infomationTextW - 10;				
						
					}

					
					print('Thumbnail-view.js createChildofVideoView >>>>>>>>>>>>>  UHD Video ThumbPath:',data.ThumbPath)
					
			}else{

		        if( data.isThumbDone ){
		        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
					print('Thumbnail-view.js createChildofVideoView >>>>>>>>>>>>>   ThumbPath:',data.ThumbPath);
			    }
				else if(self.collection.getItem(data.index).get('isDrm')){
					self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath);		    	
				}
		        else{
					print('video request thumbnail......');
		       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 324, 288);
		       	}
			}
			
			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
			}
			try{
				if (self.thumbnailColorFlag == false){
					self.thumbnailColorNumber = data.index%2;
					self.thumbnailColorFlag = true;
				}
				var tempIndex = data.index%2;
				var tempColorPickingOpacity = 255-240;
				if ( tempIndex == self.thumbnailColorNumber ){
					tempColorPickingOpacity = 255-225;
				}
				print(" createChildofVideoView  isUHDContentFolder: "+RunTimeInfo.UHDContentFolder);
				
				print(" createChildofVideoView  fillModeType: " + fillModeType);

				if(RunTimeInfo.UHDContentFolder	== true){
					renderer.thumbnail = new Thumbnail({
					    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
					    //parent: scene,//renderer.root,
				        x: 0,
				        y: 0,
				        width: self.params.renderWidth,
				        height: self.params.renderHeight,
				        coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
				        image: {
				            src: data.ThumbPath,
				            width: self.params.imageWidth,
				            height: self.params.imageHeight,
				            fillMode: fillModeType,
				        },
				        information: {
							x: 0, 
							y: self.params.imageHeight, 
							width: self.params.renderWidth, 
							height: self.params.infoHeight,
							//colorPickingOpacity: tempColorPickingOpacity,
							
							setAsBackground: UHDVideoFlag,
							colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
							enlarge:{
		                             factor: 1.5,
		                             anchorPoint: "bottom",
		             		},
				            text1: {
				            	text: data.title1,
				                font: 'SamsungSmart_Light 24px',
								x: infomationTextX, 
								y: self.params.text1Y, 
								width: infomationTextW, 
								height: self.params.text1Height,
				                horizontalAlignment: 'center',
				                verticalAlignment: 'center',
				                singleLineMode: true,
				                extractColorOpacity: 153,
				            },
							 text2: {
				            	text: uhdGenre,
				                font: 'SVD Light 20px',
		                		x: ratingInfoX,
								y: self.params.text1Y+self.params.text1Height+4,			
								width: ratingInfoW, 
								height: self.params.text1Height,		                
								horizontalAlignment: 'left',
				                verticalAlignment: 'center',
				                singleLineMode: true,
				                opacity : 128,
				            },
				            text3: {
				            	text: ratingLeve,
				                font: 'SVD Light 20px',
		                		x: ratingInfoX + ratingInfoW + 10,
								y: self.params.text1Y+self.params.text1Height+4,		
								width: ratingInfoW, 
								height: self.params.text1Height,		                
								horizontalAlignment: 'right',
				                verticalAlignment: 'center',
				                singleLineMode: true,
				                opacity : 128,
				            },
				       	},
						icon1: {
							x: self.params.icon1X, 
							y: self.params.icon1Y, 
							width: self.params.icon1Width, 
							height: self.params.icon1Height,
							async: true,
							unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
							pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
							opacity: 255*0.5,
							clickable: false
						},
						icon2: {
							x: self.params.icon2X, 
							y: self.params.icon2Y, 
							width: self.params.icon2Width, 
							height: self.params.icon2Height,
							async: true,
							unpressSrc: data.unsupportIcon,
							pressedSrc: data.unsupportIcon,
							clickable: false
						},
						icon3: {
							x: self.params.uhdX, 
							y: self.params.uhdY, 
							width: self.params.uhdWidth, 
							height: self.params.uhdHeight,
							async: true,
							unpressSrc: uhdicon,
							pressedSrc: uhdicon,
							clickable: false
						},
					});
				}else{
					renderer.thumbnail = new Thumbnail({
				    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
				    //parent: scene,//renderer.root,
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,
			        coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
			        image: {
			            src: data.ThumbPath,
			            width: self.params.imageWidth,
			            height: self.params.imageHeight,
			            fillMode: fillModeType,
			        },
			        information: {
						x: 0, 
						y: self.params.imageHeight, 
						width: self.params.renderWidth, 
						height: self.params.infoHeight,
						//colorPickingOpacity: tempColorPickingOpacity,
						
						setAsBackground: UHDVideoFlag,
						colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
						enlarge:{
	                             factor: 1.5,
	                             anchorPoint: "bottom",
	             		},
			            text1: {
			            	text: data.title1,
			                font: 'SamsungSmart_Light 24px',
							x: infomationTextX, 
							y: self.params.text1Y, 
							width: infomationTextW, 
							height: self.params.text1Height,
			                horizontalAlignment: 'center',
			                verticalAlignment: 'center',
			                singleLineMode: true,
			                extractColorOpacity: 153,
			            },
						 text2: {
			            	text: ratingLeve,
			                font: 'SVD Light 20px',
	                		x: ratingInfoX,
							y: self.params.text1Y+2,				
							width: ratingInfoW, 
							height: self.params.text1Height,		                
							horizontalAlignment: 'right',
			                verticalAlignment: 'center',
			                singleLineMode: true,
			                opacity : 128,
			            },
			        },
					icon1: {
						x: self.params.icon1X, 
						y: self.params.icon1Y, 
						width: self.params.icon1Width, 
						height: self.params.icon1Height,
						async: true,
						unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
						pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
						opacity: 255*0.5,
						clickable: false
					},
					icon2: {
						x: self.params.icon2X, 
						y: self.params.icon2Y, 
						width: self.params.icon2Width, 
						height: self.params.icon2Height,
						async: true,
						unpressSrc: data.unsupportIcon,
						pressedSrc: data.unsupportIcon,
						clickable: false
					},
					icon3: {
						x: self.params.uhdX, 
						y: self.params.uhdY, 
						width: self.params.uhdWidth, 
						height: self.params.uhdHeight,
						async: true,
						unpressSrc: uhdicon,
						pressedSrc: uhdicon,
						clickable: false
					},
				});
				
				}
			}catch(e){
				print("create video child e: ",e);
			}
			try{
			renderer.iconNumber = 3;
			renderer.unSupportNumber = 2;
			renderer.editNum = 1;
			var showCheck =  false;
			if( RunTimeInfo.isEditMode ){
				var dataIndex = data.index;
				if(self.collection.addUpperFolderItemFlag == true){
					dataIndex = dataIndex -1;
				}
				if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
					showCheck = true;
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
					renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
					dimIconInfo(renderer, renderer.editNum);
				}
				else{
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				}
				if( data.ItemType == EItemType.eItemSCSA){
					renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
					renderer.thumbnail.dim(true);
				}
			}
			else{
				renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
					renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
					//renderer.thumbnail.dim(true);
					dimIconInfo(renderer, renderer.unSupportNumber);
				}
				
			}
			
			if( data.ItemType == EItemType.eItemUHDVideo){
				renderer.thumbnail.visualizeAttachIcon(true, "icon3");
			}
		
			
			renderer.thumbnail.show();
			}catch(e){
				print('22222222222222222  e:',e);
			}
		}

	};	



	/** createChildofMusicView
	* @name createChildofMusicView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data
	* @method 	 
	* */	
	renderer.createChildofMusicView = function( renderer, data ){
		if(data.dataFlag == false){
			createFakeThumbnail(renderer, data);
			return;
		}
	
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup ){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,
		            colorPickingRange: {l:0, r: 100, t: 80, b: 100},
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
		                 x: self.params.textX,
			            y: self.params.textY,
		                width: self.params.textWidth,
		                height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
             			textColor: { r: 255, g: 255, b: 255, a: 153 },
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: self.folderNoamalImage,
					pressedSrc: self.folderNoamalImage,
					clickable: false,
					opacity: 128,
				}
			});

			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
			
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_m_upper.png",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,
		            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
	                  x: self.params.textX,
			            y: self.params.textY,
			            width: self.params.textWidth,
			            height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
					opacity:255*0.5,
					clickable: false
				}
			});
			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
			
	    }
		else{
			if ( !data.title1 ){
				data.title1 = '';
			}
			if ( !data.title2 ){
				data.title2 = '';
			}

			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_music_n.png';
	        if( data.isThumbDone ){
	        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
		    }
	        else if(!self.collection.getItem(data.index).get('isPlayAvailable')|| self.collection.getItem(data.index).get('isDrm')){
				self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath);		    	
		    }
	        else{
	       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
	       	}

			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_music.png';
			}
			var hdIcon = '';
			if( self.collection.getHDAudioType(data.index)==true){
				hdIcon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_music_hd.png';	
			}		
			if (self.thumbnailColorFlag == false){
				self.thumbnailColorNumber = data.index%2;
				self.thumbnailColorFlag = true;
			}
			var tempIndex = data.index%2;
			var tempColorPickingOpacity = 255-240;
			if ( tempIndex == self.thumbnailColorNumber ){
				tempColorPickingOpacity = 255-225;
			}
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        	coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
		        image: {
		            src: data.ThumbPath,
		            width: self.params.imageWidth,
		            height: self.params.imageHeight
		        },
		        information: {
					x: 0, 
					y: self.params.imageHeight, 
					width: self.params.renderWidth, 
					height: self.params.infoHeight,
					//colorPickingOpacity: tempColorPickingOpacity,
				
					colorPickingRange: {l:0, r: 100, t: 80, b: 100},
					enlarge:{
                             factor: 1.5,
                             anchorPoint: "bottom",
             		},
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
						x: self.params.text1X, 
						y: self.params.text1Y, 
						width: self.params.text1Width, 
						height: self.params.text1Height,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                extractColorOpacity: 153,
		            },
		        },
				icon1: {
					x: self.params.icon1X, 
					y: self.params.icon1Y, 
					width: self.params.icon1Width, 
					height: self.params.icon1Height,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					opacity: 255*0.5,
					clickable: false
				},
				icon2: {
					x: self.params.icon2X, 
					y: self.params.icon2Y, 
					width: self.params.icon2Width, 
					height: self.params.icon2Height,
					async: true,
					unpressSrc: data.unsupportIcon,
					pressedSrc: data.unsupportIcon,
					clickable: false
				},
			});
			renderer.iconNumber = 2;
			renderer.editNum = 1;
			var showCheck =  false;
			if( RunTimeInfo.isEditMode ){
				var dataIndex = data.index;
				if(self.collection.addUpperFolderItemFlag == true){
					dataIndex = dataIndex -1;
				}
				if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
					showCheck = true;
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
					renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
					dimIconInfo(renderer, renderer.editNum);
				}
				else{
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				}
			}
			else{
				renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
					renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
					//renderer.thumbnail.dim(true);
					dimIconInfo(renderer, renderer.iconNumber);
				}
				
			}

			renderer.thumbnail.show();
			
		}

	};

	/** createChildofRecordView
	* @name createChildofRecordView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data
	* @method 	 
	* */	
	renderer.createChildofRecordView = function( renderer, data ){
		if(data.dataFlag == false){
			createFakeThumbnail(renderer, data);
			return;
		}
	
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup){
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			        x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,			            
		            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
		                x: self.params.textX,
			            y: self.params.textY,
		                width: self.params.textWidth,
		                height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
						enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
             			textColor: { r: 255, g: 255, b: 255, a: 153 },
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: self.folderNoamalImage,
					pressedSrc: self.folderNoamalImage,
					clickable: false,
					opacity: 128,
				}
			});

			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
			
		}
	    else if( data.ItemType == EItemType.eItemUpFolder ){
			Log.e("add UpFolder index = "+ data.index);
			renderer.thumbnail = new Thumbnail({
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        image: {
		            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_video_upper.PNG",
		            width: self.params.renderWidth,
		            height: self.params.renderHeight
		        },
		        information: {
			         x: 0,
			        y: 0,
			        width: self.params.renderWidth,
			        height: self.params.renderHeight,			            
		            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
		                x: self.params.textX,
			            y: self.params.textY,
			            width: self.params.textWidth,
			            height: self.params.textHeight,
		                horizontalAlignment: 'center',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                enlarge:{
                             factor: 1.5,
                             anchorPoint: 'center',
             			},
		            },
		        },
				icon1: {
					x: self.params.folderX, 
					y: self.params.folderY, 
					width: self.params.folderWidth, 
					height: self.params.folderHeight,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
					clickable: false
				}
			});
			if(RunTimeInfo.isEditMode == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				renderer.thumbnail.dim(true);
			}
			else{
				renderer.thumbnail.dim(false);
			}
			renderer.thumbnail.show();
			
	    }
		else{
			if ( !data.title1 ){
				data.title1 = '';
			}
			if ( !data.title2 ){
				data.title2 = '';
			}

			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
			if( data.ItemType == EItemType.eItemPvr ){
				if(data.isLocked){
					data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_adult_n.png';
					self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );    
				}
				 
				 if(data.isAudioOnly){
					data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_audio_n.PNG';
					self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );    
				}	      	           	
				if(self.collection.getItem(data.index).get('ciThumbType') > CIThumbType.E_THUMB_OK || self.collection.getItem(data.index).get('isDrm')){
					data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
					self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );
				}
                else if(data.isLocked || data.isAudioOnly){
                   self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );                   
                }
                else if( data.isThumbDone){
                    data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
                }         
                else{
                    self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 324, 288);
                }
			}
			else{
				return renderer;
			}
			
			var infomationTextX = self.params.text1X;
			var infomationTextW = self.params.text1Width;
			var watchedIconSrc = '';
			var sportsIcoSrc = '';
			var unSupportSrc = '';
			var playIcoSrc = '';
			var dateText= '';
			var chanelName = '';
			
	
			if(data.ItemType == EItemType.eItemPvr){
			
				if(data.sportsType == 2){
					sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_soccer.png";
				}
				else if(data.sportsType == 3){				
					sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_rugby.png";
				}
				else if(data.sportsType == 4){
					sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_hockey.png";
				}
				/*
				if(data.isWatched){
					watchedIconSrc  = Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_recorded_watched.PNG"
					infomationTextX += 22;
					infomationTextW -= 22;
				}*/
				if(data.isGuidance){
					infomationTextW -= 26;
				}
				if(data.isRecording){					
					unSupportSrc = Volt.BASE_PATH + resMgr.getImgPath()+ "/Contents_icon/recorded_rec_icon.png";
				}
				if(self.collection.getItem(data.index).get('ciThumbType') == CIThumbType.E_THUMB_INVALID || self.collection.getItem(data.index).get('isDrm')){
					playIcoSrc = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
				}
				
				dateText = self.collection.getItem(data.index).get('date');
				chanelName = self.collection.getItem(data.index).get('chanelName');
				
			}
			if (self.thumbnailColorFlag == false){
				self.thumbnailColorNumber = data.index%2;
				self.thumbnailColorFlag = true;
			}
			var tempIndex = data.index%2;
			var tempColorPickingOpacity = 255-240;
			if ( tempIndex == self.thumbnailColorNumber ){
				tempColorPickingOpacity = 255-225;
			}
			var input = {
			    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
			    //parent: scene,//renderer.root,
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
		        	coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
		        image: {
		            src: data.ThumbPath,
		            width: self.params.imageWidth,
		            height: self.params.imageHeight
		        },
		        information: {
					x: 0, 
					y: self.params.imageHeight, 
					width: self.params.renderWidth, 
					height: self.params.infoHeight,
					//colorPickingOpacity: tempColorPickingOpacity,
				
					colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
					enlarge:{
                             factor: 1.5,
                             anchorPoint: "bottom",
             		},
		            text1: {
		            	text: data.title1,
		                font: 'SamsungSmart_Light 24px',
						x: infomationTextX, 
						y: self.params.text1Y, 
						width: infomationTextW, 
						height: self.params.text1Height,
		                horizontalAlignment: 'left',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                extractColorOpacity: 153,
		            },
		            text2: {
		            	text: dateText,
		            	font: 'SamsungSmart_Light 21px',
		            	x: 18,
		            	y: 60,
		            	width: 135,
		            	height: 30,
		            	horizontalAlignment: 'left',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                extractColorOpacity: 153,
		            },
		            text3: {
		            	text: chanelName,
		            	font: 'SamsungSmart_Light 21px',
		            	x: 171,
		            	y: 60,
		            	width: 135,
		            	height: 30,
		            	horizontalAlignment: 'right',
		                verticalAlignment: 'center',
		                singleLineMode: true,
		                extractColorOpacity: 153,
		            }
		        },
				icon1: {
					x: self.params.icon1X, 
					y: self.params.icon1Y, 
					width: self.params.icon1Width, 
					height: self.params.icon1Height,
					async: true,
					unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
					opacity: 255*0.5,
					clickable: false
				},
				icon2: {
					x: 280,
					y: 241,
					width: 26,
					height: 25,
					async: true,
					unpressSrc: '',
					pressedSrc: '',
					clickable:false,
				},
			};
			renderer.iconNumber = 2;
			renderer.editNum = 1;	
			/*
			if ( watchedIconSrc != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: 18,
					y: 225,
					width: 17,
					height: 17,
					async: true,
					unpressSrc: watchedIconSrc,
					pressedSrc: watchedIconSrc,
					clickable:false,
				});
			}*/
			if ( sportsIcoSrc != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: 280 -35, 
					y: 10, 
					width: 32, 
					height: 32,
					async: true,
					unpressSrc: sportsIcoSrc,
					pressedSrc: sportsIcoSrc,
					clickable: false
					
				});
			}
			if ( unSupportSrc != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: 118,
					y: 52,
					width: 88,
					height: 88,
					async: true,
					unpressSrc: unSupportSrc,
					pressedSrc: unSupportSrc,
					clickable: false,
				});
			}
			if ( playIcoSrc != '' ){
				renderer.iconNumber++;
				setIconInfo(input, renderer.iconNumber, {
					x: 280, 
					y: 10, 
					width: 32, 
					height: 32,
					async: true,
					unpressSrc: playIcoSrc,
					pressedSrc: playIcoSrc,
					clickable: false
				});
			}
			renderer.thumbnail = new Thumbnail(input);
			var showCheck =  false;
			if( RunTimeInfo.isEditMode ){
				var dataIndex = data.index;
				if(self.collection.addUpperFolderItemFlag == true){
					dataIndex = dataIndex -1;
				}
				if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
					if(data.isRecording || data.isLocked){
						var editModeView = mainView.editModeView;
						if(editModeView.optType == EOptType.eDeleteType){
							renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
							renderer.thumbnail.dim(true);
						}
						else{
							showCheck = true;
							renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
							renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
							dimIconInfo(renderer, renderer.editNum);
						}
					}
					else{
						showCheck = true;
						renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
						renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
						dimIconInfo(renderer, renderer.editNum);
					}
				}
				else{
					if(data.isRecording || data.isLocked){
						var editModeView = mainView.editModeView;
						if(editModeView.optType == EOptType.eDeleteType){
							renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
							renderer.thumbnail.dim(true);
						}
						renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
					}
					else{
						renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
					}
				}
			}
			else{
				renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				if(self.collection.getItem(data.index).get('isPlayAvailable')== false || self.collection.getItem(data.index).get('isDrm')){
					renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
					//renderer.thumbnail.dim(true);
					dimIconInfo(renderer,renderer.iconNumber)
				}
				
			}
			renderer.thumbnail.show();
			
		}
		if(data.ItemType == EItemType.eItemPvr && data.isGuidance){
			renderer.thumbnail.addThumbnailListener(self.thumbListener);
		}

	};



	
	/** onDraw
	* @name onDraw	 
	* @memberOf Thumbnail_View
	* @param {Object} rend
	* @param {String} drawTypeString
	* @param {Object} data
	* @param {int} parentWidth
	* @param {int} parentHeight
	* @method 	 
	* */	
    renderer.onDraw = function(rend, drawTypeString, data, parentWidth, parentHeight){
	    //print('@@@@[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'onDraw    @@@@   drawTypeString  '+ drawTypeString );
		if( !data )
		{
		    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'data is null    ' );
			return;
		}
		if ( data.dummyFlag == true ){
			return; 
		}
		
		var item = self.collection.getItem(data.index);
		if(item == null || item == undefined){
			print('[thumbnail-view.js]renderer.onDraw-------- item is null');
			return ;
		}
		
		
		var tepNum = rend.textWidgetNumber;
        if ("LoadData" == drawTypeString)
        {
        	if(data.dataFlag == false){
				data.createFlag = false;
			}
        	print("renderer LoadData index:"+data.index+", data.createFlag:"+data.createFlag+", dataflag: "+data.dataFlag);
			Volt.setTimeout(function(){		
				try {
					if( data.createFlag == false){
						if(data.dataFlag == false){
							var tempItem = self.collection.getItem(data.index);	
							data.dataFlag = true;
							data.title1 =  tempItem.get('title1');
							data.title2 =  tempItem.get('title2');
							data.ItemType =  tempItem.get('ItemType');
							data.isWatched =  tempItem.get('isWatched');
							data.isAudioOnly = tempItem.get('isAudioOnly');
							data.isLocked = tempItem.get('isLocked');
							data.isGuidance = tempItem.get('isGuidance');
							data.sportsType = tempItem.get('sportsType');
							data.isRecording = tempItem.get('isRecording');
							data.isThumbDone = tempItem.get('isThumbDone');
							data.imgUrl = Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_m_0"+(data.index%6+1)+".png";
							data.ThumbPath = '';
							data.conIconPath =  '';
							data.unsupportIcon = '';
							data.createFlag = true;	
						}
						self.updateRender( data, rend );
					}
				}catch(e){
					print("renderer LoadData except e:"+e);
					Log.e("renderer LoadData except e:"+e);
				}
			},100);		
        }
        else if ("UnloadData" == drawTypeString)
        {
        	rend.thumbnail.removeThumbnailListener(self.thumbListener);
			data.createFlag = false;
        }
		else if ("UpdateData" == drawTypeString){
			//var tempPath = self.collection.getItem(data.index).get('ThumbPath');
			var tempPath = item.get('ThumbPath');
			print('[thumbnail-view.js] index:'+ data.index + ', tempPath: '+ tempPath);
			if ( rend.thumbnail ){
				print('[onDraw] set thumbnail image~~~~~~~~~~~~~');
				rend.thumbnail.setContentImage(tempPath);
			}
		}
		else if ( nativeGridlistFocus.NATIVEGRIDMOVETO == drawTypeString ){
			return;
		}
		else if ( nativeGridlistFocus.NATIVEGRIDMOVEFROM == drawTypeString ){
			return;
		}
		else if ( 'FormItemFocusChangeAniEnd' == drawTypeString ){
			if( rend && rend.thumbnail ){
				//rend.thumbnail.setInformationTextFont("text1",'SamsungSmart_Light 36px');
				//var newItem = self.collection.getItem(data.index);
   				var newItem = item;
   				if(newItem != null && newItem.get('ItemType') == EItemType.eItemFolder ){
					var param = {
						index : data.index,
						rend : rend
					}
					rend.unique = Volt.setTimeout(changeRenderImg, 1, param);
				}
				else{
					/*
					var itemType = newItem.get('ItemType');
					print('11111111111111111111111itemType = ',itemType);
					var editModeView = mainView.editModeView;
					if(itemType == EItemType.eItemVideo || itemType == EItemType.eItemPhoto ||
					  itemType == EItemType.eItemMusic || item.get('ItemType') == EItemType.eItemUHDVideo){
					   if(newItem.get('isPlayAvailable') == true){
					   		rend.thumbnail.dim(false);
					   }
					   else{
					   		rend.thumbnail.dim(true);
					   }
					}
					else{
						if(itemType == EItemType.eItemPvr){
							if(RunTimeInfo.isEditMode == true){
								if(editModeView.optType == EOptType.eSendType){
								    rend.thumbnail.dim(true);
								}
								else{
									rend.thumbnail.dim(false);
								}
							}
							else{
								rend.thumbnail.dim(false);
							}
						}
					}*/
				}
			}
		}
		else if ( 'ToItemFocusChangeAniEnd' == drawTypeString ){
			if( rend && rend.thumbnail ){
				
				print('data.index : ',data.index);			
		
				var newItem = item;
   				if( newItem.get('ItemType') == EItemType.eItemFolder ){
					var tempImage = null;
					if (self.folderFocusImage){
						tempImage = self.folderFocusImage;
					}
					else{
						tempImage = resMgr.getImgPath()+'/foders/mc_icon_foder_zoom.png';
					}	
					rend.thumbnail.setAttachIcon("icon1", tempImage);
   				}
				else{
				}
				
			}
		}
	};

	/** onRelease
	* @name onRelease	 
	* @memberOf Thumbnail_View
	* @param { }    
	* @method 	 
	* */	
    renderer.onRelease = function() {

    };

	return renderer;
};

/** changeRenderImg
* @name changeRenderImg	 
* @memberOf Thumbnail_View
* @param { param }    param
* @method 	 
* */	
function changeRenderImg(param){
	self.changeRenderImg(param);
};

function setVoiceText( renderer, tempIndex, type ){
	var voiceText = self.getVoideText(tempIndex,type);
	print('[thumbnail_View.js] setVoiceText:', voiceText,' type : ',type);
	renderer.thumbnail.setTTSText({text: voiceText});
};

function getUhdThumb(contentId){
	var thumb = null;
	print('getUhdThumb >>>>>>>>>  contentId:',contentId);
	if(contentId == null){
		return thumb;
	}

	var i = 0;
	for(i = 0; i < UHDTumbnail.Tumbnail.length; i++){
		if(contentId == UHDTumbnail.Tumbnail[i]){
			print('Find thumb contentId:',contentId);
			thumb = resMgr.getImgPath()+'/UHDThumb/'+contentId +'.png';
			break;
		}
	}
	print('getUhdThumb >>>>>>>>>>>  thumb:',thumb);
	return thumb;
};


function playVoiceText( tempIndex, type ){
	var voiceText = self.getVoideText(tempIndex,type);
	print('[thumbnail_View.js] playVoiceText :', voiceText,' type : ',type);
	TTS.setText(voiceText);
	TTS.play();
	//renderer.thumbnail.setTTSText({text: voiceText});
};

function setInfoIconInfo( input, iconNum, iconPa ){
	switch (iconNum) {
        case 1:
			input.information.icon1 = iconPa;
            break;
        case 2:
			input.information.icon2 = iconPa;
			break;
        default:
            break;
    }
};

function setInfoTextInfo( input, iconNum, iconPa ){
	switch (iconNum) {
        case 1:
			input.information.text2 = iconPa;
            break;
        case 2:
			input.information.text2 = iconPa;
			break;
       case 3:
			input.information.text3 = iconPa;
			break;
        default:
            break;
    }
};

function setIconInfo( input, iconNum, iconPa ){
	switch (iconNum) {
        case 1:
			input.icon1 = iconPa;
            break;
        case 2:
			input.icon2 = iconPa;
			break;
        case 3:
			input.icon3 = iconPa;
			break;
        case 4:
			input.icon4 = iconPa;
		    break;
        case 5:
			input.icon5 = iconPa;
            break;
        case 6:
			input.icon6 = iconPa;
			break;
        case 7:
			input.icon7 = iconPa;
			break;
        case 8:
			input.icon8 = iconPa;
		    break;
        case 9:
			input.icon9 = iconPa;
			break;
        case 10:
			input.icon10 = iconPa;
		    break;
        default:
            break;
    }
};

function dimIconInfo( input, iconNum ){
	switch (iconNum) {
        case 1:
			input.thumbnail.setElementOpacity("icon1", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon1");
			break;
        case 2:
			input.thumbnail.setElementOpacity("icon2", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon2");
			break;
        case 3:
			input.thumbnail.setElementOpacity("icon3", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon3");
			break;
        case 4:
			input.thumbnail.setElementOpacity("icon4", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon4");
		    break;
        case 5:
			input.thumbnail.setElementOpacity("icon5", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon5");
            break;
        case 6:
			input.thumbnail.setElementOpacity("icon6", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon6");
			break;
        case 7:
			input.thumbnail.setElementOpacity("icon7", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon7");			
			break;
        case 8:
			input.thumbnail.setElementOpacity("icon8", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon8");	
		    break;
        case 9:
			input.thumbnail.setElementOpacity("icon9", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon9");	
			break;
        case 10:
			input.thumbnail.setElementOpacity("icon10", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon10");	
		    break;
        default:
            break;
    }
};

function createFakeThumbnail( renderer, data ){
	renderer.thumbnail = new Thumbnail({
	    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
        x: 0,
        y: 0,
        width: self.params.renderWidth,
        height: self.params.renderHeight,
        image: {
            src: resMgr.getImgPath()+'/default_thumb/icon_blank_thumbnail.png',
            width: self.params.renderWidth,
            height: self.params.renderHeight
        },
        information: {
          	x: 0,
        	y: 0,
            width: self.params.renderWidth,
	        height: self.params.renderHeight,
            text1: {
            	text: " ",
                font: 'SamsungSmart_Light 24px',
                x: self.params.textX,
	            y: self.params.textY,
                width: self.params.textWidth,
                height: self.params.textHeight,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                singleLineMode: true,
                enlarge:{
                     factor: 1.5,
                     anchorPoint: 'center',
     			},
     			textColor: { r: 255, g: 255, b: 255, a: 153 },
            },
        }
	});
	renderer.thumbnail.show();
};

exports = Thumbnail_View;
