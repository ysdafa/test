 /** 

 * @author  Li Hailong (hailong08.li@samsung.com)
 * 			
 * @fileoverview  Manage photoes item data
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var CommonInfo = Volt.require('app/common/define.js');
var EventType = CommonInfo.EventType;
var resMgr = Volt.require('app/controller/resource-controller.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var voltapi =  Volt.require('voltapi.js');
var _ = Volt.require('modules/underscore.js')._;
var self;
var pinPopup = function(){
	this.pinCodeCorrectCb = null;
	this.pinNumberPopup = null;
	this.parentWidget = null;
	var mainView = Volt.require('app/views/main-view.js');
	this.container = mainView.widget.getChild('main-popup-container');
	self = this;
	this.pinParent = null;

	this.listener = null;
	this.keyboardListener = null;
	this.txtCalculation2 = null;
	this.InvalidText = null;
    this.setPinCodeCorrectCb = function(cb){
		this.pinCodeCorrectCb = cb;

	};
	this.render = function(contentText1,defaultPinText,setPinText,defaultPin,titleTxt){	
		
		Volt.Nav.setRoot(this.container);
		print('render pip popup contentText1: ',contentText1);
		print('render pip popup defaultPinText: ',defaultPinText);
		print('render pip popup setPinText: ',setPinText);
		print('render pip popup defaultPin: ',defaultPin);
		
		var firstText = '';
		var secondText;
		var thirdText;
		var fourthText;
		
		if(contentText1 == null || contentText1 == undefined){
			Log.e("contentText1 == null || contentText1 == undefined");
			print("contentText1 == null || contentText1 == undefined");
			return;
		}
		var pinParentHeigh = 456;
		
	//	var index = contentText1.indexOf('.');
	//	print("find index"+index);
	//	if(index == null || index == undefined){
	//		index = contentText1.lenght/2;
	//	}
	//	firstText = contentText1.substring(0,index+1);	
	//	secondText = contentText1.substring(index+1,contentText1.lenght);
	//	print("firstText"+firstText);
	//	print("secondText"+secondText);
	//	var contentText = firstText +"\n"+secondText;

	
		var sysPin = Vconf.getValue('db/menu/system/change_pin');
		print('render >>>> sysPin:',sysPin);
		this.InvalidText = resMgr.getText('COM_SID_INVALID_PIN_TRY_AGAIN');
		var isAttachingContentFlag = false;
		
		if(setPinText != null && setPinText != undefined){
			isAttachingContentFlag = true;
			pinParentHeigh = 556;

			if(defaultPin != null && defaultPin != undefined && defaultPin == '0000'){
				//thirdText = defaultPinText + setPinText;
				thirdText = defaultPinText;
			}else{
				thirdText = setPinText;
			}

			this.txtCalculation = new TextWidgetEx({
				font: 'SamsungSmart_Light 30px',
		        text: thirdText,	     
		        parent: scene,
		        ellipsize: false,
		        opacity: 0,
		    });
			print('this.txtCalculation.width:',self.txtCalculation.width);
			print('this.txtCalculation.height:',self.txtCalculation.height);
			var vconfMenuLang = voltapi.vconf.getValue('db/menu_widget/language');
			if(vconfMenuLang == 'ta_IN.utf8' ||
				vconfMenuLang == 'uk_UA.utf8'){
				var secondContentW = (self.txtCalculation.width*4)/5;
				var secondContentH = self.txtCalculation.height * 3;
				var button_1Y = 435;
				var pinbox_oneY = 335;
			}else{
				var secondContentW = (self.txtCalculation.width*2)/3;
				var secondContentH = 75;
				var button_1Y = 430;
				var pinbox_oneY = 320;
			}
			
		}
		
		this.txtCalculation = new TextWidgetEx({
			font: 'SamsungSmart_Light 34px',
	        text: contentText1,	     
	        parent: scene,
	        ellipsize: false,
	        opacity: 0,
	    });
		print('this.txtCalculation.width:',self.txtCalculation.width);
		var firstContentW = (self.txtCalculation.width*2)/3;
		

		this.pinParent =  new WidgetEx(	{
		   x:0,
		   y:(1080 - pinParentHeigh)/2,
		   width: 1920,
		   height: pinParentHeigh,
		   parent: self.container,
		   color: {r:0, g:0, b:0, a:0}
		});	
		var color;
		if(HALOUtil.highContrast == true){
			color = {r: 0, g: 0, b: 0, a: 255};
		}else{
			color = {r: 10, g: 35, b: 61, a: 255};
		}
		
		this.pinNumberPopup = new PinPopup({
		    parent: this.pinParent,
			x: 0, 
			y: 0,
		    width: 1920,
		    height: pinParentHeigh,		   
		    pinType: "pinbox_one",
		    isTitle: true,
		    color: color,
		    contenttext : contentText1,
		    isContent: true,
		    buttonNum: 1,
		    autoArrange: false,
	        isTitleLine: true,
		    isContentMultiLine: true,
		    isAttachingContent: isAttachingContentFlag,
		    title : titleTxt,
		    titleLineOpacity: 102,
		});
		if(HALOUtil.highContrast == true){
		//	this.pinNumberPopup.setFirstLayerBGColor({firstLayerBGColor: {r: 255, g: 255, b: 255, a: 0}});
		//	this.pinNumberPopup.setSecondLayerBGColor({secondLayerBGColor: {r: 255, g: 0, b: 0, a: 255}});
		//	this.pinNumberPopup.setThirdLayerBGColor({thirdLayerBGColor: {r: 255, g: 0, b: 0, a: 255}});
		}
		this.pinNumberPopup.setPinBoxBackGroundImage({ state: "focus_state", src: resMgr.getImgPath()+"/pin/input_box_style_a_f.png" });
		this.pinNumberPopup.setPinBoxBackGroundImage({ state: "normal_state", src: resMgr.getImgPath()+"/pin/input_box_n.png" });
		this.pinNumberPopup.setPinBoxItemImage({ state: "no_input_type", src: resMgr.getImgPath()+"/pin/input_pin_place.png" });
		this.pinNumberPopup.setPinBoxItemImage({ state: "finish_input_type", src: resMgr.getImgPath()+"/pin/obe_pin_f.png" });
		
		this.pinNumberPopup.setFourthLayerBGImage({ fourthLayerBGImage: resMgr.getImgPath()+'/popup/popup_shadow.png'});
		
		this.pinNumberPopup.setButtonText({ buttonIndex: "button_1", state: "all", text: resMgr.getText('COM_SID_CANCEL') });


		this.pinNumberPopup.setButtonBorderWidth({ buttonIndex: "button_1", state: "all", width: 2});
	    this.pinNumberPopup.setButtonBorderColor({ buttonIndex: "button_1", state: "normal", color: { r: 255, g: 255, b: 255, a: 204}});
	    this.pinNumberPopup.setButtonBorderColor({ buttonIndex: "button_1", state: "disabled", color: { r: 255, g: 255, b: 255, a: 77}});


		this.pinNumberPopup.setButtonBackgroundColor({ buttonIndex: "button_1", state: "normal", color: { r: 0, g: 0, b: 0, a: 0 } });
		this.pinNumberPopup.setButtonBackgroundColor({ buttonIndex: "button_1", state: "focused", color: { r: 255, g: 255, b: 255, a: 242.25 } });
		this.pinNumberPopup.setButtonBackgroundColor({ buttonIndex: "button_1", state: "selected", color: { r: 255, g: 255, b: 255, a: 242.25 } });
		this.pinNumberPopup.setButtonBackgroundColor({ buttonIndex: "button_1", state: "disabled", color: { r: 255, g: 255, b: 255, a: 0 } });
		this.pinNumberPopup.setButtonBackgroundColor({ buttonIndex: "button_1", state: "focused-roll-over", color: { r: 255, g: 255, b: 255, a: 242.25 } });
		
		this.pinNumberPopup.setButtonTextColor({ buttonIndex: "button_1", state: "normal", color: { r: 255, g: 255, b: 255, a: 242.25 } });
		this.pinNumberPopup.setButtonTextColor({ buttonIndex: "button_1", state: "focused", color: { r: 70, g: 70, b: 70, a: 255 } });
		this.pinNumberPopup.setButtonTextColor({ buttonIndex: "button_1", state: "selected", color: { r: 70, g: 70, b: 70, a: 255 } });
		this.pinNumberPopup.setButtonTextColor({ buttonIndex: "button_1", state: "disabled", color: { r: 255, g: 255, b: 255, a: 76.5 } });
		this.pinNumberPopup.setButtonTextColor({ buttonIndex: "button_1", state: "focused-roll-over", color: { r: 70, g: 70, b: 70, a: 255 } });


	    this.pinNumberPopup.setButtonTextFontSize({ buttonIndex: "button_1", state: "all", fontSize:  28 });	
		
		//title rect area
		this.pinNumberPopup.setTitleLineRect({ x: (1920 - 782) / 2, y: 97.0, w: 782.0, h: 1 });
		this.pinNumberPopup.setTitlePosition({x :(1920 - 782)/2 ,  y:0});
		this.pinNumberPopup.setTitleSize({ w: 782.0, h: 97.0 });
		
		//first content text rect
		this.pinNumberPopup.setContentTextFont({font :'SamsungSmart_Light 34px'});		
		this.pinNumberPopup.setContentRect({ x: (1920-firstContentW)/2, y: 97.0 + 25 , w: firstContentW, h:85});
		this.pinNumberPopup.setContentTextOpacity({opacity: 229});
		
		try{
			this.pinNumberPopup.setContentRowGap({gap:7});
		}catch(e){
			print("pinNumberPopup SetContentRowGap E: "+ e);
			Log.e("pinNumberPopup SetContentRowGap E: "+ e);
		}
		
		//second content rect
		if(isAttachingContentFlag == true){
			this.pinNumberPopup.setAttachingContent1Rect({ x: (1920 - secondContentW) / 2, y: 97.0 +90 + 32.0, w: secondContentW, h: secondContentH });
			this.pinNumberPopup.setAttachingContentText1({ text: thirdText});
			this.pinNumberPopup.setAttachingContentText1Font({font :'SamsungSmart_Light 30px'});
			this.pinNumberPopup.setAttachingContentText1FontSize({ fontsize: 30 });
			this.pinNumberPopup.setAttachingContentText1Opacity({opacity:153});
			
			try{
				this.pinNumberPopup.setAttachingContentRowGap({gap:7});
			}catch(e){
				print("pinNumberPopup SetAttachingContentRowGap E: "+ e);
				Log.e("pinNumberPopup SetAttachingContentRowGap E: "+ e);
			}
			
			this.pinNumberPopup.setPinBoxRect({ pintype: "pinbox_one", x: (1920.0 - 349.0) / 2, y: pinbox_oneY, w: 349.0, h: 58 });
				//set button position
			this.pinNumberPopup.setButtonRect({ buttonIndex: "button_1", x: (1920 - 1920 * 0.140625) / 2, y: button_1Y, w: 1920 * 0.140625, h: 1080 * 0.061111 });

		}else{
						//set button position
			this.pinNumberPopup.setPinBoxRect({ pintype: "pinbox_one", x: (1920.0 - 349.0) / 2, y: 240, w: 349.0, h: 58 });
			this.pinNumberPopup.setButtonRect({ buttonIndex: "button_1", x: (1920 - 1920 * 0.140625) / 2, y: 350, w: 1920 * 0.140625, h: 1080 * 0.061111 });

		}

		print('pinNumberPopup height = ',self.txtCalculation.height);
	//	this.pinNumberPopup.setPinBoxRect({ pintype: "pinbox_one", x: (1920.0 - 349.0) / 2, y: 263, w: 349.0, h: 58 });


		this.pinNumberPopup.setInputItemsGap({type:"no_input_type", gap: 1920 * 0.003125 });
		this.pinNumberPopup.setInputItemsGap({type:"finish_input_type", gap: 1920 * 0.016666 });
		this.pinNumberPopup.setInputBoxItemSize({ type: "no_input_type", w: 30, h: 40 });
		this.pinNumberPopup.setInputBoxItemSize({ type: "finish_input_type", w: 9, h: 9 });
		this.pinNumberPopup.setDigitGap({ gap: 1920 * 0.003125});
		this.pinNumberPopup.setDigitTextSize({ w: 1920 * 0.015625, h: 1080 * 0.037037 });

	//	this.pinNumberPopup.orientation = "right-to-left"
		this.pinNumberPopup.setPinBoxFocus({ pintype: "pinbox_one" });

		this.listener = new PinPopupListener;	
		this.listener.onValidConfirm = function (list, isPassWordRight) {	
			Log.e("onValidConfirm isPassWordRight : " + isPassWordRight);
			print("onValidConfirm isPassWordRight : " + isPassWordRight);
			if (isPassWordRight == false) {		
				
				self.pinNumberPopup.resetPassWord({ pintype: "pinbox_one" });	
				
				self.txtCalculation.destroy();				
				self.txtCalculation = null;
				self.txtCalculation = new TextWidgetEx({
				        font: 'SamsungSmart_Light 34px',
				        text: self.InvalidText,
				        parent: scene,
				        ellipsize: false,
				        opacity: 0,
				    });
							
				self.pinNumberPopup.setContentRect({ x: (1920 - self.txtCalculation.width) / 2, y: 97.0+20 , w: self.txtCalculation.width, h: 100.0 });

				self.pinNumberPopup.setContentText({text: self.InvalidText});	
				self.pinNumberPopup.setPinBoxRect({ pintype: "pinbox_one", x: (1920.0 - 349.0) / 2, y: 240, w: 349.0, h: 58 });
				self.pinNumberPopup.setButtonRect({ buttonIndex: "button_1", x: (1920 - 1920 * 0.140625) / 2, y: 350, w: 1920 * 0.140625, h: 1080 * 0.061111 });


				//clear AttachingContentText
				self.pinNumberPopup.setAttachingContentText1({ text: ''});
			//	self.pinNumberPopup.height = 456;
			
				if(typeof self.pinNumberPopup.setSize == 'function'){
					self.pinNumberPopup.setSize(1920,456);
					//self.pinNumberPopup.height = 456;
				}else{
					Log.e("self.pinNumberPopup.setSize is not a function");
					self.pinNumberPopup.height = 456;
				}
				self.pinParent.height = 456;
				self.pinParent.y = (1080 - 456)/2;
						
			}else{
				Log.e(" Pin Code is correct ");
						
				 				 
				if(self.pinCodeCorrectCb != null && self.pinCodeCorrectCb != undefined){
					print('call use callback');
					self.pinCodeCorrectCb();
				}
				Volt.setTimeout(_.bind(self.onExit,self),1);
			}	
		};	
				
		this.listener.onPinButtonEvent = function (pinpopup, nButtonIndex, eventType) {
			print("pin popup onPinButtonEvent eventType:"+eventType);
			print("pin popup onPinButtonEvent nButtonIndex:"+nButtonIndex);
		    if ("button_pressed" == eventType || "button_clicked" == eventType) {
			        if ("button_1" == nButtonIndex) {
			           // pin.resetPassWord({ pintype: "pinbox_one"});
						Log.e("onPinButtonEvent cancel ");
						print("onPinButtonEvent cancel ");
						Volt.setTimeout(_.bind(self.onExit,self),1);
					  // self.onExit();
				    }
		    }
		};

		
		this.keyboardListener = new KeyboardListener;
		this.keyboardListener.onKeyReleased = function (actor, keyCode) {
			Log.e("Pip popup onKeyReleased keyCode:"+keyCode);
			print("Pip popup onKeyReleased keyCode:"+keyCode);
			if (keyCode == Volt.KEY_RETURN) {
				Volt.setTimeout(self.onExit,1);				
			}
			return true;
		};
		this.pinNumberPopup.addKeyboardListener(this.keyboardListener);
		
				
		this.pinNumberPopup.addListener(this.listener);	
		
		this.pinNumberPopup.show();
			
	};
	
	this.onExit = function(){
		print('destory pip popup');
		Log.e("destory pip popup");
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		if(self.pinNumberPopup){
            Log.e("pin popup remove ");
			self.pinNumberPopup.hide(); 
            self.pinNumberPopup.removeListener(self.listener);			                  
		
			if(self.listener){
				self.listener.destroy();				
			}
			self.listener = null;
		
			print('remove keyboard listener....');
			self.pinNumberPopup.removeKeyboardListener(self.keyboardListener);                       
			if(self.keyboardListener){
				self.keyboardListener.destroy();				
			}
			self.keyboardListener = null;

			Log.e("release pip popup....");
		//	HALOUtil.asyncRelease(self.pinNumberPopup);
			self.pinNumberPopup.destroy();
			print("release pip popup finish....");
			Log.e("release pip popup finish....");
            self.pinNumberPopup = null;

        }
		
		print('set focus to main view ....');
		Log.e("set focus to main view ....");
		var mainView = Volt.require('app/views/main-view.js');	
		if ( RunTimeInfo.router.currentView && RunTimeInfo.router.currentView.nativeGridList ){
			Volt.Nav.setRoot(mainView.widget,{focus: RunTimeInfo.router.currentView.nativeGridList});
		}

	};
};


exports = pinPopup;

