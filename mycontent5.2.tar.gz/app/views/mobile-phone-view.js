 /** 
 * @author  Chen Xuemei (xnicole.chen@samsung.com)
 * 			
 * @fileoverview  MyContent content view base view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
//PanelCommon.mapWidgets(['ResizeableGrid']);
var loadTemplate = PanelCommon.loadTemplate;
var MobilePhoneTemplate = Volt.require('app/templates/1080/mobiledevice-view-template.js');
var CommonInfo = Volt.require('app/common/define.js');
var EventType = CommonInfo.EventType;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;

var Q = Volt.require('modules/q.js');
var self = null;

var listRowNum  = 1;
var listColNum = 3;
var MobilePhoneView = PanelCommon.BaseView.extend({
    template_list : MobilePhoneTemplate.ContentCateList,
    template_Item : MobilePhoneTemplate.ContentCateItem,
    mainView : null,
    isShowSecPlus: [],

	/** Initialize MobilePhoneView  	 
	* @name initialize	 
	* @memberOf MobilePhoneView
	* @method 	 
	* */	
    initialize: function(){
        self = this;
        this.mainView = Volt.require('app/views/main-view.js');
    },

	/** Show MobilePhoneView  	 
	* @name show	 
	* @memberOf MobilePhoneView
	* @param {aniType} animation type
	* @method 	 
	* */	
	show: function(aniType){
		print("content view -------- show");
		var deferred = Q.defer(); 
		self.widget.show();
		deferred.resolve();
		return deferred.promise;
    },

	/** Hide MobilePhoneView  	 
	* @name hide	 
	* @memberOf MobilePhoneView
	* @param {aniType} animation type
	* @method 	 
	* */	
    hide: function(aniType){
    	var deferred = Q.defer(); 
		self.widget.hide();
    	deferred.resolve();
		return deferred.promise;
    },

	/** Destroy MobilePhoneView  	 
	* @name destroy	 
	* @memberOf MobilePhoneView
	* @method 	 
	* */	
	destroy:function(){
		//Volt.Nav.focus(null);
		this.widget.hide();
		this.widget.destroy();	
		this.widget = null;
	},

	/** Render MobilePhoneView  	 
	* @name render	 
	* @memberOf MobilePhoneView
	* @method 	 
	* */	   	
    render : function(){
    	print('[mcMobilePhoneView.js]mobile phone view render'); 	
      	this.setWidget(loadTemplate(this.template_list));    	
        __initGrid(this.widget);
        Volt.Nav.reload();
        return this;
    },    
    
    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur',
    },
    
    onFocus : function(widget){      
   		if(this.widget !== undefined && this.widget !== null){
   			this.widget.onFocus();
   		}
    },
    
    onBlur: function(widget){
    	if(this.widget !== undefined && this.widget !== null){
   			this.widget.onBlur();
   		}
    },
    
    getOptionText : function(){
		var optionText = [
				        {text:'My Content Device Settings'},
				        {text:'Tutorial'}
				    ];
			this.mainView.headerView.optionParam.firstOptionText = optionText;
			this.mainView.headerView.optionParam.firstHeight = 72*(optionText.length);

			/*please set the optionText need to show second popup*/
			this.isShowSecPlus[0] = false;
			this.isShowSecPlus[1] = false;
    }, 
	showFocus: function(){
		Volt.Nav.endModal(self.mainView);
	},	
});

function __initGrid(grid){
   	print("grid type",typeof(grid));

	var CELL_ID = "CellId";
    grid.ifItemLoaded = function(index, width, height, id){
    	print('Load Item :', index);
    
        var mustache ={
                iconPath: '',
                title: '',
                subtitle: '',
        };
        if(index  == 0)
        {
            mustache.iconPath = Volt.BASE_PATH + resMgr.getImgPath()+'/default_thumb/mc_img_pc_photo.png';
            mustache.title = 'Photos';
        }
        else if(index == 1){
            mustache.iconPath = Volt.BASE_PATH + resMgr.getImgPath()+'/default_thumb/mc_img_pc_music.png';
            mustache.title = 'Music';
        }
        else if(index == 2) {
            mustache.iconPath = Volt.BASE_PATH + resMgr.getImgPath()+'/default_thumb/mc_img_pc_videos.png';
            mustache.title = 'Videos';
        }
        
        var widget = grid.getReuseableWidget(CELL_ID);
			
		if (widget === undefined){
	           widget = new Widget({
	                    x:0,
	                    y:0,
	                    width:width,
	                    height:height,
	           });
		}
		grid.normalizeWidget(widget, CELL_ID);
        
        
        loadTemplate(MobilePhoneTemplate.ContentCateItem, mustache, widget);
        print('Load end');
        return widget;
    };
    
   grid.ifItemUpdate = function(index, widget, id, param){
 		print('updateItem :', index);
 		
       var icon =  widget.getChild(0);
       if( icon != undefined){
        	icon.show();

       }
       var title = widget.getChild(1);
       if( title != undefined){
            title.show();
       }
       var subtitle = widget.getChild(2);
       if(subtitle != undefined)
       {
    	    subtitle.show();
       }
      
       
   };
   grid.ifItemPress = function(index, widget){
		print('Item Pressed: ',index);
		EventMediator.trigger(EventType.EVENT_TYPE_SELECT_MOBILE_PHONE_VIEW, index);
   };
   
   var arrItems = [];
   for (var i = 0; i < listRowNum; ++i) 
        {
            for (var j = 0; j < listColNum; ++j) 
            {
                arrItems.push
                ({
                    width:1,
                    height:1,
                });
            }
        }
   // Attributes
	grid.itemScale = {x:1.05, y:1.05}; 
	grid.focusMode = grid.FOCUS_MODE_3D;
	grid.setItems(arrItems, true);
	grid.nAniTimeMove = 300;
	grid.color = {r:0xf2, g:0xf2, b:0xf2};
	grid.border = {width:2, color:{r:100,g:100,b:100}};
	grid.show();
	
    
}

exports = MobilePhoneView;
