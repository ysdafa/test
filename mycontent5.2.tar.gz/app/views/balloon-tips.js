 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Ballon popup class
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var self = null;

var BalloonTips = function() {
	this.text = "";
	this.txtWidth = 0;
	this.wdgHeight =0;
	this.wdgWidth = 0;
	this.txtHeight =0;
	this.tail_distance = 0;
	this.tOut = null;
	this.font = "";
	this.fontsize = 0;
	this.x = 0;
	this.y = 0;

	/**show balloon popup
	* @name show
	* @memberOf BallonPop	
	* @param {Object} the parameter for this balloon popup
	* @method
	* @return {} 	 
	* */		
	this.show = function(para){
		
		self = this;
		print('ballon tips show >>>>>>>>>>>>>>  para:',para)
		this.text = para.text;
		this.font = para.font;
		this.fontsize = para.fontsize;

		this.tailType = para.tailType;
		this.wdgx = para.x;
		this.wdgy = para.y;
		this.wdgWidth = para.wdgWidth;
		this.wdgHeight = para.wdgHeight;
		print('para.wdgHeight : ',para.wdgHeight);
		print('para.wdgWidth : ',para.wdgWidth);
		this.txtWidth = this._getStrWidth(this.text, para.font) + 36;
		this.txtHeight = this._getStrHeight(this.text, para.font) + 45;

		this.tail_distance = 0;
		this.tail_x = 0;
		this.tail_y = 0;
		print('width :',this.txtWidth);
		print('height :',this.txtHeight);
		var real_x = 0;
		var real_y = 0;
		var horizontalAlignment = 'center';
		var tailWidth = 18;
		var tailHeight = 12;
		var lineSpacing = 5;
		if(para.tailType == 'down'){
	
			this.tail_distance = 0;
			this.tail_x = this.wdgx + this.wdgWidth / 2 - 10;
			this.tail_y = this.wdgy - 12 - 2;
			this.tail_distance = (this.txtWidth - 18)/2

			this.x = this.tail_x - this.tail_distance;
			this.y = this.tail_y - this.txtHeight;

			if(this.x + this.txtWidth >= 1920){
				this.x = this.x - this.tail_distance + 12;
				this.tail_distance = this.tail_distance + (this.tail_distance - 12);
			}
			if(this.x < 0){
				this.x = this.x + this.tail_distance - 12;
				this.tail_distance = 12;
			}

		} else if(para.tailType == 'up'){
			this.tail_distance = 0;
			this.tail_x = this.wdgx + this.wdgWidth / 2 - 10;
			this.tail_y = this.wdgy + this.wdgHeight + 2;
			this.tail_distance = (this.txtWidth - 18)/2
				
			this.x = this.tail_x - this.tail_distance;
			this.y = this.tail_y - 7;

			if(this.x + this.txtWidth >= 1920){
				this.x = this.x - this.tail_distance + 12;
				this.tail_distance = this.tail_distance + (this.tail_distance - 12);
			}
			if(this.x < 0){
				this.x = this.x + this.tail_distance - 12;
				this.tail_distance = 12;
			}
		} else if(para.tailType == 'right'){
			print("para.tailType :"+para.tailType );
			this.tail_distance = 2.5;
			this.tail_x = this.wdgx;
			this.tail_y = this.wdgy + this.wdgHeight / 2 -5;
		//	this.tail_distance = 0
			tailWidth = 12;
			tailHeight = 18;
			this.txtWidth = para.textAreaW+5;
			this.txtHeight = this._getStrHeight(this.text, para.font, para.textAreaW-40)+40;
			
			print("this.txtHeight:"+this.txtHeight);
			this.x = this.tail_x - para.textAreaW;
			this.y = this.tail_y;
		
			/*
			if(this.x + this.txtWidth >= 1920){
				this.x = this.x - this.tail_distance + 12;
				this.tail_distance = this.tail_distance + (this.tail_distance - 12);
			}
			if(this.x < 0){
				this.x = this.x + this.tail_distance - 12;
				this.tail_distance = 12;
			}
			*/
		} 
		
		print('this.tail_distance : ',this.tail_distance);
		print('this.x : ',this.x);
		print('para.x : ',para.x);
		print('para.wdgWidth : ',para.wdgWidth);
		

		this.tip = new ToolTip({
				    parent: scene, 
				    x: this.x,
				    y:this.y,
				    width: this.txtWidth,
				    height: this.txtHeight,
				    color: { r: 0, g: 0, b: 0, a: 0},
				    text:this.text,
				    popupImage:resMgr.getImgPath()+'/Balloon/popup_balloon.png',
				    upTailImage:resMgr.getImgPath()+'/Balloon/popup_balloon_tail_u.png',
				    downTailImage:resMgr.getImgPath()+'/Balloon/popup_balloon_tail_d.png',
				    leftTailImage:resMgr.getImgPath()+'/Balloon/popup_balloon_tail_l.png',
				    rightTailImage:resMgr.getImgPath()+'/Balloon/popup_balloon_tail_r.png',
					tailWidth: tailWidth,
					tailHeight: tailHeight,
					tailSide: para.tailType,
					tailDistance: this.tail_distance,
					tailOffset: -4,
					lineSpacing:lineSpacing,
				    font: this.font,
				    fontSize: this.fontsize,
					textBackgroundColor: { r: 255, g: 100, b: 100, a: 0 },
					textColor: { r: 64, g: 64, b: 64, a: 204 },
					frameColor: { r: 64, g: 64, b: 64, a: 0 },
					frameWidth: 0

				}
		);
		
		if(para.tailType == 'right'){		
			this.tip.setTextPosition(20, 2);
			this.tip.setTextSize(516-20-20, this.txtHeight);
			this.tip.setTextAlignment("horizontal_align_left", "vertical_align_middle");
			this.tip.setTextRowGap(5);

		}
		
		this.tip.show();		
		this.tOut =  Volt.setTimeout(this.timeOutFn, 3000);

	},

	/**hide balloon popup
	* @name hide	 
	* @memberOf BallonPop	 
	* @method
	* @return {} 
	**/		
	this.hide = function(){
		if(this.tOut != null){
			Volt.clearTimeout(this.tOut);
		}
		if(this.tip != null){
			this.tip.hide();
		}
	},

	/**destroy balloon popup
	* @name destroy
	* @memberOf BallonPop	 
	* @method
	* @return {}  	 */		
	this.destroy = function(){
		
		//Volt.clearTimeout(this.tOut);
		if(this.tOut != null){
			Volt.clearTimeout(this.tOut);
			this.tOut = null;
		}
		if(this.tip){
			this.tip.destroy();
			this.tip = null;
		}
	};

	/**update balloon popup
	* @name update
	* @memberOf BallonPop	
	* @param {str} the new text for balloon popup
	* @param {xPos} the new x position for balloon popup	
	* @param {yPos} the new y position for balloon popup	
	* @method
	* @return {}  	 */	
	this.update = function( str, xPos, yPos ){

		if(str == undefined){
			print('update failed, str undefined');
			return;
		}

		this.text = str;
		this.x = 0;
		this.y = 0;
		
		this.txtWidth = this._getStrWidth(this.text, this.font) + 36;
		this.txtHeight = this._getStrHeight(this.text, this.font) + 45;

		this.tail_distance = 0;

		if(this.tailType == 'down'){
			
			this.tail_distance = 0;
			this.tail_x = xPos + this.wdgWidth / 2 - 10;
			this.tail_y = yPos - 12 - 2;
			this.tail_distance = (this.txtWidth - 18)/2

			this.x = this.tail_x - this.tail_distance;
			this.y = this.tail_y - this.txtHeight;

			if(this.x + this.txtWidth >= 1920){
				this.x = this.x - this.tail_distance + 12;
				this.tail_distance = this.tail_distance + (this.tail_distance - 12);
			}
			if(this.x < 0){
				this.x = this.x + this.tail_distance - 12;
				this.tail_distance = 12;
			}
			
		} else if(this.tailType == 'up'){

			this.tail_distance = 0;
			this.tail_x = xPos + this.wdgWidth / 2 - 10;
			this.tail_y = yPos + this.wdgHeight + 2;
			this.tail_distance = (this.txtWidth - 18)/2
				
			this.x = this.tail_x - this.tail_distance;
			this.y = this.tail_y - 7;


			if(this.x + this.txtWidth >= 1920){
				this.x = this.x - this.tail_distance + 12;
				this.tail_distance = this.tail_distance + (this.tail_distance - 12);
			}
			if(this.x < 0){
				this.x = this.x + this.tail_distance - 12;
				this.tail_distance = 12;
			}
		} 
		print("update tooltips x:",this.x);
		print("update tooltips y:",this.y);
		
		if(this.tip != null){
			this.tip.setTailPosition(this.tailType, this.tail_distance);
			
			this.tip.x = this.x;
		    this.tip.y = this.y;
			this.tip.width = this.txtWidth;
		    this.tip.height = this.txtHeight;
			this.tip.setText(this.text);
		}
		
		if( this.tOut!= null ){
			Volt.clearTimeout(this.tOut);
			this.tOut = null;
		}
		this.tOut =  Volt.setTimeout(this.timeOutFn, 3000);
	
	};

	/**timeout function for balloon
	* @name timeOutFn
	* @memberOf BallonPop	
	* @method
	* @return {}  	 */		
	this.timeOutFn = function(){
		print("tooltips timeOutFn")
		self.destroy();
	};

	/**get a string's width
	* @name _getStrWidth
	* @memberOf BallonPop	
	* @param {str} the target string
	* @param {fontSet} the fontsize of the text
	* @method
	* @return {int}  	 */	
	this._getStrWidth = function( str, fontSet ) {
		var wgt = new TextWidgetEx(str);
		wgt.font = fontSet;
		wgt.horizontalAlignment = 'center';
		wgt.singleLineMode = true;

		var res = wgt.width;

		wgt.destroy();
		return res;
    };

	/**get a string's height
	* @name _getStrHeight
	* @memberOf ToolTip	
	* @param {str} the target string
	* @param {fontSet} the fontsize of the text
	* @method
	* @return {int} 	 */	
	this._getStrHeight = function( str, fontSet, width) {
		print("_getStrHeight width:"+width);
		print("_getStrHeight str:"+str);
		print("_getStrHeight fontSet:"+fontSet);
		var txtCalculation ;
				
		if(width!= undefined){
	
			txtCalculation = new TextWidgetEx({
				x:0,
				y:0,
				width:width,
		        font: fontSet,
		        text: str,
		        parent: scene,
		        opacity: 0,
		        verticalAlignment: 'center',
		        horizontalAlignment:'left',
		        ellipsize: false,
		        singleLineMode:false,
		        textColor: {r:0x0f, g:0x18, b:0x27},
		    });				
		}else{
			txtCalculation = new TextWidgetEx({
				x:0,
				y:0,
		        font: fontSet,
		        text: str,
		        parent: scene,
		        opacity: 0,
		        verticalAlignment: 'center',
		        horizontalAlignment:'center',
		        ellipsize: false,
		        singleLineMode:false,
		        textColor: {r:0x0f, g:0x18, b:0x27},
		    });

		}
		
		var res = txtCalculation.height;
		print("_getStrHeight height:"+res);
		print("_getStrHeight width:"+txtCalculation.width);
		txtCalculation.destroy();
		txtCalculation = null;
		return res;
    };
	
}


exports = BalloonTips;
