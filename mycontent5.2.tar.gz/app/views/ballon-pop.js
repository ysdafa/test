 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Ballon popup class
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Backbone = Volt.require('modules/backbone.js');
var BaseView = Volt.BaseView;
var self = null;

BalloonPop = function() {
	this.text = "";
	this.bjImg = null;
	this.arrow = null;
	this.textWgt = null;
	this.width = 0;
	this.tOut = null;
	this.font = "";
	this.fontsize = 0;
	this.user = "";

	/**show balloon popup
	* @name show
	* @memberOf BallonPop	
	* @param {Object} the parameter for this balloon popup
	* @method
	* @return {} 	 
	* */		
	this.show = function(para){
		
		self = this;
		
		this.text = para.text;
		this.font = para.font;
		this.fontsize = para.fontsize;
		this.user = para.user;

		this.width = this._getStrWidth(this.text, para.font) * 1.1;
		var tempX = para.x - this.width/2;
		var realX = 0;
		var offset = 0;
		print( 'tempX for balloon is ', tempX);

		if( tempX < 0 ){
			realX = 5;
			offset = tempX + 2;
		}
		else if( tempX + this.width > 1920 ){
			realX = 1920-this.width-2;	
		}
		else{
			realX = tempX;
		}
		
		var realY = para.y - para.fontsize;
		if( para.user == 'musicplayer' ){
			realY = para.y;
		}
		
		this.bjImg = new NinePatchWidget({
			x: realX,
			y: realY,
			width: this.width,
			height: para.fontsize+6,
			async: false,
			cornerDimensions: {x:3, y:3},
			src : resMgr.getImgPath()+"/Balloon/popup_balloon.png",
			parent: scene,
		});

		var arrowImg = resMgr.getImgPath()+"/Balloon/popup_balloon_tail_d.png";
		var arrowY = para.y + 5;
		if( this.user == 'musicplayer' ){
			arrowImg = resMgr.getImgPath()+"/Balloon/popup_balloon_tail_u.png";
			arrowY = para.y - 9;
		}

		this.arrow = new ImageWidget({
			x: para.x - this.width/2,
			y: arrowY,
			width: this.width,
			height: 9,
			async: false,
			fillMode:'bottom',
			src : arrowImg,
			parent: scene,			
		});
		
		this.textWgt = new TextWidget({
			x: realX,
			y: realY,
			width: this.width,
			height: para.fontsize+6,
			text : this.text,
			font : para.font,
			horizontalAlignment: 'center',
			verticalAlignment : 'center',
			textColor: {r:64, g:64, b:64, a:204},
			parent: scene,
		});	
		
		this.tOut =  Volt.setTimeout(this.timeOutFn, 3000);
		
		this.bjImg.show();	
		this.arrow.show();
		this.textWgt.show();
	},

	/**hide balloon popup
	* @name hide	 
	* @memberOf BallonPop	 
	* @method
	* @return {}
	* */		
	this.hide = function(){
		if(this.tOut != null){
			Volt.clearTimeout(this.tOut);
		}
		
		if(this.bjImg!= null){
			this.bjImg.hide();
		}
		if(this.arrow!=null){
			this.arrow.hide();
		}
		if(this.textWgt!=null){
			this.textWgt.hide();
		}		
	},

	/**destroy balloon popup
	* @name destroy
	* @memberOf BallonPop	 
	* @method
	* @return {} 	 */		
	this.destroy = function(){
		this.hide();
		//Volt.clearTimeout(this.tOut);
		
		if(this.bjImg!= null){
			this.bjImg.destroy();
			this.bjImg = null;
		}
		if(this.arrow!=null){
			this.arrow.destroy();
			this.arrow = null;
		}
		if(this.textWgt!=null){
			this.textWgt.destroy();
			this.textWgt = null;
		}
	};

	/**update balloon popup
	* @name update
	* @memberOf BallonPop	
	* @param {String} the new text for balloon popup
	* @param {int} the new x position for balloon popup	
	* @param {int} the new y position for balloon popup	
	* @method
	* @return {} 	 */	
	this.update = function( str, xPos, yPos ){
		if(this.bjImg == null){
			print('update failed, has not created');
			return;
		}

		if(str == undefined){
			print('update failed, str undefined');
			return;
		}

		this.text = str;

		this.width = this._getStrWidth(this.text, this.font) * 1.1;
		var tempX = xPos - this.width/2;
		var realX = 0;
		var offset = 0;

		if( tempX < 0 ){
			realX = 5;
			offset = tempX + 2;
		}
		else if( tempX + this.width > 1920 ){
			realX = 1920-this.width-2;	
		}
		else{
			realX = tempX;
		}

		var realY = this.bjImg.y;
		if( yPos != undefined ){
			realY = yPos - this.fontsize;
		}
		

		this.bjImg.x = realX,
		this.bjImg.y = realY,
		this.bjImg.width = this.width;

		this.arrow.x = xPos - this.width/2;
		if( yPos != undefined ){
			this.arrow.y = yPos + 5;
		}

		this.textWgt.x = realX,
		this.textWgt.y = realY,
		this.textWgt.width = this.width,
		this.textWgt.text = str;

		if( this.tOut!= null ){
			Volt.clearTimeout(this.tOut);
			this.tOut = null;
		}
		this.tOut =  Volt.setTimeout(this.timeOutFn, 3000);
		
		this.bjImg.show();	
		if( this.user != 'musicplayer' ){
			this.arrow.show();
		}
		this.textWgt.show();		
	};

	/**timeout function for balloon
	* @name timeOutFn
	* @memberOf BallonPop	
	* @method
	* @return {} 	 */		
	this.timeOutFn = function(){
		self.hide();
	};

	/**get a string's width
	* @name _getStrWidth
	* @memberOf BallonPop	
	* @param {String} the target string
	* @param {int} the fontsize of the text
	* @method
	* @return {int}
	**/	
	this._getStrWidth = function( str, fontSet ) {
		var wgt = new TextWidget(str);
		wgt.font = fontSet;
		wgt.horizontalAlignment = 'left';
		wgt.singleLineMode = true;

		var res = wgt.width;

		wgt.destroy();
		return res;
    };
	
}


exports = BalloonPop;
