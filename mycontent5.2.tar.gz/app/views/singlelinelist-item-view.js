 /** 
 * @author  Guan Hao (hao.guan@samsung.com)
 * 			
 * @fileoverview  Single list class
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

//ControlBase = require("UIElement/ControlBase");
var SinglelineListRenderBase = Volt.require('lib/custom-widgets/singleline-listrender-base.js');

var CommonInfo = Volt.require('app/common/define.js');
var colorList = CommonInfo.colorList;

var MycontentsShare = Volt.require('app/templates/1080/mycontents-share.js');
var homepanelInfo = MycontentsShare.homepanelInfo;

/* template */
var PanelCommon = Volt.require('lib/panel-common.js');
var MainTemplate = PanelCommon.requireTemplate('main');
var MyContentsMainTemplate = Volt.require('app/templates/1080/mycontents-main-template.js');

var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;

SinglelineListItemView = function(){
	this.t_create = function(obj)
	{
		
		this.ListItemWidget = loadTemplate(MyContentsMainTemplate.renderWidget);
		this.ListItemWidget.width = obj.width;
		this.ListItemWidget.height = obj.height;
		this.ListItemWidget.parent = obj.parent;
		this.ListItemWidget.color = CommonInfo.colorList.mPlusItemBGColor;
		
		this.downLineBar = loadTemplate(MyContentsMainTemplate.renderWidget);
		this.downLineBar.y = obj.height - 1;
		this.downLineBar.width = obj.width;
		this.downLineBar.height = 1;
		this.downLineBar.parent = this.ListItemWidget;
		this.downLineBar.color = {r:255, g:255, b:255, a:25};			

		this.upLineBar = loadTemplate(MyContentsMainTemplate.renderWidget);
		this.upLineBar.width = obj.width;
		this.upLineBar.height = 1;
		this.upLineBar.parent = this.ListItemWidget;
		this.upLineBar.color = {r:255, g:255, b:255, a:25};			

		this.ListIconWidget = loadTemplate(MyContentsMainTemplate.renderImageWidget);
		this.ListIconWidget.x = 12;
		this.ListIconWidget.y = (72-38)/2;
		this.ListIconWidget.parent = this.ListItemWidget;
		
		this.TitleWidget = loadTemplate(MyContentsMainTemplate.renderTextWidget);
		this.TitleWidget.x = 58;
		this.TitleWidget.width = obj.width;
		this.TitleWidget.height = obj.height;
		this.TitleWidget.parent = this.ListItemWidget;
		this.TitleWidget.textColor = {r:255, g:255, b:255, a:255 * 0.6};        
		this.TitleWidget.font = "Samsung SVD_Medium 26px";        
		this.TitleWidget.verticalAlignment = "center";

	}
	
	this.t_destroy = function(){
	
	
	};
	
	this.t_show = function()
	{
		this.ListItemWidget.show();		
	};

	this.t_hide = function()
	{
		this.ListIconWidget.hide();	
		this.ListItemWidget.hide();	
	};	
	
	this.t_getFocus = function()
	{
		this.downLineBar.height = 8;

		this.TitleWidget.textColor = {r:255, g:255, b:255, a:255};        
		this.TitleWidget.font = "Samsung SVD_Medium 28px";        
		this.TitleWidget.verticalAlignment = "center";
		
		this.ListItemWidget.border = {width:2, color:{r:255,g:255,b:255,a:255}};
		//this.ListItemWidget.show();	
		
	};
	
	this.t_loseFocus = function()
	{
		this.downLineBar.height = 1;

		this.TitleWidget.textColor = {r:255, g:255, b:255, a:255 * 0.6};        
		this.TitleWidget.font = "Samsung SVD_Medium 26px";        
		this.TitleWidget.verticalAlignment = "center";
		
		this.ListItemWidget.border = null;
	};	
		
	this.t_itemUpdate = function(itemData){	
		this.TitleWidget.text = itemData.text;
	}
}

SinglelineListItemView.prototype = new SinglelineListRenderBase();

exports = SinglelineListItemView;
