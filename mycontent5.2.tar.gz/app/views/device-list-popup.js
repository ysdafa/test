 /** 
 * @author  Xiaoming Chen (xiaom.chen@samsung.com)
 * 			
 * @fileoverview  Common popup view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Require = Volt.require;
var PanelCommon = Require('lib/panel-common.js');

//PanelCommon.mapWidgets(['ResizeableGrid']);
var CommonInfo = Volt.require('app/common/define.js');
var colorList = CommonInfo.colorList;
var EventType = CommonInfo.EventType;
var KeyCode = CommonInfo.KeyCode;
var PopupType = CommonInfo.PopupType;
var ProgressPopupType = CommonInfo.ProgressPopupType;
var BaseView = Volt.BaseView;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;

var MycontentsShare = Volt.require('app/templates/1080/mycontents-share.js');
var homepanelInfo = MycontentsShare.homepanelInfo;
//var SingleLineList = Volt.require('lib/custom-widgets/singleline-list.js');

/* template */
var DevPopupTemplate = Volt.require('app/templates/1080/device-list-template.js');
var DeviceProvider = Volt.require("app/models/device-provider.js");
var DeviceRender = Volt.require("app/views/device-list-render.js");
var ViewGlobalData = Volt.require("app/views/view-global-data.js");
var DeviceType = CommonInfo.DeviceType;
var voiceGuide = Volt.require('app/common/voice-guide.js');



//var self = null;
//define list item attribute
var nItemHeight = 330;
var nItemWidth = 300;

var DevMediator = new PanelCommon.Mediator;

var DevListView = PanelCommon.BaseView.extend({
    template : DevPopupTemplate.container,
	wParent: null,				//parent of popup widget
	wFocused: null,				//current focus widget
	itemNum: 0,
	totalSize: 0,
	timeOut: null,
	isToProgressPopup: false,
	focusDevId: null,
    render: function() {},
    initialize: function(){
    	DevMediator.mainView = this;
		DeviceProvider.regsiterListener(this,this.onDeviceConnect,this.onDeviceDisconnect);
		var focusDevice = DeviceProvider.getCurrentDevice();
		if(focusDevice != null){
			DevMediator.mainView.focusDevId = focusDevice.get('id');
		}
    },
	getWidget: function(){return this.widget;},
	setParent: function(Parent){
	    if(Parent != null){
			this.wParent = Parent;
	    }
		else{
			print('[device-list-popup.js]setParent parent is null');
		}
	},

	setSelectItemNum: function(nums){
		this.itemNum = nums;
	},

	setTotalSize: function(size){
		this.totalSize = size;
	},
	
	/**show device list pop up 	 
	* @name show	 
	* @memberOf DevListView
	* @method 	 
	* */	
    show : function(){
    
		var mustache = {
					title: resMgr.getText('TV_SID_SEND_TO_USB_DRIVE'),
					devDesc: resMgr.getText('COM_SID_CHOOSE_WHERE_SEND_THIS_FILE'),
					itemText: resMgr.getText('COM_TV_SID_SELECTED_ITEMS') + ' :',
					sizeText: resMgr.getText('TV_SID_TOTAL_SIZE') + ' :',
					upArrowImg: Volt.BASE_PATH + resMgr.getImgPath()+"/Arrow/popup_sublist_arrow_up_n.png",
					downArrowImg: Volt.BASE_PATH + resMgr.getImgPath()+"/Arrow/popup_sublist_arrow_down_n.png",
				};
		this.widget =  PanelCommon.loadTemplate(this.template,mustache,this.wParent);
		//this.setWidget(this.widget);
		//this.widget.parent = this.wParent;
		this.widget.getChild(6).hide();
		this.widget.getChild(7).hide();
		this.updateTextInfo();
		this.widget.show();
		
        this.renderDevList();	
		this.renderButton();
		 
		this.setWidget(this.widget);
		Volt.Nav.setRoot(this.widget);
		//DevMediator.buttonView.btn1.setFocus();			//set focus to list when popup shows
		//DevMediator.mainView.wFocused = DevMediator.buttonView.btn1;		//save current focus as list

		this.setDefaultFocus();
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);


		var txt = resMgr.getText('TV_SID_SEND_TO_USB_DRIVE')+','
			+ resMgr.getText('COM_SID_CHOOSE_WHERE_SEND_THIS_FILE')
			+ resMgr.getText('COM_TV_SID_SELECTED_ITEMS')+','+ this.itemNum.toString()+','
			+ this.getTotalSizeText(this.totalSize)+','
			+ resMgr.getText('COM_SID_CANCEL')+', '+resMgr.getText('TV_SID_BUTTON');
		voiceGuide.play(txt);
    },

	setDefaultFocus: function(){
		print('device-list-popup.js setDefaultFocus()!');
		DevMediator.buttonView.btn1.killFocus();
		DevMediator.contentView.gridlist.setFocus();
		DevMediator.contentView.gridlist.showFocus('false');
		DevMediator.mainView.wFocused = DevMediator.contentView.gridlist;
    },

	/**convert total size number to text 	 
	* @name getTotalSizeText	 
	* @memberOf DevListView
	* @method 	 
	* */	
	getTotalSizeText: function(){
		var size = 0;
		if(this.totalSize < 1024){
			size = this.totalSize.toString() + 'B';
		}
		else if((this.totalSize/(1024*1024)) < 1){
			var totalSize = this.totalSize/1024;
			totalSize = totalSize.toFixed(2);
			size = totalSize.toString() + 'KB';
		}
		else if((this.totalSize/(1024*1024*1024)) < 1){
			var totalSize = this.totalSize/(1024*1024);
			totalSize = totalSize.toFixed(2);
			size = totalSize.toString() + 'MB';
		}
		else{
			var totalSize = this.totalSize/(1024*1024*1024);
			totalSize = totalSize.toFixed(2);
			size = totalSize.toString() + 'GB';
		}
		return size;
    },

	/** Get interst device postion   	 
	* @name onDeviceConnect	 
	* @memberOf deviceListView
	* @param {type} Device type , USB/DLNA/RA/PTP
	* @method 	 
	* */
    onDeviceConnect: function(deviceInfo){
        print('[device-list-popup.js] onDeviceConnect :',deviceInfo );
       	print('---------------------------------tempCollect.length:', DeviceProvider.getUsbDeviceCount());
		if(deviceInfo.get('type') == DeviceType.DEVICE_TYPE_USB){
       		DevMediator.contentView.updateDeviceList();
		}
       	//DevMediator.mainView.undimHide();
    },

	/** Get interst device postion   	 
	* @name onDeviceDisconnect	 
	* @memberOf deviceListView
	* @param {type} Device type , USB/DLNA/RA/PTP
	* @method 	 
	* */
    onDeviceDisconnect: function(deviceID,deviceType){

   		print("[device-list-popup.js] Remove device id:",deviceID, 'deviceType :',deviceType);
	    print('onDeviceDisconnect  length:', DeviceProvider.getUsbDeviceCount());
		if(deviceType == DeviceType.DEVICE_TYPE_USB){
			if(DevMediator.mainView.focusDevId == deviceID){
				DevMediator.mainView.isToProgressPopup = false;
				DevMediator.mainView.hide();
				EventMediator.trigger(EventType.EVENT_TYPE_ON_ACTIVE_DELE_DEVICE); //category change
			}
			else{
				DevMediator.contentView.updateDeviceList();
			}
		}
		//DevMediator.mainView.undimHide();
    },

	/**update device popup text info	 
	* @name updateTextInfo	 
	* @memberOf DevListView
	* @method 	 
	* */	
	updateTextInfo: function(){
		if(this.widget == null){
			return;
		}
		var text = this.widget.getChild('selected-items-id').text;
		text = text + ' ' + this.itemNum.toString();
		this.widget.getChild('selected-items-id').text = text;

		var sizeText = this.widget.getChild('total-size-id').text;
		//sizeText = sizeText + this.totalSize.toString();
		sizeText = sizeText + ' ' + this.getTotalSizeText();
		this.widget.getChild('total-size-id').text = sizeText;
    },

	/**render device list	 
	* @name renderDevList	 
	* @memberOf DevListView
	* @method 	 
	* */	
    renderDevList : function(){
        print('[device-list-popup.js] renderContent');
        new deviceListView().render(this.widget)
    },

	/**render device button	 
	* @name renderButton	 
	* @memberOf DevListView
	* @method 	 
	* */	
    renderButton : function(){
    	print('[device-list-popup.js] renderButton');
        var container = PanelCommon.loadTemplate(DevPopupTemplate.button);
		//this.widget.addChild(container);
		container.parent = this.widget;
		new buttonView().render(container);
    },

	/**hide device popup	 
	* @name hide	 
	* @memberOf DevListView
	* @method 	 
	* */	
    hide : function(){
    	print('[device-list-popup.js] hide');
		if(this.widget == null){
			return;
		}
		DeviceProvider.unregsiterListener(this,this.onDeviceConnect,this.onDeviceDisconnect);
        this.widget.hide();
		
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		this.timeOut = Volt.setTimeout(this.destroy, 1);
    },

	undimHide: function(){
		print('[device-list-popup.js] undimHide');
		DeviceProvider.unregsiterListener(this,this.onDeviceConnect,this.onDeviceDisconnect);
        this.widget.hide();
		if(this.timeOut != null){
			Volt.clearTimeout(this.timeOut);
		}
		DevMediator.mainView.widget.destroy();
		var mainView = Volt.require('app/views/main-view.js');
		mainView.devPopup = null;
		DevMediator.mainView = null;
    },
	/**destroy device popup	 
	* @name destroy	 
	* @memberOf DevListView
	* @method 	 
	* */	
	destroy : function(){
		print('------destroy()');
		if(this.timeOut != null){
			Volt.clearTimeout(this.timeOut);
		}
		DeviceProvider.unregsiterListener(this,this.onDeviceConnect,this.onDeviceDisconnect);
		DevMediator.mainView.widget.destroy();
		var mainView = Volt.require('app/views/main-view.js');
		mainView.devPopup = null;
		
		print('------1111111111111112destroy() isToProgressPopup = ', DevMediator.mainView.isToProgressPopup);
		if(DevMediator.mainView.isToProgressPopup == false){
			//Volt.Nav.setRoot(mainView.widget);    //when device popup destroy,set root widget to main view
			mainView.setRoot();
		}
		DevMediator.mainView = null;
	},

	/**the callback for remote key press
	* @name onKeyEvent	 
	* @memberOf MusicPlayerView	 
	* @param {keyCode} key number	
	* @param {type} key event type		
	* @method 	 */		
	onKeyEvent:function(keyCode, type){
		print('-----------------[device-list-popup.js] onKeyEvent()type = ',type);
		var ret = false;
		if(type != Volt.EVENT_KEY_RELEASE) {
		    return true;
		}
		switch(keyCode) {
			case Volt.KEY_RETURN:
			{
				print('onKeyEvent()1111111111111111111');
				this.hide();
			}
			break;
			
			case Volt.KEY_JOYSTICK_OK:
			{
				if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
				{
					print('[device-list-popup.js] KEY_JOYSTICK_OK, idx = ',DevMediator.contentView.gridlist.focusItemIndex );
					DevMediator.contentView.ifItemPress(DevMediator.contentView.gridlist.focusItemIndex);
				}
			}
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				print('[list-thumbnail-popup.js] __onKeyEvent keycode = Volt.KEY_JOYSTICK_LEFT');
				if(HALOUtil.getOrientation() == "right-to-left"){
					if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
					{
						DevMediator.contentView.gridlist.hideFocus('false');
						DevMediator.contentView.gridlist.killFocus();
						DevMediator.buttonView.btn1.setFocus();			//set focus to list when popup shows
						//DevMediator.buttonView.btn1.m_UpdateState();
						DevMediator.mainView.wFocused = DevMediator.buttonView.btn1;
					}
				}
				else{
					if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
					{
	//					ret = DevMediator.contentView.gridlist.onKeyEvent(KeyCode,type);
						break;
					}
					else if(DevMediator.mainView.wFocused == DevMediator.buttonView.btn1)
					{
						print('[list-thumbnail-popup.js] __onKeyEvent DevMediator.buttonView.btn1');
						if(DevMediator.contentView.gridlist != null){
							DevMediator.buttonView.btn1.killFocus();
							//DevMediator.buttonView.btn1.m_UpdateState();
							DevMediator.contentView.gridlist.setFocus();
							DevMediator.contentView.gridlist.showFocus('false');
							DevMediator.mainView.wFocused = DevMediator.contentView.gridlist;
							ret = true;
						}
					}
				}
				break;
			case Volt.KEY_JOYSTICK_RIGHT:
				print('[list-thumbnail-popup.js] __onKeyEvent keycode = Volt.KEY_JOYSTICK_RIGHT');
				if(HALOUtil.getOrientation() == "right-to-left"){
					if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
					{
	//					ret = DevMediator.contentView.gridlist.onKeyEvent(KeyCode,type);
						break;
					}
					else if(DevMediator.mainView.wFocused == DevMediator.buttonView.btn1)
					{
						print('[list-thumbnail-popup.js] __onKeyEvent DevMediator.buttonView.btn1');
						if(DevMediator.contentView.gridlist != null){
							DevMediator.buttonView.btn1.killFocus();
							//DevMediator.buttonView.btn1.m_UpdateState();
							DevMediator.contentView.gridlist.setFocus();
							DevMediator.contentView.gridlist.showFocus('false');
							DevMediator.mainView.wFocused = DevMediator.contentView.gridlist;
							ret = true;
						}
					}
				}
				else{	
					if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
					{
						DevMediator.contentView.gridlist.hideFocus('false');
						DevMediator.contentView.gridlist.killFocus();
						DevMediator.buttonView.btn1.setFocus();			//set focus to list when popup shows
						//DevMediator.buttonView.btn1.m_UpdateState();
						DevMediator.mainView.wFocused = DevMediator.buttonView.btn1;
					}
				}
				break;
			/*
			case Volt.KEY_JOYSTICK_UP:
			case Volt.KEY_JOYSTICK_DOWN:
				{
					if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist){
						ret = DevMediator.contentView.gridlist.onKeyEvent(KeyCode,type);
					}
				}
				break;*/
			default:
				break;
		}
		return true;
	}
});

var CELL_ID = "CellId";
//template of content area
var deviceListView = PanelCommon.BaseView.extend({
	gridlist : null,
	defCont: null,
	arrItems: [],
	devDataIndex: [],
	parent: null,
	avialSizeText: '',
	upArrowImg: null,
	downArrowImg: null,
	deviceListWgt:null,
	listWidget:null,
	/**init device list view	 
	* @name initialize	 
	* @memberOf deviceListView
	* @method 	 
	* */	
	initialize: function(){
		print('[device-list-popup.js]initialize device list popup');
		self = this;
		self.devDataIndex.splice(0,self.devDataIndex.length);
		self.arrItems.splice(0,self.arrItems.length);
		self.upArrowImg = DevMediator.mainView.widget.getChild(6);
		self.downArrowImg = DevMediator.mainView.widget.getChild(7);
	},

	getFocusDevSizeText: function(index){
		var item = DeviceProvider.getDeviceByIndex(self.devDataIndex[index]);
		if(item != null){
			var availSize = item.get('availableSize');
			self.avialSizeText = self.convertSizeToText(availSize);
		}
		return self.avialSizeText;
	},

	createRendererProvider: function(){
		print('device-list-popup.js createRendererProvider()');
		var rendererProvider = new RendererProvider;
		rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data)
		{
			print('device-list-popup.js funcGetRenderer() data:',data);
			var render = new DeviceRender();
			return render.getRender(parentWidth, parentHeight, data);
		};
		return rendererProvider;
	},		

	/**drow grid list
	* @name renderGridList	 
	* @memberOf deviceListView
	* @method 	 
	* */	
	renderGridList: function(){
		print('device-list-pupup renderGridList()');
		if(DevMediator.contentView.gridlist == null){
			
    		DevMediator.contentView.gridlist = PanelCommon.loadTemplate(DevPopupTemplate.list);
			DevMediator.contentView.parent.addChild(DevMediator.contentView.gridlist);
		}
 		//self.listWidget = this.widget.getChild('deviceList');
			
		DevMediator.contentView.gridlist.shadowEffectFlag = false;
		var renderpro = this.createRendererProvider();
		if(renderpro != null){
			DevMediator.contentView.gridlist.setRendererProvider(renderpro);
		}
		else{
			print('renderGridList renderpro is NULL!!!!!!');
			return;
		}

		print('renderGridList count = ',DeviceProvider.getUsbDeviceCount());
		//if(DeviceProvider.getUsbDeviceCount()<=1){
			//if(DevMediator.mainView != null){
				//DevMediator.mainView.hide();
			//}
			//return;
		//}
		DevMediator.contentView.gridlist.addItem({itemNum: DeviceProvider.getUsbDeviceCount()-1, itemSpace: 72});
//		this.addData();	
		self.makeDevDataIndex();

//		this.gridlist.enlargeFocusedItem(0, 4);
		this.gridlist.loadData();
//		this.gridlist.showFocus('true');
		this.gridlist.show();
		this.gridlist.setAnimationDuration("focusMove", 150);
		this.initListener();

		this.gridlist.focusItemIndex = 0;		

		if((DeviceProvider.getUsbDeviceCount()-1) > 4){
			print('device count is more than 4!');
			self.downArrowImg.show();
			self.upArrowImg.hide();
		}
	},

	initListener : function(){
		this.listListener = new SingleLineListControlListener;

		this.listListener.onItemLoaded = function(singleLineList, itemIndex){
			print('device-list-popup.js onItemLoaded()itemIndex = ',itemIndex);
			var data = singleLineList.getData(itemIndex);
			if( data == null ){
				print('data == null for index = ', itemIndex);
				return;
			}
		};		
		this.listListener.onItemUnloaded = function(singleLineList, itemIndex){
			print('device-list-popup.js onItemUnloaded()itemIndex = ',itemIndex);
			if(itemIndex == 0){
				self.downArrowImg.hide();
				self.upArrowImg.show();
			}
			else{
				self.downArrowImg.show();
				self.upArrowImg.hide();
			}
		};

		this.listListener.onFocusChanged = function(singleLineList, fromItemIndex, toItemIndex){
			print('self.listListener.onFocusChanged fromItemIndex:'+fromItemIndex+' toItemIndex:'+toItemIndex);
			/*
			var txt = '';
			var data = self.listWidget.getData(toItemIndex);
			var avaliableSpace = data.space;
			var index = avaliableSpace.lastIndexOf('/');
			avaliableSpace = avaliableSpace.substring(0,index);
				
			txt = data.displayName+ ',' + avaliableSpace + ',' + resMgr.getText('COM_AVAILABLE');
			
			voiceGuide.play(txt);
			*/
		};
		
		this.listListener.StartFocusChange = function(singleLineList, fromItemIndex, toItemIndex){
			print('self.listListener.StartFocusChange');
		};
		
		this.listListener.MoveOut = function(singleLineList, directionString, fromItemIndex){
			if ("Up" == directionString)    {
			}    
			else if ("Down" == directionString)    {
			}    
			else if ("Left" == directionString)    {
			}    
			else if ("Right" == directionString)    {
		}};

		this.listListener.onItemClicked = function(singleLineList, itemIndex){
			print('self.listListener.onItemClicked, itemIndex=', itemIndex);
			DevMediator.contentView.ifItemPress(itemIndex);
		};
		this.gridlist.addListListener(self.listListener);
	},
	
    render : function(Parent){
		DevMediator.contentView = this;
    	this.parent = Parent;
		self.renderGridList();
        return this;
    },

	/**get device total size and available size text
	* @name getDeviceSizeText	 
	* @memberOf deviceListView
	* @method 	 
	* */	
	getDeviceSizeText: function(availSize, totalSize){
		print('getDeviceSizeText availSize = ',availSize);
		print('getDeviceSizeText totalSize = ',totalSize);
		var sizeText = '';
		var availSizeText = self.convertSizeToText(availSize);
		var totalSizeText = self.convertSizeToText(totalSize);
		sizeText = availSizeText+' '+'/'+' '+totalSizeText;
		return sizeText;
    },

	/**update device list
	* @name updateDeviceList	 
	* @memberOf deviceListView
	* @method 	 
	* */	
	updateDeviceList: function(){
		print('[device-list-popup.js]----updateDeviceList()');
		if(DevMediator.contentView.gridlist != null){
			print('[device-list-popup.js]----1111111111111111111updateDeviceList()');
			DevMediator.contentView.gridlist.killFocus();
			DevMediator.buttonView.btn1.setFocus();			//set focus to list when popup shows
			DevMediator.mainView.wFocused = DevMediator.buttonView.btn1;
			DevMediator.contentView.gridlist.hide();
			DevMediator.contentView.gridlist.destroy();
			DevMediator.contentView.gridlist = null;
		}

		if(DevMediator.contentView.defCont != null){
			DevMediator.contentView.defCont.hide();
			DevMediator.contentView.defCont.destroy();
			DevMediator.contentView.defCont = null;
		}
		
		if(DeviceProvider.getUsbDeviceCount()<=1){
			self.defCont = PanelCommon.loadTemplate(DevPopupTemplate.defContent);
			self.parent.addChild(self.defCont);
			DevMediator.buttonView.btn1.setFocus();			//set focus to list when popup shows
			DevMediator.mainView.wFocused = DevMediator.buttonView.btn1;
		}
		else{
			print('[device-list-popup.js]----22222222222222222222222222222updateDeviceList()');
			self.devDataIndex.splice(0,self.devDataIndex.length);
			self.arrItems.splice(0,self.arrItems.length);
			DevMediator.contentView.renderGridList();
			Volt.Nav.reload();
			DevMediator.mainView.setDefaultFocus();
			//Volt.Nav.reload();
		}
    },

	/**convert number size to text
	* @name convertSizeToText	 
	* @memberOf deviceListView
	* @method 	 
	* */	
	convertSizeToText: function(size){
		var textSize = '';
		if(size < 1024){
			textSize = size.toString() + 'KB';
		}
		else if((size/(1024*1024)) < 1){
			var totalSize = size/1024;
			totalSize = totalSize.toFixed(2);
			textSize = totalSize.toString() + 'MB';
		}
		else if((size/(1024*1024*1024)) < 1){
			var totalSize = size/(1024*1024);
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'GB';
		}
		else{
			var totalSize = size/(1024*1024*1024);
			totalSize = totalSize.toFixed(0);
			textSize = totalSize.toString() + 'TB';
		}
		return textSize;
    },

	/**make list date source
	* @name makeDevDataIndex	 
	* @memberOf deviceListView
	* @method 	 
	* */
	makeDevDataIndex: function(){
		for (var j = 0; j < DeviceProvider.getDeviceCount(); j++) {
            var item = DeviceProvider.getDeviceByIndex(j);
			if(item != null){
				if(item.get('type') == DeviceType.DEVICE_TYPE_USB){
					var focusDevice = DeviceProvider.getCurrentDevice();
					var focusDevId = focusDevice.get('id');
					
					print('[device-list-popup.js]makeDevDataIndex,focusDevId = ',focusDevId);
					print('[device-list-popup.js]makeDevDataIndex,get id = ',item.get('id'));
					if(item.get('id') != focusDevId){
						print('[device-list-popup.js]ifItemLoaded,push index = ',j);
						self.devDataIndex.push(j);
						var data = new Data();
						data.imgUrl = resMgr.getImgPath()+"/mc_icon_usb.png";
						data.displayName = item.get('displayName');
						data.space = self.getDeviceSizeText(item.get('availableSize'),item.get('totalSize'));
						this.gridlist.addData(data);
						self.arrItems.push(data);
					}
				}
			}
			else{
				print('makeDevDataIndex item is null index = ',j);
			}
        }
    },

	/**send select files to select devcie
	* @name devSend	 
	* @memberOf deviceListView
	* @parmater{index} select device index
	* @method 	 
	* */
	devSend: function(index){
		print('[device-list-popup.js] index = ',index);
	//	var devInfo = RunTimeInfo.router.mainView.lastFocusDevInfo;
		var devInfo = DeviceProvider.getCurrentDevice();
		if(devInfo != null && devInfo.get('type') != DeviceType.DEVICE_TYPE_USB){
			print('device-list-popup.js source device type is not USB!');
			return false;
		}
		RunTimeInfo.router.currentView.setSelectItemToCsf();
		if(RunTimeInfo.router.currentView.collection.getRequestAgent() == ''){
			print('[device-list-popup.js] Csf agent is null');
			return false;
		}
		var param = {
				param_agent: RunTimeInfo.router.currentView.collection.getRequestAgent(),
				param_share_type: 0x02,
				param_source_device_type: 2,
				param_dest_device_type: 2,
				param_dest_device_path: '',
				param_user_data_addr: 0,
			};
		print('devSend index = ',self.devDataIndex[index]);
		var item = DeviceProvider.getDeviceByIndex(self.devDataIndex[index]);
		if(item == null){
			print('[device-list-popup.js]ifItemLoaded,item is null!! index = ',index);
		}
		else{
			param.param_dest_device_path = item.get('mountPath');
			print('[device-list-popup.js]devSend() devicePath = ',param.param_dest_device_path);
		}

		var navigatParam = {
				param_agent: RunTimeInfo.router.currentView.collection.getRequestAgent(),
				param_navigation: 1,
			};

		var CsfMgr = Volt.require('app/models/csf-manager.js');
		CsfMgr.setNavigation(navigatParam);    //before send,set navigation
		var ret = CsfMgr.send(param);
		//navigatParam.param_navigation = 0;
		//CsfMgr.setNavigation(navigatParam);    //after call send,reset navigation
		print('[device-list-popup.js] ret = ',ret);
		/*
		if(DeviceProvider.collection.csfMgr != null){
			var ret = DeviceProvider.collection.csfMgr.send(param);
			print('[device-list-popup.js] ret = ',ret);
		}*/
    },

	checkDevStorgaeFull: function(index){
		print('[device-list-popup.js] checkDevStorgaeFull()');
		var status = false;
		var item = DeviceProvider.getDeviceByIndex(self.devDataIndex[index]);
		var availSize = item.get('availableSize')*1024;
		var capSize = item.get('totalSize')*1024;
		//var totalSize = availSize + DevMediator.mainView.totalSize;
		var selSize = DevMediator.mainView.totalSize;
		print('checkDevStorgaeFull() availSize = ',availSize);
		print('checkDevStorgaeFull() capSize = ',capSize);
		print('checkDevStorgaeFull() selectSize = ',DevMediator.mainView.totalSize);
		Log.e("checkDevStorgaeFull() availSize = " + availSize);
		Log.e("checkDevStorgaeFull() capSize = " + capSize);
		Log.e("checkDevStorgaeFull() selectSize = " + DevMediator.mainView.totalSize);
		if(selSize >= availSize){
			status = true;
		}
		else{
			status = false;
		}
		return status;
	},

	/**process list item press
	* @name ifItemPress	 
	* @memberOf deviceListView
	* @parmater{index} select device index
	* @parmater{widget} select device widget
	* @method 	 
	* */
	ifItemPress : function(index, widget,id){
		print('[device-list-popup.js] ifItemPress()');
		var ret = self.checkDevStorgaeFull(index);
		if(ret == true){
			print('checkDevStorgaeFull() storage is full!');
			DevMediator.mainView.undimHide();
			var sizeText = self.getFocusDevSizeText(index);
			var mainView = Volt.require('app/views/main-view.js');
			mainView.showStorageFullMsgBox(sizeText);
			return;
		}
		var ret = self.devSend(index);
		if(ret == false){
			print('device-list-popup.js copy to USB failed!');
			return;
		}
		DevMediator.mainView.isToProgressPopup = true;
		DevMediator.mainView.hide();
		//Volt.Nav.endModal(DevMediator.mainView.widget);
		//DevMediator.mainView.destroy(DevMediator.mainView.widget);
		EventMediator.trigger(EventType.EVENT_TYPE_EXIT_EDIT_MODE_VIEW);
		print('111111111111111device-list-popup.js device index = ',self.devDataIndex[index]);
		var item = DeviceProvider.getDeviceByIndex(self.devDataIndex[index]);
		var mainView = Volt.require('app/views/main-view.js');
		mainView.showProgressPopup(ProgressPopupType.eTwoProgrePopup,item);
		Volt.KPIMapper.addEventLog('MY_OPTION_SENDUSB');
		
    },

	buildItem: function(index, width, height, id, item){
		print('buildItem device index = ',self.devDataIndex[index]);
		//var devItem = DeviceProvider.getDeviceByIndex(self.devDataIndex[index]);
		var devSizeText = self.getDeviceSizeText(item.get('availableSize'),item.get('totalSize'));
		print('----createDeviceItem devSizeText = ',devSizeText);
	    var mustache = {
	        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/mc_icon_usb.png",
	        title1: item.get('displayName'),
	        devSize: devSizeText,
	    };
		print('----createDeviceItem index = ',index);
		
		
		var widget = this.gridlist.getReuseableWidget(CELL_ID);
		if (widget === undefined){
	           widget = new WidgetEx({
	                    x:0,
	                    y:0,
	                    width:width,
	                    height:height,
	                    color : Volt.hexToRgb('#ffffff',0),
	           });
		}
		this.gridlist.normalizeWidget(widget, CELL_ID);
		
		loadTemplate(DevPopupTemplate.devListItem, mustache, widget);
		
		return widget;
	},
	
});

//template of button area
var buttonView = PanelCommon.BaseView.extend({
	btn1:null,
    render : function(button){
    	print('[device-list-popup.js] render() button');
    	DevMediator.buttonView = this;
		this.btn1 = button;
	//	this.btn1.setText({state: "all", text: Volt.LANG.COM_SID_CANCEL,});
		this.btn1.setText({state: "all", text: resMgr.getText('COM_SID_CANCEL'),});
		this.btn1.setTextColor({state: "all", color: { r:255, g:255, b:255 },});
		this.btn1.setFontSize({state: "normal", size: 32,});
		this.btn1.setFontSize({state: "focused", size: 36,});
		this.btn1.setFontSize({state: "focused-roll-over", size: 36,});
		this.btn1.setBackgroundColor({state: "all", color: { r:255, g:255, b:255, a: 0 },});
		this.btn1.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
		this.btn1.setBorder({state: "focused-roll-over",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
		this.btn1.setBorder({state: "normal",border: {width:1, color: {r:0xff,g:0xff,b:0xff,a:255}}});
		/*
		this.btn1.setBackgroundImage({state: "focused",
									  src: resMgr.getImgPath()+'/button/btn_style_c_f.png',});
	    this.btn1.setBackgroundImage({state: "normal", 
									  src: resMgr.getImgPath()+'/button/btn_style_c_n.png',});*/
		this.btn1.show();
		
		var buttonListener = new ButtonListener;
		this.btn1.addListener(buttonListener);
		buttonListener.onButtonClicked = function (button, type){
			print('----buttonListener type = ',type);
			DevMediator.mainView.isToProgressPopup = false;
			DevMediator.mainView.hide();
		};
		return this;
    },
    btnCallBack: function(){
    	DevMediator.mainView.hide();
    },
});



/**init button
* @name __initButton	 
* @memberOf global fuction
* @parmater{param} button parmaters
* @method 	 
* */
function __initButton(param){
	print('[device-list-view.js]__initButton()');
	var sampleButton = new Button({x:param.x, y:param.y, width:param.width, height:param.height, parent: param.parent});
	
	sampleButton.setText({state: "all", text: resMgr.getText('COM_SID_CANCEL'),});
	sampleButton.setTextColor({state: "all", color: { r:255, g:255, b:255 },});
	sampleButton.setFontSize({state: "normal", size: 32,});
	sampleButton.setFontSize({state: "focused", size: 36,});
	sampleButton.setBackgroundColor({state: "all", color: { r:255, g:255, b:255, a: 0 },});
	
	sampleButton.setBackgroundImage({state: "focused",
								       src: resMgr.getImgPath()+'/button/btn_style_c_f.png',
					});
    sampleButton.setBackgroundImage({state: "normal", 
								       src: resMgr.getImgPath()+'/button/btn_style_c_n.png',
					});
	sampleButton.show();
	
	return sampleButton;
}


/**process key event
* @name __onKeyEvent	 
* @memberOf global fuction
* @parmater{KeyCode} key value
* @parmater{type} key type
* @method 	 
* */
function __onKeyEvent(KeyCode,type){
    print('[device-list-popup.js]__onKeyEvent()');
	if (type == Volt.EVENT_KEY_RELEASE)
	{
		//return false;
	}
	var ret = false;
	switch(KeyCode) {
		case Volt.KEY_RETURN:
		{
			DevMediator.mainView.hide();
		}
			break;
		case Volt.KEY_JOYSTICK_OK:
		{
			if(DevMediator.mainView.wFocused == DevMediator.buttonView.btn1)
			{
				print('[device-list-popup.js] buttonView KEY_JOYSTICK_OK');
				//ret = DevMediator.buttonView.btn1.keyHandler(KeyCode,type);
			}
			else if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
			{
				print('[device-list-popup.js] KEY_JOYSTICK_OK');
				ret = DevMediator.contentView.gridlist.onKeyEvent(KeyCode,type);
			}
		}
			break;
		case Volt.KEY_JOYSTICK_LEFT:
			print('[list-thumbnail-popup.js] __onKeyEvent keycode = Volt.KEY_JOYSTICK_LEFT');
			if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
			{
				ret = DevMediator.contentView.gridlist.onKeyEvent(KeyCode,type);
			}
			else if(DevMediator.mainView.wFocused == DevMediator.buttonView.btn1)
			{
				DevMediator.buttonView.btn1.killFocus();
				//DevMediator.buttonView.btn1.m_UpdateState();
				DevMediator.contentView.gridlist.setFocus();
				DevMediator.mainView.wFocused = DevMediator.contentView.gridlist;
				ret = true;
			}
			break;
		case Volt.KEY_JOYSTICK_RIGHT:
			print('[list-thumbnail-popup.js] __onKeyEvent keycode = Volt.KEY_JOYSTICK_RIGHT');
			if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist)
			{
				var index = DevMediator.contentView.gridlist.getFocusIndex();
				var focusWidget = self.gridlist.getWidget(index);
				if(focusWidget !== undefined ){
					focusWidget.getChild(1).opacity = 255*0.6;
					focusWidget.getChild(2).opacity = 255*0.6;
					focusWidget.getChild(4).opacity = 0;
					focusWidget.getChild(5).opacity = 0;
					focusWidget.getChild(6).opacity = 0;
					focusWidget.getChild(7).opacity = 0;
	   			}
				DevMediator.contentView.gridlist.killFocus();
				DevMediator.buttonView.btn1.setFocus();			//set focus to list when popup shows
				//DevMediator.buttonView.btn1.m_UpdateState();
				DevMediator.mainView.wFocused = DevMediator.buttonView.btn1;
			}
			break;
		case Volt.KEY_JOYSTICK_UP:
		case Volt.KEY_JOYSTICK_DOWN:
			{
				if(DevMediator.mainView.wFocused == DevMediator.contentView.gridlist){
					ret = DevMediator.contentView.gridlist.onKeyEvent(KeyCode,type);
				}
			}
			break;
		default:
			break;
	}
	return ret;
}



exports = DevListView;

