/** 
 * @author  He Wenge (wenge.he@samsung.com)
 * 			
 * @fileoverview  Photo view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var resMgr = Volt.require('app/controller/resource-controller.js');
	var BaseModel = Volt.require("app/models/base-model.js");
	var PhotoModel = Volt.require("app/models/photo-model.js");

	var ContentViewBase = Volt.require("app/views/content-view-base.js");
	var CommonInfo = Volt.require("app/common/define.js");
	var EItemType = CommonInfo.EItemType;
    var EViewType = CommonInfo.EViewType;
	var OptionText = Volt.require("app/common/option-text.js");
	var VideoSortByTextList = OptionText.VideoSortByTextList;
	
	var PhotoContentViewTemplate = Volt.require('app/templates/1080/photo-view-template.js');
    var RunTimeInfo = Volt.require("app/common/run-time-info.js");
	var PanelCommon = Volt.require('lib/panel-common.js');
	var loadTemplate = PanelCommon.loadTemplate;
	var ViewGlobalData = Volt.require("app/views/view-global-data.js");
	var EventMediator = RunTimeInfo.EventMediator;
	var EventType = CommonInfo.EventType;
	var nativeGridlistFocus = CommonInfo.nativeGridlistFocus;
	var CONST = CommonInfo.CONST;
	var Render_View = Volt.require("app/views/render-view.js");
	var Thumbnail_View = Volt.require("app/views/thumbnail-view.js");
	var DeviceType = CommonInfo.DeviceType;
	var CategoryName = CommonInfo.CategoryName;
	var SortType = CommonInfo.SortType;
	var self = null;
	var PhotoContentView = ContentViewBase.extend({
		listItemNum : 18,
        arrItems : [],
        template: PhotoContentViewTemplate.container,
        templateList: PhotoContentViewTemplate.list,
        focusWidget: null,
        params: {},
		events: {
	        'NAV_FOCUS':'onFocus',
	        'NAV_BLUR':'onBlur'
	    },
		/** Render
		* @name render	 
		* @memberOf PhotoContentView
		* @method 	 
		* */	
		render : function(){
			self = this;
			return this;
		},

		/** OnFocus
		* @name onFocus	 
		* @memberOf PhotoContentView
		* @param {widget} current get focus widget
		* @method 	 
		* */	
		onFocus: function(widget) {
	        print('photo-content-view.js onFocus');
			Log.e("photo-content-view.js onFocus");
			if(this.nativeGridList != null){
				EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
				this.nativeGridList.enableFocus();
				//this.nativeGridList.setFocus();
							    this.nativeGridList.showFocus('false');
			    this.nativeGridList.setFocusImage(resMgr.getImgPath()+'/common/ksc_focus.png', -8, -8);

				this.nativeGridList.showFocus("true");
				ViewGlobalData.isGridListFocus = true;
			}

	    },

		/** OnBlur
		* @name onBlur	 
		* @memberOf PhotoContentView
		* @param {widget} current lose focus widget
		* @method 	 
		* */	
	    onBlur: function(widget) {
	        print('photo-content-view.js onBlur');
			Log.e("photo-content-view.js onBlur");
	        if( this.nativeGridList != null ){
				this.nativeGridList.hideFocus("true");
				ViewGlobalData.isGridListFocus = false;
	        }
	    },
		/** Make Data Source
		* @name makeDataSource	 
		* @memberOf PhotoContentView
		* @param {devPath} scan path
		* @method 	 
		* */	
		makeDataSource : function(devPath){
			for(var index=0; index<VideoSortByTextList.DeviceTypeTextList.length; index++){
				if(resMgr.getText(VideoSortByTextList.DeviceTypeTextList[index]) == ViewGlobalData.viewSortText[EViewType.ePhotoContentView]){
				  RunTimeInfo.router.mainView.headerView.optionParam.secondSelectedIndex[1] = index;
				}
			}

			if(ViewGlobalData.parentFielPathStack.length != 0 ){
		        devPath = ViewGlobalData.currFilePath;
			}
			else{
				ViewGlobalData.rootPath = devPath;
			}

		    this.collection.setRootGroup(ViewGlobalData.isRootGroup);
			this.collection.setGroupIndex(ViewGlobalData.GroupIndex);
			
			//var sortType = ViewGlobalData.viewSortText[EViewType.ePhotoContentView];
			var sortType = this.mainView.headerView.filterView.currentViewSortText;
			print("photo setGlobalSort sortType:"+sortType);
			switch(sortType){
				case resMgr.getText(SortType.SORT_TYPE_TITLE):
					sortType = 'CATEGORY-TITLE';
					break;

				case resMgr.getText(SortType.SORT_TYPE_DATE):
					sortType = 'CATEGORY-DATE';
					break;

				case resMgr.getText(SortType.SORT_TYPE_FOLDER):
					sortType = 'CATEGORY-FOLDER';
					break;
					 
				default:
					sortType = 'CATEGORY-TITLE';
					break;
			}
			print('test csf emp');
			print("sortType"+sortType);
			var contentType = 'CONTENT-IMAGE';

			if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB){
				this.requestUsbDataList(devPath, contentType, sortType);
			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA){
				this.requestDlnaDataList(contentType,sortType);
			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_PTP){
				this.requestPTPDataList(contentType,sortType);
			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_RA)
			{
				this.requestRaDataList(contentType, sortType);
			}
			
		},
		
	
		/** Update Widget
		* @name updateWidget	 
		* @memberOf PhotoContentView
		* @param {int} index 
		* @param {Object} data item
		* @param {Object} parent widget
		* @method 	 
		* */
		updateWidget : function(index, item, widget){	
		    if(item.get('ItemType') == EItemType.eItemFolder ||
			   item.get('ItemType') == EItemType.eItemGroup){
			   
				if(widget.getChild(1)!= null){
					widget.getChild(1).getUIElement().setTextContent({text: item.get('title1'),textHorizontalAlignment:'center'});					
				}
			}
		    else{
				if((widget.getChild(1)!= null) && (widget.getChild(2).getChild(0)!= null)){
					widget.getChild(1).getChild(0).getUIElement().setTextContent({text: item.get('title1')});
				}
		    }
		},

		/** Get Sort By Text
		* @name getSortByText	 
		* @memberOf PhotoContentView
		* @method 	 
		* */	
		getSortByText : function(){
		    var Text;
			/*the true text please refer the gui of content*/
		 
			Text = self.getResourceText(VideoSortByTextList.DeviceTypeTextList);
			if( this.mainView.headerView.filterView.optionMenuSubIndex[1] > (Text.length-1) ){
				this.mainView.headerView.filterView.optionMenuSubIndex[1] = Text.length-1;
			}
			
			return Text;
	    },

		/** Get Second Option Text
		* @name getSecondOptionText	 
		* @memberOf PhotoContentView
		* @param {nListIndex} select option index
		* @method 	 
		* */	
		getSecondOptionText : function(nListIndex){
			var Text;
			print('getSecondOptionText'+nListIndex);
			switch(nListIndex){
				/*Filter*/
				case 0:
					Text = self.getFilterText();
					break;

				case 1:
					Text = self.getSortByText();
					break;

				default:
					break;
			}
			return Text;
		},

		getFilterOption: function(){
			//return 'Filter by Photos';
			return resMgr.getText('COM_SID_FILTER_BY') + ' ' + resMgr.getText('COM_SID_PHOTOS'); 
		},

		/** updateRender
		* @name updateRender 
		* @memberOf PhotoContentView
		* @method 	 
		* */
		updateRender : function( data, renderer){
			print("photo-content-base.js updateRender");
			if( data.ItemType == EItemType.eItemFolder || data.ItemType == EItemType.eItemGroup ){
				updateFolderItemThumbnail( data, renderer);
			}
		    else if( data.ItemType == EItemType.eItemUpFolder ){
				updateUpfolderItemThumbnail( data, renderer);
		    }
			else{
				updateFileItemThumbnail( data, renderer);
			}
		},
		
	});

	/** Create List
	* @name t_CreateList	 
	* @memberOf PhotoContentView
	* @method 	 
	* */
	PhotoContentView.prototype.t_CreateList = function() {
		//folder coordinate
		self.params.renderWidth = PhotoContentViewTemplate.listItemFolder[0].width;//220
		self.params.renderHeight = PhotoContentViewTemplate.listItemFolder[0].height;//288
		self.params.textX = PhotoContentViewTemplate.listItemFolder[1].x;//20
		self.params.textY = PhotoContentViewTemplate.listItemFolder[1].y;//186
		self.params.textWidth = PhotoContentViewTemplate.listItemFolder[1].width;//180
		self.params.textHeight = PhotoContentViewTemplate.listItemFolder[1].height;//58
		self.params.folderX = PhotoContentViewTemplate.listItemFolder[2].x;//37
		self.params.folderY = PhotoContentViewTemplate.listItemFolder[2].y;//60
		self.params.folderWidth = PhotoContentViewTemplate.listItemFolder[2].width;//146
		self.params.folderHeight = PhotoContentViewTemplate.listItemFolder[2].height;//121
		//other coordinate
		self.params.imageWidth = PhotoContentViewTemplate.listItemNoFolder[0].width;//220
		self.params.imageHeight = PhotoContentViewTemplate.listItemNoFolder[0].height;//220

		self.params.infoHeight = PhotoContentViewTemplate.listItemNoFolder[1].height;//68
		self.params.text1X = PhotoContentViewTemplate.listItemNoFolder[1].children[0].x;//18
		self.params.text1Y = PhotoContentViewTemplate.listItemNoFolder[1].children[0].y;//20
		self.params.text1Width = PhotoContentViewTemplate.listItemNoFolder[1].children[0].width;//184
		self.params.text1Height = PhotoContentViewTemplate.listItemNoFolder[1].children[0].height;//28
		self.params.text2X = PhotoContentViewTemplate.listItemNoFolder[1].children[1].x;//18
		self.params.text2Y = PhotoContentViewTemplate.listItemNoFolder[1].children[1].y;//35
		self.params.text2Width = PhotoContentViewTemplate.listItemNoFolder[1].children[1].width;//184
		self.params.text2Height = PhotoContentViewTemplate.listItemNoFolder[1].children[1].height;//28

		self.params.icon1X = PhotoContentViewTemplate.listItemNoFolder[3].x;//67
		self.params.icon1Y = PhotoContentViewTemplate.listItemNoFolder[3].y;//74
		self.params.icon1Width = PhotoContentViewTemplate.listItemNoFolder[3].width;//86
		self.params.icon1Height = PhotoContentViewTemplate.listItemNoFolder[3].height;//73
		
		self.params.icon2X = PhotoContentViewTemplate.listItemNoFolder[4].x;//66
		self.params.icon2Y = PhotoContentViewTemplate.listItemNoFolder[4].y;//66
		self.params.icon2Width = PhotoContentViewTemplate.listItemNoFolder[4].width;//88
		self.params.icon2Height = PhotoContentViewTemplate.listItemNoFolder[4].height;//88

		self.params.icon3X = PhotoContentViewTemplate.listItemNoFolder[5].x;//66
		self.params.icon3Y = PhotoContentViewTemplate.listItemNoFolder[5].y;//66
		self.params.icon3Width = PhotoContentViewTemplate.listItemNoFolder[5].width;//88
		self.params.icon3Height = PhotoContentViewTemplate.listItemNoFolder[5].height;//88

		self.params.icon4X = PhotoContentViewTemplate.listItemNoFolder[6].x;//66
		self.params.icon4Y = PhotoContentViewTemplate.listItemNoFolder[6].y;//66
		self.params.icon4Width = PhotoContentViewTemplate.listItemNoFolder[6].width;//88
		self.params.icon4Height = PhotoContentViewTemplate.listItemNoFolder[6].height;//88

		self.params.icon5X = PhotoContentViewTemplate.listItemNoFolder[7].x;//66
		self.params.icon5Y = PhotoContentViewTemplate.listItemNoFolder[7].y;//66
		self.params.icon5Width = PhotoContentViewTemplate.listItemNoFolder[7].width;//88
		self.params.icon5Height = PhotoContentViewTemplate.listItemNoFolder[7].height;//88

		
		self.loadNativeGridList();
		var rendererProvider = new RendererProvider;
		rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data)
		{
			return GetRenderer(parentWidth, parentHeight, data);
		};
		var gridListener = self.createGridListener();
	    var mustache = {
	        rendererProvider: rendererProvider,
			gridListener: gridListener,
	        columnWidth: 220,
	        rowHeight: 288,
	        renderNumber:27,
	        renderColumn:9,
	    };
		self.setGridListStyle(mustache);
		self.setGridListData(mustache);
		//EventMediator.trigger(EventType.EVENT_TYPE_UNDIM_SETTING);
	}
	
	PhotoContentView.prototype.t_DestroyList = function(){
		if(self.focusWidget !== null){
			self.focusWidget.loseFocus();
		}
		self.collection.cancelAllThumbnailRequest();

		print('PhotoContentView  Remove native grid control');
		//print('PhotoContentView  Remove native grid control nativeGridList id = ',self.nativeGridList.id);
		if(self.nativeGridList != null){
			
			self.nativeGridList.custom.focusable = false;
			Volt.Nav.removeItem(self.nativeGridList);
			self.widget = null;
		}
		
	}

	/** GetRenderer
	* @name GetRenderer	 
	* @memberOf PhotoContentView
	* @param {int} current render width 
	* @param {int} current render height
	* @param {Object} current render widget
	* @method 	 
	* */	
function GetRenderer(parentWidth, parentHeight, data)
{
	try {
		var renderer = new Thumbnail_View(parentWidth, parentHeight, self);
		
		renderer.createIndex = data.index;
		renderer.autoRelease = false;
		data.createFlag = true;
		if( data.index < self.collection.size() && self.collection.at(data.index).get('dataFlag')== 0){
			data.createFlag = false;
			data.dataFlag = false;
		}
		renderer.unique = null;
		
		renderer.textWidgetNumber = 1;
		renderer.template = PhotoContentViewTemplate;
		renderer.checkBoxIndex = 3;
		if ( data.dummyFlag == false ){
			renderer.createChildofPhotoView( renderer, data );
		}
		else{
			changeRenderInfo(data.index);
		}
	}catch(e){
		print('[GetRenderer]  e:', e);
	}
	print('[photo-content-view.js] GetRenderer:',renderer);
	return renderer;
};

function changeRenderInfo(index){
	self.nativeGridList.enableItem(0, index, false); 
};

function changeRenderImg(param){
	self.changeRenderImg(param);
}

function updateFolderItemThumbnail( data, renderer){
	var input = {
	    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
        x: 0,
        y: 0,
        width: self.params.renderWidth,
        height: self.params.renderHeight,
        image: {
            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
            width: self.params.renderWidth,
            height: self.params.renderHeight
        },
        information: {
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
            text1: {
            	text: data.title1,
                font: 'SamsungSmart_Light 24px',
                x: self.params.textX,
	            y: self.params.textY,
                width: self.params.textWidth,
                height: self.params.textHeight,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                singleLineMode: true,
                enlarge:{
                     factor: 1.5,
                     anchorPoint: 'center',
     			},
     			textColor: { r: 255, g: 255, b: 255, a: 153 },
            },
        },
		icon1: {
			x: self.params.folderX, 
			y: self.params.folderY, 
			width: self.params.folderWidth, 
			height: self.params.folderHeight,
			async: true,
			unpressSrc: self.folderNoamalImage,
			pressedSrc: self.folderNoamalImage,
			clickable: false,
			opacity: 128,
		}
	};
	renderer.thumbnail.setThumbnailStyle(input);
	if(RunTimeInfo.isEditMode == true){
		renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
		renderer.thumbnail.dim(true);
	}
	else{
		renderer.thumbnail.dim(false);
	}
	renderer.thumbnail.show();
};

function updateUpfolderItemThumbnail( data, renderer){
	var input = {
	    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
        x: 0,
        y: 0,
        width: self.params.renderWidth,
        height: self.params.renderHeight,
        image: {
            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_m_upper.png",
            width: self.params.renderWidth,
            height: self.params.renderHeight
        },
        information: {
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
            text1: {
            	text: data.title1,
                font: 'SamsungSmart_Light 24px',
                 x: self.params.textX,
	            y: self.params.textY,
	            width: self.params.textWidth,
	            height: self.params.textHeight,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                singleLineMode: true,
                enlarge:{
                     factor: 1.5,
                     anchorPoint: 'center',
     			},
            },
        },
		icon1: {
			x: self.params.folderX, 
			y: self.params.folderY, 
			width: self.params.folderWidth, 
			height: self.params.folderHeight,
			async: true,
			unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
			pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
			opacity:255*0.5,
			clickable: false
		}
	};
	renderer.thumbnail.setThumbnailStyle(input);
	if(RunTimeInfo.isEditMode == true){
		renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
		renderer.thumbnail.dim(true);
	}
	else{
		renderer.thumbnail.dim(false);
	}
	renderer.thumbnail.show();
};

function updateFileItemThumbnail( data, renderer){
	if ( !data.title1 ){
		data.title1 = '';
	}
	if ( !data.title2 ){
		data.title2 = '';
	}

    data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_photo_n.png';
    if( data.isThumbDone ){
    	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
    }
    else if(!self.collection.getItem(data.index).get('isPlayAvailable') || self.collection.getItem(data.index).get('isDrm')){
		self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath);		    	
    }
    else{
   		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
   	}

	if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
		data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_camera.png';
	}

	if (self.thumbnailColorFlag == false){
		self.thumbnailColorNumber = data.index%2;
		self.thumbnailColorFlag = true;
	}
	var tempIndex = data.index%2;
	var tempColorPickingOpacity = 255-240;
	if ( tempIndex == self.thumbnailColorNumber ){
		tempColorPickingOpacity = 255-225;
	}
	var input = {
	    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
        x: 0,
        y: 0,
        width: self.params.renderWidth,
        height: self.params.renderHeight,
        coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
        image: {
            src: data.ThumbPath,
            width: self.params.imageWidth,
            height: self.params.imageHeight
        },
        information: {
			x: 0, 
			y: self.params.imageHeight, 
			width: self.params.renderWidth, 
			height: self.params.infoHeight,
			colorPickingRange: {l:0, r: 100, t: 80, b: 100},
			enlarge:{
                     factor: 1.5,
                     anchorPoint: "bottom",
     		},
            text1: {
            	text: data.title1,
                font: 'SamsungSmart_Light 24px',
				x: self.params.text1X, 
				y: self.params.text1Y, 
				width: self.params.text1Width, 
				height: self.params.text1Height,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                singleLineMode: true,
                extractColorOpacity: 153,
            },
        },
		icon1: {
			x: self.params.icon1X, 
			y: self.params.icon1Y, 
			width: self.params.icon1Width, 
			height: self.params.icon1Height,
			async: true,
			unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
			pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
			opacity: 255*0.5,
			clickable: false
		},
		icon2: {
			x: self.params.icon2X, 
			y: self.params.icon2Y, 
			width: self.params.icon2Width, 
			height: self.params.icon2Height,
			async: true,
			unpressSrc: data.unsupportIcon,
			pressedSrc: data.unsupportIcon,
			clickable: false
		},
	};
	renderer.thumbnail.setThumbnailStyle(input);
	renderer.iconNumber = 2;
	renderer.editNum = 1;
	var showCheck =  false;
	if( RunTimeInfo.isEditMode ){
		var dataIndex = data.index;
		if(self.collection.addUpperFolderItemFlag == true){
			dataIndex = dataIndex -1;
		}
		if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
			showCheck = true;
			renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
			renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
			dimIconInfo(renderer, renderer.editNum);
		}
		else{
			renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
		}
	}
	else{
		renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
		if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
			renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
			dimIconInfo(renderer, renderer.iconNumber);
		}
		
	}
	
	renderer.thumbnail.show();
};

function dimIconInfo( input, iconNum ){
	switch (iconNum) {
        case 1:
			input.thumbnail.setElementOpacity("icon1", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon1");
			break;
        case 2:
			input.thumbnail.setElementOpacity("icon2", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon2");
			break;
        case 3:
			input.thumbnail.setElementOpacity("icon3", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon3");
			break;
        case 4:
			input.thumbnail.setElementOpacity("icon4", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon4");
		    break;
        case 5:
			input.thumbnail.setElementOpacity("icon5", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon5");
            break;
        case 6:
			input.thumbnail.setElementOpacity("icon6", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon6");
			break;
        case 7:
			input.thumbnail.setElementOpacity("icon7", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon7");			
			break;
        case 8:
			input.thumbnail.setElementOpacity("icon8", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon8");	
		    break;
        case 9:
			input.thumbnail.setElementOpacity("icon9", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon9");	
			break;
        case 10:
			input.thumbnail.setElementOpacity("icon10", 255);
			input.thumbnail.dim(true);
			input.thumbnail.raiseElement("icon10");	
		    break;
        default:
            break;
    }
};

exports = PhotoContentView;