 /** 
 * @author  Chen Xuemei (xnicole.chen@samsung.com)
 * 			
 * @fileoverview  MyContent content view base view
 * @date    2014/11/17 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Require Common Modules
var PanelCommon = Volt.require('lib/panel-common.js');
var _ = Volt.require("modules/underscore.js")._;
var BaseView = Volt.BaseView;

var resMgr = Volt.require('app/controller/resource-controller.js');
 
// Require Specific template for mycontents Main View
var PvrInfoWindowTemplate  = Volt.require('app/templates/1080/content-information-box-template-pvr.js');

var CommonInfo = Volt.require('app/common/define.js');
var EventType = CommonInfo.EventType;
var ChanelType = CommonInfo.ChanelType;


//Require Run Time Modules
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var self = null;
var voiceGuide = Volt.require('app/common/voice-guide.js');

print('require content-information-box-pvr.js');

/**when  press Info key  on content item ,show it
 * @class
 * @name PvrInfoWindow 
 * @augments PanelCommon.BaseView
 */
var PvrInfoWindow = PanelCommon.BaseView.extend({

	popupWidget: null,        // Store popup widget
    template: null,
    parent: null,
	btn1: null,
	btn2: null,
	btn3: null,
	btnListener: null,
	timer: null,
	timeFunc: null,
	timerOut: 0,
	programTitle : 'notitle',
	chanelNum : 'notDefined',
	chanelTitle : 'notitle',
	recordTime : 'notDefined',
	genre : 'notDefined',
	programLength : 'notDefined',
	programSize : 'notDefined',
	playCount : 'notDefined',
	synopsis : null,
	synopsisTextHeight : 0,
	synopsisTextLine : 48,
	commonInfoWidget: null,
	tvMode : 'notDefined',
	signalType : 'notDefined',
	hd: 'notDefined',
	location: 'notDefined',
	guidance: null,
	
	/**Initialize PvrInfoWindow 
     * @name initialize
     * @memberOf PvrInfoWindow
     * @constructs 
     */	
	initialize: function(){
		print('[content-infomation-box-pvr.js] initialize');
		self = this;
		var mainView = Volt.require('app/views/main-view.js');
		self.parent = mainView.widget.getChild('main-popup-container');
		
	},
	/**Render PvrInfoWindow
     * @name render
     * @memberOf PvrInfoWindow
     * @method
     * @return {}
     */
	render: function(){
		print('[content-infomation-box-pvr.js] render');
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		voiceText =  self.programTitle +', '
					+ self.tvMode + ', '
					+ self.signalType + ', '
					+ self.chanelNum + ', '
					+ self.chanelTitle+', '
					+ self.hd + ', '
					+ self.programSize + ', '
					+ self.contentLocation + ', '
					+ resMgr.getText('COM_SID_OK')+', '
					+ resMgr.getText('TV_SID_BUTTON');
		voiceGuide.play(voiceText);
		
		self.template = PvrInfoWindowTemplate.info_window_pvr;
		self.timerOut = 60000;
		var info = {
			synopsis: self.synopsis
		};
		try {
       		self.popupWidget = PanelCommon.loadTemplate(self.template, info);
       	}
       	catch(e){
       		print('content-information-box-pvr.js loadTemplate error: ' +e);
       	}
		self.popupWidget.parent = self.parent;
		self.rollSynopsis();
		self.renderButton();
		self.renderCommonInfo();
		this.setWidget(self.popupWidget);
		Volt.Nav.setRoot(this.widget);
		self.setDefaultFocus();
		self.timer = Volt.setTimeout(self.timeFunc, self.timerOut);		
       // Volt.Nav.beginModal(self.popupWidget); 
	},


	renderCommonInfo: function(){
		var commonTemp = PvrInfoWindowTemplate.record_common_info;
		var mustache = {
			programTitle : self.programTitle,
			tvmode : self.tvMode,
			cable : self.signalType,
			chanelNumber : self.chanelNum,
			chanelTitle : self.chanelTitle,
			recordTime : self.recordTime,
			HDSD : self.hd,
			programSize : self.programSize,
			location: self.location,		
		};
		self.commonInfoWidget = PanelCommon.loadTemplate(commonTemp, mustache,self.popupWidget);
		self.commonInfoWidget.parent = self.popupWidget;
		var programTitleWgt = self.commonInfoWidget.getDescendant('pvr-info-program-title');
		var firstLineBar1 = self.commonInfoWidget.getDescendant('pvr-info-first-line-bar1');
		var tvmodeWgt = self.commonInfoWidget.getDescendant('pvr-info-tv-mode');
		var firstLineBar2 = self.commonInfoWidget.getDescendant('pvr-info-first-line-bar2');
		var cableWgt = self.commonInfoWidget.getDescendant('pvr-info-cable');
		var firstLineBar3 = self.commonInfoWidget.getDescendant('pvr-info-first-line-bar3');
		var chanelNumWgt = self.commonInfoWidget.getDescendant('pvr-info-chanel-num');
		var firstLineBar4 = self.commonInfoWidget.getDescendant('pvr-info-first-line-bar4');
		var chanelTitleWgt = self.commonInfoWidget.getDescendant('pvr-info-chanel-title');
		var firstLineBar5 = self.commonInfoWidget.getDescendant('pvr-info-first-line-bar5');
		var redcordTimeWidget = self.commonInfoWidget.getDescendant('pvr-info-record-time');

		firstLineBar1.x = programTitleWgt.width + 1920* 0.006250;
		tvmodeWgt.x =  firstLineBar1.x + 1 + 1920* 0.006250;
		firstLineBar2.x = tvmodeWgt.x + tvmodeWgt.width + 1920* 0.006250;
		cableWgt.x = firstLineBar2.x + 1 + 1920* 0.006250;
		firstLineBar3.x = cableWgt.x + cableWgt.width +1920* 0.006250;
		chanelNumWgt.x = firstLineBar3.x + 1 + 1920* 0.006250;
		firstLineBar4.x = chanelNumWgt.x + chanelNumWgt.width + 1920* 0.006250;
		chanelTitleWgt.x = firstLineBar4.x + 1 + 1920* 0.006250;
		firstLineBar5.x = chanelTitleWgt.x + chanelTitleWgt.width + 1920* 0.006250;
		redcordTimeWidget.x = firstLineBar5.x + 1 +  1920* 0.006250;
		
	},

	setProgramTitle : function(str_title){
		self.programTitle = str_title;
		
	},

	setSignalType: function(chanelType){
		switch(chanelType){
			case ChanelType.CHANNEL_TYPE_ATV:
			case ChanelType.CHANNEL_TYPE_DTV:
				{
					self.signalType = resMgr.getText('COM_SID_AIR');
					break;
				}
			case ChanelType.CHANNEL_TYPE_CATV:
			case ChanelType.CHANNEL_TYPE_CDTV:
				{
					self.signalType = resMgr.getText('COM_SID_CABLE');
					break;
				}
			default:
				break;
		}
	},	

	setTvMode: function(chanelType){
		switch(chanelType){
			case ChanelType.CHANNEL_TYPE_ATV:
			case ChanelType.CHANNEL_TYPE_CATV:
				{
					self.tvMode = 'ATV';
					break;
				}
			case ChanelType.CHANNEL_TYPE_DTV:
			case ChanelType.CHANNEL_TYPE_CDTV:
				{
					self.tvMode = 'DTV'
					break;
				}
			default:
				break;
		}
	},

	setSize: function(str_size){
		print('[content-information-box-pvr.js]setSize():'+ str_size);
		if(str_size != null){
			if( str_size == '' || str_size == 0 ){
				self.programSize = 0;
			}
			self.programSize = resMgr.getText('TV_SID_SIZE_COLON')+' ' + self.convertSizeToText(str_size);
		}
	},

	setChanelNum: function(str_num){
		if(str_num != undefined){
			self.chanelNum = str_num;
		}
	},
	setChanelTitle: function(str_chtitle){
		if(str_chtitle != undefined){
			self.chanelTitle = str_chtitle;
		}
	},

	setQuality: function(str_quality){
		self.hd = resMgr.getText('TV_SID_QUALITY') +' '+ str_quality;
	},
	setLocation: function(str_local){
		if(str_local != null){
			var temp = '/';
			self.location = resMgr.getText('TV_SID_LOCATION')+ self.replaceAll(str_local, '/', '>');
		}
	},

	setSynopsis : function(str_syno){
		if(str_syno != undefined){
			self.synopsis = str_syno;
		}		
	},
	
	setGuidance : function(str_guidance){
		if(str_guidance != undefined){
			self.guidance = str_guidance;
		}
	},
	setRecordingTime : function(str_date){
		print('[content-information-box-pvr.js]setRecordingTime():'+ str_date);
		if(str_date != null){
			if(typeof(str_date)== "number" ){
				self.recordTime = self.getDateString(str_date);
			}
			else if(typeof(str_date) == "string"){
				self.recordTime = str_date.substr(0,4)+ '.'+ str_date.substr(5,2) +'.' + str_date.substr(8,2);
			}
		}
	},
	
	/**Render PvrInfoWindow
     * @name rollSynopsis
     * @memberOf PvrInfoWindow
     * @method
     * @return {}
     */
	rollSynopsis: function(){
        var pvrSynopsisWidget = self.popupWidget.getChild('pvr-info-ci-synopsis');	
        var posSynop = 0;
        var synopsisText =  resMgr.getText('TV_SID_NO_INFORMATION_AVAILABLE');
        if(self.synopsis != null){
        	synopsisText = self.synopsis;
        }
        if(self.guidance != null){
        	var guidanceIcon = new ImageWidgetEx({
        		id: 'pvr-info-guidance-icon',
        		x:0, y:11,
        		src: resMgr.getImgPath()+ '/popup/mc_poup_icon_g.png',
        		parent : pvrSynopsisWidget
        	});

       		var guidanceContex = new TextWidgetEx({
	       		x: 40, y: 0,
	       		width : pvrSynopsisWidget.width - 40,
	       		height : 48,
	            horizontalAlignment:"left",
	            verticalAlignment:"center",
	            textColor : Volt.hexToRgb('#FFFFFF'),
	            opacity: 255* 0.9,
	            id :'pvr-info-guidance-text',
	            font : "SVD Light 34px",
	            text : self.guidance,
				ellipsize: true,
	            parent : pvrSynopsisWidget
       		});
        	posSynop = 48;

        }
       	var pvrSynopsisText = new TextWidgetEx({
       		x: 0, y: posSynop,
       		width :pvrSynopsisWidget.width,
            horizontalAlignment:"left",
          //  verticalAlignment:"center",
            textColor : Volt.hexToRgb('#FFFFFF'),
            opacity: 255* 0.5,
            id :'more_info_text',
            font : "SVD Light 36px",
            text : synopsisText,
            parent : pvrSynopsisWidget
       	});
		var lineHeight= pvrSynopsisText.getLineHeight();
		print('lineHeight: '+ lineHeight);
		pvrSynopsisText.lineSpacing = 48 - lineHeight;

		
	},
	/**Render PvrInfoWindow
     * @name renderButton
     * @memberOf PvrInfoWindow
     * @method
     * @return {}
     */
	renderButton : function(){
		var btnWidget1 = self.popupWidget.getChild('pvr-info-ci-ok-button');
		if(btnWidget1 != null){
			self.btn1 = btnWidget1;
			self.btn1.setText({state: "all", text: resMgr.getText('COM_SID_OK'),});
			self.btn1.setTextColor({state: "focused", color: { r:0x46, g:0x46, b:0x46,a:0xff },});
			self.btn1.setTextColor({state: "focused-roll-over", color: { r:0x46, g:0x46, b:0x46,a:0xff },});

			self.btn1.setTextColor({state: "normal", color: { r:255, g:255, b:255,a:0xff },});
			self.btn1.setFontSize({state: "normal", size: 32,});
			self.btn1.setFontSize({state: "focused", size: 36,});
			self.btn1.setFontSize({state: "selected", size: 36,});
			self.btn1.setFontSize({state: "focused-roll-over", size: 36,});
			self.btn1.setBackgroundColor({state: "normal", color: { r:255, g:255, b:255, a: 0 },});	
			self.btn1.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a: 255*0.95 },});	

			self.btn1.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a: 255*0.95 },});	
			self.btn1.setBorder({state: "all",border: {width:1, color: {r:0xff,g:0xff,b:0xff,a:255}}});
								          
		}

		var btnWidget2 = self.popupWidget.getChild('pvr-info-ci-scroll-up-button');
		if(btnWidget2 != null){
			self.btn2 = btnWidget2;
			self.btn2.setBackgroundColor({state: "all", color: { r:255, g:255, b:255, a: 0 },});	
			self.btn2.setIconImage({state: "focused",
											src: resMgr.getImgPath()+'/Arrow/popup_arrow_up_f.png',});
			self.btn2.setIconImage({state: "selected",
											src: resMgr.getImgPath()+'/Arrow/popup_arrow_up_f.png',});
			self.btn2.setIconImage({state: "focused-roll-over",
											src: resMgr.getImgPath()+'/Arrow/popup_arrow_up_f.png',});
    		self.btn2.setIconImage({state: "normal",
    										src: resMgr.getImgPath()+'/Arrow/popup_arrow_up_n.png'});				
		}

		var btnWidget3 = self.popupWidget.getChild('pvr-info-ci-scroll-down-button');
		if(btnWidget3 != null){
			self.btn3 = btnWidget3;
			self.btn3.setBackgroundColor({state: "all", color: { r:255, g:255, b:255, a: 0 },});	
			self.btn3.setIconImage({state: "focused",
											src: resMgr.getImgPath()+'/Arrow/popup_arrow_down_f.png',});
			self.btn3.setIconImage({state: "selected",
											src: resMgr.getImgPath()+'/Arrow/popup_arrow_down_f.png',});
	
			self.btn3.setIconImage({state: "focused-roll-over",
											src: resMgr.getImgPath()+'/Arrow/popup_arrow_down_f.png',});
    		self.btn3.setIconImage({state: "normal",
    										src: resMgr.getImgPath()+'/Arrow/popup_arrow_down_n.png'});				
		}

		var buttonListener = new ButtonListener;
		self.btnListener = buttonListener;
		self.btn1.addListener(buttonListener);
		self.btn2.addListener(buttonListener);
		self.btn3.addListener(buttonListener);

		buttonListener.onButtonClicked = function (button, type){
			print('----buttonListener onButtonClicked type = ',type);
			if(button == self.btn1){		
				Volt.setTimeout(self.onBtn1CallBack, 1);
			}
			else if(button == self.btn2){
				Volt.setTimeout(self.onBtn2CallBack, 1);
			}
			else if(button == self.btn3){
				Volt.setTimeout(self.onBtn3CallBack, 1);
			}
			else{
			}
		};

		self.btn1.show();
		if(self.synopsis == null){
			self.btn2.hide();
			self.btn3.hide();
		}
		else{
			self.btn2.show();
			self.btn3.show();
		}

		
	},

	

	onBtn1CallBack : function(){
		self.hide();
	},

	onBtn2CallBack : function(){
		self.resetTimer();
		self.textRollUp();
	},

	onBtn3CallBack : function(){	
		self.resetTimer();
		self.textRollDown();
	},

	setDefaultFocus : function(){
		if(self.btn1 != null){
			self.btn1.setFocus();
		}
	},
	
	
	/** textRollDown
     * @name textRollDown
     * @memberOf PvrInfoWindow
     * @method
     * @return {}
     */
	textRollDown : function(){
		print('[content-information-box-pvr.js] text roll down');
		var pvrSynopsisText = self.popupWidget.getDescendant('more_info_text');
		if(pvrSynopsisText != undefined && pvrSynopsisText != null){
			if(pvrSynopsisText.y + pvrSynopsisText.height  > 288)
			{
				pvrSynopsisText.y -= 48;
				if(self.guidance != null){
					var guidanceIcon = self.popupWidget.getDescendant('pvr-info-guidance-icon');
					var guidanceText =  self.popupWidget.getDescendant('pvr-info-guidance-text');
					guidanceIcon.y -= 48;
					guidanceText.y -= 48;
				}
			}
		
			
		}
		
	},
	/**Render textRollUp
     * @name textRollUp
     * @memberOf PvrInfoWindow
     * @method
     * @return {}
     */
	textRollUp : function(){
		print('[content-information-box-pvr.js] text roll up');
		var pvrSynopsisText = self.popupWidget.getDescendant('more_info_text');
		
		if(pvrSynopsisText != undefined && pvrSynopsisText != null){
			if(self.guidance != null){
					var guidanceIcon = self.popupWidget.getDescendant('pvr-info-guidance-icon');
					var guidanceText =  self.popupWidget.getDescendant('pvr-info-guidance-text');
					if(pvrSynopsisText.y < 48)
					{
						pvrSynopsisText.y += 48;
						guidanceIcon.y += 48;
						guidanceText.y += 48;					
					}
			}
			else{
				if(pvrSynopsisText.y < 0)
				{
					pvrSynopsisText.y += 48;
				}
			}					
		}
	
	},
	 /** hide InfoWindow 	 
	* @name hide	 
	* @memberOf InfoWindow
	* @method
	* @return {} 	 
	* */
    hide : function(){
    	print('[content-information-box.js] hide');
		if(self.popupWidget == null){
			print('[content-information-box.js]popupWidget is NULL!');
			return;
		}
		if( self.timer!= null ){
			Volt.clearTimeout(self.timer);
			self.timer = null;
		}		
		//Volt.Nav.endModal(self.popupWidget);
		self.popupWidget.hide();
		self.destroy();
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
    },

	/** destroy InfoWindow 	 
	* @name destroy	 
	* @memberOf InfoWindow
	* @method
	* @return {} 	 
	* */
	destroy : function(){					
		if(!self.popupWidget){
			return;
		}
		if(self.btn1 != null){
			self.btn1.killFocus();
			self.btn1.removeListener(self.btnListener);
			self.btn1 = null;
		}
		if(self.btn2 != null){
			self.btn2.killFocus();
			self.btn2.removeListener(self.btnListener);
			self.btn2 = null;
		}
		if(self.btn3 != null){
			self.btn3.killFocus();
			self.btn3.removeListener(self.btnListener);
			self.btn3 = null;
		}
		if(self.popupWidget != null){
			self.popupWidget.destroy();
			self.popupWidget = null;
		}
		var mainView = Volt.require('app/views/main-view.js');
		Volt.Nav.setRoot(mainView.widget); 
	},

	/** process timeout event  	 
	* @name timeFunc	 
	* @memberOf InfoWindow
	* @method
	* @return {} 	 
	* */
	timeFunc : function(){
    	print('get in the timeFunc');
		self.hide();
    },

    resetTimer: function(){
    	print('reset time out');
		if(self.timer != null){
			Volt.clearTimeout(self.timer);
		}
		self.timer = Volt.setTimeout(self.timeFunc, self.timerOut);			
	},

	/** process key event  	 
	* @name onKeyEvent	 
	* @memberOf InfoWindow
	* @param {templateType}  template type
	* @method
	* @return {} 	 
	* */
	onKeyEvent: function(KeyCode,type){
		print('[content-information-box-pvr.js] onKeyEvent()');
		var ret = true;
		
		if (type != Volt.EVENT_KEY_RELEASE)
		{
			return false;
		}
		if(KeyCode ==  Volt.KEY_RETURN){
			self.hide();
			return true;
		}
		
		switch(KeyCode){
			case Volt.KEY_RETURN:{
					self.hide();
				}
				
			case Volt.KEY_JOYSTICK_OK: {
					
				}
				break;
			case Volt.KEY_JOYSTICK_UP: 
				self.onBtn2CallBack();
				break;
			case Volt.KEY_JOYSTICK_DOWN: 
				self.onBtn3CallBack();
				break;
			case Volt.KEY_JOYSTICK_LEFT:
			case Volt.KEY_JOYSTICK_RIGHT: 
				self.resetTimer();
				break;
			default:
				ret = false;
				break;
		}
		return false;
	},
		/**convert number size to text
	* @name convertSizeToText	 
	* @memberOf InfoWindow
	* @method
	* @return {int} 	 
	* */	
	convertSizeToText: function(size){
		var textSize = '';
		if((size/(1024*1024)) < 1){
			var totalSize = size/1024;
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'KB';
		}
		else if((size/(1024*1024*1024)) < 1){
			var totalSize = size/(1024*1024);
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'MB';
		}
		else if((size/(1024*1024*1024*1024)) < 1){
			var totalSize = size/(1024*1024*1024);
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'GB';
		}
		else{
			var totalSize = size/(1024*1024*1024*1024);
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'TB';
		}
		return textSize;
    },

	/**convert time to string
	* @name getTimeString	 
	* @memberOf InfoWindow
	* @method
	* @return {String} 	 
	* */	
	getTimeString: function(duration) {
		var secondStyle = duration / 1000;
		var hh = parseInt(secondStyle/3600);
		var mm = parseInt(secondStyle%3600 / 60);
		var ss = parseInt(secondStyle%60);
		
		var sec = ss > 9 ? ss : '0'+ss;
		var min = mm > 9 ? mm : '0'+mm;

		var res = hh == 0 ? min+':'+sec : hh+':'+min+':'+sec;
		return res;
	},

	/**convert date to string
	* @name getDateString	 
	* @memberOf InfoWindow
	* @method 	 
	* */	
	getDateString: function (date) {
		print('[content-information-box.js] getDateString():'+ date);
		if(date == null){
			return '';
		}
		var newDate = new Date(date*1000);

		var t_dd = newDate.getDate();
		var t_mm = newDate.getMonth()+1; 
		var t_yyyy = newDate.getFullYear();

		if(t_dd < 10){
				t_dd= '0'+ t_dd;
		}
		if(t_mm < 10){
				t_mm= '0'+ t_mm;
		}
		var strDate = t_yyyy + '.' + t_mm + '.' + t_dd;
		return strDate;
		//return '2014.09.13';
	},

	replaceAll: function(s,s1,s2){
		if(s == null){
			return '';
		}
	    return s.replace(new RegExp(s1,"gm"),s2);   
	}

});

exports = PvrInfoWindow ;
