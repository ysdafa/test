 /** 
 * 			He Wenge (wenge.he@samsung.com)
 * @fileoverview  Define global constanst varibale
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var CommonInfo = Volt.require("app/common/define.js");
var CGFocusPos = CommonInfo.CGFocusPos;
var SortType = CommonInfo.SortType;
var ViewType = CommonInfo.EViewType;
var resMgr = Volt.require('app/controller/resource-controller.js');
var ViewGlobalData = {
    isGridListFocus: false,
	isEnterByConnectionGuide: false,
	isCategoryFocus: false,
	GroupIndex : -1,
	rootPath   :'',
    isRootGroup: true,
	gridlistIndex: [],
	currFilePath: '',
	parentFielPathStack: [],
	dlnaContentidStack: [],
	agent: null,
	lastPlayIndex: -1,
	uhdRisticRate: '',
	isUserSetRateLevel:false,
	viewSortText: [resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER)],
	viewUSBText:[
		ViewType.eAllContentView,
		ViewType.ePhotoContentView,
		ViewType.eVideoContentView,
		ViewType.eMusicContentView,
		ViewType.eRecordContentView,	
	],

	
	viewDLNAText:[
		ViewType.eAllContentView,
		ViewType.ePhotoContentView,
		ViewType.eVideoContentView,
		ViewType.eMusicContentView,
		ViewType.eRecordContentView,
	],
	viewPTPText: [
		ViewType.eAllContentView,
		ViewType.ePhotoContentView,
		ViewType.eVideoContentView,
		ViewType.eMusicContentView,
		ViewType.eRecordContentView,
	],

	contentType: '',
	categoryType:'',
	viewTypeIndex:0,
	firstLaunch:true,
	conguidefocus : CGFocusPos.FOCUS_NONE,
	
	reset: function(){
		print(" view global data reset ");
		this.isGridListFocus = false;
		this.GroupIndex = -1;
		this.rootPath  = '';
		this.isRootGroup  = true;
		this.gridlistIndex = [];
		this.currFilePath =  '';
		this.parentFielPathStack = [];
		this.dlnaContentidStack = [];
		
		//!!!!! Do not assigne agent  null, need call csf_disconnect, otherwise when app exit, csf will core dump
		print('view-global-data reset Csf_agent : ',this.agent);
		//this.agent = null;
		this.viewSortText = [
		           resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER)];
		this.contentType =  '';
		this.categoryType = '';
		this.conguidefocus = CGFocusPos.FOCUS_NONE;
		
	},

	deviceChange: function(){
		print(" view global data deviceChange ");
		this.isGridListFocus = false;
		this.GroupIndex = -1;
		this.rootPath  = '';
		this.isRootGroup  = true;
		this.gridlistIndex = [];
		this.currFilePath =  '';
		this.parentFielPathStack = [];
		this.dlnaContentidStack = [];
		//!!!!! Do not assigne agent  null, need call csf_disconnect, otherwise when app exit, csf will core dump
		print('view-global-data reset Csf_agent : ',this.agent);
		//this.agent = null;
		this.conguidefocus = CGFocusPos.FOCUS_NONE;
		

	},

	getViewType: function(devType){
		var viewType = ViewType.eNoneView;
		if(devType == 'USB'){
			viewType = this.viewUSBText[this.viewTypeIndex];				
		}
		else if(devType == 'DLNA'){
			viewType = this.viewDLNAText[this.viewTypeIndex];
			/*
			if(this.viewTypeIndex == 4){
				this.viewTypeIndex = 0;
				
			}*/
			
		}
		else if(devType == 'PTP'){
			viewType = this.viewPTPText[this.viewTypeIndex];
			/*
			if(this.viewTypeIndex != 1){
				this.viewTypeIndex = 1;
			}*/
		}
		return  viewType;
			/*
		switch(this.contentType){
			
			case 'CONTENT-FOLDER':{
					viewType = ViewType.eAllContentView;		
				}
			case 'CONTENT-IMAGE':{
					viewType = ViewType.ePhotoContentView;
				}
			case 'CONTENT-VIDEO':{
					viewType = ViewType.eVideoContentView;
				}
			case 'CONTENT-MUSIC':{
					viewType = ViewType.eMusicContentView;
				}
			case 'CONTENT-PVR':{
					viewType = ViewType.eRecordContentView;
				}
		}				*/

		
	},

	resetViewSortText : function(){
		this.viewSortText = [
		           resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER),
	               resMgr.getText(SortType.SORT_TYPE_FOLDER)];
	}
	
};

exports = ViewGlobalData;