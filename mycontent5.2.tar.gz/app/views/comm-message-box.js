/** 
 * @author mycontents engineer
 * @fileoverview comm-message-box.js
 * @date 2014/08/02
 * 
 * @version 1.0
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 * 
 * @note: Volt 2.0 maybe draw children according to index sequence
 */

// Modules

var Require = Volt.require;
var _ = Volt.require('modules/underscore.js')._;
//var Backbone = Require('lib/volt-backbone.js');
// Require Common Modules
var PanelCommon = Require('lib/panel-common.js');
var CommonInfo = Volt.require('app/common/define.js');
var MessageType = CommonInfo.MessageType;
var MsgBoxTemplateType = CommonInfo.MsgBoxTemplateType;
var EventType = CommonInfo.EventType;
var LaunchAppID = CommonInfo.LaunchAppID;
var EViewType = CommonInfo.EViewType;

// Require Specific template for Games Main View
var MessageBoxTemplate = Volt.require('app/templates/1080/comm-message-box-template.js');
var resMgr = Volt.require('app/controller/resource-controller.js');
var voiceGuide = Volt.require('app/common/voice-guide.js');

//Require Run Time Modules
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var mycontentWidth = RunTimeInfo.SceneResolution;
var offSet = RunTimeInfo.offSet;
var self = null;


/**CommMessageBox
 * @class
 * @name CommMessageBox 
 * @augments PanelCommon.BaseView
 */
var CommMessageBox = PanelCommon.BaseView.extend({
    mediator: null,     // Handle Events
    msgBoxType: null,
    msgBox: null,
    param: null,
    listener: null,
    parent: null,
    msgBoxDestroyCb:null,
    keyboardListener: null,
    msgFirstButtonCb:null,
    msgSecondButtonCb:null,
    parentRootWidget : null,
    mainview: null,
    
    /**Initialize CommMessageBox 
     * @name initialize
     * @memberOf CommMessageBox
     * @return {}
     */
     
    initialize: function(options) {
		self = this;
		if(options){
			self.parentRootWidget = options.parentRootWidget;
		}
		var mainView = Volt.require('app/views/main-view.js');
		self.parent = mainView.widget.getChild('main-popup-container');
		self.mainview = mainView;
		EventMediator.on(EventType.EVENT_TYPE_HIDE_MSG_BOX, this.onHideMsg, this);
		EventMediator.on(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
    },
    
    onHideMsg: function(){
    	Log.e("comm-message-box.js onHideMsg");	
		print("comm-message-box.js onHideMsg");	
		if(self.msgBoxDestroyCb != null){
			Log.e("comm-message-box.js call msgBoxDestroyCb");	
			self.msgBoxDestroyCb();
		}
		
		this.remove();

	},

	onHighcontrastChange: function(){
		print('comm-message-box.js onHighcontrastChange()');
		if(self.msgBox != null){
			self.msgBox.setFirstLayerBGColor({firstLayerBGColor: {r: 0x00, g: 0x00, b: 0x00, a: 255}});
            self.msgBox.setSecondLayerBGColor({secondLayerBGColor: {r: 0x00, g: 0x00, b: 0x00, a: 255}});
            self.msgBox.setThirdLayerBGColor({thirdLayerBGColor: {r: 0x00, g: 0x00, b: 0x00, a: 255}});
		}
	},
	
	setMsgBoxDestroyCb:function(cb){
		self.msgBoxDestroyCb = cb;
	},
	setMsgBoxContentText:function(text){
		if(this.msgBox != null && this.msgBox != undefined){
			this.msgBox.setContentText(text);
			
			voiceGuide.play(text + resMgr.getText('COM_SID_OK')+ ', '+resMgr.getText('TV_SID_BUTTON'));
			
			this.msgBox.showTime = 10000;			
		}
	},
	
	setFirstButtonClickCb:function(cb){
		self.msgFirstButtonCb = cb;
	},
	
	setSecondButtonClickCb:function(cb){
		self.msgSecondButtonCb = cb;
	},
	
	firstButtonClick:function(){
        this.remove();
		
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		
		if(self.msgFirstButtonCb != null && self.msgFirstButtonCb != undefined){
			self.msgFirstButtonCb();
		}		
	},
	
	secondButtonClick:function(){
        this.remove();
		
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		
		if(self.msgSecondButtonCb != null && self.msgSecondButtonCb != undefined){
			self.msgSecondButtonCb();
		}
	},
	
	setRoot : function(){
		if(!self.parent){
			return;
		}
		Volt.Nav.setRoot(self.parent);
	},
	
	setFocus : function(){
		if(!self.msgbox){
			return ;
		}
		self.msgBox.setDefaultFocus();
	},
	
    /**Render CommMessageBox
     * @name render
     * @memberOf CommMessageBox
     * @param {enum} type  type of CommMessageBox
     * @param {String} 
     * @method
     * @return {Object}
     */
    render: function(msgBoxType,param) {
		print('comm-message-box.js msgBoxType = ',msgBoxType);
        this.param = param;
        this.msgBoxType = msgBoxType;
		//this.setWidget(this.widget);
		//Volt.Nav.setRoot(self.parent);
        self.setRoot();
        switch(msgBoxType){
			//case MessageType.eDisconnectUsb:
				//break;
            case MessageType.eDeleteItem:
                var that = this;
                var messageBox1Listener = new MessageBoxListener;
                messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
                    
                    if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
                        Volt.setTimeout(_.bind(that.deleteItemMsgBoxOkCB,that),1);
                    }
            
                    if ('button_clicked' == eventType && 'button_2' == nButtonIndex) {
                        Volt.setTimeout(_.bind(that.deleteItemMsgBoxNoCB,that),1);
                    }
                };

				messageBox1Listener.OnTimeOut = function(messagebox){
                    Volt.setTimeout(_.bind(that.deleteItemMsgBoxNoCB,that),1);
                };

				var msgTemplate = that.getMsgBoxTemplate(MsgBoxTemplateType.NO_TITLE_TWO_BTN);
                var tmpMsgBox = PanelCommon.loadTemplate(msgTemplate, null, self.parent);
				var msgText = that.getTextByMsgType(msgBoxType);
				tmpMsgBox.setContentRect(0, 20, mycontentWidth, 170);
				tmpMsgBox.setContentTextColor(255, 255, 255, 255);
				tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
				tmpMsgBox.setButtonRect("button_1", 960-275-10+offSet, 210, 275, 70);
				tmpMsgBox.setButtonRect("button_2", 960+10+offSet, 210, 275, 70);
                tmpMsgBox.setContentTextColor(255, 255, 255, 255);
                tmpMsgBox.setContentText(msgText);
				
				voiceGuide.play(msgText + resMgr.getText('COM_SID_OK')+ ', '+ resMgr.getText('TV_SID_BUTTON'));
				
                tmpMsgBox.enablePointerFocus();
                tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
                this.setDelMsgBoxButtonStyle(tmpMsgBox,MessageType.eDeleteItem);
                tmpMsgBox.defaultFocusIndex = 2;
                tmpMsgBox.showTime = 10000;
                tmpMsgBox.addListener(messageBox1Listener);
				
				if(this.keyboardListener){
					this.keyboardListener.destroy();
					this.keyboardListener = null;
				}
				this.keyboardListener = new KeyboardListener;
				this.keyboardListener.onKeyReleased = function (actor, keyCode) {
					if (keyCode == Volt.KEY_RETURN) {
						Volt.setTimeout(_.bind(that.deleteItemMsgBoxNoCB, that), 1);
					}
				};
				tmpMsgBox.addKeyboardListener(this.keyboardListener);
				
                //tmpMsgBox.onKeyEvent = _.bind(this._onKeyEvent, this);
                tmpMsgBox.show();
                this.msgBox = tmpMsgBox;				
                this.listener = messageBox1Listener;
                break;
				
		case MessageType.eUHDTwoButton:
				var that = this;
				this.param = param;
	            var messageBox1Listener = new MessageBoxListener;
			    messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
                if ('button_focus_in' == eventType && 'button_1' == nButtonIndex) {
					voiceGuide.queuingPlay(resMgr.getText('COM_SID_YES')+ ', ' + resMgr.getText('TV_SID_BUTTON'));
                }
                
                if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
                    Volt.setTimeout(_.bind(that.firstButtonClick,that),1);
                }
                if ('button_focus_in' == eventType && 'button_2' == nButtonIndex) {
					voiceGuide.play(resMgr.getText('COM_SID_NO')+ ', ' + resMgr.getText('TV_SID_BUTTON'));
                }
                
                if ('button_clicked' == eventType && 'button_2' == nButtonIndex) {
                    Volt.setTimeout(_.bind(that.secondButtonClick,that),1);
                }
            };

			messageBox1Listener.OnTimeOut = function(messagebox){
                Volt.setTimeout(_.bind(that.secondButtonClick,that),1);
            };

			var msgTemplate = that.getMsgBoxTemplate(MsgBoxTemplateType.NO_TITLE_TWO_BTN);
            var tmpMsgBox = PanelCommon.loadTemplate(msgTemplate, null, self.parent);
			//var msgText = that.getTextByMsgType(msgBoxType);
			tmpMsgBox.contentType = "multi_line_content_type";
			tmpMsgBox.contentTextRowGap = 12;
			tmpMsgBox.setContentRect(0, 20, mycontentWidth, 170);
			tmpMsgBox.setContentTextColor(255, 255, 255, 255);
			tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
			tmpMsgBox.setButtonRect("button_1", 960-275-10+offSet, 210, 275, 70);
			tmpMsgBox.setButtonRect("button_2", 960+10+offSet, 210, 275, 70);
            tmpMsgBox.setContentTextColor(255, 255, 255, 255);
            tmpMsgBox.setContentText(param);
			
			voiceGuide.play(param);
			
            tmpMsgBox.enablePointerFocus();
            tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
            tmpMsgBox.defaultFocusIndex = 1;
            tmpMsgBox.showTime = 10000;
            tmpMsgBox.addListener(messageBox1Listener);
			this.setDelMsgBoxButtonStyle(tmpMsgBox,MessageType.eUHDTwoButton);
			
			if(this.keyboardListener){
				this.keyboardListener.destroy();
				this.keyboardListener = null;
			}
			this.keyboardListener = new KeyboardListener;
			this.keyboardListener.onKeyReleased = function (actor, keyCode) {
				if (keyCode == Volt.KEY_RETURN) {
					Volt.setTimeout(_.bind(that.secondButtonClick, that), 1);
				}
			};
			tmpMsgBox.addKeyboardListener(this.keyboardListener);
			
            //tmpMsgBox.onKeyEvent = _.bind(this._onKeyEvent, this);
            tmpMsgBox.show();
            this.msgBox = tmpMsgBox;				
            this.listener = messageBox1Listener;
			break;
		case MessageType.eNetworkError:
			var that = this;
            var messageBox1Listener = new MessageBoxListener;
            messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
               
                if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
                    Volt.setTimeout(_.bind(that.netWorkErrorMsgBoxOkCB,that),1);
                }
               
                if ('button_clicked' == eventType && 'button_2' == nButtonIndex) {
                    Volt.setTimeout(_.bind(that.netWorkErrorMsgBoxNoCB,that),1);
                }
            };

			messageBox1Listener.OnTimeOut = function(messagebox){
                Volt.setTimeout(_.bind(that.netWorkErrorMsgBoxNoCB,that),1);
            };

			var msgTemplate = that.getMsgBoxTemplate(MsgBoxTemplateType.NO_TITLE_TWO_BTN);
            var tmpMsgBox = PanelCommon.loadTemplate(msgTemplate, null, self.parent);
			var msgText = that.getTextByMsgType(msgBoxType);
			tmpMsgBox.setContentRect(0, 20, mycontentWidth, 170);
			tmpMsgBox.setContentTextColor(255, 255, 255, 255);
			tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
			tmpMsgBox.setButtonRect("button_1", 960-275-10+offSet, 210, 275, 70);
			tmpMsgBox.setButtonRect("button_2", 960+10+offSet, 210, 275, 70);
            tmpMsgBox.setContentTextColor(255, 255, 255, 255);
            tmpMsgBox.setContentText(msgText);
			
			voiceGuide.play(msgText + resMgr.getText('TV_SID_TROUBLESHOOT')+ ', '+resMgr.getText('TV_SID_BUTTON'));
			
            tmpMsgBox.enablePointerFocus();
            tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
            tmpMsgBox.defaultFocusIndex = 1;
            tmpMsgBox.showTime = 10000;
            tmpMsgBox.addListener(messageBox1Listener);
			this.setDelMsgBoxButtonStyle(tmpMsgBox,MessageType.eNetworkError);
			
			if(this.keyboardListener){
				this.keyboardListener.destroy();
				this.keyboardListener = null;
			}
			this.keyboardListener = new KeyboardListener;
			this.keyboardListener.onKeyReleased = function (actor, keyCode) {
				if (keyCode == Volt.KEY_RETURN) {
					Volt.setTimeout(_.bind(that.deleteItemMsgBoxNoCB, that), 1);
				}
			};
			tmpMsgBox.addKeyboardListener(this.keyboardListener);
			
            //tmpMsgBox.onKeyEvent = _.bind(this._onKeyEvent, this);
            tmpMsgBox.show();
            this.msgBox = tmpMsgBox;				
            this.listener = messageBox1Listener;
			break;
        case MessageType.eStorageFull:
            var that = this;
            var messageBox1Listener = new MessageBoxListener;
            messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
                if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
                    Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
                }
            };

			messageBox1Listener.OnTimeOut = function(messagebox){
                Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
            };

            var msgTemplate = that.getMsgBoxTemplate(MsgBoxTemplateType.NO_TITLE_ONE_BTN_MULTI_MSG);
       		var tmpMsgBox = PanelCommon.loadTemplate(msgTemplate, null, self.parent);
			var title = param.title;
			var msgText1 = param.text1;
			var msgText2 = param.text2;
			tmpMsgBox.setTitleRect(0, 10, mycontentWidth, 50);
			tmpMsgBox.setTitleText(title);
			tmpMsgBox.setTitleTextColor(255, 255, 255, 255);
			tmpMsgBox.setContentRect(0, 80, mycontentWidth, 70);
            tmpMsgBox.setContentTextColor(255, 255, 255, 255);
            tmpMsgBox.setContentText(msgText1);
			
			voiceGuide.play(msgText1);
			
			tmpMsgBox.setContent2Rect(0, 150, mycontentWidth, 70);
			tmpMsgBox.setContentText2Color(255, 255, 255, 255);
			tmpMsgBox.setContentText2(msgText2);
			
			voiceGuide.queuingPlay(msgText2 + resMgr.getText('COM_SID_OK')+ ', '+resMgr.getText('TV_SID_BUTTON'));
			
            tmpMsgBox.enablePointerFocus();
            tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
			tmpMsgBox.setButtonRect("button_1", (mycontentWidth-300)/2, 220, 300, 70);
            tmpMsgBox.setButtonText('button_1', 'all', Volt.i18n.t('COM_SID_OK'));
            tmpMsgBox.setButtonTextColor('button_1', 'all', 255, 255, 255, 255);
			//tmpMsgBox.setButtonTextFontSize("button_1", "all", 32);
            tmpMsgBox.defaultFocusIndex = 1;
			tmpMsgBox.setDefaultFocus();
            tmpMsgBox.showTime = 10000;
            tmpMsgBox.addListener(messageBox1Listener);
			print('111111111111111111x = ',tmpMsgBox.x);
			print('111111111111111111y = ',tmpMsgBox.y);
			print('111111111111111111wide = ',tmpMsgBox.width);
			print('111111111111111111height = ',tmpMsgBox.height);
			if(this.keyboardListener){
				this.keyboardListener.destroy();
				this.keyboardListener = null;
			}
			this.keyboardListener = new KeyboardListener;
			this.keyboardListener.onKeyReleased = function (actor, keyCode) {
				if (keyCode == Volt.KEY_RETURN) {
					Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB, that), 1);
				}
			};
			tmpMsgBox.addKeyboardListener(this.keyboardListener);
            //tmpMsgBox.onKeyEvent = _.bind(this._onKeyEvent, this);
            tmpMsgBox.show();
            this.msgBox = tmpMsgBox;				
            this.listener = messageBox1Listener;
            break;

        case MessageType.eNotAvailable:
            var that = this;
			Volt.log('comm-message-box.js---to create not availablae messagebox');
            var messageBox1Listener = new MessageBoxListener;
            messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
                if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
                    Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
                }
            };

			messageBox1Listener.OnTimeOut = function(messagebox){
                Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
            };
			Volt.log('comm-message-box.js---to create not availablae messagebox2');
           var msgTemplate = that.getMsgBoxTemplate(MsgBoxTemplateType.NO_TITLE_NO_BTN);
            var tmpMsgBox = PanelCommon.loadTemplate(msgTemplate, null, self.parent);
			var msgText = that.getTextByMsgType(msgBoxType);
            tmpMsgBox.setContentTextColor(255, 255, 255, 255);
            tmpMsgBox.setContentText(msgText);
			
			voiceGuide.play(msgText);
			Volt.log('comm-message-box.js---to create not availablae messagebox3');
            tmpMsgBox.enablePointerFocus();
            tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
            //tmpMsgBox.setButtonText('button_1', 'all', Volt.i18n.t('COM_SID_OK'));
            //tmpMsgBox.setButtonTextColor('button_1', 'all', 255, 255, 255, 255);
            //tmpMsgBox.defaultFocusIndex = 1;
            tmpMsgBox.showTime = 5000;
            tmpMsgBox.addListener(messageBox1Listener);

			if(this.keyboardListener){
				this.keyboardListener.destroy();
				this.keyboardListener = null;
			}
			this.keyboardListener = new KeyboardListener;
			this.keyboardListener.onKeyReleased = function (actor, keyCode) {
				if (keyCode == Volt.KEY_RETURN) {
					Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB, that), 1);
				}
			};
			Volt.log('comm-message-box.js---to create not availablae messagebox4');
			tmpMsgBox.addKeyboardListener(this.keyboardListener);
            //tmpMsgBox.onKeyEvent = _.bind(this._onKeyEvent, this);
            tmpMsgBox.show();
            this.msgBox = tmpMsgBox;				
            this.listener = messageBox1Listener;
			
			Volt.log('comm-message-box.js---to create not availablae messagebox 5');
            break;
        case MessageType.eUnableToSortBy:
		case MessageType.eUnableSelectCopy:
		case MessageType.eUnableSelectPlay:
		case MessageType.eUnableSelectDel:
		case MessageType.eDisconnectUsb:
		case MessageType.eMessageBox:
		case MessageType.eNotSupportFormat: /* drop */
		case MessageType.eAppVersion:
		case MessageType.eDeviceInfo:
		case MessageType.eUnAvailable:
		case MessageType.eNoRecordContent:
			print('1111111111111111111111111111111111111');
            var that = this;
            var messageBox1Listener = new MessageBoxListener;
            messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
				print("comm-message-box.js OnButtonEvent eventType = ",eventType);
				print("comm-message-box.js OnButtonEvent nButtonIndex = ",nButtonIndex);
				Log.e("comm-message-box.js OnButtonEvent eventType = " + eventType);
                if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
					if(msgBoxType == MessageType.eDisconnectUsb || msgBoxType == MessageType.eNotSupportFormat){
						Log.e("comm-message-box.js OnButtonEvent eventType = button_clicked");
                    	Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
					}
					else{
						Log.e("comm-message-box.js OnButtonEvent eventType = button_clicked");
						Volt.setTimeout(_.bind(that.optionFirstItemMsgBoxCB,that),1);
					}
                }
				if ('button_focus_in' == eventType && 'button_1' == nButtonIndex){
                    messagebox.setButtonBackgroundColor("button_1", "focused-roll-over", 255, 255, 255, 255*0.95);  
					messagebox.setButtonBackgroundColor("button_1", "roll-over", 255, 255, 255, 255*0.95);
					messagebox.setButtonTextColor('button_1', 'focused-roll-over', 0x46, 0x46, 0x46, 255);
					messagebox.setButtonTextColor('button_1', 'roll-over', 0x46, 0x46, 0x46, 255);
                }
            };

			messageBox1Listener.OnTimeOut = function(messagebox){
                //Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
                if(msgBoxType == MessageType.eDisconnectUsb || msgBoxType == MessageType.eNotSupportFormat){
                	Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
				}
				else{
					Volt.setTimeout(_.bind(that.optionFirstItemMsgBoxCB,that),1);
				}
            };
			var msgTemplate = null;
			if ( msgBoxType != MessageType.eDeviceInfo ){
				msgTemplate = that.getMsgBoxTemplate(MsgBoxTemplateType.NO_TITLE_ONE_BTN);
			}
			else{
				msgTemplate = that.getMsgBoxTemplate(MsgBoxTemplateType.NO_TITLE_ONE_BTN_MAGIC);
			}
			if(RunTimeInfo.router && RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView){
				/* if current view is music, message box parent can not be main view widget, because, message box can not display */
				print(" Current view is music player, set msg parent to scene ");
				var tmpMsgBox = PanelCommon.loadTemplate(msgTemplate, null, scene);

			}else{
				var tmpMsgBox = PanelCommon.loadTemplate(msgTemplate, null, self.parent);
			}
			
    		if(msgBoxType == MessageType.eDisconnectUsb ||msgBoxType == MessageType.eMessageBox){
				var msgText = param;

			}else{
				var msgText = that.getTextByMsgType(msgBoxType);
			}
			
			if ( msgBoxType != MessageType.eDeviceInfo ){
				tmpMsgBox.setContentRect(0, 20, mycontentWidth, 170);
			}
			else{
				tmpMsgBox.setContentRect(0, 20, mycontentWidth, 480-140);
			}
			
            tmpMsgBox.setContentTextColor(255, 255, 255, 255);
            tmpMsgBox.setContentText(msgText);
			
			voiceGuide.play(msgText + resMgr.getText('COM_SID_OK') + ', ' + resMgr.getText('TV_SID_BUTTON'));
			
            tmpMsgBox.enablePointerFocus();
            tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
			if ( msgBoxType != MessageType.eDeviceInfo ){
				tmpMsgBox.setButtonRect("button_1", (mycontentWidth-300)/2, 210, 300, 70);
			}
			else{
				tmpMsgBox.setButtonRect("button_1", (mycontentWidth-300)/2, 480-100, 300, 70);
			}
			tmpMsgBox.setButtonBackgroundColor("button_1", "focused", 255, 255, 255, 255*0.95);
            tmpMsgBox.setButtonTextColor('button_1', 'focused', 0x46, 0x46, 0x46, 255);
			tmpMsgBox.setButtonTextColor('button_1', 'normal', 255, 255, 255, 255*0.95);
            tmpMsgBox.setButtonText('button_1', 'all', resMgr.getText('COM_SID_OK'));
          	if(MessageType.eAppVersion == msgBoxType ) {
		      tmpMsgBox.setButtonImage('button_1','all',resMgr.getImgPath()+'/check_update.png');
            }
            tmpMsgBox.defaultFocusIndex = 1;
            tmpMsgBox.showTime = 10000;
			tmpMsgBox.contentType = "multi_line_content_type";
            tmpMsgBox.addListener(messageBox1Listener);
			
			if(this.keyboardListener){
				this.keyboardListener.destroy();
				this.keyboardListener = null;
			}
			this.keyboardListener = new KeyboardListener;
			this.keyboardListener.onKeyReleased = function (actor, keyCode) {
				if (keyCode == Volt.KEY_RETURN) {
					//Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB, that), 1);
					if(msgBoxType == MessageType.eDisconnectUsb || msgBoxType == MessageType.eNotSupportFormat){
                    	Volt.setTimeout(_.bind(that.OptionSelectNotifyMsgBoxCB,that),1);
					}
					else{
						Volt.setTimeout(_.bind(that.optionFirstItemMsgBoxCB,that),1);
					}
				}
			};
			tmpMsgBox.addKeyboardListener(this.keyboardListener);
            //tmpMsgBox.onKeyEvent = _.bind(this._onKeyEvent, this);
            tmpMsgBox.show();
            this.msgBox = tmpMsgBox;				
            this.listener = messageBox1Listener;
            break;
        default:
            break;
        }
		if(HALOUtil.highContrast == true){
			if(tmpMsgBox != null){
				tmpMsgBox.setSecondLayerBGHeight(1);
				tmpMsgBox.setThirdLayerBGHeight(2);
				tmpMsgBox.setFirstLayerBGColor({firstLayerBGColor: {r: 0x00, g: 0x00, b: 0x00, a: 255}});
	            tmpMsgBox.setSecondLayerBGColor({secondLayerBGColor: {r: 0x00, g: 0x00, b: 0x00, a: 255}});
	            tmpMsgBox.setThirdLayerBGColor({thirdLayerBGColor: {r: 0x00, g: 0x00, b: 0x00, a: 255}});
				tmpMsgBox.setFourthLayerBGImage(resMgr.getImgPath()+'/popup/popup_shadow.png');
			}
		}
		else{
			if(tmpMsgBox != null){
				tmpMsgBox.setSecondLayerBGHeight(1);
				tmpMsgBox.setThirdLayerBGHeight(2);
				tmpMsgBox.setFirstLayerBGColor({firstLayerBGColor: {r: 0x0a, g: 0x23, b: 0x3d, a: 255}});
	            tmpMsgBox.setSecondLayerBGColor({secondLayerBGColor: {r: 0xff, g: 0xff, b: 0xff, a: 255* 0.05}});
	            tmpMsgBox.setThirdLayerBGColor({thirdLayerBGColor: {r: 0x00, g: 0x00, b: 0x00, a: 255* 0.15}});
				tmpMsgBox.setFourthLayerBGImage(resMgr.getImgPath()+'/popup/popup_shadow.png');
			}
		}
	    self.mainview.msgbox = this;
        return this;
    },

	/**Render CommMsgBox
     	* @name getTextByMsgType
     	* @memberOf CommMessageBox
     	* @param {enum} type  type of message
     	* @method
     	*/
	getTextByMsgType: function(msgType){
		var text = '';
		switch(msgType){
			case MessageType.eUnableToSortBy:
				text = resMgr.getText('TV_SID_SORTING_TURNED_OFF_FILTER_BY_ALL');//"Unable to select the \'sort by\' option while \'filter by\' is set to all.";				 
				break;
			case MessageType.eUnableSelectCopy:
				text =  resMgr.getText('TV_SID_USB_STORASGE_DRIVE_REQUIRED_FEATURE');//"Unable to select the Copy to USB option with one USB storage.\nPlease connect additional USB storage.";
				break;
			case MessageType.eUnableSelectPlay:
				//text = "Unable to select the 'Play Selected' option while 'filter by' is set to all";
				text =  resMgr.getText('TV_SID_SELECTED_TURNED_OFF_FILETER_BY_ALL');
				break;
			case MessageType.eUnableSelectDel:
				//text = "You can delete only recorded content,Please change the filter option to 'Recorded' first";
				text =  resMgr.getText('TV_SID_CAN_ONLY_DELETE_RECORDED_CONTENT_CHANGE_FILTER');
				break;
			case MessageType.eDeleteItem:
				//text = "Delete the Selected item(s)?";
				text = resMgr.getText('TV_SID_DELETE_SELECTED_ITEMS_QUES');
				break;
			case MessageType.eUnAvailable:
				text =  resMgr.getText('TV_SID_SEND_USB_NOT_AVIAL_FILTER_BY_OPTION');
				break;
			case MessageType.eNotAvailable:
				text =  resMgr.getText('COM_SID_NOT_AVAILABLE');
				break;
			case MessageType.eNetworkError:
				text = resMgr.getText('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK');
				break; 
			case MessageType.eNotSupportFormat:
				text = resMgr.getText('COM_SID_THIS_FILE_FORMAT_NOT_SUPPORTED');
				break; 
			case MessageType.eAppVersion:
				var myConfig = CommonInfo.Config;
				text = Volt.i18n.t(myConfig.app_version);
				break; 
			case MessageType.eDeviceInfo:
				var DeviceModel = Volt.require("app/models/device-model-kpi.js");
	            var msg = '';
	            var buffer = '';
	            _.each(DeviceModel.attributes,function(value, key){
	                var str = "<b>" + key.toUpperCase() + "</b>" + ' : ' + value + ' , ';
	                Volt.log(str);
	                msg += str;
	                buffer += str;
	                if( buffer.length > 60){
	                    buffer = '';
	                    msg += '\r';
	                }
	            });
				text = Volt.i18n.t(msg);
				break;
			case MessageType.eNoRecordContent:
				text = resMgr.getText('TV_SID_THERE_NO_RECORDED_CONTENT'); //There is no recorded content.
				break;
			default:
                break;
		}
		return text;
    },

	/** set message box button style  	 
	* @name setMsgBoxButtonStyle	 
	* @memberOf CommMessageBox
	* @method 	 
	* */
	setDelMsgBoxButtonStyle: function(msg, msgType){
		if(msg == null){
			return;
		}
		if(msgType == MessageType.eDeleteItem){
			msg.setButtonText('button_1', 'all', Volt.i18n.t('COM_SID_OK'));
			msg.setButtonText('button_2', 'all', Volt.i18n.t('COM_SID_CANCEL'));
		}
		else if(msgType == MessageType.eUHDTwoButton){
			msg.setButtonText('button_1', 'all', Volt.i18n.t('COM_SID_YES'));
			msg.setButtonText('button_2', 'all', Volt.i18n.t('COM_SID_NO'));
		}
		else if(msgType == MessageType.eNetworkError){
			msg.setButtonText('button_1', 'all', Volt.i18n.t('TV_SID_TROUBLESHOOT'));
			msg.setButtonText('button_2', 'all', Volt.i18n.t('COM_SID_CANCEL'));
		}
		else{
			msg.setButtonText('button_1', 'all', Volt.i18n.t('COM_SID_OK'));
			msg.setButtonText('button_2', 'all', Volt.i18n.t('COM_SID_CANCEL'));
		}
        msg.setButtonTextColor('button_1', 'normal', 255, 255, 255, 255*0.95);
		msg.setButtonTextColor('button_1', 'focused', 0x46, 0x46, 0x46, 255);
		msg.setButtonTextColor('button_1', 'focused-roll-over', 0x46, 0x46, 0x46, 255);
		msg.setButtonTextColor('button_1', 'roll-over', 0x46, 0x46, 0x46, 255);
		msg.setButtonBackgroundColor("button_1", "focused", 255, 255, 255, 255*0.95);
		msg.setButtonBackgroundColor("button_1", "focused-roll-over", 255, 255, 255, 255*0.95);
		msg.setButtonBackgroundColor("button_1", "roll-over", 255, 255, 255, 255*0.95);

        msg.setButtonTextColor('button_2', 'normal', 255, 255, 255, 255*0.95);
		msg.setButtonTextColor('button_2', 'focused', 0x46, 0x46, 0x46, 255);
		msg.setButtonTextColor('button_2', 'focused-roll-over', 0x46, 0x46, 0x46, 255);
		msg.setButtonTextColor('button_2', 'roll-over', 0x46, 0x46, 0x46, 255);
		msg.setButtonBackgroundColor("button_2", "focused", 255, 255, 255, 255*0.95);
		msg.setButtonBackgroundColor("button_2", "focused-roll-over", 255, 255, 255, 255*0.95);
		msg.setButtonBackgroundColor("button_2", "roll-over", 255, 255, 255, 255*0.95);
    },

	/** get message box template  	 
	* @name getMsgBoxTemplate	 
	* @memberOf CommMessageBox
	* @param {enum}  template type
	* @method
	* @return {Object} 	 
	* */
	getMsgBoxTemplate: function(templateType){
		var template;
		switch(templateType){
			case MsgBoxTemplateType.NO_TITLE_ONE_BTN_MAGIC:
				template = MessageBoxTemplate.msgbox_template_magic_no_title_one_button;
				break;
			case MsgBoxTemplateType.NO_TITLE_ONE_BTN:
				template = MessageBoxTemplate.msgbox_template_no_title_one_button;
				break;
			case MsgBoxTemplateType.NO_TITLE_TWO_BTN:
				template = MessageBoxTemplate.msgbox_template_no_title_two_button;
				break;
			case MsgBoxTemplateType.NO_TITLE_THREE_BTN:
				template = MessageBoxTemplate.msgbox_template_no_title_three_button;
				break;
			case MsgBoxTemplateType.NO_TITLE_NO_BTN:
				template = MessageBoxTemplate.msgbox_template_no_title_no_button;
				break;	
			case MsgBoxTemplateType.NO_TITLE_ONE_BTN_MULTI_MSG:
				template = MessageBoxTemplate.msgbox_template_multi_msg_one_button;
				break;
			default:
				break;
		}
		return template;
    },
	
	/** remove the items  	 
	* @name remove	 
	* @memberOf CommMessageBox
	* @param {String}  options type
	* @method
	* @return {Object} 	 
	* */
	remove: function(options) {
		print('comm-message-box.js  this.msgBox: ',this.msgBox);
        if(this.msgBox){


            print('comm-message-box.js remove()');
			this.msgBox.hide(); 
            this.msgBox.removeListener(this.listener);
			this.msgBox.removeKeyboardListener(this.keyboardListener);                       
			if(this.keyboardListener){
				this.keyboardListener.destroy();				
			}
			if(this.listener){
				this.listener.destroy();				
			}
			this.listener = null;
			this.keyboardListener = null;
			//this.msgBox.destroy();
			var self = this;
			HALOUtil.asyncRelease(self.msgBox);
            this.msgBox = null;
			self.mainview.msgbox = null;
			EventMediator.off(EventType.EVENT_TYPE_HIDE_MSG_BOX, this.remove, this);
			EventMediator.off(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
			var mainView = Volt.require('app/views/main-view.js');
			mainView.msgbox = null;

	        if(this.msgBoxType == MessageType.eDisconnectUsb){
				Log.e("Message box is disconenct usb popup, just renturn, in popup destroy callback set root");
				return;
			}
			if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectMobileGuideView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectUsbGuideView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectPcGuideView ){
				var currView = RunTimeInfo.router.getCurrentView();
				if( currView != null ){
					Volt.Nav.setRoot(currView.widget);
				}
				else{
					Volt.Nav.setRoot(mainView.widget);
				}
			} 
			else{
				Volt.Nav.setRoot(mainView.widget);
			}
        }
        
        return this;
    },

	  /** OptionSelectNotifyMsgBoxCB
	 * @name InstallAppFailMsgBoxCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
    OptionSelectNotifyMsgBoxCB: function(){
        print('comm-message-box.js OptionSelectNotifyMsgBoxCB()');
		if(self.msgBoxDestroyCb){
			self.msgBoxDestroyCb();
		}
        self.remove();
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
	
    },

	onButtonClick : function(){
		self.OptionSelectNotifyMsgBoxCB();
	},
	
	/** optionFirstItemMsgBoxCB
	 * @name optionFirstItemMsgBoxCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
	optionFirstItemMsgBoxCB: function(){
		if(this.msgBox){
            print('comm-message-box.js optionFirstItemMsgBoxCB remove()');
			Log.e('comm-message-box.js optionFirstItemMsgBoxCB remove()');
			this.msgBox.hide(); 
            this.msgBox.removeListener(this.listener);
			this.msgBox.removeKeyboardListener(this.keyboardListener);                       
			if(this.keyboardListener){
				this.keyboardListener.destroy();				
			}
			if(this.listener){
				this.listener.destroy();				
			}
			this.listener = null;
			this.keyboardListener = null;
			//this.msgBox.destroy();
			var self = this;
			HALOUtil.asyncRelease(self.msgBox);
            this.msgBox = null;
			self.mainview.msgbox = null;
			EventMediator.off(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
			EventMediator.off(EventType.EVENT_TYPE_HIDE_MSG_BOX, this.remove, this);
			
			if(self.msgFirstButtonCb != null && self.msgFirstButtonCb != undefined){
				self.msgFirstButtonCb();
			}
			if ( self.msgBoxType == MessageType.eAppVersion || self.msgBoxType ==  MessageType.eDeviceInfo ){
				EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
				var mainView = Volt.require('app/views/main-view.js');
				print("optionFirstItemMsgBoxCB RunTimeInfo.router.currentViewType: "+RunTimeInfo.router.currentViewType);
				if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectMobileGuideView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectUsbGuideView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectPcGuideView ){
					var currView = RunTimeInfo.router.getCurrentView();
					if( currView != null ){
						print("optionFirstItemMsgBoxCB setRoot currView.widget");
						Volt.Nav.setRoot(currView.widget);
					}
					else{
						print("optionFirstItemMsgBoxCB setRoot mainView.widget");
						Volt.Nav.setRoot(mainView.widget);
					}
			
				}else{
					Volt.Nav.setRoot(mainView.widget);
				}
				print('comm-message-box.js optionFirstItemMsgBoxCB setRoot()');
			}
        }
    },

	 /** OptionSelectNotifyMsgBoxCB
	 * @name InstallAppFailMsgBoxCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
    deleteItemMsgBoxNoCB: function(){
        print('comm-message-box.js deleteItemMsgBoxNoCB()');
        this.remove();
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
    },
    
	 /** deleteItemMsgBoxOkCB
	 * @name deleteItemMsgBoxOkCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
	deleteItemMsgBoxOkCB: function(){
		print('comm-message-box.js deleteItemMsgBoxOkCB()');
		this.remove();		

        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		EventMediator.trigger(EventType.EVENT_TYPE_SHOW_DEL_PROGRESS_POPUP);
    },

	 /** netWorkErrorMsgBoxOkCB
	 * @name netWorkErrorMsgBoxOkCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
	netWorkErrorMsgBoxOkCB: function(){
		print('comm-message-box.js netWorkErrorMsgBoxOkCB()');
		this.remove();
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		var AppLauncher = Volt.require("app/controller/app-launch.js");
		AppLauncher.launch(LaunchAppID.APP_ID_NETWORK_SETTINGS, {key1 : 'value1'});
    },
    
     /** netWorkErrorMsgBoxNoCB
	 * @name netWorkErrorMsgBoxNoCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
	netWorkErrorMsgBoxNoCB: function(){
		print('comm-message-box.js netWorkErrorMsgBoxNoCB()');
        this.remove();
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
    },
	/** networkMsgBoxCB
	 * @name networkMsgBoxCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
    networkMsgBoxCB: function(){
        Volt.log();
        this.remove();

        var options = {
            type: options,
            setRoot: false
        };
       EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		/*
		if(Volt.Nav.getItem(0)){
			Volt.Nav.focus(Volt.Nav.getItem(0));
		}*/
        Volt.exit();
    },

	/** noNetworkMsgBoxOKCB
	 * @name noNetworkMsgBoxOKCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
    noNetworkMsgBoxOKCB: function(){
		Volt.log('noNetworkMsgBoxOKCB');
        this.remove();
        var aulApp = new Aul();
        var ret = aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
        Volt.log('ret='+ret);
        if(ret){
            Volt.log();
            CommonInfo.eChangeStatus = EChangeStatus.eEnterNetWorkApp;
        }
        var options = {
            type: options,
            setRoot: false
        };
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
    },

	/** noNetworkMsgBoxCancelCB
	 * @name noNetworkMsgBoxCancelCB
	 * @member CommMessageBox
	 * @method
	 * @return {}
	 */
    noNetworkMsgBoxCancelCB: function(){
		Volt.log('noNetworkMsgBoxCancelCB');
        this.remove();
        if( this.param !== undefined && 
	  	( this.param.curViewStatus === ECurViewStatus.eEnterViewWithoutNetwork ) ){
			Volt.log('noNetworkMsgBoxOKCB exit');
            Volt.exit();
        }
        else{
        }
		Volt.log('noNetworkMsgBoxOKCB -- ');
        var options = {
            type: options,
            setRoot: false
        };
        EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
    },
    
});

exports = CommMessageBox;

