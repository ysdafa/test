 /** 
 * @author  Chen Xuemei (xnicole.chen@samsung.com)
 * 			
 * @fileoverview  MyContent content view base view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var resMgr = Volt.require('app/controller/resource-controller.js');
	var _ = Volt.require("modules/underscore.js")._;
	var Backbone = Volt.require('modules/backbone.js');
	var BaseView = Volt.BaseView;
	var BaseModel = Volt.require("app/models/base-model.js");
	var ContentBaseCollection = Volt.require("app/models/content-base-collection.js");
//	var playerController = Volt.require('app/controller/play-controller.js');
	var RunTimeInfo = Volt.require("app/common/run-time-info.js");
	var EventMediator = RunTimeInfo.EventMediator;
	var Q = Volt.require('modules/q.js');
	var CommonInfo = Volt.require('app/common/define.js');
	var KeyCode = CommonInfo.KeyCode;
	var EventType = CommonInfo.EventType;
	var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
	var CategoryBannerType = CommonInfo.CategoryBannerType;
	var gridlistID   = CommonInfo.gridlistID;
	var FocusPosition = CommonInfo.FocusPos;
	var EditModeViewTemplate = Volt.require('app/templates/1080/editmode-view-template.js');
	var EViewType = CommonInfo.EViewType;
	var EItemType = CommonInfo.EItemType;
	var CategoryType = CommonInfo.CategoryType;
	var CSFSourceType = CommonInfo.CSFSourceType;
	var MyContentOptionType = CommonInfo.MyContentOptionType;
	var CONST = CommonInfo.CONST;
	var OptionText = Volt.require("app/common/option-text.js");
	var CategoriesName = OptionText.CategoriesName;
	var VideoFilterTextList = OptionText.VideoFilterTextList;
	var VideoSortByTextList = OptionText.VideoSortByTextList;
	var PanelCommon = Volt.require('lib/panel-common.js');
	var ViewGlobalData = Volt.require("app/views/view-global-data.js");
	var DeviceProvider = Volt.require("app/models/device-provider.js");
	//var MusicPlayerView = Volt.require('app/views/music-player-view.js');
	var LongPressPopupView = Volt.require('app/views/long-press-view.js');
	var AppLauncher = Volt.require("app/controller/app-launch.js");
    var LaunchAppID = CommonInfo.LaunchAppID;
	var	RatedLevel = CommonInfo.RatedLevel;
	var TTSEventType = CommonInfo.TTSEventType;
	var MessageType = CommonInfo.MessageType;
	var voiceGuide = Volt.require('app/common/voice-guide.js');
	var EOptType = CommonInfo.EOptType;
	var SortType = CommonInfo.SortType;
	var PvrQuality = CommonInfo.PvrQuality;
	var appConfig = Volt.require("app/common/app-config.js");
	var voltapi = Volt.require('voltapi.js');
	var launchParams = Volt.require("app/common/launch-params.js");
	var UHDTumbnail = CommonInfo.UHDTumbnail;
	var CIThumbType = CommonInfo.CIThumbType;
	// define vconfig key
	var VCONF_DUID     =     'db/comss/duid';
	var VCONF_ATOKEN   =    'db/comss/atoken';
	var VCONF_ATOKENEXPTIME = 'db/comss/atokenexptime';
	var VCONF_COUNTRYCODE   = 'db/comss/countrycode';

	
	var selHightIconPath = resMgr.getImgPath()+'/CheckBox/mc_icon_selection_check.png';
	
	var selAllCheckIconNor = resMgr.getImgPath()+'/CheckBox/btn_icon_ms_selectall_nor.png';
	var selAllCheckBoxIconNor = resMgr.getImgPath()+'/CheckBox/btn_icon_ms_selectall_nor_box.png';
	var loadTemplate = PanelCommon.loadTemplate;
	var AllContentViewTemplate = Volt.require('app/templates/1080/all-view-template.js');
	var Render_View = Volt.require("app/views/render-view.js");
	var Thumbnail_View = Volt.require("app/views/thumbnail-view.js");
	var nativeGridlistFocus = CommonInfo.nativeGridlistFocus;
	var DeviceType = CommonInfo.DeviceType;
	var CategoryName = CommonInfo.CategoryName;
	//var timer = Volt.require("app/common/timer.js");
	var inputController = Volt.require('app/controller/input-controller.js');
	var self;
	
	var PlayType = {
		PLAY_TYPE_ALL : 'ALL',	
		PLAY_TYPE_SELECTED : 'SELECTED',	
	};
	
	var FocusPos = {
		OnList	 	: 0,
		OnButton 	: 1,
	};
	/**ContentViewBase
	 * @class 
	 * @name ContentViewBase 
	 * @extends {BaseView}
	 */
	var ContentViewBase = PanelCommon.BaseView.extend({
		nRow: 0,
		nCol: 0,
		gridList: null,
		nativeGridList: null,
		nativeGridPlayerIndex:0,
		gridIndex:0,
		isGridListFocus: false,
		focusWidget: null,
		focusIndex: -1,
		contentType: '',
		sortCate: '',
		editModeWidget: null,
		isShowSecPlus: [],
		isDimFirstPlus: [],
		returnFlag  : false,
		mainView : null,
		//isEditMode : false,
		popupView: null,
		longPressFocusIndex: -1,
		template: EditModeViewTemplate.container,
		playInstance: null,
		deviceName: '',
		enterFolder:false,
		waitFirstShow:true,
		textIndex: 0,
		thumbnailColorFlag: false,
		thumbnailColorNumber: 0,
		uhdVideoItem:null,
		contentid:null,
		uhdContentId:'',
		infoWnd:null,
		selTotalSize: 0,
		folderNoamalImage: null,
		folderFocusImage: null,
		pipPopup:null,
	//	enterSepcialFolder : false,
		downEdge:false,
		isDimRecord: false,
		thumbListener: null,
		UHDContentFolder: false,
		
	 	/** Initialize ContentViewBase  	 
		* @name initialize	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		initialize: function() {
			print("content-view-base.js initialize");
			self = this;
			self.infoWnd = null;
			this.mainView = Volt.require('app/views/main-view.js');
			self.deviceName = self.mainView.categoryView.getCurrentCategoryName();
			self.collection = new ContentBaseCollection();
			self.listenTo(self.collection, 'adddata', self.UpdateBrowserData);
			self.listenTo(self.collection, 'remove', self.t_DestroyList);
			self.listenTo(self.collection, 'thumbnail', self.updateItem);
			EventMediator.on(EventType.EVENT_TYPE_UPDATE_SELECT_LIST_ITEM, this.updateSelectListItem, this);
			EventMediator.on(EventType.EVENT_TYPE_DES_SELECT_ITEM, this.setDesSelectItemToCsf, this);
			EventMediator.on(EventType.EVENT_TYPE_MUSICPLAYER_DATA_DONE, this.musicDataPrepared, this);
			EventMediator.on(EventType.EVENT_TYPE_MUSICPLAYER_DATA_FAILED, this.musicDataInvalid, this);
			EventMediator.on(EventType.EVENT_TYPE_PRESS_GRIDLIST_ITEM, this.nativeGridListCallback, this);
			EventMediator.on(EventType.EVENT_TYPE_DISCONNECT_CURRENT_DEVICE,this.onDisconnectCurrentDevice,this);
			EventMediator.on(EventType.EVENT_TYPE_HIDE_INFOWND,this.onHideInfoPopup,this);
			EventMediator.on(EventType.EVENT_TYPE_MYCONTENT_KEY_PRESS,this.onGridlistKeyEvent,this);
			EventMediator.on(EventType.EVENT_TYPE_ON_ACTIVE,this.onCloseTerm,this);

			var id = self.mainView.categoryView.currentID;
			if(DeviceProvider.isUHDDevice(id)){
				if(!voltapi.WAS.isOpened()){		
					voltapi.WAS.initAsync(function(bSuccessed){
						print('WAS init result: ' + bSuccessed);
					});
				}
			}
			var tempFoldImage = Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder.png";
			if ( RunTimeInfo.router.currentViewType == EViewType.eVideoContentView ){
				tempFoldImage = Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_02.png";
			}
			self.folderNoamalImage = new Image(tempFoldImage);
			if( self.folderNoamalImage == null ){
				self.folderNoamalImage = tempFoldImage;
			}
			self.folderFocusImage = new Image(Volt.BASE_PATH + resMgr.getImgPath()+'/foders/mc_icon_foder_zoom.png');
			if( self.folderFocusImage == null ){
				self.folderFocusImage = Volt.BASE_PATH + resMgr.getImgPath()+'/foders/mc_icon_foder_zoom.png';
			}

			self.thumbListener = new ThumbnailListener;
			self.thumbListener.onImageReady = function (thumbnail, id, success) {
				var color = thumbnail.getInformationColorPicking();
	        	var cc = HALOUtil.extractIconColor(color.r, color.g, color.b);
				
	        	if(cc == HALOUtil.CC_BLACK){
	        		thumbnail.setAttachIconImage("icon2",{
	        			unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_thumb_g_b.png",
	        			pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_thumb_g_b.png",
	        		});   
	        	}else if(cc == HALOUtil.CC_WHITE){
	        		thumbnail.setAttachIconImage("icon2",{
	        			unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_thumb_g_w.png",
	        			pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_thumb_g_w.png",
	        		});
	        	}
			};
			
			print("content-view-base.js initialize finish");
		//	self.playInstance = playerController;
		},
		onDisconnectCurrentDevice:function(deviceId){
			print('[onDisconnectCurrentDevice] ~~~~~~~~~~~~~~~~ deviceId: ',deviceId);
			self.exitEditMode();
		},
		render : function(){
			print('ContentViewBase.js : render()');
		},

		/** Show ContentViewBase  	 
		* @name show	 
		* @memberOf ContentViewBase
		* @param {enum} animation type
		* @method
		* @return {} 	 
		* */	
		show: function(aniType){
			print("content view -------- show");
			var deferred = Q.defer(); 
			self.widget.show();			
			
			if(RunTimeInfo.visibleCursor == true){
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_ROOT_ARROW, false);
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW, false);
			}
					
			deferred.resolve();
			return deferred.promise;
			//return PanelCommon.doViewSwitchAni(this.widget,'SHOW_FADE_UP');
	    },

		/** Hide ContentViewBase  	 
		* @name hide	 
		* @memberOf ContentViewBase
		* @param {String} animation type
		* @method
		* @return {} 	 
		* */	
	    hide: function(aniType){
	    	var deferred = Q.defer(); 
			print('111111111111111111content-view-base.js self.widget =',self.widget);
			//print('111111111111111111content-view-base.js self.widget id =',self.widget.id);
			if(self.widget != null && self.widget != undefined){
				self.widget.hide();
			}
	    	deferred.resolve();
			return deferred.promise;
			//return PanelCommon.doViewSwitchAni(this.widget,'HIDE_FADE_DOWN');
	    },

		/** Destroy ContentViewBase  	 
		* @name destroy	 
		* @memberOf ContentViewBase
		* @method 
		* @return {}	 
		* */	
		destroy:function(){
			print('content-view-base   destroy');
			//this.widget.hide();
			self.thumbnailColorFlag = false;
			self.thumbnailColorNumber = 0;
			print('content view base  Remove native grid control');
			Volt.Nav.removeItem(self.nativeGridList);
			self.t_DestroyList();

			if(self.thumbListener){
				self.thumbListener.destroy();
				self.thumbListener=null;
			}
		    if(self.nativeGridList){
				self.nativeGridList.loadItemAfterAniFinish = false;
		        HALOUtil.asyncRelease(self.nativeGridList);
				self.nativeGridList = null;
		    }
			if( self.infoWnd&&self.infoWnd.popupWidget != null ){
				self.infoWnd.destroy();
				self.infoWnd = null;
			}
			if(self.folderNoamalImage){
				self.folderNoamalImage.destroy();
				self.folderNoamalImage = null;
			}
			if(self.folderFocusImage){
				self.folderFocusImage.destroy();
				self.folderFocusImage = null;
			}
			//this.widget.destroy();
			//self.collection.close();
			self.stopListening(self.collection, 'adddata', self.UpdateBrowserData);
			self.stopListening(self.collection, 'remove', self.t_DestroyList);
			self.stopListening(self.collection, 'thumbnail', self.updateItem);
			EventMediator.off(EventType.EVENT_TYPE_MUSICPLAYER_DATA_DONE, this.musicDataPrepared, this);
			EventMediator.off(EventType.EVENT_TYPE_MYCONTENT_KEY_PRESS,this.onGridlistKeyEvent,this);
			returnFlag = false;
	   	},
		
		setDefaultFocus: function(){
		    print('---------mcContentViewBase.js setDefaultFocus()');
		 //   Volt.Nav.focus(Volt.Nav.getItem(0));
	   	},

		hideFocus: function(){
			Log.f("content-view-base.js hideFocus()");
			print("content-view-base.js hideFocus()");
			Volt.Nav.beginModal(self.mainView);
		},

		showFocus: function(){
			Log.f("content-view-base.js showFocus()");
			print("content-view-base.js showFocus()");
			Volt.Nav.endModal(self.mainView);
			if(self.mainView.devPopup != null || self.mainView.msgbox != null || self.mainView.popup != null){
				Log.f("content-view-base.js, isGridListFocus0:"+self.isGridListFocus);
				print("content-view-base.js, isGridListFocus0:",self.isGridListFocus);
				//var popupParent = self.mainView.widget.getChild('main-popup-container');
				//Volt.Nav.setRoot(popupParent);
				if(self.mainView.devPopup){
					Volt.Nav.setRoot(self.mainView.devPopup.widget);
					self.mainView.devPopup.setDefaultFocus();
				}
				else if(self.mainView.msgbox){
					Volt.Nav.setRoot(self.mainView.msgbox.widget);
				}
				else{
					print('content-view-base.js, set root to progress popup');
					Volt.Nav.setRoot(self.mainView.popup.widget);
				}
			}
			else{
				Log.f("content-view-base.js, isGridListFocus1:"+self.isGridListFocus);
				print("content-view-base.js, isGridListFocus1:",self.isGridListFocus);
				if(RunTimeInfo.isEditMode == true){
					Volt.Nav.setRoot(self.mainView.widget);
					//Volt.Nav.focus(self.mainView.editModeView.cancelBtn);
				}
				if(self.isGridListFocus && self.nativeGridList != null){
					EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
					self.nativeGridList.enableFocus();
				    self.nativeGridList.showFocus('false');
				    self.nativeGridList.setFocusImage(resMgr.getImgPath()+'/common/ksc_focus.png', -8, -8);
					self.nativeGridList.showFocus("true");
					ViewGlobalData.isGridListFocus = true;
				}
			}
			self.isGridListFocus = false;
		},	 

		/** destroy gridlist   	 
		* @name destoryList	 
		* @memberOf ContentViewBase
		* @method 
		* @return {}	 
		* */	
		destoryList:function(){
			print("content view base destoryList");
			EventMediator.trigger(EventType.EVENT_TYPE_HIDE_NO_DATA);
			self.thumbnailColorFlag = false;
			self.thumbnailColorNumber = 0;
		    if(self.nativeGridList){
				self.nativeGridList.loadItemAfterAniFinish = false;
				self.t_DestroyList();
				self.nativeGridList.hide();
				HALOUtil.asyncRelease(self.nativeGridList);
		        //self.nativeGridList.destroy();
				self.nativeGridList = null;
		    }
			self.destoryItemWidget();
			self.collection.reset();
	   	},

		/** destroy saved gridlist item   	 
		* @name destoryItemWidget	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		destoryItemWidget: function(){
			print('[content-view-base.js] destoryItemWidget()');
			/*
			for(var i=0; i < self.collection.size();i++){
				self.itemWidget[i] = null;
			}*/
	   	},

		/** get girid list item widget by index  	 
		* @name getListItemRootWidget	 
		* @memberOf ContentViewBase
		* @param {int} 
		* @method
		* @return {} 	 
		* */	
		getListItemRootWidget: function(itemIndex){
			print('getListItemRootWidget index =',itemIndex);
			var Renderer = self.nativeGridList.renderer(0, itemIndex);
			if(Renderer != null){
				print('111111111getListItemRootWidget index =',itemIndex);
				return Renderer.thumbnail;
			}
			else{
				print('2222222getListItemRootWidget index =',itemIndex);
				return null;
			}
	   	},

		/** get  item select state from csf by index  	 
		* @name getSelectState	 
		* @memberOf ContentViewBase
		* @param {int} 
		* @method
		* @return {} 	 
		* */	
		getSelectState: function(itemIndex){
			var param ={
         			param_agent: self.collection.getRequestAgent(),
					param_index: itemIndex,
         		};
         	var status = self.collection.csfApi.getSelectStatus(param);
			return status.return_data;
		},

		/** get select count from csf  	 
		* @name getSelectionCount	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		getSelectionCount: function(){
			var param ={
         			param_agent: self.collection.getRequestAgent(),
         		};
         	var selCount  = self.collection.csfApi.getSelectCount(param);
			return selCount.return_data;
		},

		/** set select item state to true to csf  	 
		* @name toggleSelectItem	 
		* @memberOf ContentViewBase
		* @param {int} 
		* @method
		* @return {} 	 
		* */	
		toggleSelectItem: function(item){
 			print('[content-view-base.js]toggleSelectItem item = ',item);
         	var param ={
         			param_agent: self.collection.getRequestAgent(),
     				param_count: 1,
     				param_item_list: item,
         		};
         	self.collection.csfApi.setSelectItem(param);
		},

		/** set select item state to false to csf  	 
		* @name toggleSelectItem	 
		* @memberOf ContentViewBase
		* @param {int} 
		* @method
		* @return {} 	 
		* */	
		toggleDesSelectItem: function(item){
 			print('[content-view-base.js]toggleDesSelectItem item = ',item);
         	var param ={
         			param_agent: self.collection.getRequestAgent(),
     				param_count: 1,
     				param_item_list: item,
         		};
         	self.collection.csfApi.setSelectItem(param);
		},

		/** set all item state to true to csf  	 
		* @name toggleSelectAllItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		toggleSelectAllItem: function(){
			print('[content-view-base.js]toggleSelectAllItem');
		 	//FOLDER_VIEW_FILE_TYPE_IMAGE, 0
            //FOLDER_VIEW_FILE_TYPE_VIDEO, 1
            //FOLDER_VIEW_FILE_TYPE_SOUND,2
            //FOLDER_VIEW_FILE_TYPE_MUSIC, 3
            //FOLDER_VIEW_FILE_TYPE_FOLDER,4
            //FOLDER_VIEW_FILE_TYPE_RECORDTV,5
            //FOLDER_VIEW_FILE_TYPE_M3U,6
            //FOLDER_VIEW_FILE_TYPE_AUDIO,7
            //FOLDER_VIEW_FILE_TYPE_GROUP,  8 //item type: item getted when group music or pvr by album date and so on
            //FOLDER_VIEW_FILE_TYPE_UHD, 9
            //FOLDER_VIEW_FILE_TYPE_SCSA, 10
			var optType = self.mainView.editModeView.optType;
			if(optType == EOptType.eSendType){
				//var typeArr = [0,1,3,9,10];
				var typeArr = [0,1,3,9];
			}
			else{
				//var typeArr = [0,1,3,5,9,10];
				var typeArr = [0,1,3,5,9];
			}
			
         	var param ={
         			param_agent: self.collection.getRequestAgent(),
					param_selected_item_type_arr: typeArr,
         		};
         	var ret = self.collection.csfApi.setSelectAllItems(param);
			var data = JSON.parse(ret);
			self.selTotalSize = data.return_data;
			print('toggleSelectAllItem data:  ',JSON.stringify(ret));
			print('toggleSelectAllItem data:  ',self.selTotalSize);
		},

		/** set all item state to fasle to csf  	 
		* @name toggleDesSelectAllItem	 
		* @memberOf ContentViewBase
		* @method 
		* @return {}	 
		* */	
		toggleDesSelectAllItem: function(){
			print('[content-view-base.js]toggleDesSelectAllItem');
         	var param ={
         			param_agent: self.collection.getRequestAgent(),
         		};
         	self.collection.csfApi.disSelectAllItems(param);
			self.selTotalSize = 0;
		},
		
		reSetColletion:function(){
			self.collection.reset();
		},
		
		updateThumbnailCb:function(){
			print(" content view base updateThumbnailCb ");
			self.collection.updateContentViewThumbnailCb();

		},
		/** Update List Data of ContentViewBase  	 
		* @name updateBrowserData	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		UpdateBrowserData: function(){
			print('content-view-base.js UpdateBrowserData');
			
			/*add the return item*/
	        if(ViewGlobalData.categoryType === 'CATEGORY-FOLDER'){
				if(ViewGlobalData.parentFielPathStack.length != 0 || ViewGlobalData.dlnaContentidStack.length != 0){
					Log.e("parentFielPathStack != 0");
					this.collection.addUpFolderItem();
				}else{
					print('Enable category tab focus >>>>>>>>>>>>>>>>>>>>>>>>>');
					Volt.Nav.addItem(this.mainView.categoryView.categoryList);
					//Volt.Nav.reload();
				}
			}
			else if(ViewGlobalData.categoryType === 'CATEGORY-ARTIST' ||
				ViewGlobalData.categoryType === 'CATEGORY-ALBUM' ||
				ViewGlobalData.categoryType ===  'CATEGORY-GENRE' ||
				ViewGlobalData.categoryType ===  'CATEGORY-CHANNEL_NAME'){				
				if(ViewGlobalData.GroupIndex !== -1){
					Log.e("addUpFolderItem  categoryType = " + ViewGlobalData.categoryType);
					this.collection.addUpFolderItem();
				}
			}
			print("content-view-base.js collection.length:", self.collection.length);
			Log.e("content-view-base.js collection.length:" + self.collection.length);
			if(self.collection.length !== 0){
	            /*this is test for data*/
				print('[UpdateBrowserData] ViewGlobalData.isGridListFocus : ',ViewGlobalData.isGridListFocus);

				//preInitlize playEmp	
				if (self.collection.length == 1 && (ViewGlobalData.parentFielPathStack.length > 0 || ViewGlobalData.dlnaContentidStack.length > 0)){
					EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);
				}
				
				var deviceID = DeviceProvider.getCurrentDeviceId();		
				print("UpdateBrowserData getCurrentDeviceId  deviceID:"+deviceID);
				if(self.mainView.folderPathView != null 
					&& self.mainView.folderPathView.isUHDContentFolder() 
					&& DeviceProvider.isUHDDevice(deviceID)){
					print("UpdateBrowserData set UHDContentFolder = true");
					RunTimeInfo.UHDContentFolder = true;
				}else{
					RunTimeInfo.UHDContentFolder = false;
				}
				
				this.t_CreateList();				
				
				if( RunTimeInfo.isResetByFirstScreen != true ){
					if ( RunTimeInfo.isOptionShowFlag == false ){
						print("content-view-base.js UpdateBrowserData setRoot");
						Log.e("Why setRoot here...  content-view-base.js UpdateBrowserData setRoot");
						if( (ViewGlobalData.parentFielPathStack.length > 0 || ViewGlobalData.dlnaContentidStack.length > 0) ){
							Volt.Nav.setRoot(this.mainView.widget,{focus: self.nativeGridList});
						}
						else{
							if(self.enterFolder){
								//Volt.Nav.setRoot(this.mainView.widget,{focus: self.nativeGridList});
							}
							else{
								Volt.Nav.setRoot(this.mainView.widget);
							}
							
						}
					}
					else{
						RunTimeInfo.isSetroot = true;
					}
				}
				/*enter the sub folder.please set the focus for gridlist*/

				if ( self.nativeGridList ){
		            if(ViewGlobalData.isGridListFocus 
						|| RunTimeInfo.isResetByFirstScreen == true
						|| ViewGlobalData.isEnterByConnectionGuide == true){
												
						if(RunTimeInfo.isResetByFirstScreen == true ){
							print("RunTimeInfo.isResetByFirstScreen :" + RunTimeInfo.isResetByFirstScreen);
							RunTimeInfo.isResetByFirstScreen = false;
							Volt.Nav.setRoot(this.mainView.widget,{focus: self.nativeGridList});
						}
						if(ViewGlobalData.isEnterByConnectionGuide == true){
							print("ViewGlobalData.isEnterByConnectionGuide :" + ViewGlobalData.isEnterByConnectionGuide);
							ViewGlobalData.isEnterByConnectionGuide = false;
							Volt.Nav.setRoot(this.mainView.widget,{focus: self.nativeGridList});
						}
						
						print("UpdateBrowserData self.returnFlag: "+self.returnFlag);
						if(self.returnFlag){
							
							var index = 0;
							try{
								var folder = launchParams.getLastSepcialFolder();
							}catch(e){
								print("UpdateBrowserData getLastSepcialFolder e:"+e);
								Log.e("UpdateBrowserData getLastSepcialFolder e:"+e);
							}
							if(folder != '' && folder != null && folder != undefined){
								//find folder index								
								var i = 0;
								
								print(" search folder name :"+folder);
								Log.e(" search folder name :"+folder);
								
								for(i = 0; i < self.collection.size(); i++){
									var item = self.collection.at(i);
									if(item && item.get('title1') == folder){
										index = i;
										break;
									}									
								}

							}else{
								index = ViewGlobalData.gridlistIndex.pop();
								if ( index > self.collection.size()-1 )
								{
									index = 0;
								}
							}
							print('self.returnFlag = true return setFocusItemIndex:'+index);
							Log.e("self.returnFlag = true return setFocusItemIndex:"+index);
							self.nativeGridList.setFocusItemIndex(0,index);
						}
						self.returnFlag = false;
						self.nativeGridList.enableFocus();
						
						if(ViewGlobalData.lastPlayIndex > -1){
							print('ViewGlobalData.lastPlayIndex > -1 setFocusItemIndex:'+ViewGlobalData.lastPlayIndex);
						//	Log.e('ViewGlobalData.lastPlayIndex > -1 ---1setFocusItemIndex:'+ViewGlobalData.lastPlayIndex);

							self.nativeGridList.setFocusItemIndex(0,ViewGlobalData.lastPlayIndex);
							ViewGlobalData.lastPlayIndex = -1;
							//self.nativeGridList.setFocus();		
							Volt.Nav.focus(self.nativeGridList);					
							self.nativeGridList.showFocus('true');
								
						}


				        if(ViewGlobalData.categoryType === 'CATEGORY-FOLDER'){
							if(ViewGlobalData.parentFielPathStack.length != 0 || ViewGlobalData.dlnaContentidStack.length != 0){
								Volt.Nav.removeItem(this.mainView.categoryView.categoryList);
							}else{
								print('Enable category tab focus >>>>>>>>>>>>>>>>>>>>>>>>>');
								Volt.Nav.addItem(this.mainView.categoryView.categoryList);
								Volt.Nav.reload();
							}
						}
						
						if(self.enterFolder){
							print('UpdateBrowserData >>>>>>>>>>>>>>>>>>>>>>>> set focus to grid list');
							//self.nativeGridList.setFocus();
							Volt.Nav.focus(self.nativeGridList);	
							self.nativeGridList.showFocus('false');
							this.nativeGridList.setFocusImage(resMgr.getImgPath()+'/common/ksc_focus.png', -8, -8);
							self.nativeGridList.showFocus('true');
							self.enterFolder = false;
						}
						
		            }
					else {
			           	if(ViewGlobalData.firstLaunch == true){
								print('*********************************************-----------------------');
								Volt.Nav.focus(self.widget);
								if(this.nativeGridList != null){
									this.nativeGridList.enableFocus();
									//this.nativeGridList.setFocus();
									Volt.Nav.focus(self.nativeGridList);	
									
								//	this.nativeGridList.showFocus("true");
									var tempItem = self.collection.getItem(0);			
									if( tempItem.get('ItemType') == EItemType.eItemFolder ){
										var Renderer = self.nativeGridList.renderer(0, 0);
										if ( Renderer.thumbnail ){
											Renderer.thumbnail.setAttachIcon("icon1",resMgr.getImgPath()+'/foders/mc_icon_foder_zoom.png');
										}
									}
									ViewGlobalData.isGridListFocus = true;
								}							
								ViewGlobalData.firstLaunch = false;
								ViewGlobalData.isGridListFocus = true;								
					
								//add stage
								Stage.show();
								EventMediator.trigger(EventType.EVENT_TYPE_FOCUS_CHANGE, FocusPosition.FOCUS_CONTENT);
	           				}
	           			print('clear return flag');
	           			self.returnFlag = false;
		           	}
					print("UpdateBrowserData >>> RunTimeInfo.isReturnFromMusicPlayer :"+RunTimeInfo.isReturnFromMusicPlayer);
					if(RunTimeInfo.isReturnFromMusicPlayer == true){
						RunTimeInfo.isReturnFromMusicPlayer = false;
						
						self.setFocusReturnFromMusicPlayer();
					}
				}
			}
			else{
				print('[content-view-base.js]updateBrowserData Not Content found in device');
				EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);
				if(ViewGlobalData.firstLaunch == true){
					ViewGlobalData.firstLaunch = false;
				}
			}
		
			if( RunTimeInfo.router.loadControlFlag == false ){
				print('content-view-base.js load control');
				RunTimeInfo.router.loadControlFlag = true;
				EventMediator.trigger(EventType.EVENT_TYPE_LOAD_COMMON_CONTROL);
			}
			if(RunTimeInfo.isFirstLanch){// || RunTimeInfo.isFilterChange){	
				print('[content-view-base.js]----RunTimeInfo.isFirstLanch is true and to showanimateViewSwitch ');
 				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_FILTER_ANIMATION);
				RunTimeInfo.isFirstLanch = false;
				//RunTimeInfo.isFilterChange = false;
			}
						
			RunTimeInfo.isNoContent = false;

		},
		
		setFocusReturnFromMusicPlayer: function(){
			print("content view base setFocusReturnFromMusicPlayer");
							
				/*  enter music player , content thumbnail callback is replace by music player's   */
			self.updateThumbnailCb();
				
			if(launchParams.isLaunchForMusicPlayer() != true){
				print("launchParams.isLaunchForMusicPlayer() != true");
				Log.e("launchParams.isLaunchForMusicPlayer() != true");
				self.playInstance =	Volt.require('app/controller/play-controller.js');
				if ( self.playInstance.getMusicPlayerFocus() ){
					var currentId = self.playInstance.getCurrentContentId();
					var idx = 0;
					if( currentId != undefined ){
						idx = self.collection.getPageIndex(currentId);
					}
					
					if ( idx > self.collection.size()-1 || idx < 0 )
					{
						idx = 0;
					}
					if( idx == undefined){
						idx = 0;
					}
					if( isNaN(idx) ){
						idx = 0;
					}
					print('RunTimeInfo.router.preViewType==EViewType.eMusicPlayerView  setFocusItemIndex:'+idx);

					Log.f('---setFocusItemIndex:'+idx);
					self.nativeGridList.setFocusItemIndex(0,idx);
					self.nativeGridPlayerIndex = idx;
				//	Volt.Nav.focus(self.widget);
					Volt.Nav.setRoot(self.mainView.widget,{focus: self.nativeGridList});
					self.nativeGridList.enableFocus();
					//self.nativeGridList.setFocus();
					//self.nativeGridList.showFocus("true");
					self.playInstance.setMusicPlayerFocus(false);
				}
			}else{
				print("Set root to mainView.widget");

				//Volt.Nav.setRoot(self.mainView.widget);
				Volt.Nav.setRoot(self.mainView.widget,{focus: self.nativeGridList});
			}
		},
		/** Update Select List Item  	 
		* @name updateSelectListItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		updateSelectListItem: function(){
			print('[content-view-base.js] updateSelectListItem() current path = ',ViewGlobalData.currFilePath);

			var sortType = ViewGlobalData.viewSortText[EViewType.eRecordContentView];
			if(sortType == resMgr.getText(SortType.SORT_TYPE_CHANNEL)){
				var totalCount = self.collection.csfApi.getItemCount({
					param_agent : self.collection.agent,			
				});
				var itemCount = totalCount.return_data;
				print('updateSelectListItem sort by channel Count = ',itemCount);
				itemCount = itemCount -1;
			}

			if(sortType == resMgr.getText(SortType.SORT_TYPE_CHANNEL) && itemCount == 0){
				print('updateSelectListItem sort by channel!');
				Log.e('updateSelectListItem sort by channel!');
				self.exitGroup();
			}
			else{
				self.destoryList();
				print('111updateSelectListItem() path = ',ViewGlobalData.currFilePath);
				Log.e("111updateSelectListItem() path = " + ViewGlobalData.currFilePath);
				var curPath = '';
				if(ViewGlobalData.parentFielPathStack.length != 0){
					Log.e("updateSelectListItem is in folder");
	                curPath = ViewGlobalData.currFilePath;
	            }
	            else{
	                curPath = ViewGlobalData.rootPath;
	            }
				self.makeDataSource(curPath);
				self.resetSelectStatus();
			}
		},

		/** set all non recording pvr file select state to true  	 
		* @name toggleSelectAllRecordItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		toggleSelectAllRecordItem: function(){
			print('content-view-base.js toggleSelectAllRecordItem()');
			var num = self.collection.size();
			var itemList = [];
			for(var index = 0;index<num;index++)
			{
			   var item = self.collection.getItem(index);
			   if(item.get('ItemType') == EItemType.eItemPvr){
			   		var itemRecording = item.get('isRecording');
					var isLock = item.get('isLocked');
					
					if(!itemRecording&& !isLock){
						print('toggleSelectAllRecordItem() index = ',index);
						if(self.collection.addUpperFolderItemFlag == true){
							itemList[0] = index - 1;
						}
						else{
							itemList[0] = index;
						}
						/* If the item is selected, do not call csf select interface */
						if(self.getSelectState(itemList[0]) != true){
							self.toggleSelectItem(itemList);
						}
					}
			   }
			}
		},

		/** Update Select All Item  	 
		* @name updateSelAllItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		updateSelAllItem: function(){
			//var num = self.gridList.getItemCount();
			var num = self.collection.size();
			var isSelectFlag = false;
			if(num == 0){
				print('-----updateSelAllItem() number is 0 ');
				return;
			}
			var optType = self.mainView.editModeView.optType;
			//timer.tick('updateSelAllItem start time:');
			if(optType == EOptType.eDeleteType){
				self.toggleSelectAllRecordItem();
			}
			else{
				self.toggleSelectAllItem();   //all files are selected
			}
			//timer.tick('updateSelAllItem end time:');
			print('-----updateSelAllItem() total num = ',num);
            for(var index = 0;index<num;index++)
			{
				var item = self.collection.at(index);
				self.tagItemSelected(index,true);
				if(item.get('ItemType') == EItemType.eItemVideo ||
				   item.get('ItemType') == EItemType.eItemPhoto ||
				   item.get('ItemType') == EItemType.eItemMusic ||
				   item.get('ItemType') == EItemType.eItemPvr ||
				   item.get('ItemType') == EItemType.eItemUHDVideo){
				   print('-----11111111111111111111111111111updateSelAllItem() index = ',index);
				   if(item.get('ItemType') == EItemType.eItemPvr){
				   		var itemRecording = item.get('isRecording');
						var isLock = item.get('isLocked');
						Log.e("updateSelAllItem isRecording:"+itemRecording);
						Log.e("updateSelAllItem isLocked:"+isLock);
						print("updateSelAllItem isRecording:"+itemRecording);
						print("updateSelAllItem isLocked:"+isLock);
				   		if(optType != EOptType.eSendType){
							if(optType == EOptType.eDeleteType && (itemRecording||isLock)){
							}
							else{
								isSelectFlag = true;
							    var renderer = self.nativeGridList.renderer(0, index);
							    if(renderer && renderer.thumbnail){
									//renderer.thumbnail.visualizeAttachIcon(true, "icon1");
									if ( renderer.editNum == 0 ){
										renderer.iconNumber++;
										renderer.editNum = renderer.iconNumber;
										addIconInfo(renderer, renderer.editNum, {
												x: self.params.icon1X, 
												y: self.params.icon1Y, 
												width: self.params.icon1Width, 
												height: self.params.icon1Height,
												async: true,
												unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
												pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
												opacity: 255*0.5,
												clickable: false
											});
									}
									else{
										changeIconInfo(renderer, renderer.editNum, true);
									}
									renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6,});
									dimIconInfo(renderer, renderer.editNum);
							    }
							}
				   		}
				   }
				   else{
					   isSelectFlag = true;
					   var renderer = self.nativeGridList.renderer(0, index);
					   if ( renderer && renderer.thumbnail){
							if ( renderer.editNum == 0 ){
								renderer.iconNumber++;
								renderer.editNum = renderer.iconNumber;
								addIconInfo(renderer, renderer.editNum, {
										x: self.params.icon1X, 
										y: self.params.icon1Y, 
										width: self.params.icon1Width, 
										height: self.params.icon1Height,
										async: true,
										unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
										pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
										opacity: 255*0.5,
										clickable: false
									});
							}
							else{
								changeIconInfo(renderer, renderer.editNum, true);
							}
						   renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6,});
						   dimIconInfo(renderer, renderer.editNum);
					   }
				   	}

				}
				else{
					print('-----222222222222222222NOT updateSelAllItem() index = ',index);
				}
            }
			
			var itemCount = self.getSelectionCount();
			self.updateSelItemNum(itemCount);
			if(itemCount != 0){
				self.mainView.editModeView.setOperationIdHasFocus();
				Volt.Nav.reload();
			}
		},
		
		/** Update Select All Item  	 
		* @name updateSelectItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */

		updateSelectItem: function(index){
			print('----updateSelectItem index = ', index);
			if(self.collection.addUpperFolderItemFlag == true){
				index = index-1;
			}
			var item = self.collection.at(index)
			if(item.get('ItemType') == EItemType.eItemVideo ||
			   item.get('ItemType') == EItemType.eItemPhoto ||
			   item.get('ItemType') == EItemType.eItemMusic ||
			   item.get('ItemType') == EItemType.eItemPvr ||
			   item.get('ItemType') == EItemType.eItemUHDVideo){
			   var renderer = self.nativeGridList.renderer(0, index);
			   if ( renderer && renderer.thumbnail){
				   //renderer.thumbnail.visualizeAttachIcon(true, "icon1");
					if ( renderer.editNum == 0 ){
						renderer.iconNumber++;
						renderer.editNum = renderer.iconNumber;
						addIconInfo(renderer, renderer.editNum, {
								x: self.params.icon1X, 
								y: self.params.icon1Y, 
								width: self.params.icon1Width, 
								height: self.params.icon1Height,
								async: true,
								unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
								pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
								opacity: 255*0.5,
								clickable: false
							});
					}
					else{
						changeIconInfo(renderer, renderer.editNum, true);
					}
					
			   }

			}
		},
		/** Set Item desselected  	 
		* @name setDesSelectItemToCsf	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		setDesSelectItemToCsf: function(){
			print('[content-view-base.js],setDesSelectItemToCsf()');
			print('[content-view-base.js],agent = ',self.collection.getRequestAgent());
         	var param ={
         			param_agent: self.collection.getRequestAgent(),
         		};
         	self.collection.csfApi.disSelectAllItems(param);
		},

		/** Set Item Selected  	 
		* @name setSelectItemToCsf	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		setSelectItemToCsf: function(){
			if(RunTimeInfo.isEditMode == true){
				/*
	     		var itemList = [];
	     		var index = 0;
	     		for(var i=0;i<self.collection.size();i++){
	     			if(self.getItemSelStatus(i) == true){
	     				itemList[index] = (self.collection.addUpperFolderItemFlag) ? (i-1) : i;
	     				index++;
	     			}
	     		}
	     		if(itemList.length != 0){
	     			print('[content-view-base.js]setSelectItemToCsf length = ',itemList.length);
	             	var param ={
	             			param_agent: self.collection.getRequestAgent(),
	         				param_count: itemList.length,
	         				param_item_list: itemList,
	             		};
	             	self.collection.csfApi.setSelectItem(param);
	     		}*/
			}
			else{
				//for long press select
				print('[content-view-base.js]long press setSelectItemToCsf( )');
				if(self.longPressFocusIndex == -1){
					print('[content-view-base.js]longPressFocusIndex is error index = ',self.longPressFocusIndex);
					return;
				}
				var itemList = [];
				itemList[0] = (self.collection.addUpperFolderItemFlag) ? (self.longPressFocusIndex-1) : (self.longPressFocusIndex);
				var param ={
             			param_agent: self.collection.getRequestAgent(),
         				param_count: itemList.length,
         				param_item_list: itemList,
             		};
             	self.collection.csfApi.setSelectItem(param);
			}
		},

		/** Deselect All Item  	 
		* @name DisSelectAllItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		DisSelectAllItem: function(){
			//var num = self.gridList.getItemCount();
			var num = self.collection.size();
			var isSelectFlag = false;
			if(num == 0){
				print('-----updateSelAllItem() number is 0 ');
				return;
			}
			self.toggleDesSelectAllItem();   //set all files select state are false
			print('-----DisSelectAllItem() total num = ',num);
            for(var index = 0;index<num;index++)
			{
				self.tagItemSelected(index,false);    //set base mode select state false
				
			   var item = self.collection.at(index)
			   	if(item.get('ItemType') == EItemType.eItemVideo ||
				   item.get('ItemType') == EItemType.eItemPhoto ||
				   item.get('ItemType') == EItemType.eItemMusic ||
				   item.get('ItemType') == EItemType.eItemPvr ||
				   item.get('ItemType') == EItemType.eItemUHDVideo){
					   var renderer = self.nativeGridList.renderer(0, index);
					   if(item.get('ItemType') == EItemType.eItemPvr){
					   		var itemRecording = item.get('isRecording');
							var isLock = item.get('isLocked');
							if(self.mainView.editModeView.optType == EOptType.eSendType ||
								(self.mainView.editModeView.optType == EOptType.eDeleteType && (itemRecording||isLock))){
								if(renderer && renderer.thumbnail ){
 								   renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
								   renderer.thumbnail.dim(true);
 							    }
							}
							else{
								if(renderer && renderer.thumbnail ){
									changeIconInfo(renderer, renderer.editNum, false);
									renderer.thumbnail.dim(false);
								}
							}
						}
						else{
							if(item.get('isPlayAvailable') == true){
								if(renderer && renderer.thumbnail ){
									changeIconInfo(renderer, renderer.editNum, false);
									renderer.thumbnail.dim(false);
								}	 
							}
							else{
								if(renderer && renderer.thumbnail ){
								   changeIconInfo(renderer, renderer.editNum, false);
 								   renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
								   renderer.thumbnail.dim(true);
 							    }
							}
						}
					   isSelectFlag = false;
			   }
            }
			//var itemCount = self.getSelectionCount();
			self.updateSelItemNum(0);
			//if(itemCount == 0){
				self.mainView.editModeView.setOperationIdNoFocus();
				Volt.Nav.reload();
			//}
		},

		/** Delete Selected Item  	 
		* @name delSelectItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		DelSelectItem: function(){
			print('[content-view-base.js] DelSelectItem()');
			
			Volt.KPIMapper.addEventLog('MY_CONTENT_DELETE');

			var navigatParam = {
				param_agent: RunTimeInfo.router.currentView.collection.getRequestAgent(),
				param_navigation: 1,
			};
			var CsfMgr = Volt.require('app/models/csf-manager.js');
			CsfMgr.setNavigation(navigatParam);    //before send,set navigation to CSF_NAVIGATION_SELECTED
			
			var param = {
				param_agent: self.collection.getRequestAgent(),
				param_share_type: 0x01,
				param_source_device_type: 2,
				param_user_data_addr: 0,
			};
			var ret = self.collection.csfApi.send(param);
			print('[content-view-base.js]DelSelectItem() ret = ',ret);
		},

		/** update Selected Item  	 
		* @name updateSelItemNum	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		updateSelItemNum: function(itemNum){
			//var itemNum = self.getSelItemNum();
			this.mainView.editModeView.widget.getChild(1).text = itemNum.toString();
			/*
			if(itemNum == 0){
				this.mainView.editModeView.widget.getChild(1).text = itemNum.toString();
			}
			else{
				var optType = self.mainView.editModeView.optType;
				if(optType == EOptType.eDeleteType){
					var recordingCount = self.getIsRecordingPvrCount();
					itemNum = itemNum - recordingCount;
					print('updateSelItemNum itemNum = ',itemNum);
					this.mainView.editModeView.widget.getChild(1).text = itemNum.toString();
				}
				else{
					this.mainView.editModeView.widget.getChild(1).text = itemNum.toString();
				}
			}*/
		},

		/** get selected Item counts 	 
		* @name getSelItemNum	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		getSelItemNum: function(){
			var selNum = 0;
			if(self.collection != null){
				for(var index = 0;index < self.collection.size();index++){
					if(self.getSelectState(index) == true){
						selNum++;
					}
				}
			}
			return selNum;
		},
		
		/** set select item status  	 
		* @name tagItemSelected	 
		* @memberOf ContentViewBase
		* @param {int} select item index
		* @param {boolean} bool type
		* @method 
		* @return {}	 
		* */	
		tagItemSelected: function(index, isSel){
			if(index >= 0 && index < self.collection.size())
			{
				var item = self.collection.at(index);
				item.set('isSelected',isSel);
			}
		},

		/** get select item status by index	 
		* @name getItemSelStatus	 
		* @memberOf ContentViewBase
		* @param {int} select item index
		* @method
		* @return {} 	 
		* */	
		getItemSelStatus: function(index){	
			if(index >= 0 && index < self.collection.size()){
				var item = self.collection.at(index);
				var status = item.get('isSelected');
				return status;
			}
			else{
				print('getItemSelStatus index is out of range index = ',index);
				return false;
			}
		},

		/** check if all item is select	 
		* @name getIsSelectStatus	 
		* @memberOf ContentViewBase
		* @method 
		* @return {}	 
		* */	
		getIsSelectStatus: function(){
			var status = false;
			var selectCount = self.getSelectionCount();
			if(selectCount != 0){
				status = true;
			}
			return status;
		},

		/** get recording pvr file count	 
		* @name getIsRecordingPvrCount	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		getUnableDelPvrCount: function(){
			print('content-view-base.js getUnableDelPvrCount()');
			var count = 0;
			var num = self.collection.size();
			for(var index = 0;index<num;index++)
			{
			   var item = self.collection.getItem(index);
			   if(item.get('ItemType') == EItemType.eItemPvr){
			   		var itemRecording = item.get('isRecording');
					var itemLock = item.get('isLocked');
					if(itemRecording || itemLock){
						count++;
					}
			   }
			}
			print('getUnableDelPvrCount() unadle delete count = ',count);
			Log.e("getUnableDelPvrCount() unadle delete count =" + count);
			return count;
		},

		/** get record file count	 
		* @name getRecordFileCount	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		getRecordFileCount: function(){
			print("Content-view-base.js getRecordFileCount()!");
			var pvrFileCount = 0;
			if(RunTimeInfo.isNoContent){
				pvrFileCount = 0;
			}
			else{
				var jsonData = self.collection.csfApi.getItemCount({
						param_agent : self.collection.agent,
						get_item_count_for_each_type: true,
					});
				print('getRecordFileCount data:  ',JSON.stringify(jsonData));
				if(jsonData != null){
					var data = JSON.parse(jsonData.return_data); 
					pvrFileCount = data.item_count_record;
				}
				else{
					pvrFileCount = 0;
				}
			}
			return 	pvrFileCount;
		},
		
		/** check item type	 
		* @name checkAllItemIsFolder	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		checkAllItemIsFolder: function(){
			var status = false;
			var totalCount = 0;
			var folderCount = 0;
			if(RunTimeInfo.isNoContent){
				print("checkAllItemIsFolder there is no content!");
				Log.e("checkAllItemIsFolder there is no content!");
				status = true;
			}
			else{
				var jsonData = self.collection.csfApi.getItemCount({
						param_agent : self.collection.agent,
						get_item_count_for_each_type: true,
					});
				print('checkAllItemIsFolder data:  ',JSON.stringify(jsonData));
				if(jsonData != null){
					var data = JSON.parse(jsonData.return_data); 
					totalCount = data.item_count_all;
					folderCount = data.item_count_folder;
				}
	 			if(totalCount == 0 || (totalCount != 0 && folderCount == totalCount)){
					status = true;
				}
			}
			
			return status;
		},

		/** check item type	 
		* @name checkAllItemIsFolder	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		checkAllItemIsUnableToselect: function(optType){
			print('content-view-base.js checkAllItemIsUnableToselect()');
			var status = false;
			var totalCount = 0;
			var pvrCount = 0;
			var folderCount = 0;
			var jsonData = self.collection.csfApi.getItemCount({
					param_agent : self.collection.agent,
					get_item_count_for_each_type: true,
				});
			print('checkAllItemIsFolder data:  ',JSON.stringify(jsonData));
			if(jsonData != null){
				var data = JSON.parse(jsonData.return_data); 
				totalCount = data.item_count_all;
				folderCount = data.item_count_folder;
				pvrCount = data.item_count_record
			}
			if(optType == EOptType.eDeleteType){
				var recordingCount = self.getUnableDelPvrCount();
				var fileCount = folderCount + recordingCount;
			}
			else if(optType == EOptType.eSendType){
				var fileCount = folderCount + pvrCount;
			}
 			if(totalCount == 0 || (totalCount != 0 && fileCount == totalCount)){
				status = true;
			}
			
			return status;
		},

			
		/** check all item select status	 
		* @name checkAllItemIsSelect	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		checkAllItemIsSelect: function(){
			var status = true;
			var photoCount = 0,videoCount = 0, musicCount = 0;
			var recordCount = 0, uhdCount = 0;
			var jsonData = self.collection.csfApi.getItemCount({
					param_agent : self.collection.agent,
					get_item_count_for_each_type: true,
				});
			print('checkAllItemIsSelect data:  ',JSON.stringify(jsonData));
			if(jsonData != null){
				var data = JSON.parse(jsonData.return_data); 
				photoCount = data.item_count_image;
				videoCount = data.item_count_video;
				musicCount = data.item_count_music;
				recordCount = data.item_count_record;
				uhdCount = data.item_count_uhd;
			} 

			var selectCount = self.getSelectionCount();
			print('checkAllItemIsSelect selectCount = ',selectCount);
			var optType = self.mainView.editModeView.optType;
			if(optType == EOptType.eSendType){
				var totalCount = photoCount + videoCount + musicCount + uhdCount;
			}
			else if(optType == EOptType.ePlaySelType){
				var totalCount = photoCount + videoCount + musicCount + uhdCount + recordCount;
			}
			else{
				var recordingCount = self.getUnableDelPvrCount();
				var totalCount = recordCount - recordingCount;
			}
			print('checkAllItemIsSelect totalCount = ',totalCount);
			if(selectCount == totalCount){
				status = true;
			}
			else{
				status = false
			}
			return status;
		},

		/** reset all item slelect status	 
		* @name resetSelectStatus	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		resetSelectStatus: function(){
			print('resetSelectStatus length = ',self.collection.size());
			//for(var index = 0;index < self.collection.size();index++){
				//self.tagItemSelected(index,false);
			//}
			//self.toggleDesSelectAllItem();
			if(self.mainView.editModeView != null){
				self.selTotalSize = 0;
				var itemNum = 0;
				self.mainView.editModeView.widget.getChild(1).text = itemNum.toString();
				//self.mainView.editModeView.setSelectAllWidgetIcon(selAllCheckBoxIconNor);
				self.mainView.editModeView.setSelectAllBtnText(resMgr.getText('COM_SID_SELECT_ALL'));
				self.mainView.editModeView.setOperationIdNoFocus();
				self.mainView.editModeView.setSelAllFlagStatus(false);
				self.DisSelectAllItem();
			}
			else{
				print('[content-view-base.js]resetSelectStatus() editModeView is NULL!');
			}
		},

		/** get select item size
		* @name getSelItemTitalSize	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
		getSelItemTitalSize: function(){
			var totalSize = 0;
			var count = 0;
			/*
			if(self.collection.addUpperFolderItemFlag == true){
				count = self.collection.size()-1;
			}
			else{
				count = self.collection.size();
			}*/
			/*
			count = self.collection.size()
			for(var index = 0;index < count;index++){
				if(self.getItemSelStatus(index) == true){
					print('getSelItemTitalSize select item =',index);
					var item = self.collection.getItem(index);
					print('1111111getSelItemTitalSize select item =',item);
					if(item.get('ItemType') == EItemType.eItemVideo ||
				   		item.get('ItemType') == EItemType.eItemPhoto ||
				   		item.get('ItemType') == EItemType.eItemMusic ||
				   		item.get('ItemType') == EItemType.eItemUHDVideo){
				 	  var size = item.get('size');
					  print('------------getSelItemTitalSize size = ',size);
					  totalSize += size;
					}
				}
			}*/
			totalSize = self.selTotalSize;
			print('getSelItemTitalSize totalSize = ',totalSize);
			return totalSize;
		},

		/** Update Item  	 
		* @name updateItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
	    updateItem: function(index, bSuccess){
			print('UpdateItem ', index);
			Log.e('UpdateItem ' + index);
			if ( self.gridList != null ){
				self.gridList.updateItem(index);
			}
			else if( self.nativeGridList != null ){
				
				/*
				if(self.isEditMode == true){
					self.updateSelectItem(index);
				}
				*/
				try{
				var renderer = self.nativeGridList.renderer(0, index);
				if ( renderer && renderer.thumbnail ){
					//self.hideBlankThumbnail(renderer);
				}
				var data = self.nativeGridList.getData(0, index);
				if(bSuccess){
					data.ThumbPath = self.collection.getItem(index).get('ThumbPath');
					data.isThumbDone = true;
				}
				else{
					self.setDefaultThumb(data);
					self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );
			
				}
				self.nativeGridList.updateItem(0,index);
				}catch(e){
					Log.e("content view base updateItem e:"+e);
					print("content view base updateItem e:"+e);
				}
			}
		},

		hideBlankThumbnail: function(render){
			if(ViewGlobalData.contentType === 'CONTENT-FOLDER'){
				render.thumbnail.visualizeAttachIcon(false, "icon5");
			}
			else if(ViewGlobalData.contentType === 'CONTENT-IMAGE'){
				render.thumbnail.visualizeAttachIcon(false, 'icon3');
			}
			else if(ViewGlobalData.contentType === 'CONTENT-VIDEO'){
				render.thumbnail.visualizeAttachIcon(false, 'icon4');
			}
			else if(ViewGlobalData.contentType === 'CONTENT-MUSIC'){
				render.thumbnail.visualizeAttachIcon(false, 'icon3');
			}
			else if(ViewGlobalData.contentType === 'CONTENT-PVR'){
				render.thumbnail.visualizeAttachIcon(false, 'icon3');
			}
		},

		setDefaultThumb: function(dataItem){
			if(ViewGlobalData.contentType === 'CONTENT-VIDEO'){
				if( dataItem.ItemType == EItemType.eItemVideo ){
					dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
				}
				return;
			}
			if(ViewGlobalData.contentType === 'CONTENT-PVR'){
				if(dataItem.ItemType == EItemType.eItemPvr){
					dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
					if(dataItem.isLocked){
						dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_adult_n.png';
					}
					if(dataItem.isAudioOnly){
						dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_audio_n.PNG';
					}
				}
				return;

			}
			
			if( dataItem.ItemType == EItemType.eItemVideo || dataItem.ItemType == EItemType.eItemUHDVideo){
				dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
			}
			else if( dataItem.ItemType == EItemType.eItemPhoto){
				dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_photo_n.png';
			}
			else if( dataItem.ItemType == EItemType.eItemMusic){
				dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_music_n.png';
			}					
			else if(dataItem.ItemType == EItemType.eItemPvr){
				dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
				if(dataItem.isLocked){
					dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_adult_n.png';
				}
				if(dataItem.isAudioOnly){
					dataItem.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_audio_n.PNG';
				}
			}
			
		},
		

		/** Set Focus  	 
		* @name setFocus	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		setFocus: function(){
			if(self.gridList == null){
				print('[content-view-bae.js],setFocus() gridlist is null');
				return;
			}
			//self.gridList.setFocus();
			self.gridList.setFocusIndex(0);
			self.focusWidget = FocusPos.OnList;     
		},

		/** Give Focus  	 
		* @name giveFocus	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
		giveFocus: function(){
			if(self.gridList){
				self.gridList.killFocus();
			}
			
       		self.focusWidget = null;
		},
	   
		/**Focus Move Out Callback  	 
		* @name ifMoveOut	 
		* @memberOf ContentViewBase
		* @param {boolean} move direction
		* @method
		* @return {}  	 
		* */
	    ifMoveOut : function(dir) {
	        var bRet = false;
	        var newIndex = 0;
	        if (dir == self.gridList.MOVE_OUT_DIR_UP) {
    	            EventMediator.trigger('EVENT_FOCUS_UP_LIST');
    	            bRet = true;              
	            
					//Todo: change select folder img to normal
					newIndex = self.gridList.getFocusIndex();
					print('==============[ifMoveOut]    newIndex : ', newIndex);
					var newWidget = self.gridList.getWidget(newIndex);
					var newItem = self.collection.at(newIndex);
					if(newItem.get('ItemType') == EItemType.eItemFolder){
					var imgWidget = newWidget.getChild(2);
					print('chage image to normal....');
					imgWidget.src = resMgr.getImgPath()+'/foders/mc_icon_foder.png';
				}
			 }
	        return bRet;
		},

		/**Item Pressed In EditMode  	 
		* @name editModeItemPress	 
		* @memberOf ContentViewBase
		* @param {int}index
		* @param {Object}widget
		* @method 
		* @return {} 	 
		* */		
		editModeItemPress: function(index, widget){
			print('editModeItemPress index = ',index);
			var isUnsupportFile = false;
			var item = self.collection.at(index);
			var optType = self.mainView.editModeView.optType;
			if(item.get('ItemType') == EItemType.eItemPvr){
				var itemRecording = item.get('isRecording');
				var isLock = item.get('isLocked');
				Log.e("editModeItemPress isRecording:"+itemRecording);
				print("editModeItemPress isRecording:"+itemRecording);
				if(optType == EOptType.eSendType){
					return;
				}
				if(optType == EOptType.eDeleteType && (itemRecording||isLock)){
					return;
				}
			}
			else{
				if(item.get('isPlayAvailable') == false){
					isUnsupportFile = true;
				}
			}
			var fileSize = item.get('size');
			var itemWidget = self.getListItemRootWidget(index);
			//if(self.isSelect[index] == true){
			if(self.collection.addUpperFolderItemFlag == true){
				index = index-1;
			}
			var renderer = null;
			if(self.getSelectState(index) == true){
				print('editModeItemPress isSelect is true');
				if(itemWidget != null){
					renderer = null;
    				if(self.collection.addUpperFolderItemFlag == true){
    					self.tagItemSelected(index+1,false);
						renderer = self.nativeGridList.renderer(0, index+1);
    				}else{
    					self.tagItemSelected(index,false);
						renderer = self.nativeGridList.renderer(0, index);
    				}
					if ( renderer && renderer.thumbnail ){
						//renderer.thumbnail.visualizeAttachIcon(false, "icon1");
						changeIconInfo(renderer, renderer.editNum, false);
						if(isUnsupportFile == false){
							renderer.thumbnail.dim(false);
						}
						else{
							renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
							renderer.thumbnail.dim(true);
						}
					}
					var itemList = [];
					itemList[0] = index;
					self.toggleDesSelectItem(itemList);
					
					voiceGuide.play(resMgr.getText('TV_SID_UNCHECKED'));
					self.selTotalSize = self.selTotalSize - fileSize;
					var itemCount = self.getSelectionCount();
    				self.updateSelItemNum(itemCount);
					self.mainView.editModeView.setSelAllFlagStatus(false);
					//self.mainView.editModeView.setSelectAllWidgetIcon(selAllCheckBoxIconNor);
					self.mainView.editModeView.setSelectAllBtnText(resMgr.getText('COM_SID_SELECT_ALL'));
				}
			}
			else{
				if(itemWidget != null){
					renderer = null;
    				if(self.collection.addUpperFolderItemFlag == true){
    					self.tagItemSelected(index+1,true);
						renderer = self.nativeGridList.renderer(0, index+1);
    				}else{
    					self.tagItemSelected(index,true);
						renderer = self.nativeGridList.renderer(0, index);
    				}
					if ( renderer && renderer.thumbnail ){
						if ( renderer.editNum == 0 ){
							renderer.iconNumber++;
							renderer.editNum = renderer.iconNumber;
							addIconInfo(renderer, renderer.editNum, {
									x: self.params.icon1X, 
									y: self.params.icon1Y, 
									width: self.params.icon1Width, 
									height: self.params.icon1Height,
									async: true,
									unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
									pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
									opacity: 255,
									clickable: false
								});
						}
						else{
							//renderer.thumbnail.setElementOpacity("icon1", 255);
							//renderer.thumbnail.visualizeAttachIcon(true, "icon1");
							changeIconInfo(renderer, renderer.editNum, true);
						}
						renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
						dimIconInfo(renderer, renderer.editNum);
					}
					var itemList = [];
					itemList[0] = index;
					self.toggleSelectItem(itemList);
					self.selTotalSize = self.selTotalSize + fileSize;
					voiceGuide.play(resMgr.getText('TV_SID_CHECKED'));
					var itemCount = self.getSelectionCount();
    				self.updateSelItemNum(itemCount);
				}
			}

			if(self.getIsSelectStatus() == true){
				print('----------editModeItemPress exist select item ');
				self.mainView.editModeView.setOperationIdHasFocus();
				if(self.checkAllItemIsSelect() == true){
					//self.mainView.editModeView.setSelectAllWidgetIcon(selAllCheckIconNor);
					self.mainView.editModeView.setSelectAllBtnText(resMgr.getText('SID_DESELECT_ALL'));
					self.mainView.editModeView.setSelAllFlagStatus(true);
				}
			}
			else{
				print('----------editModeItemPress ');
				self.mainView.editModeView.setOperationIdNoFocus();
			}

			Volt.Nav.reload();
		},

		/**Item Pressed Callback  	 
		* @name ifItemPress	 
		* @memberOf ContentViewBase
		* @param {int}index
		* @param {Object}widget
		* @method
		* @return {}  	 
		* */	
		ifItemPress : function(index, widget){
			print('[content-view-base.js] [ifItemPress ] index : '+ index +' widget :' + widget);
			
		
			var item = self.collection.getItem(index);
			var devType = self.getCurrentDeviceType();
			if(item == null){
				print('[ifItemPress]  item = null');
				return;
			}
			if(item.get('ItemType') == EItemType.eItemFolder){
				
				if(devType === DeviceType.DEVICE_TYPE_DLNA){
					return self.enterDlnaFolder(index);
				}
				else if(devType === DeviceType.DEVICE_TYPE_USB){
					return self.enterUsbFolder(index);
				}
			}
			/*return the parent folder*/
			else if(item.get('ItemType') == EItemType.eItemUpFolder){
				if(ViewGlobalData.categoryType === 'CATEGORY-FOLDER'){
					if(devType === DeviceType.DEVICE_TYPE_DLNA){
						return self.backDlnaUpFolder();
					}				
					else if (devType === DeviceType.DEVICE_TYPE_USB){
						return self.backUsbUpFolder();
					}
				}
				else if(ViewGlobalData.categoryType === 'CATEGORY-ARTIST' ||
				ViewGlobalData.categoryType === 'CATEGORY-ALBUM' ||
				ViewGlobalData.categoryType ===  'CATEGORY-GENRE' ||
				ViewGlobalData.categoryType ===  'CATEGORY-CHANNEL_NAME'){	
					return self.exitGroup();
				}
			}
			else if(item.get('ItemType') == EItemType.eItemGroup){
				self.enterIntoGroup(index);
			}
			else if((item.get('ItemType') == EItemType.eItemPhoto)||
				    (item.get('ItemType') == EItemType.eItemVideo)||
				    (item.get('ItemType') == EItemType.eItemPvr)){
				if(RunTimeInfo.isEditMode == false){
					var contentid = self.collection.getItemValue(index, 'CSF_MEDIA_FOCUS_ID');
					self.playItem(item.get('filePath'), item.get('ItemType'), contentid);
				}
				else{
					//self.editModeItemPress(index, widget);
				}
			}
			else if(item.get('ItemType') == EItemType.eItemMusic){
				self.playMusic(index);
			}
			else if(item.get('ItemType') == EItemType.eItemSCSA){	
				self.launchMgo(item);				
			}
		    return;
		},
//UHD start
		isHighestlevel: function(rateLevel){
			if(RunTimeInfo.uhdValidRateCount == 0){
				Log.e(" There is uhdValidRateCount is 0 ");
				
				return false;
			}
			var ratingLevelInfo = RunTimeInfo.uhdRateLevel[RunTimeInfo.uhdValidRateCount - 1];
			
			if(rateLevel == ratingLevelInfo.RATING_INFO_RATE){
				
				return true;
			}
			
			return false;
		},

		
		isLowestlevel: function(rateLevel){

			if(RunTimeInfo.uhdValidRateCount == 0){
				Log.e(" There is uhdValidRateCount is 0 ");
				
				return false;
			}
			
			var ratingLevelInfo = RunTimeInfo.uhdRateLevel[0];

			if(rateLevel == ratingLevelInfo.RATING_INFO_RATE){
				return true;
			}
			
			return false;
		},
		getRateInfoIndex:function(rateLevel){
			var index = 0;
			for(var i = 0; i < RunTimeInfo.uhdValidRateCount; i++){
				var ratingLevelInfo = RunTimeInfo.uhdRateLevel[i];
				
				if(rateLevel == ratingLevelInfo.RATING_INFO_RATE){
					index = i;
					break;
				}
			}
			print('getRateInfoIndex >>>> return index:',index);
			return index;
		},
		
		compareRateLevel:function(rateLevel1, reteLevel2){
			var rateLevel1Index = self.getRateInfoIndex(rateLevel1);
			var rateLevel2Index = self.getRateInfoIndex(reteLevel2);
			print('compareRateLevel >>>>>>>  rateLevel1Index: '+rateLevel1Index+' rateLevel2Index:'+rateLevel2Index);
			if(rateLevel1Index > rateLevel2Index){
				return 1;
			}else if(rateLevel1Index == rateLevel2Index){
				return 0;
			}else {
				return -1;
			}
			
		},
		
		//set rating information  stat
		setRateLevelYesCb:function(){
			print('initialRateLevelYesCb');
			var rating = self.uhdVideoItem.get('rateLevel');
			print('setRateLevelYesCb >>>>>>>>>> set rating:', rating);
			Vconf.setValue('db/mycontents/rating-info',rating);			
			
			var CommMessageBox = Volt.require('app/views/comm-message-box.js');
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
			var deferred =  Q.defer();        	
			
			//one button popup
			var text = resMgr.getText('TV_SID_MIX_UHD_NOT_PLAY_UNTIL_PIN');
			text = text.replace('<<A>>',rating);
			//var text = 'UHD videos rated '+ rating +' or greater will not play until a PIN is entered.';

			var popup = new CommMessageBox();
			popup.setFirstButtonClickCb(self.onYesCb);
			popup.render(MessageType.eMessageBox,text);

			deferred.resolve();
			return deferred.promise;
		},
		onYesCb:function(){
			print("onYesCb ");
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
			Volt.Nav.setRoot(self.mainView.widget,{focus: self.nativeGridList});

		},
		setRateLevelNoCb:function(){
			print('initialRateLevelNoCb');
						
			var CommMessageBox = Volt.require('app/views/comm-message-box.js');
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
			var deferred =  Q.defer();
        	deferred.resolve();
			
			//one button popup
			var text = resMgr.getText('COM_SID_MIX_UHD_VIDEO_RATE_PLAY_BLOCKED');
			text = text.replace('<<A>>', self.uhdVideoItem.get('rateLevel'));
			
			var popup = new CommMessageBox();
			popup.setFirstButtonClickCb(self.onSetRateLevelNoOkCb);
			
			popup.render(MessageType.eMessageBox,text);

			
			deferred.resolve();
			return deferred.promise;
			
		},
		
		onSetRateLevelNoOkCb:function(){
			//Just play this video file
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);	
			print('onSetRateLevelNoOkCb   >>> play UHD video file');
			print("onSetRateLevelNoOkCb RunTimeInfo.uhdValidRateCount : "+RunTimeInfo.uhdValidRateCount);
			
			if(RunTimeInfo.uhdValidRateCount > 0){
				var ratingLevelInfo = RunTimeInfo.uhdRateLevel[RunTimeInfo.uhdValidRateCount - 1];
				print('onSetRateLevelNoOkCb >>>>>>>>>> set rating:', ratingLevelInfo.RATING_INFO_RATE);
				
				Vconf.setValue('db/mycontents/rating-info',ratingLevelInfo.RATING_INFO_RATE);		
			}
						
			Volt.Nav.setRoot(self.mainView.widget,{focus: self.nativeGridList});
		},
		
		showSetRateLevel:function(item,rateLevel,contentid){
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);			
			
			var deferred =  Q.defer();
        	deferred.resolve();
			
			var CommMessageBox = Volt.require('app/views/comm-message-box.js');

			var popup = new CommMessageBox();
			var text = resMgr.getText('COM_SID_MIX_UHD_VIDEO_RATE_RESTRICT_ACCESS');
			text = text.replace('<<A>>', rateLevel);
			print('initialRateLevel  >>>>>  text:',text);	
			popup.setFirstButtonClickCb(self.setRateLevelYesCb);
			popup.setSecondButtonClickCb(self.setRateLevelNoCb);
			popup.render(MessageType.eUHDTwoButton,text);
			
			return deferred.promise;
		},
		//Initial rate level
		
		showPIN:function(rateLevel){
			print('[showInputPIN]~~~~~~~~~~~~~~~~~~');
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);			
			
			var deferred =  Q.defer();
			var isFirstShow = appConfig.getPinFirstShowFlag();
			print('isFirstShow : ',isFirstShow);
			
			var defaultPin = Vconf.getValue('db/menu/system/change_pin')
        	//if first time show pin popup
			print('defaultPin : ',defaultPin);
			var pinNumberPopup = Volt.require('app/views/pin-popup.js');
			var text = resMgr.getText('COM_SID_MIX_UHD_VIDEO_RATING_LOCK_BLOCKED_ENTER_PIN');	
			
			//var firstText = text;
			var defaultPinText;
		//	text = text.replace('<<A>>',rateLevel);	
		//	isFirstShow = "true";
		
			if(isFirstShow != "false"){
				
				if(defaultPin != null && defaultPin != undefined 
					&& defaultPin != '' && defaultPin == '0000'){
					defaultPinText = resMgr.getText('COM_SID_MIX_DEFALUT_PIN_MENU_SYSTEM_CHANGE_PIN').replace('<<A>>',defaultPin);
					
				}
				var setPinText = resMgr.getText('COM_SID_SET_PIN_MENU_SYSTEM_CHANGE_PIN'); 
				
				appConfig.setPinFirstShowFlag('false');
			}
			
			var title = resMgr.getText('COM_SID_LOCK');
			self.pipPopup = new pinNumberPopup();
			self.pipPopup.setPinCodeCorrectCb(self.onPinCorrect);
			try{
				self.pipPopup.render(text,defaultPinText,setPinText,defaultPin,title);
			}catch(e){
				print("render pin popup e:"+e);

			}
			deferred.resolve();
			return deferred.promise;
		},
		onPinCorrect:function(){
			print('Play  UHD video.....');
			self.playUhdVideFile(self.uhdVideoItem.get('filePath'), self.uhdVideoItem.get('ItemType'), self.contentid);

		},
		showNetworkErrorBox:function(){
			print('content-view-base.js showNetworkErrorBox()');
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
			var deferred =  Q.defer();
        	deferred.resolve();
			var CommMessageBox = Volt.require('app/views/comm-message-box.js');
			var popup = new CommMessageBox();
	
			popup.render(MessageType.eNetworkError);
			return deferred.promise;
		},
		
		textDoneCallback:function(object){
			print('[textDoneCallback] ......');

		},
		getNetworkStatus:function(){
			netController = Volt.require('app/controller/net-controller.js');
			Log.e('getNetworkStatus : '+ (netController.getWiredState()|| netController.getWirelessState()));

			return (netController.getCurrentWiredState()|| netController.getCurrentWirelessState());
			//return true;
		},
		
		playGLevel:function(item,rateLevel,contentid){
			print('playGLevel ....  ');
			//if it is G level, play it without any block
			
			self.playUhdVideFile(item.get('filePath'), item.get('ItemType'), contentid);
			
		},
		
		playRLevel:function(item,rateLevel,contentid){
			print('playRLevel ....  ');
			self.showPIN(rateLevel);
		
		},
		
		playOtherLevel:function(item,rateLevel,contentid){
			print('playOtherLevel ....  ');
			//1.init play for the contents: show set rate popup
			//if 
		//	var uhdUnblockRate = appConfig.getUhdUnblockRate();
		//	print("uhdUnblockRate :" + uhdUnblockRate);
			
					
			ViewGlobalData.uhdRisticRate = Vconf.getValue('db/mycontents/rating-info');
			print('ViewGlobalData.uhdRisticRate : ',ViewGlobalData.uhdRisticRate);
		//	ViewGlobalData.uhdRisticRate = '';
			if(ViewGlobalData.uhdRisticRate == '' 
				|| ViewGlobalData.uhdRisticRate == undefined
				|| ViewGlobalData.uhdRisticRate == null){
				//if user did not set rating level, show set rating level popup
				self.showSetRateLevel(item,rateLevel,contentid);
				
			} else {
				if(self.compareRateLevel(item.get('rateLevel'),ViewGlobalData.uhdRisticRate) >= 0){
					print('Show Pin popup~~~');
					self.showPIN(rateLevel);
				}else{
					self.playUhdVideFile(item.get('filePath'), item.get('ItemType'), contentid);
				}

			}		
		
		},
		playUhdVideFile:function(filePath, ItemType, contentid){

			print('playUhdVideFile  filePath:'+filePath +'  ItemType:'+ItemType + '   contentid'+contentid);
			self.playItem(filePath, ItemType, contentid);

		},
		showSetupSmartHub:function(){
			print('showSetupSmartHub');
						
			var CommMessageBox = Volt.require('app/views/comm-message-box.js');
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
			var deferred =  Q.defer();
        	deferred.resolve();
			
			//one button popup
			var text = resMgr.getText('TV_SID_USE_FEATURE_SETUP_SMART_HUB');
						
			var popup = new CommMessageBox();
			
			popup.setFirstButtonClickCb(self.onShowSetupSmartHubYes);
			popup.setSecondButtonClickCb(self.onShowSetupSmartHubNo);
			
			popup.render(MessageType.eUHDTwoButton,text);
			
			deferred.resolve();
			return deferred.promise;

		},
		onShowSetupSmartHubYes:function(){
			//launch  org.tizen.wizard  "uri"   "/usr/etc/wizard/config/wizard-setup.json"   "launcher"   "YOURAPPNAME"
			print("Launch wizard....");
			var arg = {
				"uri":"/usr/apps/org.volt.firstscreen/bin/wizard-smarthub-setting.json",
				"launcher" : "org.volt.mycontents",
			}
			
			AppLauncher.launch("org.tizen.wizard", arg);
		},
		
		onShowSetupSmartHubNo : function(){
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		},
		onCloseTerm:function(){
			print("onCloseTerm  play uhd video self.isLaunchTerm:"+RunTimeInfo.isLaunchTerm);
			if(RunTimeInfo.isLaunchTerm == true){
				RunTimeInfo.isLaunchTerm = false;		
		
				self.uhdContentId = self.uhdVideoItem.get('uhdContentId');
			
				var rateLevel = self.uhdVideoItem.get('rateLevel');
				print("onCloseTerm  rateLevel:" +rateLevel);
				//if it is highest level, show pin popup
				if(self.isHighestlevel(rateLevel)){
					
					self.playRLevel(self.uhdVideoItem,rateLevel,self.contentid);	
					
				} else if(self.isLowestlevel(rateLevel)){			
					//if it is lowest level, just play it.
					self.playGLevel(self.uhdVideoItem,rateLevel,self.contentid);
					
				}else{
			
					self.playOtherLevel(self.uhdVideoItem,rateLevel,self.contentid);
					
				}
				
			}

		},
		playUHDVideo:function(item,contentid){
			print('[playUHDVideo] ~~~~~~~~~~~~~~~~~~~~~~~~~~~');

		//	Vconf.setValue('db/mycontents/rating-info','');	
			
			if(self.getNetworkStatus()== false){				
				self.showNetworkErrorBox();
				return;
			}
			var token = Vconf.getValue(VCONF_ATOKEN);
			if(token == null || token == ''){
				self.showSetupSmartHub();
				return;
			}

			if(item == null || item == undefined){
				print('playUHDVideo item is null ');
				Log.e("playUHDVideo item is null ");
				return;
			}
			var rateLevel = item.get('rateLevel');
			print('playUHDVideo ~~~~~~~~~~~~~~~~~~~rateLevel : ',rateLevel);
			Log.e("playUHDVideo ~~~~~~~~~~~~~~~~~~~rateLevel : " + rateLevel);

						
			self.uhdVideoItem = item;
			self.contentid = contentid;
			self.uhdContentId = item.get('uhdContentId');

			
			var isDisplayUHDTerm = appConfig.getUhdTerm(true);
			print('playUHDVideo >>>>>>>>>> isDisplayUHDTerm : ',isDisplayUHDTerm);
			Log.e("playUHDVideo >>>>>>>>>> isDisplayUHDTerm : "+ isDisplayUHDTerm);
			
		//	isDisplayUHDTerm = 'true';
			
			if(isDisplayUHDTerm == null || isDisplayUHDTerm == 'true'){
				AppLauncher.launch(LaunchAppID.APP_ID_HOME_SETTING, {'task':'menuterm','term':'uhd_video'});
			//	RunTimeInfo.firstUHDVide = false;
				appConfig.setUhdTerm('false')
				RunTimeInfo.isLaunchTerm = true;
				return;
			}

			//if it is highest level, show pin popup
			if(self.isHighestlevel(rateLevel)){
				
				self.playRLevel(item,rateLevel,contentid);	
				
			} else if(self.isLowestlevel(rateLevel)){			
				//if it is lowest level, just play it.
				self.playGLevel(item,rateLevel,contentid);
				
			}else{
		
				self.playOtherLevel(item,rateLevel,contentid);
				
			}
			

		},
		/**Item Long Pressed Callback  	 
		* @name ifItemLongPress	 
		* @memberOf ContentViewBase
		* @param {int}index
		* @param {Object}widget
		* @method 
		* @return {} 	 
		* */	
		ifItemLongPress : function(index, widget){
        	Log.e("[content-view-base.js]ifItemLongPress index =  "+index+", width:"+ widget.width);
        	
        	var clipsPopupListYCoors = 0;
        	var clipsPopupListXCoors = widget.width;
			
        	self.longPressFocusIndex = index;
        	var pos = widget.getAbsolutePosition();
    		clipsPopupListXCoors = clipsPopupListXCoors + pos.x;
    		clipsPopupListYCoors = pos.y;
        	Log.e("[content-view-base.js]ifItemLongPress pos.x =  "+pos.x+", pos.y:"+ pos.y);
			print("ifItemLongPress pos.x =",pos.x);
			print("ifItemLongPress pos.y =",pos.y);
			print("ifItemLongPress widget.width =",widget.width);
			Log.e("ifItemLongPress widget.width ="+widget.width);
			var cpName = null;
			var tempItem = self.collection.getItem(index);
			if( tempItem != null ){
				if( tempItem.get('ItemType') == EItemType.eItemPvr ){
					var itemRecording = tempItem.get('isRecording');
					var isLock = tempItem.get('isLocked');
					print("ifItemLongPress itemRecording =",itemRecording);
					Log.e("ifItemLongPress itemRecording ="+itemRecording);
					Log.e("ifItemLongPress isLock ="+isLock);
					if(itemRecording || isLock){
						cpName = resMgr.getText('COM_TEXT_INFORMATION_P');
					}
					else{
						cpName = resMgr.getText('COM_SID_DELETE');
					}
					
				}
				else{
					cpName = resMgr.getText('COM_TEXT_INFORMATION_P');
				}
			}
			
        	if(self.popupView != null){
				self.popupView.remove();
        	}

			self.popupView = new LongPressPopupView();
			self.popupView.render(widget.width, clipsPopupListXCoors, clipsPopupListYCoors, cpName);       
        },
		
		/**Play Item  	 
		* @name playItem	 
		* @memberOf ContentViewBase
		* @param {String} filepath
		* @param {String} content type
		* @param {int} item content id
		* @method 
		* @return {} 	 
		* */	
		playItem : function(filePath, type, mediaId){
			print('[playItem] filePath : ',filePath, 'type : ',type, 'mediaId : ',mediaId);
			if( RunTimeInfo.playState == 1 ){							//add by hupo for deleting the mini controlbar before launch photo/video player
				self.playInstance.stop();
				EventMediator.trigger(EventType.EVENT_TYPE_PLAYER_ALL_FILEDONE);
			}

			
			if(ViewGlobalData.parentFielPathStack.length != 0){
		        var contentPath = ViewGlobalData.currFilePath;
			}
			else{
				var contentPath = ViewGlobalData.rootPath;
			}
			
		    var select_play = PlayType.PLAY_TYPE_ALL;
            if(RunTimeInfo.isEditMode == true){
			    var prepare_data = self.collection.getPreparePlayData();
				select_play = PlayType.PLAY_TYPE_SELECTED;
			}	

			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			var deviceId = deviceInfo.get('id');
			Log.e('current play device: ' + deviceInfo.get('displayName'));
			var folderId = '/';			
			if(ViewGlobalData.dlnaContentidStack.length != 0){
				folderId = ViewGlobalData.dlnaContentidStack[ViewGlobalData.dlnaContentidStack.length - 1];
			}
			var dlna_name = null;
			if( deviceInfo.get('type') === DeviceType.DEVICE_TYPE_DLNA){
				contentPath = deviceId;		
				dlna_name = deviceInfo.get('displayName');
			}
			if(deviceInfo.get('type') === DeviceType.DEVICE_TYPE_PTP){
				self.collection.cancelPtpThumbnailRequest();
			}
			if(deviceInfo.get('type') != DeviceType.DEVICE_TYPE_DLNA){
				
				var index = filePath.lastIndexOf('/');
				if(index == -1){
					return;
				}
				var fileName    = filePath.substring(index+1);
			}
			var uhd = "false";
			var uhd_contentsid = "";
			if(type == EItemType.eItemUHDVideo){
				uhd = "true";
				uhd_contentsid = self.uhdContentId;
			}
			var windowID = -1;
			try{
				windowID = VDUtil.getXWindowID();
			}
			catch (ex){
				Log.f("[app.js][getXWindowID] Error:" + ex);
			}			
            var args = {
				"app_id"         : 'mycontents',
				"source_type"    : self.getCurrentSource(),
				"file_name"      : fileName,
				"content_path"   : contentPath,
				"content_type"   : ViewGlobalData.contentType,
				"category_type"  : ViewGlobalData.categoryType,
				"prepare_data"   : prepare_data,
				"select_play"    : select_play,
				"device_id"      : deviceId,
				"folder_id"      : folderId,
				"model_name"     : '',
				"bus_value"      : ''+deviceInfo.get('bus'),
				"device_value"   : ''+deviceInfo.get('address'),
				"user_data"      : '',
				"full_path"		 : filePath,
				"media_id"		 : mediaId,
				"root_path"		 : deviceInfo.get('mountPath'),
				"group_index"	 : ''+ ViewGlobalData.GroupIndex,
				"xwindow_id"	 : String(windowID),
				"uhd_device"     : uhd,
				"hdd_serial"	 : deviceInfo.get('serialNumber'),
				"uhd_contentsid" : uhd_contentsid,
				"device_name": dlna_name

            };
			print('type:'+type +'group_index:'+args.group_index);
			print('xwindow_id in args is ', VDUtil.getXWindowID());			

		//	var deviceType = Volt.KPIMapper.getDeviceType(self.getCurrentDeviceType());
			
			if(type == EItemType.eItemPhoto){
				print('startPlaySelItem eItemPhoto');
			//	Volt.KPIMapper.addEventLog(deviceType, {
	        //    	d: {				            		
			//			detail: 'CT01',
		    //		}
	        //	});
			    AppLauncher.launch(LaunchAppID.APP_ID_PHOTO_PLAYER, args);
				//Volt.KPIMapper.enterPage('MY_PHOTO_PG_ENTER');
				Volt.KPIMapper.addEnterLog('MY_PHOTO_PG_ENTER', self.getCurrentDeviceType());
			}
			else if(type == EItemType.eItemVideo || type == EItemType.eItemUHDVideo){
				print('startPlaySelItem video');
			//	Volt.KPIMapper.addEventLog(deviceType, {
	       //     	d: {				            		
			//			detail: 'CT03',
		    //		}
	        //	});
				AppLauncher.launch(LaunchAppID.APP_ID_VIDEO_PLAYER, args);
				//Volt.KPIMapper.enterPage('MY_VIDEO_PG_ENTER');
				Volt.KPIMapper.addEnterLog('MY_VIDEO_PG_ENTER', self.getCurrentDeviceType());	
			}
			else if(type == EItemType.eItemPvr){
				print('startPlaySelItem PVR');
			//	Volt.KPIMapper.addEventLog(deviceType, {
	         //   	d: {				            		
			//			detail: 'CT05',
		    //		}
	        //	});
				AppLauncher.launch(LaunchAppID.APP_ID_PVR_PLAYER, args);
				//Volt.KPIMapper.enterPage('MY_VIDEO_PG');
			}

			RunTimeInfo.playerPause = true;
		},
		
		/**launch Mgo  	 
		* @name launchMgo	 
		* @memberOf ContentViewBase
		* @param {object} play item
		* @method
		* @return {}  	 
		* */
		launchMgo : function(item){
			print("launch MGO");
			var args = {
				runtype:'playback',
				url: item.get('filePath')
			}
			var stringArgs = JSON.stringify(args);
			var payload = 'data='+ encodeURIComponent(stringArgs);
			voltapi.WAS.launchApp("111399000031", payload, 'org.volt.mycontents');
		},

		/**Play Music  	 
		* @name playMusic	 
		* @memberOf ContentViewBase
		* @param {int} play item index
		* @method
		* @return {}  	 
		* */	
		playMusic : function(index){
			print("Play music index:"+index);
			if( self.playInstance.dataAskProcess() ){
				Log.f("in data ask process, don't do again");
				return;
			}
			var startPlayTime = new Date();
			Log.f ("[music-time]select music file in content view: " + startPlayTime.getTime());
			var deviceType = Volt.KPIMapper.getDeviceType(self.getCurrentDeviceType());
			Volt.KPIMapper.addEventLog(deviceType, {
            	d: {				            		
					detail: 'CT02',
	    		}
        	});
						
			self.playInstance.reset();

			var contentid = self.collection.getItemValue(index, 'CSF_MEDIA_FOCUS_ID');		
			print("self.collection.getItemValue CSF_MEDIA_FOCUS_ID is " + contentid);
			self.playInstance.setStartContentID(contentid);
//			self.playInstance.setStartIdx(contentid);
			
			var sortType = 'CATEGORY-FOLDER';
			var contentType = 'CONTENT-MUSIC';

			var sortType = ViewGlobalData.categoryType;
			this.playInstance.dataCollection.setGroupIndex(ViewGlobalData.GroupIndex);

			var devPath = '';
			var devType = self.getCurrentDeviceType();
			if( devType=== DeviceType.DEVICE_TYPE_DLNA ){
				var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
				var scanPath = deviceInfo.get('id');
				var folderId = '/';
				
				if(ViewGlobalData.dlnaContentidStack.length != 0){
					folderId = ViewGlobalData.dlnaContentidStack[ViewGlobalData.dlnaContentidStack.length - 1];
				}
				var options = {
					 	param_source_name : 'csf_local_source_dlna',
					 	param_scan_path: scanPath,
					 	param_content_type: contentType,
					 	param_sort_category: sortType,
					 	param_prepare_data: 'test',
					 	param_folder_id: folderId,
					 	param_requester_id: 'music-player',
				};

				self.playInstance.requestData(options);				
			}
			else if( devType=== DeviceType.DEVICE_TYPE_USB ){
				if(ViewGlobalData.parentFielPathStack.length != 0){
				    devPath = ViewGlobalData.currFilePath;
				}
				else{
					devPath = this.mainView.categoryView.currentMountPath;
				}
				var options = {
					 	param_source_name : 'csf_local_source',
					 	param_scan_path: devPath,
					 	param_content_type: contentType,
					 	param_sort_category: sortType,
					 	param_prepare_data: 'test',
					 	param_requester_id: 'music-player',
				};

				self.playInstance.requestData(options);				
			}
			else if( devType=== DeviceType.DEVICE_TYPE_RA ){
				var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
				var instanceId = deviceInfo.get('instanceID');
				var peerId = deviceInfo.get('id');
				var groupId = deviceInfo.get('groupID');
				var usrData = JSON.stringify({
					csf_ra_command: 'ra_get_photo_list',
					ra_instance_id: instanceId,
					ra_group_id: groupId,
					ra_peer_id: peerId,
					ra_media_id_of_last_query: '',
					ra_max_count: 50,
				});

				var options = {
					param_source_name: 'csf_ra_source',  
					param_scan_path: 'ra',
					param_content_type:'CONTENT-IMAGE',
					param_sort_category: 'CATEGORY-TITLE',
					param_plugin_name : 'libcsf_ra_source.so',
					param_filter:'',
					param_filter_data_type:'',
					param_data_style:0,
					param_prefectch_number:100,
					param_window_size:20,
					param_prepare_data: 'test',
					param_user_data_addr:0,
					param_source_user_data: usrData,
					param_requester_id: 'music-player',
				};
				var endPlayTime = new Date();
				Log.f("[music-time] ready to request data from csf: " + endPlayTime.getTime());				
				self.playInstance.requestData(options);
			}
		},
		
		/**musicDataPrepared  	 
		* @name musicDataPrepared	 
		* @memberOf ContentViewBase
		* @method
		* @return {}  	 
		* */
		musicDataPrepared : function(){
			print('[Content-View-Base.js] get in the musicDataPrepared');
			var getDataTime = new Date();
			print ("[music-time]get csf data for music player ok: ", getDataTime.getTime());			

			self.playInstance.indexReset();
			
			EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
			
			print("content-view-base.js musicDataPrepared switchView to:"+EViewType.eMusicPlayerView);
			Log.e("content-view-base.js musicDataPrepared switchView to:"+EViewType.eMusicPlayerView);

			RunTimeInfo.router.switchToMusicPlayer(EViewType.eMusicPlayerView, EViewSwitchAniType.eNoneAni);			
		},

		musicDataInvalid : function(){
			print('[Content-View-Base.js]: musicDataInvalid');
			EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);//DF150415-00661 when csf failed, to hide loading
			
		},		

		/**Selection  Play  	 
		* @name startPlaySelItem	 
		* @memberOf ContentViewBase
		* @method
		* @return {}  	 
		* */	
		startPlaySelItem : function(){
		    var num = self.collection.size();
            for(var index = 0;index<num;index++){
			    if(self.getSelectState(index) == true){
					print('1111111startPlaySelItem select index = ',index);
					if(self.collection.addUpperFolderItemFlag == true){
						var item = self.collection.getItem(index+1);
					}else{
						var item = self.collection.getItem(index);
					}
					print('-------startPlaySelItem item:',item.get('filePath'));
					print('-------startPlaySelItem item:',item.get('ItemType'));
					var contentid = self.collection.getItemValue(index, 'CSF_MEDIA_FOCUS_ID');
					self.playItem(item.get('filePath'),item.get('ItemType'), contentid);
					self.exitEditMode();
					break;
			    }
			 }
			//self.isEditMode = false;
		},

		/**dimPvrItem	 
		* @name dimPvrItem	 
		* @memberOf ContentViewBase
		* @method 
		* @return {} 	 
		* */	
		dimUnselectableItem: function(optType){
			 print("[content-view-base.js] dimUnselectableItem()");
			 if(self.nativeGridList != null){
				var num = self.collection.size();
				print('-----dimFolderItem() num = ',num);
	            for(var index = 0;index<num;index++)
				{
					var item = self.collection.at(index);
					var itemType = item.get('ItemType');
				   	if(itemType == EItemType.eItemFolder ||itemType == EItemType.eItemUpFolder||
						itemType == EItemType.eItemGroup || itemType == EItemType.eItemSCSA ){
						var renderer = self.nativeGridList.renderer(0, index);
						if (renderer && renderer.thumbnail){
							renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
							renderer.thumbnail.dim(true);
						}
					}
		
					//var itemRecording = false;
					//if( itemType == EItemType.eItemPvr ){
						//itemRecording = item.get('isRecording');
					//}
					//Log.e("dimUnselectableItem isRecording:"+itemRecording);
					//print("dimUnselectableItem isRecording:"+itemRecording);
					if(optType == EOptType.eSendType && itemType == EItemType.eItemPvr){
						var renderer = self.nativeGridList.renderer(0, index);
						if (renderer && renderer.thumbnail){
							renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
							renderer.thumbnail.dim(true);
						}	
					}

					if(optType == EOptType.eDeleteType){
						var itemRecording = false;
						if( itemType == EItemType.eItemPvr ){
							itemRecording = item.get('isRecording');
							var isLock = item.get('isLocked');
							Log.e("dimUnselectableItem isRecording:"+itemRecording);
							print("dimUnselectableItem isRecording:"+itemRecording);
							print("dimUnselectableItem isLock:"+isLock);
							if(itemRecording == true || isLock == true){
								print("111111111111111111itemRecording  index = ",index);
								var renderer = self.nativeGridList.renderer(0, index);
								if (renderer && renderer.thumbnail){
									print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$  index = ",index);
									renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
									renderer.thumbnail.dim(true);
								}	
							}
						}
					}
	            }
			 }
		},
		
	   	/**Enter Edit Mode 	 
		* @name enterEditMode	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
	   enterEditMode : function(optionType){
	        print("--------enter edit mode!");
			if(RunTimeInfo.isEditMode == true){
				print("--------Is already in edit mode!");
				return;
			}
	   		RunTimeInfo.isEditMode = true;
	
			if(this.mainView.categoryView != null)
			{
				print('-----enterEditMode() hide categoryView');
				this.mainView.categoryView.widget.hide();
				this.mainView.categoryView.widget.custom.focusable = false;
				//Volt.Nav.reload();
			}
			
			if(this.mainView.folderPathView != null)
			{
				print('-----enterEditMode() hide folderPathView');
				this.mainView.folderPathView.widget.hide();
			//	this.mainView.folderPathView.widget.getChild(0).custom.focusable = false;
			}
			Volt.Nav.removeItem(self.nativeGridList);
			EventMediator.trigger(EventType.EVENT_TYPE_DIM_HEADVIEW);

			if(this.mainView.editModeView != null)
			{
			    print('-----enterEditMode() destroy widget!');
				//this.mainView.editModeView.widget.getChild('select_all_id').text = resMgr.getText('COM_SID_SELECT_ALL');
				self.mainView.editModeView.setSelectAllBtnText(resMgr.getText('COM_SID_SELECT_ALL'));
				self.mainView.editModeView.setCancelBtnText(resMgr.getText('COM_SID_CANCEL'));
				this.mainView.editModeView.setSelectorBtnText(self.deviceName);
				self.mainView.editModeView.setAllbuttonFocusable(true);
				if(self.checkAllItemIsFolder() == true){
					print('-----enterEditMode() item type is folder!');
					this.mainView.editModeView.setOptionNoFocus();
				}
				else{
					if(optionType == EOptType.eSendType || optionType == EOptType.eDeleteType){
						if(self.checkAllItemIsUnableToselect(optionType) == true){
							this.mainView.editModeView.setOptionNoFocus();
						}
						else{
							this.mainView.editModeView.setOptionHasFocus();
						}
					}
					else{
						this.mainView.editModeView.setOptionHasFocus();
					}
				}
				this.mainView.editModeView.setOperationIdNoFocus();
				this.mainView.editModeView.setCancelWidgetFocus();
				this.mainView.editModeView.setSelectorWidgetFocus();
				this.mainView.editModeView.widget.show();
			}
			else{
				this.mainView.renderCategory(CategoryBannerType.CATEGORY_BANNER_TYPE_EDIT_MODE);
				if(self.checkAllItemIsFolder() == true){
					print('-----enterEditMode() item type is folder!');
					this.mainView.editModeView.setOptionNoFocus();
				}
				else{
					if(optionType == EOptType.eSendType || optionType == EOptType.eDeleteType){
						if(self.checkAllItemIsUnableToselect(optionType) == true){
							this.mainView.editModeView.setOptionNoFocus();
						}
						else{
							this.mainView.editModeView.setOptionHasFocus();
						}
					}
					else{
						this.mainView.editModeView.setOptionHasFocus();
					}
				}
			}

			//Volt.Nav.reload();
			//lt.Nav.removeItem();
			//(self.nativeGridList != null){
				//lt.Nav.focus(self.nativeGridList);
			//
			self.dimUnselectableItem(optionType);
			self.setEditModeDefaultFocus(optionType);

			
			EventMediator.trigger(EventType.EVENT_TYPE_SHOW_DEVIDE_LINE);
			//Volt.Nav.focus(this.mainView.headerView.widget.getChild(2).getChild('main-header-icon-plus-sec'));
	   },

	   /**set edit mode default focus 	 
		* @name setEditModeDefaultFocus	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */
	   setEditModeDefaultFocus: function(optType){
	   		print('content-view-base.js setEditModeDefaultFocus');
			Volt.Nav.focus(null);
			if(this.mainView.folderPathViewFlag == true){
				this.mainView.editModeView.disableDeviceSelector();	
				this.mainView.editModeView.hideDevSelectorBtn();
				var focusWidget = this.mainView.editModeView.cancelBtn;
			}
			else{
				if(optType == EOptType.ePlaySelType){
					var devNum = DeviceProvider.getDeviceCount();
				}
				else{
					var devNum = DeviceProvider.getUsbDeviceCount();
				}
				this.mainView.editModeView.showDevSelectorBtn();
				if(devNum <= 1){
					this.mainView.editModeView.disableDeviceSelector();	
					var focusWidget = this.mainView.editModeView.cancelBtn;
				}
				else{
					this.mainView.editModeView.enableDeviceSelector();
					var focusWidget = this.mainView.editModeView.deviceBtn;
				}
				//this.mainView.editModeView.showDevSelectorBtn();
			}
			Volt.Nav.reload();
			if(self.nativeGridList != null){
				var selAllBtn = this.mainView.editModeView.selAllBtn;
				var cancelBtn = this.mainView.editModeView.cancelBtn;
				if(selAllBtn.custom.focusable == true){
					Volt.Nav.focus(self.nativeGridList);
				}
				else{
					Volt.Nav.focus(cancelBtn);
				}
			}
			else{
				if(focusWidget != null){
					Volt.Nav.focus(focusWidget);
				}
				else{
					print('content-view-base.js focusWidget is null');
					Log.f('content-view-base.js focusWidget is null');
				}
			}
	   },
	   
	   	/**Exit Edit Mode 	 
		* @name exitEditMode	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
	    exitMultiSelectView: function(){
	   		print('content-view-base.js exitMultiSelectView()');
			if(self.nativeGridList != null){
				var num = self.collection.size();
				print('-----exitEditMode() num = ',num);
	            for(var index = 0;index<num;index++)
				{
					var item = self.collection.at(index)
					var itemType = item.get('ItemType');
					self.tagItemSelected(index, false);
					if(itemType == EItemType.eItemFolder||
					   itemType == EItemType.eItemUpFolder||
					   itemType == EItemType.eItemGroup ||
					   itemType == EItemType.eItemSCSA ){
						var renderer = self.nativeGridList.renderer(0, index);
						if (renderer && renderer.thumbnail){
							renderer.thumbnail.dim(false);
						}
					}
					else{
					   	if(itemType == EItemType.eItemVideo || itemType == EItemType.eItemPhoto ||
						   itemType == EItemType.eItemMusic || itemType == EItemType.eItemPvr ||
						   itemType == EItemType.eItemUHDVideo){
							var renderer = self.nativeGridList.renderer(0, index);
							if ( renderer && renderer.thumbnail ){
								//renderer.thumbnail.visualizeAttachIcon(false, "icon1");
								changeIconInfo(renderer, renderer.editNum, false);
								if(item.get('ItemType') == EItemType.eItemPvr){
									//if(self.mainView.editModeView.optType == EOptType.eSendType){
										//renderer.thumbnail.dim(false);
									//}
									renderer.thumbnail.dim(false);
								}
								else{
									if(item.get('isPlayAvailable') == true){
										renderer.thumbnail.dim(false);
									}
									else{
										renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
										renderer.thumbnail.dim(true);
									}
								}
							}

						}
					}
	            }
			}
	   },
	   
	   	/**Exit Edit Mode 	 
		* @name exitEditMode	 
		* @memberOf ContentViewBase
		* @method 	 
		* */	
	   exitEditMode : function(){
	        if(RunTimeInfo.isEditMode == false){
				print("Is already exit edit mode!");
				return;
	        }

			//self.toggleDesSelectAllItem();

			self.exitMultiSelectView();
	   		RunTimeInfo.isEditMode = false;	
			self.mainView.editModeView.setSelAllFlagStatus(false);
			self.mainView.editModeView.setAllBtnNoFocus();
			//self.mainView.editModeView.setSelectAllWidgetIcon(selAllCheckBoxIconNor);
			self.mainView.editModeView.setSelectAllBtnText(resMgr.getText('COM_SID_SELECT_ALL'));
			self.mainView.editModeView.widget.hide();
			//self.mainView.categoryView.widget.show();
			print('current category view = ',self.mainView.curCategoryType);
			if(self.mainView.curCategoryType == CategoryType.CATEGORY_VIEW){
				print('current category view is CATEGORY_VIEW');
				self.mainView.categoryView.widget.show();
				self.mainView.categoryView.widget.custom.focusable = true;
			}
			else{
				EventMediator.trigger(EventType.EVENT_TYPE_HIDE_DEVIDE_LINE);
				self.mainView.folderPathView.widget.show();
//				self.mainView.folderPathView.widget.getChild(0).custom.focusable = false;
			}
			EventMediator.trigger(EventType.EVENT_TYPE_UNDIM_HEADVIEW);
			self.mainView.editModeView.setAllbuttonFocusable(false);

			Volt.Nav.reload();
			//var itemCount = self.getSelectionCount();
			self.updateSelItemNum(0);
	   },
	   
	 	/**Enter Usb Folder 	 
		* @name enterUsbFolder	 
		* @memberOf ContentViewBase
		* @param {int} folder index
		* @method
		* @return {} 	 
		* */	
	   enterSpecialFolder : function(rootPath, subfolder){
				
			EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
			ViewGlobalData.isGridListFocus = true;
			var subFolder = subfolder + '/';
	  
		   	var devPath  = rootPath +'/' + subFolder;
			print('enterSpecialFolder, devPath:' + devPath);
		
			//push root path firstly
			ViewGlobalData.parentFielPathStack.push(rootPath);
		
			/*abtain the current folder of parent folderr*/
			var index = subFolder.indexOf('/');
			var preIndex = 0;
			var i = 0;
			if(index != -1){
				while(index != -1){
					i++;
					print("while *********** enterSpecialFolder index:"+index);
					Log.e("while *********** enterSpecialFolder index:"+index);
					if(index+1 < subFolder.length){
						var parentPath = rootPath + '/' + subFolder.substring(0,index);
						print("enterSpecialFolder parentPath:"+parentPath);
						ViewGlobalData.parentFielPathStack.push(parentPath);
					}
					var folderName = subFolder.substring(preIndex,index);	
					print("enterSpecialFolder folderName:"+folderName);
					EventMediator.trigger(EventType.EVENT_TYPE_ADD_FOLDER_PATH, folderName);
					
					print("enterSpecialFolder preIndex:"+preIndex);
					print("enterSpecialFolder subFolder.length:"+subFolder.length);
					//skip '/' 
					preIndex = index+1;					
					var restSubFolder = subFolder.substring(preIndex, subFolder.length);
					Log.e("enterSpecialFolder restSubFolder:"+restSubFolder);

					index = restSubFolder.indexOf('/');
					print("enterSpecialFolder restSubFolder / index:"+index);
					if(index == -1){
						break;
					}
					index = index + preIndex;
				}
			}else{

				EventMediator.trigger(EventType.EVENT_TYPE_ADD_FOLDER_PATH, subfolder);
			}
		
			
			if(ViewGlobalData.parentFielPathStack.length > 0){
				self.widget.color = {r:0, g:0, b:0, a:0};
			}
			ViewGlobalData.currFilePath = devPath;
			/*enter the sub folder*/
			self.destoryList();

			//enter folder flag.
			self.enterFolder = true;
			//self.enterSepcialFolder = true;
			EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);

		//	self.destoryItemWidget();
			self.makeDataSource(devPath);
			//self.mainView.renderHeader(false);
			
			self.mainView.curCategoryType = CategoryType.FOLDER_PATH_VIEW;
			//add folder path				
			
			EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);
			

			if(RunTimeInfo.visibleCursor == true){
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_ROOT_ARROW);
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
			}
			
	   },
	   
	   	/**Enter Usb Folder 	 
		* @name enterUsbFolder	 
		* @memberOf ContentViewBase
		* @param {int} folder index
		* @method
		* @return {} 	 
		* */	
	   enterUsbFolder : function(index){
	   		if(RunTimeInfo.isEditMode == true){
				print('content-view-base.js enterUsbFolder() edit mode is true!');
				return;
	   		}			
			EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
			ViewGlobalData.isGridListFocus = true;
			
	   		var item = self.collection.getItem(index);
	   		var devPath  = item.get('filePath');
			print('---enterUsbFolder, devPath:'+devPath);
			Log.e("---enterUsbFolder, devPath:"+devPath);
			ViewGlobalData.gridlistIndex.push(index);
			
			/*abtain the current folder of parent folderr*/
			var index = devPath.lastIndexOf('/');
			if(index != -1){
				var parentPath = devPath.substring(0,index);
				ViewGlobalData.parentFielPathStack.push(parentPath);
			}
			if(ViewGlobalData.parentFielPathStack.length > 0){
				self.widget.color = {r:0, g:0, b:0, a:0};
			}
			ViewGlobalData.currFilePath = devPath;
			/*enter the sub folder*/
			self.destoryList();
			
			//add folder path				
			var folderName  = item.get('title1');
			print(" enterUsbFolder  folderName: "+folderName);

			EventMediator.trigger(EventType.EVENT_TYPE_ADD_FOLDER_PATH, folderName);	

			//enter folder flag.
			self.enterFolder = true;
			EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);

		//	self.destoryItemWidget();
			self.makeDataSource(devPath);
			//self.mainView.renderHeader(false);
			self.updateHeaderViewRootArrow();
			self.mainView.curCategoryType = CategoryType.FOLDER_PATH_VIEW;
	
			EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);

			if(RunTimeInfo.visibleCursor == true){
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_ROOT_ARROW);
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
			}
			
	   },

		/**Back Usb UpFolder 	 
		* @name backUsbUpFolder	 
		* @memberOf ContentViewBase
		* @method
		* @return {} 	 
		* */	
	   backUsbUpFolder : function(){
	   		if(RunTimeInfo.isEditMode == true){
				print('content-view-base.js backUsbUpFolder() edit mode is true!');
				return;
	   		}
			Volt.KPIMapper.addEventLog('MY_CONTENT_UPPERFORDER');
			EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
			ViewGlobalData.isGridListFocus = true;
			print(" ViewGlobalData.parentFielPathStack.pop() ");
			var devPath  = ViewGlobalData.parentFielPathStack.pop();
			if(ViewGlobalData.parentFielPathStack.length === 0){
				self.widget.color = Volt.hexToRgb('#dfdfdf',255);
			}
			ViewGlobalData.currFilePath = devPath;
			self.returnFlag = true;
			/*enter the sub folder*/
			self.destoryList();
			self.destoryItemWidget();
			EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
			self.enterFolder = true;
			
			if(ViewGlobalData.parentFielPathStack.length === 0){
				EventMediator.trigger(EventType.EVENT_TYPE_DESTROY_FOLDER_PATH);				
			 } else {	 			
				EventMediator.trigger(EventType.EVENT_TYPE_DEL_FOLDER_PATH);	
				self.mainView.curCategoryType = CategoryType.FOLDER_PATH_VIEW;
			}
			 
			self.makeDataSource(devPath);
			
			self.updateHeaderViewRootArrow();
			//delete folder path
			if(ViewGlobalData.parentFielPathStack.length === 0){

				if(RunTimeInfo.isEditMode == true){
					EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);
				}
				else{
					EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				}
				self.mainView.curCategoryType = CategoryType.CATEGORY_VIEW;
				
				if(RunTimeInfo.visibleCursor == true){
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
					EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ROOT_ARROW);
				}
			} 
			
	   },
	   
	   	/**Entern DLNA Folder	 
		* @name enterDlnaFolder	 
		* @memberOf ContentViewBase
		* @param {int} folder index
		* @method 
		* @return {}	 
		* */	
	   enterDlnaFolder : function(index){
	   		if(RunTimeInfo.isEditMode == true){
				print('content-view-base.js enterDlnaFolder() edit mode is true!');
				return;
	   		}
			EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
			ViewGlobalData.isGridListFocus = true;
	   		var item = self.collection.getItem(index);
			var contentid = self.collection.getItemValue(index, 'ID_CSF');
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			ViewGlobalData.dlnaContentidStack.push(contentid);
			if(ViewGlobalData.dlnaContentidStack.length > 0){
				self.widget.color = {r:0, g:0, b:0, a:0};
			}
			var focusItem = self.nativeGridList.getFocusItemIndex();
			var index = focusItem.itemIndex;
			ViewGlobalData.gridlistIndex.push(index);

			var devPath  = deviceInfo.get('id');
			self.destoryList();
			self.destoryItemWidget();

			self.enterFolder = true;
			EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
			self.makeDataSource(devPath);
			//self.mainView.renderHeader(false);
			self.updateHeaderViewRootArrow();
			self.mainView.curCategoryType = CategoryType.FOLDER_PATH_VIEW;
			var folderName  = item.get('title1');
			EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);
			EventMediator.trigger(EventType.EVENT_TYPE_ADD_FOLDER_PATH, folderName);

			if(RunTimeInfo.visibleCursor == true){
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_ROOT_ARROW);
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
			}

			/*
			if(RunTimeInfo.isEditMode == true){
				self.resetSelectStatus();
				if(self.mainView.folderPathViewFlag == true){
					self.mainView.editModeView.disableDeviceSelector();	
				}
				else{
					self.mainView.editModeView.enableDeviceSelector();
				}
			}*/
			  		
	   },

		/**Back DLNA UpFolder 	 
		* @name backDlnaUpFolder	 
		* @memberOf ContentViewBase
		* @method 
		* @return {}	 
		* */	
	   backDlnaUpFolder : function(){
	   		if(RunTimeInfo.isEditMode == true){
				print('content-view-base.js backDlnaUpFolder() edit mode is true!');
				return;
	   		}
	   		Volt.KPIMapper.addEventLog('MY_CONTENT_UPPERFORDER');
			EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
			ViewGlobalData.isGridListFocus = true;
			
	   		ViewGlobalData.dlnaContentidStack.pop();
			if(ViewGlobalData.dlnaContentidStack.length === 0){
				self.widget.color  = Volt.hexToRgb('#dfdfdf',255);
			}
	   		var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			var devPath = deviceInfo.get('id');
			self.returnFlag = true;
	   		self.destoryList();
			self.destoryItemWidget();
			EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
			self.enterFolder = true;
			
			self.makeDataSource(devPath);
			self.updateHeaderViewRootArrow();
			//delete folder path

			if(ViewGlobalData.dlnaContentidStack.length === 0){
				EventMediator.trigger(EventType.EVENT_TYPE_DESTROY_FOLDER_PATH);
				if(RunTimeInfo.isEditMode == true){
					EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);
				}
				else{
					EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				}
				self.mainView.curCategoryType = CategoryType.CATEGORY_VIEW;

							
				if(RunTimeInfo.visibleCursor == true){
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
					EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ROOT_ARROW);
				}
			} else {
				EventMediator.trigger(EventType.EVENT_TYPE_DEL_FOLDER_PATH);
				self.mainView.curCategoryType = CategoryType.FOLDER_PATH_VIEW;
			}
			/*
			if(RunTimeInfo.isEditMode == true){
				self.resetSelectStatus();
				if(self.mainView.folderPathViewFlag == true){
					self.mainView.editModeView.disableDeviceSelector();	
				}
				else{
					self.mainView.editModeView.enableDeviceSelector();
				}
			}*/

	   },
	   
	   	/**Enter Group
		* @name enterIntoGroup	 
		* @memberOf ContentViewBase
		* @param {int} group index
		* @method
		* @return {} 	 
		* */	
	   enterIntoGroup : function(index){
	   		if(RunTimeInfo.isEditMode == true){
				print('content-view-base.js enterIntoGroup() edit mode is true!');
				return;
	   		}
	   		var focusItem = self.nativeGridList.getFocusItemIndex();
			var focusIndex = focusItem.itemIndex;
			ViewGlobalData.gridlistIndex.length = 0;
			ViewGlobalData.gridlistIndex.push(focusIndex);
			ViewGlobalData.isRootGroup = false;
			ViewGlobalData.GroupIndex  = focusIndex;

			var devPath  = ViewGlobalData.rootPath;

			if(self.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA){
				var contentid = self.collection.getItemValue(index, 'ID_CSF');
				ViewGlobalData.dlnaContentidStack.push(contentid);

			}
				self.enterFolder = true;
			/*enter the sub folder*/
			self.destoryList();
			self.destoryItemWidget();
			EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
			self.makeDataSource(devPath);
			/*
			if(RunTimeInfo.isEditMode == true){
				self.resetSelectStatus();
			}*/
	   },
	   
	    /**Exit Group 
		* @name exitGroup	 
		* @memberOf ContentViewBase
		* @method 
		* @return {}	 
		* */	
	   exitGroup : function(){
	   		if(RunTimeInfo.isEditMode == true){
				print('content-view-base.js enterIntoGroup() edit mode is true!');
				return;
	   		}
	   		var devPath  = ViewGlobalData.rootPath;
			print('devPath:'+devPath);
			self.returnFlag = true;
			ViewGlobalData.GroupIndex = -1;
			ViewGlobalData.isRootGroup = true;
			if(self.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA){
				ViewGlobalData.dlnaContentidStack.pop();
			}
			self.enterFolder = true;
			self.destoryList();
			EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
			self.makeDataSource(devPath);	
	   },
	   
	   	/**Request Usb Data Source
		* @name requestUsbDataList	 
		* @memberOf ContentViewBase
		* @param {String} device path
		* @param {enum} content type
		* @param {enum} sort type
		* @method
		* @return {} 	 
		* */
		
			
	   requestUsbDataList : function(path,contentType, categoryType){

	   		// get board info for UHD video
	   		var duid = Vconf.getValue(VCONF_DUID);
			var token = Vconf.getValue(VCONF_ATOKEN);
			var tokenex = Vconf.getValue(VCONF_ATOKENEXPTIME);
			var contrycode = Vconf.getValue(VCONF_COUNTRYCODE);
			var langId = Vconf.getValue('db/menu_widget/language');
			var id = self.mainView.categoryView.currentID;
			print('requestUsbDataList>>>>>>>>>>>>>>>>>>>>> currentID:',id);
			var uhd = DeviceProvider.isUHDDevice(id);
			var options = {
				 	param_source_name : 'csf_local_source',
				 	param_scan_path: path,
				 	param_content_type: contentType,
				 	param_sort_category: categoryType,
				 	param_prepare_data: 'test',
				 	param_is_uhd:uhd,
				 	param_lang_id:langId,
				 	param_duid:duid,
				 	param_country:contrycode,
				 	param_access_token:token,
				 	param_update_flag:false
			};
			ViewGlobalData.contentType = options.param_content_type;
			ViewGlobalData.categoryType = options.param_sort_category;
			self.collection.requestList(options);
	   },
	   
	    /**Request DLNA Data Source
		* @name requestDlnaDataList	 
		* @memberOf ContentViewBase
		* @param {enum} content type
		* @param {enum} sort type
		* @method
		* @return {}  	 
		* */	
	   requestDlnaDataList : function(contentType, categoryType){
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			var scanPath = deviceInfo.get('id');
			var folderId = '/';
			
			if(ViewGlobalData.dlnaContentidStack.length != 0){
				folderId = ViewGlobalData.dlnaContentidStack[ViewGlobalData.dlnaContentidStack.length - 1];
			}
			var options = {
				 	param_source_name : 'csf_local_source_dlna',
				 	param_scan_path: scanPath,
				 	param_content_type: contentType,
				 	param_sort_category: self.getAvailableCategory(categoryType),
				 	param_prepare_data: 'test',
				 	param_folder_id: folderId,
			};
			ViewGlobalData.contentType = options.param_content_type;
			ViewGlobalData.categoryType = options.param_sort_category;
			self.collection.requestList(options);

			
	   },

	    /**Request RA Data Source
		* @name requestRaDataList	 
		* @memberOf ContentViewBase
		* @param {enum} content type
		* @param {enum} sort type
		* @method 	 
		* */	
	   requestRaDataList : function(contentType, categoryType){
			print('[Content View Base] requestRADataList');
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			var instanceId = deviceInfo.get('instanceID');
			var peerId = deviceInfo.get('id');
			var groupId = deviceInfo.get('groupID');
			var usrData = JSON.stringify({
				csf_ra_command: 'ra_get_photo_list',
				ra_instance_id: instanceId,
				ra_group_id: groupId,
				ra_peer_id: peerId,
				ra_media_id_of_last_query: '',
				ra_max_count: 50,
			});

			var options = {
				param_source_name: 'csf_ra_source',  
				param_scan_path: 'ra',
				param_content_type:'CONTENT-IMAGE',
				param_sort_category: 'CATEGORY-TITLE',
				param_plugin_name : 'libcsf_ra_source.so',
				param_filter:'',
				param_filter_data_type:'',
				param_data_style:0,
				param_prefectch_number:100,
				param_window_size:20,
				param_prepare_data: 'test',
				param_user_data_addr:0,
				param_source_user_data: usrData,
			};
			ViewGlobalData.contentType = options.param_content_type;
			ViewGlobalData.categoryType = options.param_sort_category;
			self.collection.requestList(options);

	   },

		/**Request PTP Data Source
		* @name requestPTPData	 
		* @memberOf ContentViewBase
		* @param {enum} content type
		* @param {enum} categoryType
		* @method 	 
		* */	
		requestPTPDataList : function(contentType, categoryType){
			print('[Content View Base] requestPTPDataList');
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
	   		var modelName = deviceInfo.get('modelName');
	   		var deviceValue = parseInt(deviceInfo.get('address'));
	   		var busValue = parseInt(deviceInfo.get('bus')); 		
			var options = {
				 	param_source_name: 'csf_local_source_ptp',
				 	param_model_name: 'USB PTP Class Camera',
				 	param_scan_path: 'ptp',
				 	param_bus_value: busValue,
				 	param_device_value: deviceValue,
				 	param_content_type: 'CONTENT-IMAGE',
				 	param_sort_category: 'CATEGORY-TITLE',
				 	param_prepare_data: 'test',
				 	param_playlist_name: '',
				 	param_is_only_playlist: false,
			};
			ViewGlobalData.contentType = options.param_content_type;
			ViewGlobalData.categoryType = options.param_sort_category;
			self.collection.requestList(options);

		},
		
		events: {
		    'NAV_FOCUS':'onFocus',
		    'NAV_BLUR':'onBlur'
		},

		/**Focus In Callback
		* @name onFocus	 
		* @memberOf ContentViewBase
		* @param {widget}focus widget
		* @method 	 
		* */	
    	onFocus: function(widget){
	        print('[mcContentViewBase.js] function onFocus');
			if(self.gridList != null){
	            //self.gridList.setFocus();
				ViewGlobalData.isGridListFocus = true;
				EventMediator.trigger(EventType.EVENT_TYPE_FOCUS_CHANGE, FocusPosition.FOCUS_CONTENT);
			}
    	},

		/**Focus Out Callback
		* @name onFocus	 
		* @memberOf ContentViewBase
		* @param {widget} lose focus widget
		* @method 	 
		* */	
	    onBlur: function(widget){
	        print('[mcContentViewBase.js] function onBlur');
	        if( self.gridList != null ){
	        	self.gridList.killFocus();
				print(" ViewGlobalData.isGridListFocus = false");
				ViewGlobalData.isGridListFocus = false;
	        }
	    },

    	/**NativeGridListCallback
		* @name nativeGridListCallback	 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		nativeGridListCallback:function(){
			print('------------------nativeGridListCallback');
			
			if ( self.nativeGridList == null ){
				return true;
			}				
			
			var focusItem = self.nativeGridList.getFocusItemIndex();
			var index = focusItem.itemIndex;
			var item = self.collection.getItem(index);
			var devType = self.getCurrentDeviceType();
			if(item == undefined || item == null){
				return true;
			}
			print('------------------nativeGridListCallback, index',index);
			print('Item type >>>>>>>>>>>>>>>>>>>>>>>>>>>> : ',item.get('ItemType'));
			if(item.get('ItemType') == EItemType.eItemFolder){
				if(devType === DeviceType.DEVICE_TYPE_DLNA){
					return self.enterDlnaFolder(index);
				}
				else if(devType === DeviceType.DEVICE_TYPE_USB){
					return self.enterUsbFolder(index);
				}
			}
			else if(item.get('ItemType') == EItemType.eItemUpFolder){
				if(ViewGlobalData.categoryType === 'CATEGORY-FOLDER'){
					if(devType === DeviceType.DEVICE_TYPE_DLNA){
						return self.backDlnaUpFolder();
					}				
					else if (devType === DeviceType.DEVICE_TYPE_USB){
						return self.backUsbUpFolder();
					}
				}
				else if(ViewGlobalData.categoryType === 'CATEGORY-ARTIST' ||
				ViewGlobalData.categoryType === 'CATEGORY-ALBUM' ||
				ViewGlobalData.categoryType ===  'CATEGORY-GENRE' ||
				ViewGlobalData.categoryType ===  'CATEGORY-CHANNEL_NAME'){	
					return self.exitGroup();
				}
			}
			else if(item.get('ItemType') == EItemType.eItemGroup){
				self.enterIntoGroup(index);
			}
			else if((item.get('ItemType') == EItemType.eItemPhoto)||
				    (item.get('ItemType') == EItemType.eItemVideo)||
				    (item.get('ItemType') == EItemType.eItemPvr)||
				    (item.get('ItemType') == EItemType.eItemUHDVideo)){
				if(RunTimeInfo.isEditMode == false){
					
					var devItem = DeviceProvider.getCurrentDevice();
					if(!devItem){
						print(" nativeGridListCallback getCurrentDevice return null ");
						return ;
					}
					var devType = devItem.get('type');
					var vpValue = 0;
					
					if(devItem.get('uhd') == true){
						vpValue = 1;
					}
					
					if(devType == DeviceType.DEVICE_TYPE_USB){		
						Volt.KPIMapper.addEventLog('MY_CONTENTS_USB', {
				             d: {
				                detail : Volt.KPIMapper.getItemType(item.get('ItemType')),
								vp: vpValue,
				            }
				        });
			      
					}
					else if(devType == DeviceType.DEVICE_TYPE_DLNA){
							Volt.KPIMapper.addEventLog('MY_CONTENTS_DLNA', {
					             d: {
					                detail : Volt.KPIMapper.getItemType(item.get('ItemType')),
									vp: vpValue,
					            }
				        	});
					}
					
					print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');
					RunTimeInfo.disconnectCurrentDevice = false;
					var contentid = self.collection.getItemValue(index, 'CSF_MEDIA_FOCUS_ID');
					var isSupport = false;
					if(item.get('ItemType') == EItemType.eItemPvr){
						self.playItem(item.get('filePath'), item.get('ItemType'), contentid);
					}
					else{
					
						if(item.get('ItemType') == EItemType.eItemUHDVideo){
							self.playUHDVideo(item,contentid);
						}else{	
							self.playItem(item.get('filePath'), item.get('ItemType'), contentid);
						}
					
					}			


				}
				else{
					self.editModeItemPress(index,null);
				}
			}
			else if(item.get('ItemType') == EItemType.eItemMusic){
				print('music view edit mode ---------------',RunTimeInfo.isEditMode);
				if(RunTimeInfo.isEditMode == true){
					self.editModeItemPress(index,null);
				}
				else{				
					self.playMusic(index);
				
				}
			}
			else if(item.get('ItemType') == EItemType.eItemSCSA){	
				self.launchMgo(item);
			}
			
    	},

		onGridlistKeyEvent:function(keycode){								//for DF150123-00950
			Log.f("get key event from gridlist: " + keycode);
			print("get key event from gridlist: " + keycode);
			self.onKeyEvent(keycode,Volt.EVENT_KEY_RELEASE);
    	},
		
    	/**Key Pressed Callback
		* @name onKeyEvent	 
		* @memberOf ContentViewBase
		* @param {int}keycode
		* @param {enum} keytype
		* @method 	 
		* */
		onKeyEvent:function(keycode, keytype){
			print('[contentviewbase.js] function onKeyEvent------------------isEditMode = ' + RunTimeInfo.isEditMode + ', keycode = ' + keycode +', keytype = ' + keytype);
			if(keytype != Volt.EVENT_KEY_RELEASE){
				return false;
			}
			
			var ret = true;
			
			switch(keycode) {
				case Volt.KEY_RETURN:
					if(RunTimeInfo.isEditMode == true){
						if(self.mainView.editModeView != null && self.mainView.editModeView.isFocusEditMode == true){
							//Volt.Nav.focus(Volt.Nav.getItem(0));
							self.mainView.editModeView.isFocusEditMode = false;
						}
						self.exitEditMode();
						Volt.Nav.focus(Volt.Nav.getItem(0));
						return true;
					}
					else{
						self.handleNormalReturnKey();
					}
					break;
				case Volt.KEY_PLAY:
					self.handlePlayKey();
					break;
				case Volt.KEY_INFO:
					print('[content-view-base.js]onKeyEvent---------------------KEY_INFO');
					self.showDetailInfo();
					break;
				case Volt.KEY_JOYSTICK_DOWN:
					var focusItem = self.nativeGridList.getFocusItemIndex();
					var idx = focusItem.itemIndex;
					print("[contentviewbase.js] function onKeyEvent KEY_JOYSTICK_DOWN idx:"+idx);
					if(self.downEdge){
						try{
							AUI.play(HALOUtil.MOVE_NOKEY);
						}catch(e){
							Log.e(" e: AUI.play(HALOUtil.MOVE_NOKEY); e :"+e);
						}					
					}
					break;
				default:
					ret = false;
					break;
			}
			return ret;
    	},

		/**handle play key
		* @name handlePlayKey	 
		* @memberOf ContentViewBase
		* @param {int} keycode,
		* @param {enum}  keytype
		* @method 	 
		* */
		handlePlayKey: function(){
			print('content-view-base.js handlePlayKey()');
			if(inputController.getBlockFlag()){
				print('[content-view-base.js]handlePlayKey----------------------------block input');
				return ;
			}
			if(self.nativeGridList != null){
				var focusItem = self.nativeGridList.getFocusItemIndex();
				var index = focusItem.itemIndex;
				var item = self.collection.getItem(index);
				print('content-view-base.js, onKeyEvent4 select index:'+index+', ItemType'+item.get('ItemType'));

				if(item.get('ItemType') == EItemType.eItemUpFolder){
					
					return true;
				}else if((item.get('ItemType') == EItemType.eItemPhoto)||
					    (item.get('ItemType') == EItemType.eItemVideo)||
					    (item.get('ItemType') == EItemType.eItemPvr)){
					if(RunTimeInfo.isEditMode == false){
						RunTimeInfo.disconnectCurrentDevice = false;
						var contentid = self.collection.getItemValue(index, 'CSF_MEDIA_FOCUS_ID');
						self.playItem(item.get('filePath'), item.get('ItemType'), contentid);
					}
					else{
						RunTimeInfo.router.onViewPlaySelect();
					}
				}
				else if(item.get('ItemType') == EItemType.eItemMusic){
					print('music view edit mode ---------------',RunTimeInfo.isEditMode);
					if(RunTimeInfo.isEditMode == true){
						RunTimeInfo.router.onViewPlaySelect();
					}
					else{
						self.playMusic(index);
					}
				}else if((item.get('ItemType') == EItemType.eItemUHDVideo)){
					var contentid = self.collection.getItemValue(index, 'CSF_MEDIA_FOCUS_ID');
					self.playUHDVideo(item,contentid);

				}
			}
    	},

		/**process normal return key
		* @name processNormalReturnKey	 
		* @memberOf ContentViewBase
		* @param {int} keycode
		* @param {enum}  keytype
		* @method 	 
		* */
		handleNormalReturnKey: function(){
			print('content-view-base.js processNormalReturnKey()');
			if(self.nativeGridList != null){
			   	var devType = self.getCurrentDeviceType();
			   	print('[contentviewbase]  devType  =====  ',devType);
			    if(devType === DeviceType.DEVICE_TYPE_DLNA){
			    	if(ViewGlobalData.dlnaContentidStack.length != 0 && ViewGlobalData.categoryType === 'CATEGORY-FOLDER'){
						self.backDlnaUpFolder();
			    	}
			    	else if(!ViewGlobalData.isRootGroup){
						self.exitGroup();					
					}
					else{
						print('[contentviewbase] dlna exit ~~~~~~~~~~~~~~~~~');
						Volt.KPIMapper.addEventLog('MY_CONNECT_DEVICE', {
				             d: {
				                detail: DeviceProvider.getDeviceCount(),
								dlna: DeviceProvider.getDLNADeviceCount(),
								usb: DeviceProvider.getUsbDeviceCount(),
				            }
				        });
						print('[contentviewbase] dlna addEventLog MY_CONNECT_DEVICE ~~~~~~~~~~~~~~~~~');
						Volt.exit();
					}
			    }
			    else if(devType === DeviceType.DEVICE_TYPE_USB || devType === DeviceType.DEVICE_TYPE_PTP){
			    	if(ViewGlobalData.parentFielPathStack.length != 0){
						self.backUsbUpFolder();			
					} 
					else if(!ViewGlobalData.isRootGroup){
						
						self.exitGroup();					
					}
					else{
						print('[contentviewbase] usb exit ~~~~~~~~~~~~~~~~~');
						//{detail=ConnectedCount;dlna=DLNA;mobile=MOBILE;pc=PC;usb=USB}; 
						//{detail=3;dlna=0;mobile=0;pc=0;usb=3};
						Volt.KPIMapper.addEventLog('MY_CONNECT_DEVICE', {
				             d: {
				                detail: DeviceProvider.getDeviceCount(),
								dlna: DeviceProvider.getDLNADeviceCount(),
								usb: DeviceProvider.getUsbDeviceCount(),
				            }
				        });
						print('[contentviewbase] addEventLog MY_CONNECT_DEVICE ~~~~~~~~~~~~~~~~~');
						Volt.exit();
					}
			    }		  
            }else{
            	Volt.KPIMapper.addEventLog('MY_CONNECT_DEVICE', {
		             d: {
		                detail: DeviceProvider.getDeviceCount(),
						dlna: DeviceProvider.getDLNADeviceCount(),
						usb: DeviceProvider.getUsbDeviceCount(),
		            }
		        });
            	Volt.exit();
            }
		},
	    
	    /**Get Option Text
		* @name getOptionText	 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		getOptionText : function(){
		    /*this index is must refer the optionText array*/
            if(this.mainView.headerView.optionParam.secondSelectedIndex[0] == -1){
                var filterType = 'All';
			}
			else{
				var filterIndex = this.mainView.headerView.optionParam.secondSelectedIndex[0];
				var filterType = resMgr.getText(VideoFilterTextList.DeviceTypeTextList[filterIndex]);
			}
			if(this.mainView.headerView.optionParam.secondSelectedIndex[1] == -1){
				var sortType = 'Title';
			}
			else{
				var sortIndex = this.mainView.headerView.optionParam.secondSelectedIndex[1];
				var sortType = resMgr.getText(VideoSortByTextList.DeviceTypeTextList[sortIndex]);
			}
			var optionText = [];
			if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB){
				var id = self.mainView.categoryView.currentID;
				if( ViewGlobalData.parentFielPathStack.length != 0 && DeviceProvider.isUHDDevice(id) ){
					optionText = self.getUHDText();
				}
				else{
					if ( this.mainView.folderPathViewFlag == false ){
						if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB){
							optionText = [
						        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
						    ];
							var tempLen = optionText.length;
							if(self.mainView.getRecordSupportFlag() == 1){
								optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_DEL);
							}
							tempLen = optionText.length;
							optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY);
							if ( self.mainView.getCopySupportFlag() ){
								tempLen = optionText.length;
								optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_COPY);
							}
					
						}
						else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA){
							optionText = [
									        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
								            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
								            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),

									    ];				
						}
						else{
							optionText = [
									        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
								            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
								            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),

									    ];
						}
					}
					else{
						print('content-view-base.js optionMenuSubIndex[0]: ', this.mainView.popupView.optionMenuSubIndex[0])
						if ( this.mainView.popupView.optionMenuSubIndex[0] > 0 ){
							if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB){
								optionText = [
							        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
						            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
							    ];
								var tempLen = optionText.length;
								if(self.mainView.getRecordSupportFlag() == 1){
									optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_DEL);
								}
								tempLen = optionText.length;
								optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY);
								if ( self.mainView.getCopySupportFlag() ){
									tempLen = optionText.length;
									optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_COPY);
								}
							}
							else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA){
								optionText = [
										        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
									            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
									            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),

										    ];				
							}
							else{
								optionText = [
									        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
								            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
								      		resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
									    	];
							}
						}
						else{
								optionText = [
									        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
								            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
								            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
									    	];
						}
					}

					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					
					if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB){
						if ( optionText[2] && optionText[2] == resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_DEL) ){
							self.isDimFirstPlus[2] = true;
						}
					}
					
					var id = self.mainView.categoryView.currentID;

					if (self.mainView.getCopySupportFlag() && (DeviceProvider.getUsbDeviceCount() <= 1|| DeviceProvider.isUHDDevice(id) )){
						self.isDimFirstPlus[4] = true;
					}


					/*please set the optionText need to show second popup*/
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = true;
					self.isShowSecPlus[2] = false;
					self.isShowSecPlus[3] = false;
					self.isShowSecPlus[4] = false;

				}
			}
			else{
				optionText = [];
				if(this.mainView.folderPathViewFlag){
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = false;
				}
				else{
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = true;
					self.isShowSecPlus[2] = false;
					
				}

				
			}
			this.mainView.headerView.optionParam.firstOptionText = optionText;
			this.mainView.headerView.optionParam.firstHeight = 72*(optionText.length);
		},

		/**Get Current Sort Type
		* @name getCurrentCategory	 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		getCurrentCategory : function(){
		    //var SelectIndexText = this.mainView.categoryView.categoryList.getActiveWidget().text;		
			//var SelectIndex     = this.mainView.categoryView.categoryList.getSelectIndex();	
			var SelectIndex     = this.mainView.categoryView.getCurrentCategoryIndex();	
			print("SelectIndex::::::::::::::"+SelectIndex);
			var SelectIndexText = this.mainView.categoryView.categories[SelectIndex];
			
			print('categorieView text:'+ SelectIndexText);		
			var index ;		
			for(index = 0; index <= CategoriesName.length; index++){			
				if(SelectIndexText.indexOf(CategoriesName[index]) != -1){			  	
					break;  			
				}		
			}		
			print("index::::::::::::::"+index);
			return CategoriesName[index];
	    },

		/**Get Current Filter Type
		* @name getFilterText	 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		getFilterText : function(){
		    var text;
		
			/*here is not base on current view,because All/Video/Photo/Music View 
			Filter text is same*/
			var SelectIndex  = self.mainView.categoryView.getCurrentCategoryIndex();		
			var id = self.mainView.categoryView.categoriesID[SelectIndex];
			var devItem = DeviceProvider.getDeviceInfo(id);
			if(!devItem){
				print('getFilterText devItem == null');
				return;
			}	
			if (devItem.get('type') == DeviceType.DEVICE_TYPE_DLNA ){
				print('getFilterText DLNA');
				if(self.mainView.getRecordSupportFlag() == 1){
					text = self.getResourceText(VideoFilterTextList.DeviceTypeTextList);
				}
				else{
					text = self.getResourceText(VideoFilterTextList.DeviceTypeNoRecordTextList);
				}
			}
			else if(devItem.get('type') == DeviceType.DEVICE_TYPE_RA){
				print('getFilterType RA');
				if(self.mainView.getRecordSupportFlag() == 1){
					text = self.getResourceText(VideoFilterTextList.DeviceTypeTextList);
				}
				else{
					text = self.getResourceText(VideoFilterTextList.DeviceTypeNoRecordTextList);
				}
			}
			else{
				print('getFilterText USB');
				if(self.mainView.getRecordSupportFlag() == 1){
					text = self.getResourceText(VideoFilterTextList.DeviceTypeTextList);
				}
				else{
					text = self.getResourceText(VideoFilterTextList.DeviceTypeNoRecordTextList);
				}
			}
			if( this.mainView.headerView.filterView.optionMenuSubIndex[0] > (text.length-1) ){
				this.mainView.headerView.filterView.optionMenuSubIndex[0] = text.length-1;
			}
			return text;
	    },

		getSwitchToView :  function(text){        
			 /*this is only for usb*/
			 var viewTo;
			 
			 switch(text){
				/*Filter*/
				case resMgr.getText('UID_FILTER_ALL'):
					viewTo = EViewType.eAllContentView;
					break;

				case resMgr.getText('COM_SID_PHOTOS'):
					viewTo = EViewType.ePhotoContentView;
					break;

				case resMgr.getText('COM_SID_VIDEOS'):
					viewTo = EViewType.eVideoContentView;
					break;

				case resMgr.getText('COM_TV_SID_MUSIC'):
					viewTo = EViewType.eMusicContentView;
					break;

				case resMgr.getText('COM_RECORDED_KR_CONTENT'):
					viewTo = EViewType.eRecordContentView;
					break;

				default:
					break;
			}
			return viewTo;
		},
		
		getKPIFilter : function(eFilterType)  {
			var KpiFilter = 'SID_ALL';
			if(eFilterType == EViewType.eAllContentView){
				KpiFilter = 'SID_ALL';
			}
			else if(eFilterType == EViewType.ePhotoContentView){
				KpiFilter = 'SID_PHOTO';
			}
			else if(eFilterType == EViewType.eVideoContentView){
				KpiFilter = 'SID_VIDEO';
			} 
			else if(eFilterType == EViewType.eMusicContentView){
				KpiFilter = 'SID_MUSIC';
			} 
			else if(eFilterType == EViewType.eRecordContentView){
				KpiFilter = 'SID_RECORDED_TV';
			}
			else {
				KpiFilter = 'SID_ALL';
			}
			
			print('[kpi-mapper-mycontents.js]getKPIFilter - ' + KpiFilter);

		   return KpiFilter;
	    },

		getKPISort : function(eSortText)  {
			var sortType = 'SID_ALL';
			if(eSortText == resMgr.getText('COM_SID_DATE')){
				sortType = 'SID_DATE';
			}
			else if(eSortText == resMgr.getText('COM_SID_TITLE')){
				sortType = 'SID_TITLE';
			}
			else if(eSortText == resMgr.getText('COM_SID_FOLDER')){
				sortType = 'SID_FORLDER';
			}
			else if(eSortText == resMgr.getText('COM_BDP_STR_MODE_REPEAT_TRACK_ONE')){
				sortType = 'FBID_TRACK';
			}
			else if(eSortText == resMgr.getText('COM_SID_ALBUM')){
				sortType = 'SID_ALBUM';
			}
			else if(eSortText == resMgr.getText('COM_SID_ARTIST')){
				sortType = 'SID_ARTIST';
			}
			else if(eSortText == resMgr.getText('COM_SID_GENRE')){
				sortType = 'SID_GENRE';
			}
			else if(eSortText == resMgr.getText('UID_M_M_CHANNEL')){
				sortType = 'UID_M_M_CHANNEL';
			}
			else {
				sortType = 'SID_ALL';
			}
			
			print('[kpi-mapper-mycontents.js]getKPISort - ' + sortType);

		   return sortType;
	    },

		getArrItemsId : function(index){
            var item = self.collection.getItem(index);
			if(item == null){
				return '';
			}
			
            if((item.get('ItemType') == EItemType.eItemFolder)  ||
			   (item.get('ItemType') == EItemType.eItemUpFolder)||
			   (item.get('ItemType') == EItemType.eItemGroup)){
			   
           		return gridlistID.FOLDERID;
           	}
			else{
				return gridlistID.NOFOLDERID;
	        }
		},
		
		
		/**Get Current Source Type
		* @name getCurrentSource	 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		getCurrentSource : function(){
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			var source = 'csf_local_source';
			switch(deviceInfo.get('type')){
				case DeviceType.DEVICE_TYPE_USB:
					source = 'csf_local_source';
					break;
					
				case DeviceType.DEVICE_TYPE_DLNA:
					source = 'csf_local_source_dlna';
					break;
				case DeviceType.DEVICE_TYPE_PTP:
					source = 'csf_local_source_ptp';
					break;
				case DeviceType.DEVICE_TYPE_RA:
					source = 'csf_ra_source';
					break;
				default:
					break;
			}
			return source;
		},


		getCurrentSourceInt : function (){
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			var sourceInt  = 102;
			switch(deviceInfo.get('type')){
				case DeviceType.DEVICE_TYPE_USB:
					source = CSFSourceType.CSF_EX_USB_ID;
					break;
					
				case DeviceType.DEVICE_TYPE_DLNA:
				case DeviceType.DEVICE_TYPE_RA:
					source = CSFSourceType.CSF_EX_FACEBOOK_ID;
					break;

				case DeviceType.DEVICE_TYPE_PTP:
					source = CSFSourceType.CSF_EX_PTP_ID;
					
				default:
					break;
			}
			return source;
		},
		
		getCurrentDeviceType : function(){
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			var devType = null;
			if(deviceInfo != null){
				devType =  deviceInfo.get('type');
			}
			return devType;
		},
		
		getAvailableCategory : function(sortType){
			var deviceInfo = DeviceProvider.getDeviceInfo(this.mainView.categoryView.currentID);
			if(deviceInfo.get('type') === DeviceType.DEVICE_TYPE_DLNA ){
				return 'CATEGORY-FOLDER';
			}			
			return sortType;	
		},
		
		isInRootPath : function(){
			var devType = self.getCurrentDeviceType();
			print("isInRootPath >>> devType:" + devType);
			if(devType === DeviceType.DEVICE_TYPE_DLNA){
				print("ViewGlobalData.dlnaContentidStack.length :"+ViewGlobalData.dlnaContentidStack.length);
				return (ViewGlobalData.dlnaContentidStack.length > 0) ? false : true;
			}
			else if(devType === DeviceType.DEVICE_TYPE_USB){
				
				print("ViewGlobalData.parentFielPathStack.length :"+ViewGlobalData.parentFielPathStack.length);

				return (ViewGlobalData.parentFielPathStack.length > 0) ? false : true;	
			}			
			print("isInRootPath >>> return false:");
			return false;
		},
		
		updateHeaderViewRootArrow : function(){
			return;

		},

		/** Reset Last Play Index
		* @name resetFocusFromPlayer	 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		resetFocusFromPlayer : function(mediaId){
			print('return from player');
			if(self.nativeGridList == undefined && self.nativeGridList == null)
			{
				print('self.nativeGridList == undefined && self.nativeGridList == null');
				return;
			}
			var index = self.collection.getPageIndex(mediaId);
			ViewGlobalData.lastPlayIndex = index; 
			ViewGlobalData.isGridListFocus = true;
			print('Page Index is', index);	
		},

		showLastPlayIndex : function(){
			if(ViewGlobalData.lastPlayIndex > -1){
				print('showLastPlayIndex   setFocusItemIndex:'+ViewGlobalData.lastPlayIndex);

				self.nativeGridList.setFocusItemIndex(0,ViewGlobalData.lastPlayIndex);
				ViewGlobalData.lastPlayIndex = -1;
				//self.nativeGridList.setFocus();		
				Volt.Nav.focus(self.nativeGridList);					
				self.nativeGridList.showFocus('true');
					
			}
		},

		showDetailInfo : function(){
			print('[content-view-base.js]showDetailInfo------------------------------begin');			
			Volt.KPIMapper.addEventLog('MY_CONTENT_INFO_POPUP');
			try{
			var InfoWindowTemplate = Volt.require('app/templates/1080/content-information-box-template.js');
			var InfoWindow = Volt.require('app/views/content-information-box.js');

			var focusItem = self.nativeGridList.getFocusItemIndex();
			var index = focusItem.itemIndex;
			var item = self.collection.getItem(index);
			
			print('content-view-base.js, onKeyEvent1 select index:'+index+', ItemType'+item.get('ItemType'));
			if(item.get('ItemType') == EItemType.eItemPhoto){
				print('[contentviewbase.js] function onKeyEvent------Info Photo ');
				
				var photoItem = self.collection.getPhotoDetail(index);

				self.infoWnd = new InfoWindow();
				self.infoWnd.setcontentTitle(photoItem.get('title'));
				self.infoWnd.setcontentCreateTime(photoItem.get('creatTime'));
				self.infoWnd.setcontentFormat(photoItem.get('format'));
				self.infoWnd.setcontentSize(photoItem.get('size'));
				
				var photoWidth = photoItem.get('width');
				var photoHeight = photoItem.get('height');
				var Resolution = photoWidth+'x'+photoHeight;
				self.infoWnd.setcontentResolution(Resolution);	
				self.infoWnd.setcontentLocation(photoItem.get('location'));
				
				self.infoWnd.render(InfoWindowTemplate.info_window_template_photo);
				self.infoWnd.setDefaultFocus();

			}
			else if(item.get('ItemType') == EItemType.eItemMusic){
				print('[contentviewbase.js] function onKeyEvent------Info Music ');
				
				var musicItem = self.collection.getMusicDetail(index);

				self.infoWnd = new InfoWindow();
				self.infoWnd.setcontentTitle(musicItem.get('title'));
				self.infoWnd.setcontentArtist(musicItem.get('artist'));
				self.infoWnd.setcontentAlbum(musicItem.get('album'));
				self.infoWnd.setcontentGenre(musicItem.get('genre'));
				self.infoWnd.setcontentSavedData(musicItem.get('lastSaveDate'));
				self.infoWnd.setcontentDuration(musicItem.get('duration'));
				self.infoWnd.setcontentGenre(musicItem.get('genre'));
				self.infoWnd.setcontentSize(musicItem.get('size'));
				self.infoWnd.setcontentLocation(musicItem.get('location'));
				self.infoWnd.setcontentFormat(musicItem.get('format'));
				self.infoWnd.render(InfoWindowTemplate.info_window_template_music);
				self.infoWnd.setDefaultFocus();

			}
			else if(item.get('ItemType') == EItemType.eItemVideo){
				print('[contentviewbase.js] function onKeyEvent------Info Video ');

				var videoItem = self.collection.getVideoDetail(index);

				self.infoWnd = new InfoWindow();
				
				self.infoWnd.setcontentTitle(videoItem.get('title'));
				self.infoWnd.setcontentSavedData(videoItem.get('lastSaveDate'));
				self.infoWnd.setcontentDuration(videoItem.get('duration'));
				self.infoWnd.setcontentFormat(videoItem.get('format'));
				
				self.infoWnd.setcontentSize(videoItem.get('size'));
				self.infoWnd.setcontentResolution(videoItem.get('resolution'));
				self.infoWnd.setcontentLocation(videoItem.get('location'));
				self.infoWnd.render(InfoWindowTemplate.info_window_template_video);
				self.infoWnd.setDefaultFocus();

			}else if(item.get('ItemType') == EItemType.eItemUHDVideo){
			
				print('[contentviewbase.js] function onKeyEvent------Info Video ');

				var videoItem = self.collection.getUHDVideoDetail(index);

				self.infoWnd = new InfoWindow();
				
				self.infoWnd.setcontentTitle(videoItem.get('displayName'));
				self.infoWnd.setcontentGenre(videoItem.get('genre'));
				self.infoWnd.setcontentDuration(videoItem.get('duration'),true);
				self.infoWnd.setcontentFormat(videoItem.get('format'));
				
				self.infoWnd.setcontentSize(videoItem.get('size'));
				self.infoWnd.setcontentResolution(videoItem.get('resolution'));
				self.infoWnd.setcontentLocation(videoItem.get('location'));
				self.infoWnd.render(InfoWindowTemplate.info_window_template_uhd_video);
				self.infoWnd.setDefaultFocus();
				

			} else if(item.get('ItemType') == EItemType.eItemPvr){
				print('[contentviewbase.js] function showDetailInfo------Info Record ');
				var pvrItem = self.collection.getRecordDetail(index);
				print('getItemDetail end')
				try{
					var pvrInfoWindow = Volt.require('app/views/content-information-box-pvr.js');
				}
				catch(e){
					print("pvr info window error" + e);
				}
				self.infoWnd = new pvrInfoWindow();
				
				self.infoWnd.setProgramTitle(pvrItem.get('title'));
				self.infoWnd.setRecordingTime(pvrItem.get('date'));
				var HDSD= '';
				if(pvrItem.get('hd')== PvrQuality.DEFINITION_INFO_HD){
					HDSD= 'HD';
				}
				else if(pvrItem.get('hd')== PvrQuality.DEFINITION_INFO_SD){
					HDSD= 'SD';
				}
				else if(pvrItem.get('hd')== PvrQuality.DEFINITION_INFO_UHD){
					HDSD= 'UHD';
				}
				else{
				}
				self.infoWnd.setQuality(HDSD);
				self.infoWnd.setSize(pvrItem.get('size'));
				self.infoWnd.setLocation(pvrItem.get('location'));
				self.infoWnd.setSynopsis(pvrItem.get('synopsis'));
				self.infoWnd.setChanelNum(pvrItem.get('chanelNum'));
				self.infoWnd.setChanelTitle(pvrItem.get('chanelName'));
				self.infoWnd.setSignalType(pvrItem.get('chanelType'));
				self.infoWnd.setTvMode(pvrItem.get('chanelType'));
				self.infoWnd.setGuidance(pvrItem.get('guidance'));
				self.infoWnd.render();
				//self.infoWnd.setDefaultFocus();

			}
				}catch(e){
			print('[content-view-base.js]showDetailInfo e:'+e);

				}
			print('[content-view-base.js]showDetailInfo------------------------------end');
		},

		onHideInfoPopup : function(){
			print('content-view-base.js onHideInfoPopup()');
			if( self.infoWnd != null && self.infoWnd.popupWidget != null ){
				self.infoWnd.hide();
				self.infoWnd = null;
			}		

			if(self.pipPopup){
			//hide PIN popup
				Log.e(" [content-view-base.js] hide pin popup ");
				self.pipPopup.onExit();
				self.pipPopup = null;
			}
		},

		/** focus out action
		* @name changeRenderImg 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		changeRenderImg : function(param){
			if ( self.nativeGridList == null ){
				return;
			}
			try {
				var newItem = self.collection.getItem(param.index);
				if( newItem && newItem.get('ItemType') == EItemType.eItemFolder ){
					print('content view base, Focus out:', param.index);
					if ( param.rend && param.rend.thumbnail ){
						var tempImage = null;
						if (self.folderNoamalImage){
							tempImage = self.folderNoamalImage;
						}
						else{
							tempImage = resMgr.getImgPath()+'/foders/mc_icon_foder.png';
						}	
						param.rend.thumbnail.setAttachIcon("icon1", tempImage);
					}
				}
				if ( param.rend && param.rend.unique != null ){
					Volt.clearInterval(param.rend.unique);
					param.rend.unique = null;
				}
			}catch(e){
				print('[content-view-base.js][changeRenderImg]  e:', e);
			}
		},


		/** loadNativeGridList
		* @name loadNativeGridList 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		loadNativeGridList : function(){

			HALOUtil.enableTimeCostCount = false;
			this.nativeGridList = null;
			this.mainView.gridIndex++;
			this.templateList.id = 'nativeGrid'+this.mainView.gridIndex.toString();
			this.nativeGridList = PanelCommon.loadTemplate(this.templateList, null, this.mainView.getViewContainer());
			this.setWidget(this.nativeGridList);
			this.nativeGridList.shadowEffectFlag = false;
			this.nativeGridList.setAnimationDuration("focus-move", 500);
			this.nativeGridList.onItemClicked = function()
			{
				print('1[content-view-base.js]onItemClicked----------------------------block input flag = ' + inputController.getBlockFlag());
				inputController.getBlockFlag()
				if(inputController.getBlockFlag()){
					print('[content-view-base.js]onItemClicked----------------------------block input');
					return ;
				}
				self.nativeGridListCallback();
			};
			this.nativeGridList.onItemInfoPressed = function(){
				print("nativeGridList.onItemInfoPressed");
				self.showDetailInfo();
			};
			if(ViewGlobalData.firstLaunch == true){
			    this.nativeGridList.showFocus('false');
			    this.nativeGridList.setFocusImage(resMgr.getImgPath()+'/common/ksc_focus.png', -8, -8);
				//ViewGlobalData.firstLaunch = false;
			}

			var firstFocusInListener = new FirstShownListener;
			firstFocusInListener.onFirstShown = function (grid) {
			   print(">>>>>>>>>>>>>>>>>  grid list First show" );
			   if(RunTimeInfo.isEditMode != true){
			   		print(">>>>>>>>>>>>>>>>>  grid list First show" );
			   		EventMediator.trigger(EventType.EVENT_TYPE_SHOW_SETTING);
			   }
			   self.waitFirstShow = false;
				if(RunTimeInfo.isEditMode == true){
					print('It is in edit mode, need not play ');
					return;
				}
		   		var focusItem = self.nativeGridList.getFocusItemIndex();
				print('onFirstShown >>>>>>>>> focusItem:',focusItem);
				var index = focusItem.itemIndex;
				print('onFirstShown >>>>>>>>> index:',index);
				var item = self.collection.getItem(index);
				print('onFirstShown >>>>>>>>>  Current focus item title :', item.get('title1'));
	
				if(ViewGlobalData.parentFielPathStack.length == 0){
					//It is not in folder	
					print('It is not in folder');
					var sectionName = resMgr.getText('COM_MY_CONTENT')+',';
					var CurrentCtName = self.mainView.categoryView.getCurrentCategoryName() + ',' +resMgr.getText('COM_SID_CATEGORY')+',';
					var ctCount = self.collection.size();
					if(ctCount>1){
						var countTxt = ctCount.toString() + ',' + resMgr.getText('COM_TV_SID_ITEMS');
					}else{
						var countTxt = ctCount.toString() + ',' + resMgr.getText('COM_ITEM');
					}
					var voiceTxt = sectionName + CurrentCtName + countTxt +',' + item.get('title1');

					voiceGuide.play(voiceTxt);
				}else{
					print('It is  in folder');
					var folderName = '';		
					
					var index = ViewGlobalData.currFilePath.lastIndexOf('/');
					var folderName = ViewGlobalData.currFilePath.substring(index+1,ViewGlobalData.currFilePath.length)+',';
					
					var ctCount = self.collection.size();
					if(ctCount>1){
						var countTxt = ctCount.toString() + ',' + resMgr.getText('COM_TV_SID_ITEMS');
					}else{
						var countTxt = ctCount.toString() + ',' + resMgr.getText('COM_ITEM');
					}
					var voiceTxt = folderName + countTxt +',' + item.get('title1');
					voiceGuide.play(voiceTxt);
				}
				
			}
			
			this.nativeGridList.addFirstShownListener(firstFocusInListener);
			this.nativeGridList.canLoopWhenContinuosKey = false;

		},

		/** createRendererProvider
		* @name createRendererProvider 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		createRendererProvider : function(){
			var rendererProvider = new RendererProvider;
			rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data)
			{
				return GetRenderer(parentWidth, parentHeight, data);
			};
			return rendererProvider;
		},

		/** createGridListener
		* @name createGridListener 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		createGridListener : function(){
			var gridListener = new GridListControlListener;
			gridListener.onItemLoaded = function(gridList, groupIndex, itemIndex)
			{
			};
			
			gridListener.onFocusAnimationFinish = function (gridList, datas)
			{

			};

			gridListener.onItemUnloaded = function(gridList, groupIndex, itemIndex){
				print("content-view-base.js onItemUnloaded");
			};
			
			gridListener.onItemClicked = function(gridList, groupIndex, itemIndex)
			{
				print('2[content-view-base.js]onItemClicked----------------------------block input flag = ' + inputController.getBlockFlag());
				inputController.getBlockFlag()
				if(inputController.getBlockFlag()){
					print('[content-view-base.js]onItemClicked----------------------------block input');
					return ;
				}
				self.nativeGridListCallback();
			};
			
			gridListener.onFocusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){
				print('onFocusChanged >>>>>>>>>>>>>>>>>>  fromItemIndex:',fromItemIndex);
				print('onFocusChanged >>>>>>>>>>>>>>>>>>  toItemIndex:',toItemIndex);
				if(toItemIndex > -1 && (self.waitFirstShow == false || RunTimeInfo.isEditMode == true)){
					if((toItemIndex + 1)%3 == 0 ){
						self.downEdge = true;
					}else{
						self.downEdge = false;
					}
					
					if(fromItemIndex < 0){
						//focus move in grid list
						self.playTTSText(toItemIndex,TTSEventType.MOVE_FOCUS_TO_CONTENT_FOLDER);	
					}else{
						self.playTTSText(toItemIndex,TTSEventType.MOVE_FOCUS_IN_GRID);				
					}
					
				}				
			};
			
			gridListener.onEnterKeyLongPressed = function(gridList, groupIndex, itemIndex){
				Log.e("gridListener.onEnterKeyLongPressed start");
				if(RunTimeInfo.isEditMode == true){
					print('content-view-base.js, edit mode is true!');
					return;
				}
				var tempItem = self.collection.getItem(itemIndex);
				if( tempItem != null ){
					if( tempItem.get('ItemType') == EItemType.eItemPhoto ||
						tempItem.get('ItemType') == EItemType.eItemVideo ||
						tempItem.get('ItemType') == EItemType.eItemMusic ||
						tempItem.get('ItemType') == EItemType.eItemPvr ||
						tempItem.get('ItemType') == EItemType.eItemUHDVideo){
						gridList.longPress = true;
						var Renderer = gridList.renderer(groupIndex, itemIndex);
						self.ifItemLongPress(itemIndex,Renderer.thumbnail);
					}
				}
			};
			return gridListener;
		},

		/** setGridListForm
		* @name setGridListForm 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		setGridListStyle : function(param){
			this.nativeGridList.setRendererProvider(param.rendererProvider);
			this.nativeGridList.addListListener(param.gridListener);		
			this.nativeGridList.addGroup(1);
			this.nativeGridList.addStyle(1);
	
			var tempColumn = 0;
			var tmpColumnNum = 0;
			print("setGridListStyle  param.UHDContent:" + param.UHDContent);
			if(param.UHDContent != true){
				tmpColumnNum = CONST.MY_CONTENT_APP_COLUMN_NUM;
			}else{
				tmpColumnNum = CONST.MY_CONTENT_UHD_VIDEO_COLUMN_NUM;
			}
			
			tempColumn = self.collection.size()%tmpColumnNum;
			print('setGridListStyle, columnWidth:',param.columnWidth);
			if ( param.columnWidth < 0 || param.columnWidth > 1920 ){
				return;
			}
			if ( self.collection.size() < param.renderNumber ){
				tempColumn = param.renderColumn;
			}
			else{
				if ( tempColumn > 0 ){
					tempColumn = self.collection.size()/tmpColumnNum+1;
				}
				else{
					tempColumn = self.collection.size()/tmpColumnNum;
				}
			}
			print('setGridListStyle, self.collection.length:',self.collection.size());
			print('setGridListStyle, tempColumn:',tempColumn);
			for (i = 0; i < tempColumn; i++){
				this.nativeGridList.addColumn({groupIndex: 0, styleIndex: 0, columnWidth: param.columnWidth});
			}

			for (i = 0; i < tmpColumnNum; i++){
				this.nativeGridList.addRowToAllColumn({groupIndex: 0, styleIndex: 0, rowHeight: param.rowHeight});
			}
			
			//this.nativeGridList.enlargeFocusItem(20, 20);
			this.nativeGridList.addDataGroup(1);
			this.nativeGridList.show();
		},

		/** setGridListData
		* @name setGridListData 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		setGridListData : function(param){
			print('setGridListData');
			this.nativeGridList.list = [];
			var i = 0;
			for( i = 0; i < self.collection.size(); i++ ){
				var tempItem = self.collection.at(i);			
				var data = new Data();
				data.dataFlag = false;
				data.createFlag = false;
				if ( tempItem && tempItem.get('dataFlag') == 1 ){
					data.dataFlag = true;
					data.title1 =  tempItem.get('title1');
					data.title2 =  tempItem.get('title2');
					data.ItemType =  tempItem.get('ItemType');
					data.isWatched =  tempItem.get('isWatched');
					data.isAudioOnly = tempItem.get('isAudioOnly');
					data.isLocked = tempItem.get('isLocked');
					data.isGuidance = tempItem.get('isGuidance');
					data.sportsType = tempItem.get('sportsType');
					data.isRecording = tempItem.get('isRecording');
				}
				data.imgUrl = Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_m_0"+(data.index%6+1)+".png";
				data.isThumbDone = false;
				data.dummyFlag = false;
				data.ThumbPath = '';
				data.conIconPath =  '';
				data.unsupportIcon = '';
				data.index = i;
				this.nativeGridList.list.push(data);
				this.nativeGridList.addData({groupIndex:0, data:data});
			}
			/*
			var dummyColumnNumber = 0;
			if (self.collection.length > 1 ){
				var columnNumber = 0;
				if ( self.collection.size() < param.renderNumber ){
					print('dummyColumnNumber');
					for( ; i < param.renderNumber; i++ ){
						var data = new Data();
						data.dummyFlag = true;
						data.index = i;
						this.nativeGridList.list.push(data);
						this.nativeGridList.addData({groupIndex:0, data:data});
					}
				}
				else{
					columnNumber = self.collection.size()%CONST.MY_CONTENT_APP_COLUMN_NUM;
					
					if ( columnNumber > 0 ){
						dummyColumnNumber = (self.collection.size()-columnNumber)/CONST.MY_CONTENT_APP_COLUMN_NUM+1;
						dummyColumnNumber = dummyColumnNumber*CONST.MY_CONTENT_APP_COLUMN_NUM;
						print('2dummyColumnNumber:',dummyColumnNumber);
						for( ; i < dummyColumnNumber; i++ ){
							print('dummyIndex---:',i);
							var data = new Data();
							data.dummyFlag = true;
							data.index = i;
							this.nativeGridList.list.push(data);
							this.nativeGridList.addData({groupIndex:0, data:data});
							//this.nativeGridList.enableItem(0, i, false); 
						}
					}
				}
			}*/
			
			if ( self.collection.size() > CONST.MY_CONTENT_APP_COLUMN_NUM ){
				this.nativeGridList.loopLeftFlag = true;
				this.nativeGridList.loopRightFlag = true;
			}else{
				this.nativeGridList.loopLeftFlag = false;
				this.nativeGridList.loopRightFlag = false;
			}
			this.nativeGridList.longPress = false;
			//this.nativeGridList.setBufferColumnSize({left: 10, right: 10 });
			this.nativeGridList.loadItemAfterAniFinish = true;
			this.nativeGridList.setThumbnailDefaultImage(resMgr.getImgPath()+'/default_thumb/icon_blank_thumbnail.png');
			this.nativeGridList.loadData();
			this.nativeGridList.showFocus(false);
			this.nativeGridList.hideFocus(false);
			/*
			var j = 0;
			for( j = self.collection.size(); j < dummyColumnNumber; j++){
				print("nativeGridList.enableItem j:",j);
				this.nativeGridList.enableItem(0, j, false); 
			}
			*/
		},
		

		
		/** createNativeGridList
		* @name createNativeGridList 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		createNativeGridList : function(){
		    Log.e("content-view-base.js createNativeGridList RunTimeInfo.UHDContentFolder:"+RunTimeInfo.UHDContentFolder);
			print("content-view-base.js createNativeGridList RunTimeInfo.UHDContentFolder:"+RunTimeInfo.UHDContentFolder);
			//folder coordinate
			try{
				if(RunTimeInfo.UHDContentFolder != true){
					self.params.renderWidth = AllContentViewTemplate.listItemFolder[0].width;//220
					self.params.renderHeight = AllContentViewTemplate.listItemFolder[0].height;//288
					self.params.textX = AllContentViewTemplate.listItemFolder[1].x;//20
					self.params.textY = AllContentViewTemplate.listItemFolder[1].y;//186
					self.params.textWidth = AllContentViewTemplate.listItemFolder[1].width;//180
					self.params.textHeight = AllContentViewTemplate.listItemFolder[1].height;//58
					self.params.folderX = AllContentViewTemplate.listItemFolder[2].x;//37
					self.params.folderY = AllContentViewTemplate.listItemFolder[2].y;//60
					self.params.folderWidth = AllContentViewTemplate.listItemFolder[2].width;//146
					self.params.folderHeight = AllContentViewTemplate.listItemFolder[2].height;//121
					//other coordinate
					self.params.imageWidth = AllContentViewTemplate.listItemNoFolder[0].width;//220
					self.params.imageHeight = AllContentViewTemplate.listItemNoFolder[0].height;//220

					self.params.infoHeight = AllContentViewTemplate.listItemNoFolder[2].height;//68
					self.params.text1X = AllContentViewTemplate.listItemNoFolder[2].children[0].x;//18
					self.params.text1Y = AllContentViewTemplate.listItemNoFolder[2].children[0].y;//20
					self.params.text1Width = AllContentViewTemplate.listItemNoFolder[2].children[0].width;//184
					self.params.text1Height = AllContentViewTemplate.listItemNoFolder[2].children[0].height;//28
					self.params.text2X = AllContentViewTemplate.listItemNoFolder[2].children[1].x;//18
					self.params.text2Y = AllContentViewTemplate.listItemNoFolder[2].children[1].y;//35
					self.params.text2Width = AllContentViewTemplate.listItemNoFolder[2].children[1].width;//184
					self.params.text2Height = AllContentViewTemplate.listItemNoFolder[2].children[1].height;//28

					self.params.icon1X = AllContentViewTemplate.listItemNoFolder[1].x;//67
					self.params.icon1Y = AllContentViewTemplate.listItemNoFolder[1].y;//74
					self.params.icon1Width = AllContentViewTemplate.listItemNoFolder[1].width;//86
					self.params.icon1Height = AllContentViewTemplate.listItemNoFolder[1].height;//73
					
					self.params.icon2X = AllContentViewTemplate.listItemNoFolder[3].x;//66
					self.params.icon2Y = AllContentViewTemplate.listItemNoFolder[3].y;//66
					self.params.icon2Width = AllContentViewTemplate.listItemNoFolder[3].width;//88
					self.params.icon2Height = AllContentViewTemplate.listItemNoFolder[3].height;//88

					self.params.connectX = AllContentViewTemplate.listItemNoFolder[4].x;//67
					self.params.connectY = AllContentViewTemplate.listItemNoFolder[4].y;//74
					self.params.connectWidth = AllContentViewTemplate.listItemNoFolder[4].width;//86
					self.params.connectHeight = AllContentViewTemplate.listItemNoFolder[4].height;//73
					
					self.params.uhdX = AllContentViewTemplate.listItemNoFolder[5].x;//66
					self.params.uhdY = AllContentViewTemplate.listItemNoFolder[5].y;//66
					self.params.uhdWidth = AllContentViewTemplate.listItemNoFolder[5].width;//88
					self.params.uhdHeight = AllContentViewTemplate.listItemNoFolder[5].height;//88

					self.params.icon5X = AllContentViewTemplate.listItemNoFolder[6].x;//66
					self.params.icon5Y = AllContentViewTemplate.listItemNoFolder[6].y;//66
					self.params.icon5Width = AllContentViewTemplate.listItemNoFolder[6].width;//88
					self.params.icon5Height = AllContentViewTemplate.listItemNoFolder[6].height;//88

					self.params.icon6X = AllContentViewTemplate.listItemNoFolder[7].x;//66
					self.params.icon6Y = AllContentViewTemplate.listItemNoFolder[7].y;//66
					self.params.icon6Width = AllContentViewTemplate.listItemNoFolder[7].width;//88
					self.params.icon6Height = AllContentViewTemplate.listItemNoFolder[7].height;//88

					self.params.icon7X = AllContentViewTemplate.listItemNoFolder[8].x;//66
					self.params.icon7Y = AllContentViewTemplate.listItemNoFolder[8].y;//66
					self.params.icon7Width = AllContentViewTemplate.listItemNoFolder[8].width;//88
					self.params.icon7Height = AllContentViewTemplate.listItemNoFolder[8].height;//88
				}else{
					self.params.renderWidth = AllContentViewTemplate.uhd_content_listItemFolder[0].width;//220
					self.params.renderHeight = AllContentViewTemplate.uhd_content_listItemFolder[0].height;//288
					self.params.textX = AllContentViewTemplate.uhd_content_listItemFolder[1].x;//20
					self.params.textY = AllContentViewTemplate.uhd_content_listItemFolder[1].y;//186
					self.params.textWidth = AllContentViewTemplate.uhd_content_listItemFolder[1].width;//180
					self.params.textHeight = AllContentViewTemplate.uhd_content_listItemFolder[1].height;//58
					self.params.folderX = AllContentViewTemplate.uhd_content_listItemFolder[2].x;//37
					self.params.folderY = AllContentViewTemplate.uhd_content_listItemFolder[2].y;//60
					self.params.folderWidth = AllContentViewTemplate.uhd_content_listItemFolder[2].width;//146
					self.params.folderHeight = AllContentViewTemplate.uhd_content_listItemFolder[2].height;//121
					//other coordinate
					self.params.imageWidth = AllContentViewTemplate.uhd_content_listItemNoFolder[0].width;//220
					self.params.imageHeight = AllContentViewTemplate.uhd_content_listItemNoFolder[0].height;//220

					self.params.infoHeight = AllContentViewTemplate.uhd_content_listItemNoFolder[2].height;//68
					self.params.text1X = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[0].x;//18
					self.params.text1Y = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[0].y;//20
					self.params.text1Width = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[0].width;//184
					self.params.text1Height = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[0].height;//28
					self.params.text2X = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[1].x;//18
					self.params.text2Y = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[1].y;//35
					self.params.text2Width = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[1].width;//184
					self.params.text2Height = AllContentViewTemplate.uhd_content_listItemNoFolder[2].children[1].height;//28

					self.params.icon1X = AllContentViewTemplate.uhd_content_listItemNoFolder[1].x;//67
					self.params.icon1Y = AllContentViewTemplate.uhd_content_listItemNoFolder[1].y;//74
					self.params.icon1Width = AllContentViewTemplate.uhd_content_listItemNoFolder[1].width;//86
					self.params.icon1Height = AllContentViewTemplate.uhd_content_listItemNoFolder[1].height;//73
					
					self.params.icon2X = AllContentViewTemplate.uhd_content_listItemNoFolder[3].x;//66
					self.params.icon2Y = AllContentViewTemplate.uhd_content_listItemNoFolder[3].y;//66
					self.params.icon2Width = AllContentViewTemplate.uhd_content_listItemNoFolder[3].width;//88
					self.params.icon2Height = AllContentViewTemplate.uhd_content_listItemNoFolder[3].height;//88

					self.params.connectX = AllContentViewTemplate.uhd_content_listItemNoFolder[4].x;//67
					self.params.connectY = AllContentViewTemplate.uhd_content_listItemNoFolder[4].y;//74
					self.params.connectWidth = AllContentViewTemplate.uhd_content_listItemNoFolder[4].width;//86
					self.params.connectHeight = AllContentViewTemplate.uhd_content_listItemNoFolder[4].height;//73
					
					self.params.uhdX = AllContentViewTemplate.uhd_content_listItemNoFolder[5].x;//66
					self.params.uhdY = AllContentViewTemplate.uhd_content_listItemNoFolder[5].y;//66
					self.params.uhdWidth = AllContentViewTemplate.uhd_content_listItemNoFolder[5].width;//88
					self.params.uhdHeight = AllContentViewTemplate.uhd_content_listItemNoFolder[5].height;//88

					self.params.icon5X = AllContentViewTemplate.uhd_content_listItemNoFolder[6].x;//66
					self.params.icon5Y = AllContentViewTemplate.uhd_content_listItemNoFolder[6].y;//66
					self.params.icon5Width = AllContentViewTemplate.uhd_content_listItemNoFolder[6].width;//88
					self.params.icon5Height = AllContentViewTemplate.uhd_content_listItemNoFolder[6].height;//88

					self.params.icon6X = AllContentViewTemplate.uhd_content_listItemNoFolder[7].x;//66
					self.params.icon6Y = AllContentViewTemplate.uhd_content_listItemNoFolder[7].y;//66
					self.params.icon6Width = AllContentViewTemplate.uhd_content_listItemNoFolder[7].width;//88
					self.params.icon6Height = AllContentViewTemplate.uhd_content_listItemNoFolder[7].height;//88

					self.params.icon7X = AllContentViewTemplate.uhd_content_listItemNoFolder[8].x;//66
					self.params.icon7Y = AllContentViewTemplate.uhd_content_listItemNoFolder[8].y;//66
					self.params.icon7Width = AllContentViewTemplate.uhd_content_listItemNoFolder[8].width;//88
					self.params.icon7Height = AllContentViewTemplate.uhd_content_listItemNoFolder[8].height;//88
				

				}
				self.loadNativeGridList();
				var rendererProvider = self.createRendererProvider();
				var gridListener = self.createGridListener();
				//var param = RunTimeInfo.router.currentView.getRenderInfo();
				var param = self.getRenderInfo();
			    var mustache = {
			        rendererProvider: rendererProvider,
					gridListener: gridListener,
			        columnWidth: param.columnWidth,
			        rowHeight: param.rowHeight,
			        renderNumber:param.renderNumber,
			        renderColumn:param.renderColumn,
			        UHDContent: RunTimeInfo.UHDContentFolder,
			    };
				self.setGridListStyle(mustache);
				self.setGridListData(mustache);
			}
			catch(e){
				Log.e("createNativeGridList e");
			}

			Log.e("content-view-base.js createNativeGridList finish");
			print("content-view-base.js createNativeGridList finish");
			Volt.setTimeout(function(){		
				print('[content-view-base.js]initialize, preload photo player');
				AppLauncher.preloadPhotoPlayer();
				AppLauncher.preloadVideoPlayer();
				Log.e("[mainview.js]initialize KPI performance");
				//Volt.KPIMapper.init();
				Log.e("[mainview.js]initialize KPI finish performance");
				print('updateBrowserData    inil play EMP');
				self.playInstance =	Volt.require('app/controller/play-controller.js');
				
			},100);
		},
		
		playTTSText:function(index, type){
			var voiceText = null;
	
			voiceText = self.getVoideText(index, type);	
			
			print('[playTTSText]  voiceText:'+ voiceText +'type:'+type);
			
			if(voiceText == null || voiceText == undefined){
				return;
			}
			voiceGuide.play(voiceText);
		},
		/** getVoideText
		* @name getVoideText 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		getVoideText : function(tempIndex, type){
			
			var tempText = '';
			var tempItem = self.collection.getItem(tempIndex);
			if(tempItem == null || tempItem == undefined){
				print('getVoideText  >>>>>>>>>>>>>>>>>> item is null');
				return;
			}
			var title =  tempItem.get('title1');
			var itemText = '';
			if(self.collection.length < 1){
				itemText = self.collection.length.toString()+','+resMgr.getText('COM_ITEM')+',';
			}else{
				itemText = self.collection.length.toString()+','+resMgr.getText('COM_TV_SID_ITEMS')+',';
			}
		
			switch(type) {
		 		case TTSEventType.FIRST_FOCUS_FOLDER: {
					//first enter folder
					tempText += resMgr.getText('COM_MY_CONTENT')+',';
					tempText += self.deviceName + ','+ resMgr.getText('COM_SID_CATEGORY') + itemText + title;
					break;
				}
				case TTSEventType.MOVE_FOCUS_TO_CONTENT_FOLDER:{
					if(RunTimeInfo.isEditMode == false){
						tempText += self.deviceName + ',' + resMgr.getText('COM_SID_CATEGORY') + itemText + title;
					}else{
						var check =  tempItem.get('isSelected');
						var itemType = tempItem.get('ItemType');
						
						if(check == true){
							var checkTxt = resMgr.getText('TV_SID_CHECKED');
						} else {
							var checkTxt = resMgr.getText('TV_SID_UNCHECKED');
						}
						var disableText = '';
						if(itemType == EItemType.eItemFolder || itemType == EItemType.eItemUpFolder){
							disableText = ', '+resMgr.getText('COM_SID_DISABLE');
						}
						tempText = resMgr.getText('TV_SID_CHECKBOX_ACC')+',' + checkTxt +','+ title + disableText;
					}
					break;
				}
				case  TTSEventType.MOVE_FOCUS_IN_GRID :{
					//if edit_mode = true
					if(RunTimeInfo.isEditMode == true){
						var check =  tempItem.get('isSelected');
						var itemType = tempItem.get('ItemType');
						
						if(check == true){
							var checkTxt = resMgr.getText('TV_SID_CHECKED');
						} else {
							var checkTxt = resMgr.getText('TV_SID_UNCHECKED');
						}
						var disableText = '';
						if(itemType == EItemType.eItemFolder || itemType == EItemType.eItemUpFolder){
							disableText = ', '+resMgr.getText('COM_SID_DISABLE');
						}
						tempText = resMgr.getText('TV_SID_CHECKBOX_ACC')+',' + checkTxt +','+ title + disableText;
					}else {
						tempText = title;
					}
					//move focus among gridlist
					
					break;
				}
				default:
					break;
			}
			print('getVoideText >>>>>>>>>>>>>>>>>> tempText:',tempText);
			return tempText;
		},

		getResourceText : function(optionSids){
			var options = [];
			var index = 0;
			while(index < optionSids.length ){
				options[index] = resMgr.getText(optionSids[index]);
				index ++;
			}
			return options;
		},

		getUHDText : function(){
			var options = [
		        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
	            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
		    ];
			self.isDimFirstPlus = [];
			for (var index = 0; index < options.length; index++){
				self.isDimFirstPlus[index] = false;
				self.isShowSecPlus[index] = false;
			}
			self.isShowSecPlus[0] = true;
			return options;
		},

		/** updateRender
		* @name updateRender 
		* @memberOf ContentViewBase
		* @method 	 
		* */
		updateRender : function( data, renderer){
			print("content-view-base.js updateRender index:", data.index);
			if( data.ItemType == EItemType.eItemFolder ){
				updateFolderItemThumbnail( data, renderer);
			}
		    else if( data.ItemType == EItemType.eItemUpFolder ){
				updateUpfolderItemThumbnail( data, renderer);
		    }
			else if ( data.ItemType < EItemType.eItemFolder){
				updateFileItemThumbnail( data, renderer);
			}
			renderer.thumbnail.removeThumbnailListener(self.thumbListener);
			if(data.ItemType == EItemType.eItemPvr && data.isGuidance){
				renderer.thumbnail.addThumbnailListener(self.thumbListener);
			} 
			print("finish content-view-base.js updateRender index:", data.index);
		},
		
	});

	function createScroll(){
		print('createScroll');
		var scroll = new Scroll({
		    parent: scene,
		    width: scene.width,
		    height: 5,
		    direction: "horizontal"
		});
		scroll.setPosition(0, 1080-28-216);
		scroll.setBackgroundColor(220, 220, 220, 255*0.2);

		scroll.setPointingNormalThumbImage(resMgr.getImgPath()+"/scroll/keyscreen_scroll_pn.png");
		scroll.setPointingNormalThumbSize(20, 5);

		scroll.setMinValue(0);
		scroll.setMaxValue(scene.width);
		scroll.setValue(0);

		scroll.setRolloverTrackHeight(5);
		scroll.show();
		return scroll;
	};
	
	/** GetRenderer
	* @name GetRenderer	 
	* @memberOf AllContentView
	* @param {parentWidth} current render width
	* @param {parentHeight} current render height
	* @param {data} current render data
	* @method 	 
	* */	
	function GetRenderer(parentWidth, parentHeight, data){
		try {
			var renderer = new Thumbnail_View(parentWidth, parentHeight, self);

			renderer.createIndex = data.index;
			renderer.autoRelease = false;
			data.createFlag = true;
			if( data.index < self.collection.size() && self.collection.at(data.index).get('dataFlag')== 0){
				data.createFlag = false;
				data.dataFlag = false;
			}
			
			renderer.unique = null;
			renderer.textWidgetNumber = RunTimeInfo.router.currentView.getTextWidgetNumber();
			
			if ( RunTimeInfo.router.currentViewType == EViewType.eAllContentView ){
				renderer.template = AllContentViewTemplate;
			}
			
			if ( data.dummyFlag == false ){
				renderer.createChild( renderer, data );
			}
			else{
				changeRenderInfo(data.index);
			}
			Log.e("[content-view-base.js] GetRenderer index:"+data.index+", renderer:"+renderer+", thumbnail:"+renderer.thumbnail);
		}catch(e){
			print('[GetRenderer]  e:', e);
		}
		print('[content-view-base.js] GetRenderer:',renderer);
		return renderer;
	};


	function changeRenderInfo(index){
		self.nativeGridList.enableItem(0, index, false); 
	};
	
	function changeRenderImg(param){
		self.changeRenderImg(param);
	};

	function addIconInfo( input, iconNum, iconPa ){
		switch (iconNum) {
	        case 1:
	            break;
	        case 2:
				input.thumbnail.addThumbnailAttachIcons({icon2:iconPa});
				break;
	        case 3:
				input.thumbnail.addThumbnailAttachIcons({icon3:iconPa});
				break;
	        case 4:
				input.thumbnail.addThumbnailAttachIcons({icon4:iconPa});
			    break;
	        case 5:
				input.thumbnail.addThumbnailAttachIcons({icon5:iconPa});
	            break;
	        case 6:
				input.thumbnail.addThumbnailAttachIcons({icon6:iconPa});
				break;
	        case 7:
				input.thumbnail.addThumbnailAttachIcons({icon7:iconPa});
				break;
	        case 8:
				input.thumbnail.addThumbnailAttachIcons({icon8:iconPa});
			    break;
	        case 9:
				input.thumbnail.addThumbnailAttachIcons({icon9:iconPa});
				break;
	        case 10:
				input.thumbnail.addThumbnailAttachIcons({icon10:iconPa});
			    break;
	        default:
	            break;
	    }
	};

	function changeIconInfo( input, iconNum, flag ){
		switch (iconNum) {
	        case 1:
				input.thumbnail.visualizeAttachIcon(flag, "icon1");
	            break;
	        case 2:
				input.thumbnail.visualizeAttachIcon(flag, "icon2");
				break;
	        case 3:
				input.thumbnail.visualizeAttachIcon(flag, "icon3");
				break;
	        case 4:
				input.thumbnail.visualizeAttachIcon(flag, "icon4");
			    break;
	        case 5:
				input.thumbnail.visualizeAttachIcon(flag, "icon5");
	            break;
	        case 6:
				input.thumbnail.visualizeAttachIcon(flag, "icon6");
				break;
	        case 7:
				input.thumbnail.visualizeAttachIcon(flag, "icon7");
				break;
	        case 8:
				input.thumbnail.visualizeAttachIcon(flag, "icon8");
			    break;
	        case 9:
				input.thumbnail.visualizeAttachIcon(flag, "icon9");
				break;
	        case 10:
				input.thumbnail.visualizeAttachIcon(flag, "icon10");
			    break;
	        default:
	            break;
	    }
	};

	function dimIconInfo( input, iconNum ){
		switch (iconNum) {
	        case 1:
				input.thumbnail.setElementOpacity("icon1", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon1");
				break;
	        case 2:
				input.thumbnail.setElementOpacity("icon2", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon2");
				break;
	        case 3:
				input.thumbnail.setElementOpacity("icon3", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon3");
				break;
	        case 4:
				input.thumbnail.setElementOpacity("icon4", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon4");
			    break;
	        case 5:
				input.thumbnail.setElementOpacity("icon5", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon5");
	            break;
	        case 6:
				input.thumbnail.setElementOpacity("icon6", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon6");
				break;
	        case 7:
				input.thumbnail.setElementOpacity("icon7", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon7");			
				break;
	        case 8:
				input.thumbnail.setElementOpacity("icon8", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon8");	
			    break;
	        case 9:
				input.thumbnail.setElementOpacity("icon9", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon9");	
				break;
	        case 10:
				input.thumbnail.setElementOpacity("icon10", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon10");	
			    break;
	        default:
	            break;
	    }
	};
	function setInfoTextInfo( input, iconNum, iconPa ){
		switch (iconNum) {
	        case 1:
				input.information.text2 = iconPa;
	            break;
	        case 2:
				input.information.text2 = iconPa;
				break;
			  case 3:
				input.information.text3 = iconPa;
				break;
	        default:
	            break;
	    }
	};

	function setIconInfo( input, iconNum, iconPa ){
		switch (iconNum) {
	        case 1:
				input.icon1 = iconPa;
	            break;
	        case 2:
				input.icon2 = iconPa;
				break;
	        case 3:
				input.icon3 = iconPa;
				break;
	        case 4:
				input.icon4 = iconPa;
			    break;
	        case 5:
				input.icon5 = iconPa;
	            break;
	        case 6:
				input.icon6 = iconPa;
				break;
	        case 7:
				input.icon7 = iconPa;
				break;
	        case 8:
				input.icon8 = iconPa;
			    break;
	        case 9:
				input.icon9 = iconPa;
				break;
	        case 10:
				input.icon10 = iconPa;
			    break;
	        default:
	            break;
	    }
	};

	function updateFolderItemThumbnail( data, renderer){
		var input = {
		    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
	        image: {
	            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
	            width: self.params.renderWidth,
	            height: self.params.renderHeight
	        },
	        information: {
	          	x: 0,
	        	y: 0,
	            width: self.params.renderWidth,
		        height: self.params.renderHeight,
	            text1: {
	            	text: data.title1,
	                font: 'SamsungSmart_Light 24px',
                    x: self.params.textX,
		            y: self.params.textY,
	                width: self.params.textWidth,
	                height: self.params.textHeight,
	                horizontalAlignment: 'center',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                enlarge:{
                         factor: 1.5,
                         anchorPoint: 'center',
         			},
         			textColor: { r: 255, g: 255, b: 255, a: 153 },
	            },
	        },
			icon1: {
				x: self.params.folderX, 
				y: self.params.folderY, 
				width: self.params.folderWidth, 
				height: self.params.folderHeight,
				async: true,
				unpressSrc: self.folderNoamalImage,
				pressedSrc: self.folderNoamalImage,
				clickable: false,
				opacity: 128,
			}
		};
		renderer.thumbnail.setThumbnailStyle(input);
		if(RunTimeInfo.isEditMode == true){
			renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
			renderer.thumbnail.dim(true);
		}
		else{
			renderer.thumbnail.dim(false);
		}
		renderer.thumbnail.show();
	};
	
	function updateUpfolderItemThumbnail( data, renderer){
		var input = {
		    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
		    //parent: scene,//renderer.root,
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
	        image: {
	            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_m_upper.png",
		    width: self.params.renderWidth,
	            height: self.params.renderHeight
	        },
	        information: {
	           x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,
	           
	            text1: {
	            	text: data.title1,
	                font: 'SamsungSmart_Light 24px',
	                 x: self.params.textX,
		            y: self.params.textY,
		            width: self.params.textWidth,
		            height: self.params.textHeight,
	                horizontalAlignment: 'center',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                enlarge:{
                         factor: 1.5,
                         anchorPoint: 'center',
         			},
	            },
	        },
			icon1: {
				x: self.params.folderX, 
				y: self.params.folderY, 
				width: self.params.folderWidth, 
				height: self.params.folderHeight,
				async: true,
				unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
				pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
				clickable: false,
				opacity:255*0.5
			}
		};

		renderer.thumbnail.setThumbnailStyle(input);
		if(RunTimeInfo.isEditMode == true){
			renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
			renderer.thumbnail.dim(true);
		}
		else{
			renderer.thumbnail.dim(false);
		}
		renderer.thumbnail.show();
	};

	function prepareFileItemdata( data, renderer){
		if ( !data.title1 ){
			data.title1 = '';
		}
		if ( !data.title2 ){
			data.title2 = '';
		}
		
		var uhdFlagText = '';
		var uhdicon = '';
		var contenticon = '';

		var ratinginfoLineX = 0;
		var ratinginfoIcon = '';
		var ratingLeve = '';
		var uhdGenre = '';
		var ratingInfoX = 0;
		var ratingInfoW = 0;
		
		if( data.ItemType == EItemType.eItemVideo || data.ItemType == EItemType.eItemUHDVideo || data.ItemType == EItemType.eItemSCSA){
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
			contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_play.png';
			if(data.ItemType == EItemType.eItemUHDVideo){
				uhdicon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_uhd.png';
			}
		}
		else if( data.ItemType == EItemType.eItemPhoto){
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_photo_n.png';
			contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_camera.png';	
		}
		else if( data.ItemType == EItemType.eItemMusic){
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_music_n.png';
			if( self.collection.getHDAudioType(data.index)==true){
				contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_music_hd.png';	
			}
			else{
				contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_music.png';	
			}
		}
		else if(data.ItemType == EItemType.eItemPvr){
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
			if(data.isLocked){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_adult_n.png';
			}
			if(data.isAudioOnly){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_audio_n.PNG';
			}
			contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_play.png'
		}
		
				
		var infomationTextX = self.params.text1X;
		var infomationTextW = self.params.text1Width;
		var watchedIconSrc = '';
		var sportsIcoSrc = '';
		var fillModeType = '';
		var recordingIconSrc = '';
		var UHDVideoFlag = false;
		if(data.ItemType == EItemType.eItemPvr){
			if(data.sportsType == 2){
				sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_soccer.png";
			}
			else if(data.sportsType == 3){				
				sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_rugby.png";
			}
			else if(data.sportsType == 4){
				sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_hockey.png";
			}

			if(data.isGuidance){
				infomationTextW -= 26;
			}
           
            if(data.isLocked || data.isAudioOnly){
               self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );                   
            }
            else if(self.collection.getItem(data.index).get('ciThumbType') > CIThumbType.E_THUMB_OK || self.collection.getItem(data.index).get('isDrm') == true){
                data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
                self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );
            }
            else if( self.collection.getItem(data.index).get('isThumbDone')){
                data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
            } 
            else{
                self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
            }
       
		}
		else if(data.ItemType == EItemType.eItemUHDVideo){
			UHDVideoFlag = true;
			var uhdContentId = self.collection.getItem(data.index).get('uhdContentId');
			var uhdThumb = getUhdThumb(uhdContentId); 
			ratingLeve = self.collection.getItem(data.index).get('rateLevel');
			uhdGenre = self.collection.getItem(data.index).get('uhdVideoGenre');
			print("content view base prepareFileItemdata uhdGenre:"+uhdGenre);
			
			if(RunTimeInfo.UHDContentFolder != true){
				ratingInfoW = (self.params.renderWidth - 10)/2;
				print('ratinginfoW :',ratingInfoW);
				infomationTextW = infomationTextW - ratingInfoW;
				infomationTextX += 0;
			
				ratingInfoX = infomationTextX + infomationTextW;
				if(ratingLeve == undefined || ratingLeve == null){
					ratingLeve = ' ';
				}else{
					ratingLeve = '|' + ratingLeve;
				}
				
			}else{
				infomationTextX = 18;
				infomationTextW = 190;
				ratingInfoW = 90;
				print('ratinginfoW :',ratingInfoW);							
				
				ratingInfoX = infomationTextX;

				if(uhdGenre == undefined || uhdGenre == null){
					uhdGenre = '';
				} 
				if(ratingLeve == undefined || ratingLeve == null){
					ratingLeve = '';
				}
			}
			
		
			if(uhdThumb != null){
				//if network is connect , display uhd thumbnail
			   	data.ThumbPath = uhdThumb;
				print('Content-view-base.js createChild >>>>>>>>>>>>>  UHD Video ThumbPath:',data.ThumbPath);
				fillModeType = 'fit';
			}else{
					// else, display default thumb
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
				
			}				
			
		}else{
	        if( data.isThumbDone ){
	        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
		    }
			else if(!self.collection.getItem(data.index).get('isPlayAvailable') || self.collection.getItem(data.index).get('isDrm')){
				self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath);		    	
			}		         
	        else{
	       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
	       	}
		}
		
		if(data.ItemType == EItemType.eItemPvr){
			if(data.isRecording){					
				recordingIconSrc = Volt.BASE_PATH + resMgr.getImgPath()+ "/Contents_icon/recorded_rec_icon.png";
			}
			if(self.collection.getItem(data.index).get('ciThumbType') === CIThumbType.E_THUMB_INVALID){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
				contenticon = '';
			}
			if(self.collection.getItem(data.index).get('isDrm') == true){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
				contenticon = '';
			}
		}
		else{
			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				if(data.ItemType == EItemType.eItemPhoto){
					data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_camera.png';
					contenticon = '';
				}
				else if(data.ItemType == EItemType.eItemMusic){
					data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_music.png';
					contenticon = '';
				}
				else{
					data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
					contenticon = '';
				}
			}
		}
		
		if (self.thumbnailColorFlag == false){
			self.thumbnailColorNumber = data.index%2;
			self.thumbnailColorFlag = true;
		}
		var tempIndex = data.index%2;
		var tempColorPickingOpacity = 255-240;
		if ( tempIndex == self.thumbnailColorNumber ){
			tempColorPickingOpacity = 255-225;
		}
		print("title infomationTextX:"+infomationTextX);
		print("title infomationTextW:"+infomationTextW);
		
		print("title ratingInfoX:"+ratingInfoX);
		print("title ratingInfoW:"+ratingInfoW);
		
		print('create thumbnail begin 2-27');
		print('data.ThumbPath',data.ThumbPath);
		renderer.tempColorPickingOpacity = tempColorPickingOpacity;
		renderer.fillModeType = fillModeType;
		renderer.UHDVideoFlag = UHDVideoFlag;
		renderer.infomationTextX = infomationTextX;
		renderer.infomationTextW = infomationTextW;
		renderer.ratingInfoX = ratingInfoX;
		renderer.ratingInfoW = ratingInfoW;
		renderer.contenticon = contenticon;
		renderer.ratingLeve = ratingLeve;
		renderer.uhdGenre = uhdGenre;
		renderer.uhdicon = uhdicon;
		renderer.sportsIcoSrc = sportsIcoSrc;
		renderer.watchedIconSrc = watchedIconSrc;
		renderer.recordingIconSrc = recordingIconSrc;
	}

	function addFileItemIcon( data, renderer, input){
		renderer.iconNumber = 1;
		renderer.editNum = 0;
		
		if(data.ItemType == EItemType.eItemUHDVideo){
			if(RunTimeInfo.UHDContentFolder != true){
			setInfoTextInfo(input,2,{
	            	text: renderer.ratingLeve,
	                font: 'SVD Light 20px',
            		x: renderer.ratingInfoX+16,
					y: self.params.text1Y+2,				
					width: renderer.ratingInfoW-16, 
					height: self.params.text1Height,		                
					horizontalAlignment: 'right',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                opacity : 128,
	            });
			}else{
				
				setInfoTextInfo(input,2,{
		        	text: renderer.uhdGenre,
		            font: 'SVD Light 20px',
		    		x: renderer.ratingInfoX,
					y: self.params.text1Y+self.params.text1Height+4,				
					width: renderer.ratingInfoW, 
					height: self.params.text1Height,		                
					horizontalAlignment: 'left',
		            verticalAlignment: 'center',
		            singleLineMode: true,
		            opacity : 128,
		        });
				print("addFileItemIcon uhdGenre :"+renderer.ratingLeve);
				setInfoTextInfo(input,3,{
	            	text: renderer.ratingLeve,
	                font: 'SVD Light 20px',
            		x: renderer.ratingInfoX+renderer.ratingInfoW + 10,
					y: self.params.text1Y+self.params.text1Height+4,				
					width: renderer.ratingInfoW, 
					height: self.params.text1Height,		                
					horizontalAlignment: 'right',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                opacity : 128,
	            });
			}
		}
		print(" ratingLeve  ratingInfoX +16 ...1");
		if ( data.ItemType == EItemType.eItemPvr && data.isGuidance ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
					x: 176,
					y: 241,
					width: 26,
					height: 25,
					async: true,
					unpressSrc: '',
					pressedSrc: '',
					clickable:false,
			});
		}
		
		var showCheck =  false;
		if ( RunTimeInfo.isEditMode ){
			var dataIndex = data.index;
			if(self.collection.addUpperFolderItemFlag == true){
				dataIndex = dataIndex -1;
			}
			if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
				showCheck = true;
			}
		}
		if ( showCheck == true ){
			renderer.iconNumber++;
			renderer.editNum = renderer.iconNumber;
			setIconInfo(input, renderer.iconNumber, {
				x: self.params.icon1X, 
				y: self.params.icon1Y, 
				width: self.params.icon1Width, 
				height: self.params.icon1Height,
				async: true,
				unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
				pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
				opacity: 255*0.5,
				clickable: false
			});
		}
		
		if ( renderer.uhdicon != '' ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
				x: self.params.uhdX, 
				y: self.params.uhdY, 
				width: self.params.uhdWidth, 
				height: self.params.uhdHeight,
				async: true,
				unpressSrc: renderer.uhdicon,
				pressedSrc: renderer.uhdicon,
				clickable: false
			});
		}
		
		if ( renderer.sportsIcoSrc != '' ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
				x: self.params.connectX - 35, 
				y: self.params.connectY, 
				width: self.params.connectWidth, 
				height: self.params.connectHeight,
				async: true,
				unpressSrc: renderer.sportsIcoSrc,
				pressedSrc: renderer.sportsIcoSrc,
				clickable: false
			});
		}
		if ( data.unsupportIcon != '' ){
			renderer.iconNumber++;
			renderer.unSupportNum = renderer.iconNumber;
			setIconInfo(input, renderer.iconNumber, {
				x: self.params.icon2X, 
				y: self.params.icon2Y, 
				width: self.params.icon2Width, 
				height: self.params.icon2Height,
				async: true,
				unpressSrc: data.unsupportIcon,
				pressedSrc: data.unsupportIcon,
				clickable: false
			});
		}
		if ( renderer.watchedIconSrc != '' ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
				x: 18,
				y: 249,
				width: 17,
				height: 17,
				async: true,
				unpressSrc: renderer.watchedIconSrc,
				pressedSrc: renderer.watchedIconSrc,
				clickable:false,
			});
		}
		if ( renderer.recordingIconSrc != '' ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
				x: 66, 
				y: 66, 
				width: 88, 
				height: 88,
				async: true,
				unpressSrc: renderer.recordingIconSrc,
				pressedSrc: renderer.recordingIconSrc,
				clickable: false,
			});
		}
	};

	function setFileItemAttribute( data, renderer){
		var editModeView = self.mainView.editModeView;
		if (RunTimeInfo.isEditMode){
			var dataIndex = data.index;
			if(self.collection.addUpperFolderItemFlag == true){
				dataIndex = dataIndex -1;
			}
			if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
				if ( renderer.thumbnail ){
					renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
					dimIconInfo(renderer, renderer.editNum);
				}
			}
			else{
				if(data.ItemType == EItemType.eItemPvr && editModeView.optType == EOptType.eSendType){
					renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
					renderer.thumbnail.dim(true);
				}
			}
		
		}
		else{
			var isDrm = self.collection.getItem(data.index).get('isDrm');
			var isPlayAvailable = self.collection.getItem(data.index).get('isPlayAvailable');
			if(isPlayAvailable == false || isDrm == true){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				dimIconInfo(renderer, renderer.unSupportNum);
			}
		}
	};
	
	function updateFileItemThumbnail( data, renderer){
		prepareFileItemdata( data, renderer);
		var input = {
		    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
	        coverColor: { r: 0, g: 0, b: 0, a: renderer.tempColorPickingOpacity },
	        image: {
	            src: data.ThumbPath,
	            width: self.params.imageWidth,
	            height: self.params.imageHeight,
	            fillMode: renderer.fillModeType, //default fillmode is stretch 
	        },
	        information: {
				x: 0, 
				y: self.params.imageHeight, 
				width: self.params.renderWidth, 
				height: self.params.infoHeight,
				
				colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
				setAsBackground: renderer.UHDVideoFlag,
				highContrast: {
					color: { r: 13, g: 13, b: 13, a: 255 },
		            textColor: { r: 255, g: 255, b: 255, a: 255 },
		            highlightTextColor: {r:0xfb, g:0xba, b:0x2d, a:255}

		        },
					enlarge:{
                         factor: 1.5,
                         anchorPoint: "bottom",
         		},
	            text1: {
	            	text: data.title1,
	                font: 'SamsungSmart_Light 24px',
					x: renderer.infomationTextX, 
					y: self.params.text1Y, 
					width: renderer.infomationTextW, 
					height: self.params.text1Height,
	                horizontalAlignment: 'center',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                extractColorOpacity: 153,
	            },
	        },
			icon1: {
				x: self.params.connectX, 
				y: self.params.connectY, 
				width: self.params.connectWidth, 
				height: self.params.connectHeight,
				async: true,
				unpressSrc: renderer.contenticon,
				pressedSrc: renderer.contenticon,
				clickable: false,
			},
		};
		print('data.ThumbPath',data.ThumbPath);
		addFileItemIcon( data, renderer, input);
		renderer.thumbnail.setThumbnailStyle(input);
		print(' data.title1',data.title1);
		setFileItemAttribute( data, renderer);
		renderer.thumbnail.show();
		print('finish LoadData setThumbnailStyle index:',data.index);
	};

	function getUhdThumb(contentId){
		var thumb = null;
		print('getUhdThumb >>>>>>>>>  contentId:',contentId);
		if(contentId == null){
			return thumb;
		}

		var i = 0;
		for(i = 0; i < UHDTumbnail.Tumbnail.length; i++){
			if(contentId == UHDTumbnail.Tumbnail[i]){
				print('Find thumb contentId:',contentId);
				thumb = resMgr.getImgPath()+'/UHDThumb/'+contentId +'.png';
				break;
			}
		}
		print('getUhdThumb >>>>>>>>>>>  thumb:',thumb);
		return thumb;
	};
	
	ContentViewBase.prototype.t_CreateList = function() {
	
	};
	
	ContentViewBase.prototype.t_DestroyList = function(){
		
	};
	
	ContentViewBase.prototype.makeDataSource = function(){
		print("[ContentViewBase.js] makeDataSource");
	};

	ContentViewBase.prototype.playGroup = function(index){
		print('[ContentViewBase.js] play Group!');		
	};	
	
	exports = ContentViewBase;

	
