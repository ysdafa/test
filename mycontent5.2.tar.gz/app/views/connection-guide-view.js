 /** 
 * @author  Hu shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Connection guide view
 * @date    2014/07/14 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Backbone = Volt.require('modules/backbone.js');
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var CGFocusPos = CommonInfo.CGFocusPos;
var ConnectionGuidesViewTemplate = Volt.require('app/templates/1080/connectionguides-view-template.js');
var Q = Volt.require('modules/q.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var EventType = CommonInfo.EventType;
var self = null;
var ViewGlobalData = Volt.require("app/views/view-global-data.js");
var DeviceProvider = Volt.require("app/models/device-provider.js");
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var voiceGuide = Volt.require('app/common/voice-guide.js');
var voltapi =  Volt.require('voltapi.js');
var buttonText = resMgr.getText('TV_SID_BUTTON');
var firstEnterMobileText = resMgr.getText('COM_MY_CONTENT')+', ' + resMgr.getText('TV_SID_CONNECTION_GUIDES')+', '
					+ resMgr.getText('TV_SID_GUIDE_USE_SMARTHUB_PERSONAL_MULTIMEDIA') +', '
					+ resMgr.getText('COM_SID_HOW_TO_CONNECT_MOBILE_DEVICE')+', '
					+ buttonText ;
					//+ resMgr.getText('TV_SID_MIX_CHECK_EMANUAL_CONNECT_DEVICE_SUPPORT');

var firstEnterPCText = resMgr.getText('COM_MY_CONTENT')+', ' + resMgr.getText('TV_SID_CONNECTION_GUIDES')+', '
					+ resMgr.getText('TV_SID_GUIDE_USE_SMARTHUB_PERSONAL_MULTIMEDIA') 
					+ resMgr.getText('COM_SID_HOW_TO_CONNECT_PC')+' '
					+ buttonText;

var firstEnterUsbText = resMgr.getText('COM_MY_CONTENT')+', ' + resMgr.getText('TV_SID_CONNECTION_GUIDES')+', '
					+ resMgr.getText('TV_SID_GUIDE_USE_SMARTHUB_PERSONAL_MULTIMEDIA') 
					+ resMgr.getText('COM_SID_HOW_TO_CONNECT_USB_DRIVE')+' '
					+ buttonText;

var pcButtonText = resMgr.getText('COM_SID_HOW_TO_CONNECT_PC')+' ' + buttonText;
var mobileButtonText = resMgr.getText('COM_SID_HOW_TO_CONNECT_MOBILE_DEVICE')+ ' ' + buttonText;
var usbButtonText = resMgr.getText('COM_SID_HOW_TO_CONNECT_USB_DRIVE') +' ' + buttonText;
var offSet = RunTimeInfo.offSet;
var AccessibilityType = {
	ACCESSIBILITY_TYPE_NONE:0,
	ACCESSIBILITY_TYPE_ONLY_HIGHCONTRAST:1,
	ACCESSIBILITY_TYPE_ONLY_ENLARGE:2,
	ACCESSIBILITY_TYPE_BOTH:3,	
};
/**
 * Display Connection guide View  
 * @param {Object} Connection guide View 
 * @param 
 * @constructor
 * @extends {BaseView}
 */
var ConnGuidesView= PanelCommon.BaseView.extend({
	hasDestroy: false,
	mobileBtn: null,
	usbBtn: null,
	btnListener: null,
	first:true,
	connectGuide: null,
	template: ConnectionGuidesViewTemplate.container,
	isHighContrast : false,
	isFocuszoom : false,
	vconfMenuLang:'',
	mouseListener: null,
	
    /** Initialize connectguide view  	 
	* @name initialize	 
	* @memberOf ConGuidesPage
	* @method
	* @return {Object}	 
	* */
	initialize: function(options){
		print("[connectionguide]---------initialize");
		if ( DeviceProvider.getDeviceCount() < 1 ){
			Log.e("connectionguide initialize device count < 1 , hide setting button");
			
			EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SETTING);
		}	
	
				
		Volt.KPIMapper.enterPage('MY_CONNECTION_GUIDE_PG');
		self = this;
		self.vconfMenuLang = voltapi.vconf.getValue('db/menu_widget/language');
		print(" self.vconfMenuLang : "+self.vconfMenuLang);
		EventMediator.on(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
        EventMediator.on(EventType.EVENT_TYPE_ENLARGE_CHANGE, this.onEnlargeChange, this);
		
		EventMediator.on(EventType.EVENT_TYPE_CURSOR_HIDE, this.onConnGuideCursorHide, this);	
		EventMediator.on(EventType.EVENT_TYPE_CURSOR_SHOW, this.onConnGuideCursorShow, this);
		
		DeviceProvider.regsiterListener(self,self.onDeviceConnect,self.onDeviceDisconnect, null);
	},
	isLongLang:function(){

		if(self.vconfMenuLang == 'my_MM.utf8' 
			|| self.vconfMenuLang == 'ru_RU.utf8'
			|| self.vconfMenuLang == 'ta_IN.utf8'
			|| self.vconfMenuLang == 'bn_IN.utf8'
			|| self.vconfMenuLang == 'ml_IN.utf8'
			|| self.vconfMenuLang == 'ka_GE.utf8'			
			){
			return true;
		}

		return false;
	},
	setLongLang:function(){
		Log.e("setLongLang");
		var guide_mobile = self.widget.getDescendant('guide_mobile');

		var connectGuideText = self.widget.getDescendant('connectGuideText');
		connectGuideText.lineSpacing = 12;
		connectGuideText.height = connectGuideText.height +12;

		var connectDownText = self.widget.getDescendant('connectDownText');
		connectDownText.lineSpacing = 10;
		
		guide_mobile.x = guide_mobile.x-200;			
		guide_mobile.y = guide_mobile.y+13;		
		guide_mobile.width = guide_mobile.width+200;
		
		//self.mobileBtn.x = self.mobileBtn.x-200;				
		self.mobileBtn.width = self.mobileBtn.width+200;
		self.mobileBtn.y = self.mobileBtn.y+13;
			
		var guide_mobile_icon = self.widget.getDescendant('guide_mobile_icon');
		guide_mobile_icon.x = guide_mobile_icon.x + 100;
		guide_mobile_icon.y = guide_mobile_icon.y + 13;
		
		var guide_mobile_text = self.widget.getDescendant('guide_mobile_text');
		guide_mobile_text.x = guide_mobile_text.x +100;
		guide_mobile_text.y = guide_mobile_text.y +13;

		var guide_mobile_descrip = self.widget.getDescendant('guide_mobile_descrip');
		guide_mobile_descrip.width = guide_mobile_descrip.width+200;
		guide_mobile_descrip.y = guide_mobile_descrip.y+13;
		
		var guide_mobile_top_line = self.widget.getDescendant('guide_mobile_top_line');
		guide_mobile_top_line.width = guide_mobile_top_line.width+200;
		guide_mobile_top_line.y = guide_mobile_top_line.y+13;
		
		var guide_mobile_bottom_line = self.widget.getDescendant('guide_mobile_bottom_line');
		guide_mobile_bottom_line.width = guide_mobile_bottom_line.width+200;
		guide_mobile_bottom_line.y = guide_mobile_bottom_line.y+13;
		
		var guide_mobile_right_line = self.widget.getDescendant('guide_mobile_right_line');
		guide_mobile_right_line.x = guide_mobile_right_line.x+200;
		guide_mobile_right_line.y = guide_mobile_right_line.y+13;

		var guide_mobile_left_line = self.widget.getDescendant('guide_mobile_left_line');
		guide_mobile_left_line.y = guide_mobile_left_line.y + 13;


		var guide_usb = self.widget.getDescendant('guide_usb');
		guide_usb.width = guide_usb.width+200;
		guide_usb.y = guide_usb.y+13;
		
		self.usbBtn.width = self.usbBtn.width+200;
		self.usbBtn.y = self.usbBtn.y+13;
		
		var guide_usb_icon = self.widget.getDescendant('guide_usb_icon');
		guide_usb_icon.x = guide_usb_icon.x + 100;
		guide_usb_icon.y = guide_usb_icon.y + 13;
		
		var guide_usb_text = self.widget.getDescendant('guide_usb_text');
		guide_usb_text.x = guide_usb_text.x +100;
		guide_usb_text.y = guide_usb_text.y +13;
		
		var guide_usb_descrip = self.widget.getDescendant('guide_usb_descrip');
		guide_usb_descrip.width = guide_usb_descrip.width+200;
		guide_usb_descrip.y = guide_usb_descrip.y+13;
		
		var guide_usb_top_line = self.widget.getDescendant('guide_usb_top_line');
		guide_usb_top_line.width = guide_usb_top_line.width+200;
		guide_usb_top_line.y = guide_usb_top_line.y+13;
		
		var guide_usb_bottom_line = self.widget.getDescendant('guide_usb_bottom_line');
		guide_usb_bottom_line.width = guide_usb_bottom_line.width+200;
		guide_usb_bottom_line.y = guide_usb_bottom_line.y+13;
		
		var guide_usb_right_line = self.widget.getDescendant('guide_usb_right_line');
		guide_usb_right_line.x = guide_usb_right_line.x+200;
		guide_usb_right_line.y = guide_usb_right_line.y+13;
		
		var guide_usb_left_line = self.widget.getDescendant('guide_usb_left_line');
		
		guide_usb_left_line.y = guide_usb_left_line.y+13;
	
	},
	onHighcontrastChange:function(){
		print('connect-guide-view.js:----------- onHighcontrastChange()');		
		self.setTextAccessilibity();
	},
	
	onEnlargeChange:function(){
		print('connect-guide-view.js:------- onEnlargeChange()');
		self.setTextAccessilibity();	
	},
    

	/** Render
	* @name render	 
	* @memberOf ConnGuidesView
	* @method
	* @return {Object} 	 
	* */
	render : function(){
		print('mcConnectionGuideView.js : render()');
		Stage.show();
		try{
			if(self.connectGuide != null){
				Log.e(" connectGuide is exist, destroy it  ");
				print(" connectGuide is exist, destroy it  ");
				
				self.connectGuide.destroy();
			}
			
			var mainView = Volt.require('app/views/main-view.js');
			var conGuideWidget = loadTemplate(this.template, null, mainView.getViewContainer(), false);
			self.connectGuide = conGuideWidget;
			self.resetWidgetText();
			self.setWidget(conGuideWidget);
			
			var textWgt = new TextWidgetEx({
					x:0,
					y:0,
					font: 'SamsungSmart_Light 42px',
			        text: resMgr.getText('COM_IDWS_MOIP_MOBILE_KR_MO'),
			        parent: scene,
			        opacity: 0,
			        verticalAlignment: 'center',
			        ellipsize: true,				       
			    });
				
			var textWidth = textWgt.width;
			print("[connectGuide.js] text width:", textWidth);
			textWgt.destroy();
			textWgt = null;
			self.mobileBtn = self.widget.getDescendant('guide_mobile_btn');
			self.usbBtn = self.widget.getDescendant('guide_usb_btn');
			var imageMobile = self.widget.getDescendant('guide_mobile_icon');
			var textMobile = self.widget.getDescendant('guide_mobile_text');
			var imageX = self.mobileBtn.width/2 - (imageMobile.width + 21 + textWidth)/2;
			print("[connectGuide.js] text imageX:", imageX);
			imageMobile.x = imageX;
			textMobile.x = imageX + imageMobile.width + 21;
			
			if(self.isLongLang()){
				self.setLongLang();	
			}
			self.renderButton();	
			self.addButtonListener();
			
			self.setTextAccessilibity();	
			
	        var LoadingView = Volt.require('app/views/loading-view.js');
			print('connection guide hide loading....');
			
			if(RunTimeInfo.isLoadingShown == true){
				LoadingView.hide();	
				RunTimeInfo.isLoadingShown = false;
				EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
			}	
		}catch(e){

			print("mcConnectionGuideView.js : render() e"+e);
		}
		return self;
	},

	/** reset connect guide view textwidget text
	* @name resetWidgetText	 
	* @memberOf ConnGuidesView
	* @method
	* @return {Object} 	 
	* */
	resetWidgetText: function(){
		print('connection-guide-view.js resetWidgetText()');
		if(self.connectGuide == null){
			return;
		}
		self.connectGuide.getChild('connectGuideTitle').text = resMgr.getText('COM_SID_CONNECT_YOUR_DEVICE');
		self.connectGuide.getChild('connectGuideText').text = resMgr.getText('TV_SID_GUIDE_USE_SMARTHUB_PERSONAL_MULTIMEDIA');
		self.connectGuide.getDescendant('guide_mobile_text').text = resMgr.getText('COM_IDWS_MOIP_MOBILE_KR_MO');
		self.connectGuide.getDescendant('guide_mobile_descrip').text = resMgr.getText('COM_SID_HOW_TO_CONNECT_MOBILE_DEVICE');
		self.connectGuide.getDescendant('guide_usb_text').text = resMgr.getText('COM_SID_USB');
		self.connectGuide.getDescendant('guide_usb_descrip').text = resMgr.getText('COM_SID_HOW_TO_CONNECT_USB_DRIVE');
		var connText = resMgr.getText('TV_SID_EMANUAL_SMART_FEATURES') +" > " + resMgr.getText('TV_SID_EMANUAL_USING_MY_CONTENTS_PANELS');
		var downText = resMgr.getText('TV_SID_MIX_CHECK_OUT_MANUAL_TOPIC_MORE_WAY_CONNECT_DEVICE').replace('<<A>>',connText);
		self.connectGuide.getChild('connectDownText').text = downText;
	},

	/** show
	* @name show	 
	* @memberOf ConGuidesPage
	* @param {enum} aniType
	* @return object  	 
	* */
	show: function(aniType) {
		print('mcConnectionGuideView.js : show() focus = ',ViewGlobalData.conguidefocus);
		var mainView = Volt.require('app/views/main-view.js');
		
		if (ViewGlobalData.conguidefocus == CGFocusPos.FOCUS_MOBILE && RunTimeInfo.visibleCursor == false){
			if(self.mobileBtn != null){
				Volt.Nav.focus(self.mobileBtn);
			}
		}else if (ViewGlobalData.conguidefocus == CGFocusPos.FOCUS_USB && RunTimeInfo.visibleCursor == false){
			if(self.usbBtn != null){
				Volt.Nav.focus(self.usbBtn);
			}
		}else{
			Volt.Nav.setRoot(mainView.widget);			
			if(DeviceProvider.getDeviceCount() == 0){	
				if(self.mobileBtn != null){
					Log.e("getDeviceCount is 0");
					Volt.Nav.focus(self.mobileBtn);
				}
				else{
					Log.e("getDeviceCount is 0,mobileBtn is null");
					Volt.Nav.focus(Volt.Nav.getItem(0));
				}
			}
		}
		
        self.widget.show();
		return PanelCommon.doViewSwitchAni(this.widget,'SHOW_NONE');
    },
    
    /** hide connect guide page 	 
	* @name hide	 
	* @memberOf ConGuidesPage
	* @method
	* @return {void} 	 
	* */
    hide: function(aniType) {
        print("------ConnGuidesView hide()!");
        return PanelCommon.doViewSwitchAni(this.widget,'HIDE_NONE');
    },
	
	/** addButtonListener
	* @name addButtonListener	 
	* @memberOf ConnGuidesView
	* @method
	* @return {void} 	 
	* */
	addButtonListener: function(){
		print('connection-guide-view.js addButtonListener()');				
		
		var buttonListener = new ButtonListener;
		self.btnListener = buttonListener;
		buttonListener.onButtonClicked = self.onButtonClick;

		if(self.mobileBtn != null){
			self.mobileBtn.addListener(buttonListener);
			self.mobileBtn.show();
		}

		if(self.usbBtn != null){
			self.usbBtn.addListener(buttonListener);
			self.usbBtn.show();
		}

	},

	onButtonClick : function (button, type){
		print('----connection-guide-view.js buttonListener type = ',type);
		if(button.id == 'guide_mobile_btn'){
			Volt.KPIMapper.addEventLog('MY_SELECT_GUIDE_MOBILE');
			print("connection-guide-view.js guide_mobile_btn onButtonClick switchView to:"+EViewType.eConnectMobileGuideView);
			Log.e("connection-guide-view.js guide_mobile_btn onButtonClick switchView to:"+EViewType.eConnectMobileGuideView);
			RunTimeInfo.router.switchView(EViewType.eConnectMobileGuideView, EViewSwitchAniType.eNoneAni);				
		}
		else if(button.id == 'guide_pc_btn'){
			/*
			Volt.KPIMapper.addEventLog('MY_SELECT_GUIDE_PC');
			RunTimeInfo.router.switchView(EViewType.eConnectPcGuideView, EViewSwitchAniType.eNoneAni);
			*/
		}
		else if(button.id == 'guide_usb_btn'){
			Volt.KPIMapper.addEventLog('MY_SELECT_GUIDE_USB');
			print("connection-guide-view.js guide_usb_btn onButtonClick switchView to:"+EViewType.eConnectMobileGuideView);
			Log.e("connection-guide-view.js guide_usb_btn onButtonClick switchView to:"+EViewType.eConnectMobileGuideView);
			RunTimeInfo.router.switchView(EViewType.eConnectUsbGuideView, EViewSwitchAniType.eNoneAni);
		}
    },
    
	events: {
        //'NAV_SELECT': 'onSelect',        
        'NAV_FOCUS':'onFocus',
        'NAV_BLUR':'onBlur'
    },

	/** onFocus
	* @name onFocus	 
	* @memberOf ConnGuidesView
	* @param {Object} widget id
	* @method
	* @return {void} 	 
	* */
    onFocus: function(widget){
        print('[ConnGuidesView.js] ConnGuidesView.onFocus id =',widget.id);
		//widget.opacity = 255;		   		
		if(widget.id == 'guide_mobile_btn'){			
		    self.setBtnAccessilibity(self.mobileBtn);		    								
			if(self.first){				
				voiceGuide.play(firstEnterMobileText);
				self.first = false;
			}else{
				voiceGuide.play(mobileButtonText);

			}				
			ViewGlobalData.conguidefocus = CGFocusPos.FOCUS_MOBILE;
			if(RunTimeInfo.visibleCursor == true){
				self.widget.getDescendant('guide_mobile_text').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 46px';	
				self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 29px';
				self.widget.getDescendant('guide_mobile_icon').width = 25;
				self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_p.png';
			}
			else{
				self.widget.getDescendant('guide_mobile_text').textColor = {r:0x00, g:0x00, b:0x00};
				self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 42px';	
				self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x00, g:0x00, b:0x00};
				self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 26px';
				self.widget.getDescendant('guide_mobile_icon').width = 23;
				self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_f.png';
			}
		}
		else if(widget.id == 'guide_usb_btn'){			
			self.setBtnAccessilibity(self.usbBtn);							
			if(self.first){				
				voiceGuide.play(firstEnterUsbText);
				self.first = false;
			}else{
				voiceGuide.play(usbButtonText);
			}
			
			ViewGlobalData.conguidefocus = CGFocusPos.FOCUS_USB;	
			if(RunTimeInfo.visibleCursor == true){
				self.widget.getDescendant('guide_usb_text').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 46px';	
				self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 29px';
				if(VDUtil.getResolution() == 1280){
					self.widget.getDescendant('guide_usb_icon').width = 56;
					self.widget.getDescendant('guide_usb_icon').height = 56;
				}
				else{
					self.widget.getDescendant('guide_usb_icon').width = 56;
					self.widget.getDescendant('guide_usb_icon').height = 50;
				}
				self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_p.png';

			}
			else{
				self.widget.getDescendant('guide_usb_text').textColor = {r:0x00, g:0x00, b:0x00};
				self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 42px';
				self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x00, g:0x00, b:0x00};
				self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 26px';
				self.widget.getDescendant('guide_usb_icon').width = 50;
				self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_f.png';
			}
		}	

		EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
    },    
	
	 /** onBlur
	* @name onBlur	 
	* @memberOf ConnGuidesView
	* @param {Object} widget id
	* @method
	* @return {void} 	 
	* */
    onBlur: function(widget){
        print('[main-view.js] ConnGuidesView.onBlur');
		if( widget==null ){
			return;
		}
		if( self.hasDestroy == true ){
			return;
		}
	//	ViewGlobalData.conguidefocus = CGFocusPos.FOCUS_NONE;
		if(widget.id == 'guide_mobile_btn'){
			self.widget.getDescendant('guide_mobile_icon').width = 23;
			self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_n.png';
			//self.widget.getDescendant('guide_mobile_icon').opacity= 179;
			self.widget.getDescendant('guide_mobile_text').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 42px';
			self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 26px';	
		}
		else if(widget.id == 'guide_pc_btn'){
			self.widget.getChild('guide_pc').opacity = 255;
		}
		else if(widget.id == 'guide_usb_btn'){
			self.widget.getDescendant('guide_usb_icon').width = 50;
			self.widget.getDescendant('guide_usb_icon').height = 50;
			self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_n.png';
			//self.widget.getDescendant('guide_usb_icon').opacity= 179;
			self.widget.getDescendant('guide_usb_text').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 42px';
			self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 26px';
		}
    },

	onConnGuideCursorHide: function(){
		print("connection-guide-view.js onConnGuideCursorHide");
		if(ViewGlobalData.conguidefocus == CGFocusPos.FOCUS_MOBILE){
			if(self.mobileBtn != null){
				Volt.Nav.focus(self.mobileBtn);
			}
			self.widget.getDescendant('guide_mobile_text').textColor = {r:0x00, g:0x00, b:0x00};
			self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 42px';	
			self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x00, g:0x00, b:0x00};
			self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 26px';
			self.widget.getDescendant('guide_mobile_icon').width = 23;
			self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_f.png';
			
		}else if(ViewGlobalData.conguidefocus == CGFocusPos.FOCUS_USB){
			if(self.usbBtn != null){
				Volt.Nav.focus(self.usbBtn);
			}
			self.widget.getDescendant('guide_usb_text').textColor = {r:0x00, g:0x00, b:0x00};
			self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 42px';
			self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x00, g:0x00, b:0x00};
			self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 26px';
			self.widget.getDescendant('guide_usb_icon').width = 50;
			self.widget.getDescendant('guide_usb_icon').height = 50;
			self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_f.png';
		}else{
			self.widget.getDescendant('guide_mobile_icon').width = 23;
			self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_n.png';
			//self.widget.getDescendant('guide_mobile_icon').opacity= 179;
			self.widget.getDescendant('guide_mobile_text').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 42px';
			self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 26px';

			self.widget.getDescendant('guide_usb_icon').width = 50;
			self.widget.getDescendant('guide_usb_icon').height = 50;
			self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_n.png';
			//self.widget.getDescendant('guide_usb_icon').opacity= 179;
			self.widget.getDescendant('guide_usb_text').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 42px';
			self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x78, g:0x78, b:0x78};
			self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 26px';
		}
    },

	onConnGuideCursorShow: function(){
		print("connection-guide-view.js onConnGuideCursorShow");
		if(ViewGlobalData.conguidefocus == CGFocusPos.FOCUS_MOBILE){
			self.widget.getDescendant('guide_mobile_text').textColor = {r:0x21, g:0x9e, b:0xe6};
			self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 46px';	
			self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x21, g:0x9e, b:0xe6};
			self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 29px';
			self.widget.getDescendant('guide_mobile_icon').width = 25;
			self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_p.png';
		}else if(ViewGlobalData.conguidefocus == CGFocusPos.FOCUS_USB){
			self.widget.getDescendant('guide_usb_text').textColor = {r:0x21, g:0x9e, b:0xe6};
			self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 46px';	
			self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x21, g:0x9e, b:0xe6};
			self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 29px';
			if(VDUtil.getResolution() == 1280){
				self.widget.getDescendant('guide_usb_icon').width = 56;
				self.widget.getDescendant('guide_usb_icon').height = 56;
			}
			else{
				self.widget.getDescendant('guide_usb_icon').width = 56;
				self.widget.getDescendant('guide_usb_icon').height = 50;
			}
			self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_p.png';
		}else{
		
		}
    },
    
    /** the click event 
	* @name onKeyEvent	 
	* @memberOf ConnGuidesView	
	* @param {key} the key id
	* @parm {type} the key type
	* @return {boolean} 	
	* @method */ 

	onKeyEvent : function(key, type){
		print('[connection-guide-view.js] ------ onKeyEvent');
		if(type != Volt.EVENT_KEY_RELEASE){
			return false;
		}
		
		var ret = true;	
		switch(key){
			case Volt.KEY_RETURN :
				Volt.exit();
				break;	
	     	default:
    	    	ret = false;
    	    	break;
		}
		
		return ret;
	},
	
	setTextAccessilibity: function(){
		print("setTextAccessilibity ");
		
		if(HALOUtil.highContrast==false && HALOUtil.enlarge==false){
			self.setTextStyle(AccessibilityType.ACCESSIBILITY_TYPE_NONE);
	    }else if(HALOUtil.highContrast==false && HALOUtil.enlarge==true){			   
			self.setTextStyle(AccessibilityType.ACCESSIBILITY_TYPE_ONLY_ENLARGE);		    	
	    }else if(HALOUtil.highContrast==true && HALOUtil.enlarge==false){	    	 
	    	self.setTextStyle(AccessibilityType.ACCESSIBILITY_TYPE_ONLY_HIGHCONTRAST);		    	
	    }else {
	    	self.setTextStyle(AccessibilityType.ACCESSIBILITY_TYPE_BOTH);		    	
	    }
		
	},
	
	setBtnAccessilibity: function(button){
		if(button == null || button == undefined){
			Log.e("setBtnAccessilibity button == null || button == undefined");
			print("setBtnAccessilibity button == null || button == undefined");
			return;
		}
		
		print("setBtnAccessilibity button.id:"+ button.id);
		if(HALOUtil.highContrast==false && HALOUtil.enlarge==false){
			
			self.setBtnStyle(button, AccessibilityType.ACCESSIBILITY_TYPE_NONE);
	    }else if(HALOUtil.highContrast==false && HALOUtil.enlarge==true){		    	
			self.setBtnStyle(button,AccessibilityType.ACCESSIBILITY_TYPE_ONLY_ENLARGE);	
			
	    }else if(HALOUtil.highContrast==true && HALOUtil.enlarge==false){
	    	
			self.setBtnStyle(button,AccessibilityType.ACCESSIBILITY_TYPE_ONLY_HIGHCONTRAST);				
				    			    	
	    }else {	    	
			self.setBtnStyle(button,AccessibilityType.ACCESSIBILITY_TYPE_BOTH);	
	    			    	
	    }
		
	},

	
	setTextStyle: function(style){
		print("setTextStyle style:"+style);	
		
    	if(style == AccessibilityType.ACCESSIBILITY_TYPE_NONE){
    		self.restoreTextEnlarge();    		
    		self.restoreTextHighContrast();    		 				  				
    	}else if(style == AccessibilityType.ACCESSIBILITY_TYPE_ONLY_ENLARGE){
    		self.setTextEnlarge();
    		self.restoreTextHighContrast();    		 		 		   		
    	}else if(style == AccessibilityType.ACCESSIBILITY_TYPE_ONLY_HIGHCONTRAST){
    		self.restoreTextEnlarge();    		
    		self.setTextHighContrast();    		    		 		
    	}else{
    		self.setTextEnlarge();    		
    		self.setTextHighContrast();    				 			
    	}
    },
    
    setBtnStyle: function(button,style){
    	print("setBtnStyle style:"+style);	
		
		if(style == AccessibilityType.ACCESSIBILITY_TYPE_NONE){    		
			self.restoreBtnEnlarge(button);    		
			self.restoreBtnHighContrast(button);    			 				  				
		}else if(style==AccessibilityType.ACCESSIBILITY_TYPE_ONLY_ENLARGE){
			self.setBtnEnlarge(button);    		
			self.restoreBtnHighContrast(button);      	    				 		   		
		}else if(style == AccessibilityType.ACCESSIBILITY_TYPE_ONLY_HIGHCONTRAST){
			self.restoreBtnEnlarge(button);    		
			self.setBtnHighContrast(button);    				    		 		
		}else{    		 
			self.setBtnEnlarge(button);    		
			self.setBtnHighContrast(button);    			    		    				 			
		}	
    },
    
    setTextEnlarge: function(){
    	self.widget.getDescendant('connectGuideTitle').font='SamsungSmart_Light 79px';
		self.widget.getDescendant('connectGuideText').font='SamsungSmart_Light 36px';	
		self.widget.getDescendant('connectDownText').font='SamsungSmart_Light 26px'; 
		self.widget.getDescendant('connectGuideTitle').hight= 80;
		if(self.isLongLang() == true){
			self.widget.getDescendant('connectGuideTitle').y= 40; 
		}else{
			
			self.widget.getDescendant('connectGuideTitle').y= 50; 
		}
		if(self.isLongLang()){
		//	self.widget.getDescendant('connectGuideTitle').hight= 80;
		//	self.widget.getDescendant('connectGuideTitle').y= 50; 
			self.widget.getDescendant('connectGuideText').width=1500;
			self.widget.getDescendant('connectGuideText').x = 210+offSet;	
			self.widget.getDescendant('connectGuideText').hight = 92;
		}else{
		//	self.widget.getDescendant('connectGuideTitle').hight= 80;
		//	self.widget.getDescendant('connectGuideTitle').y= 50; 
			self.widget.getDescendant('connectGuideText').width=1200;
			self.widget.getDescendant('connectGuideText').x= 360+offSet;	
		}
  	
    },
    restoreTextEnlarge: function(){
    	self.widget.getDescendant('connectGuideTitle').font='SamsungSmart_Light 66px';
		self.widget.getDescendant('connectGuideText').font='SamsungSmart_Light 30px';	
		self.widget.getDescendant('connectDownText').font='SamsungSmart_Light 22px'; 
		
		self.widget.getDescendant('connectGuideTitle').hight= 80;
		
		if(self.isLongLang() == true){
			self.widget.getDescendant('connectGuideTitle').y= 50;
		}else{
			self.widget.getDescendant('connectGuideTitle').y= 75;
		}
		if(self.isLongLang()){
			self.widget.getDescendant('connectGuideText').width=1200;
			self.widget.getDescendant('connectGuideText').x=360+offSet; 
		}else{
			if(self.vconfMenuLang == 'hy_AM.utf8'){
				self.widget.getDescendant('connectGuideText').width=1200;
			}else{
				self.widget.getDescendant('connectGuideText').width = 950;
			}
			self.widget.getDescendant('connectGuideText').x=485+offSet; 
		}
		   	
    },
    setTextHighContrast: function(){
    	self.widget.getDescendant('connectGuideTitle').textColor = {r:0x00, g:0x00, b:0x00};
    	self.widget.getDescendant('connectGuideText').textColor = {r:0x00, g:0x00, b:0x00};
    	self.widget.getDescendant('connectDownText').textColor = {r:0x00, g:0x00, b:0x00};  	
    },
    restoreTextHighContrast: function(){
    	self.widget.getDescendant('connectGuideTitle').textColor = {r:0x0f, g:0x18, b:0x27};
    	self.widget.getDescendant('connectGuideText').textColor = {r:0x37, g:0x3c, b:0x42};
    	self.widget.getDescendant('connectDownText').textColor = {r:0x78, g:0x78, b:0x78}; 
    	  	
    },
    
    setBtnEnlarge: function(button){
    	if(button.id == 'guide_mobile_btn'){
    		self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_f.png';		
				self.widget.getDescendant('guide_mobile_icon').opacity= 255;
				//self.widget.getDescendant('guide_mobile_text').textColor = {r:0x00, g:0x00, b:0x00};
				//self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x00, g:0x00, b:0x00};
				self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 31px';	
    		
    		
    	}else if(button.id == 'guide_usb_btn'){
    		self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_f.png';		
				self.widget.getDescendant('guide_usb_icon').opacity= 255;
				//self.widget.getDescendant('guide_usb_text').textColor = {r:0x00, g:0x00, b:0x00};
				//self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x00, g:0x00, b:0x00};
				self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 31px';  		
    	}  
    	
    		    	
    },
    restoreBtnEnlarge: function(button){
    	print("restoreBtnEnlarge");
    	if(button.id == 'guide_mobile_btn'){
    		self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_f.png';
    		self.widget.getDescendant('guide_mobile_icon').opacity= 255;
			//self.widget.getDescendant('guide_mobile_text').textColor = {r:0x00, g:0x00, b:0x00};
			//self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x00, g:0x00, b:0x00};
			self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 26px';    			
    		
    		
    	}else if(button.id == 'guide_usb_btn'){
    		self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_f.png';		
			self.widget.getDescendant('guide_usb_icon').opacity= 255;
			//self.widget.getDescendant('guide_usb_text').textColor = {r:0x00, g:0x00, b:0x00};
			//self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x00, g:0x00, b:0x00};
			self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 26px';
    		 		
    	} 
   			
    },
    
    setBtnHighContrast: function(button){
    	if(button.id == 'guide_mobile_btn'){  
    		
    		self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_n.png';
			self.widget.getDescendant('guide_mobile_icon').opacity= 255;
			//self.widget.getDescendant('guide_mobile_text').textColor = {r:0x78, g:0x78, b:0x78};
			//self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x78, g:0x78, b:0x78};	
			
			self.mobileBtn.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
			self.mobileBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_h_conn.png'});	
			self.mobileBtn.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_h_conn.png'});
			self.mobileBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_h_conn.png'});  			
    		
    		
    	}else if(button.id == 'guide_usb_btn'){
    		
    		self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_n.png';
			self.widget.getDescendant('guide_usb_icon').opacity= 255;
			//self.widget.getDescendant('guide_usb_text').textColor = {r:0x78, g:0x78, b:0x78};
			//self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x78, g:0x78, b:0x78};	
			
			self.usbBtn.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
			self.usbBtn.setBackgroundImage({state: "focused", src: resMgr.getImgPath()+'/button/btn_style_a_f_h_conn.png'});	
			self.usbBtn.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f_h_conn.png'});
			self.usbBtn.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f_h_conn.png'});    		 		
    	} 
    	    	
    },
    
    
    restoreBtnHighContrast: function(button){
    	if(button.id == 'guide_mobile_btn'){ 
    		
    		self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_f.png';
			self.widget.getDescendant('guide_mobile_icon').opacity= 255;
			//self.widget.getDescendant('guide_mobile_text').textColor = {r:0x78, g:0x78, b:0x78};
			//self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x78, g:0x78, b:0x78};	
				
			self.mobileBtn.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
			self.mobileBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});	
			self.mobileBtn.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});
			self.mobileBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});    			
    		
    		
    	}else if(button.id == 'guide_usb_btn'){
    		
    		self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_f.png';
			self.widget.getDescendant('guide_usb_icon').opacity= 255;
			//self.widget.getDescendant('guide_usb_text').textColor = {r:0x78, g:0x78, b:0x78};
			//self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x78, g:0x78, b:0x78};
			
			self.usbBtn.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
			self.usbBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});	
			self.usbBtn.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});
			self.usbBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});
    		
    		 		
    	}  
    	       	
    },
	

	onDeviceConnect:function(){
		print("Connection guide onDeviceConnect");
		Log.e("Connection guide onDeviceConnect");
		if ( DeviceProvider.getDeviceCount() > 0 ){
			print("Connection guide onDeviceConnect show setting ");
			Log.e("Connection guide onDeviceConnect show setting ");
			EventMediator.trigger(EventType.EVENT_TYPE_SHOW_SETTING);
		}
	},
	
	onDeviceDisconnect:function(){
		print("Connection guide onDeviceDisconnect");
		Log.e("Connection guide onDeviceDisconnect");
		if ( DeviceProvider.getDeviceCount() < 1 ){
			print("Connection guide onDeviceDisconnect hide setting ");
			Log.e("Connection guide onDeviceDisconnect hide setting ");
			EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SETTING);
		}
	},
	
	/** destroy connectguide view  	 
	* @name destroy	 
	* @memberOf ConGuidesPage
	* @method
	* @return {Object}	 
	* */
	destroy : function(){
		print("[connectionguide]---------destroy");
		
		if(self.mobileBtn){
			self.mobileBtn.removeListener(self.btnListener);
		}
		if(self.usbBtn){
			self.usbBtn.removeListener(self.btnListener);
		}
		
	    DeviceProvider.unregsiterListener(self,self.onDeviceConnect,self.onDeviceDisconnect, null);
	EventMediator.off(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
        EventMediator.off(EventType.EVENT_TYPE_ENLARGE_CHANGE, this.onEnlargeChange, this);

		EventMediator.off(EventType.EVENT_TYPE_CURSOR_HIDE, this.onConnGuideCursorHide, this);	
		EventMediator.off(EventType.EVENT_TYPE_CURSOR_SHOW, this.onConnGuideCursorShow, this);

		//self.widget.hide();
		self.widget.destroy();
		self.mobileBtn = null;
		self.usbBtn = null;
		self.hasDestroy = true;
		self.connectGuide = null;
	},

	isInRootPath:function(){
		return true;
	},
	
	renderButton: function(){
    	self.mobileBtn.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
		self.mobileBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});	
		self.mobileBtn.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});
		self.mobileBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});				                      		
		self.mobileBtn.setFocus();
    	self.mobileBtn.Show();
    		 	
    	self.usbBtn.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
		self.usbBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});
		self.usbBtn.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});
		self.usbBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_conn.png'});								                      		
		self.usbBtn.setFocus();
    	self.usbBtn.Show();

		var naviMouseListener = new MouseListener();
		self.mouseListener = naviMouseListener;
		self.mouseListener.onMousePointerIn = function(actor, event){
			print('mouseListener----------------------------mouse pointer in : ' + actor);
			print('mouseListener----------------------------screenWidth : ' + VDUtil.getResolution());
			if(actor == self.mobileBtn){
				self.widget.getDescendant('guide_mobile_text').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 46px';	
				self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 29px';
				self.widget.getDescendant('guide_mobile_icon').width = 25;
				self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_p.png';
			}
			else if(actor == self.usbBtn){
				self.widget.getDescendant('guide_usb_text').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 46px';	
				self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x21, g:0x9e, b:0xe6};
				self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 29px';
				if(VDUtil.getResolution() == 1280){
					self.widget.getDescendant('guide_usb_icon').width = 56;
					self.widget.getDescendant('guide_usb_icon').height = 56;
				}
				else{
					self.widget.getDescendant('guide_usb_icon').width = 56;
					self.widget.getDescendant('guide_usb_icon').height = 50;
				}
				self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_p.png';
			}
		};
		
		self.mouseListener.onMousePointerOut = function(actor, event){
			print('mouseListener----------------------------mouse pointer out : ' + actor);
			if(actor == self.mobileBtn){
				self.widget.getDescendant('guide_mobile_icon').width = 23;
				self.widget.getDescendant('guide_mobile_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_phone_n.png';
				self.widget.getDescendant('guide_mobile_text').textColor = {r:0x78, g:0x78, b:0x78};
				self.widget.getDescendant('guide_mobile_text').font = 'SamsungSmart_Light 42px';
				self.widget.getDescendant('guide_mobile_descrip').textColor = {r:0x78, g:0x78, b:0x78};
				self.widget.getDescendant('guide_mobile_descrip').font = 'SamsungSmart_Light 26px';	
			}
			else if(actor == self.usbBtn){
				self.widget.getDescendant('guide_usb_icon').width = 50;
				self.widget.getDescendant('guide_usb_icon').height = 50;
				self.widget.getDescendant('guide_usb_icon').src = resMgr.getImgPath()+'/Connection/home/home_conn_usb_n.png';
				self.widget.getDescendant('guide_usb_text').textColor = {r:0x78, g:0x78, b:0x78};
				self.widget.getDescendant('guide_usb_text').font = 'SamsungSmart_Light 42px';
				self.widget.getDescendant('guide_usb_descrip').textColor = {r:0x78, g:0x78, b:0x78};
				self.widget.getDescendant('guide_usb_descrip').font = 'SamsungSmart_Light 26px';
			}
		};

		self.mobileBtn.addMouseListener(naviMouseListener);
		self.usbBtn.addMouseListener(naviMouseListener);
	},
	
	setFocusReturnFromMusicPlayer:function(){
		print("connection guide view setFocusReturnFromMusicPlayer set root to mainView.widget");
		var mainView = Volt.require('app/views/main-view.js');
		Volt.Nav.setRoot(mainView.widget);
	},
});

exports = ConnGuidesView;

