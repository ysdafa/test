 /** 
 * @author  Zhao Rui (rui9527.zhao@samsung.com)			
 * 			
 * @fileoverview  All content view 
 * @date    2014/09/20 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var resMgr = Volt.require('app/controller/resource-controller.js');
	var BaseModel = Volt.require("app/models/base-model.js");
	var ContentViewBase = Volt.require("app/views/content-view-base.js");
	var CommonInfo = Volt.require("app/common/define.js");
	var EItemType = CommonInfo.EItemType;
	var EViewType = CommonInfo.EViewType;
	var MyContentOptionType = CommonInfo.MyContentOptionType;
	var OptionText = Volt.require("app/common/option-text.js");
	var VideoFilterTextList = OptionText.VideoFilterTextList;
	var AllSortByTextList = OptionText.AllSortByTextList;
	var AllContentViewTemplate = Volt.require('app/templates/1080/all-view-template.js');
	var RunTimeInfo = Volt.require("app/common/run-time-info.js");
	var PanelCommon = Volt.require('lib/panel-common.js');
	var loadTemplate = PanelCommon.loadTemplate;
	var ViewGlobalData = Volt.require("app/views/view-global-data.js");
	var EventMediator = RunTimeInfo.EventMediator;
	var EventType = CommonInfo.EventType;
	var nativeGridlistFocus = CommonInfo.nativeGridlistFocus;
	var CONST = CommonInfo.CONST;
	var self = null;
	var CategoryName = CommonInfo.CategoryName;
	var DeviceType = CommonInfo.DeviceType;
	var launchParams = Volt.require("app/common/launch-params.js");
/**
 * Display device all content 
 * @param {Object} all content class proterties
 * @param 
 * @constructor
 * @extends {ContentViewBase}
 */
	var AllContentView = ContentViewBase.extend({
		listItemNum : 27,
        arrItems : [],
        template: AllContentViewTemplate.container,
        templateList: AllContentViewTemplate.list,
        focusWidget: null,
        params: {},
		events: {
	        'NAV_FOCUS':'onFocus',
	        'NAV_BLUR':'onBlur'
	    },
		/** Render
		* @name render	 
		* @memberOf AllContentView
		* @method 
		* @return {Object}	 
		* */	
		render : function(){
		    print('all-content-view.js render');
			self = this;			
			return this;
		},

		/** OnFocus
		* @name onFocus	 
		* @memberOf AllContentView
		* @param {widget} current get focus widget
		* @method 
		* @return {}	 
		* */	
		onFocus: function(widget) {
	        print('all-content-view.js onFocus');
			Log.e("all-content-view.js onFocus");
			if(this.nativeGridList != null){
				EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
				this.nativeGridList.enableFocus();
				//this.nativeGridList.setFocus();
			    this.nativeGridList.showFocus('false');
			    this.nativeGridList.setFocusImage(resMgr.getImgPath()+'/common/ksc_focus.png', -8, -8);

				this.nativeGridList.showFocus("true");
				ViewGlobalData.isGridListFocus = true;
			}

	    },

		/** OnBlur
		* @name onBlur	 
		* @memberOf AllContentView
		* @param {widget} current lose focus widget
		* @method 
		* @return {}	 
		* */	
	    onBlur: function(widget) {
	        print('all-content-view.js onBlur');
			Log.e("all-content-view.js onBlur");
	        if( this.nativeGridList != null ){
				this.nativeGridList.hideFocus("true");
				print(" ViewGlobalData.isGridListFocus = false");
				ViewGlobalData.isGridListFocus = false;
	        }
	    },

		/** Make Data Source
		* @name makeDataSource	 
		* @memberOf AllContentView
		* @param {devPath} scan path
		* @method 
		* @return {}	 
		* */	
		makeDataSource : function(devPath){
			print('all-content-view.js, makeDataSource devPath:'+devPath);
						
			var subfolder = launchParams.getSubFolder();
			print("all content makeDataSource subfolder :"+subfolder);
			Log.e("all content makeDataSource subfolder :"+subfolder);
			if(subfolder != null && subfolder != '' && subfolder != '/'
				&& launchParams.getSubFolderUseStatus() == false){
				Log.e("all content makeDataSource enterSpecialFolder ");
				print("all content makeDataSource enterSpecialFolder ");
				//launchParams.resetSubFolder();
				launchParams.setSubFolderUseStatus(true);
				self.enterSpecialFolder(devPath,subfolder);

				return;
			}
			
			if(ViewGlobalData.parentFielPathStack.length != 0){
		        devPath = ViewGlobalData.currFilePath;
			}
			else{
				ViewGlobalData.rootPath = devPath;
			}

			var sortType = 'CATEGORY-FOLDER';
			var contentType = 'CONTENT-FOLDER';

			
			if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB)
			{
				//call content-view-base requestUsbDataList
				this.requestUsbDataList(devPath, contentType, sortType);
			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA)
			{
				//call content-view-base requestDlnaDataList
				this.requestDlnaDataList(contentType,sortType);
			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_RA)
			{
				//call content-view-base requestRaDataList
				this.requestRaDataList(contentType, sortType);
			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_PTP){
				this.requestPTPDataList(contentType,sortType);
			}
		},


		/** Update Widget
		* @name updateWidget	 
		* @memberOf AllContentView
		* @param {int} index 
		* @param {Object} data item
		* @param {Object} parent widget
		* @method
		* @return {} 	 
		* */
		updateWidget : function(index, item, widget){
			print('[updateWidget]  ItemType ',item.get('ItemType'));
		    if(item.get('ItemType') == EItemType.eItemFolder ||
		       item.get('ItemType') == EItemType.eItemUpFolder ||
			   item.get('ItemType') == EItemType.eItemGroup){
			   
				if(widget.getChild(1)!= null){
					widget.getChild(1).getUIElement().setTextContent({text: item.get('title1'),textHorizontalAlignment:'center'});
				}
			}
		    else{
		 
				if((widget.getChild(2) != null) && (widget.getChild(2).getChild(0)!= null)){
					widget.getChild(2).getChild(0).getUIElement().setTextContent({text: item.get('title1')});
					
				}
		    }
		},

		/** Get Option Text
		* @name getOptionText	 
		* @memberOf AllContentView
		* @method
		* @return {} 	 
		* */
		getOptionText : function(){
            if(this.mainView.headerView.optionParam.secondSelectedIndex[0] == -1){
                var filterType = 'All';
				var sortType = '';
			}
			else{
				var filterIndex = this.mainView.headerView.optionParam.secondSelectedIndex[0];
				var filterType = resMgr.getText(VideoFilterTextList.DeviceTypeTextList[filterIndex]);
				var sortType = '';
			}

			var optionText = [];
			if ( this.mainView.categoryView.currentType  == DeviceType.DEVICE_TYPE_USB ){
				optionText = [];
				print('*********setting flag: ',this.mainView.folderPathViewFlag)

				var id = self.mainView.categoryView.currentID;
				var DeviceProvider = Volt.require("app/models/device-provider.js");
				if( ViewGlobalData.parentFielPathStack.length != 0 && DeviceProvider.isUHDDevice(id) ){
					optionText = self.getUHDText();
				}
				else{
					optionText = [
				        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
			            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
				    ];
					var tempLen = optionText.length;
					if(self.mainView.getRecordSupportFlag() == 1){
						optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_DEL);
					}
					tempLen = optionText.length;
					optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY);
					if ( self.mainView.getCopySupportFlag() ){
						tempLen = optionText.length;
						optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_COPY);
					}
					
					if (self.mainView.getCopySupportFlag() && (DeviceProvider.getUsbDeviceCount() <= 1|| DeviceProvider.isUHDDevice(id) )){
						print('dim send');
						self.isDimFirstPlus[4] = true;
					}
					self.isDimFirstPlus = [];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
						self.isShowSecPlus[index] = false;
					}
					self.isDimFirstPlus[1] = true;
					self.isDimFirstPlus[2] = true;
					self.isDimFirstPlus[3] = true;
					self.isShowSecPlus[0] = true;
				}
			}
			else if ( this.mainView.categoryView.currentType  == DeviceType.DEVICE_TYPE_DLNA ){
			
				optionText = [];
				if(this.mainView.folderPathViewFlag){
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isDimFirstPlus[1] = true;
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = false;
				}
				else{
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isDimFirstPlus[1] = true;
					self.isDimFirstPlus[2] = true;
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = false;
					self.isShowSecPlus[2] = false;
					
				}

			}
			else{
		
				optionText = [];
				if(this.mainView.folderPathViewFlag){
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isDimFirstPlus[1] = true;
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = false;
				}
				else{
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isDimFirstPlus[1] = true;
					self.isDimFirstPlus[2] = true;
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = false;
					self.isShowSecPlus[2] = false;
					
				}

			}
			
			this.mainView.headerView.optionParam.firstOptionText = optionText;
			this.mainView.headerView.optionParam.firstHeight = 72*(optionText.length);


		},

		/** Get Sort By Text
		* @name getSortByText	 
		* @memberOf AllContentView
		* @method
		* @return {String} 	 
		* */	
		getSortByText : function(){
		    var Text;
		
			/*the true text please refer the gui of content*/
		
			Text = self.getResourceText(AllSortByTextList.DeviceTypeTextList);
			if( this.mainView.headerView.filterView.optionMenuSubIndex[1] > (Text.length-1) ){
				this.mainView.headerView.filterView.optionMenuSubIndex[1] = Text.length-1;
			}
			return Text;
	    },

		/** Get Second Option Text
		* @name getSecondOptionText	 
		* @memberOf AllContentView
		* @param {nListIndex} select option index
		* @method
		* @return {String} 	 
		* */	
		getSecondOptionText : function(nListIndex){
			var Text;
			print('getSecondOptionText'+nListIndex);
			switch(nListIndex){
				/*Filter*/
				case 0:
					Text = self.getFilterText();
					break;

				case 1:
					Text = self.getSortByText();
					break;

				default:
					break;
			}
			return Text;
		},
		/** Get getRenderInfo
		* @name getRenderInfo	 
		* @memberOf AllContentView
		* @param {} 
		* @method
		* @return {String} 	 
		* */	
		getRenderInfo : function(){
			print("getRenderInfo UHDContentFolder:"+RunTimeInfo.UHDContentFolder);
			if(RunTimeInfo.UHDContentFolder == true){
			    var mustache = {
			        columnWidth: AllContentViewTemplate.uhd_content_list.renderWidth,
			        rowHeight: AllContentViewTemplate.uhd_content_list.renderHeight,
			        renderNumber: AllContentViewTemplate.uhd_content_list.listItemNum,
			        renderColumn: AllContentViewTemplate.uhd_content_list.renderColumn,
			    };
			}else{
			    var mustache = {
			        columnWidth: AllContentViewTemplate.list.renderWidth,
			        rowHeight: AllContentViewTemplate.list.renderHeight,
			        renderNumber: AllContentViewTemplate.list.listItemNum,
			        renderColumn: AllContentViewTemplate.list.renderColumn,
			    };
			}
			return mustache;
		},
		
		/** Get getTextWidgetNumber
		* @name getTextWidgetNumber	 
		* @memberOf AllContentView
		* @param {} 
		* @method
		* @return {int} 	 
		* */

		getTextWidgetNumber : function(){
		    var mustache = AllContentViewTemplate.list.textIndex;
			return mustache;
		},

		getFilterOption: function(){
			//return 'Filter by All';
			return resMgr.getText('COM_SID_FILTER_BY') + ' ' + resMgr.getText('UID_FILTER_ALL'); 
		},
	});

	/** Create List
	* @name t_CreateList	 
	* @memberOf AllContentView
	* @method
	* @return {} 	 
	* */
    AllContentView.prototype.t_CreateList = function(){
		self.createNativeGridList();
	}
	
	AllContentView.prototype.t_DestroyList = function(){
		print('[AllContentView  ] t_DestroyList');
		if(self.focusWidget !== null){
			self.focusWidget.loseFocus();
			//self.focusWidget.destroy();
		}
		self.collection.cancelAllThumbnailRequest();

		print('AllContentView  Remove native grid control');
		if(self.nativeGridList != null){
			
			self.nativeGridList.custom.focusable = false;
			Volt.Nav.removeItem(self.nativeGridList);
			self.widget = null;
		}

	}

exports = AllContentView;
