/** 
* @author  Hu Po (paul.hu@samsung.com)
* 			
* @fileoverview  Music Player List Render
* @date    2014/11/05 (last modified date)
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/
var resMgr = Volt.require('app/controller/resource-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
//PanelCommon.mapWidgets(['AutoScrollTextWidget']);
var MusicListTemplate = Volt.require('app/templates/1080/musicplayer-list-template.js');
var loadTemplate = PanelCommon.loadTemplate;

var launchParams = Volt.require("app/common/launch-params.js");
var CommonInfo = Volt.require("app/common/define.js");
var LaunchedByAppID = CommonInfo.LaunchedByAppID;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var self = null;
var ToGetResolution = Volt.require("app/common/run-time-info.js");

ListRender = function(){
	this.renderer = null,
	this.root = null,
	this.width = 0,
	this.height = 0,
	this.data = null,
	this.template = MusicListTemplate.listItem,
	this.normalTxtColor = {r:255, g:255, b:255, a:204},
	this.whiteInFocus = {r:255, g:255, b:255, a:255},
	this.focusTxtColor = {r:255, g:255, b:255, a:255},
	this.currTxtColor = {r:251, g:186, b:45, a:255},
	this.unsupportColor = {r:255, g:255, b:255, a:38},
	this.highCon = false;
	this.imageLocalName = null;
	self = this;

    this.setNormalTxtColor = function(R, G, B){
        if(R != null && G != null && B != null){
			this.normalTxtColor = {r:R*0.8, g:G*0.8, b:B*0.8, a:255};
		}
	};
	
	this.getRender = function(parentWidth, parentHeight, data){
		this.width = parentWidth;
		this.height = parentHeight;
		this.data = data;
		this.renderer = new Renderer(parentWidth, parentHeight);

		this.renderer.root = new WidgetEx(
		{
		   x:0,
		   y:0,
		   width:parentWidth,
		   height:parentHeight,
		   parent:scene,
		   color: {r:0, g:0, b:0, a:0}
		});
		this.imageLocalName = new Array();
		var i =0;
		for (i = 1; i <= 15; ++i) 
		{
			if (i < 10) 
			{

				this.imageLocalName[i - 1] = "mc_icon_playlist_equalizer_0" + i + ".png";

			}
			else 
			{

				this.imageLocalName[i - 1] = "mc_icon_playlist_equalizer_" + i + ".png";

			}

		}

		this.renderer.thumbnail = loadTemplate(self.template);
		this.renderer.thumbnail.show();

		this.renderer.onDraw = this.onDraw;
		this.renderer.onRelease = this.onRelease;
		this.renderer.onUpdate = this.onUpdate;
		this.renderer.onResize = this.onResize;

		this.highCon = Vconf.getValue('db/menu/system/accessibility/highcontrast');

		return this.renderer;
	};

	this.onDraw = function(rendererInstance, drawTypeString, data, parentWidth, parentHeight){
		Log.e('this onDraw is for index = '+ data.index+ ' drawTypeString = '+ drawTypeString+ 'rendererInstance=' + rendererInstance);		
		Volt.log('[music-list-render.js]---this onDraw is for index = '+ data.index+ ', drawTypeString = '+ drawTypeString+ ', rendererInstance=' + rendererInstance);
        if ("LoadData" == drawTypeString){
			if( data.index % 2 == 0 )
			{
			    rendererInstance.thumbnail.setInformationColor({r:0 ,g:0 ,b:0 ,a:28});
			}
			rendererInstance.thumbnail.setInformationText('text1',String(data.title));
			rendererInstance.thumbnail.setInformationText('text2',String(data.artist));	

			self.commonStyle(rendererInstance,data);

			if( data.avail == false )
			{
				self.unsupportStyle(rendererInstance);
			}	
			//print("----------------onDraw--------------------------");
			var playerController = Volt.require('app/controller/play-controller.js');
			var currentPlayItemIndex = playerController.getCurrentIdx();
			//print("[music-list-render.js]---------------- Create loading -------------currentPlayItemIndex is " +currentPlayItemIndex + " data.index is " + data.index);
			if (data.index == currentPlayItemIndex) 
			{

				print("[music-list-render.js]---------------- Create loading and playing loading-----currentPlayItemIndex is " +currentPlayItemIndex + " data.index is " + data.index + " playerController.getState() is " + playerController.getState() );
				//loading.SetParentOfLoadingAndPlay(rendererInstance.thumbnail);
				//loading.play();	
				if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
				{
					Volt.log('[music-list-render.js]---onDraw---CurrentPlayLoading != null');
					Log.e('[music-list-render.js]---onDraw---CurrentPlayLoading != null');
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.parent = rendererInstance.thumbnail;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.x = 54;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.y = 32;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
					
				}
				else
				{				
					//var CurrentPlayLoading = null;
					print("music play list  onDraw new Loading");
					Log.e("music play list  onDraw new Loading");
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading = new Loading({
					parent: rendererInstance.thumbnail,
					imageNum: 15,
			        x:54,
			        y:32,				
					imageWidth: 22,
					imageHeight: 22,
					imageFPS: 30,
					imagePath: resMgr.getImgPath()+"/equalizer/",
					imageName: self.imageLocalName,
					});
				}
			}
			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
			{
				Log.e("[music-list-render.js]----onDraw---the state is " + playerController.getState());
				if (playerController.getState() == 3) // if it is in play status then play
				{
					Volt.log('[music-list-render.js]----onDraw---the state is playing, to play here--');
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
				}
				else if (playerController.getState() == 4)
				{
					Volt.log('[music-list-render.js]----onDraw---the state is PAUSE, to PAUSE here--');
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
					
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.pause();
				}
				else
				{
					Volt.log('[music-list-render.js]----onDraw---the state is not playing not pause, also to play here--');
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
				}
			}				
			
		}        
		else if("UpdateData" == drawTypeString){
			rendererInstance.thumbnail.setInformationText('text1',String(data.title));
			rendererInstance.thumbnail.setInformationText('text2',String(data.artist));	

			self.commonStyle(rendererInstance,data);

			if( data.avail == false ){
				self.unsupportStyle(rendererInstance);
			}
       	}        
		else if("FromItemFocusChangeAniStart" == drawTypeString){
			print('[music-list-render.js]--onDraw--FromItemFocusChangeAniStart');
			data.focus = false;
			//The from item of focus change motion start                   
		}        
		else if("ToItemFocusChangeAniStart" == drawTypeString){
			data.focus = true;
			//The to item of focus change motion start
		}        
		else if("FormItemFocusChangeAniEnd" == drawTypeString){
			var playerController = Volt.require('app/controller/play-controller.js');
			var currentPlayItemIndex = playerController.getCurrentIdx();
			print("[music-list-render.js]--onDraw--FormItemFocusChangeAniEnd data.idx = "+ data.index + " currentPlayItemIndex is " + currentPlayItemIndex);
			self.commonStyle(rendererInstance, data);
			if ( (currentPlayItemIndex == data.index))//the player status is pause, then stop do not play
			{
				if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
				{
					Volt.log('[music-list-render.js]-----this.onDraw---FormItemFocusChangeAniEnd--from current play to another item--to play------');
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.parent = rendererInstance.thumbnail;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.x = 54;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.y = 32;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();	
					
					if (playerController.getState() == 4)
					{
						Volt.log('[music-list-render.js]--onDraw---FormItemFocusChangeAniEnd---when playerController.getState() is 4, then to Pause animation');
						Volt.require("app/common/run-time-info.js").CurrentPlayLoading.pause();
					}
					
					if (data.avail == false)
					{
						if (RunTimeInfo.notSupportSong == true)// it is for the case, when click next song which is nt supported, then currentplayloading is still running
						{
							// it should be stop
							Volt.log('[music-list-render.js]---FormItemFocusChangeAniEnd---it is the not supportSong, data.avail is false, set the parent to scene');
							Volt.require("app/common/run-time-info.js").CurrentPlayLoading.parent = scene;
							Volt.require("app/common/run-time-info.js").CurrentPlayLoading.x = -30;
							Volt.require("app/common/run-time-info.js").CurrentPlayLoading.y = -30;	
							RunTimeInfo.notSupportSong = false;
						}					
					}
			
				}

			}	
			if( data.avail == false ){
				self.unsupportStyle(rendererInstance);
			}				
			//The from item of focus change motion start
		}        
		else if("ToItemFocusChangeAniEnd" == drawTypeString){
			var playerController = Volt.require('app/controller/play-controller.js');
			var currentPlayItemIndex = playerController.getCurrentIdx();
			if ((playerController.getState() == 4) && (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null))
			{
				//CurrentPlayLoading.play();
				Volt.log('[music-list-render.js]-----this.onDraw---ToItemFocusChangeAniEnd--to pause the animation to solve the when focus change into list from control');
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
						
				var num =100000;
				while (num != 0)
				{
					num--;
				}
				
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.pause();
				//Volt.log('[music-list-render.js]-----this.onDraw---ToItemFocusChangeAniEnd--to pause the animation to solve the when focus change into list from control---7');

				
			}				
			print("[music-list-render.js]--onDraw--ToItemFocusChangeAniEnd data.idx = "+ data.index + " currentPlayItemIndex is " + currentPlayItemIndex);
			self.focusStyle(rendererInstance, data);
			//The to item of focus change motion finish
		}
		else if ("UnloadData" == drawTypeString) 
		{    
			var playerController = Volt.require('app/controller/play-controller.js');
			var currentPlayItemIndex = playerController.getCurrentIdx();
			//print("[music-list-render.js]---------------- UnloadData to destroy loading -------------currentPlayItemIndex is " +currentPlayItemIndex + " data.index is " + data.index);
     		if (data.index == currentPlayItemIndex)
			{
				print("[music-list-render.js]---------------- UnloadData to change the parent, not destory right now loading -------------currentPlayItemIndex is " +currentPlayItemIndex + " data.index is " + data.index);
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.parent = scene;
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.x = -30;
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.y = -30;
			}
   }

		
    };
		
	this.onUpdate = function(width, height){
	};

	this.onResize = function(rendererInstance, data, destWidth, destHeight, flagWithAni, duration){
		print('renderer.onResize~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
	};
		
	this.onRelease = function(){
		delete self.renderer;    
	};

	this.commonStyle = function(rendererInstance, data){
		Volt.log('[music-list-render.js]-----commonStyle------');
		if( rendererInstance != null ){
			if( data.index % 2 == 0 ){
			    rendererInstance.thumbnail.setInformationColor({r:0 ,g:0 ,b:0 ,a:28});
			}
			else{
			    rendererInstance.thumbnail.setInformationColor({r:0 ,g:0 ,b:0 ,a:1});
			}

			rendererInstance.thumbnail.setElementOpacity('icon1', 0);
			rendererInstance.thumbnail.setElementOpacity('icon2', 0);
			rendererInstance.thumbnail.setElementOpacity('icon3', 0);
			rendererInstance.thumbnail.setElementOpacity('icon4', 0);

			var focusWgt = Volt.Nav.getFocusedWidget();
			if( data.focus == true && focusWgt!=null && focusWgt.id == 'playList'){
				Log.e("[music-list-render.js]---commonStyle---ready to set focusStyle for index = "+ data.index);
				print("[music-list-render.js]---commonStyle---ready to set focusStyle for index = "+ data.index);
				self.focusStyle(rendererInstance, data);
				return;
			}
			
			var playerController = Volt.require('app/controller/play-controller.js');
			var currIdx = playerController.getCurrentIdx();
			if( currIdx==data.index ){
				Log.e('[music-list-render.js]---commonStyle---ready to set currentStyle for index = '+ data.index);
				print('[music-list-render.js]---commonStyle---ready to set currentStyle for index = '+ data.index);
				self.currentStyle(rendererInstance);
				return;
			}
			
			rendererInstance.thumbnail.setElementAllocation('information', {x: 0, width: 820});
			rendererInstance.thumbnail.setElementAllocation("information-text1", {x: 54, width: 428});
			rendererInstance.thumbnail.setElementAllocation('information-text2', {x: 536});
			//rendererInstance.thumbnail.setElementAllocation("information-icon1", {x: 0, y: 0, width: 86, height: 86});
			//rendererInstance.thumbnail.setElementAllocation('information-icon2', {x: 54, y: 32, width: 22, height: 22});		
			//rendererInstance.thumbnail.setElementAllocation("information-icon3", {x: 54, y: 30, width: 26, height: 26});
			//rendererInstance.thumbnail.setElementAllocation('information-icon4', {x: 0, y: 0, width: 86, height: 86});			
			//if (!Vconf.getValue('db/menu/system/accessibility/highcontrast'))//(self.highCon==false)//
			{
				rendererInstance.thumbnail.setInformationTextColor('text1',this.normalTxtColor);
				rendererInstance.thumbnail.setInformationTextColor('text2',this.normalTxtColor);
			}
		}
	};

	this.focusStyle = function(rendererInstance, data){
		if( rendererInstance != null ){
			var playerController = Volt.require('app/controller/play-controller.js');
			var currentPlayItemIndex = playerController.getCurrentIdx();
			
			if ( (currentPlayItemIndex == data.index))//the player status is pause, then stop do not play
			{
				Volt.log('[music-list-render.js]-----this.focusStyle----to sotp CurrentPlayLoading, change the parent to scene');
				Log.e('[music-list-render.js]-----this.focusStyle----to sotp CurrentPlayLoading, change the parent to scene');
				if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
				{
					//Volt.require("app/common/run-time-info.js").CurrentPlayLoading.stop();
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.parent = scene;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.x = -30;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.y = -30;					
				}

			}	
			
			rendererInstance.thumbnail.setAttachIconImage('icon1',{unpressSrc: data.thumbUrl, pressedSrc: data.thumbUrl});
			rendererInstance.thumbnail.setAttachIconImage('icon4',{unpressSrc: resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_album_default.PNG', pressedSrc: resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_album_default.PNG'});
			if(!Vconf.getValue('db/menu/system/accessibility/highcontrast'))
			{

				//rendererInstance.thumbnail.setInformationColor({r:255,g:255,b:255,a:242});
				rendererInstance.thumbnail.setInformationTextColor('text1',this.normalTxtColor);
				rendererInstance.thumbnail.setInformationTextColor('text2',this.normalTxtColor);
				
			}


			rendererInstance.thumbnail.setElementOpacity('icon1', 255);
			rendererInstance.thumbnail.setElementOpacity('icon2', 0);
			rendererInstance.thumbnail.setElementOpacity('icon3', 0);
			rendererInstance.thumbnail.setElementOpacity('icon4', 255);
            if(Vconf.getValue('db/menu/system/accessibility/focuszoom') == true){
			    rendererInstance.thumbnail.setElementAllocation('information', {y: -10});
            }
			else{
			    rendererInstance.thumbnail.setElementAllocation('information', {y: 0});
			}
		
			rendererInstance.thumbnail.setElementAllocation('information', {x: 86, width: 740});
			rendererInstance.thumbnail.setElementAllocation('information-text1', {x: 26, width: 356});
			rendererInstance.thumbnail.setElementAllocation('information-text2', {x: 450});

			if(!Vconf.getValue('db/menu/system/accessibility/highcontrast')){
				rendererInstance.thumbnail.setInformationTextColor('text1',this.focusTxtColor);
				rendererInstance.thumbnail.setInformationTextColor('text2',this.focusTxtColor);
			}
			else
			{
				rendererInstance.thumbnail.setInformationTextColor('text1',this.whiteInFocus);
				rendererInstance.thumbnail.setInformationTextColor('text2',this.whiteInFocus);
			}
		}
	};

	this.unsupportStyle = function(rendererInstance){
		if( rendererInstance != null ){
			rendererInstance.thumbnail.setAttachIconImage('icon3',{unpressSrc: resMgr.getImgPath()+'/play_List_icon/mc_icon_playlist_notsupport.PNG', pressedSrc: resMgr.getImgPath()+'/play List icon/mc_icon_playlist_notsupport.PNG'});
			rendererInstance.thumbnail.setElementOpacity('icon2', 0);
			rendererInstance.thumbnail.setElementOpacity('icon3', 38);
			rendererInstance.thumbnail.setElementAllocation('information', {x: 0, width: 820});
			rendererInstance.thumbnail.setElementAllocation('information-text1', {x: 86, width: 396});
			rendererInstance.thumbnail.setElementAllocation('information-text2', {x: 536});
			rendererInstance.thumbnail.setInformationTextColor('text1',this.unsupportColor);
			rendererInstance.thumbnail.setInformationTextColor('text2',this.unsupportColor);
		}
	};

	this.currentStyle = function(rendererInstance){
		Volt.log('[music-list-render.js]---this.currentStyle is called---')
		if( rendererInstance != null ){

			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
			{
				var playerController = Volt.require('app/controller/play-controller.js');
				//Volt.log('[music-list-render.js]-----this.currentStyle---CurrentPlayLoading is not null----playerController.getState() is ' + playerController.getState());
				Volt.log('[music-list-render.js]----currentStyle---change the parent of animation---keep the original status---');
				Log.e(" [music-list-render.js]----currentStyle update  CurrentPlayLoading.parent");
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.parent = rendererInstance.thumbnail;
			}
			else
			{
				Volt.log('[music-list-render.js]---Volt.require("app/common/run-time-info.js").CurrentPlayLoading is null');
				Log.e('[music-list-render.js]---Volt.require("app/common/run-time-info.js").CurrentPlayLoading is null');
			}
			//rendererInstance.thumbnail.setAttachIconImage('icon2',{unpressSrc: resMgr.getImgPath()+'/play_List_icon/mc_icon_playlist_equalizer.png'});
			
			rendererInstance.thumbnail.setElementOpacity('icon2', 255);
			rendererInstance.thumbnail.setElementAllocation('information', {x: 0, width: 820});
			rendererInstance.thumbnail.setElementAllocation('information-text1', {x: 86, width: 396});
			rendererInstance.thumbnail.setElementAllocation('information-text2', {x: 536});
			rendererInstance.thumbnail.setInformationTextColor('text1', this.currTxtColor);
			rendererInstance.thumbnail.setInformationTextColor('text2', this.currTxtColor);
		}
	};
};

exports = ListRender;
 