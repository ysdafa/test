 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Music Player view 
 * @date    2014/09/24 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
//var voltapi = require("voltapi");
var voltapi = Volt.require('voltapi.js');
var BaseView = Volt.BaseView;
var MusicCtrlBarTemplate = Volt.require('app/templates/1080/musicplayer-control-template.js');
var playerController = Volt.require('app/controller/play-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var BalloonTips = Volt.require('app/views/balloon-tips.js');
var AppLauncher = Volt.require("app/controller/app-launch.js");
var launchParams = Volt.require("app/common/launch-params.js");
var LaunchAppID = 'org.tizen.volume-setting';
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var CommonInfo = Volt.require("app/common/define.js");
var LaunchedByAppID = CommonInfo.LaunchedByAppID;
var EventType = CommonInfo.EventType;
var EViewType = CommonInfo.EViewType;
var voiceGuide = Volt.require('app/common/voice-guide.js');	

var self = null;

var MusicPlayerCtrlView = PanelCommon.BaseView.extend({
	template: MusicCtrlBarTemplate.ctrlBar,
    picRepeat: [],
    picShuffle: [],	
    picPlay: [],
    picSpeaker:[],
    picScreen:[],
    picPre:[],
    picNext:[],
    playIns: null,
    balloon: null,
    musicView: null,

	ctrlBar: null,
    speakerBtn: null,
    screenBtn: null,
    preBtn: null,
    pauseBtn: null,
    nextBtn: null,
    repeatBtn: null,
    shuffleBtn: null,
    btnListener: null,

	speakerWidget: null,
	screenWidget: null,
    preWidget: null,
    pauseWidget: null,
    nextWidget: null,
    repeatWidget: null,
    shuffleWidget: null, 

	destroyFlag: false,
	firstEnter:true,
	FlagForSpeakerScreenPreNext:true,
	focusIcon : {
		'speaker_btn' : resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist_f.png',
		'screen_btn' : resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off_f.png',
		'pre_btn' : resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev_f.png',
		'next_btn' : resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next_f.png',
	},
	blurIcon : {
		'speaker_btn' : resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist.png',
		'screen_btn' : resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off.PNG',
		'pre_btn' : resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev.png',
		'next_btn' : resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next.png',
	},

	/**Initialize MusicPlayerCtrlView 	 
	* @name initialize	 
	* @memberOf MusicPlayerCtrlView	 
	* @constructs 	 */	
	initialize: function() {
		self = this;
		
		self.picRepeat.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_repeat_all.png');
		self.picRepeat.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_repeat_off.png');
		self.picRepeat.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_repeat_one.png');
		self.picRepeat.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_repeat_all_f.png');
		self.picRepeat.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_repeat_off_f.png');
		self.picRepeat.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_repeat_one_f.png');		
		
		self.picShuffle.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_shuffle_on.png');
		self.picShuffle.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_shuffle_off.png');	
		self.picShuffle.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_shuffle_on_f.png');
		self.picShuffle.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_shuffle_off_f.png');			

		self.picPlay.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_pause.png');
		self.picPlay.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_play.png');
		self.picPlay.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_pause_f.png');	
		self.picPlay.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_play_f.png');			


        self.picSpeaker.push(resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist.png');
        self.picSpeaker.push(resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist.png');
        self.picSpeaker.push(resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist.png');
        self.picSpeaker.push(resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist.png');

        self.picScreen.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off.png');
        self.picScreen.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off.png');
        self.picScreen.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off.png');
        self.picScreen.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off.png');

        self.picNext.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next.png');
        self.picNext.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next.png');
        self.picNext.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next_f.png');
        self.picNext.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next_f.png');

        self.picPre.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev.png');
        self.picPre.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev.png');
        self.picPre.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev_f.png');
        self.picPre.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev_f.png');

		EventMediator.on(EventType.EVENT_TYPE_PLAY_STATE_CHANGED, this.updatePlayState, this);
	},

	/**render MusicPlayerCtrlView 	 
	* @name render	 
	* @memberOf MusicPlayerCtrlView	 
	* @method 	 */		
	render: function(){
		print(" Music play contrul render ");
		self.playIns = playerController;
		
		var repeatImg = self.getRepeatIcon(self.playIns.getRepeatMode());
		var shuffleImg = self.getShuffleIcon(self.playIns.getShuffleMode());
			
	    var currentItem = {
	        repeatIcon: repeatImg,
	        shuffleIcon: shuffleImg,
	    };	
		var contentWidget = loadTemplate(self.template, currentItem);
		self.setWidget(contentWidget);
		self.renderButton();
		return this;
	},

	renderButton: function(){
		self.speakerWidget = self.widget.getChild('speaker');
		self.speakerBtn = self.widget.getChild('speaker').getChild('speaker_btn');
		if(self.speakerWidget==null || self.speakerBtn==null){
			Log.f("renderButton Can't find speaker, error!");
			Volt.log('[musicplayer-control-view.js]----renderButton----Can not find speaker, error!');
			return;
		}
		self.speakerBtn.setIconAlpha({state: "all", alpha: 204,});
		
		self.screenWidget = self.widget.getChild('screenOff');
		self.screenBtn = self.screenWidget.getChild('screen_btn');
		if(self.screenWidget==null||self.screenBtn==null){
			Log.f("renderButton Can't find screenOff, error!");
			return;
		}	
		self.screenBtn.setIconAlpha({state: "all", alpha: 204,});

		self.preWidget = self.widget.getChild('pre');
		self.preBtn = self.widget.getChild('pre').getChild('pre_btn');
		if(self.preWidget==null || self.preBtn==null){
			Log.f("renderButton Can't find pre, error!");
			return;
		}	
		
		self.pauseWidget = self.widget.getChild('pause');
		self.pauseBtn = self.widget.getChild('pause').getChild('pause_btn');
		if(self.pauseWidget==null || self.pauseBtn==null){
			Log.f("renderButton Can't find pause, error!");
			return;
		}	
		self.pauseBtn.setIconAlpha({state: "all", alpha: 204,});

		self.nextWidget = self.widget.getChild('next');
		self.nextBtn = self.widget.getChild('next').getChild('next_btn');
		if(self.nextWidget==null || self.nextBtn==null){
			Log.f("renderButton Can't find next, error!");
			return;
		}	
		

		self.repeatWidget = self.widget.getChild('repeat');
		self.repeatBtn = self.widget.getChild('repeat').getChild('repeat_btn');
		if(self.repeatWidget==null || self.repeatBtn==null){
			Log.f("renderButton Can't find next, error!");
			return;
		}	
		self.repeatBtn.setIconAlpha({state: "all", alpha: 204,});

		self.shuffleWidget = self.widget.getChild('shuffle');
		self.shuffleBtn = self.widget.getChild('shuffle').getChild('shuffle_btn');
		if(self.shuffleWidget==null || self.shuffleBtn==null){
			Log.f("renderButton Can't find shuffle, error!");
			return;
		}
		self.shuffleBtn.setIconAlpha({state: "all", alpha: 204,});
		print('[musicplayer-control-view.js]----renderButton---launchParams.getLauncherAppName()  is ' + launchParams.getLauncherAppName());
		if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())//launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR
		{
			Volt.log('[musicplayer-control-view.js]----launchParams.isLaunchForMusicPlayer() is true, started from DMR or Search, to set no focus and dim status');
			if (self.repeatBtn != null)
			{
				self.setDimIconForRepeat();
				//self.repeatBtn.setIconAlpha({state: "all", alpha: 100,});
				self.repeatBtn.custom = {focusable: false};
			}
			if (self.shuffleBtn != null)
			{
				self.setDimIconForShuffle();
				//self.shuffleBtn.setIconAlpha({state: "all", alpha: 100,});
				self.shuffleBtn.custom = {focusable: false};
			}

			if (self.nextBtn != null)
			{
				self.setDimIconForBtn(self.nextBtn);
				//self.shuffleBtn.setIconAlpha({state: "all", alpha: 100,});
				self.nextBtn.custom = {focusable: false};			
			}

			if (self.preBtn != null)
			{
				self.setDimIconForBtn(self.preBtn);
				//self.shuffleBtn.setIconAlpha({state: "all", alpha: 100,});
				self.preBtn.custom = {focusable: false};				
			}	
		}
		else
		{
			self.repeatBtn.setIconAlpha({state: "all", alpha: 204,});
			self.shuffleBtn.setIconAlpha({state: "all", alpha: 204,});
			self.preBtn.setIconAlpha({state: "all", alpha: 204,});
			self.nextBtn.setIconAlpha({state: "all", alpha: 204,});
			Volt.log('[musicplayer-control-view.js]----normal operation');
		}
		var buttonListener = new ButtonListener;
		self.btnListener = buttonListener;
		buttonListener.onButtonClicked = function (button, type){
			Log.f('[musicplayer-control-view.js]----edit-mode-view.js buttonListener type = ' + type);
			Volt.log('[musicplayer-control-view.js]-----onButtonClicked----buttonListener type = '+ type);
			if( self.balloon != null ){
	    		self.balloon.destroy();
	    		self.balloon = null;
	    	}
			if(button.id == 'speaker_btn'){
				self.speakerSelectCB();
				Volt.KPIMapper.addEventLog('MY_MUSIC_PLAYER_SPEAKER');
			}
			else if(button.id == 'screen_btn'){
				Log.f("ready to call setPictureOff");
				voltapi.TUNE.init();
				voltapi.TUNE.setPictureOff();
			//	voltapi.TUNE.destroy();		
				Volt.KPIMapper.addEventLog('MY_MUSIC_OFF');
			}
			else if(button.id == 'pre_btn'){
				self.pbPlayPre();
				RunTimeInfo.bFlagForClickNextAndPrev = true;
                //var imgSrc = self.focusIcon[button.id];
                //var imgSrc = self.blurIcon[button.id];
                //self.preBtn.setIconImage({state: "focused", src: imgSrc});
				Volt.KPIMapper.addEventLog('MY_MUSIC_PREVIOUS');
			}
			else if(button.id == 'pause_btn'){
				self.pbPlayPause();
				Volt.KPIMapper.addEventLog('MY_MUSIC_PLAY_PAUSE');
			}
			else if(button.id == 'next_btn'){
				self.pbPlayNext();
				RunTimeInfo.bFlagForClickNextAndPrev = true;
				Volt.KPIMapper.addEventLog('MY_MUSIC_NEXT');
			}
			else if(button.id == 'repeat_btn'){
				self.pbRepeat();
				var repeateMode = '';
				if( self.playIns.repeatMode=="one" ){
		    		repeateMode = 'ONE';
		    	}
				else if( self.playIns.repeatMode=="all" ){
		    		repeateMode = 'ALL';
		    	}
				else if( self.playIns.repeatMode=="off" ){
		    		repeateMode = 'NONE';
		    	}
				Volt.KPIMapper.addEventLog('MY_MUSIC_PLAYER_REPEAT', {
	            	d: {            		
						detail: repeateMode,
		    		}
	        	});
				//self.pbRepeat();
			}
			else if(button.id == 'shuffle_btn'){
				self.pbShuffle();
				print("self.playIns.shuffleMode= ",self.playIns.shuffleMode);
				var kpiShuffleMode = (self.playIns.shuffleMode=="true") ? 'ON' : 'OFF';
				Volt.KPIMapper.addEventLog('MY_MUSIC_PLAYER_SHUFFLE', {
	            	d: {            		
						detail: kpiShuffleMode,
		    		}
	        	});
			}
		};

		if(HALOUtil.getOrientation () == "right-to-left"){
			print('reverse mode!!');
			self.preWidget.x = 611;
			self.nextWidget.x = 405;
		}
		
		self.speakerBtn.addListener(buttonListener);
		self.screenBtn.addListener(buttonListener);

		self.pauseBtn.addListener(buttonListener);
		print('[musicplayer-control-view.js]----renderButton----to addListener');
		if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
		{
			Volt.log('[musicplayer-control-view.js]--renderButton--it is started from DMR  to play a song');
		}
		else
		{
			self.repeatBtn.addListener(buttonListener);
			self.shuffleBtn.addListener(buttonListener);
			self.nextBtn.addListener(buttonListener);
			self.preBtn.addListener(buttonListener);
			Log.e('[musicplayer-control-view.js]---renderButton---to add listener2');
		}
	

	},

	/**destroy MusicPlayerCtrlView	 
	* @name destroy	 
	* @memberOf MusicPlayerCtrlView	 
	* @method 	 */	
	destroy: function(){
		self.destroyFlag = true;
    	if( self.balloon != null ){
    		self.balloon.destroy();
    		self.balloon = null;
    	}

		self.speakerBtn.removeListener(self.btnListener);
		self.screenBtn.removeListener(self.btnListener);

		self.pauseBtn.removeListener(self.btnListener);
		print('[musicplayer-control-view.js]---destory---to removeListener');
		if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())	
		{
			Volt.log('[musicplayer-control-view.js]--destroy----launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer()-');
		}
		else
		{
			Volt.log('[musicplayer-control-view.js]---destroy---to remove listener');
			self.repeatBtn.removeListener(self.btnListener);
			self.shuffleBtn.removeListener(self.btnListener);
			self.preBtn.removeListener(self.btnListener);
			self.nextBtn.removeListener(self.btnListener);
		}	
/*
		if (!launchParams.isLaunchForMusicPlayer()  && (launchParams.getLauncherAppName() != LaunchedByAppID.APP_ID_DMR))
		{
			self.repeatBtn.removeListener(self.btnListener);
			self.shuffleBtn.removeListener(self.btnListener);
		}

		HALOUtil.asyncRelease(self.speakerBtn);
		HALOUtil.asyncRelease(self.screenBtn);
		HALOUtil.asyncRelease(self.preBtn);
		HALOUtil.asyncRelease(self.nextBtn);
		HALOUtil.asyncRelease(self.pauseBtn);
		HALOUtil.asyncRelease(self.repeatBtn);
		HALOUtil.asyncRelease(self.shuffleBtn);
*/
		self.widget.hide();
		self.widget.destroy();		

		self.speakerBtn = null;
		self.screenBtn = null;
		self.preBtn = null;
		self.nextBtn = null;
		self.pauseBtn = null;
		self.repeatBtn = null;
		self.shuffleBtn = null;
		
	    self.speakerWidget = null,
	    self.screenWidget = null,
	    self.preWidget = null,
	    self.pauseWidget = null,
	    self.nextWidget = null,
	    self.repeatWidget = null,
	    self.shuffleWidget = null;

		EventMediator.off(EventType.EVENT_TYPE_PLAY_STATE_CHANGED, this.updatePlayState, this);		
	},

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur',
    },
    
	/**the callback for the button on focus
	* @name onFocus	 
	* @memberOf MusicPlayerCtrlView	 
	* @param {btn} which button has been focused	
	* @method 	 */	
	onFocus: function( btn ) {
		if( btn == null || btn == undefined ){
			return;
		}
		Log.f("[control-view.js] control-view.focus " + btn.id);
		print("[musicplayer-control-view.js]-----onFocus is on " + btn.id);
		if( self.musicView != null ){
			Log.f("self.musicView preFocus set to " + btn.id);
			self.musicView.preFocus = btn;
		}
		
		if(btn.id == 'speaker_btn')
		{
			/*
		    //self.speakerWidget.getChild(0).color.a = 242;
		    self.speakerBtn.setIconImage({state: "all", src: self.focusIcon[btn.id],});
		    self.speakerBtn.setIconAlpha({state: "all", alpha: 255,});
		    
		    //self.picPlay.push(resMgr.getImgPath()+'/music_player_icon/mc_play_icon_pause.png');
		   
			self.speakerWidget.getChild(0).color.a = 0;
			self.speakerBtn.setIconImage({state: "all", src: self.blurIcon[btn.id],});
			self.speakerBtn.setIconAlpha({state: "all", alpha: 204,});
			 */
		    self.speakerBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/common/4way_focus.png'});
			self.speakerBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/common/4way_focus.png'});
		    if (Vconf.getValue('db/menu/system/accessibility/highcontrast'))
			{
				var imgSrc = null;
			/*	
				if( self.speakerWidget.getChild(0).color.a == 242 )
				{
		                imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist_f.png';
				}
				else
			*/	
				{
		                imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_icon_playlist_speakerlist.png';
				}
				Volt.log('[musicplayer-control-view.js]---onFocus---imgSrc is ' + imgSrc);
				self.speakerBtn.setIconImage({state: "focused", src: imgSrc});
			}
		                    
		    //self.ContrlFocusInHighContrast(self.speakerWidget, self.speakerBtn, 'speaker_btn');
		}
		else if(btn.id == 'screen_btn')
		{
			//self.screenWidget.getChild(0).color.a = 242;
		/*	
			self.screenBtn.setIconImage({state: "all", src: self.focusIcon[btn.id],});
			self.screenBtn.setIconAlpha({state: "focused", alpha: 255,});
		*/
			
		    self.screenBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/common/4way_focus.png'});
			self.screenBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/common/4way_focus.png'});
			if (Vconf.getValue('db/menu/system/accessibility/highcontrast'))
			{
                Volt.log("-----------licm-------------screen_btn-- in musicplayer-control-view.js-------");
                var imgSrc = null;
			/*	
                if( self.screenWidget.getChild(0).color.a == 242 )
                {
                    imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off_f.png';
                }
                else
               	*/ 
                {
                    imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_screen_off.png';
                }
                self.screenBtn.setIconImage({state: "focused", src: imgSrc});
			}
			//self.ContrlFocusInHighContrast(self.screenWidget, self.screenBtn, 'screen_btn');
		}                              
		else if(btn.id == 'pre_btn')
		{
		    //self.preWidget.getChild(0).color.a = 0;// if it is commented then, it is transparent
		    //self.preWidget.getChild(0).color =Volt.hexToRgb('#60748b','242');
		    //Volt.hexToRgb('#60748b','100'),
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onFocus---DMR pre_btn--setDimIconForShuffle');
				//self.setDimIconForShuffle();			
			}
			else
			{
				/*
				self.preBtn.setIconImage({state: "all", src: self.focusIcon[btn.id],});
		    	self.preBtn.setIconAlpha({state: "all", alpha: 255,});
		    	*/
		    	self.preBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/common/4way_focus.png'});
				self.preBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/common/4way_focus.png'});
/*		    			
			    if (Vconf.getValue('db/menu/system/accessibility/highcontrast'))
			    {
	                Volt.log("-----------licm-------------pre btn in musicplayer-control-view.js-------");
	                var imgSrc = null;
	                if( self.preWidget.getChild(0).color.a == 242 )
	                {
	                    imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev_f.png';
	                }
	                else
	                {
	                    imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_prev.png';
	                }
	                self.preBtn.setIconImage({state: "focused", src: imgSrc});
			    }
				
			    //self.ContrlFocusInHighContrast(self.preWidget, self.preBtn, btn.id);
			    
			    if (Vconf.getValue('db/menu/system/accessibility/highcontrast'))
			    {
			        self.updateAnother4ButtonState(btn.id);//added later
			    }
*/			    
			}	
		}
        else if(btn.id == 'next_btn')
		{
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onFocus---DMR next_btn--setDimIconForRepeat');
				//self.setDimIconForRepeat();			
			}
			else
			{
				/*
				//self.nextWidget.getChild(0).color.a = 242;
			    self.nextBtn.setIconImage({state: "all", src: self.focusIcon[btn.id],});
			    self.nextBtn.setIconAlpha({state: "all", alpha: 255,});
			    //Volt.log("-----------licm-------------next btn in musicplayer-control-view.js before high contrast-------");
				*/
				self.nextBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/common/4way_focus.png'});
				self.nextBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/common/4way_focus.png'});
		/*
				if (Vconf.getValue('db/menu/system/accessibility/highcontrast'))
			    {
	                //Volt.log("-----------licm-------------next btn in musicplayer-control-view.js-------");
	                var imgSrc = null;
	                if( self.nextWidget.getChild(0).color.a == 242 )
	                {
		                imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next_f.png';
	                }
	                else
	                {
	                    imgSrc = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_next.png';
	                }
	                
	                self.nextBtn.setIconImage({state: "focused", src: imgSrc});
			    } 
			*/	
			    
			    //self.ContrlFocusInHighContrast(self.nextWidget, self.nextBtn, 'next_btn');
			}
		}
		else if( btn.id == 'pause_btn')
		{
		    //self.pauseWidget.getChild(0).color.a = 242;
		    self.FlagForSpeakerScreenPreNext = false;
		    //self.ContrlFocusInHighContrast(self.pauseWidget, self.pauseBtn, btn.id);
		    self.updatePlayState();
		    //self.pauseBtn.setIconAlpha({state: "all", alpha: 255,});
		    self.pauseBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/common/4way_focus.png'});
			self.pauseBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/common/4way_focus.png'});
		    
		}
		else if( btn.id == 'repeat_btn')
		{
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onFocus---DMR shuffle_btn--setDimIconForRepeat');
				//self.setDimIconForRepeat();			
			}
			else
			{
			    //self.repeatWidget.getChild(0).color.a = 242;
			    self.FlagForSpeakerScreenPreNext =false;
			    //self.ContrlFocusInHighContrast(self.repeatWidget, self.repeatBtn, 'repeat_btn');
			    self.updateRepeatIcon(self.playIns.getRepeatMode());
			    //self.repeatBtn.setIconAlpha({state: "all", alpha: 255,});
			    self.repeatBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/common/4way_focus.png'});
				self.repeatBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/common/4way_focus.png'});
			}
		    
		}
		else if( btn.id == 'shuffle_btn')
		{
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onFocus---DMR shuffle_btn--setDimIconForShuffle');
				//self.setDimIconForShuffle();			
			}
			else
			{
				//self.shuffleWidget.getChild(0).color.a = 242;
				//self.updateShuffleIcon(self.playIns.getShuffleMode());
				//self.shuffleBtn.setIconAlpha({state: "all", alpha: 255,});
		       //self.shuffleWidget.getChild(0).color.a = 242;
                self.FlagForSpeakerScreenPreNext =false;
                //self.ContrlFocusInHighContrast(self.shuffleWidget, self.shuffleBtn, 'shuffle_btn');
                self.updateShuffleIcon(self.playIns.getShuffleMode());
                //self.shuffleBtn.setIconAlpha({state: "all", alpha: 255,});	
                self.shuffleBtn.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/common/4way_focus.png'});
				self.shuffleBtn.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/common/4way_focus.png'});
			
			}

		}
		
		Volt.log('[musicplayer-control-view.js]-- onFocus--RunTimeInfo.bFlagForDMRandSearchCaseBallon is ' + RunTimeInfo.bFlagForDMRandSearchCaseBallon);
		if (RunTimeInfo.bFlagForDMRandSearchCaseBallon)
		{
			
			RunTimeInfo.bFlagForDMRandSearchCaseBallon = false;
		}
		else
		{
			self.showBalloon(btn); 
		}
        
    },
                /**the callback for the button on blur
                * @name onBlur              
                * @memberOf MusicPlayerCtrlView      
                * @param {btn} which button has been blured  
                * @method         */          
    ContrlFocusInHighContrast: function(Parentwidget, Currentbtn, buttonId)
	{
	    Volt.log("--musicplayer-control-view.js-----ContrlFocusInHighContrast----1  Currentbtn is " + Currentbtn);
	    if (Vconf.getValue('db/menu/system/accessibility/highcontrast'))
	    {                     
	          Currentbtn.setBorder({
	            state : 'focused',
	            border : {
	                width : 2,
	                color : Volt.hexToRgb('#ffffff', 80),
	            }
	        });
	    }
	    else
	    {
	          Parentwidget.getChild(0).color.a = 242;
	    }    
	},
                

	/**the callback for the button on blur
	* @name onBlur	 
	* @memberOf MusicPlayerCtrlView	 
	* @param {btn} which button has been blured	
	* @method 	 */	
	onBlur: function( btn ) {
	Volt.log('[musicplayer-control-view.js]-----onBlur----btnid is ' + btn.id);
		if( btn == null || btn == undefined || self.destroyFlag == true ){
			return;
		}
		Log.f("[musicplayer-control-view.js]---- onBlur----" + btn.id);
		print("[musicplayer-control-view.js]---- onBlur----" + btn.id);
		
		if(btn.id == 'speaker_btn'){
			self.speakerWidget.getChild(0).color.a = 0;
			self.speakerBtn.setIconImage({state: "all", src: self.blurIcon[btn.id],});
			self.speakerBtn.setIconAlpha({state: "all", alpha: 204,});
		}
		else if(btn.id == 'screen_btn'){
			self.screenWidget.getChild(0).color.a = 0;
			self.screenBtn.setIconImage({state: "all", src: self.blurIcon[btn.id],});
			self.screenBtn.setIconAlpha({state: "all", alpha: 204,});
		}		
		else if(btn.id == 'pre_btn'){
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onBlur---DMR or search pre_btn');
			}
			else
			{
				self.preWidget.getChild(0).color.a = 0;
				self.preBtn.setIconImage({state: "all", src: self.blurIcon[btn.id],});
				self.preBtn.setIconAlpha({state: "all", alpha: 204,});
			}
		}
		else if(btn.id == 'next_btn'){
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onBlur---DMR or search next_btn');
			}
			else
			{
				self.nextWidget.getChild(0).color.a = 0;
				self.nextBtn.setIconImage({state: "all", src: self.blurIcon[btn.id],});
				self.nextBtn.setIconAlpha({state: "all", alpha: 204,});			
			}
		}		
		else if( btn.id == 'pause_btn'){
			self.pauseWidget.getChild(0).color.a = 0;
			self.updatePlayState();
			self.pauseBtn.setIconAlpha({state: "all", alpha: 204,});
		}
		else if( btn.id == 'repeat_btn'){
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onBlur---DMR or search repeat_btn');
			}
			else
			{
				self.repeatWidget.getChild(0).color.a = 0;
				self.updateRepeatIcon(self.playIns.getRepeatMode());
				self.repeatBtn.setIconAlpha({state: "all", alpha: 204,});			
			}		
		}	
		else if( btn.id == 'shuffle_btn')
		{
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplayer-list-view.js]---onBlur---DMR or search shuffle_btn');
			}
			else
			{
				self.shuffleWidget.getChild(0).color.a = 0;
				self.updateShuffleIcon(self.playIns.getShuffleMode());
				self.shuffleBtn.setIconAlpha({state: "all", alpha: 204,});			
			}
		
		}			

    	if( self.balloon != null ){
    		self.balloon.destroy();
    		self.balloon = null;
    	}		
    },

	/**show the balloon tip for button
	* @name showBalloon	 
	* @memberOf MusicPlayerView	 
	* @param {wgt} show balloon for which button	
	* @method 	 */		
    showBalloon: function(wgt) {
    	Volt.log('[musicplayer-control-view.js]---showBalloon---wgt.id ' + wgt.id);
    	if( self.balloon != null ){
    		self.balloon.destroy();
    		self.balloon = null;
    	}

		var parentWgt = null;
    	var txt = '';
    	if( wgt.id == 'speaker_btn' ){
    		//txt = 'Select Speakers';
    		txt = resMgr.getText('TV_SID_SPEAKER_LIST');
			parentWgt = self.speakerWidget;
    		
    	}
		else if( wgt.id == 'screen_btn' ){
			//txt = 'Screen Off';
			txt = resMgr.getText('COM_SID_PICTURE_OFF');
			parentWgt = self.screenWidget;
		}
    	else if( wgt.id == 'pre_btn' ){
    		if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplay-control-view.js]----showBallon--shuffle_btn-dmr');
			}
			else
			{	
    		//txt = 'Previous';
    		txt = resMgr.getText('COM_SID_PREVIOUS');
			parentWgt = self.preWidget;
			}
    	}
    	else if( wgt.id == 'pause_btn' ){
			//add by uniplayr state
			if( self.playIns.isPlaying == true ){
				Log.f("self.playIns.getState()=" + self.playIns.getState());
				if( self.playIns.getState() != 3 )
				{
					//txt = 'Play';
					txt = resMgr.getText('COM_SID_PLAY');
				}
				else{
					//txt = 'Pause';
					txt = resMgr.getText('COM_SID_PAUSE');
				}
			}
			else
			{
				//txt = 'Pause';
				txt = resMgr.getText('COM_SID_PAUSE');
			}
			parentWgt = self.pauseWidget;
    	}  
    	else if( wgt.id == 'next_btn' ){
    		//txt = 'Next';
    		if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplay-control-view.js]----showBallon--shuffle_btn-dmr');
			}
			else
			{
	    		txt = resMgr.getText('COM_SID_NEXT');
				parentWgt = self.nextWidget;			
			}

    	}
    	else if( wgt.id == 'shuffle_btn' )
		{
				//txt = 'Shuffle';
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplay-control-view.js]----showBallon--shuffle_btn-dmr');
			}
			else
			{
		    	txt = resMgr.getText('SID_SHUFFLE');
				parentWgt = self.shuffleWidget;				
			}
    	}    
    	else if( wgt.id == 'repeat_btn' )
		{
			if (launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR && launchParams.isLaunchForMusicPlayer())
			{
				Volt.log('[musicplay-control-view.js]----showBallon--repeat_btn-dmr or search');
			}
			else
			{
	    			//txt = 'Repeat';
		    	txt = resMgr.getText('COM_SID_REPEAT');
				parentWgt = self.repeatWidget;		
			}
			
    	} 
		if(self.firstEnter == true && wgt.id == 'pause_btn'){
			Log.f("[musicplayer-control-view.js]---showBalloon--First enter music player~~~~~~~~~~~~~");
			Volt.log("[musicplayer-control-view.js]---showBalloon--First enter music player~~~~~~~~~~~~~");
			var playInstance = playerController;	
		
			var itemData = playInstance.getItemData(playInstance.getCurrentIdx(), false);
			var musicTitle = itemData.title;
			
			var voiceGuideTxt = String(musicTitle) + ', ' + txt+ ', ' + resMgr.getText('TV_SID_BUTTON');
	    	voiceGuide.play(voiceGuideTxt);   
			self.firstEnter = false;
		}
		else if(wgt.id == 'shuffle_btn')
		{			
			var voiceTxt = '';
			if( self.playIns.getShuffleMode()=="true" )
			{
	 
				voiceTxt = resMgr.getText('COM_SID_SUFFLE_ON');
	    	}
	    	else
			{
	    	
				voiceTxt = resMgr.getText('COM_SID_SUFFLE_OFF');
	    	}

			voiceGuide.play(voiceTxt); 
 
		}
		else if ( wgt.id == 'repeat_btn' )
		{
			var voiceTxt = '';
	
			if( self.playIns.getRepeatMode()=="one" ){
				
				voiceTxt = resMgr.getText('COM_SID_REPEAT_ONE');
			}
			else if( self.playIns.getRepeatMode()=="all" ){
				voiceTxt = resMgr.getText('COM_SID_REPEAT_ALL');
			}
			else{
				
				voiceTxt = resMgr.getText('TV_SID_REPEAT_OFF');
			}
			voiceGuide.play(voiceTxt);
		}
		else
		{
			voiceGuide.play(txt+ ', '+resMgr.getText('TV_SID_BUTTON')); 
		}
		if (parentWgt != null)
		{
			var tempX = parentWgt.x;
			var tempY = parentWgt.y + self.widget.y + 7;
			var tempFontsize = 30;
			var tempFont = '30px';
			
	    	var opt = {
	    		text: txt,
	    		x: tempX,
	    		y: tempY,
				wdgHeight: parentWgt.height,
				wdgWidth : parentWgt.width,
	    		fontsize: tempFontsize,
	    		font: tempFont,
	    		tailType: 'up',
	    	};
	    	self.balloon = new BalloonTips();
	    	self.balloon.show(opt);		
		}
		else
		{
			Volt.log('[musicplayer-control.view.js]---showBalloon---the parent is null');
		}

    },	

	/**select speaker button callback
	* @name speakerSelectCB	 
	* @memberOf MusicPlayerView	 
	* @method 	 */	
    speakerSelectCB: function(){
    	AppLauncher.launch('org.tizen.volume-setting', {key1 : 'value1'});
    },

	/**play pre button callback
	* @name pbPlayPre	 
	* @memberOf MusicPlayerView	 
	* @method 	 */	
    pbPlayPre: function(){ 	
    	Volt.log('[musicplayer-control-view.js]---pbPlayPre-');
		if( self.playIns!=null){
			var currTime = self.playIns.currTime;
			Log.f("current time is " + currTime );
			if( currTime < 3000 ){
				self.playIns.playPre();
			}
			else{
				self.playIns.play(0);
			}
		}	
    },

	/**play pause button callback
	* @name pbPlayPause	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
    pbPlayPause: function( key ){
    	Volt.log('[musicplayer-control-view.js]---pbPlayPause---key is ' + key + ' self.playIns.getState() is ' + self.playIns.getState());
    	if( self.pauseBtn != null && self.playIns != null ){
    		if(self.playIns.getState()==3 &&( key==undefined || key=='pauseKey')){		//playing
	    		try
				{
					self.playIns.pause(null);
				}
				catch(e)
				{
					Log.e('[musicplayer-control-view.js]----pbPlayPause---');
					Volt.log('[musicplayer-control-view.js]----pbPlayPause---');
					self.playIns.pause('appPause');	
				}
    		}		
    		else if(self.playIns.getState()==4 || self.playIns.getState()==2 &&( key==undefined || key=='playKey')){	//pause
    			//self.playIns.resume();   
				try
				{	
					Volt.log('--------------------------]');
					self.playIns.resume(null);
					Volt.log('[------------------------');
				}
				catch(e)
				{
					Log.e('[musicplayer-control-view.js]----pbPlayPause---');
					Volt.log('[musicplayer-control-view.js]----pbPlayPause---');
					self.playIns.resume('appResume');	
				}								
    		}
    	}    	
    },

	/**play next button callback
	* @name pbPlayNext	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
    pbPlayNext: function(){
    	Volt.log('[musicplayer-control-view.js]---pbPlayNext---');
		if( self.playIns!=null){
			if ( self.playIns.playNext(true)==false ){
				   Volt.log('[musicplayer-control-view.js]---pbPlayNext--self.playIns.playNext(true)== false--');
			}
		}
    },

	/**shuffle button callback
	* @name pbShuffle	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
    pbShuffle: function(){
    	Log.f("self.playIns.getShuffleMode() = " + self.playIns.getShuffleMode());
		Volt.log('[musicplayer-control-view.js]---pbShuffle---self.playIns.getShuffleMode() = '+ self.playIns.getShuffleMode());
		var voiceTxt = '';
		if( self.playIns.getShuffleMode()=="true" ){
    		self.playIns.setShuffleMode("false");
			voiceTxt = resMgr.getText('COM_SID_SUFFLE_OFF');
    	}
    	else{
    		self.playIns.setShuffleMode("true");
			voiceTxt = resMgr.getText('COM_SID_SUFFLE_ON');
    	}
      	self.updateShuffleIcon(self.playIns.getShuffleMode());
		voiceGuide.play(voiceTxt);
    },
    
    getShuffleIcon: function(mode){
		Volt.log('[musicplayer-control-view.js]---getShuffleIcon---mode = '+ mode);
    
    	var imgSrc = "";
    	if( mode === "true"){
    		imgSrc = self.picShuffle[0];
    	}
    	else{
    		imgSrc = self.picShuffle[1]
    	}
    	if( self.shuffleWidget!= null && self.shuffleWidget.getChild(0)!= null ){
			if( self.shuffleWidget.getChild(0).color.a == 242 ){
		    	if( mode === "true"){
		    		imgSrc = self.picShuffle[2];
		    	}
		    	else{
		    		imgSrc = self.picShuffle[3]
		    	}
			}    		
    	}
		return imgSrc;  	
    },

	updateShuffleIcon: function( mode ){
    	if( self.shuffleBtn != null ){
			var imgSrc = self.getShuffleIcon(mode);
			self._updateBtnIcon( self.shuffleBtn, imgSrc );
    	} 
    },

	/**repeat button callback
	* @name pbRepeat	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
    pbRepeat: function(){
    	Log.f("self.playIns.getRepeatMode() = " + self.playIns.getRepeatMode());
		Volt.log("[musicplayer-control-view.js]---pbRepeat--self.playIns.getRepeatMode() = " + self.playIns.getRepeatMode());
		var voiceTxt = '';
    	if( self.playIns.getRepeatMode()=="one" ){
    		self.playIns.setRepeatMode("all");
			voiceTxt = resMgr.getText('COM_SID_REPEAT_ALL');
    	}
    	else if( self.playIns.getRepeatMode()=="all" ){
    		self.playIns.setRepeatMode("off");
			voiceTxt = resMgr.getText('TV_SID_REPEAT_OFF');
    	}
    	else{
    		self.playIns.setRepeatMode("one");
			voiceTxt = resMgr.getText('COM_SID_REPEAT_ONE');
    	}
		self.updateRepeatIcon(self.playIns.getRepeatMode());
		voiceGuide.play(voiceTxt);
    },
    
    getRepeatIcon: function( mode ){
		Volt.log("[musicplayer-control-view.js]---getRepeatIcon--mode = " + mode);
    
    	var imgSrc = "";
		if( mode == "all"){
			imgSrc = self.picRepeat[0];
		}
		else if( mode == "off"){
			imgSrc = self.picRepeat[1];
		}
		else{
			imgSrc = self.picRepeat[2];
		}
		if( self.repeatWidget != null && self.repeatWidget.getChild(0)!= null ){
			if( self.repeatWidget.getChild(0).color.a == 242 ){
				if( mode == "all"){
					imgSrc = self.picRepeat[3];
				}
				else if( mode == "off"){
					imgSrc = self.picRepeat[4];
				}
				else{
					imgSrc = self.picRepeat[5];
				}
			}
		}
		return imgSrc;	
    },

	setDimIconForRepeat: function()
	{
		var mode = self.playIns.getRepeatMode();
		var imgSrc = null;
		if( self.repeatWidget != null && self.repeatWidget.getChild(0)!= null )
		{
			//if( self.repeatWidget.getChild(0).color.a == 242 ){

				imgSrc = self.picRepeat[4];


		}	
		self.playIns.setRepeatMode("off");
		self._updateBtnIcon( self.repeatBtn, imgSrc );		
	},

	setDimIconForShuffle: function()
	{
    
		Volt.log('[musicplayer-control-view.js]---getShuffleIcon---mode = '+ mode);
    	var mode = self.playIns.getShuffleMode();
    	var imgSrc = "";

    	if( self.shuffleWidget!= null && self.shuffleWidget.getChild(0)!= null )
		{

	    		imgSrc = self.picShuffle[3]		
    	}
		self.playIns.setShuffleMode("false");
		
		self._updateBtnIcon( self.shuffleBtn, imgSrc );
	
	},
    	
	updateRepeatIcon: function( mode ){
		Volt.log("[musicplayer-control-view.js]---updateRepeatIcon--mode = " + mode);	
    	if( self.repeatBtn != null ){
			var imgSrc = self.getRepeatIcon(mode);
			self._updateBtnIcon( self.repeatBtn, imgSrc );			
    	}
    },

	setDimIconForBtn:function(button)
    {
		Volt.log('[musicplayer-control-view.js]-----setDimIconForBtn---button.id is ' + button.id);
		var imgSrc = null;
    	if (button == self.preBtn)
    	{
    		if ( self.preWidget!= null && self.preWidget.getChild(0)!= null )
    		{
    				imgSrc = self.picPre[3];
    		}
			self.preBtn.setIconImage({state: "all", src: imgSrc});
			//self._updateBtnIcon( pre_btn, imgSrc );
    	}
		else if (button == self.nextBtn)
		{
    		if ( self.nextWidget!= null && self.nextWidget.getChild(0)!= null )
    		{
    				imgSrc = self.picNext[3];
    		}	
			//self._updateBtnIcon( next_btn, imgSrc );
			self.nextBtn.setIconImage({state: "all", src: imgSrc});
		}		
    },

    

	/**the callback for update the button's icon
	* @name _updateBtnIcon
	* @memberOf MusicPlayerCtrlView	 
	* @param {btn} which button to update icon
	* @param {image} the icon's image
	* @method 	 */	
	_updateBtnIcon : function( btn, image ) {
		Volt.log("[musicplayer-control-view.js]---_updateBtnIcon--btn.id is " + btn.id + " image is " + image);	
		if( btn == null || btn == undefined ){
			return;
		}
		else{
			if(btn.id == 'pause_btn'){
				self.pauseBtn.setIconImage({state: "all", src: image,});
			}
			else if(btn.id == 'repeat_btn'){
				self.repeatBtn.setIconImage({state: "all", src: image,});
			}
			else if(btn.id == 'shuffle_btn'){
				self.shuffleBtn.setIconImage({state: "all", src: image,});
			}
            else if (btn.id == 'pre_btn')
            {
                self.preBtn.setIconImage({state: "all", src: image});
            }
			//var iconWgt = btn.getChild(1);
			//if( iconWgt != null ){
				//iconWgt.src = image;
			//}
		}
	},

	updatePlayState : function(){
		var currState = self.playIns.getState();
		Log.f("[musicplayer-control-view.js]----updatePlayState----current state is " + currState);
		print('[musicplayer-control-view.js]----updatePlayState----current state is ' + currState);

		switch( currState ){
			case 3:
				var imgSrc = self.picPlay[0];
				/*
				if( self.pauseWidget.getChild(0).color.a == 242 ){
					imgSrc = self.picPlay[2];
					Volt.log('[musicplayer-control-view.js]---updatePlayState--self.picPlay2-');
				}	
				*/
				Volt.log('[musicplayer-control-view.js]---updatePlayState---imgSrc is ' + imgSrc);
				self._updateBtnIcon( self.pauseBtn, imgSrc );	

				break;
			case 4:
				var imgSrc = self.picPlay[1];
				/*
				if( self.pauseWidget.getChild(0).color.a == 242 ){
					imgSrc = self.picPlay[3];
				}
				*/
				Volt.log('[musicplayer-control-view.js]---updatePlayState---imgSrc is ' + imgSrc);
				self._updateBtnIcon( self.pauseBtn, imgSrc );	
				
				break;
			default:
				break;
		}
    },


	updatePlayunSupportedSong: function()
    {
    	var currState = self.playIns.getState();
    	if (currState == 3)
    	{
			var imgSrc = self.picPlay[0];
			if( self.pauseWidget.getChild(0).color.a == 242 ){
				imgSrc = self.picPlay[2];
			}	
			self._updateBtnIcon( self.pauseBtn, imgSrc );	    	
    	}
		else if (currState == 4)
		{
			var imgSrc = self.picPlay[1];
			if( self.pauseWidget.getChild(0).color.a == 242 ){
				imgSrc = self.picPlay[3];
			}
			self._updateBtnIcon( self.pauseBtn, imgSrc );			
		}
		else // default status---playing status
		{
			var imgSrc = self.picPlay[1];
			if( self.pauseWidget.getChild(0).color.a == 242 ){
				imgSrc = self.picPlay[3];
			}
			self._updateBtnIcon( self.pauseBtn, imgSrc );		
		}
    },

    updateAnother4ButtonState : function(buttonid)
	{
	    var currState = self.playIns.getState();
	    Log.f("[musicplayer-control-view.js]current state is " + currState + " buttonid is " + buttonid);
		Volt.log("[musicplayer-control-view.js]current state is " + currState + " buttonid is " + buttonid);
		
	    switch( currState )
		{
		    case 3:
		        if (buttonid == 'pre_btn')
		        {
					var imgSrc = self.picPre[0];
					if( self.preWidget.getChild(0).color.a == 242 )
					{
					    imgSrc = self.picPre[2];
					}              
					//self._updateBtnIcon( self.preBtn, imgSrc );
					self.preBtn.setIconImage({state: "all", src: imgSrc});                                                                        
		        }
		        else if (buttonid == 'next_btn')
		        {
					var imgSrc = self.picNext[0];
					if( self.nextWidget.getChild(0).color.a == 242 ){
		                imgSrc = self.picNext[2];
					}              
					//self._updateBtnIcon( self.nextBtn, imgSrc );
					self.nextBtn.setIconImage({state: "all", src: imgSrc});                                                                                     
		        }
		        else if (buttonid == 'screen_btn')
		        {
                    var imgSrc = self.picScreen[0];
                    if( self.screenWidget.getChild(0).color.a == 242 ){
                        imgSrc = self.picScreen[2];
                    }              
                    //self._updateBtnIcon( self.screenBtn, imgSrc );
                    self.screenBtn.setIconImage({state: "all", src: imgSrc});                                                                                 
		        }
		        else if (buttonid == 'speaker_btn')
		        {
                    var imgSrc = self.picSpeaker[0];
                    if( self.speakerWidget.getChild(0).color.a == 242 ){
                        imgSrc = self.picSpeaker[2];
                    }              
                    //self._updateBtnIcon( self.speakerBtn, imgSrc );            
                    self.speakerBtn.setIconImage({state: "all", src: imgSrc});                                                              
		        }
		        break;
		    case 4:
		        if (buttonid == 'pre_btn')
		        {
                    var imgSrc = self.picPre[1];
                    if( self.preWidget.getChild(0).color.a == 242 ){
                        imgSrc = self.picPre[3];
                    }
                    //self._updateBtnIcon( self.preBtn, imgSrc );
                    self.preBtn.setIconImage({state: "all", src: imgSrc});
		        }
		        else if (buttonid == 'next_btn')
		        {
                    var imgSrc = self.picNext[1];
                    if( self.nextWidget.getChild(0).color.a == 242 ){
                            imgSrc = self.picNext[3];
                    }              
                    //self._updateBtnIcon( self.nextBtn, imgSrc );
                    self.nextBtn.setIconImage({state: "all", src: imgSrc});                                                                     
		        }
		        else if (buttonid == 'screen_btn')
		        {
                    var imgSrc = self.picScreen[1];
                    if( self.screenWidget.getChild(0).color.a == 242 ){
                        imgSrc = self.picScreen[3];
                    }              
                    //self._updateBtnIcon( self.screenBtn, imgSrc );
                    self.screenBtn.setIconImage({state: "all", src: imgSrc});                                                                 
		        }
		        else if (buttonid == 'speaker_btn')
		        {
                    var imgSrc = self.picSpeaker[1];
                    if( self.speakerWidget.getChild(0).color.a == 242 ){
                        imgSrc = self.picSpeaker[3];
                    }              
                    //self._updateBtnIcon( self.speakerBtn, imgSrc );            
                    self.speakerBtn.setIconImage({state: "all", src: imgSrc});                                                              
		        }
		        break;
		    default:
		       	break;
		}
	},
});		

exports = MusicPlayerCtrlView;
