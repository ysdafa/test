 /** 
 * @author  He Wenge (wenge.he@samsung.com)
 * 			
 * @fileoverview  MyContent record view 
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var resMgr = Volt.require('app/controller/resource-controller.js');
	var BaseModel = Volt.require("app/models/base-model.js");
	var ContentViewBase = Volt.require("app/views/content-view-base.js");
	var CommonInfo = Volt.require("app/common/define.js");
	var EItemType = CommonInfo.EItemType;
	var EViewType = CommonInfo.EViewType;
	var MyContentOptionType = CommonInfo.MyContentOptionType;
	var OptionText = Volt.require("app/common/option-text.js");
	var VideoFilterTextList = OptionText.VideoFilterTextList;
	var RecordSortByTextList = OptionText.RecordSortByTextList;
	var RecordContentViewTemplate = Volt.require('app/templates/1080/record-view-template.js');
	var RunTimeInfo = Volt.require("app/common/run-time-info.js");
	var PanelCommon = Volt.require('lib/panel-common.js');
	var loadTemplate = PanelCommon.loadTemplate;
	var ViewGlobalData = Volt.require("app/views/view-global-data.js");
	var DeviceProvider = Volt.require("app/models/device-provider.js");
	var EventMediator = RunTimeInfo.EventMediator;
	var EventType = CommonInfo.EventType;
	var nativeGridlistFocus = CommonInfo.nativeGridlistFocus;
	var CONST = CommonInfo.CONST;
	var DeviceType = CommonInfo.DeviceType;
	var Render_View = Volt.require("app/views/render-view.js");
	var Thumbnail_View = Volt.require("app/views/thumbnail-view.js");
	var CategoryName = CommonInfo.CategoryName;
	var SortType = CommonInfo.SortType;
	
	var self = null;

	var RecordContentView = ContentViewBase.extend({
		listItemNum : 18,
		arrItems : [],
		template: RecordContentViewTemplate.container,
		templateList:RecordContentViewTemplate.list,
		focusWidget: null,
		params: {},
		events: {
	        'NAV_FOCUS':'onFocus',
	        'NAV_BLUR':'onBlur'
	    },
		/** Render
		* @name render	 
		* @memberOf RecordContentView
		* @method 	 
		* */	
		render : function(){
			self = this;	
			return this;
		},

		/** OnFocus
		* @name onFocus	 
		* @memberOf RecordContentView
		* @param {widget} current get focus widget
		* @method 	 
		* */	
		onFocus: function(widget) {
			print('record-condent-view.js onFocus');
			Log.e("record-content-view.js onFocus");
			if(this.nativeGridList != null){
				EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
				this.nativeGridList.enableFocus();
				//this.nativeGridList.setFocus();
				this.nativeGridList.showFocus('false');
				this.nativeGridList.setFocusImage(resMgr.getImgPath()+'/common/ksc_focus.png', -8, -8);

				this.nativeGridList.showFocus("true");
				ViewGlobalData.isGridListFocus = true;
			}
	    },

		/** OnBlur
		* @name onBlur	 
		* @memberOf RecordContentView
		* @param {widget} current lose focus widget
		* @method 	 
		* */	
	    onBlur: function(widget) {
	    	print('record-condent-view.js onBlur');
			Log.e("record-content-view.js onBlur");
	        if( this.nativeGridList != null ){
				this.nativeGridList.hideFocus("true");
				ViewGlobalData.isGridListFocus = false;
	        }
	    },
		/** Make Data Source
		* @name makeDataSource	 
		* @memberOf RecordContentView
		* @param {devPath} scan path
		* @method 	 
		* */	
		makeDataSource : function(devPath){
	   		for(var index=0; index<RecordSortByTextList.DeviceTypeTextList.length; index++){
				if(resMgr.getText(RecordSortByTextList.DeviceTypeTextList[index]) == ViewGlobalData.viewSortText[EViewType.eRecordContentView]){
				  RunTimeInfo.router.mainView.headerView.optionParam.secondSelectedIndex[1] = index;
				}
			}
			
			if(ViewGlobalData.parentFielPathStack.length != 0){
		        devPath = ViewGlobalData.currFilePath;
			}
			else{
				ViewGlobalData.rootPath = devPath;
			}
		    this.collection.setRootGroup(ViewGlobalData.isRootGroup);
			this.collection.setGroupIndex(ViewGlobalData.GroupIndex);
			//var sortType = ViewGlobalData.viewSortText[EViewType.eRecordContentView];
			var sortType = this.mainView.headerView.filterView.currentViewSortText;
			print("record setGlobalSort sortType:"+sortType);
			switch(sortType){
				case resMgr.getText(SortType.SORT_TYPE_TITLE):
					sortType = 'CATEGORY-TITLE';
					break;

				case resMgr.getText(SortType.SORT_TYPE_DATE):
					sortType = 'CATEGORY-DATE';
					break;

				case resMgr.getText(SortType.SORT_TYPE_CHANNEL):
					sortType = 'CATEGORY-CHANNEL_NAME';
					break;

				case resMgr.getText(SortType.SORT_TYPE_FOLDER):
					sortType = 'CATEGORY-FOLDER';
					break;
					 
				default:
					sortType = 'CATEGORY-TITLE';
					break;
			}
			print('makeDataSource devPath11');
			print('test csf emp');
			print("sortType"+sortType);
			var contentType = 'CONTENT-PVR';
			if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB)
			{
				this.requestUsbDataList(devPath, contentType, sortType);
			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_DLNA)
			{
				//this.requestDlnaDataList(contentType,sortType);
				EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);
				EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);

			}
			else if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_PTP){
				EventMediator.trigger(EventType.EVENT_TYPE_FAILE_REQUEST_DATA);
				EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
			}
		},


		/** Update Widget
		* @name updateWidget	 
		* @memberOf RecordContentView
		* @param {int} index
		* @param {Object} data item
		* @param {Object} parent widget
		* @method 	 
		* */
		updateWidget : function(index, item, widget){	
		    if(item.get('ItemType') == EItemType.eItemFolder ||
			   item.get('ItemType') == EItemType.eItemGroup){
			   
				if(widget.getChild(1)!= null){
					widget.getChild(1).getUIElement().setTextContent({text: item.get('title1'),textHorizontalAlignment:'center'});	
				}
			}
		    else{
				if((widget.getChild(2) != null) && (widget.getChild(2).getChild(0)!= null)){
					widget.getChild(2).getChild(0).getUIElement().setTextContent({text: item.get('title1')});
				}
		    }
		},

		/** Get Option Text
		* @name getOptionText	 
		* @memberOf AllContentView
		* @method 	 
		* */
     	getOptionText : function(){
		 print('getOptionText33');
		    /*this index is must refer the optionText array*/
            if(this.mainView.headerView.optionParam.secondSelectedIndex[0] == -1){
                var filterType = 'All';
			}
			else{
				var filterIndex = this.mainView.headerView.optionParam.secondSelectedIndex[0];
				var filterType = resMgr.getText(VideoFilterTextList.DeviceTypeTextList[filterIndex]);
			}
			if(this.mainView.headerView.optionParam.secondSelectedIndex[1] == -1){
				var sortType = 'Title';
			}
			else{
				var sortIndex = this.mainView.headerView.optionParam.secondSelectedIndex[1];
				var sortType = resMgr.getText(RecordSortByTextList.DeviceTypeTextList[sortIndex]);
			}

			var optionText = [];
			if(this.getCurrentDeviceType() === DeviceType.DEVICE_TYPE_USB){
				var id = self.mainView.categoryView.currentID;
				if( ViewGlobalData.parentFielPathStack.length != 0 && DeviceProvider.isUHDDevice(id) ){
					optionText = self.getUHDText();
				}
				else{
					if ( this.mainView.folderPathViewFlag == false ){
						optionText = [
					        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
				            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
					    ];
						var tempLen = optionText.length;
						if(self.mainView.getRecordSupportFlag() == 1){
							optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_DEL);
						}
						tempLen = optionText.length;
						optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY);
						if ( self.mainView.getCopySupportFlag() ){
							tempLen = optionText.length;
							optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_COPY);
						}
					}
					else{
						print('record-content-view.js1 optionMenuSubIndex[0]: ', this.mainView.popupView.optionMenuSubIndex[0])
						optionText = [
					        resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
				            resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
					    ];
						var tempLen = optionText.length;
						if(self.mainView.getRecordSupportFlag() == 1){
							optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_DEL);
						}
						tempLen = optionText.length;
						optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY);
						if ( self.mainView.getCopySupportFlag() ){
							tempLen = optionText.length;
							optionText[tempLen] = resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_COPY);
						}
					}

					self.isDimFirstPlus = [];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
						self.isShowSecPlus[index] = false;
					}
			
					if(this.mainView.getCopySupportFlag()){
						self.isDimFirstPlus[4] = true;
					}

					if(self.mainView.getRecordSupportFlag() == 1 && DeviceProvider.getUsbDeviceCount() <= 1){
						if(self.getRecordFileCount() == 0){
							self.isDimFirstPlus[2] = true;
							self.isDimRecord = true;
						}
						else{
							self.isDimRecord = false;
						}
					}
					else{
						self.isDimRecord = false;
					}
					/*please set the optionText need to show second popup*/
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = true;
					self.isShowSecPlus[2] = false;
					self.isShowSecPlus[3] = false;
					self.isShowSecPlus[4] = false;
					self.isShowSecPlus[5] = false;
				}
			}
			else{
				optionText = [];
				if(this.mainView.folderPathViewFlag){
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    //resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isShowSecPlus[0] = true;
					//self.isShowSecPlus[1] = false;
				}
				else{
					optionText = [
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_FILTER),
					    resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_SORT),
					    //resMgr.getText(MyContentOptionType.MYCONTENT_OPTION_TYPE_PLAY),
					];
					for (var index = 0; index < optionText.length; index++){
						self.isDimFirstPlus[index] = false;
					}
					self.isShowSecPlus[0] = true;
					self.isShowSecPlus[1] = true;
					//self.isShowSecPlus[2] = false;
					
				}

			}
			
			this.mainView.headerView.optionParam.firstOptionText = optionText;
			this.mainView.headerView.optionParam.firstHeight = 72*(optionText.length);


		},

		/** Get Sort By Text
		* @name getSortByText	 
		* @memberOf RecordContentView
		* @method 	 
		* */	
		getSortByText : function(){
		    var Text;
			/*the true text please refer the gui of content*/		
			
			Text = self.getResourceText(RecordSortByTextList.DeviceTypeTextList);
			if( this.mainView.headerView.filterView.optionMenuSubIndex[1] > (Text.length-1) ){
				this.mainView.headerView.filterView.optionMenuSubIndex[1] = Text.length-1;
			}
			return Text;
	    },

		/** Get Second Option Text
		* @name getSecondOptionText	 
		* @memberOf RecordContentView
		* @param {nListIndex} select option index
		* @method 	 
		* */	
		getSecondOptionText : function(nListIndex){
			var Text;
			print('getSecondOptionText'+nListIndex);
			switch(nListIndex){
				/*Filter*/
				case 0:
					Text = self.getFilterText();
					break;

				case 1:
					Text = self.getSortByText();
					break;

				default:
					break;
			}
			return Text;
		},

		getFilterOption: function(){
			//return 'Filter by Record';
			return resMgr.getText('COM_SID_FILTER_BY') + ' ' + resMgr.getText('COM_RECORDED_KR_CONTENT'); 
		},

		/** updateRender
		* @name updateRender 
		* @memberOf RecordContentView
		* @method 	 
		* */
		updateRender : function( data, renderer){
			print("record-content-base.js updateRender");
			if( data.ItemType == EItemType.eItemFolder || data.ItemType == EItemType.eItemGroup ){
				updateFolderItemThumbnail( data, renderer);
			}
		    else if( data.ItemType == EItemType.eItemUpFolder ){
				updateUpfolderItemThumbnail( data, renderer);
		    }
			else{
				updateFileItemThumbnail( data, renderer);
			}
			renderer.thumbnail.removeThumbnailListener(self.thumbListener);
			if(data.ItemType == EItemType.eItemPvr && data.isGuidance){
				renderer.thumbnail.addThumbnailListener(thumbListener);
			}
		},
		
	});

	/** Create List
	* @name t_CreateList	 
	* @memberOf RecordContentView
	* @method 	 
	* */
	RecordContentView.prototype.t_CreateList = function(){
		//folder coordinate
		self.params.renderWidth = RecordContentViewTemplate.listItemFolder[0].width;//220
		self.params.renderHeight = RecordContentViewTemplate.listItemFolder[0].height;//288
		self.params.textX = RecordContentViewTemplate.listItemFolder[1].x;//20
		self.params.textY = RecordContentViewTemplate.listItemFolder[1].y;//186
		self.params.textWidth = RecordContentViewTemplate.listItemFolder[1].width;//180
		self.params.textHeight = RecordContentViewTemplate.listItemFolder[1].height;//58
		self.params.folderX = RecordContentViewTemplate.listItemFolder[2].x;//37
		self.params.folderY = RecordContentViewTemplate.listItemFolder[2].y;//60
		self.params.folderWidth = RecordContentViewTemplate.listItemFolder[2].width;//146
		self.params.folderHeight = RecordContentViewTemplate.listItemFolder[2].height;//121
		//other coordinate
		self.params.imageWidth = RecordContentViewTemplate.listItemNoFolder[0].width;//324
		self.params.imageHeight = RecordContentViewTemplate.listItemNoFolder[0].height;//192

		self.params.infoHeight = RecordContentViewTemplate.listItemNoFolder[2].height;//96
		self.params.text1X = RecordContentViewTemplate.listItemNoFolder[2].children[0].x;//18
		self.params.text1Y = RecordContentViewTemplate.listItemNoFolder[2].children[0].y;//20
		self.params.text1Width = RecordContentViewTemplate.listItemNoFolder[2].children[0].width;//184
		self.params.text1Height = RecordContentViewTemplate.listItemNoFolder[2].children[0].height;//28
		self.params.text2X = RecordContentViewTemplate.listItemNoFolder[2].children[1].x;//18
		self.params.text2Y = RecordContentViewTemplate.listItemNoFolder[2].children[1].y;//35
		self.params.text2Width = RecordContentViewTemplate.listItemNoFolder[2].children[1].width;//184
		self.params.text2Height = RecordContentViewTemplate.listItemNoFolder[2].children[1].height;//28

		self.params.icon1X = RecordContentViewTemplate.listItemNoFolder[4].x;//67
		self.params.icon1Y = RecordContentViewTemplate.listItemNoFolder[4].y;//74
		self.params.icon1Width = RecordContentViewTemplate.listItemNoFolder[4].width;//86
		self.params.icon1Height = RecordContentViewTemplate.listItemNoFolder[4].height;//73
		
		self.params.icon2X = RecordContentViewTemplate.listItemNoFolder[1].x;//66
		self.params.icon2Y = RecordContentViewTemplate.listItemNoFolder[1].y;//66
		self.params.icon2Width = RecordContentViewTemplate.listItemNoFolder[1].width;//88
		self.params.icon2Height = RecordContentViewTemplate.listItemNoFolder[1].height;//88

		self.params.icon3X = RecordContentViewTemplate.listItemNoFolder[5].x;//66
		self.params.icon3Y = RecordContentViewTemplate.listItemNoFolder[5].y;//66
		self.params.icon3Width = RecordContentViewTemplate.listItemNoFolder[5].width;//88
		self.params.icon3Height = RecordContentViewTemplate.listItemNoFolder[5].height;//88

		self.params.icon4X = RecordContentViewTemplate.listItemNoFolder[6].x;//66
		self.params.icon4Y = RecordContentViewTemplate.listItemNoFolder[6].y;//66
		self.params.icon4Width = RecordContentViewTemplate.listItemNoFolder[6].width;//88
		self.params.icon4Height = RecordContentViewTemplate.listItemNoFolder[6].height;//88

		self.params.icon5X = RecordContentViewTemplate.listItemNoFolder[7].x;//66
		self.params.icon5Y = RecordContentViewTemplate.listItemNoFolder[7].y;//66
		self.params.icon5Width = RecordContentViewTemplate.listItemNoFolder[7].width;//88
		self.params.icon5Height = RecordContentViewTemplate.listItemNoFolder[7].height;//88
	
		self.loadNativeGridList();
		var rendererProvider = new RendererProvider;
		rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data)
		{
			return GetRenderer(parentWidth, parentHeight, data);
		};
		var gridListener = self.createGridListener();
	    var mustache = {
	        rendererProvider: rendererProvider,
			gridListener: gridListener,
	        columnWidth: 324,
	        rowHeight: 288,
	        renderNumber:18,
	        renderColumn:6,
	    };
		self.setGridListStyle(mustache);
		self.setGridListData(mustache);
		//EventMediator.trigger(EventType.EVENT_TYPE_UNDIM_SETTING);
	}

	/** Destroy List
	* @name t_DestroyList	 
	* @memberOf RecordContentView
	* @method 	 
	* */	
	RecordContentView.prototype.t_DestroyList = function(){
		if(self.focusWidget !== null){
			self.focusWidget.loseFocus();
		}
		self.collection.cancelAllThumbnailRequest();
		
		print('RecordContentView  Remove native grid control');
		if(self.nativeGridList != null){
			
			self.nativeGridList.custom.focusable = false;
			Volt.Nav.removeItem(self.nativeGridList);
			self.widget = null;
		}
	}

	/** GetRenderer
	* @name GetRenderer	 
	* @memberOf RecordContentView
	* @param {int} parentWidth
	* @param {int} parentHeight, 
	* @param {Object} data
	* @method 	 
	* */	
function GetRenderer(parentWidth, parentHeight, data)
{
	try {
		var renderer = new Thumbnail_View(parentWidth, parentHeight, self);
		
		renderer.createIndex = data.index;
		renderer.autoRelease = false;
		data.createFlag = true;
		if( data.index < self.collection.size() && self.collection.at(data.index).get('dataFlag')== 0){
			data.createFlag = false;
			data.dataFlag = false;
		}
		renderer.unique = null;
		
		renderer.textWidgetNumber = 2;
		renderer.template = RecordContentViewTemplate;
		renderer.checkBoxIndex = 4;
		
		if ( data.dummyFlag == false ){
			renderer.createChildofRecordView( renderer, data );
		}
		else{
			changeRenderInfo(data.index);
		}
	}catch(e){
		print('[GetRenderer]  e:', e);
	}
	print('[music-content-view.js] GetRenderer:',renderer);
	return renderer;
};

	function updateFolderItemThumbnail( data, renderer){
		var input = {
		    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
	        image: {
	            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
	            width: self.params.renderWidth,
	            height: self.params.renderHeight
	        },
	        information: {
		        x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,			            
	            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
	            text1: {
	            	text: data.title1,
	                font: 'SamsungSmart_Light 24px',
	                x: self.params.textX,
		            y: self.params.textY,
	                width: self.params.textWidth,
	                height: self.params.textHeight,
	                horizontalAlignment: 'center',
	                verticalAlignment: 'center',
	                singleLineMode: true,
					enlarge:{
                         factor: 1.5,
                         anchorPoint: 'center',
         			},
         			textColor: { r: 255, g: 255, b: 255, a: 153 },
	            },
	        },
			icon1: {
				x: self.params.folderX, 
				y: self.params.folderY, 
				width: self.params.folderWidth, 
				height: self.params.folderHeight,
				async: true,
				unpressSrc: self.folderNoamalImage,
				pressedSrc: self.folderNoamalImage,
				clickable: false,
				opacity: 128,
			}
		};
		renderer.thumbnail.setThumbnailStyle(input);
		if(RunTimeInfo.isEditMode == true){
			renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
			renderer.thumbnail.dim(true);
		}
		else{
			renderer.thumbnail.dim(false);
		}
		renderer.thumbnail.show();
			
	};
	
	function updateUpfolderItemThumbnail( data, renderer){
		var input = {
		    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
	        image: {
	            src: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_video_upper.PNG",
	            width: self.params.renderWidth,
	            height: self.params.renderHeight
	        },
	        information: {
		         x: 0,
		        y: 0,
		        width: self.params.renderWidth,
		        height: self.params.renderHeight,			            
	            colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
	            text1: {
	            	text: data.title1,
	                font: 'SamsungSmart_Light 24px',
	                x: self.params.textX,
		            y: self.params.textY,
		            width: self.params.textWidth,
		            height: self.params.textHeight,
	                horizontalAlignment: 'center',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                enlarge:{
                         factor: 1.5,
                         anchorPoint: 'center',
         			},
	            },
	        },
			icon1: {
				x: self.params.folderX, 
				y: self.params.folderY, 
				width: self.params.folderWidth, 
				height: self.params.folderHeight,
				async: true,
				unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
				pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
				clickable: false
			}
		};
		renderer.thumbnail.setThumbnailStyle(input);
		if(RunTimeInfo.isEditMode == true){
			renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
			renderer.thumbnail.dim(true);
		}
		else{
			renderer.thumbnail.dim(false);
		}
		renderer.thumbnail.show();
	};
	
	function updateFileItemThumbnail( data, renderer){
		if ( !data.title1 ){
			data.title1 = '';
		}
		if ( !data.title2 ){
			data.title2 = '';
		}

		data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
		if( data.ItemType == EItemType.eItemPvr ){
			if(data.isLocked){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_adult_n.png';
				self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );    
			}
			 
			 if(data.isAudioOnly){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_audio_n.PNG';
				self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );    
			}	      	           	
			if(self.collection.getItem(data.index).get('ciThumbType') > CIThumbType.E_THUMB_OK || self.collection.getItem(data.index).get('isDrm')){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_v.PNG';
				self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );
			}
            else if(data.isLocked || data.isAudioOnly){
               self.collection.getItem(data.index).set('ThumbPath', data.ThumbPath );                   
            }
            else if( data.isThumbDone){
                data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
            }         
            else{
                self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 324, 288);
            }
		}
		else{
			return renderer;
		}
		
		var infomationTextX = self.params.text1X;
		var infomationTextW = self.params.text1Width;
		var watchedIconSrc = '';
		var sportsIcoSrc = '';
		var unSupportSrc = '';
		var playIcoSrc = '';
		var dateText= '';
		var chanelName = '';
		

		if(data.ItemType == EItemType.eItemPvr){
		
			if(data.sportsType == 2){
				sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_soccer.png";
			}
			else if(data.sportsType == 3){				
				sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_rugby.png";
			}
			else if(data.sportsType == 4){
				sportsIcoSrc=Volt.BASE_PATH + resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_hockey.png";
			}
			if(data.isGuidance){
				infomationTextW -= 26;
			}
			if(data.isRecording){					
				unSupportSrc = Volt.BASE_PATH + resMgr.getImgPath()+ "/Contents_icon/recorded_rec_icon.png";
			}
			if(self.collection.getItem(data.index).get('ciThumbType') == CIThumbType.E_THUMB_INVALID || self.collection.getItem(data.index).get('isDrm')){
				playIcoSrc = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_notsupport_play.png';
			}
			
			dateText = self.collection.getItem(data.index).get('date');
			chanelName = self.collection.getItem(data.index).get('chanelName');
			
		}
		if (self.thumbnailColorFlag == false){
			self.thumbnailColorNumber = data.index%2;
			self.thumbnailColorFlag = true;
		}
		var tempIndex = data.index%2;
		var tempColorPickingOpacity = 255-240;
		if ( tempIndex == self.thumbnailColorNumber ){
			tempColorPickingOpacity = 255-225;
		}
		var input = {
		    visibleStyles: ( 0x01 | 0x20 | 0x02 ),
	        x: 0,
	        y: 0,
	        width: self.params.renderWidth,
	        height: self.params.renderHeight,
	        	coverColor: { r: 0, g: 0, b: 0, a: tempColorPickingOpacity },
	        image: {
	            src: data.ThumbPath,
	            width: self.params.imageWidth,
	            height: self.params.imageHeight
	        },
	        information: {
				x: 0, 
				y: self.params.imageHeight, 
				width: self.params.renderWidth, 
				height: self.params.infoHeight,
				colorPickingRange: {l:0, r: 100, t: 80, b: 100}, 
				enlarge:{
                         factor: 1.5,
                         anchorPoint: "bottom",
         		},
	            text1: {
	            	text: data.title1,
	                font: 'SamsungSmart_Light 24px',
					x: infomationTextX, 
					y: self.params.text1Y, 
					width: infomationTextW, 
					height: self.params.text1Height,
	                horizontalAlignment: 'left',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                extractColorOpacity: 153,
	            },
	            text2: {
	            	text: dateText,
	            	font: 'SamsungSmart_Light 21px',
	            	x: 18,
	            	y: 60,
	            	width: 135,
	            	height: 30,
	            	horizontalAlignment: 'left',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                extractColorOpacity: 153,
	            },
	            text3: {
	            	text: chanelName,
	            	font: 'SamsungSmart_Light 21px',
	            	x: 171,
	            	y: 60,
	            	width: 135,
	            	height: 30,
	            	horizontalAlignment: 'right',
	                verticalAlignment: 'center',
	                singleLineMode: true,
	                extractColorOpacity: 153,
	            }
	        },
			icon1: {
				x: self.params.icon1X, 
				y: self.params.icon1Y, 
				width: self.params.icon1Width, 
				height: self.params.icon1Height,
				async: true,
				unpressSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
				pressedSrc: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/check_ms_tb.png",
				opacity: 255*0.5,
				clickable: false
			},
			icon2: {
				x: 280,
				y: 241,
				width: 26,
				height: 25,
				async: true,
				unpressSrc: '',
				pressedSrc: '',
				clickable:false,
			},
		};
		renderer.iconNumber = 2;
		renderer.editNum = 1;	
		if ( sportsIcoSrc != '' ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
				x: 280 -35, 
				y: 10, 
				width: 32, 
				height: 32,
				async: true,
				unpressSrc: sportsIcoSrc,
				pressedSrc: sportsIcoSrc,
				clickable: false
				
			});
		}
		if ( unSupportSrc != '' ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
				x: 118,
				y: 52,
				width: 88,
				height: 88,
				async: true,
				unpressSrc: unSupportSrc,
				pressedSrc: unSupportSrc,
				clickable: false,
			});
		}
		if ( playIcoSrc != '' ){
			renderer.iconNumber++;
			setIconInfo(input, renderer.iconNumber, {
				x: 280, 
				y: 10, 
				width: 32, 
				height: 32,
				async: true,
				unpressSrc: playIcoSrc,
				pressedSrc: playIcoSrc,
				clickable: false
			});
		}
		renderer.thumbnail.setThumbnailStyle(input);
		var showCheck =  false;
		if( RunTimeInfo.isEditMode ){
			var dataIndex = data.index;
			if(self.collection.addUpperFolderItemFlag == true){
				dataIndex = dataIndex -1;
			}
			if ( RunTimeInfo.router.getCurrentView().getSelectState(dataIndex) ){
				if(data.isRecording || data.isLocked){
					var editModeView = mainView.editModeView;
					if(editModeView.optType == EOptType.eDeleteType){
						renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
						renderer.thumbnail.dim(true);
					}
					else{
						showCheck = true;
						renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
						renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
						dimIconInfo(renderer, renderer.editNum);
					}
				}
				else{
					showCheck = true;
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
					renderer.thumbnail.setDimBackgroundColor({r:0x21, g:0x9e, b:0xe6, a:255*0.6});
					dimIconInfo(renderer, renderer.editNum);
				}
			}
			else{
				if(data.isRecording || data.isLocked){
					var editModeView = mainView.editModeView;
					if(editModeView.optType == EOptType.eDeleteType){
						renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
						renderer.thumbnail.dim(true);
					}
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				}
				else{
					renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
				}
			}
		}
		else{
			renderer.thumbnail.visualizeAttachIcon(showCheck, "icon1");
			if(self.collection.getItem(data.index).get('isPlayAvailable')== false || self.collection.getItem(data.index).get('isDrm')){
				renderer.thumbnail.setDimBackgroundColor({r:0x00, g:0x00, b:0x00, a:255*0.65});
				dimIconInfo(renderer,renderer.iconNumber)
			}
			
		}
		if(data.ItemType == EItemType.eItemPvr && data.isGuidance){
			renderer.thumbnail.addThumbnailListener(self.thumbListener);
		}
		
		renderer.thumbnail.show();
	};

	function setIconInfo( input, iconNum, iconPa ){
		switch (iconNum) {
	        case 1:
				input.icon1 = iconPa;
	            break;
	        case 2:
				input.icon2 = iconPa;
				break;
	        case 3:
				input.icon3 = iconPa;
				break;
	        case 4:
				input.icon4 = iconPa;
			    break;
	        case 5:
				input.icon5 = iconPa;
	            break;
	        case 6:
				input.icon6 = iconPa;
				break;
	        case 7:
				input.icon7 = iconPa;
				break;
	        case 8:
				input.icon8 = iconPa;
			    break;
	        case 9:
				input.icon9 = iconPa;
				break;
	        case 10:
				input.icon10 = iconPa;
			    break;
	        default:
	            break;
	    }
	};

	function dimIconInfo( input, iconNum ){
		switch (iconNum) {
	        case 1:
				input.thumbnail.setElementOpacity("icon1", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon1");
				break;
	        case 2:
				input.thumbnail.setElementOpacity("icon2", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon2");
				break;
	        case 3:
				input.thumbnail.setElementOpacity("icon3", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon3");
				break;
	        case 4:
				input.thumbnail.setElementOpacity("icon4", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon4");
			    break;
	        case 5:
				input.thumbnail.setElementOpacity("icon5", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon5");
	            break;
	        case 6:
				input.thumbnail.setElementOpacity("icon6", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon6");
				break;
	        case 7:
				input.thumbnail.setElementOpacity("icon7", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon7");			
				break;
	        case 8:
				input.thumbnail.setElementOpacity("icon8", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon8");	
			    break;
	        case 9:
				input.thumbnail.setElementOpacity("icon9", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon9");	
				break;
	        case 10:
				input.thumbnail.setElementOpacity("icon10", 255);
				input.thumbnail.dim(true);
				input.thumbnail.raiseElement("icon10");	
			    break;
	        default:
	            break;
	    }
	};
	
function changeRenderInfo(index){
	self.nativeGridList.enableItem(0, index, false); 
};

function changeRenderImg(param){
	self.changeRenderImg(param);
}

exports = RecordContentView;
