 /** 
 * @author  Li Hailong (hailong08.li@samsung.com)
 * 			
 * @fileoverview  Enter sub-folder, folder path will be shown
 * @date    2014/08/05 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */


var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var CommonInfo = Volt.require('app/common/define.js');
var CONST = CommonInfo.CONST;
var EventType = CommonInfo.EventType;

var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
	
var FolderPathViewTemplate = Volt.require('app/templates/1080/folderpath-view-template.js');
var FolderPathList = Volt.require('lib/custom-widgets/folder-path-list.js');
var WinsetBackground = Volt.require("WinsetUIElement/winsetBackground.js");
//PanelCommon.mapWidget('FolderPathList', FolderPathList);
var mycontentWidth = RunTimeInfo.SceneResolution;
var UHD_CONTENT_FOLDER_NAME = 'UHD Content';

var self = null;
var FolderPathView = PanelCommon.BaseView.extend({
    template: FolderPathViewTemplate.folderpath,
    parentView : null,

    folderPathWidget : null,
    isDeleteAll:false,
    
    /** Render folder path view
	* @name render	 
	* @memberOf FolderPathView
	* @method 	 
	* */
    render: function() {
        print('[folder-path-view.js] render  loadTemplate');
        print('template', self.template);
	
		
		
	    var contentWidget = loadTemplate(self.template);
		
	    print('[folder-path-view.js] contentWidget', contentWidget);
	    print('[folder-path-view.js] contentWidget.height', contentWidget.height);
	    print('[folder-path-view.js] contentWidget.child count', contentWidget.getChildCount());
	    print('[folder-path-view.js] self', self);
        self.setWidget(contentWidget);
		
  		 var winsetWidget = new WinsetBackground({
	        parent : contentWidget,
	        x : 0,
	        y : 0,
	        width : mycontentWidth,
	        height : 72,
	        bgColor : Volt.hexToRgb('#192334'),
	        bgHighContrastColor : Volt.hexToRgb('#1a1a1a', 100),
	        style: 1, //HighContrast_Background :           1,
	    });
	    
		if(HALOUtil.highContrast == true){
	    //    winsetWidget.color = Volt.hexToRgb('#1a1a1a', 100);
	    }	
		
        self.folderPathWidget = new FolderPathList(winsetWidget);
     	contentWidget.addChild(self.folderPathWidget);
        print('[folder-path-view.js] contentWidget.child count', contentWidget.getChildCount());  

		if(RunTimeInfo.isEditMode == true){
			print('onAddFolderPath editmode is true!');
			self.widget.hide();
		}
        return this;
    },

	onKeyEvent:function(keycode, keytype){
		print('[folder-path-view.js] --- keycode:'+keycode+', keytype:'+keytype);
		return false;
  	},
  	
    /** Initialize FolderPathView
	* @name initialize	 
	* @memberOf FolderPathView
	* @param {parentView} parent
	* @method 	 
	* */
    initialize: function(parentView) {
        self = this;
	
        self.parentView = parentView;
    },
    
    /** Destroy FolderPathView
	* @name destroy	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
	destroy:function(){
		
	},
	
	/** Hide FolderPathView
	* @name hide	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
	hide : function(){
		self.widget.hide();
	},
	
	/** Show FolderPathView
	* @name show	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
	show : function(){
		self.widget.show();
	},
	
	/** Add folder to folder view 
	* @name addSubFolder	 
	* @memberOf FolderPathView	
	* @param {subfolder} folder name
	* @method 	 
	* */
	addSubFolder : function(subfolder){
	
		self.folderPathWidget.setPath(subfolder);
		self.isDeleteAll = false;
	},
	
	/** Delete top folder from folder view 
	* @name deleteSubFolder	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
	deleteSubFolder : function(){
	
		self.folderPathWidget.deletePath();
		//self.folderPathWidget.setPath(self.folderPathArray);
		
	},
	
	isUHDContentFolder : function(){
		if(self.folderPathWidget == null){
			print("isUHDContentFolder self.folderPathWidget == null return ");
			Log.e("isUHDContentFolder self.folderPathWidget == null return ");
			return false;
		}
		var topFolder = self.folderPathWidget.getTop();
		print("isUHDContentFolder topFolder:"+topFolder);
		Log.e("isUHDContentFolder topFolder:"+topFolder);
		if(topFolder == UHD_CONTENT_FOLDER_NAME){
			return true;
		}
		
		return false;
	},
	/** Get top folder from folder view 
	* @name getTopFolder	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
	getTopFolder : function(){
		return	self.folderPathWidget.getTop();
	},
	/** Get delete all path flag
	* @name isDeleteAllPath	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
	isDeleteAllPath:function(){
		return self.isDeleteAll;
	},
	
	/** Delete all path
	* @name clearAllPath	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
	clearAllPath: function(){
	
		print('[clearAllPath]  folderPathWidget:', self.folderPathWidget);
		
		if(self.folderPathWidget != null && self.folderPathWidget != undefined){
			
			self.folderPathWidget.clearAllPath();
		}

		self.isDeleteAll = true;
	},
	
	/** Expand FolderPathView
	* @name expand	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
    expand: function() {

    },
    
	/** Shrink FolderPathView
	* @name shrink	 
	* @memberOf FolderPathView	
	* @method 	 
	* */
    shrink: function() {

    }

});

exports = FolderPathView;
