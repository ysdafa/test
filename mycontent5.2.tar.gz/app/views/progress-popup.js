 /** 
 * @author  Xiaoming Chen (xiaom.chen@samsung.com)
 * 			
 * @fileoverview  Common popup view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var CommonInfo = Volt.require('app/common/define.js');
var ProgressPopupType = CommonInfo.ProgressPopupType;
var BaseView = Volt.BaseView;

/* template */
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var ProgressPopupTemplate = Volt.require('app/templates/1080/progress-popup-template.js');

var CommonInfo = Volt.require('app/common/define.js');
var EventType = CommonInfo.EventType;
var CSFSefType = CommonInfo.CSFSefType;
var MessageType = CommonInfo.MessageType;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var DeviceProvider = Volt.require("app/models/device-provider.js");
var Q = Volt.require('modules/q.js');
var CommMessageBox = Volt.require('app/views/comm-message-box.js');
var MsgBoxType = CommonInfo.MsgBoxTemplateType;
var CsfMgr = Volt.require('app/models/csf-manager.js');
var mycontentWidth = RunTimeInfo.SceneResolution;


var self = null;


var ProgressPopup = PanelCommon.BaseView.extend({
    template : ProgressPopupTemplate.oneProgressBarContainer,
	wParent: null,				//parent of popup widget
	btn1: null,
	popupWidget: null,
	progressType : ProgressPopupType.eOneProgrePopup,
	progressBar1: null,
	progressBar2: null,
	itemNum: 0,
	devInfo: null,
	isCancelState: true,
	curFileCount: 1,
	timeOut: null,
	btnListener: null,
	sendTimer: null,
	keyboardListener: null,
	reqAgent: null,
	isBtnShow: true,
	/**init progress popup
	* @name initialize	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
    initialize: function() {
        self = this;
		var mainView = Volt.require('app/views/main-view.js');
		self.wParent = mainView.widget.getChild('main-popup-container');
		EventMediator.on(EventType.EVENT_TYPE_UPDATE_PROGRESS_BAR_INFO, self.updateProgressBarInfo, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_SENDING_POPUP, self.hideSendingPopup, this);
		EventMediator.on(EventType.EVENT_TYPE_EXIT, self.hideSendingPopup, this);
		self.isCancelState = true;
		self.reqAgent = RunTimeInfo.router.currentView.collection.getRequestAgent();
    },

	/**render progress popup
	* @name render	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	render: function() {
		if(self.popupWidget != null){
			self.popupWidget.destroy();
		}
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		if(self.progressType == ProgressPopupType.eOneProgrePopup){
			self.renderOneProgrePopup();
		}
		else if(self.progressType == ProgressPopupType.eTwoProgrePopup){
			self.renderTwoProgrePopup();
		}
		else{
		}

		this.setWidget(self.popupWidget);
		Volt.Nav.setRoot(self.popupWidget);
		//self.popupWidget.onKeyEvent = self.onKeyEvent;
		self.setDefaultFocus();
		RunTimeInfo.isSendPopupShow = true;
        //Volt.Nav.beginModal(self.popupWidget);
        return this;
    },

	/**render one progress bar popup
	* @name renderOneProgrePopup	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	renderOneProgrePopup: function(){
		DeviceProvider.regsiterListener(self,self.onDevConnect,self.onDevDisconnect);
		var mustache = {
        		title: resMgr.getText('COM_SID_DELETING_KR_PANEL'),
    			message: resMgr.getText('COM_TV_SID_TOTAL') + ' (0/'+ self.itemNum.toString() + ')',
    		};
		self.template = ProgressPopupTemplate.oneProgressBarContainer;
        self.popupWidget = PanelCommon.loadTemplate(self.template,mustache,self.wParent);
		//self.popupWidget.parent = self.wParent;
		self.renderButton();
		self.renderProgressBar();
    },

	/**render two progress bar popup
	* @name renderTwoProgrePopup	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	renderTwoProgrePopup: function(){
		DeviceProvider.regsiterListener(self,self.onDevConnect,self.onDevDisconnect);
		var mustache = {
        		title: resMgr.getText('COM_TV_SENDING_DOT'),
    			message1: resMgr.getText('COM_TV_SID_TOTAL') +' (0/0)',
    			message2: resMgr.getText('COM_BDP_STR_MODE_REPEAT_TRACK_ONE') + '1',
    		};
		self.template = ProgressPopupTemplate.twoProgBarContainer;
        self.popupWidget = PanelCommon.loadTemplate(self.template,mustache,self.wParent);
		//self.popupWidget.parent = self.wParent;
		self.renderTwoProgressButton();
		self.renderTwoProgressBar();
    },

	/**render two progress bar popup button
	* @name renderTwoProgressButton	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	renderTwoProgressButton: function(){
		var btnWidget1 = self.popupWidget.getChild(8);
		if(btnWidget1 != null){
			self.btn1 = btnWidget1;
			self.btn1.setText({state: "all", text: resMgr.getText('COM_SID_STOP'),});
			self.btn1.setTextColor({state: "all", color: { r:255, g:255, b:255 },});
			
			self.btn1.setFontSize({state: "normal", size: 32,});
			self.btn1.setFontSize({state: "focused", size: 36,});
			self.btn1.setFontSize({state: "focused-roll-over", size: 36,});
			self.btn1.setFontSize({state: "selected", size: 36,});
			self.btn1.setBackgroundColor({state: "all", color: { r:255, g:255, b:255, a: 0 },});
			
			self.btn1.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.btn1.setBorder({state: "focused-roll-over",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.btn1.setBorder({state: "normal",border: {width:1, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			
			var buttonListener = new ButtonListener;
			self.btnListener = buttonListener;
			self.btn1.addListener(buttonListener);
			buttonListener.onButtonClicked = function (button, type){
				print('----buttonListener type = ',type);
				self.onBtnCallBack();
			};
			/*
			self.keyboardListener = new KeyboardListener;
			//self.keyboardListener.onKeyPressed = function (actor, keyCode) {
			self.keyboardListener.onKeyReleased = function (actor, keyCode) {
				print('progress-popup.js keyboardListener keyCode = ',keyCode);
				if (keyCode == Volt.KEY_JOYSTICK_OK) {
					//Volt.setTimeout(self.onBtnCallBack, 1);
					self.onBtnCallBack();
				}
			};
			self.btn1.addKeyboardListener(self.keyboardListener);
			*/
			//self.btn1.callback = self.onBtnCallBack;
			self.btn1.show();
		}
    },

	/**render two progress bar
	* @name renderTwoProgressBar	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	renderTwoProgressBar: function(){
		var progressWidget1 = self.popupWidget.getChild(4);
		if(progressWidget1 != null){
			self.progressBar1 = progressWidget1;
			self.progressBar1.setPosition(510+(mycontentWidth-1920)/2,152);
			self.progressBar1.setProgressColor(255,255,255,255);
			self.progressBar1.setBackgroundColor(255,255,255,25);				
		}

		var progressWidget2 = self.popupWidget.getChild(7);
		if(progressWidget2 != null){
			self.progressBar2 = progressWidget2;
			self.progressBar2.setPosition(510+(mycontentWidth-1920)/2,264);
			self.progressBar2.setProgressColor(255,255,255,255);
			self.progressBar2.setBackgroundColor(255,255,255,25);				
		}
    },

	/**render one progress bar
	* @name renderProgressBar	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	renderProgressBar: function(){
		var progressWidget = self.popupWidget.getChild(4);
		if(progressWidget != null){
			self.progressBar1 = progressWidget;
			self.progressBar1.setPosition(510+(mycontentWidth-1920)/2,172);
			self.progressBar1.setProgressColor(255,255,255,255);
			self.progressBar1.setBackgroundColor(255,255,255,25);			
			//self.progressBar1.unprocessColor = Volt.hexToRgb('#ffffff','10');
			//self.progressBar1.show();
		}
    },

	setDeviceInfo: function(info){
		self.devInfo = info;
    },

	/** Get interst device postion   	 
	* @name onDeviceConnect	 
	* @memberOf ProgressPopup
	* @param {type} Device type , USB/DLNA/RA/PTP
	* @method 	 
	* */
    onDevConnect: function(deviceInfo){
        print('[progress-popup.js] onDeviceConnect :',deviceInfo );
    },

	/** Get interst device postion   	 
	* @name onDeviceDisconnect	 
	* @memberOf ProgressPopup
	* @param {type} Device type , USB/DLNA/RA/PTP
	* @method 	 
	* */
    onDevDisconnect: function(deviceID,deviceType){
    	/*if(self.popupWidget == null){
			return;
    	}
		print("[progress-popup.js] Remove device id:",deviceID, 'deviceType :',deviceType);
		//print("[progress-popup.js] device id:",self.devInfo.get('id'));
		var id = RunTimeInfo.router.mainView.lastFocusDevInfo.get('id');
		print("[progress-popup.js] last focus id:",id);
		if(self.devInfo != null && (deviceID == self.devInfo.get('id'))){
			print("[progress-popup.js] 2223334found focus id!");
			self.hide();
			self.timeOut = Volt.setTimeout(self.destroy, 1);
			//var devName = self.devInfo.get('displayName');
			//self.showDevDisConnectMsgBox(devName);
		}
		else{
			if(RunTimeInfo.router.mainView.lastFocusDevInfo != null){
				var lastFocusId = RunTimeInfo.router.mainView.lastFocusDevInfo.get('id');
				print("[progress-popup.js] 1111last focus id:",lastFocusId);
				if(deviceID == lastFocusId){
					print('progress-popup.js, Found focus id!');
					self.hide();
					self.timeOut = Volt.setTimeout(self.destroy, 1);
					//var devName = RunTimeInfo.router.mainView.lastFocusDevInfo.get('displayName');
					//self.showDevDisConnectMsgBox(devName);
					//EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				}
			}
		}*/
		
    },
    
    isWorkingDevice : function(deviceId){
    	var fromId = RunTimeInfo.router.mainView.lastFocusDevInfo.get('id');
    	if(fromId == deviceId){
    		return true;
    	}
    	
    	if(!self.devInfo){
    		return false;
    	}
    	
    	var toId = self.devInfo.get('id');
    	if(deviceId == toId){
    		return true;
    	}
    	
    	return false;
    },

	renderButton: function(){
		var btnWidget1 = self.popupWidget.getChild(5);
		if(btnWidget1 != null){
			self.btn1 = btnWidget1;
			self.btn1.setText({state: "all", text: resMgr.getText('COM_SID_CANCEL'),});
			self.btn1.setTextColor({state: "all", color: { r:255, g:255, b:255, a:255 },});
			self.btn1.setFontSize({state: "normal", size: 32,});
			self.btn1.setFontSize({state: "focused", size: 36,});
			self.btn1.setFontSize({state: "focused-roll-over", size: 36,});
			self.btn1.setFontSize({state: "selected", size: 36,});
			self.btn1.setBackgroundColor({state: "all", color: { r:255, g:255, b:255, a: 0 },});
			
			self.btn1.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.btn1.setBorder({state: "focused-roll-over",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.btn1.setBorder({state: "normal",border: {width:1, color: {r:0xff,g:0xff,b:0xff,a:255}}});

			//self.btn1.setParent(self.popupWidget);
			if(self.itemNum > 1){
				self.btn1.show();
			}
			else{
				self.isBtnShow = false;
				self.btn1.hide();
			}
			var buttonListener = new ButtonListener;
			self.btnListener = buttonListener;
			self.btn1.addListener(buttonListener);
			buttonListener.onButtonClicked = function (button, type){
				print('----progress buttonListener type = ',type);
				print('----progress button = ',button);
				if(button.id == 'one-progress-bar-btn1'){
					print('----progress button id = ',button.id);
					if(self.itemNum > 1){
						self.onBtnCallBack();
					}
					else{
						if(self.isBtnShow == true){
							self.onBtnCallBack();
						}
					}
				}
			};
			//self.btn1.callback = self.onBtnCallBack;
			//self.btn1.show();
		}
    },

	cancelProcess: function(){
		print('[progress-popup.js]cancelProcess()');
		if(self.isCancelState == true){
			var agent = RunTimeInfo.router.currentView.collection.getShareHandle();
			print('[progress-popup.js]111111cancelProcess()');
			print('[progress-popup.js]11111144444cancelProcess()agent = ',agent);
			
			var navigatParam = {
				param_agent: RunTimeInfo.router.currentView.collection.getRequestAgent(),
				param_navigation: 0,
			};
			CsfMgr.setNavigation(navigatParam);    //after send,reset navigation to CSF_NAVIGATION_ALL
			
			var param = {
				param_share_handle: RunTimeInfo.router.currentView.collection.getShareHandle(),
			};
			RunTimeInfo.router.currentView.collection.csfApi.stopSend(param);
		}

		if(self.progressType == ProgressPopupType.eOneProgrePopup){
			//EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_SELECT_LIST_ITEM);
			EventMediator.trigger(EventType.EVENT_TYPE_EXIT_EDIT_MODE_VIEW);
			RunTimeInfo.router.currentView.updateSelectListItem();
			//EventMediator.trigger(EventType.EVENT_TYPE_EXIT_EDIT_MODE_VIEW);
		}
    },

	onBtnCallBack: function(){
		self.cancelProcess();
		self.hide();
		self.timeOut = Volt.setTimeout(this.destroy, 1);
		//self.destroy();
    },

	hideSendingPopup: function(){
		print('progress-popup.js hideSendingPopup()');
		self.onBtnCallBack();
    },

	hideDelProgBarMsg: function(){
		print('[progress-popup.js]hideDelProgBarMsg()');
		if(self.progressType == ProgressPopupType.eOneProgrePopup){
			var msgWidget = self.popupWidget.getChild(2);
			if(msgWidget != null){
				msgWidget.hide();
			}
		}
    },
	
	setProgBarMessage1Text: function(msgText){
		print('[comm-messge-box.js]setMessageText()');
		if(self.progressType == ProgressPopupType.eOneProgrePopup){
			var msgWidget = self.popupWidget.getChild(2);
			if(msgWidget != null){
				msgWidget.text = msgText;
			}
		}
		else if(self.progressType == ProgressPopupType.eTwoProgrePopup){
			var msgWidget = self.popupWidget.getChild(2);
			if(msgWidget != null){
				msgWidget.text = msgText;
			}
		}
		else{
		}
    },

	setProgBarMessage2Text: function(msgText){
		print('[comm-messge-box.js]setMessageText2()');
		var msgWidget = self.popupWidget.getChild(5);
		if(msgWidget != null){
			msgWidget.text = msgText;
		}
    },

	/**set default focus
	* @name setDefaultFocus	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	setDefaultFocus: function(){
		print('progress-popup.js setDefaultFocus');
		if(self.btn1 != null){
			self.btn1.enableFocus(true);
			self.btn1.setFocus();
		}
    },

	/**set progress type
	* @name setProgressType	 
	* @memberOf ProgressPopup
	* @parmater{progressType} progress type
	* @method 	 
	* */
	setProgressType: function(progressType){
		self.progressType = progressType;
	},

	setSelectItemNum: function(nums){
		self.itemNum = nums;
	},

	/**update one progress bar info
	* @name updateOneProgressBarInfo	 
	* @memberOf ProgressPopup
	* @parmater{eventType} received event type
	* @parmater{sendData} received data
	* @method 	 
	* */
	updateOneProgressBarInfo: function(eventType,sendData){
		if(self.popupWidget == null){
			print('[progress-popup.js]self.popupWidget is null');
			return;
		}

		if(sendData == null){
			print('[progress-popup.js]sendData is null');
			return;
		}
		
		var total_count = sendData.param_share_total_file_count;
		var done_count = sendData.param_share_done_file_count;
		print('[progress-popup.js]eventType = ',eventType);
		print('[progress-popup.js]total_count = ',total_count);
		print('[progress-popup.js]done_count = ',done_count);
		if(total_count == 0){
			print('[progress-popup.js]total_count is 0');
			return;
		}
		if(eventType == CSFSefType.SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED){
			print('2222222222[progress-popup.js]done_count = ',done_count);
			self.isBtnShow = true;
			var titleWidget = self.popupWidget.getChild(1);
			if(titleWidget != null){
				//titleWidget.text = 'Deleted successfully';
				titleWidget.text = resMgr.getText('TV_SID_DELETED_SUCCESSFULLY');
			}
			
			if(self.btn1 != null){
				self.btn1.setText({state: "all", text: resMgr.getText('COM_SID_OK'),});
				self.btn1.show();
				//self.btn1.setText(self.btn1.buttonState.STATE_FOCUSED, resMgr.getText('COM_SID_OK'));
				//self.btn1.m_UpdateState();
			}
			//self.updateOneProgressBar(1);
			var messge = resMgr.getText('COM_TV_SID_TOTAL') +' (' + done_count.toString() + '/' + total_count.toString() + ')';
			self.setProgBarMessage1Text(messge);
			if(self.itemNum == 1){
				self.hideDelProgBarMsg();
			}
			self.isCancelState = false;
			
			var navigatParam = {
				param_agent: self.reqAgent,
				param_navigation: 0,
			};
			CsfMgr.setNavigation(navigatParam);    //after send,reset navigation
			
			//EventMediator.trigger(EventType.EVENT_TYPE_DES_SELECT_ITEM);
			self.sendTimer = Volt.setTimeout(self.timeOutHide, 8000);	
		}
		else if(eventType == CSFSefType.SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED){
			print('3333333333333333333333333[progress-popup.js]done_count = ',done_count);
			var messge = resMgr.getText('COM_TV_SID_TOTAL') +' (' + done_count.toString() + '/' + total_count.toString() + ')';
			self.setProgBarMessage1Text(messge);
			var precent = done_count/total_count;
			self.updateOneProgressBar(precent);
		}
		else if(eventType == CSFSefType.SEF_CSF_EVENT_SHARE_FAIL){
			print('11111progress-popup.js delete pvr data failed');
			Log.e("progress-popup.js delete pvr data failed receive SEF_CSF_EVENT_SHARE_FAIL");
			var param = {
				param_share_handle: RunTimeInfo.router.currentView.collection.getShareHandle(),
			};
			RunTimeInfo.router.currentView.collection.csfApi.stopSend(param);
			
			var navigatParam = {
				param_agent: self.reqAgent,
				param_navigation: 0,
			};
			CsfMgr.setNavigation(navigatParam);    //after send,reset navigation
			
			//RunTimeInfo.router.currentView.setDesSelectItemToCsf();    //after stopsend, set all csf select status to disselect
			self.hide();
			//self.destroy();
		}
    },

	/**update two progress bar info
	* @name updateTwoProgressBarInfo	 
	* @memberOf ProgressPopup
	* @parmater{eventType} received event type
	* @parmater{sendData} received data
	* @method 	 
	* */
	updateTwoProgressBarInfo: function(eventType,sendData){
		if(self.popupWidget == null){
			print('[progress-popup.js]self.popupWidget is null');
			return;
		}

		if(sendData == null){
			print('[progress-popup.js]sendData is null');
			return;
		}
		
		var total_count = sendData.param_share_total_file_count;
		var done_count = sendData.param_share_done_file_count;
		print('[progress-popup.js]eventType = ',eventType);
		print('[progress-popup.js]total_count = ',total_count);
		print('[progress-popup.js]done_count = ',done_count);
		if(total_count == 0){
			print('[progress-popup.js]total_count is 0');
			return;
		}
		
		if(eventType == CSFSefType.SEF_CSF_EVENT_SHARE_ALL_FILE_FINISHED){
			print('2222222222[progress-popup.js]done_count = ',done_count);
			
			var titleWidget = self.popupWidget.getChild(1);
			if(titleWidget != null){
				titleWidget.text = resMgr.getText('COM_BDP_SID_SUCCESSFULLY_SENT');
			}
			
			if(self.btn1 != null){
				self.btn1.setText({state: "all", text: resMgr.getText('COM_SID_OK'),});
				//self.btn1.setText(self.btn1.buttonState.STATE_FOCUSED, Volt.LANG.COM_SID_OK);
				//self.btn1.m_UpdateState();
			}
			self.updateSecondProgressBar(1);
			self.isCancelState = false;

			RunTimeInfo.router.currentView.setDesSelectItemToCsf();
			
			var navigatParam = {
				param_agent: RunTimeInfo.router.currentView.collection.getRequestAgent(),
				param_navigation: 0,
			};
			CsfMgr.setNavigation(navigatParam);    //after send,reset navigation
			//EventMediator.trigger(EventType.EVENT_TYPE_DES_SELECT_ITEM); //when all file send, desselect files in csf
			//EventMediator.trigger(EventType.EVENT_TYPE_EXIT_EDIT_MODE_VIEW); //exit edit mode
			self.sendTimer = Volt.setTimeout(self.timeOutHide, 8000);		

		}
		else if(eventType == CSFSefType.SEF_CSF_EVENT_SHARE_ONE_FILE_FINISHED){
			print('3333333333333333333333333[progress-popup.js]done_count = ',done_count);

			var messge = resMgr.getText('COM_TV_SID_TOTAL') + ' (' + done_count.toString() + '/' + total_count.toString() + ')';
			self.setProgBarMessage1Text(messge);
			//for first progress bar update info
			var precent = done_count/total_count;
			self.updateFirstProgressBar(precent);
			self.updateSecondProgressBar(1);
			//for second progress bar update info
			if(self.curFileCount < total_count){
				var count = (++self.curFileCount);
			}
			else{
				var count = total_count;
			}
			var message2 = resMgr.getText('COM_BDP_STR_MODE_REPEAT_TRACK_ONE') + count.toString();
			self.setProgBarMessage2Text(message2);
			if(count < total_count){
				self.updateSecondProgressBar(0);
			}
		}
		else if(eventType == CSFSefType.SEF_CSF_EVENT_SHARE_FILE_UPDATE){
			
			var messge = resMgr.getText('COM_TV_SID_TOTAL') + ' (' + done_count.toString() + '/' + total_count.toString() + ')';
			self.setProgBarMessage1Text(messge);
			
			var curFileSize = sendData.param_share_current_file_size;
			var progressSize = sendData.param_share_progress_file_size;
			print('[progress-popup.js]curFileSize = ',curFileSize);
			print('[progress-popup.js]progressSize = ',progressSize);

			var precent = progressSize/curFileSize;
			self.updateSecondProgressBar(precent);
		}
		else if(eventType == CSFSefType.SEF_CSF_EVENT_SHARE_FAIL){
			print('progress-popup.js copy to usb failed');
			Log.e("progress-popup.js copy to usb failed receive SEF_CSF_EVENT_SHARE_FAIL!");
			var param = {
				param_share_handle: RunTimeInfo.router.currentView.collection.getShareHandle(),
			};
			RunTimeInfo.router.currentView.collection.csfApi.stopSend(param);

			var navigatParam = {
				param_agent: RunTimeInfo.router.currentView.collection.getRequestAgent(),
				param_navigation: 0,
			};
			CsfMgr.setNavigation(navigatParam);    //after send,reset navigation to CSF_NAVIGATION_ALL
			
			RunTimeInfo.router.currentView.setDesSelectItemToCsf();  //after stopsend, set all csf select status to disselect
			self.hide();
			Volt.setTimeout(this.destroy, 1);
		}
    },

	updateProgressBarInfo: function(eventType,sendData){
		if(self.progressType == ProgressPopupType.eOneProgrePopup){
			self.updateOneProgressBarInfo(eventType,sendData);
		}
		else if(self.progressType == ProgressPopupType.eTwoProgrePopup){
			self.updateTwoProgressBarInfo(eventType,sendData);
		}
		else{
		}
	},

	updateOneProgressBar: function(precent){
		print('[progress-popup.js] precent = ',precent);
		if(self.progressBar1 != null){
//			self.progressBar1.setProgress(precent);
			self.progressBar1.setValue(precent*100);
		}
		var precentWidget = self.popupWidget.getChild(3);
		if(precentWidget != null){
			var preText = (precent*100).toFixed(0).toString() + '%';
			precentWidget.text = preText;
		}
    },

	updateFirstProgressBar: function(precent){
		print('[progress-popup.js] precent = ',precent);
		if(self.progressBar1 != null){
//			self.progressBar1.setProgress(precent);
			self.progressBar1.setValue(precent*100);
		}
		var precentWidget = self.popupWidget.getChild(3);
		if(precentWidget != null){
			var preText = (precent*100).toFixed(0).toString() + '%';
			precentWidget.text = preText;
		}
    },

	showDevDisConnectMsgBox : function(name) {
		print('[main-view.js] showDevDisConnectMsgBox name = ',name);
		var deferred =  Q.defer();
        	deferred.resolve();

		var popup = new CommMessageBox();
		var disConText = resMgr.getText('COM_TV_SID_MIX_IS_DISCONNECTED');
		disConText = disConText.replace('<<A>>',name);		
		print('showDevDisConnectMsgBox >>>>>>>>  disConText:',disConText);
		popup.render(MessageType.eDisconnectUsb,disConText);
		return deferred.promise;
	},


	updateSecondProgressBar: function(precent){
		print('[progress-popup.js] precent = ',precent);
		if(self.progressBar2 != null){
//			self.progressBar2.setProgress(precent);
			self.progressBar2.setValue(precent*100);
		}
		var precentWidget = self.popupWidget.getChild(6);
		if(precentWidget != null){
			var preText = (precent*100).toFixed(0).toString() + '%';
			precentWidget.text = preText;
		}
    },

	/**hide progress popup when time out
	* @name timeOutHide	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	timeOutHide: function(){
		print('progress-popup.js, timeOutHide()!');
		self.cancelProcess();
		self.hide();
		self.destroy();
    },
    
	/**hide progress popup
	* @name hide	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
    hide : function(){
    	print('[progress-popup.js] hide()');
		if(self.popupWidget != null){
			//Volt.Nav.endModal(self.popupWidget);
			self.btn1.killFocus();
			self.btn1.custom.focusable = false;
			self.popupWidget.hide();
			RunTimeInfo.isSendPopupShow = false;
			EventMediator.off(EventType.EVENT_TYPE_UPDATE_PROGRESS_BAR_INFO, self.updateProgressBarInfo, this);
			EventMediator.off(EventType.EVENT_TYPE_HIDE_SENDING_POPUP, self.hideSendingPopup, this);
			EventMediator.off(EventType.EVENT_TYPE_EXIT, self.hideSendingPopup, this);
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
			EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_DEVICE_AVAILABLE_SIZE);
			//Volt.Nav.reload();
		}
		else{
			print('[progress-popup.js] self.popupWidget is NULL!');
		}
		if(self.sendTimer != null){
			Volt.clearTimeout(self.sendTimer);
		}
    },

	/**destroy progress popup
	* @name destroy	 
	* @memberOf ProgressPopup
	* @method 	 
	* */
	destroy : function(){
		print('--------------Progerss-popup.js destroy()');
		if(!self.popupWidget){
			return;
		}
		if(self.timeOut != null){
			Volt.clearTimeout(self.timeOut);
		}
		EventMediator.off(EventType.EVENT_TYPE_UPDATE_PROGRESS_BAR_INFO, self.updateProgressBarInfo, this);
		//if(self.btn1 != null){
			//self.btn1.destroy();
		//}
		if(self.btn1 != null && self.btnListener != null){
			self.btn1.removeListener(self.btnListener);
			//HALOUtil.asyncRelease(self.btn1);
			self.btn1 = null;
		}
		//HALOUtil.asyncRelease(self.popupWidget);
		self.popupWidget.destroy();
		self.popupWidget = null;
		
		var mainView = Volt.require('app/views/main-view.js');
		mainView.popup = null;
		mainView.setRoot();
		//Volt.Nav.focus(Volt.Nav.getItem(0));
		//EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM); 
		//Volt.Nav.focus(Volt.Nav.getItem(0));
	},

	onKeyEvent: function(KeyCode,type){
		print('[progress-popup.js.js] onKeyEvent()');
		if (type != Volt.EVENT_KEY_RELEASE){
			return false;
		}
		
		var ret = true;
		switch(KeyCode){
			case Volt.KEY_RETURN:{
				Log.e("[progress-popup.js.js] onKeyEvent() RETURN");
				self.cancelProcess();
				self.hide();
				self.timeOut = Volt.setTimeout(this.destroy, 1);
				break;
			}
			default:
				ret = false;
				break;
		}
		
		return ret;
	},
});

exports = ProgressPopup;

