 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  welcome page view
 * @date    2014/12/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var PanelCommon = Volt.require('lib/panel-common.js');
var resMgr = Volt.require('app/controller/resource-controller.js');
var appLauncher = Volt.require("app/controller/app-launch.js");
var CommonInfo = Volt.require("app/common/define.js");
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var deviceProvider = Volt.require("app/models/device-provider.js");
var EventMediator = RunTimeInfo.EventMediator;
var EventType = CommonInfo.EventType;
var LaunchAppID = CommonInfo.LaunchAppID;
var loadTemplate = PanelCommon.loadTemplate;


var self = null;
var WelcomePageView = PanelCommon.BaseView.extend({
	template : null,
	button : null,
	buttonListener: null,
	focusListener: null,

	initialize : function(){
		self = this;
		self.template = Volt.require('app/templates/1080/welcome-page-template.js').container;
	},
	
	destroy : function(){
		deviceProvider.unregsiterListener(self,self.onDeviceConnect,self.onDeviceDisconnect, self.onDeviceUpdate);
		HALOUtil.asyncRelease(self.widget);
	},
	
	render : function(){
		print('[welcome-page-view.js]render----------------------------');
		var mainView = Volt.require('app/views/main-view.js');
		var viewWidget = loadTemplate(self.template, null, mainView.getViewContainer(), false);
		self.setWidget(viewWidget);
		self.initButton();
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SETTING);
		deviceProvider.regsiterListener(self,self.onDeviceConnect,self.onDeviceDisconnect, self.onDeviceUpdate);
		Stage.show();
		return self;	
	},
	
	show: function(aniType) {
		print('[welcome-page-view.js]show----------------------------');
        self.widget.show();
        Volt.Nav.setRoot(this.widget);
		return PanelCommon.doViewSwitchAni(this.widget,'SHOW_NONE');
    },

    hide: function(aniType) {
        return PanelCommon.doViewSwitchAni(this.widget,'HIDE_NONE');
    },
    
	initButton : function(){		
		self.button = self.widget.getDescendant('connectDeviceButton');
		if(!self.button){
			return ;
		}
		
		//add button listener
		self.buttonListener = new ButtonListener;
		self.buttonListener.onButtonClicked = self.onButtonClick;
		self.button.addListener(self.buttonListener);
		
		//init UI   	
    	self.button.setBackgroundImage({state: 'normal', src: resMgr.getImgPath()+'/button/btn_style_a_n.png'});
    	self.button.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
    	self.button.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.button.setTextColor({state: 'normal', color: { r:00, g:00, b:00, a:204 }}); 
		self.button.setTextColor({state: 'focused', color: { r:33, g:158, b:230, a:255 }}); 
		self.button.setTextColor({state: 'focused-roll-over',  color: { r:33, g:158, b:230, a:255 }});
		self.button.setTextColor({state: 'selected',  color: { r:33, g:158, b:230, a:255 }});
    	self.button.setFontSize({state: 'normal', size: 32});
    	self.button.setFontSize({state: 'focused', size: 36});	
    	self.button.setFontSize({state: 'focused-roll-over', size: 36});
    	self.button.setFontSize({state: 'selected', size: 36});
    	self.button.setBackgroundColor({state: 'normal', color: { r:255, g:255, b:255, a:255 }});
		self.button.setBackgroundColor({state: 'focused', color: { r:255, g:255, b:255, a:255 }});
		self.button.setBackgroundColor({state: 'focused-roll-over', color: { r:255, g:255, b:255, a:255 }}); 	
		self.button.setBackgroundColor({state: 'selected', color: { r:255, g:255, b:255, a:255 }});                       			
    	self.button.setText ({state: 'all', text: 'How to connect devices'}); 
    	self.button.setFocus();
    	self.button.show();
	},
	
	onKeyEvent : function(key, type){
		if(type != Volt.EVENT_KEY_RELEASE){
			return false;
		}
		
		var ret = true;	
		switch(key){
			case Volt.KEY_RETURN :
				Volt.exit();
				break;	
	     	default:
    	    	ret = false;
    	    	break;
		}
		
		return ret;
	},
	
	onButtonClick : function(button, type){
		if(!button){
			return ;
		}
		print('[welcome-page-view.js]onButtonClick----------------launch WebAppService');
		self.launchWebAppservice();
	},
	
	launchWebAppservice : function(){
		var args = {
			'WIDGET_ID_SRC' : 'org.volt.mycontents',
			'EVENT_TYPE' : '4201',
			'DATA' : '&menuitem=mycontents',
	    };	
		appLauncher.launch(LaunchAppID.APP_ID_WEBAPP_SERVICE, args);	
	},
	
	onDeviceConnect: function(deviceInfo){
        
    },
    
    onDeviceDisconnect: function(deviceID,deviceType){
		   	
    },
    
    onDeviceUpdate:function(device){
		
	},
});

exports = WelcomePageView;

