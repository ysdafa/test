/** 
 * @author clips engineer
 * @fileoverview main-popup-view.js
 * @date 2014/07/24
 * 
 * @version 1.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 * 
 * @note: Volt 2.0 maybe draw children according to index sequence
 */


// Require Common Modules
var PanelCommon = Volt.require('lib/panel-common.js');
var _ = Volt.require("modules/underscore.js")._;
var Backbone = Volt.require('modules/backbone.js');
var BaseView = Volt.BaseView;
  
// Require Specific template for Games Main View
var LongPressPopupTemplate = Volt.require('app/templates/1080/long-press-popup-template.js');

var CommonInfo = Volt.require('app/common/define.js');
var EventType = CommonInfo.EventType;
var EViewType = CommonInfo.EViewType;
var EItemType = CommonInfo.EItemType;
var resMgr = Volt.require('app/controller/resource-controller.js');
//Require Run Time Modules
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var self = null;
var mainView = Volt.require('app/views/main-view.js');
/**when long press on content item ,show it
 * @class
 * @name PopupView 
 * @augments PanelCommon.BaseView
 */
var LongPressPopupView = PanelCommon.BaseView.extend({
    mediator: null,     // Handle Events
    popup: null,        // Store popup widget
    options: null,    // store the options of render()
    timeOut: null,
    wParent: null,
    
    /**Initialize PopupView 
     * @name initialize
     * @memberOf PopupView
     * @constructs 
     */
    initialize: function(options) {
        // Get mediator from MainView
        self = this;
		self.wParent = mainView.widget.getChild('main-popup-container');
		EventMediator.on(EventType.EVENT_TYPE_EXIT_LONG_PRESS_POPUP, this.onTimeoutCB, this);
    },

    /**Render popup
     * @name render
     * @memberOf PopupView
     * @param {Number} itemWidth  itemWidth of PopupView
     * @param {Number} x  coordinate x of PopupView
     * @param {Number} y  coordinate y of PopupView
     * @param {String} cpName  
     * @method
     */
    render: function(itemWidth, x, y, cpName) {
		//this.mediator.trigger('EVENT_DIM_MAINVIEW',this.options);
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		var popup_x,popup_y;


        // Load template
       // var popup = PanelCommon.loadTemplate(LongPressPopupTemplate.optionMenu, null, self.wParent, false);
       print("Long-press-view.js scene.width =",scene.width);
		print("Long-press-view.js scene.height =",scene.height);
		 Log.e("Long-press-view.js scene.width ="+scene.width);
		Log.e("Long-press-view.js scene.height ="+scene.height);
        // Custom Widget specific initialization
        if( x + 282  > 1920){
			popup_x = x - 282 - itemWidth;
        }
		else{
			popup_x = x;
		}
		if(y+ 72 > 1080){
        	popup_y = 1080 - 72;
		}
		else{
			popup_y = y;
		}
		var firstText = null;
		if( cpName == resMgr.getText('COM_SID_DELETE')){
			firstText = [{style: 5, text: cpName , bDim: false},
							 {style: 5, text: resMgr.getText('COM_TEXT_INFORMATION_P') , bDim: false}];
		}
		else{
			firstText = [{style: 5, text: cpName , bDim: false}];
		}
		
		
			var Optionmenu = ({
			type:'cmOption',
			x: popup_x,
			y: popup_y,
			width: 282,
			color: Volt.hexToRgb('#ff0000'),
			id:"option",
			nResoultionStyle: "1",
			parent: self.wParent,
			//bgColor: { r: 15, g: 24, b: 42, a: 255 },
			bgColor: { r: 39, g: 124, b: 175, a: 200 },
			showNumber: 2,
			items: firstText,
			//subx:100,
			//suby:100,
	       // subText: tempSecText,
	        isSubtextShow:false,
		});
		var popup = PanelCommon.loadTemplate(Optionmenu);
		Volt.Nav.setRoot(popup);
		this.setWidget(popup);
      //  popup.setListTextStyle({      x: 20, });

	//	popup.setListText(0, cpName);
		//popup.text[0] = this.cpName;
		popup.setTimeout(10*1000, _.bind(this.onTimeoutCB,this));
        popup.setCallback(_.bind(this.onOptionMenuCB, this));
	//	popup.setShowListArrow(false);
		popup.enableFocus(true);
        popup.setFocus();
        popup.show();
		this.popup = popup;
		RunTimeInfo.isLongPopupShow = true;
		//this.popup.onKeyEvent = self.onKeyEvent;
        return this;
    },

	onTimeoutCB: function () {
        Volt.log('option-menu timeout');
        self.remove();
		//var mainView = Volt.require('app/views/main-view.js');
		Volt.Nav.setRoot(mainView.widget);    //when device popup destroy,set root widget to main view
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
    },
    /**remove popup
     * @name remove
     * @memberOf PopupView
     * @method
     */
    remove: function() {
    	print('long-press-view.js remove');
    	//EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
        //Volt.Nav.endModal();
        RunTimeInfo.isLongPopupShow = false;
		EventMediator.off(EventType.EVENT_TYPE_EXIT_LONG_PRESS_POPUP, this.onTimeoutCB, this);
        if(self.popup){
			print('11111111111long-press-view.js remove');
            self.popup.hide();
            self.popup.destroy();
	    	self.popup = null;
        }
		if(self.timeOut != null){
			Volt.clearTimeout(self.timeOut);
		}
        return self;
    },

    /**callback of select item on popup
     * @name onOptionMenuCB
     * @memberOf PopupView
     * @method
     */
    onOptionMenuCB: function(index, subIndex){
        print('[long-press-view.js]onOptionMenuCB index = ',index);
		print('[long-press-view.js]onOptionMenuCB subIndex = ',subIndex);
        if (index == 0) {
			//if(){ //app is not installed
				//Volt.Nav.endModal();	            
				this.timeOut = Volt.setTimeout(this.remove, 1);
				//EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
				var tempView = RunTimeInfo.router.currentView;
				var tempItem = null;
				if( tempView ){
					tempItem = tempView.collection.getItem(tempView.longPressFocusIndex);
				}
				if( tempItem != null ){
					if( tempItem.get('ItemType') == EItemType.eItemPvr ){
						print('[long-press-view.js] select delete');
						var itemRecording = tempItem.get('isRecording');
						var isLock = tempItem.get('isLocked');
						if(itemRecording || isLock){
							if( RunTimeInfo.router.currentView ){
								RunTimeInfo.router.currentView.showDetailInfo();
							}
						}
						else{
							EventMediator.trigger(EventType.EVENT_TYPE_LONG_PRESS_SHOW_MSG_BOX);
						}
					}
					else{
						print('[long-press-view.js] select infomation');
						if( RunTimeInfo.router.currentView ){
							RunTimeInfo.router.currentView.showDetailInfo();
						}
					}
				}
				return;
			//}
        }
        else if (index == 1) {
			this.timeOut = Volt.setTimeout(this.remove, 1);
			if( RunTimeInfo.router.currentView ){
				RunTimeInfo.router.currentView.showDetailInfo();
			}
		}  
        else if (index == -1) {
            //self.onTimeoutCB();
        }   
    },

	onKeyEvent: function(KeyCode,type){
		print('[comm-message-box.js] onKeyEvent()');
		if (type != Volt.EVENT_KEY_RELEASE)
		{
			return false;
		}
		var ret = true;
		switch(KeyCode){
			case Volt.KEY_RETURN:{
				self.onTimeoutCB();
				break;
			}
			default:
				ret = false;
				break;
		}
		
		return ret;
	},

});


exports = LongPressPopupView;


