/** 
 * @author mycontents engineer 
 * @fileoverview loading-view.js.
 * @date 2014/07/26
 * 
 * @version 0.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */


var resMgr = Volt.require('app/controller/resource-controller.js');
var Q = Volt.require('modules/q.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var LoadingTemplate = Volt.require('app/templates/1080/loading-template.js');
var imagePath = Volt.getRemoteUrl(resMgr.getImgPath()+'/loading/white/');

/**when fetch data or switch content ,show it
 * @class
 * @name LoadingView 
 * @augments PanelCommon.BaseView
 */
var LoadingView = PanelCommon.BaseView.extend({
	viewIsVisiable : false,
	viewLoading : null,
	popupBG : null,
	bBlock : false,
	whitePointWidth : 20,

     /**Initialize LoadingView 
     * @name initialize
     * @memberOf LoadingView
     * @constructs 
     */
	initialize : function() {
		print('----------LoadingView initialize()');
		this.bBlock = false;
		var imageList;
		
		this.popupBG = PanelCommon.loadTemplate(LoadingTemplate.dimWgt);
		this.popupBG.hide();
		
		imageList = this.getLoadingImage(20);
		LoadingTemplate.viewLoading.imagePath = imageList.imgPath;
		LoadingTemplate.viewLoading.imageName = imageList.imgList;
		LoadingTemplate.viewLoading.parent = this.popupBG;
		this.viewLoading = this.createLoadingView(LoadingTemplate.viewLoading);
		this.viewLoading.stop();
	},
    
    /**Render LoadingView 
     * @name render
     * @memberOf LoadingView
     * @method 
     */ 
	render: function() {
		
	},
	
	/**Show LoadingView 
     * @name show
     * @memberOf LoadingView
     * @method 
     */ 
	show : function() {
		var that =this;
		this.viewIsVisiable = true;
		var deferred =  Q.defer();

		scene.removeChild(that.popupBG);
		scene.addChild(that.popupBG);
		
		this.popupBG.show();
		this.viewLoading.play();
		
		if(this.bBlock === false){
	            Volt.Nav.block();
	            this.bBlock = true;
	        }
		deferred.resolve();
		return deferred.promise;
	},

    /**Hide LoadingView 
     * @name hide
     * @memberOf LoadingView
     * @method 
     */ 
	hide : function() {
		var deferred = Q.defer();
		
		this.popupBG.hide();
		if (this.viewLoading) {
			this.viewLoading.stop();
		}
		
		if(this.bBlock === true){
	            Volt.Nav.unblock();
	            this.bBlock = false;
	        }   
		deferred.resolve();
		this.viewIsVisiable = false;
		return deferred.promise;
	},

	/**Create LoadingView 
     * @name createLoadingView
     * @memberOf LoadingView
     * @param {param} loading param
     * @method 
     */ 
	createLoadingView : function(param){
		var loadingWgt = new Loading(param);
		return loadingWgt;
	},
	
	/**get LoadingImage
     * @name getLoadingImage
     * @memberOf LoadingView
     * @param {whitePointWidth} loading iamge point width
     * @method 
     */ 
	getLoadingImage : function(whitePointWidth) {
		var imgList = [];
		var imgPath = imagePath + whitePointWidth + 'x' + whitePointWidth + '/';
		for (var i = 0; i < 63; i++) {
			var index = i+1;
			if (i < 9) {
				imgList[i] = 'loading_bright_' + whitePointWidth + '_0' + index + '.png';
			} else {
				imgList[i] = 'loading_bright_' + whitePointWidth + '_' + index + '.png';
			}
		}
		return {
			imgPath : imgPath,
			imgList : imgList
		};
	},
	
});

exports = new LoadingView();
