/** 
* @author  Hu Po (paul.hu@samsung.com)
* 			
* @fileoverview  Music Player List Render
* @date    2014/11/05 (last modified date)
*
* Copyright 2014 by Samsung Electronics, Inc.,
* 
* This software is the confidential and proprietary information
* of Samsung Electronics, Inc. ("Confidential Information").  You
* shall not disclose such Confidential Information and shall use
* it only in accordance with the terms of the license agreement
* you entered into with Samsung.
*/
var PanelCommon = Volt.require('lib/panel-common.js');
//PanelCommon.mapWidgets(['AutoScrollTextWidget']);
var DevPopupTemplate = Volt.require('app/templates/1080/device-list-template.js');
var loadTemplate = PanelCommon.loadTemplate;
var CommonInfo = Volt.require("app/common/define.js");
var self = null;

DeviceRender = function(){
	this.renderer = null,
	this.root = null,
	this.width = 0,
	this.height = 0,
	this.data = null,
	this.template = DevPopupTemplate.devListItem,
	self = this;
	
	this.getRender = function(parentWidth, parentHeight, data){
		print('device-list-render.js getRender()');
		this.width = parentWidth;
		this.height = parentHeight;
		this.data = data;
		this.renderer = new Renderer(parentWidth, parentHeight);

		this.initWidget(data);

		this.renderer.onDraw = this.onDraw;
		this.renderer.onRelease = this.onRelease;
		this.renderer.onUpdate = this.onUpdate;
		this.renderer.onResize = this.onResize;

		return this.renderer;
	};

	this.initWidget = function(data){
		print('device-list-render.js initWidget()');
		if( this.renderer != null ){
			
			this.renderer.root = new WidgetEx({
				x:0,
				y:0,	   
				width:0,	   
				height:0,	 
				parent:scene	
			});	

			if(data == null){
				 var mustache = {
			        imgUrl: '',
					title1: '',
			        devSize: '',
			    };
			}
			else{
			    var mustache = {
			        imgUrl: data.imgUrl,
					title1: data.displayName,
			        devSize: data.space,
			    };
			}
			
			var listItem = loadTemplate(self.template,mustache);

			this.renderer.check = listItem.getChild(0);
			if( this.renderer.check == null ){
				print('this.renderer.check == null, error!!');
				return;
			}	
			this.renderer.name = listItem.getChild(1);
			if( this.renderer.name == null ){
				print('this.renderer.name == null, error!!');
				return;
			}	
			this.renderer.space = listItem.getChild(2);
			if( this.renderer.space == null ){
				print('this.renderer.space == null, error!!');
				return;
			}
			this.renderer.bound1 = listItem.getChild(3);
			if( this.renderer.bound1 == null ){
				print('this.renderer.bound1 == null, error!!');
				return;
			}		
			this.renderer.bound2 = listItem.getChild(4);
			if( this.renderer.bound2 == null ){
				print('this.renderer.bound2 == null, error!!');
				return;
			}	
			this.renderer.bound3 = listItem.getChild(5);
			if( this.renderer.bound3 == null ){
				print('this.renderer.bound3 == null, error!!');
				return;
			}			
			this.renderer.bound4 = listItem.getChild(6);
			if( this.renderer.bound4 == null ){
				print('this.renderer.bound4 == null, error!!');
				return;
			}
			
			this.renderer.bound5 = listItem.getChild(7);
			if( this.renderer.bound5 == null ){
				print('this.renderer.bound5 == null, error!!');
				return;
			}
			
			
			this.renderer.root.addChild(this.renderer.check);
			this.renderer.root.addChild(this.renderer.name);			
			this.renderer.root.addChild(this.renderer.space);
			this.renderer.root.addChild(this.renderer.bound1);			
			this.renderer.root.addChild(this.renderer.bound2);
			this.renderer.root.addChild(this.renderer.bound3);			
			this.renderer.root.addChild(this.renderer.bound4);
			this.renderer.root.addChild(this.renderer.bound5);		
		}
	};

	this.onDraw = function(rendererInstance, drawTypeString, data, parentWidth, parentHeight){
		print(' drawTypeString = ', drawTypeString, 'rendererInstance=', rendererInstance);
		
        if ("LoadData" == drawTypeString){
		}        
		else if("UpdateData" == drawTypeString){
       	}        
		else if("FromItemFocusChangeAniStart" == drawTypeString){
			print('FromItemFocusChangeAniStart');
			rendererInstance.bound2.opacity = 0;
			rendererInstance.bound3.opacity = 0;
			rendererInstance.bound4.opacity = 0;
			rendererInstance.bound5.opacity = 0;
			//The from item of focus change motion start                   
		}        
		else if("ToItemFocusChangeAniStart" == drawTypeString){
			//The to item of focus change motion start
		}        
		else if("FormItemFocusChangeAniEnd" == drawTypeString){		
			//The from item of focus change motion start
		}        
		else if("ToItemFocusChangeAniEnd" == drawTypeString){
			print('ToItemFocusChangeAniEnd');
			rendererInstance.bound2.opacity = 255;
			rendererInstance.bound3.opacity = 255;
			rendererInstance.bound4.opacity = 255;
			rendererInstance.bound5.opacity = 255;			
			//The to item of focus change motion finish
		}
		
    };
		
	this.onUpdate = function(width, height){
		
	};

	this.onResize = function(rendererInstance, data, destWidth, destHeight, flagWithAni, duration){
		print('renderer.onResize~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
	};
		
	this.onRelease = function(){
		self.renderer.root.destroy();
		delete self.renderer;    
	};
};

exports = DeviceRender;
 