/**
 * @author Zha Lihao(lihao.zha@samsung.com)
 * @fileoverview An example of Games Main View.
 * @date 2014/06/28
 *
 * @version 1.1
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Require = Volt.require,
_ = Require('modules/underscore.js')._,
Backbone = Require('lib/volt-backbone.js'),
PanelCommon = Require('lib/panel-common.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var CommonInfo = Volt.require('app/common/define.js');
var colorList = CommonInfo.colorList;
var EventType = CommonInfo.EventType;
var ViewGlobalData = Volt.require("app/views/view-global-data.js");
var voideGuide = Volt.require('app/common/voice-guide.js');
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var DeviceType = CommonInfo.DeviceType;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var mycontentWidth = RunTimeInfo.SceneResolution;
var BalloonTips = Volt.require('app/views/balloon-tips.js');

var self = null;
////////////////////////////////////////////////////////////////////////////////
var MainPopupView = PanelCommon.BaseView.extend({
    mediator: null, // Handle Events

    popup: null, // Store popup widget

    options: null, // store the options of render()
	filterView: null,
	firstText: [],
	secondText: [],
    optionMenuIndex : -1, //save option menu selected index
    optionMenuSubIndex : [], //save option menu first selected index
    resetFlag: false,
    firstEnter: true,
    secondLeveFistTimeEnter:true,
    subMenuShown:false,
    secondMenuFocusIndex:[],
    itemCount:0,
    balloon:null,

	/** initialize
	* @name initialize	 
	* @memberOf MainPopupView
	* @param {Object} options
	* @method
	* @return {} 	 
	* */
    initialize: function(options) {
		self = this;
        this.mediator = options.mediator;
		this.optionMenuSubIndex[0] = 0;
		this.optionMenuSubIndex[1] = 2;
        this.mediator.on('EVENT_MAIN_POPUP_SHOW', this.render, this);
        this.mediator.on('EVENT_MAIN_POPUP_HIDE', this.remove, this);
		this.mediator.on(EventType.EVENT_TYPE_RETURN_TO_OPTION, this.returnToOptionMenu, this);
		var mainView = Volt.require('app/views/main-view.js');
		this.filterView = mainView.headerView.filterView;
    },

	/** render
	* @name render	 
	* @memberOf MainPopupView
	* @param {Object} options
	* @method  create sublist for option menu
	* @return {} 	 
	* */
    render: function (options) {
		print('MainPopupView:', options);
        this.options = {
            type: options,
            setRoot: false
        };
		
		self.firstEnter = true;
		print('main popup render >>>  this.firstEnter:',this.firstEnter);
        switch (options) {
        case 'OPTION_MENU':
            {
				print("sortIndex resetFlag"+this.resetFlag);
				if ( this.resetFlag == true && RunTimeInfo.router.currentViewType != EViewType.eConnectionGuideView){
					this.resetFlag = false;
					this.optionMenuSubIndex[1] = RunTimeInfo.router.getCurrentView().getSecondOptionText(1).length-1;
				}
				//option menu same as viewTypeIndex
				this.optionMenuSubIndex[0] = ViewGlobalData.viewTypeIndex;
				if( self.filterView.optionMenuSubIndex[1] > -1 ){
					this.optionMenuSubIndex[1] = self.filterView.optionMenuSubIndex[1];
					print("main-popup-view.js filterView.1optionMenuSubIndex[1]:"+self.filterView.optionMenuSubIndex[1]);
				}
				print("main-popup-view.js firstIndex:"+this.optionMenuSubIndex[0]+"secondIndex:"+this.optionMenuSubIndex[1]);
				var firstText = new Array();
				var mainView = Volt.require('app/views/main-view.js');
				this.itemCount = mainView.headerView.optionParam.firstOptionText.length;
				for (var index = 0; index < this.itemCount; index++){
					firstText.push({ style: 12, text: Volt.i18n.t(mainView.headerView.optionParam.firstOptionText[index]) });
				}
				var tempView;
				if ( RunTimeInfo.router.currentViewType == EViewType.eConnectionGuideView ){
					tempView = this.filterView;
					print("main-popup-view.js filterView.optionMenuSubIndex[1]:"+self.filterView.optionMenuSubIndex[1]);
					if ( self.filterView.optionMenuSubIndex[1] == -1 ){
						self.filterView.optionMenuSubIndex[1] = self.filterView.getSortLength(this.optionMenuSubIndex[0])-1;
						print("this.filterView.optionMenuSubIndex[1]:",self.filterView.optionMenuSubIndex[1]);
						this.optionMenuSubIndex[1] = self.filterView.optionMenuSubIndex[1];
					}
				}
				else{
					tempView = RunTimeInfo.router.getCurrentView();
				}
				var tempSecText = new Array();
				
				for ( var i = 0; i < this.itemCount; i++ ){
					if( tempView.isShowSecPlus[i] == true ){
						print('isShowSecPlus '+i+' true');
						var subText = tempView.getSecondOptionText(i);
						if (!subText){
							break;
						}
						print('subText.length: '+subText.length);
						var tempText = new Array();
						for (var j = 0; j < subText.length; j++){
							print('subText: '+subText[j]);
							tempText.push({ style: 13, text: Volt.i18n.t(subText[j]) });
						}
						tempSecText.push( {
			                index: i,
							showNumber: 6,
							bKeyCommon: true,
			                items: tempText,
			                width: 300,
			            }
						);
					}
					
				}
				
				var Optionmenu = ({
					type:'cmOption',
					x: mycontentWidth-330,
					y: 120,
					//width: 420,
					color: Volt.hexToRgb('#ff0000'),
					nResoultionStyle: "1",
					parent:this.widget,
					bKeyCommon: true,
					showNumber: 5,
					items: firstText,
					subx:-200,
					suby:0,
			        subText: tempSecText,
			        isSubtextShow:true,
				});
                var Optionmenu = PanelCommon.loadTemplate(Optionmenu);
				print('main-popup-view.js Optionmenu x = ',Optionmenu.x);
				print('main-popup-view.js Optionmenu y = ',Optionmenu.y);
				print('main-popup-view.js Optionmenu width = ',Optionmenu.width);
				Optionmenu.loopLeftFlag = false;
				Optionmenu.loopRightFlag = false;
				Optionmenu.setCallback(_.bind(this.onOptionMenuCB, this));
				Optionmenu.setFocusChangeCallback(_.bind(this.onOptionMenuFocusChange, this));
				var subIndex = 0;
				print("main-pop-view.js set focus0********************");
				for ( var i = 0; i < this.itemCount; i++ ){
					if( tempView.isShowSecPlus[i] == false ){
						if ( tempView.isDimFirstPlus[i] ){
							Optionmenu.dimListItem(i);
						}
					}
					else{
						subIndex = 0;
						if ( RunTimeInfo.router.currentViewType == EViewType.eConnectionGuideView ){
							subIndex = tempView.optionMenuSubIndex[i];
							var subText = tempView.getSecondOptionText(i);
							if(subIndex>=subText.length)
							{
								subIndex = subText.length-1;
							}
						}
						else if ( this.optionMenuSubIndex[i] )
						{
							subIndex = this.optionMenuSubIndex[i];
						}
						this.secondMenuFocusIndex[i] = subIndex;
						print('wi:'+i+', subIndex:'+subIndex);
						Optionmenu.setSubSelectIndex(i,subIndex);
						Optionmenu.setSubFocusIndex(i,subIndex);
					}
				}
				print("main-pop-view.js set focus1********************");
                Optionmenu.setTimeout( 10 * 1500 , _.bind( this.onTimeoutCB, this) );

                this.popup = Optionmenu;
				print("main-pop-view.js set focus2********************");
				Optionmenu.show();
				Optionmenu.keepSubFocusIndex(true);
				Optionmenu.setFocus();
				Optionmenu.showFocus('false');
				print("main-pop-view.js set focus3********************");
                //this.popup = popup;
                this.mediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
				mainView.isOptionPopupShown = true;
				RunTimeInfo.isOptionShowFlag = true;
                break;
            }
        default:
            break;
        }
		
		
        return this;
    },

	/** onOptionMenuFocusChange
	* @name onOptionMenuFocusChange	 
	* @memberOf MainPopupView
	* @param
	* @method  facus change callback of sublist
	* @return {} 	 
	* */
    onOptionMenuFocusChange: function(preIndex,preSubIndex,curIndex,curSubIndex,bDim){
    	//return;
		print('onOptionMenuFocusChange  >>>>>>' + ' preIndex:'+preIndex + ' preSubIndex: '+preSubIndex+' curIndex:'+curIndex+' curSubIndex:'+curSubIndex+' bDim:'+bDim);	
		//top menu
		
		if(self.balloon != null){
			print('onOptionMenuFocusChange >>> Destroy balloon.....');
			Log.e("onOptionMenuFocusChange >>> Destroy balloon.....");
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
		
		var tempCurView = null;
		
		if ( RunTimeInfo.router.currentViewType == EViewType.eConnectionGuideView ){
			tempCurView = self.filterView;
		}
		else{
			tempCurView = RunTimeInfo.router.getCurrentView();
		}

		var focusSub = 0;
		if ( curIndex == -1 ){
			focusSub = 2;
		}else{
			focusSub = 1;
		}
		
		if( focusSub == 1 ){
			if(self.firstEnter == false){
				print('Move focus on top menu.....')
				var txt = this.popup.getListText(curIndex);
				var filterTxt = '';
				print('RunTimeInfo.router.currentView.isShowSecPlus[curIndex] : ',tempCurView.isShowSecPlus[curIndex]);
				if( tempCurView.isShowSecPlus[curIndex] == true){
					filterTxt = this.popup.getSubListText(curIndex,this.secondMenuFocusIndex[curIndex]);
				}	
				
				if(bDim == false){
					
					voideGuide.play(txt+' '+filterTxt);
				}else{
					var disableText = txt + ' '+ filterTxt + ','+resMgr.getText('COM_SID_DISABLE');
					voideGuide.play(disableText);
				}
				if(curIndex == 1){
					//move focus to sort by item
					var mainView = Volt.require('app/views/main-view.js');
					print("mainView.categoryView.currentType:"+mainView.categoryView.currentType);
					if(mainView.categoryView.currentType == DeviceType.DEVICE_TYPE_DLNA){

						var text = resMgr.getText('TV_SID_CHANGING_SORT_ORDER_MY');
				    	var opt = {
					    		text: text,
					    		x: mycontentWidth-330,
					    		y: 120+68,
								wdgHeight: 72,
								wdgWidth : 0,
					    		fontsize: 28,
					    		font: 'SmasungSmart_Light 28px',
					    		tailType: 'right',
					    		textAreaW: 516,
				    	};
						try{
					    	self.balloon = new BalloonTips();
					    	self.balloon.show(opt);	
						}catch(e){
							print("onOptionMenuFocusChange show balloon e:"+e);
						}
					}	
				}
			}else{
				print('First enter top menu.....')		
				var count = this.itemCount;
				var filterTxt = '';
				print('RunTimeInfo.router.currentView.isShowSecPlus[curIndex] : ',tempCurView.isShowSecPlus[curIndex]);
				if( tempCurView.isShowSecPlus[curIndex] == true){
					print('main-popup-view.js, curIndex'+curIndex+'secondIndex:'+this.secondMenuFocusIndex[curIndex]);
					filterTxt = this.popup.getSubListText(curIndex,this.secondMenuFocusIndex[curIndex]);
				}
				var txt = resMgr.getText('COM_SID_OPTIONS')+','+count.toString()+','+resMgr.getText('COM_TV_SID_ITEMS')+','+this.popup.getListText(curIndex)+' '+filterTxt;
				voideGuide.play(txt);
				self.firstEnter = false;
			}
				
		}else{
		//sub menu
			print('Enter sub menu.....')
			if(curSubIndex != -1){
				print('First enter sub menu.....')
				print('focusChangeCallback >>> subMenuShown:', self.subMenuShown);
				if(preSubIndex == -1){
					var subText = this.popup.getSubListText(preIndex,curSubIndex);
					
					
					var subMenuTxt = tempCurView.getSecondOptionText(preIndex);
					
					if(subMenuTxt == undefined){
						return;
					}
					
					var itemCountTxt = subMenuTxt.length.toString()+','+resMgr.getText('COM_TV_SID_ITEMS');
					if(bDim == false){
						voideGuide.play(itemCountTxt+','+subText);
					}else{
						voideGuide.play(itemCountTxt+','+subText+','+resMgr.getText('COM_SID_DISABLE'));
					}
					self.subMenuShown = false;
				
				}else{
					print('Move focus on sub menu.....')
					var txt = this.popup.getSubListText(preIndex,curSubIndex);
					print('>>>>>>>>>>>>>  txt',txt);
				
					if(bDim == false){
						voideGuide.play(txt);
					}else{
						voideGuide.play(txt+','+resMgr.getText('COM_SID_DISABLE'));
					}
				}
			}

		}
	},

	/** remove
	* @name remove	 
	* @memberOf MainPopupView
	* @param
	* @method 
	* @return {} 	 
	* */
    remove: function (options) {
    	print('main-popup-view.js remove');
		RunTimeInfo.isOptionShowFlag = false;
		if ( RunTimeInfo.router.currentViewType != EViewType.eConnectionGuideView){
			//self.filterView.optionMenuSubIndex[1] = -1;
		}
		if(self.balloon != null){
			print('onOptionMenuFocusChange >>> Destroy balloon.....');
			Log.e("onOptionMenuFocusChange >>> Destroy balloon.....");
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
		if(this.popup == null){
			print('main-popup-view.js this.popup is null');
			return;
		}
		
        if (this.popup) {
			this.popup.hide();
            Volt.setTimeout(self.destroy,0);
        }
		this.optionMenuIndex = -1;
		var mainView = Volt.require('app/views/main-view.js');	
		Volt.Nav.setRoot(mainView.widget);
		mainView.isOptionPopupShown = false;
		this.mediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
        return this;
    },

	destroy: function(){
		print('main-popup-view.js destroy');
		if(self.popup != null){
			self.popup.destroy();
			self.popup = null;
		}
    },

	returnToOptionMenu : function(){
		if(this.popup){
			Volt.Nav.beginModal(this.popup);
		}
    },

	/** onOptionMenuCB
	* @name onOptionMenuCB	 
	* @memberOf MainPopupView
	* @param
	* @method  click callback of sublist
	* @return {} 	 
	* */
    onOptionMenuCB: function (index, subIndex, bDim) {
		print('onOptionMenuCB >>>>>  index is ' + index + ', subIndex is ' + subIndex);
		if ( RunTimeInfo.router.currentViewType == EViewType.eConnectionGuideView ){
			if ( index == 0 ){
				ViewGlobalData.viewTypeIndex = subIndex;
				this.filterView.optionMenuSubIndex[index] = subIndex;
				//this.resetFlag = true;
			}
			else{
				this.setConnectionGuideAttribute(index, subIndex);
			}
			
			if(index==0||index==1){
				this.setGlobalSort(index, subIndex);
			}
			this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
			return;
		}
		
		this.optionMenuIndex = index;
		if(subIndex != -1){
			this.optionMenuSubIndex[index] = subIndex;
		}
		if ( index >= 0 ){
			this.filterView.optionMenuSubIndex[index] = subIndex;
			print("onOptionMenuCB index"+index+"secindex:"+this.filterView.optionMenuSubIndex[index]);
		}
		var mainView = Volt.require('app/views/main-view.js');
		mainView.headerView.optionParam.firstSelectedIndex = this.optionMenuIndex;
		
		var MainPopupTemplate = Volt.require('app/templates/1080/main-popup-template.js');
        var optionMenuIndices = MainPopupTemplate.optionMenuIndices;
		
        if (subIndex == -1) {
			print('onOptionMenuCB >>> Set self.subMenuShown :', self.subMenuShown);
			self.subMenuShown = true;
			print('onOptionMenuCB >>>> Set self.subMenuShown :', self.subMenuShown);
            if (index != -1) {
                this.optionMenuIndex = index;
            }
   
            if (index === optionMenuIndices.sortByName) {

            } else if (index === optionMenuIndices.sortById) {

            } else if (index === optionMenuIndices.signIn) {
                //mainModel.updateAccountName('David Kim\'s Page');
            }

			if(bDim){
				print('main-popup-view.js, click index is ' + index);
				Volt.Nav.endModal();
				//this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
				this.mediator.trigger(EventType.EVENT_TYPE_SELECT_OPTION_MENU_1, index);

			}
			else{
				//Volt.Nav.endModal();
				var DeviceProvider = Volt.require("app/models/device-provider.js");
				if(index == 4 && DeviceProvider.getUsbDeviceCount() <= 1){
					this.mediator.trigger(EventType.EVENT_TYPE_SELECT_OPTION_MENU_1, index);
				}
				else{
					this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
					this.mediator.trigger(EventType.EVENT_TYPE_SELECT_OPTION_MENU_1, index);
				}
			}
			
        }
		else{
			if ( index == 0 ){
				this.resetFlag = true;
				//RunTimeInfo.router.mainView.popupView.optionMenuSubIndex[1] = RunTimeInfo.router.getCurrentView().getSecondOptionText(1).length-1;
			}
			mainView.headerView.optionParam.secondSelectedIndex[index] = subIndex;
			mainView.headerView.optionParam.secondOptionText = RunTimeInfo.router.getCurrentView().getSecondOptionText(index);
			if(index==0||index==1){
				this.setGlobalSort(index, subIndex);
			}
			this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
			this.mediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
			this.mediator.trigger(EventType.EVENT_TYPE_SELECT_OPTION_PLUS, subIndex);
			
			self.subMenuShown = false;
			
		}
		
    },

    setConnectionGuideAttribute: function ( index, subIndex ) {
        print("main-popup-view.js, setConnectionGuideAttribute,index:"+index+", subIndex:"+subIndex);
		var tempViewIndex = ViewGlobalData.viewTypeIndex;
		var tempSortText = self.filterView.getSecondOptionText(1);
		if( tempViewIndex == 1 ){
			ViewGlobalData.viewSortText[EViewType.ePhotoContentView] = tempSortText[subIndex];
		}
		else if( tempViewIndex == 2 ){
			ViewGlobalData.viewSortText[EViewType.eVideoContentView] = tempSortText[subIndex];
		}
		else if( tempViewIndex == 3 ){
			ViewGlobalData.viewSortText[EViewType.eMusicContentView] = tempSortText[subIndex];
		}
		else if( tempViewIndex == 4 ){
			ViewGlobalData.viewSortText[EViewType.eRecordContentView] = tempSortText[subIndex];
		}
		else{

		}
		//ViewGlobalData.viewSortText[tempViewIndex+1] = tempSortText[subIndex];
		this.filterView.optionMenuSubIndex[index] = subIndex;
		print("setConnectionGuideAttribute,tempViewIndex:"+tempViewIndex);
    },

    setGlobalSort: function ( index, subIndex ) {
		if( index == 0 ){
			//when select filter, store the sort type to filterView
			//var deText =  RunTimeInfo.router.getCurrentView().getSecondOptionText(1);
			var deText = this.filterView.getSortTextByViewIndex(subIndex);
			if( this.filterView.lastViewSortText == "" ){
				var deIndex = deText.length - 1;
				this.filterView.lastViewSortText = deText[deIndex];
				this.filterView.currentViewSortText = deText[deIndex];
				this.filterView.optionMenuSubIndex[1] = deIndex;
			}
			else{
				//check that last view sort type is useful or not for current view
				for(var i=0; i< deText.length; i++){
					if( deText[i] == this.filterView.lastViewSortText ){
						this.filterView.currentViewSortText = this.filterView.lastViewSortText;
						this.filterView.optionMenuSubIndex[1] = i;
						break;
					}
					if( i == (deText.length - 1)){
						this.filterView.currentViewSortText = deText[i];
						this.filterView.optionMenuSubIndex[1] = i;
					}
				}
			}
		}
		else if( index == 1 ){
			//when select sort, store the sort type to filterView
			if( RunTimeInfo.router.currentViewType == EViewType.eConnectionGuideView ){
				var tempSortText = self.filterView.getSecondOptionText(1);
				this.filterView.currentViewSortText = tempSortText[subIndex];
			}
			else{
				var mainView = Volt.require('app/views/main-view.js');
				this.filterView.currentViewSortText = mainView.headerView.optionParam.secondOptionText[subIndex];
			}
		}
		print("setGlobalSort "+this.filterView.lastViewSortText+" ==> "+this.filterView.currentViewSortText);
		this.filterView.lastViewSortText = this.filterView.currentViewSortText;
    },
	
    onTimeoutCB: function () {
        Volt.log('option-menu timeout');
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    onBtn1ClickCB: function (type) {
        Volt.log('click popup button1 , type is ' + type);
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    onBtn2ClickCB: function (type) {
        Volt.log('click popup button2 , type is ' + type);
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    onReturnCB: function (type) {
        Volt.log('click return in popup , type is ' + type);
        this.mediator.trigger('EVENT_MAIN_POPUP_HIDE', this.options);
    },

    clearOption: function () {
        Volt.log('MainPopupView , clearOption ');
		this.optionMenuSubIndex[0] = 0;
    },
    
    translate: function(){
        this.popup.setListText([resMgr.getText('TV_SID_LANGUAGE'),resMgr.getText('TV_SID_SORT_BY_NAME'), resMgr.getText('TV_SID_SORY_BY_ID'), resMgr.getText('TV_SID_VIEW_DETAIL'),resMgr.getText('UID_FAVORITES'),resMgr.getText('TV_RECOMMENDATION_TYPE'),resMgr.getText('TV_SID_BLOCK_ADULT_CONTENT'),resMgr.getText('TV_SID_TUTORIAL')]);
        this.popup.setSubListText(0,[resMgr.getText('TV_SID_ENGLISH'),resMgr.getText('TV_SID_WAVE_ENGLISH')]);
        this.popup.setSubListText(3,[resMgr.getText('TV_SID_POPULAR'),resMgr.getText('TV_SID_PREFERENCE')]);
        this.popup.setSubListText(4,[resMgr.getText('COM_SID_OFF'),resMgr.getText('COM_SID_ON')]);
    }
});

exports = MainPopupView;

