 /** 
 * @author  zhao rui (rui9527.zhao@samsung.com)		
 * 			
 * @fileoverview  All content view 
 * @date    2014/09/16 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
	var resMgr = Volt.require('app/controller/resource-controller.js');
	var BaseModel = Volt.require("app/models/base-model.js");
	var CommonInfo = Volt.require("app/common/define.js");
	var EItemType = CommonInfo.EItemType;
	var AllContentViewTemplate = Volt.require('app/templates/1080/all-view-template.js');
	var RunTimeInfo = Volt.require("app/common/run-time-info.js");
	var PanelCommon = Volt.require('lib/panel-common.js');
	var loadTemplate = PanelCommon.loadTemplate;
	var ViewGlobalData = Volt.require("app/views/view-global-data.js");
	var EventMediator = RunTimeInfo.EventMediator;
	var EventType = CommonInfo.EventType;
	var nativeGridlistFocus = CommonInfo.nativeGridlistFocus;
	var CONST = CommonInfo.CONST;
	var self = null;
	
/**
 * Render_View 
 * @param {int} parentWidth
 * @param {int} parentHeight
 * @param {Object} viewPointer 
 * @constructor
 * @extends {null}
 */
Render_View = function(parentWidth, parentHeight, viewPointer ) {
	self = viewPointer;
    var renderer = new Renderer(parentWidth, parentHeight);

	/** createRoot
	* @name createRoot	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {int} parentWidth
	* @param {int} parentHeight 
	* @param {boolean} dummyFlag  
	* @method 	 
	* */	
	renderer.createRoot = function( renderer, parentWidth, parentHeight, dummyFlag ){
		renderer.unique = null;
		renderer.root = new Widget(
		{
		   x:0,
		   y:0,
		   width:parentWidth,
		   height:parentHeight,
		   parent:scene,
		   color: {r:0, g:0, b:0, a:0}
		});
		if ( dummyFlag == true ){
	        var color1 = Volt.hexToRgb('#e8e8e8');
	        var color2 = Volt.hexToRgb('#ffffff');
			var color3 = Volt.hexToRgb('#f5f5f5');
	        renderer.root.gradient = {
	            tlColor : color1,
	            trColor : color3,
	            blColor : color3,
	            brColor : color2
	        };
		}
		
	};

	/** createChild
	* @name createChild	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data 
	* @method 	 
	* */	
	renderer.createChild = function( renderer, data ){
		if( data.ItemType == EItemType.eItemFolder ){
			
			var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		        imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder.png",
		        title1: data.title1,
		    };
			
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
			
		   	var textColor = {r: 255, g: 255, b: 255};
			if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
				{text:data.title1,
				textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
				textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
				textHorizontalAlignment:'center',
				scrollgap:20});

				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
		    var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_05.png",
				imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
		    };
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
		    
		   	var textColor = {r: 255, g: 255, b: 255};
		    if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
				{	text:data.title1,
					textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
					textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
					textHorizontalAlignment:'center',
					scrollgap:20}
				);

				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
	    }
		else if ( data.ItemType < EItemType.eItemFolder){
			var uhdFlagText = '';
			if( data.ItemType == EItemType.eItemVideo || data.ItemType == EItemType.eItemUHDVideo){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
				var contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_play.png';
				print('[Render view~~~~~~createChild~~~~~~~~]uhd :',data.uhd);
				if(data.ItemType == EItemType.eItemUHDVideo){
					var uhdicon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_uhd.png';
				}
			}
			else if( data.ItemType == EItemType.eItemPhoto){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_photo_n.png';
				var contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_camera.png';	
			}
			else if( data.ItemType == EItemType.eItemMusic){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_music_n.png';
				var contenticon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_music.png';	
			}
			else if(data.ItemType == EItemType.eItemPvr){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
			}
			
	        if( data.isThumbDone ){
	        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
		    }            
	        else{
	       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
	       	}

			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_thumb_notsupport.png';
			}
			
		    var mustache = {
		        imgUrl: data.ThumbPath,
				IconUrl: data.conIconPath,
		        title1: data.title1,
		        title2: data.title2,
		        unvailableIcon: data.unsupportIcon,
		        contenticon:contenticon,
		        uhdicon:uhdicon
		    };
		    loadTemplate(renderer.template.listItemNoFolder, mustache, renderer.root);

			var tepNum = renderer.textWidgetNumber;
			if(renderer.root.getChild(tepNum) != null){
				renderer.root.getChild(tepNum).color = {
					r : 24,
					g : 41,
					b : 61,
	            };
			}
			
			var itemType = self.collection.getItem(data.index).get('ItemType');
			print('[createChild] ~~~~~~~~~~~~~~~~~  itemType:',itemType);
			if(itemType == EItemType.eItemUHDVideo){
				renderer.root.getChild(5).src = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_uhd.png';
			}
			
			if(renderer.root.getChild(tepNum).getChild(0)!= null){
				var textColor = {
	                r : 255,
	                g : 255,
	                b : 255,
	                a : 153,
	            };
				renderer.root.getChild(tepNum).getChild(0).getUIElement().setTextContent(
						{text:data.title1,
						textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
						textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
						
						scrollgap:20});
				renderer.root.getChild(tepNum).getChild(0).getUIElement().setScrollRate(50);  
			}
		}
	};

	/** createChildofPhotoView
	* @name createChildofPhotoView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data 
	* @method 	 
	* */	
	renderer.createChildofPhotoView = function( renderer, data ){		
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup){
			var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		        imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder.png",
		        title1: data.title1,
		    };
			
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
			
		   	var textColor = {r: 255, g: 255, b: 255};
			if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
								{text:data.title1,
								textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
								textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
								textHorizontalAlignment:'center',
								scrollgap:20});
					//{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20,textHorizontalAlignment:'center'});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
		    var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_05.png",
				imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
		    };
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
		    
		   	var textColor = {r: 255, g: 255, b: 255};
		    if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
								{text:data.title1,
								textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
								textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
								textHorizontalAlignment:'center',
								scrollgap:20});
				//{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20,textHorizontalAlignment:'center'});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
	    }
		else{
		    data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_photo_n.png';
	        if( data.isThumbDone ){
	        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
		    }            
	        else{
	       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
	       	}

			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_thumb_notsupport.png';
			}
			var mustache = {
				imgUrl: data.ThumbPath,
				checkUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/mc_icon_selection_check.png",
				title1: data.title1,
				title2: data.title2,
				unvailableIcon: data.unsupportIcon,
			};
			loadTemplate(renderer.template.listItemNoFolder, mustache, renderer.root);
			var checkImg = renderer.root.getChild(3);
			if(checkImg != null){
				if(RunTimeInfo.isEditMode == true  ){
					var dataIndex = data.index;
					if(self.collection.addUpperFolderItemFlag == true){
						dataIndex = dataIndex -1;
					}
					if(self.getSelectState(dataIndex) == true){
						checkImg.opacity = 255*0.5;
					}
					checkImg.show();
				}
				else{
					checkImg.hide();
				}
			}
			
			if(renderer.root.getChild(1) != null){
				renderer.root.getChild(1).color = 
				{
					r : 24,
					g : 41,
					b : 61,
				};
			}
			if(renderer.root.getChild(1).getChild(0)!= null){
				var textColor = {
	                r : 255,
	                g : 255,
	                b : 255,
	                a : 153,
	            };
			  	renderer.root.getChild(1).getChild(0).getUIElement().setTextContent(
								{text:data.title1,
								textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
								textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
								
								scrollgap:20});
				//{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20});
				renderer.root.getChild(1).getChild(0).getUIElement().setScrollRate(50);  
			}
		}
	};

	/** createChildofVideoView
	* @name createChildofVideoView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data 
	* @method 	 
	* */	
	renderer.createChildofVideoView = function( renderer, data ){
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup ){
			
			var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_video_0"+(data.index%5+1)+".PNG",
		        imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_02.png",
		        title1: data.title1,
		    };
			
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
			
		   	var textColor = {r: 255, g: 255, b: 255};
			if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
						{text:data.title1,
						textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
						textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
						textHorizontalAlignment:'center',
						scrollgap:20});
				//{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20,textHorizontalAlignment:'center'});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
		    var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_video_05.PNG",
				imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
		    };
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
		    
		   	var textColor = {r: 255, g: 255, b: 255};
		    if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
						{text:data.title1,
						textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
						textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
						textHorizontalAlignment:'center',
						scrollgap:20});
				//	{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20,textHorizontalAlignment:'center'});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
	    }
		else{
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
	        if( data.isThumbDone ){
	        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
		    }            
	        else{
	       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 324, 288);
	       	}

			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_thumb_notsupport.png';
			}
			
			if(data.ItemType == EItemType.eItemUHDVideo){
					var uhdicon = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_uhd.png';
			}
			var mustache = {
				imgUrl: data.ThumbPath,
				checkUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/mc_icon_selection_check.png",
				title1: data.title1,
				title2: data.title2,
				unvailableIcon: data.unsupportIcon,
				uhdicon : uhdicon,
			};
			loadTemplate(renderer.template.listItemNoFolder, mustache, renderer.root);
			//self.itemWidget[index] = widget;
			if(renderer.root.getChild(4) != null){
				if(RunTimeInfo.isEditMode == true){
					var dataIndex = data.index;
					if(self.collection.addUpperFolderItemFlag == true){
						dataIndex = dataIndex -1;
					}
					if(self.getSelectState(dataIndex) == true){
						renderer.root.getChild(4).opacity = 255*0.5;
					}
					renderer.root.getChild(4).show();
				}
				else{
					renderer.root.getChild(4).hide();
				}
			}

			if(renderer.root.getChild(1) != null){
				renderer.root.getChild(1).color = 
				{
					r : 24,
					g : 41,
					b : 61,
				};
			}
			var itemType = self.collection.getItem(data.index).get('ItemType');
			print('[createChild] ~~~~~~~~~~~~~~~~~  itemType:',itemType);
			if(itemType == EItemType.eItemUHDVideo){
				renderer.root.getChild(6).src = resMgr.getImgPath()+'/Contents_icon/mc_icon_contents_uhd.png';
			}
			
			if(renderer.root.getChild(1).getChild(0)!= null){
				var textColor = {
	                r : 255,
	                g : 255,
	                b : 255,
	                a : 153,
	            };

				renderer.root.getChild(1).getChild(0).getUIElement().setTextContent(
						{text:data.title1,
						textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
						textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
						
						scrollgap:20});
				//{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20});
				renderer.root.getChild(1).getChild(0).getUIElement().setScrollRate(50);    
			}
			
		}
	};		

	/** createChildofMusicView
	* @name createChildofMusicView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data 
	* @method 	 
	* */	
	renderer.createChildofMusicView = function( renderer, data ){
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup ){
			
			var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		        imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder.png",
		        title1: data.title1,
		    };
			
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
			
		   	var textColor = {r: 255, g: 255, b: 255};
			if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
							{text:data.title1,
							textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
							textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
							textHorizontalAlignment:'center',
							scrollgap:20});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
		}	
	    else if( data.ItemType == EItemType.eItemUpFolder ){
		    var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_05.png",
				imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper.png",
		    };
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
		    
		   	var textColor = {r: 255, g: 255, b: 255};
		    if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
						{text:data.title1,
							textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
							textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
							textHorizontalAlignment:'center',
							scrollgap:20});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
	    }
		else{
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_music_n.png';
	        if( data.isThumbDone ){
	        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
		    }            
	        else{
	       		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 220, 288);
	       	}

			if(self.collection.getItem(data.index).get('isPlayAvailable')== false){
				data.unsupportIcon = Volt.BASE_PATH + resMgr.getImgPath()+'/Contents_icon/mc_icon_thumb_notsupport.png';
			}
			var mustache = {
				imgUrl: data.ThumbPath,
				checkUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/mc_icon_selection_check.png",
				title1: data.title1,
				title2: data.title2,
				unvailableIcon: data.unsupportIcon,
			};
			loadTemplate(renderer.template.listItemNoFolder, mustache, renderer.root);
			//this.itemWidget[index] = widget;
			var checkImg = renderer.root.getChild(3);
			if(checkImg != null){
				if(RunTimeInfo.isEditMode == true  ){
					var dataIndex = data.index;
					if(self.collection.addUpperFolderItemFlag == true){
						dataIndex = dataIndex -1;
					}
					if(self.getSelectState(dataIndex) == true){
						checkImg.opacity = 255*0.5;
					}
					checkImg.show();
				}
				else{
					checkImg.hide();
				}
			}

			if(renderer.root.getChild(1) != null){
				renderer.root.getChild(1).color = 
				{
					r : 24,
					g : 41,
					b : 61,
				};
			}
			if(renderer.root.getChild(1).getChild(0)!= null){
				var textColor = {
	                r : 255,
	                g : 255,
	                b : 255,
					a : 153,
	            };
			  	renderer.root.getChild(1).getChild(0).getUIElement().setTextContent(
							{text:data.title1,
							textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
							textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
							
							scrollgap:20});
					renderer.root.getChild(1).getChild(0).getUIElement().setScrollRate(50);  
			}
		}
	};

	/** createChildofRecordView
	* @name createChildofRecordView	 
	* @memberOf RenderView
	* @param {Object} renderer
	* @param {Object} data 
	* @method 	 
	* */	
	renderer.createChildofRecordView = function( renderer, data ){
		if( data.ItemType == EItemType.eItemFolder ||
			data.ItemType == EItemType.eItemGroup){
			var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_m_0"+(data.index%4+1)+".PNG",
		        imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder.png",
		        title1: data.title1,
		    };
			
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
			
		   	var textColor = {r: 255, g: 255, b: 255, a: 153};
			if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
								{text:data.title1,
								textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
								textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
								textHorizontalAlignment:'center',
								scrollgap:20});
				//{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20,textHorizontalAlignment:'center'});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
		}
	    else if( data.ItemType == EItemType.eItemUpFolder ){
		    var mustache = {
		        imgUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_img_foder_bg_video_05.PNG",
				imgUrlFolder:Volt.BASE_PATH + resMgr.getImgPath()+"/foders/mc_icon_foder_upper_02.png",
		    };
		    loadTemplate(renderer.template.listItemFolder, mustache, renderer.root);
		    
		   	var textColor = {r: 255, g: 255, b: 255};
		    if(renderer.root.getChild(1) !== null){
				renderer.root.getChild(1).getUIElement().setTextContent(
								{text:data.title1,
								textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
								textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
								textHorizontalAlignment:'center',
								scrollgap:20});
					//{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20,textHorizontalAlignment:'center'});
				renderer.root.getChild(1).getUIElement().setScrollRate(50); 
			}
	    }
		else{
			data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
			if( data.ItemType == EItemType.eItemPvr){
				data.ThumbPath = resMgr.getImgPath()+'/default_thumb/mc_icon_thumb_default_video_n.png';
		        if( data.isThumbDone ){
		        	data.ThumbPath = self.collection.getItem(data.index).get('ThumbPath');
			    }            
	            else{
					/*
	            	var jsonRequest = {
						str_uri: self.collection.getItem(data.index).get('filePath'),
					};
					var sendRes = VoltApi.PVR.sendThumbnailRequest(jsonRequest);
					print('result :', sendRes.str_result);*/
	           		self.collection.requestThumbnail(self.getCurrentSourceInt(), data.index, 324, 288);
	           	}
			}
			else{
				return renderer;
			}
			var mustache = {
				imgUrl: data.ThumbPath,
				checkUrl: Volt.BASE_PATH + resMgr.getImgPath()+"/CheckBox/mc_icon_selection_check.png",
				title1: data.title1,
				title2: data.title2,
				watchUrl: data.isWatched ? (Volt.BASE_PATH +resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_watching.png"):(Volt.BASE_PATH +resMgr.getImgPath()+"/Contents_icon/mc_icon_contents_not watched.png"),
			};
			
			loadTemplate(renderer.template.listItemNoFolder, mustache, renderer.root);

			var textColor = {r: 255, g: 255, b: 255};
			if(renderer.root.getChild(2) !== null && renderer.root.getChild(2).getChild(0) !== null){
				renderer.root.getChild(2).getChild(0).getUIElement().setTextContent(							
								{text:data.title1,
								textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
								textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
								textHorizontalAlignment:'center',
								scrollgap:20});
				//	{text:data.title1,textfont:"24px",textcolor:textColor,focusTextColor:textColor,scrollgap:20});
				renderer.root.getChild(2).getChild(0).getUIElement().setScrollRate(50); 
			}
			//this.itemWidget[index] = widget;
			if(renderer.root.getChild(4) != null){
				if(RunTimeInfo.isEditMode == true){
					var dataIndex = data.index;
					if(self.collection.addUpperFolderItemFlag == true){
						dataIndex = dataIndex -1;
					}
					if(self.getSelectState(dataIndex) == true){
						renderer.root.getChild(4).opacity = 255*0.5;
					}
					renderer.root.getChild(4).show();
				}
				else{
					renderer.root.getChild(4).hide();
				}
			}
		}
	};

	/** onDraw
	* @name onDraw	 
	* @memberOf RenderView
	* @param {Object} rend
	* @param {String} drawTypeString
	* @param {Object} data
	* @param {int} parentWidth
	* @param {int} parentHeight
	* @method 	 
	* */	
    renderer.onDraw = function(rend, drawTypeString, data, parentWidth, parentHeight){
	    //print('@@@@[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'onDraw    @@@@   drawTypeString  '+ drawTypeString );
		
		if( !data )
		{
		    print('[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'data is null    ' );
			return;
		}
		if ( data.dummyFlag == true ){
			return; 
		}
		var tepNum = rend.textWidgetNumber;
        if ("LoadData" == drawTypeString)
        {
        }
		else if ("UpdateData" == drawTypeString){
			
			var tempPath = self.collection.getItem(data.index).get('ThumbPath');
			print('------------------tempPath:',tempPath);
			rend.root.getChild(0).src = tempPath;
			if(rend.root.getChild(0) != null){
				var colorPicking = rend.root.getChild(0).getColorPicking(10);
				print("colorPicking:success 10" + colorPicking.success);
				print("colorPicking:color.r " + colorPicking.color.r);
				print("colorPicking:color.g " + colorPicking.color.g);
				print("colorPicking:color.b " + colorPicking.color.b);

				var red = colorPicking.color.r;
	            var green = colorPicking.color.g;
	            var blue = colorPicking.color.b;

				if(rend.root.getChild(tepNum) != null){
					rend.root.getChild(tepNum).color = {
	                    r : red,
	                    g : green,
	                    b : blue,
	                };
				}
				var utility = new Utility;
				var fontColor = utility.extractForegroundColor(red, green, blue);
				var titleWidget = null;
				var itemType = self.collection.getItem(data.index).get('ItemType');
				if((itemType !== EItemType.eItemFolder && itemType !== EItemType.eItemUpFolder)){
					var subWidget = rend.root.getChild(tepNum);
					titleWidget = subWidget.getChild(0);
					
				}
				else{
					titleWidget = rend.root.getChild(1);
				}
				var tempColor = {
	                    r : fontColor.color.r,
	                    g : fontColor.color.g,
	                    b : fontColor.color.b,
	            };			
				titleWidget.getUIElement().setTextContent(
						{text:data.title1,
						textfont:{normal:"24px",focus:"24px",slected:"24px",dim:"24px"},
						textcolor:{normal:tempColor,focus:tempColor,slected:tempColor,dim:tempColor},
						scrollgap:20});

			}
		}
		else if ( nativeGridlistFocus.NATIVEGRIDMOVETO == drawTypeString ){			
   			var newItem = self.collection.getItem(data.index);

   			if( rend !== undefined ){
				
   				var titleWidget = null;
   				
   				if((newItem.get('ItemType') !== EItemType.eItemFolder && 
   					 newItem.get('ItemType') !== EItemType.eItemUpFolder && 
   					 newItem.get('ItemType') !== EItemType.eItemGroup)){
   					var subWidget = rend.root.getChild(tepNum);
   					titleWidget = subWidget.getChild(0);
					var dataIndex = data.index;
					if(self.collection.addUpperFolderItemFlag == true){
						dataIndex = dataIndex -1;
					}
					if((RunTimeInfo.isEditMode == true) && (self.getSelectState(dataIndex) == true)){
						rend.root.getChild(rend.checkBoxIndex).opacity = 255;
						rend.root.getChild(rend.checkBoxIndex-1).opacity = 255*0.8;
					}
   				}
   				else{
   					titleWidget = rend.root.getChild(1);
   					
   				}
   				if(titleWidget !== null){
   					self.focusWidget = titleWidget.getUIElement();
   					titleWidget.getUIElement().getFocus();
   				
   				}	
   			}
		}
		else if ( nativeGridlistFocus.NATIVEGRIDMOVEFROM == drawTypeString ){
			
   			var newItem = self.collection.getItem(data.index);

   			if( rend !== undefined ){
   				var titleWidget = null;
   				
   				if((newItem.get('ItemType') !== EItemType.eItemFolder && 
   					newItem.get('ItemType') !== EItemType.eItemUpFolder && 
   					newItem.get('ItemType') !== EItemType.eItemGroup)){
   					var subWidget = rend.root.getChild(tepNum);
   					titleWidget = subWidget.getChild(0);
					var dataIndex = data.index;
					if(self.collection.addUpperFolderItemFlag == true){
						dataIndex = dataIndex -1;
					}
					if((RunTimeInfo.isEditMode == true) && (self.getSelectState(dataIndex) == true)){
						rend.root.getChild(rend.checkBoxIndex).opacity = 255*0.5;
						rend.root.getChild(rend.checkBoxIndex-1).opacity = 0;
					}
   				}
   				else{
   					titleWidget = rend.root.getChild(1);
   					
   				}
   				if(titleWidget !== null){
   					self.focusWidget = titleWidget.getUIElement();
   					titleWidget.getUIElement().loseFocus();
   				
   				}	
   				   					

   			}
		}
		else if ( 'FormItemFocusChangeAniEnd' == drawTypeString ){
			if( rend !== undefined ){
				var newItem = self.collection.getItem(data.index);
   				if( newItem.get('ItemType') == EItemType.eItemFolder ){
					var param = {
						index : data.index,
						rend : rend
					}
					rend.unique = Volt.setInterval(changeRenderImg, 105, param);
				}
			}
		}
		else if ( 'ToItemFocusChangeAniEnd' == drawTypeString ){
			if( rend !== undefined ){
				var newItem = self.collection.getItem(data.index);
   				if( newItem.get('ItemType') == EItemType.eItemFolder ){
   					rend.root.getChild(2).src = resMgr.getImgPath()+'/foders/mc_icon_foder_zoom.png';
					//print('all-content-view.js, Focus in:', data.index);
   				}	
			}
		}
	};

	/** onRelease
	* @name onRelease	 
	* @memberOf RenderView
	* @param { }    
	* @method 	 
	* */	
    renderer.onRelease = function() {
	    print('@@@@[' + Volt.__file__ + '] [' + Volt.__func__ + '] [:' + Volt.__line__ + '] ' + 'onRelease    @@@@' );
		if ( renderer.unique != null ){
			Volt.clearInterval(renderer.unique);
			renderer.unique = null;
		}
		renderer.root.destroy();
        delete renderer;
		renderer = null;
    };

	return renderer;
}

/** changeRenderImg
* @name changeRenderImg	 
* @memberOf RenderView
* @param { param }    param
* @method 	 
* */	
function changeRenderImg(param){
	self.changeRenderImg(param);
};

exports = Render_View;
