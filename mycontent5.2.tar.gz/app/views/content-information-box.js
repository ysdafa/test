/** 
 * @author mycontents engineer
 * @fileoverview Content-information-view.js
 * @date 2014/07/24
 * 
 * @version 1.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 * 
 * @note: Volt 2.0 maybe draw children according to index sequence
 */

var resMgr = Volt.require('app/controller/resource-controller.js');
// Require Common Modules
var PanelCommon = Volt.require('lib/panel-common.js');
var _ = Volt.require("modules/underscore.js")._;
var BaseView = Volt.BaseView;
  
// Require Specific template for mycontents Main View
var InfoWindowTemplate = Volt.require('app/templates/1080/content-information-box-template.js');

var CommonInfo = Volt.require('app/common/define.js');
var EventType = CommonInfo.EventType;
var EViewType = CommonInfo.EViewType;
//Require Run Time Modules
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var self = null;

var voiceGuide = Volt.require('app/common/voice-guide.js');

/**when  press Info key  on content item ,show it
 * @class
 * @name InfoWindow 
 * @augments PanelCommon.BaseView
 */
var InfoWindow = PanelCommon.BaseView.extend({
    popupWidget: null,        // Store popup widget
    template: null,
    parent: null,
	btn1: null,
	timer: null,
	timerOut: 0,
	timeFunc: null,
	btnListener: null,

	contentTitle: '',
	contentCreateTime: '',
	contentFormat: '',
	contentSize: '',
	contentResolution: '',
	contentLocation: '',

	contentDuration: '',
	contentSavedData: '',
	contentChannel: '',
	contentHDSD: '',
	contentGenre: '',	
	contentArtist:'',
	contentAlbum:'',


	saveTimeHeader: null,
	saveTimeDetail: null,
	formatHeader: null,
	formatDetail: null,
	sizeHeader: null,
	sizeDetail: null,
	locHeader: null,
	locDetail: null,

	itemNum: 6,

	destroyCb:null,
	
    /**Initialize InfoWindow 
     * @name initialize
     * @memberOf InfoWindow
     * @constructs 
     */
    initialize: function() {
        // Get mediator from MainView
        self = this;
		var mainView = Volt.require('app/views/main-view.js');
		self.parent = mainView.widget.getChild('main-popup-container');
		EventMediator.on(EventType.EVENT_HIDE_INFORMATION, self.hide, this);
    },
	setDestroyCb:function(cb){

		self.destroyCb = cb;
	},
    /**Render InfoWindow
     * @name render
     * @memberOf InfoWindow
     * @param {enum}  templateType of InfoWindow
     * @method
     */
    render: function(templateType, type){
		print('content-infomation-box.js templateType:',templateType);
		
		//if(RunTimeInfo.router && RunTimeInfo.router.currentViewType != EViewType.eMusicPlayerView){
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		//}
		var voiceText = "";
		
        // Load template
        if(templateType == InfoWindowTemplate.info_window_template_photo){
		    var mustache = {
		        title: self.contentTitle,
		        created: ''+ self.contentCreateTime,
		        format: ''+ self.contentFormat,
		        size:''+ self.contentSize,
		        resolution:''+ self.contentResolution,
		        location: self.contentLocation,
		    };
			voiceText = resMgr.getText('COM_TEXT_INFORMATION_P')+', '
					+ resMgr.getText('TV_SID_TITLE_COLON')+', '
					+ self.contentTitle +', '
					+ resMgr.getText('TV_SID_CREATED_COLON')+', '
					+ self.contentCreateTime + ','
					+ resMgr.getText('TV_SID_FORMAT_COLON') + ','
					+ self.contentFormat + ', '
					+ resMgr.getText('TV_SID_SIZE_COLON') + ', '
					+ self.contentSize+', '
					+ resMgr.getText('TV_SID_RESOLUTION') + ', '
					+ self.contentResolution + ', '
					+ resMgr.getText('TV_SID_LOCATION') + ', '
					+ self.contentLocation + ', '
					+ resMgr.getText('COM_SID_OK')+', '
					+ resMgr.getText('TV_SID_BUTTON');
    	}
		else if(templateType == InfoWindowTemplate.info_window_template_video){
		    var mustache = {
		        title: self.contentTitle,
				duration: ''+ self.contentDuration,
		        savedData: ''+ self.contentSavedData,
		        format: ''+ self.contentFormat,
		        size:''+ self.contentSize,
		        resolution:''+ self.contentResolution,
		        location: self.contentLocation,
		    };

			voiceText = resMgr.getText('COM_TEXT_INFORMATION_P')+', '
					+ resMgr.getText('TV_SID_TITLE_COLON')+', '
					+ self.contentTitle +', '
					+ resMgr.getText('IDWS_MOIP_DURATION_KR_BLANK')+', '
					+ self.contentDuration + ','
					+ resMgr.getText('TV_SID_LAST_SAVED')+ ', '
					+ self.contentSavedData + ', '
					+ resMgr.getText('TV_SID_FORMAT_COLON') + ', '
					+ self.contentFormat + ', '
					+ resMgr.getText('TV_SID_SIZE_COLON') + ', '
					+ self.contentSize+', '
					+ resMgr.getText('TV_SID_RESOLUTION') + ', '
					+ self.contentResolution + ', '
					+ resMgr.getText('TV_SID_LOCATION') + ', '
					+ self.contentLocation + ', '
					+ resMgr.getText('COM_SID_OK')+', '
					+ resMgr.getText('TV_SID_BUTTON');
		}else if(templateType == InfoWindowTemplate.info_window_template_uhd_video){
		    var mustache = {
		        title: self.contentTitle,
				duration: ''+ self.contentDuration,
		       	genre: ''+self.contentGenre,
		        format: ''+ self.contentFormat,
		        size:''+ self.contentSize,
		        resolution:''+ self.contentResolution,
		        location: self.contentLocation,
		    };

			voiceText = resMgr.getText('COM_TEXT_INFORMATION_P')+', '
					+ resMgr.getText('TV_SID_TITLE_COLON')+', '
					+ self.contentTitle +', '
					+ resMgr.getText('IDWS_MOIP_DURATION_KR_BLANK')+', '
					+ self.contentDuration + ','
					+ resMgr.getText('TV_SID_LAST_SAVED')+ ', '
					+ self.contentSavedData + ', '
					+ resMgr.getText('TV_SID_FORMAT_COLON') + ', '
					+ self.contentFormat + ', '
					+ resMgr.getText('TV_SID_SIZE_COLON') + ', '
					+ self.contentSize+', '
					+ resMgr.getText('TV_SID_RESOLUTION') + ', '
					+ self.contentResolution + ', '
					+ resMgr.getText('TV_SID_LOCATION') + ', '
					+ self.contentLocation + ', '
					+ resMgr.getText('COM_SID_OK')+', '
					+ resMgr.getText('TV_SID_BUTTON');
		}
		
		else if(templateType == InfoWindowTemplate.info_window_template_music){
			print("render info_window_template_music  type: "+ type);
			Log.e("render info_window_template_music  type: "+ type);
			if(type == 'music-player'){
	 			self.parent = scene;
			}
		    var mustache = {
		        title: self.contentTitle,
				artist: ''+self.contentArtist,
				album: ''+self.contentAlbum,
				genre: ''+self.contentGenre,
				duration: ''+ self.contentDuration,
		        savedData: ''+ self.contentSavedData,
		        format: '' + self.contentFormat,
		        size: ''+ self.contentSize,
		        location: self.contentLocation,
		    };


			voiceText = resMgr.getText('COM_TEXT_INFORMATION_P')+', '
					+ resMgr.getText('TV_SID_TITLE_COLON')+', '
					+ self.contentTitle +', '
					+ resMgr.getText('IDWS_MOIP_DURATION_KR_BLANK')+', '
					+ self.contentDuration + ','
					+ resMgr.getText('TV_SID_LAST_SAVED')+ ', '
					+ self.contentSavedData + ', '
					+ resMgr.getText('TV_SID_FORMAT_COLON') + ','
					+ self.contentFormat + ', '
					+ resMgr.getText('TV_SID_SIZE_COLON') + ', '
					+ self.contentSize+', '		
					+ resMgr.getText('TV_SID_LOCATION') + ', '
					+ self.contentLocation + ', '
					+ resMgr.getText('COM_SID_OK')+', '
					+ resMgr.getText('TV_SID_BUTTON');
		}
	
		else if(templateType == InfoWindowTemplate.info_window_template_record){
		    var mustache = {
		        title: self.contentTitle,
				channel: ''+self.contentChannel,
		        savedData: ''+ self.contentSavedData,
		        HDSD: ''+self.contentHDSD,
		        size:''+ self.contentSize,
		        location:self.contentLocation,
		    };

			voiceText = resMgr.getText('COM_TEXT_INFORMATION_P')+', '
					+ resMgr.getText('TV_SID_TITLE_COLON')+', '
					+ self.contentTitle +', '
					+ resMgr.getText('TV_SID_CHANNEL_COLON_BLANK')+', '
					+ self.contentChannel + ','
					+ resMgr.getText('TV_SID_LAST_SAVED')+ ', '
					+ self.contentSavedData + ', '
					+ resMgr.getText('TV_SID_QUALITY') + ','
					+ self.contentHDSD + ', '
					+ resMgr.getText('TV_SID_SIZE_COLON') + ', '
					+ self.contentSize+', '
					+ resMgr.getText('TV_SID_LOCATION') + ', '
					+ self.contentLocation + ', '
					+ resMgr.getText('COM_SID_OK')+', '
					+ resMgr.getText('TV_SID_BUTTON');
    	}

		voiceGuide.play(voiceText);
		
		
        self.template = templateType;
		self.timerOut = 60000;
		try{
	        self.popupWidget = PanelCommon.loadTemplate(self.template,mustache,self.parent);
		}catch(e){
			print("load InfoWindowTemplate e:"+e);
		}
		//self.popupWidget.parent = self.parent;
		self.renderButton();
		this.setWidget(self.popupWidget);
		Volt.Nav.setRoot(this.widget);
		if(templateType == InfoWindowTemplate.info_window_template_music){
		//	self.replaceMusicInfo();
		}		
		//self.popupWidget.onKeyEvent = self.onKeyEvent;
		self.setDefaultFocus();
		self.timer = Volt.setTimeout(self.timeFunc, self.timerOut);		
        //Volt.Nav.beginModal(self.popupWidget);
		
        return this;
    },

	replaceMusicInfo: function(){
		self.saveTimeHeader = self.widget.getChild(10);
		self.saveTimeDetail = self.widget.getChild(11);
		self.formatHeader = self.widget.getChild(12);
		self.formatDetail = self.widget.getChild(13);
		self.sizeHeader = self.widget.getChild(14);
		self.sizeDetail = self.widget.getChild(15);
		self.locHeader = self.widget.getChild(16);
		self.locDetail = self.widget.getChild(17);		
		if( self.saveTimeHeader==null ||
			self.saveTimeDetail==null ||
			self.formatHeader==null ||
			self.formatDetail==null ||
			self.sizeHeader==null ||
			self.sizeDetail==null ||
			self.locHeader==null ||
			self.locDetail==null){
			Log.f("the GUI element is not enough!!");
		}
		Log.f("self.contentSavedData = "+self.contentSavedData+"self.contentFormat="+self.contentFormat+"self.contentSize="+self.contentSize+"self.contentLocation"+self.contentLocation);
		if( self.contentSavedData=='..'){
			self.itemNum--;
			self.saveTimeHeader.opacity = 0;
			self.saveTimeDetail.opacity = 0;
		}
		if( self.contentFormat==''){
			self.itemNum--;
			self.formatHeader.opacity = 0;
			self.formatDetail.opacity = 0;				
		}
		else if( self.itemNum==5 ){
			self.formatHeader.y = self.formatHeader.y-48;
			self.formatDetail.y = self.formatDetail.y-48;
		}
		if( self.contentSize=='0'||self.contentSize=='0.0KB'){
			self.itemNum--;
			self.sizeHeader.opacity = 0;
			self.sizeDetail.opacity = 0;				
		}	
		else if( self.itemNum<=5 ){
			self.sizeHeader.y = self.sizeHeader.y-48*(6-self.itemNum);
			self.sizeDetail.y = self.sizeDetail.y-48*(6-self.itemNum);
		}	
		if( self.contentLocation==''){
			self.itemNum--;
			self.locHeader.opacity = 0;
			self.locDetail.opacity = 0;					
		}
		else if( self.itemNum<=4 ){
			self.locHeader.y = self.locHeader.y-48*(6-self.itemNum);
			self.locDetail.y = self.locDetail.y-48*(6-self.itemNum);
		}	
		self.btn1.setPosition(self.btn1.x, self.btn1.y-48*(6-self.itemNum));
		
		self.widget.height = 579-(6-self.itemNum)*48;			
		self.widget.y = (1080-self.widget.height)/2;
		Log.f("self.widget.height = "+self.widget.height+"self.widget.y "+self.widget.y);
		self.widget.show();
    },

	/**render Button in InfoWindow
     * @name renderButton
     * @memberOf InfoWindow
     * @method
     * @return {}
     */
	renderButton: function(){
		var btnWidget1 = self.popupWidget.getChild('common-message-box-btn1');
		if(btnWidget1 != null){
			self.btn1 = btnWidget1;
			self.btn1.setText({state: "all", text: resMgr.getText('COM_SID_OK'),});
			self.btn1.setTextColor({state: "all", color: { r:0x46, g:0x46, b:0x46,a:0xff },});
			self.btn1.setFontSize({state: "normal", size: 32,});
			self.btn1.setFontSize({state: "focused", size: 36,});
			self.btn1.setFontSize({state: "selected", size: 36,});
			self.btn1.setFontSize({state: "focused-roll-over", size: 36,});
			self.btn1.setBackgroundColor({state: "all", color: { r:255, g:255, b:255, a: 255*0.95 },});
	
			self.btn1.setBackgroundImage({state: "focused",
								             src: resMgr.getImgPath()+'/button/btn_style_c_f.png',});
    		self.btn1.setBackgroundImage({state: "normal", 
								             src: resMgr.getImgPath()+'/button/btn_style_c_n.png',});
			var buttonListener = new ButtonListener;
			self.btnListener = buttonListener;
			self.btn1.addListener(buttonListener);
			buttonListener.onButtonClicked = function (button, type){
				print('----buttonListener type = ',type);
				//self.onBtnCallBack();
				Volt.setTimeout(self.onBtnCallBack, 1);
			};
			//self.btn1.callback = self.onBtnCallBack;
			self.btn1.show();
		}
		
    },

	onBtnCallBack: function(){
		self.hide();
    },
    
    /**render setcontentTitle in InfoWindow
     * @name setcontentTitle
     * @memberOf InfoWindow
     * @param {String} contentTitle
     * @method
     * @return {}
     */
	setcontentTitle: function(contentTitle){
		print('[content-information-box.js]setcontentTitle():'+ contentTitle);
		if(contentTitle != null){
			self.contentTitle = contentTitle;
		}else{
			self.contentTitle = '-';
		}
    },
    
    setcontentArtist:function(contentArtist){
		print('[content-information-box.js]setcontentArtist():'+ contentArtist);
		if(contentArtist != null){
			self.contentArtist = contentArtist;
		}else{
			self.contentArtist = '-';
		}
	},
	setcontentAlbum:function(contentAlbum){
		print('[content-information-box.js]setcontentAlbum():'+ contentAlbum);
		if(contentAlbum != null){
			self.contentAlbum = contentAlbum;
		}else{
			self.contentAlbum = '-';
		}
	},

    /**render setcontentCreateTime in InfoWindow
     * @name setcontentCreateTime
     * @memberOf InfoWindow
     * @param {String} contentTitle
     * @method
     * @return {}
     */

	setcontentCreateTime: function(contentCreateTime){
		print('[content-information-box.js]setcontentAuthor():'+ contentCreateTime);
		if(contentCreateTime != null){
			if(typeof(contentCreateTime)== "number" ){
				self.contentCreateTime = self.getDateString(contentCreateTime);
			}
			else if(typeof(contentCreateTime) == "string"){
				self.contentCreateTime = contentCreateTime.substr(0,4)+ '.'+ contentCreateTime.substr(5,2) +'.' + contentCreateTime.substr(8,2);
			}

		}else{
			self.contentCreateTime = '-';
		}
			
    },
    
    /**render setcontentFormat in InfoWindow
     * @name setcontentFormat
     * @memberOf InfoWindow
     * @param {String} contentFormat
     * @method
     * @return {}
     */
	setcontentFormat: function(contentFormat){
		print('[content-information-box.js]setcontentFormat():'+ contentFormat);
		if(contentFormat != null){
		//	var fromPos = contentFormat.indexOf('/', 0); 
		//	var format = contentFormat.substring(fromPos+1); 
		//	self.contentFormat = format.toUpperCase();
			self.contentFormat = contentFormat;
		}else{
			self.contentFormat = '-';
		}
	
    },
    
    /**render setcontentSize in InfoWindow
     * @name setcontentSize
     * @memberOf InfoWindow
     * @param {String} contentSize
     * @method
     * @return {}
     */
	setcontentSize: function(contentSize){
		print('[content-information-box.js]setcontentSize():'+ contentSize);
		if(contentSize != null && contentSize != '' || contentSize != undefined){
			if( contentSize == '' || contentSize == 0 ){
				self.contentSize = 0;
			}
			self.contentSize = self.convertSizeToText(contentSize);
		}else{
			self.contentSize = '-';
		}
    },
	/**render setcontentResolution in InfoWindow
     * @name setcontentResolution
     * @memberOf InfoWindow
     * @param {String} contentResolution
     * @method
     * @return {}
     */
	setcontentResolution: function(contentResolution){
		print('[content-information-box.js]setcontentResolution():'+ contentResolution);
		if(contentResolution != null){
			self.contentResolution = contentResolution;
		}else{
			self.contentResolution = '-';
		}
    },
    /**render setcontentResolution in InfoWindow
     * @name setcontentResolution
     * @memberOf InfoWindow
     * @param {String} contentResolution
     * @method
     * @return {}
     */
    setcontentLocation: function(contentLocation){
		print('[content-information-box.js]setcontentLocation():'+ contentLocation);
		if(contentLocation != null){
			var temp = '/';
			self.contentLocation = self.replaceAll(contentLocation, '/', '>');
		}else{
			self.contentLocation = '-';
		}
    },
    /**render setcontentDuration in InfoWindow
     * @name setcontentDuration
     * @memberOf InfoWindow
     * @param {String} contentResolution
     * @method
     * @return {}
     */

	setcontentDuration: function(contentDuration,isUhd){
		print('[content-information-box.js]setcontentDuration():'+ contentDuration);
		if(contentDuration >0){
			self.contentDuration = self.getTimeString(contentDuration,isUhd);
		}else{
			self.contentDuration = '-';
		}
    },
    /**render setcontentSavedData in InfoWindow
     * @name setcontentSavedData
     * @memberOf InfoWindow
     * @param {String} contentSavedData
     * @method
     * @return {}
     */
    setcontentSavedData: function(contentSavedData){
		print('[content-information-box.js]setcontentSavedData():'+ contentSavedData);
		if(contentSavedData != null){
			if(typeof(contentSavedData)== "number" ){
				self.contentSavedData = self.getDateString(contentSavedData);
			}
			else if(typeof(contentSavedData) == "string"){
				self.contentSavedData = contentSavedData.substr(0,4)+ '.'+ contentSavedData.substr(5,2) +'.' + contentSavedData.substr(8,2);
			}
		}else{
			self.contentSavedData = '-';
		}
    },
    /**render setcontentChannel in InfoWindow
     * @name setcontentChannel
     * @memberOf InfoWindow
     * @param {String} contentChannel
     * @method
     * @return {}
     */
    setcontentChannel: function(contentChannel){
		print('[content-information-box.js]setcontentChannel():'+ contentChannel);
		if(contentChannel != null){
			self.contentChannel = contentChannel;
		}
    },
    /**render setcontentHDSD in InfoWindow
     * @name setcontentHDSD
     * @memberOf InfoWindow
     * @param {String} contentHDSD
     * @method
     * @return {}
     */
    setcontentHDSD: function(contentHDSD){
		print('[content-information-box.js]setcontentHDSD():'+ contentHDSD);
		if(contentHDSD != null){
			self.contentHDSD = contentHDSD;
		}
    },
    /**render setcontentGenre in InfoWindow
     * @name setcontentGenre
     * @memberOf InfoWindow
     * @param {String} contentGenre
     * @method
     * @return {}
     */
    setcontentGenre: function(contentGenre){
		print('[content-information-box.js]setcontentGenre():'+ contentGenre);
		if(contentGenre != null){
			self.contentGenre = contentGenre;
		}else{
			self.contentGenre = '-';
		}
    },
    
    /** setDefaultFocus InfoWindow 	 
	* @name setDefaultFocus	 
	* @memberOf InfoWindow
	* @method
	* @return {} 	 
	* */
	setDefaultFocus: function(){
		if(self.btn1 != null){
			self.btn1.setFocus();
		}
    },

	
    
    /** hide InfoWindow 	 
	* @name hide	 
	* @memberOf InfoWindow
	* @method
	* @return {} 	 
	* */
    hide : function(){
    	print('[content-information-box.js] hide111111');
		if(self.popupWidget == null){
			print('[content-information-box.js]popupWidget is NULL!');
			Log.e("[content-information-box.js]popupWidget is NULL! return ");
			return;
		}	
		//Volt.Nav.endModal(self.popupWidget);
		self.popupWidget.hide();
		//EventMediator.off(EventType.EVENT_HIDE_INFORMATION, self.hide, this);
		self.destroy();
		print(" information popup hide, undim main view ");
		Log.e(" information popup hide, undim main view ");
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
    },

	/** destroy InfoWindow 	 
	* @name destroy	 
	* @memberOf InfoWindow
	* @method
	* @return {} 	 
	* */
	destroy : function(){		
		print("  information popup destroy,  ");
		if(self.destroyCb != null && self.destroyCb != undefined){
			self.destroyCb();	
		}
		self.destroyCb = null;
		
		if(!self.popupWidget){
			return;
		}
		if( self.timer!= null ){
			Volt.clearTimeout(self.timer);
			self.timer = null;
		}	
		if(self.btn1 != null){
			//self.btn1.destroy();
			self.btn1.killFocus();
			self.btn1.removeListener(self.btnListener);
			//HALOUtil.asyncRelease(self.btn1);
			self.btn1 = null;
		}
		if(self.popupWidget != null){
			self.popupWidget.destroy();
			//HALOUtil.asyncRelease(self.popupWidget);
			self.popupWidget = null;
		}
		
		if(RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView){
			if( typeof RunTimeInfo.router.currentView.setListFocusNearestOrNot == 'function'){
				RunTimeInfo.router.currentView.setListFocusNearestOrNot(false);
			}
			Volt.Nav.setRoot(RunTimeInfo.router.currentView.widget,RunTimeInfo.router.currentView.preFocus);
			if( RunTimeInfo.router.currentView.preFocus && RunTimeInfo.router.currentView.preFocus.id == "playList" ){
				Volt.Nav.focus(RunTimeInfo.router.currentView.preFocus);
			}
		}else{
			var mainView = Volt.require('app/views/main-view.js');
			Volt.Nav.setRoot(mainView.widget, {focus: RunTimeInfo.router.currentView.nativeGridList}); 
		}
	},

	/** process timeout event  	 
	* @name timeFunc	 
	* @memberOf InfoWindow
	* @method 
	* @return {}	 
	* */
	timeFunc : function()
    {
    	print('get in the timeFunc');
		self.hide();
    },

	/** process key event  	 
	* @name onKeyEvent	 
	* @memberOf InfoWindow
	* @param {enum}  KeyCode
	* @param {enum}  type
	* @method
	* @return {boolean} 	 
	* */
	onKeyEvent: function(KeyCode,type){
		print('[content-information-box.js] onKeyEvent()');
		var ret = true;
		
		if (type != Volt.EVENT_KEY_RELEASE)
		{
			return false;
		}

		switch(KeyCode){
			case Volt.KEY_RETURN:
			{
				Volt.setTimeout(self.onBtnCallBack, 1);
				break;
			}
			default:
				ret = false;
				break;
		}
		
		return ret;
	},

	/**convert number size to text
	* @name convertSizeToText	 
	* @memberOf InfoWindow
	* @method
	* @return {int} 	 
	* */	
	convertSizeToText: function(size){
		var textSize = '';
		if((size/(1024*1024)) < 1){
			var totalSize = size/1024;
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'KB';
		}
		else if((size/(1024*1024*1024)) < 1){
			var totalSize = size/(1024*1024);
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'MB';
		}
		else if((size/(1024*1024*1024*1024)) < 1){
			var totalSize = size/(1024*1024*1024);
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'GB';
		}
		else{
			var totalSize = size/(1024*1024*1024*1024);
			totalSize = totalSize.toFixed(1);
			textSize = totalSize.toString() + 'TB';
		}
		return textSize;
    },

	/**convert time to string
	* @name getTimeString	 
	* @memberOf InfoWindow
	* @method
	* @return {String} 	 
	* */	
	getTimeString: function(duration, isUhd) {
		if(isUhd == true){
			var secondStyle = duration;
		}else{
			var secondStyle = duration / 1000;
		}
		var hh = parseInt(secondStyle/3600);
		var mm = parseInt(secondStyle%3600 / 60);
		var ss = parseInt(secondStyle%60);
		
		var sec = ss > 9 ? ss : '0'+ss;
		var min = mm > 9 ? mm : '0'+mm;

		var res = hh == 0 ? min+':'+sec : hh+':'+min+':'+sec;
		return res;
	},

	/**convert date to string
	* @name getDateString	 
	* @memberOf InfoWindow
	* @method 	 
	* */	
	getDateString: function (date) {
		print('[content-information-box.js] getDateString():'+ date);
		if(date == null){
			return '';
		}
		var newDate = new Date(date*1000);

		var t_dd = newDate.getDate();
		var t_mm = newDate.getMonth()+1; 
		var t_yyyy = newDate.getFullYear();

		if(t_dd < 10){
				t_dd= '0'+ t_dd;
		}
		if(t_mm < 10){
				t_mm= '0'+ t_mm;
		}
		var strDate = t_yyyy + '.' + t_mm + '.' + t_dd;
		return strDate;
		//return '2014.09.13';
	},

	replaceAll: function(s,s1,s2){
		if(s == null){
			return '';
		}
	    return s.replace(new RegExp(s1,"gm"),s2);   
	}
});



exports = InfoWindow;






