 /** 
 * @author  Xiaoming Chen (xiaom.chen@samsung.com)
 * 			
 * @fileoverview  MyContent edit mode view
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js'); 
var PanelCommon = Volt.require('lib/panel-common.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var loadTemplate = PanelCommon.loadTemplate;
var MainTemplate = PanelCommon.requireTemplate('main');
var EventMediator = RunTimeInfo.EventMediator;
var CommonInfo = Volt.require('app/common/define.js');
var CONST = CommonInfo.CONST;
var EventType = CommonInfo.EventType;
var EViewType = CommonInfo.EViewType;
var EOptType = CommonInfo.EOptType;
var KeyCode = CommonInfo.KeyCode;
var FocusPos = CommonInfo.FocusPos;

var EditModeViewTemplate = Volt.require('app/templates/1080/editmode-view-template.js');
var DeviceProvider = Volt.require("app/models/device-provider.js");
var selAllCheckIconNor = resMgr.getImgPath()+'/CheckBox/btn_icon_ms_selectall_nor.png';
var selAllCheckIconFocus = resMgr.getImgPath()+'/CheckBox/btn_icon_ms_selectall_fou.png';
var selAllCheckBoxIconNor = resMgr.getImgPath()+'/CheckBox/btn_icon_ms_selectall_nor_box.png';
var selAllCheckBoxIconFocus = resMgr.getImgPath()+'/CheckBox/btn_icon_ms_selectall_fou_box.png';
var voiceGuide = Volt.require('app/common/voice-guide.js');	
var DeviceSelectorView = Volt.require('app/views/device-selector-view.js');
var mainView = Volt.require('app/views/main-view.js');
var self = null;

var normalArrow = resMgr.getImgPath()+'/Arrow/popup_dropdown_arrow_n.png';
var selectArrow = resMgr.getImgPath()+'/Arrow/popup_dropdown_arrow_s.png';
/**
 * Mycontent edit mode view class, it will create 
 * @param {Object} Main view calss proterties
 * @param 
 * @constructor
 * @extends {BaseView}
 */
var EditModeView = PanelCommon.BaseView.extend({
    template: EditModeViewTemplate.container,
    selectAllFlag : false,
    optType: EOptType.eNoneType,
	selAllBtn: null,
	optionBtn: null,
	cancelBtn: null,
	deviceBtn: null,
	deviceSelector: null,
	selWidget: null,
	isFocusEditMode: false,
	isFirstFocusDeviceSelect:true,
	deviceSelectable: true,
	isFocusDevSelector: false,
	tempV: 0,

	cancelBtnDim: false,
	selectorBtnDim: false,
	deviceBtnDim :false,
	operationBtnDim : false,
	selectAllBtnDim: false,
	
	/** Initialize EditModeView  	 
	* @name initialize	 
	* @memberOf EditModeView
	* @method 	 
	* */	
    initialize: function(parentView) {
        this.mainView = parentView;
        this.mainView.editModeView = this;
		DeviceProvider.regsiterListener(this,this.onDeviceConnect,this.onDeviceDisconnect);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_DEVSELECTOR_POPUP, this.hideDeviceSelector, this);
		self = this;
    },

	/** render edit mode view  	 
	* @name render	 
	* @memberOf EditModeView
	* @method 	 
	* */	
    render: function() {
        print('[edit-mode-view..js] EditModeView');
		var selectText = resMgr.getText('COM_TV_SID_SELECTED_ITEMS');
		
		print('selectText:',selectText.length);
		var tempLen = selectText.length;
		if ( tempLen < 14 ){
			tempLen = 14;
		}
		tempLen = (tempLen/14)*180;
		this.tempV = (tempLen-180);
		if(this.tempV > 0){
			this.tempV = this.tempV + 3;
		}
		var mustache = {
					itemText: resMgr.getText('COM_TV_SID_SELECTED_ITEMS') + ':',
					numText: '0',
					selectText: resMgr.getText('COM_SID_SELECT_ALL'),
					delText: resMgr.getText('COM_SID_DELETE'),
					cancelText: resMgr.getText('COM_SID_CANCEL'),
					devName: self.mainView.categoryView.getCurrentCategoryName(),
				};		
		var contentWidget = loadTemplate(this.template,mustache);
		var textWidget = contentWidget.getChild(0);

		textWidget.custom.multilingual.SID = 'COM_TV_SID_SELECTED_ITEMS';
		textWidget.custom.multilingual.PLUS = ':';
		//var arrow = contentWidget.getChild('arrow_image');
		//arrow.src = resMgr.getImgPath()+'/Arrow/mc_ms_arrow_down_n.PNG';
		this.setWidget(contentWidget);
		
		textWidget.width = tempLen;
		var numTextWidget = contentWidget.getChild(1);
		if(numTextWidget != null){
			numTextWidget.x = 600+this.tempV;
		}
		
		this.renderButton();	
        return this;
    },

	/** render button  	 
	* @name renderButton	 
	* @memberOf EditModeView
	* @method 	 
	* */	
	renderButton: function() {
		print('------------edit-mode-view.js,renderButton()');
		self.selAllBtn = this.widget.getChild('select_all_id').getChild('select_all_btn');
		self.optionBtn = this.widget.getChild('operation_id').getChild('operation_btn');
		self.cancelBtn = this.widget.getChild('cancel_id').getChild('cancel_btn');
		self.deviceBtn = this.widget.getChild('cur_dev_name_id').getChild('selector_btn');

		var buttonListener = new ButtonListener;
		buttonListener.onButtonClicked = function (button, type){
			print('----edit-mode-view.js buttonListener type = ',type);
			print('----edit-mode-view.js buttonListener button.id = ',button.id);
			if(button.custom.focusable != true){
			//	return;
			}
			
			if(button.id == 'select_all_btn'){
				print("self.selectAllBtnDim:"+self.selectAllBtnDim);
				if(self.selectAllBtnDim == true){
					
					return;
				}
				self.onSelectAllItem();	
			}
			else if(button.id == 'operation_btn'){
				print("onButtonClicked RunTimeInfo.operationBtnDim:"+RunTimeInfo.operationBtnDim);
				if(RunTimeInfo.operationBtnDim == true){
					
					return;
				}
				self.onOperate();
			}
			else if(button.id == 'cancel_btn'){
				print("onButtonClicked self.cancelBtnDim:"+self.cancelBtnDim);
				if(self.cancelBtnDim == true){
					
					return;
				}
				self.onCancelSelectItem();
			}
			else if(button.id == 'selector_btn'){
				print("self.selectorBtnDim:"+self.selectorBtnDim);
				if(self.selectorBtnDim == true){
					
					return;
				}
				self.onDeviceSelect();
			}
		};
		
		var buttonFocusListener = new FocusListener;
		buttonFocusListener.onFocusIn = function (button) {
		 	print('onFocusIn  >>>> button id :'+ button.id);
			print('onFocusIn  >>>> button text :'+ button.text());
			if(button.id == 'selector_btn'){
				var txt = resMgr.getText('SID_DEVICE_CHOICE') + ',' + button.text();
			}else{
				var txt = button.text() + ', ' + resMgr.getText('TV_SID_BUTTON');
			}
			voiceGuide.play(txt);		 	
		};
		
		if(self.selAllBtn != null){
			self.selAllBtn.addListener(buttonListener);
			self.selAllBtn.addFocusListener(buttonFocusListener);
			self.selAllBtn.setFontSize({state: "all", size: 28,});		
			self.selAllBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			self.selAllBtn.setBackgroundImage({state:"focused",src:resMgr.getImgPath()+"/common/4way_focus.png"});
			//self.selAllBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			//self.selAllBtn.setBorder({state: "focused-roll-over",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			//self.selAllBtn.show();
		}
		if(self.optionBtn != null){
			self.optionBtn.addListener(buttonListener);
			self.optionBtn.addFocusListener(buttonFocusListener);
			self.optionBtn.setFontSize({state: "all", size: 28,});
			self.optionBtn.setBackgroundImage({state:"focused",src:resMgr.getImgPath()+"/common/4way_focus.png"});
			self.optionBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			//self.optionBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			//self.optionBtn.setBorder({state: "focused-roll-over",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			//self.optionBtn.show();
		}
		if(self.cancelBtn != null){
			self.cancelBtn.addListener(buttonListener);
			self.cancelBtn.addFocusListener(buttonFocusListener);
			self.cancelBtn.setFontSize({state: "all", size: 28,});
			self.cancelBtn.setBackgroundImage({state:"focused",src:resMgr.getImgPath()+"/common/4way_focus.png"});
			self.cancelBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			//self.cancelBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			//self.cancelBtn.setBorder({state: "focused-roll-over",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			//self.cancelBtn.show();
		}
		if(self.deviceBtn != null){
			self.deviceBtn.addListener(buttonListener);
			self.deviceBtn.addFocusListener(buttonFocusListener);
			self.deviceBtn.setBackgroundImage({state:"focused",src:resMgr.getImgPath()+"/common/4way_focus.png"});
			self.deviceBtn.setTextColor({state: "normal", color: {r:0xff,g:0xff,b:0xff,a:255},});
			self.deviceBtn.setTextColor({state: "focused", color: {r:0xff,g:0xff,b:0xff,a:255},});
			self.deviceBtn.setFontSize({state: "focused", size: 31,});
			self.deviceBtn.setFontSize({state: "selected", size: 31,});
			self.deviceBtn.setFontSize({state: "focused-roll-over", size: 31,});
			self.deviceBtn.setFontSize({state: "roll-over", size: 31,});
			self.deviceBtn.setFontSize({state: "normal", size: 28,});
			//self.deviceBtn.show();
		}
		
    },

    events: {
        //'NAV_SELECT #select_all_id': 'onSelectAllItem',
        //'NAV_SELECT #operation_id': 'onOperate',
        //'NAV_SELECT #cancel_id': 'onCancelSelectItem',
        
        'NAV_FOCUS':'onFocus',
        'NAV_BLUR':'onBlur'
    },

	/** Get interst device postion   	 
	* @name onDeviceConnect	 
	* @memberOf edit mode view
	* @param {type} Device type , USB/DLNA/RA/PTP
	* @method 	 
	* */
    onDeviceConnect: function(deviceInfo){
        print('[edit-mode-view.js] onDeviceConnect :',deviceInfo );
       	if(RunTimeInfo.isEditMode != true){
			return
       	}
		
		if(self.optType == EOptType.ePlaySelType){
			var devNum = DeviceProvider.getDeviceCount();
		}
		else{
			var devNum = DeviceProvider.getUsbDeviceCount();
		}

		if(devNum <= 1){
			self.disableDeviceSelector();
			if(self.isFocusDevSelector == true){
				Volt.Nav.focus(self.cancelBtn);
			}
		}
		else{
			self.enableDeviceSelector();
		}
    },

	/** Get interst device postion   	 
	* @name onDeviceDisconnect	 
	* @memberOf edit mode view
	* @param {type} Device type , USB/DLNA/RA/PTP
	* @method 	 
	* */
    onDeviceDisconnect: function(deviceID,deviceType){
   		print("[edit-mode-view.js] Remove device id:",deviceID, 'deviceType :',deviceType);
		print("edit-mode-view.js isFocusDevSelector = ",self.isFocusDevSelector);
	   	if(RunTimeInfo.isEditMode != true){
			return
       	}

		if(self.optType == EOptType.ePlaySelType){
			var devNum = DeviceProvider.getDeviceCount();
		}
		else{
			var devNum = DeviceProvider.getUsbDeviceCount();
		}

		if(devNum <= 1){
			self.disableDeviceSelector();
			if(self.isFocusDevSelector == true){
				Volt.Nav.focus(self.cancelBtn);
			}
		}
		else{
			self.enableDeviceSelector();
		}
    },

	/** select all/deselect all list item  	 
	* @name onSelectAllItem	 
	* @memberOf EditModeView
	* @method 	 
	* */	
	onSelectAllItem: function(){
		print('[edit-mode-view.js] editModeView.onSelectAllItem');
		if(self.selectAllFlag){
			print('[edit-mode-view.js] ------------------------- trigger deselect all');
			//EventMediator.trigger(EventType.EVENT_TYPE_VIEW_DESELECT_ALL);
			//self.widget.getChild('select_all_id').getChild(0).src = selAllCheckBoxIconFocus;
			self.setSelectAllBtnText(resMgr.getText('COM_SID_SELECT_ALL'));
			self.selectAllFlag = false;
			EventMediator.trigger(EventType.EVENT_TYPE_VIEW_DESELECT_ALL);
		}else{
			print('[edit-mode-view.js] ------------------------- trigger select all');
			//EventMediator.trigger(EventType.EVENT_TYPE_VIEW_SELECT_ALL);
			//this.widget.getChild('select_all_id').text = Volt.LANG.UID_DESELECT_ALL;
			//self.widget.getChild('select_all_id').getChild(0).src = selAllCheckIconFocus;
			self.setSelectAllBtnText(resMgr.getText('SID_DESELECT_ALL'));
			self.selectAllFlag = true;
			EventMediator.trigger(EventType.EVENT_TYPE_VIEW_SELECT_ALL);
		}
    },

	/** select option in edit mode  	 
	* @name onOperate	 
	* @memberOf EditModeView
	* @method 	 
	* */	
	onOperate: function(){
		print('[edit-mode-view..js] editModeView.onOperate');
		if(self.optType == EOptType.ePlaySelType){
		
			print('[edit-mode-view.js] ------------------------- play');
			EventMediator.trigger(EventType.EVENT_TYPE_VIEW_PLAY_SELECT);
		
		} else if(self.optType == EOptType.eDeleteType){
			
			print('[edit-mode-view.js] ------------------------- delete');
			EventMediator.trigger(EventType.EVENT_TYPE_VIEW_DELETE_SELECT);
		
		}else if(self.optType == EOptType.eSendType){
		
			print('[edit-mode-view.js] ------------------------- trigger send');
			EventMediator.trigger(EventType.EVENT_TYPE_VIEW_SEND_SELECT);
		
		}
    },

	setSelAllFlagStatus: function(flag){
		this.selectAllFlag = flag;
    },

	/** select select all text  	 
	* @name setSelectAllWidgetText	 
	* @memberOf EditModeView
	* @param {text} 
	* @method 	 
	* */
	setSelectAllWidgetIcon: function(icon){
		this.widget.getChild('select_all_id').getChild(0).src = icon;
		//this.selAllBtn.setIconImage({state: "all", src: icon,});
    },

	/** set select all button text  	 
	* @name setSelectAllBtnText	 
	* @memberOf EditModeView
	* @param {text} 
	* @method 	 
	* */
	setSelectAllBtnText: function(strText){
		if(this.selAllBtn != null){
			this.selAllBtn.setText({state: "all", text: strText,});
		}
    },

	/** set cancel button text  	 
	* @name setCancelBtnText	 
	* @memberOf EditModeView
	* @param {String} 
	* @method 	 
	* */
	setCancelBtnText: function(strText){
		if(this.cancelBtn != null){
			this.cancelBtn.setText({state: "all", text: strText,});
			this.cancelBtn.setFontSize({state: "all", size: 28,});
		}
    },

	/** set select all button text  	 
	* @name setSelectAllBtnText	 
	* @memberOf EditModeView
	* @param {text} 
	* @method 	 
	* */
	setSelectorBtnText: function(strText){
		if(self.deviceBtn != null){
			self.deviceBtn.setText({state: "all", text: strText,});
		}
    },

	/** set all button has no focus  	 
	* @name setAllBtnNoFocus	 
	* @memberOf EditModeView
	* @method 	 
	* */
	setAllBtnNoFocus: function(){
		this.setOptionNoFocus();
		this.setOperationIdNoFocus();
		self.cancelBtnDim = true;
		self.selectorBtnDim = true;
		//this.widget.getDescendant('cancel_btn').custom.focusable = false;
		//this.widget.getDescendant('selector_btn').custom.focusable = false;
    },

	/** set cancel button has focus  	 
	* @name setCancelWidgetFocus	 
	* @memberOf EditModeView
	* @method 	 
	* */
	setCancelWidgetFocus: function(){
		self.cancelBtnDim = false;
		this.widget.getDescendant('cancel_btn').custom.focusable = true;
    },

	/** set Selector button has focus  	 
	* @name setSelectorWidgetFocus	 
	* @memberOf EditModeView
	* @method 	 
	* */
	setSelectorWidgetFocus: function(){
		self.selectorBtnDim = false;
		this.widget.getDescendant('selector_btn').custom.focusable = true;
    },

	/** set cancel button has focus  	 
	* @name setCancelWidgetFocus	 
	* @memberOf EditModeView
	* @method 	 
	* */
	setOptionNoFocus: function(){
		print('[edit-mode-view.js]------setOptionNoFocus()');
		self.selectAllBtnDim = true;
		//this.widget.getDescendant('select_all_btn').custom.focusable = false;
		if(self.selAllBtn != null){
			print('[edit-mode-view.js]------setOperationIdNoFocus() selAllBtn');
			self.selAllBtn.setTextColor({state:"all",color:{r: 255, g: 255, b: 255, a: 255*0.15},});
		}
    },

	/** set select all button has focus  	 
	* @name setOptionHasFocus	 
	* @memberOf EditModeView
	* @method 	 
	* */
	setOptionHasFocus: function(){
		print('[edit-mode-view.js]------setOptionNoFocus()');
		if(self.selectAllBtnDim == true){
			self.selectAllBtnDim = false;
			if(self.selAllBtn != null){
				self.selAllBtn.setTextColor({state: "all",
									color: {r: 255, g: 255, b: 255, a: 255},});
			}
		}
    },

	/** set operation button has no focus  	 
	* @name setOperationIdNoFocus	 
	* @memberOf EditModeView
	* @method 	 
	* */
	setOperationIdNoFocus: function(){
		print('[edit-mode-view.js]------setOperationIdNoFocus()');
		//this.widget.getDescendant('operation_btn').custom.focusable = false;
		print("setOperationIdNoFocus RunTimeInfo.operationBtnDim:"+RunTimeInfo.operationBtnDim);
		
		RunTimeInfo.operationBtnDim = true;
		
		if(self.optionBtn != null){
			print('[edit-mode-view.js]------setOperationIdNoFocus() optionBtn');
			self.optionBtn.setTextColor({state:"all",color:{r: 255, g: 255, b: 255, a: 255*0.15},});
		}
    },

	/** set operation button has  focus  	 
	* @name setOperationIdHasFocus	 
	* @memberOf EditModeView
	* @method 	 
	* */
	setOperationIdHasFocus: function(){
		print('[edit-mode-view.js]------setOperationIdHasFocus()');
		this.widget.getDescendant('operation_btn').custom.focusable = true;
		print("setOperationIdHasFocus RunTimeInfo.operationBtnDim:"+RunTimeInfo.operationBtnDim);
		
		RunTimeInfo.operationBtnDim = false;
		
		print("setOperationIdHasFocus RunTimeInfo.operationBtnDim:"+RunTimeInfo.operationBtnDim);
		if(self.optionBtn != null){
			self.optionBtn.setTextColor({state: "all",
								color: {r: 255, g: 255, b: 255, a: 255},});
		}
    },

	/** exit edit mode view  	 
	* @name onCancelSelectItem	 
	* @memberOf EditModeView
	* @method 	 
	* */
	onCancelSelectItem: function(){
		print('[edit-mode-view..js] editModeView.onCancelSelItem');
		EventMediator.trigger(EventType.EVENT_TYPE_VIEW_CANCEL_SELECT);
    },

	/** focus on widget  	 
	* @name onFocus	 
	* @memberOf EditModeView
	* @param {widget}  focus widget
	* @method 	 
	* */
    onFocus: function(widget){
        print('[edit-mode-view..js] editModeView.onFocus id =',widget.id);
		//widget.color = Volt.hexToRgb('#219ee6');
		if(widget.id == 'select_all_btn'){
		
			//this.widget.getChild('select_all_id').color = Volt.hexToRgb('#ffffff',95);
			//this.selAllBtn.setTextColor({state: "all", color: {r:0x46,g:0x46,b:0x46,a:255},});
			this.selAllBtn.setFontSize({state: "all", size: 31,});
			this.isFocusEditMode = true;
		}
		else if(widget.id == 'operation_btn'){
			if(RunTimeInfo.operationBtnDim == true){
				print(" this.optionBtn.custom.focusable == false ");
				Log.e(" this.optionBtn.custom.focusable == false ");
			//	return;
			}
			//this.widget.getChild('operation_id').color = Volt.hexToRgb('#ffffff',95);
			//this.optionBtn.setFocus();
			//this.optionBtn.setTextColor({state: "all", color: {r:0x46,g:0x46,b:0x46,a:255},});
			this.optionBtn.setFontSize({state: "all", size: 31,});
			
		
			this.isFocusEditMode = true;

		}
		else if(widget.id == 'cancel_btn'){
			//this.widget.getChild('cancel_id').color = Volt.hexToRgb('#ffffff',95);
			//this.cancelBtn.setFocus();
			//this.cancelBtn.setTextColor({state: "all", color: {r:0x46,g:0x46,b:0x46,a:255},});
			this.cancelBtn.setFontSize({state: "all", size: 31,});
			this.isFocusEditMode = true;
		}
		else if(widget.id == 'selector_btn'){
			//this.widget.getChild('arrow_image').color = Volt.hexToRgb('#ffffff',95);
			//this.cancelBtn.setFocus();
			//this.deviceBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			//this.deviceBtn.setFontSize({state: "all", size: 31,});
			//if(RunTimeInfo.visibleCursor ==false){
				//this.setFocusImage(widget.id);
			//}
			this.isFocusEditMode = true;
			this.isFocusDevSelector = true;
		}

		//this.setFocusImage(widget.id);
        //widget.animate('scale', {x: 1.2, y: 1.2}, 300, 'cubic');
        //EventMediator.trigger('EVENT_MAIN_CATEGORY_FOCUS');
        //EventMediator.trigger(EventType.EVENT_TYPE_FOCUS_CHANGE, FocusPos.FOCUS_CATEGORY);
    },

	/** lose focus on widget  	 
	* @name onBlur	 
	* @memberOf EditModeView
	* @param {widget}  lose focus widget
	* @method 	 
	* */
    onBlur: function(widget){
        print('[edit-mode-view..js] editModeView.onBlur');
		//widget.color = Volt.hexToRgb('#f2f2f2');
		if(widget.id == 'select_all_btn'){
			/*
			var iconWidget = this.widget.getChild('select_all_id');
			iconWidget.color = Volt.hexToRgb('#f2f2f2');
			if(iconWidget.getChild(0).src == selAllCheckIconFocus){
				iconWidget.getChild(0).src = selAllCheckIconNor;
			}
			else if(iconWidget.getChild(0).src == selAllCheckBoxIconFocus){
				iconWidget.getChild(0).src = selAllCheckBoxIconNor;
			}*/
			//this.selAllBtn.killFocus();
			this.widget.getChild('select_all_id').color = Volt.hexToRgb('#0f1826',100);
			//this.selAllBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			this.selAllBtn.setFontSize({state: "all", size: 28,});
			this.isFocusEditMode = false;
		}
		else if(widget.id == 'operation_btn'){
			if(this.optionBtn.custom.focusable == false){
			//	return;
			}
			this.widget.getChild('operation_id').color = Volt.hexToRgb('#0f1826',100);
			//this.optionBtn.killFocus();
			//this.optionBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			this.optionBtn.setFontSize({state: "all", size: 28,});
			this.isFocusEditMode = false;
		}
		else if(widget.id == 'cancel_btn'){
			this.widget.getChild('cancel_id').color = Volt.hexToRgb('#0f1826',100);
			//this.cancelBtn.killFocus();
			//this.cancelBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			this.cancelBtn.setFontSize({state: "all", size: 28,});
			this.isFocusEditMode = false;
		}
		else if(widget.id == 'selector_btn'){
			//this.widget.getChild('arrow_image').color = Volt.hexToRgb('#0f1826',100);
			//this.cancelBtn.killFocus();
			//this.deviceBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
			//this.deviceBtn.setFontSize({state: "all", size: 28,});
			//this.hideFocusImage(widget.id);
			this.isFocusEditMode = false;
			this.isFocusDevSelector = false;
		}
    },
	/** set arrow image 	 
	* @name onBlur	 
	* @memberOf EditModeView
	* @param {widget}  lose focus widget
	* @method 	 
	* */
	setArrowImage: function(url){
		/*
		var arrowImage = this.widget.getChild('arrow_image');
		if(arrowImage != null){
			arrowImage.src = url;
		}*/
		self.deviceBtn.setIconImage({state:"all",src: url});
    },
	/** hide edit mode view  	 
	* @name hide	 
	* @memberOf EditModeView
	* @param {id}  current focus widget id
	* @method 	 
	* */
	hide: function(){
		print('edit-mode-view.js hide()');
		this.widget.hide();
		DeviceProvider.unregsiterListener(this,this.onDeviceConnect,this.onDeviceDisconnect);
    },

	/** destroy edit mode view  	 
	* @name destroy	 
	* @memberOf EditModeView
	* @param {id}  current focus widget id
	* @method 	 
	* */
	destroy: function(){
		print('edit-mode-view.js destroy()');
    },

	/** hide focus image  	 
	* @name hideFocusImage	 
	* @memberOf EditModeView
	* @param {id}  current focus widget id
	* @method 	 
	* */
	hideFocusImage: function(id){
    	if(id == 'select_all_id'){
   			var widget = this.widget.getChild('edit-select-id');
			widget.hide();
    	}
    	else if(id == 'operation_id'){
    		var widget = this.widget.getChild('edit-option-id');
			widget.hide();
    	}
    	else if(id == 'cancel_id'){
    		var widget = this.widget.getChild('edit-cancel-id');
			widget.hide();
    	}
		else if(id == 'selector_btn'){
    		var widget = this.widget.getChild('edit-devselector-id');
			if(widget != null){
				widget.hide();
			}
    	}
    	else{
    	}
    },

	/** set focus image  	 
	* @name setFocusImage	 
	* @memberOf EditModeView
	* @param {id}  current focus widget id
	* @method 	 
	* */
    setFocusImage: function(id){
    	if(id == 'select_all_id'){
    		if(this.widget.getChild('edit-select-id') == null){
    			this.widget.addChild(loadTemplate(EditModeViewTemplate.focusSelAll));
        	}
        	else{
				//this.widget.getChild('select_all_id').text = 'Select All';
        		this.widget.getChild('edit-select-id').show();
        	}
    	}
    	else if(id == 'operation_id'){
			if(this.widget.getChild('edit-option-id') == null){
    			this.widget.addChild(loadTemplate(EditModeViewTemplate.focusOption));
        	}
        	else{
        		this.widget.getChild('edit-option-id').show();
        	}
    	}
    	else if(id == 'cancel_id'){
			
    		if(this.widget.getChild('edit-cancel-id') == null){
				print('------111223edit-cancel-id is null');
    			this.widget.addChild(loadTemplate(EditModeViewTemplate.focusCancel));
        	}
        	else{
        		this.widget.getChild('edit-cancel-id').show();
        	}
    	}
		else if(id == 'selector_btn'){
			
    		if(this.widget.getChild('edit-devselector-id') == null){
				print('------111223cur_dev_name_id is null');
    			this.widget.addChild(loadTemplate(EditModeViewTemplate.focusDevSelector));
        	}
        	else{
        		this.widget.getChild('edit-devselector-id').show();
        	}
    	}
    },

    showDeviceSelector : function(){
    	print('edit-mode-view.js showDeviceSelector()');
	
    	this.selWidget = new WidgetEx({
			x: 0, y: 216,width: 383, height: 400,
			color:{r:255,g:255,b:255,a:0},
			parent: this.mainView.getPopUpContainer(), 
		});
	
		this.deviceSelector = new DeviceSelectorView({
			x:0 , y: 0 ,listWidth: 383,
			parent: this.selWidget,	
			optType: self.optType,
		});
		var cateIndex = self.mainView.categoryView.getCurrentCategoryIndex();
		var index = self.mainView.categoryView.categoriesID[cateIndex];
		var devList = this.deviceSelector.getDeviceCollect(self.optType);
		this.deviceSelector.setListText(devList);			
		this.deviceSelector.setSelectId(index);
		this.deviceSelector.render();
		this.deviceSelector.setReturnCb(function(){
			self.hideDeviceSelector();
			Volt.Nav.setRoot(mainView.widget);
		});
		this.deviceSelector.setClickCb(function(){
			self.onClickSelector();
		});
		self.selWidget.show();
		if(self.deviceBtn != null){
			self.deviceBtn.setTextColor({state: "all", color: {r:0xff,g:0xc2,b:0x1f,a:255},});
		}
		self.setArrowImage(selectArrow);
		var deviceCount = devList.length;
		if(deviceCount > 1){
			var itemTxt = deviceCount.toString()+','+resMgr.getText('COM_TV_SID_ITEMS')+',';
		}else{
			var itemTxt = deviceCount.toString()+','+resMgr.getText('COM_ITEM')+',';
		}
		var txt = itemTxt + self.mainView.categoryView.categories[cateIndex];
		voiceGuide.play(txt);
		
		if(self.optType == EOptType.ePlaySelType){
			Volt.KPIMapper.addEventLog('MY_OPTION_SELECT');
		}
		else if(self.optType == EOptType.eDeleteType){
			Volt.KPIMapper.addEventLog('MY_OPTION_DELETE');
		}		
    },


	hideDeviceSelector : function(){
		if(self.deviceSelector != null){
			self.deviceSelector.hide();
			self.deviceSelector = null;
			self.selWidget.hide();
			self.selWidget = null;		
			//var mainView = Volt.require('app/views/main-view.js');
			//Volt.Nav.setRoot(mainView.widget);    //when device popup destroy,set root widget to main view
			if(self.deviceBtn != null){
				self.deviceBtn.setTextColor({state: "all", color: {r:0xff,g:0xff,b:0xff,a:255},});
				self.deviceBtn.setFontSize({state: "roll-over", size: 28,});
			}
			self.setArrowImage(normalArrow);
		}
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
	},
    
    onDeviceSelect :function(){
    	EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
    	self.showDeviceSelector();
    },

	onClickSelector: function(){
		print('[device-selector-view] onItemClicked');
		if(self.deviceSelector == null){
			print('[device-selector-view] onItemClicked deviceSelector is null');
			Log.f('[device-selector-view] onItemClicked deviceSelector is null');
			return;
		}
		var index = self.deviceSelector.itemList.focusItemIndex;
		self.deviceSelector.setSelectIndex(index);
		var devId = self.deviceSelector.deviceCollect[index].id;
		var devName = self.deviceSelector.deviceCollect[index].name;
		print('11111111111111111111111111111111111111111111111111111edit-mode-view.js select device name = ',devName);
		self.setSelectorBtnText(devName);
		var curView = RunTimeInfo.router.currentView;
		if(curView != null){
			curView.resetSelectStatus();
		}
		var setTxt = resMgr.getText('COM_SID_POPUP_WIDGET_SELECT_GUIDE');
		setTxt = setTxt.replace('<<A>>', self.deviceSelector.deviceCollect[index].name);
		var txt = setTxt + resMgr.getText('SID_DEVICE_CHOICE')+','+ self.deviceSelector.deviceCollect[index].name;
		voiceGuide.play(txt);
		
		EventMediator.trigger(EventType.EVENT_TYPE_EDIT_DEVICE_CHANGE, devId);
		if(self.deviceBtn != null){
			Volt.Nav.focus(self.deviceBtn);
		}		
    } ,

	hideDevSelectorBtn: function(){
		print('[edit-mode-view.js] hideDevSelectorBtn');
		if(self.deviceBtn != null){
			self.deviceBtn.hide();
			self.deviceBtn.custom.focusable = false;
		}
		/*
		var arrow = self.widget.getChild('arrow_image');
		if(arrow != null){
			arrow.opacity = 0;
		}*/
		var lineWidget = self.widget.getChild(6);
		if(lineWidget != null){
			lineWidget.opacity = 0;
		}
		
		var selTextWidget = self.widget.getChild(0);
		if(selTextWidget != null){
			selTextWidget.x = 35;
		}

		var numTextWidget = self.widget.getChild(1);
		if(numTextWidget != null){
			numTextWidget.x = 217 + this.tempV;
		}
    },

	showDevSelectorBtn: function(){
		print('[edit-mode-view.js] showDevSelectorBtn');
		if(self.deviceBtn != null){
			self.deviceBtn.show();
		}
		/*
		var arrow = self.widget.getChild('arrow_image');
		if(arrow != null){
			arrow.opacity = 255;
		}*/
		var lineWidget = self.widget.getChild(6);
		if(lineWidget != null){
			lineWidget.opacity = 255*0.1;
		}
		
		var selTextWidget = self.widget.getChild(0);
		if(selTextWidget != null){
			selTextWidget.x = 418;
		}
		
		var numTextWidget = self.widget.getChild(1);
		if(numTextWidget != null){
			numTextWidget.x = 600+this.tempV;
		}
    },

    disableDeviceSelector: function(){
    	print('[device-selector-view] disableDeviceSelector');
    	self.deviceSelectable == false;
		self.deviceBtn = self.widget.getChild('cur_dev_name_id').getChild('selector_btn');
		if(self.deviceBtn != null){
			self.deviceBtnDim = true;
		//	self.deviceBtn.custom.focusable = false;
			self.deviceBtn.setIconAlpha({state: "all", alpha: 0});
		}
		/*
		var arrow = self.widget.getChild('arrow_image');
		if(arrow != null){
			print('11111111111111111111111disableDeviceSelector');
			arrow.hide();
			arrow.opacity = 0;
		}*/
    },

    enableDeviceSelector: function(){
    	print('[device-selector-view] enableDeviceSelector');
    	self.deviceSelectable == true;
		self.deviceBtn = self.widget.getChild('cur_dev_name_id').getChild('selector_btn');
		if(self.deviceBtn != null){
			self.deviceBtnDim = false;
			self.deviceBtn.custom.focusable = true;
			self.deviceBtn.setIconAlpha({state: "all", alpha: 255});
		}
		/*
		var arrow = self.widget.getChild('arrow_image');
		if(arrow != null){
			arrow.show();
			arrow.opacity = 255;
		}*/
    },
    setAllbuttonFocusable: function(bflag){
    	if(self.deviceBtn != null){
    		self.deviceBtn.custom.focusable = bflag;
    	}
    	if(self.selAllBtn  != null){	
    		self.selAllBtn.custom.focusable = bflag;
    	}
    	if(self.optionBtn  != null){
    		self.optionBtn.custom.focusable = bflag;
    	}
    	if(self.cancelBtn  != null){
    		self.cancelBtn.custom.focusable = bflag;
    	}  	
    },

});

exports = EditModeView;
