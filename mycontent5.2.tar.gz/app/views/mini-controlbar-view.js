 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Music Player view 
 * @date    2014/08/08 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Backbone = Volt.require('modules/backbone.js');
var BaseView = Volt.BaseView;
var CommonInfo = Volt.require("app/common/define.js");
var EItemType = CommonInfo.EItemType;
var EventType = CommonInfo.EventType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var EViewType = CommonInfo.EViewType;
var KeyCode = CommonInfo.KeyCode;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var playerController = Volt.require('app/controller/play-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var MusicMiniCtrlBarTemplate = Volt.require('app/templates/1080/mini-controlbar-template.js');
var launchParams = Volt.require("app/common/launch-params.js");
var LaunchedByAppID = CommonInfo.LaunchedByAppID;

var self = null;
var THUMB_BASE_PATH = resMgr.getThumbPath();

var MusicMiniView = PanelCommon.BaseView.extend({
	template: MusicMiniCtrlBarTemplate.controlBar,
	
	thumbImg: null,
	infoWgt: null,
	titleTxt: null,
	artistTxt: null,
	albumTxt: null,
	progressWgt: null,
	preBtn: null,
	pauseBtn: null,
	nextBtn: null,
	totalTxt: null,
	currentTxt: null,
	sepLine: null,
	focusState: false,
	destroyState: true,
	
	playIns: null,

	/**initialize MusicMiniView 	 
	* @name initialize	 
	* @memberOf MusicMiniView	 
	* @method 	 */		
	initialize: function() {
		self = this;
	},

	/**render MusicMiniView 	 
	* @name render	 
	* @memberOf MusicMiniView	 
	* @method 	 */		
	render: function() {
		self.playIns = playerController;
		self.destroyState = false;

		var itemData = self.playIns.getItemData();
		
		var currentItem = {
	        thumbUrl: '',
	        title: itemData.title,
	        artist: itemData.artist,
	        album: itemData.album,
	    };
		var miniBar = loadTemplate(self.template, currentItem);		
		self.setWidget(miniBar);
		
		self.thumbImg = self.widget.getDescendant('thumb');
		if(self.thumbImg==null){
			print("Can't find thumb, error!");
			return;
		}		
		
		self.titleTxt = self.widget.getDescendant('title');
		if(self.titleTxt==null){
			print("Can't find title, error!");
			return;
		}	
		
		self.artistTxt = self.widget.getDescendant('artist');
		if(self.artistTxt==null){
			print("Can't find artist, error!");
			return;
		}	

		self.sepLine = self.widget.getDescendant('separator');
		if(self.sepLine==null){
			print("Can't find separator, error!");
			return;
		}			

		self.infoWgt = self.widget.getChild('infoArea');
		if(self.infoWgt==null){
			print("Can't find infoArea, error!");
			return;
		}			
		
		self.albumTxt = self.widget.getDescendant('album');
		if(self.albumTxt==null){
			print("Can't find album, error!");
			return;
		}

		self.totalTxt = self.widget.getChild('timeTotal');
		if(self.totalTxt==null){
			print("Can't find timeTotal, error!");
			return;
		}	
		
		self.currentTxt = self.widget.getChild('timeCurr');
		if(self.currentTxt==null){
			print("Can't find timeCurr, error!");
			return;
		}			

		var textColor = {
				r : 110,
				g : 137,
				b : 179,
				a : 153,
		};
        self.titleTxt.getUIElement().setTextContent(
			{text:currentItem.title,
			textfont:{normal:"28px",focus:"28px",slected:"28px",dim:"28px"},
			textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
			});
		textColor.a = 102;
        self.artistTxt.getUIElement().setTextContent(
			{text:currentItem.artist,
			textfont:{normal:"26px",focus:"26px",slected:"26px",dim:"26px"},
			textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
			});
        self.albumTxt.getUIElement().setTextContent(
			{text:currentItem.album,
			textfont:{normal:"26px",focus:"26px",slected:"26px",dim:"26px"},
			textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor},
			});
		
		self.progressWgt = self.widget.getChild('Proline');
		if(self.progressWgt==null){
			print("Can't find Progress, error!");
			return;
		}	
		self.progressWgt.getUIElement().setLeftKeyCallback(self._progressRW);
		self.progressWgt.getUIElement().setRightKeyCallback(self._progressFF);			
		
		self.preBtn = self.widget.getChild('preBtn');
		if(self.preBtn==null){
			print("Can't find preBtn, error!");
			return;
		}
		
		self.pauseBtn = self.widget.getChild('pauseBtn');
		if(self.pauseBtn==null){
			print("Can't find pauseBtn, error!");
			return;
		}
		
		self.nextBtn = self.widget.getChild('nextBtn');
		if(self.nextBtn==null){
			print("Can't find nextBtn, error!");
			return;
		}

		var currIdx = self.playIns.getCurrentIdx();
		self.updateInfo(currIdx);
		self.playIns.getDuration();
		
		return this;
	},

	/**destroy music play 	 
	* @name destroy	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
	destroy: function(){
		if( self.progressWgt!= null ){
			self.progressWgt.destroy();
			self.progressWgt = null;
		}
		self.widget.hide();
		self.widget.destroy();

		self.destroyState = true;
	},
	
    events: {   
    	'NAV_SELECT': 'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur',
    },	

	/**the callback for select music mini control bar's button
	* @name onSelect	 
	* @memberOf MusicMiniView	 
	* @param {widget} which widget has been selected	
	* @method 	 */			
    onSelect: function(widget) {
		if( widget == self.preBtn ){
			self.playIns.playPre(); 		
		}
		else if( widget == self.pauseBtn ){
    		if(self.playIns.getState()==3){		//playing
    			self.playIns.pause();
    		}		
    		else if(self.playIns.getState()==4){	//pause
    			self.playIns.resume();  			
    		}
		}
		else if( widget == self.nextBtn ){
			self.playIns.playNext(); 		
		}   
		else if( widget == self.infoWgt ){
			print('Ready to recover music player');
			RunTimeInfo.router.switchToMusicPlayer(EViewType.eMusicPlayerView, EViewSwitchAniType.eNoneAni);			
		}
		else{
			print('no respond widget in MusicMiniView');
		}
    },

	/**the callback for the widget on focus
	* @name onFocus	 
	* @memberOf MusicMiniView	 
	* @param {widget} which widget has been focused	
	* @method 	 */	
    onFocus: function(widget) {
      	if( widget == null ){
			return;
      	}    
        print('[main-view.js] MusicPlayer.focus ' + widget.id);
		self.focusState = true;

        if( widget == self.progressWgt ){
        	self.progressWgt.onFocus();
        	return;
        }		
		else if(widget == self.infoWgt) {
			var textColor = {
					r : 110,
					g : 137,
					b : 179,
					a : 255,
			};
	        self.titleTxt.getUIElement().setTextContent({textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor}});
	        self.artistTxt.getUIElement().setTextContent({textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor}});
	        self.albumTxt.getUIElement().setTextContent({textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor}});
			return;
		}
        
        widget.opacity  = 255;
    },   

	/**the callback for the widget lose focus
	* @name onBlur	 
	* @memberOf MusicMiniView	 
	* @param {widget} which widget has been losed focus	
	* @method 	 */		
    onBlur: function(widget) {
      	if( widget == null || widget === undefined){
			return;
      	}

		self.focusState = false;

		if( self.destroyState == true ){
			return;
		}

        if( widget == self.progressWgt ){
        	self.progressWgt.onBlur();
        	return;
        }   
		else if(widget == self.infoWgt) {
			var textColor = {
					r : 110,
					g : 137,
					b : 179,
					a : 153,
			};
	        self.titleTxt.getUIElement().setTextContent({textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor}});
			textColor.a = 102;			
	        self.artistTxt.getUIElement().setTextContent({textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor}});
	        self.albumTxt.getUIElement().setTextContent({textcolor:{normal:textColor,focus:textColor,slected:textColor,dim:textColor}});	
			return;
		}
    	        
        widget.opacity = 153;
    },

	/**update the current playing music item info
	* @name updateInfo	 
	* @memberOf MusicMiniView	 
	* @method 	 */		
	updateInfo: function( idx ){
		if(self.destroyState==true){
			return;
		}
		var itemData = self.playIns.getItemData();
		if( itemData==null ){
			print('can\'t get the music file data');
			return;
		}
    	
    	if( self.thumbImg == null || self.titleTxt == null || self.artistTxt == null || self.albumTxt == null ){
    		print('GUI element is not enough!');
    		return;
    	}

		var thumbSrc = itemData.thumb;
		if( thumbSrc==resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_album_default.PNG' ){
			thumbSrc = resMgr.getImgPath()+'/default_thumb/mc_music_thumbnail_play_default.png';
		}

	    self.thumbImg.src = thumbSrc;		
        self.titleTxt.getUIElement().setTextContent({text:itemData.title});
        self.artistTxt.getUIElement().setTextContent({text:itemData.artist});
        self.albumTxt.getUIElement().setTextContent({text:itemData.album});

		//replace the position of artist/album
		self.sepLine.x = 116;
		self.albumTxt.x = 125;
		var artistLength = self._getStrWidth( itemData.artist,'26px' );
		if( artistLength < 110 ){
			self.sepLine.x = 116 - 110 + artistLength;
			self.albumTxt.x = 125 - 110 + artistLength; 
		}
	},

	/**update the current playing time
	* @name updateTime	 
	* @memberOf MusicMiniView	 
	* @param {per} the progressBar's position
	* @param {timeStr} the current time's string	
	* @param {timeInt} the current time's integer		
	* @method 	 */		
	updateTime: function( per, timeStr, timeInt ){
		if(self.destroyState==true){
			return;
		}
    	if( self.progressWgt != null && per >= 0 && per <= 1 ){
    		self.progressWgt.getUIElement().setProgress( per*1000 );
    	}
		var timeWidth = self._getStrWidth(timeStr, '20px');
		print('width of timeStr is ', timeWidth, 'timeStr is',timeStr );

		if( self.currentTxt != null ){
			self.currentTxt.text = String(timeStr);
		}		
	},

	/**update the total playing time
	* @name updateTotalTime	 
	* @memberOf MusicMiniView	 
	* @param {StrTotalTime} the total time's string
	* @param {IntTotalTime} the total time's integer	
	* @method 	 */
	updateTotalTime: function( StrTotalTime, IntTotalTime ){
		if(self.destroyState==true){
			return;
		}
		var timeWidth = self._getStrWidth(StrTotalTime, '20px');
		print('width of StrTotalTime is ', timeWidth);

    	if( self.progressWgt != null ){
			self.progressWgt.getUIElement().x = self.currentTxt.x + timeWidth + 10;
    		self.progressWgt.getUIElement().resetBarWidth( 788-2*timeWidth-2*10 );
			print('update progressWgt to x = ', self.currentTxt.x + timeWidth + 10, ' width = ',788-2*timeWidth-2*10 );
    	}

		if( self.totalTxt != null ){
			self.totalTxt.x = self.currentTxt.x  + 788 - timeWidth;
			self.totalTxt.text = StrTotalTime;
		}		
	},

	/**check whether the miniView fet the focus
	* @name getFocusState	 
	* @memberOf MusicMiniView	 
	* @method 	 */	
	getFocusState: function(){
		return self.focusState;
	},

	playbackKeyPress : function(keycode, keytype) {		
		if( keytype == Volt.EVENT_KEY_RELEASE ){
			return true;
		}		
		
		switch(keycode){
			 case KeyCode.pause:{
    			if(self.playIns.getState()==3){		//playing
    				self.playIns.pause();
    			}	
			 	break;
			 }
			 case KeyCode.play:{
    			if(self.playIns.getState()==4){	//pause
    				self.playIns.resume();  			
    			}
			 	break;
			 }
			 case KeyCode.fastforward: {
			 	self._progressFF();
				break;
			 }
			 case KeyCode.backforward: {
			 	self._progressRW();
				break;
			 }
			 case KeyCode.next: {
			 	self.playIns.playNext(); 
				break;
			 }
			 case KeyCode.pre: {
			 	self.playIns.playPre(); 
				break;
			 }	
    		 default:
    	    	break;			 
		}
	},

	/**fast forward callback 
	* @name _progressFF	 
	* @memberOf MusicMiniView	 
	* @method 	 */		
    _progressFF: function() {
    	if( self.playIns != null ){
	    	self.playIns.jumpForward(10000);
    	}
    },

	/**rewind back callback 
	* @name _progressRW	 
	* @memberOf MusicMiniView	 
	* @method 	 */		
    _progressRW: function() {
    	if( self.playIns != null ){    
    		self.playIns.jumpBackward(10000);    
    	}
    },	

	/**skip to next music file
	* @name skipToNext	 
	* @memberOf MusicMiniView	 
	* @method 	 */	
	skipToNext: function() {
    	if( self.playIns != null ){    
			/*
			if ( self.playIns.playNextWithoutMsg()==false ){
				EventMediator.trigger(EventType.EVENT_TYPE_PLAYER_ALL_FILEDONE);
			}
			*/
    	}		
    },

	/**the callback for get thumbnail failed
	* @name getThumbnailFailed	 
	* @memberOf MusicMiniView	 
	* @param {failedPath} the get thumbnail failed file path
	* @method 	 */	
	getThumbnailFailed : function(failedPath) {
		if(self.destroyState==true){
			return;
		}
		var currIdx = self.playIns.getCurrentIdx();
		var item = self.playIns.getData(currIdx);
		var currPath = item.get('filePath');		

		if( self.thumbImg != null && failedPath==currPath){
			self.thumbImg.src = resMgr.getImgPath()+'/default_thumb/mc_music_thumbnail_play_default.png';
		}	
	},	

	/**the callback for get thumbnail successful
	* @name getThumbnailSuccessful	 
	* @memberOf MusicMiniView	 
	* @param {index} the get thumbnail successful index
	* @method 	 */	
	getThumbnailSuccessful: function(index) {
		if(self.destroyState==true){
			return;
		}	
		var currIdx = self.playIns.getCurrentIdx();
		if( self.thumbImg != null && index==currIdx){
			self.thumbImg.src = THUMB_BASE_PATH + 'Player' + currIdx + '.jpg';
		}
    },

	/**check the current playing music file's device ID
	* @name verifyDeviceDisconnectStatus	 
	* @memberOf MusicMiniView	 
	* @param {deviceID} the plug out device ID
	* @method 	 */		
	verifyDeviceDisconnectStatus: function( deviceID ) {
    	if( self.playIns != null ){    
			print('aaaaa ', self.playIns.getDeviceID(), deviceID );
			if ( self.playIns.getDeviceID() == deviceID ){
				return true;
			}
    	}

		return false;
    },	

	updatePlayState: function(){
		var currState = self.playIns.getState();
		print('current state is ', currState);

		switch( currState ){
			case 3:
				self.pauseBtn.src = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_pause.png';
				break;
			case 4:
				self.pauseBtn.src = resMgr.getImgPath()+'/music_player_icon/mc_play_icon_play.png'; 	
				break;
			default:
				break;
		}
    },

	/**get a string's width
	* @name _getStrWidth
	* @memberOf MusicMiniView	
	* @param {str} the target string
	* @param {fontSet} the fontsize of the text
	* @method 	 */	
	_getStrWidth: function( str, fontSet ) {
		var wgt = new TextWidget(str);
		wgt.font = fontSet;
		wgt.horizontalAlignment = 'left';
		wgt.singleLineMode = true;

		var res = wgt.width;

		wgt.destroy();

		return res;
    },
});

exports = MusicMiniView;

