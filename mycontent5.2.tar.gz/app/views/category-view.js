 /** 
 * @author  Zhao Rui (rui9527.zhao@samsung.com)
 * 			
 * @fileoverview  Provider device list for views 
 * @date    2014/08/13 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var loadTemplate = PanelCommon.loadTemplate;
var MainTemplate = PanelCommon.requireTemplate('main');
var EventMediator = RunTimeInfo.EventMediator;
var CommonInfo = Volt.require('app/common/define.js');
var CONST = CommonInfo.CONST;
var EventType = CommonInfo.EventType;
var FocusPos = CommonInfo.FocusPos;
var DeviceProvider = Volt.require("app/models/device-provider.js");
var launchParams = Volt.require("app/common/launch-params.js");
var ViewGlobalData = Volt.require("app/views/view-global-data.js");
var DeviceType = CommonInfo.DeviceType;
var self;
var LaunchedByAppID = CommonInfo.LaunchedByAppID;
var voiceGuide = Volt.require('app/common/voice-guide.js');
var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var Q = Volt.require('modules/q.js');
var CommMessageBox = Volt.require('app/views/comm-message-box.js');
var MessageType = CommonInfo.MessageType;
var mycontentWidth = RunTimeInfo.SceneResolution;

/**
 * Display CategoryView  
 * @param {Object} CategoryView items
 * @param 
 * @constructor
 * @extends {BaseView}
 */

var CategoryView = PanelCommon.BaseView.extend({
    template: MainTemplate.category,
    mainView : null,
    categoryList : null,
	categories: null,
	categoriesID: null,
	currentMountPath: null,
	currentID: -1,
	currentIndex: -1,
	currentText:'',
	currentType: null,
	bSamsungDevice: false,
	lastUsbDevicePos : 0,
	lastDLNADevicePos : 0,
	lastRaDevicePos:0,
	preCategoriesID:'',
	onRest:false,
	//popup:null,
	removeDeviceList: null,
    isWaitDevice:false,
    haloAni: null,
    haloAniListener: null,
    timeOut:null,
    
    /** Initialize CategoryView  	 
	* @name initialize	 
	* @memberOf CategoryView
	* @param {Object} the Parent view of this view
	* @method
	* @return {} 	 
	* */	
    initialize: function(parentView) {
        self = this;

        this.mainView = parentView;
        this.mainView.categoryView = this;
		this.categories = new Array();		
		this.categoriesID = new Array();
		this.removeDeviceList = new Array();
		this.setHaloAnimation();
	//	EventMediator.on(EventType.EVENT_TYPE_LANGUAGE_CHANGED, this.languageChanged, this);	
        EventMediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.expand, this);
        EventMediator.on('EVENT_MAIN_CATEGORY_BLUR', this.shrink, this);
		EventMediator.on(EventType.EVENT_TYPE_RESET, this.onReset, this);
		EventMediator.on(EventType.EVENT_TYPE_ON_ACTIVE_DELE_DEVICE, this.onActiveDeleteDevice, this);
		EventMediator.on(EventType.EVENT_TYPE_ADD_FIRST_DLNA_DEVICE, this.addFirstDlnaDevice, this);
		EventMediator.on(EventType.EVENT_TYPE_MYCONTENT_HALO_CATEGORY_PRESS, this.onCategoryItemSelect, this);
		EventMediator.on(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE, this.setCategoryFocusable, this);
		DeviceProvider.regsiterListener(self,self.onDeviceConnect,self.onDeviceDisconnect, self.onDeviceUpdate);

    },
    
    /** Destroy CategoryView  	 
	* @name destroy	 
	* @memberOf CategoryView
	* @method
	* @return {} 	 
	* */
    destroy:function(){
	    DeviceProvider.unregsiterListener(self,self.onDeviceConnect,self.onDeviceDisconnect, self.onDeviceUpdate);
	},
    /** Get interst device postion   	 
	* @name getInsertPos	 
	* @memberOf CategoryView
	* @param {enum} Device type , USB/DLNA/RA/PTP
	* @method 
	* @return {} 	 
	* */
    getInsertPos: function(type){
    	var insertPos = 0;
    	if(type === DeviceType.DEVICE_TYPE_USB || type === DeviceType.DEVICE_TYPE_PTP){
			//insertPos = self.lastUsbDevicePos;
 			insertPos = 0;//Usb new connect device , shoud display on first position	
	 	} else if(type === DeviceType.DEVICE_TYPE_DLNA){
	 		insertPos = self.lastUsbDevicePos +self.lastRaDevicePos + self.lastDLNADevicePos;
			
	 	} else if(type === DeviceType.DEVICE_TYPE_RA){
			insertPos = self.lastUsbDevicePos + self.lastRaDevicePos;
			
	 	} else {
	 		insertPos = self.lastUsbDevicePos + self.lastDLNADevicePos + self.lastRaDevicePos;
	 	}
	 	
    	return insertPos;
    },
    /** Increase inster device postion   	 
	* @name increaseInsertPos	 
	* @memberOf CategoryView
	* @param {enum} Device type , USB/DLNA/RA/PTP
	* @method
	* @return {} 	 
	* */
    increaseInsertPos : function(type){
    			
		if(type === DeviceType.DEVICE_TYPE_USB || type ===  DeviceType.DEVICE_TYPE_PTP){
			 self.lastUsbDevicePos++;
		} else if(type === DeviceType.DEVICE_TYPE_DLNA){
			self.lastDLNADevicePos++;
		} else if(type === DeviceType.DEVICE_TYPE_RA){
			self.lastRaDevicePos++;
		}
	},
	
	/** judge the tab changed or not   	 
	* @name isChangeTab	 
	* @memberOf CategoryView
	* @method
	* @return true or false 	 
	* */	
  isChangeTab:function(){
	
		if(RunTimeInfo.router && (RunTimeInfo.router.currentViewType == EViewType.eConnectUsbGuideView ||
		  RunTimeInfo.router.currentViewType == EViewType.eConnectPcGuideView ||
		  RunTimeInfo.router.currentViewType == EViewType.eConnectMobileGuideView)){
		  	print('isChangeTab >>>>>>>>>>  return true');
			return true;
		}
		else{
			print('isChangeTab >>>>>>>>>>  return false');
			return false;
		}
   },
   /** judge the the device exist or not   	 
	* @name isDeviceNameExist	 
	* @memberOf CategoryView
	* @method
	* @return {int} 	 
	* */
	isDeviceExist: function(deviceID){
		var i = 0;
		var index = -1;
		print('isDeviceNameExist >>>>>>>>>>>>> deviceID: ',deviceID);
		var categoriesCount = self.categoriesID.length;
		for(i = 0; i < categoriesCount; i++){
			if(deviceID == self.categoriesID[i]){
				print('Same device name index:', i);
				index = i;
				break;
			}
		}
		return index;
	},
    /** Get interst device postion   	 
	* @name onDeviceConnect	 
	* @memberOf CategoryView
	* @param {object} Device type , USB/DLNA/RA/PTP
	* @method 
	* @return {}	 
	* */
    onDeviceConnect: function(deviceInfo){
        print('[category-view.js] onDeviceConnect :',deviceInfo );
		Log.e("[category-view.js] onDeviceConnect :" );
    //   	print('---------------------------------tempCollect.length:', DeviceProvider.getDeviceCount());
     	try{
     	  
	       	var deviceDisplayName = deviceInfo.get('displayName');
			var deviceID = deviceInfo.get('id');
			
			//search self.removeDeviceList,
			print(" self.removeDeviceList.length ", self.removeDeviceList.length);
			for(var j = 0; j < self.removeDeviceList.length; j++){
				if(deviceID == self.removeDeviceList[j]){
					Log.e("onDeviceConnect delete device in removeDeviceList:" + deviceID);
					print("onDeviceConnect delete device in removeDeviceList:" + deviceID);
							//delete device
					self.removeDeviceList.splice(j,1);
					break;
				}		
			}
			
	       	if(self.mainView.msgbox && typeof self.mainView.msgbox.onButtonClick == 'function'){
				print(" self.mainView.msgbox onButtonClick  ");
	       		self.mainView.msgbox.onButtonClick();
	       	}


			print('CategoryView onDeviceConnect item name:' + deviceDisplayName + ', ID: ' + deviceID);
			Log.e("CategoryView onDeviceConnect item name:" + deviceDisplayName + ", ID: " + deviceID);
			
				
			var insertPos = 0;
	 		var type = deviceInfo.get('type');
			var sameDeviceIndex = self.isDeviceExist(deviceID);
		
			if(sameDeviceIndex != -1){
				print("update device to category tab");
				Log.e("update device to category tab");
				//if deviceDisplayName is exist in categories, updatge device name
				self.categories[sameDeviceIndex] = deviceDisplayName;
				self.categoryList.setTabText(deviceDisplayName, sameDeviceIndex);	
				
			}else{
				print("Add device to category tab");
				Log.e("Add device to category tab");
			 	self.categories.splice(0,0,deviceDisplayName);
		 		self.categoriesID.splice(0,0,deviceID);
				
		 		self.categoryList.addTab(deviceDisplayName,insertPos);
			}
		
			//reset focus to last focus 
			self.resetFocus();
			//if current view is connect pc/usb/mobile,  do not switch new c
			if(self.isChangeTab())
			{
				print('onDeviceConnect  >>>>>>>> current view is connection guide');
				return;
			}
		

	 		if(launchParams.getLauncherAppName() == LaunchedByAppID.APP_ID_SOURCE_LIST 
				&& launchParams.getDeviceType() == 'DLNA' 
				&& launchParams.getFirstUsedStatus() == true){
				if(deviceID == launchParams.getDLNADeviceId()){
					print('Find  dlna device ~~~~~~~~~~~~~~~~~~~~~~~~~~~deviceID :',deviceID);
					this.categoryList.changeTab(insertPos);
					launchParams.setFirstUsedStatus(false);
				}
			}
	   	}catch(e){
			print(" onDeviceConnect  e: ",e);
		}
		
    },
    
    onDeviceUpdate:function(device){
		print('category view onDeviceUpdate>>>>>>>>>>>>>>>>>>>>');
		Log.e("category view onDeviceUpdate>>>>>>>>>>>>>>>>>>>>");
		var bFind = false;
		if(device == null){
			Log.e("category view onDeviceUpdate device is null");
			return;
		}
	
		var deviceId = device.get('id');
		var type = device.get('type');
		var i = 0;
	    for(i = 0; i < self.categoriesID.length; i++) {
		    		    	
	    	if(self.categoriesID[i] == deviceId){
					
	    		print('[onDeviceUpdate] Device displayname :',self.categories[i]);
	    		Log.e("[onDeviceUpdate] Device displayname :" + self.categories[i]);
				bFind = true;
				break;
	    	}
	    }
		
		if(deviceId == self.currentID){
			print("update deviceId == self.currentID");
			Log.e("update deviceId == self.currentID");
			EventMediator.trigger(EventType.EVENT_TYPE_UPDATE_CUREENT_DEVICE_AVAILABLE_SIZE, type, device);			
		}
		
		var displayname = device.get('displayName');
		print("category view onDeviceUpdate New displayname:"+displayname);
		Log.e("category view onDeviceUpdate New displayname:"+displayname);
		
		if(bFind == true){		
			Log.e("category view onDeviceUpdate Find device index:"+i);
			self.categoryList.setTabText(displayname, i);
		}else{
			//if can not find , add it.
			Log.e("category view onDeviceUpdate Can not finde , add it  ");
			self.onDeviceConnect(device);
		}
		

	},
	
	 /** Add the first dlna device    	 
	* @name addFirstDlnaDevice	 
	* @memberOf CategoryView
	* @param {Object} Device type , USB/DLNA/RA/PTP
	* @method 
	* @return {}	 
	* */
	addFirstDlnaDevice:function(deviceInfo){
        print('[category-view.js] addFirstDlnaDevice :',deviceInfo );
    //   	print('---------------------------------tempCollect.length:', DeviceProvider.getDeviceCount());
       	
       	var deviceDisplayName = deviceInfo.get('displayName');
		var deviceID = deviceInfo.get('id');
		print('CategoryView item name:' + deviceDisplayName + ', ID: ' + deviceID);
		var insertPos = 0;
 		var type = deviceInfo.get('type');
 			
		insertPos = self.getInsertPos(type);
		self.increaseInsertPos(type);
	 	self.categories.splice(insertPos,0,deviceDisplayName);
 		self.categoriesID.splice(insertPos,0,deviceID);
		
 		this.categoryList.addTab(deviceDisplayName,insertPos);
		
		//reset focus to last focus 
		self.resetFocus();
		
		if(self.isChangeTab())
		{
			print('onDeviceConnect  >>>>>>>> current view is connection guide');
			return;
		}	
		

		
 		if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_SOURCE_LIST 
			&& launchParams.getDeviceType() == 'DLNA' 
			&& launchParams.getFirstUsedStatus() == true){
			if(deviceID == launchParams.getDLNADeviceId()){
				print('Find  dlna device ~~~~~~~~~~~~~~~~~~~~~~~~~~~deviceID :',deviceID);
				this.categoryList.changeTab(insertPos);
				launchParams.setFirstUsedStatus(false);
			}
		} 
		else { 
			if(insertPos == 0 && self.categories.length == 2){
				this.categoryList.changeTab(insertPos);
			} 		
		}

    },

	/** popupDestroy   	 
	* @name popupDestroy	 
	* @memberOf CategoryView
	* @method 
	* @return {}	 
	* */
    popupDestroy:function(){
    	print('category view popupDestroy');
		Log.e("category view device disconenct popup Destroy");
		//self.popup = null;
		self.mainView.msgbox = null;
		
		self.removeDevices(self.removeDeviceList);
		self.removeDeviceList = [];
		if(RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView){
			Log.e(" device disconnect popup destroy, current view is music, undim main view ");
			print(" device disconnect popup destroy, current view is music, undim main view ");
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_UNDIM);
		}
		
		print("category view popupDestroy self.mainView.isOptionPopupShown : "+self.mainView.isOptionPopupShown);
		if(self.mainView.isOptionPopupShown == false){	
			print("RunTimeInfo.router.currentViewType:"+RunTimeInfo.router.currentViewType);
			if ( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectMobileGuideView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectUsbGuideView ||
				 RunTimeInfo.router.currentViewType == EViewType.eConnectPcGuideView ){
			
				 print(" 22222222222 ");
				var currView = RunTimeInfo.router.getCurrentView();
				if( currView != null ){
					Volt.Nav.setRoot(currView.widget);
				}
				else {
					Volt.Nav.setRoot(self.mainView.widget);
				}
			}else{
				print("Set root to mainView.widget");
				Volt.Nav.setRoot(self.mainView.widget);
			}
			
		}else{
		
			print(" Do not set focus");
		}

		
	},
	/** Add the first dlna device    	 
	* @name showDevDisConnectMsgBox	 
	* @memberOf CategoryView
	* @param {String} disconnect device name
	* @method 
	* @return 	deferred.promise 
	* */
	showDevDisConnectMsgBox : function(name) {
		print('[category view] showDevDisConnectMsgBox name = ',name);
		Log.e("[category view] showDevDisConnectMsgBox name = " + name);
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_INFOWND);
		
		if(self.mainView.devPopup != null){
			print('[category view] showDevDisConnectMsgBox device list popup is not null');
			return;
		}
		var deferred =  Q.defer();
		//if (RunTimeInfo.router.currentViewType != EViewType.eMusicPlayerView){
			EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);

		//}	
		self.mainView.msgbox = new CommMessageBox();
		self.mainView.msgbox.setMsgBoxDestroyCb(self.popupDestroy);
		var disConText = resMgr.getText('COM_TV_SID_MIX_IS_DISCONNECTED');
		disConText = disConText.replace('<<A>>',name);		
		print('showDevDisConnectMsgBox >>>>>>>>  disConText:',disConText);
		self.mainView.msgbox.render(MessageType.eDisconnectUsb,disConText);
		
		deferred.resolve();
		return deferred.promise;
	},
	
	/** removeDevices    	 
	* @name removeDevices	 
	* @memberOf CategoryView
	* @param {Object} devices list
	* @method 
	* @return {}	 
	* */
	removeDevices:function(deviceList){
		print('Remove devices .... ');
		Log.e("Remove devices .... ");
		//////////////////////////////////////////////////
		var currentDeviceIndex = 0;
		var i = 0;
		print('removeDevices >>>>>>>>>>> deviceList.length:',deviceList.length);
		for(var j = 0; j < deviceList.length; j++){
		    for(i = 0; i < self.categoriesID.length; i++) {
		    		    	
		    	if(self.categoriesID[i] == deviceList[j]){
					
		    		print('[removeDevices] Device displayname :',self.categories[i]);
		    		break;
		    	}
		    }

			
			//delete device
			self.categories.splice(i,1);
	 		self.categoriesID.splice(i,1); 	
	
		 	
		 	//get current focus device index
		 	currentDeviceIndex = self.categoryList.currentTabIndex();
		 	print('[removeDevices] currentDeviceIndex  ', currentDeviceIndex);
		
			print('remove device index :',i);
			Log.e("remove device index :" + i);
			if(i >= 0 && i < self.categoryList.numberOfTab()){
		 		self.categoryList.removeTab(i);
		 	}
	
			if(self.isChangeTab())
			{
				print('removeDevices  >>>>>>>> current view is connection guide');
			//	return;
			}else{
			 	//if only if remove devic is selected device, adjust focus 
			 	if(currentDeviceIndex == i){
				 	var index = 0;
					//if it is not first one, move focus to previous device.
					if(i > 0){
						index = i - 1;
					}
					//if it is the first one, move focus to new first one device 
					else {
						index = 0;
					//	self.onSelectItem(index);
					}
					EventMediator.trigger(EventType.EVENT_TYPE_DISCONNECT_CURRENT_DEVICE,deviceList[j]);
					RunTimeInfo.disconnectCurrentDevice = true;
					print('removeDevices change index >>>>>>>>>>>>>>>>> index:',index);
					Log.e("removeDevices change index >>>>>>>>>>>>>>>>> index:" + index);
					
					EventMediator.trigger('EVENT_MAIN_POPUP_HIDE');
					
					self.categoryList.changeTab(index);					
			 	}
			}
		}
			
	},
	isShowDisconnenctPopup:function(){
		print(" isShowDisconnenctPopup ");
		if(RunTimeInfo.isShowDisconnectPop == false 
			|| RunTimeInfo.isLoadingShown == true){
			Log.e("isShowDisconnenctPopup return false ");
			print("isShowDisconnenctPopup return false ");
			return false;
		}

		return true;

	},
    /** Device disconnect callback 	 
	* @name onDeviceDisconnect	 
	* @memberOf CategoryView
	* @param {int} device ID
	* @param {enum} Device type , USB/DLNA/RA/PTP
	* @method
	* @return {}	 	 
	* */
    onDeviceDisconnect: function(deviceID,deviceType){
   		Log.e("[category-view.js] onDeviceDisconnect device id:" + deviceID + "deviceType :" + deviceType);

   		print("[category-view.js] onDeviceDisconnect device id:",deviceID, 'deviceType :',deviceType);
   		//var deviceType = DeviceProvider.getDeviceInfo(deviceID);
	    print('onDeviceDisconnect  length:', DeviceProvider.getDeviceCount());
		
		self.removeDeviceList.push(deviceID);

		//find remove device name, fill in disconnect popup
		var i = 0;
	    for(i = 0; i < self.categoriesID.length; i++) {
		    		    	
		    	if(self.categoriesID[i] == deviceID){
					
		    		print('[onDeviceDisconnect] Device displayname :',self.categories[i]);
		    		Log.e("[onDeviceDisconnect] Device displayname :" + self.categories[i]);

					break;
		    	}
	    }
	    
	    var progressPopup = self.mainView.popup;
	    if(RunTimeInfo.isSendPopupShow && progressPopup && progressPopup.isWorkingDevice(deviceID))
	    {
	    	if(typeof self.mainView.hideSendPopup == 'function'){
				print("Category view onDeviceDisconnect  hideSendPopup ");
				Log.e("Category view onDeviceDisconnect  hideSendPopup ");
		    	self.mainView.hideSendPopup();
    		}
	    }
	    print("[category-view.js] onDeviceDisconnect isShowDisconnectPop:"+RunTimeInfo.isShowDisconnectPop);
		// show disconnect popup
		if(self.isShowDisconnenctPopup() == true){
			if(self.categories[i] == undefined){
				Log.e(" self.categories[i]  == undefined ");
				return;
			}			
			if(self.mainView.msgbox == null){
				Log.e("onDeviceDisconnect Show disconnect popup");
				print("onDeviceDisconnect Show disconnect popup:",RunTimeInfo.router.currentViewType);
				if( RunTimeInfo.router.currentViewType == EViewType.eMusicPlayerView){
					var i=-1;
				    for(i = 0; i < self.categoriesID.length; i++) {
			    		    	
				    	if(self.categoriesID[i] == deviceID){
				    		print('[removeDevices] Device displayname :',self.categories[i]);
				    		break;
				    	}
				    }
				 	var currentDeviceIndex = self.categoryList.currentTabIndex();
					print('currentDeviceIndex'+currentDeviceIndex+",i:"+i);
				 	if(currentDeviceIndex == i){
						self.showDevDisConnectMsgBox(self.categories[i]);
			 		}else{
			 	
						print("Mycontent is Suspend remove device");
						Log.e("Mycontent is Suspend remove device");
						self.removeDevices(self.removeDeviceList);
						self.removeDeviceList = [];
						
					}
				}
				else{
					self.showDevDisConnectMsgBox(self.categories[i]);
				}

				
			}else{
				try{
				print('onDeviceDisconnect update disconenct popup : ' + self.categories[i]);
				var disConText = resMgr.getText('COM_TV_SID_MIX_IS_DISCONNECTED');
				disConText = disConText.replace('<<A>>',self.categories[i]);	
				print("self.mainView.msgbox:"+self.mainView.msgbox);
				if(typeof self.mainView.msgbox.setMsgBoxContentText == 'function'){
					self.mainView.msgbox.setMsgBoxContentText(disConText);
				}
				print('Disconnect popup is exist..');
				Log.e("Disconnect popup is exist..");
				}catch(e){
					print("onDeviceDisconnect update disconenct popup e:"+e);
				}
			}
		}else{
			//remove device
			Log.e("Mycontent is deactive >>>>>>   just remove all device, do not show disconnect popup");
			print("Mycontent is deactive >>>>>>   just remove all device, do not show disconnect popup");

			print("RunTimeInfo.SuspendFlag:"+RunTimeInfo.SuspendFlag);
			Log.e("RunTimeInfo.SuspendFlag:"+RunTimeInfo.SuspendFlag);
			
			if(RunTimeInfo.SuspendFlag != false || RunTimeInfo.isLoadingShown == true){
				print("Mycontent is Suspend remove device");
				Log.e("Mycontent is Suspend remove device");
				self.removeDevices(self.removeDeviceList);
				self.removeDeviceList = [];
			}
			print('Category lenght :', self.categoryList.numberOfTab());
			print('categoriesID lenght :', self.categoriesID.length);
			print('categories lenght :', self.categories.length);
		}
   	
    },
	/** Category render function
	* @name render	 
	* @memberOf CategoryView
	* @method
	* @return {Object} 	 
	* */
    render: function() {
        print('[category-view.js] CategoryView.render');
	    var deviceItem = null;
	    print('Device count:', DeviceProvider.getDeviceCount());
		var parent = this.mainView.widget.getDescendant('main-category-container');
		var ct = loadTemplate(this.template, null, parent);
        this.setWidget(ct);

		
	    this.categoryList = this.widget;

		this.categoryList.setTabTextColor("highlighted", 255, 255, 255, 255);
		//this.categoryList.setTabTargetHeight(72,108);
	    var insertPos = 0;
	    //add connection guide		
		this.categories[0] = resMgr.getText('TV_SID_CONNECTION_GUIDES');
		this.categoriesID[0] = 'Connection Guide';
		this.categoryList.addTab(this.categories[0], 0);	  

	    for(var i = DeviceProvider.getDeviceCount(); i > 0 ; i--) {
	    	var deviceDisplayName = DeviceProvider.getDeviceByIndex(i-1).get('displayName');
	    	var deviceId = DeviceProvider.getDeviceByIndex(i-1).get('id');
	    	var type = DeviceProvider.getDeviceByIndex(i-1).get('type');
			insertPos = self.getInsertPos(type);
			self.increaseInsertPos(type);
			print('=============================== insertpos : ',insertPos);
			Log.e("=============================== insertpos : " + insertPos);
	    	self.categoriesID.splice(insertPos,0,deviceId);
	    	self.categories.splice(insertPos,0,deviceDisplayName);
	    	this.categoryList.addTab(deviceDisplayName,insertPos);	    	
	    }
		 
		var index = self.getIndexByLaunchParams();  
		if(index != -1){
			//var  index = self.getIndexByLaunchParams();  
			print('[category-view.js] CategoryView.render index;',index);
			
			 if(launchParams.getDeviceType() == 'DLNA'){
				launchParams.setFirstUsedStatus(false);
			 } 
			self.categoryList.changeTab(index);
		} else {
			index = 0;
			print(" launch by  "+launchParams.getLauncherAppName());
			print(" launch by firstscreen "+launchParams.getLauncherAppName());
			Log.e(" launch by firstscreen ");
			self.categoryList.changeTab(0);					
			print('Wait dlna device connect');
			Log.e('Wait dlna device connect');
		}
		print("self.categoriesID[index]:"+self.categoriesID[index]);
		if(self.categoriesID[index] != 'Connection Guide'){
			
			var devItem = DeviceProvider.getDeviceInfo(self.categoriesID[index]);
				
			if(devItem != null){	
				self.sendEnterMyContentKPILog(devItem);
			}else{
				print('[category-view] onSelectItem------------ devItem is null');
				Log.e("[category-view] onSelectItem------------ devItem is null");		
			}	
		}
		EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
		
        return this;
    },
    
	sendEnterMyContentKPILog:function(devItem){
		print(" sendEnterMyContentKPILog ");
		var deviceType = 0;
		deviceType = devItem.get('type');
		print(" sendEnterMyContentKPILog deviceType:"+deviceType);
		Log.e(" sendEnterMyContentKPILog deviceType:"+deviceType);
		
		var kpiLogDetail = '';
		if(deviceType == DeviceType.DEVICE_TYPE_PTP){
			kpiLogDetail = 'PTP';
		}else if(devItem.get('uhd') == true){
			kpiLogDetail = 'UHD_VP';
		}
		
		Volt.KPIMapper.addEventLog('MY_ENTER_GUIDE_PG', {
        	d: {
        		type: (deviceType == DeviceType.DEVICE_TYPE_DLNA ? 'DLNA' : 'USB'),
				detail: kpiLogDetail,
				pa: Volt.KPIMapper.getPreviousApp(),
    		}
		});

	},
	onKeyEvent:function(keycode, keytype){
  		return false;
  	},
  	/** get DeviceId By Luanch Params
	* @name getDeviceIdByLuanchParams	 
	* @memberOf CategoryView
	* @method
	* @return deviceId 	 
	* */
	getDeviceIdByLuanchParams:function(){
		var deviceId = null;
		var deviceType = launchParams.getDeviceType();
    	print('[Category view][getDeviceIdByLuanchParams] deviceType : ',deviceType);
    	switch(deviceType){
    		case DeviceType.DEVICE_TYPE_USB:{
		    	var deviceMountPath = launchParams.getDeviceMountPath();
		    	print('[Category view][getDeviceIdByLuanchParams]   deviceMountPath ', deviceMountPath);
		    	deviceId = DeviceProvider.getIdByMountPath(deviceMountPath);
		    	print('[Category view][getDeviceIdByLuanchParams]   deviceId ', deviceId);
    			break;
    		}
    		case DeviceType.DEVICE_TYPE_PTP:{
    			var bus = launchParams.getDeviceBus();
    			var address = launchParams.getDeviceAddress();
    			print('[getDeviceIdByLuanchParams]   bus :',bus, 'address : ',address);
    			deviceId = DeviceProvider.getIdByBusAddress(bus,address);
		    	print('[Category view][getDeviceIdByLuanchParams]   deviceId ', deviceId);
		    	break;
    		}
    		case DeviceType.DEVICE_TYPE_DLNA:{
    			deviceId = launchParams.getDLNADeviceId();
    			print('[Category view][getDeviceIdByLuanchParams]   dlna device id ', deviceId);
    			break;
    		}
    		default :{

    			break;
    		}
    	}
		return deviceId;
	},
   	/** Category render function
	* @name getCategoryIndex	 
	* @memberOf CategoryView
	* @method 
	* @return {int} 	 	 
	* */
    getIndexByLaunchParams : function(){
    //	var index = -1;  //for welcome page. 
    	var index = -1;
    	var deviceId = null;
		
    	deviceId = self.getDeviceIdByLuanchParams();
    	if(deviceId == null){	
			print("getIndexByLaunchParams deviceId == null ");
			Log.e("getIndexByLaunchParams deviceId == null ");
	
		}else{
	    	for(var i = 0; i < self.categoriesID.length; i++ ){
	    		if(self.categoriesID[i] != null && self.categoriesID[i] != undefined && self.categoriesID[i] == deviceId){
	    			print('[getIndexByLaunchParams]  finde id ',deviceId);  			
					Log.e("[getIndexByLaunchParams]  finde id " + deviceId);  	
	    			index = i;
	    			break;    			
	    		}
	    	}
		}
		Log.e("getIndexByLaunchParams  return index :"+ index.toString());
		print("getIndexByLaunchParams  return index :"+ index.toString());
    	return index;
    },
    
    /** Get device display name by category list index
	* @name getDeviceNameByCategoryIndex	 
	* @memberOf CategoryView
	* @param {int} category list index
	* @method
	* @return {int} 	 
	* */
    getDeviceNameByCategoryIndex : function(index){
    	return self.categories[index];
    },

	/** set category view focus disable
	* @name setFocusableFalse	 
	* @memberOf CategoryView
	* @param {boolean} flag of the focus able.
	* @method
	* @return {} 	 
	* */
    setCategoryFocusable : function(flag){
    	print('category-view.js setCategoryFocusable = ',flag);
    	this.widget.custom.focusable = flag;
		print(" setCategoryFocusable Disabla category tab click ");
		//self.categoryList.enable(flag);
		self.categoryList.setEnableChangeTab(flag);
		Volt.Nav.reload();
    },
    
    onTimeOut:function(){
    	print("Category  onTimeOut");
		Log.e("Category  onTimeOut");
		self.onSelectItem(self.currentIndex);
		
	},
	
    onCategoryItemSelect:function(index){
	    print("onCategoryItemSelect index:"+index);
		Log.e("onCategoryItemSelect index:"+index);
		
		self.currentIndex = index;
		
		if( self.timeOut!= null ){
			print("onUsbDeviceConnect clear time");
			Volt.clearTimeout(self.timeOut);
			self.timeOut = null;
		}
		self.timeOut =  Volt.setTimeout(self.onTimeOut, 250);	

	},
    /** Category list item select callback function
	* @name onSelectItem	 
	* @memberOf CategoryView
	* @param {index} category list index
	* @method
	* @return {}  	 
	* */
	onSelectItem:function(index) {
		var type;
		print('category-view.js, onSelectItem, index : ',index);
		print('category-view.js, onSelectItem, index : ',self.categories[index]);
		Log.e("gategory-view.js, onSelectItem, index : " + index);
		Log.e("gategory-view.js, onSelectItem, device name : " + self.categories[index]);
		try {
			
			self.onRest = false;
			
			ViewGlobalData.isCategoryFocus = true;
			print('category-view.js onSelectItem flag:',ViewGlobalData.isCategoryFocus);
			self.currentIndex = index;
			
			//if currenct select category is not connection guide, use device id to get device information
			if(self.categoriesID[index] != 'Connection Guide'){
				if( launchParams.isLaunchForMusicPlayer()==false){
					EventMediator.trigger(EventType.EVENT_TYPE_BEGIN_REQUEST_DATA);
				}
				var devItem = DeviceProvider.getDeviceInfo(self.categoriesID[index]);
				
				if(!devItem){
					print('[category-view] onSelectItem------------ devItem is null');
					Log.e("[category-view] onSelectItem------------ devItem is null");
					return ;
				}	

				self.currentID = devItem.get('id');
				Log.e("onSelectItem self.currentID: "+self.currentID);
				self.currentType = devItem.get('type');
				self.bSamsungDevice = devItem.get('bSamsungDevice');
				if (devItem.get('type') == DeviceType.DEVICE_TYPE_USB ){
					print('[category-view], usb path:', devItem.get('mountPath'));
					self.currentMountPath = devItem.get('mountPath');			
				}
				else if (devItem.get('type') == DeviceType.DEVICE_TYPE_DLNA ){
					print('[category-view], DLNA');
					self.currentMountPath = devItem.get('id');
				}	
				type = devItem.get('type');
				DeviceProvider.setCurrentDeviceId(type,devItem);
			} 
			else {
				type = 'Connection Guide';
				self.currentID = 'Connection Guide';
				self.currentType = '';
				DeviceProvider.setCurrentDeviceId(null,null);
			}

			//if previous category is connection guide, 
			if(self.preCategoriesID == 'Connection Guide' && self.currentID != 'Connection Guide' ){
				if(RunTimeInfo.isEditMode != true){
					print(" oncategory item change, show setting button ");
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_SETTING);
				}
			}
			
			self.preCategoriesID = self.currentID;		
			
			print("oncategory item change Play voice");
			var ttsTxt = self.categories[index];
			voiceGuide.queuingPlay(ttsTxt);
		
			EventMediator.trigger(EventType.EVENT_TYPE_CATEGORY_CHANGE, type, devItem);
		}catch(e){
			print('[category-view.js, onSelectItem]  e:', e);
			Log.e("[category-view.js, onSelectItem]  e:" + e);
		}
   },
    
    events: {
        'NAV_SELECT':'onSelect',
        'NAV_FOCUS':'onFocus',
        'NAV_BLUR':'onBlur'
    },

	/** check if is in folder function
	* @name isInFolder	 
	* @memberOf CategoryView
	* @param {} 
	* @method 
	* @return {boolean}	 
	* */
	isInFolder: function(){
		var deviceInfo = DeviceProvider.getDeviceInfo(this.currentID);
		var devType = null;
		if(deviceInfo != null){
			devType =  deviceInfo.get('type');
		}
		if(devType == DeviceType.DEVICE_TYPE_USB){
			if(ViewGlobalData.parentFielPathStack.length > 0){
				return true;
			}
		}
		else if(devType == DeviceType.DEVICE_TYPE_DLNA){
			if(ViewGlobalData.dlnaContentidStack.length > 0){
				return true;
			}
		}
		return false;
    },
    
	/** Category list get focus callback function
	* @name onFocus	 
	* @memberOf CategoryView
	* @param {Object} Category list
	* @method
	* return {} 	 
	* */
    onFocus: function(widget){
      //  print('[category-view.js] CategoryView  onFocus =',widget.id);
		if(self.isInFolder() == true || RunTimeInfo.isEditMode == true){
			print('[category-view.js] onFocus  isInFolder');
			return;
		}
		RunTimeInfo.CategoryFocus = true;
		EventMediator.trigger('EVENT_MAIN_CATEGORY_FOCUS');
	        
      //  EventMediator.trigger(EventType.EVENT_TYPE_FOCUS_CHANGE, FocusPos.FOCUS_CATEGORY);

		if(ViewGlobalData.firstLaunch == false){
			var focusIndex = self.categoryList.currentTabIndex();
			print(' category onFocus >>>>>>>>>>>>>>>>>>> focusIndex',focusIndex);
			var ttsTxt = self.categories[focusIndex];
			if(ttsTxt != undefined && typeof(ttsTxt) == 'string'){
				voiceGuide.queuingPlay(ttsTxt);

			}
		}

    },
	/** Category list lost onBlur callback function
	* @name onBlur	 
	* @memberOf CategoryView
	* @param {Object} Category list
	* @method
	* return {} 	 
	* */
    onBlur: function(widget){
        print('[category-view.js] CategoryView.onBlur');
		if(self.isInFolder() == true || RunTimeInfo.isEditMode == true){
			print('[category-view.js] onBlur  isInFolder');
			return;
		}
		RunTimeInfo.CategoryFocus = false;
		var focusIndex = self.categoryList.currentTabIndex();
		var devDisplayName = self.getDeviceNameByCategoryIndex(focusIndex);
		self.mainView.lastFocusDevInfo = self.getLastFocusDevInfo(devDisplayName);
	//	EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');

    },
    /** get Current Category Name 
	* @name getCurrentCategoryName	 
	* @memberOf CategoryView
	* @method
	* return {String} 	 
	* */
	getCurrentCategoryName: function(){
        print('[category-view.js] getCurrentCategoryName');
		var devDisplayName = self.categoryList.currentTabText();
		
		return devDisplayName;
	},
	 /** get Current Category Index 
	* @name getCurrentCategoryIndex	 
	* @memberOf CategoryView
	* @method
	* return {int} 	 
	* */
	getCurrentCategoryIndex: function(){
		
		var focusIndex = self.categoryList.currentTabIndex();
		Log.e("getCurrentCategoryIndex >>> focusIndex :" + focusIndex);
		return focusIndex;
	},
	 /** get Last Focus DevInfo 
	* @name getLastFocusDevInfo	 
	* @memberOf CategoryView
	* @method
	* return {Object} 	 
	* */
	getLastFocusDevInfo: function(devName){
		print('getLastFocusDevInfo device name = ',devName);
		var devInfo = null;
		for(var i=0;i<DeviceProvider.getDeviceCount();i++){
			devInfo = DeviceProvider.getDeviceByIndex(i);
			if(devName == devInfo.get('displayName')){
				print('found device name = ',devName);
				break;
			}
		}
		return devInfo;
    },
    /** Set animation 
	* @name setHaloAnimation	 
	* @memberOf CategoryView
	* @method
	* return {} 	 
	* */
	setHaloAnimation: function(){
		this.haloAni = new MultiObjectTransition();
		this.haloAniListener = new MultiObjectTransitionListener();
		this.haloAni.temp = this;
		this.haloAniListener.onStart = function(transition)
		{
		}
		this.haloAniListener.onVia = function(transition)
		{
		}
		this.haloAniListener.onStoped = function(transition, isFinished)
		{ 
             if (isFinished)
             {
                   transition.temp.isAnimating = false;
             }
		}
		this.haloAni.addListener(this.haloAniListener);
	},
	
    /** When category list got focus , expand widget
	* @name expand	 
	* @memberOf CategoryView
	* @method
	* @return {} 	 
	* */
    expand: function() {
        print('[category-view.js] CategoryView.expand');
		if(this == null){
			print('[category-view.js] CategoryView is null');
			return;
		}
        var parent = this.mainView.widget.getDescendant('main-category-container');

		this.isAnimating = true;
		if (this.haloAni){
			this.haloAni.setDuration(CONST.MENU_ANIM_DURATION);
			this.haloAni.AddObjectDestination(parent, "y", 144-36);
			this.haloAni.AddObjectDestination(parent, "size", {w:mycontentWidth, h:108});

			this.haloAni.AddObjectDestination(this.widget, "y", 0);
			this.haloAni.AddObjectDestination(this.widget, "size", {w:mycontentWidth, h:108});
			this.haloAni.play();
		}

        
    },
    
	/** When category list lost focus , shrink widget
	* @name expand	 
	* @memberOf CategoryView
	* @method
	* @return {}  	 
	* */
    shrink: function() {
        print('[category-view.js] CategoryView.shrink');
		if(this == null){
			print('[category-view.js] CategoryView is null');
			return;
		}
		var parent = this.mainView.widget.getDescendant('main-category-container');


		this.isAnimating = true;
		if (this.haloAni){
			this.haloAni.setDuration(CONST.MENU_ANIM_DURATION);
			this.haloAni.AddObjectDestination(parent, "y", 144);
			this.haloAni.AddObjectDestination(parent, "size", {w:mycontentWidth, h:72});
			this.haloAni.AddObjectDestination(this.widget, "y", 0);
			this.haloAni.AddObjectDestination(this.widget, "size", {w:mycontentWidth, h:72});

			this.haloAni.play();
		}

    },
    
    /** Get the first Usb device index
	* @name expand	 
	* @memberOf CategoryView
	* @method
	* @return {}  	 
	* */	
    selectFirstUsbDevice:function(){
    	
    //	ViewGlobalData.firstLaunch = true;	
    	print('[category-view.js] -----ViewGlobalData.firstLaunch ==' + ViewGlobalData.firstLaunch);	
		var index = 0;
		var item = DeviceProvider.getLastestUSBDevice();
		if(item != null && item != undefined){
			var id = item.get('id');
			for(var i = 0; i < self.categoriesID.length; i++){
				if(id  == self.categoriesID[i]){		
					print('selectFirstUsbDevice find device >>>>>>>>>>>>>>>>  i:',i);
					index = i;
					break;
				}
			}
		}
		
		this.categoryList.changeTab(index);
	},
	
	/** Get the lastest DLNA device index
	* @name expand	 
	* @memberOf CategoryView
	* @method
	* @return {}  	 
	* */	
    selectLastestDLNADevice:function(){    	
    //	ViewGlobalData.firstLaunch = true;	
		var index = 0;
    	print('[category-view.js] -----selectLastestDLNADevice');	
		var item = DeviceProvider.getLastestDLNADevice();
		if(item != null && item != undefined){
			var id = item.get('id');
			for(var i = 0; i < self.categoriesID.length; i++){
				if(id == self.categoriesID[i]){		
					print('selectLastestDLNADevice find device >>>>>>>>>>>>>>>>  i:',i);
					index = i;
					break;
				}
			}
			
		}
		this.categoryList.changeTab(index);
	},
	/** reset the app
	* @name onReset	 
	* @memberOf CategoryView
	* @method
	* @return {}  	 
	* */
	onReset : function(instanceOnFlag){
		Log.e(" cateory view onReset instanceOnFlag: "+instanceOnFlag);
		print(" [cateory-view.js]--- onReset instanceOnFlag: "+instanceOnFlag);
		self.onRest = true;
		var index = 0;
		print("Enable setEnableChangeTab ");
		self.categoryList.setEnableChangeTab(true);
		
		if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_USB_LAUNCHER ||
		launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_PVR_RECORDER ||
		launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_SOURCE_LIST)
		{
			index = self.getIndexByLaunchParams();   
			
			print('[category-view.js]onReset >>>>>>>>>>>>>>>>>>>>>>>> index',index);
			Log.e("onReset >>>>>>>>>>>>>>>>>>>>>>>> index" + index);
			if(index < 0 || index >= self.categoryList.numberOfTab()){
				print('onReset >>>>>>>>>>>>>>>>>>>>>>>> invailid index');
				Log.e("onReset >>>>>>>>>>>>>>>>>>>>>>>> invailid index");
				self.categoryList.changeTab(0);
				index = 0;
				self.isWaitDevice = true;
				
			}else{
				var focusIndex = self.categoryList.currentTabIndex();
				print('category-view.js, onReset , not Same device index device :' + self.categories[index]);
				print('category-view.js, onReset , not Same device focusIndex device :' + self.categories[focusIndex]);
				print('category-view.js, onReset , not Same device focusIndex:' + focusIndex);
				print("category-view.js, onReset , not Same device self.currentIndex:"+self.currentIndex);
				Log.e("category-view.js, onReset , not Same device self.currentIndex:"+self.currentIndex);
				Log.e("category-view.js, onReset , not Same device focusIndex:" + focusIndex);

				if (focusIndex != index){
					//this.categoryList.changeTab(20);
					this.categoryList.changeTab(index);
					
				}else{		
					print(" category-view.js, onReset ,  Same device");
					Log.e(" category-view.js, onReset ,  Same device  call onSelectItem");
					this.categoryList.changeTab(index);
					self.onSelectItem(index);
				}
			}
		} else {			
			if(instanceOnFlag == true){
				Log.e(" instanceOnFlag  change tab to 0");
				print(" [cateory-view.js]-- onReset---else-- instanceOnFlag: "+instanceOnFlag);
				this.categoryList.changeTab(0);
				index = 0;
			}else {
				index = self.getLastFocusDeviceIndex();
				print('onReset launch by firstscreen >>>>>>>>>>>>>>>>>>>>>>>> focusIndex : ',index);	 
				Log.e("onReset launch by firstscreen>>>>>>>>>>>>>>>>>>>>>>>> focusIndex : " + index);	 
				if(index < 0 || index >= self.categoryList.numberOfTab()){
					//if index is invailid, set index = 0;
					print('onReset launch by firstscreen >>>>>>>>>>>>>>>>>>>>>>>> invailid index');
					Log.e("onReset launch by firstscreen >>>>>>>>>>>>>>>>>>>>>>>> invailid index");
					self.categoryList.changeTab(0);
					index = 0;
					self.isWaitDevice = true;
				}else{
					this.categoryList.changeTab(index);
					self.onSelectItem(index);
				}
			}
			
		}
		print(" cateory view onReset  send kpi log, device id: "+self.categoriesID[index]);
		if(self.categoriesID[index] != 'Connection Guide'){

			var devItem = DeviceProvider.getDeviceInfo(self.categoriesID[index]);
				
			if(devItem != null){	
				self.sendEnterMyContentKPILog(devItem);				
			}else{
				print('[category-view] onSelectItem------------ devItem is null');
				Log.e("[category-view] onSelectItem------------ devItem is null");		
			}	
		}
	},
	/** get Last Focus Device Index
	* @name getLastFocusDeviceIndex	 
	* @memberOf CategoryView
	* @method
	* @return {int}  	 
	* */
	getLastFocusDeviceIndex : function(){
		var index = 0;
		for(var i = 0; i < self.categoriesID.length; i++){
			if(self.currentID  == self.categoriesID[i]){
				index = i;
				break;
			}

		}
		print('getLastFocusDeviceIndex >>>>>>>>>>>>>>>>> index:',index);
		return index;
	},
	/** reset Focus
	* @name getLastFocusDeviceIndex	 
	* @memberOf CategoryView
	* @method
	* @return {}  	 
	* */
	resetFocus : function(){
		var focusIndex = self.categoryList.currentTabIndex();
		print('resetFocus  >>>>>>>>>>>>>>>>>>>>>> Current focus index: ',focusIndex);
		Log.e("resetFocus  >>>>>>>>>>>>>>>>>>>>>> Current focus index: " + focusIndex);
		if(focusIndex != -1 && focusIndex != undefined){
			
			self.currentIndex = focusIndex;
			print(" resetFocus change self.currentIndex to : "+self.currentIndex);
			Log.e(" resetFocus change self.currentIndex to : "+self.currentIndex);
			
			self.categoryList.changeTab(focusIndex);
		}

	},
	/** judge the language changed or not
	* @name languageChanged	 
	* @memberOf CategoryView
	* @method
	* @return {}  	 
	* */
	languageChanged:function(){
		print('languageChanged  >>>  ');
		if(self.categoryList != null){
			var text = resMgr.getText('TV_SID_CONNECTION_GUIDES');
			var count = self.categoryList.numberOfTab();
			print('languageChanged >>> self.categoryList count:',count);
			self.categoryList.setTabText(text, count-1);
		}
	},
	
	onActiveDeleteDevice : function(){

		print("onActiveDeleteDevice : ");
		Log.e("onActiveDeleteDevice : ");


		self.removeDevices(self.removeDeviceList);
		self.removeDeviceList = [];
	},
});

exports = CategoryView;
