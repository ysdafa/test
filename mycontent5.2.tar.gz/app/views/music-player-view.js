 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Music Player view 
 * @date    2014/07/10 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var _ = Volt.require('modules/underscore.js')._;
var resMgr = Volt.require('app/controller/resource-controller.js');
var BaseView = Volt.BaseView;
var BaseModel = Volt.require("app/models/base-model.js");
var MusicModel = Volt.require("app/models/music-model.js");
var CommonInfo = Volt.require("app/common/define.js");
var MsgBoxType = CommonInfo.MsgBoxTemplateType;
var KeyCode = CommonInfo.KeyCode;
var EItemType = CommonInfo.EItemType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var EViewType = CommonInfo.EViewType;
var EventType = CommonInfo.EventType;
var MessageType = CommonInfo.MessageType;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var Q = Volt.require('modules/q.js');
var MusicPlayerViewTemplate = Volt.require('app/templates/1080/musicplayer-view-template.js');
var playerController = Volt.require('app/controller/play-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
//PanelCommon.mapWidgets(['AutoScrollTextWidget','ResizeableGrid']);
var loadTemplate = PanelCommon.loadTemplate;
var CommMessageBox = Volt.require('app/views/comm-message-box.js');
var launchParams = Volt.require("app/common/launch-params.js");
var LaunchedByAppID = CommonInfo.LaunchedByAppID;
var MusicPlayerCtrlView = Volt.require('app/views/musicplayer-control-view.js');
var MusicPlayerListView = Volt.require('app/views/musicplayer-list-view.js');
var BalloonTips = Volt.require('app/views/balloon-tips.js');
var voiceGuide = Volt.require('app/common/voice-guide.js');	
var mycontentWidth = RunTimeInfo.SceneResolution;
var self = null;
var CELL_ID = "CellId";
var THUMB_BASE_PATH = resMgr.getThumbPath();
var inputController = Volt.require('app/controller/input-controller.js');
var appConfig = Volt.require("app/common/app-config.js");

var MusicPlayerView = PanelCommon.BaseView.extend({
    template: MusicPlayerViewTemplate.container,
    templateList: MusicPlayerViewTemplate.list,    

    thumbArea: null,
	thumbImg: null,
    titleTxt: null,
    artistTxt: null,
    currTxt: null,
    totalTxt: null,
    progressWgt: null,
    musicList: null,
    upArrowImg: null,
    downArrowImg: null,
    closeBtn: null,
    exitBtn: null,
    ctrlBar: null,
    hdIcon: null,

	balloon: null,
	ProgressRightArrow: null,
	ProgressLeftArrow: null,
	
	progressPos: 0,

	msgBox: null,
	infoWindow: null,
    
    playIns: null,
    deviceID: -1,

	dmrIns: null,
    
    listTimer: null,
    dmrTimer: null,
    shown: false,
    isDim: false,

	preFocus: null,
	progressDrag: false,
    
    arrItems: [],
    coverWgt: null,

	musicView: null,
	focusWidget: null,
	setValueByTime: false,
	backColorPick: {r:37,g:37,b:37,a:255},

	txtColor: {},									//common text color in list
	focusTxtColor: {},								//focus text color in list
	currTxtColor: {},								//current playing text color in list

	ExitType: {
		RETURN_KEY:0,
		EXIT_KEY:1,
		STOP_KEY:2,
		ALL_DONE:3,
		DMR_STOP:4,
		DISCONNECT_DEVICE:5,
	},

	/**Initialize MusicPlayerView 	 
	* @name initialize	 
	* @memberOf MusicPlayerView	 
	* @constructs 	 */	
	initialize: function() {
		var initTime = new Date();
		Log.e("[music-time]start initialize music player view: " + initTime.getTime());	
		print("[music-player-view.js]-----initialize----");
		self = this;	

		self.txtColor = {r:255, g:255, b:255};
		self.focusTxtColor = {r:70, g:70, b:70, a:255};
		self.currTxtColor = {r:251, g:186, b:45, a:255};

		EventMediator.on(EventType.EVENT_TYPE_NOT_AVAILIABLE, this.showNAMessageBox, this);	
		EventMediator.on(EventType.EVENT_TYPE_UNSUPPORT_FILE, this.showUnSupportMsgBox, this);	
		EventMediator.on(EventType.EVENT_TYPE_UNFOUND_FILE, this.showSingleMsgBox, this);
		EventMediator.on(EventType.EVENT_TYPE_UPDATE_TOTALTIME, this.updateTotalTime, this);	
		EventMediator.on(EventType.EVENT_TYPE_UPDATE_CURRENTTIME, this.updateTime, this);
		EventMediator.on(EventType.EVENT_TYPE_UPDATE_MUSICINFO, this.updateCurrentItem, this);	
		EventMediator.on(EventType.EVENT_TYPE_PLAYER_ALL_FILEDONE, this.exitMusicPlayer, this);	
		EventMediator.on(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_FAILD, this.getThumbnailFailed, this);	
		EventMediator.on(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_DONE, this.getThumbnailSuccessful, this);	
		EventMediator.on(EventType.EVENT_TYPE_PROGRESS_PRESS, this.progressKeyEvent, this);	
		EventMediator.on(EventType.EVENT_TYPE_DIM_MUSICPLAYER, this.dimMusicPlayer, this);	
		EventMediator.on(EventType.EVENT_TYPE_UNDIM_MUSICPLAYER, this.undimMusicPlayer, this);	
		EventMediator.on(EventType.EVENT_TYPE_HIDE_ALL_POPUP, this.onHideAllPopup, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_INFOWND,this.onHideAllPopup,this);
		EventMediator.on(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighContrast, this);
		EventMediator.on(EventType.EVENT_TYPE_NETWORK_NOT_STABLE, this.showSingleMsgBox, this);
		EventMediator.on(EventType.EVENT_TYPE_CAN_NOT_PLAY, this.showSingleMsgBox, this);
//		EventMediator.on(EventType.EVENT_TYPE_PLAYBACK_KEY_PRESS, this.playbackKeyPress, this);	

		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_MINIBAR);

		var DeviceProvider = Volt.require("app/models/device-provider.js");

		DeviceProvider.regsiterListener(self,self.onDeviceConnect,self.onDeviceDisconnect);

		if(launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR){
			var dmrController = Volt.require('app/controller/dmr-controller.js');			
			self.dmrIns = new  dmrController();
			self.dmrIns.create();
		} 
		Volt.KPIMapper.enterPage('MY_MUSIC_PG');    
	},	    

	/**render MusicPlayerView 	 
	* @name render	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
	render : function(){
	   	print("[music-player-view.js]-----MusicPlayerView render");
		var renderTime = new Date();
		Log.f ("[music-time]start to render music player view: "+ renderTime.getTime());	
		if( self.musicView != null ){
			self.musicView.destroy();
		}

		if( self.dmrTimer != null ){
			Log.f("new song for dmr process "); 
			Volt.clearTimeout(self.dmrTimer);
			self.dmrTimer = null;			
		}

		self.playIns = playerController;	
		
		var itemData = self.playIns.getItemData(self.playIns.getCurrentIdx(), false);
		if( itemData == null ){
			Log.f('Error!!  self.playIns.getItemData(self.playIns.getCurrentIdx(), false) == null');
			print('Error!!  self.playIns.getItemData(self.playIns.getCurrentIdx(), false) == null');

			return null;
		}
			
		if(!launchParams.isLaunchForMusicPlayer()){
			var mainView = Volt.require('app/views/main-view.js');
			if( mainView.categoryView != null ){
				self.deviceID = mainView.categoryView.currentID;
			}			
		}
		else{//DMR started
			Volt.log('[music-player-view.js]---render---launchParams.isLaunchForMusicPlayer()  is true--');
			self.deviceID = launchParams.getDLNADeviceId();
		}
		Log.e("music-player view render deviceID:" + self.deviceID);
		
		self.playIns.setDeviceID(self.deviceID);		
		self.playIns.setMusicPlayerFocus(true);
		var title = ' ';
		var artist = ' ';
		
		if(itemData != null){
			print(" itemData != null ");
			Log.e(" itemData != null get title and artist");
			title = itemData.title;
			artist = itemData.artist;
		}else{
			print(" itemData = null ");
			Log.e(" itemData = null can not get title and artist");
		}
			
	    var currentItem = {
	        thumbUrl: '',
	        title: title,
	        artist: artist,
	    };
    		
		var contentWidget = loadTemplate(self.template,currentItem);
		self.musicView = contentWidget;
	
		self.setWidget(contentWidget);	
		contentWidget.onKeyEvent = self.onKeyEvent;
		contentWidget.addEventListener('onMouseOver', self._onMouseOver);
		try{
			self.ctrlBar = new MusicPlayerCtrlView();
			self.ctrlBar.render();
			self.ctrlBar.musicView = this;
			self.widget.addChild(self.ctrlBar.widget);
		}catch(e){
			print("Music player view render e:"+e);
		}
		self.thumbArea = self.widget.getChild('thumbnailArea');
		if(self.thumbArea==null){
			Log.f("Can't find shuffle, error!");
			print("[music-player-view.js]----Can't find shuffle,  self.thumbArea==null error!");
			return null;
		}	
		self.thumbArea.onReady = self.onThumbnailReady;
		//self.thumbArea.setMaskImage(resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_play.PNG',0,0);
		self.thumbArea.setMaskImage('/usr/apps/org.volt.mycontents/src_original/'+resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_play.PNG',0,0);//

		self.hdIcon = self.widget.getDescendant('HDIcon');
		if(self.hdIcon==null){
			Log.f("Can't find HDIcon, error!");
			print("[music-player-view.js]---Can't find HDIcon, error!");
			return null;
		}	
		
		self.titleTxt = self.widget.getChild('musicTitle');
		if(self.titleTxt==null){
			Log.f("Can't find musicTitle, error!");
			print("[music-player-view.js]---Can't find musicTitle, error!");
			return null;
		}

		// the solution for DF150224-01658 the song title cutted problem
		self.titleTxt.reSize(RunTimeInfo.SceneResolution*0.572917 + RunTimeInfo.offsetFor2560*2 - 400,92);
		
		
		//self.titleTxt.setPosition(200,587); it has been set in template
		//self.titleTxt.setSize(700,110);		

		self.titleTxt.setBackgroundColor(255,255,255,0);

		self.titleTxt.enableMultline(true);
		self.titleTxt.enableEllipsis(true);
		//self.titleTxt.setFontSize( 46 ); has been set in template
		self.titleTxt.setTextAlignment(1, 3);
		self.titleTxt.setText(itemData.title);

		var titleLine = self.titleTxt.lineCount();
		Log.f("[music-player-view.js]-----self.titleTxt line is " + titleLine);
		print("[music-player-view.js]-----self.titleTxt line is " + titleLine);

		self.artistTxt = self.widget.getChild('musicArtist');
		if(self.artistTxt==null){
			Log.f("Can't find musicArtist, error!");
			print("[music-player-view.js]---Can't find musicArtist, error!");
			return null;
		}	

		if( titleLine == 1 ){
			self.artistTxt.y = 649;
		}
		else{
			self.artistTxt.y = 700;
		}		
		
		self.progressWgt = self.widget.getChild('stepWidget');
		if(self.progressWgt==null){
			Log.f("Can't find ProgressBar, error!");
			print("[music-player-view.js]---Can't find ProgressBar, error!");
			return null;
		}	
		//self.progressWgt.setPosition(40 ,839);get from template, it should be Okay?
		self.progressWgt.setProgressColor(255,255,255,255);
		self.progressWgt.setBackgroundColor(255,255,255,25);
		self.progressWgt.normalThumbImage = resMgr.getImgPath()+'/progress/progress_active_a_n.png';
		self.progressWgt.focusThumbImage = resMgr.getImgPath()+'/progress/progress_active_a_f.png';
		self.progressWgt.setThumbSize(34, 34);
		self.progressWgt.setThumbAlign("center");
		self.progressWgt.reverse = false;
		if(HALOUtil.getOrientation () == "right-to-left"){
			//self.progressWgt.reverse = true;
			var tempCur = self.widget.getChild('currTime');
			var tempTotal = self.widget.getChild('totalTime');
			var totalX = tempTotal.x;
			var currentX = tempCur.x;
			print("totalX:"+totalX+", currentX:"+ currentX);
			tempTotal.x = currentX-142*(mycontentWidth/1920);
			tempCur.x = totalX+142*(mycontentWidth/1920);
		}
		var listener = new ProgressListener;
		listener.onValueChanged = self._onValueChanged; 
		self.progressWgt.addListener(listener);
		self.currTxt = self.widget.getChild('currTime');
		if(self.currTxt==null){
			Log.f("Can't find currTime, error!");
			print("Can't find currTime, error!");

			return null;
		}
		
		self.totalTxt = self.widget.getChild('totalTime');
		if(self.totalTxt==null){
			Log.f("Can't find totalTime, error!");
			print("Can't find totalTime, error!");

			return null;
		}

		EventMediator.on(EventType.EVENT_TYPE_CURSOR_SHOW, self.onCursorVisible, self);
		EventMediator.on(EventType.EVENT_TYPE_CURSOR_HIDE, self.onCursorHidden, self);

		if(RunTimeInfo.visibleCursor == true){
			self.onCursorVisible();
		}

		self.onHighContrast();

		self.setWidget(self.musicView);

		Stage.show();
		var renderTimeEnd = new Date();
		Log.f ("[music-time]end to render music player view: " + renderTimeEnd.getTime());			
		print ("[music-time]end to render music player view: " + renderTimeEnd.getTime());	
		return this;
	},	

	/**set default focus of MusicPlayerView 	 
	* @name setDefaultFocus	 
	* @memberOf MusicPlayerView	 
	* @method 	 */	
	setDefaultFocus: function(){
		print('[music-player-view.js]-----setDefaultFocus for music player');
		Volt.Nav.setRoot(self.widget);
		if( self.ctrlBar!= null && self.ctrlBar.widget.getChild(3)!= null ){

			Volt.Nav.focus(self.ctrlBar.widget.getChild(3).getChild(1));
		}		
	},

	hideFocus: function(){
		Log.f("[music-player-view.js]:hideFocus");
		self.focusWidget = Volt.Nav.getFocusedWidget();
		Volt.Nav.focus(null);
		self.isDim = true;
	},

	showFocus: function(){
		Log.f("[music-player-view.js]:showFocus " + self.focusWidget);
		print("[music-player-view.js]:showFocus " + self.focusWidget);
		
		if ( self.infoWindow ){
			self.infoWindow.setDefaultFocus();
			Log.f("[music-player-view.js]: self.infoWindow !=null  " );
			print("[music-player-view.js]: self.infoWindow !=null  " );
			return;
		}
		
		if( self.focusWidget!= null && self.musicList!= null){
			if( self.focusWidget==self.musicList.listWgt ){
				Log.f("set self.musicList.nearFocusIdxFlag = false");
				self.musicList.nearFocusIdxFlag = false;
			}
			Volt.log('[music-player-view.js]--ShowFocus---musicList is not null, and to set FocusWidget--self.focusWidget is ' +self.focusWidget);
			if (launchParams.isLaunchForMusicPlayer() && (launchParams.getLauncherAppName() == LaunchedByAppID.APP_ID_DMR))
			{
				if( self.ctrlBar != null )
				{
					if (self.focusWidget == self.ctrlBar.repeatBtn || self.focusWidget == self.ctrlBar.shuffleBtn || self.focusWidget == self.ctrlBar.preBtn || self.focusWidget == self.ctrlBar.nextBtn)		
					{
						self.focusWidget = self.ctrlBar.pauseBtn;
						Volt.Nav.focus(self.focusWidget);
					}
				}
				
			}
			Volt.Nav.focus(self.focusWidget);	
		}
		else{
			if( self.ctrlBar != null ){
				pauseBtn = self.ctrlBar.pauseBtn;
				if( pauseBtn != null ){
					Volt.Nav.focus(pauseBtn);	
				}
			}
		}
		self.isDim = false;
	},

	getShown : function() {
		return self.shown;
	},

	/**show music play 	 
	* @name show	 
	* @memberOf MusicPlayerView	 
	* @param {aniType} the animation when show music player
	* @method 	 */		
	show: function(aniType){
		//print('VDUtil.unregisterKey()');
		//VDUtil.unregisterKey();
		
		var beforeShowTime = new Date();
		Log.f("[music-player-view.js]---show--muisc time is before Show Music View Time: " + beforeShowTime.getTime());
		print("[music-player-view.js]---show--muisc time is before Show Music View Time: " + beforeShowTime.getTime());
        var deferred =  Q.defer();
		var pauseBtn = null;
		
		if(self.widget != null){
			Volt.log("[music-player-view.js]---show--self.widget is != null");
	        self.widget.show(); 
	        self.shown = true;
			
			if(self.ctrlBar == null || self.ctrlBar.widget == null){
				Log.f("[music-player-view.js]---show--self.ctrlBar == null || self.ctrlBar.widget == null");
				print('[music-player-view.js]---show--self.ctrlBar == null || self.ctrlBar.widget == null');
				deferred.resolve();
				return deferred.promise;
			}

			pauseBtn = self.ctrlBar.pauseBtn;
			if(pauseBtn == null){
				Log.f("self.ctrlBar.pauseBtn");
				deferred.resolve();
				return deferred.promise;
			}
			
			var afterShowTime = new Date();
			Log.f ("[music-time]End Show Music View Time: " + afterShowTime.getTime());			
			
			if( launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR )
			{
				var pos = launchParams.getDmrStartPos();
				print('[music-player-view.js]--show--the start position for DMR is ', pos);
				self.updateForDMRorSearch();
				self.playIns.play(pos);
			}
			else{
			       self.playIns.play(0);
			}
		}	

		//Volt.Nav.setRoot(self.widget);
		
		var rootOpt = {
			focus: pauseBtn,
		};
		Volt.Nav.setRoot(self.widget, rootOpt);//new added here
		
		Volt.Nav.setNextItemRule(self.progressWgt, 'down', pauseBtn);

		menuController = Volt.require('app/controller/menu-controller.js');
		Log.e(" music player show  disableMusicMenu ");
		menuController.disableMusicMenu();

		if( !launchParams.isLaunchForMusicPlayer()){
			Log.f('[music-player-view.js]----launchParams.isLaunchForMusicPlayer() is false to stop request_Data---');
			EventMediator.trigger(EventType.EVENT_TYPE_END_REQUEST_DATA);
		}	
		
		Volt.log('[music-player-view.js]----to settimeer for dmr--launchParams.getLauncherAppName() is ' + launchParams.getLauncherAppName() + ' LaunchedByAppID.APP_ID_DMR is ' + LaunchedByAppID.APP_ID_DMR);

		if( launchParams.getLauncherAppName() === LaunchedByAppID.APP_ID_DMR )
		{
			Volt.log('[music-player-view.js]----dmr launched---and to update DMR dim btns--');
			self.updateForDMRorSearch();
		}	
       
		
		deferred.resolve();
		
	
		Volt.log('[music-player-view.js]--show--end--- ');		
        return deferred.promise;        
	},
	
	updateForDMRorSearch: function(){
		Volt.log('[music-play-view.js]---updateForDMRorSearch---');
		Log.e('[music-play-view.js]---updateForDMRorSearch---');
		if (self.ctrlBar !=  null)
		{
			if (self.ctrlBar.repeatBtn != null)
			{
				self.ctrlBar.setDimIconForRepeat();
				//self.ctrlBar.repeatWidget.getChild(0).color.a = 242;
				//self.ctrlBar.repeatBtn.setIconAlpha({state: "all", alpha: 255,});
				self.ctrlBar.repeatBtn.custom = {focusable: false};
				//self.shuffleWidget.getChild(0).color.a = 242;
				self.ctrlBar.repeatWidget.getChild(0).color.a = 0;
				self.ctrlBar.repeatBtn.setIconAlpha({state: "all", alpha: 100,});
				
			}
			if (self.ctrlBar.shuffleBtn != null)
			{
				self.ctrlBar.setDimIconForShuffle();
				//self.ctrlBar.shuffleWidget.getChild(0).color.a = 242;
				//self.ctrlBar.shuffleBtn.setIconAlpha({state: "all", alpha: 255,});
				self.ctrlBar.shuffleBtn.custom = {focusable: false};
				self.ctrlBar.shuffleWidget.getChild(0).color.a = 0;
				self.ctrlBar.shuffleBtn.setIconAlpha({state: "all", alpha: 100,});
				
			}

			if (self.ctrlBar.nextBtn != null)
			{
				self.ctrlBar.setDimIconForBtn(self.ctrlBar.nextBtn);
				//self.ctrlBar.shuffleWidget.getChild(0).color.a = 242;
				//self.ctrlBar.shuffleBtn.setIconAlpha({state: "all", alpha: 255,});
				self.ctrlBar.nextBtn.custom = {focusable: false};
				self.ctrlBar.nextWidget.getChild(0).color.a = 0;
				self.ctrlBar.nextBtn.setIconAlpha({state: "all", alpha: 100,});
				
			}

			if (self.ctrlBar.preBtn != null)
			{
				self.ctrlBar.setDimIconForBtn(self.ctrlBar.preBtn);
				//self.ctrlBar.shuffleWidget.getChild(0).color.a = 242;
				//self.ctrlBar.shuffleBtn.setIconAlpha({state: "all", alpha: 255,});
				self.ctrlBar.preBtn.custom = {focusable: false};
				self.ctrlBar.preWidget.getChild(0).color.a = 0;
				self.ctrlBar.preBtn.setIconAlpha({state: "all", alpha: 100,});
				
			}

			Volt.log('[music-player-view.js]---to set next rule for musicList.listWgt and pauseBtn, self.musicList is ' + self.musicList);
			if (self.musicList != null && self.musicList.listWgt != null)
			{
				Volt.Nav.setNextItemRule(self.musicList.listWgt, 'left', self.ctrlBar.pauseBtn);
				Volt.Nav.setNextItemRule(self.ctrlBar.pauseBtn, 'right', self.musicList.listWgt);
			}
			else
			{
				Volt.log('[music-player-view.js]---self.musicList is null or self.musicList.listWgt is null');
			}
			
			//Volt.Nav.setNextItemRule(self.ctrlBar.pauseBtn, 'right', self.musicList.listWgt);
			Volt.Nav.setNextItemRule(self.ctrlBar.pauseBtn, 'left', self.ctrlBar.screenBtn);
			Volt.Nav.setNextItemRule(self.ctrlBar.screenBtn, 'right', self.ctrlBar.pauseBtn);
		}
		

	},
	/**hide music play 	 
	* @name hide	 
	* @memberOf MusicPlayerView	 
	* @param {aniType} the animation when hide music player
	* @method 	 */		
	hide: function(aniType){
		Volt.log('music-player-view.js---hide----');
        var deferred =  Q.defer();
        self.widget.hide();
        self.shown = false;
		if( self.balloon != null ){
			self.balloon.destroy();
			self.balloon = null;
		}
		//print('VDUtil.registerKey()');
		//VDUtil.registerKey();
		menuController = Volt.require('app/controller/menu-controller.js');

		Log.e("music player hide enableMusicMenu");
		menuController.enableMusicMenu();

		Log.e("music player hide disableMenu");
		menuController.disableMenu();	
		Log.f("music player hide");   
		deferred.resolve();         
        return deferred.promise;
	},	

	/**destroy music play 	 
	* @name destroy	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
	destroy: function(){
		Log.f("music player destroy");	
		Volt.log("music player destroy");
		self.hideNAMsgBox();
		
		if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
		{
			Volt.log("music player destroy----to set currentPlayLoading to null");
			Log.f("music player destroy----to set currentPlayLoading to null");
			//Volt.require("app/common/run-time-info.js").CurrentPlayLoading.destroy();
			Volt.require("app/common/run-time-info.js").CurrentPlayLoading= null;		
		}
		
		if(self.dmrIns != null){
			self.dmrIns.destroy();
			self.dmrIns = null;
		}
		
		if( self.listTimer!= null ){
			Volt.clearTimeout(self.listTimer);
			self.listTimer = null;
		}
				
		if( self.musicList != null ){
			self.musicList.destroy();
			self.musicList = null;
		}
		if( self.ctrlBar != null ){
			self.ctrlBar.destroy();
			self.ctrlBar = null;
		}
		if( self.balloon != null ){
			self.balloon.destroy();
			self.balloon = null;
		}
		if( self.msgBox != null){
			self.msgBox.hide();
			self.msgBox.destroy();
			self.msgBox = null;
		}
		if(self.closeBtn != null){
			self.closeBtn.destroy();
			self.closeBtn = null;
		}
		if(self.exitBtn != null){
			self.exitBtn.destroy();
			self.exitBtn = null;
		}			
		if( self.infoWindow&&self.infoWindow.popupWidget != null ){
			self.infoWindow.hide();
			self.infoWindow = null;
		}
		self._destroyProgressArrow();
		self.arrItems = [];
		
		self.widget.hide();
		self.widget.destroy();

	    self.thumbArea = null,
		self.thumbImg = null,
	    self.titleTxt = null,
	    self.artistTxt = null,
	    self.currTxt = null,
	    self.totalTxt = null,
	    self.progressWgt = null,
 	    self.upArrowImg = null,
 	    self.downArrowImg = null,
  
        self.shown = false;	

		self.musicView = null;
		self.focusWidget = null;

		EventMediator.off(EventType.EVENT_TYPE_NOT_AVAILIABLE, this.showNAMessageBox, this);	
		EventMediator.off(EventType.EVENT_TYPE_UNSUPPORT_FILE, this.showUnSupportMsgBox, this);	
		EventMediator.off(EventType.EVENT_TYPE_UPDATE_TOTALTIME, this.updateTotalTime, this);	
		EventMediator.off(EventType.EVENT_TYPE_UPDATE_CURRENTTIME, this.updateTime, this);
		EventMediator.off(EventType.EVENT_TYPE_UPDATE_MUSICINFO, this.updateCurrentItem, this);	
		EventMediator.off(EventType.EVENT_TYPE_PLAYER_ALL_FILEDONE, this.exitMusicPlayer, this);	
		EventMediator.off(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_FAILD, this.getThumbnailFailed, this);	
		EventMediator.off(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_DONE, this.getThumbnailSuccessful, this);
		EventMediator.off(EventType.EVENT_TYPE_PROGRESS_PRESS, this.progressKeyEvent, this);	
		EventMediator.off(EventType.EVENT_TYPE_DIM_MUSICPLAYER, this.dimMusicPlayer, this);	
		EventMediator.off(EventType.EVENT_TYPE_UNDIM_MUSICPLAYER, this.undimMusicPlayer, this);	
		EventMediator.off(EventType.EVENT_TYPE_UNFOUND_FILE, this.showSingleMsgBox, this);
		EventMediator.off(EventType.EVENT_TYPE_HIDE_ALL_POPUP, this.onHideAllPopup, this);
		EventMediator.off(EventType.EVENT_TYPE_HIDE_INFOWND,this.onHideAllPopup,this);
		EventMediator.off(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighContrast, this);
		EventMediator.off(EventType.EVENT_TYPE_NETWORK_NOT_STABLE, this.showSingleMsgBox, this);
		EventMediator.off(EventType.EVENT_TYPE_CAN_NOT_PLAY, this.showSingleMsgBox, this);
//		EventMediator.off(EventType.EVENT_TYPE_PLAYBACK_KEY_PRESS, this.playbackKeyPress, this);	
		print("music player destroy finish");
	},
	
    events: {   
    	'NAV_SELECT': 'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur',
    },

	/**the callback for select music player's button
	* @name onSelect	 
	* @memberOf MusicPlayerView	 
	* @param {widget} which widget has been selected	
	* @method 	 */	
	onSelect: function( widget ){
		print(' onSelect in Music Player View');
    },

	/**the callback for the widget on focus
	* @name onFocus	 
	* @memberOf MusicPlayerView	 
	* @param {widget} which widget has been focused	
	* @method 	 */		
    onFocus: function(widget) {
      	if( widget == null ){
			Log.e("[music-player view] onFocus widget == null ");
			return;
      	}    
        Log.f("[music-player view] MusicPlayer.focus " + widget.id);
		print("[music-player view] MusicPlayer.focus " + widget.id);
		
        if( widget == self.progressWgt ){
			self._showBalloon4ProgressBar();
			
			if (Vconf.getInteger('memory/window_system/input/cursor_visible'))
			{
				Volt.log("[music-player-view.js]---onFocus--- Vconf.getInteger('memory/window_system/input/cursor_visible') is " + Vconf.getInteger('memory/window_system/input/cursor_visible'));
			}
			else
			{
				self._showProgressArrow();
			}
			var txt = resMgr.getText('TV_SID_PROGRESS_BAR');
			voiceGuide.play(txt);

        	return;
        }
		else
		{
			//self.ctrlBar.buttonFocus(widget);
			return;
		}
    },

	/**the callback for the widget lose focus
	* @name onBlur	 
	* @memberOf MusicPlayerView	 
	* @param {widget} which widget has been losed focus	
	* @method 	 */		
    onBlur: function(widget) {
      	if( widget == null || widget === undefined){
			return;
      	}
		Log.e("music player view destory tooltips");
	   	if( self.balloon != null ){
			print("music player view onBlur Destroy balloon");
    		self.balloon.destroy();
    		self.balloon = null;
    	}

		self._destroyProgressArrow();
		
		if( self.shown == false ){
			return;
		}	

//		self.preFocus = widget;
		return;
    },	
    
	_destroyProgressArrow:function()
    {
	   	if( self.ProgressRightArrow != null )
         {
			print("music player view onBlur Destroy ProgressRightArrow");
    		self.ProgressRightArrow.destroy();
    		self.ProgressRightArrow = null;
    	}

	   	if( self.ProgressLeftArrow != null ){
			print("music player view onBlur Destroy ProgressLeftArrow");
    		self.ProgressLeftArrow.destroy();
    		self.ProgressLeftArrow = null;
    	}		
		return;
    },
    
	progressKeyEvent:function(keyCode){
		Log.f("get in the progressKeyEvent");
        switch (keyCode) {
	        case Volt.KEY_JOYSTICK_LEFT:
				self._progressRW();
				break;
	        case Volt.KEY_JOYSTICK_RIGHT:
				self._progressFF();
	            break;
	        default:
	            break;
        }	
		return;
	},

	respondTheseKeysInDim : function( keyCode ) {
		if( keyCode == Volt.KEY_INFO ||
			keyCode == Volt.KEY_PAUSE ||
			keyCode == Volt.KEY_PLAY ||
			keyCode == Volt.KEY_STOP ||
			keyCode == Volt.KEY_FF ||
			keyCode == Volt.KEY_REWIND ||
			keyCode == Volt.KEY_FF_ ||
			keyCode == Volt.KEY_REWIND_ ){
				return true;
			}
		return false;
	},

	/**the callback for remote key press
	* @name onKeyEvent	 
	* @memberOf MusicPlayerView	 
	* @param {keyCode} key number	
	* @param {type} key event type		
	* @method 	 */		
	onKeyEvent:function(keyCode, type){
		Log.f("[music-player-view.js] function onKeyEvent keyCode= " + keyCode + " type = " + type + " Volt.EVENT_KEY_PRESS is " + Volt.EVENT_KEY_PRESS);
		print("[music-player-view.js] function onKeyEvent keyCode= " + keyCode + " type = " + type + " Volt.EVENT_KEY_PRESS is " + Volt.EVENT_KEY_PRESS );
		var ret = true;
		if(inputController.getBlockFlag() == true){
			print("[music-player-view.js] function onKeyEvent inputController.getBlockFlag() == true  return ");
			Log.e("[music-player-view.js] function onKeyEvent inputController.getBlockFlag() == true  return ");

			return;
		}
		if( self.listTimer!= null ){
			Volt.clearTimeout(self.listTimer);
			self.listTimer = null;
		}
		
		if( type == Volt.EVENT_KEY_PRESS ){
			Log.f('don\'t respond key press');
			print('don\'t respond key press');
			return ret;
		}		

		Log.f("onKeyEvent mycontents is dimmed!!!!: "+self.isDim);
		print("onKeyEvent mycontents is dimmed!!!!: "+self.isDim);
		if( self.isDim == true && self.respondTheseKeysInDim(keyCode) == false && !RunTimeInfo.bFlagForNAMsgBoxShow ){
			Log.f('[music-player-view.js]------onKeyEvent mycontents is dimmed!!!!');
			print('[music-player-view.js]------onKeyEvent mycontents is dimmed!!!!');
			return false;
		}
		
    	self.listTimer = Volt.setTimeout(self.listTimerCB,30000);

		var focusWgt =  Volt.Nav.getFocusedWidget();

		if(self.musicList != null && self.musicList.onKeyEvent != null && focusWgt==self.musicList.listWgt && keyCode==KeyCode.enter){
			Log.e("music player onKeyEvent return self.musicList.onKeyEvent(keyCode, type); ");
			return self.musicList.onKeyEvent(keyCode, type);
		}
	
		switch(keyCode){
			 case  KeyCode.returnKey:{
				self.exitMusicPlayer(self.ExitType.RETURN_KEY);
			 	break;
			 }
			 case KeyCode.stop: {
				self.exitMusicPlayer(self.ExitType.STOP_KEY);	 	
			 	break;
			 }
			 case Volt.KEY_INFO: {
			 	print('[music-player-view.js]---onKeyEvent--Volt.KEY_INFO, and the keyCode is ' + keyCode);
			 	var InfoWindowTemplate = Volt.require('app/templates/1080/content-information-box-template.js');
				var InfoWindow = Volt.require('app/views/content-information-box.js');
				
				var infoIdx = 0;
				var focusWgt = Volt.Nav.getFocusedWidget();	
				if( focusWgt!=self.musicList.listWgt ){ 
					infoIdx = self.playIns.getCurrentIdx();
				}
				else{
					infoIdx = self.musicList.getListFocus();
				}
				Volt.log('[music-player-view.js]----onKeyEvent---infoIdx is ' + infoIdx);
				try{


						var InfoData = self.playIns.getMusicDetail(infoIdx);
					 	self.infoWindow = new InfoWindow();
						self.infoWindow.setcontentTitle(InfoData.title);
						self.infoWindow.setcontentSavedData(InfoData.lastSaveDate);
						self.infoWindow.setcontentArtist(InfoData.artist);
						self.infoWindow.setcontentAlbum(InfoData.album);
						self.infoWindow.setcontentDuration(InfoData.duration);
						self.infoWindow.setcontentGenre(InfoData.genre);
						self.infoWindow.setcontentSize(InfoData.size);	
						self.infoWindow.setcontentFormat(InfoData.format);
						self.infoWindow.setcontentLocation(InfoData.location);
						self.infoWindow.render(InfoWindowTemplate.info_window_template_music,'music-player');
						self.infoWindow.setDefaultFocus();
						self.infoWindow.setDestroyCb(self.onInformationDestroy);
						RunTimeInfo.bFlagForInforBox = true;
					

				}catch(e){
					print("Show music player infor popup e:"+e);
				}
				//print('[music-player-view.js]----onKeyEvent--RunTimeInfo.bFlagForInforBox is '+ RunTimeInfo.bFlagForInforBox);
				break;
			 }
 			 case Volt.KEY_PLAY_BACK:{			//temp for Volt.KEY_PLAY_BACK
 			 	Log.e("get the Volt.KEY_PLAY_BACK in music-player-view");
 			 	if( self.playIns != null ){
					if( self.playIns.getState()==3){
						self.playIns.pause();
					}
					else{
						self.playIns.resume(null); 
						if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
						{
							Volt.log('[music-player-view.js]---onKeyEvent---KEY_PLAY_BACK--CurrentPlayLoading is not null, and resume to play----');
							Log.e('[music-player-view.js]---onKeyEvent---KEY_PLAY_BACK--CurrentPlayLoading is not null, and resume to play----');
							Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
						}						
					}
 			 	}
				break;
 			 }
			 case KeyCode.pause:{
			 	if( self.ctrlBar != null ){
    				self.ctrlBar.pbPlayPause( 'pauseKey' );
			 	}
			 	break;
			 }
			 case KeyCode.play:{
			 	if( self.ctrlBar != null ){
    				self.ctrlBar.pbPlayPause( 'playKey' );
			 	}
			 	break;
			 }
			 case KeyCode.fastforward: {
			 	self._progressFF();
				break;
			 }
			 case KeyCode.backforward: {
			 	self._progressRW();
				break;
			 }
			 case KeyCode.next: {
			 	if( self.ctrlBar != null ){
			 		self.ctrlBar.pbPlayNext();
			 	}
				break;
			 }
			 case KeyCode.pre: {
			 	if( self.ctrlBar != null ){
			 		self.ctrlBar.pbPlayPre();
			 	}
				break;
			 }				 
    		 default:
    		 	ret = false;
    	    	break;			 
		}
		Log.e(" music player onKeyEvent return value: "+ret);
		return ret;
	},

	playbackKeyPress : function(keycode, keytype) {
		if( self.listTimer!= null ){
			Volt.clearTimeout(self.listTimer);
			self.listTimer = null;
		}
		
    	self.listTimer = Volt.setTimeout(self.listTimerCB,30000);
		
		if( keytype == Volt.EVENT_KEY_RELEASE ){
			return true;
		}		
		
		switch(keycode){
			 case KeyCode.pause:{
			 	if( self.ctrlBar != null ){
    				self.ctrlBar.pbPlayPause( 'pauseKey' );
			 	}
			 	break;
			 }
			 case Volt.KEY_PLAY_BACK:			//temp for Volt.KEY_PLAY_BACK
			 case KeyCode.play:{
			 	if( self.ctrlBar != null ){
    				self.ctrlBar.pbPlayPause( 'playKey' );
			 	}
			 	break;
			 }
			 case KeyCode.fastforward: {
			 	self._progressFF();
				break;
			 }
			 case KeyCode.backforward: {
			 	self._progressRW();
				break;
			 }
			 case KeyCode.next: {
			 	if( self.ctrlBar != null ){
				 	self.ctrlBar.pbPlayNext();
			 	}
				break;
			 }
			 case KeyCode.pre: {
			 	if( self.ctrlBar != null ){
			 		self.ctrlBar.pbPlayPre();
			 	}
				break;
			 }	
    		 default:
    	    	break;			 
		}
	},

	/**process for leaving music player
	* @name exitMusicPlayer	 
	* @memberOf MusicPlayerView	 
	* @param {eType} leaving type		
	* @method 	 */	
	exitMusicPlayer : function( eType ) {
		Log.f( "eType = " + eType );	
		Volt.log('[music-player-view.js]----exitMusicPlayer---eType is '+ eType + ' launchParams.isLaunchForMusicPlayer() is ' + launchParams.isLaunchForMusicPlayer() + ' RunTimeInfo.bFlagForInforBox is ' + RunTimeInfo.bFlagForInforBox);
		if (RunTimeInfo.bFlagForInforBox)
		{
			EventMediator.trigger(EventType.EVENT_HIDE_INFORMATION);
			RunTimeInfo.bFlagForInforBox = false;	
		}

		if(launchParams.isLaunchForMusicPlayer())
		{		//means music player is launched by other app directly
			Volt.log('app.js-----onReset-----to hide the informatin box');
			//var InfoWindow = Volt.require('app/views/content-information-box.js');
			/* MUST reset launch params */
			launchParams.resetParams();
			
			Log.f("ready to Volt.exit()");
			Volt.log("[music-palyer-view.js]--exitMusicPlayer-ready to Volt.exit() launchParams.isLaunchForMusicPlayer() is true");
			if(self.playIns!= null){		//pause
			    self.playIns.stop();
				RunTimeInfo.playState = 0;
			}
			if (eType == self.ExitType.ALL_DONE || eType == self.ExitType.DMR_STOP){
				if(self.dmrTimer==null){
					self.dmrTimer = Volt.setTimeout(self._realExit4Dmr,3000);
					Log.f("set timer for real exit");
				}
				return;
			}
			
			if(self.dmrIns != null){
				self.dmrIns.sendStopReason(1);
				self.dmrIns.destroy();
				self.dmrIns = null;
			}
			print('[music-player-view.js]---exitMusicPlayer--RunTimeInfo.launchMusicReturnContentOrNot='+RunTimeInfo.launchMusicReturnContentOrNot);
			var DeviceProvider = Volt.require("app/models/device-provider.js");
			if( RunTimeInfo.launchMusicReturnContentOrNot == false )
			{
				
				Volt.exit();				
			}
			else{
				if(DeviceProvider.getDeviceCount() < 1){
					RunTimeInfo.router.returnFromMusicPlayer(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
				}
				else{
					if( RunTimeInfo.router.preViewType != EViewType.eMusicPlayerView ){
						Log.f("Switch to preView : " + RunTimeInfo.router.preViewType);
						RunTimeInfo.router.returnFromMusicPlayer(RunTimeInfo.router.preViewType, EViewSwitchAniType.eNoneAni);
					}
					else{
						RunTimeInfo.router.returnFromMusicPlayer(EViewType.eAllContentView, EViewSwitchAniType.eNoneAni);
					}
				}
			}
			return;
		}
		else
		{
			if(self.playIns!= null){		//pause
			    self.playIns.stop();
				RunTimeInfo.playState = 0;
			}
			if(eType != self.ExitType.DISCONNECT_DEVICE){
				Volt.Nav.focus(null);
				

				var DeviceProvider = Volt.require("app/models/device-provider.js");

				if(DeviceProvider.getDeviceCount() < 1){
					Log.f("There is no any device, switch to connnection guide view");
					RunTimeInfo.router.returnFromMusicPlayer(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);

				} else {
					Log.f("Switch to preView : " + RunTimeInfo.router.preViewType);
					RunTimeInfo.router.returnFromMusicPlayer(RunTimeInfo.router.preViewType, EViewSwitchAniType.eNoneAni);
				}
			}	
			//EventMediator.trigger(EventType.EVENT_TYPE_KILL_FOCUS, null);
		}
    },    

	updateDMRMusicData: function(){
		Log.f("[music-player-view]: updateDMRMusicData");
		Volt.log("[music-player-view]: updateDMRMusicData");
		if( self.dmrTimer != null ){
			Log.f("new song for dmr process "); 
			Volt.clearTimeout(self.dmrTimer);
			self.dmrTimer = null;			
		}
		
		if( self.progressWgt != null ){
			self.progressWgt.setValue(0);
		}

    	if( self.currTxt != null ){
			var startValue = "00:00";
    		self.currTxt.text = startValue;
    	}

		if( self.dmrIns == null ){
			var dmrController = Volt.require('app/controller/dmr-controller.js');			
			self.dmrIns = new  dmrController();
			self.dmrIns.create();
		}
		else{
			self.dmrIns.attachDMR();
		}		

//		self.updateCurrentItem(0);
		self.playIns.play(launchParams.getDmrStartPos());

		//self.updateForDMRorSearch();
    },

	dmrExitNotify: function(){
		Log.f("[music-player-view]: dmrExitNotify");
		if( self.dmrIns != null ){
			self.dmrIns.sendStopReason(1);
			self.dmrIns.destroy();
			self.dmrIns = null;					
		}
    },

	updateSearchMusicData: function(){
		Log.f("[music-player-view]: updateSearchMusicData");		
//		self.updateCurrentItem(0);
		self.playIns.play(0);
    },	

	/**update the current playing music item info
	* @name updateCurrentItem	 
	* @memberOf MusicPlayerView	 
	* @param {idx} the current item's index	
	* @method 	 */		
    updateCurrentItem: function( idx ){
    	Volt.log('[music-player-view.js]---updateCurrentItem-- idx is ' + idx);
		var itemData = self.playIns.getItemData(idx,false);
    	
    	if( self.thumbArea == null || self.titleTxt == null || self.artistTxt == null ){
    		Log.f("GUI element is not enough!");
    		return;
    	}

		var thumbUrl = itemData.thumb;
		if( thumbUrl == resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_album_default.PNG'){
			thumbUrl = resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_play_default.PNG';
		}
		
		self.titleTxt.setText(itemData.title);
		var titleLine = self.titleTxt.lineCount();
		Log.f("self.titleTxt line is " + titleLine);
		
		self.artistTxt.text = itemData.artist;	

		if( titleLine == 1 ){
			self.artistTxt.y = 649;
		}
		else{
			self.artistTxt.y = 700;
		}

		if( self.musicList == null ){
			Volt.log('[music-player-view.js]---updateCurrentItem-- idx is '+ idx);
			
			var createListTime = new Date();
			Log.f ("[music-time]Create Music List Time: " + createListTime.getTime());	
			self.musicList = new MusicPlayerListView();
			self.musicList.render();
			self.widget.addChild(self.musicList.widget);
			Volt.Nav.addItem(self.musicList.listWgt);

			if (launchParams.isLaunchForMusicPlayer() && (launchParams.getLauncherAppName() == LaunchedByAppID.APP_ID_DMR))
			{
				Volt.log('[music-player-view.js]----updateCurrentItem----to set pauseBtn---');
				Volt.Nav.setNextItemRule(self.musicList.listWgt, 'left', self.ctrlBar.pauseBtn);
				Volt.Nav.setNextItemRule(self.ctrlBar.pauseBtn, 'right', self.musicList.listWgt);
				
				Volt.Nav.setNextItemRule(self.ctrlBar.pauseBtn, 'left', self.ctrlBar.screenBtn);
				Volt.Nav.setNextItemRule(self.ctrlBar.screenBtn, 'right', self.ctrlBar.pauseBtn);
				Volt.log('[music-player-view.js]----updateCurrentItem---to setNextItemRule for list and pause for dmr');
				Log.e('[music-player-view.js]----updateCurrentItem---to setNextItemRule for list and pause for dmr');
			}
			else
			{
				Volt.Nav.setNextItemRule(self.musicList.listWgt, 'left', self.ctrlBar.shuffleBtn);	
				Volt.log('[music-player-view.js]----updateCurrentItem---exclude DMR case--');			
			}
			
			self.musicList.musicView = self;

			if(self.exitBtn != null){
				self.exitBtn.raise(null);
			}

			if(launchParams.isLaunchForMusicPlayer()){// it should be set default focus to all cases, but why  it is not right here?
				self.setDefaultFocus();
			}

			//first time to create list, and also to play the music---need to check, only when the first entering music -player?
			//if the i scroll the list, will it create the list again?
			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null) 
			{
				Volt.log('[music-player-view.js]-----updateCurrentItem---the first time to create the list-CurrentPlayLoading is not null, first time to  play----');
				Log.e('[music-player-view.js]-----updateCurrentItem---the first time to create the list-CurrentPlayLoading is not null, first time to  play----');
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
			}	
		}
		else{
			Volt.log('[music-player-view.js]----updateCurrentItem---else---');
			if(launchParams.isLaunchForMusicPlayer()){
				Volt.log('[music-player-view.js]---updateCurrentItem--it is for DMR, RunTimeInfo.bFlagForDMRCLickPlaying is ' + RunTimeInfo.bFlagForDMRCLickPlaying);
				//if (RunTimeInfo.bFlagForDMRCLickPlaying)
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.parent = scene;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.x = -30;
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.y = -30;
					Volt.log('[music-player-view.js]------set the parent of the loading to scene---');
					if(self.musicList != null)
					{
						self.musicList.updateData();
						
					}
				
			}
			
			if (RunTimeInfo.bFlagForPrev == true)
			{
				
				if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null) 
				{
					Volt.log('[music-player-view.js]-----updateCurrentItem---CurrentPlayLoading is not null, RunTimeInfo.bFlagForPrev is true, to play----');
					Log.f('[music-player-view.js]-----updateCurrentItem---CurrentPlayLoading is not null, RunTimeInfo.bFlagForPrev is true, to play----');
					Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
				}	
				RunTimeInfo.bFlagForPrev = false;
			}
			RunTimeInfo.bFlagForDMRCLickPlaying = false;
			Volt.log('[music-player-view.js]---updateCurrentItem-- RunTimeInfo.bFlagForDMRCLickPlaying is '+RunTimeInfo.bFlagForDMRCLickPlaying);
			self.musicList.updateCurrentItem(idx);
		}

		self._updateThumbnail(thumbUrl, false);

		if( self.hdIcon != null ){
			if( self.playIns.checkHDAudioSupport(idx)==true ){
				Log.f("self.playIns.checkHDAudioType(idx)==true");
				self.hdIcon.src = resMgr.getImgPath()+'/Contents_icon/mc_thumbnail_icon_hd.png';
				self.hdIcon.opacity = 255;
			}
			else {
				self.hdIcon.opacity = 0;
			}
		}
		Volt.log('[music-play-view.js]---updateCurrentItem---end----');
        return;
    },	

	/**update the playing music item's total time
	* @name updateTotalTime	 
	* @memberOf MusicPlayerView	 
	* @param {StrTotalTime} total time's string	value
	* @param {IntTotalTime} total time's int value		
	* @method 	 */		
	updateTotalTime: function( StrTotalTime, IntTotalTime ){
		Log.f("[music-player-view.js]------totalTime in updateTotalTime is " + StrTotalTime);
		print("[music-player-view.js]------totalTime in updateTotalTime is " + StrTotalTime);
		if( self.totalTxt != null ){
			self.totalTxt.text = String(StrTotalTime);
		}
    },

	/**update the current playing time
	* @name updateTime	 
	* @memberOf MusicPlayerView	 
	* @param {per} the progressBar's position
	* @param {timeStr} the current time's string	
	* @method 	 */		
    updateTime: function( per, timeStr, timeInt ){
    	Volt.log('[music-player-view.js]------------updateTime----per is ' +per +' timeStr is '+ timeStr + ' timeInt is ' +timeInt );
    	if( self.currTxt != null ){
    		self.currTxt.text = String(timeStr);
    	}
		self.progressPos = per;	    
    	if( self.progressWgt != null && per >= 0 && per <= 1 ){
			//Volt.log('[music-player-view.js]---updateTime---self.playIns.seekEnable is ' + self.playIns.seekEnable + ' self.progressDrag ' + self.progressDrag )
			if( self.playIns.seekEnable == true && self.progressDrag == false ){
			
    			self.progressWgt.setValue(per*1000);
			}
    	}	
    },

	/**fast forward callback 
	* @name _progressFF	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
    _progressFF: function() {
    	Volt.log('[music-player-view.js]----_progressFF');
    	if( self.playIns != null ){
	    	if (self.playIns.jumpForward(10)==-1){
				self.showNAMessageBox();
	    	}
    	}
    },

	/**rewind back callback 
	* @name _progressRW	 
	* @memberOf MusicPlayerView	 
	* @method 	 */		
    _progressRW: function() {
    Volt.log('[music-player-view.js]----_progressRW');
    	if( self.playIns != null ){    
    		if (self.playIns.jumpBackward(10)==-1){
				self.showNAMessageBox();
    		}
    	}
    },

	/**when there is no ket press input 30s, call this function 
	* @name listTimerCB	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	listTimerCB : function() {
		var focusWgt = Volt.Nav.getFocusedWidget();
    	
		if(focusWgt!=self.musicList){
			return;
		}
		
		var idx = self.playIns.getCurrentIdx();
		Log.f("timer callbck: listTimerCB" + idx);
		if( self.musicList != null ){
			self.musicList.setListFocus(idx);
		}
	},

	/**show 'Not Available' message box
	* @name showNAMessageBox	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	showNAMessageBox : function() {
	/*
		if( self.shown == false ){
			return;
		}

		Log.f("[music-player.js] MusicPlayerView.showNAMessageBox");
		print("[music-player-view.js] MusicPlayerView.showNAMessageBox");
		var deferred =  Q.defer();
        	deferred.resolve();
		EventMediator.trigger(EventType.EVENT_TYPE_MAIN_VIEW_DIM);
		var msgBox = new CommMessageBox({parentRootWidget : self.widget});
		msgBox.render(MessageType.eNotAvailable);
		return deferred.promise;
	*/

		//write vconf , if there is any error, need fresh cotnent
	//	print("showSingleMsgBox setUpdateContentFlag to true");
	//	appConfig.setUpdateContentFlag('true');
		
		if( self.shown == false ){
			return;
		}

		if( self.msgBox != null ){
			self.msgBox.hide();
			self.msgBox.destroy();
			self.msgBox = null;
		}		
		if( self.coverWgt != null ){
			self.coverWgt.removeEventListener("OnMouseOver", self.dimWidgetOnMouseOver);
			self.coverWgt.removeEventListener("OnMouseClick", self.dimWidgetOnMouseClick);
			self.coverWgt.destroy();
			self.coverWgt = null;
		}
		
		self.dimMusicPlayer();
		Log.f("ready to create messageBox1Listener");
        var messageBox1Listener = new MessageBoxListener;
		Log.f("end to create messageBox1Listener");

        messageBox1Listener.OnTimeOut = function(messagebox){
            Volt.setTimeout(_.bind(self.hideNAMsgBox,self),1);
        };		

        var tmpMsgBox = PanelCommon.loadTemplate(MusicPlayerViewTemplate.msgBox_0, null, scene);
        tmpMsgBox.setContentTextColor(255, 255, 255, 255);
		
		var text= resMgr.getText('COM_SID_NOT_AVAILABLE');;
	
		
        tmpMsgBox.setContentText(text);
        tmpMsgBox.enablePointerFocus();
        tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
	
        //tmpMsgBox.defaultFocusIndex = 1;
        tmpMsgBox.showTime = 10000;
        tmpMsgBox.addListener(messageBox1Listener);
		RunTimeInfo.bFlagForNAMsgBoxShow = true;
  
        tmpMsgBox.show();
		Volt.log('[music-player-view.js]----to show the not availale messagebox');
        self.msgBox = tmpMsgBox;
	},

	/**the callback for skip button in unsupport messageBox
	* @name unsupportSkip	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	unsupportSkip :function() {
		print("unsupportSkip!!!");
		Volt.log('[music-player-view.js]---unsupportSkip---');
		Log.f("[music-player-view.js]---unsupportSkip---");
		
		if( self.msgBox != null ){
			self.msgBox.hide();
			self.msgBox.destroy();
			self.msgBox = null;	
		}
		self.undimMusicPlayer();
		
		if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
		{
			Volt.log('[music-player-view.js]--unsupportSkip-- to play ');
			Log.f('[music-player-view.js]--unsupportSkip-- to play ');
			Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
		}

		if ( self.playIns.playNext( true )==false ){
			Volt.log('[music-player-view.js]---unsupportSkip---play next failed');
		}

	},

	/**the callback for stop button in unsupport messageBox
	* @name unsupportSkip	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	unsupportStop :function() {
		print("unsupportStop!!!");
		if( self.msgBox != null ){
			self.msgBox.hide();
			self.msgBox.destroy();
			self.msgBox = null;	
		}
		self.undimMusicPlayer();
		self.exitMusicPlayer(self.ExitType.STOP_KEY);
	},

	hideNAMsgBox :function() {
		print("[music-player-view.js]----hideNAMsgBox!!!");
		Log.e("[music-player-view.js]----hideNAMsgBox!!!");
		if( self.msgBox != null ){
			self.msgBox.hide();
			self.msgBox.destroy();
			self.msgBox = null;	
		}
		
		self.undimMusicPlayer();
		RunTimeInfo.bFlagForNAMsgBoxShow = false;
	},
	/**show 'UnSupport' message box
	* @name showUnSupportMsgBox	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	showUnSupportMsgBox : function() {

			//write vconf , if there is any error, need fresh cotnent
		print("showUnSupportMsgBox setUpdateContentFlag to true");
		appConfig.setUpdateContentFlag('true');
		
		if( self.shown == false ){
			return;
		}

		if (self.ctrlBar != null)
		{
			self.ctrlBar.pauseWidget.getChild(0).color.a = 0;
			//self.ctrlBar.updatePlayunSupportedSong();
			self.ctrlBar.pauseBtn.setIconAlpha({state: "all", alpha: 204,});			
		}
		
		if( self.msgBox != null ){
			self.msgBox.hide();
			self.msgBox.destroy();
			self.msgBox = null;
		}		

		self.dimMusicPlayer();
		Log.f("ready to create messageBox1Listener");
		Volt.log("[music-player-view.js]---showUnSupportMsgBox---ready to create messageBox1Listener---");
		RunTimeInfo.bFlagForNotSupportPopup = true;
        var messageBox1Listener = new MessageBoxListener;
        messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
            if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
                self.unsupportSkip();
            }
            if ('button_clicked' == eventType && 'button_2' == nButtonIndex) {
                 self.unsupportStop();
            }
        };
		Log.f("end to create messageBox1Listener");
		
        messageBox1Listener.OnTimeOut = function(messagebox){
            Volt.setTimeout(_.bind(self.unsupportSkip,self),1);
        };
		
		Log.f("ready to create tmpMsgBox");
        var tmpMsgBox = PanelCommon.loadTemplate(MusicPlayerViewTemplate.msgBox_2, null, scene);
        tmpMsgBox.setContentTextColor(255, 255, 255, 255);
        tmpMsgBox.setContentText(resMgr.getText('COM_SID_THIS_FILE_FORMAT_NOT_SUPPORTED'));
        tmpMsgBox.enablePointerFocus();
        tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
        tmpMsgBox.setButtonText('button_1', 'all', resMgr.getText('COM_SID_SKIP'));
        tmpMsgBox.setButtonTextColor('button_1', 'normal', 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonTextColor('button_1', 'focused', 0x46, 0x46, 0x46, 255);
		tmpMsgBox.setButtonTextColor('button_1', 'focused-roll-over', 0x46, 0x46, 0x46, 255);
		tmpMsgBox.setButtonTextColor('button_1', 'roll-over', 0x46, 0x46, 0x46, 255);	
        tmpMsgBox.setButtonTextFontSize("button_1", "all", 32);
        tmpMsgBox.setButtonText('button_2', 'all', resMgr.getText('COM_SID_STOP'));
        tmpMsgBox.setButtonTextColor('button_2', 'normal', 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonTextColor('button_2', 'focused', 0x46, 0x46, 0x46, 255);
		tmpMsgBox.setButtonTextColor('button_2', 'focused-roll-over', 0x46, 0x46, 0x46, 255);
		tmpMsgBox.setButtonTextColor('button_2', 'roll-over', 0x46, 0x46, 0x46, 255);
        tmpMsgBox.setButtonTextFontSize("button_2", "all", 32);
		tmpMsgBox.setButtonBackgroundColor("button_1", "focused", 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonBackgroundColor("button_1", "focused-roll-over", 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonBackgroundColor("button_1", "roll-over", 255, 255, 255, 255*0.95);		
		tmpMsgBox.setButtonBackgroundColor("button_2", "focused", 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonBackgroundColor("button_2", "focused-roll-over", 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonBackgroundColor("button_2", "roll-over", 255, 255, 255, 255*0.95);				
        tmpMsgBox.defaultFocusIndex = 1;
        tmpMsgBox.showTime = 10000;
        tmpMsgBox.addListener(messageBox1Listener);

        if(self.keyboardListener){
            self.keyboardListener.destroy();
            self.keyboardListener = null;
        }                                                           
        self.keyboardListener = new KeyboardListener;
            self.keyboardListener.onKeyReleased = function (actor, keyCode) {
                if (keyCode == Volt.KEY_RETURN) {
                   Volt.setTimeout(_.bind(self.unsupportSkip, self), 1);
                }
            };
        tmpMsgBox.addKeyboardListener(this.keyboardListener);    
        tmpMsgBox.show();
        self.msgBox = tmpMsgBox;
	},

	showSingleMsgBox : function() {

		//write vconf , if there is any error, need fresh cotnent
	//	print("showSingleMsgBox setUpdateContentFlag to true");
	//	appConfig.setUpdateContentFlag('true');
		
		if( self.shown == false ){
			return;
		}

		if( self.msgBox != null ){
			self.msgBox.hide();
			self.msgBox.destroy();
			self.msgBox = null;
		}		
		if( self.coverWgt != null ){
			self.coverWgt.removeEventListener("OnMouseOver", self.dimWidgetOnMouseOver);
			self.coverWgt.removeEventListener("OnMouseClick", self.dimWidgetOnMouseClick);
			self.coverWgt.destroy();
			self.coverWgt = null;
		}
		
		self.dimMusicPlayer();
		Log.f("ready to create messageBox1Listener");
        var messageBox1Listener = new MessageBoxListener;
        messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType) {
            if ('button_clicked' == eventType && 'button_1' == nButtonIndex) {
                self.unsupportStop();
            }
        };
		Log.f("end to create messageBox1Listener");

        messageBox1Listener.OnTimeOut = function(messagebox){
            Volt.setTimeout(_.bind(self.unsupportStop,self),1);
        };		

        var tmpMsgBox = PanelCommon.loadTemplate(MusicPlayerViewTemplate.msgBox_1, null, scene);
        tmpMsgBox.setContentTextColor(255, 255, 255, 255);
		
		var text= null;
		if (RunTimeInfo.msgType == 'CANNOT_PLAY')
		{
			text = resMgr.getText('TV_SID_UNABLE_TO_PLAY_THIS_TRACK');
			RunTimeInfo.msgType = null;
		}
		else if (RunTimeInfo.msgType == 'NOT_FOUND')
		{
			text = resMgr.getText('COM_CANNOT_FIND_THE_FILE_YOURE_LOOKING_FOR');
			RunTimeInfo.msgType = null;
			print('[music-player-view.js]--showSingleMsgBox--not found-----');
		}
		else if (RunTimeInfo.msgType == 'NOT_STABLE')
		{
			text = resMgr.getText('COM_TV_PLEASE_CHECK_NETWORK_CONNECTION');
			RunTimeInfo.msgType = null;
			Volt.log('[music-player-view.js]---showSingleMsgBox---network is not stable');
		}		
		
		Volt.log('[music-player-view.js]---showSingleMsgBox---text is ' + text);
		Log.e('[music-player-view.js]---showSingleMsgBox---text is ' + text);
		
        tmpMsgBox.setContentText(text);
        tmpMsgBox.enablePointerFocus();
        tmpMsgBox.setContentTextAlignment("horizontal_align_center", "vertical_align_middle");
        tmpMsgBox.setButtonText('button_1', 'all', resMgr.getText('COM_SID_STOP'));
        tmpMsgBox.setButtonTextColor('button_1', 'normal', 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonTextColor('button_1', 'focused', 0x46, 0x46, 0x46, 255);
		tmpMsgBox.setButtonTextColor('button_1', 'focused-roll-over', 0x46, 0x46, 0x46, 255);
		tmpMsgBox.setButtonTextColor('button_1', 'roll-over', 0x46, 0x46, 0x46, 255);
        tmpMsgBox.setButtonTextFontSize("button_1", "all", 32);
		tmpMsgBox.setButtonBackgroundColor("button_1", "focused", 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonBackgroundColor("button_1", "focused-roll-over", 255, 255, 255, 255*0.95);
		tmpMsgBox.setButtonBackgroundColor("button_1", "roll-over", 255, 255, 255, 255*0.95);		
        tmpMsgBox.defaultFocusIndex = 1;
        tmpMsgBox.showTime = 10000;
        tmpMsgBox.addListener(messageBox1Listener);

        if(self.keyboardListener){
            self.keyboardListener.destroy();
            self.keyboardListener = null;
        }                                                           
        self.keyboardListener = new KeyboardListener;
            self.keyboardListener.onKeyReleased = function (actor, keyCode) {
                if (keyCode == Volt.KEY_RETURN) {
                   Volt.setTimeout(_.bind(self.unsupportStop, self), 1);
                }
            };
        tmpMsgBox.addKeyboardListener(this.keyboardListener);    
        tmpMsgBox.show();
        self.msgBox = tmpMsgBox;
	},

	/**the callback for device connect
	* @name onDeviceConnect	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	onDeviceConnect : function() {
		Log.f("onDeviceConnect in Music-Player-View");
	},

	/**the callback for device disconnect
	* @name onDeviceDisconnect	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	onDeviceDisconnect : function(deviceID,deviceType) {
		Log.f("onDeviceDisconnect in Music-Player-View " + deviceID + self.deviceID);
		if( deviceID != self.deviceID )
		{
			print("onDeviceDisconnect in Music-Player-View " + deviceID + self.deviceID);
			return;
		}
		self.exitMusicPlayer(self.ExitType.DISCONNECT_DEVICE);
	},

	/**the callback for get thumbnail failed
	* @name getThumbnailFailed	 
	* @param {failedPath} get thumbnail failed file path	
	* @memberOf MusicPlayerView	 
	* @method 	 */
	getThumbnailFailed : function(failedPath) {
		Log.f("getThumbnailFailed for " + failedPath);

		var idx = self.playIns.getCurrentIdx();
		var item = self.playIns.getData(idx);
		var currPath = item.get('filePath');

		if( failedPath == currPath ){
			self._updateThumbnail( resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_play_default.PNG', false );
		}		
	},

	/**the callback for get thumbnail successful
	* @name getThumbnailSuccessful	 
	* @param {index} get thumbnail successful file index	
	* @memberOf MusicPlayerView	 
	* @method 	 */
	getThumbnailSuccessful : function( index ) {
		Log.f("getThumbnailSuccessful for " + index);
		if( self.playIns==null ){
			Log.f("self.playIns==null in getThumbnailSuccessful");
			return;
		}

		var idx = self.playIns.getCurrentIdx();

		if( idx == index ){
			self._updateThumbnail( THUMB_BASE_PATH + 'Player' + idx + '.jpg', true );
		}
		if( self.musicList != null ){
			self.musicList.updateItem(index);
		}
	},

	/**try to get the music file thumbnail
	* @name _updateThumbnail	 
	* @param {url} the music file url
	* @memberOf MusicPlayerView	 
	* @method 	 */
	_updateThumbnail : function( url, flag ) {
		Log.f("update the thumbnail to " + url + " flag= " + flag);
		if( self.thumbArea== null ){
			Log.f( "_updateThumbnail failed because of self.thumbImg== null" );
			return;
		}
	    self.thumbArea.src = url;
		

	},
	
	onThumbnailReady : function() {
		Volt.log('[music-player-view.js]--------onThumbnailReady------');
		var bgColor = {r:96,g:116,b:139,a:255};
		var accessibility = Vconf.getValue('db/menu/system/accessibility/highcontrast');

		if( accessibility==true ){
			bgColor = {r:37,g:37,b:37,a:255};
		}
		if( self.thumbArea.src == resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_play_default.PNG' ){
			self.musicView.animate("color", bgColor, 1000);
//			var utility = new Utility;
//			self.txtColor = (utility.extractForegroundColor(bgColor.r, bgColor.g, bgColor.b)).color;
//			self._updateTxtColor(self.txtColor);
			Volt.log('[music-player-view.js]--------onThumbnailReady--thumbArea is the default image----');
			return;				
		}
		//Volt.log('---------------The case for successfully getting thumbArea-----!!');	
		//self.thumbArea.setMaskImage('/usr/apps/org.volt.mycontents/src_original/'+resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_play.PNG',0,0);//
		Log.f('before setMaskImage!!' + resMgr.getImgPath()+'/default_thumb/mc_playlist_thumbnail_play.PNG');
		
		
		if( accessibility==true ){
			self.musicView.animate("color", bgColor, 1000);
			return;
		}
		
		var colorPicking = self.thumbArea.getColorPicking(0,376,418,418);
		Log.f("music player view colorPicking 10:success " + colorPicking.success);
		Log.f("colorPicking:color.r " + colorPicking.color.r);
		Log.f("colorPicking:color.g " + colorPicking.color.g);
		Log.f("colorPicking:color.b " + colorPicking.color.b);

		if(colorPicking.success == true){
	        bgColor.r = colorPicking.color.r,
	        bgColor.g = colorPicking.color.g,
	        bgColor.b = colorPicking.color.b;
	    }

		self.backColorPick.r = bgColor.r;
		self.backColorPick.g = bgColor.g;
		self.backColorPick.b = bgColor.b;

//		var utility = new Utility;
//		self.txtColor = (utility.extractForegroundColor(colorPicking.color.r, colorPicking.color.g, colorPicking.color.b)).color;
//		self._updateTxtColor(self.txtColor);
		self.musicView.animate("color", bgColor, 1000);	
	},

	/**update the GUI text's color
	* @name _updateTxtColor	 
	* @param {colorValue} the color value for text
	* @memberOf MusicPlayerView	 
	* @method 	 */
	_updateTxtColor : function( colorValue ) {
		if( self.titleTxt==null || self.artistTxt==null || self.currTxt==null || self.totalTxt==null ){
    		Log.f("GUI element is not enough!");
    		return;
    	}

		Log.f("_updateTxtColor to " + colorValue.r + " " + colorValue.g + " " + colorValue.b );

//		self.titleTxt.setTextColor(colorValue.r, colorValue.g, colorValue.b);
//		self.titleTxt.textColor = colorValue;
		self.artistTxt.textColor = colorValue;
		
		self.currTxt.textColor = colorValue;
		self.totalTxt.textColor = colorValue;

		if( self.musicList != null ){
			self.musicList.updateTextColor(colorValue);
		}
	},

	/**progress bar's mouse click callback
	* @name _onValueChanged	 
	* @param {process} the click position
	* @memberOf MusicPlayerView	 
	* @method 	 */
	
	_onValueChanged : function( process, type ) {	
		if( type=='setvalue'){
			var focusWgt = Volt.Nav.getFocusedWidget();
			if( self.progressWgt == focusWgt){
				if( self.playIns != null ){
					if( self.playIns.seekEnable == true )
					{
						var changeX = 0;
						Volt.log('----------HALOUtil.getOrientation () is ' + HALOUtil.getOrientation ());
						if(HALOUtil.getOrientation () == "right-to-left")// for reverser
						{
							changeX = self.widget.getChild('currTime').x + self.progressWgt.x - self.progressWgt.width*self.progressPos;//) + 142*(mycontentWidth/1920)
						}
						else
						{
							changeX = self.progressWgt.x + self.progressWgt.width*self.progressPos - 16
							//self.balloon.update(self.currTxt.text,self.progressWgt.x + self.progressWgt.width*self.progressPos - 16, self.progressWgt.y + 6);
						}
						if(self.balloon != null){
							self.balloon.update(self.currTxt.text, changeX, self.progressWgt.y + 6);
						}
					}
				}
				// for two arrow in progress bar
				if (Vconf.getInteger('memory/window_system/input/cursor_visible'))
				{
					Volt.log("[music-player-view.js]---onFocus--- Vconf.getInteger('memory/window_system/input/cursor_visible') is " + Vconf.getInteger('memory/window_system/input/cursor_visible'));
				}
				else
				{
					self._showProgressArrow();
					var MoveXForRight =0;
					var MoveXForLeft = 0;
					if (HALOUtil.getOrientation () == "right-to-left")
					{
						MoveXForRight = self.widget.getChild('currTime').x +self.progressWgt.x -self.progressWgt.width*self.progressPos + 0.008854*1920 + 0.008854*1920*1.5+ 0.001041*1920;//left
						MoveXForLeft = self.widget.getChild('currTime').x + self.progressWgt.x - self.progressWgt.width*self.progressPos - 0.008854*1920 - 0.001041*1920;					
					}
					else
					{
						MoveXForRight = self.progressWgt.x +self.progressWgt.width*self.progressPos - 0.008854*1920 - 0.008854*1920*0.8- 0.001041*1920;
						MoveXForLeft = self.progressWgt.x + self.progressWgt.width*self.progressPos+ 0.008854*1920 + 0.001041*1920;
					}
					self._updateProgressArrowPosition(MoveXForRight, MoveXForLeft);//(self.progressWgt.x +self.progressWgt.width*self.progressPos - 0.008854*1920 - 0.008854*1920*0.8- 0.001041*1920,self.progressWgt.x + self.progressWgt.width*self.progressPos+ 0.008854*1920 + 0.001041*1920);
				}
				
			}
		}
		else if( type == 'click' || type == 'dragend'){
			print('type == click || type == dragend');
			var para = process.value / process.maxValue;
			var per = para/1000;
			self.progressDrag = false;
			if( self.playIns != null ){
				self.progressPos = per;
				var targetTime = per * self.playIns.getDuration();
				var res = self.playIns.seek(targetTime*1000);
				print("[music-player-view.js]:_mouseClickProgress seek to "+ targetTime + " " + res);			
				if( res == -1 ){
					self.showNAMessageBox();
				}
			}			
		}
		else if( type=='drag' ){
			print('type == drag' + 'process.value = ' + process.value + 'process.maxValue = ' + process.maxValue);
			var para = process.value / process.maxValue;
			self.progressDrag = true;
			if( self.playIns != null ){
				var targetTime = para * self.playIns.getDuration();
				var secondStyle = targetTime/1000;
				var hour = parseInt(secondStyle/3600);
				var minute = parseInt(secondStyle%3600 / 60);
				var second = parseInt(secondStyle%60);
				var timeStr = self.playIns.getTimeString(hour, minute,second);				
				print('timeStr in drag is ' + timeStr + 'para = ' + para + 'self.playIns.getDuration = ' + self.playIns.getDuration());
				if (HALOUtil.getOrientation () == "right-to-left")
				{
					//HALOUtil.getOrientation () == "right-to-left"
					if(self.balloon != null){
						self.balloon.update(timeStr, self.widget.getChild('currTime').x + self.progressWgt.x - self.progressWgt.width*para, self.progressWgt.y + 6);
					}
				}else{
					if(self.balloon != null){
						self.balloon.update(timeStr,self.progressWgt.x + self.progressWgt.width*para - 16, self.progressWgt.y + 6);
					}
				}
			}
		}
	},

	/**show balloon for progress Bar
	* @name _showBalloon4ProgressBar	 
	* @memberOf MusicPlayerView	 
	* @method 	 */
	_showBalloon4ProgressBar : function() {
    	if( self.balloon != null ){
    		self.balloon.destroy();
    		self.balloon = null;
    	}
		var xForBalloon = 0;
		
		if (HALOUtil.getOrientation () == "right-to-left")
		{
			xForBalloon = self.widget.getChild('currTime').x + self.progressWgt.x - self.progressWgt.width*self.progressPos;// nt add 16 is avoid the offset
		}
		else
		{
			xForBalloon= self.progressWgt.x + self.progressWgt.width*self.progressPos - 16
		}
    	var opt = {
    		text: self.currTxt.text,
    		x: xForBalloon,
    		y: self.progressWgt.y + 6,
			wdgHeight: 34,
			wdgWidth : 34,
    		fontsize: 30,
    		font: '30px',
    		tailType: 'down',
    	};

		
    	self.balloon = new BalloonTips();
    	self.balloon.show(opt);		
	},

	_onMouseOver : function() {
		Log.f( "[music-player-view.js]: _onMouseOver" );
	},

	onCursorVisible : function() {
		if( self.musicView == null ){
			return;
		}
		
		if (self.ProgressLeftArrow != null)
		{
			self.ProgressLeftArrow.destroy();
			self.ProgressLeftArrow = null;
		}

		if (self.ProgressRightArrow != null)
		{
			self.ProgressRightArrow.destroy();
			self.ProgressRightArrow = null;
		}
																		
		var NormalButton = Volt.require('lib/custom-widgets/cm-normal-button.js');
		if( self.closeBtn == null ){ 
			self.closeBtn = new NormalButton({ 
				x: 0, y:0, width: 78, height: 98,
				color: {r:0,g:0,b:0,a:51},
        		src: '',
        		opacity: 255,
			}); 
			self.closeBtn.parent = self.musicView;
			self.closeBtn.addEventListener('onMouseOver', self._onCloseBtnMouseOver);
			self.closeBtn.addEventListener('onMouseOut', self._onCloseBtnMouseOut);		
			self.closeBtn.addEventListener('onMouseClick', self._onCloseBtnMouseClick);	
	 
			self.closeBtn.setIconImage({state: "all", src:resMgr.getImgPath()+ '/mc_arrow_return_n.png'});
			self.closeBtn.setIconAttr({x:18.5, y:31.5,width:36,height:36});
			self.closeBtn.setIconAlpha({state: "all", alpha: 153});			
		}
		if( self.exitBtn == null ) {
			self.exitBtn = new NormalButton({ 
				x: RunTimeInfo.SceneResolution-78, y:0, width: 78, height: 98,
				color: {r:0,g:0,b:0,a:51},
        		src: '',
        		opacity: 255,
			}); 
			self.exitBtn.parent = self.musicView;
			self.exitBtn.addEventListener('onMouseOver', self._onExitBtnMouseOver);
			self.exitBtn.addEventListener('onMouseOut', self._onExitBtnMouseOut);		
			self.exitBtn.addEventListener('onMouseClick', self._onExitBtnMouseClick);	
	 
			self.exitBtn.setIconImage({state: "all", src:resMgr.getImgPath()+ '/common/comn_icon_tm_close_nor.png'});
			self.exitBtn.setIconAttr({x:18.5, y:31.5,width:36,height:36});
			self.exitBtn.setIconAlpha({state: "all", alpha: 153});	
		}
	},

	onCursorHidden : function() {
		if( self.musicView == null ){
			return;
		}		
		if(self.closeBtn != null){
			self.closeBtn.destroy();
			self.closeBtn = null;
		}
		if(self.exitBtn != null){
			self.exitBtn.destroy();
			self.exitBtn = null;
		}		
	},	
	_showProgressArrow: function()
	{
		Log.f("[music-player-view.js]: _showProgressArrow  ");
		//Volt.log("[music-player-view.js]: _showProgressArrow  ");
		//print("[music-player-view.js]: _showProgressArrow  ");

		Volt.log('music-player-view.js]: -------------_showProgressArrow-----------HALOUtil.getOrientation () is ' + HALOUtil.getOrientation ());
		if (HALOUtil.getOrientation () == "right-to-left")//reverse state
		{

			if (self.playIns.currTime > (self.playIns.totalTime-1000))
			{
				Volt.log("self.playIns.currTime == self.playIns.totalTime, do not need to show right arrow");
			}
			else if (self.playIns.currTime <= (self.playIns.totalTime-1000))
			{
				if (self.ProgressRightArrow != null)
				{
					//self.ProgressRightArrow.destroy();
					//self.ProgressRightArrow = null;
				}
				else //if ( (self.widget.getChild('currTime').x - self.progressWgt.width*self.progressPos) < (self.widget.getChild('currTime').x -(40+0.008854*1920 + 0.008854*1920*0.8 + 0.001041*1920)))
				{
					self.ProgressRightArrow = new ImageWidgetEx(
						{   x: self.widget.getChild('currTime').x +self.progressWgt.x - self.progressWgt.width*self.progressPos - 0.008854*1920 - 0.001041*1920,
			 				y: self.progressWgt.y - 7,
			 				width: 12, height: 16,
			 				src: resMgr.getImgPath()+'/progress/info_progress_control_arrow_right.png',
							parent: self.musicView,
			 			});	
					
				}		
			}


			if (self.playIns.currTime < 1000)
			{
				Volt.log("self.playIns.currTime is 0, do not need to show left arrow");
			}
			else if (self.playIns.currTime >= 1000)
			{
				if (self.ProgressLeftArrow != null)
				{
					//self.ProgressLeftArrow.destroy();
					//self.ProgressLeftArrow = null;
				}
				else //if ((self.widget.getChild('currTime').x - self.progressWgt.width*self.progressPos) > (self.widget.getChild('currTime').x -(self.progressWgt.width- 0.008854*1920 + 0.001041*1920)))
				{
					self.ProgressLeftArrow = new ImageWidgetEx(
						{   x: self.widget.getChild('currTime').x +self.progressWgt.x - self.progressWgt.width*self.progressPos + 0.008854*1920 + 0.008854*1920*0.8 + 0.001041*1920,
			 				y: self.progressWgt.y - 7,
			 				width: 12, height: 16,
			 				src: resMgr.getImgPath()+'/progress/info_progress_control_arrow_left.png',
							parent: self.musicView,
			 			});				
				}			
			}
		}
		else
		{
			if (self.ProgressRightArrow != null)
			{
				//self.ProgressRightArrow.destroy();
				//self.ProgressRightArrow = null;
			}
			else if (self.playIns.currTime <= (self.playIns.totalTime-1000))
			{
				self.ProgressRightArrow = new ImageWidgetEx(
					{   x: self.progressWgt.x + self.progressWgt.width*self.progressPos + 0.008854*1920 + 0.001041*1920,
		 				y: self.progressWgt.y - 7,
		 				width: 12, height: 16,
		 				src: resMgr.getImgPath()+'/progress/info_progress_control_arrow_right.png',
						parent: self.musicView,
		 			});	
				
			}
			
			if (self.ProgressLeftArrow != null)
			{
				//self.ProgressLeftArrow.destroy();
				//self.ProgressLeftArrow = null;
			}
			else if (self.playIns.currTime >= 1000)
			{
				self.ProgressLeftArrow = new ImageWidgetEx(
					{   x: self.progressWgt.x + self.progressWgt.width*self.progressPos - 0.008854*1920 - 0.008854*1920*0.8 - 0.001041*1920,
		 				y: self.progressWgt.y - 7,
		 				width: 12, height: 16,
		 				src: resMgr.getImgPath()+'/progress/info_progress_control_arrow_left.png',
						parent: self.musicView,
		 			});				
			}		
		}
	
		//self.ProgressRightArrow.show();
		//self.ProgressLeftArrow.show();	
		return;
	},

	_updateProgressArrowPosition:function(valueX1, valueX2)
	{
		Log.f("[music-player-view.js]: _updateProgressArrowPosition = ");
		Volt.log("[music-player-view.js]: _updateProgressArrowPosition = ");
		if (self.ProgressRightArrow != null)
		{
			if (self.playIns.currTime > (self.playIns.totalTime-1000))
			{
				self.ProgressRightArrow.hide();
			}
			else 
			{
				self.ProgressRightArrow.x = valueX2;
				self.ProgressRightArrow.show();
			}				
		}
		else
		{
			if (self.playIns.currTime < (self.playIns.totalTime-1000))
			{
				self.ProgressRightArrow = new ImageWidgetEx(
					{   x: valueX2,
		 				y: self.progressWgt.y - 7,
		 				width: 12, height: 16,
		 				src: resMgr.getImgPath()+'/progress/info_progress_control_arrow_right.png',
						parent: self.musicView,
		 			});			
			}

			if (self.playIns.currTime > (self.playIns.totalTime-1000))
			{
				if (self.ProgressRightArrow != null)
				{
					self.ProgressRightArrow.hide();				
				}
			}
			else
			{
				if (self.ProgressRightArrow != null)
				{
					self.ProgressRightArrow.show();				
				}			
			}
		}
		
		
		if (self.ProgressLeftArrow != null)
		{
			if (self.playIns.currTime < 1000)
			{
				self.ProgressLeftArrow.hide();
			}
			else 
			{
				self.ProgressLeftArrow.x = valueX1;
				self.ProgressLeftArrow.show();					
			}
		}
		else
		{
			if (self.playIns.currTime> 1000)
			{
				self.ProgressLeftArrow = new ImageWidgetEx(
					{   x: valueX1,//self.progressWgt.x + self.progressWgt.width*self.progressPos - 0.008854*1920 - 0.008854*1920*0.8 - 0.001041*1920
		 				y: self.progressWgt.y - 7,
		 				width: 12, height: 16,
		 				src: resMgr.getImgPath()+'/progress/info_progress_control_arrow_left.png',
						parent: self.musicView,
		 			});	

				if (self.playIns.currTime < 1000)
				{
					if (self.ProgressLeftArrow != null)
					{
						self.ProgressLeftArrow.hide();					
					}
				}
				else
				{
					if (self.ProgressLeftArrow != null)
					{
						self.ProgressLeftArrow.show();					
					}				
				}
			}
		}
		return;
	},

	_onCloseBtnMouseOver : function() {
		print("music player _onCloseBtnMouseOver");
		if(self.balloon != null){
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
		
		if( self.closeBtn != null)
		{
			self.closeBtn.setFocus();
			self.closeBtn.setIconAttr({x:16.5, y:29.5,width:40,height:40});
			self.closeBtn.setIconAlpha({state: "all", alpha: 255});	

			var opt = {
	    		text: resMgr.getText('COM_SID_RETURN'),
	    		x: self.closeBtn.x,
	    		y: self.closeBtn.y,
				wdgHeight: self.closeBtn.height,
				wdgWidth : self.closeBtn.width,
	    		fontsize: 30,
	    		font: '30px',
	    		tailType: 'up',
	    	};

		
	    	self.balloon = new BalloonTips();
	    	self.balloon.show(opt);		
		}
	},

	_onCloseBtnMouseOut : function() {
		print("music player _onCloseBtnMouseOut");
		Log.f("[_onCloseBtnMouseOut]: self.preFocus = "+self.preFocus.id);
		
		if(self.balloon != null){
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
		
		if( self.closeBtn != null)
		{
			self.closeBtn.setIconAttr({x:18.5, y:31.5,width:36,height:36});
			self.closeBtn.setIconAlpha({state: "all", alpha: 153});		
		}
	},

	_onCloseBtnMouseClick : function() {
		print("music player _onCloseBtnMouseClick");
		Log.f( "[music-player-view.js]: _onCloseBtnMouseClick" );
		
		if(self.balloon != null){
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
				
		if( self.closeBtn != null && self.closeBtn.opacity == 255){
			self.exitMusicPlayer(self.ExitType.RETURN_KEY);
		}
	},

	_onExitBtnMouseOver : function() {
		print("music player  _onExitBtnMouseOver  ");
		if(self.balloon != null){
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}

		var opt = {
    		text: resMgr.getText('COM_SID_EXIT'),
    		x: self.exitBtn.x,
    		y: self.exitBtn.y,
			wdgHeight:  self.exitBtn.height,
			wdgWidth :  self.exitBtn.width,
    		fontsize: 30,
    		font: '30px',
    		tailType: 'up',
    	};

		
    	self.balloon = new BalloonTips();
    	self.balloon.show(opt);	
		
		self.exitBtn.setFocus();
		self.exitBtn.setIconAttr({x:16.5, y:29.5,width:40,height:40});
		self.exitBtn.setIconAlpha({state: "all", alpha: 255});
	},

	_onExitBtnMouseOut : function() {
		print("music player  _onExitBtnMouseOut  ");
		if(self.balloon != null){
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
				
		self.exitBtn.setIconAttr({x:18.5, y:31.5,width:36,height:36});
		self.exitBtn.setIconAlpha({state: "all", alpha: 153});
	},

	_onExitBtnMouseClick : function() {
		print("music player  _onExitBtnMouseClick  ");
		Log.f( "[music-player-view.js]: _onExitBtnMouseClick" );
		try{
			if(self.balloon != null){
				self.balloon.hide();
				self.balloon.destroy();
				self.balloon = null;
			}
			if( self.exitBtn != null && self.exitBtn.opacity == 255){
				var mainView = Volt.require('app/views/main-view.js');
				mainView.widget.hide();
				Volt.exitKey();
			}
		}
		catch(e){
			Log.e("music-player-view.js]  Volt.exitKey() "+e);
			Volt.exit();
		}
	},	

	_realExit4Dmr : function() {
		Log.f("_realExit4Dmr in music player");
		Volt.log('[music-player-view.js]--_realExit4Dmr is called---RunTimeInfo.launchMusicReturnContentOrNot is ' + RunTimeInfo.launchMusicReturnContentOrNot);
		self.dmrTimer = null;

		if(self.dmrIns != null){
			self.dmrIns.sendStopReason(0);
			self.dmrIns.destroy();
			self.dmrIns = null;
		}		
		var DeviceProvider = Volt.require("app/models/device-provider.js");
		//Volt.log('[]RunTimeInfo.launchMusicReturnContentOrNot is ' + RunTimeInfo.launchMusicReturnContentOrNot)
		if( RunTimeInfo.launchMusicReturnContentOrNot == false )
		{
			Volt.log('[music-player-view.js]-------to test whether there is a black');
			Volt.exit();				
		}
		else{
			if(DeviceProvider.getDeviceCount() < 1){
				RunTimeInfo.router.returnFromMusicPlayer(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
			}
			else{
				if( RunTimeInfo.router.preViewType != EViewType.eMusicPlayerView ){
					Log.f("Switch to preView : " + RunTimeInfo.router.preViewType);
					RunTimeInfo.router.returnFromMusicPlayer(RunTimeInfo.router.preViewType, EViewSwitchAniType.eNoneAni);
				}
				else{
					RunTimeInfo.router.returnFromMusicPlayer(EViewType.eAllContentView, EViewSwitchAniType.eNoneAni);
				}
			}
		}
		return;
	},

	dimMusicPlayer : function() {
		print(" dimMusicPlayer ");
		self.hideFocus();
		self.coverWgt = new WidgetEx({
		    width: RunTimeInfo.SceneResolution,
		    height: 1080,
		    parent: scene,
		    color: {r: 15, g:24, b:38, a: 0},
		});
		self.coverWgt.addEventListener("OnMouseOver", self.dimWidgetOnMouseOver);
		self.coverWgt.addEventListener("OnMouseClick", self.dimWidgetOnMouseClick);
		self.setWidget(self.coverWgt);
		Volt.Nav.setRoot(self.widget);
	},

	undimMusicPlayer : function() {
		print(" undimMusicPlayer ");
		if( self.coverWgt != null ){
			print("undimMusicPlayer removeEventListener");
			self.coverWgt.removeEventListener("OnMouseOver", self.dimWidgetOnMouseOver);
			self.coverWgt.removeEventListener("OnMouseClick", self.dimWidgetOnMouseClick);
			self.coverWgt.destroy();
			self.coverWgt = null;
		}
		self.setWidget(self.musicView);
		Volt.Nav.setRoot(self.widget);

		self.showFocus();
	},

	dimWidgetOnMouseOver : function() {
		return false;
	},
	dimWidgetOnMouseClick : function() {
		Log.f("dimWidgetOnMouseClick ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		return false;
	},
	onInformationDestroy:function(){
		print("onInformationDestroy");
		self.infoWindow = null;

	},
	onHideAllPopup : function() {
		Log.f("[music-player-view.js]----onHideAllPopup in music player");
		print('[music-player-view.js]----onHideAllPopup in music player, and focusWidget will be set to NULL');
		if( self.infoWindow!= null && self.infoWindow.popupWidget != null ){
			self.infoWindow.hide();
			self.infoWindow = null;
			self.focusWidget = null;
			self.focusWidget = Volt.Nav.getFocusedWidget();
			Volt.log('[music-player-view.js]----onHideAllPopup---set null and get the focus widget---');
			
		}
		else if( self.msgBox != null ){
			self.msgBox.destroy();
			self.msgBox = null;
			self.focusWidget = null;
			Volt.log('[music-player-view.js]----onHideAllPopup---msgBox to destroy');
			self.undimMusicPlayer();// to solve the crash defect
			Volt.log('[music-player-view.js]----onHideAllPopup---msgBox to destroy---2')
		}
	},

	setListFocusNearestOrNot : function( flag ) {
		if( self.musicList != null ){
			self.musicList.nearFocusIdxFlag = flag;
		}
	},

	onHighContrast : function(){
		var highCon = Vconf.getValue('db/menu/system/accessibility/highcontrast');

		if( self.musicView == null ){
			return;
		}

		Log.f("highCon has changed to "+highCon);

		if( highCon == true ){
			self.musicView.animate("color", {r:37,g:37,b:37,a:255}, 1000);
			
			if( self.titleTxt!= null ){
				self.titleTxt.setTextColor(255,255,255,255);	
			}
			if( self.artistTxt!= null ){
				self.artistTxt.textColor = {r:255,g:255,b:255,a:255};
			}

			if( self.totalTxt!= null && self.currTxt!= null ){
				self.totalTxt.opacity = 255;
				self.currTxt.opacity = 255;			
			}
			if( self.musicList!=null){
				self.musicList.listWgt.updateAllItems();
			}
		}
		else{
			self.musicView.animate("color", self.backColorPick, 1000);
			
			if( self.titleTxt!= null ){
				self.titleTxt.setTextColor(255,255,255,230);	
			}
			if( self.artistTxt!= null ){
				self.artistTxt.textColor = {r:255,g:255,b:255,a:153};
			}

			if( self.totalTxt!= null && self.currTxt!= null ){
				self.totalTxt.opacity = 153;
				self.currTxt.opacity = 153;			
			}	
			if( self.musicList!=null){
				self.musicList.listWgt.updateAllItems();
			}			
		}
	},
});
	
exports = MusicPlayerView;

