var _ = Volt.require("modules/underscore.js")._;
var Backbone = Volt.require('modules/backbone.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var cmSubList = Volt.require('lib/custom-widgets/cm-sub-list.js');
var resMgr = Volt.require('app/controller/resource-controller.js');
var voiceGuide = Volt.require('app/common/voice-guide.js');
var DeviceProvider = Volt.require("app/models/device-provider.js");
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var CommonInfo = Volt.require('app/common/define.js');
var EViewType = CommonInfo.EViewType;
var EOptType = CommonInfo.EOptType;
var EventType = CommonInfo.EventType;
var EventMediator = RunTimeInfo.EventMediator;


var self = null;

var DeviceSelectorView = PanelCommon.BaseView.extend({
	x: 0,
	y: 0,
	itemLine: 4,
	selectIndex: 0,
	listWidth: 383,
	listHeight: 4 * 72 +60 * 2,
	itemTexts: [],
	itemList: null,
	optType: null,
	deviceCollect : [],
	initialize: function(args){
		self = this;
		self.parent = args.parent;
		if(args.x != undefined) {
			this.x = args.x;
		}
		if(args.y != undefined) {
			this.y= args.y;
		}
		if(args.itemLine != undefined){
			this.itemLine = args.itemLine;
		}
		if(args.listWidth != undefined){
			this.listWidth = args.listWidth;
		}
		self.optType = args.optType;
		var listItemWidth = this.listWidth;
		var listItemHeight = 72;
		var singleLineListHeight = 4*72;
		print('this.itemLine : ' + this.itemLine + '');
		
		if(self.optType == EOptType.ePlaySelType){
			print('self.optType == EOptType.ePlaySelType');
			if(RunTimeInfo.router.currentViewType == EViewType.eRecordContentView){
				var devNum = DeviceProvider.getUsbDeviceCount();
				print('usb device count: ' + devNum);
				if(devNum <= 4){
					this.listHeight = devNum * 72+ 2*(devNum -1);
					singleLineListHeight = devNum * 72+ 2*(devNum -1);

				}
				else{
					this.listHeight = 4 * 72 + 60* 2;
				}
			}
			else{
				var devNum = DeviceProvider.getDeviceCount();
				print('total device count: ' +devNum);
				if(devNum <= 4){
					this.listHeight = devNum * 72 + 2*(devNum -1);
					singleLineListHeight = devNum * 72 + 2*(devNum -1);
				}
				else{
					this.listHeight = 4 * 72 + 60* 2;
					
				}
			}
		}
		else{
			print('self.optType == other type');
			var devNum = DeviceProvider.getUsbDeviceCount();
			print('usb device count: ' + devNum);
			if(devNum <= 4){
				this.listHeight = devNum * 72+ 2*(devNum -1);
				singleLineListHeight = devNum * 72+ 2*(devNum -1);

			}
			else{
				this.listHeight = 4 * 72 + 60* 2;
			}
		}

		print('[device selector] listHeight: ' + this.listHeight);
		//this.listHeight = 4 * 72 + 60* 2;
		this.itemList = new cmSubList({
			parent: args.parent,
			width: 383,
			height: this.listHeight,
			color: {r: 0x0f, g: 0x18, b: 0x26, a: 255},
			singleLineListWidth: 383,
			singleLineListHeight: singleLineListHeight,
			nItemNumberOnWindow: 4,			
		});
		this.itemList.loopLeftFlag = false;
		this.itemList.loopRightFlag = false;
		if(self.optType == EOptType.ePlaySelType){
			if(RunTimeInfo.router.currentViewType == EViewType.eRecordContentView){
				//dlna device not have record file
				if(DeviceProvider.getUsbDeviceCount() > 4){
					this.itemList.setSingleLineListPosition({x: 0, y: 60});
				}
				else{
					this.itemList.setSingleLineListPosition({x: 0, y: 0});
				}
			}
			else{
				if(DeviceProvider.getDeviceCount() > 4){
					this.itemList.setSingleLineListPosition({x: 0, y: 60});
				}
				else{
					this.itemList.setSingleLineListPosition({x: 0, y: 0});
				}
			}
		}
		else{
			if(DeviceProvider.getUsbDeviceCount() > 4){
				this.itemList.setSingleLineListPosition({x: 0, y: 60});
			}
			else{
				this.itemList.setSingleLineListPosition({x: 0, y: 0});
			}
		}
		this.itemList.setFirstLayerBGColor({firstLayerBGColor:{r: 255, g: 255, b: 255, a:10}});
		this.itemList.showTime = 10000;
		this.itemList.custom = {focusable: true};
		var subListListener = new SubListListener;
		subListListener.OnFocusChanged = function(sublist,fromItemIndex,toItemIndex){
			print('OnFocusChanged >>>>  fromItemIndex:'+fromItemIndex+'  toItemIndex:' +toItemIndex);
			if(fromItemIndex > -1 && toItemIndex > -1){
				var txt = sublist.text({index: toItemIndex});
				voiceGuide.play(txt);
			}
			else{
				if(toItemIndex < 0){
					//EventMediator.trigger(EventType.EVENT_TYPE_HIDE_DEVSELECTOR_POPUP);
				}
			}
		}
		
		subListListener.OnItemClicked = function (sublist, itemIndex) {
			if(sublist != null){
				sublist.onItemClicked();
			}
			else{
				print('device-selector-view.js sublist is null!');
				Log.f('device-selector-view.js sublist is null!');
			}
		};
		subListListener.OnTimeOut = function(sublist){
			print('device selevtor view OnTimeOut');
			if(sublist != null && sublist.onReturn != undefined ){
				sublist.onReturn();
			}
		};

		this.itemList.addListener(subListListener);
	},
	render: function(){
		this.setWidget(this.itemList);
		this.widget.custom.focusable = true;
		Volt.Nav.setRoot(this.widget);
		this.itemList.setFocus();
		this.itemList.enableFocus();
		this.itemList.showFocus('true');
	},
	events: {      
        'NAV_FOCUS':'onFocus',
        'NAV_BLUR':'onBlur'
    },
    onFocus: function(widget){
    	print('[device-selector-view] getFocus');
		///self.setSelectIndex(0);
		//self.itemList.setFocus();
		//self.itemList.showFocus('true');

    },

	onBlur: function(widget){
		//self.itemList.killFocus();
    },
    
	create: function(args){
		
	},
	setListText : function(devText){
		this.itemTexts = devText;
		this.itemList.addItem({itemNum: this.itemTexts.length, itemSpace: 72, itemGap : 2});
		for(var i = 0; i < this.itemTexts.length ; i++){
			this.itemList.addData({
				index: i ,
				itemBGNormalColor: {r: 255, g: 255, b: 255, a: 0},
                itemBGFocusedColor: {r: 255,g: 255,b: 255,a: 0},
				itemBGDimColor: {r: 255,g: 255,b: 255,a: 0},
				image:{x:8,y:16,width:40, height:40, 
					normalImagePath:resMgr.getImgPath()+'/CheckBox/popup_sub_check_icon_y.png', 
					dimImagePath: resMgr.getImgPath()+'/CheckBox/popup_sub_check_icon_y.png', 
					focusedImagePath: resMgr.getImgPath()+'/CheckBox/popup_sub_check_icon_y.png',
					hAlign: 'horizontal_align_center',
					vAlign: 'vertical_align_middle',
				},
				text:{x:56,y:0,width:250, height:72, 
					itemTextString: this.itemTexts[i],
					itemTextNormalColor: {r: 0xFF,g: 0xFF,b: 0xFF,a: 255}, 
					itemTextFocusedColor: {r: 0xFF,g: 0xFF,b: 0xFF,a: 255}, 
					itemTextDimColor: {r: 0xFF,g: 0xFF,b: 0xFF,a: 38},
					itemTextNormalFont: 'SamsungSmart_Light 28px',
					itemTextFocusedFont: 'SamsungSmart_Light 28px',
					itemTextDimFont: 'SamsungSmart_Light 28px',
					hAlign: 'horizontal_align_left',
					vAlign: 'vertical_align_middle',
				},
			})
		}
		this.itemList.setDataSource();
		this.itemList.setArrowImageAttr({ArrowDirection: "upArrow", x: 24, y: 0, width:310, height: 60, arrowNormalImagePath:  resMgr.getImgPath()+'/Arrow/popup_sublist_arrow_up_n.png'});
		this.itemList.setArrowImageAttr({ArrowDirection: "downArrow", x: 24, y: 348,width:310, height: 60, arrowNormalImagePath:  resMgr.getImgPath()+'/Arrow/popup_sublist_arrow_down_n.png'});
		this.itemList.focusItemIndex = 0;
		this.itemList.setFocusImage( resMgr.getImgPath() + '/common/ksc_focus.png', -4, -4);
	},

	
	setSelectIndex: function(index){
		this.itemList.checkItemIndex = index;
		this.itemList.focusItemIndex = index;
		this.selectIndex =index;
	},

	setSelectId : function(devId){
		for( var i =0; i < this.deviceCollect.length; i++ ){
			if( devId == this.deviceCollect[i].id ){
				print('default focus index: ' + i);
				this.selectIndex = i;
				this.itemList.checkItemIndex = i;
				this.itemList.focusItemIndex = i;
			}
			
		}
	},
	getSelectText: function(){
		return this.itemTexts[this.selectIndex];
	},
	getselectIndex: function(){
		return this.selectIndex;
	},
	getDeviceCollect: function(optType){
		//var DeviceProvider = Volt.require("app/models/device-provider.js");
		self.optType = optType;
		var devTexts = [];
		switch(optType){
			case EOptType.ePlaySelType:
				if(RunTimeInfo.router.currentViewType == EViewType.eRecordContentView){
					print('getDeviceCollect is eRecordContentView');
					for(var i = 0; i < DeviceProvider.getDeviceCount() ; i++) {
						var deviceDisplayName = DeviceProvider.getDeviceByIndex(i).get('displayName');
				    	var deviceId = DeviceProvider.getDeviceByIndex(i).get('id');
				    	var type = DeviceProvider.getDeviceByIndex(i).get('type');
						if(type != 'USB'){
							Log.e("getDeviceCollect optType: " + optType+ "type:"+type);
							continue;
						}
						this.deviceCollect.push({id: deviceId, devType: type, name: deviceDisplayName});
						devTexts.push(deviceDisplayName);
					}
				}
				else{
					print('getDeviceCollect is not eRecordContentView');
					for(var i = 0; i < DeviceProvider.getDeviceCount() ; i++) {
						var deviceDisplayName = DeviceProvider.getDeviceByIndex(i).get('displayName');
				    	var deviceId = DeviceProvider.getDeviceByIndex(i).get('id');
				    	var type = DeviceProvider.getDeviceByIndex(i).get('type');
						this.deviceCollect.push({id: deviceId, devType: type, name: deviceDisplayName});
						devTexts.push(deviceDisplayName);
					}
				}
				break;
			case EOptType.eDeleteType:
			case EOptType.eSendType:
				for(var i = 0; i < DeviceProvider.getDeviceCount() ; i++) {
					var deviceDisplayName = DeviceProvider.getDeviceByIndex(i).get('displayName');
			    	var deviceId = DeviceProvider.getDeviceByIndex(i).get('id');
			    	var type = DeviceProvider.getDeviceByIndex(i).get('type');
					if(type != 'USB'){
						Log.e("getDeviceCollect optType: " + optType+ "type:"+type);
						continue;
					}
					this.deviceCollect.push({id: deviceId, devType: type, name: deviceDisplayName});
					devTexts.push(deviceDisplayName);
				}
				break;	
			}
		return devTexts;
	},
	setReturnCb: function(returnCb){
		this.itemList.onReturn = returnCb;	
	},
	setClickCb: function(clickCb){
		this.itemList.onItemClicked = clickCb;
	},
	hide: function(){
		Volt.Nav.removeItem(self.itemList);
		self.itemList.custom.focusable = false;
		self.widget.custom.focusable = false;
		if(self.itemList){
	        HALOUtil.asyncRelease(self.itemList);
			self.itemList = null;
		}
		self.deviceCollect.splice(0,self.deviceCollect.length);
		self.deviceCollect.length = 0;
	},

	
	
	
});
exports = DeviceSelectorView;
