 /** 
 * @author  Hu Po (paul.hu@samsung.com)
 * 			
 * @fileoverview  Music Player view 
 * @date    2014/09/26 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var BaseView = Volt.BaseView;
var MusicListTemplate = Volt.require('app/templates/1080/musicplayer-list-template.js');
var playerController = Volt.require('app/controller/play-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var EventMediator = RunTimeInfo.EventMediator;
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var ListRender = Volt.require("app/views/music-list-render.js");
var KeyCode = CommonInfo.KeyCode;
var EventType = CommonInfo.EventType;
var self = null;
var resMgr = Volt.require('app/controller/resource-controller.js');
var THUMB_BASE_PATH = resMgr.getThumbPath();
var voiceGuide = Volt.require('app/common/voice-guide.js');	

var MusicPlayerListView = PanelCommon.BaseView.extend({
	template: MusicListTemplate.list,
	listWgt: null,
	listListener: null,
	listData: [],
	firstEnterList:true,
	listRender: null,
	tickerID: null,
	externalFocus: false,
	musicView: null,
	nearFocusIdxFlag: true,
	/**Initialize MusicPlayerListView 	 
	* @name initialize	 
	* @memberOf MusicPlayerListView	 
	* @constructs 	 */	
	initialize: function() {
		self = this;
		self.listWgt = null;
		self.listListener = null;
		self.listRender = null;

		EventMediator.on(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_DONE, this.getThumbnailSuccessful, this);	
		EventMediator.on(EventType.EVENT_TYPE_UNSUPPORT_FILE, this.updateItemAvailable, this);	
	},

	/**render MusicPlayerListView 	 
	* @name render	 
	* @memberOf MusicPlayerListView	 cm
	* @method 	 */	
	render : function(){
		var contentWidget = loadTemplate(self.template);
		self.setWidget(contentWidget);

		self.listWgt = self.widget.getChild('playList');
		if( self.listWgt == null ){
			Log.f("can\'t get playList in MusicPlayerListView");
			return null;
		}
		self.listWgt.autoHighContrast = false;

		self._setListStyle();

		self.listWgt.addItem({itemNum: playerController.dataCollection.size(), itemSpace: 86});
		
		self.addData();	

		self.listWgt.focusItemIndex = playerController.getCurrentIdx();
		self.listWgt.loadData();
		self.listWgt.enableFocus();
		self.listWgt.foveaEffect = false;
		self.listWgt.setAnimationDuration("focusMove", 150);
		
		self.initListener();

		return this;
	},

	destroy: function () {
		Volt.log('[musicplayer-list-view.js]-------destroy is called -----');
		self.listData = [];
		self.listWgt = null;
		self.listListener = null;
		self.listRender = null;
        self.clearTicker();
		
		EventMediator.off(EventType.EVENT_TYPE_PLAYER_GETTHUMBNAIL_DONE, this.getThumbnailSuccessful, this);
		EventMediator.off(EventType.EVENT_TYPE_UNSUPPORT_FILE, this.updateItemAvailable, this);	
	},

    events: {   
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur',
    },

	onFocus: function(widget){
		print(" music player list view onFocus ");
		self.firstEnterList = true;
		if (self.listWgt != null)// protect when remove the usb suddenly to core dump 
		{
			self.listWgt.showFocus('false');
		}	
		
		
		if( self.musicView != null ){
			Log.f("self.musicView preFocus set to " + widget.id);
			self.musicView.preFocus = widget;
		}
		
		if( self.nearFocusIdxFlag == true ){
			var topIndex = 0;
			if (self.listWgt != null)
			{
				var topIndex = self.listWgt.windowStartIndex();
				Log.f("topIndex = "+ topIndex + " self.listData.length = " + self.listData.length);
				var focusIdx = topIndex+10 < self.listData.length ? topIndex+10 : self.listData.length-1;
				Log.f("the nearest item index is " + focusIdx);
				self.listWgt.focusItemIndex = focusIdx;			
			}

		}
		self.nearFocusIdxFlag = true;

		if (self.listWgt != null)
		{
			self.listWgt.showFocus('true');
		}

		self.externalFocus = false;
		var image = Volt.getRemoteUrl(resMgr.getImgPath()+'/common/ksc_focus.png');
		if (self.listWgt != null)
		{
   			self.listWgt.setFocusImage(image, -8, -8);// the parameter is not irght?		
		}		
		
    },

    
	onBlur: function(widget){
		print("music player list onBlur ");
		self.listWgt.hideFocus('true');		
		self.firstEnterList = false;
    },

	onKeyEvent: function(keyCode, type){
		Log.f("onKeyEvent in Musicplayer-list-view keyCode = " + keyCode );
		if (type != Volt.EVENT_KEY_RELEASE) 	{
			return false;	
		}
		
		var ret = true;
		switch(keyCode)
		{
			case KeyCode.enter:{
				var selectIdx = self.listWgt.focusItemIndex;
				self._playItem(selectIdx);
				break;
			}
			default:
				ret = false;
				break;
		}
		
		return ret;
    },

	getListFocus: function(){
		if( self.listWgt!= null ){
			return self.listWgt.focusItemIndex;
		}
		return -1;
    },

	setListFocus: function( idx ){
		if( self.listWgt!= null ){
			var oldIdx = self.listWgt.focusItemIndex;			
			self.listWgt.updateItem(oldIdx);
			
			if( idx == self.listWgt.focusItemIndex ){
				return;
			}
			self.listWgt.focusItemIndex = idx;
			self.listWgt.updateItem(idx);
			self.listWgt.showFocus('false');
			self.listWgt.hideFocus('false');			
		}
    },

    setTicker: function(){
	    print('~~~~~~setTickersetTickersetTickersetTickersetTickersetTickersetTicker~~~~~~~~~');
	    if (self.tickerID !== null) {
	        Volt.log(' this.iID = ' + self.tickerID);
	        Volt.clearInterval(self.tickerID);
	        Volt.clearTimer(self.tickerID);
	        self.tickerID = null;
	    }

		ticker = 0;
        var that = self;
        var idx = playerController.getCurrentIdx();
        self.tickerID = Volt.setInterval(
            function () {
                ticker++;
                if(ticker/10 == 3) {
                    print('~~~~~~Timeout, move focus to current play item~~~~~~~~~');
					that.listWgt.focusItemIndex = idx;
					that.listWgt.showFocus('false');
					if(  Volt.Nav.getFocusedWidget() != that.listWgt ){
						that.listWgt.hideFocus('false');			
					}			
                }
            }, 1000);

	},

    clearTicker: function(){
	    print('clearTickerclearTickerclearTickerclearTickerclearTickerclearTickerclearTickerclearTicker');
	    if (self.tickerID !== null) {
	        Volt.log(' this.iID = ' + self.tickerID);
	        Volt.clearInterval(self.tickerID);
	        Volt.clearTimer(self.tickerID);
	        self.tickerID = null;
	    }
	},

	updateCurrentItem: function(idx){
		Volt.log('[musicplayer-list-view.js]---updateCurrentItem----idx is' + idx);
		preIdx = playerController.getPreIdx();
		self.listWgt.updateAllItems();

		if( idx == self.listWgt.focusItemIndex ){
			Log.f("idx = " + idx + " focusItemIndex = " + self.listWgt.focusItemIndex + " return!!");
			print("[musicplayer-list-view.js]--updateCurrentItem--idx = " + idx + " focusItemIndex = " + self.listWgt.focusItemIndex + " return!!");

			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null && (Volt.Nav.getFocusedWidget() == self.listWgt)) 
			{
				Volt.log('[musicplayer-list-view.js]-----updateCurrentItem---CurrentPlayLoading is not null, because it is idx is equal to focuxitem and the focus is on the list, need to sop animation----');
				Log.f('[musicplayer-list-view.js]-----updateCurrentItem---CurrentPlayLoading is not null, because it is idx is equal to focuxitem and the focus is on the list, need to sop animation----');
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.stop();		
			}	
			return;
		}		

		self.listWgt.focusItemIndex = idx;

		self.listWgt.showFocus('false');
		if(  Volt.Nav.getFocusedWidget() != self.listWgt ){
			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null && (playerController.getState() == 3)) 
			{
				Volt.log('[musicplayer-list-view.js]-----updateCurrentItem---CurrentPlayLoading is not null, the focus is not list, to play--ADD IN THE CASE IT IS PLAYING----');
				Log.f('[musicplayer-list-view.js]-----updateCurrentItem---CurrentPlayLoading is not null, the focus is not list, to play--ADD IN THE CASE IT IS PLAYING----');
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.play();
			}			
			self.listWgt.hideFocus('false');			
		}
    },

	updateItem: function( idx ){
		Volt.log('[musicplayer-list-view.js]---updateItem--- and idx is ' + idx);
		if( self.listWgt!= null ){
			self.listWgt.updateItem(idx);
		}
    },

	updateItemAvailable: function( idx ){
		Log.f('[musicplayer-list-view.js]---updateItemAvailable---idx is ' + idx);
		Volt.log('[musicplayer-list-view.js]---updateItemAvailable---idx is ' + idx);
		var data = null;
		if (self.listWgt != null)
		{
			data = self.listWgt.getData(idx);
		}
		
		if( data == null ){
			print('[musicplayer-list-view.js]---updateItemAvailable--data == null for index = ', idx);
			return;
		}
//		data.avail = itemData.avail;
		data.avail = (playerController.getValue( idx, 'PLAYED_COUNT' ) == -1 ? false: true);
		print('[musicplayer-list-view.js]--updateItemAvailable--data.avail for index = '+idx+' is '+playerController.getValue( idx, 'PLAYED_COUNT' ));
		self.updateItem(idx);
    },

	updateData: function(){
		if( self.listWgt!= null ){
			self.listWgt.deleteItem({fromItem:0,  itemNum:self.listData.length});
			self.listData = [];		
			self.listWgt.focusItemIndex = 0;			
			self.listWgt.addItem({itemNum: playerController.dataCollection.size(), itemSpace: 86});
			self.addData();
			self.listWgt.loadData();
		}
    },

	/** createRendererProvider
	* @name createRendererProvider 
	* @memberOf MusicPlayerListView
	* @method 	 
	* */
	_createRendererProvider: function(){
		var rendererProvider = new RendererProvider;
		rendererProvider.funcGetRenderer = function(parentWidth, parentHeight, data)
		{
			self.listRender = new ListRender();
			self.listRender.setNormalTxtColor(255,255,255); //color value: color.r, color.g, color.b
			return self.listRender.getRender(parentWidth, parentHeight, data);
		};
		return rendererProvider;
	},	

	_setListStyle: function(){
		self.listWgt.shadowEffectFlag = false;
		var renderpro = self._createRendererProvider();
		self.listWgt.setRendererProvider(renderpro);
	},

	addData: function() {
		var currIdx = playerController.getCurrentIdx();
		var itemCount = playerController.dataCollection.size();
		var startIdx = currIdx-12<0 ? 0:currIdx-12;
		var endIdx = currIdx+12 >= itemCount ? itemCount-1 : startIdx+13;	

		self.listData = [];

		Log.f("[musicplayer-list-view.js]--addData--currIdx = " + currIdx + "itemCount = " + itemCount + "startIdx = " + startIdx + "endIdx = " + endIdx);
		print("[musicplayer-list-view.js]--addData--currIdx = " + currIdx + "itemCount = " + itemCount + "startIdx = " + startIdx + "endIdx = " + endIdx);
		for( i = 0; i < itemCount; i++ ){
			var data = new Data();
			if( i >=startIdx && i <= endIdx ){
				var itemData = playerController.getItemData(i, false);
				if( itemData== null ){
					Log.f("itemData== null in musicplayer-list-view.js:addData");
					return;
				}
				data.isReady = false;
				data.thumbUrl = itemData.thumb;
				data.title =  itemData.title;
				data.artist =  itemData.artist;
				data.avail = itemData.avail;
				data.index = i;
				data.focus = false;	
				print('[musicplayer-list-view.js]--in addData function--itemData.title = ', itemData.title);
			}
			else{
				data.isReady = false;
				data.thumbUrl = resMgr.getImgPath() + '/default_thumb/mc_playlist_thumbnail_album_default.PNG';
				data.title =  '';
				data.artist =  '';
				data.avail = true;
				data.index = i;
				data.focus = false;	
			}

			self.listData.push(data);
			self.listWgt.addData(data);
		}
	},

	updateTextColor: function( colorValue ) {
		Log.f("[musicplayer-list-view.js] updateTextColor");
		if( self.listRender != null ){
			self.listRender.setNormalTxtColor(colorValue.r,colorValue.g,colorValue.b);
		}
		if( self.listWgt != null ){
			Log.f("Ready to update All Items in Music list!!");
			self.listWgt.updateAllItems();
		}
	},

	getThumbnailSuccessful: function( thumbIdx ) {
		if( self.listWgt==null ){
			Log.f("self.musicList==null in getThumbnailSuccessful");
			return;
		}
		Log.f("[musicplayer-list-view.js]get in getThumbnailSuccessful!! index = " + thumbIdx);
		data = self.listWgt.getData(thumbIdx);
		if( data == null ){
			Log.f("data == null for index = " + thumbIdx);
		}
		print('update data thumbnail url = ',THUMB_BASE_PATH + 'Player' + thumbIdx + '.jpg');
		data.thumbUrl =  THUMB_BASE_PATH + 'Player' + thumbIdx + '.jpg';

		self.listWgt.updateItem(thumbIdx);
		print('[musicplayer-list-view.js]get in getThumbnailSuccessful End!!');
	},

	initListener: function() {
		self.listListener = new SingleLineListControlListener;

		self.listListener.onItemLoaded = function(singleLineList, itemIndex){
			Log.f("try to load the item: " + itemIndex);
			var data = singleLineList.getData(itemIndex);
			if( data == null ){
				print('data == null for index = ', itemIndex);
				return;
			}
			print('data.title = ',data.title);
			if( data.title == '' ){
				print('go to update data');
				var itemData = playerController.getItemData(itemIndex);
				if( itemData== null ){
					return;
				}
				data.isReady = false;
				data.thumbUrl = itemData.thumb;
				data.title =  itemData.title;
				data.artist =  itemData.artist;
				data.index = itemIndex;
				data.avail = itemData.avail;
				data.focus = false;
				print('title is ',data.title );
				print('thumbUrl is ' + data.thumbUrl );
			}
		};
		
		self.listListener.onItemUnloaded = function(singleLineList, itemIndex){
			
		};

		self.listListener.onFocusChanged = function(singleLineList, fromItemIndex, toItemIndex){
			print('self.listListener.onFocusChanged fromItemIndex:'+fromItemIndex+' toItemIndex:'+toItemIndex);
			Log.e("self.listListener.onFocusChanged");
			if(toItemIndex != -1){
				if(self.listWgt == null){
					Log.e(" onFocusChanged self.listWgt == null");
					print(" onFocusChanged self.listWgt == null");
					return;
				}
				print("self.listListener.onFocusChanged self.firstEnterList:"+self.firstEnterList);
				if(self.firstEnterList == true && fromItemIndex != -1){
					self.firstEnterList = false;
					
					var musicCount = playerController.dataCollection.size();
					var itemTxt = '';
					if(musicCount > 1){
						itemTxt = musicCount.toString() + ',items, ';

					}else{
						itemTxt = musicCount.toString() + ',item, ';
					}
					var itemDate = self.listWgt.getData(toItemIndex);
					var txt = resMgr.getText('SID_PLAYLIST') +',' + itemTxt + itemDate.title;
				
				}else{
					var itemDate = self.listWgt.getData(toItemIndex);
					var txt = itemDate.title;
				}
				voiceGuide.play(txt);
			}
		};
		
		self.listListener.StartFocusChange = function(singleLineList, fromItemIndex, toItemIndex){
			print('self.listListener.StartFocusChange');
		};
		
		self.listListener.MoveOut = function(singleLineList, directionString, fromItemIndex){
			if ("Up" == directionString)    {
				
			}    
			else if ("Down" == directionString)    {

			}    
			else if ("Left" == directionString)    {

			}    
			else if ("Right" == directionString)    {

		}};

		self.listListener.onItemClicked = function(singleLineList, itemIndex){
			Log.f("self.listListener.onItemClicked, itemIndex=" + itemIndex);
			self._playItem(itemIndex);
		};

		self.listWgt.addListListener(self.listListener);
	},

	_playItem: function(selectIdx){
		var oldPlayingIdx = playerController.getCurrentIdx();
		Volt.log('[musicplayer-list-view.js]------_playItem is called, selectIdx is '+ selectIdx + ' OldPlayingIdx is ' +oldPlayingIdx );
		playerController.play(0, selectIdx);
		self.listWgt.updateItem(oldPlayingIdx);
		self.listWgt.focusItemIndex = selectIdx;


		if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading == null)
		{
			Volt.log('[musicplayer-list-view.js]------------CurrentPlayLoading == null---2---');
			Log.e('[musicplayer-list-view.js]------------CurrentPlayLoading == null------');
		}
		else
		{
			Volt.log('[musicplayer-list-view.js]-----_playItem-------CurrentPlayLoading != null--AND TO STOP-2---');
			Log.e('[musicplayer-list-view.js]------------CurrentPlayLoading != null------');
			if (Volt.require("app/common/run-time-info.js").CurrentPlayLoading != null)
			{
				Volt.require("app/common/run-time-info.js").CurrentPlayLoading.stop();		
			}	
		}
		
	},
});

exports = MusicPlayerListView;
