var resMgr = Volt.require('app/controller/resource-controller.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var loadTemplate = PanelCommon.loadTemplate;
var MainTemplate = PanelCommon.requireTemplate('main');
var EventMediator = RunTimeInfo.EventMediator;
var CommonInfo = Volt.require('app/common/define.js');
var CONST = CommonInfo.CONST;
var EventType = CommonInfo.EventType;
var FocusPos = CommonInfo.FocusPos;
var EViewType = CommonInfo.EViewType;
var MycontentsShare = Volt.require('app/templates/1080/mycontents-share.js');
var homepanelInfo = MycontentsShare.homepanelInfo;
var Coords = Volt.require('app/templates/1080/dynamic-coords.js');
var MyContentsMainTemplate = Volt.require('app/templates/1080/mycontents-main-template.js');
var DeviceProvider = Volt.require("app/models/device-provider.js");
var voiceGuide = Volt.require('app/common/voice-guide.js');	
var BalloonTips = Volt.require('app/views/balloon-tips.js');
//var winsetToolTip = Volt.require('WinsetUIElement/winsetToolTip.js');
 var WinsetBackground = Volt.require("WinsetUIElement/winsetBackground.js");
var mycontentWidth = RunTimeInfo.SceneResolution;

//var BalloonTips = Volt.require('app/views/balloon-tips.js');
var HeaderView = PanelCommon.BaseView.extend({
    template: MyContentsMainTemplate.secondDepthHeader,
	buttonListener: null,
	buttonFocusListener : null,
    mainView : null,
    filterView: null,
    balloon : null,
	homePlus: {},
	titleImage: [],
	optionParam: { firstOptionText: [],
				   secondOptionText: [],
				   secondSelectedIndex: [],
				 },
	showCloseButton : false,
	showReturnButton: false,
	closebutton : false,
	
	transition: null,
    haloAni: null,
    haloAniListener: null,
    plusBtn:null,
    returnBtn:null,
	exitBtn:null,
	headerViewDim:false,

    initialize: function() {
    	self = this;		
		this.mainView = Volt.require('app/views/main-view.js');
		this.mainView.headerView = this;
		this.filterView = Volt.require("app/views/filter-view.js");
        EventMediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink, this);
        EventMediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand, this);
		EventMediator.on(EventType.EVENT_TYPE_SHOW_ROOT_ARROW, this.onShowReturnButton, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_ROOT_ARROW, this.onHideReturnButton, this);
		
		EventMediator.on(EventType.EVENT_TYPE_SHOW_EXIT_ARROW, this.onShowExitButton, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_EXIT_ARROW, this.onHideExitButton, this);
		
		EventMediator.on(EventType.EVENT_TYPE_SHOW_SETTING, this.onShowSetting, this);
		EventMediator.on(EventType.EVENT_TYPE_HIDE_SETTING, this.onHideSetting, this);

		EventMediator.on(EventType.EVENT_TYPE_DIM_HEADVIEW, this.onDimHeadView, this);
		EventMediator.on(EventType.EVENT_TYPE_UNDIM_HEADVIEW, this.onUndimHeadView, this);
		EventMediator.on(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
		
		for (var index = 0; index < 10; index++) {
			this.optionParam.secondSelectedIndex[index] = -1;
		}	
		EventMediator.on(EventType.EVENT_TYPE_KILL_FOCUS, this.killFocus, this);		
		EventMediator.on(EventType.EVENT_TYPE_SHOW_FOCUS, this.showFocus, this);	

		self.addClickCallback();
		this.setHaloAnimation();
    },
    //
	addOptionBtnKeyboardListener:function(btn){
		self.optionBtnKeyboardListener = new KeyboardListener;
	    self.optionBtnKeyboardListener.onKeyPressed = function (actor, keyCode) {

	    };
		self.optionBtnKeyboardListener.onKeyReleased = function(actor, keyCode){
			print('header view onKeyReleased keyCode',keyCode);
			if (keyCode == Volt.KEY_JOYSTICK_UP ){
				print('header view keyCode',keyCode);
				print('header view play ');
				try{
					AUI.play(HALOUtil.MOVE_NOKEY);
				}catch(e){
					print(" e: AUI.play(HALOUtil.MOVE_NOKEY); e :"+e);
					Log.e(" e: AUI.play(HALOUtil.MOVE_NOKEY); e :"+e);
				}	
			}else if(keyCode == Volt.KEY_JOYSTICK_RIGHT){
				if(HALOUtil.getOrientation() == "left-to-right"){
					try{
						AUI.play(HALOUtil.MOVE_NOKEY);
					}catch(e){
						Log.e(" e: AUI.play(HALOUtil.MOVE_NOKEY); e :"+e);
						print(" e: AUI.play(HALOUtil.MOVE_NOKEY); e :"+e);
					}	
				}
			}else if(keyCode == Volt.KEY_JOYSTICK_LEFT){
				if(HALOUtil.getOrientation() == "right-to-left"){
					try{
						AUI.play(HALOUtil.MOVE_NOKEY);
					}catch(e){
						Log.e(" e: AUI.play(HALOUtil.MOVE_NOKEY); e :"+e);
						print(" e: AUI.play(HALOUtil.MOVE_NOKEY); e :"+e);
					}
				}
			}
			
		};
	    btn.addKeyboardListener(self.optionBtnKeyboardListener);

	},
    render: function() {
        print('[header-view.js] HeaderView.render');
		var parent = this.mainView.widget.getDescendant('main-header-container');
		print('head-view.js render parent.id',parent.id);		
		
		 var winsetWidget = new WinsetBackground({
	        parent : parent,
	        x : 0,
	        y : 0,
	        width : mycontentWidth,
	        height : 144,
	        bgColor : Volt.hexToRgb('#0f1826'),
	        style: 1, //HighContrast_Background :           1,
	    });
	    
		if(HALOUtil.highContrast == true){
	        winsetWidget.color = Volt.hexToRgb('#000000', 100);
	    }
		
		this.widget = loadTemplate(MyContentsMainTemplate.header, null, winsetWidget);
        this.setWidget(this.widget);  

		this.widget.getDescendant('main-header-text').text = resMgr.getText('TV_SID_MY_CONTENT_NAME');

		this.widget.getDescendant('main-header-icon-plus-sec').addListener(this.buttonListener);
		this.widget.getDescendant('main-header-return-arrow').addListener(this.buttonListener);
		this.widget.getDescendant('main-header-exit-arrow').addListener(this.buttonListener);
		this.widget.getDescendant('main-header-icon-plus-sec').addFocusListener(this.buttonFocusListener);
		this.widget.getDescendant('main-header-return-arrow').addFocusListener(this.buttonFocusListener);
		this.widget.getDescendant('main-header-exit-arrow').addFocusListener(this.buttonFocusListener);
		self.plusBtn = this.widget.getDescendant('main-header-icon-plus-sec');
		
		if(HALOUtil.highContrast == true){
	        this.widget.getDescendant('main-header-icon-plus-sec').color = Volt.hexToRgb('#000000');
			self.plusBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000'),});
	    }
		else{
			self.plusBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826'),});
		}
		self.plusBtn.setBackgroundImage({state:"focused",src:resMgr.getImgPath()+"/common/4way_focus.png"});
		self.addOptionBtnKeyboardListener(self.plusBtn);
		
		self.returnBtn = this.widget.getDescendant('main-header-return-arrow');
		self.returnBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826',0),});
		self.returnBtn.setIconAlpha({state: "all", alpha: 153,});
		self.returnBtn.setIconAlpha({state: "focused",alpha: 255,});
		self.returnBtn.setIconAlpha({state: "focused-roll-over",alpha: 255,});
		self.returnBtn.setIconScaleFactor({state: "all", scaleX: 1.0, scaleY: 1.0});
		self.returnBtn.setIconScaleFactor({state: "focused-roll-over", scaleX: 1.1, scaleY: 1.1});
		self.returnBtn.setIconImage({state: "all",
									  src: resMgr.getImgPath()+'/common/comn_icon_tm_return.png',});		
		//self.returnBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
		//self.returnBtn.setBackgroundImage({state:"focused",src:resMgr.getImgPath()+"/common/4way_focus.png"});
		if(HALOUtil.highContrast == true){
	        self.returnBtn.color = Volt.hexToRgb('#000000');
			self.returnBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000'),});
	    }
		else{
			self.returnBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826'),});
		}
				
		self.exitBtn = this.widget.getDescendant('main-header-exit-arrow');
	//	self.exitBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826',0),});		
		self.exitBtn.setIconImage({state: "all",
									  src: resMgr.getImgPath()+'/common/comn_icon_tm_close.png',});
	//	self.returnBtn.setBackgroundImage({state:"focused",src:resMgr.getImgPath()+"/common/4way_focus.png"});
		//self.exitBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
		self.exitBtn.setIconAlpha({state: "all", alpha: 153,});
		self.exitBtn.setIconAlpha({state: "focused",alpha: 255,});
		self.exitBtn.setIconAlpha({state: "focused-roll-over",alpha: 255,});

		self.exitBtn.setIconScaleFactor({state: "all", scaleX: 1.0, scaleY: 1.0});
		self.exitBtn.setIconScaleFactor({state: "focused-roll-over", scaleX: 1.1, scaleY: 1.1});
		
		if(HALOUtil.highContrast == true){
			print(" self.exitBtn.setBackgroundColor to #000000 ");
	        self.exitBtn.color = Volt.hexToRgb('#000000');
			self.exitBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000',100),});
        }else{
        	print(" self.exitBtn.setBackgroundColor to #0f1826 ");
			self.exitBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826',100),});
		}
		
		var freeViewHdSupport = SystemInfo.getBoolValue(SystemInfo.KEY_FREE_VIEW_HD_SUPPORTED);
		Log.e("Header view render freeViewHdSupport : " + freeViewHdSupport);
	//	freeViewHdSupport = true;
		if(freeViewHdSupport == true){
			EventMediator.on(EventType.EVENT_TYPE_UPDATE_CUREENT_DEVICE_AVAILABLE_SIZE, this.onCategoryCallback, this);
			
			EventMediator.on(EventType.EVENT_TYPE_CATEGORY_CHANGE, this.onCategoryCallback, this);
		}else{
			//disable translate lang
			self.enableDeviceInfo(false);
	
		}
    	//hide focus
	    self.killFocus();
		
		if(RunTimeInfo.visibleCursor == true){
			Log.e(" render header view , RunTimeInfo.visibleCursor == true show exit button");
			this.onShowExitButton();
		}
		
		return this;
    },
    onHighcontrastChange:function(){
    	print("onHighcontrastChange HALOUtil.highContrast:"+HALOUtil.highContrast);
		if(HALOUtil.highContrast == true){
	        self.plusBtn.color = Volt.hexToRgb('#000000');
			self.plusBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000'),});
	    }
		else{
			self.plusBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826'),});
		}
		if(HALOUtil.highContrast == true){
	        self.returnBtn.color = Volt.hexToRgb('#000000');
			self.returnBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000'),});
	    }
		else{
			self.returnBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826'),});
		}
		
		if(HALOUtil.highContrast == true){
	        self.exitBtn.color = Volt.hexToRgb('#000000');
			self.exitBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000',100),});
	    }
		else{
			self.exitBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#0f1826',100),});
		}
	},
	killFocus:function(){
		print('Set unvisable-button focus');
		var launchParams = Volt.require("app/common/launch-params.js");
		if( launchParams.isLaunchForMusicPlayer()==false){
			Volt.Nav.focus(null);
		}
	},
	
	showFocus:function(){
		print('kill unvisable-button focus');

	},
	
	onKeyEvent:function(keycode, keytype){
		print(" header view  onKeyEvent ");
		return false;
  	},

    events: {
        'NAV_SELECT #main-header-icon-schedule': 'onSelectSchedule',
        'NAV_SELECT #main-header-icon-search': 'onSelectSearch',
      //  'NAV_SELECT #main-header-icon-plus-sec': 'onSelectSetting',
      //  'NAV_SELECT #main-header-return-arrow': 'onSelectReturn',
     //   'NAV_SELECT #main-header-exit-arrow': 'onSelectExitButton',


        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },
    	/**convert number size to text
	* @name convertSizeToText	 
	* @memberOf deviceListView
	* @method 	 
	* */	
	convertSizeToText: function(size){
		var textSize = '';
		if(size < 1024){
			textSize = size.toString() + 'KB';
		}
		else if((size/(1024*1024)) < 1){
			var totalSize = size/1024;
			totalSize = totalSize.toFixed(2);
			textSize = totalSize.toString() + 'MB';
		}
		else if((size/(1024*1024*1024)) < 1){
			var totalSize = size/(1024*1024);
			totalSize = totalSize.toFixed(2);
			textSize = totalSize.toString() + 'GB';
		}
		else{
			var totalSize = size/(1024*1024*1024);
			totalSize = totalSize.toFixed(2);
			textSize = totalSize.toString() + 'TB';
		}
		return textSize;
    },
    
    enableDeviceInfo:function(enable){
    	if(enable == false){
			self.widget.getDescendant('device-mem-info').opacity = 0;
			self.widget.getDescendant('device-mem-info').getChild(1).custom.multilingual.DISABLE = 'true';
			self.widget.getDescendant('device-mem-info').getChild(3).custom.multilingual.DISABLE = 'true';
			self.widget.getDescendant('device-mem-info').getChild(0).opacity = 0;
			self.widget.getDescendant('device-mem-info').getChild(2).opacity = 0;
			self.widget.getDescendant('device-mem-info').getChild(4).opacity = 0;
		}else{
			self.widget.getDescendant('device-mem-info').opacity = 255;
			self.widget.getDescendant('device-mem-info').getChild(1).custom.multilingual.DISABLE = 'false';
			self.widget.getDescendant('device-mem-info').getChild(3).custom.multilingual.DISABLE = 'false';
			self.widget.getDescendant('device-mem-info').getChild(0).opacity = 255;
			self.widget.getDescendant('device-mem-info').getChild(2).opacity = 153;
			self.widget.getDescendant('device-mem-info').getChild(4).opacity = 153;
		}
	},
	
	onCategoryCallback : function(type, devItem){

		print(' head view >>>>>>>>>>> onCategoryCallback type: ',type);
		
		if(type != 'Connection Guide' && type != 'DLNA' && type != 'PTP'){
			
			var totalSpace = devItem.get('totalSize');
			var freeSpace = devItem.get('availableSize');
			
			var freeSpacePecent = (devItem.get('availableSize') / (totalSpace*1.0)) * 100;
			print("header view onCategoryCallback freeSpacePecent : "+freeSpacePecent);
			freeSpacePecent = freeSpacePecent.toFixed(0);
			//freeSpacePecent = Math.floor(freeSpacePecent);
			
			var per = (totalSpace - freeSpace) / totalSpace;
			print('Used percent : ',per);
			var used = totalSpace - freeSpace;
			var usedText = self.convertSizeToText(used);

			var freeTxt = self.convertSizeToText(freeSpace)+'('+ freeSpacePecent +'%)';
			
			self.enableDeviceInfo(true);
			
			var progressBar = this.widget.getDescendant('device-mem-info').getChild(0);
		
			progressBar.setProgressColor(255,255,255,153);
			progressBar.setBackgroundColor(255,255,255,51);
			progressBar.setValue(per * 1000);
			
			print('progressBar :',progressBar.id);
			
			
			this.widget.getDescendant('device-mem-info').getChild(2).text = usedText;
		//	this.widget.getDescendant('device-mem-info').getChild(2).text = '890.23MB';

			
			this.widget.getDescendant('device-mem-info').getChild(4).text = freeTxt;
			//this.widget.getDescendant('device-mem-info').getChild(4).text = '2.23GB(10%)';
		}else{	
			self.enableDeviceInfo(false);
		}
	},
    /** add setting callback   	 
	* @name addClickCallback	 
	* @memberOf Header-view
	* @param {} 
	* @method 	 
	* */
	addClickCallback: function(){
        this.buttonListener = new ButtonListener;
        this.buttonListener.onButtonClicked = function (button, type) {
			print('Header-view.js button.id:',button.id);
			print('Header-view.js type:',type);
			
			var curView = RunTimeInfo.router.currentView;
			if(curView != null && RunTimeInfo.isEditMode == true){
				print("onButtonClicked  In edit mode ");
				return;
			}
			
            if (button.id == 'main-header-icon-plus-sec') {
				print('[header-view.js] click setting');

				self.onSelectSetting(button);
            }
			else if(button.id == 'main-header-return-arrow'){
				print('[header-view.js] click return-arrow');
				self.onSelectReturn(button);
			}
			else if(button.id == 'main-header-exit-arrow'){
				print('[header-view.js] click exit-arrow');
				self.onSelectExitButton();
			}
        }.bind(self);

        this.buttonListener.onButtonStateChanged = function(button, toState){
        	print('Header-view.js onButtonStateChanged button.id: '+ button.id + ' type: ' + typeof(button.id));
			print('Header-view.js onButtonStateChanged toState: '+ toState + ' type: ' + typeof(toState));
			
			
			if(button.id == 'main-header-icon-plus-sec'){
				if(toState == 'focused'){
					print('sec button focued');
					self.widget.getChild('main-header-icon-filter-setting').opacity = 255;
					self.widget.getChild('main-header-icon-filter-setting').width = 36;
					self.widget.getChild('main-header-icon-filter-setting').height = 36;
					self.hideTooltips();
					print("RunTimeInfo.visibleCursor:"+RunTimeInfo.visibleCursor);
					if(RunTimeInfo.visibleCursor == false){
						var optionTxt = resMgr.getText('COM_SID_OPTIONS');
						self.showTooltips(button,optionTxt);
					}
					
	            }else if(toState == 'focused-roll-over'){
					print('sec button focused-roll-over');
					self.widget.getChild('main-header-icon-filter-setting').opacity = 255;
					self.widget.getChild('main-header-icon-filter-setting').width = 40;
					self.widget.getChild('main-header-icon-filter-setting').height = 40;

					if(RunTimeInfo.visibleCursor == true){						
						self.hideTooltips();
						var optionTxt = resMgr.getText('COM_SID_OPTIONS');
						self.showTooltips(button,optionTxt);
					}
					
	            }else if(toState == 'normal') {
	            	print('sec button normal');
					self.widget.getChild('main-header-icon-filter-setting').opacity = 153;
					self.widget.getChild('main-header-icon-filter-setting').width = 36;
					self.widget.getChild('main-header-icon-filter-setting').height = 36;
					self.hideTooltips();
	            }
			}else if(button.id == 'main-header-exit-arrow'){
				if(toState == 'focused'){
					self.hideTooltips();

				}else if(toState == 'focused-roll-over') {
					self.hideTooltips();
					var optionTxt = resMgr.getText('COM_SID_EXIT');
					self.showTooltips(button,optionTxt);
				}else if(toState == 'normal'){
					self.hideTooltips();
		
				}
			}else if(button.id == 'main-header-return-arrow'){
				if(toState == 'focused'){				
					self.hideTooltips();
					
				}else if(toState == 'focused-roll-over') {
					self.hideTooltips();
					var optionTxt = resMgr.getText('COM_SID_RETURN');
					self.showTooltips(button,optionTxt);
				}else if(toState == 'normal'){
					self.hideTooltips();
				}
			}
        	
        }.bind(self);
		
		 this.buttonFocusListener = new FocusListener;
		 this.buttonFocusListener.onFocusIn = function (button,p2) {
		 	print('heard-view.js buttonFocusListener onFocusIn  >>>> button id :'+ button.id + '  p2: ' +p2 );
			var curView = RunTimeInfo.router.currentView;
			
			if(curView != null && RunTimeInfo.isEditMode == true){
				return;
			}
			var optionTxt = '';
		 	
		
			if(button.id == 'main-header-icon-plus-sec'){				
				EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
				optionTxt = resMgr.getText('COM_SID_OPTIONS');
				print('onFocusIn>>>>>>>>>>>>>  optionTxt:',optionTxt);				
				
			}else if(button.id == 'main-header-return-arrow'){
				optionTxt = resMgr.getText('COM_SID_RETURN');
				
			}else if(button.id == 'main-header-exit-arrow'){
				optionTxt = resMgr.getText('COM_SID_EXIT');
				EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
			}
			var txt = optionTxt + ', ' + resMgr.getText('TV_SID_BUTTON');

			voiceGuide.play(txt);
			
		 };
		 
	 	 this.buttonFocusListener.onFocusOut = function (p1,p2) {
		 	print('buttonFocusListener onFocusOut  >>>> p1:'+ p1 + '  p2: ' +p2 );
			
			self.hideTooltips();
			
		 };
	},
	
    onFocus: function(widget) {
        print('[header-view.js] HeaderView.focus ' + widget.id);
  	//	EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
        EventMediator.trigger(EventType.EVENT_TYPE_FOCUS_CHANGE, FocusPos.FOCUS_CATEGORY);
	
    },

    onBlur: function(widget) {
        print('[header-view.js] HeaderView.onBlur ' + widget.id);
      //  widget.opacity  = 51;
		if( widget.id == 'main-header-return-arrow' ){
			
		} else if(widget.id == 'main-header-icon-plus-sec'){
		
		}
		if( this.balloon != null ){
    		this.balloon.destroy();
    		this.balloon = null;
    	}
    },

    onSelectSchedule: function() { 
    	print('[header-view.js] HeaderView.onSelectSchedule'); 
		var CommonPopupView = Volt.require('app/views/common-popup-view.js');
		this.mainView.messagePopup = new CommonPopupView();
		var popupView = this.mainView.messagePopup;
		popupView.render();
		var buttonProperty =[{unfocusedbuttontext:"ok"},
							 {unfocusedbuttontext:"cancel"}];
		var tmpStr = "All remote controls are set for screnn1 initially.";
		tmpStr += " Before start, set Remote control. To set remote control, try to move";
		tmpStr +=" highlight with remote control. And press, Enter the screen which you want to"
		tmpStr +=" control if you want to change to set, then go to menu.(Menu>Picture>Smart Dual view>Settings)"
		var tmpTitle = 'title test';
		var tepObj = { 
						y: 1080/2-410/2,
						height:410,
						title: tmpTitle,
						text: tmpStr,
						buttonGroup: buttonProperty,
					 };
		popupView.showMessageBox(tepObj);
		
	},
    
    onSelectSearch: function() { 
    	print('[header-view.js] HeaderView.onSelectSearch'); 
    },

    /** setting callback   	 
	* @name onSelectSetting	 
	* @memberOf Header-view
	* @param { button } 
	* @method 	 
	* */
    onSelectSetting: function( button ) { 
    	print('[header-view.js] [onSelectSetting] currentview type',RunTimeInfo.router.getCurrentViewType());

		self.hideTooltips();

		if(RunTimeInfo.router.getCurrentViewType() == EViewType.eConnectionGuideView){
    		print('[header-view.js] if current view is connection guide, do not show option popup');
			if ( self.filterView.optionMenuSubIndex[0] == 0 ){
				self.filterView.getFirstText(EViewType.eAllContentView);
			}
			else{
				self.filterView.getFirstText(EViewType.ePhotoContentView);
			}
			EventMediator.trigger('EVENT_MAIN_POPUP_SHOW', 'OPTION_MENU');
    		return;
    	}

		Volt.KPIMapper.addEventLog('MY_SELECT_OPTIONS');
		var curView = RunTimeInfo.router.getCurrentView();
		if(curView != null){
			curView.getOptionText();
			EventMediator.trigger('EVENT_MAIN_POPUP_SHOW', 'OPTION_MENU');
		}

    },

    onSelectReturn:function() {
    	print('[header-view.js] HeaderView.onSelectReturn');

		self.hideTooltips();
		
		if(RunTimeInfo.router.currentView.isInRootPath() != true){
			print('Update content view');
			RunTimeInfo.router.mainView.popupView.clearOption();
	    	EventMediator.trigger(EventType.EVENT_TYPE_SELECT_HEADER_RETURN);
		}
		
    },
    
	onSelectExitButton:function(){
		print('Exit mycontents~~~~~~~~~~~~~~~~~~~~~~~');
		self.hideTooltips();
		
		if(self.showCloseButton == true){
			try{
				print(" Exit mycontents  Volt.exitKey() ");
				Volt.exitKey();
			}
			catch(e){
				print(" Exit mycontents  Volt.exitKey() "+e);
				Log.e(" Exit mycontents  Volt.exitKey() "+e);
				Volt.exit();
			}
		}
	},

	setHaloAnimation: function(){
		this.haloAni = new MultiObjectTransition();
		this.haloAniListener = new MultiObjectTransitionListener();
		this.haloAni.temp = this;
		this.haloAniListener.onStart = function(transition)
		{
		}
		this.haloAniListener.onVia = function(transition)
		{
		}
		this.haloAniListener.onStoped = function(transition, isFinished)
		{ 
             if (isFinished)
             {
                   transition.temp.isAnimating = false;
             }
		}
		this.haloAni.addListener(this.haloAniListener);
	},
	
    expand: function() {
        print('[header-view.js] HeaderView.expand');
        //this.widget.animate('y', 0, CONST.MENU_ANIM_DURATION);
		this.isAnimating = true;

        var parent = this.mainView.widget.getDescendant('main-header-container');
		
		this.haloAni.setDuration(CONST.MENU_ANIM_DURATION);
		this.haloAni.AddObjectDestination(parent, "y", 0);
		this.haloAni.AddObjectDestination(parent, "size", {w:mycontentWidth, h:144});
		
		this.haloAni.AddObjectDestination(this.widget, "y", 0);
		this.haloAni.AddObjectDestination(this.widget, "size", {w:mycontentWidth, h:144});
		self.setHeaderChildExpandAni();
		this.haloAni.play();
    },
	setHeaderChildExpandAni : function(){
		// header text 
		var  headerText = this.widget.getDescendant('main-header-text');
		
		this.haloAni.AddObjectDestination(headerText, "y", 45);
		
		//header line
		var headerLine = self.mainView.widget.getDescendant('main-category-underbar-container');
		this.haloAni.AddObjectDestination(headerLine, "y", 144);
		
		//close button line
		var closeBtnLine = this.widget.getDescendant('close-button-line');
		this.haloAni.AddObjectDestination(closeBtnLine, "size", {w:1, h:144});

		//return button line
		var returnBtnLine = this.widget.getDescendant('left-head-line');
		this.haloAni.AddObjectDestination(returnBtnLine, "size", {w:1, h:144});
				//header line
		var optionBtnLine = this.widget.getDescendant('right-head-line');
		this.haloAni.AddObjectDestination(optionBtnLine, "size", {w:1, h:144});
		
		
		var filterIcon = this.widget.getDescendant('main-header-icon-filter-setting');
		this.haloAni.AddObjectDestination(filterIcon, "y", 55);
		
		//option button
		var plusBtn = this.widget.getDescendant('main-header-icon-plus-sec');
		this.haloAni.AddObjectDestination(plusBtn, "y", 0);
		//close button
		var closeBtn = this.widget.getDescendant('main-header-exit-arrow');
		this.haloAni.AddObjectDestination(closeBtn, "y", 0);
		//return button
		var returnBtn = this.widget.getDescendant('main-header-return-arrow');
		this.haloAni.AddObjectDestination(returnBtn, "y", 0);
		//device capatiy info
		self.setDeviceMemExpandAni();
	},
	setDeviceMemExpandAni : function(){
		var deviceMemContainer = self.widget.getDescendant('device-mem-info');
		this.haloAni.AddObjectDestination(deviceMemContainer, "y", 0);
		this.haloAni.AddObjectDestination(deviceMemContainer, "size", {w:277, h:143});

	},
    shrink: function() {
        print('[header-view.js] HeaderView.shrink');
		this.isAnimating = true;

        var parent = this.mainView.widget.getDescendant('main-header-container');		
		this.haloAni.setDuration(CONST.MENU_ANIM_DURATION);
		
		this.haloAni.AddObjectDestination(parent, "y", 0);
		this.haloAni.AddObjectDestination(parent, "size", {w:mycontentWidth, h:108});
		this.haloAni.AddObjectDestination(this.widget, "y", 0);
		this.haloAni.AddObjectDestination(this.widget, "size", {w:mycontentWidth, h:108});

		self.setHeaderChildShrinkAni();
		
		this.haloAni.play();
    },
	setHeaderChildShrinkAni : function(){

		// header text 
		var  headerText = this.widget.getDescendant('main-header-text');
		this.haloAni.AddObjectDestination(headerText, "y", 45 - 20);
		//header line
		var headerLine = self.mainView.widget.getDescendant('main-category-underbar-container');
		this.haloAni.AddObjectDestination(headerLine, "y", 144 - 36);
		
		//close button line
		var closeBtnLine = this.widget.getDescendant('close-button-line');
		this.haloAni.AddObjectDestination(closeBtnLine, "size", {w:1, h:144-36});

		//return button line
		var returnBtnLine = this.widget.getDescendant('left-head-line');
		this.haloAni.AddObjectDestination(returnBtnLine, "size", {w:1, h:144-36});

		//option menu line
		var optionBtnLine = this.widget.getDescendant('right-head-line');
		this.haloAni.AddObjectDestination(optionBtnLine, "size", {w:1, h:144-36});
		
		var filterIcon = this.widget.getDescendant('main-header-icon-filter-setting');
		this.haloAni.AddObjectDestination(filterIcon, "y", 55 - 20);
		
		//option button
		var plusBtn = this.widget.getDescendant('main-header-icon-plus-sec');
		this.haloAni.AddObjectDestination(plusBtn, "y", -20);
		//close button
		var closeBtn = this.widget.getDescendant('main-header-exit-arrow');
		this.haloAni.AddObjectDestination(closeBtn, "y", -25);
		//return button
		var returnBtn = this.widget.getDescendant('main-header-return-arrow');
		this.haloAni.AddObjectDestination(returnBtn, "y", -20);
		//device capatiy info
		self.setDeviceMemShrinkAni();
	},
	
	setDeviceMemShrinkAni : function(){
	
		var deviceMemContainer = self.widget.getDescendant('device-mem-info');
		this.haloAni.AddObjectDestination(deviceMemContainer, "y", -20);
		this.haloAni.AddObjectDestination(deviceMemContainer, "size", {w:277, h:120});
	
	},
	
    animateViewSwitch: function(){
    	print('[header-view.js] filter option animation');
		// 2nd is main-header-icon-plus-sec
		// 4th is right-head-line
		// 7th is close button left line
		// 5th is main-header-filter-option
		if(self.transition == null){
			self.transition = new MultiObjectTransition();
		}
		
		if(self.widget && self.widget.getChild != null && self.widget.getChild != undefined && 
			self.widget.getChild('main-header-icon-filter-setting') && self.widget.getChild('right-head-line') && self.widget.getChild('main-header-filter-option')){
	    	Volt.setTimeout( function(){
					if(self.showCloseButton == true){
						//close button is shown
		    			self.widget.getChild('main-header-icon-filter-setting').animate('rotation.z', 0, 500, 'cubic');

						self.transition.AddObjectDestination(self.widget.getChild('right-head-line'),'x',mycontentWidth-200);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'x',mycontentWidth-200);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'alpha',0);
						self.transition.AddObjectDestination(self.widget.getDescendant('device-mem-info'),'x',mycontentWidth-507-47);
						self.transition.setDuration(500);
						self.transition.play();


					} else {
		    			self.widget.getChild('main-header-icon-filter-setting').animate('rotation.z', 0, 500, 'cubic');
						self.transition.AddObjectDestination(self.widget.getChild('right-head-line'),'x',mycontentWidth-100);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'x',mycontentWidth-100);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'alpha',0);
						self.transition.AddObjectDestination(self.widget.getDescendant('device-mem-info'),'x',mycontentWidth-407-47);
						self.transition.setDuration(500);
						self.transition.play();
						
					}
	    		}, 2000);

			Volt.log('[Header-view.js]---animateViewSwitch-- to get the getCurrentView');
			var tempText = 'test';
			if (RunTimeInfo.router != null)
			{
				Volt.log('[header-view.js]----RunTimeInfo.router is not null');
				if (typeof RunTimeInfo.router.getCurrentView == 'function')
				{
					Volt.log('[Header-view.js]---animateViewSwitch-- 1111');
					try
					{
					 	tempText = RunTimeInfo.router.getCurrentView().getFilterOption();
					}
					catch(e)
					{
						Volt.log('[Header-view.js]---animateViewSwitch-- 2222 e is ' + e);	
					} 
				}			
			}

			var textWgt = new TextWidgetEx({
					x:0,
					y:0,
					font: '30px',
			        text: tempText,
			        parent: scene,
			        opacity: 0,
			        verticalAlignment: 'center',
			        ellipsize: true,				       
			    });
				
			var textWidth = textWgt.width;
			print("[header-view.js] filter option animation text width:", textWidth);
			textWgt.destroy();
			textWgt = null;
			if (self.transition != null)
			{
				if(self.showCloseButton == true)
				{
					//close button is shown
					Volt.log('[Header-view.js]---animateViewSwitch-- 2222333');
			    	self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').text = RunTimeInfo.router.getCurrentView().getFilterOption();
					self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').width = textWidth;
					self.widget.getChild('main-header-icon-filter-setting').animate('rotation.z', -90, 500, 'cubic');
					if ( textWidth > 245 ){
						self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').x = 0;
						self.transition.AddObjectDestination(self.widget.getChild('right-head-line'),'x',(mycontentWidth-100)-textWidth-1-15-100);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'x',(mycontentWidth-100)-textWidth-100);
					}
					else{
						self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').x = 245-textWidth;
						self.transition.AddObjectDestination(self.widget.getChild('right-head-line'),'x',(mycontentWidth-446)+(245-textWidth)-15);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'x',(mycontentWidth-445));
					}
					self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'alpha',255);
					self.transition.AddObjectDestination(self.widget.getDescendant('device-mem-info'),'x',(mycontentWidth-752-47));
					self.transition.setDuration(500);
					self.transition.play();
					
				//	self.widget.getChild(4).animate('x', 1474, 500, 'cubic');
			    //	self.widget.getChild(5).animate('x', 1475, 500, 'cubic');
			    //	self.widget.getChild(5).animate('opacity', 255, 500, 'cubic');
				//	self.widget.getDescendant('device-mem-info').animate('x', 1045, 500, 'cubic');
				}
				else
				{
					Volt.log('[Header-view.js]---animateViewSwitch-- 22224444');
					if (RunTimeInfo.router != null)
					{
						Volt.log('[header-view.js]----RunTimeInfo.router is not null');
						if (typeof RunTimeInfo.router.getCurrentView == 'function')
						{
							Volt.log('[Header-view.js]---animateViewSwitch-- 1111RunTimeInfo.router.getCurrentView() is ' + RunTimeInfo.router.getCurrentView());
							try
							{
							 	tempText = RunTimeInfo.router.getCurrentView().getFilterOption();// getFilterOption is in content-base-view
							}
							catch(e)
							{
								Volt.log('[Header-view.js]---animateViewSwitch-- 2222 e is ' + e);	
							} 
						}			
					}
					
			    	self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').text = tempText;//RunTimeInfo.router.getCurrentView().getFilterOption()
					self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').width = textWidth;
			    	self.widget.getChild('main-header-icon-filter-setting').animate('rotation.z', -90, 500, 'cubic');
					if ( textWidth > 245 ){
						self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').x = 0;
						self.transition.AddObjectDestination(self.widget.getChild('right-head-line'),'x',(mycontentWidth-100)-textWidth-1-15);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'x',(mycontentWidth-100)-textWidth);
					}
					else{
						self.widget.getChild('main-header-filter-option').getChild('main-head-filter-text').x = 245-textWidth;
						self.transition.AddObjectDestination(self.widget.getChild('right-head-line'),'x',(mycontentWidth-346)+(245-textWidth)-15);
						self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'x',(mycontentWidth-345));
					}
					self.transition.AddObjectDestination(self.widget.getChild('main-header-filter-option'),'alpha',255);
					if ( textWidth > 245 ){
						self.transition.AddObjectDestination(self.widget.getDescendant('device-mem-info'),'x',(mycontentWidth-652)-180-47);
					}
					else{
						self.transition.AddObjectDestination(self.widget.getDescendant('device-mem-info'),'x',(mycontentWidth-652-47));
					}
					self.transition.setDuration(500);
					self.transition.play();
					
					//self.widget.getChild(4).animate('x', 1574, 500, 'cubic');
			    	//self.widget.getChild(5).animate('x', 1575, 500, 'cubic');
			    	//self.widget.getChild(5).animate('opacity', 255, 500, 'cubic');
					//self.widget.getDescendant('device-mem-info').animate('x', 1145, 500, 'cubic');
				}			
			}
		}
    },
	
    
	onShowSetting:function(){
		print('[onShowSetting]   onShowSetting');
		this.widget.getChild('main-header-icon-plus-sec').show();
	//	this.widget.getChild(2).opacity = 25;
		this.widget.getChild('main-header-icon-plus-sec').custom.focusable = true;
		this.widget.getChild('main-header-icon-filter-setting').show();
		//right line
		this.widget.getChild('right-head-line').opacity = 25;
		this.widget.getChild('right-head-line').show();
		Volt.Nav.reload();

	},
	
	onHideSetting : function(){
		print('[onHideSetting]   onHideSetting');
		this.widget.getChild('main-header-icon-plus-sec').hide();
		this.widget.getChild('main-header-icon-plus-sec').custom.focusable = false;
		this.widget.getChild('main-header-icon-filter-setting').hide();

		//right line
		this.widget.getChild('right-head-line').opacity = 0;
		this.widget.getChild('right-head-line').hide();
	},

	onUndimHeadView:function(){
		print('[onShowSetting]   onShowSetting');
		this.widget.opacity = 255;
		this.widget.getChild('main-header-text').opacity = 204;
		//this.widget.getChild('main-header-icon-plus-sec').show();
	//	this.widget.getChild(2).opacity = 25;
		this.widget.getChild('main-header-icon-plus-sec').custom.focusable = true;
		
		if(self.showCloseButton == true){
			this.widget.getChild('main-header-exit-arrow').custom.focusable = true;
		}
		if(self.showReturnButton == true){
			this.widget.getChild('main-header-return-arrow').custom.focusable = true;
		}
		//this.widget.getChild('main-header-icon-filter-setting').show();
		//right line
		this.widget.getChild('right-head-line').opacity = 25;
		this.widget.getChild('right-head-line').show();
		
		this.headerViewDim = false;
		
		Volt.Nav.reload();

	},
	
	onDimHeadView : function(){
		print('[onDimHeadView]   onDimHeadView');
		//this.widget.getChild('main-header-text').opacity = 255*0.2;
		this.widget.opacity = 255*0.2;
		this.headerViewDim = true;
		//this.widget.getChild('main-header-icon-plus-sec').hide();
		this.widget.getChild('main-header-icon-plus-sec').custom.focusable = false;
		this.widget.getChild('main-header-exit-arrow').custom.focusable = false;
		this.widget.getChild('main-header-return-arrow').custom.focusable = false;
		Volt.Nav.reload();
		//this.widget.getChild('main-header-icon-filter-setting').hide();

		//right line
		//this.widget.getChild('right-head-line').opacity = 0;
	},

	onShowReturnButton:function(reloadFlag){
	
		print('onShowReturnButton >>> onShowRootArrow');
		Log.e("onShowReturnButton >>> onShowRootArrow");
		if(RunTimeInfo.router && RunTimeInfo.router.currentView!= null 
			&& (typeof RunTimeInfo.router.currentView.isInRootPath == 'function') 
			&& RunTimeInfo.router.currentView.isInRootPath() != true){
			self.onShowRootArrow(reloadFlag);
		}
		
	},
	
	onHideReturnButton:function(){
		print('>>>>>>>>>>>>>>> onHideReturnButton');

		print('onHideReturnButton >>> onHideRootArrow');
		Log.e("onHideReturnButton >>> onHideRootArrow");
		

		self.onHideRootArrow();
		
	},
	
	onShowExitButton:function(reloadFlag){
		
		if(self.showCloseButton == true){
			print('Exit button is already show~~~~~~~~~~');
			Log.e("Exit button is already show~~~~~~~~~~");
			return;
		}



		// 2nd is main-header-icon-plus-sec
		this.widget.getChild('main-header-icon-plus-sec').x = this.widget.getChild('main-header-icon-plus-sec').x - 100;
		
		// 4th is right-head-line
		this.widget.getChild('right-head-line').x = this.widget.getChild('right-head-line').x - 100;
		
		self.widget.getChild('main-header-icon-filter-setting').x -= 100;
		
		// 7th is close button left line
		this.widget.getChild(7).show();
		this.widget.getChild(7).opacity = 25;
		if(self.headerViewDim == false){
			this.widget.getChild('main-header-exit-arrow').custom.focusable = true;
		}
		
		this.widget.getChild('main-header-exit-arrow').show();
		
		this.widget.getChild('main-header-exit-arrow').opacity=255;
	//	this.widget.getChild('main-header-exit-arrow').setBackgroundColor({state: 'normal',color: {r:0, g:0, b:0, a:0}});
	//	this.widget.getChild('main-header-exit-arrow').setBackgroundColor({state: 'focused',color: {r:0, g:0, b:0, a:0}});
		this.widget.getChild('device-mem-info').x = this.widget.getChild('device-mem-info').x - 100;

		if(reloadFlag != false){

			Volt.Nav.reload();
		}
		self.showCloseButton = true;

		print('show Exit button  ~~~~~~~~~~');
		Log.e("show Exit button ~~~~~~~~~~");
	},
	
	onHideExitButton:function(){
		if(self.showCloseButton == false){
			print('Exit is already hide~~~~~~~~~');
			Log.e("Exit is already hide~~~~~~~~~");
			return;
		}

		self.hideTooltips();
		
		this.widget.getChild('main-header-exit-arrow').hide();
		this.widget.getChild('main-header-exit-arrow').opacity = 0;
		this.widget.getChild('main-header-exit-arrow').custom.focusable = false;
		// 7th is close button left line
		this.widget.getChild(7).show();
		this.widget.getChild(7).opacity = 0;
		
		self.widget.getChild('main-header-icon-filter-setting').x += 100;
		
		// 2nd is main-header-icon-plus-sec
		this.widget.getChild('main-header-icon-plus-sec').x = this.widget.getChild('main-header-icon-plus-sec').x + 100;
		
		// 4th is right-head-line
		this.widget.getChild('right-head-line').x = this.widget.getChild('right-head-line').x + 100;
		
		this.widget.getChild('device-mem-info').x = this.widget.getChild('device-mem-info').x + 100;
		self.showCloseButton = false;
				
		print('hide Exit~~~~~~~~~');
		Log.e("hide Exit~~~~~~~~~");
	},
	
	onShowRootArrow : function(reloadFlag){
		//text.x = 172
		if(self.showReturnButton == true){
			print('RootArrow is already show ~~~~~~~~~');
			Log.e("RootArrow is already show ~~~~~~~~~");
			return;
		}
		Log.e("onShowRootArrow  ");
		
		var title = this.widget.getChild('main-header-text');
		title.x = Coords.HEADER_TITLE_X;
		var arrow = this.widget.getChild('main-header-return-arrow');
		if(arrow != null && arrow != undefined){
			arrow.opacity = 255;
			if(self.headerViewDim == false){
				arrow.custom.focusable = true;
			}
			print('[header-view.js] onShowRootArrow arrow.show');
			arrow.show();
		}
		print('show >>>>>>>>>>>>>>> line...');
		var line = this.widget.getChild('left-head-line');
		if(line != null && line != undefined){
			line.opacity = 25;
			line.show();
		}
		self.showReturnButton = true;
		
		if(reloadFlag != false){
			Volt.Nav.reload();
		}
	},
	
	onHideRootArrow : function(){
	
		self.hideTooltips();
	
		if(self.showReturnButton == false){
			print('RootArrow is already hide ~~~~~~~~~');
			Log.e("RootArrow is already hide ~~~~~~~~~");
			return;
		}
		var title = this.widget.getChild('main-header-text');
		var arrow = this.widget.getChild('main-header-return-arrow');
		Log.e("onHideRootArrow");
		
		title.x = Coords.HEADER_TITLE_ORIGIN_X;
		if(arrow != null && arrow != undefined){
			arrow.opacity = 0;
			arrow.custom.focusable = false;
			print('[header-view.js] onHideRootArrow arrow.hide');
			arrow.hide();
		}
		
		var line = this.widget.getChild('left-head-line');
		if(line != null && line != undefined){
			line.opacity = 0;
			line.hide();
		}
		self.showReturnButton = false;
		Volt.Nav.reload();
	},
		
	showTooltips :function(button, text){
		Log.e("showTooltips >>> Destroy balloon.....text:"+text);
		print("showTooltips >>> Destroy balloon.....text:"+text);
		
		if(button == null || text == null){			
			Log.e("button == null || text == nul");
			return;
		}
		
    	var opt = {
	    		text: text,
	    		x: button.x,
	    		y: 3,
				wdgHeight: button.height,
				wdgWidth : button.width,
	    		fontsize: 30,
	    		font: '30px',
	    		tailType: 'up',
    	};

    	self.balloon = new BalloonTips();
    	self.balloon.show(opt);	

	},
	
	hideTooltips:function(){
		print('hideTooltips >>> .....');
		if(self.balloon != null){
			print('hideTooltips >>> Destroy balloon.....');
			Log.e("hideTooltips >>> Destroy balloon.....");
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
	},
});

exports = HeaderView;
