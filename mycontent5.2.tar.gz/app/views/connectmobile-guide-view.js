 /** 
 * @author  Hu Shijian (shijian.hu@samsung.com)
 * 			
 * @fileoverview  Connect mobile device guide view
 * @date    2014/07/17 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
var resMgr = Volt.require('app/controller/resource-controller.js');
var Backbone = Volt.require('modules/backbone.js');
var CommonInfo = Volt.require("app/common/define.js");
var EViewType = CommonInfo.EViewType;
var EViewSwitchAniType = CommonInfo.EViewSwitchAniType;
var EventType = CommonInfo.EventType;
var connectmobileGuidesViewTemplate = Volt.require('app/templates/1080/connectmobile-guide-view-template.js');
var Q = Volt.require('modules/q.js');
var CommonInfo = Volt.require("app/common/define.js");
var KeyCode = CommonInfo.KeyCode;
var RunTimeInfo = Volt.require("app/common/run-time-info.js");
var self = null;
var PanelCommon = Volt.require('lib/panel-common.js');
var loadTemplate = PanelCommon.loadTemplate;
var AppLauncher = Volt.require("app/controller/app-launch.js");
var LaunchAppID = CommonInfo.LaunchAppID;
//var Button = Volt.require('modules/UIElement/Button_Generic.js');
var mainView = Volt.require('app/views/main-view.js');
var EventMediator = RunTimeInfo.EventMediator;
var voiceGuide = Volt.require('app/common/voice-guide.js');
var DeviceProvider = Volt.require("app/models/device-provider.js");
var DeviceType = CommonInfo.DeviceType;
var WIRELESSKEY = 'db/menu/network/ap_name';
var VCONF_DEVICE_NAME = 'db/menu/network/devicename/tv_name';
var NetworkType = CommonInfo.NetworkType;
var BalloonTips = Volt.require('app/views/balloon-tips.js');
var offSet = RunTimeInfo.offSet;
var voltapi =  Volt.require('voltapi.js');
var netController = null;
/**
 * Display mobile page  
 * @param {Object} mobile page properties
 * @param 
 * @constructor
 * @extends {BaseView}
 */
var ConMobileGuidePage= PanelCommon.BaseView.extend({
	template: connectmobileGuidesViewTemplate.Container,	
	index:1,	
	preparePage: null,
	connectPage: null,
	disconnectPage: null,
	installPage: null,
	linkPage: null,
	browserPage: null,
	btnNet: null,
	btnShowFiles: null,
	btnClose: null,
	btnNaviLeft:null,
	btnNaviRight:null,
	btnListener: null,
	focusListener : null,
	mouseListener: null,
	buttonFocusListener:null,
	isConnected: true,
	lastestDLNADevice:'',
	muteFocus : null,
	focusPos : '',
	dlnaCount : 0,
	balloon:null,
	vconfMenuLang:'',
	connectDLNAInStep4: false,
	lastestDLNADeviceID:'',
	/** the network listener
	* @name onNetworkListener	 
	* @memberOf ConMobileGuidePage	
	* @param {int} networkType
	* @parm {boolean} connectFlag	
	* @return {}
	* */
	onNetworkListener : function(networkType, connectFlag){
		print('[connectmobile-guide-view]onNetworkListener-----------networkType = ' + networkType + ', connectFlag = ' + connectFlag);
		Log.e("[connectmobile-guide-view]onNetworkListener-----------networkType = " + String(networkType) + ", connectFlag = " + String(connectFlag));

		if(networkType != NetworkType.WIRELESS){
			print("connection mobile view onNetworkListener networkType is not NetworkType.WIRELESS ");
			Log.e("connection mobile view onNetworkListener networkType is not NetworkType.WIRELESS ");
			return;
		}
		print("onNetworkListener self.index:" + self.index);
		if(self.index == 2){
			if(connectFlag==false){
				self.connectPage.hide();
				self.disconnectPage.show();
				self.btnNet.Show();
				self.btnNet.custom.focusable = true;
				self.btnNet.setFocus();				
			}else{
				self.connectPage.show();
				self.disconnectPage.hide();		
				self.btnNet.hide();	
				self.btnNet.custom.focusable = false;
				self.muteFocus.setFocus();	
						
			}							
		} 
		self.updateWireLessName(connectFlag);
	},
	
	/** the device listener
	* @name onDeviceConnect	 
	* @memberOf ConMobileGuidePage	
	* @param {Object} deviceInfo inluding DLNA USB etc..	
	* @return {} 
	* */
	
	onDeviceConnect: function(deviceInfo){
        print('[connectmobile-guide-view.js] onDeviceConnect :',deviceInfo );
		
		if(netController.getCurrentWirelessState() == false){
			print("onDeviceConnect WIRELESS network is not connection");
			Log.e("onDeviceConnect WIRELESS network is not connection");
			return;
		}
		if(deviceInfo.get('type') != DeviceType.DEVICE_TYPE_DLNA){
       		return ;
		}
		
		if(!self || !self.btnShowFiles || !self.btnClose){
			print('[connectmobile-guide-view.js]onDeviceConnect, self == null || self.btnShowFiles == null || self.btnClose == null');
			return ;
		}
		self.lastestDLNADeviceID = deviceInfo.get('id');
		print(" [connectmobile-guide-view.js] onDeviceConnect lastestDLNADeviceID: " + self.lastestDLNADeviceID);
		// switch to step 5 automatically
		if(self.index == 4){
		//if(self.index == 4 && self.dlnaCount <= 0){
			self.connectDLNAInStep4 = true;
			self.switchToRight();
			self.dlnaCount = DeviceProvider.getDLNADeviceCount();
		}
		
		// display show my files button and set focus
		/*
		if (self.index == 5) {
			self.btnShowFiles.Show();
			self.btnShowFiles.custom.focusable = true;
			self.updateConnectDevName();
			self.browserPage.getChild('mobile_browser_list').show();	
	 		self.btnShowFiles.x = 595+offSet;
	 		self.btnClose.x = 941+offSet; 
			self.btnClose.killFocus();
			self.btnClose.setBorder({state: "normal", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
	 		self.btnShowFiles.setFocus();			
		}		
		*/
   },
   
   /** the device listener
	* @name onDeviceDisconnect	 
	* @memberOf ConMobileGuidePage	
	* @param {int} deviceID the ID of the device	
	* @param {enum} deviceInfo inluding DLNA USB etc..	
	* @return {} 
	* */
   onDeviceDisconnect: function(deviceID,deviceType){
   		print("[connectmobile-guide-view.js] Remove device id:",deviceID, 'deviceType :',deviceType);
		if(deviceType != DeviceType.DEVICE_TYPE_DLNA){
			return ;
		}		
		
		if(!self || !self.btnShowFiles || !self.btnClose){
			print('[connectpc-connectmobile-view.js]onDeviceDisconnect, self == null || self == undefined || self.btnShowFiles == null || self.btnShowFiles == undefined');
			return ;
		}
		
		if (self.index == 5) {
			if(self.lastestDLNADeviceID == deviceID){
				/* if there is any DLNA device, hide show my file button */
				self.btnShowFiles.killFocus();
				self.btnShowFiles.Hide();
				self.btnShowFiles.custom.focusable = false;
				//Volt.Nav.reload();
				self.browserPage.getChild('mobile_browser_list').hide();
		 		self.btnClose.x = 794+offSet;
		 		//self.btnClose.setFocus(); 
			}else{
				/* update device name */
				self.updateConnectDevName();
			}
 		}
    },
	addButtonEvent:function(){
		print("connect mobile addButtonEvent");
		 self.buttonFocusListener = new FocusListener;
		 self.buttonFocusListener.onFocusIn = function (button,p2) {
		 	print('heard-view.js onFocusIn  >>>> button id :'+ button.id + '  p2: ' +p2 );
	
			var optionTxt = '';
			
			if(button.id == 'main-header-return-arrow'){
				optionTxt = resMgr.getText('COM_SID_RETURN');
				
			}else if(button.id == 'main-header-exit-arrow'){
				optionTxt = resMgr.getText('COM_SID_EXIT');
				EventMediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
			}
			var txt = optionTxt + ', ' + resMgr.getText('TV_SID_BUTTON');

			voiceGuide.play(txt);
			
		 };
		 
	 	 self.buttonFocusListener.onFocusOut = function (p1,p2) {
		 	print('onFocusOut  >>>> p1:'+ p1 + '  p2: ' +p2 );
			
			self.hideTooltips();
			
		 };

	},

	/** Render and run the mobile page
	* @name render	 
	* @memberOf ConMobileGuidePage
	* @method 
	* @return {Object}	 
	* */

	render : function(){
		print('connectmobile-guide-view.js : render()');
		EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,false);
		netController.registerListener(this.onNetworkListener, this);
		DeviceProvider.regsiterListener(this, this.onDeviceConnect, this.onDeviceDisconnect);
	//	var mainView = Volt.require('app/views/main-view.js');
		var mobileGuideWidget = loadTemplate(this.template, null, mainView.getViewContainer(), false);
		print('connectmobile-guide-view.js : sucess----------');
		self.setWidget(mobileGuideWidget);
		

		self.muteFocus = self.widget.getChild('mute_focus');
		self.preparePage = 	self.widget.getChild('mobile_prepare_page');
		self.connectPage = 	self.widget.getChild('mobile_connect_page');
		self.disconnectPage = self.widget.getChild('mobile_disconnect_page');
		self.installPage = 	self.widget.getChild('mobile_install_page');
		self.linkPage = self.widget.getChild('mobile_link_page');	
		self.browserPage = 	self.widget.getChild('mobile_browser_page');
		if(HALOUtil.getOrientation() == "right-to-left"){
			self.setOsdReverseImg();
		}
		print('connectmobile-guide-view.js : ------createButton()');	
		self.createButton();
		self.renderButton();
		self.ControlNavi();
		self.btnNaviLeft.hide();
		self.linkPage.getChild('mobile_link_Devicename').text = Vconf.getValue('db/menu/network/devicename/tv_name');
		
		self.muteFocus.show();
		self.preparePage.show();
		self.playPrepareGuide();
		self.connectPage.hide();
		self.disconnectPage.hide();	
		self.btnNet.hide();	
	//	self.btnNet.custom.focusable = true;
		self.installPage.hide();	
		self.linkPage.hide();
		self.browserPage.hide();
		
		self.setAccessilibity();	
		self.setPrePageTextPos();
		self.setLinkPageTextPos();
		if(self.isLongLang() == true){
			self.setLongLang();
		}
		
		
		//SystemInfo.getStringValue(SystemInfo.KEY_PRODUCT_CODE_SW);
		if (netController.getCurrentWirelessState()) {
			self.updateConnectDevName();	
		}else{
//			self.connectPage.getChild('mobile_conn_list').hide();
			self.browserPage.getChild('mobile_browser_list').hide();
		}		
		
		try{
		self.addButtonEvent();
		
		self.returnBtn = self.widget.getDescendant('return-arrow');    	
		self.exitBtn = self.widget.getDescendant('exit-arrow');
		
		if(self.returnBtn){

			self.returnBtn.addListener(self.btnListener);
			self.returnBtn.addFocusListener(self.focusListener);

			self.returnBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000',20),});
			self.returnBtn.setIconImage({state: "all",
										  src: resMgr.getImgPath()+'/common/comn_icon_tm_return.png',});
			//self.exitBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.returnBtn.setIconAlpha({state: "all", alpha: 153,});
			self.returnBtn.setIconAlpha({state: "focused",alpha: 255,});
			self.returnBtn.setIconAlpha({state: "focused-roll-over",alpha: 255,});

			self.returnBtn.setIconScaleFactor({state: "all", scaleX: 1.0, scaleY: 1.0});
			self.returnBtn.setIconScaleFactor({state: "focused-roll-over", scaleX: 1.1, scaleY: 1.1});
		}
		if(self.exitBtn){
			
			self.exitBtn.addListener(self.btnListener);
			self.exitBtn.addFocusListener(self.focusListener);
			
			self.exitBtn.setBackgroundColor({state: "all", color: Volt.hexToRgb('#000000',20),});
			self.exitBtn.setIconImage({state: "all",
										  src: resMgr.getImgPath()+'/common/comn_icon_tm_close.png',});
			//self.exitBtn.setBorder({state: "focused",border: {width:3, color: {r:0xff,g:0xff,b:0xff,a:255}}});
			self.exitBtn.setIconAlpha({state: "all", alpha: 153,});
			self.exitBtn.setIconAlpha({state: "focused",alpha: 255,});
			self.exitBtn.setIconAlpha({state: "focused-roll-over",alpha: 255,});

				self.exitBtn.setIconScaleFactor({state: "all", scaleX: 1.0, scaleY: 1.0});
				self.exitBtn.setIconScaleFactor({state: "focused-roll-over", scaleX: 1.1, scaleY: 1.1});
			
			}
			
			if(RunTimeInfo.visibleCursor == true){
				self.onConenctionGuideCursorShow();
			}
					
		}catch(e){
			print("connection mobile guide render got exception e: ", e);
		}
		self.updateWireLessName(netController.getCurrentWirelessState());
		return self;
	},

	isLongLang:function(){
		if(self.vconfMenuLang == 'my_MM.utf8'){
			return true;
		}
		return false;
	},
	setLongLang:function(){
		print('connectmobile-guide-view.js setLongLang()');
		Log.e("setLongLang");
		self.installPage.getDescendant('mobile_install_page_downtext1').lineSpacing = 12;
		self.linkPage.getDescendant('mobile_link_page_downtext1').lineSpacing = 12;
		self.linkPage.getDescendant('mobile_link_page_downtext2').lineSpacing = 12;
		self.linkPage.getDescendant('mobile_link_page_downtext3').lineSpacing = 12;
		self.linkPage.getDescendant('mobile_link_page_downtext4').lineSpacing = 12;
		self.browserPage.getDescendant('mobile_browser_page_downtext1').lineSpacing = 12;
		self.browserPage.getDescendant('mobile_browser_page_downtext2').lineSpacing = 12;
	},

	setOsdReverseImg: function(){
		print('connectmobile-guide-view.js setOsdReverseImg()');
		var installImgUrl = resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_03_reverse.png';
		var linkImgUrl = resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_04_reverse.png';
		var browserImgUrl = resMgr.getImgPath()+'/Connection/img/rc_cg_mobile_05_reverse.png';
		self.installPage.getDescendant('mobile_install_img').src = installImgUrl;
		self.linkPage.getDescendant('mobile_link_img').src = linkImgUrl;
		self.browserPage.getDescendant('mobile_browser_img').src = browserImgUrl;
	},

	setLinkPageTextPos: function(){
		var text = self.linkPage.getChild('mobile_link_page_title').text;
		var fontType = 'SamsungSmart_Light 85px';
		var textLength = self.getTextWidth(text,30,fontType);
		print('connectmobile-guide-view.js setLinkPageTextPos textLength = ',textLength);
		if(textLength > scene.width){
			self.linkPage.getChild('mobile_link_page_title').y = 75;
			self.linkPage.getChild('mobile_link_page_title').height = 90*2+15;
		}
	},

	setPrePageTextPos: function(){
		var text = self.preparePage.getChild('mobile_prepare_page_uptext').text;
		var fontType = 'SamsungSmart_Light 36px';
		var textLength = self.getTextWidth(text,44,fontType);
		print('connectmobile-guide-view.js setPrePageTextPos textLength = ',textLength);
		if(textLength > scene.width){
			//self.linkPage.getChild('mobile_link_page_title').y = 75;
			self.preparePage.getChild('mobile_prepare_page_uptext').height = 44*2;
		}
	},

	/** get the latest DLNADevice name 
	* @name updateConnectDevName	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	updateConnectDevName: function(){
		print('connectmobile-guide-view.js updateConnectDevName');
		if(DeviceProvider.getDLNADeviceCount() > 0){
			self.lastestDLNADevice = self.getLastestDLNADevice();
			print('[connectmobile-guide-view.js]--------lastestDLNADevice==',self.lastestDLNADevice);
			if(self.browserPage != null){
				try{
					print(" updateConnectDevName to  :"+self.lastestDLNADevice);
					self.browserPage.getChild('mobile_browser_list').text = resMgr.getText('COM_IDS_MSG_BT_CONNECTED_KR_YEONGEOL').replace('<<A>>',self.lastestDLNADevice);
					self.browserPage.getChild('mobile_browser_page_uptext').y = 280;
				}catch(e){
					print("updateConnectDevName e:"+e);
					Log.e("updateConnectDevName e:"+e);

				}
			}else{
				print("updateConnectDevName self.browserPage == null");
				Log.e("updateConnectDevName self.browserPage == null");
			}
		}
		else{
			print('connectmobile-guide-view.js No dlna device find!');
			Log.e('connectmobile-guide-view.js No dlna device find!');
			self.browserPage.getChild('mobile_browser_page_uptext').y = 261;
		}
	},
	
	/** render the three buttons to the view 
	* @name renderButton	 
	* @memberOf ConMobileGuidePage
	* @method 
	* @return {} 	 
	* */
	renderButton: function(){
		print('connectmobile-guide-view.js renderButton()');
		self.btnNet = self.disconnectPage.getDescendant('mobile_networkSettingBtn');
		self.btnShowFiles = self.browserPage.getDescendant('mobile_browser_showFilesBtn');
		self.btnClose = self.browserPage.getDescendant('mobile_browser_closeBtn');
		var buttonListener = new ButtonListener;
		self.btnListener = buttonListener;
		buttonListener.onButtonClicked = self.onButtonClick;
		buttonListener.onButtonStateChanged = self.onButtonStateChange;
		
		self.focusListener = new FocusListener;
		self.focusListener.onFocusIn = self.onFocusIn;
		self.focusListener.onFocusOut = self.onFocusOut;
		
		if(self.btnNet != null){
			self.btnNet.addListener(buttonListener);
			self.btnNet.addFocusListener(self.focusListener);
			self.btnNet.Show();
			self.btnNet.custom.focusable = true;
		}
		if(self.btnShowFiles != null){
			self.btnShowFiles.addListener(buttonListener);
			self.btnShowFiles.addFocusListener(self.focusListener);
			self.btnShowFiles.Show();
			self.btnShowFiles.custom.focusable = true;
		}
		if(self.btnClose != null){
			self.btnClose.addListener(buttonListener);
			self.btnClose.addFocusListener(self.focusListener);
			self.btnClose.Show();
			self.btnClose.custom.focusable = true;
		}
	},

	onButtonStateChange : function(button, toState){
    	print('connection mobile view onButtonStateChanged button.id: '+ button.id + ' type: ' + typeof(button.id));
		print('connection mobile view onButtonStateChanged toState: '+ toState + ' type: ' + typeof(toState));
		if(button.id == 'exit-arrow'){
			if(toState == 'focused'){
				self.hideTooltips();
			}else if(toState == 'focused-roll-over') {
				self.hideTooltips();
				var optionTxt = resMgr.getText('COM_SID_EXIT');
				self.showTooltips(button,optionTxt);
			}else if(toState == 'normal'){
				self.hideTooltips();
	
			}
		}else if(button.id == 'return-arrow'){
			if(toState == 'focused'){				
				self.hideTooltips();
				
			}else if(toState == 'focused-roll-over') {
				self.hideTooltips();
				var optionTxt = resMgr.getText('COM_SID_RETURN');
				self.showTooltips(button,optionTxt);
			}else if(toState == 'normal'){
				self.hideTooltips();
			}
		}
    	
    },
	/** Control the navi by mouse 
	* @name ControlNavi	 
	* @memberOf ConMobileGuidePage
	* @method 
	* @return {} 	 
	* */
	ControlNavi: function(){
		var btnLeft = self.widget.getDescendant('mobile_navi_l'); 
		var btnRight = self.widget.getDescendant('mobile_navi_r'); 

		
		self.btnNaviLeft = btnLeft;
		self.btnNaviRight = btnRight;
		   		
		if(HALOUtil.getOrientation() == "right-to-left"){
			self.btnNaviLeft.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_r_n.png';
			self.btnNaviRight.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_l_n.png';
		}
		var naviMouseListener = new MouseListener();
		self.mouseListener = naviMouseListener;
		
		self.mouseListener.onMousePointerIn = function(actor, event){
			print('mouseListener----------------------------mouse pointer in : ' + actor);
			if(actor==btnLeft){
				if(HALOUtil.getOrientation() == "right-to-left"){
					self.btnNaviLeft.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_r_f.png';
				}else{
					self.btnNaviLeft.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_l_f.png';
				}
			}else if(actor==btnRight){
				if(HALOUtil.getOrientation() == "right-to-left"){
					self.btnNaviRight.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_l_f.png';

				}else{
					self.btnNaviRight.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_r_f.png';
				}
			}
			else if(actor==self.btnNet){
				self.btnNet.setTextColor({state: "all", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
    			self.btnNet.setFontSize({state: "all", size: 36,});
			}else if(actor==self.btnShowFiles){
				self.btnShowFiles.setTextColor({state: "all", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
    			self.btnShowFiles.setFontSize({state: "all", size: 36,});
			}else if(actor==self.btnClose){
				self.btnClose.setTextColor({state: "all", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
    			self.btnClose.setFontSize({state: "all", size: 36,});
			}
					

		};
		
		self.mouseListener.onMousePointerOut = function(actor, event){
			print('mouseListener----------------------------mouse pointer out : ' + actor);
			if(actor==btnLeft){
				if(HALOUtil.getOrientation() == "right-to-left"){
					self.btnNaviLeft.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_r_n.png';

				}else{
					self.btnNaviLeft.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_l_n.png';
				}
			}else if(actor==btnRight){
				if(HALOUtil.getOrientation() == "right-to-left"){
					self.btnNaviRight.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_l_n.png';

				}else{
					self.btnNaviRight.src = resMgr.getImgPath()+'/Connection/navi/connect_navi_r_n.png';
				}
			}else if(actor==self.btnNet){
				self.btnNet.setTextColor({state: "all", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
    			self.btnNet.setFontSize({state: "all",size: 32,});	
			}else if(actor==self.btnShowFiles){
				self.btnShowFiles.setTextColor({state: "all", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
    			self.btnShowFiles.setFontSize({state: "all",size: 32,});	
			}else if(actor==self.btnClose){
				self.btnClose.setTextColor({state: "all", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
    			self.btnClose.setFontSize({state: "all",size: 32,});	
			}

		};
		
		self.mouseListener.onMouseButtonReleased = function(actor, event){
			print('mouseListener----------------------------mouse button released : ' + actor);
			if(actor==btnLeft){
				self.switchToLeft();
				
			}else if(actor==btnRight) {
				self.switchToRight();
				
			}
			
		};
		
		self.btnNaviLeft.addMouseListener(naviMouseListener);
		self.btnNaviRight.addMouseListener(naviMouseListener);
		self.btnNet.addMouseListener(naviMouseListener);
		self.btnShowFiles.addMouseListener(naviMouseListener);
		self.btnClose.addMouseListener(naviMouseListener);
		
	},
	/** get the latest device name 
	* @name getLastestDLNADevice	 
	* @memberOf ConMobileGuidePage
	* @method 
	* @return {String} 	 
	* */
	getLastestDLNADevice: function(){		
		var DeviceProvider = Volt.require("app/models/device-provider.js");
		var item = DeviceProvider.getLastestDLNADevice();
		if(item == null){
			return;
		} else {
			return item.get('name');			
		}				
	},
	
	/** show the display 
	* @name show	 
	* @memberOf ConMobileGuidePage
	* @param {enum} the type of animation  	 
	* */

	show: function(aniType) {
		print('connectmobile-guide-view.js : show()');		
		var deferred = Q.defer(); 
		self.widget.show();
		Volt.Nav.setRoot(self.widget);
		//Volt.Nav.reload();	
		//self.muteFocus.setFocus();
		deferred.resolve();
		return deferred.promise;
    },
    
     events: {
    	//'NAV_SELECT': 'onSelect', 
	    //'NAV_FOCUS':'onFocus',
	    //'NAV_BLUR':'onBlur'
	},
	
	/** hide mobile page 	 
	* @name hide	 
	* @memberOf ConMobileGuidePage
	* @param {enum} the type of animation    	 
	* */

    hide: function(aniType) {
        print("[connectmobile-guide-view.js]---- hide()!");
        var deferred = Q.defer();       
		self.widget.hide();	
    	deferred.resolve();    	
		return deferred.promise;
    },
    
	/** the click event for remote control
	* @name onKeyEvent	 
	* @memberOf ConMobileGuidePage	
	* @param {int} the key id
	* @param {enum} the key type
	* @return {boolean}	
	* @method */	
	onKeyEvent : function(key, type){
		print('[connectmobile-guide-view.js] ------ onKeyEvent');
		var keyValue = key;
		if(type != Volt.EVENT_KEY_RELEASE){
			return false;
		}
		if(HALOUtil.getOrientation() == "right-to-left"){
			print('right-to-left  contver  key value');
			if(keyValue == KeyCode.left){
				keyValue = KeyCode.right;
			}
			else if(keyValue == KeyCode.right){
				keyValue = KeyCode.left;
			}
		}		
		var ret = true;
		switch(keyValue){
			case KeyCode.left:{
				print('[connectmobile-guide-view.js] ------ switch left index= ' + self.index);      	            	
				self.switchToLeft();                             
				break;
			}
			case KeyCode.right:{
				print('[connectmobile-guide-view.js] ------ switch right index= ' + self.index);            	          	
			    self.switchToRight();                   
				break;
			}
			case KeyCode.up:
			case KeyCode.down:{
				break;
			}
			case KeyCode.returnKey:{				
                //Backbone.history.navigate('conguides-view', {trigger: true});
				self.hideTooltips();
				
                EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
				
				print("connectmobile-guide-view.js returnKey onKeyEvent switchView to:"+EViewType.eConnectionGuideView);
				Log.e("connectmobile-guide-view.js returnKey onKeyEvent switchView to:"+EViewType.eConnectionGuideView);

                RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
                Volt.KPIMapper.addEventLog('MY_EXIT_GUIDE_MOBILE', {
		             d: {
		                detail : self.index
		            }
		        });		

				if(RunTimeInfo.visibleCursor == true){
					
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
				}
				break;	
			}
	     	default:
    	    	ret = false;
    	    	break;
		}
		return ret;
	},
	
	/** Switch the page while click the left key.	 
	* @name switchToLeft	 
	* @memberOf ConMobileGuidePage
	* @return {}
	* @method 	 
	* */
	
	switchToLeft:function(){
		 print("switchToLeft self.index ==",self.index);		 
		 if (self.index == 5) {
		 		
		 	if(self.btnShowFiles.showFlag && (self.focusPos == 'closeButton')){
				self.btnClose.killFocus();
				self.btnClose.setBorder({state: "normal", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
				self.btnShowFiles.custom.focusable = true;
				self.btnShowFiles.setFocus();		
				var txt = resMgr.getText('COM_SID_WHOW_MY_FILES')+ ', '+resMgr.getText('TV_SID_BUTTON');
				TTS.queuingPlay(txt);
		 	}else{
		 		self.browserPage.hide();
			 	self.linkPage.show();
			 	self.btnNaviRight.show();		
				
				self.playLinkGuide();
				
			 	self.index--;
			 	self.muteFocus.setFocus();
			 	
			 	self.setAccessilibity();	
		    
		 	}
		 	self.dlnaCount = DeviceProvider.getDLNADeviceCount();
		 } else if (self.index == 4) {
		 	
		 	self.installPage.show();
		 	self.btnNaviRight.show();
			
			self.playInstallGuide();
			
		 	self.linkPage.hide();
		 	self.index--;
		 	self.muteFocus.setFocus();
		 	self.setAccessilibity();	
		    
		 } else if (self.index == 3) {
		 	
		 	
			//Get the network status and judge which page will be called
			self.btnNaviRight.show();
 		 	if (netController.getCurrentWirelessState()) {
		 		print("switchToLeft [connectmobile-guide-view.js]--------getWirelessState=" + netController.getCurrentWirelessState());

				self.connectPage.show();
				self.updateConnectDevName();
				self.playNetworkConnectGuide();
					
				self.muteFocus.setFocus();
		 	} else {
		 		self.disconnectPage.show();
		 		self.btnNet.Show();
				self.btnNet.custom.focusable = true;
				self.btnNet.setFocus();
				
				self.playNoNetworkConnectGuide();
		 	}	
		 	self.installPage.hide();
		 	self.index--;
		 	
		 	self.setAccessilibity();	
			if(RunTimeInfo.visibleCursor == true){
			 	self.btnNet.setBackgroundImage({state: "focused-roll-over", src: ''});
				self.btnNet.setBackgroundImage({state: "focused", src: ''});

				self.btnNet.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
				self.btnNet.setFontSize({state: "focused", size: 32,});		
				self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
				self.btnNet.setFontSize({state: "focused-roll-over", size: 32,});
			 }
			 else{
			 	self.btnNet.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
				self.btnNet.setBackgroundImage({state: "focused", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});

				self.btnNet.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
				self.btnNet.setFontSize({state: "focused", size: 36,});		
				self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
				self.btnNet.setFontSize({state: "focused-roll-over", size: 36,});
			 }
		 } else if (self.index == 2) {
		 	
		 	
		    
		 	self.preparePage.show();
		 	self.btnNaviLeft.hide();
		 	self.btnNaviRight.show();
			
			self.playPrepareGuide();
		
		 	//Get the network status and judge which page will be called
		 	if (netController.getCurrentWirelessState()) {		 		
		 		self.connectPage.hide();
				self.disconnectPage.hide(); 
		 		print("[connectmobile-guide-view.js]--------self.connectPage.hide()");
		 	} else {
		 		print("[connectmobile-guide-view.js]--------self.disconnectPage.hide()");
		 		self.disconnectPage.hide(); 
				self.connectPage.hide();
		 		self.btnNet.hide();
				self.btnNet.custom.focusable = false;
		 	}	 	 	
		 	self.index--;
		 	self.muteFocus.setFocus();
		 	
		 	self.setAccessilibity();	
		 } else if (self.index == 1) {
		 	self.setAccessilibity();	
		 	self.muteFocus.setFocus();
		 	return;
		 }
		
	},
	
	/** Switch the page while click the right key.		 
	* @name switchToRight	 
	* @memberOf ConMobileGuidePage
	* @return {}
	* @method 	 
	* */
	switchToRight:function(){
		 print("self.index ==",self.index);	
		 	 
		 if (self.index == 1) {	
		 	self.preparePage.hide();
		 	self.btnNaviLeft.show();
		 	print("[connectmobile-guide-view.js]--------getWirelessState=" + netController.getCurrentWirelessState());
		 	//Get the network status and judge which page will be called
		 	if (netController.getCurrentWirelessState()) {		 		
		 		self.connectPage.show();
				self.updateConnectDevName();
				self.playNetworkConnectGuide();
				
				self.muteFocus.setFocus();
		 		print("[connectmobile-guide-view.js]--------self.connectPage.show()");
		 	} else {
		 		print("[connectmobile-guide-view.js]--------self.disconnectPage.show()");
		 		self.disconnectPage.show(); 
		 		self.btnNet.Show();
				self.btnNet.custom.focusable = true;
				self.btnNet.setFocus();
				self.playNoNetworkConnectGuide();

			}
	
		 	self.index++;
		 	
		 	 self.setAccessilibity();	
			 if(RunTimeInfo.visibleCursor == true){
			 	self.btnNet.setBackgroundImage({state: "focused-roll-over", src: ''});
				self.btnNet.setBackgroundImage({state: "focused", src: ''});
				
				self.btnNet.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
				self.btnNet.setFontSize({state: "focused", size: 32,});		
				self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
				self.btnNet.setFontSize({state: "focused-roll-over", size: 32,});
			 }
			 else{
			 	self.btnNet.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
				self.btnNet.setBackgroundImage({state: "focused", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
				
				self.btnNet.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
				self.btnNet.setFontSize({state: "focused", size: 36,});		
				self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
				self.btnNet.setFontSize({state: "focused-roll-over", size: 36,});
			 }
		 } else if (self.index == 2) {
		 	//Get the network status and judge which page will be called
		 	if (netController.getCurrentWirelessState()) {		 		
		 		self.connectPage.hide();
				self.disconnectPage.hide(); 
				self.btnNet.hide();
				self.btnNet.custom.focusable = false;
		 		print("[connectmobile-guide-view.js]--------self.connectPage.hide()");
		 	} else {
		 		print("[connectmobile-guide-view.js]--------self.disconnectPage.hide()");
		 		self.disconnectPage.hide(); 
				self.connectPage.hide();
		 		self.btnNet.hide();
				self.btnNet.custom.focusable = false;
		 	}
		 			 	
		 	self.installPage.show();
		 	self.btnNaviLeft.show();
			
		 	self.playInstallGuide();
				
		 	self.index++;
		 	self.muteFocus.setFocus();
		 	self.setAccessilibity();	
		 } else if (self.index == 3) {

		 	self.installPage.hide();
		 	self.linkPage.show();
		 	self.btnNaviLeft.show();

		 	self.playLinkGuide();
			
		 	self.index++;
		 	self.dlnaCount = DeviceProvider.getDLNADeviceCount();
		 	self.muteFocus.setFocus();
		 	self.setAccessilibity();	
		 } else if (self.index == 4) {
		 	self.browserPage.show();		 	
		 	self.linkPage.hide();
		 	self.btnNaviLeft.show();
		 	self.btnNaviRight.hide();
			if (netController.getCurrentWirelessState()){
				self.updateConnectDevName();
			}
		 	
	 	//	if(netController.getCurrentWirelessState() && DeviceProvider.getDLNADeviceCount() > 0){
	 		if(self.connectDLNAInStep4 == true){
				self.connectDLNAInStep4 = false;
		 		self.btnShowFiles.x = 595+offSet;
				self.btnShowFiles.custom.focusable = true;
				self.btnShowFiles.Show();
		 		self.btnClose.x = 941+offSet; 
				self.btnClose.killFocus();
		 		self.btnShowFiles.setFocus();
			 	self.browserPage.getChild('mobile_browser_list').show();
			 	self.playConnectBrowserGuide();
			}else {
				self.btnShowFiles.killFocus();
		 		self.btnShowFiles.Hide();
				self.btnShowFiles.custom.focusable = false;
		 		self.browserPage.getChild('mobile_browser_list').hide();
		    	self.btnClose.x = 794+offSet; 
		 		self.btnClose.setFocus();	
				self.playNoConnectBrowserGuide();
		 	}	 	
		 	self.index++;
		 	self.setAccessilibity();	
			if(RunTimeInfo.visibleCursor == true){
			 	self.btnShowFiles.setBackgroundImage({state: "focused-roll-over", src: ''});
				self.btnShowFiles.setBackgroundImage({state: "focused", src: ''});
				self.btnClose.setBackgroundImage({state: "focused-roll-over", src: ''});
				self.btnClose.setBackgroundImage({state: "focused", src: ''});
				
				self.btnShowFiles.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
				self.btnShowFiles.setFontSize({state: "focused", size: 32,});		
				self.btnShowFiles.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
				self.btnShowFiles.setFontSize({state: "focused-roll-over", size: 32,});
				
				self.btnClose.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
				self.btnClose.setFontSize({state: "focused", size: 32,});		
				self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
				self.btnClose.setFontSize({state: "focused-roll-over", size: 32,});
			 }
			 else{
			 	self.btnShowFiles.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
				self.btnShowFiles.setBackgroundImage({state: "focused", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
				self.btnClose.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
				self.btnClose.setBackgroundImage({state: "focused", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});

				self.btnShowFiles.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
				self.btnShowFiles.setFontSize({state: "focused", size: 36,});		
				self.btnShowFiles.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
				self.btnShowFiles.setFontSize({state: "focused-roll-over", size: 36,});

				self.btnClose.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
				self.btnClose.setFontSize({state: "focused", size: 36,});		
				self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
				self.btnClose.setFontSize({state: "focused-roll-over", size: 36,});
			 }
		 } else if (self.index == 5) {	
		 		if(self.focusPos == 'showFilesButton'){
					self.btnShowFiles.killFocus();
					self.btnShowFiles.custom.focusable = false;
					self.btnShowFiles.setBorder({state: "normal",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
					self.btnClose.setFocus();    
					var txt = resMgr.getText('COM_SID_CLOSE')+ ', ' + resMgr.getText('TV_SID_BUTTON');
					voiceGuide.play(txt); 			 	
				}
				self.setAccessilibity();	
		 }
		 
		
		 
	},
	

	/** Initialize mobile view  	 
	* @name initialize	 
	* @memberOf ConMobileGuidePage
	* @param {String}options
	* @method
	* @return {} 	 
	* */
	initialize: function(options){
		print('connectmobile-guide-view.js : initialize()');
		self = this;
		netController = Volt.require('app/controller/net-controller.js');
		Vconf.setOnChangeHandler(VCONF_DEVICE_NAME,function(){self.onDeviceNameChange()});
		Vconf.setOnChangeHandler(WIRELESSKEY, function(){
			print("######### setOnChangeHandler: wireless name ");
			self.updateWireLessName(netController.getCurrentWirelessState());
		});
		self.vconfMenuLang = voltapi.vconf.getValue('db/menu_widget/language');
		self.isHighContrast = Vconf.getValue('db/menu/system/accessibility/highcontrast');
	    self.isFocuszoom = Vconf.getValue('db/menu/system/accessibility/focuszoom');
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_SETTING,null);
	//	EventMediator.on(EventType.EVENT_TYPE_LANGUAGE_CHANGED, this.onLanguageChange, this);	
		EventMediator.on(EventType.EVENT_TYPE_CURSOR_HIDE, this.onConenctionGuideCursorHide, this);	
		EventMediator.on(EventType.EVENT_TYPE_CURSOR_SHOW, this.onConenctionGuideCursorShow, this);	
		EventMediator.on(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
        EventMediator.on(EventType.EVENT_TYPE_ENLARGE_CHANGE, this.onEnlargeChange, this);
		//	EventMediator.trigger(EventType.EVENT_TYPE_DISABLE_HEADER_BUTTON);
		
	//	EventMediator.trigger(EventType.EVENT_TYPE_HIDE_ROOT_ARROW);
		EventMediator.trigger(EventType.EVENT_TYPE_HIDE_EXIT_ARROW);

	},
	
	onHighcontrastChange:function(){
		print('[connectmobile-guide-view.js]:----------- onHighcontrastChange()');		
		self.setAccessilibity();	  	
	},
	
	onEnlargeChange:function(){
		print('[connectmobile-guide-view.js]:------- onEnlargeChange()');
		self.setAccessilibity();			
	},

	onDeviceNameChange: function(){
		print('[connectmobile-guide-view.js]:------- onDeviceNameChange()');
		if(self.linkPage != null){
			self.linkPage.getChild('mobile_link_Devicename').text = Vconf.getValue('db/menu/network/devicename/tv_name');
		}
	},
	
	onConenctionGuideCursorHide:function(){

		print("moblie guide onConenctionGuideCursorHide ");
		
		self.hideTooltips();
		
		if(self.returnBtn != null){
			self.returnBtn.hide();
			self.returnBtn.opacity = 0;
			self.returnBtn.custom.focusable = false;
		}

		if(self.exitBtn != null){
			self.exitBtn.hide();
			self.exitBtn.opacity = 0;
			self.exitBtn.custom.focusable = false;
		}

		if(self.btnNet != null){
			self.btnNet.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
			self.btnNet.setFontSize({state: "normal",size: 32,});	
			self.btnNet.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnNet.setFontSize({state: "focused", size: 36,});		
			self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
			self.btnNet.setFontSize({state: "focused-roll-over", size: 36,});
			self.btnNet.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnNet.setFontSize({state: "selected", size: 36,});
		}
		
		if(self.btnClose != null){
			self.btnClose.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
			self.btnClose.setFontSize({state: "normal",size: 32,});	
			self.btnClose.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnClose.setFontSize({state: "focused", size: 36,});		
			self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
			self.btnClose.setFontSize({state: "focused-roll-over", size: 36,});
			self.btnClose.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnClose.setFontSize({state: "selected", size: 36,});
		}
		
		if(self.btnShowFiles != null){
			self.btnShowFiles.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
			self.btnShowFiles.setFontSize({state: "normal",size: 32,});	
			self.btnShowFiles.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnShowFiles.setFontSize({state: "focused", size: 36,});		
			self.btnShowFiles.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
			self.btnShowFiles.setFontSize({state: "focused-roll-over", size: 36,});
			self.btnShowFiles.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
			self.btnShowFiles.setFontSize({state: "selected", size: 36,});
		}
		/*
		if( self.btnNet != null ){
			self.btnNet.setBorder({state: "normal", border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnNet.setBorder({state: "focused", border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnNet.setBorder({state: "focused-roll-over", border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnNet.setBorder({state: "selected", border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
		}
		if( self.btnClose != null ){
			self.btnClose.setBorder({state: "normal",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnClose.setBorder({state: "focused",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnClose.setBorder({state: "focused-roll-over",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnClose.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
		}
		if( self.btnShowFiles != null ){
			self.btnShowFiles.setBorder({state: "normal",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnShowFiles.setBorder({state: "focused",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnShowFiles.setBorder({state: "focused-roll-over",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
			self.btnShowFiles.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:0 }}});
		}*/
		Volt.Nav.reload();
	},
	
	onConenctionGuideCursorShow:function(){

		print("moblie guide onConenctionGuideCursorShow ");

		if(self.returnBtn != null){
			self.returnBtn.show();
			self.returnBtn.opacity = 255;
			self.returnBtn.custom.focusable = true;
		}

		if(self.exitBtn != null){
			self.exitBtn.show();
			self.exitBtn.opacity = 255;
			self.exitBtn.custom.focusable = true;
		}

		if(self.btnNet != null){
			self.btnNet.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
			self.btnNet.setFontSize({state: "focused", size: 32,});		
			self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
			self.btnNet.setFontSize({state: "focused-roll-over", size: 32,});
		}

		if(self.btnClose != null){
			self.btnClose.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
			self.btnClose.setFontSize({state: "focused", size: 32,});		
			self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
			self.btnClose.setFontSize({state: "focused-roll-over", size: 32,});
		}

		if(self.btnShowFiles != null){
			self.btnShowFiles.setTextColor({state: "focused", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		
			self.btnShowFiles.setFontSize({state: "focused", size: 32,});		
			self.btnShowFiles.setTextColor({state: "focused-roll-over", color: { r:0x43, g:0x47, b:0x52, a:255 },});    		  	
			self.btnShowFiles.setFontSize({state: "focused-roll-over", size: 32,});
		}
		/*
		if( self.btnNet != null ){
			self.btnNet.setBorder({state: "normal", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnNet.setBorder({state: "focused", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnNet.setBorder({state: "focused-roll-over", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnNet.setBorder({state: "selected", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		}
		if( self.btnClose != null ){
			self.btnClose.setBorder({state: "normal",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnClose.setBorder({state: "focused",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnClose.setBorder({state: "focused-roll-over",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnClose.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		}
		if( self.btnShowFiles != null ){
			self.btnShowFiles.setBorder({state: "normal",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnShowFiles.setBorder({state: "focused",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnShowFiles.setBorder({state: "focused-roll-over",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			self.btnShowFiles.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		}*/
		
		Volt.Nav.reload();

	},
	/** onLanguageChange 	 
	* @name onLanguageChange	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	onLanguageChange : function(){
	// change language , mycontent will exit
	//	self.updateWireLessName();
	},
	
	updateWireLessName : function(wirlessConnect){
		
		if(self.connectPage){

			if(wirlessConnect == false){
				self.connectPage.getChild('mobile_wireless_name').text = resMgr.getText('COM_SID_A_WIRELESS_ROUTER');
			}else{
				var wirelessName = Vconf.getValue(WIRELESSKEY);
				Log.e("updateWireLessName  wirelessName:"+wirelessName);
				self.connectPage.getChild('mobile_wireless_name').text = resMgr.getText('COM_SID_TV_CONNECTED_TO_COLON') + wirelessName;
			}
		}
	},
	
	/** destroy mobile view  	 
	* @name destroy	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	destroy : function(){

		print("Destroy connection mobile guide");
		try{
			if(RunTimeInfo.visibleCursor == true){
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
			}
			
	        EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
			
			if ( DeviceProvider.getDeviceCount() > 0 ){
				Log.e("connection mobile guide destroy device count > 0, show setting button");
				EventMediator.trigger(EventType.EVENT_TYPE_SHOW_SETTING,null);
			}
		}catch(e){
			Log.e("connection mobile guide destroy e:" + e);
			print("connection mobile guide destroy e:" + e);
		}
		
		if(self.btnNet){
			self.btnNet.removeListener(self.btnListener);
			self.btnNet.removeFocusListener(self.focusListener);
		}
		if(self.btnShowFiles){
			self.btnShowFiles.removeListener(self.btnListener);
			self.btnShowFiles.removeFocusListener(self.focusListener);
		}
		if(self.btnClose){
			self.btnClose.removeListener(self.btnListener);
			self.btnClose.removeFocusListener(self.focusListener);
		}
		
		if(self.exitBtn){
			self.exitBtn.removeListener(self.btnListener);
			self.exitBtn.removeFocusListener(self.focusListener);
		}

		if(self.returnBtn){
			self.returnBtn.removeListener(self.btnListener);
			self.returnBtn.removeFocusListener(self.focusListener);
		}
		

		this.widget.hide();
		this.widget.destroy();
		this.widget = null;

		self.hideTooltips();
		
		netController.unregisterListener(this.onNetworkListener, this);
		DeviceProvider.unregsiterListener(this, this.onDeviceConnect, this.onDeviceDisconnect);
		EventMediator.off(EventType.EVENT_TYPE_CURSOR_HIDE, this.onConenctionGuideCursorHide, this);	
		EventMediator.off(EventType.EVENT_TYPE_CURSOR_SHOW, this.onConenctionGuideCursorShow, this);	
		
		EventMediator.off(EventType.EVENT_TYPE_HIGHCONTRAST_CHANGE, this.onHighcontrastChange, this);
        EventMediator.off(EventType.EVENT_TYPE_ENLARGE_CHANGE, this.onEnlargeChange, this);
	 	self.focusListener = null;
		self.btnListener = null;
				

	},
	/** onFocusIn 	 
	* @name onFocusIn	 
	* @memberOf ConMobileGuidePage
	* @param {Object}button
	* @method
	* @return {} 	 
	* */

	onFocusIn: function(button){
		if(button == null){
			Log.e("connection mobile onFocusIn  button == null ");
			return;
		}
		print("connection mobile onFocusIn id:"+button.id);
		
		
		if(button.id == 'mobile_networkSettingBtn'){
			self.focusPos = 'networkButton';		
		}
		else if(button.id == 'mobile_browser_showFilesBtn'){
			self.focusPos = 'showFilesButton';													
		}
		else if(button.id == 'mobile_browser_closeBtn'){		
			self.focusPos = 'closeButton';	
		}
		else if(button.id == 'mute_focus'){
			self.focusPos = 'muteFocus';
			
		}else if(button.id == 'exit-arrow'){
			self.focusPos == 'exit-arrow';		
			
			var txt = resMgr.getText('COM_SID_EXIT') + ', ' + resMgr.getText('TV_SID_BUTTON');

			voiceGuide.play(txt);
			
	    //	self.showTooltips(button,resMgr.getText('COM_SID_CLOSE'));
			
		}else if(button.id == 'return-arrow'){
			self.focusPos == 'return-arrow';
			var txt = resMgr.getText('COM_SID_RETURN') + ', ' + resMgr.getText('TV_SID_BUTTON');

			voiceGuide.play(txt);
			
		//	self.showTooltips(button,resMgr.getText('COM_SID_RETURN'));
	    	
		}		
	
    },
    
	onFocusOut: function(button){
	
		self.hideTooltips();
			
	
    },
    /** onButtonClick 	 
	* @name onButtonClick	 
	* @memberOf ConMobileGuidePage
	* @param {Object}button
	* @param {enum}type
	* @method
	* @return {} 	 
	* */
    onButtonClick : function (button, type){
    	print("onButtonClick button.id:"+button.id);
		
		if(button.id == 'mobile_networkSettingBtn'){
			AppLauncher.launch(LaunchAppID.APP_ID_NETWORK_SETTINGS, {key1 : 'value1'});					
		}
		else if(button.id == 'mobile_browser_showFilesBtn'){
			var DeviceProvider = Volt.require("app/models/device-provider.js");
			print("onButtonClick   getDLNADeviceCount:"+DeviceProvider.getDLNADeviceCount());
			try{
				if (DeviceProvider.getDLNADeviceCount() > 0 ){		
					print("onButtonClick switchView  ")
					EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
					var ViewGlobalData = Volt.require("app/views/view-global-data.js");
					ViewGlobalData.isEnterByConnectionGuide = true;
					mainView.categoryView.selectLastestDLNADevice();
					//RunTimeInfo.router.switchView(EViewType.eAllContentView, EViewSwitchAniType.eNoneAni);
				}		
			}catch(e){
				print("mobile_browser_showFilesBtn   switchView e:"+e);
			}
		}
		else if(button.id == 'mobile_browser_closeBtn'){				
			EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
			RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
			//add for fix the defect DF150108-00669	
			Volt.KPIMapper.addEventLog('MY_EXIT_GUIDE_MOBILE', {
	             d: {
	                detail : self.index
	            }
	        });	

			if(RunTimeInfo.visibleCursor == true){
					
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
			}
			
		} else if(button.id == 'return-arrow'){
			print(" connection mobile return button click ");
			
			self.hideTooltips();
			                //Backbone.history.navigate('conguides-view', {trigger: true});
            EventMediator.trigger(EventType.EVENT_TYPE_SET_CATEGORY_FOCUSABLE_FALSE,true);
            RunTimeInfo.router.switchView(EViewType.eConnectionGuideView, EViewSwitchAniType.eNoneAni);
			if(RunTimeInfo.visibleCursor == true){
					
					EventMediator.trigger(EventType.EVENT_TYPE_SHOW_EXIT_ARROW);
			}
		}else if(button.id == 'exit-arrow'){
			print(" connection mobile exit button click ");
			self.hideTooltips();
			
			try{
				print(" Exit mycontents  Volt.exitKey() ");
			//	var mainView = Volt.require('app/views/main-view.js');
				mainView.widget.hide();
				Volt.exitKey();
			}
			catch(e){
				Log.e(" mobile Exit mycontents  Volt.exitKey() "+e);
				Volt.exit();
			}
		}
    },
    /** showFocus 	 
	* @name showFocus	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
    showFocus: function(){
    	print('connectmobile-guide-view.js showFocus()');
    	Volt.Nav.setRoot(self.widget);
		//Volt.Nav.reload();	
    	
    	if(self.index == 2 && self.btnNet.showFlag){
			self.btnNet.custom.focusable = true;
			Volt.Nav.focus(self.btnNet);
    		//self.btnNet.setFocus();	
    	}else if(self.index == 5){
    		if(self.btnShowFiles.showFlag && self.focusPos == 'showFilesButton'){
				self.btnClose.killFocus();
				Volt.Nav.focus(self.btnShowFiles);
				//self.btnShowFiles.setFocus();	
			}
			else{
				self.btnShowFiles.killFocus();
				self.btnShowFiles.custom.focusable = false;
				//self.btnClose.setFocus();
				Volt.Nav.focus(self.btnClose);
			}						
    	}else{
    		//self.muteFocus.setFocus();
			Volt.Nav.focus(self.muteFocus);
    	}
    },
   
    /** createButton for mobile view  	 
	* @name createButton	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
    createButton: function(){	
		var btnwidgetNet = self.disconnectPage.getDescendant('mobile_networkSettingBtn');    	
    	self.btnNet = btnwidgetNet;
		print('self.btnNet ===================================================',self.btnNet);
		print('888');
    	self.btnNet.setText({state: "all", text: resMgr.getText('COM_TV_SID_NETWORK_SETTINGS'),}); 
    	
		self.btnNet.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
    	self.btnNet.setFontSize({state: "normal",size: 32,});			           	
    	self.btnNet.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
    	self.btnNet.setBorder({state: "normal", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
    	
    	self.btnNet.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
    	self.btnNet.setFontSize({state: "focused", size: 36,});
		self.btnNet.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a:0 },});
		self.btnNet.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.btnNet.setBorder({state: "focused", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
		self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
    	self.btnNet.setFontSize({state: "focused-roll-over", size: 36,});
		self.btnNet.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a:0 },});
		self.btnNet.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.btnNet.setBorder({state: "focused-roll-over", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
		self.btnNet.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
    	self.btnNet.setFontSize({state: "selected", size: 36,});
		self.btnNet.setBackgroundColor({state: "selected", color: { r:255, g:255, b:255, a:0 },});
		self.btnNet.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		//self.btnNet.setBorder({state: "selected", border: {width:1, color: { r:64, g:64, b:64, a:204 }}});
		
		//self.btnNet.setFocus();
    	self.btnNet.Show();
		self.btnNet.custom.focusable = true;
    	print('[connectmobile-guide-view.js]-------createButton networkSetting'); 
		
    	    	
    	var btnwidgetCheck = self.browserPage.getDescendant('mobile_browser_showFilesBtn');    	
    	self.btnShowFiles = btnwidgetCheck;
    	self.btnShowFiles.setText ({state: "all",text: resMgr.getText('COM_SID_WHOW_MY_FILES'),});    
    	
    	self.btnShowFiles.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },});  	    	   		
    	self.btnShowFiles.setFontSize({state: "normal",size: 32,});
    	self.btnShowFiles.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});   
    	self.btnShowFiles.setBorder({state: "normal",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
	
    	self.btnShowFiles.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnShowFiles.setFontSize({state: "focused",size: 36,});
		self.btnShowFiles.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a:0 },});
		self.btnShowFiles.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.btnShowFiles.setBorder({state: "focused",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
		self.btnShowFiles.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnShowFiles.setFontSize({state: "focused-roll-over",size: 36,});
		self.btnShowFiles.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a:0 },});
		self.btnShowFiles.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});	
		self.btnShowFiles.setBorder({state: "focused-roll-over",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
		self.btnShowFiles.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnShowFiles.setFontSize({state: "selected",size: 36,});
		self.btnShowFiles.setBackgroundColor({state: "selected", color: { r:255, g:255, b:255, a:0 },});
		self.btnShowFiles.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
    	//self.btnShowFiles.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
    			                      		
    	
    	self.btnShowFiles.Show();    	
    	//self.btnShowFiles.setFocus();		    	
    	
    	print('[connectmobile-guide-view.js]-------createButton checkContentBtn');
		
    	
    	var btnwidgetClose = self.browserPage.getDescendant('mobile_browser_closeBtn');
		self.btnClose = btnwidgetClose;
    	self.btnClose.setText ({state: "all",text: resMgr.getText('COM_SID_CLOSE'),});   
    	
    	self.btnClose.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },});    	    	 		
    	self.btnClose.setFontSize({state: "normal",size: 32,}); 
    	self.btnClose.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
		self.btnClose.setBorder({state: "normal", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
    	 	
    	self.btnClose.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnClose.setFontSize({state: "focused", size: 36,});
		self.btnClose.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a:0 },});
		self.btnClose.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.btnClose.setBorder({state: "focused", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
						    
		self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnClose.setFontSize({state: "focused-roll-over",size: 36,});					    
		self.btnClose.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a:0 },});
		self.btnClose.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
    	self.btnClose.setBorder({state: "focused-roll-over", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		
    	self.btnClose.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 
    	self.btnClose.setFontSize({state: "selected",size: 36,});					    
		self.btnClose.setBackgroundColor({state: "selected", color: { r:255, g:255, b:255, a:0 },});
    	self.btnClose.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		//self.btnClose.setBorder({state: "selected", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
    	self.btnClose.Show();	
    	print('[connectmobile-guide-view.js]-------createButton closeBtn');    	   		
    },    
 
	isInRootPath:function(){
		return true;
	},
	 /**playPrepareGuide   	 
	* @name playPrepareGuide	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	playPrepareGuide:function(){
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '5');
		stepText = stepText.replace('<<B>>', '1');
		
		var prepareText = stepText + ', ' 
			+ resMgr.getText('COM_SID_PREPRARE')+ ', ' 
			+ resMgr.getText('COM_SID_LETS_GET_STARTED')+', '
			+ resMgr.getText('COM_SID_ENJOY_PHOTOS_VIDEOS_MUSIC_MOBILE_TV')+', '
			+ resMgr.getText('COM_SID_WHAT_YOU_NEED_KR_DEVICE') +', '
			+ resMgr.getText('COM_SID_WIRELESS_ROUTHER_MOBILE_DEVICE');
		voiceGuide.play(prepareText);

	},
	 /**playNetworkConnectGuide   	 
	* @name playNetworkConnectGuide	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	playNetworkConnectGuide:function(){
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '5');
		stepText = stepText.replace('<<B>>', '2');
		
		var networkConnectText = stepText + ', ' 
			+ resMgr.getText('COM_TV_SID_CONNECT') +', ' 
			+ resMgr.getText('COM_SID_JOIN_WIRELESS_NETWORK')+', '
			+ resMgr.getText('COM_SID_TV_MOBILE_ON_SAMSE_WIRELESS_NETWORK')+', '
			+ (self.lastestDLNADevice == '' ? '': resMgr.getText('COM_SID_TV_CONNECTED_TO_COLON')+ self.lastestDLNADevice+', ') 
			+ resMgr.getText('COM_SID_SET_MOBILE_CONNECT_SAME_NETWORK_TV');
		voiceGuide.play(networkConnectText);
	},
	/**playNoNetworkConnectGuide   	 
	* @name playNoNetworkConnectGuide	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	playNoNetworkConnectGuide:function(){	
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '5');
		stepText = stepText.replace('<<B>>', '2');
		
		var noNetworkConnectText = stepText +', ' 
			+ resMgr.getText('COM_TV_SID_CONNECT') +', ' +
			+ resMgr.getText('COM_SID_JOIN_WIRELESS_NETWORK')+', '
			+ resMgr.getText('COM_SID_TV_MOBILE_ON_SAMSE_WIRELESS_NETWORK')+', '
			+ resMgr.getText('COM_SID_A_WIRELESS_ROUTER') +', '
			+ resMgr.getText('COM_SID_TV_NOT_CONNECTED_WIRELESS_NETWORK_NETWORK_SETTING')+', '
			+ resMgr.getText('COM_TV_SID_NETWORK_SETTINGS')
			+', ' + resMgr.getText('TV_SID_BUTTON');
		voiceGuide.play(noNetworkConnectText);
	},
	/**playInstallGuide   	 
	* @name playInstallGuide	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	playInstallGuide:function(){
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '5');
		stepText = stepText.replace('<<B>>', '3');
		var installText = stepText + ', '
			+ resMgr.getText('COM_SID_INSTALL')+', '
			+ resMgr.getText('COM_SID_INSTALL_SMART_VIEW')+', '
			+ resMgr.getText('COM_SID_DOWNLOAD_FEE_MOBILE_APP_SMART_VIEW')+', '
			+ resMgr.getText('COM_SID_SEARTCH_SMART_VIEW_APP_STORE')+', '
			+ resMgr.getText('COM_SID_TAP_INSTALL_BUTTON');
		voiceGuide.play(installText);
	},
	/**playConnectBrowserGuide   	 
	* @name playConnectBrowserGuide	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	playLinkGuide:function(){
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '5');
		stepText = stepText.replace('<<B>>', '4');
		
		var tvName = resMgr.getText('TV_SID_MIX_TV_NAME_IS');
		tvName = tvName.replace('<<A>>', Vconf.getValue('db/menu/network/devicename/tv_name'));
		var linkText = stepText + ', '
			+ resMgr.getText('COM_LINK_KR_LINK')+', '
			+ resMgr.getText('COM_SID_MOBIEL_DEVICE_AND_TV')+', '
			+ resMgr.getText('COM_SID_SMART_VIEW_LINK_PHONE_TABLET')+', '
			+ resMgr.getText('COM_SID_OPEN_SMART_VIEW')+', '
			+ resMgr.getText('COM_SID_TAP_CONNECTE_TO_TV')+', '
			+ resMgr.getText('COM_SID_CHOOSE_TV_FROM_LIST')+', '
			+ tvName+', '
			+ resMgr.getText('COM_SID_ENTER_PIN_SHOWN_TV');

		voiceGuide.play(linkText);
	},
	/**playConnectBrowserGuide   	 
	* @name playConnectBrowserGuide	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	playConnectBrowserGuide:function(){
		var connectDeviceName = resMgr.getText('COM_IDS_MSG_BT_CONNECTED_KR_YEONGEOL');
		if(self.lastestDLNADevice != ''){
			connectDeviceName = connectDeviceName.replace('<<A>>',self.lastestDLNADevice);
		}else{
			connectDeviceName = '';
		}
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '5');
		stepText = stepText.replace('<<B>>', '5');
		
		var browserText = stepText + ', '
			+ resMgr.getText('COM_FBID_BROWSE_KR_WANRYO')+', '
			+ resMgr.getText('COM_SID_START_EXPLORING')+', '
			+ connectDeviceName+', '
			+ resMgr.getText('COM_SID_ENJOY_CONTENT_MOBILE_DEVICE_TV')+', '
			+ resMgr.getText('COM_SID_TRANSAFER_SIMPLE_PUSH')+', '
			+ resMgr.getText('TV_SID_ACEESS_MULTIMEDIA_MOBILE_SMARTHUB_UPPER')+', '
			+ resMgr.getText('COM_SID_WHOW_MY_FILES') + ', ' + resMgr.getText('TV_SID_BUTTON');




		voiceGuide.play(browserText);
	},
	/**playNoConnectBrowserGuide   	 
	* @name playNoConnectBrowserGuide	 
	* @memberOf ConMobileGuidePage
	* @method
	* @return {} 	 
	* */
	playNoConnectBrowserGuide:function(){			
		var stepText = resMgr.getText('TV_MIX_STEP_OF');
		stepText = stepText.replace('<<A>>', '5');
		stepText = stepText.replace('<<B>>', '5');
		
		var browserText = stepText + ', '
			+ resMgr.getText('COM_FBID_BROWSE_KR_WANRYO')+', '
			+ resMgr.getText('COM_SID_START_EXPLORING')+', '
			+ resMgr.getText('COM_SID_ENJOY_CONTENT_MOBILE_DEVICE_TV')+', '
			+ resMgr.getText('COM_SID_TRANSAFER_SIMPLE_PUSH')+', '
			+ resMgr.getText('TV_SID_ACEESS_MULTIMEDIA_MOBILE_SMARTHUB_UPPER')+','
			+ resMgr.getText('COM_SID_CLOSE') + ', ' + resMgr.getText('TV_SID_BUTTON');

		voiceGuide.play(browserText);
	},

	/** return text width
	* @name getTextWidth	 
	* @memberOf FolderPathList
	* @method 	 
	* */
	getTextWidth: function(textList, textHigth, fontStyle){
		var textWidth = 0;
		Log.e("getTextWidth >>>> textList:"+textList);
		//calc text width, font: 'Calibri 26px',
		txtCalculation = new TextWidgetEx({
			x:0,
			y:0,
			height: textHigth,
	        font: fontStyle,
	        text: textList,
	        parent: scene,
	        opacity: 0,
	        verticalAlignment: 'center',
	        ellipsize: true,
	        textColor: {r:0x0f, g:0x18, b:0x27},
	    });
		
		textWidth = txtCalculation.width;
		Log.e("getTextWidth >>>> textWidth:"+textWidth);
		
	    // Delete it
	    txtCalculation.destroy();
		txtCalculation = null;

		return textWidth;
	},
	
	setAccessilibity: function(){
		if(HALOUtil.highContrast==false && HALOUtil.enlarge==false){
				self.setTextStyle(1);
	    }else if(HALOUtil.highContrast==false && HALOUtil.enlarge==true){			   
			self.setTextStyle(2);		    	
	    }else if(HALOUtil.highContrast==true && HALOUtil.enlarge==false){	    	 
	    	self.setTextStyle(3);		    	
	    }else {
	    	self.setTextStyle(4);		    	
	    }
		
	},
	

	setTextStyle: function(style){		
		if(style==1){				
				self.restoreHighContrast();	
				self.restoreEnlarge();							
		}else if(style==2){//only enlarge
			self.restoreHighContrast();	
			self.setEnlarge();		
		}else if(style==3){//only high contrast
			self.setHighContrast();	
			self.restoreEnlarge();			
		}else{ //both enlarge and high contrast
			self.setHighContrast();
			self.setEnlarge();					
		}
		
	},
	
	setEnlarge: function(){
		if(self.index==1){
			self.setPrepareEnlarge();			
		}else if(self.index==2){
			self.setConnectEnlarge();			
		}else if(self.index==3){
			self.setInstallEnlarge();			
		}else if(self.index==4){
			self.setLinkEnlarge();	
		}else{
			self.setBrowserEnlarge();	
		}		
	},
	
	restoreEnlarge: function(){
		if(self.index==1){
			self.restorePrepareEnlarge();			
		}else if(self.index==2){
			self.restoreConnectEnlarge();			
		}else if(self.index==3){
			self.restoreInstallEnlarge();			
		}else if(self.index==4){
			self.restoreLinkEnlarge();	
		}else{
			self.restoreBrowserEnlarge();	
		}		
	},
	
	
	setHighContrast: function(){
		if(self.index==1){
			self.setPrepareHighContrast();			
		}else if(self.index==2){
			self.setConnectHighContrast();			
		}else if(self.index==3){
			self.setInstallHighContrast();			
		}else if(self.index==4){
			self.setLinkHighContrast();	
		}else{
			self.setBrowserHighContrast();	
		}		
	},
	
	restoreHighContrast: function(){
		if(self.index==1){
			self.restorePrepareHighContrast();			
		}else if(self.index==2){
			self.restoreConnectHighContrast();			
		}else if(self.index==3){
			self.restoreInstallHighContrast();			
		}else if(self.index==4){
			self.restoreLinkHighContrast();	
		}else{
			self.restoreBrowserHighContrast();	
		}		
	},
	
	
	setPrepareEnlarge: function(){
		self.preparePage.getDescendant('mobile_prepare_page_title').font='SamsungSmart_Light 127px';
				self.preparePage.getDescendant('mobile_prepare_page_uptext').font='SamsungSmart_Light 43px';
				self.preparePage.getDescendant('mobile_prepare_page_downtext').font='SamsungSmart_Light 50px';
				self.preparePage.getDescendant('mobile_prepare_page_downtext2').font='SamsungSmart_Light 40px';
				self.preparePage.getDescendant('mobile_prepare_page_title').y=100;
				self.preparePage.getDescendant('mobile_prepare_page_title').height=127;
				self.preparePage.getDescendant('mobile_prepare_page_downtext2').y = 900;
		
	},
	restorePrepareEnlarge: function(){
		self.preparePage.getDescendant('mobile_prepare_page_title').font='SamsungSmart_Light 85px';
				self.preparePage.getDescendant('mobile_prepare_page_uptext').font='SamsungSmart_Light 36px';
				self.preparePage.getDescendant('mobile_prepare_page_downtext').font='SamsungSmart_Light 42px';
				self.preparePage.getDescendant('mobile_prepare_page_downtext2').font='SamsungSmart_Light 34px';
				self.preparePage.getDescendant('mobile_prepare_page_title').y=145;
				self.preparePage.getDescendant('mobile_prepare_page_title').height=90;
				self.preparePage.getDescendant('mobile_prepare_page_downtext2').y = 894;
	},
	setConnectEnlarge: function(){
		
		if (netController.getCurrentWirelessState()) {
			if(self.vconfMenuLang == 'ta_IN.utf8' || self.vconfMenuLang == 'ja_JP.utf8'){
				self.connectPage.getDescendant('mobile_connect_page_title').font='SamsungSmart_Light 100px';

			}else{
				self.connectPage.getDescendant('mobile_connect_page_title').font='SamsungSmart_Light 127px';
			}
			self.connectPage.getDescendant('mobile_connect_page_uptext').font='SamsungSmart_Light 43px';
			self.connectPage.getDescendant('mobile_wireless_name').font='SamsungSmart_Light 38px';
			self.connectPage.getDescendant('mobile_connect_page_downtext').font='SamsungSmart_Light 40px';
			self.connectPage.getDescendant('mobile_connect_page_title').y=100;
			self.connectPage.getDescendant('mobile_connect_page_title').height=127;
			self.connectPage.getDescendant('mobile_connect_page_uptext').y = 271;
			
		}else{
			if(self.vconfMenuLang == 'ta_IN.utf8' || self.vconfMenuLang == 'ja_JP.utf8'){
				self.disconnectPage.getDescendant('mobile_disconnect_page_title').font='SamsungSmart_Light 100px';
			}else{
				self.disconnectPage.getDescendant('mobile_disconnect_page_title').font='SamsungSmart_Light 127px';
			}
			self.disconnectPage.getDescendant('mobile_disconnect_page_uptext').font='SamsungSmart_Light 43px';
			self.disconnectPage.getDescendant('mobile_disconnect_page_DownRouterText').font='SamsungSmart_Light 38px';
			self.disconnectPage.getDescendant('mobile_disconnect_page_downtext').font='SamsungSmart_Light 40px';
			self.disconnectPage.getDescendant('mobile_disconnect_page_title').y=100;
			self.disconnectPage.getDescendant('mobile_disconnect_page_title').height=127;
			self.disconnectPage.getDescendant('mobile_disconnect_page_uptext').y = 271;
			self.disconnectPage.getDescendant('mobile_disconnect_page_DownRouterText').height = 46;
			
			//self.btnNet.setSize(382, 76);
    		//self.btnNet.x=769+offSet;
		    		
    		self.btnNet.setFontSize({state: "normal",size: 43,});
    		self.btnNet.setFontSize({state: "focused",size: 43,});
    		self.btnNet.setFontSize({state: "focused-roll-over",size: 43,});
    		self.btnNet.setFontSize({state: "selected",size: 43,});  		   		
    		   				
		}
		
	},
	restoreConnectEnlarge: function(){		
		if (netController.getCurrentWirelessState()) {
			self.connectPage.getDescendant('mobile_connect_page_title').font='SamsungSmart_Light 85px';
			self.connectPage.getDescendant('mobile_connect_page_uptext').font='SamsungSmart_Light 36px';
			self.connectPage.getDescendant('mobile_wireless_name').font='SamsungSmart_Light 32px';
			self.connectPage.getDescendant('mobile_connect_page_downtext').font='SamsungSmart_Light 34px';
			self.connectPage.getDescendant('mobile_connect_page_title').y=145;
			self.connectPage.getDescendant('mobile_connect_page_title').height=90;
			self.connectPage.getDescendant('mobile_connect_page_uptext').y = 261;
			
		}else{
			self.disconnectPage.getDescendant('mobile_disconnect_page_title').font='SamsungSmart_Light 85px';
			self.disconnectPage.getDescendant('mobile_disconnect_page_uptext').font='SamsungSmart_Light 36px';
			self.disconnectPage.getDescendant('mobile_disconnect_page_DownRouterText').font='SamsungSmart_Light 32px';
			self.disconnectPage.getDescendant('mobile_disconnect_page_downtext').font='SamsungSmart_Light 34px';
			self.disconnectPage.getDescendant('mobile_disconnect_page_title').y=145;
			self.disconnectPage.getDescendant('mobile_disconnect_page_title').height=90;
			self.disconnectPage.getDescendant('mobile_disconnect_page_uptext').y = 261;
			self.disconnectPage.getDescendant('mobile_disconnect_page_DownRouterText').height = 36;
			
			//self.btnNet.setSize(324, 76);
    		//self.btnNet.x=799+offSet; 
    		self.btnNet.setFontSize({state: "normal",size: 32,});
    		self.btnNet.setFontSize({state: "focused",size: 36,});
    		self.btnNet.setFontSize({state: "focused-roll-over",size: 36,});
    		self.btnNet.setFontSize({state: "selected",size: 36,}); 	
    							
		}
		
	},
	
	setInstallEnlarge: function(){
		if( self.vconfMenuLang == 'ja_JP.utf8'){
			self.installPage.getDescendant('mobile_install_page_title').font='SamsungSmart_Light 110px';
		}else{
			self.installPage.getDescendant('mobile_install_page_title').font='SamsungSmart_Light 127px';
		}
		self.installPage.getDescendant('mobile_install_page_uptext').font='SamsungSmart_Light 43px';
		self.installPage.getDescendant('mobile_install_page_downtext1').font='SamsungSmart_Light 40px';
		self.installPage.getDescendant('mobile_install_page_downtext2').font='SamsungSmart_Light 40px';
		self.installPage.getDescendant('mobile_install_page_title').y=124;
		self.installPage.getDescendant('mobile_install_page_title').height=127;
		self.installPage.getDescendant('mobile_install_page_downtext1').height = 200;
		
	},
	restoreInstallEnlarge: function(){
		self.installPage.getDescendant('mobile_install_page_title').font='SamsungSmart_Light 85px';
		self.installPage.getDescendant('mobile_install_page_uptext').font='SamsungSmart_Light 36px';
		self.installPage.getDescendant('mobile_install_page_downtext1').font='SamsungSmart_Light 34px';
		self.installPage.getDescendant('mobile_install_page_downtext2').font='SamsungSmart_Light 34px';
		self.installPage.getDescendant('mobile_install_page_title').y=145;
		self.installPage.getDescendant('mobile_install_page_title').height=90;
		self.installPage.getDescendant('mobile_install_page_downtext1').height = 200;
		
	},
	
	setLinkEnlarge: function(){
		self.linkPage.getDescendant('mobile_link_page_title').font='SamsungSmart_Light 95px';
		self.linkPage.getDescendant('mobile_link_page_uptext').font='SamsungSmart_Light 43px';
		self.linkPage.getDescendant('mobile_link_page_downtext1').font='SamsungSmart_Light 40px';
		self.linkPage.getDescendant('mobile_link_page_downtext2').font='SamsungSmart_Light 40px';
		self.linkPage.getDescendant('mobile_link_page_downtext3').font='SamsungSmart_Light 40px';
		self.linkPage.getDescendant('mobile_link_page_downtext4').font='SamsungSmart_Light 40px';
		self.linkPage.getDescendant('mobile_link_page_title').y=80;
		self.linkPage.getDescendant('mobile_link_page_title').height=200;
		self.linkPage.getDescendant('mobile_link_page_uptext').y = 302;
		self.linkPage.getDescendant('mobile_link_page_downtext1').height = 173;
		
	},
	restoreLinkEnlarge: function(){
		self.linkPage.getDescendant('mobile_link_page_title').font='SamsungSmart_Light 85px';
		self.linkPage.getDescendant('mobile_link_page_uptext').font='SamsungSmart_Light 36px';
		self.linkPage.getDescendant('mobile_link_page_downtext1').font='SamsungSmart_Light 34px';
		self.linkPage.getDescendant('mobile_link_page_downtext2').font='SamsungSmart_Light 34px';
		self.linkPage.getDescendant('mobile_link_page_downtext3').font='SamsungSmart_Light 34px';
		self.linkPage.getDescendant('mobile_link_page_downtext4').font='SamsungSmart_Light 34px';
		self.linkPage.getDescendant('mobile_link_page_title').y=145;
		self.linkPage.getDescendant('mobile_link_page_title').height=90;
		self.linkPage.getDescendant('mobile_link_page_uptext').y = 276;
		self.linkPage.getDescendant('mobile_link_page_downtext1').height = 173;
		self.setLinkPageTextPos();
		
	},
	setBrowserEnlarge: function(){
		self.browserPage.getDescendant('mobile_browser_page_title').font='SamsungSmart_Light 127px';
		self.browserPage.getDescendant('mobile_browser_page_uptext').font='SamsungSmart_Light 43px';
		if(self.vconfMenuLang == 'ta_IN.utf8' || self.vconfMenuLang == 'hy_AM.utf8' || self.vconfMenuLang == 'ka_GE.utf8'){
			self.browserPage.getDescendant('mobile_browser_page_downtext1').font='SamsungSmart_Light 38px';
			self.browserPage.getDescendant('mobile_browser_page_downtext2').font='SamsungSmart_Light 38px';

		}else{
			self.browserPage.getDescendant('mobile_browser_page_downtext1').font='SamsungSmart_Light 40px';
			self.browserPage.getDescendant('mobile_browser_page_downtext2').font='SamsungSmart_Light 40px';

		}
		self.browserPage.getDescendant('mobile_browser_page_title').y=100;
		self.browserPage.getDescendant('mobile_browser_page_title').height=127;
		//self.browserPage.getDescendant('mobile_browser_page_uptext').y = 271;
		self.browserPage.getDescendant('mobile_browser_page_downtext1').height = 168;
		self.browserPage.getDescendant('mobile_browser_page_downtext2').height = 168;
		
		//button enlarge
		self.btnClose.setFontSize({state: "normal",size: 43,});
		self.btnClose.setFontSize({state: "focused",size: 43,});
		self.btnClose.setFontSize({state: "focused-roll-over",size: 43,});
		self.btnClose.setFontSize({state: "selected",size: 43,});
		self.btnClose.y = 955;
		//self.btnClose.setSize(382, 76);
		//self.btnClose.x=769+offSet;
		self.btnShowFiles.setFontSize({state: "normal",size: 43,});
		self.btnShowFiles.setFontSize({state: "focused",size: 43,});
		self.btnShowFiles.setFontSize({state: "focused-roll-over",size: 43,});
		self.btnShowFiles.setFontSize({state: "selected",size: 43,});
		self.btnShowFiles.y = 955;
		
	},
	restoreBrowserEnlarge: function(){
		self.browserPage.getDescendant('mobile_browser_page_title').font='SamsungSmart_Light 85px';
		self.browserPage.getDescendant('mobile_browser_page_uptext').font='SamsungSmart_Light 36px';
		self.browserPage.getDescendant('mobile_browser_page_downtext1').font='SamsungSmart_Light 34px';
		self.browserPage.getDescendant('mobile_browser_page_downtext2').font='SamsungSmart_Light 34px';
		self.browserPage.getDescendant('mobile_browser_page_title').y=135;
		self.browserPage.getDescendant('mobile_browser_page_title').height=90;
		//self.browserPage.getDescendant('mobile_browser_page_uptext').y = 261;
		self.browserPage.getDescendant('mobile_browser_page_downtext1').height = 168;
		self.browserPage.getDescendant('mobile_browser_page_downtext2').height = 168;
		
		self.btnClose.setFontSize({state: "normal",size: 32,});
		self.btnClose.setFontSize({state: "focused",size: 36,});
		self.btnClose.setFontSize({state: "focused-roll-over",size: 36,});
		self.btnClose.setFontSize({state: "selected",size: 36,});
		self.btnClose.y = 945;
						 		   		
		//self.btnClose.setSize(322, 76);
		//self.btnClose.x=794+offSet;
		self.btnShowFiles.setFontSize({state: "normal",size: 32,});
		self.btnShowFiles.setFontSize({state: "focused",size: 36,});
		self.btnShowFiles.setFontSize({state: "focused-roll-over",size: 36,});
		self.btnShowFiles.setFontSize({state: "selected",size: 36,}); 
		self.btnShowFiles.y = 945;
  		
	},
	

	setPrepareHighContrast: function(){
		self.preparePage.getDescendant('mobile_prepare_page_title').textColor = {r:0x00, g:0x00, b:0x00};
		self.preparePage.getDescendant('mobile_prepare_page_uptext').textColor = {r:0x00, g:0x00, b:0x00};
		self.preparePage.getDescendant('mobile_prepare_page_downtext').textColor = {r:0x00, g:0x00, b:0x00};
		self.preparePage.getDescendant('mobile_prepare_page_downtext2').textColor = {r:0x00, g:0x00, b:0x00};
		
	},
	restorePrepareHighContrast: function(){
		self.preparePage.getDescendant('mobile_prepare_page_title').textColor = {r:0x0f, g:0x18, b:0x27};
				self.preparePage.getDescendant('mobile_prepare_page_uptext').textColor = {r:0x37, g:0x3c, b:0x42};
				self.preparePage.getDescendant('mobile_prepare_page_downtext').textColor = {r:0x18, g:0x18, b:0x18};
				self.preparePage.getDescendant('mobile_prepare_page_downtext2').textColor = {r:0x78, g:0x78, b:0x78};
		
	},
	setConnectHighContrast: function(){
		if (netController.getCurrentWirelessState()) {	
			self.connectPage.getDescendant('mobile_connect_page_title').textColor = {r:0x00, g:0x00, b:0x00};
			self.connectPage.getDescendant('mobile_connect_page_uptext').textColor = {r:0x00, g:0x00, b:0x00};
			self.connectPage.getDescendant('mobile_wireless_name').textColor = {r:0x00, g:0x00, b:0x00};
			self.connectPage.getDescendant('mobile_connect_page_downtext').textColor = {r:0x00, g:0x00, b:0x00};
				
		} else {
			self.disconnectPage.getDescendant('mobile_disconnect_page_title').textColor = {r:0x00, g:0x00, b:0x00};
			self.disconnectPage.getDescendant('mobile_disconnect_page_uptext').textColor = {r:0x00, g:0x00, b:0x00};
			self.disconnectPage.getDescendant('mobile_disconnect_page_DownRouterText').textColor = {r:0x00, g:0x00, b:0x00};
			self.disconnectPage.getDescendant('mobile_disconnect_page_downtext').textColor = {r:0x00, g:0x00, b:0x00};
			
			self.btnNet.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
			//self.btnNet.setBorder({state: "normal", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
			self.btnNet.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
			//self.btnNet.setBorder({state: "focused", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
			self.btnNet.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
			//self.btnNet.setBorder({state: "focused-roll-over", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
			self.btnNet.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
			//self.btnNet.setBorder({state: "selected", border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
			self.btnNet.setTextColor({state: "normal", color: { r:00, g:00, b:00, a:255 },}); 
			self.btnNet.setTextColor({state: "focused", color: { r:00, g:00, b:00, a:255 },}); 
			self.btnNet.setTextColor({state: "focused-roll-over", color: { r:00, g:00, b:00, a:255 },}); 
			self.btnNet.setTextColor({state: "selected", color: { r:00, g:00, b:00, a:255 },});	
			
					
		}
		
	},
	restoreConnectHighContrast: function(){
		if (netController.getCurrentWirelessState()) {					
			self.connectPage.getDescendant('mobile_connect_page_title').textColor = {r:0x0f, g:0x18, b:0x27};
			self.connectPage.getDescendant('mobile_connect_page_uptext').textColor = {r:0x37, g:0x3c, b:0x42};
			self.connectPage.getDescendant('mobile_wireless_name').textColor = {r:0x00, g:0x88, b:0xcc};
			self.connectPage.getDescendant('mobile_connect_page_downtext').textColor = {r:0x78, g:0x78, b:0x78};
		} else {
			self.disconnectPage.getDescendant('mobile_disconnect_page_title').textColor = {r:0x0f, g:0x18, b:0x27};
			self.disconnectPage.getDescendant('mobile_disconnect_page_uptext').textColor = {r:0x37, g:0x3c, b:0x42};
			self.disconnectPage.getDescendant('mobile_disconnect_page_DownRouterText').textColor = {r:0x00, g:0x88, b:0xcc};
			self.disconnectPage.getDescendant('mobile_disconnect_page_downtext').textColor = {r:0x78, g:0x78, b:0x78};
			
			self.btnNet.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },}); 
	    	self.btnNet.setFontSize({state: "normal",size: 32,});			           	
	    	self.btnNet.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
			//self.btnNet.setBorder({state: "normal", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			
	    	self.btnNet.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
	    	self.btnNet.setFontSize({state: "focused", size: 36,});
			self.btnNet.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a:0 },});
			self.btnNet.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
			//self.btnNet.setBorder({state: "focused", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			
			self.btnNet.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		  	
	    	self.btnNet.setFontSize({state: "focused-roll-over", size: 36,});
			self.btnNet.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a:0 },});
			self.btnNet.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});	
			//self.btnNet.setBorder({state: "focused-roll-over", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			
			self.btnNet.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },});    		
	    	self.btnNet.setFontSize({state: "selected", size: 36,});
			self.btnNet.setBackgroundColor({state: "selected", color: { r:255, g:255, b:255, a:0 },});
			self.btnNet.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
			//self.btnNet.setBorder({state: "selected", border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
			
					
		}
		
		
	},
	
	setInstallHighContrast: function(){
		self.installPage.getDescendant('mobile_install_page_title').textColor = {r:0x00, g:0x00, b:0x00};
				self.installPage.getDescendant('mobile_install_page_uptext').textColor = {r:0x00, g:0x00, b:0x00};
				self.installPage.getDescendant('mobile_install_page_downtext1').textColor = {r:0x00, g:0x00, b:0x00};
				self.installPage.getDescendant('mobile_install_page_downtext2').textColor = {r:0x00, g:0x00, b:0x00};
		
	},
	restoreInstallHighContrast: function(){
		self.installPage.getDescendant('mobile_install_page_title').textColor = {r:0x0f, g:0x18, b:0x27};
				self.installPage.getDescendant('mobile_install_page_uptext').textColor = {r:0x37, g:0x3c, b:0x42};
				self.installPage.getDescendant('mobile_install_page_downtext1').textColor = {r:0x78, g:0x78, b:0x78};
				self.installPage.getDescendant('mobile_install_page_downtext2').textColor = {r:0x78, g:0x78, b:0x78};
		
	},
	
	setLinkHighContrast: function(){
		self.linkPage.getDescendant('mobile_link_page_title').textColor = {r:0x00, g:0x00, b:0x00};
				self.linkPage.getDescendant('mobile_link_page_uptext').textColor = {r:0x00, g:0x00, b:0x00};
				self.linkPage.getDescendant('mobile_link_page_downtext1').textColor = {r:0x00, g:0x00, b:0x00};
				self.linkPage.getDescendant('mobile_link_page_downtext2').textColor = {r:0x00, g:0x00, b:0x00};
				self.linkPage.getDescendant('mobile_link_page_downtext3').textColor = {r:0x00, g:0x00, b:0x00};
				self.linkPage.getDescendant('mobile_link_page_downtext4').textColor = {r:0x00, g:0x00, b:0x00};	
		
	},
	restoreLinkHighContrast: function(){
		self.linkPage.getDescendant('mobile_link_page_title').textColor = {r:0x0f, g:0x18, b:0x27};
				self.linkPage.getDescendant('mobile_link_page_uptext').textColor = {r:0x37, g:0x3c, b:0x42};
				self.linkPage.getDescendant('mobile_link_page_downtext1').textColor = {r:0x78, g:0x78, b:0x78};
				self.linkPage.getDescendant('mobile_link_page_downtext2').textColor = {r:0x78, g:0x78, b:0x78};
				self.linkPage.getDescendant('mobile_link_page_downtext3').textColor = {r:0x78, g:0x78, b:0x78};
				self.linkPage.getDescendant('mobile_link_page_downtext4').textColor = {r:0x78, g:0x78, b:0x78};	
		
	},
	setBrowserHighContrast: function(){
		self.browserPage.getDescendant('mobile_browser_page_title').textColor = {r:0x00, g:0x00, b:0x00};
		self.browserPage.getDescendant('mobile_browser_page_uptext').textColor = {r:0x00, g:0x00, b:0x00};
		self.browserPage.getDescendant('mobile_browser_page_downtext1').textColor = {r:0x00, g:0x00, b:0x00};
		self.browserPage.getDescendant('mobile_browser_page_downtext2').textColor = {r:0x00, g:0x00, b:0x00};
		
		self.btnClose.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
		self.btnClose.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});	
		self.btnClose.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
		self.btnClose.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
		/*
		self.btnClose.setBorder({state: "normal",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		self.btnClose.setBorder({state: "focused",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		self.btnClose.setBorder({state: "focused-roll-over",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		self.btnClose.setBorder({state: "selected",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		*/
		self.btnClose.setTextColor({state: "normal", color: { r:00, g:00, b:00, a:255 },}); 
		self.btnClose.setTextColor({state: "focused", color: { r:00, g:00, b:00, a:255 },}); 
		self.btnClose.setTextColor({state: "focused-roll-over", color: { r:00, g:00, b:00, a:255 },}); 
		self.btnClose.setTextColor({state: "selected", color: { r:00, g:00, b:00, a:255 },}); 

		self.btnShowFiles.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});    	    	
		self.btnShowFiles.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});	
		self.btnShowFiles.setBackgroundImage({state: 'focused-roll-over', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
		self.btnShowFiles.setBackgroundImage({state: 'selected', src: resMgr.getImgPath()+'/button/btn_style_a_f_h.png'});
		/*
		self.btnShowFiles.setBorder({state: "normal",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		self.btnShowFiles.setBorder({state: "focused",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		self.btnShowFiles.setBorder({state: "focused-roll-over",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		self.btnShowFiles.setBorder({state: "selected",border: {width:1, color: {r:0,g:0,b:0,a:255*0.1}}});
		*/
		self.btnShowFiles.setTextColor({state: "normal", color: { r:00, g:00, b:00, a:255 },}); 
		self.btnShowFiles.setTextColor({state: "focused", color: { r:00, g:00, b:00, a:255 },}); 
		self.btnShowFiles.setTextColor({state: "focused-roll-over", color: { r:00, g:00, b:00, a:255 },}); 
		self.btnShowFiles.setTextColor({state: "selected", color: { r:00, g:00, b:00, a:255 },}); 
		
	},
	restoreBrowserHighContrast: function(){
		
		self.browserPage.getDescendant('mobile_browser_page_title').textColor = {r:0x0f, g:0x18, b:0x27};
		self.browserPage.getDescendant('mobile_browser_page_uptext').textColor = {r:0x37, g:0x3c, b:0x42};
		self.browserPage.getDescendant('mobile_browser_page_downtext1').textColor = {r:0x78, g:0x78, b:0x78};
		self.browserPage.getDescendant('mobile_browser_page_downtext2').textColor = {r:0x78, g:0x78, b:0x78};
				   			
		self.btnClose.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },});  	    	 				    	
    	self.btnClose.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
		self.btnClose.setFontSize({state: "normal",size: 32,});		
    			    	 	
    	self.btnClose.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 		    	
		self.btnClose.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a:0 },});
		self.btnClose.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.btnClose.setFontSize({state: "focused",size: 36,});
						    
		self.btnClose.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 		    						    
		self.btnClose.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a:0 },});
		self.btnClose.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
    	self.btnClose.setFontSize({state: "focused-roll-over",size: 36,});
		
    	self.btnClose.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 		    					    
		self.btnClose.setBackgroundColor({state: "selected", color: { r:255, g:255, b:255, a:0 },});
    	self.btnClose.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.btnClose.setFontSize({state: "selected",size: 36,});
		/*
		self.btnClose.setBorder({state: "normal",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		self.btnClose.setBorder({state: "focused",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		self.btnClose.setBorder({state: "focused-roll-over",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		self.btnClose.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
*/
		self.btnShowFiles.setTextColor({state: "normal", color: { r:0x43, g:0x47, b:0x52, a:255 },});  	    	 				    	
    	self.btnShowFiles.setBackgroundImage({state: "normal", src: resMgr.getImgPath()+'/button/btn_style_a_n.png',});
    	self.btnShowFiles.setFontSize({state: "normal",size: 32,});	
		
    	self.btnShowFiles.setTextColor({state: "focused", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 		    	
		self.btnShowFiles.setBackgroundColor({state: "focused", color: { r:255, g:255, b:255, a:0 },});
		self.btnShowFiles.setBackgroundImage({state: 'focused', src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});	
		self.btnShowFiles.setFontSize({state: "focused",size: 36,});
		
		self.btnShowFiles.setTextColor({state: "focused-roll-over", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 		    						    
		self.btnShowFiles.setBackgroundColor({state: "focused-roll-over", color: { r:255, g:255, b:255, a:0 },});
		self.btnShowFiles.setBackgroundImage({state: "focused-roll-over", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
    	self.btnShowFiles.setFontSize({state: "focused-roll-over",size: 36,});
		
    	self.btnShowFiles.setTextColor({state: "selected", color: { r:0x21, g:0x9e, b:0xe6, a:255 },}); 		    					    
		self.btnShowFiles.setBackgroundColor({state: "selected", color: { r:255, g:255, b:255, a:0 },});
    	self.btnShowFiles.setBackgroundImage({state: "selected", src: resMgr.getImgPath()+'/button/btn_style_a_f.png'});
		self.btnShowFiles.setFontSize({state: "selected",size: 36,});
/*
		self.btnShowFiles.setBorder({state: "normal",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		self.btnShowFiles.setBorder({state: "focused",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		self.btnShowFiles.setBorder({state: "focused-roll-over",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
		self.btnShowFiles.setBorder({state: "selected",border: {width:1, color: { r:33, g:158, b:230, a:255 }}});
*/
	},
	showTooltips :function(button, text){
		Log.e("showTooltips >>> Destroy balloon.....text:"+text);
		print("showTooltips >>> Destroy balloon.....text:"+text);
		
		if(button == null || text == null){			
			Log.e("button == null || text == nul");
			return;
		}
		
    	var opt = {
	    		text: text,
	    		x: button.x,
	    		y: 6,
				wdgHeight: button.height,
				wdgWidth : button.width,
	    		fontsize: 30,
	    		font: '30px',
	    		tailType: 'up',
    	};

    	self.balloon = new BalloonTips();
    	self.balloon.show(opt);	

	},
	
	hideTooltips:function(){
		print('hideTooltips >>> .....');
		if(self.balloon != null){
			print('hideTooltips >>> Destroy balloon.....');
			Log.e("hideTooltips >>> Destroy balloon.....");
			self.balloon.hide();
			self.balloon.destroy();
			self.balloon = null;
		}
	},
	setFocusReturnFromMusicPlayer:function(){
		print("connection mobile guide view setFocusReturnFromMusicPlayer set root to self.widget");
		Log.e("connection mobile guide view setFocusReturnFromMusicPlayer set root to self.widget");

		Volt.Nav.setRoot(self.widget);
	},
});
exports = ConMobileGuidePage;

