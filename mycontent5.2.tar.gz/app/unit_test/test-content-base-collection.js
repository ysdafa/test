
var ContentBaseCollection = require("file://app/models/content-base-collection.js");


jasmine.describe('content base collection', function(){

	 var flag, result;

    jasmine.beforeEach(function()
    {
        flag = false;
    });
	jasmine.it('request all view data', function(){

		jasmine.runs(function(){
			print('request list runs');
			var collection  = new ContentBaseCollection();
			var options = {
				 	param_source_name : 'csf_local_source',
				 	param_scan_path: '/opt/storage/usb/sda1',
				 	param_content_type: 'CONTENT-FOLDER',
				 	param_sort_category: 'CATEGORY-FOLDER',
				 	param_prepare_data: 'test',
			};
			collection.requestList(options).then(function(response){
					print('-----------response-----------:' + response);
					result = response;
					flag = true;
			});
		});
	});
	jasmine.waitsFor(function() {
  		return flag; 
	}, 'not responsed in 5000ms', 5000);
	jasmine.runs(function(){
		jasmine.expect(result).toBe(true);
	});

});
	

	

