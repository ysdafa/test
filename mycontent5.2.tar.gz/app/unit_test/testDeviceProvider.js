var DeviceProvider = Volt.require('app/models/device-provider.js');

jasmine.describe('Device-collection api', function()
{
	
	jasmine.it('Device Collection GetValidIndex, input [1,8,5,7,10], 10, should return 2', function()
    {		
			var index = [1,8,5,7,10];
			var maxIndex = 10;
			
			jasmine.expect(DeviceProvider.collection._GetValidIndex(index,maxIndex)).toEqual(2);
	});
	
	jasmine.it('Device Collection GetValidIndex, input [1,2,3,4,5], 5, should return 6', function()
    {		
			var index = [1,2,3,4,5];
			var maxIndex = 5;
			
			jasmine.expect(DeviceProvider.collection._GetValidIndex(index,maxIndex)).toEqual(6);
	});
	jasmine.it('Device Collection GetValidIndex, input [1,2,4,5,7], 7, should return 3', function()
    {		
			var index = [1,2,4,5,7];
			var maxIndex = 7;
			
			jasmine.expect(DeviceProvider.collection._GetValidIndex(index,maxIndex)).toEqual(3);
	});
	jasmine.it('DeviceCollection GetValidIndex, input [2,3,4,5], 5,  should return 1', function()
    {		
			var index = [2,3,4,5];
			var maxIndex = 5;
			
			jasmine.expect(DeviceProvider.collection._GetValidIndex(index,maxIndex)).toEqual(1);
	});
	
	jasmine.it('Device provider usb device count, connect 1 usb device, device count should be 1', function()
    {		
			jasmine.expect(DeviceProvider.getUsbDeviceCount()).toEqual(1);
	});	
	
	jasmine.it('Device provider device type, connect 1 usb device, first device is usb', function()
    {		
			var device = DeviceProvider.collection.at(0);
			var type = device.get('type');
			print('[jasmine]  type:',type);
			jasmine.expect(type).toEqual('USB');
	});	
	
	jasmine.it('Device provide get device list, connect 1 usb device, return value is not null', function()
    {		
			jasmine.expect(DeviceProvider.getDeviceList() != null).toBeTruthy();
	});	
	
	jasmine.it('Device provide get first device, connect 1 usb device, return value is not null', function()
    {		DeviceProvider.getDeviceByIndex(0)
			jasmine.expect(DeviceProvider.getDeviceByIndex(0) != null).toBeTruthy();
	});	
	
});
