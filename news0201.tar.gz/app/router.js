var Backbone = Volt.require('lib/volt-backbone.js');
var RouterController = Volt.require('app/controller/router-controller.js');
var GlobalMediator = Volt.require('app/common/GlobalMediator.js');
var Global = Volt.require('app/common/Global.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
LogCollector = Volt.require('lib/volt-kpi.js');

//kpi log start
var KPI = Volt.require('app/common/kpi-options.js');
//kpi log end
var Router = Backbone.Router.extend({

    initialize: function() {
        this.on('route', function() {
            Volt.log('URL : ' + Backbone.history.location.hash);
        });
        GlobalMediator.on(CommonDefines.Event.APP_ON_DEACTIVATE, function(){

			Volt.isDeactive = true;
            //KPI start
            if (true == Global.LeaveByReturnForKPILog.get()){
                //record EXIT kpi event log
                var kpiExit = new KPI.Common.Exit();
                kpiExit.send({ew : Global.ExitWayForKPILog.get()});
                Global.ExitWayForKPILog.set('EXIT'); //restored to default

                Volt.log('Begin KPILogLeavePage');
                KPILogLeavePage();
            }
       	    //KPI end

			if(!Volt.isShowNetWotkSetting){
	            Global.APP_STATUS = Global.APP_DEACTIVATE;
	            var ErrorHandler = Volt.require('app/common/errorHandler.js');
	            ErrorHandler.hide();
	            RouterController.pauseView(RouterController.getCurrentView());
			}

            //for mls start
	    var voltapi = Volt.require('voltapi.js');
            var eVConfPlugin = voltapi['vconf'];
            var result = eVConfPlugin.getValue('memory/mls/state');
        	
            Volt.log(' vconf MLS_STATE : ' + result);
        	if(result == 1){
                PanelCommon = Volt.require('lib/panel-common.js');
                var dimView = PanelCommon.requireView('dim');
                dimView.hide();
        		print("[app.js] don't show the dim view !");	
        	}
            //for mls end
        });
        GlobalMediator.on(CommonDefines.Event.APP_ON_ACTIVATE, function(){
			Volt.isDeactive = false;

			if(Volt.isShowNetWotkSetting){
				var ErrorHandler = Volt.require('app/common/errorHandler.js');
				Volt.setTimeout(ErrorHandler.destroyPopup,1);
				Volt.Nav.endModal();
				Volt.isShowNetWotkSetting = false;
			}


            //KPI start
            if (true == Global.LeaveByReturnForKPILog.get()){
                Volt.log('Begin KPILogEnterPage');
                KPILogEnterPage();
                Global.LeaveByReturnForKPILog.set(false);
            }
       	    //KPI end

            Global.APP_STATUS = Global.APP_ACTIVE;
            RouterController.resumeView(RouterController.getCurrentView());
        });
        GlobalMediator.on(CommonDefines.Event.APP_ON_HIDE, function(){
            //KPI start
            //record EXIT kpi event log
            var kpiExit = new KPI.Common.Exit();
            kpiExit.send({ew : Global.ExitWayForKPILog.get()});
            Global.ExitWayForKPILog.set('EXIT'); //restored to default
            
            Volt.log('Begin KPILogLeavePage');
            Global.LeaveWayForKPILog.set('EXIT');
            KPILogLeavePage();
       	    //KPI end

            LogCollector.KPI_VoltLog_AppStop();
        });
    },

    routes: {
        'home': 'home',
        'detail/:id/:focus': 'detail',
		'weather/:id': 'weather',
		'tutorialColdStart' : 'tutorialColdStart',
		'weatherSetting' : 'weatherSetting'
    },

    home: function() {
        RouterController.root('main-view');
        Volt.KPIMapper.enterPage('H01_HOME', {d:{lw: Global.LeaveWayForKPILog.get()}});
        Global.LeaveWayForKPILog.set('');//reset
    },
    detail : function(id, focus){
        RouterController.detail('newson-detail-view', {'id':id,'focus':focus});
        Volt.KPIMapper.enterPage('H02_DETAIL', {d:{lw: Global.LeaveWayForKPILog.get()}});
        Global.LeaveWayForKPILog.set('');//reset
    },
	weather: function(id, options) { 
    	options.id = id;
    	Volt.log(typeof options.weatherTile);
    	RouterController.detail('weather-detial-view', options); 
        Volt.KPIMapper.enterPage('H04_WEATHER', {d:{lw: Global.LeaveWayForKPILog.get()}});
        Global.LeaveWayForKPILog.set('');//reset
	},
	tutorialColdStart : function() {
		RouterController.secondDepth('newson-tutorial-cold-start-view');
	},
	weatherSetting : function() {
        RouterController.secondDepth('newson-weather-setting-view-china');
        Volt.KPIMapper.enterPage('H05_WEATHER', {d:{lw: Global.LeaveWayForKPILog.get()}});
        Global.LeaveWayForKPILog.set('');//reset
	},
});

//KPI start
var KPILogEnterPage = function(){
    var pageEvent = '', pageName = '';
    if (RouterController.getCurrentView().name){
        pageName = RouterController.getCurrentView().name;
        Volt.log('Enter NewsOn on '+pageName);
        switch(pageName){
            case 'main-view':
                pageEvent = 'H01_HOME';
                break;
            case 'newson-detail-view':
                pageEvent = 'H02_DETAIL';
                break;
            case 'weather-detial-view':
                pageEvent = 'H04_WEATHER';
                break;
            case 'newson-weather-setting-view-china':
                pageEvent = 'H05_WEATHER';
                break;
            default:
                break;
        }
    }
    if (pageEvent != ''){
        Volt.KPIMapper.enterPage(pageEvent, {d:{lw: Global.LeaveWayForKPILog.get()}});
        Global.LeaveWayForKPILog.set('');//reset
    }
};

var KPILogLeavePage = function(){
    var pageEvent = '', pageName = '';
    if (RouterController.getCurrentView().name){
        pageName = RouterController.getCurrentView().name;
        Volt.log('Exit NewsOn on '+pageName);
        switch(pageName){
            case 'main-view':
                pageEvent = 'H01_HOME';
                break;
            case 'newson-detail-view':
                pageEvent = 'H02_DETAIL';
                break;
            case 'weather-detial-view':
                pageEvent = 'H04_WEATHER';
                break;
            case 'newson-weather-setting-view-china':
                pageEvent = 'H05_WEATHER';
                break;
            default:
                break;
        }
    }
    if (pageEvent != ''){
        Volt.KPIMapper.leavePage(pageEvent, {d:{lw: Global.LeaveWayForKPILog.get()}});
        Global.LeaveWayForKPILog.set('');//reset
    }
};
//KPI end

exports = new Router();
