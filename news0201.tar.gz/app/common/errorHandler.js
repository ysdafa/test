var _ = Volt.require("modules/underscore.js")._;
var Backbone = Volt.require('lib/volt-backbone.js');
var Q = Volt.require('modules/q.js');
//var BaseView = require("file://app/views/baseView.js");
var PanelCommon = Volt.require('lib/panel-common.js');
var CommonTemplate = Volt.requireAppTemplate('newson-common-template.js');
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
//var MessageboxView = Volt.require('app/views/messagebox-view.js');
var BaseView = PanelCommon.BaseView;

//var dimView = PanelCommon.requireView('dim');
var winsetMessageBox = Volt.require("WinsetUIElement/winsetMessageBox.js");
var Global = Volt.require('app/common/Global.js');
var RouterController = Volt.require('app/controller/router-controller.js');
DeviceModel = Volt.require('app/common/deviceModel.js');

var ErrorHandlerSelf = null;
var messageBox = null;
var option = null;
var ErrorHandler = BaseView.extend({
	template : CommonTemplate.container,
	viewCallback : null,
	buttonClickType:'',
	parent : null,
	showFlag : false,
	type:-1,
	timer:null,
	firstTime:true,

	initialize : function() {
		ErrorHandlerSelf = this;

		this.setWidget(PanelCommon.loadTemplate(this.template));
		scene.addChild(this.widget);
	},	
			
    handleNetworkError : function(errorCode, viewCallback){
    	Volt.log('errorCode:'+errorCode);

        switch (errorCode) {
            case 400:
            case 401:
            case 403:
            case 404:
            case 405:
            case 406:
            case 408:
            case 409:
                this.show(CommonDefines.PopupType.SERVER_ERROR2, errorCode, viewCallback);
                break;
            
            case 500:
            case 503:
                this.show(CommonDefines.PopupType.SERVER_UNDER_MAINTAIN, errorCode, viewCallback);
                break;

            default :
                this.show(CommonDefines.PopupType.UNEXPECTED_PROBLEM, errorCode, viewCallback);
                break;
        }
    },
    
    show : function(type, errorCode, viewCallback) 
	{
	    Volt.log('type:'+type + 'errorCode:'+errorCode);

		if(ErrorHandlerSelf.showFlag === true){
			Volt.log('is showing popup now');
			return;
		}

		if(messageBox) {
			messageBox.destroy();
            messageBox = null;
		}

		if(Volt.isDeactive){
			Volt.log('is isDeactive now');
		 	viewCallback();
			return;
		}

		
		ErrorHandlerSelf.type = type;		
	    ErrorHandlerSelf.showFlag = true;

		if(viewCallback === undefined){
		
			ErrorHandlerSelf.viewCallback = null;
		}
		else {
		
			ErrorHandlerSelf.viewCallback = viewCallback;
		}
		scene.removeChild(ErrorHandlerSelf.widget);
		scene.addChild(ErrorHandlerSelf.widget);
		/*
		dimView.show({
	        parent: this.widget
	    });
        */
		var options = {type : type, errorCode: errorCode };
	   	var content = __getContent(options);
		var timeout = __getTimeout(options.type);
		Volt.log('timeout ='+ timeout);
		ErrorHandlerSelf.timeOutTime = timeout;
		ErrorHandlerSelf.timeoutCB = ErrorHandlerSelf.hide;
		ErrorHandlerSelf.callbacks = [];
		
		switch (type) {
            case CommonDefines.PopupType.SAVE :
            case CommonDefines.PopupType.MAXIMUM :
            case CommonDefines.PopupType.MINIMUM :
            case CommonDefines.PopupType.EM_FROM_CITYLIST_SERVER :
            case CommonDefines.PopupType.VERSION :
            case CommonDefines.PopupType.APP_VERSION :
            case CommonDefines.PopupType.DEVICE_INFO :
            case CommonDefines.PopupType.SERVER_ERROR2 : 
            case CommonDefines.PopupType.SERVER_UNDER_MAINTAIN :
            case CommonDefines.PopupType.UNEXPECTED_PROBLEM :
	    case CommonDefines.PopupType.NETWORK_ERROR_ENTRY:
		      option = {
                    type : type,
                    style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button ,
	                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
	                nResoultionStyle: Volt.is720p?winsetMessageBox.ResoultionStyle.Resoultion_720:winsetMessageBox.ResoultionStyle.Resoultion_1080,
	                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
	                button : true,
	                contentText:content,
	                button1Text:Volt.i18n.t('SID_OK'),
	                contextLineNumber: 1,
	                prePage : '',
                 };

	        Volt.setTimeout(ErrorHandlerSelf.showMessageBox,10);

                break;
        case CommonDefines.PopupType.CONFIG_VERSION :
            getConfigXML().then(function(configXML){
                content = configXML.widget.ver;
                option = {
                    type : type,
                    style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button ,
	                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
	                nResoultionStyle: Volt.is720p?winsetMessageBox.ResoultionStyle.Resoultion_720:winsetMessageBox.ResoultionStyle.Resoultion_1080,
	                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
	                button : true,
	                contentText:content,
	                button1Text:Volt.i18n.t('SID_OK'),
	                contextLineNumber: 1,
	                prePage : '',
                 };

    	        Volt.setTimeout(ErrorHandlerSelf.showMessageBox,10);
            });
            break;
		case CommonDefines.PopupType.NETWORK_ERROR1 :
   		        option = {
                            type : type,
                            style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line ,
      		                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
      		                nResoultionStyle:  Volt.is720p?winsetMessageBox.ResoultionStyle.Resoultion_720:winsetMessageBox.ResoultionStyle.Resoultion_1080,
      		                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
      		                button : true,
      		                contentText:content,
      		                button1Text:Volt.i18n.t('UID_ONTV_TROUBLESHOT'),
      		                button2Text:Volt.i18n.t('SID_CANCEL'),
      		                contextLineNumber: 1,
      		                prePage : '',
                     };

				ErrorHandlerSelf.callbacks = [ErrorHandlerSelf.networkCallback];
				Volt.setTimeout(ErrorHandlerSelf.showMessageBox,10);
                break;

            case CommonDefines.PopupType.CANCEL :
  
				option = {
                        type : type,
                        style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_1Line ,
  		                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
  		                nResoultionStyle:  Volt.is720p?winsetMessageBox.ResoultionStyle.Resoultion_720:winsetMessageBox.ResoultionStyle.Resoultion_1080,
  		                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
  		                button : true,
  		                contentText:content,
  		                button1Text:Volt.i18n.t('SID_YES'),
  		                button2Text:Volt.i18n.t('SID_NO'),
  		                contextLineNumber: 1,
  		                prePage : '',
                 };
				//ErrorHandlerSelf.callbacks = [function(){ErrorHandlerSelf.hide(); Backbone.history.back();}];
				Volt.setTimeout(ErrorHandlerSelf.showMessageBox,10);

                break;
    
			default :
				Volt.log('error type');
				break;			
		}
	},
					
						
	networkCallback : function() {
        Volt.log();		
		var aulApp = new Aul();
		var ret = aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
		
		//ErrorHandlerSelf.networkErrorFlag = true;
    },
	
    showMessageBox : function() {
        Volt.log();

        messageBox = new winsetMessageBox(option);
		ErrorHandlerSelf.widget.addChild(messageBox);
        //voice guide start
        var voiceText = '';
        if (option.title){
            voiceText = voiceText + ((''==voiceText)?'':', ') + option.title;
        }
        if (option.contentText){
            voiceText = voiceText + ((''==voiceText)?'':', ') + option.contentText;
        }
        if (voiceText != ''){
            Global.voiceGuide(voiceText);
        }
        //voice guide end
        
		messageBox.show();
		
		//ErrorHandlerSelf.messageBox = PanelCommon.loadTemplate(CommonTemplate.MessageBoxNoTitle,option, ErrorHandlerSelf.widget),
		
		ErrorHandlerSelf.messageBoxListener = new MessageBoxListener;
        messageBox.addListener(ErrorHandlerSelf.messageBoxListener);
		ErrorHandlerSelf.messageBoxListener.OnButtonEvent = ErrorHandlerSelf.onButtonEvent;
		messageBox.onKeyEvent = ErrorHandlerSelf._onkeyEvent;

		messageBox.setDefaultFocus("button_1");	

		if (ErrorHandlerSelf.timer != null) {
			Volt.clearTimeout(ErrorHandlerSelf.timer);
			ErrorHandlerSelf.timer = null;
		}

		if(ErrorHandlerSelf.timeOutTime > 0) {
			Volt.log('set timer:'+ ErrorHandlerSelf.timeOutTime);
            ErrorHandlerSelf.timer = Volt.setTimeout(ErrorHandlerSelf.timeoutCB, ErrorHandlerSelf.timeOutTime);
    	}
        RouterController.pauseView(RouterController.getCurrentView());
		Volt.Nav.beginModal(messageBox);
		return messageBox;
    },

    _onkeyEvent: function(keycode, type) {
        Volt.log('keycode keycode:' + keycode + 'type:' + type);
		if(ErrorHandlerSelf.showFlag == false){
        	Volt.log('showFlag is false');
			return false;
		}

		
		var ret = false;
		if (type == Volt.EVENT_KEY_RELEASE) {
			Volt.log('EVENT_KEY_PRESS');
			return false;
		}
		switch (keycode) {
			case Volt.KEY_RETURN: {
				Volt.log(' press return key');
			    ErrorHandlerSelf.hide();
				Volt.isPopUpReturn = true;
				ret = true;
				break;
			}
			default:
				break;
		}
		return ret;
    },

	onButtonEvent : function(messagebox, nButtonIndex, eventType) {
        Volt.log('oonButtonEvent eventType:' + eventType + 'nButtonIndex' + nButtonIndex);

		 if(Volt.isShowNetWotkSetting){
			Volt.log('isShowNetWotkSetting');
			return;
		 }

		
		if (ErrorHandlerSelf.timer != null) {
			Volt.clearTimeout(ErrorHandlerSelf.timer);	
            ErrorHandlerSelf.timer = Volt.setTimeout(ErrorHandlerSelf.timeoutCB, ErrorHandlerSelf.timeOutTime);
		}
		
		if ("button_clicked" == eventType){
			 switch(nButtonIndex) {
                case "button_1": {
					ErrorHandlerSelf.buttonClickType = "button_1";
					if (ErrorHandlerSelf.callbacks && ErrorHandlerSelf.callbacks[0]) {
						ErrorHandlerSelf.callbacks[0]();
						
						/*if(ErrorHandlerSelf.type != CommonDefines.PopupType.CANCEL){
                    		ErrorHandlerSelf.callbacks[0]();
						} else {
							ErrorHandlerSelf.returnCallback = ErrorHandlerSelf.callbacks[0];
						}*/
                	}
					
                    ErrorHandlerSelf.hide();
                    break;
                }
                case "button_2":
					ErrorHandlerSelf.buttonClickType = "button_2";
					if (ErrorHandlerSelf.callbacks && ErrorHandlerSelf.callbacks[1]) {
                    	ErrorHandlerSelf.callbacks[1]();
                	}
                    ErrorHandlerSelf.hide();
                    break;    
                default:
                    break;                
           	 }
       	}else if ('button_focus_in' == eventType){
            //voice guide start
            var voiceText = '';
            if ("button_1" == nButtonIndex){
                voiceText = option.button1Text + ', button';
            } else if ("button_2" == nButtonIndex){
                voiceText = option.button2Text + ', button';
            }
            if (voiceText != ''){
                //Volt.log('voice guide text : '+voiceText);
                //TTS.queuingPlay(voiceText);
                Global.voiceGuide(voiceText, true);
            }
            //voice guide end
        }

    },

    hide : function(option) {
        Volt.log();

		if(ErrorHandlerSelf.showFlag == true){
			//ErrorHandlerSelf.showFlag = false;
			//dimView.hide();
			
			if(messageBox) {

				Volt.log('messageBox delete');
				messageBox.hide();
				
			   	//Volt.setTimeout(ErrorHandlerSelf.destroyPopup,1);
			}

			if (ErrorHandlerSelf.timer != null) {
				Volt.clearTimeout(ErrorHandlerSelf.timer);	
				ErrorHandlerSelf.timer = null;
			}
			
			if((ErrorHandlerSelf.type == CommonDefines.PopupType.NETWORK_ERROR1) && (ErrorHandlerSelf.buttonClickType == "button_1") ) {
				Volt.log('type is CNETWORK_ERROR1');
 				Volt.isShowNetWotkSetting = true;
				//Volt.Nav.focus(null);
			} else {
				Volt.setTimeout(ErrorHandlerSelf.destroyPopup,1);
				RouterController.resumeView(RouterController.getCurrentView());	
				Volt.Nav.endModal();
			}
			
			//Volt.Nav.endModal();
		}

		//winsetDimView.hide();
    },

	destroyPopup : function(option) {
		Volt.log('destroyPopup11');

		//ErrorHandlerSelf.widget.removeChild(ErrorHandlerSelf.messageBox);

		//var messageBox = ErrorHandlerSelf.messageBox;
		if(messageBox) {
			Volt.log('destroying');

			messageBox.removeListener(ErrorHandlerSelf.messageBoxListener);
		    messageBox.destroy();
			//delete messageBox;	
			messageBox = null;
		}

		if(null != ErrorHandlerSelf.viewCallback)
        {
        	Volt.log('viewCallback not null');

			if(ErrorHandlerSelf.type == CommonDefines.PopupType.CANCEL) {
				Volt.log('type is CommonDefines.PopupType.CANCEL');
				if(ErrorHandlerSelf.buttonClickType == "button_1"){
					Volt.log('viewCallback');
 					ErrorHandlerSelf.viewCallback();
				}

			}else {
            	ErrorHandlerSelf.viewCallback();
			}
        }
		
		ErrorHandlerSelf.buttonClickType = "";
		ErrorHandlerSelf.showFlag = false;

		//dimView.hide();
    },	

});


/*
 * Define a content for MessageBox
 * @param {JSON} options - the define info for MessageBox
 */
function __getContent(options) {
    var iContent;
    switch (options.type) {
        case CommonDefines.PopupType.SAVE :
            //iContent = Volt.LANG.POPUP_SAVE_TIP;
            iContent = Volt.i18n.t('COM_ID_DPF_APPLICATION_SAVED_MSG');
            break;
        case CommonDefines.PopupType.CANCEL :
            iContent = Volt.i18n.t('TV_SID_WANT_TO_DISCARD_ALL_CHANOES');
            break;
        case CommonDefines.PopupType.MAXIMUM :
            //iContent = Volt.LANG.POPUP_MAXIMUM_TIP;
            iContent = Volt.i18n.t('COM_SID_MIX_SELECT_UP_CITIES', {A : 5});
            break;
        case CommonDefines.PopupType.MINIMUM :
            iContent = Volt.i18n.t('COM_SID_MUST_SELECT_AT_LEAST_ONE_CITY');
            break;
        case CommonDefines.PopupType.EM_FROM_CITYLIST_SERVER :
            var WeatherSettingModel = Volt.require('app/models/newson-weather-setting-model.js');
            iContent = WeatherSettingModel.get('attributes').error_msg;
            break;
        case CommonDefines.PopupType.VERSION :
            iContent = Volt.i18n.t('SID_VERSION') + " : " + CommonDefines.VERSION;
            break;
        case CommonDefines.PopupType.APP_VERSION :
            iContent = CommonDefines.Config.app_version;
            break;
        case CommonDefines.PopupType.DEVICE_INFO :
            var msg = '';
            var buffer = '';
            _.each(DeviceModel.attributes,function(value, key){
                var str = "<b>" + key.toUpperCase() + "</b>" + ' : ' + value + ' , ';
                Volt.log(str);
                msg += str;
                buffer += str;
                if( buffer.length > 60){
                    buffer = '';
                    msg += '\r';
                }
            });
            iContent = msg;
            break;
        case CommonDefines.PopupType.NETWORK_ERROR_ENTRY:
            iContent = Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK');
            break;
        case CommonDefines.PopupType.SERVER_ERROR2 :
            iContent = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER', {A : ''}) + '(<<' + options.errorCode + '>>)';
            break;
        case CommonDefines.PopupType.NETWORK_ERROR1 :
            iContent = Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK') + '(<<' + options.errorCode + '>>)';
            break;
        case CommonDefines.PopupType.SERVER_UNDER_MAINTAIN :
            iContent = Volt.i18n.t('TV_SID_MIX_SERVER_UNDER_MAITENANCE', {A : ''}) + '(<<' + options.errorCode + '>>)';
            break
        case CommonDefines.PopupType.UNEXPECTED_PROBLEM :
            iContent = Volt.i18n.t('TV_SID_MIX_UNEXPECTED_PROBLEM_OCCURRED_TRY_TURN_OFF_AGAIN', {A : options.errorCode});
            iContent = iContent.replace('(', '(<<');
            iContent = iContent.replace(')', '>>)');
            break;
        default :
            iContent = null;
    }
    return iContent;
};


/*
 * Define default timeout for MessageBox
 * @param {String} type - the type of MessageBox
 */
function __getTimeout(type) {
    var timeout;
    switch (type) {
        case CommonDefines.PopupType.CANCEL :
		case CommonDefines.PopupType.NETWORK_ERROR1 :
            timeout = CommonDefines.PopupTime.SPECIFIC_TIMEOUT;
            break;
        case CommonDefines.PopupType.NETWORK_ERROR_ENTRY:
        case CommonDefines.PopupType.DEVICE_INFO:
            timeout = 0;
            break;
        default :
            timeout = CommonDefines.PopupTime.SIMPLE_TIMEOUT;
    }
    return timeout;
}

var configXML = null;
var getConfigXML = function(){
        Volt.log('getConfigXML configXML = ' + configXML);
        var deferred = Q.defer();
        if(configXML == null) {
            var configPath = Volt.getRemoteUrl('config.xml');
            _XMLToJSON(configPath).then(function(obj){
                configXML = obj;
                deferred.resolve(obj);
            });
        } else {
            deferred.resolve(configXML);
        }
        return deferred.promise;
};

var _XMLToJSON = function(xmlFileUrl){
    Volt.log('_XMLToJSON ..... url = ' + xmlFileUrl);
    var deferred = Q.defer();
    var resourceRequest = new ResourceRequest(xmlFileUrl);
    resourceRequest.method = 'GET';
    resourceRequest.async = true;
    resourceRequest.success = function (data, textStatus, xhr) {
        _parseConfig(data)
        .then(function (obj) {
            deferred.resolve(obj);
        })
        .fail(function (err) {
            deferred.reject(err);
        });
    };
    resourceRequest.error = function (xhr, textStatus, errorStr) {
        deferred.reject(errorStr);
    };
    resourceRequest.process();
    return deferred.promise;
};

var _parseConfig = function(data){
Volt.log('_parseConfig ..... data = ' + data);
var xmlString = data.replace("\ufeff", "");
var deferred = Q.defer();
var xml = Volt.require('modules/SaxParser.js');
var obj = {};
var currentTag = null;
var parser = new xml.SaxParser(function(cb){
    cb.onEndDocument(function () {
        Volt.log("onEndDocument obj = " + JSON.stringify(obj));
        deferred.resolve(obj);
    });
    cb.onStartElementNS(function (elem) {
        if(elem == "_name" || elem == "_parent" || elem == "_value"){
            Volt.log("XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
            return;
        }
        var tag = {
            _name : elem,
            _parent : currentTag
        };
        currentTag = tag;
    });
    cb.onCharacters(function(value){
        if(currentTag && value.indexOf('\n') !== 0) {
            currentTag._value = value;
        } else {
            Volt.log("onCharacters Invalid Value:" + JSON.stringify(arguments));
        }
    });
    cb.onEndElementNS(function (elem) {
        if(elem == "_name" || elem == "_parent" || elem == "_value"){
            Volt.log("XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
            return;
        }
        if(currentTag && currentTag._parent) {
            if(currentTag._value) {
                currentTag._parent[currentTag._name] = currentTag._value;
            } else {
                currentTag._parent[currentTag._name] = currentTag;
                delete currentTag._name;
            }
            var p = currentTag._parent;
            delete currentTag._parent;
            currentTag = p;
        } else {
            obj[currentTag._name] = currentTag;
            delete currentTag._name;
            delete currentTag._parent;
        }
    });
    cb.onError(function (msg) {
        deferred.reject(msg);
    });
});
    parser.parseString(xmlString);
    return deferred.promise;
}

exports = new ErrorHandler();
