

/**
 * Include modules
 */
Volt.require('lib/volt-global.js');
Volt.require('lib/volt-nav.js');
Volt.require('app/router.js');
Volt.require('lib/magicmethods.js');
var PanelCommon = Volt.require('lib/panel-common.js');
var Backbone = Volt.require('lib/volt-backbone.js');
var BaseView = PanelCommon.BaseView;

// Require Libs
_ = Volt.require('modules/underscore.js')._;
function setTimeout(cb, interval, param) {
	return Volt.setTimeout(cb, interval, param);
}

function clearTimeout(id){
	if (id !== undefined)  {
		Volt.clearTimeout(id);
	}
}
function setInterval(cb, interval, param){
	return Volt.setInterval(cb, interval, param);
}

function clearInterval(id){
	if (id !== undefined) {
		Volt.clearInterval(id);
	}
}
function rgcConfigMouseEvent(widget)
{

   widget.addEventListener("OnMouseOver", function(targetWidget, eventData)
	{
		//widget.setFocus();
	});

	widget.addEventListener("OnMouseOut", function(targetWidget, eventData)
	{
		//widget.killFocus();
	});
}
function defaultValue(value, defaultValue)
{
	if (value === undefined)
	{
		return defaultValue;
	}
	else
	{
		return value;
	}
}
function rgcCancelAnimation ()
{
    if(this.timeOut)
    {
        clearTimeout(this.timeOut);
        this.timeOut = null;
    }
    if(this.interval)
    {
        clearInterval(this.interval);
        this.interval = null;
    }
    
    if(this.animationHandleOne){
        this.animationHandleOne.cancel();
        this.animationHandleOne = null;
    };
    
    if(this.animationHandleTwo){
        this.animationHandleTwo.cancel();
        this.animationHandleTwo = null;
    };
    
    if(this.animationHandleThree){
        this.animationHandleThree.cancel();
        this.animationHandleThree = null;
    };
    
    if(this.animationHandleFour){
        this.animationHandleFour.cancel();
        this.animationHandleFour = null;
    };
    
    if(this.animationHandleFive){
        this.animationHandleFive.cancel();
        this.animationHandleFive = null;
    };
    
    if(this.animationHandleSix){
        this.animationHandleSix.cancel();
        this.animationHandleSix = null;
    };
    
    if(this.animationHandleSeven){
        this.animationHandleSeven.cancel();
        this.animationHandleSeven = null;
    };
    
    if(this.animationHandleEight){
        this.animationHandleEight.cancel();
        this.animationHandleEight = null;
    };
    
}

function rgcKillFocus()
{
    this.container[0].show();
    if(this.canScroll && this.container[1])
    {
        this.container[1].x = 0;
        this.container[1].hide();
    }
    if(this.canScroll && this.container[2])
        this.container[2].hide();
    this.cancelAnimation();
}
var self = null;
function rgcSetFocus()
{
    self = this;
    self.cancelAnimation();//clear timer incase muti-times enter
    if(self.canScroll)
    {
        self.container[0].hide();
        self.container[1].show();
        self.container[2].hide();
        self.timeOut = setTimeout(function(){
            
            self.animationHandleOne = self.container[1].animate(self.animationOne, function(){
                var timer = self.width * 10;
                self.animationHandleTwo = self.container[1].animate('x',self.container[1].x - self.width, timer,function(){
                    self.container[1].hide();
                });
                self.container[2].x = self.width;
                self.container[2].show();
                var timer2 = self.container[2].width * 10;
                self.animationHandleThree = self.container[2].animate('x',self.container[2].x - self.container[2].width, timer2,function(){
                    self.animationHandleFour = self.container[2].animate('x',self.container[2].x - self.width,timer);
                    self.container[1].x = self.width;
                    self.container[1].show();
                    self.animationHandleFive = self.container[1].animate('x',self.container[1].x - self.container[1].width - self.width, timer2 + timer);
                });
                
                self.interval = setInterval(function(){
                    self.container[2].x = self.width;
                    self.container[2].show();
                    self.animationHandleSix = self.container[2].animate('x',self.container[2].x - self.container[2].width, timer2,function(){
                        self.animationHandleSeven = self.container[2].animate('x',self.container[2].x - self.width,timer,function(){
                            self.container[2].hide();
                        });
                        self.container[1].x = self.width;
                        self.container[1].show();
                        self.animationHandleEight = self.container[1].animate('x',self.container[1].x - self.container[1].width - self.width, timer2 + timer,function(){
                            self.container[1].hide();
                        });
                    });
                }, 2 * timer2, null);
            }, self.animationTimeOne,null);
        }, 1000, null);
    }
}
function rgcSetText(text)
{
    this.killFocus();
    this.container[0].text = text;
    if(this.container[1])
    {
        this.removeChild(this.container[1]);
        this.container[1].destroy();
        this.container[1] = null;
    }
    
    if(this.container[2] && this.canScroll)
    {
        this.removeChild(this.container[2]);
        this.container[2].destroy();
        this.container[2] = null;
    }
    this.canScroll = false;
    var testWidget = new TextWidget({
        x:0,
        y:0,
        singleLineMode:true,
        horizontalAlignment : 'left',
        verticalAlignment : 'center',
        font:this.font,
        color : {r:0,g:111,b:0,a:0},
        textColor : Volt.hexToRgb('#000000', 60),
        text:text,
        justify : true,
    });
    var width = testWidget.width;
    testWidget.destroy();
    if(width > this.width)
        this.canScroll = true;
    if(this.canScroll)
    {
        var testWidget = new TextWidget({
            x:0,
            y:0,
            singleLineMode:true,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font:this.font,
            color : {r:0,g:111,b:0,a:0},
            textColor : Volt.hexToRgb('#000000', 60),
            text:text + '          ',
            justify : true,
        });
        var width_with_blank = testWidget.width;
        testWidget.destroy();
        this.container[1] = new TextWidget({
            x:0,
            y:0,
            width:width_with_blank,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font:this.font,
            color : {r:0,g:111,b:0,a:0},
            textColor : Volt.hexToRgb('#000000', 60),
            text:text + '          ',
            justify : true,
            parent:this,
        });
        this.container[2] = new TextWidget({
            x:0,
            y:0,
            width:width_with_blank,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font:this.font,
            text:text + '          ',
            justify : true,
            color : {r:0,g:0,b:111,a:0},
            textColor : Volt.hexToRgb('#000000', 60),
            parent:this,
        });
    }
    if(this.canScroll)
    {
        this.container[1].hide();
        this.container[2].hide();
        this.animationTimeOne = (this.container[1].width -  this.width) * 10;
        this.animationOne = new Animation(this.animationTimeOne, 0);
        this.animationOne.addProperty("x", -(this.container[1].x + this.container[1].width - this.width));
    }
}

function rgcSetTextColor(color)
{
    if(color === undefined || color === null)
        return;
    if(this.container[0])
    {
        this.container[0].textColor = color;
    }
    if(this.container[1])
    {
        this.container[1].textColor = color;
    }
    if(this.container[2])
    {
        this.container[2].textColor = color;
    }
}
function ScrollableText(param)
{
	var scrollableText = new Widget();
    if(param['x'] === undefined)
        return;
	scrollableText.x = parseInt(defaultValue(param['x'],0));
    scrollableText.y = parseInt(defaultValue(param['y'],0));
    scrollableText.width = parseInt(defaultValue(param['width'],200));
    scrollableText.height = parseInt(defaultValue(param['height'] + 20,40));
    scrollableText.cropOverflow = true;
    scrollableText.parent = param['parent'];
    //scrollableText.focusable = false;
    scrollableText.color = {r:111,g:0,b:0,a:0};
    var fontSize = parseInt(param['fontSize']);
    var fontStyle = param['fontStyle'];
    var text = param['text']+'';
    var font = '';
    if(fontStyle === undefined || fontStyle === null)
        font = fontSize + 'px';
    else 
        font = fontStyle + ' ' + fontSize + 'px';
    scrollableText.font = font;
    scrollableText.container = [];
    scrollableText.timer = null;
    
    var testWidget = new TextWidget({
        x:0,
        y:0,
        singleLineMode:true,
        horizontalAlignment : 'left',
        verticalAlignment : 'center',
        font:font,
        color : {r:0,g:111,b:0,a:0},
        textColor : Volt.hexToRgb('#000000', 60),
        text:text,
        justify : true,
    });
    var width = testWidget.width;
    testWidget.destroy();
    scrollableText.container[0] = new TextWidget({
        x:0,
        y:0,
        height:scrollableText.height - 20,
        width:scrollableText.width,
        font:font,
        ellipsize:true,
        singleLineMode:false,
        color : {r:111,g:0,b:0,a:0},
        horizontalAlignment : 'left',
        verticalAlignment : 'center',
        textColor : Volt.hexToRgb('#000000', 60),
        text:text,
        parent:scrollableText,
    });
    
    scrollableText.canScroll = false;
    if(width > scrollableText.width)
        scrollableText.canScroll = true;
    if(scrollableText.canScroll)
    {
        var testWidget = new TextWidget({
            x:0,
            y:0,
            singleLineMode:true,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font:font,
            color : {r:0,g:111,b:0,a:0},
            textColor : Volt.hexToRgb('#000000', 60),
            text:text + '          ',
            justify : true,
        });
        var width_with_blank = testWidget.width;
        testWidget.destroy();
        scrollableText.container[1] = new TextWidget({
            x:0,
            y:0,
            width:width_with_blank,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font:font,
            color : {r:0,g:111,b:0,a:0},
            textColor : Volt.hexToRgb('#000000', 60),
            text:text + '          ',
            justify : true,
            parent:scrollableText,
        });
        scrollableText.container[2] = new TextWidget({
            x:0,
            y:0,
            width:width_with_blank,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            font:font,
            text:text + '          ',
            justify : true,
            color : {r:0,g:0,b:111,a:0},
            textColor : Volt.hexToRgb('#000000', 60),
            parent:scrollableText,
        });
        
    }
   
    if(scrollableText.canScroll)
    {
        scrollableText.animationTimeOne = (scrollableText.container[1].width -  scrollableText.width) * 10;
        scrollableText.animationOne = new Animation(scrollableText.animationTimeOne, 0);
        scrollableText.animationOne.addProperty("x", -(scrollableText.container[1].x + scrollableText.container[1].width - scrollableText.width));
    }
    scrollableText._configMouseEvent = rgcConfigMouseEvent;
    scrollableText.cancelAnimation = rgcCancelAnimation;
    scrollableText.setText = rgcSetText;
    scrollableText.setFocus = rgcSetFocus;
    scrollableText.killFocus = rgcKillFocus;
    scrollableText.setTextColor = rgcSetTextColor;
    scrollableText.timeOut = null;
    scrollableText.interval = null;
    scrollableText.animationHandleOne = null;
    scrollableText.animationHandleTwo = null;
    scrollableText.animationHandleThree = null;
    scrollableText.animationHandleFour = null;
    scrollableText.animationHandleFive = null;
    scrollableText.animationHandleSix = null;
    scrollableText.animationHandleSeven = null;
    scrollableText.animationHandleEight = null;
    scrollableText.container[0].show();
    
    if(scrollableText.canScroll)
    {
        scrollableText.container[1].hide();
        scrollableText.container[2].hide();
    }
    scrollableText._configMouseEvent(scrollableText);
    
	return scrollableText;
}
exports = ScrollableText;