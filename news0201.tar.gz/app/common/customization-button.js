/**
 * @author Zhu Hongjie (hj00.zhu@samsung.com)
 * @fileoverview Draw a Button
 * @date 2014/10/30(last modified date)
 * 
 * Copyright 2014 by Samsung Electronics, Inc.
 * 
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */

/**
 * Custom a button by assigned template base on GUI.
 * @function customizationButton
 * @param {Button} button - a button defined in template
 * @param {JSON} options - a json defined text of button, style json of button, the callbacks of button
 * @example
 *      1. define button in template 
 *      {
            type : 'Button',
            x : ...,
            width : ...,
            height : ...,
            color : {r:...,g:...,b:...,a:...},
            custom : {
                focusable : true
            }
        }
        2. define style in template, can defined fontSize, textColor, color, image, icon in template, 
        and all of them can define 'normal', 'focused', 'selected', 'roll-over', 'focused-roll-over', 'disabled', 'disabled-focused', 'all' status
        buttonTextStyleC : {
             fontSize : {
                 all : 32,
                 focused : 36
             },
             textColor : {
                 normal : Volt.hexToRgb('#ffffff', 60),
                 focused : Volt.hexToRgb('#464646'),
                 selected : Volt.hexToRgb('#fbba2d'),
                 disabled : Volt.hexToRgb('#ffffff', 10)
             }
         }
         3. use customizationButton to custom
         customizationButton(this.cancelButton, {
                 text : '',
                 style : CommonTemplate.buttonTextStyleC,
                 callback : onSelectCancelButton
          });
 */
var isShowLog = true;
var customizationButton = function(button, options) {
    if(button == null || button == undefined) {
        throw new Error('Error to custom Button: non button');
    }
    if (options.hasOwnProperty('style') && options.hasOwnProperty('callback')) {
        if (options.hasOwnProperty('text') && options.text != undefined) {
            Volt.log('Button -' + options.text);
            if (isShowLog) {
                print('[customization-button.js] setText({state : "all", text :' + options.text + '});');
            }
            button.setText({
                state : 'all',
                text : options.text
            });
        }

        var buttonStyle = options.style;
        if (buttonStyle) {
            if (options.hasOwnProperty('text')) {
                __setFontSize(button, buttonStyle);
                __setTextColor(button, buttonStyle);
            }
            __setBackgroudImage(button, buttonStyle);
            __setBackgroundColor(button, buttonStyle);
            __setIconImage(button, buttonStyle);
        } else {
            throw new Error('Error to custom Button: non-valid style');
        }
        var buttonListener = new ButtonListener;
        buttonListener.onButtonClicked = function(button, type) {
            Volt.log('[customization-button.js] onButtonClicked(' + button.id + ', ' + type + ');');
            if (options.callback) {
                options.callback(button);
            }
        };
        button.addListener(buttonListener);
        
        button.release = function(){
            button.removeListener(buttonListener);
            button.destroy();
            delete button;
        };
    } else {
        throw new Error('Error to custom Button: non style or non callback');
    }

};

function __setFontSize(button, style) {
    if (style.hasOwnProperty('fontSize') && button.setFontSize) {
        if ('number' == typeof style.fontSize.all) {
            if (isShowLog) {
                print('[customization-button.js] setFontSize({state : "all", size :' + style.fontSize.all + '});');
            }
            button.setFontSize({
                state : 'all',
                size : style.fontSize.all
            });
        }
        for ( var name in style.fontSize) {
            if (__isButtonStatus(name) && 'number' == typeof style.fontSize[name]) {
                if (isShowLog) {
                    print('[customization-button.js] setFontSize({state : ' + name + ', size :' + style.fontSize[name] + '});');
                }
                button.setFontSize({
                    state : name,
                    size : style.fontSize[name]
                });
            }
        }
    }
}

function __setTextColor(button, style) {
    if (style.hasOwnProperty('textColor') && button.setTextColor) {
        if ('object' == typeof style.textColor.all) {
            if (isShowLog) {
                print('[customization-button.js] setTextColor({state : "all", color :' + JSON.stringify(style.textColor.all) + '});');
            }
            button.setTextColor({
                state : 'all',
                color : style.textColor.all
            });
        }
        for ( var name in style.textColor) {
            if (__isButtonStatus(name) && 'object' == typeof style.textColor[name]) {
                if (isShowLog) {
                    print('[customization-button.js] setTextColor({state : ' + name + ', color :' + JSON.stringify(style.textColor[name]) + '});');
                }
                button.setTextColor({
                    state : name,
                    color : style.textColor[name]
                });
            }
        }
    }
}

function __setBackgroudImage(button, style) {
    if (style.hasOwnProperty('image') && button.setBackgroundImage) {
        if ('string' == typeof style.image.all) {
            if (isShowLog) {
                print('[customization-button.js] setBackgroudImage({state : "all", src :' + style.image.all + '});');
            }
            button.setBackgroundImage({
                state : 'all',
                src : style.image.all
            });
        }
        for ( var name in style.image) {
            if (__isButtonStatus(name) && 'string' == typeof style.image[name]) {
                if (isShowLog) {
                    print('[customization-button.js] setBackgroudImage({state : ' + name + ', src :' + style.image[name] + '});');
                }
                button.setBackgroundImage({
                    state : name,
                    src : style.image[name]
                });
            }
        }
    }
}

function __setBackgroundColor(button, style) {
    if (style.hasOwnProperty('color') && button.setBackgroundColor) {
        if ('object' == typeof style.color.all) {
            if (isShowLog) {
                print('[customization-button.js] setBackgroundColor({state : "all", src :' + JSON.stringify(style.color.all) + '});');
            }
            button.setBackgroundColor({
                state : 'all',
                color : style.color.all
            });
        }
        for ( var name in style.color) {
            if (__isButtonStatus(name) && 'object' == typeof style.color[name]) {
                if (isShowLog) {
                    print('[customization-button.js] setBackgroundColor({state : ' + name + ', src :' + JSON.stringify(style.color[name]) + '});');
                }
                button.setBackgroundColor({
                    state : name,
                    color : style.color[name]
                });
            }
        }
    }
}

function __setIconImage(button, style) {
    if (style.hasOwnProperty('icon') && button.setIconImage) {
        if ('string' == typeof style.icon.all) {
            if (isShowLog) {
                print('[customization-button.js] setIconImage({state : "all", src :' + style.icon.all + '});');
            }
            button.setIconImage({
                state : 'all',
                src : style.icon.all
            });
        }
        for ( var name in style.icon) {
            if (__isButtonStatus(name) && 'string' == typeof style.icon[name]) {
                if (isShowLog) {
                    print('[customization-button.js] setIconImage({state : ' + name + ', src :' + style.icon[name] + '});');
                }
                button.setIconImage({
                    state : name,
                    src : style.icon[name]
                });
            }
        }
    }
}

function __isButtonStatus(status) {
    switch (status) {
        case 'normal' :
        case 'focused' :
        case 'selected' :
        case 'roll-over' :
        case 'focused-roll-over' :
        case 'disabled' :
        case 'disabled-focused' :
//        case 'all':
            return true;
    }
    return false;
}

exports = customizationButton;