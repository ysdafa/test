var ImageWidgetEx = function(params) {
	this.cropper = new Widget(params);
	this.cropper.cropOverflow = true;
	this.cropper.color = {r:0, g:0, b:0, a: 0};
	this.cropper.pickColor = null;
	this.width = params.width;
	this.height = params.height;
	this.imageSrc = params.src;
	this.cropMode = params.cropMode;
	this.imageWidth = params.width; // �⺻��
	this.imageHeight = params.height;
	
	var $this = this;
	
	this.hiddenImage = new ImageWidget({x: -99999, y: -999999, src: this.imageSrc, parent: this.cropper, onReady: function(bLoading) {
		if(bLoading)
        {
            $this.onImageReady();
            $this.cropper.pickColor = $this.hiddenImage.getColorPicking(10);
        }
        if($this.imageSrc !== null || $this.imageSrc !== undefined)
        {
            if($this.cropper.onReady)
            {
                $this.cropper.onReady(bLoading);
            }
        }
	}});
    this.cropper.setSrc = function(src){
        $this.rgcsetSrc(src);
    };
}

ImageWidgetEx.prototype.rgcsetSrc = function (src)
{
    if(this.hiddenImage)
    {
        this.cropper.removeChild(this.hiddenImage);
        this.hiddenImage.destroy();
        this.hiddenImage = null;
    }
    this.imageSrc = src;
    var $this = this;
    this.hiddenImage = new ImageWidget({x: -99999, y: -999999, src: this.imageSrc, parent: this.cropper, onReady: function(bLoading) {
		if(bLoading)
        {
            $this.onImageReady();
            $this.cropper.pickColor = $this.hiddenImage.getColorPicking(10);
        }
        if($this.imageSrc !== null || $this.imageSrc !== undefined)
        {
            if($this.cropper.onReady)
            {
                $this.cropper.onReady(bLoading);
            }
        }
	}});
}

ImageWidgetEx.prototype.onImageReady = function() {
	this.imageWidth = parseInt(this.hiddenImage.width);
	this.imageHeight = parseInt(this.hiddenImage.height);
//    this.cropper.color = {r:0, g:0, b:0, a: 128};
	this.updateCropMode();
}

ImageWidgetEx.prototype.updateCropMode = function() {
	switch (this.cropMode) {
	case "cropCenterMiddle":
		this.cropCenterMiddle();
		break;
	case "cropCenterTop":
		this.cropCenterTop();
		break;
	case "cropCenterBottom":
		this.cropCenterBottom();
		break;
	case "cropLeftMiddle":
		this.cropLeftMiddle();
		break;
	case "cropLeftTop":
		this.cropLeftTop();
		break;
	case "cropLeftBottom":
		this.cropLeftBottom();
		break;
	case "cropRightMiddle":
		this.cropRightMiddle();
		break;
	case "cropRightTop":
		this.cropRightTop();
		break;
	case "cropRightBottom":
		this.cropRightBottom();
		break;
	case "cropCenter":
		this.cropCenter();
		break;
	case "cropLeft":
		this.cropLeft();
		break;
	case "cropRight":
		this.cropRight();
		break;
	case "cropTop":
		this.cropTop();
		break;
	case "cropBottom":
		this.cropBottom();
		break;
	}
}

ImageWidgetEx.prototype.cropCenterMiddle = function() {
	var x = (this.width - this.imageWidth) / 2;
	var y = (this.height - this.imageHeight) / 2;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}

ImageWidgetEx.prototype.cropCenterTop = function() {
	var x = (this.width - this.imageWidth) / 2;
	var y = 0;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}

ImageWidgetEx.prototype.cropCenterBottom = function() {
	var x = (this.width - this.imageWidth) / 2;
	var y = this.height - this.imageHeight;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}

ImageWidgetEx.prototype.cropLeftMiddle = function() {
	var x = 0;
	var y = (this.height - this.imageHeight) / 2;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}

ImageWidgetEx.prototype.cropLeftTop = function() {
	var x = 0;
	var y = 0;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}
ImageWidgetEx.prototype.cropLeftBottom = function() {
	var x = 0;
	var y = this.height - this.imageHeight;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}

ImageWidgetEx.prototype.cropRightMiddle = function() {
	var x = this.width - this.imageWidth;
	var y = (this.height - this.imageHeight) / 2;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}

ImageWidgetEx.prototype.cropRightTop = function() {
	var x = this.width - this.imageWidth;
	var y = 0;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}
ImageWidgetEx.prototype.cropRightBottom = function() {
	var x = this.width - this.imageWidth;
	var y = this.height - this.imageHeight;

	this.hiddenImage.x = x;
	this.hiddenImage.y = y;
}

ImageWidgetEx.prototype.cropCenter = function() {
	var x = 0;
	var y = 0;
	
	var targetWidth, targetHeight;
	if (this.imageWidth < this.imageHeight) {
		targetWidth = this.width;
		targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth;
        
	} else {
		targetHeight = this.height;
		targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
	}
	
	if(typeof(targetWidth) !== 'number') {
	    Volt.log(this.width);
	    return;
	}
	if(typeof(targetHeight) !== 'number') {
	    Volt.log(this.height);
	    return;
    }
	
	this.hiddenImage.width = targetWidth;
	this.hiddenImage.height = targetHeight;
    
    if(this.height > this.hiddenImage.height)
    {
        var scale  = this.height * 1.0 / this.hiddenImage.height;
        this.hiddenImage.width *= scale;
        this.hiddenImage.height *= scale;
    }else if(this.width > this.hiddenImage.width)
    {
        var scale  = this.width * 1.0 / this.hiddenImage.width;
        this.hiddenImage.width *= scale;
        this.hiddenImage.height *= scale;
    }
    this.hiddenImage.x = (this.width - this.hiddenImage.width) / 2;
	this.hiddenImage.y = (this.height - this.hiddenImage.height) / 2;
	//this.hiddenImage.x = 0;
	//this.hiddenImage.y = 0;
}

ImageWidgetEx.prototype.cropLeft = function() {
	var x = 0;
	var y = 0;
	
	if (this.imageWidth < this.imageHeight) {	
		var targetWidth = this.width;
		var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
	} else {
		var targetHeight = this.height;
		var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
	}
	
	this.hiddenImage.width = targetWidth;
	this.hiddenImage.height = targetHeight;
	this.hiddenImage.x = 0;
	this.hiddenImage.y = (this.height - targetHeight) / 2;
}

ImageWidgetEx.prototype.cropRight = function() {
	var x = 0;
	var y = 0;
	
	if (this.imageWidth < this.imageHeight) {	
		var targetWidth = this.width;
		var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
	} else {
		var targetHeight = this.height;
		var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
	}
	
	this.hiddenImage.width = targetWidth;
	this.hiddenImage.height = targetHeight;
	this.hiddenImage.x = this.width - targetWidth;
	this.hiddenImage.y = (this.height - targetHeight) / 2;
}

ImageWidgetEx.prototype.cropTop = function() {
	var x = 0;
	var y = 0;
	
	if (this.imageWidth < this.imageHeight) {	
		var targetWidth = this.width;
		var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
	} else {
		var targetHeight = this.height;
		var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
	}
	
	this.hiddenImage.width = targetWidth;
	this.hiddenImage.height = targetHeight;
	this.hiddenImage.x = (this.width - targetWidth) / 2;
	this.hiddenImage.y = 0;
}

ImageWidgetEx.prototype.cropBottom = function() {
	var x = 0;
	var y = 0;
	
	if (this.imageWidth < this.imageHeight) {	
		var targetWidth = this.width;
		var targetHeight = (this.imageHeight * 1.0 / this.imageWidth) * targetWidth; 
	} else {
		var targetHeight = this.height;
		var targetWidth = (this.imageWidth * 1.0 / this.imageHeight) * targetHeight;
	}
	
	this.hiddenImage.width = targetWidth;
	this.hiddenImage.height = targetHeight;
	this.hiddenImage.x = (this.width - targetWidth) / 2;
	this.hiddenImage.y = this.height - targetHeight;
}
exports = ImageWidgetEx;
