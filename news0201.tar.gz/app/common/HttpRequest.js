/**
 * @author He Mingcan (mingcan.he@samsung.com)
 * @fileoverview HttpRequest.js send cpapi init httprequest.
 * @date 2014/07/17(last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung.
 */
var voltapi = Volt.require('voltapi.js');
var isRestClient = true;
var RestRequestId = null;

var HttpRequest = {
    handleRequest : function (option) {
        if (true == isRestClient){
            if (false === voltapi.rest.isOpened()) {
                Volt.log('begin to open rest client async');
    	        voltapi.rest.initAsync(sendRequest);
    	    }else{
    	        Volt.log('rest client is already opened');
                sendRequest(true);
            }
            
            function sendRequest(isOpened){
                Volt.log('end openning rest client, result is '+isOpened);
                if (true == isOpened){
                    voltapi.rest.clearParam();
            	    voltapi.rest.clearBody();
                    
                    voltapi.rest.setSmartTVHeader(true);
                    voltapi.rest.sendAsync(option.type, option.url,
                    	function(data, status, response) {
                    		Volt.log('data is ' + data);
                    		Volt.log('url is ' + response.uri);
                    		option.success(JSON.parse(data));
                    	},
                    	function(object, status, err) {
                    		Volt.log('err is ' + err);
                    		option.error(err);
                    	},
                    	function(object, status) {
                    	    Volt.clearTimeout(timer_id);
                    		Volt.log('On complete');
                    	},
                    	function(id){
                    	    RestRequestId = id;
                            Volt.log('RestRequest readyCallback, id is '+id);
                        }
                    );
                    var timer_id = Volt.setTimeout(function(){
                        if (RestRequestId != null){
                            voltapi.rest.cancel(RestRequestId);
                        }
                    	Volt.log('request timeout!');
                    	option.error('request timeout!');
                    }, 40000);
                }else{
                    Volt.log('init rest failed!');
                    option.error('init rest failed!');
                }
            }
        } else {
            var retryTimes = 0;
            var network_request = new ResourceRequest(option.url);
            network_request.method = option.type;
            Volt.log('url is ' + option.url);
            Volt.log('type is ' + option.type);
            //network_request.async  = true;        //default: true
            network_request.success = onSuccess;
            network_request.error = onError;
            //network_request.success = option.success;
            //network_request.error = option.error;
            /*
            var aQuery = [],
            sProp,
            for (sProp in option.property) {
            network_request.addHeader(sProp, option.property[sProp]);
            }
             */
            if ('validtoken' == option.operation) {
            	Volt.log('set ValidToken headers');
            	network_request.addHeader('Token', option.property.token);
            	network_request.addHeader('DUID', option.property.duid);
            	network_request.addHeader('ModelID', option.property.model_id);
            	network_request.addHeader('CountryCode', option.property.country_code);
            } else if ('seedkey' == option.operation) {
            	Volt.log('set seedkey headers');
            	network_request.addHeader('AppKey', option.property.app_key);
            	network_request.addHeader('DUID', option.property.duid);
            	network_request.addHeader('ModelID', option.property.model_id);
            } else if ('domainlist' == option.operation) {
            	Volt.log('set domainlist headers');
            	//network_request.addHeader('CountryCode', option.property.country_code);
            	network_request.addHeader('Content-Type', option.property.content_type);
            	network_request.addHeader('Content-Length', option.property.content_length);
            	network_request.addHeader('Accept', option.property.accept);
            	//Date: '2014-05-01T15:53:18+00:00',
            	network_request.addHeader('Host', option.property.host);
            	network_request.addHeader('Cache-Control', option.property.cache_control);
            	network_request.addHeader('Accept-Encoding', option.property.accept_encoding);
            	network_request.addHeader('AToken', option.property.token);
            	network_request.addHeader('SmartTVClient', option.property.smart_tv_client);
            	network_request.addHeader('DUID', option.property.duid);
            }

            requestProcess();

            var self = this;	
            var customTime;
            function requestProcess(){
                network_request.process();
                customTime = Volt.setTimeout(function(){
                    network_request.cancel();
                    retryTimes++;
                    if (retryTimes <= 3){
                    	Volt.log('retry times: ' + retryTimes);
                    	requestProcess();
                    }else{
                    	Volt.log('request timeout!');
                    	option.error('request timeout!');
                    }		
                }, 10000);
            }

            function onSuccess(data, status, response) {
            	Volt.clearTimeout(customTime);
            	Volt.log('data is ' + data);
            	Volt.log('url is ' + response.uri);
            	option.success(JSON.parse(data));
            }

            function onError(object, status, err) {
            	Volt.clearTimeout(customTime);
            	Volt.log('err is ' + err);
            	option.error(err);
            }
        }
    }
};

exports = HttpRequest;
