var PanelCommon = Volt.require('lib/panel-common.js');
var WinsetToolTip = Volt.require("WinsetUIElement/winsetToolTip.js");
PanelCommon.mapWidget('WinsetToolTip', WinsetToolTip);


var toolTip = null;
var shownFlag = false;

var show = function(paras,template){
	//Volt.log('showToolTip .....paras = ' + JSON.stringify(paras));
	var tempWidth = Volt.getTextWidth({text : paras.text, font : "SVD Light 30px"}) + 30;
	var position = getToolTipPosition(paras,30,tempWidth);
	
	if('up' == paras.direction){
		paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Up;
	}else if('down' == paras.direction){
		paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Down;
	}else if('left' == paras.direction){
		paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Left;
	}else if('right' == paras.direction){
		paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Right;
	}
    var mustache = {
        x : position.x,
		y : position.y,
        w : tempWidth,
        style: paras.direction,
        nResoultionStyle: WinsetToolTip.ResoultionStyle.Resoultion_1080,
	    text: paras.text,
	    tailPostion:position.tailPostion,
	    parent:paras.parent
    }
    if(toolTip){
        hide();
    }
    toolTip = PanelCommon.loadTemplate(template, mustache);
    toolTip.setFont('SVD Light 30px');
    toolTip.setFontSize(30);
    toolTip.setFrameColor(64, 64, 64, 0);
    toolTip.show();
    shownFlag = true;
	Volt.setTimeout(function(){hide();}, 3000);
}

var hide = function(){
	Volt.log('hideToolTip ....');
    if(toolTip){
		toolTip.destroy();
        shownFlag = false;
        toolTip = null;
    }
}

var isShown = function(){
    return shownFlag;
}

var getToolTipPosition = function(paras,fontSize,width){	
 	//Volt.log('getToolTipPosition .....paras = ' + JSON.stringify(paras) + ',,,fontSize = ' + fontSize + ',,,width = ' + width);
	var toolTipPosition = {x:0,y:0,tailPostion:'center'};
	
	switch(paras.direction){     
		case 'down':{
			toolTipPosition.y = paras.y - fontSize - 18;			
			toolTipPosition.x = paras.x + paras.width/2 - width/2;
			break;
		}
		case 'up':{
			toolTipPosition.y = paras.y + paras.height;			
			toolTipPosition.x = paras.x + paras.width/2 - width/2;
			break;
		}
		case 'left':{
			toolTipPosition.y = paras.y - fontSize/2 + paras.height/2 + 5 ;			
			toolTipPosition.x = paras.x + paras.width + 14;
			break;
		}
		case 'right':{
			toolTipPosition.y = paras.y - fontSize/2 +paras.height/2 - 5 ;			
			toolTipPosition.x = paras.x - width - 14;
			break;
		}
	}
	
	if( toolTipPosition.x < 0 ){
        toolTipPosition.x = paras.x + paras.width / 2 - scene.width * 0.0109375;
        toolTipPosition.tailPostion = 'start';
	}else if( toolTipPosition.x + width > Volt.width ){			
        toolTipPosition.x = paras.x + paras.width / 2 + scene.width * 0.0109375 - width;
        toolTipPosition.tailPostion = 'end';
	}
	
	Volt.log('getToolTipPosition toolTipPosition = ' + JSON.stringify(toolTipPosition));	
	return toolTipPosition;  
}

exports = {
    show : show,
    hide : hide,
    isShown : isShown
};

