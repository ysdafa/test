var PanelCommon = Volt.require('lib/panel-common.js');
var Q = PanelCommon.Q;
var Backbone = Volt.require('lib/volt-backbone.js');
//var CommonInfo = Volt.require("app/common/commonInfo.js");
//Require common defines
var CommonDefines = Volt.require('app/common/commonDefines.js');
var voltapi = Volt.require('voltapi.js');
var isRestClient = true;
var RestRequestId = null;

var BaseModel = Backbone.Model.extend({	
	url:"",

	initialize : function() {

	},

	parse : function(data,status,response) {

	},
	

	fetch : function(options) {	
		var self = this;		
		var deferred =  Q.defer();
		//var url = CommonInfo.addSignature(this.url);
		var url = this.url;
        print('--------------------------------'+url);
		if ('' == url){
			self.trigger('error', {status:CommonDefines.ErrorCode.SERVER_ERROR_CODE}, 'error', null);
			deferred.resolve(false);
			return deferred.promise;
		}
        if (true == isRestClient){
            if (false === voltapi.rest.isOpened()) {
                Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& init voltapi.rest ');
    	        voltapi.rest.initAsync(sendRequest);
    	    }else{
    	        Volt.log('rest client is already opened');
                sendRequest(true);
            }

            function sendRequest(isOpened){
                Volt.log('end openning rest client, result is '+isOpened);
                if (true == isOpened){
                    Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& url - ' + url);
                    voltapi.rest.clearParam();
                    voltapi.rest.clearBody();
                    voltapi.rest.setSmartTVHeader(false);
                    voltapi.rest.setHeader('Cache-Control', '');
                    voltapi.rest.setHeader('Accept-Encoding', '');
                    voltapi.rest.sendAsync('GET', url,
                    	function(data,status,response){	
                            if(response.uri != url)
                            	return;
                            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& success - ' + url);
                            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& success - ' + data);
                            self.parse(data,status,response);
                            deferred.resolve(true);
                    	},
                    	
                    	function(object, status, exception) {  
                    	    Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& error - ' + url);
                            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& error - object.status: ' + object.status);
                            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& error - status: ' + status);
                            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& error - exception: ' + exception);
                            self.trigger('error', object, status, exception);
                            deferred.resolve(false);
                    	},
                    	
                    	function(object, status) {   
                            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& complete - ' + url +' status - ' + status);
                            Volt.clearTimeout(timer_id);
                            self.trigger('complete',object, status);
                            //deferred.resolve();
                    	},

                        function(id){
                    	    RestRequestId = id;
                            Volt.log('RestRequest readyCallback, id is '+id);
                        }
                    );
                    var timer_id = Volt.setTimeout(function(){
                        if (RestRequestId != null){
                            voltapi.rest.cancel(RestRequestId);
                        }
                    	Volt.log('request timeout!');
                    	self.trigger('error', {status:CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE}, 'error', null);
                        deferred.resolve(false);
                        self.trigger('complete', null, 'error');
                    }, 40000);
                }else{
                    self.trigger('error', {status:CommonDefines.ErrorCode.UNEXPECTED_ERROR_CODE}, 'error', null);
                    deferred.resolve(false);
                    self.trigger('complete', null, 'error');                }
            }
        } else {
    		var timer = null;
    		var retryTimes = 0;
    		Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& url - ' + url);
    		var network_request = new ResourceRequest({
    			async:true,
    			uri: url,
    			success: function(data,status,response){	
    				if(response.uri != url)
    					return;
    				Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& success - ' + url);
    				if(timer) {
    				    Volt.clearTimeout(timer);
    				}
    				self.parse(data,status,response);
    				deferred.resolve(true);
    			},
    			
    			error: function(object, status, exception) {  
    			    Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& error - ' + url);
    			    if(timer) {
                        Volt.clearTimeout(timer);
                    }
    				 self.trigger('error', object, status, exception);
    				 deferred.resolve(false);
    			},
    			
    			complete: function(object, status) {   
    			    if(status != 'success' && retryTimes < CommonDefines.NetWorkTime.RETRY_TIME) {
    			        return;
    			    }
    			    Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& complete - ' + url +' status - ' + status);
    			    if(timer) {
                        Volt.clearTimeout(timer);
                    }
    				self.trigger('complete',object, status);
    				//deferred.resolve();
    			},
    		});
    		
    		
    		function requestProcess() {
    		    network_request.process();
    		    timer = Volt.setTimeout(function() {
    		        network_request.cancel();
    		        retryTimes++;
    		        if(retryTimes <= CommonDefines.NetWorkTime.RETRY_TIME){
    		            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& retry times: ' + retryTimes);
    		            requestProcess();
    		        } else {
    		            Volt.log('&&&&&&&&&&&&&&&&&&&&&&&&& request timeout! - ' + url);
    		            self.trigger('error', null, 'error', null);
    		            deferred.resolve(false);
                    }
                }, CommonDefines.NetWorkTime.REQUEST_TIMEOUT);
            };
            requestProcess();
        }
		
        return deferred.promise;
    },	


});
exports = BaseModel;
