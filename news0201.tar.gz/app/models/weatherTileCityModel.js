
var Backbone = Volt.require('lib/volt-backbone.js');

    var WeatherTileCityModel = Backbone.Model.extend({

        defaults: {
            id: '',
            location: '',
            background_image: '',
            temp_scale: 'C',
            local_time: '',
            current_conditions: '',
            current_condition_icon: '',
            current_temp: '',
            today_high_temp: '',
            today_low_temp: '',
            brand_img_url: '',
            count: 0,
            high_temp_icon: '',
            low_temp_icon: ''
        }

    })
	
	exports = WeatherTileCityModel;


