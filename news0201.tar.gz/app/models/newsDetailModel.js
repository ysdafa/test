
var Backbone = Volt.require('lib/volt-backbone.js');
var BaseModel = Volt.require("app/models/baseModel.js");
var CPAPI = Volt.require('app/common/CPAPI.js');
var RelatedTileCollection = Volt.require("app/models/relatedTileCollection.js");
Global = Volt.require('app/common/Global.js');

var NewsDetailModel = BaseModel.extend({

	defaults: {
		attributes: {
			status: 0,
			error_msg: ''
		},
		brand_img_url: '',
		full_story_avail: '',
		full_story_txt: '',
		id: null,
		img_url: '',
		now_utc_timestamp: '',
		image_aspect_ratio: '',
		source: '',
		source_icon: '',
		source_copyright: '',
		summary: '',
		timestamp: '',
		title: '',
        //for now in china
        related_news_avail : '',
        related_news_num : 0,
	},
    relatedTileCollection : null,
    
	initialize: function(options) {
		//if(!options)
			//return;
		//this.url = options.url +"&appid=com.samsung.panels.tv.ytoday&contextid=samsung.main.2014&man=SEC&model=14_X14_BT&deviceid=SHCJYGR247DHC&swversion=T-MST14DEUC-0721.0&region=BR&language=pt&res=1920x1080&ts=1398135176&format=json";
        this.relatedTileCollection = new RelatedTileCollection();
	},
	
	setInitData: function(options){	
		if(!options)
			return;
		//this.url = options.url +'&' + serverInfo.getQueryString();
		this.url = CPAPI.getNewsDetailAPI({
			url : options.url
		});
        if(this.relatedTileCollection !== null)
        {
            this.relatedTileCollection.clear();
        }
		//this.url = serverInfo.getDomain()+'news_details?app_key=1204660113&url='+options.url;
		//this.url = options.url;
		//this.url = options.url + "&appid=com.samsung.panels.tv.ytoday&contextid=samsung.main.2014&man=SEC&model=14_X14_BT&deviceid=SHCJYGR247DHC&swversion=T-MST14DEUC-0721.0&region=BR&language=pt&res=1920x1080&ts=1398135176&format=json";
	},
    
	validate: function(attrs, options) {
        Volt.log('validate for detail view model');
        if(attrs.attributes === undefined){
            return 'attrs.attributes undefined';
        }
        if(attrs.attributes.status === undefined || attrs.attributes.status === null){
            return 'attrs.attributes.status exception';
        }
        if(attrs.attributes.status === '-1'){
            return 'detail mode get data error';
        }
    },
	parse: function(data,staus,response) {
		
		var data = JSON.parse(data);
		var oNewsDetailData = {
			attributes: data.attributes,
			brand_img_url: data.brand_img_url,
			full_story_avail: data.full_story_avail,
			full_story_txt: data.full_story_txt,
			id: data.id,
			img_url: data.img_url,
			image_aspect_ratio: data.image_aspect_ratio,
			now_utc_timestamp: data.now_utc_timestamp,
			source: data.source,
			source_icon: data.source_icon,
			source_copyright: data.source_copyright,
			summary: data.summary,
			timestamp: data.timestamp,
			title: data.title,
			stringstamp: '',
            related_news_avail : data.related_news_avail,
            related_news_num : data.related_news_num,
            timestatus:''
		};
		
		
		var temp = ((parseInt(oNewsDetailData.now_utc_timestamp) - parseInt(oNewsDetailData.timestamp)));
		
		var status = null;
		if(temp >= 0 && temp <= 59)
		{
            status = Volt.i18n.t('COM_SID_JUST_NOW');
		}else if(temp >= 60 && temp <= 119)
		{
            status = Volt.i18n.t('TV_SID_1_MINUTES_AGO');
		}else if(temp >= 120 && temp <= 3600 - 1)
		{
            status = Volt.i18n.t('SID_MIX_MINUTES_AGO_KR_BLANK', {A : Math.floor(temp/60)});
		}else if(temp >= 3600 && temp <= 7200 - 1)
		{
            status = Volt.i18n.t('TV_SID_1_HOUR_AGO');
		}else if(temp >= 3600 && temp <= 3600*24 - 1)
		{
            status = Volt.i18n.t('SID_MIX_HOURS_AGO', {A : Math.floor(temp/3600)});
		}else if(temp >= 3600*24 && temp <= 3600*48 - 1)
		{
            status = Volt.i18n.t('TV_SID_1_DAY_AGO');
		}
        else
		{
            status = Volt.i18n.t('TV_SID_MIX_DAYS_AGO', {A : Math.floor(temp/(3600*24))});
		}
		day = Math.floor(temp/24);
		hour = Math.floor(temp%24),
		sec_temp = ((parseInt(oNewsDetailData.now_utc_timestamp) - parseInt(oNewsDetailData.timestamp))%3600)
		minute = Math.floor(sec_temp / 60);
		sec = sec_temp % 60;
		oNewsDetailData.stringstamp = Global.formatTime(parseInt(oNewsDetailData.timestamp));
        oNewsDetailData.timestatus = status;
		this.set(oNewsDetailData);
        if(data.related_news_avail === 'Y')
        {
            this.relatedTileCollection.reset(data.related_tiles);
        }
		return oNewsDetailData;
	}

});

exports = new NewsDetailModel();  
