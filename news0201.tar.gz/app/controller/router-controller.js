 /** 
 * @author changkyo Seo (ck1.seo@samsung.com)
 * @fileoverview This module manages router of app.
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 * 
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 *
 * @note
 *  1) This file is JSLint Compatible
 *  2) It's bad to couple with Volt-Navigator, but we have to.
 */

/**
 * @namespace RouterController
 */

// Require Modules
var Q = Volt.require('modules/q.js');
var _ = Volt.require("modules/underscore.js")._;
var Backbone = Volt.require('lib/volt-backbone.js');
Volt.require('lib/volt-nav.js');
var Nav = Volt.Nav;

// Predefined View Type
var VIEW_TYPE_ROOT = 1,
    VIEW_TYPE_2ND_DEPTH = 2,
    VIEW_TYPE_DETAIL = 3,
    VIEW_TYPE_POPUP = 4;

// Matrix of View Switching Type
var showMatrix = {};
showMatrix[VIEW_TYPE_ROOT] = {};
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_ROOT] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_UP';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH] = {};
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_ROOT] = 'SHOW_FADE_UP';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL] = {};
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_ROOT] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_POPUP] = {};
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_ROOT] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_2ND_DEPTH] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_DETAIL] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';

var hideMatrix = {};
hideMatrix[VIEW_TYPE_ROOT] = {};
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_ROOT] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_DOWN';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_2ND_DEPTH] = {};
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_ROOT] = 'HIDE_FADE_DOWN';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_DETAIL] = {};
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_ROOT] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_POPUP] = {};
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_ROOT] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_POPUP] = 'HIDE_FADE_OUT';

/**
 * Get show type
 * @method
 * @memberof RouterController
 * @param  {enum} fromType From animation type
 * @param  {enum} toType   To animation tyle
 * @return {enum}          Return animation type
 */
function getShowType(fromType, toType) {
    return showMatrix[fromType][toType];
}

/**
 * Get hide type
 * @method
 * @memberof RouterController
 * @param  {enum} fromType From animation type
 * @param  {enum} toType   To animation tyle
 * @return {enum}          Return animation type
 */
function getHideType(fromType, toType) {
    return hideMatrix[fromType][toType];
}

/**
 * Get page transition log
 * @method
 * @memberof RouterController
 * @param  {string} sHideView View to hide
 * @param  {string} sShowView View to show
 * @param  {enum} nFromType From animation type
 * @param  {enum} nToType   To animation type
 * @return {string}           Message
 */
function getPageTransitionLog(sHideView, sShowView, nFromType, nToType) {
    var sMsg = '';
    switch (nToType) {
    case VIEW_TYPE_ROOT:
        sMsg += 'rootView';
        break;
    case VIEW_TYPE_2ND_DEPTH:
        sMsg += 'secondDepthView';
        break;
    case VIEW_TYPE_DETAIL:
        sMsg += 'detailView';
        break;
    case VIEW_TYPE_POPUP:
        sMsg += 'popupView';
        break;
    }
    sMsg += ' from ' + sHideView + '(' + getHideType(nFromType, nToType) + ')';
    sMsg += ' to ' + sShowView + '(' + getShowType(nFromType, nToType) + ')';

    return sMsg;
}

// Global Variables to Store Current View Information
/*var currentViewName = '',               // Name of Current View
    currentViewType = VIEW_TYPE_ROOT,   // Type of Current View
    
    // Cache for View
    viewCache = {};*/

var oCurrentView = {
        instance: null,
        name: '',
        type: VIEW_TYPE_ROOT
    }
    , oViewCache = {};

function CacheCtrl() {
    var cache = oViewCache;

    function initCache(viewname,param) {
        cache[viewname] = {
            name: viewname,
            instance: new (Volt.require('app/views/'+viewname+'.js')),
            sublist: {}
        };
        cache[viewname].instance.render(param);
        cache[viewname].sub = _.bind(sub, cache[viewname]);
        cache[viewname].show = _.bind(show, cache[viewname]);
        cache[viewname].hide = _.bind(hide, cache[viewname]);
    }
	

    function get(viewname,param) {
        if (!(cache[viewname] && cache[viewname].instance)) {
            initCache(viewname,param);
        }
        return cache[viewname];
    }

    function sub() {
        var subview, visible, subviews = Array.prototype.slice.call(arguments, 0);
        for (var idx=0;idx<subviews.length;idx++) {
            if (!this.sublist[subviews[idx]]) {
                subview = this.sublist[subviews[idx]] = {
                    instance: new (Volt.require('app/views/' + subviews[idx] + '.js')),
                    display: false,
                    hidden: true
                };
                subview.instance.render(this.instance);
            }
        }

        for (var key in this.sublist) {
            visible = false;
            for (var idx=0;idx<subviews.length;idx++) {
                if (key == subviews[idx]) {
                    visible = true;
                }
            }
            if (!visible) {
                this.sublist[key].display = false;
                if (!this.sublist[key].hidden) {
                    this.sublist[key].instance.hide();
                    this.sublist[key].hidden = true;
                }
            }
        }

        this.deferred.promise.then(_.bind(function(){
            for (var idx=0;idx<subviews.length;idx++) {
                subview = this.sublist[subviews[idx]];
                if (!subview.display) {
                    subview.display = true;
                    subview.hidden = false;
                    subview.instance.show();
                }
            }
        }, this));
        return this;
    }

    function show(param, animationType) {
        var deferred = Q.defer();
        var showList = [];
        if (!this.display) {
            showList.push(this.instance.show(param, animationType));
            this.display = true;
        }
        for (var key in this.sublist) {
            if (this.sublist[key].display && this.sublist[key].hidden) {
                this.sublist[key].hidden = false;
                showList.push(this.sublist[key].instance.show(param, animationType));
            }
        }
        Q.all(showList).then(function(){}).fail(function(e){ print(e); });
        deferred.resolve();
        return deferred.promise;
    }

    function hide() {
        var deferred = Q.defer();
        var hideList = [];
        hideList.push(this.instance.hide());
        this.display = false;
        for (var key in this.sublist) {
            if (this.sublist[key].display) {
                this.sublist[key].display = false;
                this.sublist[key].hidden = true;
                hideList.push(this.sublist[key].instance.hide());
            }
        }
        Q.all(hideList).then(function(){
            deferred.resolve();
        }).fail(function(e){ print(e); });
        return deferred.promise;
    }
    return {
        get: get
    }
}

var cacheCtrl = CacheCtrl();
/**
 * Change view
 * @method
 * @memberof RouterController
 * @param  {string} viewName    View name
 * @param  {object} options     Options
 * @param  {string} viewType    View type
 * @return {object}             View object
 */
/*function changeView(viewName, options, viewType) {
    // Block User Input
    Nav.block();
    
    Volt.log(getPageTransitionLog(currentViewName, viewName, currentViewType, viewType));
    
    // Create View if not created
    if (!viewCache[viewName]) {
        var View = Volt.require('app/views/' + viewName + '.js');
        var viewInst = viewCache[viewName] = new View();
        viewInst.render(options);
    }

    // Hide Current View then Show Next View
    hideView(viewCache[currentViewName], options, getHideType(currentViewType, viewType))
        .then(function () {
            showView(viewCache[viewName], options, currentViewType, viewType);
            
            // Update storage
            currentViewName = viewName;
            currentViewType = viewType;

            Nav.unblock();
        }, Nav.unblock);
}*/

function changeView(sViewName,param,type) {
    print('[router.js] ' + getPageTransitionLog(oCurrentView.name, sViewName, oCurrentView.type, type));
    if (sViewName != oCurrentView.name) {
        var before = _.clone(oCurrentView)
        oCurrentView = cacheCtrl.get(sViewName,param);
        oCurrentView.type = type;
        oCurrentView.deferred = Q.defer();
        hideView(before, param,getHideType(before.type, oCurrentView.type))
            .then(function(){
                showView(oCurrentView, param ? param : false, getShowType(before.type, oCurrentView.type), before);
                oCurrentView.deferred.resolve();
            }).fail(function(e){ print(e) });
    }
	else {
            oCurrentView.instance.update(param ? param : false,getHideType(oCurrentView.type, oCurrentView.type),getShowType(oCurrentView.type, oCurrentView.type));  
    }
    return oCurrentView;
}
/**
 * Change to popup view
 * @method
 * @memberof RouterController
 * @param  {string} viewName    View name
 * @param  {object} options     Options
 * @return {object}             View
 */
function popupView(viewName, options) {
    Volt.log(getPageTransitionLog(oCurrentView.name, viewName, oCurrentView.type, VIEW_TYPE_POPUP));
    var isHistoryBack = Backbone.history.isHistoryBack;
    if (oCurrentView.instance) {
		if(oCurrentView.type == VIEW_TYPE_POPUP){
			if(isHistoryBack||(true == options.replace)){
                hideView(oCurrentView,options,getHideType(oCurrentView.type, VIEW_TYPE_POPUP));
			}
		}
		else{
			pauseView(oCurrentView);
		}
        
    }
    var before = _.clone(oCurrentView);
    oCurrentView = cacheCtrl.get(viewName,options);
    oCurrentView.type = VIEW_TYPE_POPUP;
    showView(oCurrentView, options, getShowType(before.type, oCurrentView.type));

    return oCurrentView;
}

/**
 * Change to root view
 * @method
 * @memberof RouterController
 * @param  {string} viewName    View name
 * @param  {object} options     Options
 * @return {object}             View
 */
function rootView(viewName, options) {
    return changeView(viewName, options, VIEW_TYPE_ROOT);
}

/**
 * Change to second depth view
 * @method
 * @memberof RouterController
 * @param  {string} viewName    View name
 * @param  {object} options     Options
 * @return {object}             View
 */
function secondDepthView(viewName, options) {
    return changeView(viewName, options, VIEW_TYPE_2ND_DEPTH);
}

/**
 * Change to detail view
 * @method
 * @memberof RouterController
 * @param  {string} viewName    View name
 * @param  {object} options     Options
 * @return {object}             View
 */
function detailView(viewName, options) {
    return changeView(viewName, options, VIEW_TYPE_DETAIL);
}


/**
 * Hide view
 * @method
 * @memberof RouterController
 * @param {Object}  viewInst    View instance
 * @param {Object}  options         Options passed to View
 * @param {Enum}    hideType        Hide animationn type
 * @return promise
 */
function hideView(viewInst, options, hideType) {
    var deferred = Q.defer();

    if (!viewInst.instance) {
        deferred.resolve();
        return deferred.promise;
    }
    print('router-controller.js:hideView:hideType is '+hideType);
    viewInst.instance
        .hide(options, hideType)
        .then(function () {
            deferred.resolve();
        });

    // deferred.resolve();
    return deferred.promise;
}

/**
 * Show view
 * @method
 * @memberof RouterController
 * @param {Object}  viewInst        View instance
 * @param {Object}  options         Options passed to View
 * @param {Enum}    prevViewType    Show animationn type
 * @param {Enum}    viewType        Show animationn type
 * @return None
 */
function showView(viewCtrl, params, showType, before) {
    
    if (before && before.type == VIEW_TYPE_POPUP) {
        viewCtrl.instance.resume(params, showType);
    } else {
        viewCtrl.instance.show(params, showType);
    }

}

/**
 * Pause view
 * @method
 * @memberof RouterController
 * @param  {Object}
 */
function pauseView(viewInst, options) {
    Volt.Nav.pause();
    Volt.log('view pause');
    if (viewInst.instance && viewInst.instance.pause) {
        viewInst.instance.pause(options);
    }
}

/**
 * Resume view
 * @method
 * @memberof RouterController
 * @param  {Object}
 */
function resumeView(viewInst, options) {
    Volt.Nav.resume();
    Volt.log('view resume');
    if (viewInst.instance && viewInst.instance.resume) {
        viewInst.instance.resume(options);
    }
}

function getCurrentView(){
    return oCurrentView;
}
exports = {
    'root': rootView,
    'secondDepth': secondDepthView,
    'detail': detailView,
    'popup': popupView,
    'getCurrentView' : getCurrentView,
    'pauseView' : pauseView,
    'resumeView' : resumeView
};

