var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
var WinsetButton = Volt.require('WinsetUIElement/winsetButton.js');
var NewsonMainTemplate = {
    header : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.width,//1920,
        height : Volt.height * 0.133333,//144, //1080 * 0.133333
        color : Volt.hexToRgb('#0f1826',0),
        children : [/*{
            type : 'text',
            x : Volt.width * 0.018750,//36, // 1920 * 0.018750
            y : 0,
            height : Volt.height * 0.133333,//144, //1080 * 0.133333
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity : 102,
            //text : Volt.LANG.NEWSON_MAIN_TITLE,
            text : Volt.i18n.t('TV_SID_NEWS_ON'),
            font : '50px'
        },*/ {
            id : 'main-header-tools',
            type : 'widget',
            x : Volt.width * (1 - 2 * 0.052604) ,//1820, //1920 * (1 - 1 * 0.052083)
            y : 0,
            width : Volt.width * 0.052604 * 2 ,//200,// 1920 * 0.052083 * 2
            height : Volt.height * 0.133333,//144,//1080 * 0.133333
            color : Volt.hexToRgb('#0f1826',0),
            children : [{
                id : 'main-header-icon-setting',
                type : 'Button',
                x : (Volt.is720p)? 0 : -Volt.width*4/1920,
                y : (Volt.is720p)? 0 : -Volt.height*4/1080,
                width : Volt.width * 0.052604+((Volt.is720p)? 0 :Volt.width*8/1920),//101, // 1920 * 0.052604
                height : Volt.height * 0.133333+((Volt.is720p)? 0 :Volt.height*8/1080),//144, //1080 * 0.133333
                icon: {
                    x: (Volt.width * 0.052604 + ((Volt.is720p)? 0 : Volt.width*8/1920) - Volt.width*36/1920)/2,
                    y: (Volt.height * 0.133333 + ((Volt.is720p)? 0 : Volt.height*8/1080) - Volt.height*36/1080)/2,
                    width: Volt.width*36/1920,
                    height: Volt.height*36/1080,
                    src: ResourceMgr.ComnIconTmSetting,
                },

                custom : {
                    'focusable' : true
                },/*
                children : [{
                    type : 'widget',
                    width : 1,
                    height : Volt.height * 0.133333,//144,//1080 * 0.133333
                    color : Volt.hexToRgb('#ffffff'),
                    opacity : 25 //255 * 0.1
                }, 
                {
                    type : 'image',
                    x : 0, 
                    y : 0, 
                    width : Volt.width * 0.052604,//101, // 1920 * 0.052604
                    height : Volt.height * 0.133333,//144,//1080 * 0.133333
                    opacity : 255,
                    src : ResourceMgr.FocusGrid,//Volt.getRemoteUrl('images/1080/icon/comn_icon_tm_setting_nor.png')
                },
                {
                    type : 'Button',
                    x : Volt.width * 4 / 1920, 
                    y : Volt.height * 4 / 1080, 
                    width : Volt.width * 0.052604 - Volt.width * 8 / 1920,//101, // 1920 * 0.052604
                    height : Volt.height * 0.133333 - Volt.height * 8 / 1080,//144,//1080 * 0.133333
                    backgroundImage: {
                        x: (Volt.width * 0.052604 - Volt.width*36/1920 - Volt.width * 8 / 1920)/2,//32,// (1920 * 0.052604 - 36)/2
                        y: (Volt.height * 0.133333 - Volt.height*36/1080- Volt.height * 8 / 1080)/2,//54,// (1080 * 0.133333 - 36)/2
                        width: Volt.width*36/1920,
                        height: Volt.height*36/1080,
                        src: ResourceMgr.ComnIconTmSettingNor,
                    }
                }]*/
            }, {
                id : 'main-header-icon-close',
                type : 'Button',
                x : Volt.width * 0.052604 - ((Volt.is720p)? 0 : Volt.width*4/1920),//100, // 1920 * 0.052083
                y : ((Volt.is720p)? 0 : -Volt.height*4/1080),
                width : Volt.width * 0.052604 + ((Volt.is720p)?0:Volt.width*8/1920),//101, // 1920 * 0.052604
                height : Volt.height * 0.133333 + ((Volt.is720p)?0:Volt.height*8/1080),//144, //1080 * 0.133333
                icon: {
                    x: (Volt.width * 0.052604 + ((Volt.is720p)?0:Volt.width*8/1920) - Volt.width*36/1920)/2,
                    y: (Volt.height * 0.133333 + ((Volt.is720p)?0:Volt.height*8/1080) - Volt.height*36/1080)/2,
                    width: Volt.width*36/1920,
                    height: Volt.height*36/1080,
                    src: ResourceMgr.ComnIconTmClose,
                },
                custom : {
                    'focusable' : false
                },
            },
            {
                    type : 'widget',
                    width : 1,
                    x:0,
                    id:'main-header-icon-divide-one',
                    height : Volt.height * 0.133333,//144,//1080 * 0.133333
                    color : Volt.hexToRgb('#ffffff'),
                    opacity : 25 //255 * 0.1
            },
            {
                    type : 'widget',
                    width : 1,
                    x:1+Volt.width * 0.052604,
                    height : Volt.height * 0.133333,//144,//1080 * 0.133333
                    color : Volt.hexToRgb('#ffffff'),
                    opacity : 25 //255 * 0.1
            },
            ]
        }]
    },

    category : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.width,//1920,
        height : Volt.height * 0.066667,//72, // 1080 * 0.066667
        color : Volt.hexToRgb('#f2f2f2',0),
        children : [{
            type : 'text',
            x : 0,
            y : Volt.height * (0.005556 + 45 / 1080),//52, //1080 * (0.066667 - 0.018519) 
            width : Volt.width - Volt.width * 0.018229,//1885,//1920 - 1920 * 0.018229
            height : Volt.height * 0.018519,//20,//1080 * 0.018519
            font : "SVD Medium 13px",
            id : 'properity',
            text : '{{properity}}',
            horizontalAlignment : 'right',
            textColor : Volt.hexToRgb('#ffffff', 30)
        }, {
            type : 'image',
            x : Volt.width - Volt.width*192/1920,//1774, //1920 - 1920 * 0.018229 - 111
            y : Volt.height * 0.005556,//15, // 1080 * 0.013889
            width : Volt.width*192/1920,
            height : Volt.height*45/1080,
            id : 'cpLogo',
            src : '{{cpLogo}}'
        }, {
            
            type : 'widget',
            color : Volt.hexToRgb('#ffffff',10),
            x:0,
            y:0,
            width:Volt.width,
            height : 1,// 1080 * 0.066667
        }]
    },

    content : {
        type : 'GridListControl',
        id:'main-content-grid',
        x : 0,
        y : 0,
        width : Volt.width,//1920,
        height : Volt.height * 0.8,//864, //1080 * 0.8
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        custom : {
            'focusable' : true
        },
        color : {
            r : 0,
            g : 111,
            b : 0,
            a : 0
        }
    },
    
    error : {
        type : 'widget',
        id : 'main-content-error',
        x:0,
        y:0,
        width : Volt.width,//1920,
        height : Volt.height * 0.8,//864, //1080 * 0.8
        children : [{
                type : 'text',
                id:'main-content-error-text',
                x : 1920/2,
                y : 329,//52, //1080 * (0.066667 - 0.018519) 
                //width : 1920 - 180,//1885,//1920 - 1920 * 0.018229
                height : 48,//20,//1080 * 0.018519
                textColor : Volt.hexToRgb('#000000', 60),
                font : 'SVD Light 36px',
                text :Volt.i18n.t('TV_SID_NOT_CONNECTED_INTERNET_REQUIRES_NETWORK')+'<<404>>',
            },
            {
                type : 'WinsetButton',
                id:'main-content-error-button',
                x : (1920 - Volt.width*0.140104)/2,
                y : 329 + 45,//52, //1080 * (0.066667 - 0.018519) 
                style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text,
                buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
                text: Volt.i18n.t('UID_ONTV_TROUBLESHOT'),
                bHasBorder: true,
                width : Volt.width*0.140104,
                height : Volt.height*0.060185,
                color:Volt.hexToRgb('#ffffff',0),
                custom : {
                    focusable : false,
                }
            },
        ]
    },
   /* optionMenuForChina : {
        type : 'OptionMenu',
        x : Volt.width - Volt.width*435/1920,//1485,// 1920 - 435
        y : Volt.height * 0.133333,//144, // 1080 * 0.133333
        width : Volt.width*435/1920,
        renderNum : 1,
        loop : false,
        text : [Volt.i18n.t('TV_SID_WEATHER_SETTINGS')],
        custom : {
            'focusable' : true
        }
    },*/


	optionMenuForChina : {
	        type : 'widget',
	        x : Volt.width - Volt.width*435/1920,//1485,// 1920 - 435
	        y : Volt.height * 0.133333,//144, // 1080 * 0.133333
	        width : Volt.width*435/1920,
	        height : Volt.height *120/1080,//144,//1080 * 0.133333
	        //color:{r:0,g:0,b:0,a:0},
	        color : Volt.hexToRgb('#0f1826'),
            border:{width:0.2,color:{r:0xff,g:0xff,b:0xff,a:5}},
            opacity:250,
           	children : [
	        {
		        type : 'Button',
		        x : Volt.width*30/1920,//1485,// 1920 - 435
		        y : 0,//144, // 1080 * 0.133333
		        width : Volt.width*435/1920,
		        height : Volt.height *120/1080,//144,//1080 * 0.133333
		        color : Volt.hexToRgb('#0f1826'),
				/*text: {
	    			x:0,
	    			y:0,
	    			width: Volt.width*435/1920,
		            height: 120 ,
		            text: Volt.i18n.t('TV_SID_WEATHER_SETTINGS'),
		            font:"Samsung SVD_Medium 36px",
				    color: { r:255, g:255, b:255, a:255 * 0.8 },
		            hAlign: "left", //horizontal alignment, "center" in default
		            //vAlign: "cneter"  //vertical alignment, "middle" in default
				}, */

		    },
		    {
				type : 'widget',
    			x:Volt.width*23/1920,
    			y:Volt.height*23/1080,
    			width:Volt.width*(435 - 40)/1920,
    			height:Volt.height *70/1080,
    			color : Volt.hexToRgb('#0f1826'),
    			border:{width:2,color:{r:0xff,g:0xff,b:0xff,a:255}},
    			horizontalAlignment : "left",
    			verticalAlignment : "center",
	        },
	       {
				type : 'text',
    			x:Volt.width*30/1920,
    			y:0,
    			width: Volt.width*(435-4)/1920,
    			height: Volt.height *(120 - 4)/1080,
    			textColor:{r:255, g:255, b:255, a:255 * 0.8},
    			text: Volt.i18n.t('TV_SID_WEATHER_SETTINGS'),
    			font:"Samsung SVD_Medium 36px",
    			horizontalAlignment : "left",
    			verticalAlignment : "center",
	        }]

    },

    containerMap : {
        news_thumbnail1 : {
            width : Volt.width * 0.337500 ,//648, // 1920 * 0.337500 
            height : Volt.height * 0.500000,//540, // 1080 * 0.500000
            imageHeight : Volt.width*412/1920,
            infoHeight : Volt.height*128/1080,
            title : {
                x : Volt.width * 0.010417 + Volt.width * 3/1920,//20, // 1920 * 0.010417
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 - Volt.height * 0.001852)/2,//16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : Volt.width * (0.337500 - 2 * 0.010417) - Volt.width * 6/1920,//608,// 1920 * (0.337500 - 2 * 0.010417)
                height : 64,//64, // 1920 * 0.016667 * 2
                font : 'SVD Light 26px'
            },
            time : {
                x : Volt.width * 0.010417 + Volt.width * 3/1920,//20,// 1920 * 0.010417
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 + Volt.height * 0.001852)/2 + Volt.height*64/1080,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : Volt.width * (0.337500 - 2 * 0.010417- 0.003125 - 39 / Volt.width - 6 /Volt.width),//608,// 1920 * (0.337500 - 2 * 0.010417)
                height : 35,//30, // 1920 * 0.015625
                font : 'SVD Medium 20px'
            },
            cp_icon : {
                x : Volt.width * (0.337500 - 0.010417) - (39+6)*Volt.width/1920,//589, // 1920 * (0.337500 - 0.010417) - 39
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 + Volt.height * 0.001852)/2 + Volt.height*64/1080,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : Volt.width*39/1920,
                height : Volt.height*30/1080,
                opacity : 102
            // 255 * 0.4
            }
        },
        news_thumbnail2 : {
            width : Volt.width * 0.168750,//324, //1920 * 0.168750
            height : Volt.height * 0.300000,//324, // 1080 * 0.300000
            imageHeight : Volt.width*196/1920,
            infoHeight : Volt.height*128/1080,
            title : {
                x : Volt.width * 0.010417,//20, // 1920 * 0.010417
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 - Volt.height * 0.001852)/2,//16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : Volt.width * (0.168750 - 2 * 0.010417),//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 64,//64, // 1920 * 0.016667 * 2
                font : 'SVD Light 26px'
            },
            time : {
                x : Volt.width * 0.010417,//20,// 1920 * 0.010417
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 + Volt.height * 0.001852)/2 + Volt.height*64/1080,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : Volt.width * (0.168750 - 2 * 0.010417 - 0.003125 - 39 / Volt.width),//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 35,//30, // 1920 * 0.015625
                font : 'SVD Medium 20px'
            },
            cp_icon : {
                x : Volt.width * (0.168750 - 0.010417) - 39,//265, // 1920 * (0.168750 - 0.010417) - 39
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 + Volt.height * 0.001852)/2 + Volt.height*64/1080,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : Volt.width*39/1920,
                height : Volt.height*30/1080,
                opacity : 102
            // 255 * 0.4
            }
        },
        news_thumbnail3 : {
            width : Volt.width * 0.168750,//324, // 1920 * 0.168750
            height : Volt.height * 0.400000,//432, // 1080 * 0.400000
            imageHeight : Volt.width*304/1920,
            infoHeight : Volt.height*128/1080,
            title : {
                x : Volt.width * 0.010417,//20, // 1920 * 0.010417
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 - Volt.height * 0.001852)/2,//16, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 - 1080 * 0.001852)/2
                width : Volt.width * (0.168750 - 2 * 0.010417),//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 64,//64, // 1920 * 0.016667 * 2
                font : 'SVD Light 26px'
            },
            time : {
                x : Volt.width * 0.010417,//20,// 1920 * 0.010417
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 + Volt.height * 0.001852)/2 + Volt.height*64/1080,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : Volt.width * (0.168750 - 2 * 0.010417- 0.003125 - 39 / Volt.width),//284,// 1920 * (0.168750 - 2 * 0.010417)
                height : 35,//30, // 1920 * 0.015625
                font : 'SVD Medium 20px'
            },
            cp_icon : {
                x : Volt.width * (0.168750 - 0.010417) - 39,//265, // 1920 * (0.168750 - 0.010417) - 39
                y : (Volt.height * 0.118519 - Volt.width * 0.016667 * 2 - Volt.width * 0.015625 + Volt.height * 0.001852)/2 + Volt.height*64/1080,//82, // (1080 * 0.118519 - 1920 * 0.016667 * 2 - 1920 * 0.015625 + 1080 * 0.001852)/2 + 64
                width : Volt.width*39/1920,
                height : Volt.height*30/1080,
                opacity : 102
            // 255 * 0.4
            }
        },
        weather_thumbnail : {
            width : Volt.width * 0.337500 ,//648, // 1920 * 0.337500 
            height : Volt.height * 0.500000,//540, // 1080 * 0.500000
            imageHeight : Volt.width*412/1920,
            infoHeight : Volt.height*128/1080,
            weather_icon : {
                x : Volt.width * 0.010417,//20, //1920 * 0.010417
                y : Volt.height * 0.021296,//23, //1080 * 0.021296
                width : Volt.width*83/1920,
                height : Volt.height*83/1080
            },
            icon_h : {
                x : Volt.width * 0.337500 - Volt.width * 0.010417 - Volt.width*110/1920 - Volt.width * 0.010417 - Volt.width*50/1920 - Volt.width * 0.003125 - Volt.width*19/1920,//423,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50 - 1920 * 0.003125 - 19
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : Volt.width*19/1920,
                height : Volt.height*41/1080
            },
            icon_l : {
                x : Volt.width * 0.337500 - Volt.width * 0.010417 - Volt.width*110/1920 - Volt.width * 0.010417 - Volt.width*50/1920 - Volt.width * 0.003125 - Volt.width*19/1920,//423,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50 - 1920 * 0.003125 - 19
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2 + Volt.height * 0.037963 + Volt.height * 0.001852,//65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : Volt.width*19/1920,
                height : Volt.height*41/1080
            },
            location : {
                x : Volt.width * 0.010417 + Volt.width*83/1920 + Volt.width * 0.00625,//115,//1920 * 0.010417 + 83 + 1920 * 0.00625
                y :  (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : Volt.width * 0.156250,//300, //1920 * 0.156250
                height : Volt.height * 0.037963,//41,//1080 * 0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 26px"
            },
            conditions : {
                x : Volt.width * 0.010417 + Volt.width*83/1920 + Volt.width * 0.00625,//115,//1920 * 0.010417 + 83 + 1920 * 0.00625
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2 + Volt.height * 0.037963 + Volt.height * 0.001852,//65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : Volt.width * 0.156250,//300, //1920 * 0.156250
                height : Volt.height * 0.037963,//41,//1080 * 0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 40px"
            },
            highTemperature : {
                x : Volt.width * 0.337500 - Volt.width * 0.010417 - Volt.width*110/1920 - Volt.width * 0.010417 - Volt.width*50/1920,//448,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : Volt.width*50/1920, //special value
                height : Volt.height*0.037963,//41,//1080*0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 30px"
            },
            lowTemperature : {
                x : Volt.width* 0.337500 - Volt.width * 0.010417 - Volt.width*110/1920 - Volt.width * 0.010417 - Volt.width*50/1920,//448,// 1920 * 0.337500 - 1920 * 0.010417 - 110 - 1920 * 0.010417 - 50
                y : (Volt.height*128/1080 - Volt.height*0.037963 - Volt.height* 0.001852 - Volt.height* 0.037963)/2 + Volt.height* 0.037963 + Volt.height* 0.001852,//65, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2 + 1080 * 0.037963 + 1080 * 0.001852  
                width : Volt.width*50/1920, //special value
                height : Volt.height*0.037963,//41,//1080*0.037963
                opacity : 153, // 255 * 0.6
                font : "SVD Light 30px"
            },
            temperature : {
                x : Volt.width * 0.337500 - Volt.width * 0.01250 - Volt.width*110/1920,//518, // 1920 * 0.337500 - 1920 * 0.010417 - 110
                y : (Volt.height*128/1080 - Volt.height * 0.037963 - Volt.height * 0.001852 - Volt.height * 0.037963)/2,//22, // (128 - 1080 * 0.037963 - 1080 * 0.001852 - 1080 * 0.037963)/2
                width : Volt.width*110/1920, //special value
                height : Volt.height * 0.077778,//84,// 1080 * 0.077778
                opacity : 153, // 255 * 0.6
                font : "SVD Light 70px"
            },
            photoAttribute : {
                x : 0,//338,// 1920 * 0.337500 - 1920 * 0.005208 - 300
                y : Volt.height*128/1080 - Volt.height * 26 / 1080,//108, //128 - 1080 * 0.018519
                //width : Volt.width *300/1920,//special value
                width :Volt.width * (0.337500-0.0125),
                height : Volt.height * 26 / 1080,//20,//1080 * 0.018519
                font : "SVD Light 13px"
            },
            cp_icon : {
                x : Volt.width * 0.337500 - Volt.width*42/1920,//606, // 1920 * 0.337500 - 42
                y : Volt.height*370/1080, // 412 - 42
                width : Volt.width*42/1920,
                height : Volt.height*42/1080
            }
        }
    },

    constNum : {
        iconBgBlurWidth : 1,
        iconBgFocusWidth : 101,
        showCloseToolX:  Volt.width * (1 - 2 * 0.052604)- 4* Volt.width/1920,//1720, // 1920 * (1 - 2 * 0.052083)
        hideCloseToolX : Volt.width * (1 - 1 * 0.052604)- 4* Volt.width/1920,//1820, //1920 * (1 - 1 * 0.052083)
        showCloseOptionMenuX : Volt.width - Volt.width * 0.052604 - Volt.width*435/1920,//1384, // 1920 - 1920 * 0.052604 - 435
        hideCloseOptionMenuX : Volt.width*1485/1920// 1920 - 435
    //1920 * 0.052604
    },
};

exports = NewsonMainTemplate;
