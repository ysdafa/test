var style = null;
var resolution = null;
var NewsonLoadingTemplate = {
    /*
    loading : {
        type : 'LoadingDialog2',
        dimWidth : 1920,
        dimHeight : 1080,
        dimX : 0,
        dimY : 0,
        dimSecondX : 809.5,//(1920 - 301) / 2
        dimSecondY : 486,
        dimSecondWidth : 301,
        dimSecondHeight : 128,//58 + 60 + 10
        dimSecondColor : Volt.hexToRgb('#111111', 0),
        loadingBg1X : 0,
        loadingBg1Y : 0,
        loadingBg1Width : 301,
        loadingBg1Height : 58,
        loadingBg2X : 0,
        loadingBg2Y : 68,//0 + 58 + 10
        loadingBg2Width : 301,
        loadingBg2Height : 60,
        loadingFont : 'SVD Light 40px',
        whitePointHeight : 20,
        whitePointWidth : 20,
        imagePath : Volt.getRemoteUrl('images/1080/loading/white/'),
        interval : 66
    },*/
    loading : {
        type:'widget',
        x:0,
        y:0,
        width:Volt.width,
        height:Volt.height,
        color:Volt.hexToRgb('#000000', 60),
        parent:Volt.WinsetRoot,
        children:[{
            type:'winsetLoading',
            x : (Volt.width - Volt.width*301/1920) / 2,
			y : (Volt.height - Volt.height*58/1080) / 2,
			text: Volt.i18n.t('COM_SID_LOADING_DOT'),
            style: null,//winsetLoading.LoadingStyle.Loading_Bright_20,
            nResoultionStyle: null,//winsetLoading.ResoultionStyle.Resoultion_1080
            custom : {
                multilingual : {
                    SID : 'COM_SID_LOADING_DOT'
                },
            }
        }]
    },
    loading2 : {
        type : 'LoadingDialog2',
        dimWidth : 1920,
        dimHeight : 1080,
        dimX : 0,
        dimY : 0,
        dimSecondX : 1566,//1920 - 340 - 14
        dimSecondY : 17,
        dimSecondWidth : 340,
        dimSecondHeight : 126,
        dimSecondColor : Volt.hexToRgb('#0f1826', 85),
        loadingBg1X : 67,//(340 - 206) / 2
        loadingBg1Y : 19,
        loadingBg1Width : 206,
        loadingBg1Height : 40,
        loadingBg2X : 67,//(340 - 206) / 2
        loadingBg2Y : 65,//19 + 40 + 6
        loadingBg2Width : 206,
        loadingBg2Height : 50,
        loadingFont : 'SVD Light 34px',
        whitePointHeight : 14,
        whitePointWidth : 14,
        imagePath : Volt.getRemoteUrl('images/1080/loading/white/'),
        interval : 66
    }
};

exports = NewsonLoadingTemplate;