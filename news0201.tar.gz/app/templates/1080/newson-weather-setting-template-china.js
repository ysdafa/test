var CommonTemplate = Volt.require('app/templates/1080/newson-common-template.js');
var ScreenTemplate = Volt.require('app/templates/1080/newson-screen-template.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
//var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetButton = Volt.require('WinsetUIElement/winsetButton.js');

var THUMB_STYLE_BLANK = 0x00;
var THUMB_STYLE_IMAGE = 0x01;
var THUMB_STYLE_ICON = 0x02;
var THUMB_STYLE_TEXT = 0x04;
var THUMB_STYLE_PROGRESSBAR = 0x08;
var THUMB_STYLE_CHECKBOX = 0x10;
var THUMB_STYLE_INFO = 0x20;
var CurTemplate = {
    title : {
        height : Volt.height * 0.1333,//144,// 1080 * 0.1333
        text : {
            x : Volt.width * 0.018750,//40, // 1920 * 0.02083
            y : Volt.height * 0.042593,//46, // 1080 * 0.042593
            width : Volt.width * 0.944792,//1814, // 1920 * 0.944792
            height : Volt.height*65/1080
        //1080 * 0.050000
        },
        button : {
            x : (Volt.width * 0.075000 - Volt.width*64/1920)/2,//40, // (1920 * 0.075000 - 64)/2
            y : (Volt.height * 0.133333 - Volt.height*64/1080)/2,//40, // (1080 * 0.133333 - 64)/2
            width : Volt.width*64/1920,
            height : Volt.height*64/1080
        }
    },

    container : {
        height : Volt.height * (1-0.1333),//936,// 1080 * (1-0.1333)
        tip : {
            x : Volt.width * 0.034375,//66, // 1920 * 0.034375
            y : Volt.height * (0.042593 + 0.050000 + 0.077778) - Volt.height * 0.1333,//40, // 1080 * (0.042593 + 0.050000 + 0.077778) - 1080 * 0.1333
            width : Volt.width * 0.931250,//1788,// 1920 * 0.931250
            height : Volt.height * (0.035185 * 2 + 0.109259 + 0.031481),//230, //1080 * (0.035185 * 2 + 0.109259 + 0.031481)
            tip1And2 : {
                height : Volt.height * 0.035185,//38, //1080 * 0.035185
            },
            tip3 : {
                y : Volt.height * (0.035185 * 2 + 0.109259),//194, //1080 * (0.035185 * 2 + 0.109259)
                height : Volt.height * 0.031481,//34, // 1080 * 0.031481
            }
        },
        province : {
            y : Volt.height * (0.398148 - 0.1333) ,//286, // 1080 * (0.398148 - 0.1333) 
            width : Volt.width * 0.183333 * 5,//1760, //1920 * 0.183333 * 5
            height : Volt.height * 0.068519,//74, // 1080 * 0.068519
            list : {
                x : Volt.width * 0.041667,//80, // 1920 * 0.041667
                item : {
                    width : Volt.width * 0.183333,//352, //1920 * 0.183333
                }
            },
            division : {
                x : Volt.width * 0.183333 - Volt.width * 0.000521,//351, // 1920 * 0.183333 - 1920 * 0.000521
                y : Volt.height * (0.419444 - 0.398148),//23, //1080 * (0.419444 - 0.398148) 
                width : Volt.width * 0.000521,//1,// 1920 * 0.000521
                height : Volt.height * 0.025000,//27// 1080 * 0.025000
            },
        },
        hr : {
            y : Volt.height* (0.466667 - 0.1333),//360, //1080 * (0.466667 - 0.1333)
            height : Volt.height * 0.001852,//2, // 1080 * 0.001852
        },
        city : {
            y : Volt.height * (0.468519 - 0.1333),//362, // 1080 * (0.468519 - 0.1333)
            width : Volt.width * 0.230208 * 4,//1768, //1920 * 0.230208 * 4
            height : Volt.height * 0.094444 * 4,//408, // 1080 * 0.094444 * 4
            list : {
                x : Volt.width * 0.052083,//100, // 1920 * 0.052083
                item : {
                    width : Volt.width  * 0.230208,//442, //1920 * 0.230208
                    height : Volt.height * 0.094444,//102, //1080 * 0.094444
                    box : {
                        y : Volt.height * (0.497222 - 0.468519),//31, // 1080 * (0.497222 - 0.468519)
                        width : Volt.width*40/1920,
                        height : Volt.height*40/1080,
                    },
                    text : {
                        x : Volt.width * (0.080208 - 0.052083),//54, // 1920 * (0.080208 - 0.052083)
                        width : Volt.width * 0.177083,//340, //1920 * 0.177083
                    },
                    bg : {
                        width : Volt.width * 0.213542,//410, //1920 * 0.213542
                    }
                }
            },
            division : {
                x : 0,
                y : Volt.height * 0.094444 - Volt.height * 0.000926,//101,//1080 * 0.094444 - 1080 * 0.000926
                width : Volt.width * 0.906250,//1740, // 1920 * 0.906250
                height : 1 // 1080 * 0.000926
            }
        },
        button : {
            y : Volt.height * ( 1 - 0.047222 - 0.060185) - Volt.height * 0.1333,//820, //1080 * ( 1 - 0.047222 - 0.060185) - 1080 * 0.1333
            width : Volt.width * 0.140625,//270, // 1920 * 0.140625
            height : Volt.height * 0.060185,//65, // 1080 * 0.060185
            b1 : {
                x : Volt.width/2 -  Volt.width * 0.012500/2 - Volt.width * 0.140625,//678, // 1920  / 2 -  1920 * 0.012500 / 2 - 1920 * 0.140625
            },
            b2 : {
                x : Volt.width/2 +  Volt.width * 0.012500/2,//972, // 1920  / 2 +  1920 * 0.012500 / 2
            }
        }
    }
};

var WeatherSettingTemplate = {
    main : {
        parent : Volt.WinsetRoot,
        type : 'widget',
        width : ScreenTemplate.width,
        height : ScreenTemplate.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-title-area',
            type : 'WinsetBackground',
            width : ScreenTemplate.width,
            height : CurTemplate.title.height,
            bgHighContrastColor:Volt.hexToRgb('#000000'),
            bgColor:Volt.hexToRgb('#1F2B3D'),
            //color : Volt.hexToRgb('#1F2B3D')
        }, {
            id : 'newson-weather-setting-container-area',
            type : 'WinsetBackground',
            y : CurTemplate.title.height,
            width : ScreenTemplate.width,
            height : CurTemplate.container.height,
            bgHighContrastColor:Volt.hexToRgb('#000000'),
            bgColor:Volt.hexToRgb('#233146'),
            //color : Volt.hexToRgb('#233146')
        }, {
            id : 'newson-weather-setting-popup-container',
            type : 'widget',
            width : ScreenTemplate.width,
            height : ScreenTemplate.height,
            color : Volt.hexToRgb('#000000', 0)
        }]
    },

    titleArea : {
        type : 'WinsetBackground',
        width : ScreenTemplate.width,
        height : CurTemplate.title.height,
        bgHighContrastColor:Volt.hexToRgb('#ffffff',6),
        bgColor:ScreenTemplate.transparentColor,
        //color : 
        children : [{
            id : 'newson-weather-setting-title-text',
            type : 'text',
            x : CurTemplate.title.text.x,
            y : CurTemplate.title.text.y,
            x_cursor : CurTemplate.title.text.x + Volt.width*0.052083,
            width : CurTemplate.title.text.width,
            height : CurTemplate.title.text.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 40),
            text : Volt.i18n.t('TV_SID_WEATHER_SETTINGS'),
            font : 'SVD Light 50px',
            custom : {
                multilingual : {
                    SID : 'TV_SID_WEATHER_SETTINGS'
                },
            }
        }, {
            id : 'newson-weather-setting-return-button',
            type:'widget',
            x:0,
            y:0,
            width:Volt.width*0.052083,
            height:Volt.height*0.13333,
            color : Volt.hexToRgb('#000000', 0),
            children:[{
                type : 'image',
                x : (Volt.width * 0.052083 - Volt.width*42/1920)/2,//40, // (1920 * 0.075000 - 64)/2
                y : (Volt.height * 0.13333 - Volt.height*42/1080)/2,//40, // (1080 * 0.133333 - 64)/2
                width : Volt.width*42/1920,//64,
                height : Volt.height*42/1080,//64,
                opacity : 255*0.6,
                color : ScreenTemplate.transparentColor
            },{
                type : 'widget',
                x : Volt.width*0.052083 - 1,//40, // (1920 * 0.075000 - 64)/2
                y : 0,//40, // (1080 * 0.133333 - 64)/2
                width : 1,//64,
                height : Volt.height*0.13333,//64,
                color : Volt.hexToRgb('#ffffff', 25)
            }
            ]
        }, {
            id : 'newson-weather-setting-close-button',
            type:'widget',
            x:Volt.width*(1 - 0.052083),
            y:0,
            width:Volt.width*0.052083,
            height:Volt.height*0.13333,
            color : Volt.hexToRgb('#000000', 0),
            children:[{
                type : 'image',
                x : (Volt.width * 0.052083 - Volt.width*42/1920)/2,//40, // (1920 * 0.075000 - 64)/2
                y : (Volt.height * 0.13333 - Volt.height*42/1080)/2,//40, // (1080 * 0.133333 - 64)/2
                width : Volt.width*42/1920,//64,
                height : Volt.height*42/1080,//64,
                opacity : 255*0.6,
                color : ScreenTemplate.transparentColor
            }
            ,{
                type : 'widget',
                x : 1,//40, // (1920 * 0.075000 - 64)/2
                y : 0,//40, // (1080 * 0.133333 - 64)/2
                width : 1,//64,
                height : Volt.height*0.13333,//64,
                color : Volt.hexToRgb('#ffffff', 25)
            }]
        }]
    },

    containerArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-tip-area',
            type : 'widget',
            x : CurTemplate.container.tip.x,
            y : CurTemplate.container.tip.y,
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.height,
            color : ScreenTemplate.transparentColor
        }, {
            id : 'newson-weather-setting-province-content-area',
            type : 'widget',
            y : CurTemplate.container.province.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.province.height,
            color : ScreenTemplate.transparentColor,
            //add by yipeng.zhu 2014.12.04
            children : [{
                type:'image',
                x:Volt.width * 0.00625,
                y:(CurTemplate.container.province.height - (Volt.height * 38 / 1080) )/2,
                width:Volt.width * 20 / 1920,
                height:Volt.height * 38 / 1080,
                src:ResourceMgr.SettingArrowLeft,
                opacity:255*0.5,
                //color:{r:111,g:111,b:111,a:255},
            },{
                type:'image',
                x:Volt.width * (1-0.00625 - 38 / 1920),
                y:(CurTemplate.container.province.height - Volt.height * 38 / 1080 )/2,
                width:Volt.width * 20 / 1920,
                height:Volt.height * 38 / 1080,
                src:ResourceMgr.SettingArrowRight,
                opacity:255*0.5
                //color:{r:111,g:111,b:111,a:255},
            }]
            //end of yipeng.zhu add
        }, {
            id : 'newson-weather-setting-division-hr',
            type : 'widget',
            y : CurTemplate.container.hr.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.hr.height,
            color : Volt.hexToRgb('#ffffff', 10)
        }, {
            id : 'newson-weather-setting-city-content-area',
            type : 'widget',
            y : CurTemplate.container.city.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.city.height,
            color : ScreenTemplate.transparentColor,
            //add by yipeng.zhu 2014.12.04
            children : [{
                type:'image',
                x:Volt.width * 0.017708,
                y:(CurTemplate.container.city.height - (Volt.height * 50 / 1080) )/2,
                width:Volt.width * 26 / 1920,
                height:Volt.height * 50 / 1080,
                src:ResourceMgr.SettingArrowLeft,
                opacity:255*0.5,
            },{
                type:'image',
                x:Volt.width * (1-0.017708 - 26 / 1920),
                y:(CurTemplate.container.city.height - Volt.height * 50 / 1080 )/2,
                width:Volt.width * 26 / 1920,
                height:Volt.height * 50 / 1080,
                src:ResourceMgr.SettingArrowRight,
                opacity:255*0.5
            },{
                type : 'widget',
                x: Volt.width * 0.052083,
                y : Volt.height * 0.09444,
                width : Volt.width * (1 - 2 * 0.052083),
                height : Volt.height * 0.000926,
                color : Volt.hexToRgb('#ffffff', 5),
                opacity:0,
            },{
                type : 'widget',
                x: Volt.width * 0.052083,
                y : Volt.height * 0.09444*2,
                width : Volt.width * (1 - 2 * 0.052083),
                height : Volt.height * 0.000926,
                color : Volt.hexToRgb('#ffffff', 5),
                opacity:0,
            },{
                type : 'widget',
                x: Volt.width * 0.052083,
                y : Volt.height * 0.09444*3,
                width : Volt.width * (1 - 2 * 0.052083),
                height : Volt.height * 0.000926,
                color : Volt.hexToRgb('#ffffff', 5),
                opacity:0,
            },{
                type : 'widget',
                x: Volt.width * 0.052083,
                y : Volt.height * 0.09444*4,
                width : Volt.width * (1 - 2 * 0.052083),
                height : Volt.height * 0.000926,
                color : Volt.hexToRgb('#ffffff', 5),
                opacity:0,
            }]
            //end of yipeng.zhu add
        }, {
            id : 'newson-weather-setting-button-area',
            type : 'widget',
            y : CurTemplate.container.button.y,
            width : ScreenTemplate.width,
            height : CurTemplate.container.button.height,
            color : ScreenTemplate.transparentColor
        }]
    },

    tipArea : {
        type : 'widget',
        width : CurTemplate.container.tip.width,
        height : CurTemplate.container.tip.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            type : 'text',
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.tip1And2.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 60),
            text : Volt.i18n.t('TV_SID_SELECT_CITIES_WOULD_LIKE_TO_FOLLOW'),
            font : 'SVD Light 30px',
            custom : {
                multilingual : {
                    SID : 'TV_SID_SELECT_CITIES_WOULD_LIKE_TO_FOLLOW'
                },
            }
        }, {
            type : 'text',
            y : CurTemplate.container.tip.tip1And2.height,
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.tip1And2.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 60),
            //text : Volt.LANG.WEATHER_SETTING_TIP_2,
            text : Volt.i18n.t('COM_SID_MIX_SELECT_UP_CITIES', {A : 5}),
            font : 'SVD Light 30px',
            custom : {
                multilingual : {
                    SID : 'COM_SID_MIX_SELECT_UP_CITIES',
                    replace_value : 5
                },
            }
        }, {
            id : 'newson-weather-setting-selected-count',
            type : 'text',
            y : CurTemplate.container.tip.tip3.y,
            width : CurTemplate.container.tip.width,
            height : CurTemplate.container.tip.tip3.height,
            horizontalAlignment : 'left',
            verticalAlignment : 'top',
            textColor : Volt.hexToRgb('#ffffff', 60),
            text : '',
            font : 'SVD Light 30px'
        }]
    },

    provinceContentArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.province.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-province-list',
            type : 'widget',
            x : CurTemplate.container.province.list.x,
            width : CurTemplate.container.province.width,
            height : CurTemplate.container.province.height,
            color : ScreenTemplate.transparentColor
        }]
    },

    cityContentArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.city.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-city-list',
            type : 'widget',
            x : CurTemplate.container.city.list.x,
            width : CurTemplate.container.city.width,
            height : CurTemplate.container.city.height,
            color : ScreenTemplate.transparentColor
        }]
    },

    buttonArea : {
        type : 'widget',
        width : ScreenTemplate.width,
        height : CurTemplate.container.button.height,
        color : ScreenTemplate.transparentColor,
        children : [{
            id : 'newson-weather-setting-save-button',
            type : 'WinsetButton',
            style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            text: Volt.i18n.t('SID_DONE'),
            bHasBorder: true,
            x : CurTemplate.container.button.b1.x,
            y : 0,
            width : CurTemplate.container.button.width,
            height : CurTemplate.container.button.height,
            //color : ScreenTemplate.transparentColor,
            custom : {
                focusable : true
            }
        }, {
            id : 'newson-weather-setting-cancel-button',
            type : 'WinsetButton',
            style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            text: Volt.i18n.t('SID_CANCEL'),
            bHasBorder: true,
            x : CurTemplate.container.button.b2.x,
            y:0,
            width : CurTemplate.container.button.width,
            height : CurTemplate.container.button.height,
            color : ScreenTemplate.transparentColor,
            custom : {
                focusable : true
            }
        }]
    },
    /*
    provinceList : {
        type : 'GridListControl',
        parent : null,
        width : CurTemplate.container.province.width,
        height : CurTemplate.container.province.height,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        focusHideWhenCursorShow:true,
        custom : {
            focusable : true
        }
    },
    */
    provinceList : {
        type : 'CategoryTab',
        parent : null,
        id:'provinceList',
        width : CurTemplate.container.province.width,
        height : CurTemplate.container.province.height+((Volt.is720p)? 0 :Volt.width*4/1920),
        color : ScreenTemplate.transparentColor,
        //color : {r:111,g:111,b:111,a:100},
        setTabSpacing:0,
        enableLooping : true,
        tabFont: 'SVD Light 35px',
        unselectedFontSize: 35,
        selectedFontSize: 38,
        highlightedFontSize : 38,
        focusFrameImagePath: ResourceMgr.FocusGrid,
        spliterSize: {
            w: 2,
            h: CurTemplate.container.province.division.height,
        },
        enableLooping:true,
        margin: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
        },
        /*
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        focusHideWhenCursorShow:true,*/
        /*
        margin: {
            top: 0,
            bottom: 0,
            left: Volt.width * 0.005208,
            right: Volt.width * 0.005208
        },*/
        custom : {
            focusable : true
        }
    },
    
    cityList : {
        type : 'GridListControl',
        parent : null,
        id:'cityList',
        width : CurTemplate.container.city.width,
        height : CurTemplate.container.city.height,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0,
        focusHideWhenCursorShow: true,
        focusMargin:{left:0, right:40, top:0, bottom:0},
        custom : {
            focusable : true
        }
    },
    
    provinceItem : {
        type : 'widget',
        width : CurTemplate.container.province.list.item.width,
        height : CurTemplate.container.province.height,
        color : ScreenTemplate.transparentColor,
        ID:'ProvinceItem',
        children :[{
            type:'Thumbnail',
            visibleStyles: THUMB_STYLE_INFO,
            width : CurTemplate.container.province.list.item.width,
            height : CurTemplate.container.province.height,
            color : ScreenTemplate.transparentColor,
            information:{
                x: 0,
                y: 0,
                width: CurTemplate.container.province.list.item.width,
                height: CurTemplate.container.province.height,
                color : ScreenTemplate.transparentColor,
                highContrast: {
                    color: Volt.hexToRgb('#FFFFFF', 0),
                    highlightTextColor: Volt.hexToRgb('#FFFFFF', 100),
                },
                text1:{
                    width : CurTemplate.container.province.list.item.width,
                    height : CurTemplate.container.province.height,
                    font : 'SVD Light 35px',
                    textColor : Volt.hexToRgb('#ffffff', 80),
                    horizontalAlignment : 'center',
                    verticalAlignment : 'center',
                    enlarge: {
                        factor: 1.2,
                        anchorPoint: "top-left",
                    },
                    text : '{{ provinceName }}',
                },
            }
        },
        {
            ID : 'division',
            type : 'widget',
            x : CurTemplate.container.province.division.x,
            y : CurTemplate.container.province.division.y,
            width : CurTemplate.container.province.division.width,
            height : CurTemplate.container.province.division.height,
            color : Volt.hexToRgb('#ffffff', 10)
        }]
    },

    cityItem : {
        type:'Thumbnail',
        visibleStyles: THUMB_STYLE_INFO,
        width : CurTemplate.container.city.list.item.width,
        height : CurTemplate.container.city.list.item.height,
        color : ScreenTemplate.transparentColor,
        information:{
            x: 0,
            y: 0,
            width: CurTemplate.container.city.list.item.width - (Volt.width * 40/1080),
            height: CurTemplate.container.city.list.item.height,
            color : ScreenTemplate.transparentColor,
            highContrast: {
                color: Volt.hexToRgb('#FFFFFF', 0),
                highlightTextColor: Volt.hexToRgb('#FFFFFF', 100),
            },
            icon1:
            {   
                ID : 'CheckBox',
                x: 10, 
                y : CurTemplate.container.city.list.item.box.y, 
                width : CurTemplate.container.city.list.item.box.width,
                height : CurTemplate.container.city.list.item.box.height,
                src : ResourceMgr.PopupCheckBox,//Volt.getRemoteUrl('images/1080/checkbox/popup_check_box.png'),
            },
            icon2:
            {   
                ID : 'CheckIcon',
                x: 10, 
                y : CurTemplate.container.city.list.item.box.y, 
                width : CurTemplate.container.city.list.item.box.width,
                height : CurTemplate.container.city.list.item.box.height,
                src : ResourceMgr.PopupCheckIconNormal,//Volt.getRemoteUrl('images/1080/checkbox/popup_check_icon_n.png'),
            },
            text1:{
                x : CurTemplate.container.city.list.item.text.x+10,
                width : CurTemplate.container.city.list.item.text.width,
                height : CurTemplate.container.city.list.item.height,
                text : '{{ cityName }}',
                textColor : Volt.hexToRgb('#ffffff', 80),
                verticalAlignment : 'center',
                enlarge: {
                    factor: 1.2,
                    anchorPoint: "top-left",
                },
                font : 'SVD Light 35px'
            },
        }
    }

};

exports = WeatherSettingTemplate;
