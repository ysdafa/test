var NewsonDetailTemplate = {
    verticallist : {
        type:'SingleLineListControl',
        x : 0,
        y : 0,
        //rows : 20,
        width : Volt.width * 0.168750,//324, // 1920 * 0.168750
        height : Volt.height,//1080,
        //itemWidth : 324, // 1920 * 0.168750
        //itemHeight : 292, // 196 + 1280 * 0.088889
        //nAniTimeMove : 300,
	scrollType: "Vertical",
        custom : {
            'focusable' : true
        },
        parent : Volt.WinsetRoot
    },

    arryItem : {
        width : 1,
        height : 1,
        id : null
    },

    constNum : {
        infoSpace : Volt.width * 0.006250,//12, // 1920 * 0.006250, space between source and pressTime
        bodyLineHeight : Volt.height * 0.046296,//50, //1080 * 0.046296
        lineSpace : Volt.height * 0.025926,//28 , //1080 * 0.025926
        contentHeight : Volt.height * 550 / 1080,//scene.height *(0.572222-0.046296),//600, // 1080 * 0.572222 - (1080 * 0.572222 % (1080 * 0.046296)), the height of contentAppend
        new_thumbnail4Height : Volt.height * 0.088889,//96, // 1080 * 0.088889
        focuBW : 4, // the border width of arrow when focused
        blurBW : 1, // the border width of arrow when blurred
        videoFocusBW : 5, // the border width of video when focused
        videoBlurBW : 0 // the border width of video when blurred
    }
};

exports = NewsonDetailTemplate;