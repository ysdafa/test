var NewsonMainTemplate = Volt.require('app/templates/1080/newson-main-template.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
var THUMB_STYLE_BLANK = 0x00;
var THUMB_STYLE_IMAGE = 0x01;
var THUMB_STYLE_ICON = 0x02;
var THUMB_STYLE_TEXT = 0x04;
var THUMB_STYLE_PROGRESSBAR = 0x08;
var THUMB_STYLE_CHECKBOX = 0x10;
var THUMB_STYLE_INFO = 0x20;

var MainDetailTemplate = {
    container_news_thumbnail1 : {
        type : 'image',
        x : 0,
        y : 0,
        width : NewsonMainTemplate.containerMap.news_thumbnail1.width,
        height : NewsonMainTemplate.containerMap.news_thumbnail1.height,
        src : ResourceMgr.IconBlankThumbnail,
        fillMode : 'center',
        color : Volt.hexToRgb('#d4d4d4', 100),
        children : [{
            type : 'widget',
            x : NewsonMainTemplate.containerMap.news_thumbnail1.width - 1,
            y : 0,
            width : 1,
            height : NewsonMainTemplate.containerMap.news_thumbnail1.height,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'widget',
            x : 0,
            y : NewsonMainTemplate.containerMap.news_thumbnail1.height - 1,
            width : NewsonMainTemplate.containerMap.news_thumbnail1.width,
            height : 1,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'Thumbnail',
            visibleStyles : (THUMB_STYLE_IMAGE | THUMB_STYLE_INFO),
            width : NewsonMainTemplate.containerMap.news_thumbnail1.width,
            height : NewsonMainTemplate.containerMap.news_thumbnail1.height,
            image : {
                src : '{{src}}',
                width : NewsonMainTemplate.containerMap.news_thumbnail1.width,
                height : NewsonMainTemplate.containerMap.news_thumbnail1.imageHeight,
                fillMode:"center-crop",
                enlarge: {
                    factor: 1.1,
                    anchorPoint: "center",
                },
            },
            information : {
                x : 0,
                y : NewsonMainTemplate.containerMap.news_thumbnail1.imageHeight,
                width : NewsonMainTemplate.containerMap.news_thumbnail1.width,
                height : NewsonMainTemplate.containerMap.news_thumbnail1.infoHeight,
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "bottom",
                },
                icon1 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail1.cp_icon.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail1.cp_icon.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail1.cp_icon.width,
                    height : NewsonMainTemplate.containerMap.news_thumbnail1.cp_icon.height,
                    opacity : NewsonMainTemplate.containerMap.news_thumbnail1.cp_icon.opacity,
                    fillMode : "stretch",
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    src : ResourceMgr.NewsCpIconSinaW
                },
                text1 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail1.title.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail1.title.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail1.title.width,
                    height : NewsonMainTemplate.containerMap.news_thumbnail1.title.height,
                    font : NewsonMainTemplate.containerMap.news_thumbnail1.title.font,
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    text : '{{title}}',
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    verticalAlignment : 'top',
                    horizontalAlignment : "left",
                    singleLineMode : false
                },
                text2 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail1.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail1.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail1.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail1.time.height,
                    text : '{{sourcecp}}',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail1.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },

				text3 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail1.time.x+300,
                    y : NewsonMainTemplate.containerMap.news_thumbnail1.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail1.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail1.time.height,
                    text : '-',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail1.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },

				text4 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail1.time.x+320,
                    y : NewsonMainTemplate.containerMap.news_thumbnail1.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail1.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail1.time.height,
                    text : '{{time}}',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail1.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },

                text5 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail1.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail1.time.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail1.time.width,
                    //width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail1.time.height,
                    text : '',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail1.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },
            }
        }]
    },
    container_weather_thumbnail : {
        type : 'image',
        x : 0,
        y : 0,
        width : NewsonMainTemplate.containerMap.weather_thumbnail.width,
        height : NewsonMainTemplate.containerMap.weather_thumbnail.height,
        //src:'{{src}}',
        fillMode : 'center',
        src : ResourceMgr.IconBlankThumbnail,
        color : Volt.hexToRgb('#d4d4d4', 100),
        children : [{
            type : 'widget',
            x : NewsonMainTemplate.containerMap.weather_thumbnail.width - 1,
            y : 0,
            width : 1,
            height : NewsonMainTemplate.containerMap.weather_thumbnail.height,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'widget',
            x : 0,
            y : NewsonMainTemplate.containerMap.weather_thumbnail.height - 1,
            width : NewsonMainTemplate.containerMap.weather_thumbnail.width,
            height : 1,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'Thumbnail',
            width : NewsonMainTemplate.containerMap.weather_thumbnail.width,
            height : NewsonMainTemplate.containerMap.weather_thumbnail.height,
            visibleStyles : (THUMB_STYLE_IMAGE | THUMB_STYLE_INFO),
            image : {
                src : '{{src}}',
                width : NewsonMainTemplate.containerMap.weather_thumbnail.width,
                height : NewsonMainTemplate.containerMap.weather_thumbnail.imageHeight,
                enlarge: {
                    factor: 1.1,
                    anchorPoint: "center",
                },
            },
            information : {
                x : 0,
                y : NewsonMainTemplate.containerMap.weather_thumbnail.imageHeight,
                width : NewsonMainTemplate.containerMap.weather_thumbnail.width,
                height : NewsonMainTemplate.containerMap.weather_thumbnail.infoHeight,
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "bottom",
                },
                icon1 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.weather_icon.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.weather_icon.y,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.weather_icon.height,
                    width : NewsonMainTemplate.containerMap.weather_thumbnail.weather_icon.width,
                    fillMode : "stretch",
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    src : '{{currentConditionIcon}}',
                    async : true,
                },
                icon2 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.icon_h.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.icon_h.y,
                    width : NewsonMainTemplate.containerMap.weather_thumbnail.icon_h.width,
					//width :-1,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.icon_h.height,
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    src : ResourceMgr.NewsTemperatureIconHigh,
                    //fillMode : "stretch"
                },
                icon3 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.icon_l.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.icon_l.y,
                    width : NewsonMainTemplate.containerMap.weather_thumbnail.icon_l.width,
					//width :-1,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.icon_l.height,
                    src : ResourceMgr.NewsTemperatureIconLow,
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    //fillMode : "stretch"
                },
                text1 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.location.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.location.y,
                    width : NewsonMainTemplate.containerMap.weather_thumbnail.location.width,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.location.height,
                    text : '{{location}}',
                    font : NewsonMainTemplate.containerMap.weather_thumbnail.location.font,
                    horizontalAlignment : "left",
                    textColor : Volt.hexToRgb('#000000', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    singleLineMode : false
                },
                text2 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.conditions.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.conditions.y,
                    width : NewsonMainTemplate.containerMap.weather_thumbnail.conditions.width,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.conditions.height,
                    text : '{{currentConditions}}',
                    font : NewsonMainTemplate.containerMap.weather_thumbnail.conditions.font,
                    horizontalAlignment : "left",
                    textColor : Volt.hexToRgb('#000000', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    singleLineMode : false
                },
                text3 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.highTemperature.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.highTemperature.y,
                    //width : NewsonMainTemplate.containerMap.weather_thumbnail.highTemperature.width,
					width :-1,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.highTemperature.height,
                    text : '{{todayHighTemp}}',
                    font : NewsonMainTemplate.containerMap.weather_thumbnail.highTemperature.font,
                    //horizontalAlignment : "left",
                    textColor : Volt.hexToRgb('#000000', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    singleLineMode : false
                },
                text4 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.y,
                    //width : NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.width,
					width :-1,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.height,
                    text : '{{todayLowTemp}}',
                    font : NewsonMainTemplate.containerMap.weather_thumbnail.lowTemperature.font,
                    //horizontalAlignment : "left",
                    textColor : Volt.hexToRgb('#000000', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    singleLineMode : false
                },
                text5 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.temperature.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.temperature.y,
                    //width : NewsonMainTemplate.containerMap.weather_thumbnail.temperature.width,
					width :-1,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.temperature.height,
                    text : '{{currentTemp}}',
                    font : NewsonMainTemplate.containerMap.weather_thumbnail.temperature.font,
                    //horizontalAlignment : "left",
                    textColor : Volt.hexToRgb('#000000', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    singleLineMode : false
                },
                text6 : {
                    x : NewsonMainTemplate.containerMap.weather_thumbnail.photoAttribute.x,
                    y : NewsonMainTemplate.containerMap.weather_thumbnail.photoAttribute.y,
                    width : NewsonMainTemplate.containerMap.weather_thumbnail.photoAttribute.width,
                    height : NewsonMainTemplate.containerMap.weather_thumbnail.photoAttribute.height,
                    text : '{{photoAttribute}}',
                    font : NewsonMainTemplate.containerMap.weather_thumbnail.photoAttribute.font,
                    horizontalAlignment : "right",
                    verticalAlignment : "center",
                    textColor : Volt.hexToRgb('#000000', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    singleLineMode : false
                }
            },
            icon1 : {
                x : NewsonMainTemplate.containerMap.weather_thumbnail.cp_icon.x,
                y : NewsonMainTemplate.containerMap.weather_thumbnail.cp_icon.y,
                width : NewsonMainTemplate.containerMap.weather_thumbnail.cp_icon.width,
                height : NewsonMainTemplate.containerMap.weather_thumbnail.cp_icon.height,
                fillMode : "stretch",
                opacity : 255,
                unpressSrc : Volt.getRemoteUrl('images/1080/news_weather_ch_cp_icon.png'),
                clickable : false
            }
        }]
    },

    

    container_news_thumbnail2 : {
        type : 'image',
        x : 0,
        y : 0,
        width : NewsonMainTemplate.containerMap.news_thumbnail2.width,
        height : NewsonMainTemplate.containerMap.news_thumbnail2.height,
        //src:'{{src}}',
        src : ResourceMgr.IconBlankThumbnail,
        fillMode : 'center',
        color : Volt.hexToRgb('#d4d4d4', 100),
        children : [{
            type : 'widget',
            x : NewsonMainTemplate.containerMap.news_thumbnail2.width - 1,
            y : 0,
            width : 1,
            height : NewsonMainTemplate.containerMap.news_thumbnail2.height,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'widget',
            x : 0,
            y : NewsonMainTemplate.containerMap.news_thumbnail2.height - 1,
            width : NewsonMainTemplate.containerMap.news_thumbnail2.width,
            height : 1,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'Thumbnail',
            visibleStyles : (THUMB_STYLE_IMAGE | THUMB_STYLE_INFO),
            width : NewsonMainTemplate.containerMap.news_thumbnail2.width,
            height : NewsonMainTemplate.containerMap.news_thumbnail2.height,
            image : {
                src : '{{src}}',
                width : NewsonMainTemplate.containerMap.news_thumbnail2.width,
                height : NewsonMainTemplate.containerMap.news_thumbnail2.imageHeight,
                fillMode:"center-crop",
                enlarge: {
                    factor: 1.1,
                    anchorPoint: "center",
                },
            },
            information : {
                x : 0,
                y : NewsonMainTemplate.containerMap.news_thumbnail2.imageHeight,
                width : NewsonMainTemplate.containerMap.news_thumbnail2.width,
                height : NewsonMainTemplate.containerMap.news_thumbnail2.infoHeight,
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "bottom",
                },
                icon1 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail2.cp_icon.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail2.cp_icon.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail2.cp_icon.width,
                    height : NewsonMainTemplate.containerMap.news_thumbnail2.cp_icon.height,
                    opacity : NewsonMainTemplate.containerMap.news_thumbnail2.cp_icon.opacity,
                    fillMode : "stretch",
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    src : Volt.getRemoteUrl('images/1080/news_cp_icon_sina_w.png')
                },
                text1 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail2.title.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail2.title.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail2.title.width,
                    height : NewsonMainTemplate.containerMap.news_thumbnail2.title.height,
                    font : NewsonMainTemplate.containerMap.news_thumbnail2.title.font,
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    text : '{{title}}',
                    verticalAlignment : 'top',
                    horizontalAlignment : "left",
                    singleLineMode : false
                },

				text2 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail2.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail2.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail2.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail2.time.height,
                    text : '{{sourcecp}}',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail2.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },
				text3 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail2.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail2.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail2.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail2.time.height,
                    text : '-',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail2.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },
						
                text4 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail2.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail2.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail2.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail2.time.height,
                    text : '{{time}}',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail2.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },

				text5 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail2.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail2.time.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail2.time.width,
                    //width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail2.time.height,
                    text : '',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail2.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                }
            }
        }]
    },

    container_news_thumbnail3 : {
        type : 'image',
        x : 0,
        y : 0,
        width : NewsonMainTemplate.containerMap.news_thumbnail3.width,
        height : NewsonMainTemplate.containerMap.news_thumbnail3.height,
        //src:'{{src}}',
        src : ResourceMgr.IconBlankThumbnail,
        fillMode : 'center',
        color : Volt.hexToRgb('#d4d4d4', 100),
        children : [{
            type : 'widget',
            x : NewsonMainTemplate.containerMap.news_thumbnail3.width - 1,
            y : 0,
            width : 1,
            height : NewsonMainTemplate.containerMap.news_thumbnail3.height,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'widget',
            x : 0,
            y : NewsonMainTemplate.containerMap.news_thumbnail3.height - 1,
            width : NewsonMainTemplate.containerMap.news_thumbnail3.width,
            height : 1,
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'Thumbnail',
            visibleStyles : (THUMB_STYLE_IMAGE | THUMB_STYLE_INFO),
            width : NewsonMainTemplate.containerMap.news_thumbnail3.width,
            height : NewsonMainTemplate.containerMap.news_thumbnail3.height,
            image : {
                src : '{{src}}',
                width : NewsonMainTemplate.containerMap.news_thumbnail3.width,
                height : NewsonMainTemplate.containerMap.news_thumbnail3.imageHeight,
                fillMode:"center-crop",
                enlarge: {
                    factor: 1.1,
                    anchorPoint: "center",
                },
            },
            information : {
                x : 0,
                y : NewsonMainTemplate.containerMap.news_thumbnail3.imageHeight,
                width : NewsonMainTemplate.containerMap.news_thumbnail3.width,
                height : NewsonMainTemplate.containerMap.news_thumbnail3.infoHeight,
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "bottom",
                },
                icon1 : {
                    x : NewsonMainTemplate.containerMap.news_thumbnail3.cp_icon.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail3.cp_icon.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail3.cp_icon.width,
                    height : NewsonMainTemplate.containerMap.news_thumbnail3.cp_icon.height,
                    opacity : NewsonMainTemplate.containerMap.news_thumbnail3.cp_icon.opacity,
                    fillMode : "stretch",
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    src : Volt.getRemoteUrl('images/1080/news_cp_icon_sina_w.png')
                },
                text1 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail3.title.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail3.title.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail3.title.width,
                    height : NewsonMainTemplate.containerMap.news_thumbnail3.title.height,
                    font : NewsonMainTemplate.containerMap.news_thumbnail3.title.font,
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    text : '{{title}}',
                    verticalAlignment : 'top',
                    horizontalAlignment : "left",
                    singleLineMode : false
                },
                text2 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail3.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail3.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail3.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail3.time.height,
                    text : '{{time}}',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail3.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },

				text3 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail3.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail3.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail3.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail3.time.height,
                    text : '-',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail3.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },

				text4 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail3.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail3.time.y,
                    //width : NewsonMainTemplate.containerMap.news_thumbnail3.time.width,
                    width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail3.time.height,
                    text : '{{time}}',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail3.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },
                
                text5 : {
                    type : 'text',
                    x : NewsonMainTemplate.containerMap.news_thumbnail3.time.x,
                    y : NewsonMainTemplate.containerMap.news_thumbnail3.time.y,
                    width : NewsonMainTemplate.containerMap.news_thumbnail3.time.width,
                    //width :-1,
                    height : NewsonMainTemplate.containerMap.news_thumbnail3.time.height,
                    text : '',
                    textColor : Volt.hexToRgb('#FFFFFF', 60),
                    highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                    },
                    enlarge: {
                        factor: 1.5,
                        anchorPoint: "top-left",
                    },
                    font : NewsonMainTemplate.containerMap.news_thumbnail3.time.font,
                    horizontalAlignment : "left",
					autoScroll:false,
                    singleLineMode : false
                },
            }
        }]
    },

    main_detail_default : [
        ResourceMgr.ChDefaultImageLl01,
        ResourceMgr.ChDefaultImageLl02,
        ResourceMgr.ChDefaultImageSl01,
        ResourceMgr.ChDefaultImageSL02,
        ResourceMgr.ChDefaultImageSs01,
        ResourceMgr.ChDefaultImageSs02,
        ResourceMgr.ChDefaultImageSs03,
        ResourceMgr.ChDefaultImageSs04
    ],

    constNum : {
        thumbnailTextLineHeight : 32
    // 1920 * 0.016667
    }
};
exports = MainDetailTemplate;
