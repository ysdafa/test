var ScreenTemplate = Volt.require('app/templates/1080/newson-screen-template.js');
//var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetButton = Volt.require('WinsetUIElement/winsetButton.js');
var ResourceMgr = Volt.require('app/templates/newson-resource-mgr-template.js');
var NewsOnDetailTemplate = {
    container : {
        parent : Volt.WinsetRoot,
        type : 'widget',
        width : Volt.width,
        height : Volt.height,
        color : Volt.hexToRgb('#000000', 40),
        children : [{
            type : 'WinsetBackground',
            //id : 'detail-title-area',
            width : Volt.width,
            height : Volt.height * 0.343519,//371,// 1080 * 0.343519
            //color : Volt.hexToRgb('#000000', 8),
            bgHighContrastColor:Volt.hexToRgb('#ffffff',10),
            bgColor:Volt.hexToRgb('#000000',8),
            children : [{
                type : 'widget',
                id : 'detail-title-area',
                width : Volt.width * 0.831250,//1596, // 1920 * 0.831250
                height : Volt.height * 0.343519,//371,// 1080 * 0.343519
                color : Volt.hexToRgb('#000000', 0)
            }]
        }, {
            type : 'widget',
            y : Volt.height * 0.343519,//371,// 1080 * 0.343519
            width : Volt.width * 0.831250,//1596, // 1920 * 0.831250
            height : Volt.height * (1 - 0.343519),//709, // 1080 * (1 - 0.343519)
            id : 'detail-content-area',
            color : Volt.hexToRgb('#ffffff', 0)
        }, {
            type : 'widget',
            x : Volt.width * 0.831250,//1596, // 1920 * 0.831250
            width : Volt.width * 0.168750,//324, // 1920 * 0.168750
            height : Volt.height,
            id : 'detail-relate-area',
            color : Volt.hexToRgb('#ffffff', 0)
        }, 
        {
            id : 'newson-news-detail-return-button',
            type:'widget',
            x:0,
            y:0,
            width:Volt.width*0.038021,
            height:Volt.height*0.091667,
            color : Volt.hexToRgb('#000000', 20),
            children:[{
                type : 'image',
                x : (Volt.width * 0.038021 - Volt.width*42/1920)/2,//40, // (1920 * 0.075000 - 64)/2
                y : (Volt.height * 0.091667 - Volt.height*42/1080)/2,//40, // (1080 * 0.133333 - 64)/2
                width : Volt.width*42/1920,//64,
                height : Volt.height*42/1080,//64,
                opacity : 255*0.6,
                color : ScreenTemplate.transparentColor
            }]
        },
        {
            id : 'newson-news-detail-close-button',
            type:'widget',
            x:Volt.width * (1-0.038021),
            y:0,
            width:Volt.width*0.038021,
            height:Volt.height*0.091667,
            color : Volt.hexToRgb('#000000', 20),
            children:[{
                type : 'image',
                x : (Volt.width * 0.038021 - Volt.width*42/1920)/2,//40, // (1920 * 0.075000 - 64)/2
                y : (Volt.height * 0.091667 - Volt.height*42/1080)/2,//40, // (1080 * 0.133333 - 64)/2
                width : Volt.width*42/1920,//64,
                height : Volt.height*42/1080,//64,
                opacity : 255*0.6,
                color : ScreenTemplate.transparentColor
            }]
        }]
    },
    /*
    TitleArea:{
        type : 'widget',
        x : 0, y : 0, width : 1920 - 277, height : 144,
        color : Volt.hexToRgb('#0F2540',0),
    	children: [
            {
                type : 'text',
                x : 60, y: 0, width : 1920 - 277 - (2 * 60), height : 144,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff', 90),
    			id:'headline',
                ellipsize : true,
                text : '{{ headline }}',
                font : 'SVD Light 58px',
                singleLineMode: false,
            },
        ]
    },
    */
    DetailContentArea : {
        type : 'widget',
        width : Volt.width * 0.831250,//1596, // 1920 * 0.831250
        height : Volt.height * (1 - 0.343519),//709, // 1080 * (1 - 0.343519)
        color : Volt.hexToRgb('#ff0000', 0),
        children : [{
            type : 'widget',
            width : Volt.width * 0.831250,//1596, // 1920 * 0.831250
            y:Volt.height * 0.044444,
            x:0,
            height : Volt.height * 550 / 1080,//Volt.height * (0.572222 - 0.046296),//600, // 1080 * 0.572222 - (1080 * 0.572222 % (1080 * 0.046296))
            id : 'contentArea',
            cropOverflow : true,
            color : Volt.hexToRgb('#000000', 0)
        }, {
            type : 'WinsetButton',
            x :  Volt.width * 0.360417,//692, // 1920 * 0.360417
            y : Volt.height * (1 - 0.343519 - 0.037037) - Volt.height*52/1080,//617, // 1080 * (1 - 0.343519 - 0.037037) - 52
            width : Volt.width*96/1920,
            height : Volt.height*52/1080,//52,
            style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA,
            buttonType: WinsetButton.ButtonType.BUTTON_ICON,
            custom : {
                'focusable' : false
            },
            //opacity : Volt.getPercentage(10),
            id : 'artical_up',
            iconImgSrc: ResourceMgr.DetailArrowUp,
            iconHeight: Volt.height*30/1080,
            iconWidth: Volt.width*30/1920,
            /*
            icon : {
                x : (96 - 30) / 2, // (96 - 32) / 2
                y : (52 - 30) / 2, //(52 - 32) / 2
                width : Volt.width*30/1920,//96,
                height : Volt.height*30/1080,//52,
                src: ResourceMgr.DetailArrowUp
            }*/
        }, {
            type : 'WinsetButton',
            x : Volt.width * 0.360417 + Volt.width*96/1920 + Volt.width * 0.010417,//808, // 1920 * 0.360417 + 96 + 1920 * 0.010417
            y : Volt.height * (1 - 0.343519 - 0.037037) - Volt.height*52/1080,//617, // 1080 * (1 - 0.343519 - 0.037037) - 52
            width : Volt.width*96/1920,//96,
            height : Volt.height*52/1080,//52,
            style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA,
            buttonType: WinsetButton.ButtonType.BUTTON_ICON,
            custom : {
                'focusable' : false
            },
            id : 'artical_down',
            iconImgSrc: ResourceMgr.DetailArrowDown,
            iconHeight: Volt.height*30/1080,
            iconWidth: Volt.width*30/1920,
            /*
            color : Volt.hexToRgb('#ffffff', 0),
            icon:
            {
                x : (96 - 30) / 2, // (96 - 32) / 2
                y : (52 - 30) / 2, //(52 - 32) / 2
                width : Volt.width*30/1920,//96,
                height : Volt.height*30/1080,//52,
                src: ResourceMgr.DetailArrowDown
            }*/
        },
        {
            type : 'WinsetButton',
            x : Volt.width * (0.831250 - 369/1920)/2,
            y : Volt.height * (1 - 0.343519 - 0.037037) - Volt.height*52/1080,//617, // 1080 * (1 - 0.343519 - 0.037037) - 52
            width : Volt.width*369/1920,
            height : Volt.height*65/1080,
            id : 'read_article',
            custom : {
                'focusable' : false
            },
            color : Volt.hexToRgb('#ffffff', 0),
            style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            text: Volt.i18n.t('TV_SID_READ_ARTICLE'),
            bHasBorder: true,
        },

        {
            type : 'ScrollBar',
            x:Volt.width*1550/1920, //1596-42-4,
            y:Volt.height * 0.044444,
            height:Volt.height*0.483333,//600,
            width:Volt.width*(0.002083),//4,
            id:'detail_scroll_bar',
            loop:true,
        }
        ]
    },
    contentAppend : {
        type : 'widget',
        x:0,
        y:0,
        width : Volt.width * 0.831250,//1596, // 1920 * 0.831250
        height : Volt.height * (0.572222-0.046296),//600, // 1080 * 0.572222 - (1080 * 0.572222 % (1080 * 0.046296))
        color : Volt.hexToRgb('#ffffff', 0),
        id : 'contentRealArea',
        children : [
            {
            type : 'image',
            //cropMode: 'cropLeftTop',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            y : 0,//Volt.height*50/1080 - (Volt.height * 0.044444 + Volt.height*34/1080 + Volt.height * 0.003704),//62, // 100 - (1080 * 0.044444 + 34 + 1080 * 0.003704)
//            width : 145, 
            width : Volt.width *145/1920,//145,
            height : Volt.height*34/1080,//34,
            id : 'brand_img_url',
            src : '{{ brand_img_url }}',
            opacity : 255 * 0.6,
            color : Volt.hexToRgb('#FFFFFF', 0)
        }, {
            type : 'text',
            id : 'summary',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            y : Volt.height* 50/1080, // 1080 * (0.044444 + 0.026852 + 0.003704) - (1080 * 0.572222 % (1080 * 0.046296))
            width : Volt.width * (0.831250 - 2 * 0.044792),//1424, // 1920 * (0.831250 - 2 * 0.044792)
            //height:50*6,
            text : '{{summary}}',
            ellipsize:true,
            justify:true,
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            font : '35px'
        //ellipsize : true,
        }, {
            type : 'widget', // color drowing
            id : 'color_drowing_horizontal',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            width : Volt.width * 0.741667,//1424, // 1920 * 0.741667
            height : Volt.height * 0.001852,//2, // 1080 * 0.001852
            color : Volt.hexToRgb('#FFFFFF', 20)
        }, {
            type : 'text',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            width : Volt.width * (0.831250 - 2 * 0.044792),//1424, // 1920 * (0.831250 - 2 * 0.044792)
            height : Volt.height * 0.027778,//30, // 1080 * 0.027778
            //text : 'Full Article',
            text : Volt.i18n.t('COM_SID_FULL_ARTICLE'),
            id : 'osd_fullarticle',
            textColor : Volt.hexToRgb('#FFFFFF', 80),
            font : 'SVD Light 26px',
            custom : {
                multilingual : {
                    SID : 'COM_SID_FULL_ARTICLE'
                },
            }
        // ellipsize : true,
        }, {
            type : 'text',
            id : 'fullarticle',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            y : Volt.height*63/1080, // 1080 * (0.044444 + 0.026852 + 0.003704) - (1080 * 0.572222 % (1080 * 0.046296))
            width : Volt.width * (0.831250 - 2 * 0.044792),//1424, // 1920 * (0.831250 - 2 * 0.044792)
            //height:709 - 40 - 52 - (48 + 29 + 4 + 50 * 6 + 28 + 2 + 28 + 20 + 15),
            text : '{{fullarticle}}',
            justify:true,
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            font : 'SVD Light 35px'
        //ellipsize : true,
        }]
    },
    contentAppendBackup : {
        type : 'widget',
        x:0,
        y:0,
        width : Volt.width * 0.831250,//1596, // 1920 * 0.831250
        height : Volt.height * (0.572222-0.046296),//600, // 1080 * 0.572222 - (1080 * 0.572222 % (1080 * 0.046296))
        color : Volt.hexToRgb('#ffffff', 0),
        id : 'contentRealArea_backup',
        opacity:0,
        children : [
            {
            type : 'image',
            //cropMode: 'cropLeftTop',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            y : 0,//Volt.height*50/1080 - (Volt.height * 0.044444 + Volt.height*34/1080 + Volt.height * 0.003704),//62, // 100 - (1080 * 0.044444 + 34 + 1080 * 0.003704)
//            width : 145, 
            width : Volt.width *145/1920,//145,
            height : Volt.height*34/1080,//34,
            id : 'brand_img_url_backup',
            src : '{{ brand_img_url }}',
            opacity : 255 * 0.6,
            color : Volt.hexToRgb('#FFFFFF', 0)
        }, {
            type : 'text',
            id : 'summary_backup',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            y : Volt.height* 50/1080, // 1080 * (0.044444 + 0.026852 + 0.003704) - (1080 * 0.572222 % (1080 * 0.046296))
            width : Volt.width * (0.831250 - 2 * 0.044792),//1424, // 1920 * (0.831250 - 2 * 0.044792)
            //height:50*6,
            text : '{{summary}}',
            ellipsize:true,
            justify:true,
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            font : '35px'
        //ellipsize : true,
        }, {
            type : 'widget', // color drowing
            id : 'color_drowing_horizontal_backup',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            width : Volt.width * 0.741667,//1424, // 1920 * 0.741667
            height : Volt.height * 0.001852,//2, // 1080 * 0.001852
            color : Volt.hexToRgb('#FFFFFF', 20)
        }, {
            type : 'text',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            width : Volt.width * (0.831250 - 2 * 0.044792),//1424, // 1920 * (0.831250 - 2 * 0.044792)
            height : Volt.height * 0.027778,//30, // 1080 * 0.027778
            //text : 'Full Article',
            text : Volt.i18n.t('COM_SID_FULL_ARTICLE'),
            id : 'osd_fullarticle_backup',
            textColor : Volt.hexToRgb('#FFFFFF', 80),
            font : 'SVD Light 26px'
        // ellipsize : true,
        }, {
            type : 'text',
            id : 'fullarticle_backup',
            x : Volt.width * 0.044792,//86, // 1920 * 0.044792
            y : Volt.height*63/1080, // 1080 * (0.044444 + 0.026852 + 0.003704) - (1080 * 0.572222 % (1080 * 0.046296))
            width : Volt.width * (0.831250 - 2 * 0.044792),//1424, // 1920 * (0.831250 - 2 * 0.044792)
            //height:709 - 40 - 52 - (48 + 29 + 4 + 50 * 6 + 28 + 2 + 28 + 20 + 15),
            text : '{{fullarticle}}',
            justify:true,
            textColor : Volt.hexToRgb('#FFFFFF', 60),
            font : 'SVD Light 35px'
        //ellipsize : true,
        }]
    },
    
    detailArrowDown : {
        'unfocus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_n.png'),
        'focus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_down_f.png')
    },

    detailArrowUp : {
        'unfocus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_n.png'),
        'focus' : Volt.getRemoteUrl('images/1080/arrow/detail_arrow_up_f.png')
    },

    RelatedItem : [{
        type : 'image',
        width : Volt.width * 0.168750,//324, // 1920 * 0.168750
        height : Volt.height * (0.18148 + 0.088889),//292, // 1080 * (0.18148 + 0.088889)
        src : ResourceMgr.IconBlankThumbnail,
        fillMode : 'center',
        color : Volt.hexToRgb('#d4d4d4', 100),
        children : [{
            type : 'widget',
            x : Volt.width * 0.168750 - 1,//323, // 1920 * 0.168750 - 1
            y : 0,
            width : 1, 
            height : Volt.height * (0.18148 + 0.088889),//292, // 1080 * (0.18148 + 0.088889)
            color : Volt.hexToRgb('#c9c9c9', 100)
        }, {
            type : 'widget',
            x : 0,
            y :  Volt.height * (0.18148 + 0.088889) -1,//291, // 1080 * (0.18148 + 0.088889) -1
            width : Volt.width * 0.168750,//324,  // 1920 * 0.168750
            height : 1,
            color : Volt.hexToRgb('#c9c9c9', 100)
        },
		{
		type: 'Thumbnail',
		visibleStyles: (0x01 | 0x20),
        width : Volt.width * 0.168750,//324, // 1920 * 0.168750
        height : Volt.height * (0.18148 + 0.088889),//292, // 1080 * (0.18148 + 0.088889)
		image:{
            src: '{{ imgUrl }}',
			width: Volt.width * 0.168750,//324,
			height: Volt.height*196/1080,
            fillMode:"center-crop",
            enlarge: {
                    factor: 1.1,
                    anchorPoint: "center",
            },
        },//196},
		information:{
			x: 0,
			y: Volt.height*196/1080,//196,
			width: Volt.width * 0.168750,//324,
			height: Volt.height*96/1080,//96,
            enlarge: {
                    factor: 1.5,
                    anchorPoint: "bottom",
            },
			text1:{
				x:Volt.width*20/1920,//20,
				y:Volt.height*16/1080,//16,
				width:Volt.width*284/1920,//1920,
				height: Volt.height*32/1080,//1080,
				font: 'SVD Light 26px',
                highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                },
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "top-left",
                },
				text: '{{ title }}',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
				singleLineMode: true
			},
			
			text2:{
				x:Volt.width*20/1920,
				y:Volt.height*50/1080,
				//width:Volt.width*(324- 20*2)/1920,
				width :-1,
				height: Volt.height*32/1080,
                highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                },
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "top-left",
                },
				font: 'SVD Medium 20px',
				text: '{{ sourcecp }}',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
				singleLineMode: true
			},

			text3:{
				x:Volt.width*20/1920+30,
				y:Volt.height*50/1080,
				//width:Volt.width*(324- 20*2)/1920,
				width :-1,
				height: Volt.height*32/1080,
                highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                },
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "top-left",
                },
				font: 'SVD Medium 20px',
				text: '-',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
				singleLineMode: true
			},

			text4:{
				x:Volt.width*20/1920+50,
				y:Volt.height*50/1080,
				//width:Volt.width*(324- 20*2)/1920,
				width :-1,
				height: Volt.height*32/1080,
                highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                },
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "top-left",
                },
				font: 'SVD Medium 20px',
				text: '{{ timestamp }}',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
				singleLineMode: true
			},

			text5:{
				x:Volt.width*20/1920,
				y:Volt.height*50/1080,
				//width:Volt.width*(324- 20*2)/1920,
				width :-1,
				height: Volt.height*32/1080,
                highContrast: {
                        textColor: Volt.hexToRgb('#FFFFFF', 100),
                        highlightTextColor: Volt.hexToRgb('#fbba2d', 100),
                },
                enlarge: {
                    factor: 1.5,
                    anchorPoint: "top-left",
                },
				font: 'SVD Medium 20px',
				text: '',
                textColor : Volt.hexToRgb('#FFFFFF', 60),
				singleLineMode: true
			},
		},
	}]	
}]	

};

exports = NewsOnDetailTemplate;
