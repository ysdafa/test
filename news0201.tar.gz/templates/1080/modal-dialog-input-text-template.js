var ModalDialogInputTextTemplate = {
    container : {
        type: 'widget',
		custom : {
			'focusable' : true,
			'onKeyEvent' : null
		},
        x: 500, y: 200, width: 920, height : 680,
        color : Volt.hexToRgb('#000000',100),
        border : {width : 10, color : {r:0,g:0,b:255,a:255}},
        children : [
            {
                type : 'widget',
                id : 'input-text-title-container',
                x : 35, y : 0, width : 885, height : 64,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                id : 'input-text-description-container',
                x : 35, y : 64, width : 885, height : 64,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : 20, y : 128, width : 880, height : 400,
                id : 'input-text-field-container',
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : 20, y : 528, width : 900 , height : 150,
                id : 'input-text-button-container',
                color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    },
    title: {
        type: 'widget',
        x: 0, y: 0, width: 885, height: 64,
        color: Volt.hexToRgb('#000000',0),
        children:[
        {
            type: 'text',
            x: 0, y: 0, width: 885, height: 64,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity: 255,
            text : 'Title',
            font : '36px'
        }]
    },
    description: {
        type: 'widget',
        x: 0, y: 0, width: 885, height: 64,
        color: Volt.hexToRgb('#000000',0),
        children:[
        {
            type: 'text',
            x: 0, y: 0, width: 885, height: 64,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity: 255,
            text : 'Description',
            font : '36px'
        }]
    },
	textField: {
        x: 15,
        y: 15,
        width:850,
        height:370,
    },
    btn1: {
        x:80,
		y:25,
		width: 300,
		height: 100,
		text: 'Confirm',
    },
	btn2: {
        x:500,
		y:25,
		width: 300,
		height: 100,
		text: 'Cancel',
    }
};

exports = ModalDialogInputTextTemplate;


