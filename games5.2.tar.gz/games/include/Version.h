/* Do NOT change the following line.  It will be overwritten during cmake. */
#define GAMES_PANEL_VERSION "1.0.0"
#define GAMES_PANEL_VERSION_MAJOR 1
#define GAMES_PANEL_VERSION_MINOR 0
#define GAMES_PANEL_VERSION_PATCH 0
