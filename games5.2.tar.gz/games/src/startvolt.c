#include <sharedvc.h>
#include <dbg.h>
#include <unistd.h>

int main(int argc, char **argv)
{
	LOGE("In main function");
	bundle *b = bundle_create();
 	bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
	//bundle_add(b,"--app-js", "/opt/down/panels/games/app.js");
    bundle_add(b,"--data-path", "/opt/down/panels/games_temp");
    if (access("/opt/down/panels/games/src/app.js", F_OK) == 0 || access("/opt/down/panels/games/src/app.js.spm", F_OK) == 0 ) 
	{
        bundle_add(b,"--app-js", "/opt/down/panels/games/src/app.js");
 	} 
 	else 
 	{
 		bundle_add(b,"--app-js", "/opt/down/panels/games/src_original/app.js");
 	}
    
 	bundle_add(b, "--msaa-samples", "4"); 
	startVoltContainer(argc, argv, b);
	bundle_free(b);
	LOGE("wainting");
	return 0;
}

