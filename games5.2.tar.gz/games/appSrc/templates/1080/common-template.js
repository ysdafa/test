var CommonTemplate = {
    // Constants
    TOPMENU_OPACITY_NORMAL: 102,
    TOPMENU_OPACITY_SELECT: 255,

    //
    CATEGORY_ANIM_DURATION: 200,
    CONTENT_ANIM_DURATION: 300,

    //
    HEADER_Y_NORMAL: 0,
    HEADER_Y_SHRINK: -18,

    CATEGORY_Y_NORMAL: 144,
    CATEGORY_HEIGHT_NORMAL: 72,
    CATEGORY_CHILD_Y_NORMAL: 0,

    CATEGORY_Y_EXPAND: 108,
    CATEGORY_HEIGHT_EXPAND: 108,
    CATEGORY_CHILD_Y_EXPAND: 18,
    
    
    
    
    // for dim
    OPACITY_TRANSPARENCY: 0,
    OPACITY_OPAQUE: 255,
    OPACITY_DIM: 102,
    
    SCREEN_WIDTH:Volt.sceneWidth,
    SCREEN_HEIGHT: 1080,
    // Template for DimView
    dim: {
        type: 'widget',
        x: 0, y: 0, width: Volt.sceneWidth, height: 1080,
        color: {r: 0, g: 0, b: 0, a: 0},
        opacity: 102,
        children:[
            {
                type: 'widget',
                x: 0, y: 0, width: Volt.sceneWidth, height: 1080,
                color: {r: 0, g: 0, b: 0, a: 255},
            },{
                type: 'widget',
                x: 0, y: 0, width: Volt.sceneWidth, height: 0,
                color: {r: 0, g: 0, b: 0, a: 255},
            },{
                type: 'widget',
                x: 0, y: 0, width: 0, height: 0,
                color: {r: 0, g: 0, b: 0, a: 255},
            },{
                type: 'widget',
                x: 0, y: 0, width: 0, height: 0,
                color: {r: 0, g: 0, b: 0, a: 255},
            }
        ]
    }
}

exports = CommonTemplate;
