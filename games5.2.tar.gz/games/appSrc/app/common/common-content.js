var PanelCommon       = Volt.requireNoContext('lib/panel-common.js');
var CommonDefine      = Volt.requireNoContext('app/common/common-define.js');
var voltApiWrapper    = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var Backbone          = Volt.requireNoContext('lib/volt-backbone.js');
var MainCategoryModel = Volt.requireNoContext("app/models/main-category-model.js");
var Mediator          = Volt.requireNoContext('app/common/event-mediator.js');
var _                 = Volt.requireNoContext('modules/underscore.js')._;
var Utils             = Volt.requireNoContext('app/common/utils.js');
var Q = Volt.requireNoContext('modules/q.js');

var CommonFucntion    = Volt.requireNoContext('app/common/common-function.js');
var ErrorHandling     = Volt.requireNoContext('app/common/error-handling.js');
var DeviceModel 	  = Volt.requireNoContext('app/models/device-model.js');
var RouterController  = Volt.requireNoContext('app/controller/router-controller.js');
var WinsetToolTip 	  = Volt.requireNoContext("WinsetUIElement/winsetToolTip.js");
var WinsetProgress 	  = Volt.requireNoContext("WinsetUIElement/winsetProgress.js");
var WinsetScroll	  = Volt.requireNoContext("WinsetUIElement/winsetScroll.js");
var VoiceGuide    	  = Volt.requireNoContext('app/common/voiceGuide.js');

var toolTip = null;
var timeOut = null;
var widgetExListener = null;


var onColorPickerForPopupOrText = function(baseColor){
    var pickedColor = {r:0,g:0,b:0};
    Volt.log("baseColor:r " + baseColor.r);
    var utility = new Utility;
    var result = utility.extractForegroundColor(baseColor.r, baseColor.g, baseColor.b);
    Volt.log("colorPicking:color -- " + result.color);
    if (result && result.color) {
        pickedColor.r = result.color.r;
        pickedColor.g = result.color.g;
        pickedColor.b = result.color.b;
    } else {
        pickedColor.r = parseInt(Math.random() * 255 + 1);
        pickedColor.g = parseInt(Math.random() * 255 + 1);
        pickedColor.b = parseInt(Math.random() * 255 + 1);
    }
    return pickedColor;
};

var getContextualContent = function(app_id) {
    var listText = [];
    var bisWidgetInstalled  = voltApiWrapper.isWidgetInstalled(app_id);
    var binstalledPath  = voltApiWrapper.getInstalledPath(app_id);
    var bisWidgetInstalling  = voltApiWrapper.isWidgetInstalling(app_id);
    var isInstalled  = ( bisWidgetInstalled && binstalledPath && !bisWidgetInstalling );
    var currentID    = MainCategoryModel.get('category');
    var isNewVersion = voltApiWrapper.haveNewVersion(app_id);
	var isUpdating   = voltApiWrapper.isAppUpdating(app_id);
    Volt.log('[common-content.js] getContextualContent currentID::::' + currentID); 
    Volt.log('[common-content.js] getContextualContent isInstalled::::' + isInstalled);
	Volt.log('[common-content.js] getContextualContent isUpdating::::'+isUpdating);

    if (isInstalled) {
        //var currentPage = MainCategoryModel.get('category');
        //var isNewVersion = voltApiWrapper.haveNewVersion(app_id);
        //Volt.log('currentPage::::'+currentPage);
        switch(currentID) {
            case 'C0010':
            case 'C0070':
                listText.push(Volt.i18n.t('UID_VIEW_DETAILS'));
                if (isNewVersion) {
                    if(!isUpdating){
                        listText.push(Volt.i18n.t('COM_SID_DELETE'));
                        listText.push(Volt.i18n.t('COM_SID_UPDATE'));
                    }
                } else {
                    listText.push(Volt.i18n.t('COM_SID_DELETE'));
                }
                break;

            case 'C0030':
            case 'C0040':
            case 'C0050':
            case 'C0080':
            case 'C0081':
            case 'C0082':
            case 'C0084':
            case 'C0083':
                listText.push(Volt.i18n.t('COM_SID_PLAY_KR_RUN'));
                if (isNewVersion && !isUpdating) {
                    listText.push(Volt.i18n.t('COM_SID_UPDATE'));
                }
                break;

            default:
                break;
        }
    } else {
        var Obj = voltApiWrapper.getWidgetInstallStatus(app_id);
        if (Obj != undefined) {
            Volt.log('[common-content.js] InitDownloadBtn status:' + Obj.status + " " + Obj.progress);
            switch(Obj.status) {
                case 'downloading':
                    listText.push(Volt.i18n.t('COM_SID_CANCEL'));
                    break;
                case 'installing':
                    listText.push(Volt.i18n.t('COM_SID_CANCEL'));
                    break;
                default:
                    listText.push(Volt.i18n.t('COM_SID_DOWNLOAD'));
                    break;
            }
        } else {
            listText.push(Volt.i18n.t('COM_SID_DOWNLOAD'));
        }
    }

    return listText;
};

var ContextualMenuCallback = function(listIndex, option) {
    Volt.log('[common-content.js] ContextualMenuCallback  option : ' + JSON.stringify(option));
    if (!option) {
        Volt.log('[common-content.js] ContextualMenuCallback : the second parameter is illegal !');
        return;
    }
	
	if (this.optionPopup.ifDim({index:listIndex})) {
		return;
	}
		
    var app_id       = option.options.app_id;
    var app_size     = option.options.size;
    var app_name 	 = option.options.title;
    var popup_text   = option.options.popup_text;
    var popup_flag   = option.options.popup_flag;
    var content = this.optionPopup.text({
        index : listIndex
    });
    this.hide();
    switch(content) {
        case Volt.i18n.t('UID_VIEW_DETAILS'):
            Volt.log('[common-content.js] ContextualMenuCallback send longPress detail log');
			addEventLog('LPVIEW',app_id);
            //Mediator.trigger(CommonDefine.Event.GENRE_DETAIL_ENTER_DETAIL);
            Volt.KPIAppId = app_id;
            Backbone.history.navigate('detail/' + app_id, {
                trigger : true,
                bgColor : option.bgColor
            });
            break;
        case Volt.i18n.t('COM_SID_DELETE'):
			Volt.log('[common-content.js] ContextualMenuCallback send longPress Delete log');
			addEventLog('LPDELETE',app_id);
            var appId = [];
            appId[0] = app_id;

            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK, appId);
            break;
        case Volt.i18n.t('COM_SID_PLAY_KR_RUN'):
			addEventLog('LPPLAYCLICK',app_id);
            var Utils = Volt.requireNoContext('app/common/utils.js');
            var bLogInStatus = Utils.Account.getSignState();
            if (bLogInStatus) {
                Volt.log('[common-content.js] this app is installed and already login, run it');
                voltApiWrapper.launchApp(app_id, '');
            } else {
                Volt.log('[common-content.js] this app is installed and not login, pop up login');
				Volt.KPIParams.event = 'JUMPSSO';
				Volt.KPIParams.cp 	 = Volt.KPIMapper.getPageEvent().pageEvent;
				Volt.KPIParams.ssoby = 'option';
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED, app_id);
            }
            break;
        case Volt.i18n.t('COM_SID_UPDATE'):
            Volt.log('[common-content.js] ContextualMenuCallback send longPress Update log');
            addEventLog('LPUPDATE',app_id);
            voltApiWrapper.updateApp(app_id);
            var data = {
                app_id : app_id,
            };
            Mediator.trigger(CommonDefine.Event.BEGIN_DOWNLOAD, data);
            break;
        case Volt.i18n.t('COM_SID_DOWNLOAD'):
            Volt.log('[common-content.js] ContextualMenuCallback send longPress Download log');
			addEventLog('LPDWCLICK',app_id);
            if(popup_flag == 'Y'){
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_PSN, '', popup_text); 
            } else {
                installApp(app_id, app_size, app_name);
            }
            break;
        case Volt.i18n.t('COM_SID_CANCEL'):
            Volt.log('[common-content.js] ContextualMenuCallback send longPress Cancel log');
			addEventLog('LPCANCEL',app_id);
            voltApiWrapper.cancelInstallApp(app_id);
            var data = {
                app_id : app_id,
            };
            Mediator.trigger(CommonDefine.Event.DOWNLOAD_CANCELED, data);
            break;
        default:
            //TODO
            break;
    }
};

var addEventLog = function(eventName, app_id) {
	Volt.log("[common-content.js] addEventLog ..... Volt.pageItemIndex = " + Volt.pageItemIndex);
	Volt.KPIMapper.addEventLog(eventName, {
        d : {
            cp : '',
            appid : app_id,
            sp:Volt.KPIMapper.getSelectPosition(Volt.pageItemIndex),
            inputby:'',
        }
    });
};

var onLongPress = function(grid, model, index, widget, thumbnailObj) {
	Volt.log("[common-content.js]long press**********");
	Mediator.on(CommonDefine.Event.DESTROY_LONG_PRESS_MENU, destroyPopup);
	grid.onBlur();
    //because grid.dim(true) interface has problem when reverseOSD,it will refine after interface is ok
    grid.dim(true);
    
    grid.setDimWindowColor({
        red : 0,
        green : 0,
        blue : 0,
        alpha : 153
    });

	var app_id  = model.app_id;
	var listText = getContextualContent(app_id);
	var OptionMenu = Volt.requireNoContext('app/views/option-menu-popup.js');
	var itemBGColor = null;
	if(thumbnailObj.imgReady){
        itemBGColor = thumbnailObj.getInformationColorPicking();
    }

	var longPressMenu = new OptionMenu({
		style : CommonDefine.Const.LONG_PRESS_MENU,
		listItems : listText,
		//bgColor : itemBGColor,
		callback : ContextualMenuCallback,
		options : model,
	});
	var longPressPopup = longPressMenu.optionPopup;
	var pos = widget.getAbsolutePosition();
	Volt.log('pos x:::' + pos.x);
	if (pos.x + widget.width + 308 > Volt.sceneWidth) {
		longPressPopup.x = pos.x - 308 -2; //"4" is double width of sublist border
	} else {
		longPressPopup.x = pos.x + widget.width;
	}
	longPressPopup.y = pos.y;
	longPressMenu.show();
	setOptionMenu(longPressMenu);
	
	function destroyPopup() {
		Volt.log('[common-content.js] destroyPopup .....');
		grid.dim(false);

		Mediator.off(CommonDefine.Event.DESTROY_LONG_PRESS_MENU);
		grid.showFocus("true");
		setOptionMenu(null);
	}

};

var optionMenuObj = null;
var getOptionMenu = function (){
    return optionMenuObj;
};

var setOptionMenu = function (param){
    Volt.log('[common-content.js] setOptionMenu param =' + param);
    optionMenuObj = param;
};


var onLaunch = function(CurrentPage, app_id, thumbnail, selectPosition) {
    var networkStatus = Volt.requireNoContext('app/common/network-state.js');
    if (!networkStatus.getNetWorkState()) {
		ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR,'','505');
    } else {
		var bWidgetInstalled = voltApiWrapper.isWidgetInstalled(app_id);
		//add path check;
		var installedPath = voltApiWrapper.getInstalledPath(app_id);
		var bIsInstalling = voltApiWrapper.isWidgetInstalling(app_id);
		Volt.log('[common-content.js]onLaunch app_id = ' + app_id + ',,,,,bWidgetInstalled = ' + bWidgetInstalled+ ',,,,,installedPath = ' + installedPath);
		//add KPI log
		var eventName = (bWidgetInstalled && installedPath) ? 'EXEGAME' : 'VIEWGAME';
		Volt.log('[common-content.js]onLaunch eventName = ' + eventName );
		Volt.KPIMapper.addEventLog(eventName, {
	            d : {
	                cp : CurrentPage,
	                appid : app_id,
	                sp:selectPosition,
	                content:'n/a',
	                inputby:'',
	            }
	     });
   
        var isEnterDetail = true;
        if(CurrentPage == 'G02_SLIGHT'){
            if(bWidgetInstalled && installedPath && !bIsInstalling){
                isEnterDetail = false;
                if(Utils.Account.getSignState()){
                	Volt.log('[common-content.js]onLaunch launchApp');
                    voltApiWrapper.launchApp(app_id);
                } else {
                	Volt.KPIParams.event = 'JUMPSSO';
                	Volt.KPIParams.cp 	 = Volt.KPIMapper.getPageEvent().pageEvent;
					Volt.KPIParams.ssoby = 'game';
                    ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED, app_id);
                }  
            }
        }

        if(isEnterDetail){
            Volt.KPIAppId = app_id;
            var itemBGColor = null;
            if(thumbnail){
                Volt.log("[common-content.js] onLaunch, imgReady = " + thumbnail.imgReady);
                if(thumbnail.imgReady){
                    itemBGColor = thumbnail.getInformationColorPicking();
                }
            }
            
            if(itemBGColor){
                Backbone.history.navigate('detail/' + app_id, {
                    trigger : true,
                    bgColor : itemBGColor
                });
            } else {
                Backbone.history.navigate('detail/' + app_id, {
                    trigger : true
                });
            }
        }
    }
};

function addInformationUSBIcon(thumbnailObj, targetSrc, darkTargetSrc, iconID) {
    Volt.log("[common-content.js] addInformationUSBIcon");
    var inforAlloc = thumbnailObj.getElementAllocation("information");
    Volt.log("[common-content.js] width = " + inforAlloc.width + ", height = " + inforAlloc.height);
    
    var iconParam = {
        x : inforAlloc.width - Volt.sceneWidth * 0.005208 - 32*2 - Volt.sceneWidth*0.005209,
        y : 1080 * 0.011111,
        width : 32,
        height : 32,
        src : targetSrc,
        darkSrc: darkTargetSrc,
        async : true,
    };

    var attr = {};
    attr[iconID] = iconParam;
    thumbnailObj.addThumbnailInformationIcons(attr);
    var obj = {
      type: iconID,
      created: true,
    };
    return obj;
};

function addInformationIcon(thumbnailObj,targetSrc){
    Volt.log("[common-content.js] addInformationIcon");
    var inforAlloc = thumbnailObj.getElementAllocation("information");
    Volt.log("[common-content.js] width = " + inforAlloc.width + ", height = " + inforAlloc.height);
    
    var iconParam = {
        x : inforAlloc.width - Volt.sceneWidth * 0.005208 - 32,
        y : 1080 * 0.011111,
        width : 32,
        height : 32,
        src : targetSrc,
        async : true,
    };
    thumbnailObj.addThumbnailInformationIcons({icon1:iconParam});
    var obj = {
      type: "icon1",
      created: true,
    };
    return obj;
};

function addThumbnailProgressbar(thumbnailObj){
    Volt.log("[common-content.js] addThumbnailProgressbar");
    var inforAlloc = thumbnailObj.getElementAllocation("information");
    Volt.log("[common-content.js] width = " + inforAlloc.width + ", height = " + inforAlloc.height);

    var progressbarParam = {
        x : 0,
        y : inforAlloc.y,
        width : inforAlloc.width,
        height : 2,
        backgroundColor : Volt.hexToRgb('#ffffff', 20),
        progressColor : Volt.hexToRgb('#ffffff', 60),
        normalThumbSrc : "",
        focusThumbSrc : "",
        thumbWidth : 8,
        thumbHeight : 10,
    };
    thumbnailObj.addThumbnailProgressBar({
        progressBar : progressbarParam
    });
    
    var obj = {
        type : "progressbar",
        created : true,
    };
    return obj;

};

function updateThumbnailInfoIcon(thumbnailObj, targetSrc, iconID){
    Volt.log("[common-content.js] updateThumbnailInfoIcon");
    iconID = iconID ? iconID : "icon1";
    thumbnailObj.setInformationIcon(iconID, targetSrc);
    visualizeThumbnailElement(thumbnailObj,true, iconID);
};

function visualizeThumbnailElement(thumbnailObj,flag,elementType){
    Volt.log("[common-content.js] visualizeThumbnailElement elementType ="+ elementType);
    switch(elementType) {
        case "icon2":
            thumbnailObj.visualizeInformationIcon(flag, "icon2");
            break;
        case "icon1" :
            thumbnailObj.visualizeInformationIcon(flag, "icon1");
            break;
        case "progressbar" :
            thumbnailObj.visualizeThumbnailStyle(flag, CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR);
            break;
        case "checkbox" :
            thumbnailObj.visualizeThumbnailStyle(flag, CommonDefine.ThumbnailStyle.THUMB_STYLE_CHECKBOX);
            break;
        default :
            break;
    }
};

function updateItemUSBIcon(appId, thumbnailObj, option,itemIcon,iconID) {
    Volt.log("[common-content.js] updateItemUSBIcon, appId = " + appId);
    Volt.log("[common-content.js] updateItemUSBIcon, option =" + option);
    Volt.log("[common-content.js] updateItemUSBIcon, itemIcon =" + itemIcon);

    // only mypage will show USB icon
    if (option !== 'mypage') return itemIcon;
    
    var bExistInUSB = voltApiWrapper.checkUsbApp(appId);

    if (bExistInUSB) {
        if(itemIcon){
	        //updateThumbnailInfoIcon(thumbnailObj, Volt.BASE_PATH + "images/" + scene.height + "/g_icon_usb_wh.png", iconID);
    	} else {
    	    itemIcon = addInformationUSBIcon(thumbnailObj,
                            Volt.BASE_PATH + "images/" + scene.height + "/g_icon_usb_wh.png",
                            Volt.BASE_PATH + "images/" + scene.height + "/g_icon_usb_bk.png",
                            iconID);
            var inforAlloc = thumbnailObj.getElementAllocation("information");
            thumbnailObj.setElementAllocation("information-text1", {width: inforAlloc.width - 1920*0.010417 - 1920*0.005208*3 - 32*2});
    	}
    } else {
        itemIcon && visualizeThumbnailElement(thumbnailObj, false, itemIcon.type);
        var inforAlloc = thumbnailObj.getElementAllocation("information");
        thumbnailObj.setElementAllocation("information-text1", {width: inforAlloc.width - 1920*0.010417 - 1920*0.005208*2 - 32});
    }

    return itemIcon;
}

function updateItemIcon(appId, thumbnailObj, option,itemIcon) {
    Volt.log("[common-content.js] updateItemIcon, appId = " + appId);
    Volt.log("[common-content.js] updateItemIcon, option =" + option);
    Volt.log("[common-content.js] updateItemIcon, itemIcon =" + itemIcon);
    
    //thumbnailObj.visualizeInformationIcon(true,"icon1");
    
    var bInstalled = voltApiWrapper.isWidgetInstalled(appId);
    var bHasNewVersion = voltApiWrapper.haveNewVersion(appId);
    var bUpdated = voltApiWrapper.isAppUpdated(appId);
    var bUpdating = voltApiWrapper.isAppUpdating(appId);
    var bInstalling = voltApiWrapper.isWidgetInstalling(appId);
    
    var installedPath = voltApiWrapper.getInstalledPath(appId);
    var bInUSBList = voltApiWrapper.isAppInUSBList(appId);
    
    Volt.log("[common-content.js] updateItemIcon, bInUSBList =" + bInUSBList);
    
    if (installedPath && installedPath.indexOf("/opt/storage/usb/") != -1 && !bInUSBList) {
        voltApiWrapper.addToUSBList(appId, installedPath);
        bInUSBList = true;
    }
    
    var bExistInUSB = false;
    var bRet = voltApiWrapper.checkUsbApp(appId);
    if(bRet){
        bExistInUSB = true;
    }
    Volt.log("[common-content.js] updateItemIcon, bInstalling = " + bInstalling);
    Volt.log("[common-content.js] updateItemIcon, bInstalled = " + bInstalled);
    Volt.log("[common-content.js] updateItemIcon, bExistInUSB = " + bExistInUSB);
    
	if(bInstalled && bUpdated && !bInstalling) {
		Volt.log("[common-content.js] should show update complete icon");
		if(itemIcon){
		    updateThumbnailInfoIcon(thumbnailObj,Volt.BASE_PATH + "images/" + scene.height + "/g_icon_update_comp.png");
		} else {
		    itemIcon = addInformationIcon(thumbnailObj,Volt.BASE_PATH + "images/" + scene.height + "/g_icon_update_comp.png");
		}
	}
	
    if (bHasNewVersion && !bUpdating) {
        Volt.log("[common-content.js] should show update icon");
        if(itemIcon){
            updateThumbnailInfoIcon(thumbnailObj,Volt.BASE_PATH + "images/" + scene.height + "/g_icon_update_need.png");
        } else {
            itemIcon = addInformationIcon(thumbnailObj,Volt.BASE_PATH + "images/" + scene.height + "/g_icon_update_need.png");
        }
    }

	if ((bInstalled && !bUpdating && option != 'mypage')) {
        Volt.log("[common-content.js] updateItemIcon, installedPath =" + installedPath);
        if(itemIcon){
            //itemIcon has been created
            if (installedPath && !bInstalling) {
                if (bInUSBList) {
                    Volt.log("[common-content.js] installed on USB");
                    if (bExistInUSB) {
                        Volt.log("[common-content.js] existInUSB,should show installed icon");
                        updateThumbnailInfoIcon(thumbnailObj,Volt.BASE_PATH + "images/" + scene.height + "/g_icon_download_comp.png");
                    } else {
                        Volt.log("[common-content.js] not existInUSB,should hide installed icon");
                        visualizeThumbnailElement(thumbnailObj,false, itemIcon.type);
                    }
                } else {
                    Volt.log("[common-content.js] installed on memory,should show installed icon");
                    updateThumbnailInfoIcon(thumbnailObj,Volt.BASE_PATH + "images/" + scene.height + "/g_icon_download_comp.png");
                }
            } else {
                Volt.log("[common-content.js] installedPath is null, should hide installed icon");
                visualizeThumbnailElement(thumbnailObj,false,itemIcon.type);
            }

        } else {
            //itemIcon is null
            Volt.log("[common-content.js] itemIcon is null");
            //if(bInUSBList && !bExistInUSB){
            if(installedPath){
                itemIcon = addInformationIcon(thumbnailObj,Volt.BASE_PATH + "images/" + scene.height + "/g_icon_download_comp.png");
            } else {
                Volt.log("[common-content.js] existInUSB,but USB is disconnected,no need to create icon");
                itemIcon = null;
            }
        }
    }
    
    if(!bInstalled && !bUpdating && option != 'mypage'){
        Volt.log("[common-content.js] should hide installed icon");
        if(itemIcon){
            visualizeThumbnailElement(thumbnailObj,false,itemIcon.type);
        }
    }
    
    if(bInstalled && !bHasNewVersion && !bUpdated && option == 'mypage'){
        Volt.log("[common-content.js] should hide update complete icon");
        if(itemIcon){
            visualizeThumbnailElement(thumbnailObj,false,itemIcon.type);
        }
    }
    
    return itemIcon;
}

function createProgressControl(widget, xValue, yValue, width, height) {
	Volt.log("[common-content.js] createProgressControl");
    var progress = new WinsetProgress({
    	nProgressStyle : WinsetProgress.ProgressStyle.Progress_Style_A,
        parent : widget,
        width : width,
        height : height,
        x : xValue,
        y : yValue,
        direction: "horizontal",
        minValue : 0,
        value : 0,
        maxValue : width,
    });
    progress.setProgressColor(255, 255, 255, 153);
	progress.setBackgroundColor(255, 255, 255, 51);

    progress.show();
    return progress;
}

/*   
function updateItemProgress(appId, thumbnailObj, option, progressBarObj){
    Volt.log("[common-content.js] updateItemProgress, " + appId);
    if(voltApiWrapper.isWidgetInstalling(appId)){
        Volt.log("[common-content.js] updateItemProgress, progressBarObj =" + progressBarObj);
        if(progressBarObj){
            //progressBarObj has created
        } else {
            //progressBarObj is null
            progressBarObj = addThumbnailProgressbar(thumbnailObj);
        }
        visualizeThumbnailElement(thumbnailObj,true,"progressbar");
        thumbnailObj.dim(true);
        thumbnailObj.setDimBackgroundColor({r:0, g:0, b:0, a:153});
        thumbnailObj.raiseElement("progressBar");
        thumbnailObj.setProgressRange(0, 100);
        
        var Obj = voltApiWrapper.getWidgetInstallStatus(appId);
        if (Obj != undefined) {
            Volt.log("[common-content.js] updateItemProgress: " + Obj.status + "/" + Obj.progress);
            thumbnailObj.setProgressValue(Obj.status === 'installing' ? 100 : Obj.progress);
        }
    } else {
        if(progressBarObj){
            visualizeThumbnailElement(thumbnailObj,false,"progressbar");
            thumbnailObj.dim(false);
        }
    }
    
    return progressBarObj;
}
*/

function updateItemProgress(appId, thumbnailObj, option){
    Volt.log("[common-content.js] updateItemProgress, " + appId);
    if(voltApiWrapper.isWidgetInstalling(appId)){
        thumbnailObj.visualizeThumbnailStyle(true, CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR);
        
        thumbnailObj.dim(true);
        thumbnailObj.setDimBackgroundColor({r:0, g:0, b:0, a:153});
        thumbnailObj.raiseElement("progressBar");
        thumbnailObj.setProgressRange(0, 100);
        
        var Obj = voltApiWrapper.getWidgetInstallStatus(appId);
        //var rate = 0;
        if (Obj != undefined) {
            Volt.log("[common-content.js] updateItemProgress: " + Obj.status + "/" + Obj.progress);
            thumbnailObj.setProgressValue(Obj.status === 'installing' ? 100 : Obj.progress);
        }
        
    } else {
        thumbnailObj.visualizeThumbnailStyle(false, CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR);
        thumbnailObj.dim(false);
    }
}

function showDeletePopup(bIsMulti, app_ids) {
    Volt.log('[common-content.js] showDeletePopup ' + bIsMulti + ' ' + app_ids);
    var params = {
        "type" : 'delete',
        "app_id" : app_ids,
        "isMulti" : bIsMulti,
    };

    Backbone.history.navigate('popup/' + JSON.stringify(params), {
        trigger : true
    });
/*
    if (bIsMulti == false) {
        voltApiWrapper.unInstallApp(app_ids);
    } else {
        var uninstallAppId = [];
        for ( i = 0; i < app_ids.length; i++) {
            uninstallAppId.push({
                "app" : app_ids[i]
            });
        }

        var ret = voltApiWrapper.unInstallMutilApps(uninstallAppId);
        Volt.log("[common-content.js] unInstallMutilApps() ret : " + ret);
    }
    var voiceGuide = Volt.i18n.t('COM_SID_DELETING_KR_PANEL') + ',' + Volt.i18n.t('TV_SID_PLEASE_WAIT') + ', '
        + Volt.i18n.t('COM_SID_CANCEL')+ ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
    VoiceGuide.getVoiceGuide(voiceGuide);
    */
}

function showInstallPopup(app_id) {
    Volt.log('[common-content.js] showInstallPopup ' + app_id);
    var params = {
        "type" : 'cpinstall',
        "app_id" : app_id,
    };

    Backbone.history.navigate('popup/' + JSON.stringify(params), {
        trigger : true
    });
    voltApiWrapper.installApp(app_id, '', '');
}

function installFail(eventInfo) {
    Volt.log('[common-content.js] installFail, app_id = '+ eventInfo.app_id);
    Mediator.trigger(CommonDefine.Event.DOWNLOAD_CANCELED, eventInfo);
    ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FAIL, eventInfo.app_id, eventInfo.errorCode);
}

function showAppSyncError(eventInfo) {
    Volt.log('[common-content.js] eventInfo:app_id = ' + eventInfo.app_id);
    voltApiWrapper.cancelInstallApp(eventInfo.app_id);
    Mediator.trigger(CommonDefine.Event.DOWNLOAD_CANCELED, eventInfo);
    ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE, eventInfo.app_id);
}

function installApp(app_id, app_size,app_name){
	Volt.log('[common-content.js]app_id = ' + app_id + ' app_size = ' + app_size + ',,,app_name = ' + app_name);
	var bIsStorageEnough = voltApiWrapper.IsStorageEnough(app_size);
	//bIsStorageEnough = false;
	if (bIsStorageEnough) {
		Volt.log('[common-content.js]installApp storage is enough');
		voltApiWrapper.installApp(app_id, '', '', app_size);
        var data = {
            app_id : app_id,
        };
        Mediator.trigger(CommonDefine.Event.BEGIN_DOWNLOAD, data);
	} else {
		Volt.log('[common-content.js] storage is not enough, check usb memory');
		//need refine later
		var UsbStorages = voltApiWrapper.getUsbStorages();
		if(UsbStorages && UsbStorages.storages.length >= 1) {
            Volt.log('UsbStorages.storages.length:::::'+UsbStorages.storages.length);
			if(UsbStorages.storages.length == 1) {
                Volt.log('UsbStorages.storages.length is 1');
				var path = getStoragePath(UsbStorages.storages[0].mountPath);
				Volt.log('[common-content.js] path = ' + path);
				var data = {
		            app_id : app_id
				};
				voltApiWrapper.installApp(app_id, '', path, app_size);
				Mediator.trigger(CommonDefine.Event.BEGIN_DOWNLOAD, data);
			} else {
                Volt.log('Choose Device Popup!!!!!!');
				var params = {
					type : 'choose-device',
					app_name:app_name,
					app_id : app_id,
					app_size : app_size
				};
				/*
				var ChooseDevicePopup = Volt.requireNoContext('app/views/choose-device-popup.js');
				ChooseDevicePopup.show(params);*/
				Volt.log('navigate to Choose-Device Popup!!!!!!');
                Backbone.history.navigate('popup/' + JSON.stringify(params), {
                    trigger : true
                });
			}
		} else {
            Volt.log('UsbStorages is not valid!!!!!!!!!');
        }
	}
}

function chooseUsbPopUpItemPress(app_id, install_path, app_size) {
	Volt.log('[common-content.js]chooseUsbPopUpItemPress, app_id = ' + app_id + ' install_path = ' + install_path);
	var data = {
        app_id : app_id
    };
	voltApiWrapper.installApp(app_id, '', install_path, app_size);
	Mediator.trigger(CommonDefine.Event.BEGIN_DOWNLOAD, data);
}

var getViewType = function() {
	var length = Backbone.history.location.history.length;
    if (length > 0) {
        var currentViewInfo = Backbone.history.location.history[length - 1];
        Volt.log('[common-content.js] getViewType currentViewInfo =' + currentViewInfo.toString());
        var temp = currentViewInfo.split('/')[0];
        if("#popup" == temp){
            temp = currentViewInfo.split('/')[1];
			Volt.log('[common-content.js] getViewType #popup viewType = ' + temp);
        } 
		return temp;
    }
    return null;
};

var getMsgPopupType = function(){
    var length = Backbone.history.location.history.length;
    if (length > 0) {
        var currentViewInfo = Backbone.history.location.history[length - 1];
        Volt.log('[common-content.js] getMsgPopupType currentViewInfo =' + currentViewInfo);
        var type = null;
        var temp = currentViewInfo.split('/')[0];
        if ("#popup" == temp) {
            temp = currentViewInfo.split('/')[1];
            Volt.log('[common-content.js] getMsgPopupType temp =' + temp);
            if("game-controller" == temp){
                type = null;
            } else {
                var params = JSON.parse(temp);
                Volt.log('[common-content.js] getMsgPopupType params.type = ' + params.type);
                type = params.type;
            }
            return type;
        } 
        
        if("#msgpopup" == temp){
            type = getCurrentMSGPopup();
        }
        
        return type;
    }
    return null;
};

var currentMSGPopup = null;
var setCurrentMSGPopup = function(params){
    if(params){
        Volt.log('[common-content.js] setCurrentMSGPopup type =' + params.type);
        if(params.type){
            currentMSGPopup = params.type;
        }
    }
};

var getCurrentMSGPopup = function(){
    return currentMSGPopup;
};

var bDeleteResultPopup = null;
var checkDeleteResultPopup = function() {
    var msgPopupType = getMsgPopupType();
    if (msgPopupType) {
        Volt.log('[common-content.js] checkDeleteResultPopup msgPopupType = ' + msgPopupType);
        //if (CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS == msgPopupType || CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_DELETE == msgPopupType || "delete" == msgPopupType) {
        if ("delete" == msgPopupType) {
            Volt.log('[common-content.js] checkDeleteResultPopup delete result popup ');
            bDeleteResultPopup = {
                type : msgPopupType,
                isResult : true,
            };
        }
    } else {
        bDeleteResultPopup = null;
    }
};

var isDeleteResultPopup = function(){
    return bDeleteResultPopup;
};

var resetDeleteResultPopup = function(param){
    Volt.log('[common-content.js] resetDeleteResultPopup param ='+param);
    bDeleteResultPopup = param;
};

/*
var checkDeleteingPopup = function() {
    var length = Backbone.history.location.history.length;
    if (length > 0) {
        var currentViewInfo = Backbone.history.location.history[length - 1];
        Volt.log('[common-content.js] checkDeleteingPopup currentViewInfo =' + currentViewInfo);
         var temp = currentViewInfo.split('/')[0];
        if ("#popup" == temp) {
            temp = currentViewInfo.split('/')[1];
            var params = JSON.parse(temp);
            Volt.log('[common-content.js] checkDeleteingPopup params.type = ' + params.type);
            
            if ("delete" == params.type ) {
                return true;
            }
        }
    }
    
    return false;
};
*/
var profileColor = null;
var profileColorArray = [{
    num : 0,
    color : Volt.hexToRgb('#667fdc')
}, {
    num : 1,
    color : Volt.hexToRgb('#a0cc55')
}, {
    num : 2,
    color : Volt.hexToRgb('#7e4c86')
}, {
    num : 3,
    color : Volt.hexToRgb('#fbbea7')
}, {
    num : 4,
    color : Volt.hexToRgb('#7ad5b4')
}, {
    num : 5,
    color : Volt.hexToRgb('#cc9e61')
}, {
    num : 6,
    color : Volt.hexToRgb('#72d5d5')
}, {
    num : 7,
    color : Volt.hexToRgb('#d66666')
}, {
    num : 8,
    color : Volt.hexToRgb('#e5dd60')
}, {
    num : 9,
    color : Volt.hexToRgb('#a38d4f')
}];

var getProfileColor = function() {
    return profileColor;
};

var getProfileColorByIndex = function(index){
    Volt.log('[common-content.js] getProfileColorByIndex index = ' + index);
    if(!isNaN(index) && index <= 10){
        profileColor = profileColorArray[index-1].color;
    } else {
        profileColor = profileColorArray[0].color;
    }
    
    return profileColor;
};

var showToolTip = function(paras,template){
    Volt.log('[common-content.js] showToolTip .....paras = ' + JSON.stringify(paras));
    
    var toolTipWidth = HALOUtil.getTextSize(paras.text, 'SamsungSmart_Light 30px').width + 30;
    var toolTipHeight = HALOUtil.getTextSize(paras.text, 'SamsungSmart_Light 30px').height + 38;
    var position = getToolTipPosition(paras,30,toolTipWidth);

    if('up' == paras.direction){
        paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Up;
    }else if('down' == paras.direction){
        paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Down;
    }else if('left' == paras.direction){
        paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Left;
    }else if('right' == paras.direction){
        paras.direction = WinsetToolTip.TooltipStyle.Tooltip_Tail_Right;
    }

    var mustache = {
        x : position.x,
        y:position.y,
        w : toolTipWidth,
        h:toolTipHeight,
        style: paras.direction,
        nResoultionStyle: WinsetToolTip.ResoultionStyle['Resoultion_' + 1080],
        tailPostion:position.tailPostion,
        parent:paras.parent
    };
    if(toolTip){
        hideToolTip();
    }
    toolTip = PanelCommon.loadTemplate(template.toolTip,mustache);
    toolTip.setFont('SamsungSmart_Light 30px');
    toolTip.setFontSize(30);
    toolTip.setFrameColor(64, 64, 64, 0);
    toolTip.setText(paras.text);
    toolTip.show();

    timeOut = Volt.setTimeout(function(){hideToolTip();}, 3000);
};

var hideToolTip = function(){
    Volt.log('[common-content.js] hideToolTip ....');
    if(toolTip){
        toolTip.destroy();
        toolTip = null;
    }

    if(timeOut){
        Volt.clearTimeout(timeOut);
        timeOut = null;
    }
};

var getToolTipPosition = function(paras,fontSize,width){
    var toolTipPosition = {x:0,y:0,tailPostion:'center'};

    switch(paras.direction){
    case 'down':{
        toolTipPosition.y = paras.y - fontSize - 18;			
        toolTipPosition.x  = paras.x + paras.width/2 - width/2;
        break;
    }
    case 'up':{
        toolTipPosition.y = paras.y + paras.height;			
        toolTipPosition.x  = paras.x + paras.width/2 - width/2;
        break;
    }
    case 'left':{
        toolTipPosition.y = paras.y - fontSize/2 + paras.height/2 + 5 ;			
        toolTipPosition.x  = paras.x + paras.width + 14;
        break;
    }
    case 'right':{
        toolTipPosition.y = paras.y - fontSize/2 +paras.height/2 - 5 ;			
        toolTipPosition.x  = paras.x - width - 14;
        break;
    }
    }

    if (toolTipPosition.x + width > Volt.sceneWidth) {
        Volt.log('[common-content.js] getToolTipPosition adjust toolTip position set tailPostion== end');
        toolTipPosition.x = paras.x + paras.width / 2 + Volt.sceneWidth * 0.0109375 - width;
        toolTipPosition.tailPostion = 'end';
    }else if(toolTipPosition.x < 0){
        Volt.log('[common-content.js] getToolTipPosition adjust toolTip position set tailPostion== start');
        toolTipPosition.x = paras.x + paras.width / 2 - Volt.sceneWidth * 0.0109375;
        toolTipPosition.tailPostion = 'start';
    }
    Volt.log('[common-content.js] getToolTipPosition toolTipPosition = ' + JSON.stringify(toolTipPosition));
    return toolTipPosition;  
};

var showRollOver = function(parent, controllerList) {
    Volt.log("[common-content.js] showRollOver width = " + parent.width + " height = " + parent.height);
    if(!controllerList) {
        Volt.log('[common-content.js] showRollOver controller_list - ' + controllerList);
        return;
    }
    var length = controllerList.length;
    Volt.log('[common-content.js] showRollOver controller_list.length - ' + length);
    Volt.log('[common-content.js] showRollOver controller_list - ' + JSON.stringify(controllerList));
    
    var imageArray = new Array();
    var roll_over_url = undefined;
    var available = undefined;
    if(controllerList.at){
        for( var i = 0; i < length; i++){
            available = controllerList.at(i).get('avaliable');
            if(available == 'Y'){
                roll_over_url = controllerList.at(i).get('roll_over_url');
                imageArray.push(roll_over_url);
            }
            Volt.log("~~~~~~~~~~~~~~ controllerList.at(" + i + ").get('roll_over_url') = " + roll_over_url + " available = " + available);
        }
    }else{
        for( var i = 0; i < length; i++){
            available = controllerList[i]['avaliable'];
            if(available == 'Y'){
                roll_over_url = controllerList[i]['roll_over_url'];
                imageArray.push(roll_over_url);
            }
            Volt.log("~~~~~~~~~~~~~~ controllerList[" + i + "]['roll_over_url'] = " + roll_over_url + " available = " + available);
        }
    }
    
    length = imageArray.length;
    Volt.log('[common-content.js] showRollOver controller_list.length - ' + length);
    
    var interval = 8; //76 - 68
    var iconEdgeLength = 68;
    var width = parent.width;
    var height = parent.height;
    var xArray = new Array();
    var yArray = new Array();
    if (length == 1) {
        xArray.push((width - iconEdgeLength) / 2);
        yArray.push((height - iconEdgeLength) / 2);
    } else if (length == 2) {
        xArray.push((width - interval) / 2 - iconEdgeLength);
        yArray.push((height - iconEdgeLength) / 2);
        
        xArray.push((width + interval) / 2);
        yArray.push((height - iconEdgeLength) / 2);
    } else if (length >= 3) {
        xArray.push((width - iconEdgeLength) / 2 - interval - iconEdgeLength);
        yArray.push((height - iconEdgeLength) / 2);
        
        xArray.push((width - iconEdgeLength) / 2);
        yArray.push((height - iconEdgeLength) / 2);
        
        xArray.push((width - iconEdgeLength) / 2 + interval + iconEdgeLength);
        yArray.push((height - iconEdgeLength) / 2);
    } else {
        return;
    }
    
    parent.rollover_animations = [];
    parent.rollover_images = [];
    parent.rollover_timer = [];
    var drawImage = function(i){
        if(i >= xArray.length) {
            parent.rollover_timer[0] = showImage(0, 0);
            parent.rollover_timer[1] = showImage(1, 33);
            parent.rollover_timer[2] = showImage(2, 66);
            return;
        }
        parent.rollover_images[i] = new ImageWidgetEx({
            x : xArray[i] + iconEdgeLength/2,
            y : yArray[i] + iconEdgeLength/2,
            width : 0,
            height : 0,
            parent : parent,
            src : imageArray[i],
        });
        parent.rollover_images[i].onReady = function(){
            Volt.log('[common-content.js] showRollOver ' + i + ' image Ready');
            i++;
            drawImage(i);
        };
    };
    
    var showImage = function(i, delayTime){
        if(i >= xArray.length) {
            return null;
        }
        var timer = Volt.setTimeout(function(){
            Volt.log('[common-content.js] showRollOver ' + i + ' show image');
            try{
                parent.rollover_animations[i] = new MultiObjectTransition();
                parent.rollover_animations[i].setDuration(50);
                parent.rollover_animations[i].AddObjectDestination(parent.rollover_images[i], "x", xArray[i]);
                parent.rollover_animations[i].AddObjectDestination(parent.rollover_images[i], "y", yArray[i]);
                parent.rollover_animations[i].AddObjectDestination(parent.rollover_images[i], "size", {w:iconEdgeLength, h:iconEdgeLength});
                parent.rollover_animations[i].play();
                
                /*
                parent.rollover_animations[i] = new Animation(50);
                parent.rollover_animations[i].addProperty('x', xArray[i]);
                parent.rollover_animations[i].addProperty('y', yArray[i]);
                parent.rollover_animations[i].addProperty('width', iconEdgeLength);
                parent.rollover_animations[i].addProperty('height', iconEdgeLength);
                parent.rollover_images[i].animate(parent.rollover_animations[i], function(){
                    //do noting
                });
                */
            } catch(e){
                Volt.log('[common-content.js] showRollOver ' + i + ' show image error:' + e);
            }
        }, delayTime);
        return timer;
    };
    drawImage(0);
};

var hideRollOver = function(parent) {
    Volt.log('[common-content.js] hideRollOver');
    if(parent.rollover_images) {
        var rollOverCount = parent.rollover_images.length;
        for(var i = 0; i < rollOverCount; i++){
            Volt.log('[common-content.js] hideRollOver ' + i);
            if(parent.rollover_timer && parent.rollover_timer[i]) {
                Volt.clearTimeout(parent.rollover_timer[i]);
                parent.rollover_timer[i] = null;
            }
            if(parent.rollover_animations && parent.rollover_animations[i]) {
                parent.rollover_animations[i].stop();
                parent.rollover_animations[i] = null;
            }
            if(parent.rollover_images && parent.rollover_images[i]) {
                parent.rollover_images[i].destroy();
                parent.rollover_images[i] = null;
            }
        }
    }
    parent.rollover_animations = [];
    parent.rollover_images = [];
    parent.rollover_timer = [];
};

var setBlankStyle = function(rendererInstance,parentWidth, parentHeight){
    rendererInstance.root.color = Volt.hexToRgb('#d4d4d4');
    var blankRightWidget = new WidgetEx({
        x : parentWidth - 1,
        y : 0,
        width : 1,
        height : parentHeight - 1,
        parent : rendererInstance.root,
        color : Volt.hexToRgb('#c9c9c9'),
    });
    var blankBottomWidget = new WidgetEx({
        x : 0,
        y : parentHeight - 1,
        width : parentWidth - 1,
        height : 1,
        parent : rendererInstance.root,
        color : Volt.hexToRgb('#c9c9c9'),
    });
};

var addThumbnailListener = function(thumbnail){
    thumbnail.imgReady = false;
    var thumbListener = new ThumbnailListener;
    
    thumbListener.onImageReady = function(thumbnail, id, success) {
        thumbnail.imgReady = success;
        /*
        if(success){
            var color = thumbnail.getInformationColorPicking();
            var cc = HALOUtil.extractIconColor(color.r, color.g, color.b);
            
            if (cc == HALOUtil.CC_BLACK || (cc == HALOUtil.CC_WHITE && HALOUtil.highContrast)) {
                thumbnail.setInformationRatingImage({
                    onSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_on.png'),
                    offSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_off.png'),
                    halfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_half.png')
                });

            } else if (cc == HALOUtil.CC_WHITE) {
                thumbnail.setInformationRatingImage({
                    onSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_on.png'),
                    offSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_off.png'),
                    halfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_half.png')
                });
            }
        }
        */
    };
    thumbnail.addThumbnailListener(thumbListener);
};

var loadTemplateInWinsetBackgroud = function(template, mustache, parent, isShow){
    var WinsetBackground = Volt.requireNoContext("WinsetUIElement/winsetBackground.js");
    if(parent == null || parent == undefined) {
        parent = template.parent;
        if(parent == null || parent == undefined) {
            parent = scene;
        }
    }
    var winsetWidget = new WinsetBackground({
        parent : parent,
        x : template.x,
        y : template.y,
        width : template.width,
        height : template.height,
        bgColor : template.color,
        style: CommonDefine.Winset.HighContrast_Background,
    });
    var oldWidget = PanelCommon.loadTemplate(template, mustache, winsetWidget, isShow);
    oldWidget.color = Volt.hexToRgb('#000000', 0);
    oldWidget.x = 0;
    oldWidget.y = 0;
    var highContrast = DeviceModel.get('highContrast');
    if(highContrast){
        winsetWidget.color = Volt.hexToRgb('#000000', 100);
    }
    return winsetWidget;
};

/*
var addWidgetExListener = function(widget){
    widget._defaultColor = {
        r : widget.color.r,
        g : widget.color.g,
        b : widget.color.b,
        a : widget.color.a,
    };
    var highContrast = DeviceModel.get('highContrast');
    if(highContrast){
        widget.color = Volt.hexToRgb('#000000', 100);
    }
    if(widgetExListener == null) {
        widgetExListener = new WidgetExListener;
        widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
            Volt.log("[common-content.js] widgetEx onHighContrastChanged:" + flagHighContrast + " defaultColor:" + JSON.stringify(widgetEx._defaultColor));
            if(flagHighContrast) {
                widgetEx.color = Volt.hexToRgb('#000000', 100);
            } else {
                if(widgetEx._defaultColor) {
                    widgetEx.color = widgetEx._defaultColor;
                }
            }
        };
    }
    Volt.log("[common-content.js] addWidgetExListener");
    widget.addWidgetExListener(widgetExListener);
};*/

var updateData = function(data_list, gorupIndex,grid) {
    Volt.log('[common-content.js] updateData');
    var itemCount = grid.itemCount(gorupIndex);
    Volt.log('[common-content.js] updateData itemCount =' + itemCount);
    if (data_list.length > 0) {
        for (var i = 0; i < data_list.length; i++) {
            var thumbnail = data_list.at(i).get('thumbnail_url');
            var title = data_list.at(i).get('game_title');
            var genre = data_list.at(i).get('genre');
            var appId = data_list.at(i).get('app_id');
            var rating = data_list.at(i).get('rating');
            var size = data_list.at(i).get('size');
            var controllerList = data_list.at(i).get('controller_list');
            var downloadAble = data_list.at(i).get('downloadable');
            
            Volt.log('[common-content.js] updateData i =' + i);
            if(i < itemCount){
                var data = grid.getData(gorupIndex, i);
                if (thumbnail)
                    data.imgUrl = thumbnail;
                if (title)
                    data.title = title;
                if (genre)
                    data.genre = genre;
                if (appId)
                    data.app_id = appId;
                if (rating)
                    data.rating = rating;
                if (size)
                    data.size = size;
                if (controllerList)
                    data.controller_list = controllerList;
                if (downloadAble)
                    data.downloadable = downloadAble;
            } else {
                break;
            }
        }
    }
};
    
var createScroll = function(params){
    Volt.log('[common-content.js]  createScroll');
    Volt.log('[common-content.js]  createScroll params =' + JSON.stringify(params));
    //widget, xValue, yValue, height, active, maxValue
    var parent = scene;
    var style = 0;
    var xValue = 0;
    var yValue = 0;
    var width = 0;
    var height = 0;
    var maxValue = 0;
    
    if(params.parent)  parent = params.parent;
    if(params.x) xValue = params.x;
    if(params.y) yValue = params.y;
    if(params.width) width = params.width;
    if(params.height) height = params.height;
    if(params.maxValue) maxValue = params.maxValue;
    if(params.style) style = params.style;
    
    var scroll = new WinsetScroll({
    	style : style,
        parent : parent,
        x : xValue,
        y : yValue,
        width : width,
        height : height,
    });
    if(params.hasOwnProperty('active')) {
        scroll.active = params.active;
    }
    if(CommonDefine.Winset.SCROLL_VERTICAL == style){  
        if (maxValue > 0) {
          var perHeight = height/maxValue;
          scroll.setPointingNormalThumbSize(5, perHeight);
          scroll.setPointingOverThumbSize(21, perHeight);
          scroll.setPointingFocusThumbSize(29, perHeight + height * 0.008333);
        }
        
    } else {
        Volt.log('[common-content.js]  createScroll ---------- horizontal');
        scroll.setTrackShadowHeight(width * 0.000926);
        scroll.setRolloverTrackHeight(width * 0.019444);
        
        scroll.setPointingNormalThumbImage(Volt.getRemoteUrl("images/" + scene.height + "/scroll/keyscreen_scroll_pn.png"));
        scroll.setPointingNormalThumbSize(36, 4);

        scroll.setPointingOverThumbImage(Volt.getRemoteUrl("images/" + scene.height + "/scroll/keyscreen_scroll_po.png"));
        scroll.setPointingOverThumbSize(40, 20);

        scroll.setPointingFocusThumbImage(Volt.getRemoteUrl("images/" + scene.height + "/scroll/keyscreen_scroll_pf.png"));
        scroll.setPointingFocusThumbSize(40, 20); 
        
        if (maxValue > 0){
            scroll.setMinValue(0);
            scroll.setMaxValue(maxValue);
            scroll.setValue(0);
        }
    }
    
    scroll.setTimerOut = function() {
        Volt.log("[common-content.js] scroll setTimerOut - hide scroll after 2 sec");
        scroll.show();
        if (this.timer !== undefined) {
            Volt.clearTimeout(this.timer);
        }
        this.timer = Volt.setTimeout(function() {
            scroll.hide();
        }, 1000 * 2);
    };

    scroll.clearTimeOut = function() {
        Volt.log("[common-content.js] scroll clearTimeOut - hide scroll");
        if (this.timer) {
            Volt.clearTimeout(this.timer);
        }
    };

    return scroll;
};

var setFoverFactor = function (thumbnail,parentWidth) {
    Volt.log('[common-content.js] setFoverFactor parentWidth =' + parentWidth);
    var IC_LINEAR = 0, IC_BEZIER = 1;
    
    switch(parentWidth){
        case parseInt(Volt.sceneWidth * 0.3375) :
            //main-view big image
            thumbnail.setFoveaImageScaleFactor(0.05);
            thumbnail.setFoveaImageInterpolatorType(IC_LINEAR);

            thumbnail.setFoveaInfoBoxScaleFactor(0.02);
            thumbnail.setFoveaInfoBoxInterpolatorType(IC_BEZIER); 
            break;
        case parseInt(Volt.sceneWidth * 0.341667) :
        case parseInt(Volt.sceneWidth * 0.140625) :
        case 292 :
            //detail-view big image,screen shot,videos
            thumbnail.setFoveaImageScaleFactor(0.1);
            thumbnail.setFoveaImageInterpolatorType(IC_LINEAR);
            break;
        case parseInt(Volt.sceneWidth * 0.16875) :
            //main-view common image
            thumbnail.setFoveaImageScaleFactor(0.1);
            thumbnail.setFoveaImageInterpolatorType(IC_LINEAR);
            thumbnail.setFoveaInfoBoxScaleFactor(0.06);
            thumbnail.setFoveaInfoBoxInterpolatorType(IC_BEZIER);
            break;
        default : 
            thumbnail.setFoveaImageScaleFactor(0.1);
            thumbnail.setFoveaImageInterpolatorType(IC_LINEAR);

            thumbnail.setFoveaInfoBoxScaleFactor(0.06);
            thumbnail.setFoveaInfoBoxInterpolatorType(IC_BEZIER); 
            break;
    }
    
    
};

var lastFocusInMainView = null;
var setLastFocusForGrid = function(params){
    Volt.log('[common-content.js] setLastFocusForGrid');
    if (params && params.widget != null && params.widget != undefined) {
        Volt.log('[common-content.js] setLastFocusForGrid params.widget =' + params.widget);
        lastFocusInMainView = params;
    } else {
        Volt.log('[common-content.js] setLastFocusForGrid null');
        lastFocusInMainView = null;
    }
};

var getLastFocusForGrid = function(){
    return lastFocusInMainView;
};

var configXML = null;
var getConfigXML = function(){
    Volt.log('[common-content.js] getConfigXML configXML = ' + configXML);
    var deferred = Q.defer();
    if(configXML == null) {
        var configPath = Volt.getRemoteUrl('config.xml');
        _XMLToJSON(configPath).then(function(obj){
            configXML = obj;
            deferred.resolve(obj);
        });
    } else {
        deferred.resolve(configXML);
    }
    return deferred.promise;
};

var _XMLToJSON = function(xmlFileUrl){
    Volt.log('[common-content.js] _XMLToJSON ..... url = ' + xmlFileUrl);
    var deferred = Q.defer();
    var resourceRequest = new ResourceRequest(xmlFileUrl);
    resourceRequest.method = 'GET';
    resourceRequest.async = true;
    resourceRequest.success = function (data, textStatus, xhr) {
        _parseConfig(data)
        .then(function (obj) {
            deferred.resolve(obj);
        })
        .fail(function (err) {
            deferred.reject(err);
        });
    };
    resourceRequest.error = function (xhr, textStatus, errorStr) {
        deferred.reject(errorStr);
    };
    resourceRequest.process();
    return deferred.promise;
};

var _parseConfig = function(data){
    Volt.log('[common-content.js] _parseConfig ..... data = ' + data);
    var xmlString = data.replace("\ufeff", "");
    var deferred = Q.defer();
    var xml = Volt.requireNoContext('modules/SaxParser.js');
    var obj = {};
    var currentTag = null;
    var parser = new xml.SaxParser(function(cb){
        cb.onEndDocument(function () {
            Volt.log("[common-content.js] onEndDocument obj = " + JSON.stringify(obj));
            deferred.resolve(obj);
        });
        cb.onStartElementNS(function (elem) {
            if(elem == "_name" || elem == "_parent" || elem == "_value"){
                Volt.log("[common-content.js] XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
                return;
            }
            var tag = {
                _name : elem,
                _parent : currentTag
            };
            currentTag = tag;
        });
        cb.onCharacters(function(value){
            if(currentTag && value.indexOf('\n') !== 0) {
                currentTag._value = value;
            } else {
                Volt.log("[common-content.js] onCharacters Invalid Value:" + JSON.stringify(arguments));
            }
        });
        cb.onEndElementNS(function (elem) {
            if(elem == "_name" || elem == "_parent" || elem == "_value"){
                Volt.log("[common-content.js] XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
                return;
            }
            if(currentTag && currentTag._parent) {
                if(currentTag._value) {
                    currentTag._parent[currentTag._name] = currentTag._value;
                } else {
                    currentTag._parent[currentTag._name] = currentTag;
                    delete currentTag._name;
                }
                var p = currentTag._parent;
                delete currentTag._parent;
                currentTag = p;
            } else {
                obj[currentTag._name] = currentTag;
                delete currentTag._name;
                delete currentTag._parent;
            }
        });
        cb.onError(function (msg) {
            deferred.reject(msg);
        });
    });
    parser.parseString(xmlString);
    return deferred.promise;
};

var lastClickID = {};
var isClickable = function(id){
    Volt.log("[common-content.js] isClickable " + id + " = " + lastClickID[id]);
    if(lastClickID[id]) {
        lock_isClickable = false;
        return false;
    } else {
        lastClickID[id] = true;
        Volt.setTimeout(function(){
            Volt.log("[common-content.js] isClickable " + id + " reset");
            lastClickID[id] = false;
        }, 500);
        return true;
    }
};

var getStoragePath = function(mountPath){
    var nIndex = mountPath.indexOf('/');
    var storagePath = '/opt/storage/usb' + mountPath.substring(nIndex);
    return storagePath;
};

var usbConnected = false;
var setUsbState = function(state){
    Volt.log("[common-content.js] setUsbState state =" + state);
    usbConnected = state;
    Volt.first = false;
};

var getUsbState = function(){
    return usbConnected;
};

var herderSettingWidget = null;
var setHeaderSettingWidget = function(widget){
    Volt.log("[common-content.js] setHeaderSettingWidget widget =" + widget);
    if(widget){
        herderSettingWidget = widget;
    }
};

var getHeaderSettingWidget = function(){
    return herderSettingWidget;
};

var bOptionEditNickName = false;
var setOptionEditNickName = function(flag){
    bOptionEditNickName = flag;
};

var getOptionEditNickName = function(){
    return bOptionEditNickName;
};

var bPanelActived = true;
var setPanelActive = function(flag){
    bPanelActived = flag;
};

var getPanelActive = function(){
    return bPanelActived;
};

var mainViewRootWgt = null;
var setMainViewRootWgt = function(widget){
    Volt.log("[common-content.js] setMainViewRootWgt widget =" + widget);
    if(widget){
        mainViewRootWgt = widget;
    }
};

var getMainViewRootWgt = function(){
    return mainViewRootWgt;
};


var bFocusOnMyPageEnded = false;
var setMyPageFocusEnded = function(flag){
    bFocusOnMyPageEnded = flag;
};

var getMyPageFocusEndedFlag = function(){
    return bFocusOnMyPageEnded;
};

exports = {
    onLongPress          : onLongPress,
    onLaunch             : onLaunch,
    updateItemIcon       : updateItemIcon,
    updateItemUSBIcon    : updateItemUSBIcon,
    showDeletePopup      : showDeletePopup,
    showInstallPopup     : showInstallPopup,
    installFail          : installFail,
    installApp           : installApp,

    showAppSyncError     : showAppSyncError,
    getViewType          : getViewType,
    getProfileColor      : getProfileColor,
    
    showRollOver         : showRollOver,
    hideRollOver         : hideRollOver,
    setBlankStyle        : setBlankStyle,
    addThumbnailListener : addThumbnailListener,
    updateData           : updateData,
    showToolTip          : showToolTip,
    hideToolTip          : hideToolTip,
    createScroll         : createScroll,
    setFoverFactor       : setFoverFactor,
    updateItemProgress   : updateItemProgress,
    loadTemplateInWinsetBackgroud : loadTemplateInWinsetBackgroud,
    getProfileColorByIndex      : getProfileColorByIndex,
    chooseUsbPopUpItemPress     : chooseUsbPopUpItemPress,
    onColorPickerForPopupOrText : onColorPickerForPopupOrText,
    createProgressControl       : createProgressControl,
    setLastFocusForGrid         : setLastFocusForGrid,
    getLastFocusForGrid         : getLastFocusForGrid,
    getConfigXML                : getConfigXML,
    isClickable                 : isClickable,
    getOptionMenu               : getOptionMenu,
    getMsgPopupType             : getMsgPopupType,
    setOptionMenu               : setOptionMenu,
    isDeleteResultPopup         : isDeleteResultPopup,
    checkDeleteResultPopup      : checkDeleteResultPopup,
    resetDeleteResultPopup      : resetDeleteResultPopup,
    getStoragePath              : getStoragePath,
    setUsbState                 : setUsbState,
    getUsbState                 : getUsbState,
    setHeaderSettingWidget      : setHeaderSettingWidget,
    getHeaderSettingWidget      : getHeaderSettingWidget,
    setOptionEditNickName       : setOptionEditNickName,
    getOptionEditNickName       : getOptionEditNickName,
    setPanelActive              : setPanelActive,
    getPanelActive              : getPanelActive,
    setMainViewRootWgt          : setMainViewRootWgt,
    getMainViewRootWgt          : getMainViewRootWgt,
    setCurrentMSGPopup          : setCurrentMSGPopup,
    getCurrentMSGPopup          : getCurrentMSGPopup,
    setMyPageFocusEnded         : setMyPageFocusEnded,
    getMyPageFocusEndedFlag     : getMyPageFocusEndedFlag,
};