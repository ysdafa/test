
var lastFocusWidget = null;

var FocusManager = {

    setLastFocus : function(params){
        Volt.log('[focus-manager.js] setLastFocus params.widget =' + params.widget);
        if (params.widget != null && params.widget != undefined) {
            lastFocusWidget = params;
            if (params.widget.id) {
               Volt.log('[focus-manager.js] setLastFocus lastFocusInMainView = ' + params.widget.id);
            }
        }
    },

    getLastFocus : function(){
        return lastFocusWidget;
    },
    
    onFocusIn : function(){
        Volt.log('onFocusIn');
        lastFocusWidget.addEventListener('onFocus', function(){
            //will be called when the widget receives focus.

        });
    },
    
    onFocusOut : function(){
        Volt.log('onfFocusOut');
        lastFocusWidget.addEventListener('OnUnFocus', function(){
            //will be called when the widget receives focus.

        });
    },
    
    hasFocus : function(widget){
        Volt.log('widget hasFocus or not');
        return widget.hasKeyFocus();
    },
    
    clearDefaultFocus : function(){
        Volt.log('clearDefaultFocus......');
        scene.clearKeyFocus();
    },
    
    getDefaultFocus : function(){
        Volt.log('getDefaultFocus......');
        return scene.getKeyFocus();
    },
    
    setDefaultFocus : function(widget){
        Volt.log('setDefaultFocus......');
        scene.setKeyFocus(widget);
    },
    
}

exports = FocusManager;