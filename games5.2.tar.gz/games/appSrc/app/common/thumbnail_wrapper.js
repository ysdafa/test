var CommonDefine = Volt.requireNoContext('app/common/common-define.js');

thumbnail = function(parent, width, height, itemIndex, styleIndex) {
    this.parent = parent;

    this.getStyle = function(width, height, styleIndex) {
        print("[thumbnail_wrapper.js]  styleIndex = " + styleIndex);
        this.width = width;
        this.height = height;

        if (CommonDefine.GridListThumbnailStyle.THUMBNAIL2 == styleIndex) {
            //main category sub view, Thumbnail2
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE | CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO | CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR),
                image : {
                    width : this.width,
                    height : this.width,
                    async : true,
                    src : "",
                    //defaultSrc : Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'),
                    fillMode : "center-crop",
                    //fillMode : 'center',
                },
                information : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : this.height - this.width,
                    enlarge : {
                        factor : 1.5,
                        anchorPoint : "bottom",
                    },
                    text1 : {
                        x : 1920 * 0.010417,
                        y : 1080 * 0.009259,
                        width : this.width - 1920 * (0.010417 + 0.005208) - 32 - 16,
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 26px",
                        text : "",
                        singleLineMode : true,
                        opacity : 153,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    text2 : {
                        x : 1920 * 0.010417,
                        y : (this.height - this.width) - 1080 * (0.025926 + 0.009259),
                        width : this.width - 1920 * (0.010417 * 2 + 0.05625),
                        height : 1080 * 0.025926,
                        font : "SamsungSmart_Medium 20px",
                        text : "",
                        horizontalAlignment : "left",
                        verticalAlignment : 'center',
                        opacity : 102,
                        ellipsize : true,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    rating : {
                        x : this.width - 1920 * 0.010417 * 5 - 17,
                        y : (this.height - this.width) - 1080 * 0.014815 - 17,
                        width : 1920 * 0.010417 * 4 + 17,
                        height : 17,
                        onSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_on.png'),
                        halfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_half.png'),
                        offSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_off.png'),
                        darkOnSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_on.png'),
                        darkHalfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_half.png'),
                        darkOffSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_off.png'),
                        iconWidth : 17,
                        iconHeight : 17,
                        value : 0,
                        gap : 1920 * 0.010417 - 17
                    },
                },
                progressBar : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : 2,
                    backgroundColor : Volt.hexToRgb('#ffffff', 20),
                    progressColor : Volt.hexToRgb('#ffffff', 60),
                    normalThumbSrc : "",
                    focusThumbSrc : "",
                    autoFitWhenEnlarge : true,
                }
            };
        } if (CommonDefine.GridListThumbnailStyle.THUMBNAIL2_NO_NETWORK == styleIndex) {
            //main category sub view, Thumbnail2
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE | CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO | CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR),
                image : {
                    width : this.width,
                    height : this.width,
                    async : true,
                    src : Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'),
                    //fillMode : "center-crop",
                    fillMode : 'center',
                },
                information : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : this.height - this.width,
                    enlarge : {
                        factor : 1.5,
                        anchorPoint : "bottom",
                    },
                    text1 : {
                        x : 1920 * 0.010417,
                        y : 1080 * 0.009259,
                        width : this.width - 1920 * (0.010417 + 0.005208) - 32 - 16,
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 26px",
                        text : "",
                        singleLineMode : true,
                        opacity : 153,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    text2 : {
                        x : 1920 * 0.010417,
                        y : (this.height - this.width) - 1080 * (0.025926 + 0.009259),
                        width : this.width - 1920 * (0.010417 * 2 + 0.05625),
                        height : 1080 * 0.025926,
                        font : "SamsungSmart_Medium 20px",
                        text : "",
                        horizontalAlignment : "left",
                        verticalAlignment : 'center',
                        opacity : 102,
                        ellipsize : true,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    rating : {
                        x : this.width - 1920 * 0.010417 * 5 - 17,
                        y : (this.height - this.width) - 1080 * 0.014815 - 17,
                        width : 1920 * 0.010417 * 4 + 17,
                        height : 17,
                        onSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_on.png'),
                        halfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_half.png'),
                        offSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_off.png'),
                        darkOnSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_on.png'),
                        darkHalfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_half.png'),
                        darkOffSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_off.png'),
                        iconWidth : 17,
                        iconHeight : 17,
                        value : 0,
                        gap : 1920 * 0.010417 - 17
                    },
                },
                progressBar : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : 2,
                    backgroundColor : Volt.hexToRgb('#ffffff', 20),
                    progressColor : Volt.hexToRgb('#ffffff', 60),
                    normalThumbSrc : "",
                    focusThumbSrc : "",
                    autoFitWhenEnlarge : true,
                }
            };
        } else if(CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_ODD == styleIndex){
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE | CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO | CommonDefine.ThumbnailStyle.THUMB_STYLE_CHECKBOX | CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR),
                image : {
                    width : this.width,
                    height : this.width,
                    async : true,
                    defaultSrc : Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'),
                    fillMode : "center-crop",
                    //fillMode : 'center',
                },
                information : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : this.height - this.width,
                    enlarge : {
                        factor : 1.5,
                        anchorPoint : "bottom",
                    },
                    highContrast: {
                        color: Volt.hexToRgb('#0d0d0d', 100),
                    },
                    text1 : {
                        x : 1920 * 0.010417,
                        y : 1080 * 0.009259,
                        width : this.width - 1920 * (0.010417 + 0.005208) - 32 - 16,
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 26px",
                        text : "",
                        singleLineMode : true,
                        opacity : 153,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    text2 : {
                        x : 1920 * 0.010417,
                        y : (this.height - this.width) - 1080 * (0.025926 + 0.009259),
                        width : this.width - 1920 * (0.010417 * 2 + 0.05625),
                        height : 1080 * 0.025926,
                        font : "SamsungSmart_Medium 20px",
                        text : "",
                        horizontalAlignment : "left",
                        verticalAlignment : 'center',
                        opacity : 102,
                        ellipsize : true,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    
                    rating : {
                        x : this.width - 1920 * 0.010417 * 5 - 17,
                        y : (this.height - this.width) - 1080 * 0.014815 - 17,
                        width : 1920 * 0.010417 * 4 + 17,
                        height : 17,
                        onSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_on.png'),
                        halfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_half.png'),
                        offSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_off.png'),
                        darkOnSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_on.png'),
                        darkHalfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_half.png'),
                        darkOffSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_off.png'),
                        iconWidth : 17,
                        iconHeight : 17,
                        value : 0,
                        gap : 1920 * 0.010417 - 17
                    },

                },
                checkBox : {
                    x : (this.width - 138)/2,
                    y : (this.height - 138)/2,
                    width : 138,
                    height : 138,
                    autoCheck: false,
                    checkedSrc : Volt.getRemoteUrl('images/' + scene.height + '/check_ms_tb.png')
                },
                progressBar : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : 2,
                    backgroundColor : Volt.hexToRgb('#ffffff', 20),
                    progressColor : Volt.hexToRgb('#ffffff', 60),
                    normalThumbSrc : "",
                    focusThumbSrc : "",
                    autoFitWhenEnlarge : true,
                }
            };
            
        } else if(CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_EVEV == styleIndex){
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE | CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO | CommonDefine.ThumbnailStyle.THUMB_STYLE_CHECKBOX | CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR),
                image : {
                    width : this.width,
                    height : this.width,
                    async : true,
                    defaultSrc : Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'),
                    fillMode : "center-crop",
                    //fillMode : 'center',
                },
                information : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : this.height - this.width,
                    enlarge : {
                        factor : 1.5,
                        anchorPoint : "bottom",
                    },
                    highContrast: {
                        color: Volt.hexToRgb('#252525', 100),
                    },
                    text1 : {
                        x : 1920 * 0.010417,
                        y : 1080 * 0.009259,
                        width : this.width - 1920 * (0.010417 + 0.005208) - 32 - 16,
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 26px",
                        text : "",
                        singleLineMode : true,
                        opacity : 153,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    text2 : {
                        x : 1920 * 0.010417,
                        y : (this.height - this.width) - 1080 * (0.025926 + 0.009259),
                        width : this.width - 1920 * (0.010417 * 2 + 0.05625),
                        height : 1080 * 0.025926,
                        font : "SamsungSmart_Medium 20px",
                        text : "",
                        horizontalAlignment : "left",
                        verticalAlignment : 'center',
                        opacity : 102,
                        ellipsize : true,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    
                    rating : {
                        x : this.width - 1920 * 0.010417 * 5 - 17,
                        y : (this.height - this.width) - 1080 * 0.014815 - 17,
                        width : 1920 * 0.010417 * 4 + 17,
                        height : 17,
                        onSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_on.png'),
                        halfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_half.png'),
                        offSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_white_off.png'),
                        darkOnSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_on.png'),
                        darkHalfSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_half.png'),
                        darkOffSrc : Volt.getRemoteUrl('images/' + scene.height + '/common/dp_like_star_black_off.png'),
                        iconWidth : 17,
                        iconHeight : 17,
                        value : 0,
                        gap : 1920 * 0.010417 - 17
                    },

                },
                checkBox : {
                    x : (this.width - 138)/2,
                    y : (this.height - 138)/2,
                    width : 138,
                    height : 138,
                    autoCheck: false,
                    checkedSrc : Volt.getRemoteUrl('images/' + scene.height + '/check_ms_tb.png')
                },
                progressBar : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : 2,
                    backgroundColor : Volt.hexToRgb('#ffffff', 20),
                    progressColor : Volt.hexToRgb('#ffffff', 60),
                    normalThumbSrc : "",
                    focusThumbSrc : "",
                    autoFitWhenEnlarge : true,
                }
            };
            
        } else if (CommonDefine.GridListThumbnailStyle.DETAIL_RELATED == styleIndex) {
            //detail view
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE | CommonDefine.ThumbnailStyle.THUMB_STYLE_ICON),
                image : {
                    width : this.width,
                    height : this.height,
                    fillMode : "center-crop",
                    async : true,
                },
                icon1 : {
                    x : 256,
                    y : 8,
                    width : 28,
                    height : 28,
                    clickable : true,
                    unpressSrc : Volt.BASE_PATH + "images/" + scene.height + "/g_thumb_icon_video.png",
                    pressedSrc : Volt.BASE_PATH + "images/" + scene.height + "/g_thumb_icon_video.png",
                    async : true,
                },
                icon2 : {
                    x : 0,
                    y : 108,
                    width : 56,
                    height : 56,
                    clickable : true,
                    unpressSrc : Volt.BASE_PATH + "images/" + scene.height + "/g_thumb_icon_youtube.PNG",
                    pressedSrc : Volt.BASE_PATH + "images/" + scene.height + "/g_thumb_icon_youtube.PNG",
                    async : true,
                },
            };
        } else if (CommonDefine.GridListThumbnailStyle.GAME_CONTROLLER_GUIDE == styleIndex) {
            //game controller guide
        } else if (CommonDefine.GridListThumbnailStyle.COUPON_BOX_VIEW == styleIndex) {//coupon box view
           this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO,
                information : {
                    x : 0,
                    y : 0,
                    width : this.width,
                    height : 1080 * (1 - 0.050926 - 0.02963),
                    color : Volt.hexToRgb('#000000', 0),
                    text1 : {//coupon_title
                        x : 1920 * 0.028125,
                        y : 1080 * 0.050926,
                        width : this.width - 1920 * 0.028125 * 2,
                        height : 1080 * 0.042593 * 2,
                        font : "SamsungSmart_Light 38px",
                        text : "",
                        opacity : 255,
                        singleLineMode : false,
                        ellipsize : false,
                        horizontalAlignment : "left",
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        },
                        autoScroll : false,
                    },
                    text2 : {//valid date
                        x : 1920 * 0.028125,
                        y : 1080 * (0.050926 + 0.042593 * 2 + 0.032407),
                        width : this.width - 1920 * 0.028125 * 2,
                        height : 1080 * 0.022222,
                        font : "SamsungSmart_Light 20px",
                        text : "",
                        opacity : 204,
                        singleLineMode : true,
                        horizontalAlignment : "left",
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        }
                    },
                    icon1 : {
                        x : 0,
                        y : 1080 * 0.219444,
                        width : this.width,
                        height : 1080 * 0.012963,
                        src : Volt.BASE_PATH + "images/" + scene.height + "/g_coupon_line.png",
                        async : true,
                    },
                    text3 : {//guide_message
                        x : 1920 * 0.028125,
                        y : 1080 * (0.050926 + 0.042593 * 2 + 0.032407 + 0.022222 + 0.081484),
                        width : this.width - 1920 * 0.028125 * 2,
                        height : 1080 * 0.033333 * 9,
                        font : "SamsungSmart_Light 26px",
                        text : "",
                        opacity : 255,
                        singleLineMode : false,
                        horizontalAlignment : "left",
                        verticalAlignment : "top",
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "top-left", 
                        },
                        ellipsize : false,
                        autoScroll : false,
                        rowGap : 7,
                    },
                    text4 : {// promo_message
                        x : 1920 * 0.028125,
                        y : 1080 * 0.792593,
                        width : this.width - 1920 * 0.028125 * 2,
                        height : 1080 * 0.022222 * 2,
                        font : "SamsungSmart_Light 20px",
                        text : "",
                        opacity : 255,
                        singleLineMode : false,
                        horizontalAlignment : "center",
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "center", 
                        },
                        ellipsize : false,
                        autoScroll : false,
                    },
                    //games thumbnial
                    icon2 : {
                        //games pic1
                        x : 1920 * 0.028125,
                        y : 1080 * 0.631482,
                        width : 1920 * 0.075,
                        height : 1080 * 0.133333,
                        src : "",
                        async : true,
                    },
                    icon3 : {
                        //games pic2
                        x : 1920 * (0.028125 + 0.075),
                        y : 1080 * 0.631482, //0.726495
                        width : 1920 * 0.075,
                        height : 1080 * 0.133333,
                        src : "",
                        async : true,
                    },
                    icon4 : {
                        //games pic3
                        x : 1920 * (0.028125 + 0.075 * 2),
                        y : 1080 * 0.631482,
                        width : 1920 * 0.075,
                        height : 1080 * 0.133333,
                        src : "",
                        async : true,
                    },
                }

            };
        } else if (CommonDefine.GridListThumbnailStyle.MESSAGE_BOX_VIEW == styleIndex) {//message box view

        } else if (CommonDefine.GridListThumbnailStyle.MYPAGE_LEFT_MESSAGE == styleIndex) {
            print("[thumbnail_wrapper.js]  MYPAGE_LEFT_MESSAGE");
            //mypage left
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO),
                information : {
                    x : 0,
                    y : 0,
                    width : this.width,
                    height : this.height,
                    color : Volt.hexToRgb('#000000', 0),
                    highContrast: {
                        color: Volt.hexToRgb('#0d0d0d', 100),
                    },
                    icon1: {
                        //message image
                        x : this.width / 2 - 30,
                        y : this.height / 2 - 1080 * 0.005556 - 60,
                        width : 60,
                        height : 60,
                        src : "",
                        async : true,
                    },
                    icon2 :{
                        //message num image
                        x : this.width / 2 + 1920 * 0.006771 - 1,
                        y : this.height / 2 - 1080 * 0.002778 * 3 - 60,
                        width : 31,
                        height : 31,
                        src : Volt.BASE_PATH + "images/" + scene.height + "/g_icon_massage_num.png",
                        async : true,
                    },
                    text1 : {
                        // Message
                        x : 1920 * 0.010417,
                        y : this.height / 2,
                        width : this.width - 1920 * 0.01041 * 2,
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 28px",
                        text : "",
                        textColor : Volt.hexToRgb('#ffffff'),
                        singleLineMode : true,
                        horizontalAlignment : "center",
                        opacity : 255,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "center", 
                        }
                    },
                    text2 : {
                        //message num text
                        x : this.width / 2 + 1920 * 0.006771 - 1,
                        y : this.height / 2 - 1080 * 0.002778 * 3 - 60,
                        width : 31,
                        height : 1080 * 0.028704,
                        text : "",
                        textColor : Volt.hexToRgb('#000000'),
                        font : "SamsungSmart_Light 22px",
                        singleLineMode : true,
                        horizontalAlignment : 'center',
                        opacity : 255,
                    }
                }
            };

        } else if (CommonDefine.GridListThumbnailStyle.MYPAGE_LEFT_COUPON == styleIndex) {
            print("[thumbnail_wrapper.js]  MYPAGE_LEFT_COUPON");
            //mypage left
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO),
                information : {
                    x : 0,
                    y : 0,
                    width : this.width,
                    height : this.height,
                    color : Volt.hexToRgb('#000000', 0),
                    highContrast: {
                        color: Volt.hexToRgb('#252525', 100),
                    },
                    icon1: {
                        //coupon image
                        x : this.width / 2 - 30,
                        y : this.height / 2 - 1080 * 0.005556 - 60,
                        width : 60,
                        height : 60,
                        src : "",
                        async : true,
                    },
                    text1 : {
                        //Coupon
                        x : 1920 * 0.010417,
                        y : this.height / 2,
                        width : this.width - 1920 * 0.01041 * 2,
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 28px",
                        text : "",
                        textColor : Volt.hexToRgb('#ffffff'),
                        singleLineMode : true,
                        horizontalAlignment : "center",
                        opacity : 255,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "center", 
                        }
                    },
                }
            };

        } else if (CommonDefine.GridListThumbnailStyle.MYPAGE_PROFILE == styleIndex) {
            print("[thumbnail_wrapper.js]  my page left view - profile");
            //mypage left
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO),
                information : {
                    x : 0,
                    y : 0,
                    width : this.width,
                    height : this.height,
                    color : Volt.hexToRgb('#000000', 0),
                    highContrast: {
                        color: Volt.hexToRgb('#353535', 100),
                    },
                    text1 : {
                        // nick name
                        x : 1920 * 0.010417,
                        y : 1080 * (0.087037 + 0.024074) + 160,
                        width : this.width - 2 * (1920 * 0.010417),
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 28px",
                        text : "",
                        textColor : Volt.hexToRgb('#ffffff'),
                        singleLineMode : true,
                        horizontalAlignment : "center",
                        opacity : 255,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "center",
                        }
                    },
                    text2 : {
                        //email address
                        x : 1920 * 0.010417,
                        y : 1080 * (0.087037 + 0.024074 + 0.033333) + 160,
                        width : this.width - 2 * (1920 * 0.010417),
                        height : 1080 * 0.033333,
                        text : "",
                        textColor : Volt.hexToRgb('#ffffff'),
                        font : "SamsungSmart_Light 20px",
                        singleLineMode : true,
                        horizontalAlignment : 'center',
                        opacity : 255,
                        enlarge : {
                            factor : 1.5,
                            anchorPoint : "center", 
                        }
                    }
                }
            };

        } else if (CommonDefine.GridListThumbnailStyle.DETAIL_SCREEN_SHOT == styleIndex) {
            //detail view for screen shot
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE),
                image : {
                    defaultSrc : Volt.BASE_PATH + "images/" + scene.height + "/icon_blank_thumbnail.png",
                    width : this.width,
                    height : this.height,
                    fillMode : "center-crop",
                    async : true,
                }
            };
        } else if (CommonDefine.GridListThumbnailStyle.DETAIL_BIG_THUMBNAIL == styleIndex) {
            //detail view for big thumbnail
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE | CommonDefine.ThumbnailStyle.THUMB_STYLE_ICON),
                image : {
                    defaultSrc : Volt.BASE_PATH + "images/" + scene.height + "/icon_blank_thumbnail.png",
                    width : this.width,
                    height : this.height,
                    fillMode : "center-crop",
                    async : true,
                },
                icon1 : {
                    x : this.width - 40,
                    y : 8,
                    width : 32,
                    height : 32,
                    unpressSrc : Volt.BASE_PATH + "images/" + scene.height + "/g_thumb_icon_video.png",
                    pressedSrc : Volt.BASE_PATH + "images/" + scene.height + "/g_thumb_icon_video.png",
                    async : true,
                }
            };
        } else if(CommonDefine.GridListThumbnailStyle.THUMBNAIL4 == styleIndex){
            //Thumbnail 4
        } else if (CommonDefine.GridListThumbnailStyle.THUMBNAIL_SELECT_GAMES == styleIndex) {
            //main category sub view, Thumbnail2
            this.thumbStyle = {
                width : this.width,
                height : this.height,
                visibleStyles : (CommonDefine.ThumbnailStyle.THUMB_STYLE_IMAGE | CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO),
                image : {
                    width : this.width,
                    height : this.width,
                    async : true,
                    src : "",
                    //defaultSrc : Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'),
                    fillMode : "center-crop",
                    //fillMode : 'center',
                },
                information : {
                    x : 0,
                    y : this.width,
                    width : this.width,
                    height : this.height - this.width,
                    text1 : {
                        x : Volt.sceneWidth * 0.010417,
                        y : 1080 * 0.009259,
                        width : this.width - Volt.sceneWidth * (0.010417 + 0.005208) - 32 - 16,
                        height : 1080 * 0.033333,
                        font : "SamsungSmart_Light 26px",
                        text : "",
                        singleLineMode : true,
                        opacity : 153,
                    },
                    text2 : {
                        x : Volt.sceneWidth * 0.010417,
                        y : (this.height - this.width) - 1080 * (0.025926 + 0.009259),
                        width : this.width - Volt.sceneWidth * (0.010417 * 2 + 0.05625),
                        height : 1080 * 0.025926,
                        font : "SamsungSmart_Medium 20px",
                        text : "",
                        horizontalAlignment : "left",
                        verticalAlignment : 'center',
                        opacity : 102,
                        ellipsize : true,
                    },
                },
            };
        }
    };

    this.setStyle = function(styleIndex, parentWidth, parentHeight, flagAni) {
        this.getStyle(parentWidth, parentHeight, styleIndex);
        this.prototype.setThumbnailStyle(this.thumbStyle, flagAni);
    };

    this.getStyle(width, height, styleIndex);

    this.prototype = new Thumbnail(this.thumbStyle);
    this.prototype.setStyleTransAnimation(330);
    this.prototype.setScaleAnimation(330);
    /*if (styleIndex == 2) {
     this.prototype.setInformationTextScrollAttribute("text3", {
     duration: 5000,
     delay: 0,
     repeat: -1,
     scrollType: "start_outside_stop_outside",
     direction: "backward"
     });
     }*/
};
exports = thumbnail;
