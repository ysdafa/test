
var Backbone = Volt.requireNoContext('lib/volt-backbone.js'),
    _ = Volt.requireNoContext("modules/underscore.js")._;

EventMediator = _.extend({}, Backbone.Events);

exports = EventMediator;