var _              = Volt.requireNoContext("modules/underscore.js")._;
var voltapi        = Volt.requireNoContext("voltapi.js");
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var CommonFucntion = Volt.requireNoContext('app/common/common-function.js');
var EventMediator  = Volt.requireNoContext('app/common/event-mediator.js');
var Utils          = Volt.requireNoContext('app/common/utils.js');

var installList    = [];
var nativeGameList = [];
var needUpdateList = [];
var updatingList   = [];
var updatedList    = [];
var installedInUSBList = [];
var unInstallList = [];
var bWasInitStatus = false;
var wrapperSelf    = null;
var bUSBConnect = false;
var bUSBDisconnect = false;
var usbArguments = null;
var bAppChanged = false;
var appList = [];

var VoltApiWrapper = (function() {
    exports = {
        init : function() {
            Volt.log('[voltapi-wrapper.js] init.......');
            wrapperSelf = this;
            EventMediator.on(CommonDefine.Event.WAS_READY, _.bind(this.onWASInitialized,this)); 
        },

        onWASInitialized : function(){
            Volt.log('[voltapi-wrapper.js]receive WAS_READY:::'+bWasInitStatus);
            if(!bWasInitStatus){
                bWasInitStatus = true;
                this.registAppInstallEvent();
                this.initSSOAccountInfo();
                this.subscribeSSOStateChange();
                this.getUpdateAppList();
                this.getUSBGameList();
                this.removeUnInstallList();
                EventMediator.on(CommonDefine.Event.USB_CONNECT, this.onUSBConnect,this);
                EventMediator.on(CommonDefine.Event.USB_DISCONNECT, this.onUSBDisconnect,this);
                //EventMediator.on(CommonDefine.Event.GAMES_EXIT, this.exit, this);
            }
        },
        
        exit : function(){
            EventMediator.off(CommonDefine.Event.USB_CONNECT, null, this);
            EventMediator.off(CommonDefine.Event.USB_DISCONNECT, null, this);
            //EventMediator.off(CommonDefine.Event.GAMES_EXIT, null, this);
        },

        checkInitStatus : function() {
            return bWasInitStatus;
        },
        
        hasInstalledApps : function(mountPath){
            Volt.log('[voltapi-wrapper.js] hasInstalledApps: mountPath = ' + mountPath);
            for(var index = 0;index < installedInUSBList.length;index++){
                var installedPath = installedInUSBList[index].install_path;
                var pos = installedPath.indexOf("SmartTV");
                var temp = installedPath.substring(0,pos -1)
                Volt.log('[voltapi-wrapper.js] hasInstalledApps: temp = ' + temp);
                if(mountPath == temp){
                    return true;
                }                
            }
            
            return false;
        },
        
        onUSBConnect : function(arguments){
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            bUSBConnect = true;
            bUSBDisconnect = false;
            Volt.log('[voltapi-wrapper.js] onUSBConnect,arguments= ' + JSON.stringify(arguments));
            usbArguments = arguments;
            
            var deviceInfo = JSON.stringify(arguments);
            deviceInfo = deviceInfo.replace("$USB_DIR", '/opt/storage/usb');
            
            var data = JSON.parse(deviceInfo);
            var storage = data[0].storage;
            Volt.log("[voltapi-wrapper.js] onUSBConnect - mountPath = " + storage.mountPath);
            Volt.log("[voltapi-wrapper.js] onUSBConnect - id = " + storage.id);
            
            this.getUSBGameList();
                        
            if(installedInUSBList.length > 0){
                Volt.log('[voltapi-wrapper.js] onUSBConnect, check hasInstalledApps ');
                var flag = this.hasInstalledApps(storage.mountPath);
                if(!flag){
                    Volt.log('[voltapi-wrapper.js] onUSBConnect,installedInUSBList is not null but this USB has no installed games,CONNECT_USB');
                    EventMediator.trigger(CommonDefine.Event.CONNECT_USB, usbArguments);
                    bUSBConnect = false;
                } else {
                    // when inserUSB, event of appChanged will be received before connectUSB
                    if (bUSBConnect && bAppChanged) {
                        Volt.log('[voltapi-wrapper.js] onUSBConnect,this USB have installed games,CONNECT_USB');
                        EventMediator.trigger(CommonDefine.Event.CONNECT_USB, usbArguments);
                        bUSBConnect = false;
                        bAppChanged = false;
                        return;
                    }
                }
            } else {
                Volt.log('[voltapi-wrapper.js]onUSBConnect, installedInUSBList is null,this USB has no installed games, CONNECT_USB');
                EventMediator.trigger(CommonDefine.Event.CONNECT_USB, usbArguments);
                bUSBConnect = false;
            }
        },
        
        onUSBDisconnect : function(arguments){
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            bUSBConnect = false;
            bUSBDisconnect = true;
            Volt.log('[voltapi-wrapper.js] onUSBDisconnect,arguments= ' + JSON.stringify(arguments));
            usbArguments = arguments;
            
            if(installedInUSBList.length == 0){
                Volt.log('[voltapi-wrapper.js] installedInUSBList is null,this USB has no installed games, DISCONNECT_USB');
                EventMediator.trigger(CommonDefine.Event.DISCONNECT_USB, usbArguments);
                bUSBDisconnect = false;
            } else {
                var deviceInfo = JSON.stringify(arguments);
                deviceInfo = deviceInfo.replace("$USB_DIR", '/opt/storage/usb');

                var data = JSON.parse(deviceInfo);
                var storage = data[0].storage;
                Volt.log("[voltapi-wrapper.js] onUSBDisconnect - mountPath = " + storage.mountPath);
                Volt.log("[voltapi-wrapper.js] onUSBDisconnect - id = " + storage.id);
                var flag = this.hasInstalledApps(storage.mountPath);
                if(!flag){
                    Volt.log("[voltapi-wrapper.js]onUSBDisconnect, installedInUSBList is not null, this USB has no installed games, DISCONNECT_USB");
                    EventMediator.trigger(CommonDefine.Event.DISCONNECT_USB, usbArguments);
                    bUSBDisconnect = false;
                }
            }
        },
        
        onWASAppChanged: function(){
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            Volt.log('[voltapi-wrapper.js] receive event ==> app has been changed ' + JSON.stringify(arguments));
            EventMediator.trigger(CommonDefine.Event.MEMORY_APP_CHANGE);
            EventMediator.trigger(CommonDefine.Const.UPDATE_ITEMS,"memoryAppChange");
            
            if(installedInUSBList.length > 0){
                bAppChanged = true;
                if (bUSBConnect && bAppChanged) {
                    Volt.log('[voltapi-wrapper.js] onWASAppChanged CONNECT_USB');
                    //this.getNativeGameList();
                    EventMediator.trigger(CommonDefine.Event.CONNECT_USB, usbArguments);
                    bUSBConnect = false;
                    bAppChanged = false;
                }

                if (bUSBDisconnect && bAppChanged) {
                    Volt.log('[voltapi-wrapper.js] onWASAppChanged DISCONNECT_USB');
                    EventMediator.trigger(CommonDefine.Event.DISCONNECT_USB, usbArguments);
                    bUSBDisconnect = false;
                    bAppChanged = false;
                }
            }
        },

        registAppInstallEvent : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            Volt.log("[voltapi-wrapper.js] registAppInstallEvent");
            voltapi.WAS.addEventListener(CommonDefine.WAS.WAS_EVENT_CRASH, _.bind(this.wasCrashCallback,this));
            
            //register install related event
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOADING,        
                                        _.bind(this.downloadProgressCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_COMPLETED, 
                                        _.bind(this.downloadCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALLING,         
                                        _.bind(this.installProgressCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_COMPLETED,  
                                        _.bind(this.installCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_CANCLE_COMPLETED, 
                                        _.bind(this.downloadCanceledCallBack,this));

            //register fail event
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOT_EXIST, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NOSPACE, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_LICENSE_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_SERVER_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NETWORK_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_OTHERS, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_EXIST, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_PKGMGR_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_LICENSE_ERROR, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_OTHERS, 
                                        _.bind(this.installErrorCallback,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE,
                                        _.bind(this.installErrorCallback,this));
                                        /*
            voltapi.WAS.addEventListener(111,
                                        _.bind(this.installErrorCallback,this));   
                                        */
           //add by ZK 20150115 begin
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_NO_UPDATED_VERSION,
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NO_INSTALL_DIR, 
                                        _.bind(this.installErrorCallback, this));
            /*voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_CANCLE_FAILED, 
                                        _.bind(this.installErrorCallback, this));*/
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_USB_PATH_NOT_EXIST, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_USB_INSTALL_NOT_SUPPORT, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_EXTRACT_FILES, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_INSTALL_APP, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_SPACE_NOT_ENOUGH, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_USB_SPACE_NOT_ENOUGH, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_INVALID_APP_TYPE, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_VD_MOUNT_TOOL_ERROR, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_APP_IS_INSTALLING, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_INPUT_PARAMETER, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_MOVE_DIR, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_COPY_FILES, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_TEMP_DIR_NOT_EXIST, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_FAIL_UNKNOW_INSTALL_TYPE, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_INSTALL_FAIL_REQUEST_LICENSE_FAILED, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_INSTALL_INSTALL_FAIL_APP_COUNTRY_NOT_SUPPORT, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_DECRYPY_CONFIG, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_ICON_URL_IS_EMPTY, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_DOWNLOAD_ICON, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_DOWNLOAD_APP, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_APP_NOT_EXIST, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_INPUT_PARAMETER, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_MOVE_DIR, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_UNZIP_FILES, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_NO_LICENSE_FILE, 
                                        _.bind(this.installErrorCallback, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_DOWNLOAD_FAIL_TEMP_DIR_NOT_EXIST, 
                                        _.bind(this.installErrorCallback, this));
            //add by ZK 20150115 end
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_SSO_STATE_CHANGE, 
                                        _.bind(this.ssoStateChangeCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_REQUEST_APP_LIST, 
                                        _.bind(this.saveUpdateList,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_SSO_SHOW_POPUP, 
                                        _.bind(this.showPopupCallback, this));
            
            //uninstall event
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALLING, 
                                        _.bind(this.unInstallingCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_COMPLETED, 
                                        _.bind(this.unInstallCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_EXIST, 
                                        _.bind(this.unInstallErrorCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_FAIL_PKGMGR_ERROR, 
                                        _.bind(this.unInstallErrorCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_REMOVABLE, 
                                        _.bind(this.unInstallErrorCallBack,this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_FAIL_OTHERS, 
                                        _.bind(this.unInstallErrorCallBack,this));
                                        
            //add by ZK 20150115 begin
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_CANCLE_COMPLETED, 
                                        _.bind(this.unInstallingCallBack, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_CANCLE_FAILED, 
                                        _.bind(this.unInstallErrorCallBack, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_UNINSTALL_FAIL_SMRATHUB_NOT_RUNNING, 
                                        _.bind(this.unInstallErrorCallBack, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_MULTI_UNINSTALL_COMPLETED,   
                                        _.bind(this.unInstallingCallBack, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_MULTI_UNINSTALL_FAILED, 
                                        _.bind(this.unInstallErrorCallBack, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_MULTI_UNINSTALL_CANCEL_COMPLETED, 
                                        _.bind(this.unInstallingCallBack, this));
            voltapi.WAS.addEventListener(voltapi.WAS.WAS_EVENT_MULTI_UNINSTALL_CANCEL_FAILED, 
                                        _.bind(this.unInstallErrorCallBack, this)); 
            //add by ZK 20150115 end                            
            
            /*vonf events*/                
            voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_WAS_APP_CHANGE,
                    _.bind(this.onWASAppChanged, this));
            
        },
        
        wasCrashCallback: function (eventType, data1) {
            Volt.log("[voltapi-wrapper.js] wasCrashCallback eventType: " + eventType);
            Volt.log("[voltapi-wrapper.js] wasCrashCallback data1: " + JSON.stringify(data1));
            var i = 0;
            var data = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] wasCrashCallback data.result: " + data.result);
            if (-1 != data.result) {
                Volt.log('WAS do not have exceptional!!!!');
                return;
            }
            wrapperSelf.installExceptional(data, eventType);
            wrapperSelf.uninstallExceptional(data, eventType);
        },
        
        installExceptional: function(data, eventType){
            Volt.log('[voltapi-wrapper.js]installExceptional');
            for ( i = 0; i < installList.length; i++) {
                if (installList[i].appID !== undefined) {
                    Volt.log("[voltapi-wrapper.js] wasCrashCallback installing appID is " + installList[i].appID);
                    var param = {
                        "app_id" : installList[i].appID,
                        "result" : data.result,
                    };
                    wrapperSelf.installErrorCallback(eventType, JSON.stringify(param),null);
                }
            }
        },
        
        uninstallExceptional: function(data, eventType){
            Volt.log('[voltapi-wrapper.js]uninstallExceptional');
            for ( i = 0; i < unInstallList.length; i++) {
                if (unInstallList[i].appID !== undefined) {
                    Volt.log("[voltapi-wrapper.js] wasCrashCallback unInstallList appID is " + unInstallList[i].appID);
                    var param = {
                        "app_id" : unInstallList[i].appID,
                        "result" : data.result,
                    };
                    wrapperSelf.unInstallErrorCallBack(eventType, JSON.stringify(param),null);
                }
            }
        },

        installApp : function(appID, packet_path, install_path, app_size) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            Volt.log('installApp::===>app_size:::'+app_size + ",install_path " + install_path);
            if (!wrapperSelf.isWidgetInstalling(appID)) {
                wrapperSelf.addInstallList(appID, install_path, app_size);
                
                var bExistInUSBList = wrapperSelf.isAppInUSBList(appID);
                if (bExistInUSBList) {
                    wrapperSelf.removeFromUSBList(appID);
                }
                
                //if installed on USB,install_path is not null
                if (install_path && install_path.length > 0) {
                    wrapperSelf.addToUSBList(appID, install_path, app_size);
                }
                
                var bRet = voltapi.WAS.installApp(appID, packet_path, install_path);
                Volt.log("[voltapi-wrapper.js]request installApp " + appID + " result " + bRet + " install_path = " + install_path+' app_size ='+app_size);
                return bRet;
            } else {
                Volt.log("[voltapi-wrapper.js]don't request install this app this time " + appID);
                return false;
            }
        },

        cancelInstallApp : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            if (wrapperSelf.isWidgetInstalling(appID)) {
                Volt.log("[voltapi-wrapper.js] cancelInstallApp(" + appID +")");
                wrapperSelf.removeInstallList(appID);
                if (wrapperSelf.isAppInUSBList(appID)) {
                    wrapperSelf.removeFromUSBList(appID);
                }
                var bRet = voltapi.WAS.cancelInstallApp(appID);
                return bRet;
            }
        },

        unInstallApp : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            wrapperSelf.removeUnInstallList();
            var bRet = voltapi.WAS.unInstallApp(appID);
            wrapperSelf.addToUnInstallList(appID);
            Volt.log("[voltapi-wrapper.js] unInstallApp(" + appID + ") " + bRet);
            return bRet;
        },
        
        addToUnInstallList : function(appID){
            Volt.log("[voltapi-wrapper.js] addToUnInstallList " + appID);

            var findObj = _.find(unInstallList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                unInstallList.push(newObj);
                Volt.log("[voltapi-wrapper.js] unInstallList " + unInstallList);
            }
        },
        
        removeFromUnInstallList : function(appID){
            Volt.log("[voltapi-wrapper.js] removeFromUnInstallList(" + appID + ")");

            var findObj = _.find(unInstallList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(unInstallList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                unInstallList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove unInstallList, length:::'+unInstallList.length);
            }
        },
        
        removeUnInstallList : function(){
            unInstallList = [];
        },

        updateApp : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            if (!wrapperSelf.isAppUpdating(appID)) {
                wrapperSelf.addInstallList(appID);
                wrapperSelf.removeUpdateGame(appID);//remove needUpdateList and push into UpdatingList
                wrapperSelf.pushUpdatingList(appID);
                var bRet = voltapi.WAS.updateApp(appID);
                Volt.log("[voltapi-wrapper.js] updateApp() " + bRet);
            }
            return bRet;
        },

        launchApp : function(appID, payload) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            if(wrapperSelf.getGameTermStatus() == false) {
				Volt.log('[voltapi-wrapper.js] launchApp did not agree game terms');
                wrapperSelf.showGameTermsPopup();
        	} else {
                var bRet = voltapi.WAS.launchApp(appID, payload);
	            Volt.log("[voltapi-wrapper.js] launchApp(" + appID + ") " + bRet);
	            if(0 == bRet){
                    wrapperSelf.addEventLog('PLAYGAME',{cp : '',appid:appID,});
	                if(!wrapperSelf.haveNewVersion(appID) && wrapperSelf.isAppUpdated(appID)){
	                    Volt.log("[voltapi-wrapper.js] launchApp,newest version need remove updated icon, appID = " + appID);
	                    wrapperSelf.removeUpdatedGame(appID);
	                }
	            }
	            
	            return bRet;
        	}
        },

        addEventLog : function(eventName,options){
            Volt.log('[voltapi-wrapper.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
            //add Event log
            if(!eventName){
                return;
            }
            Volt.KPIMapper.addEventLog(eventName, {d : options});
        },
        //for app install status
        isWidgetInstalled : function(appID) {//didn't implemented
            if(!bWasInitStatus){
                Volt.log('[voltapi-wrapper.js] WAS Wrapper is not initialed');
                return;
            }
            
            var bRet = wrapperSelf.getAppInfo(appID);
            if (bRet != undefined && bRet != -1 && bRet != false) {
                return true;
            }
            
            return false;
        },
        
        isWidgetInstalledInUSB : function(appID){
            if(!bWasInitStatus){
                Volt.log('[voltapi-wrapper.js] WAS Wrapper is not initialed');
                return;
            }
            
            var bRet = wrapperSelf.getAppInfo(appID);
            if(bRet != undefined && bRet != -1 && bRet != false && bRet.app_installed_path && bRet.app_installed_path.indexOf("/opt/storage/usb/") != -1){
                return true;
            }
            return false;
        },
        
        checkUsbApp :function(appID){
            if(!bWasInitStatus){
                Volt.log('[voltapi-wrapper.js] WAS Wrapper is not initialed');
                return false;
            }
            var bRet = voltapi.WAS.checkUsbApp(appID);
            Volt.log('[voltapi-wrapper.js] checkUsbApp bRet ='+ bRet);
            if (bRet != undefined && bRet != -1) {
                return true;
            }
            
            return false;
        },
        
        unInstallMutilApps : function(uninstallAppId){
            if(!bWasInitStatus){
                Volt.log('[voltapi-wrapper.js] WAS Wrapper is not initialed');
                return;
            }
            Volt.log("[voltapi-wrapper.js] unInstallMutilApps uninstallAppId.length : " + uninstallAppId.length);
            wrapperSelf.removeUnInstallList();
            for ( var i = 0; i < uninstallAppId.length; i++) {
                wrapperSelf.addToUnInstallList(uninstallAppId[i].app);
            }
            
            var bRet = voltapi.WAS.mutilUnInstallApps(uninstallAppId);
            Volt.log("[voltapi-wrapper.js] voltapi.WAS.mutilUnInstallApps() bRet : " + bRet);
            return bRet;
        },
        
        cancelUnInstallMutilApps : function(){
            if(!bWasInitStatus){
                Volt.log('[voltapi-wrapper.js] WAS Wrapper is not initialed');
                return;
            }
            var bRet = voltapi.WAS.cancelMutilUnInstallApps();
            wrapperSelf.removeUnInstallList();
            Volt.log("[voltapi-wrapper.js] voltapi.WAS.mutilUnInstallApps() bRet : " + bRet);
            return bRet;
        },

        getAppInfo : function(appID) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var ret = voltapi.WAS.getAppInfo(appID);
            Volt.log("[voltapi-wrapper.js] getAppInfo" + appID + " " + ret);
            //Volt.log('[voltapi-wrapper.js] getAppInfo = ' + JSON.stringify(ret));
            return ret;
        },
        
        getInstalledPath : function(appID){
            if(!bWasInitStatus){
                Volt.log('[voltapi-wrapper.js] WAS Wrapper is not initialed');
                return null;
            }
            
            var bRet = wrapperSelf.getAppInfo(appID);
            
            if(bRet != undefined && bRet != -1 && bRet != false){
                Volt.log('[voltapi-wrapper.js] bRet.app_installed_path ='+ bRet.app_installed_path);
                if(bRet.app_installed_path){
                    return bRet.app_installed_path;
                }
            }
            return null;
        },

        getWidgetInstallStatus : function(appID) {
            if(!bWasInitStatus){
                Volt.log('[voltapi-wrapper.js] WAS Wrapper is not initialed');
                return;
            }
            
            if (wrapperSelf.isWidgetInstalling(appID)) {
                var findObj = _.find(installList, function(obj) {
                    if (obj.appID === appID) {
                        return obj;
                    }
                });
                return findObj;
            }
        },

        isWidgetInstalling : function(appID) {
            Volt.log('[voltapi-wrapper.js]isWidgetInstalling: ', installList);
            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined && (findObj.status === 'downloading' || findObj.status === 'installing')) {
                Volt.gamesInstallAppPath = findObj.install_path;
                Volt.log("[voltapi-wrapper.js] this widget is Installing" + appID);
                return true;
            } else {
                Volt.log("[voltapi-wrapper.js] this widget is not installing" + appID);
                return false;
            }
        },
        //Manager need update list
        getUpdateAppList : function() {//get update app list
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return;
            }
            
			//this.pushUpdateList('141399000185');
            var ret = voltapi.WAS.requestAppList(voltapi.WAS.WAS_LIST_TYPE_APP_UPDATE_LIST);
            Volt.log("[voltapi-wrapper.js] getUpdateAppList: " + JSON.stringify(ret));
            return ret;
        },

        haveNewVersion : function(appID) {
            Volt.log('[voltapi-wrapper.js]haveNewVersion: installList = ' + needUpdateList);
            var findObj = _.find(needUpdateList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[voltapi-wrapper.js] this widget has new version:" + appID);
                return true;
            } else {
                Volt.log("[voltapi-wrapper.js] this widget is already latest:" + appID);
                return false;
            }
        },

        saveUpdateList : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] saveUpdateList: data1 = " + JSON.stringify(data1));
            if (!CommonFucntion.checkValid(data1)) {
                return;
            }
            for (var i = 0; i < data1.length; i++) {
                var appInfo = this.getAppInfo(data1[i].app_id);
                Volt.log("[saveUpdateList]is_premium_game:::::"+appInfo.is_premium_game);
                if(appInfo.is_premium_game == 2){
                    this.pushUpdateList(data1[i].app_id);
                }
            }
        },

        pushUpdateList : function(appID) {
            Volt.log("[voltapi-wrapper.js] pushUpdateList(" + appID + ")");

            var findObj = _.find(needUpdateList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                needUpdateList.push(newObj);
                Volt.log("[voltapi-wrapper.js] needUpdateList:" + JSON.stringify(needUpdateList));
            }
        },

        removeUpdateGame : function(appID) {
            Volt.log("[voltapi-wrapper.js] removeUpdateGame(" + appID + ")");

            var findObj = _.find(needUpdateList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(needUpdateList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                needUpdateList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove needUpdateList, length:::'+needUpdateList.length);
            }
        },

        removeUpdateList : function() {
            needUpdateList = [];
        },

		getNeedUpdateFlag : function() {
			var nCount = needUpdateList.length;
			Volt.log("[voltapi-wrapper.js] nCount = " + nCount);
			if(nCount > 0) {
                for( var i = 0; i < nCount; i++){
                    var needUpdateObj = needUpdateList[i];
                    Volt.log('[voltapi-wrapper.js]getNeedUpdateFlag check ::::' + needUpdateObj.appID);
                    var findObj = _.find(nativeGameList, function(obj){
                        if(obj.appID === needUpdateObj.appID){
                            return obj;
                        }
                    });
                    if(CommonFucntion.checkValid(findObj)){
                        Volt.log('[voltapi-wrapper.js]getNeedUpdateFlag APP ::::' + needUpdateObj.appID + ' need update');
                        return true;
                    }
                }
            }
			return false;
        },

        //Manager updating List
        pushUpdatingList : function(appID) {
            Volt.log("[voltapi-wrapper.js] pushUpdatingList(" + appID + ")");

            var findObj = _.find(updatingList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                updatingList.push(newObj);
                Volt.log("[voltapi-wrapper.js] pushUpdatingList:" + JSON.stringify(updatingList));
            }
        },

        removeUpdatingGame : function(appID) {
            Volt.log("[voltapi-wrapper.js] removeUpdatingGame(" + appID + ")");

            var findObj = _.find(updatingList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(updatingList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                updatingList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove updatingList, length:::'+updatingList.length);
            }
        },

        removeUpdatingList : function() {
            updatingList = [];
        },

        isAppUpdating : function(appID) {
            Volt.log('[voltapi-wrapper.js]isWidgetUpdating: updatingList = ' + updatingList);
            var findObj = _.find(updatingList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[voltapi-wrapper.js] this widget is Updating:" + appID);
                return true;
            } else {
                Volt.log("[voltapi-wrapper.js] this widget is not Updating:" + appID);
                return false;
            }
        },

        //Manager updated List
        pushUpdatedList : function(appID) {
            Volt.log("[voltapi-wrapper.js] pushUpdatedList(" + appID + ")");

            var findObj = _.find(updatedList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                updatedList.push(newObj);
                Volt.log("[voltapi-wrapper.js] pushUpdatedList:" + JSON.stringify(updatedList));
            }
        },

        removeUpdatedGame : function(appID) {
            Volt.log("[voltapi-wrapper.js] removeUpdatedGame(" + appID + ")");

            var findObj = _.find(updatedList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(updatedList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                updatedList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove updatedList, length:::'+updatedList.length);
            }
        },

        removeUpdatedList : function() {
            updatedList = [];
        },

        isAppUpdated : function(appID) {
            Volt.log('[voltapi-wrapper.js]removeUpdatedGame: updatedList = ' + updatedList);
            var findObj = _.find(updatedList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[voltapi-wrapper.js] this widget is Updated:" + appID);
                return true;
            } else {
                Volt.log("[voltapi-wrapper.js] this widget is not Updated:" + appID);
                return false;
            }
        },
        
        //Manager installing game list begin
        addInstallList : function(appID,install_path, app_size) {
            Volt.log("[voltapi-wrapper.js] addInstallList(" + appID + ", " + install_path + ")"+' app_size:::'+app_size);

            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                newObj.status = 'downloading';
                newObj.progress = 0;
                newObj.install_path = install_path;
                newObj.app_size     = app_size;
                installList.push(newObj);
                Volt.log("[voltapi-wrapper.js] installList" + installList);
            }
        },
        
        isAppInUSBList : function (appID){
            Volt.log('[voltapi-wrapper.js] isAppInUSBList: installedInUSBList = ' + installedInUSBList);
            var findObj = _.find(installedInUSBList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[voltapi-wrapper.js] this widget is installed in USB :" + appID);
                return true;
            } else {
                Volt.log("[voltapi-wrapper.js] this widget is not installed in USB:" + appID);
                return false;
            }
        },
        
        addToUSBList : function(appID,install_path, app_size){
            Volt.log("[voltapi-wrapper.js] addToUSBList(" + appID + ", " + install_path + ")"+' app_size:::'+app_size);

            var findObj = _.find(installedInUSBList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                newObj.install_path = install_path;
                installedInUSBList.push(newObj);
                Volt.log("[voltapi-wrapper.js] addToUSBList installedInUSBList.length:::" +installedInUSBList.length);
            }
        },
        
        removeFromUSBList : function(appID){
            Volt.log("[voltapi-wrapper.js] removeFromUSBList(" + appID + ")");

            var findObj = _.find(installedInUSBList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(installedInUSBList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                installedInUSBList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove installedInUSBList, length:::'+installedInUSBList.length);
            }
        },
        
        removeUSBList : function(){
            installedInUSBList = [];
        },

        removeInstallList : function(appID) {
            Volt.log("[voltapi-wrapper.js] removeInstallList(" + appID + ")");

            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(installList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                installList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove installList, length:::'+installList.length);
            }
        },

        removeAllInstallList : function() {
            Volt.log("[voltapi-wrapper.js] removeAllInstallList()");
			var findObj = _.find(installList, function(obj) {
				Volt.log('[voltapi-wrapper.js]remove appID::::'+obj.appID);
				if(wrapperSelf.isWidgetInstalling(obj.appID)){
					var bRet = wrapperSelf.cancelInstallApp(obj.appID);
					Volt.log('[voltapi-wrapper.js] cancelInstallApp bRet = '+bRet);
				}
            });
			
            installList = [];
        },

        setInstallListStatus : function(appID, status, progress) {
            Volt.log("[voltapi-wrapper.js] setInstallListStatus(" + appID + ", " + status + ", " + progress + ")");

            var findObj = _.find(installList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            if (CommonFucntion.checkValid(findObj)) {
                findObj.status = status;
                findObj.progress = progress;

                var findIndex = _.indexOf(installList, findObj);
                installList.splice(findIndex, 1, findObj);
            }
        },

        getInstallList : function() {
            Volt.log("[voltapi-wrapper.js] getInstallList()");
            return installList;
        },

        //Manager installing game list end

        //Manager native game list begin
        getAppList : function() {//get local game widgets
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return;
            }
            
            var ret = voltapi.WAS.getAppList(voltapi.WAS.APPS_TYPE_ALL, voltapi.WAS.APPS_INFO_PREMIUM_GAME_TRUE, voltapi.WAS.APPS_INFO_FEATURED_ALL, voltapi.WAS.VIEWMODE_CUSTOM, 0, 100);
            Volt.log("[voltapi-wrapper.js] getAppList: " + JSON.stringify(ret));
            return ret;
        },

        pushNativeGame : function(appID) {
            Volt.log("[voltapi-wrapper.js] pushNativeGame(" + appID + ")");
            
            var findObj = _.find(nativeGameList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID = appID;
                nativeGameList.push(newObj);
                Volt.log("[voltapi-wrapper.js] nativeGameList" + nativeGameList);
            }
        },

        removeNativeGame : function(appID) {
            Volt.log("[voltapi-wrapper.js] removeNativeGame(" + appID + ")");

            var findObj = _.find(nativeGameList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(nativeGameList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                nativeGameList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove nativeGameList, length:::'+nativeGameList.length);
            }
        },
        
        pushAppList: function(data){
            Volt.log('[voltapi-wrapper.js]pushAppList');
            var findObj = _.find(appList, function(obj) {
                if (obj.appID === data.app_id) {
                    return obj;
                }
            });

            if (!CommonFucntion.checkValid(findObj)) {
                var newObj = {};
                newObj.appID            = data.app_id;
                newObj.appTitle         = data.app_title;
                newObj.is_multi_screen2 = data.is_multi_screen2;
                appList.push(newObj);
                Volt.log("[voltapi-wrapper.js] pushAppList::" + appList);
            }
        },
        
        removeAppList: function(appID){
            Volt.log("[voltapi-wrapper.js] removeAppList(" + appID + ")");

            var findObj = _.find(appList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            if (CommonFucntion.checkValid(findObj)) {
                var findIndex = _.indexOf(appList, findObj);
                Volt.log('[voltapi-wrapper.js] find index::::'+findIndex);
                appList.splice(findIndex, 1);
                Volt.log('[voltapi-wrapper.js] after remove appList, length:::'+appList.length);
            }
        },
        
        removeAllAppList: function(){
            appList = [];
        },
        
        getNativeGameInfo: function(appID){
            Volt.log('[voltapi-wrapper.js] getNativeGameInfo()');
            var findObj = _.find(appList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });
            
            return findObj;
        },
        
        isInNativeGameList : function(appID){
            Volt.log('[voltapi-wrapper.js] isInNativeGameList: nativeGameList = ' + nativeGameList);
            var findObj = _.find(nativeGameList, function(obj) {
                if (obj.appID === appID) {
                    return obj;
                }
            });

            if (findObj !== undefined) {
                Volt.log("[voltapi-wrapper.js] this appID " + appID + " is installed");
                return true;
            } else {
                Volt.log("[voltapi-wrapper.js] this appID " + appID + " is not installed");
                return false;
            }
        },

        getNativeGameList : function() {
            Volt.log('[voltapi-wrapper.js] getNativeGameList()');
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return [];
            }

            wrapperSelf.removeNativeGameList();
            wrapperSelf.removeAllAppList();
            var getApplist = wrapperSelf.getAppList();
            for (var i = 0; i < getApplist.length; i++) {
                Volt.log('[voltapi-wrapper.js] ==== premium game infomation ======');
                Volt.log('[voltapi-wrapper.js] app_id:::' + getApplist[i].app_id);
                Volt.log('[voltapi-wrapper.js] app_title:::' + getApplist[i].app_title);
                Volt.log('[voltapi-wrapper.js] is_premium_game:::' + getApplist[i].is_premium_game);
                
                var install_path = getApplist[i].app_installed_path;
                var isInUSBList = wrapperSelf.isAppInUSBList(getApplist[i].app_id);
                Volt.log('[voltapi-wrapper.js] install_path:::'+ install_path + ",isInUSBList =" + isInUSBList);
                if(install_path && install_path.length > 0 && install_path.indexOf("/opt/storage/usb/") != -1 && !isInUSBList){
                    wrapperSelf.addToUSBList(getApplist[i].app_id,install_path);
                }
                if (getApplist[i].is_premium_game == '2') {
                    Volt.log('[voltapi-wrapper.js] pushNativeGame........');
                    wrapperSelf.pushNativeGame(getApplist[i].app_id);
                    wrapperSelf.pushAppList(getApplist[i]);
                }
            }
            return nativeGameList;
        },
        
        getUSBGameList : function(){
            Volt.log('[voltapi-wrapper.js] getUSBGameList()');
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return [];
            }
            
            wrapperSelf.removeUSBList();
            var getApplist = wrapperSelf.getAppList();
            for (var i = 0; i < getApplist.length; i++) {
                var install_path = getApplist[i].app_installed_path;
                Volt.log('[voltapi-wrapper.js] install_path:::'+ install_path);
                if(install_path && install_path.length > 0 && install_path.indexOf("/opt/storage/usb/") != -1){
                    wrapperSelf.addToUSBList(getApplist[i].app_id,install_path);
                }
            }
            return installedInUSBList;
        },

        removeNativeGameList : function() {
            nativeGameList = [];
        },
        //Manager native game list end

        downloadProgressCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] downloadProgressCallback()" + data1.app_id + " result:" + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                this.setInstallListStatus(data1.app_id, 'downloading', data1.result);
            }

            EventMediator.trigger(CommonDefine.Event.DOWNLOAD_PROGRESS, data1);
        },

        downloadCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] downloadCallback()" + data1.app_id + " result:" + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                if (data1.result === 0) {
                    this.setInstallListStatus(data1.app_id, 'downloading', 100);
                    data1.result = 100;
                } else {// download error
                    // that.removeInstallList(data1.app_id);
                }
            }

            EventMediator.trigger(CommonDefine.Event.DOWNLOAD_PROGRESS, data1);
        },

        installProgressCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] installProgressCallback()" + data1.app_id + " result:" + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                this.setInstallListStatus(data1.app_id, 'installing', data1.result);
            }

            EventMediator.trigger(CommonDefine.Event.INSTALL_PROGRESS, data1);
        },

        installCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] installCallback()" + data1.app_id + " result:" + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                if (this.isWidgetInstalling(data1.app_id)) {
                    Volt.log("[voltapi-wrapper.js] install success:" + data1.app_id);
					if(this.isAppUpdating(data1.app_id)) {
						this.pushUpdatedList(data1.app_id);
					}
                    this.removeInstallList(data1.app_id);
                    this.removeUpdatingGame(data1.app_id);
                    this.removeUpdateGame(data1.app_id);
                    EventMediator.trigger(CommonDefine.Event.INSTALL, data1);
                    var isUSB = wrapperSelf.isWidgetInstalledInUSB(data1.app_id) == true ? 'usb' : 'tv';
                    wrapperSelf.addEventLog('DWFIN',{cp : '',target : isUSB,});
                }
                //this.pushNativeGame(data1.app_id);
            }
        },

        downloadCanceledCallBack : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] downloadCanceledCallBack()" + data1.app_id + " result:" + data1.result);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                wrapperSelf.removeInstallList(data1.app_id);
                wrapperSelf.removeUpdatingGame(data1.app_id);
                wrapperSelf.removeUpdateGame(data1.app_id);
                wrapperSelf.removeUpdatedGame(data1.app_id);

                if (wrapperSelf.isAppInUSBList(data1.app_id)) {
                    wrapperSelf.removeFromUSBList(data1.app_id);
                }
            }

            EventMediator.trigger(CommonDefine.Event.DOWNLOAD_CANCELED, data1); 

        },

        unInstallingCallBack : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                Volt.log("[voltapi-wrapper.js] unInstallingCallBack()" + data1.app_id + data1.result);
                EventMediator.trigger(CommonDefine.Event.UNINSTALL_PROGRESS, data1);
            }
        },

        unInstallCallBack : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            if (CommonFucntion.checkValid(data1) && data1.app_id !== undefined && data1.result !== undefined) {
                Volt.log("[voltapi-wrapper.js] unInstallCallBack()" + data1.app_id + data1.result);
                EventMediator.trigger(CommonDefine.Event.UNINSTALL, data1);
                wrapperSelf.removeNativeGame(data1.app_id);
                wrapperSelf.removeFromUnInstallList(data1.app_id);
                wrapperSelf.removeUpdatingGame(data1.app_id);
                wrapperSelf.removeUpdateGame(data1.app_id);
                wrapperSelf.removeUpdatedGame(data1.app_id);
                if (wrapperSelf.isAppInUSBList(data1.app_id)) {
                    wrapperSelf.removeFromUSBList(data1.app_id);
                }
            }
        },
        
        unInstallErrorCallBack : function(eventType, data1, data2){
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] unInstallErrorCallBack  eventType = " + eventType + ", app_id = " + data1.app_id + ", result = " + data1.result);
            
            wrapperSelf.removeFromUnInstallList(data1.app_id);
            wrapperSelf.removeUpdatingGame(data1.app_id);
            wrapperSelf.removeUpdateGame(data1.app_id);
            wrapperSelf.removeUpdatedGame(data1.app_id);
            if (wrapperSelf.isAppInUSBList(data1.app_id)) {
                wrapperSelf.removeFromUSBList(data1.app_id);
            }
            
            var type;
            /*
            switch(eventType){
                case voltapi.WAS.WAS_EVENT_UNINSTALL_FAIL_NOT_EXIS:
                    type = CommonDefine.Event.UNINSTALL_FAIL_APP_NOT_EXIST;
                    data1.errorCode = eventType;
                    break;
                default : 
                    type = CommonDefine.Event.UNINSTALL_FAIL;
                    data1.errorCode = eventType;
                    break;
            }
            */
            if(eventType){
                type = CommonDefine.Event.UNINSTALL_FAIL;
                data1.errorCode = eventType;
            }
            
            EventMediator.trigger(type, data1);
        },

        installErrorCallback : function(eventType, data1, data2) {
            data1 = JSON.parse(data1);
            Volt.log("[voltapi-wrapper.js] installErrorCallback: eventType = " + eventType + ", app_id = " + data1.app_id + ", result = " + data1.result);
            var type;
            wrapperSelf.removeInstallList(data1.app_id);
            wrapperSelf.removeUpdatingGame(data1.app_id);
            wrapperSelf.removeUpdatedGame(data1.app_id);

            if (wrapperSelf.isAppInUSBList(data1.app_id)) {
                wrapperSelf.removeFromUSBList(data1.app_id);
            }

            switch (eventType) {
                case voltapi.WAS.WAS_EVENT_INSTALL_FAIL_APPSYNC_NOT_COMPLETE:
                    type = CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE;
                    break;
                default:
                    type = CommonDefine.Event.INSTALL_FAIL;
					data1.errorCode = eventType;
                    //type = CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE;
                    break;
            }
            
            if(eventType != voltapi.WAS.WAS_EVENT_INSTALL_CANCLE_FAILED){
                EventMediator.trigger(type, data1);
            } else {
                Volt.log('voltapi.WAS.WAS_EVENT_INSTALL_CANCLE_FAILED, we do not handle it!!');
            }
        },

        //////////////////////////////////////
        // WAS SSO Wrapper
        //////////////////////////////////////

        /*requestSSOAccessToken: function(appID, secretKey) {
         if(!bWasInitStatus)
         {
         print("[voltapi-wrapper.js] WAS Wrapper is not initialed");
         return false;
         }
         var ret = voltapi.WAS.requestSSOAccessToken(appID, secretKey);
         return ret;
         },*/

        subscribeSSOStateChange : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.subscribeSSOStateChange();
            return ret;
        },

        getSSOLoginState : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.getSSOLoginState();
            Volt.log("[voltapi-wrapper.js] getSSOLoginState = " + ret);
            if (ret == -1) {
                ret = 0;
            }
            return ret;
        },

        getSSOLoginInfo : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return null;
            }
            var ret = voltapi.WAS.getSSOLoginInfo();
            Volt.log("[voltapi-wrapper.js] login Info: " + ret);
            return ret;
        },

        /*getSSOToken: function() {
         if(!bWasInitStatus)
         {
         print("[voltapi-wrapper.js] WAS Wrapper is not initialed");
         return false;
         }
         var ret = voltapi.WAS.getSSOToken();
         print("[voltapi-wrapper.js] getSSOToken: " + ret);
         return ret;
         },*/

        startSSOPopup : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var payload = 'SignIn&callerId=org.volt.games';
            Volt.log('[voltapi-wrapper.js] startSSOPopup ====>>> payload = '+payload);
            var ret = voltapi.WAS.showSSOPopup(payload);
            return ret;
        },
        
        showPopupCallback : function(type, data){
            Volt.log('[voltapi-wrapper.js] showPopupCallback');
            var json = JSON.parse(data);
            Volt.log("[voltapi-wrapper.js] >>>>>>>>>>>>>>>>>>>>>>>>>>>WAS_SSO_SHOW_POPUP type:: "+type+"result ::"+ data);
        },

        showCPLinkPopup : function(payload) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.showSSOPopup(payload);
            return ret;
        },

        isLinkedApp : function(cpName) {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.isLinkedApp(cpName);
            Volt.log("[voltapi-wrapper.js]" + cpName + " link status:" + ret);
            return ret;
        },

        getGuid : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.getGuid();
            Volt.log("[voltapi-wrapper.js] getGuid = " + ret);
            return ret;
        },

        initSSOAccountInfo : function() {
            Volt.log("[voltapi-wrapper.js] initSSOAccountInfo");
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return;
            }
            
            if (wrapperSelf.getSSOLoginState() == false) {
                Volt.log("[voltapi-wrapper.js] SSO log out!!!!");
                Utils.Account.initSSOAccoutInfo(false);
            } else {
                var accountInfo = wrapperSelf.getSSOLoginInfo();
                if (CommonFucntion.checkValid(accountInfo)) {
                    Volt.log("[voltapi-wrapper.js] initSSOAccoutInfo:" + accountInfo.login_id + " " + accountInfo.user_icon);
                    Utils.Account.initSSOAccoutInfo(true, accountInfo.login_id, accountInfo.user_icon);
                }
            }
        },

        ssoStateChangeCallBack : function(eventType, data1, data2) {
            Volt.log('[voltapi-wrapper.js]ssoStateChangeCallBack!!! data1 ='+ data1);
            var data = JSON.parse(data1);
            Volt.log('[voltapi-wrapper.js]ssoStateChangeCallBack!!! data.fail ='+ data.fail);
            if(data.fail && data.fail == -1){
                Volt.log('[voltapi-wrapper.js]ssoStateChangeCallBack!!! WAS crash');
                wrapperSelf.subscribeSSOStateChange();
                return;
            }
            
            Volt.log("[voltapi-wrapper.js] ssoStateChangeCallBack()" + data.login_state + " " + data.account + " " + data.user_icon);
            Utils.Account.updateAccountInfo(data);
        },

        getGameTermStatus : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var ret = voltapi.WAS.getSSOTermStatus("user_game_tc");
            Volt.log("[voltapi-wrapper.js] getGameTermStatus, ret = " + ret);
            return ret;
        },

		showGameTermsPopup: function(){
			if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            wrapperSelf.addEventLog('JUMPTERMS',{cp : '',inputby:'',});
			var ret = voltapi.WAS.showSSOPopup("GameTerms&callerId=org.volt.games");
            return ret;
        },
        
        getUsingMemory: function(){
            Volt.log('getDownloadingMemory');
            var totalMemory = 0;
            var findObj = _.find(installList, function(obj) {
                if (obj) {
                    Volt.log('app size:::::'+obj.app_size);
                    totalMemory += obj.app_size;
                }
            });
            return totalMemory;
        },
        
        //memory info
        getMemory : function() {
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return "";
            }
            var ret = voltapi.WAS.getMemory();
            Volt.log("[voltapi-wrapper.js] getMemory = " + ret);
            //need refine
            if ( typeof ret == 'string') {
                return ret;
            } else {
                return " ";
            }
        },

        getStoragePercent : function(){//temp use should refine
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var obj = wrapperSelf.getMemoryObject({
                usedUnit : 'B',
                totalUnit : 'B'
            });
            if(obj){
                var used = obj.used;
                var total = obj.total;
                Volt.log("[voltapi-wrapper.js] getStoragePercent is " + used / total);
                return used / total;
            }
            return 0;
        },

        getFreeSize : function(unit){ //return with unit: MB
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var obj = wrapperSelf.getMemoryObject({
                freeUnit : 'MB'
            });
            if(obj){
                var free = obj.free;
                Volt.log("[voltapi-wrapper.js] getFreeSize is " + free + 'MB');
                return free;
            }
            return -1;
        },

        getMemoryObject : function(unitObj){
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            
            var memoryObject = null;
            var ret = wrapperSelf.getMemory();
            //ret is like this type : "12.01MB / 2.59GB"
            if(typeof ret == 'string'){
                var nIndex = ret.indexOf('/');
                var nlength = ret.length;
                Volt.log("[voltapi-wrapper.js] nIndex is " + nIndex + " nlength is " + nlength);
                if(nIndex != -1){
                    memoryObject = {};
                    var used = memoryObject.used = ret.substring(0, nIndex - 3);
                    var usedUnit = memoryObject.usedUnit = ret.substring(nIndex - 3, nIndex - 1);
                    var total = memoryObject.total = ret.substring(nIndex + 2, nlength - 2);
                    var totalUnit = memoryObject.totalUnit = ret.substring(nlength - 2);
                    if(usedUnit == 'MB'){
                        used = parseFloat(used) * 1024;
                    }else if(usedUnit == 'GB'){
                        used = parseFloat(used) * 1024 * 1024;
                    }
                    if(totalUnit == 'MB'){
                        total = total * 1024;
                    }else if(totalUnit == 'GB'){
                        total = total * 1024 * 1024;
                    }
                    var free = total - used;
                    if(unitObj){
                        if(unitObj.usedUnit && unitObj.usedUnit == 'B'){ // only support 'B', if not set unit or set other unit return default unit
                            memoryObject.used = used;
                            memoryObject.usedUnit = 'B';
                        }
                        if(unitObj.totalUnit && unitObj.totalUnit == 'B'){ // only support 'B', if not set unit or set other unit return default unit
                            memoryObject.total = total;
                            memoryObject.totalUnit = 'B';
                        }
                        if(unitObj.freeUnit){ // only support 'MB', 'default', if not set unit or set other unit, do not return free
                            if(unitObj.freeUnit == 'MB'){
                                memoryObject.free = free / 1024;
                                memoryObject.freeUnit = 'MB';
                            }else if(unitObj.freeUnit == 'default'){
                                var tempUnit = wrapperSelf.setSuitablyUnit(free);
                                memoryObject.free = tempUnit.size;
                                memoryObject.freeUnit = tempUnit.unit;
                            }
                        }
                    }
                }
            }
            Volt.log("[voltapi-wrapper.js] getMemoryObject = " + JSON.stringify(memoryObject));
            return memoryObject;
        },
        
        setSuitablyUnit : function(size) {//the unit of size is B
            var COUNTMB = 1024;
            var COUNTGB = 1024 * 1024;
            var unit = 'B';
            if(size >= COUNTGB){
                size /= COUNTGB;
                unit = 'GB';
            }else if(size >= COUNTMB){
                size /= COUNTMB;
                unit = 'MB';
            }
            size = parseFloat(size).toFixed(2);
            return {
                size : size,
                unit : unit
            };
        },
        
        IsStorageEnough : function(app_size) {//need refine
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            if(Volt.IsStorageEnough === false){//TODO : This code need delete when was can download to usb
                Volt.log("[voltapi-wrapper.js] IsStorageEnough return: false for tester");//TODO : This code need delete when was can download to usb
                return false;//TODO : This code need delete when was can download to usb
            }//TODO : This code need delete when was can download to usb
            var bRet = true;
            var freeSize = wrapperSelf.getFreeSize();
            var usingSize = wrapperSelf.getUsingMemory();
            Volt.log('freeSize=====>'+freeSize+' usingSize=====>'+usingSize);
			
            if(freeSize != -1){
                var curFreeSize = usingSize ? freeSize - usingSize : freeSize;
                Volt.log('current free size::::'+curFreeSize);
                if(parseFloat(app_size) >= curFreeSize) {
                    bRet = false;
                }
            }
            Volt.log("[voltapi-wrapper.js] IsStorageEnough return: " + bRet);
            return bRet;
        },

        //network status
        GetDebugInfo : function() {
            Volt.log('[voltapi-wrapper.js] GetDebugInfo .....');
            
            if (!bWasInitStatus) {
                Volt.log("[voltapi-wrapper.js] WAS Wrapper is not initialed");
                return false;
            }
            var odebugInfo = voltapi.WAS.getDebugInfo();
            return odebugInfo;
        },
  
        getUsbStorages : function() {
            if(!voltapi.ContentsMgr.isOpened()){
                Volt.log('[voltapi-wrapper.js] voltapi.ContentsMgr is not opened');
                return;
            }
            
            var bFlg = voltapi.ContentsMgr.connect();
            //var bFlg2 = voltapi.ContentsMgr.disconnect();
            Volt.log("[voltapi-wrapper.js] bFlg: " + bFlg);
            if (bFlg) {
                var UsbInfo = voltapi.ContentsMgr.getStorages();
                Volt.log("[voltapi-wrapper.js] getUsbStorages: " + JSON.stringify(UsbInfo));
                return UsbInfo;
            }
                
            return;
        }
    };

})();
