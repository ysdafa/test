var CommonDefine = Volt.requireNoContext('app/common/common-define.js');
var Backbone = Volt.requireNoContext('lib/volt-backbone.js');
var RouterController = Volt.requireNoContext('app/controller/router-controller.js');
var Mediator = Volt.requireNoContext('app/common/event-mediator.js');
var Utils = Volt.requireNoContext('app/common/utils.js');

var ErrorHandling = {
    panelIsActive : true,
    displayingMsgbox : null,
    
    initialize : function() {
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.handleActive, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.handleDeactive, this);
    },
    handleActive : function() {
        Volt.log("[Error-Handling.js] game panel is active!");
        this.panelIsActive = true;
    },
    handleDeactive : function() {
        Volt.log("[Error-Handling.js] game panel is deactive!");
        this.panelIsActive = false;
    },
    showMessage : function(messageId, app_id, errorCode) {
        this.destroyWidgetPopup();
        
        if(this.displayingMsgbox && this.displayingMsgbox+"" == messageId+""){
            Volt.log("[Error-Handling.js] the same type message type,return!");
            return;
        }
        
        var bNeedDelay = this.destroyNavigatePopup();
        if (bNeedDelay) {
            print('[Error-Handling.js] bNeedDelay == true');
            var ErrorSelf = this;
            Volt.setTimeout(function() {
                ErrorSelf.showMessagePopupView(messageId, app_id, errorCode);
            }, 200);

        } else {
            print('[Error-Handling.js] bNeedDelay == false');
            this.showMessagePopupView(messageId, app_id, errorCode);
        }
    },

    showMessagePopupView : function(messageId, app_id, errorCode) {
        var LoadingView    = Volt.requireNoContext('app/views/loading-view.js');
        if (!this.panelIsActive||(LoadingView.viewIsVisiable&&LoadingView.type != CommonDefine.Const.VIDEO_LOADING)) {
            Volt.log("[Error-Handling.js] game panel is deactive,popup is not allowed!");
            return;
        }
        print('[Error-Handling.js] showMessagePopupView');
        switch(messageId) {
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>', errorCode),
                    button : true,
                    button_1_Text : Volt.i18n.t('TV_SID_TROUBLESHOOT'),
                    button_2_Text : Volt.i18n.t('COM_SID_CANCEL'),
                    contextLineNumber : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', errorCode),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_PREPARING_TV_TRY_AGAIN'),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    appID : app_id,
                };
                if (Volt.GAMES_REVERSE) {
                    param.contentText = "\u200f" + Volt.i18n.t('TV_SID_PREPARING_TV_TRY_AGAIN');
                }
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_1LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_DELETE_SELECTED_ITEMS_QUES'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                    defaultFocus : "button_2",
                    appID : app_id,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MUST_SIGN_SAMSUNG_ACCOUNT_SIGN_IN'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                    appID : app_id,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_DELETED_SUCCESSFULLY'),
                    button : true,
                    contextLineNumber : 1,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    appID : app_id,
                };
                
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_DELETE:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_DELETE,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MIX_FAILED_DELETE').replace('<<A>>', errorCode),
                    button : true,
                    contextLineNumber : 1,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UPDATE:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UPDATE,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MIX_FAILED_UPDATE').replace('<<A>>', errorCode),
                    button : true,
                    contextLineNumber : 1,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_DOWNLOAD:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_DOWNLOAD,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MIX_FAILED_TO_DOWNLOAD').replace('<<A>>', errorCode),
                    button : true,
                    contextLineNumber : 1,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FAIL:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FAIL,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MIX_FAILED_TO_DOWNLOAD').replace('<<A>>', errorCode),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    appID : app_id,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('COM_SID_DOWNLOADGAME_BEFORE_CAN_RATE_IT'),
                    button : true,
                    contextLineNumber : 1,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FACEBOOK:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_FACEBOOK,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MIX_INSTALLED_INSTALL_IT').replace('<<A>>', 'Facebook'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                    appID : '11091000000',
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_YOUTUBE:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_INSTALL_YOUTUBE,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_VIDEO_YOUTUBE_APP_INSTALL'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                    appID : '111299001912',

                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_GAME_CENTER:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_GAME_CENTER,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : "Game Center : 0.0.1 - 2014-0811",
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_UPDATE_NEW_VERSION:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_UPDATE_NEW_VERSION,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_A_NEW_VERSION_GAME_AVAILABLE_INSTALL'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'), //update to new version
                    button_2_Text : Volt.i18n.t('SID_NO'), //launch the games(old version)
                    appID : app_id,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_COUPON:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_COUPON,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MUST_SIGN_SAMSUNG_ACCOUNT_SIGN_IN'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_MESSAGE:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_MESSAGE,
                    style : CommonDefine.Winset.MESSAGEBOX_NOTITLE_BUTTON_2_8LINE,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_MUST_SIGN_SAMSUNG_ACCOUNT_SIGN_IN'),
                    button : true,
                    button_1_Text : Volt.i18n.t('SID_YES'),
                    button_2_Text : Volt.i18n.t('SID_NO'),
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_EXPIRED:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_EXPIRED,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_THIS_COUPON_HAS_EXPIRED'),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_USED:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_USED,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_THIS_COUPON_HAS_ALREADY_BEEN_USED'),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                //var fbMsg = new message_Box(param); /**** switch to halo component****/
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_COUPON:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_COUPON,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_COUPON_REGISTRATION_FAILED_PLEASE_TRY_AGAIN_LATER'),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_INVALID_COUPON:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_INVALID_COUPON,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_COUPON_INVALID_CHECK_TRY_AGAIN'),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                break;

            case CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_NICKNAME:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_NICKNAME,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : errorCode,
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                break;
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_NICKNAME_CONFLICT:
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_NICKNAME_CONFLICT,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : "This nickname is already in use.Please enter another one",
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                break;
            case CommonDefine.Magic.SHOW_VERSION :
                var CommonContent = Volt.requireNoContext('app/common/common-content.js');
                CommonContent.getConfigXML().then(function(configXML) {
                    var param = {
                        style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                        buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                        bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                        contentText : configXML.widget.ver,
                        button : true,
                        button_1_Text : Volt.i18n.t('COM_SID_OK'),
                        contextLineNumber : 1,
                        focusIndex : 1,
                    };
                    Backbone.history.navigate('msgpopup', {
                        trigger : true,
                        msgParam : JSON.stringify(param),
                    });
                });
                break;
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_PSN :
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_PSN,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : errorCode,
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                break;
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_NOT_SUPPORT_MLS :
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_NOT_SUPPORT_MLS,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('COM_SID_FUNCTION_AVAILABLE_MULTI_LINK_SCREEN'),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_CANCEL'),
                    contextLineNumber : 1,
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                break;
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB :
                var param = {
                    type : CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB,
                    style : CommonDefine.Winset.MESSAGEBOX_EXTENSION_ONE_BUTTON,
                    buttonStyle : CommonDefine.Winset.MESSAGEBOX_BUTTON_IMAGE_O_STYLE_F_FOCUS1,
                    bgStyle : CommonDefine.Winset.MESSAGEBOX_BACKGROUND_STYLE_B_1,
                    contentText : Volt.i18n.t('TV_SID_SOTRAGE_DEVICE_DISCONNECTED'),
                    button : true,
                    button_1_Text : Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber : 1,
                    focusIndex : 1,
                };
                Backbone.history.navigate('msgpopup', {
                    trigger : true,
                    msgParam : JSON.stringify(param),
                });
                break;
            default:
                print('message-id:::' + messageId);
                break;
        }
    },

    destroyWidgetPopup : function() {//destroy all widget type popups
        print('[Error-Handling.js] destroyWidgetPopup');
        Mediator.trigger(CommonDefine.Event.DESTORY_OPTION_MENU);
    },

    destroyNavigatePopup : function() {
        print('[Error-Handling.js] destroyNavigatePopup' + RouterController.getCurrentView().type);
        if (RouterController.getCurrentView().type == 4) {
            var CommonContent = Volt.requireNoContext('app/common/common-content.js');
            var msgType = CommonContent.getMsgPopupType();
            var bPanelActived = CommonContent.getPanelActive();
            if ("choose-device" == msgType && !bPanelActived) {
                Volt.log("choose-device-popup,no need destroy.");
            } else {
                print('[Error-Handling.js] destroyNavigatePopup, back first');
                Utils.Timer.clearTimeOut();
                Backbone.history.back();
                return true;
            }
        }
        return false;
    },
};

exports = ErrorHandling;

