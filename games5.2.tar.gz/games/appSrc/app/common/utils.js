var Backbone = Volt.requireNoContext('lib/volt-backbone.js');
var EventMediator  = Volt.requireNoContext('app/common/event-mediator.js');
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');

exports.Timer = {
    timer: 0,
    back : function() {
        Volt.log("[utils.js] it's time out,back to parent view");
        Backbone.history.back();
    },
    
    setTimerOut : function() {
        Volt.log("[utils.js] setTimerOut for msg/usual popup.");
        if (this.timer !== undefined) {
            Volt.clearTimeout(this.timer);
        }
        this.timer = Volt.setTimeout(this.back, 1000 * 20);
    },

    clearTimeOut : function(){
        Volt.log("[utils.js] clear timer.");
        if(this.timer){
            Volt.clearTimeout(this.timer);
        }
    }
};

exports.Date = {
    MonthArray : [{
        num : 0,
        str : 'Jan.'
    }, {
        num : 1,
        str : 'Feb.'
    }, {
        num : 2,
        str : 'Mar.'
    }, {
        num : 3,
        str : 'Apr.'
    }, {
        num : 4,
        str : 'May.'
    }, {
        num : 5,
        str : 'June.'
    }, {
        num : 6,
        str : 'July.'
    }, {
        num : 7,
        str : 'Aug.'
    }, {
        num : 8,
        str : 'Sept.'
    }, {
        num : 9,
        str : 'Oct.'
    }, {
        num : 10,
        str : 'Nov.'
    }, {
        num : 11,
        str : 'Dec.'
    }],

    getEngDateString : function(date) {// eg:Sept.20 2014
        var year  = date.getFullYear();
        var month = date.getMonth();
        var day   = date.getDate();
        var str   = this.MonthArray[month].str + day + ' ' + year;
        return str;
    },

    getUSAEngDateString : function(date) {// eg:09/20/2014  MM/DD/YYYY
        var year  = date.getFullYear();
        var month = date.getMonth();
        var day   = date.getDate();
        month = month + 1;
        if (month < 10) {
            month = '0' + month;
        }
        if (day < 10)
            day = '0' + day;
        var str = month + "/" + day + "/" + year;
        return str;
    },

    getEUEngDateString : function(date) {// eg:20/09/2014  DD/MM/YYYY
        var year  = date.getFullYear();
        var month = date.getMonth();
        var day   = date.getDate();
        month = month + 1;
        if (month < 10) {
            month = '0' + month;
        }
        if (day < 10)
            day = '0' + day;
        var str = day + "/" + month + "/" + year;
        return str;
    },

    getKORDateString : function(date) {// eg:2014/09/20  YYYY/MM/DD
        var year = date.getFullYear();
        var month = date.getMonth();
        var day = date.getDate();
        month = month + 1;
        if (month < 10) {
            month = '0' + month;
        }
        if (day < 10)
            day = '0' + day;
        var str = year + "/" + month + "/" + day;
        return str;
    },

    getCNDateString : function(date){//eg:2014年09月20日  
        var year  = date.getFullYear();
        var month = date.getMonth();
        var day   = date.getDate();
        month = month + 1;
        if (month < 10) {
            month = '0' + month;
        }
        if (day < 10)
            day = '0' + day;
        var str = year + "年" + month + "月" + day + "日";
        return str;
    },

    getShortDateString : function(date) {//eg:2014-07-29
        var year  = date.getFullYear();
        var month = date.getMonth();
        var day   = date.getDate();
        month = month + 1;
        if (month < 10)
            month = '0' + month;
        if (day < 10)
            day = '0' + day;
        var str = year + '-' + month + '-' + day;
        return str;
    },

    getDateTimeString : function(date) {//eg:2014-07-29 13:30:50
        var year  = date.getFullYear();
        var month = date.getMonth();
        var day   = date.getDate();
        month = month + 1;
        if (month < 10)
            month = '0' + month;
        if (day < 10)
            day = '0' + day;
        var hour = date.getHours();
        if (hour < 10) {
            hour = '0' + hour;
        }
        var minute = date.getMinutes();
        if (minute < 10) {
            minute = '0' + minute;
        }
        var second = date.getSeconds();
        if (second < 10) {
            second = '0' + second;
        }
        var str = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
        return str;
    },

    //transfer strDate to date object
    //strDate example:2014-09-30
    transferStrToDate : function(strDate) {
        var date = eval('new Date(' + strDate.replace(/\d+(?=-[^-]+$)/, function(a) {
            return parseInt(a, 10) - 1;
        }).match(/\d+/g) + ')');
        Volt.log('transferStrToDate date = ' + date);
        return date;
    },
    
    //string example:20141231-235959
    transferNumStrToDate : function(string){
        if(string == '') return;
        var tempStr = null;
        if(string.indexOf('-') > 0){ //example:20141231-235959
            var dateStr = string.split('-')[0];
            var timeStr = string.split('-')[1];
            tempStr = this.splitStrNoTime(dateStr);
            tempStr = tempStr + " " + timeStr.substr(0,2) + ":" + timeStr.substr(2,2) + ":" + timeStr.substr(4,2);
        } else {//example:20141231
            tempStr = this.splitStrNoTime(string);
        }
        Volt.log('transferNumStrToDate tempStr = ' + tempStr);
        var date = this.transferStrToDate(tempStr);
        return date;
    },
    
    //example:20141231
    splitStrNoTime : function(str){
        return str.substr(0,4) + "-" + str.substr(4,2) + "-" +str.substr(6,2);
    },
    
    getFormatedDate : function(date) {
        var DeviceModel = Volt.requireNoContext('app/models/device-model.js');
        var countryCode = DeviceModel.get('countryCode');
        var languageCode = DeviceModel.get('languageCode');
        var formatedDate = null;
        Volt.log('getFormatedDate countryCode = '+ countryCode + ",languageCode = "+languageCode);

        switch(countryCode) {
            //case 'CN':
            //    if ('EN' === languageCode || 'en' === languageCode) {
            //        formatedDate = this.getEngDateString(date);
            //    } else {
            //        formatedDate = this.getCNDateString(date);
            //    }
            //    break;
            case 'KR':
                //if ('EN' === languageCode || 'en' === languageCode) {
                //    formatedDate = this.getEngDateString(date);
                //} else {
                //    formatedDate = this.getKORDateString(date);
                //}
                formatedDate = this.getKORDateString(date);
                break;
            case 'EU':
                formatedDate = this.getEUEngDateString(date);
                break;
            case 'US':
                formatedDate = this.getUSAEngDateString(date);
                break;
            default :
                formatedDate = this.getUSAEngDateString(date);
                break;
        }

        return formatedDate;
    }
};

exports.Account = {
    loginState : false,
    ssoAccount : "",
    usrIcon : "",
    first: true,
    
    initSSOAccoutInfo: function(status, account, icon) {
        Volt.log("[utils.js] Init sso account info");
        if(this.loginState != status){
            Volt.log("[utils.js] initSSOAccoutInfo sign state update");
            this.loginState = status;
            EventMediator.trigger(CommonDefine.Event.SIGN_STATE_UPDATE);
        } else {
            this.loginState = status;
        }
        
        if(true == this.loginState) {
            this.ssoAccount = account;
            this.usrIcon = icon;
        }
        Volt.log("[utils.js] initSSOAccoutInfo:" + this.loginState + " " + this.ssoAccount + " " + this.usrIcon);
    },

    updateAccountInfo: function(data1) {
        var CommonFucntion = Volt.requireNoContext('app/common/common-function.js');
        
        if(CommonFucntion.checkValid(data1)) {
            Volt.log('[utils.js]change1:::'+this.loginState === data1.login_state);
            Volt.log('[utils.js]change2::'+this.ssoAccount === data1.account);
            Volt.log('[utils.js]change3::'+this.usrIcon === data1.user_icon);
            var bChange = ((this.loginState === data1.login_state)&&
                           (this.ssoAccount === data1.account)&&
                           (this.usrIcon === data1.user_icon));
                           
            this.loginState = data1.login_state;
            this.ssoAccount = data1.account;
            this.usrIcon    = data1.user_icon;
            Volt.log("[utils.js] updateAccountInfo: bChange =" + bChange);
            Volt.log("[utils.js] updateAccountInfo:" + this.loginState + " " + this.ssoAccount + " " + this.usrIcon);
            Volt.log("[utils.js] updateAccountInfo: this.first =" + this.first);
            if(!bChange && !this.first) {
                Volt.log("[utils.js] status change, send event");
                EventMediator.trigger(CommonDefine.Event.SIGN_STATE_UPDATE);
            }
            
            if(this.first){
                this.first = false;	    
            }
        }
    },

    updateSignState : function(signState) {
        this.loginState = signState;
    },

    getSignState : function() {
        return this.loginState;
    },

    getAccount : function() {
        return this.ssoAccount;
    },

    getUsrIcon : function() {
        return this.usrIcon;
    }
};

exports.Global = {
    APP_ACTIVE      : 'ON_ACTIVATE',
    APP_DEACTIVATE  : 'ON_DEACTIVATE',
    APP_UNKNOWN     : 'ON_UNKNOWN',
    MEMORY_TEST_ON  : 1,
    MEMORY_TEST_OFF : 0,
};

exports.Nav={
    BLOCK_NAV : false,
}
