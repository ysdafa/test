var Q = Volt.requireNoContext('modules/q.js');
var _ = Volt.requireNoContext("modules/underscore.js")._;
var Backbone = Volt.requireNoContext('lib/volt-backbone.js');
var Utils          = Volt.requireNoContext('app/common/utils.js');
var VIEW_TYPE_ROOT = 1
    , VIEW_TYPE_2ND_DEPTH = 2
    , VIEW_TYPE_DETAIL = 3
    , VIEW_TYPE_POPUP = 4;

var oCurrentView = {
        instance: null,
        name: '',
        type: VIEW_TYPE_ROOT,
        viewinfo: null
    }
    , oViewCache = {};

var showMatrix = {};
showMatrix[VIEW_TYPE_ROOT] = {};
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_ROOT] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_UP';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH] = {};
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_ROOT] = 'SHOW_FADE_UP';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL] = {};
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_ROOT] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_2ND_DEPTH] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_DETAIL] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';
showMatrix[VIEW_TYPE_POPUP] = {};
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_ROOT] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_2ND_DEPTH] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_DETAIL] = 'SHOW_NONE';
showMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_POPUP] = 'SHOW_FADE_IN';

var hideMatrix = {};
hideMatrix[VIEW_TYPE_ROOT] = {};
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_ROOT] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_DOWN';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_ROOT][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_2ND_DEPTH] = {};
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_ROOT] = 'HIDE_FADE_DOWN';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_2ND_DEPTH][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_DETAIL] = {};
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_ROOT] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_DETAIL][VIEW_TYPE_POPUP] = 'HIDE_NONE';
hideMatrix[VIEW_TYPE_POPUP] = {};
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_ROOT] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_2ND_DEPTH] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_DETAIL] = 'HIDE_FADE_OUT';
hideMatrix[VIEW_TYPE_POPUP][VIEW_TYPE_POPUP] = 'HIDE_FADE_OUT';

function getShowType(fromType, toType) {
    return showMatrix[fromType][toType];
}

function getHideType(fromType, toType) {
    return hideMatrix[fromType][toType];
}

function getPageTransitionLog(sHideView, sShowView, nFromType, nToType) {
    var sMsg = '';
    switch(nToType) {
        case VIEW_TYPE_ROOT:
            sMsg += 'rootView';
            break;
        case VIEW_TYPE_2ND_DEPTH:
            sMsg += 'secondDepthView';
            break;
        case VIEW_TYPE_DETAIL:
            sMsg += 'detailView';
            break;
        case VIEW_TYPE_POPUP:
            sMsg += 'popupView';
            break;
    }
    sMsg += ' from ' + sHideView + '(' + getHideType(nFromType, nToType) + ')';
    sMsg += ' to ' + sShowView + '(' + getShowType(nFromType, nToType) + ')';

    return sMsg;
}

function CacheCtrl() {
    var cache = oViewCache;

    function initCache(viewname) {
        cache[viewname] = {
            name: viewname,
            instance: new (Volt.requireNoContext('app/views/'+viewname+'.js')),
            sublist: {}
        };
        cache[viewname].instance.render();
        cache[viewname].sub = _.bind(sub, cache[viewname]);
        cache[viewname].show = _.bind(show, cache[viewname]);
        cache[viewname].hide = _.bind(hide, cache[viewname]);
    }

    function get(viewname) {
        if (!(cache[viewname] && cache[viewname].instance)) {
            initCache(viewname);
        }
        return cache[viewname];
    }

	function sub(subViewName) {
		var subViewCtrl = this.sublist[subViewName];
		// The sub view operated in this sub() call
		this.subName = subViewName;
		if (!subViewCtrl) {
			subViewCtrl = this.sublist[subViewName] = {
				instance : new (Volt.requireNoContext('app/views/' + subViewName + '.js')),
				visible : false, // Current State of Sub View
				visibleFlag : true // Next State to be set of Sub View
				//                display: false,
				//                hidden: true
			};
			subViewCtrl.instance.render(this.instance);
		}

		subViewCtrl.visibleFlag = true;

		for (var key in this.sublist) {
			if (key != subViewName) {
				subViewCtrl = this.sublist[key];
				subViewCtrl.visibleFlag = false;
				subViewCtrl.instance.hide();
				if (subViewCtrl.visible) {
					Volt.log('[router-controller.js]' + ' hide: ' + key);
					subViewCtrl.visible = false;
				}
			}
		}

		this.deferred.promise.then( function() {
			Volt.log('[router-controller.js]' + ' then: ' + subViewName);
			var subViewCtrl = this.sublist[subViewName];
			if (subViewCtrl.visibleFlag && !subViewCtrl.visible) {
				Volt.log('[router-controller.js]' + ' show: ' + subViewName);
				subViewCtrl.instance.show();
				Utils.Nav.BLOCK_NAV = false;
				Volt.log('[router-controller.js]' + ' Utils.Nav.BLOCK_NAV: ' + Utils.Nav.BLOCK_NAV);
				subViewCtrl.visible = true;
			}
		}.bind(this));

		return this;
	}
    function show(param, animationType) {
        var deferred = Q.defer();
        var showList = [];
        if (!this.display) {
            showList.push(this.instance.show(param, animationType));
            this.display = true;
        }
        for (var key in this.sublist) {
            if (this.sublist[key].display && this.sublist[key].hidden) {
                this.sublist[key].hidden = false;
                showList.push(this.sublist[key].instance.show(param, animationType));
            }
        }
        Q.all(showList).then(function(){}).fail(function(e){ Volt.log(e); });
        deferred.resolve();
        return deferred.promise;
    }

    function hide() {
        var deferred = Q.defer();
        var hideList = [];
        hideList.push(this.instance.hide());
        this.display = false;
        for (var key in this.sublist) {
            if (this.sublist[key].display) {
                this.sublist[key].display = false;
                this.sublist[key].hidden = true;
                hideList.push(this.sublist[key].instance.hide());
            }
        }
        Q.all(hideList).then(function(){
            deferred.resolve();
        }).fail(function(e){ Volt.log(e); });
        return deferred.promise;
    }
    return {
        get: get
    };
}

var cacheCtrl = CacheCtrl();
function changeView(sViewName, type, param) {
    Volt.log('[router-controller.js] ' + getPageTransitionLog(oCurrentView.name, sViewName, oCurrentView.type, type));
	Volt.log('[router-controller.js]changeView..... sViewName = ' + sViewName +',,,oCurrentView.name = ' + oCurrentView.name);
    if (sViewName != oCurrentView.name) {
        var before = _.clone(oCurrentView);
        oCurrentView = cacheCtrl.get(sViewName);
        oCurrentView.type = type;
        oCurrentView.deferred = Q.defer();
        oCurrentView.viewinfo = param;
        hideView(before, getHideType(before.type, oCurrentView.type))
            .then(function(){
                showView(oCurrentView, param ? param : false, getShowType(before.type, oCurrentView.type), before);
                if(oCurrentView.changedInPopupView) {
                    Volt.log("[router-controller.js] ###################################### ");
                }
                oCurrentView.deferred.resolve();
            }).fail(function(e){ Volt.log(e); });
    }else {
    	if('main-view' != oCurrentView.name){//note:just for detail view
			var before = _.clone(oCurrentView);
	        oCurrentView = cacheCtrl.get(sViewName);
	        oCurrentView.type = type;
	        oCurrentView.deferred = Q.defer();
			
			hideView(before, 'update')
            .then(function(){
                showView(oCurrentView, param ? param : false, getShowType(before.type, oCurrentView.type), before);
                if(oCurrentView.changedInPopupView) {
                    Volt.log("[router-controller.js] ###################################### ");
                }
                oCurrentView.deferred.resolve();
            }).fail(function(e){ Volt.log(e); });
		}
    }
    return oCurrentView;
}

function rootView(sViewName, params) {
    return changeView(sViewName, VIEW_TYPE_ROOT, params);
}

function secondDepthView(sViewName, params) {
    return changeView(sViewName, VIEW_TYPE_2ND_DEPTH, params);
}

function detailView(sViewName, params) {
    return changeView(sViewName, VIEW_TYPE_DETAIL, params);
}

function popupView(sViewName, params) {
	Volt.log('[router-controller.js] popupView~~~~~');
    Volt.log('[router-controller.js] ' + getPageTransitionLog(oCurrentView.name,sViewName,oCurrentView.type,VIEW_TYPE_POPUP));
    
    if (oCurrentView.instance) {
        pauseView(oCurrentView);
    }
    var before = _.clone(oCurrentView);
    oCurrentView = cacheCtrl.get(sViewName);
    oCurrentView.deferred = before.deferred;
    oCurrentView.changedInPopupView = true;
    oCurrentView.type = VIEW_TYPE_POPUP;
    oCurrentView.viewinfo = params;
    showView(oCurrentView, params, getShowType(before.type, oCurrentView.type),before);

    return oCurrentView;
}

function pauseView(viewCtrl,options) {
	Volt.log('[router-controller.js] pauseView~~~~~ viewCtrl.name = ' + viewCtrl.name);
	
    if (viewCtrl.instance && viewCtrl.instance.pause) {
		Volt.log('[router-controller.js]pauseView  pause the view');
        viewCtrl.instance.pause(options);
    }
}

function resumeView(view, options, showType) {
	Volt.log('[router-controller.js] resumeView~~~~~view.name = ' + view.name);
	
    if (view.instance && view.instance.resume) {
		Volt.log('[router-controller.js] resumeView~~~~~');
        view.instance.resume(options);
    }
}

function hideView(viewCtrl, hideType) {
	Volt.log('[router-controller.js] hideView.....viewCtrl.name = ' + viewCtrl.name);
    var deferred = Q.defer();

    if (!viewCtrl.instance) {
        deferred.resolve();
        return deferred.promise;

    }

    viewCtrl.instance
        .hide(hideType)
        .then(function(){
            deferred.resolve();
        });

    // deferred.resolve();
    return deferred.promise;
}

function showView(viewCtrl, params, showType, before) {
    Volt.log('[router-controller.js] showView~~~~~~~  params = ' + JSON.stringify(params));
    if (before && before.type == VIEW_TYPE_POPUP) {
        if(viewCtrl && viewCtrl.instance) {
            if(viewCtrl.instance.resume){
                viewCtrl.instance.resume(params, showType);
            }
        }
    } else {
        if(viewCtrl && viewCtrl.instance) {
            viewCtrl.instance.show(params, showType);
        }
    }
}

function getCurrentView(){
	Volt.log('[router-controller.js] getCurrentView oCurrentView.type = ' + oCurrentView.type + ',,,oCurrentView.name = ' + oCurrentView.name);
    return oCurrentView;
}

exports = {
    'root': rootView,
    'secondDepth': secondDepthView,
    'detail': detailView,
    'getCurrentView' : getCurrentView,
    'pauseView' : pauseView,
    'resumeView' : resumeView,
    'popup': popupView,
    'hideView': hideView,
};