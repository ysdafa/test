var Backbone         = Volt.requireNoContext('lib/volt-backbone.js');
var RouterController = Volt.requireNoContext('app/controller/router-controller.js');
var Mediator         = Volt.requireNoContext('app/common/event-mediator.js');
var CommonDefine     = Volt.requireNoContext('app/common/common-define.js');
var Utils            = Volt.requireNoContext('app/common/utils.js');
var PanelCommon      = Volt.requireNoContext('lib/panel-common.js');
var CommonContent    = Volt.requireNoContext('app/common/common-content.js');
var ErrorHandling  = Volt.requireNoContext('app/common/error-handling.js');
var voltApiWrapper      = Volt.requireNoContext("app/common/voltapi-wrapper.js");

var Router = Backbone.Router.extend({
	bNeedResume:false,
		
    initialize: function() {
        this.on('route', function() {
            print('[router.js] URL : ' + Backbone.history.location.hash);
        });
    },

	routes : {
		"home" : "home",
		"Spotlight" : "spotlight",
		"Brand Zone" : "brandzone",
		'What`s New' : "whatsNew",
		"Most Popular" : "mostPopular",
		"Top Grossing" : "topGrossing",

		"Arcade" : "arcade",
		"Party" : "party",
		"Puzzle" : "puzzle",
		"Sports" : "sports",
		"Shooting" : "shooting",

		"My Page" : "myPage",
		"detail/:id" : "detail",
		"coupon" : "coupon",
		"message" : "message",
		"genre/:viewInfo" : "genreDetail",
		"popup/:type" : "popup",
		//"msgpopup/:param" : "messagePopup",
		"msgpopup" : "messagePopup",
		"Rpg" : "rpg",
	},

    home: function() {
        Volt.log('[router.js] home....');
		RouterController.root('main-view').sub('main-spotlight-view'); 
    },
    
    spotlight:function(){
        Volt.log('[router.js] main-spotlight-view....');
		Volt.KPIMapper.enterPage('G02_SLIGHT');
        RouterController.root('main-view').sub('main-spotlight-view'); 
    },
    
    brandzone:function(){
       Volt.log('[router.js] main-brandzone-view....');
        RouterController.root('main-view').sub('main-brandzone-view');
    },
    
    whatsNew:function(){
        Volt.log('[router.js] main-whatsnew-view....');
		Volt.KPIMapper.enterPage('G04_WHATSNEW');
        RouterController.root('main-view').sub('main-whatsnew-view');
    },
    
    mostPopular:function(){
        Volt.log('[router.js] main-popular-view....');
		Volt.KPIMapper.enterPage('G03_POPULAR');
        RouterController.root('main-view').sub('main-popular-view');
    },
    
    topGrossing:function(){
        Volt.log('[router.js] main-grossing-view....');
		Volt.KPIMapper.enterPage('G05_TOPGROSSING');
		RouterController.root('main-view').sub('main-grossing-view');
	},
	arcade : function() {
		Volt.log('[router.js] main-genre-arcade-view....');
		Volt.KPIMapper.enterPage('G09_GENRE01');
		RouterController.root('main-view').sub('main-genre-arcade-view');
	},

	party : function() {
		Volt.log('[router.js] main-genre-party-view....');
		Volt.KPIMapper.enterPage('G11_GENRE03');
		RouterController.root('main-view').sub('main-genre-party-view');
	},

	puzzle : function() {
		Volt.log('[router.js] main-genre-puzzle-view....');
		Volt.KPIMapper.enterPage('G12_GENRE04');
		RouterController.root('main-view').sub('main-genre-puzzle-view');
	},

	sports : function() {
		Volt.log('[router.js] main-genre-sports-view....');
		Volt.KPIMapper.enterPage('G10_GENRE02');
		RouterController.root('main-view').sub('main-genre-sports-view');
	},

	shooting : function() {
		Volt.log('[router.js] main-genre-shooting-view....');
		Volt.KPIMapper.enterPage('G13_GENRE05');
		RouterController.root('main-view').sub('main-genre-shooting-view');
	},
	
	rpg : function() {
        Volt.log('[router.js] main-genre-rpg-view....');
        Volt.KPIMapper.enterPage('G14_GENRE06');
        RouterController.root('main-view').sub('main-genre-rpg-view');
    },

	myPage : function() {
		Volt.log('[router.js] main-mypage-view-new....');
		Volt.KPIMapper.enterPage('G01_MYPAGE');
        RouterController.root('main-view').sub('main-mypage-view-new');
    },
    
    detail : function(id,option){
        Volt.log('[router.js] detail-view....id = ' + id);
        var appdw = 'n';
        if(voltApiWrapper.isWidgetInstalled(id)){
            appdw ='y';
        }
        Volt.KPIMapper.enterPage('G08_DETAIL',{d:{appid: id,appdw:appdw}});
        option.id = id;
        RouterController.detail('detail-view',option);
    },
    
    coupon : function(option){
        Volt.log('[router.js] coupon-box-view....');
		Volt.KPIMapper.enterPage('G07_COUPON');
        RouterController.secondDepth('coupon-box-view',option);
    },
    
    message : function(){
        Volt.log('[router.js] message-box-view....');
        RouterController.secondDepth('message-box-view');
    },
    
    popup : function(type){
        Volt.log('[router.js] popup-view ....type = ' + type);
        if (type.indexOf("select-games") > 0) {
            Volt.log('[router.js] popup....select-games-popup');
            //RouterController.popup(params.type + '-popup', params.id);
            RouterController.popup('select-games-popup', type);
        } else if (type.indexOf("game-rating") > 0) {
            Volt.log('[router.js] popup....game-rating-popup');
            RouterController.popup('game-rating-popup', type);
        } else if (type.indexOf("choose-device") > 0) {
            Volt.log('[router.js] popup....choose-device-popup');
            RouterController.popup('choose-device-popup', type);
        } else if (type.indexOf("input-text") > 0) {
            Volt.log('[router.js] popup....input-text-popup');
            RouterController.popup('input-text-popup', type);
        } else if (type.indexOf("delete") > 0) {
            Volt.log('[router.js] popup....delete-popup');
            RouterController.popup('delete-popup', type);
        } else if (type.indexOf("cpinstall") > 0) {
            Volt.log('[router.js] popup....cpinstall-popup');
            RouterController.popup('cpinstall-popup', type);
        } else {
            Volt.log('[router.js] popup ....last else branch ');
            RouterController.popup(type + '-popup', type);
        }
	},
	
    genreDetail:function(viewInfo){
        Volt.log("[router.js]genre-detail-view....viewInfo = " + viewInfo + ',viewInfo.genreName = ' + JSON.parse(viewInfo).genreName);
		//Volt.KPIMapper.enterPage('G06_GENRE',{d:{genre : JSON.parse(viewInfo).genreName }});
        RouterController.secondDepth('genre-detail-view',viewInfo);
    },
    
	messagePopup:function(param){
		Volt.log('[router.js] popup ....message-popup param.titletext = ' + param.msgParam);
		RouterController.popup('message-box-popup',param.msgParam);
	},

});

exports = new Router();