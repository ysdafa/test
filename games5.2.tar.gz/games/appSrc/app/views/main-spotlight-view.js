var PanelCommon   = Volt.requireNoContext('lib/panel-common.js');
var Backbone      = Volt.requireNoContext('lib/volt-backbone.js');
var CommonContent = Volt.requireNoContext('app/common/common-content.js');
//var progressClass = Volt.requireNoContext("modules/UIElement/ProgressBar.js");
var Mediator      = Volt.requireNoContext('app/common/event-mediator.js');
var LoadingView   = Volt.requireNoContext('app/views/loading-view.js');
var CommonDefine  = Volt.requireNoContext('app/common/common-define.js');
var Gridlist      = Volt.requireNoContext('app/views/grid-list-view.js');
var Utils         = Volt.requireNoContext('app/common/utils.js');

var SpotLightModel    = Volt.requireNoContext('app/models/spotlight-model.js');
var GridlistTemplate  = Volt.requireNoContext('app/templates/1080/grid-list-template.js');
var MainCategoryModel = Volt.requireNoContext("app/models/main-category-model.js");
var NoContentView 	  = Volt.requireNoContext('app/views/no-content-view.js');
var voltApiWrapper    = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var VoiceGuide        = Volt.requireNoContext('app/common/voiceGuide.js');
var networkStatus = Volt.requireNoContext('app/common/network-state.js');

var realDataStateInSpotlight = false;
var spotLightSelf = null;
var autoLaunchAppId = null;

var SpotLightView = PanelCommon.BaseView.extend({
    parent     : null,
    contentWgt : null,
    groupCnt   : 0,
    viewIsVisible   : false,
    bListenerStatus : false,
    viewType        : 'spotlight',
    renderSignState : null,
    spotlightData   : null,
    groupTitles     : null,
    gridViewInSpotlight : null,
    netWorkErrMsg   : null,
    firstLoad       : false,
    signStateChanged: false,
    delayFocus      : false,
    accountSpotLight : null,

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    initialize : function() {
        Volt.log('spotlight initialize');
        this.spotlightData = {};
        this.spotlightData.groups = [];
        this.firstLoad = true;
        spotLightSelf = this;
    },

    requestData : function() {
        var that = this;
        function onSuccess() {
            //this.remove();
            //LoadingView.hide();
            that.renderContent();
            that.bInRefresh = false;
        }

        function onError() {
            //LoadingView.hide();
            var viewType = CommonContent.getViewType();
            if (viewType == "#Spotlight") {
                // ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR, '', JSON.stringify(msg.status));
                // that.handleError();
            }
            that.bInRefresh = false;
        }


        SpotLightModel.fetch().then(onSuccess, onError);
    },

    render : function(parentWidget) {
        Volt.log('[main-spotlight-view.js] spotlight view render');
        realDataStateInSpotlight = MainCategoryModel.isReady();
        this.parent = parentWidget.widget.getChild('main-content-container');
        //this.listenTo(MainCategoryModel, 'change:ready', this.updateContent);

        this.renderSignState = Utils.Account.getSignState();
        Volt.log('[main-spotlight-view.js] render ~~~~~ signStateInSpotlight =' + this.renderSignState);
        
        this.accountSpotLight = Utils.Account.getAccount();
        Volt.log('[main-spotlight-view.js] render ~~~~~ accountSpotLight =' + this.accountSpotLight);

        return this;
    },

    updateContent : function() {
        Volt.log('[main-spotlight-view.js] updateContent');
        Volt.log('[main-spotlight-view.js] updateContent contentWgt = ' + this.contentWgt);
        realDataStateInSpotlight = MainCategoryModel.isReady();
        if (this.contentWgt) {
            if (this.contentWgt.id != "SPOTLIGNT_CONTENT") {
                if (realDataStateInSpotlight) {
                    this.remove();
                    this.renderContent();
                }
                return;
            }
            var groupCntReal = 0;

            var trending_list = SpotLightModel.get('trending_list');
            var genre_games_list = SpotLightModel.get('genre_games_list');
            var friends_pick_list = SpotLightModel.get('friends_pick_list');
            //var friends_pick_list = SpotLightModel.get('genre_games_list');//only test for add group

            if (trending_list.length > 0)
                groupCntReal++;
            if (genre_games_list.length > 0)
                groupCntReal++;

            var signState = Utils.Account.getSignState();
            if (signState) {
                if (friends_pick_list.length > 0)
                    groupCntReal++;
            }

            var dataStyleStr = "";
            for (var index = 0; index < this.groupCnt; index++) {
                dataStyleStr += this.spotlightData.groups[index].dataStyle;
            }

            Volt.log('[main-spotlight-view.js] updateContent  dataStyleStr = ' + dataStyleStr);
            Volt.log('[main-spotlight-view.js] updateContent  this.groupCnt = ' + this.groupCnt);
            Volt.log('[main-spotlight-view.js] updateContent  groupCntReal =' + groupCntReal);
            this.groupTitles = this.gridViewInSpotlight.groupTitle;
            Volt.log('[main-spotlight-view.js] updateContent  this.groupTitles =' + this.groupTitles);

            if (this.groupCnt < groupCntReal) {
                //group number increased
                Volt.log('[main-spotlight-view.js] updateContent  group number increased');
                this.addGroupForSpotlight(dataStyleStr, trending_list, genre_games_list, friends_pick_list);
                this.updateItems();
                this.contentWgt.groupCnt = groupCntReal;
            } else if (this.groupCnt > groupCntReal) {
                //group number decreased
                Volt.log('[main-spotlight-view.js] updateContent  group number decreased');
                this.removeGroup(dataStyleStr, genre_games_list, friends_pick_list);
                this.updateDataForAllGroup(trending_list, genre_games_list, friends_pick_list);
                this.contentWgt.groupCnt = groupCntReal;
            } else {
                //group number does not chang,only update datas
                Volt.log('[main-spotlight-view.js] updateContent  group number does not chang');
                this.updateDataForAllGroup(trending_list, genre_games_list, friends_pick_list);
            }

        } else {
            this.renderContent();
        }

    },

    renderContent : function() {
        Volt.log('main-spotlight-view renderContent....');
        var trending_count = parseInt(SpotLightModel.get('trending_list_cnt'));
        var genre_count = parseInt(SpotLightModel.get('genre_games_list_cnt'));
        var friends_count = parseInt(SpotLightModel.get('friends_pick_list_cnt'));
        var totalCount = trending_count + genre_count + friends_count;

        Volt.log('main-spotlight-view renderContent.... contentWgt =' + this.contentWgt);
        if (!this.contentWgt) {
            if (totalCount == 0) {
                var noContentWgtId = this.viewType;
                var textToShow = Volt.i18n.t('COM_NO_CONTENT_FOUND');
                this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;
            } else {
                this.contentWgt = this.initGrid(this);
                this.contentWgt.id = "SPOTLIGNT_CONTENT";
                this.contentWgt.focusable = true;
                this.contentWgt.show();
            }
            this.parent.addChild(this.contentWgt);
        } else {
            this.updateContent();
        }

        this.setWidget(this.contentWgt);
        this.setFirstFocus();

        Volt.Nav.reload();
    },
    
    setFirstFocus : function(){
        //this.setFocusForSpotlight();
        var isActive = CommonContent.getPanelActive();
        Volt.log('isActive::::'+isActive);
        if (this.firstLoad) {
            Volt.log('main-spotlight-view renderContent.... setFocus');
            Volt.log('main-spotlight-view renderContent.... isActive =' + isActive);
            if(isActive){
                if (this.contentWgt.focusable) {
                    Volt.Nav.focus(this.contentWgt);
                } else {
                    Volt.Nav.focus(Volt.Nav.getItem(3));
                }
            } else {
                this.delayFocus = true;
            }
        }
    },

    updateDataForAllGroup : function(trending_list, genre_games_list, friends_pick_list) {
        Volt.log('[main-spotlight-view.js] updateDataForAllGroup');
        var group = -1;

        if (trending_list.length > 0) {
            group++;
            CommonContent.updateData(trending_list, group, this.contentWgt);
        }

        if (genre_games_list.length > 0) {
            group++;
            CommonContent.updateData(genre_games_list, group, this.contentWgt);
        }

        var signState = Utils.Account.getSignState();
        if (signState) {
            if (friends_pick_list.length > 0) {
                group++;
                CommonContent.updateData(friends_pick_list, group, this.contentWgt);
            }
        }
        Volt.log('[updateDataForAllGroup] updateItems');
        this.updateItems();
    },

    removeGroup : function(dataStyleStr, genre_games_list, friends_pick_list) {
        Volt.log('[main-spotlight-view.js] removeGroup');

        if (genre_games_list.length == 0) {
            if (dataStyleStr.indexOf("genre") >= 0) {
                Volt.log('[main-spotlight-view.js] clearDataSource --- genre_games_list');
                this.clearDataFromGroup();
            }
        }

        var signState = Utils.Account.getSignState();
        Volt.log('[main-spotlight-view.js] removeGroup signState =' + signState);
        this.renderSignState = signState;
        var currentAccount = this.getCurrentAccount();
        Volt.log('[main-spotlight-view.js] removeGroup currentAccount =' + currentAccount);
        if(!signState || (this.accountSpotLight !== currentAccount)){
            this.removeFriendPickGroup(dataStyleStr);
            this.accountSpotLight = currentAccount;
        }
    },
    
    getCurrentAccount : function(){
        //account has changed
        var currentAccount = null;
        var accountInfo = voltApiWrapper.getSSOLoginInfo();        
        if (accountInfo && accountInfo.login_id) {
            currentAccount = accountInfo.login_id;
        }
        
        return currentAccount;
    },
    
    removeFriendPickGroup : function(dataStyleStr){
        Volt.log('[main-spotlight-view.js] removeFriendPickGroup --- friends_pick_list');
        //only remove friendPick group
        if (dataStyleStr.indexOf("friendsPick") >= 0) {
            this.clearDataFromGroup();
        }
    },

    clearDataFromGroup : function() {
        this.contentWgt.clearDataSource(this.groupCnt - 1);
        this.contentWgt.allGroupDataArr[this.groupCnt - 1] = [];
        this.groupTitles[this.groupCnt - 1].destroy();
        this.groupCnt--;
        this.contentWgt.loadData();
    },

    addGroupForSpotlight : function(dataStyleStr, trending_list, genre_games_list, friends_pick_list) {
        Volt.log('[main-spotlight-view.js] addGroupForSpotlight');
        Volt.log("[main-spotlight-view.js] addGroupForSpotlight dataStyleStr= " + dataStyleStr);
        var group = -1;
        if (trending_list.length > 0) {
            if (-1 == dataStyleStr.indexOf("trending")) {
                Volt.log('[main-spotlight-view.js] addGroupForSpotlight ---- trending_list');
                var trending_title = SpotLightModel.get('trending_title');
                this.spotlightData.groups.push({
                    title : trending_title,
                    modelArr : trending_list,
                    dataStyle : "trending"
                });

                this.addNewGroup();
            } else {
                //only update data
                group++;
                CommonContent.updateData(trending_list, group, this.contentWgt);
            }
        }

        if (genre_games_list.length > 0) {
            if (-1 == dataStyleStr.indexOf("genre")) {
                Volt.log('[main-spotlight-view.js] addGroupForSpotlight ---- genre_games_list');
                var genre_games_title = SpotLightModel.get('genre_games_title');
                this.spotlightData.groups.push({
                    title : genre_games_title,
                    modelArr : genre_games_list,
                    dataStyle : "genre"
                });

                this.addNewGroup();
            } else {
                //only update data
                group++;
                CommonContent.updateData(genre_games_list, group, this.contentWgt);
            }
        }

        var signState = Utils.Account.getSignState();
        this.renderSignState = signState;
        if (signState) {
            if (friends_pick_list.length > 0) {
                Volt.log('[main-spotlight-view.js] dataStyleStr.indexOf("friendsPick") =' + dataStyleStr.indexOf("friendsPick"));
                if (-1 == dataStyleStr.indexOf("friendsPick")) {
                    Volt.log('[main-spotlight-view.js] addGroupForSpotlight ---- friends_pick_list');
                    this.spotlightData.groups.push({
                        title : Volt.i18n.t('TV_SID_FRIENDS_PICKS'),
                        modelArr : friends_pick_list,
                        dataStyle : "friendsPick"
                    });

                    this.addNewGroup();
                } else {
                    //only update data
                    group++;
                    CommonContent.updateData(friends_pick_list, group, this.contentWgt);
                }
            }
        }
        
        var currentAccount = this.getCurrentAccount();
        Volt.log('[main-spotlight-view.js] addGroupForSpotlight currentAccount =' + currentAccount);
        if(this.accountSpotLight !== currentAccount){
            this.accountSpotLight = currentAccount;
        }
    },

    addNewGroup : function() {
        Volt.log('[main-spotlight-view.js] addNewGroup');
        this.groupCnt++;
        Volt.log('[main-spotlight-view.js] addNewGroup ---- this.groupCnt =' + this.groupCnt);

        var modalData = JSON.stringify(this.spotlightData);
        var transformedData = JSON.parse(modalData);
        if (this.contentWgt.allGroupDataArr[this.groupCnt - 1])
            Volt.log('[main-spotlight-view.js] assignGridData group length1 =' + this.contentWgt.allGroupDataArr[this.groupCnt - 1].length);

        var bGroupCreated = this.gridViewInSpotlight.bGroupCreated;
        Volt.log('[main-spotlight-view.js] addNewGroup bGroupCreated =' + bGroupCreated);
        Volt.log('[main-spotlight-view.js] addNewGroup bGroupCreated =' + bGroupCreated[this.groupCnt - 1]);
        if (bGroupCreated[this.groupCnt - 1]) {
            // add group title
            var groupWidth = this.gridViewInSpotlight.groupWidth[this.groupCnt - 1];
            this.gridViewInSpotlight.renderGroupTitle(this.groupCnt - 1, this.spotlightData.groups[this.groupCnt - 1].title, groupWidth);

        } else {
            this.contentWgt.addGroup(1);
            this.contentWgt.addStyle(1);
            this.gridViewInSpotlight.renderGridGroup(this.groupCnt - 1, this.spotlightData.groups[this.groupCnt - 1], null);
        }

        this.contentWgt.addDataGroup(1);

        Volt.log('[main-spotlight-view.js] assignGridData');
        this.gridViewInSpotlight.assignGroupData(this.groupCnt - 1, transformedData.groups[this.groupCnt - 1].modelArr, null);
        Volt.log('[main-spotlight-view.js] addNewGroup group length2 =' + this.contentWgt.allGroupDataArr[this.groupCnt - 1].length);

        Volt.log('[main-spotlight-view.js] addNewGroup loadData');
        this.contentWgt.loadData();
    },

    initGrid : function(self) {
        //var spotlightData    = {};
        self.spotlightData.style = CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME;
        self.spotlightData.groups = [];

        var trending_list = SpotLightModel.get('trending_list');
        var trending_title = SpotLightModel.get('trending_title');
        var sub_title1 = trending_title ? trending_title : Volt.i18n.t('TV_SID_TRENDING');
        if (trending_list.length > 0) {
            self.groupCnt++;
            self.spotlightData.groups.push({
                title : sub_title1,
                modelArr : trending_list,
                dataStyle : "trending"
            });
        }

        var genre_games_list = SpotLightModel.get('genre_games_list');
        var genre_games_title = SpotLightModel.get('genre_games_title');
        var sub_title2 = genre_games_title ? genre_games_title : Volt.i18n.t('COM_TV_SID_GENRES');
        if (genre_games_list.length > 0) {
            self.groupCnt++;
            self.spotlightData.groups.push({
                title : sub_title2,
                modelArr : genre_games_list,
                dataStyle : "genre"
            });
        }

        var signState = Utils.Account.getSignState();
        if (signState) {
            var friends_pick_list = SpotLightModel.get('friends_pick_list');
            //var friends_pick_list = SpotLightModel.get('genre_games_list');//only for test for remove group
            if (friends_pick_list.length > 0) {
                self.groupCnt++;
                self.spotlightData.groups.push({
                    title : Volt.i18n.t('TV_SID_FRIENDS_PICKS'),
                    modelArr : friends_pick_list,
                    dataStyle : "friendsPick"
                });
            }
        }

        var gridView = new Gridlist(GridlistTemplate.Spotlight, JSON.stringify(self.spotlightData), parseInt(1920 * 0.16875), parseInt(1080 * 0.377778));
        self.gridViewInSpotlight = gridView;

        gridView.setItemData = function(mustache, modelData) {
            Volt.log("gridView  setItemData modelData =" + modelData);
            mustache.imgUrl = (modelData['thumbnail_url']) ? modelData['thumbnail_url'] : '';
            mustache.title = (modelData['game_title']) ? modelData['game_title'] : '';
            mustache.genre = (modelData['genre']) ? modelData['genre'] : '';
            mustache.app_id = (modelData['app_id']) ? modelData['app_id'] : '';
            mustache.rating = (modelData['rating']) ? modelData['rating'] : '';
            mustache.size = (modelData['size']) ? modelData['size'] : '';
            mustache.controller_list = (modelData['controller_list']) ? modelData['controller_list'] : '';
            mustache.downloadable = (modelData['downloadable']) ? modelData['downloadable'] : '';
            mustache.popup_flag = (modelData['popup_flag']) ? modelData['popup_flag'] : '';
            mustache.popup_text = (modelData['popup_text']) ? modelData['popup_text'] : '';
        };

        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
            Volt.log("gridView  setTemplate");
            CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
            CommonContent.addThumbnailListener(rendererInstance.thumbnail);
            CommonContent.setFoverFactor(rendererInstance.thumbnail, parentWidth);
            this.onItemUpdate(rendererInstance, data, null);
            this.onItemIconLoad(data, rendererInstance);
        };

        gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
            var spValue = '';
            var spIndex = 0;

            if (groupIndex == 0) {
                spIndex = itemIndex + 1;
            } else if (groupIndex == 1) {
                spIndex = parseInt(SpotLightModel.get('trending_list_cnt')) + 1 + itemIndex;
            } else if (groupIndex == 2) {
                spIndex = parseInt(SpotLightModel.get('trending_list_cnt')) + parseInt(SpotLightModel.get('genre_games_list_cnt')) + 1 + itemIndex;
            }

            spValue = Volt.KPIMapper.getSelectPosition(spIndex);
            Volt.log("[main-spotlight-view.js] gridView  onItemPress");

            var Renderer = this.widget.renderer(groupIndex, itemIndex);
            if (itemData.popup_flag == 'Y') {
                var ErrorHandling = Volt.requireNoContext('app/common/error-handling.js');
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_PSN, '', itemData.popup_text);
            } else {
                CommonContent.onLaunch('G02_SLIGHT', itemData.app_id, Renderer.thumbnail, spValue);
            }
            //CommonContent.onLaunch('', itemData.app_id);
        };

        gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {
            Volt.log("[main-spotlight-view.js] gridView  fromFocusChangeStart");
            //this.onTextScrollStart(parent);
        };

        gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {
            Volt.log("[main-spotlight-view.js] gridView  toFocusChangeEnd");
            //this.onTextScrollEnd(parent);
        };

        gridView.itemLoaded = function(gridList, groupIndex, itemIndex) {
            Volt.log("[main-spotlight-view.js] gridView  itemLoaded");
            var data = gridList.getData(groupIndex, itemIndex);
            data.group = groupIndex;
            if (groupIndex == 0) {
                data.item = itemIndex;
            } else if (groupIndex == 1) {
                data.item = itemIndex + SpotLightModel.get('trending_list_cnt');
            } else if (groupIndex == 2) {
                data.item = itemIndex + SpotLightModel.get('trending_list_cnt') + SpotLightModel.get('genre_games_list_cnt');
            }

            //self.groupTitles = gridView.groupTitle;
        };
        
        gridView.itemUnloaded = function(gridList, groupIndex, itemIndex) {
            
        };

        gridView.updateElements = function(parent, data) {
            Volt.log('[main-spotlight-view.js] updateElements');

            this.onItemUpdate(parent, data, null);
            this.onItemIconLoad(data, parent);
        };

        gridView.resetElements = function(parent, data) {
            Volt.log('[main-spotlight-view.js] resetElements');
            //update install icon
            this.onItemIconReset(data);
        };

        gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
            Volt.log('[main-spotlight-view.js] gridView.focusChanged toItemIndex = ' + toItemIndex + ',,,toGroupIndex = ' + toGroupIndex);
            Volt.bQueuingPlay = false;
            if (toItemIndex >= 0 && toGroupIndex >= 0) {
                var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];

                var voiceText = '';
                if (-1 == fromItemIndex) {
                    voiceText += Volt.i18n.t('UID_PAN_GAMES') + ',' + Volt.i18n.t('TV_SID_MIX_CATEGORY_END').replace('<<A>>', Volt.i18n.t('TV_SID_SPOTLIGHT')) + ',';
                    var tempNum = 0;
                    var title = '';
                    if (0 == toGroupIndex) {
                        tempNum = SpotLightModel.get('trending_list_cnt');
                        Volt.pageItemIndex = toItemIndex + 1;
                        var trending_title = SpotLightModel.get('trending_title');
                        title = trending_title ? trending_title : Volt.i18n.t('TV_SID_TRENDING');
                    } else if (1 == toGroupIndex) {
                        tempNum = SpotLightModel.get('genre_games_list_cnt');
                        Volt.pageItemIndex = parseInt(SpotLightModel.get('trending_list_cnt')) + 1 + toItemIndex;
                        var genre_games_title = SpotLightModel.get('genre_games_title');
                        title = genre_games_title ? genre_games_title : Volt.i18n.t('COM_TV_SID_GENRES');
                    } else if (2 == toGroupIndex) {
                        tempNum = SpotLightModel.get('friends_pick_list_cnt');
                        Volt.pageItemIndex = parseInt(SpotLightModel.get('trending_list_cnt')) + parseInt(SpotLightModel.get('genre_games_list_cnt')) + 1 + toItemIndex;
                        title = Volt.i18n.t('TV_SID_FRIENDS_PICKS');
                    }

                    if (title) {
                        voiceText += title + ',';
                    }
                    voiceText += Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', tempNum) + ',';
                }

                voiceText += data.title + '.';
                VoiceGuide.getVoiceGuide(voiceText);
                Volt.log('autoLaunchAppId:::'+autoLaunchAppId);
                var state = voltApiWrapper.getSSOLoginState();
                if(spotLightSelf.signStateChanged && state && autoLaunchAppId){
                   voltApiWrapper.launchApp(autoLaunchAppId);
                   autoLaunchAppId = null;
                }
			}
        };

        return gridView.render().widget;
    },

    remove : function() {
        Volt.log('[main-spotlight-view.js] remove');
        if (this.contentWgt) {
            Volt.log('[main-spotlight-view.js] remove1');
            this.contentWgt.id = '';
            Volt.Nav.focus(null);
            Volt.Nav.removeItem(this.contentWgt);
            this.parent.removeChild(this.contentWgt);
            this.contentWgt.destroy();
            this.contentWgt = null;
            this.gridViewInSpotlight = null;
        }

        this.groupCnt = 0;
        this.spotlightData.groups = [];
    },

    onFocus : function(widget) {
        Volt.log('[main-spotlight-view.js] ContentView.onFocus');

        if (this.contentWgt) {
            widget = this.contentWgt;
            Volt.Nav.focus(this.contentWgt);
            widget.onFocus();
            this.firstLoad = false;
        }
    },

    onBlur : function(widget) {
        if (widget) {
            Volt.log('[main-spotlight-view.js] ContentView.onBlur');
            if (this.contentWgt && this.contentWgt.onBlur) {
                this.contentWgt.onBlur();
            }
        }
    },

    show : function(param, animationType) {
        Volt.log('[main-spotlight-view.js] show');
        Mediator.on(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, this.updateListenerFlag, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
        Mediator.on(CommonDefine.Event.SIGN_STATE_UPDATE, this.refresh, this);
        Mediator.on('UPDATE_EVENTLISTENER_FLAG_MYPAGE',this.updateEventWhenEnterIntoDetail, this);

        this.startListening();
        this.addEventListener();
        if (this.contentWgt) {
            if (this.contentWgt.hasOwnProperty('focusable')) {
                this.contentWgt.focusable = true;
            }
            if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'SPOTLIGNT_CONTENT') {
                this.contentWgt.showWithAnimation();
            } else {
                this.contentWgt.show();
            }
        }

        this.viewIsVisible = true;
        Volt.Nav.reload();

        Volt.log('[main-spotlight-view.js] show ready = ' + MainCategoryModel.isReady());
        var categoryState = MainCategoryModel.isReady();
        if (categoryState && (categoryState != realDataStateInSpotlight)) {
            Volt.log('[main-spotlight-view.js] show update from cacheData to realData ');
            this.updateContent();
            realDataStateInSpotlight = categoryState;
        } else {
            Volt.log('[show]updateItems');
            this.updateItems();
        }
    },

    hide : function(animationType) {
        Volt.log('[main-spotlight-view.js] hide');
        this.viewIsVisible = false;
        this.removeEventListener();
        this.stopListening();
        Mediator.off(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, null, this);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE,      null, this);
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE,        null, this);
        Mediator.off(CommonDefine.Event.UPDATE_FOR_REAL_DATA,     null, this);
        Mediator.off(CommonDefine.Event.UPDATE_FOR_CACHE_DATA,    null, this);
        Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE,        null, this);
        Mediator.off('UPDATE_EVENTLISTENER_FLAG_MYPAGE',          null, this);

        if (this.contentWgt) {

            if (this.contentWgt.hasOwnProperty('focusable')) {
                this.contentWgt.focusable = false;
            }
            if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'SPOTLIGNT_CONTENT') {
                this.contentWgt.hideWithAnimation();
            } else {
                this.contentWgt.hide();
            }
        }
    },
    
    updateEventWhenEnterIntoDetail : function(flag){
        Volt.log('[main-spotlight-view.js] updateEventWhenEnterIntoDetail flag ='+ flag);
        if(flag){
            Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
            Mediator.on(CommonDefine.Event.SIGN_STATE_UPDATE, this.refresh, this);
        } else {
            Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE, null, this);
            Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, this);
        }
    },

    deactive : function() {
        Volt.log('[main-spotlight-view.js] deactive');
        this.stopListening();
    },

    active : function() {
        Volt.log('[main-spotlight-view.js] active');
        this.startListening();
        if(!this.bInRefresh){
            this.updateItems();
        }
        this.bInRefresh = false;
        
        Volt.log('[main-spotlight-view.js] active this.delayFocus =' + this.delayFocus);
        if(this.delayFocus){
            if (this.contentWgt.focusable) {
                Volt.Nav.focus(this.contentWgt);
            } else {
                Volt.Nav.focus(Volt.Nav.getItem(3));
            }
            this.delayFocus = false;
        }
    },

    handleError : function(option) {
        Volt.log("[main-spotlight-view.js] handleError");
        this.remove();
        var noContentWgtId = this.viewType;
        if (networkStatus.getNetWorkState()) {
            var textToShow = Volt.i18n.t('TV_SID_MIX_UABLE_CONNECT_SAMSUNG_SERVER').replace('<<A>>', "400");
            this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;
        } else {
            var textToShow = Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>', "400");
            this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_WITH_BTN).widget;
        }
        this.parent.addChild(this.contentWgt);
        this.setWidget(this.contentWgt);
        if (this.firstLoad) {
            if (this.contentWgt.focusable) {
                Volt.Nav.focus(this.contentWgt);
            } else if (option.categoryLength > 0) {
                Volt.Nav.focus(Volt.Nav.getItem(3));
            } else {
                Volt.Nav.focus(Volt.Nav.getItem(0));
            }
        }
        Volt.Nav.reload();
    },

    addEventListener : function() {
        Volt.log('[main-spotlight-view.js] addEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == false) {
            Mediator.on(CommonDefine.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
            Mediator.on(CommonDefine.Event.BEGIN_DOWNLOAD, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_CANCELED, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
            Mediator.on(CommonDefine.Event.UNINSTALL, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.NETWORK_ERROR, this.handleError, this);
            Mediator.on(CommonDefine.Event.DISCONNECT_USB, this.disconnectUSB, this);
            Mediator.on(CommonDefine.Event.CONNECT_USB, this.connectUSB, this);
            this.bListenerStatus = true;
        }
    },

    removeEventListener : function() {
        Volt.log('[main-spotlight-view.js] removeEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == true) {
            Mediator.off(CommonDefine.Event.MSGBOX_BUTTON, null, this);
            Mediator.off(CommonDefine.Event.DOWNLOAD_PROGRESS, null, this);
            Mediator.off(CommonDefine.Event.INSTALL, null, this);
            Mediator.off(CommonDefine.Event.BEGIN_DOWNLOAD, null, this);
            Mediator.off(CommonDefine.Event.DOWNLOAD_CANCELED, null, this);
            Mediator.off(CommonDefine.Event.UNINSTALL, null, this);
            //Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE, null, this);
            Mediator.off(CommonDefine.Event.NETWORK_ERROR, null, this);
            Mediator.off(CommonDefine.Event.DISCONNECT_USB, null, this);
            Mediator.off(CommonDefine.Event.CONNECT_USB, null, this);
            this.bListenerStatus = false;
        }
    },

    connectUSB : function() {
        Volt.log('[main-spotlight-view.js] connectUSB ');
        //need update icons when games installed on USB and disconnectUSB
        this.updateItems();
    },
    
    disconnectUSB : function() {
        Volt.log('[main-spotlight-view.js] disconnectUSB ');
        //need update icons when games installed on USB and disconnectUSB
        //this.updateItems();
    },

    updateListenerFlag : function(flag) {
        Volt.log('[main-spotlight-view.js] updateListenerFlag,flag = ' + flag);
        if (flag == true) {
            this.addEventListener();
            this.startListening();
        } else {
            this.removeEventListener();
            this.stopListening();
        }
        this.bListenerStatus = flag;
    },

    startListening : function() {
        Volt.log('[main-spotlight-view.js] startListening ');
        Mediator.on(CommonDefine.Const.UPDATE_ITEMS, this.updateItems, this);

        Mediator.on(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
        Mediator.on(CommonDefine.Event.UPDATE_FOR_CACHE_DATA, this.updateContent, this);
    },

    stopListening : function() {
        Volt.log('[main-spotlight-view.js] stopListening ');
        Mediator.off(CommonDefine.Const.UPDATE_ITEMS, null, this);
    },

    refresh : function() {
        Volt.log('[main-spotlight-view.js] refresh ');
        this.bInRefresh = true;
        //this.remove();
        //LoadingView.show(CommonDefine.Const.SWITCH_WHILE_LOADING);
        this.signStateChanged = true;
        this.requestData();
        //this.updateItems();
    },

    updateItems : function() {
        Volt.log('[main-spotlight-view.js] updateItems');
        //var currentSignState = voltApiWrapper.getSSOLoginState();
        var currentSignState = Utils.Account.getSignState();
        Volt.log('[main-spotlight-view.js] updateItems currentSignState =' + currentSignState);
        var currentAccount = this.getCurrentAccount();
        if (this.renderSignState != currentSignState) {
            this.renderSignState = currentSignState;
            this.refresh();
        } else if(this.accountSpotLight !== currentAccount){
            this.accountSpotLight = currentAccount;
            this.refresh();
        } else {
            if (this.contentWgt && this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'SPOTLIGNT_CONTENT') {
                for (var i = 0; i < this.groupCnt; i++) {
                    Volt.log("[main-spotlight-view.js] updateAllItems~~group index is " + i);
                    this.contentWgt.updateAllItems && this.contentWgt.updateAllItems(i);
                }
            }

        }
    },

    processMsgBoxEvent : function(data) {
        Volt.log('[main-spotlight-view.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType + data.appID);
        if (data.eventType == CommonDefine.Event.SELECT_BTN1) {
            switch(data.msgBoxtype) {
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS:
                    Volt.log('[main-spotlight-view.js] MSGBOX_TYPE_DELETE_SUNCCESS');
                    var dataObj = checkingGroupAndIndex(this, data.appID);
                    if (dataObj) {
                        Volt.log('[main-spotlight-view.js] MSGBOX_TYPE_DELETE_SUNCCESS, group = ' + dataObj.group + ",index = " + dataObj.index);
                        this.checkValid(dataObj.group, dataObj.index);
                    }

                    break;

                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_CHECK:
                    Volt.log('[main-spotlight-view.js] begin delete');
                    Volt.setTimeout(function() {
                        Volt.log('[main-spotlight-view.js] begin delete appNum = ' + data.appID.length);
                        CommonContent.showDeletePopup(false, data.appID);
                    }, 200);
                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
                    autoLaunchAppId = data.appID;
                    voltApiWrapper.startSSOPopup();
                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB:
                    this.updateItems();
                    break;
                default:
                    break;
            }
        } else if (data.eventType == CommonDefine.Event.SELECT_BTN2) {
            switch(data.msgBoxtype) {
                default:
                    break;
            }
        } else if (data.eventType == CommonDefine.Event.EVENT_CLOSE_POPUP) {

        }
    },

    updateProgressBar : function(eventInfo) {
        Volt.log('[main-spotlight-view.js] updateProgressBar');
        if (spotLightSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-spotlight-view.js] updateProgressBar, ID = ' + eventInfo.app_id);

        var dataObj = checkingGroupAndIndex(spotLightSelf, eventInfo.app_id);
        if (dataObj) {
            var groupArr = dataObj.groupArr;
            for (var i = 0; i < groupArr.length; i++) {
                Volt.log('[main-spotlight-view.js] updateProgressBar, group = ' + groupArr[i].group + ",index = " + groupArr[i].index);
                spotLightSelf.checkValid(groupArr[i].group, groupArr[i].index);
            }
        }
    },

    finishInstall : function(eventInfo) {
        if (spotLightSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-spotlight-view.js] finishInstall, ID = ' + eventInfo.app_id);
        var dataObj = checkingGroupAndIndex(spotLightSelf, eventInfo.app_id);
        if (dataObj) {
            var groupArr = dataObj.groupArr;
            for (var i = 0; i < groupArr.length; i++) {
                Volt.log('[main-spotlight-view.js] finishInstall, group = ' + groupArr[i].group + ",index = " + groupArr[i].index);
                spotLightSelf.checkValid(groupArr[i].group, groupArr[i].index);
            }
        }
    },

    checkValid : function(groupIndex, index) {
        Volt.log('[main-spotlight-view.js] checkValid');
        var group = -1;
        var trending_count = parseInt(SpotLightModel.get('trending_list_cnt'));
        var genre_count = parseInt(SpotLightModel.get('genre_games_list_cnt'));
        var friends_count = parseInt(SpotLightModel.get('friends_pick_list_cnt'));

        if (trending_count > 0 && spotLightSelf.contentWgt) {
            group++;
            if (groupIndex == group && index >= 0 && index < trending_count) {
                var itemCount = spotLightSelf.contentWgt.itemCount(groupIndex);
                if (index < itemCount) {
                    spotLightSelf.contentWgt.updateItem(group, index);
                }
            }
        }

        if (genre_count > 0 && spotLightSelf.contentWgt) {
            group++;
            if (groupIndex == group && index >= 0 && index < genre_count) {
                var itemCount = spotLightSelf.contentWgt.itemCount(groupIndex);
                if (index < itemCount) {
                    spotLightSelf.contentWgt.updateItem(group, index);
                }
            }
        }

        var signState = Utils.Account.getSignState();
        if (signState) {
            if (friends_count > 0 && spotLightSelf.contentWgt) {
                group++;
                if (groupIndex == group && index >= 0 && index < friends_count) {
                    var itemCount = spotLightSelf.contentWgt.itemCount(groupIndex);
                    if (index < itemCount) {
                        spotLightSelf.contentWgt.updateItem(group, index);
                    }
                }
            }
        }
    }
});

function checkingGroupAndIndex(self, app_id) {
    Volt.log('[main-spotlight-view.js] checkingGroupAndIndex');
    if (self.viewIsVisible == false) {
        return;
    }

    var group = -1;
    var index = -1;
    var obj = {};
    obj.groupArr = [];

    var trending_count = parseInt(SpotLightModel.get('trending_list_cnt'));
    var genre_count = parseInt(SpotLightModel.get('genre_games_list_cnt'));
    var friends_count = parseInt(SpotLightModel.get('friends_pick_list_cnt'));

    if (trending_count > 0 && self.contentWgt) {
        group++;
        for (var i = 0; i < trending_count; i++) {
            var data = self.contentWgt.getData(group, i);
            if (data.app_id == app_id) {
                index = i;
                obj.groupArr.push({
                    group : group,
                    index : index,
                });
                break;
            }
        }
    }

    if (genre_count > 0 && self.contentWgt) {
        group++;
        for (var i = 0; i < genre_count; i++) {
            var data = self.contentWgt.getData(group, i);
            if (data.app_id == app_id) {
                index = i;
                obj.groupArr.push({
                    group : group,
                    index : index,
                });
                break;
            }
        }
    }
    var signState = Utils.Account.getSignState();
    if (signState) {
        if (friends_count > 0 && self.contentWgt) {
            group++;
            for (var i = 0; i < friends_count; i++) {
                var data = self.contentWgt.getData(group, i);
                if (data.app_id == app_id) {
                    index = i;

                    obj.groupArr.push({
                        group : group,
                        index : index,
                    });

                    break;
                }
            }
        }
    }
    return obj;
};

exports = SpotLightView;
