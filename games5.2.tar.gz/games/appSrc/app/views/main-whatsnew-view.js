var PanelCommon       = Volt.requireNoContext('lib/panel-common.js');
var MainCategoryModel = Volt.requireNoContext("app/models/main-category-model.js");
var CommonContent     = Volt.requireNoContext('app/common/common-content.js');

var Backbone         = Volt.requireNoContext('lib/volt-backbone.js');
var Mediator         = Volt.requireNoContext('app/common/event-mediator.js');
var Gridlist         = Volt.requireNoContext('app/views/grid-list-view.js');
var GridlistTemplate = Volt.requireNoContext('app/templates/1080/grid-list-template.js');
var CommonDefine     = Volt.requireNoContext('app/common/common-define.js');
var WhatsNewModel    = Volt.requireNoContext("app/models/whats-new-model.js");
var NoContentView    = Volt.requireNoContext('app/views/no-content-view.js');
var VoiceGuide       = Volt.requireNoContext('app/common/voiceGuide.js');
var networkStatus = Volt.requireNoContext('app/common/network-state.js');

var realDataStateInWhatsnew = false;
var whatsNewSelf = null;

var WhatsNewView = PanelCommon.BaseView.extend({
    parent : null,
    contentWgt : null,
    viewIsVisible : false,
    bListenerStatus : false,
    viewType : 'whatsnew',

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    initialize : function() {
        whatsNewSelf = this;
    },

    render : function(parentWidget) {
        Volt.log('whats new view render');
        this.parent = parentWidget.widget.getChild('main-content-container');
        this.renderContent();

        return this;
    },

    renderContent : function() {
        realDataStateInWhatsnew = MainCategoryModel.isReady();
        var whatsnew_list = WhatsNewModel.get('whatsnew_list');

        if (!whatsnew_list || whatsnew_list.length == 0) {
            var noContentWgtId = this.viewType;

            if (networkStatus.getNetWorkState()) {
                var textToShow = Volt.i18n.t('COM_NO_CONTENT_FOUND');
                this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;
            } else {
                var textToShow = Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>', "400");
                this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_WITH_BTN).widget;
            }
        } else {
            this.contentWgt = this.initGrid(whatsnew_list);
            this.contentWgt.id = "WHATSNEW_CONTENT";
            this.contentWgt.focusable = true;
            this.contentWgt.show();
        }
        this.parent.addChild(this.contentWgt);
        this.setWidget(this.contentWgt);
        Volt.Nav.reload();
    },

    initGrid : function(dataList) {
        var whatsNewData = {
            style : CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME,
            groups : [{
                modelArr : dataList
            }]
        };
        var gridView = new Gridlist(GridlistTemplate.whatsNew, JSON.stringify(whatsNewData), parseInt(1920 * 0.16875), parseInt(1080 * 0.4));

        gridView.setItemData = function(mustache, modelData) {
            mustache.imgUrl = (modelData['thumbnail_url']) ? modelData['thumbnail_url'] : '';
            mustache.title = (modelData['game_title']) ? modelData['game_title'] : '';
            mustache.genre = (modelData['genre']) ? modelData['genre'] : '';
            mustache.app_id = (modelData['app_id']) ? modelData['app_id'] : '';
            mustache.rating = (modelData['rating']) ? modelData['rating'] : '';
            mustache.size = (modelData['size']) ? modelData['size'] : '';
            mustache.controller_list = (modelData['controller_list']) ? modelData['controller_list'] : '';
            mustache.downloadable = (modelData['downloadable']) ? modelData['downloadable'] : '';
            mustache.popup_flag = (modelData['popup_flag']) ? modelData['popup_flag'] : '';
            mustache.popup_text = (modelData['popup_text']) ? modelData['popup_text'] : '';
        };

        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
            CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
            CommonContent.addThumbnailListener(rendererInstance.thumbnail);
            CommonContent.setFoverFactor(rendererInstance.thumbnail, parentWidth);
            this.onItemUpdate(rendererInstance, data);
            this.onItemIconLoad(data, rendererInstance, 'NoIcon');
        };

        gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
            var Renderer = this.widget.renderer(groupIndex, itemIndex);
            var spValue = Volt.KPIMapper.getSelectPosition(itemIndex + 1);
            if (itemData.popup_flag == 'Y') {
                var ErrorHandling = Volt.requireNoContext('app/common/error-handling.js');
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_PSN, '', itemData.popup_text);
            } else {
                CommonContent.onLaunch('G04_WHATSNEW', itemData.app_id, Renderer.thumbnail, spValue);
                //CommonContent.onLaunch('', itemData.app_id);
            }
        };

        gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {
            //this.onTextScrollStart(parent);
        };

        gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {
            //this.onTextScrollEnd(parent);
        };

        gridView.itemLoaded = function(gridList, groupIndex, itemIndex) {
            var data = gridList.getData(groupIndex, itemIndex);
            data.group = groupIndex;
            data.item = itemIndex;
        };
        
        gridView.itemUnloaded = function(gridList, groupIndex, itemIndex) {
            
        };

        gridView.updateElements = function(parent, data) {
            Volt.log('[main-whatsnew-view.js] updateElements');
            this.onItemUpdate(parent, data);
            this.onItemIconLoad(data, parent, 'NoIcon');
        };

        gridView.resetElements = function(parent, data) {
            Volt.log('[main-whatsnew-view.js] resetElements');
            this.onItemIconReset(data);
        };

        gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
            Volt.log('[main-whatsnew-view.js] gridView.focusChanged .....');

            if (toItemIndex >= 0 && toGroupIndex >= 0) {
                var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
                Volt.pageItemIndex = toItemIndex + 1;
                var voiceText = '';
                if (-1 == fromItemIndex) {
                    voiceText += Volt.i18n.t('UID_PAN_GAMES') + ',' + Volt.i18n.t('TV_SID_MIX_CATEGORY_END').replace('<<A>>', Volt.i18n.t('TV_WHATS_NEW_KR_HOT')) + ',' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', WhatsNewModel.get('whatsnew_list_cnt')) + ',';
                }

                voiceText += data.title + '.';
                VoiceGuide.getVoiceGuide(voiceText);
            }
        };

        return gridView.render().widget;
    },

    remove : function() {
        if (this.contentWgt) {
            this.parent.removeChild(this.contentWgt);
            this.contentWgt.destroy();
            this.contentWgt = null;
        }
    },

    onFocus : function(widget) {
        Volt.log('[main-whatsnew-view.js] ContentView.onFocus');

        if (this.contentWgt) {
            widget = this.contentWgt;
            Volt.Nav.focus(this.contentWgt);
            widget.onFocus();
        }

        if (widget && widget.id) {
            Volt.log('[main-whatsnew-view.js] onFocus widget.id =' + widget.id);
            Backbone.history.setCache(widget.id);
        }
    },

    onBlur : function(widget) {
        if (widget) {
            Volt.log('[main-whatsnew-view.js] ContentView.onBlur');
            if (this.contentWgt) {
                this.contentWgt.onBlur();
            }
        }
    },

    show : function(param, animationType) {
        Volt.log('[main-whatsnew-view.js] show');

        Mediator.on(CommonDefine.Const.UPDATE_ITEMS, this.updateItems, this);
        Mediator.on(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, this.updateListenerFlag, this);
        Mediator.on(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
        this.addEventListener();
        if (this.contentWgt) {

            if (this.contentWgt.hasOwnProperty('focusable')) {
                this.contentWgt.focusable = true;
            }
            if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'WHATSNEW_CONTENT') {
                this.contentWgt.showWithAnimation();
            } else {
                this.contentWgt.show();
            }
            this.updateItems();
        }

        this.viewIsVisible = true;
        Volt.Nav.reload();

        Volt.log('[main-whatsnew-view.js] show ready = ' + MainCategoryModel.isReady());
        var categoryState = MainCategoryModel.isReady();
        if (categoryState && (categoryState != realDataStateInWhatsnew)) {
            this.updateContent();
        }
    },

    hide : function(animationType) {
        this.viewIsVisible = false;
        this.removeEventListener();
        Mediator.off(CommonDefine.Const.UPDATE_ITEMS, null, this);
        Mediator.off(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, null, this);
        Mediator.off(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
        if (this.contentWgt) {
            if (this.contentWgt.hasOwnProperty('focusable')) {
                this.contentWgt.focusable = false;
            }
            if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'WHATSNEW_CONTENT') {
                this.contentWgt.hideWithAnimation();
            } else {
                this.contentWgt.hide();
            }
        }
    },

    updateContent : function() {
        Volt.log('[main-whatsnew-view.js] update content');
        realDataStateInWhatsnew = MainCategoryModel.isReady();
        if (this.contentWgt) {
            if (this.contentWgt.id != "WHATSNEW_CONTENT") {
                if (realDataStateInWhatsnew) {
                    this.remove();
                    this.renderContent();
                }
                return;
            }

            var whatsnew_list = WhatsNewModel.get('whatsnew_list');
            CommonContent.updateData(whatsnew_list, 0, this.contentWgt);
            this.updateItems();
        } else {
            this.renderContent();
        }
    },

    addEventListener : function() {
        Volt.log('[main-whatsnew-view.js] addEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == false) {
            Mediator.on(CommonDefine.Event.BEGIN_DOWNLOAD, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_CANCELED, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
            this.bListenerStatus = true;
        }
    },

    removeEventListener : function() {
        Volt.log('[main-whatsnew-view.js] removeEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == true) {
            Mediator.off(CommonDefine.Event.DOWNLOAD_PROGRESS, null, this);
            Mediator.off(CommonDefine.Event.INSTALL, null, this);
            Mediator.off(CommonDefine.Event.BEGIN_DOWNLOAD, null, this);
            Mediator.off(CommonDefine.Event.DOWNLOAD_CANCELED, null, this);
            this.bListenerStatus = false;
        }
    },

    updateListenerFlag : function(flag) {
        Volt.log('[main-whatsnew-view.js] updateListenerFlag,flag = ' + flag);
        if (flag == true) {
            this.addEventListener();
            this.updateItems();
        } else {
            this.removeEventListener();
        }
        this.bListenerStatus = flag;
    },

    updateItems : function() {
        Volt.log("[main-whatsnew-view.js] updateAllItems~~");
        var gridCount = WhatsNewModel.get('whatsnew_list_cnt');
        if (this.contentWgt && this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'WHATSNEW_CONTENT' && (gridCount > 0)) {
            this.contentWgt.updateAllItems && this.contentWgt.updateAllItems(0);
        }
    },

    getWidget : function() {
        return this.contentWgt;
    },

    updateProgressBar : function(eventInfo) {
        if (whatsNewSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-whatsnew-view.js] updateProgressBar, ID = ' + eventInfo.app_id);
        var index;
        for ( index = 0; index < WhatsNewModel.get('whatsnew_list_cnt'); index++) {
            if (whatsNewSelf.contentWgt) {
                var data = whatsNewSelf.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
            }
        }
        Volt.log('[main-whatsnew-view.js] index = ' + index + ', whatsnew_list_cnt = ' + WhatsNewModel.get('whatsnew_list_cnt'));
        //update install icon
        //update progress bar
        if (index < WhatsNewModel.get('whatsnew_list_cnt') && whatsNewSelf.contentWgt) {
            var itemCount = whatsNewSelf.contentWgt.itemCount(0);
            if (index < itemCount) {
                whatsNewSelf.contentWgt.updateItem(0, index);
            }
        }
    },

    finishInstall : function(eventInfo) {
        if (whatsNewSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-whatsnew-view.js] finishInstall, ID = ' + eventInfo.app_id);
        var index;
        for ( index = 0; index < WhatsNewModel.get('whatsnew_list_cnt'); index++) {
            if (whatsNewSelf.contentWgt) {
                var data = whatsNewSelf.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
            }
        }
        Volt.log('[main-whatsnew-view.js] index = ' + index + ', whatsnew_list_cnt = ' + WhatsNewModel.get('whatsnew_list_cnt'));
        //update install icon
        //update progress bar
        if (index < WhatsNewModel.get('whatsnew_list_cnt') && whatsNewSelf.contentWgt) {
            var itemCount = whatsNewSelf.contentWgt.itemCount(0);
            if (index < itemCount) {
                whatsNewSelf.contentWgt.updateItem(0, index);
            }
        }
    },
});

exports = WhatsNewView;
