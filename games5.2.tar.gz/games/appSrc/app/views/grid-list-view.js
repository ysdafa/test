var _                 = Volt.requireNoContext("modules/underscore.js")._;
var Backbone          = Volt.requireNoContext('lib/volt-backbone.js');
var PanelCommon       = Volt.requireNoContext('lib/panel-common.js');
var GridlistTemplate  = Volt.requireNoContext('app/templates/1080/grid-list-template.js');
var CommonContent     = Volt.requireNoContext('app/common/common-content.js');
var GamesMainTemplate = Volt.requireNoContext("app/templates/1080/main-template.js");
var CommonDefine      = Volt.requireNoContext('app/common/common-define.js');
var voltApiWrapper    = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var DeviceModel       = Volt.requireNoContext('app/models/device-model.js');
var Mediator       = Volt.requireNoContext('app/common/event-mediator.js');
var networkStatus = Volt.requireNoContext('app/common/network-state.js');
var thumbnailStyleIndex = 0;
 
var GridlistView = PanelCommon.BaseView.extend({
	param : null,
	groupCnt : 0,
	groupsData : null,
	style : 0,
	rowNum : 0,
	minWidth : 0,
	minHeight : 0,
    downloadProcessbar : [],
	itemDimWidget : [],
    itemIcon : [],
    itemUSBIcon: [],
    longPressNeedful : true,
    scrollNeedful : true,
    leftCnt : 0,
    groupTitle : [],
    bGroupCreated : [],
    groupWidth : [],

	initialize : function(param, JSONObj, minColumnWidth, minRowHeight) {
        this.itemWidgets= new Array();
		var tmpData     = JSON.parse(JSONObj);
		this.param      = param;
		this.style      = tmpData.style;
		this.groupsData = tmpData.groups;
        
		for (var i = 0; i < this.groupsData.length; ++i) {
			Volt.log("[grid-list-view.js] groups : "+this.groupsData.length);
			Volt.log("[grid-list-view.js]  modelArr.length ="+ this.groupsData[i].modelArr.length);
			if (this.groupsData[i].modelArr.length > 0) {
				this.groupCnt++;
			}
			Volt.log("[grid-list-view.js] myPage leftItemCnt : "+ this.groupsData[i].leftItemCnt);
			if(this.groupsData[i].leftItemCnt && this.groupsData[i].modelArr.length == 0){
			    this.groupCnt ++;
			}
			
			if(this.groupsData[i].leftItemCnt){
			    this.leftCnt = this.groupsData[i].leftItemCnt;
			}
		}
        
		Volt.log("[grid-list-view.js] leftCnt = "+this.leftCnt);
		Volt.log("[grid-list-view.js] this groupCnt = "+this.groupCnt);
		this.minWidth  = minColumnWidth;
		this.minHeight = minRowHeight;

		if (param.height && minRowHeight) {
			this.rowNum = Math.floor(param.height / minRowHeight);
		}

		this.setOpenAPI();
	}, 

    setOpenAPI : function(){
		Volt.log('[grid-list-view.js]setOpenAPI');
		this.setItemTemplate      = function(parent, parentWidth, parentHeight, data) { };
		this.setItemData          = function(mustache, modelData) {};
		this.onColorPick          = function(widget) {};
		this.onItemPress          = function(itemData,groupIndex, itemIndex) {};
		this.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {};
		this.toFocusChangeEnd     = function(parent, parentWidth, parentHeight, data) {};
		this.itemLoaded           = function(gridList, groupIndex, itemIndex) {};
		this.itemUnloaded         = function(gridList, groupIndex, itemIndex) {};
		this.updateElements       = function(parent, data) {};
		this.resetElements        = function(parent, data) {};
		this.moveOut              = function(gridList, directionString, fromGroupIndex, fromItemIndex){};
		this.focusChanged         = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex){};
		this.disableLongPress     = function(){this.longPressNeedful = false;};
		this.disableScroll        = function(){this.scrollNeedful = false;};
		
		this.initGrid             = _.bind(_initGrid, this);
		this.renderGrid           = _.bind(_renderGrid, this);
		this.renderGridGroup      = _.bind(_renderGridGroup, this);
		this.renderGroupTitle     = _.bind(_renderGroupTitle, this);
		this.assignGroupData      = _.bind(_assignGridData, this);
	},	
	
    render : function() {
        this.downloadProcessbar     = [];
        this.itemDimWidget          = [];
        this.itemIcon               = [];
        this.itemUSBIcon            = [];
        var gridlist                = this.initGrid();
        gridlist.longPressAvailable = this.longPressNeedful;
        gridlist.onKeyEvent         = _.bind(this.onKeyEvent, this);
        gridlist.onFocus            = _.bind(this.onFocus, this);
        gridlist.onBlur             = _.bind(this.onBlur, this);
        gridlist.onItemPress        = _.bind(this.onItemPress, this);
        gridlist.itemLoaded         = _.bind(this.itemLoaded, this);
        gridlist.itemUnloaded       = _.bind(this.itemUnloaded, this);
        gridlist.moveOut            = _.bind(this.moveOut,this);
		gridlist.focusChanged       = _.bind(this.focusChanged,this);
		gridlist.getRealIndexInScreenRange = _.bind(this.getRealIndexInScreenRange,this);
		gridlist.getRealItemInScreenRange  = _.bind(this.getRealItemInScreenRange,this);
		gridlist.leftCnt            = this.leftCnt;
		Volt.log("[grid-list-view.js]gridlist.leftCnt =" + gridlist.leftCnt);
        this.setWidget(gridlist);
        this.renderGrid();
        return this;
    },
	
	show : function() {
		Volt.log("[grid-list-view.js]gridlist  show");
		this.widget.show();
	},
    
	hide : function() {
		Volt.log("[grid-list-view.js]gridlist  hide");
		if(this.widget){
		    this.widget.hide();
		}
		this.leftCnt = 0;
	},
    
	onFocus : function(showFocus) {
		Volt.log("[grid-list-view.js]gridlist  focus");
		this.widget.shadowEffectFlag = false; //disable shadow effect of focused item
		if(!(this.widget.hasOwnProperty('id') && 'GameControllerGuide' == this.widget.id)){
            var offset = (scene.height == 1080) ? -5 : -8;
            Volt.log('grid offset::::'+offset);
			this.widget.setFocusImage(Volt.getRemoteUrl("images/" + scene.height + "/highlight/ksc_focus.png"), offset, offset);
		}
		
		this.widget.enableFocus();
		this.widget.setFocus();
		if(showFocus == false) {
		    this.widget.showFocus("false");
		} else {
		    this.widget.showFocus("true");
		}
	},
    
	onBlur : function() {
		Volt.log("[grid-list-view.js] gridlist  blur");
		this.widget.hideFocus("true");
	},

	onKeyEvent : function(keycode, keytype) {
		Volt.log("[grid-list-view.js] gridlist  onkeyEvent");
        if(keytype == Volt.EVENT_KEY_PRESS){
            this.widget.event = true;
        }
        
		if (keytype == Volt.EVENT_KEY_RELEASE) {
            if(this.widget.event == false){
                return;
            }
            else{
                this.widget.event = false;
            }            
        
			if (keycode == Volt.KEY_JOYSTICK_OK) {
				var focusItem = this.widget.getFocusItemIndex();
				var index = focusItem.itemIndex;
				var groupIndex = focusItem.groupIndex;
				var data = this.widget.allGroupDataArr[groupIndex][index];

				if (this.widget.longpress == false) {
					this.onItemPress(data,groupIndex, index);
				}else{
					Volt.log("[grid-list-view.js] =====================longpress");
					Mediator.trigger(CommonDefine.Event.GRID_LONG_PRESS);
					this.widget.longpress = false;
				} 
			}
			return;
		}
		switch(keycode) {
			case Volt.KEY_JOYSTICK_UP:
				return this.widget.moveFocus("Up");
				break;
			case Volt.KEY_JOYSTICK_DOWN:
				return this.widget.moveFocus("Down");
				break;
			case Volt.KEY_JOYSTICK_LEFT:
				return this.widget.moveFocus("Left");
				break;
			case Volt.KEY_JOYSTICK_RIGHT:
				return this.widget.moveFocus("Right");
				break;
			default:
				return false;
				break;
		}
	},
    
    addItemWidget : function(wz, data){
        Volt.log('[grid-list-view.js]addItemWidget : groupIndex - ' + data.groupIndex + ' itemIndex - ' + data.itemIndex);
        if(!this.itemWidgets[data.groupIndex]){
            this.itemWidgets[data.groupIndex] = [];
        }

        this.itemWidgets[data.groupIndex][data.itemIndex] = wz;
    },
    
    getFocusedWidget: function() {
    	Volt.log('[grid-list-view.js] getFocusedWidget.....');
        var focusItem  = this.widget.getFocusItemIndex();
        var itemIndex  = focusItem.itemIndex;
        var groupIndex = focusItem.groupIndex;

        if(this.itemWidgets[groupIndex] && this.itemWidgets[groupIndex][itemIndex]){
            var wz = this.itemWidgets[groupIndex][itemIndex];
            return wz;
        }
    },
    
    getRealIndexInScreenRange : function(groupIndex, itemIndex){
        var screenRange = this.widget.getOnScreenRange();
        Volt.log('[grid-list-view.js] countRealIndexInScreenRange screenRange = ' + JSON.stringify(screenRange));
        var beginIndex = screenRange.startGroupIndex + screenRange.startItemIndex;
        var realIndex = 0;
        var tempCount;
        for(var i = screenRange.startGroupIndex; i < groupIndex; i++){
            tempCount = this.widget.itemCount(i);
            realIndex += tempCount;
        }
        realIndex += (itemIndex - beginIndex);
        Volt.log('[grid-list-view.js] countRealIndexInScreenRange realIndex = ' + realIndex);
        return realIndex;
    },
    
    getRealItemInScreenRange : function(realIndex){
        var screenRange = this.widget.getOnScreenRange();
        var realItem = {};
        Volt.log('[grid-list-view.js] countRealItemInScreenRange screenRange = ' + JSON.stringify(screenRange));
        var exceedCount = realIndex - (this.widget.itemCount(screenRange.startGroupIndex) - screenRange.startItemIndex);
        if(exceedCount < 0) {
            realItem.groupIndex = screenRange.startGroupIndex;
            realItem.itemIndex = screenRange.startItemIndex + realIndex;
        } else {
            var tempCount;
            for(var i = screenRange.startGroupIndex + 1; i <= screenRange.endGroupIndex; i++){
                if(i == screenRange.endGroupIndex) {
                    tempCount = screenRange.endItemIndex;
                } else {
                    tempCount = this.widget.itemCount(i);
                }
                exceedCount -= tempCount;
                if(exceedCount < 0) {
                    realItem.groupIndex = i;
                    realItem.itemIndex = exceedCount + tempCount;
                    break;
                }
            }
            if(exceedCount >= 0) {//when realIndex is exceed the screenRange, return the last item in screenRange
                realItem.groupIndex = screenRange.endGroupIndex;
                realItem.itemIndex = screenRange.endItemIndex;
            }
        }
        Volt.log('[grid-list-view.js] countRealItemInScreenRange realItem = ' + JSON.stringify(realItem));
        return realItem;
    },
    
    addItem: function(groupIdx, model) {
        Volt.log("[grid-list-view.js] gridlist  addItem");

        var data = new Data();
        data._index = this.itemWidgets[groupIdx].length;
        data.groupIndex = groupIdx;
        data.itemIndex  = this.itemWidgets[groupIdx].length;
        this.setItemData(data, model);
        this.widget.insertData({
            groupIndex : groupIdx,
            itemIndex : data.itemIndex,
            data : data
        });
        this.widget.allGroupDataArr[groupIdx].push(data);
        this.widget.loadData();
    },

    removeItem: function(groupIdx, fromItemIndex, toItemIndex) {
        Volt.log("[grid-list-view.js] gridlist  removeItem");

        this.widget.removeData({
            groupIdx : groupIdx,
            fromItemIndex : fromItemIndex,
            toItemIndex : toItemIndex
        });
        this.widget.allGroupDataArr[groupIdx].splice(this.widget.allGroupDataArr[groupIdx].indexOf(data), 1);
        this.widget.loadData();
    },
    
    onItemIconLoad :function(data, parent, option){
        this.itemIcon[data.item] = CommonContent.updateItemIcon(data.app_id, parent.thumbnail, option, this.itemIcon[data.item]);
        
        //update install Icon
        if (option === 'NoIcon') {
        } else {
            this.itemUSBIcon[data.item] = CommonContent.updateItemUSBIcon(
                                                data.app_id, 
                                                parent.thumbnail, 
                                                option, 
                                                this.itemUSBIcon[data.item], 
                                                this.itemIcon[data.item] ? "icon2" : "icon1");
        }
        
        //this.downloadProcessbar[data.item] = CommonContent.updateItemProgress(data.app_id, parent.thumbnail, option,this.downloadProcessbar[data.item]);
         CommonContent.updateItemProgress(data.app_id, parent.thumbnail, option);
    },

    onItemIconReset: function(data){
        this.itemIcon[data.item] = null;
        this.itemUSBIcon[data.item] = null;
        //install progress bar
        this.downloadProcessbar[data.item] = null;
        this.itemDimWidget[data.item] = null;
    },
    
    //update items for main-view
    onItemUpdate: function(parent, data, option) {
        Volt.log("[grid-list-view.js] gridlist  onItemUpdate data.rating = " + data.rating);
        Volt.log("[grid-list-view.js] gridlist  onItemUpdate option = " + option);
        var thumbnailObj = parent.thumbnail;
        if(data.imgUrl){
            Volt.log("[grid-list-view.js] gridlist  onItemUpdate networkStatus = " + networkStatus.getNetWorkState());
            if(!networkStatus.getNetWorkState()){
                //thumbnailObj.setContentImage(Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'));
            }else {
                thumbnailObj.setContentImage(data.imgUrl);
            }
        }
        
        if (thumbnailObj.visibleStyles() & CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO) {
            if(data.title)  thumbnailObj.setInformationText("text1", data.title);
            if(data.genre) thumbnailObj.setInformationText("text2", data.genre);
            if(data.rating){
				var ratingNum = parseInt(data.rating) * 2;
				var tempIndex = String(data.rating).indexOf(".");
				if(tempIndex != -1 && String(data.rating).substring(tempIndex + 1) > 0){
	                ratingNum += 1;
				}
				//Notice: The rating value range is 0 ~ 10.
				if(ratingNum < 0){
					ratingNum = 0;
				}else if(ratingNum > 10){
					ratingNum = 10;
				}
			
				thumbnailObj.setInformationRatingValue(ratingNum);
            } else {
                thumbnailObj.visualizeInformationRating(false);
            }
        }
        if(option == "mypage"){
            thumbnailObj.visualizeThumbnailStyle(false, CommonDefine.ThumbnailStyle.THUMB_STYLE_PROGRESSBAR | CommonDefine.ThumbnailStyle.THUMB_STYLE_CHECKBOX);
        }
    },

});

var itemLoaded = function(gridList, groupIndex, itemIndex) {
	Volt.log("[grid-list-view.js] gridlist  itemloaded");
	gridList.itemLoaded(gridList, groupIndex, itemIndex);
};

var itemUnloaded = function(gridList, groupIndex, itemIndex) {
	Volt.log("[grid-list-view.js] gridlist  itemUnloaded");
	gridList.itemUnloaded(gridList, groupIndex, itemIndex);
};

var asyncItemLoad = function(gridList, groupIndex, itemIndex) {
	Volt.log("[grid-list-view.js] gridlist  async");
};

var focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
	Volt.log("[grid-list-view.js] gridlist  focusChange fromItemIndex = " + fromItemIndex + ',,,toItemIndex = ' + toItemIndex);
	Volt.log("[grid-list-view.js] gridlist  focusChange groupCnt = " + gridList.groupCnt);
	if(toGroupIndex >= gridList.groupCnt){
	    toGroupIndex = gridList.groupCnt-1;
	    toItemIndex = 0;
	}
	gridList.focusChanged(gridList, fromGroupIndex, fromItemIndex, toGroupIndex,toItemIndex);
	if(fromItemIndex >= 0 && fromGroupIndex >= 0){
        var data = gridList.getData(fromGroupIndex, fromItemIndex);
        if(data && data.controller_list) {
            var renderFrom = gridList.renderer(fromGroupIndex, fromItemIndex);
            if(renderFrom && renderFrom.thumbnail) {
                CommonContent.hideRollOver(renderFrom.thumbnail);
            }
        }
    }
    if(toItemIndex >= 0 && toGroupIndex >= 0){
        var data = gridList.getData(toGroupIndex, toItemIndex);
        if(data && data.controller_list) {
            var render = gridList.renderer(toGroupIndex, toItemIndex);
            if(render && render.thumbnail) {
                CommonContent.showRollOver(render.thumbnail, data.controller_list);
            }
        }
    }
};

var focusChangeStart = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
	Volt.log("[grid-list-view.js] gridlist  focuschangestart");
};

var moveOut = function(gridList, directionString, fromGroupIndex, fromItemIndex) {
	Volt.log("[grid-list-view.js] gridlist  moveOut  " + directionString);
	/*
	if ("Up" == directionString) {
	} else if ("Down" == directionString) {
	} else if ("Left" == directionString) {
	} else if ("Right" == directionString) {
	}
	*/
	gridList.moveOut(gridList, directionString, fromGroupIndex, fromItemIndex);
};

var itemIndexChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
	Volt.log("[grid-list-view.js] gridlist  directionString  " + directionString);
};

var itemClicked = function(gridList, groupIndex, itemIndex) {
	Volt.log("[grid-list-view.js]itemClick");
	var data = gridList.allGroupDataArr[groupIndex][itemIndex];
	gridList.onItemPress(data, groupIndex, itemIndex);

};

var enterKeyLongPressed = function(gridList, groupIndex, itemIndex,type) {
	Volt.log("[grid-list-view.js] on long press");
	Volt.log("[grid-list-view.js] on long press gridList.leftCnt = "+ gridList.leftCnt);
	Volt.log("[grid-list-view.js] on long press itemIndex = "+ itemIndex);
	gridList.longpress = true;
	
	if(gridList.leftCnt > 0){
        if(itemIndex < gridList.leftCnt){
            gridList.longPressAvailable = false;
        } else {
            gridList.longPressAvailable = true;
        }
    }
	
	if(gridList.longPressAvailable == false){
		return;
	}
	var data = this.widget.allGroupDataArr[groupIndex][itemIndex];
	var Renderer = this.widget.renderer(groupIndex, itemIndex);
	var MultiSelection = Volt.requireNoContext('app/views/multi-selection.js');
	var status = MultiSelection.getState();
	Volt.log('multi selection status :::::'+status);
	if(status == ''){
		CommonContent.onLongPress(this.widget, data, itemIndex, Renderer.root, Renderer.thumbnail);
		if(type == 'mouse'){
			Volt.log("[grid-list-view.js]================ long press with mouse");
			Mediator.trigger(CommonDefine.Event.GRID_LONG_PRESS);
			gridList.longpress = false;
		}
	}
};

var getRenderer = function(parentWidth, parentHeight, data) {
    Volt.log("[grid-list-view.js] getRenderer");
    Volt.log("[grid-list-view.js] getRenderer parentWidth = " + parentWidth + ",parentHeight =" + parentHeight);
    var self = this;
    var renderer = new Renderer(parentWidth, parentHeight);
    renderer.root = new WidgetEx({
        x : 0,
        y : 0,
        width : parentWidth,
        height : parentHeight,
        parent : scene
    });
    renderer.root.show();
    
    var viewType = CommonContent.getViewType();
    Volt.log("[grid-list-view.js] getRenderer viewType =" + viewType);
    switch(viewType) {
        case "#My Page":
//        case "#Most Popular":
            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_ODD;
            break;
        case "#detail":
            if(data.screenshot){
                thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.DETAIL_SCREEN_SHOT;
            } else if(data.bigThumbnail){
                thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.DETAIL_BIG_THUMBNAIL;
            } else {
                thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.DETAIL_RELATED;
            }
            break;
		case "game-controller":
		    thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.GAME_CONTROLLER_GUIDE;
        	break;
        case "#coupon":
            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.COUPON_BOX_VIEW;
            break;
        case "#message":
            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MESSAGE_BOX_VIEW;
            break;
        default:
            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.THUMBNAIL2;
            break;
    }
    
    var popupType = CommonContent.getMsgPopupType();
    Volt.log("[grid-list-view.js] getRenderer popupType =" + popupType);
    if(popupType && "select-games" == popupType){
        thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.THUMBNAIL_SELECT_GAMES;
    }
    
    Volt.log("[grid-list-view.js] thumbnailStyleIndex = " + thumbnailStyleIndex);

    if (CommonDefine.GridListThumbnailStyle.GAME_CONTROLLER_GUIDE == thumbnailStyleIndex) {
        Volt.log("[grid-list-view.js] game-controller-guide ");
    } else {
        Volt.log("[grid-list-view.js] main sub-view or coupon box view ");
        if(!networkStatus.getNetWorkState()){
            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.THUMBNAIL2_NO_NETWORK;
        }
        
        if(data.leftItemCnt){
            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_LEFT_COUPON;
            Volt.log("[grid-list-view.js] data.hasMsg ="+ data.hasMsg);
            if(data.hasMsg){
                thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_LEFT_MESSAGE;
            }
            if(data.isProfileItem) {
                thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_PROFILE;
            }
        }
        
        if(CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_ODD == thumbnailStyleIndex){
            Volt.log("[grid-list-view.js] self.leftCnt ="+ self.leftCnt);
            if (data.columnIndex % 2 == 0) {
                switch(data.rowIndex){
                    case 1:
                        if(self.leftCnt > 1){
                            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_EVEV;
                        }
                        break;
                    case 2:
                        if(self.leftCnt == 1){
                            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_EVEV;
                        }
                        break;
                    default:
                        break;
                }
            } else {
                switch(data.rowIndex){
                    case 1:
                        if(self.leftCnt == 1){
                            if(data.columnIndex != 1){
                                thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_EVEV;
                            }
                        }
                        break;
                    case 2:
                        if(self.leftCnt > 1){
                            thumbnailStyleIndex = CommonDefine.GridListThumbnailStyle.MYPAGE_THUMBNAIL_EVEV;
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        
        var ThumbnailClass = Volt.requireNoContext('app/common/thumbnail_wrapper.js');
        renderer.customThumbnail = new ThumbnailClass(renderer.root, parentWidth, parentHeight, data.itemIndex, thumbnailStyleIndex);
        renderer.thumbnail = renderer.customThumbnail.prototype;
    }

    renderer.onDraw = function(rendererInstance, drawTypeString, data, parentWidth, parentHeight) {
        Volt.log("[grid-list-view.js] onDraw thumbnailStyleIndex = " + thumbnailStyleIndex);
        if (!data) {
            Volt.log("[grid-list-view.js] onDraw data ~~~~~~~~~");
            return;
        }

        if ("LoadData" == drawTypeString) {
            Volt.log("[grid-list-view.js] onDraw ~~~~~~~~~ LoadData ....");
            //self.setItemTemplate(rendererInstance.root, parentWidth, parentHeight, data);
            //self.addItemWidget(rendererInstance.root, data);
            if (CommonDefine.GridListThumbnailStyle.GAME_CONTROLLER_GUIDE == thumbnailStyleIndex) {
                Volt.log("[grid-list-view.js] onDraw ~~~~~~~~~ LoadData #coupon // game-controller");
                self.setItemTemplate(rendererInstance.root, parentWidth, parentHeight, data);
                self.addItemWidget(rendererInstance.root, data);
            } else {
                Volt.log("[grid-list-view.js] onDraw ~~~~~~~~~ LoadData sub-view //#coupon");
                self.setItemTemplate(rendererInstance, parentWidth, parentHeight, data);
            }
        } else if ("UnloadData" == drawTypeString) {
            Volt.log("[grid-list-view.js] UnloadData");
            if (CommonDefine.GridListThumbnailStyle.GAME_CONTROLLER_GUIDE == thumbnailStyleIndex) {
                self.resetElements(rendererInstance.root, data);
            } else {
                self.resetElements(rendererInstance.thumbnail, data);
            }
        } else if ("UpdateData" == drawTypeString) {
            Volt.log("[grid-list-view.js] UpdateData");
            /*if (CommonDefine.GridListThumbnailStyle.GAME_CONTROLLER_GUIDE == thumbnailStyleIndex) {
                self.updateElements(rendererInstance.root, data);
            } else {*/
                self.updateElements(rendererInstance, data);
            //}

            /*
             //Update items
             var parent = rendererInstance.root;
             var imgWgt = parent.getChild(1);
             if (imgWgt.imgFlag === false) {
             Volt.log("Update data Draw!");
             self.setItemTemplate(rendererInstance.root, parentWidth, parentHeight, data);
             }
             */
        } else if ("FromItemFocusChangeAniStart" == drawTypeString) {
            //The from item of focus change motion start
            self.fromFocusChangeStart(rendererInstance.root, parentWidth, parentHeight, data);
            Volt.log('*************************FromItemFocusChangeAniStart**************************************', data.title);
        } else if ("ToItemFocusChangeAniEnd" == drawTypeString) {
            //The to item of focus change motion start
            self.toFocusChangeEnd(rendererInstance.root, parentWidth, parentHeight, data);
            Volt.log('*************************ToItemFocusChangeAniEnd**************************************', data.title);
        }
    };

    renderer.onResize = function(data, destWidth, destHeight, flagWithAni, duration) {
        Volt.log("[grid-list-view.js] onResize");
        if ("withAni" == flagWithAni) {
        } else if ("noAni" == flagWithAni) {
        }

    };
	
	renderer.onTransformStyle = function (rendererInstance, data, fromStyle, toStyle, parentWidth, parentHeight, flagWithAni, duration) {
	    Volt.log("[grid-list-view.js] onTransformStyle");
        rendererInstance.customThumbnail.setStyle(toStyle, parentWidth, parentHeight, flagWithAni);
    };

    renderer.onUpdate = function(width, height) {

    };

    renderer.onRelease = function() {
        renderer.root.destroy();
        if (renderer.thumbnail) {
            renderer.thumbnail.destroy();
        }
        delete renderer;
    };

    return renderer;
};

var _initScrollBar = function(width, height){
	Volt.log("[grid-list-view.js] _initScrollBar ==========");
    var params = {
    	style : CommonDefine.Winset.SCROLL_HORIZONTAL,
        parent : scene,
        x : 0,
        y : height - Math.floor(1080 * 0.021296),
        width : width,
        height : 1080 * 0.004630,
        maxValue : 100,
    };
        
    var scroll = CommonContent.createScroll(params);
    scroll.show();
    return scroll;
};

var _initGrid = function() {
	var rendererProvider = new RendererProvider;
	rendererProvider.funcGetRenderer = _.bind(getRenderer, this);

	var gridListener = new GridListControlListener;
	gridListener.onItemLoaded = itemLoaded;
	gridListener.onItemUnloaded = itemUnloaded;
	gridListener.onAsyncItemLoad = asyncItemLoad;
	gridListener.onFocusChanged = focusChanged;
	gridListener.onFocusChangeStart = focusChangeStart;
	gridListener.onMoveOut = moveOut;
	gridListener.onItemIndexChanged = itemIndexChanged;
	gridListener.onItemClicked = itemClicked;
	gridListener.onEnterKeyLongPressed = _.bind(enterKeyLongPressed, this);

	var gridlist = new GridListControl(this.param);
	gridlist.setRendererProvider(rendererProvider);
	gridlist.addListListener(gridListener);
	gridlist.addGroup(this.groupCnt);
	gridlist.addDataGroup(this.groupCnt);
	gridlist.enlargeFocusItem(20, 20);
	//gridlist.enlargeFocusItem(80, 80);
	//gridlist.setAnimationDuration(100);
	gridlist.setAnimationDuration(330);
	gridlist.addStyle(1);
	//gridlist.addStyle(3);
	gridlist.setStyle(0);
	gridlist.allGroupDataArr = [];
	gridlist.longpress = false;
	gridlist.groupCnt = this.groupCnt;
	gridlist.setBufferColumnSize({ left: 4, right: 4 });
	gridlist.setThumbnailDefaultImage(Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'));
	//gridlist.useMarginWhenFocusEdgeItem = false;
//	gridlist.rolloverEffect = true;
    gridlist.canLoopWhenContinuosKey = false;
    
    Volt.log("[grid-list-view.js] _initGrid this.leftCnt ="+ this.leftCnt);
    if(this.leftCnt > 0){
        gridlist.autoHighContrast = false;
    }
	
    if(this.scrollNeedful) {
        var scroll = _initScrollBar(this.param.width, this.param.height);
        gridlist.attachScrollBar(scroll);
    }
	return gridlist;
};

var _renderGrid = function() {
	Volt.log("[grid-list-view.js] _renderGrid");
	
	var groupIndex = 0;
    var i = 0;

    while(i < this.groupsData.length) {
        var group = this.groupsData[i];

        if(group.leftItemCnt){ //my page
            _renderGridMypage(this);
            break;
        }

        if (group.modelArr.length <= 0) {
            i++;
            continue;
        }

        //this.renderGridGroup(i, group.modelArr.length);
        this.renderGridGroup(groupIndex, group);
        this.assignGroupData(groupIndex, group.modelArr);
        groupIndex++;
        i++;
    }

	this.widget.loadData();
};

var _renderGridMypage = function(self){
    Volt.log("[grid-list-view.js] _renderGridMypage");
    for (var i = 0; i < self.groupsData.length; ++i) {
        group = self.groupsData[i];
        var itemCnt = 0;
        
        if(group.modelArr.length > 0){
            itemCnt = group.leftItemCnt + group.modelArr.length;
        } else {
            itemCnt = group.leftItemCnt + 1;
        }
        
        Volt.log("[grid-list-view.js] _renderGridMypage itemCnt = " + itemCnt);
        
        self.renderGridGroup(i, itemCnt, group);
        self.assignGroupData(i, group.modelArr, group);
    }
};

var _renderGridGroup = function(groupIdx, groupData,mypageGroupData) {
	Volt.log("[grid-list-view.js] renderGridGroup");
	var modelsCnt = 0;
	if(groupData.modelArr){
	    modelsCnt = groupData.modelArr.length;
	} else {
	    modelsCnt = groupData;
	}
	
	if(mypageGroupData)  Volt.log("[grid-list-view.js] renderGridGroup mypageGroupData = " + mypageGroupData);
	
    var colNum = 0;
    var width = 0;
    var height = 0;
    var usedHeight = 0;
    var groupWidth = 0;
    
    if (this.style == CommonDefine.Const.HALO_ITEM_ALL_SAME) {
        //all items are the same
        colNum = Math.ceil(modelsCnt / this.rowNum);
    } else if (this.style == CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME) {
        //items are not all same
        if(mypageGroupData && mypageGroupData.modelArr.length <= 0){
            colNum = 2;
        } else {
            colNum = Math.ceil((modelsCnt + 1) / this.rowNum);
        }
        
       //colNum = Math.ceil((modelsCnt + 1) / this.rowNum);
    } else {
        return;
    }
    Volt.log("[grid-list-view.js] renderGridGroup colNum = "+ colNum);
    
    if (mypageGroupData) {
        renderGridGroupMypage(this,groupIdx, colNum, mypageGroupData);
    } else {
        for (var i = 0; i < colNum; ++i) {
            usedHeight = 0;
            if (i == 0) {
                if (this.style == CommonDefine.Const.HALO_ITEM_ALL_SAME) {
                    width = this.minWidth;
                    height = this.minHeight;
                } else {
                    width = 2 * this.minWidth;
                    height = 2 * this.minHeight;
                }
            } else {
                width = this.minWidth;
                height = this.minHeight;
            }
            this.widget.addColumn({
                groupIndex : groupIdx,
                styleIndex : 0,
                columnWidth : width
            });
            groupWidth += width;

            for (var j = 0; j < this.rowNum; ++j) {
                usedHeight += height;
                if (usedHeight <= this.param.height) {
                    this.widget.addRowToColumn({
                        groupIndex : groupIdx,
                        styleIndex : 0,
                        columnIndex : i,
                        rowHeight : height
                    });
                }

            }
        }
    }
    
    if (groupData.title) {
        this.renderGroupTitle(groupIdx,groupData.title,groupWidth);
        this.bGroupCreated[groupIdx] = true;
        this.groupWidth[groupIdx] = groupWidth;
    }
};


var _renderGroupTitle = function (groupIdx,title,groupWidth){
    var titleWgt = null;
    
    if (title) {
        titleWgt = PanelCommon.loadTemplate(GridlistTemplate.GroupTitle, {
            title : title
        });
        titleWgt.width = groupWidth;
        this.widget.attachGroupTitle(groupIdx, titleWgt);
        Volt.log("[grid-list-view.js] renderGroupTitle groupIdx =" + groupIdx);
        this.groupTitle[groupIdx] = titleWgt;
    }
};


var renderGridGroupMypage = function (self, groupIdx, colNum, mypageGroupData){
    Volt.log("[grid-list-view.js] renderGridGroupMypage");
    var width = 0;
    var height = 0;
    var usedHeight = 0;
   
    Volt.log("[grid-list-view.js] renderGridGroupMypage colNum = "+ colNum + ", groupIdx = " + groupIdx);
    var hasMsg = mypageGroupData.hasMsg;
    var gameCnt = mypageGroupData.modelArr.length;
    if(mypageGroupData.leftItemCnt > 1 || (mypageGroupData.leftItemCnt == 1 && gameCnt > 0)){
        for (var i = 0; i < colNum; ++i) {
            usedHeight = 0;
            if (i == 0) {
                if (self.style == CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME) {
                    //login in with msg,coupon and profile
                    if (hasMsg) {
                        width = self.minWidth;
                        height = self.minHeight / 2;
                    } else {
                        width = self.minWidth;
                        height = self.minHeight;
                    }
                } else {
                    width = self.minWidth;
                    height = self.minHeight;
                }
            } else if(i == 1){
                //login in and no installed games
                if (gameCnt <= 0) {
                    width = self.param.width - self.minWidth;
                    height = self.minHeight * 2;
                } else {
                    width = self.minWidth;
                    height = self.minHeight;
                }
            } else {
                width = self.minWidth;
                height = self.minHeight;
            }

            self.widget.addColumn({
                groupIndex : groupIdx,
                styleIndex : 0,
                columnWidth : width
            });

            for (var j = 0; j <= self.rowNum; ++j) {
                if (j == 2 || (mypageGroupData.leftItemCnt == 1 && j == 1)) {
                    height = self.minHeight;
                }
                usedHeight += height;
                if (usedHeight <= self.param.height) {
                    self.widget.addRowToColumn({
                        groupIndex : groupIdx,
                        styleIndex : 0,
                        columnIndex : i,
                        rowHeight : height
                    });
                }
            }
        }
    } else if(mypageGroupData.leftItemCnt == 1 && gameCnt <= 0) {
        //leftItemCnt ==1 and no installed games
        self.rowNum = 1;
        for (var i = 0; i < colNum; ++i) {
            if(i == 0){
                width = self.minWidth;
                height = self.minHeight;
            }
            
            if(i == 1){
                width = self.param.width - self.minWidth;
                height = self.minHeight * 2;
            }
            
            self.widget.addColumn({
                groupIndex : groupIdx,
                styleIndex : 0,
                columnWidth : width
            });

            self.widget.addRowToColumn({
                groupIndex : groupIdx,
                styleIndex : 0,
                columnIndex : i,
                rowHeight : height
            });
        }
    }
};

var _assignGridData = function(groupIdx, models,mypageGroupData) {
	Volt.log("[grid-list-view.js] _assignGridData");
	
    if (mypageGroupData) {
        assignGridDataMypage(this,groupIdx, models, mypageGroupData);
    } else {
        var modelData = null;
        this.widget.allGroupDataArr[groupIdx] = [];
        for (var j = 0; j < models.length; ++j) {
            modelData = models[j];
            var data = new Data();
            this.setItemData(data, modelData);
            this.widget.addData({
                groupIndex : groupIdx,
                data : data
            });
            this.widget.allGroupDataArr[groupIdx].push(data);
        }
    }
};

var assignGridDataMypage = function(self,groupIdx, models,mypageGroupData) {
    Volt.log("[grid-list-view.js] assignGridDataMypage ");
    self.widget.allGroupDataArr[groupIdx] = [];
    if(mypageGroupData.leftItemCnt){
        Volt.log("[grid-list-view.js] assignGridDataMypage leftItemCnt =" + mypageGroupData.leftItemCnt);
        var itemCnt = 0;
        if(models.length > 0){
            itemCnt = mypageGroupData.leftItemCnt + models.length;
        } else {
            itemCnt = mypageGroupData.leftItemCnt;
        }
        
        Volt.log("[grid-list-view.js] assignGridDataMypage itemCnt =" + itemCnt);

        var modelData = null;
        var temp = models.length;
        var columnIndex = 1;
        var rowIndex = 0;

        for (var j = 0; j < itemCnt; ++j) {
            var data = new Data();
            if (j < mypageGroupData.leftItemCnt) {
                var leftData = {
                    "leftItemCnt" : mypageGroupData.leftItemCnt,
                    "itemIndex" : j,
                };
                if((mypageGroupData.leftItemCnt == 3 && j == 2) || (mypageGroupData.leftItemCnt == 2 && j == 1 && mypageGroupData.hasMsg == false)) {
                    leftData.isProfileItem = true;
                }
                
                if((mypageGroupData.leftItemCnt == 3 && j == 0) || (mypageGroupData.leftItemCnt == 2 && j == 0 && mypageGroupData.hasMsg)){
                    leftData.hasMsg = true;
                }
                self.setItemData(data, leftData);
            } else {
                rowIndex ++;
                if(rowIndex > 2){
                    columnIndex++;
                    rowIndex = 1;
                }
                if(mypageGroupData.leftItemCnt == 1 && columnIndex == 1 && rowIndex == 2){
                    columnIndex++;
                    rowIndex = 1;
                }
                
                var gamesIndex = itemCnt - mypageGroupData.leftItemCnt - temp;
                Volt.log("[grid-list-view.js] assignGridDataMypage temp =" + temp);
                Volt.log("[grid-list-view.js] assignGridDataMypage gamesIndex =" + gamesIndex);
                modelData = models[gamesIndex];
                
                modelData.columnIndex = columnIndex;
                modelData.rowIndex = rowIndex
                
                self.setItemData(data, modelData);
                temp--;
            }

            self.widget.addData({
                groupIndex : groupIdx,
                data : data
            });
            self.widget.allGroupDataArr[groupIdx].push(data);
        }
    }
};

exports = GridlistView;

