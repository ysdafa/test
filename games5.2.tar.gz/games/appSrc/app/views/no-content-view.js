var Backbone = Volt.requireNoContext('lib/volt-backbone.js');
var PanelCommon = Volt.requireNoContext('lib/panel-common.js');
var NoContentTemplate = Volt.requireNoContext('app/templates/1080/no-content-template.js');
var CommonFucntion = Volt.requireNoContext('app/common/common-function.js');
var CommonDefine = Volt.requireNoContext('app/common/common-define.js');
var _ = Volt.requireNoContext('modules/underscore.js')._;

var NoContentView = PanelCommon.BaseView.extend({
	template : null,
	btnReturn : null,

	render : function(wgtID, txtToShow, noContentViewType) {
		Volt.log('[no-content-view.js] NoContentView.render');
		if (arguments.length != 3) {
			Volt.log("------[no-content-view.js] param number must be 3!------");
			return;
		}
		
		if(isNaN(noContentViewType)){
			Volt.log("------[no-content-view.js] third param must be number------");
			return;
		}
        
        this.noContentViewType = noContentViewType;
		switch(noContentViewType) {
			case CommonDefine.Const.NO_CONTENT_GENERAL:
				this.template = NoContentTemplate.general;
				break;
			case CommonDefine.Const.NO_CONTENT_WITH_BTN:
				this.template = NoContentTemplate.myPage;
				break;
			case CommonDefine.Const.NO_CONTENT_COUPON:
				this.template = NoContentTemplate.coupon;
				break;
			default:
				this.template = NoContentTemplate.general;
                this.noContentViewType = CommonDefine.Const.NO_CONTENT_GENERAL;
		}

		this.setWidget(PanelCommon.loadTemplate(this.template));

		if ( typeof (wgtID) === 'string') {
			this.widget.id = wgtID;
		}
		if ( typeof (txtToShow) === 'string') {
			this.widget.getChild(0).text = txtToShow;
		} else {
			this.widget.getChild(0).text = "The second param should be string type!";
		}
        
		if (noContentViewType==CommonDefine.Const.NO_CONTENT_WITH_BTN) {
			var btnLsner = new ButtonListener();
			btnLsner.onButtonClicked = function(btn,type){
				switch(btn.ID){
					case 'return':
					Backbone.history.back();
					break;
					case 'troubleshoot':
					var aulApp = new Aul();
                    aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                    break;
                    default:
                    break;
				}
				
			};
			var btnStyle = {
				style : CommonDefine.Winset.Button_KeyScreen_Common_ContentsBtn_StyleB_Text,
				buttonType : CommonDefine.Winset.BUTTON_TEXT,
			};
			this.btnReturn = PanelCommon.loadTemplate(NoContentTemplate.button,btnStyle,this.widget.getChild(1));
			this.btnReturn.addListener(btnLsner);
			if(CommonDefine.Const.NO_CONTENT_COUPON == noContentViewType){
				this.btnReturn.setText({state:'all',text:Volt.i18n.t('COM_SID_RETURN')});
				this.btnReturn.ID = 'return';
			}else{
				this.btnReturn.setText({state:'all',text:Volt.i18n.t('TV_SID_TROUBLESHOOT')});
				this.btnReturn.ID = 'troubleshoot';
			}
			
			this.widget.getChild(1).addEventListener('OnMouseOver', function() {
				Volt.log("[no-content-view.js] ------------- button setFocus");
				this.btnReturn.setFocus();
			}.bind(this));
			
			this.widget.onFocus = _.bind(this.onFocus,this);
			this.widget.onBlur = _.bind(this.onBlur,this);
			this.widget.focusable = true;
		}
		return this;
	},
	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur',
	},
	onFocus : function(widget) {
		Volt.log('[no-content-view.js] onFocusReturn this.btnReturn.text() = ' + this.btnReturn.text());
		this.btnReturn.setFocus();
	},

	onBlur : function(widget) {
		Volt.log('[no-content-view.js] onBlurReturn');
		//this.btnReturn.killFocus();
	},
});

exports = NoContentView;
