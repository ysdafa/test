// Require Common Modules
var Backbone      = Volt.requireNoContext('lib/volt-backbone.js');
var _             = Volt.requireNoContext('modules/underscore.js')._;
var PanelCommon   = Volt.requireNoContext('lib/panel-common.js');
var CommonDefine  = Volt.requireNoContext('app/common/common-define.js');
var Mediator      = Volt.requireNoContext('app/common/event-mediator.js');
var Utils         = Volt.requireNoContext('app/common/utils.js');

var voltApiWrapper     = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var MainTemplate       = PanelCommon.requireTemplate('main');
var MainCategoryModel  = Volt.requireNoContext("app/models/main-category-model.js");
var CategoryCollection = Volt.requireNoContext('app/models/category-base-collection.js');
var WinsetCategoryTab  = Volt.requireNoContext("WinsetUIElement/winsetCategoryTab.js");
var DeviceModel        = Volt.requireNoContext("app/models/device-model.js");
var VoiceGuide         = Volt.requireNoContext('app/common/voiceGuide.js');
var voltapi        = Volt.requireNoContext('voltapi.js');

var signStateInCategory = 0;
var categoryViewSelf = null;

var CategoryView = PanelCommon.BaseView.extend({
	parent : null,
	bRealData : false,
	tabChanged :false,
	expandAni : null,
	shrinkAni : null,
	categoryList : [],
	signState : false,
	userAccount : null,
	
	initialize : function(parent) {
		this.parent = parent;
		this.startListening();
		categoryViewSelf = this;
		//this.listenTo(CategoryCollection, 'reset', this.updateCategoryTab);
	},

	startListening : function() {
        Mediator.on('EVENT_DESTROY_MULTI_SELECTION', 	this.showCategory, 	this);
        Mediator.on('EVENT_MAIN_CATEGORY_HIDE', 		this.hideCategory, 	this);
        Mediator.on('EVENT_MAIN_CATEGORY_FOCUS', 		this.expand, 		this);
        Mediator.on('EVENT_MAIN_CATEGORY_BLUR', 		this.shrink, 		this);

        Mediator.on(CommonDefine.Event.SIGN_STATE_UPDATE, 	 this.updateCategory, this);
        Mediator.on('EVENT_PRESS_DELETE_MENU', 			     this.moveCategory,   this);
        Mediator.on('EVENT_PRESS_UPDATE_MENU', 			     this.moveCategory,   this);
        Mediator.on(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateCategory, this);
        Mediator.on(CommonDefine.Event.UPDATE_FOR_CACHE_DATA,this.updateCategory, this);
        Mediator.on('EVENT_PRESS_EDIT_NICKNAME',             this.moveCategory,   this);
	},
    
    stopListening : function(){
        Mediator.off('EVENT_DESTROY_MULTI_SELECTION', 	null, 	    this);
        Mediator.off('EVENT_MAIN_CATEGORY_HIDE', 		null, 	    this);
        Mediator.off('EVENT_MAIN_CATEGORY_FOCUS', 		null, 		this);
        Mediator.off('EVENT_MAIN_CATEGORY_BLUR', 		null, 		this);

        Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE, 	    null,   this);
        Mediator.off('EVENT_PRESS_DELETE_MENU', 			    null,   this);
        Mediator.off('EVENT_PRESS_UPDATE_MENU', 			    null,   this);
        Mediator.off(CommonDefine.Event.UPDATE_FOR_REAL_DATA,   null,   this);
        Mediator.off(CommonDefine.Event.UPDATE_FOR_CACHE_DATA,  null,   this);
        Mediator.off('EVENT_PRESS_EDIT_NICKNAME',               null,   this);
    },

	render : function(parentPoint) {
		Volt.log('[main-category-view.js] CategoryView.render');

		if (!this.widget.created) {
			var MainTemplate = PanelCommon.requireTemplate('main');
			this.setWidget(this.initCategoryTab(this.parent));
			this.widget.created = true;
		}
		return this;
	},

	events : {
		NAV_FOCUS : 'onFocus',
		NAV_BLUR : 'onBlur',
	},

	onFocus : function(widget) {
		Volt.log('[main-category-view.js] CategoryView.onFocus');
		Mediator.trigger('EVENT_MAIN_CATEGORY_FOCUS');
		widget.setFocus();
		var categoryName = Volt.i18n.t('TV_SID_MIX_CATEGORY_END').replace('<<A>>',MainCategoryModel.get('categoryName'));
		VoiceGuide.getVoiceGuide(categoryName);
		
        if (categoryViewSelf.bRealData){
            categoryViewSelf.bRealData = false;
        }
	},

	onBlur : function(widget) {
		Volt.log('[main-category-view.js] CategoryView.onBlur');
		Mediator.trigger('EVENT_MAIN_CATEGORY_BLUR');
	},

	expand : function() {
		Volt.log('[main-category-view.js] CategoryView.expand');
		
		
		/*
		this.widget.animate('y', -36, CommonDefine.Const.MENU_ANIM_DURATION);
		this.widget.animate('height', 1080 * 0.1, CommonDefine.Const.MENU_ANIM_DURATION);
		*/
		if(this.expandAni){
            this.expandAni.stop();
        }
        if(this.shrinkAni){
            this.shrinkAni.stop(true);
        }
		this.expandAni = new MultiObjectTransition();
		this.expandAni.setDuration(CommonDefine.Const.MENU_ANIM_DURATION);
		this.expandAni.AddObjectDestination(this.widget,"y", -36);
		this.expandAni.AddObjectDestination(this.widget, "size", {w: this.widget.width, h:1080 * 0.1});
		this.expandAni.play();
	},

	shrink : function() {
		Volt.log('[main-category-view.js] CategoryView.shrink');
		/*
		this.widget.animate('y', 0, CommonDefine.Const.MENU_ANIM_DURATION);
		this.widget.animate('height', 1080 * 0.066667, CommonDefine.Const.MENU_ANIM_DURATION);
		*/
		
		if(this.shrinkAni){
            this.shrinkAni.stop();
        }
        if(this.expandAni){
            this.expandAni.stop(true);
        }
		
		this.shrinkAni = new MultiObjectTransition();
		this.shrinkAni.setDuration(CommonDefine.Const.MENU_ANIM_DURATION);
		this.shrinkAni.AddObjectDestination(this.widget,"y", 0);
		this.shrinkAni.AddObjectDestination(this.widget, "size", {w: this.widget.width, h:1080 * 0.066667});
		this.shrinkAni.play();
	},

	hideCategory : function() {
		Volt.log('[main-category-view.js] hideCategory ~~~~~');
		this.widget.focusable = false;
		this.widget.opacity = 0;
		Mediator.off('EVENT_MAIN_CATEGORY_FOCUS', null, this);
		Mediator.off('EVENT_MAIN_CATEGORY_BLUR', null, this);
		//this.offEvent();
		Volt.Nav.reload();
	},

	showCategory : function() {
		Volt.log('[main-category-view.js] showCategory ~~~~~');
		this.widget.focusable = true;
		this.widget.opacity = 255;
		this.widget.changeTab(0);
		Mediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.expand, this);
		Mediator.on('EVENT_MAIN_CATEGORY_BLUR', this.shrink, this);
		//this.onEvent();
		Volt.Nav.reload();
	},

	moveCategory : function() {
		var index = this.widget.currentTabIndex();
		var categoryId = CategoryCollection.at(index).get('id');
		if (categoryId != "C0070") {
			Volt.log('move My Page');
			//            Volt.Nav.focus(this.widget);
			this.widget.changeTab(0);
		}
	},

	renderAnimation : function() {
		this.widget.opacity = 255;
		this.widget.animate('scale', {
			x : 1.2,
			y : 1.2
		}, 300, 'cubic');
	},

	updateCategory : function() {
        Volt.log('[main-category-view.js] updateCategory ');
        var that = this;
        
        var needUpdate = this.isNeedUpdate();
        if(!needUpdate){
            return;
        }

        this.updateCategoryTab(that.widget);
        that.bRealData = true;
	},
	
	isNeedUpdate : function(){
        var needed = false;
        var currentSignState = voltApiWrapper.getSSOLoginState();
        if (this.signState == currentSignState) {
            Volt.log('[main-category-view.js] updateCategory same signstate, currentSignState ='+currentSignState);
            if(this.signState){
                //need check user account
                var accountInfo = voltApiWrapper.getSSOLoginInfo();
                var currentAccount = null;
                if (accountInfo && accountInfo.login_id) {
                    currentAccount = accountInfo.login_id;
                }
                if (this.userAccount == currentAccount) {
                    Volt.log('[main-category-view.js] updateCategory same account ');
                    needed = this.checkCategory();
                } else {
                    this.userAccount = currentAccount;
                    needed = true;
                }
            } else {
                //no need check user account
                needed = this.checkCategory();
            }
            
        } else {
            this.signState = currentSignState;
            needed = true;
        }
        
        return needed;
    },
    
    checkCategory : function(){
        var categoryNum = CategoryCollection.length;
        if (this.categoryList.length === categoryNum) {
            Volt.log('[main-category-view.js] checkCategory same length ');
            var currentCategoryList = [];
            for (var i = 0; i < CategoryCollection.length; ++i) {
                currentCategoryList.push(CategoryCollection.at(i).get('name'));
            }
            var temp1 = currentCategoryList.sort().toString();
            var temp2 = this.categoryList.sort().toString();
            Volt.log('[main-category-view.js] checkCategory temp1= ' + temp1);
            Volt.log('[main-category-view.js] checkCategory temp2= ' + temp2);
            if (temp1 == temp2) {
                Volt.log('[main-category-view.js] checkCategory same categorys ');
                return false;
            }
        }
        return true;
    },
    
    /*
	onEvent : function() {
		Volt.log('[main-category-view.js] onEvent ~~~~~');
		//var currentSignState = voltApiWrapper.getSSOLoginState();
		var currentSignState = Utils.Account.getSignState();
		Volt.log('[main-category-view.js] onEvent ~~~~~ currentSignState =' + currentSignState);
		if (signStateInCategory != currentSignState) {
			signStateInCategory = currentSignState;
			this.updateCategory();
		}

		Mediator.on(CommonDefine.Event.SIGN_STATE_UPDATE, this.updateCategory, this);
		Mediator.on(CommonDefine.Event.EDIT_NICK_NAME, this.updateNickName, this);
	},

	offEvent : function() {
		Volt.log('[main-category-view.js] offEvent ~~~~~');
		signStateInCategory = Utils.Account.getSignState();
		Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE, this.updateCategory, this);
		Mediator.off(CommonDefine.Event.EDIT_NICK_NAME, this.updateNickName, this);
	},
	*/

    initCategoryTab : function(parent) {
        Volt.log('[main-category-view.js] initCategoryTab ~~~~~');
        var categoryTab = new WinsetCategoryTab({
            style : WinsetCategoryTab.Categorytabtyle.Categorytab_Style_A,
            x : 0,
            y : 0,
            unFocusHighlightbarHeight : 2,
            focusHighlightbarHeight : 1080*0.1,
            width : Volt.sceneWidth,
            height : 1080 * 0.066667,
            parent : parent
        });
        
        new Widget({
            x : 0,
            y : 0,
            width : Volt.sceneWidth,
            height : 1,
            color : Volt.hexToRgb('#ffffff', 10),
            parent : categoryTab
        }); 

        var tabListener = new CategoryTabListener;
        tabListener.onTabChanged = _.bind(this.onFocusCategroyTabChanged, this);
        //tabListener.onTabClicked = _.bind(this.onItemClick, this);
        categoryTab.addCategoryTabListener(tabListener);
        
        var keyboardListener = new KeyboardListener;
        keyboardListener.onKeyReleased = function (actor, keyCode) {
            Volt.log('[main-category-view.js] onKeyReleased');
            if (keyCode == Volt.KEY_JOYSTICK_OK) {
                Volt.setTimeout(function() {
                    Volt.Nav.onKeyEvent(Volt.KEY_JOYSTICK_DOWN, Volt.EVENT_KEY_PRESS);
                }, 10);
                this.tabChanged = false;
            }
        };
        categoryTab.addKeyboardListener(keyboardListener);
        return categoryTab;
    },

	onFocusCategroyTabChanged : function(categoryTab, index) {
		Volt.log('[main-category-view.js] onFocusCategroyTabChanged ~~~~~'+index);
		this.tabChanged = true;
		var categoryName = Volt.i18n.t('TV_SID_MIX_CATEGORY_END').replace('<<A>>',categoryTab.tabText(index));
		if(!categoryViewSelf.bRealData){
		    VoiceGuide.getVoiceGuide(categoryName);
		}
		
		var categoryId = CategoryCollection.at(index).get('id');
		Volt.log('[main-category-view.js] onFocusCategroyTabChanged ~~~~~ categoryId ='+ categoryId);
		var name = getCategoryNameByID(categoryId);
		Volt.log('[main-category-view.js] onFocusCategroyTabChanged ~~~~~ name ='+ name);
		MainCategoryModel.set('category', categoryId);
		MainCategoryModel.set('categoryName', CategoryCollection.at(index).get('name'));
		Backbone.history.navigate(name.split("\/")[0], {
			trigger : true,
			replace : true
		});
		//add KPILog
		Volt.KPIMapper.addEventLog('MOVECATEG', {
            d : {
                cp : '',
                sp:Volt.KPIMapper.getSelectPosition(0),
                inputby: '',
            }
        });
	},
	
	addCategoryTabItem : function() {
		Volt.log('[main-category-view.js] addCategoryTabItem ~~~~~');
		var count = CategoryCollection.length;
		if(count>0){
			this.widget.focusable = true;
		}
		var curName = null, itemWithSlash = false;
		var categoryId = null,itemName = null, tmpWidth = -1;
		var currentCategoryList = [];
		for (var i = 0; i < count; ++i) {
			tmpWidth = -1;
			categoryId = CategoryCollection.at(i).get('id');
			if ("C0070" == categoryId) {
				changeMyPageName(i,this);
				itemName = CategoryCollection.at(i).get('name');
				var currLang = DeviceModel.get('languageCode');
				if ('en' == currLang) {
					if (itemName.length > 15) {
						tmpWidth = new TextWidget({
							text : '15 characters^^',
							font : this.widget.tabFont
						}).width;
					}
				} else if ('ko' == currLang) {
					if (itemName.length > 13) {
						tmpWidth = new TextWidget({
							text : '13 characters',
							font : this.widget.tabFont
						}).width;
					}
				}
			}
			currentCategoryList.push(CategoryCollection.at(i).get('name'));
			this.widget.addTab(CategoryCollection.at(i).get('name'), tmpWidth, -1);
		}
		
		this.categoryList = currentCategoryList.slice(0);
		
		for (var i = 0; i < count; ++i) {
			curName = CategoryCollection.at(i).get('name');
			if (curName.indexOf("/")!=-1 && itemWithSlash == false) {
				itemWithSlash = true;
				this.widget.setTabSpliterSize(2, 1080*0.02037, i);
			}
		}
	},
    
    addCategoryTabItemFor720 : function(){
        Volt.log('[main-category-view.js] addCategoryTabItem for 720P ~~~~~');
		var count = CategoryCollection.length;
		if(count>0){
			this.widget.focusable = true;
		}
		var curName = null, itemWithSlash = false;
		var categoryId = null,itemName = null, tmpWidth = -1;
		var currentCategoryList = [];
		
		for (var i = 0; i < count; ++i) {
			tmpWidth = -1;
			categoryId = CategoryCollection.at(i).get('id');
            switch(categoryId){
                case "C0070":
                    changeMyPageName(i,this);
                    itemName = CategoryCollection.at(i).get('name');
                    var currLang = DeviceModel.get('languageCode');
                    if ('en' == currLang) {
                        if (itemName.length > 15) {
                            tmpWidth = new TextWidget({
                                text : '15 characters^^',
                                font : this.widget.tabFont
                            }).width;
                        }
                    } else if ('ko' == currLang) {
                        if (itemName.length > 13) {
                            tmpWidth = new TextWidget({
                                text : '13 characters',
                                font : this.widget.tabFont
                            }).width;
                        }
                    }
                    this.widget.addTab(CategoryCollection.at(i).get('name'), tmpWidth, -1);
                    break;
                case "C0010":
                    this.widget.addTab(CategoryCollection.at(i).get('name'), tmpWidth, -1);
                    break;
                default:
                    break;
            }
            
            currentCategoryList.push(CategoryCollection.at(i).get('name'));
		}
		this.categoryList = currentCategoryList.slice(0);
    },

	removeCategoryTab : function() {
        Volt.log('[main-category-view.js] removeCategoryTab ~~~~~');
        var tabNum = this.widget.numberOfTab();
        Volt.log('[main-category-view.js] tabNum:::' + tabNum);
        for (var i = tabNum - 1; i >= 0; i--) {
            Volt.log('removeTab..........');
            this.widget.removeTab(i);
        }
        this.categoryList = [];
	},

	selectCategoryTab : function() {
		Volt.log('[main-category-view.js] selectCategoryTab ~~~~~');
		var currentID = MainCategoryModel.get('category');
		Volt.log('[main-category-view.js] __setSelectedCategory  currentID =' + currentID);
		var count = CategoryCollection.length;
		if (currentID) {
			for (var i = count - 1; i >= 0; i--) {
				var categoryId = CategoryCollection.at(i).get('id');
				if (categoryId === currentID) {
					this.widget.changeTab(i);
					break;
				}
			}
		} else {
		    if(this.widget.numberOfTab() > 1) {
		        this.widget.changeTab(1);
		    } else {
		        Volt.Nav.blur();
		    }
		}
		this.tabChanged=false;
	},

	updateCategoryTab : function() {
		Volt.log('[main-category-view.js] updateCategoryTab ~~~~~');
		this.removeCategoryTab();
        if(scene.height == 720){
            Volt.log('720P');
            this.addCategoryTabItemFor720();
        } else {
            Volt.log('not for 720P');
            this.addCategoryTabItem();
        } 
		
		this.selectCategoryTab();
		try{
		    Volt.Nav.reload();
		} catch(e) {
		    Volt.log('[main-category-view.js] updateCategoryTab ~~~~~ e :' + e);
		}
	}
});

function getCategoryNameByID(categoryId) {
	Volt.log('[main-category-view.js] getCategoryNameByID ~~~~~');
	var name = '';

	switch(categoryId) {
		case 'C0010':
			name = 'Spotlight';
			break;
		case 'C0030':
			name = 'Most Popular';
			break;
		case 'C0040':
			name = 'What`s New';
			break;
		case 'C0050':
			name = 'Top Grossing';
			break;
		case 'C0070':
			name = 'My Page';
			break;
		case 'C0080':
			name = 'Arcade';
			break;
		case 'C0081':
			name = 'Party';
			break;
		case 'C0082':
			name = 'Puzzle';
			break;
		case 'C0083':
			name = 'Sports';
			break;
		case 'C0084':
			name = 'Shooting';
			break;
		case 'C0085':
		      name = 'Rpg';
		      break;
		default:
			break;
	}
	return name;
}

function changeMyPageName(index,categorySelf) {
    Volt.log('[main-category-view.js] changeMyPageName ~~~~~');
    var bWasReady = voltApiWrapper.checkInitStatus();
    Volt.log('[main-category-view.js] changeMyPageName ~~~~~ bWasReady =' + bWasReady);
    if (bWasReady) {
        var signState = voltApiWrapper.getSSOLoginState();
        Volt.log('[main-category-view.js] changeMyPageName ~~~~~ signState =' + signState);
        if (signState) {
            var accountInfo = voltApiWrapper.getSSOLoginInfo();
            if(accountInfo && accountInfo.login_id){
                var account = accountInfo.login_id;
                Volt.log('[main-category-view.js] changeMyPageName ~~~~~ account =' + account);
                categorySelf.userAccount = account;
                if (account && account.length > 0) {
                    var temp = account.split('@')[0];
                    Volt.log('SIGN IN ACCOUNT>>>>>>>>>>>' + temp);
                    CategoryCollection.at(index).set('name', Volt.i18n.t('TV_SID_MIX_S_PAGE').replace('<<A>>', temp));
                } else {
                    Volt.log('Can not get samsung account>>>>>>>>>>>' + account);
                    CategoryCollection.at(index).set('name', Volt.i18n.t('TV_SID_MIX_S_PAGE').replace('<<A>>', Volt.i18n.t('TV_SID_EDIT_NICKNAME')));
                }
            } else {
                CategoryCollection.at(index).set('name', Volt.i18n.t('TV_SID_MIX_S_PAGE').replace('<<A>>', Volt.i18n.t('TV_SID_EDIT_NICKNAME')));
            }
            
        } else {
            CategoryCollection.at(index).set('name', Volt.i18n.t('UID_MY_GAMES'));
            categorySelf.userAccount = null;
        }
    } else {
        CategoryCollection.at(index).set('name', Volt.i18n.t('UID_MY_GAMES'));
    }
}

exports = CategoryView;
