// Include libraries
var Backbone        	= Volt.requireNoContext('lib/volt-backbone.js');
var Q               	= Volt.requireNoContext('modules/q.js');
var CommonDefine    	= Volt.requireNoContext('app/common/common-define.js');
var PanelCommon     	= Volt.requireNoContext('lib/panel-common.js');
var CouponBoxModel  	= Volt.requireNoContext('app/models/coupon-box-model.js');
var Utils           	= Volt.requireNoContext('app/common/utils.js');
var EventMediator   	= Volt.requireNoContext('app/common/event-mediator.js');
var Gridlist        	= Volt.requireNoContext('app/views/grid-list-view.js');
var VoltApiWrapper  	= Volt.requireNoContext("app/common/voltapi-wrapper.js");
var CommonContent       = Volt.requireNoContext('app/common/common-content.js');
var DeviceModel 	    = Volt.requireNoContext('app/models/device-model.js');
var SelectGamesTemplate = Volt.requireNoContext('app/templates/1080/select-games-popup.js');
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');

selectGamesSelf = null;
var SelectGamesPopup = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.container,
    params : null,
    winsetBackground : null,
    gameView : null,
    btnView : null,

    render : function() {
    },

    initialize : function() {
        Volt.log('[select-games-popup.js] initialize');
    },

    show : function(options, animationType) {
        Volt.log('[select-games-popup.js] show,options =' + options);
        this.params = JSON.parse(options);
        selectGamesSelf = this;
        
        this.winsetBackground = CommonContent.loadTemplateInWinsetBackgroud(this.template);
        this.setWidget(this.winsetBackground.getChild(0));
        this.winsetBackground.show();

        this.renderTitle();
        this.renderLine();
        this.renderDescription();
        this.renderGameGrid(this.params.couponNo, this.params.index);
        this.renderButton();

        Volt.Nav.setRoot(this.widget);
        Volt.Nav.focus(Volt.Nav.getItem(0));
    },

    renderTitle : function() {
        Volt.log('[select-games-popup.js] renderTitle');
        var container = this.widget.getChild('title-container');
        container.addChild(new titleView().render().widget);
    },

    renderLine : function() {
        Volt.log('[select-games-popup.js] renderLine');
        var container = this.widget.getChild('line-container');
        container.addChild(new lineView().render().widget);
    },

    renderDescription : function() {
        Volt.log('[select-games-popup.js] renderDescription');
        var container = this.widget.getChild('description-container');
        container.addChild(new description().render().widget);
    },

    renderGameGrid : function(couponNo, itemIndex) {
        Volt.log('[select-games-popup.js] renderGameGrid couponNo = ' + couponNo);
        var container = this.widget.getChild('grid-container');
        container.addChild(new gameGridView().render(container, couponNo, itemIndex).widget);
    },

    renderButton : function() {
        Volt.log('[select-games-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        container.addChild(new buttonView().render().widget);
    },

    hide : function() {
        Volt.log('[select-games-popup.js] hide');
        var deferred = Q.defer();
        
        Volt.Nav.focus(null);
        Volt.Nav.reset();
        
        if(this.gameView){
            this.gameView.destroy();
            this.gameView = null;
        }
        
        if(this.btnView){
            this.btnView.destroy();
        }
        
        if(this.winsetBackground){
            this.winsetBackground.hide();
            this.destroy(this.winsetBackground);
            this.winsetBackground.destroy();
            this.winsetBackground = null;
        }

        deferred.resolve();
        return deferred.promise;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                this.destroy(widget.getChild(i));
            }
        }
    },
});

//template of title area
var titleView = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.title,

    render : function() {
        popupTitle = this;
        SelectGamesTemplate.title.children[0].text = Volt.i18n.t('TV_SID_SELECT_GAMES');
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of line area
var lineView = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.line,

    render : function() {
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of description area
var description = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.description,

    render : function() {
        SelectGamesTemplate.description.children[0].text = Volt.i18n.t('TV_SID_CAN_USE_COUPON_ON_THE_GAMES_BELOW')
            + "\n" + Volt.i18n.t('TV_SID_EARN_REWARDS_FOR_PLAYING_GAMES') + "\n" + Volt.i18n.t('TV_SID_SELECT_JUST_ONE_GAME');
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of text field area
var gameGridView = PanelCommon.BaseView.extend({
    grid : null,

    render : function(container, couponNo, itemIndex) {
        Volt.log('[select-games-popup.js] gameGridView render begin');
        selectGamesSelf.gameView = this;
        if (!this.widget.created) {
            var coupon_game_list = CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list');
            var gameListCount = CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list_count');
            
            var couponGameData = {
                style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
                groups : [{
                    modelArr : coupon_game_list
                }]
            };

            var gridView = null;
            if(gameListCount ==2){
                gridView = new Gridlist(SelectGamesTemplate.grid2, JSON.stringify(couponGameData), parseInt(Volt.sceneWidth * 0.16875), parseInt(1080 * 0.377778));
            }else if(gameListCount ==3){
                gridView = new Gridlist(SelectGamesTemplate.grid3, JSON.stringify(couponGameData), parseInt(Volt.sceneWidth * 0.16875), parseInt(1080 * 0.377778));
            }

            gridView.setItemData = function(mustache, modelData) {
                mustache.imgUrl = modelData['thumbnail_url'];
                mustache.title = modelData['game_title'];
                mustache.appId = modelData['app_id'];
            };

            gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
                Volt.log('[select-games-popup.js] setItemTemplate');
                CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
                selectGamesSelf.gameView.addThumbnailListener(rendererInstance.thumbnail);
                CommonContent.setFoverFactor(rendererInstance.thumbnail,parentWidth);
                var thumbnailObj = rendererInstance.thumbnail;
                thumbnailObj.setContentImage(data.imgUrl);
                if (thumbnailObj.visibleStyles() & CommonDefine.ThumbnailStyle.THUMB_STYLE_INFO) {
                    thumbnailObj.setInformationText("text1", data.title);
                    thumbnailObj.visualizeInformationText(false,"text2");
                }
            };

            gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
                Volt.log("[select-games-popup.js] onItemPress itemIndex =" + itemIndex);

                Utils.Timer.clearTimeOut();
                //games is installed?
                var appId = itemData.appId;
                Volt.log("[select-game-popup.js] onItemPress, appId = " + appId);
                var installed = VoltApiWrapper.isWidgetInstalled(appId);
                Volt.log("[select-game-popup.js] onItemPress, installed = " + installed);
                var installedPath = VoltApiWrapper.getInstalledPath(appId);
                Volt.log("[select-game-popup.js] onItemPress, installedPath = " + installedPath);
                var Renderer = this.widget.renderer(groupIndex, itemIndex);
                var itemBGColor = null;
                if(Renderer.thumbnail.imgReady){
                    itemBGColor = Renderer.thumbnail.getInformationColorPicking();
                }

                Volt.setTimeout(function(appId, itemBGColor, installed,installedPath) {
                    if (installed && installedPath) {
                        //run this game
                        VoltApiWrapper.launchApp(appId);
                    } else {
                        //enter into detail-view
                        //add EventLog
                        var spValue  = 'CCP' + Volt.KPIMapper.getIndexFormat(itemIndex + 1);
						Volt.KPIMapper.addEventLog('VIEWGAME', {
				            d : {
				                cp : 'G07_COUPON',
				                appid : appId,
				                sp:spValue,
				                content:'n/a',
				                inputby:'',
				            }
				        });
									
                        EventMediator.trigger("ENTER_INTO_DETAIL_FROM_POPUP");
                        Volt.KPIAppId = appId;
                        if(itemBGColor){
                            var bgColor = JSON.parse(itemBGColor);
                            Backbone.history.navigate('detail/' + appId, {
                                trigger : true,
                                bgColor : bgColor
                            });
                        } else {
                            Backbone.history.navigate('detail/' + appId, {
                                trigger : true
                            });
                        }
                    }
                }, 200, appId, JSON.stringify(itemBGColor), installed,installedPath);

                Backbone.history.back();
            };

            gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {
                Utils.Timer.clearTimeOut();
            };

            gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {
                //this.onTextScrollEnd(parent);
                Utils.Timer.setTimerOut();
            };

			gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
				Volt.log('[select-games-popup.js] gridView.focusChanged ,fromItemIndex = ' + fromItemIndex + ',,,toItemIndex = ' + toItemIndex);
				if(toItemIndex >= 0 && toGroupIndex >= 0){
					var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
					var voiceText = '';
		
					if(-1 == fromItemIndex){
						var gameCouts = Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>',CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list_count'));
						voiceText += SelectGamesTemplate.title.children[0].text + ', ' + SelectGamesTemplate.description.children[0].text + ',' + gameCouts + ',';
					}

					voiceText += data.title + '.';
					VoiceGuide.getVoiceGuide(voiceText);
				}
			};
			
            this.grid = gridView.render().widget;
            this.grid.focusable = true;
            this.setWidget(this.grid);
            this.widget.created = true;
        }

        Volt.log('[select-games-popup.js] gameGridView render end');
        return this;
    },
    
    addThumbnailListener : function(thumbnail){
        thumbnail.imgReady = false;
        var thumbListener = new ThumbnailListener;

        thumbListener.onImageReady = function(thumbnail, id, success) {
            thumbnail.imgReady = success;
        };
        thumbnail.addThumbnailListener(thumbListener); 
    },

    events : {
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onSelect : function() {
        //Backbone.history.navigate('detail/' + this.model.get('id'), {trigger: true });
    },

    onFocus : function(widget) {
        Volt.log('[select-games-popup.js] gameGridView.onFocus');
        if (this.grid) {
            widget = this.grid;
            Volt.Nav.focus(this.grid);
            widget.onFocus();
        }
    },
    
    onBlur : function(widget) {
        Volt.log('[select-games-popup.js] gameGridView.onBlur');
        if (widget) {
            if (selectGamesSelf.gameView.grid) {
                widget.onBlur();
            }
        }
    },

    destroy : function() {
        if(selectGamesSelf.gameView.grid){
            selectGamesSelf.gameView.grid.destroy();
        }
    }
});

//template of button area
var buttonView = PanelCommon.BaseView.extend({
    template : SelectGamesTemplate.button,
    btn1 : null,
	btnListener : new ButtonListener(),
	
    render : function() {
        Volt.log('[select-games-popup.js] buttonView.render');
        selectGamesSelf.btnView = this;
        //var that = this;
        this.btnListener.onButtonClicked = function(button,type){
        	selectGamesSelf.btnView.onSelectCloseButton();
        };
        
    	var btnStyle = {
		style : CommonDefine.Winset.Button_image_O_Style_F,
		buttonType : CommonDefine.Winset.BUTTON_TEXT,
		};
        this.setWidget(PanelCommon.loadTemplate(this.template,btnStyle));
        this.btn1 = this.widget.getDescendant("cancelBtn");
        this.btn1.addListener(selectGamesSelf.btnView.btnListener);
        return this;
    },
    events : {
        'NAV_FOCUS #Close' : 'onFocusCloseButton',
    },

    onSelectCloseButton : function(widget) {
        Volt.log('[select-games-popup.js] buttonView.onSelect');
       	Backbone.history.back();
        Utils.Timer.clearTimeOut();
    },

    onFocusCloseButton : function(widget) {
        Volt.log('[select-games-popup.js] buttonView.focus');
        var voiceGuide = Volt.i18n.t('COM_SID_CLOSE') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);
        this.btn1.setFocus();
        Utils.Timer.setTimerOut();
    },
    
    destroy : function(){
        Volt.log('[select-games-popup.js] buttonView destroy');
        if(this.btn1){
            this.btn1.removeListener(this.btnListener);
            this.btn1.destroy();
            this.btnListener.destroy();
            this.btn1 = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

exports = SelectGamesPopup;
