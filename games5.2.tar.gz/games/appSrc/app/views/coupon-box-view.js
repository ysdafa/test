// Include libraries
var Q            = Volt.requireNoContext('modules/q.js');
var Backbone     = Volt.requireNoContext('lib/volt-backbone.js');
var Mediator     = Volt.requireNoContext('app/common/event-mediator.js');
var LoadingView  = Volt.requireNoContext('app/views/loading-view.js');
var PanelCommon  = Volt.requireNoContext('lib/panel-common.js');
var DimView      = Volt.requireNoContext('app/views/dim-view.js');

var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var VoltApiWrapper = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var Gridlist       = Volt.requireNoContext('app/views/grid-list-view.js');
var CommonContent  = Volt.requireNoContext('app/common/common-content.js');
var voltapi        = Volt.requireNoContext('voltapi.js');
var Utils          = Volt.requireNoContext('app/common/utils.js');
var CouponBoxModel = Volt.requireNoContext('app/models/coupon-box-model.js');
var CouponTemplate = Volt.requireNoContext('app/templates/1080/coupon-template.js');
var ErrorHandling  = Volt.requireNoContext('app/common/error-handling.js');
var NoContentView  = Volt.requireNoContext('app/views/no-content-view.js');
var DeviceModel    = Volt.requireNoContext('app/models/device-model.js');
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');
var networkStatus  = Volt.requireNoContext('app/common/network-state.js');
////////////////////////////////////////////////////////////////////////////////

var statusCouponView = 'HIDE';
var headerViewSelf = null;
var contentViewSelf = null;
var couponViewSelf = null;
var noContentText = '';

var CouponBoxView = PanelCommon.BaseView.extend({
    template        : CouponTemplate.container,
    isFirst         : true,
    isBackFromPopup : false,
    //gridWgt : null,
    reback          : false,
    bgColor         : null,
    backFromDetail  : false,
    viewType        : 'couponNC',
    isActive        : false,
    lastFocusInCoupon : null,

    initialize : function() {
        Volt.log('[coupon-box-view.js] initialize');
        couponViewSelf = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));
    },

    render : function() {
        Volt.log('[coupon-box-view.js] CouponBoxView.render');
        this.renderHeader();
    },

    renderHeader : function() {
        var container = this.widget.getDescendant('coupon-header-container');
        this.headerView = new HeaderView().render();
        container.addChild(this.headerView.widget);
    },

    renderContent : function() {
        Volt.log('[coupon-box-view.js] renderContent');
        var container = this.widget.getChild('coupon-content-container');
        if (CouponBoxModel.get('coupon_list_cnt') && CouponBoxModel.get('coupon_list_cnt') != 0) {
            this.contentView = new ContentView().render(container,this);
        } else {
        	var noContentWgtId = this.viewType;
        	var textToShow = Volt.i18n.t('TV_SID_REGISTERED_COUPONS') + '\n' + Volt.i18n.t('TV_SID_PLEASE_RETURN_TO_GO_TO_THE_PREVIOUS_SCREEN');
            noContentText = textToShow;
            this.contentView = new NoContentView().render(noContentWgtId,textToShow,CommonDefine.Const.NO_CONTENT_COUPON);
        }
        container.addChild(this.contentView.widget, 0);
        this.contentContainer = container;
        Volt.Nav.reload();
    },

    show : function(param, animationType) {
        this.viewIsVisiable = true;
        statusCouponView = "SHOW";
        Volt.log('[coupon-box-view.js] bgColor =' + param.bgColor);
        if (undefined === param.bgColor) {
            this.bgColor = CommonContent.getProfileColor();
        } else {
            this.bgColor = param.bgColor;
        }

        if (this.isFirst) {
            Volt.log('[coupon-box-view.js] first show');
            if (this.reback) {
                this.setWidget(PanelCommon.loadTemplate(this.template));
                this.renderHeader();
                this.reback = false;
            }
            Volt.Nav.setRoot(this.widget,{focus : null});
            //Volt.Nav.focus(null);
            LoadingView.show(CommonDefine.Const.VIEW_LOADING);

            this.requestData();
            this.isFirst = false;
        } else if (this.isBackFromPopup) {
            Volt.log('[coupon-box-view.js] back form popup');
            DimView.hide();
            Volt.Nav.setRoot(this.widget);
            var gridWgt = this.contentContainer.getChild(0);
            if (gridWgt.id == this.viewType) {
                Volt.Nav.focus(Volt.Nav.getItem(0));
            } else {
                Volt.Nav.focus(gridWgt);
                gridWgt.focusable = true;
            }
            this.isBackFromPopup = false;
        } else if (this.backFromDetail) {
            Volt.Nav.setRoot(this.widget, {focus : this.contentContainer.getChild(0)});
            //Volt.Nav.focus(this.contentContainer.getChild(0));
            this.backFromDetail = false;
        }
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
        Mediator.on(CommonDefine.Event.CHANGE_MLS,   this.changeMLS,  this);
        this.isActive = true;

        this.widget.show();
        this.startListener();
    },
    
    changeMLS : function(mlsMode){
        Volt.log("[coupon-box-view.js] changeMLS " + mlsMode);
        if(mlsMode) {
			DimView.hide();
        }
    },
    
    startListener : function (){
        Mediator.on(CommonDefine.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
        Mediator.on("ENTER_INTO_DETAIL_FROM_POPUP", this.enterIntoDetailFromPopup, this);
        Mediator.on(CommonDefine.Event.REGISTER_COUPON, this.refresh, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
        Mediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, headerViewSelf.onChangeCursor, headerViewSelf);
        Mediator.on(CommonDefine.Event.NO_NEED_BACK_WHEN_CUT_LOADING,this.setLastFocus,this);
        Mediator.on(CommonDefine.Event.DISCONNECT_USB, this.disconnectUSB, this);
    }, 
    
    stopListener : function (){
        Mediator.off(CommonDefine.Event.REGISTER_COUPON, this.refresh,this);
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR,null,headerViewSelf);
        Mediator.off("ENTER_INTO_DETAIL_FROM_POPUP", null, this);
        Mediator.off(CommonDefine.Event.MSGBOX_BUTTON, null, this);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, this);
        Mediator.off(CommonDefine.Event.NO_NEED_BACK_WHEN_CUT_LOADING,null,this);
        Mediator.off(CommonDefine.Event.DISCONNECT_USB,null,this);
    },
    
    disconnectUSB : function(){
        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB);
    },

    requestData : function() {
        var that = this;
        function onSuccess() {
            Volt.log('[coupon-box-view.js] onSuccess');
            LoadingView.hide();
            if (that.viewIsVisiable == true) {
                that.renderContent();
                var gridWgt = that.contentContainer.getChild(0);
                if (gridWgt.id == that.viewType) {
                    Volt.Nav.focus(Volt.Nav.getItem(0));
                } else {
                    Volt.log('[coupon-box-view.js] onSuccess grid exists');
                    gridWgt.focusable = true;
                    Volt.log('[coupon-box-view.js] onSuccess lastFocusInCoupon ='+ that.lastFocusInCoupon);
                    if(that.lastFocusInCoupon){
                        Volt.Nav.focus(that.lastFocusInCoupon);
                    } else {
                        Volt.Nav.focus(gridWgt);
                    }
                    
                }
                if (!that.isActive) {
                	that.getLastFocus();
                	Volt.Nav.blur();
                }
            }
            
        }

        function onError(msg) {
            LoadingView.hide();
            Volt.log("[coupon-box-view.js]" + CommonContent.getViewType());
            var viewType = CommonContent.getViewType();
            if (viewType == '#coupon') {
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR,'',JSON.stringify(msg.status));
            }
        }
		
        if (networkStatus.getNetWorkState()) {
            CouponBoxModel.fetch().then(onSuccess, onError);
            /* test coupon fake data */
            //CouponBoxModel.fetch("fake").then(onSuccess, onError);

        } else {
            Volt.log('[coupon-box-view.js]network disconnected!!!!');
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR, '', 404);
        }
    },

    hide : function(animationType) {
        Volt.log('[coupon-box-view.js] hide');
        var deferred = Q.defer();
        deferred.resolve();
        couponViewSelf.stopListener();
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, couponViewSelf);
        Mediator.off(CommonDefine.Event.CHANGE_MLS,   null,  couponViewSelf);
        Volt.Nav.focus(null);
        Volt.Nav.reset();
        LoadingView.hide();
        couponViewSelf.viewIsVisiable = false;
        
        if (couponViewSelf.backFromDetail) {
            Volt.log('[coupon-box-view.js] enter to detail');
            couponViewSelf.widget.hide();
        } else {
            couponViewSelf.isFirst = true;
            couponViewSelf.reback = true;
			couponViewSelf.remove();
        }
        
        statusCouponView = "HIDE";
        noContentText = '';
        couponViewSelf.isActive = false;
        couponViewSelf.lastFocusInCoupon = null;
        couponViewSelf.bgColor = null;
        couponViewSelf.isBackFromPopup = false;
        
        return deferred.promise;
    },

	remove: function(){
		Volt.log('[coupon-box-view.js]remove');
		if(contentViewSelf && contentViewSelf.grid){
			contentViewSelf.destroy();
			contentViewSelf.grid = null;
			contentViewSelf = null;
		}
		
		if (couponViewSelf.widget){
            couponViewSelf.widget.destroyChildren();
			couponViewSelf.widget.hide();
			couponViewSelf.widget.destroy();
			couponViewSelf.widget = null;
		}
		couponViewSelf.contentView = null;
    },

    pause : function(option) {
        Volt.log('[coupon-box-view.js] pause');
        if ("PAUSE" == statusCouponView) {
            Volt.log('[coupon-box-view.js] This view has already paused');
            return;
        }

        statusCouponView = "PAUSE";
        this.getLastFocus();
        Volt.Nav.blur();
        var mlsMode = voltapi.vconf.getValue('memory/mls/state');
        Volt.log('[detail-view.js] GamesThumbnailView check - vconf MLS_STATE : ' + mlsMode);
        if (option&&option.deactive &&mlsMode == 1) {
			Volt.log('[coupon-box-view.js]mls Mode! Do not show dim');
		} else {
			DimView.show({
				parent : this.widget.getChild('coupon-popup-container')
			});
		}
    },

    resume : function() {
        Volt.log('[coupon-box-view.js] resume');
    	if ("SHOW" == statusCouponView) {
            Volt.log('[coupon-box-view.js] This view has already showed');
            return;
        }
		
        if (this.isActive) {
            DimView.hide();
            statusCouponView = "SHOW";
            this.setLastFocus();
        }
    },
    
    deactive : function () {
        Volt.log('[coupon-box-view.js] deactive.......'); 
        if(!this.isActive){
            Volt.log('[coupon-box-view.js] already in deactive');
            return;
        }
        this.isActive = false;
        this.stopListener();
        this.pause({deactive:true});
    },
    
    active : function () {
        Volt.log('[coupon-box-view.js] active'); 
        if(this.isActive){
            Volt.log('[coupon-box-view.js] already in active');
            return;
        }
        this.isActive = true;
        this.startListener();
        this.resume();
    },
    
    getLastFocus : function () {
        this.lastFocusInCoupon = Volt.Nav.getFocusedWidget();
        Volt.log('[coupon-box-view.js] getLastFocus lastFocusInCoupon =' + this.lastFocusInCoupon);
    },
    
    setLastFocus : function() {
        Volt.log('[coupon-box-view.js] setLastFocus'); 
        if (this.lastFocusInCoupon) {
            Volt.log('[coupon-box-view.js] setLastFocus LoadingView.viewIsVisiable ='+LoadingView.viewIsVisiable);
            if(!LoadingView.viewIsVisiable){
                Volt.Nav.setRoot(this.widget, {
                    focus : this.lastFocusInCoupon
                });
            }
        } else {
            Volt.log('[coupon-box-view.js] setLastFocus while lastfocus is null');
            if(!LoadingView.viewIsVisiable){
                Volt.Nav.setRoot(this.widget);
            }
        }
    },

    processMsgBoxEvent : function(data) {
        Volt.log('[coupon-box-view.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);

        if (data.eventType == CommonDefine.Event.SELECT_BTN1) {
            switch(data.msgBoxtype) {
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
                    VoltApiWrapper.startSSOPopup();
                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR:
                    Backbone.history.back();
                    break;
                default:
                    break;
            }
        } else if (data.eventType == CommonDefine.Event.SELECT_BTN2) {

        }
    },

    enterIntoDetailFromPopup : function(params, bgColor) {
        this.backFromDetail = true;
    },
    
    refresh : function(options) {
        Volt.log("[coupon-box-view.js] refresh");
        this.isFirst = false;
        Volt.Nav.setRoot(this.widget);
        
        var gridWgt = this.contentContainer.getChild(0);
        Volt.log("[coupon-box-view.js] refresh gridWgt : " + gridWgt);
        if (gridWgt) {
            if (gridWgt.hasOwnProperty('id') && gridWgt.id == this.viewType) {
                for (var index = 0; index < gridWgt.getChildCount(); index++) {
                    Volt.Nav.removeItem(gridWgt.getChild(index));
                }
                this.contentContainer.removeChild(gridWgt);
                gridWgt.destroyChildren();
            } else {
                Volt.Nav.removeItem(gridWgt);
                this.contentContainer.removeChild(gridWgt);
            }

            gridWgt.destroy();
            this.requestData();
        }

    },
});

var HeaderView = PanelCommon.BaseView.extend({
    template : CouponTemplate.header,
    pageBackArrow : null,
    registerBtn : null,
    btnListener : new ButtonListener(),
    
    initialize : function(parent) {
        Volt.log('[coupon-box-view.js] HeaderView.initialize');
        headerViewSelf = this;
        var that = this;
        this.btnListener.onButtonClicked = function(button, type) {
            Volt.log('[coupon-box-view.js] onButtonClicked:' + button.id);
            switch(button.id) {
                case 'coupon-header-icon-schedule-image':
                    that.onSelectSchedule();
                    break;
                case 'coupon-box-back-icon':
                    CommonContent.hideToolTip();
                    Backbone.history.back();
                    break;
                default :
                    break;
            }
        };
    },

    render : function() {
        Volt.log('[coupon-box-view.js] HeaderView.render');
        //CouponTemplate.header.children[2].children[0].children[0].src = Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_topmenu_plus.png');
        this.setWidget(CommonContent.loadTemplateInWinsetBackgroud(this.template));
        
        if (!voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)) {
            this.widget.getDescendant('coupon-box-title').x = 36;
        } else {
            this.widget.getDescendant('coupon-box-title').x = 136;
        }

        this.setBackIcon();
        this.setRigisterIcon();

        this.onChangeCursor(DeviceModel.get('visibleCursor'));
        
        return this;
    },

    events : {
        //'NAV_SELECT #coupon-header-icon-schedule' : 'onSelectSchedule',
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onFocus : function(widget) {
        Volt.log('[coupon-box-view.js] HeaderView onFocus');
        if (widget && widget.id) {
            Volt.log('[coupon-box-view.js] HeaderView.focus ' + widget.id);
            if (widget.id == 'coupon-header-icon-schedule') {
                this.registerBtn.setFocus();
                var voiceGuide = '';
                if(!(CouponBoxModel.get('coupon_list_cnt') && CouponBoxModel.get('coupon_list_cnt') != 0)){
                    voiceGuide += Volt.i18n.t('TV_SID_COUPONS') + ',' + noContentText + ',';
                }
                voiceGuide += Volt.i18n.t('TV_SID_REDEEM_CUPON') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                VoiceGuide.getVoiceGuide(voiceGuide);
                
                var AbsolutePosition = this.registerBtn.parent.getAbsolutePosition();
                var opt = {
                    text: Volt.i18n.t('TV_SID_REDEEM_CUPON'),
                    x: AbsolutePosition.x,
                    y: AbsolutePosition.y,
                    height: this.registerBtn.parent.height,
                    width: this.registerBtn.parent.width,
                    direction:'up',
                    parent:this.registerBtn.parent,
                };
                CommonContent.showToolTip(opt,CouponTemplate);
            } else if (widget.id == 'coupon-box-back-icon-area') {
                Volt.log('[coupon-box-view.js] onFocus coupon-box-back-icon-area');
                this.backBtn.setFocus();
            }
        }
        //widget.opacity = 255; 
    },

    onBlur : function(widget) {
        CommonContent.hideToolTip();
        return;
    },

    onSelectSchedule : function() {
        Volt.log('[coupon-box-view.js] HeaderView.onSelectSchedule');
        CommonContent.hideToolTip();
        addEventLog('COUPONCLICK', {cp : 'G07_COUPON',inputby:'',});
        
        this.isBackFromPopup = true;
        var params = {
            "event" : "coupon-regist",
            "type" : 'input-text',
            'cp' : Volt.KPIMapper.getPageEvent().pageEvent,
            'from': 'coupon-regist',
        };
        Backbone.history.navigate('popup/' + JSON.stringify(params), {
            trigger : true
        });
    },
    
    onChangeCursor : function(visible) {
        Volt.log("[coupon-box-view.js] onChangeCursor visible is: " + visible);

        if (this.pageBackArrow) {
            if (visible) {
                this.pageBackArrow.show();
                this.widget.getDescendant('coupon-box-title').x = 136;
            } else {
                this.pageBackArrow.hide();
                this.widget.getDescendant('coupon-box-title').x = 36;
                
                var widget = Volt.Nav.getFocusedWidget();
                if(widget && widget.id == 'coupon-header-icon-schedule'){
                    Volt.Nav.focus(widget);
                    var AbsolutePosition = this.registerBtn.parent.getAbsolutePosition();
                    var opt = {
                        text: Volt.i18n.t('TV_SID_REDEEM_CUPON'),
                        x: AbsolutePosition.x,
                        y: AbsolutePosition.y,
                        height: this.registerBtn.parent.height,
                        width: this.registerBtn.parent.width,
                        direction:'up',
                        parent:this.registerBtn.parent,
                    };
                    CommonContent.showToolTip(opt,CouponTemplate);
                }
            }
        }
    },
    
    setRigisterIcon : function(){
        Volt.log('[coupon-box-view.js] HeaderView.setRigisterIcon');

        this.registerBtn = new Button(CouponTemplate.registerBtn);
        this.registerBtn.parent = this.widget.getDescendant('coupon-header-icon-schedule');
        this.widget.getDescendant('coupon-header-icon-schedule').addEventListener('OnMouseOver',function(){
        	this.registerBtn.setFocus();
            this.registerBtn.opacity = 255;
            var AbsolutePosition = this.registerBtn.parent.getAbsolutePosition();
			var opt = {
				text: Volt.i18n.t('TV_SID_REDEEM_CUPON'),
				x: AbsolutePosition.x,
				y: AbsolutePosition.y,
				height: this.registerBtn.parent.height,
				width: this.registerBtn.parent.width,
				direction:'up',
				parent:this.registerBtn.parent,
			};
				
			CommonContent.showToolTip(opt,CouponTemplate);
        }.bind(this));

        this.widget.getDescendant('coupon-header-icon-schedule').addEventListener('OnMouseOut', function() {
			CommonContent.hideToolTip();
            //this.registerBtn.killFocus();
        }.bind(this));
                
        this.registerBtn.setBackgroundImage({state:"focused",src:"images/" + scene.height + "/highlight/4way_focus.png"});
        
        this.registerBtn.setIconAlpha({state:"normal",alpha:153});
        this.registerBtn.setIconAlpha({state:"focused",alpha:255});
        this.registerBtn.setIconScaleFactor({
            state : "focused-roll-over",
            scaleX : 1.1,
            scaleY : 1.1,
        }); 
        this.registerBtn.addListener(this.btnListener);
    },

    setBackIcon : function(){
        Volt.log('[coupon-box-view.js] HeaderView.setBackIcon');

        this.pageBackArrow = this.widget.getDescendant('coupon-box-back-icon-area');
        this.backBtn = new Button(CouponTemplate.backBtn);
        this.backBtn.parent = this.pageBackArrow;
        this.pageBackArrow.addEventListener('OnMouseOver',function(){
            this.backBtn.setFocus();
			var AbsolutePosition = this.pageBackArrow.getAbsolutePosition();
			var opt = {
				text: Volt.i18n.t('COM_SID_RETURN'),
				x: AbsolutePosition.x,
				y: AbsolutePosition.y,
				height: this.pageBackArrow.height,
				width: this.pageBackArrow.width,
				direction:'up',
				parent:this.pageBackArrow,
			};
				
			CommonContent.showToolTip(opt,CouponTemplate);
        }.bind(this));

        this.pageBackArrow.addEventListener('OnMouseOut', function() {
			CommonContent.hideToolTip();
            this.backBtn.killFocus();
        }.bind(this));
        
        this.backBtn.setBackgroundImage({
			state : "focused",
			src : "images/" + scene.height + "/highlight/4way_focus.png"
		});

        this.backBtn.setIconAlpha({state:"normal",alpha:153});
        this.backBtn.setIconAlpha({state:"focused",alpha:255});
        this.backBtn.setIconScaleFactor({
            state : "focused-roll-over",
            scaleX : 1.1,
            scaleY : 1.1,
        }); 

        this.backBtn.addListener(this.btnListener);
    }
});

var ContentView = PanelCommon.BaseView.extend({
    template : CouponTemplate.content,
    grid : null,

    render : function(parent, self) {
        Volt.log('[coupon-box-view.js] ContentView.render');
        contentViewSelf = this;
        
        if (!this.widget.created) {
            var couponList = CouponBoxModel.get("coupon_list");
            var couponData = {
                style : CommonDefine.Const.HALO_ITEM_ALL_SAME,
                groups : [{
                    modelArr : couponList
                }]
            };

            var gridView = new Gridlist(this.template, JSON.stringify(couponData), parseInt(1920 * 0.28125), parseInt(1080 * 0.866667));

            gridView.setItemData = function(mustache, modelData) {
                var isExpired = modelData['expired_flag'];
                var isUsed = modelData['used_flag'];
                var gameListCnt = parseInt(modelData['game_list_count']);
                var gameList = modelData['game_list'];
                var validDate = modelData['expired_date'];
                mustache.num = modelData['no'];

                if ('Y' === isExpired && 'Y' === isUsed) {
                    mustache.expired = Volt.i18n.t('TV_SID_EXPIRED_KR_PERIOD');
                    mustache.used = Volt.i18n.t('COM_SID_USED_KR_ING');
                } else if (isExpired == 'Y' || isUsed == 'Y') {
                    if (isExpired == 'Y')
                        mustache.expired = Volt.i18n.t('TV_SID_EXPIRED_KR_PERIOD');
                    if (isUsed == 'Y')
                        mustache.expired = Volt.i18n.t('COM_SID_USED_KR_ING');
                }
                
                var date = Utils.Date.transferNumStrToDate(validDate);
                var formatedDate = Utils.Date.getFormatedDate(date);
                Volt.log('[coupon-box-view.js] formatedDate = ' + formatedDate); 

                mustache.title = modelData['coupon_title'];
                //mustache.valid = modelData['expired_date'];
                mustache.valid = formatedDate;
                mustache.couponId = modelData['coupon_no'];
                mustache.promoMsg = modelData['promo_message'];
                mustache.message = modelData['guide_message'];
                mustache.gameListCnt = gameListCnt;
                
                Volt.log("[coupon-box-view.js] onItemPress gameNum =" + gameListCnt);

                if (gameListCnt == 1) {
                    mustache.img_url1 = gameList[0].thumbnail_url;
                } else if (gameListCnt == 2) {
                    mustache.img_url1 = gameList[0].thumbnail_url;
                    mustache.img_url2 = gameList[1].thumbnail_url;
                } else if (gameListCnt == 3) {
                    mustache.img_url1 = gameList[0].thumbnail_url;
                    mustache.img_url2 = gameList[1].thumbnail_url;
                    mustache.img_url3 = gameList[2].thumbnail_url;
                }
            };

            gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
                Volt.log("[coupon-box-view.js] setItemTemplate");
                var thumbnailObj = rendererInstance.thumbnail;
                var rootWgt = rendererInstance.root;
                
                thumbnailObj.setFoveaImageScaleFactor(0.03);
                thumbnailObj.setFoveaImageInterpolatorType(0);

                thumbnailObj.setFoveaInfoBoxScaleFactor(0.03);
                thumbnailObj.setFoveaInfoBoxInterpolatorType(0);
                thumbnailObj.dim(true);
                thumbnailObj.setDimBackgroundColor({r:0, g:0, b:0, a:255 * 0.2});
                
                /*
                if(data.title || data.promoMsg){
                    var textTmp = (data.title) ? data.title +" "+ data.promoMsg : data.promoMsg;
                    thumbnailObj.setInformationText("text1",textTmp);
                }
                */
                
                if(data.title){
                    var transformedTitle = contentViewSelf.transformHTML(data.title);
                    var temp = transformedTitle.split("\n");
                    Volt.log("[coupon-box-view.js] line 1 = " + temp[0]);
                    if(temp[0]){
                        var displayedTitle = temp[0];
                        Volt.log("[coupon-box-view.js] temp[0].length = " + temp[0].length);
                        //max length is 25 in per line
                        if(temp[0].length <= 25){
                            if (temp[1] && temp[1].length) {
                                displayedTitle += (temp[1].length > 25) ? temp[1].substring(0, 20) + "..." : "\n" + temp[1];
                            }
                        } else if(temp[0].length > 50){
                            displayedTitle = temp[0].substring(0,45) + "..."
                        }
                        
                        thumbnailObj.setInformationText("text1",displayedTitle);
                    }
                }
                
                thumbnailObj.setInformationText("text2","Valid : " + data.valid);
                Volt.log("[coupon-box-view.js] setItemTemplate data.message = " + data.message);
                if(data.message){
                    var transformedGuide = contentViewSelf.transformHTML(data.message);
                    //max length is 35 in per line
                    thumbnailObj.setInformationText("text3",transformedGuide);
                }
                if(data.promoMsg){
                    var transformedPromo = contentViewSelf.transformHTML(data.promoMsg);
                    var temp = transformedPromo.split("\n");
                    Volt.log("[coupon-box-view.js] line 1 = " + temp[0]);
                    if(temp[0]){
                        var displayedMsg = temp[0];
                        Volt.log("[coupon-box-view.js] temp[0].length = " + temp[0].length);
                        //max length is 25 in per line
                        if(temp[0].length <= 25){
                            if (temp[1] && temp[1].length) {
                                Volt.log("[coupon-box-view.js] temp[0].length = " + temp[1].length);
                                displayedMsg += (temp[1].length > 25) ? temp[1].substring(0, 20) + "..." : "\n" + temp[1];
                            }
                        } else if(temp[0].length > 50){
                            displayedMsg = temp[0].substring(0,45) + "..."
                        }
                        
                        thumbnailObj.setInformationText("text4",displayedMsg);
                    }
                    //thumbnailObj.setInformationText("text4",transformedPromo);
                }
                
                
                Volt.log("[coupon-box-view.js] setItemTemplate data.gameListCnt : " + data.gameListCnt);
                var gameCount = parseInt(data.gameListCnt);
                switch(gameCount){
                    case 1:
                        Volt.log("[coupon-box-view.js] setItemTemplate 1" );
                        thumbnailObj.setInformationIcon("icon3",data.img_url1);
                        thumbnailObj.visualizeInformationIcon(false,"icon2");
                        thumbnailObj.visualizeInformationIcon(false,"icon4");
                        break;
                    case 2:
                        Volt.log("[coupon-box-view.js] setItemTemplate 2" );
                        //adjust the x,y position for icon2 and icon3
                        thumbnailObj.setElementAllocation("information-icon2",{
                            x : 1920 * (0.028125 + 0.075/2),
                        });
                        thumbnailObj.setElementAllocation("information-icon3",{
                            x : 1920 * (0.028125 + 0.075/2 + 0.075),
                        });
                        thumbnailObj.setInformationIcon("icon2",data.img_url1);
                        thumbnailObj.setInformationIcon("icon3",data.img_url2);
                        thumbnailObj.visualizeInformationIcon(false,"icon4");
                        break;
                    case 3:
                        Volt.log("[coupon-box-view.js] setItemTemplate 3" );
                        thumbnailObj.setInformationIcon("icon2",data.img_url1);
                        thumbnailObj.setInformationIcon("icon3",data.img_url2);
                        thumbnailObj.setInformationIcon("icon4",data.img_url3);
                        break;
                    default :
                        Volt.log("[coupon-box-view.js] setItemTemplate no game list" );
                        thumbnailObj.visualizeInformationIcon(false,"icon2");
                        thumbnailObj.visualizeInformationIcon(false,"icon3");
                        thumbnailObj.visualizeInformationIcon(false,"icon4");
                        break;
                }
                
                Volt.log("[coupon-box-view.js] setItemTemplate data.expired : " + data.expired);
                Volt.log("[coupon-box-view.js] setItemTemplate data.used : " + data.used);
                var isExpired = data.expired;
                var isUsed = data.used;
                
                Volt.log("[coupon-box-view.js] setItemTemplate data.num : " + data.num);
                var currentNum = parseInt(data.num);
                
                var topRotationIconPara = {
                    //expired pic
                    x : 1920 * 0.077604,
                    y : 1080 * 0.163889,
                    width : 240,
                    height : 121,
                    src : Volt.BASE_PATH + "images/" + scene.height + "/g_coupon_outline.png",
                    async : true,
                };

                var belowRotationIconPara = {
                    x : 1920 * 0.077604,
                    y : 1080 * 0.265741,
                    width : 240,
                    height : 121,
                    src : Volt.BASE_PATH + "images/" + scene.height + "/g_coupon_outline.png",
                    async : true,
                };
                
                if(isExpired != undefined && isUsed != undefined){
                    //expired and used
                    Volt.log("[coupon-box-view.js] setItemTemplate expired and used" );
                    contentViewSelf.onColorPicker(rendererInstance, 1);
                    
                    if (currentNum % 2 == 0) {
                        contentViewSelf.createDim(rootWgt, parentWidth, parentHeight, 255 * 0.1);
                    }
                    
                    thumbnailObj.addThumbnailInformationIcons({icon5:topRotationIconPara});
                    thumbnailObj.addThumbnailInformationIcons({icon6:belowRotationIconPara});
                    
                    contentViewSelf.createTopRotationTextWidget(thumbnailObj,parentWidth, parentHeight,data.expired);
                    contentViewSelf.createBelowRotationTextWidget(thumbnailObj,parentWidth, parentHeight);
                    
                    contentViewSelf.updateTextOpacity(thumbnailObj);
                    
                } else if (isExpired != undefined || isUsed != undefined){
                    //expired or used
                    Volt.log("[coupon-box-view.js] setItemTemplate expired or used" );
                    contentViewSelf.onColorPicker(rendererInstance, 1);
                    if(currentNum%2 == 0){
                        contentViewSelf.createDim(rootWgt,parentWidth, parentHeight,255 * 0.1);
                    }
                    
                    thumbnailObj.addThumbnailInformationIcons({icon5:topRotationIconPara});
                    contentViewSelf.createTopRotationTextWidget(thumbnailObj,parentWidth, parentHeight,data.expired);
                    contentViewSelf.updateTextOpacity(thumbnailObj);
                } else {
                    //not expired and not used
                    Volt.log("[coupon-box-view.js] setItemTemplate not expired and not used" );
                    contentViewSelf.onColorPicker(rendererInstance, 0);
                    if(currentNum%2 == 0){
                        contentViewSelf.createDim(rootWgt,parentWidth, parentHeight,255 * 0.1);
                    }
                }
            };

            gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
                Volt.log("[coupon-box-view.js] onItemPress itemIndex =" + itemIndex);
                var couponId = itemData.couponId;
                var expiredFlag = CouponBoxModel.get("coupon_list").at(itemIndex).get('expired_flag');
                var used = CouponBoxModel.get("coupon_list").at(itemIndex).get('used_flag');
                var gameNum = parseInt(CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list_count'));
                Volt.log("[coupon-box-view.js] onItemPress gameNum =" + gameNum);
				var spValue  = 'CC' + Volt.KPIMapper.getIndexFormat(itemIndex + 1);
				var eventName = '';
				
                if ('Y' == expiredFlag) {
					addEventLog('COUPONERROR',{
								cp : 'G07_COUPON',
				                sp:spValue,
				                content:'coupon' + '|' + couponId,
				                status:'expired',
				                inputby:'',
				   });
				
				   ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_EXPIRED);
                } else if ('Y' == used) {
                	addEventLog('COUPONERROR',{
								cp : 'G07_COUPON',
				                sp:spValue,
				                content:'coupon' + '|' + couponId,
				                status:'used',
				                inputby:'',
				   });

				   ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_COUPON_USED);
                } else if (1 == gameNum) {
                    //games is installed?
                    var appId = CouponBoxModel.get("coupon_list").at(itemIndex).get('game_list')[0].app_id;
                    Volt.log("[coupon-box-view.js] onItemPress appId =" + appId);
                    var installed = VoltApiWrapper.isWidgetInstalled(appId);
                    var installedPath = VoltApiWrapper.getInstalledPath(appId);
                    Volt.log("[coupon-box-view.js] onItemPress installed =" + installed);
                    Volt.log("[coupon-box-view.js] onItemPress installedPath =" + installedPath);
                    if (installed && installedPath) {
                        //run this game
                        eventName = 'EXEGAME';
                        VoltApiWrapper.launchApp(appId);
                    } else {
                        eventName = 'VIEWGAME';
                        Volt.log("[coupon-box-view.js] onItemPress view detail -- 1");
						self.backFromDetail = true;
                        Volt.KPIAppId = appId;
                        Backbone.history.navigate('detail/' + appId, {
                            trigger : true
                        });
                    }
					addEventLog(eventName,{
								cp : 'G07_COUPON',
				                appid : appId,
				                sp:spValue,
				                content:'coupon' + '|' + couponId,
				                inputby:'',
				   });
                } else if(gameNum > 1) {
                    var couponNo = CouponBoxModel.get("coupon_list").at(itemIndex).get('coupon_no');
                    var params = {
                        "couponNo" : couponNo,
                        "index" : itemIndex,
                        "type" : 'select-games'
                    };

					 addEventLog('POPCGAMES',{
								cp : 'G07_COUPON',
				                content:'coupon' + '|' + couponId,
				                inputby:'',
				    });
                    self.isBackFromPopup = true;
                    Backbone.history.navigate('popup/' + JSON.stringify(params), {
                        trigger : true
                    });
                } else {
                    Volt.log('[coupon-box-view.js] no games in this coupon');
                }
            };
            
            gridView.itemLoaded = function(gridList, groupIndex, itemIndex) {
                Volt.log("[coupon-box-view.js] itemLoaded  ");
                Volt.log("[coupon-box-view.js] itemLoaded  groupIndex: " + groupIndex + ",itemIndex: " + itemIndex);
                var data = gridList.getData(groupIndex, itemIndex);
                data.group = groupIndex;
                data.item = itemIndex;
            };
            
            gridView.itemUnloaded = function(gridList, groupIndex, itemIndex) {
                
            };

			gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
                Volt.log('[coupon-box-view.js] gridView.focusChanged fromItemIndex = ' + fromItemIndex + ',,,toItemIndex = ' + toItemIndex + ',,,toGroupIndex= ' + toGroupIndex);
                
                // update title position when enlarger is on
                if(HALOUtil.enlarge){
                    if (toItemIndex >= 0 && toGroupIndex >= 0) {
                        var renderer = this.widget.renderer(toGroupIndex, toItemIndex);
                        if (renderer && renderer.thumbnail) {
                            var focusedThumbnail = renderer.thumbnail;
                            focusedThumbnail.setElementAllocation("information-text1", {
                                height : 1080 * 0.042593 * 2 + 20,
                            });
                        }
                    }
                }

                if (toItemIndex >= 0 && toGroupIndex >= 0) {
                    var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
                    var voiceGuide = data.title;

                    if (data.expired != undefined) {
                        voiceGuide += ',' + Volt.i18n.t('TEXT_EXPIRED_P') + '.';
                        VoiceGuide.getVoiceGuide(voiceGuide);
                        return;
                    }

                    if (data.used != undefined) {
                        voiceGuide += ',' + Volt.i18n.t('COM_SID_USED_KR_ING') + '.';
                        VoiceGuide.getVoiceGuide(voiceGuide);
                        return;
                    }

                    var voiceText = '';
                    if (-1 == fromItemIndex) {
                        voiceText += Volt.i18n.t('TV_SID_COUPONS') + ',' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', CouponBoxModel.get('coupon_list_cnt')) + ',';
                    }

                    voiceText += data.title + ',' + data.message + ',' + Volt.i18n.t('TV_SID_SELECTING_A_COUPON_WILL_TAKE_YOU_TO_THE_GAME');
                    var coupon = CouponBoxModel.get("coupon_list").at(toItemIndex);
                    var gameTitle = '';
                    for ( i = 0; i < parseInt(data.gameListCnt); i++) {
                        gameTitle += ',' + coupon.get('game_list')[i].game_title;
                    }

                    voiceText += gameTitle + '.';
                    VoiceGuide.getVoiceGuide(voiceText);
                }

			};
			
            gridView.disableLongPress();
            this.grid = gridView.render().widget;
            this.grid.focusable = true;
            this.setWidget(this.grid);
            this.widget.created = true;
        }
        return this;
    },
    
    transformHTML : function(str){
        Volt.log("[coupon-box-view.js] transformHTML str =" + str);
        var transformedStr = str;
        if (transformedStr) {
            transformedStr = transformedStr.replace(/\n\s+/g, '\n');
            transformedStr = transformedStr.replace(/\n/g, '\n');
            //match
            transformedStr = transformedStr.replace(/\\n/g, '\n');
            transformedStr = transformedStr.replace(/\t/g, '\n');
            //match<br />
            transformedStr = transformedStr.replace(/<br\s*\/?>/gim, '\n');
            //match<p>
            transformedStr = transformedStr.replace(/<p\s*>/gim, '');
            //matach</p>
            transformedStr = transformedStr.replace(/<\/p>/gim, '');
        }

        return transformedStr;
    },
    
    onColorPicker : function(parent, flag) {
        Volt.log("[coupon-box-view.js] onColorPicker flag =" + flag);
        switch(flag) {
            case 0:
                //no expired and no used
                parent.root.color = {
                    r : couponViewSelf.bgColor.r,
                    g : couponViewSelf.bgColor.g,
                    b : couponViewSelf.bgColor.b
                };
                break;
            case 1:
                //expired/used
                parent.root.color = Volt.hexToRgb('#52565d');
                break;
            default:
                break;
        }

        var fontColor = CommonContent.onColorPickerForPopupOrText(parent.root.color);

        Volt.log("[coupon-box-view.js] onColorPicker:fontColor r:" + fontColor.r + ",g:" + fontColor.g + ",b:" + fontColor.b);
        var thumbnailObj = parent.thumbnail;

        thumbnailObj.setInformationTextColor("text1", {
            r : fontColor.r,
            g : fontColor.g,
            b : fontColor.b,
        });
        thumbnailObj.setInformationTextColor("text2", {
            r : fontColor.r,
            g : fontColor.g,
            b : fontColor.b,
        });
        thumbnailObj.setInformationTextColor("text3", {
            r : fontColor.r,
            g : fontColor.g,
            b : fontColor.b,
        });
        thumbnailObj.setInformationTextColor("text4", {
            r : fontColor.r,
            g : fontColor.g,
            b : fontColor.b,
        });
    }, 
    
    createTopRotationTextWidget : function(thumbnailObj,parentWidth, parentHeight,textStr) {
        Volt.log("[coupon-box-view.js] createTopRotationTextWidget textStr =" + textStr);
        var textPara = {
            x : 1920 * 0.077604,
            y : 1080 * 0.163889,
            width : 240,
            height : 121,
            font : "SamsungSmart_Light 32px",
            text : textStr,
            singleLineMode : false,
            horizontalAlignment : "center",
            rotation : {
                x : 0,
                y : 0,
                z : -15
            },
            textColor : {
                r : 255,
                g : 255,
                b : 255,
                a : 255
            },
        }; 
        
        thumbnailObj.addThumbnailInformationTexts({text5:textPara});
    }, 
    
    createBelowRotationTextWidget : function(thumbnailObj,parentWidth, parentHeight) {
        Volt.log("[coupon-box-view.js] createBelowRotationTextWidget ");
        var textPara = {
            x : 1920 * 0.077604,
            y : 1080 * 0.265741,
            width : 240,
            height : 121,
            font : "SamsungSmart_Light 32px",
            text : Volt.i18n.t('COM_SID_USED_KR_ING'),
            singleLineMode : false,
            horizontalAlignment : "center",
            rotation : {
                x : 0,
                y : 0,
                z : -15
            },
            textColor : {
                r : 255,
                g : 255,
                b : 255,
                a : 255
            },
        }; 
        
        thumbnailObj.addThumbnailInformationTexts({text6:textPara});
    }, 
    
    updateTextOpacity : function(thumbnailObj) {
        thumbnailObj.setElementOpacity("information-text1", 255 * 0.2);
        thumbnailObj.setElementOpacity("information-text2", 255 * 0.2);
        thumbnailObj.setElementOpacity("information-text3", 255 * 0.2);
        thumbnailObj.setElementOpacity("information-text4", 255 * 0.07);
        thumbnailObj.setElementOpacity("information-icon2", 255 * 0.07);
        thumbnailObj.setElementOpacity("information-icon3", 255 * 0.07);
        thumbnailObj.setElementOpacity("information-icon4", 255 * 0.07);
    }, 
    
    createDim : function(thumbnailObj,parentWidth, parentHeight,alpa) {
        Volt.log("[coupon-box-view.js] createDim");
        var dimWgt = new WidgetEx({
            parent : thumbnailObj,
            x : 0,
            y : 0,
            width : parentWidth,
            height : parentHeight,
            color : {
                r : 0,
                g : 0,
                b : 0,
                a : alpa
            },
        });
    },
    
    events : {
        //'NAV_SELECT':'onSelect',
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onSelect : function() {
    },

    onFocus : function(widget) {
        Volt.log('[coupon-box-view.js] ContentView.onFocus widget ='+ widget);
        if(!widget){
            widget = this.widget;
        }
            
        if (this.grid) {
            widget = this.grid;
            Volt.Nav.focus(this.grid);
            widget.onFocus();
        }
    },

    onBlur : function(widget) {
        Volt.log('[coupon-box-view.js] ContentView.onBlur');
        if (CouponBoxModel.get('coupon_list_cnt') != 0) {
            if (widget) {
                if (this.grid) {
                    this.grid.onBlur();
                }
            }
        }
    },

    destroy : function() {
        Volt.log('[coupon-box-view.js] ContentView.destroy');
        if(this.grid){
            this.grid.destroy();
        }
    }
});

var addEventLog = function(eventName,options){
	Volt.log('[coupon-box-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
	//add Event log
	if(!eventName){
		return;
	}
    Volt.KPIMapper.addEventLog(eventName, {d : options});
};
exports = CouponBoxView; 