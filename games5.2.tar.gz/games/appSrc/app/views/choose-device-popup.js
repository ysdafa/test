// Include libraries
var _                 = Volt.requireNoContext("modules/underscore.js")._;
var Q                = Volt.requireNoContext('modules/q.js');
var Backbone         = Volt.requireNoContext('lib/volt-backbone.js');
var PanelCommon      = Volt.requireNoContext('lib/panel-common.js');
var CommonDefine     = Volt.requireNoContext('app/common/common-define.js');
var Mediator    = Volt.requireNoContext('app/common/event-mediator.js');
var voltApiWrapper   = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var CommonContent    = Volt.requireNoContext('app/common/common-content.js');
var ChooseDevicesTemplate = Volt.requireNoContext('app/templates/1080/choose-devices-popup.js');
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');
var DeviceModel = Volt.requireNoContext('app/models/device-model.js');
var dimView = Volt.requireNoContext('app/views/dim-view.js');

var TempUsbStorages = new Array();
var APP_ID = null;
var APP_SIZE = null;
var APP_NAME = null;
var lastFocus = null;
var chooseDevicePopupSelf = null;
var popupSelectedDeviceView = null;
var popupDevicesView = null;
var popupBtnView = null;

var ChooseDevicePopup = PanelCommon.BaseView.extend({
    template : ChooseDevicesTemplate.container,
    
    isActive : false,
    dimExist : false,

    render : function(){
    },

    getWidget : function(){
        return this.widget;
    },

    show : function(params){
        Volt.log('[choose-device-popup.js] show ' + params);
        var param = JSON.parse(params);
        APP_ID = param.app_id;
        APP_SIZE = param.app_size;
        APP_NAME = param.app_name;
        Mediator.trigger('EVENT_SHOW_CHOOSE_DEVICE_POPUP');
        this.winsetBackgroud = CommonContent.loadTemplateInWinsetBackgroud(this.template);
        this.setWidget(this.winsetBackgroud.getChild(0));
        this.winsetBackgroud.show();
        chooseDevicePopupSelf = this;
        this.renderSelectedDevice();
        this.renderDevices();
        this.renderButton();
        this.startListening();
        this.isActive = true;
        Volt.Nav.setRoot(this.widget, {
            focus : null
        });
        this.setSublistFocusable(true);
        Volt.Nav.focus(popupDevicesView.widget);
    },
    
    setSublistFocusable : function(focusable){
        if(focusable) {
            popupDevicesView.widget.focusable = true;
            Volt.Nav.reload();
            Volt.Nav.setNextItemRule(popupDevicesView.widget, 'left', popupDevicesView.widget);
            Volt.Nav.setNextItemRule(popupDevicesView.widget, 'right', popupBtnView.widget.getDescendant('Cancel'));
            Volt.Nav.setNextItemRule(popupBtnView.widget.getDescendant('Cancel'), 'left', popupDevicesView.widget);
            Volt.Nav.setNextItemRule(popupBtnView.widget.getDescendant('Cancel'), 'right', popupBtnView.widget.getDescendant('Cancel'));
        } else {
            Volt.log('[choose-device-popup.js]  popupDevicesView.widget setFocus');
            if(popupDevicesView&&popupDevicesView.widget){
                Volt.log('[choose-device-popup.js]  popupDevicesView.widget can not focus');
                popupDevicesView.widget.focusable = false;
                Volt.Nav.reload();
                Volt.Nav.setNextItemRule(popupBtnView.widget.getDescendant('Cancel'), 'left', popupBtnView.widget.getDescendant('Cancel'));
                Volt.Nav.setNextItemRule(popupBtnView.widget.getDescendant('Cancel'), 'right', popupBtnView.widget.getDescendant('Cancel'));
            }
           
        }
    },

    renderSelectedDevice : function(){
        var container = this.widget.getChild('selected-device-container');
        new selectedDeviceView().render(container);
    },

    renderDevices : function(){
        Volt.log('[choose-device-popup.js] renderDevices');
        var container = this.widget.getChild('devices-container');
        new DevicesView(container).render();
    },

    renderButton : function(){
        Volt.log('[choose-device-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        container.addChild(new buttonView().render().widget);
    },

    hide : function(){
        Volt.log('[choose-device-popup.js] hide');
        var deferred = Q.defer();
        
        this.stopListening();
        this.reset();
        this.destroy();
        Mediator.trigger('EVENT_HIDE_CHOOSE_DEVICE_POPUP');
        
        deferred.resolve();
        return deferred.promise;
    },

    reset : function(){
        if(popupDevicesView&&popupDevicesView.widget){
            popupDevicesView.widget.enable(false);
        }
        Volt.Nav.focus(null);
        Volt.Nav.reset();
        this.isActive = false;
        lastFocus = null;
        APP_ID = null;
        APP_SIZE = null;
        APP_NAME = null;
        this.dimExist = false;
        TempUsbStorages.length = 0;
        chooseDevicePopupSelf = null;
    },

    destroy : function(){
        Volt.log('[choose-device-popup.js] destroy~~~~~');
        if(this.winsetBackgroud){
            this.winsetBackgroud.hide();
            if(popupSelectedDeviceView){
                popupSelectedDeviceView.destroy();
            }
            if(popupDevicesView){
                popupDevicesView.destroy();
            }
            if(popupBtnView){
                popupBtnView.destroy();
            }
            this.winsetBackgroud.destroyChildren();
            this.winsetBackgroud.destroy();
            this.winsetBackgroud = null;
            popupSelectedDeviceView = null;
            popupDevicesView = null;
            popupBtnView = null;
        }
    },

    startListening : function(){
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE, this.active, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
        Mediator.on(CommonDefine.Event.USB_CONNECT, this.connectUSB, this);
        Mediator.on(CommonDefine.Event.USB_DISCONNECT, this.disconnectUSB, this);
        Mediator.on(CommonDefine.Event.CHANGE_HIGH_CONTRAST, this.changeHighContrast,  this);
        Mediator.on(CommonDefine.Event.CHANGE_FOCUS_ZOOM, this.changeFocusZoom,  this);
    },

    stopListening : function(){
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, this);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, this);
        Mediator.off(CommonDefine.Event.USB_CONNECT,null, this);
        Mediator.off(CommonDefine.Event.USB_DISCONNECT,null, this);
        Mediator.off(CommonDefine.Event.CHANGE_HIGH_CONTRAST, null, this);
        Mediator.off(CommonDefine.Event.CHANGE_FOCUS_ZOOM, null, this);
    },

    active : function(){
        Volt.log('[choose-device-popup.js] active');
        this.isActive = true;
        if(this.dimExist){
            dimView.hide();
        }
       
        Volt.Nav.setRoot(this.widget, {
            focus : lastFocus
        });
    },

    deactive : function(){
        Volt.log('[choose-device-popup.js] deactive');
        this.isActive = false;
        Volt.Nav.blur();
        if(dimView.isDimExist()){
            return;
        }
        dimView.show({
            parent : scene
        });
        this.dimExist = true;
    },
    /*
    pause:function(){
      this.deactive();  
    },
    
    resume : function(){
        dimView.hide();
        this.active();
    },
    */
    onKeyEvent : function(keyCode, keyType){
        if(keyType == Volt.EVENT_KEY_RELEASE){
            return false;
        }
        switch(keyCode){
            case Volt.KEY_RETURN: {
                Volt.log("[choose-device-popup.js] @@@Return key");
                //chooseDevicePopupSelf.hide();
                Backbone.history.back();
                return true;
            }
        }
        return false;
    },

    connectUSB : function(data){
        Volt.log("[choose-device-popup.js] connectUSB - " + data);
        try{
            var storage = data[0].storage;
            Volt.log("[choose-device-popup.js] connectUSB - mountPath = " + storage.mountPath);
            if(popupDevicesView){ //TODO :There may use comment code when function addItemByIndex and deleteItem of sublist become Stability
/*                if(popupDevicesView.widget.addItemByIndex){
                    Volt.log("[choose-device-popup.js] connectUSB - TempUsbStorages.length = " + TempUsbStorages.length);
                    Volt.log("[choose-device-popup.js] connectUSB - sublist.length = " + popupDevicesView.widget.numofItem());
                    var i = TempUsbStorages.length;
                    Volt.log("[choose-device-popup.js] connectUSB - addItemIndex = " + i);
                    var totalSizeWithUnit = voltApiWrapper.setSuitablyUnit(storage.totalSize);
                    var availableSizeWithUnit = voltApiWrapper.setSuitablyUnit(storage.availableSize);
                    Volt.log("TempUsbStorages = " + JSON.stringify(TempUsbStorages));
                    TempUsbStorages[i] = {};
                    TempUsbStorages[i].name = storage.name;
                    TempUsbStorages[i].mountPath = storage.mountPath;
                    TempUsbStorages[i].fileSystem = storage.fileSystem;
                    TempUsbStorages[i].totalSize = totalSizeWithUnit.size + totalSizeWithUnit.unit;
                    TempUsbStorages[i].availableSize = availableSizeWithUnit.size + availableSizeWithUnit.unit;
                    if(!(availableSizeWithUnit.unit == 'GB' || (availableSizeWithUnit.unit == 'MB' && parseFloat(APP_SIZE) <= availableSizeWithUnit.size))){
                        TempUsbStorages[i].isDim = false;
                    }
                    Volt.log("TempUsbStorages = " + JSON.stringify(TempUsbStorages));
                    Volt.log("[choose-device-popup.js] connectUSB - TempUsbStorages.length = " + TempUsbStorages.length);
                    var deviceInfo = getDeviceInfo(i);
                    deviceInfo.index = i;
                    deviceInfo.text.itemTextString = TempUsbStorages[i].name;
                    deviceInfo.text2.itemTextString = TempUsbStorages[i].totalSize + ' ' + TempUsbStorages[i].fileSystem;

                    var chooseArea = ChooseDevicesTemplate.chooseArea;
                    var itemProperty = chooseArea.itemProperty;
                    itemProperty.itemNum = TempUsbStorages.length;

                    Volt.log("[choose-device-popup.js] connectUSB - sublist.length = " + popupDevicesView.widget.numofItem());

                    deviceInfo.itemSpace = 1080 * 0.066667;
                    popupDevicesView.widget.addItemByIndex(deviceInfo);
                    deviceInfo.itemSpace = undefined;

                    if(popupDevicesView.widget.numofItem() == 1){
                        chooseDevicePopupSelf.setSublistFocusable(true);
                        if(chooseDevicePopupSelf.isActive){
                            Volt.Nav.focus(popupDevicesView.widget);
                        }else{
                            lastFocus = popupDevicesView.widget;
                        }
                    }
                }else */
                if(TempUsbStorages.length == 0){
                    popupDevicesView.render(0);
                    chooseDevicePopupSelf.setSublistFocusable(true);
                    if(chooseDevicePopupSelf.isActive){
                        Volt.Nav.focus(popupDevicesView.widget);
                    }else{
                        lastFocus = popupDevicesView.widget;
                    }
                }else{
                    var lastFocusItemIndex = popupDevicesView.widget.focusItemIndex;
                    popupDevicesView.destroy();
                    popupDevicesView.render(lastFocusItemIndex);
                    chooseDevicePopupSelf.setSublistFocusable(true);
                    if(chooseDevicePopupSelf.isActive){
                        Volt.Nav.focus(popupDevicesView.widget);
                    }else{
                        lastFocus = popupDevicesView.widget;
                    }
                }
            }
        }catch (e){
            Volt.log('[choose-device-popup.js] connectUSB error = ' + e);
        }
    },

    disconnectUSB : function(data){
        Volt.log('[choose-device-popup.js] disconnectUSB - ' + data);
        try{
            var storage = data[0].storage;
            Volt.log("[choose-device-popup.js] disconnectUSB - mountPath = " + storage.mountPath);
            if(popupDevicesView){ //TODO :There may use comment code when function addItemByIndex and deleteItem of sublist become Stability
/*                if(popupDevicesView.widget.addItemByIndex){
                    var deleteItemIndex = -1;
                    var maxIndex = TempUsbStorages.length - 1;
                    for( var i = 0; i <= maxIndex; i++){
                        if(TempUsbStorages[i].mountPath == storage.mountPath){
                            deleteItemIndex = i;
                        }
                    }
                    if(deleteItemIndex >= 0){
                        Volt.log("[choose-device-popup.js] disconnectUSB - TempUsbStorages.length = " + TempUsbStorages.length);
                        Volt.log("[choose-device-popup.js] disconnectUSB - sublist.length = " + popupDevicesView.widget.numofItem());
                        Volt.log("[choose-device-popup.js] disconnectUSB - removeItemIndex = " + deleteItemIndex);
                        Volt.log("TempUsbStorages = " + JSON.stringify(TempUsbStorages));
                        TempUsbStorages.splice(deleteItemIndex, 1);
                        Volt.log("TempUsbStorages = " + JSON.stringify(TempUsbStorages));
                        popupDevicesView.widget.deleteItem({
                            fromItem : deleteItemIndex,
                            itemNum : 1
                        });
                        popupDevicesView.widget.updateAllItems();
                        Volt.log("[choose-device-popup.js] disconnectUSB - TempUsbStorages.length = " + TempUsbStorages.length);
                        Volt.log("[choose-device-popup.js] disconnectUSB - sublist.length = " + popupDevicesView.widget.numofItem());
                        var maxIndex = popupDevicesView.widget.numofItem() - 1;
                        getDeviceInfo();
                        for( var i = deleteItemIndex; i <= maxIndex; i++){
                            Volt.log("[choose-device-popup.js] disconnectUSB updateItem " + i);
                            var deviceInfo = getDeviceInfo(i, false);
                            deviceInfo.index = i;
                            deviceInfo.text.itemTextString = TempUsbStorages[i].name;
                            deviceInfo.text2.itemTextString = TempUsbStorages[i].totalSize + ' ' + TempUsbStorages[i].fileSystem;
                            popupDevicesView.widget.updateItem(deviceInfo);
                        }
                        if(maxIndex >= 0){
                            if(deleteItemIndex >= maxIndex) {
                                popupDevicesView.widget.focusItemIndex = maxIndex;
                            }
                        }else{
                            chooseDevicePopupSelf.setSublistFocusable(false);
                            var params = {
                                name : "",
                                availableSize : "",
                                totalSize : "",
                                fileSystem : ""
                            };
                            popupSelectedDeviceView.updateInfo(params);
                            if(chooseDevicePopupSelf.isActive){
                                Volt.Nav.focus(popupBtnView.widget.getDescendant('Cancel'));
                            }else{
                                lastFocus = popupBtnView.btn1;
                            }
                        }
                    }
                }else*/
                {
                   // var maxIndex = TempUsbStorages.length - 1;
                    var maxIndex = voltApiWrapper.getUsbStorages().storages.length;
                    Volt.log("[choose-device-popup.js] disconnectUSB - current USB number = " + maxIndex);
                    if(maxIndex <= 0){
                        chooseDevicePopupSelf.setSublistFocusable(false);
                        popupDevicesView.destroy();
                        var params = {
                            name : "",
                            availableSize : "",
                            totalSize : "",
                            fileSystem : ""
                        };
                        popupSelectedDeviceView.updateInfo(params);
                        TempUsbStorages.length = 0;
                        if(chooseDevicePopupSelf.isActive){
                            Volt.log("[choose-device-popup.js] disconnectUSB, no usb,should hide this popup. ");
                            popupBtnView.onSelectCancelButton();
                            //Volt.Nav.focus(popupBtnView.widget.getDescendant('Cancel'));
                        }else{
                            lastFocus = popupBtnView.btn1;
                        }
                    }else{
                        var lastFocusItemIndex = popupDevicesView.widget.focusItemIndex;
                        popupDevicesView.destroy();
                        popupDevicesView.render(lastFocusItemIndex);
                        chooseDevicePopupSelf.setSublistFocusable(true);
                        if(chooseDevicePopupSelf.isActive){
                            Volt.Nav.focus(popupDevicesView.widget);
                        }else{
                            lastFocus = popupDevicesView.widget;
                        }
                    }
                }
            }
        }catch (e){
            Volt.log('[choose-device-popup.js] disconnectUSB error = ' + e);
        }
    },
    
    changeHighContrast : function(flagHighContrast){
        Volt.log("[choose-device-popup.js] changeHighContrast " + flagHighContrast);
        if(popupDevicesView && popupDevicesView.widget) {
            var numofItem = popupDevicesView.widget.numofItem();
            getDeviceInfo();
            for( var i = 0; i < numofItem; i++){
                Volt.log("[choose-device-popup.js] updateItem " + i);
                var deviceInfo = getDeviceInfo(i, false);
                deviceInfo.index = i;
                deviceInfo.text.itemTextString = TempUsbStorages[i].name;
                deviceInfo.text2.itemTextString = TempUsbStorages[i].totalSize + ' ' + TempUsbStorages[i].fileSystem;
                popupDevicesView.widget.updateItem(deviceInfo);
            }
        }
    },
    
    changeFocusZoom : function(enlarge){
        Volt.log("[choose-device-popup.js] changeFocusZoom " + enlarge);
        if(popupDevicesView && popupDevicesView.widget) {
            var numofItem = popupDevicesView.widget.numofItem();
            getDeviceInfo();
            for( var i = 0; i < numofItem; i++){
                Volt.log("[choose-device-popup.js] updateItem " + i);
                var deviceInfo = getDeviceInfo(i, false);
                deviceInfo.index = i;
                deviceInfo.text.itemTextString = TempUsbStorages[i].name;
                deviceInfo.text2.itemTextString = TempUsbStorages[i].totalSize + ' ' + TempUsbStorages[i].fileSystem;
                popupDevicesView.widget.updateItem(deviceInfo);
            }
        }
    }
});

//template of description area
var selectedDeviceView = PanelCommon.BaseView.extend({

    render : function(container){
        popupSelectedDeviceView = this;
        this.setWidget(container);
        return this;
    },

    updateInfo : function(params){
        Volt.log('[choose-device-popup.js] selectedDeviceView updateInfo.....');

        if(params){
            var deviceNameWidget = this.widget.getChild("device-name");
            var memoryInfoWidget = this.widget.getChild("device-memory");

            deviceNameWidget.text = params.name;
            if(params.availableSize != "" && params.totalSize != ""){
                memoryInfoWidget.text = params.availableSize + "/" + params.totalSize;
            } else {
                memoryInfoWidget.text = "";
            }
        }
    },

    destroy : function(){
        Volt.log('[choose-device-popup.js] selectedDeviceView destroy');
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

var DevicesView = PanelCommon.BaseView.extend({

    initialize : function(container){
        this.parent = container;
    },

    render : function(lastFocusItemIndex){
        popupDevicesView = this;
        this.widget = initList(this.parent);
        if(lastFocusItemIndex) {
            
            if(this.widget.numofItem() >= lastFocusItemIndex +1){
                this.widget.focusItemIndex = lastFocusItemIndex;
            }else{
                this.widget.focusItemIndex = 0;
            }
            
        } else {
            this.widget.focusItemIndex = 0;
        }
        this.setWidget(this.widget);
        return this;
    },

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    onFocus : function(widget){
        Volt.log('[choose-device-popup.js] DevicesView.focus ');
        lastFocus = this.widget;
        if(this.widget){
            this.widget.enableFocus();
            this.widget.setFocus();
            this.widget.showFocus("false");
        }
    },

    onBlur : function(widget){
        if(this.widget){
            Volt.log('[choose-device-popup.js] DevicesView.onBlur ');
            this.widget.hideFocus("false");
            this.widget.killFocus();
        }
    },

    destroy : function(){
        Volt.log('[choose-device-popup.js] DevicesView destroy');
        if(this.widget){
            this.widget.hide();
            if(this.widget.scroll){   
            this.widget.scroll.destroy();
            this.widget.scroll = null;
            }
            this.widget.destroy();
            this.widget = null;
        }
    }
});

//template of button area
var buttonView = PanelCommon.BaseView.extend({
    template : ChooseDevicesTemplate.button,
    btn1 : null,
    btnListener : new ButtonListener(),
    render : function(Parent){
        Volt.log('[choose-device-popup.js] buttonView.render');
        popupBtnView = this;
        popupBtnView.btnListener.onButtonClicked = function(button, type){
            popupBtnView.onSelectCancelButton();
        };
        var btnStyle = {
            style : CommonDefine.Winset.Button_image_O_Style_F,
            buttonType : CommonDefine.Winset.BUTTON_TEXT,
        };
        this.setWidget(PanelCommon.loadTemplate(this.template, btnStyle));
        this.btn1 = this.widget.getDescendant('cancelBtn');
        this.btn1.addListener(popupBtnView.btnListener);
        return this;
    },

    events : {
        'NAV_FOCUS #Cancel' : 'onFocusCancelButton',
        'NAV_BLUR #Cancel' : 'onBlurCancelBtn',
    },

    onSelectCancelButton : function(widget){
        Volt.log('[choose-device-popup.js] buttonView.onSelectCancelButton');
        //chooseDevicePopupSelf.hide();
        Backbone.history.back();
    },

    onFocusCancelButton : function(widget){
        Volt.log('[choose-device-popup.js] buttonView.onFocusCancelButton');
        var voiceGuide = Volt.i18n.t('COM_SID_CANCEL') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        getVoiceGuide(voiceGuide);
        this.btn1.setFocus();
    },

    onBlurCancelBtn : function(widget){
        Volt.log('[choose-device-popup.js] buttonView.onBlurCancelBtn');
        this.btn1.killFocus();
    },

    destroy : function(){
        Volt.log('[choose-device-popup.js] buttonView destroy');
        if(this.btn1){
            this.btn1.removeListener(this.btnListener);
            this.btn1.destroy();
            this.btnListener.destroy();
            this.btn1 = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

function renderScroll(parent,maxValue) {
        var scrollHeight = Math.ceil(1080 * 0.066667 * 5);
        var scrollParams = {
            style : CommonDefine.Winset.SCROLL_VERTICAL,
            parent : parent,
            x : Volt.sceneWidth * 0.199479+Volt.sceneWidth * 0.423958+10,
            y : 1080 * (0.139815 + 0.044444 + 0.018519 + 0.080556),
            width : 5,
            height : scrollHeight,
            active : false
        };
        verticalScroll = CommonContent.createScroll(scrollParams);
        verticalScroll.setMinCurMaxValue(1, 1, maxValue);
        return verticalScroll;
}

function initList(parent){
    var chooseArea = ChooseDevicesTemplate.chooseArea;
    var sublistProperty = chooseArea.subListProperty;
    sublistProperty.parent = parent;
    var list = new SubList(sublistProperty);
    list.setFirstLayerBGColor({
        firstLayerBGColor : Volt.hexToRgb('#000000', 0)
    });
    list.setSecondLayerBGColor({
        secondLayerBGColor : Volt.hexToRgb('#000000', 0)
    });
    list.setThirdLayerBGBorderColor({
        thirdLayerBGBorderColor : Volt.hexToRgb('#000000', 0)
    });
    list.setSingleLineListPosition(chooseArea.singleLineListPosition);

    var storages = voltApiWrapper.getUsbStorages().storages;
    Volt.log('[choose-device-popup.js] storages.length - ' + storages.length);
    var itemTotalNum = storages.length;
    var itemProperty = chooseArea.itemProperty;
    itemProperty.itemNum = itemTotalNum;
    var testMaxNum = itemTotalNum;
    itemProperty.itemNum = Math.max(itemTotalNum, testMaxNum);
    list.addItem(itemProperty);
    if(itemTotalNum >= 5){
        // "5" is the default max number showing on the screen
        list.scroll = renderScroll(list,itemTotalNum);
    }
    
    TempUsbStorages.length = 0;
    getDeviceInfo();
    for( var i = 0; i < itemTotalNum; i++){
        var totalSizeWithUnit = voltApiWrapper.setSuitablyUnit(storages[i].totalSize);
        var availableSizeWithUnit = voltApiWrapper.setSuitablyUnit(storages[i].availableSize);
        TempUsbStorages[i] = {};
        TempUsbStorages[i].name = storages[i].name;
        TempUsbStorages[i].mountPath = storages[i].mountPath;
        TempUsbStorages[i].fileSystem = storages[i].fileSystem;
        TempUsbStorages[i].totalSize = totalSizeWithUnit.size + totalSizeWithUnit.unit;
        TempUsbStorages[i].availableSize = availableSizeWithUnit.size + availableSizeWithUnit.unit;
        if(!(availableSizeWithUnit.unit == 'GB' || (availableSizeWithUnit.unit == 'MB' && parseFloat(APP_SIZE) <= availableSizeWithUnit.size))){
            TempUsbStorages[i].isDim = false;
        }

        var deviceInfo = getDeviceInfo(i, false);
        deviceInfo.index = i;
        deviceInfo.text.itemTextString = TempUsbStorages[i].name;
        deviceInfo.text2.itemTextString = TempUsbStorages[i].totalSize + ' ' + TempUsbStorages[i].fileSystem;
        list.addData(deviceInfo);
    }

    for( var i = itemTotalNum; i < testMaxNum; i++){
        TempUsbStorages[i] = {};
        TempUsbStorages[i].name = "testUSB" + i;
        TempUsbStorages[i].mountPath = "";
        TempUsbStorages[i].fileSystem = "FileSystem";
        TempUsbStorages[i].totalSize = "0.00GB";
        TempUsbStorages[i].availableSize = "0GB";
        TempUsbStorages[i].isDim = false;

        var deviceInfo = getDeviceInfo(i, false);
        deviceInfo.index = i;
        deviceInfo.text.itemTextString = TempUsbStorages[i].name;
        deviceInfo.text2.itemTextString = TempUsbStorages[i].totalSize + ' ' + TempUsbStorages[i].fileSystem;
        list.addData(deviceInfo);
    }
    list.setDataSource();

    for( var i = 0; i < itemTotalNum; i++){
        if(TempUsbStorages[i].isDim === false){
            list.setDim({
                index : i,
                ifDim : true
            });
        }
    }

    for( var i = itemTotalNum; i < testMaxNum; i++){
        list.setDim({
            index : i,
            ifDim : true
        });
    }

    list.setArrowImageAttr(chooseArea.upArrow);
    list.setArrowImageAttr(chooseArea.downArrow);
    list.setAnimationDuration("loop", 0);

    var subListListener = new SubListListener;
    subListListener.OnItemClicked = function(sublist, index){
        Volt.log('[choose-device-popup.js]click - ' + index);
        if(TempUsbStorages[index].isDim === false){
            return;
        }
        var data = TempUsbStorages[index];
        Volt.log('[choose-device-popup.js] DevicesView.onSelect, app_id = ' + APP_ID + ' ,path = ' + data.mountPath);
        var storagepath = data.mountPath;
        var nIndex = storagepath.indexOf('/');
        var path = '/opt/storage/usb' + storagepath.substring(nIndex);
        Volt.log('[choose-device-popup.js] path = ' + path);
        CommonContent.chooseUsbPopUpItemPress(APP_ID, path, APP_SIZE);
        //chooseDevicePopupSelf.hide();
        Backbone.history.back();
    };

    subListListener.OnFocusChanged = function(sublist, fromIndex, toIndex){
        Volt.log('[choose-device-popup.js] onFocusChanged fromIndex = ' + fromIndex + ', toIndex = ' + toIndex);
        if(toIndex >= 0){
            if(sublist.scroll){
                sublist.scroll.setValue(toIndex+1);
            }
            var data = TempUsbStorages[toIndex];
            var params = {
                name : data.name,
                availableSize : data.availableSize,
                totalSize : data.totalSize,
                fileSystem : data.fileSystem
            };

            var voiceGuide = '';
            if(-1 == fromIndex){//first time
                voiceGuide += chooseDevicePopupSelf.widget.getChild('choose-devices-title').text + APP_NAME + ',';
                var appSize = voltApiWrapper.setSuitablyUnit(APP_SIZE);
                var unit = 'COM_SID_MIX_MB';
                if('GB' == appSize.unit){
                    unit = 'COM_SID_MIX_GB';
                }
                voiceGuide += Volt.i18n.t(unit).replace('<<A>>', appSize.size) + ',';
                voiceGuide += Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', sublist.numofItem()) + ',';
            }
            voiceGuide += params.name + ',' + params.availableSize + ',' + Volt.i18n.t('TV_SID_AVAILABLE_LOWER');
            if(TempUsbStorages[toIndex].isDim){
                voiceGuide += ',' + Volt.i18n.t('TV_SID_DISABLED');
            }
            voiceGuide += '.';
            getVoiceGuide(voiceGuide);

            popupSelectedDeviceView.updateInfo(params);
        }
    };
    list.addListener(subListListener);
    return list;
};

function getVoiceGuide(voiceGuide){
    Volt.log('[choose-device-popup.js] getVoiceGuide voiceGuide = ' + voiceGuide);
    VoiceGuide.getVoiceGuide(voiceGuide);
};

function getDeviceInfo(i, isNeedRest){
    var chooseArea = ChooseDevicesTemplate.chooseArea;
    var deviceInfo = chooseArea.deviceInfo;

    var highContrast = DeviceModel.get('highContrast');
    var enlarge = DeviceModel.get('focusZoom');
    if(isNeedRest !== false){ //if isNeedRest is not false, deviceInfo need update
        if(highContrast){
            for(var property in chooseArea.highContrast.text){
                if(typeof chooseArea.highContrast.text[property] == 'object') {
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for highContrast " + property + " = " + JSON.stringify(chooseArea.highContrast.text[property]));
                } else {
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for highContrast " + property + " = " + chooseArea.highContrast.text[property]);
                }
                deviceInfo.text[property] = chooseArea.highContrast.text[property];
                deviceInfo.text2[property] = chooseArea.highContrast.text[property];
            }
        }else{
            for(var property in chooseArea.normal.text){
                if(typeof chooseArea.normal.text[property] == 'object'){
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for normal " + property + " = " + JSON.stringify(chooseArea.normal.text[property]));
                } else {
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for normal " + property + " = " + chooseArea.normal.text[property]);
                }
                deviceInfo.text[property] = chooseArea.normal.text[property];
                deviceInfo.text2[property] = chooseArea.normal.text[property];
            }
            for(var property in chooseArea.normal.item){
                if(typeof chooseArea.normal.item[property] == 'object'){
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for normal " + property + " = " + JSON.stringify(chooseArea.normal.item[property]));
                } else {
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for normal " + property + " = " + chooseArea.normal.item[property]);
                }
                deviceInfo[property] = chooseArea.normal.item[property];
            }
        }
        if(enlarge) {
            for(var property in chooseArea.enlarge.text){
                if(typeof chooseArea.enlarge.text[property] == 'object'){
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for enlarge " + property + " = " + JSON.stringify(chooseArea.enlarge.text[property]));
                } else {
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for enlarge " + property + " = " + chooseArea.enlarge.text[property]);
                }
                deviceInfo.text[property] = chooseArea.enlarge.text[property];
                deviceInfo.text2[property] = chooseArea.enlarge.text[property];
            }
        }
    }

    if(i !== undefined && highContrast){// if i is undefined or highContrast is false, deviceInfo do not need update 
        if(i % 2 == 0){
            for(var property in chooseArea.highContrast.item1st){
                if(typeof chooseArea.highContrast.item1st[property] == 'object'){
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for highContrast " + property + " = " + JSON.stringify(chooseArea.highContrast.item1st[property]));
                } else {
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for highContrast " + property + " = " + chooseArea.highContrast.item1st[property]);
                }
                
                deviceInfo[property] = chooseArea.highContrast.item1st[property];
            }
        }else{
            for(var property in chooseArea.highContrast.item2nd){
                if(typeof chooseArea.highContrast.item2nd[property] == 'object'){
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for highContrast " + property + " = " + JSON.stringify(chooseArea.highContrast.item2nd[property]));
                } else {
                    Volt.log("[choose-device-popup.js] ~~~~~~~~~~~~~~~~~~~~~~~ set property for highContrast " + property + " = " + chooseArea.highContrast.item2nd[property]);
                }
                
                deviceInfo[property] = chooseArea.highContrast.item2nd[property];
            }
        }
    }
    return deviceInfo;
}

//exports = new ChooseDevicePopup();
exports = ChooseDevicePopup;
