/** 
 * @author Wang Xiaojun(xiaojun.wang@samsung.com)/Zha Lihao(lihao.zha@samsung.com)
 * @fileoverview An example of Games Main View.
 * @date 2014/06/28
 * 
 * @version 1.1
 * 
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 * 
 * @note: Volt 2.0 maybe draw children according to index sequence
 */
// Include libraries
var _              = Volt.requireNoContext("modules/underscore.js")._;
var Q              = Volt.requireNoContext('modules/q.js');
var Backbone       = Volt.requireNoContext('lib/volt-backbone.js');
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var CommonFunction = Volt.requireNoContext('app/common/common-function.js');
var CommonContent  = Volt.requireNoContext('app/common/common-content.js');
var PanelCommon    = Volt.requireNoContext('lib/panel-common.js');
var dimView        = Volt.requireNoContext('app/views/dim-view.js');
var voltapi        = Volt.requireNoContext("voltapi.js");

var MainCategoryModel = Volt.requireNoContext("app/models/main-category-model.js");
var CategoryCollection = Volt.requireNoContext('app/models/category-base-collection.js');
var Mediator       = Volt.requireNoContext('app/common/event-mediator.js');
var HeaderView     = Volt.requireNoContext('app/views/main-header-view.js');
var CategoryView   = Volt.requireNoContext('app/views/main-category-view.js');
var LoadingView    = Volt.requireNoContext('app/views/loading-view.js');
var voltApiWrapper = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var OptionMenu     = Volt.requireNoContext('app/views/option-menu-popup.js');
var ErrorHandling  = Volt.requireNoContext('app/common/error-handling.js');
var Utils          = Volt.requireNoContext('app/common/utils.js');
var localStorage   = Volt.requireNoContext("lib/volt-local-storage.js");
var networkStatus  = Volt.requireNoContext('app/common/network-state.js');
var DeviceModel    = Volt.requireNoContext('app/models/device-model.js');
var MultiSelection = Volt.requireNoContext('app/views/multi-selection.js');
var MagicKey       = Volt.requireNoContext('app/common/MagicKey.js');

////////////////////////////////////////////////////////////////////////////////
var statusView = 'HIDE'; //SHOW HIDE ACTIVE DEACTIVE
var lastFocusWgt = null;
var _dim = null;

var MainView = PanelCommon.BaseView.extend({
	firstFocus     : true,
	headerView     : null,
	categoryView   : null,
	offResult      : false,
	requestSuccess : true,
	appPaused      : false,
	optionMenu     : null,
	isActive       : false,
	bUsbConnect    : false,
	bUsbDisconnect : false,
    historySignState: false,
    
	initialize : function() {
		mainViewSelf = this;
	    MagicKey.addListener(CommonDefine.Magic.SHOW_VERSION, function(){
            ErrorHandling.showMessage(CommonDefine.Magic.SHOW_VERSION);
        });
	    MagicKey.addListener(CommonDefine.Magic.SHOW_PROCMEMORY, function(){
	        Volt.log("TTTTTTTTTTTTTTTTTTTTTTTTest " + VDUtil.getProcMemory());
        });
        MagicKey.addListener(CommonDefine.Magic.CHANGE_ISSTORAGEENOUGH, function(){//TODO : This code need delete when was can download to usb
            if(Volt.IsStorageEnough !== false) {//TODO : This code need delete when was can download to usb
                Volt.IsStorageEnough = false;//TODO : This code need delete when was can download to usb
            } else {//TODO : This code need delete when was can download to usb
                Volt.IsStorageEnough = true;//TODO : This code need delete when was can download to usb
            }//TODO : This code need delete when was can download to usb
            Volt.log("TTTTTTTTTTTTTTTTTTTTTTTTest Change IsStorageEnough = " + Volt.IsStorageEnough);//TODO : This code need delete when was can download to usb
        });
	},

	render : function() {
		Volt.log('[main-view.js] MainView.render');
		var MainTemplate = PanelCommon.requireTemplate('main');
		this.setWidget(CommonContent.loadTemplateInWinsetBackgroud(MainTemplate.container, null, null, false).getChild(0));
		this.renderHeader();
		this.renderCategory();
	},

    renderHeader: function() {
        Volt.log('[main-view.js] renderHeaderIcon');
        var container = this.widget.getDescendant('main-header-container');
        this.headerView = new HeaderView(container).render();
    },

    renderCategory: function(model,collection,options) {
        Volt.log('[main-view.js] renderCategory');
        // Check if categoryView exists, if so, just render(), otherwise, create a new one
        var container = this.widget.getChild('main-category-container');
        this.categoryView = new CategoryView(container).render(this);
    },

    // Show this View
    show: function(options, animationType) {
        Volt.log('[main-view.js]  show');

        //// @su.yan| 20150117: rollback to setTimeout as HQ requires "Request to apply code to show title(header view) first."
        //// @xiaojun.wang|20150110: Fix [Performance Test] DF150109-01321, DF141217-02470
        var deferred = Q.defer();
        
        this.widget.show();
        Stage.show();
        
        this.isActive = true;
        statusView = 'SHOW';
        this.startListening();
        this.headerView.startListening();
        this.headerView.show();
        this.categoryView.startListening();
        
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, this.deactive, this);
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE,   this.active,   this);
        Mediator.on(CommonDefine.Event.GAMES_EXIT,          this.exit,     this);
        //Mediator.on(CommonDefine.Event.CONNECT_USB,         mainViewSelf.updateFlag, mainViewSelf);//WAS event
        Mediator.on(CommonDefine.Event.USB_CONNECT,         mainViewSelf.updateFlag, mainViewSelf);//ContentsMgr event
        Mediator.on(CommonDefine.Event.DISCONNECT_USB,      mainViewSelf.pullOutUsbByMistake,mainViewSelf);
        Mediator.on(CommonDefine.Event.CHANGE_MLS,          this.changeMLS,  this);
        Mediator.on('EVENT_SHOW_CHOOSE_DEVICE_POPUP',       this.pauseForChooseDevicePopup, this);
        Mediator.on('EVENT_HIDE_CHOOSE_DEVICE_POPUP',       this.resumeForChooseDevicePopup, this);
			
        if (this.firstFocus) {
			if(Volt.post){
				Volt.post(_.bind(this.load, this));
			} else {	
				Volt.setTimeout(_.bind(this.load, this), 150);
		    }
        } else {    
            Volt.log('later enter main view');
            //Volt.Nav.setRoot(this.widget);
            Volt.Nav.setRoot(this.widget,{focus : lastFocusWgt});
            lastFocusWgt = null;
            //Mediator.trigger(CommonDefine.Event.MAIN_CATEGORY_ON_EVENT);
            Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, true);
            Mediator.trigger('UPDATE_EVENTLISTENER_FLAG_MYPAGE',true);
            Mediator.trigger(CommonDefine.Const.UPDATE_ITEMS);
        }
        
        var currentSignState = voltApiWrapper.getSSOLoginState();
        Volt.log('currentSignState:::'+currentSignState+"historySignState::::"+this.historySignState);
        if(this.historySignState != currentSignState){
            Mediator.trigger(CommonDefine.Event.SIGN_STATE_UPDATE);
        }
        
        this.bUsbConnect = false;
        this.bUsbDisconnect = false;
        this.bDeleteResultPopup = false;
        this.bDisconnectPopup = false;
        deferred.resolve();
        return deferred.promise;
    },
	
	load: function() {
		//call Volt.Nav.setRoot, for reset the root when coming back to this view.
		Volt.Nav.setRoot(this.widget, {focus : null});
		CommonContent.setMainViewRootWgt(this.widget);
		Volt.log('first enter main view');
		var cache = localStorage.getItem('main-category');
		Volt.log('[main-view.js] offline'+ JSON.stringify(cache));
		if(!cache){
			LoadingView.show(CommonDefine.Const.VIEW_LOADING);
		}
        var isChangedCache = this.checkCache();
        Volt.log("isChangedCache:::"+isChangedCache);
        if(!isChangedCache){
            this.offline();
        }
		
		Mediator.trigger('GAMES_POST_LOAD');
		this.firstFocus = false;
	},
    
    offline: function(){
        var that = this; 
		//step1:if caching data is more than 24h,then don't need to read cache data
		var categoryCachingTime = localStorage.getItem('category-base-caching-time');
		var mainCachingTime = localStorage.getItem('main-category-caching-time');
		var currentTime = new Date().getTime();
		Volt.log('[main-view.js]offline currentTime = ' + currentTime);
		
		//step2:cache signState is not match now state,then don't need to read cache data
		if(currentTime - categoryCachingTime > 86400000 || currentTime - mainCachingTime > 86400000){
			Volt.log('[main-view.js] cacheing data is more than 24h,or cache signState is not match now state,do not need to read cache data ');
			return;
		}
		
        function onSuccess() {
            Volt.log('off line success');
            that.offResult = true;
            //LoadingView.hide();
            //need trigger this event because spotlight will be blank before change:ready at first[for time sequence]
            Mediator.trigger(CommonDefine.Event.UPDATE_FOR_CACHE_DATA);
            Volt.log('onSuccess, Stage Show.....');
            Stage.show();
        }
        
        function onFail() {
            Volt.log('off line fail');
            that.offResult = false;
        }
        
        Q.all([
            CategoryCollection.offline(),
            MainCategoryModel.offline()
        ])
        .then(onSuccess, onFail);
    },
    
    checkCache:function(){
        var countryCode  = DeviceModel.get('countryCode');
        var languageCode = DeviceModel.get('languageCode');
        var cacheLanguage = localStorage.getItem('language-code');
        var cacheCountry  = localStorage.getItem('country-code');
        Volt.log('current country code:::'+countryCode+", cache country code::::"+cacheCountry);
        Volt.log('current language code:::'+languageCode+", cache language code::::"+cacheLanguage);
        var isCountryChanged = countryCode == cacheCountry? false : true;
        var isLanguageChanged = languageCode == cacheLanguage? false : true;
        Volt.log("isCountryChanged :::"+isCountryChanged+", isLanguageChanged:::"+isLanguageChanged);
        return (isCountryChanged || isLanguageChanged);
    },
    
    requestData:function(){
        Volt.log('[main-view.js] request for real data');
        localStorage.setItem('country-code', DeviceModel.get("countryCode"));
        localStorage.setItem('language-code', DeviceModel.get("languageCode"));
        var that = this;
        function onSuccess(){
            Volt.log('[main-view.js] requestData onSuccess');
            LoadingView.hide();
            MainCategoryModel.ready();
            Mediator.trigger(CommonDefine.Event.UPDATE_FOR_REAL_DATA);
            Volt.log('requestData, Stage Show.....');
            Stage.show();
        }
        
        function onError(msg){
            Volt.log("error msg::::"+JSON.stringify(msg));
            LoadingView.hide();
            Volt.log('off line result::::'+that.offResult);
            if(!that.offResult){
                Volt.log('[main-view.js] requestData  request fail........');
                that.requestSuccess = false;
                var option={
                    errMsg:msg,
                    categoryLength:CategoryCollection.length
                }
                Mediator.trigger(CommonDefine.Event.NETWORK_ERROR,option);
                Volt.log('onError, Stage Show.....');
                Stage.show();
            }
        }

        Q.all([
                CategoryCollection.fetch(),
                MainCategoryModel.fetch({
                    path : 'ALL',
                    latest_app_id : ''
                })
            ])
        .then(onSuccess, onError);
    },
    
    hide: function(animationType) {
        Volt.log('[main-view.js] hide ~~~~~~');
        var deferred = Q.defer();
        if (statusView == 'HIDE') {
            Volt.log('[main-view.js] main view have already pause');
            deferred.resolve();
            return deferred.promise;
        }

        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, this);
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, this);
        Mediator.off(CommonDefine.Event.GAMES_EXIT, null, this);
	    Mediator.off(CommonDefine.Event.CHANGE_MLS, null, this);
        
        statusView = 'HIDE';
        Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, false);
        Mediator.off(CommonDefine.Event.MAIN_CATEGORY_CACHE_DATA);
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR);
        Mediator.off(CommonDefine.Event.DISCONNECT_USB, null, this);
        //Mediator.off(CommonDefine.Event.CONNECT_USB, null, this);
        Mediator.off(CommonDefine.Event.USB_CONNECT, null, this);
        Mediator.off('EVENT_SHOW_CHOOSE_DEVICE_POPUP', null, this);
        Mediator.off('EVENT_HIDE_CHOOSE_DEVICE_POPUP', null, this);

        this.historySignState = voltApiWrapper.getSSOLoginState();
        Volt.log('historySignState :::'+this.historySignState);
        
        this.stopListening();
        this.headerView.stopListening();
        this.headerView.hide();
        this.categoryView.stopListening();
        Mediator.trigger('UPDATE_EVENTLISTENER_FLAG_MYPAGE',false);
        this.isActive = false;
        this.bUsbConnect = false;
        this.bUsbDisconnect = false;
        //lastFocusWgt = null;
        lastFocusWgt = Volt.Nav.getFocusedWidget();
        _dim = null;
        this.bDeleteResultPopup = false;
        this.bDisconnectPopup = false;
        
        this.widget.hide();

        deferred.resolve();
        return deferred.promise;
    },

    pause : function(option) {
        Volt.log('[main-view.js] pause~~~~~');
        if (statusView == 'PAUSE') {
            Volt.log('[main-view.js] main view have already pause');
            //press menu when deleting or delete-result popup
            var result = CommonContent.isDeleteResultPopup();
            if (result) {
                this.bDeleteResultPopup = true;
            }
            Volt.log('[main-view.js] pause ~~~~~ bDeleteResultPopup= ' + this.bDeleteResultPopup);
            
            var msgPopup = CommonContent.getCurrentMSGPopup();
            if(CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB == msgPopup){
                this.bDisconnectPopup = true;
            }
            Volt.log('[main-view.js] pause ~~~~~ bDisconnectPopup= ' + this.bDisconnectPopup);
            return;
        }

        statusView = 'PAUSE';
        MultiSelection.pause();
        Volt.log('[main-view.js] pause ~~~~~ bUsbConnect= ' + mainViewSelf.bUsbConnect);
        //Mediator.trigger('UPDATE_UNINSTALL_FLAG_MYPAGE',false);

        mainViewSelf.getLastFocus();

        Volt.Nav.blur();
        var mlsMode = voltapi.vconf.getValue('memory/mls/state');
        Volt.log(' vconf MLS_STATE : ' + mlsMode);
        if (option&&option.deactive && mlsMode == 1) {
            Volt.log('[main-view.js]mls Mode! Do not show dim');
        } else {
            dimView.show({
                parent : mainViewSelf.widget
            });
        }
    },

    resume : function() {
        Volt.log('[main-view.js] resume .....');
        if (statusView == 'SHOW') {
            Volt.log('[main-view.js] main view have already resume');
            return;
        }

        Volt.log('[main-view.js] resume .....statusView =' + statusView);
        Volt.log('[main-view.js] resume .....isActive =' + mainViewSelf.isActive);
        if (mainViewSelf.isActive) {
            dimView.hide();
            MultiSelection.resume();
            mainViewSelf.setLastFocus();
            statusView = 'SHOW';
            mainViewSelf.isActive = true;
            /*
            if(MultiSelection.isStatus("SHOW")){
                mainViewSelf.bUsbDisconnect = false;
            }
            */
            //Mediator.trigger('UPDATE_UNINSTALL_FLAG_MYPAGE',true);
            Mediator.trigger(CommonDefine.Event.CHECK_USER_ICON);
        }

        if (!mainViewSelf.requestSuccess) {
            Volt.log('request fail');
            Volt.quit();
        }
    },
    
    pauseForChooseDevicePopup : function(){
        Volt.log("[main-view.js] pauseForChooseDevicePopup --------");
        statusView = 'PAUSE';
        
        Mediator.off(CommonDefine.Event.GAMES_ON_ACTIVATE, null, mainViewSelf);
        Mediator.off(CommonDefine.Event.GAMES_ON_DEACTIVATE, null, mainViewSelf);
        Mediator.off(CommonDefine.Event.DISCONNECT_USB, null, mainViewSelf);
        //Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, false);
        /*
        mainViewSelf.getLastFocus();
        Volt.Nav.blur();
        _dim = dimView.show({
            parent : this.widget
        }, true);
        */
    },

    resumeForChooseDevicePopup : function(){
        Volt.log("[main-view.js] resumeForChooseDevicePopup --------");
        //statusView = 'SHOW';
        
        Mediator.on(CommonDefine.Event.GAMES_ON_ACTIVATE,   mainViewSelf.active,   mainViewSelf);
        Mediator.on(CommonDefine.Event.GAMES_ON_DEACTIVATE, mainViewSelf.deactive, mainViewSelf);
        Mediator.on(CommonDefine.Event.DISCONNECT_USB,      mainViewSelf.pullOutUsbByMistake,mainViewSelf);
        //Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, true);
        /*
        dimView.hide(_dim);
        _dim = null;
        mainViewSelf.setLastFocus();
        */
        mainViewSelf.resume();
    },
    
    active : function(){
        Volt.log('main view active......');
         if(this.isActive){
            Volt.log('[main-view]main view have already active');
            return;
        }
        
        this.isActive = true;
        Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, true);
        this.resume();
        this.startListening();
        Mediator.off("MYPAGE_FOCUS_HAS_SETTED",null, this);
    },
    
    deactive : function(){
        Volt.log('main view deactive.......');
        if (!LoadingView.viewIsVisiable) {
            if (!this.isActive) {
                Volt.log('[main-view]main view have already deactive');
                return;
            }

            this.isActive = false;
            this.pause({
                deactive : true
            });
            this.stopListening();
            Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, false);
            Mediator.on("MYPAGE_FOCUS_HAS_SETTED", this.handlerFocusWhenDeactive, this);
        }
    },
    
    handlerFocusWhenDeactive : function(){
        Volt.log('[main-view.js] handlerFocusWhenDeactive');
        var bPanelActive = CommonContent.getPanelActive();
        if(!bPanelActive){
            var bEnded = CommonContent.getMyPageFocusEndedFlag();
            if(bEnded){
                lastFocusWgt = Volt.Nav.getFocusedWidget();
                Volt.log('[main-view.js] handlerFocusWhenDeactive lastFocusWgt ='+ lastFocusWgt);
                Volt.Nav.blur();
                CommonContent.setMyPageFocusEnded(false);
            }
        }
    },
    
    exit : function(bHide){
        Volt.log('main view exit.......');
		Volt.log('[main-view.js]bHide = '+ bHide);
		Mediator.trigger(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, false);
		/*if(bHide){
			voltApiWrapper.removeAllInstallList();
		}*/
    },
    
    getLastFocus : function() {
        Volt.log('[main-view.js] getLastFocus');
        var result = CommonContent.isDeleteResultPopup();
        if (result) {
            this.bDeleteResultPopup = true;
        }

        if(MultiSelection.getState()){
            Volt.log('[main-view.js] getLastFocus multi-delete');
            var tempWgt = Volt.Nav.getFocusedWidget();
            Volt.log('[main-view.js] getLastFocus multi-delete tempWgt =' + tempWgt);
            
            if(this.bDeleteResultPopup){
                lastFocusWgt = this.widget.getDescendant('main-header-icon-setting');
            } else if(tempWgt && tempWgt.hasOwnProperty("id") && "myPageContent" == tempWgt.id){
                Volt.log('[main-view.js] getLastFocus when multi-delete focus is on grid');
                lastFocusWgt = tempWgt;
            } else {
                lastFocusWgt = MultiSelection.getLastFocus();
            }
        } else {
            Volt.log('[main-view.js] getLastFocus -------');
            lastFocusWgt = Volt.Nav.getFocusedWidget();
        }
        
        Volt.log('[main-view.js] getLastFocus lastFocusWgt =' + lastFocusWgt);
        if(lastFocusWgt && lastFocusWgt.hasOwnProperty("id") && lastFocusWgt.id) {
            Volt.log('[main-view.js] getLastFocus lastFocusWgt.id =' + lastFocusWgt.id);
        }
        
        if(!lastFocusWgt || !lastFocusWgt.id) {
            Volt.log('[main-view.js] getLastFocus return');
            //CommonContent.setLastFocusForGrid(null);
            return;
        }
        
        switch(lastFocusWgt.id) {
            case "SPOTLIGNT_CONTENT":
                var focusedItem = lastFocusWgt.getFocusItemIndex();
                Volt.log('[main-view.js] getLastFocus spotlight (' + focusedItem.groupIndex + "," + focusedItem.itemIndex + ")");
                var params = {
                    widgetType : "grid",
                    widget : lastFocusWgt,
                    groupIndex : focusedItem.groupIndex,
                    itemIndex : focusedItem.itemIndex,
                    view : "spotlight",
                    refresh : false,
                };
                CommonContent.setLastFocusForGrid(params);
                break;
             case "myPageContent":
                var focusedItem = lastFocusWgt.getFocusItemIndex();
                Volt.log('[main-view.js] getLastFocus mypage (' + focusedItem.groupIndex + "," + focusedItem.itemIndex + ")");
                var params = {
                    widgetType : "grid",
                    widget : lastFocusWgt,
                    groupIndex : focusedItem.groupIndex,
                    itemIndex : focusedItem.itemIndex,
                    view : "mypage",
                    refresh : false,
                };
                CommonContent.setLastFocusForGrid(params);
                Volt.log('[main-view.js] getLastFocus ~~~~~ bUsbConnect = ' + this.bUsbConnect);
                /*
                if(this.bUsbConnect){
                    Volt.log('[main-view.js] getLastFocus, insert USB');
                    Mediator.trigger("REMOVE_WHEN_INSERT_USB");
                    this.bUsbConnect = false;
                }
                */

                break;
            default :
                CommonContent.setLastFocusForGrid(null);
                break;
        }
    },
    
    setLastFocus : function(){
        Volt.log('[main-view.js] setLastFocus');
        if(MultiSelection.isStatus("SHOW") && MultiSelection.isLastFocus()){
            Volt.log('[main-view.js] setLastFocus on multi-selection');
            this.setLastFocusWhenMultiSelection();
            return;
        }
        
        Volt.log('[main-view.js] setLastFocus lastFocusWgt =' + lastFocusWgt);
        var lastFocusInMainView = CommonContent.getLastFocusForGrid();
        if(lastFocusInMainView){
            var mainViewWgt = lastFocusInMainView.widget;
            Volt.log('[main-view.js] setLastFocus mainViewWgt =' + mainViewWgt);
            this.setLastFocusForMainView(lastFocusInMainView);
        } else {
            Volt.log('[main-view.js] setLastFocus, lastfocus is not on grid.');
            this.setLastFocusWhenNotOnGrid();
        }
    },
    
    setLastFocusWhenMultiSelection : function(){
        Volt.log('[main-view.js] setLastFocusWhenMultiSelection');
        Volt.Nav.setRoot(this.widget, {
            focus : MultiSelection.getLastFocus()
        });

        Volt.log('[main-view.js] setLastFocusWhenMultiSelection  this.bUsbConnect =' + this.bUsbConnect);
        Volt.log('[main-view.js] setLastFocusWhenMultiSelection  this.bUsbDisconnect =' + this.bUsbDisconnect);
        if (this.bDeleteResultPopup) {
            Volt.log('[main-view.js] setLastFocusWhenMultiSelection, press menu when delete-success popup is showing');
            Volt.Nav.setRoot(this.widget, {
                focus : null
            });
            Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS, lastFocusWgt);
            this.resetDeleteResult();
            this.bDisconnectPopup = false;
            this.bUsbDisconnect = false;
            this.bUsbConnect = false;
            return;
        }

        if (this.bUsbConnect && !this.bUsbDisconnect) {
            Volt.log('[main-view.js] setLastFocusWhenMultiSelection  usb connect');
            Mediator.trigger("REMOVE_WHEN_INSERT_USB");
            this.bUsbConnect = false;
            this.resetDeleteResult();
            return;
        }

        if (this.bUsbDisconnect && this.bDisconnectPopup) {
            Volt.log('[main-view.js] setLastFocusWhenMultiSelection press menu when disconnectUSB');
            Mediator.trigger("REMOVE_WHEN_INSERT_USB");
            this.bDisconnectPopup = false;
            this.bUsbDisconnect = false;
            this.bUsbConnect = false;
            this.resetDeleteResult();
            return;
        }
        Volt.log('[main-view.js] setLastFocusWhenMultiSelection  this.bDeleteResultPopup =' + this.bDeleteResultPopup);
    },
    
    resetDeleteResult : function(){
        if (this.bDeleteResultPopup) {
            this.bDeleteResultPopup = false;
            CommonContent.resetDeleteResultPopup(null);
        }
    },
    
    setLastFocusWhenNotOnGrid : function(){
        Volt.log('[main-view.js] setLastFocusWhenNotOnGrid ~~~~~ bUsbConnect =' + this.bUsbConnect);
        Volt.log('[main-view.js] setLastFocusWhenNotOnGrid ~~~~~ bDisconnectPopup =' + this.bDisconnectPopup);
        if (this.bUsbConnect) {
            this.handlerWhenConnectUSB();
            return;
        }
        
        if(this.bDisconnectPopup){
            //when USB disconnect popup and press menu
            Volt.log("[main-view.js] setLastFocusWhenNotOnGrid, press menu when USB disconnect popup.");
            Volt.Nav.setRoot(this.widget, {
                focus : lastFocusWgt
            });
            Mediator.trigger("HIDE_DISCONNECT_POPUP",true);
            this.bUsbDisconnect = false;
            this.bDisconnectPopup = false;
        } else {
            Volt.log('[main-view.js] setLastFocusWhenNotOnGrid ~~~~~ bDeleteResultPopup =' + this.bDeleteResultPopup);
            if (MultiSelection.getState()) {
                Volt.log('[main-view.js] setLastFocusWhenNotOnGrid, multiselection');
                if (this.bDeleteResultPopup) {
                    Volt.log('[main-view.js] setLastFocusWhenNotOnGrid, press menu when delete-success popup is showing');
                    Volt.Nav.setRoot(this.widget, {
                        focus : null
                    });
                    //Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS, lastFocusWgt);
                    this.resetDeleteResult();
                } else {
                    Volt.Nav.setRoot(this.widget);
                }

            } else {
                Volt.Nav.setRoot(this.widget, {
                    focus : lastFocusWgt
                });
            }
        }
    },
    
    setLastFocusForMainView : function (lastFocusInMainView) {
        Volt.log('[main-view.js] setLastFocusForMainView');
        Volt.log('[main-view.js] setLastFocusForMainView ..... view =' + lastFocusInMainView.view);
        
        switch(lastFocusInMainView.view) {
            case "spotlight" :
                Volt.Nav.setRoot(this.widget, {
                    focus : lastFocusInMainView.widget
                });
                CommonContent.setLastFocusForGrid(null);
                break;
            case "mypage" :
                //Volt.Nav.setRoot(this.widget,{focus:null});
                if(this.bUsbConnect && !this.bUsbDisconnect){
                    this.handlerWhenConnectUsbOnMypage();
                } else if(this.bUsbDisconnect){
                    Volt.log('[main-view.js] usb disconnected');
                    this.handlerWhenDisconnectUsbOnMypage();
                } else {
                    Volt.log('[main-view.js] not insertUSB  this.bDeleteResultPopup ='+ this.bDeleteResultPopup);
                    if(this.bDeleteResultPopup){
                        Volt.Nav.setRoot(this.widget,{focus:null});
                        var result = CommonContent.isDeleteResultPopup();
                        
                        if (result && ("delete" == result.type || CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS == result.type)) {
                            Volt.log('[main-view.js] press menu when deleting/delete-success popup');
                            Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS, null);
                            /*
                            Volt.Nav.setRoot(this.widget, {
                                focus : lastFocusInMainView.widget
                            });*/
                        } else {
                            Volt.log('[main-view.js] press menu when delete-fail popup');
                            Mediator.trigger(CommonDefine.Event.SET_ROOT_COMPLETE);
                        }
                        
                       this.resetDeleteResult();
                    } else {
                        Volt.log('[main-view.js] other case ');
                        Volt.Nav.setRoot(this.widget,{focus:null});
                        Mediator.trigger(CommonDefine.Event.SET_ROOT_COMPLETE);
                    }
                }
                //CommonContent.setLastFocusForGrid(null);
                
                break;
            default:
                break;
        }
    },
    
    handlerWhenConnectUsbOnMypage : function(){
        Volt.log('[main-view.js] handlerWhenConnectUsbOnMypage');
        Volt.Nav.setRoot(this.widget, {
            focus : null
        });
        if (this.bDeleteResultPopup && MultiSelection.getState()) {
            Volt.log('[main-view.js] insertUSB when multiselect  deleting/delete result popup');
            var result = CommonContent.isDeleteResultPopup();
            if (result && "delete" == result.type) {
                Volt.log('[main-view.js] insertUSB when multiselect  deleting popup');
                Mediator.trigger("REMOVE_WHEN_INSERT_USB");
            } else {
                Volt.log('[main-view.js] insertUSB when multiselect  delete success/fail popup');
                lastFocusWgt = this.widget.getDescendant('main-header-icon-setting');
                Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS, lastFocusWgt);
            }

        } else if (this.bDeleteResultPopup) {
            Volt.log('[main-view.js] insertUSB when longpress  deleting/delete result popup');
            Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS, null);
        } else {
            Volt.log('[main-view.js] insertUSB when deleting/delete result popup');
            if (this.isActive) {
                Mediator.trigger("REMOVE_WHEN_INSERT_USB");
            }
        }

        this.bUsbConnect = false;
        this.resetDeleteResult();
    },
    
    handlerWhenDisconnectUsbOnMypage : function(){
        Volt.log('[main-view.js] handlerWhenDisconnectUsbOnMypage');
        /*
        if(!this.bDisconnectPopup){
            var msgPopup = CommonContent.getCurrentMSGPopup();
            if (CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB == msgPopup) {
                this.bDisconnectPopup = true;
            }
        }
        */

        Volt.log('[main-view.js] handlerWhenDisconnectUsbOnMypage this.bDisconnectPopup ='+ this.bDisconnectPopup);
        if (this.bDisconnectPopup) {
            // disconnectpopup and press menu
            Volt.Nav.setRoot(this.widget, {
                focus : null
            });
            Mediator.trigger("HIDE_DISCONNECT_POPUP",true);
            this.bUsbDisconnect = false;
        } else {
            var destroyedPopup = CommonContent.getCurrentMSGPopup();
            Volt.log('[main-view.js] handlerWhenDisconnectUsbOnMypage destroyedPopup ='+ destroyedPopup);
            if(CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB == destroyedPopup){
                Volt.Nav.setRoot(this.widget,{focus : null});
                this.bUsbDisconnect = false;
            } else {
                Volt.Nav.setRoot(this.widget,{focus : lastFocusWgt});
            }
        }
        Volt.log('[main-view.js] handlerWhenDisconnectUsbOnMypage bDeleteResultPopup ='+ this.bDeleteResultPopup);
        this.resetDeleteResult();
        this.bDisconnectPopup = false;
    },
  
    handlerWhenConnectUSB : function(){
        Volt.log('[main-view.js] handlerWhenConnectUSB, MultiSelection.isLastFocus() ='+ MultiSelection.isLastFocus());
        if (MultiSelection.isStatus("SHOW") && !MultiSelection.isLastFocus()) {
            Volt.log('[main-view.js] handlerWhenConnectUSB, insertUSB when multi-select');
            
            if(this.bDeleteResultPopup){
                Volt.log('[main-view.js] handlerWhenConnectUSB, insertUSB or press menu when delete-success popup is showing');
                Volt.log('[main-view.js] handlerWhenConnectUSB, lastFocusWgt =' + lastFocusWgt);
                Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,lastFocusWgt);
                this.resetDeleteResult();
            } else {
                Volt.Nav.setRoot(this.widget);
            }
        } else {
            Volt.log('[main-view.js] handlerWhenConnectUSB, insertUSB when no multi-select');
            
            if(this.bDeleteResultPopup){
                Volt.log('[main-view.js] handlerWhenConnectUSB, lastFocusWgt =' + lastFocusWgt);
                Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,lastFocusWgt);
                this.resetDeleteResult();
            } else {
                Volt.Nav.setRoot(this.widget,{focus : lastFocusWgt});
            }
            Mediator.trigger("REMOVE_WHEN_INSERT_USB");
        }
        this.bUsbConnect = false;
    },

	handleMenuDestroy : function (){
		dimView.hide();
		this.optionMenu = null;
		CommonContent.setOptionMenu(null);
		this.headerView.settingBtn.setBackgroundImage({state:"focused",src:"images/" + scene.height + "/highlight/4way_focus.png"});
		this.headerView.settingBtn.setBackgroundImage({state:"focused-roll-over",src:"images/" + scene.height + "/highlight/4way_focus.png"});
		Mediator.off(CommonDefine.Event.DESTROY_MENU,null,this);
	},

	addEventLog : function(eventName,options){
		Volt.log('[main-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
		if(!eventName){
			return;
		}

		Volt.KPIMapper.addEventLog(eventName, {d : options,});
	},
	
	onOptionMenu : function(index) {
		Volt.log('[option-menu-popup.js] onOptionMenuCB index' + index);
		if (this.optionPopup.ifDim({index:index})) {
			return;
		}
		//	this.optionPopup.clearTimeout();
		var option = this.optionPopup.text({index:index});
		Volt.log('[option-menu-popup.js] onOptionMenuCB text = ' + option);

		switch(option) {
			case Volt.i18n.t('UID_SIGN_IN'):
			case Volt.i18n.t('UID_SIGN_OUT'):
				mainViewSelf.addEventLog('JUMPSSO',{cp : '',ssoby: 'option',inputby:'',});
				voltApiWrapper.startSSOPopup();
				this.hide();
				break;
                
			case Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE'):
				mainViewSelf.addEventLog('OPTIONGCGUIDE',{cp : '',inputby:'',});
				if (!networkStatus.getNetWorkState()) {
					this.hide();
					ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR, '', '505');
				} else {
					this.hide();
					Backbone.history.navigate('popup/game-controller', {
						trigger : true
					});
				}
				break;
                
			case Volt.i18n.t('TV_SID_GAMES_7'):
				mainViewSelf.addEventLog('OPTIONDELETE',{cp : '',inputby:'',});
				this.hide();
                Volt.log('multi selection delete..........');
                MultiSelection.setState('delete');                
				Mediator.trigger('EVENT_PRESS_DELETE_MENU');
				break;
                
			case Volt.i18n.t('TV_SID_EDIT_NICKNAME'):
				mainViewSelf.addEventLog('OPTIONNICK',{cp : '',inputby:'',});
				this.hide();
				
                var category = MainCategoryModel.get('category');
                Volt.log('[main-view.js] category is :' + category);

                if (category == 'C0070') {
                    var params = {
                        "event" : "edit-name",
                        "type" : 'input-text',
                        'cp' : Volt.KPIMapper.getPageEvent().pageEvent,
                        'from' : 'click-optionMenu',
                    };
                    Backbone.history.navigate('popup/' + JSON.stringify(params), {
                        trigger : true
                    }); 
                } else {
                    CommonContent.setOptionEditNickName(true);
                    Mediator.trigger("EVENT_PRESS_EDIT_NICKNAME");
                }
                
				break;
                
			case Volt.i18n.t('TV_SID_GAMES_6'):
				mainViewSelf.addEventLog('OPTIONUPDATE',{cp : '',inputby:'',});
				this.hide();
                MultiSelection.setState('update');
				Mediator.trigger('EVENT_PRESS_UPDATE_MENU');
				break;
                
			case Volt.i18n.t('COM_SORT_BY_COLON').replace(':',''):
				if (this.subMenuSelected != subIndex) {
					this.subMenuSelected = subIndex;
				}

				this.optionPopup.setSubSelectIndex(2, this.subMenuSelected);
				var text = this.optionPopup.getSubListText(index, subIndex);
				this.hide();
				Mediator.trigger(CommonDefine.Event.EVENT_SORT, text);
				break;

			default:
				this.hide();
				break;
		}
	},
    
	showOptionMenu : function() {
		Volt.log('[main-view.js] showOptionMenu ~~~~~');
		Mediator.on(CommonDefine.Event.DESTROY_MENU, this.handleMenuDestroy, this);
		var currentPage = MainCategoryModel.get('category');
		dimView.show({
			parent : this.widget
		});
		var that = this;
		var menuItemArr = [Volt.i18n.t('UID_SIGN_IN'), Volt.i18n.t('TV_SID_GAMES_7'), Volt.i18n.t('TV_SID_EDIT_NICKNAME'), Volt.i18n.t('TV_SID_GAMES_6'), Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE')];
		this.optionMenu = new OptionMenu({
			style : CommonDefine.Const.OPTION_MENU,
			listItems : menuItemArr,
            /*
			bgColor : {
				r : 15,
				g : 24,
				b : 38,
				a : 255
			},
            */
			callback : that.onOptionMenu
		});
		this.optionMenu.show(currentPage);
		CommonContent.setOptionMenu(this.optionMenu);
	},
	
	updateFlag : function () {
	    Volt.log('[main-view.js] connectUSB updateFlag');
	    var category = MainCategoryModel.get('category');
        Volt.log('[main-view.js] category is :' + category);    
        if (category != 'C0070') {
            this.bUsbConnect = false;
        } else {
            this.bUsbConnect = true;
        }
        this.bUsbDisconnect = false;
	},
	
	/*
	resetFlag : function(){
	    Volt.log('[main-view.js] connectUSB resetFlag');
	    if(this.firstUSBConnect){
	        this.firstUSBConnect = false;
	        this.bUsbConnect = false;
	    }
	},
	*/
    
    pullOutUsbByMistake : function(param) {
        Volt.log("[main-view.js] ===   pullOutUsbByMistake path "+param['0'].storage.mountPath);
        this.bUsbDisconnect = true;
        this.bUsbConnect = false;
        this.bDisconnectPopup = false;
        var installList = voltApiWrapper.getInstallList();
        var originalList = [];
        for(var i=0;i<installList.length;i++){
            originalList[i] = installList[i];
        }
        for (var i=0; i < originalList.length; i++) {
            if (voltApiWrapper.isWidgetInstalling(originalList[i].appID) && originalList[i].install_path == param['0'].storage.mountPath.replace("$USB_DIR", "/opt/storage/usb")) {
                var data = {
                    app_id : originalList[i].appID,
                };
                voltApiWrapper.cancelInstallApp(originalList[i].appID);
            }
        };
        var category = MainCategoryModel.get('category');
        Volt.log('[main-view.js] category is :' + category);    
        if (category != 'C0070') {
            ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB);
        }
    },
    
    changeMLS : function(mlsMode){
        Volt.log("[main-view.js] changeMLS " + mlsMode);
        if(mlsMode) {
            dimView.hide();
        }
    },
    
    startListening : function() {
        Mediator.on(CommonDefine.Event.OPTION_MENU_POPUP,        this.showOptionMenu,      this);
        Mediator.on(CommonDefine.Event.MSGBOX_BUTTON,            this.processMsgBoxEvent,  this);
        //Mediator.on(CommonDefine.Event.EVENT_DELETE_SUCCESS, CommonContent.unInstallSuccess, this);
        Mediator.on(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, CommonContent.showAppSyncError, this);
        Mediator.on(CommonDefine.Event.INSTALL_FAIL,             CommonContent.installFail, this);
        Mediator.on('SERVER_API_READY',                          this.requestData,          this);

        Mediator.on(CommonDefine.Event.GAMES_NETWORK_CHANGED, this.networkStatusChanged, this);
        //Mediator.on(CommonDefine.Event.CONNECT_USB, this.updateFlag, this);
        //Mediator.on(CommonDefine.Event.DISCONNECT_USB,this.pullOutUsbByMistake,this);
    },
    
    stopListening: function(){
        Mediator.off(CommonDefine.Event.OPTION_MENU_POPUP, null, this);
        Mediator.off(CommonDefine.Event.MSGBOX_BUTTON, null, this);
        //Mediator.off(CommonDefine.Event.EVENT_DELETE_SUCCESS);
        Mediator.off(CommonDefine.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE, null, this);
        Mediator.off(CommonDefine.Event.INSTALL_FAIL, null, this);
        //Mediator.off(CommonDefine.Event.CONNECT_USB, null, this);
        Mediator.off('SERVER_API_READY', null, this);
        //Mediator.off(CommonDefine.Event.DISCONNECT_USB,null,this);
        Mediator.off(CommonDefine.Event.GAMES_NETWORK_CHANGED, null, this);
    },

    networkStatusChanged: function(status) {
        if (!status) return;

        if (true) {
            this.requestData();
            return;
        }
    },
    
	onKeyEvent : function (keyCode, keyType) {
		Volt.log('[main-view.js] keyCode is :' + keyCode);
		if (keyType == Volt.EVENT_KEY_RELEASE) {
			return false;
		}
		
		if(MultiSelection.onKeyEvent(keyCode)){
		    return true;
		}
        
        var widget = Volt.Nav.getFocusedWidget();
        if (widget && widget.constructor && widget.constructor.name== "CategoryTab") {
            if(Utils.Nav.BLOCK_NAV){
                Volt.log('[main-view.js] subview is switching,ignore any key!');
                return true;
            }
            if (keyCode == Volt.KEY_JOYSTICK_LEFT || keyCode == Volt.KEY_JOYSTICK_RIGHT) {
                Volt.log('[main-view.js] keyCode is left or right while focusing on categoryTab!');
                Utils.Nav.BLOCK_NAV = true;
                return true;
            }
        }

		var category = MainCategoryModel.get('category');
		Volt.log('[main-view.js] category is :' + category);	
		if (category == 'C0070') {
			if(keyCode === Volt.KEY_RETURN && LoadingView.viewIsVisiable === false) {
				Volt.log('trigger : EVENT_RETURN_EDIT_MODE');
				Mediator.trigger('EVENT_RETURN_EDIT_MODE');
			}
		} 
		return false;
	},

	processMsgBoxEvent: function(data) {
		Volt.log('[main-view.js] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
		if(data.eventType == CommonDefine.Event.SELECT_BTN1) {
			switch(data.msgBoxtype) {
				case CommonDefine.MsgBoxType.MSGBOX_TYPE_SIGIN_INSTALLED:
					voltApiWrapper.startSSOPopup();
					break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                    var aulApp = new Aul();
                    aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                    break;
                case CommonDefine.MsgBoxType.MSGBOX_TYPE_DISCONNECT_USB:
                    var category = MainCategoryModel.get('category');
                    Volt.log('[main-view.js] category is :' + category);
                    if (category != 'C0070') {
                        this.bUsbDisconnect = false;
                        Mediator.trigger(CommonDefine.Const.UPDATE_ITEMS);
                    }
                    break;

				default:
					break;
			}
		} else if(data.eventType == CommonDefine.Event.SELECT_BTN2) {
			
		}
	},	
});

exports=MainView;
