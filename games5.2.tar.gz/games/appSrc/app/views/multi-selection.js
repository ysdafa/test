// Include libraries
var Backbone 				= Volt.requireNoContext('lib/volt-backbone.js');
var PanelCommon 			= Volt.requireNoContext('lib/panel-common.js');
var MultiSelectionTemplate  = Volt.requireNoContext('app/templates/1080/multi-selection-template.js');
var Mediator 			    = Volt.requireNoContext('app/common/event-mediator.js');
var CommonContent 			= Volt.requireNoContext('app/common/common-content.js');
var CommonDefine            = Volt.requireNoContext('app/common/common-define.js');
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');

var multiSelectionSelf = null;
var status = '';//null->delete->update
var statusView = 'HIDE';
var viewIsVisible = false;
var MultiSelection = PanelCommon.BaseView.extend({

	template: MultiSelectionTemplate.container,
    isExpand : false,
	selectAllBtn:null,
    deleteBtn:null,
    cancelBtn:null,
    selectAllBg:null,
    deleteBg:null,
    cancelBg:null,
    isChecked:false,
    lastFocusInMutiSelection : false,
    lastFocusWidget : null,
    lastFocusBtn : null,
    timer : null,
    btnListener : new ButtonListener(),
    
    initialize: function() {
    	this.btnListener.onButtonClicked=function(button,type){
    		switch(button.id){
    			case "selectAll":
    			    this.updateSelectAllState(!this.isChecked);
    		        Mediator.trigger('EVENT_SELECTALL_BUTTON',this.isChecked);
    		        break;
    			case "delete":
    			    Mediator.trigger('EVENT_DELETE_BUTTON');
    			    break;
    			case "cancel":
    			    Mediator.trigger('EVENT_CANCEL_BUTTON');
    			    break;
    			default:
    			    break;
    		}
    	}.bind(this);
    },
    
    render: function() {
    },
    
    setState: function(state){
        Volt.log('state=====>'+state);
        status = state;
    },
    
    getState : function(){
        return status;
    },
    
    isViewIsVisible : function() {
        return viewIsVisible;
    },
    
    onKeyEvent : function(keyCode){
        if(statusView == 'SHOW'){
            switch(keyCode){
                case Volt.KEY_RETURN: {
                    Volt.log("[multi-selection.js] @@@Return key");
                    Mediator.trigger('EVENT_RETURN_EDIT_MODE');
                    return true;
                }
            }
        }
        return false;
    },
 
	show : function(isButtonCreated,text,parent) {
	    multiSelectionSelf = this;
		Volt.log("[multi-selection.js] In function show");
		statusView = 'SHOW';
		if(isButtonCreated === false) {
			//set widget
			Volt.log("[multi-selection.js] set widget");
			this.widget = CommonContent.loadTemplateInWinsetBackgroud(this.template, null,parent);
	       	this.setWidget(this.widget); 
		}
		if(viewIsVisible === false) {
		  //hide category and shrink header
	        Mediator.on("UPDATE_SELECT_ALL_STATE",this.updateSelectAllState,this);
	        Mediator.on('EVENT_MULTI_SELECTION_FOCUS', this.expand, this);
	        Mediator.on('EVENT_MULTI_SELECTION_BLUR', this.shrink, this);
	        Mediator.trigger('EVENT_MAIN_CATEGORY_HIDE');
	        viewIsVisible = true;
		}
        
		if(isButtonCreated === false) {
			Volt.log("[multi-selection.js] isButtonCreated === false");
			this.selectedItemsWidget = this.widget.getDescendant('multiselection-select-items');
            this.selectedNum = this.widget.getDescendant('multiselection-select-num');
            this.selectedNum.x = this.selectedItemsWidget.x + this.selectedItemsWidget.width + Volt.sceneWidth * 0.004167;
            
			//create button
			this.selectAllBg = this.widget.getDescendant('multiselection-selectall-bg');
			this.selectAllBtn = this.createButton(this.selectAllBg,Volt.i18n.t('COM_SID_SELECT_ALL'));
			this.selectAllBtn.id="selectAll";
			
            this.isChecked = false;
	 		
			this.deleteBg = this.widget.getDescendant('multiselection-delete-bg');
			this.deleteBtn = this.createButton(this.deleteBg,text);
			this.deleteBtn.id="delete";
			this.cancelBg = this.widget.getDescendant('multiselection-cancel-bg');
			this.cancelBtn = this.createButton(this.cancelBg,Volt.i18n.t('COM_SID_CANCEL'));
			this.cancelBtn.id = "cancel";
		} else {
			Volt.log("[multi-selection.js] isButtonCreated === true");

			var lastText = this.deleteBtn.text(); 
            if(lastText !== text) {
                /*
                this.deleteBtn.setText(this.deleteBtn.btnState.NORMAL, text);
                this.deleteBtn.setText(this.deleteBtn.btnState.FOCUS, text);
                this.deleteBtn.setText(this.deleteBtn.btnState.SELECTED, text); 
                this.deleteBtn.setText(this.deleteBtn.btnState.DIM, text);
                */
                this.deleteBtn.setText({state:"all",text:text});
                this.deleteBtn.show();
            }
            this.isChecked = false;
			this.selectAllBg.focusable = true;
			this.deleteBg.focusable = true;
			this.cancelBg.focusable = true;
			Volt.Nav.reload();
		}

        this.resetHideMultiSelection();
        
		this.widget.show();
		this.disableDeleteBtn();
    },
    
	hide : function() {
	    Volt.log("[multi-selection.js] In function hide");
	    statusView = 'HIDE';
	    this.widget.hide();
	    this.shrink();
		this.selectAllBg.focusable = false;
		this.deleteBg.focusable    = false;
		this.cancelBg.focusable    = false;
		this.updateSelectNum(0);
		this.updateSelectAllState(false);
		this.setState('');
		this.lastFocusBtn = null;
		this.lastFocusWidget = null;
		this.resetHideMultiSelection();
		if(this.shrinkAnimation) {
            this.shrinkAnimation.stop();
        }
		if(this.expandAnimation) {
            this.expandAnimation.stop();
        }
        this.initPosition();
        multiSelectionSelf = null;
        viewIsVisible = false;
		
		Mediator.off("UPDATE_SELECT_ALL_STATE",null,this);
		Mediator.off('EVENT_MULTI_SELECTION_FOCUS', null, this);
        Mediator.off('EVENT_MULTI_SELECTION_BLUR', null, this);
		Volt.Nav.reload();
	},
	
	initPosition : function() {
	    var btnHeight = 1080 * 0.066667;
        this.selectedItemsWidget.y = 0;
        this.selectedNum.y = 0;
        this.widget.y = 1080 * 0.133333;
        this.selectAllBg.getChild(0).height = btnHeight;
        this.deleteBg.getChild(0).height = btnHeight;
        this.cancelBg.getChild(0).height = btnHeight;
        this.widget.height = btnHeight;
	},
	
	destroy : function(){
	    if(this.timer) {
            Volt.clearTimeout(this.timer);
            this.timer = null;
        }
	    
	    if(this.selectAllBtn) {
	        this.selectAllBtn.removeListener(this.btnListener);
	        this.selectAllBtn.destroy();
	        this.selectAllBtn = null;
	    }
	    
	    if(this.deleteBtn) {
            this.deleteBtn.removeListener(this.btnListener);
            this.deleteBtn.destroy();
            this.deleteBtn = null;
        }
	    
	    if(this.cancelBtn) {
            this.cancelBtn.removeListener(this.btnListener);
            this.cancelBtn.destroy();
            this.cancelBtn = null;
        }
	    
	    this.btnListener = null;
	    
	    this.widget.destroyChildren();
        this.widget.destroy();
        this.widget = null;
	},
	
	expand : function() {
	    if(!this.isExpand) {
	        this.isExpand = true;
	        Volt.log('[multi-selection.js] MultiSelection.expand');
	        var btnWidth = Volt.sceneWidth * 0.156250;
	        var btnHeight = 1080 * 0.1;
	        
	        if(this.shrinkAnimation) {
	            this.shrinkAnimation.stop();
	        }
            this.expandAnimation = new MultiObjectTransition();
            this.expandAnimation.setDuration(CommonDefine.Const.MENU_ANIM_DURATION);
            this.expandAnimation.AddObjectDestination(this.selectedItemsWidget, "y", 18);
            this.expandAnimation.AddObjectDestination(this.selectedNum, "y", 18);
            this.expandAnimation.AddObjectDestination(this.widget, "y", 1080 * 0.1);
            
            this.expandAnimation.AddObjectDestination(this.selectAllBg.getChild(0), "size", {w: this.selectAllBg.getChild(0).width, h:btnHeight});
            this.expandAnimation.AddObjectDestination(this.deleteBg.getChild(0), "size", {w: this.deleteBg.getChild(0).width, h:btnHeight});
            this.expandAnimation.AddObjectDestination(this.cancelBg.getChild(0), "size", {w: this.cancelBg.getChild(0).width, h:btnHeight});
            this.expandAnimation.AddObjectDestination(this.widget, "size", {w: this.widget.width, h:btnHeight});
            
            Volt.log("[multi-selection.js] setSize(" + (btnWidth) + ", " + (btnHeight) + ") for button");
            this.selectAllBtn.setSize(btnWidth, btnHeight);
            this.deleteBtn.setSize(btnWidth, btnHeight);
            this.cancelBtn.setSize(btnWidth, btnHeight);

            var animationListener = new MultiObjectTransitionListener();
            animationListener.onStoped = function(transition, isFinished){
                if(true == isFinished){
                    Volt.log("[multi-selection.js] expand animate over");
                    if(multiSelectionSelf){
                        if(multiSelectionSelf.lastFocusBtn){
                            multiSelectionSelf.lastFocusBtn.setFocus();
                        }
                        multiSelectionSelf.lastFocusInMutiSelection = true;
                    }
                }
            };
            this.expandAnimation.addListener(animationListener);
            this.expandAnimation.play();
	        /*
	        this.selectedItemsWidget.animate('y', 18, CommonDefine.Const.MENU_ANIM_DURATION);
	        this.selectedNum.animate('y', 18, CommonDefine.Const.MENU_ANIM_DURATION);
	        this.widget.animate('y', 1080 * 0.1, CommonDefine.Const.MENU_ANIM_DURATION);
//	        this.selectAllBtn.animate('scale', {x: 1, y: 1.5}, CommonDefine.Const.MENU_ANIM_DURATION, 'cubic');
//	        this.deleteBtn.animate('scale', {x: 1, y: 1.5}, CommonDefine.Const.MENU_ANIM_DURATION, 'cubic');
//	        this.cancelBtn.animate('scale', {x: 1, y: 1.5}, CommonDefine.Const.MENU_ANIM_DURATION, 'cubic');
	        
	        var tempAnimation = new Animation(CommonDefine.Const.MENU_ANIM_DURATION);
	        tempAnimation.addProperty('height', btnHeight);
	        Volt.log("[multi-selection.js] setSize(" + (btnWidth) + ", " + (btnHeight) + ") for button");
	        this.selectAllBtn.setSize(btnWidth, btnHeight);
	        this.deleteBtn.setSize(btnWidth, btnHeight);
	        this.cancelBtn.setSize(btnWidth, btnHeight);
	        this.selectAllBg.getChild(0).animate(tempAnimation, function(){
	            Volt.log("[multi-selection.js] expand animate over");
	            if(this.lastFocusBtn){
                    this.lastFocusBtn.setFocus();
                }
                this.lastFocusInMutiSelection = true;
	        }.bind(this));
	        this.deleteBg.getChild(0).animate(tempAnimation);
	        this.cancelBg.getChild(0).animate(tempAnimation);
	        this.widget.animate(tempAnimation);
	        */
	    }
    },

    shrink : function() {
        this.lastFocusInMutiSelection = false;
        if(this.isExpand) {
            this.isExpand = false;
            Volt.log('[multi-selection.js] MultiSelection.shrink');
            var btnWidth = Volt.sceneWidth * 0.156250;
            var btnHeight = 1080 * 0.066667;
            
            if(this.expandAnimation) {
                this.expandAnimation.stop();
            }
            this.shrinkAnimation = new MultiObjectTransition();
            this.shrinkAnimation.setDuration(CommonDefine.Const.MENU_ANIM_DURATION);
            this.shrinkAnimation.AddObjectDestination(this.selectedItemsWidget, "y", 0);
            this.shrinkAnimation.AddObjectDestination(this.selectedNum, "y", 0);
            this.shrinkAnimation.AddObjectDestination(this.widget, "y", 1080 * 0.133333);
            
            this.shrinkAnimation.AddObjectDestination(this.selectAllBg.getChild(0), "size", {w: this.selectAllBg.getChild(0).width, h:btnHeight});
            this.shrinkAnimation.AddObjectDestination(this.deleteBg.getChild(0), "size", {w: this.deleteBg.getChild(0).width, h:btnHeight});
            this.shrinkAnimation.AddObjectDestination(this.cancelBg.getChild(0), "size", {w: this.cancelBg.getChild(0).width, h:btnHeight});
            this.shrinkAnimation.AddObjectDestination(this.widget, "size", {w: this.widget.width, h:btnHeight});
            
            Volt.log("[multi-selection.js] setSize(" + (btnWidth) + ", " + (btnHeight) + ") for button");
            this.selectAllBtn.setSize(btnWidth, btnHeight);
            this.deleteBtn.setSize(btnWidth, btnHeight);
            this.cancelBtn.setSize(btnWidth, btnHeight);
            this.shrinkAnimation.play();
            
            /*
            this.selectedItemsWidget.animate('y', 0, CommonDefine.Const.MENU_ANIM_DURATION);
            this.selectedNum.animate('y', 0, CommonDefine.Const.MENU_ANIM_DURATION);
            this.widget.animate('y', 1080 * 0.133333, CommonDefine.Const.MENU_ANIM_DURATION);
//            this.selectAllBtn.animate('scale', {x: 1, y: 1}, CommonDefine.Const.MENU_ANIM_DURATION, 'cubic');
//            this.deleteBtn.animate('scale', {x: 1, y: 1}, CommonDefine.Const.MENU_ANIM_DURATION, 'cubic');
//            this.cancelBtn.animate('scale', {x: 1, y: 1}, CommonDefine.Const.MENU_ANIM_DURATION, 'cubic');
            var tempAnimation = new Animation(CommonDefine.Const.MENU_ANIM_DURATION);
            tempAnimation.addProperty('height', btnHeight);
            Volt.log("[multi-selection.js] setSize(" + (btnWidth) + ", " + (btnHeight) + ") for button");
            this.selectAllBtn.setSize(btnWidth, btnHeight);
            this.deleteBtn.setSize(btnWidth, btnHeight);
            this.cancelBtn.setSize(btnWidth, btnHeight);
            this.selectAllBg.getChild(0).animate(tempAnimation, function(){
                Volt.log("[multi-selection.js] shrink animate over");
            }.bind(this));
            this.deleteBg.getChild(0).animate(tempAnimation);
            this.cancelBg.getChild(0).animate(tempAnimation);
            this.widget.animate(tempAnimation);
            */
        }
    },
    
	events : {
		//'NAV_SELECT #multiselection-selectall-bg' : 'onSelect_selectall_button',
		//'NAV_SELECT #multiselection-delete-bg' : 'onSelect_delete_button',
		//'NAV_SELECT #multiselection-cancel-bg' : 'onSelect_cancel_button',
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur',
	},
	
	onFocus : function(widget) {
	    if(widget && widget.id) {
	        if(widget.id === 'multiselection-selectall-bg') {
	            Volt.log('[multi-selection.js] onFocus_selectall_button this.lastFocusInMutiSelection = ' + this.lastFocusInMutiSelection);
				var voiceGuide = Volt.i18n.t('COM_SID_SELECT_ALL');
				if(this.isChecked){
	                voiceGuide = Volt.i18n.t('SID_DESELECT_ALL_KR_CANCEL_ALL');
	            }
				voiceGuide += ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
	            VoiceGuide.getVoiceGuide(voiceGuide);
	            if(!this.selectAllBtn) {
	                return;
	            }
	            if(this.lastFocusInMutiSelection) {
	                this.selectAllBtn.setFocus();
	            } else {
	                this.lastFocusBtn = this.selectAllBtn;
	            }
	        } else if(widget.id === 'multiselection-delete-bg'){
	            Volt.log('[multi-selection.js] onFocus_delete_button this.lastFocusInMutiSelection = ' + this.lastFocusInMutiSelection);
				var voiceGuide = this.deleteBtn.text() + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
				VoiceGuide.getVoiceGuide(voiceGuide);
	            if(!this.deleteBtn) {
	                return;
	            }
	            if(this.lastFocusInMutiSelection) {
	                this.deleteBtn.setFocus();
	            } else {
	                this.lastFocusBtn = this.deleteBtn;
	            }
	        } else if(widget.id === 'multiselection-cancel-bg'){
	            Volt.log('[multi-selection.js] onFocus_cancel_button this.lastFocusInMutiSelection = ' + this.lastFocusInMutiSelection);
                var voiceGuide = Volt.i18n.t('COM_SID_CANCEL') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                VoiceGuide.getVoiceGuide(voiceGuide);
	            if(!this.cancelBtn) {
	                return;
	            }
	            if(this.lastFocusInMutiSelection) {
	                this.cancelBtn.setFocus();
	            } else {
	                this.lastFocusBtn = this.cancelBtn;
	            }
            } else {
                Volt.log("[multi-selection.js] onFocus error widget.id = " + widget.id);
                return;
            }
	        this.lastFocusWidget = widget;
	        Backbone.history.setCache(widget.id);
	    }
	},
	
	onBlur : function(widget) {
	    if(widget && widget.id) {
            if(widget.id === 'multiselection-selectall-bg') {
                Volt.log('[multi-selection.js] onBlur_selectall_button');
                if(!this.selectAllBtn) {
                    return;
                }
                this.selectAllBtn.killFocus();
            } else if(widget.id === 'multiselection-delete-bg'){
                Volt.log('[multi-selection.js] onBlur_delete_button');
                if(!this.deleteBtn) {
                    return;
                }
                this.deleteBtn.killFocus();
            } else if(widget.id === 'multiselection-cancel-bg'){
                Volt.log('[multi-selection.js] onBlur_cancel_button');
                if(!this.cancelBtn) {
                    return;
                }
                this.cancelBtn.killFocus();
            } else {
                Volt.log("[multi-selection.js] onBlur error widget.id = " + widget.id);
                return;
            }
        }
	},
	
	updateSelectNum : function(selectedNumText){
	    if(!this.selectedNum) {
	        Volt.log('[multi-selection.js] error: selectedNum is null');
	        return;
	    }
	    this.selectedNum.text = '' + selectedNumText;
	},
	
	disableDeleteBtn : function() {
		if(!this.deleteBtn) {
			return;
		}

		//this.deleteBtn.stateBorder[this.deleteBtn.btnState.DIM] = {width: 1, color : Volt.hexToRgb('#000000',10)};
		//this.deleteBtn.setTextColor(this.deleteBtn.btnState.DIM, Volt.hexToRgb('#404040',10));
		this.deleteBg.focusable = false;
		//this.deleteBtn.t_getDim();
		this.deleteBtn.enable(false);
		Volt.Nav.reload();
	},
	
	enableDeleteBtn : function() {
		if(!this.deleteBtn) {
			return;
		}
		//this.deleteBtn.t_loseDim();
		this.deleteBg.focusable = true;
		this.deleteBtn.enable(true);
		Volt.Nav.reload();
	},
	
	createButton : function(parent,text) {
		Volt.log("[multi-selection.js]In function createButton");
		var btn = new Button(MultiSelectionTemplate.generalBtn);
		btn.parent = parent;
		btn.setText({state:"all", text:text});
		btn.setFontSize({state: "all", size: 28});
		btn.setFontSize({state: "focused", size: 31});
		btn.setFontSize({state: "focused-roll-over", size: 31});
		btn.setTextColor({state: "all", color: Volt.hexToRgb('#ffffff', 100)});
		btn.setTextColor({state: "disabled", color: Volt.hexToRgb('#ffffff', 30)});
		btn.setBackgroundImage({state:"all",src:""});
		btn.setBackgroundImage({state:"focused",src:"images/" + scene.height + "/highlight/4way_focus.png"});
        btn.setBackgroundImage({state:"focused-roll-over",src:"images/" + scene.height + "/highlight/4way_focus.png"});
        btn.setBackgroundColor({state:"all",color:Volt.hexToRgb('#000000', 0)});
        
		btn.addListener(this.btnListener);
		btn.show();
		return btn;
	},
	
	prepareHideMultiSelection : function() {
	    if(this.deleteBtn) {
	        this.deleteBtn.setBackgroundImage({state:"all",src:""});
	    }
        this.lastFocusWidget = null;
	    this.lastFocusInMutiSelection = false;
	},
	
	resetHideMultiSelection : function() {
	    if(this.deleteBtn) {
	        this.deleteBtn.setBackgroundImage({state:"all",src:""});
	        this.deleteBtn.setBackgroundImage({state:"focused",src:"images/" + scene.height + "/highlight/4way_focus.png"});
	        this.deleteBtn.setBackgroundImage({state:"focused-roll-over",src:"images/" + scene.height + "/highlight/4way_focus.png"});
	    }
	},
	
	updateSelectAllState : function(checkedFlag){
	    Volt.log("[multi-selection.js] updateSelectAllState checkedFlag = " + checkedFlag);
        if (checkedFlag) {
            this.isChecked = true;
			this.selectAllBtn.setText({state:"all",text:Volt.i18n.t('SID_DESELECT_ALL_KR_CANCEL_ALL')});
        } else {
            this.isChecked = false;
            this.selectAllBtn.setText({state:"all",text:Volt.i18n.t('COM_SID_SELECT_ALL')});
        }
	},
	
	pause : function() {
	    if(statusView == 'SHOW'){
	        Volt.log('[multi-selection.js] pause~~~~~');
	        statusView = 'PAUSE';
	    }
    },
    
    resume : function() {
        if(statusView == 'PAUSE'){
            Volt.log('[multi-selection.js] resume .....');
            statusView = 'SHOW';
        }
    },
    
    isStatus : function(status) {
        Volt.log("[multi-selection.js] isStatus = " + status + " === " + statusView);
        return statusView === status;
    },
    
    getLastFocus : function() {
        return this.lastFocusWidget;
    },
    
    isLastFocus : function() {
        Volt.log("[multi-selection.js] isLastFocus = " + this.lastFocusInMutiSelection);
        return this.lastFocusInMutiSelection;
    }
});

exports = new MultiSelection;
