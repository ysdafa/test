var Backbone       = Volt.requireNoContext('lib/volt-backbone.js');
var _              = Volt.requireNoContext('modules/underscore.js')._;
var Q              = Volt.requireNoContext('modules/q.js');
var Mediator       = Volt.requireNoContext('app/common/event-mediator.js');
var PanelCommon    = Volt.requireNoContext('lib/panel-common.js');
var networkStatus  = Volt.requireNoContext('app/common/network-state.js');
var Utils          = Volt.requireNoContext('app/common/utils.js');
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var CommonContent  = Volt.requireNoContext('app/common/common-content.js');
var ErrorHandling = Volt.requireNoContext('app/common/error-handling.js');
var MyPageModel         = Volt.requireNoContext('app/models/my-page-model.js');
var UserProfileModel    = Volt.requireNoContext('app/models/user-profile-model.js');
var RegisterCouponModel = Volt.requireNoContext('app/models/coupon-box-model.js');
var CouponRegisterTemplate = Volt.requireNoContext('app/templates/1080/coupon-register-popup.js');
var localStorage      = Volt.requireNoContext("lib/volt-local-storage.js");
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');
var LoadingView    = Volt.requireNoContext('app/views/loading-view.js');

var inputBox = null;
var inputTextPopup = PanelCommon.BaseView.extend({
    template : CouponRegisterTemplate.container,
    textField : null,
    params : null,
    userToDo : null,
    winsetBackground : null,
    
    render : function() {
    },

    show : function(options, animationType) {
        Volt.log('[input-text-popup.js] show options =' + JSON.stringify(options));
        this.params = JSON.parse(options);
        this.userToDo = this.params.event;
        
        this.winsetBackground = CommonContent.loadTemplateInWinsetBackgroud(this.template);
        this.setWidget(this.winsetBackground.getChild(0));
        this.winsetBackground.show();

        this.renderTitle();
        this.renderLine();
        this.renderTextField();
        this.renderButton(options);

        Volt.Nav.setRoot(this.widget);
    },

    renderTitle : function() {
        Volt.log('[input-text-popup.js] renderTitle');
        var container = this.widget.getChild('title-container');
        container.addChild(new titleView().render(this).widget);
    },

    renderLine : function() {
        Volt.log('[input-text-popup.js] renderTitle');
        var container = this.widget.getChild('line-container');
        container.addChild(new lineView().render().widget);
    },

    renderTextField : function() {
        Volt.log('[input-text-popup.js] renderTextField');
        var container = this.widget.getChild('input-text-field-container');
        container.addChild(new textFieldView().render().widget);
    },

    renderButton : function(options) {
        Volt.log('[input-text-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        container.addChild(new buttonView().render(options).widget);
    },

    hide : function() {
        Volt.log('[input-text-popup.js] hide');

        var deferred = Q.defer();
        //Volt.Nav.focus(null);
        Volt.Nav.reset();
        CommonContent.setCurrentMSGPopup(this.params);
        if(this.winsetBackground){
            this.winsetBackground.hide();
            this.destroy(this.winsetBackground);
            this.winsetBackground.destroy();
            this.winsetBackground = null;
        }

        Mediator.off("DISABLE_DONE_BTN");
        Mediator.off("ENABLE_DONE_BTN");

        deferred.resolve();
        return deferred.promise;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                this.destroy(widget.getChild(i));
            }
        }
    },
});

//template of title area
var titleView = PanelCommon.BaseView.extend({
    template : CouponRegisterTemplate.title,

    render : function(self) {
        if (self.userToDo == 'coupon-regist') {
            CouponRegisterTemplate.title.children[0].text = Volt.i18n.t('TV_SID_REGISTER_YOUR_COUPON');
        } else {
            CouponRegisterTemplate.title.children[0].text = Volt.i18n.t('TV_SID_EDIT_YOUR_NICKNAME');
        }

        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of line area
var lineView = PanelCommon.BaseView.extend({
    template : CouponRegisterTemplate.line,
    render : function() {
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

//template of text field area
var textFieldView = PanelCommon.BaseView.extend({
    template : CouponRegisterTemplate.inputBox,

    render : function() {
        Volt.log('[input-text-popup.js] textFieldView render1');
        inputBox = PanelCommon.loadTemplate(CouponRegisterTemplate.inputBox, null, this.widget, false);
        this.setWidget(inputBox);
        this.initInputBox();
        inputBox.isShow = true;
        this.addInputBoxListener();
        inputBox.onKeyEvent = _.bind(this.onKeyEvent, this);
        return this;
    },

    events : {
        NAV_SELECT : 'onSelect',
        NAV_FOCUS : 'onFocus',
        NAV_BLUR : 'onBlur'
    },

    onSelect : function(widget) {
        Volt.log('[input-text-popup.js] textFieldView.onSelect');
        var text = inputBox.text();
        Volt.log('[input-text-popup.js] text = ' + inputBox.text());
        Utils.Timer.clearTimeOut();
    },

    onFocus : function(widget) {
        Volt.log('[input-text-popup.js] set focus');
		var voiceGuide = CouponRegisterTemplate.title.children[0].text + ',' + Volt.i18n.t('TV_SID_TEXT_BOX') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);
        //inputBox.enableFocus(true);
        inputBox.enableIME(true);
        inputBox.setFocus();
        Utils.Timer.clearTimeOut();
    },

    onBlur : function(widget) {
        Volt.log('[input-text-popup.js] onBlur lose focus');
        //inputBox.enableFocus(false);
        //inputBox.enableIME(false);
        inputBox.killFocus();
        Utils.Timer.clearTimeOut();
    },
    
    initInputBox : function(){
        Volt.log('init InputBox');
        inputBox.setText("");
       // inputBox.setFont("SamsungSmart_Light");
        inputBox.setTextMaxCount(200);
		inputBox.show();
    },
    
    addInputBoxListener : function(){
        var inputBoxListener = new InputBoxListener;
		inputBoxListener.onImeState = function(inputBox, type) {
            Volt.log('[input-box-view.js]onImeState changed, type :::'+type);
			if (type == "ime_show") {
				// ime show
				inputBox.isShow = true;
			} else if (type == "ime_hide") {
				// ime hide
				inputBox.isShow = false;
			}
		};
		inputBox.addListener(inputBoxListener);
    },
    
    onKeyEvent: function(keyCode, keyType){
        Volt.log("IME onKeyEvent. keyType is " + keyType + " keyCode is " + keyCode);
        if (keyType == Volt.EVENT_KEY_RELEASE) {
            Volt.log('keyType is Volt.EVENT_KEY_RELEASE');
            return;
        } else {
            Volt.log('keyType is Volt.EVENT_KEY_PRESS');
            switch(keyCode){
                case 65376:
                case 65421:
                    this.onIMEDone();
                    return true;
                case 65385:
                    this.onIMECancel();
                    return true;
                case Volt.KEY_JOYSTICK_DOWN:
                    this.onIMEDown();
                    return true;
                case Volt.KEY_RETURN: 
                    this.onIMEReturn();
                    return true;
                    break;
                case Volt.KEY_JOYSTICK_OK:
                    this.onIMEEnter();
                    return true;
                default: 
                    return false;
            }
        }
    },

    onIMEDone : function(){
        Volt.log('[input-text-popup.js] onKeyEvent-done text = ' + inputBox.text());
        if (inputBox.text().length === 0) {
            Mediator.trigger("DISABLE_DONE_BTN");
        } else {
            Mediator.trigger("ENABLE_DONE_BTN");
        }
        //Volt.Nav.focus(Volt.Nav.getItem(1));
    },
    
    onIMECancel : function(){
        Volt.log('[input-text-popup.js] onKeyEvent-Cancel text = ' + inputBox.text());
        var text = inputBox.text();
        var length = text.length;
        Volt.log("length is ", length);
        if (length > 0) {
            inputBox.setSelection(0, length);
            inputBox.deleteText();
        }
        Volt.Nav.focus(Volt.Nav.getItem(1));
    },
    
    onIMEDown : function(){
        Volt.log('[input-text-popup.js] onKeyEvent-Down text = ' + inputBox.text());
        if (!inputBox.isShow) {
		    if (inputBox.text().length == 0) {
				Volt.log('Move focus to Cancel Button');
				Volt.Nav.focus(Volt.Nav.getItem(1));
			} else {
				Volt.log('Move focus to Done Button');
				Mediator.trigger("ENABLE_DONE_BTN");
			}
		}
    },
    
    onIMEReturn : function(){
        Volt.log("keyCode == Volt.KEY_RETURN, Done Button");
        if(inputBox.isShow){
            Volt.log('IME show');
        } else {
            Volt.log('IME not show');
            Mediator.trigger("ENABLE_DONE_BTN");
        }
    },
    
    onIMEEnter :function(){
        if(!inputBox.isShow){
            if (inputBox.text().length == 0) {
                Volt.log('Move focus to Cancel Button');
                Volt.Nav.focus(Volt.Nav.getItem(1));
            } else {
                Volt.log('Move focus to Done Button');
                Mediator.trigger("ENABLE_DONE_BTN");
            }
        }
    }
});

//template of button area
var buttonView = PanelCommon.BaseView.extend({
    template : CouponRegisterTemplate.button,
    btnView : null,
    btnListener : new ButtonListener(),
    btn1 : null,
    btn2 : null,
    options : null,

    initialize : function() {
        Mediator.on("DISABLE_DONE_BTN", this.disableDoneBtn, this);
        Mediator.on("ENABLE_DONE_BTN", this.enableDoneBtn, this);
    },
	
    render : function(options) {
    	Volt.log('[input-text-popup.js] buttonView.render options = ' + JSON.stringify(options));
		this.options = options;
		btnView = this;
        btnView.btnListener.onButtonClicked = function(button, type) {
            if (button.id == 'doneBtn') {
                btnView.onSelectDoneButton();
            } else {
                btnView.onSelectCancelButton();
            }
        };
        var btnStyle = {
            style : CommonDefine.Winset.Button_image_O_Style_F,
            buttonType : CommonDefine.Winset.BUTTON_TEXT,
        };

        this.setWidget(PanelCommon.loadTemplate(this.template, btnStyle));
        this.btn1 = this.widget.getDescendant('doneBtn');
        this.btn2 = this.widget.getDescendant('cancelBtn');
        this.btn1.addListener(btnView.btnListener);
        this.btn2.addListener(btnView.btnListener);
        Mediator.trigger("DISABLE_DONE_BTN");
        return this;
    },

    events : {
        'NAV_FOCUS #Done' : 'onFocusDoneButton',
        'NAV_FOCUS #Cancel' : 'onFocusCancelButton',
    },

    onSelectDoneButton : function(widget) {
        Volt.log('[input-text-popup.js] buttonView.onSelectDoneButton tnView.options = ' + JSON.stringify(btnView.options));
        Mediator.trigger(CommonDefine.Event.EDIT_NICK_NAME_POPUP_YBUT);
        var optionsTemp = JSON.parse(btnView.options);
        if(optionsTemp && 'click-profile' == optionsTemp.from){
            addEventLog('NICKRQST',{cp:optionsTemp.cp,inputby:''});
        }
        Utils.Timer.clearTimeOut();
        this.putData(optionsTemp);
    },

    onSelectCancelButton : function(widget) {
        Volt.log('[input-text-popup.js] buttonView.onSelectCancelButton');
        Utils.Timer.clearTimeOut();
        Backbone.history.back();
    },

    onFocusDoneButton : function(widget) {
        Volt.log('[input-text-popup.js] buttonView.onFocusDoneButton ' + widget.id);
        var voiceGuide = Volt.i18n.t('UID_DONE') + ', ' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);

        this.btn1.setFocus();
        Utils.Timer.setTimerOut();
    },

    onFocusCancelButton : function(widget) {
        Volt.log('[input-text-popup.js] buttonView.onFocusCancelButton ' + widget.id);
        var voiceGuide = Volt.i18n.t('COM_SID_CANCEL') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);

        this.btn2.setFocus();
        Utils.Timer.setTimerOut();
    },

    putData : function(options) {
        Volt.log('[input-text-popup.js] putData options = ' + JSON.stringify(options));
        if (!networkStatus.getNetWorkState()) {
            nickNameResponse(CouponRegisterTemplate.title.children[0].text);
            Backbone.history.back();

            Volt.setTimeout( function() {
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR, '', '505');
            }.bind(this), 200);
        } else {
            var text = "123";
            var text = inputBox.text();
            Volt.log("[input-text-popup.js] text is "+ text);
            var standardText = encodeURI(text);
            Volt.log('[input-text-popup.js] standardText:::'+standardText);
            var title = CouponRegisterTemplate.title.children[0].text;
            Volt.log("[input-text-popup.js] title is "+title);

            function onSuccess(data) {
                Volt.log('The input text has been put/post successfully');
                nickNameResponse(title);
                LoadingView.hide();
                if(options && ('click-optionMenu' == options.from)){
                    addEventLog('OPTIONNICKRQST',{ cp : options.cp,inputby:'',register:'y'});
                }

                if(options && 'coupon-regist' == options.from){
                    addEventLog('COUPONRQST',{ cp : options.cp,inputby:'',register:'y',});
                }
                
                var value = JSON.parse(data);
                if (title === Volt.i18n.t('TV_SID_REGISTER_YOUR_COUPON')) {
                    LoadingView.hide();
                    var couponNum = MyPageModel.get('coupon_count');
                    couponNum++;
                    Volt.log("couponNum = " + couponNum);
                    //RegisterCouponModel.set('',text);
                    MyPageModel.set('coupon_count', couponNum);
                    Mediator.trigger(CommonDefine.Event.REGISTER_COUPON);
                } else if (title === Volt.i18n.t('TV_SID_EDIT_YOUR_NICKNAME')) {
                    if (value.rsp.hasOwnProperty('err')) {
                        Volt.log('put nick name error=======>');
                        Volt.log('desc::::::' + value.rsp.desc);
                        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_NICKNAME, '', value.rsp.desc);
                    } else {
                        Volt.log('[input-text-popup.js] put nick name right!!!!!!!!!!');
                        UserProfileModel.set('nick_name', text);
                        MyPageModel.set('nick_name', text);
                        Mediator.trigger(CommonDefine.Event.EDIT_NICK_NAME);

                        //update cache data
                        var caching = localStorage.getItem('main-category');
                        var strCaching = JSON.stringify(caching);
                        if (caching && strCaching.length > 0) {
                            var parsonCache = JSON.parse(caching);
                            var cachNickName = parsonCache.rsp.C0070.mypage.nick_name;
                            Volt.log("[input-text-popup.js] updateCache  cachNickName =" + cachNickName);
                            Volt.log("[input-text-popup.js] updateCache  realNickName =" + text);
                            if (cachNickName != text) {
                                parsonCache.rsp.C0070.mypage.nick_name = text;
                                localStorage.setItem('main-category', JSON.stringify(parsonCache));
                            }
                        }

                    }
                }
            }

            function onFail(response) {
                Volt.log('The input text put/post fail response = ' + JSON.stringify(response));
                var viewType = CommonContent.getViewType();
                LoadingView.hide();
                nickNameResponse(title);
                if(options && ('click-optionMenu' == options.from)){
                    addEventLog('OPTIONNICKRQST',{ cp : options.cp,inputby:'',register:'n'});
                }

                if(options && 'coupon-regist' == options.from){
                    addEventLog('COUPONRQST',{ cp : options.cp,inputby:'',register:'n',});
                }

				if (title === Volt.i18n.t('TV_SID_REGISTER_YOUR_COUPON')) {
					Volt.log('register coupon box');
					var messageType = CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_COUPON;
					if (response.hasOwnProperty('headers')) {
						if ('1044501' == response.headers.ErrorCode) {
							messageType = CommonDefine.MsgBoxType.MSGBOX_TYPE_INVALID_COUPON;
						}
					}

					ErrorHandling.showMessage(messageType);
				} else if(title === Volt.i18n.t('TV_SID_EDIT_YOUR_NICKNAME')){
					Volt.log('edit nick name');
					var messageType = null;
                    if (response.hasOwnProperty('headers')) {
                        if ('1044504' == response.headers.ErrorCode) {
                            //This nickname is already in use
                            messageType = CommonDefine.MsgBoxType.MSGBOX_TYPE_NICKNAME_CONFLICT;
                        }else {
                            messageType = CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_REGISTER_NICKNAME;
                        }
                        ErrorHandling.showMessage(messageType,'', response.headers.ErrorCode);
                    }
				}
            }

            if (title === Volt.i18n.t('TV_SID_REGISTER_YOUR_COUPON')) {
                LoadingView.show(CommonDefine.Const.POPUP_LOADING,true);
                RegisterCouponModel.post(standardText).then(onSuccess, onFail);
            } else if (title === Volt.i18n.t('TV_SID_EDIT_YOUR_NICKNAME')) {
                UserProfileModel.put(standardText).then(onSuccess, onFail);
            }

            Backbone.history.back();
        }
    },

    disableDoneBtn : function() {
        this.btn1.enable(false);
        var btn1tmp = this.widget.getChild('Done');
        btn1tmp.focusable = false;
        Volt.Nav.reload();
    },

    enableDoneBtn : function() {
        this.btn1.enable(true);
        var btn1tmp = this.widget.getChild('Done');
        btn1tmp.focusable = true;
        Volt.Nav.reload();
        Volt.Nav.focus(this.widget.getChild('Done'));
    },
    
    destroy : function(){
        Volt.log('[cpinstall-popup.js] buttonView destroy');
        if(this.btn1){
            this.btn1.removeListener(this.btnListener);
            this.btn1.destroy();
            this.btn1 = null;
        }
        if(this.btn2){
            this.btn2.removeListener(this.btnListener);
            this.btn2.destroy();
            this.btnListener.destroy();
            this.btn2 = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

var nickNameResponse = function(str){
    Volt.log('[input-text-popup.js] nickNameResponse ....str = ' + str);
    if(Volt.i18n.t('TV_SID_EDIT_YOUR_NICKNAME') === str){
        Mediator.trigger(CommonDefine.Event.EDIT_NICK_NAME_RESPONSE);
    }
};

var addEventLog = function(eventName,options){
    Volt.log('[input-text-popup.js] addEventLog ....eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
    if(!eventName){
        return;
    }

    Volt.KPIMapper.addEventLog(eventName, { d : options});
};

exports = inputTextPopup;
