var PanelCommon = Volt.requireNoContext('lib/panel-common.js');
var CommonDefine = Volt.requireNoContext('app/common/common-define.js');
var WinsetLoading = Volt.requireNoContext("WinsetUIElement/winsetLoading.js");
var LoadingTemplate = Volt.requireNoContext('app/templates/1080/loading-template.js');
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');
var Backbone    = Volt.requireNoContext('lib/volt-backbone.js');
var RouterController  = Volt.requireNoContext('app/controller/router-controller.js');
var CommonContent  = Volt.requireNoContext('app/common/common-content.js');
PanelCommon.mapWidget('WinsetLoading',WinsetLoading);
var Mediator          = Volt.requireNoContext('app/common/event-mediator.js');
var localStorage   = Volt.requireNoContext("lib/volt-local-storage.js");

var LoadingView = PanelCommon.BaseView.extend({
    viewIsVisiable : false,
    type : 0, //default 01 loading
    viewLoading : null,
    popupLoading : null,
    loadingView : null,
    dimWgt : null,
    data : {},
    resoultion : null,
    bNoNeedBack : false,
    eventArePair : false,

    initialize : function() {
        
        this.data.style20 = WinsetLoading.LoadingStyle.Loading_Dark_20;
        this.data.style14 = WinsetLoading.LoadingStyle.Loading_Dark_14;
        this.data.style17 = WinsetLoading.LoadingStyle.Loading_Dark_17;

        this.dimWgt = PanelCommon.loadTemplate(LoadingTemplate.dimWgt, this.data);
        this.dimWgt.addEventListener("onMouseOver", function() {
            Volt.log('[loading-view.js]onMouseOver');
        });
        this.dimWgt.hide();
        this.dimWgt.addKeyboardListener(this.renderKeyBoardListener());
        this.dimWgt.addFocusListener(this.keepingFocus());
        this.viewLoading = this.dimWgt.getDescendant('viewLoading');
        this.popupLoading = this.dimWgt.getDescendant('popupLoading');
        this.videoLoading = this.dimWgt.getDescendant('videoLoading');
    },

    renderKeyBoardListener : function(){
        var list = new KeyboardListener();
        list.onKeyPressed = function() {
            Volt.log('[loading-view.js] onKeyPressed');
            this.eventArePair = true;
        }.bind(this);
        list.onKeyReleased = function(actor,keyCode) {
            Volt.log('[loading-view.js] onKeyReleased');
            
            if(this.eventArePair != true){
                Volt.log('[loading-view.js] Press and Release are not pair,ignore the event');
                return;
            }
            
            this.eventArePair = false;
            if(keyCode == Volt.KEY_RETURN){
                if(this.bNoNeedBack){
                    Volt.log("[loading-view.js] view will stay on current view!");
                    //for loading when coupon-register 
                    this.bNoNeedBack = false;
                    this.hide();
                    Mediator.trigger(CommonDefine.Event.NO_NEED_BACK_WHEN_CUT_LOADING);
                } else {
                    Volt.log("[loading-view.js] -------------currentView "+RouterController.getCurrentView().name);
                    var cache = localStorage.getItem('main-category');
                    if(RouterController.getCurrentView().name == 'main-view'&&(!cache)){
                        Volt.log("[loading-view.js]Nav Exit Games Panel.....");
                        this.hide();
                        Volt.setTimeout(function () {
                            Volt.quit(); 
                        }, 1);
                    }else{
                        Volt.log("[loading-view.js] view will go back!!");
                        this.hide();
                        Backbone.history.back();
                    }
                    
                }
            }
        }.bind(this);
        return list;
    },
    
    keepingFocus:function(){
      var focus=new FocusListener(); 
      focus.onFocusIn = function(){
          Volt.log("[loading-view.js]------------focus in");
      }.bind(this);
      focus.onFocusOut = function(){
          Volt.log("[loading-view.js]------------focus out");
          if(this.viewIsVisiable && (this.type!=CommonDefine.Const.VIDEO_LOADING)){
              this.dimWgt.setFocus();
          }
      }.bind(this);
      return focus;
    },
    
    
    resetLoadingPos : function(parent){
        Volt.log("[loading-view.js]----------------resetLoadingPos");
        var pos = null;
        if(!parent){
            parent = scene;
            pos = {x:0,y:0};
            this.dimWgt.width = Volt.sceneWidth-1;
            this.dimWgt.height = 1080-1;
        }else{
            pos = parent.getAbsolutePosition();
            this.dimWgt.width = parent.width-1;
            this.dimWgt.height = parent.height-1;
        }
        this.dimWgt.x = pos.x;
        this.dimWgt.y = pos.y;
        //minusing one is special handing for video's black line
        this.loadingView.x = (this.dimWgt.width-301)/2;
        this.loadingView.y = (this.dimWgt.height-58)/2;
    },

    show : function(type, flag, parent) {
        Volt.log("[loading-view.js]-----------------------show");
        var voiceGuide = Volt.i18n.t('COM_TV_SID_LOADING') + ',' + Volt.i18n.t('TV_SID_PLEASE_WAIT') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);
        //hide toolTip
        CommonContent.hideToolTip();
        
        this.viewIsVisiable = true;
        if (this.type == CommonDefine.Const.VIDEO_LOADING && (type!=this.type)) { //reset the size of loading view to full screen
            this.resetLoadingPos();
            this.loadingView.stop();
        }
        this.type = type;
        if (flag) {
            this.bNoNeedBack = true;
        } else {
            this.bNoNeedBack = false;
        }
        
        switch(type) {
            case CommonDefine.Const.VIEW_LOADING:
            case CommonDefine.Const.SWITCH_WHILE_LOADING:
                this.loadingView = this.viewLoading;
                break;
            case CommonDefine.Const.POPUP_LOADING:
                this.loadingView = this.popupLoading;
                break;
            case CommonDefine.Const.VIDEO_LOADING:
                this.loadingView = this.videoLoading;
                this.resetLoadingPos(parent);
                break;
            default:
                this.loadingView = this.viewLoading;
        }
        scene.removeChild(this.dimWgt);
        scene.addChild(this.dimWgt);
        if (type == CommonDefine.Const.POPUP_LOADING) {
            this.dimWgt.getChild('pupLoadingBg').show();
        } else {
            this.dimWgt.getChild('pupLoadingBg').hide();
        }
        if(this.type!=CommonDefine.Const.VIDEO_LOADING){
            this.dimWgt.enableFocus(true);
            this.dimWgt.setFocus();
            Volt.Nav.block();
        }
        this.dimWgt.show();
        this.loadingView.play();
    },

    hide : function() {
        Volt.log("[loading-view.js]-----------------------hide");
        this.viewIsVisiable && Volt.Nav.unblock();
        this.dimWgt.enableFocus(false);
        this.dimWgt.hide();
        if (this.loadingView) {
            this.loadingView.stop();
        }
        this.viewIsVisiable = false;
    },
});

var checkTerminateApp = function(){
    Volt.log('checkTerminateApp');
    var aulAppTT = new Aul();
    if(Volt.terminatePhotoPlayerPID){
        Volt.log('terminatePkg org.tizen.photo-player-tv');
        aulAppTT.terminatePkg("org.tizen.photo-player-tv");
    }
    
    if(Volt.terminateVideoPlayerPID){
        Volt.log('terminatePkg org.tizen.video-player-tv');
        aulAppTT.terminatePkg("org.tizen.video-player-tv");
    }
};

exports =  new LoadingView();
