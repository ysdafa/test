var PanelCommon = Volt.requireNoContext('lib/panel-common.js');
var GamesMainTemplate=Volt.requireNoContext("app/templates/1080/main-template.js");
var MainCategoryModel = Volt.requireNoContext("app/models/main-category-model.js");
var CommonContent = Volt.requireNoContext('app/common/common-content.js');
var CommonFunction = Volt.requireNoContext('app/common/common-function.js');
var Backbone    = Volt.requireNoContext('lib/volt-backbone.js');
var Mediator = Volt.requireNoContext('app/common/event-mediator.js');
var NoContentView = Volt.requireNoContext('app/views/no-content-view.js');
var CommonDefine = Volt.requireNoContext('app/common/common-define.js');
var networkStatus = Volt.requireNoContext('app/common/network-state.js');

var BrandZoneView = PanelCommon.BaseView.extend({
	parent : null,
	contentWgt : null,
	viewType : 'brandzone',
	
	events : {
		'NAV_FOCUS' : 'onFocus',
		'NAV_BLUR' : 'onBlur'
	},

    initialize: function() {

    },

    render: function(parentWidget) {
        Volt.log('brandzone view render');
        this.parent = parentWidget.widget.getChild('main-content-container');
        if(MainCategoryModel.isReady()){
           this.renderContent();
        }
        else{
            var brandzoneModel = MainCategoryModel.get('brandzone');
        }
        
        return this;
    },

	renderContent : function() {
		var brandzoneModel = MainCategoryModel.get('brandzone');
        var listCnt = brandzoneModel.get('brandzone_list_cnt');
		if ( !listCnt || listCnt == 0) {
			var noContentWgtId = this.viewType;
			if (networkStatus.getNetWorkState()) {
                var textToShow = Volt.i18n.t('COM_NO_CONTENT_FOUND');
                this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;
            } else {
                var textToShow = Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>', "400");
                this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_WITH_BTN).widget;
            }

		} else {
			/*load data*/
		}
		this.setWidget(this.contentWgt);
		this.parent.addChild(this.contentWgt);
		Volt.Nav.reload();
	},

	remove : function() {
		if (this.contentWgt) {
			this.parent.removeChild(this.contentWgt);
			this.contentWgt.destroy();
			this.contentWgt = null;
		}
	},

	onFocus : function(widget) {
		Volt.log('[main-brandzone-view.js] ContentView.onFocus');
		if (widget && widget.id) {
			Volt.log('[main-brandzone-view.js] onFocus widget.id =' + widget.id);
			Backbone.history.setCache(widget.id);
		}
	},

	onBlur : function(widget) {

	},

	show : function(param, animationType) {

		if (this.contentWgt) {
			this.contentWgt.show();
			if (!(this.widget.hasOwnProperty('id') && this.widget.id == this.viewType)) {
				this.widget.focusable = true;
			}
		}
		Volt.Nav.reload();
	},

	hide : function(animationType) {
		if (this.contentWgt) {
			this.contentWgt.hide();
			if (!(this.widget.hasOwnProperty('id') && this.widget.id == this.viewType)) {
				this.widget.focusable = false;
			}
		}
	},

	getWidget : function() {

	},
});

exports = BrandZoneView;
