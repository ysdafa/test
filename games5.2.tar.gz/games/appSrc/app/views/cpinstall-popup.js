// Include libraries
var _              = Volt.requireNoContext('modules/underscore.js')._;
var Backbone       = Volt.requireNoContext('lib/volt-backbone.js');
var Q              = Volt.requireNoContext('modules/q.js');
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var CommonContent  = Volt.requireNoContext('app/common/common-content.js');
var PanelCommon    = Volt.requireNoContext('lib/panel-common.js');
var Mediator       = Volt.requireNoContext('app/common/event-mediator.js');
var CommonFucntion = Volt.requireNoContext('app/common/common-function.js');
var CPInstallPopupTemplate = Volt.requireNoContext('app/templates/1080/cpinstall-popup-template.js');
var voltApiWrapper    = Volt.requireNoContext("app/common/voltapi-wrapper.js");

var cpInstallPopup = PanelCommon.BaseView.extend({
    template : CPInstallPopupTemplate.container,
    params : null,
    progressBar : null,
    appID : null,
    timer : null,
    isShow : false,
    winsetBackground : null,
    btnView : null,

    initialize : function() {
        installPopupSelf = this;
    },
    
    render : function() {
    },

    show : function(options) {
        Volt.log('[cpinstall-popup.js] show options =' + options);
        this.startListening();
        this.params = JSON.parse(options);
        this.appID = this.params.app_id;
        
        this.winsetBackground = CommonContent.loadTemplateInWinsetBackgroud(this.template);
        this.setWidget(this.winsetBackground.getChild(0));
        this.winsetBackground.show();
        
        this.isShow = true;
        this.renderDescrption();
        this.renderProgressBar();
        this.renderButton();
        Volt.Nav.setRoot(this.widget);
        //this.setTimeOut();
    },

    startListening : function() {
        Mediator.on(CommonDefine.Event.EVENT_CLOSE_POPUP, _.bind(function() {
            //this.clearTimeOut();
           Backbone.history.back();
        }), this);
        Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgress, this);
        Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
    },

    stopListening : function() {
        Mediator.off(CommonDefine.Event.EVENT_CLOSE_POPUP,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL_PROGRESS,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL, null, this);
    },

    renderDescrption : function() {
        Volt.log('[cpinstall-popup.js] renderDescrption');
        var container = this.widget.getChild('description-container');
        var description = new descriptionView().render().widget;
        container.addChild(description);
        
        var isInUSB = voltApiWrapper.isWidgetInstalledInUSB(this.appID);
        if (isInUSB) {
            description.text = "Downloading ...\n" + Volt.i18n.t('TV_SID_NOT_REMOVE_STORAGE_USE');
            this.widget.getChild('progressbar-container').y += description.height;
            this.widget.getChild('button-container').y += description.height;
            this.widget.getChild('description-container').height += description.height;
            this.widget.height += description.height;
            description.height *= 2;
        } else {
            description.text = "Downloading ...";
        }
    },

    renderProgressBar : function() {
        var container = this.widget.getChild('progressbar-container');
        Volt.log('[cpinstall-popup.js] render single ProgressBar');
        this.progressBar = CommonContent.createProgressControl(container, 0, 0, 780, 2);
    },
    
    renderButton : function() {
        Volt.log('[cpinstall-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        container.addChild(new buttonView().render().widget);
    },

    hide : function() {
        Volt.log('[cpinstall-popup.js] hide');
        var deferred = Q.defer();
        
        //this.clearTimeOut();
        this.stopListening();
        
        if(this.btnView){
            this.btnView.destroy();
            this.btnView = null;
        }
        
        if(this.winsetBackground){
            this.winsetBackground.hide();
            this.destroy(this.winsetBackground);
            this.winsetBackground.destroy();
            this.winsetBackground = null;
        }
        this.progressBar = null;
        this.appID = null;
        this.isShow = false;
        
        deferred.resolve();
        return deferred.promise;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                temp = widget.getChild(i);
                this.destroy(temp);
            }
        }
    },

    updateProgress : function(eventInfo) {
        if (CommonFucntion.checkValid(this)) {
            Volt.log("[cpinstall-popup.js] updateProgress");
            if (CommonFucntion.checkValid(eventInfo)) {
                Volt.log("[cpinstall-popup.js] " + eventInfo.app_id + " " + eventInfo.result);
                if (eventInfo.app_id == this.appID) {
                    if (eventInfo.result <= 100) {
                        if (CommonFucntion.checkValid(this.progressBar)) {
                            this.progressBar.value = eventInfo.result * 780 / 100;
                            //this.setTimeOut();
                        }
                    }
                }
            }
        }
    },

    finishInstall : function(eventInfo) {
        if (CommonFucntion.checkValid(this)) {
            Volt.log("[cpinstall-popup.js] finishInstall");
            if (CommonFucntion.checkValid(eventInfo) && eventInfo.app_id == this.appID) {
                //this.hide();
                Backbone.history.back();
            }
        }
    },
    
    /*
    setTimeOut : function() {
        this.clearTimeOut();
        this.timer = Volt.setTimeout(function() {
            Volt.log('[cpinstall-popup.js] time out');
           Backbone.history.back();
        }, 1000 * 10);

    },

    clearTimeOut : function() {
        if (this.timer != null && this.timer != undefined) {
            Volt.clearTimeout(this.timer);
        }
    },
    */
    onKeyEvent : function (keyCode, keyType) {
        Volt.log("[cpinstall-popup.js] onKeyEvent ");
        if(keyCode == Volt.KEY_RETURN && (keyType == Volt.EVENT_KEY_PRESS || keyType == Volt.EVENT_KEY_RELEASE)){
            voltApiWrapper.cancelInstallApp(installPopupSelf.appID);
            Backbone.history.back();
            return true;
        }
    },
});

//template of description
var descriptionView = PanelCommon.BaseView.extend({
    template : CPInstallPopupTemplate.description,

    render : function() {
        this.setWidget(PanelCommon.loadTemplate(this.template));
        return this;
    }
});

var buttonView = PanelCommon.BaseView.extend({
    template : CPInstallPopupTemplate.button,
    btn1 : null,
    btnListener : new ButtonListener(),

    render : function(Parent) {
        Volt.log('[cpinstall-popup.js] buttonView.render');
        installPopupSelf.btnView = this;
        installPopupSelf.btnView.btnListener = new ButtonListener();
        installPopupSelf.btnView.btnListener.onButtonClicked=function(btn,type){
            Volt.log('[cpinstall-popup.js] buttonView.onButtonClicked btn.text =' + btn.text());
            
            voltApiWrapper.cancelInstallApp(installPopupSelf.appID);
			var data = {
				info: 'cancel Install',
				app_id: installPopupSelf.appID,
			};
			//Mediator.trigger(CommonDefine.Event.EVENT_FINISH_CPINSTALL, data);
			Backbone.history.back();
        }
        
        var btnStyle = {
			style : CommonDefine.Winset.Button_image_O_Style_F,
			buttonType : CommonDefine.Winset.BUTTON_TEXT,
        };
        
        this.setWidget(PanelCommon.loadTemplate(this.template,btnStyle));
        this.btn1= this.widget.getDescendant('cancelBtn');
        this.btn1.addListener(this.btnListener);
        return this;
    },
    
    events : {
        'NAV_FOCUS #Cancel' : 'onFocusCancelButton',
    },
    
    onFocusCancelButton : function(widget) {
        Volt.log('[cpinstall-popup.js] buttonView.onFocusCancelButton ' + widget.id);
        this.btn1.setFocus();
    },
    
    destroy : function(){
        Volt.log('[cpinstall-popup.js] buttonView destroy');
        if(this.btn1){
            this.btn1.removeListener(this.btnListener);
            this.btn1.destroy();
            this.btnListener.destroy();
            this.btn1 = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

//exports = new cpInstallPopup;
exports = cpInstallPopup; 