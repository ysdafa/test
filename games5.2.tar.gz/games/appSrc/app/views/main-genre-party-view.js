var MainGenreBaseView = Volt.requireNoContext('app/views/main-genre-base-view.js');
var PanelCommon  = Volt.requireNoContext('lib/panel-common.js');
var PartyBranchView = PanelCommon.BaseView.extend({
	viewType : "party",
	genreSubView: null,
	initialize : function() {
		Volt.log('[main-genre-party-view.js] initialize');
	},

	render : function(parentWidget) {
		Volt.log('[main-genre-party-view.js] MainView.render');
		this.genreSubView = new MainGenreBaseView();
		this.genreSubView.render(parentWidget, this.viewType);
	},
	
	show : function(){
		Volt.log('[main-genre-party-view.js] show');
		this.genreSubView.show();
	},

	hide : function(){
		Volt.log('[main-genre-party-view.js] hide');
		this.genreSubView.hide();
	},
	
});

exports = PartyBranchView;