// Include libraries
var _              		= Volt.requireNoContext('modules/underscore.js')._;
var Backbone       		= Volt.requireNoContext('lib/volt-backbone.js');
var Q                   = Volt.requireNoContext('modules/q.js');
var CommonDefine   		= Volt.requireNoContext('app/common/common-define.js');
var PanelCommon    		= Volt.requireNoContext('lib/panel-common.js');
var Mediator       		= Volt.requireNoContext('app/common/event-mediator.js');
var CommonFucntion 		= Volt.requireNoContext('app/common/common-function.js');
var DeletePopupTemplate = Volt.requireNoContext('app/templates/1080/delete-popup-template.js');
var CommonContent 		= Volt.requireNoContext('app/common/common-content.js');
var voltApiWrapper      = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var ErrorHandling       = Volt.requireNoContext('app/common/error-handling.js');
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');
var MyPageModel         = Volt.requireNoContext('app/models/my-page-model.js');

var deletePopupSelf = null;
var singleTimeID = null;
var multiTimeID = null;

var DeletePopup = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.container,
    params : null,
    totalNum : 0,
    currentNum : 0,
    progress : 0,
    progressBar : null,
    appID : null,
    isMulti : false,
    isShow : false,
    gamesID : null,
    descView : null,
    progressBarView : null,
    popupBtnView : null,
    percentTextWgt : null,
    timer: null,
    winsetBackground : null,
    isInUSB : false,
    
    render : function() {
    },

    show : function(options) {
        Volt.log('[delete-popup.js] show options =' + options);
        deletePopupSelf = this;
        this.startListening();
        this.params = JSON.parse(options);
        this.currentNum = 0;
        this.appID = this.params.app_id;
        this.gamesID = this.params.app_id;
        this.isMulti = this.params.isMulti;
        if (!this.isMulti) {
            this.totalNum = 1;
        } else {
            this.totalNum = this.appID.length;
        }
        
        this.winsetBackground = CommonContent.loadTemplateInWinsetBackgroud(this.template);
        this.setWidget(this.winsetBackground.getChild(0));
        this.winsetBackground.show();
        
        this.renderDescrption();
        this.renderProgressBar();
        this.renderButton();
        //this.checkAppStatus(this.appID);
        this.doUninstall(this.appID);
        
        this.isShow = true;
        Volt.Nav.setRoot(this.widget);
    },

    startListening : function() {
        Mediator.on(CommonDefine.Event.UNINSTALL_FAIL,this.showDeleteFailPopup,this);
        Mediator.on(CommonDefine.Event.UNINSTALL_PROGRESS, this.updateProgress, this);
        Mediator.on(CommonDefine.Event.UNINSTALL, this.finishDelete, this);
        //Mediator.on(CommonDefine.Event.UNINSTALL_FAIL_APP_NOT_EXIST, this.setTimeOut, this);
    },

    stopListening : function() {
        Mediator.off(CommonDefine.Event.UNINSTALL_FAIL,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL_PROGRESS,null, this);
        Mediator.off(CommonDefine.Event.UNINSTALL, null, this);
        //Mediator.off(CommonDefine.Event.UNINSTALL_FAIL_APP_NOT_EXIST, null, this);
    },

    renderDescrption : function() {
        Volt.log('[delete-popup.js] renderDescrption');
        var container = this.widget.getChild('description-container');
        var description = new descriptionView().render().widget;
        this.isInUSB = false;
        container.addChild(description);
        if(this.isMulti){
            this.isInUSB = this.checkUSB();
        }else {
            this.isInUSB = voltApiWrapper.isWidgetInstalledInUSB(this.appID);
        }
         
        if (this.isInUSB) {
            description.getChild(0).text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL') + "\n" + Volt.i18n.t('TV_SID_NOT_REMOVE_STORAGE_USE');
            description.getChild(0).height*=2;
            
            if(this.isMulti){
                var addedHeight = description.getChild(1).height;
                description.height += addedHeight;
                description.getChild(1).y += addedHeight;
                
                this.widget.getChild('description-container').height += addedHeight;
                this.widget.getChild('progressbar-container').y += addedHeight;
                this.widget.getChild('button-container').y += addedHeight/2;
                this.widget.height += addedHeight;
            }
            
        } else {
            description.getChild(0).text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL');
        }
    },
    
    checkUSB : function(){
        var flag = false;
        for (var i = 0; i < this.appID.length; ++i) {
            flag = voltApiWrapper.isWidgetInstalledInUSB(this.appID[i]);
            if(flag){
                break;
            }
        }
        return flag;
    },
    
    checkAppStatus : function(appID){
        Volt.log('[delete-popup.js] checkAppStatus');
        if(!this.isMulti){
            var bExist = voltApiWrapper.isInNativeGameList(appID);
            if(bExist){
                Volt.log('[delete-popup.js] appID ' + appID + " exists.");
            } else {
                Volt.log('[delete-popup.js] appID ' + appID + " does not exist.");
                this.setTimeOut();
            }
        }
    },
    
    doUninstall : function(app_ids){
        Volt.log('[delete-popup.js] doUninstall');
        var wasRet = 0;
        if (this.isMulti == false) {
            wasRet = voltApiWrapper.unInstallApp(app_ids);
        } else {
            var uninstallAppId = [];
            for ( i = 0; i < app_ids.length; i++) {
                uninstallAppId.push({
                    "app" : app_ids[i]
                });
            }

            wasRet = voltApiWrapper.unInstallMutilApps(uninstallAppId);
            
        }
        
        Volt.log("[delete-popup.js] doUninstall() wasRet : " + wasRet);
        if (-1 == wasRet) {
            //WAS abnormal
            deletePopupSelf.showDeleteFailPopup();
        } else {
            var voiceGuide = Volt.i18n.t('COM_SID_DELETING_KR_PANEL') + ',' + Volt.i18n.t('TV_SID_PLEASE_WAIT') + ', ' + Volt.i18n.t('COM_SID_CANCEL') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
            VoiceGuide.getVoiceGuide(voiceGuide);
        }
    },

    renderProgressBar : function() {
        var container = this.widget.getChild('progressbar-container');
        var progressWgt = new progressView().render().widget;
        container.addChild(progressWgt);
    },
    
    renderButton : function() {
        Volt.log('[delete-popup.js] renderButton');
        var container = this.widget.getChild('button-container');
        var btnViewWgt = new buttonView().render().widget
        container.addChild(btnViewWgt);
        if(!this.isMulti){
            btnViewWgt.hide();
        } else {
            btnViewWgt.show();
        }
    },

    hide : function() {
        Volt.log('[delete-popup.js] hide');
        var deferred = Q.defer();

        this.clearTimeOut();
        this.stopListening();
        if(this.progressBarView){
            this.progressBarView.destroy();
        }
        
        if(this.popupBtnView){
            if (Volt.i18n.t('COM_SID_CANCEL') == this.popupBtnView.btn1.text() && this.isMulti) {
                Volt.log('[delete-popup.js] panel Deactive when multi-deleting,should cancel uninstall');
                voltApiWrapper.cancelUnInstallMutilApps();
            }
            this.popupBtnView.destroy();
        }
        
        this.reset();
        if(this.winsetBackground){
            this.winsetBackground.hide();
            this.destroy(this.winsetBackground);
            this.winsetBackground.destroy();
            this.winsetBackground = null;
        }
        
        deferred.resolve();
        return deferred.promise;
    },
    
    reset : function (){
        Volt.log('[delete-popup.js] reset');
        this.appID = null;
        this.isShow = false;
        this.params = null;
        this.totalNum = 0;
        this.currentNum = 0;
        this.progress = 0;
        this.isMulti = false;
        this.gamesID = null;
        this.descView = null;
        this.progressBarView = null;
        this.popupBtnView = null;
        this.timer = null;
        this.isInUSB = false;
        
        if (multiTimeID) {
            Volt.clearInterval(multiTimeID);
            multiTimeID = null;
        }
        
        if (singleTimeID) {
            Volt.clearInterval(singleTimeID);
            singleTimeID = null;
        }
        
        deletePopupSelf = null;
    },

    destroy : function(widget) {
        if (!widget)
            return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = nChildLength - 1; i >= 0; i--) {
                temp = widget.getChild(i);
                this.destroy(temp);
            }
        }
    },
    
    onKeyEvent : function (keyCode, keyType) {
        if(keyCode == Volt.KEY_RETURN && (keyType == Volt.EVENT_KEY_PRESS || keyType == Volt.EVENT_KEY_RELEASE)){
            Volt.log("[delete-popup.js] onKeyEvent return");
             /*
            if(deletePopupSelf.popupBtnView){
                Volt.log("[delete-popup.js] return  btn1.text =" +deletePopupSelf.popupBtnView.btn1.text());
                if (Volt.i18n.t('COM_SID_CANCEL') == deletePopupSelf.popupBtnView.btn1.text()) {
                    deletePopupSelf.popupBtnView.onSelectCancelButton();
                } else if (Volt.i18n.t('COM_SID_OK') == deletePopupSelf.popupBtnView.btn1.text()) {
                    deletePopupSelf.popupBtnView.onSelectOkButton();
                }
            }
            */
            return true;
        }
    },

    updateProgress : function(eventInfo) {
        Volt.log("[delete-popup.js] updateProgress");
        if (CommonFucntion.checkValid(this) && this.isMulti == false) {
            Volt.log("[delete-popup.js] updateProgress single delete");
            if (CommonFucntion.checkValid(eventInfo)) {
                Volt.log("[delete-popup.js] updateProgress result app_id =" + eventInfo.app_id + ", " + eventInfo.result);
                if (eventInfo.app_id == this.appID) {
                    if (eventInfo.result <= 100) {
                        if (CommonFucntion.checkValid(this.progressBar)) {
                            if(eventInfo.result < 100){
                                this.progress = eventInfo.result;
                                if(!singleTimeID){
                                    singleTimeID = Volt.setInterval(function(){
                                        if(eventInfo.result < 100){
                                            var voiceGuide = Volt.i18n.t('COM_SID_DELETING_KR_PANEL') + ',' + this.progress + ',percent,' 
                                                + Volt.i18n.t('TV_SID_PLEASE_WAIT') + ', ' + Volt.i18n.t('COM_SID_CANCEL') 
                                                + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                                            VoiceGuide.getVoiceGuide(voiceGuide);
                                        }
                                    }.bind(this), 5000);
                                }
                            }else{
                                if(singleTimeID){
                                    Volt.clearInterval(singleTimeID);
                                }
                            }

                            this.progressBar.value = eventInfo.result * parseInt(Volt.sceneWidth * 0.40625) / 100;
                            if(this.percentTextWgt){
                                this.percentTextWgt.text = eventInfo.result + "%";
                            }
                            //this.setTimeOut();
                        }
                    }
                }
            }
        } else if(CommonFucntion.checkValid(this)) {
            Volt.log("[delete-popup.js] updateProgress multi delete");
            if (CommonFucntion.checkValid(eventInfo)) {
                for(var index = 0; index < this.totalNum; index ++){
                    if(this.gamesID[index] == eventInfo.app_id){
                        Volt.log("[delete-popup.js] updateProgress this.currentNum =" + this.currentNum + ",deletingAppId =" +eventInfo.app_id);
                        MyPageModel.set('uninstalling_app_id',eventInfo.app_id);
                         
                        if (eventInfo.result <= 100) {
                            if (CommonFucntion.checkValid(this.progressBar)) {
                                var progressValue = ((this.currentNum + 1)/this.totalNum) * eventInfo.result * parseInt(Volt.sceneWidth * 0.40625)/ 100;
                                if(eventInfo.result < 100){
                                    if(!multiTimeID){
                                            multiTimeID = Volt.setInterval(function(){
                                            if(eventInfo.result < 100){
                                                var num = this.currentNum + 1;
                                                var voiceGuide = Volt.i18n.t('COM_SID_DELETING_KR_PANEL') + ',' + num + ' of ' + this.totalNum
                                                    + ',' + Volt.i18n.t('TV_SID_PLEASE_WAIT') + ', ' + Volt.i18n.t('COM_SID_CANCEL') 
                                                    + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                                                VoiceGuide.getVoiceGuide(voiceGuide);
                                            }
                                        }.bind(this), 5000);
                                    }
                                }else{
                                    if(multiTimeID){
                                        Volt.clearInterval(multiTimeID);
                                    }
                                }
                        
                                if(progressValue > this.progressBar.value){
                                    this.progressBar.value = progressValue;
                                }
                                Volt.log("[delete-popup.js] updateProgress multi delete this.progressBar.value =" + this.progressBar.value);
                                //this.setTimeOut();
                            }
                        }
                    }
                    break;
                }
            }
        }
    },

    finishDelete : function(eventInfo) {
        if (CommonFucntion.checkValid(this)) {
            if (this.isMulti == false) {
                Volt.log("[delete-popup.js] finish single delete");
                if (CommonFucntion.checkValid(eventInfo) && eventInfo.app_id == this.appID) {
                    Volt.log("[delete-popup.js] finish delete.isMulti == false");
					
                    this.showDeleteSuccessPopup(eventInfo.app_id);
                }
            } else {
                Volt.log("[delete-popup.js] receive multi delete event");
                if (CommonFucntion.checkValid(eventInfo)) {
                    Volt.log("[delete-popup.js] eventInfo.app_id = ", eventInfo.app_id);
                    Volt.log("[delete-popup.js] before appID = " + this.appID);
                    MyPageModel.set('uninstalling_app_id',null);
                    for (var i = 0; i < this.appID.length; ++i) {
                        if (this.appID[i] == eventInfo.app_id) {
                            this.currentNum++;
                            if (this.currentNum > this.totalNum) {
                                this.currentNum = this.totalNum;
                            }
                            this.appID.splice(i, 1);//delete the specified item
                            Volt.log("[delete-popup.js] after appID = " + this.appID);
                            break;
                        }
                    }

                    if (CommonFucntion.checkValid(this.progressBar)) {
                        this.progressBar.value = this.currentNum * 780 / this.totalNum;
                        if (this.currentNum < this.totalNum) {
                            deletePopupSelf.descView.widget.getChild(1).text = Volt.i18n.t('COM_MIX_TOTAL_KR_OVERALL').replace('<<A>>',this.currentNum + 1).replace('<<B>>',this.totalNum);
                        }
                        
                        if(this.percentTextWgt){
                            var percent = this.currentNum/this.totalNum * 100;
                            this.percentTextWgt.text = parseInt(percent) + "%";
                        }
                        //this.setTimeOut();
                    }

                    if (this.currentNum == this.totalNum) {
                        Volt.log("[delete-popup.js] finish delete.isMulti == true");
                        /*var voiceGuide = Volt.i18n.t('TV_SID_MIX_COMPLETE').replace('<<A>>','') + this.currentNum + 'of ' 
                                         + this.totalNum + ',' + Volt.i18n.t('COM_SID_OK') + ',button.';
                        VoiceGuide.getVoiceGuide(voiceGuide);*/
                        this.showDeleteSuccessPopup(this.appID);
                    }
                }
            }
        }
    },

    showDeleteFailPopup : function(eventInfo) {
        Volt.log('[delete-popup.js] showDeleteFailPopup');
        Volt.setTimeout(function() {
            if(eventInfo){
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_DELETE,null,eventInfo.errorCode);
            } else {
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_DELETE);
            }
            
        }, 200);
        Backbone.history.back();
    },

    showDeleteSuccessPopup : function(appId) {
        Volt.log('[delete-popup.js] showDeleteSuccessPopup appId =' + appId);
        deletePopupSelf.descView.widget.getChild(0).text = Volt.i18n.t('TV_SID_DELETED_SUCCESSFULLY');
        if(!this.isMulti){
            deletePopupSelf.popupBtnView.widget.show();
        } else {
            if(this.isInUSB){
                var addedHeight = deletePopupSelf.descView.widget.getChild(1).height;
                deletePopupSelf.descView.widget.height -= addedHeight;
                deletePopupSelf.descView.widget.getChild(0).height -= addedHeight;
                deletePopupSelf.descView.widget.getChild(1).y -= addedHeight;

                deletePopupSelf.widget.getChild('description-container').height -= addedHeight;
                deletePopupSelf.widget.getChild('progressbar-container').y -= addedHeight;
                deletePopupSelf.widget.getChild('button-container').y -= addedHeight/2;
                deletePopupSelf.widget.height -= addedHeight;
                this.isInUSB = false;
            }
        }
        
        deletePopupSelf.popupBtnView.btn1.setText({
            state: "all",
            text: Volt.i18n.t('COM_SID_OK')
        });
        this.setTimeOut();
    },
    
    setTimeOut: function () {
        this.clearTimeOut();
        this.timer = Volt.setTimeout(function () {
            Volt.log('[delete-success-popup.js] time out');
            Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,null,true);
            Backbone.history.back();
        }, 1000 * 10);
    },

    clearTimeOut: function () {
        Volt.log('[delete-success-popup.js] clearTimeOut');
        if (this.timer != null && this.timer != undefined) {
            Volt.clearTimeout(this.timer);
        }
    },
});

//template of description
var descriptionView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.description,

    render : function() {
        deletePopupSelf.descView = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));
        if(!deletePopupSelf.isMulti){
            Volt.log('[delete-popup.js] descriptionView single');
            this.widget.getChild(1).hide();
        } else {
            Volt.log('[delete-popup.js] descriptionView multi');
            this.widget.getChild(1).show();
            this.widget.getChild(1).text = Volt.i18n.t('COM_MIX_TOTAL_KR_OVERALL').replace('<<A>>',deletePopupSelf.currentNum).replace('<<B>>',deletePopupSelf.totalNum);
        }
        return this;
    }
});

var progressView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.progressBar,
    
    render : function() {
        deletePopupSelf.progressBarView = this;
        this.setWidget(PanelCommon.loadTemplate(this.template));
        var progressbarWgt = this.widget.getDescendant("progressBar");
        deletePopupSelf.percentTextWgt = this.widget.getDescendant("percentText");
        Volt.log('[delete-popup.js] progressView this.progressBar =' + deletePopupSelf.progressBar);
        if(deletePopupSelf.progressBar) {
            //deletePopupSelf.progressBar.show();
        } else {
            deletePopupSelf.progressBar = CommonContent.createProgressControl(progressbarWgt, 0, 0, parseInt(Volt.sceneWidth * 0.40625), 2);
        }
        return this;
    },
    
    destroy :function (){
        if(deletePopupSelf.progressBar) {
            deletePopupSelf.progressBar.destroy();
            deletePopupSelf.progressBar = null;
        }
        if(deletePopupSelf.percentTextWgt){
            deletePopupSelf.percentTextWgt = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    },
});

var buttonView = PanelCommon.BaseView.extend({
    template : DeletePopupTemplate.button,
    btn1 : null,
    btnListener : new ButtonListener(),

    render : function() {
        Volt.log('[delete-popup.js] buttonView.render');
        deletePopupSelf.popupBtnView = this;
        
        deletePopupSelf.popupBtnView.btnListener.onButtonClicked=function(btn,type){
            Volt.log('[delete-popup.js] buttonView.onButtonClicked btn.text =' + btn.text());
            if(btn && Volt.i18n.t('COM_SID_CANCEL') == btn.text()){
                deletePopupSelf.popupBtnView.onSelectCancelButton();
            } else if(btn && Volt.i18n.t('COM_SID_OK') == btn.text()){
                deletePopupSelf.popupBtnView.onSelectOkButton();
            }
        }
        
        var btnStyle = {
            style : CommonDefine.Winset.Button_image_O_Style_F,
            buttonType : CommonDefine.Winset.BUTTON_TEXT,
        };
        
        this.setWidget(PanelCommon.loadTemplate(this.template,btnStyle));
        this.btn1= this.widget.getDescendant('cancelBtn');
        this.btn1.addListener(this.btnListener);
        return this;
    },
    
    events : {
        'NAV_FOCUS #Cancel' : 'onFocusCancelButton',
    },
    
    onFocusCancelButton : function(widget) {
        Volt.log('[delete-popup.js] buttonView.onFocusCancelButton ' + widget.id);
        var voiceGuide = Volt.i18n.t('COM_SID_CANCEL') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
        VoiceGuide.getVoiceGuide(voiceGuide);

        this.btn1.setFocus();
    },
    
    onSelectCancelButton : function(widget) {
        Volt.log('[delete-popup.js] buttonView.onSelectCancelButton');
        
        if (deletePopupSelf.isMulti == true) {
            voltApiWrapper.cancelUnInstallMutilApps();
        }
        
        Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,null,true);
        Backbone.history.back();
    },
    
    onSelectOkButton : function(widget) {
        Volt.log('[delete-popup.js] buttonView.onSelectOkButton');
        
        deletePopupSelf.clearTimeOut();
        Mediator.trigger(CommonDefine.Event.MSG_POPUP_TIMEOUT, CommonDefine.MsgBoxType.MSGBOX_TYPE_DELETE_SUNCCESS,null,true);
        Backbone.history.back();
    },
    
    destroy : function(){
        Volt.log('[delete-popup.js] buttonView destroy');
        if(this.btn1){
            this.btn1.removeListener(this.btnListener);
            this.btn1.destroy();
            this.btnListener.destroy();
            this.btn1 = null;
        }
        if(this.widget){
            this.widget.destroyChildren();
            this.widget.destroy();
            this.widget = null;
        }
    }
});

//exports = new DeletePopup;
exports = DeletePopup; 
