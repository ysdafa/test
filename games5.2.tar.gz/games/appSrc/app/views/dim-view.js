var PanelCommon = Volt.requireNoContext('lib/panel-common.js');

var gDimView = null;
var DimView = PanelCommon.BaseView.extend({
    bDimExit: null,
    initialize :function(){

    },

    show: function (params, isReturn) {
        Volt.log('[dim-view.js] show .....params = ' + JSON.stringify(params));
        var dimView = null;
        try {
            Volt.log('create dim view');
            dimView = new DimWindow({
                parent: params.parent,
                x: 0,
                y: 0,
                width: Volt.sceneWidth,
                height: 1080,
                color: { r: 0, g: 0, b: 0, a: 153 },
            });

            dimView.addEventListener("onMouseOver",function(){
                    Volt.log('[dim-view.js]onMouseOver');
            });

            //dimView.clearTransparentArea();
            var position = params.rect;
            //if dim show first ,then popup show,then we don't need to pass the rect,else we must pass
            if(position != null){
                Volt.log('[dim-view.js] show x:::'+position.x+"y::::"+position.y+"width:::"+position.w+"height::::"+position.h);
                dimView.addTransparentArea({ x: position.x, y: position.y, width: position.w, height: position.h });
            }

            dimView.show();
            this.bDimExit = true;
        } catch(e){
            //for synchronize
            Volt.log('[dim-view.js] catch error when show: ' + e);
        }
        if(isReturn === true){
            //do not change gDimView object
            return dimView;
        } else {
            gDimView = dimView;
        }
    },

    hide: function (dimView) {
        Volt.log('[dim-view.js] hide .....this.dimView = ' + gDimView);
        Volt.log('[dim-view.js] hide .....dimView = ' + dimView);
        this.bDimExit = false;
        try {
            if(dimView !== undefined){
                if(dimView) {
                    dimView.clearTransparentArea();
                    dimView.hide();
                    dimView.destroy();
                    dimView = null;
                }
            } else if(gDimView != null){
                gDimView.clearTransparentArea();
                gDimView.hide();
                gDimView.destroy();
                gDimView = null;
            }
        } catch(e){
            //for synchronize
            Volt.log('[dim-view.js] catch error when hide: ' + e);
        }
    },

    isDimExist : function(){
        Volt.log('[dim-view.js] isDimExist this.bDimExit = ' + this.bDimExit);
        return this.bDimExit;
    },
});

exports = new DimView();
