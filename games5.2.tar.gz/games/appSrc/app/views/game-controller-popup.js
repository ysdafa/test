var Q              = Volt.requireNoContext('modules/q.js');
var Backbone       = Volt.requireNoContext('lib/volt-backbone.js');
var LoadingView    = Volt.requireNoContext('app/views/loading-view.js');
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var CommonFucntion = Volt.requireNoContext('app/common/common-function.js');
var CommonContent  = Volt.requireNoContext('app/common/common-content.js');
var PanelCommon    = Volt.requireNoContext('lib/panel-common.js');
var EventMediator  = Volt.requireNoContext('app/common/event-mediator.js');
var Utils          = Volt.requireNoContext('app/common/utils.js');
var gameControllerTemplate = Volt.requireNoContext("app/templates/1080/game-controller-popup.js");
var GameControllerGuideModel    = Volt.requireNoContext('app/models/game-controller-guide-model.js');
var Gridlist                    = Volt.requireNoContext('app/views/grid-list-view.js');
var ErrorHandling = Volt.requireNoContext("app/common/error-handling.js");
var VoiceGuide    = Volt.requireNoContext('app/common/voiceGuide.js');
var DeviceModel   = Volt.requireNoContext('app/models/device-model.js');

var gameControllerGuide = PanelCommon.BaseView.extend({
    contentInstant : null,
        
    initialize : function () {
        Volt.log("[game-controller-popup.js]  initialize.....");
        this.setWidget(PanelCommon.loadTemplate(gameControllerTemplate.container, null, null, false));
    },

    show : function (id, animationType) {
        Volt.log("[game-controller-popup.js]  show.....");
        EventMediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor, this);
        this.viewIsVisible = true;
        LoadingView.show(CommonDefine.Const.POPUP_LOADING);

        if (!this.widget) {
            this.setWidget(PanelCommon.loadTemplate(gameControllerTemplate.container, null, null, false));
        }

        Volt.Nav.setRoot(this.widget);
        this.requestData();
    },

    requestData : function () {
        var that = this;
        function onSuccess() {
            Volt.log('[game-controller-popup.js] requestData onSuccess');
            LoadingView.hide();
            if (that.widget) { //To make sure the widget exists
                if (that.viewIsVisible == true) {
                    that.renderContent();
                }

                Volt.Nav.reload();
                that.widget.show();
            }
        }

        function onError(msg) {
            Volt.log("[game-controller-popup.js] requestData onError error msg-----" + JSON.stringify(msg.status));
            LoadingView.hide();
            var viewType = CommonContent.getViewType();
            if (viewType == '#popup') {
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_CONNECT_SEVER_ERROR,"",JSON.stringify(msg.status)); 
            }
        }

        GameControllerGuideModel.fetch().then(onSuccess, onError);
    },

    renderContent : function () {
        Volt.log('[game-controller-popup.js] renderContent');
        var container = this.widget.getDescendant('game-content-container');
        this.contentInstant = new contentChangeView().render(container);
    },

    onKeyEvent : function (keyCode, keyType) {
        Volt.log('[game-controller-popup.js] GameGuidePopupsKeyHandler   keyCode is :' + keyCode);
        if (keyType == Volt.EVENT_KEY_RELEASE) {
            return false;
        }

        switch (keyCode) {
        case Volt.KEY_JOYSTICK_LEFT:
        case Volt.KEY_JOYSTICK_RIGHT:{
            var gridWidget = this.widget.getDescendant('game-content-container').getChild(0);
            if(gridWidget){
                gridWidget.onKeyEvent(keyCode, keyType);
            }
            return ;
        }

        default:
            return false;
        }
    },

    onChangeCursor : function(visible){
        Volt.log('[game-controller-popup.js] onChangeCursor visible = ' + visible);
        if(visible){
            Utils.Timer.clearTimeOut();
        }else{
            Utils.Timer.setTimerOut();
        }
    },

    hide : function (animationType) {
        Volt.log("[game-controller-popup.js] hide .....");
        EventMediator.off(CommonDefine.Event.GAME_CONTROLLER_GUIDE);
        EventMediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR,null,this);

        this.viewIsVisible = false;
        LoadingView.hide();

        var deferred = Q.defer();
        if (this.widget) {
                this.widget.hide();
                Volt.setTimeout(function () {
                    this.destroy(this.widget);
                }.bind(this), 1);
        }
        deferred.resolve();
        return deferred.promise;
    },

    destroy : function (widget) {
        if (!widget)
            return;
        //remove closeButton listener
        if(this.contentInstant){
            if(this.contentInstant.closeBtn && this.contentInstant.btnListener){
                Volt.log('[game-controller-popup.js]destroy remove closeButton listener');
                this.contentInstant.closeBtn.removeListener(this.contentInstant.btnListener);
                this.contentInstant.btnListener.destroy();
                this.contentInstant.closeBtn = null;
                this.contentInstant.btnListener = null;
            }
            this.contentInstant = null;
        }
        
        this.widget.destroyChildren();
        this.widget.destroy();
        this.widget = null;
    },

});

var contentChangeView = PanelCommon.BaseView.extend({
    leftArrow : null,
    rightArrow : null,
    grid: null,
    closeBtn : null,
    btnListener : new ButtonListener(),

    initialize : function(){
        this.btnListener.onButtonClicked = function(){
            Volt.log('[game-controller-popup.js] onButtonClicked .....');
            if(this.closeBtn && this.btnListener){
                this.closeBtn.removeListener(this.btnListener);
                this.closeBtn.destroy();
                this.btnListener.destroy();
                this.closeBtn = null;
                this.btnListener = null;
            }
            
            Utils.Timer.clearTimeOut();
            Backbone.history.back();
        }.bind(this);
    },

    render : function (container) {
        if (!this.widget.created) {
            this.grid = this.initGrid(container);
            this.grid.enlargeFocusItem(0,0);
            this.grid.onFocus();

            this.grid.useMarginWhenFocusEdgeItem = false;
            this.grid.loopLeftFlag = false;
            this.grid.loopRightFlag = false;
            this.grid.rolloverEffect = false;

            container.addChild(this.grid);
            this.setWidget(this.grid);
            //page_depth
            PanelCommon.loadTemplate(gameControllerTemplate.gamePageDepth, null, container);
            //left-right arrow
            this.renderLeftRightArrow(container);
        }
        return this;
    },

    arrowShowOrHide : function(arrow,bShow){
        Volt.log('[game-controller-popup.js] arrowShowOrHide .....' );
        if(!arrow){
            Volt.log('[game-controller-popup.js] arrowShowOrHide arrowWidget did not exist ,so return! ' );
            return;
        }

        if(bShow){
            arrow.show();
        }else{
            arrow.hide();
        }
    },
    
    initGrid : function(container){
        Volt.log('[game-controller-popup.js] initGrid .....' );
        if(!container){
            Volt.log('[game-controller-popup.js] initGrid container did not exist ,so return! ' );
        }

        var gameControllerData = {
                style :CommonDefine.Const.HALO_ITEM_ALL_SAME,
                groups : [{
                    modelArr : GameControllerGuideModel.get('guide_page_list')
                }]
            };

        var gridView = new Gridlist(gameControllerTemplate.gridList, JSON.stringify(gameControllerData), Volt.sceneWidth, 771);

        gridView.setItemData = function(mustache, modelData) {
            mustache.page = modelData['page'];
            mustache.style = CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_E;
            mustache.buttonType = CommonDefine.Winset.BUTTON_TEXT;
            mustache.dim_flag = modelData['dim_flag'];
            
            var culContent = modelData['controller_url_list'];
            var bestForApp = modelData['best_for_app'];

            Volt.log('[game-controller-popup.js] dim_flag = ' + modelData['dim_flag']);
            mustache.page_text1 = specialStr(modelData['description']);
            if('Y' == mustache.dim_flag){
                mustache.page_text2 = modelData['dim_text'];
            }else{
                mustache.page_text2 = modelData['page_notice'];
            }
            
            if(culContent.length == 1){
                mustache.page_text0 = modelData['controller_name'];
                mustache.page_image0 = culContent[0]['controller_url'];
                mustache.page_image1 = modelData['controller_icon_url'];

                for(var i = 0; i < bestForApp.length; ++i){
                    mustache['best_for_app_image' + i] = bestForApp[i]['app_icon_url'];
                    mustache['page_text' + parseInt(i + 3)] = bestForApp[i]['game_title'];
                }
            }else{//make sure in pageOne
                mustache.page_text0 = Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE');
                for (var i = 0; i < culContent.length; i++) {
                     mustache['page_image' + i] = culContent[i]['controller_url'];
                    /*if (Volt.i18n.t('TV_SID_SMART_TOUCH_CONTROL') == culContent[i]['controller_name']) {
                        mustache.page_image0 = culContent[i]['controller_url'];
                    } else if (Volt.i18n.t('COM_SID_KEYBOARD_KR_KEYBOARD') == culContent[i]['controller_name']
                    || Volt.i18n.t('COM_SID_KEYBOARD_AND_MOUSE') == culContent[i]['controller_name']) {
                        mustache.page_image1 = culContent[i]['controller_url'];
                    } else if (Volt.i18n.t('COM_SID_MOBILE_APP') == culContent[i]['controller_name']) {
                        mustache.page_image2 = culContent[i]['controller_url'];
                    } else if (Volt.i18n.t('COM_SID_GAMEPAD') == culContent[i]['controller_name']) {
                        mustache.page_image3 = culContent[i]['controller_url'];
                    } else if (Volt.i18n.t('COM_SID_STANDARD_REMOTE') == culContent[i]['controller_name']) {
                        mustache.page_image4 = culContent[i]['controller_url'];
                    }*/
                }
            }
        };

        gridView.setItemTemplate = function(parent, parentWidth, parentHeight, data) {
            var pageIndex = parseInt(data.page);
            Volt.log('[game-controller-popup.js] gridView.setItemTemplate pageIndex = ' + pageIndex);
            var widget = this.setPageTemplate(pageIndex, data, parent);
            //setBackgroundColor for closeButton
            if(widget && widget.getChild(8)){
                widget.getChild(8).setBackgroundColor({state:"all",color:{ r: 33, g: 158, b: 230, a: 255 }});
            }
            
           this.modifyWidgetPos(widget,pageIndex);
            Volt.log('[game-controller-popup.js] gridView.setItemTemplate  children  ~~~~~~~~~~~~ '+parent.getChildCount());
        }.bind(this);

        gridView.itemLoaded = function(gridList,groupIndex, itemIndex){
            var data = gridList.getData(groupIndex, itemIndex);
            data.group = groupIndex;
            data.item = itemIndex;
        };
        
        gridView.itemUnloaded = function(gridList, groupIndex, itemIndex) {

        };

        gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
            Volt.log('[game-controller-popup.js] gridView.focusChanged fromItemIndex = ' + fromItemIndex + ',,,toItemIndex = ' + toItemIndex);
            if(DeviceModel.get('visibleCursor')){
                Utils.Timer.clearTimeOut();
            }else{
                Utils.Timer.setTimerOut();
            }

            var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];

            EventMediator.trigger(CommonDefine.Event.GAME_CONTROLLER_GUIDE, {
                "num" : parseInt(data.page)
            });
            
            updatePageDepth(parseInt(data.page), container.getChild('page_depth'));

            //for voice Guide
            if(toItemIndex >= 0 && toGroupIndex >= 0){
                var toItem = gridList.renderer(toGroupIndex,toItemIndex);
                if(toItem && toItem.root){
                    this.closeBtn = toItem.root.getChild(0).getChild(8);
                }
                
                if(this.closeBtn){
                    Volt.log('[game-controller-popup.js] gridView.focusChanged this.closeBtn exist,start to setFocus');
                    //Volt.Nav.focus(this.closeBtn);
                    this.closeBtn.setFocus();
                    this.closeBtn.setBackgroundImage({state:'all',src:''});
                    this.closeBtn.addListener(this.btnListener);
                }else{
                    Volt.log('[game-controller-popup.js] gridView.focusChanged this.closeBtn did not exist!');
                    return;
                }

                var currentPage = toItemIndex + 1;
                var totalPage = parseInt(GameControllerGuideModel.get('guide_page_cnt'));
                var voiceGuide = Volt.i18n.t('TV_SID_MIX_TTS_PAGE_OF').replace('<<A>>',currentPage).replace('<<B>>',totalPage) + ','; 
                if(0 == toItemIndex){
                    voiceGuide += Volt.i18n.t('COM_SID_GAME_CONTROLLER_GUIDE') + ',';
                }else{
                    voiceGuide += data.page_text0 + ',';
                }

                voiceGuide += data.page_text1 +',' + Volt.i18n.t('COM_SID_CLOSE') + ',' 
                    + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                VoiceGuide.getVoiceGuide(voiceGuide);
            }
        }.bind(this);

        gridView.disableScroll();
        return gridView.render().widget;
    },

    setPageTemplate : function(pageIndex, data, parent){
        Volt.log('[game-controller-popup.js] setPageTemplate .....pageIndex = ' + pageIndex);
        var pageTemplate = null;
        if(!pageIndex){
            return pageTemplate;
        }
        
        switch (pageIndex){
            case 1:
                pageTemplate = gameControllerTemplate.gamePageOne;
                break;
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                pageTemplate = gameControllerTemplate.gamePageTwo;
                break;
            default :
                pageTemplate = gameControllerTemplate.gamePageOne;
                break;
        }
        
        Volt.log('[game-controller-popup.js] setPageTemplate..pageTemplate = ' + JSON.stringify(pageTemplate));
        return PanelCommon.loadTemplate(pageTemplate, data, parent);
    },

    modifyWidgetPos : function(widget,pageIndex){
        Volt.log('[game-controller-popup.js] modifyWidgetPos.....pageIndex = ' + pageIndex);
        var lineSpacing = 0;
        if(widget) {
            var lineHeight = 0;
            if(1 == pageIndex){
                lineHeight  = widget.getChild(1).getLineHeight();
                widget.getChild(1).lineSpacing = Math.ceil(1080 * 0.037037) - lineHeight;
                lineSpacing = widget.getChild(1).lineSpacing;
            }else{
                widget.getChild(1).x = widget.getChild(5).x + widget.getChild(5).width + Volt.sceneWidth * 0.010417;
                lineHeight = widget.getChild(6).getLineHeight();
                widget.getChild(6).lineSpacing = Math.ceil(1080 * 0.02963) - lineHeight;
                lineSpacing = widget.getChild(6).lineSpacing;
            }
        }
        Volt.log('[game-controller-popup.js] modifyWidgetPos.....lineSpacing = ' + lineSpacing);
    },

    renderLeftRightArrow : function (container) {
        Volt.log('[game-controller-popup.js] renderLeftRightArrow .....');
        this.leftArrow = PanelCommon.loadTemplate(gameControllerTemplate.LeftArrorw, null, container);
        this.rightArrow = PanelCommon.loadTemplate(gameControllerTemplate.RightArrow, null, container);
        this.arrowShowOrHide(this.leftArrow,0);
        EventMediator.on(CommonDefine.Event.GAME_CONTROLLER_GUIDE, function (page) {
            if(1 == page.num){
                this.arrowShowOrHide(this.leftArrow,0);
            }else{
                this.arrowShowOrHide(this.leftArrow,1);
            }

            if(parseInt(GameControllerGuideModel.get('guide_page_cnt')) == page.num){
                this.arrowShowOrHide(this.rightArrow,0);
            }else{
                this.arrowShowOrHide(this.rightArrow,1);
            }
        }.bind(this));
        
        this.leftArrow.addEventListener("OnMouseOver", function () {
            this.leftArrow.opacity = 255;
        }.bind(this));

        this.leftArrow.addEventListener("OnMouseOut", function () {
            this.leftArrow.opacity = 204;
        }.bind(this));

        this.leftArrow.addEventListener('OnMouseClick', function () {
            this.widget.moveFocus("Left");
        }.bind(this));

        this.rightArrow.addEventListener("OnMouseOver", function () {
            this.rightArrow.opacity = 255;
        }.bind(this));

        this.rightArrow.addEventListener("OnMouseOut", function () {
            this.rightArrow.opacity = 204;
        }.bind(this));

        this.rightArrow.addEventListener('OnMouseClick', function () {
            this.widget.moveFocus("Right");
        }.bind(this));
    },
});

function updatePageDepth(pageIndex, container) {
    Volt.log('[game-controller-popup.js] updatePageDepth pageIndex = ' + pageIndex);

    if(!container){
        Volt.log('[game-controller-popup.js] updatePageDepth container is null just return');
        return;
    }

    var pageCnt = parseInt(GameControllerGuideModel.get('guide_page_cnt')) + 1;
    for (var index = 1; index < pageCnt; index++) {
        var childWgt = container.getChild(index - 1);
        if (index == pageIndex) {
            childWgt.src = Volt.getRemoteUrl('images/' + scene.height + '/games/g_gcg_comon_depth_h.png');
        } else {
            childWgt.src = Volt.getRemoteUrl('images/' + scene.height + '/games/g_gcg_comon_depth_n.png');
        }
    }
};

function specialStr(str){
    Volt.log('[game-controller-popup.js] specialStr str = ' + str);
    var newstr = "";
    for (var i = 0; i < str.length; i++) {
        strTemp = str.charAt(i);
        switch (strTemp) {
            case '\"':
                newstr += "\\\"";
                break;
            case '\\':
                newstr += "\\\\";
                break;
            case '/':
                newstr += "\\/";
                break;
            case '\b':
                newstr += "\\b";
                break;
            case '\f':
                newstr += "\\f";
                break;
            case '\n':
                newstr += "\\n";
                break;
            case '\r':
                newstr += "\\r";
                break;
            case '\t':
                newstr += "\\t";
                break;
            default:
                newstr += strTemp;
        }
    }
   return newstr;
};

exports = gameControllerGuide;