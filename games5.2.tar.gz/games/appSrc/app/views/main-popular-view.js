var PanelCommon        = Volt.requireNoContext('lib/panel-common.js');
var MainCategoryModel  = Volt.requireNoContext("app/models/main-category-model.js");
var CommonContent      = Volt.requireNoContext('app/common/common-content.js');

var Backbone           = Volt.requireNoContext('lib/volt-backbone.js');
var Gridlist           = Volt.requireNoContext('app/views/grid-list-view.js');
var GridlistTemplate   = Volt.requireNoContext('app/templates/1080/grid-list-template.js');
var CommonDefine       = Volt.requireNoContext('app/common/common-define.js');
var Mediator           = Volt.requireNoContext('app/common/event-mediator.js');
var MostPopularModel   = Volt.requireNoContext("app/models/most-popular-model.js");
var NoContentView      = Volt.requireNoContext('app/views/no-content-view.js');
var VoiceGuide         = Volt.requireNoContext('app/common/voiceGuide.js');
var networkStatus = Volt.requireNoContext('app/common/network-state.js');

var realDataStateInPopular = false;
var mostPopularSelf = null;

var MostPopularView = PanelCommon.BaseView.extend({
    parent : null,
    contentWgt : null,
    viewIsVisible : false,
    bListenerStatus : false,
    viewType : 'popular',

    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },

    initialize : function() {
        mostPopularSelf = this;
    },

    render : function(parentWidget) {
        Volt.log('most popular view render');
        this.parent = parentWidget.widget.getChild('main-content-container');
        this.renderContent();

        return this;
    },

    renderContent : function() {
        realDataStateInPopular = MainCategoryModel.isReady();
        var popular_list = MostPopularModel.get('popular_list');

        if (!popular_list || popular_list.length == 0) {
            var noContentWgtId = this.viewType;
            if (networkStatus.getNetWorkState()) {
                var textToShow = Volt.i18n.t('COM_NO_CONTENT_FOUND');
                this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_GENERAL).widget;
            } else {
                var textToShow = Volt.i18n.t('TV_SID_MIX_CONNECTED_FEATURE_NETWORK').replace('<<A>>', "400");
                this.contentWgt = new NoContentView().render(noContentWgtId, textToShow, CommonDefine.Const.NO_CONTENT_WITH_BTN).widget;
            }
        } else {
            this.contentWgt = this.initGrid(popular_list);
            this.contentWgt.focusable = true;
            this.contentWgt.id = "POPULAR_CONTENT";
            this.contentWgt.show();
        }
        this.parent.addChild(this.contentWgt);
        this.setWidget(this.contentWgt);
        Volt.Nav.reload();
    },

    initGrid : function(dataList) {
        var popularData = {
            style : CommonDefine.Const.HALO_ITEM_NOT_ALL_SAME,
            groups : [{
                modelArr : dataList
            }]
        };
        var gridView = new Gridlist(GridlistTemplate.Popular, JSON.stringify(popularData), parseInt(1920 * 0.16875), parseInt(1080 * 0.4));

        gridView.setItemData = function(mustache, modelData) {
            mustache.imgUrl = (modelData['thumbnail_url']) ? modelData['thumbnail_url'] : '';
            mustache.title = (modelData['game_title']) ? modelData['game_title'] : '';
            mustache.genre = (modelData['genre']) ? modelData['genre'] : '';
            mustache.app_id = (modelData['app_id']) ? modelData['app_id'] : '';
            mustache.rating = (modelData['rating']) ? modelData['rating'] : '';
            mustache.size = (modelData['size']) ? modelData['size'] : '';
            mustache.controller_list = (modelData['controller_list']) ? modelData['controller_list'] : '';
            mustache.downloadable = (modelData['downloadable']) ? modelData['downloadable'] : '';
            mustache.popup_flag = (modelData['popup_flag']) ? modelData['popup_flag'] : '';
            mustache.popup_text = (modelData['popup_text']) ? modelData['popup_text'] : '';
        };

        gridView.setItemTemplate = function(rendererInstance, parentWidth, parentHeight, data) {
            CommonContent.setBlankStyle(rendererInstance, parentWidth, parentHeight);
            CommonContent.addThumbnailListener(rendererInstance.thumbnail);
            CommonContent.setFoverFactor(rendererInstance.thumbnail, parentWidth);
            this.onItemUpdate(rendererInstance, data);
            this.onItemIconLoad(data, rendererInstance, 'NoIcon');
        };

        gridView.onItemPress = function(itemData, groupIndex, itemIndex) {
            var Renderer = this.widget.renderer(groupIndex, itemIndex);
            var spValue = Volt.KPIMapper.getSelectPosition(itemIndex + 1);
            if (itemData.popup_flag == 'Y') {
                var ErrorHandling = Volt.requireNoContext('app/common/error-handling.js');
                ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_PSN, '', itemData.popup_text);
            } else {
                CommonContent.onLaunch('G03_POPULAR', itemData.app_id, Renderer.thumbnail, spValue);
                //CommonContent.onLaunch('', itemData.app_id);
            }
        };

        gridView.fromFocusChangeStart = function(parent, parentWidth, parentHeight, data) {
            //this.onTextScrollStart(parent);
        };

        gridView.toFocusChangeEnd = function(parent, parentWidth, parentHeight, data) {
            //this.onTextScrollEnd(parent);
        };

        gridView.itemLoaded = function(gridList, groupIndex, itemIndex) {
            var data = gridList.getData(groupIndex, itemIndex);
            data.group = groupIndex;
            data.item = itemIndex;
        };
        
        gridView.itemUnloaded = function(gridList, groupIndex, itemIndex) {
            
        };

        gridView.updateElements = function(parent, data) {
            Volt.log('[most-popular-view.js] updateElements');
            this.onItemUpdate(parent, data);
            this.onItemIconLoad(data, parent, 'NoIcon');
        };

        gridView.resetElements = function(parent, data) {
            Volt.log('[most-popular-view.js] resetElements');
            this.onItemIconReset(data);
        };

        gridView.focusChanged = function(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
            Volt.log('[main-popular-view.js] gridView.focusChanged .....');
            if (toItemIndex >= 0 && toGroupIndex >= 0) {
                var data = gridList.allGroupDataArr[toGroupIndex][toItemIndex];
                Volt.pageItemIndex = toItemIndex + 1;
                var voiceText = '';
                if (-1 == fromItemIndex) {
                    voiceText += Volt.i18n.t('UID_PAN_GAMES') + ',' + Volt.i18n.t('TV_SID_MIX_CATEGORY_END').replace('<<A>>', Volt.i18n.t('COM_SID_MOSTPOPULAR_CATEGORY')) + ',' + Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', MostPopularModel.get('popular_list_cnt')) + ',';
                }

                voiceText += data.title + '.';
                VoiceGuide.getVoiceGuide(voiceText);
            }
        };

        return gridView.render().widget;
    },

    remove : function() {
        if (this.contentWgt) {
            this.parent.removeChild(this.contentWgt);
            this.contentWgt.destroy();
            this.contentWgt = null;
        }
    },

    onFocus : function(widget) {
        Volt.log('[main-popular-view.js] ContentView.onFocus');

        if (this.contentWgt) {
            widget = this.contentWgt;
            Volt.Nav.focus(this.contentWgt);
            widget.onFocus();
        }

        if (widget && widget.id) {
            Volt.log('[main-popular-view.js] onFocus widget.id =' + widget.id);
            Backbone.history.setCache(widget.id);
        }
    },

    onBlur : function(widget) {
        if (widget) {
            Volt.log('[main-popular-view.js] ContentView.onBlur');
            if (this.contentWgt) {
                this.contentWgt.onBlur();
            }
        }
    },

    show : function(param, animationType) {
        Volt.log('[main-popular-view.js] show');

        Mediator.on(CommonDefine.Const.UPDATE_ITEMS, this.updateItems, this);
        Mediator.on(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, this.updateListenerFlag, this);
        Mediator.on(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
        this.addEventListener();
        if (this.contentWgt) {
            if (this.contentWgt.hasOwnProperty('focusable')) {
                this.contentWgt.focusable = true;
            }
            if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'POPULAR_CONTENT') {
                this.contentWgt.showWithAnimation();
            } else {
                this.contentWgt.show();
            }
            this.updateItems();
        }

        this.viewIsVisible = true;
        Volt.Nav.reload();

        Volt.log('[main-popular-view.js] show realDataStateInPopular =' + realDataStateInPopular);
        var categoryState = MainCategoryModel.isReady();
        if (categoryState && (categoryState != realDataStateInPopular)) {
            this.updateContent();
        }
    },

    hide : function(animationType) {
        this.viewIsVisible = false;
        Volt.log('[main-popular-view.js] hide');
        this.removeEventListener();
        Mediator.off(CommonDefine.Const.UPDATE_ITEMS, null, this);
        Mediator.off(CommonDefine.Event.UPDATE_SUBVIEW_EVENTFLAG, null, this);
        Mediator.off(CommonDefine.Event.UPDATE_FOR_REAL_DATA, this.updateContent, this);
        if (this.contentWgt) {
            if (this.contentWgt.hasOwnProperty('focusable')) {
                this.contentWgt.focusable = false;
            }
            if (this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'POPULAR_CONTENT') {
                this.contentWgt.hideWithAnimation();
            } else {
                this.contentWgt.hide();
            }
        }
    },

    updateContent : function() {
        Volt.log('[main-popular-view.js] update content');
        realDataStateInPopular = MainCategoryModel.isReady();
        if (this.contentWgt) {
            if (this.contentWgt.id != "POPULAR_CONTENT") {
                if (realDataStateInPopular) {
                    this.remove();
                    this.renderContent();
                }
                return;
            }

            var popular_list = MostPopularModel.get('popular_list');
            CommonContent.updateData(popular_list, 0, this.contentWgt);
            this.updateItems();
        } else {
            this.renderContent();
        }
    },

    addEventListener : function() {
        Volt.log('[main-popular-view.js] addEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == false) {
            Mediator.on(CommonDefine.Event.BEGIN_DOWNLOAD, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_PROGRESS, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.DOWNLOAD_CANCELED, this.updateProgressBar, this);
            Mediator.on(CommonDefine.Event.INSTALL, this.finishInstall, this);
            this.bListenerStatus = true;
        }
    },

    removeEventListener : function() {
        Volt.log('[main-popular-view.js] removeEventListener, that.bListenerStatus = ' + this.bListenerStatus);
        if (this.bListenerStatus == true) {
            Mediator.off(CommonDefine.Event.DOWNLOAD_PROGRESS, null, this);
            Mediator.off(CommonDefine.Event.INSTALL, null, this);
            Mediator.off(CommonDefine.Event.BEGIN_DOWNLOAD, null, this);
            Mediator.off(CommonDefine.Event.DOWNLOAD_CANCELED, null, this);
            this.bListenerStatus = false;
        }
    },

    updateListenerFlag : function(flag) {
        Volt.log('[main-popular-view.js] updateListenerFlag,flag = ' + flag);
        if (flag == true) {
            this.addEventListener();
            this.updateItems();
        } else {
            this.removeEventListener();
        }
        this.bListenerStatus = flag;
    },

    updateItems : function() {
        Volt.log("[main-popular-view.js] updateAllItems~~");
        var gridCount = MostPopularModel.get('popular_list_cnt');
        if (this.contentWgt && this.contentWgt.hasOwnProperty('id') && this.contentWgt.id == 'POPULAR_CONTENT' && (gridCount > 0)) {
            this.contentWgt.updateAllItems && this.contentWgt.updateAllItems(0);
        }
    },

    getWidget : function() {
        return this.contentWgt;
    },

    updateProgressBar : function(eventInfo) {
        if (mostPopularSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-popular-view.js] updateProgressBar, ID = ' + eventInfo.app_id);
        var index;
        for ( index = 0; index < MostPopularModel.get('popular_list_cnt'); index++) {
            if (mostPopularSelf.contentWgt) {
                var data = mostPopularSelf.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
            }
        }
        Volt.log('[main-popular-view.js] index = ' + index + ', popular_list_cnt = ' + MostPopularModel.get('popular_list_cnt'));
        //update install icon
        //update progress bar
        if (index < MostPopularModel.get('popular_list_cnt') && mostPopularSelf.contentWgt) {
            var itemCount = mostPopularSelf.contentWgt.itemCount(0);
            if (index < itemCount) {
                mostPopularSelf.contentWgt.updateItem(0, index);
            }
        }
    },

    finishInstall : function(eventInfo) {
        if (mostPopularSelf.viewIsVisible == false) {
            return;
        }
        Volt.log('[main-popular-view.js] finishInstall, ID = ' + eventInfo.app_id);
        var index;
        for ( index = 0; index < MostPopularModel.get('popular_list_cnt'); index++) {
            if (mostPopularSelf.contentWgt) {
                var data = mostPopularSelf.contentWgt.getData(0, index);
                if (data.app_id == eventInfo.app_id) {
                    break;
                }
            }
        }
        Volt.log('[main-popular-view.js] index = ' + index + ', popular_list_cnt = ' + MostPopularModel.get('popular_list_cnt'));
        //update install icon
        //update progress bar
        if (index < MostPopularModel.get('popular_list_cnt') && mostPopularSelf.contentWgt) {
            var itemCount = mostPopularSelf.contentWgt.itemCount(0);
            if (index < itemCount) {
                mostPopularSelf.contentWgt.updateItem(0, index);
            }
        }
    },
});

exports = MostPopularView;
