// Require Common Modules
var Backbone       = Volt.requireNoContext('lib/volt-backbone.js');
var PanelCommon    = Volt.requireNoContext('lib/panel-common.js');
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var voltApiWrapper = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var Mediator       = Volt.requireNoContext('app/common/event-mediator.js');
var Utils          = Volt.requireNoContext('app/common/utils.js');

var CommonContent  = Volt.requireNoContext('app/common/common-content.js');
var voltapi        = Volt.requireNoContext('voltapi.js');
var GamesMainTemplate  = Volt.requireNoContext('app/templates/1080/main-template.js');
var VoiceGuide     = Volt.requireNoContext('app/common/voiceGuide.js');
var DeviceModel    = Volt.requireNoContext('app/models/device-model.js');
var dimView        = Volt.requireNoContext('app/views/dim-view.js');

var HeaderView = PanelCommon.BaseView.extend({
    isSigned : false,
    closeIcon : null,
    btnListener : new ButtonListener(),
    loginBtn : null,
    settingBtn :null,
    closeBtn : null,
    iconWidget : null,
    userIconImg :null,
    count : 0,
    offsetFlag: true,
    currentUserIcon : null,
    toolTipstr : {},
  
	initialize : function(parent) {
		this.parent = parent;
		this.startListening();
		
		var that = this;
		this.btnListener.onButtonClicked = function(button, type) {
		    Volt.log("[main-header-view.js] onButtonClicked = " + button.id);
			switch(button.id) {
				case 'login-icon':
					that.onSelectLogin();
					break;
				case 'main-header-icon-setting-image':
					button.setBackgroundImage({state:"all",src:""});
					that.onSelectSetting();
					break;
				case 'main-header-icon-close-image':
					Mediator.trigger(CommonDefine.Event.GAMES_EXIT);
                    if(Volt.exitKey){
                        Volt.log('[main-header-view.js]exitKey');
                        Volt.exitKey();
                    } else {
                        Volt.exit();
                    }
					break;
				default :
					break;
			}
		};
	},

    render : function() {
        Volt.log('[main-header-view.js] HeaderView.render');
        var that = this;
        this.widget = CommonContent.loadTemplateInWinsetBackgroud(GamesMainTemplate.header, null, this.parent).getChild(0);
		this.loginBtn = new Button(GamesMainTemplate.loginBtn);
		this.loginBtn.parent = this.widget.getDescendant('main-header-icon-login');
		this.settingBtn = new Button(GamesMainTemplate.settingBtn);
		this.settingBtn.parent =this.widget.getDescendant('main-header-icon-setting');
		this.closeBtn = new Button(GamesMainTemplate.closeBtn);
		this.closeBtn.parent =this.widget.getDescendant('main-header-icon-close');
        
        var loginWidget = this.widget.getDescendant('main-header-icon-login');
        var settingWidget = this.widget.getDescendant('main-header-icon-setting');
        var closeWidget = this.widget.getDescendant('main-header-icon-close');
        Volt.Nav.setNextItemRule(loginWidget, 'right', settingWidget);
        Volt.Nav.setNextItemRule(settingWidget, 'left', loginWidget);
        Volt.Nav.setNextItemRule(settingWidget, 'right', closeWidget);
        Volt.Nav.setNextItemRule(closeWidget, 'left', settingWidget);
        
		this.loginBtn.setBackgroundImage({state:"focused",src:"images/" + scene.height + "/highlight/4way_focus.png"});
		this.settingBtn.setBackgroundImage({state:"focused",src:"images/" + scene.height + "/highlight/4way_focus.png"});
		this.closeBtn.setBackgroundImage({state:"focused",src:"images/" + scene.height + "/highlight/4way_focus.png"});
		
		 /*
        this.loginBtn.setBackgroundImage({state:"focused-roll-over",src:"images/" + scene.height + "/highlight/4way_focus.png"});
        this.settingBtn.setBackgroundImage({state:"focused-roll-over",src:"images/" + scene.height + "/highlight/4way_focus.png"});
        this.closeBtn.setBackgroundImage({state:"focused-roll-over",src:"images/" + scene.height + "/highlight/4way_focus.png"});
        */
    	
        this.settingBtn.setIconScaleFactor({
            state : "focused-roll-over",
            scaleX : 1.1,
            scaleY : 1.1,
        });
        this.closeBtn.setIconScaleFactor({
            state : "focused-roll-over",
            scaleX : 1.1,
            scaleY : 1.1,
        }); 
		
		this.loginBtn.setIconAlpha({state:"normal",alpha:153});
		this.settingBtn.setIconAlpha({state:"normal",alpha:153});
		this.closeBtn.setIconAlpha({state:"normal",alpha:153});
		
		this.loginBtn.setIconAlpha({state:"focused",alpha:255});
		this.settingBtn.setIconAlpha({state:"focused",alpha:255});
		this.closeBtn.setIconAlpha({state:"focused",alpha:255});
		
		this.loginBtn.setIconAlpha({state:"focused-roll-over",alpha:255});
		this.settingBtn.setIconAlpha({state:"focused-roll-over",alpha:255});
		this.closeBtn.setIconAlpha({state:"focused-roll-over",alpha:255});
		
        this.loginBtn.addListener(that.btnListener);
        this.settingBtn.addListener(that.btnListener);
        this.closeBtn.addListener(that.btnListener);

        this.toolTipForMouse(this.loginBtn,this.loginBtn.parent);
        this.toolTipForMouse(this.settingBtn,this.settingBtn.parent);
        this.toolTipForMouse(this.closeBtn,this.closeBtn.parent);
        
        this.updateUserIcon();
        this.setWidget(this.widget);
        this.closeIcon = this.widget.getDescendant('main-header-icon-close');
        return this;
    },

    toolTipForMouse : function(btnWidget,btnParent){
        Volt.log('[main-header-view.js] toolTipForMouse .....btnParent.id = ' + btnParent.id);
        this.mouseListener = new MouseListener;
        this.mouseListener.onMousePointerIn = function (widget, event) {
            Volt.log('[main-header-view.js] toolTipForMouse @onMousePointerIn widget = ' + widget.parent.id);
            var AbsolutePosition = btnWidget.getAbsolutePosition();
            var textStr = '';
            switch(btnParent.id){
                case 'main-header-icon-login':{
                        textStr = Volt.i18n.t('UID_SIGN_IN');
                        if (Utils.Account.getSignState()){
                             textStr = Volt.i18n.t('UID_SIGN_OUT');
                        }
                        break;
                    }
                case 'main-header-icon-setting':
                    textStr = Volt.i18n.t('UID_OPTIONS');
                    break;
                case 'main-header-icon-close':
                    textStr = Volt.i18n.t('COM_SID_EXIT');
                    break;
                default:
                    break;
            }
            var opt = {
                    text: textStr,
                    x: AbsolutePosition.x,
                    y: AbsolutePosition.y,
                    height: btnWidget.height,
                    width: btnWidget.width,
                    direction:'up',
                    parent:btnParent,
                };
            this.toolTipstr = opt;
            CommonContent.showToolTip(opt,GamesMainTemplate);
        }.bind(this);
        this.mouseListener.onMousePointerOut = function (widget, event) {
            Volt.log('[main-header-view.js] toolTipForMouse @onMousePointerOut widget = ' + widget.parent.id);
            this.toolTipstr = {};
            CommonContent.hideToolTip();
        }.bind(this);

        btnWidget.addMouseListener(this.mouseListener);
    },
    
    startListening : function(){
        Mediator.on('EVENT_DESTROY_MULTI_SELECTION', this.showHeader,   this);
        Mediator.on('EVENT_MAIN_CATEGORY_HIDE',      this.shrinkHeader, this);
        Mediator.on('EVENT_MAIN_CATEGORY_FOCUS',     this.shrink,       this);
        Mediator.on('EVENT_MAIN_CATEGORY_BLUR',      this.expand,       this);
        Mediator.on(CommonDefine.Event.SIGN_STATE_UPDATE, this.updateUserIcon, this);
        Mediator.on(CommonDefine.Event.CHECK_USER_ICON,   this.updateUserIcon, this);
    },
    
    stopListening : function(){
        Mediator.off('EVENT_DESTROY_MULTI_SELECTION', null, this);
        Mediator.off('EVENT_MAIN_CATEGORY_HIDE',      null, this);
        Mediator.off('EVENT_MAIN_CATEGORY_FOCUS',     null, this);
        Mediator.off('EVENT_MAIN_CATEGORY_BLUR',      null, this);
        Mediator.off(CommonDefine.Event.SIGN_STATE_UPDATE, null, this);
        Mediator.off(CommonDefine.Event.CHECK_USER_ICON,   null, this);
    },
    
    updateUserIcon : function() {
        Volt.log('[main-header-view.js] updateUserIcon');
        var loginIcon = this.widget.getDescendant('login-icon');
        var signState = voltApiWrapper.getSSOLoginState();
        //var signState = Utils.Account.getSignState();
        Volt.log('[main-header-view.js] signState = ' + signState);
        
        if (signState) {
            //login in
            var accountInfo = voltApiWrapper.getSSOLoginInfo();
            Volt.log('[main-header-view.js] accountInfo = ' + accountInfo);
            if (accountInfo && accountInfo.user_icon) {
                var path = accountInfo.user_icon;
                if (path && path.length > 0) {
                    Volt.log('[main-header-view.js] path.length = ' + path.length);
                    var account_list = JSON.parse(path);
                    Volt.log('path:::' + account_list);
                    var bFound = false;
                    for (var i = 0; i < account_list.length; i++) {
                        if (account_list[i].hasOwnProperty('iconPath_60')) {
                            var userThumbnail = account_list[i].iconPath_60;
                            Volt.log('iconPath_60:::' + userThumbnail);
                            Volt.log('currentUserIcon:::' + this.currentUserIcon);
                            if(this.currentUserIcon){
                                if(this.currentUserIcon !== userThumbnail){
                                    Volt.log('[main-header-view.js] user changed ');
                                    if (this.userIconImg) {
                                        this.destroyUserIconWgt();
                                    }
                                }
                            }
                            this.currentUserIcon = userThumbnail;
                            
                            if (userThumbnail && userThumbnail.length > 0) {
                                bFound = true;
                                if (this.userIconImg) {
                                    if(this.iconWidget){
                                        this.iconWidget.show();
                                    }
                                    this.userIconImg.show();
                                } else {
                                    
                                    var tempImageWgt = new ImageWidgetEx({
                                        parent : scene,
                                        x : 0,
                                        y : 0,
                                        width : 0,
                                        height : 0,
                                        src : ""
                                    });

                                    Volt.log('currentUserIcon:::' + tempImageWgt.setMaskImage + ",typeof(setMaskImage) :: " + typeof (tempImageWgt.setMaskImage));
                                    
                                    if (tempImageWgt.setMaskImage && typeof (tempImageWgt.setMaskImage) == "function") {
                                        this.setMaskIcon(loginIcon,userThumbnail);
                                    } else {
                                        this.setNoMaskIcon(loginIcon,userThumbnail);
                                    }
                                    
                                    tempImageWgt.destroy();
                                    //this.setNoMaskIcon(loginIcon,userThumbnail);
                                }
                            }
                            break;
                        }
                    }

                    if (!bFound) {
                        //login in but no iconPath_70 property
                        Volt.log('[main-header-view.js] no iconPath_60 property');
                        this.setDefaultLoginIcon(loginIcon);
                    }
                } else {
                    //login in but path.length == 0
                    Volt.log('[main-header-view.js] login in but path.length is 0');
                    this.setDefaultLoginIcon(loginIcon);
                }
            } else {
                this.setDefaultLoginIcon(loginIcon);
            }

        } else {
            //login out
            if (this.userIconImg) {
                this.destroyUserIconWgt();
                this.currentUserIcon = null;
            }

            loginIcon.setIconImage({
                state : "all",
                src : Volt.getRemoteUrl('images/' + scene.height + '/common/g_state_logout.png')
            });
        }
    },
    
    setMaskIcon : function(parent,userThumbnail){
        Volt.log("[main-header-view.js]setMaskIcon");
        this.userIconImg = new ImageWidgetEx({
            parent : parent,
            x : (Volt.sceneWidth * 0.052083 - 60) / 2,
            y : (1080 * 0.133333 - 60) / 2,
            width : 60,
            height : 60,
            src : Volt.getAbsolutePath(userThumbnail)
        });
        this.userIconImg.show();
        this.userIconImg.setMaskImage(Volt.getRemoteUrl('images/' + scene.height + '/common/g_state_login_bg.png'),0,0);
        Volt.log("[main-header-view.js]setMaskIcon end");
    },
    
    setNoMaskIcon : function(parent,userThumbnail){
        Volt.log("[main-header-view.js]setNoMaskIcon");
        this.iconWidget = new WidgetEx({
            parent : parent,
            x : 20,
            y : 42,
            width : 60,
            height : 60,
            cropOverflow : true,
            roundedCorners : {
                radius : 30.0,
                arcStep : 0.1
            },
        });
        this.userIconImg = new ImageWidgetEx({
            parent : this.iconWidget,
            x : 0,
            y : 0,
            width : 60,
            height : 60,
            src : Volt.getAbsolutePath(userThumbnail)
        });
    },
    
    setDefaultLoginIcon : function(loginIcon){
        Volt.log("[main-header-view.js]setDefaultLoginIcon");
        loginIcon.setIconImage({
            state : "all",
            src : Volt.getRemoteUrl('images/' + scene.height + '/dummy/id_image_01.png')
        });
    },
    
    destroyUserIconWgt :function(){
        Volt.log("[main-header-view.js]destroyUserIconWgt");
        this.userIconImg.destroy();
        if(this.iconWidget){
            this.iconWidget.destroy();
        }
        this.userIconImg = null;
        this.iconWidget = null;
    },

    onChangeCursor : function(visible) {
        Volt.log("[main-header-view.js]visible is " + visible);
        var LoadingView    = Volt.requireNoContext('app/views/loading-view.js');
        var bPanelActive = CommonContent.getPanelActive();
        if (this.closeIcon && bPanelActive && !LoadingView.viewIsVisiable) {
            if (visible) {
                this.widget.getDescendant('main-header-icon-login').x = 1;
                this.widget.getDescendant('main-header-icon-setting').x = 1 + Volt.sceneWidth * 0.052083;
                this.widget.getDescendant('main-header-line').opacity = 25;
                this.closeIcon.show();
                this.offsetFlag = false;
                this.widget.getDescendant('main-header-icon-close').focusable = true;
                Volt.Nav.reload();
            } else {
                this.widget.getDescendant('main-header-icon-login').x = 1 + Volt.sceneWidth * 0.052083;
                this.widget.getDescendant('main-header-icon-setting').x = 1 + Volt.sceneWidth * 0.052083 * 2;
                this.widget.getDescendant('main-header-line').opacity = 0;
                this.closeIcon.hide();
                this.offsetFlag = true;
                this.widget.getDescendant('main-header-icon-close').focusable = false;
                Volt.Nav.reload();
                
                var focusedWidget = Volt.Nav.getFocusedWidget();
                if (focusedWidget && focusedWidget.hasOwnProperty('id')) {
                    if(focusedWidget.id == 'main-header-icon-setting' 
                        || focusedWidget.id == 'main-header-icon-close'){
                        Volt.Nav.focus(this.widget.getDescendant('main-header-icon-setting'));
                        var AbsolutePosition = this.settingBtn.getAbsolutePosition();
                        var opt = {
                            text: Volt.i18n.t('UID_OPTIONS'),
                            x: AbsolutePosition.x,
                            y: 55,
                            height: this.settingBtn.height,
                            width: this.settingBtn.width,
                            direction:'up',
                            parent:this.widget.getDescendant('main-header-icon-setting'),
                        };
                        this.toolTipstr = opt;
                        this.toolTipstr.x = 1821;
                        CommonContent.showToolTip(opt,GamesMainTemplate);
                    }else if(focusedWidget.id == 'main-header-icon-login'){
                        var signState = Utils.Account.getSignState();
                        var AbsolutePosition = this.loginBtn.getAbsolutePosition();
                        var opt = {
                            text: Volt.i18n.t('UID_SIGN_IN'),
                            x: AbsolutePosition.x,
                            y: 55,
                            height: this.loginBtn.height,
                            width: this.loginBtn.width,
                            direction:'up',
                            parent:this.widget.getDescendant('main-header-icon-login'),
                        };
                        if (signState){
                            opt.text = Volt.i18n.t('UID_SIGN_OUT');
                             this.toolTipstr.text = Volt.i18n.t('UID_SIGN_OUT');
                        }
                        
                        this.toolTipstr = opt;
                        this.toolTipstr.x = 1721;
                        CommonContent.showToolTip(opt,GamesMainTemplate);
                    }
                }
            }
            if(!dimView.isDimExist()){
                this.updateToolTip();
            }
        }
    },
    	
    events : {
        'NAV_FOCUS' : 'onFocus',
        'NAV_BLUR' : 'onBlur'
    },
    
    onFocus : function(widget) {
        Volt.log('[main-header-view.js] HeaderView.focus ' + widget.id);

        if (widget && widget.id) {
            Volt.log("[main-header-view.js] focused :" + widget.id);
            if(widget.id == 'main-header-icon-setting') {
                this.settingBtn.setFocus();
                var AbsolutePosition = this.settingBtn.getAbsolutePosition();
                var opt = {
                    text: Volt.i18n.t('UID_OPTIONS'),
                    x: AbsolutePosition.x,
                    y: AbsolutePosition.y,
                    height: this.settingBtn.height,
                    width: this.settingBtn.width,
                    direction:'up',
                    parent:this.widget.getDescendant('main-header-icon-setting'),
                };
                this.toolTipstr = opt;
                CommonContent.showToolTip(opt,GamesMainTemplate);
                var voiceGuide = Volt.i18n.t('UID_OPTIONS') + ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON')+ '.';
                VoiceGuide.getVoiceGuide(voiceGuide);
            
                if(this.count <= 0){
                    CommonContent.setHeaderSettingWidget(widget);
                }
                this.count ++;
                
                if(CommonContent.getOptionEditNickName()){
                    var params = {
                        "event" : "edit-name",
                        "type" : 'input-text',
                        'cp' : Volt.KPIMapper.getPageEvent().pageEvent,
                        'from' : 'click-optionMenu',
                    };
                    Backbone.history.navigate('popup/' + JSON.stringify(params), {
                        trigger : true
                    });
                    CommonContent.setOptionEditNickName(false);
                }
            }
            if(widget.id == 'main-header-icon-login') {
                var AbsolutePosition = this.loginBtn.getAbsolutePosition();
                this.loginBtn.setFocus();
                var opt = {
                    text: Volt.i18n.t('UID_SIGN_IN'),
                    x: AbsolutePosition.x,
                    y: 55,
                    height: this.loginBtn.height,
                    width: this.loginBtn.width,
                    direction:'up',
                    parent:this.widget.getDescendant('main-header-icon-login'),
                };

                var signState = Utils.Account.getSignState();
                if (signState){
                    opt.text = Volt.i18n.t('UID_SIGN_OUT');
                }
                this.toolTipstr = opt;
                CommonContent.showToolTip(opt,GamesMainTemplate);

                var voiceText = '';
                if(signState){
                    voiceText = Volt.i18n.t('UID_SIGN_OUT');
                }else{
                    voiceText = Volt.i18n.t('UID_SIGN_IN');
                }
                voiceText += ',' + Volt.i18n.t('COM_IDS_CATEGORY_CALENDAR_BUTTON') + '.';
                VoiceGuide.getVoiceGuide(voiceText);
                }

            if(widget.id == 'main-header-icon-close') {
                Volt.log('[main-header-view.js]main-header-icon-close button OnMouseOver');
                if(this.offsetFlag){
                    Volt.Nav.focus(this.widget.getDescendant('main-header-icon-setting'));
                }else{
                    var AbsolutePosition = this.closeIcon.getAbsolutePosition();
                    var opt = {
                        text: Volt.i18n.t('COM_SID_EXIT'),
                        x: AbsolutePosition.x,
                        y: AbsolutePosition.y,
                        height: this.closeIcon.height,
                        width: this.closeIcon.width,
                        direction:'up',
                        parent:this.widget.getDescendant('main-header-icon-close'),
                    };
                    this.toolTipstr = opt;
                    CommonContent.showToolTip(opt,GamesMainTemplate);
                    this.closeBtn.setFocus();
                }
            }
        }
    },

    onBlur : function(widget) {
        if (widget) {
			
            Volt.log('[main-header-view.js] HeaderView.onBlur ' + widget.id);
			if(widget.id == 'main-header-icon-setting') {
                this.toolTipstr = {};
				CommonContent.hideToolTip();
			}
			if(widget.id == 'main-header-icon-login') {
                this.toolTipstr = {};
				CommonContent.hideToolTip();
			}
			if(widget.id == 'main-header-icon-close') {
				Volt.log('[main-header-view.js]main-header-icon-close button OnMouseOut');
                this.toolTipstr = {};
				CommonContent.hideToolTip();
			}
        }
    },
    //show popup view example when click login button
    onSelectLogin : function() {
        Volt.log('[main-header-view.js] HeaderView.onSelectLogin');
        //add event log
		this.addEventLog('JUMPSSO',{cp : '',ssoby: 'header',inputby:'',});
        voltApiWrapper.startSSOPopup();
    },

    //show msgbox example when click plus button
    onSelectSetting : function() {
        Volt.log('[main-header-view.js] HeaderView.onSelectSetting');
		CommonContent.hideToolTip();
		//add event log
		this.addEventLog('OPTIONCLICK',{cp : '',inputby:'',});
        Mediator.trigger(CommonDefine.Event.OPTION_MENU_POPUP);
    },

    expand : function() {
        Volt.log('[main-header-view.js] HeaderView.expand');
        this.widget.animate('y', 0, CommonDefine.Const.MENU_ANIM_DURATION);
    },

    shrink : function() {
        Volt.log('[main-header-view.js] HeaderView.shrink');

        this.widget.animate('y', -18, CommonDefine.Const.MENU_ANIM_DURATION);
    },
    onMouseOver : function() {
      Volt.log("[multi-selection.js] onMouseOver");
    },
    shrinkHeader : function() {
    	Volt.log('[main-header-view.js] shrinkHeader');
        Mediator.off('EVENT_MAIN_CATEGORY_FOCUS', null, this);
        Mediator.off('EVENT_MAIN_CATEGORY_BLUR', null, this);
        Mediator.on('EVENT_MULTI_SELECTION_FOCUS', this.shrink, this);
        Mediator.on('EVENT_MULTI_SELECTION_BLUR', this.expand, this);
        this.loginBtn.enable(false);
        this.settingBtn.enable(false);
        this.closeBtn.enable(false);
        this.widget.getDescendant('main-header-icon-login').focusable = false;
        this.widget.getDescendant('main-header-icon-setting').focusable = false;
        this.widget.getDescendant('main-header-icon-close').focusable = false;
        this.widget.getDescendant('main-header-dim').color = { r: 0, g: 0, b: 0, a: 153 };
        this.widget.getDescendant('main-header-dim').addEventListener('OnMouseOver',this.onMouseOver); 
        Volt.Nav.reload();
    },
    showHeader : function() {
        this.loginBtn.enable(true);
        this.settingBtn.enable(true);
        this.closeBtn.enable(true);
        this.widget.getDescendant('main-header-icon-login').focusable = true;
        this.widget.getDescendant('main-header-icon-setting').focusable = true;
        this.widget.getDescendant('main-header-icon-close').focusable = true;
        Mediator.off('EVENT_MULTI_SELECTION_FOCUS', null, this);
        Mediator.off('EVENT_MULTI_SELECTION_BLUR', null, this);
        Mediator.on('EVENT_MAIN_CATEGORY_FOCUS', this.shrink, this);
        Mediator.on('EVENT_MAIN_CATEGORY_BLUR', this.expand, this);
        this.widget.getDescendant('main-header-dim').color = { r: 0, g: 0, b: 0, a: 0 };
        this.widget.getDescendant('main-header-dim').removeEventListener('OnMouseOver',this.onMouseOver); 
        Volt.Nav.reload();
        Volt.Nav.focus(this.widget.getDescendant('main-header-icon-setting'));
    },

	addEventLog : function(eventName,options){
		Volt.log('[main-header-view.js] addEventLog eventName = ' + eventName + ',,,options = ' + JSON.stringify(options));
		Volt.KPIMapper.addEventLog(eventName, {d : options});
	},
	
	show : function() {
	    this.loginBtn.enable(true);
        this.settingBtn.enable(true);
        this.closeBtn.enable(true);
        this.onChangeCursor(DeviceModel.get('visibleCursor'));
        Mediator.on(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor, this);
	},
	
	hide : function() {
	    this.loginBtn.enable(false);
        this.settingBtn.enable(false);
        this.closeBtn.enable(false);
        Mediator.off(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, null, this);
        this.count = 0;
        this.toolTipstr = {};
	},

    updateToolTip: function(){
        if (this.toolTipstr && this.toolTipstr.hasOwnProperty('text')) {
            this.toolTipstr.direction = 'up';
            CommonContent.hideToolTip();
            CommonContent.showToolTip(this.toolTipstr,GamesMainTemplate);
        }
    }

});

exports = HeaderView; 