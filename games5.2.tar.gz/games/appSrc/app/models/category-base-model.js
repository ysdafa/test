var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
/** @lends GamesModel.prototype */
var CategoryBaseModel = Backbone.Model.extend({
    defaults: {
        'no' : null,
        'name' : null, 
        'id' : null, 
        //'order' : null, 
    }
        
});
exports = CategoryBaseModel;