var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var YouTuBeTraillerListModel = Backbone.Model.extend({
    defaults : {
          'trailer_id_kpi':null,
          'screenshot_url' : null, 
          'trailer_id' : null,
          'trailer_title' : null,
          'cp_logo_url':null
    },
    initialize : function(models, options) {

    },
    parse : function(response) {

    }
})

var initialize = function() {

}
function onKeyEvent(keycode) {

}

exports = YouTuBeTraillerListModel; 