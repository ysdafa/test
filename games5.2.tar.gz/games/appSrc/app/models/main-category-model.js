var Q 				  = Volt.requireNoContext('modules/q.js');
var Backbone 		  = Volt.requireNoContext("lib/volt-backbone.js");
var SpotLightModel 	  = Volt.requireNoContext('app/models/spotlight-model.js');
var WhatsNewModel 	  = Volt.requireNoContext('app/models/whats-new-model.js');
var MostPopularModel  = Volt.requireNoContext('app/models/most-popular-model.js');
var TopGrossingModel  = Volt.requireNoContext('app/models/top-grossing-model.js');
var MyPageModel 	  = Volt.requireNoContext('app/models/my-page-model.js');
var BrandZoneModel	  =Volt.requireNoContext('app/models/brand-zone-model.js');
//var GenreModel = Volt.requireNoContext('app/models/genre-list-model.js');
var GenreModel = Volt.requireNoContext('app/models/genre-detail-model.js');
var ServerController  = Volt.requireNoContext('app/controller/server-controller.js');
var localStorage 	  = Volt.requireNoContext("lib/volt-local-storage.js");
var bAPIReady 		  = false;

var MainCategoryModel = Backbone.Model.extend({
	defaults : {
		'spotlight' : null, //'ok'
		'popular' : null, //"Merry Charistmas"
		'whatsnew' : null,
		'grossing' : null,
		'arcade' : null,
		'party' : null,
		'puzzle' : null,
		'sports' : null,
		'shooting' : null,
		'mypage' : null,
		'brandzone' : null,
		'rpg'       : null,
		'category' : null,
		'categoryName' : null,
		'lastCategory' : '',
		'ready' : null,
	},
	ready : function() {
		bAPIReady = true;
		this.set('ready', true);
	},
	isReady : function() {
		return bAPIReady;
	},

	initialize : function() {
		this.set('spotlight', SpotLightModel);
		this.set('popular', MostPopularModel);
		this.set('whatsnew', WhatsNewModel);
		this.set('grossing', TopGrossingModel);
		this.set('arcade', new GenreModel());
		this.set('party', new GenreModel());
		this.set('puzzle', new GenreModel());
		this.set('sports', new GenreModel());
		this.set('shooting', new GenreModel());
		this.set('mypage', MyPageModel);
		this.set('brandzone', BrandZoneModel);
		this.set('rpg',new GenreModel());
	},

	offline: function(data) {
		Volt.log('[main-category-view.js] offline');
        var deferred = Q.defer();
        var caching = localStorage.getItem('main-category');

        Volt.log('[main-category-model.js] offline'+ JSON.stringify(caching));
		var strCaching = JSON.stringify(caching);
        if (caching && strCaching.length > 0) {
            data = caching;
            this.parse(data,'offline');
            deferred.resolve();
        }else {
            deferred.reject();
        }
        return deferred.promise;
    },
    
    //hanxy add         
    fetch:function(options) {
		var deferred =  Q.defer(), self = this;
		Volt.log("[main-category-model.js] fetch1");
		var _rest;
		if(options == null || options == undefined) {
		  _rest = "game/recommend/v2/main/category/ALL";
		} else {
		   
		   if(options.path != undefined && options.path != null && options.path != '') {
		       _rest = "game/recommend/v2/main/category/" + options.path;
		   } else {
		      Volt.log("[main-category-model.js] error: lack url path param ");
		      return;        
		   }

		   if(options.latest_app_id != undefined && options.latest_app_id != null && options.latest_app_id != '') {
               _rest = _rest + '?latest_app_id=' + options.latest_app_id;
           } 
		}

		Volt.log("[main-category-model.js] process a request");
		ServerController.callAPI({
	            type: 'GET',
	            url: _rest
	        },
	        {
	        	bodyValue: {},
				success : function(data, status, response) {
	                Volt.log("[------------getMainCagoriesByAllOrID callback-----------] success result:" + data);
		            self.parse(data,status,response);  
		            deferred.resolve();    
	            },
	            error : function(response, status, exception) {
	                Volt.log("[------------getMainCagoriesByAllOrID callback-----------] error result:" + exception + JSON.stringify(response));
	            	deferred.reject(response);
	            },
	            complete: function(response, status) {   
	                Volt.log("[------------completeCallback-----------] " + status);	
	            }
	        }
		);
		
		return deferred.promise;
	},

	parse : function(data, status, response) {
		if('offline' != status){
			var time = new Date().getTime();
			localStorage.setItem('main-category', data);
			localStorage.setItem('main-category-caching-time', time);
        	Volt.log("[main-category-model.js] main-category-caching-time : "+ time);
		}
    	
		/*refine need to do: data parse should be added into models */
		var mainCategoryModel = this;
		// /*........spotlight model......*/
		var spotlightModel = mainCategoryModel.get('spotlight');
		spotlightModel.parse(data);

		/*........popular model......*/
		var popularModel = mainCategoryModel.get('popular');
		popularModel.parse(data);

		/*......whatsnew model.......*/
		var whatsNewModel = mainCategoryModel.get('whatsnew');
		whatsNewModel.parse(data);

		/*......topgrossing model.......*/
		var grossingModel = mainCategoryModel.get('grossing');
		grossingModel.parse(data);

		/*......genre model.......*/
		var arcadeModel = mainCategoryModel.get('arcade');
		arcadeModel.parse(data,'C0080');
		
		var partyModel = mainCategoryModel.get('party');
		partyModel.parse(data,'C0081');
		
		var puzzleModel = mainCategoryModel.get('puzzle');
		puzzleModel.parse(data,'C0082');
		
		var sportsModel = mainCategoryModel.get('sports');
		sportsModel.parse(data,'C0083');
		
		var shootingModel = mainCategoryModel.get('shooting');
		shootingModel.parse(data,'C0084');
		
		var rpgModel = mainCategoryModel.get('rpg');
		rpgModel.parse(data,'C0085');

		/*......mypage model.......*/
		var myPageModel = mainCategoryModel.get('mypage');
		myPageModel.parseMyPage(data);

		/*......brand-zone-model model.......*/
		var brandzoneModel = mainCategoryModel.get('brandzone');
		brandzoneModel.parse(data);
	}
});

exports = new MainCategoryModel();