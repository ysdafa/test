/**
 * @author sunlj
 * @20140723
 */

var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameControllerModel = Volt.requireNoContext('app/models/game-controller-model.js');

var GameControllerCollection = Backbone.Collection.extend({
    model : GameControllerModel,

});

exports = GameControllerCollection;
