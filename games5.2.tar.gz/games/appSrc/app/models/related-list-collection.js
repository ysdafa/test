var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var RelatedListModel = Volt.requireNoContext("app/models/related-list-model.js");

var RelatedListCollection = Backbone.Collection.extend({
        model : RelatedListModel,
        
    });

exports = RelatedListCollection;
