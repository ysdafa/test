var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var ShsTraillerListModel = Volt.requireNoContext("app/models/shs-trailer-list-model.js");

var ShsTrailerListCollection = Backbone.Collection.extend({
        model : ShsTraillerListModel,
        
    });

exports = ShsTrailerListCollection;
