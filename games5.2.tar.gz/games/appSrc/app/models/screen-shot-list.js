var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var ScreenShotListModel = Backbone.Model.extend({
    defaults : {
          'screenshot_url' : null, 
          'thumbnail_url' : null
    },
    initialize : function(models, options) {

    },
    parse : function(response) {

    }
})

var initialize = function() {

}
function onKeyEvent(keycode) {

}

exports = ScreenShotListModel; 