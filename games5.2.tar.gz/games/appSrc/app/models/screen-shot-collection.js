var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var ScreenShotListModel = Volt.requireNoContext("app/models/screen-shot-list.js");

var ScreenShotListCollection = Backbone.Collection.extend({
        model : ScreenShotListModel,
        
    });

exports = ScreenShotListCollection;
