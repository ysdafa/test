var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var ControllerListModel = Volt.requireNoContext("app/models/controller-list-model.js");

var ControllerListCollection = Backbone.Collection.extend({
        model : ControllerListModel,
        
    });

exports = ControllerListCollection;
