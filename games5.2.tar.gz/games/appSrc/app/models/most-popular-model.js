var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameListCollection = Volt.requireNoContext("app/models/game-list-collection.js");
/** @lends GamesModel.prototype */
var MostPopularModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,    //'ok'   
        'category_id' : null,
		'category_name' : null,
        'popular_list_cnt' : null
    },
    initialize : function(models, options) {
        this.set('popular_list', new GameListCollection());
    },

    fetch:function(options){
            
    },
            
    parse:function(data){
    	var parsonData = JSON.parse(data);
		if(!parsonData.rsp.hasOwnProperty('C0030')){
			return;
		}
    	this.set('category_id',    parsonData.rsp.C0030.category_id);
		this.set('category_name',  parsonData.rsp.C0030.category_name);
        this.set('popular_list_cnt',parsonData.rsp.C0030.list_cnt);
           
        var popular_list = this.get('popular_list');
        popular_list.reset(parsonData.rsp.C0030.list_data);
              
        }
});
exports = new MostPopularModel();