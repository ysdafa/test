var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameListModel = Volt.requireNoContext("app/models/game-list-model.js");

var GameListCollection = Backbone.Collection.extend({
        model : GameListModel,
        
    });

exports = GameListCollection;
