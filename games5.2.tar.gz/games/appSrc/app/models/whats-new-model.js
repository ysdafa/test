var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameListCollection = Volt.requireNoContext("app/models/game-list-collection.js");
/** @lends GamesModel.prototype */
var WhatsNewModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,    //'ok'   
        'category_id' : null,
		'category_name' : null,
        'whatsnew_list_cnt' : null
    },
    
    initialize : function(models, options) {
        this.set('whatsnew_list', new GameListCollection());
    },

    fetch:function(options){
   
    },
            
    parse:function(data){
   		var parsonData = JSON.parse(data);
		if(!parsonData.rsp.hasOwnProperty('C0040')){
			return;
		}
    	this.set('category_id',         parsonData.rsp.C0040.category_id);
		this.set('category_name',      parsonData.rsp.C0040.category_name);
        this.set('whatsnew_list_cnt',parsonData.rsp.C0040.list_cnt);
           
        var whatsnew_list = this.get('whatsnew_list');
        whatsnew_list.reset(parsonData.rsp.C0040.list_data);
        }
});
exports = new WhatsNewModel();