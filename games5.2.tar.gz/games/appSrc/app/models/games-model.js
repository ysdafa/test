var Backbone = Volt.requireNoContext("lib/volt-backbone.js");

/** @lends GamesModel.prototype */
var GamesModel = Backbone.Model.extend({
    defaults: {
        imgUrl: null,       // URL of Thumbnail Image
        rcolor: null,       // Representative Color
        title: null,        // Title of Game
    },
});
exports = GamesModel;