/**
 * @author tiansx 
 * @20140613
 */
var Q = Volt.requireNoContext('modules/q.js');
var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var CouponCollection = Volt.requireNoContext('app/models/coupon-collection.js');
var ServerController = Volt.requireNoContext('app/controller/server-controller.js');
/** @lends GamesModel.prototype */
var testData = {
    "rsp" : {
        "stat" : "ok",
        "coupon_list_cnt" : "6",
        "coupon_list" : [
        {
            "no" : "1",
            "coupon_no" : "123456783",
            "coupon_title" : "Coupon test data Coupon test data redundant,http://d2tnx644ijgq6i.cloudfront.net/stg/game/202022/15categoryother ",
            "expired_date" : "20141231-235959",
            "expired_flag" : "N",
            "used_flag" : "N",
            "promo_message" : "30% off Event !",
            "guide_message" : "this is coupon message ....... this is coupon message this is coupon message this is coupon message this is coupon message this is coupon message this is coupon message this is coupon message this is coupon message this is coupon message this is coupon message this is coupon message",
            "game_list_count" : "3",
            "game_list" : [{
                "no" : "1",
                "game_title" : "JUST DANCE NOW",
                "app_id" : "111477001195",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203063/15main_1080.jpg",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }, {
                "no" : "2",
                "game_title" : "Monster Sniper",
                "app_id" : "141399000167",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202022/15categoryother.jpg",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }, {
                "no" : "3",
                "game_title" : "Pororo BoardStar",
                "app_id" : "141499000008",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202034/15categoryother.png",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }]
        },
        {
                "no" : "1",
                "coupon_title" : "SQA test 001-0001-05 (fi..) SQA TEST \n only for test",
                "coupon_no" : "sqa-test-001-0001-05",
                "expired_date" : "20150410-235959",
                "expired_flag" : "N",
                "used_flag" : "N",
                "promo_message" : "messgage : SQA test 001-0001-05\nLine : 2 (fixed)",
                "guide_message" : "guide message 1\r\nguide message 2\r\n",
                "game_list_count" : "0",
                "game_list" : [
                ]
        },
        {
            "no" : "2",
            "coupon_no" : "123456789",
            "coupon_title" : "Coupon test data",
            "expired_date" : "20140530",
            "expired_flag" : "Y",
            "used_flag" : "Y",
            "promo_message" : "30% off Event !",
            "guide_message" : "this is coupon message .......",
            "game_list_count" : "2",
            "game_list" : [{
                "no" : "1",
                "game_title" : "Capsule Hunter",
                "app_id" : "141499000005",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202024/15categoryother.png",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }, {
                "no" : "2",
                "game_title" : "Abyss Attack",
                "app_id" : "141399000185",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202021/15categoryfirst.jpg",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }]
        }, 
        {
            "no" : "3",
            "coupon_no" : "123456780",
            "coupon_title" : "Coupon test data",
            "expired_date" : "20140930",
            "expired_flag" : "N",
            "used_flag" : "Y",
            "promo_message" : "30% off Event !",
            "guide_message" : "this is coupon message .......",
            "game_list_count" : "2",
            "game_list" : [{
                "no" : "1",
                "game_title" : "Abyss Attack",
                "app_id" : "141399000185",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202021/15categoryfirst.jpg",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }, {
                "no" : "2",
                "game_title" : "Monster Sniper",
                "app_id" : "141399000167",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202022/15categoryother.jpg",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }]
        },
        {
            "no" : "4",
            "coupon_no" : "123456781",
            "coupon_title" : "Coupon test data",
            "expired_date" : "20141030-202010",
            "expired_flag" : "N",
            "used_flag" : "N",
            "promo_message" : "30% off Event !",
            "guide_message" : "this is coupon message .......",
            "game_list_count" : "1",
            "game_list" : [{
                "no" : "2",
                "game_title" : "Abyss Attack",
                "app_id" : "141399000185",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202021/15categoryfirst.jpg",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }]
        },
        {
            "no" : "5",
            "coupon_no" : "123456782",
            "coupon_title" : "Coupon test data",
            "expired_date" : "20141030",
            "expired_flag" : "N",
            "used_flag" : "N",
            "promo_message" : "30% off Event !",
            "guide_message" : "this is coupon message .......",
            "game_list_count" : "2",
            "game_list" : [{
                "no" : "1",
                "game_title" : "Capsule Hunter",
                "app_id" : "141499000005",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202024/15categoryother.png",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }, {
                "no" : "2",
                "game_title" : "Abyss Attack",
                "app_id" : "141399000185",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202021/15categoryfirst.jpg",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }]
        },
        {
            "no" : "6",
            "coupon_no" : "123456782",
            "coupon_title" : "Coupon test data",
            "expired_date" : "20140830",
            "expired_flag" : "Y",
            "used_flag" : "N",
            "promo_message" : "30% off Event !",
            "guide_message" : "this is coupon message .......",
            "game_list_count" : "1",
            "game_list" : [{
                "no" : "1",
                "game_title" : "Capsule Hunter",
                "app_id" : "141499000005",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202024/15categoryother.png",
                "item_no" : "544",
                "item_name" : "This is my coupon"
            }]
        }
        ]
    }
}; 
var CouponBoxModel = Backbone.Model.extend({
    defaults: {
        "state": null,       // ok
        "coupon_list_cnt": null,
    },
    
    initialize : function(models, options) {
        this.set('coupon_list', new CouponCollection());
    },
    
    fetch:function(options){
    	var deffered=Q.defer();
        var self = this;

		var _rest = "game/user/v2/coupon/coupons";
		Volt.log("[coupon-box-model.js] process a request");
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
		            Volt.log("[coupon-box-model.js] success result:" + data);
		            if(options != undefined && options != null && options != ''){
		                self.parseFakeData();
		            }else{
		                self.parse(data,status,response);
		            }
		            
		            deffered.resolve();    
		        },
		        error : function(response, status, exception) {
		            Volt.log("[coupon-box-model.js] error result:" + exception + JSON.stringify(response));
		        	deffered.reject(response);
		        },
		        complete: function(response, status) {   
		            Volt.log("[coupon-box-model.js] " + status);	
		        }
		    }
		);
        return deffered.promise; 
    },

	post:function(coupon_no) {
		var deffered=Q.defer();
        var self = this;
		var _rest = "game/user/v2/coupon/coupon";
		Volt.log("[coupon-box-model.js] Post coupon no:" + coupon_no);
		
		ServerController.callAPI({
		        type: 'POST',
		        url: _rest
		    },
		    {
		    	bodyValue: {"coupon_no": coupon_no,},
				success : function(data, status, response) {
		            Volt.log("[coupon-box-model.js]post success result:" + data);
					deffered.resolve(data);    
		        },
		        error : function(response, status, exception) {
		            Volt.log("[coupon-box-model.js]post error result:" + status + ',,,' + JSON.stringify(response));
					deffered.reject(response);
		        },
		        complete: function(response, status) {   
		            Volt.log("[coupon-box-model.js]post " + status);
		        }
		    }
		);
        return deffered.promise;
    },

    stopRequestData : function() {
		ServerController.cancel();
	},
	parse:function(data, status, response) {
		var parsonData = JSON.parse(data);
		this.set('coupon_list_cnt',parsonData.rsp.coupon_list_cnt);
        var coupon_list = this.get('coupon_list');
        coupon_list.reset(parsonData.rsp.coupon_list);
	},
	
	parseFakeData:function() {
        this.set('coupon_list_cnt',testData.rsp.coupon_list_cnt);
        var coupon_list = this.get('coupon_list');
        coupon_list.reset(testData.rsp.coupon_list);
    }
});
exports = new CouponBoxModel();
