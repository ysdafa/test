var Backbone       = Volt.requireNoContext("lib/volt-backbone.js");
var voltapi        = Volt.requireNoContext('voltapi.js');
var CommonDefine   = Volt.requireNoContext('app/common/common-define.js');
var Mediator       = Volt.requireNoContext('app/common/event-mediator.js');
var _              = Volt.requireNoContext("modules/underscore.js")._;

var DeviceInfoModel = Backbone.Model.extend({
    defaults:{
        duid        :"",
        modelId     :"",
        languageCode:"",
        countryCode :"",
        vdToken     :"",
        firmware    :"",
        resolutionX :"",
        resolutionY :"",
        bluetooth   :"",
        mlsState    :""
    },
    
    init:function(){
        Mediator.on(CommonDefine.Event.WAS_READY, _.bind(this.onWASInitialized,this)); 
         
        this.setInfoFromVCONF();

        _.each(this.attributes, function(value, key){
             Volt.log('[device-model.js] set : ' + key + ' : ' + value);
        });
        
        this.setChangeHandlerVconf();    
    },
    
    onWASInitialized: function(){
        this.setInfoFromWAS();
    },

    setInfoFromWAS : function(){
        Volt.log('[device-model.js] setInfoFromWAS');
           
        var firmware_version = voltapi.WAS.getInfolinkVer(); 
        Volt.log('firmware_version:::'+firmware_version);
        this.set('firmware', (firmware_version) ? firmware_version : 'T-FXPAKUC-1110.1');        
    },

    setInfoFromVCONF :function(){
        this.set("duid",        getDUID());
        this.set("modelId",     getModelId());
        this.set("languageCode",getLanguageCode());
        this.set("vdToken",     getAToken());
        this.set("resolutionX", String(Volt.sceneWidth));
        this.set("resolutionY", String(scene.height));
        this.set("bluetooth",   getBluetooth());
        this.set('countryCode', getCountryCode());

        this.set('highContrast', getHighContrast());
        this.set('focusZoom', getFocusZoom());
        this.set('tts', getTTS());
		this.set('visibleCursor',getVisibleCursor());
		this.set('mlsState', getMLSState());
    },

    setChangeHandlerVconf:function(){
        /*change callback*/
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_ACCESSIBILITY_HIGHCONTRAST,
                        _.bind(this.onChangeHighContrast, this));
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_SETTINGS_KEY_FOCUSZOOM,
                        _.bind(this.onChangeFocusZoom, this));
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_MENU_ACCESSIBILITY_TTS,
                        _.bind(this.onChangeTTS, this));
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_MEMORY_VOLT_PANEL_HIDE,
                        _.bind(this.onPanelHide, this));
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE,
                        _.bind(this.onChangeVisibleCursor,this));
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_COUNTRY_CODE,
                        _.bind(this.onChangeCountryCode,this));
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_SETTINGS_KEY_SYSTEM_MENU_LANGUAGE,
                        _.bind(this.onChangeLanguage,this));
        voltapi.vconf.setOnChangeHandler(CommonDefine.vconf.SYSTEM_MLS_STATE,
                        _.bind(this.onChangeMLSState,this));
    },
    
    onChangeHighContrast : function(key, value){
        Volt.log("[deviceInfoModel.js] onChangeHighContrast() : " + value);
        this.set('highContrast', value || '');
        if (value) {
            HALOUtil.highContrast = true;
        } else {
            HALOUtil.highContrast = false;
        }
        Mediator.trigger(CommonDefine.Event.CHANGE_HIGH_CONTRAST, value);
    },
    
    onChangeFocusZoom : function(key, value){
        Volt.log("[deviceInfoModel.js] onChangeFocusZoom() : " + value);
        this.set('focusZoom', value || '');
        if (value) {
            HALOUtil.enlarge = true;
        } else {
            HALOUtil.enlarge = false;
        }
        Mediator.trigger(CommonDefine.Event.CHANGE_FOCUS_ZOOM, value);
    },
    
    onChangeTTS: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeTTS() : " + value);
        this.set('tts', value || '');
        //Mediator.trigger(CommonDefine.Event.CHANGE_TTS);
    },
    
    onChangeVisibleCursor : function(key, value) {
        Volt.log("onChangeVisibleCursor() : " + value);
        this.set('visibleCursor', value || '');
        Mediator.trigger(CommonDefine.Event.CHANGE_VISIBLE_CURSOR, value);
    },
    
    onChangeCountryCode: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeCountryCode() : " + value);
        this.set('countryCode', value || '');
        Mediator.trigger(CommonDefine.Event.CHANGE_COUNTRY_CODE);
    },

    onChangeLanguage: function(key, value) {
        Volt.log("[deviceInfoModel.js] onChangeLanguage() : " + value);
        this.set('language', value || '');
        //Mediator.trigger(CommonDefine.Event.CHANGE_LANGUAGE);
        Volt.quit(); 
    },
    
    onChangeMLSState : function(key, value){
        Volt.log("[deviceInfoModel.js] onChangeMLSState() : " + value);
        this.set('mlsState', value || '');
        Mediator.trigger(CommonDefine.Event.CHANGE_MLS, value);
    },
    
    onPanelHide: function(key, value) {
        Volt.log("[deviceInfoModel.js] onPanelHide() : " + value);
        if (parseInt(value) == 1) {
			Volt.log("[deviceInfoModel.js] CEC Mode, should exit");
            Volt.exit();
        }
    },

	getInputBy : function(){
		var strInputBy = this.get('visibleCursor');
		Volt.log('[device-model.js] getInputBy strInputBy = ' + strInputBy);
		if(strInputBy){
			strInputBy = 'point';
		}else{
			strInputBy = '4direct';
		}

		return strInputBy;
	}

});

var getTTS = function(){
    var strTTS = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_MENU_ACCESSIBILITY_TTS);
    Volt.log('[device-model.js] strTTS = ' + strTTS);
    return parseInt(strTTS);
};

var getVisibleCursor = function(){
	var visibleCursor = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE);
    Volt.log('[device-model.js] getVisibleCursor visibleCursor = ' + visibleCursor);
    return visibleCursor;
};

var getHighContrast = function() {
    var highContrast = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_ACCESSIBILITY_HIGHCONTRAST);
    Volt.log('[device-model.js] highContrast = ' + highContrast);
    return highContrast;
};

function getFocusZoom() {
    var focusZoom = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_SETTINGS_KEY_FOCUSZOOM);
    Volt.log('[device-model.js] focusZoom = ' + focusZoom);
    return focusZoom;
}

function getCountryCode(){
    var strCountryCode = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_COUNTRY_CODE);
    Volt.log('[device-model.js] strCountryCode : ' + strCountryCode);
    if(strCountryCode == 'CN'){
        strCountryCode = 'US';
    }
    Volt.log('[device-model.js] strCountryCode2222 : ' + strCountryCode);
    
    return strCountryCode;
}

var getDUID = function() {
    var strDUID = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_COMSS_DUID);
    Volt.log("[device-model.js] strDUID = " + strDUID);
    return strDUID;
};

var getModelId = function() {
    var strModelId = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_COMSS_MODELID);
    Volt.log("[device-model.js] strModelId = " + strModelId);
    return strModelId;
};

var getAToken = function() {
    var strAtoken = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_COMSS_ATOKEN);
    Volt.log("[device-model.js] strAtoken = " + strAtoken);
    if (( typeof strAtoken != 'string') || strAtoken.length == 0) {
        strAtoken = "x+Ii6VuGclNTaTnjHuKa6hKbG6k85O+GtVTap54iRn4UOsqtwIrnYUrkHa8cFxls15p0FlxDnNyH87i37jKsI7koOHwLut4mcb3dCAo/Hd0wMQ===SASAT=";
    }
    return strAtoken;
};

var getLanguageCode = function() {

	var languageCode = '';
    var preDefine = {
        'fr_CA' : 'fr-US',
        'es_MX' : 'es-US',
        'pt_BR' : 'pt-US',
        'en_GB' : 'en-GB',
        'zh_CN' : 'zh-CN',
        'zh_HK' : 'zh-HK',
        'zh_TW' : 'zh-TW'
    };

    var vconfMenuLang = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_SETTINGS_KEY_SYSTEM_MENU_LANGUAGE);
    var lang = vconfMenuLang.split('.')[0];
    Volt.err("[deviceInfoModel.js] getLanguageCode(), Lang: "+vconfMenuLang);
    
    if(preDefine[lang]){
        languageCode = preDefine[lang];
    }else{
        languageCode = lang.split('_')[0];
    }
    
   return languageCode;
};

var getBluetooth = function(){
    var supportBluetooth = SystemInfo.getBoolValue(SystemInfo.KEY_BT_PROFILE_BT_SMART_CONTROL); 
    Volt.log("[device-model.js] supportBluetooth = " + supportBluetooth);
    if(supportBluetooth == true){
        Volt.log('support bluetooth');
        return 'Y';
    }else{
        Volt.log('do not support bluetooth');
        return 'N';
    }
};

var getMLSState = function(){
    var mlsState = voltapi.vconf.getValue(CommonDefine.vconf.SYSTEM_MLS_STATE);
    Volt.log("[device-model.js] mlsState = " + mlsState);
    return mlsState;
};

exports = new DeviceInfoModel();
