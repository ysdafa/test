var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameControllerCollection = Volt.requireNoContext('app/models/game-controller-collection.js');
var ServerController = Volt.requireNoContext('app/controller/server-controller.js');
var Q = Volt.requireNoContext('modules/q.js');

var GameControllerGuideModel = Backbone.Model.extend({
    defaults : {
        "state" : null, // ok
        "guide_page_cnt" : null,
    },

    initialize : function (models, options) {
        this.set('guide_page_list', new GameControllerCollection());
    },

    fetch : function (options) {
        var deffered = Q.defer();
        var self = this;

        var rest = "game/content/v2/guide"; ;
        Volt.log("[game-controller-guide.js] process a get request:" + rest);

        ServerController.callAPI({
            type : 'GET',
            url : rest
            }, {
            bodyValue : {},
            success : function (data, status, response) {
                Volt.log("[game-controller-guide.js] success result:" + data);
                self.parse(data, status, response);
                deffered.resolve();
            },
            
            error : function (response, status, exception) {
                Volt.log("[game-controller-guide.js] error result:" + exception + JSON.stringify(response));
                deffered.reject(response);
            },
            
            complete : function (response, status) {
                Volt.log("[game-controller-guide.js] " + status);
            }
        });
        return deffered.promise;
    },

    parse : function (data, status, response) {

        var parsonData = JSON.parse(data);
        this.set('guide_page_cnt', parsonData.rsp.guide_page_cnt);
        Volt.log("----------guide_page_cnt" + this.get('guide_page_cnt'));
        var guide_page_list = this.get('guide_page_list');
        guide_page_list.reset(parsonData.rsp.guide_page_list);
        Volt.log("----------guide_page_list" + JSON.stringify(guide_page_list));
    }
});
exports = new GameControllerGuideModel();