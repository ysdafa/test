/**
 * @author tiansx
 * @20140613
 */

var Backbone = Volt.requireNoContext("lib/volt-backbone.js");


var MessageBoxModel = Volt.requireNoContext('app/models/message-box-model.js');

var MessagesCollection = Backbone.Collection.extend({
    model: MessageBoxModel,
    
    mode: {
        MODE_TEST: 20,
    },
        
    fetch: function(mode) {
        if (mode == this.mode.MODE_TEST) {
            this.reset(__messagesList);
        }
    },
});

exports = new MessagesCollection();



var __messagesList = [
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:82, g:72, b:36},
    bcolor:{r:112, g:95, b:42},
    title:'No Man Land',
    date:'2014-6-12 09:12:36',
    message:"When you lose a game, they'll respect you if you give 100 percent, if you give everything.When life gets hard and you want to give up ,remeber that life is full of ups and downs,and without the downs ,the ups would mean nothing.",
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:255, g:177, b:92},
    bcolor:{r:255, g:193, b:127},
    title:'Iron Man',
    date:'2014-6-12 19:56:36',
    message:"When life gets hard and you want to give up ,remeber that life is full of ups and downs,and without the downs ,the ups would mean nothing.",
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:51, g:97, b:255},
    bcolor:{r:67, g:101, b:211},
    title:'Tom & Jerry',
    date:'2014-6-12 21:24:36',
    message:"When life gets hard and you want to give up ,remeber that life is full of ups and downs,and without the downs ,the ups would mean nothing.",
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:108, g:233, b:133},
    bcolor:{r:148, g:232, b:165},
    title:'Reloaded',
    date:'2014-6-12 20:46:36',
    message:"When you lose a game, they'll respect you if you give 100 percent, if you give everything",
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:0, g:152, b:135},
    bcolor:{r:66, g:150, b:140},
    title:'Lord of the Rings',
    date:'2014-6-12 19:45:36',
    message:"When you lose a game, they'll respect you if you give 100 percent, if you give everything",
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:171, g:171, b:169},
    bcolor:{r:196, g:196, b:164},
    title: 'Death Race',
    date:'2014-6-12 16:52:36',
    message:'very impressive',
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:0, g:0, b:0},
    bcolor:{r:30, g:30, b:30},
    title:'The Oxford Murders',
    date:'2014-6-12 15:02:36',
    message:'very impressive',
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:138, g:129, b:194},
    bcolor:{r:151, g:141, b:211},
    title:'Titanic',
    date:'2014-6-12 05:32:36',
    message:'very impressive',
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:6, g:25, b:31},
    bcolor:{r:15, g:30, b:56},
    title:'Pirates of the Caribbean',
    date:'2014-6-12 14:02:36',
    message:'very impressive', 
},
{
    imgUrl:Volt.BASE_PATH + "images/" + scene.height + "/games/1.jpg",
    rcolor:{r:9, g:40, b:68},
    bcolor:{r:10, g:31, b:84},
    title:'Ra One',
    date:'2014-6-12 11:35:36',
    message:'very impressive',
}
];