var BackBone=Volt.requireNoContext("lib/volt-backbone.js");
var GenreModel=BackBone.Model.extend({
    defaults:{
        'no':null,
        'name':null,
        'id':null,
        'thumbnail_url':null,
    },
    
    initialize : function(models, options) {

    },
    
    parse : function(response) {

    }
});
exports=GenreModel;