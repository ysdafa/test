var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var CPTraillerListModel = Volt.requireNoContext("app/models/cp-trailer-list-model.js");

var CPTrailerListCollection = Backbone.Collection.extend({
        model : CPTraillerListModel,
        
    });

exports = CPTrailerListCollection;
