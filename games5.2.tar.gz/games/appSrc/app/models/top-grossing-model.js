var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameListCollection = Volt.requireNoContext("app/models/game-list-collection.js");
/** @lends GamesModel.prototype */
var TopGrossingModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,    //'ok'   
        'category_id' : null,
		'category_name' : null,
        'grossing_list_cnt' : null
    },
    
    initialize : function(models, options) {
        this.set('grossing_list', new GameListCollection());
    },

    fetch:function(options){
   
    },
            
    parse:function(data){
    	var parsonData = JSON.parse(data);
		if(!parsonData.rsp.hasOwnProperty('C0050')){
			return;
		}
    	this.set('category_id',      parsonData.rsp.C0050.category_id);
		this.set('category_name',    parsonData.rsp.C0050.category_name);
        this.set('grossing_list_cnt',parsonData.rsp.C0050.list_cnt);
           
        var grossing_list = this.get('grossing_list');
        grossing_list.reset(parsonData.rsp.C0050.list_data);
        }
});
exports = new TopGrossingModel();