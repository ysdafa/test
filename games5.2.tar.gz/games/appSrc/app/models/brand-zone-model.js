var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameListCollection = Volt.requireNoContext("app/models/game-list-collection.js");
/** @lends GamesModel.prototype */
var BrandZoneModel = Backbone.Model.extend({
    defaults : {
        'stat' : null,   //'ok'
        'brandzone_list_cnt':0,   
    },
    
    initialize : function(models, options) {
       this.set('brandzone_list',new GameListCollection());
    },

    fetch:function(options){
  
    },
            
    parse:function(parsonData){
           
        }
});
exports = new BrandZoneModel();