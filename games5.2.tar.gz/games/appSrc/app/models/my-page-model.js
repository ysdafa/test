var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameListCollection = Volt.requireNoContext("app/models/game-list-collection.js");
var ServerController = Volt.requireNoContext('app/controller/server-controller.js');
var voltApiWrapper = Volt.requireNoContext("app/common/voltapi-wrapper.js");
var Q = Volt.requireNoContext('modules/q.js');
var localStorage      = Volt.requireNoContext("lib/volt-local-storage.js");

var testData = {
    "rsp" : {
        "stat" : "ok",
        "game_list_cnt" : "23",
        "game_list" : [{
                "no" : "1",
                "game_title" : "Capsule Hunter",
                "app_id" : "141499000005",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202024/15categoryother.png",
                "genre" : "Arcade/Action",
                "version" : "2.41504",
                "rating" : "2.9",
                "downloadable" : "Y"
            }, {
                "no" : "2",
                "game_title" : "O2JAM Shuffle",
                "app_id" : "141477000090",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203049/15categoryother.jpg",
                "genre" : "Party/Music",
                "version" : "1.16103",
                "rating" : "3.0",
                "downloadable" : "Y"
            }, {
                "no" : "3",
                "game_title" : "Best of Board Games - Solitaire",
                "app_id" : "3201410000101",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203060/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.01403",
                "rating" : "0",
                "downloadable" : "Y"
            }, {
                "no" : "4",
                "game_title" : "Best of Board Games - Chess",
                "app_id" : "3201410000100",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203058/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.11502",
                "rating" : "5.0",
                "downloadable" : "Y"
            }, {
                "no" : "5",
                "game_title" : "Best of Arcade Games - Brick Breaker",
                "app_id" : "3201410000103",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203059/15categoryother.jpg",
                "genre" : "Arcade/Action",
                "version" : "1.01403",
                "rating" : "0",
                "downloadable" : "Y"
            }, {
                "no" : "6",
                "game_title" : "Sudoku",
                "app_id" : "11090206007",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203071/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.00513",
                "rating" : "4.0",
                "downloadable" : "Y"
            }, {
                "no" : "7",
                "game_title" : "UPDATE TEST APP modify1",
                "app_id" : "3201411000464",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203054/15categoryother.png",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.3000",
                "rating" : "0",
                "downloadable" : "Y"
            }, {
                "no" : "8",
                "game_title" : "Mo or Do",
                "app_id" : "141477000093",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203046/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.215",
                "rating" : "0",
                "downloadable" : "Y"
            }, {
                "no" : "9",
                "game_title" : "Candy Coaster",
                "app_id" : "141399000165",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202015/15categoryother.jpg",
                "genre" : "Arcade/Action",
                "version" : "2.41501",
                "rating" : "3.9",
                "downloadable" : "Y"
            }, {
                "no" : "10",
                "game_title" : "Twin Cobra",
                "app_id" : "3201411000532",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203057/15categoryother.jpg",
                "genre" : "Shooting/Strategy",
                "version" : "1.715",
                "rating" : "4.7",
                "downloadable" : "Y"
            }, {
                "no" : "11",
                "game_title" : "Brain Training",
                "app_id" : "111477000145",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202033/hot_1080.png",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.03202",
                "rating" : "3.5",
                "downloadable" : "Y"
            }, {
                "no" : "12",
                "game_title" : "Best of Board Games �C Mahjong",
                "app_id" : "3201410000066",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203062/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.21602",
                "rating" : "0",
                "downloadable" : "Y"
            }, {
                "no" : "13",
                "game_title" : "Sky Chaser",
                "app_id" : "141399000171",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202011/15categoryother.jpg",
                "genre" : "Arcade/Action",
                "version" : "2.11502",
                "rating" : "3.3",
                "downloadable" : "Y"
            }, {
                "no" : "14",
                "game_title" : "GameTreeTV",
                "app_id" : "111399002417",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203064/15categoryother.png",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.00406",
                "rating" : "2.0",
                "downloadable" : "Y"
            }, {
                "no" : "15",
                "game_title" : "Drop Duel",
                "app_id" : "11101000401",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203067/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.00402",
                "rating" : "0",
                "downloadable" : "Y"
            }, {
                "no" : "16",
                "game_title" : "Playcast",
                "app_id" : "3201412000675",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203074/15categoryother.jpg",
                "genre" : "Arcade/Action",
                "version" : "0.00501",
                "rating" : "5.0",
                "downloadable" : "Y"
            }, {
                "no" : "17",
                "game_title" : "Bingo HOME: Race to Earth",
                "app_id" : "3201412000708",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203061/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "0.11508",
                "rating" : "3.0",
                "downloadable" : "Y"
            }, {
                "no" : "18",
                "game_title" : "Monster Sniper",
                "app_id" : "141399000167",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202022/15categoryother.jpg",
                "genre" : "Shooting/Strategy",
                "version" : "3.815",
                "rating" : "3.5",
                "downloadable" : "Y"
            }, {
                "no" : "19",
                "game_title" : "Running Dog",
                "app_id" : "141399000159",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202013/15categoryother.png",
                "genre" : "Arcade/Action",
                "version" : "1.00003",
                "rating" : "3.5",
                "downloadable" : "Y"
            }, {
                "no" : "20",
                "game_title" : "Fishing Grandmer",
                "app_id" : "141399000170",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202014/hot_1080.jpg",
                "genre" : "Sports/Racing",
                "version" : "1.01501",
                "rating" : "2.9",
                "downloadable" : "Y"
            }, {
                "no" : "21",
                "game_title" : "Miracle Band",
                "app_id" : "141399000177",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/202019/15categoryother.jpg",
                "genre" : "Party/Music",
                "version" : "1.12701",
                "rating" : "2.7",
                "downloadable" : "Y"
            }, {
                "no" : "22",
                "game_title" : "Pyramid Challenge",
                "app_id" : "111399002398",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203070/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.00006",
                "rating" : "3.7",
                "downloadable" : "Y"
            }, {
                "no" : "23",
                "game_title" : "Mahjong Fruits",
                "app_id" : "11090206003",
                "thumbnail_url" : "http://d2tnx644ijgq6i.cloudfront.net/stg/game/203068/15categoryother.jpg",
                "genre" : "Puzzle/Brain/Board",
                "version" : "1.00212",
                "rating" : "4.5",
                "downloadable" : "Y"
            }
        ],
        "not_exist_list_cnt" : "0",
        "not_exist_list" : [{
                "app_id" : ""
            }
        ]
    }
};

/** @lends GamesModel.prototype */
var MyPageModel = Backbone.Model.extend({
    defaults : {
		'category_id' : null,
		'category_name' : null,
        'game_list_cnt' : null,
        'nick_name':null,
        'coupon_count':null,
        'uninstalling_app_id' : null,
    },
    
    initialize : function(models, options) {
        this.set('game_list', new GameListCollection());
    },  
    
    fetch:function(options){
        var deferred =  Q.defer()
        , self = this;
        
        var deletingAppId = this.get('uninstalling_app_id');
        Volt.log("[my-page-model.js] fetch  deletingAppId:" + deletingAppId);

		var _rest = "game/user/v2/installed/games";
		//set native game list as param
		var nativeList = voltApiWrapper.getNativeGameList();
		var param = '';
		if(nativeList.length > 0) {
			param = '?app_ids=';
			for(var i = 0; i < nativeList.length; i++) {
				Volt.log('nativeList[' + i + ']=' + nativeList[i] + ' ' + nativeList[i].appID);
				if(deletingAppId && nativeList[i].appID == deletingAppId){
                    //nativeList.spice(i,1);
                    this.set('uninstalling_app_id',null);
                } else{
                    param = param + nativeList[i].appID;
                    if(i < nativeList.length - 1) {
                        param = param + '%2c';
                    }
                }
			}
		}
		_rest = _rest + param;
		Volt.log("[my-page-model.js] process a get request:" + _rest);
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
            },{
                bodyValue: {},
                success : function(data, status, response) {
                    Volt.log("[my-page-model.js] success result:" + data);
                    if(options != undefined && options != null && options != ''){
                        Volt.log("[my-page-model.js] success result  fakeData test");
                        self.parseFakeData();
                    } else {
                        self.parse(data,status,response);
                    }
                    
                    deferred.resolve();    
                },
                error : function(response, status, exception) {
                    Volt.log("[my-page-model.js] error result:" + exception + JSON.stringify(response));
                    deferred.reject(response);
                },
                complete: function(response, status) {   
                    Volt.log("[my-page-model.js] " + status);	
                }
            }
		);
        return deferred.promise;
    },

    fetchMyPage: function(path){
        var deferred =  Q.defer()
		, self = this;
		Volt.log("[my-page-model.js] fetchMyPage fetch1");
		var _rest;
	 
		   if(path != undefined && path != null && path != '') {
		       _rest = "game/recommend/v2/main/category/" + path;
		   } else {
		      Volt.log("[my-page-model.js] fetchMyPage error: lack url path param ");
		      return;        
		   }
		

		Volt.log("[my-page-model.js] process a request");
		ServerController.callAPI({
	            type: 'GET',
	            url: _rest
	        },{
	        	bodyValue: {},
				success : function(data, status, response) {
	                Volt.log("[[my-page-model.js]------------fetchMyPage callback-----------] success result:" + data);
		            self.parseMyPage(data,status,response);
		            deferred.resolve();    
	            },
	            error : function(response, status, exception) {
	                Volt.log("[[my-page-model.js]------------fetchMyPage callback-----------] error result:" + exception + JSON.stringify(response));
	            	deferred.reject(response);
	            },
	            complete: function(response, status) {   
	                Volt.log("[[my-page-model.js]------------fetchMyPage completeCallback-----------] " + status);	
	            }
	        }
		);

        return deferred.promise;
    },
    
    parse: function(data,status,response){
		var parsonData = JSON.parse(data);
		this.set('game_list_cnt', parsonData.rsp.game_list_cnt);
        
        var mypage_list = this.get('game_list');
        mypage_list.reset(parsonData.rsp.game_list);
    },
    
    parseMyPage: function(data,status,response){
        Volt.log("[my-page-model.js] parseMyPage ");
        var parsonData = JSON.parse(data);
		if(!parsonData.rsp.hasOwnProperty('C0070')){
			return;
		}
		
        this.set('category_name', parsonData.rsp.C0070.category_name);
		this.set('nick_name',     parsonData.rsp.C0070.mypage.nick_name);
        this.set('coupon_count',  parsonData.rsp.C0070.mypage.coupon_count);
        
        var caching = localStorage.getItem('main-category');
        var strCaching = JSON.stringify(caching);
        if(caching && strCaching.length > 0){
            var parsonCache = JSON.parse(caching);
            var cachNickName = parsonCache.rsp.C0070.mypage.nick_name;
            Volt.log("[my-page-model.js] parseMyPage  cachNickName =" + cachNickName);
            Volt.log("[my-page-model.js] parseMyPage  realNickName =" + this.get('nick_name'));
            if (cachNickName != this.get('nick_name')) {
                parsonCache.rsp.C0070.mypage.nick_name = this.get('nick_name');
                localStorage.setItem('main-category', JSON.stringify(parsonCache));
            }
        }
    },
    
    parseFakeData:function() {
        Volt.log("[my-page-model.js] parseFakeData ");
        this.set('game_list_cnt', testData.rsp.game_list_cnt);
        var mypage_list = this.get('game_list');
        mypage_list.reset(testData.rsp.game_list);
    }
});
exports = new MyPageModel();