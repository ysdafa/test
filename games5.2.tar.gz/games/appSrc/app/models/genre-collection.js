var Backbone=Volt.requireNoContext('lib/volt-backbone.js');
var GenreModel=Volt.requireNoContext('app/models/genre-model.js');
var GenreCollection=Backbone.Collection.extend({
    model:GenreModel,

});
exports=GenreCollection;