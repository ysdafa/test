/**
 * @author tiansx 
 * @20140613
 */

var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var CouponListModel = Volt.requireNoContext('app/models/coupon-list-model.js');

var CouponCollection = Backbone.Collection.extend({
    model:CouponListModel,
});

exports = CouponCollection;
