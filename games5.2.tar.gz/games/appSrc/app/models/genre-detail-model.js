var Backbone = Volt.requireNoContext("lib/volt-backbone.js");
var GameListCollection = Volt.requireNoContext("app/models/game-list-collection.js");
var ServerController = Volt.requireNoContext('app/controller/server-controller.js');
var Q=Volt.requireNoContext("modules/q.js");
/** @lends GamesModel.prototype */
var GenreModel = Backbone.Model.extend({
	defaults : {
		'stat' : null, //'ok'
		'category_id' : null,
		'list_cnt' : null,
		'genre_group_name' : null,
		'genre_group_id' : null,
        'genre_group_cnt': null,
        'genre_group_list': null,
	},
	initialize : function(models, options) {
		this.set('data_list', new GameListCollection());
        this.set('genre_group_list', new GameListCollection());
	},

    fetch:function(options){
		var deferred =  Q.defer();
		var self = this;

		var _rest;
		if(options == null || options == undefined) {
			_rest = "game/recommend/v2/main/categories";
		} else {
			if(options.path != undefined && options.path != null && options.path != '') {
				_rest = "game/recommend/v2/main/category/" + options.path;
			} else {
				Volt.log("[genre-detail-model.js] error: lack url path param ");
				return;        
			}
		}
		Volt.log("[genre-detail-model.js] process a get request:" + _rest);
		
		ServerController.callAPI({
		        type: 'GET',
		        url: _rest
		    },
		    {
		    	bodyValue: {},
				success : function(data, status, response) {
					Volt.log("[genre-detail-model.js] success result:" + data);
                            var id = options.path.split('?')[0];
                            Volt.log('id::::::::'+id);
		            self.parse(data,id);  
		            deferred.resolve();    
		        },
		        error : function(response, status, exception) {
		        	Volt.log("[genre-detail-model.js] error result:" + exception + JSON.stringify(response));
		        	deferred.reject(response);
		        },
		        complete: function(response, status) {   
		        	Volt.log("[genre-detail-model.js] " + status);	
		        }
		    }
		);
        return deferred.promise;      
    },
         
	stopRequestData : function() {
		ServerController.cancel();
	},
	
	parse : function(data, id) {
		var parsonData = JSON.parse(data);
		if(parsonData.rsp && parsonData.rsp[id] && parsonData.rsp[id].hasOwnProperty('list_cnt')){
		    this.set('list_cnt', parsonData.rsp[id].list_cnt);
	        var data_list = this.get('data_list');
	        data_list.reset(parsonData.rsp[id].list_data);
        }
	},
	
	parseGenre : function(data) {
		var parsonData = JSON.parse(data);
		this.set('genre_group_name', parsonData.rsp.genre_group_name);
		this.set('genre_group_id', parsonData.rsp.genre_group_id);
                this.set('genre_group_cnt', parsonData.rsp.genre_group_cnt);
                var data_list = this.get('genre_group_list');
		data_list.reset(parsonData.rsp.genre_group_list);
	},

	clear : function() {
		Volt.log("[-----------] clear data");
		this.set('genre_group_cnt', 0);
		var data_list = this.get('genre_group_list');
		data_list.reset(null);
	}
});
exports = GenreModel;
