var CouponTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: Volt.sceneWidth, height: 1080,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'coupon-header-container',
                type: 'widget',
                x: 0, y: 0, width: Volt.sceneWidth, height: 1080 * 0.133333,
                color: Volt.hexToRgb('#0f1826')
            },  {
                id: 'coupon-content-container', 
                type: 'widget',
                x: 0, y: 1080 * 0.133333, width: Volt.sceneWidth, height: 1080 * 0.866667,
                color: Volt.hexToRgb('#ffffff'),
            },
            {
                id: 'coupon-popup-container',
                type: 'widget',
                x: 0, y: 0, width: Volt.sceneWidth, height: 1080,
                color: Volt.hexToRgb('#000000',0),
            }
        ]
    },

    header: {
        type: 'widget', x: 0, y: 0, width: Volt.sceneWidth, height: 1080 * 0.133333,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                id : "coupon-box-title",
                type: 'text', x: Volt.sceneWidth * 0.018750, y: 0, width: Volt.sceneWidth * 0.378125, height: 1080 * 0.133333,
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                opacity: 204,
                font : 'SamsungSmart_Light 50px',
                text : Volt.i18n.t('TV_SID_COUPONS'),
            },
            {
                type : 'widget',
                id : 'coupon-box-back-icon-area',
                x : 0, y : 0, width : Volt.sceneWidth * 0.052083, height : 1080 * 0.133333,
                color : {r:0,g:0,b:0,a:0},
                children : [
				{
					type:'widget',
					id:'coupon-back-icon-line',
					x:Volt.sceneWidth * 0.052083 - 1,
					y:0,
					width:1,
					height:1080 * 0.133333,
					opacity: 26,
					color : Volt.hexToRgb('#ffffff'),
				},]
            },
            { //x:1623,width:292
                type: 'widget', x: Volt.sceneWidth - Volt.sceneWidth * 0.052083, y: 0, width: Volt.sceneWidth * 0.052083, height: 1080 * 0.133333,
                color: Volt.hexToRgb('#000000', 0),
                id: 'coupon-header-icon-schedule',
                custom: { 'focusable': true },
            },
            {
            	type:'widget',
				id:'coupon-header-icon-schedule-line',
				x:Volt.sceneWidth - Volt.sceneWidth * 0.052083,
				y:0,
				width:1,
				height:1080 * 0.133333,
				opacity: 26,
				color : Volt.hexToRgb('#ffffff'),
            
            }
        ]
    },

   content:{
        x : 0,
        y : 0,
        width : Volt.sceneWidth,
        height : 1080 * 0.866667,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    
    registerBtn : {
        id : 'coupon-header-icon-schedule-image',
        icon: {
            src:Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_topmenu_plus.png'),
            x:(Volt.sceneWidth * 0.052083 - 36)/2,y:(1080 * 0.133333 - 36)/2,
            width:36,height:36
        },
        color : {r : 0,g : 0,b : 0,a:0},
        width: Volt.sceneWidth * 0.052083 - 1 ,
        height: 1080 * 0.133333 ,
        x: 0,
        y: 0
      },
      
    backBtn:{
        id : 'coupon-box-back-icon',
        x : 0,
        y : 0,
        width : Volt.sceneWidth * 0.051563,
        height : 1080 * 0.133333,
        icon : {src:Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_tm_return.png'),
        x:(Volt.sceneWidth * 0.051563 - 36) / 2,y : (1080 * 0.133333 - 36) / 2,
        width : 36, height : 36,},
        color: { r: 0, g: 0, b: 0, a: 0 },
   },

	toolTip : {
        type : 'WinsetToolTip',
        x : '{{x}}',
        y : '{{y}}',
        width : '{{w}}',
        height : '{{h}}',
        style : '{{style}}',
        nResoultionStyle : '{{nResoultionStyle}}',
        text : '{{text}}',
        tailPostion: '{{tailPostion}}',
        //parent : scene
    }
 
};

exports = CouponTemplate;
