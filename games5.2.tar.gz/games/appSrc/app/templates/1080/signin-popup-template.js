/**
 * @author tiansx
 * @20140627
 */
var SingInTemplate = {
    container : {
        type: 'widget',
        custom : {
            'focusable' : true,
            'onKeyEvent' : null
        },
        x: 0, y: 347, width: Volt.sceneWidth, height : 386,
        color : Volt.hexToRgb('#0f1826',85),
        children : [            
            {
                type : 'widget',
                id : 'description-container',
                x : 399, y : 0, width : 1122, height : 200,
                color : Volt.hexToRgb('#0f1826',0),
                opacity:216,
            },            
            {
                type : 'widget',
                x :399, y : 286, width : 1122 , height : 66,
                id : 'button-container',
                color : Volt.hexToRgb('#0f1826',0),
                opacity:216,
            }
        ]
    },
    
    description: {
        type: 'widget',
        x: 0, y: 0, width: 1122, height: 200,
        color: Volt.hexToRgb('#0f1826',0),
        children:[
        {
            type: 'text',
            x: 150, y: 60, width: 822, height: 140,
            horizontalAlignment : 'center',
            verticalAlignment : 'center',
            textColor : Volt.hexToRgb('#ffffff'),
            opacity: 216,
            text : 'Description',
            font : 'SamsungSmart_Light 34px'
        }]
    },
    
    button:{
        type : 'widget',
        x : 0, y : 0, width : 1122, height : 66,
        color : Volt.hexToRgb('#0f1826',0),
            
        children: [
            {
                type : 'widget',
                id : 'Yes',
                custom : {'focusable' : true,},
                x:285,y:0,width: 270,height: 66,
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                id : 'No',
                custom : {'focusable' : true,},
                x : 567, y : 0, width : 270, height : 66,
                color : Volt.hexToRgb('#ffffff',0),
            },
        ],
    }
};

exports = SingInTemplate;


