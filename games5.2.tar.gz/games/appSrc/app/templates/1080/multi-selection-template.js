var MultiSelectionTemplate = {
    container : {
        type : 'widget',
        x : 0,
        y : 1080 * 0.133333,
        width : Volt.sceneWidth,
        height : 1080 * 0.066667,
        color : Volt.hexToRgb('#0f1826'),
        children : [{
            id : 'multiselection-selectall-bg',
            type : 'widget',
            x : Volt.sceneWidth * (1 - 3 * 0.156250),
            y : 0,
            width : Volt.sceneWidth * 0.156250,
            height : 1080 * 0.066667,
            color : Volt.hexToRgb('#ffffff', 0),
            children : [{
                type : 'widget',
                width : 1,
                height : 1080 * 0.066667,
                color : Volt.hexToRgb('#ffffff', 10)
            }],
            custom : {
                'focusable' : true
            }
        }, {

            id : 'multiselection-delete-bg',
            type : 'widget',
            x : Volt.sceneWidth * (1 - 2 * 0.156250),
            y : 0,
            width : Volt.sceneWidth * 0.156250,
            height : 1080 * 0.066667,
            color : Volt.hexToRgb('#ffffff', 0),
            children : [{
                type : 'widget',
                width : 1,
                height : 1080 * 0.066667,
                color : Volt.hexToRgb('#ffffff', 10)
            }],
            custom : {
                'focusable' : true
            }
        }, {
            id : 'multiselection-cancel-bg',
            type : 'widget',
            x : Volt.sceneWidth * (1 - 0.156250),
            y : 0,
            width : Volt.sceneWidth * 0.156250,
            height : 1080 * 0.066667,
            color : Volt.hexToRgb('#ffffff', 0),
            children : [{
                type : 'widget',
                width : 1,
                height : 1080 * 0.066667,
                color : Volt.hexToRgb('#ffffff', 10)
            }],
            custom : {
                'focusable' : true
            }
        }, {
            id : 'multiselection-select-items',
            type : 'text',
            x : Volt.sceneWidth * 0.020833,
            y : 0,
            height : 1080 * 0.066667,
            verticalAlignment : "center",
            horizontalAlignment : 'left',
            textColor : Volt.hexToRgb('#ffffff'),
            color : Volt.hexToRgb('#000000', 0),
            font : "SamsungSmart_Light 28px",
            text : Volt.i18n.t('TV_SID_MIX_SELECTED_ITEM_COLON').replace('<<A>>','')
        }, {
            id : 'multiselection-select-num',
            type : 'text',
            x : 0,
            y : 0,
            height : 1080 * 0.066667,
            verticalAlignment : "center",
            horizontalAlignment : 'left',
            textColor : Volt.hexToRgb('#24b6f4'),
            color : Volt.hexToRgb('#000000', 0),
            font : "SamsungSmart_Light 31px",
            text : '0'
        }, {
            type : 'widget',
            x : 0,
            y : 0,
            width : Volt.sceneWidth,
            height : 1,
            color : Volt.hexToRgb('#ffffff', 10),
        }]
    },
    generalBtn : {
        x : 0,
        y : 0,
        width : Volt.sceneWidth * 0.156250 ,
        height : 1080 * 0.066667 
    }

};
exports = MultiSelectionTemplate;