var SharePopupTemplate = {
    container : {
		parent:scene,
        type: 'widget',
        id : 'share-bg-container',
        x : 0, y : 227, width : Volt.sceneWidth, height : 626,
        color : Volt.hexToRgb('#0f1826',85),
		children:[
				{
					type : 'widget',
					id : 'share-title-container',
					x : 399, y : 0, width : 1122, height : 96,
					color : {r:255,g:255,b:255,a:0},
				},
				{
					type : 'widget',
					x : 399, y : 121, width : 1122, height : 66,
					id : 'share-account-container',
					color : {r:255,g:255,b:255,a:0},
				},
				{
					type : 'widget',
					x : 399, y : 217, width : 1122, height : 240,
					id : 'share-comment-container',
					color : {r:255,g:255,b:255,a:0},
				},
				{
					type : 'widget',
					x : 0, y : 530, width : Volt.sceneWidth , height : 66,
					id : 'share-button-container',
					color : {r:255,g:255,b:255,a:0},
				}
				]
            },

	title:{
    	type : 'widget',
		x : 0, y : 0, width : 1122, height : 96,
		color : {r:255,g:255,b:255,a:0},
    	children : [
		    {
		        type : 'image',
		        x : 480, y: 27, width : 42, height : 42,
				id: 'share_popup_facebook_icon',
				src : Volt.getRemoteUrl('images/' + scene.height + '/games/screnshot_image1.jpg'),
			},
			{
		        type : 'text',
		        x : 542, y: 0, width : 200, height : 96,
		        horizontalAlignment : 'center',
		        verticalAlignment : 'left',
		        textColor : Volt.hexToRgb('#ffffff', 255),
		        text : Volt.i18n.t('COM_SID_SHARE'),
		        font : '46',
	    	},
            {
                type : 'widget',
                x : 0, y : 95, width : 1122 , height : 1,
                id : 'share_title_horizontal_line',
                color : {r:255,g:255,b:255,a:76},
            }
		]
    },
    
account_area:{
    	type : 'widget',
		x : 0, y : 0, width : 1122, height : 66,
		color : {r:255,g:255,b:255,a:0},
		children : [
			{
		        type : 'text',
		        x : 0, y: 0, width : 850, height : 66,
				id : 'share_account_ID',
		        horizontalAlignment : 'center',
		        verticalAlignment : 'left',
		        textColor : {r:255,g:255,b:255,a:255},
		        text : 'ryan@samsung.com',
		        font : '30',
	    	},
			{
                type : 'widget',
                x : 850, y : 0, width : 1122 , height : 66,
                id : 'share_changeID_button',
				custom : {'focusable' : true,},
                color : {r:255,g:255,b:255,a:0},
            }
		]
},

comment_area:{
    	type : 'widget',
		x : 0, y : 0, width : 1122, height : 240,
		color : {r:255,g:255,b:255,a:0},
		children : [
			{
		        type : 'image',
		        x : 0, y: 0, width : 240, height : 240,
				id :'share_account_thumbnail',
				src : Volt.getRemoteUrl('images/' + scene.height + '/games/screnshot_image1.jpg'),
	    	},
			{
                type : 'widget',
                x : 240, y : 0, width : 882 , height : 240,
                id : 'share_comment_input',
				custom : {'focusable' : true,},
                color : {r:255,g:255,b:255,a:0},
            }
		]
},

button:
	{
    	type : 'widget',
		x : 0, y : 0, width : 1880, height : 66,
		color : Volt.hexToRgb('#ffffff',0),
		children: [
			{
				type : 'widget',
				id : 'Post',
				custom : {'focusable' : true,},
				x : 684, y : 0, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
	    	{
				type : 'widget',
				id : 'Cancel',
				custom : {'focusable' : true,},
				x : 966, y : 0, width : 270, height : 66,
				color : Volt.hexToRgb('#ffffff',0),
	    	},
		],
    }
}
exports = SharePopupTemplate;