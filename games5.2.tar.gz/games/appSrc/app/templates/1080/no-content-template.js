var noContentTemplate = {
    general: {
        type: 'widget',
        x: 0, y: 0,    
        width: Volt.sceneWidth, height: 1080*0.8,
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            {
                type: 'text',
                x: 0, y: 1080*0.357407,
                anchor: {x: 0.5, y: 0},
                origin: {x: 0.5, y: 0},
                lineSpacing: 5,
                width: Volt.sceneWidth-2*Volt.sceneWidth*0.046875, height: 1080*0.044444*2 + 15,
                font: 'SamsungSmart_Light 35px',
                textColor: Volt.hexToRgb('#000000', 255*0.6),
                verticalAlignment: 'center',
                horizontalAlignment: 'center',
                color: Volt.hexToRgb('#dfdfdf'),
            }
        ],
    },
    
    myPage: {
        type: 'widget',
        x: 0, y: 0,
        width: Volt.sceneWidth, height: 1080*0.8,
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            {
                type: 'text',
                x: 0, y: 1080*(1-0.39074)/2,
                origin: {x: 0.5, y: 0},
                anchor: {x: 0.5, y: 0},
                lineSpacing: 5,
                width: Volt.sceneWidth*(1-0.046875*2) , height: 1080*0.044444*2 + 45,
                font: 'SamsungSmart_Light 35px',
                textColor: Volt.hexToRgb('#000000', 255*0.6),
                verticalAlignment: 'center',
                horizontalAlignment: 'center',
            },
            {
                type: 'widget',
                x: 0, y: 0-1080*(1-0.39074)/2,
                origin: {x: 0.5, y: 1},
                anchor: {x: 0.5, y: 1},
                width: Volt.sceneWidth*0.140104, height: 1080*0.060185,
                color: {r: 0, g: 0, b: 0, a: 0},
                //custom: {focusable: true,},              
            }
        ]
        
    },
    
    coupon: { 
        type: 'widget',
        x: 0, y: 0,
        width: Volt.sceneWidth, height: 1080*(1-0.133333),
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            {
                type: 'text',
                x: 0, y:1080*(1-0.133333-0.044444*2)/2,
                anchor: {x: 0.5, y: 0},
                origin: {x: 0.5, y: 0},
                lineSpacing: 5,
                width: Volt.sceneWidth - Volt.sceneWidth*0.046875*2, height: 1080*0.044444*2 + 15,
                font: 'SamsungSmart_Light 35px',
                textColor: Volt.hexToRgb('#000000', 153),
                verticalAlignment: 'center',
                horizontalAlignment: 'center',            
            },
        ]
    },
    
    
    button: {
        type: 'WinsetBtn',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        x: 0,
        y: 0,
        width: Volt.sceneWidth*0.140104,
        height: 1080*0.060185,
        text: "",
    }

}
    
exports = noContentTemplate;

