var GamesMainTemplate = {
    header: {
        type: 'widget', x: 0, y: 0, width: Volt.sceneWidth, height: 1080 * 0.133333,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                type: 'text', x: Volt.sceneWidth * 0.018750, y: 0, width: Volt.sceneWidth * 0.378125, height: 1080 * 0.133333,
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                opacity: 204,
                text : Volt.i18n.t('UID_PAN_GAMES'),
                font : 'SamsungSmart_Light 50px'
            }, {//width:300
                type: 'widget', x: Volt.sceneWidth * 0.84375, y: 0, width: Volt.sceneWidth * 0.15625, height: 1080 * 0.133333,
                color: Volt.hexToRgb('#000000', 0),
                children: [
                    {
				    	id: 'main-header-line',
				    	type: 'widget', x: 0, y: 0, width: 1, height: 1080 * 0.133333 + 18,
                        color: Volt.hexToRgb('#ffffff'), opacity: 25
                    },{
                        type: 'widget', x: Volt.sceneWidth * 0.052083, y: 0, width: 1, height: 1080 * 0.133333 + 18,
                        color: Volt.hexToRgb('#ffffff'), opacity: 25
                    },{
                        type: 'widget', x: Volt.sceneWidth * 0.052083 * 2, y: 0, width: 1, height: 1080 * 0.133333 + 18,
                        color: Volt.hexToRgb('#ffffff'), opacity: 25
                    },
                    {
                        id: 'main-header-icon-login',
                        type: 'widget', x: 1, y: 0, width: Volt.sceneWidth * 0.052083 -1, height: 1080 * 0.133333, opacity: 255,
                        color: Volt.hexToRgb('#000000', 0),
                        custom: { 'focusable': true },
                    },{
                        id: 'main-header-icon-setting',
                        type: 'widget', x: Volt.sceneWidth * 0.052083 + 1, y: 0, width: Volt.sceneWidth * 0.052083 -1, height: 1080 * 0.133333, opacity: 255,
                        color: Volt.hexToRgb('#000000', 0),
                        custom: { 'focusable': true },
                    },{
                        id: 'main-header-icon-close',
                        type: 'widget', x: Volt.sceneWidth * 0.052083 * 2 + 1, y: 0, width: Volt.sceneWidth * 0.052083 -1, height: 1080 * 0.133333, opacity: 255,
                        color: Volt.hexToRgb('#000000', 0),
                        custom: { 'focusable': true },
                    }
                ]
            },
            {
                id : "main-header-dim",
                type: 'widget', x: 0, y: 0, width: Volt.sceneWidth, height: 1080 * 0.133333,
                color: Volt.hexToRgb('#000000', 0),
            }
        ]
    },

	loginBtn : {
		id : 'login-icon',
		icon : {
			src : Volt.getRemoteUrl('images/' + scene.height + '/common/g_state_logout.png'),
			x : (Volt.sceneWidth * 0.052083 - 60) / 2,
			y : (1080 * 0.133333 - 60) / 2,
			width : 60,
			height : 60
		},
		color : {
			r : 0,
			g : 0,
			b : 0,
			a : 0
		},
		height : 1080 * 0.133333 ,
		width : Volt.sceneWidth * 0.052083 - 1,
		x : 0,
		y : 0
	},

	settingBtn : {
		id : 'main-header-icon-setting-image',
		icon : {
			src : Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_tm_setting.png'),
			x : (Volt.sceneWidth * 0.052083 - 36) / 2,
			y : (1080 * 0.133333 - 36) / 2,
			width : 36,
			height : 36
		},
		color : {
			r : 0,
			g : 0,
			b : 0,
			a : 0
		},
		height : 1080 * 0.133333 ,
		width : Volt.sceneWidth * 0.052083 - 1,
		x : 0,
		y : 0
	},

	closeBtn : {
		id : 'main-header-icon-close-image',
		icon : {
			src : Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_tm_close.png'),
			x : (Volt.sceneWidth * 0.052083 - 36) / 2,
			y : (1080 * 0.133333 - 36) / 2,
			width : 36,
			height : 36
		},
		color : {
			r : 0,
			g : 0,
			b : 0,
			a : 0
		},
		height : 1080 * 0.133333,
		width : Volt.sceneWidth * 0.052083 - 1,
		x : 0,
		y : 0
	},
   
    TitleBarWidget:{
        type: 'text',
        x: 0, 
        y: -48, 
        width: 324*5*4, 
        height: 48,
        color: {r:0xf2, g:0xf2, b:0xf2},
    },
                 
    TitleWidget:{
        type: 'text',
        x: 0, 
        y: 0, 
        width: 1620, 
        height: 48,
        verticalAlignment:"center",
        textColor:{r:0, g:0, b:0},
        font:"SamsungSmart_Light 22px",
        text:'{{ text }}',
        parent:scene,
    },
    
    imageWidget:{
        type: 'image',
        width: 17, 
        height: 17,
        src : '{{ src }}',
	asyn:true,

    },
    
  	toolTip:{
        type : 'WinsetToolTip',
        x: '{{x}}',
		y: 144,
		width: '{{w}}',
    	height: '{{h}}',
		style: '{{style}}',
		nResoultionStyle: '{{nResoultionStyle}}',
		text: '{{text}}',
		tailPostion: '{{tailPostion}}',
		//parent:scene
    },
};

exports = GamesMainTemplate;
