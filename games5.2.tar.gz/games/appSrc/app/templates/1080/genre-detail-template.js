var GenreDetailTemplate = {
    genreItem:[
        {
            type:'widget',
            x : 0,
            y : 0,
            width : 323,
            height : 431,
            color:Volt.hexToRgb('#d4d4d4'),
            children:[
                {
                    type:'image',
                    x : 0,
                    y : 0,
                    width : 323,
                    height : 431,
                    src : Volt.getRemoteUrl('images/' + scene.height + '/icon_blank_thumbnail.png'),
                    fillMode : 'center',
                }
            ]
        },
		{
			type:'Thumbnail',
			visibleStyles: (0x01 | 0x20),
			x : 0,y : 0,width : 324,height : 324,
			image:{src: '{{ imgUrl }}',
				width: 324,
				height: 324},
			custom:{ID:'IMG'},
			information:{
				x: 0,
				y: 324,
				width: 324,
				height: 108,
				text1:{
					x:20,
					y:10,
					width:324,
					height: 36,
					font: 'SamsungSmart_Light 26px',
					text: '{{ title }}',
					singleLineMode: true},
				text2:{
					x:20,
					y:58,
					width:176,
					height: 28,
					font: 'SamsungSmart_Medium 20px',
					text: '{{genre}}',
					singleLineMode: true},
				},
			

		},
    ],
    
    imageWidget:{
        type: 'image',
        width: 17, 
        height: 17,
        src : '{{ src }}',
        asyn:true,
    },
}

exports=GenreDetailTemplate;