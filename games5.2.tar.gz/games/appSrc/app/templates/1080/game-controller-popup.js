var GameControllerGuideTemplate = {
    container : {
        parent : scene,
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.sceneWidth,
        height : 1080,
        color : Volt.hexToRgb('#000000', 77),
        children : [{
                type : 'widget',
                id : 'game-content-container',
                x : 0,
                y : 1080 * 0.142593,
                width : Volt.sceneWidth,
                height : 1080 * 0.713889,
                color : Volt.hexToRgb('#f1f1f1'),
                },
        ]
    },

    gamePageOne : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.sceneWidth,
        height : 1080 * 0.713889,
        color : Volt.hexToRgb('#f1f1f1'),
        horizontalAlignment : 'center',
        verticalAlignment : 'center',

        children : [{
                type : 'text',
                x : Volt.sceneWidth * 0.24375 / 2,
                y : 1080 * 0.083333,
                width : Volt.sceneWidth * 0.75625,
                height : 1080 * 0.098148,
                horizontalAlignment : 'center',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#101010', 100),
                font : 'SamsungSmart_Light 78px',
                text : '{{page_text0}}'
            }, {
                type : 'text',
                x : Volt.sceneWidth * 0.24375 / 2,
                y : 1080 * (0.083333 + 0.098148),
                width : Volt.sceneWidth * 0.75625,
                height : 1080 * 0.037037 * 2,
                horizontalAlignment : 'center',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#000000', 100),
                font : 'SamsungSmart_Light 34px',
                text : '{{page_text1}}'
            }, {
                type : 'image',
                x : Volt.sceneWidth * 0.057292,
                y : (771 - 56) / 2,
                width : 219,
                height : 1080 * 0.378704 +4,
                src : '{{page_image0}}'
            }, {
                type : 'image',
                x : Volt.sceneWidth * 0.057292 + 219 + 36,
                y : (771 - 56) / 2,
                width : 219,
                height : 1080 * 0.378704 +4,
                src : '{{page_image1}}'
            }, {
                type : 'image',
                x : Volt.sceneWidth * 0.057292 + 219 * 2 + 36 * 2,
                y : (771 - 56) / 2,
                width : 450,
                height : 1080 * 0.378704 +4,
                src : '{{page_image2}}'
            }, {
                type : 'image',
                x : Volt.sceneWidth * 0.057292 + 219 * 2 + 36 * 3 + 450,
                y : (771 - 56) / 2,
                width : 219,
                height : 1080 * 0.378704 +4,
                src : '{{page_image3}}'
            }, {
                type : 'image',
                x : Volt.sceneWidth * 0.057292 + 219 * 3 + 36 * 4 + 450,
                y : (771 - 56) / 2,
                width : 450,
                height : 1080 * 0.378704 +4,
                src : '{{page_image4}}'
            }, {
                type : 'text',
                x : Volt.sceneWidth * 0.015625,
                y : 721,
                width : Volt.sceneWidth * (0.5 - 0.015625),
                height : 1080 * 0.027778,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#000000', 60),
                font : 'SamsungSmart_Light 22px',
                text : '{{page_text2}}'
            }, {
                //id:'CLOSE_BUTTON',
                custom : {'focusable' : true,},
                color : Volt.hexToRgb('#ffffff', 100),
                type : 'WinsetBtn',
                style : '{{style}}',
                buttonType : '{{buttonType}}',
                x : Volt.sceneWidth * (1-0.141667) / 2,
                y : 771 - 1080 * (0.046296 + 0.062963),
                width : Volt.sceneWidth * 0.141667,
                height : 1080 * 0.062963,
                text : Volt.i18n.t('COM_SID_CLOSE'),
                },
        ]
    },

    gamePageTwo : {
        type : 'widget',
        x : 0,
        y : 0,
        width : Volt.sceneWidth,
        height : 1080 * 0.713889,
        color : Volt.hexToRgb('#f1f1f1'),
        children : [{
                type : 'image',
                x : 0,
                y : 0,
                width : 960,
                height : 771,
                src : '{{page_image0}}'
            }, {
                type : 'image',
                y : 1080 * 0.100926,
                width : 42,
                height : 70,
                fillMode:'center',
                src : '{{page_image1}}'
            }, {
                type : 'image',
                x : 1040,
                y : 1080 * (0.100926 + 0.27963),
                width : 240,
                height : 150,
                src : '{{best_for_app_image0}}'
            }, {
                type : 'image',
                x : 1300,
                y : 1080 * (0.100926 + 0.27963),
                width : 240,
                height : 150,
                src : '{{best_for_app_image1}}'
            }, {
                type : 'image',
                x : 1560,
                y : 1080 * (0.100926 + 0.27963),
                width : 240,
                height : 150,
                src : '{{best_for_app_image2}}'
            }, {
                type : 'text',
                x : 1040,
                y : 1080 * 0.100926,
                height : 1080 * 0.064815,
                horizontalAlignment : 'left',
                verticalAlignment: 'center',
                textColor : Volt.hexToRgb('#000000', 100),
                font : 'SamsungSmart_Light 57px',
                text : '{{page_text0}}'
            }, {
                type : 'text',
                x : 1040,
                y : 1080 * (0.100926 + 0.082407),
                width : Volt.sceneWidth * 0.40625 + 40,
                height : 1080 * (0.02963 * 2 + 0.096296),
                horizontalAlignment : 'left',
                textColor : Volt.hexToRgb('#000000', 100),
                font : 'SamsungSmart_Light 27px',
                text : '{{page_text1}}'
            }, {
                type : 'text',
                x : Volt.sceneWidth * 0.015625,
                y : 721,
                width : Volt.sceneWidth * (0.5 - 0.015625),
                height : 1080 * 0.027778,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#000000', 40),
                font : 'SamsungSmart_Light 22px',
                text : '{{page_text2}}'
            }, {
                //id:'CLOSE_BUTTON',
                custom : {'focusable' : true,},
                color : Volt.hexToRgb('#ffffff', 100),
                type : 'WinsetBtn',
                style : '{{style}}',
                buttonType : '{{buttonType}}',
                x : Volt.sceneWidth * (1- 0.180208 - 0.141667),
                y : 771 - 1080 * (0.046296 + 0.062963),
                width : Volt.sceneWidth * 0.141667,
                height : 1080 * 0.062963,
                text : Volt.i18n.t('COM_SID_CLOSE'),
            },{
                type : 'text',
                x : 1040,
                y : 1080 * 0.338889,
                width : Volt.sceneWidth * 0.40625,
                height : 1080 * 0.02963,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#000000', 100),
                text : Volt.i18n.t('COM_SID_BEST_FOR'),
                font : 'SamsungSmart_Light 27px',
            }, {
                type : 'text',
                x : 1040,
                y : 1080 * 0.525926,
                width : Volt.sceneWidth * 0.126042,
                height : 1080 * 0.025926 * 2,
                horizontalAlignment : 'left',
                textColor : Volt.hexToRgb('#000000', 80),
                text : '{{page_text3}}',
                font : 'SamsungSmart_Light 22px',
            }, {
                type : 'text',
                x : 1300,
                y : 1080 * 0.525926,
                verticalAlignment : 'center',
                width : 521,
                height : 30,
                horizontalAlignment : 'left',
                textColor : Volt.hexToRgb('#000000', 80),
                text : '{{page_text4}}',
                font : 'SamsungSmart_Light 22px',
            }, {
                type : 'text',
                x : 1560,
                y : 1080 * 0.525926,
                width : 521,
                height : 30,
                horizontalAlignment : 'left',
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#000000', 80),
                text : '{{page_text5}}',
                font : 'SamsungSmart_Light 22px',
            },
        ]
    },

    gamePageDepth : {
        type : 'widget',
        x : 1720,
        y : 1080 * 0.027778,
        width : 140,
        height : 20,
        id : 'page_depth',
        color : Volt.hexToRgb('#f1f1f1', 0),
        children : [{
                type : 'image',
                x : 0,
                y : 0,
                width : 20,
                height : 20,
            }, {
                type : 'image',
                x : 30,
                y : 0,
                width : 20,
                height : 20,
            }, {
                type : 'image',
                x : 60,
                y : 0,
                width : 20,
                height : 20,
            }, {
                type : 'image',
                x : 90,
                y : 0,
                width : 20,
                height : 20,
            }, {
                type : 'image',
                x : 120,
                y : 0,
                width : 20,
                height : 20,
            }, {
                type : 'image',
                x : 150,
                y : 0,
                width : 20,
                height : 20,
            },
        ]
    },

    LeftArrorw : {
        type : 'image',
        x : Volt.sceneWidth * 0.015625,
        y : 1080 * 0.338889,
        width : 32,
        height : 56,
        opacity : 204,
        src : Volt.GAMES_REVERSE ? Volt.getRemoteUrl('images/' + scene.height + '/games/g_gcg_comon_arrow_r.png') : Volt.getRemoteUrl('images/' + scene.height + '/games/g_gcg_comon_arrow_l.png'),
    },

    RightArrow : {
        type : 'image',
        x : Volt.sceneWidth * (1 - 0.015625) - 32,
        y : 1080 * 0.338889,
        width : 32,
        height : 56,
        opacity : 204,
        src : Volt.GAMES_REVERSE ? Volt.getRemoteUrl('images/' + scene.height + '/games/g_gcg_comon_arrow_l.png') : Volt.getRemoteUrl('images/' + scene.height + '/games/g_gcg_comon_arrow_r.png'),
    },

    gridList : {
        id:'GameControllerGuide',
        x : 0,
        y : 0,
        width : Volt.sceneWidth,
        height : 1080 * 0.713889,
        titleSpace : 0,
        groupSpace : 0,
        cellSpace : 0,
        focusRangeStartOffset : 0,
        focusRangeEndOffset : 0
    },
    
}
exports = GameControllerGuideTemplate;
