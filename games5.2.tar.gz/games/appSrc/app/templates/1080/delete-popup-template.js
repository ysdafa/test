var DeletePopupTemplate = {
    container : {
        parent:scene,
        type: 'widget',
       
        x: 0, y: 1080 *(1 - 0.287037)/2, width: Volt.sceneWidth, height : 1080 * 0.287037,
        color : Volt.hexToRgb('#0f1826',85),
        children : [
            {
                type : 'widget',
                id : 'description-container',
                x : Volt.sceneWidth * 0.239063, y : 1080 * 0.034259, 
                width : Volt.sceneWidth * 0.40625, height : 1080 * (0.044444 * 2),
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : Volt.sceneWidth * 0.239063, y : 1080 * (0.044444 * 2 + 0.034259),
                width : Volt.sceneWidth * (1 - 0.239063 * 2), height : 1080 * 0.042593,
                id : 'progressbar-container',
                color : Volt.hexToRgb('#ffffff',0),
            },
            {
                type : 'widget',
                x : Volt.sceneWidth * 0.239063, y : 1080 * 0.185185, 
                width : Volt.sceneWidth * (1 - 0.239063 * 2) , height : 1080 * 0.061111,
                id : 'button-container',
                color : Volt.hexToRgb('#ffffff',0),
            }
        ]
    },

    description: { 
        type : 'widget',
        x: 0, y: 0, width: Volt.sceneWidth * 0.40625, height: 1080 * (0.044444 * 2),
        color : Volt.hexToRgb('#000000',0),
        children :[{
            type : 'text',
            x : 0, y : 0, width : Volt.sceneWidth * 0.40625, height : 1080 * 0.044444,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            color : Volt.hexToRgb('#0f1826', 0),
            textColor : Volt.hexToRgb('#ffffff', 100),
            text : '',
            font : 'SamsungSmart_Light 34px'
        }, {
            type : 'text',
            x : 0, y : 1080 * 0.044444, width : Volt.sceneWidth * 0.40625, height : 1080 * 0.044444,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            color : Volt.hexToRgb('#0f1826', 0),
            textColor : Volt.hexToRgb('#ffffff', 100),
            text : '',
            font : 'SamsungSmart_Light 34px'
        }]
    },
    
    progressBar: {
        type: 'widget',        
        x: 0, y: 0, width: Volt.sceneWidth * (1 - 0.239063 * 2), height: 1080 * 0.042593,
        color : Volt.hexToRgb('#000000',0),
        children : [{
            type : 'widget',
            x: 0, y: 1080 * 0.020370, 
            width: Volt.sceneWidth * 0.40625, height: 1080 * 0.001852,
            color : Volt.hexToRgb('#000000',0),
            id:'progressBar',
        },{
            type : 'text',
            id : 'percentText',
            x : Volt.sceneWidth * (0.40625 + 0.020833), y : 0, 
            width : Volt.sceneWidth * 0.046875, height : 1080 * 0.042593,
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            color : Volt.hexToRgb('#0f1826', 0),
            textColor : Volt.hexToRgb('#ffffff', 100),
            text : '1%',
            font : 'SamsungSmart_Light 32px'
        }]
    },
            
    button:{
        type : 'widget',
        x : 0, y : 0, width : Volt.sceneWidth * (1 - 0.239063 * 2), height : 1080 * 0.061111,
        color : Volt.hexToRgb('#000000',0),
        children : [{
            type : 'widget',
            id : 'Cancel',
            custom : {'focusable' : true,},
            x : Volt.sceneWidth * (1 - 0.239063 * 2 - 0.140625 -0.046875)/2, y : 0,
            width : Volt.sceneWidth * 0.140625, height : 1080 * 0.061111,
            color : Volt.hexToRgb('#ffffff',0),
            
            children:[{
                type : 'WinsetBtn',
                style : '{{style}}',
                buttonType : '{{buttonType}}',
                id : 'cancelBtn',
                x : 0,
                y : 0,
                width : Volt.sceneWidth * 0.140625,
                height : 1080 * 0.061111,
                text : Volt.i18n.t('COM_SID_CANCEL'),
            }]

        }]
    },
};

exports = DeletePopupTemplate;