var titleTextColor = Volt.hexToRgb('#FFFFFF', 90);
var storageTextColor = Volt.hexToRgb('#FFFFFF', 100);
var infoTextColor = Volt.hexToRgb('#FFFFFF', 100);
var barColor = Volt.hexToRgb('#FFFFFF', 20);
var DetailTemplate = {
    container : {
        parent : scene,
        type : 'widget',
        id : 'detail-view-bg-area',
        x : 0,
        y : 0,
        width : Volt.sceneWidth,
        height : 1080,
        color : Volt.hexToRgb('#1f2b3d', 100),
        children : [{
            type : 'widget',
            id : 'detail-view-bg-area-dim-layer',
            x : 0,
            y : 0,
            width : Volt.sceneWidth,
            height : 1080,
            color : Volt.hexToRgb('#000000', 0),
            children : [{
                type : 'widget',
                id : 'detail-view-title-area',
                x : 0,
                y : 0,
                width : Volt.sceneWidth,
                height : 1080 * 0.133333,
                color : Volt.hexToRgb('#1f2b3d', 100)
            }, {
                type : 'widget',
                x : Volt.sceneWidth === 2560 ? 320 : 0,
                y : 1080 * 0.133333,
                width : 1920,
                height : 1080 * (1 - 0.133333),
                color : Volt.hexToRgb('#233146', 0),
                children : [{
                    id : 'detail-view-content-area',
                    type : 'widget',
                    x : 0,
                    y : 0,
                    width : 1920,
                    height : 1080 * (1 - 0.133333),
                    color : Volt.hexToRgb('#233146', 100),
                    children : [
                    {
                        type : 'widget',
                        id : 'detail-view-gamesthumbnail-area',
                        x : Math.floor(1920 * 0.020833),
                        y : 0,
                        width : Math.floor(1920 * 0.341667)-1,
                        height : Math.floor(1080 * 0.341667)-1,
                        color : Volt.hexToRgb('#FFFFFF', 0),
                        cropOverflow : true
                        
                    }, {
                        type : 'widget',
                        id : 'detail-view-storage-area',
                        x : 1920 * 0.020833,
                        y : 1080 * (0.64537 - 0.133333),
                        width : 1920 * 0.144271,
                        height : 1080 * 0.074074,
                        color : Volt.hexToRgb('#FFFFFF', 0)
                    }, {
                        type : 'widget',
                        id : 'detail-view-gamesinfo-area',
                        x : 1920 * (0.020833 + 0.341667 + 0.026042),
                        y : 0,
                        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
                        height : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185 * 3 + 0.031481),
                        color : Volt.hexToRgb('#FFFFFF', 0)
                    }, {
                        type : 'widget',
                        id : 'detail-view-moreinfo-area',
                        x : 1920 * (0.020833 + 0.341667 + 0.026042),
                        y : 1080 * 0.256481 - 26,
                        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
                        height : 1080 * (1 - 0.133333 - 0.256481) + 26,
                        color : Volt.hexToRgb('#FFFFFF', 0)
                    }, {
                        type : 'widget',
                        id : 'detail-view-description-area',
                        x : 1920 * (0.020833 + 0.341667 + 0.026042),
                        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
                        height : 1080 * (0.035185 * 3 + 0.025926),
                        color : Volt.hexToRgb('#FFFFFF', 0)
                    }, {
                        type : 'widget',
                        id : 'detail-view-screenshot-area',
                        x : 1920 * (0.020833 + 0.341667 + 0.026042),
                        width : 1920 * (0.140625 * 4 + 0.005208 * 3) + 5,
                        height : 1080 * (0.138889 + 0.037037),
                        color : Volt.hexToRgb('#FFFFFF', 0)
                    }, {
                        type : 'widget',
                        id : 'detail-view-button-area',
                        x : 1920 * (0.020833 + 0.341667 + 0.026042),
                        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
                        height : 1080 * (0.060185 + 0.018519 + 0.001852 + 0.011111 + 0.018519 * 2 + 0.025926),
                        color : Volt.hexToRgb('#FFFFFF', 0)
                    }]
                }]
            }, {
                type : 'widget',
                x : 0,
                y : 1080 * 0.798148,
                width : Volt.sceneWidth,
                height : 1080 * (1 - 0.798148),
                id : 'detail-view-relate-area',
                color : Volt.hexToRgb('#1f2b3d', 0),
                children : [{
                    type : 'widget',
                    id : 'detail-view-relate-area-dim-layer',
                    x : 0,
                    y : 1080 * (1 - 0.151852 - 0.798148),
                    width : Volt.sceneWidth,
                    height : 1080 * 0.151852,
                    color : Volt.hexToRgb('#1f2b3d', 100)
                }, {
                    type : 'widget',
                    id : 'detail-relate-container',
                    x : 0,
                    y : 1080 * (1 - 0.151852 - 0.798148),
                    width : Volt.sceneWidth,
                    height : 1080 * 0.151852,
                    color : Volt.hexToRgb('#000000', 0)
                }, {
                    type : 'text',
                    id : 'detail_relate_video_text',
                    x : 1920 * 0.0125,
                    y : 0,
                    height : 1080 * 0.048148,
                    text : Volt.i18n.t('COM_SID_VIDEOS'),
                    textColor : Volt.hexToRgb('#FFFFFF', 0),
                    color : Volt.hexToRgb('#FFFFFF', 0),
                    font : 'SamsungSmart_Light 26px',
                    horizontalAlignment : 'left',
                    verticalAlignment : 'center'
                }]
            }, {
                id : 'detail-popup-container',
                type : 'widget',
                x : 0,
                y : 0,
                width : 1920,
                height : 1080,
                color : Volt.hexToRgb('#000000', 0)
            }]
        }]
    },

    games_title : {
        type : 'text',
        x : 0,
        y : 0,
        width : Volt.sceneWidth,
        height : 1080 * 0.133333,
        textColor : titleTextColor,
        font : "SamsungSmart_Light 66px",
        horizontalAlignment : "center",
        verticalAlignment : "center",
        ellipsize : true,
        id : 'games_title_view_text',
        text : '{{game_title}}',
        children : [{
            type : 'widget',
            id : 'detail-view-title-returnicon-area',
            x : 0,
            y : 0,
            width : Volt.sceneWidth * 0.051563,
            height : 1080 * 0.133333,
            color : Volt.hexToRgb('#000000', 0),
            children : [{
                type : 'widget',
                id : 'detail-back-icon-line',
                x : Volt.sceneWidth * 0.051563 - 1,
                y : 0,
                width : 1,
                height : 1080 * 0.133333,
                opacity : 26,
                color : Volt.hexToRgb('#ffffff')
            },]
        }, {
            type : 'widget',
            id : 'detail-view-title-closeicon-area',
            x : Volt.sceneWidth * (1 - 0.051563),
            y : 0,
            width : Volt.sceneWidth * 0.051563,
            height : 1080 * 0.133333,
            color : Volt.hexToRgb('#000000', 0),
            children : [{
                type : 'widget',
                id : 'detail-close-icon-line',
                x : 0,
                y : 0,
                width : 1,
                height : 1080 * 0.133333,
                opacity : 26,
                color : Volt.hexToRgb('#ffffff')
            },]
        }, ]

    },

    backBtn : {
        id : 'back-icon',
        x : 0,
        y : 0,
        width : 1920 * 0.051563 ,
        height : 1080 * 0.133333 ,
        icon : {
            src : Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_tm_return.png'),
            x : (1920 * 0.051563 - 36) / 2,
            y : (1080 * 0.133333 - 36) / 2,
            width : 36,
            height : 36,
        },
        color : {
            r : 0,
            g : 0,
            b : 0,
            a : 0
        },
    },
    closeBtn : {
        id : 'close-icon',
        x : 0,
        y : 0,
        width : 1920 * 0.051563,
        height : 1080 * 0.133333,
        icon : {
            src : Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_tm_close.png'),
            x : (1920 * 0.051563 - 36) / 2,
            y : (1080 * 0.133333 - 36) / 2,
            width : 36,
            height : 36,
        },
        color : {
            r : 0,
            g : 0,
            b : 0,
            a : 0
        },
    },

    info_area : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
        height : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185 * 3 + 0.031481),
        color : Volt.hexToRgb('#FFFFFF', 0),
        children : [{
            type : 'text',
            id : 'genre',
            x : 0,
            y : 1080 * 0.02963,
            //width:500,
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : 'SamsungSmart_Light 32px',
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            text : '{{genre}}'
        }, {
            type : 'text',
            id : 'rating',
            y : 1080 * 0.02963,
            width : 1920 * 0.020833,
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : 'SamsungSmart_Light 26px',
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            //ellipsize:true,
            text : '{{rating}}'
        }, {
            type : 'text',
            id : 'price',
            x : 0,
            y : 1080 * (0.02963 + 0.035185 + 0.019444),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : '{{price}}'
        }, {
            type : 'widget',
            id : 'priceBar',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.008333),
            width : 1920 * 0.000521,
            height : 1080 * 0.018519,
            color : barColor
        }, {
            type : 'text',
            y : 1080 * (0.02963 + 0.035185 + 0.019444),
            height : 1080 * 0.035185,
            id : 'ratedTxt',
            textColor : infoTextColor,
            font : 'SamsungSmart_Light 26px',
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            text : Volt.i18n.t('SID_RATED') + ': '
        }, {
            type : 'text',
            id : 'ratedNoTxt',
            y : 1080 * (0.02963 + 0.035185 + 0.019444),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : '{{ gameAgeRating }}'
        }, {
            type : 'image',
            id : 'ageRatingImage',
            y : parseInt(1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185 / 2)) - 13,
            width : 26,
            height : 26,
            src : '{{ageRatingUrl}}'
        }, {
            type : 'widget',
            id : 'ratedBar',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.008333),
            width : 1920 * 0.000521,
            height : 1080 * 0.018519,
            color : barColor
        }, {
            type : 'text',
            y : 1080 * (0.02963 + 0.035185 + 0.019444),
            height : 1080 * 0.035185,
            id : 'sizeTxt',
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : Volt.i18n.t('COM_BDP_SID_HTS_SPKR_SIZE_TEXT') + ': '
        }, {
            type : 'text',
            id : 'sizeInfoTxt',
            y : 1080 * (0.02963 + 0.035185 + 0.019444),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : '{{ size }}'
        }, {
            type : 'widget',
            id : 'sizeBar',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.008333),
            width : 1920 * 0.000521,
            height : 1080 * 0.018519,
            color : barColor
        }, {
            type : 'text',
            id : 'updatedTxt',
            y : 1080 * (0.02963 + 0.035185 + 0.019444),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : Volt.i18n.t('COM_SID_UPDATED') + ' '
        }, {
            type : 'text',
            id : 'updateInfoTxt',
            y : 1080 * (0.02963 + 0.035185 + 0.019444),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : '{{ updatedDate }}'
        }, 
        /*{
            type : 'widget',
            id : 'updatedBar',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.008333),
            width : 1920 * 0.000521,
            height : 1080 * 0.018519,
            color : barColor
        }, 
        */
       {
            type : 'text',
            id : 'lastVerTxt',
            x : 0,
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : Volt.i18n.t('TV_SID_LASTEST_VERSION') + ": "
        }, {
            type : 'text',
            id : 'verInfoTxt',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : "Ver. " + '{{ version }}'
        }, {
            type : 'widget',
            id : 'lastVerBar',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185 + 0.008333),
            width : 1920 * 0.000521,
            height : 1080 * 0.018519,
            color : barColor
        },{
            type : 'text',
            id : 'lang',
            //x : 0,
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : Volt.i18n.t('TV_SID_LANGUAGE') + " "
        }, {
            type : 'text',
            id : 'langInfoTxt',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : '{{ language }}'
        }, 
        /*{
            type : 'widget',
            id : 'langBar',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185 + 0.008333),
            width : 1920 * 0.000521,
            height : 1080 * 0.018519,
            color : barColor
        }, {
            type : 'text',
            id : 'devTxt',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : Volt.i18n.t('COM_SID_DEVELOPER') + ': '
        }, {
            type : 'text',
            id : 'devInfo',
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : '{{developer}}'
        }, */
        {
            type : 'text',
            id : 'ctrllerTxt',
            x : 0,
            y : 1080 * (0.02963 + 0.035185 + 0.019444 + 0.035185 * 2),
            height : 1080 * 0.035185,
            textColor : infoTextColor,
            font : "SamsungSmart_Light 26px",
            horizontalAlignment : "left",
            verticalAlignment : "center",
            text : Volt.i18n.t('COM_SID_CONTROLLERS') + ":"
        }]
    },

    description_area : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
        height : 1080 * (0.035185 * 3 + 0.025926),
        color : Volt.hexToRgb('#FFFFFF', 0),
        children : [{
            type : 'text',
            id : 'games_description_text_content',
            x : 0,
            y : 0,
            width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042 - 0.05625),
            cropOverflow : true,
            horizontalAlignment : "left",
            font : "SamsungSmart_Light 30px",
            color : Volt.hexToRgb('#FF0000', 0),
            textColor : infoTextColor
        }, {
            type : 'widget',
            id : 'more_button_widget',
            color : Volt.hexToRgb('#FFFFFF', 0),
            x : 1920 * (1 - 0.020833 - 0.341667 - 0.026042 - 0.05625 + 0.011458),
            y : 1080 * 0.035185 * 2.5 - 20,
            width : 40,
            height : 40,
            custom : {
                'focusable' : false
            }
        }]
    },

    more_description_area : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
        height : 1080 * (1 - 0.133333 - 0.256481) + 26,
        color : Volt.hexToRgb('#FFFFFF', 0),
        children : [{
            type : 'widget',
            id : 'games_more_description_text_content',
            x : 0,
            y : 1080 * 0.015741 + 26,
            width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042 - 0.05625),
            height : 1080 * 0.035185 * 13,
            color : Volt.hexToRgb('#FF0000', 0),
            cropOverflow : true
        }, {
            type : 'image',
            id : 'up_arrow',
            x : 0,
            y : 0,
            width : 1920 * 0.563542, 
            height : 1080 * 0.024074, 
            opacity : 153,
            src : Volt.getRemoteUrl('images/' + scene.height + '/games/games_detail_arrow_u.png'),
            rotation: {x: 0, y: Volt.GAMES_REVERSE ? 180 : 0, z: 0}
            //fillMode:'center',
        }, {
            type : 'image',
            id : 'down_arrow',
            x : 0,
            y : 1080 * (0.035185 * 13 + 0.015741 * 2) + 26,
            width : 1920 * 0.563542, //1236,
            height : 1080 * 0.024074, //32,
            opacity : 153,
            src : Volt.getRemoteUrl('images/' + scene.height + '/games/games_detail_arrow_d.png'),
            rotation: {x: 0, y: Volt.GAMES_REVERSE ? 180 : 0, z: 0}
            //fillMode:'center',
        }, {
            type : 'widget',
            id : 'moreinfo_close_button_widget',
            color : Volt.hexToRgb('#FFFFFF', 0),
            x : 1920 * 0.192188,
            y : 1080 * (1 - 0.133333 - 0.256481 - 0.027778 - 0.060185) + 26,
            width : 1920 * 0.161458,
            height : 1080 * 0.060185,
            children : [{
                type : 'WinsetBtn',
                style : '{{style}}',
                buttonType : '{{buttonType}}',
                resoultion : '{{resoultion}}',
                id : 'closeBtn',
                x : 0,
                y : 0,
                width : 1920 * 0.161458,
                height : 1080 * 0.060185,
                text : Volt.i18n.t('COM_SID_CLOSE'),
            }],
            custom : {
                'focusable' : true
            }
        }]
    },

    smartCtrllerImg : {
        type : 'image',
        y : (1080 * 0.035185 - 33) / 2,
        width : 32,
        height : 33,
        src : '',
        fillMode : 'stretch'
    },

    smartCtrllerTxt : {
        type : 'text',
        y : 0,
        height : 1080 * 0.035185,
        textColor : infoTextColor,
        font : "SamsungSmart_Light 26px",
        horizontalAlignment : "left",
        verticalAlignment : "center",
        text : '{{text}}'
    },

    smartCtrllerBar : {
        type : 'widget',
        y : 0,
        width : 1920 * 0.000521,
        height : 1080 * 0.018519,
        color : barColor
    },

    star : {
        type : 'image',
        width : 20,
        height : 20,
        src : '',
        fillMode : "stretch",
    },

    storageinfo_area : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920 * 0.144271,
        height : 1080 * (0.027778 + 0.001852 + 0.022222 * 2),
        color : Volt.hexToRgb('#FFFFFF', 0),
        children : [
        {
            type : 'text',
            id : 'storage_text_info',
            x : 0,
            y : 0,
            height : 1080 * 0.027778,
            textColor : storageTextColor,
            font : 'SamsungSmart_Medium 20px',
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            text : Volt.i18n.t('TV_SID_INTERNAL_MEMORY_INFO')
        }, {
            type : 'text',
            id : 'storage_text',
            x : 0,
            y : 0,
            //width : 1920 * 0.144271 + 160,
            height : 1080 * 0.027778,
            textColor : storageTextColor,
            font : 'SamsungSmart_Medium 20px',
            horizontalAlignment : 'left',
            verticalAlignment : 'center',
            text : ""
        }, {
            type : 'text',
            x : 0,
            y : 1080 * (0.027778 + 0.001852),
            width : 1920 * 0.066667 + 100,
            height : 1080 * 0.024075,
            textColor : storageTextColor,
            font : 'SamsungSmart_Light 20px',
            horizontalAlignment : 'left',
            verticalAlignment : 'bottom',
            text : Volt.i18n.t('COM_SID_USED_KR_ING')
        }, {
            type : 'text',
            id : 'memory_used_text',
            x : 0,
            y : 1080 * (0.027778 + 0.001852 + 0.022222),
            width : 1920 * 0.066667,
            height : 1080 * 0.022222,
            textColor : storageTextColor,
            font : 'SamsungSmart_Light 20px',
            horizontalAlignment : 'left',
            verticalAlignment : 'bottom',
            text : ""
        }, {
            type : 'text',
            x : 1920 * (0.144271 - 0.066667),
            y : 1080 * (0.027778 + 0.001852),
            width : 1920 * 0.066667 + 60,
            height : 1080 * 0.024075,
            textColor : storageTextColor,
            font : 'SamsungSmart_Light 20px',
            horizontalAlignment : 'right',
            verticalAlignment : 'bottom',
            text : Volt.i18n.t('TV_SID_AVAILABLE_EMPTY')
        }, {
            type : 'text',
            id : 'memory_avaliable_text',
            x : 1920 * (0.144271 - 0.066667),
            y : 1080 * (0.027778 + 0.001852 + 0.022222),
            width : 1920 * 0.066667 + 60,
            height : 1080 * 0.022222,
            textColor : storageTextColor,
            font : 'SamsungSmart_Light 20px',
            horizontalAlignment : 'right',
            verticalAlignment : 'bottom',
            text : ""
        }]
    },

    button_area : {
        type : 'widget',
        x : 0,
        y : 0,
        width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042),
        height : 1080 * (0.060185 + 0.018519 + 0.001852 + 0.011111 + 0.018519 * 2 + 0.025926),
        color : Volt.hexToRgb('#FFFFFF', 0),
        children : [{
            type : 'widget',
            id : 'download_button_widget',
            color : Volt.hexToRgb('#FFFFFF', 0),
            x : 0,
            y : 0,
            width : 1920 * 0.161458,
            height : 1080 * 0.060185,
            custom : {
                'focusable' : true
            }
        }, {
            type : 'widget',
            id : 'download_button_progressbar',
            color : Volt.hexToRgb('#FFFFFF', 0),
            x : 0,
            y : 1080 * (0.060185 + 0.018519),
            width : 1920 * 0.161458,
            height : 1080 * 0.001852,
            custom : {
                'focusable' : false
            }
        }, {
            type : 'text',
            id : 'memory_running_low_text',
            x : 0,
            y : 1080 * (0.060185 + 0.018519 + 0.001852 + 0.011111),
            width : 1920 * (1 - 0.020833 - 0.341667 - 0.026042 - 0.05625 + 0.011458),
            height : 1080 * 0.018519 * 2 + 10,
            lineSpacing: 5,
            horizontalAlignment : "left",
            verticalAlignment : "center",
            textColor : infoTextColor,
            font : 'SamsungSmart_Light 20px',
            text : "",
            custom : {
                'focusable' : false
            }
        }, {
            type : 'widget',
            id : 'rating_button_widget',
            color : Volt.hexToRgb('#FFFFFF', 0),
            x : 1920 * (0.161458 + 0.013021),
            y : 0,
            width : 1920 * 0.161458,
            height : 1080 * 0.060185,
            custom : {
                'focusable' : true
            }
        }, {
            type : 'widget',
            id : 'controller_button_widget',
            color : Volt.hexToRgb('#FFFFFF', 0),
            x : 1920 * (0.161458 + 0.013021) * 2,
            y : 0,
            width : 1920 * 0.033854,
            height : 1080 * 0.060185,
            custom : {
                'focusable' : true
            }
        }]
    },

    downloadBtn : {
        type : 'WinsetBtn',
        style : '{{style}}',
        buttonType : '{{buttonType}}',
        resoultion : '{{resoultion}}',
        id : "downloadBtn",
        x : 0,
        y : 0,
        width : 1920 * 0.161458,
        height : 1080 * 0.060185,
        text : Volt.i18n.t('COM_SID_DOWNLOAD')
    },

    shareBtn : {
        type : 'WinsetBtn',
        style : '{{style}}',
        resoultion : '{{resoultion}}',
        id : 'shareBtn',
        buttonType : '{{buttonType}}',
        iconImgSrc : Volt.getRemoteUrl("images/" + scene.height + "/g_detail_icon_facebook.png"),
        iconHeight : 1080 * 0.060185,
        iconWidth : 1920 * 0.033854,
        width : 1920 * 0.033854,
        height : 1080 * 0.060185,
        x : 0,
        y : 0
    },

    controllerBtn : {
        type : 'WinsetBtn',
        style : '{{style}}',
        id : 'controllerBtn',
        buttonType : '{{buttonType}}',
        resoultion : '{{resoultion}}',
        iconImgSrc : Volt.getRemoteUrl("images/" + scene.height + "/g_detail_icon_control.png"),
        iconHeight : 1080 * 0.060185,
        iconWidth : 1920 * 0.033854,
        width : 1920 * 0.033854,
        height : 1080 * 0.060185,
        x : 0,
        y : 0
    },

    ratingBtn : {
        type : 'WinsetBtn',
        style : '{{style}}',
        buttonType : '{{buttonType}}',
        resoultion : '{{resoultion}}',
        id : "ratingBtn",
        x : 0,
        y : 0,
        width : 1920 * 0.161458,
        height : 1080 * 0.060185,
        text : ""
    },

    moreBtn : {
        type : 'WinsetBtn',
        style : '{{style}}',
        buttonType : '{{buttonType}}',
        resoultion : '{{resoultion}}',
        id : 'moreBtn',
        x : 0,
        y : 0,
        width : 40,
        height : 40,
        iconWidth : 30,
        iconHeight : 30,
        iconImgSrc : Volt.getRemoteUrl("images/" + scene.height + "/games/btn_icon_more.png")
    },

    toolTip : {
        type : 'WinsetToolTip',
        x : '{{x}}',
        y : '{{y}}',
        width : '{{w}}',
        height : '{{h}}',
        style : '{{style}}',
        nResoultionStyle : '{{nResoultionStyle}}',
        text : '{{text}}',
        tailPostion: '{{tailPostion}}',
        //parent : scene
    }
};

exports = DetailTemplate;