var LoadingTemplate = {
    dimWgt : {
        type : 'widget',
        id : 'loadDim',
        x : 0,
        y : 0,
        parent : scene,
        width : Volt.sceneWidth,
        height : 1080,
        color : {
            r : 0,
            g : 0,
            b : 0,
            a : 255 * 0.6
        },
        children : [{
            type : 'widget',
            id : 'pupLoadingBg',
            x : Volt.sceneWidth * (1 - 0.012963 - 0.177083),
            y : 1080 * 0.015741,
            width : Volt.sceneWidth * 0.177083,
            height : 1080 * 0.116667,
            color : Volt.hexToRgb('#0F1826', 85),
            children : [{
                type : 'WinsetLoading',
                id : 'popupLoading',
                x : (Volt.sceneWidth * 0.177083 - 201) / 2,
                y : (1080 * 0.116667 - 40) / 2,
                style : '{{style14}}',
                text : ""
            }]
        }, {
            type : 'WinsetLoading',
            id : "viewLoading",
            x : (Volt.sceneWidth - 301) / 2,
            y : (1080 - 58) / 2,
            style : '{{style20}}',
            text : ""
        }, {
            type : 'WinsetLoading',
            id : "videoLoading",
            style : '{{style17}}',
            text : ""
        }]
    },
};
exports = LoadingTemplate;
