var RatingTemplate = {
    container : {
		//parent:scene,
        type: 'widget',
		custom : {
			'focusable' : true,
			'onKeyEvent' : null
		},
        x: 0 , y: (1080-514)/2, width: Volt.sceneWidth, height : 418,
    	color : Volt.hexToRgb('#0a5d88'),
    	opacity: 255 * 0.85,
        children: [
		]			
    },

}

exports = RatingTemplate;

