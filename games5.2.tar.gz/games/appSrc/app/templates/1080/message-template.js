/**
 * @author tiansx
 */
var MessageTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0, y: 0, width: Volt.sceneWidth, height: 1080,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'message-header-container', // @20140624 update by tiansx for myPage optimization 
                type: 'widget',
                x: 0, y: 0, width: Volt.sceneWidth, height: 144,
                color: Volt.hexToRgb('#0f1826')
            },  {
                id: 'message-content-container', // @20140624 update by tiansx for myPage optimization 
                type: 'widget',
                x: 0, y: 144, width: Volt.sceneWidth, height: 936,
            },

        ]
    },

    header: {
        type: 'widget', x: 0, y: 0, width: Volt.sceneWidth, height: 144,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                type: 'text', x: 36, y: 0, width: 726, height: 144,
                verticalAlignment : 'center',
                textColor : Volt.hexToRgb('#ffffff'),
                opacity: 102,
                text : '',
                font : '50px'
            },
            {
                type : 'widget',
                id : 'message-box-back-icon-area',
                x : 0, y : 0, width : 100, height : 144,
                color : {r:0,g:0,b:0,a:0},
                children : [
				{
					type:'widget',
					id:'message-back-icon-line',
					x:99,
					y:0,
					width:1,
					height:144,
					opacity: 26,
					color : Volt.hexToRgb('#ffffff'),
				},
                {
                    type:'image',
                    id:'message-box-back-icon',
                    x:16,
                    y:54,
                    width:36,
                    height:36,
                    src:Volt.getRemoteUrl('images/' + scene.height + '/common/comn_icon_tm_return_nor.png'),
                    fillMode:"center",
                    horizontalAlignment:"center",
                    verticalAlignment:"center",
                },
                {
	                type: 'text', x: 36+100, y: 0, width: 726, height: 144,
	                verticalAlignment : 'center',
	                textColor : Volt.hexToRgb('#ffffff'),
	                opacity: 102,
	                text : '',
	                font : '50px'
	            },
              ]
            },
            {
                type: 'widget', x: 1623, y: 0, width: 292, height: 144,
                color: Volt.hexToRgb('#000000', 0),
                children: [                    
                    {
                        id: 'message-header-icon-alarm',
                        type: 'widget', x: 198, y: 0, width: 99, height: 144, opacity: 51,
                        color: Volt.hexToRgb('#000000', 0),
                        custom: { 'focusable': true },
                        text:'test',
                        children: [{
                            type : 'image',
                            x: 33, y: 55, width : 33, height : 33,
                            src : Volt.getRemoteUrl('images/' + scene.height + '/common/g_icon_alarm_nor.png')
                        },]
                    },
                ]
            }
        ]
    }, 

    gridItem:[
      {
        type:'widget',
        x: 0, y: 0, width: 540, height: 170,
        color : {r : 0,g : 0,b : 0,a:0},
        custom:{ID:'thumbnailUp'},
        children:[
            {
                type:'image',
                x: 0, y: 0, width: 540, height: 170,
                src: Volt.getRemoteUrl('images/' + scene.height + '/g_massage_bg_black.png'),
                children:[
                    {
                        type:'image',
                        x: 0, y: 0, width: 170, height: 170,
                        src:'{{imgUrl}}'
                    },
                    {
                        type:'text',
                        x: 202, y: 42, width: 306, height: 36,
                        font : 'SamsungSmart_Light 36px',
                        textColor : {r : 255,g : 255,b : 255},
                        opacity: 153,
                        ellipsize : true,
                        horizontalAlignment : "center",
                        verticalAlignment:"center",
                        text:'{{title}}'
                    },
                    {
                        type:'text',
                        x: 202, y: 88, width: 306, height: 36,
                        font : 'SamsungSmart_Light 26px',
                        textColor : {r : 255,g : 255,b : 255},
                        opacity: 153,
                        ellipsize : true,
                        horizontalAlignment : "center",
                        verticalAlignment:"center",
                        text:'{{date}}'
                    }
                ]          
            },
        ]
      },
      {
          type:'widget',
          x: 0, y: 170, width: 540, height: 298,
          color : {r : 0,g : 0,b : 0,a:0},
          custom:{ID:'thumbnailDown'},
          children:[
              {
                   type:'text',
                   x: 44, y: 18, width: 452, height: 262,
                   font : 'SamsungSmart_Light 26px',
                   textColor : {r : 255,g : 255,b : 255},
                   opacity: 153,
                   ellipsize : false,
                   horizontalAlignment : "center",
                   verticalAlignment:"center",
                   text:'{{messageInfo}}'             
              }
          ]
      }
      
    ]
};

exports = MessageTemplate;
