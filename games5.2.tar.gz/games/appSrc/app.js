(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.requireNoContext = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.requireNoContext('$VOLT_ROOT/modules/modules_distribution.min.js');
Volt.requireNoContext('distribution.min.js');


var DeepLinkWidgetID = "";
var editMode         = false;

var PanelCommon      = Volt.requireNoContext('lib/panel-common.js');
var EventMediator    = Volt.requireNoContext('app/common/event-mediator.js');
var CommonDefine     = Volt.requireNoContext('app/common/common-define.js');
var dimView          = Volt.requireNoContext('app/views/dim-view.js'); 
var DeviceModel      = Volt.requireNoContext("app/models/device-model.js");
var Backbone         = Volt.requireNoContext('lib/volt-backbone.js');
var networkStatus    = Volt.requireNoContext('app/common/network-state.js');
var ErrorHandling    = Volt.requireNoContext('app/common/error-handling.js');
var Utils            = Volt.requireNoContext('app/common/utils.js');
var voltapi          = Volt.requireNoContext('voltapi.js');
var voltapiWrapper   = Volt.requireNoContext('app/common/voltapi-wrapper.js');
Volt.KPIMapper       = Volt.requireNoContext('app/common/kpi-mapper.js');
var ServerController = Volt.requireNoContext('app/controller/server-controller.js');
var VoiceGuide       = Volt.requireNoContext('app/common/voiceGuide.js');
var CommonContent    = Volt.requireNoContext('app/common/common-content.js');
var KPI              = Volt.requireNoContext('lib/volt-kpi.js');
Volt.IsDeepLink = false;
Volt.pageItemIndex = 0;
if(HALOUtil.screenWidth){
	Volt.log('[app.js]Check HALOUtil.screenWidth undefined!!!! 1920 ');
    Volt.sceneWidth = HALOUtil.screenWidth;
} else {
	Volt.log('[app.js]Check  HALOUtil.screenWidth defined!!!!');
	Volt.sceneWidth = 1920;	
}

Volt.sceneHeight = 1080;
Volt.KPIParams = {event:'',cp:'',ssoby:'',appid:'',sp:'',content:'',status:''};
Volt.KPIAppId = '';
var MagicKey         = Volt.requireNoContext('app/common/MagicKey.js');

/**
 * Entry point for Volt application
 */
var initialize = function() {
	Volt.log('[app.js] initialize .....');
	try{
        Memory.init(3, 150 * 1024);
    }catch(e){
        Volt.log('[app.js] initialize did not support  Memory.init() function,please using latest image');
    }
    
    //EventMediator.on(CommonDefine.Event.MSGBOX_BUTTON, processMsgBoxEvent, this);
    preload();
    startApp();
    Stage.show();
};

function preload(){
    Volt.log('preload.......');
    setupEnv();    
    loadModules();
}

function postload(){
    Volt.log('postload.......');
    initNetwork();
    voltapiWrapper.init();//before initWAS
    ServerController.init(); //before initWAS
    initWAS();
    checkUSB();
}

function loadModules() {
    Volt.requireNoContext('lib/volt-global.js');
    Volt.requireNoContext('lib/volt-nav.js');
    Volt.requireNoContext('app/router.js');
    
    var WinsetBtn      = Volt.requireNoContext("WinsetUIElement/winsetButton.js");   
    var WinsetToolTip  = Volt.requireNoContext("WinsetUIElement/winsetToolTip.js");
    var WinsetInputBox = Volt.requireNoContext("WinsetUIElement/winsetInputBox.js");
    if(!WinsetBtn.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA){
    	Volt.log("[app.js]================  new button style");
    	CommonDefine.Winset.BUTTON_IMAGE_O_STYLE_F_FOCUS1 = 7;
    }
    PanelCommon.mapWidget('WinsetBtn',      WinsetBtn); 
    PanelCommon.mapWidget('WinsetToolTip',  WinsetToolTip);
    PanelCommon.mapWidget('WinsetInputBox', WinsetInputBox);
}

function setupEnv() { 
    DeviceModel.init();
    //multilingual
    Volt.i18n = Volt.requireNoContext('lib/volt-multilingual.js');
    //drawSplashImage();
    Volt.log('[app.js] setupEnv lauguage = ' + DeviceModel.get('languageCode'));
    Volt.i18n.init({
            lng : DeviceModel.get('languageCode'),
            resGetPath : 'lang/<<lng>>.json',
            getAsync : false,
            interpolationPrefix : '<<',
            interpolationSuffix : '>>'
        }, function(t) {}
    );
    
    checkAccessibility();
    HALOUtil.applyOrientation();
    Volt.GAMES_REVERSE = (HALOUtil.getOrientation() == 'right-to-left');
}

function initNetwork(){
    networkStatus.init();
    if(voltapi.network.isOpened() === false){
        Volt.log('[app.js] network not initialized........');
        var retry = 0;
        function networkAsyncCallback(is_success){
            Volt.log('networkAsyncCallback Successful or not:::'+is_success);
            if(is_success){
                EventMediator.trigger(CommonDefine.Event.NETWORK_READY);
            } else {
                Volt.log('networkAsyncCallback Fail, retry::'+retry);
                if(retry < 1){
                    voltapi.network.initAsync(networkAsyncCallback);
                    retry++;
                }
            }
        }
        voltapi.network.initAsync(networkAsyncCallback);
    }
}

function initWAS(){
    if(voltapi.WAS.isOpened() === false) {
        Volt.log('[app.js] was not initialized........');
        var retry = 0;
        function WASAsyncCallback(is_success){
            Volt.log('WASAsyncCallback Successful or not:::'+is_success);
            if(is_success){
                EventMediator.trigger(CommonDefine.Event.WAS_READY);
                Volt.KPIMapper.init();
                checkReset();
            } else {
                Volt.log('WASAsyncCallback Fail, retry :::'+retry);
                if(retry < 1){
                    voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
                    retry++;
                }
            }
        }

        function WASAsyncReopenCallback(){
            Volt.log('WASAsyncReopenCallback Successful');
            EventMediator.trigger(CommonDefine.Event.WAS_READY);      
        }

        voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
	}
}

function startApp(){
    Volt.bQueuingPlay = true;
    Backbone.history.start();

    //if network error, first screen will popup network error
    /*var status = networkStatus.getNetWorkState();
    print('[app.js] status ::' + status);
    if(!status){
        print('!!!!!!!!!!!!!!!!network error!!!!!!!!!!!!!!!!!!!!!!!');
        networkPopup = true;
        ErrorHandling.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR);
        return;
    } */
	ErrorHandling.initialize();
    if (!Volt.IsDeepLink) {
        Volt.log("[App.js]Is not deeplink");
        EventMediator.on('GAMES_POST_LOAD', postload, this);
        Backbone.history.navigate('home', {
            trigger : true
        });
        Volt.first = true;
    } else {
        Volt.log("[App.js]Is deeplink,widget ID = " + DeepLinkWidgetID);
        postload();
        Volt.KPIAppId = DeepLinkWidgetID;
        Backbone.history.navigate('detail/' + DeepLinkWidgetID, {
            trigger : true
        });
    }
}

var onShow = function(data){
    Volt.log("[App.js]receive event ON_SHOW:" + JSON.stringify(data));
    sendLog(KPI.LOG_APP_START);
    if (data == undefined || data == null) {
        Volt.log('data is null or undefined');
        return;
    }

    if (data["Sub_Menu"] == "detail") {
		Volt.IsDeepLink = true;
        DeepLinkWidgetID = data["widget_id"];
    }
};

var onResume = function() {
    Volt.log('[app.js] ON_RESUME .....');
    Volt.KPIMapper.KPILogEnterPage();
    EventMediator.trigger(CommonDefine.Const.UPDATE_ITEMS);
    sendLog(KPI.LOG_APP_START);
};

var onPause = function() {
    Volt.log('[app.js] ON_PAUSE .....');
    VDUtil.AppControl_InitDbusConnection();
    VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.games");
    VDUtil.AppControl_FiniDbusConnection();

    Volt.KPIMapper.KPILogLeavePage();
    sendLog(KPI.LOG_APP_STOP);
};

var onHide = function() {
	Volt.log('[app.js] ON_HIDE .....');
	EventMediator.trigger(CommonDefine.Event.GAMES_EXIT, true);
    Volt.KPIMapper.KPILogLeavePage(); 
    sendLog(KPI.LOG_APP_STOP);
};

//note:need refine later.
var onReset = function(data) {
    Volt.log("[App.js]receive event ON_RESET::" + JSON.stringify(data));
    Volt.Reset = true;
    Volt.bQueuingPlay = false;
    voltapi.vconf.setValue('db/WaitingScreenApp/Visible', true);
    var visible = voltapi.vconf.getValue('db/WaitingScreenApp/Visible');
    Volt.log('visible::::'+visible);
    
    Stage.show();
    Volt.log("Call Stage.show()");	
    dimView.hide();
    
	if(data && data.widget_id){
		Volt.log('[App.js] enter into detail view.....');
        if(data.Sub_Menu == 'detail' ){
			Volt.log('[app.js] onReset DeepLinkWidgetID = ' + DeepLinkWidgetID + ',,,data.widget_id = ' + data.widget_id);
			if(DeepLinkWidgetID != data.widget_id){
				DeepLinkWidgetID = data.widget_id;
                Volt.IsDeepLink   = true;
                Volt.KPIAppId = DeepLinkWidgetID;
				Backbone.history.navigate('detail/' + data.widget_id, {
					replace : true,
		            trigger : true
		        });
			}
        }
	}
};

var onDeactive = function(){
    Volt.log("[App.js]receive event  CommonDefine.Event.GAMES_ON_DEACTIVATE");
    //stop voiceGuide first
    VoiceGuide.stopVoiceGuide();
    CommonContent.setPanelActive(false);
    CommonContent.checkDeleteResultPopup();
    ErrorHandling.destroyWidgetPopup();
    ErrorHandling.destroyNavigatePopup();
    EventMediator.trigger(CommonDefine.Event.GAMES_ON_DEACTIVATE);
};

var onActive = function(){
    Volt.log("[App.js]receive event CommonDefine.Event.GAMES_ON_ACTIVATE");
    var dMode = VDUtil.get3dMode();// <- getting 3d status
    Volt.log("[App.js] onActive dMode ="+ dMode);
    if (dMode != 0) {
        VDUtil.set3dMode(0);//3D effect off <- setting 3d off
    }

    EventMediator.trigger(CommonDefine.Event.GAMES_ON_ACTIVATE);
    CommonContent.setPanelActive(true);
};

/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function(keycode, type) {
    Volt.log("[app.js] onKeyEvent - keycode : " + keycode + " type : " + type);

    if(type == Volt.EVENT_KEY_PRESS){
        MagicKey.onKeyPress(keycode);
    }
    
    // if Volt.Nav didn't process the event, the app will process it.
    if (Volt.Nav.onKeyEvent(keycode, type) === false) {
        if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS) {
			var optionMenu = CommonContent.getOptionMenu();
			if (optionMenu) {
				if (optionMenu.getOptionMenuState()) {
					optionMenu.hide();
					return;
				}
			}
            if (Backbone.history.getCount() > 1) {
                Volt.log("[app.js]onKeyEvent Nav Return ..... ");
                //checkLastFocus();
                Backbone.history.back();
                Utils.Timer.clearTimeOut();
                DeepLinkWidgetID = '';
            } else {
                if(DeepLinkWidgetID && Volt.IsDeepLink){
                    Volt.log('previous view is detail, need to quit');
                    EventMediator.trigger(CommonDefine.Event.GAMES_EXIT, true);
                    Volt.quit();
                    checkTerminateApp();
                } else {
                    Volt.log("[app.js]onKeyEvent Nav Return Key press.....");
                    Volt.log("[app.js]Nav Exit Games Panel.....");
                    EventMediator.trigger(CommonDefine.Event.GAMES_EXIT, false);
                    Volt.exit(); 
                    checkTerminateApp();
                }
            }
        }
    }
};

Volt.addEventListener(Volt.ON_SHOW,       onShow);
Volt.addEventListener(Volt.ON_HIDE,       onHide);
Volt.addEventListener(Volt.ON_PAUSE,      onPause);
Volt.addEventListener(Volt.ON_RESUME,     onResume);
Volt.addEventListener(Volt.ON_DEACTIVATE, onDeactive);
Volt.addEventListener(Volt.ON_ACTIVATE,   onActive);
Volt.addEventListener(Volt.ON_RESET,      onReset); 

var checkReset = function() {
    Volt.log("[app.js] checkReset()");
    if(SmartHubReset && SmartHubReset.needReset){ 
        Volt.log('smarthub reset.....');    
		if(SmartHubReset.needReset()){
            //1.delete some config file & cached data....
            var localStorage = Volt.requireNoContext("lib/volt-local-storage.js");
	        localStorage.clear();
            SmartHubReset.clearCacheFolder();
	        //2.call reset API to SERVER.
            DeviceReset();
        }
        else{
          	Volt.log("[app.js] not need reset");
        }
    }  
};

var DeviceReset = function(){
    Volt.log('DeviceReset:::Smart Hub Reset');
    ServerController.callAPI({
            type: 'DELETE',
            url: "game/device/v2/reset"
        },{
            bodyValue: {},
            success : function(data, status, response) {
            	Volt.log("[------------Reset callback-----------] success result:" + data);
                //After Complete should call below API.
                SmartHubReset.resetComplete();
            },
            error : function(response, status, exception) {
            	Volt.log("[------------Reset callback-----------] error result:" + exception + JSON.stringify(response));
            },
            complete: function(response, status) {   
            	Volt.log("[------------completeCallback-----------] " + status);	
            }
        }
    );
};

var checkUSB = function() {
    Volt.log("[app.js] checkUSB()");
    var retry = 0;
    var onOpenCallback = function(is_success){
        Volt.log('contentMgrAsynCallback:::::is_success=>'+is_success);
        if(is_success){
            Volt.log("[app.js] Success Callback of ContentsMgr.initAsync()");
            var bConnect = voltapi.ContentsMgr.connect();
            Volt.log("[app.js] checkUSB(), connect: "+bConnect);
        } else {
            Volt.log("[app.js] Fail Callback of ContentsMgr.initAsync(), retry::"+retry);
            if(retry < 1){
                voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
                retry++;
            }
        }
    };

    var onSuccessCallback = function(){
        Volt.log("[app.js] checkUSB(): CONNECT_USB");
        CommonContent.setUsbState(true);
        //EventMediator.trigger(CommonDefine.Event.CONNECT_USB, arguments);
        Volt.log('[[app.js] checkUSB(): CONNECT_USB, arguments = ' + JSON.stringify(arguments));
        EventMediator.trigger(CommonDefine.Event.USB_CONNECT, arguments);
    };

    var onFailCallback = function(){
        Volt.log("[app.js] checkUSB(): DISCONNECT_USB");
        CommonContent.setUsbState(false);
        //EventMediator.trigger(CommonDefine.Event.DISCONNECT_USB, arguments);
        Volt.log('[app.js] checkUSB(): DISCONNECT_USB, arguments =' + JSON.stringify(arguments));
        EventMediator.trigger(CommonDefine.Event.USB_DISCONNECT, arguments);
    };

    voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
};

var checkAccessibility = function(){
    var highContrast = DeviceModel.get('highContrast');
    Volt.log("[app.js] checkAccessibility:highContrast is " + highContrast);
    if(highContrast){
        HALOUtil.highContrast = true;
    }else{
        HALOUtil.highContrast = false;
    }

    var focusZoom = DeviceModel.get('focusZoom');
    Volt.log("[app.js] checkAccessibility:focusZoom is " + focusZoom);
    if(focusZoom){
        HALOUtil.enlarge = true;
    }else{
        HALOUtil.enlarge = false;
    }
};

var checkTerminateApp = function(){
    Volt.log('checkTerminateApp');
    var aulAppTT = new Aul();
    if(Volt.terminatePhotoPlayerPID){
        Volt.log('terminatePkg org.tizen.photo-player-tv');
        aulAppTT.terminatePkg("org.tizen.photo-player-tv");
    }
    
    if(Volt.terminateVideoPlayerPID){
        Volt.log('terminatePkg org.tizen.video-player-tv');
        aulAppTT.terminatePkg("org.tizen.video-player-tv");
    }
};

var sendLog = function(log){
    var bWASOpen = voltapi.WAS.isOpened();
    Volt.log('[app.js] sendLog log = ' + log + ',,,bWASOpen = ' + bWASOpen);
    if(bWASOpen){
        KPI.sendLog(log);
    }else{
        EventMediator.once(CommonDefine.Event.WAS_READY, function () {
            KPI.sendLog(log);
        });
    }
};

/*
var processMsgBoxEvent = function(data){
    if(data.eventType == CommonDefine.Event.SELECT_BTN1) {
        switch(data.msgBoxtype) {
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                var aulApp = new Aul();
                aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
                break;
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_REQUIRE_NETWORK:
                Volt.quit();
                var aulApp = new Aul();
                aulApp.launchApp("org.volt.firstscreen");
                break;
            default:
                break;
        }
    } else if(data.eventType == CommonDefine.Event.SELECT_BTN2) {
        switch(data.msgBoxtype) {
            case CommonDefine.MsgBoxType.MSGBOX_TYPE_NETWORK_ERROR:
                Volt.quit();
                var aulApp = new Aul();
                aulApp.launchApp("org.volt.firstscreen");
                break;
            default:
                break;
        }
    }
}*/