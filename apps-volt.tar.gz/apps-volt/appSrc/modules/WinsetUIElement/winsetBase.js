/** 
 * @author Su Yan (su.yan@samsung.com)
 * @fileoverview defination winset base class.
 * @date    2015/04/27 (last modified date)
 *
 * Copyright 2015 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var winsetBase = function(){
/*	this.ResolutionStyle = 
	{
		Resolution_720:0,	
		Resolution_1080:1,
		Resolution_720_21_9:2,
		Resolution_1080_21_9:3,	
		Resolution_Style_MAX:4
	};
*/

};
	
winsetBase.ResolutionStyle = {
	Resolution_720:0,	
	Resolution_1080:1,
	Resolution_720_21_9:2,
	Resolution_1080_21_9:3,	
	Resolution_Style_MAX:4
};
winsetBase.validator =
{

    // validate rules object collections
	types: {},

    // validate error messages 
	messages: [],

    // validate types collections
	config: {},

    // public method    // parameter is object: key => value
	validate: function (data) {

        var i, msg, type, checker, result_ok;

        // clear messages
		this.messages = [];

        for (i in data) {
            if (data.hasOwnProperty(i)) {

                type = this.config[i];  // get the validate rule name from key                
				checker = this.types[type]; // get the validate object from rule
                if (!type) {
                    continue; // If no exist, no handle                
					}
                if (!checker) { // If validate object no exsit throw error                   
					throw {
                        name: "ValidationError",
                        message: "No handler to validate type " + type
                    };
                }

                result_ok = checker.validate(data[i]); // validating              
				if (!result_ok) {
                    msg = "Invalid value for *" + i + "*, " + checker.instructions;
                    this.messages.push(msg);
                }
            }
        }
        return this.hasErrors();
    },

    // helper    
	hasErrors: function () {
        return this.messages.length !== 0;
    }
};

validator.types.isStringOrNumber = {
    validate: function (value) {
		if (typeof value == "number" || typeof value == "string"))
		{
				if(typeof value == "string"){
					return = parseInt(objParameter.style);
				}else{
					return style;	
				}
		}
		return -1;
    },
    instructions: "not stirng or number"
};


validator.types.isString = {
    validate: function (value) {
        if(typeof value == "string"){
				return vale;	
		}
		return -1;
    },
    instructions: "not String"
};


validator.types.isObject = {
    validate: function (value) {
        if(typeof value == "object"){
				return value;	
		}
		return -1;
    },
    instructions: "not Object"
};

validator.types.isBooleanOrString = {
    validate: function (value) {
		if (typeof value == "boolean" || typeof value == "string"))
		{
				if(typeof value == "boolean"){
					if("true" == objParameter.bHasBorder){
						reture true;
					}else if("false" == objParameter.bHasBorder){
						return false;
					}
				}else{
					return value;	
				}
		}
		return -1;
    },
    instructions: "not Boolean or String "
};

winsetBase.getResolution = function(){
	var res = HALOUtil.getCurrentResolution();
	screenWidth = 1920;
	if(true == res.success){
		if(1920 == res.hRes && 1080 == res.vRes){
			return winsetBase.ResolutionStyle.Resolution_1080;
			//screenWidth = 1920;
		}else if(2520 == res.hRes && 1080 == res.vRes){
			return winsetBase.ResolutionStyle.Resolution_1080_21_9;
			//screenWidth = 2520;
		}else if(1280 == res.hRes && 720 == res.vRes){
			return winsetBase.ResolutionStyle.Resolution_720;
			//screenWidth = 1280;
		}else if(1680 == res.hRes && 720 == res.vRes){
			return winsetBase.ResolutionStyle.Resolution_720_21_9;
			//screenWidth = 1680;
		}else{
			return winsetBase.ResolutionStyle.Resolution_1080;
		}
		
	}else{
		return winsetBase.ResolutionStyle.Resolution_1080;
	}
}


exports = winsetBase;