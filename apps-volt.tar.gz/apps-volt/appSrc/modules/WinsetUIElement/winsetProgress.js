var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetProgress = function (objParameter){	
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	var m_pInstance = null;
	
	//default value
	var m_defaultParent = scene;
	var m_defaultId = null;
	var m_imagePath	= "modules/WinsetUIElement/winsetImg/";
	var m_progressStyle = 0;
	var m_resolutionStyle = 0;	
	var m_defaultX = 0;
	var m_defaultY = 0;	
	var m_defaultWidth = 300;
	var m_defaultHeight = 50;	
	var m_defaultDirection = "horizontal";	
	var m_defaultMinValue = 0;
	var m_defaultMaxValue = 100;
	var m_defaultValue = 0;
	var m_defaultReverse = false;	
	var m_defaultAtive = false;
	var m_defaultThumbSizeWidth = -1;
	var m_defaultThumbSizeHeight = -1;	
		
	var m_defaultProgressImage = null;
	var m_defaultBackgroundImage = null;
	var m_defaultProgressColor = {r:255,g:255,b:255,a:255};
	var m_defaultProgressColorOpacity = 1;
	var m_defaultBackgroundColor = {r:255,g:255,b:255,a:255};
	var m_defaultBackgroundColorOpacity = 0.1;
	
	var m_defaultSliderNormalImage = null;
	var m_defaultSliderFocusImage = null;

	
var m_create = function(objParameter){
	m_resolutionStyle = getResolution();
	//analysis parameter
	m_analysisParameter(objParameter);
	
	//set default value
	m_setDefaultValueByProgressStyle();
	
	print("000" + m_defaultSliderNormalImage);	
	//create progress instance 
	m_pInstance = new Progress({
		parent: m_defaultParent,
		x:m_defaultX,
		y:m_defaultY,
		width: m_defaultWidth,
		height: m_defaultHeight,
		direction: m_defaultDirection
	});

	//set default attribute
	m_pInstance.minValue = m_defaultMinValue;
	m_pInstance.maxValue = m_defaultMaxValue;
	m_pInstance.value = m_defaultValue;	
	m_pInstance.reverse = m_defaultReverse;
	m_pInstance.active = m_defaultAtive;
	
	if(m_defaultId != null){
		m_pInstance.id = m_defaultId;
	}
	
	if(m_defaultSliderNormalImage != null)	{
		m_pInstance.normalThumbImage = m_defaultSliderNormalImage;
	}

	if(m_defaultSliderFocusImage != null){
		m_pInstance.focusThumbImage = m_defaultSliderFocusImage;
	}		
	
	if((m_defaultThumbSizeWidth != -1) 
		&&(m_defaultThumbSizeHeight != -1)){
		m_pInstance.setThumbSize(m_defaultThumbSizeWidth, m_defaultThumbSizeHeight);	
	}	
	
	m_pInstance.setProgressColor(m_defaultProgressColor.r, m_defaultProgressColor.g, m_defaultProgressColor.b, m_defaultProgressColorOpacity*255);
	m_pInstance.setBackgroundColor(m_defaultBackgroundColor.r, m_defaultBackgroundColor.g, m_defaultBackgroundColor.b, m_defaultBackgroundColorOpacity*255);
	m_pInstance.setThumbAlign("center");
	m_pInstance.active = true;
		
	return 	m_pInstance;
}		
	
var m_analysisParameter = function(objParameter){
	if("undefined" == objParameter){
		return;
	}
	
	if(objParameter.hasOwnProperty("nProgressStyle") 
		&& (typeof objParameter.nProgressStyle == "number" || typeof objParameter.nProgressStyle == "string")){
		
		if(typeof objParameter.nProgressStyle == "string"){
			m_progressStyle = parseInt(objParameter.nProgressStyle);
		}else{
			m_progressStyle = objParameter.nProgressStyle;	
		}
		
		if((0 > m_progressStyle) || (ProgressStyle.Progress_Style_MAX <= m_progressStyle)){
			m_progressStyle = 0;
		}
	}
			
	// if(objParameter.hasOwnProperty("nResolutionStyle") 
		// && (typeof objParameter.nResolutionStyle == "number" || typeof objParameter.nResolutionStyle == "string")){
			// if(typeof objParameter.nResolutionStyle == "string"){
				// m_resolutionStyle = parseInt(objParameter.nResolutionStyle);
			// }else{
				// m_resolutionStyle = objParameter.nResolutionStyle;
			// }
// 			
		// if((ResolutionStyle.Resolution_720 > m_resolutionStyle) || (ResolutionStyle.Resolution_Style_MAX <= m_resolutionStyle)){
			// m_resolutionStyle = ResolutionStyle.m_resolutionStyle;
		// }	
	// }
	// set resource path
	if(m_resolutionStyle == ResolutionStyle.Resolution_1080 || m_resolutionStyle == ResolutionStyle.Resolution_1080_21_9){
		m_imagePath = m_imagePath + "1080p/progress/";
	} else if (m_resolutionStyle == ResolutionStyle.Resolution_720 || m_resolutionStyle == ResolutionStyle.Resolution_720_21_9){
		m_imagePath = m_imagePath + "720p/progress/";
	}
	
	if(objParameter.hasOwnProperty("x")
		&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
		if(typeof objParameter.x == "string"){
			m_defaultX = parseInt(objParameter.x);	
		}else{
			m_defaultX = objParameter.x;	
		} 
		
	}
	
	if(objParameter.hasOwnProperty("y")
		&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
		if(typeof objParameter.y == "string"){
			m_defaultY = parseInt(objParameter.y);	
		}else{
			m_defaultY = objParameter.y;	
		}
	}	
	
	if(objParameter.hasOwnProperty("width")
		&& (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
		if(typeof objParameter.width == "string"){
			m_defaultWidth = parseInt(objParameter.width);
		}else{
			m_defaultWidth = objParameter.width;
		}	
	}	
	
	if(objParameter.hasOwnProperty("height")
		&& (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
		if(typeof objParameter.height == "string"){
			m_defaultHeight = parseInt(objParameter.height);
		}else{
			m_defaultHeight = objParameter.height;
		}			
	}
	
	if(objParameter.hasOwnProperty("minValue")
		&& (typeof objParameter.minValue == "number" || typeof objParameter.minValue == "string")){
		if(typeof objParameter.minValue == "string"){
			m_defaultMinValue = parseInt(objParameter.minValue);
		}else{
			m_defaultMinValue = objParameter.minValue;
		}
		
	}
	
	if(objParameter.hasOwnProperty("maxValue")
		&& (typeof objParameter.maxValue == "number" || typeof objParameter.maxValue == "string")){
		if(typeof objParameter.maxValue == "string"){
			m_defaultMaxValue = parseInt(objParameter.maxValue);
		}else{
			m_defaultMaxValue = objParameter.maxValue;
		}
	}
	
	if(objParameter.hasOwnProperty("value")
		&& (typeof objParameter.value == "number" || typeof objParameter.value == "string")){
		if(typeof objParameter.value == "string"){
			m_defaultValue = parseInt(objParameter.value);
		}else{
			m_defaultValue = objParameter.value;
		}	
	}	
	
	if(objParameter.hasOwnProperty("reverse")
		&& (typeof objParameter.reverse == "boolean")){
		m_defaultReverse= objParameter.reverse;
	}
	
	if(objParameter.hasOwnProperty("direction")
		&& (typeof objParameter.direction == "string")){
		m_defaultDirection= objParameter.direction;
	}
	
	if(objParameter.hasOwnProperty("id")
		&& (typeof objParameter.id == "string")){
		m_defaultId = objParameter.id;
	}
	
	if(objParameter.hasOwnProperty("parent")
		&& (typeof objParameter.parent == "object")){
		m_defaultParent = objParameter.parent;
	}	
}
		
var m_setDefaultValueByProgressStyle = function(){
	//set default value
		switch(m_progressStyle)
		{
			case ProgressStyle.Progress_Style_A:
				{
					m_defaultProgressColor = {r:255,g:255,b:255,a:255};
					m_defaultProgressColorOpacity = 1;
					m_defaultBackgroundColor = {r:255,g:255,b:255,a:255};
					m_defaultBackgroundColorOpacity = 0.4;	

					m_defaultDirection = "horizontal";		
				}
			break;
			
			case ProgressStyle.Progress_Style_B:
				{
					m_defaultProgressColor = {r:1,g:138,b:218,a:255};
					m_defaultProgressColorOpacity = 1;
					m_defaultBackgroundColor = {r:0,g:0,b:0,a:255};
					m_defaultBackgroundColorOpacity = 0.4;
					
					m_defaultDirection = "horizontal";						
				}		
			break;
			
			case ProgressStyle.Progress_Style_Timeshift:
				{
					m_defaultProgressColor = {r:120,g:229,b:109,a:255};
					m_defaultProgressColorOpacity = 1;
					m_defaultBackgroundColor = {r:255,g:255,b:255,a:255};
					m_defaultBackgroundColorOpacity = 0.2;	

					m_defaultDirection = "horizontal";		
				}			
			break;
			
			case ProgressStyle.Progress_Style_Recoding:
				{
					m_defaultProgressColor = {r:223,g:113,b:117,a:255};
					m_defaultProgressColorOpacity = 1;
					m_defaultBackgroundColor = {r:255,g:255,b:255,a:255};
					m_defaultBackgroundColorOpacity = 0.2;	

					m_defaultDirection = "horizontal";		
				}			
			break;
			
			case ProgressStyle.Progress_Text_Style_A:
			{
				m_defaultProgressColor = {r:61,g:127,b:201,a:255};
				m_defaultProgressColorOpacity = 1;
				m_defaultBackgroundColor = {r:0,g:0,b:0,a:255};
				m_defaultBackgroundColorOpacity = 0.1;
				
				m_defaultDirection = "horizontal";
			}
			break;

			case ProgressStyle.Progress_Text_Style_B:
			{
				m_defaultProgressColor = {r:255,g:255,b:255,a:255};
				m_defaultProgressColorOpacity = 1;
				m_defaultBackgroundColor = {r:255,g:255,b:255,a:255};
				m_defaultBackgroundColorOpacity = 0.1;

				m_defaultDirection = "horizontal";
			}
			break;

			case ProgressStyle.Progress_Slider_Dial:
				{
					m_defaultProgressColor = {r:255,g:255,b:255,a:255};
					m_defaultProgressColorOpacity = 1;
					m_defaultBackgroundColor = {r:255,g:255,b:255,a:255};
					m_defaultBackgroundColorOpacity = 0.1;	

					m_defaultDirection = "horizontal";		
					
					m_defaultSliderNormalImage = m_imagePath + "progress_setting_slider_dial.png";					
					//default image
					m_defaultThumbSizeWidth = 12;
					m_defaultThumbSizeHeight = 12;	
					// if(m_resolutionStyle == ResolutionStyle.Resolution_1080 || m_resolutionStyle == ResolutionStyle.Resolution_1080_21_9){
// 
						// m_defaultThumbSizeWidth = 12;
						// m_defaultThumbSizeHeight = 12;					
					// }	
					// else if(m_resolutionStyle == ResolutionStyle.Resolution_720 || m_resolutionStyle == ResolutionStyle.Resolution_720_21_9){
						// m_defaultThumbSizeWidth = 8;
						// m_defaultThumbSizeHeight = 8;										
					// }					
				}			
			break;
			
			case ProgressStyle.Active_Progress_Style_A:
				{
					m_defaultProgressColor = {r:255,g:255,b:255,a:255};
					m_defaultProgressColorOpacity = 1;
					m_defaultBackgroundColor = {r:255,g:255,b:255,a:255};
					m_defaultBackgroundColorOpacity = 0.1;	
					
					m_defaultDirection = "horizontal";		
					m_defaultAtive = true;

					m_defaultSliderNormalImage =  m_imagePath + "progress_active_a_n.png";
					m_defaultSliderFocusImage =  m_imagePath + "progress_active_a_f.png";			
					//default image
					m_defaultThumbSizeWidth = 34;
					m_defaultThumbSizeHeight = 34;				
					// if(m_resolutionStyle == ResolutionStyle.Resolution_1080 || m_resolutionStyle == ResolutionStyle.Resolution_1080_21_9){
						// m_defaultThumbSizeWidth = 34;
						// m_defaultThumbSizeHeight = 34;	
					// }	
					// else if(m_resolutionStyle == ResolutionStyle.Resolution_720 || m_resolutionStyle == ResolutionStyle.Resolution_720_21_9){
						// m_defaultThumbSizeWidth = 22;
						// m_defaultThumbSizeHeight = 22;						
					// }					
				}				
			break;		

			case ProgressStyle.Active_Progress_Style_B:
				{
					m_defaultProgressColor = {r:61,g:127,b:201,a:255};
					m_defaultProgressColorOpacity = 1;
					m_defaultBackgroundColor = {r:0,g:0,b:0,a:255};
					m_defaultBackgroundColorOpacity = 0.1;	

					m_defaultDirection = "horizontal";		
					m_defaultAtive = true;
					
					m_defaultSliderNormalImage = m_imagePath + "progress_active_b_n.png";
					m_defaultSliderFocusImage = m_imagePath + "progress_active_b_f.png";					
					//default image
					m_defaultThumbSizeWidth = 34;
					m_defaultThumbSizeHeight = 34;
					// if(m_resolutionStyle == ResolutionStyle.Resolution_1080 || m_resolutionStyle == ResolutionStyle.Resolution_1080_21_9){
						// m_defaultThumbSizeWidth = 34;
						// m_defaultThumbSizeHeight = 34;					
					// }	
					// else if(m_resolutionStyle == ResolutionStyle.Resolution_720 || m_resolutionStyle == ResolutionStyle.Resolution_720_21_9){
						// m_defaultThumbSizeWidth = 22;
						// m_defaultThumbSizeHeight = 22;										
					// }
				}
			break;
		default:
			break;
		}
}
	

//return the instance of native progress	
return m_create(objParameter);	
}

//style type
var ProgressStyle = {
	Progress_Style_A:0,
	Progress_Style_B:1,
	Progress_Style_Timeshift:2,
	Progress_Style_Recoding:3,
	Progress_Text_Style_A:4, // to be delete
	Progress_Text_Style_B:5, // to be delete
	Progress_Slider_Dial:6,
	Active_Progress_Style_A:7, // to be delete
	Active_Progress_Style_B:8, // to be delete		
	Progress_Style_MAX:9, 
};

winsetProgress.ProgressStyle = ProgressStyle;
winsetProgress.prototype = new winsetBase();

exports = winsetProgress;
