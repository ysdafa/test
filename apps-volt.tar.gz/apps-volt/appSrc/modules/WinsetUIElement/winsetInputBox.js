var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetInputBox = function(obj) {
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	// local var
	var inputbox,
		height = 300,
		width = 300,
		x = 0,
		y = 0,
		id = null,
		parent = scene,
		// image
		bgNormal,
		bgDefault,
		bgFocus,
		bgSelected,
		bgDim,
		// color
		normalTextColor,
		defaultTextColor,
		focusTextColor,
		selectedTextColor,
		dimTextColor,
		textBgColor = { r: 255, g: 255, b: 255, a: 0 },
		cursorColor,
		selectionColor = { r: 64, g: 64, b: 64, a: 204 },
		// font
		fontName = "SamsungSmart_Light 30px",
		normalTextFont,
		focusTextFont,
		margin_h = 0,
        margin_v = 0,
		text = "Default",
		textHAlignment,
		style = InputBoxStyle.InputBox_Style_E_Left,
		resolution = ResolutionStyle.Resolution_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/";
		
	   	
	var m_analysisParameter = function(objParameter){
		Volt.log('[winsetInputBox.js @m_analysisParameter]');

		if (objParameter != "undefined") {
			if (objParameter.hasOwnProperty("style") && (typeof objParameter.style == "number" || typeof objParameter.style == "string")) {
				if (typeof objParameter.style == "string") {
					style = parseInt(objParameter.style);
				} else {
					style = objParameter.style;	
				}
					
				if ((style < 1) || (InputBoxStyle.InputBox_Style_Max <= style)) {
					style = 1;
				}
			}
			
			if (objParameter.hasOwnProperty("x") && (typeof objParameter.x == "number" || typeof objParameter.x == "string")) {
				if (typeof objParameter.x == "string") {
					x = parseInt(objParameter.x);	
				} else {
					x = objParameter.x;	
				} 
				
			}
			
			if (objParameter.hasOwnProperty("y") && (typeof objParameter.y == "number" || typeof objParameter.y == "string")) {
				if (typeof objParameter.y == "string") {
					y = parseInt(objParameter.y);	
				} else {
					y = objParameter.y;	
				}
			}	
			
			if (objParameter.hasOwnProperty("width") && (typeof objParameter.width == "number" || typeof objParameter.width == "string")) {
				if (typeof objParameter.width == "string") {
					width = parseInt(objParameter.width);
				} else {
					width = objParameter.width;
				}	
			}	
			
			if (objParameter.hasOwnProperty("height") && (typeof objParameter.height == "number" || typeof objParameter.height == "string")) {
				if (typeof objParameter.height == "string") {
					height = parseInt(objParameter.height);
				} else {
					height = objParameter.height;
				}			
			}
			
			if (objParameter.hasOwnProperty("id") && (typeof objParameter.id == "string")) {
				id = objParameter.id;	
			}
			
			if (objParameter.hasOwnProperty("text") && (typeof objParameter.text == "string")) {
				text = objParameter.text;	
			}
			
			if (objParameter.hasOwnProperty("parent") && (typeof objParameter.parent == "object")) {
				parent = objParameter.parent;	
			}	
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		Volt.log('[winsetInputBox.js @m_setDefaultValueByProgressStyle]');
		// set resource path
		margin_h = 24;
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			path = path + "1080p/input/";
			// margin_h = 24; // 1920 * 0.0125
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			path = path + "720p/input/";
			// margin_h = 16; //1280 * 0.0125;
		}
		
		//set default value
		switch(style)
		{
			case InputBoxStyle.InputBox_Style_E_Left:
				{
					// image path
					bgNormal = path + "input_box_n.png";
					bgDefault = path + "input_box_n.png";
					bgFocus = path + "input_box_f.png";
					bgSelected = path + "input_box_f.png";
					bgDim = path + "input_box_d.png";
						
					textHAlignment = "left";
					
					normalTextColor = { r: 255, g: 255, b: 255, a: 229.5 };
					defaultTextColor = { r: 255, g: 255, b: 255, a: 127.5 };
					focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
					selectedTextColor = { r: 70, g: 70, b: 70, a: 255 };
					dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					cursorColor = { r: 96, g: 96, b: 96, a: 255 };
					// font
					normalTextFont = 30;
					focusTextFont = 30;
				}
				break;
			
			case InputBoxStyle.InputBox_Style_E_Center:
				{
					// image path
					bgNormal = path + "input_box_n.png";
					bgDefault = path + "input_box_n.png";
					bgFocus = path + "input_box_f.png";
					bgSelected = path + "input_box_f.png";
					bgDim = path + "input_box_d.png";
						
					textHAlignment = "center";
					
					normalTextColor = { r: 255, g: 255, b: 255, a: 229.5 };
					defaultTextColor = { r: 255, g: 255, b: 255, a: 127.5 };
					focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
					selectedTextColor = { r: 70, g: 70, b: 70, a: 255 };
					dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					cursorColor = { r: 96, g: 96, b: 96, a: 255 };
					// font
					normalTextFont = 30;
					focusTextFont = 30;
				}
				break;
			
			case InputBoxStyle.InputBox_Style_F_Left:
				{
					// image path
					bgNormal = path + "obe_input_n.png";
					bgDefault = path + "obe_input_n.png";
					bgFocus = path + "obe_input_f.png";
					bgSelected = path + "obe_input_s.png";
					bgDim = path + "obe_input_n.png";
						
					textHAlignment = "left";
					
					normalTextColor = { r: 64, g: 64, b: 64, a: 204 };
					defaultTextColor = { r: 64, g: 64, b: 64, a: 102 };
					focusTextColor = { r: 33, g: 158, b: 230, a: 255 };
					selectedTextColor = { r: 64, g: 64, b: 64, a: 204 };
					dimTextColor = { r: 96, g: 96, b: 96, a: 76.5 };
						
					cursorColor = { r: 64, g: 64, b: 64, a: 204 };
					// font
					normalTextFont = 34;
					focusTextFont = 34;
				}
				break;
			
			case InputBoxStyle.InputBox_Style_F_Center:
				{
					// image path
					bgNormal = path + "obe_input_n.png";
					bgDefault = path + "obe_input_n.png";
					bgFocus = path + "obe_input_f.png";
					bgSelected = path + "obe_input_s.png";
					bgDim = path + "obe_input_n.png";
						
					normalTextColor = { r: 64, g: 64, b: 64, a: 204 };
					defaultTextColor = { r: 64, g: 64, b: 64, a: 102 };
					focusTextColor = { r: 33, g: 158, b: 230, a: 255 };
					selectedTextColor = { r: 64, g: 64, b: 64, a: 204 };
					dimTextColor = { r: 96, g: 96, b: 96, a: 76.5 };
					
					textHAlignment = "center";
					
					cursorColor = { r: 64, g: 64, b: 64, a: 204 };
					// font
					normalTextFont = 34;
					focusTextFont = 34;
				}
				break;
				
			default:
				break;
		}
	}

	
	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	inputBox = new InputBox({
				//x: x,
				//y: y,
                parent: parent,
                width: width,
                height: height,
                margin_h: margin_h,
                margin_v: margin_v
                });
	
	if (id != null) {
		inputBox.id = id;
	}
	
	inputBox.setText(text);
	inputBox.setPosition(x, y, 0);
	inputBox.setImage("normal", bgNormal);
	inputBox.setImage("focus", bgFocus);
	
	inputBox.setTextBGColor(textBgColor.r, textBgColor.g, textBgColor.b, textBgColor.a);
	
	inputBox.setTextColor("normal", normalTextColor.r, normalTextColor.g, normalTextColor.b, normalTextColor.a);
	inputBox.setTextColor("focus", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
	
	inputBox.setTextHAlignment(textHAlignment);
	
	inputBox.setSelectionColor(selectionColor.r, selectionColor.g, selectionColor.b, selectionColor.a);
	inputBox.setCursorColor(cursorColor.r, cursorColor.g, cursorColor.b, cursorColor.a);
	
	inputBox.setFont(fontName);
	inputBox.setFontSize(normalTextFont);
	
	return inputBox;
};

var InputBoxStyle = {
	InputBox_Style_E_Left:1,
	InputBox_Style_E_Center:2,
	InputBox_Style_F_Left:3,
	InputBox_Style_F_Center:4,
	InputBox_Style_Max:5
};

winsetInputBox.InputBoxStyle = InputBoxStyle;
winsetInputBox.prototype = new winsetBase();

exports = winsetInputBox;

