var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetMessageBox = function(obj){		
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	// local var
	var style = MessageBoxStyle.MessageBox_Title_Button_1Line,
		resolution = ResolutionStyle.Resolution_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		messagebox = null,
		x = 0,
		y = 0,
		id = null,
		parent = scene,
		screenWidth = 1920,
		screenHeight = 1080,
		width = 1920,
		height = 1080,
		bTitle,
		bButton,
		// background
		bgcolor,
		firstLayerBGColor,
		secondLayerBGColor,
		thirdLayerBGColor,
		secondLayerBGHeight,
		thirdLayerBGHeight,
		bgPickColor = { r: 0, g: 0, b: 0, a: 0 },
		shadowPath = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		bgStyle = BackgroundStyle.Background_Style_E_2,
		// title
		titleText = "title",
        titleTextFont,
        titleTextColor,
        titleLineColor,
        titleRect = {},
        // title line 
        titleLineRect = {},
        // content text
        contentNumber,
        contentLine,
        contextLineNumber = 1,
        contentText = "Message Popup",
        contentTextFont,
        contentTextColor,
        contentRect = {},
        contentText2 = "Message Popup",
        contentText2Font,
        contentText2Color,
        contentRect2 = {},
        // button attr
        buttonStyle = ButtonStyle.Button_image_O_Style_F,
        buttonType,
        button1Rect = {},
        button2Rect = {},
        button3Rect = {},
        button1Text = "OK",
        button2Text = "Cancel",
        button3Text = "No",
        buttonBgNormal,
		buttonBgFoucs,
		buttonBgSelect,
		buttonBgDim,
		buttonBgNormalColor,
		buttonBgFoucsColor,
		buttonBgSelectColor,
		buttonBgDimColor,
		buttonBgRolloverColor,
		normalFont,
		focusFont,
		selectFont,
		dimFont,
		rolloverFont,
		normalTextColor,
		focusTextColor,
		selectTextColor,
		dimTextColor,
		rolloverTextColor,
		normalBorderColor,
		dimBorderColor,
		// loading
		bLoading = false,
		loadingWidth,
		loadingHeight,
		loadingImageName = [],
		loadingImageNumber = 63,
		loadingImagePath,
		loadingX = 0,
		loadingY = 0,
		bAutoFlag = false,
		bHighContrast = false,
		popupStyle = PopupStyle.TV_and_Smart_Hub_Popup;	
        
				
	var m_analysisParameter = function(objParameter){
		Volt.log('[winsetMessageBox.js @m_analysisParameter]');

		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") && (typeof objParameter.style == "number" || typeof objParameter.style == "string")){
				if(typeof objParameter.style == "string"){
					style = parseInt(objParameter.style);
				}else{
					style = objParameter.style;	
				}
				if((1 > style) || (MessageBoxStyle.MessageBox_Style_Max <= style)){
					style = 1;
				}
			}
			
			if(objParameter.hasOwnProperty("x") && (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
				if(typeof objParameter.x == "string"){
					x = parseInt(objParameter.x);	
				}else{
					x = objParameter.x;	
				} 
			}
			
			if(objParameter.hasOwnProperty("y") && (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					y = parseInt(objParameter.y);	
				}else{
					y = objParameter.y;	
				}
			}	
			
			if(objParameter.hasOwnProperty("width") && (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
				if(typeof objParameter.width == "string"){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}	
			
			if(objParameter.hasOwnProperty("height") && (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
				if(typeof objParameter.height == "string"){
					height = parseInt(objParameter.height);
				}else{
					height = objParameter.height;
				}			
			}
			
			if(objParameter.hasOwnProperty("bgStyle") && (typeof objParameter.bgStyle == "number" || typeof objParameter.bgStyle == "string")){	
				if(typeof objParameter.bgStyle == "string"){
					bgStyle = parseInt(objParameter.bgStyle);	
				}else{
					bgStyle = objParameter.bgStyle;
				}
				if(BackgroundStyle.Background_Style_B_1 > bgStyle || BackgroundStyle.Background_Style_Max <= bgStyle){
					bgStyle = BackgroundStyle.Background_Style_B_1;
				}
			}
			
			if(objParameter.hasOwnProperty("bgPickColor") && (typeof objParameter.bgPickColor == "object")){
				bgPickColor = objParameter.bgPickColor;	
			}
	
			if(objParameter.hasOwnProperty("buttonStyle") && (typeof objParameter.buttonStyle == "number" || typeof objParameter.buttonStyle == "string")){
				if(typeof objParameter.buttonStyle == "string"){
					buttonStyle = parseInt(objParameter.buttonStyle);
				}else{
					buttonStyle = objParameter.buttonStyle;
				}
				if(1 > buttonStyle || ButtonStyle.Button_Style_Max <= buttonStyle){
					buttonStyle = 1;
				}
			}
			
			if(objParameter.hasOwnProperty("contextLineNumber") && (typeof objParameter.contextLineNumber == "number")){
				contextLineNumber = objParameter.contextLineNumber;
				Volt.log("contextLineNumber is    --------- " + contextLineNumber);
			}
			
			if(objParameter.hasOwnProperty("id") && (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
			
			if(objParameter.hasOwnProperty("parent") && (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
			
			if(objParameter.hasOwnProperty("titleText") && (typeof objParameter.titleText == "string")){
				titleText = objParameter.titleText;	
			}
			
			if(objParameter.hasOwnProperty("contentText") && (typeof objParameter.contentText == "string")){
				contentText = objParameter.contentText;	
			}
			
			if(objParameter.hasOwnProperty("contentText2") && (typeof objParameter.contentText2 == "string")){
				contentText2 = objParameter.contentText2;	
			}
			
			if(objParameter.hasOwnProperty("button1Text") && (typeof objParameter.button1Text == "string")){
				button1Text = objParameter.button1Text;	
			}
			
			if(objParameter.hasOwnProperty("button2Text") && (typeof objParameter.button2Text == "string")){
				button2Text = objParameter.button2Text;	
			}
			
			if(objParameter.hasOwnProperty("button3Text") && (typeof objParameter.button3Text == "string")){
				button3Text = objParameter.button3Text;	
			}
			
			if(objParameter.hasOwnProperty("popupStyle") && (typeof objParameter.popupStyle == "number" || typeof objParameter.popupStyle == "string")){
				if(typeof objParameter.popupStyle == "string"){
					popupStyle = parseInt(objParameter.popupStyle);	
				}else{
					popupStyle = objParameter.popupStyle;	
				}
			}	
		}
	}
			
	var m_setCreateValue = function(){
		Volt.log('[winsetMessageBox.js @m_setCreateValue]');

		contentTextFont = "SamsungSmart_Light 34px";	

		//set default value
		switch(style)
		{
			case MessageBoxStyle.MessageBox_Title_Button_1Line:
				{
					bTitle = true;
			        contentLine = "single_line_content_type";
					buttonType = "button_2";
					contentNumber = 1;
				}
				break;
			
			case MessageBoxStyle.MessageBox_Title_Button_2_8Line:
				{
					bTitle = true;
			        contentLine = "multi_line_content_type";
					buttonType = "button_2";
					contentNumber = 1;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_1Line:
				{
					bTitle = false;
			        contentLine = "single_line_content_type";
					buttonType = "button_2";
					contentNumber = 1;
				}
				break;	
			
			case MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line:
				{
					bTitle = false;
			        contentLine = "multi_line_content_type";
					buttonType = "button_2";
					contentNumber = 1;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_Message_Text_Align:
				{
					bTitle = false;
			        contentLine = "multi_line_with_single_line_content_type";
					buttonType = "button_2";
					contentNumber = 2;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_NoButton:
				{
					bTitle = false;
			        contentLine = "multi_line_content_type";
					buttonType = "no_button";
					contentNumber = 1;
				}
				break;
			
			case MessageBoxStyle.MessageBox_1Line:
				{
					bTitle = false;
			        contentLine = "single_line_content_type";
					buttonType = "no_button";
					contentNumber = 1;
				}
				break;
				
			case MessageBoxStyle.MessageBox_1Line_Loading:
				{
					bTitle = false;
			        contentLine = "single_line_content_with_loading_type";
					buttonType = "no_button";
					contentNumber = 1;
				}
				break;
				
			case MessageBoxStyle.MessageBox_2Line_Loading:
				{
					bTitle = false;
			        contentLine = "multi_line_content_with_loading_type";
					buttonType = "no_button";
					contentNumber = 1;
				}
				break;	
				
			case MessageBoxStyle.MessageBox_3Line_Loading:
				{
					bTitle = false;
			        contentLine = "multi_line_content_with_loading_type";
					buttonType = "no_button";
					contentNumber = 1;
				}
				break;	
				
			case MessageBoxStyle.MessageBox_Extension_One_Button:
				{
					bTitle = false;
			        contentLine = "multi_line_content_type";
					buttonType = "button_1";
					contentNumber = 1;
				}
				break;
				
			case MessageBoxStyle.MessageBox_Extension_Three_Button:
				{
					bTitle = false;
			        contentLine = "multi_line_content_type";
					buttonType = "button_3";
					contentNumber = 1;
				}
				break;
				
			case MessageBoxStyle.High_Contrast_MessageBox_Title_Button_2_8Line:
				{
					bTitle = true;
			        contentLine = "multi_line_content_type";
					buttonType = "button_2";
					contentNumber = 1;
				}
				break;
			
			case MessageBoxStyle.High_Contrast_MessageBox_NoTitle_Button_2_8Line:
				{
					bTitle = false;
			        contentLine = "multi_line_content_type";
					buttonType = "button_2";
					contentNumber = 1;
				}
				break;
			
			case MessageBoxStyle.High_Contrast_MessageBox_NoTitle_NoButton:
				{
					bTitle = false;
			        contentLine = "multi_line_content_type";
					buttonType = "no_button";
					contentNumber = 1;
				}
				break;
			
			case MessageBoxStyle.High_Contrast_MessageBox_1Line:
				{
					bTitle = false;				
			        contentLine = "single_line_content_type";
					buttonType = "no_button";
					contentNumber = 1;
				}
				break;
			
			default:
				break;
		}
	}
	
	var m_setDefaultValueByProgressStyle = function(){
		Volt.log('[winsetMessageBox.js @m_setDefaultValueByProgressStyle]');

		// set resource path
		loadingWidth = 301;
		loadingHeight = 58;
		screenWidth = 1920;
		screenHeight = 1080;
		secondLayerBGHeight = screenHeight * 0.000926;
		thirdLayerBGHeight = screenHeight * 0.001852;
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			loadingImagePath = path + "1080p/Loading/";
			path = path + "1080p/btn/";
			shadowPath = shadowPath + "1080p/";
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			loadingImagePath = path + "720p/Loading/";
			path = path + "720p/btn/";
			shadowPath = shadowPath + "720p/";
		}
		
		//set default value
		switch(style)
		{
			case MessageBoxStyle.MessageBox_Title_Button_1Line:
				{
					y = (1 - 0.351852) * screenHeight/2;
					
					titleTextFont = "SamsungSmart_Light 44px";
					contentTextFont = "SamsungSmart_Light 34px";
					width = 1920;
					height = 1080 * 0.351852;

					// title
			       	titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
			       	titleRect.x = (1 - 0.584375)/2 * screenWidth;
			       	titleRect.y = 0;
			       	titleRect.width = 0.584375 * screenWidth;
			       	titleRect.height = 0.089815 * screenHeight;
			        
			        // title line
			        titleLineRect.x = (1 - 0.584375)/2 * screenWidth;
			        titleLineRect.y = 0.089815 * screenHeight + 0;
			        titleLineRect.width = 0.584375 * screenWidth;
			        titleLineRect.height = 1;
			        // content text
			        contentNumber = 1;
			        
			        // contextLineNumber = 1;
			        contentLine = "single_line_content_type";
			    	
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.063889) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					// buttonType = "button_2";
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.089815 + 0.063889 + 0.044444 + 0.064815) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.089815 + 0.063889 + 0.044444 + 0.064815) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
			
			case MessageBoxStyle.MessageBox_Title_Button_2_8Line:
				{
					if(contextLineNumber > 8){
						contextLineNumber = 8;
					}
					
					y = (1 - 0.089815 - 0.025926 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					 // title line
			        titleLineRect.x = (1 - 0.584375)/2 * screenWidth;
			        titleLineRect.y = 0.089815 * screenHeight + 0;
			        titleLineRect.width = 0.584375 * screenWidth;
			        titleLineRect.height = 1;
			        
			        titleTextFont = "SamsungSmart_Light 44px";
					contentTextFont = "SamsungSmart_Light 34px";
					width = 1920;
					height = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					
			       	titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
			       	titleRect.x = (1 - 0.584375)/2 * screenWidth;
			       	titleRect.y = 0;
			       	titleRect.width = 0.584375 * screenWidth;
			       	titleRect.height = 0.089815 * screenHeight;
			       
			        // content text
			        contentNumber = 1;
			   
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.025926) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * contextLineNumber * screenHeight;
			    
			        // button
			        bButton = true;
					buttonType = "button_2";
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_1Line:
				{
					y = (1 - 0.287037) * screenHeight/2;
					
					titleTextFont = "SamsungSmart_Light 44px";
					contentTextFont = "SamsungSmart_Light 34px";
					width = 1920;
					height = 0.287037 * screenHeight;
					
			        // content text
			        contentNumber = 1;
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.088889 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.088889 +  0.044444  + 0.064815) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.088889 +  0.044444  + 0.064815) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;	
			
			case MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line:
				{
					if(contextLineNumber > 8){
						contextLineNumber = 8;
					}
					y = (1 - 0.044444 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					width = 1920;
					height = (0.044444 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					
			        // content text
			        contentNumber = 1;
	
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.044444 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = true;
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_Button_Message_Text_Align:
				{
					if(contextLineNumber > 8){
						contextLineNumber = 8;
					}

					y = (1 - 0.044444 - 0.044444 * contextLineNumber - 0.029630 - 0.044444 - 0.042593 - 0.061111 - 0.027778) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					contentText2Font = "SamsungSmart_Light 34px";
					width = 1920;
					height = (0.044444 + 0.044444 * contextLineNumber + 0.029630 + 0.044444 + 0.042593 + 0.061111 + 0.027778) * screenHeight;
					
			        // content text
			        contentNumber = 2;
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			        contentText2Color ={ r: 69, g: 187, b: 163, a: 230 };
			        
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.044444 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			      	
			      	contentRect2.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect2.y = (0.044444 + 0.044444 * contextLineNumber + 0.029630) * screenHeight;
			      	contentRect2.width = 0.584375 * screenWidth;
			      	contentRect2.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = true;
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.029630 + 0.044444 + 0.042593) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.029630 + 0.044444 + 0.042593) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_NoTitle_NoButton:
				{
					if(contextLineNumber > 8){
						contextLineNumber = 8;
					}
					y = (1 - 0.046296 - 0.044444 * contextLineNumber - 0.042593) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					contentText2Font = "SamsungSmart_Light 34px"
					width = 1920;
					height = (0.046296 + 0.044444 * contextLineNumber + 0.042593) * screenHeight;
					
			        // content text
			        contentNumber = 1;
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.046296 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = false;
				}
				break;
			
			case MessageBoxStyle.MessageBox_1Line:
				{
					y = (1 - 0.131481) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					contentText2Font = "SamsungSmart_Light 34px";
					width = 1920;
					height = 0.131481 * screenHeight;
					
			        // content text
			        contentNumber = 1;
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.043519 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = false;
				}
				break;
				
			case MessageBoxStyle.MessageBox_1Line_Loading:
				{
					y = (1 - 0.220370) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					contentText2Font = "SamsungSmart_Light 34px";
					width = 1920;
					height = 0.220370 * screenHeight;
					
			        // content text
			        contentNumber = 1;
			        contentLine = "single_line_content_with_loading_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.046296 + 0.033333) * screenHeight + loadingHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = false;
					
					// loading
					bLoading = true;
					loadingX =  (screenWidth - loadingWidth)/2;
					loadingY = 0.046296 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_2Line_Loading:
				{
					if(contextLineNumber > 2){
						contextLineNumber = 2;
					}
					y = (1 - 0.266667) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					contentText2Font = "SamsungSmart_Light 34px";
					width = 1920;
					height = 0.266667 * screenHeight;
					
			        // content text
			        contentNumber = 1;
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.048148 + 0.031481) * screenHeight + loadingHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * 2;
			    
			        // button
			        bButton = false;
					
					// loading
					bLoading = true;
					loadingX =  (screenWidth - loadingWidth)/2;
					loadingY = 0.048148 * screenHeight;
				}
				break;	
				
			case MessageBoxStyle.MessageBox_3Line_Loading:
				{
					if(contextLineNumber > 3){
						contextLineNumber = 3;
					}
					y = (1 - 0.309259) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					contentText2Font = "SamsungSmart_Light 34px";
					width = 1920;
					height = 0.309259 * screenHeight;
					
			        // content text
			        contentNumber = 1;
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.048148 + 0.031481) * screenHeight + loadingHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * 3;
			    
			        // button
			        bButton = false;
					
					// loading
					bLoading = true;
					loadingX =  (screenWidth - loadingWidth)/2;
					loadingY = 0.048148 * screenHeight;
				}
				break;	
				
			case MessageBoxStyle.MessageBox_Extension_One_Button:
				{
					y = (1 - 0.044444 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					width = 1920;
					height = (0.044444 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					
			        // content text
			        contentNumber = 1;
	
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.044444 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = true;
					button1Rect.x = (1 - 0.140625) * screenWidth/2;
					button1Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.MessageBox_Extension_Three_Button:
				{
					y = (1 - 0.044444 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					contentTextFont = "SamsungSmart_Light 34px";
					width = 1920;
					height = (0.044444 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					
			        // content text
			        contentNumber = 1;
	
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.044444 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = true;
					button1Rect.x = (1 - 0.140625 - 0.146875 * 2) * screenWidth/2;
					button1Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
					
					button2Rect.x = (1 - 0.140625) * screenWidth/2;
					button2Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button2Rect.width = 0.140625 * screenWidth;
					button2Rect.height = 0.061111 * screenHeight;
					
					button3Rect.x = (1 - 0.140625 + 0.146875 * 2) * screenWidth/2;
					button3Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button3Rect.width = 0.140625 * screenWidth;
					button3Rect.height = 0.061111 * screenHeight;
				}
				break;
				
			case MessageBoxStyle.High_Contrast_MessageBox_Title_Button_2_8Line:
				{
					if(contextLineNumber > 8){
						contextLineNumber = 8;
					}
					bHighContrast = true;
					y = (1 - 0.089815 - 0.025926 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					 // title line
			        titleLineRect.x = (1 - 0.584375)/2 * screenWidth;
			        titleLineRect.y = 0.089815 * screenHeight + 0;
			        titleLineRect.width = 0.584375 * screenWidth;
			        titleLineRect.height = 1;
			        
					if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						titleTextFont = "SamsungSmart_Light 44px";
						contentTextFont = "SamsungSmart_Light 34px";
						width = 1920;
						height = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						titleTextFont = "SamsungSmart_Light 30px";
						contentTextFont = "SamsungSmart_Light 22px";
						width = 1280;
						height = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					}
					
			       	titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
			       	titleRect.x = (1 - 0.584375)/2 * screenWidth;
			       	titleRect.y = 0;
			       	titleRect.width = 0.584375 * screenWidth;
			       	titleRect.height = 0.089815 * screenHeight;
			       
			        // content text
			        contentNumber = 1;
			   
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = (0.089815 + 0.025926) * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * contextLineNumber * screenHeight;
			    
			        // button
			        bButton = true;
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.089815 + 0.025926 + 0.044444 * contextLineNumber + 0.020370) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
			
			case MessageBoxStyle.High_Contrast_MessageBox_NoTitle_Button_2_8Line:
				{
					if(contextLineNumber > 8){
						contextLineNumber = 8;
					}
					bHighContrast = true;
					y = (1 - 0.044444 - 0.044444 * contextLineNumber - 0.020370 - 0.061111 - 0.027778) * screenHeight/2;
					
					if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						contentTextFont = "SamsungSmart_Light 34px";
						width = 1920;
						height = (0.044444 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						contentTextFont = "SamsungSmart_Light 22px";
						width = 1280;
						height = (0.044444 + 0.044444 * contextLineNumber + 0.020370 + 0.061111 + 0.027778) * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
	
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.044444 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = true;
					button1Rect.x = (1 - 0.00625 - 0.140625 * 2) * screenWidth/2;
					button1Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
					button1Rect.width = 0.140625 * screenWidth;
					button1Rect.height = 0.061111 * screenHeight;
        			button2Rect.x = (1 - 0.00625 - 0.140625 * 2 + 0.146875 * 2) * screenWidth/2;
        			button2Rect.y = (0.044444 +  0.044444 * contextLineNumber + 0.020370) * screenHeight;
        			button2Rect.width = 0.140625 * screenWidth;
        			button2Rect.height = 0.061111 * screenHeight;
				}
				break;
			
			case MessageBoxStyle.High_Contrast_MessageBox_NoTitle_NoButton:
				{
					// bTitle = false;
					if(contextLineNumber > 8){
						contextLineNumber = 8;
					}
					bHighContrast = true;
					y = (1 - 0.046296 - 0.044444 * contextLineNumber - 0.042593) * screenHeight/2;
					
					if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						contentTextFont = "SamsungSmart_Light 34px";
						contentText2Font = "SamsungSmart_Light 34px"
						width = 1920;
						height = (0.046296 + 0.044444 * contextLineNumber + 0.042593) * screenHeight;
					} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						contentTextFont = "SamsungSmart_Light 22px";
						contentText2Font = "SamsungSmart_Light 22px";
						width = 1280;
						height = (0.046296 + 0.044444 * contextLineNumber + 0.042593) * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        contentLine = "multi_line_content_type";
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.046296 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight * contextLineNumber;
			    
			        // button
			        bButton = false;
					buttonType = "no_button";
				}
				break;
			
			case MessageBoxStyle.High_Contrast_MessageBox_1Line:
				{
					bHighContrast = true;
					y = (1 - 0.131481) * screenHeight/2;
					
					if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						contentTextFont = "SamsungSmart_Light 34px";
						contentText2Font = "SamsungSmart_Light 34px";
						width = 1920;
						height = 0.131481 * screenHeight;
					} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						contentTextFont = "SamsungSmart_Light 22px";
						contentText2Font = "SamsungSmart_Light 22px";
						width = 1280;
						height = 0.131481 * screenHeight;
					}
					
			        // content text
			        contentNumber = 1;
			        
			        contentTextColor ={ r: 255, g: 255, b: 255, a: 255 };
			     
			      	contentRect.x = (1 - 0.584375)/2 * screenWidth;
			      	contentRect.y = 0.043519 * screenHeight;
			      	contentRect.width = 0.584375 * screenWidth;
			      	contentRect.height = 0.044444 * screenHeight;
			    
			        // button
			        bButton = false;
				}
				break;
			
			default:
				break;
		}
		
		// button attr
		if(true == bButton){
			// text fontsize
			normalFont = 32;
			focusFont = 32;
			selectFont = 32;
			rolloverFont = 32;
			dimFont = 32;   
			
			if(buttonStyle == ButtonStyle.Button_Style_A || buttonStyle == ButtonStyle.Button_image_O_Style_E){		  
			    // background
			    buttonBgNormal = path + "btn_style_b_n.png";
				buttonBgFoucs = path + "btn_style_b_f.png";
				buttonBgSelect = path + "btn_style_b_s.png";
				buttonBgDim = path + "btn_style_b_d.png";
				
				// text color
				normalTextColor = { r: 64, g: 64, b: 64, a: 204 };
				focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
				selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
				dimTextColor = { r: 64, g: 64, b: 64, a: 76.5 };	
				rolloverTextColor = { r: 255, g: 255, b: 255, a: 255 };
				
				buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
				buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
				buttonBgSelectColor = { r: 33, g: 158, b: 230, a: 255 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				buttonBgRolloverColor = { r: 33, g: 158, b: 230, a: 255 };
				
				// boder color
				normalBorderColor = { r: 0, g: 0, b: 0, a: 51 };
				dimBorderColor = { r: 0, g: 0, b: 0, a: 25.5 };		
			}
	        
			 if(buttonStyle == ButtonStyle.Button_Style_B_Focus1 || buttonStyle == ButtonStyle.Button_image_O_Style_F_Focus1 || buttonStyle == ButtonStyle.Button_image_O_Style_F){
			    // background
			    buttonBgNormal = path + "btn_style_a_n.png";
				buttonBgFoucs = path + "btn_style_a_f.png";
				buttonBgSelect = path + "btn_style_a_s.png";
				buttonBgDim = path + "btn_style_a_d.png";
				
				// text color
				normalTextColor = { r: 255, g: 255, b: 255, a: 242.25 };
				focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
				selectTextColor = { r: 70, g: 70, b: 70, a: 255 };
				dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };	
				rolloverTextColor = { r: 70, g: 70, b: 70, a: 255 };	
				
				buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
				buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
				buttonBgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				buttonBgRolloverColor = { r: 255, g: 255, b: 255, a: 242.25 };
				
				// boder color
				normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
				dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
			}
			
			 if(buttonStyle == ButtonStyle.Button_Style_B_Focus2 || buttonStyle == ButtonStyle.Button_image_O_Style_F_Focus2){
			    // background
			    buttonBgNormal = path + "btn_style_a_n.png";
				buttonBgFoucs = path + "btn_style_a_f.png";
				buttonBgSelect = path + "btn_style_a_s.png";
				buttonBgDim = path + "btn_style_a_d.png";
				
				// text color
				normalTextColor = { r: 255, g: 255, b: 255, a: 242.25 };
				focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
				selectTextColor = { r: 70, g: 70, b: 70, a: 255 };
				dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };	
				rolloverTextColor = { r: 70, g: 70, b: 70, a: 255 };	
				
				buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
				buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
				buttonBgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
				buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
				buttonBgRolloverColor = { r: 255, g: 255, b: 255, a: 242.25 };
				
				// boder color
				normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
				dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
			} 
		}
		
		// loading attr
		if(true == bLoading){
			loadingImageNumber = 63;
			loadingImagePath = loadingImagePath + "white/20x20/";
			for (var i = 1; i <= 63; ++i){
			    if (i < 10){
			        loadingImageName[i-1] = "loading_bright_20_0" + i + ".png";
			    }
			    else{
			        loadingImageName[i-1] = "loading_bright_20_" + i + ".png";
			    }	
			}
		}
	
		// background
		if(BackgroundStyle.Background_Style_B_1 == bgStyle || BackgroundStyle.Background_Style_E_1 == bgStyle){
			firstLayerBGColor = bgPickColor;
			secondLayerBGColor = { r: 255, g: 255, b: 255, a: 12.75 };
			thirdLayerBGColor = { r: 0, g: 0, b: 0, a: 38.25 };
		}
		
		if(BackgroundStyle.Background_Style_B_2 == bgStyle || BackgroundStyle.Background_Style_E_2 == bgStyle){
			firstLayerBGColor = { r: 10, g: 35, b: 61, a: 255 };
			secondLayerBGColor = { r: 255, g: 255, b: 255, a: 12.75 };
			thirdLayerBGColor = { r: 0, g: 0, b: 0, a: 38.25 };
		}
		
		if(BackgroundStyle.Background_Style_B_3 == bgStyle || BackgroundStyle.Background_Style_E_3 == bgStyle){
			firstLayerBGColor = { r: 237, g: 237, b: 237, a: 242.25 };
			secondLayerBGColor = { r: 255, g: 255, b: 255, a: 12.75 };
			thirdLayerBGColor = { r: 0, g: 0, b: 0, a: 38.25 };
		}
		
		switch(popupStyle){
			case PopupStyle.Wizard_Popup:
			{
				titleTextColor = { r: 58, g: 58, b: 58, a: 229.5 };
				titleLineColor = { r: 0, g: 0, b: 0, a: 76.5 };
			
			}
			break;
			
			case PopupStyle.TV_and_Smart_Hub_Popup:
			{
				titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
				titleLineColor = { r: 255, g: 255, b: 255, a: 76.5 };
			}
			break;
			
			default:
				break;
		}		
	}
	
	var setHighContrast = function(){
		if(null != messagebox){
			if(true == bTitle){
				messagebox.setTitleTextColor(255, 255, 255, 255);
			}
	
			// content text
			if(1 == contentNumber){
				messagebox.setContentTextColor(255, 255, 255, 255);
			}
			
			if(2 == contentNumber){
				messagebox.setContentTextColor(255, 255, 255, 255);
				messagebox.setContentText2Color(255, 255, 255, 255);
			}

			messagebox.setFirstLayerBGColor({ firstLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
			messagebox.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
			messagebox.setThirdLayerBGColor({ thirdLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
		}
	}
	
	var setNoHighContrast = function(){
		if(null != messagebox){
			if(true == bTitle){
				messagebox.setTitleTextColor(titleTextColor.r, titleTextColor.g, titleTextColor.b, titleTextColor.a);
			}
	
			// content text
			if(1 == contentNumber){
				messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
			}
			if(2 == contentNumber){
				messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
				messagebox.setContentText2Color(contentText2Color.r, contentText2Color.g, contentText2Color.b, contentText2Color.a);
			}
	
			messagebox.setFirstLayerBGColor({ firstLayerBGColor: firstLayerBGColor });
		    messagebox.setSecondLayerBGColor({ secondLayerBGColor: secondLayerBGColor });
		    messagebox.setThirdLayerBGColor({ thirdLayerBGColor: thirdLayerBGColor });
		}
	}
	
	resolution = getResolution();				
	m_analysisParameter(obj);
	m_setCreateValue();
	
	if(true == bAutoFlag){
		width = 1920;
		height = 1080;	
	}
	
	//create Messagebox instance 
	messagebox = new MessageBox({
		 parent: parent,
		 width: width,
		 bTitle: bTitle,
		 color: {r: 0, g: 0, b: 0, a: 0 },
		 bAutoFlag: bAutoFlag,
         contentTextFont: contentTextFont,
         contentText: contentText,
         contentType: contentLine,
         buttonType: buttonType
	});
	
	if(1 == contentNumber || 2 == contentNumber){
		messagebox.setContentRect(0, 0, 0.584375 * screenWidth, 1080);
	}
	
	var lineInfo = HALOUtil.getTextLineInfo(contentText, contentTextFont, 0.584375 * screenWidth);
	Volt.log("contextLineNumber is : " + contextLineNumber);
	
	contextLineNumber = lineInfo.length;
	Volt.log("1 contextLineNumber is " + contextLineNumber);
	
	if(null != id){
		messagebox.id = id;
	}
	
	m_setDefaultValueByProgressStyle();
	
	messagebox.height = height;
	messagebox.x = 0;
	messagebox.y = 0;
	messagebox.origin = {x: 0.5, y: 0.5};
	messagebox.anchor = {x: 0.5, y: 0.5};
	
	// title
	if(true == bTitle){
		messagebox.setTitleText(titleText);
		if(false == bAutoFlag){
			messagebox.setTitleRect(titleRect.x, titleRect.y, titleRect.width, titleRect.height);
		}
		messagebox.setTitleTextColor(titleTextColor.r, titleTextColor.g, titleTextColor.b, titleTextColor.a);
		messagebox.setTitleTextFont(titleTextFont);
		messagebox.setTitleTextAlignment("horizontal_align_center", "vertical_align_middle");
		// title line
		messagebox.setTitleLineRect(titleLineRect.x, titleLineRect.y, titleLineRect.width, titleLineRect.height);
		messagebox.setTitleLineColor(titleLineColor.r, titleLineColor.g, titleLineColor.b, titleLineColor.a);
	}
	
	
	// content text
	if(1 == contentNumber){
		if(false == bAutoFlag){
			messagebox.setContentRect(contentRect.x, contentRect.y, contentRect.width, contentRect.height);
		}
		
		messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
		messagebox.setContentTextAlignment("horizontal_align_center", "vertical_align_top");
	}
	if(2 == contentNumber){
		if(false == bAutoFlag){
			messagebox.setContentRect(contentRect.x, contentRect.y, contentRect.width, contentRect.height);
		}
		
		messagebox.setContentTextColor(contentTextColor.r, contentTextColor.g, contentTextColor.b, contentTextColor.a);
		if(1 == contextLineNumber){
			messagebox.setContentTextAlignment("horizontal_align_center", "vertical_align_top");
		}else{
			messagebox.setContentTextAlignment("horizontal_align_left", "vertical_align_top");
		}
		// messagebox.contentTextRowGap = 100;
		messagebox.setContentText2Font(contentText2Font);
		messagebox.setContentText2(contentText2);
		if(false == bAutoFlag){
			messagebox.setContent2Rect(contentRect2.x, contentRect2.y, contentRect2.width, contentRect2.height);
		}
		messagebox.setContentText2Color(contentText2Color.r, contentText2Color.g, contentText2Color.b, contentText2Color.a);
		messagebox.setContentText2Alignment("horizontal_align_center", "vertical_align_top");	
	}
	
    var allHeight = 0;
    
    for (var i = 0; i < contextLineNumber; i++)
    {
        print("number is - " + i + " height is " + lineInfo[i]);
        allHeight += lineInfo[i];
    }
	var gap = (0.044444  * 1080 * contextLineNumber - allHeight) / (contextLineNumber + 1);
	print("gap is      " + gap);
	messagebox.contentTextRowGap = gap;
	
	if(true == bButton){
		
		if("button_1" == buttonType){
			messagebox.setButtonText("button_1", "all", button1Text);
			
			if(false == bAutoFlag){
				messagebox.setButtonRect("button_1", button1Rect.x, button1Rect.y, button1Rect.width, button1Rect.height);	
			}	
		}
		
		if("button_2" == buttonType){
			messagebox.setButtonText("button_1", "all", button1Text);
			messagebox.setButtonText("button_2", "all", button2Text);
			
			if(false == bAutoFlag){
				messagebox.setButtonRect("button_1", button1Rect.x, button1Rect.y, button1Rect.width, button1Rect.height);
				messagebox.setButtonRect("button_2", button2Rect.x, button2Rect.y, button2Rect.width, button2Rect.height);	
			}	
		}
		
		if("button_3" == buttonType){
			messagebox.setButtonText("button_1", "all", button1Text);
			messagebox.setButtonText("button_2", "all", button2Text);
			messagebox.setButtonText("button_3", "all", button3Text);
			
			if(false == bAutoFlag){
				messagebox.setButtonRect("button_1", button1Rect.x, button1Rect.y, button1Rect.width, button1Rect.height);
				messagebox.setButtonRect("button_2", button2Rect.x, button2Rect.y, button2Rect.width, button2Rect.height);
				messagebox.setButtonRect("button_3", button3Rect.x, button3Rect.y, button3Rect.width, button3Rect.height);
			}	
		}
		
		messagebox.setButtonBorderColor("button_all", "normal", normalBorderColor.r, normalBorderColor.g, normalBorderColor.b, normalBorderColor.a);
		messagebox.setButtonBorderColor("button_all", "disabled", dimBorderColor.r, dimBorderColor.g, dimBorderColor.b, dimBorderColor.a);
		messagebox.setButtonBorderWidth ("button_all", "normal", 2.0);
		messagebox.setButtonBorderWidth ("button_all", "disabled", 2.0);
		
		messagebox.setButtonBackgroundColor("button_all", "all", buttonBgNormal.r, buttonBgNormal.g, buttonBgNormal.b, buttonBgNormal.a);
		messagebox.setButtonBackgroundColor("button_all", "normal", buttonBgNormal.r, buttonBgNormal.g, buttonBgNormal.b, buttonBgNormal.a);
		messagebox.setButtonBackgroundColor("button_all", "focused", buttonBgFoucsColor.r, buttonBgFoucsColor.g, buttonBgFoucsColor.b, buttonBgFoucsColor.a);
		messagebox.setButtonBackgroundColor("button_all", "selected", buttonBgSelectColor.r, buttonBgSelectColor.g, buttonBgSelectColor.b, buttonBgSelectColor.a);
		messagebox.setButtonBackgroundColor("button_all", "disabled", buttonBgDimColor.r, buttonBgDimColor.g, buttonBgDimColor.b, buttonBgDimColor.a);
		messagebox.setButtonBackgroundColor("button_all", "roll-over", buttonBgFoucsColor.r, buttonBgFoucsColor.g, buttonBgFoucsColor.b, buttonBgFoucsColor.a);
		messagebox.setButtonBackgroundColor("button_all", "focused-roll-over", buttonBgFoucsColor.r, buttonBgFoucsColor.g, buttonBgFoucsColor.b, buttonBgFoucsColor.a);
		
		messagebox.setButtonTextColor("button_all", "all", normalTextColor.r, normalTextColor.g, normalTextColor.b, normalTextColor.a);
		messagebox.setButtonTextColor("button_all", "normal", normalTextColor.r, normalTextColor.g, normalTextColor.b, normalTextColor.a);
		messagebox.setButtonTextColor("button_all", "focused", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
		messagebox.setButtonTextColor("button_all", "selected", selectTextColor.r, selectTextColor.g, selectTextColor.b, selectTextColor.a);
		messagebox.setButtonTextColor("button_all", "disabled", dimTextColor.r, dimTextColor.g, dimTextColor.b, dimTextColor.a);
		messagebox.setButtonTextColor("button_all", "roll-over", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
		messagebox.setButtonTextColor("button_all", "focused-roll-over", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
       
		messagebox.setButtonTextFontSize("button_all", "all", normalFont);
		messagebox.setButtonTextFontSize("button_all", "normal", normalFont);
		messagebox.setButtonTextFontSize("button_all", "focused", focusFont);
		messagebox.setButtonTextFontSize("button_all", "selected", selectFont);
		messagebox.setButtonTextFontSize("button_all", "disabled", dimFont);
		messagebox.setButtonTextFontSize("button_all", "roll-over", focusFont);
		messagebox.setButtonTextFontSize("button_all", "focused-roll-over", focusFont);	
	}    
	
	// loading
	if(true == bLoading){
		messagebox.setLoadingAttr({
			x: loadingX,
			y: loadingY,
			imageWidth: loadingWidth,
			imageHeight: loadingHeight, 
			imageNum: loadingImageNumber, 
			imageFps: 15, 
			imagePath: loadingImagePath, 
			imageName: loadingImageName
		});	
	}
	
	print("2 contextLineNumber is " + contextLineNumber);
	
	bHighContrast = HALOUtil.highContrast; // check status of highcontrast now
    if(true == bHighContrast){
    	setHighContrast();
    }else{
    	messagebox.setFirstLayerBGColor({ firstLayerBGColor: firstLayerBGColor });
	    messagebox.setSecondLayerBGColor({ secondLayerBGColor: secondLayerBGColor });
	    messagebox.setThirdLayerBGColor({ thirdLayerBGColor: thirdLayerBGColor });
    }
    messagebox.setSecondLayerBGHeight(secondLayerBGHeight);
    messagebox.setThirdLayerBGHeight(thirdLayerBGHeight);
    messagebox.setFourthLayerBGImage({ fourthLayerBGImage: shadowPath + "bg/popup_shadow.png" });
	
	var widgetExListener = new WidgetExListener;
	widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
		print("flagHighContrast is " + flagHighContrast);
		print("bHighContrast is " + bHighContrast);
	    if((true == flagHighContrast) && (false == bHighContrast)){
	    	setHighContrast();
	    	bHighContrast = true;
	    }
	    
	    if((false == flagHighContrast) && (true == bHighContrast)){
	    	setNoHighContrast();
	    	bHighContrast = false;
	    }
	};
	messagebox.addWidgetExListener(widgetExListener);
	
	messagebox.destroyListener = function(){
		if(null != widgetExListener){
			messagebox.removeWidgetExListener(widgetExListener);
			widgetExListener.destroy();
			widgetExListener = null;
		}
	};
	
	return messagebox;	
}

var MessageBoxStyle = {
		MessageBox_Title_Button_1Line:1,
		MessageBox_Title_Button_2_8Line:2,
		MessageBox_NoTitle_Button_1Line:3,
		MessageBox_NoTitle_Button_2_8Line:4,
		MessageBox_NoTitle_Button_Message_Text_Align:5,
		MessageBox_NoTitle_NoButton:6,
		MessageBox_1Line:7,
		MessageBox_1Line_Loading:8,
		MessageBox_2Line_Loading:9,
		MessageBox_3Line_Loading:10,
		// panel extension
		MessageBox_Extension_One_Button:11,
		MessageBox_Extension_Three_Button:12,
		// High Contrast
		High_Contrast_MessageBox_Title_Button_2_8Line:13, // to be delete
		High_Contrast_MessageBox_NoTitle_Button_2_8Line:14, // to be delete
		High_Contrast_MessageBox_NoTitle_NoButton:15, // to be delete
		High_Contrast_MessageBox_1Line:16, // to be delete
		
		MessageBox_Style_Max:17
	};
	
var BackgroundStyle = {
		Background_Style_B_1:1, // to be delete
		Background_Style_B_2:2, // to be delete
		Background_Style_B_3:3, // to be delete
		Background_Style_E_1:4,
		Background_Style_E_2:5,
		Background_Style_E_3:6,
		Background_Style_Max:7
	};
	
var ButtonStyle = {
		Button_Style_A: 1, // to be delete
		Button_Style_B_Focus1: 2, // to be delete
		Button_Style_B_Focus2: 3, // to be delete
		Button_image_O_Style_E: 4, 
		Button_image_O_Style_F_Focus1: 5, // to be delete
	    Button_image_O_Style_F_Focus2: 6, // to be delete
	    Button_image_O_Style_F: 7,
	    Button_Style_Max: 8
	};
	
var PopupStyle = {
	Wizard_Popup: 1,
	TV_and_Smart_Hub_Popup: 2
}

winsetMessageBox.MessageBoxStyle = MessageBoxStyle;
winsetMessageBox.BackgroundStyle = BackgroundStyle;
winsetMessageBox.ButtonStyle = ButtonStyle;
winsetMessageBox.PopupStyle = PopupStyle;
winsetMessageBox.prototype = new winsetBase();

exports = winsetMessageBox;