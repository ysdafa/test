var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetButton = function(obj){				
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	// local var
	this.safButtonProperties = {
		style: ButtonStyle.BUTTON_STYLE_A,
		resolution : ResolutionStyle.Resolution_1080,
		button : null,
		x : 0,
		y : 0,
		width : 150,
		height : 150,
		parent : scene,
		id : null,
		path : "modules/WinsetUIElement/winsetImg/",
		text : "Button Text",
		// spacing
		textLeftSpacing : 0.010417,
		icontextSpacing : 0.006250,
		// icon attr
		iconWidth : 0,
		iconHeight : 0,
		iconImgSrc : null,
		iconFocusImgSrc : null,
		iconNormalOpactiy: 0,
		iconFoucsOpactiy: 0,
		iconSelectOpactiy: 0,
		iconDimOpactiy: 0,
		// image path
		bgNormal : null,
		bgFoucs : null,
		bgSelect : null,
		bgDim = null,
		// background color
		bgNormalColor : { r: 0, g: 0, b: 0, a: 0 },
		bgFoucsColor : { r: 0, g: 0, b: 0, a: 0 },
		bgSelectColor : { r: 0, g: 0, b: 0, a: 0 },
		bgDimColor : { r: 0, g: 0, b: 0, a: 0 },
		// buttonType 1: text, 2: icon, 3: text + icon
		buttonType : ButtonType.BUTTON_TEXT,
		// text fontsize
		textWidth : 0,
		normalFont : 0,
		focusFont : 0,
		selectFont :0,
		dimFont :0,
		// text color
		normalTextColor : { r: 0, g: 0, b: 0, a: 0 },
		focusTextColor : { r: 0, g: 0, b: 0, a: 0 },
		selectTextColor : { r: 0, g: 0, b: 0, a: 0 },
		dimTextColor: { r: 0, g: 0, b: 0, a: 0 },
		rolloverColor : { r:0, g:0, b:0, a:0 },
		bHighContrast : false,
		// border
		bHasBorder : true,
		normalBorderColor : { r: 0, g: 0, b: 0, a: 0 },
		selectBorderColor : { r: 0, g: 0, b: 0, a: 0 },
		dimBorderColor : { r: 0, g: 0, b: 0, a: 0 } ,		
		// screen attr
		screenWidth = 1920;
	};

	var analysisParameters = 
	{
		style : { refer : this.safButtonProperties.style, type: 'isStringOrNumber', 	default: 1 },
		buttonType : { refer : this.safButtonProperties.buttonType, type: 'isStringOrNumber' },
		x : {refer : this.safButtonProperties.x, type: type: 'isStringOrNumber' },
		y : {refer : this.safButtonProperties.y, type: type: 'isStringOrNumber' },
		width : {refer : this.safButtonProperties.width, type: type: 'isStringOrNumber' },
		height : {refer : this.safButtonProperties.height, type: type: 'isStringOrNumber' },
		iconWidth : {refer : this.safButtonProperties.iconWidth, type: type: 'isStringOrNumber' },
		iconHeight : {refer : this.safButtonProperties.iconHeight, type: type: 'isStringOrNumber' },
		iconImgSrc : {refer : this.safButtonProperties.iconImgSrc, type: type: 'isString' },
		iconFocusImgSrc : {refer : this.safButtonProperties.iconFocusImgSrc, type: type: 'isString' },
		text : {refer : this.safButtonProperties.text, type: type: 'isString' },
		textWidth : {refer : this.safButtonProperties.textWidth, type: type: 'isStringOrNumber' },
		id : {refer : this.safButtonProperties.id, type: type: 'string' },
		parent : {refer : this.safButtonProperties.parent, type: type: 'isObject' },
		text : {refer : this.safButtonProperties.text, type: type: 'isString' },
		bHasBorder : {refer : this.safButtonProperties.bHasBorder, type: type: 'isBooleanOrString' }
	}

	
	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number" || typeof objParameter.style == "string")){
				
				if(typeof objParameter.style == "string"){
					style = parseInt(objParameter.style);
				}else{
					style = objParameter.style;	
				}
				
				if((1 > style) || (ButtonStyle.Button_Style_Max <= style)){
					style = 1;
				}
			}
			
			
			if(objParameter.hasOwnProperty("buttonType")
				&& (typeof objParameter.buttonType == "number" || typeof objParameter.buttonType == "string")){
				if(typeof objParameter.buttonType == "string"){
					buttonType = parseInt(objParameter.buttonType);	
				}else{
					buttonType = objParameter.buttonType;	
				}	
			}

			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
				if(typeof objParameter.x == "string"){
					x = parseInt(objParameter.x);	
				}else{
					x = objParameter.x;	
				} 
				
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					y = parseInt(objParameter.y);	
				}else{
					y = objParameter.y;	
				}
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
				if(typeof objParameter.width == "string"){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
				if(typeof objParameter.height == "string"){
					height = parseInt(objParameter.height);
				}else{
					height = objParameter.height;
				}			
			}
			
			if(objParameter.hasOwnProperty("iconWidth")
				&& (typeof objParameter.iconWidth == "number" || typeof objParameter.iconWidth == "string")){
				if(typeof objParameter.iconWidth == "string"){
					iconWidth = parseInt(objParameter.iconWidth);	
				}else{
					iconWidth = objParameter.iconWidth;	
				}				
			}	
			
			if(objParameter.hasOwnProperty("iconHeight")
				&& (typeof objParameter.iconHeight == "number" || typeof objParameter.iconHeight == "string")){
				if(typeof objParameter.iconHeight == "string"){
					iconHeight = parseInt(objParameter.iconHeight);
				}else{
					iconHeight = objParameter.iconHeight;
				}				
			}	
			
			if(objParameter.hasOwnProperty("iconImgSrc")
				&& (typeof objParameter.iconImgSrc == "string")){
				iconImgSrc = objParameter.iconImgSrc;	
			}
			
			if(objParameter.hasOwnProperty("iconFocusImgSrc")
				&& (typeof objParameter.iconFocusImgSrc == "string")){
				iconFocusImgSrc = objParameter.iconFocusImgSrc;	
			}
			
			if(objParameter.hasOwnProperty("text")
				&& (typeof objParameter.text == "string")){
				text = objParameter.text;	
			}
			
			if(objParameter.hasOwnProperty("textWidth")
				&& (typeof objParameter.textWidth == "number" || typeof objParameter.textWidth == "string")){
				if(typeof objParameter.textWidth == "string"){
					textWidth = parseInt(objParameter.textWidth);
				}else{
					textWidth = objParameter.textWidth;
				}		
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
				
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
			
			if(objParameter.hasOwnProperty("bHasBorder")
				&& (typeof objParameter.bHasBorder == "boolean" || typeof objParameter.bHasBorder == "string")){
				if(typeof objParameter.bHasBorder == "string"){
					if("true" == objParameter.bHasBorder){
						bHasBorder = true;
					}else if("false" == objParameter.bHasBorder){
						bHasBorder = false;
					}
				}else{
					bHasBorder = objParameter.bHasBorder;
				}	
			}
		}	
	}
			
	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			path = path + "1080p/btn/";
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			path = path + "720p/btn/";
		}

		//set default value
		switch(style)
		{
			case ButtonStyle.BUTTON_STYLE_A:
			case ButtonStyle.Button_image_O_Style_E:
				{
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
		
					// image path
					// bgNormal = path + "btn_style_b_n.png";
					// bgFoucs = path + "btn_style_b_f.png";
					// bgSelect = path + "btn_style_b_s.png";
					// bgDim = path + "btn_style_b_d.png";
					
					// background color
					bgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
					bgSelectColor = { r: 33, g: 158, b: 230, a: 255 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 0, g: 0, b: 0, a: 51 };
					// selectBorderColor = { r: 241, g: 171, b: 21, a: 153 };
					dimBorderColor = { r: 0, g: 0, b: 0, a: 25.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						// text fontsize
						normalFont = 32;
						focusFont = 32;
						selectFont = 32;
						dimFont = 32;
						// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// // text fontsize
							// normalFont = 32;
							// focusFont = 32;
							// selectFont = 32;
							// dimFont = 32;
						// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// // text fontsize
							// normalFont = 21;
							// focusFont = 21;
							// selectFont = 21;
							// dimFont = 21;
						// }
						
						// text color
						normalTextColor = { r: 64, g: 64, b: 64, a: 255 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 64, g: 64, b: 64, a: 76.5 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 242.25;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76.5;
					}
				}
				break;
				
			case ButtonStyle.Button_image_O_Style_F:
			case ButtonStyle.BUTTON_STYLE_B_FOCUS1:
			case ButtonStyle.Button_image_O_Style_F_FOCUS1:
				{
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
					
					// image path
					// bgNormal = path + "btn_style_a_n.png";
					// bgFoucs = path + "btn_style_a_f.png";
					// bgSelect = path + "btn_style_a_s.png";
					// bgDim = path + "btn_style_a_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
					bgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 0 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						// text fontsize
						normalFont = 32;
						focusFont = 32;
						selectFont = 32;
						dimFont = 32;
						// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// // text fontsize
							// normalFont = 32;
							// focusFont = 32;
							// selectFont = 32;
							// dimFont = 32;
						// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// // text fontsize
							// normalFont = 21;
							// focusFont = 21;
							// selectFont = 21;
							// dimFont = 21;
						// }
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 242.25 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 70, g: 70, b: 70, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 242.25;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76.5;
					}
				}
				break;
			
			// to be delete
			case ButtonStyle.BUTTON_STYLE_B_FOCUS2:
			case ButtonStyle.Button_image_O_Style_F_FOCUS2:
				{
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_a_n.png";
					bgFoucs = path + "btn_style_a_f.png";
					bgSelect = path + "btn_style_a_s.png";
					bgDim = path + "btn_style_a_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
					bgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 0 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						// text fontsize
						normalFont = 32;
						focusFont = 32;
						selectFont = 32;
						dimFont = 32;
						// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// // text fontsize
							// normalFont = 32;
							// focusFont = 32;
							// selectFont = 32;
							// dimFont = 32;
						// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// // text fontsize
							// normalFont = 21;
							// focusFont = 21;
							// selectFont = 21;
							// dimFont = 21;
						// }
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 242.25 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 70, g: 70, b: 70, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 242.25;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76.5;
					}
				}
				break;
			
			// to be delete
			case ButtonStyle.BUTTON_STYLE_C_FOCUS1:
			case ButtonStyle.Button_image_O_Style_G_FOCUS1:
			case ButtonStyle.Button_image_O_Style_G:
				{
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_c_n.png";
					bgFoucs = path + "btn_style_c_f.png";
					bgSelect = path + "btn_style_c_s.png";
					bgDim = path + "btn_style_c_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 242 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						// text fontsize
						normalFont = 26;
						focusFont = 30;
						selectFont = 30;
						dimFont = 26;
						// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// // text fontsize
							// normalFont = 26;
							// focusFont = 30;
							// selectFont = 30;
							// dimFont = 26;
						// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// // text fontsize
							// normalFont = 17;
							// focusFont = 20;
							// selectFont = 20;
							// dimFont = 17;
						// }
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 153 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 255, g: 194, b: 31, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
			
			// to be delete
			case ButtonStyle.BUTTON_STYLE_C_FOCUS2:
			case ButtonStyle.Button_image_O_Style_G_FOCUS2:
				{
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_c_n.png";
					bgFoucs = path + "btn_style_c_f.png";
					bgSelect = path + "btn_style_c_s.png";
					bgDim = path + "btn_style_c_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 242 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						// text fontsize
						normalFont = 26;
						focusFont = 30;
						selectFont = 30;
						dimFont = 26;
						// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// // text fontsize
							// normalFont = 26;
							// focusFont = 30;
							// selectFont = 30;
							// dimFont = 26;
						// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// // text fontsize
							// normalFont = 17;
							// focusFont = 20;
							// selectFont = 20;
							// dimFont = 17;
						// }
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 153 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 255, g: 194, b: 31, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
			
			case ButtonStyle.Button_image_O_Style_H:
				{
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_b_n.png";
					bgFoucs = path + "btn_style_b_f.png";
					bgSelect = path + "btn_style_b_s.png";
					bgDim = path + "btn_style_b_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
					bgSelectColor = { r: 33, g: 158, b: 230, a: 255 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 0, g: 0, b: 0, a: 38.25 };
					selectBorderColor = { r: 241, g: 171, b: 21, a: 0 };
					dimBorderColor = { r: 0, g: 0, b: 0, a: 25.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						// text fontsize
						normalFont = 26;
						focusFont = 26;
						selectFont = 26;
						dimFont = 26;
						// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// // text fontsize
							// normalFont = 26;
							// focusFont = 26;
							// selectFont = 26;
							// dimFont = 26;
						// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// // text fontsize
							// normalFont = 17;
							// focusFont = 17;
							// selectFont = 17;
							// dimFont = 17;
						// }
						
						// text color
						normalTextColor = { r: 64, g: 64, b: 64, a: 242.25 };
						focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
						selectTextColor = { r: 244, g: 244, b: 244, a: 255 };
						dimTextColor = { r: 64, g: 64, b: 64, a: 76.5 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 242.25;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76.5;
					}
				}
				break;
			
				
			// High Contrast to be delete
			case ButtonStyle.High_Contrast_Button_image_O_Style_E:
				{
					bHighContrast = true;
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
		
					// image path
					bgNormal = path + "btn_style_b_n.png";
					bgFoucs = path + "btn_style_b_f.png";
					bgSelect = path + "btn_style_b_s.png";
					bgDim = path + "btn_style_b_d.png";
					
					// background color
					bgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 0 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// text fontsize
							normalFont = 32;
							focusFont = 36;
							selectFont = 36;
							dimFont = 32;
						} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// text fontsize
							normalFont = 21;
							focusFont = 24;
							selectFont = 24;
							dimFont = 21;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 255 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 255 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.High_Contrast_Button_image_O_Style_F_FOCUS1:
				{
					bHighContrast = true;
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_a_n.png";
					bgFoucs = path + "btn_style_a_f.png";
					bgSelect = path + "btn_style_a_s.png";
					bgDim = path + "btn_style_a_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 0 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// text fontsize
							normalFont = 32;
							focusFont = 36;
							selectFont = 36;
							dimFont = 32;
						} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// text fontsize
							normalFont = 21;
							focusFont = 24;
							selectFont = 24;
							dimFont = 21;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 255 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 255 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.High_Contrast_Button_image_O_Style_F_FOCUS2:
				{
					bHighContrast = true;
					// spacing
					textLeftSpacing = 0.010417,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_a_n.png";
					bgFoucs = path + "btn_style_a_f.png";
					bgSelect = path + "btn_style_a_s.png";
					bgDim = path + "btn_style_a_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 0 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// text fontsize
							normalFont = 32;
							focusFont = 36;
							selectFont = 36;
							dimFont = 32;
						} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// text fontsize
							normalFont = 21;
							focusFont = 24;
							selectFont = 24;
							dimFont = 21;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 255 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 255 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.High_Contrast_Button_image_O_Style_G_FOCUS1:
				{
					bHighContrast = true;
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_c_n.png";
					bgFoucs = path + "btn_style_c_f.png";
					bgSelect = path + "btn_style_c_s.png";
					bgDim = path + "btn_style_c_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 0 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// text fontsize
							normalFont = 26;
							focusFont = 30;
							selectFont = 30;
							dimFont = 26;
						} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// text fontsize
							normalFont = 17;
							focusFont = 20;
							selectFont = 20;
							dimFont = 17;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 255 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 255 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
			case ButtonStyle.High_Contrast_Button_image_O_Style_G_FOCUS2:
				{
					bHighContrast = true;
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_c_n.png";
					bgFoucs = path + "btn_style_c_f.png";
					bgSelect = path + "btn_style_c_s.png";
					bgDim = path + "btn_style_c_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 0 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// text fontsize
							normalFont = 26;
							focusFont = 30;
							selectFont = 30;
							dimFont = 26;
						} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// text fontsize
							normalFont = 17;
							focusFont = 20;
							selectFont = 20;
							dimFont = 17;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 255 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 255 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
			
			case ButtonStyle.High_Contrast_Button_image_O_Style_H:
				{
					bHighContrast = true;
					// spacing
					textLeftSpacing = 0.005208,
					icontextSpacing = 0.006250,
					
					// image path
					bgNormal = path + "btn_style_b_n.png";
					bgFoucs = path + "btn_style_b_f.png";
					bgSelect = path + "btn_style_b_s.png";
					bgDim = path + "btn_style_b_d.png";
				
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 33, g: 158, b: 230, a: 0 };
					bgSelectColor = { r: 0, g: 0, b: 0, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					selectBorderColor = { r: 255, g: 194, b: 31, a: 153 };
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType || 3 == buttonType){
						// set text attr value
						if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
							// text fontsize
							normalFont = 26;
							focusFont = 30;
							selectFont = 30;
							dimFont = 26;
						} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
							// text fontsize
							normalFont = 17;
							focusFont = 20;
							selectFont = 20;
							dimFont = 17;
						}
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 255 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 255 };	
					}
					
					if(2 == buttonType || 3 == buttonType){
						iconNormalOpactiy = 153;
						iconFoucsOpactiy = 255;
						iconSelectOpactiy = 255;
						iconDimOpactiy = 76;
					}
				}
				break;
				
				case ButtonStyle.Button_image_X_Style_B:
				{
					bHighContrast = false;
				
					buttonType = 2;
					bHasBorder = false;
					
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
					bgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					iconNormalOpactiy = 153;
					iconFoucsOpactiy = 255;
					iconSelectOpactiy = 255;
					iconDimOpactiy = 38.25;
					
				}
				break;
				
				case ButtonStyle.Button_image_Mycontent_Option:
				{
					bHighContrast = false;
				
					buttonType = 2;
					bHasBorder = true;
					
					// background color
					bgNormalColor = { r: 255, g: 255, b: 255, a: 0 };
					bgFoucsColor = { r: 255, g: 255, b: 255, a: 0 };
					bgSelectColor = { r: 255, g: 255, b: 255, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					bgFoucs = path + "for_app.png";
					
					iconNormalOpactiy = 255;
					iconFoucsOpactiy = 255;
					iconSelectOpactiy = 255;
					iconDimOpactiy = 76;
					
				}
				break;
				
				//add keyScreen common button
				case ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA:
				{
					textLeftSpacing = 0.010417;					
					
					bgFoucs = path + "ksc_focus.png";
					
					// background color
					bgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
					bgFoucsColor = { r: 0, g: 0, b: 0, a: 0 };
					bgSelectColor = { r: 255, g: 255, b: 255, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
					focusBorderColor = {r: 255, g: 255, b: 255, a:204};
					selectBorderColor = {r: 255, g: 255, b: 255, a:204};
					dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
					
					if(1 == buttonType){
						// text fontsize
						normalFont = 32;
						focusFont = 36;
						selectFont = 36
						dimFont = 32;
			
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor =  { r: 255, g: 255, b: 255, a: 76.5 };
					}
					
					if (2 == buttonType){
						iconNormalOpactiy = 204;
						iconFoucsOpactiy = 255;
						iconDimOpactiy = 76.5;
					}
				}
				break;
				
				case ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text:
				{
					textLeftSpacing = 0.010417;
					
					// background color
					bgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
					bgFoucsColor = { r: 0, g: 0, b: 0, a: 0 };
					bgSelectColor = { r: 255, g: 255, b: 255, a: 0 };
					bgDimColor = { r: 255, g: 255, b: 255, a: 0 };
					
					// boder color
					normalBorderColor = { r: 0, g: 0, b: 0, a: 51 };
					focusBorderColor = { r: 33, g: 158, b: 230, a: 255 };
					dimBorderColor = { r: 0, g: 0, b: 0, a: 51 };
					
					
					// text fontsize
					normalFont = 32;
					focusFont = 36;
					selectFont = 36
					dimFont = 32;
		
					// text color
					normalTextColor = { r: 67, g: 71, b: 82, a: 255 };
					focusTextColor = { r: 33, g: 158, b: 230, a: 255 };
					selectTextColor = { r: 33, g: 158, b: 230, a: 255 };
					dimTextColor =  { r: 67, g: 71, b: 82, a: 102 };
				}
				break;
				
			default:
				break;
		}
	}

	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	//create button instance 
	if(1 == buttonType){
		button = new Button({
			x: x,
			y: y,
			width: width,
			height: height,
			parent: parent,
			text: { text: text, x: textLeftSpacing * screenWidth, y: 0, width: width - 2 * textLeftSpacing * screenWidth, height: height, hAlign: "center", vAlign: "middle" }
		});
	}
	
    if(2 == buttonType){
		button = new Button({
			x: x,
			y: y,
			width: width,
			height: height,
			parent: parent,
			icon: { src: iconImgSrc, x: (width - iconWidth)/2, y: (height - iconHeight)/2, width: iconWidth, height: iconHeight }
			// icon: { src: iconImgSrc }
		});
		
		if(null != iconFocusImgSrc){
			button.setIconImage({
				state: "focused",
				src: iconFocusImgSrc
			});
			
			button.setIconImage({
				state: "selected",
				src: iconFocusImgSrc
			});
			
			button.setIconImage({
				state: "roll-over",
				src: iconFocusImgSrc
			});
			
			button.setIconImage({
				state: "focused-roll-over",
				src: iconFocusImgSrc
			});
		}	
	}
	
	if(3 == buttonType){
		button = new Button({
			x: x,
			y: y,
			width: width,
			height: height,
			parent: parent,
			text: { text: text, x: (width - iconWidth - textWidth - screenWidth * icontextSpacing)/2 + iconWidth + screenWidth * icontextSpacing, y: 0, width: textWidth, height: height, hAlign: "left", vAlign: "middle" },
			icon: { src: iconImgSrc, x: (width - iconWidth - textWidth - screenWidth * icontextSpacing)/2, y: (height - iconHeight)/2, width: iconWidth, height: iconHeight }
		});
	}
	
	if(null != button){
		if(null != id){
			button.id = id;
		}
		
		if(1 == buttonType || 3 == buttonType){
			button.setTextAttr({ font: "SamsungSmart_Light 32px" });
		}
		
		if(true == bHasBorder){
			if(ButtonStyle.Button_image_Mycontent_Option == style){
				if(null != bgFoucs){
					button.setBackgroundImage({
						state: "focused",
						src: bgFoucs,
					});
					
					button.setBackgroundImage({
						state: "roll-over",
						src: bgFoucs,
					});
					
					button.setBackgroundImage({
						state: "focused-roll-over",
						src: bgFoucs,
					});
				}
			}
			//add common btn
			else if (ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA == style){
				if(null != bgFoucs){
					button.setBackgroundImage({
						state: "focused",
						src: bgFoucs,
					});
					button.setBackgroundImage({
						state: "disabled-focused",
						src: bgFoucs,
					});
					button.setBackgroundImageAttr({x:-8, y:-8, width: width+16, height:height+16});
				}
				
				button.setBorder({
					state: "normal",
					border: {
						width: 1,
						color: normalBorderColor
					}
				});
				
				button.setBorder({
						state: "focused",
						border: {
							width: 1,
							color: normalBorderColor
						}
				});
				
				button.setBorder({
					state: "selected",
					border: {
						width: 1,
						color: selectBorderColor
					}
				});
				
				
				button.setBorder({
					 state: "roll-over",
					 border: {
						width: 1,
						color: focusBorderColor
					 }
				});
				 
				button.setBorder({
					 state: "focused-roll-over",
					 border: {
						width: 1,
						color: focusBorderColor
					 }
				 });
			
				button.setBorder({
					state: "disabled",
					border: {
						width: 1,
						color: dimBorderColor
					}
				});
				
				button.setBorder({
					state: "disabled-focused",
					border: {
						width: 1,
						color: focusBorderColor
					}
				});					
			}
			else if (ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text == style){
				button.setBorder({
					state: "normal",
					border: {
						width: 2,
						color: normalBorderColor
					}
				});
				
				button.setBorder({
					 state: "focused",
					 border: {
						width: 5,
						color: focusBorderColor
					 }
				});
				
				button.setBorder({
					 state: "selected",
					 border: {
						width: 2,
						color: normalBorderColor
					 }
				});
				
				button.setBorder({
					 state: "roll-over",
					 border: {
						width: 2,
						color: normalBorderColor
					 }
				});
				 
				button.setBorder({
					 state: "focused-roll-over",
					 border: {
						width: 2,
						color: normalBorderColor
					 }
				 });
			
				button.setBorder({
					state: "disabled",
					border: {
						width: 2,
						color: dimBorderColor
					}
				});
				
				button.setBorder({
					state: "disabled-focused",
					border: {
						width: 5,
						color: focusBorderColor
					}
				});
			}
			
			else {	
				button.setBorder({
					state: "normal",
					border: {
						width: 2,
						color: normalBorderColor
					}
				});
			
				// button.setBorder({
					// state: "selected",
					// border: {
						// width: 2,
						// color: selectBorderColor
					// }
				// });
			
				button.setBorder({
					state: "disabled",
					border: {
						width: 2,
						color: dimBorderColor
					}
				});
				
				//add dim focus
				button.setBorder({
					state: "disabled-focused",
					border: {
						width: 2,
						color: dimBorderColor
					}
				});
			}
			
			// set each state of image
			// if(null != bgNormal){
				// button.setBackgroundImage({
					// state: "normal",
					// src: bgNormal,
				// });
			// }
			
			
			// button.setBackgroundImage({
				// state: "focused",
				// src: bgFoucs,
			// });
			// if(null != bgSelect){
				// button.setBackgroundImage({
					// state: "selected",
					// src: bgSelect,
				// });
			// }
// 			
			// if(null != bgDim){
				// button.setBackgroundImage({
					// state: "disabled",
					// src: bgDim,
				// });
			// }
		}
		
		// set background color
		button.setBackgroundColor({
			state: "normal",
			color: bgNormalColor,
		});
		
		button.setBackgroundColor({
			state: "focused",
			color: bgFoucsColor,
		});
		
		button.setBackgroundColor({
			state: "selected",
			color: bgSelectColor,
		});
		
		button.setBackgroundColor({
			state: "disabled",
			color: bgDimColor,
		});
		
		//add dim focus
		button.setBackgroundColor({
			state: "disabled-focused",
			color: bgDimColor,
		});
		
		button.setBackgroundColor({
			state: "roll-over",
			color: bgFoucsColor,
		});
		
		button.setBackgroundColor({
			state: "focused-roll-over",
			color: bgFoucsColor,
		});
		
		// set text attr
		if(1 == buttonType || 3 == buttonType){
			// set each state of text font
			button.setFontSize({
				state: "normal",
				size: normalFont,
			});
			
			button.setFontSize({
				state: "focused",
				size: focusFont,
			});
			
			button.setFontSize({
				state: "selected",
				size: selectFont,
			});
			
			button.setFontSize({
				state: "disabled",
				size: dimFont,
			});
			
			//add dim focus
			button.setFontSize({
				state: "disabled-focused",
				size: dimFont,
			});
			
			button.setFontSize({
				state: "roll-over",
				size: focusFont,
			});
			
			button.setFontSize({
				state: "focused-roll-over",
				size: focusFont,
			});
			
			// set each state of text color
			button.setTextColor({
				state: "normal",
				color: normalTextColor,
			});
			
			button.setTextColor({
				state: "focused",
				color: focusTextColor,
			});
			
			button.setTextColor({
				state: "selected",
				color: selectTextColor
			});
			
			button.setTextColor({
				state: "disabled",
				color: dimTextColor
			});
			
			//add dim focus
			button.setTextColor({
				state: "disabled-focused",
				color: dimTextColor
			});
			
			button.setTextColor({
				state: "roll-over",
				color: focusTextColor
			});
			
			button.setTextColor({
				state: "focused-roll-over",
				color: focusTextColor
			});
			
			if(true == bHighContrast){
				button.setTextColor({
					state: "roll-over",
					color: { r: 255, g: 255, b: 255, a: 255 }
				});
			}
		}
		
		// set icon attr
		if(2 == buttonType || 3 == buttonType){	
			//add common button
			if (ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA == style){
				button.setIconAlpha({
					state: "normal",
					alpha: iconNormalOpactiy
				});
				
				button.setIconAlpha({
					state: "focused",
					alpha: iconFoucsOpactiy
				});
				
				button.setIconAlpha({
					state: "selected",
					alpha: iconFoucsOpactiy
				});
				
				button.setIconAlpha({
					state: "roll-over",
					alpha: iconFoucsOpactiy
				});
				
				button.setIconAlpha({
					state: "focused-roll-over",
					alpha: iconFoucsOpactiy
				});
				
				button.setIconAlpha({
					state: "disabled",
					alpha: iconDimOpactiy
				});	
			}
			else {
				button.setIconAlpha({
					state: "normal",
					alpha: iconNormalOpactiy
				});
				
				button.setIconAlpha({
					state: "focused",
					alpha: iconFoucsOpactiy
				});
				
				button.setIconAlpha({
					state: "selected",
					alpha: iconSelectOpactiy
				});
				
				button.setIconAlpha({
					state: "disabled",
					alpha: iconDimOpactiy
				});		
			}
			
			//add dim focus
			button.setIconAlpha({
				state: "disabled-focused",
				alpha: iconDimOpactiy
			});
		}
	}
	
	return button;	
}

var ButtonStyle = {
	BUTTON_STYLE_A: 1, // to be delete
	BUTTON_STYLE_B_FOCUS1: 2, // to be delete
	BUTTON_STYLE_B_FOCUS2: 3, // to be delete
	BUTTON_STYLE_C_FOCUS1: 4, // to be delete
	BUTTON_STYLE_C_FOCUS2: 5, // to be delete
	Button_image_O_Style_E: 6,
	Button_image_O_Style_F_FOCUS1: 7, // to be delete
	Button_image_O_Style_F_FOCUS2: 8, // to be delete
	Button_image_O_Style_G_FOCUS1: 9, // to be delete
	Button_image_O_Style_G_FOCUS2: 10, // to be delete
	Button_image_O_Style_H: 11,
	// High Contrast
	High_Contrast_Button_image_O_Style_E: 12, // to be delete
	High_Contrast_Button_image_O_Style_F_FOCUS1: 13, // to be delete
	High_Contrast_Button_image_O_Style_F_FOCUS2: 14, // to be delete
	High_Contrast_Button_image_O_Style_G_FOCUS1: 15, // to be delete
	High_Contrast_Button_image_O_Style_G_FOCUS2: 16, // to be delete
	High_Contrast_Button_image_O_Style_H: 17,
	Button_image_O_Style_F: 18,
	Button_image_O_Style_G: 19, // to be delete
	Button_image_X_Style_B: 20,
	Button_image_Mycontent_Option: 21,
	//add keyScreen common button,
	Button_KeyScreen_Common_ContentsBtn_StyleA:22,
	Button_KeyScreen_Common_ContentsBtn_StyleB_Text:23,
	Button_Style_Max: 24
};

var ButtonType = {
	BUTTON_TEXT: 1,
	BUTTON_ICON: 2,
	BUTTON_TEXT_ICON: 3
};

winsetButton.ButtonStyle = ButtonStyle;
winsetButton.ButtonType = ButtonType;
winsetButton.prototype = new winsetBase();

exports = winsetButton;
