(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetProgress.js";
winsetProgress = Volt.require(script_AID);

var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	Stage.show();
	//style Active_Progress_Style_B
	progress1 = new winsetProgress({
		nProgressStyle:winsetProgress.ProgressStyle.Active_Progress_Style_B,
		nResoultionStyle:1,
		width:600,
		height:20,
		id:"test"
		});
	progress1.x = 100;
	progress1.y = 100;

	progress1.value =20;
	progress1.parent = scene;
	progress1.show();	
	
	//Progress_Style_A
	progress2 = new winsetProgress({
		nProgressStyle:"0",
		nResoultionStyle:"0",
		width:"600",
		height:"20",		
	});	
	progress2.x = 100;
	progress2.y = 200;
	progress2.value =20;
	progress2.parent = scene;	
	progress2.show();		
	

//Progress_Style_B
	progress3 = new winsetProgress({
		nProgressStyle:1,
		nResoultionStyle:0,
		width:600,
		height:20,		
	});
	progress3.x = 100;
	progress3.y = 300;
	progress3.value =20;
	progress3.parent = scene;
	progress3.show();	

//Progress_Style_Timeshift
	progress4 = new winsetProgress({
		nProgressStyle:2,
		nResoultionStyle:0,
		width:600,
		height:20,		
	});
	progress4.x = 100;
	progress4.y = 400;
	progress4.value =20;
	progress4.parent = scene;	
	progress4.show();		
	
	
//Progress_Style_Recoding
	progress5 = new winsetProgress({
		nProgressStyle:3,
		nResoultionStyle:0,
		width:600,
		height:20,		
	});
	progress5.x = 100;
	progress5.y = 500;
	progress5.value =20;
	progress5.parent = scene;		
	progress5.show();
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){		
		if(progress1.value < progress1.maxValue){
			progress1.value = progress1.value + 1;		
		}
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){		
		if(progress1.value > progress1.minValue){
			progress1.value = progress1.value - 1;		
		}
		return;
	}	
	
}