(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetCheckBox.js";
winsetCheckBox = Volt.require(script_AID);
var checkbox,
	checkbox1,
	checkbox2,
	checkbox3,
	checkbox4;
	
var checkgroup = new CheckBoxGroup();

var parent = new Actor({
    parent: scene,
    width: 500,
    height: 300,
    color: {r:255, g:0, b:0, a:0}
});
parent.show();

var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	checkbox = new winsetCheckBox({
		style: "5",
		nResoultionStyle: "1",
		x: "200",
		y: "100",
		id: "test",
		parent: scene	
	});
	// checkbox.parent = parent;
	checkgroup.addButton(checkbox);
	checkbox.show();
	
	checkbox1 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_E_Focus1,
		nResoultionStyle: winsetCheckBox.ResoultionStyle.Resoultion_1080,
		x: 200,
		y: 300	
	});
	checkbox1.parent = parent;
	checkgroup.addButton(checkbox1);
	checkbox1.show();
	
	checkbox2 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_E_Focus2,
		nResoultionStyle: winsetCheckBox.ResoultionStyle.Resoultion_1080,
		x: 200,
		y: 500	
	});
	checkbox2.parent = parent;
	checkgroup.addButton(checkbox2);
	checkbox2.show();
	
	checkbox3 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_F_Normal1,
		nResoultionStyle: winsetCheckBox.ResoultionStyle.Resoultion_1080,
		x: 200,
		y: 700	
	});
	checkbox3.parent = parent;
	checkgroup.addButton(checkbox3);
	checkbox3.show();
	
	checkbox4 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_F_Normal2,
		nResoultionStyle: winsetCheckBox.ResoultionStyle.Resoultion_1080,
		x: 200,
		y: 850	
	});
	checkbox4.parent = parent;
	checkgroup.addButton(checkbox4);
	checkbox4.show();
	
	checkgroup.setDefaultSelectedItem({id:1});
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
        
        return;
    }

}
