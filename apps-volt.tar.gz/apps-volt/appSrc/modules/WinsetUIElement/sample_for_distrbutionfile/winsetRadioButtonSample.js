(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetRadioButton.js";
winsetRadioButton = Volt.require(script_AID);
var checkradio,
	checkradio1,
	checkradio2,
	checkradio3;
	
var radiobuttongroup = new RadioButtonGroup();

var parent = new Actor({
    parent: scene,
    width: 500,
    height: 300,
    color: {r:255, g:0, b:0, a:0}
});
parent.show();

var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	Stage.show();
	checkradio = new winsetRadioButton({
		style: "5",
		nResoultionStyle: "2",
		x:	"200",
		y:  "100",
		parent: scene,
		id: "test"
	});
	// checkradio.parent = parent;
	radiobuttongroup.addButton(checkradio);
	checkradio.show();
	
	checkradio1 = new winsetRadioButton({
		style: winsetRadioButton.RadioButtonStyle.Radiobutton_Style_B_Focus1,
		nResoultionStyle: winsetRadioButton.ResoultionStyle.Resoultion_1080,
		x:	200,
		y:  300	
	});
	checkradio1.parent = parent;
	radiobuttongroup.addButton(checkradio1);
	checkradio1.show();
	
	checkradio2 = new winsetRadioButton({
		style: winsetRadioButton.RadioButtonStyle.Radiobutton_Style_E_Focus1,
		nResoultionStyle: winsetRadioButton.ResoultionStyle.Resoultion_1080,
		x:	200,
		y:  500	
	});
	checkradio2.parent = parent;
	radiobuttongroup.addButton(checkradio2);
	checkradio2.show();
	
	checkradio3 = new winsetRadioButton({
		style: winsetRadioButton.RadioButtonStyle.Radiobutton_Style_E_Focus2,
		nResoultionStyle: winsetRadioButton.ResoultionStyle.Resoultion_1080,
		x:	200,
		y:  700	
	});
	checkradio3.parent = parent;
	radiobuttongroup.addButton(checkradio3);
	checkradio3.show();
	
	radiobuttongroup.setDefaultSelectedItem({id:1});
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
        
        return;
    }

}
