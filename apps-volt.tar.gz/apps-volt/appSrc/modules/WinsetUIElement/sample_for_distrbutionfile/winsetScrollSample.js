(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetScroll.js";
winsetScroll = Volt.require(script_AID);
var scroll,
	tmp,
	value = 10;
	
var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	Stage.show();
	scroll = new winsetScroll({
		x: "1200",
		y: 200,
		id: "test",
		minValue: "0",
		maxValue: 100,
		value: value,
		style: winsetScroll.ScrollStyle.Scroll_Style_C,
		nResoultionStyle: winsetScroll.ResoultionStyle.Resoultion_1080,
		parent: scene,
		height: 600
	});
	// scroll.setBackgroundColor(200, 200, 200, 51);
	// scroll.setMinValue(0);
	// scroll.setMaxValue(100);
	// scroll.setValue(value);
	// scroll.parent = scene;
	scroll.setFocus();
	scroll.show();
	tmp = scene.getChild("test");
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		if(value > 0)
		{	
			value -= 1;
			tmp.setValue(value);		
		}		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       
	   if(value < 100)
       {
			value += 1;
            tmp.setValue(value);
       }
       return;
    }
    
    if (keycode == Volt.KEY_JOYSTICK_LEFT){
       
       scroll.setFocus();
       return;
    }
    
     if (keycode == Volt.KEY_JOYSTICK_RIGHT){
       
	   scroll.killFocus();
       return;
    }

}
