(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetBackground.js";
winsetBackground = Volt.require(script_AID);
var bg;
	
var initialize = function(){
	// scene.color = {r:125,g:125,b:125,a:0};
	Stage.show();
	bg = new winsetBackground({
    	id: "test",
    	parent: scene,
		style: "1",
		bgColor: { r: 255, g: 0, b: 0, a: 255},
		nResoultionStyle: "1"
	});
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		HALOUtil.highContrast = true;
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		HALOUtil.highContrast = false;
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_DOWN){
			
		return;
	}		
}
