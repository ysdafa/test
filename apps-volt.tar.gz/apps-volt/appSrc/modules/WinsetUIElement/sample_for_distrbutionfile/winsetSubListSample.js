(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetSubList.js";
winsetSubList = Volt.require(script_AID);
var sublist,
	reload = [ { text: "AA" }, { style: 2, text: "BB" }, { style: 3, text: "CC" }, { style: 4, text: "LL" }, { style: 5, text: "OO" }, { style: 5, text: "VV" }, { style: 5, text: "EE" }, { style: 5, text: "Home" } ];
	
var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:0};
	Stage.show();
	sublist = new winsetSubList({
		x: "100",
		y: "100",
		width: 300,
    	id: "test",
    	parent: scene,
		style: "4",
		bgColor: {r: 255, g: 0, b: 0, a: 255},
		nResoultionStyle: "1",
		// itemName: ["On", "Go", "Come", "Off", "Fx", "St"],
		// items: [ { style: 1, text: "On" }, { style: 2, text: "Off" }, { style: 3, text: "Go" }, { style: 4, text: "Go" }, { style: 5, text: "Go" }, { style: 5, text: "Go" }, { style: 5, text: "Go" }, { style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },]
		items: [ { style: 1, text: "On" , bDim: true }, { style: 1, text: "Off" }, { style: 1, text: "Come" }, ]	
	});
	
	sublist.setFocus();
	sublist.x = 500;
	sublist.y = 500;
	sublist.show();
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	// sublist.onKeyEvent(keycode, keytype);
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		sublist.reload(reload);
		// sublist.show();
		// sublist.setDim(sublist.focusItemIndex);
		// print("sublist dim is " + sublist.isDim(sublist.focusItemIndex));
		print("widht is " + sublist.width);
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		// sublist.hide();
		// sublist.unDim(sublist.focusItemIndex);
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
			
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_DOWN){
			
		return;
	}		
}
