(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetPinNumberPopup.js";
winsetPinNumberPopup = Volt.require(script_AID);

var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	Stage.show();
	pinNumberPopup = new winsetPinNumberPopup({
		nResoultionStyle:1,
		nPinNumberPopupStyle:1,
		strTitleText:"PIN TITLE",
		strContentText:"this is the pin number popup",
		strInputDescriptionOne:"First Input",
		strInputDescriptionTwo:"Second Input",
		strButtonText:"cancel",
		id:"test"
	});
	pinNumberPopup.parent = scene;
	pinNumberPopup.show();
		
	var listener = new PinPopupListener;
	listener.onValidConfirm = function (list, isPassWordRight) {
	
		if (isPassWordRight == false) {
			pinNumberPopup.resetPassWord({ pintype: "pinbox_one" });
		}
	};
	pinNumberPopup.addListener(listener);	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		HALOUtil.highContrast = true;
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		HALOUtil.highContrast = false;
		return;
	}	
}