(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');


var script_AID = "modules/WinsetUIElement/winsetButton.js";
winsetButton = Volt.require(script_AID);
var button,
	button1,
	button2,
	button3,
	button4,
	button5,
	button6,
	button7,
	button8,
	button9,
	button10,
	button11;
	
var initialize = function(){
	scene.color = {r:150,g:150,b:150,a:255};
	Stage.show();
	button = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_E,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		x: 100,
		y: 100,
		text: "test",
		parent: scene,
		bHasBorder: "false",
		id: "test"
	});
	// button.parent = scene;
	
	button.show();
	
	button1 = new winsetButton({
		style: "6",
		buttonType: "2",
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: "80",
		iconWidth: "100",
		bHasBorder: "false",
		x: "500",
		y: "100"
	});
	button1.parent = scene;
	button1.show();
	
	button2 = new winsetButton({
		style: "6",
		buttonType: "3",
		text: "Test",
		height: "150",
		width: "300",
		textWidth: "100",
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: "80",
		iconWidth: "100",
		bHasBorder: "false",
		x: "800",
		y: "100"
	});
	button2.parent = scene;
	button2.show();
	
	button3 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_H,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		x: 100,
		y: 300
	});
	button3.parent = scene;
	
	button3.show();
	
	button4 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_F_FOCUS2,
		buttonType: winsetButton.ButtonType.BUTTON_ICON,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 500,
		y: 300
	});
	button4.parent = scene;
	button4.show();
	
	button5 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_F_FOCUS2,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT_ICON,
		text: "Test",
		height: 150,
		width: 300,
		textWidth: 100,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 800,
		y: 300
	});
	button5.parent = scene;
	button5.show();
	
	button6 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		x: 100,
		y: 500
	});
	button6.parent = scene;
	button6.show();
	
	button7 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
		buttonType: winsetButton.ButtonType.BUTTON_ICON,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 500,
		y: 500
	});
	button7.parent = scene;
	button7.show();
	
	button8 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT_ICON,
		text: "Test",
		height: 150,
		width: 300,
		textWidth: 100,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 800,
		y: 500
	});
	button8.parent = scene;
	button8.show();
	
	var black = new Widget({
		x: 0,
		y: 800,
		width: 1920,
		height: 200,
		color: { r: 0, g: 0, b: 0, a: 255 },
		parent: scene
	});
	// black.show();
	
	button9 = new winsetButton({
		style: winsetButton.ButtonStyle.High_Contrast_Button_image_O_Style_E,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		x: 100,
		y: 25
	});
	button9.parent = black;
	button9.show();
	
	button10 = new winsetButton({
		style: winsetButton.ButtonStyle.High_Contrast_Button_image_O_Style_F_FOCUS1,
		buttonType: winsetButton.ButtonType.BUTTON_ICON,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 500,
		y: 25
	});
	button10.parent = black;
	button10.show();
	
	button11 = new winsetButton({
		style: winsetButton.ButtonStyle.High_Contrast_Button_image_O_Style_H,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT_ICON,
		text: "Test",
		height: 150,
		width: 300,
		textWidth: 100,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 800,
		y: 25
	});
	button11.parent = black;
	button11.show();
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		button3.setFocus();
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       button3.killFocus();
        return;
    }

}
