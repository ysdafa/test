(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');


var script_AID = "modules/WinsetUIElement/winsetCategoryTab.js";
winsetCategoryTab = Volt.require(script_AID);
var category;
	
var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	Stage.show();
	category = new winsetCategoryTab({
		style: winsetCategoryTab.Categorytabtyle.Categorytab_Style_A,
		nResoultionStyle: winsetCategoryTab.ResoultionStyle.Resoultion_1080,
		y: 300,
		tabName: ["Go", "Come"]
	});
	
	category.parent = scene;
	category.show();
	
	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       
       return;
    }
    
    if (keycode == Volt.KEY_JOYSTICK_LEFT){
       
     
       return;
    }
    
     if (keycode == Volt.KEY_JOYSTICK_RIGHT){
       
	 
       return;
    }

}
