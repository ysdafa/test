(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetLoading.js";
winsetLoading = Volt.require(script_AID);
var loading;
	
var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	Stage.show();
	loading = new winsetLoading({
		x: "810",
		y: 476,
		// width: 301,
		// height: 58,
		// style: winsetLoading.LoadingStyle.Loading_Bright_20,
		style: "4",
		nResoultionStyle: winsetLoading.ResoultionStyle.Resoultion_1080,
		parent: scene,
		text: "Please Wait",
		id: "test"
	});
	
	// loading.parent = scene;
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		loading.play();	
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       
	   loading.pause();
       return;
    }
}
