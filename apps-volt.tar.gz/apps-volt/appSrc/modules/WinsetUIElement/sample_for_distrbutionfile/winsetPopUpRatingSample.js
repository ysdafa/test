(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetPopUpRating.js";
winsetPopUpRating = Volt.require(script_AID);

var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	Stage.show();
	popUpRating = new winsetPopUpRating({
		nPopUpRatingStyle:"0",
		nResoultionStyle:"1",
		id:"test",
		button1Text:"Test1",
		button2Text:"Teset2",
		buttonStyle:winsetPopUpRating.ButtonStyle.Button_image_O_Style_F_Focus1 + ""
	});
		
	popUpRating.setDefaultFocus("button_1");
	//popUpRating.setPosition(0, 200);
	popUpRating.show();
	
	var popupRatingListener = new PopupRatingListener;
	popupRatingListener.OnButtonEvent = function(popupRating, nButtonIndex, eventType){
		if ("button_clicked" == eventType &&  "button_1" == nButtonIndex){
			print("==================button_clicked====================");	
		}
	}
	popUpRating.addListener(popupRatingListener);	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	
}