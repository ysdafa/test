(function(){
    Volt.pakages = { instances: {}, modules: {} };
    Volt.BASE_PATH = 'file://';
    Volt.require = function(path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            return require(Volt.browser ? path : Volt.BASE_PATH + path);
        }
    };
})();
Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

var script_AID = "modules/WinsetUIElement/winsetToolTip.js";
winsetToolTip = Volt.require(script_AID);
var Tooltip = [];
	
var initialize = function(){
	scene.color = {r:125,g:0,b:0,a:255};
	Stage.show();
	Tooltip[0] = new winsetToolTip({
		x: "100",
		y: "100",
		width: 150,
    	height: 150,
    	id: "test",
    	parent: scene,
    	text: "Test",
		style: "1",
		nResolutionStyle: "1",
		tailPostion: "start"
	});
	// Tooltip[0].text = "NewText";
	// Tooltip[0].parent = scene;
	Tooltip[0].show();
	
	Tooltip[1] = new winsetToolTip({
		x: 350,
		y: 100,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Down,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "center"
	});
	Tooltip[1].text = "NewText";
	Tooltip[1].parent = scene;
	Tooltip[1].show();
	
	Tooltip[2] = new winsetToolTip({
		x: 600,
		y: 100,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Down,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "end"
	});
	Tooltip[2].text = "NewText";
	Tooltip[2].parent = scene;
	Tooltip[2].show();
	
	Tooltip[3] = new winsetToolTip({
		x: 100,
		y: 350,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Up,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "start"
	});
	Tooltip[3].text = "NewText";
	Tooltip[3].parent = scene;
	Tooltip[3].show();
	
	Tooltip[4] = new winsetToolTip({
		x: 350,
		y: 350,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Up,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "center"
	});
	Tooltip[4].text = "NewText";
	Tooltip[4].parent = scene;
	Tooltip[4].show();
	
	Tooltip[5] = new winsetToolTip({
		x: 600,
		y: 350,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Up,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "end"
	});
	Tooltip[5].text = "NewText";
	Tooltip[5].parent = scene;
	Tooltip[5].show();
	
	Tooltip[6] = new winsetToolTip({
		x: 100,
		y: 600,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Left,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "start"
	});
	Tooltip[6].text = "NewText";
	Tooltip[6].parent = scene;
	Tooltip[6].show();
	
	Tooltip[7] = new winsetToolTip({
		x: 350,
		y: 600,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Left,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "center"
	});
	Tooltip[7].text = "NewText";
	Tooltip[7].parent = scene;
	Tooltip[7].show();
	
	Tooltip[8] = new winsetToolTip({
		x: 600,
		y: 600,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Left,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "end"
	});
	Tooltip[8].text = "NewText";
	Tooltip[8].parent = scene;
	Tooltip[8].show();
	
	Tooltip[9] = new winsetToolTip({
		x: 100,
		y: 850,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Right,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "start"
	});
	Tooltip[9].text = "NewText";
	Tooltip[9].parent = scene;
	Tooltip[9].show();
	
	Tooltip[10] = new winsetToolTip({
		x: 350,
		y: 850,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Right,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "center"
	});
	Tooltip[10].text = "NewText";
	Tooltip[10].parent = scene;
	Tooltip[10].show();
	
	Tooltip[11] = new winsetToolTip({
		x: 600,
		y: 850,
		width: 150,
    	height: 150,
		style: winsetToolTip.TooltipStyle.Tooltip_Tail_Right,
		nResolutionStyle: winsetToolTip.ResolutionStyle.Resolution_1080,
		tailPostion: "end"
	});
	Tooltip[11].text = "NewText";
	Tooltip[11].parent = scene;
	Tooltip[11].show();	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       
       return;
    }
    
    if (keycode == Volt.KEY_JOYSTICK_LEFT){
       
     
       return;
    }
    
     if (keycode == Volt.KEY_JOYSTICK_RIGHT){
       
	 
       return;
    }

}
