/*
var PopUpRatingStyle = {
	PopUpRatingStyle_A:0,
	PopUpRatingStyle_B:1,
	PopUpRating_Style_MAX:2,
};
		
var ButtonStyle = {
		Button_image_O_Style_E: 1,
	    Button_image_O_Style_F: 2,
	    Button_Style_Max: 3
};

var BackgroudStyle = {
	BG_Style_E_1:1,
	BG_Style_E_2:2,
	BG_Style_E_3:3,
	BG_Style_Max:4
};		
*/


var script_AID = "modules/WinsetUIElement/winsetPopUpRating";
winsetPopUpRating = require(script_AID);

var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	popUpRating = new winsetPopUpRating({
		nPopUpRatingStyle:winsetPopUpRating.PopUpRatingStyle.PopUpRatingStyle_4way,
		nBackgroudStyle:winsetPopUpRating.BackgroudStyle.BG_Style_E_2,
		nbuttonStyle: winsetPopUpRating.ButtonStyle.Button_image_O_Style_F + "",		
		id:"test",
		button1Text:"Test1",
		button2Text:"Teset2",
		bgPickColor: {r:0,g:0,b:125,a:255},
		bUseHalfStar: true
		// bHighContrast:true		
	});
		
	// popUpRating.setDefaultFocus("button_1");
	//popUpRating.setPosition(0, 200);
	popUpRating.show();
	
	var popupRatingListener = new PopupRatingListener;
	popupRatingListener.OnButtonEvent = function(popupRating, nButtonIndex, eventType){
		if ("button_clicked" == eventType &&  "button_1" == nButtonIndex){
			print("==================button_clicked====================");	
		}
	}
	popUpRating.addListener(popupRatingListener);	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		HALOUtil.highContrast = true;
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		HALOUtil.highContrast = false;
		return;
	}	
}