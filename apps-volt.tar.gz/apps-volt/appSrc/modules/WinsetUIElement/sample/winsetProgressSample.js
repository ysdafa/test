/*
//style type
var ProgressStyle = {
	Progress_Style_A:0,
	Progress_Style_B:1,
	Progress_Style_Timeshift:2,
	Progress_Style_Recoding:3,
	Progress_Text_Style_A:4,
	Progress_Text_Style_B:5,
	Progress_Slider_Dial:6,
	Active_Progress_Style_A:7,
	Active_Progress_Style_B:8,		
	Progress_Style_MAX:9,
};
		
var ResoultionStyle = {
	Resoultion_720:0,	
	Resoultion_1080:1,
	Resoultion_720_21_9:2,
	Resoultion_1080_21_9:3,	
	Resoultion_Style_MAX:4,
};
*/


var script_AID = "modules/WinsetUIElement/winsetProgress";
winsetProgress = require(script_AID);

var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:0,b:0,a:255};

	//style Active_Progress_Style_B
	progress1 = new winsetProgress({
		nProgressStyle:winsetProgress.ProgressStyle.Progress_Style_A,
		nResoultionStyle:1,
		width:600,
		height:20,
		id:"test"
		});
	progress1.x = 100;
	progress1.y = 100;
	
	progress1.value = 0;
	progress1.parent = scene;
	progress1.show();	
	
	//Progress_Style_A
	progress2 = new winsetProgress({
		nProgressStyle:winsetProgress.ProgressStyle.Progress_Style_B,
		nResoultionStyle:"0",
		width:"600",
		height:"20",		
	});	
	progress2.x = 100;
	progress2.y = 200;
	progress2.value =20;
	progress2.parent = scene;	
	progress2.show();		
	

//Progress_Style_B
	progress3 = new winsetProgress({
		nProgressStyle:winsetProgress.ProgressStyle.Progress_Style_Timeshift,
		nResoultionStyle:0,
		width:600,
		height:20,		
	});
	progress3.x = 100;
	progress3.y = 300;
	progress3.value =20;
	progress3.parent = scene;
	progress3.show();	

//Progress_Style_Timeshift
	progress4 = new winsetProgress({
		nProgressStyle:winsetProgress.ProgressStyle.Progress_Style_Recoding,
		nResoultionStyle:0,
		width:600,
		height:20,		
	});
	progress4.x = 100;
	progress4.y = 400;
	progress4.value =20;
	progress4.parent = scene;	
	progress4.show();		
	
	
//Progress_Style_Recoding
	progress5 = new winsetProgress({
		nProgressStyle:winsetProgress.ProgressStyle.Progress_Slider_Dial,
		nResoultionStyle:0,
		width:600,
		height:20,		
	});
	progress5.x = 100;
	progress5.y = 500;
	progress5.value =20;
	progress5.parent = scene;		
	progress5.show();
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){		
		if(progress1.value < progress1.maxValue){
			progress1.value = progress1.value + 1;		
		}
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){		
		if(progress1.value > progress1.minValue){
			progress1.value = progress1.value - 1;		
		}
		return;
	}	
	
}