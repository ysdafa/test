var script_AID = "modules/WinsetUIElement/winsetSubList";
winsetSubList = require(script_AID);
var sublist,
	reload = [ { text: "AA" }, { style: 2, text: "BB" }, { style: 3, text: "CC" }, { style: 4, text: "LL" }, { style: 5, text: "OO" }, { style: 5, text: "VV" }, { style: 5, text: "EE" }, { style: 5, text: "Home" } ];
	
var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	
	sublist = new winsetSubList({
		x: "500",
		y: "100",
		width: 300,
    	id: "test",
    	parent: scene,
		// style: "4",
		bgColor: {r: 100, g: 0, b: 100, a: 0},
		bTextScroll: true,
		bKeyCommon: true,
		// nResoultionStyle: "1",
		// items: [ { text: "On" }],
		// items: [ { style: 1, text: "On" }, { style: 2, text: "Off" }, { style: 3, text: "Go" }, { style: 4, text: "Go" }, { style: 5, text: "Go" }, { style: 5, text: "Go" }, { style: 5, text: "Go" }, { style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },{ style: 5, text: "Go" },]
		items: [ { style: 12, text: "Onnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" , bDim: false },
		 { style: 12, text: "Offfffffffffffffffffffffffffffffff", bDim: true}, 
		 { style: 13, text: "Comerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr" }, 
		 { style: 13, text: "AA" }, 
		 { style: 13, text: "BB" }, 
		 { style: 13, text: "CC" },
		  { style: 13, text: "DD" }, 
		  { style: 13, text: "EE" }, 
		  { style: 13, text: "FF" }, 
		  { style: 13, text: "HH" } 
		  ]	
	});
	
	sublist.showFocus("false");
	sublist.setFocus();
	sublist.checkItemIndex = 1;
	// sublist.setFocus();
	// sublist.x = 100;
	// sublist.y = 100;
	// // sublist.setShowTime(5000);
	// sublist.showFocus("false");
	// sublist.show();
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	// sublist.onKeyEvent(keycode, keytype);
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		// sublist.reload(reload);
		// sublist.show();
		// sublist.setDim(sublist.focusItemIndex);
		// print("sublist dim is " + sublist.isDim(sublist.focusItemIndex));
		// print("widht is " + sublist.width);
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		// sublist.hide();
		// sublist.unDim(sublist.focusItemIndex);
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
			
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_DOWN){
			
		return;
	}
	
	if (keycode == Volt.KEY_1){
       HALOUtil.highContrast = true;
	 
       return;
    }
    
    if (keycode == Volt.KEY_2){
       HALOUtil.highContrast = false;
	 
       return;
    }
    
    if (keycode == Volt.KEY_3){
       HALOUtil.enlarge = true;
	 
       return;
    }
    
    if (keycode == Volt.KEY_4){
       HALOUtil.enlarge = false;
	 
       return;
    }
    
    if (keycode == Volt.KEY_5){
       
	 
       return;
    }	
}
