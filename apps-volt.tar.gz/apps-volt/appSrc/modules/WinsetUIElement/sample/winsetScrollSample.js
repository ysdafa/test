var script_AID = "modules/WinsetUIElement/winsetScroll";
winsetScroll = require(script_AID);
var scroll,
	tmp,
	value = 10;
	
var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	scroll = new winsetScroll({
		x: "1200",
		y: 200,
		id: "test",
		minValue: "0",
		maxValue: 100,
		value: value,
		style: winsetScroll.ScrollStyle.Scroll_Style_C,
		parent: scene,
		height: 600
	});
	
	scroll1 = new winsetScroll({
		y: 800,
		id: "test1",
		minValue: "0",
		maxValue: 100,
		value: value,
		style: winsetScroll.ScrollStyle.Scroll_Style_D,
		parent: scene
	});
	
	scroll1.setFocus();
	scroll.show();
	tmp = scene.getChild("test");
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		if(value > 0)
		{	
			value -= 1;
			tmp.setValue(value);		
		}		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       
	   if(value < 100)
       {
			value += 1;
            tmp.setValue(value);
       }
       return;
    }
    
    if (keycode == Volt.KEY_JOYSTICK_LEFT){
       
       scroll.setFocus();
       return;
    }
    
     if (keycode == Volt.KEY_JOYSTICK_RIGHT){
       
	   scroll.killFocus();
       return;
    }

}
