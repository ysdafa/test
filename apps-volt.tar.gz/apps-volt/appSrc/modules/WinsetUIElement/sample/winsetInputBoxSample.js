var script_AID = "modules/WinsetUIElement/winsetInputBox";
winsetInputBox = require(script_AID);
var input = [];
	
var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	
	input[0] = new winsetInputBox({
		x: "100",
		y: "100",
		width: 400,
    	height: 80,
    	id: "test",
    	parent: scene,
		style: "1",
		nResoultionStyle: "1"
	});
	input[0].show();
	input[0].setFocus();
	
	input[1] = new winsetInputBox({
		x: 100,
		y: 300,
		width: 400,
    	height: 120,
		style: winsetInputBox.InputBoxStyle.InputBox_Style_F_Center,
		nResoultionStyle: winsetInputBox.ResoultionStyle.Resoultion_1080,
		parent:scene
	});
	// input[1].parent = scene;
	input[1].show();
	
	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       
       return;
    }
    
    if (keycode == Volt.KEY_JOYSTICK_LEFT){
       
     
       return;
    }
    
     if (keycode == Volt.KEY_JOYSTICK_RIGHT){
       
	 
       return;
    }

}
