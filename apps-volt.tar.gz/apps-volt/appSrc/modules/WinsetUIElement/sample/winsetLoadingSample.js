var script_AID = "modules/WinsetUIElement/winsetLoading";
winsetLoading = require(script_AID);
var loading;
	
var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	loading = new winsetLoading({
		x: "810",
		y: 476,
		// width: 301,
		// height: 58,
		// style: winsetLoading.LoadingStyle.Loading_Bright_20,
		style: "4",
		nResoultionStyle: winsetLoading.ResoultionStyle.Resoultion_1080,
		parent: scene,
		text: "Please Wait",
		id: "test"
	});
	
	// loading.parent = scene;
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		loading.play();	
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       
	   loading.pause();
       return;
    }
}
