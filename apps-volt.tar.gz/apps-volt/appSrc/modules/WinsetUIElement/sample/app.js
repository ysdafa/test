var script_AID = "modules/WinsetUIElement/winsetButton";
var winsetButton = require(script_AID);
var button,
	button1,
	button2,
	button3,
	button4,
	button5,
	button6,
	button7,
	button8,
	button9,
	button10,
	button11;
	
var initialize = function(){
	Stage.show();
	scene.color = {r: 10, g: 35, b: 61, a:255};
	button = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_Mycontent_Option,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/obe_navi_arrow_l_f.png",
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		iconHeight: "134",
		iconWidth: "134",
		x: 100,
		y: 100,
		text: "test",
		parent: scene,
		bHasBorder: false,
		id: "test"
	});
	// button.parent = scene;
	
	button.show();
	
	button1 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_X_Style_B,
		// buttonType: "2",
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/obe_navi_arrow_l_d.png",
		iconFocusImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/obe_navi_arrow_l_f.png",
		iconHeight: "134",
		iconWidth: "134",
		// bHasBorder: true,
		x: "500",
		y: "100"
	});
	button1.parent = scene;
	button1.show();
	
	button2 = new winsetButton({
		style: "20",
		buttonType: "3",
		text: "Test",
		height: "150",
		width: "300",
		textWidth: "100",
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/obe_navi_arrow_l_f.png",
		iconHeight: "134",
		iconWidth: "134",
		x: "800",
		y: "100"
	});
	button2.parent = scene;
	button2.show();
	
	//common button Style A
	button3 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		bHasBorder: true,
		x: 100,
		y: 300,
		text : "test ok"
	});
	button3.parent = scene;
	//button3.enable(false);
	button3.show();
	
	//common button Style A
	button4 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA,
		buttonType: winsetButton.ButtonType.BUTTON_ICON,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		bHasBorder: "true",
		x: 500,
		y: 300
	});
	button4.parent = scene;
	//button4.enable(false);
	button4.show();
	
	button5 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_E,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT_ICON,
		text: "Test",
		height: 150,
		width: 300,
		textWidth: 100,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 800,
		y: 300
	});
	button5.parent = scene;
	button5.show();
	
	button6 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_F,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		x: 100,
		y: 500
	});
	button6.parent = scene;
	button6.show();
	
	button7 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_F,
		buttonType: winsetButton.ButtonType.BUTTON_ICON,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 500,
		y: 500
	});
	button7.parent = scene;
	button7.show();
	
	button8 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_F,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT_ICON,
		text: "Test",
		height: 150,
		width: 300,
		textWidth: 100,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 800,
		y: 500
	});
	button8.parent = scene;
	button8.show();
	
	var black = new Widget({
		x: 0,
		y: 800,
		width: 1920,
		height: 200,
		color: { r: 0, g: 0, b: 0, a: 0 },
		parent: scene
	});
	// black.show();
	
	button9 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_H,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		height: 150,
		width: 250,
		x: 100,
		y: 25
	});
	button9.parent = black;
	button9.show();
	
	button10 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_H,
		buttonType: winsetButton.ButtonType.BUTTON_ICON,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 500,
		y: 25
	});
	button10.parent = black;
	button10.show();
	
	button11 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_H,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT_ICON,
		text: "Test",
		height: 150,
		width: 300,
		textWidth: 100,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 800,
		y: 25
	});
	button11.parent = black;
	button11.show();
	
	/*	//common button Style B
	button12 = new winsetButton({
		style: winsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text,
		buttonType: winsetButton.ButtonType.BUTTON_TEXT,
		text: "test OK?",
		height: 150,
		width: 250,
		x: 1200,
		y: 25
	});
	button12.parent = black;
	//button12.enable(false);
	button12.show();
	*/
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		button3.setFocus();
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       button3.killFocus();
        return;
    }

    if (keycode == Volt.KEY_8) {
        print('[app.js @onKeyEvent] gc()');
        gc();
    } else if (keycode == Volt.KEY_5) {
        print('[app.js @onKeyEvent] VDUtil.heapSnapshot()');
        gc();
        VDUtil.heapSnapshot();
    }

}
