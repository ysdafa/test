var script_AID = "modules/WinsetUIElement/winsetMessageBox";
winsetMessageBox = require(script_AID);
var box = [],
	focus,
	index = 0;

// listener
var messageBox1Listener = new MessageBoxListener;
messageBox1Listener.OnButtonEvent = function(messagebox, nButtonIndex, eventType){
	if ("button_clicked" == eventType &&  "button_1" == nButtonIndex ){
        messagebox.titleText = "Test";
        messagebox.contentText = "You have enter OK : ) ";
	}
	
	if ("button_clicked" == eventType &&  "button_2" == nButtonIndex ){
        messagebox.titleText = "Test";
        messagebox.contentText = "You have enter Cancel : ) ";
	}
};
	
var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	box[0] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_Title_Button_2_8Line,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
		bgPickColor: {r: 255, g: 255, b: 0, a: 200},
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_E_2,
		button1Text: "AA",
		button2Text: "BB",
		contentText: "Test Popup Message Popup Message Popup Message Popup Message Popup Message Test Popup Message Popup Message Popup Message Popup Message Popup Message Test Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[0].parent = scene;
	box[0].show();
	focus = box[0];
	box[0].setDefaultFocus("button_1");
	box[0].addListener(messageBox1Listener);
	
	box[1] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_Title_Button_2_8Line,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_E,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
		contentText: "Test Popup Message Popup Message Popup Message Popup Message Popup Message Test Popup Message Popup Message Popup Message Popup Message Popup Message Test Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup Message  contentText:Test Popup Message Popup Message Popup Message Popup Message Popup Message Test Popup Message Popup Message Popup Message Popup Message Popup Message Test Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup MessageTest Popup Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[1].parent = scene;
	box[1].hide();
	//box[1].setDefaultFocus("button_1");
	
	box[2] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_1Line,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_Style_B_Focus2,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_3
	});
	box[2].parent = scene;
	box[2].hide();
	// box[2].setDefaultFocus("button_1");
	
	box[3] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_Style_B_Focus1,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		// contextLineNumber: 4
	});
	box[3].parent = scene;
	box[3].hide();
	// box[3].setDefaultFocus("button_1");
	
	box[4] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_Message_Text_Align,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_Style_B_Focus1,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		// contextLineNumber: 4
	});
	box[4].parent = scene;
	box[4].hide();
	// box[4].setDefaultFocus("button_1");
	
	box[5] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_NoButton,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		// contextLineNumber: 4
	});
	box[5].parent = scene;
	box[5].hide();
	
	box[6] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_1Line,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1
	});
	box[6].parent = scene;
	box[6].hide();
	
	box[7] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_1Line_Loading,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		contentText : "Test Popup Message Popup Message Popup Message"
	});
	box[7].parent = scene;
	box[7].hide();	
	
	box[8] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_2Line_Loading,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		contentText: "Test Popup Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[8].parent = scene;
	box[8].hide();	
	
	box[10] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_E,
		// contextLineNumber: 5,
		contentText: "Test Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[10].parent = scene;
	box[10].hide();
	
	box[9] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_3Line_Loading,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		// contextLineNumber: 5,
		contentText: "Test Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[9].parent = scene;
	box[9].hide();	
	
	box[11] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.High_Contrast_MessageBox_Title_Button_2_8Line,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_E,
		// contextLineNumber: 5,
		parent:scene,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		contentText: "Test Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[11].hide();	
	
	box[12] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.High_Contrast_MessageBox_NoTitle_Button_2_8Line,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		// contextLineNumber: 5,
		parent:scene,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_E,
		contentText: "Test Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[12].hide();	
	
	box[13] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.High_Contrast_MessageBox_NoTitle_NoButton,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		// contextLineNumber: 5,
		parent:scene,
		contentText: "Test Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[13].hide();
	
	box[14] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.High_Contrast_MessageBox_1Line,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		// contextLineNumber: 5,
		parent:scene,
		contentText: "Test Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message"
	});
	box[14].hide();
	
	box[15] = new winsetMessageBox({
		style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_Three_Button,
		nResoultionStyle: winsetMessageBox.ResoultionStyle.Resoultion_1080,
		bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_1,
		buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_E,
		// contextLineNumber: 5,
		parent:scene,
		contentText: "Three Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup Message Popup Message Popup Message Popup Message Message Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup MessageMessage Popup Message Popup Message"
	});
	box[15].hide();	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_1){
		index = 0;
		focus.hide();
		focus = box[0];
		box[0].show();
		return;
	}	

    if (keycode == Volt.KEY_2){
    	index = 1;
       	focus.hide();
		focus = box[1];
		box[1].show();
        return;
    }
    
    if (keycode == Volt.KEY_3){
    	index = 2;
		focus.hide();
		focus = box[2];
		box[2].show();
		return;
	}	

    if (keycode == Volt.KEY_4){
    	index = 3;
       	focus.hide();
		focus = box[3];
		box[3].show();
        return;
    }
    
    if (keycode == Volt.KEY_5){
    	index = 4;
		focus.hide();
		focus = box[4];
		box[4].show();
		return;
	}	

    if (keycode == Volt.KEY_6){
    	index = 5;
       	focus.hide();
		focus = box[5];
		box[5].show();
        return;
    }
    
    if (keycode == Volt.KEY_7){
    	index = 6;
		focus.hide();
		focus = box[6];
		box[6].show();
		return;
	}
	
	if (keycode == Volt.KEY_8){
		index = 7;
		focus.hide();
		focus = box[7];
		box[7].show();
		return;
	}	
	
	if (keycode == Volt.KEY_9){
		index = 8;
		focus.hide();
		focus = box[8];
		box[8].show();
		return;
	}	
	
	if (keycode == Volt.KEY_0){
		index = 9;
		focus.hide();
		focus = box[9];
		box[9].show();
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		box[index].hide();
		index = (index + 1)%16;
		box[index].show();
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_DOWN){
		box[index].hide();
		index = Math.abs((index + 15)%16);
		box[index].show();
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		HALOUtil.highContrast = true;
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		HALOUtil.highContrast = false;
		return;
	}			
}
