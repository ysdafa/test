var script_AID = "modules/WinsetUIElement/winsetCheckBox";
winsetCheckBox = require(script_AID);
var checkbox,
	checkbox1,
	checkbox2,
	checkbox3,
	checkbox4,
	checkbox5,
	checkbox6;
	
var checkgroup = new CheckBoxGroup();

var parent = new Actor({
    parent: scene,
    width: 500,
    height: 300,
    color: {r:255, g:0, b:0, a:0}
});
parent.show();

var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	
	checkbox1 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_D,
		x: 200,
		y: 0	
	});
	checkbox1.parent = scene;
	checkgroup.addButton(checkbox1);
	checkbox1.show();
	
	checkbox2 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_E,
		x: 200,
		y: 100	
	});
	checkbox2.parent = scene;
	checkgroup.addButton(checkbox2);
	checkbox2.show();
	
	checkbox3 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_F_Wizard_Sub_Popup,
		x: 200,
		y: 200	
	});
	checkbox3.parent = scene;
	checkgroup.addButton(checkbox3);
	checkbox3.show();
	
	checkbox4 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_F_TV_and_Smart_Hub_Sub_Popup,
		x: 200,
		y: 300	
	});
	checkbox4.parent = scene;
	checkgroup.addButton(checkbox4);
	checkbox4.show();
	
	checkbox5 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_D_Default,
		x: 200,
		y: 400	
	});
	checkbox5.parent = scene;
	checkgroup.addButton(checkbox5);
	checkbox5.show();
	
	checkbox6 = new winsetCheckBox({
		style: winsetCheckBox.CheckBoxStyle.Checkbox_Style_E_Default,
		x: 200,
		y: 500	
	});
	checkbox6.parent = scene;
	checkgroup.addButton(checkbox6);
	checkbox6.show();
	// checkgroup.setDefaultSelectedItem({id:1});
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
        
        return;
    }

}
