var script_AID = "modules/WinsetUIElement/winsetCategoryTab";
winsetCategoryTab = require(script_AID);
var category;
var button;
var script_AID1 = "modules/WinsetUIElement/winsetButton";
winsetButton = require(script_AID1);
	
var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	
	category = new winsetCategoryTab({
		style: winsetCategoryTab.Categorytabtyle.Categorytab_Style_A,
		nResoultionStyle: winsetCategoryTab.ResoultionStyle.Resoultion_1080,
		width:1920,
		// height: 300,
		unFocusHighlightbarHeight: 2,
		focusHighlightbarHeight: 108,
		y: 300,
		height: 72,
		bUseFocus: false,
		// tabName: ["Go", "Come", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "BBBBBBBBBBBBBBBBBBBBBVVVVVVVVVVVVVV", "CCCCCCCCCCCCCCCVVVVVVVVVVVVVVVVVVVVV", "Go", "Go", "Go", "Go", "Go",]
	});
	
	category.parent = scene;
	category.addTab("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
	category.addTab("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB");
	category.show();
	category.changeTab(0);
	
	button = new winsetButton({
		style: winsetButton.ButtonStyle.Button_image_O_Style_F,
		buttonType: winsetButton.ButtonType.BUTTON_ICON,
		iconImgSrc: "$VOLT_ROOT/modules/modules/WinsetUIElement/winsetImg/1080p/btn/popup_btn_arrow_left_f.png",
		iconHeight: 80,
		iconWidth: 100,
		x: 500,
		y: 500
	});
	button.parent = scene;
	button.show();
	button.setFocus();
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		category.killFocus();
		button.setFocus();
		category.height = 72;
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
       button.killFocus();
       category.setFocus();
       
       category.animate('height', 108, 2000);
       return;
    }
    
    if (keycode == Volt.KEY_JOYSTICK_LEFT){
       
       return;
    }
    
    if (keycode == Volt.KEY_JOYSTICK_RIGHT){
       
	 
       return;
    }
	
	if (keycode == Volt.KEY_1){
       HALOUtil.highContrast = true;
	 
       return;
    }
    
    if (keycode == Volt.KEY_2){
       HALOUtil.highContrast = false;
	 
       return;
    }
    
    if (keycode == Volt.KEY_3){
       HALOUtil.enlarge = true;
	 
       return;
    }
    
    if (keycode == Volt.KEY_4){
       HALOUtil.enlarge = false;
	 
       return;
    }
    
    if (keycode == Volt.KEY_5){
       
	 
       return;
    }
	
}
