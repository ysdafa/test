/*
//style type
var PinNumberPopupStyle = {
	PinNumberPopupStyle_NoButton:0,
	PinNumberPopupStyle_WithButton:1,
	PinNumberPopupStyle_MAX:2,
};

var ButtonStyle = {
		Button_image_O_Style_E: 1,
	    Button_image_O_Style_F: 2,
	    Button_Style_Max: 3
};

var BackgroudStyle = {
	BG_Style_E_1:1,
	BG_Style_E_2:2,
	BG_Style_E_3:3,
	BG_Style_Max:4
};		
		
		
*/

var script_AID = "modules/WinsetUIElement/winsetPinNumberPopup";
winsetPinNumberPopup = require(script_AID);

var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	pinNumberPopup = new winsetPinNumberPopup({
		nPinNumberPopupStyle:winsetPinNumberPopup.PinNumberPopupStyle.PinNumberPopupStyle_One_Pin_WithButton,
		nBackgroudStyle:winsetPinNumberPopup.BackgroudStyle.BG_Style_E_1,
		nbuttonStyle: winsetPinNumberPopup.ButtonStyle.Button_image_O_Style_F,
		strTitleText:"PIN TITLE",
		strContentText:"this is the pin number popup",
		strInputDescriptionOne:"First Input",
		strInputDescriptionTwo:"Second Input",
		strButtonText:"Cancel",
		id:"test"
	});
	pinNumberPopup.parent = scene;
	pinNumberPopup.show();
		
	var listener = new PinPopupListener;
	listener.onValidConfirm = function (list, isPassWordRight) {
	
		if (isPassWordRight == false) {
			pinNumberPopup.resetPassWord({ pintype: "pinbox_one" });
		}
	};
	pinNumberPopup.addListener(listener);	
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		HALOUtil.highContrast = true;
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		HALOUtil.highContrast = false;
		return;
	}	
}