var script_AID = "modules/WinsetUIElement/winsetBackground";
winsetBackground = require(script_AID);
var bg;
	
var initialize = function(){
	scene.color = {r:125,g:125,b:125,a:255};
	// HALOUtil.highContrast = true;
	
	print("bHighContrast is " + HALOUtil.highContrast);
	Stage.show();
	bg = new winsetBackground({
		y: 100,
    	id: "test",
    	parent: scene,
		// style: "1",
		// bgHighContrastColor: { r: 0, g: 0, b: 255, a: 255 },
		bgColor: { r: 255, g: 0, b: 0, a: 255},
		height: 600
	});
	
	// bg.setBackgroundColor({ r: 255, g: 0, b: 0, a: 255 });
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	
	if (keycode == Volt.KEY_JOYSTICK_LEFT){
		HALOUtil.highContrast = true;
		print("HALOUtil.highContrast is " + HALOUtil.highContrast);
		return;
	}
	
	if (keycode == Volt.KEY_JOYSTICK_RIGHT){
		HALOUtil.highContrast = false;
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_DOWN){
			
		return;
	}		
}
