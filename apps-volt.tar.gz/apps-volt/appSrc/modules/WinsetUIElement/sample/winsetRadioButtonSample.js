var script_AID = "modules/WinsetUIElement/winsetRadioButton";
winsetRadioButton = require(script_AID);
var checkradio,
	checkradio1,
	checkradio2,
	checkradio3;
	
var radiobuttongroup = new RadioButtonGroup();

var parent = new Actor({
    parent: scene,
    width: 500,
    height: 300,
    color: {r:255, g:0, b:0, a:0}
});
parent.show();

var initialize = function(){
	Stage.show();
	scene.color = {r:125,g:125,b:125,a:255};
	
	checkradio1 = new winsetRadioButton({
		style: winsetRadioButton.RadioButtonStyle.Radiobutton_Style_D,
		nResoultionStyle: winsetRadioButton.ResoultionStyle.Resoultion_1080,
		x:	200,
		y:  300	
	});
	checkradio1.parent = parent;
	radiobuttongroup.addButton(checkradio1);
	checkradio1.show();
	
	checkradio2 = new winsetRadioButton({
		style: winsetRadioButton.RadioButtonStyle.Radiobutton_Style_E,
		nResoultionStyle: winsetRadioButton.ResoultionStyle.Resoultion_1080,
		x:	200,
		y:  500	
	});
	checkradio2.parent = parent;
	radiobuttongroup.addButton(checkradio2);
	checkradio2.show();
	
	
	checkradio3 = new winsetRadioButton({
		style: winsetRadioButton.RadioButtonStyle.Radiobutton_Style_D_Checked,
		nResoultionStyle: winsetRadioButton.ResoultionStyle.Resoultion_1080,
		x:	200,
		y:  700	
	});
	checkradio3.parent = parent;
	radiobuttongroup.addButton(checkradio3);
	checkradio3.show();
	
	checkradio = new winsetRadioButton({
		style: winsetRadioButton.RadioButtonStyle.Radiobutton_Style_E_Checked,
		nResoultionStyle: winsetRadioButton.ResoultionStyle.Resoultion_1080,
		x:	200,
		y:  900	
	});
	checkradio.parent = parent;
	radiobuttongroup.addButton(checkradio);
	checkradio.show();
	// radiobuttongroup.setDefaultSelectedItem({id:1});
}

function onKeyEvent(keycode, keytype){	
	if (keytype == Volt.EVENT_KEY_RELEASE){
		return;
	}	
	
	if (keycode == Volt.KEY_JOYSTICK_UP){
		
		return;
	}	

    if (keycode == Volt.KEY_JOYSTICK_DOWN){
        
        return;
    }

}
