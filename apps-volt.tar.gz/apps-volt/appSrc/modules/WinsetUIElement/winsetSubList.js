var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetSubList = function(obj) {
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;

	// local var
	var sublist,

		id = null,
		dataSourceArray = [],
		itemName = [],
		itemNumber = 0,
		showNumber = 5,
		items,
		// style = SubListStyle.SubList_Style_WIZARD_SUB_POPUP,
		resolution = ResolutionStyle.Resolution_1080,
		parent = scene,
		imagePath = "modules/WinsetUIElement/winsetImg/",	
		
		screenWidth = 1920,
		screenHeight = 1080,
		x = 0,
		y = 0,		
		sublistWidth = 300,
		singleListHeight = 300,
		sublistHorizontalMargin = 2, // 0.001042 * 1920
		sublisVerticalMargin = 2, // 0.001852 * 1080
		itemWidth = -1,
		itemHeight = -1,
		
		//item BG
		// itemNormalBgColor = { r: 0, g: 0, b: 0, a:0 },
		// itemFocusBgColor = { r: 33, g: 158, b: 232, a:255 },
		// itemNormalBgOpacity = 0.05*255,
		// itemFocusBgOpacity = 0.95*255,		

		//item text	
		itemTextX = 0.028646 * screenWidth,
		itemTextY = 0,
		itemTextWidth = itemWidth - (0.028646 + 0.006250) * screenWidth,
		itemTextHeight = itemHeight,
		
		itemTextNormalColor, 
		itemTextFocusedColor,
		itemTextSelectedColor, 
		itemTextDimColor,	
		
		// itemNormalFontOpacity = 0.6 * 255,
		// itemFocusFontOpacity = 255,
		// itemSeletedFontOpacity = 255,
		// itemDimFontOpacity = 0.1 * 255,
				
		itemTextNormalFont,
		itemTextFocusFont,
		itemTextSelectedFont,
		itemTextMouseFocusedFont,
		itemTextDimFont,	
		
		//check box
		itemHasCheckBox = false,
		itemCheckBoxNormalImg = imagePath + "check/popup_sub_check_icon.png",
		itemCheckBoxFocusImg = imagePath + "check/popup_sub_check_icon_f.png",
		itemCheckBoxSelectedImg = imagePath + "check/popup_sub_check_icon_s.png",
		itemCheckBoxDimImg = imagePath + "check/popup_sub_check_icon_n.png",
		
		itemCheckBoxX = 0.003125 * screenWidth,
		itemCheckBoxY = (itemHeight - 40) / 2,
		itemCheckBoxWidth = 40,
		itemCheckBoxHeight = 40,
		
		//left arrow
		itemHasLeftArrow = false,
		itemLeftArrowNormalImg = imagePath + "sublist/list_arrow_c_left.png",
		itemLeftArrowFocusImg = imagePath + "sublist/list_arrow_c_left_f.png",
		itemLeftArrowSelectedImg = imagePath + "sublist/list_arrow_c_left_s.png",
		itemLeftArrowDimImg = imagePath + "sublist/list_arrow_c_left.png",
		
		itemLeftArrowWidth = 40,
		itemLeftArrowHeight = 40,
		itemLeftArrowX = 0.003125 * screenWidth,
		itemLeftArrowY = (itemHeight - itemLeftArrowHeight)/2,
		
		//right arrow
		itemHasRightArrow = false,
		itemRightArrowNormalImg = imagePath + "sublist/list_arrow_c_right.png",
		itemRightArrowFocusImg = imagePath + "sublist/list_arrow_c_right_f.png",
		itemRightArrowSelectedImg = imagePath + "sublist/list_arrow_c_right_s.png",
		itemRightArrowDimImg = imagePath + "sublist/list_arrow_c_right.png",
		
		itemRightArrowNormalOpacity = 255,
		itemRightArrowDimOpacity = 0.1*255,

		itemRightArrowWidth = 40,
		itemRightArrowHeight = 40,
		itemRightArrowX = itemWidth - 0.003125 * screenWidth - itemRightArrowWidth,
		itemRightArrowY = (itemHeight - itemRightArrowHeight)/2,
		
		// background color
		bg,
		bg1,
		bg2,
		bgHeight,
		bgWidth,
		bgColor = null,
		pressed = false,
		
		// arrow
		bShowArrow = false,
		upArrow,
		downArrow,
		arrowWidth,
		arrowHeight,
		// text
		bTextScroll = true,
		textScrollAttr = {
			duration: 5000,
			speed: 0.06,
			delay: 10,
			repeat: -1,
			type: "continue_scroll",
			direction: "backward",
			continueGap: 0
		},
		
		bKeyCommon = false,
		bgStyle,
		itemGap,
		bHighContrast = false,
		bEnlarge = false,
		dataList = [];
		 
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number" || typeof objParameter.style == "string")){
				
				if(typeof objParameter.style == "string"){
					style = parseInt(objParameter.style);
				}else{
					style = objParameter.style;	
				}
				
				if((1 > style) || (SubListStyle.SubList_Style_Max <= style)){
					style = 1;
				}
			}
			
			if (objParameter.hasOwnProperty("nResolutionStyle") 
				&& (typeof objParameter.nResolutionStyle == "number" || typeof objParameter.nResolutionStyle == "string")){
					if(typeof objParameter.nResolutionStyle == "string"){
						resolution = parseInt(objParameter.nResolutionStyle);
					}else{
						resolution = objParameter.nResolutionStyle;
					}
				
				if((ResolutionStyle.Resolution_720 > resolution) || (ResolutionStyle.Resolution_Style_MAX <= resolution)){
					resolution = ResolutionStyle.Resolution_1080;
				}
					
			}
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
				if(typeof objParameter.x == "string"){
					x = parseInt(objParameter.x);	
				}else{
					x = objParameter.x;	
				} 
				
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					y = parseInt(objParameter.y);	
				}else{
					y = objParameter.y;	
				}
			}	
			
			// if(objParameter.hasOwnProperty("width")
				// && (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
				// if(typeof objParameter.width == "string"){
					// var tmpWidth = parseInt(objParameter.width);
					// sublistWidth = tmpWidth;
					// itemWidth = tmpWidth;
				// }else{
					// sublistWidth = objParameter.width;
					// itemWidth = objParameter.width;
				// }
			// }
// 			
			// if(objParameter.hasOwnProperty("height")
				// && (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
				// if(typeof objParameter.height == "string"){
					// singleListHeight = parseInt(objParameter.height);
				// }else{
					// singleListHeight = objParameter.height;
				// }			
			// }
			
			if(objParameter.hasOwnProperty("itemWidth")
				&& (typeof objParameter.itemWidth == "number" || typeof objParameter.itemWidth == "string")){
				if(typeof objParameter.itemWidth == "string"){
					itemWidth = parseInt(objParameter.itemWidth);
				}else{
					itemWidth = objParameter.itemWidth;
				}
			}
			
			if(objParameter.hasOwnProperty("itemHeight")
				&& (typeof objParameter.itemHeight == "number" || typeof objParameter.itemHeight == "string")){
				if(typeof objParameter.itemHeight == "string"){
					itemHeight = parseInt(objParameter.itemHeight);
				}else{
					itemHeight = objParameter.itemHeight;
				}			
			}
			
			if(objParameter.hasOwnProperty("showNumber")
				&& (typeof objParameter.showNumber == "number" || typeof objParameter.showNumber == "string")){
				if(typeof objParameter.showNumber == "string"){
					showNumber = parseInt(objParameter.showNumber);
				}else{
					showNumber = objParameter.showNumber;
				}			
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
			
		
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
			
			
			// if(objParameter.hasOwnProperty("itemName")
				// && (Object.prototype.toString.call(objParameter.itemName) === "[object Array]")){
				// if(5 <= objParameter.itemName.length){
					// for(var i = 0; i < 5; i++){
						// itemName[i] = objParameter.itemName[i];
						// itemNumber = 5;
					// }
				// }
// 				
				// if(5 > objParameter.itemName.length && 0 < objParameter.itemName.length){
					// for(var i = 0; i < objParameter.itemName.length; i++){
						// itemName[i] = objParameter.itemName[i];
						// itemNumber = objParameter.itemName.length;
					// }
				// }
			// }
			
			if(objParameter.hasOwnProperty("items")
				&& (Object.prototype.toString.call(objParameter.items) === "[object Array]")){
				items = objParameter.items;
				itemNumber = objParameter.items.length;
			}
			
			if(objParameter.hasOwnProperty("bgColor")
				&& (typeof objParameter.bgColor == "object")){
				bgColor = objParameter.bgColor;	
			}
			
			if(objParameter.hasOwnProperty("bTextScroll")
				&& (typeof objParameter.bTextScroll == "boolean" || typeof objParameter.bTextScroll == "string")){
				if(typeof objParameter.bTextScroll == "string"){
					if("true" == objParameter.bTextScroll){
						bTextScroll = true;
					}else if("false" == objParameter.bTextScroll){
						bTextScroll = false;
					}
				}else{
					bTextScroll = objParameter.bTextScroll;
				}	
			}
			
			if(objParameter.hasOwnProperty("textScrollAttr")
				&& (typeof objParameter.textScrollAttr == "object")){
			
				if(objParameter.textScrollAttr.hasOwnProperty("duration")){
					textScrollAttr.duration = objParameter.textScrollAttr.duration;
				}
			
				if(objParameter.textScrollAttr.hasOwnProperty("speed")){
					textScrollAttr.speed = objParameter.textScrollAttr.speed;
				}
				
				if(objParameter.textScrollAttr.hasOwnProperty("delay")){
					textScrollAttr.delay = objParameter.textScrollAttr.delay;
				}
				
				if(objParameter.textScrollAttr.hasOwnProperty("repeat")){
					textScrollAttr.repeat = objParameter.textScrollAttr.repeat;
				}
				
				if(objParameter.textScrollAttr.hasOwnProperty("type")){
					textScrollAttr.scrollType = objParameter.textScrollAttr.scrollType;
				}
				
				if(objParameter.textScrollAttr.hasOwnProperty("direction")){
					textScrollAttr.direction = objParameter.textScrollAttr.direction;
				}
				
				if(objParameter.textScrollAttr.hasOwnProperty("continueGap")){
					textScrollAttr.continueGap = objParameter.textScrollAttr.continueGap;
				}
			}
			
			if(objParameter.hasOwnProperty("bKeyCommon")
				&& (typeof objParameter.bKeyCommon == "boolean" || typeof objParameter.bKeyCommon == "string")){
				if(typeof objParameter.bKeyCommon == "string"){
					if("true" == objParameter.bKeyCommon){
						bKeyCommon = true;
					}else if("false" == objParameter.bKeyCommon){
						bKeyCommon = false;
					}
				}else{
					bKeyCommon = objParameter.bKeyCommon;
				}	
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		//common attributes	
		if(false == bTextScroll){
			textScrollAttr = { speed: 0 };
		}
		
		screenWidth = 1920;
		screenHeight = 1080;
		
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			imagePath = imagePath + "1080p/";	
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			imagePath = imagePath + "720p/";
		}
		
		if(false == bKeyCommon){
			if(itemNumber > showNumber){
				bShowArrow = true;
			}
			
			if(-1 == itemHeight){
				itemHeight = 0.064815 * screenHeight;
			}
			if(-1 == itemWidth){
				itemWidth = 300;
			}
			
			if(true == bShowArrow){
				singleListHeight = showNumber * itemHeight + (showNumber - 1) * 0.001852 * screenHeight;
				bgHeight = 2 * 0.001852 * screenHeight + 2 * 0.055556 * screenHeight + singleListHeight;
			}else{
				singleListHeight = itemNumber * itemHeight + (itemNumber - 1) * 0.001852 * screenHeight;
				bgHeight = 2 * 0.001852 * screenHeight + singleListHeight;
			}
			
			bgWidth = itemWidth + 2 * 0.001042 * screenWidth;
			// itemTextNormalFont = "SamsungSmart_Medium 30px";
			// itemTextFocusFont = "SamsungSmart_Medium 36px";
			// itemTextSelectedFont = "SamsungSmart_Medium 36px";
			// itemTextDimFont = "SamsungSmart_Medium 30px";
// 	
			// //check box			
			// itemCheckBoxWidth = 40;
			// itemCheckBoxHeight = 40;
// 			
			// //left arrow	
			// itemLeftArrowWidth = 40;
			// itemLeftArrowHeight = 40;		
// 	
			// //right arrow
			// itemRightArrowWidth = 40;
			// itemRightArrowHeight = 40;
			
			arrowWidth = 282;
			arrowHeight = 60;
			
			sublistHorizontalMargin =  0.001042 * screenWidth;
			sublisVerticalMargin = 0.001852 * screenHeight; 					
			sublistWidth = sublistWidth + sublisVerticalMargin * 2; 
			
			// itemHeight = 0.064815 * screenHeight;
			
			textScrollAttr.continueGap = 0.020833 * screenWidth;
			
			itemGap = 0.001852 * screenHeight;
			
			bgStyle = BackgroundStyle.BG_Style_E_4_5;
		}else{
			showNumber = itemNumber; 
			
			itemGap = 0;
			
			if(-1 == itemHeight){
				itemHeight = 0.066667 * screenHeight;
			}
			
			if(-1 == itemWidth){
				itemWidth = 0.160417 * screenWidth;
			}
			bgWidth = itemWidth + 2;
			
			singleListHeight = itemHeight * itemNumber;
			bgHeight = 2 + singleListHeight;
			
			textScrollAttr.continueGap = 0.020833 * screenWidth;
			bgStyle = BackgroundStyle.BG_Style_Key_Common;
		}
		
		
		
		//common attributes	 <item text>	
		// itemTextY = 0;
		// itemTextHeight = itemHeight;
		
		//common attributes	<check box>
		// itemCheckBoxX = 0.003125 * screenWidth;
		// itemCheckBoxY = (itemHeight - itemCheckBoxHeight)/2;
		
		//common attributes	<left arrow>
		// itemLeftArrowX = 0.003125 * screenWidth;
		// itemLeftArrowY = (itemHeight - itemLeftArrowHeight)/2;	
		// itemLeftArrowNormalOpacity = 255;
		// itemLeftArrowDimOpacity = 0.1*255;
		
		//common attributes	<right arrow>
		// itemRightArrowX = itemWidth - 0.003125 * screenWidth - itemRightArrowWidth;
		// itemRightArrowY = (itemHeight - itemRightArrowHeight)/2;			
		// itemRightArrowNormalOpacity = 255;
		// itemRightArrowDimOpacity = 0.1*255;
		
		itemCheckBoxX = 0.003125 * screenWidth;
		itemCheckBoxY = (itemHeight - 40) / 2;
		
		itemLeftArrowWidth = 40;
		itemLeftArrowHeight = 40;
		itemLeftArrowX = 0.003125 * screenWidth;
		itemLeftArrowY = (itemHeight - itemLeftArrowHeight) / 2;
		
		itemRightArrowWidth = 40;
		itemRightArrowHeight = 40;
		itemRightArrowX = itemWidth - 0.003125 * screenWidth - itemRightArrowWidth;
		itemRightArrowY = (itemHeight - itemRightArrowHeight) / 2;
		
		bHighContrast = HALOUtil.highContrast;
		bEnlarge = HALOUtil.enlarge;
	}

	var setItemStyleValue = function(obj, data){
		// style
		if(!obj.hasOwnProperty("style")){
			obj.style = SubListStyle.SubList_Style_TEXT_NORMAL_LIST_TV_AND_SMART_HUB_SUB_POPUP;
		}else{
			if(obj.style < 1 || obj.style > SubListStyle.SubList_Style_Max){
				obj.style = SubListStyle.SubList_Style_TEXT_NORMAL_LIST_TV_AND_SMART_HUB_SUB_POPUP;
			}
		}
		
		if(!obj.hasOwnProperty("text")){
			obj.text = "item" + i;
		}
		
		switch(obj.style)
		{
			case SubListStyle.SubList_Style_WIZARD_SUB_POPUP:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a: 0 };
					data.itemBGFocusedColor = { r: 33, g: 158, b: 230, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					print("bEnlarge is " + bEnlarge);
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
					
					//check box			
					itemCheckBoxWidth = 40;
					itemCheckBoxHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// //check box			
						// itemCheckBoxWidth = 40;
						// itemCheckBoxHeight = 40;
// 			
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// //check box				
						// itemCheckBoxWidth = 26;
						// itemCheckBoxHeight = 26;	
					// }
					//item text	
					data.text = {
						x: (0.003125 +  0.004688) * screenWidth + itemCheckBoxWidth,
						y: 0,
						width: itemWidth - (0.003125 +  0.004688 + 0.006250) * screenWidth - itemCheckBoxWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont,
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: { r: 47,g: 47, b: 47,a: 153 }, 
						itemTextFocusedColor: { r: 255,g: 255, b: 255, a: 255 },
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: { r: 47,g: 47,b: 47,a: 76.5 }
					};
										
					//check box
					data.image = {
						x: itemCheckBoxX,
						y: itemCheckBoxY,
						width: itemCheckBoxWidth, 
						height: itemCheckBoxHeight, 
						normalImagePath: imagePath + "check/popup_sub_check_icon_f.png",
						focusedImagePath: imagePath + "check/popup_sub_check_icon.png"
						// dimImagePath: "./images/TF_SelectButton/check_style_b.png"
					};
					
					data.textScrollAttr = textScrollAttr;		
				}
				break;
			case SubListStyle.SubList_Style_TV_AND_SMART_HUB_SUB_POPUP:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 255, g: 255, b: 255, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
		
					//check box			
					itemCheckBoxWidth = 40;
					itemCheckBoxHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// //check box			
						// itemCheckBoxWidth = 40;
						// itemCheckBoxHeight = 40;
// 			
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// //check box				
						// itemCheckBoxWidth = 26;
						// itemCheckBoxHeight = 26;	
					// }
					//item text	
					data.text = {
						x: (0.003125 +  0.004688)*screenWidth + itemCheckBoxWidth,
						y: 0,
						width: itemWidth - (0.003125 +  0.004688 + 0.006250)*screenWidth - itemCheckBoxWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: {r: 255,g: 255,b: 255,a: 153}, 
						itemTextFocusedColor: {r: 47,g: 47,b: 47,a: 255}, 
						itemTextSelectedColor: { r: 255,g: 194,b: 31,a: 255 },
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: {r: 255,g: 255,b: 255,a: 76.5 }
					};
										
					//check box
					data.image = {
						x: itemCheckBoxX,
						y: itemCheckBoxY,
						width: itemCheckBoxWidth, 
						height: itemCheckBoxHeight, 
						normalImagePath: imagePath + "check/popup_sub_check_icon.png",
						focusedImagePath: imagePath + "check/popup_sub_check_icon_f.png"
						// dimImagePath: "./images/TF_SelectButton/check_style_b.png"
					};
					
					data.textScrollAttr = textScrollAttr;
				}			
				break;
				
			case SubListStyle.SubList_Style_TEXT_NORMAL_LIST_WIZARD_SUB_POPUP:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 33, g: 158, b: 230, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
		
					//check box			
					itemCheckBoxWidth = 40;
					itemCheckBoxHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// //check box			
						// itemCheckBoxWidth = 40;
						// itemCheckBoxHeight = 40;
// 			
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// //check box				
						// itemCheckBoxWidth = 26;
						// itemCheckBoxHeight = 26;	
					// }
					//item text	
					data.text = {
						x: 0.028646 * screenWidth,
						y: 0,
						width: itemWidth - (0.028646 + 0.006250) * screenWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont,
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: {r: 47,g: 47,b: 47,a: 153}, 
						itemTextFocusedColor: {r: 255,g: 255,b: 255,a: 255},
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: {r: 47,g: 47,b: 47,a: 76.5 }
					};
										
					data.textScrollAttr = textScrollAttr;		
				}
				break;
				
			case SubListStyle.SubList_Style_NORMAL_LIST:
			case SubListStyle.SubList_Style_TEXT_NORMAL_LIST_TV_AND_SMART_HUB_SUB_POPUP:
				{		
					
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 255, g: 255, b: 255, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
		
					//check box			
					itemCheckBoxWidth = 40;
					itemCheckBoxHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// //check box			
						// itemCheckBoxWidth = 40;
						// itemCheckBoxHeight = 40;
// 			
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// //check box				
						// itemCheckBoxWidth = 26;
						// itemCheckBoxHeight = 26;	
					// }
					//item text	
					data.text = {
						x: 0.028646 * screenWidth,
						y: 0,
						width: itemWidth - (0.028646 + 0.006250) * screenWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: {r: 255,g: 255,b: 255,a: 153}, 
						itemTextFocusedColor: {r: 47,g: 47,b: 47,a: 255},
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: {r: 255,g: 255,b: 255,a: 76.5 }
					};
					
					data.textScrollAttr = textScrollAttr;
				};
				break;
				
			case SubListStyle.SubList_Style_CHECK_TWO:
			case SubListStyle.SubList_Style_TEXT_CHECK_TWO_WIZARD_SUB_POPUP:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 33, g: 158, b: 230, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
		
					//check box			
					itemCheckBoxWidth = 40;
					itemCheckBoxHeight = 40;
		
					// arrow
					itemRightArrowWidth = 40;
					itemRightArrowHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// //check box			
						// itemCheckBoxWidth = 40;
						// itemCheckBoxHeight = 40;
// 			
						// // arrow
						// itemRightArrowWidth = 40;
						// itemRightArrowHeight = 40;
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// //check box				
						// itemCheckBoxWidth = 26;
						// itemCheckBoxHeight = 26;
// 						
						// // arrow
						// itemRightArrowWidth = 26;
						// itemRightArrowHeight = 26;	
					// }
					//item text	
					data.text = {
						x: (0.003125 +  0.004688) * screenWidth + itemCheckBoxWidth,
						y: 0,
						width: itemWidth - (0.003125 * 2 +  0.004688 * 2) * screenWidth - itemCheckBoxWidth - itemRightArrowWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: {r: 47,g: 47,b: 47,a: 153}, 
						itemTextFocusedColor: {r: 255,g: 255,b: 255,a: 255}, 
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: {r: 47,g: 47,b: 47,a: 76.5 }
					};
										
					//check box
					data.image = {
						x: itemCheckBoxX,
						y: itemCheckBoxY,
						width: itemCheckBoxWidth, 
						height: itemCheckBoxHeight, 
						normalImagePath: imagePath + "check/popup_sub_check_icon_f.png",
						focusedImagePath: imagePath + "check/popup_sub_check_icon.png"
						// dimImagePath: "./images/TF_SelectButton/check_style_b.png"
					};
					
					// arrow
					data.image2 = {
						x: itemRightArrowX,
						y: itemRightArrowY,
						width: itemRightArrowWidth, 
						height: itemRightArrowHeight, 
						normalImagePath: imagePath + "sub_popup/list_arrow_c_right_f.png",
						focusedImagePath: imagePath + "sub_popup/list_arrow_c_right.png",
					    dimImagePath: imagePath + "sub_popup/list_arrow_c_right_f.png",
					    normalAlpha: 255,
					    focusAlpha: 255,
					    dimAlpha: 25.5
					};
					
					data.textScrollAttr = textScrollAttr;
				}			
				break;
			
			case SubListStyle.SubList_Style_TEXT_CHECK_TWO_TV_AND_SMART_HUB_SUB_POPUP:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 255, g: 255, b: 255, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
		
					//check box			
					itemCheckBoxWidth = 40;
					itemCheckBoxHeight = 40;
					
					// arrow
					itemRightArrowWidth = 40;
					itemRightArrowHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// //check box			
						// itemCheckBoxWidth = 40;
						// itemCheckBoxHeight = 40;
// 						
						// // arrow
						// itemRightArrowWidth = 40;
						// itemRightArrowHeight = 40;
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// //check box				
						// itemCheckBoxWidth = 26;
						// itemCheckBoxHeight = 26;
// 						
						// // arrow
						// itemRightArrowWidth = 26;
						// itemRightArrowHeight = 26;
					// }
					//item text	
					data.text = {
						x: (0.003125 +  0.004688) * screenWidth + itemCheckBoxWidth,
						y: 0,
						width: itemWidth - (0.003125 * 2 +  0.004688 * 2) * screenWidth - itemCheckBoxWidth - itemRightArrowWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: {r: 255,g: 255,b: 255,a: 153}, 
						itemTextFocusedColor: {r: 47,g: 47,b: 47,a: 255}, 
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: {r: 255,g: 255,b: 255,a: 76.5 }
					};
										
					//check box
					data.image = {
						x: itemCheckBoxX,
						y: itemCheckBoxY,
						width: itemCheckBoxWidth, 
						height: itemCheckBoxHeight, 
						normalImagePath: imagePath + "check/popup_sub_check_icon.png",
						focusedImagePath: imagePath + "check/popup_sub_check_icon_f.png",
						// dimImagePath: "./images/TF_SelectButton/check_style_b.png"
					};
					
					// arrow
					data.image2 = {
						x: itemRightArrowX,
						y: itemRightArrowY,
						width: itemRightArrowWidth, 
						height: itemRightArrowHeight, 
						normalImagePath: imagePath + "sub_popup/list_arrow_c_right.png",
						focusedImagePath: imagePath + "sub_popup/list_arrow_c_right_f.png",
					    dimImagePath: imagePath + "sub_popup/list_arrow_c_right.png",
					    normalAlpha: 255,
					    focusAlpha: 255,
					    dimAlpha: 25.5
					};
					
					data.textScrollAttr = textScrollAttr;
				}			
				break;
			
			case SubListStyle.SubList_Style_CHECK_THREE_WIZARD_SUB_POPUP:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 33, g: 158, b: 230, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
		
					// arrow		
					itemLeftArrowWidth = 40;
					itemLeftArrowHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// // arrow		
						// itemLeftArrowWidth = 40;
						// itemLeftArrowHeight = 40;
// 			
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// // arrow		
						// itemLeftArrowWidth = 26;
						// itemLeftArrowHeight = 26;
					// }
					//item text	
					data.text = {
						x: (0.003125 +  0.004688) * screenWidth + itemLeftArrowWidth,
						y: 0,
						width: itemWidth - (0.003125 +  0.004688 + 0.006250) * screenWidth - itemLeftArrowWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: {r: 47,g: 47,b: 47,a: 153}, 
						itemTextFocusedColor: {r: 255,g: 255,b: 255,a: 255}, 
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: {r: 47,g: 47,b: 47,a: 76.5 }
					};
										
					// arrow
					data.image2 = {
						x: itemLeftArrowX,
						y: itemLeftArrowY,
						width: itemLeftArrowWidth, 
						height: itemLeftArrowHeight, 
						normalImagePath: imagePath + "sublist/list_arrow_c_left_f.png",
						focusedImagePath: imagePath + "sublist/list_arrow_c_left.png",
						dimImagePath: imagePath + "sublist/list_arrow_c_left_f.png",
						normalAlpha: 255,
					    focusAlpha: 255,
					    dimAlpha: 25.5
					};
					
					data.textScrollAttr = textScrollAttr;
				}			
				break;			
					
			case SubListStyle.SubList_Style_CHECK_THREE:
			case SubListStyle.SubList_Style_CHECK_THREE_TV_AND_SMART_HUB_SUB_POPUP:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 255, g: 255, b: 255, a: 242 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 30px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 44px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 44px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
		
					// arrow		
					itemLeftArrowWidth = 40;
					itemLeftArrowHeight = 40;
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 30px";
						// itemTextFocusFont = "SamsungSmart_Medium 36px";
						// itemTextSelectedFont = "SamsungSmart_Medium 36px";
						// itemTextDimFont = "SamsungSmart_Medium 30px";
// 			
						// // arrow		
						// itemLeftArrowWidth = 40;
						// itemLeftArrowHeight = 40;
// 			
					// } else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
						// itemTextNormalFont = "SamsungSmart_Medium 20px";
						// itemTextFocusFont = "SamsungSmart_Medium 24px";
						// itemTextSelectedFont = "SamsungSmart_Medium 24px";
						// itemTextDimFont = "SamsungSmart_Medium 20px";
// 						
						// // arrow		
						// itemLeftArrowWidth = 26;
						// itemLeftArrowHeight = 26;
					// }
					//item text	
					data.text = {
						x: (0.003125 +  0.004688) * screenWidth + itemLeftArrowWidth,
						y: 0,
						width: itemWidth - (0.003125 +  0.004688 + 0.006250) * screenWidth - itemLeftArrowWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: {r: 255,g: 255,b: 255,a: 153}, 
						itemTextFocusedColor: {r: 47,g: 47,b: 47,a: 255}, 
						itemTextSelectedColor: { r: 255,g: 194, b: 31, a: 255 },
						itemTextDimColor: {r: 255,g: 255,b: 255,a: 76.5 }
					};
										
					// arrow
					data.image2 = {
						x: itemLeftArrowX,
						y: itemLeftArrowY,
						width: itemLeftArrowWidth, 
						height: itemLeftArrowHeight, 
						normalImagePath: imagePath + "sublist/list_arrow_c_left.png",
						focusedImagePath: imagePath + "sublist/list_arrow_c_left_f.png",
						dimImagePath: imagePath + "sublist/list_arrow_c_left.png",
						normalAlpha: 255,
					    focusAlpha: 255,
					    dimAlpha: 25.5
					};
					
					data.textScrollAttr = textScrollAttr;
				}			
				break;
				
			case SubListStyle.KeyScreen_Common_SMART_HUB_SUBLIST_Text:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 0, g: 0, b: 0, a: 0 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					// check enlarge
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 34px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
						
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 43px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 43px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
					
					// check highcontrast
					if(false == bHighContrast){
						itemTextNormalColor =  { r: 255, g: 255, b: 255, a: 255 };
						itemTextFocusedColor = { r: 255, g: 255, b: 255, a: 255 };
						itemTextSelectedColor = { r: 255, g: 194, b: 31, a: 255 }; 
						itemTextDimColor = { r: 255, g: 255, b: 255, a: 38.25 };
					}else{
						itemTextNormalColor = { r: 255, g: 255, b: 255, a: 255 };
						itemTextFocusedColor = { r: 255, g: 194, b: 31, a: 255 };
						itemTextSelectedColor = { r: 255, g: 194, b: 31, a: 255 }; 
						itemTextDimColor = { r: 255, g: 255, b: 255, a: 38.25 };
					}
					
					//item text	
					data.text = {
						x: 0.015625 * screenWidth,
						y: 0,
						width: itemWidth - 0.015625 * screenWidth * 2,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: itemTextNormalColor, 
						itemTextFocusedColor: itemTextFocusedColor,
						itemTextSelectedColor: itemTextSelectedColor, 
						itemTextDimColor: itemTextDimColor
					};
										
					data.textScrollAttr = textScrollAttr;		
				}
				break;
				
			case SubListStyle.KeyScreen_Common_SMART_HUB_SUBLIST_Check:
				{
					//item BG
					data.itemBGNormalColor = { r: 0, g: 0, b: 0, a:0 };
					data.itemBGFocusedColor = { r: 0, g: 0, b: 0, a: 0 };					
					data.itemBGDimColor = { r: 0, g: 0, b: 0, a: 0 };
					
					// check enlarge
					if(false == bEnlarge){
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 30px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 34px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
						
					}else{
						itemTextNormalFont = "SamsungSmart_Medium 30px";
						itemTextFocusFont = "SamsungSmart_Medium 43px";
						itemTextSelectedFont = "SamsungSmart_Medium 30px";
						itemTextMouseFocusedFont = "SamsungSmart_Medium 43px";
						itemTextDimFont = "SamsungSmart_Medium 30px";
					}
					
					// check highcontrast
					if(false == bHighContrast){
						itemTextNormalColor =  { r: 255, g: 255, b: 255, a: 255 };
						itemTextFocusedColor = { r: 255, g: 255, b: 255, a: 255 };
						itemTextSelectedColor = { r: 255, g: 194, b: 31, a: 255 }; 
						itemTextDimColor = { r: 255, g: 255, b: 255, a: 38.25 };
					}else{
						itemTextNormalColor = { r: 255, g: 255, b: 255, a: 255 };
						itemTextFocusedColor = { r: 255, g: 194, b: 31, a: 255 };
						itemTextSelectedColor = { r: 255, g: 194, b: 31, a: 255 }; 
						itemTextDimColor = { r: 255, g: 255, b: 255, a: 38.25 };
					}
		
					//check box			
					itemCheckBoxWidth = 40;
					itemCheckBoxHeight = 40;
					
					//check box
					data.image = {
						x: 0.004167 * screenWidth,
						y: (itemHeight - itemCheckBoxHeight) / 2 ,
						width: itemCheckBoxWidth, 
						height: itemCheckBoxHeight, 
						normalImagePath: imagePath + "sublist/popup_sub_check_icon_y.png",
						focusedImagePath: imagePath + "sublist/popup_sub_check_icon_y.png",
					    dimImagePath: imagePath + "sublist/popup_sub_check_icon_y.png"
					};
					
					//item text	
					data.text = {
						x: 2 * 0.004167 * screenWidth + itemCheckBoxWidth,
						y: 0,
						width: itemWidth - 2 * 0.004167 * screenWidth - itemCheckBoxWidth - 0.015625 * screenWidth,
						height: itemHeight, 
						itemTextNormalFont: itemTextNormalFont, 
						itemTextFocusedFont: itemTextFocusFont, 
						itemTextSelectedFont: itemTextSelectedFont,
						itemTextMouseFocusedFont: itemTextMouseFocusedFont,
						itemTextDimFont: itemTextDimFont, 
						hAlign: "horizontal_align_left", 
						vAlign: "vertical_align_middle", 
						itemTextString: obj.text, 
						itemTextNormalColor: itemTextNormalColor, 
						itemTextFocusedColor: itemTextFocusedColor,
						itemTextSelectedColor: itemTextSelectedColor, 
						itemTextDimColor: itemTextDimColor
					};
										
					data.textScrollAttr = textScrollAttr;
				}			
				break;
							
			default:
				break;
		}
	}
	
	
	var setHighContrast = function(){
		sublist.setFirstLayerBGColor({ firstLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
		sublist.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 0 } });
		
		if(true == bKeyCommon){
			for(var i = 0; i < itemNumber; i++){
				sublist.updateItem(
                    {
                        index: i,
                        text: 
                        { 
	                    	itemTextNormalColor: { r: 255, g: 255, b: 255, a: 255 }, 
							itemTextFocusedColor: { r: 255, g: 194, b: 31, a: 255 },
							itemTextSelectedColor: { r: 255, g: 194, b: 31, a: 255 }, 
							itemTextDimColor: { r: 255, g: 255, b: 255, a: 38.25 }
						}
                    }
                ) 

			}
		}
	}
	
	var setNoHighContrast = function(){
		if(null != bgColor){
			sublist.setFirstLayerBGColor({ firstLayerBGColor: bgColor });
		}else{
			switch(bgStyle){
				case BackgroundStyle.BG_Style_E_4_5:
					sublist.setFirstLayerBGColor({ firstLayerBGColor: { r: 248, g: 248, b: 248, a: 255 } });
					break;
				case BackgroundStyle.BG_Style_Key_Common:
					sublist.setFirstLayerBGColor({ firstLayerBGColor: { r: 15, g: 24, b: 38, a: 255 } });
					sublist.setSecondLayerBGColor({ secondLayerBGColor: { r: 255, g: 255, b: 255, a: 76.5 } });
					break;
				
				default:
					break;
			}	
		}
		
		if(true == bKeyCommon){
			for(var i = 0; i < itemNumber; i++){
				sublist.updateItem(
                    {
                        index: i,
                        text: 
                        { 
	                    	itemTextNormalColor: { r: 255, g: 255, b: 255,a: 255 }, 
							itemTextFocusedColor: { r: 255, g: 255, b: 255,a: 255 },
							itemTextSelectedColor: { r: 255, g: 194, b: 31, a: 255 }, 
							itemTextDimColor: { r: 255, g: 255, b: 255, a: 38.25 }
						}
                    }
                ) 

			}
		}
	}
	
	var setEnlarge = function(){
		if(true == bKeyCommon){
			for(var i = 0; i < itemNumber; i++){
				sublist.updateItem(
                    {
                        index: i,
                        text: 
                        { 
	                    	itemTextMouseFocusedFont: "SamsungSmart_Medium 43px", 
							itemTextFocusedFont: "SamsungSmart_Medium 43px"
						}
                    }
                ) 

			}
		}else{
			for(var i = 0; i < itemNumber; i++){
				sublist.updateItem(
                    {
                        index: i,
                        text: 
                        { 
							itemTextFocusedFont: "SamsungSmart_Medium 44px",
							itemTextSelectedFont: "SamsungSmart_Medium 44px"
						}
                    }
                ) 

			}
		}
	}
	
	var setNoEnlarge = function(){
		if(true == bKeyCommon){
			for(var i = 0; i < itemNumber; i++){
				sublist.updateItem(
                    {
                        index: i,
                        text: 
                        { 
	                    	itemTextMouseFocusedFont: "SamsungSmart_Medium 43px", 
							itemTextFocusedFont: "SamsungSmart_Medium 30px"
						}
                    }
                ) 

			}
		}else{
			for(var i = 0; i < itemNumber; i++){
				sublist.updateItem(
                    {
                        index: i,
                        text: 
                        { 
							itemTextFocusedFont: "SamsungSmart_Medium 30px",
							itemTextSelectedFont: "SamsungSmart_Medium 30px"
						}
                    }
                ) 

			}
		}
	}
	
	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	sublist = new SubList({
			x: x,
			y: y,
			parent: parent,
			width: bgWidth,
			height: bgHeight,
			color: { r: 0, g: 0, b: 0, a: 0 },
			singleLineListWidth: itemWidth,
			singleLineListHeight: singleListHeight,
			nItemNumberOnWindow: showNumber
	});
	
	// if(null != bgColor){
		// sublist.color = bgColor;
	// }
	
	if(null != id){
		sublist.id = id;
	}
	
	switch(bgStyle){
		case BackgroundStyle.BG_Style_E_4_5:
			if(true == bHighContrast){
				sublist.setFirstLayerBGColor({ firstLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
				sublist.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 0 } });
			}else{
				if(null != bgColor){
					sublist.setFirstLayerBGColor({ firstLayerBGColor: bgColor });
				}else{
					sublist.setFirstLayerBGColor({ firstLayerBGColor: { r: 248, g: 248, b: 248, a: 255 } });
				}
				
				sublist.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 0 } });
			}
			
			sublist.setThirdLayerBGBorderColor({ thirdLayerBGBorderColor: {r: 0, g: 0, b: 0, a: 25.5 } });
			sublist.setThirdLayerBGBorderWidth(1);
		break;
		case BackgroundStyle.BG_Style_Key_Common:
			if(true == bHighContrast){
				sublist.setFirstLayerBGColor({ firstLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
				sublist.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 0 } });
			}else{
				if(null != bgColor){
					sublist.setFirstLayerBGColor({ firstLayerBGColor: bgColor });
					sublist.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 0 } });
				}else{
					sublist.setFirstLayerBGColor({ firstLayerBGColor: { r: 15, g: 24, b: 38, a: 255 } });
					sublist.setSecondLayerBGColor({ secondLayerBGColor: { r: 255, g: 255, b: 255, a: 76.5 } });
				}
			}
			sublist.setThirdLayerBGBorderColor({ thirdLayerBGBorderColor: {r: 0, g: 0, b: 0, a: 25.5 } });
			sublist.setThirdLayerBGBorderWidth(1);
		break;
		
		default:
		break;
	}
	sublist.setFourthLayerBGImage(imagePath + "sub_popup/popup_sublist_shadow.png");
	
	// if(true == bHighContrast){
		// setHighContrast();
	// }else{
		// setNoHighContrast();
	// }
	
	if(false == bKeyCommon){
		if(true == bShowArrow){
			sublist.setSingleLineListPosition({x: 0.001042 * screenWidth, y: 0.055556 * screenHeight + 0.001042 * screenWidth });
		}else{
			sublist.setSingleLineListPosition({x: 0.001042 * screenWidth, y: 0.001042 * screenWidth });
		}
	}else{
		sublist.setSingleLineListPosition({x: 1, y: 1 });
	}
	
	sublist.addItem({itemNum: itemNumber, itemSpace: itemHeight, itemGap: itemGap });
	
	// add data
	for(var i = 0; i < itemNumber; i++){
		var data = new Data();
	    data.index = i;
		setItemStyleValue(items[i], data);
		//dataList[i] = data;
		sublist.addData(data);
	}
	
	sublist.setDataSource();
	
	// set arrow
	if(true == bShowArrow){
		sublist.setArrowImageAttr({ArrowDirection: "upArrow", x: (itemWidth + 2 * 0.001042 * screenWidth - arrowWidth) / 2, y: 0, width: arrowWidth, height: arrowHeight, arrowNormalImagePath: imagePath + "arrow/popup_sublist_arrow_up.png" });
		sublist.setArrowImageAttr({ArrowDirection: "downArrow", x: (itemWidth + 2 * 0.001042 * screenWidth - arrowWidth) / 2, y: 2 * 0.001852 * screenHeight + 0.055556 * screenHeight + singleListHeight, width: arrowWidth, height: arrowHeight, arrowNormalImagePath: imagePath + "arrow/popup_sublist_arrow_down.png" });
	}
	
	// set dim
	for(var i = 0; i < itemNumber; i++){
		if(items[i].hasOwnProperty("bDim")){
			if(true == items[i].bDim){
				sublist.setDim({ index: i, ifDim: true });
			}
		}
	}
	
	sublist.setAnimationDuration("loop", 0);
	if(true == bKeyCommon){
		sublist.setFocusImage(imagePath + "highlight/ksc_focus.png", -7, -7);
	}
	// sublist.showFocus("false");
	// sublist.setFocus();
	
	var widgetExListener = new WidgetExListener;
	widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
		print("flagHighContrast is " + flagHighContrast);
		print("bHighContrast is " + bHighContrast);
	    if((true == flagHighContrast) && (false == bHighContrast)){
	    	setHighContrast();
	    	bHighContrast = true;
	    }
	    
	    if((false == flagHighContrast) && (true == bHighContrast)){
	    	setNoHighContrast();
	    	bHighContrast = false;
	    }
	};
	
	widgetExListener.onEnlargeChanged = function (widgetEx, flagEnlarge) {
    	if((true == flagEnlarge) && (false == bEnlarge)){
	    	setEnlarge();
	    	bEnlarge = true;
	    }
	    
	    if((false == flagEnlarge) && (true == bEnlarge)){
	    	setNoEnlarge();
	    	bEnlarge = false;
	    }
	};

	sublist.addWidgetExListener(widgetExListener);
	
	sublist.destroyListener = function(){
		if(null != widgetExListener){
			sublist.removeWidgetExListener(widgetExListener);
			widgetExListener.destroy();
			widgetExListener = null;
		}
	};
	
	return sublist;
};

var SubListStyle = {
	SubList_Style_WIZARD_SUB_POPUP: 1,
	SubList_Style_TV_AND_SMART_HUB_SUB_POPUP: 2,
	SubList_Style_NORMAL_LIST: 3, // to delete
	SubList_Style_TEXT_NORMAL_LIST_WIZARD_SUB_POPUP: 4,
	SubList_Style_TEXT_NORMAL_LIST_TV_AND_SMART_HUB_SUB_POPUP: 5,
	SubList_Style_CHECK_TWO: 6, // to delete
	SubList_Style_TEXT_CHECK_TWO_WIZARD_SUB_POPUP: 7,
	SubList_Style_TEXT_CHECK_TWO_TV_AND_SMART_HUB_SUB_POPUP: 8,
	SubList_Style_CHECK_THREE_WIZARD_SUB_POPUP: 9,
	SubList_Style_CHECK_THREE_TV_AND_SMART_HUB_SUB_POPUP: 10,
	SubList_Style_TEXT_CHECK_THREE: 11, // to delete
	// for common gui
	KeyScreen_Common_SMART_HUB_SUBLIST_Text: 12,
	KeyScreen_Common_SMART_HUB_SUBLIST_Check: 13,
	SubList_Style_Max: 14
};

var BackgroundStyle = {
	BG_Style_E_4_5: 1,
	BG_Style_Key_Common: 2,
	BG_Style_Max: 3
};

winsetSubList.SubListStyle = SubListStyle;
winsetSubList.prototype = new winsetBase();

exports = winsetSubList;

