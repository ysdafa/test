var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetRadioButton = function(obj){	
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	

	// local var
	var style = RadioButtonStyle.Radiobutton_Style_A,
		resolution = ResolutionStyle.Resolution_1080,
		radioButton,
		path = "modules/WinsetUIElement/winsetImg/",
		x = 0,
		y = 0,
		width = 40,
		height = 40,
		parent = scene,
		id = null,
		// image path
		bgNormal = null,
		bgFoucs = null,
		bgSelect = null,
		bgDim = null,
		normalCheckImagePath = null,
		foucsCheckImagePath = null,
		selectCheckImagePath = null,
		dimCheckImagePath = null,
		// image opcity
		bgNormalOpacity,
		bgFoucsOpacity,
		bgSelectOpacity,
		bgDimOpacity,
		normalCheckImageOpacity,
		foucsCheckImageOpacity,
		selectCheckImageOpacity,
		dimCheckImageOpacity;
				
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number" || typeof objParameter.style == "string")){
				
				if(typeof objParameter.style == "string"){
					style = parseInt(objParameter.style);
				}else{
					style = objParameter.style;	
				}
				
				if((1 > style) || (RadioButtonStyle.Radiobutton_Style_Max <= style)){
					style = 1;
				}
			}
			
			// if (objParameter.hasOwnProperty("nResolutionStyle") 
				// && (typeof objParameter.nResolutionStyle == "number" || typeof objParameter.nResolutionStyle == "string")){
					// if(typeof objParameter.nResolutionStyle == "string"){
						// resolution = parseInt(objParameter.nResolutionStyle);
					// }else{
						// resolution = objParameter.nResolutionStyle;
					// }
// 					
				// if((ResolutionStyle.Resolution_720 > resolution) || (ResolutionStyle.Resolution_Style_MAX <= resolution)){
					// resolution = ResolutionStyle.Resolution_1080;
				// }	
			// }
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
				if(typeof objParameter.x == "string"){
					x = parseInt(objParameter.x);	
				}else{
					x = objParameter.x;	
				} 
				
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					y = parseInt(objParameter.y);	
				}else{
					y = objParameter.y;	
				}
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
				if(typeof objParameter.width == "string"){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
				if(typeof objParameter.height == "string"){
					height = parseInt(objParameter.height);
				}else{
					height = objParameter.height;
				}			
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
				
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
		}	
	}
			
	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		width = 40;
		height = 40;
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			path = path + "1080p/check/";
			// width = 40;
			// height = 40;
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			path = path + "720p/check/";
			// width = 26;
			// height = 26;
		}
		//set default value
		switch(style)
		{
			case RadioButtonStyle.Radiobutton_Style_D:
			case RadioButtonStyle.Radiobutton_Style_A:
				{
					// bg image path
					bgNormal = path + "popup_radio_box_d.png";
					bgFoucs = path + "popup_radio_box_w.png";
					bgSelect = path + "popup_radio_box_y.png";
					bgDim = path + "popup_radio_box_d.png";
					
		            // check image path
					// normalCheckImagePath = path + "checkbox_radio.png";
					foucsCheckImagePath = path + "popup_radio_icon_w.png";
					selectCheckImagePath = path + "popup_radio_icon_y.png";
					
					// bg opacity
					bgNormalOpacity = 76.5;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 25.5;
					// check image opacity
					//add normal check
					normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;			
				}
				break;
			
			//add normal check
			case RadioButtonStyle.Radiobutton_Style_D_Checked:
				{
					// bg image path
					bgNormal = path + "popup_radio_box_d.png";
					bgFoucs = path + "popup_radio_box_w.png";
					bgSelect = path + "popup_radio_box_y.png";
					bgDim = path + "popup_radio_box_d";
					
		            // check image path
					normalCheckImagePath = path + "popup_radio_icon_b.png";
					foucsCheckImagePath = path + "popup_radio_icon_w.png";
					selectCheckImagePath = path + "popup_radio_icon_y.png";
					
					// bg opacity
					bgNormalOpacity = 76.5;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 25.5;
					// check image opacity
					//add normal check
					normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;			
				}
				break;
				
			case RadioButtonStyle.Radiobutton_Style_E_Focus2:
			case RadioButtonStyle.Radiobutton_Style_B_Focus2:
			case RadioButtonStyle.Radiobutton_Style_E_Focus1:
			case RadioButtonStyle.Radiobutton_Style_B_Focus1:
			case RadioButtonStyle.Radiobutton_Style_C:
			case RadioButtonStyle.Radiobutton_Style_E:
				{
					// bg image path
					bgNormal = path + "popup_radio_box_w.png";
					bgFoucs = path + "popup_radio_box_d.png";
					bgSelect = path + "popup_radio_box_y.png";
					bgDim = path + "popup_radio_box_w.png";
					
		            // check image path
					foucsCheckImagePath = path + "popup_radio_icon_d.png";
					selectCheckImagePath = path + "popup_radio_icon_y.png";
					
					// bg opacity
					bgNormalOpacity = 153;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 102;
					// check image opcity
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;			
				}
				break;
			
			//add normal check
			case RadioButtonStyle.Radiobutton_Style_E_Checked:
				{
					// bg image path
					bgNormal = path + "popup_radio_box_w.png";
					bgFoucs = path + "popup_radio_box_d.png";
					bgSelect = path + "popup_radio_box_y.png";
					bgDim = path + "popup_radio_box_w.png";
					
		            // check image path
					normalCheckImagePath = path + "popup_radio_icon_w.png";
					foucsCheckImagePath = path + "popup_radio_icon_d.png";
					selectCheckImagePath = path + "popup_radio_icon_y.png";
					
					// bg opacity
					bgNormalOpacity = 153;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 102;
					
					// check image opcity
					normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;			
				}
				break;
			
			default:
				break;
		}
	}
	
	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	//create selectButton instance 
	radioButton = new SelectButton({
		x: x,
		y: y,
		parent: parent,
		width: width,
		height: height,
		color: { r:0, g:0, b:0, a:0}
	});
	
	if(null != id){
		radioButton.id = id;
	}
		
	// set background 
	if(null != bgNormal){
		radioButton.setBoxBackGroudImage({ state: "normal", imageSrc: bgNormal });
		radioButton.setBoxBackGroudImageOpacity({ state: "normal",opacity: bgNormalOpacity });
	}
	
	if(null != bgFoucs){
		radioButton.setBoxBackGroudImage({ state: "focused", imageSrc: bgFoucs });
		radioButton.setBoxBackGroudImageOpacity({ state: "focused",opacity: bgFoucsOpacity });
	}
	
	if(null != bgSelect){
		radioButton.setBoxBackGroudImage({ state: "selected", imageSrc: bgSelect });
		radioButton.setBoxBackGroudImageOpacity({ state: "selected",opacity: bgSelectOpacity });
	}
	
	if(null != bgDim){
		radioButton.setBoxBackGroudImage({ state: "disabled", imageSrc: bgDim });
		radioButton.setBoxBackGroudImageOpacity({ state: "disabled",opacity: bgDimOpacity });
	}
	
	
	// set check
	if(null != normalCheckImagePath){
		radioButton.setCheckImage({ state: "normal", imageSrc: normalCheckImagePath });
		radioButton.setCheckImageOpacity({ state: "normal", opacity: normalCheckImageOpacity });
	}
	
	if(null != foucsCheckImagePath){
		radioButton.setCheckImage({ state: "focused", imageSrc: foucsCheckImagePath });
		radioButton.setCheckImageOpacity({ state: "focused", opacity: foucsCheckImageOpacity });
	}
	
	if(null != selectCheckImagePath){
		radioButton.setCheckImage({ state: "selected", imageSrc: selectCheckImagePath });
		radioButton.setCheckImageOpacity({ state: "selected",opacity: selectCheckImageOpacity });
	}
	
	if(null != dimCheckImagePath){
		radioButton.setCheckImage({ state: "disabled", imageSrc: dimCheckImagePath });
		radioButton.setCheckImageOpacity({ state: "disabled",opacity: dimCheckImageOpacity });
	}
	 
    return radioButton;
}

var RadioButtonStyle = {
	Radiobutton_Style_A: 1, // to be delete
	Radiobutton_Style_B_Focus1: 2, // to be delete
	Radiobutton_Style_B_Focus2: 3, // to be delete
	Radiobutton_Style_C: 4, // to be delete
	Radiobutton_Style_D: 5, 
	Radiobutton_Style_D_Checked: 6,
	Radiobutton_Style_E_Focus1: 7, // to be delete
	Radiobutton_Style_E_Focus2: 8, // to be delete
	Radiobutton_Style_E: 9, 
	Radiobutton_Style_E_Checked: 10,
	Radiobutton_Style_Max: 11 // to be delete
};

winsetRadioButton.RadioButtonStyle =  RadioButtonStyle;
winsetRadioButton.prototype = new winsetBase();

exports = winsetRadioButton;
