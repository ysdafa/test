var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetPinNumberPopup = function (objParameter){
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	var m_pInstance = null;
	//default value
	var m_defaultParent = scene;
	var m_defaultId = null;
	var m_imagePath	= "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/";
	var m_pinNumberPopupStyle = 0;
	var m_resolutionStyle = 0;
	var m_bAutoArrange = false;	
	
	var m_defaultWidth = 1920;
	var m_defaultHeight = 1080;
	var m_defaultAdd = 0;
	var m_defaultPinType = "pinbox_two";

	//bg 
	var m_defaultBgColor = { r: 39, g: 124, b: 175, a: 200 };
	var m_defaultBgX = 0;
	var m_defaultBgY = 0;	
	var m_defaultBgW = 1920;
	var m_defaultBgH = 1080*0.502778;	
			
	//title	
	var m_defaultHasTitle = true;	
	var m_defaultTitle = "PIN TITLE";
	var m_defaultTitleX = (1920 - 782)/2;
	var m_defaultTitleY = 0;
	var m_defaultTitleW = 782.0;
	var m_defaultTitleH =  97.0;
	var m_defaultTitleFontSize = 46,
		titleTextColor;
	
	//title line
	var m_defaultTitleLineH =  1;	
		
	//content
	var m_defaultHasContent = true;	
	var m_defaultContentText = "this is the pin number popup";
	var m_defaultContentTextX = (1920 - 782) / 2;
	var m_defaultContentTextY = 97.0 + 32.0;
	var m_defaultContentTextW = 782.0;
	var m_defaultContentTextH = 48.0;
	var m_defaultContentFontSize = 34;
	
	//pin box one text
	var m_defaultPinBoxTextOne = "First Input";
	var m_defaultPinBoxTextW = 0.584375 * 1920;		
	var m_defaultPinBoxTextH = 0.044444 * 1080;		
	var m_defaultPinBoxTextX = (1920 - m_defaultPinBoxTextW)/2;		
	var m_defaultPinBoxTextY = (0.089815 + 0.010185 + 0.044444 + 0.044444)*1080;	
		
	//pin box one
	var m_defaultPinBoxOneX = (1920.0 - 345.0) / 2;
	var m_defaultPinBoxOneY = 97.0 + 32.0 + 50.0 + 48.0;
	var m_defaultPinBoxOneW = 345.0;
	var m_defaultPinBoxOneH = 57;
	
	//pin box two text
	var m_defaultPinBoxTextTwo = "Second Input";
	var m_defaultPinBoxTextTwoW = 0.584375 * 1920;	
	var m_defaultPinBoxTextTwoH = 0.044444 * 1080;
	var m_defaultPinBoxTextTwoX = (1920 - m_defaultPinBoxTextTwoW)/2;		;
	var m_defaultPinBoxTextTwoY = (0.089815 + 0.010185 + 0.044444 + 0.044444 + 0.044444 + 0.014815 + 0.053704 + 0.028704)*1080;
	
	//pin box two
	var m_defaultPinBoxTwoW = 345.0;
	var m_defaultPinBoxTwoH = 57;
	var m_defaultPinBoxTwoX = (1920.0 - 345.0) / 2;
	var m_defaultPinBoxTwoY = (0.089815 + 0.010185 + 0.044444 + 0.044444 + 0.044444 + 0.014815 + 0.053704 + 0.028704 + 0.044444 + 0.014815)*1080;	
	
	//pin gap	
	var	m_defaultInputItemsGap_NoInput = 1920 * 0.003125;
	var	m_defaultInputItemsGap_FinishInput = 1920 * 0.016666;	
	
	var m_defaultDigitGap = 1920 * 0.003125;
	var m_defaultPinBoxFontSize = 34;
	
	//digit text
	var m_defaultDigitTextW =1920 * 0.015625;
	var m_defaultDigitTextH = 1080 * 0.037037;
	
	//pin box 
	var m_defaultPinBoxBGFocusImage = "";
	var m_defaultPinBoxBGNormalImage = "";	
	var m_defaultPinBoxItemFcousImage = "";
	var m_defaultPinBoxItemNormalImage = "";	
	
	//pin box item
	var	m_defaultInputBoxItemW_NoInput = 30;
	var m_defaultInputBoxItemH_NoInput = 40;
	var	m_defaultInputBoxItemW_FinishInput = 9;	
	var m_defaultInputBoxItemH_FinishInput = 9;

	//button one
	var m_defaultButtonNum =0;
	var m_defaultButtonOneText = "Cancel";
	var m_defaultButtonOneX = (1920 - 1920 * 0.140625) / 2;
	var m_defaultButtonOneY = 1080 * 0.41207 - 1080 * (0.061111 + 0.036111);
	var m_defaultButtonOneW = 1920 * 0.140625;
	var m_defaultButtonOneH = 1080 * 0.061111;
	
	var m_defaultOrientationType = 	"left-to-right",
		bHighContrast = false,
		popupStyle = PopupStyle.TV_and_Smart_Hub_Popup;
	
	//button property	
	var buttonStyle = ButtonStyle.Button_image_O_Style_F,
		buttonBgNormal,
		buttonBgFoucs,
		buttonBgSelect,
		buttonBgDim,
		buttonBgNormalColor,
		buttonBgFoucsColor,
		buttonBgSelectColor,
		buttonBgDimColor,
		buttonBgRolloverColor,
		normalFont,
		focusFont,
		selectFont,
		dimFont,
		rolloverFont,
		normalTextColor,
		focusTextColor,
		selectTextColor,
		dimTextColor,
		rolloverTextColor;	
	
	var m_bgStyle = BackgroudStyle.BG_Style_E_1;
	
	
	var m_create = function(objParameter){
		Volt.log('[winsetPinNumberPopup.js @m_create]'); 

		m_resoultionStyle = getResolution();
		//analysis parameter
		m_analysisParameter(objParameter);
		
		//set default value
		m_setDefaultValueByPinNumberPopupStyle();
				
		//create PinPopup instance 
		m_pInstance = new PinPopup({
			parent: m_defaultParent,
			width: m_defaultBgW,
			height: m_defaultBgH,
			pinType: m_defaultPinType,
			isTitle: m_defaultHasTitle,
			color: m_defaultBgColor,
			isContent: m_defaultHasContent,
			buttonNum:m_defaultButtonNum,
			autoArrange:m_bAutoArrange,
			title : m_defaultTitle
		});		
		
		m_pInstance.x = 0;
		m_pInstance.y = 0;		
		m_pInstance.origin = {x: 0.5, y: 0.5};
		m_pInstance.anchor = {x: 0.5, y: 0.5};				
		
		
		m_pInstance.setPinBoxBackGroundImage({ state: "focus_state", src: m_defaultPinBoxBGFocusImage});
		m_pInstance.setPinBoxBackGroundImage({ state: "normal_state", src: m_defaultPinBoxBGNormalImage});
		
		m_pInstance.setPinBoxDescriptionText({ pintype: "pinbox_one", text: m_defaultPinBoxTextOne });
		if(m_defaultPinType == "pinbox_two"){
			m_pInstance.setPinBoxDescriptionText({ pintype: "pinbox_two", text: m_defaultPinBoxTextTwo });
		}
		m_pInstance.setPinBoxFocus({pintype:"pinbox_one"});
			
		//title	
		m_pInstance.setTitlePosition({x :m_defaultTitleX ,  y:m_defaultTitleY});		
		m_pInstance.setTitleSize({ w: m_defaultTitleW, h: m_defaultTitleH });		
			
		//title line		
		m_pInstance.setTitleLineRect({ x: m_defaultTitleX, y:m_defaultTitleH, w: m_defaultTitleW, h: m_defaultTitleLineH});
		m_pInstance.setTitletTextFontSize({fontsize:m_defaultTitleFontSize});
		m_pInstance.setTitletTextColor({ color: titleTextColor });
			
		//content
		if(m_pinNumberPopupStyle == PinNumberPopupStyle.PinNumberPopupStyle_NoButton)
		{
			m_pInstance.contentText = m_defaultContentText;
			m_pInstance.setContentRect({ x: m_defaultContentTextX, y:m_defaultContentTextY, w: m_defaultContentTextW, h: m_defaultContentTextH });		
			m_pInstance.setContentTextFontSize({fontsize:m_defaultContentFontSize});
		}
			
		//pin box one text
		m_pInstance.setPinBoxDescriptionSize({ pintype: "pinbox_one", x: m_defaultPinBoxTextX, y: m_defaultPinBoxTextY, w: m_defaultPinBoxTextW, h: m_defaultPinBoxTextH });
				
		//pin box one
		m_pInstance.setPinBoxRect({ pintype: "pinbox_one", x: m_defaultPinBoxOneX, y: m_defaultPinBoxOneY, w: m_defaultPinBoxOneW, h: m_defaultPinBoxOneH });		
			
		if(m_defaultPinType == "pinbox_two"){
			//pin box two text
			m_pInstance.setPinBoxDescriptionSize({ pintype: "pinbox_two", x: m_defaultPinBoxTextTwoX, y: m_defaultPinBoxTextTwoY, w: m_defaultPinBoxTextTwoW, h: m_defaultPinBoxTextTwoH });		
				
			//pin box two
			m_pInstance.setPinBoxRect({ pintype: "pinbox_two", x: m_defaultPinBoxTwoX, y: m_defaultPinBoxTwoY, w: m_defaultPinBoxTwoW, h: m_defaultPinBoxTwoH });
			m_pInstance.setPinBoxDescriptionTextFontSize({pintype:"pinbox_all",fontsize:m_defaultPinBoxFontSize});
		}else{
			m_pInstance.setPinBoxDescriptionTextFontSize({pintype:"pinbox_one",fontsize:m_defaultPinBoxFontSize});
		}
		
		//pin box gap
		m_pInstance.setInputItemsGap({ type: "finish_input_type", gap: m_defaultInputItemsGap_FinishInput });
		m_pInstance.setInputItemsGap({ type: "no_input_type", gap: m_defaultInputItemsGap_NoInput });
		m_pInstance.setDigitGap({ gap: m_defaultDigitGap});
			
		//digit text
		m_pInstance.setDigitTextSize({ w: m_defaultDigitTextW, h: m_defaultDigitTextH });	
		
		//pin box item
		m_pInstance.setPinBoxItemImage({ state: "no_input_type", src: m_defaultPinBoxItemNormalImage});
		m_pInstance.setPinBoxItemImage({ state: "finish_input_type", src: m_defaultPinBoxItemFcousImage});		
		m_pInstance.setInputBoxItemSize({ type: "no_input_type", w: m_defaultInputBoxItemW_NoInput, h: m_defaultInputBoxItemH_NoInput});
		m_pInstance.setInputBoxItemSize({ type: "finish_input_type", w: m_defaultInputBoxItemW_FinishInput, h: m_defaultInputBoxItemH_FinishInput });		
		
		//canel button
		if(m_pinNumberPopupStyle == PinNumberPopupStyle.PinNumberPopupStyle_WithButton || m_pinNumberPopupStyle == PinNumberPopupStyle.PinNumberPopupStyle_One_Pin_WithButton)
		{
			m_pInstance.setButtonText({ buttonIndex: "button_1", state: "all", text: m_defaultButtonOneText });			
			m_pInstance.setButtonRect({ buttonIndex: "button_1", x: m_defaultButtonOneX, y: m_defaultButtonOneY, w: m_defaultButtonOneW, h: m_defaultButtonOneH});	
			
			m_pInstance.setButtonImage({ buttonIndex: "button_1", state: "normal", src: buttonBgNormal });
			m_pInstance.setButtonImage({ buttonIndex: "button_1", state: "disabled", src: buttonBgDim });
			
			m_pInstance.setButtonBackgroundColor({ buttonIndex: "button_1", state: "normal", color: buttonBgNormalColor });
			m_pInstance.setButtonBackgroundColor({ buttonIndex: "button_1", state: "focused", color: buttonBgFoucsColor });
			m_pInstance.setButtonBackgroundColor({ buttonIndex: "button_1", state: "selected", color: buttonBgFoucsColor });
			m_pInstance.setButtonBackgroundColor({ buttonIndex: "button_1", state: "disabled", color: buttonBgDimColor });
			m_pInstance.setButtonBackgroundColor({ buttonIndex: "button_1", state: "focused-roll-over", color: buttonBgRolloverColor });
			
			m_pInstance.setButtonTextColor({ buttonIndex: "button_1", state: "normal", color: normalTextColor });
			m_pInstance.setButtonTextColor({ buttonIndex: "button_1", state: "focused", color: focusTextColor });
			m_pInstance.setButtonTextColor({ buttonIndex: "button_1", state: "selected", color: focusTextColor });
			m_pInstance.setButtonTextColor({ buttonIndex: "button_1", state: "disabled", color: dimTextColor });
			m_pInstance.setButtonTextColor({ buttonIndex: "button_1", state: "focused-roll-over", color: focusTextColor });
		   
			m_pInstance.setButtonTextFontSize({ buttonIndex: "button_1",state: "all", fontSize: normalFont});
			m_pInstance.setButtonTextFontSize({ buttonIndex: "button_1", state: "normal", fontSize: normalFont });
			m_pInstance.setButtonTextFontSize({ buttonIndex: "button_1", state: "focused", fontSize: focusFont });
			m_pInstance.setButtonTextFontSize({ buttonIndex: "button_1", state: "selected", fontSize: selectFont });
			m_pInstance.setButtonTextFontSize({ buttonIndex: "button_1", state: "disabled", fontSize: dimFont });
			m_pInstance.setButtonTextFontSize({ buttonIndex: "button_1", state: "focused-roll-over", fontSize: focusFont });
		}	
		
		if(m_defaultId != null){
			m_pInstance.id = m_defaultId;
		}
		
		bHighContrast = HALOUtil.highContrast;
		if(true == bHighContrast){
			m_pInstance.color = { r: 0, g: 0, b: 0, a: 255 };	
		}
		
		var widgetExListener = new WidgetExListener;
		widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
		    if((true == flagHighContrast) && (false == bHighContrast)){
		    	m_pInstance.color = { r: 0, g: 0, b: 0, a: 255 };
		    	bHighContrast = true;
		    }
		    
		    if((false == flagHighContrast) && (true == bHighContrast)){
		    	if(null != m_defaultBgColor){
		    		m_pInstance.color = m_defaultBgColor;
		    	}
		    	bHighContrast = false;
		    }
		};
		m_pInstance.addWidgetExListener(widgetExListener);
		
		m_pInstance.destroyListener = function(){
			if(null != widgetExListener){
				m_pInstance.removeWidgetExListener(widgetExListener);
				widgetExListener.destroy();
				widgetExListener = null;
			}
		};
		
		return m_pInstance;
	}
	
	var m_analysisParameter = function(objParameter){
		Volt.log('[winsetPinNumberPopup.js @m_analysisParameter]'); 

		if("undefined" == objParameter){
			return;
		}

		if (objParameter.hasOwnProperty("nPinNumberPopupStyle") && (typeof objParameter.nPinNumberPopupStyle == "number")
			&& ( objParameter.nPinNumberPopupStyle >= PinNumberPopupStyle.PinNumberPopupStyle_NoButton)
			&& (PinNumberPopupStyle.PinNumberPopupStyle_MAX > objParameter.nPinNumberPopupStyle)){		
				m_pinNumberPopupStyle = objParameter.nPinNumberPopupStyle;
		}
		
		if(objParameter.hasOwnProperty("nbuttonStyle") && (typeof objParameter.nbuttonStyle == "number" || typeof objParameter.nbuttonStyle == "string")){
			if(typeof objParameter.nbuttonStyle == "string"){
				buttonStyle = parseInt(objParameter.nbuttonStyle);
			}else{
				buttonStyle = objParameter.nbuttonStyle;
			}
			
			if(1 > buttonStyle || ButtonStyle.Button_Style_Max <= buttonStyle){
				buttonStyle = 1;
			}
		}		
		
		if(objParameter.hasOwnProperty("buttonStyle") && (typeof objParameter.buttonStyle == "number" || typeof objParameter.buttonStyle == "string")){
			if(typeof objParameter.buttonStyle == "string"){
				buttonStyle = parseInt(objParameter.buttonStyle);
			}else{
				buttonStyle = objParameter.buttonStyle;
			}
			
			if(1 > buttonStyle || ButtonStyle.Button_Style_Max <= buttonStyle){
				buttonStyle = 1;
			}
		}
	
		if(objParameter.hasOwnProperty("nBackgroudStyle") && (typeof objParameter.nBackgroudStyle == "number")
			&& (objParameter.nBackgroudStyle >= BackgroudStyle.BG_Style_E_1)
			&& (BackgroudStyle.BG_Style_Max > objParameter.nBackgroudStyle)){		
			m_bgStyle = objParameter.nBackgroudStyle;
		}
							
		if(objParameter.hasOwnProperty("x") && (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
			if(typeof objParameter.x == "string"){
				m_defaultBgX = parseInt(objParameter.x);	
			}else{
				m_defaultBgX = objParameter.x;	
			} 
			
		}
			
		if(objParameter.hasOwnProperty("y") && (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
			if(typeof objParameter.y == "string"){
				m_defaultBgY = parseInt(objParameter.y);	
			}else{
				m_defaultBgY = objParameter.y;	
			}
		}	
			
		if(objParameter.hasOwnProperty("width") && (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
			if(typeof objParameter.width == "string"){
				m_defaultWidth = parseInt(objParameter.width);
			}else{
				m_defaultWidth = objParameter.width;
			}	
		}	
		
		if(objParameter.hasOwnProperty("height") && (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
			if(typeof objParameter.height == "string"){
				m_defaultHeight = parseInt(objParameter.height);
			}else{
				m_defaultHeight = objParameter.height;
			}			
		}
			
		if(objParameter.hasOwnProperty("id") && (typeof objParameter.id == "string")){
			m_defaultId = objParameter.id;
		}
		
		if(objParameter.hasOwnProperty("parent") && (typeof objParameter.parent == "object")){
			m_defaultParent = objParameter.parent;
		}	
		
		if(objParameter.hasOwnProperty("strContentText") &&(typeof objParameter.strContentText == "string")){
			m_defaultContentText = objParameter.strContentText;
		}		
		
		if(objParameter.hasOwnProperty("strTitleText") &&(typeof objParameter.strTitleText == "string")){
			m_defaultTitle = objParameter.strTitleText;
		}
		
		if(objParameter.hasOwnProperty("strInputDescriptionOne") &&(typeof objParameter.strInputDescriptionOne == "string")){
			m_defaultPinBoxTextOne = objParameter.strInputDescriptionOne;
		}

		if(objParameter.hasOwnProperty("strInputDescriptionTwo") &&(typeof objParameter.strInputDescriptionTwo == "string")){
			m_defaultPinBoxTextTwo = objParameter.strInputDescriptionTwo;
		}

		if(objParameter.hasOwnProperty("strButtonText") &&(typeof objParameter.strButtonText == "string")){
			m_defaultButtonOneText = objParameter.strButtonText;
		}
		
		if(objParameter.hasOwnProperty("popupStyle") && (typeof objParameter.popupStyle == "number" || typeof objParameter.popupStyle == "string")){
			if(typeof objParameter.popupStyle == "string"){
				popupStyle = parseInt(objParameter.popupStyle);	
			}else{
				popupStyle = objParameter.popupStyle;	
			}
		}	
	}
	
	var m_setDefaultValueByPinNumberPopupStyle = function(){
		Volt.log('[winsetPinNumberPopup.js @m_setDefaultValueByPinNumberPopupStyle]'); 

		// set resource path
		m_defaultTitleFontSize = 46;
		m_defaultContentFontSize = 34;
		m_defaultPinBoxFontSize = 34;
		
		//button font size
		normalFont = 32;
		focusFont = 32;
		selectFont = 32;
		rolloverFont = 32;
		dimFont = 32;	
		if(m_resolutionStyle == ResolutionStyle.Resolution_1080 || m_resolutionStyle == ResolutionStyle.Resolution_1080_21_9){
			m_imagePath = m_imagePath + "1080p";
		} else if (m_resolutionStyle == ResolutionStyle.Resolution_720 || m_resolutionStyle == ResolutionStyle.Resolution_720_21_9){
			m_imagePath = m_imagePath + "720p";
		}
				
		//pin box image
		m_defaultPinBoxBGFocusImage = m_imagePath + "/pinNumberPopup/input_box_f.png";
		m_defaultPinBoxBGNormalImage = m_imagePath + "/pinNumberPopup/input_box_n.png";
		m_defaultPinBoxItemFcousImage = m_imagePath + "/pinNumberPopup/obe_pin_f.png";
		m_defaultPinBoxItemNormalImage = m_imagePath + "/pinNumberPopup/input_pin_place.png";		
					
		//resolution
		m_defaultWidth = 1920;
		m_defaultHeight = 1080;
		m_defaultAdd = 0;				
		m_defaultTitleLineH = 1;
		m_defaultInputBoxItemW_NoInput = 30;
		m_defaultInputBoxItemH_NoInput = 40;						
		m_defaultInputBoxItemW_FinishInput = 9;	
		m_defaultInputBoxItemH_FinishInput = 9;		
		
		//popup style
		switch(m_pinNumberPopupStyle){
			case PinNumberPopupStyle.PinNumberPopupStyle_NoButton:
				{
					m_defaultButtonNum =0;
					
					//bg
					m_defaultBgW = m_defaultWidth + m_defaultAdd*2;
					m_defaultBgH = 0.502778 * m_defaultHeight;					
					
					//title
					m_defaultTitleW = 0.584375 * m_defaultWidth;
					m_defaultTitleH = 0.089815 * m_defaultHeight;		
					m_defaultTitleX = (m_defaultWidth - m_defaultTitleW)/2 + m_defaultAdd;
					m_defaultTitleY = 0;

					//content
					m_defaultContentTextW = 0.584375 * m_defaultWidth;
					m_defaultContentTextH = 0.044444 * m_defaultHeight;	
					m_defaultContentTextX = (m_defaultWidth - m_defaultContentTextW) / 2 + m_defaultAdd;
					m_defaultContentTextY = (0.089815 + 0.010185) * m_defaultHeight;		
					
					//pin box one text
					m_defaultPinBoxTextW = 0.584375 * m_defaultWidth;		
					m_defaultPinBoxTextH = 0.044444 * m_defaultHeight;		
					m_defaultPinBoxTextX = (m_defaultWidth - m_defaultPinBoxTextW)/2 + m_defaultAdd;		
					m_defaultPinBoxTextY = (0.089815 + 0.010185 + 0.044444 + 0.044444)*m_defaultHeight;		
					
					//pin box one		
					m_defaultPinBoxOneW = 0.181771 * m_defaultWidth;
					m_defaultPinBoxOneH = 0.053704 * m_defaultHeight;				
					m_defaultPinBoxOneX = (m_defaultWidth - m_defaultPinBoxOneW) / 2 + m_defaultAdd;
					m_defaultPinBoxOneY = (0.089815 + 0.010185 + 0.044444 + 0.044444 + 0.044444 + 0.014815) * m_defaultHeight;				
					
					//pin box two text		
					m_defaultPinBoxTextTwoW = 0.584375 * m_defaultWidth;	
					m_defaultPinBoxTextTwoH = 0.044444 * m_defaultHeight;
					m_defaultPinBoxTextTwoX = (m_defaultWidth - m_defaultPinBoxTextTwoW)/2 + m_defaultAdd;		;
					m_defaultPinBoxTextTwoY = (0.089815 + 0.010185 + 0.044444 + 0.044444 + 0.044444 + 0.014815 + 0.053704 + 0.028704)*m_defaultHeight;		
					
					//pin box two
					m_defaultPinBoxTwoW = 0.181771 * m_defaultWidth;
					m_defaultPinBoxTwoH = 0.053704 * m_defaultHeight;
					m_defaultPinBoxTwoX = (m_defaultWidth - m_defaultPinBoxTwoW) / 2 + m_defaultAdd;
					m_defaultPinBoxTwoY = (0.089815 + 0.010185 + 0.044444 + 0.044444 + 0.044444 + 0.014815 + 0.053704 + 0.028704 + 0.044444 + 0.014815)*m_defaultHeight;			
					
					//pin box gap
					m_defaultInputItemsGap_NoInput = 0.003125 * m_defaultWidth;
					m_defaultInputItemsGap_FinishInput = 0.016666 * m_defaultWidth;					
					m_defaultDigitGap = 0.003125 * m_defaultWidth;		
					
					//digit text
					m_defaultDigitTextW =0.015625 * m_defaultWidth;
					m_defaultDigitTextH = 0.037037 * m_defaultHeight;						
				
				}
				break;
			case PinNumberPopupStyle.PinNumberPopupStyle_WithButton:
				{				
					m_defaultButtonNum =1;		
					m_defaultHasContent = false;
				
					//bg
					m_defaultBgW = m_defaultWidth + m_defaultAdd*2;
					m_defaultBgH = 0.491667 * m_defaultHeight;					
					
					//title
					m_defaultTitleW = 0.407292 * m_defaultWidth;
					m_defaultTitleH = 0.089815 * m_defaultHeight;		
					m_defaultTitleX = (m_defaultWidth - m_defaultTitleW)/2 + m_defaultAdd;
					m_defaultTitleY = 0;
					
					//pin box one text
					m_defaultPinBoxTextW = 0.407292 * m_defaultWidth;		
					m_defaultPinBoxTextH = 0.044444 * m_defaultHeight;		
					m_defaultPinBoxTextX = (m_defaultWidth - m_defaultPinBoxTextW)/2 + m_defaultAdd;		
					m_defaultPinBoxTextY = (0.089815 + 0.025926)*m_defaultHeight;		
					
					//pin box one		
					m_defaultPinBoxOneW = 0.181771 * m_defaultWidth;
					m_defaultPinBoxOneH = 0.053704 * m_defaultHeight;				
					m_defaultPinBoxOneX = (m_defaultWidth - m_defaultPinBoxOneW) / 2 + m_defaultAdd;
					m_defaultPinBoxOneY = (0.089815 + 0.025926 + 0.044444 + 0.021296) * m_defaultHeight;				
					
					//pin box two text		
					m_defaultPinBoxTextTwoW = 0.407292 * m_defaultWidth;	
					m_defaultPinBoxTextTwoH = 0.044444 * m_defaultHeight;
					m_defaultPinBoxTextTwoX = (m_defaultWidth - m_defaultPinBoxTextTwoW)/2 + m_defaultAdd;
					m_defaultPinBoxTextTwoY = (0.089815 + 0.025926 + 0.044444 + 0.021296 + 0.053704 + 0.013889)*m_defaultHeight;		
					
					//pin box two
					m_defaultPinBoxTwoW = 0.181771 * m_defaultWidth;
					m_defaultPinBoxTwoH = 0.053704 * m_defaultHeight;
					m_defaultPinBoxTwoX = (m_defaultWidth - m_defaultPinBoxTwoW) / 2 + m_defaultAdd;
					m_defaultPinBoxTwoY = (0.089815 + 0.025926 + 0.044444 + 0.021296 + 0.053704 + 0.013889 + 0.044444 + 0.021296)*m_defaultHeight;			
					
					//pin box gap
					m_defaultInputItemsGap_NoInput = 0.003125 * m_defaultWidth;
					m_defaultInputItemsGap_FinishInput = 0.016666 * m_defaultWidth;						
					m_defaultDigitGap = 0.003125 * m_defaultWidth;		
					
					//digit text
					m_defaultDigitTextW =0.015625 * m_defaultWidth;
					m_defaultDigitTextH = 0.037037 * m_defaultHeight;						
								
					//button one
					m_defaultButtonOneW = 0.140625 * m_defaultWidth;
					m_defaultButtonOneH = 0.061111 * m_defaultHeight;
					m_defaultButtonOneX = (m_defaultWidth - m_defaultButtonOneW) / 2 + m_defaultAdd;
					m_defaultButtonOneY = m_defaultHeight * 0.491667 - m_defaultHeight * (0.061111 + 0.027778);
					
					if(buttonStyle == ButtonStyle.Button_image_O_Style_E){
					    // background
					    buttonBgNormal = m_imagePath + "/btn/btn_style_b_n.png";
						buttonBgFoucs = m_imagePath + "/btn/btn_style_b_f.png";
						buttonBgSelect = m_imagePath + "/btn/btn_style_b_s.png";
						buttonBgDim = m_imagePath + "/btn/btn_style_b_d.png";
						
						normalTextColor = { r: 64, g: 64, b: 64, a: 204 };
						focusTextColor = { r: 244, g: 244, b: 244, a: 255 };
						selectTextColor = { r: 241, g: 171, b: 21, a: 255 };
						dimTextColor = { r: 64, g: 64, b: 64, a: 76 };
						rolloverTextColor = { r: 64, g: 64, b: 64, a: 204 };
						
						buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
						buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
						buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
						buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
						buttonBgRolloverColor = { r: 33, g: 158, b: 230, a: 255 };			   
					}
		        
					if(buttonStyle == ButtonStyle.Button_image_O_Style_F){
					    // background
						buttonBgNormal = m_imagePath + "/btn/btn_style_a_n.png";
						buttonBgFoucs = m_imagePath + "/btn/btn_style_a_f.png";
						buttonBgSelect = m_imagePath + "/btn/btn_style_a_s.png";
						buttonBgDim = m_imagePath + "/btn/btn_style_a_d.png";
						
						normalTextColor = { r: 255, g: 255, b: 255, a: 204 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 255, g: 194, b: 31, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76 };
						rolloverTextColor = { r: 255, g: 255, b: 255, a: 204 };	
						
						buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
						buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242 };
						buttonBgSelectColor = { r: 0, g: 0, b: 0, a: 13 };
						buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
						buttonBgRolloverColor = { r: 255, g: 255, b: 255, a: 242 };	
					}									
				}
				break;
			
			case PinNumberPopupStyle.PinNumberPopupStyle_One_Pin_WithButton:
				{				
					m_defaultButtonNum =1;		
					m_defaultHasContent = false;
				
					//bg
					m_defaultBgW = m_defaultWidth + m_defaultAdd*2;
					m_defaultBgH = 0.412037 * m_defaultHeight;					
					
					//title
					m_defaultTitleW = 0.407292 * m_defaultWidth;
					m_defaultTitleH = 0.089815 * m_defaultHeight;		
					m_defaultTitleX = (m_defaultWidth - m_defaultTitleW)/2 + m_defaultAdd;
					m_defaultTitleY = 0;
					
					// pin
					m_defaultPinType = "pinbox_one";
					//pin box one text
					m_defaultPinBoxTextW = 0.407292 * m_defaultWidth;		
					m_defaultPinBoxTextH = 0.044444 * m_defaultHeight;		
					m_defaultPinBoxTextX = (m_defaultWidth - m_defaultPinBoxTextW)/2 + m_defaultAdd;		
					m_defaultPinBoxTextY = (0.089815 + 0.029630)*m_defaultHeight;		
					
					//pin box one		
					m_defaultPinBoxOneW = 0.181771 * m_defaultWidth;
					m_defaultPinBoxOneH = 0.053704 * m_defaultHeight;				
					m_defaultPinBoxOneX = (m_defaultWidth - m_defaultPinBoxOneW) / 2 + m_defaultAdd;
					m_defaultPinBoxOneY = (0.089815 + 0.029630 + 0.044444 + 0.046296) * m_defaultHeight;				
					
					//pin box gap
					m_defaultInputItemsGap_NoInput = 0.003125 * m_defaultWidth;
					m_defaultInputItemsGap_FinishInput = 0.016666 * m_defaultWidth;						
					m_defaultDigitGap = 0.003125 * m_defaultWidth;		
					
					//digit text
					m_defaultDigitTextW = 0.015625 * m_defaultWidth;
					m_defaultDigitTextH = 0.037037 * m_defaultHeight;						
								
					//button one
					m_defaultButtonOneW = 0.140625 * m_defaultWidth;
					m_defaultButtonOneH = 0.061111 * m_defaultHeight;
					m_defaultButtonOneX = (m_defaultWidth - m_defaultButtonOneW) / 2 + m_defaultAdd;
					m_defaultButtonOneY = m_defaultHeight * 0.412037 - m_defaultHeight * (0.061111 + 0.036111);
					
					if(buttonStyle == ButtonStyle.Button_image_O_Style_E){
					    // background
					    buttonBgNormal = m_imagePath + "/btn/btn_style_b_n.png";
						buttonBgFoucs = m_imagePath + "/btn/btn_style_b_f.png";
						buttonBgSelect = m_imagePath + "/btn/btn_style_b_s.png";
						buttonBgDim = m_imagePath + "/btn/btn_style_b_d.png";
						
						// text color
						normalTextColor = { r: 64, g: 64, b: 64, a: 204 };
						focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
						selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
						dimTextColor = { r: 64, g: 64, b: 64, a: 76.5 };	
						rolloverTextColor = { r: 255, g: 255, b: 255, a: 255 };
						
						buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
						buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
						buttonBgSelectColor = { r: 33, g: 158, b: 230, a: 255 };
						buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
						buttonBgRolloverColor = { r: 33, g: 158, b: 230, a: 255 };
								   
					}
		        
					if(buttonStyle == ButtonStyle.Button_image_O_Style_F){
					    // background
						buttonBgNormal = m_imagePath + "/btn/btn_style_a_n.png";
						buttonBgFoucs = m_imagePath + "/btn/btn_style_a_f.png";
						buttonBgSelect = m_imagePath + "/btn/btn_style_a_s.png";
						buttonBgDim = m_imagePath + "/btn/btn_style_a_d.png";
						
						// text color
						normalTextColor = { r: 255, g: 255, b: 255, a: 242.25 };
						focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
						selectTextColor = { r: 70, g: 70, b: 70, a: 255 };
						dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };	
						rolloverTextColor = { r: 70, g: 70, b: 70, a: 255 };	
						
						buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
						buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
						buttonBgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
						buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
						buttonBgRolloverColor = { r: 255, g: 255, b: 255, a: 242.25 };
					}									
				}
				break;
			
			default:
				break;
		}
	
		//backgroup sytle
		switch(m_bgStyle){
			case BackgroudStyle.BG_Style_E_1:{
				m_defaultBgColor = { r: 39, g: 124, b: 175, a: 200 };
			}
			break;
			case BackgroudStyle.BG_Style_E_2:{
				m_defaultBgColor = { r: 15, g: 24, b: 38, a: 255*0.85};
			}
			break;
			case BackgroudStyle.BG_Style_E_3:{
				m_defaultBgColor = { r: 237, g: 237, b: 237, a: 255*0.95};
			}
			break;			
			default:
				break;
		}
		
		switch(popupStyle){
			case PopupStyle.Wizard_Popup:
			{
				titleTextColor = { r: 58, g: 58, b: 58, a: 229.5 };
				titleLineColor = { r: 0, g: 0, b: 0, a: 76.5 };
			}
			break;
			
			case PopupStyle.TV_and_Smart_Hub_Popup:
			{
				titleTextColor = { r: 255, g: 255, b: 255, a: 255 };
				titleLineColor = { r: 255, g: 255, b: 255, a: 76.5 };
			}
			break;
			
			default:
				break;
		}		
	}
	
	//return the instance of native PinNumberPopup	
	return m_create(objParameter);		
}

//style type
var PinNumberPopupStyle = {
	PinNumberPopupStyle_NoButton:0,
	PinNumberPopupStyle_WithButton:1,
	PinNumberPopupStyle_One_Pin_WithButton:2,
	PinNumberPopupStyle_MAX:3,
};

var ButtonStyle = {
		Button_image_O_Style_E: 1,
	    Button_image_O_Style_F: 2,
	    Button_Style_Max: 3
};

var BackgroudStyle = {
	BG_Style_E_1:1,
	BG_Style_E_2:2,
	BG_Style_E_3:3,
	BG_Style_Max:4
};

var PopupStyle = {
	Wizard_Popup: 1,
	TV_and_Smart_Hub_Popup: 2
}

winsetPinNumberPopup.PinNumberPopupStyle = PinNumberPopupStyle;
winsetPinNumberPopup.ButtonStyle = ButtonStyle;
winsetPinNumberPopup.BackgroudStyle = BackgroudStyle;
winsetPinNumberPopup.PopupStyle = PopupStyle;

winsetPinNumberPopup.prototype = new winsetBase();

exports = winsetPinNumberPopup;