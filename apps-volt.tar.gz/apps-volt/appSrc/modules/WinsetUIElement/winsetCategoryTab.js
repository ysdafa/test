var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetCategoryTab = function(obj) {	
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	// local var
	var categorytab,
		screenWidth = 1920,
		screenHeight = 1080,
		height = -1,
		width = -1,
		x = 0,
		y = 0,
		parent = scene,
		id = null,
		style = Categorytabtyle.Categorytab_Style_A,
		resolution = ResolutionStyle.Resolution_1080,
		path = "modules/WinsetUIElement/winsetImg/",
		focusFrameImagePath,
		// background
		bgColor,
		bgImage,
		// arrow
		leftArrow,
		rightArrow,
		arrowWidth,
		arrowHeight,
		// tab
		tabSpacing,
		tabFontName = "Sans 20px",
		tabNormalFontSize,
		tabFocusFontSize,
		tabSelectFontSize,
		tabNormalTextColor = {},
		tabFocusTextColor = {},
		tabSelectTextColor = {},
		tabNormalBgColor,
		tabFocusBgColor,
		tabSelectBgColor,
		tabNormalBgImage,
		tabFocusBgImage,
		tabSelectBgImage,
		tabMargin = {},
		tabName = null,
		spliterColor,
		unFocusHighlightbarHeight = 2,
		focusHighlightbarHeight = 2,
		bHighContrast = false,
		bEnlarge = false,
		bUseFocus = true,
		enableHighlightbar,
		enableFocusFrame,
		hintBarColor = { r: 30, g: 158, b: 230, a: 255 },
    	hintBarHeight = 1;
		
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if(objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number" || typeof objParameter.style == "string")){
				if(typeof objParameter.style == "string"){
					style = parseInt(objParameter.style);	
				}else{
					style = objParameter.style;	
				}
				
				if(Categorytabtyle.Categorytab_Style_A != style){
					style = Categorytabtyle.Categorytab_Style_A;
				}		
			}
		
			// if (objParameter.hasOwnProperty("nResolutionStyle") 
				// && (typeof objParameter.nResolutionStyle == "number" || typeof objParameter.nResolutionStyle == "string")){
					// if(typeof objParameter.nResolutionStyle == "string"){
						// resolution = parseInt(objParameter.nResolutionStyle);
					// }else{
						// resolution = objParameter.nResolutionStyle;
					// }
// 					
				// if((ResolutionStyle.Resolution_720 > resolution) || (ResolutionStyle.Resolution_Style_MAX <= resolution)){
					// resolution = ResolutionStyle.Resolution_1080;
				// }	
			// }
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
				if(typeof objParameter.x == "string"){
					x = parseInt(objParameter.x);
				}else{
					x = objParameter.x;
				}		
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					y = parseInt(objParameter.y);
				}else{
					y = objParameter.y;
				}		
			}
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
				if(typeof objParameter.height == "string"){
					height = parseInt(objParameter.height);
				}else{
					height = objParameter.height;
				}	
			}
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
				if(typeof objParameter.width == "string"){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
				
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
			
			if(objParameter.hasOwnProperty("tabName")
				&& (Object.prototype.toString.call(objParameter.tabName) === "[object Array]")){
				// if(5 <= objParameter.tabName.length){
					// for(var i = 0; i < 5; i++){
						// tabName[i] = objParameter.tabName[i];
					// }
				// }
// 				
				// if(5 > objParameter.tabName.length){
					// for(var i = 0; i < objParameter.tabName.length; i++){
						// tabName[i] = objParameter.tabName[i];
					// }
				// }
				tabName = objParameter.tabName;
			}
			
			if(objParameter.hasOwnProperty("unFocusHighlightbarHeight")
				&& (typeof objParameter.unFocusHighlightbarHeight == "number" || typeof objParameter.unFocusHighlightbarHeight == "string")){
				if(typeof objParameter.unFocusHighlightbarHeight == "string"){
					unFocusHighlightbarHeight = parseInt(objParameter.unFocusHighlightbarHeight);
				}else{
					unFocusHighlightbarHeight = objParameter.unFocusHighlightbarHeight;
				}		
			}
			
			if(objParameter.hasOwnProperty("focusHighlightbarHeight")
				&& (typeof objParameter.focusHighlightbarHeight == "number" || typeof objParameter.focusHighlightbarHeight == "string")){
				if(typeof objParameter.focusHighlightbarHeight == "string"){
					focusHighlightbarHeight = parseInt(objParameter.focusHighlightbarHeight);
				}else{
					focusHighlightbarHeight = objParameter.focusHighlightbarHeight;
				}		
			}
			
			// if(objParameter.hasOwnProperty("bUseFocus")
				// && (typeof objParameter.bUseFocus == "boolean" || typeof objParameter.bUseFocus == "string")){
				// if(typeof objParameter.bUseFocus == "string"){
					// if("true" == objParameter.bUseFocus){
						// bUseFocus = true;
					// }else if("false" == objParameter.bUseFocus){
						// bUseFocus = false;
					// }
				// }else{
					// bUseFocus = objParameter.bUseFocus;
				// }	
			// }
			
			if(objParameter.hasOwnProperty("hintBarHeight")
				&& (typeof objParameter.hintBarHeight == "number" || typeof objParameter.hintBarHeight == "string")){
				if(typeof objParameter.hintBarHeight == "string"){
					hintBarHeight = parseInt(objParameter.hintBarHeight);
				}else{
					hintBarHeight = objParameter.hintBarHeight;
				}		
			}
			
			if(objParameter.hasOwnProperty("hintBarColor")
				&& (typeof objParameter.hintBarColor == "object")){
				hintBarColor = objParameter.hintBarColor;	
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		screenHeight = 1080;
		if(-1 == width){
			width = 1920;
		}
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			focusFrameImagePath = path + "1080p/highlight/";
			path = path + "1080p/categorytab/";
			
			// screenHeight = 1080;
			// if(-1 == width){
				// width = 1920;
			// }
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			focusFrameImagePath = path + "720p/highlight/";
			path = path + "720p/categorytab/";
			// screenHeight = 720;
			// if(-1 == width){
				// width = 1280;
			// }
		}
		
		if(-1 == height){
			height = 0.1 * screenHeight;
		}
		
		//set default value
		switch(style)
		{
			case Categorytabtyle.Categorytab_Style_A:
				{
					// image path
					bgColor = { r: 15, g: 24, b: 38, a:255 };
					// bgImage =
					// arrow
					leftArrow = path + "chlist_title_arrow_left_s.png";
					rightArrow = path + "chlist_title_arrow_right_s.png";
					
					// tab
					tabSpacing = 0;
					tabMargin.Top = 0;
					tabMargin.Bottom = 0; 
					tabMargin.Left = 0;
					tabMargin.Right = 0;
					tabNormalTextColor = { r: 255, g: 255, b: 255, a: 255 };
					tabFocusTextColor = { r: 255, g: 255, b: 255, a: 255  };
					tabSelectTextColor = { r: 36, g: 182, b: 244, a: 255 };
					tabNormalBgColor = { r: 255, g: 255, b: 255, a: 0 };
					tabFocusBgColor = { r: 255, g: 255, b: 255, a: 242 };
					tabSelectBgColor = { r: 255, g: 255, b: 255, a: 0 };
					
					spliterColor = { r: 255, g: 255, b: 255, a: 153 };
					
					arrowWidth = 0;
					arrowHeight = 0;
					tabNormalFontSize = 28;
					tabFocusFontSize = 33;
					tabSelectFontSize = 33;
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// arrowWidth = 18;
						// arrowHeight = 34;
						// tabNormalFontSize = 28;
						// tabFocusFontSize = 31;
						// tabSelectFontSize = 31;
					// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
						// arrowWidth = 12;
						// arrowHeight = 22;
						// tabNormalFontSize = 18;
						// tabFocusFontSize = 20;
						// tabSelectFontSize = 20;
					// }
				}
				break;
			default:
				break;
		}
	}

	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	if(true == bUseFocus){
		enableHighlightbar = false;
		enableFocusFrame = true;
	}else{
		enableHighlightbar = true;
		enableFocusFrame = false;
	}
		
	categorytab = new CategoryTab({
	    x: x,
	    y: y,
	    tabFont: "SamsungSmart_Light 28px",
	    parent: parent,
	    width: width,
	    height: height,
	    spliterColor: spliterColor,
	    enableHighlightbar: enableHighlightbar,
	    highlightbarHeight: unFocusHighlightbarHeight,
	    highlightbarFocusedColor: { r: 255, g: 255, b: 255, a: 242 },
    	highlightbarUnfocusedColor: { r: 33, g: 158, b: 230, a: 255 },
	    highligthFocusAnimation: { unfocus: unFocusHighlightbarHeight, focused: focusHighlightbarHeight, duration: 0 },
    	highligthMoveAnimationDuration: 200,
    	focusFrameImagePath: focusFrameImagePath + 'ksc_focus.png',
    	focusFrameOffset: { w: 14, x: -7, h: 14, y: -7 },
		focusFrameMoveAnimationDuration: 200,
		enableFocusFrame: enableFocusFrame,
		enableHintBar: true,
    	hintBarColor: hintBarColor,
    	hintBarHeight: hintBarHeight
	});
	
	if(null != id){
		categorytab.id = id;
	}
	
	// categorytab.enableHighlightBar(true);
	// categorytab.setHighlightBarHeight(2);
	// categorytab.setHighlightBarColor(33, 158, 230, 255);

	categorytab.setMargin(tabMargin.Top, tabMargin.Bottom, tabMargin.Left, tabMargin.Right);
	categorytab.setTabSpliterSize (2, 2);
	//categorytab.setTabSpacing(tabSpacing);
	// categorytab.enableLooping(true);
	categorytab.setArrowsSize(arrowWidth, arrowHeight);
	categorytab.setArrowsImage(leftArrow, rightArrow);
	// categorytab.setTabTextLimitWidth(200);
	// tab
	// categorytab.setTabFontName(tabFontName);
	bEnlarge = HALOUtil.enlarge;
	if(true == bEnlarge){
		categorytab.setTabFontSize("unselected", 1.5 * tabNormalFontSize);
		categorytab.setTabFontSize("selected", 1.5 * tabSelectFontSize);
		categorytab.setTabFontSize("highlighted", 1.5 * tabFocusFontSize);
		categorytab.setTabTextLimitWidth(categorytab.getTabTextLimitWidth() * 1.5);
	}else{
		categorytab.setTabFontSize("unselected", tabNormalFontSize);
		categorytab.setTabFontSize("selected", tabSelectFontSize);
		categorytab.setTabFontSize("highlighted", tabFocusFontSize);
	}
	
	categorytab.setTabTextColor("unselected", tabNormalTextColor.r, tabNormalTextColor.g, tabNormalTextColor.b, tabNormalTextColor.a);
	categorytab.setTabTextColor("selected", tabSelectTextColor.r, tabSelectTextColor.g, tabSelectTextColor.b, tabSelectTextColor.a);
	// categorytab.setTabTextColor("selected", tabSelectTextColor.r, tabSelectTextColor.g, tabSelectTextColor.b, tabSelectTextColor.a);
	categorytab.setTabTextColor("highlighted", tabFocusTextColor.r, tabFocusTextColor.g, tabFocusTextColor.b, tabFocusTextColor.a);
	
	// categorytab.setTabImage("unselected", tabNormalBgImage);
	// categorytab.setTabImage("selected", tabFocusBgImage);
	// categorytab.setTabImage("highlighted", tabSelectBgImage);
	// categorytab.setTabTextColor("unselected", tabNormalTextColor.r, tabNormalTextColor.g, tabNormalTextColor.b, tabNormalTextColor.a);
	// categorytab.setTabTextColor("selected", tabFocusTextColor.r, tabFocusTextColor.g, tabFocusTextColor.b, tabFocusTextColor.a);
	// categorytab.setTabTextColor("highlighted", tabSelectTextColor.r, tabSelectTextColor.g, tabSelectTextColor.b, tabSelectTextColor.a);
// 	
	// categorytab.setTabColor("unselected", bgColor.r, bgColor.g, bgColor.b, bgColor.a * 0.5);
	// categorytab.setTabColor("unselected", tabNormalBgColor.r, tabNormalBgColor.g, tabNormalBgColor.b, tabNormalBgColor.a);
	// categorytab.setTabColor("selected", tabSelectBgColor.r, tabSelectBgColor.g, tabSelectBgColor.b, tabSelectBgColor.a);
	// categorytab.setTabColor("highlighted", tabFocusBgColor.r, tabFocusBgColor.g, tabFocusBgColor.b, tabFocusBgColor.a);

	// categorytab.setBackgroundImage(bgImage);
	
	bHighContrast = HALOUtil.highContrast;
	if(true == bHighContrast){
		categorytab.setBackgroundColor(0, 0, 0, 255);
	}else{
		categorytab.setBackgroundColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a);
	}
	
	if(null != tabName){
		for(var i = 0; i < tabName.length; i++){
			categorytab.addTab(tabName[i]);
		}
	}
	
	
	// categorytab.addTab(tabName[0], 300, height);
	// categorytab.addTab(tabName[1], 300, height);
	// categorytab.addTab(tabName[2], 300, height);
	// categorytab.addTab(tabName[3], 300, height);
	// categorytab.addTab(tabName[4], 300, height);
	var setHighContrast = function(){
		categorytab.setBackgroundColor(0, 0, 0, 255);	
	}
	
	var setNoHighContrast = function(){
		categorytab.setBackgroundColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a);	
	}
	
	var setEnlarge = function(){
		categorytab.setTabFontSize("unselected", 1.5 * tabNormalFontSize);
		categorytab.setTabFontSize("selected", 1.5 * tabSelectFontSize);
		categorytab.setTabFontSize("highlighted", 1.5 * tabFocusFontSize);
		categorytab.setTabTextLimitWidth(categorytab.getTabTextLimitWidth() * 1.5);
		categorytab.refreshSubTabs();
	}
	
	var setNoEnlarge = function(){
		categorytab.setTabFontSize("unselected", tabNormalFontSize);
		categorytab.setTabFontSize("selected", tabSelectFontSize);
		categorytab.setTabFontSize("highlighted", tabFocusFontSize);
		categorytab.setTabTextLimitWidth(categorytab.getTabTextLimitWidth() / (1.5));
		categorytab.refreshSubTabs();
	}
	
	var widgetExListener = new WidgetExListener;
	widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
		print("flagHighContrast is " + flagHighContrast);
		print("bHighContrast is " + bHighContrast);
	    if((true == flagHighContrast) && (false == bHighContrast)){
	    	setHighContrast();
	    	bHighContrast = true;
	    }
	    
	    if((false == flagHighContrast) && (true == bHighContrast)){
	    	setNoHighContrast();
	    	bHighContrast = false;
	    }
	};
	
	widgetExListener.onEnlargeChanged = function (widgetEx, flagEnlarge) {
    	if((true == flagEnlarge) && (false == bEnlarge)){
	    	setEnlarge();
	    	bEnlarge = true;
	    }
	    
	    if((false == flagEnlarge) && (true == bEnlarge)){
	    	setNoEnlarge();
	    	bEnlarge = false;
	    }
	};

	categorytab.addWidgetExListener(widgetExListener);
	
	categorytab.destroyListener = function(){
		if(null != widgetExListener){
			categorytab.removeWidgetExListener(widgetExListener);
			widgetExListener.destroy();
			widgetExListener = null;
		}
	};

	return categorytab;
};

var Categorytabtyle = {
	Categorytab_Style_A: 1
};

winsetCategoryTab.Categorytabtyle = Categorytabtyle;
winsetCategoryTab.prototype = new winsetBase();
exports = winsetCategoryTab;

