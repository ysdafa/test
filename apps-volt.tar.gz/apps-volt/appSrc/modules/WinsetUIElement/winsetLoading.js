var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetLoading = function(obj) {
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;

	// local var
	var loading,
		height = 58,
		width = 301,
		imageWidth = 301,
		imageHeight = 58,
		textWidth = 0,
		textHeight = 0,
		x = 1500,
		y = 0,
		parent = scene,
		id = null,
		gap = 0,
		style = LoadingStyle.Loading_Bright_20,
		resolution = ResolutionStyle.Resolution_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		imageName = [],
		text = "Loading...",
		textFont,
		textColor;
	   	
	var m_analysisParameter = function(objParameter){
		Volt.log('[winsetLoading.js @m_analysisParameter]');

		if (objParameter != "undefined") {
			if (objParameter.hasOwnProperty("style") && (typeof objParameter.style == "number" || typeof objParameter.style == "string")) {
				
				if (typeof objParameter.style == "string") {
					style = parseInt(objParameter.style);
				} else {
					style = objParameter.style;	
				}
				
				if ((style < 1) || (LoadingStyle.Loading_Style_Max <= style)) {
					style = 1;
				}
			}
			
			if (objParameter.hasOwnProperty("x") && (typeof objParameter.x == "number" || typeof objParameter.x == "string")) {
				if (typeof objParameter.x == "string") {
					x = parseInt(objParameter.x);	
				} else {
					x = objParameter.x;	
				} 
				
			}
			
			if(objParameter.hasOwnProperty("y") && (typeof objParameter.y == "number" || typeof objParameter.y == "string")) {
				if (typeof objParameter.y == "string") {
					y = parseInt(objParameter.y);	
				} else {
					y = objParameter.y;	
				}
			}	
			
			if (objParameter.hasOwnProperty("width") && (typeof objParameter.width == "number" || typeof objParameter.width == "string")) {
				if (typeof objParameter.width == "string") {
					width = parseInt(objParameter.width);
				} else {
					width = objParameter.width;
				}	
			}	
			
			if (objParameter.hasOwnProperty("height") && (typeof objParameter.height == "number" || typeof objParameter.height == "string")) {
				if (typeof objParameter.height == "string") {
					height = parseInt(objParameter.height);
				} else {
					height = objParameter.height;
				}			
			}

			if (objParameter.hasOwnProperty("id") && (typeof objParameter.id == "string")) {
				id = objParameter.id;	
			}
			
			if (objParameter.hasOwnProperty("text") && (typeof objParameter.text == "string")) {
				text = objParameter.text;	
			}
				
			if (objParameter.hasOwnProperty("parent") && (typeof objParameter.parent == "object")) {
				parent = objParameter.parent;	
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		Volt.log('[winsetLoading.js @m_setDefaultValueByProgressStyle]');

		// set resource path
		if (resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9) {
			path = path + "1080p/Loading/";
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9) {
			path = path + "720p/Loading/";		
		}

		//set default value
		switch(style)
		{
			case LoadingStyle.Loading_Dark_20:
				{
					// image path
					path = path + "white/20x20/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_bright_20_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_bright_20_" + i + ".png";
					    }	
					}
					
					textFont = 40;
					gap = -1080 * 0.009259;
					imageWidth = 301;
					imageHeight = 58;
					textWidth = 0.156771 * 1920;
					textHeight = 0.055556 * 1080;
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
			
			case LoadingStyle.Loading_Dark_17:
				{
					// image path
					path = path + "white/17x17/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_bright_17_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_bright_17_" + i + ".png";
					    }	
					}

					textFont = 40;
					gap = -1080 * 0.009259;
					imageWidth = 301;
					imageHeight = 58;
					textWidth = 0.156771 * 1920;
					textHeight = 0.055556 * 1080;
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			case LoadingStyle.Loading_Dark_14:
				{
					// image path
					path = path + "white/14x14/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_bright_14_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_bright_14_" + i + ".png";
					    }	
					}
					
					textFont = 34;
					gap = -1080 * 0.005556;
					imageWidth = 206;
					imageHeight = 40;
					textWidth = 0.107292 * 1920;
					textHeight = 0.046296 * 1080;
					textColor = {r:255, g:255, b:255, a:255};
				}
				break;	
				
			case LoadingStyle.Loading_Bright_20:
				{
					// image path
					path = path + "Black/20x20/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_dark_20_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_dark_20_" + i + ".png";
					    }	
					}
					
					textFont = 40;
					gap = -1080 * 0.009259;
					imageWidth = 301;
					imageHeight = 58;
					textWidth = 0.156771 * 1920;
					textHeight = 0.055556 * 1080;
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			case LoadingStyle.Loading_Bright_17:
				{
					// image path
					path = path + "Black/17x17/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_dark_17_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_dark_17_" + i + ".png";
					    }	
					}
					
					textFont = 40;
					gap = -1080 * 0.009259;
					imageWidth = 301;
					imageHeight = 58;
					textWidth = 0.156771 * 1920;
					textHeight = 0.055556 * 1080;
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
				
				case LoadingStyle.Loading_Bright_14:
				{
					// image path
					path = path + "Black/14x14/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_dark_14_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_dark_14_" + i + ".png";
					    }	
					}
					
					textFont = 34;
					gap = -1080 * 0.005556;
					imageWidth = 206;
					imageHeight = 40;
					textWidth = 0.107292 * 1920;
					textHeight = 0.046296 * 1080;
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
			
			// to be delete
			case LoadingStyle.Loading_Apps_White:
				{
					// image path
					path = path + "white/20x20/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_bright_20_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_bright_20_" + i + ".png";
					    }	
					}

					if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						textFont = 32;
						gap = 1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.268750 * 1920;
						textHeight = 0.037037 * 1080;
					} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
						textFont = 21;
						gap = 720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.268750 * 1280;
						textHeight = 0.037037 * 720;		
					}
					
					textColor = {r:255, g:255, b:255, a:217};
				}
				break;
			
			// to be delete	
			case LoadingStyle.Loading_Apps_Black:
				{
					// image path
					path = path + "Black/20x20/";
					
					for (var i = 1; i <= 63; ++i) {
					    if (i < 10) {
					        imageName[i-1] = "loading_dark_20_0" + i + ".png";
					    } else {
					        imageName[i-1] = "loading_dark_20_" + i + ".png";
					    }	
					}
	
					if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						textFont = 32;
						gap = 1080 * 0.009259;
						imageWidth = 301;
						imageHeight = 58;
						textWidth = 0.268750 * 1920;
						textHeight = 0.037037 * 1080;
					} else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
						textFont = 21;
						gap = 720 * 0.009259;
						imageWidth = 201;
						imageHeight = 39;
						textWidth = 0.268750 * 1280;
						textHeight = 0.037037 * 720;					
					}
					
					textColor = {r:58, g:58, b:58, a:230};
				}
				break;
				
			default:
				break;
		}
	}

	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	loading = new Loading({
		imageNum: 63,
        x: x,
        y: y,
        parent: parent,
        imageWidth: imageWidth,
		imageHeight: imageHeight,
		textWidth: textWidth,
		textHeight: textHeight,
        gap: gap,
        imageFPS: 15,
        fontSize: textFont,
        text: text,
        imagePath: path,
        imageName: imageName,
        fontName: "SamsungSmart_Light 32px",
        textColor: textColor
	});
	
	if(id != null){
		loading.id = id;	
	}
	
	return loading;
};

var LoadingStyle = {
	Loading_Bright_20:1,
	Loading_Bright_17:2,
	Loading_Bright_14:3,
	Loading_Dark_20:4,
	Loading_Dark_17:5,
	Loading_Dark_14:6,
	Loading_Apps_White:7, // to be delete
	Loading_Apps_Black:8, // to be delete
	Loading_Style_Max:9
};

winsetLoading.LoadingStyle = LoadingStyle;
winsetLoading.prototype = new winsetBase();

exports = winsetLoading;

