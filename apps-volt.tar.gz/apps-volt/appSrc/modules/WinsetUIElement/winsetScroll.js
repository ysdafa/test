var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetScroll = function(obj) {
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;

	// local var
	var scroll = null,
		height = -1,
		width = -1,
		parent = scene,
		id = null,
		x = 0,
		y = 0,
		minValue = 0,
		maxValue = 100,
		value = 50,
		style = ScrollStyle.Scroll_Style_C,
		resolution = ResolutionStyle.Resolution_1080,
		path = "modules/WinsetUIElement/winsetImg/",
		pointingNormalThumbImageWidth = 5,
		pointingNormalThumbImageHeight = 40,
		pointingOverThumbImageWidth = 21,
		pointingOverThumbImageHeight = 40,
		pointingFocusThumbImageWidth = 29,
		pointingFocusThumbImageHeight = 49,
		pointingNormalThumbImage = null,
		pointingOverThumbImage = null,
		pointingFocusThumbImage = null,
		bgFocusImage = null,
		bgNormalImage = null,
		direction,
		bgColor = null,
		screenWidth,
		screenHeight;
		
	   	
	var m_analysisParameter = function(objParameter){
		if("undefined" != objParameter){
			if (objParameter.hasOwnProperty("style") 
				&& (typeof objParameter.style == "number" || typeof objParameter.style == "string")){
				
				if(typeof objParameter.style == "string"){
					style = parseInt(objParameter.style);
				}else{
					style = objParameter.style;	
				}
				
				if((1 > style) || (ScrollStyle.Scroll_Style_Max <= style)){
					style = 1;
				}
			}
			
			// if(objParameter.hasOwnProperty("nResolutionStyle") 
				// && (typeof objParameter.nResolutionStyle == "number" || typeof objParameter.nResolutionStyle == "string")){
					// if(typeof objParameter.nResolutionStyle == "string"){
						// resolution = parseInt(objParameter.nResolutionStyle);
					// }else{
						// resolution = objParameter.nResolutionStyle;
					// }
// 					
				// if((ResolutionStyle.Resolution_720 > resolution) || (ResolutionStyle.Resolution_Style_MAX <= resolution)){
					// resolution = ResolutionStyle.Resolution_1080;
				// }	
			// }
			
			if(objParameter.hasOwnProperty("x")
				&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
				if(typeof objParameter.x == "string"){
					x = parseInt(objParameter.x);	
				}else{
					x = objParameter.x;	
				} 
				
			}
			
			if(objParameter.hasOwnProperty("y")
				&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					y = parseInt(objParameter.y);	
				}else{
					y = objParameter.y;	
				}
			}	
			
			if(objParameter.hasOwnProperty("width")
				&& (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
				if(typeof objParameter.width == "string"){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}	
			
			if(objParameter.hasOwnProperty("height")
				&& (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
				if(typeof objParameter.height == "string"){
					height = parseInt(objParameter.height);
				}else{
					height = objParameter.height;
				}			
			}
			
			if(objParameter.hasOwnProperty("id")
				&& (typeof objParameter.id == "string")){
				id = objParameter.id;	
			}
			
			if(objParameter.hasOwnProperty("parent")
				&& (typeof objParameter.parent == "object")){
				parent = objParameter.parent;	
			}
			
			if(objParameter.hasOwnProperty("minValue")
				&& (typeof objParameter.minValue == "number" || typeof objParameter.minValue == "string")){
				if(typeof objParameter.minValue == "string"){
					minValue = parseInt(objParameter.minValue);
				}else{
					minValue = objParameter.minValue;
				}
					
			}
			
			if(objParameter.hasOwnProperty("maxValue")
				&& (typeof objParameter.maxValue == "number" || typeof objParameter.maxValue == "string")){
				if(typeof objParameter.maxValue == "string"){
					maxValue = parseInt(objParameter.maxValue);
				}else{
					maxValue = objParameter.maxValue;
				}		
			}
			
			if(objParameter.hasOwnProperty("value")
				&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
				if(typeof objParameter.y == "string"){
					value = parseInt(objParameter.value);
				}else{
					value = objParameter.value;
				}
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		// set resource path
		screenWidth = 1920;
		screenHeight = 1080;
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			path = path + "1080p/scroll/";
			// if(resolution == ResolutionStyle.Resolution_1080){
				// screenWidth = 1920;
			// }else{
				// screenWidth = 2520;
			// }
			// screenHeight = 1080;
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			path = path + "720p/scroll/";
			// if(resolution == ResolutionStyle.Resolution_720){
				// screenWidth = 1280;
			// }else{
				// screenWidth = 1680;
			// }
			// screenHeight = 720;
		}

		//set default value
		switch(style)
		{
			case ScrollStyle.Scroll_Style_A:
			case ScrollStyle.Scroll_Style_B:
			case ScrollStyle.Scroll_Style_C:
				{
					// image path
					pointingNormalThumbImage = path + "chvol_scroll_nor.png";
					pointingOverThumbImage = path + "chvol_scroll_over.png";
					pointingFocusThumbImage = path + "chvol_scroll_focus.png";
					
					bgFocusImage = path + "chvol_scroll_bg_nor.PNG";
					bgNormalImage = path + "chvol_scroll_bg_focus.PNG";
					
					pointingNormalThumbImageWidth = 5;
					pointingNormalThumbImageHeight = 40;
					pointingOverThumbImageWidth = 21;
					pointingOverThumbImageHeight = 40;
					pointingFocusThumbImageWidth = 29;
					pointingFocusThumbImageHeight = 49;
					
					if(0 > height){
						height = 1080;				
					}
					if(0 > width){
						width = 5;
					}
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// pointingNormalThumbImageWidth = 5;
						// pointingNormalThumbImageHeight = 40;
						// pointingOverThumbImageWidth = 21;
						// pointingOverThumbImageHeight = 40;
						// pointingFocusThumbImageWidth = 29;
						// pointingFocusThumbImageHeight = 49;
// 						
						// if(0 > height){
							// height = 1080;				
						// }
						// if(0 > width){
							// width = 5;
						// }
					// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
						// pointingNormalThumbImageWidth = 4;
						// pointingNormalThumbImageHeight = 26;
						// pointingOverThumbImageWidth = 14;
						// pointingOverThumbImageHeight = 26;
						// pointingFocusThumbImageWidth = 19;
						// pointingFocusThumbImageHeight = 32;
// 						
						// if(0 > height){
							// height = 720;
						// }
						// if(0 > width){
							// width = 4;
						// }				
					// }
				}
				direction = "vertical";
				break;
			
			case ScrollStyle.Scroll_Style_D:
				{
					// image path
					pointingNormalThumbImage = path + "keyscreen_scroll_pn.png";
					pointingOverThumbImage = path + "keyscreen_scroll_pn.png";
					pointingFocusThumbImage = path + "keyscreen_scroll_pn.png";
					
					pointingNormalThumbImageWidth = 0.018750 * screenWidth;
					pointingNormalThumbImageHeight = 0.004630 * screenHeight;
					pointingOverThumbImageWidth = 0.018750 * screenWidth;
					pointingOverThumbImageHeight = 0.004630 * screenHeight;
					pointingFocusThumbImageWidth = 0.018750 * screenWidth;
					pointingFocusThumbImageHeight = 0.004630 * screenHeight;
					if(0 > height){
						height = 0.004630 * screenHeight;				
					}
					if(0 > width){
						width = screenWidth;
					}
					
					// if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
						// pointingNormalThumbImageWidth = 0.018750 * screenWidth;
						// pointingNormalThumbImageHeight = 0.004630 * screenHeight;
						// pointingOverThumbImageWidth = 0.018750 * screenWidth;
						// pointingOverThumbImageHeight = 0.004630 * screenHeight;
						// pointingFocusThumbImageWidth = 0.018750 * screenWidth;
						// pointingFocusThumbImageHeight = 0.004630 * screenHeight;
						// if(0 > height){
							// height = 0.004630 * screenHeight;				
						// }
						// if(0 > width){
							// width = screenWidth;
						// }
					// } else if(resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){						
						// pointingNormalThumbImageWidth = 4;
						// pointingNormalThumbImageHeight = 26;
						// pointingOverThumbImageWidth = 14;
						// pointingOverThumbImageHeight = 26;
						// pointingFocusThumbImageWidth = 19;
						// pointingFocusThumbImageHeight = 32;
						// if(0 > height){
							// height = 0.004630 * screenHeight;				
						// }
						// if(0 > width){
							// width = screenWidth;
						// }				
					// }
				}
				direction = "horizontal";
				break;
			
			default:
				break;
		}
	}

	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	if(ScrollStyle.Scroll_Style_C == style){
		scroll = new Scroll({
			x: x,
			y: y,
			// id: id,
			minValue: minValue,
			maxValue: maxValue,
			value: value,
			parent: parent,
			width: width,
			height: height,
			trackShadowHeight: 0,
			direction: direction,
			active: true,
			color: { r: 0, g: 0, b: 0, a: 0 },
			backgroundColor: { r: 255, g: 0, b: 0, a: 0 },
			trackShadowColor: { r: 255, g: 0, b: 0, a: 0 },
			
			pointingNormalThumbImageWidth: pointingNormalThumbImageWidth,
			pointingNormalThumbImageHeight: pointingNormalThumbImageHeight,
			pointingNormalThumbImage: pointingNormalThumbImage,
			pointingOverThumbImageWidth: pointingOverThumbImageWidth,
			pointingOverThumbImageHeight: pointingOverThumbImageHeight,
			pointingOverThumbImage: pointingOverThumbImage,
			pointingFocusThumbImageWidth: pointingFocusThumbImageWidth,
			pointingFocusThumbImageHeight: pointingFocusThumbImageHeight,
			pointingFocusThumbImage: pointingFocusThumbImage,
			rolloverTopTrackHeight: pointingOverThumbImageWidth,
			// backgroud
			pointingNormalBackgroundImage: bgFocusImage,
			pointingOverBackgroundImage: bgNormalImage
		});
	}else if(ScrollStyle.Scroll_Style_D == style){
		scroll = new Scroll({
			parent: parent,
			width: width,
			height: height,
			direction: direction,
			// color: { r: 0, g: 0, b: 0, a: 0 },
			// backgroundColor: { r: 255, g: 0, b: 0, a: 255 },
			// trackShadowColor: { r: 0, g: 255, b: 0, a: 255 },
			x: x,
			y: y,
		
			// id: id,
			minValue: minValue,
			maxValue: maxValue,
			currentValue: value,
			trackShadowHeight: screenHeight * 0.000926,
			pointingNormalThumbImageWidth: pointingNormalThumbImageWidth,
			pointingNormalThumbImageHeight: pointingNormalThumbImageHeight,
			pointingNormalThumbImage: pointingNormalThumbImage,
			pointingOverThumbImageWidth: pointingOverThumbImageWidth,
			pointingOverThumbImageHeight: pointingOverThumbImageHeight,
			pointingOverThumbImage: pointingOverThumbImage,
			pointingFocusThumbImageWidth: pointingFocusThumbImageWidth,
			pointingFocusThumbImageHeight: pointingFocusThumbImageHeight,
			pointingFocusThumbImage: pointingFocusThumbImage,
			rolloverTopTrackHeight: 0.004630 * screenHeight
		});
		
		scroll.setBackgroundColor(220, 220, 220, 51);
		scroll.setTrackShadowColor(0, 0, 0, 51);
	}
	
	if(null != scroll){
		if(null != id){
			scroll.id = id;
		}
		
		scroll.active = true;
	}
	
	return scroll;
};

var ScrollStyle = {
	Scroll_Style_A: 1,
	Scroll_Style_B: 2,
	Scroll_Style_C: 3,
	Scroll_Style_D: 4,
	Scroll_Style_Max: 5
};

winsetScroll.ScrollStyle = ScrollStyle;
winsetScroll.prototype = new winsetBase();

exports = winsetScroll;

