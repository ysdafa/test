var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetBackground = function(obj) {
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	// local var
	var bg,
		x = 0,
		y = 0,
		height = -1,
		width = -1,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
	    bgColor = null,
	    bgHighContrastColor = null,
	    parent = scene,
	    bHighContrast = false,
	    id = null,
	    style = -1;
		
	//style(highcontrast (0,1), x, y, width, height, id, parent, bgcolor, bghighcontrastcolor
	var m_analysisParameter = function(objParameter){
		Volt.log('[winsetBackground.js @m_analysisParameter]');

		if (objParameter != "undefined") {
			if (objParameter.hasOwnProperty("style") && (typeof objParameter.style =="number" || typeof objParameter.style == "string")) {
				if (typeof objParameter.style == "string") {
					style = parseInt(objParameter =="string");
				} else {
					style = objParameter.style;
				}
			}

			if (objParameter.hasOwnProperty("x") && (typeof objParameter.x == "number" || typeof objParameter.x == "string")) {
				if (typeof objParameter.x == "string") {
					x = parseInt(objParameter.x);	
				} else {
					x = objParameter.x;	
				} 
				
			}
			
			if (objParameter.hasOwnProperty("y") && (typeof objParameter.y == "number" || typeof objParameter.y == "string")) {
				if (typeof objParameter.y == "string") {
					y = parseInt(objParameter.y);	
				} else {
					y = objParameter.y;	
				}
			}	
			
			if (objParameter.hasOwnProperty("width") && (typeof objParameter.width == "number" || typeof objParameter.width == "string")) {
				if(typeof objParameter.width == "string"){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}	
			
			if (objParameter.hasOwnProperty("height") && (typeof objParameter.height == "number" || typeof objParameter.height == "string")) {
				if (typeof objParameter.height == "string") {
					height = parseInt(objParameter.height);
				} else {
					height = objParameter.height;
				}			
			}
			
			if (objParameter.hasOwnProperty("id") && (typeof objParameter.id == "string")) {
				id = objParameter.id;	
			}
			
			if (objParameter.hasOwnProperty("parent") && (typeof objParameter.parent == "object")) {
				parent = objParameter.parent;	
			}
			
			if (objParameter.hasOwnProperty("bgColor") && (typeof objParameter.bgColor == "object")) {
				bgColor = objParameter.bgColor;	
			}
			
			if (objParameter.hasOwnProperty("bgHighContrastColor") && (typeof objParameter.bgHighContrastColor == "object")) {
				bgHighContrastColor = objParameter.bgHighContrastColor;	
			}
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		Volt.log('[winsetBackground.js @m_setDefaultValueByProgressStyle]');

		// set resource path
		if (width == -1) {
			width = 1920;
		}	
		if (height == -1) {
			height = 1080;
		}
		
		if (bgColor == null) {
			bgColor = { r: 0, g: 0, b: 0, a: 0 };
		}
		if (bgHighContrastColor == null) {
			bgHighContrastColor = { r: 0, g: 0, b: 0, a: 255 };
		}
		//set default value
		switch(style)
		{
			case BackgroundStyle.HighContrast_Background:
				{
					bHighContrast = true;
				}
				break;
			default:
				break;
		}
		
		
	}

	resolution = getResolution();	
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	bHighContrast = HALOUtil.highContrast;
	
	bg = new WidgetEx({
		x: x,
	    y: y,
		parent: parent,
	    width: width,
	    height: height
	});
	
	if (bHighContrast == true) {
		bg.color = bgHighContrastColor;
	} else {
		bg.color = bgColor;
	}
	
	if (id != null) {
		bg.id = id;
	}
	
	var widgetExListener = new WidgetExListener;
	widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
		print("flagHighContrast is " + flagHighContrast);
		print("bHighContrast is " + bHighContrast);

		if ((flagHighContrast == true) && (bHighContrast == false)) {
	    	bg.color = bgHighContrastColor;
	    	bHighContrast = true;
	    }
	    if ((flagHighContrast == false) && (bHighContrast == true)) {
	    	if (bgColor != null) {
	    		bg.color = bgColor;
	    	}
	    	bHighContrast = false;
	    }
	};
	bg.addWidgetExListener(widgetExListener);

	bg.setBackgroundColor = function(color){
		bgColor = color;
	};
	
	bg.getBackgroundColor = function(){
		return bgColor;
	};
	
	bg.destroyListener = function(){
		if (widgetExListener != null) {
			bg.removeWidgetExListener(widgetExListener);
			widgetExListener.destroy();
			widgetExListener = null;
		}
	};

	return bg;
};

var BackgroundStyle = {
	HighContrast_Background: 1,
};


winsetBackground.BackgroundStyle = BackgroundStyle;
winsetBackground.prototype = new winsetBase();

exports = winsetBackground;

