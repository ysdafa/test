var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetCheckBox = function(obj){		
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	// local var
	var style = CheckBoxStyle.Checkbox_Style_A,
		resolution = ResolutionStyle.Resolution_1080,
		path = "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/",
		checkBox,
		x = 0,
		y = 0,
		width = 40,
		height = 40,
		parent = scene,
		id = null,
		// image path
		bgNormal = null,
		bgFoucs = null,
		bgSelect = null,
		bgDim = null,
		normalCheckImagePath = null,
		foucsCheckImagePath = null,
		selectCheckImagePath = null,
		dimCheckImagePath = null,
		// image opcity
		bgNormalOpacity,
		bgFoucsOpacity,
		bgSelectOpacity,
		bgDimOpacity,
		normalCheckImageOpacity,
		foucsCheckImageOpacity,
		selectCheckImageOpacity,
		dimCheckImageOpacity;
			
	var m_analysisParameter = function(objParameter){
		Volt.log('[winsetCheckBox.js @m_analysisParameter]');

		if (objParameter != "undefined") {
			if (objParameter.hasOwnProperty("style") && (typeof objParameter.style == "number" || typeof objParameter.style == "string")) {
				if (typeof objParameter.style == "string") {
					style = parseInt(objParameter.style);
				} else {
					style = objParameter.style;	
				}
				
				if((style < 1) || (CheckBoxStyle.Checkbox_Style_Max <= style)){
					style = 1;
				}
			}
				
			if (objParameter.hasOwnProperty("x") && (typeof objParameter.x == "number" || typeof objParameter.x == "string")) {
				if (typeof objParameter.x == "string") {
					x = parseInt(objParameter.x);	
				} else {
					x = objParameter.x;	
				} 
				
			}
			
			if (objParameter.hasOwnProperty("y") && (typeof objParameter.y == "number" || typeof objParameter.y == "string")) {
				if (typeof objParameter.y == "string") {
					y = parseInt(objParameter.y);	
				} else {
					y = objParameter.y;	
				}
			}	
			
			if (objParameter.hasOwnProperty("width") && (typeof objParameter.width == "number" || typeof objParameter.width == "string")) {
				if (typeof objParameter.width == "string") {
					width = parseInt(objParameter.width);
				} else {
					width = objParameter.width;
				}	
			}	
			
			if (objParameter.hasOwnProperty("height") && (typeof objParameter.height == "number" || typeof objParameter.height == "string")) {
				if (typeof objParameter.height == "string") {
					height = parseInt(objParameter.height);
				} else {
					height = objParameter.height;
				}			
			}
			
			if (objParameter.hasOwnProperty("id") && (typeof objParameter.id == "string")) {
				id = objParameter.id;	
			}
				
			if (objParameter.hasOwnProperty("parent") && (typeof objParameter.parent == "object")) {
				parent = objParameter.parent;	
			}
		}		
	}
			
	var m_setDefaultValueByProgressStyle = function(){
		Volt.log('[winsetCheckBox.js @m_setDefaultValueByProgressStyle]');

		// set resource path
		width = 40;
		height = 40;
		if (resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9) {
			path = path + "1080p/check/";
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9) {
			path = path + "720p/check/";
		}
		//set default value
		switch(style)
		{	
			case CheckBoxStyle.Checkbox_Style_A:
			case CheckBoxStyle.Checkbox_Style_D:
				{
					// image path
					bgNormal = path + "popup_check_box_d.png";
					bgFoucs = path + "popup_check_box_w.png";
					bgSelect = path + "popup_check_box_y.png";
					bgDim = path + "popup_check_box_d.png";
					
					normalCheckImagePath = path + "popup_check_icon_b.png";
					foucsCheckImagePath = path + "popup_check_icon_w.png";
					selectCheckImagePath = path + "popup_check_icon_y.png";
					dimCheckImagePath = path + "popup_check_icon_d.png";
					
					// image opcity
					bgNormalOpacity = 76.5;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 25.5;
					normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;
					dimCheckImageOpacity = 25.5;				
				}
				break;
			
			case CheckBoxStyle.Checkbox_Style_E_Focus1:
			case CheckBoxStyle.Checkbox_Style_B_Focus1:
			case CheckBoxStyle.Checkbox_Style_E:
			case CheckBoxStyle.Checkbox_Style_B_Focus2:
			case CheckBoxStyle.Checkbox_Style_E_Focus2:
				{
					// image path
					bgNormal = path + "popup_check_box_w.png";
					bgFoucs = path + "popup_check_box_d.png";
					bgSelect = path + "popup_check_box_y.png";
					bgDim = path + "popup_check_box_w.png";
					
					normalCheckImagePath = path + "popup_check_icon_w.png";
					foucsCheckImagePath = path + "popup_check_icon_d.png";
					selectCheckImagePath = path + "popup_check_icon_y.png";
					dimCheckImagePath = path + "popup_check_icon_w.png";
					
					// image opcity
					bgNormalOpacity = 153;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 102;
					normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;
					dimCheckImageOpacity = 102;			
				}
				break;
			
			case CheckBoxStyle.Checkbox_Style_C:
			case CheckBoxStyle.Checkbox_Style_F_Normal1:
			case CheckBoxStyle.Checkbox_Style_F_Wizard_Sub_Popup:
				{
					// check image path
					normalCheckImagePath = path + "popup_sub_check_icon_d.png";
					foucsCheckImagePath = path + "popup_sub_check_icon_w.png";
					selectCheckImagePath = path + "popup_sub_check_icon_y.png";
					
					// check image opcity
					normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;				
				}	
			break;
			
			case CheckBoxStyle.Checkbox_Style_F_Normal2:
			case CheckBoxStyle.Checkbox_Style_F_TV_and_Smart_Hub_Sub_Popup:
				{
					// check image path
					normalCheckImagePath = path + "popup_sub_check_icon_w.png";
					foucsCheckImagePath = path + "popup_sub_check_icon_d.png";
					selectCheckImagePath = path + "popup_sub_check_icon_y.png";
					
					// check image opcity
					normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;				
				}	
			break;
			
			case CheckBoxStyle.Checkbox_Style_D_Default:
				{
					// image path
					bgNormal = path + "popup_check_box_d.png";
					bgFoucs = path + "popup_check_box_w.png";
					bgSelect = path + "popup_check_box_y.png";
					bgDim = path + "popup_check_box_d.png";
					
					// normalCheckImagePath = path + "popup_check_icon_b.png";
					foucsCheckImagePath = path + "popup_check_icon_w.png";
					selectCheckImagePath = path + "popup_check_icon_y.png";
					dimCheckImagePath = path + "popup_check_icon_d.png";
					
					// image opcity
					bgNormalOpacity = 76.5;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 25.5;
					// normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;
					dimCheckImageOpacity = 25.5;			
				}	
			break;
			
			case CheckBoxStyle.Checkbox_Style_E_Default:
				{
					// image path
					bgNormal = path + "popup_check_box_w.png";
					bgFoucs = path + "popup_check_box_d.png";
					bgSelect = path + "popup_check_box_y.png";
					bgDim = path + "popup_check_box_w.png";
					
					// normalCheckImagePath = path + "popup_check_icon_w.png";
					foucsCheckImagePath = path + "popup_check_icon_d.png";
					selectCheckImagePath = path + "popup_check_icon_y.png";
					dimCheckImagePath = path + "popup_check_icon_w.png";
					
					// image opcity
					bgNormalOpacity = 153;
					bgFoucsOpacity = 153;
					bgSelectOpacity = 153;
					bgDimOpacity = 102;
					// normalCheckImageOpacity = 255;
					foucsCheckImageOpacity = 255;
					selectCheckImageOpacity = 255;
					dimCheckImageOpacity = 102;					
				}	
			break;
			default:
				break;
		}
	}
		
	
	resolution = getResolution();
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	//create button instance 
	checkBox = new SelectButton({
		x: x,
		y: y,
		width: width,
		height: height,
		color: { r:0, g:0, b:0, a:0},
		parent: parent
	});

	if (id != null) {
		checkBox.id = id;
	}
	
	// set background attr
	if (bgNormal != null) {
		checkBox.setBoxBackGroudImage({ state: "normal", imageSrc: bgNormal });
		checkBox.setBoxBackGroudImageOpacity({ state: "normal", opacity: bgNormalOpacity });
	}	
	
	if (bgFoucs != null) {
		checkBox.setBoxBackGroudImage({ state: "focused", imageSrc: bgFoucs });
		checkBox.setBoxBackGroudImageOpacity({ state: "focused",opacity: bgFoucsOpacity });
	}
	if (bgSelect != null) {
		checkBox.setBoxBackGroudImage({ state: "selected", imageSrc: bgSelect });
		checkBox.setBoxBackGroudImageOpacity({ state: "selected",opacity: bgSelectOpacity });
	}
	if (bgDim != null) {
		checkBox.setBoxBackGroudImage({ state: "disabled", imageSrc: bgDim });
		checkBox.setBoxBackGroudImageOpacity({ state: "disabled",opacity: bgDimOpacity });
	}
	
	// set check image attr
	if (normalCheckImagePath != null) {
		checkBox.setCheckImage({ state: "normal", imageSrc: normalCheckImagePath });
		checkBox.setCheckImageOpacity({ state: "normal", opacity: normalCheckImageOpacity });
	}
	if (foucsCheckImagePath != null) {
		checkBox.setCheckImage({ state: "focused", imageSrc: foucsCheckImagePath });
		checkBox.setCheckImageOpacity({ state: "focused", opacity: foucsCheckImageOpacity });
	}
    if (selectCheckImagePath != null) {
    	checkBox.setCheckImage({ state: "selected", imageSrc: selectCheckImagePath });
    	checkBox.setCheckImageOpacity({ state: "selected", opacity: selectCheckImageOpacity });
    }
    if (dimCheckImagePath != null) {
    	checkBox.setCheckImage({ state: "disabled", imageSrc: dimCheckImagePath });
    	checkBox.setCheckImageOpacity({ state: "disabled", opacity: dimCheckImageOpacity });
    }
       
    return checkBox;
}

var CheckBoxStyle = {
	Checkbox_Style_A: 1, // to be delete
	Checkbox_Style_B_Focus1: 2, // to be delete
	Checkbox_Style_B_Focus2: 3, // to be delete
	Checkbox_Style_C: 4, // to be delete
	Checkbox_Style_D: 5,
	Checkbox_Style_D: 5,
	Checkbox_Style_E_Focus1: 6, // to be delete
	Checkbox_Style_E_Focus2: 7, // to be delete
	Checkbox_Style_F_Normal1: 8, // to be delete
	Checkbox_Style_F_Normal2: 9, // to be delete
	Checkbox_Style_E: 10,
	Checkbox_Style_F_Wizard_Sub_Popup: 11,
	Checkbox_Style_F_TV_and_Smart_Hub_Sub_Popup: 12,
	Checkbox_Style_D_Default: 13,
	Checkbox_Style_E_Default: 14,
	Checkbox_Style_Max: 15
};

winsetCheckBox.CheckBoxStyle =  CheckBoxStyle;
winsetCheckBox.prototype = new winsetBase();

exports = winsetCheckBox;
