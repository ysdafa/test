var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetToolTip = function(obj) {
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;

	// local var
	var balloon,
		height = 300,
		width = 300,
		x = 1500,
		y = 0,
		id = null,
		text = 'Tooltip',
		parent = scene,
		style = TooltipStyle.Balloon_Tail_Down,
		resolution = ResolutionStyle.Resolution_1080,
		path = '$VOLT_ROOT/modules/WinsetUIElement/winsetImg/',
		tail_width,
		tail_height,
		tail_side,
	    tail_distance,
	    tailPostion = 'start',
	    frame_width = 0;
		
	   	
	var m_analysisParameter = function(objParameter){
		Volt.log('[winsetToolTip.js @m_analysisParameter]');

		if('undefined' != objParameter){
			if (objParameter.hasOwnProperty('style') && (typeof objParameter.style == 'number' || typeof objParameter.style == 'string')){
				if(typeof objParameter.style == 'string'){
					style = parseInt(objParameter.style);
				}else{
					style = objParameter.style;	
				}
				
				if((1 > style) || (TooltipStyle.Tooltip_Style_Max <= style)){
					style = 1;
				}
			}
			
			if(objParameter.hasOwnProperty('x') && (typeof objParameter.x == 'number' || typeof objParameter.x == 'string')){
				if(typeof objParameter.x == 'string'){
					x = parseInt(objParameter.x);	
				}else{
					x = objParameter.x;	
				} 
			}
			
			if(objParameter.hasOwnProperty('y') && (typeof objParameter.y == 'number' || typeof objParameter.y == 'string')){
				if(typeof objParameter.y == 'string'){
					y = parseInt(objParameter.y);	
				}else{
					y = objParameter.y;	
				}
			}	
			
			if(objParameter.hasOwnProperty('width') && (typeof objParameter.width == 'number' || typeof objParameter.width == 'string')){
				if(typeof objParameter.width == 'string'){
					width = parseInt(objParameter.width);
				}else{
					width = objParameter.width;
				}	
			}	
			
			if(objParameter.hasOwnProperty('height') && (typeof objParameter.height == 'number' || typeof objParameter.height == 'string')){
				if(typeof objParameter.height == 'string'){
					height = parseInt(objParameter.height);
				}else{
					height = objParameter.height;
				}			
			}
			
			if(objParameter.hasOwnProperty('tailPostion') && (typeof objParameter.tailPostion == 'string')){
				tailPostion = objParameter.tailPostion;	
			}
			
			if(objParameter.hasOwnProperty('id') && (typeof objParameter.id == 'string')){
				id = objParameter.id;	
			}
			
			if(objParameter.hasOwnProperty('text') && (typeof objParameter.text == 'string')){
				text = objParameter.text;	
			}
			
			if(objParameter.hasOwnProperty('parent') && (typeof objParameter.parent == 'object')){
				parent = objParameter.parent;	
			}	
		}	
	}

	var m_setDefaultValueByProgressStyle = function(){
		Volt.log('[winsetToolTip.js @m_setDefaultValueByProgressStyle]');

		// set resource path
		if(resolution == ResolutionStyle.Resolution_1080 || resolution == ResolutionStyle.Resolution_1080_21_9){
			path = path + '1080p/balloon/';
			Volt.log('[winsetToolTip.js @m_setDefaultValueByProgressStyle]');
		} else if (resolution == ResolutionStyle.Resolution_720 || resolution == ResolutionStyle.Resolution_720_21_9){
			path = path + '720p/balloon/';
		}
		
		//set default value
		switch(style)
		{
			case TooltipStyle.Tooltip_Tail_Down:
				{	
					tail_side = 'down';
					
					tail_width = 18;
					tail_height = 12;
					if('start' == tailPostion){
						tail_distance = 12 - frame_width;
					}
					if('center' == tailPostion){
						tail_distance = (width - tail_width)/2 - frame_width;
					}
					if('end' == tailPostion){
						tail_distance = width - tail_width - 12 - frame_width;
					}
				}
				break;
			
			case TooltipStyle.Tooltip_Tail_Up:
				{
					tail_side = 'up';
					
					tail_width = 18;
					tail_height = 12;
					if('start' == tailPostion){
						tail_distance = 12 - frame_width;
					}
					if('center' == tailPostion){
						tail_distance = (width - tail_width)/2 - frame_width;
					}
					if('end' == tailPostion){
						tail_distance = width - tail_width - 12 - frame_width;
					}
				}
				break;
				
			case TooltipStyle.Tooltip_Tail_Left:
				{
					tail_side = 'left';
					
					tail_width = 12;
					tail_height = 18;
					if('start' == tailPostion){
						tail_distance = 6 - frame_width;
					}
					if('center' == tailPostion){
						tail_distance = (height - tail_height)/2 - frame_width;
					}
					if('end' == tailPostion){
						tail_distance = height - tail_height - 6 - frame_width;
					}
				}
				break;
				
			case TooltipStyle.Tooltip_Tail_Right:
				{
					tail_side = 'right';
					
					tail_width = 12;
					tail_height = 18;
					if('start' == tailPostion){
						tail_distance = 6 - frame_width;
					}
					if('center' == tailPostion){
						tail_distance = (height - tail_height)/2 - frame_width;
					}
					if('end' == tailPostion){
						tail_distance = height - tail_height - 6 - frame_width;
					}
				}
				break;
				
			default:
				break;
		}
	}

	resolution = getResolution();		
	m_analysisParameter(obj);
	m_setDefaultValueByProgressStyle();
	
	balloon = new ToolTip({
		x: x,
	    y: y,
	    // id: id,
	    text: text,
		parent: parent,
	    width: width,
	    height: height,
	    popupImage: path + 'popup_balloon.png',
	    upTailImage: path + 'popup_balloon_tail_u.png',
    	downTailImage: path + 'popup_balloon_tail_d.png',
    	leftTailImage: path + 'popup_balloon_tail_l.png',
   		rightTailImage: path + 'popup_balloon_tail_r.png',
   		tailSide: tail_side,
   		tailWidth: tail_width,
    	tailHeight: tail_height,
	    tailDistance: tail_distance,
	    tailOffset: -3,
	    font: 'SamsungSmart_Light 30px',
	    fontSize: 30,
	    textBackgroundColor: { r: 255, g: 255, b: 255, a: 0 },
	    color: { r: 64, g: 64, b: 64, a: 0 },
	    frameColor: { r: 64, g: 64, b: 64, a: 0 },
	    frameWidth: frame_width
	});

	if(null != id){
		balloon.id = id;
	}
	
	return balloon;
};

var TooltipStyle = {
	Tooltip_Tail_Down:1,
	Tooltip_Tail_Up:2,
	Tooltip_Tail_Left:3,
	Tooltip_Tail_Right:4,
	Tooltip_Style_Max:5
};

winsetToolTip.TooltipStyle = TooltipStyle;
winsetToolTip.prototype = new winsetBase();

exports = winsetToolTip;