var winsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var winsetPopUpRating = function (objParameter){	
	winsetBase.call(this);
	var ResolutionStyle = winsetBase.ResolutionStyle;
	var getResolution = winsetBase.getResolution;
	
	var m_pInstance = null;
	//default value
	var m_defaultParent = scene;
	var m_defaultId = null;
	var m_imagePath	= "$VOLT_ROOT/modules/WinsetUIElement/winsetImg/";
	var m_popUpRatingStyle = 0;
	var m_resolutionStyle = 0;	
	var m_bHighContrast = false;

	var m_defaultWidth = 1920;
	var m_defaultHeight = 1080;
	var m_defaultAdd = 0;
	
	var m_defaultBgColor = {r: 39, g: 124, b: 175, a: 200};
	var m_defaultBGX = 0;
	var m_defaultBGY = 0;
	var m_defaultBGWidth = 1920;
	var m_defaultBGHeight = 418;	
	

	var m_defaultTitleColor = {r: 255, g: 255, b: 255, a: 255};
	var titleLineColor;
	var m_defaultTitleSize = "SamsungSmart_Light 44px";
	var m_defaultTitleX = 569;
	var m_defaultTitleY = 0;
	var m_defaultTitleWidth = 782;
	var m_defaultTitleHeight = 97;

	var m_defaultContentColor = {r: 255, g: 255, b: 255, a: 255};
	var m_defaultContenSize =  "SamsungSmart_Light 34px";	
	var m_defaultContentX = 569;
	var m_defaultContentY = 108;
	var m_defaultContentWidth = 782;
	var m_defaultContentHeight = 96;

	var m_defaultLeftArrowX = 717;
	var m_defaultLeftArrowY = 108 + 96 + 21;
	var m_defaultLeftArrowWidth = 62;
	var m_defaultLeftArrowHeight = 62;
	
	var m_defaultRightArrowX = 817 + 57* 5+ 100;
	var m_defaultRightArrowY = 108 + 96 + 21;
	var m_defaultRightArrowWidth = 62;
	var m_defaultRightArrowHeight = 62;
	
	var m_defaultStarIconWidthWithGap = 57;
	var m_defaultFirstStarIconX = 817
	var m_defaultFirstStarIconY = 108 + 96 + 26;
	var m_defaultFirstStarIconWidth = 46;
	var m_defaultFirstStarIconHeight = 46;
	
	var m_defaultOkX = 817 - 135;
	var m_defaultOkY = 250 + 46 + 35;
	var m_defaultOkWidth = 270;
	var m_defaultOkHeight = 66;
	var button1Text = "OK";
	var m_defaultOkSize = 32;
	
	var m_defaultCancelX = 817 + 57* 5 - 135;
	var m_defaultCancelY = 250 + 46 + 35;
	var m_defaultCancelWidth=270;
	var m_defaultCancelHeight=66;
	var button2Text = "Cancel";
	var m_defaultCancelSize = 36;
	
	var m_defaultTitle ="Test PopupRating";
	var m_defaultContent ="This is the m_pInstance!";
	var m_defaultMarkedImage = "";
	var m_defaultunMarkedImage = "";
	var m_defaultHalfMarkedImage = "";
	var m_defaultNormalLeftArrowImage = "";
	var m_defaultFocusLeftArrowImage = "";
	var m_defaultDisabledLeftArrowImage = "";
	var m_defaultNormalRightArrowImage = "";
	var m_defaultFocusRightArrowImage = "";
	var m_defaultDisabledRightArrowImage = "";
	
	var buttonStyle = 1,
		buttonBgNormal,
		buttonBgFoucs,
		buttonBgSelect,
		buttonBgDim,
		buttonBgNormalColor,
		buttonBgFoucsColor,
		buttonBgSelectColor,
		buttonBgDimColor,
		buttonBgRolloverColor,
		normalFont,
		focusFont,
		selectFont,
		dimFont,
		rolloverFont,
		normalTextColor,
		focusTextColor,
		selectTextColor,
		dimTextColor,
		rolloverTextColor,
		iconBgRect = {},
		iconBgColor = {};
		
	var m_bgStyle = BackgroudStyle.BG_Style_E_2,
		bgPickColor = { r: 0, g: 0, b: 0, a: 0 },
		firstLayerBGColor,
		secondLayerBGColor,
		thirdLayerBGColor,
		secondLayerBGHeight,
		thirdLayerBGHeight,
		// button border color
		normalBorderColor,
		dimBorderColor,
		bUseHalfStar = false,
		popupStyle = PopupStyle.TV_and_Smart_Hub_Popup;	

	
var m_create = function(objParameter){
	Volt.log('[winsetPopUpRating.js @m_create]');
	
	m_resolutionStyle = getResolution();
	//analysis parameter
	m_analysisParameter(objParameter);
	
	//set default value
	m_setDefaultValueByPopUpRatingStyle();
				
	//create PopUpRating instance 
	m_pInstance = new PopupRating({
			parent: m_defaultParent,
			x:m_defaultBGX,
			y:m_defaultBGY,
			width: m_defaultBGWidth,
			height: m_defaultBGHeight,
			color: m_defaultBgColor,
			nPopupRatingType: "base_label_with_popup_type",
			starIconUnmarkedImagePath: m_defaultMarkedImage,
			starIconMarkedImagePath: m_defaultunMarkedImage,
			starIconHalfMarkedImagePath: m_defaultHalfMarkedImage,
			normalLeftArrowButtonImagePath: m_defaultNormalLeftArrowImage,
			focusLeftArrowButtonImagePath: m_defaultFocusLeftArrowImage, 
			disabledLeftArrowButtonImagePath: m_defaultDisabledLeftArrowImage,
			normalRightArrowButtonImagePath: m_defaultNormalRightArrowImage,
			focusRightArrowButtonImagePath: m_defaultFocusRightArrowImage, 
			disabledRightArrowButtonImagePath: m_defaultDisabledRightArrowImage,
		    normalLeftArrowButtonImageOpacity: 153,
            normalRightArrowButtonImageOpacity: 153,
            focusLeftArrowButtonImageOpacity: 255,
            focusRightArrowButtonImageOpacity: 255,
            disabledLeftArrowButtonImageOpacity: 25.5,
            disabledRightArrowButtonImageOpacity: 25.5,
			titleText: m_defaultTitle,
			titleTextFont: m_defaultTitleSize,
			contentText: m_defaultContent,
			contentTextFont: m_defaultContenSize,
			button_1_Text: button1Text,
			button_2_Text: button2Text,
			buttonTextNormalSize: m_defaultOkSize,
			buttonTextFocusSize: m_defaultCancelSize,
			bAutoFlag:false,
			bHasHalfMarkedStar: bUseHalfStar
		});	
	
	m_pInstance.x = 0;
	m_pInstance.y = 0;
	m_pInstance.origin = {x: 0.5, y: 0.5};
	m_pInstance.anchor = {x: 0.5, y: 0.5};
	
	if(m_defaultId != null){
		m_pInstance.id = m_defaultId;
	}
	
	m_pInstance.setTitleRect(m_defaultTitleX,m_defaultTitleY,m_defaultTitleWidth,m_defaultTitleHeight);
	m_pInstance.setTitleTextColor(m_defaultTitleColor.r, m_defaultTitleColor.g, m_defaultTitleColor.b, m_defaultTitleColor.a);
	m_pInstance.setTitleTextAlignment("horizontal_align_center","vertical_align_middle");
	
	m_pInstance.setTitleLineRect(m_defaultTitleX,m_defaultTitleY + m_defaultTitleHeight,m_defaultTitleWidth,1);
	m_pInstance.setTitleLineColor(titleLineColor.r, titleLineColor.g, titleLineColor.b, titleLineColor.a);
	
	m_pInstance.setContentRect(m_defaultContentX,m_defaultContentY,m_defaultContentWidth,m_defaultContentHeight);
	m_pInstance.setContentTextColor(m_defaultContentColor.r, m_defaultContentColor.g, m_defaultContentColor.b, m_defaultContentColor.a);
	m_pInstance.setContentTextAlignment("horizontal_align_center","vertical_align_top");
	
	m_pInstance.setArrowButtonRect("arrow_button_1", m_defaultLeftArrowX, m_defaultLeftArrowY, m_defaultLeftArrowWidth, m_defaultLeftArrowHeight);
	m_pInstance.setArrowButtonRect("arrow_button_2", m_defaultRightArrowX, m_defaultRightArrowY, m_defaultRightArrowWidth, m_defaultRightArrowHeight);
	
	m_pInstance.setStarIconsBGRect(iconBgRect.x, iconBgRect.y, iconBgRect.width, iconBgRect.height);
	
	for(var index = 1; index <=5; index++){
		var strIconName =  "star_icon_" + index.toString();
		var nStarInconX = m_defaultFirstStarIconX + (index -1)* m_defaultStarIconWidthWithGap;	
		m_pInstance.setStarIconRect(strIconName,nStarInconX, m_defaultFirstStarIconY, m_defaultFirstStarIconWidth, m_defaultFirstStarIconHeight);	
	}
	
	// set color and image for point and 4-way
	m_pInstance.setStarIconsBGColor(255, 255, 255, 12.75, "normal", "pointing");
    m_pInstance.setStarIconsBGColor(0, 0, 0, 0, "normal", "4way");
    m_pInstance.setStarIconsBGColor(255, 255, 255, 242.25, "focused", "4way");

    m_pInstance.setStarIconsBGBorderColor("normal", 255, 255, 255, 200, "4way");
    m_pInstance.setStarIconsBGBorderColor("focused", 0, 0, 0, 0, "4way");
    m_pInstance.setStarIconsBGBorderWidth("normal", 2, "4way");
    m_pInstance.setStarIconsBGBorderWidth("focused", 0 , "4way");

	m_pInstance.setArrowButtonImage("arrow_button_1", "normal", m_imagePath + "/rating/popup_rating_arrow_l.png", "pointing");
    m_pInstance.setArrowButtonImage("arrow_button_1", "focused", m_imagePath+"/rating/popup_rating_arrow_l_f.png", "pointing");
    m_pInstance.setArrowButtonImage("arrow_button_1", "disabled", m_imagePath + "/rating/popup_rating_arrow_l.png", "pointing");
    m_pInstance.setArrowButtonImage("arrow_button_2", "normal", m_imagePath + "/rating/popup_rating_arrow_r.png", "pointing");
    m_pInstance.setArrowButtonImage("arrow_button_2", "focused", m_imagePath + "/rating/popup_rating_arrow_r_f.png", "pointing");
    m_pInstance.setArrowButtonImage("arrow_button_2", "disabled", m_imagePath + "/rating/popup_rating_arrow_r.png", "pointing");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_1", "normal", 153, "pointing");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_1", "focused", 255, "pointing");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_1", "disabled", 25.5, "pointing");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_2", "normal",153, "pointing");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_2", "focused", 255, "pointing");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_2", "disabled", 25.5, "pointing");
			
    m_pInstance.setArrowButtonImage("arrow_button_1", "normal", m_imagePath + "/rating/popup_rating_arrow_4way_l.png", "4way");
    // m_pInstance.setArrowButtonImage("arrow_button_1", "focused", m_imagePath + "/rating/popup_rating_arrow_4way_l.png", "4way");
    m_pInstance.setArrowButtonImage("arrow_button_1", "disabled", m_imagePath + "/rating/popup_rating_arrow_4way_l.png", "4way");
    m_pInstance.setArrowButtonImage("arrow_button_2", "normal", m_imagePath + "/rating/popup_rating_arrow_4way_r.png", "4way");
    // m_pInstance.setArrowButtonImage("arrow_button_2", "focused", m_imagePath + "/rating/popup_rating_arrow_4way_r.png", "4way");
    m_pInstance.setArrowButtonImage("arrow_button_2", "disabled", m_imagePath + "/rating/popup_rating_arrow_4way_r.png", "4way");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_1", "normal", 153, "4way");
    // m_pInstance.setArrowButtonImageOpacity("arrow_button_1", "focused", 153, "4way");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_1", "disabled", 25.5, "4way");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_2", "normal",153, "4way");
    // m_pInstance.setArrowButtonImageOpacity("arrow_button_2", "focused", 153, "4way");
    m_pInstance.setArrowButtonImageOpacity("arrow_button_2", "disabled", 25.5, "4way");
	
	m_pInstance.setButtonRect("button_1", m_defaultOkX, m_defaultOkY, m_defaultOkWidth, m_defaultOkHeight);
	m_pInstance.setButtonRect("button_2", m_defaultCancelX, m_defaultCancelY, m_defaultCancelWidth, m_defaultCancelHeight);
	
    m_pInstance.markedStarIconNumber = 0;
    
    // use border to instead of image
	m_pInstance.setButtonBorderColor("button_all", "normal", normalBorderColor.r, normalBorderColor.g, normalBorderColor.b, normalBorderColor.a);
	m_pInstance.setButtonBorderColor("button_all", "disabled", dimBorderColor.r, dimBorderColor.g, dimBorderColor.b, dimBorderColor.a);
	m_pInstance.setButtonBorderWidth ("button_all", "normal", 2.0);
	m_pInstance.setButtonBorderWidth ("button_all", "disabled", 2.0);
	
	m_pInstance.setButtonBackgroundColor("button_all", "all", buttonBgNormalColor.r, buttonBgNormalColor.g, buttonBgNormalColor.b, buttonBgNormalColor.a);
	m_pInstance.setButtonBackgroundColor("button_all", "normal", buttonBgNormalColor.r, buttonBgNormalColor.g, buttonBgNormalColor.b, buttonBgNormalColor.a);
	m_pInstance.setButtonBackgroundColor("button_all", "focused", buttonBgFoucsColor.r, buttonBgFoucsColor.g, buttonBgFoucsColor.b, buttonBgFoucsColor.a);
	m_pInstance.setButtonBackgroundColor("button_all", "selected", buttonBgSelectColor.r, buttonBgSelectColor.g, buttonBgSelectColor.b, buttonBgSelectColor.a);
	m_pInstance.setButtonBackgroundColor("button_all", "disabled", buttonBgDimColor.r, buttonBgDimColor.g, buttonBgDimColor.b, buttonBgDimColor.a);
	m_pInstance.setButtonBackgroundColor("button_all", "focused-roll-over", buttonBgRolloverColor.r, buttonBgRolloverColor.g, buttonBgRolloverColor.b, buttonBgRolloverColor.a);
	
	m_pInstance.setButtonTextColor("button_all", "all", normalTextColor.r, normalTextColor.g, normalTextColor.b, normalTextColor.a);
	m_pInstance.setButtonTextColor("button_all", "normal", normalTextColor.r, normalTextColor.g, normalTextColor.b, normalTextColor.a);
	m_pInstance.setButtonTextColor("button_all", "focused", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
	m_pInstance.setButtonTextColor("button_all", "selected", selectTextColor.r, selectTextColor.g, selectTextColor.b, selectTextColor.a);
	m_pInstance.setButtonTextColor("button_all", "disabled", dimTextColor.r, dimTextColor.g, dimTextColor.b, dimTextColor.a);
	m_pInstance.setButtonTextColor("button_all", "focused-roll-over", focusTextColor.r, focusTextColor.g, focusTextColor.b, focusTextColor.a);
   
	m_pInstance.setButtonTextFontSize("button_all", "all", normalFont);
	m_pInstance.setButtonTextFontSize("button_all", "normal", normalFont);
	m_pInstance.setButtonTextFontSize("button_all", "focused", focusFont);
	m_pInstance.setButtonTextFontSize("button_all", "selected", selectFont);
	m_pInstance.setButtonTextFontSize("button_all", "disabled", dimFont);
	m_pInstance.setButtonTextFontSize("button_all", "focused-roll-over", focusFont);
    
	var widgetExListener = new WidgetExListener;
	widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
	    if((true == flagHighContrast) && (false == m_bHighContrast)){
	    	m_pInstance.setFirstLayerBGColor({ firstLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
   			m_pInstance.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
    		m_pInstance.setThirdLayerBGColor({ thirdLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
	    	m_bHighContrast = true;
	    }
	    
	    if((false == flagHighContrast) && (true == m_bHighContrast)){
	    	m_pInstance.setFirstLayerBGColor({ firstLayerBGColor: firstLayerBGColor });
   			m_pInstance.setSecondLayerBGColor({ secondLayerBGColor: secondLayerBGColor });
    		m_pInstance.setThirdLayerBGColor({ thirdLayerBGColor: thirdLayerBGColor });
	    	m_bHighContrast = false;
	    }
	};
	
	// set background
    m_bHighContrast = HALOUtil.highContrast; // check status of highcontrast now
    if(true == m_bHighContrast){
    	m_pInstance.setFirstLayerBGColor({ firstLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
		m_pInstance.setSecondLayerBGColor({ secondLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
		m_pInstance.setThirdLayerBGColor({ thirdLayerBGColor: { r: 0, g: 0, b: 0, a: 255 } });
    }else{
    	m_pInstance.setFirstLayerBGColor({ firstLayerBGColor: firstLayerBGColor });
	    m_pInstance.setSecondLayerBGColor({ secondLayerBGColor: secondLayerBGColor });
	    m_pInstance.setThirdLayerBGColor({ thirdLayerBGColor: thirdLayerBGColor });
    }
    m_pInstance.setSecondLayerBGHeight(secondLayerBGHeight);
    m_pInstance.setThirdLayerBGHeight(thirdLayerBGHeight);
    m_pInstance.setFourthLayerBGImage({ fourthLayerBGImage: m_imagePath + "/bg/popup_shadow.png" });
	
	m_pInstance.addWidgetExListener(widgetExListener);
	
	m_pInstance.destroyListener = function(){
		if(null != widgetExListener){
			m_pInstance.removeWidgetExListener(widgetExListener);
			widgetExListener.destroy();
			widgetExListener = null;
		}
	};
	
	return 	m_pInstance;
}		
	
var m_analysisParameter = function(objParameter){
	Volt.log('[winsetPopUpRating.js @m_analysisParameter]');

	if("undefined" == objParameter){
		return;
	}

	if (objParameter.hasOwnProperty("nPopUpRatingStyle") 
		&& (typeof objParameter.nPopUpRatingStyle == "number" || typeof objParameter.nPopUpRatingStyle == "string")){
			if(typeof objParameter.nPopUpRatingStyle == "string"){
				m_PopUpRatingStyle = parseInt(objParameter.nPopUpRatingStyle);
			}else{
				m_PopUpRatingStyle = objParameter.nPopUpRatingStyle;
			}
			
			if(0 > m_PopUpRatingStyle || PopUpRatingStyle.PopUpRating_Style_MAX < m_PopUpRatingStyle){
				m_PopUpRatingStyle = 0;
			}
	}
		
	if(objParameter.hasOwnProperty("nBackgroudStyle")
		&& (typeof objParameter.nBackgroudStyle == "number")
		&& (objParameter.nBackgroudStyle >= BackgroudStyle.BG_Style_E_1)
		&& (BackgroudStyle.BG_Style_Max > objParameter.nBackgroudStyle)){		
		m_bgStyle = objParameter.nBackgroudStyle;
	}	

	if(objParameter.hasOwnProperty("nbuttonStyle")
		&& (typeof objParameter.nbuttonStyle == "number" || typeof objParameter.nbuttonStyle == "string")){
		if(typeof objParameter.nbuttonStyle == "string"){
			buttonStyle = parseInt(objParameter.nbuttonStyle);
		}else{
			buttonStyle = objParameter.nbuttonStyle;
		}
		
		if(1 > buttonStyle || ButtonStyle.Button_Style_Max <= buttonStyle){
			buttonStyle = 1;
		}
	}
	
	if(objParameter.hasOwnProperty("buttonStyle")
		&& (typeof objParameter.buttonStyle == "number" || typeof objParameter.buttonStyle == "string")){
		if(typeof objParameter.buttonStyle == "string"){
			buttonStyle = parseInt(objParameter.buttonStyle);
		}else{
			buttonStyle = objParameter.buttonStyle;
		}
		
		if(1 > buttonStyle || ButtonStyle.Button_Style_Max <= buttonStyle){
			buttonStyle = 1;
		}
	}
	
	if(objParameter.hasOwnProperty("x")
		&& (typeof objParameter.x == "number" || typeof objParameter.x == "string")){
		if(typeof objParameter.x == "string"){
			m_defaultX = parseInt(objParameter.x);	
		}else{
			m_defaultX = objParameter.x;	
		} 
		
	}
	
	if(objParameter.hasOwnProperty("y")
		&& (typeof objParameter.y == "number" || typeof objParameter.y == "string")){
		if(typeof objParameter.y == "string"){
			m_defaultY = parseInt(objParameter.y);	
		}else{
			m_defaultY = objParameter.y;	
		}
	}	
	
	if(objParameter.hasOwnProperty("width")
		&& (typeof objParameter.width == "number" || typeof objParameter.width == "string")){
		if(typeof objParameter.width == "string"){
			m_defaultBGWidth = parseInt(objParameter.width);
		}else{
			m_defaultBGWidth = objParameter.width;
		}	
	}	
	
	if(objParameter.hasOwnProperty("height")
		&& (typeof objParameter.height == "number" || typeof objParameter.height == "string")){
		if(typeof objParameter.height == "string"){
			m_defaultBGHeight = parseInt(objParameter.height);
		}else{
			m_defaultBGHeight = objParameter.height;
		}			
	}	
			
	if(objParameter.hasOwnProperty("parent")
		&& (typeof objParameter.parent == "object")){
		m_defaultParent = objParameter.parent;
	}
	
	if(objParameter.hasOwnProperty("id")
		&& (typeof objParameter.id == "string")){
		m_defaultId = objParameter.id;
	}
	
	if(objParameter.hasOwnProperty("button1Text")
		&& (typeof objParameter.button1Text == "string")){
		button1Text = objParameter.button1Text;
	}
	
	if(objParameter.hasOwnProperty("button2Text")
		&& (typeof objParameter.button2Text == "string")){
		button2Text = objParameter.button2Text;
	}
	
	if(objParameter.hasOwnProperty("bgPickColor")
		&& (typeof objParameter.bgPickColor == "object")){
		bgPickColor = objParameter.bgPickColor;	
	}
	
	if(objParameter.hasOwnProperty("bUseHalfStar")
		&& (typeof objParameter.bUseHalfStar == "boolean" || typeof objParameter.bUseHalfStar == "string")){
		if(typeof objParameter.bUseHalfStar == "string"){
			if("true" == objParameter.bUseHalfStar){
				bUseHalfStar = true;
			}else if("false" == objParameter.bUseHalfStar){
				bUseHalfStar = false;
			}
		}else{
			bUseHalfStar = objParameter.bUseHalfStar;
		}	
	}
	
	if(objParameter.hasOwnProperty("popupStyle")
		&& (typeof objParameter.popupStyle == "number" || typeof objParameter.popupStyle == "string")){
		if(typeof objParameter.popupStyle == "string"){
			popupStyle = parseInt(objParameter.popupStyle);	
		}else{
			popupStyle = objParameter.popupStyle;	
		}
	}	
}
		
var m_setDefaultValueByPopUpRatingStyle = function(){
	Volt.log('[winsetPopUpRating.js @m_setDefaultValueByPopUpRatingStyle]');

	// set resource path
	if(m_resolutionStyle == ResolutionStyle.Resolution_1080 || m_resolutionStyle == ResolutionStyle.Resolution_1080_21_9){
		m_imagePath = m_imagePath + "1080p";
	} else if (m_resolutionStyle == ResolutionStyle.Resolution_720 || m_resolutionStyle == ResolutionStyle.Resolution_720_21_9){
		m_imagePath = m_imagePath + "720p";
	}
	
	//set common value
	m_defaultMarkedImage = m_imagePath+"/rating/popup_rating_off.png";
	m_defaultunMarkedImage = m_imagePath+"/rating/popup_rating_on.png";
	m_defaultHalfMarkedImage = m_imagePath+"/rating/popup_rating_half.png";
		
	//resolution
	m_defaultWidth = 1920;
	m_defaultHeight = 1080;			
	m_defaultAdd =0;			
	
	m_defaultTitleSize = "SamsungSmart_Light 46px";			
	m_defaultContenSize =  "SamsungSmart_Light 34px";	
				
	//leftrrowX
	m_defaultLeftArrowWidth = 62;
	m_defaultLeftArrowHeight = 62;

	//rightArrowX
	m_defaultRightArrowWidth = 62;
	m_defaultRightArrowHeight = 62;

	//first star	
	m_defaultFirstStarIconWidth = 32;
	m_defaultFirstStarIconHeight = 32;
	
	//button ok
	m_defaultOkSize = 32;
	
	//button cancel
	m_defaultCancelSize = 36;
	
	switch(m_PopUpRatingStyle){
		case PopUpRatingStyle.PopUpRatingStyle_A:
		case PopUpRatingStyle.PopUpRatingStyle_Pointing:
		{
			m_defaultNormalLeftArrowImage = m_imagePath+"/rating/popup_rating_arrow_l.png";
			m_defaultFocusLeftArrowImage = m_imagePath+"/rating/popup_rating_arrow_l_f.png";
			m_defaultDisabledLeftArrowImage = m_imagePath+"/rating/popup_rating_arrow_l.png";
			m_defaultNormalRightArrowImage = m_imagePath+"/rating/popup_rating_arrow_r.png";
			m_defaultFocusRightArrowImage = m_imagePath+"/rating/popup_rating_arrow_r_f.png";
			m_defaultDisabledRightArrowImage = m_imagePath+"/rating/popup_rating_arrow_r.png";
			
			iconBgColor = { r: 255, g: 255, b: 255, a: 13 };
		}
		break;
		
		case PopUpRatingStyle.PopUpRatingStyle_B:
		case PopUpRatingStyle.PopUpRatingStyle_4way:
		{
			m_defaultNormalLeftArrowImage = m_imagePath+"/rating/popup_rating_arrow_4way_l.png";
			m_defaultFocusLeftArrowImage = m_imagePath+"/rating/popup_rating_arrow_4way_l.png";
			m_defaultDisabledLeftArrowImage = m_imagePath+"/rating/popup_rating_arrow_4way_l.png";
			m_defaultNormalRightArrowImage = m_imagePath+"/rating/popup_rating_arrow_4way_r.png";
			m_defaultFocusRightArrowImage = m_imagePath+"/rating/popup_rating_arrow_4way_r.png";
			m_defaultDisabledRightArrowImage = m_imagePath+"/rating/popup_rating_arrow_4way_r.png";
			
			iconBgColor = { r: 255, g: 255, b: 255, a: 242.25 };
		}
		break;
		
		default:
		break;
	}
	
	//BG
	m_defaultBGX = 0;
	m_defaultBGY = 0;
	m_defaultBGWidth = m_defaultWidth + m_defaultAdd*2;
	m_defaultBGHeight = m_defaultHeight*0.387037;	
		
	//title	
	m_defaultTitleX = (m_defaultWidth - 0.407292*m_defaultWidth)/2 + m_defaultAdd;
	m_defaultTitleY = 0;
	m_defaultTitleWidth = 0.407292*m_defaultWidth;
	m_defaultTitleHeight = 0.089815*m_defaultHeight;		
	
	//content		
	m_defaultContentX = (m_defaultWidth - 0.407292*m_defaultWidth)/2 + m_defaultAdd;
	m_defaultContentY = (0.089815 + 0.010185) *m_defaultHeight + 5;
	m_defaultContentWidth = 0.407292*m_defaultWidth;
	m_defaultContentHeight = 0.044444*2*m_defaultHeight;	

	//icon bg
	iconBgRect.width = 0.163021*m_defaultWidth;
	iconBgRect.height = 0.057407*m_defaultHeight;
	iconBgRect.x =  (m_defaultWidth - 0.163021*m_defaultWidth)/2 + m_defaultAdd;
	iconBgRect.y = (0.089815 + 0.010185 + 0.044444*2 + 0.019444)*m_defaultHeight;
	
	//leftrrowX
	m_defaultLeftArrowX = 0 -  (m_defaultLeftArrowWidth + 0.005208*m_defaultWidth);
	m_defaultLeftArrowY = 0;
	
	//rightArrowX
	m_defaultRightArrowX = iconBgRect.width + 0.005208*m_defaultWidth;
	m_defaultRightArrowY = 0;
	
	//first star
	m_defaultFirstStarIconX = (iconBgRect.width -  m_defaultFirstStarIconWidth*5 - 0.008333*m_defaultWidth *4)/2;
	m_defaultFirstStarIconY = (iconBgRect.height  - m_defaultFirstStarIconHeight)/2;			
	m_defaultStarIconWidthWithGap = 0.008333*m_defaultWidth + m_defaultFirstStarIconWidth;		
	
	//button ok
	m_defaultOkX = (m_defaultWidth - (0.146875 + 0.140625)*m_defaultWidth)/2 +m_defaultAdd;
	m_defaultOkY = (0.387037 - 0.027778 - 0.061111)*m_defaultHeight;
	m_defaultOkWidth = 0.140625*m_defaultWidth;
	m_defaultOkHeight = 0.061111*m_defaultHeight;	
				
	//button cancel
	m_defaultCancelX = m_defaultOkX + 0.146875*m_defaultWidth;
	m_defaultCancelY = (0.387037 - 0.027778 - 0.061111)*m_defaultHeight;
	m_defaultCancelWidth=0.140625*m_defaultWidth;
	m_defaultCancelHeight=0.061111*m_defaultHeight;
	
	// text fontsize
	normalFont = 32;
	focusFont = 32;
	selectFont = 32;
	dimFont = 32;
	rolloverFont = 32;
	
	if(buttonStyle == ButtonStyle.Button_image_O_Style_E){
		// text color
		normalTextColor = { r: 64, g: 64, b: 64, a: 255 };
		focusTextColor = { r: 255, g: 255, b: 255, a: 255 };
		selectTextColor = { r: 255, g: 255, b: 255, a: 255 };
		dimTextColor = { r: 64, g: 64, b: 64, a: 76.5 };	
		rolloverTextColor = { r: 255, g: 255, b: 255, a: 255 };
		
		buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
		buttonBgFoucsColor = { r: 33, g: 158, b: 230, a: 255 };
		buttonBgSelectColor = { r: 33, g: 158, b: 230, a: 255 };
		buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
		buttonBgRolloverColor = { r: 33, g: 158, b: 230, a: 255 };
		
		// boder color
		normalBorderColor = { r: 0, g: 0, b: 0, a: 51 };
		dimBorderColor = { r: 0, g: 0, b: 0, a: 25.5 };			   
	}
	        
	if(buttonStyle == ButtonStyle.Button_image_O_Style_F_Focus1 || buttonStyle == ButtonStyle.Button_image_O_Style_F){
		// text color
		normalTextColor = { r: 255, g: 255, b: 255, a: 242.25 };
		focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
		selectTextColor = { r: 70, g: 70, b: 70, a: 255 };
		dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };	
		rolloverTextColor = { r: 70, g: 70, b: 70, a: 255 };	
		
		buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
		buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
		buttonBgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
		buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
		buttonBgRolloverColor = { r: 255, g: 255, b: 255, a: 242.25 };
		
		// boder color
		normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
		dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
	}
			
	if(buttonStyle == ButtonStyle.Button_image_O_Style_F_Focus2){
		// text color
		normalTextColor = { r: 255, g: 255, b: 255, a: 242.25 };
		focusTextColor = { r: 70, g: 70, b: 70, a: 255 };
		selectTextColor = { r: 70, g: 70, b: 70, a: 255 };
		dimTextColor = { r: 255, g: 255, b: 255, a: 76.5 };	
		rolloverTextColor = { r: 70, g: 70, b: 70, a: 255 };	
		
		buttonBgNormalColor = { r: 0, g: 0, b: 0, a: 0 };
		buttonBgFoucsColor = { r: 255, g: 255, b: 255, a: 242.25 };
		buttonBgSelectColor = { r: 255, g: 255, b: 255, a: 242.25 };
		buttonBgDimColor = { r: 255, g: 255, b: 255, a: 0 };
		buttonBgRolloverColor = { r: 255, g: 255, b: 255, a: 242.25 };
		
		// boder color
		normalBorderColor = { r: 255, g: 255, b: 255, a: 204 };
		dimBorderColor = { r: 255, g: 255, b: 255, a: 76.5 };
	}

	//backgroup sytle
	switch(m_bgStyle){
		case BackgroudStyle.BG_Style_E_1:{
			m_defaultBgColor = { r: 39, g: 124, b: 175, a: 0 };
			firstLayerBGColor = bgPickColor;
			secondLayerBGColor = { r: 255, g: 255, b: 255, a: 12.75 };
			thirdLayerBGColor = { r: 0, g: 0, b: 0, a: 38.25 };
			secondLayerBGHeight = m_defaultHeight * 0.000926;
			thirdLayerBGHeight = m_defaultHeight * 0.001852;
		}
		break;
		case BackgroudStyle.BG_Style_E_2:{
			m_defaultBgColor = { r: 15, g: 24, b: 38, a: 0 };
			firstLayerBGColor = { r: 10, g: 35, b: 61, a: 255 };
			secondLayerBGColor = { r: 255, g: 255, b: 255, a: 12.75 };
			thirdLayerBGColor = { r: 0, g: 0, b: 0, a: 38.25 };
			secondLayerBGHeight = m_defaultHeight * 0.000926;
			thirdLayerBGHeight = m_defaultHeight * 0.001852;
		}
		break;
		case BackgroudStyle.BG_Style_E_3:{
			m_defaultBgColor = { r: 237, g: 237, b: 237, a: 0 };
			firstLayerBGColor = { r: 10, g: 35, b: 61, a: 0 };
			secondLayerBGColor = { r: 255, g: 255, b: 255, a: 0 };
			thirdLayerBGColor = { r: 0, g: 0, b: 0, a: 0 };
			secondLayerBGHeight = m_defaultHeight * 0.000926;
			thirdLayerBGHeight = m_defaultHeight * 0.001852;
		}
		break;			
		default:
			break;
	}
	
	switch(popupStyle){
		case PopupStyle.Wizard_Popup:
		{
			m_defaultTitleColor = { r: 58, g: 58, b: 58, a: 229.5 };
			titleLineColor = { r: 0, g: 0, b: 0, a: 76.5 };
			
			m_defaultContentColor = { r: 58, g: 58, b: 58, a: 255 };
		}
		break;
		
		case PopupStyle.TV_and_Smart_Hub_Popup:
		{
			m_defaultTitleColor = { r: 255, g: 255, b: 255, a: 255 };
			titleLineColor = { r: 255, g: 255, b: 255, a: 76.5  };
			
			m_defaultContentColor = { r: 255, g: 255, b: 255, a: 255 };
		}
		break;
		
		default:
			break;
	}		
}	

//return the instance of native PopUpRating	
return m_create(objParameter);	
}

//style type
var PopUpRatingStyle = {
	PopUpRatingStyle_A: 0,
	PopUpRatingStyle_B: 1,
	PopUpRatingStyle_Pointing: 2,
	PopUpRatingStyle_4way: 3,
	PopUpRating_Style_MAX: 4
};

var ButtonStyle = {
		Button_image_O_Style_E: 1,
		Button_image_O_Style_F_Focus1: 2, // to be delete
	    Button_image_O_Style_F_Focus2: 3, // to be delete
	    Button_image_O_Style_F: 4,
	    Button_Style_Max: 5
};

var BackgroudStyle = {
	BG_Style_E_1:1,
	BG_Style_E_2:2,
	BG_Style_E_3:3, // to be delete
	BG_Style_Max:4
};

var PopupStyle = {
	Wizard_Popup: 1,
	TV_and_Smart_Hub_Popup: 2
}

winsetPopUpRating.PopUpRatingStyle = PopUpRatingStyle;
winsetPopUpRating.ButtonStyle = ButtonStyle;
winsetPopUpRating.BackgroudStyle = BackgroudStyle;
winsetPopUpRating.PopupStyle = PopupStyle;

winsetPopUpRating.prototype = new winsetBase();

exports = winsetPopUpRating;
