(function () {
    Volt.pakages = {
        instances: {},
        modules: {}
    };
    Volt.BASE_PATH = 'http://10.89.5.119:8080/'; // In case server environment
    //Volt.BASE_PATH = 'file://';
    Volt.require = function (path) {
        if (Volt.pakages.instances[path]) {
            return Volt.pakages.instances[path];
        } else if (Volt.pakages.modules[path]) {
            Volt.pakages.instances[path] = new Volt.pakages.modules[path]()._exports;
            return Volt.pakages.instances[path];
        } else {
            if (path.indexOf('$') == -1) {
                return require(Volt.browser ? path : Volt.BASE_PATH + path);
            } else {
                return require(path);
            }
        }
    };
})();

////////////////////////////////////////////////////////////////////////////////
//// APP CONFIG
////////////////////////////////////////////////////////////////////////////////
// Change the config when merging to [INT]

Volt.__INT__ = true; // Uncomment this when merging from [FET] to [INT]
Volt.AppsVersion = "A-AQUAGDSP-2921"; // Update this when merging from [FET] to [INT]

//##############################################################################
//Volt.__DEBUG__ = true;
//Volt.__SIM_STORAGE_FULL__ = true;
//Volt.__SIM_UPDATE__ = true;
//Volt.__SIM_NETWORK_STATUS__ = 'NG'; // Simulate the situation that a network error occurrs
//Volt.__RELEASE_RESOURCE_REQUEST__ = false; // Release resource request after the request is completed
//Volt.__SIM_21_9__ = true;   // Simulate the 21:9 resolution
////////////////////////////////////////////////////////////////////////////////
//// GLOBALS
////////////////////////////////////////////////////////////////////////////////
/**
 * Include modules
 */

//// This should be required first.
//Volt.require('distribution.min.js');

//// Remove the path '$VOLT_ROOT/modules/' in require to fix bug of require twice.
// ALERT: This should NOT be commented.
//Volt.require('$VOLT_ROOT/modules/modules_distribution.min.js');

HALOUtil.applyOrientation();
Volt.require('lib/volt-multi-resolution.js');
Volt.require('lib/volt-common.js');
Volt.require('lib/volt-nav.js');

Volt.require('lib/volt-debug.js');

Volt.require('app/router.js');
Volt.KpiMapper = Volt.require('app/common/kpiMapper.js');
Volt.DeviceInfoModel = Volt.require('app/models/deviceInfoModel.js');
Volt.i18n = Volt.require('lib/volt-multilingual.js');

var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js'),
    Backbone = Volt.require('lib/volt-backbone.js'),
    KPI = Volt.require('lib/volt-kpi.js'),
    AppInstallMgr = Volt.require('app/common/appInstallMgr.js'),
    //Models = Volt.require('app/models/models.js'),
    DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    ServerAPI = Volt.require('app/common/serverAPI.js'),
    CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js'),
    MagicKey = Volt.require('app/common/MagicKey.js'),
    AppController = Volt.require('app/controllers/app-controller.js');

// Indicate if the app is in Quick View Mode
Volt.bQuickView = false; // Whether app is in QuickView Mode
var startView = "whatsnew"; //smartHubPopupView //'whatsnew';
var hiddenKeyArray = new Array();
var developKeyArray = new Array();
var exitKeyArray = new Array();

////////////////////////////////////////////////////////////////////////////////
//// PUBLIC FUNCTIONS
////////////////////////////////////////////////////////////////////////////////
/**
 * Entry point for Volt application
 */
var initialize = function () {
    Volt.err("[app.js] Apps Version: " + Volt.AppsVersion);

    var sAgreedView;
    if (this.loggingEmp) {
        sAgreedView = this.loggingEmp.execute("IsAgreedWith", 'viewing');
    }
   Volt.err("[app.js] HALOUtil.minorVersion: " + HALOUtil.minorVersion);
    if(HALOUtil.minorVersion){
        Volt.err("[app.js] HALOUtil.minorVersion: " + HALOUtil.minorVersion);
        Volt.moveSupport = HALOUtil.minorVersion >= 2 ? true : false;
    }else{
        Volt.moveSupport = false;
    }
    if(false == Volt.moveSupport){
            CommonDefines.OptionMenu.LOCK_MY_APPS = 1;
            CommonDefines.OptionMenu.SORT_BY = 2;
            CommonDefines.OptionMenu.UPDATE_APPS = 3;
            CommonDefines.OptionMenu.MOVE_MY_APPS = 4
    }
    
    if (sAgreedView == 1) {
        try {
            HALOUtil.enableLogging(true);
            print('HALOUtil.enableLogging');
        } catch (ex) {
            print('cannot find HALOUtil.enableLogging');
        }

    }

    function startApp() {
        Volt.log('[app.js @startApp]');
        //voltapi.vconf.setValue(CommonDefines.Vconf.DB_WAITING_SCREEN_APP_VISIBLE, true);

        // Setup Post-Load modules
        setupEnv('POST');

        if (Volt.bQuickView) {
            Volt.bQuickView = false;
            Backbone.history.navigate(startView, {
                trigger: true,
                replace: true,
            });
        }
    }

    ////
    setBackgroundBg();
    Stage.show(); // show apps panel, request from Volt UIFW

    // Setup Pre-Load modules
    setupEnv('PRE');

    if (startView == 'whatsnew') {
        Volt.bQuickView = true;
        showQuickView();

        if (Volt.post) {
            Volt.log('[app.js @initialize] Post setEnv via Volt.post()');
            Volt.post(startApp);
        } else {
            Volt.log('[app.js @initialize] Post setEnv via Volt.setTimeout()');
            Volt.setTimeout(startApp, 150);
        }

    } else { // Into detail
        startApp();
    }
};

/**
 * Key event listener from volt engine
 * @param keycode
 * @param type
 */
var onKeyEvent = function (keycode, type) {
    Volt.log("[app.js @onKeyEvent] keycode : " + Volt.getKeyName(keycode, type));

    if (type == Volt.EVENT_KEY_PRESS) {
        MagicKey.onKeyPress(keycode);

        Volt.Debugger.onKeyEvent(keycode);

        if (keycode == Volt.KEY_EXIT) {
            if (AppController.ifSupportExitKey()) {
                AppController.exit();
            } else {
                Volt.setTimeout(function () {
                    Volt.quit();
                }, 1);
            }

            return;
        }
    }
    if (true == checkSmartHubKey(keycode, type)) {
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SMARTHUB_INFO);
        return;
    }
    if (true == checkdevelopKey(keycode, type)) {
        Volt.err("[app.js] onKeyEvent show develop popupp ");
        var param = {};
        Backbone.history.navigate('commonpopup/' + JSON.stringify(param), {
            trigger: true
        });
        return;
    }
    if (true == checkExitKey(keycode, type)) {
        Volt.setTimeout(function () {
            Volt.exitKey();
        },1)
        return;
    }
    var loadingPopup = Volt.require("lib/views/loading-popup.js");

    //when loading popup is show,only reactive to KEY_RETURN/EVENT_KEY_PRESS
    if (true == loadingPopup.createFlag) {
        if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS) {
            Volt.log("[app.js] loadingPopup:" + JSON.stringify(loadingPopup.options));
            if (loadingPopup.options && loadingPopup.options.bLaunching) {

                EventMediator.trigger('COMMON_POPUP_KEY_RETURN_RELEASE');
                return;
            } else {
                EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
            }

        } else {
            Volt.log("[app.js] loadingPopup return");
            return;
        }
    }

    // if Volt.Nav didn't process the event, the app will process it.
    if (Volt.Nav.onKeyEvent(keycode, type) === false) {
        if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS) {
            if (Backbone.history.getCount() > 1) {
                if (Backbone.history.getCount() >= 2) {
                    var beforeViewInfo = Backbone.history.location.history[Backbone.history.getCount() - 2];
                    var strBefore = beforeViewInfo.split('/')[0];
                    if (strBefore == "#detail") {
                        if (Volt.DeviceInfoModel.get('networksStatus') != 'OK') {
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                            return;
                        }
                    }
                }
                Backbone.history.back();
            } else if (Backbone.history.getCache('viewName') != 'main') {
                Volt.log('[app.js @onKeyEvent] Quit');
                Volt.setTimeout(function () {
                    Volt.quit();
                }, 1);
            } else {
                Volt.log('[app.js] exit apps panel, apps panel will hide in background');
                Volt.exit();
                //Volt.quit();
            }
        }
    }
};
Volt.onKeyEvent = onKeyEvent;


////////////////////////////////////////////////////////////////////////////////
//// PRIVATE FUNCTIONS
////////////////////////////////////////////////////////////////////////////////
// phase: 'PRE', 'POST'
function setupEnv(phase) {
    if (phase == 'PRE') {
        Volt.log("[app.js] @setupEnv PRE");

        if (Volt.browser) {
            Volt.DeviceInfoModel.set('networksStatus', 'OK');
        }
        //if (SystemInfo.getIntValue(SystemInfo.KEY_SCREEN_WIDTH) == 1280) {
        //    HALOUtil.enable720P = true;
        //}
        Volt.APPS_REVERSE = (HALOUtil.getOrientation() == 'right-to-left');
        Volt.log("[app.js] Volt.APPS720P = " + (scene.width == 1280));
        Volt.log("[app.js] Volt.APPS_REVERSE = " + Volt.APPS_REVERSE);

        var lang = Volt.DeviceInfoModel.getLanguageCode();
        Volt.i18n.init({
            lng: lang,
            resGetPath: 'lang/<<lng>>.json',
            getAsync: false,
            interpolationPrefix: '<<',
            interpolationSuffix: '>>'
        }, function (t) {});

        // Note: All templates should be required after i18n initialized.
        Volt.require('app/views/overlay-view.js');
        
        checkReset(); //use this api need the image after 2014 11.11

        // This only should be called once.
        // Fix: DF150107-01112: [Apps] Encountered fatal error happen when enter to Skype install page
        Backbone.history.start();

    } else if (phase == 'POST') {
        Volt.log("[app.js] @setupEnv POST");

        // Tasks must be initialized before initWAS
        ServerAPI.initialize();
        DownloadedAppsMgr.initialize();
        
        // Async Tasks, which need time to init at background
        initWASEmp();
        initNetworkEmp();
        initContentsMgrEmp();
        
        // Tasks non-related with timing. init at last
        AppInstallMgr.initialize();
        //checkAccessibility(); //Volt Panel Accessibility (High Contrast & Enlarge)
        
        // Initialize Models
        Volt.require('app/models/models.js').initialize();
    }
}

////////////////////////////////////////////////////////////////////////////////
function onLoad() {
    Volt.log("[app.js @onLoad]");
}

// From outside
var onShow = function (data) {
    Volt.err("[app.js] onShow");

    for (var i in data) {
        Volt.err('******************************************SHOW data[' + i + ']:' + data[i]);
        switch (i) {
        case 'Sub_Menu':
            var viewName = data[i];
            if (viewName == 'Event') {
                startView = 'events';
            } else if (viewName == 'smartHubInfo') {
                startView = 'whatsnew/smartHubPopupView';
            } else {
                startView = 'detail/';
            }
            break;
        case 'widget_id':
            startView += data[i];
            break;
        }
    }
    CommonFunctions.disableMenu();

    // @xiaojun.wang|20150121: Fix CH150120-02178. When showing panel, send 'APPSTART'
    if (Volt.DeviceInfoModel.isWASReady()) {
        KPI.sendLog(KPI.LOG_APP_START);
    } else {
        EventMediator.once(CommonDefines.Event.WAS_READY, function () {
            KPI.sendLog(KPI.LOG_APP_START);
        });
    }
};

var onReset = function (data) {
    Volt.err("[app.js] onReset");
    
    AppController.reset(data);
};

var onActivate = function () {
    Volt.err("[app.js] onActivate");
    var dMode = VDUtil.get3dMode(); // <- getting 3d status
    if (dMode != 0)
    {
            VDUtil.set3dMode(0); //3D effect off <- setting 3d off
    }
    AppController.activate();
    
    CommonFunctions.setAppState(CommonDefines.AppState.APP_STATE_ACTIVATE);
    if (!Volt.bQuickView) {
        if (Volt.DeviceInfoModel.get('mls') == 1) {
            EventMediator.trigger('VOLT_ACTIVATE');
        } else {
            Volt.setTimeout(function () {
                EventMediator.trigger('VOLT_ACTIVATE');
            }, 1);
        }
    }
};

var onDeactivate = function () {
    Volt.err("[app.js] onDeactivate");
    Volt.err("[app.js] onDeactivate:result is 0, need deactive");

    AppController.deactivate();
    
    if (Volt.DeviceInfoModel.get('mls') == 1) {
        EventMediator.trigger('VOLT_DEACTIVATE');
    } else {
        Volt.setTimeout(function () {
            if (CommonFunctions.getAppState() != CommonDefines.AppState.APP_STATE_EXIT) {
                CommonFunctions.setAppState(CommonDefines.AppState.APP_STATE_DEACTIVATE);
            }
            
            EventMediator.trigger('VOLT_DEACTIVATE');
        }, 1);
/*        
        if (typeof gc == 'function') {
            Volt.setTimeout(function () {
                Volt.log('[app.js @onDeactivate] gc()');
                gc();
            }, 800);
        }
*/
    }
};

var onResume = function () {
    Volt.err("[app.js] onResume");
    EventMediator.trigger('VOLT_RESUME');
    CommonFunctions.disableMenu();
    if(Volt.KpiMapper.getPrevPage()){
        Volt.err("[app.js] send enterPage log");
        Volt.KpiMapper.enterPage(Volt.KpiMapper.getPrevPage().eventName)
    }
    
    // @xiaojun.wang|20150121: Fix CH150120-02178. When showing panel, send 'APPSTART'
    if (Volt.DeviceInfoModel.isWASReady()) {
        KPI.sendLog(KPI.LOG_APP_START);
    } else {
        EventMediator.once(CommonDefines.Event.WAS_READY, function () {
            KPI.sendLog(KPI.LOG_APP_START);
        });
    }
};

var onPause = function () {
    Volt.err("[app.js] onPause");
    CommonFunctions.enableMenu();
    if(Volt.KpiMapper.getCurrentPage()){
        Volt.err("[app.js] send leavePage log");
        Volt.KpiMapper.leavePage(Volt.KpiMapper.getCurrentPage().eventName)
    }
    EventMediator.trigger('VOLT_PAUSE');
    
    //// @xiaojun.wang|20150121: Fix CH150120-02178. When hiding panel, send 'APPSTOP'
    if (Volt.DeviceInfoModel.isWASReady()) {
        KPI.sendLog(KPI.LOG_APP_STOP);
    } else {
        EventMediator.once(CommonDefines.Event.WAS_READY, function () {
            KPI.sendLog(KPI.LOG_APP_STOP);
        });
    }
};

var onHide = function () {
    Volt.err("[app.js] onHide");
    CommonFunctions.enableMenu();
    EventMediator.trigger('VOLT_HIDE');
    Volt.KpiMapper.endKPI();

    //// @xiaojun.wang|20150121: Fix CH150120-02178. When hiding panel, send 'APPSTOP'
    if (Volt.DeviceInfoModel.isWASReady()) {
        KPI.sendLog(KPI.LOG_APP_STOP);
    } else {
        EventMediator.once(CommonDefines.Event.WAS_READY, function () {
            KPI.sendLog(KPI.LOG_APP_STOP);
        });
    }
};

var onUnload = function () {
    Volt.err("[app.js] onUnload");
    if(Volt.KpiMapper.getCurrentPage()){
        Volt.err("[app.js] send leavePage log");
        Volt.KpiMapper.leavePage(Volt.KpiMapper.getCurrentPage().eventName)
    }
    EventMediator.trigger('VOLT_UNLOAD');
};

Volt.addEventListener(Volt.ON_LOAD, onLoad);
Volt.addEventListener(Volt.ON_SHOW, onShow);
Volt.addEventListener(Volt.ON_DEACTIVATE, onDeactivate);
Volt.addEventListener(Volt.ON_PAUSE, onPause);
Volt.addEventListener(Volt.ON_RESUME, onResume);
Volt.addEventListener(Volt.ON_ACTIVATE, onActivate);
Volt.addEventListener(Volt.ON_HIDE, onHide);
Volt.addEventListener(Volt.ON_UNLOAD, onUnload);
Volt.addEventListener(Volt.ON_RESET, onReset);

function showQuickView() {
    Backbone.history.navigate('main', {
        trigger: true
    });
};
var setBackgroundBg = function () {
    scene.color = {
        r: 0x0f,
        g: 0x18,
        b: 0x26,
        a: 0xff
    };
};

var checkSmartHubKey = function (keycode, type) {
    var ret = false;
    var arrayPopNum = 0;
    if (type == Volt.EVENT_KEY_RELEASE) {
        return;
    }
    //Volt.log("[app.js] checkSmartHubKey - keycode : " + keycode);
    switch (hiddenKeyArray.length) {
    case 0:
        if (Volt.KEY_CHUP == keycode || '269025047' == keycode) {
            Volt.log("[app.js] checkSmartHubKey -Hidden Key is ok1");
            hiddenKeyArray[0] = keycode;
        }
        break;
    case 1:
        if (Volt.KEY_CHUP == keycode || '50' == keycode) {
            Volt.log("[app.js] checkSmartHubKey -Hidden Key is ok2");
            hiddenKeyArray[1] = keycode;
        } else {
            arrayPopNum = 1;
        }
        break;
    case 2:
        if (Volt.KEY_CHDOWN == keycode || '56' == keycode) {
            Volt.log("[app.js] checkSmartHubKey -Hidden Key is ok3");
            hiddenKeyArray[2] = keycode;
        } else {
            arrayPopNum = 2;
        }
        break;
    case 3:
        if (Volt.KEY_CHUP == keycode || '57' == keycode) {
            Volt.log("[app.js] checkSmartHubKey -Hidden Key is ok4");
            hiddenKeyArray[3] = keycode;
        } else {
            arrayPopNum = 3;
        }
        break;
    case 4:
        if (Volt.KEY_PLAY_BACK == keycode || '49' == keycode) {
            Volt.log("[app.js] checkSmartHubKey -Hidden Key is ok5");
            ret = true;
        }
        arrayPopNum = 4;
        break;
    default:
        break;
    }
    for (var i = 0; i < arrayPopNum; i++) {
        hiddenKeyArray.pop();
    }
    //Volt.log("[app.js] checkSmartHubKey -hiddenKeyArray.length is " + hiddenKeyArray.length);
    return ret;
};
var checkdevelopKey = function (keycode, type) {
    var ret = false;
    var arrayPopNum = 0;
    if (type == Volt.EVENT_KEY_RELEASE) {
        return;
    }
    //Volt.log("[app.js] checkdevelopKey - keycode : " + keycode);
    switch (developKeyArray.length) {
    case 0:
        if ('49' == keycode) {
            developKeyArray[0] = keycode;
        }
        break;
    case 1:
        if ('50' == keycode) {
            developKeyArray[1] = keycode;
        } else {
            arrayPopNum = 1;
        }
        break;
    case 2:
        if ('51' == keycode) {
            developKeyArray[2] = keycode;
        } else {
            developKeyArray = 2;
        }
        break;
    case 3:
        if ('52' == keycode) {
            developKeyArray[3] = keycode;
        } else {
            arrayPopNum = 3;
        }
        break;
    case 4:
        if ('53' == keycode) {
            Volt.log("[app.js] checkdevelopKey -Hidden Key is ok");
            ret = true;
        }
        arrayPopNum = 4;
        break;
    default:
        break;
    }
    for (var i = 0; i < arrayPopNum; i++) {
        developKeyArray.pop();
    }
    //Volt.log("[app.js] checkdevelopKey -developKeyArray.length is " + developKeyArray.length);
    return ret;
};
var checkExitKey = function (keycode, type) {
    var ret = false;
    var arrayPopNum = 0;
    if (type == Volt.EVENT_KEY_RELEASE) {
        return;
    }

    switch (exitKeyArray.length) {
    case 0:
        if (Volt.KEY_MUTE == keycode || '269025047' == keycode) {
            exitKeyArray[0] = keycode;
        }
        break;
    case 1:
        if ('52' == keycode) {
            exitKeyArray[1] = keycode;
        } else {
            arrayPopNum = 1;
        }
        break;
    case 2:
        if ('52' == keycode) {
            exitKeyArray[2] = keycode;
        } else {
            arrayPopNum = 2;
        }
        break;
    case 3:
        if ('52' == keycode) {
            exitKeyArray[3] = keycode;
        } else {
            arrayPopNum = 3;
        }
        break;
    case 4:
        if ('52' == keycode) {
            Volt.log("[app.js] checkExit -Hidden Key is ok");
            ret = true;
        }
        arrayPopNum = 4;
        break;
    default:
        break;
    }
    for (var i = 0; i < arrayPopNum; i++) {
        exitKeyArray.pop();
    }

    return ret;
};
var checkReset = function () {
    Volt.log("[app.js] checkReset()");
    //use this api need the image after 2014 11.11
    if (SmartHubReset && SmartHubReset.needReset) {
        if (SmartHubReset.needReset()) {

            var localStorage = Volt.require("lib/volt-local-storage.js");
            localStorage.clear();
            SmartHubReset.resetComplete();
        } else {
            Volt.log("[app.js] not need reset");
        }
    }
};
var checkAccessibility = function () {
    var highContrast = Volt.DeviceInfoModel.get('highContrast');
    Volt.log("[app.js] checkAccessibility:highContrast is " + highContrast);
    if (highContrast) {
        HALOUtil.highContrast = true;
    } else {
        HALOUtil.highContrast = false;
    }

    var focusZoom = Volt.DeviceInfoModel.get('focusZoom');
    Volt.log("[app.js] checkAccessibility:focusZoom is " + focusZoom);
    if (focusZoom) {
        HALOUtil.enlarge = true;
    } else {
        HALOUtil.enlarge = false;
    }
};

var addNetworkListener = function () {
    voltapi.network.networkConnectionListener(
        function (type) {
            Volt.err("[app.js] network onconnect, type is " + type); // type 0:cable, 1: wireless, 2: gateway
//            EventMediator.trigger(CommonDefines.Event.CONNECT_NETWORK);
            EventMediator.trigger('EVENT_NETWORK_CONNECTION');
        },
        function (type) {
            Volt.err("[app.js] network ondisconnect, type is " + type);
//            EventMediator.trigger(CommonDefines.Event.DISCONNECT_NETWORK);
            EventMediator.trigger('EVENT_NETWORK_CONNECTION');
        }
    );
    Volt.err('[app.js] networksStatus: ' + Volt.DeviceInfoModel.get('networksStatus'));
};

var initNetworkEmp = function () {
    Volt.err("[app.js] initNetworkEmp()");
    var retry = 0;
    var self = this;

    function networkAsyncCallback(is_success) {
        Volt.log('networkAsyncCallback Successful or not:::' + is_success);

        if (Volt.__SIM_NETWORK_STATUS__) {
            Volt.DeviceInfoModel.set('networksStatus', Volt.__SIM_NETWORK_STATUS__);
        } else {
            if (false == voltapi.network.checkNetworkStatus()) {
                Volt.log('network is disconnected');
                Volt.DeviceInfoModel.set('networksStatus', 'NG');
            } else {
                Volt.log('network is connected');
                Volt.DeviceInfoModel.set('networksStatus', 'OK');
            }
        }

        if (is_success) {
            self.addNetworkListener();
        } else {
            Volt.log('networkAsyncCallback Fail, retry::' + retry);
            if (retry < 1) {
                voltapi.network.initAsync(networkAsyncCallback);
                retry++;
            }
        }
    }
    voltapi.network.initAsync(networkAsyncCallback);
};
var initContentsMgrEmp = function () {
    print("[app.js] initContentsMgrEmp()");
    var retry = 0;
    var onOpenCallback = function (is_success) {
        Volt.log('contentMgrAsynCallback:::::is_success=>' + is_success);
        if (is_success) {
            Volt.log("[app.js] Success Callback of ContentsMgr.initAsync()");
            var bConnect = voltapi.ContentsMgr.connect();
            Volt.log("[app.js] checkUSB(), connect: " + bConnect);
        } else {
            Volt.log("[app.js] Fail Callback of ContentsMgr.initAsync(), retry::" + retry);
            if (retry < 1) {
                voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
                retry++;
            }
        }
    };

    var onSuccessCallback = function () {
        Volt.err("[app.js] checkUSB(), connected USB");
        EventMediator.trigger(CommonDefines.Event.CONNECT_USB);
    };

    var onFailCallback = function () {
        Volt.err("[app.js] checkUSB(), disconnected USB");
        EventMediator.trigger(CommonDefines.Event.DISCONNECT_USB);
    };

    voltapi.ContentsMgr.initAsync(onOpenCallback, onSuccessCallback, onFailCallback);
};

function initWASEmp() {
    Volt.log('[app.js] initWASEmp()');
    var retry = 0;

    function WASAsyncCallback(is_success) {
        Volt.log('WASAsyncCallback Successful or not:::' + is_success);
        if (is_success) {
            Volt.err("[app.js] Callback of WAS.initAsync()");
            EventMediator.trigger(CommonDefines.Event.WAS_READY);
            Volt.KpiMapper.init();
            checkAccessibility();

            // Entry to Views
            if (startView != 'whatsnew') {
                Backbone.history.navigate(startView, {
                    trigger: true
                });
            }

        } else {
            Volt.log('WASAsyncCallback Fail, retry :::' + retry);
            if (retry < 1) {
                if (voltapi.WAS.isOpened() === false) {
                    voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
                    retry++;
                }
            }
        }
    }

    function WASAsyncReopenCallback() {
        Volt.log('WASAsyncReopenCallback Successful');
        EventMediator.trigger(CommonDefine.Event.WAS_READY);
    }

    if (voltapi.WAS.isOpened()) {
        WASAsyncCallback(true);
    } else {
        voltapi.WAS.initAsync(WASAsyncCallback, WASAsyncReopenCallback);
    }
}

function checkDeepLink(data) {
    var subMenu, route;

    subMenu = data.Sub_Menu;

    if (subMenu == 'detail') {
        if (data.widget_id) {
            Volt.log('Deep Link: true');
            route = 'detail/' + data.widget_id + '/' + data.caller_id;
        } else {
            Volt.err('[app.js @checkDeepLink] Wrong launch parameters');
        }
    }

    // if (data.caller_id && data.caller_id == 'org.tizen.search-all') {
    // Volt.err("[app.js] onReset, caller_id: " + data.caller_id);
    // route += '/' + data.caller_id;
    // } else {
    // Volt.err("[app.js] onReset, caller_id is not exist.");
    // }

    //Volt.log('Deep Link: ' + Volt.__bDeepLink__);

    return route;
}

var prevKey;
Volt.Debugger = {
    onKeyEvent: function (keyCode) {
        if (!Volt.__DEBUG__) {
            return;
        }

        if (keyCode == Volt.KEY_9) {    // 9 -- Exit
            Volt.setTimeout(function () {
                Volt.quit();
            }, 1);
        }
        
//        if (keyCode == Volt.KEY_8) {
//            Volt.log('[app.js @onKeyEvent] gc()');
//            gc();
//        } else if (keyCode == Volt.KEY_5) {
//            Volt.log('[app.js @onKeyEvent] VDUtil.heapSnapshot()');
//            gc();
//            VDUtil.heapSnapshot();
//        }
//
//        if (Volt.__SIM_21_9__) {
//            if (keyCode == Volt.KEY_4) {
//                Volt.setOffset('-');
//            } else if (keycode == Volt.KEY_6) {
//                Volt.setOffset('+');
//            }
//        }

        // 33 -- Connect, 36 -- Disconnect
        if (Volt.__SIM_NETWORK_STATUS__) {
            if (prevKey == Volt.KEY_3) {
                if (keyCode == Volt.KEY_3) {
                    Volt.__SIM_NETWORK_STATUS__ = 'OK';
                    EventMediator.trigger('EVENT_NETWORK_CONNECTION');
                    keyCode = null;
                } else if (keyCode == Volt.KEY_6) {
                    Volt.__SIM_NETWORK_STATUS__ = 'NG';
                    EventMediator.trigger('EVENT_NETWORK_CONNECTION');
                    keyCode = null;
                }
            }
        }

        prevKey = keyCode;
    }
};
