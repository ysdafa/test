var Backbone = Volt.require('lib/volt-backbone.js');
var EventMediator = Volt.require('app/common/eventMediator.js');
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var _ = Volt.require('modules/underscore.js')._;

var AppsSyncVM = Backbone.Model.extend({
    /** @lends AppsSyncVM.prototype */

    defaults: {
        syncAppList: null,
        toBeUninstall: null,
        toBeInstall: null,
        curUninstallIdx: -1,
        curUninstallAppTitle: '',
        curUninstallProgress: 0
    },

    /**
     * Initialize AppsSyncVM
     * @name AppsSyncVM
     * @constructs
     */
    initialize: function () {

        this.set('syncAppList', new Backbone.Collection([], {
            model: AppInfoModel
        }));
        this.set('toBeInstall', new Backbone.Collection([], {
            model: AppInfoModel
        }));

        this.bindListener();
    },

    destroy: function () {
        this.trigger('destroy');
        this.unbindListener();
    },

    fetch: function () {
        voltapi.WAS.appsSync();
    },

    start: function () {
        voltapi.WAS.appsSync();
    },

    bindListener: function () {
        this.listenTo(EventMediator, CommonDefines.Event.APPS_LIST, this.onAppsList);
        this.listenTo(EventMediator, CommonDefines.Event.APPS_SYNC_COMPLETED, this.onAppsSyncCompleted);
        this.listenTo(EventMediator, CommonDefines.Event.APPS_SYNC_FAIL_NETWORK_ERROR, this.onAppsSyncFail);
        this.listenTo(EventMediator, CommonDefines.Event.APPS_SYNC_FAIL_OTHERS, this.onAppsSyncFail);
    },

    unbindListener: function () {
        this.stopListening();
    },

    onAppsList: function (eventInfo) {
        Volt.log('[AppsSyncVM] onAppsList');

        // eventInfo: 
        // [
        //    {
        //       "app_featured" : 2,
        //       "app_icon" : "/opt/down/common/apps_icon/111399000846.png",
        //       "app_id" : "111399000846",
        //       "app_size" : 0,
        //       "app_state" : 1,
        //       "app_title" : "PressReader",
        //       "app_version" : "1.017",
        //       "icon_colorpick" : "#55AA00",
        //       "title_font_colorpick" : "#D2D2D2"
        //       "firstscreen_icon":"/opt/down/webappservice/apps_icon/FirstScreen/111299001409.png",
        //       "panel_icon":"/opt/down/webappservice/apps_icon/Panel/111299001409.png",
        //    },
        //    ...
        // ]

        if (eventInfo === null) {
            // [TODO] exception handling
            Volt.err('[AppsSyncVM] APPS_LIST event occurs with NO data!');
            return;
        }

        var appList = eventInfo.length ? eventInfo : [],
            filtered = [],
            syncAppList = this.get('syncAppList'),
            toBeInstall = this.get('toBeInstall');

          Volt.log('[AppsSyncVM] parse data is ' + JSON.stringify(appList));
        _.each(appList, function (appData) {
            if (appData.app_id) {
                if ((appData.app_featured == CommonDefines.WAS.APPS_INFO_FEATURED_MYAPP || appData.app_featured == CommonDefines.WAS.APPS_INFO_FEATURED_RECOMMONDED) && appData.app_state == CommonDefines.WAS.WAS_APP_STATE_NEED_INSTALL) {
                    filtered.push(appData);
                }
            }
        });

        syncAppList.reset(appList);
        toBeInstall.reset(filtered);

        if (toBeInstall.length > 0) {
            this.trigger('SYNC_TO_BE_INSTALL', toBeInstall.toJSON());
        }

    },

    onAppsSyncCompleted: function () {
        Volt.log('[AppsSyncVM] onAppsSyncCompleted');
        this.trigger('APPS_SYNC_COMPLETED');
    },

    onAppsSyncFail: function () {
        Volt.log('[AppsSyncVM] onAppsSyncFail');
        this.trigger('APPS_SYNC_COMPLETED');
    }

});

var AppInfoModel = Backbone.Model.extend({
    /** @lends AppInfoModel.prototype */

    // app_state enum  
    // {
    //     WAS_APP_STATE_DEFAULT = 0,
    //     WAS_APP_STATE_NEED_INSTALL,
    //     WAS_APP_STATE_NEED_UNINSTALL,
    //     WAS_APP_STATE_NEED_UPDATE
    // } was_app_state_e;

    defaults: {
        app_featured: 1, // 1: MyApps, 2: Recommended
        app_icon: '', // ex) /opt/down/common/apps_icon/111199000396.png
        app_id: '', // ex) 111199000396
        app_size: 0, // ?
        app_state: 2, // app_state enum
        app_title: '', // PressReader
        app_version: '', // 1.017
        icon_colorpick: '', // #711C71
        title_font_colorpick: '', // #D1D1D1
        panel_icon: '',

        is_need_update: 0,
        is_updating: true,
        is_dim: true,
        state: 'UPDATE_START',
        progress: 0
    }
});

exports = AppsSyncVM;