var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require('modules/underscore.js')._,

    voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js'),
    MyAppsModel = Volt.require('app/models/myAppsModel.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js');

var localStorage = Volt.require("lib/volt-local-storage.js");
var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var DownloadedAppsMgr = Volt.require("app/common/downloadedAppsMgr.js");
var MyAppsCollection = Backbone.Collection.extend({

    model: MyAppsModel,
    viewmode: CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD,

    initialize: function () {
        Volt.log('[MyAppsCollection] initialize');

        this.bindEventListener();
    },

    fetch: function (viewmode) {
        Volt.log('[MyAppsCollection] fetch');
        
        var appList = this.getAppList(viewmode);
        try {
            // for debug
            var jsonStr = JSON.stringify(appList);
            Volt.err('[MyAppsCollection] WAS.getAppList : ' + jsonStr);
            var appListData = this.parse(appList);
            var cachingData = localStorage.getItem('apps-myaps-caching-data');
            if (cachingData && cachingData.length > 0) {   //cache data exist 
                if(appListData.length == cachingData.length){
                    Volt.log('[MyAppsCollection] fetch, use caching data');
                    this.reset(cachingData);
                }else{
                    Volt.log('[MyAppsCollection] fetch, applist data length is not match to caching data length, use applist data');
                     this.reset(appListData);
                }
            }else{
                Volt.log('[MyAppsCollection] fetch, caching data not exist, use applist data');
                this.reset(appListData);
            }

        } catch (e) {
            Volt.err('[MyAppsCollection] WAS.getAppList Error : ' + e);

            this.trigger('error', e);
        }
    },

    getAppList: function (viewmode) {

        if (viewmode !== undefined) {
            this.viewmode = viewmode;
        }

        var type = CommonDefines.WAS.APPS_TYPE_ALL,
            premium = CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE,
            feature = CommonDefines.WAS.APPS_INFO_FEATURED_ALL,
            index = 0, // from
            count, appList;

        count = voltapi.WAS.getAppCount(type, premium, feature);
        appList = voltapi.WAS.getAppList(type, premium, feature, this.viewmode, index, count);

        return appList;
    },

    parse: function (appList) {
        Volt.log('[MyAppsCollection] parse data is ' + JSON.stringify(appList));

        var filtered = [];

        _.each(appList, function (appData) {

            if (appData.app_id) {
                if ((appData.app_featured == CommonDefines.WAS.APPS_INFO_FEATURED_MYAPP || appData.app_featured == CommonDefines.WAS.APPS_INFO_FEATURED_RECOMMONDED) && appData.is_hidden == 0) {
                    filtered.push(appData);
                }
            }
        });

        return filtered;
    },

    refresh: function () {
        Volt.log('[MyAppsCollection] refresh');

        var appList = this.getAppList();

        try {

            // for debug
            var jsonStr = JSON.stringify(appList);
            Volt.err('[MyAppsCollection] WAS.getAppList : ' + jsonStr);

            this.set(this.parse(appList));

        } catch (e) {
            Volt.err('[MyAppsCollection] WAS.getAppList Error : ' + e);

            this.trigger('error', e);
        }
    },

    bindEventListener: function () {
        Volt.log('[MyAppsCollection] bindEventListener');

        this.listenTo(EventMediator, CommonDefines.Event.WAS_READY, _.bind(this.onWASReady, this));
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_COMPLETED, _.bind(this.onInstallComp, this));
        this.listenTo(EventMediator, CommonDefines.Event.UNINSTALL_COMPLETED, _.bind(this.onUninstallComp, this));

        voltapi.vconf.setOnChangeHandler(CommonDefines.Vconf.MEMORY_WAS_APP_CHANGE, _.bind(this.onWASAppChange, this));
    },

    onWASReady: function () {
        Volt.log('[MyAppsCollection] onWASReady');

        /*var sortOption = localStorage.getItem('sortOption') || 0,
            viewmode = CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD;

        switch (sortOption) {
        case 0:
            viewmode = CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD;
            break;

        case 1:
            viewmode = CommonDefines.WAS.VIEWMODE_MOSTLYPLAYED;
            break;

        case 2:
            viewmode = CommonDefines.WAS.VIEWMODE_A_TO_Z;
            break;

        case 3:
            viewmode = CommonDefines.WAS.VIEWMODE_Z_TO_A;
            break;
        }*/

        this.fetch(CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD);
    },

    onInstallComp: function (info) {
        Volt.log('[MyAppsCollection] onInstallComp');

        // info: {
        //     app_id
        //     result
        // }

        var appData = voltapi.WAS.getAppInfo(info.app_id);

        // for debug
        try {
            var jsonStr = JSON.stringify(appData);
            Volt.err('[MyAppsCollection] WAS.getAppInfo : ' + jsonStr);
        } catch (e) {
            Volt.err('[MyAppsCollection] WAS.getAppInfo Error : ' + e);
        }
        Volt.log('[MyAppsCollection] appData.is_hidden is ' + appData.is_hidden);
        if(0 == appData.is_hidden){
               this.add(this.parse([appData]));
        }else{
               this.remove(this.findWhere({
                   app_id: appData.app_id
               }));
        }
    },

    onUninstallComp: function (info) {
        Volt.log('[MyAppsCollection] onUninstallComp');

        this.remove(this.findWhere({
            app_id: info.app_id
        }));
    },

    onWASAppChange: function () {
        Volt.err('[MyAppsCollection] onWASAppChange');

        // http://kms.sec.samsung.net/club/club.menu.bbs.read.screen?page_num=1&p_club_id=4968&p_menu_id=15&p_group_id=null&message_id=3005970
        // When user do the installation, uninstallation , update, usb plugin/plugin out(some apps has been installed in usb) operation, WAS will set the vconf value to be 1.
        EventMediator.trigger(CommonDefines.Event.EVENT_CHECK_DETAIL_BUTTON);//check detail button
        
        var appList = this.getAppList();

        try {

            // for debug
            var jsonStr = JSON.stringify(appList);
            var appLength = this.parse(appList).length;
            Volt.err('[MyAppsCollection] this.length is ' + this.length);
            Volt.err('[MyAppsCollection] appList      is ' + appLength);
            if(this.length == appLength){  //if update apps completely,do no need reset
                     this.set(this.parse(appList), {
                        remove: false
                    });
            }else{
                  var wasSyncState = voltapi.WAS.getAppsSyncState();
                  Volt.err('[MyAppsCollection] wasSyncState is ' + wasSyncState);
                  if(wasSyncState != CommonDefines.WAS.WAS_APPS_SYNC_COMPLETED){
                        Volt.err('[MyAppsCollection] WAS APPS SYNC not COMPLETED');
                        return;
                  }
                 if (AppInstallMgr.installList.length || AppInstallMgr.unInstallList.length) {
                      this.listenTo(EventMediator, CommonDefines.Event.EVENT_UPDATE_MYAPPS_VIEW, _.bind(this.updateMyappView, this));
                  }else{
                      this.reset(this.parse(appList), {
                          remove: false
                      });
                      DownloadedAppsMgr.fetch();
                   }   
             }
        } catch (e) {
            Volt.err('[MyAppsCollection] WAS.getAppList Error : ' + e);
            this.trigger('error', e);
        }
    },
   updateMyappView: function () {
        Volt.err('[MyAppsCollection] updateMyappView');
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_UPDATE_MYAPPS_VIEW);
        var appList = this.getAppList();
        try {
            // for debug
            var jsonStr = JSON.stringify(appList);
            var appLength = this.parse(appList).length;
            Volt.err('[MyAppsCollection] this.length is ' + this.length);
            Volt.err('[MyAppsCollection] appList      is ' + appLength);
            if(this.length != appLength){  //usb connect and disconnect when apps is install or unstall
                this.reset(this.parse(appList), {
                    remove: false
                });
                DownloadedAppsMgr.fetch();
            }
        } catch (e) {
            Volt.err('[MyAppsCollection] WAS.getAppList Error : ' + e);
            this.trigger('error', e);
        }
    }
});

exports = MyAppsCollection;