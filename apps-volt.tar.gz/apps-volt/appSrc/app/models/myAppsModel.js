/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview MyApps Model.
 * @date    2014/09/17 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._;

/**
 * @name MyAppsModel
 */
var MyAppsModel = Backbone.Model.extend(
    /** @lends MyAppsModel.prototype */
    {
        defaults: {
            app_featured: '',
            app_icon_path: '',
            app_id: '',
            app_index: '',
            app_installed_path: '',
            app_package_name: '',
            app_panel_icon_path: '',
            app_runtitle: '',
            app_size: '',
            app_title: '',
            app_tizen_id: '',
            app_type: '',
            app_version: '',
            app_widget_category: '',
            icon_colorpick: '',
            installState: '',
            install_date: '',
            installed_source_type: '',
            is_display: '',
            is_hidden: '',
            is_lock: '',
            is_multi_screen: '',
            is_need_update: '',
            is_network: '',
            is_premium_game: '',
            is_removable: '',
            is_support_gesture: '',
            is_support_voice: '',
            is_updated: '',
            rating: '',
            title_font_colorpick: '',
            type: '',
            use_count: ''
        },

        idAttribute: 'app_id',

        /**
         * Initialize MyAppsModel
         * @name MyAppsModel
         * @constructs
         */
        initialize: function () {},

        /**
         * parse given data
         * @method
         * @param  {object} appInfoData object coverted into json string
         * @return {object}             object coverted into json string
         */
        parse: function (appInfoData) {

            try {
                return appInfoData;
            } catch (e) {
                console.error('[myAppsModel.js] parse error : ' + e);
                return false;
            }

        }
    });

exports = MyAppsModel;