/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages categories list view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require("modules/VoltJSON.js");

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js');
var CategoriesListTemplate = Volt.require('app/templates/1080/categoriesListTemplate.js');
var GridListView = Volt.require('app/views/gridListView.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var AppInfoProgressView = Volt.require("app/views/appInfoProgressView.js");
var GridListTemplate = Volt.require('app/templates/grid-list-template.js');
var AppInfoVMCollection = Volt.require('app/models/appInfoVMCollection.js');
var Models = Volt.require('app/models/models.js');
var localStorage = Volt.require("lib/volt-local-storage.js");
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");
var tvResolution = (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080;
var isRemainGridList = false;
var sortOption = ['releasedate', 'popularity', 'titleasc', 'titledesc'];

var CategoriesListView = Volt.BaseView.extend({
    /** @lends CategoriesListView.prototype */
    appInfoVMCollection: null,
    template: CategoriesListTemplate.container,
    
    gridView: null,
    grid: null,
    
    parameters: {},
    currentFetchedPage: 0,
    viewList: null,
    isShown: false,
    sortStandard: sortOption[0],
    noContentBtn:null,
    
    exitFlag: false,
    
    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * Initialize this view
     * @method
     */
    initialize: function () {
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
        this.listenTo(EventMediator, 'GRID_FOVEA_DISABLE', _.bind(this.removefoveaEffect, this));
        this.listenTo(EventMediator, 'GRID_FOVEA_ENABLE', _.bind(this.addfoveaEffect, this));
        
        this.listenTo(EventMediator, 'VOLT_EXIT', this.onExit);
    },
    /**
     * set msgbox button click callback
     * @method  caoyr 11.15
     * @memberof categoriesListView
     */
    processMsgBoxEvent: function (data) {
        Volt.log('[categoriesListView] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
                Volt.log('[categoriesListView] processMsgBoxEvent: ok');
                Backbone.history.back();

                break;
            default:
                break;
            }
        } else if (data.eventType == CommonDefines.Event.SELECT_BTN2) {
            Volt.log('[detail-view.js] processMsgBoxEvent:SELECT_BTN2');
        }
    },
        /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (widget) {
            if (widget.id == ('categories-list-button-' + this.parameters.categoryId)) {
                    if(this.noContentBtn){
                         this.noContentBtn.setFocus();
                    }
            } 
        }
    },

    /**
     * When blured on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onBlur: function (widget) {
    },
    /**
     * Render once after view is created
     * @method
     */
    render: function (parentWidget, categoryId) {
        Volt.log('[CategoriesListView @render] categoryId: ' + categoryId);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_FOCUS_ZOOM, this.resetListImage);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_HIGH_CONTRAST, this.resetListImage);
        
        var contentContainer = parentWidget.widget.getChild('main-content-container');
        this.parameters = new Object();
        this.parameters = _.extend(this.parameters, {
            categoryId: categoryId,
            categoryTitle: '',
            param: {
                perPage: 60,
                sort: sortOption[0],
                page: '1'
            }
        });

        this.parameters.categoryId = categoryId;

        this.setWidget(Volt.loadTemplate(this.template, {
            type: this.parameters.categoryId
        }));
        contentContainer.addChild(this.widget);
        if (!this.appInfoVMCollection) {
            this.appInfoVMCollection = new AppInfoVMCollection();
            print("this.parameters.categoryId is " + this.parameters.categoryId);
            this.appInfoVMCollection.setCollection('categories', this.parameters.categoryId);
        }

    },
    
    onExit: function () {
        this.exitFlag = true;
    },
    
    createNocontentButton: function () {
        Volt.err('[CategoriesListView] createNocontentButton');
        if (this.noContentBtn) {
            Volt.err('[CategoriesListView] this.noContentBtn is exist');
            return;
        }
        var btnStyle = {
            style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resolution: tvResolution,
        };
        var btnBG = this.widget.getDescendant('categories-list-button-' + this.parameters.categoryId);
        if (btnBG) {
            Volt.err('[CategoriesListView] createNocontentButton');
            this.noContentBtn = Volt.loadTemplate(CategoriesListTemplate.troubelShootBtn, btnStyle);
            btnBG.addChild(this.noContentBtn);
            this.noContentBtn.setText({
                state: "all",
                text: Volt.i18n.t('TV_SID_TROUBLESHOOT'),
            });
        }
        btnBG.custom = {
            focusable: true
        };
        Volt.Nav.setNextItemRule(btnBG, 'right', btnBG);
        var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
        if (wzNoContent) {
            wzNoContent.text = Volt.i18n.t('TV_SID_MIX_NOT_CONNECTED_INTERNET_FEATURE').replace('<<A>>', 'AS000');
        }

        Volt.err('[CategoriesListView] createNocontentButton');
        var btnListener = this.btnListener = new ButtonListener();
        btnListener.onButtonClicked = function (button, type) {
            var aulApp = new Aul();
            aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
        }.bind(this);

        this.noContentBtn.addListener(btnListener);
        Volt.Nav.reload();
        Volt.Nav.focus(btnBG);

        //// @xiaojun.wang|20150215: Refresh when network is connected again
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS, this.onChangeNetwork);
    },
    destroyNocontentButton: function () {
        Volt.err('[CategoriesListView] destroyNocontentButton');
        if (this.noContentBtn) {
            
            var btnBG = this.widget.getDescendant('categories-list-button-' + this.parameters.categoryId);
            
            if (Volt.Nav.getCurrentFocus() == btnBG) {
                EventMediator.trigger('EVENT_CATEGORY_SET_FOCUS');
            }
            
            if (btnBG) {
                Volt.Nav.removeItem(btnBG, true);
                btnBG.removeChild(this.noContentBtn);
            }
            this.noContentBtn.destroy();
            this.noContentBtn = null;
            
//            Volt.Nav.reload();
        }
        var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
        if (wzNoContent) {
            wzNoContent.text = "";
        }

        //// @xiaojun.wang|20150215: Refresh when network is connected again
        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS);
    },
    /**
     * Render contents of this view.
     * @method
     * @param  {collection} collection Fetched data from server of categories app list.
     */
    renderContent: function (collection, options) {
        Volt.log('[CategoriesListView] renderContent');

        var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
        if (this.appInfoVMCollection.length > 0) {
            EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
            if (wzNoContent) {
                wzNoContent.text = '';
            }
            if (this.gridView) {
                this.updateContent();
                return;
            }
            var gridListContainer = this.widget.getChild('categories-list-content-container-' + this.parameters.categoryId);

            CategoriesListTemplate.gridList.parent = gridListContainer;
            
            this.initNativeGrid();

            var grid = this.grid;
            
            gridListContainer.addChild(grid);
            grid.showWithAnimation();

            this.currentFetchedPage = this.appInfoVMCollection.collection.getPageInfo().page;

            Volt.Nav.setNextItemRule(grid, 'up', 'category-list-container');
            Volt.Nav.setNextItemRule(grid, 'left', grid);
            Volt.Nav.setNextItemRule(grid, 'right', grid);

            Volt.Nav.reload();
            //    Volt.Nav.focus(this.gridView);
        } else {
            //if (wzNoContent && options.previousModels.length == 0) {
            if (wzNoContent && !this.gridView) {
                EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
                wzNoContent.text = Volt.i18n.t('COM_NO_CONTENT_FOUND');
            }
        }
    },
    updateContent: function () {
        Volt.log("[CategoriesListView.js] updateContent this.grid.itemCount = " + this.grid.itemCount(0));
        Volt.log("[CategoriesListView.js] updateContent this.appInfoVMCollection.length = " + this.appInfoVMCollection.length);
        if (this.gridView) {
            if (this.appInfoVMCollection.length > 0) {
                for (var i = 0; i < this.appInfoVMCollection.length; i++) {

                    if (i >= this.grid.itemCount(0)) {
                        this.gridView.addItem(this.appInfoVMCollection.at(i));
                    } else {
                        var data = this.grid.getData(0, i);
                        data.model = this.appInfoVMCollection.at(i);
                        Volt.log('update content:data.model.title ' + data.model.get('title'));
                    }
                }
            }
            this.grid.updateAllItems(0);
        }
    },
    /**
     * Render content each item by added to model.
     * @method
     * @param  {model} model Added model.
     */
    renderContentPerItem: function (model, collection) {
        Volt.log('[CategoriesListView] renderContentPerItem');
        this.currentFetchedPage = this.appInfoVMCollection.collection.getPageInfo().page;
        this.gridView.addItem(model);
    },

    renderReturnButton: function () {
        var wzReturnButton = this.widget.find('.categories-list-header-returnicon-area'),
            wzTitle = this.widget.find('.categories-list-header-text'),
            nTitleX = 36;

        if (Volt.DeviceInfoModel.get('visibleCursor') == '1') {
            wzReturnButton[0].show();
            wzTitle[0].x = wzReturnButton[0].width + nTitleX;
        } else {
            wzReturnButton[0].hide();
            wzTitle[0].x = nTitleX;
        }
    },

    initNativeGrid: function () {
        var self = this;
        var wzGridView = null;
        this.viewList = new Array();

        this.gridView = new GridListView({
            gridListControlParam: CategoriesListTemplate.gridList,
            thumbnailStyle: GridListTemplate.THUMB_CATEGORY,
            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[CategoryListView @onDrawLoadData] index: ' + data._index);
                    var model = data.model;

                    var iCategoriesAppInfoView = new CategoriesAppInfoView(model);
                    iCategoriesAppInfoView.render(data._index, thumbnail);

                    self.viewList[data._index] = iCategoriesAppInfoView;
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.log('[CategoryListView @onDrawUpdateData] index: ' + data._index);
                    self.viewList[data._index].updateItemView(thumbnail, data);
                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[CategoryListView @onDrawUnloadData] index: ' + data._index);

                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }

                    //// @xiaojun.wang|20150120: Fix DF150119-00713
                    delete self.viewList[data._index];
                },
                onGridFocus: function (wzFocused) {
                    Volt.log('[CategoryListView] onGridFocus');

                    gc();

                    if (wzFocused) {
                        var voiceText = self.parameters.categoryTitle + ' ' +
                            Volt.i18n.t('SID_CATEGORY_KR_CA') + ',' +
                            Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', self.appInfoVMCollection.length) + ',' +
                            wzFocused.customTitle + ',' + Volt.i18n.t('TV_SID_VOICE_GUIDE_NOT_AVAIIL_ALL_APPS');

                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.log('[CategoryListView] onGridBlur');

                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo, fromItemIndex, toItemIndex) {
                    Volt.log('[CategoryListView] onFocusChanged wzFrom is ' + fromItemIndex + ',wzTo is ' + toItemIndex);
                    if (wzFrom && wzTo) {
                        CommonFunctions.voiceGuide(wzTo.customTitle);
                    }
                    //add by pei828.yang 20141206 If total items is bigger than 60 and move to last item, need to request next more 60 items & add them to gridlist.
                    if (self.appInfoVMCollection.length >= 10) {
                        if (toItemIndex >= (self.appInfoVMCollection.length - 10)) {
                            Volt.log('[CategoryListView] self.appInfoVMCollection.length = ' + self.appInfoVMCollection.length);
                            Volt.log('[CategoryListView] self.appInfoVMCollection.collection.getPageInfo().total = ' + self.appInfoVMCollection.collection.getPageInfo().total);
                            if (self.appInfoVMCollection.length < self.appInfoVMCollection.collection.getPageInfo().total) {
                                self.parameters.param.page = (parseInt(self.currentFetchedPage) + 1).toString();
                                Volt.log('[CategoryListView] this.parameters.param.page is ' + self.parameters.param.page);
                                Volt.log('[CategoryListView] self.appInfoVMCollection.collection.getPageInfo().lastPage is ' + self.appInfoVMCollection.collection.getPageInfo().lastPage);
                                if (parseInt(self.parameters.param.page) <= parseInt(self.appInfoVMCollection.collection.getPageInfo().lastPage)) {
                                    self.appInfoVMCollection.setDefaultParameters(self.parameters);
                                    self.fetchServer(false);
                                }
                            }
                        }
                    }
                },
                onItemPress: function (wz, itemData, data) {
                    Volt.log('[CategoryListView] onItemPress');

                    self.SelectItem(itemData.itemIndex, data.model);
                },
                onEnterKeyLongPressed: function (wzFocused, itemIndex, type) {
                    if (wzFocused && itemIndex != -1) {
                        if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                            return;
                        }
                        var vmSelected = self.appInfoVMCollection.collection.at(itemIndex),
                            iSelectedContext = self.viewList[itemIndex];

                        var param = {
                            baseWidget: wzFocused,
                            appInfoVM: vmSelected,
                            parentView: iSelectedContext,
                            type: iSelectedContext.type,
                            feature: iSelectedContext.feature
                        }

                        if (type == 'mouse') {
                            param.setfocus = true;
                        }
                        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU, param);

                        /*
                                        if (type == 'mouse') {
                                            EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_RELEASE);
                                        }
                                        */
                        Volt.KpiMapper.addEventLog('LONGPRESSSC');
                    }
                }
            }
        });

        this.grid = this.gridView.render(this.appInfoVMCollection).widget;
        this.grid.custom = {
            focusable: true
        };
        return true;
    },
    
    removeGrid: function () {
        Volt.log('[CategoriesListView] remove grid list');

        if (this.gridView) {            
            Volt.Nav.removeItem(this.grid, true);
            
            this.gridView.remove();
            this.grid = null;
        }
    },


    /**
     * When user select the app info, this function will triggered.
     * @method
     * @param  {int} index Triggered item index
     */
    SelectItem: function (index, model) {
        Volt.log('[CategoriesListView] CategoriesAppInfoView :: onSelect : ' + index);
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
            return;
        }
        isRemainGridList = true;


        var sCategoryId = this.appInfoVMCollection.categoryId || this.appInfoVMCollection.collection.categoryId,
            nRemain = sCategoryId % 11,
            sCategoryName = '';

        Volt.log('[CategoriesListView] SelectItem :: nRemain : ' + nRemain);

        switch (nRemain) {
        case 5:
            sCategoryName = 'VIDEO';
            break;
        case 6:
            sCategoryName = 'SPORT';
            break;
        case 7:
            sCategoryName = 'GAME';
            break;
        case 8:
            sCategoryName = 'LIFESTYLE';
            break;
        case 9:
            sCategoryName = 'INFORMATION';
            break;
        case 10:
            sCategoryName = 'EDUCATION';
            break;
        case 0:
            sCategoryName = 'KIDS';
            break;

        default:
            sCategoryName = 'ALL';
            break;
        }

        Backbone.history.navigate('detail/' + model.get('id'), {
            trigger: true
        });


        Volt.KpiMapper.addEventLog('SELECTSC', {
            d: {
                cn: sCategoryName,
                appid: model.get('id'),
                pn: model.get('order')
            }
        });
    },

    /**
     * Show this view.
     * @method
     * @param  {object} param Parameters
     * @param  {enum} animationType Animation type to showing this view.
     * @return {deferred} Deferred promise return.
     */
    show: function (param, animationType) {
        Volt.log('[CategoriesListView] show');
        this.listenTo(EventMediator, 'SORT_GRID_LIST', this.onSortGridList);

        this.isShown = true;

        var self = this;
        var deferred = Q.defer();

        isRemainGridList = false;
        this.parameters.categoryId = param.id;
        this.parameters.categoryTitle = param.title;

        if (this.gridView && this.sortStandard == sortOption[localStorage.getItem('sortOption')]) { // to be changed :: 
            this.widget.show();
            EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

            if (this.exitFlag) {
                this.resetFocus();
            }
            
            this.grid.showWithAnimation();

            Volt.Nav.addItem(this.grid, true);

            for (var i in this.viewList) {
                this.viewList[i].showProgressBar();
            }

            //            Volt.Nav.reload();

            var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
            var isDetail = (/#detail/g).test(previousHistory);

            if (isDetail) {
                Volt.Nav.focus(this.grid);
            } else {
                this.grid.setFocusItemIndex(0, 0);
            }

        } else {
            if (Volt.DeviceInfoModel.get('networksStatus') == 'OK') {

                //TODO:
                if (this.gridView) {
                    for (var i in this.viewList) {
                        this.viewList[i].hideProgressBar();
                    }
                    this.gridView = null;
                    this.grid = null;
                }

                this.sortStandard = sortOption[localStorage.getItem('sortOption')];
                this.parameters.param.sort = this.sortStandard; // to be changed :: sortOption[index];
                this.appInfoVMCollection.setDefaultParameters(this.parameters);
                EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING');
                this.fetchServer(true);
            } else {
                this.appInfoVMCollection.setDefaultParameters(this.parameters);
                this.createNocontentButton();
            }
            this.widget.show();
        }

        // Clear Exit Flag
        this.exitFlag = false;
        
        // Listen to model
        if (this.appInfoVMCollection) {
            this.listenTo(this.appInfoVMCollection, 'reset', this.renderContent);
            this.listenTo(this.appInfoVMCollection, 'add', this.renderContentPerItem);
            this.listenTo(this.appInfoVMCollection, 'error', this.showErrorPopup);
            this.appInfoVMCollection.startListeningEvent();
        }

        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS, this.onFocusGrid);
        deferred.resolve();
        return deferred.promise;
    },
    
    removefoveaEffect: function () {
        if (!this.grid == null) {
            this.grid.foveaEffect = false;
        }
    },
    addfoveaEffect: function () {
        if (!this.grid == null) {
            this.grid.foveaEffect = true;
        }
    },
    /**
     * hide this view.
     * @method
     * @param  {enum} animationType Animation type to hiding this view.
     * @return {deferred} Deferred promise return.
     */
    hide: function (animationType) {
        Volt.log('[CategoriesListView] hide');
        var deferred = Q.defer();
        deferred.resolve();

        // this.renderTotalCount(true);
        this.isShown = false;
        this.widget.hide();
        this.destroyNocontentButton();
        if (!isRemainGridList) {
            // force to deactive auto scroll widget
            if (this.grid) {
                Volt.Nav.removeItem(this.grid, true);
                this.grid.hideWithAnimation();
                for (var i in this.viewList) {
                    this.viewList[i].hideProgressBar();
                }
            }
        }
        
        if (this.appInfoVMCollection) {
            this.stopListening(this.appInfoVMCollection);
            this.appInfoVMCollection.stopListeningEvent();
        }

        this.stopListening(EventMediator, 'SORT_GRID_LIST');
        this.stopListening(EventMediator, 'VOLT_DEACTIVATE');
        this.stopListening(EventMediator, 'GRID_FOVEA_DISABLE');
        this.stopListening(EventMediator, 'GRID_FOVEA_ENABLE');
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS);
        
        return deferred.promise;
    },

    /**
     * Pause this view.
     * @method
     */
    pause: function () {
        Volt.log('[CategoriesListView] pause');

        /*if (this.loading) {
            this.hideLoading();
        }*/
        if (this.isShown) {
            EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
        }
    },

    /**
     * Resume this view.
     * @method
     */
    resume: function () {
        Volt.log('[CategoriesListView] resume');
        if (this.isShown) {
            this.widget.show();
        }
    },

    resetFocus: function () {
        Volt.log('[categoriesListView.js @resetFocus]');

        if (this.gridView) {
            var grid = this.grid;

            if (grid.getFocusItemIndex().itemIndex !== 0) {

                try {
                    HALOUtil.enableAUI(false);
                    Volt.log('HALOUtil.enableAUI(false)');
                } catch (e) {}

                grid.setFocusItemIndex(0, 0);
                grid.showFocus('false');
                grid.hideFocus('false');

                try {
                    HALOUtil.enableAUI(true);
                    Volt.log('HALOUtil.enableAUI(true)');
                } catch (e) {}
            }
        }
    },

    /**
     * Callback function of plus button select.
     * @method
     * @param  {int} index    Selected index of menu
     * @param  {int} subIndex Selected index of sub menu
     */
    onSortGridList: function (index) {
        Volt.log('[CategoriesListView] onSortGridList');
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
            return;
        }
        var deferred = Q.defer(),
            optionMenu = parseInt(index, 10);

        this.sortStandard = sortOption[optionMenu];

        if (index == -1) return;

        this.parameters.param.page = '1,2';

        // force to deactive auto scroll widget
        if (this.gridView) {
            for (var i in this.viewList) {
                this.viewList[i].hideProgressBar();
            }
        }

        var wzNoContent = this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId);
        wzNoContent.text = '';

        //this.gridView = null;

        this.parameters.param.sort = this.sortStandard;
        this.appInfoVMCollection.setDefaultParameters(this.parameters);
        EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING');
        this.fetchServer(true);

        Volt.KpiMapper.addEventLog('SELECTOPTION', {
            d: {
                //con: this.sortStandard //EV005 : {cp=N01_NEW;sappid=org.volt.apps;sappver=1412}
            }
        });
        deferred.resolve();
        return deferred.promise;
    },

    showErrorPopup: function (serverError) {
        Volt.log("[categoriesListView.js @showErrorPopup");
        if (this.appInfoVMCollection.length > 0){
            Volt.log("[categoriesListView.js @list already exist, do not show error message");
        }
        else{
            this.widget.getChild('categories-list-no-content-container-' + this.parameters.categoryId).text = serverError.message;
        }
        return;
    },

    initParameters: function () {
        this.parameters.param.perPage = 30;
        // no need to init sort option.
        this.parameters.param.page = '1';
        this.currentFetchedPage = 0;
    },

    resetListImage: function(){
        Volt.log('[categoriesListView.js @resetListImage]');
        if(Volt.DeviceInfoModel.get('highContrast')){
            if(this.grid){
                this.grid.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/acc_focus.png'), -4, -4);
            }
        }
        else{
            if(this.grid){
                this.grid.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -4, -4);
            }
        }
    },


    onFocusGrid:function(){
        Volt.log('[featuredListView.js @onFocusGrid]');
        if ( this.grid && this.grid.custom.focusable == true ){
            Volt.Nav.focus(this.grid);
        }

    },
    
    fetchServer: function (value) {
        if (Volt.DeviceInfoModel.get('networksStatus') == "OK") {
            this.destroyNocontentButton();
            Q.all([
                       this.appInfoVMCollection.fetch(value)
                   ])
                .then(_.bind(function () {}, this))
                .fail(_.bind(function () {
                    EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
                }, this));
        } else if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
            EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
            this.createNocontentButton();
        }
    },
    
    onChangeNetwork: function() {
        EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING');
        this.fetchServer();
    }
});

var CategoriesAppInfoView = Volt.BaseView.extend({
    /** @lends CategoriesAppInfoView.prototype */
    thumbnail: null,
    thumbListener: null, // Thumbnail Listener for color pick

    progressView: null,
    /**
     * Initialize CategoriesInfoView
     * @method
     * @param  {model} viewModel CategoriesInfoView view model
     */
    initialize: function (viewModel) {
        this.VM = viewModel;
        this.listenTo(this.VM, 'change', this.renderChange);
    },

    bindListener: function () {
        this.listenTo(this.VM, 'change', this.renderChange);
        this.listenTo(this.VM, 'DESTROY_VIEW', this.remove);
        this.showProgressBar();
    },

    unbindListener: function () {
        this.stopListening();
        this.hideProgressBar();
    },

    /**
     * Render this view
     * @method
     * @param  {int} index  Index of CategoriesInfoView
     * @param  {widget} widget Widget of CategoriesInfoView
     */
    render: function (index, iThumbnail) {
        var data = this.VM.toJSON();

        if (iThumbnail) {
            this.thumbnail = iThumbnail;
            var icon = data.icon ? data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT) : '';
            var screenshot = data.screenshot ? data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT) : '';

            if (screenshot) {
               this.thumbnail.setContentImage(screenshot);
                this.useDefaultImage = false;
            } else {
                this.thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                this.useDefaultImage = true;
            }
            this.thumbnail.setInformationIcon("icon2",icon);
            this.thumbnail.setInformationText("text1",data.title ? data.title : '');
            this.thumbnail.setInformationText("text2",data.updated ? CommonFunctions.convertDate(data.updated.split('T')[0]) : '');
            this.thumbnail.setInformationText("text3",data.fileSize ? this.convertByte(data.fileSize) : '');

            var self = this;

            this.thumbListener = new ThumbnailListener;
            this.thumbListener.onImageReady = function (thumbnail, id, success) {
                thumbnail.border = {width:0, color: Volt.hexToRgb('#000000', 0)};
                if (success) {
                    if (self.useDefaultImage) {
                    }
                } else {
                    thumbnail.timeId = Volt.setTimeout(function () {
                        thumbnail.setContentImage(GridListTemplate.defaultScreenShot);
                        self.useDefaultImage = true;
                        thumbnail.timeId = null;
                    }, 0);
                }
            }
            this.thumbnail.addThumbnailListener(this.thumbListener);
            this.thumbnail.setDimBackgroundColor({
                r: 0,
                g: 0,
                b: 0,
                a: 153
            });
            this.thumbnail.dim(false);
            this.thumbnail.visualizeInformationIcon(false, 'icon1');

            this.thumbnail.setProgressRange(0, 100);
            this.setWidget(this.thumbnail);
            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
            this.thumbnail.customSupportVoice = data.is_support_voice;
            this.setDownloadIcon(this.VM.get('isDownloaded'));
            this.bindListener();
        }
    },

    remove: function () {
        if (this.thumbnail) {
            this.thumbnail.removeThumbnailListener(this.thumbListener);
            this.unbindListener();

            if (this.thumbnail.timeId) {
                Volt.clearTimeout(this.thumbnail.timeId);
                this.thumbnail.timeId = null;
            }

            this.thumbnail = null;
            this.thumbListener = null;
        }
    },

    updateItemView: function (Thumbnail, data) {
        Volt.err('CategoriesAppInfoView updateItemView : ');
        this.VM = data.model;
        var data = this.VM.toJSON();
        if (Thumbnail) {
            this.thumbnail = Thumbnail;
            var icon = data.icon ? data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT) : '';
            var screenshot = data.screenshot ? data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT) : '';
            print('icon is ' + icon);
            print('screenshot is ' + screenshot);
            if (screenshot) {
                this.thumbnail.setContentImage(screenshot);
                this.useDefaultImage = false;
            } else {
                this.thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                this.useDefaultImage = true;
            }
            this.thumbnail.setInformationIcon("icon2", icon);
            this.thumbnail.setInformationText("text1", data.title ? data.title : '');
            this.thumbnail.setInformationText("text2", data.updated ? CommonFunctions.convertDate(data.updated.split('T')[0]) : '');
            this.thumbnail.setInformationText("text3", data.fileSize ? this.convertByte(data.fileSize) : '');
            this.thumbnail.visualizeInformationIcon(false, 'icon1');
            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
            this.thumbnail.customSupportVoice = data.is_support_voice;
            this.setDownloadIcon(this.VM.get('isDownloaded'));
        }
        this.resetProgressBar();
    },
    /**
     * convert bytes mark
     * @method
     * @param  {number} value app size
     * @return {string}       converted size
     */
    convertByte: function (value) {

        if (value >= 1048576) {
            return parseFloat(value / 1048576).toFixed(2) + " " + Volt.i18n.t('SID_MB');
        } else if (value >= 1024) {
            return parseInt(value / 1024) + " " + Volt.i18n.t('SID_KB');
        } else {
            return parseInt(value) + " " + Volt.i18n.t('SID_BYTE');
        }
    },
    /**
     * Render changed model.
     * @method
     * @param {model} changedModel Changed model.
     */
    renderChange: function (changedModel) {

        for (key in changedModel.changed) {
            if (key == 'isDownloaded') {
                if (changedModel.changed[key]) {
                    if (this.thumbnail) {
                        this.thumbnail.visualizeInformationIcon(true, 'icon1');
                    }

                } else {
                    if (this.thumbnail) {
                        this.thumbnail.visualizeInformationIcon(false, 'icon1');
                    }
                }
            } else if (key == 'fileSize') {
                this.thumbnail && this.thumbnail.setInformationText("text3", this.convertByte(changedModel.changed.fileSize));
            }
        }       
    },

    setDownloadIcon: function (bDownloaded) {
        if (bDownloaded) {
            if (this.thumbnail) {
                this.thumbnail.visualizeInformationIcon(true, 'icon1');
            }
        } else {
            if (this.thumbnail) {
                this.thumbnail.visualizeInformationIcon(false, 'icon1');
            }
        }
    },

    /**
     * install
     * @method
     */
    installApp: function () {
        Volt.log('[CategoriesListView] CategoriesAppInfoView :: Install App : ' + this.VM.get('id'));

        if (!this.progressView) {
            this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }
        this.progressView.installApp();
    },

    cancelInstallApp: function () {
        Volt.log('[CategoriesListView] CategoriesAppInfoView :: cancelInstall App : ' + this.VM.get('id'));

        if (!this.progressView) {
            this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }

        this.progressView.cancelInstallApp();
    },

    /**
     * show view
     * @method
     */
    showProgressBar: function () {
        if (!this.progressView) {
            this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }
        this.progressView.updateThumbnail(this.thumbnail);
        this.progressView.show();
    },

    /**
     * hide view
     * @method
     */
    hideProgressBar: function () {
        if (this.progressView) {
            this.progressView.hideProgressBar();
            this.progressView.updateThumbnail(null);
        }
    },

    resetProgressBar: function () {
        if (!this.progressView) {
            this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
        } else {
            this.progressView.resetProgressBar(this.thumbnail, this.VM);
        }
        this.progressView.show();
    }
});

exports = CategoriesListView;
