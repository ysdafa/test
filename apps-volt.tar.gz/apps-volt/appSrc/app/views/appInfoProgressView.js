/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview This module manages appInfoProgessView
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require("modules/VoltJSON.js");

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var Models = Volt.require('app/models/models.js');
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
/**
 * @name AppInfoProgessView
 */
var AppInfoProgessView = Volt.BaseView.extend({
    /** @lends AppInfoProgessView.prototype */
    template: null,
    thumbnail: null,
    dimTemplate: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: 0,
        height: 0,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 153
        }
    },
    arrIsListening: null,
    downloadEvent: [
        CommonDefines.Event.INSTALL_START,
        CommonDefines.Event.DOWNLOADING,
        CommonDefines.Event.DOWNLOAD_COMPLETED,
        CommonDefines.Event.INSTALLING,
        CommonDefines.Event.INSTALL_COMPLETED,
        CommonDefines.Event.INSTALL_CANCEL_COMPLETED,
        //CommonDefines.Event.INSTALL_CANCEL_FAILED
    ],
    errorEvent: [
        CommonDefines.Event.DOWNLOAD_FAIL_NOT_EXIST,
        CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE,
        CommonDefines.Event.DOWNLOAD_FAIL_LICENSE_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_SERVER_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_NETWORK_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_OTHERS,

        CommonDefines.Event.DOWNLOAD_FAIL_DECRYPY_CONFIG,
        CommonDefines.Event.DOWNLOAD_FAIL_ICON_URL_IS_EMPTY,
        CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_ICON,
        CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_APP,
        CommonDefines.Event.DOWNLOAD_FAIL_APP_NOT_EXIST,
        CommonDefines.Event.DOWNLAOD_LOAD_WIDGET_INFO,
        CommonDefines.Event.DOWNLOAD_FAIL_CONVERT_ID_FROM_RUNTITLE,
        CommonDefines.Event.DOWNLOAD_FAIL_INPUT_PARAMETER,
        CommonDefines.Event.DOWNLOAD_FAIL_MOVE_DIR,
        CommonDefines.Event.DOWNLOAD_FAIL_UNZIP_FILES,
        CommonDefines.Event.DOWNLOAD_FAIL_NO_LICENSE_FILE,
        CommonDefines.Event.DOWNLOAD_FAIL_NO_INSTALL_DIR,
        CommonDefines.Event.DOWNLOAD_FAIL_TEMP_DIR_NOT_EXIST,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_URL,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_EMP_INFO,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_NOT_ENOUGH_MEMORY,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_MOVE,
        CommonDefines.Event.DOWNLOAD_FAIL_EMP_DOWNLOAD,

        CommonDefines.Event.INSTALL_FAIL_EXIST,
        CommonDefines.Event.INSTALL_FAIL_PKGMGR_ERROR,
        CommonDefines.Event.INSTALL_FAIL_LICENSE_ERROR,
        CommonDefines.Event.INSTALL_FAIL_OTHERS,
        CommonDefines.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE
    ],

    /**
     * initialize
     * @name AppInfoProgessView
     * @constructs
     * @param  {object} template   template
     * @param  {Model} model VM correspond to this
     */
    initialize: function (iThumbnail, model) {
        this.id = model.get('id');
        this.usbInstall = model.get('usbInstall');
        this.fileSize = model.get('fileSize') ? model.get('fileSize') : 0;
        this.fileDecompSize = model.get('fileDecompSize') ? model.get('fileDecompSize') : this.fileSize;
        this.thumbnail = iThumbnail;
        this.arrIsListening = new Array();
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_USB_INSTALL_APP, this.usbInstallApp);
    },
    updateThumbnail: function (thumbnail) {
        this.thumbnail = thumbnail;
    },
    /**
     * install app
     * @method
     */
    installApp: function (path) {

        if (this.isDownloadableApp()) {
            this.listenTo(EventMediator, CommonDefines.Event.INSTALL_START, this.parseProgressEvent);
            this.listenToCancelEvent();

            AppInstallMgr.installApp(String(this.id), path ? path : '');

            if (AppInstallMgr.getAllInstallList().length > 1) {
                this.readyProgressBar();
            }
        } else {
            //// Fix: DF150126-00393, Use async call to resume previous pause first
            var appId = this.id;
            var fileSize = this.fileSize;
            var fileDecompSize = this.fileDecompSize;
            Volt.log('[appInfoProgressView.js]  fileSize is ' + fileSize);
            Volt.log('[appInfoProgressView.js]  fileDecompSize is ' + fileDecompSize);
            Volt.setTimeout(function () {
                //Models.externalStorageModel.checkConnectUSB(appId,fileSize,fileDecompSize);
                Models.externalStorageModel.checkConnectUSB(appId,fileSize, 0);
            }, 0);
        }
    },
    usbInstallApp: function (eventInfo) {
        Volt.log('[appInfoProgressView.js @usbInstallApp] id: ' + eventInfo.app_id + ' this.id: ' + this.id);
        if (eventInfo.app_id == String(this.id)) {
            this.listenTo(EventMediator, CommonDefines.Event.INSTALL_START, this.parseProgressEvent);
            this.listenToCancelEvent();
            if (AppInstallMgr.getAllInstallList().length > 0) {
                this.readyProgressBar();
            }
        }
    },

    showAppSyncError: function () {
        /*var setPopup = {
            text: Volt.i18n.t('TV_SID_PREPARING_THE_TV_PLEASE_TRY_AGAIN_LATER'),
            buttons: [
                {
                    name: Volt.i18n.t('COM_SID_OK')
                
                }
            ]
        }

        new MsgPopupView(setPopup);*/
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE);
    },

    cancelInstallApp: function () {

        this.listenToCancelEvent();
        AppInstallMgr.cancelInstallApp(String(this.id));
    },
    
    remove: function () {
        this.hideProgressBar();
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_USB_INSTALL_APP);
    },
    
    /**
     * show view
     * @method
     */
    show: function () {

        var obj = AppInstallMgr.getInstallList(String(this.id));

        if (obj) {
            switch (obj.status) {
            case CommonDefines.AppInstallMgr.STATUS_INSTALL_READY:
                this.parseProgressEvent({
                    app_id: obj.app_id,
                    eventType: null
                });
                break;
            case CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_PROGRESS:
                this.parseProgressEvent({
                    app_id: obj.app_id,
                    result: obj.value,
                    eventType: CommonDefines.Event.DOWNLOADING
                }, true);
                break;
            case CommonDefines.AppInstallMgr.STATUS_DOWNLOAD_RESULT:
                this.parseProgressEvent({
                    app_id: obj.app_id,
                    result: 0,
                    eventType: CommonDefines.Event.DOWNLOAD_COMPLETED
                });
                break;
            case CommonDefines.AppInstallMgr.STATUS_INSTALL_PROGRESS:
                this.parseProgressEvent({
                    app_id: obj.app_id,
                    result: obj.value,
                    eventType: CommonDefines.Event.INSTALLING
                }, true);
                break;
            }
        }
    },
    /**
     * hide view
     * @method
     */
    hide: function () {
        this.hideProgressBar();
    },
    /**
     * resume view
     * @method
     */
    resume: function () {},
    /**
     * pause view
     * @method
     */
    pause: function () {},
    /**
     * parse event
     * @param  {object} eventInfo event Info
     * @param  {boolean} fromShow  isfrom show()
     */
    parseProgressEvent: function (eventInfo, fromShow) {
        Volt.log('[appInfoProgressView.js @parseProgressEvent]');

        if (eventInfo && eventInfo.app_id && eventInfo.app_id == this.id) {

            if (eventInfo.eventType == null) {
                this.listenTo(EventMediator, CommonDefines.Event.INSTALL_START, this.parseProgressEvent);
                this.readyProgressBar();
            } else if (eventInfo.eventType == CommonDefines.Event.INSTALL_START) {

                if (eventInfo.value == 0) {
                    this.stopListening(EventMediator, CommonDefines.Event.INSTALL_START);
                    this.listenToDownloadEvent();
                    this.setProgressBar();
                } else {
                    this.hideProgressBar();
                }
            } else if (eventInfo.eventType == CommonDefines.Event.DOWNLOADING) {

                if (eventInfo.result != null && eventInfo.result >= 0 && eventInfo.result <= 100) {
                    if (fromShow == true) {
                        this.listenToDownloadEvent();
                    }
                    this.updateProgressBar(eventInfo.result);
                } else {
                    this.hideProgressBar();
                }
            } else if (eventInfo.eventType == CommonDefines.Event.DOWNLOAD_COMPLETED) {
                if (eventInfo.result == 0) {
                    this.stopListeningDownloadEvent();
                    this.listenToInstallEvent();
                    this.suspendProgressBar();
                } else {
                    this.hideProgressBar();
                }
            } else if (eventInfo.eventType == CommonDefines.Event.INSTALLING) {

                if (eventInfo.result != null && eventInfo.result >= 0 && eventInfo.result <= 100) {
                    if (fromShow == true) {
                        this.listenToInstallEvent();
                    }
                } else {
                    this.hideProgressBar();
                }
            } else {
                this.hideProgressBar();
            }
        }
    },

    parseErrorEvent: function (eventInfo) {
        this.eventInfo = eventInfo;
        Volt.setTimeout(_.bind(this.processInstallErrorEvent,this),2);
    },
     processInstallErrorEvent: function () {
        var eventInfo = this.eventInfo;
        this.hideProgressBar();
		
        if (eventInfo && eventInfo.app_id && eventInfo.app_id == this.id) {
			eventInfo.usbInstall = this.usbInstall;
            switch (eventInfo.eventType) {
            case CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE:
                if (this.usbInstall) {
                    //Models.externalStorageModel.checkConnectUSB(this.id,this.fileSize,this.fileDecompSize);
                    CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD, eventInfo);
                } else {
                    CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CANNT_DOWNLOADTOUSB);
                }
                
                break;
            case CommonDefines.Event.INSTALL_FAIL_APPSYNC_NOT_COMPLETE:
                this.showAppSyncError();
                break;
            default:
                if (CommonDefines.Event.INSTALL_FAIL_OTHERS == eventInfo.eventType) {
                    if (eventInfo.failCode) {
                        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD, eventInfo);
                        break;
                    }
                }
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD, eventInfo);
                break;
            }
        }
    },
    /**
     * stop Bind
     * @method
     */
    stopBind: function (eventList) {
        var self = this;
        if (eventList == null) {
            this.stopBind(this.downloadEvent);
            this.stopBind(this.errorEvent);
        } else {
            _.each(eventList, function (eventType, i) {
                self.stopListening(EventMediator, eventType);
            });
        }
    },

    listenToDownloadEvent: function () {
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADING, this.parseProgressEvent);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_COMPLETED, this.parseProgressEvent);
        this.listenToErrorEvent();
        this.listenToCancelEvent();
    },

    listenToInstallEvent: function () {
        this.listenTo(EventMediator, CommonDefines.Event.INSTALLING, this.parseProgressEvent);
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_COMPLETED, this.parseProgressEvent);
        this.listenToErrorEvent();
        this.listenToCancelEvent();
    },

    listenToErrorEvent: function () {
        var self = this;

        _.each(this.errorEvent, function (eventType, i) {
            self.listenTo(EventMediator, eventType, self.parseErrorEvent);
        });
    },

    listenToCancelEvent: function () {
        this.listenTo(EventMediator, CommonDefines.Event.INSTALL_CANCEL_COMPLETED, this.parseProgressEvent);
    },

    stopListeningDownloadEvent: function () {
        this.stopListening(EventMediator, CommonDefines.Event.DOWNLOADING);
        this.stopListening(EventMediator, CommonDefines.Event.DOWNLOAD_COMPLETED);
    },

    stopListeningInstallEvent: function () {
        this.stopListening(EventMediator, CommonDefines.Event.INSTALLING);
        this.stopListening(EventMediator, CommonDefines.Event.INSTALL_COMPLETED);
    },

    /**
     * ready Progressbar
     * @method
     */
    readyProgressBar: function () {
        Volt.log('[appInfoProgessView] readyProgressBar');
        this.listenTo(EventMediator, CommonDefines.Event.WAS_CRASH_HIDE_PROGRESSBAR, this.hideProgressBar);
        if (this.thumbnail) {
            this.thumbnail.dim(true);
            this.thumbnail.raiseElement('progressBar');
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
        }
    },

    /**
     * set Progressbar
     * @method
     */
    setProgressBar: function () {
        Volt.log('[appInfoProgessView] setProgressBar ' + this.id);

        if (this.thumbnail) {
            this.thumbnail.dim(true);
            this.thumbnail.raiseElement('progressBar');
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
        }
    },
    /**
     * update progressbar
     * @method
     * @param  {number} progress progress_data
     */
    updateProgressBar: function (progress) {

        Volt.log('[appInfoProgessView] updateProgressBar ' + this.id + ' ' + progress);
        if (this.thumbnail) {
            this.thumbnail.dim(true);
            this.thumbnail.raiseElement('progressBar');
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(Number(progress));
        }
    },

    /**
     * suspendProgressBar
     * @method
     */
    suspendProgressBar: function () {

        Volt.log('[appInfoProgessView] suspendProgressBar ' + this.id);
        if (this.thumbnail) {
            this.thumbnail.dim(true);
            this.thumbnail.raiseElement('progressBar');
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(100);
        }
    },
    /**
     * hide progressbar
     * @method
     */
    hideProgressBar: function () {

        Volt.log('[appInfoProgessView] hideProgressBar ' + this.id);
        this.stopListening(EventMediator,  CommonDefines.Event.WAS_CRASH_HIDE_PROGRESSBAR);
        this.stopBind();
        if (this.thumbnail) {
            this.thumbnail.dim(false);
            this.thumbnail.setProgressValue(0);
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
        }
    },

    resetProgressBar: function (iThumbnail, model) {
        this.hideProgressBar();

        this.id = model.get('id');
        this.usbInstall = model.get('usbInstall');
        this.fileSize = model.get('fileSize') ? model.get('fileSize') : 0;
        this.fileDecompSize = model.get('fileDecompSize') ? model.get('fileDecompSize') : this.fileSize;

        this.thumbnail = iThumbnail;
        this.arrIsListening = new Array();
        //this.listenTo(EventMediator, CommonDefines.Event.EVENT_USB_INSTALL_APP, this.usbInstallApp);
    },

    listenTo: function (to, eventType, callback) {
        // Volt.log('[appInfoProgessView] listenTo ');

        if (this.arrIsListening[eventType] == true)
            return;

        this.arrIsListening[eventType] = true;
        Backbone.View.prototype.listenTo.apply(this, arguments);
    },

    stopListening: function (to, eventType) {
        // Volt.log('[appInfoProgessView] stopListening ');

        this.arrIsListening[eventType] = false;
        Backbone.View.prototype.stopListening.apply(this, arguments);
    },


    isDownloadableApp: function () {
        Volt.log("[appInfoProgessView] isDownloadableApp ");
        if (Volt.__SIM_STORAGE_FULL__) {
            return false;
        }

        // @xiaojun.wang|20150310: Fix DF150309-02778: when installing in internal, we don't need to check fileDecompSize.
        
        var remainedLocalMemory = 0;
        var arrTemp = Volt.DeviceInfoModel.get('localMemory').split('/');
        for (var i = 0; i < arrTemp.length; i++) {
            arrTemp[i] = CommonFunctions.getSize(arrTemp[i], 'B');
        }
        remainedLocalMemory = arrTemp[1] - arrTemp[0];

        Volt.log('[detailVM.js @isDownloadableApp] fileSize: ' + this.fileSize + ' remainedLocalMemory: ' + remainedLocalMemory);
        return (this.fileSize <= remainedLocalMemory);
    },
});

exports = AppInfoProgessView;