// Modules
var Require = Volt.require,
    Backbone = Require('lib/volt-backbone.js'),

    // Require Common Modules
    _ = Volt.require("modules/underscore.js")._;

var WinsetScroll = Volt.require("modules/WinsetUIElement/winsetScroll.js");

var SingleLinelistView = Backbone.View.extend({
    singlelineParam: null,
    dataPointers: [],
    initialize: function (singlelineParam) {
        this.singlelineParam = singlelineParam;
    },

    render: function () {
        this.initList = _.bind(__initList, this);
        var singleLinelist = this.initList(this.singlelineParam);
        Volt.log("[singleLinelist-list-view.js] singleLinelist is  " + singleLinelist);
        this.setWidget(singleLinelist);
        return this;
    },

});

var getRenderer = function (singleList, parentWidth, parentHeight, data) {
    Volt.log("[singleLinelist-list-view.js] getRenderer parentWidth =" + parentWidth + " parentHeight = " + parentHeight);
    var renderer = new Renderer(parentWidth, parentHeight);
    renderer.root = new WidgetEx({
        x: 0,
        y: 0,
        width: parentWidth,
        height: parentHeight,
        parent: scene,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        }
    });
    renderer.root.show();
    singleList.initRenderer(renderer, data, parentWidth, parentHeight);

    renderer.onDraw = function (rendererInstance, drawTypeString, data, parentWidth, parentHeight) {
        if (!data) {
            Volt.log('[singleLinelist-list-view.js] nodata^^^^^^^^^^^^^^^^^^^^^^^^^^^^')
            //return;
        }
        if ("LoadData" == drawTypeString) {
            Volt.log("[singleLinelist-list-view.js] LoadData");
            singleList.onDrawLoadData(rendererInstance, data, parentWidth, parentHeight);
        } else if ("UpdateData" == drawTypeString) {
            Volt.log("[singleLinelist-list-view.js] UpdateData");
            singleList.onDrawUpdateData(rendererInstance.root, data, parentWidth, parentHeight);
        } else if ("FromItemFocusChangeAniStart" == drawTypeString) {
            //            print("[singleLinelist-list-view.js] FromItemFocusChangeAniStart");
            singleList.onDrawFromFocusChangeStart(rendererInstance.root, data, parentWidth, parentHeight);
        } else if ("ToItemFocusChangeAniEnd" == drawTypeString) {
            Volt.log("[singleLinelist-list-view.js] ToItemFocusChangeAniEnd");
            singleList.onDrawToFocusChangeEnd(rendererInstance.root, data, parentWidth, parentHeight);
        } else if ("onFocusChanged" == drawTypeString) {
            Volt.log("[singleLinelist-list-view.js] onFocusChanged");
            singleList.onFocusChanged(singleLineList, fromItemIndex, toItemIndex);
        } else if ("onFocusChangeStart" == drawTypeString) {
            Volt.log("[singleLinelist-list-view.js] onFocusChangeStart");
            singleList.onFocusChangeStart(singleLineList, fromItemIndex, toItemIndex);
        }
    };

    renderer.onResize = function (rendererInstance, data, destWidth, destHeight, flagWithAni, duration) {
        if ("withAni" == flagWithAni) {} else if ("noAni" == flagWithAni) {}

    };

    renderer.onUpdate = function (width, height) {

    };

    renderer.onRelease = function () {
        Volt.log("[singleLinelist-list-view.js] onRelease" + renderer.root.getChildCount());

        renderer.root.destroy();
        delete renderer;
    };

    return renderer;
};


var itemClicked = function (singleLineList, itemIndex) {
    Volt.log("[singleLinelist-list-view.js] itemClicked index = " + itemIndex);
    //response the callback onItemMouseClick to mouse click on listitem
    singleLineList.onItemMouseClick(itemIndex);
};

var FocusChanged = function (singleLineList, fromItemIndex, toItemIndex) {
    Volt.log("[singleLinelist-list-view.js] FocusChanged fromItemIndex = " + fromItemIndex + "toItemIndex:" + toItemIndex);
    singleLineList.onFocusChanged(singleLineList, fromItemIndex, toItemIndex);
};
var FocusChangeStart = function (singleLineList, fromItemIndex, toItemIndex) {
    Volt.log("[singleLinelist-list-view.js] FocusChangeStart fromItemIndex = " + fromItemIndex + "toItemIndex:" + toItemIndex);
    singleLineList.onFocusChangeStart(singleLineList, fromItemIndex, toItemIndex);
};
var ItemLoaded = function (singleLineList, itemIndex) {
    singleLineList.onItemLoaded(singleLineList, itemIndex);
};
var MoveOut = function (singleLineList, directionString, fromItemIndex) {
    Volt.log("[singleLinelist-list-view.js] MoveOut fromItemIndex = " + fromItemIndex + "directionString:" + directionString);
    //singleLineList.onMoveOut(singleLineList, directionString, fromItemIndex);
    if ("Up" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_UP);
    }
    else if ("Down" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_DOWN);
    }
    else if ("Left" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_LEFT);
    }
    else if ("Right" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_RIGHT);
    }
};
var __initList = function (param) {
    //create gridlist refer to param
    var singleList = new SingleLineListControl(param);

    /* *******************set render and listener of gridlistcontrol begin**************************/
    //api from native element
    var rendererProvider = new RendererProvider;


    rendererProvider.funcGetRenderer = function (parentWidth, parentHeight, data) {
        return getRenderer(singleList, parentWidth, parentHeight, data);
    };

    singleList.setRendererProvider(rendererProvider);
    /* *******************set render and listener of gridlistcontrol end**************************/

    var singleLineListener = new SingleLineListControlListener;
    singleLineListener.onFocusChanged = FocusChanged;
    singleLineListener.onFocusChangeStart = FocusChangeStart;
    singleLineListener.onItemClicked = itemClicked;
    singleLineListener.onMoveOut = MoveOut;
    singleLineListener.onItemLoaded = ItemLoaded;
    singleList.addListListener(singleLineListener);
    singleList.Listener = singleLineListener;

    /* ******************set call back api from common-module begin******************/
    //callback to draw list item
    singleList.onDrawLoadData = function (render, data, parentWidth, parentHeight) {};
    //callback to response "enter" key press
    singleList.onItemPress = function (index) {};
    //singleList.onItemRelease = function (index) {};
    singleList.onKeyReleased = function (index) {};

    //callback to response update list item
    singleList.onDrawUpdateData = function (widget, data, parentWidth, parentHeight) {};
    //callback to response focus change start( from item)
    singleList.onDrawFromFocusChangeStart = function (widget, data, parentWidth, parentHeight) {};
    //callback to response focus change start( to item)
    singleList.onDrawToFocusChangeEnd = function (widget, data, parentWidth, parentHeight) {};
    //callback to response mouse click
    singleList.onItemMouseClick = function (index) {};
    singleList.onFocusChanged = function (singleLineList, fromItemIndex, toItemIndex) {};
    singleList.onFocusChangeStart = function (singleLineList, fromItemIndex, toItemIndex) {};
    singleList.initRenderer = function (renderer, data, parentWidth, parentHeight) {};

    var keyboardListener = new KeyboardListener;

    keyboardListener.onKeyReleased = function (actor, keyCode) {
        if (keyCode == Volt.KEY_JOYSTICK_OK) {
            Volt.err('[singlelineListView.js] keyboardListener.onKeyReleased');
            var index = singleList.focusItemIndex;
             if (index == undefined) {
                    index = 0;
             }
            singleList.onKeyReleased(index);
        }
    }.bind(this);
    singleList.addKeyboardListener(keyboardListener);
    this.keyboardListener = keyboardListener;

    /* ******************set call back api from common-module  end ******************/


    /* ******************set onkeyevent process begin******************/
    this.onKeyEvent = function (keycode, keytype) {
        var ret = false;


        if ( keytype == Volt.EVENT_KEY_RELEASE ){
           return;

        }

/*
        if (keycode == Volt.KEY_JOYSTICK_OK) {
            var index = singleList.focusItemIndex;
            print('[singleLinelist-list-view.js] focusItemIndex = ' + singleList.focusItemIndex);
            if (index == undefined) {
                index = 0;
            }
            singleList.onItemRelease(index);
            ret = true;
        }

        */


        Volt.log("[singleLinelist-list-view.js] onKeyEvent keycode = " + keycode);
        switch (keycode) {
        case Volt.KEY_JOYSTICK_UP:
            singleList.moveFocus("Up");
            return true;
        case Volt.KEY_JOYSTICK_DOWN:
            singleList.moveFocus("Down");
            return true;
        case Volt.KEY_JOYSTICK_OK:
            {
                //response the callback onItemPress to key press on listitem
                var index = singleList.focusItemIndex;
                Volt.log('[singleLinelist-list-view.js] focusItemIndex = ' + singleList.focusItemIndex);
                if (index == undefined) {
                    index = 0;
                }
                singleList.onItemPress(index);
                ret = true;
            }
            break;
        case Volt.KEY_JOYSTICK_LEFT:
            singleList.moveFocus("Left");
            return true;
            //return true;
        case Volt.KEY_JOYSTICK_RIGHT:
            singleList.moveFocus("Right");
            return true;
        default:
            // to do
            break;
        }
        return ret;
    };

    singleList.onKeyEvent = this.onKeyEvent.bind(this);
    /* ******************set onkeyevent process end******************/

    singleList.setScrollBar = function (options) {
        Volt.err('[singleLinelist-list-view.js] getScroll');

        var scroll = new WinsetScroll({
            style: 3,
            parent: scene,
            x: options.width - Math.floor(Volt.width * 0.006250),
            y: 0,
            minValue: 0,
            maxValue: 100,
            value: 0,
            width: options.width*0.003640+1,
            height: options.height ,
        });

        singleList.attachScrollBar(scroll);
    };

    //    singleList.updateScrollBar = function(max, min, value){
    //        this.scroll.setMaxValue(max);
    //        this.scroll.setMinValue(min);
    //        this.scroll.setValue(value);
    //        
    //        var perHeight = this.scroll.height/max;
    //        this.scroll.setPointingNormalThumbSize(5, perHeight);
    //        this.scroll.setPointingOverThumbSize(21, perHeight);
    //        this.scroll.setPointingFocusThumbSize(29, perHeight + this.scroll.height * 0.008333);
    //    };

    singleList.show();

    Volt.log("[singleLinelist-list-view.js] init singlelinelist ");
    return singleList;
};

exports = SingleLinelistView;