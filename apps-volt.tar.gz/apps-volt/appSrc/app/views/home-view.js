/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages home view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Public libraries
var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require("modules/VoltJSON.js");
var _ = Volt.require("modules/underscore.js")._;

// Common components
var MainTemplate = Volt.requireCommonTemplate('main');

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js'),
    HomeTemplate = Volt.require('app/templates/1080/home-template.js');

var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var  voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var  AppInstallMgr = Volt.require('app/common/appInstallMgr.js');

var loadingPopup = Volt.require("lib/views/loading-popup.js");

var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");
var tvResolution = (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080;

var MENU_ANIM_DURATION = 200;

var WinsetToolTip = Volt.require('modules/WinsetUIElement/winsetToolTip.js');
Volt.mapWidget('WinsetToolTip', WinsetToolTip);
var WinsetLoading = Volt.require('modules/WinsetUIElement/winsetLoading.js');
Volt.mapWidget('WinsetLoading', WinsetLoading);

var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");

var OverlayView = Volt.require('app/views/overlay-view.js');

var MagicKey = Volt.require('app/common/MagicKey.js');
var Model;

/**
 * @name HomeView
 */
var HomeView = Volt.BaseView.extend({
    /** @lends HomeView.prototype */
    template: MainTemplate.container, // Template of Main View is a container framework
    bLastFocus: false,
    bLaunching: false,
    bMyAppsEditMode: false,
    bMyAppsLongpressEditMode: false,
    bFirstShow: true,
    bMouseVisibility: false, // If mouse is visible
    /**
     * Initialize HomeView
     * @name HomeView
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, 'SHOW_EDIT_MODE', this.onMyAppsEditMode);
        this.listenTo(EventMediator, 'HIDE_EDIT_MODE', this.offMyAppsEditMode);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_LONGPRESS_MOVE_MYAPPS, this.updateMyAppsEditMode);
        MagicKey.addListener(CommonDefines.Magic.SHOW_VERSION, function () {
            CommonWidgetPopup.showMessage(CommonDefines.Magic.SHOW_VERSION);
        });
    },

    /**
     * Render once after view is created
     * @method
     */
    render: function () {
        Volt.log('[HomeView] render()');
        // Parse the template
        this.setWidget(Volt.loadTemplate(this.template));

        // Render everything
        this.renderHeader();
        
        this.widget._navOnKeyEvent = function (keycode, type) {
           if (keycode == Volt.KEY_RETURN && type == Volt.EVENT_KEY_PRESS && Backbone.history.getFragment() == 'myapps') {
                if(this.bMyAppsEditMode){
                    EventMediator.trigger('HIDE_EDIT_MODE');
                    EventMediator.trigger('UPDATE_MYAPPS_VIEW');
                    return true;
                }
                if(this.bMyAppsLongpressEditMode){
                    EventMediator.trigger('UPDATE_MYAPPS_VIEW');
                    this.bMyAppsLongpressEditMode = false;
                    return true;
                }    
            }
            return false;

        }.bind(this);
    },

    /**
     * Show this view.
     * @method
     * @param  {object} param Parameters
     * @param  {enum} animationType Animation type to showing this view.
     * @return {deferred} Deferred promise return.
     */
    show: function (options, animationType) {
        Volt.log('[home-view.js]@show');
        var deferred = Q.defer();
        deferred.resolve();

        //// If view is not changed and not the first time to show, just ignore.
        if (options && options.change === false && !this.bFirstShow) {
            return deferred.promise;
        }

        this.widget.show();
        Stage.show(); // show apps panel, request from Volt UIFW

        //// if not to a sub view, show loading
        if (Volt.bQuickView) {
            EventMediator.trigger('EVENT_OVERLAY_SHOW_DIM');
            return deferred.promise;
        }

        if (this.bFirstShow) {
            this.renderCategory();
            this.bFirstShow = false;
        }

        this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.deactivate);
        this.listenTo(EventMediator, 'HOMEVIEW_LAUNCH_APP', this.startLaunch);
        this.listenTo(EventMediator, 'COMMON_POPUP_KEY_RETURN_RELEASE', this.cancelLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS, this.onNetworkStatus);
        this.listenTo(EventMediator, CommonDefines.Event.DISCONNECT_USB, this.showUsbPopup);
        //// TODO: temporarily Comment this
        this.onChangeCursor(null, true);

        //call Volt.Nav.setRoot, for reset the root when coming back to this view.
        Volt.Nav.setRoot(this.widget, {
            focus: null
        });
        var developMode = voltapi.vconf.getValue(CommonDefines.Vconf.DB_DEVELOP_MODE);
        Volt.log('[home-view.js] developMode is ' + developMode);
        if (developMode) {
            if ('0' == developMode) {
                this.widget.getDescendant('main-header-develop-title').text = '';
            } else if ('1' == developMode) {
                this.widget.getDescendant('main-header-develop-title').text = 'Developer Mode';
            }
        } else {
            this.widget.getDescendant('main-header-develop-title').text = '';
        }
        this.addListeners();

        return deferred.promise;
    },
    showUsbPopup: function () {
        //// @xiaojun.wang: DF150207-00669
        Volt.log('[HomeView]  Backbone.history.getCount is ' + Backbone.history.getCount());
        if (1 != Backbone.history.getCount()) {
            Volt.log('[HomeView] do not need show usb popup');
            return;
        }
        // If we are in deactivate state, do not show popup
        if (CommonFunctions.getAppState() != CommonDefines.AppState.APP_STATE_DEACTIVATE) {
            Volt.log('[HomeView] hide delete popup');
            EventMediator.trigger(CommonDefines.Event.EVENT_HIDE_DELETE_POPUP); //when usb disconnect,hide delete popup  
            Volt.log('[HomeView] show usb popup');
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_USB_NOT_CONNECT);
        }
    },
    /**
     * hide this view.
     * @method
     * @param  {enum} animationType Animation type to hiding this view.
     * @return {deferred} Deferred promise return.
     */
    hide: function (options, animationType) {
        var deferred = Q.defer();
        deferred.resolve();

        //// If it is switching sub views, just ignore.
        if (options && options.change === false) {
            return deferred.promise;
        }
        this.widget.hide();
        this.stopListening(EventMediator, 'VOLT_DEACTIVATE');
        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS);
        this.stopListening(EventMediator, 'HOMEVIEW_LAUNCH_APP');
        this.stopListening(EventMediator, 'COMMON_POPUP_KEY_RETURN_RELEASE');
        this.stopListening(EventMediator, CommonDefines.Event.DISCONNECT_USB);
        this.removeListeners();

        return deferred.promise;
    },

    /**
     * Pause this view.
     * @method
     */
    pause: function () {
        Volt.log('[HomeView] pause');

        if (this.loading) {
            this.hideLoading();
        }
        Volt.Nav.pause();
    },

    /**
     * Resume this view.
     * @method
     */
    resume: function (params, showType, beforeType) {
        Volt.log('[HomeView] resume');

        this.widget.show();

        Volt.Nav.setRoot(this.widget);
        if ('#popup/updateAppsList' == Backbone.history.hashstack[Backbone.history.hashstack.length - 2]) {
            Volt.Nav.focus(this.widget.getDescendant('main-header-icon-option'));
        }
        if (4 != beforeType) { //if  beforeType is popup
            Volt.Nav.resume();
        }
        this.headerview.bPopupshowing = false;
    },

    addListeners: function () {
        Volt.log('[home-view.js] @addListeners');
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
    },

    removeListeners: function () {
        Volt.log('[home-view.js] @removeListeners');
        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
    },

    /**
     * Render header view
     * @method
     */
    renderHeader: function () {
        Volt.log('[HomeView] renderHeaderIcon');
        var container = this.widget.getDescendant('main-header-container');
        this.headerview = new HeaderView();
        container.addChild(this.headerview.render(this).widget);
    },

    /**
     * Render menu list view
     * @method
     */
    renderCategory: function () {
        Volt.log('[HomeView] renderCategory()');

        if (!this.category) {
            var CategoryView = Volt.require('app/views/menuListView.js');

            this.category = new CategoryView({
                parent: this
            }).render();
        }
    },

    /**
     * Render content view
     * @method
     */
    renderContent: function () {
        Volt.log('[HomeView] renderContent');
    },
    
    startLaunch: function () {
        Volt.log('[HomeView] startLaunch');

        this.bLaunching = true;

        this.bindLaunchEvents();
    },

    cancelLaunch: function () {
        Volt.log('[HomeView] cancelLaunch');

        if (this.bLaunching) {
            var sLaunchedAppId = AppInstallMgr.getLaunchedAppID();
            AppInstallMgr.terminateApp(sLaunchedAppId);
            this.bLaunching = false;
        }

    },

    failLaunch: function () {
        Volt.log('[HomeView] failLaunch');
        this.bLaunching = false;
        this.unbindLaunchEvents();

    },

    bindLaunchEvents: function () {
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE, this.failLaunch);

        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_LAUNCH, this.onLaunched);
    },

    unbindLaunchEvents: function () {
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE);

        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_LAUNCH);
    },

    onLaunched: function () {
        Volt.log('[HomeView] onLaunched');

        this.bLaunching = false;

        this.unbindLaunchEvents();
    },
    onNetworkStatus: function () {
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            //var networkPopup = new MsgPopupView({type: CommonDefines.Popup.TYPE_NETWORK});
            //CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);//when network disconnect,do not show popup
        }
    },

    deactivate: function () {
        Volt.log('[HomeView] deactivate');

    },

    onMyAppsEditMode: function () {
        this.bMyAppsEditMode = true;
    },

    offMyAppsEditMode: function () {
        this.bMyAppsEditMode = false;
    },
    updateMyAppsEditMode: function (flag) {
        this.bMyAppsLongpressEditMode = flag;

    },

    onChangeCursor: function (visible, force) {
        if (force === true) { // Force to update
            // Synchronize state of mouse
            visible = Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE);
        } else if (this.bMouseVisibility == visible) {
            return;
        }

        Volt.log('[home-view.js @onChangeCursor] visible: ' + visible);
        this.bMouseVisibility = visible;
        this.headerview && this.headerview.onChangeCursor(visible);
    },
});

/**
 * @namespace HomeView
 * @name HeaderView
 */
var HeaderView = Volt.BaseView.extend({
    /** @lends HeaderView.prototype */
    template: HomeTemplate.header,
    parent: null,
    bPopupshowing: false,
    timeId: null,
    offsetFlag: true,
    toolTipWidget: null,
    btnListener: null,
    expandAnimation: null,
    shrinkAnimation: null,
    /**
     * Events delegation
     * @type {object}
     */
    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    /**
     * Initialize HeaderView
     * @name HeaderView
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS, this.shrink);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR, this.expand);
        this.listenTo(EventMediator, 'OPTIONMENU_POPUP_HIDE', this.changePoupStatus);

        this.btnListener = new ButtonListener();
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);
    },

    /**
     * Render this view
     * @method
     */
    render: function (parentWidget) {
        Volt.log('[HeaderView] render()');

        var highContrast = DeviceInfoModel.get('highContrast');

        var flag = highContrast || '0';
        this.setWidget(Volt.loadTemplate(this.template, {
            highconstract: flag
        }));

        this.parent = parentWidget;

        var iconSearchBtnBG = this.widget.getDescendant('main-header-icon-search');
        this.iconSearchBtn = Volt.loadTemplate(HomeTemplate.iconBtn, {
            WinsetID: "SearchBtnId"
        }, iconSearchBtnBG);
        this.initButton(this.iconSearchBtn, Volt.getRemoteUrl('images/1080/common/comn_icon_tm_search.png'));

        var iconOptionBtnBG = this.widget.getDescendant('main-header-icon-option');
        this.iconOptionBtn = Volt.loadTemplate(HomeTemplate.iconBtn, {
            WinsetID: "OptionBtnId"
        }, iconOptionBtnBG);
        this.initButton(this.iconOptionBtn, Volt.getRemoteUrl('images/1080/common/comn_icon_tm_setting.png'));

        var iconCloseBtnBG = this.widget.getDescendant('main-header-icon-close');
        this.iconCloseBtn = Volt.loadTemplate(HomeTemplate.iconBtn, {
            WinsetID: "CloseBtnId"
        }, iconCloseBtnBG);
        this.initButton(this.iconCloseBtn, Volt.getRemoteUrl('images/1080/common/comn_icon_tm_close.png'));

        var iconContainer = this.widget.getChild('header-container');
        this.wzCloseButton = iconContainer.getChild('main-header-icon-close');
        this.onChangeCursor(Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE));

        Volt.Nav.setNextItemRule(iconContainer.getChild('main-header-icon-search'), 'down', 'category-list-container');
        Volt.Nav.setNextItemRule(iconContainer.getChild('main-header-icon-search'), 'left', 'main-header-icon-search');

        return this;
    },
    initButton: function (iconButton, iconImage) {
        Volt.log('[HeaderView] initButton()');
        iconButton.setBackgroundColor({
            state: "all",
            color: Volt.hexToRgb('#0f1826', 0)
        });

        iconButton.setBackgroundImage({
            state: "focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        iconButton.setBackgroundImage({
            state: "normal",
            src: '',
        });

        iconButton.setBackgroundImage({
            state: "disabled",
            src: '',
        });
        iconButton.setBackgroundImage({
            state: "disabled-focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        iconButton.setBackgroundImage({
            state: "selected",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });


        iconButton.setIconImage({
            state: "all",
            src: iconImage
        });

        iconButton.setIconAlpha({
            state: "normal",
            alpha: 255 * 0.6
        });
        iconButton.setIconAlpha({
            state: "disabled",
            alpha: 255 * 0.2
        });
        iconButton.setIconAlpha({
            state: "focused-roll-over",
            alpha: 255
        });
        iconButton.setIconAlpha({
            state: "roll-over",
            alpha: 255
        });


        if (iconButton.setIconScaleFactor) {
            iconButton.setIconScaleFactor({
                state: "focused-roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });


            iconButton.setIconScaleFactor({
                state: "roll-over",
                scaleX: 1.1,
                scaleY: 1.1,
            });
        }

        iconButton.setIconAttr({
            x: Volt.dimmensionWidth * 0.017187 + ((Volt.APPS720P) ? 3 : 4),
            y: Volt.height * 0.050926 + ((Volt.APPS720P) ? 3 : 4),
            width: Volt.dimmensionWidth * 0.01875,
            height: Volt.height * 0.033333
        });

        iconButton.addListener(this.btnListener);

        this.mouseListener = new MouseListener;
        this.mouseListener.onMousePointerIn = function (widget, event) {
            Volt.log('[HeaderView @onMousePointerIn] widget: ' + widget.parent.id);
            this.showToolTip(widget.parent);
        }.bind(this);
        this.mouseListener.onMousePointerOut = function (widget, event) {
            Volt.log('[HeaderView @onMousePointerOut] widget: ' + widget.parent.id);
            this.hideToolTip(widget.parent);
        }.bind(this);

        iconButton.addMouseListener(this.mouseListener);
    },
    /**
     * Call when this view focused
     * @method
     * @param  {widget} widget Focused widget
     */
    onFocus: function (widget) {
        Volt.log('[HeaderView] onFocus() ' + widget.id);

        var iconContainer = this.widget.getChild('header-container');
        if (widget) {
            switch (widget.id) {
            case 'main-header-icon-search':
                Volt.log('[HeaderView] iconSearchBtn.setFocus()');
                this.iconSearchBtn.setFocus();
                CommonFunctions.voiceGuide(Volt.i18n.t('COM_FBID_SEARCH') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                this.showToolTip(widget);
                break;
            case 'main-header-icon-option':
                Volt.log('[HeaderView] iconOptionBtn.setFocus()');
                this.iconOptionBtn.setFocus();
                CommonFunctions.voiceGuide(Volt.i18n.t('COM_SID_OPTIONS') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                this.showToolTip(widget);

                break;
            case 'main-header-icon-close':
                Volt.log('[HeaderView] iconCloseBtn.setFocus()');
                if (true == this.offsetFlag) {
                    var iconContainer = this.widget.getChild('header-container');
                    Volt.Nav.focus(iconContainer.getChild('main-header-icon-option'));
                    this.showToolTip(iconContainer.getChild('main-header-icon-option'));
                } else {
                    this.iconCloseBtn.setFocus();
                    this.showToolTip(widget);
                }
                break;
            }
        }
    },
    /**
     * Call when this view blurred
     * @method
     * @param  {Widget} widget Blurred widget
     */
    onBlur: function (widget) {
        Volt.log('[HeaderView] onBlur() id: #' + widget.id);

        if (widget) {
            switch (widget.id) {
            case 'main-header-icon-search':
                this.hideToolTip();
                break;
            case 'main-header-icon-option':
                this.hideToolTip();
                break;
            case 'main-header-icon-close':
                this.hideToolTip();
                break;
            }
        }
    },
    onSelect: function (widget) {
        if (widget) {
            Volt.log("widget.id: " + widget.id);

            switch (widget.id) {
            case "SearchBtnId":
                this.onSelectSearch();
                break;
            case "OptionBtnId":
                var absolutePosition = widget.getAbsolutePosition();
                this.onSelectWinsetOption(absolutePosition);
                break;
            case "CloseBtnId":
                this.onSelectClose();
                break;
            }
        }
    },
    onSelectWinsetOption: function (absolutePosition) {
        Volt.log('[HeaderView] onSelectWinsetOption()');
        this.bLastFocus = true;
        Volt.KpiMapper.addEventLog('SELECTOPTION', {
            d: {
                cp: ''
            }
        });
        if (!this.bPopupshowing) {

            var localStorage = Volt.require("lib/volt-local-storage.js");
            this.listenTo(EventMediator, CommonDefines.Event.OPTION_MENU, this.processOptionMenuEvent, this);
            var optionMenuTemplate = HomeTemplate.optionMenu;
            if(Volt.moveSupport){
                optionMenuTemplate = HomeTemplate.optionMenuMove;
            }
            optionMenuTemplate.subSelectIndex = localStorage.getItem('sortOption') ? localStorage.getItem('sortOption') : 0;
            optionMenuTemplate.x = absolutePosition.x + HomeTemplate.optionWidth - (Volt.dimmensionWidth * 0.010417 + optionMenuTemplate.itemWidth ) ;

            if (!(optionMenuTemplate.subSelectIndex >= 0 && optionMenuTemplate.subSelectIndex <= 3)) {
                optionMenuTemplate.subSelectIndex = 0;
            }
            Volt.log('[HeaderView] onSelectWinsetOption:sortPostion is ' + optionMenuTemplate.subSelectIndex);
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_OPTIONMENU, optionMenuTemplate);
            this.bPopupshowing = true;
        } else {
            Volt.log('[HeaderView] this.bPopupshowing is true');
        }

    },

    processOptionMenuEvent: function (data) {
        Volt.log('[home-view.js] processOptionMenuEvent:data.parentIndex is ' + data.parentIndex + " data.subIndex is " + data.subIndex);

        var localStorage = Volt.require("lib/volt-local-storage.js");
        var Models = Volt.require('app/models/models.js');

        nSelectedSortOption = localStorage.getItem('sortOption'),
        this.stopListening(EventMediator, CommonDefines.Event.OPTION_MENU);
        sSortStandards = ['By Date', 'Most Used', 'TITLE A-Z', 'TITLE Z-A'];
        this.bPopupshowing = false;
        switch (data.parentIndex) {
        case CommonDefines.OptionMenu.DELETE_MY_APPS: // Delete
            Volt.KpiMapper.addEventLog('SELECTDELETE');
             if (data.dimflag == true) {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_NO_APP_DELETE);
            }else{
                 EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
                Volt.setTimeout(function () {
                    EventMediator.trigger('SHOW_EDIT_MODE', 'delete');
                }, 0);
            }
            break;
	case CommonDefines.OptionMenu.MOVE_MY_APPS: // Move My Apps
            //Volt.KpiMapper.addEventLog('SELECTLOCKUNLOCK');
              EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
              Volt.setTimeout(function () {
                  EventMediator.trigger('SHOW_EDIT_MODE', 'move');
              }, 0);
            break;
        case CommonDefines.OptionMenu.LOCK_MY_APPS: // Lock / Unlock
            Volt.KpiMapper.addEventLog('SELECTLOCKUNLOCK');
            var param = {
                callback: function () {
                    EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
                    Volt.setTimeout(function () {
                        EventMediator.trigger('SHOW_EDIT_MODE', 'lock');
                    }, 0);
                }
            };
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_PIN, param);
            break;
        case CommonDefines.OptionMenu.SORT_BY: // Sort
            Volt.KpiMapper.addEventLog('SELECTSORT');
            if (Volt.DeviceInfoModel.get('networksStatus') == "OK") {
                subOptionMenu = parseInt(data.subIndex, 10);
                Volt.log('[home-view.js] subOptionMenu is ' + subOptionMenu);
                Volt.log('[home-view.js] nSelectedSortOption is ' + nSelectedSortOption);
                if (nSelectedSortOption != subOptionMenu) {
                    // 0 : 'By Date', 1: 'Most Used', 2: 'Title A-Z', 3 : 'Title Z-A'
                    Volt.KpiMapper.addEventLog('CHANGESORT', {
                        d: {
                            con: sSortStandards[subOptionMenu]
                        }
                    });
                    localStorage.setItem('sortOption', subOptionMenu);
                    EventMediator.trigger('SORT_GRID_LIST', subOptionMenu);
                }
            } else {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK); //when network disconnect,do not show popup
            }

            break;
        case CommonDefines.OptionMenu.UPDATE_APPS: // Update Apps
            Volt.KpiMapper.addEventLog('SELECTUPDATE');
            if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK); //when network disconnect,do not show popup
                break;
            }
            if (data.dimflag == true) {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS);
            } else {
                EventMediator.trigger('START_EDIT_MODE', 'MYAPPS');
                Volt.setTimeout(function () {
                    EventMediator.trigger('SHOW_EDIT_MODE', 'update');
                }, 0);
            }
            break;
        default:
            Volt.log('[home-view.js] invalid parentIndex is ' + data.parentIndex);
            break;
        }
    },
    /**
     * Call when search button selected
     * @method
     */
    onSelectSearch: function () {
        Volt.err('[HeaderView] onSelectSearch()');
        Volt.KpiMapper.addEventLog('SELECTSEARCH', {
            d: {
                cp: ''
            }
        });

        if (!Volt.browser) {
            Volt.log('[HeaderView] Launch search all');
            var appName = "org.tizen.search-all",
                args = {
                    "--root": "/usr/apps/org.tizen.search-all/",
                    "domain": "apps"
                },
                aulApp = new Aul();

            var result = aulApp.launchApp(appName, args);
            Volt.err('[HeaderView] Launch Search-All, result: ' + result);
            EventMediator.trigger('EVENT_OVERLAY_SHOW_DIM');
            Volt.Nav.focus(null);
        }
    },

    onSelectClose: function () {
        Volt.log('[HomeView.js] onSelectClose(), exit apps panel, apps panel will hide in background');
        if(Volt.APPS720P){
            Volt.exitKey();
        } else {
            Volt.setTimeout(function () {
                //Volt.quit();
                Volt.onKeyEvent(Volt.KEY_EXIT, Volt.EVENT_KEY_PRESS);
            }, 1);
        }
    },

    onChangeCursor: function (bVisible) {
        Volt.log('home-view.js ::HeaderView @onChangeCursor: visible: ' + bVisible);
        var iconContainer = this.widget.getChild('header-container');
        // @xiaojun.wang|20150311: Response to cursor change when popup exists or dimmed
        if (this.wzCloseButton && iconContainer) {
            Volt.log('home-view.js ::HeaderView @onChangeCursor: show/hide close button');
            if (bVisible) {
                iconContainer.getChild('main-header-icon-search-border').x = 0;
                iconContainer.getChild('main-header-icon-search').x = 1;
                iconContainer.getChild('main-header-icon-option-border').x = Volt.dimmensionWidth * 0.052083;
                iconContainer.getChild('main-header-icon-option').x = Volt.dimmensionWidth * 0.052083 + 1;
                iconContainer.getChild('main-header-icon-close-border').x = Volt.dimmensionWidth * 0.052083 * 2;
                this.wzCloseButton.show();
                this.offsetFlag = false;
            } else {
                iconContainer.getChild('main-header-icon-search-border').x = Volt.dimmensionWidth * 0.052083;
                iconContainer.getChild('main-header-icon-search').x = Volt.dimmensionWidth * 0.052083 + 1;
                iconContainer.getChild('main-header-icon-option-border').x = Volt.dimmensionWidth * 0.052083 * 2;
                iconContainer.getChild('main-header-icon-option').x = Volt.dimmensionWidth * 0.052083 * 2 + 1;
                iconContainer.getChild('main-header-icon-close-border').x = Volt.dimmensionWidth * 0.052083 * 3;
                this.wzCloseButton.hide();
                this.offsetFlag = true;

                if (Volt.Nav.getFocusedWidget() && Volt.Nav.getFocusedWidget().id == 'main-header-icon-close') {
                    Volt.Nav.focus(iconContainer.getChild('main-header-icon-option'));
                }
                if (Volt.Nav.getFocusedWidget() && Volt.Nav.getFocusedWidget().id == 'main-header-icon-search') {
                    CommonFunctions.voiceGuide(Volt.i18n.t('COM_FBID_SEARCH') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                    this.showToolTip(Volt.Nav.getFocusedWidget());
                }
            }
            this.updateToolTip();
        }
    },

    changePoupStatus: function () {
        Volt.log('[HeaderView] changePoupStatus()');

        this.bPopupshowing = false;

        if (!Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)) {
            this.onChangeCursor(false);
        } else {
            this.onChangeCursor(true);
        }
    },

    /**
     * Call when expand header view
     * @method
     */
    expand: function () {
        if (!OverlayView.isLoading()) {
            Volt.log('[HeaderView] expand()');
            if (this.expandAnimation) {
                this.expandAnimation.stop();
            }
            if (this.shrinkAnimation) {
                this.shrinkAnimation.stop(true);
            }

            (!this.expandAnimation) && (this.expandAnimation = new MultiObjectTransition());
            this.expandAnimation.setDuration(MENU_ANIM_DURATION);
            this.expandAnimation.AddObjectDestination(this.widget, "y", 0);
            this.expandAnimation.play();
        }
    },

    /**
     * Call when shrink header view
     * @method
     */
    shrink: function () {
        Volt.log('[HeaderView] shrink()');
        if (this.shrinkAnimation) {
            this.shrinkAnimation.stop();
        }
        if (this.expandAnimation) {
            this.expandAnimation.stop(true);
        }
        (!this.shrinkAnimation) && (this.shrinkAnimation = new MultiObjectTransition());
        this.shrinkAnimation.setDuration(MENU_ANIM_DURATION);
        this.shrinkAnimation.AddObjectDestination(this.widget, "y", -Volt.height * 0.016667);
        this.shrinkAnimation.play();
    },

    showToolTip: function (widget) {
        var absolutePosition = widget.getAbsolutePosition();
        Volt.log("[homeView.js] showToolTip absolutePosition.x = " + absolutePosition.x);
        Volt.log("[homeView.js] showToolTip absolutePosition.y = " + absolutePosition.y);
        var text = '';

        if (widget && widget.id == 'main-header-icon-search') {
            text = Volt.i18n.t('COM_FBID_SEARCH');
        } else if (widget && widget.id == 'main-header-icon-option') {
            text = Volt.i18n.t('COM_SID_OPTIONS');
        } else if (widget && widget.id == 'main-header-icon-close') {
            text = Volt.i18n.t('SID_EXIT');
        }
        if (text == '') {
            Volt.log("[HomeView.js] showtooltip error, text is empty");
            return;
        }
        var mustache = {
            x: absolutePosition.x + widget.width / 2 - Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) / 2 - Volt.dimmensionWidth * 0.0078125,
            w: Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) + Volt.dimmensionWidth * 0.015625,
            style: WinsetToolTip.TooltipStyle.Tooltip_Tail_Up,
            nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
            text: text,
            tailPostion: "center"
        };
        if (mustache.x + mustache.w > Volt.width) {
            mustache.x = absolutePosition.x + widget.width / 2 + Volt.dimmensionWidth * 0.0109375 - mustache.w;
            mustache.tailPostion = "end";
        }
        if (this.toolTip) {
            this.hideToolTip();
        }
        this.toolTipWidget = widget;
        this.toolTip = Volt.loadTemplate(HomeTemplate.toolTip, mustache);
        this.toolTip.setText(text);
        this.toolTip.show();
        this.startToolTipTimeOut();
    },
    hideToolTip: function (widget) {
        Volt.log("[homeView.js] hideToolTip");
        if (widget && widget != this.toolTipWidget) {
            Volt.log("[homeView.js] tooltip changed, do not hideToolTip");
            return;
        }
        if (this.toolTip) {
            Volt.log("[homeView.js] hideToolTip destroy tooltip");
            this.toolTip.destroy();
            this.toolTip = null;
        }
        this.toolTipWidget = null;
        this.clearToolTipTimeOut();
    },

    startToolTipTimeOut: function () {
        Volt.log('[HeaderView] startToolTipTimeOut');
        this.clearToolTipTimeOut();
        this.timeId = Volt.setTimeout(_.bind(this.hideToolTip, this), 2000);
    },
    clearToolTipTimeOut: function () {
        Volt.log('[HeaderView] clearToolTipTimeOut');
        if (this.timeId) {
            Volt.clearTimeout(this.timeId);
            this.timeId = null;
        }
    },

    updateToolTip: function () {
        Volt.log('[HeaderView] updateToolTip');
        if (this.toolTipWidget) {
            var tempWidget = this.toolTipWidget;
            this.hideToolTip();
            this.toolTipWidget = tempWidget;
            this.showToolTip(this.toolTipWidget);
        }
    },

    hide: function () {
        this.hideToolTip();
    }

});

exports = HomeView;
