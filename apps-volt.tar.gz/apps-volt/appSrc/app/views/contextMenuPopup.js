var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var EventMediator = Volt.require('app/common/eventMediator.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var OptionMenu = Volt.require('lib/custom-widgets/cm_option_menu_new.js');
var Template = Volt.require("app/templates/1080/contextMenuTemplate.js");
var DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js');
var AppInstallMgr = Volt.require('app/common/appInstallMgr.js');
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');

var ContextMenuPopup = Volt.BaseView.extend({
    contextMenuPopup: null,
    option: null,
    select_delete: false,
    beshowPopup: false,
    successEvent: [
        CommonDefines.Event.INSTALL_COMPLETED
    ],

    failEvent: [
        CommonDefines.Event.DOWNLOAD_FAIL_NOT_EXIST,
        CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE,
        CommonDefines.Event.DOWNLOAD_FAIL_LICENSE_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_SERVER_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_NETWORK_ERROR,
        CommonDefines.Event.DOWNLOAD_FAIL_OTHERS,

        CommonDefines.Event.DOWNLOAD_FAIL_DECRYPY_CONFIG,
  CommonDefines.Event.DOWNLOAD_FAIL_ICON_URL_IS_EMPTY,
  CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_ICON,
  CommonDefines.Event.DOWNLOAD_FAIL_DOWNLOAD_APP,
  CommonDefines.Event.DOWNLOAD_FAIL_APP_NOT_EXIST,
  CommonDefines.Event.DOWNLAOD_LOAD_WIDGET_INFO,
  CommonDefines.Event.DOWNLOAD_FAIL_CONVERT_ID_FROM_RUNTITLE,
  CommonDefines.Event.DOWNLOAD_FAIL_INPUT_PARAMETER,
  CommonDefines.Event.DOWNLOAD_FAIL_MOVE_DIR,
  CommonDefines.Event.DOWNLOAD_FAIL_UNZIP_FILES,
  CommonDefines.Event.DOWNLOAD_FAIL_NO_LICENSE_FILE,
  CommonDefines.Event.DOWNLOAD_FAIL_NO_INSTALL_DIR,
  CommonDefines.Event.DOWNLOAD_FAIL_TEMP_DIR_NOT_EXIST,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_URL,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_GET_EMP_INFO,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_NOT_ENOUGH_MEMORY,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_FAIL_MOVE,
  CommonDefines.Event.DOWNLOAD_FAIL_EMP_DOWNLOAD,

        CommonDefines.Event.INSTALL_FAIL_EXIST,
        CommonDefines.Event.INSTALL_FAIL_PKGMGR_ERROR,
        CommonDefines.Event.INSTALL_FAIL_LICENSE_ERROR,
        CommonDefines.Event.INSTALL_FAIL_OTHERS,
        CommonDefines.Event.INSTALL_CANCEL_COMPLETED,
        // CommonDefines.Event.INSTALL_CANCEL_FAILED
    ],

    initialize: function () {
        Volt.log('[contextMenuPopup.js] initialize');
    },


    show: function (param) {
        Volt.log('[contextMenuPopup.js] show');
        this.option = param;
        var template = _.clone(Template.contextMenu);
        this.select_delete = false;
        this.beshowPopup = false;
        Volt.log('[contextMenuPopup.js]  this.select_delete is ' + this.select_delete);
        Volt.log('[contextMenuPopup.js]  this.beshowPopup is ' + this.beshowPopup);
        Volt.log('[contextMenuPopup.js] this.option.baseWidget.getAbsolutePosition().x = ' + this.option.baseWidget.getAbsolutePosition().x);
        Volt.log('[contextMenuPopup.js] this.option.baseWidget.getAbsolutePosition().y = ' + this.option.baseWidget.getAbsolutePosition().y);

        var xPos = this.option.baseWidget.getAbsolutePosition().x + this.option.baseWidget.width;
        var yPos = this.option.baseWidget.getAbsolutePosition().y;
        /*if(Volt.APPS_REVERSE){
            xPos = Volt.width - this.option.baseWidget.getAbsolutePosition().x;
	      if(xPos + template.width > scene.width){
                xPos = Volt.width - this.option.baseWidget.getAbsolutePosition().x - this.option.baseWidget.width - template.width;
            }
	 }*/
        template.x = xPos;
        template.y = yPos;

        var appID = this.option.appInfoVM.get('id');
        Volt.log("[contextMenuPopup.js] appID is " + appID);
        Volt.log("[contextMenuPopup.js] app_id is " + this.option.appInfoVM.get('app_id'));
        
        if (this.option.type == 'myapps' && this.option.feature == 1) {
            template.showNumber = 2;
            if(Volt.moveSupport){
                 template.showNumber = 3;
            }
            if (this.option.is_removable == true) {
                if ( AppInstallMgr.getUpdateList(this.option.appInfoVM.get('app_id')).app_id != undefined ){
                        template.showNumber = 1;
                        template.items[0].text = Volt.i18n.t('COM_SID_CANCEL');

                        if (template.items[1]) {
                          template.items.pop();
                        }
                }else{
                     template.items[0].text = Volt.i18n.t('COM_SID_DELETE');
                      if (template.items[1]) {
                         template.items[1].text = Volt.i18n.t('TV_SID_VIEW_DETAILS');
                     } else {
                         template.items.push({
                             style: 12,
                             text: Volt.i18n.t('TV_SID_VIEW_DETAILS')
                         });
                     }
                     if(Volt.moveSupport){  //add move support process
                          if (template.items[1]) {
                              template.items[1].text = Volt.i18n.t('COM_SID_MOVE');
                          } else {
                              template.items.push({
                                  style: 12,
                                  text: Volt.i18n.t('COM_SID_MOVE'),
                              });
                          }
                          if (template.items[2]) {
                              template.items[2].text = Volt.i18n.t('TV_SID_VIEW_DETAILS');
                          } else {
                              template.items.push({
                                  style: 12,
                                  text: Volt.i18n.t('TV_SID_VIEW_DETAILS')
                              });
                          }
                     }   
                }
            }else {
                 if (AppInstallMgr.getInstallList(this.option.appInfoVM.get('app_id')).app_id == undefined){
                        template.items[0].text = Volt.i18n.t('TV_SID_REINSTALL');
                        if (template.items[1]) {
                            template.items[1].text = Volt.i18n.t('TV_SID_VIEW_DETAILS');
                        } else {
                            template.items.push({
                                style: 12,
                                text: Volt.i18n.t('TV_SID_VIEW_DETAILS')
                            });
                        }
                        if(Volt.moveSupport){  //add move support process
                            if (template.items[1]) {
                            template.items[1].text = Volt.i18n.t('COM_SID_MOVE');
                            } else {
                               if(Volt.moveSupport){
                                    template.items.push({
                                        style: 12,
                                        text: Volt.i18n.t('COM_SID_MOVE')
                                    });
                               }
                                
                            }
                            if (template.items[2]) {
                                template.items[2].text = Volt.i18n.t('TV_SID_VIEW_DETAILS');
                            } else {
                                template.items.push({
                                    style: 12,
                                    text: Volt.i18n.t('TV_SID_VIEW_DETAILS')
                                });
                            }
                        }     
                  }else{
                      template.showNumber = 1;
                      if (template.items[2]) {
                          template.items.pop();
                      }
                      if (template.items[1]) {
                          template.items.pop();
                      }
                      template.items[0].text = Volt.i18n.t('COM_SID_CANCEL');
                  }  
            }
        } else {
            template.showNumber = 1;
            if (template.items[2]) {
                template.items.pop();
            }
            if (template.items[1]) {
                template.items.pop();
            }
            if (this.option.type == 'myapps') {
                if (AppInstallMgr.getInstallList(this.option.appInfoVM.get('app_id')).app_id == undefined){
                    if ( AppInstallMgr.getUpdateList(this.option.appInfoVM.get('app_id')).app_id == undefined ){
                    Volt.log("[contextMenuPopup.js] reinstall");
                     template.showNumber = 2;
                     if(Volt.moveSupport){
                          template.showNumber = 3;
                     }
                    template.items[0].text = Volt.i18n.t('TV_SID_REINSTALL');
                      if (template.items[1]) {
                         template.items[1].text = Volt.i18n.t('TV_SID_VIEW_DETAILS');
                     } else {
                         template.items.push({
                             style: 12,
                             text: Volt.i18n.t('TV_SID_VIEW_DETAILS')
                         });
                     }
                     if(Volt.moveSupport){  //add move support process
                        if (template.items[1]) {
                             template.items[1].text = Volt.i18n.t('COM_SID_MOVE');
                         } else {
                             template.items.push({
                                 style: 12,
                                 text: Volt.i18n.t('COM_SID_MOVE')
                             });
                         }
    		            if (template.items[2]) {
                             template.items[2].text = Volt.i18n.t('TV_SID_VIEW_DETAILS');
                         } else {
                             template.items.push({
                                 style: 12,
                                 text: Volt.i18n.t('TV_SID_VIEW_DETAILS')
                             });
                         } 
                     }
                    }else{
                       // Volt.log("[contextMenuPopup.js] cancel");
                        template.items[0].text = Volt.i18n.t('COM_SID_CANCEL');
                     }
                }else{
                    //Volt.log("[contextMenuPopup.js] update now     ");
                    Volt.log("[contextMenuPopup.js] cancel");
                    template.items[0].text = Volt.i18n.t('COM_SID_CANCEL');
                 }
            } else if (DownloadedAppsMgr.isDownloaded(appID) == true) {
                template.items[0].text = Volt.i18n.t('UID_OPEN');
            } else if (AppInstallMgr.getInstallList(appID).app_id == undefined) {
                template.items[0].text = Volt.i18n.t('UID_DOWNLOAD');
            } else {
                template.items[0].text = Volt.i18n.t('COM_SID_CANCEL');
            }
        }

        this.contextMenuPopup = new OptionMenu(template);
        this.contextMenuPopup.setCallback(_.bind(this.onContextMenuCB, this));
        this.contextMenuPopup.setFocusChangeCallback(_.bind(this.onContextMenuFocusChange, this));
        this.contextMenuPopup.setSelectIndex(0);
        
        if (xPos + this.contextMenuPopup.width > Volt.width) {
            this.contextMenuPopup.x = this.option.baseWidget.getAbsolutePosition().x - ( this.contextMenuPopup.width );
        }


        //make 'cancel' dim at update stauts 
        var downloadingApps = _.findWhere(AppInstallMgr.installList, {app_id:this.option.appInfoVM.get('app_id')});
        if (downloadingApps!= null && downloadingApps.type == CommonDefines.AppInstallMgr.TYPE_UPDATE)
         {
            this.contextMenuPopup.dimListItem(0);
         }
        if (this.option.type == 'myapps' && (this.option.appInfoVM.get('app_title') == 'e-Manual' ||
            this.option.appInfoVM.get('app_id') == "org.tizen.browser")) {
            this.contextMenuPopup.dimListItem(0);
            if(3 == template.showNumber){
                this.contextMenuPopup.dimListItem(2);
            }else if(2 == template.showNumber){
                this.contextMenuPopup.dimListItem(1);
            } 
        }

         if (this.option.type != 'myapps') {
            if (DownloadedAppsMgr.isDownloaded(appID) != true){
                    //Volt.log('[option-menu-popup.js]this.option.parentView.progressView.isDownloadableApp() is ' + this.option.parentView.progressView.isDownloadableApp());
                if (AppInstallMgr.getInstallList(appID).app_id == undefined){
                  if (!this.option.parentView.progressView.isDownloadableApp()) {

                    //Volt.log('[option-menu-popup.js]this.option.parentView.progressView.isDownloadableApp() is ' + this.option.parentView.progressView.isDownloadableApp());
                        var result = voltapi.ContentsMgr.getStorages();
                        var len = 0;
                        if (result && result.storages) {
                            len = result.storages.length;
                        }
                        if( 0 == len){
                            this.contextMenuPopup.dimListItem(0);
                            //Volt.log('[option-menu-popup.js]this.contextMenuPopup.dimListItem     ' );
                        }
                 }
             }
            }  
        }
        
        this.contextMenuPopup.setTimeout(30 * 1000, _.bind(this.hide, this));
        //this.contextMenuPopup.setFocus();
        this.contextMenuPopup.showFocus('false');
        this.contextMenuPopup.show();
        //Volt.Nav.beginModal(this.contextMenuPopup);

        if ( this.option.setfocus ){
            this.focusmenu();
        }else{
            EventMediator.on(CommonDefines.Event.EVENT_LONGPRESS_RELEASE, this.focusmenu, this);
        }
		this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.hide);
        this.listenTo(EventMediator,CommonDefines.Event.EVENT_SHOW_COMMON_POPUP, this.popupCheck, this);
        this.listenToSucessEvent();
        this.listenToFailEvent();
    },


    popupCheck: function(messageType){
        Volt.log('[option-menu-popup.js] popupCheck:messageType is ' + messageType);
        if(CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU != messageType){
            this.beshowPopup = true;        
            EventMediator.trigger('EVENT_OVERLAY_DIM_ALL');
            this.hide();
        }
    },


    onContextMenuCB: function (index, subIndex, bDim) {
        Volt.log('[contextMenuPopup.js] index is ' + index + ', subIndex is ' + subIndex + ', bDim is ' + bDim);
        if (bDim) {
            Volt.log('[contextMenuPopup.js] this item is dimmed');
            return;
        }
        var viewDetailIndex = 1;
        if(Volt.moveSupport){
            viewDetailIndex = 2;
        }
        if (this.option.type == 'myapps' && this.option.feature == 1 && index == 0 && this.option.is_removable == true) {
            Volt.log('[contextMenuPopup.js] EVENT_MY_APPS_SINGLE_DELETE ' + this.option.appInfoVM.get('app_id'));
            this.select_delete = true;
            EventMediator.trigger('EVENT_OVERLAY_DIM_ALL');
            EventMediator.trigger(CommonDefines.Event.EVENT_MY_APPS_SINGLE_DELETE, this.option.appInfoVM.get('app_id'));

            Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                d: {
                    cmn: 'delete'
                }
            });
        } else if (this.option.type == 'myapps' && this.option.feature == 1 && index == viewDetailIndex && this.option.is_removable == false) {
            if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                return;
            } else {
                Backbone.history.navigate('detail/' + this.option.appInfoVM.get('app_id'), {
                    trigger: true
                });

                Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                    d: {
                        cmn: 'viewdetail'
                    }
                });
            }
        } else if (this.option.type == 'myapps' && this.option.feature == 1 && index == viewDetailIndex) {
            if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                return;
            } else {
                Backbone.history.navigate('detail/' + this.option.appInfoVM.get('app_id'), {
                    trigger: true
                });

                Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                    d: {
                        cmn: 'viewdetail'
                    }
                });
            }
        } else if (this.option.type == 'myapps' && (this.option.feature == 2 || this.option.is_removable == false) && index == 0) {
          if (AppInstallMgr.getInstallList(this.option.appInfoVM.get('app_id')).app_id == undefined && AppInstallMgr.getUpdateList(this.option.appInfoVM.get('app_id')).app_id == undefined){
                  AppInstallMgr.installApp(this.option.appInfoVM.get('app_id'), "");  
                  this.option.appInfoVM.set('is_dim',true);
                  this.option.appInfoVM.set('state','INSTALL_START');
                  Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                      d: {
                          cmn: 'reinstall'
                      }
                  });
            }else{
                   AppInstallMgr.cancelInstallApp(this.option.appInfoVM.get('app_id'));
      
                  Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                      d: {
                          cmn: 'cancel'
                      }
                  });
            }
           
        } else if (this.option.type == 'myapps' && this.option.feature == 2 && index == viewDetailIndex) {
          if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                return;
            } else {
                Backbone.history.navigate('detail/' + this.option.appInfoVM.get('app_id'), {
                    trigger: true
                });

                Volt.KpiMapper.addEventLog('SELECTLONGPRESSMA', {
                    d: {
                        cmn: 'viewdetail'
                    }
                });
            }
           
        } else if (index == 0) {
            Volt.log(DownloadedAppsMgr.isDownloaded(this.option.appInfoVM.get('id')));

            if (DownloadedAppsMgr.isDownloaded(this.option.appInfoVM.get('id')) == true) {
                AppInstallMgr.launchApp(this.option.appInfoVM.get('id'), "");
                EventMediator.trigger('HOMEVIEW_LAUNCH_APP');

                switch (this.option.type) {
                case 'whatsNew':
                    Volt.KpiMapper.addEventLog('SELECTLONGPRESSWN', {
                        d: {
                            cmn: 'open'
                        }
                    });
                    break;
                case 'mostPopular':
                    Volt.KpiMapper.addEventLog('SELECTLONGPRESSMP', {
                        d: {
                            cmn: 'open'
                        }
                    });
                    break;
                case 'categories':
                default:
                    Volt.KpiMapper.addEventLog('SELECTLONGPRESSSC', {
                        d: {
                            cmn: 'open'
                        }
                    });
                    break;
                }
            } else {
                if (AppInstallMgr.getInstallList(this.option.appInfoVM.get('id')).app_id == undefined) {

                    this.option.parentView.installApp();

                    switch (this.option.type) {
                    case 'whatsNew':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSWN', {
                            d: {
                                cmn: 'download'
                            }
                        });
                        break;
                    case 'mostPopular':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSMP', {
                            d: {
                                cmn: 'download'
                            }
                        });
                        break;
                    case 'categories':
                        //fall through
                    default:
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSSC', {
                            d: {
                                cmn: 'download'
                            }
                        });
                        break;
                    }
                } else {
                    this.option.parentView.cancelInstallApp();

                    switch (this.option.type) {
                    case 'whatsNew':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSWN', {
                            d: {
                                cmn: 'cancel'
                            }
                        });
                        break;
                    case 'mostPopular':
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSMP', {
                            d: {
                                cmn: 'cancel'
                            }
                        });
                        break;

                    case 'categories':
                        //fall through
                    default:
                        Volt.KpiMapper.addEventLog('SELECTLONGPRESSSC', {
                            d: {
                                cmn: 'cancel'
                            }
                        });
                        break;
                    }
                }
            }
        }
        
        if (this.option.type == 'myapps' && index == 1){
            if(Volt.moveSupport){
                EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_MOVE_MYAPPS,true);
            }
        }
        this.hide();
    },

    onContextMenuFocusChange: function (preIndex, preSubIndex, curIndex, curSubIndex, bDim) {
        Volt.log("[contextMenuPopup.js] onContextMenuFocusChange ::: " + preIndex + ',' + preSubIndex + ',' + curIndex + ',' + curSubIndex + ',' + bDim);
        var voiceText = this.contextMenuPopup.getListText(curIndex);
        if(curIndex == 1){
            voiceText = voiceText + ',' + Volt.i18n.t('TV_SID_VOICE_GUIDE_NOT_SUPPORTED');
        }
        CommonFunctions.voiceGuide(voiceText);
    },


    listenToSucessEvent: function () {
        var self = this;
        _.each(this.successEvent, function (eventType, i) {
            self.listenTo(EventMediator, eventType, self.processSuccessEvent);
        });
    },

    listenToFailEvent: function () {
        var self = this;
        _.each(this.failEvent, function (eventType, i) {
            self.listenTo(EventMediator, eventType, self.processFailEvent);
        });
    },

    stopListenToEvent: function (eventList) {
        var self = this;
        if (eventList == null) {
            this.stopListenToEvent(this.successEvent);
            this.stopListenToEvent(this.failEvent);
        } else {
            _.each(eventList, function (eventType, i) {
                self.stopListening(EventMediator, eventType);
            });
        }
    },

    processSuccessEvent: function (data) {
        Volt.log('[contextMenuPopup] get download complete event');
        if (this.contextMenuPopup && this.option.appInfoVM.get('id') == data.app_id) {
            Volt.log('[contextMenuPopup] set submenu to OPEN');
            this.contextMenuPopup.setListText(0, Volt.i18n.t('UID_OPEN'));

        }
        if (this.contextMenuPopup&&this.option.type == 'myapps'&& this.option.appInfoVM.get('app_id')== data.app_id)
        {
            //this.contextMenuPopup.unDimListItem(0);
            this.hide();
        }
    },

    processFailEvent: function (data) {
        Volt.log('[contextMenuPopup] get parse error event');
        if (this.contextMenuPopup && this.option.appInfoVM.get('id') == data.app_id) {
            this.contextMenuPopup.setListText(0, Volt.i18n.t('UID_DOWNLOAD'));
        }
        if (this.contextMenuPopup&&this.option.type == 'myapps'&& this.option.appInfoVM.get('app_id') == data.app_id)
        {
            //this.contextMenuPopup.unDimListItem(0);
            this.hide();
        }
    },

    hide: function () {
        Volt.log('[contextMenuPopup.js] hide');
        if (this.contextMenuPopup) {
            this.contextMenuPopup.hide();
            this.contextMenuPopup.destroy();
            this.contextMenuPopup = null;
        }
        this.stopListenToEvent();

        if (CommonDefines.AppState.APP_STATE_ACTIVATE == CommonFunctions.getAppState() && this.select_delete == false && !this.beshowPopup ) {
            EventMediator.trigger('EVENT_OVERLAY_HIDE_DIM');
        }
		else if(CommonDefines.AppState.APP_STATE_DEACTIVATE == CommonFunctions.getAppState()){
            EventMediator.trigger('EVENT_OVERLAY_DIM_ALL');
			Volt.Nav.focus(null);
		}
        

        //Volt.Nav.endModal();

        
        this.stopListening();
        //Volt.log('[contextMenuPopup] off    this.option.setfocus     '+this.option.setfocus  );
        if ( !this.option.setfocus  ){
            //Volt.log('[contextMenuPopup] off    EVENT_LONGPRESS_RELEASE   ');
            EventMediator.off(CommonDefines.Event.EVENT_LONGPRESS_RELEASE, this.focusmenu, this);
        }
    },


    focusmenu: function () {
        Volt.log('[contextMenuPopup] ~~~~~~~focusmenu~~~~~~~~~~~');
        this.contextMenuPopup.setFocus();

    }
});

exports = new ContextMenuPopup;