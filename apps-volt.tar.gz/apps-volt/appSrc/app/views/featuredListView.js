/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview This module manages featured list view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require("modules/VoltJSON.js");

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js');
var FeaturedListTemplate = Volt.require('app/templates/1080/featuredListTemplate.js');
var GridListView = Volt.require('app/views/gridListView.js');
var GridListTemplate = Volt.require('app/templates/grid-list-template.js');

var AppInfoVMCollection = Volt.require('app/models/appInfoVMCollection.js');
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var AppInfoProgressView = Volt.require("app/views/appInfoProgressView.js");
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");
var tvResolution = (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080;
/**
 * @name FeaturedListView
 */
var FeaturedListView = Volt.BaseView.extend({
    /** @lends FeaturedListView.prototype */
    appInfoVMCollection: null,
    template: FeaturedListTemplate.container,
    gridlist: FeaturedListTemplate.gridList,
    appInfoView: null,
    piaView: null,
    viewList: null,
    gridListView: null,
    isShown: false,
    noContentBtn: null,
    
    exitFlag: false,
    
    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },
    /**
     * Initialize this view
     * @name FeaturedListView
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent);
        this.listenTo(EventMediator, 'GRID_FOVEA_DISABLE', this.removefoveaEffect);
        this.listenTo(EventMediator, 'GRID_FOVEA_ENABLE', this.addfoveaEffect);
        
        this.listenTo(EventMediator, 'VOLT_EXIT', this.onExit);
    },

    /**
     * render once after view is created
     * @method
     * @param  {widget} parentWidget parentWidget
     * @return {View}              this View
     */
    render: function (parentWidget) {
        Volt.err('[FeaturedListView] render');
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_FOCUS_ZOOM, this.resetListImage);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_HIGH_CONTRAST, this.resetListImage);

        var contentContainer = parentWidget.widget.getChild('main-content-container');

        this.setWidget(Volt.loadTemplate(this.template, {
            type: this.featuredType
        }));
        contentContainer.addChild(this.widget);

        if (!this.appInfoVMCollection) {
            this.appInfoVMCollection = new AppInfoVMCollection();
            this.appInfoVMCollection.setCollection(this.featuredType);
        }

        this.setAppInfoView();
        return this;
    },

    /**
     * show this view
     * @method
     * @param  {object} param         additional data
     * @param  {number} animationType showing animation type
     * @return {object}               promise obj to synchronize logic.
     */
    show: function (param, animationType) {
        Volt.log('[featuredListView.js @show]');

        var deferred = Q.defer();
        var self = this;

        this.isShown = true;
        // Listen to model
        if (this.appInfoVMCollection) {
            this.listenTo(this.appInfoVMCollection, 'reset', this.renderContent);
            this.listenTo(this.appInfoVMCollection, 'add', function (added) {
                this.gridListView.addItem(added);
            });
            this.listenTo(this.appInfoVMCollection, 'error', this.showErrorPopup);
            this.appInfoVMCollection.startListeningEvent();
        }

        this.listenTo(EventMediator, 'TEMP_LONGPRESSKEY', this.onLongPressed);
        this.listenTo(EventMediator, CommonDefines.Event.GRID_NAV_FOCUS_CHANGED, this.onFocusChanged);
        this.listenTo(EventMediator, CommonDefines.Event.GRID_NAV_FOCUS_BLURED, this.onFocusBlured);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS, this.onFocusGrid);

        this.fetch();

        this.widget.show();

        if (this.gridListView) {

            // Hide Loading
            EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

            this.gridListView.widget.custom = {
                focusable: true
            };
            
            if (this.exitFlag) {
                this.resetFocus();
            }
            
            this.gridListView.widget.showWithAnimation();

            for (var i in this.viewList) {
                this.viewList[i].showProgressBar();
            }
        }

        Volt.Nav.reload();

        if (this.gridListView) {
            var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
            var isDetail = (/#detail/g).test(previousHistory);
            if (isDetail) {
                Volt.Nav.focus(this.gridListView.widget);
            }
        }
        
        this.exitFlag = false;
        
        deferred.resolve();
        return deferred.promise;
    },
    /**
     * hide this view
     * @method
     * @param  {number} animationType hiding animation type
     * @return {object}               promise obj to synchronize logic.
     */
    hide: function (animationType) {
        Volt.err('[FeaturedListView] hide');
        this.isShown = false;

        var deferred = Q.defer();
        deferred.resolve();
        this.destroyNocontentButton();
        this.widget.hide();

        if (this.gridListView) {
            Volt.Nav.removeItem(this.gridListView.widget, true);
            this.gridListView.widget.hideWithAnimation();

            // Hide progress bars
            for (var i in this.viewList) {
                this.viewList[i].hideProgressBar();
            }
        }

        if (this.appInfoVMCollection) {
            this.stopListening(this.appInfoVMCollection);
            this.appInfoVMCollection.stopListeningEvent();
        }
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS);
        this.stopListening(EventMediator, 'GRID_FOVEA_DISABLE');
        this.stopListening(EventMediator, 'GRID_FOVEA_ENABLE');
        return deferred.promise;
    },
    
    /**
     * Pause this view.
     * @method
     */
    pause: function () {
        Volt.err('[FeaturedListView] pause');
        if (this.isShown) {
            for (var i in this.viewList) {
                this.viewList[i].hideProgressBar();
            }
        }
    },

    /**
     * Resume this view.
     * @method
     */
    resume: function () {
        Volt.err('[FeaturedListView] resume');
        if (this.isShown) {
            this.widget.show();
            for (var i in this.viewList) {
                this.viewList[i].showProgressBar();
            }
        }
    },
    
    fetch: function () {
        if (!this.gridListView) {
            EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING');
            this.fetchServer();
        }
    },

    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (widget) {
            if (widget.id == ('featured-list-button-index-' + this.featuredType)) {
                if (this.noContentBtn) {
                    this.noContentBtn.setFocus();
                }
            }
        }
    },

    /**
     * When blured on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onBlur: function (widget) {},
    
    onExit: function () {
        this.exitFlag = true;
    },
    
    setFocus: function () {
        if (this.gridListView) {
            Volt.Nav.focus(this.gridListView.widget);
            return true;
        }
        return false;
    },
    
    resetFocus: function () {
        Volt.log(['featuredListView.js @resetFocus']);
        if (this.gridListView) {
            var grid = this.gridListView.widget;

            // If the focus of grid is not at the first item, set to first item
            if (grid.getFocusItemIndex().itemIndex !== 0) {
                try {
                    HALOUtil.enableAUI(false);
                    Volt.log('HALOUtil.enableAUI(false)');
                } catch (e) {}

                grid.setFocusItemIndex(0, 0);
                // Call this to update the grid
                grid.showFocus('false');
                grid.hideFocus('false');

                try {
                    HALOUtil.enableAUI(true);
                    Volt.log('HALOUtil.enableAUI(true)');
                } catch (e) {}
            }

            if (this.featuredType == 'whatsNew') {
                Volt.Nav.focus(grid);
            }
        }
    },
    
    /**
     * set msgbox button click callback
     * @method  caoyr 11.14
     * @memberof FeaturedListView
     */
    processMsgBoxEvent: function (data) {
        Volt.err('[FeaturedListView] processMsgBoxEvent:type is:', data.msgBoxtype + " eventType is:" + data.eventType);
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
                Volt.err('[FeaturedListView] processMsgBoxEvent: ok');
                Backbone.history.back();

                break;
            default:
                break;
            }
        } else if (data.eventType == CommonDefines.Event.SELECT_BTN2) {
            Volt.err('[detail-view.js] processMsgBoxEvent:SELECT_BTN2');
        }
    },
    
    createNocontentButton: function () {
        Volt.err('[FeaturedListView] createNocontentButton');
        if (this.noContentBtn) {
            Volt.err('[FeaturedListView] this.noContentBtn is exist');
            return;
        }
        var btnStyle = {
            style: WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleB_Text,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resolution: tvResolution,
        };
        var btnBG = this.widget.getDescendant('featured-list-button-index-' + this.featuredType);
        if (btnBG) {
            Volt.err('[FeaturedListView] createNocontentButton');
            this.noContentBtn = Volt.loadTemplate(FeaturedListTemplate.troubelShootBtn, btnStyle);
            btnBG.addChild(this.noContentBtn);
            this.noContentBtn.setText({
                state: "all",
                text: Volt.i18n.t('TV_SID_TROUBLESHOOT'),
            });
        }
        btnBG.custom = {
            focusable: true
        };
        Volt.Nav.setNextItemRule(btnBG, 'right', btnBG);
        this.widget.getChild('featured-list-no-content-' + this.featuredType).text = Volt.i18n.t('TV_SID_MIX_NOT_CONNECTED_INTERNET_FEATURE').replace('<<A>>', 'AS000');

        Volt.err('[FeaturedListView] createNocontentButton');
        var btnListener = this.btnListener = new ButtonListener();
        btnListener.onButtonClicked = function (button, type) {
            var aulApp = new Aul();
            aulApp.launchApp("org.tizen.NetworkSetting-Tizen");
        }.bind(this);

        this.noContentBtn.addListener(btnListener);
        Volt.Nav.reload();
        Volt.Nav.focus(btnBG);

        //// @xiaojun.wang|20150215: Refresh when network is connected again
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS, this.fetchServer);
    },

    destroyNocontentButton: function () {
        Volt.err('[FeaturedListView] destroyNocontentButton');
        if (this.noContentBtn) {
            var btnBG = this.widget.getDescendant('featured-list-button-index-' + this.featuredType);

            if (Volt.Nav.getCurrentFocus() == btnBG) {
                EventMediator.trigger('EVENT_CATEGORY_SET_FOCUS');
            }

            if (btnBG) {
                btnBG.custom = {
                    focusable: false
                };
            }
            btnBG.removeChild(this.noContentBtn);
            this.noContentBtn.destroy();
            Volt.Nav.reload();
            this.noContentBtn = null;
        }
        this.widget.getChild('featured-list-no-content-' + this.featuredType).text = "";

        //// @xiaojun.wang|20150215: Refresh when network is connected again
        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS);
    },


    fetchCache: function (data) {

        Q.all([
            this.appInfoVMCollection.offline(data)
        ])
            .then(_.bind(function () {
            }, this))
            .fail(_.bind(function () {
            }, this));
    },

    fetchServer: function (isReset) {
        Volt.log('[FeaturedListView] fetchServer networkstatus is ' + Volt.DeviceInfoModel.get('networksStatus'));
        if (Volt.DeviceInfoModel.get('networksStatus') == "OK") {
            this.destroyNocontentButton();
            Q.all([
                this.appInfoVMCollection.fetch(isReset)
            ])
                .then(function () {
                })
                .fail(function () {
                    EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
                });

        } else if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
            EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
            if (!this.gridListView) {
                this.createNocontentButton();
            }
        }
    },
    updateContent: function () {
        print('update content');
        if (this.gridListView && this.gridListView.gridListControl) {
            if (this.appInfoVMCollection.length > 0) {
                for (var i = 0; i < this.appInfoVMCollection.length; i++) {
                    var data = this.gridListView.gridListControl.getData(0, i);
                    data.model = this.appInfoVMCollection.at(i);
                    print('update content:data.model.title ' + data.model.get('title'));
                }
            }
            this.gridListView.gridListControl.updateAllItems(0);
        }
    },
    /**
     * make it be gridList style.
     * @method
     * @param  {Collection} collection appInfoVMCollection
     */
    renderContent: function (collection, options) {
        Volt.err('[FeaturedListView] renderContent');

        // For what'snew to remove this button
        this.destroyNocontentButton();

        EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

        if (this.appInfoVMCollection.length > 0) {
            if (!this.gridListView) {
                var container = this.widget.getChild('featured-list-content-container-' + this.featuredType);
                this.gridlist.parent = container;
                this.gridListView = this.initNativeGrid();

                this.grid = this.gridListView.render(this.appInfoVMCollection).widget;

                container.addChild(this.grid);

                this.grid.showWithAnimation();
            } else {
                this.updateContent();
            }

            if (this.gridListView) {
                this.grid.custom = {
                    focusable: true
                };

                for (var i in this.viewList) {
                    this.viewList[i].showProgressBar();
                }
            }
            this.widget.getChild('featured-list-no-content-' + this.featuredType).text = "";

            Volt.Nav.setNextItemRule(this.grid, 'up', 'category-list-container');
            Volt.Nav.setNextItemRule(this.grid, 'left', this.grid);
            Volt.Nav.setNextItemRule(this.grid, 'right', this.grid);

            Volt.Nav.reload();

            if ("whatsNew" == this.featuredType) {
                //add by lihao.zha@20141222 for fixing first enter panel voice guide issue
                Volt.Nav.focus(null);
                Volt.Nav.focus(this.grid); //make first page's default focus to first item of gridlist. 
            }

        } else {
            this.widget.getChild('featured-list-no-content-' + this.featuredType).text = Volt.i18n.t('COM_NO_CONTENT_FOUND');
            if ("whatsNew" == this.featuredType && !this.gridListView && Volt.Nav.getCurrentFocus() == null) {
                // Focus CategoryList
                EventMediator.trigger('EVENT_CATEGORY_SET_FOCUS');
            }
        }
    },

    initNativeGrid: function () {
        Volt.err('[FeaturedView] initNativeGrid');
        this.viewList = new Array();
        var gridListView = new GridListView({
            gridListControlParam: this.gridlist,
            thumbnailStyle: this.featuredType == 'whatsNew' ? GridListTemplate.THUMB_WHATS_NEW : GridListTemplate.THUMB_MOST_POPULAR,
            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.err('[FeaturedView] onDrawLoadData ' + data._index);
                    var model = data.model; //this.appInfoVMCollection.at(parseInt(data._index, 10));
                    var iView = null;
                    if (self.featuredType == 'whatsNew' && self.piaView != null && data._index == 1) {
                        iView = new self.piaView(model, self.featuredType, thumbnail);
                    } else {
                        iView = new self.appInfoView(model, self.featuredType);
                    }
                    iView.render(data._index, thumbnail);
                    self.viewList[data._index] = iView;
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.err('[FeaturedView] onDrawUpdateData ' + data._index);
                    self.viewList[data._index].updateItemView(thumbnail, data);

                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.err('[FeaturedView @onDrawUnloadData] index:' + data._index);

                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }

                    //// @xiaojun.wang|20150120: Fix DF150119-00713
                    delete self.viewList[data._index];
                },
                onGridFocus: function (wzFocused) {
                    Volt.err('[FeaturedView] onGridFocus');

                    gc();

                    if (wzFocused) {
                        var voiceText;
                        if (wzFocused.customType == 'whatsNew') {
                            voiceText = Volt.i18n.t('TV_SID_APPS_KR_PANEL') + ' ' +
                                Volt.i18n.t('UID_APPS_WHATS_NEW');
                        } else {
                            voiceText = Volt.i18n.t('TV_SID_APPS_KR_PANEL') + ' ' +
                                Volt.i18n.t('COM_SID_MOSTPOPULAR_CATEGORY');
                        }
                        voiceText = voiceText + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA') + ',' +
                            Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', self.appInfoVMCollection.length) +
                            ',' + wzFocused.customTitle + ',' + Volt.i18n.t('TV_SID_VOICE_GUIDE_NOT_AVAIIL_ALL_APPS');
                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.err('[FeaturedView] onGridBlur');

                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo) {
                    Volt.err('[FeaturedView] onFocusChanged');
                    if (wzFrom && wzTo) {
                        CommonFunctions.voiceGuide(wzTo.customTitle);
                    }
                },
                onItemPress: function (wz, itemData, data) {
                    Volt.err('[FeaturedView] onItemPress');
                    self.SelectItem(itemData.itemIndex, data.model, self.featuredType);

                },
                onEnterKeyLongPressed: function (wzFocused, itemData, type) {
                    if (wzFocused && itemData != -1) {
                        if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                            return;
                        }
                        var vmSelected = self.appInfoVMCollection.collection.at(itemData);
                        iSelectedContext = self.viewList[itemData];

                        if (iSelectedContext.downloadable) {
                            var param = {
                                baseWidget: wzFocused,
                                appInfoVM: vmSelected,
                                parentView: iSelectedContext,
                                type: iSelectedContext.type,
                                feature: iSelectedContext.feature
                            }

                            if (type == 'mouse') {
                                param.setfocus = true;
                            }
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU, param);
                        }

                        switch (self.appInfoVMCollection.type) {
                        case 'whatsNew':
                            Volt.KpiMapper.addEventLog('LONGPRESSWN');
                            break;

                        case 'mostPopular':
                            Volt.KpiMapper.addEventLog('LONGPRESSMP');
                            break;
                        }
                    }
                },

            }

        });

        // for test
        var self = this;

        return gridListView;
    },



    /**
     * callback on selecting
     * @method
     * @param  {number} index selected item's indext
     */
    SelectItem: function (index, model, type) {
        Volt.err('AppInfoView onSelect : ' + index);
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
            return;
        }
        if ('whatsNew' == type) {
            Volt.err('AppInfoView play ad');
            if (1 == index) {
                if (this.viewList[index]) {
                    if (this.viewList[index].onSelect) {
                        this.viewList[index].onSelect();
                    }
                }
                return;
            }
        }
        switch (type) {

        case 'mostPopular':
            Volt.KpiMapper.addEventLog('SELECTMP', {
                d: {
                    appid: model.get('id'),
                    pn: model.get('order')
                }
            });

            break;

        case 'event':
            Volt.KpiMapper.addEventLog('SELECTEV', {
                d: {
                    appid: model.get('id'),
                    pn: model.get('order')
                }
            });
            break;

        case 'whatsNew':
            Volt.KpiMapper.addEventLog('SELECTWN', {
                d: {
                    appid: model.get('id'),
                    pn: model.get('order')
                }
            });

            break;
        }

        Backbone.history.navigate('detail/' + model.get('id'), {
            trigger: true
        });



    },


    removeGrid: function () {
        Volt.err('[FeaturedListView] remove grid list');

        if (this.gridListView) {
            this.gridListView = null;
        }
    },

    setAppInfoView: function () {
        this.appInfoView = AppInfoView;
    },

    removefoveaEffect: function () {
        if (!this.gridListView.gridListControl == null) {
            this.gridListView.gridListControl.foveaEffect = false;
        }
    },
    addfoveaEffect: function () {
        if (!this.gridListView.gridListControl == null) {
            this.gridListView.gridListControl.foveaEffect = true;
        }
    },

    showErrorPopup: function (serverError) {
        Volt.log("[featuredListView.js @showErrorPopup");
        if (this.appInfoVMCollection.length > 0) {
            Volt.log("[featuredListView.js @list already exist, do not show error message");
        } else {
            this.widget.getChild('featured-list-no-content-' + this.featuredType).text = serverError.message;

            EventMediator.trigger('EVENT_CATEGORY_SET_FOCUS');
        }
        return;
    },

    showDisconnectPopup: function () {
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        return;
    },

    resetListImage: function () {
        Volt.log('[featuredListView.js @resetListImage]');
        if (Volt.DeviceInfoModel.get('highContrast')) {
            if (this.gridListView && this.gridListView.widget) {
                this.gridListView.widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/acc_focus.png'), -4, -4);
            }
        } else {
            if (this.gridListView && this.gridListView.widget) {
                this.gridListView.widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -4, -4);
            }
        }
    },


    onFocusGrid: function () {
        Volt.log('[featuredListView.js @onFocusGrid]');
        if (this.gridListView && this.gridListView.widget && this.gridListView.widget.custom.focusable == true) {

            Volt.Nav.focus(this.gridListView.widget);
        }

    }

});

/**
 * @name AppInfoView
 */
var AppInfoView = Volt.BaseView.extend({
    /** @lends AppInfoView.prototype */
    template: FeaturedListTemplate,
    bgmode: "LIGHT",
    downloadable: true,
    thumbnail: null,
    progressView: null,

    thumbListener: null, // Thumbnail Listener for color pick

    /**
     * initialize
     * @name AppInfoView
     * @constructs
     * @param  {Model} model VM correspond to this
     * @param  {string} type   featuredType
     */
    initialize: function (model, type) {
        this.VM = model;
        this.type = type;
    },

    bindListener: function () {
        this.listenTo(this.VM, 'change', this.renderChange);
        this.listenTo(this.VM, 'DESTROY_VIEW', this.remove);
        this.showProgressBar();
    },

    unbindListener: function () {
        this.stopListening();
        this.hideProgressBar();
    },

    /**
     * render this view
     * @method
     * @param  {number} index  rendering appInfoView's index
     * @param  {type} widget rendering appInfoView's widget
     */
    render: function (index, iThumbnail) {
        Volt.err('AppInfoView render : ');
        if (iThumbnail) {
            var self = this;
            this.thumbnail = iThumbnail;
            var data = this.VM.toJSON();
            var icon = data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT);
            var screenshot = data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT);

            if (screenshot) {
                this.thumbnail.setContentImage(screenshot);
                this.useDefaultImage = false;
            } else {
                this.thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                this.useDefaultImage = true;
            }
            this.thumbnail.setInformationIcon("icon1",icon);
            this.thumbnail.setInformationText("text1",data.title ? data.title : '');

            
            if (this.type == 'whatsNew') {
                this.thumbnail.setInformationText("text2",data.updated ? CommonFunctions.convertDate(data.updated.split('T')[0]) : '');
                this.thumbnail.setInformationText("text3",data.fileSize ? this.convertByte(data.fileSize) : '');
            } else {
                // MostPopular

                var ratings = data.gradeAvg ? (data.gradeAvg * 2) : 0;
                if (ratings == 0) {
                    this.thumbnail.setInformationText("text2",data.fileSize ? this.convertByte(data.fileSize) : '');
                    this.thumbnail.setInformationText("text3",'No Ratings');
                    this.thumbnail.setInformationRatingValue(0);
                    this.thumbnail.visualizeInformationRating(false);
                } else {
                    this.thumbnail.setInformationText("text2",data.fileSize ? this.convertByte(data.fileSize) : '');
                    this.thumbnail.setInformationText("text3",'');
                    this.thumbnail.setInformationRatingValue(ratings);
                    this.thumbnail.visualizeInformationRating(true);
                }
            }

            this.thumbListener = new ThumbnailListener;
            this.thumbListener.onImageReady = function (thumbnail, id, success) {
                thumbnail.border = {width:0, color: Volt.hexToRgb('#000000', 0)};
                if (success) {
                    thumbnail.timeId = Volt.setTimeout(function () {
                        if (self.useDefaultImage) {
                        } else {
                            var color = thumbnail.getInformationColorPicking();
                            var cc = HALOUtil.extractIconColor(color.r, color.g, color.b);
                        }

                        if (self.type !== 'whatsNew') {
                            if (cc == HALOUtil.CC_WHITE) {
                                thumbnail.setInformationRatingImage({
                                    onSrc: CommonFunctions.getRatingImage().ratingOnBkBuf,
                                    halfSrc: CommonFunctions.getRatingImage().ratingHalfBKBuf,
                                    offSrc: CommonFunctions.getRatingImage().ratingBgBuf,
                                });
                            }
                            var data = self.VM.toJSON();
                            var ratings = data.gradeAvg ? (data.gradeAvg * 2) : 0;
                            if (ratings == 0) {
                                thumbnail.visualizeInformationRating(false);
                            } else {
                                thumbnail.visualizeInformationRating(true);
                            }
                        }
                    }, 0);
                } else {
                    thumbnail.timeId = Volt.setTimeout(function () {
                        thumbnail.setContentImage(GridListTemplate.defaultScreenShot);
                        self.useDefaultImage = true;
                        thumbnail.timeId = null;
                    }, 0);
                }
            }
            this.thumbnail.addThumbnailListener(this.thumbListener);
            this.thumbnail.setDimBackgroundColor({
                r: 0,
                g: 0,
                b: 0,
                a: 153
            });
            this.thumbnail.dim(false);

            this.thumbnail.visualizeInformationIcon(false, 'icon2');

            if (this.type !== 'whatsNew') {
                this.thumbnail.visualizeInformationRating(false);
            }

            this.thumbnail.setProgressRange(0, 100);
            this.setWidget(this.thumbnail);
            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
            this.thumbnail.customSupportVoice = data.is_support_voice;

            this.setDownloadColorPicking(this.VM.get('isDownloaded'));
            this.bindListener();
        }
    },

    remove: function () {
        if (this.thumbnail) {
            this.thumbnail.removeThumbnailListener(this.thumbListener);
            this.unbindListener();

            if (this.thumbnail.timeId) {
                Volt.clearTimeout(this.thumbnail.timeId);
                this.thumbnail.timeId = null;
            }

            this.thumbnail = null;
            this.thumbListener = null;
        }
    },

    updateItemView: function (Thumbnail, data) {
        Volt.err('AppInfoView updateItemView : ');
        this.VM = data.model;
        this.hideProgressBar();
        if (Thumbnail) {
            var self = this;
            this.thumbnail = Thumbnail;

            var data = this.VM.toJSON();
            var icon = data.icon.replace("{w}", CommonDefines.ImageSize.PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.PNG_ICON_HEIGHT);
            var screenshot = data.screenshot.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT);

            if (screenshot) {
                this.thumbnail.setContentImage(screenshot);
                this.useDefaultImage = false;
            } else {
                this.thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                this.useDefaultImage = true;
            }
            this.thumbnail.setInformationIcon("icon1", icon);

            this.thumbnail.setInformationText("text1", data.title ? data.title : '');
            if (this.type == 'whatsNew') {
                this.thumbnail.setInformationText("text2", data.updated ? CommonFunctions.convertDate(data.updated.split('T')[0]) : '');
                this.thumbnail.setInformationText("text3", data.fileSize ? this.convertByte(data.fileSize) : '');
            } else {

                this.thumbnail.setInformationText("text2", data.fileSize ? this.convertByte(data.fileSize) : '');
                var ratings = data.gradeAvg ? (data.gradeAvg * 2) : 0;
                if (ratings == 0) {
                    this.thumbnail.setInformationText("text3", 'No Ratings');
                    this.thumbnail.visualizeInformationRating(false);
                } else {
                    this.thumbnail.setInformationRatingValue(ratings);
                    this.thumbnail.setInformationText("text3", '');
                    this.thumbnail.visualizeInformationRating(true);
                }
            }
            this.thumbnail.visualizeInformationIcon(false, 'icon2');

            this.thumbnail.customTitle = data.title || '';
            this.thumbnail.customType = this.type;
            this.thumbnail.customSupportVoice = data.is_support_voice;


            if (this.type !== 'whatsNew') {
                this.thumbnail.visualizeInformationRating(false);
            }
            this.setDownloadColorPicking(this.VM.get('isDownloaded'));
            this.bindListener();
        }
        this.resetProgressBar();
    },
    extendData: function (mustache, data) {
        return mustache;
    },

    setDownloadColorPicking: function (bFlag) {

        if (bFlag) {
            if (this.thumbnail) {
                this.thumbnail.visualizeInformationIcon(true, 'icon2');
            }
        } else {
            if (this.thumbnail) {
                this.thumbnail.visualizeInformationIcon(false, 'icon2');
            }
        }
    },
    /**
     * convert bytes mark
     * @method
     * @param  {number} value app size
     * @return {string}       converted size
     */
    convertByte: function (value) {

        if (value >= 1048576) {
            return parseFloat(value / 1048576).toFixed(2) + " " + Volt.i18n.t('SID_MB');
        } else if (value >= 1024) {
            return parseInt(value / 1024) + " " + Volt.i18n.t('SID_KB');
        } else {
            return parseInt(value) + " " + Volt.i18n.t('SID_BYTE');
        }
    },
    /**
     * callback func when changed.
     * @method
     * @param  {Model} changedModel changedModel
     */
    renderChange: function (changedModel) {
        Volt.err('AppInfoView renderChange : ');
        var key;
        for (key in changedModel.changed) {
            if (key == 'isDownloaded') {
                this.setDownloadColorPicking(changedModel.changed.isDownloaded);
            } else if (key == 'fileSize') {
                if (this.thumbnail) {
                    if (this.type == 'whatsNew') {
                        this.thumbnail.setInformationText("text3", this.convertByte(changedModel.changed.fileSize));
                    } else {
                        this.thumbnail.setInformationText("text2", this.convertByte(changedModel.changed.fileSize));
                    }
                }

            }
        }
    },

    events: {
        'NAV_BLUR': 'onBlur',
        'NAV_FOCUS': 'onFocus'
    },

    /**
     * Call when it is blurred
     * @method
     */
    onBlur: function () {

    },

    /**
     * Call when it is focused
     * @method
     */
    onFocus: function () {

    },

    /**
     * install
     * @method
     */
    installApp: function () {

        if (this.progressView == null) {
            this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }

        this.progressView.installApp();
    },

    cancelInstallApp: function () {
        // [TODO] When press Cancel button, cancal installing app.
        if (this.progressView == null) {
            this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }

        this.progressView.cancelInstallApp();
    },

    /**
     * show view
     * @method
     */
    showProgressBar: function () {
        try {
            if (this.progressView == null) {
                this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
            }

            this.progressView.updateThumbnail(this.thumbnail);
            this.progressView.show();
        } catch (e) {

        }

    },
    /**
     * hide view
     * @method
     */
    hideProgressBar: function () {

        if (this.progressView) {
            this.progressView.hideProgressBar();
            this.progressView.updateThumbnail(null);
        }
    },

    resetProgressBar: function () {
        if (!this.progressView) {
            this.progressView = new AppInfoProgressView(this.thumbnail, this.VM);
        } else {
            this.progressView.resetProgressBar(this.thumbnail, this.VM);
        }
        this.progressView.show();
    },
    /**
     * resume view
     * @method
     */
    resume: function () {},
    /**
     * pause view
     * @method
     */
    pause: function () {}

});

exports = {
    'listView': FeaturedListView,
    'appInfoView': AppInfoView
};
