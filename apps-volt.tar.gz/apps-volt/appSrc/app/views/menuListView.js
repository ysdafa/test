/** 
 * @author donghyun Lee (donghyun81.lee@samsung.com)
 * @fileoverview This module manages installation of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require("modules/underscore.js")._,
    voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js'),
    VoltJSON = Volt.require("modules/VoltJSON.js");

// Implements
var EventMediator = Volt.require('app/common/eventMediator.js'),
    MenuTemplate = Volt.require('app/templates/1080/menuTemplate.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js'),
    WinsetCategoryTab = Volt.require('modules/WinsetUIElement/winsetCategoryTab.js'),
    ServerAPI = Volt.require('app/common/serverAPI.js'),
    Models = Volt.require('app/models/models.js'),
    OverlayView = Volt.require('app/views/overlay-view.js');

var MENU_ANIM_DURATION = 200;

/**
 * @name MenuListView
 */
var MenuListView = Volt.BaseView.extend({
    /** @lends MenuListView.prototype */

    /**
     * Initialize MenuListView
     * @name MenuListView
     * @constructs
     */
    parent: null, // Parent View

    isFetching: false,
    categoryTabs: null, // Category Tab Control
    //bFirstChange: true, // Initial setting of CategoryTabs
    expandAnimation: null,
    shrinkAnimation: null,

    bAllowKeyDown: true,
    keyDownTimeId: null,

    initialize: function (options) {
        if (options) {
            this.parent = options.parent;
        }

        this.listenTo(EventMediator, 'START_EDIT_MODE', this.moveMyApps);
        this.listenTo(EventMediator, CommonDefines.Event.MOVE_FOCUS_MYAPPS, this.moveMyApps);
        this.listenTo(EventMediator, 'EVENT_CATEGORY_CHANGE_INDEX', this.changeIndex);
        this.listenTo(Models.menuVMCollection, 'reset', this.updateCategoryTabs);
        
        this.listenTo(EventMediator, 'EVENT_CATEGORY_SET_FOCUS', this.setFocus);
        this.listenTo(EventMediator, 'EVENT_CATEGORY_KILL_FOCUS', this.killFocus);

    },

    render: function () {
        Volt.log('[menuListView.js] render');

        this.setWidget(Volt.loadTemplate(MenuTemplate.categoryTab, null, this.parent.widget.getChild('main-category-container')));

        if (!this.categoryTabs) {
            this.initCategoryTabs();
            this.widget.addChild(this.categoryTabs);
        }

        this.updateCategoryTabs();

        this.fetch();

        this.widget.onKeyEvent = _.bind(this.onKeyEvent, this);

        //Volt.Nav.reload();
        return this;
    },

    onKeyEvent: function (keycode, type) {
        Volt.log('[menuListView.js @onKeyEvent] ' + Volt.getKeyName(keycode));
        switch (keycode) {
        case Volt.KEY_JOYSTICK_LEFT:
        case Volt.KEY_JOYSTICK_RIGHT:
            Volt.log('[menuListView.js @onKeyEvent] skip');
            return true;

        case Volt.KEY_JOYSTICK_DOWN:
            if (this.bAllowKeyDown) {
                return false;
            } else {
                Volt.log('[menuListView.js @onKeyEvent] skip');
                return true;
            }

        default:
            return false;
        }
    },

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    onFocus: function (widget) {
        Volt.log('[menuListView.js] onFocus');
        Volt.log('[menuListView.js] count is ' + this.categoryTabs.numberOfTab());
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS);
        var container = this.parent.widget.getChild('main-category-underbar-container');

        //container.animate('y', scene.height * 0.1, MENU_ANIM_DURATION);
        //this.categoryTabs.animate('y', -scene.height * 0.033333, MENU_ANIM_DURATION);
        //this.categoryTabs.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);
        if (this.expandAnimation) {
            this.expandAnimation.stop();
        }
        if (this.shrinkAnimation) {
            this.shrinkAnimation.stop(true);
        }
        (!this.expandAnimation) && (this.expandAnimation = new MultiObjectTransition());
        this.expandAnimation.setDuration(MENU_ANIM_DURATION);
        this.expandAnimation.AddObjectDestination(container, "y", Volt.height * 0.1);
        this.expandAnimation.AddObjectDestination(this.categoryTabs, "y", -Volt.height * 0.033333);
        this.expandAnimation.AddObjectDestination(this.categoryTabs, "size", {
            w: this.categoryTabs.width,
            h: Volt.height * 0.1
        });
        this.expandAnimation.play();

        this.categoryTabs.setFocus();

        CommonFunctions.voiceGuide(Models.menuVMCollection.at(this.categoryTabs.currentTabIndex()).get('tmpName') + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA'));
    },

    onBlur: function (widget) {
        Volt.log('[menuListView.js] onBlur');
        var container = this.parent.widget.getChild('main-category-underbar-container');
        if (!OverlayView.isLoading()) {
            //container.animate('y', scene.height * 0.133333, MENU_ANIM_DURATION);
            //this.categoryTabs.animate('y', 0, MENU_ANIM_DURATION);
            //this.categoryTabs.animate('height', scene.height * 0.066667, MENU_ANIM_DURATION);
            if (this.shrinkAnimation) {
                this.shrinkAnimation.stop();
            }
            if (this.expandAnimation) {
                this.expandAnimation.stop(true);
            }
            (!this.shrinkAnimation) && (this.shrinkAnimation = new MultiObjectTransition());
            this.shrinkAnimation.setDuration(MENU_ANIM_DURATION);
            this.shrinkAnimation.AddObjectDestination(container, "y", Volt.height * 0.133333);
            this.shrinkAnimation.AddObjectDestination(this.categoryTabs, "y", 0);
            this.shrinkAnimation.AddObjectDestination(this.categoryTabs, "size", {
                w: this.categoryTabs.width,
                h: Volt.height * 0.066667
            });
            this.shrinkAnimation.play();

            EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);
        }
    },

    setFocus: function() {
        Volt.Nav.setLastFocusedWidget(this.widget);
        Volt.Nav.focus(this.widget);
    },
    
    killFocus: function () {
        this.onBlur();
    },
    
    changeIndex: function (index) {
        //navigate my apps
        Volt.log('[MenuListView] changeIndex()');
        Volt.Nav.focus(null);
        Models.menuVMCollection.currentMenuIndex = index;
        this.categoryTabs.changeTab(index);
    },
    
    ////
    onChangeNetwork: function () {
        Volt.log('[categoriesView.js] onConnectNetwork');
        if (this.isFetching == false && Models.menuVMCollection.isExpand == false) {
            this.fetch();
        }
    },

    initCategoryTabs: function () {
        this.categoryTabs = new WinsetCategoryTab({
            style: WinsetCategoryTab.Categorytabtyle.Categorytab_Style_A,
            x: 0,
            y: 0,
            unFocusHighlightbarHeight: 2,
            focusHighlightbarHeight: Volt.height * 0.1,
            width: Volt.width,
            height: Volt.height * 0.066667,
        });

        var tabListener = new CategoryTabListener;

        tabListener.onTabChanged = function (ctab, index) {
            Volt.log('[menuListView.js] onTabChanged: index is ' + index);
            CommonFunctions.voiceGuide(Models.menuVMCollection.at(this.categoryTabs.currentTabIndex()).get('tmpName') + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA'));
            this.menuChanged(ctab, index);
        }.bind(this);
        this.categoryTabs.addCategoryTabListener(tabListener);


        var keyboardListener = new KeyboardListener;

        keyboardListener.onKeyPressed = function (actor, keyCode) {
            Volt.log('[menuListView.js @onKeyPressed] keyCode: ' + Volt.getKeyName(keyCode));
            if (keyCode == Volt.KEY_JOYSTICK_LEFT || keyCode == Volt.KEY_JOYSTICK_RIGHT) {
                this.bAllowKeyDown = false;

                if (this.keyDownTimeId) {
                    Volt.clearTimeout(this.keyDownTimeId);
                    this.keyDownTimeId = null;
                }

                this.keyDownTimeId = Volt.setTimeout(function () {
                    this.bAllowKeyDown = true;
                    this.keyDownTimeId = null;
                }.bind(this), 500);
            }
            if (keyCode == Volt.KEY_JOYSTICK_OK) {
                Volt.log('[menuListView.js    @trigger(CommonDefines.Event.EVENT_MAIN_GRID_FOCUS)   ]');
                EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_GRID_FOCUS);
            }
        }.bind(this);
        keyboardListener.onKeyReleased = function (actor, keyCode) {
            Volt.log('[menuListView.js @onKeyReleased]');
            if (keyCode == Volt.KEY_JOYSTICK_OK) {
                //Volt.log('[menuListView.js    @trigger(CommonDefines.Event.EVENT_MAIN_GRID_FOCUS)   ]');
                //EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_GRID_FOCUS);
            }
        };
        this.categoryTabs.addKeyboardListener(keyboardListener);
    },

    updateMenu: function () {
        Volt.log('[menuListView.js] updateMenu: index is ' + Models.menuVMCollection.nextMenuIndex);
        Models.menuVMCollection.setSwitchFlag(false);
        this.menuChanged(null, Models.menuVMCollection.nextMenuIndex);
    },

    menuChanged: function (ctab, index) {
        Volt.log('[menuListView.js] menuChanged: index is ' + index);

        //// To prevent callback when first time of tab change.
        // if (this.bFirstChange) {
        // this.bFirstChange = false;
        // return;
        // }

        if (true == Models.menuVMCollection.getSwitchFlag()) {
            Volt.log('[menuListView.js] menu is switching,please wait...');
            Models.menuVMCollection.nextMenuIndex = index;
            return;
        }
        var sRoute = Models.menuVMCollection.at(index).get('route'),
            sPageName = Models.menuVMCollection.at(index).get('pageName');

        if (Models.menuVMCollection.currentMenuIndex != index) {
            Models.menuVMCollection.currentMenuIndex = index;
            Models.menuVMCollection.nextMenuIndex = index;
            Models.menuVMCollection.setSwitchFlag(true);
            Volt.setTimeout(_.bind(this.updateMenu, this), 500);
            //cancel http request hide loading first
            //if(voltapi.rest.m_requestMap){
            //print("voltapi.rest.m_requestMap is " + JSON.stringify(voltapi.rest.m_requestMap));
            //}
            //EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

            Volt.KpiMapper.addEventLog('SELECTMENU', {
                d: {
                    sm: sPageName
                }
            });

            Backbone.history.navigate(sRoute, {
                trigger: true,
                replace: true
            });
        }
        //CommonFunctions.voiceGuide(Models.menuVMCollection.at(index).get('tmpName') + ' ' + Volt.i18n.t('SID_CATEGORY_KR_CA'));
    },

    updateCategoryTabs: function () {
        Volt.log('[menuListView.js] updateCategoryTabs');

        var i = 0;
        var n = this.categoryTabs.numberOfTab();
        Volt.log('[menuListView.js] updateCategoryTabs numberOfTab is ' + n);
        if (n > 0) {
            for (i = n - 1; i >= 3; i--) {
                Volt.log('[menuListView.js] i  ' + i);
                this.categoryTabs.removeTab(i);
            }
            for (var idx = 3; idx < Models.menuVMCollection.length; idx++) {
                if (Models.menuVMCollection.at(idx).get('isDefault')) {
                    Volt.log('[menuListView.js] addTab is ' + Models.menuVMCollection.at(idx).get('tmpName'));
                    this.categoryTabs.addTab(Models.menuVMCollection.at(idx).get('tmpName'));
                }
            }
            this.categoryTabs.changeTab(Models.menuVMCollection.currentMenuIndex);
            
            
        } else {
            for (var idx = 0; idx < Models.menuVMCollection.length; idx++) {
                if (Models.menuVMCollection.at(idx).get('isDefault')) {
                    Volt.log('[menuListView.js] addTab is ' + Models.menuVMCollection.at(idx).get('tmpName'));
                    this.categoryTabs.addTab(Models.menuVMCollection.at(idx).get('tmpName'));
                }
            }
            Volt.log('[menuListView.js] count is ' + this.categoryTabs.numberOfTab());
            this.categoryTabs.setTabSpliterSize(2, Volt.height * 0.02037, 3);
            this.categoryTabs.changeTab(1);
        }
    },

    fetch: function () {
        Volt.log('[categoriesView.js] fetch');

        if (!ServerAPI.isReady()) {
            Volt.log("[menuListView.js] WAS ready");
            this.listenToOnce(EventMediator, CommonDefines.Event.SERVERAPI_READY, this.fetch);
            return;
        }

        if (Volt.DeviceInfoModel.get('networksStatus') == 'OK') {

            this.isFetching = true;
            Q.all([
                Models.menuVMCollection.fetch()
            ])
                .then(_.bind(function () {
                    this.isFetching = false;
                }, this))
                .fail(_.bind(function () {
                    this.isFetching = false;
                }, this));

        } else {
//            this.listenToOnce(EventMediator, CommonDefines.Event.CONNECT_NETWORK, this.onConnectNetwork);
            this.listenToOnce(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS, this.onChangeNetwork);
        }
    },

    /**
     * Expand category area on focus
     */
    expand: function () {
        Volt.log('[MenuListView] expand()');
        return;
    },

    /**
     * Shrink category area on blur
     */
    shrink: function () {
        Volt.log('[MenuListView] shrink()');
        return;
    },

    /**
     * Show this view.
     * @method
     * @param  {object} param Parameters
     * @param  {enum} animationType Animation type to showing this view.
     * @return {deferred} Deferred promise return.
     */
    show: function (param, animationType) {
        var deferred = Q.defer();
        deferred.resolve();
        this.widget.show();

        return deferred.promise;
    },

    moveMyApps: function () {
        //navigate my apps
        Volt.log('[MenuListView] moveMyApps()');
        Volt.Nav.focus(null);
        this.categoryTabs.changeTab(0);
    },

    /**
     * hide this view.
     * @method
     * @param  {enum} animationType Animation type to hiding this view.
     * @return {deferred} Deferred promise return.
     */
    hide: function (animationType) {
        var deferred = Q.defer();
        deferred.resolve();
        this.widget.hide();

        return deferred.promise;
    },
});

exports = MenuListView;