/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module show app's detail information
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

////////////////////////////////////////////////////////////////////////////////
// REQUIRE MODULES
////////////////////////////////////////////////////////////////////////////////

//// Include Basic Modules
var Backbone = Volt.require("modules/backbone.js");
var _ = Volt.require("modules/underscore.js")._;
var VoltJSON = Volt.require("modules/VoltJSON.js");
var Q = Volt.require('modules/q.js');
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');

//// Include UI-Components Modules
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var WinsetScroll = Volt.require("modules/WinsetUIElement/winsetScroll.js");
var WinsetProgress = Volt.require('modules/WinsetUIElement/winsetProgress.js');
var WinsetToolTip = Volt.require('modules/WinsetUIElement/winsetToolTip.js');
//// Require Lib
var CommonTemplate = Volt.requireTemplate('common');
var CmButtonView = Volt.require('lib/views/cm-button-view.js');
//// Include View Models
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
var Models = Volt.require('app/models/models.js');
var DetailVM = Volt.require("app/models/detailVM.js");

//// Include Templates
var Template = Volt.require("app/templates/detail-template.js");

//// Include Common Views
var GridListView = Volt.require('app/views/gridListView.js');
var ProgressBarView = Volt.require('app/views/progressbarView.js');
var AppInfoProgressView = Volt.require("app/views/appInfoProgressView.js");

    //// Include Commons
var EventMediator = Volt.require('app/common/eventMediator.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');

var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var DownloadedAppsMgr = Volt.require("app/common/downloadedAppsMgr.js");
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var GridListTemplate = Volt.require('app/templates/grid-list-template.js');

var tvResolution = (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080;

var MAX_RATING_NUM = 5;

var Createflag = false;

var ismovie = false;

// Local Mediator for detail view only
var Mediator = Volt.Mediator();
/**
 * @name DetailView
 */
var DetailView = Volt.BaseView.extend({
    /** @lends DetailView.prototype */
    template: Template.container,

    pickedColor: null, //// Picked Color from Icon

    subViewMap: null, //// Map of Sub View Classes

    screenShotViewShow: false,

    lastFocus: null, // Last focused normal widget
    bMouseVisibility: false, // If mouse is visible
    bKeyboardActive: true, // If keyboard is active
    focusButtonId: '',
    /**
     * Initialize DetailView
     * @name DetailView
     * @constructs
     */
    initialize: function () {
        Volt.log("[DetailView.js] initialize");
        detailview = this;

        //// Init Map of Sub View Classes
        this.subViewMap = {
            AppInfo: AppInfoView,
            StorageInfo: StorageInfoView,
            Description: DescriptionView,
            Buttons: ButtonsView,
            Screenshots: ScreenshotsView,
            RelatedApps: RelatedAppsView,
        };
    },

    /**
     * To request server fetch
     * @method
     * @memberof DetailView
     * @param  {string}  viewInfo  Widget ID
     */
    show: function (viewInfo, animationType) {
        Volt.log("[DetailView.js] show(), viewInfo: " + JSON.stringify(viewInfo));
        CommonFunctions.forceDisableVoiceGuide(false);
        //// reset
        this.bKeyboardActive = true;
        this.lastFocus = null;
        this.bMouseVisibility = -1;
        this.focusButtonId = '';

        Volt.Nav.reset();

        //// If we have showed, return
        if (Createflag) {
            /***fix bug tempory**/
            return;
        }

        //// show apps panel, request from Volt UIFW
        Stage.show();
        // Load from template
        this.setWidget(Volt.loadTemplate(this.template, {
            highconstract: DeviceInfoModel.get('highContrast') || '0'
        }));

        //// Action s2: Set the flag
        Createflag = true;

        this.widget.show();
        this.widget._navOnKeyEvent = this.onKeyEvent.bind(this);

        // Only consider requested detail by SearchAll
        var bRequestedSearchAll = viewInfo && viewInfo.caller;
        DetailVM.setDefault(bRequestedSearchAll);

        Backbone.history.setCache('bDeepLink', viewInfo && viewInfo.caller);

        //// Action s3: Add Event Listeners and start listening
        this.addListeners();

        //// Action s4: Check network state and fetch data
        if (Volt.DeviceInfoModel.get('networksStatus') == 'OK') {

            var restHeaderStatus = Volt.DeviceInfoModel.get('restHeaderStatus');

            if (restHeaderStatus !== 1) {
                this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.msgBoxEvent, this);
                this.showFailRestHeaderPopup(restHeaderStatus);
                return;
            }
            EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING');

            if (Backbone.history.isHistoryBack) {
                if (!DetailVM.pullCachedData(viewInfo.id)) {
                    DetailVM.fetch(viewInfo.id);
                }
            } else {
                DetailVM.fetch(viewInfo.id);
            }
        } else {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        }

        Volt.Nav.setRoot(this.widget);
    },

    /**
     * When hide view, handle stop event listening and hided view
     * @method
     * @memberof DetailView
     */
    hide: function () {
        Volt.log("[DetailView.js] hide ");

        Volt.Nav.reset();
        this.remove();
    },

    /**
     * To request server fetch
     * @method
     * @memberof DetailView
     * @param  {string}  viewInfo  Widget ID
     */
    render: function () {
        Volt.log("[DetailView.js] render ");
    },

    /**
     * Destroy everything created in this view
     * @method
     * @memberof DetailView
     */
    remove: function () {
        Volt.log('[detail-view.js @remove]');
        try {
            //// Move focus out
            Volt.Nav.focus(null);

            // TODO: Check if we should cancel fetch in Action 4

            //// Action 3: Remove Event Listeners
            this.removeListeners();

            //// Action x: Remove View
            this.removeView();

            //// Action: Destroy this.widget
            this.widget.destroy();
            this.widget = null;

            // Action : Clear the flag
            Createflag = false;

        } catch (e) {
            Volt.log('[detail-view.js @remove] occured exception: ' + e);
        }
    },

    /**
     * Pause this view.
     * @method
     */
    pause: function () {
        Volt.log('[DetailView] pause');
        EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

        Volt.Nav.pause();
    },

    /**
     * When returned focus from popup, it reset focus.
     * @method
     * @memberof DetailView
     */
    resume: function () {
        Volt.log("[DetailView.js] resume ");

        var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
        var ispopup = (/popup/g).test(previousHistory);

        if (!ispopup) {
            Volt.Nav.resume();
        }
        this.widget.show();
        Volt.Nav.setRoot(this.widget);
        //add by lihao.zha, temporarily fix can not get VOLT_DEACTIVATE event (refer to DF141223-01431)
        if (Volt.Nav.getFocusedWidget() && Volt.Nav.getFocusedWidget().id == "download_button_widget") {
            var tempWidget = Volt.Nav.getFocusedWidget();
            Volt.Nav.focus(null);
            Volt.Nav.focus(tempWidget);
        }
        if (this.screenShotViewShow) {
            this.screenShotViewShow = false;
            if (CommonDefines.AppState.APP_STATE_DEACTIVATE == CommonFunctions.getAppState()) {
                //to update wzlastFocus of Nav
                Volt.Nav.pause();
                Volt.Nav.unblock();
            }
        }
    },

    onKeyEvent: function (keyCode, keyType) {
        if (keyType == Volt.EVENT_KEY_RELEASE) {
            return false;
        }
        switch (keyCode) {
        case Volt.KEY_RETURN:

            var descriptionView = this.Description;

            //// 1. Return from More Description
            if (descriptionView && descriptionView.onReturn()) {
                return true;
            }

            // Hide Tooltip first before navigate back to Main View
            EventMediator.trigger('EVENT_HIDE_TOOLTIP');

            if (Backbone.history.getCache('bDeepLink')) {
                Volt.log('Quit from Deep Link');
                if (1 == Backbone.history.getCount()) {
                    Volt.quit();
                } else {
                    Backbone.history.back();
                }
                return true;
            }

            // Check network before return to previous detail view
            if (Backbone.history.getCount() >= 2) {
                var beforeViewInfo = Backbone.history.location.history[Backbone.history.getCount() - 2];
                var strBefore = beforeViewInfo.split('/')[0];
                if (strBefore == "#detail" && Volt.DeviceInfoModel.get('networksStatus') != 'OK') {
                    CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                    return true;
                }
            }

            return false;

        default:
            // If keyboard is inactive and no current focus, stop Key Event Process Flow
            if (this.bKeyboardActive || Volt.Nav.getCurrentFocus()) {
                return false;
            } else {
                return true;
            }
            break;
        }

        return true;
    },

    addListeners: function () {
        Volt.log('[DetailView]');

        this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.dim);

        this.listenTo(DetailVM, 'change:id', this.renderView);
        this.listenTo(DetailVM, 'error', this.showErrorPopup);

        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_MORE_BTN', this.hideGridList);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_CLOSE_BTN', this.showGridList);

        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_NETWORK_STATUS, this.onNetworkStatus);

        this.listenTo(EventMediator, 'DETAIL_LAUNCH_APP', this.startLaunch);
        this.listenTo(EventMediator, 'COMMON_POPUP_KEY_RETURN_RELEASE', this.cancelLaunch);

        this.listenTo(EventMediator, 'EVENT_DETAIL_SET_COLORPICK', this.setColorPick);

        //// Show and Hide Tooltip from Sub View 
        this.listenTo(EventMediator, 'EVENT_SHOW_TOOLTIP', this.showToolTip);
        this.listenTo(EventMediator, 'EVENT_HIDE_TOOLTIP', this.hideToolTip);

        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onChangeCursor);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_FOCUS_ZOOM, this.resetListImage);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_HIGH_CONTRAST, this.resetListImage);

        //// Use Mediator instead of EventMediator to reduce coupling
        this.listenTo(Mediator, 'EVENT_STORE_FOCUS', this.onStoreFocus);
        this.listenTo(Mediator, 'EVENT_RESTORE_FOCUS', this.onRestoreFocus);
    },

    removeListeners: function () {
        Volt.log('[DetailView]');
        // @xj-2014/12/20: Stop listening to prevent unexpected event-processing
        this.stopListening();

        // @xj-2014/12/22: Why we should stop listening here? Where is the listening started
        DetailVM.stopListeningEvent();
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    /**
     * Taken data from server then called this to render view
     * @method
     * @memberof DetailView
     */
    renderView: function () {
        Volt.log("[DetailView.js] renderView ");

        //this.hideLoading();
        EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

        //hide winset BG color when show loading, reset winsetBG color when loading hide
        var highContrast = DeviceInfoModel.get('highContrast');
        if (!highContrast) {
            this.widget.getDescendant('detail-title-area').color = (Volt.hexToRgb('#1f2b3d'));
            this.widget.getDescendant('detail-list-area').getChild(0).color = (Volt.hexToRgb('#1f2b3d'));
        } else {
            this.widget.getDescendant('detail-title-area').color = (Volt.hexToRgb('#ffffff', 6));
            this.widget.getDescendant('detail-list-area').getChild(0).color = (Volt.hexToRgb('#ffffff', 10));
        }

        this.renderSubView('AppInfo');
        this.renderSubView('StorageInfo');
        this.renderSubView('Description');
        this.renderSubView('Buttons');
        this.renderSubView('Screenshots');
        this.renderSubView('RelatedApps');
        
        // Rules
        if (this['Description'] && this['Description'].moreButtonParent) {
            if (this['Screenshots'] && this['Screenshots'].widget) {
                Volt.Nav.setNextItemRule(this.Description.moreButtonParent, 'down', this['Screenshots'].widget);
            } else if (this.Buttons && this.Buttons.ratingBtnBG) {
                Volt.Nav.setNextItemRule(this.Description.moreButtonParent, 'down', this.Buttons.ratingBtnBG);
            }
        }

        // Set init focus
        if (!Backbone.history.isHistoryBack) {
            EventMediator.trigger('EVENT_DETAIL_SET_BUTTON_FOCUS', true);
        }
    },
    /**
     * Remove the view, clear all content inside this view
     */
    removeView: function () {

        // Remove rule to release reference
        if (this.Description) {
            Volt.Nav.clearNextItemRule(this.Description.moreButtonParent);
        }
        
        this.removeSubView('AppInfo');
        this.removeSubView('StorageInfo');
        this.removeSubView('Description');
        this.removeSubView('Buttons');
        this.removeSubView('Screenshots');
        this.removeSubView('RelatedApps');

        this.widget.hide();
        
        // @xiaojun.wang|20150326: Destroy Listeners of Winset UI Element
        CommonFunctions.destroyListener(this.widget, ['detail-background-colorpick', 'detail-title-area', 'detail-background-list']);

        //// TODO: hideLoading will call resume, this will cause 'access destroyed error'
        EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
    },

    /**
     * Render a sub view
     * @method
     * @memberof DetailView
     */
    renderSubView: function (subViewName) {
        Volt.log("@renderSubView: subViewName: " + subViewName);

        var SubView = this.subViewMap[subViewName];
        if (!SubView) {
            // Not a valid Sub View Name
            return;
        }

        // Create if not exists.
        if (!this[subViewName]) {
            // Unified interface to create a sub view.
            this[subViewName] = new SubView({
                parent: this
            }).render();
        }
    },
    /**
     * Destroy a Sub View
     */
    removeSubView: function (subViewName) {
        Volt.log("@removeSubView: subViewName: " + subViewName + this[subViewName]);

        if (this[subViewName]) {
            // Unified interface to remove a sub view.
            this[subViewName].remove();
            this[subViewName] = null;
        }
    },

    ////////////////////////////////////
    showFailRestHeaderPopup: function (errCode) {
        Volt.err('[DetailView.js] showFailRestHeaderPopup:' + errCode);
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR, {
            code: errCode
        });
    },

    msgBoxEvent: function (data) {
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR:
                Volt.log('[DetailView.js] MSGBOX_TYPE_SETHEADER_ERROR, exit apps panel, apps panel will hide in background');
                Volt.exit();
                break;
            default:
                break;
            }
        }
    },

    startLaunch: function () {
        Volt.log('[DetailView] startLaunch');

        if (!this.bLaunching) {
            this.bLaunching = true;
        }

        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS, this.failLaunch);
        this.listenTo(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE, this.failLaunch);
    },

    cancelLaunch: function () {
        Volt.log('[DetailView] cancelLaunch');
        var sLaunchedAppId = AppInstallMgr.getLaunchedAppID();

        if (this.bLaunching) {
            AppInstallMgr.terminateApp(sLaunchedAppId);
        }
    },

    failLaunch: function () {
        Volt.log('[DetailView] failLaunch');
        this.bLaunching = false;

        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NOT_EXIST);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_TIMEOUT);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_EMP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_CAPH_APP);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_NETWORK);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_FAIL_OTHERS);
        this.stopListening(EventMediator, CommonDefines.Event.LAUNCHER_TERMINATE);
    },


    /**
     * Set colorPick info to apply color
     * @method
     * @memberof DetailView
     */
    setColorPick: function (colorPick) {
        Volt.log(JSON.stringify(colorPick));
        try {
            var highContrast = DeviceInfoModel.get('highContrast');
            Volt.log('[detailView] highContrast  : ' + highContrast);
            Volt.log('[detailView] colorPick  : ' + colorPick);
            if (colorPick) {
                Volt.log('[detailView] colorPick  : ' + colorPick.r + '  ' + colorPick.g + '  ' + colorPick.b);
                this.widget.color = {
                    r: colorPick.r,
                    g: colorPick.g,
                    b: colorPick.b,
                    a: 255
                };
                this.widget.getDescendant('detail-thumb-area').getDescendant('thumb-area').color = {
                    r: colorPick.r,
                    g: colorPick.g,
                    b: colorPick.b,
                    a: 255
                };

                if (!highContrast) {
                    this.widget.getChild('detail-background-colorpick').color = Volt.hexToRgb('#000000', 30);
                    this.widget.getChild('detail-title-area').color = Volt.hexToRgb('#000000', 8);
                    this.widget.getChild('detail-list-area').getChild(0).color = Volt.hexToRgb('#000000', 8);
                }

                var color = {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 64
                };
                this.widget.getChild('detail-background-colorpick').setBackgroundColor(color);
                this.widget.getChild('detail-title-area').setBackgroundColor({
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 20.4
                });
                this.widget.getChild('detail-list-area').getChild(0).setBackgroundColor({
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 20.4
                });
            } 
        } catch (e) {
            Volt.log('[detailView] setColorPick(), occured exception: ' + e);
        }
    },

    /**
     * Hide related apps area
     * @method
     * @memberof DetailView
     */
    hideGridList: function () {
        this['Screenshots'] && this['Screenshots'].hide();
        this['RelatedApps'] && this['RelatedApps'].hide();
    },

    /**
     * Show related apps area
     * @method
     * @memberof DetailView
     */
    showGridList: function () {
        this['Screenshots'] && this['Screenshots'].show();
        this['RelatedApps'] && this['RelatedApps'].show();
    },

    /**
     * Destory this view's widget and release memory.
     * @method
     * @memberof DetailView
     */
    destroy: function (widget) {
        Volt.log("[DetailView.js] destroy");
        if (!widget) return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = 0; i < nChildLength; i++) {
                this.destroy(widget.getChild(i));
            }
        }
        widget.id = '';
        delete widget;
        widget = null;
    },

    showErrorPopup: function (serverError) {
        Volt.log("[DetailView.js] showErrorPopup");

        //this.hideLoading();
        EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

        if (serverError.code == 'AS666') {
            //var networkPopup = new MsgPopupView({type: CommonDefines.Popup.TYPE_NETWORK});
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
        } else {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE, serverError);
        }
        return;
    },

    onNetworkStatus: function () {
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            //CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);//when network disconnect,do not show popup
        }
    },

    dim: function () {
        Volt.log('[DetailView] dim');
        if (!Volt.Nav.getLastFocusedWidget() && this.lastFocus) {
            Volt.Nav.setLastFocusedWidget(this.lastFocus);
        }
    },

    showToolTip: function (widget) {
        if (!(widget && widget.getAbsolutePosition)) {
            return;
        }

        var absolutePosition = widget.getAbsolutePosition();
        var text = '';
        if (widget && widget.id == 'rating_button_widget') {
            text = Volt.i18n.t('TV_SID_RATING_POINT');
        } else if (widget && widget.id == 'detail-more-button') {
            text = Volt.i18n.t('COM_TV_SID_MORE');
        } else if (widget && widget.id == 'detail-return-button') {
            text = Volt.i18n.t('COM_SID_RETURN');
        } else if (widget && widget.id == 'detail-exit-button') {
            text = Volt.i18n.t('SID_EXIT');
        }
        if (text == '') {
            Volt.log("[detailView.js] showtooltip error, text is empty");
            return;
        }
        var mustache = {
            x: absolutePosition.x + widget.width / 2 - Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) / 2 - Volt.width * 0.0078125,
            y: absolutePosition.y + widget.height,
            w: Volt.getTextWidth({
                text: text,
                font: (Volt.APPS720P) ? "SVD Light 20px" : "SVD Light 30px"
            }) + Volt.width * 0.015625,
            style: WinsetToolTip.TooltipStyle.Tooltip_Tail_Up,
            nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
            text: text,
            tailPostion: "center"
        };
        if (mustache.x + mustache.w > Volt.width) {
            mustache.x = absolutePosition.x + widget.width / 2 + Volt.width * 0.0109375 - mustache.w;
            mustache.tailPostion = "end";
        } else if (mustache.x < 0) {
            mustache.x = absolutePosition.x + widget.width / 2 - Volt.width * 0.0109375;
            mustache.tailPostion = "start";
        }

        if (this.toolTip) {
            this.hideToolTip();
        }
        this.toolTip = Volt.loadTemplate(Template.toolTip, mustache);
        this.toolTip.setText(text);
        this.toolTip.show();
        this.startToolTipTimeOut(); //set timeout to 3s   DF141120-01530,add by yangpei 20141112

    },
    hideToolTip: function () {
        Volt.log('hideToolTip');
        if (this.toolTip) {
            this.toolTip.destroy();
            this.toolTip = null;
        }
        this.clearToolTipTimeOut();
    },

    startToolTipTimeOut: function () {
        this.clearToolTipTimeOut();
        this.timeId = Volt.setTimeout(_.bind(this.hideToolTip, this), 2000);
    },

    clearToolTipTimeOut: function () {
        if (this.timeId) {
            Volt.clearTimeout(this.timeId);
            this.timeId = null;
        }
    },

    onStoreFocus: function () {
        focus = Volt.Nav.getCurrentFocus();

        this.bKeyboardActive = false;

        if (focus) {
            this.lastFocus = focus;
            Volt.Nav.focus(null);
        }
        Volt.log('[detail-view.js @onStoreFocus]' + Volt.getWidgetHierarchy(this.lastFocus));
    },

    onRestoreFocus: function () {
        Volt.log('[detail-view.js @onRestoreFocus] lastFocus:' + Volt.getWidgetHierarchy(this.lastFocus));
        Volt.log('[detail-view.js @onRestoreFocus] Current Focus:' + Volt.getWidgetHierarchy(Volt.Nav.getCurrentFocus()));
        if (this.lastFocus && !Volt.Nav.getCurrentFocus()) {
            Volt.Nav.focus(this.lastFocus);
        }
        this.bKeyboardActive = true;
        this.lastFocus = null;
    },

    onChangeCursor: function (visible) {

        if (this.bMouseVisibility == visible) {
            return;
        }

        Volt.log('[detail-view.js @onChangeCursor] visible: ' + visible);

        this.bMouseVisibility = visible;

        if (this['AppInfo']) {
            this['AppInfo'].onChangeCursor(visible);
        }

        if (!visible) {
            this.onRestoreFocus();
        }
    },

    resetListImage: function () {
        Volt.log('[detail-view.js @resetListImage]');
        if (Volt.DeviceInfoModel.get('highContrast')) {
            if (this.gridListView && this.gridListView.widget) {
                this.gridListView.widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/acc_focus.png'), -4, -4);
            }
            if (this['Screenshots'] && this['Screenshots'].widget) {
                this['Screenshots'].widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/acc_focus.png'), -4, -4);
            }
        } else {
            if (this.gridListView && this.gridListView.widget) {
                this.gridListView.widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -4, -4);
            }
            if (this['Screenshots'] && this['Screenshots'].widget) {
                this['Screenshots'].widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -4, -4);
            }
        }
    }

});

/**
 * @name AppInfoView
 */
//var AppInfoView = Volt.BaseView.extend({
var AppInfoView = Backbone.View.extend({
    parent: null, // Parent View of this view

    // Return Button for Mouse
    returnButton: null,
    exitButton: null,

    mouseListener: null,

    bActive: true, // Whether the button is enabled to click

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////

    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render static widgets
     * Render both left side thumb area and right side description of app
     * @method
     * @memberof DetailView
     */
    render: function () {
        Volt.log("[detail-view.js ::AppInfoView @render]");

        var parentWidget = this.parent.widget;

        //// Get 3 sub areas
        var titleArea = parentWidget.getDescendant('detail-title-area');
        var thumbArea = parentWidget.getDescendant('detail-thumb-area');
        var appInfoArea = parentWidget.getDescendant('detail-appInfo-area');


        //// Render Title
        Volt.loadTemplate(Template.title, {
            title: DetailVM.get('title')
        }, titleArea);

        // Buttons in the header
        this.returnButton = titleArea.getDescendant('detail-return-button');
        this.exitButton = titleArea.getDescendant('detail-exit-button');
        CmButtonView.render(this.returnButton);
        CmButtonView.render(this.exitButton);

        //// Update View according to Cursor state
        this.onChangeCursor(Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE));

        //// Render Thumbnail
        var thumb = Volt.loadTemplate(Template.ThumbArea, {
            thumbnail: DetailVM.get('icon').replace("{w}", CommonDefines.ImageSize.DETAIL_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.DETAIL_ICON_HEIGHT)
        }, thumbArea);

        //add by lihao.zha@20150222, fix DF150209-02266
        Volt.log("[detail-view.js] Volt.DeviceInfoModel.getLanguageCode = " + Volt.DeviceInfoModel.getLanguageCode());
        if (Volt.DeviceInfoModel.getLanguageCode() == 'my' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'kn' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'ml' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'tu' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'bn' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'gu' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'mai' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'ks' ||
            Volt.DeviceInfoModel.getLanguageCode() == 'ar') {
            thumb.getChild(1).lineSpacing = 6;
        }

        //// Update Color Pick
        this.getIconColorPick(thumb.getChild(0));

        //// Render AppInfo

        //'{{categoryname}} **** {{avgRating}}'
        //'Free | Rating: {{rated}} | Size: {{filesize}} | Updated: {{updated}}'
        //' Version {{version}} | Languages: {{language}}',
        var nAvgRating = Number(DetailVM.get('gradeAvg')).toFixed(1);
        var strInstalled = ''; //'.Ver'+strInstalledVerion
        var strInstalledVerion = '';
        var strEmail = '';
        var strVersion = '';
        if (DetailVM.get('isDownloaded')) {
            strInstalledVerion = DetailVM.get('installedVersion') + ' ' + Volt.i18n.t('TV_SID_INSTALLED');
            strInstalled = "(" + Volt.i18n.t('TV_SID_MIX_VER_ABBR').replace('<<A>>', strInstalledVerion) + ")";
        }

        if (DetailVM.get('contact')) {
            strEmail = '(' + DetailVM.get('contact') + ')';
        }
        strVersion = Volt.i18n.t('TV_SID_MIX_VER_ABBR').replace('<<A>>', DetailVM.get('version'));
        var appInfoTemplate = Volt.loadTemplate(Template.appInfo, {
            avgRating: nAvgRating,
            size: CommonFunctions.getFormattedSize(DetailVM.get('fileSize', false)),
            updated: DetailVM.convertDate(DetailVM.get('updated').slice(0, 10)),
            installed: strInstalled,
            developer: DetailVM.get('vendor') + strEmail,
            rated: DetailVM.convertRated(DetailVM.get('rated')),
            version: strVersion,
            language: DetailVM.get('titleLangDesc'),
            category: DetailVM.get('category'),
        }, appInfoArea);



        this.renderInfoText(appInfoTemplate);
        //// Render Stars
        var srcStarOn = Volt.getMultiResImage('common/dp_like_star_on.png');
        var srcStarOff = Volt.getMultiResImage('common/dp_like_star_off.png');
        var srcStarHalf = Volt.getMultiResImage('common/dp_like_star_half.png');

        var integerRating = Math.floor(nAvgRating);
        var pointRating = nAvgRating - integerRating;
        var nFirstLine1 = appInfoTemplate.getChild('detail-description-firstLine1');
        var nFirstLine2 = appInfoTemplate.getChild('detail-description-firstLine2');
        for (var i = 0; i < MAX_RATING_NUM; i++) {
            var starUrl = '';
            if (i < integerRating) {
                starUrl = srcStarOn;
            } else {
                if (i == integerRating && pointRating >= 0.5) {
                    starUrl = srcStarHalf;
                } else {
                    starUrl = srcStarOff;
                }
            }
            Template.contentStar.y = (Volt.height * 0.043519 -  Template.contentStar.height)/2;
            if (Volt.APPS_REVERSE) {
                Template.contentStar.x = Volt.dimmensionWidth * 0.015625 * (4 - i)+nFirstLine1.width +Volt.dimmensionWidth * 0.009896 ;
            } else {
                Template.contentStar.x = Volt.dimmensionWidth * 0.015625 * i+nFirstLine1.width +Volt.dimmensionWidth * 0.009896 ;
            }
            Volt.loadTemplate(Template.contentStar, {
                imageUrl: starUrl
            }, appInfoArea);
        }
        nFirstLine2.x = 5 * Volt.dimmensionWidth * 0.015625+nFirstLine1.width +Volt.dimmensionWidth * 0.009896;
        //// Add Listeners
        // After we showed, we can response to listeners
        this.addListeners();

        return this;
    },
    
    remove: function () {
        Volt.log('[detail-view.js ::AppInfoView @remove]');

        //// Remove Listeners Here
        this.removeListeners();

        this.returnButton = null;
        this.exitButton = null;
        
        this.parent = null;
        this.widget = null;
    },

    //// Add Event Listeners
    addListeners: function () {
        Volt.log('[AppInfoView]');

        var mouseListener = this.mouseListener = new MouseListener;

        mouseListener.onMousePointerIn = function (actor, event) {
            Volt.log('[AppInfoView @onMousePointerIn] actor: ' + actor.id);
            EventMediator.trigger('EVENT_STORE_FOCUS');
            EventMediator.trigger('EVENT_SHOW_TOOLTIP', actor);
            //actor.setFocus();
        };
        mouseListener.onMousePointerOut = function (actor, event) {
            Volt.log('[AppInfoView @onMousePointerOut] actor: ' + actor.id);
            EventMediator.trigger('EVENT_HIDE_TOOLTIP');
        };
        mouseListener.onMouseButtonReleased = function (actor, event) {
            Volt.log('[AppInfoView @onMouseButtonReleased] actor: ' + actor.id + '  bActive: ' + this.bActive);

            if (this.bActive) {
                this.bActive = false;

                Volt.setTimeout(function () {
                    this.bActive = true;
                }.bind(this), CommonTemplate.DRUATION_ACTIVE_INTERVAL);

                Volt.setTimeout(function () {
                    if (actor.id == 'detail-return-button') {
                        //// Fix Bug of DF141224-01332:
                        //// [ST5][Hawk-P][AppStore][Detail New] Mouse, B detail view,press more, then press Return with mouse, it should return to B
                        Volt.onKeyEvent(Volt.KEY_RETURN, Volt.EVENT_KEY_PRESS);
                    } else if (actor.id == 'detail-exit-button') {
                        // Quit Service when click close
                        //Volt.quit();
                        Volt.onKeyEvent(Volt.KEY_EXIT, Volt.EVENT_KEY_PRESS);
                    }
                }, 1);
            }
        }.bind(this);

        this.returnButton.addMouseListener(mouseListener);
        this.exitButton.addMouseListener(mouseListener);
        
        this.listenTo(DetailVM, 'change:fileSize', this.onFileSizeChange);
    },

    // Remove Event Listeners
    removeListeners: function () {
        Volt.log('[AppInfoView @removeListeners]');

        if (this.mouseListener) {
            this.returnButton && this.returnButton.removeMouseListener(this.mouseListener);
            this.exitButton && this.exitButton.removeMouseListener(this.mouseListener);
            this.mouseListener.destroy();
            this.mouseListener = null;
        }
        
        this.stopListening();
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    
    renderInfoText: function (appInfoTemplate) {
        var nSecondLine1 = appInfoTemplate.getChild('detail-description-secondLine1');
        var nSecondLineBar1 = appInfoTemplate.getChild('detail-description-secondLine_bar1');
        var nSecondLine2 = appInfoTemplate.getChild('detail-description-secondLine2');
        var nSecondLine3 = appInfoTemplate.getChild('detail-description-secondLine3');
        var nSecondLineBar2 = appInfoTemplate.getChild('detail-description-secondLine_bar2');
        var nSecondLine4 = appInfoTemplate.getChild('detail-description-secondLine4');
        var nSecondLineBar3 = appInfoTemplate.getChild('detail-description-secondLine_bar3');
        var nSecondLine5 = appInfoTemplate.getChild('detail-description-secondLine5');
        var nThirdLine1 = appInfoTemplate.getChild('detail-description-thirdLine1');
        var nThirdLineBar1 = appInfoTemplate.getChild('detail-description-thirdLine_bar1');
        var nThirdLine2 = appInfoTemplate.getChild('detail-description-thirdLine2');
        var nThirdLine3 = appInfoTemplate.getChild('detail-description-thirdLine3');
        var nForthLine1 = appInfoTemplate.getChild('detail-description-forthLine1');
        var nForthLineicon1 = appInfoTemplate.getChild('detail-description-forthLineIcon1');
        var nForthLine2 = appInfoTemplate.getChild('detail-description-forthLine2');
        var nForthLineBar1 = appInfoTemplate.getChild('detail-description-forthLine_bar1');
        var nForthLineicon2 = appInfoTemplate.getChild('detail-description-forthLineIcon2');      
        var nForthLine3 = appInfoTemplate.getChild('detail-description-forthLine3');        
        nSecondLineBar1.x = nSecondLine1.width + Volt.dimmensionWidth * 0.009375;
        nSecondLine2.x = nSecondLineBar1.x + Volt.dimmensionWidth * 0.009375 + Volt.dimmensionWidth * 0.000521;
        var nImageWidth = nSecondLine2.width + nSecondLine2.x;
        if (DetailVM.get('ratedIcon')) {
            // Add to set image of rate for Brazil
            var ratedIcon = appInfoTemplate.getChild('detail-description-secondLineIcon');
            ratedIcon.x = nSecondLine2.width + nSecondLine2.x + Volt.dimmensionWidth * 0.003646;
            nImageWidth = ratedIcon.x + ratedIcon.width + Volt.dimmensionWidth * 0.003646;
            ratedIcon.src = DetailVM.get('ratedIcon');
        }
        nSecondLine3.x = nImageWidth;
        nSecondLineBar2.x = nSecondLine3.x + nSecondLine3.width + Volt.dimmensionWidth * 0.009375;
        nSecondLine4.x = nSecondLineBar2.x + nSecondLineBar2.width + Volt.dimmensionWidth * 0.009375;
        nSecondLineBar3.x = nSecondLine4.x + nSecondLine4.width + Volt.dimmensionWidth * 0.009375;
        nSecondLine5.x = nSecondLineBar3.x + nSecondLineBar3.width + Volt.dimmensionWidth * 0.009375;
        nThirdLineBar1.x = nThirdLine1.x + nThirdLine1.width + Volt.dimmensionWidth * 0.009375;
        nThirdLine2.x = nThirdLineBar1.x + nThirdLineBar1.width + Volt.dimmensionWidth * 0.009375;
        nThirdLine3.x = nThirdLine2.x + nThirdLine2.width;
        if (DetailVM.get('pointer') == "true")
        {
            nForthLineicon1.x = nForthLine1.x + nForthLine1.width + Volt.dimmensionWidth * 0.003646;
            nForthLineicon1.src = Volt.getRemoteUrl('images/1080/common/apps_icon_cont_pointer.png');
            nForthLine2.x = nForthLineicon1.x + nForthLineicon1.width + Volt.dimmensionWidth *0.004167;
            nForthLine2.text = Volt.i18n.t('TV_SID_POINTER_AVAILABLE');
            if (DetailVM.get('gesture') == "true")
            {
                nForthLineBar1.x = nForthLine2.x + nForthLine2.width+ Volt.dimmensionWidth * 0.009375;
                nForthLineBar1.color = Volt.hexToRgb('#ffffff', 20);
                nForthLineicon2.x = nForthLineBar1.x + nForthLineBar1.width + Volt.dimmensionWidth * 0.007813;
                nForthLineicon2.src = Volt.getRemoteUrl('images/1080/common/apps_icon_cont_gesture.png');
                nForthLine3.x = nForthLineicon2.x + nForthLineicon2.width + Volt.dimmensionWidth *0.004167;
                nForthLine3.text = Volt.i18n.t('TV_SID_GESTURE_AVAILABLE');                
            }
        }
        else if (DetailVM.get('gesture') == "true")
        {
            nForthLineicon1.x = nForthLine1.x + nForthLine1.width + Volt.dimmensionWidth * 0.003646;
            nForthLineicon1.src = Volt.getRemoteUrl('images/1080/common/apps_icon_cont_gesture.png');
            nForthLine2.x = nForthLineicon1.x + nForthLineicon1.width + Volt.dimmensionWidth *0.004167;
            nForthLine2.text = Volt.i18n.t('TV_SID_GESTURE_AVAILABLE');
            
        }
        else {
            nForthLine1.text = "";
        }
    },
    
    // Invoked when Cusor State changes
    onChangeCursor: function (visible) {
        Volt.log('[AppInfoView] visible: ' + visible);
        // Add this if to prevent the ODD invoke after stopListening
        if (this.returnButton) {
            if (visible) {
                this.returnButton.show();
                this.exitButton.show();
            } else {
                this.returnButton.hide();
                this.exitButton.hide();
            }
        }
    },

    getIconColorPick: function (imageWidget) {
        Volt.log("[AppInfoView]");

        if (imageWidget) {
            var pickedColor = {};
            imageWidget.onReady = function (success) {
                if (success) {
                    Volt.err('[detail-view.js] getIconColorPick()');
                    imageWidget.show();
                    var colorPicking = imageWidget.getColorPicking(5);
                    if (colorPicking.success && colorPicking.color) {
                        pickedColor = colorPicking.color;
                        pickedColor.a = 255;
                        EventMediator.trigger('EVENT_DETAIL_SET_COLORPICK', pickedColor);
                        return;
                    }
                }
                EventMediator.trigger('EVENT_DETAIL_SET_COLORPICK', null);
            };
        } else {
            Volt.err("[detail-view.js] getIconColorPick(), Not exist imageWidget ");
            EventMediator.trigger('EVENT_DETAIL_SET_COLORPICK', null);
        }
    },
    
    onFileSizeChange: function (model, value) {
        Volt.log('[detail-view.js @onFileSizeChange] fileSize:' + value);
        
        var wzAppInfo = this.parent.widget.getDescendant('detail-appInfo-area').getChild(0);
        
        var nSecondLine4 = wzAppInfo.getChild('detail-description-secondLine4');
        var nSecondLineBar3 = wzAppInfo.getChild('detail-description-secondLine_bar3');
        var nSecondLine5 = wzAppInfo.getChild('detail-description-secondLine5');
        var updateSize = CommonFunctions.getFormattedSize(value);
        nSecondLine4.text = Volt.i18n.t('COM_BDP_SID_HTS_SPKR_SIZE_TEXT') + ": " + updateSize;
        nSecondLineBar3.x = nSecondLine4.x + nSecondLine4.width + Volt.dimmensionWidth * 0.009375;
        nSecondLine5.x = nSecondLineBar3.x + nSecondLineBar3.width + Volt.dimmensionWidth * 0.009375;
    },
});
/**
 * @name StorageView
 */
var StorageInfoView = Volt.BaseView.extend({
    /** @lends DetailView.prototype */
    parent: null,

    //// Widgets inside this sub view
    allMemoryText: null,
    usedMemoryText: null,
    availableMemoryText: null,
    allMemoryValueText: null,
    usedMemoryValueText: null,
    availableMemoryValueText: null,
    
    storageProgressbar: null,

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////

    /**
     * Initialize StorageView to register event
     * @name StorageView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render ProgressBar to show local memory
     * @method
     * @memberof StorageView
     */
    render: function () {
        Volt.log("[detail-view.js @StorageInfoView @renderStorageInfo]");

        var container = this.parent.widget.getDescendant('detail-storage-area');

        var LocalMemory = DetailVM.get('storageInfo');
        var widget = Volt.loadTemplate(Template.storage, null, container, false);

        this.allMemoryText = widget.getDescendant('storage-info-text-all');
        this.usedMemoryText = widget.getDescendant('storage-info-text-used');
        this.availableMemoryText = widget.getDescendant('storage-info-text-available');
        this.allMemoryValueText = widget.getDescendant('storage-info-text-all-value');
        this.usedMemoryValueText = widget.getDescendant('storage-info-text-used-value');
        this.availableMemoryValueText = widget.getDescendant('storage-info-text-available-value');

        ////
        var mustache = {
            nProgressStyle: WinsetProgress.ProgressStyle.Progress_Style_A,
            nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
        };

        this.storageProgressbar = Volt.loadTemplate(Template.storageProgressBar, mustache, widget.getDescendant('storage-info-progress-bg'));

        Volt.log("render, LocalMemory.storageRate = " + LocalMemory.storageRate);

        //// Update Color Pick
        var pickedColor = this.parent.pickedColor;
        if (pickedColor) {
            var textColor = {
                r: pickedColor.r,
                g: pickedColor.g,
                b: pickedColor.b,
                a: 255 * 0.6
            };
            widget.getChild('storage-info-text-all').textColor = textColor;
            widget.getChild('storage-info-text-used').textColor = textColor;
            widget.getChild('storage-info-text-available').textColor = textColor;
            widget.getChild('storage-info-text-all-value').textColor = textColor;
            widget.getChild('storage-info-text-used-value').textColor = textColor;
            widget.getChild('storage-info-text-available-value').textColor = textColor;
        }

        //// @xj|2014/12/13: After view rendered, update data
        this.update();
        this.addListeners();
        this.setWidget(widget);
        widget.show();

        return this;
    },

    remove: function () {
        //// @xj|2014/12/23: Theoretically, we should destroy this.widget here. Since we will destroy widget of parent, we don't need to destroy widget here.
        this.removeListeners();

        this.allMemoryText = null;
        this.usedMemoryText = null;
        this.availableMemoryText = null;
        this.allMemoryValueText = null;
        this.usedMemoryValueText = null;
        this.availableMemoryValueText = null;

        this.storageProgressbar = null;
        
        this.parent = null;
        this.widget = null;
    },

    /**
     * Show storage area
     * @method
     * @memberof StorageView
     */
    show: function () {
        this.widget.show();
    },

    /**
     * Hide storage area
     * @method
     * @memberof StorageView
     */
    hide: function () {
        this.widget.hide();
    },

    /**
     * When changed local storage memory, it update progressbar
     * @method
     * @memberof StorageView
     */
    update: function () {
        if (this.storageProgressbar && DetailVM.get('storageInfo')) {
            var LocalMemory = DetailVM.get('storageInfo');

            //this.storageProgressbar.percentage = LocalMemory.storageRate;
            Volt.log("update, LocalMemory.storageRate = " + LocalMemory.storageRate);

            this.storageProgressbar.value = LocalMemory.storageRate * 100;

            this.allMemoryValueText.text = '(' + this.getMemoryText().all + ')';
            this.usedMemoryValueText.text = this.getMemoryText().used;
            this.availableMemoryValueText.text = this.getMemoryText().available;

            this.allMemoryText.width = Volt.getTextWidth({
                text: this.allMemoryText.text,
                font: (Volt.APPS720P) ? '13px' : '20px'
            }) + Volt.dimmensionWidth * 0.003125;
            this.allMemoryValueText.width = Volt.getTextWidth({
                text: this.allMemoryValueText.text,
                font: (Volt.APPS720P) ? '13px' : '20px'
            }) + Volt.dimmensionWidth * 0.003125;
            this.allMemoryValueText.x = this.allMemoryText.x + this.allMemoryText.width;
        }
    },

    addListeners: function () {
        this.listenTo(DetailVM, 'change:storageInfo', this.update);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_MORE_BTN', this.hide);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_CLOSE_BTN', this.show);
    },

    removeListeners: function () {
        this.stopListening();
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    getMemoryText: function () {
        if (!DetailVM || !DetailVM.get('storageInfo') && !DetailVM.get('storageInfo').storageInfo) {
            return {
                used: "0KB",
                available: "0KB",
                all: "0KB"
            };
        }
        var used = DetailVM.get('storageInfo').storageInfo.split("/")[0];
        var all = DetailVM.get('storageInfo').storageInfo.split("/")[1];

        if (used.search(/GB/g) != -1) {
            used = Number(used.split("G")[0]) * 1024 * 1024;
        } else if (used.search(/MB/g) != -1) {
            used = Number(used.split("M")[0]) * 1024;
        } else if (used.search(/KB/g) != -1) {
            used = Number(used.split("K")[0]);
        }
        if (all.search(/GB/g) != -1) {
            all = Number(all.split("G")[0]) * 1024 * 1024;
        } else if (all.search(/MB/g) != -1) {
            all = Number(all.split("M")[0]) * 1024;
        } else if (all.search(/KB/g) != -1) {
            all = Number(all.split("K")[0]);
        }
        var available = all - used;
        return {
            used: CommonFunctions.getFormattedSize(used, true),
            available: CommonFunctions.getFormattedSize(available, true),
            all: CommonFunctions.getFormattedSize(all, true),
        };
    },
});

/**
 * @name DescriptionView
 */
var DescriptionView = Volt.BaseView.extend({
    /** @lends DescriptionView.prototype */
    parent: null, // Parent View

    // Widgets
    moreButtonParent: null,
    closeButtonParent: null,
    moreButton: null,
    closeButton: null,
    
    upArrow: null,
    downArrow: null,
    
    descriptionText: null,

    // Data
    descriptionHeight: 0, // Real height of description

    currentPage: 0,
    maxPage: 0,
    scroll: null,

    btnListener: null,
    mouseListener: null,
    arrowMouseListener: null,
    keyboardListener: null, // keyboard listener for close button

    //// Flag
    moreDescriptionFlag: false,
    adjustheight: 0,

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_SELECT #detail-description-up-arrow': 'onSelect',
        'NAV_SELECT #detail-description-down-arrow': 'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////
    /**
     * Initialize DescriptionView
     * @name DescriptionView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render description info.
     * @method
     * @memberof DescriptionView
     */
    render: function () {
        Volt.log("[DescriptionView.js] render");
        try {
            var strDescription = this.escapeHtml(DetailVM.get('description'));
            var developerText = Volt.i18n.t('COM_SID_DEVELOPER') + ': ' + DetailVM.get('vendor') + '(' + DetailVM.get('contact') + ')';

            if (Volt.APPS_REVERSE) {
                developerText = DetailVM.get('vendor') + '(' + DetailVM.get('contact') + ')' + ': ' + Volt.i18n.t('COM_SID_DEVELOPER');
            }
            //// Load Template
            var widget = Volt.loadTemplate(Template.description, null, this.parent.widget.getDescendant('detail-description-area'));

            widget.getDescendant('detail-description-text').text = strDescription + '\n\n' + developerText;
           
            this.setWidget(widget);

            // TODO: Check if color pick is working?
            // Color Pick
            var pickedColor = this.parent.pickedColor;
            if (pickedColor) {
                //widget.getChild(0).textColor = Volt.hexToRgb(this.parent.pickedColor, 80);
                widget.getDescendant('detail-description-text').textColor = {
                    r: pickedColor.r,
                    g: pickedColor.g,
                    b: pickedColor.b,
                    a: 255,
                };
            }

            this.descriptionText = widget.getChild(0).getChild('detail-description-text');
            this.upArrow = widget.getChild('detail-description-up-arrow');
            this.downArrow = widget.getChild('detail-description-down-arrow');
            var lineHeight = this.descriptionText.getLineHeight();
            Volt.log("lineHeight!!!!!!!!!!!!!" + lineHeight);
            this.descriptionText.lineSpacing = Math.ceil(1080 * 0.040741) - lineHeight - 1;
            this.descriptionHeight = this.descriptionText.height;
            if (this.descriptionHeight > Template.descriptionLineHeight) {
                this.maxPage = Math.ceil(this.descriptionHeight / Template.descriptionMaxLineHight);
                Volt.log('[descriptionView] this.maxPage: ' + this.maxPage);
                this.widget.getDescendant('detail-description-text-container').height = Template.descriptionLineHeight;
                //this.descriptionText.height = Template.descriptionLineHeight;
                this.descriptionText.ellipsize = true;

                //// Set up More Button
                this.moreButtonParent = this.widget.getChild('detail-more-button');

                var btnStyle = {
                    style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
                    buttonType: WinsetButton.ButtonType.BUTTON_ICON,
                    resolution: tvResolution,
                };

                if (WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA)
                    btnStyle.style = WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA;

                this.moreButton = Volt.loadTemplate(Template.moreBtn, btnStyle, this.moreButtonParent);

                this.moreButton.setIconScaleFactor({
                    state: "focused-roll-over",
                    scaleX: 1.1,
                    scaleY: 1.1,
                });
                if (!WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA) {
                    this.moreButton.setIconImage({
                        state: "normal",
                        src: Volt.getRemoteUrl("images/1080/common/btn_icon_more.png"),
                    });
                    this.moreButton.setIconImage({
                        state: "focused",
                        src: Volt.getRemoteUrl("images/1080/common/btn_icon_more_f.png"),
                    });
                    this.moreButton.setIconImage({
                        state: "focused-roll-over",
                        src: Volt.getRemoteUrl("images/1080/common/btn_icon_more_f.png"),
                    });
                    this.moreButton.setIconImage({
                        state: "selected",
                        src: Volt.getRemoteUrl("images/1080/common/btn_icon_more.png"),
                    });

                    this.moreButton.setIconAlpha({
                        state: "normal",
                        alpha: 255
                    });

                }



                //// Set up Close Button
                this.closeButtonParent = this.widget.getChild('detail-close-button');

                this.closeButtonParent.onKeyEvent = function (keyCode, keyType) {
                    return true;
                }

                var btnStyleText = {
                    style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
                    buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
                    resolution: tvResolution,
                };

                if (WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA)
                    btnStyleText.style = WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA;

                this.closeButton = Volt.loadTemplate(Template.closeBtn, btnStyleText, this.closeButtonParent);
                this.closeButtonParent.hide();

                //// Update Volt.Nav Candidate List
                Volt.Nav.addItem(this.moreButtonParent, true);
            }

            this.hideArrow();
            
            //// Add Event Listener
            this.addListeners();

            return this;

        } catch (e) {
            Volt.log('[descriptionView] occured exception: ' + e);
        }
    },

    remove: function () {
        //// @xj|2014/12/23: Theoretically, we should destroy this.widget here. Since we will destroy widget of parent, we don't need to destroy widget here.
        this.removeListeners();
        
        this.moreButtonParent = null;
        this.closeButtonParent = null;
        this.moreButton = null;
        this.closeButton = null;
        this.descriptionText = null;
        
        this.upArrow = null;
        this.downArrow = null;
        
        this.parent = null;
        this.widget = null;
    },

    addListeners: function () {
        //// Add Event Listener
        if (this.moreButton && this.closeButton) {
            var btnListener = this.btnListener = new ButtonListener();
            btnListener.onButtonClicked = function (button, type) {
                this.onSelect(button);
            }.bind(this);

            this.moreButton.addListener(btnListener);
            this.closeButton.addListener(btnListener);

            this.mouseListener = new MouseListener;
            this.mouseListener.onMousePointerIn = function (widget, event) {
                Volt.log('[DescriptionView @onMousePointerIn] widget: ' + widget.parent.id);
                EventMediator.trigger('EVENT_SHOW_TOOLTIP', widget.parent);
            };
            this.mouseListener.onMousePointerOut = function (widget, event) {
                Volt.log('[DescriptionView @onMousePointerOut] widget: ' + widget.parent.id);
                EventMediator.trigger('EVENT_HIDE_TOOLTIP');
            };

            this.moreButton.addMouseListener(this.mouseListener);
        }
    },

    removeListeners: function () {
        this.stopListening();

        if (this.btnListener) {
            this.moreButton && this.moreButton.removeListener(this.btnListener);
            this.closeButton && this.closeButton.removeListener(this.btnListener);
            
            this.btnListener.destroy();
            this.btnListener = null;
        }

        if (this.mouseListener) {
            this.moreButton && this.moreButton.removeMouseListener(this.mouseListener);
            
            this.mouseListener.destroy();
            this.mouseListener = null;
        }
        
        if (this.keyboardListener) {
            this.keyboardListener.destroy();
            this.keyboardListener = null;
        }
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////

    onReturn: function () {

        if (this.moreDescriptionFlag) {
            this.onSelect(this.closeButton);
            this.moreDescriptionFlag = false;
            return true;
        }
        return false;
    },

    escapeHtml: function (descriptionText) {

        var escapeText = descriptionText;

        if (escapeText) {

            escapeText = escapeText.replace(/\n\s+/g, '\n');
            escapeText = escapeText.replace(/\n/g, '\n');
            escapeText = escapeText.replace(/\t/g, '\n');

            escapeText = escapeText.replace(/<br\s*\/?>/gim, '\n'); //match<br />

            escapeText = escapeText.replace(/<p\s*>/gim, ''); //match<p>
            escapeText = escapeText.replace(/<\/p>/gim, ''); //matach</p>
        }

        return escapeText;
    },

    /**
     * When select button, doing button's action
     * @method
     * @memberof DescriptionView
     * @param {object} widget  selected widget's object
     */
    onSelect: function (widget) {

        switch (widget.id) {
        case 'moreBtn':
            EventMediator.trigger('EVENT_PRESS_DETAIL_MORE_BTN', true);
            this.moreDescriptionFlag = true;
            this.moreDescription();
            break;

        case 'closeBtn':
            EventMediator.trigger('EVENT_PRESS_DETAIL_CLOSE_BTN', true);
            this.moreDescriptionFlag = false;
            this.normalDescription();
            break;

        }
    },

    moreDescription: function () {

        Volt.Nav.removeItem(this.moreButtonParent, true);
        this.moreButtonParent.hide();

        Volt.Nav.addItem(this.closeButtonParent, true);
        this.closeButtonParent.show();
        var fullarticleLineTotal = this.descriptionText.getFullTextLineCount();
        if (fullarticleLineTotal >= 12) {
            var fullarticleVisiableLineHeight = this.descriptionText.getLineHeight(0, 12);
        } else {
            var fullarticleVisiableLineHeight = this.descriptionText.getLineHeight(0, fullarticleLineTotal);
        }
        var fullarticleFirstLineHeight = this.descriptionText.getLineHeight(0);

        this.descriptionText.height = this.descriptionHeight;
        this.widget.getDescendant('detail-description-text-container').height = fullarticleVisiableLineHeight;
        this.descriptionText.ellipsize = false;
        this.widget.getChild('detail-close-button').show();
        this.adjustheight = fullarticleVisiableLineHeight;
        Volt.log("fullarticleVisiableLineHeight~~~~~~~~~~~~~~~~~~~~~" + fullarticleVisiableLineHeight + "fullarticleFirstLineHeight~~~" + fullarticleFirstLineHeight + "getFullTextLineCount" + fullarticleLineTotal + this.descriptionText.text);
        //if descriptionText's length is more than one page, add scroll and keyboardlistener to listen up/down key
        if (this.descriptionText.height > Template.descriptionMaxLineHight) {
            this.setScrollbar();
            this.showArrow();
        }

        if (!this.keyboardListener) {
            this.keyboardListener = new KeyboardListener;
            this.keyboardListener.onKeyReleased = function (actor, keyCode) {
                var ret;
                switch (keyCode) {
                case Volt.KEY_JOYSTICK_UP:
                    {
                        Volt.log("@@@UP key");
                        ret = this.textRollUp();
                        if (!ret) {
                            AUI.play(HALOUtil.MOVE_NOKEY);
                            Volt.log('[volt-nav.js @handleKeyPress] AUI.play(HALOUtil.MOVE_NOKEY)');
                        }
                        break;
                    }
                case Volt.KEY_JOYSTICK_DOWN:
                    {
                        Volt.log("@@@DOWN key");
                        ret = this.textRollDown();
                        if (!ret) {
                            AUI.play(HALOUtil.MOVE_NOKEY);
                            Volt.log('[volt-nav.js @handleKeyPress] AUI.play(HALOUtil.MOVE_NOKEY)');
                        }
                        break;
                    }
                case Volt.KEY_JOYSTICK_LEFT:
                case Volt.KEY_JOYSTICK_RIGHT:
                    {
                        AUI.play(HALOUtil.MOVE_NOKEY);
                        Volt.log('[volt-nav.js @handleKeyPress] AUI.play(HALOUtil.MOVE_NOKEY)');
                    }
                    break;
                default:
                    return false;
                }

            }.bind(this);
        }

        this.closeButton.addKeyboardListener(this.keyboardListener);
        Volt.Nav.focus(this.closeButtonParent);
    },

    normalDescription: function () {
        Volt.Nav.removeItem(this.closeButtonParent, true);
        this.closeButtonParent.hide();

        Volt.Nav.addItem(this.moreButtonParent, true);
        this.moreButtonParent.show();
        this.widget.height = Template.descriptionLineHeight;
        this.descriptionText.y = 0;
        this.widget.getDescendant('detail-description-text-container').height = Template.descriptionLineHeight;
        this.descriptionText.ellipsize = true;
        this.hideArrow();
        if (this.scroll) {
            this.scroll.clearTimeOut();
            this.scroll.destroy();
            this.scroll = null;
        }
        this.currentPage = 0; //reset 

        if (this.keyboardListener) {
            this.closeButton.removeKeyboardListener(this.keyboardListener);
        }

        if (this.arrowMouseListener) {
            this.upArrow.removeMouseListener(this.arrowMouseListener);
            this.downArrow.removeMouseListener(this.arrowMouseListener);
            this.arrowMouseListener.destroy();
            this.arrowMouseListener = null;
        }

        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onShowScroll);
        if (this.parent.lastFocus) { // Focus in return button
            this.parent.lastFocus = this.moreButtonParent;
        } else { //// If the focus not on return button, focus more button.
            Volt.Nav.focus(this.moreButtonParent);
        }
    },

    showArrow: function () {
        this.renderArrow();
        
        if (this.descriptionText.height <= this.adjustheight) {
            this.upArrow.hide();
            this.downArrow.hide();
            return;
        }

        if (this.currentPage > 0) {
            this.upArrow.show();
            this.scroll.setValue(Math.ceil(this.currentPage / this.maxPage * 100));
            Volt.log("this.currentPage    " + this.currentPage + "~~~~~~~~~Math.ceil(this.currentPage/this.maxPage * 100)~~~~~~~~~~~~~" + Math.ceil(this.currentPage / this.maxPage * 100));
        } else {
            this.upArrow.hide();
            this.scroll.setValue(0);

        }

        if (this.currentPage < this.maxPage - 1) {
            this.downArrow.show();
        } else {
            this.downArrow.hide();

            this.scroll.setValue(100);
        }

        Volt.Nav.reload();
    },

    hideArrow: function () {

        if (this.upArrow) {
            this.upArrow.hide();

        }

        if (this.downArrow) {
            this.downArrow.hide();

        }
    },

    setScrollbar: function () {

        if (this.scroll) {
            return;
        }

        var scroll = new WinsetScroll({
            style: 3,
            parent: this.widget.getChild('detail-description-text-container'),
            x: 1236 - 10,
            y: 0,
            minValue: 0,
            maxValue: 100,
            value: 0,
            width: this.adjustheight * 0.004630,
            height: this.adjustheight,
        });

        //Volt.log(' ***********moredescription.setScrollBar********  ');

        scroll.timer = -1;
        scroll.active = false;

        scroll.setTimerOut = function () {
            //Volt.log("[common-content.js] scroll setTimerOut - hide scroll after 2 sec");
            scroll.show();
            if (scroll.timer) {
                Volt.clearTimeout(scroll.timer);
            }
            scroll.timer = Volt.setTimeout(function () {
                scroll.hide();
            }, 1000 * 2);
        };

        scroll.clearTimeOut = function () {
            //Volt.log("[common-content.js] scroll clearTimeOut - hide scroll");
            if (scroll.timer) {
                Volt.clearTimeout(scroll.timer);
            }
        };

        this.scroll = scroll;
        scroll.hide();


        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.onShowScroll);

        //judge mouse status
        if (voltapi.vconf.getValue('memory/window_system/input/cursor_visible')) {
            //print(' voltapi.vconf.getValue(memory/window_system/input/cursor_visible)   ' + voltapi.vconf.getValue('memory/window_system/input/cursor_visible'));
            this.onShowScroll(true);
        }

        return scroll;

    },

    onShowScroll: function (visible) {
        if (this.scroll) {
            if (visible) {
                this.scroll.show();
                this.scroll.clearTimeOut();
                this.scroll.setTimerOut();
            } else { //if  mouse pointer disappera, scroll hide, focus return to close btn
                this.scroll.hide();
                this.scroll.clearTimeOut();
                this.closeButton.setFocus();
            }
        }
    },


    textRollUp: function () {
        Volt.log("[detail-view.js] textRollUp    this.currentPage =  " + this.currentPage);
        Volt.log("[detail-view.js] textRollUp    this.descriptionText.y =  " + this.descriptionText.y);
        var ret = false;
        if (this.currentPage > 0) {
            this.currentPage--;
            this.descriptionText.y = -this.currentPage * this.adjustheight;
            this.scroll.show();
            this.scroll.clearTimeOut();
            this.scroll.setTimerOut();
            this.showArrow();
            ret = true;
        }

        return ret;

    },

    textRollDown: function () {
        Volt.log("[detail-view.js] textRollDown    this.currentPage =  " + this.currentPage);
        Volt.log("[detail-view.js] textRollDown    this.descriptionText.y =  " + this.descriptionText.y);
        var ret = false;
        if (this.currentPage < (this.maxPage - 1)) {
            this.currentPage++;
            this.descriptionText.y = -this.currentPage * this.adjustheight;
            this.scroll.show();
            this.scroll.clearTimeOut();
            this.scroll.setTimerOut();
            this.showArrow();
            ret = true;
        }
        return ret;
    },


    renderArrow: function () {

        if (this.arrowMouseListener) {
            return;
        }
        
        this.arrowMouseListener = new MouseListener;
        this.arrowMouseListener.onMousePointerIn = function (actor, event) {
            Volt.log('    onMousePointerIn     event  ', event);
            if (actor.id == 'detail-description-up-arrow') {
                Volt.Nav.blur();
                this.upArrow.opacity = 255;

            } else if (actor.id == 'detail-description-down-arrow') {
                Volt.Nav.blur();
                this.downArrow.opacity = 255;
            }
        }.bind(this);
        this.arrowMouseListener.onMousePointerOut = function (actor, event) {
            Volt.log('    onMousePointerOut     event  ', event);
            if (actor.id == 'detail-description-up-arrow') {
                this.upArrow.opacity = 153;
            } else if (actor.id == 'detail-description-down-arrow') {
                this.downArrow.opacity = 153;
            }
        }.bind(this);

        this.arrowMouseListener.onMouseButtonReleased = function (actor, event) {
            Volt.log('    onMouseButtonReleased      event  ', event);
            if (actor.id == 'detail-description-up-arrow') {
                this.textRollUp();
            } else if (actor.id == 'detail-description-down-arrow') {
                this.textRollDown();
            }
        }.bind(this);

        this.upArrow.addMouseListener(this.arrowMouseListener);
        this.downArrow.addMouseListener(this.arrowMouseListener);

    },


    /**
     * When focued button, changed border
     * @method
     * @memberof DescriptionView
     * @param {object} widget  focued widget's object
     */
    onFocus: function (widget) {
        if (widget) {
            this.parent.focusButtonId = widget.id;
            switch (widget.id) {
            case 'detail-more-button':
                this.moreButton.setFocus();
                CommonFunctions.voiceGuide(Volt.i18n.t('COM_TV_SID_MORE') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                EventMediator.trigger('EVENT_SHOW_TOOLTIP', widget);
                break;
            case 'detail-close-button':
                this.closeButton.setFocus();
                var voiceText = this.escapeHtml(DetailVM.get('description')) + ',' +
                    Volt.i18n.t('COM_SID_CLOSE') + ',' + Volt.i18n.t('TV_SID_BUTTON');
                CommonFunctions.voiceGuide(voiceText);
                break;
            default:
                widget.color = Volt.hexToRgb('#ffffff', 95);
                widget.getChild(0).textColor = Volt.hexToRgb('#464646', 100);
                widget.getChild(0).font = '36px';
                widget.border = {
                    width: 2,
                    color: Volt.hexToRgb('#ffffff', 95)
                };
                break;
            }
        }
    },

    /**
     * When blured button, changed border
     * @method
     * @memberof DescriptionView
     * @param {object} widget  blured widget's object
     */
    onBlur: function (widget) {
        if (widget) {
            switch (widget.id) {
            case 'detail-more-button':
                this.moreButton.killFocus();
                EventMediator.trigger('EVENT_HIDE_TOOLTIP', widget);
                break;
            case 'detail-close-button':
                this.closeButton.killFocus();
                EventMediator.trigger('EVENT_HIDE_TOOLTIP', widget);
                break;
            default:
                widget.color = Volt.hexToRgb('#ffffff', 0);
                widget.getChild(0).textColor = Volt.hexToRgb('#ffffff', 80);
                if (widget.getChild(0) && widget.getChild(0).font) {
                    widget.getChild(0).font = '32px';
                }
                widget.border = {
                    width: 2,
                    color: Volt.hexToRgb('#ffffff', 80)
                };
                break;
            }
        }
    }
});

/**
 * @namespace DetailView
 * @name ButtonsView
 */
var ButtonsView = Volt.BaseView.extend({
    /** @lends ButtonsView.prototype */
    parent: null,
    
    downloadBtn: null,
    ratingBtn: null,
    downloadBtnBG: null,
    ratingBtnBG: null,
    
    lowMemoryText: null,

    progressbarView: null,
    
    StarOnURL: Volt.getMultiResImage('common/btn_icon_like_star_on.png'),
    StarOffURL: Volt.getMultiResImage('common/btn_icon_like_star_off.png'),
    StarHalfUrl: Volt.getMultiResImage('common/btn_icon_like_star_half.png'),
    
    ratingStarList: null,
    buttonColorPick: "#ffffff",
    bFirstFocus: true,
    cancelButtonDimFlag:false,
    btnListener: null,

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    ////////////////////////////////////
    // Public Functions
    ////////////////////////////////////
    /**
     * Initialize DetailView
     * @name ButtonsView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
    },
    /**
     * Render buttons : Download, Rating
     * @method
     * @memberof ButtonsView
     */
    render: function (textColorPick) {
        Volt.log('detail-view.js ::ButtonsView @render');

        var btnContainer = Volt.loadTemplate(Template.buttonContainer, null, this.parent.widget.getDescendant('detail-button-area'));
        this.setWidget(btnContainer);

        var btnStyle = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resolution: tvResolution,
        };


        if (WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA)
            btnStyle.style = WinsetButton.ButtonStyle.Button_KeyScreen_Common_ContentsBtn_StyleA;

        this.downloadBtnBG = this.widget.getChild('download_button_widget');
        this.downloadBtn = Volt.loadTemplate(Template.downloadBtn, btnStyle, this.downloadBtnBG);
        this.downloadBtn.setText({
            state: "all",
            text: DetailVM.getDownloadBtnName()
        });

        if (Volt.DeviceInfoModel.get('focusZoom')) {
            this.downloadBtn.setFontSize({
                state: "normal",
                size: (Volt.APPS720P) ? 20 : 31
            });
            this.downloadBtn.setFontSize({
                state: "focused",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "roll-over",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "focused-roll-over",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "selected",
                size: (Volt.APPS720P) ? 24 : 36
            });
            this.downloadBtn.setFontSize({
                state: "disabled",
                size: (Volt.APPS720P) ? 20 : 31
            });
        }
        this.ratingBtnBG = this.widget.getChild('rating_button_widget');
        if(Volt.APPS_REVERSE){
           this.ratingBtnBG.rotation.y = 180; 
        }

        this.ratingBtn = Volt.loadTemplate(Template.ratingBtn, btnStyle, this.ratingBtnBG);

        var i;
        this.ratingStarList = [];
        for (i = 0; i < MAX_RATING_NUM; i++) {
            this.ratingStarList[i] = Volt.loadTemplate(Template.btnStar);
            this.ratingStarList[i].x = Volt.dimmensionWidth * 0.0609375 + Volt.dimmensionWidth * 0.01875 * i;
            this.ratingBtnBG.addChild(this.ratingStarList[i]);
        }
        
        this.updateRatingBtn();
        //this.showLowMemoryMessage();
        this.addListeners();

        // Add Nav Rule
        Volt.Nav.setNextItemRule(this.ratingBtnBG, 'right', this.ratingBtnBG);
        
        Volt.Nav.reload();
        return this;
    },

    remove: function () {
        Volt.log('detail-view.js ::ButtonsView @remove');
        Volt.Nav.clearNextItemRule(this.ratingBtnBG);

        
        this.removeListeners();
        
        this.downloadBtn = null;
        this.ratingBtn = null;
        this.downloadBtnBG = null;
        this.ratingBtnBG = null;
        
        this.lowMemoryText = null;
        
        if (this.progressbarView) {
            this.progressbarView.hide();
            this.progressbarView = null;
        }
        
        this.ratingStarList.length = 0;
        
        this.parent = null;
        this.widget = null;
    },

    /**
     * Show this widget
     * @method
     * @memberof ButtonsView
     */
    show: function () {
        Volt.log("rating_button_widget focusable true");
        
        var widget;
        
        this.listenTo(EventMediator, 'EVENT_UPDATE_DOWNLOAD_BUTTON', this.updateDownloadBtn);
        this.listenTo(DetailVM, 'change:userRating', this.updateRatingBtn);
        this.listenTo(DetailVM, 'change:isInstalling', this.setProgressBar);

        this.setProgressBar(DetailVM.get('nInitProgress'));

        widget = this.widget.getChild('download_button_widget');
        
        widget && (widget.custom = {focusable: true});
        
        widget = this.widget.getChild('rating_button_widget');
        widget && (widget.custom = {focusable: true});

        this.showLowMemoryMessage();
        this.ratingBtn.addListener(this.btnListener);
        this.downloadBtn.addListener(this.btnListener);
        this.widget.show();
        Volt.Nav.reload();
    },

    /**
     * Hide this widget
     * @method
     * @memberof ButtonsView
     */
    hide: function () {
        this.stopListening(DetailVM, 'change:userRating');
        this.stopListening(DetailVM, 'change:isInstalling');
        this.stopListening(EventMediator, 'EVENT_UPDATE_DOWNLOAD_BUTTON');

        if (this.widget.getChild('download_button_widget')) {
            this.widget.getChild('download_button_widget').custom = {
                focusable: false
            };
        }

        Volt.log("rating_button_widget focusable flase");

        if (this.widget.getChild('rating_button_widget')) {
            this.widget.getChild('rating_button_widget').custom = {
                focusable: false
            };
        }
        this.ratingBtn.removeListener(this.btnListener);
        this.downloadBtn.removeListener(this.btnListener);
        Volt.Nav.reload();
        EventMediator.trigger('EVENT_HIDE_TOOLTIP');

        this.widget.hide();
    },

    setFocus: function () {
        Volt.Nav.focus(this.widget.getChild('download_button_widget'));
    },

    addListeners: function () {
        this.listenTo(DetailVM, 'change:userRating', this.updateRatingBtn);
        this.listenTo(DetailVM, 'change:isInstalling', this.setProgressBar);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_MORE_BTN', this.hide);
        this.listenTo(EventMediator, 'EVENT_PRESS_DETAIL_CLOSE_BTN', this.show);
        this.listenTo(EventMediator, 'EVENT_DETAIL_SUCCESS_DOWNLOAD', this.updateProgressBar);
        this.listenTo(EventMediator, CommonDefines.Event.DOWNLOAD_FAIL_NOSPACE, this.showLowMemoryMessage);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_CHECK_DETAIL_BUTTON, this.showLowMemoryMessage);
        this.listenTo(EventMediator, 'EVENT_DETAIL_SET_BUTTON_FOCUS', this.setFocus);
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this); //add by yangpei 20141110
        this.listenTo(EventMediator, 'EVENT_UPDATE_DOWNLOAD_BUTTON', this.updateDownloadBtn);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_FOCUS_ZOOM, this.updateBtnFont);

        this.listenTo(EventMediator, CommonDefines.Event.CHAHGE_LOCAL_MEMORY, this.updateButtonGuideText);
        this.listenTo(EventMediator, CommonDefines.Event.CONNECT_USB, this.updateButtonGuideText);
        this.listenTo(EventMediator, CommonDefines.Event.DISCONNECT_USB, this.onDisconnectUsb);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_DIM_CANCEL_BUTTON,this.dimCancelButton);

        var btnListener = this.btnListener = new ButtonListener();
        btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);

        this.downloadBtn.addListener(btnListener);
        this.ratingBtn.addListener(btnListener);

        this.mouseListener = new MouseListener;
        this.mouseListener.onMousePointerIn = function (widget, event) {
            Volt.log('[ButtonsView @onMousePointerIn] widget: ' + widget.parent.id);
            EventMediator.trigger('EVENT_SHOW_TOOLTIP', widget.parent);
        };
        this.mouseListener.onMousePointerOut = function (widget, event) {
            Volt.log('[ButtonsView @onMousePointerOut] widget: ' + widget.parent.id);
            EventMediator.trigger('EVENT_HIDE_TOOLTIP');
        };

        this.ratingBtn.addMouseListener(this.mouseListener);
    },

    removeListeners: function () {
        this.stopListening();

        if (this.btnListener) {
            this.downloadBtn && this.downloadBtn.removeListener(this.btnListener);
            this.ratingBtn && this.ratingBtn.removeListener(this.btnListener);
            
            this.btnListener.destroy();
            this.btnListener = null;
        }
        
        if (this.mouseListener) {
            this.ratingBtn && this.ratingBtn.removeMouseListener(this.mouseListener);
            
            this.mouseListener.destroy();
            this.mouseListener = null;
        }
    },

    ////////////////////////////////////
    // Private Functions
    ////////////////////////////////////
    setDimRatingButton: function () {

        if (this.ratingBtn) {
            if (!DetailVM.get('isDownloaded')) {
                this.ratingBtn.custom = {
                    focusable: false
                };
                this.ratingBtn.opacity = Volt.getPercentage(30);
                this.ratingBtn.border = {
                    width: 2,
                    color: Volt.hexToRgb('#ffffff')
                };

            } else {
                this.ratingBtn.custom = {
                    focusable: true
                };

                this.ratingBtn.opacity = Volt.getPercentage(100);

                this.onBlur(this.ratingBtn);
            }

            Volt.Nav.reload();
        }
    },

    setRatingStarOpacity: function (opacity) {

        if (this.ratingStarList && opacity) {
            var nOpacity = 255 * opacity;
            for (var i = 0; i < MAX_RATING_NUM; i++) {
                this.ratingStarList[i].opacity = nOpacity;
            }
        }

    },
    onDisconnectUsb: function () {
        Volt.log('[DetailView] onDisconnectUsb');
        this.showLowMemoryMessage();
        var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 1];
        var isDetail = (/#detail/g).test(previousHistory);

        //// @xiaojun.wang: DF150207-00669
        // If we are in deactivate state, do not show popup
        if (isDetail && CommonFunctions.getAppState() != CommonDefines.AppState.APP_STATE_DEACTIVATE) {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_USB_NOT_CONNECT);
        }
    },
    showLowMemoryMessage: function () {
        Volt.log('[DetailView] showLowMemoryMessage');
        if (this.lowMemoryText) {
            this.lowMemoryText.show();
        } else {
            this.lowMemoryText = Volt.loadTemplate(Template.downloadGuideText);
            this.widget.addChild(this.lowMemoryText);
        }
        //process app sync
        var wasSyncState = voltapi.WAS.getAppsSyncState();
        Volt.err('[DetailView] wasSyncState is ' + wasSyncState);
        if(wasSyncState != CommonDefines.WAS.WAS_APPS_SYNC_COMPLETED){
            Volt.err('[DetailView] WAS APPS SYNC not COMPLETED');  
            if(Volt.i18n.t('UID_DOWNLOAD') == DetailVM.getDownloadBtnName()){
                this.downloadBtn.enable(false);
                this.lowMemoryText.text = Volt.i18n.t('TV_SID_SMART_HUB_UPDATED_TRY_AGAIN_LATER');
                return;
            }   
        }else{
            if(!this.cancelButtonDimFlag){
                this.downloadBtn.enable(true);
                this.lowMemoryText.text = "";
            }
        }
        if (DetailVM.get('isDownloaded')) {
            if(!this.cancelButtonDimFlag){
                this.downloadBtn.enable(true);
            }
            this.lowMemoryText.text = "";
            return;
        }
        if (!DetailVM.isDownloadableApp()) {
            var result = voltapi.ContentsMgr.getStorages();
            var len = 0;
            if (result && result.storages) {
                len = result.storages.length;
            }
            Volt.log("[DetailView] result.storages.length is " + len);
            if (Volt.i18n.t('COM_SID_CANCEL') == DetailVM.getDownloadBtnName()) {
                this.lowMemoryText.text = "";
                if(0 != len){
                     var result = AppInstallMgr.getInstallList(DetailVM.get('id'));
                     if (result && result.app_id == DetailVM.get('id')) {
                         if(result.path){
                              Volt.log("[DetailView] result.path is " + result.path);
                              this.lowMemoryText.text = Volt.i18n.t('TV_SID_NOT_REMOVE_STORAGE_USE');
                         }
                     }
                }
                return;
            }
// For store movie Start
            try {
                Volt.log("[DetailView] isUnnecessaryMovie success");
                ismovie = VDUtil.isUnnecessaryMovie();
            } catch (e) {
                Volt.log("[DetailView] isUnnecessaryMovie fail");
            }
// For store movie End     

            if (len > 0) {
                Volt.log("[DetailView] connect usb");
                if (DetailVM.checkUsbMemory(result)) {
                     if(!this.cancelButtonDimFlag){
                         this.downloadBtn.enable(true);
                     }
                    this.lowMemoryText.text = Volt.i18n.t('COM_SID_INTERNAL_MEMORY_LOW_ATTACHED_USB');
                } else {
                    this.downloadBtn.enable(false);
                    this.lowMemoryText.text = Volt.i18n.t('TV_SID_MIX_INTERNAL_MEMORY_LOW_ANOTHER_DEVICE_ATTACHED').replace('<<A>>', DetailVM.get('title'));
                }
// For store movie Start
            } else if (ismovie == true) {
                try {
                    Volt.log("[DetailView] ismovie true and delete movie");
                    VDUtil.removeUnnecessaryMovie();
                    DetailVM.updateStorageInfo();
                    EventMediator.trigger(CommonDefines.Event.EVENT_DELETE_STORE_MOVIE);

                    this.downloadBtn.enable(true);
                    this.lowMemoryText.text = "";
                } catch (e) {
                    Volt.log("[DetailView] ismovie true and did not delete movie");
                    this.downloadBtn.enable(false);
                    this.lowMemoryText.text = Volt.i18n.t('COM_SID_INTERNAL_MEMORY_LOW_USB_INSTALL');
                }
            }
// For store movie End
            else {
                Volt.log("[DetailView] ismovie false");
                this.downloadBtn.enable(false);
                this.lowMemoryText.text = Volt.i18n.t('COM_SID_INTERNAL_MEMORY_LOW_USB_INSTALL');
            }
        } else {
            if(!this.cancelButtonDimFlag){
                this.downloadBtn.enable(true);
            }
            this.lowMemoryText.text = "";
        }
        // Update Rating Button when usb changed
        this.updateRatingBtn();

    },
    updateButtonGuideText: function () {
        Volt.log('updateButtonGuideText');
        this.showLowMemoryMessage();
    },
    dimCancelButton: function (flag) {
        Volt.log('dimCancelButton: flag is ' + flag);
        if(this.downloadBtn){
             if(flag){
                     this.downloadBtn.enable(false);//dim cancel button
                     this.cancelButtonDimFlag = true;
             }else{
                     this.downloadBtn.enable(true);//dim cancel button//undim cancel button
                     this.cancelButtonDimFlag = false;
             }
        }
    },
    /**
     * When changed download button's state, updated both button's name and progressBar
     * @method
     * @memberof ButtonsView
     */
    updateDownloadBtn: function () {
        Volt.log("detailView.js:updateDownloadBtn");
        if (this.downloadBtn) {
            Volt.log('updateDownloadBtn:text is ' + DetailVM.getDownloadBtnName());
            this.downloadBtn.setText({
                state: "all",
                text: DetailVM.getDownloadBtnName()
            });
            this.showLowMemoryMessage();
            if(Volt.i18n.t('UID_OPEN') == DetailVM.getDownloadBtnName()){
                if (this.progressbarView) {
                    this.progressbarView.hide();
                    delete this.progressbarView;
                    this.progressbarView = null;
                    this.stopListening(EventMediator, CommonDefines.Event.DOWNLOADING);
                }
            }
        }
    },

    updateBtnFont: function () {
        Volt.log("detailView.js:updateBtnFont focuszoom is " + Volt.DeviceInfoModel.get('focusZoom'));
        if (this.downloadBtn) {
            if (Volt.DeviceInfoModel.get('focusZoom')) {
                this.downloadBtn.setFontSize({
                    state: "normal",
                    size: (Volt.APPS720P) ? 20 : 31
                });
                this.downloadBtn.setFontSize({
                    state: "focused",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "roll-over",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "focused-roll-over",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "selected",
                    size: (Volt.APPS720P) ? 24 : 36
                });
                this.downloadBtn.setFontSize({
                    state: "disabled",
                    size: (Volt.APPS720P) ? 20 : 31
                });
            } else {
                this.downloadBtn.setFontSize({
                    state: "normal",
                    size: (Volt.APPS720P) ? 17 : 26
                });
                this.downloadBtn.setFontSize({
                    state: "focused",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "roll-over",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "focused-roll-over",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "selected",
                    size: (Volt.APPS720P) ? 20 : 30
                });
                this.downloadBtn.setFontSize({
                    state: "disabled",
                    size: (Volt.APPS720P) ? 17 : 26
                });
            }
        }
    },
    /**
     * When start download app, set to show progressbar
     * @method
     * @memberof ButtonsView
     * @param  {object}  eventInfo  app_id, value
     */
    setProgressBar: function (nProgress) {
        Volt.log("detailView.js:setProgressBar");
        if (DetailVM.get('isInstalling')) {
            if (this.progressbarView) {
                this.progressbarView.show();
            } else {
                var value;
                if (nProgress && nProgress > 0) {
                    value = nProgress;
                }
                this.progressbarView = new ProgressBarView({
                    id: 'detail-download-button' + DetailVM.get('id'),
                    parent: this.downloadBtn,
                    value: value,
                });
                this.downloadBtn.addChild(this.progressbarView.render().widget);
            }

            this.listenTo(EventMediator, CommonDefines.Event.DOWNLOADING, this.updateProgressBar);
        } else {

            if (this.progressbarView) {
                this.progressbarView.hide();
                delete this.progressbarView;
                this.progressbarView = null;
            }

            this.stopListening(EventMediator, CommonDefines.Event.DOWNLOADING);
        }

        this.updateDownloadBtn();
    },

    /**
     * When changed progress to install app, updated progressbar
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    updateProgressBar: function (eventInfo) { 
        if (eventInfo && eventInfo.app_id == DetailVM.get('id') && eventInfo.result) {
            if (this.progressbarView) {
                EventMediator.trigger(CommonDefines.Event.EVENT_DIM_CANCEL_BUTTON, false);
                this.progressbarView.updateProgressBar(eventInfo.result);
            }
        }
    },

    /**
     * When changed userRating updated rated stars
     * @method
     * @memberof ButtonsView
     */
    updateRatingBtn: function () {
        if (!this.ratingStarList) {
            return;
        }

        var nUserRating = DetailVM.get('userRating');


        var integerRating = Math.floor(nUserRating / 2);
        var pointRating = nUserRating / 2 - integerRating;



        for (var i = 0; i < MAX_RATING_NUM; i++) {

            if (i < integerRating) {
                this.ratingStarList[i].src = this.StarOnURL;
            } else {

                if (i == integerRating && pointRating >= 0.5) {
                    this.ratingStarList[i].src = this.StarHalfUrl;
                } else {
                    this.ratingStarList[i].src = this.StarOffURL;
                }

            }
        }
    },

    /**
     * When selected button, to handle calling function.
     * @method
     * @memberof ButtonsView
     * @param {object} widget selected widget's object
     */
    onSelect: function (widget) {
        if (widget) {
            Volt.log("widget.id: " + widget.id);
            if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
                CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                return;
            }



            switch (widget.id) {
            case "downloadBtn":
                var appID = DetailVM.get('id');

                if (DownloadedAppsMgr.isDownloaded(appID)) {
                    Volt.log(" onSelect winsetDimView.show");
                    EventMediator.trigger('EVENT_OVERLAY_SHOW_DIM');
                    DetailVM.runApp();
                    Volt.KpiMapper.addEventLog('OPEN', {
                        d: {
                            appid: appID,
                        }
                    });
                } else {
                    var result = AppInstallMgr.getInstallList(appID);

                    if (result && result.app_id == appID) {
                        DetailVM.cancelInstallApp();
                        CommonFunctions.voiceGuide(Volt.i18n.t('UID_DOWNLOAD') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                        Volt.KpiMapper.addEventLog('CANCEL', {
                            d: {
                                appid: appID,
                            }
                        });

                    } else {
                        DetailVM.installApp();
                        CommonFunctions.voiceGuide(Volt.i18n.t('TV_DOWNLOADING_STATUS_KR_BLANK') + ',' +
                            Volt.i18n.t('COM_SID_CANCEL') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                        Volt.KpiMapper.addEventLog('DOWNLOAD', {
                            d: {
                                appid: appID,
                            }
                        });

                    }
                }
                break;
            case "ratingBtn":
                if (DetailVM.get('isDownloaded')) {
                    DetailVM.showRatingPopup();
                } else {
                    CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE);
                }
                break;
            }
        }
    },


    processMsgBoxEvent: function (data) {
        Volt.log('[detail-view.js] processMsgBoxEvent:type is:' + data.msgBoxtype + " eventType is:" + data.eventType);
        /* if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE:
                Volt.log('[detail-view.js] processMsgBoxEvent:start to download app');
                if (true == this.widget.getChild('download_button_widget').custom.focusable) {
                    //Volt.Nav.focus(this.widget.getChild('download_button_widget'));
                    if (DetailVM.get('isDownloaded') == false) {
                        var appID = DetailVM.get('id');
                        var result = AppInstallMgr.getInstallList(appID);
                        if (result && result.app_id == appID) {} else {
                            DetailVM.installApp();
                        }
                        Volt.KpiMapper.addEventLog('DOWNLOAD', {
                            d: {
                                appid: appID,
                            }
                        });
                    }
                }
                break;
            default:
                break;
            }
        } else if (data.eventType == CommonDefines.Event.SELECT_BTN2) {
            Volt.log('[detail-view.js] processMsgBoxEvent:SELECT_BTN2');
        }
        */
    },
    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (widget) {
            this.parent.focusButtonId = widget.id;
            if (widget.id == 'download_button_widget') {
                this.downloadBtn.setFocus();
                if (this.bFirstFocus) {
                    CommonFunctions.voiceGuide(DetailVM.get('title') + ',' + DetailVM.getDownloadBtnName() +
                        ',' + Volt.i18n.t('TV_SID_BUTTON'));

                    this.bFirstFocus = false;
                } else {
                    CommonFunctions.voiceGuide(DetailVM.getDownloadBtnName() + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                }
            } else {
                this.ratingBtn.setFocus();
                this.StarOnURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_on_f.png'),
                this.StarOffURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_off_f.png'),
                this.StarHalfUrl = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_half_f.png'),
                this.updateRatingBtn();

                EventMediator.trigger('EVENT_SHOW_TOOLTIP', widget);

                CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_RATING_POINT') + ',' + Volt.i18n.t('TV_SID_BUTTON'));
            }
        }
    },

    /**
     * When blured on button, changed border
     * @method
     * @memberof ButtonsView
     * @param  {object}  widget  focued widget
     */
    onBlur: function (widget) {
        if (widget) {

            if (widget.id == 'download_button_widget') {
                //this.downloadBtn.killFocus();//DF141204-01069 Lock the app Detail page - open selected button flashes.
            } else {
                this.StarOnURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_on.png'),
                this.StarOffURL = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_off.png'),
                this.StarHalfUrl = Volt.getRemoteUrl('images/1080/common/btn_icon_like_star_half.png'),
                this.updateRatingBtn();

                EventMediator.trigger('EVENT_HIDE_TOOLTIP');
                //this.hideToolTip(widget);
            }
        }
    },

    escapeHtml: function (descriptionText) {

        var escapeText = descriptionText;

        if (escapeText) {

            escapeText = escapeText.replace(/\n\s+/g, '\n');
            escapeText = escapeText.replace(/\n/g, '\n');
            escapeText = escapeText.replace(/\t/g, '\n');

            escapeText = escapeText.replace(/<br\s*\/?>/gim, '\n'); //match<br />

            escapeText = escapeText.replace(/<p\s*>/gim, ''); //match<p>
            escapeText = escapeText.replace(/<\/p>/gim, ''); //matach</p>
        }

        return escapeText;
    },
});


var ScreenshotsView = Volt.BaseView.extend({
    parent: null, // Parent View

    gridListView: null, // Grid List View
    viewList: null, // Sub Views

    /**
     * Initialize DetailView
     * @name ScreenshotsView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render screenshot images
     * @method
     * @memberof DetailView
     */
    render: function () {
        Volt.log("[detail-view.js ::ScreenshotsView @render] screenshotList: " + JSON.stringify(DetailVM.get('screenshotList')));

        var grid = null;

        if (DetailVM.get('screenshotList').length > 0) {

            this.gridListView = this.initScreenShotGrid();

            if (this.gridListView) {
                grid = this.gridListView.widget;

                // Add to Nav Candidate List
                Volt.Nav.addItem(grid, true);

                // Nav Rules
                grid.loopRightFlag = false;
                grid.loopLeftFlag = false;
                Volt.Nav.setNextItemRule(grid, 'left', grid);

                grid.showWithAnimation();
            }
        }

        this.widget = grid;
        return this;
    },

    remove: function () {
        Volt.log('[detail-view.js ::ScreenshotsView @remove]');
        
        Volt.Nav.clearNextItemRule(this.widget);
        Volt.Nav.clearNextItemRule(this.widget);
        
        var i
        for (i in this.viewList) {
            this.viewList[i].remove();
            this.viewList[i] = null;
        }
        this.viewList = null;

        if (this.gridListView) {
            this.gridListView.remove();
            this.gridListView = null;
        }

        this.parent = null;
        this.widget = null;
    },

    show: function () {
        if (this.widget) {
            Volt.Nav.addItem(this.widget, true);
            this.widget.showWithAnimation();
        }
    },

    hide: function () {
        if (this.widget) {
            this.widget.hide();
            Volt.Nav.removeItem(this.widget, true);
        }
    },

    ////////////////////////////////////////////////////////////////////////////

    initScreenShotGrid: function () {
        var self = this;

        var gridTemplate = _.clone(Template.screenShotGridList);
        gridTemplate.parent = this.parent.widget.getDescendant('detail-screenshot-area');

        this.viewList = new Array();

        Volt.log('initScreenShotGrid itemWidth:' + gridTemplate.itemWidth);
        var gridListView = new GridListView({
            gridListControlParam: gridTemplate,
            thumbnailStyle: GridListTemplate.THUMB_SCREENSHOT,
            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[initScreenShotGrid] onDrawLoadData ' + data._index);
                    var model = data.model;

                    var iScreenShotView = new ScreenshotView(model, null);
                    iScreenShotView.render(data._index, thumbnail);
                    self.viewList[data._index] = iScreenShotView;
                },
                onDrawUpdateData: function (thumbnail, data) {},
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[initScreenShotGrid] onDrawUnloadData');
                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }

                    //// @xiaojun.wang|20150120: Fix DF150119-00713
                    delete self.viewList[data._index];
                },
                onGridFocus: function (wzFocused) {},
                onGridBlur: function (wzFocused) {},
                onFocusChangeStart: function (wzFrom, wzTo) {},
                onFocusChanged: function (wzFrom, wzTo, fromindex, toindex, list) {
                    Volt.log('[initScreenShotGrid] onFocusChanged');

                    var range = list.getOnScreenRange();
                    var startIndex = range.startItemIndex;
                    var endIndex = range.endItemIndex;

                    var focusIndex = toindex;

                    if (self.parent['Buttons'].downloadBtnBG.custom.focusable == false) {
                        Volt.Nav.setNextItemRule(list, 'down', self.parent['Buttons'].ratingBtnBG);
                    } else {
                        //modify focus policy
                        if (startIndex == focusIndex) {
                            Volt.Nav.setNextItemRule(list, 'down', self.parent['Buttons'].downloadBtnBG);
                            Volt.log('[DetailView] setNextItemRule  downloadBtnBG ');
                        } else {
                            Volt.Nav.setNextItemRule(list, 'down', self.parent['Buttons'].ratingBtnBG);
                            Volt.log('[DetailView] setNextItemRule   ratingBtnBG');
                        }
                    }

                    if (wzTo) {
                        var voiceText = Volt.i18n.t('TV_SID_MIX_IMAGE_THUMBNAIL').replace('<<A>>', String(toindex + 1));
                        if (wzFrom == null) {
                            voiceText = Volt.i18n.t('TV_SID_PHOTO_LIST') + ',' +
                                Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', DetailVM.get('screenshotList').length) +
                                ', ' + Volt.i18n.t('TV_SID_MIX_IMAGE_THUMBNAIL').replace('<<A>>', String(toindex + 1));
                        }
                        CommonFunctions.voiceGuide(voiceText);
                    }


                },
                onItemPress: function (wz, itemData) {
                    Volt.log('[initScreenShotGrid] @@@@ onItemPress' + itemData.itemIndex);
                    /*Backbone.history.navigate('detail/popup/screenShot/' + itemData.itemIndex, {
                        trigger: true
                    });*/
                    ScreenShotPhotoPlayer(itemData.itemIndex);
                    self.parent.screenShotViewShow = true;

                    Volt.KpiMapper.addEventLog('SCREENSHOT');
                },

                onEnterKeyLongPressed: function () {},

                onFocusPolicy: function (list) {
                    Volt.log('[initScreenShotGrid] @@@@ onFocusPolicy self.parent.focusButtonId = ' + self.parent.focusButtonId);
                    if(self.parent.focusButtonId === ''){
                        return;
                    }
                    var range = list.getOnScreenRange();
                    var startIndex = range.startItemIndex;
                    var endIndex = range.endItemIndex;

                    var itemIdx = list.getFocusItemIndex();
                    var focusIndex = itemIdx.itemIndex;
                    var groupIndex = itemIdx.groupIndex;

                    if (endIndex - startIndex >= 1) {
                        if (self.parent.focusButtonId == 'rating_button_widget') {
                            if (endIndex - startIndex == 1) {
                                if (focusIndex != startIndex + 1) {
                                    list.setFocusItemIndex(groupIndex, startIndex + 1);
                                }
                            } else {
                                if (focusIndex != startIndex + 2) {
                                    list.setFocusItemIndex(groupIndex, startIndex + 2);
                                }
                            }
                        } else if (self.parent.focusButtonId == 'download_button_widget') {
                            if (focusIndex != startIndex) {
                                list.setFocusItemIndex(groupIndex, startIndex);
                            }
                        }
                    }

                    if (self.parent.focusButtonId == 'detail-more-button') {
                        list.setFocusItemIndex(groupIndex, endIndex);
                    }

                    self.parent.focusButtonId = '';
                },

            },
            bShowScroll: false,

        });
        Volt.log('initScreenShotGrid data:#################' + JSON.stringify(DetailVM.get('screenshotList')));

        var screenShotCollection = this.getScreenShotCollection();

        return gridListView.render(screenShotCollection);
    },

    getScreenShotCollection: function () {
        Volt.log("DetailVM.get('screenshotList')[i]:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        var screenShotArray = new Array();
        for (var i = 0; i < DetailVM.get('screenshotList').length; i++) {
            Volt.log("DetailVM.get('screenshotList')[i]:" + DetailVM.get('screenshotList')[i]);
            screenShotArray[i] = {};
            screenShotArray[i].icon = DetailVM.get('screenshotList')[i];
            Volt.log('screenShotArray[i].icon' + screenShotArray[i].icon);
        };
        var ScreenShotListModel = Backbone.Model.extend({
            defaults: {
                'icon': null,
            },
        });
        var screenShotCollection = Backbone.Collection.extend({
            model: ScreenShotListModel,
        });
        var screenShot = new screenShotCollection;
        screenShot.add(screenShotArray);
        return screenShot;
    },
});

var RelatedAppsView = Volt.BaseView.extend({
    parent: null, // Parent View

    gridListView: null, // Grid List View
    grid: null,
    viewList: null, // Sub Views

    /**
     * Initialize DetailView
     * @name ScreenshotsView
     * @constructs
     */
    initialize: function (options) {
        this.parent = options.parent;
    },

    /**
     * Render related apps list
     * @method
     * @memberof DetailView
     */
    render: function () {
        Volt.log("[detail-view.js ::RelatedAppsView @render]");

        this.widget = this.parent.widget.getChild('detail-list-area');
        
        var relatedAppText = Volt.loadTemplate(Template.relatedText, null, this.widget);

        //add by lihao.zha@20150227, to fix reverse osd pos error
        relatedAppText.x = Template.relatedText.x;
        var grid = null;

        if (DetailVM.get('appInfoVMCollection').length > 0) {

            this.gridListView = this.initGridListView();

            if (this.gridListView) {
                grid = this.gridListView.widget;

                // Add to Nav Candidate List
                Volt.Nav.addItem(grid, true);

                grid.showWithAnimation();

                if (Backbone.history.isHistoryBack) {
                    if (DetailVM.get('lastIndex') !== undefined) {
                        grid.setFocusItemIndex(0, DetailVM.get('lastIndex'));
                        Volt.Nav.focus(grid);
                    } else {
                        EventMediator.trigger('EVENT_DETAIL_SET_BUTTON_FOCUS', true);
                    }
                }
            }
        }

        this.grid = grid;
        return this;
    },

    remove: function () {
        Volt.log('[detail-view.js ::RelatedAppsView @remove]');
        
        // Remove Rules
        Volt.Nav.clearNextItemRule(this.grid);
        
        var i
        for (i in this.viewList) {
            this.viewList[i].remove();
            this.viewList[i] = null;
        }
        this.viewList = null;

        if (this.gridListView) {
            this.gridListView.remove();
            this.gridListView = null;
        }
        this.grid = null;
        this.parent = null;
    },

    show: function () {
        this.widget && this.widget.show();
        
        if (this.grid) {
            Volt.Nav.addItem(this.grid, true);
            this.grid.showWithAnimation();
        }
    },

    hide: function () {
        this.widget && this.widget.hide();
        
        if (this.grid) {
            this.grid.hide();
            Volt.Nav.removeItem(this.grid, true);
        }
    },
    
    initGridListView: function () {

        var self = this;
        //var gridTemplate = _.clone(Template.setGridList);
        
        var gridTemplate = _.clone(GridListTemplate.getGridTemplate('GRID_RELATED'));
        gridTemplate.parent = this.widget;
        
        this.viewList = [];

        var gridListView = new GridListView({
            gridListControlParam: gridTemplate,
            thumbnailStyle: GridListTemplate.THUMB_RELATED,
            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[DetailView] onDrawLoadData ' + data._index);
                    var model = data.model;

                    var iRelatedAppView = new RelatedAppView(model, null);
                    iRelatedAppView.render(data._index, thumbnail);
                    self.viewList[data._index] = iRelatedAppView;
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.log('[DetailView] onDrawUpdateData');
                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[DetailView] onDrawUnloadData');
                    var VM = data.model;

                    if (VM) {
                        VM.destroyView();
                    }
                    //// @xiaojun.wang|20150120: Fix DF150119-00713
                    delete self.viewList[data._index];
                },
                onGridFocus: function (wzFocused) {
                    Volt.log('[DetailView] onGridFocus');
                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_FOCUS');
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.log('[DetailView] onGridBlur');
                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo, fromindex, toindex, list) {
                    Volt.log('[DetailView] onFocusChanged');

                    var range = list.getOnScreenRange();
                    var startIndex = range.startItemIndex;
                    var endIndex = range.endItemIndex;

                    var focusIndex = toindex;


                    if (wzTo) {
                        var voiceText = wzTo.customTitle;
                        if (wzFrom == null) {
                            voiceText = Volt.i18n.t('TV_SID_USER_THIS_APP_DOWNLOADED') + ',' +
                                Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', DetailVM.get('appInfoVMCollection').length) +
                                ' ' + wzTo.customTitle;
                        }
                        CommonFunctions.voiceGuide(voiceText);

                        var parent = self.parent;
                        
                        if (parent['Buttons'].downloadBtnBG.custom.focusable == false) {
                            Volt.Nav.setNextItemRule(list, 'up', parent['Buttons'].ratingBtnBG);
                        } else {
                            //modify focus policy
                            if ( Volt.width == 2560 ){
                                
                                if ((endIndex - startIndex <= 6) || (focusIndex <= (startIndex + 6))) {
                                    Volt.Nav.setNextItemRule(list, 'up', parent['Buttons'].downloadBtnBG);
                                    Volt.log('[DetailView] setNextItemRule  downloadBtnBG ');
                                } else if (focusIndex > (startIndex + 6)) {
                                    Volt.Nav.setNextItemRule(list, 'up', parent['Buttons'].ratingBtnBG);
                                    Volt.log('[DetailView] setNextItemRule   ratingBtnBG');
                                }
                            }else{
                                if ((endIndex - startIndex <= 5) || (focusIndex <= (startIndex + 4))) {
                                    Volt.Nav.setNextItemRule(list, 'up', parent['Buttons'].downloadBtnBG);
                                    Volt.log('[DetailView] setNextItemRule  downloadBtnBG ');
                                } else if (focusIndex > (startIndex + 4)) {
                                    Volt.Nav.setNextItemRule(list, 'up', parent['Buttons'].ratingBtnBG);
                                    Volt.log('[DetailView] setNextItemRule   ratingBtnBG');
                                }
                            }
                        }
                    }
                },
                onItemPress: function (wz, itemData, data) {
                    Volt.log('[DetailView] onItemPress');
                    if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
                        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                        return;
                    }

                    var id = data.model.get('id'),
                        index = itemData.itemIndex;

                    if (id) {
                        print(' index is   ' + index);
                        DetailVM.cacheData(index);

                        //// xj|20141226: hide loading will call Volt.Nav.resume(), but wzLastFocused is destroyed.
                        //// Blur focus first to prevent resume() error 
                        Volt.Nav.blur();

                        Volt.setTimeout(function () {
                            Backbone.history.navigate('detail/' + id, {
                                trigger: true
                            });

                        }, 10);

                        Volt.KpiMapper.addEventLog('RELATEDAPP', {
                            d: {
                                appid: id,
                            }
                        });
                    }

                },

                onEnterKeyLongPressed: function () {

                },

                onFocusPolicy: function (list) {
                    var parent = self.parent;
                    
                    Volt.log('[DetailView] @@@@ onFocusPolicy parent.focusButtonId = ' + parent.focusButtonId);
                    
                    if(parent.focusButtonId === ''){
                        return;
                    }
                    var range = list.getOnScreenRange();
                    var startIndex = range.startItemIndex;
                    var endIndex = range.endItemIndex;

                    var itemIdx = list.getFocusItemIndex();
                    var focusIndex = itemIdx.itemIndex;
                    var groupIndex = itemIdx.groupIndex;
                    if ( Volt.width == 2560){
                        if (endIndex - startIndex >= 6) {
                            if (parent.focusButtonId == 'rating_button_widget') {
                                if (endIndex - startIndex == 6) {
                                    if (focusIndex != startIndex + 6) {
                                        list.setFocusItemIndex(groupIndex, startIndex + 6);
                                    }
                                } else {
                                    if (focusIndex != startIndex + 7) {
                                        list.setFocusItemIndex(groupIndex, startIndex + 7);
                                    }
                                }
                            } else if (parent.focusButtonId == 'download_button_widget') {
                                if (focusIndex != startIndex + 5) {
                                    list.setFocusItemIndex(groupIndex, startIndex + 5);
                                }
                            }
                        } else {
                            list.setFocusItemIndex(groupIndex, endIndex);
                        }
                    }else{
                        if (endIndex - startIndex >= 5) {
                            if (parent.focusButtonId == 'rating_button_widget') {
                                if (endIndex - startIndex == 5) {
                                    if (focusIndex != startIndex + 5) {
                                        list.setFocusItemIndex(groupIndex, startIndex + 5);
                                    }
                                } else {
                                    if (focusIndex != startIndex + 6) {
                                        list.setFocusItemIndex(groupIndex, startIndex + 6);
                                    }
                                }
                            } else if (parent.focusButtonId == 'download_button_widget') {
                                if (focusIndex != startIndex + 4) {
                                    list.setFocusItemIndex(groupIndex, startIndex + 4);
                                }
                            }
                        } else {
                            list.setFocusItemIndex(groupIndex, endIndex);
                        }
                    }
                    
                    parent.focusButtonId = '';
                },
            }
        });

        return gridListView.render(DetailVM.get('appInfoVMCollection'));
    },
    ////////////////////////////////////////////////////////////////////////////
});

/**
 * @name ScreenshotView
 */
var ScreenshotView = Volt.BaseView.extend({
    VM: null,
    thumbnail: null,

    initialize: function (model, type) {
        this.VM = model;
    },

    render: function (index, iThumbnail) {
        Volt.log('[detail-view.js ::ScreenshotView @render] index: ' + index);
        var data = this.VM.toJSON();
        var iconURL = data.icon;

        if (iThumbnail) {
            iconURL = data.icon.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_HEIGHT);

            iThumbnail.setFoveaImageScaleFactor(0.1);
            iThumbnail.setFoveaImageInterpolatorType(0);

            iThumbnail.border = {width:0, color: Volt.hexToRgb('#000000', 0)};
            iThumbnail.dim(false);
            //iThumbnail.setTTSText({text: data.title || ''});

            this.thumbnail = iThumbnail;
            this.thumbnail.setContentImage(iconURL);
            this.bindListener();
        }
        return this;
    },

    remove: function () {
        Volt.log('[detail-view.js ::ScreenshotView @remove]');
        this.unbindListener();

        // Remove all vars defined in this view to release resources
        this.thumbnail = null;
        this.VM = null;
    },

    bindListener: function () {
        //this.listenTo(this.VM, 'change', this.renderChange);     
        this.listenTo(this.VM, 'DESTROY_VIEW', this.remove);
    },

    unbindListener: function () {
        this.stopListening();
    },
});


/**
 * @name RelatedAppView
 */
var RelatedAppView = Volt.BaseView.extend({
    /** @lends RelatedAppView.prototype */
    template: GridListTemplate.getThumbnailTemplate('THUMB_RELATED'),

    thumbnail: null, // Thumbnail Widget
    thumbListener: null, // Thumbnail Listener for color pick
    /**
     * Initialize RelatedAppView
     * @name RelatedAppView
     * @constructs
     * @param {object} model each Related app model
     */
    initialize: function (model, type) {
        this.VM = model;
    },

    /**
     * Render related app
     * @method
     * @memberof RelatedAppView
     * @param {number} index  index of this relatedApp
     * @param {object} widget this widget's object
     */
    render: function (index, iThumbnail) {
        Volt.log('[RelatedAppView]index ' + index);
        var data = this.VM.toJSON();
        var self = this;
        var iconURL = data.icon;

        if (iThumbnail) {

            this.thumbnail = iThumbnail;

            if (data.icon.lastIndexOf('png') != -1) {
                iconURL = data.icon.replace("{w}", CommonDefines.ImageSize.DETAIL_PNG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.DETAIL_PNG_ICON_HEIGHT);
            } else {
                iconURL = data.icon.replace("{w}", CommonDefines.ImageSize.DETAIL_JPG_ICON_WIDTH).replace("{h}", CommonDefines.ImageSize.DETAIL_JPG_ICON_HEIGHT);
            }
            
            this.thumbnail.setContentImage(iconURL);
            this.thumbnail.setInformationText("text1",data.title ? data.title : '');

            // Update downloaded icon state
            this.update(data.isDownloaded, data.title);

            this.thumbListener = new ThumbnailListener;
            this.thumbListener.onImageReady = function (thumbnail, id, success) {
                thumbnail.border = {width:0, color: Volt.hexToRgb('#000000', 0)};
                if (success == true) {
                    if (!DeviceInfoModel.get('highContrast')) {
                        var informationColorpick = thumbnail.getInformationColorPicking();
                        thumbnail.color = {
                            r: informationColorpick.r,
                            g: informationColorpick.g,
                            b: informationColorpick.b,
                            a: 255
                        };

                        thumbnail.setInformationColor({
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 20.4
                        });
                    }
                } else { // parse false, set default image instead
                    Volt.log("********************");
                    thumbnail.timeId = Volt.setTimeout(function () {
                        thumbnail.setContentImage(GridListTemplate.defaultScreenShot); //getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                        thumbnail.timeId = null;
                    }, 0);
                }
            };

            this.thumbnail.addThumbnailListener(this.thumbListener);
            this.thumbnail.setDimBackgroundColor({
                r: 0,
                g: 0,
                b: 0,
                a: 153
            });

            this.thumbnail.dim(false);
            this.thumbnail.setProgressRange(0, 100);

            this.setWidget(this.thumbnail);
            this.thumbnail.customTitle = data.title || '';
            //this.thumbnail.setTTSText({text: data.title || ''});
            this.bindListener();
        }
        return this;
    },
    
    remove: function () {
        Volt.log('[RelatedAppView @remove]');
        this.unbindListener();
        
        if (this.thumbnail) {
            this.thumbnail.removeThumbnailListener(this.thumbListener);
            
            if (this.thumbnail.timeId) {
                Volt.clearTimeout(this.thumbnail.timeId);
                this.thumbnail.timeId = null;
            }

            this.thumbnail = null;
        }
        if (this.thumbListener) {
            this.thumbListener.destroy();
            this.thumbListener = null;
        }
    },

    /**
     * show view
     * @method
     */
    show: function () {

        var data = this.VM.toJSON();
        var template = '';
        var id = '';

        if (this.appInfoProgressView == null) {
            this.appInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
        }

        this.appInfoProgressView.show();
    },

    update: function (bDownloaded, text) {
        var textwidth = this.template.information.text1.width;
        if (bDownloaded) {
            this.thumbnail.setElementAllocation('information-text1', {
                width: textwidth
            });
            this.thumbnail.visualizeInformationIcon(true, 'icon1');
        } else {
            textwidth += this.template.information.icon1.width;
            this.thumbnail.setElementAllocation('information-text1', {
                width: textwidth
            });
            this.thumbnail.visualizeInformationIcon(false, 'icon1');
        }

    },

    bindListener: function () {
        this.listenTo(this.VM, 'change', this.renderChange);
        this.listenTo(this.VM, 'DESTROY_VIEW', this.remove);
        this.showProgressBar();
    },

    unbindListener: function () {
        this.stopListening();
        this.hideProgressBar();
    },

    /**
     * When select related app, go to detail screen.
     * @method
     * @memberof RelatedAppView
     * @param {number} index  index of this relatedApp
     */
    renderChange: function (changedModel) {
        if (_.keys(changedModel.changed)[0] == 'isDownloaded') {
            // Update downloaded icon state
            this.update(changedModel.changed.isDownloaded);
        }
    },

    showProgressBar: function () {
        try {
            if (this.AppInfoProgressView == null) {
                this.AppInfoProgressView = new AppInfoProgressView(this.thumbnail, this.VM);
            }
            this.AppInfoProgressView.updateThumbnail(this.thumbnail);
            this.AppInfoProgressView.show();
        } catch (e) {

        }
    },
    /**
     * hide view
     * @method
     */
    hideProgressBar: function () {

        if (this.AppInfoProgressView) {
            //            this.AppInfoProgressView.hideProgressBar();
            this.AppInfoProgressView.remove();

        }
    },
});
function ScreenShotPhotoPlayer(index){
    var args = {
        "app_id"               : "org.volt.apps",
        "play_index"           : index,
        "need_slideshow"       : false,
        "xwindow_id"           : String(VDUtil.getXWindowID()),
        "function_thumbnail"   : false, 
        "items" : []
    };
    var imageURL = null;
    var photoPlayerSrc = null;
    for( var i = 0; i < Models.detailModel.get('screenshotList').length; i++){
        imageURL = Models.detailModel.get('screenshotList')[i];
        photoPlayerSrc = imageURL.replace("{w}", CommonDefines.ImageSize.SCREENSHOT_LARGE_WIDTH).replace("{h}", CommonDefines.ImageSize.SCREENSHOT_LARGE_HEIGHT);
        args.items.push({
            "file_name" : DetailVM.get('title'),
            "file_date" : "",
            "file_size" : "",
            "file_location" : "",
            "file_path" : photoPlayerSrc
        });
    }

    var jsonData = JSON.stringify(args);
    Volt.log('jsonData:::::' + jsonData);
    var Play_list = {
        "play_list_data" : jsonData
    };
    var aulApp2 = new Aul();
    aulApp2.launchApp("org.tizen.photo-player-tv", Play_list);
    Volt.terminatePhotoPlayerPID = true;
};
exports = DetailView;
