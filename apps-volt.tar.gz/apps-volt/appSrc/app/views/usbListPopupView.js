/** 
 * @author hocheol lee (hocheol7.lee@opentide.com)
 * @fileoverview This module show connected usb list in tv.
 * @date    2014/07/21 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require('modules/VoltJSON.js');

// Include Template
var Template = Volt.require('app/templates/1080/usbListPopupTemplate.js');

// Include Event Mediator
var EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js');

// Include External Stroage Collection
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
// var ExternalStorageModel = Volt.require("app/models/externalStorageModel.js");
var Models = Volt.require("app/models/models.js");
var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var Singlelist = Volt.require('app/views/singlelineListView.js');
Volt.mapWidget('Singlelist', Singlelist);
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var dataPointers = [];
/**
 * @name USBListPopupView
 */
var USBListPopupView = Volt.BaseView.extend({
    /** @lends USBListPopupView.prototype */
    template: Template.container,
    selectedUSBView: null,
    usbListView: null,
    mouseListener: null,
    /**
     * Initialize USBListPopupView
     * @name USBListPopupView
     * @constructs
     */
    initialize: function () {
        Volt.log("[USBListPopupView.js] initialize");
    },

    /**
     * Render this widget
     * @method
     * @memberof USBListPopupView
     */
    render: function () {
        Volt.log("[USBListPopupView.js] render");
    },

    /**
     * Show this widget, fetch usbListm and bind event
     * @method
     * @memberof USBListPopupView
     */
    show: function (viewInfo) {
        Volt.log("[USBListPopupView.js] show(), viewInfo: " + viewInfo);
        var usbListInfo = JSON.parse(viewInfo);
        Models.externalStorageModel.set("usbList", []);
        this.setWidget(Volt.loadTemplate(this.template));
        this.showHeaderCover();
        Volt.Nav.setRoot(this.widget);
        this.widget.show();
        Models.externalStorageModel.updateUSBList();
        this.renderUSBListPopup(usbListInfo);
        // Volt.Nav.bindListener( this.widget, 'keydown', _.bind(this.onKeyDown,this) );      
    },
     showHeaderCover: function () {
         var upCoverWidget = this.widget.getDescendant('usbList-popup-upcover');
         upCoverWidget.addEventListener('OnMouseOver', this._blockMouse);
         
         var downCoverWidget = this.widget.getDescendant('usbList-popup-downcover');
         downCoverWidget.addEventListener('OnMouseOver', this._blockMouse);
         
    },
    hideHeaderCover: function () {
         var upCoverWidget = this.widget.getDescendant('usbList-popup-upcover');
         upCoverWidget.removeEventListener('OnMouseOver', this._blockMouse);
         
         var downCoverWidget = this.widget.getDescendant('usbList-popup-downcover');
         downCoverWidget.removeEventListener('OnMouseOver', this._blockMouse);  
    },
     _blockMouse: function () {
             
    },
    /**
     * Render usbList popup
     * @method
     * @memberof USBListPopupView
     */
    renderUSBListPopup: function (viewInfo) {
        Volt.log('[USBListPopupView.js] renderUSBListPopup');

        if (Models.externalStorageModel.get('usbList').length > 0) {
            this.renderTitle();
            this.renderLine();
            this.renderSelectedUSB();
            this.renderButton();
            /*
            var appID = '';
            if( viewInfo && viewInfo.appid ){
                appID = viewInfo.appid;
            }
    */
            this.renderUSBList(viewInfo);

            var showArrow = false;
            if ( Models.externalStorageModel.get('usbList').length > 5 )
                showArrow = true;

            this.setArrow(showArrow );
        }
    },

    /**
     * create titleView for rendering title
     * @method
     * @memberof USBListPopupView
     */
    renderTitle: function () {
        Volt.log('[USBListPopupView.js] renderTitle');
        var container = this.widget.getChild(0).getChild('usbList-title-container');
        container.addChild(Volt.loadTemplate(Template.title));
    },

    /**
     * create lineView for rendering line
     * @method
     * @memberof USBListPopupView
     */
    renderLine: function () {
        Volt.log('[USBListPopupView.js] renderLine');
        var container = this.widget.getChild('usbList-popup').getChild('usbList-line-container');
        container.addChild(Volt.loadTemplate(Template.line));
    },

    /**
     * create selectedUSBView for rendering selected usb info
     * @method
     * @memberof USBListPopupView
     */
    renderSelectedUSB: function () {
        Volt.log('[USBListPopupView.js] renderSelectedDevice');
        var container = this.widget.getChild('usbList-popup').getChild('usbList-selectedUSBInfo-container');
        this.selectedUSBView = new SelectedUSBView();
        container.addChild(this.selectedUSBView.render(container).widget);
    },

    /**
     * create usbListView for rendering selected usb info
     * @method
     * @memberof USBListPopupView
     */
    renderUSBList: function (appID) {
        Volt.log('[USBListPopupView.js] renderUSBList');
        var container = this.widget.getChild('usbList-popup').getChild('usbList-list-container');
        this.usbListView = new USBListView(appID);
        this.usbListView.render(container);
        Volt.Nav.focus(this.usbListView.usbList);
        Volt.Nav.setNextItemRule(this.widget.getDescendant('usbList-button-container'), 'left', this.usbListView.usbList);
    },
    /*
    updateUSBList : function(){ 
        if( this.usbListView ){
            this.usbListView.destroy();
            Models.externalStorageModel.updateUSBList();
            this.renderUSBList();
        }
    },
    */

    /**
     * create buttonView for rendering cancel button
     * @method
     * @memberof USBListPopupView
     */
    renderButton: function () {
        Volt.log('[USBListPopupView.js] renderButton');
        var container = this.widget.getChild(0).getChild('usbList-button-container');
        this.cancelButtonView = new ButtonView();
        this.cancelButtonView.render(container);
    },

    setArrow: function (flag) {
        if (flag == true) {
            Volt.log("[USBListPopupView.js]setArrow%%%%%%%%%  true  %%%%%");

            this.widget.getDescendant('arrow_up').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png');
            this.widget.getDescendant('arrow_down').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png');


            this.mouseListener = new MouseListener;

            this.mouseListener.onMousePointerIn = function (actor, event) {
                if ( this.usbListView && this.usbListView.usbList ){
                    Volt.Nav.focus(this.usbListView.usbList);
                }

                if (actor.id == 'arrow_down' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png');
                }
                if (actor.id == 'arrow_up' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png');
                }
            }.bind(this);
            this.mouseListener.onMousePointerOut = function (actor, event) {
                if (actor.id == 'arrow_down' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png');
                }
                if (actor.id == 'arrow_up' && actor.src == Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png')) {
                    actor.src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png');
                }
            };
            this.mouseListener.onMouseButtonReleased = function (actor, event) {
                Volt.log('onMouseButtonReleased');
                if (actor.id == 'arrow_up') {
                    this.usbListView.usbList.moveFocus('Up');
                } else {
                    this.usbListView.usbList.moveFocus('Down');
                }
            }.bind(this);

            this.widget.getDescendant('arrow_up').addMouseListener(this.mouseListener);
    		this.widget.getDescendant('arrow_down').addMouseListener(this.mouseListener);

            
        } else {
            this.widget.getDescendant('arrow_up').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_d.png');
            this.widget.getDescendant('arrow_down').src = Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_d.png');
        }

      
	},


    /**
     * Hide this widget
     * @method
     * @memberof USBListPopupView
     */
    hide: function () {
        Volt.log('[USBListPopupView.js] hide');
        this.stopListening(Models.externalStorageModel);
        this.widget.hide();
        if (this.usbListView) {
            this.usbListView.stopListening();
        }
        if ( this.selectedUSBView ){
            this.selectedUSBView.stopListening();     
        }
        this.hideHeaderCover();
        this.destroy(this.widget);
    },

    /**
     * Destory this widget
     * @method
     * @memberof USBListPopupView
     */
    destroy: function (widget) {
        Volt.log('[USBListPopupView.js] destroy');
        this.widget.destroy();
        this.widget = null;

        if ( this.usbListView )
        {
            this.usbListView.listener.destroy();
            this.usbListView.listener = null;

            this.usbListView.usbList = null;
            this.usbListView  = null;
            
        }

        if ( this.cancelButtonView ){

            this.cancelButtonView.btnListener.destroy();
            this.cancelButtonView.btnListener = null;

            this.cancelButtonView = null;
        }

        if ( this.mouseListener ){
            this.mouseListener.destroy();
            this.mouseListener = null;
        }

        
        dataPointers = [];
    },



});
/**
 * @name SelectedUSBView
 */
var SelectedUSBView = Volt.BaseView.extend({
    /** @lends SelectedUSBView.prototype */
    template: Template.usbItem,
    usbName: null,
    usbStorage: null,

    /**
     * Initialize selectedUSBView
     * @name SelectedUSBView
     * @constructs
     */
    initialize: function () {
        this.listenTo(EventMediator, 'EVENT_UPDATE_SELECTED_USB', _.bind(this.updateInfo, this));
    },

    /**
     * Render line of usbList popup
     * @method
     * @memberof SelectedUSBView
     * @param object    container   parent widget
     */
    render: function (container) {
        this.setWidget(Volt.loadTemplate(this.template,null,container));
        this.usbName = this.widget.getChild("usbList-usb-name");
        this.usbStorage = this.widget.getChild("usbList-usb-storage");

        this.updateInfo({
            name: Models.externalStorageModel.get('usbList')[0].name,
            availableSize: convertMemory(Models.externalStorageModel.get('usbList')[0].availableSize),
            totalSize: convertMemory(Models.externalStorageModel.get('usbList')[0].totalSize)
        });
        return this;
    },

    /**
     * Update focued usb information
     * @method
     * @memberof SelectedUSBView
     * @param {number}    idx   focused index number of list
     */
    updateInfo: function (param) {
        Volt.log('[USBListPopupView.js]  param.name + ' + param.name);
        this.usbName.text = param.name;
        this.usbStorage.text = param.availableSize + '/' + param.totalSize;
    },
});

/**
 * @namespace USBListPopupView
 * @name ButtonView
 */
var ButtonView = Volt.BaseView.extend({
    /** @lends ButtonView.prototype */
    template: Template.button,
    btnListener: new ButtonListener(),

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        //'NAV_BLUR': 'onBlur'
    },

    /**
     * Initialize ButtonView
     * @name ButtonView
     * @constructs
     */
    initialize: function () {},

    /**
     * Render button
     * @method
     * @memberof ButtonView
     */
    render: function (Parent) {
        var btnStyle = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resolution: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
        }
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);
        this.cancelButton = Volt.loadTemplate(this.template, btnStyle, Parent);
        this.cancelButton.addListener(this.btnListener);
        this.setWidget(Parent);
        return this;
    },

    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onSelect: function (widget) {
        if (widget) {
            // EventMediator.trigger(CommonDefines.Event.CONNECT_USB);
            //widget.border  = {
            //    width : 2 , color :  Volt.hexToRgb('#ffffff', 95)
            //}; 
            Backbone.history.back();
        }
    },

    /**
     * When focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        if (widget && widget.id == 'usbList-button-container') {
            this.cancelButton.setFocus();
            CommonFunctions.voiceGuide(this.cancelButton.text() + ',' + Volt.i18n.t('TV_SID_BUTTON'));
        }
    },

    /**
     * When blured focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param   {object}  widget  blured widget
     */
    onBlur: function (widget) {
        if (widget && widget.id == 'usbList-button-container') {
            //this.cancelButton.killFocus();
        }
    }
});

/**
 * @name USBListView
 */
var USBListView = Volt.BaseView.extend({
    /** @lends USBListView.prototype */
    usbList: null,
    appID: '',
    listener: null,
    /**
     * Initialize USBListView
     * @name USBListView
     * @constructs
     */
    initialize: function (appInfo) {
        this.listenTo(EventMediator, CommonDefines.Event.CONNECT_USB, this.updateUSBList);
        this.listenTo(EventMediator, CommonDefines.Event.DISCONNECT_USB, this.updateUSBList);
        this.appID = appInfo ? appInfo.appid : '';
        this.fileSize = appInfo ? appInfo.fileSize : '';;
        this.fileDecompSize = appInfo ? appInfo.fileDecompSize : '';
        Volt.log("USBListView this.appID  is " + this.appID);
        Volt.log("USBListView this.fileSize is " + this.fileSize);
        Volt.log("USBListView this.fileDecompSize is " + this.fileDecompSize);
        
    },

    events: {
        //'NAV_SELECT ':'onSelect',
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    onFocus: function (widget) {
        Volt.log("USBListView onFocus");
        if (widget) {
            if(this.usbList){
                this.usbList.enableFocus();
                this.usbList.setFocus();
                this.usbList.showFocus("true");
                this.usbList.getFocus = true;     
            } 
        }
    },

    onBlur: function (widget) {
        Volt.log("USBListView onBlur");
        if (this.usbList  && widget ) {
            this.usbList.hideFocus("true");
            this.usbList.getFocus = false;       
        }
    },
    /**
     * Render usbList to use ContextMenu
     * @method
     * @memberof USBListView
     * @param  {object}  widget  focued widget
     */
    render: function (parent) {
        Volt.log('[USBListView] render');

        this.usbList = initList(parent,this.fileSize,this.fileDecompSize);
        
        this.listener = this.usbList.Listener;
        this.usbList.appID = this.appID;
        this.setWidget(this.usbList);
        parent.addChild(this.usbList);        
        Volt.Nav.reload();
        return this;
    },

    destroy: function () {
        if (this.usbList) {
            this.usbList.destroy();
        }
    },

    updateUSBList: function () {
        Volt.log('[USBListView] updateUSBList');
        if (this.usbList) {
            var result = Models.externalStorageModel.updateUSBList();
            if (result && result.storages) {
                var nList = result.storages.length;

                if (nList == 0) {
                    Volt.log('[USBListView] Backbone.history.back');
                    this.stopListening();
                    Backbone.history.back();
                } else {
                    Volt.log('[USBListView111] focusIndex : ' + this.usbList.focusItemIndex);
                    Volt.log('[USBListView] deleteItem count : ' + this.usbList.numOfItem());
                    if(this.usbList.numOfItem() == result.storages.length){
                          Volt.log('[USBListView] do not need update usblist view');
                          return;
                    }
                    this.usbList.deleteItem({
                        fromItem: 0,
                        itemNum: this.usbList.numOfItem()
                    });

                    Volt.log('[USBListView] addItem count : ' + result.storages.length);
                    this.usbList.addItem({
                        itemNum: result.storages.length,
                        itemSpace: Volt.height * 0.066667
                    });
                    dataPointers = [];
                    for (var i = 0; i < nList; i++) {
                        var data = new Data();
                        data.name = result.storages[i].name;
                        data.mountPath = result.storages[i].mountPath;
                        data.fileSystem = result.storages[i].fileSystem;
                        data.availableSize = convertMemory(result.storages[i].availableSize);
                        data.totalSize = convertMemory(result.storages[i].totalSize);
                        // Avoid garbage collecting Halo Data instances
                        dataPointers.push(data);
                        this.usbList.addData(data);
                    }
                    this.usbList.loadData();
                    this.usbList.focusItemIndex = 0;
                    var params = {
                        name: result.storages[0].name,
                        availableSize: convertMemory(result.storages[0].availableSize),
                        totalSize: convertMemory(result.storages[0].totalSize),
                        fileSystem: result.storages[0].fileSystem
                    }
                    CommonFunctions.voiceGuide(params.name + ',' + params.totalSize + ',' + params.fileSystem);
                    EventMediator.trigger('EVENT_UPDATE_SELECTED_USB', params);
                }
            }
        }
    },
});

function convertMemory(memory) {
    if (memory) {
        return parseFloat(memory / 1048576).toFixed(2) + "GB";
    } else {
        return 0;
    }
};
function setSuitablyUnit(size) { //the unit of size is B
        Volt.log("[usbListPopupView.js] setSuitablyUnit");
        var COUNTMB = 1024;
        var COUNTGB = 1024 * 1024;
        var unit = 'B';
        if (size >= COUNTGB) {
            size /= COUNTGB;
            unit = 'GB';
        } else if (size >= COUNTMB) {
            size /= COUNTMB;
            unit = 'MB';
        }
        size = parseFloat(size).toFixed(2);
        return {
            size: size,
            unit: unit
        };
};
function  checkUsbListMemory (data,fileSize,fileDecompSize) {  
   Volt.log("[usbListPopupView.js] fileSize is " + fileSize);
   Volt.log("[usbListPopupView.js] fileDecompSize is " + fileDecompSize);
    var nMegabyte = 1048576;
    var needInstallingSize = parseInt(fileSize) + parseInt(fileDecompSize);
    needInstallingSize = needInstallingSize + 10 * nMegabyte;
    needInstallingSize = Math.ceil(needInstallingSize / nMegabyte);
    var i = 0;
    if (data) {
        Volt.log("[usbListPopupView.js] checkUsbListMemory:data.availableSize is " + data.availableSize);
        Volt.log("[usbListPopupView.js] checkUsbListMemory:needInstallingSize is " + needInstallingSize);
        var tempAvailable = setSuitablyUnit(data.availableSize);
        Volt.log("[usbListPopupView.js] checkUsbListMemory:tempAvailable.size is " + tempAvailable.size*1024);
        if(parseFloat(needInstallingSize) <= (tempAvailable.size*1024)) {
            return true;
        }
    } else {
        return false;
    }
};

function initList(parent,fileSize,fileDecompSize) {
    var bFirstEnter = true;
    var list = Volt.loadTemplate(Template.list, null, parent).render().widget;
    list.autoHighContrast = false;
    list.custom = {};
    list.custom.focusable = true;
    list.getFocus = false;
    list.fileSize = fileSize;
    list.fileDecompSize = fileDecompSize;
    Volt.Nav.setNextItemRule(list, 'up', list);
    Volt.Nav.setNextItemRule(list, 'down', list);

    var storages = Models.externalStorageModel.get('usbList');

    Volt.log('storages.length - ' + storages.length);
    list.addItem({
        itemNum: storages.length ,
        itemSpace: Volt.height * 0.066667
    });

    list.setBackgroundColor(0, 0, 0, 0);
    list.enlargeFocusedItem(10, 0);
    list.shadowEffectFlag = false;
    list.setAnimationDuration("focusMove", 100);
    list.setAnimationDuration("loop", 100);
    list.foveaEffect = false;
    list.useMarginWhenFocusEdgeItem = false;
    list.show();
    var param = {  width: Volt.width * 0.423958,
                    height: Volt.height * (0.066667 * 5 ),
        };
    list.setScrollBar(param);

    list.initRenderer = function (renderer, data, parentWidth, parentHeight) {
        Volt.log('data - ' + JSON.stringify(data));
        var template = Template.deviceList;
        if ( parseInt(data.itemindex)%2 != 0){     
            Volt.log('~~~~~~~~~~~~~~~~~~~~~~~~change color - ' + data.itemindex);
            template.information.highContrast.color = {
                    r: 0x25,
                    g: 0x25,
                    b: 0x25,
                    a: 0xff
                };
        }else{
            template.information.highContrast.color = {
                    r: 0x0d,
                    g: 0x0d,
                    b: 0x0d,
                    a: 0xff
                };
        }
        
        var device = Volt.loadTemplate(template, null, renderer.root);
        renderer.thumbnail = renderer.root.getChild(0);
        
        
        renderer.thumbnail.setInformationText("text1", data.name);
		//var versionInfo = 'v'+ data.app_version + '  ' + convertDateFormat(data.updated_date);
		renderer.thumbnail.setInformationText("text2", data.totalSize + " " + data.fileSystem);


        var widgetExListener = new WidgetExListener;
        widgetExListener.onHighContrastChanged = function (widgetEx, flagHighContrast) {
            Volt.log(widgetEx + " onHighContrastChanged: " + flagHighContrast);

            if ( flagHighContrast ){
                if ( data.itemindex == list.focusItemIndex && list.getFocus ){
                    var focusrenderer = list.renderer(list.focusItemIndex);
                    if (null != focusrenderer) {
                        if (focusrenderer.thumbnail == widgetEx){
                            focusrenderer.thumbnail.setInformationColor({r: 255, g: 255, b: 255, a: 255});
                        }
                    }
                }
            }else{

                if ( data.itemindex == list.focusItemIndex && list.getFocus){
                    var focusrenderer = list.renderer(list.focusItemIndex);
                    if (null != focusrenderer) {
                        if (focusrenderer.thumbnail == widgetEx){
                            focusrenderer.thumbnail.setInformationColor({r: 255, g: 255, b: 255, a: 255});
                        }
                    }
                }else{
                    widgetEx.setInformationColor({r: 255, g: 255, b: 255, a: 0});
                    //Volt.log(widgetEx + " onHighContrastChanged: " + flagHighContrast + "  set to 255 255 255 0 ");
                }

            }
        }
        renderer.thumbnail.addWidgetExListener(widgetExListener);        

        

        renderer.thumbnail.onFocus = function () {
            //Volt.log('onFocus    HALOUtil.highContrast -     ' + HALOUtil.highContrast);
            if ( list.getFocus ){
                if ( HALOUtil.highContrast == false ){
                    
            		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.focused);
            		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.focused);
                }

                renderer.thumbnail.setInformationColor({
                    r: 255,
                    g: 255,
                    b: 255,
                    a: 255
                });
        		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_f.png");

                if(!checkUsbListMemory(data,list.fileSize,list.fileDecompSize)) {
                    Volt.log('[usbListPopupView.js] thumbnail is dim');
                    renderer.thumbnail.dim(true);
               }
            }

            
        };
        renderer.thumbnail.onNormal = function () {
            //Volt.log('onNormal    HALOUtil.highContrast -     ' + HALOUtil.highContrast);

            if (!HALOUtil.highContrast){
                renderer.thumbnail.setInformationColor({
                    r: 255,
                    g: 255,
                    b: 255,
                    a: 0
                });
            }
            
            if(!checkUsbListMemory(data,list.fileSize,list.fileDecompSize)) {
                Volt.log('[usbListPopupView.js] thumbnail is dim');
                renderer.thumbnail.dim(false);
                return;
            }
    		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_n.png");
    		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.normal);
    		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.normal);
            
        };
        renderer.thumbnail.onSelect = function () {
                //device.color = Volt.hexToRgb('#ffffff', 100);
                if(!checkUsbListMemory(data,list.fileSize,list.fileDecompSize)) {
                    Volt.log('[usbListPopupView.js] thumbnail is dim');
                    return;
                }
		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_f.png");
		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.selected);
		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.selected);


            
        };
        renderer.thumbnail.onDim = function () {
		device.color = Volt.hexToRgb('#ffffff', 0);
      
		renderer.thumbnail.setInformationIcon("icon1","images/1080/common/popup/apps_popup_icon_usb_f.png");
		renderer.thumbnail.setInformationTextColor("text1",Template.deviceInfoStyle.textColor.disabled);
		renderer.thumbnail.setInformationTextColor("text2",Template.deviceInfoStyle.textColor.disabled);
            
        };

        if(!checkUsbListMemory(data,list.fileSize,list.fileDecompSize)) {
            Volt.log('[usbListPopupView.js]renderer.thumbnail.onDim');
            renderer.thumbnail.onDim();
        }

    };
    list.onItemMouseClick = function (index) {
        list.onKeyReleased(index);
    };
    list.onKeyReleased = function (index) {
         Volt.log('onKeyReleased:click - ' + index);
        var data = list.getData(index);
         if(!checkUsbListMemory(data,list.fileSize,list.fileDecompSize)) {
            Volt.log('[usbListPopupView.js] thumbnail is dim');
            return;
        }
        
        Volt.log(' DevicesView.onSelect, this.app_id = ' + this.appID + ' ,path = ' + data.mountPath);
        var storagepath = data.mountPath;
        var nIndex = storagepath.indexOf('/');

        var usbInfo = Models.externalStorageModel.get('usbList')[index];
        usbInfo.mountPath = usbInfo.mountPath.replace('$USB_DIR', '/opt/storage/usb');
        
        Backbone.history.back();
        
        if (this.appID && usbInfo.mountPath) {
            EventMediator.trigger(CommonDefines.Event.EVENT_USB_INSTALL_APP, {
                app_id: this.appID,
            });
            AppInstallMgr.installApp(this.appID, usbInfo.mountPath);
        }
    };
    list.onItemPress = function (index) {
        Volt.log('onItemPress:click - ' + index);
    };

    list.onDrawFromFocusChangeStart = function (root, data, parentWidth, parentHeight) {
        //root.getChild(0).onNormal();
    };

    list.onDrawToFocusChangeEnd = function (root, data, parentWidth, parentHeight) {};
    list.onItemLoaded = function (singleLineList, itemIndex) {
        Volt.log("list.onItemLoaded~~~~~~");
    };

    list.onFocusChanged = function (singleList, fromIndex, toIndex) {
        Volt.log("[usbListPopupView.js]onFocusChanged fromIndex = " + fromIndex + ",toIndex = " + toIndex);
        var usbStorages = Models.externalStorageModel.get('usbList');
        Volt.log("[usbListPopupView.js]onFocusChanged dataPointers.length = " + dataPointers.length );
    	var endTotopflag = (usbStorages.length>5&&fromIndex ==(usbStorages.length-1)&&toIndex==0);
    	var topToendflag = (usbStorages.length>5&&toIndex ==(usbStorages.length-1)&&fromIndex==0);


        
        if (fromIndex >= 0 &&  !endTotopflag && !topToendflag ) {
            singleList.renderer(fromIndex).thumbnail.onNormal();
        }
        if (toIndex >= usbStorages.length) {
            return;
        }
        if (toIndex >= 0) {
            singleList.renderer(toIndex).thumbnail.onFocus();
            var params = {
                name: usbStorages[toIndex].name,
                availableSize: convertMemory(usbStorages[toIndex].availableSize),
                totalSize: convertMemory(usbStorages[toIndex].totalSize),
                fileSystem: usbStorages[toIndex].fileSystem
            };
            if (bFirstEnter) {
                CommonFunctions.voiceGuide(Volt.i18n.t('COM_SID_CHOOSE_WHERE_INSTALL_THE_APP') +
                    Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', usbStorages.length) + ',' +
                    params.name + ',' + params.totalSize + ',' + params.fileSystem);
                bFirstEnter = false;
            } else {
                CommonFunctions.voiceGuide(params.name + ',' + params.totalSize + ',' + params.fileSystem);
            }
            EventMediator.trigger('EVENT_UPDATE_SELECTED_USB', params);
        }
    }

    for (var i = 0; i < storages.length ; i++) {
        var data = new Data();
        data.name = storages[i].name;
        data.mountPath = storages[i].mountPath;
        data.fileSystem = storages[i].fileSystem;
        data.availableSize = convertMemory(storages[i].availableSize);
        data.totalSize = convertMemory(storages[i].totalSize);
        data.itemindex = i;
        
        dataPointers.push(data);
        list.addData(data);

    }
    list.loadData();

    return list;
}

exports = USBListPopupView;