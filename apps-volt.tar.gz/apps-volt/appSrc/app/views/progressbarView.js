/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview ProgressbarView
 * @date    2014/07/18 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Include libraries
var _ = Volt.require('modules/underscore.js')._;
var Q = Volt.require('modules/q.js');
var Backbone = Volt.require('lib/volt-backbone.js');
var Template = Volt.require('app/templates/1080/progressbarTemplate.js');
//var ProgressBarUI = Volt.require("UIElement/Progress.js");

var WinsetProgress = Volt.require('modules/WinsetUIElement/winsetProgress.js');
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

Volt.mapWidget('WinsetProgress', WinsetProgress);
/**
 * @name ProgressbarView
 */
var ProgressbarView = Volt.BaseView.extend({
    /** @lends ProgressbarView.prototype */
    pWidgetInfo: null,

    /**
     * initialize progress
     * @name ProgressbarView
     * @constructs
     * @param  {object} param   default param
     * @param  {object} pWidget parent widget
     */
    initialize: function (param) {

        if (param === undefined) {
            Volt.log('[ProgressbarView.js] wrong param ');
            return;
        }
        if (!param.parent) {
            Volt.log('[ProgressbarView.js] wrong parent - ');
            return;
        }
        if (!param.value) {
            param.value = 0;
        }

        this.param = param;
    },
    /**
     * render progressbar
     * @method
     * @return {widget} return this pointer
     */
    render: function () {
        Volt.log('[ProgressbarView.js] render');
        this.initProgressBar();
        return this;
    },
    /**
     * show progressbar
     * @method
     * @return {object} promise object
     */
    show: function () {
        Volt.log('[ProgressbarView.js] show');
        var deferred = Q.defer();
        if (this.progressBar) {
            this.progressBar.show();
        }
        deferred.resolve();
        return deferred.promise;
    },
    /**
     * initialize uiElement progressbar
     * @method
     */
    initProgressBar: function () {

        Volt.log("[ProgressbarView.js] initProgressBar");

        var mustache = {
            nProgressStyle: WinsetProgress.ProgressStyle.Progress_Style_A,
            nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
        };
        this.setWidget(Volt.loadTemplate(Template.bg, mustache, this.param.parent));
        this.progressBar = this.widget.getChild(0);
        this.progressBar.value = this.param.value * 100;
        this.progressBar.show();
    },
    /**
     * animate progressbar's width
     * @method
     * @param  {number} nPercent progress percent
     */
    updateProgressBar: function (nPercent) {
        if (this.progressBar && nPercent) {
            if (nPercent > 100) {
                nPercent = 100;
                // this.widget.hide();
            } else if (nPercent < 0) {
                nPercent = 0;
            }
            //this.progressBar.percentage = percent;
            this.progressBar.value = nPercent;
        }
    },
    /**
     * hide progressbar
     * @method
     * @return {object} promise object
     */
    hide: function () {
        var deferred = Q.defer();
        if (this.widget) {
            this.widget.hide();
            if (this.progressBar) {
                this.progressBar.hide();
                this.progressBar.destroy();

                this.progressBar = null;
            }
            this.widget.destroy();
            delete this.widget;
            this.widget = null;
        }
    },
    /**
     * destroy instance
     * @method
     * @param  {widget} widget progress instance
     */
    destroy: function (widget) {
        Volt.log("[ProgressbarView.js] destroy");
        if (!widget) return;
        var nChildLength = widget.getChildCount();
        if (nChildLength > 0) {
            for (var i = 0; i < nChildLength; i++) {
                this.destroy(widget.getChild(i));
            }
        }
        widget.id = '';
        delete widget;
        widget = null;
    }
});

exports = ProgressbarView;