var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var VoltJSON = Volt.require('modules/VoltJSON.js');

// Include Template
var Template = Volt.require('app/templates/1080/update-lowmemory-template.js');

// Include Event Mediator
var EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js');

// Include External Stroage Collection
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
var Models = Volt.require("app/models/models.js");
var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

/**
 * @name USBListPopupView
 */
var LowMemoryPopupView = Volt.BaseView.extend({
    /** @lends USBListPopupView.prototype */
    template: Template.container,
    TitleView: null,
    NeededView: null,
    /**
     * Initialize USBListPopupView
     * @name USBListPopupView
     * @constructs
     */
    initialize: function () {
        Volt.log("[LowMemoryPopupView.js] initialize");
    },

    /**
     * Render this widget
     * @method
     * @memberof USBListPopupView
     */
    render: function () {
        Volt.log("[LowMemoryPopupView.js] render");
    },

    /**
     * Show this widget, fetch usbListm and bind event
     * @method
     * @memberof USBListPopupView
     */
    show: function (viewInfo) {
        Volt.log("[LowMemoryPopupView.js] show(), viewInfo: " + viewInfo);
        
        viewInfo = '[{"device_path" : "tv", "need_memory" : "1224" },{"device_path" : "$USB_DIR/sdb1", "need_memory" : "76349" },{"device_path" : "$USB_DIR/sdc1", "need_memory" : "7634944" },'+
            '{"device_path" : "$USB_DIR/sdd1", "need_memory" : "7634944" },{"device_path" : "$USB_DIR/sda1", "need_memory" : "7634944" }]';
        this.neededListInfo = JSON.parse(viewInfo);
        //this.neededListInfo = viewInfo;
        Volt.log('this.neededListInfo.toString()   '+ this.neededListInfo.toString());
        this.setWidget(Volt.loadTemplate(this.template));
        this.showHeaderCover();
        Volt.Nav.setRoot(this.widget);
        this.widget.show();
        this.renderNeedlist();
    },
     showHeaderCover: function () {
         var upCoverWidget = this.widget.getDescendant('usbList-popup-upcover');
         upCoverWidget.addEventListener('OnMouseOver', this._blockMouse);
         
         var downCoverWidget = this.widget.getDescendant('usbList-popup-downcover');
         downCoverWidget.addEventListener('OnMouseOver', this._blockMouse);
         
    },
    hideHeaderCover: function () {
         var upCoverWidget = this.widget.getDescendant('usbList-popup-upcover');
         upCoverWidget.removeEventListener('OnMouseOver', this._blockMouse);
         
         var downCoverWidget = this.widget.getDescendant('usbList-popup-downcover');
         downCoverWidget.removeEventListener('OnMouseOver', this._blockMouse);  
    },
     _blockMouse: function () {
             
    },
    /**
     * Render usbList popup
     * @method
     * @memberof USBListPopupView
     */
    renderNeedlist: function (viewInfo) {
        Volt.log('[LowMemoryPopupView.js] renderUSBListPopup');

            this.renderTitle();
            this.renderNeededInfo(this.neededListInfo);
            this.renderButton();
           
    },

    /**
     * create titleView for rendering title
     * @method
     * @memberof USBListPopupView
     */
    renderTitle: function () {
        Volt.log('[LowMemoryPopupView.js] renderTitle');
        var container = this.widget.getChild('lowmemory-popup').getChild('lowmemory-title-container');
        container.addChild(Volt.loadTemplate(Template.title));
    },


    /**
     * create selectedUSBView for rendering selected usb info
     * @method
     * @memberof USBListPopupView
     */
    renderNeededInfo: function () {
        Volt.log('[LowMemoryPopupView.js] renderSelectedDevice');
        var container = this.widget.getChild('lowmemory-popup').getChild('lowmemory-list-container');
        this.NeededView = new NeededInfoView(this.neededListInfo);
        this.NeededView.render(container);
    },

    /**
     * create buttonView for rendering cancel button
     * @method
     * @memberof USBListPopupView
     */
    renderButton: function () {
        Volt.log('[LowMemoryPopupView.js] renderButton');
        var container = this.widget.getChild('lowmemory-popup').getChild('lowmemory-button-container');
        this.okButtonView = new ButtonView();
        this.okButtonView.render(container);
    },


    /**
     * Hide this widget
     * @method
     * @memberof USBListPopupView
     */
    hide: function () {
        Volt.log('[LowMemoryPopupView.js] hide');
        this.widget.hide();
        
        this.hideHeaderCover();
        this.destroy(this.widget);
    },

    /**
     * Destory this widget
     * @method
     * @memberof USBListPopupView
     */
    destroy: function (widget) {
        Volt.log('[LowMemoryPopupView.js] destroy');
        this.widget.destroy();
        this.widget = null;

        if ( this.okButtonView ){

            this.okButtonView.btnListener.destroy();
            this.okButtonView.btnListener = null;

            this.okButtonView = null;
        }

        
    },



});
/**
 * @name NeededInfoView
 */
var NeededInfoView = Volt.BaseView.extend({
    /** @lends NeededInfoView.prototype */
    template: Template.neededItem,

    /**
     * Initialize NeededInfoView
     * @name NeededInfoView
     * @constructs
     */
    initialize: function (neededinfo) {
        this.neededinfo = neededinfo;
    },

    /**
     * Render line of usbList popup
     * @method
     * @memberof SelectedUSBView
     * @param object    container   parent widget
     */
    render: function (container) {
        var internalObj = _.find(this.neededinfo, function (obj) {
            if (obj.device_path === "tv") {
                return obj;
            }
        });

        var linenum = 0;

        if ( internalObj != undefined ){
            var mustache = {
                name: "Internal Memroy",
                neededsize: ":"+CommonFunctions.getFormattedSize(internalObj.need_memory,false)+" needed",
            };

            Volt.loadTemplate(this.template,mustache,container);      
            linenum ++;
        }

        var result = Models.externalStorageModel.updateUSBList();

        if ( result && result.storages ){
            for(var i = 0; (i< this.neededinfo.length) && (linenum <6); i++){
                Volt.log('[LowMemoryPopupView.js] i    '+i);
                Volt.log('[LowMemoryPopupView.js] this.neededinfo[i]    '+this.neededinfo[i]);
                if ( this.neededinfo[i].device_path != "tv" ){
                    Volt.log('[LowMemoryPopupView.js] this.neededinfo[i].device_path    '+this.neededinfo[i].device_path);
                    var usbobject =  _.find(result.storages, function (obj) {
                        Volt.log('[LowMemoryPopupView.js] obj.mountPath    '+obj.mountPath);
                        Volt.log('[LowMemoryPopupView.js] this.neededinfo[i].device_path    '+this.neededinfo[i].device_path);
                        if (obj.mountPath === this.neededinfo[i].device_path) {
                            return obj;
                        }
                    }.bind(this));

                    if ( usbobject != undefined ){
                        var mustache = {
                            name: usbobject.name,
                            neededsize: ":"+CommonFunctions.getFormattedSize(this.neededinfo[i].need_memory,false)+" needed",
                        };

                        var devicewidget = Volt.loadTemplate(this.template,mustache,container);
                        devicewidget.y = linenum * Volt.height * 0.044445;
                        linenum ++;
                    }
                }

            }
        }
        
        //return this;
    },

   
});

/**
 * @namespace USBListPopupView
 * @name ButtonView
 */
var ButtonView = Volt.BaseView.extend({
    /** @lends ButtonView.prototype */
    template: Template.button,
    btnListener: new ButtonListener(),

    events: {
        'NAV_FOCUS': 'onFocus',
    },

    /**
     * Initialize ButtonView
     * @name ButtonView
     * @constructs
     */
    initialize: function () {},

    /**
     * Render button
     * @method
     * @memberof ButtonView
     */
    render: function (Parent) {
        var btnStyle = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_G_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resolution: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
        }
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect(button);
        }.bind(this);
        this.okButton = Volt.loadTemplate(this.template, btnStyle, Parent);
        this.okButton.addListener(this.btnListener);
        this.setWidget(Parent);

        this.onFocus(Parent);
        return this;
    },

    /**
     * When focued focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onSelect: function (widget) {
        if (widget) {
            Backbone.history.back();
        }
    },

    /**
     * When focus on button, changed border
     * @method
     * @memberof ButtonView
     * @param  {object}  widget  focued widget
     */
    onFocus: function (widget) {
        Volt.log('[LowMemoryPopupView.js]button    onFocus   ');
        if (widget && widget.id == 'lowmemory-button-container') {
            this.okButton.setFocus();
            CommonFunctions.voiceGuide(this.okButton.text() + ',' + Volt.i18n.t('TV_SID_BUTTON'));
        }
    },

});


exports = LowMemoryPopupView;


