/** 
 * @author youngil baek (yi01.baek@samsung.com)
 * @fileoverview This module manages featured list view of app.
 * @date    2014/07/23 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ('Confidential Information').  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require('modules/underscore.js')._,
    Q = Volt.require('modules/q.js'),
    VoltJSON = Volt.require('modules/VoltJSON.js');

var EventMediator = Volt.require('app/common/eventMediator.js'),
    MyAppsTemplate = Volt.require('app/templates/1080/myAppsTemplate.js'),
    Models = Volt.require('app/models/models.js'),
    GridListView = Volt.require('app/views/gridListView.js');

var MyAppsVMCollection = Volt.require('app/models/myAppsVMCollection.js');
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var AppInfoProgressView = Volt.require('app/views/appInfoProgressView.js');
var localStorage = Volt.require('lib/volt-local-storage.js');
var DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js');
var AppInstallMgr = Volt.require('app/common/appInstallMgr.js');
var MENU_ANIM_DURATION = 200;
    //sortOption = ['releasedate', 'popularity', 'titleasc', 'titledesc'];
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
var GridListTemplate = Volt.require('app/templates/grid-list-template.js');


var tvResolution = (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080;
/**
 * @name MyAppsView
 */
var MyAppsView = Volt.BaseView.extend({
    /** @lends MyAppsView.prototype */

    myAppsVMCollection: null,
    template: MyAppsTemplate.container,
    gridlistTmpl: GridListTemplate.getGridTemplate('GRID_MYAPPS'),

    gridListView: null,
    //sortStandard: sortOption[0],
    headerCover: null,
    loadingFlag: false,
    appsSyncVM:null,
    exitFlag: false,
    moveAppsFlag: false,     //this flag is only used for check long press item and select move, 
                            //not used for enter myapp view edit mode
    /**
     * Initialize this view
     * @name MyAppsView
     * @constructs
     */
    initialize: function () {
        Volt.log('[MyAppsView] initialize');
        this.myAppsVMCollection = new MyAppsVMCollection();
        
        this.listenTo(EventMediator, 'VOLT_EXIT', this.onExit);
    },

    /**
     * render once after view is created
     * @method
     * @param  {widget} parentWidget parentWidget
     * @return {View}              this View
     */
    render: function (parentWidget) {
        Volt.log('[MyAppsView] render');
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_FOCUS_ZOOM, this.resetListImage);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_HIGH_CONTRAST, this.resetListImage);

        this.contentContainer = parentWidget.widget.getChild('main-content-container');
        this.headerContainer = parentWidget.widget.getChild('main-header-container');

        this.setWidget(Volt.loadTemplate(this.template));
        this.contentContainer.addChild(this.widget);

        return this;
    },

    onExit: function () {
        this.exitFlag = true;
        EventMediator.trigger('HIDE_EDIT_MODE');
    },
    
    /**
     * make it be gridList style.
     * @method
     * @param  {Collection} collection myAppsVMCollection
     */
    renderContent: function (collection, common) {
        Volt.log('[MyAppsView] renderContent');

        if (this.myAppsVMCollection.length > 0) {

            if (!this.gridListView) {
                var container = this.widget.getChild('myapps-content-container');
                this.gridlistTmpl.parent = container;
                this.gridListView = this.initNativeGrid();

                container.addChild(this.gridListView.render(this.myAppsVMCollection).widget);
                //add by lihao.zha@20150125, to fix 720P focus is 1px small issue
                if (1280 == scene.width) {
                    this.gridListView.widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -5, -5);
                }
                this.gridListView.widget.showWithAnimation();
            }
            localStorage.setItem('apps-myaps-caching-data', this.myAppsVMCollection);
            this.gridListView.widget.custom = {
                focusable: true
            };

            this.widget.getChild('myapps-no-content').text = '';

            Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'category-list-container');
            Volt.Nav.setNextItemRule(this.gridListView.widget, 'right', this.gridListView.widget);
            Volt.Nav.reload();
        }
    },

    renderCount: function () {
        Volt.log('[MyAppsView] renderCount');
        try {
            var wzSelectedItemsCount = this.contentContainer.parent.getChild('main-category-container').getChild('edit-mode-container').find('.edit-mode-selected-count');
            if (wzSelectedItemsCount.length > 0) {
                Volt.log('[MyAppsView] renderCount: getCheckedItemCount is ' + this.myAppsVMCollection.getCheckedItemCount());
                Volt.log('[MyAppsView] renderCount: getCheckableItemCount is ' + this.myAppsVMCollection.getCheckableItemCount());
                wzSelectedItemsCount[0].text = String(this.myAppsVMCollection.getCheckedItemCount());
                if (this.myAppsVMCollection.getCheckedItemCount() == this.myAppsVMCollection.getCheckableItemCount()) {
                    this.editButtonGroupView.isSelectAll = true;
                    this.editButtonGroupView.buttonSelect.setText({
                        state: "all",
                        text: Volt.i18n.t('UID_DESELECT_ALL')
                    });
                } else {
                    this.editButtonGroupView.isSelectAll = false;
                    this.editButtonGroupView.buttonSelect.setText({
                        state: "all",
                        text: Volt.i18n.t('COM_SID_SELECT_ALL')
                    });
                }
            }
        } catch (e) {}
    },
    updateAppsView: function () {
        Volt.log('[MyAppsView] updateAppsView');
         if (this.gridListView && this.gridListView.gridListControl) {
            this.gridListView.gridListControl.editFlag = false;
            this.gridListView.gridListControl.clearDataSource(0) ;
            this.gridListView.gridListControl.addDataGroup(1) ;
            for (var i = 0; i < this.myAppsVMCollection.length; i++) {
                //var data = this.gridListView.gridListControl.getData(0, i);
                //data.model = this.myAppsVMCollection.at(i);
                //print('updateAppsView:data.model.title ' + data.model .get('app_title'));
                this.gridListView.addData(this.myAppsVMCollection.at(i), i);
                print('updateAppsView:data.model.title ' + this.myAppsVMCollection.at(i).get('app_title'));
            }
            
            //this.gridListView.gridListControl.updateAllItems(0);
            this.gridListView.gridListControl.loadData();
            if(this.moveAppsFlag){
                this.moveAppsFlag = false;
                this.hideHeaderCover();
                EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_MOVE_MYAPPS,false);
            }
        }
    },
    updateAppsData: function () {
        Volt.log('[MyAppsView] updateAppsData');
         if (this.gridListView && this.gridListView.gridListControl) {
            var lenth = this.myAppsVMCollection.length;
            this.stopListening(this.myAppsVMCollection);
            this.myAppsVMCollection.clear();
            if (lenth > 0) {
                for (var i = 0; i < lenth; i++) {
                    var data = this.gridListView.gridListControl.getData(0, i);
                    this.myAppsVMCollection.add(data.model);
                    print('updateAppsData:data.model.app_title ' + data.model.get('app_title'));
                }
                localStorage.setItem('apps-myaps-caching-data', this.myAppsVMCollection);
            }
            this.listenTo(this.myAppsVMCollection, 'reset', this.onReset);
            this.listenTo(this.myAppsVMCollection, 'add', this.onItemAdded);
            this.listenTo(this.myAppsVMCollection, 'remove', this.onItemRemoved);
            this.listenTo(this.myAppsVMCollection, 'error', this.showErrorPopup);
            this.listenTo(this.myAppsVMCollection, 'change:is_checked', this.renderCount);
        }
    },
    updateGridEditMode: function () {
         Volt.log('[MyAppsView] updateGridEditMode');
         if (this.gridListView && this.gridListView.gridListControl) {
              if ('move' == this.myAppsVMCollection.modeType){
                   var visible = Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE);
                   Volt.log('[MyAppsView] visible is ' + visible);
                   if(visible){
                       this.gridListView.gridListControl.editFlag = true;
                   }else{
                       this.gridListView.gridListControl.editFlag = false;
                   }
                   if(this.editButtonGroupView){
                       this.editButtonGroupView.updateEditTitle(this.gridListView.gridListControl.editFlag);
                   }
              }
         }
    },
    initNativeGrid: function () {
        Volt.log('[MyAppsView] initNativeGrid');

        var gridListView = new GridListView({
            gridListControlParam: this.gridlistTmpl,

            listeners: {
                onDrawLoadData: function (thumbnail, data) {
                    Volt.log('[MyAppsView] onDrawLoadData ' + data.model.get('app_title'));

                    // data: {
                    //     model
                    // }

                    var iView = new MyAppsItemView(data.model, self);
                    iView.render(thumbnail);
                },
                onDrawUpdateData: function (thumbnail, data) {
                    Volt.log('[MyAppsView] onDrawUpdateData');

                    var myAppsVM = data.model;

                    if (myAppsVM) {
                        myAppsVM.updateView(thumbnail);
                    }
                },
                onDrawUnloadData: function (thumbnail, data) {
                    Volt.log('[MyAppsView] onDrawUnloadData');

                    var myAppsVM = data.model;

                    if (myAppsVM) {
                        myAppsVM.destroyView();
                    }
                },
                onGridFocus: function (wzFocused) {
                    Volt.log('[MyAppsView] onGridFocus');
                    if (wzFocused) {
                        var voiceText;
                        if (self.myAppsVMCollection.modeType == 'delete' ||
                            self.myAppsVMCollection.modeType == 'lock' ||
                            self.myAppsVMCollection.modeType == 'move') {
                            EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);
                            if(self.myAppsVMCollection.modeType == 'move'){
                                voiceText = Volt.i18n.t('TV_SID_MOVE_MY_APPS')+ ',' + 
                                    Volt.i18n.t('TV_SID_VOICE_GUIDE_NOT_SUPPORTED') + ',' + 
                                    Volt.i18n.t('TV_SID_PRESS_RETURN_PREVIOUS_SCREEN');
                            }
                            else{
                                if (self.myAppsVMCollection.modeType == 'delete') {
                                    voiceText = Volt.i18n.t('TV_SID_DELETE_MY_APPS') + ',' +
                                        Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', self.myAppsVMCollection.length);
                                } else {
                                    voiceText = Volt.i18n.t('TV_SID_LOCK_UNLOCK_MY_APPS') + ',' +
                                        Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', self.myAppsVMCollection.length);
                                }
                                if (wzFocused.customIsDim === true && wzFocused.customIsChecked !== true) {
                                    voiceText = voiceText + wzFocused.customTitle + ',' +
                                        Volt.i18n.t('TV_SID_DISABLED');
                                } else if (wzFocused.customIsChecked === true) {
                                    voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' +
                                        Volt.i18n.t('TV_SID_CHECKED') + ',' + wzFocused.customTitle;
                                } else if (wzFocused.customIsChecked === false) {
                                    voiceText = voiceText + Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' +
                                        Volt.i18n.t('TV_SID_UNCHECKED') + ',' + wzFocused.customTitle;
                                }
                            }
                        } else if(self.gridListView.gridListControl.editFlag){
                            Volt.log("[MyAppsView] onGridFocus, gridListControl.editFlag is true");
                            return;
                        } else {
                            voiceText = Volt.i18n.t('TV_SID_APPS_KR_PANEL') + ' ' +
                                Volt.i18n.t('TV_SID_MY_APPS_KR_PANEL') + ' ' +
                                Volt.i18n.t('SID_CATEGORY_KR_CA') + ',' +
                                Volt.i18n.t('COM_SID_POPUP_WIDGET_SHOW_GUIDE').replace('<<A>>', self.myAppsVMCollection.length) +
                                ',' + wzFocused.customTitle;
                        }
                        CommonFunctions.forceDisableVoiceGuide(false);
                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onGridBlur: function (wzFocused) {
                    Volt.log('[MyAppsView] onGridBlur');

                    if (wzFocused && typeof wzFocused.trigger == 'function') {
                        wzFocused.trigger('NAV_BLUR');
                    }
                },
                onFocusChangeStart: function (wzFrom, wzTo) {

                },
                onFocusChanged: function (wzFrom, wzTo) {
                    Volt.log('[MyAppsView] onFocusChanged');
                    if(self.gridListView.gridListControl.editFlag){
                        Volt.log("[MyAppsView] onFocusChanged, gridListControl.editFlag is true");
                        return;
                    }
                    if (wzFrom && wzTo) {
                        var voiceText = "";
                        Volt.log("[myAppsView.js] onFocusChanged myAppsVMCollection.modeType = " + self.myAppsVMCollection.modeType);
                        if (self.myAppsVMCollection.modeType == 'delete' ||
                            self.myAppsVMCollection.modeType == 'lock') {
                            if (wzTo.customIsDim === true && wzTo.customIsChecked !== true) {
                                voiceText = wzTo.customTitle + ',' + Volt.i18n.t('TV_SID_DISABLED');
                            } else if (wzTo.customIsChecked === true) {
                                voiceText = Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' + Volt.i18n.t('TV_SID_CHECKED') + ',' + wzTo.customTitle;
                            } else if (wzTo.customIsChecked === false) {
                                voiceText = Volt.i18n.t('TV_SID_CHECKBOX_ACC') + ',' + Volt.i18n.t('TV_SID_UNCHECKED') + ',' + wzTo.customTitle;
                            }
                        } else {
                            voiceText = wzTo.customTitle;
                        }
                        CommonFunctions.voiceGuide(voiceText);
                    }
                },
                onItemPress: function (wz, itemData, data) {
                    Volt.log('[MyAppsView @onItemPress] index: ' + data._index);

                    self.selectItem(data.model, data._index);
                },
                onEnterKeyLongPressed: function (wzFocused, itemData, type) {
                    Volt.log('[MyAppsView] onEnterKeyLongPressed' + itemData + self.myAppsVMCollection.at(itemData) + ' ' + self.myAppsVMCollection.at(itemData).get('app_featured'));
                    if(true == self.gridListView.gridListControl.editFlag){
                        Volt.log("[MyAppsView] gridListControl.editFlag is true");
                        return;
                    }
                    if (wzFocused && itemData != -1) {
                        if (Volt.DeviceInfoModel.get('networksStatus') == "NG") {
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
                            return;
                        }
                        var vmSelected = self.myAppsVMCollection.at(itemData);
                        // if (self.myAppsVMCollection.at(itemData).get('dimFlag')) {
                        //     Volt.log('[onEnterKeyLongPressed] dimFlag is  true');
                        //     CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_NOT_SUPPORT_MLS);
                        //     return;
                        // }
                        var param = {
                            baseWidget: wzFocused,
                            appInfoVM: vmSelected,
                            type: 'myapps',
                            feature: self.myAppsVMCollection.at(itemData).get('app_featured'),
                            is_removable: self.myAppsVMCollection.at(itemData).get('is_removable'),
                        };
                        Volt.log("[MyAppsView] app_title = " + self.myAppsVMCollection.at(itemData).get('app_title'));
                        Volt.log("[MyAppsView] app_feature = " + param.feature);
                        Volt.log("[MyAppsView] is_removable = " + param.is_removable);
                        if (self.myAppsVMCollection.at(itemData).get('app_title') == 'Browser') {
                            param.feature = 2;
                        }
                        if (self.myAppsVMCollection.at(itemData).get('app_title') == 'e-Manual') {
                            param.feature = 2;
                        }
                        if (self.myAppsVMCollection.at(itemData).get('is_edit_mode')) {
                            Volt.log('[MyAppsView] view is on edit mode do not show longpress popup');
                            return;
                        }
                        if (type == 'mouse') {
                            param.setfocus = true;
                        }
                        if(DownloadedAppsMgr.isDownloaded(self.myAppsVMCollection.at(itemData).get("app_id"))){
                            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU, param);
                        }else{
                            Volt.log('[MyAppsView] apps is in sync');
                        }
                        Volt.KpiMapper.addEventLog('LONGPRESSMA');
                    }
                },
		 onItemIndexChanged:function(gridlist,fromItemIndex,toItemIndex) {
                    Volt.err('[MyAppsView] onItemIndexChanged:from ' + fromItemIndex + " to " + toItemIndex);
                    if(gridlist.editFlag && self.moveAppsFlag&&Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
                        self.moveAppsFlag = false;
                        self.updateAppsData();
                        self.hideHeaderCover();
                        EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_MOVE_MYAPPS,false);
                        Volt.setTimeout(function () {
                            self.gridListView.gridListControl.editFlag = false;
                        }, 1);
                    }
                }
            }

        });

        // for test
        var self = this;

        return gridListView;
    },

    /**
     * callback on selecting
     * @method
     */
    selectItem: function (model, index) {
        Volt.log('[MyAppsItemView] onSelect');

        //var self = this;
         if (model.get('is_edit_mode')){
               if ('move' == this.myAppsVMCollection.modeType){
                    if(true == this.gridListView.gridListControl.editFlag){
                        this.gridListView.gridListControl.editFlag = false;
                    }else{
                        this.gridListView.gridListControl.editFlag = true;
                    }
                    if(this.editButtonGroupView){
                        this.editButtonGroupView.updateEditTitle(this.gridListView.gridListControl.editFlag);
                    }
                    return;
               }
         }
         if(this.moveAppsFlag){
             if(true == this.gridListView.gridListControl.editFlag){
                   this.gridListView.gridListControl.editFlag = false;
                   this.moveAppsFlag = false;
                   this.updateAppsData();
                   this.hideHeaderCover();
                   EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_MOVE_MYAPPS,false);
             }
             return;
         }
        if (model.get('is_updating')) { // Updating -> NR
            Volt.log('[MyAppsItemView] NR - state : ' + model.get('state'));
            return;
        }
        if (AppInstallMgr.getInstallList(model.get('app_id')).app_id) {
            Volt.log('[MyAppsItemView] app is instaling state: : ' + model.get('state'));
            return;
        }

        if (model.get('is_edit_mode')) { // Edit mode -> toggle checkbox
            Volt.log("model.get(is_edit_mode):" + model.get('is_edit_mode'));
            if (model.get('is_checkable')) model.setChecked();
        } else { // Launch app
            if (0 == AppInstallMgr.launchApp(model.get('app_id'), '')) { //fix bugs of DF141204-01236  Infinite loading add by pei828.yang 20141209
                EventMediator.trigger('HOMEVIEW_LAUNCH_APP');
            }
            model.set('is_updated', 0);

            Volt.KpiMapper.addEventLog('SELECTMA', {
                d: {
                    appid: model.get('app_id'),
                    //// @xiaojun.wang|20150122: Fix DF150119-02278
                    pn: index + 1, //model.get('app_index')
                }
            });
        }
    },

    removeGrid: function () {
        Volt.log('[MyAppsView] remove grid list');
        if (this.gridListView && this.gridListView.gridListControl) {
            EventMediator.trigger(CommonDefines.Event.EVENT_STOP_MYAPPS_LISTEN_EVENT);
            var container = this.widget.getChild('myapps-content-container');
            if (container) {
                Volt.log('[MyAppsView] remove grid list111111');
                Volt.Nav.removeItem(this.gridListView.gridListControl);
                container.removeChild(this.gridListView.gridListControl);
            }
            this.gridListView.gridListControl.hide();
            this.gridListView.gridListControl.destroy();
            this.gridListView.gridListControl = null;
            this.gridListView = null;
        }
    },
    /**
     * show this view
     * @method
     * @param  {object} param         additional data
     * @param  {number} animationType showing animation type
     * @return {object}               promise obj to synchronize logic.
     */
    show: function (param, animationType) {
        Volt.log('[MyAppsView] show');

        /*var nLocalSortIndex = localStorage.getItem('sortOption') ? localStorage.getItem('sortOption') : 0,
            sLastSort = sortOption[nLocalSortIndex];

        if (this.sortStandard != sLastSort) {
            this.requestFetch(nLocalSortIndex);
        }*/

        var deferred = Q.defer();

        if (!this.gridListView) {
            this.renderContent();
        } else {
            //EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');

            // this.gridListView.widget.setFocusItemIndex(0, 0);
            this.gridListView.widget.custom = {
                focusable: true
            };
            
            if (this.exitFlag) {
                this.resetFocus();
            }
            
            this.gridListView.widget.showWithAnimation();

            //fix focus issue,  longpress->more->return
            var previousHistory = Backbone.history.hashstack[Backbone.history.hashstack.length - 2];
            var isDetail = (/#detail/g).test(previousHistory);

            if (isDetail) {
                Volt.Nav.focus(this.gridListView.widget);
            }
        }

        if (this.myAppsVMCollection.length == 0) {
            this.loadingFlag = true;
            EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING'); // hide at onReset
        }

        this.widget.show();
        this.bindListener();

        Volt.Nav.reload();

        if (this.isNeedSync()) {
            this.startSync();
        }
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS, this.onFocusGrid);
        EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
        
        this.exitFlag = false;
        
        deferred.resolve();
        return deferred.promise;
    },


    /**
     * hide this view
     * @method
     * @param  {number} animationType hiding animation type
     * @return {object}               promise obj to synchronize logic.
     */
    hide: function (animationType) {
        Volt.log('[MyAppsView] hide');

        var deferred = Q.defer();
        deferred.resolve();

        this.widget.hide();
        this.unbindListener();

        if (this.gridListView) {
            Volt.Nav.removeItem(this.gridListView.widget, true);
            //            this.gridListView.widget.custom = {
            //                focusable: false
            //            };
            this.gridListView.widget.hideWithAnimation("autoDestroy");
        }

        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_GRID_FOCUS);

        return deferred.promise;
    },
    /**
     * pause
     * @method
     */
    pause: function () {
        Volt.log('[MyAppsView] pause');
    },

    resetFocus: function () {
        Volt.log(['featuredListView.js @reset']);

        if (this.gridListView) {
            var grid = this.gridListView.widget;

            // If the focus of grid is not at the first item, set to first item
            if (grid.getFocusItemIndex().itemIndex !== 0) {

                try {
                    HALOUtil.enableAUI(false);
                    Volt.log('HALOUtil.enableAUI(false)');
                } catch (e) {}

                grid.setFocusItemIndex(0, 0);
                // Call this to update the grid
                grid.showFocus('false');
                grid.hideFocus('false');

                try {
                    HALOUtil.enableAUI(true);
                    Volt.log('HALOUtil.enableAUI(true)');
                } catch (e) {}
            }
        }
    },
    
    bindListener: function () {
        Volt.log('[MyAppsView] bindListener');

        // ���� ��ġ�Ǵ� ���� ������ �ϱ� ���� hide�� stoplistening ���� �ʰ� ���Խ� �ߺ� �������� ���� ������ ��
        this.stopListening(this.myAppsVMCollection);

        this.listenTo(this.myAppsVMCollection, 'reset', this.onReset);

        this.listenTo(this.myAppsVMCollection, 'add', this.onItemAdded);
        this.listenTo(this.myAppsVMCollection, 'remove', this.onItemRemoved);

        this.listenTo(this.myAppsVMCollection, 'error', this.showErrorPopup);
        this.listenTo(this.myAppsVMCollection, 'change:is_checked', this.renderCount);
        this.listenToOnce(EventMediator, 'UPDATE_SELECTBTN', this.renderCount);
        this.listenTo(EventMediator, 'SHOW_EDIT_MODE', this.showEditMode);
        this.listenTo(EventMediator, 'HIDE_EDIT_MODE', this.hideEditMode);
        this.listenTo(EventMediator, 'EDIT_MODE_SELECT_ALL', this.setSelectAll);
        this.listenTo(EventMediator, 'EDIT_MODE_EXECUTE', this.editModeExecute);
        this.listenTo(EventMediator, 'UPDATE_MYAPPS_VIEW', this.updateAppsView);
        this.listenTo(EventMediator, 'UPDATE_MYAPPS_DATA', this.updateAppsData);       
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR, this.updateGridEditMode);
 
        this.listenTo(EventMediator, 'SORT_GRID_LIST', this.onSortGridList);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MY_APPS_SINGLE_DELETE, this.checkAppIsLockForDelete);
        this.listenTo(EventMediator, CommonDefines.Event.MSGBOX_BUTTON, this.processMsgBoxEvent, this);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_LONGPRESS_MOVE_MYAPPS, this.startMoveApps, this);
    },

    unbindListener: function () {
        Volt.log('[MyAppsView] unbindListener');

        this.stopListening(EventMediator, 'SHOW_EDIT_MODE');
        this.stopListening(EventMediator, 'HIDE_EDIT_MODE');
        this.stopListening(EventMediator, 'SORT_GRID_LIST');
        this.stopListening(EventMediator, 'EDIT_MODE_EXECUTE');
        this.stopListening(EventMediator, 'UPDATE_MYAPPS_VIEW'); 
        this.stopListening(EventMediator, 'UPDATE_MYAPPS_DATA'); 
        this.stopListening(EventMediator, CommonDefines.Event.CHANGE_VISIBLE_CURSOR);
        
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MY_APPS_SINGLE_DELETE);
        this.stopListening(EventMediator, CommonDefines.Event.MSGBOX_BUTTON);
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_LONGPRESS_MOVE_MYAPPS);

    },

    onReset: function () {
        Volt.log('[MyAppsView] onReset');
        var resetCurrentFocusWidgetFlag = false;
        var resetLastFocusWidgetFlag = false;

        if ((this.gridListView.gridListControl == Volt.Nav.getFocusedWidget()) || (this.gridListView.gridListControl == Volt.Nav.getLastFocusedWidget())) {
            resetLastFocusWidgetFlag = true;
        }
        if (this.gridListView.gridListControl == Volt.Nav.getFocusedWidget()) {
            resetCurrentFocusWidgetFlag = true;
            Volt.Nav.focus(null);
        }
        this.removeGrid();
        this.renderContent();
        if (true == resetLastFocusWidgetFlag) {
            Volt.log('[MyAppsView] setLastFocusedWidget');
            Volt.Nav.setLastFocusedWidget(this.gridListView.gridListControl);
        }
        if (true == resetCurrentFocusWidgetFlag) {
            Volt.log('[MyAppsView] setCurrentFocusedWidget');
            Volt.Nav.focus(this.gridListView.gridListControl);
        }
        if (true == this.loadingFlag) {
            EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
            this.loadingFlag = false;
        }
        if (('delete' == this.myAppsVMCollection.modeType) || ('lock' == this.myAppsVMCollection.modeType)) {
            this.myAppsVMCollection.setEditMode(this.myAppsVMCollection.modeType, true);
            if (this.gridListView) {
                Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'edit-select-button');
                Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-select-button'), 'down', this.gridListView.widget);
                Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-select-button'), 'left', this.editButtonGroupView.widget.getDescendant('edit-select-button'));
                Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-exceute-button'), 'down', this.gridListView.widget);
                Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-cancel-button'), 'down', this.gridListView.widget);
            }
            this.renderCount();
        }
    },

    onItemAdded: function (model, collection, options) {
        Volt.log('[MyAppsView] onItemAdded');

        if (options && options.add) {
            this.gridListView.addItem(model);
            if (('delete' == this.myAppsVMCollection.modeType) || ('lock' == this.myAppsVMCollection.modeType)) {
                Volt.log('[MyAppsView] set to is_edit_mode');
                model.set('is_edit_mode', true);
                this.editButtonGroupView.isSelectAll = false;
                this.editButtonGroupView.buttonSelect.setText({
                    state: "all",
                    text: Volt.i18n.t('COM_SID_SELECT_ALL')
                });

            }
            localStorage.setItem('apps-myaps-caching-data', this.myAppsVMCollection);
        }
    },

    onItemRemoved: function (model, collection, options) {
        // options.index : deleted model's index in collection

        Volt.log('[MyAppsView] onItemRemoved');

        if (options && options.index !== undefined) {
            this.gridListView.removeItem(options.index, options.index);

            var uninstallList = AppInstallMgr.getAllUnInstallList();
            if (uninstallList && uninstallList.length === 0) {
                //EventMediator.trigger('EVENT_OVERLAY_HIDE_LOADING');
            }
            localStorage.setItem('apps-myaps-caching-data', this.myAppsVMCollection);
        } else {
            Volt.log('[MyAppsView] options exist : ' + (options != null));
            if (options) {
                Volt.log('[MyAppsView] options.index : ' + options.index);
            }
        }
    },
    /**
     * set msgbox button click callback
     * @method  caoyr 11.14
     * @memberof FeaturedListView
     */
    processMsgBoxEvent: function (data) {
        Volt.log('[myAppsView] processMsgBoxEvent:type is:' + data.msgBoxtype + " eventType is:" + data.eventType);
        if (data.eventType == CommonDefines.Event.SELECT_BTN1) {
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS:
                Volt.log('[myAppsView] processMsgBoxEvent: ok' + data.appID);
                //EventMediator.trigger('HIDE_EDIT_MODE');
                this.hideEditMode();
                //EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING');//delete loading view when delete locked app item
                //Volt.Nav.focus();

                // @xiaojun.wang|20150128: If the app is locked, a pin popup will be popped. we should dim before the pin is gone.
                //if (this.bIsLock) {
                EventMediator.trigger('EVENT_OVERLAY_SHOW_DIM');
                Volt.Nav.focusHiddenActor();
                //}

                if (data.appID.length == 1) {
                    this.myAppsVMCollection.deleteApps('single', data.appID, this.bIsLock);
                } else if (data.appID.length > 1) {
                    this.myAppsVMCollection.deleteApps('multi', data.appID, this.bIsLock);
                }

                break;
            case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
                Volt.log('[myappsView] processMsgBoxEvent: ok');
                Backbone.history.back();
                break;
            default:
                break;
            }
        } else if (data.eventType == CommonDefines.Event.SELECT_BTN2) {
            Volt.log('[myAppsView.js] processMsgBoxEvent:SELECT_BTN2');
            switch (data.msgBoxtype) {
            case CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS:
                Volt.log('[myAppsView] processMsgBoxEvent: ok');
                //fix DF141215-01487,user may still want to delete the other items, do not need to exit delete mode
                //EventMediator.trigger('HIDE_EDIT_MODE');
                break;
            default:
                break;
            }
        }
    },

    startMoveApps: function(flag){
        Volt.log('[myappsView] startMoveApps: flag is ' + flag);
        if(false == flag){
            return;
        }
        this.moveAppsFlag = true;
        if(this.gridListView && this.gridListView.gridListControl){
            this.gridListView.gridListControl.editFlag = true;
        }
        this.showHeaderCover();

        var voiceText = Volt.i18n.t('COM_SID_MOVE') + ',' + Volt.i18n.t('TV_SID_VOICE_GUIDE_NOT_SUPPORTED') + ',' + 
                        Volt.i18n.t('TV_SID_PRESS_RETURN_PREVIOUS_SCREEN');

        CommonFunctions.voiceGuide(voiceText);
    },
    /**
     * Callback function of plus button select.
     * @method
     * @param  {int} index    Selected index of menu
     * @param  {int} subIndex Selected index of sub menu
     */
    /*requestFetch: function (sLastSort) {
        Volt.log('[MyAppsView] requestFetch(' + sLastSort + ')');

        //this.myAppsVMCollection.clear();

        switch (sLastSort) {
        case 0:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD);
            break;

        case 1:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_MOSTLYPLAYED);
            break;

        case 2:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_A_TO_Z);
            break;

        case 3:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_Z_TO_A);
            break;
        }

        this.sortStandard = sortOption[sLastSort];
    },*/

    showErrorPopup: function (serverError) {
        Volt.log('[MyAppsView] showErrorPopup');
        if (this.myAppsVMCollection.length > 0) {
            Volt.log("[MyAppsView.js @list already exist, do not show error message");
        } else {
            this.widget.getChild('myapps-no-content').text = serverError.message;
        }
    },

    showDisconnectPopup: function () {
        Volt.log('[MyAppsView] showDisconnectPopup');

        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
    },

    showDeleteConfirmPopup: function (app_id) {
        Volt.log('[MyAppsView] showDeleteConfirmPopup');
        Volt.log('CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS,app_id:)' + app_id);
        CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS, app_id);
    },

    checkAppIsLockForDelete: function (app_id) {
        Volt.log('[MyAppsView] checkAppIsLockForDelete' + app_id);
        this.bIsLock = false,
        self = this;

        var app_ID = [];
        if (app_id == null) {
            app_ID = this.myAppsVMCollection.getCheckedItemAppID();
            if (app_ID.length == 0) {
                EventMediator.trigger('HIDE_EDIT_MODE');
                return;
            }
        } else {
            print("app_id" + app_id);
            app_ID[0] = app_id;
        }
        print("app_id" + app_id);
        this.bIsLock = this.myAppsVMCollection.getLockedFlag(app_id);
        // when param not exist, may be multi delete 
        /*if (!app_id) {
            if (!this.myAppsVMCollection.checkHaveMultiDeleteApps()) {
                EventMediator.trigger('HIDE_EDIT_MODE');
                return;
            } else if (this.myAppsVMCollection.where({ is_lock : 1, is_checked : true }).length > 0) {
                this.bIsLock = true;
            }
        } 
        if (this.myAppsVMCollection.where({ app_id : app_id, is_lock : 1 }).length > 0) { // for single delete
            this.bIsLock = true;
        }*/

        Volt.log("showDeleteConfirmPopup^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" + this.bIsLock); //do not need check lock,volt team will lunch pinpopup
        this.showDeleteConfirmPopup(app_ID);
    },

    showEditMode: function (sType) {
        Volt.log('[MyAppsView] showEditMode');
        if ( ('delete' == this.myAppsVMCollection.modeType) || ('lock' == this.myAppsVMCollection.modeType) || ('update' == this.myAppsVMCollection.modeType) ) {
            Volt.log('[MyAppsView] already show edit view');
            return;
        }
        this.showHeaderCover();
        var wzMenuListContainer = this.contentContainer.parent.getChild('main-category-container');
        var wzMenuList = wzMenuListContainer.getDescendant('category-list-container');
        Volt.Nav.focus(null); //unfocus menu
        wzMenuList.hide();

        this.myAppsVMCollection.setEditMode(sType, true);
        if (1 == DeviceInfoModel.get('mls')) {
            EventMediator.trigger(CommonDefines.Event.CHANGE_MLS_STATE);
        }

        if (!this.editButtonGroupView) {
            this.editButtonGroupView = new EditButtonGroupView(this.contentContainer.parent);
            this.editButtonGroupView.render(this);
            wzMenuListContainer.addChild(this.editButtonGroupView.widget);
        }

        if (this.editButtonGroupView) this.editButtonGroupView.show(sType);

        if (this.gridListView) {
            if( ('move' == this.myAppsVMCollection.modeType)){
                Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'edit-exceute-button');
                 if(Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE)){
                       this.gridListView.gridListControl.editFlag = true;
                  }
            }else{ 
                Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'edit-select-button');
                this.gridListView.gridListControl.editFlag = false;
            } 
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-select-button'), 'down', this.gridListView.widget);
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-select-button'), 'left', this.editButtonGroupView.widget.getDescendant('edit-select-button'));
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-exceute-button'), 'down', this.gridListView.widget);
            Volt.Nav.setNextItemRule(this.editButtonGroupView.widget.getDescendant('edit-cancel-button'), 'down', this.gridListView.widget);
        }

        //add by lihao.zha@20150410, fix DF150409-02165
        if ('delete' == this.myAppsVMCollection.modeType){
            EventMediator.trigger('EVENT_OVERLAY_HIDE_DIM');
        }
        
        // focus first item
        this.gridListView.widget.setFocusItemIndex(0, 0);
        Volt.Nav.focus(this.gridListView.widget);
        this.renderCount();
        this.gridListView.widget.event = false; // EVENT_KEY_RELEASE is delievered to gridListView. This makes the first item checked.
    },

    hideEditMode: function (sType) {
        Volt.log('[MyAppsView] hideEditMode');    
        if (false == this.myAppsVMCollection.modeType) {
            Volt.log('[MyAppsView] hide edit view');
            return;
        }
        this.gridListView.gridListControl.editFlag = false;
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);
        var wzMenuListContainer = this.contentContainer.parent.getChild('main-category-container');
        var wzMenuList = wzMenuListContainer.getDescendant('category-list-container');
        //this.contentContainer.parent.find('.list-arrow')[0].show();
        //      this.contentContainer.parent.find('.list-arrow')[1].show();
        this.hideHeaderCover();

        Volt.Nav.focus(null);
        if (this.editButtonGroupView) {
            this.editButtonGroupView.hide();
        }

        if (this.gridListView) {
            Volt.Nav.setNextItemRule(this.gridListView.widget, 'up', 'category-list-container');
            if (this.gridListView.gridListControl) {
                this.gridListView.gridListControl.setFocusItemIndex(0, 0);
            }
        }

        this.myAppsVMCollection.setEditMode(sType, false);
        if (1 == DeviceInfoModel.get('mls')) {
            EventMediator.trigger(CommonDefines.Event.CHANGE_MLS_STATE);
        }

        if (wzMenuList.custom) {
            wzMenuList.custom.focusable = true;
        }
        wzMenuList.show();

        Volt.Nav.reload();
        Volt.Nav.focus(Volt.Nav.getItem(1));
    },

    setSelectAll: function (flag) {
        CommonFunctions.forceDisableVoiceGuide(true);
        this.myAppsVMCollection.setSelectAll(flag);
        CommonFunctions.forceDisableVoiceGuide(false);
    },


    requestUpdateApps: function (app_id) {
        Volt.log('[MyAppsView] requestUpdateApps' );
        var app_ID = [];
        if (app_id == null) {
            app_ID = this.myAppsVMCollection.getCheckedItemAppID();
            if (app_ID.length == 0) {
                EventMediator.trigger('HIDE_EDIT_MODE');
                return;
            }
        } else {
            print("app_id" + app_id);
            app_ID[0] = app_id;
        }

        AppInstallMgr.updateApp(app_ID);
        Volt.KpiMapper.addEventLog('UPDATEAPPS', {
            d: {
                appid: app_ID,
                san: app_ID.length
            }
        });

    },

    editModeExecute: function (type) {
        if (type == 'delete') {
            this.checkAppIsLockForDelete();
        } else if (type == 'lock') {
            this.myAppsVMCollection.setAppLock();
            EventMediator.trigger('HIDE_EDIT_MODE');
            localStorage.setItem('apps-myaps-caching-data', this.myAppsVMCollection);
        }else if (type == 'update') {
            this.requestUpdateApps();
            EventMediator.trigger('HIDE_EDIT_MODE');
        }else if (type == 'move') {
            Volt.log('[MyAppsView] editModeExecute:move');
            EventMediator.trigger('HIDE_EDIT_MODE');
        }
    },

    /**
     * Callback function of plus button select.
     * @method
     * @param  {int} index    Selected index of menu
     * @param  {int} subIndex Selected index of sub menu
     */
    /*onSortGridList: function (index) {
        Volt.log('[MyAppsView] onSortGridList');
        if (Volt.DeviceInfoModel.get('networksStatus') == 'NG') {
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.TYPE_NETWORK);
            return;
        }
        var optionMenu = parseInt(index, 10);

        if (index == -1) return;

        //this.myAppsVMCollection.clear();
        this.loadingFlag = true;
        EventMediator.trigger('EVENT_OVERLAY_SHOW_LOADING');
        switch (optionMenu) {
        case 0:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD);
            break;

        case 1:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_MOSTLYPLAYED);
            break;

        case 2:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_A_TO_Z);
            break;

        case 3:
            this.myAppsVMCollection.fetch(CommonDefines.WAS.VIEWMODE_Z_TO_A);
            break;
        }
        this.sortStandard = sortOption[optionMenu];
    },*/

    isNeedSync: function () {
        Volt.log('[MyAppsView] isNeedSync');

        var wasSyncState = voltapi.WAS.getAppsSyncState(),
            bNeedSync = wasSyncState != CommonDefines.WAS.WAS_APPS_SYNC_COMPLETED;

        // for test
        // bNeedSync = true;

        // for debug
        var enum2str = {
            '10': 'WAS_APPS_SYNC_STATE_INIT',
            '11': 'WAS_APPS_SYNC_STATE_START',
            '12': 'WAS_APPS_SYNC_STATE_UNINSTALL_COMPLETED',
            '13': 'WAS_APPS_SYNC_INSTALL_COMPLETED',
            '14': 'WAS_APPS_SYNC_COMPLETED'
        };
        Volt.log('[MyAppsView] voltapi.WAS.getAppsSyncState() returns ' + wasSyncState + ' : ' + enum2str[wasSyncState]);

        return bNeedSync;
    },

    startSync: function () {
       Volt.log('[MyAppsView] startSync');
        if(this.appsSyncVM) {
            Volt.log('[MyAppsView] Sync is in progress');
            return; 
        }
        var AppsSyncVM = Volt.require('app/models/appsSyncVM.js');

        this.appsSyncVM = new AppsSyncVM();

        this.listenTo(this.appsSyncVM, 'SYNC_TO_BE_INSTALL', this.onSyncToBeInstall);
        this.listenTo(this.appsSyncVM, 'APPS_SYNC_COMPLETED', this.onAppsSyncCompleted);

        this.appsSyncVM.start();

        Volt.Nav.reload();
    },

    onSyncToBeInstall: function (apps) {
        Volt.log('[MyAppsView] onSyncToBeInstall');

        // for debug
        Volt.log(JSON.stringify(apps));

        this.myAppsVMCollection.add(apps);
    },

    onAppsSyncCompleted: function () {
        Volt.log('[MyAppsView] onAppsSyncCompleted');

        if (this.appsSyncVM) {
            this.appsSyncVM.destroy();
            this.appsSyncVM = null;
        }

        this.myAppsVMCollection.refresh();

        Volt.Nav.reload();
    },

    showHeaderCover: function () {
        Volt.log('[MyAppsView] renderHeaderCover');

        
        if (!this.headerCover) {
            this.headerCover = Volt.loadTemplate(MyAppsTemplate.headerCover);    
        }
        if(this.moveAppsFlag){
            this.headerCover.height = Volt.height * 0.2;
        }
        else{
            this.headerCover.height = Volt.height * 0.133333;
        }
	this.headerCover.show();
        this.headerCover.addEventListener('OnMouseOver', this._blockMouse);
        this.headerContainer.getDescendant('main-header-title').textColor = Volt.hexToRgb('#ffffff', 20);
        this.headerContainer.getDescendant('SearchBtnId').enable(false);
        this.headerContainer.getDescendant('OptionBtnId').enable(false);
        this.headerContainer.getDescendant('CloseBtnId').enable(false);
        
    },

    hideHeaderCover: function () {
        Volt.log('[MyAppsView] destroyHeaderCover');
        if (this.headerCover) {
            this.headerCover.removeEventListener('onMouseOver', this._blockMouse);
            this.headerCover.hide();
        }
        this.headerContainer.getDescendant('main-header-title').textColor = Volt.hexToRgb('#ffffff', 80);
        this.headerContainer.getDescendant('SearchBtnId').enable(true);
        this.headerContainer.getDescendant('OptionBtnId').enable(true);
        this.headerContainer.getDescendant('CloseBtnId').enable(true);
    },

    _blockMouse: function () {},

    resetListImage: function () {
        Volt.log('[MyAppsView.js @resetListImage]');
        var offset = (1280 == scene.width) ? -5 : -4;
        if (Volt.DeviceInfoModel.get('highContrast')) {
            if (this.gridListView && this.gridListView.widget) {
                this.gridListView.widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/acc_focus.png'), offset, offset);
            }
        } else {
            if (this.gridListView && this.gridListView.widget) {
                this.gridListView.widget.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), offset, offset);
            }
        }
    },

    onFocusGrid: function () {
        Volt.log('[featuredListView.js @onFocusGrid]');
        if (this.gridListView && this.gridListView.widget && this.gridListView.widget.custom.focusable == true) {
            Volt.Nav.focus(this.gridListView.widget);
        }

    }

});

/**
 * @name MyAppsItemView
 */
var MyAppsItemView = Volt.BaseView.extend({
    /** @lends MyAppsItemView.prototype */
    template: GridListTemplate.getThumbnailTemplate('THUMB_MYAPPS'),
    model: null,
    parentView: null,
    
    bgmode: 'DARK',
    renderedIcons: null,
    MAX_ICON: 4,
    
    thumbnail: null, // Thumbnail Widget
    thumbListener: null, // Thumbnail Listener for color pick

    /**
     * initialize
     * @name MyAppsItemView
     * @constructs
     * @param  {Model} model VM correspond to this
     */
    initialize: function (model, parentView) {
        Volt.log('[MyAppsItemView] initialize');

        this.model = model;
        this.parentView = parentView;
        this.bindListener();
    },

    /**
     * render this view
     * @method
     * @param  {type} widget rendering appItemView's widget
     */
    render: function (thumbnail) {
        Volt.log('[MyAppsItemView] render');

        var self = this;
        var data, textColor, itemTmpl, iconTmpls, thumbListener;

        this.thumbnail = thumbnail;

        //data = this.model.toJSON();
        data = this.model.attributes;
        
        // Make thumbnail template
        itemTmpl = JSON.parse(JSON.stringify(this.template)); // use JSON for deep copy
        iconTmpls = this.makeIconTmpls(thumbnail);

        _.extend(itemTmpl.information, iconTmpls);

        this.updateTemplate(itemTmpl);
        //itemTmpl.image.src = data.app_panel_icon_path || data.panel_icon || Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'); // AppsSync() returns 'panel_icon' instead of 'app_panel_icon_path'
        itemTmpl.information.text1.text = data.app_title;

        // Color pick
        thumbListener = this.thumbListener = new ThumbnailListener();
        thumbListener.onImageReady = function (thumbnail, id, success) {
            thumbnail.border = {width:0, color: Volt.hexToRgb('#000000', 0)};
            if (success == true) {
                //                Volt.setTimeout(function () {
                var informationColorpick;
                if (DeviceInfoModel.get('highContrast')) {
                    informationColorpick = thumbnail.getInformationColor();
                } else {
                    informationColorpick = thumbnail.getInformationColorPicking();
                }
                textColorpick = HALOUtil.extractIconColor(informationColorpick.r, informationColorpick.g, informationColorpick.b);

                // set bg color type
                if (textColorpick == HALOUtil.CC_WHITE) {
                    self.bgmode = 'LIGHT';
                } else {
                    self.bgmode = 'DARK';
                }

                self.renderIcons(thumbnail);
                //                }, 0);
            } else { // parse false, set default image instead
                thumbnail.timeId = Volt.setTimeout(function () {
                    Volt.log("********************");
                    thumbnail.setContentImage(Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'));
                    thumbnail.timeId = null;
                }, 10);
                
                thumbnail.setContentImageFillMode('stretch');
            }
        };
        thumbnail.addThumbnailListener(thumbListener);

        // Set thumbnail template
        thumbnail.setThumbnailStyle(itemTmpl);

        //add by lihao.zha@10141118, to pass app title to onFocusChanged function
        thumbnail.customTitle = data.app_title || '';
        thumbnail.customSupportVoice = data.is_support_voice;

        // Set component properties
        thumbnail.setProgressRange(0, 200); // downloading + installing

        // Set widget
        this.setWidget(thumbnail);

        // Render checkbox
        this.onIsCheckedChanged(this.model, data.is_checked);

        // Render progress
        this.onStateChanged(this.model, data.state);

        // Render dim
        Volt.log("[myAppsView.js] data.is_multi_screen2 is " + data.is_multi_screen2);
        if (DeviceInfoModel.get('mls') == 1) {
            Volt.log("[myAppsView.js] MLS:result is 1");
            if (1 == data.is_multi_screen2 || data.is_edit_mode) {
                this.onIsDimChanged(this.model, data.is_dim);
            } else {
                this.thumbnail.customIsDim = true;
                this.thumbnail.dim(true);
                this.dimFlag = true;
                this.model.set('dimFlag', true);
            }
        } else {
            this.onIsDimChanged(this.model, data.is_dim);
        }

        // TTS
        //removed by lihao.zha@20141118, move tts to onFocusChanged function
        //thumbnail.setTTSText({text: data.app_title || ''});
    },
    
    remove: function () {
        Volt.log('[MyAppsItemView] remove ' + this.model.get('app_title'));

        this.unbindListener();
        if (this.thumbnail) {
            try {
                if (this.thumbListener) {
                    this.thumbnail.removeThumbnailListener(this.thumbListener);
                }
    
                if (this.thumbnail.timeId) {
                    Volt.clearTimeout(this.thumbnail.timeId);
                    this.thumbnail.timeId = null;
                }
            } catch (e) {
                Volt.log("[MyAppsItemView] removeThumbnailListener fail  ");
            }  
            this.thumbnail = null;
            this.thumbListener = null;
        }

    },

    makeIconTmpls: function (thumbnail) {
        var iconTmpls = {},
            aIcons = this.getIconsToRender(thumbnail);

        for (var i = 0; i < aIcons.length; i++) {

            tmpl = aIcons[i].tmpl;
            iconId = 'icon' + (i + 1); // 1-base

            iconTmpls[iconId] = aIcons[i].tmpl;
        }

        // Save to find 'update' icon position
        this.renderedIcons = aIcons;

        return iconTmpls;
    },

    renderIcons: function (thumbnail) {
        Volt.log('[MyAppsItemView] renderIcons');

        var aIcons = this.getIconsToRender(thumbnail),
            tmpl, iconId;

        for (var i = 0; i < this.MAX_ICON; i++) {

            iconId = 'icon' + (i + 1); // 1-base

            if (i < aIcons.length) {
                tmpl = aIcons[i].tmpl;

                thumbnail.visualizeInformationIcon(true, iconId);
                thumbnail.setElementAllocation('information-' + iconId, {
                    x: tmpl.x,
                    y: tmpl.y,
                    width: tmpl.width,
                    height: tmpl.height
                });
                thumbnail.setInformationIcon(iconId, tmpl.src);
            } else {
                thumbnail.visualizeInformationIcon(false, iconId);
            }

        }
    },

    getIconsToRender: function (thumbnail) {

        // Filter icons to render
        var iconTmpls = this.getIconTmpls(),
            aIcons = [];

        if (this.model.get('type') == 'user_usb') aIcons.push({
            type: 'usb',
            tmpl: iconTmpls.usb
        });
        Volt.log('[MyAppsItemView] app_installed_path is ' + this.model.get('app_installed_path'));
        if ((this.model.get('app_installed_path') && ("" != this.model.get('app_installed_path')))) {
            if (this.model.get('app_installed_path').indexOf("/opt/usr/apps/") < 0) {
                aIcons.push({
                    type: 'usb',
                    tmpl: iconTmpls.usb
                });
            }
        }
        if (this.model.get('is_lock') == 1) aIcons.push({
            type: 'lock',
            tmpl: iconTmpls.lock
        });

        // for test
        // aIcons.push({type: 'usb', tmpl: iconTmpls.usb});
        // aIcons.push({type: 'lock', tmpl: iconTmpls.lock});

        // Arrage icon position
        var MARGIN = 7,
            x = 20;

        _.each(aIcons, function (icon) {
            icon.tmpl.x = x;
            x = x + icon.tmpl.width + MARGIN;
        });

        // for debug
        // for (var i = 0; i < aIcons.length; i++) {
        //     Volt.log('ICON TYPE: ' + aIcons[i].type);
        //     Volt.log('ICON X   : ' + aIcons[i].tmpl.x);
        // }

        if (this.model.get('is_need_update') == 1) {
            aIcons.push({
                type: 'update',
                tmpl: iconTmpls.update
            });
        } else {
            if (this.model.get('is_updated') == 1) {
                aIcons.push({
                    type: 'updated',
                    tmpl: iconTmpls.updated
                });
            }
        }
        // for test
        // aIcons.push({type: 'update', tmpl: iconTmpls.update});
        // aIcons.push({type: 'updated', tmpl: iconTmpls.updated});

        // for adjustment of information text field's X position.
        var xForUpdateIcons = 0;
        if (this.model.get('is_need_update') == 1 || this.model.get('is_updated') == 1) xForUpdateIcons = iconTmpls.update.width;
        thumbnail.setElementAllocation('information-text1', {
            x: x,
            y: this.template.information.text1.y,
            width: GridListTemplate.getGridTemplate('GRID_MYAPPS').itemWidth - x - MARGIN - 20 - xForUpdateIcons,
            height: this.template.information.text1.height
        });

        return aIcons;
    },

    getIconTmpls: function () {
        var iconTmpls;
        if (this.bgmode == 'DARK') {
            iconTmpls = {
                usb: MyAppsTemplate.usbIcon_w,
                lock: MyAppsTemplate.lockIcon_w,
                update: MyAppsTemplate.updateIcon,
                updated: MyAppsTemplate.updatedIcon
            };
        } else { // 'LIGHT'
            iconTmpls = {
                usb: MyAppsTemplate.usbIcon_b,
                lock: MyAppsTemplate.lockIcon_b,
                update: MyAppsTemplate.updateIcon,
                updated: MyAppsTemplate.updatedIcon
            };
        }
        return _.extend({}, iconTmpls);
    },

    onMLSChange: function () {
        Volt.log('[MyAppsItemView] onMLSChange MLS state is ' + DeviceInfoModel.get('mls'));
        var model = this.model;
        if (1 == DeviceInfoModel.get('mls') && !model.get('is_edit_mode')) {
            Volt.log('[MyAppsItemView] model.is_multi_screen2 is ' + model.get('is_multi_screen2'));
            if (0 == model.get('is_multi_screen2')) {
                this.thumbnail.dim(true);
                this.model.set('dimFlag', true);
            }
        } else {
            if (0 == model.get('is_multi_screen2')) {
                this.thumbnail.dim(false);
                this.onIsDimChanged(this.model, this.model.get('is_dim'));
                this.model.set('dimFlag', false);
            }
        }
    },

    bindListener: function () {
        this.listenTo(this.model, 'DESTROY_VIEW', this.remove);
        this.listenTo(this.model, 'UPDATE_VIEW', this.onUpdateView);

        this.listenTo(this.model, 'change:state', this.onStateChanged);
        this.listenTo(this.model, 'change:progress', this.onProgressChanged);
        this.listenTo(this.model, 'change:is_checked', this.onIsCheckedChanged);
        this.listenTo(this.model, 'change:is_lock', this.onIsLockChanged);
        this.listenTo(this.model, 'change:is_updated', this.onIsUpdatedChanged);
        this.listenTo(this.model, 'change:is_dim', this.onIsDimChanged);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_MLS_STATE, this.onMLSChange);
        this.listenTo(EventMediator, CommonDefines.Event.CHANGE_HIGH_CONTRAST, this.onHighContrastChange);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_STOP_MYAPPS_LISTEN_EVENT, this.unbindListener);
    },

    unbindListener: function () {
        this.stopListening();
    },

    onUpdateView: function (thumbnail) {
        Volt.log('[MyAppsItemView] onUpdateView ' + this.model.get('app_title'));

        this.thumbnail = thumbnail;
        this.setWidget(thumbnail);

        // Update information
        thumbnail.setContentImage(this.model.get('app_panel_icon_path') || this.model.get('panel_icon'));
        thumbnail.setInformationText('text1', this.model.get('app_title'));
        thumbnail.customTitle = this.model.toJSON().app_title || '';
        thumbnail.customSupportVoice = this.model.toJSON().is_support_voice;
        this.renderIcons(thumbnail);

        // Render checkbox
        this.onIsCheckedChanged(this.model, this.model.get('is_checked'));

        // Render progress
        this.onStateChanged(this.model, this.model.get('state'));

        // Render dim
        this.onIsDimChanged(this.model, this.model.get('is_dim'));

        // TTS
        //modified by lihao.zha@20141118, move tts to onFocusChanged function
        //thumbnail.setTTSText({text: this.model.get('app_title') || ''});
    },

    onStateChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onStateChanged ' + value);

        switch (value) {
        case 'UPDATE_START':
        case 'INSTALL_START':
            // [TODO] Dim ó��
            this.thumbnail.setProgressValue(0);
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            break;
        case 'DOWNLOADING':
        case 'DOWNLOAD_COMPLETED':
        case 'INSTALLING':
            break;
        case 'INSTALL_COMPLETED':
            // [TODO] Dim ó��
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.aniUpdateComplete();
            break;
        case 'INSTALL_CANCEL_COMPLETED':
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            break;
        case 'DOWNLOAD_FAIL':
        case 'INSTALL_FAIL':
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(0);
            CommonWidgetPopup.showMessage(CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD, options);
            break;
        default:
            this.thumbnail.visualizeThumbnailStyle(false, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(0);
            break;
        }

    },

    onProgressChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onProgressChanged ' + value + ' : ' + this.model.get('app_title'));

        var state = this.model.get('state');

        switch (state) {
        case 'DOWNLOADING':
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(value);
            break;
        case 'INSTALLING':
            this.thumbnail.visualizeThumbnailStyle(true, CommonDefines.Const.THUMB_STYLE_PROGRESSBAR);
            this.thumbnail.setProgressValue(100 + value);
            break;
        default:
            break;
        }
    },

    onIsCheckedChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsCheckedChanged ' + value);

        if (value) {
            this.thumbnail.setDimBackgroundColor({
                r: 0x21,
                g: 0x9e,
                b: 0xe6,
                a: 255 * 0.6
            }); // default dim color
            this.thumbnail.customIsChecked = true;
            if (this.parentView.myAppsVMCollection.modeType == 'delete' || this.parentView.myAppsVMCollection.modeType == 'lock') {
                CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_CHECKED'));
            }
        } else {
            this.thumbnail.setDimBackgroundColor({
                r: 0,
                g: 0,
                b: 0,
                a: 255 * 0.8
            }); // default dim color
            this.thumbnail.customIsChecked = false;
            if (this.parentView.myAppsVMCollection.modeType == 'delete' || this.parentView.myAppsVMCollection.modeType == 'lock') {
                CommonFunctions.voiceGuide(Volt.i18n.t('TV_SID_UNCHECKED'));
            }
        }
        EventMediator.trigger(CommonDefines.Event.EVENT_MYAPP_CHECK_ITEMNUM_CHANGE);
        this.thumbnail.visualizeThumbnailStyle(value, CommonDefines.Const.THUMB_STYLE_CHECKBOX);
        this.thumbnail.setChecked(value);
    },

    onIsLockChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsLockChanged ' + value);

        this.renderIcons(this.thumbnail);
    },

    onIsUpdatedChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsUpdatedChanged ' + value);

        this.renderIcons(this.thumbnail);
    },

    onIsDimChanged: function (model, value, options) {
        Volt.log('[MyAppsItemView] onIsDimChanged ' + model.get('app_title') + ' ' + value);

        this.thumbnail.customIsDim = value;
        this.thumbnail.dim(value);
        this.thumbnail.raiseElement('progressBar');
        this.thumbnail.raiseElement('checkBox');
    },

    onHighContrastChange: function () {
        Volt.setTimeout(function () {
            var informationColorpick;
            if (DeviceInfoModel.get('highContrast')) {
                informationColorpick = this.thumbnail.getInformationColor();
            } else {
                informationColorpick = this.thumbnail.getInformationColorPicking();
            }

            textColorpick = HALOUtil.extractIconColor(informationColorpick.r, informationColorpick.g, informationColorpick.b);
            if (textColorpick == HALOUtil.CC_WHITE) {
                this.bgmode = 'LIGHT';
            } else {
                this.bgmode = 'DARK';
            }

            this.renderIcons(this.thumbnail);
        }.bind(this), 10);
    },

    aniUpdateComplete: function () {
        Volt.log('[MyAppsItemView] aniUpdateComplete');

        var self = this,

            // animation image sources
            aniImgPath = Volt.getRemoteUrl('images/1080/common/icon_update_sequence_0<<A>>.png'),
            aniImgNums = [1, 2, 3, 4, 5, 6],

            // find 'update' icon position
            icon = _.findWhere(this.renderedIcons, {
                type: 'update'
            }),
            idx = _.indexOf(this.renderedIcons, icon),
            iconId;
        if(this.thumbnail){
            Volt.log('[MyAppsItemView]self.thumbnai setContentImage');
            if(this.model){
                 this.thumbnail.setContentImage(this.model.get('app_panel_icon_path') || this.model.get('panel_icon'));
            }
        }
        if (idx >= 0) {

            iconId = 'icon' + (idx + 1); // 1-base

            for (var i = 0; i < aniImgNums.length; i++) {
                (function (idx) {
                    Volt.setTimeout(function () {
                        self.thumbnail.setInformationIcon(iconId, aniImgPath.replace('<<A>>', aniImgNums[idx]));
                    }, 100 * idx);
                })(i);
            }
        }
    },
    
    updateTemplate: function (template) {
        var data = this.model.attributes;
        //var src = data.app_panel_icon_path || data.panel_icon || Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png'); // AppsSync() returns 'panel_icon' instead of 'app_panel_icon_path'
        
        var src;
        
        if (data.app_panel_icon_path || !data.app_icon_path) {
            if (data.app_panel_icon_path) {
                src = data.app_panel_icon_path;
                if (src.lastIndexOf('.png') >= 0 || src.lastIndexOf('.PNG') >= 0) {
                    template.image.fillMode = 'center';
                }
            } else {
                src = Volt.getRemoteUrl('images/1080/common/apps_screenshot_default.png');
            }
        } else {
            src = data.app_icon_path;
            template.image.fillMode = 'center';
        }
        
        template.image.src = src;
    },
});

var EditButtonGroupView = Volt.BaseView.extend({
    /** @lends EditButtonGroupView.prototype */

    template: MyAppsTemplate.editModeContainer,
    isSelectAll: false,
    executeType: null,
    btnListener: new ButtonListener(),
    parentView: null,
    buttonExecuteEnableFlag: false,
    expendAnimation: null,
    shrinkAnimation: null,
    /**
     * Initialize EditButtonGroupView
     * @method
     */
    initialize: function (parentWidget) {
        this.parent = parentWidget;
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelectButton(button);
        }.bind(this);
    },

    events: {
        'NAV_FOCUS #edit-select-button': 'onFocusButton',
        'NAV_BLUR #edit-select-button': 'onBlurButton',
        //'NAV_SELECT #edit-select-button' : 'onSelectButton',

        'NAV_FOCUS #edit-cancel-button': 'onFocusButton',
        'NAV_BLUR #edit-cancel-button': 'onBlurButton',
        //'NAV_SELECT #edit-cancel-button' : 'onSelectButton',

        'NAV_FOCUS #edit-exceute-button': 'onFocusButton',
        'NAV_BLUR #edit-exceute-button': 'onBlurButton',
        //'NAV_SELECT #edit-exceute-button' : 'onSelectButton'
    },

    /**
     * Render this view.
     * @method
     */
    render: function (parentView) {
        this.parentView = parentView;

        var highContrast = DeviceInfoModel.get('highContrast');

        var flag = highContrast || '0';

        this.container = Volt.loadTemplate(this.template, {
            highconstract: flag
        });

        var title_w = this.container.getChild('select-title').width;
        this.container.getChild('select-count').x = this.container.getChild('select-title').x + title_w;


        this.selectAllBg = this.container.getDescendant('edit-select-button');
        this.buttonSelect = this.createButton(this.selectAllBg, Volt.i18n.t('COM_SID_SELECT_ALL'));
        this.buttonSelect.id = "select-all-button";

        this.isChecked = false;
        this.deleteBg = this.container.getDescendant('edit-exceute-button');
        this.buttonExecute = this.createButton(this.deleteBg, Volt.i18n.t('UID_DESELECT_ALL'));
        this.buttonExecute.id = "delete-button";

        this.cancelBg = this.container.getDescendant('edit-cancel-button');
        this.buttonCancel = this.createButton(this.cancelBg, Volt.i18n.t('COM_SID_CANCEL'));
        this.buttonCancel.id = "cancel-button";


        this.container.addChild(this.selectAllBg);
        this.container.addChild(this.deleteBg);
        this.container.addChild(this.cancelBg);
        this.buttonExecute.enable(false);
        this.buttonExecuteEnableFlag = false;
        this.setWidget(this.container);

        return this;
    },

    /**
     * Show this view.
     * @method
     */
    show: function (sType) {
        Volt.log("[EditButtonGroupView] show()");
        this.executeType = sType;
        this.setExecuteButtonText();

        this.parent.getDescendant('main-header-icon-search').custom.focusable = false;
        this.parent.getDescendant('main-header-icon-option').custom.focusable = false;
        this.parent.getDescendant('main-header-icon-close').custom.focusable = false;
        this.parent.getDescendant('category-list-container').custom.focusable = false;

        this.widget.getChild('edit-cancel-button').custom.focusable = true;
        this.widget.getChild('edit-select-button').custom.focusable = true;

        this.buttonExecute.enable(false);
        this.buttonExecuteEnableFlag = false;
        this.widget.getChild('edit-exceute-button').custom.focusable = true;

        this.widget.find('.edit-mode-selected-count')[0].text = String(this.parentView.myAppsVMCollection.getCheckedItemCount());
        this.buttonSelect.setText({
            state: "all",
            text: Volt.i18n.t('COM_SID_SELECT_ALL')
        });
        this.isSelectAll = false;
        EventMediator.trigger("UPDATE_SELECTBTN");
        this.widget.show();

        if(this.parentView.myAppsVMCollection.modeType == 'move') {
             this.widget.getChild('edit-select-button').custom.focusable = false;
             this.buttonSelect.enable(false);
             this.buttonSelect.hide();  
             this.buttonExecute.enable(true);
             this.buttonExecuteEnableFlag = true;
             this.updateEditTitle(false);
             this.container.getChild('select-count').hide();
        }else{
             this.buttonSelect.enable(true);
             this.buttonSelect.show(); 
             this.container.getChild('select-title').text = Volt.i18n.t('TV_SID_MIX_SELECTED_ITEM_COLON').replace('<<A>>', "");
             var title_w = this.container.getChild('select-title').width;
             this.container.getChild('select-count').x = this.container.getChild('select-title').x + title_w;
             this.container.getChild('select-count').show();
         }
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS, this.expand);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR, this.shrink);
        this.listenTo(EventMediator, CommonDefines.Event.EVENT_MYAPP_CHECK_ITEMNUM_CHANGE, this.updateDeleteBtn);

        Volt.Nav.reload();
    },

    /**
     * Hide this view.
     * @method
     */
    hide: function () {
        this.parent.getDescendant('main-header-icon-search').custom.focusable = true;
        this.parent.getDescendant('main-header-icon-option').custom.focusable = true;
        this.parent.getDescendant('main-header-icon-close').custom.focusable = true;
        this.parent.getDescendant('category-list-container').custom.focusable = true;

        this.widget.getChild('edit-cancel-button').custom.focusable = false;
        this.widget.getChild('edit-exceute-button').custom.focusable = false;
        this.widget.getChild('edit-select-button').custom.focusable = false;
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS);
        this.stopListening(EventMediator, CommonDefines.Event.EVENT_MAIN_CATEGORY_BLUR);
        this.widget.hide();
        this.shrink();
    },
    updateEditTitle: function (flag) {
        Volt.log("[EditButtonGroupView] updateEditTitle()");
        if(this.parentView.myAppsVMCollection.modeType == 'move'){
               var visible = Vconf.getInteger(CommonDefines.Vconf.RUNTIME_INFO_KEY_DEVICEMGR_CURSOR_VISIBLE);
               Volt.log('[MyAppsView] visible is ' + visible);
               if(this.container.getChild('select-title')){
                    if(visible){
                       this.container.getChild('select-title').text = Volt.i18n.t('TV_SID_SELECT_APP_DRAG_DESIRED_POSITON');
                   }else{
                       if(flag){
                           this.container.getChild('select-title').text = Volt.i18n.t('TV_SID_MOVE_APP_MOVE_BUTTONS_ENTER_CONFIRM');
                       }else{
                            this.container.getChild('select-title').text = Volt.i18n.t('TV_SID_SELECT_AP_WANT_MOVE');
                       }
                   }
               } 
        }
    },
    onFocusButton: function (widget) {
        EventMediator.trigger(CommonDefines.Event.EVENT_MAIN_CATEGORY_FOCUS);
        if (widget) {
            switch (widget.id) {
            case 'edit-select-button':
                Volt.log('[myAppsView.js] this.buttonSelect.setFocus();^^^');
                this.buttonSelect.setFocus();
                CommonFunctions.voiceGuide(this.buttonSelect.text() + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                break;
            case 'edit-exceute-button':
                Volt.log('[myAppsView.js] this.exceute.setFocus();^^^');
                this.buttonExecute.setFocus();
                var voiceText = this.buttonExecute.text() + ',' + Volt.i18n.t('TV_SID_BUTTON');
                if (!this.buttonExecuteEnableFlag) {
                    voiceText = voiceText + ',' + Volt.i18n.t('TV_SID_DISABLED');
                }
                CommonFunctions.voiceGuide(voiceText);
                break;
            case 'edit-cancel-button':
                Volt.log('[myAppsView.js] this.exceute.setFocus();^^^');
                this.buttonCancel.setFocus();
                CommonFunctions.voiceGuide(this.buttonCancel.text() + ',' + Volt.i18n.t('TV_SID_BUTTON'));
                break;
            default:
                break;
            }
        }
    },

    onBlurButton: function (widget) {

        if (widget) {

            switch (widget.id) {
            case 'edit-select-button':
                this.buttonSelect.killFocus();
                break;
            case 'edit-exceute-button':
                this.buttonExecute.killFocus();
                break;
            case 'edit-cancel-button':
                //this.moreButton.color = Volt.hexToRgb('#ffffff', 95);
                //this.moreButton.getChild(0).src = Volt.getRemoteUrl('images/1080/common/btn_icon_more_f.png');
                this.buttonCancel.killFocus();
                break;
            default:
                break;
            }
        }
    },

    renderSelectAll: function (flag) {
        if (flag) {
            this.isSelectAll = true;
            EventMediator.trigger('EDIT_MODE_SELECT_ALL', true);
        } else {
            this.isSelectAll = false;
            EventMediator.trigger('EDIT_MODE_SELECT_ALL', false);
        }
    },

    setExecuteButtonText: function () {
        var buttonText = null;

        switch (this.executeType) {
        case 'delete':
            buttonText = Volt.i18n.t('COM_SID_DELETE');
            break;
        case 'lock':
        case 'move':
            buttonText = Volt.i18n.t('COM_SID_SAVE');
            break;
            buttonText = Volt.i18n.t('COM_SID_SAVE');
            break;
        case 'update':
            buttonText = Volt.i18n.t('UID_UPDATE');
            break;
        }

        this.buttonExecute.setText({
            state: "all",
            text: buttonText
        });
    },

    updateDeleteBtn: function () {
        Volt.log("[EditButtonGroupView]updateDeleteBtn getCheckedItemCount = " + this.parentView.myAppsVMCollection.getCheckedItemCount());
        if (this.parentView.myAppsVMCollection.modeType == 'delete' || this.parentView.myAppsVMCollection.modeType == 'update') {
            if (this.parentView.myAppsVMCollection.getCheckedItemCount() > 0) {
                if (this.buttonExecute) {
                    this.buttonExecute.enable(true);
                    this.buttonExecuteEnableFlag = true;
                    //this.widget.getChild('edit-exceute-button').custom.focusable = true;
                    //Volt.Nav.reload();
                    Volt.Nav.addItem(this.widget.getChild('edit-exceute-button'), true);

                }
            } else {
                if (this.buttonExecute) {
                    this.buttonExecute.enable(false);
                    this.buttonExecuteEnableFlag = false;
                    //                    this.widget.getChild('edit-exceute-button').custom.focusable = true;
                    //                    Volt.Nav.reload();
                    Volt.Nav.addItem(this.widget.getChild('edit-exceute-button'), true);
                }
            }
        } else {
            if (this.buttonExecute) {
                Volt.log("[EditButtonGroupView]updateDeleteBtn buttonExecute enable");
                this.buttonExecute.enable(true);
                this.buttonExecuteEnableFlag = true;
                //this.widget.getChild('edit-exceute-button').custom.focusable = true;
                //Volt.Nav.reload();
                Volt.Nav.addItem(this.widget.getChild('edit-exceute-button'), true);
            }
        }
    },

    /**
     * Expand category area on focus
     */
    expand: function () {
        Volt.log('[EditButtonGroupView] expand()');
        if (this.expendAnimation) {
            this.expendAnimation.stop();
        }
        if (this.shrinkAnimation) {
            this.shrinkAnimation.stop(true);
        }
        this.expendAnimation = new MultiObjectTransition();
        this.expendAnimation.setDuration(MENU_ANIM_DURATION);

        var editCategory = this.parent.getChild('main-category-container');

        this.expendAnimation.AddObjectDestination(editCategory, "y", Volt.height * 0.1);
        this.expendAnimation.AddObjectDestination(editCategory, "size", {
            w: editCategory.width,
            h: Volt.height * 0.1
        });
        this.expendAnimation.AddObjectDestination(this.widget, "y", 0);
        this.expendAnimation.AddObjectDestination(this.widget, "size", {
            w: this.widget.width,
            h: Volt.height * 0.1
        });

        if (this.parentView && this.parentView.headerCover) {
            this.expendAnimation.AddObjectDestination(this.parentView.headerCover, "size", {
                w: this.parentView.headerCover.width,
                h: Volt.height * 0.1
            });
        }

        var underbarBg = this.parent.getChild('main-category-underbar-container');
        this.expendAnimation.AddObjectDestination(underbarBg, "y", Volt.height * 0.1);

        this.expendAnimation.AddObjectDestination(Volt.find(this.widget, '.edit-mode-selected-text')[0], "y", Volt.height * 0.0166667);
        this.expendAnimation.AddObjectDestination(Volt.find(this.widget, '.edit-mode-selected-count')[0], "y", Volt.height * 0.0166667);
        this.expendAnimation.AddObjectDestination(this.deleteBg, "size", {
            w: this.deleteBg.width,
            h: Volt.height * 0.099074
        });
        this.expendAnimation.AddObjectDestination(this.selectAllBg, "size", {
            w: this.selectAllBg.width,
            h: Volt.height * 0.099074
        });
        this.expendAnimation.AddObjectDestination(this.cancelBg, "size", {
            w: this.cancelBg.width,
            h: Volt.height * 0.099074
        });

        _.each(this.widget.find('.multi_seletion_buttons_bar'), function (wz) {
            this.expendAnimation.AddObjectDestination(wz, "size", {
                w: wz.width,
                h: Volt.height * 0.099074
            });
        }.bind(this));

        this.buttonExecute.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonSelect.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonCancel.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        this.expendAnimation.play();
        /*var editCategory = this.parent.getChild('main-category-container');
        editCategory.animate('y', scene.height * 0.1, MENU_ANIM_DURATION);
        editCategory.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);
        this.widget.animate('y', 0, MENU_ANIM_DURATION);
        this.widget.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);

        if (this.parentView && this.parentView.headerCover) {
            this.parentView.headerCover.animate('height', scene.height * 0.1, MENU_ANIM_DURATION);
        }

        var underbarBg = this.parent.getChild('main-category-underbar-container');
        underbarBg.animate('y', scene.height * 0.1, MENU_ANIM_DURATION);

        Volt.find(this.widget, '.edit-mode-selected-text')[0].animate('y', scene.height * 0.0166667, MENU_ANIM_DURATION);
        Volt.find(this.widget, '.edit-mode-selected-count')[0].animate('y', scene.height * 0.0166667, MENU_ANIM_DURATION);
        this.deleteBg.animate('height', scene.height * 0.099074, MENU_ANIM_DURATION);
        this.buttonExecute.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        this.selectAllBg.animate('height', scene.height * 0.099074, MENU_ANIM_DURATION);
        this.buttonSelect.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        this.cancelBg.animate('height', scene.height * 0.099074 + 8, MENU_ANIM_DURATION);
        this.buttonCancel.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.099074 + ((Volt.APPS720P) ? 6 : 8));
        _.each(this.widget.find('.multi_seletion_buttons_bar'), function (wz) {
            wz.animate('height', scene.height * 0.099074, MENU_ANIM_DURATION);
        });*/
    },

    /**
     * Shrink category area on blur
     */
    shrink: function () {
        Volt.log('[EditButtonGroupView] shrink()');

        if (this.shrinkAnimation) {
            this.shrinkAnimation.stop();
        }
        if (this.expendAnimation) {
            this.expendAnimation.stop(true);
        }
        this.shrinkAnimation = new MultiObjectTransition();
        this.shrinkAnimation.setDuration(MENU_ANIM_DURATION);

        var editCategory = this.parent.getChild('main-category-container');

        this.shrinkAnimation.AddObjectDestination(editCategory, "y", Volt.height * 0.133333);
        this.shrinkAnimation.AddObjectDestination(editCategory, "size", {
            w: editCategory.width,
            h: Volt.height * 0.066667
        });
        this.shrinkAnimation.AddObjectDestination(this.widget, "y", 0);
        this.shrinkAnimation.AddObjectDestination(this.widget, "size", {
            w: this.widget.width,
            h: Volt.height * 0.066667
        });

        if (this.parentView && this.parentView.headerCover) {
            this.shrinkAnimation.AddObjectDestination(this.parentView.headerCover, "size", {
                w: this.parentView.headerCover.width,
                h: Volt.height * 0.133333
            });
        }

        var underbarBg = this.parent.getChild('main-category-underbar-container');
        this.shrinkAnimation.AddObjectDestination(underbarBg, "y", Volt.height * 0.133333);

        this.shrinkAnimation.AddObjectDestination(Volt.find(this.widget, '.edit-mode-selected-text')[0], "y", 0);
        this.shrinkAnimation.AddObjectDestination(Volt.find(this.widget, '.edit-mode-selected-count')[0], "y", 0);
        this.shrinkAnimation.AddObjectDestination(this.deleteBg, "size", {
            w: this.deleteBg.width,
            h: Volt.height * 0.065741
        });
        this.shrinkAnimation.AddObjectDestination(this.selectAllBg, "size", {
            w: this.selectAllBg.width,
            h: Volt.height * 0.065741
        });
        this.shrinkAnimation.AddObjectDestination(this.cancelBg, "size", {
            w: this.cancelBg.width,
            h: Volt.height * 0.065741
        });

        _.each(this.widget.find('.multi_seletion_buttons_bar'), function (wz) {
            this.shrinkAnimation.AddObjectDestination(wz, "size", {
                w: wz.width,
                h: Volt.height * 0.065741
            });
        }.bind(this));

        this.buttonExecute.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonSelect.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonCancel.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        this.shrinkAnimation.play();

        /*var editCategory = this.parent.getChild('main-category-container');
        editCategory.animate('y', scene.height * 0.133333, MENU_ANIM_DURATION);
        editCategory.animate('height', scene.height * 0.066667, MENU_ANIM_DURATION);
        this.widget.animate('y', 0, MENU_ANIM_DURATION);
        this.widget.animate('height', scene.height * 0.066667, MENU_ANIM_DURATION);
        if (this.parentView && this.parentView.headerCover) {
            this.parentView.headerCover.animate('height', scene.height * 0.133333, MENU_ANIM_DURATION);
        }

        var underbarBg = this.parent.getChild('main-category-underbar-container');
        underbarBg.animate('y', scene.height * 0.133333, MENU_ANIM_DURATION);

        Volt.find(this.widget, '.edit-mode-selected-text')[0].animate('y', 0, MENU_ANIM_DURATION);
        Volt.find(this.widget, '.edit-mode-selected-count')[0].animate('y', 0, MENU_ANIM_DURATION);
        this.deleteBg.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        this.selectAllBg.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        this.cancelBg.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        this.buttonExecute.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonSelect.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        this.buttonCancel.setSize(Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8), Volt.height * 0.065741 + ((Volt.APPS720P) ? 6 : 8));
        _.each(this.widget.find('.multi_seletion_buttons_bar'), function (wz) {
            wz.animate('height', scene.height * 0.065741, MENU_ANIM_DURATION);
        });*/

    },

    onSelectButton: function (widget) {
        Volt.log('[MyAppsView] onSelectButton   this.isSelectAll    ' + this.isSelectAll);
        var modeType = this.parentView.myAppsVMCollection.modeType;
        switch (widget.id) {
        case 'select-all-button':
            if (this.isSelectAll) { //title is deselect
                this.renderSelectAll(false);
            } else { //title is select
                this.renderSelectAll(true);
            }
            CommonFunctions.voiceGuide(this.buttonSelect.text() + ',' + Volt.i18n.t('TV_SID_BUTTON'));
            break;
        case 'delete-button':
            if(modeType == 'move') {
                EventMediator.trigger('UPDATE_MYAPPS_DATA');
            }
            EventMediator.trigger('EDIT_MODE_EXECUTE', this.executeType);
            break;
        case 'cancel-button':
            var modeType = this.parentView.myAppsVMCollection.modeType;
            EventMediator.trigger('HIDE_EDIT_MODE');
            if(modeType == 'move') {
                EventMediator.trigger('UPDATE_MYAPPS_VIEW');
            }
            break;
        }
    },
    createButton: function (parent, text) {
        Volt.log("[multi-selection.js]In function createButton");
        var that = this;



        var btn = Volt.loadTemplate(MyAppsTemplate.generalBtn);




        btn.setText({
            state: "all",
            text: text
        });


        btn.setTextColor({
            state: 'normal',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'focused',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'roll-over',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'focused-roll-over',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'selected',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 255
            }
        });
        btn.setTextColor({
            state: 'disabled',
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 77
            }
        });

        btn.setTextColor({
            state: "disabled-focused",
            color: {
                r: 255,
                g: 255,
                b: 255,
                a: 77
            }
        });


        btn.setFontSize({
            state: "normal",
            size: (Volt.APPS720P) ? 18 : 28
        });
        btn.setFontSize({
            state: "disabled",
            size: (Volt.APPS720P) ? 18 : 28
        });
        btn.setFontSize({
            state: "disabled-focused",
            size: (Volt.APPS720P) ? 20 : 31
        });
        btn.setFontSize({
            state: "roll-over",
            size: (Volt.APPS720P) ? 20 : 31
        });
        btn.setFontSize({
            state: "focused-roll-over",
            size: (Volt.APPS720P) ? 20 : 31
        });
        btn.setFontSize({
            state: "selected",
            size: (Volt.APPS720P) ? 20 : 31
        });
        btn.setFontSize({
            state: "focused",
            size: (Volt.APPS720P) ? 20 : 31
        });


        btn.setBackgroundColor({
            state: "all",
            color: {
                r: 255,
                g: 0,
                b: 255,
                a: 0
            }
        });


        btn.setBackgroundImage({
            state: "focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "normal",
            src: '',
        });
        btn.setBackgroundImage({
            state: "roll-over",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "focused-roll-over",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "disabled",
            src: '',
        });
        btn.setBackgroundImage({
            state: "disabled-focused",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });
        btn.setBackgroundImage({
            state: "selected",
            src: Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png')
        });

        btn.setTextAttr({
            x: ((Volt.APPS720P) ? 6 : 8),
            y: 0,
            width: Volt.width * 0.15625 - ((Volt.APPS720P) ? 6 : 8),
            height: Volt.height * 0.063889 + ((Volt.APPS720P) ? 12 : 16), //to avoid letters cutting, add the magic number. add by caoyr 
            hAlign: "center",
            vAlign: "middle"
        });

        btn.parent = parent;
        btn.addListener(that.btnListener);
        btn.show();

        return btn;
    },
});

exports = MyAppsView;
