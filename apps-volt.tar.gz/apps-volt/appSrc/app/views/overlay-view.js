var Backbone = Volt.require('lib/volt-backbone.js'),
    DimView = Volt.require("lib/views/dim-view.js"),
    LoadingPopup = Volt.require("lib/views/loading-popup.js"),

    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js');

var OverlayView = Backbone.View.extend({
    bLoading: false,

    initialize: function () {
        this.listenTo(EventMediator, 'EVENT_OVERLAY_SHOW_DIM', this.onShowDim);
        this.listenTo(EventMediator, 'EVENT_OVERLAY_HIDE_DIM', this.onHideDim);
        this.listenTo(EventMediator, 'EVENT_OVERLAY_DIM_ALL', this.onAllDim);
        this.listenTo(EventMediator, 'EVENT_OVERLAY_SHOW_LOADING', this.onShowLoading);
        this.listenTo(EventMediator, 'EVENT_OVERLAY_HIDE_LOADING', this.onHideLoading);

        this.listenTo(EventMediator, 'VOLT_DEACTIVATE', this.onDeactivate);
        this.listenTo(EventMediator, 'VOLT_ACTIVATE', this.onActivate);
    },

    //    show: function () {
    //
    //    },
    //
    //    hide: function () {
    //
    //    },

    onShowDim: function () {
        Volt.log('[overlay-view.js @onShowDim]');
        DimView.show();
    },

    onHideDim: function () {
        Volt.log('[overlay-view.js @onHideDim]');
        // If the app is in deactivate state, don't hide dim
        if (CommonFunctions.getAppState() == CommonDefines.AppState.APP_STATE_ACTIVATE) {
            DimView.hide();
        }
    },

    onAllDim: function () {
        Volt.log('[overlay-view.js @onAllDim]');
        DimView.dimmall();
    },

    onShowLoading: function (dim) {
        Volt.log('[overlay-view.js @onShowLoading]');
        this.bLoading = true;

        if (dim !== false) {
            this.onShowDim();
        }
        LoadingPopup.show();
    },

    onHideLoading: function (dim) {
        Volt.log('[overlay-view.js @onHideLoading]');
        this.bLoading = false;
        if (dim !== false) {
            this.onHideDim();
        }
        LoadingPopup.hide();
    },

    isLoading: function () {
        return this.bLoading;
    },

    onDeactivate: function () {
        if (Volt.DeviceInfoModel.get('mls') == 1) {
            Volt.log('[overlay-view.js @onDeactivate] mls mode');
            if (!this.isLoading()) {
                DimView.hide();
            }
            if (!Volt.Nav.isPause()) {
                Volt.Nav.pause();
            }
        } else {
            this.onShowDim();
        }
    },

    onActivate: function () {
        if (!this.isLoading()) {
            DimView.hide();
        }
        if (Volt.Nav.isPause()) {
            Volt.Nav.resume();
        }
    },
});

exports = new OverlayView();