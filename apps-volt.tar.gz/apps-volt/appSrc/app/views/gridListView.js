var Backbone = Volt.require('lib/volt-backbone.js'),
    _ = Volt.require('modules/underscore.js')._,
    CommonDefines = Volt.require('app/common/commonDefines.js');

var WinsetScroll = Volt.require("modules/WinsetUIElement/winsetScroll.js");
var EventMediator = Volt.require('app/common/eventMediator.js');
var GridListTemplate = Volt.require('app/templates/grid-list-template.js');

//var defaultimage = new Image(Volt.getRemoteUrl('images/1080/common/icon/icon_blank_thumbnail.png'));

var GridlistView = Volt.BaseView.extend({

    gridListControl: null,

    gridListControlParam: null,
    listeners: null,

    gridListener: null,
    keyboardListener: null, // Keyboard Listener for this grid
    
    bHandleKeyRelease: false,
    bLongPress: false,
    bFocused: false,
    bshowScroll: true,

    rendererProvider: null,
    
    rows: 0,
    cols: 0,

    events: {
        'NAV_FOCUS': 'onFocus',
        'NAV_BLUR': 'onBlur'
    },

    dataPointers: null,

    initialize: function (options) {

        // options: {
        //     gridListControlParam: {
        //         x : 0, y : 0, width : 1920, height : 864,
        //         titleSpace : 0, groupSpace : 0, cellSpace : 0,
        //         focusRangeStartOffset : 0, focusRangeEndOffset : 0,
        //         itemWidth : 196, itemHeight : 288
        //     },
        //     
        //     listeners: {
        //         onDrawLoadData
        //         onDrawUpdateData
        //         onItemPress
        //         onGridFocus
        //         onGridBlur
        //         onEnterKeyLongPressed
        //     }
        // }
        
        this.dataPointers = [];

        this.gridListControlParam = options.gridListControlParam;
        this.thumbnailStyle = options.thumbnailStyle;
        this.listeners = options.listeners;
        this.bshowScroll = options.bShowScroll != undefined ? options.bShowScroll : true;

        this.gridListControl = this.initGridListControl(options.gridListControlParam);
        this.setWidget(this.gridListControl);

        // Relations with volt-nav
        this.widget.onKeyEvent = _.bind(this.onKeyEvent, this);
        this.gridListControl.widgetType = 'NativeGrid';


        var keyboardListener = new KeyboardListener;
        // Fix: to judge if onItemPress() is trigger, press should be detected first.
        keyboardListener.onKeyPressed = function (actor, keyCode) {
            Volt.log('[GridListView.js @onKeyPressed]');
            if (keyCode == Volt.KEY_JOYSTICK_OK) {
                actor.__bKeyPressed_OK = true;
            }
        };

        keyboardListener.onKeyReleased = function (actor, keyCode) {
            if (keyCode == Volt.KEY_JOYSTICK_OK) {
                Volt.err('[GridListView] keyboardListener.onKeyReleased, this.bLongPress   ' + this.bLongPress);
                if (!this.bLongPress) {

                    if (actor.__bKeyPressed_OK) {
                        var focusItem = actor.getFocusItemIndex();
                        var data = actor.getData(focusItem.groupIndex, focusItem.itemIndex);
                        this.listeners.onItemPress(this.getFocusedWidget(), focusItem, data);
                    }
                    actor.__bKeyPressed_OK = false;

                } else {
                    Volt.err('[GridListView] ************************trigger    EVENT_LONGPRESS_RELEASE*******************************');
                    EventMediator.trigger(CommonDefines.Event.EVENT_LONGPRESS_RELEASE, actor);
                }
                this.bLongPress = false;
            }
        }.bind(this);
        this.gridListControl.addKeyboardListener(keyboardListener);

        this.keyboardListener = keyboardListener;
    },
    
    render: function (collection) {
        Volt.err('[GridListView] render');

        // Add empty cells
        var gridInfo = this.gridListControlParam;

        this.rows = Math.floor(gridInfo.height / gridInfo.itemHeight);
        this.cols = Math.ceil(collection.length / this.rows);

        this.gridListControl.addRegularGrid({
            groupIndex: 0,
            styleIndex: 0,
            columnNumber: this.cols,
            rowNumber: this.rows,
            columnWidth: gridInfo.itemWidth,
            rowHeight: gridInfo.itemHeight
        });

        // Add data
        var data = null;
        for (var i = 0; i < collection.length; i++) {
            this.addData(collection.at(i), i);
        }
        this.gridListControl.loadData();
        this.gridListControl.enableFocus();
        //this.gridListControl.showFocus('false');
        //this.gridListControl.hideFocus('true');
        return this;
    },
    
    remove: function () {
        Volt.log('[gridListView.js @remove]');
        
        if (this.widget) {
            if (this.gridListener) {
                this.gridListener.destroy();
                this.gridListener = null;
            }
            if (this.keyboardListener) {
                this.widget.removeKeyboardListener(this.keyboardListener);
                this.keyboardListener.destroy();
                this.keyboardListener = null;
            }

            this.gridListControl.destroy();
            this.gridListControl = null;

            this.widget = null;
        }
        
        if (this.rendererProvider) {
            this.rendererProvider.destroy();
            this.rendererProvider = null;
        }

        this.gridListControlParam = null;
        this.listeners = null;

        this.dataPointers.length = 0;
        this.dataPointers = null;
    },
    
    onFocus: function () {
        Volt.err('[GridListView] onFocus');

        // below 2 APIs makes onEnterKeyLongPressed work.
        if (this.gridListControl) {

            if ( this.listeners.onFocusPolicy ){
                this.listeners.onFocusPolicy(this.gridListControl);
            }
            
            this.gridListControl.enableFocus();
            this.gridListControl.setFocus();
            this.gridListControl.showFocus('false');
            //this.gridListControl.showWithAnimation();
        }

        this.bFocused = true;
        this.listeners.onGridFocus(this.getFocusedWidget());
    },

    onBlur: function () {
        Volt.err('[GridListView] onBlur');
        if (this.gridListControl) {
            this.gridListControl.hideFocus('true');
            //this.gridListControl.hideWithAnimation();
        }
        this.bFocused = false;
        this.listeners.onGridBlur(this.getFocusedWidget());
    },

    onItemPress: function () {
        Volt.err('[GridListView] onItemPress');

    },

    onKeyEvent: function (keycode, keytype) {
        Volt.err('[GridListView] onKeyEvent   keytype    ' + keytype);

        if (keytype == Volt.EVENT_KEY_RELEASE) {
            return;
        }
        
        switch (keycode) {
        case Volt.KEY_JOYSTICK_UP:
            this.gridListControl.moveFocus('Up');
            return true;
        case Volt.KEY_JOYSTICK_DOWN:
            this.gridListControl.moveFocus('Down');
            return true;
        case Volt.KEY_JOYSTICK_LEFT:
            this.gridListControl.moveFocus('Left');
            return true;
        case Volt.KEY_JOYSTICK_RIGHT: 
            this.gridListControl.moveFocus('Right');
            return true;
        default:
            return false;
        }
    },

    getFocusedWidget: function () {
        var itemIdx = this.gridListControl.getFocusItemIndex(),
            focusedWz = this.getWidget(itemIdx.groupIndex, itemIdx.itemIndex);

        Volt.err('[GridListView] getFocusedWidget ' + JSON.stringify(itemIdx));
        Volt.err('[GridListView] getFocusedWidget returns ' + focusedWz);
        return focusedWz;
    },

    getWidget: function (groupIndex, itemIndex) {
        var itemData = null,
            wz = null;
        if (groupIndex >= 0 && itemIndex >= 0) {
            itemData = this.gridListControl.getData(groupIndex, itemIndex);

            if (itemData) {
                wz = itemData.thumbnail;
            }
        }

        return wz;
    },

    addData: function (model, index) {
        Volt.log('[GridListView] addData');

        var data = new Data();
        data.isReady = false;

        data.model = model;
        data.thumbnail = null; // this property will set at onDraw()
        data.parent = this.gridListControl;

        // Avoid garbage collecting Halo Data instances
        this.dataPointers.push(data);

        if (index !== undefined) {
            data._index = index;
        } else {
            data._index = this.gridListControl.itemCount(0);
        }

        print('[grid-list-view.js] data._index: ' + data._index);

        this.gridListControl.addData({
            groupIndex: 0,
            data: data
        });
    },

    addItem: function (model) {
        Volt.log('[GridListView] addItem');

        if (this.isFull()) {
            this.addColumn();
        }

        this.addData(model);
        this.gridListControl.loadData(false);
    },

    removeItem: function (fromItemIndex, toItemIndex) {
        Volt.err('[GridListView] removeItem ' + fromItemIndex + ',' + toItemIndex);

        this.gridListControl.removeData({
            groupIndex: 0,
            fromItemIndex: fromItemIndex,
            toItemIndex: toItemIndex,
            needUpdate: true
        });
    },

    isFull: function () {
        var groupIndex = 0,
            styleIndex = 0,
            columnCount, itemCount, bFull;

        columnCount = this.gridListControl.columnCount(groupIndex, styleIndex);
        itemTotal = this.gridListControl.itemCount(groupIndex);

        bFull = (columnCount * this.rows) <= itemTotal;
        Volt.err('[GridListView] isFull returns ' + bFull);

        return bFull;
    },

    addColumn: function () {
        Volt.err('[GridListView] addColumn');

        var groupIndex = 0,
            styleIndex = 0,
            columnWidth = this.gridListControlParam.itemWidth,
            rowHeight = this.gridListControlParam.itemHeight,
            columnIndex;

        columnIndex = this.gridListControl.addColumn({
            groupIndex: groupIndex,
            styleIndex: styleIndex,
            columnWidth: columnWidth
        });

        for (var i = 0; i < this.rows; i++) {
            this.gridListControl.addRowToColumn({
                groupIndex: groupIndex,
                styleIndex: styleIndex,
                columnIndex: columnIndex,
                rowHeight: rowHeight
            });
        }
    },

    initGridListControl: function (options) {
        Volt.err('[GridListView] initGridListControl');

        // options: {
        //     x : 0, y : 0, width : 1920, height : 864,
        //     titleSpace : 0, groupSpace : 0, cellSpace : 0,
        //     focusRangeStartOffset : 0, focusRangeEndOffset : 0,
        //     itemWidth : 196, itemHeight : 288
        // }

        // RendererProvider & Renderer
        var rendererProvider = this.rendererProvider = new RendererProvider();
        rendererProvider.funcGetRenderer = _.bind(getRenderer, this);

        // GridListControlListener
        var gridListener = this.gridListener = new GridListControlListener();
        gridListener.onItemLoaded = _.bind(onItemLoaded, this);
        gridListener.onItemUnloaded = _.bind(onItemUnloaded, this);
        gridListener.onFocusChanged = _.bind(onFocusChanged, this);
        gridListener.onFocusChangeStart = _.bind(onFocusChangeStart, this);
        gridListener.onMoveOut = _.bind(onMoveOut, this);
        gridListener.onItemIndexChanged = _.bind(onItemIndexChanged, this);
        gridListener.onItemClicked = _.bind(onItemClicked, this);
        gridListener.onEnterKeyLongPressed = _.bind(onEnterKeyLongPressed, this);


        var gridListControl = new GridListControl(options);
        gridListControl.setRendererProvider(rendererProvider);
        gridListControl.addListListener(gridListener);
        gridListControl.addGroup(1);
        gridListControl.addDataGroup(1);
        gridListControl.enlargeFocusItem(20, 20);
        gridListControl.setAnimationDuration(200);
        gridListControl.setAnimationDuration("itemMove", 200);
        gridListControl.addStyle(1);
        gridListControl.setStyle(0);
        gridListControl.shadowEffectFlag = false;
        if(Volt.DeviceInfoModel.get('highContrast')){
            gridListControl.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/acc_focus.png'), -4, -4);
        }
        else{
            gridListControl.setFocusImage(Volt.getRemoteUrl('images/1080/common/highlight/ksc_focus.png'), -4, -4);
        }
        gridListControl.setThumbnailDefaultImage(Volt.getRemoteUrl('images/1080/common/icon/icon_blank_thumbnail.png'));
        gridListControl.canLoopWhenContinuosKey = false;
        if (isReverseLanguage(Volt.DeviceInfoModel.getLanguageCode())) {
            gridListControl.setOrientation('right-to-left');
        }



        if (this.bshowScroll) {
            var scroll = getScroll(options);
            gridListControl.attachScrollBar(scroll);
        }

        return gridListControl;
    }

});

// Renderer
function getRenderer(parentWidth, parentHeight, data) {
    Volt.log('[GridListView] getRenderer');

    var renderer = new Renderer(parentWidth, parentHeight);

    var thumbStyle = {};

    switch(this.thumbnailStyle){
        case GridListTemplate.THUMB_WHATS_NEW:{
            if(data._index == 1){
                Volt.log('[GridListView] getRenderer thumbnail style THUMB_PIA');
                thumbStyle = _.clone(GridListTemplate.getThumbnailTemplate('THUMB_PIA'));
            }
            else{
                Volt.log('[GridListView] getRenderer thumbnail style is THUMB_WHATS_NEW');
                thumbStyle = _.clone(GridListTemplate.getThumbnailTemplate('THUMB_WHATS_NEW'));
            }
            break;
        }
        case GridListTemplate.THUMB_MOST_POPULAR:{
            Volt.log('[GridListView] getRenderer thumbnail style is THUMB_MOST_POPULAR');
            thumbStyle = _.clone(GridListTemplate.getThumbnailTemplate('THUMB_MOST_POPULAR'));
            break;
        }
        case GridListTemplate.THUMB_CATEGORY:{
            Volt.log('[GridListView] getRenderer thumbnail style is THUMB_CATEGORY');
            thumbStyle = _.clone(GridListTemplate.getThumbnailTemplate('THUMB_CATEGORY'));
            break;
        }
        case GridListTemplate.THUMB_RELATED:{
            Volt.log('[GridListView] getRenderer thumbnail style is THUMB_RELATED');
            thumbStyle = _.clone(GridListTemplate.getThumbnailTemplate('THUMB_RELATED'));
            break;
        }
        case GridListTemplate.THUMB_SCREENSHOT:{
            Volt.log('[GridListView] getRenderer thumbnail style is THUMB_SCREENSHOT');
            thumbStyle = _.clone(GridListTemplate.getThumbnailTemplate('THUMB_SCREENSHOT'));
            break;
        }
        default:
            Volt.log('[GridListView] getRenderer empty thumbnail style');
            break;
    }
    
    _.extend(thumbStyle,{
            width: parentWidth,
            height: parentHeight,
            border: {width:1, color: Volt.hexToRgb('#c9c9c9', 100)},
            color: Volt.hexToRgb('#d4d4d4', 100)
        });
    renderer.thumbnail = new Thumbnail(thumbStyle);
    renderer.thumbnail.setStyleTransAnimation(330);
    renderer.thumbnail.setScaleAnimation(330);
    renderer.thumbnail.show();

    renderer.onDraw = _.bind(function (rendererInstance, drawTypeString, data, parentWidth, parentHeight) {

        if (!data) {
            Volt.err('[GridListView][Renderer] onDraw() -> data is null!');
            return;
        }

        data.thumbnail = rendererInstance.thumbnail;

        Volt.err('[GridListView][Renderer] onDraw() ' + drawTypeString + ' : ' + (data.model.get('app_title') || data.model.get('title')));

        if (drawTypeString == 'LoadData') {
            this.listeners.onDrawLoadData(rendererInstance.thumbnail, data);
        } else if (drawTypeString == 'UpdateData') {
            this.listeners.onDrawUpdateData(rendererInstance.thumbnail, data);
        } else if (drawTypeString == 'UnloadData') {
            this.listeners.onDrawUnloadData(rendererInstance.thumbnail, data);
        }

    }, this);
    renderer.onResize = _.bind(function (data, destWidth, destHeight, flagWithAni, duration) {
        Volt.err('[GridListView][Renderer] onResize');
    }, this);

    return renderer;
}

// GridListControlListener
function onItemLoaded(gridList, groupIndex, itemIndex) {
    Volt.err('[GridListControlListener] onItemLoaded -> ' + itemIndex);

    var data = gridList.getData(groupIndex, itemIndex);
    if (data) {
        data.isReady = true;
    }
}

function onItemUnloaded(gridList, groupIndex, itemIndex) {
    Volt.err('[GridListControlListener] onItemUnloaded -> ' + itemIndex);

    var data = gridList.getData(groupIndex, itemIndex);
    if (data) {
        data.isReady = false;
    }
}

function onFocusChanged(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
    Volt.err('[GridListControlListener] onFocusChanged from(' + fromGroupIndex + ',' + fromItemIndex + ')' + ' to(' + toGroupIndex + ',' + toItemIndex + ')');

    var data, wzFrom = null,
        wzTo = null;

    if (typeof this.listeners.onFocusChanged != 'function') {
        return;
    }

    if (fromGroupIndex >= 0 && fromItemIndex >= 0) {
        data = gridList.getData(fromGroupIndex, fromItemIndex);
        wzFrom = data ? data.thumbnail : null;
    }
    if (toGroupIndex >= 0 && toItemIndex >= 0) {
        data = gridList.getData(toGroupIndex, toItemIndex);
        wzTo = data ? data.thumbnail : null;
    }
    this.listeners.onFocusChanged(wzFrom, wzTo, fromItemIndex, toItemIndex, gridList);
}

function onFocusChangeStart(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
    Volt.err('[GridListControlListener] onFocusChangeStart from(' + fromGroupIndex + ',' + fromItemIndex + ')' + ' to(' + toGroupIndex + ',' + toItemIndex + ')');

    var data, wzFrom = null,
        wzTo = null;

    if (typeof this.listeners.onFocusChangeStart != 'function') {
        return;
    }

    if (fromGroupIndex >= 0 && fromItemIndex >= 0) {
        data = gridList.getData(fromGroupIndex, fromItemIndex);
        wzFrom = data ? data.thumbnail : null;
    }
    if (toGroupIndex >= 0 && toItemIndex >= 0) {
        data = gridList.getData(toGroupIndex, toItemIndex);
        wzTo = data ? data.thumbnail : null;
    }
    this.listeners.onFocusChangeStart(wzFrom, wzTo);
}

function onMoveOut(gridList, directionString, fromGroupIndex, fromItemIndex) {
    Volt.err('[GridListControlListener] onMoveOut ' + directionString);
    if ("Up" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_UP);
    }
    else if ("Down" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_DOWN);
    }
    else if ("Left" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_LEFT);
    }
    else if ("Right" == directionString)
    {
        Volt.Nav.handleKeyPress(Volt.KEY_JOYSTICK_RIGHT);
    }
}

function onItemIndexChanged(gridList, fromGroupIndex, fromItemIndex, toGroupIndex, toItemIndex) {
    Volt.err('[GridListControlListener] onItemIndexChanged');
    if(gridList.editFlag == true){
        Volt.err('[GridListControlListener] gridList.editFlag  is true');
        if(this.listeners.onItemIndexChanged){
            this.listeners.onItemIndexChanged(gridList,fromItemIndex,toItemIndex);
        }
    }else{
        Volt.err('[GridListControlListener] gridList.editFlag  is false');
    }  
}

function onItemClicked(gridList, groupIndex, itemIndex) {
    Volt.err('[GridListControlListener] onItemClicked');

    var focusItem = this.widget.getFocusItemIndex();
    var data = this.widget.getData(focusItem.groupIndex, focusItem.itemIndex);
    this.listeners.onItemPress(this.getFocusedWidget(), focusItem, data);
}

function onEnterKeyLongPressed(gridList, groupIndex, itemIndex, type) {
    Volt.err('[GridListControlListener] onEnterKeyLongPressed ' + this.bLongPress + ' ' + this.bFocused);

    var wz = null;
    wz = this.getWidget(groupIndex, itemIndex);
    if (type == 'keyboard' && !this.bLongPress && this.bFocused) { // grid???? ??????? ?????? long press ???T?? ???? ?? ó????? ???? ?????? isFocused üu??
        this.bLongPress = true; //blongpress is used for keyboard to judge, mouse process do not need this flag
        this.listeners.onEnterKeyLongPressed(wz, itemIndex, type);
    } else if (type == 'mouse' && this.bFocused) {
        this.listeners.onEnterKeyLongPressed(wz, itemIndex, type);
    }
}

// Scroll
function getScroll(options) {
    Volt.err('[GridListView] getScroll');

    var scroll = new WinsetScroll({
        style: 4,
        parent: scene,
        x: 0,
        y: options.height - Math.floor(Volt.height * 0.021296),
        minValue: 0,
        maxValue: 100,
        value: 0,
        width: options.width,
        height: Volt.height * 0.006481,
    });

    return scroll;
}

function isReverseLanguage(languageCode) {
    return (languageCode == 'ar') || (languageCode == 'fa') || (languageCode == 'he') || (languageCode == 'ur');
}

exports = GridlistView;