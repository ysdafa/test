// Include libraries
var _ = Volt.require('modules/underscore.js')._;
var Backbone = Volt.require('lib/volt-backbone.js');
var CommonDefine = Volt.require('app/common/commonDefines.js');
var EventMediator = Volt.require('app/common/eventMediator.js');
//var CommonFucntion 		= Volt.require('app/common/common-function.js');
var DeletePopupTemplate = Volt.require('app/templates/1080/delete-popup-template.js');
//var CommonContent 		= Volt.require('app/common/common-content.js');
//var voltApiWrapper    = Volt.require("app/common/voltapi-wrapper.js");
var WinsetButton = Volt.require("modules/WinsetUIElement/winsetButton.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var tvResolution = WinsetBase.ResolutionStyle.Resolution_1080;
var CommonWidgetPopup = Volt.require('app/common/commonWidgetPopup.js');
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");

var DeletePopup = Backbone.View.extend({
    template: DeletePopupTemplate.container,
    params: null,
    totalNum: 0,
    currentNum: 0,
    progressBar: null,
    appID: null,
    currentID: null,
    isMulti: false,
    timer: null,
    isShow: false,
    btnListener: new ButtonListener(),
    percentText: null,
    successFlag: true,
    render: function () {},

    show: function (options) {
        Volt.log('[delete-popup.js] show options =' + options);

        this.params = JSON.parse(options);
        this.currentNum = 1;
        this.appID = this.params.app_id;
        this.isMulti = this.params.isMulti;
        if (!this.isMulti) {
            this.totalNum = 1;
        } else {
            this.totalNum = this.appID.length;
        }
        this.setWidget(Volt.loadTemplate(this.template));
        this.widget.show();
        this.renderDescrption();
        this.renderProgressBar();
        this.renderButton();
        if (!this.isMulti) {
            this.cancelButton.hide();
        }
        this.isShow = true;
        Volt.Nav.beginModal(this.widget);
        this.cancelButton.setFocus();
        this.percentText = this.widget.getChild('percentText-container');
        this.bindListening();

        if(1 == this.params.currentNum){
            this.currentNum = 2;
             if (this.progressBar) {
             var percent = this.currentNum/this.totalNum;
                this.progressBar.value = Math.floor(percent * 0.492188 * Volt.width);
            }
            this.percentText.text = Math.ceil(percent * 100) + '%';
        } 
        this.updateDescription();
    },

    bindListening: function () {
        this.listenTo(EventMediator, CommonDefine.Event.EVENT_HIDE_DELETE_POPUP, _.bind(this.cancelDeletePopup, this));
        this.listenTo(EventMediator, 'VOLT_DEACTIVATE', _.bind(this.hide, this));
        this.listenTo(EventMediator, CommonDefine.Event.UNINSTALLING, _.bind(this.updateProgress, this));
        this.listenTo(EventMediator, CommonDefine.Event.UNINSTALL_COMPLETED, _.bind(this.finishDelete, this));
        this.listenTo(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_NOT_EXIST, _.bind(this.failDelete, this));
        this.listenTo(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_PKGMGR_ERROR, _.bind(this.failDelete, this));
        this.listenTo(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_NOT_REMOVABLE, _.bind(this.failDelete, this));
        this.listenTo(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_OTHERS, _.bind(this.failDelete, this));


        
    },

    unbindListening: function () {
        //EventMediator.off(CommonDefine.Event.UNINSTALLING);
        //EventMediator.off(CommonDefine.Event.UNINSTALL_COMPLETED);
        this.stopListening(EventMediator, CommonDefine.Event.UNINSTALLING);
        this.stopListening(EventMediator, CommonDefine.Event.UNINSTALL_COMPLETED);
        this.stopListening(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_NOT_EXIST);
        this.stopListening(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_PKGMGR_ERROR);
        this.stopListening(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_NOT_REMOVABLE);
        this.stopListening(EventMediator, CommonDefine.Event.UNINSTALL_FAIL_OTHERS);
        this.stopListening(EventMediator, 'VOLT_DEACTIVATE');
        this.stopListening(EventMediator, CommonDefine.Event.EVENT_HIDE_DELETE_POPUP);
    },
    failDelete: function (eventInfo) {
        Volt.log('[delete-popup.js] failDelete');
        this.successFlag = false;
        if(eventInfo && eventInfo.app_id) {
             if (eventInfo.failCode) {           
                 if ("0" == eventInfo.failCode){
                     Volt.log('[delete-popup.js] failDelete:WAS crash,return 0!!!');
                      this.allUninstallFinishedCB();
                 }
             }      
        }
        Volt.log('[delete-popup.js] failDelete:this.currentNum is ' + this.currentNum);
        Volt.log('[delete-popup.js] failDelete:this.totalNum is ' + this.totalNum);
        if (this.currentNum >= this.totalNum) {
            Volt.log('[delete-popup.js] failDelete:this.allUninstallFinishedCB');
            this.allUninstallFinishedCB();
        }
        this.currentNum++;
    },
    _onkeyEvent: function (keyCode, keyType) {
        if (keyType == Volt.EVENT_KEY_RELEASE) {
            return false;
        }
        print("_onkeyEvent  " + keyCode);
        switch (keyCode) {
        case Volt.KEY_RETURN:
            this.clearTimeOut();
            EventMediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
            break;
        default:
            return false;
            break;
        }

        return true;
    },
    renderDescrption: function () {
        Volt.log('[delete-popup.js] renderDescrption');
        var container = this.widget.getChild('delete-description-container');
        var description = new descriptionView().render().widget;
        container.addChild(description);
        
        var isInUSB = this.isWidgetInstalledInUSB(this.appID);
        if(isInUSB){
            descriptionText.widget.getChild('deleting_Text').text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL')+Volt.i18n.t('TV_SID_NOT_REMOVE_STORAGE_USE');
        } 
		else 
		{
            descriptionText.widget.getChild('deleting_Text').text = Volt.i18n.t('COM_SID_DELETING_KR_PANEL');
        }
    },

    renderProgressBar: function () {
        var container = this.widget.getChild('progressbar-container');
        if (this.isMulti == false) {
            Volt.log('[delete-popup.js] render single ProgressBar');

        } else {
            Volt.log('[delete-popup.js] render multi ProgressBar, appID = ' + this.appID + ' totalNum = ' + this.totalNum);
        }
        this.progressBar = this.createProgressControl(container, 0, 0, 0.492188 * Volt.width, 2);
    },
    renderButton: function () {
        print('renderButton');
        var container = this.widget.getChild('button-container');
        var btnStyleText = {
            style: WinsetButton.ButtonStyle.Button_image_O_Style_F_FOCUS1,
            buttonType: WinsetButton.ButtonType.BUTTON_TEXT,
            resolution: tvResolution,
        }
        this.btnListener.onButtonClicked = function (button, type) {
            this.onSelect();
        }.bind(this);
        this.cancelButton = Volt.loadTemplate(DeletePopupTemplate.deleteCancelBtn, btnStyleText, container);
        if (this.isMulti == true) {
            this.cancelButton.addListener(this.btnListener);
        }

    },
    onSelect: function () {
        EventMediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
    },
    createProgressControl: function (widget, xValue, yValue, width, height) {
        var progress = new Progress({
            parent: widget,
            width: width,
            height: height,
            x: xValue,
            y: yValue,
            direction: "horizontal",
            minValue: 0,
            value: 0,
            maxValue: width,
            color: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100)
        });
        progress.show();
        return progress;
    },
     cancelDeletePopup: function () {
        Volt.log('[delete-popup.js] cancelDeletePopup');
        this.hide();
        
        return;
    },
    hide: function () {
        Volt.log('[delete-popup.js] hide');

        this.clearTimeOut();
        if (this.isMulti == true) {
            voltapi.WAS.cancelMutilUnInstallApps(); 
        }
        AppInstallMgr.unInstallList =  [];
        this.unbindListening();
        Volt.Nav.endModal();
        this.widget.hide();
        this.progressBar = null;
        this.appID = null;
        this.isShow = false;
        Volt.setTimeout(_.bind(this.destroy, this), 1);
        if (CommonDefine.AppState.APP_STATE_ACTIVATE == CommonFunctions.getAppState()) {
            Volt.log('[delete-popup.js] CommonDefines.AppState.APP_STATE_ACTIVATE');
            EventMediator.trigger('EVENT_OVERLAY_HIDE_DIM');
        } else if (CommonDefine.AppState.APP_STATE_DEACTIVATE == CommonFunctions.getAppState()) {
            Volt.log('[delete-popup.js] CommonDefines.AppState.APP_STATE_DEACTIVATE');
            Volt.Nav.focus(null);
        }
        return;
    },

    destroy: function (widget) {
        this.widget.destroy();
    },

    updateProgress: function (eventInfo) {
        Volt.log("[delete-popup.js] updateProgress");
        if (eventInfo) {
            Volt.log("[delete-popup.js] " + eventInfo.app_id + " " + eventInfo.result);
            if (eventInfo.result <= 100) {
                if (this.progressBar) {
                 var percent = (this.currentNum+eventInfo.result/100-1)/this.totalNum;
					Volt.log("[delete-popup.js] percent:" + percent + "~~" +Math.ceil(percent * 0.492188 * Volt.width));
                    this.progressBar.value = Math.floor(percent * 0.492188 * Volt.width);
                    //this.setTimeOut();
                }
                this.percentText.text = Math.ceil(percent * 100) + '%';
            }
        }
    },
    updateDescription: function () {
        if (this.isMulti) {
            this.widget.getDescendant('deleting_Number_Text').text = Volt.i18n.t('COM_MIX_TOTAL_KR_BLANK').replace('<<A>>', this.currentNum).replace('<<B>>', this.totalNum);
        } else {
            this.widget.getDescendant('deleting_Number_Text').text = '';
        }

    },
    isWidgetInstalledInUSB: function (appID) {
        if(this.isMulti)
        {
            for(var i = 0; i < appID.length;i++)
            {
                var bRet = voltapi.WAS.getAppInfo(appID[i]);
                if (bRet != undefined && bRet != -1 && bRet != false && bRet.app_installed_path && bRet.app_installed_path.indexOf("/opt/storage/usb/") != -1) {
                    return true;
                }
            }
        }
        else{
        var bRet = voltapi.WAS.getAppInfo(appID);
        if (bRet != undefined && bRet != -1 && bRet != false && bRet.app_installed_path && bRet.app_installed_path.indexOf("/opt/storage/usb/") != -1) {
            return true;
            }
        }
        return false;
    },
    finishDelete: function (eventInfo) {
        if (this != null && this != undefined) {
            if (this.isMulti == false) {
                Volt.log("[delete-popup.js] finish single delete");
                if (eventInfo != null && eventInfo != undefined && eventInfo.app_id == this.appID) {
                    Volt.log("trigger CommonDefine.Event.EVENT_DELETE_SUCCESS, finish delete.isMulti == false");
                    this.allUninstallFinishedCB();
                }
            } else {
                Volt.log("[delete-popup.js] receive multi delete event");
                if (eventInfo != null && eventInfo != undefined) {
                    Volt.log("[delete-popup.js] eventInfo.app_id = ", eventInfo.app_id);
                    Volt.log("[delete-popup.js] before appID = " + this.appID);
                    for (var i = 0; i < this.appID.length; ++i) {
                        if (this.appID[i] == eventInfo.app_id) {
                            Volt.log('this.currentNum:' + this.currentNum + 'this.totalNum' + this.totalNum);
                            if (this.currentNum >= this.totalNum) {
                                //this.currentNum = this.totalNum;
                                this.allUninstallFinishedCB();
                                //EventMediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
                                return;
                            }
                            this.currentNum++;
                            this.appID.splice(i, 1);
                            Volt.log("[delete-popup.js] after appID = " + this.appID);
                            this.updateDescription();
                            break;
                        }
                    }
                }
            }
        }
    },
    allUninstallFinishedCB: function () {
        Volt.log("allUninstallFinishedCB");
        if (this.successFlag == false) {
            this.clearTimeOut();
            EventMediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
            CommonWidgetPopup.showMessage(CommonDefine.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL);
            return;
        }
        descriptionText.widget.getChild('deleting_Text').text = Volt.i18n.t('COM_TV_SID_DELETED_SUCCESSFULLY');
        if(this.progressBar){
            Volt.log("set this.progressBar.value to 100%"+this.widget.getChild('progressbar-container').width );
            this.progressBar.value = Math.floor(this.widget.getChild('progressbar-container').width);
            this.percentText.text =  '100%';
        }
        if (!this.isMulti) {
            this.cancelButton.show();
            this.cancelButton.addListener(this.btnListener);
            this.cancelButton.setFocus();

        }
        this.setTimeOut();
        this.cancelButton.setText({
            state: "all",
            text: Volt.i18n.t('COM_SID_OK')
        });
        
        this.widget.onKeyEvent = _.bind(this._onkeyEvent, this);
    },
    setTimeOut: function () {
        this.clearTimeOut();
        this.timer = Volt.setTimeout(function () {
            Volt.log('[delete-popup.js] time out');
            EventMediator.trigger(CommonDefine.Event.CLOSE_DELETING_POPUP);
        }, 1000 * 10);

    },

    clearTimeOut: function () {
        if (this.timer != null && this.timer != undefined) {
            Volt.clearTimeout(this.timer);
        }
    },
});

//template of description
var descriptionView = Backbone.View.extend({
    template: DeletePopupTemplate.description,

    render: function () {
        this.setWidget(Volt.loadTemplate(this.template));
        descriptionText = this;
        return this;
    }
});


exports = new DeletePopup;