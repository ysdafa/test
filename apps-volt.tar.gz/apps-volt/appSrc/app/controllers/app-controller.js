var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js'),
    Backbone = Volt.require('lib/volt-backbone.js'),
    EventMediator = Volt.require('app/common/eventMediator.js'),
    CommonDefines = Volt.require('app/common/commonDefines.js'),
    CommonFunctions = Volt.require('app/common/commonFunctions.js'),
    RouterController = Volt.require('app/controllers/router-controller.js');

var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");

var AppController = {
    STATE_DEACTIVATE: 1,
    //STATE_ACTIVATE: 2,

    STATE_RUN: 0,
    STATE_EXIT: 0x8,

    state: 0,

    ////////////////////////////////////
    setState: function (state) {
        this.state = state;
    },
    clearState: function (state) {
        this.state &= (!state);
    },

    isState: function (state) {
        return this.state & state;
    },

    activate: function () {
            try { // for prevent json error when volt engine did not relased
                VDUtil.exitRegisterKey();
            } catch (e) {
                // error log
            }

        if (this.isState(this.STATE_EXIT)) {
            this.clearState(this.STATE_EXIT);
            Volt.Nav.setLastFocusedWidget(Volt.Nav.getCurrentFocus());
        }
    },

    deactivate: function () {
        try { // for prevent json error when volt engine did not relased
            VDUtil.exitUnregisterKey();
        } catch (e) {
            // error log
        }

    },

    exit: function () {
        Volt.log('[app-controller.js @exit]');

        if((1280 == scene.width) || (1920 == scene.width && Volt.DeviceInfoModel.get('mls') == 1)) {
            Volt.setTimeout(function () {
                Volt.exitKey();
            },1)
            return;
        }
        
        CommonFunctions.forceDisableVoiceGuide(true);
        this.setState(this.STATE_EXIT);
        scene.hide();

        Volt.setTimeout(function () {
            EventMediator.trigger('EVENT_CATEGORY_CHANGE_INDEX', 1);
            
            // Update focus
            EventMediator.trigger('VOLT_EXIT');
            
            RouterController.clear();
            Backbone.history.clear();
            Backbone.history.hashstack.length = 0;

        }, 1); 
         try { // for prevent json error when volt engine did not relased
                Volt.log('[app-controller.js @VDUtil.launchLastSource111]');
                VDUtil.launchLastSource();
            } catch (e) {
               Volt.exit();
            }
    },

    reset: function (data) {
        var route;

        CommonFunctions.forceDisableVoiceGuide(false);
        if (this.isState(this.STATE_EXIT)) {
            scene.show();
            route = 'whatsnew';
        }

        Stage.show(); // show apps panel, request from Volt UIFW

        //        if (startView != 'whatsnew') {
        //            startView = 'whatsnew';
        //        }
        if (data) {
            if (data.Sub_Menu == 'detail' && data.widget_id) {
                route = data.Sub_Menu + '/' + data.widget_id;

                if (data.caller_id) {
                    Volt.err("[app.js] onReset, caller_id: " + data.caller_id);
                    route += '/' + data.caller_id;
                } else {
                    Volt.err("[app.js] onReset, caller_id is not exist.");
                }
            }
        }
        if (route) {
            Volt.err('route: ' + route);
            Backbone.history.navigate(route, {
                trigger: true
            });
            Volt.Nav.resume(); //fix bug of DF141206-00669:Key is blocked after installed facebook
        } else {
            EventMediator.trigger('VOLT_RESUME');
        }

        // DF141114-00502, DF141115-00373, DF141119-00405: Added code by VOLT Team's guide. 
        voltapi.vconf.setValue(CommonDefines.Vconf.DB_WAITING_SCREEN_APP_VISIBLE, true);
        CommonFunctions.disableMenu();
    },
    
    ifSupportExitKey: function () {
        return typeof VDUtil.exitUnregisterKey == 'function';
    },
};

exports = AppController;