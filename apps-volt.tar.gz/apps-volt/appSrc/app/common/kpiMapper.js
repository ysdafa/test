var KPI = Volt.require('lib/volt-kpi.js');
//var Models = Volt.require('app/models/models.js');

var KpiMapper = new(function () {

    var CATEGORY_MAPPER = {
        'M01_MYAPPS': 'PG001',
        'N01_NEW': 'PG002',
        'M01_MOST': 'PG003',

        'C02_SPORT': 'PG004',
        'C02_LIFE': 'PG005',
        'C02_INFO': 'PG006',
        'C02_EDU': 'PG007',
        'C02_KIDS': 'PG008',
        'C02_VIDEO': 'PG009',
        'C02_GAME': 'PG010',

        'D03_DETAIL': 'PG011',

        'SELECTMENU': 'EV001',
        'SELECTMA': 'EV002',
        'LONGPRESSMA': 'EV003',
        'SELECTLONGPRESSMA': 'EV004',
        'SELECTOPTION': 'EV005',
        'SELECTDELETE': 'EV006',
        'SELECTLOCKUNLOCK': 'EV007',
        'SELECTUPDATE': 'EV008',
        'SELECTSORT': 'EV009',
        'CHANGESORT': 'EV010',
        'UPDATEAPPS': 'EV011',

        'SELECTMP': 'EV012',
        'LONGPRESSMP': 'EV013',
        'SELECTLONGPRESSMP': 'EV014',
        'SELECTWN': 'EV015',
        'LONGPRESSWN': 'EV016',
        'SELECTLONGPRESSWN': 'EV017',

        'SELECTSC': 'EV018',
        'LONGPRESSSC': 'EV019',
        'SELECTLONGPRESSSC': 'EV020',
        'SELECTSEARCH': 'EV021',

        'DOWNLOAD': 'EV022',
        'CANCEL': 'EV023',
        'OPEN': 'EV024',
        'RATINGAPP': 'EV025',
        'RELATEDAPP': 'EV026',
        'SCREENSHOT': 'EV027',
        'COUNTSCREENSHOT': 'EV028'
    };

    var currentPage = null,
        prevPage = null;


    this.init = function () {
        KPI.init({
            serviceName: '15_apps',
            modelId: Volt.DeviceInfoModel.get('modelId'),
            uid: '',
            duid: Volt.DeviceInfoModel.get('duid'),
            countryCode: Volt.DeviceInfoModel.get('countryCode'),
            version: Volt.DeviceInfoModel.get('firmwareVersion'),
            configFallbackPath: 'app/common/LogPolicyConfig.xml',
            debug: true
        });
    }

    this.addEventLog = function (eventName, pOptions) {

        Volt.log('[kpi-mapper.js]addEventLog - ' + eventName);

        var options = pOptions ? pOptions : {};

        options['c'] = CATEGORY_MAPPER[eventName];

        if (eventName == 'SELECTSEARCH' || eventName == 'SELECTOPTION') {
            if (!currentPage) {
                options['d']['cp'] = 'W01_NEW';
            } else {
                options['d']['cp'] = currentPage.eventName;
            }
        }

        if (eventName == 'DOWNLOAD') {
            //            if (!currentPage) {
            //                options['d']['pp'] = '';
            //            } else {
            //                options['d']['pp'] = currentPage.eventName;
            //            }
            if (!prevPage) {
                options['d']['pp'] = '';
            } else {
                options['d']['pp'] = prevPage.eventName;
            }
        }

        KPI.add(eventName, options);
    }

    //startPage, endPage
    this.enterPage = function (eventName, pOptions) {

        Volt.log('[kpi-mapper.js]enterPage - ' + eventName);

        var options = pOptions ? pOptions : {};
        var cartegory = CATEGORY_MAPPER[eventName];

        switch (eventName) {
        case 'C02_GAMES':
            eventName = 'C02_GAME';
            break;
        case 'C02_LIFESTYLE':
            eventName = 'C02_LIFE';
            break;
        case 'C02_VIDEOS':
            eventName = 'C02_VIDEO';
            break;
        case 'C02_SPORTS':
            eventName = 'C02_SPORT';
            break;
        case 'C02_EDUCATION':
            eventName = 'C02_EDU';
            break;
        }

        var pageName = eventName;
        options['c'] = cartegory;

        if (currentPage != null) {
            if (currentPage.eventName != eventName) {
                this.leavePage(currentPage.eventName, currentPage.options);
            } else if (options.hasOwnProperty('appid')) {
                if (options['appid'] != currentPage.options['appid']) {
                    this.leavePage(currentPage.eventName, currentPage.options);
                }
            } else {
                Volt.err('[kpi-mapper.js] This page is already entered!' + currentPage.eventName);
                return;
            }
        }

        if (currentPage != null) {
            options['d'] = {};
            options['d']['pp'] = currentPage.eventName;
            Volt.err('[kpi-mapper.js] Last Page : ' + options.d.pp);
        }

        if (eventName == 'M01_MYAPPS') {
            if (currentPage == null) options['d'] = {};

            var Models = Volt.require('app/models/models.js');
            options['d']['cmaa'] = Models.myAppsCollection.length;
            options['d']['cua'] = Models.externalStorageModel.get('usbList').length;
            Volt.err(options);
        }

        KPI.startPage(pageName, options);
        currentPage = {
            eventName: eventName,
            options: options
        };
    }

    this.leavePage = function (eventName, pOptions) {
        var pageName,
            cartegory,
            options;

        if (eventName) { //target Page
            pageName = eventName;
            options = pOptions ? pOptions : {};
            options['c'] = CATEGORY_MAPPER[eventName];
        } else { //Last Page
            if (currentPage) {
                pageName = currentPage.eventName;
                options = pOptions ? pOptions : {};
                options['c'] = CATEGORY_MAPPER[eventName];
            }
        }

        if (pageName) {
            delete options['appid'];
            KPI.endPage(pageName, options);

            prevPage = currentPage;
            currentPage = null;
        } else {
            Volt.err('[kpi-mapper.js] There is no page event to be leave');
        }
    }

    this.endKPI = function () {
        KPI.endPage();
    }

    this.changeUID = function () {
        KPI.changeUID(KPI.getUID());
    }

    this.getCurrentPage = function(){
        return currentPage;
    }

    this.getPrevPage = function(){
        return prevPage;
    }

})();

exports = KpiMapper;