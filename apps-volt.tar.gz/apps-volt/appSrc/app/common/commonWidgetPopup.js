var CommonDefines = Volt.require('app/common/commonDefines.js');
var EventMediator = Volt.require('app/common/eventMediator.js');
var message_Box = Volt.require('lib/views/message-box-popup.js');
var winsetDimView = Volt.require("lib/views/dim-view.js");
var winsetMessageBox = Volt.require("modules/WinsetUIElement/winsetMessageBox.js");
var WinsetBase = Volt.require("modules/WinsetUIElement/winsetBase.js");

var Q = Volt.require('modules/q.js');
var _ = Volt.require('modules/underscore.js')._;
var voltapi = Volt.require('$VOLT_ROOT/modules/voltapi.js');
var ratingPopup = null;
var PinPopup = null;
var configXML = null;
var self = this;
var updateListParam = null;
var CommonFunctions = Volt.require('app/common/commonFunctions.js');
var commonWidgetPopup = {
    //initialize: function () {},
    showMessage: function (messageId, params) {
        EventMediator.trigger('EVENT_OVERLAY_SHOW_DIM');
        EventMediator.trigger(CommonDefines.Event.EVENT_SHOW_COMMON_POPUP,messageId);
        this.showMessagePopupView(messageId, params);
    },

    showMessagePopupView: function (messageId, params) {
        Volt.log('[commonWidgetPopup.js] showMessagePopupView');
        switch (messageId) {
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_MEMORY_FULL_CONNECT_USB_INSTALL:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_MEMORY_FULL_CONNECT_USB_INSTALL,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('COM_SID_MEMORY_FULL_CONNECT_USB_INSTALL'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL:
            print("CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL");
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_TO_UNINSTALL,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: 'Failed to delete.',
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param); /**** switch to halo component****/
            break;

        case CommonDefines.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_APPSYNC_NOT_COMPLETE,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_SMART_HUB_UPDATED_TRY_AGAIN_LATER'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param); /**** switch to halo component****/

            break;

        case CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_DLD_BEFORE_RATE,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('COM_SID_MUST_DOWNLOAD_APP_RATING'),
                buttonText: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:10*1000,
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_LATEST_VERSIONS_OF_ALL_APPS,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('COM_TV_SID_YOU_HAVE_LATEST_VERSIONS_OF_ALL_APPS_MSG'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
         case CommonDefines.MsgBoxType.MSGBOX_TYPE_NO_APP_DELETE:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_NO_APP_DELETE,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_FEATURE_NOT_AVAIL_APPS_DELETED_CAN_NOT'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_RATEING:
            Volt.log('[common-content.js]showRatingPopup, params = ' + params);
            EventMediator.on(CommonDefines.Event.CLOSE_RATING_POPUP, this.destroyRatingPopup);
            ratingPopup = Volt.require('lib/views/rating-popup.js');
            ratingPopup.show(params);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_DELETE:
            Volt.log('[common-content.js]showDeletingPopup, params = ' + params);
            EventMediator.on(CommonDefines.Event.CLOSE_DELETING_POPUP, this.destroyDeletingPopup);
            deletingPopup = Volt.require('app/views/delete-popup.js');
            print('myAppsVMcollection.js deleteApps' + params);
            deletingPopup.show(params);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_PIN:
            //EventMediator.on(CommonDefines.Event.CLOSE_RATING_POPUP, this.destroyRatingPopup);
            PinPopup = Volt.require('lib/views/pin-popup.js');
            PinPopup.show(params);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_OPTIONMENU:

            EventMediator.on('UPDATE_APPS_COLLECTION_FETCHED', this.getFetched);
            //this.listenToOnce(EventMediator, 'UPDATE_APPS_COLLECTION_FETCHED', this.getFetched);
            updateListParam = params;
            Models = Volt.require("app/models/models.js");
            Models.updateAppsCollection.fetch();
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_CONTEXTMENU:
            ContextMenuPopup = Volt.require('app/views/contextMenuPopup.js');
            ContextMenuPopup.show(params);
            if (params.baseWidget) {
                Volt.log('[dim-view.js] show x:::' + params.baseWidget.getAbsolutePosition().x + "y::::" + params.baseWidget.getAbsolutePosition().y + "width:::" + params.baseWidget.width + "height::::" + params.baseWidget.height);
                if (winsetDimView.dimView) {
                    winsetDimView.dimView.addTransparentArea({
                        x: params.baseWidget.getAbsolutePosition().x,
                        y: params.baseWidget.getAbsolutePosition().y,
                        width: params.baseWidget.width,
                        height: params.baseWidget.height
                    });
                }
            }
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_SERVER_ERROR_GUIDE,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: params.message,
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param);

            break;
        case CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS:
            var param = {
                type: CommonDefines.MsgBoxType.TYPE_DELETE_MY_APPS,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_1Line,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_DELETE_SELECTED_ITEMS_QUES'),
                button1Text: Volt.i18n.t('COM_SID_YES'),
                button2Text: Volt.i18n.t('COM_SID_NO'),
                contextLineNumber: 1,
                prePage: '',
                defaultfocus: "button_2",
                timeout:10*1000,
            };
            param.appID = params;
            print("param.appID = params:" + param.appID);
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_SETHEADER_ERROR,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_MIX_UNABLE_CONNECT_SAMSUNG_SERVER_UPDATE_TV_SW').replace('<<A>>', '(' + params.code + ')'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_DEVELOP,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: params.message,
                button1Text: Volt.i18n.t('COM_SID_CLOSE'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_NOT_SUPPORT_MLS:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_NOT_SUPPORT_MLS,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('COM_SID_FUNCTION_AVAILABLE_MULTI_LINK_SCREEN'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_USB_NOT_CONNECT:
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_USB_NOT_CONNECT,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_SOTRAGE_DEVICE_DISCONNECTED'),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:5*1000,
            };
            message_Box.show(param);
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_SMARTHUB_INFO:
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_SMARTHUB_INFO_VIEW:
            Volt.log('commonWidgetPopup.js: getDebugInfo is ' + JSON.stringify(voltapi.WAS.getDebugInfo()));
            var debugInfo = voltapi.WAS.getDebugInfo();
            var voltVersion = "";
            if(Volt.getVersion()){
                voltVersion = Volt.getVersion().string;
            }
            Volt.log('commonWidgetPopup.js: voltVersion is ' + JSON.stringify(voltVersion));
            var voltApiVersion = voltapi.volt_api_version;
            var voltApiVersionDate = voltapi.volt_api_version_date;
            var smartHubInfo = '"apps_db_status":' + debugInfo.apps_db_status + ', "category_type":' + debugInfo.category_type + ', "chip_info":' + debugInfo.chip_info + '\n' + '"country":' + debugInfo.country + ', "lineup_model":' + debugInfo.lineup_model + ', "local_set":' + debugInfo.local_set + '\n' + '"model_id":' + debugInfo.model_id + ', "networks_status:' + debugInfo.networks_status + ', "product_type":' + debugInfo.product_type + '\n' + '"sef_version":' + debugInfo.sef_version + ', "server_type":' + debugInfo.server_type + ', "sync_status":' + debugInfo.sync_status + '\n' + '"wp_baseline":' + debugInfo.wp_baseline + ', "mac_addr":' + debugInfo.mac_addr + '\n' + '"hubsite_status":' + debugInfo.hubsite_status + ', "duid":' + debugInfo.duid + '\n' + '"firmware_version":' + debugInfo.firmware_version + ', "manager_status":' + debugInfo.manager_status + '\n' + '"local_time":' + debugInfo.local_time +  '\n' + '"volt_version":' + voltVersion + ', "volt_api_version":' + voltApiVersion + ', "volt_api_date":' + voltApiVersionDate;      
            Volt.log('commonWidgetPopup.js: smartHub information is ' + smartHubInfo);
            var param = {
                type: messageId,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: smartHubInfo,
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                timeout:0,
            };
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.TYPE_NETWORK:
            var param = {
                type: CommonDefines.MsgBoxType.TYPE_NETWORK,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_NoTitle_Button_2_8Line,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_MIX_NOT_CONNECTED_INTERNET_FEATURE').replace('<<A>>', 'AS000'),
                //button_1_Text:'Troubleshoot',
                button1Text: Volt.i18n.t('TV_SID_TROUBLESHOOT'),
                button2Text: Volt.i18n.t('COM_SID_CANCEL'),
                contextLineNumber: 1,
                prePage: '',
                timeout:10*1000,
            };
            // print("Volt.i18n.t('COM_TV_SID_NETWORK_STATUS')"+Volt.i18n.t('COM_TV_SID_NETWORK_STATUS'));
            message_Box.show(param); /**** switch to halo component****/
            break;
        case CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD:
			Volt.log('[commonWidgetPopup.js]CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD  params.eventType:'+params.eventType+"params.failCode"+params.failCode);
            if (CommonDefines.AppState.APP_STATE_DEACTIVATE == CommonFunctions.getAppState()) {
                Volt.log('[commonWidgetPopup.js] now app status is APP_STATE_DEACTIVATE, do not show this messagepopup');
                return false;
            }
            var param = {
                type: CommonDefines.MsgBoxType.MSGBOX_TYPE_FAIL_DOWNLOAD,
                style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                nResolutionStyle: (Volt.APPS720P) ? WinsetBase.ResolutionStyle.Resolution_720 : WinsetBase.ResolutionStyle.Resolution_1080,
                bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                button: true,
                contentText: Volt.i18n.t('TV_SID_MIX_FAILED_TO_DOWNLOAD').replace('<<A>>', 'Code: ' + params.eventType),
                button1Text: Volt.i18n.t('COM_SID_OK'),
                contextLineNumber: 1,
                prePage: '',
                defaultfocus: "button_1",
                timeout:5*1000,
            };
            switch (params.eventType) {
            case CommonDefines.WAS.DOWNLOAD_FAIL_NOSPACE:
			case CommonDefines.WAS.DOWNLOAD_FAIL_EMP_NOT_ENOUGH_MEMORY:
			case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_SPACE_NOT_ENOUGH:
				 if (!params.usbInstall)
				 {
					param.contentText = Volt.i18n.t('TV_SID_INSATTAL_APP_NEED_MAKE_MORE_MEMORY');
				 }
				 else
                 {param.contentText = Volt.i18n.t('TV_SID_MIX_INTERNAL_MEMORY_LOW_USB_ATTACHED').replace('<<A>>', "app");}
                break;
            case CommonDefines.WAS.DOWNLOAD_FAIL_SERVER_ERROR:
			case CommonDefines.WAS.WAS_EVENT_INSTALL_INSTALL_FAIL_APP_COUNTRY_NOT_SUPPORT:
				param.contentText = Volt.i18n.t('TV_SID_MIX_APP_NOT_SUPPORTED_BY_TV').replace('<<B>>', 'Code: ' + params.eventType);
				break;
            case CommonDefines.WAS.DOWNLOAD_FAIL_NETWORK_ERROR:
			case CommonDefines.WAS.DOWNLOAD_FAIL_DOWNLOAD_APP:
				param.contentText = Volt.i18n.t('TV_SID_MIX_NOT_CONNECTED_INTERNET_FEATURE').replace('<<A>>', 'Code: ' + params.eventType);
				break;
            case CommonDefines.WAS.WAS_EVENT_INSTALL_USB_PATH_NOT_EXIST:
			case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_EXTRACT_FILES:
				param.contentText = Volt.i18n.t('TV_SID_MIX_CHECK_STORAGE_DEVICE_CONNECTION_AGAIN').replace('<<A>>', 'Code: ' + params.eventType);
				break;
            case CommonDefines.WAS.WAS_EVENT_INSTALL_USB_INSTALL_NOT_SUPPORT:
				param.contentText = Volt.i18n.t('TV_SID_INSATTAL_APP_NEED_MAKE_MORE_MEMORY');
				break;
			case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_USB_SPACE_NOT_ENOUGH:
				param.contentText = Volt.i18n.t('TV_SID_MIX_INTERNAL_MEMORY_LOW_USB_ATTACHED').replace('<<A>>', "app");
				break;
            case CommonDefines.WAS.WAS_EVENT_INSTALL_FAIL_APP_IS_INSTALLING:
				param.contentText = Volt.i18n.t('TV_SID_MIX_INSTALLED_TRY_AGAIN').replace('<<B>>', 'Code: ' + params.eventType).replace('<<A>>', "app");
				break;
			case CommonDefines.Event.INSTALL_FAIL_OTHERS:
				if (params.failCode)
				{
					param.contentText = Volt.i18n.t('TV_SID_MIX_FAILED_TO_DOWNLOAD').replace('<<A>>', 'Code: ' + params.failCode);
				}
				break;
			default:
				break;
            }
            message_Box.show(param);
            break;
        case CommonDefines.Magic.SHOW_VERSION:
            getConfigXML().then(function (configXML) {
                var param = {
                    type: CommonDefines.Magic.SHOW_VERSION,
                    style: winsetMessageBox.MessageBoxStyle.MessageBox_Extension_One_Button,
                    buttonStyle: winsetMessageBox.ButtonStyle.Button_image_O_Style_F,
                    bgStyle: winsetMessageBox.BackgroundStyle.Background_Style_B_2,
                    contentText: configXML.widget.ver,
                    button: true,
                    button_1_Text: Volt.i18n.t('COM_SID_OK'),
                    contextLineNumber: 1,
                    focusIndex: 1,
                    timeout:0,
                };
                message_Box.show(param);
            });
            break;
        default:
            Volt.log('message-id:::' + messageId);
            EventMediator.trigger('EVENT_OVERLAY_HIDE_DIM');
            break;
        }
    },
    getFetched: function () {
        EventMediator.off('UPDATE_APPS_COLLECTION_FETCHED');
        var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
        optionMenuPopup = Volt.require('lib/views/option-menu-popup.js');
        optionMenuPopup.show(updateListParam);
        if (Models.updateAppsCollection.length == 0) {
            optionMenuPopup.dimListItem(CommonDefines.OptionMenu.UPDATE_APPS);
        }
        else{
            Volt.log("is updating???"+Models.updateAppsCollection.length);
            var countMyApps = voltapi.WAS.getAppCount(CommonDefines.WAS.APPS_TYPE_ALL, CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE, CommonDefines.WAS.APPS_INFO_FEATURED_ALL);
            var appsData = voltapi.WAS.getAppList(CommonDefines.WAS.APPS_TYPE_ALL, CommonDefines.WAS.APPS_INFO_PREMIUM_GAME_FALSE, CommonDefines.WAS.APPS_INFO_FEATURED_ALL, CommonDefines.WAS.VIEWMODE_LASTDOWNLOAD, 0, countMyApps);
            var count = Models.updateAppsCollection.length;
            for(var i = 0;i < Models.updateAppsCollection.length;i++ ){
                    Volt.log("is updating???"+Models.updateAppsCollection.at(i).get('app_id'));
                    var downloadingApps = _.findWhere(AppInstallMgr.installList, {app_id: Models.updateAppsCollection.at(i).get('app_id')});

                    Volt.log("is updating???"+downloadingApps);

                    if (downloadingApps != null)
                    {
                        count--;
                        break;
                    }
                 for (var j = 0;j < appsData.length;j++ ) {
                      Volt.log("[UpdateAppsCollection.js] appsData.app_id is " + appsData[j].app_id);
                     if(Models.updateAppsCollection.at(i).get('app_id') == appsData[j].app_id){
                            break;
                     }
                     count--;
                 }
                
            }
            if (count == 0){
                optionMenuPopup.dimListItem(CommonDefines.OptionMenu.UPDATE_APPS);
            }
        }
         //process delete apps,if there is no apps to delete,dim item
        Volt.log("Models.myAppsCollection.length is "+Models.myAppsCollection.length);
        if (Models.myAppsCollection.length == 0) {
            optionMenuPopup.dimListItem(0);
        }else{
            var deleteAbleAppsCount = 0;
            for(var i = 0;i < Models.myAppsCollection.length;i++ ){
                Volt.log("is_removable is "+ Models.myAppsCollection.at(i).get('is_removable') + " app_featured is " + Models.myAppsCollection.at(i).get('app_featured')+" app_title is " + Models.myAppsCollection.at(i).get('app_title'));
                if((true == Models.myAppsCollection.at(i).get('is_removable'))&&(1 == Models.myAppsCollection.at(i).get('app_featured'))&& Models.myAppsCollection.at(i).get('app_title')!="e-Manual"&&  Models.myAppsCollection.at(i).get('app_title')!="Browser"){
                    deleteAbleAppsCount++;
                }
            }
            if(0 == deleteAbleAppsCount){
                optionMenuPopup.dimListItem(0);
            }
        }
    },

    destroyRatingPopup: function () {
        Volt.log('[commonWidgetPopup.js]destroyRatingPopup');
        EventMediator.off(CommonDefines.Event.CLOSE_RATING_POPUP, this.destroyRatingPopup);
        if (ratingPopup != null) {
            ratingPopup.hide();
            ratingPopup = null;
        }
        EventMediator.trigger('EVENT_OVERLAY_HIDE_DIM');
    },
    destroyDeletingPopup: function () {
        Volt.log('[commonWidgetPopup.js]destroyDeletingPopup');
        EventMediator.off(CommonDefines.Event.CLOSE_DELETING_POPUP);
        if (deletingPopup != null) {
            deletingPopup.hide();
            deletingPopup = null;
        }
        EventMediator.trigger('EVENT_OVERLAY_HIDE_DIM');
    },
    destroyWidgetPopup: function () { //destroy all widget type popups
        EventMediator.trigger(CommonDefines.Event.EVENT_CLOSE_POPUP);
    },
};
var getConfigXML = function () {
    Volt.log('[commonWidgetPopup.js] getConfigXML configXML = ' + configXML);
    var deferred = Q.defer();
    if (configXML == null) {
        Volt.log('[commonWidgetPopup.js] getConfigXML configXML11111111111111');
        var configPath = Volt.getRemoteUrl('config.xml');
        _XMLToJSON(configPath).then(function (obj) {
            configXML = obj;
            deferred.resolve(obj);
        });
        Volt.log('[commonWidgetPopup.js] getConfigXML configXML222222');
    } else {
        deferred.resolve(configXML);
    }
    return deferred.promise;
};

var _XMLToJSON = function (xmlFileUrl) {
    Volt.log('[commonWidgetPopup.js] _XMLToJSON ..... url = ' + xmlFileUrl);
    var deferred = Q.defer();
    var resourceRequest = new ResourceRequest(xmlFileUrl);
    resourceRequest.method = 'GET';
    resourceRequest.async = true;
    resourceRequest.success = function (data, textStatus, xhr) {
        _parseConfig(data)
            .then(function (obj) {
                deferred.resolve(obj);
            })
            .fail(function (err) {
                deferred.reject(err);
            });
    };
    resourceRequest.error = function (xhr, textStatus, errorStr) {
        deferred.reject(errorStr);
    };
    resourceRequest.process();
    return deferred.promise;
};

var _parseConfig = function (data) {
    Volt.log('[commonWidgetPopup.js] _parseConfig ..... data = ' + data);
    var xmlString = data.replace("\ufeff", "");
    var deferred = Q.defer();
    var xml = Volt.require('modules/SaxParser.js');
    var obj = {};
    var currentTag = null;
    var parser = new xml.SaxParser(function (cb) {
        cb.onEndDocument(function () {
            Volt.log("[commonWidgetPopup.js] onEndDocument obj = " + JSON.stringify(obj));
            deferred.resolve(obj);
        });
        cb.onStartElementNS(function (elem) {
            if (elem == "_name" || elem == "_parent" || elem == "_value") {
                Volt.log("[commonWidgetPopup.js] XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
                return;
            }
            var tag = {
                _name: elem,
                _parent: currentTag
            };
            currentTag = tag;
        });
        cb.onCharacters(function (value) {
            if (currentTag && value.indexOf('\n') !== 0) {
                currentTag._value = value;
            } else {
                Volt.log("[commonWidgetPopup.js] onCharacters Invalid Value:" + JSON.stringify(arguments));
            }
        });
        cb.onEndElementNS(function (elem) {
            if (elem == "_name" || elem == "_parent" || elem == "_value") {
                Volt.log("[commonWidgetPopup.js] XXXXXXXXXXXXXXX onStartElementNS used keyword = " + elem);
                return;
            }
            if (currentTag && currentTag._parent) {
                if (currentTag._value) {
                    currentTag._parent[currentTag._name] = currentTag._value;
                } else {
                    currentTag._parent[currentTag._name] = currentTag;
                    delete currentTag._name;
                }
                var p = currentTag._parent;
                delete currentTag._parent;
                currentTag = p;
            } else {
                obj[currentTag._name] = currentTag;
                delete currentTag._name;
                delete currentTag._parent;
            }
        });
        cb.onError(function (msg) {
            deferred.reject(msg);
        });
    });
    parser.parseString(xmlString);
    return deferred.promise;
}

exports = commonWidgetPopup;