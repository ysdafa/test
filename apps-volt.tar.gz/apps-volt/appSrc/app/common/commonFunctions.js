/** 
 * @author lihao Zha (lihao.zha@samsung.com)
 * @fileoverview This module defines common functions.
 * @date    2014/11/15 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var DeviceInfoModel = Volt.require('app/models/deviceInfoModel.js');
var CommonDefines = Volt.require('app/common/commonDefines.js');

var bForceDisableVoiceGuide = false;
var appState = CommonDefines.AppState.APP_STATE_ACTIVATE;

var gRatingBgBuf = new ImageBuffer(Volt.getRemoteUrl('images/1080/common/apps_contents_star_bg.png'));
var gRatingOnBuf = new ImageBuffer(Volt.getRemoteUrl('images/1080/common/apps_contents_star_wh.png'));
var gRatingHalfBuf = new ImageBuffer(Volt.getRemoteUrl('images/1080/common/apps_contents_star_wh_half.png'));
var gRatingOnBkBuf  = new ImageBuffer(Volt.getRemoteUrl('images/1080/common/apps_contents_star_bk.png'));
var gRatingHalfBKBuf = new ImageBuffer(Volt.getRemoteUrl('images/1080/common/apps_contents_star_bk_half.png'));

var voiceGuide = function (voiceText, bQueuingPlay) {
    Volt.log('[commonFunctions.js] [appsvoice] voice guide text : ' + voiceText);
    if (bForceDisableVoiceGuide) {
        Volt.log('[commonFunctions.js] [appsvoice] forceDisableVoiceGuide, do not need to play unnecessary tts');
        return;
    }
    if (1 != DeviceInfoModel.get('tts')) {
        Volt.log('[commonFunctions.js] [appsvoice] voice guide function is off, do not need to play tts');
        return;
    }
    if (bQueuingPlay) {
        Volt.log('[commonFunctions.js] [appsvoice] queuingPlay');
        TTS.queuingPlay(voiceText);
    } else {
        TTS.setText("");
        TTS.play();
        Volt.setTimeout(function(){
            TTS.setText(voiceText);
            TTS.play();
        },1);
        
    }
}

var forceDisableVoiceGuide = function (bForceDisable) {
    bForceDisableVoiceGuide = bForceDisable;
}

var getAppState = function () {
    return appState;
}

var setAppState = function (state) {
    appState = state;
}

var disableMenu = function () {
    Volt.log("[commonFunctions.js] disableMenu");
    VDUtil.AppControl_InitDbusConnection();
    VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.apps");
    VDUtil.AppControl_DisableItem("picturesize", "org.volt.apps");//DF141225-00447 disable picture size 
    VDUtil.AppControl_DisableItem("3d", "org.volt.apps");//DF150125-00081 disable 3D  
    VDUtil.AppControl_DisableItem("pip", "org.volt.apps");//DF141225-00850 disable PIP sound  
    VDUtil.AppControl_DisableItem("resetpicture", "org.volt.apps");
    VDUtil.AppControl_DisableItem("setup", "org.volt.apps");
    VDUtil.AppControl_DisableItem("osd-language", "org.volt.apps");
    VDUtil.AppControl_DisableItem("softwareupdate", "org.volt.apps");
    VDUtil.AppControl_DisableItem("self-diagnosis", "org.volt.apps");
    VDUtil.AppControl_FiniDbusConnection();
}

var enableMenu = function () {
    Volt.log("[commonFunctions.js] enableMenu");
    VDUtil.AppControl_InitDbusConnection();
    VDUtil.AppControl_RemoveDisabledItemsByAppname("org.volt.apps");
    VDUtil.AppControl_FiniDbusConnection();
}

////////////////////////////////////////////////////////////////////////////////
//// Common Functions about storage calculation
/**
 * Return to convert app size
 * @method
 * @memberof DetailView
 */
function getFormattedSize(value, Kunit) {
    var retValue = '';
    var retUnit = '';
    var ret = '';

    if (value >= 1048576) {
        retValue = parseFloat(value / 1048576).toFixed(2);
        retUnit = Kunit ? Volt.i18n.t('SID_GB'):Volt.i18n.t('SID_MB');
    } else if (value >= 1024) {
        if ( Kunit ){
            retValue = parseFloat(value / 1024).toFixed(2);;
            retUnit =  Volt.i18n.t('SID_MB');
        }else{
            retValue = parseInt(value / 1024);
            retUnit = Volt.i18n.t('SID_KB');
        }
    } else {
        retValue = parseInt(value);
        retUnit = Kunit? Volt.i18n.t('SID_KB'):Volt.i18n.t('SID_BYTE');
    }
        
/*    if(Volt.APPS_REVERSE && (retUnit == 'Byte' || retUnit == 'KB' || retUnit == 'MB' || retUnit == 'GB')){
        ret = retUnit + retValue;
    }
    else{
        ret = retValue + retUnit;
    }*/
    ret = retValue + retUnit;
    return ret;
}

function getSize(strSize, unit) {
    Volt.log('[commonFunction.js @getKBSize] strSize: ' + strSize);
    var nMemory = strSize.replace(/[^0-9.]/g, '');
    var strUnit = strSize.replace(/[^a-zA-Z]/gi, '').toUpperCase();
    var scale = 1;
    
    if (unit == 'MB') {
        scale = 1048576;
    } else if (unit == 'KB') {
        scale = 1024;
    } else if (unit == 'GB') {
        scale = 1073741824;
    }
    
    switch (strUnit) {
    case "MB":
        nMemory = nMemory * 1048576;
        break;
    case "KB":
        nMemory = nMemory * 1024;
        break;
    case "GB":
        nMemory = nMemory * 1073741824;
        break;
    }
    
    return parseFloat(nMemory / scale);
}

function convertDate(date) {
    var genericDate = null;
    var year = date.substr(0,4);
    var month = date.substr(5,2);
    var day = date.substr(8,2);

    if (Vconf.getString(CommonDefines.Vconf.DB_COMSS_COUNTRYCODE) == 'KR'){
        genericDate = year + '/' + month + '/' + day;
    }
    else if (SystemInfo.KEY_DTV_TYPE && SystemInfo.getIntValue(SystemInfo.KEY_DTV_TYPE) == 0){     // ATSC
        genericDate = month + '/' + day + '/' + year;
    }
    else if (SystemInfo.KEY_DTV_TYPE && SystemInfo.getIntValue(SystemInfo.KEY_DTV_TYPE) == 1){     // DVB
        genericDate = day + '/' + month + '/' + year;
    }
    else{
        genericDate = year + '/' + month + '/' + day;
    }

    return genericDate;
}

/**
 * Calculate size of app according to filesize, fileDecompSize, fileExtension and whether installed
 *
 * @function
 * @param {Number}  fileSize        - Size of app
 * @param {Number}  fileDecompSize  - Decompressed size of app
 * @param {String}  fileExtension   - File Extension
 * @param {Boolean} installed       - If the app is installed
 * @return {Number} Return the size to display.
 * @since 0.150326
 *
 * @example
 *
 */
function calcAppSize(fileSize, fileDecompSize, fileExtension, installed) {
    if (fileExtension == 'img' || fileExtension == 'tmg') {
        if (installed) {
            return fileSize;
        } else {
            return fileSize + 10485760;
        }
    } else {
        if (installed) {
            return fileDecompSize;
        } else {
            return fileSize + fileDecompSize + 10485760;
        }
    }
    
}

/**
 * Calculate size of app according to filesize, fileDecompSize, fileExtension and whether installed
 *
 * @function
 * @param {Object}  root    - Widget Root
 * @param {Array}   ids     - Id array to destroyListener
 * @since 0.150326
 *
 * @example
 *
 */
function destroyListener(root, ids) {
    try {
        if (ids.constructor.name == 'Array') {
            var i = ids.length;
            while (i--) {
                root.getDescendant(ids[i]).destroyListener();
            }
        }
    } catch (e) {
        //
    }
}

function getRatingImage() { 
    var ratingImage = {
                  ratingBgBuf:gRatingBgBuf,
                  ratingOnBuf:gRatingOnBuf,
                  ratingHalfBuf:gRatingHalfBuf,
                  ratingOnBkBuf :gRatingOnBkBuf,
                  ratingHalfBKBuf:gRatingHalfBKBuf,
     };
    return ratingImage;
}
////////////////////////////////////////////////////////////////////////////////
exports = {
    voiceGuide: voiceGuide,
    forceDisableVoiceGuide: forceDisableVoiceGuide,
    getAppState: getAppState,
    setAppState: setAppState,
    disableMenu: disableMenu,
    enableMenu: enableMenu,
    convertDate: convertDate,
    
    getFormattedSize: getFormattedSize,
    getSize: getSize,
    calcAppSize: calcAppSize,
    
    destroyListener: destroyListener,
    getRatingImage:getRatingImage
};