var DIMMESION_WIDTH = Volt.dimmensionWidth;
var CategoriesListTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        color: Volt.hexToRgb('#dfdfdf'),
        children: [
            /*{
                id: 'categories-list-header-container',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#0f1826')
            },*/
            {
                id: 'categories-list-content-container-{{ type }}',
                type: 'widget',
                x: 0,
                y: 0,
                width: Volt.width,
                height: Volt.height * 0.8,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'categories-list-no-content-container-{{ type }}',
                type: 'text',
                x: Volt.width * 0.046875,
                y: Volt.height * (0.8-0.044444*2-0.041667-0.060185)/2,   
                width: Volt.width * (1-0.046875*2),
                height: Volt.height * 0.044444*2 + 10,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: '35px'
            },
            {
                id: 'categories-list-button-{{ type }}',
                type: 'widget',
                x: Volt.width * (1 - 0.140104)/2,
                y: Volt.height * (0.8-0.044444*2-0.041667-0.060185)/2 + Volt.height * (0.044444*2+0.041667), 
                width: Volt.width * 0.140104,
                height: Volt.height * 0.060185,
                color: Volt.hexToRgb('#000000', 0),
                custom: {
                    'focusable': false
                }
            }
        ]
    },
    troubelShootBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        x: 0,
        y: 0,
        width: Volt.width * 0.140104,
        height: Volt.height * 0.060185,
    },
    dim: {
        id: 'categories-list-dim',
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#000000'),
        opacity: Volt.getPercentage(80)
    },

    categoriesListItem: {

    },

    progressbar: {
        x: 20,
        y: 160,
        width: 156,
        height: 2,
        percentage: 0
    },
    gridList: {
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        itemHeight: Volt.height * 0.4,
        itemWidth: DIMMESION_WIDTH * 0.196875,
        rows: 2
    },

    optionMenuBG: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 1920,
        height: 1080,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 153
        },
        parent: scene,
        children: [{
            type: 'image',
            x: 1854,
            y: 55,
            width: 33,
            height: 33,
            opacity: 153,
            src: Volt.getRemoteUrl('images/1080/common/comn_icon_topmenu_option.png')
        }]
    },

    optionMenu: {
        type: 'OptionMenu',
        x: 1461,
        y: 120,
        width: 439,
        text: [Volt.i18n.t('TV_SID_RELEASE_DATE_KR_DATE'), Volt.i18n.t('COM_SID_TITLE_A_Z'), Volt.i18n.t('COM_SID_TITLE_Z_A')],
        custom: {
            focusable: true
        },
        loop: true,
        selectedIdx: 0,
        parent: scene
    },
    optionMenuPara: {
        x: Volt.width * (1 - 0.186458 - 0.010417),
        y: Volt.height * 0.111111,
        width: Volt.width * 0.186458,
        id: "option",
        nResoultionStyle: "1",
        parent: scene,
        mainSelectIndex: 0,
        subSelectIndex: 0,
        bgColor: {
            r: 39,
            g: 124,
            b: 175,
            a: 200
        },
        showNumber: 4,
        items: [{
            style: 2,
            text: Volt.i18n.t('TV_SID_RELEASE_DATE_KR_DATE')
        }, {
            style: 2,
            text: 'Popularity'
        }, {
            style: 2,
            text: Volt.i18n.t('COM_SID_TITLE_A_Z')
        }, {
            style: 2,
            text: Volt.i18n.t('COM_SID_TITLE_Z_A')
        }],
    }
};

exports = CategoriesListTemplate;