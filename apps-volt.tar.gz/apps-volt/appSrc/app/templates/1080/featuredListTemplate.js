var DIMMESION_WIDTH = Volt.dimmensionWidth;

var CommonFunctions = Volt.require('app/common/commonFunctions.js');

var FeaturedListTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'featured-list-content-container-{{ type }}',
                type: 'widget',
                x: 0,
                y: 0,
                width: Volt.width,
                height: Volt.height * 0.8,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'featured-list-no-content-{{ type }}',
                type: 'text',
                x: Volt.width * 0.046875,
                y: Volt.height * (0.8-0.044444*2-0.041667-0.060185)/2,   
                width: Volt.width * (1-0.046875*2),
                height: Volt.height * 0.044444*2 + 10,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: '35px'
            },
            {
                id: 'featured-list-content-index-{{ type }}',
                type: 'text',
                x: Volt.width * 0.9375,
                y: Volt.height * 0.055556,
                height: Volt.height * 0.050926,
                width: Volt.width * 0.052083,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 40),
                text: '',
                font: '26px'
            },
            {
                id: 'featured-list-button-index-{{ type }}',
                type: 'widget',
                x: Volt.width * (1 - 0.140104)/2,
                y: Volt.height * (0.8-0.044444*2-0.041667-0.060185)/2 + Volt.height * (0.044444*2+0.041667), 
                width: Volt.width * 0.140104,
                height: Volt.height * 0.060185,
                color: Volt.hexToRgb('#000000', 0),
                custom: {
                    'focusable': false
                }
            }
        ]
    },
     // Deprecated Start
    troubelShootBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        x: 0,
        y: 0,
        width: Volt.width * 0.140104,
        height: Volt.height * 0.060185,
    },
    eventContainer: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                type: 'image',
                x: 0,
                y: 0,
                width: 378,
                height: 864,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'featured-list-content-container-{{ type }}',
                type: 'widget',
                x: 378,
                y: 0,
                width: 1920 - 378,
                height: 864,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'featured-list-no-content-{{ type }}',
                type: 'text',
                x: 90,
                y: 308,
                height: 55,
                width: 1920 - 180,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: '35px'
            },
            {
                id: 'featured-list-content-index-{{ type }}',
                type: 'text',
                x: 1800,
                y: -60,
                height: 55,
                width: 100,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 40),
                text: '',
                font: '26px'
            }
        ]
    },

    progressbar: {
        //x: Volt.width * 0.013542,
        x: DIMMESION_WIDTH * 0.013542,
        y: Volt.height * 0.22778,
        //width: Volt.width * 0.17083,
        width: DIMMESION_WIDTH * 0.17083,
        height: 2,
        percentage: 0
    },

    gridList: {
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        itemHeight: Volt.height * 0.4,
        //itemWidth: Volt.width * 0.196875,
        itemWidth: DIMMESION_WIDTH * 0.196875,
        rows: 2
    },
};

exports = FeaturedListTemplate;