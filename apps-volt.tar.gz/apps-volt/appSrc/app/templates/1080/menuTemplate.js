var Template = {

    /*list: {
        type: 'widget',
        x: 0, y: 0, width: 1920, height: 108,
        color: Volt.hexToRgb('#f2f2f2', 100),
        children: [{
            type: 'widget',
            x: 0, y: 18, width: 1920, height: 90,
            color: Volt.hexToRgb('#f2f2f2', 0),
            custom: { 'className':'category-content' },
            children: [{
                id: 'category-list-container',
                type: 'widget',
                x: 69, y: 0, width: 1920 - 69*2, height: 90,
                color: Volt.hexToRgb('#f2f2f2', 0),
                cropOverflow: false,
                custom: { 'focusable': true, 'className': 'list-container' },
                children: [
                    {
                        type: 'widget',
                        x: 0, y:0, height: 90,
                        color: Volt.hexToRgb('#f2f2f2', 100),
                        custom: { 'className':'list-animation-container' }
                    }
                ]
            }, {
                type: 'image',
                x:0 , y: 0, width : 48, height : 72,                
                color: Volt.hexToRgb('#f2f2f2', 100),
                custom: { 'className':'list-arrow' },
                children:[{
                    type: 'image',
                    x:12 , y: 21, width : 17, height : 31,
                    src : Volt.getRemoteUrl('images/1080/common/arrow/comn_sub_arrow_left_n.png'),
                    color: Volt.hexToRgb('#f2f2f2', 100),
                }]                
            }, {
                type: 'image',
                x:1920-48 , y: 0, width : 48, height : 72,                
                color: Volt.hexToRgb('#f2f2f2', 100),
                custom: { 'className':'list-arrow' },
                children:[{
                    type: 'image',
                    x: 0, y: 21, width :17, height : 31,
                    src : Volt.getRemoteUrl('images/1080/common/arrow/comn_sub_arrow_right_n.png'),
                    color: Volt.hexToRgb('#f2f2f2', 100),
                }]
            }]
        }]
    },*/

    menu: {
        type: 'widget',
        x: 0,
        y: 0,
        height: Volt.height * 0.083333, //90,
        color: Volt.hexToRgb('#f2f2f2', 100),
        children: [
            {
                type: 'widget',
                y: -Volt.height * 0.016667,
                height: Volt.height * 0.1,
                color: Volt.hexToRgb('#219ee6', 80)
            },
            {
                type: 'text',
                x: Volt.width * 0.020833,
                y: Volt.height * 0.018518,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#464646', 40),
                text: '{{ menuName }}',
                font: (Volt.APPS720P) ? '19px' : '28px',
                ellipsize: true,
                custom: {
                    className: 'label'
                }
        }]
    },
    menuItemBackground: {
        type: 'widget',
        x: 0,
        y: 0,
        height: Volt.height * 0.083333,
        color: Volt.hexToRgb('#f2f2f2', 100),
    },

    categoryTab: {
        id: 'category-list-container',
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.066666,
        color: Volt.hexToRgb('#0f1826'),
        custom: {
            'focusable': true
        }
    },
    // <?#1 Port to Halo Category Tabs ?>
    category: {
        type: 'CategoryTab',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.066666,

        color: {
            r: 15,
            g: 24,
            b: 38,
            a: 255
        },
        margin: {
            top: 0,
            bottom: 0,
            left: Volt.width * 0.005208,
            right: Volt.width * 0.005208
        },

        spliterSize: {
            w: 2,
            h: 2
        },
        enableLooping: true,
        tabFont: (Volt.APPS720P) ? "Sans 19px" : "Sans 28px",
        unselectedFontSize: (Volt.APPS720P) ? 19 : 28,
        selectedFontSize: (Volt.APPS720P) ? 19 : 28,
        highlightedFontSize: (Volt.APPS720P) ? 19 : 28,
        arrowSize: {
            w: Volt.width * (0.024479 - 0.005208),
            h: Volt.width * 0.031481
        },
        leftArrowImage: Volt.getRemoteUrl('images/1080/common/arrow/comn_sub_arrow_left_n.png'),
        rightArrowImage: Volt.getRemoteUrl('images/1080/common/arrow/comn_sub_arrow_right_n.png'),
        /* highlightbarColor: {
            r: 30,
            g: 158,
            b: 230,
            a: 255
        },*/

        highlightbarFocusedColor: {
            r: 255,
            g: 255,
            b: 255,
            a: 255
        },
        highlightbarUnfocusedColor: {
            r: 30,
            g: 158,
            b: 230,
            a: 255
        },

        spliterColor: {
            r: 70,
            g: 70,
            b: 70,
            a: 255
        },
        enableHighlightbar: true,
        highlightbarHeight: 1,
        //textMargin: scene.width * 0.020833,
        textLeftMargin: Volt.width * 0.020833,
        textRightMargin: Volt.width * 0.020833,
        textLimit: Volt.width * 0.208333,
        enableAlignTabsCenter: true,
        highligthFocusAnimation: {
            unfocus: 1,
            focused: 108,
            duration: 200
        },
        highligthMoveAnimationDuration: 200


        /*custom: {
            focusable: true
        },*/
    },

};

exports = Template;