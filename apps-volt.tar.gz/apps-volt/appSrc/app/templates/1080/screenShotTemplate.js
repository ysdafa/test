var CommonTemplate = Volt.requireTemplate('common'),
    SCREEN_WIDTH = Volt.width,
    SCREEN_HEIGHT = Volt.height,
    DIMMESION_WIDTH = Volt.dimmensionWidth;

var screenShotTemplate = {

    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#000000', 50),
        children: [
            {
                type: 'WinsetBackground',
                id: 'popupContainer',
                x: 0,
                y: Volt.height * 0.066667,
                width: Volt.width,
                height: Volt.height * 0.866667,
                bgColor: Volt.hexToRgb('#0f1826', 85),
                bgHighContrastColor: Volt.hexToRgb('#000000', 85),
                children: [
                    {
                        type: 'widget',
                        x: (SCREEN_WIDTH - DIMMESION_WIDTH) / 2,
                        y: 0,
                        width: DIMMESION_WIDTH,
                        height: SCREEN_HEIGHT * 0.866667,
                        color: CommonTemplate.COLOR_TRANSPARENCY,
                        children: [
                            {
                                type: 'image',
                                id: 'screenshot-thumbnail',
                                x: DIMMESION_WIDTH * 0.166667,
                                y: Volt.height * 0.064815,
                                width: DIMMESION_WIDTH * 0.666667,
                                height: Volt.height * 0.666667,
                                border: {
                                    width: 0,
                                    color: Volt.hexToRgb('#aabbcc', 80)
                                }
                            }, {
                                type: 'image',
                                id: 'screenshot-left-arrow',
                                x: DIMMESION_WIDTH * 0.131771,
                                y: Volt.height * 0.398148,
                                width: DIMMESION_WIDTH * 0.013021,
                                height: Volt.height * 0.044444,
                                //color : {r:0,g:0,b:0,a:0},
                                src: Volt.APPS_REVERSE ? Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_r_n.png') : Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_l_n.png')
                                //custom: { 'focusable': true }
                            }, {
                                type: 'image',
                                id: 'screenshot-right-arrow',
                                x: DIMMESION_WIDTH * 0.855208,
                                y: Volt.height * 0.398148,
                                width: DIMMESION_WIDTH * 0.013021,
                                height: Volt.height * 0.044444,
                                //color : {r:0,g:0,b:0,a:0},
                                src: Volt.APPS_REVERSE ? Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_l_n.png') : Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_r_n.png'),
                                //custom: { 'focusable': true }
                            }, {
                                type: 'widget',
                                id: 'screenshot-close-button',
                                x: DIMMESION_WIDTH * 0.4296875,
                                y: Volt.height * 0.767592,
                                width: DIMMESION_WIDTH * 0.140625,
                                height: Volt.height * 0.061111,
                                color: {
                                    r: 0,
                                    g: 0,
                                    b: 0,
                                    a: 0
                                },
                                custom: {
                                    'focusable': true
                                }
                                /*border : {
                                    width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
                                },
                                children : [
                                    {
                                        type : 'text',
                                        x : 0, y : 0, width : 270, height : 66,
                                        horizontalAlignment : 'center',
                                        verticalAlignment : 'center',
                                        font : '32px', textColor : Volt.hexToRgb('#ffffff'),
                                        opacity : Volt.getPercentage(80),
                                        text : Volt.i18n.t('COM_SID_CLOSE')
                                    }
                                ],*/
                            }
                        ]
                    }
                ]
            }
        ]
    },
    screenShotcloseBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "screenShotcloseBtn",
        x: 0,
        y: 0,
        width: DIMMESION_WIDTH * 0.140625,
        height: Volt.height * 0.061111,
        text: Volt.i18n.t('COM_SID_CLOSE'),
    },

    leftArrowBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: 'leftArrowBtn',
        x: 0,
        y: 0,
        width: DIMMESION_WIDTH * 0.013021,
        height: Volt.height * 0.044444,
        iconWidth: DIMMESION_WIDTH * 0.013021,
        iconHeight: Volt.height * 0.044444,
        iconImgSrc: Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_l_n.png'),
    },

    rightArrowBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: 'rightArrowBtn',
        x: 0,
        y: 0,
        width: DIMMESION_WIDTH * 0.013021,
        height: Volt.height * 0.044444,
        iconWidth: DIMMESION_WIDTH * 0.013021,
        iconHeight: Volt.height * 0.044444,
        iconImgSrc: Volt.getRemoteUrl('images/1080/common/popup/apps_popup_arrow_r_n.png'),
    },
};

exports = screenShotTemplate;