/** 
 * @author  Daeho Song (daehor.song@samsung.com)
 * @fileoverview Message Popup Template for UI
 * @date    2014/07/28 (last modified date)
 *
 * Copyright 2014 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var MessagePopupTemplate = {

    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: 1920,
        height: 1080,
        color: Volt.hexToRgb('#000000', 60),
        children: [
            {
                type: 'widget',
                x: 0,
                width: 1920,
                color: Volt.hexToRgb('#0f1826', 90),
                custom: {
                    'focusable': true,
                    //'onKeyEvent' : null
                }
            }
        ],
    },

    header: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 1920,
        height: 96,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'text',
                x: 0,
                y: 0,
                width: 1920,
                height: 96,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                text: '{{title}}',
                font: '44px'
            }, {
                type: 'widget',
                x: 399,
                y: 95,
                width: 1122,
                height: 1,
                color: Volt.hexToRgb('#ffffff', 76)
            }
        ]
    },

    contentLineHeight: 40,

    content: {
        type: 'widget',
        x: 399,
        y: 48,
        width: 1920 - (399 * 2),
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'text',
                x: 0,
                y: 0,
                width: 1920 - (399 * 2),
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 90),
                text: '{{content}}',
                font: '34px'
            }
        ]
    },

    buttonGap: 12,

    buttonHeightGap: 22,

    buttonArea: {
        type: 'widget',
        x: 0,
        height: 66,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        }
    },

    button: {
        type: 'widget',
        id: '{{id}}',
        x: 0,
        y: 0,
        width: 270,
        height: 66,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        border: {
            width: 2,
            color: Volt.hexToRgb('#aabbcc', 80)
        },
        children: [
            {
                type: 'text',
                x: 0,
                y: 0,
                width: 270,
                height: 66,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                font: '32px',
                textColor: Volt.hexToRgb('#ffffff', 60),
                opacity: Volt.getPercentage(80),
                text: '{{name}}'
            }
        ],
        custom: {
            'focusable': true
        }
    },

    pinPopupAttribute: {
        x: 710,
        y: 375,
        height: 330,
        width: 500
    },

    pinBoxAttribute: {
        PINBoxX: 35,
        PINBoxY: 130,
        PINBoxWidth: 100,
        PINBoxHeight: 70,
        PINBoxGap: 10,
        bgSrc: {
            normal: Volt.getRemoteUrl("images/1080/common/input/input_box_n.png"),
            focus: Volt.getRemoteUrl("images/1080/common/input/input_box_style_c_f.png")
        },
        PINImgSrc: {
            normal: Volt.getRemoteUrl("images/1080/common/input/obe_pin_n.png"),
            focus: Volt.getRemoteUrl("images/1080/common/input/obe_pin_f.png")
        },
        PINImgX: 50,
    },

    pinPopupButtonAttribute: {
        x: 115,
        y: 234,
        width: 270,
        height: 66,
        buttonText: {
            normal: ''
        },
    }
};

exports = MessagePopupTemplate;