var UpdateAppsTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#000000', 50),
        children: [
            {
                type: 'WinsetBackground',
                id: 'updateApps-popup',
                x: 0,
                y: Volt.height * 0.107408,
                width: Volt.width,
                height: Volt.height * 0.785185,
                style: '{{highconstract}}',
                bgColor: Volt.hexToRgb('#0f1826',100),
                bgHighContrastColor: Volt.hexToRgb('#000000', 100), 

                children: [
                    {
                        type: 'widget',
                        id: 'updateApps-title-container',
                        x: 0,
                        y: 0,
                        width: Volt.width,
                        height: Volt.height * 0.090741,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        }
              }, {
                        type: 'widget',
                        id: 'updateApps-line-container',
                        x: Volt.width * 0.2078125,
                        y: Volt.height * 0.090741,
                        width: Volt.width * 0.584375,
                        height: 1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        }
              }, {
                        type: 'widget',
                        x: Volt.width * 0.199479,
                        y: Volt.height * (0.090741),
                        width: Volt.width * 0.423958,
                        height: Volt.height * (0.133333 * 4 + 0.080556 * 2),
                        id: 'updateApps-list-container',
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        horizontalAlignment: 'center',
                        children: [
                            {
                                type: "image",
                                x: 15,
                                y: 25,
                                id: 'arrow_up',
                                width: Volt.width * 0.407291,
                                height: Volt.height * 0.040740,
                                //src: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_d.png'),
                          },
                            {
                                type: "image",
                                x: 15,
                                y: Volt.height * (0.533333 + 0.080556) + 18,
                                id: 'arrow_down',
                                width: Volt.width * 0.407291,
                                height: Volt.height * 0.040740,
                                //src: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_d.png'),
      },
      ],
                        opacity: 216
              }, {
                        type: 'widget',
                        x: Volt.width * 0.199479,
                        y: Volt.height * (0.171297),
                        width: Volt.width * 0.423958,
                        height: Volt.height * (0.133333 * 4 + 0.080556 * 2),
                        id: 'updateApps-loading-container',
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        opacity: 216
                    },
                    {
                        type: 'widget',
                        x: Volt.width * 0.659896,
                        y: Volt.height * 0.171297,
                        width: Volt.width * 0.140625,
                        height: Volt.height * 0.244444,
                        id: 'updateApps-button-container',
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        opacity: 216
              }
          ]
         }
        ]
    },
    title: {
        type: 'WinsetBackground',
        x: 0,
        y: 0,
        width: Volt.width,
        height: 0.090741 * Volt.height,
        style: '{{highconstract}}',
        bgColor: Volt.hexToRgb('#0f1826',100),
        bgHighContrastColor: Volt.hexToRgb('#000000', 100), 
        children: [
            {
                type: 'text',
                x: 0,
                y: 0,
                width: Volt.width,
                height: 0.088889 * Volt.height,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 255),
                text: Volt.i18n.t('COM_TV_SID_UPDATE_APPS_KR_SINGULAR'),
                font: (Volt.APPS720P) ? '31px' : '46px'
            }
        ]
    },

    line: {
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width * 0.584375,
        height: 1,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                type: "widget",
                x: 0,
                y: 0,
                width: Volt.width * 0.584375,
                height: 1,
                color: Volt.hexToRgb('#a0a0a0', 255),
         }
        ]
    },
    list: {
        type: 'Singlelist',
        x: 0,
        y: Volt.height * 0.080556, //scene.height * 0.080556,
        width: Volt.width * 0.423958,
        height: Volt.height * (0.133333 * 4),
        scrollType: "Vertical",
        id: "updateList",
        custom: {
            focusable: true,
        },
    },
    UpdateItem: {
        type: 'Thumbnail',
        visibleStyles: (0x20 | 0x10),

        information: {
            x: (0.006250) * Volt.width,
            y: 0,
            width: (0.218750 + 0.001042 + 0.092708 + 0.007813 + 0.059896 + 0.009375) * Volt.width + 40,
            height: 0.133333 * Volt.height,
            color:Volt.hexToRgb('#000000',0),
            highContrast:{
                textColor: Volt.hexToRgb('#ffffff'),
                highlightTextColor:{r:0x00, g:0x00, b:0x00, a:255}  
            },
            text1: {
                x: (0.007813 + 0.059896 + 0.009375) * Volt.width + 40,
                y: 0.040741 * Volt.height,
                width: 0.218750 * Volt.width,
                height: 0.044444 * Volt.height,
                font: (Volt.APPS720P) ? "SamsungSmart_Korea_Medium 22px" : "SamsungSmart_Korea_Medium 34px",
                textColor: Volt.hexToRgb('#ffffff'),
                text: '',
                ellipsize: true,
            },
            text2: {
                x: (0.007813 + 0.059896 + 0.009375) * Volt.width + 40,
                y: (0.040741 + 0.044444) * Volt.height,
                width: 0.218750 * Volt.width,
                height: 0.027778 * Volt.height,
                font: (Volt.APPS720P) ? "SamsungSmart_Korea_Medium 13px" : "SamsungSmart_Korea_Medium 20px",
                textColor: Volt.hexToRgb('#ffffff'),
                text: '',
                ellipsize: true,
            },
            text3: {
                x: (0.218750 + 0.001042 + 0.007813 + 0.059896 + 0.009375) * Volt.width + 40,
                y: 0.051852 * Volt.height,
                width: 0.092708 * Volt.width,
                height: 0.037037 * Volt.height,
                font: (Volt.APPS720P) ? "SamsungSmart_Korea_Medium 22px" : "SamsungSmart_Korea_Medium 34px",
                textColor: Volt.hexToRgb('#ffffff'),
                text: '',
                ellipsize: true,
            },
            icon1: {
                //src: Volt.getRemoteUrl("images/1080/common/btn_icon_favorite_on.png"),
                x: 0.009375 * Volt.width + 40,
                y: (0.133333 - 0.087963) / 2 * Volt.height,
                width: 0.059896 * Volt.width,
                height: 0.087963 * Volt.height,
                async: true
            },
            icon2: {
                //src: Volt.getRemoteUrl("images/winsetImg/1080p/check/popup_check_box.png"),
                x: 0,
                y: 0.016667 * Volt.height,
                width: 40,
                height: 40,
                async: true
            },
            icon3: {
                //src: Volt.getRemoteUrl("images/winsetImg/1080p/check/popup_check_icon_n.png"),
                x: 0,
                y: 0.016667 * Volt.height,
                width: 40,
                height: 40,
                async: true
            },
        },
    },
    buttonArea: {
        type: 'widget',
        x: 0,
        y: 0,
        width: 0.140625 * Volt.width,
        height: Volt.height * 0.5,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'widget',
                id: 'update-selectall-button',
                x: 0,
                y: Volt.height * 0.122222,
                width: Volt.width * 0.140625,
                height: Volt.height * 0.061111,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                /*border : {
                    width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
                },
                children : [
                    {
                        type : 'text',
                        x : 0, y : 0, width : 270, height : 66,
                        horizontalAlignment : 'center',
                        verticalAlignment : 'center',
                        font : '32px', textColor : {r: 255, g: 255, b: 255, a:255},
                        opacity : Volt.getPercentage(80),
                        text : 'Select All'
                    }
                ],*/
                custom: {
                    'focusable': true
                },
            },
            {
                type: 'widget',
                id: 'update-deselectall-button',
                x: 0,
                y: Volt.height * (0.075926+0.122222),
                width: Volt.width * 0.140625,
                height: Volt.height * 0.061111,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                /*border : {
                    width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
                },
                children : [
                    {
                        type : 'text',
                        x : 0, y : 0, width : 270, height : 66,
                        horizontalAlignment : 'center',
                        verticalAlignment : 'center',
                        font : '32px', textColor : {r: 255, g: 255, b: 255, a:255},
                        opacity : Volt.getPercentage(80),
                        text : 'Deselect All'
                    }
                ],*/
                custom: {
                    'focusable': true
                },
            },
            {
                type: 'widget',
                id: 'update-update-button',
                x: 0,
                y: Volt.height * (0.151852+0.122222),
                width: Volt.width * 0.140625,
                height: Volt.height * 0.061111,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                /*border : {
                    width : 2 , color :  Volt.hexToRgb('#ffffff', 30)
                },
                children : [
                    {
                        type : 'text',
                        x : 0, y : 0, width : 270, height : 66,
                        horizontalAlignment : 'center',
                        verticalAlignment : 'center',
                        font : '32px', textColor : {r: 255, g: 255, b: 255, a:255},
                        opacity : Volt.getPercentage(80),
                        text : 'Update'
                    }
                ],*/
                custom: {
                    'focusable': false
                },
            },
            {
                type: 'widget',
                id: 'update-close-button',
                x: 0,
                y: Volt.height * (0.227778+0.122222),
                width: Volt.width * 0.140625,
                height: Volt.height * 0.061111,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                /*border : {
                    width : 2 , color :  Volt.hexToRgb('#ffffff', 80)
                },
                children : [
                    {
                        type : 'text',
                        x : 0, y : 0, width : 270, height : 66,
                        horizontalAlignment : 'center',
                        verticalAlignment : 'center',
                        font : '32px', textColor : {r: 255, g: 255, b: 255, a:255},
                        opacity : Volt.getPercentage(80),
                        text : 'Close'
                    }
                ],*/
                custom: {
                    'focusable': true
                },
            }
        ]
    },

    UpdateAppsList: {
        type: 'widget',
        id: 'updateapps-list-area',
        x: 0,
        y: 0,
        width: Volt.width * 0.423958,
        height: Volt.height * (0.533333 + 0.080556 * 2),
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        custom: {
            'focusable': true
        },
        children: [

  ],

    },

    /*loading : {
        icon : {
            type : 'image',
            x:0, y : 0,  width : 301, height:58,
            src : Volt.getRemoteUrl('images/1080/common/loading/white/20x20/loading_bright_20_01.png')
        }
    },*/

    loading: {
        type: 'WinsetLoading',
        x: Volt.width *0.133594,
        y: Volt.height * 0.239815,
        width: Volt.width * 0.423958,
        height: Volt.height * (0.133333 * 4 + 0.080556 * 2),
        style: '{{style20}}',
        nResoultionStyle: '{{nResoultionStyle}}',
        text: ''
    },

    setList: {
        x: 0,
        y: 0,
        width: Volt.width * 0.423958,
        height: Volt.height * 0.533333,
        color: Volt.hexToRgb('#0f1826'),
        itemWidth: Volt.width * 0.423958,
        itemHeight: Volt.height * 0.133333,
        cursorOffsetX: Volt.width * 0.010417,
        itemSpace: Volt.height * 0.009259,
        topMargin: Volt.height * 0.046296,
        bottomMargin: Volt.height * 0.046296,
        isVerticalFlag: true,
        looping: false,
        upArrow: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png'),
        downArrow: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png')
    },

    upArrow: {
        x: 0,
        y: 0,
        unHighlightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_n.png'),
        highlightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_up_f.png')
    },

    downArrow: {
        x: 0,
        y: Volt.height * 0.472222,
        unHighlightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_n.png'),
        highlightSrc: Volt.getRemoteUrl('images/1080/common/popup/popup_arrow_down_f.png')
    },
    closeBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "closeBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.140625,
        height: Volt.height * 0.061111,
        text: Volt.i18n.t('COM_SID_CLOSE'),
    },
    updateBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "updateBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.140625,
        height: Volt.height * 0.061111,
        text: Volt.i18n.t('UID_UPDATE'),
    },
    deselectAllBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "deselectAllBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.140625,
        height: Volt.height * 0.061111,
        text: Volt.i18n.t('UID_DESELECT_ALL')
    },
    selectAllBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "selectAllBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.140625,
        height: Volt.height * 0.061111,
        text: Volt.i18n.t('COM_SID_SELECT_ALL'),
    }
}

exports = UpdateAppsTemplate;