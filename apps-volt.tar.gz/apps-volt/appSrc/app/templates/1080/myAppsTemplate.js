var DIMMESION_WIDTH = Volt.dimmensionWidth;

var MyAppsTemplate = {

    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.8,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
            {
                id: 'myapps-content-container',
                type: 'widget',
                x: 0,
                y: 0,
                width: Volt.width,
                height: Volt.height * 0.8,
                color: Volt.hexToRgb('#dfdfdf')
            },
            {
                id: 'myapps-no-content',
                type: 'text',
                x: Volt.width * 0.046875,
                y: Volt.height * 0.285185,
                width: Volt.width * 0.90625,
                height: Volt.height * 0.050926,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 60),
                text: '',
                font: (Volt.APPS720P) ? '23px' : '35px'
            },
            {
                id: 'myapps-content-index',
                type: 'text',
                x: Volt.width * 0.9375,
                y: -Volt.height * 0.055556,
                width: Volt.width * 0.052083,
                height: Volt.height * 0.050926,
                horizontalAlignment: 'center',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#000000', 40),
                text: '',
                font: (Volt.APPS720P) ? '17px' : '26px'
            }
        ]
    },

    lockIcon_w: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        //width: Volt.width * 0.008333,
        width: DIMMESION_WIDTH * 0.008333,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_lock_white.png'),
        async: true
    },

    lockIcon_b: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        //width: Volt.width * 0.008333,
        width: DIMMESION_WIDTH * 0.008333,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_lock_black.png'),
        async: true
    },

    usbIcon_w: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        //width: Volt.width * 0.016667,
        width: DIMMESION_WIDTH * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_usb_white.png'),
        async: true
    },

    usbIcon_b: {
        type: 'image',
        opacity: Volt.getPercentage(65),
        x: 0,
        y: Volt.height * 0.02037,
        //width: Volt.width * 0.016667,
        width: DIMMESION_WIDTH * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon/icon_usb_black.png'),
        async: true
    },

    updateIcon: {
        type: 'image',
        //x: Volt.width * 0.105729,
        x: DIMMESION_WIDTH * 0.105729,
        y: Volt.height * 0.02037,
        //width: Volt.width * 0.016667,
        width: DIMMESION_WIDTH * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon_update_sequence_01.png'),
        async: true
    },

    updatedIcon: {
        type: 'image',
        //x: Volt.width * 0.105729,
        x: DIMMESION_WIDTH * 0.105729,
        y: Volt.height * 0.02037,
        //width: Volt.width * 0.016667,
        width: DIMMESION_WIDTH * 0.016667,
        height: Volt.height * 0.02963,
        src: Volt.getRemoteUrl('images/1080/common/icon_update_sequence_06.png'),
        async: true
    },

    editModeContainer: {
        type: 'WinsetBackground',
        id: 'edit-mode-container',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.066667,
        style: '{{highconstract}}',
        bgColor: Volt.hexToRgb('#0f1826'),
        bgHighContrastColor: Volt.hexToRgb('#000000', 100),
        children: [
            {
                type: 'text',
                id: 'select-title',
                x: Volt.width * 0.020833,
                y: 0,
                /*width : Volt.width*0.15625,*/ height: Volt.height * 0.066667,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                font: (Volt.APPS720P) ? '18px' : '28px',
                textColor: Volt.hexToRgb('#ffffff'),
                text: Volt.i18n.t('TV_SID_MIX_SELECTED_ITEM_COLON').replace('<<A>>', ""), //'Selected items : ',
                custom: {
                    className: 'edit-mode-selected-text'
                }
            },
            {
                type: 'text',
                id: 'select-count',
                x: 0,
                y: 0,
                width: Volt.width * 0.052083,
                height: Volt.height * 0.066667,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                font: (Volt.APPS720P) ? '21px' : '31px',
                textColor: Volt.hexToRgb('#24b6f4'),
                text: '0',
                custom: {
                    className: 'edit-mode-selected-count'
                }
            },
            {
                custom: {
                    'focusable': true
                },
                id: 'edit-select-button',
                type: 'widget',
                x: Volt.width * 0.53125,
                y: 0,
                width: Volt.width * 0.15625,
                height: Volt.height * 0.066667,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                custom: {
                    'focusable': true
                },
                id: 'edit-exceute-button',
                type: 'widget',
                x: Volt.width * 0.6875,
                y: 0,
                width: Volt.width * 0.15625,
                height: Volt.height * 0.066667,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            }, {
                custom: {
                    'focusable': true
                },
                id: 'edit-cancel-button',
                type: 'widget',
                x: Volt.width * 0.84375,
                y: 0,
                width: Volt.width * 0.15625,
                height: Volt.height * 0.066667,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
            },
        ]
    },
    generalBtn: {
        type: 'Button',
        //style : '{{style}}',
        //buttonType : '{{buttonType}}',
        x: (Volt.APPS720P) ? -3 : -4,
        y: (Volt.APPS720P) ? -3 : -4,
        width: Volt.width * 0.15625 + ((Volt.APPS720P) ? 6 : 8),
        height: Volt.height * 0.066667 + ((Volt.APPS720P) ? 6 : 8),
        children: [
            {
                type: 'widget',
                x: (Volt.APPS720P) ? 3 : 4,
                y: (Volt.APPS720P) ? 3 : 4,
                width: 1,
                height: Volt.height * 0.066667,
                color: {
                    r: 255,
                    g: 255,
                    b: 255,
                    a: 51
                },
                custom: {
                    className: 'multi_seletion_buttons_bar'
                }
            },
        ]
    },

    itemDim: {
        type: 'widget',
        x: 0,
        y: 0,
        //width: Volt.width * 0.102083,
        width: DIMMESION_WIDTH * 0.102083,
        height: Volt.height * 0.266667,
        color: Volt.hexToRgb('#0f1826'),
        opacity: Volt.getPercentage(80)
    },

    headerCover: {
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height * 0.133333,
        color: Volt.hexToRgb('#000000'),
        opacity: Volt.getPercentage(20),
        parent: scene
    }
};

exports = MyAppsTemplate;