var developModeSetTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#000000', 50),
        children: [
            {
                type: 'widget',
                id: 'updateApps-popup',
                x: Volt.width * 0.2,
                y: Volt.height * 0.25,
                width: Volt.width * 0.6,
                height: Volt.height * 0.5,
                color: Volt.hexToRgb('#0f1826', 100),
                children: [
                    {
                        type: 'widget',
                        id: 'updateApps-title-container',
                        x: Volt.width * 0.6 * 0.2,
                        y: Volt.height * 0.5 * 0.2,
                        width: Volt.width * 0.6 * 0.2,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        }
              },
                    {
                        type: 'widget',
                        id: 'set-on-button',
                        x: Volt.width * 0.6 * 0.5,
                        y: Volt.height * 0.5 * 0.2,
                        width: Volt.width * 0.6 * 0.1,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              },
                    {
                        type: 'widget',
                        id: 'set-off-button',
                        x: Volt.width * 0.6 * 0.6,
                        y: Volt.height * 0.5 * 0.2,
                        width: Volt.width * 0.6 * 0.1,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              },
                    {
                        type: 'text',
                        x: Volt.width * 0.6 * 0.2,
                        y: Volt.height * 0.5 * 0.5,
                        width: Volt.width * 0.6 * 0.3,
                        height: Volt.height * 0.5 * 0.1,
                        horizontalAlignment: 'left',
                        verticalAlignment: 'center',
                        textColor: Volt.hexToRgb('#ffffff', 255),
                        text: 'Host PC IP :',
                        font: (Volt.APPS720P) ? '26px' : '31px'
              },
                    {
                        type: 'widget',
                        id: 'set-inpux-button1',
                        x: Volt.width * 0.6 * 0.2,
                        y: Volt.height * 0.5 * 0.6,
                        width: Volt.width * 0.6 * 0.12,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              },
                    {
                        type: 'text',
                        x: Volt.width * 0.6 * (0.2 + 0.12) + 10,
                        y: Volt.height * 0.5 * 0.6,
                        width: Volt.width * 0.6 * 0.02,
                        height: Volt.height * 0.5 * 0.1,
                        horizontalAlignment: 'conter',
                        verticalAlignment: 'center',
                        textColor: Volt.hexToRgb('#ffffff', 255),
                        text: ' . ',
                        font: (Volt.APPS720P) ? '26px' : '31px'
              },
                    {
                        type: 'widget',
                        id: 'set-inpux-button2',
                        x: Volt.width * 0.6 * (0.2 + 0.12 + 0.03),
                        y: Volt.height * 0.5 * 0.6,
                        width: Volt.width * 0.6 * 0.12,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              },
                    {
                        type: 'text',
                        x: Volt.width * 0.6 * (0.2 + 0.12 + 0.03 + 0.12) + 10,
                        y: Volt.height * 0.5 * 0.6,
                        width: Volt.width * 0.6 * 0.02,
                        height: Volt.height * 0.5 * 0.1,
                        horizontalAlignment: 'conter',
                        verticalAlignment: 'center',
                        textColor: Volt.hexToRgb('#ffffff', 255),
                        text: ' . ',
                        font: (Volt.APPS720P) ? '26px' : '31px'
              },
                    {
                        type: 'widget',
                        id: 'set-inpux-button3',
                        x: Volt.width * 0.6 * (0.2 + 0.12 * 2 + 0.03 * 2),
                        y: Volt.height * 0.5 * 0.6,
                        width: Volt.width * 0.6 * 0.12,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              },
                    {
                        type: 'text',
                        x: Volt.width * 0.6 * (0.2 + 0.12 * 2 + 0.03 * 2 + 0.12) + 10,
                        y: Volt.height * 0.5 * 0.6,
                        width: Volt.width * 0.6 * 0.02,
                        height: Volt.height * 0.5 * 0.1,
                        horizontalAlignment: 'conter',
                        verticalAlignment: 'center',
                        textColor: Volt.hexToRgb('#ffffff', 255),
                        text: ' . ',
                        font: (Volt.APPS720P) ? '26px' : '31px'
              },
                    {
                        type: 'widget',
                        id: 'set-inpux-button4',
                        x: Volt.width * 0.6 * (0.2 + 0.12 * 3 + 0.03 * 3),
                        y: Volt.height * 0.5 * 0.6,
                        width: Volt.width * 0.6 * 0.12,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              },
                    {
                        type: 'widget',
                        id: 'set-ok-button',
                        x: Volt.width * 0.6 * 0.25,
                        y: Volt.height * 0.5 * 0.8,
                        width: Volt.width * 0.6 * 0.2,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              },
                    {
                        type: 'widget',
                        id: 'set-cancel-button',
                        x: Volt.width * 0.6 * (0.25 + 0.2 + 0.1),
                        y: Volt.height * 0.5 * 0.8,
                        width: Volt.width * 0.6 * 0.2,
                        height: Volt.height * 0.5 * 0.1,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        custom: {
                            'focusable': true
                        },
              }
          ]
         }
        ]
    },
    title: {
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width * 0.6 * 0.3,
        height: Volt.height * 0.5 * 0.1,
        color: Volt.hexToRgb('#0f1826'),
        children: [
            {
                type: 'text',
                x: 0,
                y: 0,
                width: Volt.width * 0.6 * 0.3,
                height: Volt.height * 0.5 * 0.1,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 255),
                text: 'Developer mode : Off',
                font: (Volt.APPS720P) ? '26px' : '31px'
            }
        ]
    },
    onBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "onBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.6 * 0.1,
        height: Volt.height * 0.5 * 0.1,
        text: 'On',
    },
    offBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "offBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.6 * 0.1,
        height: Volt.height * 0.5 * 0.1,
        text: 'Off',
    },
    okBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "okBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.6 * 0.2,
        height: Volt.height * 0.5 * 0.1,
        text: Volt.i18n.t('COM_SID_OK')
    },
    cancelBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "cancelBtn",
        x: 0,
        y: 0,
        width: Volt.width * 0.6 * 0.2,
        height: Volt.height * 0.5 * 0.1,
        text: Volt.i18n.t('COM_SID_CANCEL'),
    },
    inputBox: {
        type: 'WinsetInputBox',
        style: '{{style}}',
        nResoultionStyle: '{{resoultion}}',
        id: '{{id}}',
        x: 0,
        y: 0,
        width: Volt.width * 0.6 * 0.12,
        height: Volt.height * 0.5 * 0.1,
    },
    smartHubContainer: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#233146', 0),
    }
}
exports = developModeSetTemplate;