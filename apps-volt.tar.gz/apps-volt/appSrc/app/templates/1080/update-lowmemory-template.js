var UpdateLowMemoryPopupTemplate = {

    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#000000', 50),
        children: [
            {
                type: 'WinsetBackground',
                id: 'lowmemory-popup',
                x: 0,
                y: Volt.height *(1 - 0.52963)/2,
                width: Volt.width,
                height: Volt.height * 0.52963,
                bgColor: Volt.hexToRgb('#0f1826'),
                bgHighContrastColor: Volt.hexToRgb('#000000', 100), // 1f2b3d
                children: [
                    {
                        type: 'widget',
                        id: 'lowmemory-title-container',
                        x: Volt.width * (1 - 0.584375)/2,
                        y: Volt.height * 0.020371,
                        width: Volt.width * 0.584375,
                        height: Volt.height * 0.044445*2,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        }
                  },  {
                        type: 'widget',
                        x: Volt.width * (1 - 0.584375)/2,
                        y: Volt.height * (0.020371 + 0.044445*3 ) ,
                        width: Volt.width * 0.584375,
                        height: Volt.height * (0.044445 * 6 ),
                        id: 'lowmemory-list-container',
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        horizontalAlignment: 'center',
                        opacity: 216,
                  },{
                        type: 'widget',
                        x: Volt.width * (1 - 0.140625)/2,
                        y: Volt.height * (0.020317 + 0.044445*8 + 0.064815),
                        width: Volt.width * 0.140625,
                        height: Volt.height * 0.061111,
                        id: 'lowmemory-button-container',
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                        opacity: 216,
                        custom: {
                            'focusable': true
                        }
                  },
             ]
             },{
                type: 'widget',
                id: 'usbList-popup-upcover',
                x: 0,
                y: 0,
                width: Volt.width,
                height: Volt.height * 0.15,
                color: Volt.hexToRgb('#000000'),
                opacity: Volt.getPercentage(20),
                parent: scene
            },         
            {
                type: 'widget',
                id: 'usbList-popup-downcover',
                x: 0,
                y: Volt.height * 0.85,
                width: Volt.width,
                height: Volt.height * 0.15,
                color: Volt.hexToRgb('#000000'),
                opacity: Volt.getPercentage(20),
                parent: scene
            } 
        ]
    },

    title: {
            type: 'text',
            x: 0,
            y: 0,
            width: Volt.width * 0.584375,
            height: Volt.height * 0.088889,
            horizontalAlignment: 'left',
            verticalAlignment: 'center',
            textColor: Volt.hexToRgb('#ffffff', 90),
            text: "The updated was not completeed because of insufficient memory.Please make more memory,To manage the update manually change auto updated settings",
            font: (Volt.APPS720P) ? '22px' : '34px',
            singleLineMode: false,
    },

    neededItem: {
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width * 0.584375,
        height: Volt.height * 0.044445,
        color: Volt.hexToRgb('#0f1826',0),
        children: [
            {
                type: 'text',
               // id: "device-name",
                x: 0,
                y: 0,
                width: Volt.width * 0.284375,
                height: Volt.height * 0.044445,
                color: Volt.hexToRgb('#ffffff', 0),
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 90),
                font: (Volt.APPS720P) ? "SamsungSmart_Korea_Light 22px" : "SamsungSmart_Korea_Light 34px",
                text:'{{name}}',
                ellipsize: true
          }, {
                type: 'text',
                //id: "needed-storage",
                x: Volt.width * (0.284375 + 0.010417),
                y: 0,
                width: Volt.width * 0.289584,
                height: Volt.height * 0.044445,
                horizontalAlignment: 'right',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 90),
                opacity: 255,
                text:'{{neededsize}}',
                color: Volt.hexToRgb('#ff0000', 0),
                font: (Volt.APPS720P) ? "SamsungSmart_Korea_Light 22px" : "SamsungSmart_Korea_Light 34px",
          },
          
        ]
    },

    button: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "usbList-cancel-button",
        x: 0,
        y: 0,
        width: Volt.width * 0.140625,
        height: Volt.height * 0.061111,
        text: Volt.i18n.t('COM_SID_OK'),
    },

    
 
    
   

}

exports = UpdateLowMemoryPopupTemplate;


