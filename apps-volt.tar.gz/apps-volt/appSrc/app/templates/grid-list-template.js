/** 
 * @author Common Module Team
 * @fileoverview Template for Grid List View
 * @date 2014/11/18
 *
 * @version 2.0
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

// Thumbnail Visibile Style Definitions
// HALO_ITEM_ALL_SAME:                 0,
// HALO_ITEM_NOT_ALL_SAME:             1,
// THUMB_STYLE_BLANK:                  0x00,
// THUMB_STYLE_IMAGE:                  0x01,
// THUMB_STYLE_ICON:                   0x02,
// THUMB_STYLE_TEXT:                   0x04,
// THUMB_STYLE_PROGRESSBAR:            0x08,
// THUMB_STYLE_CHECKBOX:               0x10,
// THUMB_STYLE_INFO:                   0x20

var THUMB_VISIBLE_STYLE_IMAGE = 0x01;
var THUMB_VISIBLE_STYLE_INFO = 0x20;

// Get Common Parameters from CommonTemplate
var CommonTemplate = Volt.requireTemplate('common');
var SCREEN_WIDTH = Volt.width;
var SCREEN_HEIGHT = Volt.height;
var DIMMESION_WIDTH = Volt.dimmensionWidth;

// Calc Multi-Resolution Parameters
var wUpdateIcon = Volt.getMultiResParam(21, 32);
var CommonFunctions = Volt.require('app/common/commonFunctions.js');

//
var GridListTemplate = {
    // Grid Template Index Definition
    GRID_MYAPPS: 0,
    GRID_RELATED: 1,
    
    // Thumbnail Template Index Definition
    THUMB_MYAPPS: 0,
    THUMB_WHATS_NEW: 1,
    THUMB_PIA: 2,
    THUMB_MOST_POPULAR: 3,
    THUMB_CATEGORY: 4,
    THUMB_RELATED: 5,
    THUMB_SCREENSHOT: 6,

    // Get a grid template according to thumbnail style defined in GUI doc
    getGridTemplate: function (gridStyle) {
        return this.grids[this[gridStyle]];
    },

    // Get a thumbnail template according to thumbnail style defined in GUI doc
    getThumbnailTemplate: function (thumbStyle) {
        return this.thumbnails[this[thumbStyle]];
    },

    grids: [
        {   // Grid Template of My Apps
            x: 0,
            y: 0,
            width: Volt.width,
            height: Volt.height * 0.8,
            titleSpace: 0,
            groupSpace: 0,
            cellSpace: 0,
            focusRangeStartOffset: 0,
            focusRangeEndOffset: 0,
            //itemWidth: Volt.width * 0.132812,
            itemWidth: DIMMESION_WIDTH * 0.132812,
            itemHeight: Volt.height * 0.266666,
            editModeIndicator: {
                up: { x: (DIMMESION_WIDTH * 0.132812-67)/2, y: -39, width: 67, height: 39, src: Volt.getRemoteUrl('images/1080/common/apps_arrow_multi_move_u.png')},
                down: { x: (DIMMESION_WIDTH * 0.132812-67)/2, y: Volt.height * 0.266666, width: 67, height: 39, src: Volt.getRemoteUrl('images/1080/common/apps_arrow_multi_move_d.png') },
                left: { x: -40, y: (Volt.height * 0.266666-69)/2, width: 40, height: 69, src: Volt.getRemoteUrl('images/1080/common/apps_arrow_multi_move_l.png') },
                right: { x: DIMMESION_WIDTH * 0.132812, y: (Volt.height * 0.266666-69)/2, width: 40, height: 69, src: Volt.getRemoteUrl('images/1080/common/apps_arrow_multi_move_r.png') },
            }
        }, {   // Grid Template of Related Apps
            x: 0,
            y: SCREEN_HEIGHT * 0.043519, //47,
            width: SCREEN_WIDTH,
            height: SCREEN_HEIGHT * 0.20463, //221,
            titleSpace: 0,
            groupSpace: 0,
            cellSpace: 0,
            focusRangeStartOffset: 0,
            focusRangeEndOffset: 0,
            color: {
                r: 0,
                g: 0,
                b: 0,
                a: 0
            },
            itemHeight: SCREEN_HEIGHT * 0.20463, //221,
            itemWidth: DIMMESION_WIDTH * 0.102083, //196,
            rows: 1
        },
    ],

    //// Thumbnail Styles
    thumbnails: [
        { // Thumbnail Template of My Apps
            visibleStyles: (0x01 | // CommonDefines.Const.THUMB_STYLE_IMAGE
                0x20), // CommonDefines.Const.THUMB_STYLE_INFO
            image: {
                x: 0,
                y: 0,
                width: DIMMESION_WIDTH * 0.132812,
                height: SCREEN_HEIGHT * 0.196296,
                src: '',
                async: true,
                fillMode: 'stretch'
            },

            progressBar: {
                x: DIMMESION_WIDTH * 0.009375,
                y: SCREEN_HEIGHT * 0.196296,
                width: DIMMESION_WIDTH * 0.114062,
                height: 2,
                backgroundColor: Volt.hexToRgb('#ffffff', 40),
                progressColor: Volt.hexToRgb('#ffffff', 100),
                normalThumbSrc: '',
                focusThumbSrc: '',
                thumbWidth: DIMMESION_WIDTH * 0.004167,
                thumbHeight: SCREEN_HEIGHT * 0.009259,
                slidable: false
            },
            information: {
                x: 0,
                y: SCREEN_HEIGHT * 0.196296,
                width: DIMMESION_WIDTH * 0.1328125,
                height: SCREEN_HEIGHT * 0.07037,
                coverColor: Volt.hexToRgb('#000000', 8),
                setAsBackground: true,

                colorPickingRange: {
                    l: 0,
                    r: 100,
                    t: 80,
                    b: 100
                }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
                icon1: {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0,
                    src: '',
                    async: true
                },
                icon2: {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0,
                    src: '',
                    async: true
                },
                icon3: {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0,
                    src: '',
                    async: true
                },
                icon4: {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0,
                    src: '',
                    async: true
                },

                text1: {
                    x: DIMMESION_WIDTH * 0.010417,
                    y: 0,
                    width: DIMMESION_WIDTH * 0.111979,
                    height: SCREEN_HEIGHT * 0.07037,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 17px' : 'SamsungSmart_Light 26px',
                    singleLineMode: true,
                    horizontalAlignment: 'center',
                    verticalAlignment: 'center',
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },
                }
            },
            checkBox: {
                x: DIMMESION_WIDTH * 0.030208,
                y: SCREEN_HEIGHT * 0.069444,
                width: DIMMESION_WIDTH * 0.071875,
                height: SCREEN_HEIGHT * 0.127778,
                uncheckSrc: Volt.getRemoteUrl('images/1080/common/check/check_ms_tb.png'),
                checkedSrc: Volt.getRemoteUrl('images/1080/common/check/check_ms_tb.png'),
            },
        }, { // Thumbnail Template of what's new
            visibleStyles: (0x01 | // CommonDefines.Const.THUMB_STYLE_IMAGE
                0x20), // CommonDefines.Const.THUMB_STYLE_INFO
            coverColor: Volt.hexToRgb('#000000', 8),
            image: {
                //x: Volt.width * 0.013542,
                x: DIMMESION_WIDTH * 0.013542,
                y: Volt.height * 0.056481,
                //width: Volt.width * (0.196875 - 0.013542 * 2) /*328*/ ,
                width: DIMMESION_WIDTH * (0.196875 - 0.013542 * 2) /*328*/ ,
                height: Volt.height * (0.4 - 0.056481 - 0.030556 - 0.056481 - 0.087963) /*184*/ ,
                async: true,
                cropOverflow: false,
                pivot: {
                    x: 0.5,
                    y: 1
                },
            },
            progressBar: {
                //x: Volt.width * 0.013542,
                x: DIMMESION_WIDTH * 0.013542,
                y: Volt.height * 0.22778,
                //width: Volt.width * (0.196875 - 0.013542 * 2),
                width: DIMMESION_WIDTH * (0.196875 - 0.013542 * 2),
                height: 2,
                backgroundColor: Volt.hexToRgb('#ffffff', 40),
                progressColor: Volt.hexToRgb('#ffffff', 100),
                normalThumbSrc: '',
                focusThumbSrc: '',
                thumbWidth: 8,
                thumbHeight: 10,
            },
            information: {
                x: 0,
                y: Volt.height * (0.4 - 0.056481 - 0.087963) + 2 /*278*/ ,
                //width: Volt.width * 0.196875,
                width: DIMMESION_WIDTH * 0.196875,
                height: Volt.height * 0.14259,
                colorPickingRange: {
                    l: 0,
                    r: 100,
                    t: 80,
                    b: 100
                }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
                setAsBackground: true,
                pivot: {
                    x: 0.5,
                    y: 0
                },


                icon1: {
                    //x: Volt.width * 0.013542,
                    x: DIMMESION_WIDTH * 0.013542,
                    y: 0,
                    //width: Volt.width * 0.059896,
                    width: DIMMESION_WIDTH * 0.059896,
                    height: Volt.height * 0.087963, //115*95
                    src: '',
                    async: true
                },
                text1: {
                    //x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: 0,
                    //width: Volt.width * 0.101042,
                    width: DIMMESION_WIDTH * 0.101042,
                    height: Volt.height * 0.040741,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 19px' : 'SamsungSmart_Light 28px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },
                },
                text2: {
                    //x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: Volt.height * 0.040741,
                    //width: Volt.width * 0.101042,
                    width: DIMMESION_WIDTH * 0.101042,
                    height: Volt.height * 0.025926,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 13px' : 'SamsungSmart_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },

                },
                text3: {
                    //x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: Volt.height * (0.040741 + 0.025926),
                    //width: Volt.width * (0.101042 - 0.016667),
                    width: DIMMESION_WIDTH * (0.101042 - 0.016667),
                    height: Volt.height * 0.028926, //Volt.height*0.025926,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 13px' : 'SamsungSmart_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },

                },
                icon2: {
                    //x: Volt.width * (0.196875 - 0.014583 - 0.016667),
                    x: DIMMESION_WIDTH * (0.196875 - 0.014583 - 0.016667),
                    y: Volt.height * (0.040741 + 0.025926),
                    //width: Volt.width * 0.016667,
                    width: DIMMESION_WIDTH * 0.016667,
                    height: Volt.height * 0.02963,
                    src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                    async: true
                },

            }
        }, {// Thumbnail Template of pia
            visibleStyles: (0x40),
            scrollPlayer: {
                x: 0,
                y: 0,
                //width: Volt.width * 0.196875,
                width: DIMMESION_WIDTH * 0.196875,
                height: Volt.height * 0.4,
                duration: 1000,
                itemNumber: 1,
                mode: 'QUADRATIC-in',
                fillMode: 'fit',
                src1: Volt.getRemoteUrl('images/1080/common/PIA_15.jpg'),
                src2: Volt.getRemoteUrl('images/1080/common/PIA_15.jpg'),
                async: true,
            }
        }, { // Thumbnail Template of most popular
            visibleStyles: (0x01 | // CommonDefines.Const.THUMB_STYLE_IMAGE
                0x20), // CommonDefines.Const.THUMB_STYLE_INFO
            coverColor: Volt.hexToRgb('#000000', 8),
            image: {
                //x: Volt.width * 0.013542,
                x: DIMMESION_WIDTH * 0.013542,
                y: Volt.height * 0.056481,
                //width: Volt.width * (0.196875 - 0.013542 * 2),
                width: DIMMESION_WIDTH * (0.196875 - 0.013542 * 2),
                height: Volt.height * (0.4 - 0.056481 - 0.030556 - 0.056481 - 0.087963),
                src: '',
                async: true,
                cropOverflow: false,
                pivot: {
                    x: 0.5,
                    y: 1
                },

            },
            progressBar: {
                //x: Volt.width * 0.013542,
                x: DIMMESION_WIDTH * 0.013542,
                y: Volt.height * 0.22778,
                //width: Volt.width * (0.196875 - 0.013542 * 2),
                width: DIMMESION_WIDTH * (0.196875 - 0.013542 * 2),
                height: 2,
                backgroundColor: Volt.hexToRgb('#ffffff', 40),
                progressColor: Volt.hexToRgb('#ffffff', 100),
                normalThumbSrc: '',
                focusThumbSrc: '',
                thumbWidth: 8,
                thumbHeight: 10,
            },
            information: {
                x: 0,
                y: Volt.height * (0.4 - 0.056481 - 0.087963) + 2,
                //width: Volt.width * 0.196875,
                width: DIMMESION_WIDTH * 0.196875,
                height: Volt.height * 0.14259,
                colorPickingRange: {
                    l: 0,
                    r: 100,
                    t: 80,
                    b: 100
                }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
                setAsBackground: true,
                pivot: {
                    x: 0.5,
                    y: 0
                },


                icon1: {
                    //x: Volt.width * 0.013542,
                    x: DIMMESION_WIDTH * 0.013542,
                    y: 0,
                    //width: Volt.width * 0.059896,
                    width: DIMMESION_WIDTH * 0.059896,
                    height: Volt.height * 0.087963, //115*95
                    src: '',
                    async: true
                },
                text1: {
                    //x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: 0,
                    //width: Volt.width * 0.101042,
                    width: DIMMESION_WIDTH * 0.101042,
                    height: Volt.height * 0.040741,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 19px' : 'SamsungSmart_Light 28px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },
                },
                text2: {
                    //x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: Volt.height * (0.040741 + 0.025926),
                    //width: Volt.width * (0.101042 - 0.016667),
                    width: DIMMESION_WIDTH * (0.101042 - 0.016667),
                    height: Volt.height * 0.028926, //Volt.height*0.025926,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 13px' : 'SamsungSmart_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },
                },
                text3: {
                    //x: Volt.width * 0.082292,
                    x: DIMMESION_WIDTH * 0.082292,
                    y: Volt.height * 0.040741,
                    //width: Volt.width * 0.101042,
                    width: DIMMESION_WIDTH * 0.101042,
                    height: Volt.height * 0.028926,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 13px' : 'SamsungSmart_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },

                },
                /*for no ratings*/
                rating: {
                    //x: Volt.width * (0.196875 - 0.101042 - 0.013542),
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: Volt.height * 0.040741,
                    //width: Volt.width * 0.052083,
                    width: DIMMESION_WIDTH * 0.052083,
                    height: Volt.height * 0.025926,
                    onSrc: CommonFunctions.getRatingImage().ratingOnBuf,
                    onOpacity: 127,
                    halfSrc: CommonFunctions.getRatingImage().ratingHalfBuf,
                    halfOpacity: 127,
                    bgSrc: CommonFunctions.getRatingImage().ratingBgBuf,
                    bgOpacity: 51,
                    //offSrc:  Volt.getRemoteUrl('images/1080/common/apps_contents_star_bg.png'),         
                    //iconWidth: Volt.width * 0.010417,
                    iconWidth: DIMMESION_WIDTH * 0.010417,
                    iconHeight: Volt.height * 0.018518,
                    value: 5,
                    gap: 0
                },

                icon2: {
                    //x: Volt.width * (0.196875 - 0.014583 - 0.016667),
                    x: DIMMESION_WIDTH * (0.196875 - 0.014583 - 0.016667),
                    y: Volt.height * (0.040741 + 0.025926),
                    //width: Volt.width * 0.016667,
                    width: DIMMESION_WIDTH * 0.016667,
                    height: Volt.height * 0.02963,
                    src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                    async: true
                }
            }
        }, { // Thumbnail Template of category
            visibleStyles: (0x01 | // CommonDefines.Const.THUMB_STYLE_IMAGE
                0x20), // CommonDefines.Const.THUMB_STYLE_INFO
            coverColor: Volt.hexToRgb('#000000', 8),
            image: {
                x: DIMMESION_WIDTH * 0.013542,
                y: Volt.height * 0.056481,
                width: DIMMESION_WIDTH * (0.196875 - 0.013542 * 2) /*328*/ ,
                height: Volt.height * (0.4 - 0.056481 - 0.030556 - 0.056481 - 0.087963) /*184*/ ,
                async: true,
                cropOverflow: false,
                pivot: {
                    x: 0.5,
                    y: 1
                },
            },
            progressBar: {
                x: DIMMESION_WIDTH * 0.013542,
                y: Volt.height * 0.22778,
                width: DIMMESION_WIDTH * (0.196875 - 0.013542 * 2),
                height: 2,
                backgroundColor: Volt.hexToRgb('#ffffff', 40),
                progressColor: Volt.hexToRgb('#ffffff', 100),
                normalThumbSrc: '',
                focusThumbSrc: '',
                thumbWidth: 8,
                thumbHeight: 10,
            },
            information: {
                x: 0,
                y: Volt.height * (0.4 - 0.056481 - 0.087963) + 2 /*278*/ ,
                width: DIMMESION_WIDTH * 0.196875,
                height: Volt.height * 0.14259,
                colorPickingRange: {
                    l: 0,
                    r: 100,
                    t: 80,
                    b: 100
                }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
                setAsBackground: true,
                pivot: {
                    x: 0.5,
                    y: 0
                },


                icon2: {
                    x: DIMMESION_WIDTH * 0.013542,
                    y: 0,
                    width: DIMMESION_WIDTH * 0.059896,
                    height: Volt.height * 0.087963, //115*95
                    src: '',
                    async: true
                },
                text1: {
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: 0,
                    width: DIMMESION_WIDTH * 0.101042,
                    height: Volt.height * 0.040741,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 19px' : 'SamsungSmart_Light 28px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },
                },
                text2: {
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: Volt.height * 0.040741,
                    width: DIMMESION_WIDTH * 0.101042,
                    height: Volt.height * 0.025926,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 13px' : 'SamsungSmart_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },

                },
                text3: {
                    x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                    y: Volt.height * (0.040741 + 0.025926),
                    width: DIMMESION_WIDTH * (0.101042 - 0.016667),
                    height: Volt.height * 0.028926, //Volt.height*0.025926,
                    font: (Volt.APPS720P) ? 'SamsungSmart_Light 13px' : 'SamsungSmart_Light 20px',
                    singleLineMode: true,
                    horizontalAlignment: "left",
                    verticalAlignment: "center",
                    text: '',
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },

                },
                icon1: {
                    x: DIMMESION_WIDTH * (0.196875 - 0.014583 - 0.016667),
                    y: Volt.height * (0.040741 + 0.025926),
                    width: DIMMESION_WIDTH * 0.016667,
                    height: Volt.height * 0.02963,
                    src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                    async: true
                },
            }
        }, { // Thumbnail Template of Related Apps
            visibleStyles: (THUMB_VISIBLE_STYLE_IMAGE | THUMB_VISIBLE_STYLE_INFO), //  | 0x10 | 0x08),
            coverColor: Volt.hexToRgb('#000000', 8),
            image: { //// App Icon
                width: DIMMESION_WIDTH * 0.102083, //196,
                height: SCREEN_HEIGHT * 0.15, //162,
                async: true
            },
            progressBar: {
                x: DIMMESION_WIDTH * 0.010417, //20,
                y: SCREEN_HEIGHT * 0.15, //162,
                width: DIMMESION_WIDTH * 0.08125, //156,
                height: 2,
                backgroundColor: Volt.hexToRgb('#ffffff', 40),
                progressColor: Volt.hexToRgb('#ffffff', 100),
                normalThumbSrc: '',
                focusThumbSrc: '',
                thumbWidth: 2,
                thumbHeight: 2,

                slidable: false
            },
            information: {
                x: 0,
                y: SCREEN_HEIGHT * 0.15, //162,
                width: DIMMESION_WIDTH * 0.102083, //196,
                height: SCREEN_HEIGHT * 0.05463, //59,
                colorPickingRange: {
                    l: 0,
                    r: 100,
                    t: 80,
                    b: 100
                }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom
                text1: { //// App Title
                    x: DIMMESION_WIDTH * 0.010417,
                    y: SCREEN_HEIGHT * 0.009259,
                    width: DIMMESION_WIDTH * (0.081249) - wUpdateIcon,
                    height: SCREEN_HEIGHT * 0.037037,
                    font: Volt.getMultiResParam('SamsungSmart_Light 17px', 'SamsungSmart_Light 26px'),
                    singleLineMode: true,
                    opacity: 255 * 0.6,
                    horizontalAlignment: "center",
                    verticalAlignment: "center",
                    ellipsize: true,
                    enlarge: {
                        factor: 1.5,
                        //anchorPoint: "center",
                    },
                },
                icon1: { //// Update Icon
                    x: DIMMESION_WIDTH * (0.102083 - 0.010417) - wUpdateIcon, //196 - 32 - 9,
                    y: SCREEN_HEIGHT * 0.012963, //14,
                    width: wUpdateIcon, //32,
                    height: wUpdateIcon, //32,
                    src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                    async: true
                }
            },
        }, {// Thumbnail Template of screen shot
            visibleStyles: (0x01 | 0x20),
            image: {
                width: DIMMESION_WIDTH * 0.155730,
                height: SCREEN_HEIGHT * 0.154630,
                async: true
            },
        }
    ],

    defaultScreenShot: Volt.getMultiResImage('common/apps_screenshot_default.png'),
};

exports = GridListTemplate;



/*
    var gridHeight = SCREEN_HEIGHT * 0.8,

    //
    generalThumbWidth = DIMMESION_WIDTH * 0.196875,
    generalThumbHeight = SCREEN_HEIGHT * 0.4,
    generalImageWidth = Volt.getMultiResParam(217, 328),
    generalImageHeight = Volt.getMultiResParam(122, 184),
    generalPaddingX = DIMMESION_WIDTH * 0.013542,
    generalPaddingY = DIMMESION_WIDTH * 0.56481,
    generalIconWidth = Volt.getMultiResParam(115, 77),
    generalIconWidth = Volt.getMultiResParam(95, 63);
    
    
    // Grid
    general_grid: {
        type: 'GridListControl',
        width: DIMMESION_WIDTH,
        height: gridHeight,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: 0,
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        itemHeight: generalThumbWidth,
        itemWidth: generalThumbHeight,
        rows: 2,
        custom: {
            focusable: true
        }
    },

    // Template for General Apps Item: What's New and Categories
    general_thumbnail: { // Style General
        type: 'Thumbnail',
        visibleStyles: (THUMB_VISIBLE_STYLE_IMAGE | THUMB_VISIBLE_STYLE_INFO),
        width: generalThumbWidth,
        height: generalThumbHeight,

        image: {
            x: generalPaddingX,
            y: generalPaddingY,
            width: generalImageWidth, // 328
            height: generalImageHeight,// 184
            async: true,
            defaultSrc: Volt.getMultiResImage('icon/icon_blank_thumbnail.png'),
        },

        progressBar: {
            x: DIMMESION_WIDTH * 0.013542,
            y: SCREEN_HEIGHT * 0.22778,
            width: DIMMESION_WIDTH * (0.196875 - 0.013542 * 2),
            height: 2,
            backgroundColor: Volt.hexToRgb('#ffffff', 40),
            progressColor: Volt.hexToRgb('#ffffff', 100),
            normalThumbSrc: '',
            focusThumbSrc: '',
            thumbWidth: 8,
            thumbHeight: 10,
        },

        information: {
            x: generalPaddingX,
            y: generalPaddingY + generalImageHeight + SCREEN_HEIGHT * 0.030556//278 ,
            width: generalThumbWidth - generalPaddingX,
            height: SCREEN_HEIGHT * 0.14259,
            
            colorPickingRange: {
                l: 0,
                r: 100,
                t: 80,
                b: 100
            }, // Left to Right: 0 -100, Top to Bottom: 80 - 100, means 20% from bottom

            icon1: {    // App Icon
                x: 0,
                y: 0,
                width: generalIconWidth,
                height: generalIconHeight, //115*95
                //src: '',
                async: true
            },
            
            text1: {    // Title
                x: generalIconWidth + DIMMESION_WIDTH * 0.008854,
                y: 0,
                width: DIMMESION_WIDTH * 0.101042,
                height: SCREEN_HEIGHT * 0.035185,
                font: Volt.getMultiResParam('SamsungSmart_Light 18px', 'SamsungSmart_Light 28px'),
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },
            },
            
            text2: {    // Date
                x: generalIconWidth + DIMMESION_WIDTH * 0.008854,
                y: SCREEN_HEIGHT * 0.040741,
                width: DIMMESION_WIDTH * 0.101042,
                height: SCREEN_HEIGHT * 0.025926,
                font: Volt.getMultiResParam('SamsungSmart_Light 13px', 'SamsungSmart_Light 20px'),
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },

            },
            text3: { // Volume
                x: DIMMESION_WIDTH * (0.196875 - 0.101042 - 0.013542),
                y: SCREEN_HEIGHT * (0.040741 + 0.025926),
                width: DIMMESION_WIDTH * (0.101042 - 0.016667),
                height: SCREEN_HEIGHT * 0.028926, //SCREEN_HEIGHT*0.025926,
                font: CommonTemplate.getParam('SamsungSmart_Light 13px' : 'SamsungSmart_Light 20px'),
                singleLineMode: true,
                horizontalAlignment: "left",
                verticalAlignment: "center",
                text: '',
                enlarge: {
                    factor: 1.5,
                    //anchorPoint: "center",
                },

            },
            icon2: {    // Downloaded
                x: DIMMESION_WIDTH * (0.196875 - 0.014583 - 0.016667),
                y: SCREEN_HEIGHT * (0.040741 + 0.025926),
                width: DIMMESION_WIDTH * 0.016667,
                height: SCREEN_HEIGHT * 0.02963,
                src: Volt.getRemoteUrl('images/1080/common/icon_downloaded.png'),
                async: true
            },
        }
    },

    progressbar: {
        x: DIMMESION_WIDTH * 0.013542,
        y: SCREEN_HEIGHT * 0.22778,
        width: DIMMESION_WIDTH * 0.17083,
        height: 2,
        percentage: 0
    },
 */