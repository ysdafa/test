var CommonTemplate = Volt.requireTemplate('common'),
    SCREEN_WIDTH = Volt.width,
    SCREEN_HEIGHT = Volt.height,
    DIMMESION_WIDTH = Volt.dimmensionWidth,

    titleHeight = SCREEN_HEIGHT * 0.133334,

    titleButtonWidth = DIMMESION_WIDTH * 0.052083,
    titleButtonHeight = titleHeight,
    titleButtonIconWidth = Volt.getMultiResParam(24, 36),

    btnMoreWidth = Volt.getMultiResParam(27, 40),

    thumbWidth = DIMMESION_WIDTH * 0.266667,
    thumbHeight = SCREEN_HEIGHT * 0.391667,

    thumbAreaX = DIMMESION_WIDTH * 0.020834,
    thumbAreaHeight = thumbHeight + SCREEN_HEIGHT * (0.013889 + 0.018519 * 2),

    textX = thumbAreaX + thumbWidth + DIMMESION_WIDTH * 0.021875,
    textWidth = DIMMESION_WIDTH * (0.643750 + 0.007292) + btnMoreWidth,

    appInfoY = titleHeight + SCREEN_HEIGHT * 0.022223,
    appInfoHeight = SCREEN_HEIGHT * (0.043591 + 0.040741 + 0.070371 + 0.040741),

    descY = appInfoY + appInfoHeight,
    descHeight = SCREEN_HEIGHT * 0.040741 * 2,

    shotY = descY + descHeight + SCREEN_HEIGHT * 0.012963,
    shotWidth = DIMMESION_WIDTH * (0.160417 * 3 + 0.155730),

    shotItemHeight = SCREEN_HEIGHT * 0.154630,
    shotItemWidth = DIMMESION_WIDTH * 0.155730,

    buttonWidth = DIMMESION_WIDTH * 0.213542,
    buttonHeight = SCREEN_HEIGHT * 0.058334,

    buttonsY = shotY + shotItemHeight + SCREEN_HEIGHT * 0.025926,
    buttonsWidth = DIMMESION_WIDTH * 0.229167 * 2 + buttonWidth,

    iconWidth = Volt.getMultiResParam(24, 36),
    starWidth = Volt.getMultiResParam(32, 32);

var detailViewTemplate = {

    screenShotGap: 320,
    normalDescription: 38 * 3,
    moreDescription: 410,
    buttonGap: 440,

    dim: {
        id: 'detail-dim',
        type: 'widget',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH,
        height: SCREEN_HEIGHT,
        color: Volt.hexToRgb('#000000'),
        opacity: Volt.getPercentage(80)
    },

    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: SCREEN_WIDTH,
        height: SCREEN_HEIGHT,
        color: Volt.hexToRgb('#233146', 0),
        children: [
            {
                type: 'WinsetBackground',
                id: 'detail-background-colorpick',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH,
                height: SCREEN_HEIGHT,
                style: '{{highconstract}}',
                bgColor: Volt.hexToRgb('#233146'),
                bgHighContrastColor: Volt.hexToRgb('#000000', 100),
            }, {
                type: 'WinsetBackground',
                id: 'detail-title-area',
                x: 0,
                y: 0,
                width: SCREEN_WIDTH,
                height: titleHeight,
                style: '{{highconstract}}',
                bgColor: Volt.hexToRgb('#1f2b3d', 0),
                bgHighContrastColor: Volt.hexToRgb('#ffffff', 0),
            }, { // Center of detail page
                type: 'widget',
                x: (SCREEN_WIDTH - DIMMESION_WIDTH) / 2,
                y: 0,
                width: DIMMESION_WIDTH,
                height: SCREEN_HEIGHT,
                color: CommonTemplate.COLOR_TRANSPARENCY,
                children: [
                    {
                        type: 'widget',
                        id: 'detail-thumb-area',
                        x: thumbAreaX,
                        y: titleHeight,
                        width: thumbWidth,
                        height: thumbAreaHeight,
                        color: CommonTemplate.COLOR_TRANSPARENCY,
                    }, {
                        type: 'widget',
                        id: 'detail-appInfo-area',
                        x: textX,
                        y: appInfoY,
                        width: textWidth,
                        height: appInfoHeight,
                        color: CommonTemplate.COLOR_TRANSPARENCY,
                    }, {
                        type: 'widget',
                        id: 'detail-description-area',
                        x: textX,
                        y: descY,
                        width: textWidth,
                        height: descHeight,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                    }, {
                        id: 'detail-screenshot-area',
                        type: 'widget',
                        x: textX,
                        y: shotY,
                        width: shotWidth,
                        height: shotItemHeight,
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                    }, {
                        type: 'widget',
                        x: textX,
                        y: buttonsY,
                        width: buttonsWidth,
                        height: buttonHeight,
                        id: 'detail-button-area',
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                    }, {
                        type: 'widget',
                        x: thumbAreaX,
                        y: titleHeight + thumbAreaHeight + 0.020371 * SCREEN_HEIGHT,
                        width: DIMMESION_WIDTH * (0.087500 * 2 + 0.005209),
                        height: SCREEN_HEIGHT * (0.037963 + 0.027778 * 2),
                        id: 'detail-storage-area',
                        color: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 0
                        },
                    },
                ],
            }, {
                type: 'widget',
                x: 0,
                y: SCREEN_HEIGHT * (1 - 0.20463 - 0.043519),
                width: SCREEN_WIDTH,
                height: SCREEN_HEIGHT * (0.20463 + 0.043519),
                id: 'detail-list-area',
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                children: [
                    {
                        type: 'WinsetBackground',
                        id: 'detail-background-list',
                        x: 0,
                        y: SCREEN_HEIGHT * 0.043519,
                        width: SCREEN_WIDTH,
                        height: SCREEN_HEIGHT * 0.20463,
                        style: '{{highconstract}}',
                        bgColor: Volt.hexToRgb('#1f2b3d', 0),
                        bgHighContrastColor: Volt.hexToRgb('#ffffff', 0),
                    }
                ]
            }
        ]
    },

    title: [
        {
            type: 'text',
            x: 0,
            y: 0,
            width: SCREEN_WIDTH,
            height: titleHeight,
            font: Volt.getMultiResParam('44px', '66px'),
            text: '{{title}}',
            textColor: Volt.hexToRgb('#ffffff', 100),
            horizontalAlignment: "center",
            verticalAlignment: "center"
        }, {
            id: 'detail-return-button',
            type: 'Button',
            x: 0,
            y: 0,
            width: titleButtonWidth,
            height: titleButtonHeight,
            color: CommonTemplate.COLOR_TRANSPARENCY,
            icon: {
                x: (titleButtonWidth - titleButtonIconWidth) / 2,
                y: (titleButtonHeight - titleButtonIconWidth) / 2,
                width: titleButtonIconWidth,
                height: titleButtonIconWidth,
                src: Volt.getMultiResImage('icon/comn_icon_tm_return.png'),
                opacity: 255 * 0.6
            },
            custom: {
                cmStyle: 'TITLE_LEFT'
            }
        }, {
            id: 'detail-exit-button',
            type: 'Button',
            x: SCREEN_WIDTH - titleButtonWidth,
            y: 0,
            width: titleButtonWidth,
            height: titleButtonHeight,
            color: CommonTemplate.COLOR_TRANSPARENCY,
            icon: {
                x: (titleButtonWidth - titleButtonIconWidth) / 2,
                y: (titleButtonHeight - titleButtonIconWidth) / 2,
                width: titleButtonIconWidth,
                height: titleButtonIconWidth,
                src: Volt.getMultiResImage('common/comn_icon_tm_close_nor.png'),
                opacity: 255 * 0.6
            },
            custom: {
                cmStyle: 'TITLE_RIGHT'
            }
        }
    ],

    ThumbArea: {
        type: 'widget',
        x: 0,
        y: 0,
        width: thumbWidth,
        height: thumbAreaHeight,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'image',
                id: 'thumb-area',
                x: 0,
                y: 0,
                width: thumbWidth,
                height: thumbHeight,
                src: '{{ thumbnail }}',
                fillMode: 'center',
            }, {
                type: 'text',
                x: 0,
                y: thumbHeight,
                width: thumbWidth,
                height: thumbAreaHeight - thumbHeight,
                font: Volt.getMultiResParam('9px', '13px'),
                text: Volt.i18n.t('TV_SID_SAMSUNG_ELECTRONICS_PLAY_ROLE_INTERMEDIARY_REGISTERED'),
                textColor: Volt.hexToRgb('#ffffff', 100),
                horizontalAlignment: "left",
                verticalAlignment: "center",
            }
        ]
    },

    appInfo: {
        type: 'widget',
        x: 0,
        y: 0,
        width: textWidth,
        height: appInfoHeight,
        color: CommonTemplate.COLOR_TRANSPARENCY,
        children: [
            {
                type: 'text',
                id: 'detail-description-firstLine1',
                x: 0,
                y: 0,
                height: SCREEN_HEIGHT * 0.043519,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: '{{category}}',
                font: Volt.getMultiResParam('21px', '32px'),
                //singleLineMode: true,
            },
            {
                type: 'text',
                id: 'detail-description-firstLine2',
                y: SCREEN_HEIGHT * 0.002778,
                height: SCREEN_HEIGHT * 0.043519,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: '{{avgRating}}   ',
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
            },            
            {
                type: 'text',
                id: 'detail-description-secondLine1',
                x: 0,
                y: SCREEN_HEIGHT * 0.043519,
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('SID_FREE_M_FREE'),
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
            },
            {
                type: 'widget',
                id: 'detail-description-secondLine_bar1',
                y: SCREEN_HEIGHT * 0.043519 + SCREEN_HEIGHT * 0.011111,
                width: DIMMESION_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519,
                color: Volt.hexToRgb('#ffffff', 20),
            },
            {
                type: 'text',
                id: 'detail-description-secondLine2',
                y: SCREEN_HEIGHT * 0.043519,
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('SID_RATED') + ': ',
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
            },
            {
                type: 'image',
                id: 'detail-description-secondLineIcon',
                y: SCREEN_HEIGHT * (0.043519 + 0.008333),
                width: 26,
                height: 26,
                fillMode: 'fit',
            },
            {
                type: 'text',
                id: 'detail-description-secondLine3',
                y: SCREEN_HEIGHT * 0.043519,
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: "{{rated}} ",
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
            },
            {
                type: 'widget',
                id: 'detail-description-secondLine_bar2',
                y: SCREEN_HEIGHT * 0.043519 + SCREEN_HEIGHT * 0.011111,
                width: DIMMESION_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519,
                color: Volt.hexToRgb('#ffffff', 20),
            },
            {
                type: 'text',
                id: 'detail-description-secondLine4',
                y: SCREEN_HEIGHT * 0.043519,
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('COM_BDP_SID_HTS_SPKR_SIZE_TEXT') + ": {{size}}",
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
            },
            {
                type: 'widget',
                id: 'detail-description-secondLine_bar3',
                y: SCREEN_HEIGHT * 0.043519 + SCREEN_HEIGHT * 0.011111,
                width: DIMMESION_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519,
                color: Volt.hexToRgb('#ffffff', 20),
            },
            {
                type: 'text',
                id: 'detail-description-secondLine5',
                y: SCREEN_HEIGHT * 0.043519,
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('COM_SID_UPDATED') + " {{updated}}",
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
            },
            {
                type: 'text',
                id: 'detail-description-thirdLine1',
                x: 0,
                y: SCREEN_HEIGHT * (0.043519 + 0.040741),
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('TV_SID_LASTEST_VERSION') + ': {{version}} {{installed}}',
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
            },
            {
                type: 'widget',
                id: 'detail-description-thirdLine_bar1',
                y: SCREEN_HEIGHT * (0.043519 + 0.040741) + SCREEN_HEIGHT * 0.011111,
                width: DIMMESION_WIDTH * 0.000521,
                height: SCREEN_HEIGHT * 0.018519,
                color: Volt.hexToRgb('#ffffff', 20),
            },
            {
                type: 'text',
                id: 'detail-description-thirdLine2',
                y: SCREEN_HEIGHT * (0.043519 + 0.040741),
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('SID_LANGUAGES_KR_SUPPORT') + ': ',
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
             },
            {
                type: 'text',
                id: 'detail-description-thirdLine3',
                y: SCREEN_HEIGHT * (0.043519 + 0.040741),
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: '{{language}}',
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
         },
         {
                type: 'text',
                id: 'detail-description-forthLine1',
                x:0,
                y: SCREEN_HEIGHT * (0.043519 + 0.040741+0.040741),
                height: SCREEN_HEIGHT * 0.040741,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                text: Volt.i18n.t('COM_SID_CONTROLLERS') + ': ',
                font: Volt.getMultiResParam('17px', '26px'),
                //singleLineMode: true,
         },
        {
            type: 'image',
            id: 'detail-description-forthLineIcon1',
            y: SCREEN_HEIGHT * (0.043519 + 0.040741+0.040741),
            width: Volt.getMultiResParam(29, 44),
            height: Volt.getMultiResParam(29, 44),
            fillMode: 'fit',
        },
        {
            type: 'text',
            id: 'detail-description-forthLine2',
            y: SCREEN_HEIGHT * (0.043519 + 0.040741+0.040741),
            height: SCREEN_HEIGHT * 0.040741,
            horizontalAlignment: 'left',
            verticalAlignment: 'center',
            textColor: Volt.hexToRgb('#ffffff', 100),
            ellipsize: true,
            font: Volt.getMultiResParam('17px', '26px'),
            //singleLineMode: true,
        },
        {
            type: 'widget',
            id: 'detail-description-forthLine_bar1',
            y: SCREEN_HEIGHT * (0.043519 + 0.040741+0.040741) + SCREEN_HEIGHT * 0.011111,
            width: DIMMESION_WIDTH * 0.000521,
            height: SCREEN_HEIGHT * 0.018519,
            color: Volt.hexToRgb('#ffffff', 0),
        },
        {
            type: 'image',
            id: 'detail-description-forthLineIcon2',
            y: SCREEN_HEIGHT * (0.043519 + 0.040741+0.040741),
            width: Volt.getMultiResParam(29, 44),
            height: Volt.getMultiResParam(29, 44),
            fillMode: 'fit',
        },
       {
            type: 'text',
            id: 'detail-description-forthLine3',
            y: SCREEN_HEIGHT * (0.043519 + 0.040741+0.040741),
            height: SCREEN_HEIGHT * 0.040741,
            horizontalAlignment: 'left',
            verticalAlignment: 'center',
            textColor: Volt.hexToRgb('#ffffff', 100),
            ellipsize: true,
            font: Volt.getMultiResParam('17px', '26px'),
            //singleLineMode: true,
        },        

        ]
    },

    descriptionOneLineHeight: SCREEN_HEIGHT * 0.040741,
    descriptionLineHeight: SCREEN_HEIGHT * 0.040741 * 2,
    descriptionMaxLineHight: SCREEN_HEIGHT * 0.040741 * 12,

    description: {
        type: 'widget',
        x: 0,
        y: 0,
        width: DIMMESION_WIDTH * 0.643750,
        height: SCREEN_HEIGHT * (0.040741 * 12 + 0.029630 * 2),
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'widget',
                id: 'detail-description-text-container',
                x: 0,
                y: 0,
                width: DIMMESION_WIDTH * 0.643750,
                height: SCREEN_HEIGHT * 0.040741 * 12,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                cropOverflow: true,
                children: [
                    {
                        type: 'text',
                        id: 'detail-description-text',
                        x: 0,
                        y: 0,
                        width: DIMMESION_WIDTH * 0.643750,
                        horizontalAlignment: 'left',
                        textColor: Volt.hexToRgb('#ffffff', 100),
                        text: '{{description}}',
                        font: Volt.getMultiResParam('20px', '30px'),
                    }
                ]
            }, {
                type: 'image',
                id: 'detail-description-up-arrow',
                x: 0,
                y: -SCREEN_HEIGHT * 0.029630,
                width: DIMMESION_WIDTH * 0.643750,
                height: SCREEN_HEIGHT * 0.029630,
                opacity: 153,
                rotation: {
                    x: 0,
                    y: Volt.APPS_REVERSE ? 180 : 0,
                    z: 0
                },
                src: Volt.getRemoteUrl('images/1080/common/apps_detail_arrow_u.png')
            }, {
                type: 'image',
                id: 'detail-description-down-arrow',
                x: 0,
                y: SCREEN_HEIGHT * 0.040741 * 12,
                width: DIMMESION_WIDTH * 0.643750,
                height: SCREEN_HEIGHT * 0.029630,
                opacity: 153,
                rotation: {
                    x: 0,
                    y: Volt.APPS_REVERSE ? 180 : 0,
                    z: 0
                },
                src: Volt.getRemoteUrl('images/1080/common/apps_detail_arrow_d.png')
            }, {
                type: 'widget',
                id: 'detail-more-button',
                x: DIMMESION_WIDTH * (0.643750 + 0.007292),
                y: SCREEN_HEIGHT * 0.040741,
                width: DIMMESION_WIDTH * 0.020833,
                height: SCREEN_HEIGHT * 0.037037,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                custom: {
                    'focusable': false
                }
            }, {
                type: 'widget',
                id: 'detail-close-button',
                x: DIMMESION_WIDTH * 0.228125,
                y: SCREEN_HEIGHT * (0.040741 * 12 + 0.060186),
                width: DIMMESION_WIDTH * 0.156771,
                height: SCREEN_HEIGHT * 0.060186,
                color: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 0
                },
                custom: {
                    'focusable': false
                }
            },
        ]
    },

    moreBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: 'moreBtn',
        x: 0,
        y: 0,
        width: btnMoreWidth,
        height: btnMoreWidth,
        iconWidth: DIMMESION_WIDTH * 0.011458,
        iconHeight: SCREEN_HEIGHT * 0.02037,
        iconImgSrc: Volt.getRemoteUrl("images/1080/common/btn_icon_more.png"),
    },

    closeBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "closeBtn",
        x: 0,
        y: 0,
        width: DIMMESION_WIDTH * 0.156771,
        height: SCREEN_HEIGHT * 0.060186,
        text: Volt.i18n.t('COM_SID_CLOSE'),
    },

    screenShotGridList: {
        x: 0,
        y: 0,
        width: shotWidth,
        height: shotItemHeight,
        titleSpace: 0,
        groupSpace: 0,
        cellSpace: DIMMESION_WIDTH * (0.160417 - 0.155730),
        focusRangeStartOffset: 0,
        focusRangeEndOffset: 0,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        itemHeight: shotItemHeight,
        itemWidth: shotItemWidth,
        rows: 1
    },
    buttonContainer: {
        type: 'widget',
        x: 0,
        y: 0,
        width: buttonsWidth,
        height: buttonHeight,
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                custom: {
                    'focusable': true
                },
                type: 'widget',
                id: 'download_button_widget',
                color: Volt.hexToRgb('#FFFFFF', 0),
                x: 0,
                y: 0,
                width: buttonWidth,
                height: buttonHeight,
            }, {
                custom: {
                    'focusable': true
                },
                type: 'widget',
                id: 'rating_button_widget',
                color: Volt.hexToRgb('#FFFFFF', 0),
                x: DIMMESION_WIDTH * 0.229167,
                y: 0,
                width: buttonWidth,
                height: buttonHeight,
            },
        ]
    },

    downloadBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "downloadBtn",
        x: 0,
        y: 0,
        width: buttonWidth,
        height: buttonHeight,
    },

    ratingBtn: {
        type: 'WinsetButton',
        style: '{{style}}',
        buttonType: '{{buttonType}}',
        resoultion: '{{resoultion}}',
        id: "ratingBtn",
        x: 0,
        y: 0,
        width: buttonWidth,
        height: buttonHeight,
        text: "",
    },

    contentStar: {
        type: 'image',
        x: 0,
        y: SCREEN_HEIGHT * 0.0125,
        width: Volt.getMultiResParam(13, 20),
        height: Volt.getMultiResParam(13, 20),
        src: '{{imageUrl}}',
        fillMode: 'fit',
    },

    btnStar: {
        type: 'image',
        x: 0,
        y: SCREEN_HEIGHT * 0.014815,
        width: starWidth,
        height: starWidth,
    },

    storage: {
        type: 'widget',
        x: 0,
        y: 0,
        width: DIMMESION_WIDTH * 0.180209,
        height: SCREEN_HEIGHT * (0.037963 + 0.027778 * 2),
        color: {
            r: 0,
            g: 0,
            b: 0,
            a: 0
        },
        children: [
            {
                type: 'widget',
                id: 'storage-info-progress-bg',
                x: 0,
                y: SCREEN_HEIGHT * 0.031482,
                width: DIMMESION_WIDTH * 0.180209,
                height: SCREEN_HEIGHT * 0.001852,
                color: Volt.hexToRgb('#ffffff', 0)
            },
            {
                type: 'text',
                id: 'storage-info-text-all',
                x: 0,
                y: 0,
                width: DIMMESION_WIDTH * 0.180209,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: Volt.APPS_REVERSE ? 'right' : 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: (Volt.APPS720P) ? "SamsungSmart_Medium 13px" : "SamsungSmart_Medium 20px",
                //singleLineMode: true,
                text: Volt.i18n.t('TV_SID_INTERNAL_MEMORY_INFO'),
            }, {
                type: 'text',
                id: 'storage-info-text-all-value',
                x: 0,
                y: 0,
                width: DIMMESION_WIDTH * 0.180209,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
                //singleLineMode: true,
            }, {
                type: 'text',
                id: 'storage-info-text-used',
                x: 0,
                y: SCREEN_HEIGHT * 0.037963,
                width: DIMMESION_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
                text: Volt.i18n.t('COM_SID_USED_KR_ING'),
            }, {
                type: 'text',
                id: 'storage-info-text-available',
                x: DIMMESION_WIDTH * (0.087500 + 0.005209),
                y: SCREEN_HEIGHT * 0.037963,
                width: DIMMESION_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: 'right',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
                text: Volt.i18n.t('TV_SID_AVAILABLE_EMPTY'),
            }, {
                type: 'text',
                id: 'storage-info-text-used-value',
                x: 0,
                y: SCREEN_HEIGHT * (0.037963 + 0.027778),
                width: DIMMESION_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: 'left',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
            }, {
                type: 'text',
                id: 'storage-info-text-available-value',
                x: DIMMESION_WIDTH * (0.087500 + 0.005209),
                y: SCREEN_HEIGHT * (0.037963 + 0.027778),
                width: DIMMESION_WIDTH * 0.087500,
                height: SCREEN_HEIGHT * 0.027778,
                horizontalAlignment: 'right',
                verticalAlignment: 'center',
                textColor: Volt.hexToRgb('#ffffff', 100),
                ellipsize: true,
                font: Volt.getMultiResParam('13px', '20px'),
            }
        ]
    },

    downloadGuideText: {
        type: 'text',
        x: 0,
        y: SCREEN_HEIGHT * (0.058334 + 0.010186 + 0.001852 + 0.005556),
        width: DIMMESION_WIDTH * 0.643750,
        height: SCREEN_HEIGHT * 0.036112,
        horizontalAlignment: 'left',
        verticalAlignment: 'top',
        font: Volt.getMultiResParam('13px', '20px'),
        textColor: Volt.hexToRgb('#ffffff', 100),
        opacity: Volt.getPercentage(100),
        text: Volt.i18n.t('COM_SID_INTERNAL_MEMORY_LOW_USB_INSTALL')
    },

    relatedText: {
        type: 'text',
        x: DIMMESION_WIDTH * 0.013542,
        y: 0,
        //width: SCREEN_WIDTH * (1 - 0.013542),
        width: SCREEN_WIDTH - 2 * 0.013542 * DIMMESION_WIDTH,
        height: SCREEN_HEIGHT * 0.037037,
        font: (Volt.APPS720P) ? "SamsungSmart_Medium 17px" : "SamsungSmart_Medium 26px",
        text: Volt.i18n.t('TV_SID_USER_THIS_APP_DOWNLOADED'),
        textColor: Volt.hexToRgb('#ffffff', 100),
        horizontalAlignment: "left",
        verticalAlignment: "center"
    },

    storageProgressBar: {
        type: 'WinsetProgress',
        x: 0,
        y: 0,
        width: DIMMESION_WIDTH * 0.180209,
        height: 2,
        nProgressStyle: '{{nProgressStyle}}',
        nResoultionStyle: '{{nResoultionStyle}}'
    },

    toolTip: {
        type: 'WinsetToolTip',
        x: '{{x}}',
        y: '{{y}}',
        width: '{{w}}',
        height: 62,
        style: '{{style}}',
        nResoultionStyle: '{{nResoultionStyle}}',
        text: '{{text}}',
        tailPostion: '{{tailPostion}}',
        parent: scene
    },

    loading: {
        type: 'WinsetLoading',
        x: (Volt.width - Volt.width * 0.156771) / 2,
        y: Volt.height * 0.521296,
        style: '{{style20}}',
        nResoultionStyle: '{{nResoultionStyle}}',
        text: Volt.i18n.t('COM_SID_LOADING_DOT')
    },
};

exports = detailViewTemplate;