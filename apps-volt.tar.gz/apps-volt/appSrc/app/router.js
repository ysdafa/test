 /** 
  * @author donghyun Lee (donghyun81.lee@samsung.com)
  * @fileoverview This module manages backbone router of app.
  * @date    2014/07/23 (last modified date)
  *
  * Copyright 2014 by Samsung Electronics, Inc.,
  *
  * This software is the confidential and proprietary information
  * of Samsung Electronics, Inc. ("Confidential Information").  You
  * shall not disclose such Confidential Information and shall use
  * it only in accordance with the terms of the license agreement
  * you entered into with Samsung.
  */

 var Backbone = Volt.require('lib/volt-backbone.js');
 var RouterController = Volt.require('app/controllers/router-controller.js');

 /**
  * @name Router
  */
 var Router = Backbone.Router.extend({
     /** @lends Router.prototype */

     /**
      * Initialize Router
      * @name Router
      * @constructs
      */
     initialize: function () {
         Backbone.history.hashstack = [];
         this.on('route', function () {
             Volt.log('[router.js] URL : ' + Backbone.history.location.hash);
             Backbone.history.hashstack.push(Backbone.history.location.hash);
         });
     },

     /**
      * Routes
      * @type {object}
      */
     routes: {
         'main': 'main',
         'myapps': 'myapps',
         'mostpopular': 'mostpopular',
         'events': 'events',
         'whatsnew': 'whatsnew',
         'categories': 'categories',
         'categoriesList/:id/:name': 'categoriesList',
         'detail/:id': 'detail',
         'detail/:id/:caller': 'intoDetail',
         'detail/popup/rating/:id/:num': "ratingPopup",
         'detail/popup/screenShot/:idx': 'screenShotPopup',
         'popup/usbList/:param': 'usbListPopup',
         'popup/lowmemory/:param': 'lowmemorypopup',
         'popup/updateAppsList': 'updateAppsPopup',
         "commonpopup/:param": "commonpopup",
         'whatsnew/smartHubPopupView': 'smartHubPopupView',
     },

     main: function () {
         RouterController.root('home-view');
     },

     myapps: function () {
         Volt.log('[Router] myapps()');
         RouterController.root('home-view', {
             view: 'myAppsView'
         }).sub('myAppsView');
         Volt.KpiMapper.enterPage('M01_MYAPPS');
     },

     /**
      * Routes to events view
      * @method
      */
     events: function () {
         Volt.log('[Router] events()');
         RouterController.root('home-view').sub('eventView');
         Volt.KpiMapper.enterPage('E01_EVENT');
     },
     /**
      * Routes to events view
      * @method
      */
     smartHubPopupView: function () {
         Volt.log('[Router] smartHubPopupView()');
         RouterController.popup('smartHubPopupView');
     },
     /**
      * Routes to mostpopular view
      * @method
      */
     mostpopular: function () {
         Volt.log('[Router] mostpopular()');
         RouterController.root('home-view').sub('mostPopularView');
         Volt.KpiMapper.enterPage('M01_MOST');
     },

     /**
      * Routes to whatsnew view
      * @method
      */
     whatsnew: function () {
         Volt.log('[Router] whatsnew()');
         RouterController.root('home-view').sub('whatsNewView');
         Volt.KpiMapper.enterPage('N01_NEW');
     },

     /**
      * Routes to categories view
      * @method
      */
     categories: function () {
         Volt.log('[Router] categories()');
         RouterController.root('home-view').sub('categoriesView');
         Volt.KpiMapper.enterPage('C01_CATEGORY');
     },

     /**
      * Routes to categoriesList view
      * @method
      * @param {string} id Category Id
      * @param {string} title Category title
      */
     categoriesList: function (id, title) {
         Volt.log('[router] categoriesList :: ' + id + ', ' + title);
         //RouterController.root('home-view', 'categoriesListView').categories('categoriesListView', id, {
         RouterController.root('home-view', {
             view: 'categoriesListView'
         }).categories('categoriesListView', id, {
             id: id,
             title: title
         });
         //        RouterController.root('home-view', 'categoriesListView').sub('categoriesListView', {id: id, title: title});

         var nRemain = id % 11;

         switch (nRemain) {
         case 5:
             Volt.KpiMapper.enterPage('C02_VIDEO');
             break;
         case 6:
             Volt.KpiMapper.enterPage('C02_SPORT');
             break;
         case 7:
             Volt.KpiMapper.enterPage('C02_GAME');
             break;
         case 8:
             Volt.KpiMapper.enterPage('C02_LIFE');
             break;
         case 9:
             Volt.KpiMapper.enterPage('C02_INFO');
             break;
         case 10:
             Volt.KpiMapper.enterPage('C02_EDU');
             break;
         case 0:
             Volt.KpiMapper.enterPage('C02_KIDS');
             break;

         default:
             Volt.KpiMapper.enterPage('C02_ALL');
             break;
         }

     },

     /**
      * Routes to detail view
      * @method
      * @param {string} id Category Id
      */
     detail: function (appID) {
         Volt.log('[router] detail :: ' + appID);
         //RouterController.detail('detailView', {id: appID});
         RouterController.detail('detail-view', {
             id: appID
         });
         Volt.KpiMapper.enterPage('D03_DETAIL', {
             appid: appID
         });
     },

     intoDetail: function (appID, caller) {
         Volt.log('[router] intoDetail :: ' + appID);
         RouterController.detail('detail-view', {
             id: appID,
             caller: caller
         });
         Volt.KpiMapper.enterPage('D03_DETAIL', {
             appid: appID
         });
     },

     /**
      * Routes to screenShotPopup view
      * @method
      * @param {int} idx Index of screen shot
      */
     screenShotPopup: function (idx) {
         Volt.log('[router] screenShot :: ' + idx);
         RouterController.popup('screenShotView', idx);
     },

     /**
      * Routes to ratingPopup view
      * @method
      * @param {int} num Rating number
      */
     ratingPopup: function (id, num) {
         Volt.log('[router] ratingPopoup :: ' + id + num);
         RouterController.popup('ratingView', {
             id: id,
             num: num
         });
     },

     /**
      * Routes to usbListPopup view
      * @method
      */
     usbListPopup: function (param) {
         Volt.log('[router] usbListPopup ::');
         RouterController.popup('usbListPopupView', param);
     },

     updateAppsPopup: function () {
         Volt.log('[router] updateListPopup ::');
         RouterController.popup('updateAppsView');
     },
     commonpopup: function (param) {
         Volt.log('[router] commonpopup ::');
         RouterController.popup('commonPopupView', param);
     },


     lowmemorypopup:function (param) {
         Volt.log('[router] lowmemorypopup ::');
         RouterController.popup('updateLowMemoryPopup', param);
     }
 });

 exports = new Router();