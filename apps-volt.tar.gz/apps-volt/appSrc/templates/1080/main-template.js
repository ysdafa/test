var MainTemplate = {
    container: {
        parent: scene,
        type: 'widget',
        x: 0,
        y: 0,
        width: Volt.width,
        height: Volt.height,
        color: Volt.hexToRgb('#f2f2f2'),
        children: [
/*            {
                id: 'main-title-area',
                type: 'widget',
                x: 0, y: 0, width: 1920, height: 144,
                color: Volt.hexToRgb('#0f1826')
            },
*/
            {
                id: 'main-header-container',
                type: 'widget',
                x: 0,
                y: 0,
                width: Volt.width,
                height: Volt.height * 0.133333,
                color: Volt.hexToRgb('#0f1826')
            }, {
                id: 'main-category-container',
                type: 'WinsetBackground',
                x: 0,
                y: Volt.height * 0.133333,
                width: Volt.width,
                height: Volt.height * 0.066667,
                bgColor: Volt.hexToRgb('#0f1826'),
                bgHighContrastColor: Volt.hexToRgb('#000000', 100),
            }, {
                id: 'main-category-underbar-container',
                type: 'widget',
                x: 0,
                y: Volt.height * 0.133333,
                width: Volt.width,
                height: 1,
                color: Volt.hexToRgb('#ffffff', 25)
            }, {
                id: 'main-underbar-container',
                type: 'widget',
                x: 0,
                y: 972,
                width: Volt.width,
                height: 108,
                color: Volt.hexToRgb('#0f1826')
            }, {
                id: 'main-content-container',
                type: 'widget',
                x: 0,
                y: Volt.height * 0.2,
                width: Volt.width,
                height: Volt.height * 0.8,
                color: Volt.hexToRgb('#dfdfdf')
            }
        ]
    }
};

exports = MainTemplate;
