/**
 * @author Common Module Team
 * @fileoverview Common Template for Panel Dev.
 * @date 2014/11/19
 *
 * @version 2.0
 *
 * @copyright Copyright 2014 by Samsung Electronics, Inc.,
 * <p>This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

var CommonTemplate = {
    ////////////////////////////////////
    // Constants
    ////////////////////////////////////
    //FACTOR_ENLARGE: 1.5,


    ////////////////////////////////////
    // Color
    COLOR_WHITE: {
        r: 0xff,
        g: 0xff,
        b: 0xff
    },
    COLOR_TRANSPARENCY: {
        a: 0
    },

    ////////////////////////////////////
    // Time
    DRUATION_ACTIVE_INTERVAL: 500,

    ////////////////////////////////////
    // Template for DimView
    // dim: {
        // type: 'DimWindow',
        // x: 0,
        // y: 0,
        // width: scene.width,
        // height: scene.height,
        // color: {
            // r: 0,
            // g: 0,
            // b: 0
        // },
        // opacity: 102
    // }

};

exports = CommonTemplate;




////////////////////////////////////////////////////////////////////////////////
// DO NOT CROSS
// DEPRECATED CODE STARTS FROM HERE
////////////////////////////////////////////////////////////////////////////////