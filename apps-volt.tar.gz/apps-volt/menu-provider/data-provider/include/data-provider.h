#ifndef  __DATA_PROVIDER_H__
#define  __DATA_PROVIDER_H__

#include <stdbool.h>
#include <menu/menu-provider.h>

int create_provider(struct data_provider_cbs **cbs);
int delete_provider(struct data_provider_cbs **cbs);
int reset_Auto_Start_Update();

#endif /* __DATA_PROVIDER_H__ */
