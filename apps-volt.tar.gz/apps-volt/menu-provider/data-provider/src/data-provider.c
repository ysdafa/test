#include <stdio.h>
#include <stdlib.h>
#include <Elementary.h>
#include "dbg.h"
#include "i18n.h"
#include "data-provider.h"
#include "vconf.h"
#include "was_db_api.h"

#ifndef PLUGIN_API
#define PLUGIN_API __attribute__ ((visibility("default")))
#endif

#define GET_TRANSLATED_TEXT(SID)    (dgettext("autostartupdate-dataprovider",(SID)))

static int get_display_name(const char *key, char **value)
{
    _INFO("key:%s",key);
   int gameFlag = 0;
    if(!strcmp(key,"db/menu/Smarthub/App_Game_Auto_Update"))		
    { 		 
              vconf_get_bool( "memory/volt/support_game_panel", &gameFlag);
		if(gameFlag){
			*value = strdup(GET_TRANSLATED_TEXT("TV_SID_APP_AND_GAME_AUTO_UPDATE"));   
              }else
              {
                     *value = strdup(GET_TRANSLATED_TEXT("TV_SID_APP_AUTO_UPDATE"));   
              }
    }
	else if(!strcmp(key,"db/menu/Smarthub/Auto-Start_Settings/Channel-bound_Apps_Ticker"))
    {
		*value = strdup(GET_TRANSLATED_TEXT("TV_SID_CHANNEL_BOUND_APPS_TICKER"));
    }
    _INFO("Key: Value    %s--%s",key,*value );
    return 0;
}

static int get_help_text(const char *key, char **value)
{
    _INFO("key:%s",key);
	int gameFlag = 0;
    
    if(!strcmp(key,"db/menu/Smarthub/App_Game_Auto_Update"))
    {
		vconf_get_bool( "memory/volt/support_game_panel", &gameFlag);
	       if(gameFlag){
			  *value = strdup(GET_TRANSLATED_TEXT("TV_SID_AUTOMATICALLY_UPDATE_ISTALLED_APPS_GAEMS"));
              }
		else{
		 	  *value = strdup(GET_TRANSLATED_TEXT("TV_SID_AUTOMATICALLY_UPDATE_ISTALLED_APPS"));
		}                                                                            
	}
	else if(!strcmp(key,"db/menu/Smarthub/Auto-Start_Settings/Channel-bound_Apps_Ticker"))
	{
	    //*value = strdup(GET_TRANSLATED_TEXT("TV_SID_SELECT_WHETER_OR_NOT_CHANNEL_BOUND_APPS_INFORMATION"));
	    *value = strdup(evas_textblock_text_utf8_to_markup(NULL, GET_TRANSLATED_TEXT("TV_SID_SELECT_WHETER_OR_NOT_CHANNEL_BOUND_APPS_INFORMATION")));
	}
    _INFO("Key: Value    %s--%s",key,*value );
    return 0;
}

static int set_int(const char *key, int value)
{
	if(vconf_set_int(key, value))
	{
		return value;
	}
	return 0;
}

static int get_int(const char *key, int *value)
{
	if(vconf_get_int(key, value))
	{
		return *value;
	}
	return 0;
}
static int set_string(const char *key, const char *value)
{
	if(vconf_set_str(key, value))
	{
		return 1;
	}
	return 0;
}
static int get_string(const char *key, char **value)
{
	*value = vconf_get_str(key);
	if(!(*value))
	{
		return 1;
	}
	return 0;
}
static const void **get_list_items(const char *key, int *item_cnt)
{
	char **p = NULL;
       int i =0;
	p=calloc(30, sizeof(*p));
	
	int nRealNum = 0;
	was_app_info_s* pAppList = NULL;

	p[0]=calloc(1,1024);
	strncpy( p[0], "Off", strlen("Off")+1);     
	
	p[1]=calloc(1,1024);
	strncpy( p[1], "Channel-Bound Apps", strlen("Channel-Bound Apps")+1);   
	
       int ret = was_get_ticker_app_list(20, &pAppList, &nRealNum);
	if( 0 !=ret)
	{
	    _INFO("Get ticker app list error or ticker app list size is 0, return value is [%d]", ret);
	     *item_cnt = 2;
	     return (const void **)p;
	}
	_INFO("ticker app size is %d", nRealNum);
	if( !pAppList )
	{
            	_INFO("pAppList is null");
		 *item_cnt = 2;
            	return (const void **)p;
	}
       for(i = 0; i<nRealNum; i++)
       {
		p[i+2]=calloc(1,1024);
		strncpy( p[i+2], pAppList[i].app_title, strlen(pAppList[i].app_title)+1);
	 }
	  *item_cnt = 2 + nRealNum;
	return (const void **)p;
}

static int get_list_item_display_value(void *it, char **value)
{
	char *p, *a;
	p=calloc(1,1024);
	a = it;
	if(0 == strncmp(a,"Channel-Bound Apps",strlen("Channel-Bound Apps")))
	{
		strncpy( p, GET_TRANSLATED_TEXT("TV_SID_CHANNEL_BOUND_APPS"), strlen(GET_TRANSLATED_TEXT("TV_SID_CHANNEL_BOUND_APPS"))+1 );
	}
	else if(0 == strncmp(a,"Off",strlen("Off")))
	{
		strncpy( p, GET_TRANSLATED_TEXT("UID_OFF"), strlen(GET_TRANSLATED_TEXT("UID_OFF"))+1 );
	}else
	{
		strncpy( p, a, strlen(a)+1 );
	}
	*value = p;
	
	return 0;
}

static int get_list_item_string_value(void *it, char **value)
{
	char *p, *a;
	p=calloc(1,1024);
	a = it;	
	strncpy( p, a, strlen(a)+1 );
	*value = p;

	return 0;
}

PLUGIN_API int reset_Auto_Start_Update(){
	
	int resetFlag = vconf_set_int("db/menu/Smarthub/App_Game_Auto_Update", 0);
	resetFlag = vconf_set_int("db/menu/Smarthub/Auto-Start_Settings/Channel-bound_Apps_Ticker", 0);

	return resetFlag;
}

PLUGIN_API int create_provider(struct data_provider_cbs **cbs)
{
	struct data_provider_cbs *m_cbs;
	m_cbs = calloc(1,sizeof(*m_cbs));
	bindtextdomain("autostartupdate-dataprovider", LOCALEDIR);
	m_cbs->get_display_name = &get_display_name;
       m_cbs->get_help_text = &get_help_text;
       m_cbs->set_int = &set_int;
       m_cbs->get_int = &get_int;
	m_cbs->set_string = &set_string;
	m_cbs->get_string = &get_string;
      m_cbs->get_list_items = &get_list_items ;
	m_cbs->get_list_item_display_value = &get_list_item_display_value ;
	 m_cbs->get_list_item_string_value = &get_list_item_string_value ;
	*cbs = m_cbs;
	return 0;
}

PLUGIN_API int delete_provider(struct data_provider_cbs **cbs)
{
	if(!cbs)
	{
		return 1;
	}

	if(*cbs)
	{
		free(*cbs);
	}
	return 0;
}
