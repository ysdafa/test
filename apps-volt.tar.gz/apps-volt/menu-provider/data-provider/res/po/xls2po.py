#!/usr/bin/env python
######################################################################
# xls2po.py by Moonsoo Kim ( ms930.kim@samsung.com )                 #
# You can convert excel file to po                                   #
# To use this tool, you need to install python-xlrd                  #
#                                                                    #
# 2014.07.08 Initial Creation                                        #
# 2014.11.05 Apply 2015 new Langs, Apply locale name changes         #
######################################################################
import xlrd
import sys
import time

ERROR_PO = 'error'
LANG_START_OFFSET = 8 # the first colum index that contains translation text
LangToLocaleConvertTable = {
	'Kor':'ko_KR', 'EngUS':'en_US', 'FraUS':'fr_CA',
	'SpaUS':'es_MX', 'PorUS':'pt_BR', 'Alb':'sq_AL',
	'Aze':'az_AZ', 'Bos':'bs_BA', 'Bul':'bg_BG',
	'Cro':'hr_HR', 'Cze':'cs_CZ', 'Dan':'da_DK',
	'Dut':'nl_NL', 'Est':'et_EE', 'Fin':'fi_FI',
	'Fra':'fr_FR', 'Deu':'de_DE', 'Gre':'el_GR',
	'Hun':'hu_HU', 'Ita':'it_IT', 'Kaz':'kk_KZ',
	'Lat':'lv_LV', 'Ltu':'lt_LT', 'Mac':'mk_MK',
	'Nor':'nn_NO', 'Eng':'en_GB', 'Pol':'pl_PL',
	'Por':'pt_PT', 'Rom':'ro_RO', 'Rus':'ru_RU',
	'Ser':'sr_RS', 'Slk':'sk_SK', 'Slv':'sl_SI',
	'Spa':'es_ES', 'Swe':'sv_SE', 'Tur':'tr_TR',
	'Ukr':'uk_UA', 'Uzb':'uz_UZ@cyrillic', 'Chi':'zh_CN',
	'Hkg':'zh_HK', 'Tpe':'zh_TW', 'Tha':'th_TH',
	'Arb':'ar_AE', 'Fsi':'fa_IR', 'Heb':'he_IL',
	'Ind':'id_ID', 'Mal':'ms_MY', 'Vie':'vi_VN',
	'Asm':'as_IN', 'Ben':'bn_IN', 'Bhi':'bh_IN',
	'Guj':'gu_IN', 'Kan':'kn_IN', 'Kas':'ks_IN',
	'Kon':'kok_IN', 'Mym':'ml_IN', 'Mai':'mai_IN',
	'Man':'mni_IN', 'Mar':'mr_IN', 'Nep':'ne_NP',
	'Ori':'or_IN', 'Pun':'pa_PK', 'San':'sat_IN',
	'Sas':'sa_IN', 'Sin':'sd_IN', 'Tam':'ta_IN',
	'Tel':'te_IN', 'Tul':'tu_IN', 'Dev':'hi_IN',
	'Urd':'ur_PK', 'Afr':'af_ZA', 'Zul':'zu_ZA',
	'Swa':'sw_KE', 'Amh':'am_ET', 'Yor':'yo_NG',
	'Igb':'ig_NG', 'Hau':'ha_NG', 'Xho':'xh_ZA',
	'Mon':'mn_MN', 'Jpn':'ja_JP', 'Arm':'hy_AM',
	'Geo':'ka_GE', 'Bur':'my_MM', 'Khm':'km_KH',
	'Sor':'ckb_IQ','Kur':'ku_TR', 'Au':'en_AU'
}

PO_HEADER="msgid \"\"\nmsgstr \"\"\n\"MIME-Version: 1.0\\n\"\n\"Content-Type: text/plain; charset=UTF-8\\n\"\n\"Content-Transfer-Encoding: 8bit\\n\"\n\n"

# read language name...
def GetPoName(excelLangHeader, outputDirectory):
	try:
		# e.g. Korean(Kor)
		startIndex = excelLangHeader.index('(') + 1
		endIndex   = len(excelLangHeader) - 1
		languageKey = excelLangHeader[startIndex:endIndex]

		if languageKey in LangToLocaleConvertTable.keys():
			return outputDirectory + '/' + LangToLocaleConvertTable[languageKey] + '.po'
		else:
			return ERROR_PO
	except Exception, e:
	  	print " [Error] An invalid header is skipped, check your excel file : %s" %excelLangHeader
		return ERROR_PO

def GetSID(sid):
	return 'msgid \"%s\"' % sid

def GetMsgStr(msgStr):
	return 'msgstr \"%s\"' % msgStr

def WritePO(f, data):
	f_out = open(f, "wb")
	f_out.write(PO_HEADER)
	f_out.write(data)
	f_out.close()

##########################################
# Main                                   #
##########################################
def main():
	
	startTime = time.time()

	if len(sys.argv) != 3:
		print '\nUsage : %s <ExcelFileName> <OutputDirectory>\n' %sys.argv[0]
		print ' e.g.  %s TVViewer_Resource_Text.xls ./po\n' %sys.argv[0]
		return

	excelFileName   = sys.argv[1]
	outputDirectory = sys.argv[2]

	print "Start Converting '%s'..." %excelFileName

	try:
		workBook  = xlrd.open_workbook(excelFileName)
		workSheet = workBook.sheet_by_name('Input_Resource')
	except Exception, e:
		print " [Error] Failed to open excel file. DRM may have been applied ?"
		return

	numRows  = workSheet.nrows - 1
	numCols = workSheet.ncols - 1

	if numRows < 1:
		print 'There is no content in the given excel file !'
		return

	if numCols <= (LANG_START_OFFSET+1):
		print 'There is no translated language in the give excel file ! check the file format !'
		return

	# check header should be skipped or not 
	startRow = -1 
	if workSheet.cell_value(0,0) == 'OSD DB ID':
		startRow = 0

	col = LANG_START_OFFSET - 1
	while col < numCols:
		col += 1
		excelLangHeader = workSheet.cell_value(0, col)
		poName = GetPoName(excelLangHeader, outputDirectory)
		if poName == ERROR_PO:
			continue

		poOut = ''
		row = startRow

		while row < numRows:
			row += 1
			sid = GetSID(workSheet.cell_value(row,0))

			# Cell Types: 0=Empty, 1=Text, 2=Number, 3=Date, 4=Boolean, 5=Error, 6=Blank
			if workSheet.cell_type(row,col) == 1: 
				msgStr = GetMsgStr(workSheet.cell_value(row,col).strip('\n').replace('"', '\\"').replace('\n', '\\n'))
			else:
				msgStr = GetMsgStr(workSheet.cell_value(row,col))

			data = '\n' + sid + '\n' + msgStr + '\n'
			poOut = poOut + data

		WritePO(poName, poOut.encode('utf-8'))

	totalelapsed = time.time() - startTime
	print ">> Job Finshed. Total : %d SIDs are convertd in %f sec\n" %(numRows, totalelapsed)

if __name__ == "__main__":
	main()
