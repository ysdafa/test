#ifndef  __VISIBILITY_CHECKER_H__
#define  __VISIBILITY_CHECKER_H__

#include <stdbool.h>

bool check_visibility_int(const char *key, int data);
bool check_visibility_bool(const char *key, bool data);
bool check_visibility_double(const char *key, double data);
bool check_visibility_string(const char *key, const char *data);

#endif /* __VISIBILITY_CHECKER_H__ */
