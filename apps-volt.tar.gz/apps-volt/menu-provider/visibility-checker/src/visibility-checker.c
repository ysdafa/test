#include <stdio.h>
#include "dbg.h"
#include "i18n.h"
#include "visibility-checker.h"
#include <system_info.h>



#ifndef PLUGIN_API
#define PLUGIN_API __attribute__ ((visibility("default")))
#endif

PLUGIN_API bool check_visibility_int(const char *key, int data)
{
	/* code to check value of key against data and return true or false*/
	bool nSupportAutoUpdate = 1;
    //system_info_get_value_int(SYSTEM_INFO_KEY_HD_AUDIO_SUPPORTED, &nSupportHdAudio);
	return nSupportAutoUpdate;
}
PLUGIN_API bool check_visibility_bool(const char *key, bool data)
{
	/* code to check value of key against data and return true or false*/
	
	bool nSupportAutoUpdate = true;
    //system_info_get_value_bool(SYSTEM_INFO_KEY_HD_AUDIO_SUPPORTED, &nSupportHdAudio);
	return nSupportAutoUpdate;
}
PLUGIN_API bool check_visibility_double(const char *key, double data)
{
	/* code to check value of key against data and return true or false*/
	return true;
}
PLUGIN_API bool check_visibility_string(const char *key, const char *data)
{
	/* code to check value of key against data and return true or false*/
	return true;
}


