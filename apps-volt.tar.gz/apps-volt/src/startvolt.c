#include <sharedvc.h>
#include <dbg.h>
#include <unistd.h>

int main(int argc, char **argv)
{
	LOGE("In main function");
	bundle *b = bundle_create();
 	bundle_add(b, "--root", "/usr/apps/org.volt.firstscreen/bin/");
	bundle_add(b,"--data-path", "/opt/down/panels/apps_temp");
	bundle_add(b, "--v8.gc.threshold", "204800");
  	bundle_add(b, "--v8.gc.threshold-poll-interval", "3");
	if (access("/opt/down/panels/apps/src/app.js", F_OK) == 0 ||access("/opt/down/panels/apps/src/app.js.spm", F_OK) == 0) 
	{
  	      bundle_add(b,"--app-js", "/opt/down/panels/apps/src/app.js");
 	} 
 	else 
 	{
 		bundle_add(b,"--app-js", "/usr/apps/org.volt.apps/src_original/app.js");
 	}
	startVoltContainer(argc, argv, b);
	bundle_free(b);
	LOGE("waiting");
	return 0;
}
