var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var AppInstallMgr = Volt.require("app/common/appInstallMgr.js");
var EventMediator = Volt.require('app/common/eventMediator.js');
var voltapi = Volt.require('modules/voltapi.js');

jasmine.describe("AppInstallMgr Test Suite", function() {
    var installCallback;
    
    jasmine.beforeEach(function() {
        voltapi.WAS.init();
        voltapi.WAS.createManagerProxy();
    });

    jasmine.it("Testing AppInstallMgr module loaded correctly", function() {
        jasmine.expect(AppInstallMgr).toBeDefined();
    });

    jasmine.it("Testing AppInstallMgr installApp()", function() {
        
        var ret = false;
        
        jasmine.runs(function() {

            AppInstallMgr.registerCallback('voltapi.WAS.WAS_MANAGER_DOWNLOAD_PROGRESS', cb1);
            AppInstallMgr.registerCallback('voltapi.WAS.WAS_MANAGER_DOWNLOAD', cb2);
            AppInstallMgr.registerCallback('voltapi.WAS.WAS_MANAGER_INSTALL_PROGRESS', cb3);
            AppInstallMgr.registerCallback('voltapi.WAS.WAS_MANAGER_INSTALL', cb4);

            function cb1(eventType, data1, data2){
                jasmine.expect(data1).toContain("downloadProgress");
            };

            function cb2(eventType, data1, data2){
                jasmine.expect(data1).toContain("downloadResult");
            };

            function cb3(eventType, data1, data2){
                jasmine.expect(data1).toContain("installProgress");
            };

            function cb4(eventType, data1, data2){
                jasmine.expect(data1).toContain("installResult");
                ret = true;
            };

            AppInstallMgr.installApp("11091000000");
        });

        jasmine.waitsFor(function() {
            return ret;
        }, "Request took too long", 20000);
    });


    jasmine.it("Testing AppInstallMgr cancelinstallApp()", function() {
        
        var ret = false;
        
        jasmine.runs(function() {

            AppInstallMgr.registerCallback('voltapi.WAS.WAS_MANAGER_DOWNLOAD_CANCELED', cb5);

            function cb5(eventType, data1, data2){
                jasmine.expect(data1).toContain("cancelResult");
                ret = true;
            };

            AppInstallMgr.cancelInstallApp("11091000000");
        });

        jasmine.waitsFor(function() {
            return ret;
        }, "Request took too long", 3000);
    });

    jasmine.it("Testing AppInstallMgr getInstallList()", function() {
        jasmine.expect(AppInstallMgr.getInstallList("11091000000")).not.toBeNull();
    });

    jasmine.it("Testing AppInstallMgr getAllInstallList()", function() {
        jasmine.expect(AppInstallMgr.getAllInstallList()).not.toBeNull();
    });

    jasmine.it("Testing AppInstallMgr removeAllInstallList()", function() {
        print(AppInstallMgr.removeAllInstallList());
        jasmine.expect(AppInstallMgr.getAllInstallList()).toEqual([]);
    });
});