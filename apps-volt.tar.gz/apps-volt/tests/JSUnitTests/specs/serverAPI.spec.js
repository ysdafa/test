var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var ServerAPI = Volt.require("app/common/serverAPI.js");

jasmine.describe("ServerAPI Test Suite", function() {
    
    var success_called = false,
        error_called = false,
        success_response = false,
        error_response = false;

    var self = this;

    jasmine.beforeEach(function() {
        success_called = false;
        error_called = false;
        success_response = false,
        error_response = false;
    });

    jasmine.it("Testing ServerAPI module loaded correctly", function() {
        jasmine.expect(ServerAPI).toBeDefined();
    });

    jasmine.it('Testing getCategoryList API from server', function() {
       
        jasmine.runs(function() {
            ServerAPI.getCategoryList({
                success: function(data, status, response) {
                    if (response.status == 200) {
                        success_response = true;
                    } else {
                        error_response = true;
                    } 
                    success_called = true;
                },
                error: function(object, status, exception) {
                    error_called = true;
                },
                complete: function() {
                    jasmine.expect(success_response).toBeTruthy();
                    jasmine.expect(error_response).toBeFalsy();
                    jasmine.expect(success_called).toBeTruthy();
                    jasmine.expect(error_called).toBeFalsy();
                }
            });
        });

        jasmine.waitsFor(function() {
            return success_called;
        }, "Request took too long", 5000);

    });

    jasmine.it('Testing getCategoryAppList API from server', function() {

        jasmine.runs(function() {
           
            ServerAPI.getCategoryAppList({
                id: 0000008904,
                success: function(data, status, response) {
                    if (response.status == 200) {
                        success_response = true;
                    } else {
                        error_response = true;
                    } 
                    success_called = true;
                },
                error: function(object, status, exception) {
                    error_called = true;
                },
                complete: function() {
                    jasmine.expect(success_response).toBeTruthy();
                    jasmine.expect(error_response).toBeFalsy();
                    jasmine.expect(success_called).toBeTruthy();
                    jasmine.expect(error_called).toBeFalsy();
                }
            });
        });

        jasmine.waitsFor(function() {
            return success_called;
        }, "Request took too long", 5000);
    });


    jasmine.it('Testing getMostPopular API from server', function() {
                
        jasmine.runs(function() {
            ServerAPI.getMostPopular({
                success: function(data, status, response) {
                    if (response.status == 200) {
                        success_response = true;
                    } else {
                        error_response = true;
                    } 
                    success_called = true;
                },
                error: function(object, status, exception) {
                    error_called = true;
                },
                complete: function() {
                    jasmine.expect(success_response).toBeTruthy();
                    jasmine.expect(error_response).toBeFalsy();
                    jasmine.expect(success_called).toBeTruthy();
                    jasmine.expect(error_called).toBeFalsy();
                }
            });
        });

        jasmine.waitsFor(function() {
            return success_called;
        }, "Request took too long", 5000);
    });

    jasmine.it('Testing getWhatsNew API from server', function() {
                
        jasmine.runs(function() {
            ServerAPI.getWhatsNew({
                success: function(data, status, response) {
                    if (response.status == 200) {
                        success_response = true;
                    } else {
                        error_response = true;
                    } 
                    success_called = true;
                },
                error: function(object, status, exception) {
                    error_called = true;
                },
                complete: function() {
                    jasmine.expect(success_response).toBeTruthy();
                    jasmine.expect(error_response).toBeFalsy();
                    jasmine.expect(success_called).toBeTruthy();
                    jasmine.expect(error_called).toBeFalsy();
                }
            });
        });

        jasmine.waitsFor(function() {
            return success_called;
        }, "Request took too long", 5000);
    });

    jasmine.it('Testing getDetail API from server', function() {        
        jasmine.runs(function() {
            ServerAPI.getAppDetail({
                path : {
                    appId : 11091300004
                },
                success: function(data, status, response) {
                    if (response.status == 200) {
                        success_response = true;
                    } else {
                        error_response = true;
                    } 
                    success_called = true;
                },
                error: function(object, status, exception) {
                    error_called = true;
                },
                complete: function() {
                    jasmine.expect(success_response).toBeTruthy();
                    jasmine.expect(error_response).toBeFalsy();
                    jasmine.expect(success_called).toBeTruthy();
                    jasmine.expect(error_called).toBeFalsy();
                }
            });
        });

        jasmine.waitsFor(function() {
            return success_called;
        }, "Request took too long", 5000);
    });

    jasmine.it('Testing putAppGradePoint API from server', function() {
            jasmine.runs(function() {
            ServerAPI.putAppGradePoint({
                path : {
                    appId : 11091300004
                },
                param : {
                    rate : 5
                },
                success: function(data, status, response) {
                    if (response.status == 200) {
                        success_response = true;
                    } else {
                        error_response = true;
                    } 
                    success_called = true;
                },
                error: function(object, status, exception) {
                    error_called = true;
                },
                complete: function() {
                    jasmine.expect(success_response).toBeTruthy();
                    jasmine.expect(error_response).toBeFalsy();
                    jasmine.expect(success_called).toBeTruthy();
                    jasmine.expect(error_called).toBeFalsy();
                }
            });
        });

        jasmine.waitsFor(function() {
            return success_called;
        }, "Request took too long", 5000);
    });
});