var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var _ = Volt.require("modules/underscore.js")._;
var ServerAPI = Volt.require("app/common/serverAPI.js");
var WhatsNewCollection = Volt.require("app/models/whatsNewCollection.js");

jasmine.describe("whatsNewCollection Test Suite", function() {
    
    var whatsNewCollection;

    jasmine.beforeEach(function() {
        whatsNewCollection = new WhatsNewCollection();
    });

    jasmine.it("Testing WhatsNewCollection loaded correctly", function() {
        jasmine.expect(whatsNewCollection).toBeDefined();
    });

    jasmine.it("Testing WhatsNewCollection created correctly", function() {
        jasmine.expect(whatsNewCollection).toBeDefined();
    });

    jasmine.it('Testing WhatsNewCollection data fetch and verification data from server', function() {
        jasmine.runs(function() {
            whatsNewCollection.fetch();
        });

        jasmine.waitsFor(function() { 
            return whatsNewCollection.length > 0; 
        }, "Request took too long", 5000);

        jasmine.runs(function() {
            jasmine.expect(whatsNewCollection.length).toBeGreaterThan(0);

            if (whatsNewCollection.length > 0) {
                whatsNewCollection.each(function(categories) {
                    jasmine.expect(categories.get('id')).not.toBeNull();
                    jasmine.expect(categories.get('name')).not.toBeNull();
                    jasmine.expect(categories.get('title')).not.toBeNull();
                    jasmine.expect(categories.get('uri')).not.toBeNull();
                });
            }
        });
    });
});