var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var _ = Volt.require("modules/underscore.js")._;
var ServerAPI = Volt.require("app/common/serverAPI.js");
var MostPopularCollection = Volt.require("app/models/mostPopularCollection.js");

jasmine.describe("MostPopularCollection Test Suite", function() {
    
    var mostPopularCollection;

    jasmine.beforeEach(function() {
        mostPopularCollection = new MostPopularCollection();
    });

    jasmine.it("Testing MostPopularCollection loaded correctly", function() {
        jasmine.expect(mostPopularCollection).toBeDefined();
    });

    jasmine.it("Testing MostPopularCollection created correctly", function() {
        jasmine.expect(mostPopularCollection).toBeDefined();
    });

    jasmine.it('Testing MostPopularCollection data fetch and verification data from server', function() {
        jasmine.runs(function() {
            mostPopularCollection.fetch();
        });

        jasmine.waitsFor(function() { 
            return mostPopularCollection.length > 0; 
        }, "Request took too long", 5000);

        jasmine.runs(function() {
            jasmine.expect(mostPopularCollection.length).toBeGreaterThan(0);

            if (mostPopularCollection.length > 0) {
                mostPopularCollection.each(function(categories) {
                    jasmine.expect(categories.get('id')).not.toBeNull();
                    jasmine.expect(categories.get('name')).not.toBeNull();
                    jasmine.expect(categories.get('title')).not.toBeNull();
                    jasmine.expect(categories.get('uri')).not.toBeNull();
                });
            }
        });
    });
});