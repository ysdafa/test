var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var _ = Volt.require("modules/underscore.js")._;
var ServerAPI = Volt.require("app/common/serverAPI.js");
var CategoriesInfoCollection = Volt.require("app/models/categoriesInfoCollection.js");

jasmine.describe("CategoriesInfoCollection Test Suite", function() {
    
    var categoriesInfoCollection;

    jasmine.beforeEach(function() {
        categoriesInfoCollection = new CategoriesInfoCollection();
    });

    jasmine.it("Testing CategoriesInfoCollection loaded correctly", function() {
        jasmine.expect(CategoriesInfoCollection).toBeDefined();
    });

    jasmine.it("Testing CategoriesInfoCollection created correctly", function() {
        jasmine.expect(categoriesInfoCollection).toBeDefined();
    });

    jasmine.it('Testing CategoriesInfoCollection data fetch and verification data from server', function() {
        jasmine.runs(function() {
            categoriesInfoCollection.fetch();
        });

        jasmine.waitsFor(function() { 
            return categoriesInfoCollection.length > 0; 
        }, "Request took too long", 5000);

        jasmine.runs(function() {
            jasmine.expect(categoriesInfoCollection.length).toBeGreaterThan(0);

            if (categoriesInfoCollection.length > 0) {
                categoriesInfoCollection.each(function(categories) {
                    jasmine.expect(categories.get('id')).not.toBeNull();
                    jasmine.expect(categories.get('name')).not.toBeNull();
                    jasmine.expect(categories.get('title')).not.toBeNull();
                    jasmine.expect(categories.get('uri')).not.toBeNull();
                });
            }
        });
    });
});