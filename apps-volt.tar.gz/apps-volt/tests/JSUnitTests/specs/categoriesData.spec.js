var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var _ = Volt.require("modules/underscore.js")._;
var ServerAPI = Volt.require("app/common/serverAPI.js");
var CategoriesInfoCollection = Volt.require("app/models/categoriesInfoCollection.js");
var CategoriesListCollection = Volt.require("app/models/categoriesListCollection.js");

jasmine.describe("Categories data fetch and verification test suite", function() {
    
    var categoriesInfoCollection,
        categoriesListCollection,
        categoryId = [];

    jasmine.describe(" - CategoriesInfoCollection test case", function() {

        jasmine.beforeEach(function() {
            categoriesInfoCollection = new CategoriesInfoCollection();
        });

        jasmine.it("Testing CategoriesInfoCollection loaded correctly", function() {
            jasmine.expect(CategoriesInfoCollection).toBeDefined();
        });

        jasmine.it("Testing CategoriesInfoCollection created correctly", function() {
            jasmine.expect(categoriesInfoCollection).toBeDefined();
        });

        jasmine.it('Testing CategoriesInfoCollection data fetch and verification data from server', function() {
            jasmine.runs(function() {
                categoriesInfoCollection.fetch();
            });

            jasmine.waitsFor(function() { 
                return categoriesInfoCollection.length > 0; 
            }, "Request took too long", 5000);

            jasmine.runs(function() {
                jasmine.expect(categoriesInfoCollection.length).toBeGreaterThan(0);

                if (categoriesInfoCollection.length > 0) {
                    categoriesInfoCollection.each(function(categories) {
                        jasmine.expect(categories.get('id')).not.toBeNull();
                        jasmine.expect(categories.get('name')).not.toBeNull();
                        jasmine.expect(categories.get('title')).not.toBeNull();
                        jasmine.expect(categories.get('uri')).not.toBeNull();

                        categoryId.push(categories.get('id'));
                    });
                }
            });
        });
    });

    jasmine.describe(" - CategoriesListCollection test case", function() {
        
        jasmine.beforeEach(function() {
            categoriesListCollection = new CategoriesListCollection();
        });

        jasmine.it("Testing CategoriesListCollection loaded correctly", function() {
            jasmine.expect(CategoriesInfoCollection).toBeDefined();
        });

        jasmine.it("Testing CategoriesListCollection created correctly", function() {
            jasmine.expect(categoriesListCollection).toBeDefined();
        });

        jasmine.it("Testing get app list in each category test" , function() {
            _.each(categoryId, function(cid) {
                var self = this;
                this.cid = cid;

                jasmine.runs(function() {
                    categoriesListCollection.fetch({ categoryId: self.cid });
                });

                jasmine.waitsFor(function() { 
                    return categoriesListCollection.length > 0; 
                }, "Request took too long", 5000);

                jasmine.runs(function() {
                    jasmine.expect(categoriesListCollection.length).toBeGreaterThan(0);

                    // if (categoriesListCollection.length > 0) {
                    //     categoriesListCollection.each(function(categories) {
                    //         jasmine.expect(categories.get('id')).not.toBeNull();
                    //         jasmine.expect(categories.get('title').text).not.toBeNull();
                            
                    //     });
                    // }
                });
            });
        });
    });
});
