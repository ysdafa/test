var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var _ = Volt.require("modules/underscore.js")._;
var ServerAPI = Volt.require("app/common/serverAPI.js");
var DetailModel = Volt.require("app/models/detailModel.js");
var voltapi = Volt.require('modules/voltapi.js');

var TEST_APP_ID = "111199000560";
var TEST_GRADE_POINT = 3;

jasmine.describe("DetailModel Test Suite", function() {
    
    var detailModel;

    jasmine.beforeEach(function() {
        detailModel = new DetailModel();
    });

    jasmine.it("Testing DetailModel loaded correctly", function() {
        jasmine.expect(DetailModel).toBeDefined();
    });

    jasmine.it("Testing DetailModel created correctly", function() {
        jasmine.expect(detailModel).toBeDefined();
    });

    jasmine.it('Testing DetailModel data fetch and verification data from server', function() {
        jasmine.runs(function() {
            detailModel.fetch({
                appId : TEST_APP_ID
            });
        });

        jasmine.waitsFor(function() { 
            return detailModel.id > 0; 
        }, "Request took too long", 5000);

        jasmine.runs(function() {
            // jasmine.expect(categoriesInfoCollection.length).toBeGreaterThan(0);
            if ( detailModel ) {
                jasmine.expect(detailModel.get('id')).not.toBeNull();
                jasmine.expect(detailModel.get('title')).not.toBeNull();
                jasmine.expect(detailModel.get('updated')).not.toBeNull();
                jasmine.expect(detailModel.get('vendor')).not.toBeNull();
                jasmine.expect(detailModel.get('supportemail')).not.toBeNull();
                jasmine.expect(detailModel.get('description')).not.toBeNull();
                jasmine.expect(detailModel.get('filesize')).not.toBeNull();
                jasmine.expect(detailModel.get('rated')).not.toBeNull();
                jasmine.expect(detailModel.get('gradeavg')).not.toBeNull();
                jasmine.expect(detailModel.get('icon')).not.toBeNull();
                jasmine.expect(detailModel.get('usbInstall')).not.toBeNull();
                jasmine.expect(detailModel.get('screenshotlarge1')).not.toBeNull();
                jasmine.expect(detailModel.get('screenshot2')).not.toBeNull();
                jasmine.expect(detailModel.get('screenshot3')).not.toBeNull();
                jasmine.expect(detailModel.get('screenshot4')).not.toBeNull();
                jasmine.expect(detailModel.get('relatedapps')).not.toBeNull();
            }
        });
    });

    jasmine.it('Testing put gradePoint to server', function() {


        jasmine.waitsFor(function() { 
            ServerAPI.putAppGradePoint({
                path    : {appId: TEST_APP_ID},
                param   : {rate : TEST_GRADE_POINT},
            });
        });

    });
});




jasmine.describe("ContentsMgr Test Suite", function() {

    var result;

    jasmine.beforeEach(function() {
        result = voltapi.ContentsMgr.init(function(){
            Volt.log("Connect USB");
        }, function(){
            Volt.log("Disconnect USB");
        });
    });

    jasmine.it("Testing ContentsMgr init successfully", function() {
        jasmine.expect(result).toBeDefined();
    });

    jasmine.it('Testing ContentsMgr function', function() {
        jasmine.expect(voltapi.ContentsMgr.connect()).not.toBeNull();
        jasmine.expect(voltapi.ContentsMgr.getStorages()).not.toBeNull();
        jasmine.expect(voltapi.ContentsMgr.disconnect()).not.toBeNull();
    });

});