var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var DeviceInfoModel = Volt.require("app/models/deviceInfoModel.js");
var voltapi = Volt.require('modules/voltapi.js');

jasmine.describe("DeviceInfoModel Test Suite", function() {
    
    var deviceInfoModel;

    jasmine.beforeEach(function() {
        voltapi.WAS.init();
        voltapi.WAS.createManagerProxy();
    });

    jasmine.it("Testing DeviceInfoModel loaded correctly", function() {
        jasmine.expect(DeviceInfoModel).toBeDefined();
    });

    jasmine.it('Testing DeviceInfoModel data fetch and verification data from WAS', function() {
        jasmine.runs(function() {
            DeviceInfoModel.updateInfoFromWAS();
            jasmine.expect(DeviceInfoModel.get('appsDbStatus')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('categoryType')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('chipInfo')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('country')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('duid')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('firmwareVersion')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('hubsiteStatus')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('lineupModel')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('localSet')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('localTime')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('macAddr')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('managerStatus')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('modelId')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('networksStatus')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('productType')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('sefVersion')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('serverType')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('syncStatus')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('wpBaseline')).not.toBeNull();
            jasmine.expect(DeviceInfoModel.get('countryCode')).not.toBeNull();
        });
    });
});