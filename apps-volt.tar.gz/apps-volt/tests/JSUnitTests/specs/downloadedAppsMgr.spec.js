var jasmine = Volt.require("tests/JSUnitTests/jasmine.js");
var _ = Volt.require("modules/underscore.js")._;
var voltapi = Volt.require('modules/voltapi.js');
var DownloadedAppsMgr = Volt.require('app/common/downloadedAppsMgr.js');

jasmine.describe("DownloadedAppsMgr Test Suite", function() {
    
    jasmine.beforeEach(function() {
        voltapi.WAS.init();
        voltapi.WAS.createManagerProxy();
        voltapi.WAS.createTokenProxy();
        voltapi.WAS.createUtilProxy();

        DownloadedAppsMgr.initialize();
    });

    jasmine.it("Testing downloadedAppsMgr loaded correctly", function() {
        jasmine.expect(DownloadedAppsMgr).toBeDefined();
    });

    jasmine.it("Testing downloadedAppsMgr created correctly", function() {
        jasmine.expect(DownloadedAppsMgr).toBeDefined();
    });    

    jasmine.it('Testing downloadedAppsMgr data fetch and verification data from was', function() {
        
        DownloadedAppsMgr.fetch();

        var len = DownloadedAppsMgr.downloadedAppList.length;
        jasmine.expect(len).toBeGreaterThan(0);

        for(var i=0; i < len; i++){
            jasmine.expect(DownloadedAppsMgr.downloadedAppList[i].id).not.toBeNull();
            jasmine.expect(DownloadedAppsMgr.downloadedAppList[i].version).not.toBeNull();
        }

    });

    jasmine.it('Testing downloadedAppsMgr check data', function() {
        
        jasmine.expect(DownloadedAppsMgr.isDownloaded('org.tizen.browser')).toEqual(true);

    });

    jasmine.it('Testing downloadedAppsMgr getlist', function() {
        
        var list = DownloadedAppsMgr.downloadedAppList;
        jasmine.expect(DownloadedAppsMgr.getDownloadedList()).toBe(list);

    });

    jasmine.it('Testing downloadedAppsMgr getobject', function() {
        
        var list = DownloadedAppsMgr.downloadedAppList;
        jasmine.expect(DownloadedAppsMgr.getDownloadedAppInfo()).not.toBeNull();

    });

});