module.exports = function(grunt) {

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    jshint: {
      files: ['gruntfile.js', '../modules/**/*.js', '../tests/**/*.js', '../examples/**/*.js'],
      options: {
        // options here to override JSHint defaults
        globals: {
          Volt: true
        },
        //Ignoring for now until I break out the mustache dependency
        ignores: ['../modules/VoltJSON.js', '../examples/XMLTest/SaxParser.js', '../examples/SRCSmartHub/**/*.js', '../examples/SRC4K/**/*.js',
                  '../modules/backbone.js', '../modules/underscore.js'],
        //Ignore the whitepsace error
        "-W099": true
      }
    },
    shell: {
      unitTest: {
        options: { // Options
          stdout: true
        },
        command: '<%= pkg.voltPath %> ./JSUnitTests/harness.js --root ../'
      }
    },
    watch: {
      scripts: {
        files: './JSUnitTests/**/*.js',
        tasks: ['shell'],
      },
    }
  });

  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-shell');
  grunt.loadNpmTasks('grunt-contrib-watch');

  grunt.registerTask('default', ['shell', 'jshint']);

  grunt.registerTask('unitTest', ['shell']);

};
