#ifndef _FIRSTSCRENNLISTCONTROL_H
#define _FIRSTSCRENNLISTCONTROL_H

namespace Bridge
{
	class FirstScreenControlBridge : public virtual DataListBridge, public IFirstScreenListListener
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "FirstScreenControl";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual CDataListControl* constructSubWidget(Widget* parent, float width, float height, const ScriptObject& argObject);

		//Listener call back from control.
		virtual bool OnMainMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex);
		virtual bool OnScrollListItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int scrollDataIndex);
		virtual bool OnSubMenuItemLoaded(class IFirstScreenListControl* list, int mainMenuIndex, int subMenuIndex);

	public:
		FirstScreenControlBridge()
		{
		}

		enum E_LISTENER_TYPE
		{
			MAIN_ITEM_LOAD = 0,
			MAIN_ITEM_UNLOAD,
			MAIN_ITEM_ASYNC_LOAD,
			SUB_ITEM_LOAD,
			SUB_ITEM_UNLOAD,
			SUB_ITEM_ASYNC_LOAD,
			SCROLL_ITEM_LOAD,
			SCROLL_ITEM_UNLOAD,
			SCROLL_ITEM_ASYNC_LOAD,
			FOCUS_CHANGE_START,
			FOCUS_CHANGE,
			MOVE_OUT,
			ITEM_INDEX_CHANGE
		};

	private:

		// Methods
		static ScriptObject m_AddMainMenuItem(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_AddSubItem(IAnimatable* self, const ScriptArray& args);
		static ScriptObject m_SetScrollItemNumber(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_ExpandMainMenu(IAnimatable* self, const ScriptArray& args);
		static ScriptObject m_ShrinkMainMenu(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_SetMaxMargin(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_SetExpandAnimationDuration(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_SetScrollSpeed(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_AddMainMenuData(IAnimatable* self, const ScriptArray& args);
		static ScriptObject m_AddSubMenuData(IAnimatable* self, const ScriptArray& args);
		static ScriptObject m_AddScrollMenuData(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_MainMenuData(IAnimatable* self, const ScriptArray& args);
		static ScriptObject m_SubMenuData(IAnimatable* self, const ScriptArray& args);
		static ScriptObject m_ScrollMenuData(IAnimatable* self, const ScriptArray& args);

		static ScriptObject m_SetFocusRange(IAnimatable* self, const ScriptArray& args);
	};
}

#endif