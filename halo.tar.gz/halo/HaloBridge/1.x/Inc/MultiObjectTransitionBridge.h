#ifndef _MULTIOBJECT_TRANSITION_INCLUDED_H_
#define _MULTIOBJECT_TRANSITION_INCLUDED_H_

namespace Bridge
{
	class InternalTransListener : public ITimeLineListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(Started);
		DEFINE_CALLBACK_FUNCTION(Via);
		DEFINE_CALLBACK_FUNCTION(Stoped);

		virtual bool OnStarted(class ITimeLine *animation, void *data);
		virtual bool OnVia(class ITimeLine *animation, void *data);
		virtual bool OnStoped(class ITimeLine *animation, bool flagFinished, void *data);
	protected:

	private:
	};

	class TransListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "MultiObjectTransitionListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class MultiObjectTransitionBridge : virtual public ScriptBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "MultiObjectTransition";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual void destroyFromScript(void* destroyedObject);

	private:
		static IWidgetExtension::EAnimatableValue m_AniType(const ScriptObject &jsStringObject);
		static void m_SetDestination(CMultiObjectTransition* self, const ScriptArray& args);

		static ScriptObject m_SetDuration(CMultiObjectTransition* self, const ScriptArray& args);
		static ScriptObject m_AddObjectDestination(CMultiObjectTransition* self, const ScriptArray& args);
		static ScriptObject m_Play(CMultiObjectTransition* self, const ScriptArray& args);
		static ScriptObject m_Stop(CMultiObjectTransition* self, const ScriptArray& args);
		static ScriptObject m_AddListener(CMultiObjectTransition* self, const ScriptArray& args);
	};
}

#endif