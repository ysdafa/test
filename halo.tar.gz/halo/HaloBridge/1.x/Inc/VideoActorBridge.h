#if !defined(WIN32) && !defined(LINUX_BUILD)
#ifndef _VIDEOACTOR_BRIDGE_H
#define _VIDEOACTOR_BRIDGE_H


namespace Bridge
{
	class VideoActorListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const { return "VideoActorListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalVideoActorListener : public IVideoActorListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(VideoPlayCompleted);

		virtual bool OnVideoPlayCompleted(class IVideoActor* videoActor);
	};

	class VideoActorBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "VideoActor"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
		
		virtual Color getDefaultColor() { return Color(0, 0, 0, 0); }
	private:

		static ScriptObject play(CVideoActor* self, const ScriptArray &args);
		static ScriptObject stop(CVideoActor* self, const ScriptArray &args);
		static ScriptObject pause(CVideoActor* self, const ScriptArray &args);
		static ScriptObject getPlayerState(CVideoActor* self, const ScriptArray &args);	

		/** Translate access to the video type property between JS and native. */	
		static ScriptObject getVideoType(CVideoActor* self);	
		static void setVideoType(CVideoActor* self, ScriptObject);

		static ScriptObject addListener(CVideoActor* self, const ScriptArray &args);
		static ScriptObject removeListener(CVideoActor* self, const ScriptArray &args);



	public:
		static ClutterVideoController deserializeType(std::string typeStr);
		static std::string serializeType(ClutterVideoController type);
		static std::string serializePlayerState(ClutterVideoControllerState state);
	};
}

#endif
#endif
