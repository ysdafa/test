#ifndef _IMAGEWIDGETHELPERBRIDGE_H
#define _IMAGEWIDGETHELPERBRIDGE_H

#define ARG_IS_VALID(object, string, type) ASSERT(true == object.has(string) && true == object.get(string).type())
#define ARG_HAS_STRING(object, string) ASSERT(true == object.has(string))

namespace Bridge
{
	//class ActorListenerBridge : public ScriptBridge
	//{
	//public:

	//protected:
	//	virtual inline const char* getScriptClassName() const {return "FirstShownListener";}
	//	virtual void mapScriptInterface(ScriptContext&);
	//	virtual void* constructFromScript(const ScriptArray& args);
	//	virtual void destroyFromScript(void* pointerToDestroyedObject);

	//private:
	//};

	//class InternalActorListener : public IActorListener
	//{
	//public:
	//	DEFINE_CALLBACK_FUNCTION(FirstFocusIn);

	//	virtual bool OnFirstFocusIn(class IActor* actor);
	//};

	class ImageWidgetExBridge : public ImageWidgetBridge
	{
	public:
		template<typename NATIVE_TYPE>
		static ScriptObject wrapNativeObjectToJS(NATIVE_TYPE *object)
		{
			return wrapExistingNativeObject<NATIVE_TYPE>(object);
		}

		template<typename NATIVE_TYPE>
		static NATIVE_TYPE* unwrapObject(ScriptObject wrappedNativeObject)
		{
			return unwrapNativeObject<NATIVE_TYPE>(wrappedNativeObject);
		}

	protected:
		virtual inline const char* getScriptClassName() const {return "ImageWidgetEx";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual ImageWidget* constructImageWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
		virtual void destroyFromScript(void* destroyedObject);

	private:

		static ScriptObject handleDestroy(CImageWidgetEx* self, const ScriptArray& args);
		// Methods
		//static ScriptObject setParent(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setBackgroundColor(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setSize(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setPositon(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setLayout(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject isReversible(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject enableReverse(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject setOrientation(CImageWidgetEx* self, const ScriptArray& args);
		

		//static ScriptObject show(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject hide(CImageWidgetEx* self, const ScriptArray& args);

		//static ScriptObject setClipArea(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject removeClipArea(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setAlpha(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setPivotPoint(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setRotation(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject setScale(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject addChild(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject numOfChildren(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject destroyAllChildren(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject raise(CImageWidgetEx* self, const ScriptArray& args);
		//static ScriptObject lower(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject enable(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject enableFocus(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject enablePointerFocus(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject setFocus(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject killFocus(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject isFocused(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject setTabWindow(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject moveTab(CImageWidgetEx* self, const ScriptArray& args);
		
		
		static ScriptObject addMouseListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject addKeyboardListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject addClickListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject addKeyLongPressListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject addFocusListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject addDragListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject addCursorListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeMouseListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeKeyboardListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeClickListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeKeyLongPressListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeFocusListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeDragListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeCursorListener(CImageWidgetEx* self, const ScriptArray& args);

		static ScriptObject addActorListener(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeActorListener(CImageWidgetEx* self, const ScriptArray& args);

		static ScriptObject addAction(CImageWidgetEx* self, const ScriptArray& args);
		static ScriptObject removeAction(CImageWidgetEx* self, const ScriptArray& args);

		//static ScriptObject bindTransition(CImageWidgetEx* self, const ScriptArray& args);

		static ScriptObject m_getOrientation(CImageWidgetEx* self);
		static void m_setOrientation(CImageWidgetEx* self, ScriptObject value);
		static ScriptObject m_isReversible(CImageWidgetEx* self);
		static void m_enableReverse(CImageWidgetEx* self, ScriptObject value);
	};
}

#endif
