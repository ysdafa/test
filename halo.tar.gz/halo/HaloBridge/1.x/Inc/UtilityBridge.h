#ifndef _UTILITY_BRIDGE_H
#define _UTILITY_BRIDGE_H

namespace Bridge
{
	class UtilityBridge : public ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Utility";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject) {}

	private:
		static ScriptObject extractForegroundColor(CUtility* self, const ScriptArray& args);
		static ScriptObject extractIconColor(CUtility* self, const ScriptArray& args);

	};

}

#endif