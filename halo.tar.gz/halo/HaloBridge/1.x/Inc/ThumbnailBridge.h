#ifndef _THUMBNAIL_BRIDGE_H_
#define _THUMBNAIL_BRIDGE_H_

using namespace HALO;

namespace Bridge
{
	class ThumbnailListenerBridge : public BaseListenerBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "ThumbnailListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);
	};

	class InternalThumbListener : public IThumbnailListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ImageReady);
		DEFINE_CALLBACK_FUNCTION(ScrollImageReady);
		DEFINE_CALLBACK_FUNCTION(InformationIconReady);
		DEFINE_CALLBACK_FUNCTION(AttachIconReady);
		DEFINE_CALLBACK_FUNCTION(IconClicked);

		virtual bool OnImageReady(class IThumbnail *thumbnail, int index, bool success);
		virtual bool OnScrollImageReady(class IThumbnail *thumbnail, int index, bool success);
		virtual bool OnInformationIconReady(class IThumbnail *thumbnail, int index, bool success);
		virtual bool OnAttachIconReady(class IThumbnail *thumbnail, int index, bool success);
		virtual bool OnIconClicked(class IThumbnail *thumbnail, int index);

	};

	class ThumbnailBridge : public ActorBridge
	{
	public:
		const std::set<void*> *InstanceCreatedObjects()
		{
			return &instanceCreatedObjects;
		}

	protected:
		virtual inline const char* getScriptClassName() const { return "Thumbnail"; }

		virtual void mapScriptInterface(ScriptContext& context);

		//virtual void* constructFromScript(const ScriptArray& args);
		virtual Color getDefaultColor() { return Color(0, 0, 0, 0); }

		virtual CThumbnail* constructThumbnail(Widget* parent, float width, float height, const ScriptArray& args);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

		//virtual inline void destroyFromScript(void* destroyedObject)
		//{
		//	CThumbnail* widget = reinterpret_cast<CThumbnail*>(destroyedObject);
		//	delete widget;
		//}

	private:
		static EHAlignment deserializeHorizontalTextAlignment(std::string alignmentStr, EHAlignment theDefault);
		static EVAlignment deserializeVerticalTextAlignment(std::string alignmentStr, EVAlignment theDefault);
		static ClutterTimelineDirection deserializeTextScrollDirection(std::string directionStr, ClutterTimelineDirection theDefault);
		static ClutterTextScrollType deserializeTextScrollType(std::string typeStr, ClutterTextScrollType theDefault);
		static TweenMode deserializeTransitionMode(std::string tweenStr);

		static ImageWidget::FillMode deserializeFillMode(const std::string&);
		static std::string serializeFillMode(const ImageWidget::FillMode);

		static TRegion ScriptToRange(const ScriptObject& val);

		static IThumbnail::EAnchorPoint deserializeAnchorPoint(const std::string&);

		static void parseThumbnailParams(const ScriptObject& options, IThumbnail::EThumbnailStyles& styles, IThumbnail::EThumbnailStyles& visibleStyles, IThumbnail::TThumbnailAttr& attr);
		static void parseInformationTexts(const ScriptObject& textObj, IThumbnail::TThumbnailAttr& attr);
		static void parseInformationIcons(const ScriptObject& iconObj, IThumbnail::TThumbnailAttr& attr);
		static void parseAttachIconParams(const ScriptObject& iconObj, IThumbnail::TThumbnailAttr& attr);

		static ScriptObject setThumbnailStyle(CThumbnail* self, const ScriptArray& args);

		static ScriptObject setContentImage(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationColor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationText(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationTextColor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationTextFont(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationIcon(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setAttachIcon(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setAttachIconImage(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setAttachText(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setAttachTextColor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setAttachTextFont(CThumbnail* self, const ScriptArray& args);
		static ScriptObject enableAttachTextEllipsize(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setAttachTextScrollAttribute(CThumbnail* self, const ScriptArray& args);
		static ScriptObject enableAttachTextAutoScroll(CThumbnail* self, const ScriptArray& args);
		static ScriptObject enableInformationTextEllipsize(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationTextScrollAttribute(CThumbnail* self, const ScriptArray& args);
		static ScriptObject enableInformationTextAutoScroll(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setAttachTextColorPickingRange(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationColorPickingRange(CThumbnail* self, const ScriptArray& args);
		static ScriptObject getInformationColor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject getInformationColorPicking(CThumbnail* self, const ScriptArray& args);
		static ScriptObject getInformationExtractColor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject getImageColorPicking(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationRatingValue(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setInformationRatingImage(CThumbnail* self, const ScriptArray& args);

		static ScriptObject setProgressRange(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setProgressValue(CThumbnail* self, const ScriptArray& args);

		static ScriptObject setScaleAnimation(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setStyleTransAnimation(CThumbnail* self, const ScriptArray& args);
		static ScriptObject visualizeThumbnailStyle(CThumbnail* self, const ScriptArray& args);
		static ScriptObject visualizeAttachIcon(CThumbnail* self, const ScriptArray& args);
		static ScriptObject visualizeInformationIcon(CThumbnail* self, const ScriptArray& args);
		static ScriptObject visualizeInformationText(CThumbnail* self, const ScriptArray& args);
		static ScriptObject visualizeInformationRating(CThumbnail* self, const ScriptArray& args);

		static ScriptObject thumbnailStyle(CThumbnail* self, const ScriptArray& args);
		static ScriptObject visibleThumbnailStyle(CThumbnail* self, const ScriptArray& args);

		static ScriptObject addThumbnailListener(CThumbnail* self, const ScriptArray& args);
		static ScriptObject removeThumbnailListener(CThumbnail* self, const ScriptArray& args);

		static ScriptObject scaleElement(CThumbnail* self, const ScriptArray& args);

		static ScriptObject enableFontScale(CThumbnail* self, const ScriptArray& args);
		static ScriptObject SetTTSText(CThumbnail* self, const ScriptArray& args);

		static ScriptObject setImage(CThumbnail* self, const ScriptArray& args);

		static ScriptObject getElementAllocation(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setElementAllocation(CThumbnail* self, const ScriptArray& args);

		static ScriptObject setElementOpacity(CThumbnail* self, const ScriptArray& args);

		static ScriptObject setDimBackgroundColor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setDimImage(CThumbnail* self, const ScriptArray& args);
		static ScriptObject dim(CThumbnail* self, const ScriptArray& args);
		static ScriptObject raiseElement(CThumbnail* self, const ScriptArray& args);

		static ScriptObject setChecked(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setCheckBoxImage(CThumbnail* self, const ScriptArray& args);

		static ScriptObject scrollImage(CThumbnail* self, const ScriptArray& args);
		static ScriptObject setScrollPlayerImages(CThumbnail* self, const ScriptArray& args);
		static ScriptObject SetFoveaImageScaleFactor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject SetFoveaImageInterpolatorType(CThumbnail* self, const ScriptArray& args);
		static ScriptObject SetFoveaInfoBoxScaleFactor(CThumbnail* self, const ScriptArray& args);
		static ScriptObject SetFoveaInfoBoxInterpolatorType(CThumbnail* self, const ScriptArray& args);
		
#if !defined(WIN32) && !defined(LINUX_BUILD)
		static ScriptObject setVideoActorAttr(CThumbnail* self, const ScriptArray& args);
		static ScriptObject play(CThumbnail* self, const ScriptArray &args);
		static ScriptObject stop(CThumbnail* self, const ScriptArray &args);
		static ScriptObject pause(CThumbnail* self, const ScriptArray &args);

#endif
	};
}

#endif //_THUMBNAIL_BRIDGE_H_
