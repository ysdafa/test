#ifndef _ASYNCTASKBRIDGE_H
#define _ASYNCTASKBRIDGE_H

namespace Bridge
{
	class TaskListenerBridge : public virtual ScriptBridge, public virtual ITaskListener
	{
	protected:
		virtual inline const char* getScriptClassName() const { return "TaskListener"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
		}

	public:
		TaskListenerBridge()
		{
		}
		virtual void* OnStart(void* params);
		virtual bool OnUpdate(void* result);
		virtual bool OnFinish(void* result);
		virtual bool OnCancel(void* params);
	private:
		ScriptFunction m_OnStart;
		ScriptFunction m_OnUpdate;
		ScriptFunction m_OnFinish;
		ScriptFunction m_OnCancel;
		static ScriptObject SetTask(ITaskListener* self, const ScriptArray& args);
		static ScriptObject GetTask(ITaskListener* self, const ScriptArray& args);
	};

	class AsyncTaskBridge : public virtual ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "AsyncTask";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
		}

		virtual IAsyncTask* constructAsyncTask(void* params, IThreadPool* threadPool);

	public:
		AsyncTaskBridge()
		{
		}

	private:
		static ScriptObject Execute(IAsyncTask* self, const ScriptArray& args);
		static ScriptObject Update(IAsyncTask* self, const ScriptArray& args);
		static ScriptObject Cancel(IAsyncTask* self, const ScriptArray& args);
		static ScriptObject SetTaskListener(IAsyncTask* self, const ScriptArray& args);
		static ScriptObject RemoveTaskListener(IAsyncTask* self, const ScriptArray& args);

	};
}

#endif