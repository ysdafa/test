#ifndef _DEVICE_BRIDGE_H
#define _DEVICE_BRIDGE_H

namespace Bridge
{
	//! DeviceBridge
	class DeviceBridge : public ScriptBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "Device";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);

		virtual inline void destroyFromScript(void* destroyedObject)
		{
			IDevice* device = reinterpret_cast<IDevice*>(destroyedObject);
			delete device;
		}
		
	public:
		DeviceBridge()
		{
			allowGarbageCollection = false;
		}

	private:
		static ScriptObject getDeviceType(IDevice* self, const ScriptArray& args);
		static ScriptObject getDeviceID(IDevice* self, const ScriptArray& args);
		static ScriptObject getDeviceName(IDevice* self, const ScriptArray& args);
	};

	//! Mouse
	class MouseDeviceBridge : public DeviceBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "MouseDevice";}
		
		virtual void* constructFromScript(const ScriptArray& args);

		virtual void mapScriptInterface(ScriptContext& context);
		
	public:
		enum EMouseOption
		{
			OPTION_USER_TYPE = 0,
			MOUSE_OPTION_MAX,
		};

	private:
		static ScriptObject setPointerSensibility(IMouseDevice* self, const ScriptArray& args);
		static ScriptObject getPointerSensibility(IMouseDevice* self, const ScriptArray& args);

		static ScriptObject setMouseOption(IMouseDevice* self, const ScriptArray& args);
		static ScriptObject getMouseOption(IMouseDevice* self, const ScriptArray& args);
	};

	//! KeyboardDevice
	class KeyboardDeviceBridge : public DeviceBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "KeyboardDevice";}

		virtual void* constructFromScript(const ScriptArray& args);

		virtual void mapScriptInterface(ScriptContext& context);

	public:
		enum EKeyboardOption
		{
			OPTION_KEYBOARD_TOGGLE_LANG = 0,
			KEYBOARD_OPTION_MAX,
		};

	private:
		static ScriptObject setKeyboardOption(IKeyboardDevice* self, const ScriptArray& args);
		static ScriptObject getKeyboardOption(IKeyboardDevice* self, const ScriptArray& args);
	};

	//! TouchDevice
	class TouchDeviceBridge : public DeviceBridge
	{
	protected:
		virtual inline const char* getScriptClassName() const {return "TouchDevice";}

		virtual void* constructFromScript(const ScriptArray& args);

		virtual void mapScriptInterface(ScriptContext& context);

	public:
		enum ETouchMode
		{
			TOUCH_DIRECTION = 0,
			TOUCH_POINTING = 1,
		};

	private:
		static ScriptObject setTouchMode(ITouchDevice* self, const ScriptArray& args);
		static ScriptObject getTouchMode(ITouchDevice* self, const ScriptArray& args);
	};

	//! IKeyboardDeviceBridge
	//! IMotionDeviceBridge
	//! ISmartconDeviceBridge

} // End namespace

#endif