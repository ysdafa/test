#ifndef _LABEL_BRIDGE_H
#define _LABEL_BRIDGE_H

namespace Bridge
{
	using namespace HALO;
	class LabelBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "Label"; }

		virtual void mapScriptInterface(ScriptContext& context);

		//virtual IActor* constructWidget(IActor* parent, float width, float height, const ScriptObject& args);
		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setImage(CLabel* self, const ScriptArray& args);
		static ScriptObject setText(CLabel* self, const ScriptArray& args);
		static ScriptObject setTextColor(CLabel* self, const ScriptArray& args);
		static ScriptObject setTextFont(CLabel* self, const ScriptArray& args);
		static ScriptObject setFontSize(CLabel* self, const ScriptArray& args);
		static ScriptObject enableMultiLine(CLabel* self, const ScriptArray& args);
	};
}

#endif