#ifndef _HALOIMAGEBRIDGE_H
#define _HALOIMAGEBRIDGE_H

namespace Bridge
{
	class HaloImageBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "HaloImage";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
	private:
		static ScriptObject setImage(CImage* self, const ScriptArray& args);
	};
}

#endif