#ifndef _BUTTON_BRIDGE_H
#define _BUTTON_BRIDGE_H

namespace Bridge
{
	class ButtonListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const { return "ButtonListener"; }
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};

	class InternalButtonListener : public IButtonListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ButtonClicked);

		virtual bool OnButtonClicked(class IButton* button, EButtonClickType type);
	};

	class ButtonBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "Button"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
	private:
		static ScriptObject backgroundColor(CButton* self, const ScriptArray &args);
		static ScriptObject setBackgroundColor(CButton* self, const ScriptArray &args);

		static ScriptObject backgroundImage(CButton* self, const ScriptArray &args);
		static ScriptObject setBackgroudImage(CButton* self, const ScriptArray &args);

		static ScriptObject text(CButton* self, const ScriptArray &args);
		static ScriptObject setText(CButton* self, const ScriptArray &args);

		static ScriptObject textColor(CButton* self, const ScriptArray &args);
		static ScriptObject setTextColor(CButton* self, const ScriptArray &args);

		static ScriptObject fontSize(CButton* self, const ScriptArray &args);
		static ScriptObject setFontSize(CButton* self, const ScriptArray &args);

		static ScriptObject iconImage(CButton* self, const ScriptArray &args);
		static ScriptObject setIconImage(CButton* self, const ScriptArray &args);

		static ScriptObject iconAlpha(CButton* self, const ScriptArray &args);
		static ScriptObject setIconAlpha(CButton* self, const ScriptArray &args);

		static ScriptObject setBackgroundImageAttr(CButton* self, const ScriptArray &args);
		static ScriptObject setIconAttr(CButton* self, const ScriptArray &args);
		static ScriptObject setTextAttr(CButton* self, const ScriptArray &args);

		static ScriptObject addListener(CButton* self, const ScriptArray &args);
		static ScriptObject removeListener(CButton* self, const ScriptArray &args);

	public:
		static CButton::EButtonState deserializeState(std::string stateStr, CButton::EButtonState theDefault);
		static EHAlignment deserializeHAlignment(std::string alignStr, EHAlignment theDefault);
		static EVAlignment deserializeVAlignment(std::string alignStr, EVAlignment theDefault);
	};
}

#endif