#ifndef _SubList_BRIDGE_H
#define _SubList_BRIDGE_H

namespace Bridge
{
	class SubListListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "SubListListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);

	private:
	};
	
	class InternalSubListListener : public ISubListListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ItemClicked);
		DEFINE_CALLBACK_FUNCTION(FocusChanged);
		DEFINE_CALLBACK_FUNCTION(EnterKeyLongPressed);
		DEFINE_CALLBACK_FUNCTION(TimeOut);

		bool OnItemClicked(class ISubList* subList, int itemIndex);
		bool OnFocusChanged(class ISubList *subList, int fromItemIndex, int toItemIndex);
		bool OnEnterKeyLongPressed(class ISubList *subList, int itemIndex);
		bool OnTimeOut(class ISubList* subList);

	protected:

	private:
	};
	
	class SubListBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "SubList"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget*  constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setFirstLayerBGColor(CSubList* self, const ScriptArray &args);
		static ScriptObject setSecondLayerBGColor(CSubList* self, const ScriptArray &args);
		static ScriptObject setThirdLayerBGBorderWidth(CSubList* self, const ScriptArray &args);
		static ScriptObject setThirdLayerBGBorderColor(CSubList* self, const ScriptArray &args);
		static ScriptObject setFourthLayerBGImage(CSubList* self, const ScriptArray &args);
		static ScriptObject addItem(CSubList* self, const ScriptArray &args);
		static ScriptObject addData(CSubList* self, const ScriptArray &args);
		static ScriptObject updateItem(CSubList* self, const ScriptArray &args);
		static ScriptObject deleteItem(CSubList* self, const ScriptArray &args);
		static ScriptObject updateAllItems(CSubList* self, const ScriptArray &args);
		static ScriptObject setDataSource(CSubList* self, const ScriptArray &args);
		static ScriptObject setSingleLineListPosition(CSubList* self, const ScriptArray &args);
		static ScriptObject setArrowImageAttr(CSubList* self, const ScriptArray &args);
		static ScriptObject setButtonAttr(CSubList* self, const ScriptArray &args);
		static ScriptObject numofItem(CSubList* self, const ScriptArray &args);
		static ScriptObject setDim(CSubList* self, const ScriptArray &args);
		static ScriptObject ifDim(CSubList* self, const ScriptArray &args);
		static ScriptObject showFocus(CSubList* self, const ScriptArray &args);
		static ScriptObject hideFocus(CSubList* self, const ScriptArray &args);
		static ScriptObject setFocus(CSubList* self, const ScriptArray &args);
		static ScriptObject killFocus(CSubList* self, const ScriptArray &args);
		static ScriptObject text(CSubList* self, const ScriptArray &args);
		static ScriptObject text2(CSubList* self, const ScriptArray &args);
		static ScriptObject setAnimationDuration(CSubList* self, const ScriptArray &args);

		static ScriptObject addListener(CSubList* self, const ScriptArray &args);
		static ScriptObject removeListener(CSubList* self, const ScriptArray &args);

		void parseSubListParams(const ScriptObject& options, CSubList::TSubListAttr& attr);
	public:
		static int deserializeAlignment(std::string alignMent);
		static int deserializeScrollType(std::string type);
		static int deserializeScrollDirection(std::string direction);
	};
}

#endif
