#ifndef _FIXEDLAYOUTBRIDGE_H
#define _FIXEDLAYOUTBRIDGE_H

namespace Bridge
{
	class FixedLayoutBridge : public LayoutManagerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "FixedLayout"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual ILayout* constructWidget(const ScriptArray& args);

	private:
		//static ScriptObject setImage(HALO::IActor* self, const ScriptArray& args);
	};
}

#endif