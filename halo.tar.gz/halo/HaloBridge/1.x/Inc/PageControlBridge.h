#ifndef _PAGECONTROL_BRIDGE_H
#define _PAGECONTROL_BRIDGE_H

namespace Bridge
{
	using namespace HALO;
	class PageControlBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "PageControl"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setCurrentPage(CPageControl* self, const ScriptArray& args);

		static ScriptObject setNumberOfPages(CPageControl* self, const ScriptArray& args);

		static ScriptObject setPageIndicatorImage(CPageControl* self, const ScriptArray& args);

		static ScriptObject setHighlightPageIndicatorImage(CPageControl* self, const ScriptArray& args);

		static ScriptObject setPageIndicatorGap(CPageControl* self, const ScriptArray& args);

		static ScriptObject setHideForSinglePageFlag(CPageControl* self, const ScriptArray& args);

		static ScriptObject setPageIndicatorImageSize(CPageControl* self, const ScriptArray& args);
	};
}

#endif