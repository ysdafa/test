#ifndef _TEXTBRIDGE_H
#define _TEXTBRIDGE_H

namespace Bridge
{
	class TextBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "Text";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual HALO::IActor* constructWidget(HALO::IActor* parent, float width, float height, const ScriptObject& argObject);
		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);
	private:
		static ScriptObject setTextColor(HALO::CText* self, const ScriptArray& args);

		static ScriptObject enableMultline(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setText(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setFont(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setTextAlignment(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setRowGap(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setMaxTextCount(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setFontSize(HALO::CText* self, const ScriptArray& args);

		static ScriptObject enableShadow(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setShadowPosition(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setShadowColor(HALO::CText* self, const ScriptArray& args);

		static ScriptObject enableEllipsis(HALO::CText* self, const ScriptArray& args);

		static ScriptObject setScrollAttribute(HALO::CText* self, const ScriptArray& args);

		static ScriptObject startScroll(HALO::CText* self, const ScriptArray& args);

		static ScriptObject stopScroll(HALO::CText* self, const ScriptArray& args);

		static int deserializeScrollType(std::string type);

		static int deserializeScrollDirection(std::string direction);

		//static ScriptObject reSize(HALO::CText* self, const ScriptArray& args);
	};
}

#endif
