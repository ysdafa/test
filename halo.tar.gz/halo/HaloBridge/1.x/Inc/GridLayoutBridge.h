#ifndef _GRIDLAYOUTBRIDGE_H
#define _GRIDLAYOUTBRIDGE_H

namespace Bridge
{
	class GridLayoutBridge : public LayoutManagerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "GridLayout"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual ILayout* constructWidget(const ScriptArray& args);

	private:
		static ScriptObject Attach(ILayout* self, const ScriptArray& args);
		static ScriptObject ChildAt(ILayout* self, const ScriptArray& args);
		static ScriptObject InsertColumn(ILayout* self, const ScriptArray& args);
		static ScriptObject InsertRow(ILayout* self, const ScriptArray& args);
		static ScriptObject InsertNextTo(ILayout* self, const ScriptArray& args);
		static ScriptObject SetDirection(ILayout* self, const ScriptArray& args);
		static ScriptObject Direction(ILayout* self, const ScriptArray& args);
		static ScriptObject EnableColumnHomogeneous(ILayout* self, const ScriptArray& args);
		static ScriptObject IsColumnHomogeneousEnable(ILayout* self, const ScriptArray& args);
		static ScriptObject EnableRowHomogeneous(ILayout* self, const ScriptArray& args);
		static ScriptObject IsRowHomogeneousEnable(ILayout* self, const ScriptArray& args);
		static ScriptObject SetColumnSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject ColumnSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject SetRowSpacing(ILayout* self, const ScriptArray& args);
		static ScriptObject RowSpacing(ILayout* self, const ScriptArray& args);
	};
}

#endif