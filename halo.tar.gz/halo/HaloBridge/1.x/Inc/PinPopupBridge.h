#ifndef _PINPOPUP_BRIDGE_H
#define _PINPOPUP_BRIDGE_H

namespace Bridge
{
	class PinPopupListenerBridge : public BaseListenerBridge
	{
	public:

	protected:
		virtual inline const char* getScriptClassName() const {return "PinPopupListener";}
		virtual void mapScriptInterface(ScriptContext&);
		virtual void* constructFromScript(const ScriptArray& args);
	private:
	};

	class InternalPinPopupListener : public IPinPopupListener
	{
	public:
		DEFINE_CALLBACK_FUNCTION(ValidConfirm);
		virtual bool OnValidConfirm(class IPinPopup* list ,  bool isPassWordRight);
		DEFINE_CALLBACK_FUNCTION(CompareConfirm);
		virtual bool OnCompareConfirm(class IPinPopup* list ,  bool isPassWordRight , const char* pin1Pwd , const char* pin2Pwd);
		DEFINE_CALLBACK_FUNCTION(PinButtonEvent);
		virtual bool OnButtonEvent(class IPinPopup* pinpopup, const int nButtonIndex, EEventTypes eventType);
	protected:
		static std::string deserializeState(IPinPopupListener::EEventTypes eventType);
		static std::string deserializeButtonState(CPinPopup::EPinPopupButtons buttonType);
	};

	class PinPopupBridge :virtual public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "PinPopup"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget*  constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setTitletText(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setTitletTextFontSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setTitletTextColor(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setTitlePosition(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setTitleSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setContentText(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setContentTextFont(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setContentTextFontSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setContentTextFontColor(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setContentRect(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxItemImage(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxBackGroundImage(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxDescriptionText(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxDescriptionTextFontSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxDescriptionTextColor(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxDescriptionRect(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxItemDigitFontSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxItemDigitColor(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxItemDigitFont(CPinPopup* self, const ScriptArray &args);

		static ScriptObject resetPassWord(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxFocus(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonPosition(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonRect(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonImage(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonText(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonTextColor(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonTextFontSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setButtonBackgroundColor(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setPinBoxRect(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setTitleLineRect(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setDigitTextSize(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setDigitGap(CPinPopup* self, const ScriptArray &args);

		static ScriptObject setInputItemsGap(CPinPopup* self, const ScriptArray &args);
		
		static ScriptObject setInputBoxItemSize(CPinPopup* self, const ScriptArray &args);
		
		static ScriptObject addListener(CPinPopup* self, const ScriptArray &args);

		static ScriptObject removeListener(CPinPopup* self, const ScriptArray &args);

		static void parsePinPopupParams(const ScriptObject& options, CPinPopup::TPinPopupAttr& attr);

	public:
		static CPinPopup::EInputBoxState deserializeState(std::string stateStr, CPinPopup::EInputBoxState theDefault);
		static CPinPopup::EInputItemsState deserializeState(std::string stateStr, CPinPopup::EInputItemsState theDefault);
		static CPinPopup::E_PINNUMBER_TYPE deserializeState(std::string stateStr, CPinPopup::E_PINNUMBER_TYPE theDefault);
		static CPinPopup::EPinPopupButtons deserializeButtonState(std::string stateStr, CPinPopup::EPinPopupButtons theDefault);
	};
}

#endif
