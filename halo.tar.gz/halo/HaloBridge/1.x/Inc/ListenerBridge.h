#ifndef _LISTENER_BRIDGE_H
#define _LISTENER_BRIDGE_H

using namespace HALO;

namespace Bridge
{
	class BaseListenerBridge : public ScriptBridge
	{
	public:
		ScriptObject WrapNativeObjectToJS(CActor *control)
		{
			return wrapExistingNativeObject(control);
		}
		virtual void mapScriptInterface(ScriptContext& context);
		virtual void destroyFromScript(void* destroyedObject);
		
	private:
		// destroy
		static ScriptObject handleDestroy(IListener* self, const ScriptArray& args);

	public:
		BaseListenerBridge()
		{
			allowGarbageCollection = false;
		}
	};

	class BaseInternalListener/* : public IListener*/
	{
	public:
		struct TCallback
		{
			TCallback(void) : flagExist(false) {}

			bool flagExist;
			ScriptFunction function;
		};

		BaseInternalListener(BaseListenerBridge *owner) : t_owner(owner) {}

	protected:
		BaseListenerBridge *t_owner;
	};

	class FocusListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "FocusListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	class InternalFocusListener : public BaseInternalListener, public IFocusListener
	{
	public:
		InternalFocusListener(FocusListenerBridge *owner) : BaseInternalListener(owner) {}

		virtual bool OnFocusIn(IActor* pWindow);
		virtual bool OnFocusOut(IActor* pWindow);

	public:
		DEFINE_CALLBACK_FUNCTION(FocusIn);
		DEFINE_CALLBACK_FUNCTION(FocusOut);
	};

	class MouseListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "MouseListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Mouse);

	DEFINE_CALLBACK_FUNCTION(MouseButtonPressed);
	DEFINE_CALLBACK_FUNCTION(MouseButtonReleased);
	DEFINE_CALLBACK_FUNCTION(MouseMoved);
	DEFINE_CALLBACK_FUNCTION(MouseWheel);
	DEFINE_CALLBACK_FUNCTION(MouseClicked);
	DEFINE_CALLBACK_FUNCTION(MousePointerIn);
	DEFINE_CALLBACK_FUNCTION(MousePointerOut);
	DEFINE_CALLBACK_FUNCTION(CapturedMouseButtonPressed);
	DEFINE_CALLBACK_FUNCTION(CapturedMouseButtonReleased);
	DEFINE_CALLBACK_FUNCTION(CapturedMouseMoved);
	DEFINE_CALLBACK_FUNCTION(CapturedMouseWheel);
	DEFINE_CALLBACK_FUNCTION(CapturedMouseClicked);
	DEFINE_CALLBACK_FUNCTION(CapturedMousePointerIn);
	DEFINE_CALLBACK_FUNCTION(CapturedMousePointerOut);

	DEFINE_EVENT_FUNCTION(Mouse, MouseButtonPressed);
	DEFINE_EVENT_FUNCTION(Mouse, MouseButtonReleased);
	DEFINE_EVENT_FUNCTION(Mouse, MouseMoved);
	DEFINE_EVENT_FUNCTION(Mouse, MouseWheel);
	DEFINE_EVENT_FUNCTION(Mouse, MouseClicked);
	DEFINE_EVENT_FUNCTION(Mouse, MousePointerIn);
	DEFINE_EVENT_FUNCTION(Mouse, MousePointerOut);
	DEFINE_EVENT_FUNCTION(Mouse, CapturedMouseButtonPressed);
	DEFINE_EVENT_FUNCTION(Mouse, CapturedMouseButtonReleased);
	DEFINE_EVENT_FUNCTION(Mouse, CapturedMouseMoved);
	DEFINE_EVENT_FUNCTION(Mouse, CapturedMouseWheel);
	DEFINE_EVENT_FUNCTION(Mouse, CapturedMouseClicked);
	DEFINE_EVENT_FUNCTION(Mouse, CapturedMousePointerIn);
	DEFINE_EVENT_FUNCTION(Mouse, CapturedMousePointerOut);

	DEFINE_INTERNAL_CLASS_END();

	class TouchListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "TouchListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Touch);

	DEFINE_CALLBACK_FUNCTION(TouchPressed);
	DEFINE_CALLBACK_FUNCTION(TouchReleased);
	DEFINE_CALLBACK_FUNCTION(TouchMoved);
	DEFINE_CALLBACK_FUNCTION(TouchTap);
	DEFINE_CALLBACK_FUNCTION(TouchFlicked);
	DEFINE_CALLBACK_FUNCTION(TouchPinched);
	DEFINE_CALLBACK_FUNCTION(TouchStretched);
	DEFINE_CALLBACK_FUNCTION(TouchLongPressed);

	DEFINE_EVENT_FUNCTION(Touch, TouchPressed);
	DEFINE_EVENT_FUNCTION(Touch, TouchReleased);
	DEFINE_EVENT_FUNCTION(Touch, TouchMoved);
	DEFINE_EVENT_FUNCTION(Touch, TouchTap);
	DEFINE_EVENT_FUNCTION(Touch, TouchFlicked);
	DEFINE_EVENT_FUNCTION(Touch, TouchPinched);
	DEFINE_EVENT_FUNCTION(Touch, TouchStretched);
	DEFINE_EVENT_FUNCTION(Touch, TouchLongPressed);

	DEFINE_INTERNAL_CLASS_END();

	class KeyboardListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "KeyboardListener";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Keyboard);

	DEFINE_CALLBACK_FUNCTION(KeyPressed);
	DEFINE_CALLBACK_FUNCTION(KeyReleased);
	DEFINE_CALLBACK_FUNCTION(CapturedKeyPressed);
	DEFINE_CALLBACK_FUNCTION(CapturedKeyReleased);

	DEFINE_KEYBOARD_EVENT_FUNCTION(KeyPressed);
	DEFINE_KEYBOARD_EVENT_FUNCTION(KeyReleased);
	DEFINE_KEYBOARD_EVENT_FUNCTION(CapturedKeyPressed);
	DEFINE_KEYBOARD_EVENT_FUNCTION(CapturedKeyReleased);

	DEFINE_INTERNAL_CLASS_END();

	class MotionListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "MotionListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Motion);

	DEFINE_CALLBACK_FUNCTION(MotionTilt);
	DEFINE_CALLBACK_FUNCTION(MotionRoll);
	DEFINE_CALLBACK_FUNCTION(MotionPanning);
	DEFINE_CALLBACK_FUNCTION(MotionSnap);

	DEFINE_EVENT_FUNCTION(Motion, MotionTilt);
	DEFINE_EVENT_FUNCTION(Motion, MotionRoll);
	DEFINE_EVENT_FUNCTION(Motion, MotionPanning);
	DEFINE_EVENT_FUNCTION(Motion, MotionSnap);

	DEFINE_INTERNAL_CLASS_END();

	class RemoteControlListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "RemoCtrlListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};
	
	DEFINE_INTERNAL_CLASS_BEGIN(RemoteControl);

	DEFINE_CALLBACK_FUNCTION(KeyPressed);
	DEFINE_CALLBACK_FUNCTION(KeyReleased);
	DEFINE_CALLBACK_FUNCTION(KeyLongPressed);

	DEFINE_EVENT_FUNCTION(Remocon, KeyPressed);
	DEFINE_EVENT_FUNCTION(Remocon, KeyReleased);
	DEFINE_EVENT_FUNCTION(Remocon, KeyLongPressed);

	DEFINE_INTERNAL_CLASS_END();

	class RidgeListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "RidgeListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
		
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Ridge);

	DEFINE_CALLBACK_FUNCTION(RidgeOn);
	DEFINE_CALLBACK_FUNCTION(RidgeOff);
	DEFINE_CALLBACK_FUNCTION(RidgeMove);
	DEFINE_CALLBACK_FUNCTION(RidgeFlick);

	DEFINE_EVENT_FUNCTION(Ridge, RidgeOn);
	DEFINE_EVENT_FUNCTION(Ridge, RidgeOff);
	DEFINE_EVENT_FUNCTION(Ridge, RidgeMove);
	DEFINE_EVENT_FUNCTION(Ridge, RidgeFlick);

	DEFINE_INTERNAL_CLASS_END();

	class CursorListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "CursorListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
		
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Cursor);

	DEFINE_CALLBACK_FUNCTION(Shown);
	DEFINE_CALLBACK_FUNCTION(Hidden);
	DEFINE_CALLBACK_FUNCTION(DeviceTypeChanged);

	DEFINE_EVENT_FUNCTION(Cursor, Shown);
	DEFINE_EVENT_FUNCTION(Cursor, Hidden);
	DEFINE_EVENT_FUNCTION(Cursor, DeviceTypeChanged);

	DEFINE_INTERNAL_CLASS_END();

	class SensorListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "SensorListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Sensor);

	DEFINE_CALLBACK_FUNCTION(SensorStart);
	DEFINE_CALLBACK_FUNCTION(SensorMoved);
	DEFINE_CALLBACK_FUNCTION(SensorEnd);

	DEFINE_EVENT_FUNCTION(Sensor, SensorStart);
	DEFINE_EVENT_FUNCTION(Sensor, SensorMoved);
	DEFINE_EVENT_FUNCTION(Sensor, SensorEnd);

	DEFINE_INTERNAL_CLASS_END();

	class ClickListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "ClickListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Click);

	DEFINE_CALLBACK_FUNCTION(Clicked);
	DEFINE_CALLBACK_FUNCTION(LongPress);

	DEFINE_EVENT_FUNCTION(, Clicked);
	DEFINE_EVENT_FUNCTION(LongPress, LongPress);

	DEFINE_INTERNAL_CLASS_END();

	class SemanticEventListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "SemanticEventListener";}

		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(SemanticEvent);

	DEFINE_CALLBACK_FUNCTION(SemanticEvent);

	DEFINE_EVENT_FUNCTION(, SemanticEvent);

	DEFINE_INTERNAL_CLASS_END();

	class SystemEventListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "SystemEventListener";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(SystemEvent);

	DEFINE_CALLBACK_FUNCTION(SystemQuit);
	DEFINE_CALLBACK_FUNCTION(CursorVisible);
	DEFINE_CALLBACK_FUNCTION(CursorHidden);

	DEFINE_SYSTEM_EVENT_FUNCTION(SystemQuit);
	DEFINE_SYSTEM_EVENT_FUNCTION(CursorVisible);
	DEFINE_SYSTEM_EVENT_FUNCTION(CursorHidden);

	DEFINE_INTERNAL_CLASS_END();

	class CustomEventListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "CustomEventListener";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(CustomEvent);

	DEFINE_CALLBACK_FUNCTION(CustomEvent);

	DEFINE_EVENT_FUNCTION(, CustomEvent);

	DEFINE_INTERNAL_CLASS_END();

	class DragListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "DragListener";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Drag);

	DEFINE_CALLBACK_FUNCTION(DragBegin);
	DEFINE_CALLBACK_FUNCTION(DragEnd);
	DEFINE_CALLBACK_FUNCTION(DragMotion);
	DEFINE_CALLBACK_FUNCTION(DragHold);

	DEFINE_EVENT_FUNCTION(Drag, DragBegin);
	DEFINE_EVENT_FUNCTION(Drag, DragEnd);
	DEFINE_EVENT_FUNCTION(Drag, DragMotion);
	DEFINE_EVENT_FUNCTION(Drag, DragHold);

	DEFINE_INTERNAL_CLASS_END();

	class GestureListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "GestureListener";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(Gesture);

	DEFINE_CALLBACK_FUNCTION(GestureBegin);
	DEFINE_CALLBACK_FUNCTION(GestureEnd);
	DEFINE_CALLBACK_FUNCTION(GestureCancel);
	DEFINE_CALLBACK_FUNCTION(GestureProgress);

	DEFINE_EVENT_FUNCTION(Gesture, GestureBegin);
	DEFINE_EVENT_FUNCTION(Gesture, GestureEnd);
	DEFINE_EVENT_FUNCTION(Gesture, GestureCancel);
	DEFINE_EVENT_FUNCTION(Gesture, GestureProgress);

	DEFINE_INTERNAL_CLASS_END();

	class KeyLongPressListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "KeyLongPressListener";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(KeyLongPress);

	DEFINE_CALLBACK_FUNCTION(KeyLongPress);

	DEFINE_EVENT_FUNCTION(Keyboard, KeyLongPress);

	DEFINE_INTERNAL_CLASS_END();

	class KeyCombinationListenerBridge : public BaseListenerBridge
	{
	public:
		virtual inline const char* getScriptClassName() const {return "KeyCombListener";}
		
		virtual void mapScriptInterface(ScriptContext& context);

		virtual void* constructFromScript(const ScriptArray& args);
	};

	DEFINE_INTERNAL_CLASS_BEGIN(KeyCombination);

	DEFINE_CALLBACK_FUNCTION(KeyCombination);

	DEFINE_EVENT_FUNCTION(Keyboard, KeyCombination);

	DEFINE_INTERNAL_CLASS_END();


} // End of namespace


#endif