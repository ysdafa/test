#ifndef _RECTANGLE_BRIDGE_H
#define _RECTANGLE_BRIDGE_H

namespace Bridge
{
	using namespace HALO;
	class RectangleBridge : public ActorBridge
	{
	public:
		virtual inline const char* getScriptClassName() const { return "Rectangle"; }

		virtual void mapScriptInterface(ScriptContext& context);

		virtual Widget* constructWidget(float x, float y, float width, float height, Widget* parent, const ScriptArray& args);

	private:
		static ScriptObject setBorderThickness(CRectangle* self, const ScriptArray& args);

		static ScriptObject setBorderColor(CRectangle* self, const ScriptArray& args);
	};
}

#endif