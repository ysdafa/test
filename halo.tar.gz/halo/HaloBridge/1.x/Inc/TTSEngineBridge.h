#ifndef WIN32
#ifndef _TTSENGINE_BRIDGE_H
#define _TTSENGINE_BRIDGE_H


namespace Bridge
{
	class TTSEngineBridge :virtual public ScriptInstanceBridge
	{
	public:
		TTSEngineBridge();
		~TTSEngineBridge();
		virtual inline const char* getScriptClassName() const {return "TTS"; }

		virtual void mapScriptInterface(ScriptContext& context);
		
		static ScriptObject SetText(TTSEngineBridge *self, const ScriptArray &args);

		static ScriptObject PlayText(TTSEngineBridge *self, const ScriptArray &args);

		static ScriptObject QueueText(TTSEngineBridge *self, const ScriptArray &args);

		static ScriptObject StopText(TTSEngineBridge *self, const ScriptArray &args);
		
	};
}

#endif
#endif
