#ifndef _HALO_BRIDGE_H_
#define _HALO_BRIDGE_H_

#ifdef __cplusplus
extern "C" {
#endif

	void RunHalo(void);

	void ExitHalo(void);

	void HALO_PreInitialize(void);

	void HALO_Initialize(void);

	void HALO_Finalize(void);

#ifdef __cplusplus
}
#endif

#endif